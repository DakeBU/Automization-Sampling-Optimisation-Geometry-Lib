import AutoSamplingTheory.ExampleCases.ProximalBPS.ActualAbsoluteNextEventTime
import Mathlib.Order.Fin.Tuple

/-! Internal event decomposition for the sealed ordered-prefix induction. -/
namespace OrderedEvents92
open scoped NNReal
noncomputable section
set_option autoImplicit false

private def readTime {Z : Type*} (r : (ℝ≥0 × Z) ⊕ Unit) : ℝ :=
  match r with
  | Sum.inl a => a.1
  | Sum.inr _ => 0

private def guard {Z : Type*} (n : ℕ) (T : ℝ≥0)
    (h : Fin (n+1) → ((ℝ≥0 × Z) ⊕ Unit)) : Prop :=
  (∀ j, ∃ a, h j = Sum.inl a) ∧
  StrictMono (fun j => readTime (h j)) ∧
  ∀ i : Fin n, readTime (h i.succ) < (T : ℝ)

private theorem guard_snoc {Z : Type*} (n : ℕ) (T : ℝ≥0)
    (h : Fin (n+1) → ((ℝ≥0 × Z) ⊕ Unit)) (r : (ℝ≥0 × Z) ⊕ Unit) :
    guard (n+1) T (Fin.snoc h r) ↔
      guard n T h ∧ (∃ a, r = Sum.inl a) ∧
        readTime (h (Fin.last n)) < readTime r ∧ readTime r < (T : ℝ) := by
  unfold guard
  have ht : (fun j => readTime ((Fin.snoc h r : Fin (n+2) → _) j)) =
      Fin.snoc (fun j => readTime (h j)) (readTime r) := by
    funext j
    induction j using Fin.lastCases with
    | last => simp only [Fin.snoc_last]
    | cast i => simp only [Fin.snoc_castSucc]
  rw [ht, Fin.strictMono_iff_lt_succ]
  simp only [Fin.forall_iff_castSucc, Fin.snoc_castSucc, Fin.snoc_last,
    Fin.succ_castSucc, Fin.succ_last]
  rw [← Fin.strictMono_iff_lt_succ]
  tauto

private theorem record_history_snoc {Z : Type*}
    (record : ℕ → ((ℝ≥0 × Z) ⊕ Unit)) (n : ℕ) :
    (fun j : Fin (n+2) => record j.val) =
      Fin.snoc (fun j : Fin (n+1) => record j.val) (record (n+1)) := by
  funext j
  induction j using Fin.lastCases with
  | last => simp only [Fin.snoc_last, Fin.val_last]
  | cast i => simp only [Fin.snoc_castSucc, Fin.val_castSucc]

private theorem record_guard_step {Z : Type*}
    (record : ℕ → ((ℝ≥0 × Z) ⊕ Unit)) (n : ℕ) (T : ℝ≥0) :
    guard (n+1) T (fun j => record j.val) ↔
      guard n T (fun j => record j.val) ∧
      ((∃ a, record n = Sum.inl a) ∧ (∃ a, record (n+1) = Sum.inl a) ∧
        readTime (record n) < readTime (record (n+1)) ∧
        readTime (record (n+1)) < (T : ℝ)) := by
  rw [record_history_snoc, guard_snoc]
  simp only [Fin.val_last]
  constructor
  · rintro ⟨hg, hn, hlo, hhi⟩
    exact ⟨hg, hg.1 (Fin.last n), hn, hlo, hhi⟩
  · rintro ⟨hg, _, hn, hlo, hhi⟩
    exact ⟨hg, hn, hlo, hhi⟩

private theorem record_event_step {Ω Z : Type*}
    (record : Ω → ℕ → ((ℝ≥0 × Z) ⊕ Unit)) (n : ℕ) (T : ℝ≥0) :
    {w | guard (n+1) T (fun j => record w j.val)} =
      {w | guard n T (fun j => record w j.val)} ∩
      {w | (∃ a, record w n = Sum.inl a) ∧
        (∃ a, record w (n+1) = Sum.inl a) ∧
        readTime (record w n) < readTime (record w (n+1)) ∧
        readTime (record w (n+1)) < (T : ℝ)} := by
  ext w
  exact record_guard_step (record w) n T

end
end OrderedEvents92
