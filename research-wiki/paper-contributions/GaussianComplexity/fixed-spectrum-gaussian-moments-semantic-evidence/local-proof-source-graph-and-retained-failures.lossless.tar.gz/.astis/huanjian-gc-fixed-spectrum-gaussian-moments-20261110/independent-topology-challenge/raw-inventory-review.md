# Independent phase 1 raw-inventory check

**PASS for raw inventory completeness/content within its three declared source roots. No final source-graph/root-closure admission is given.**

The exact extractor `phase1/FREEZE.json` SHA-256 is `d465a5eefce67b21a93ac34d2d05b21accd9c825cbf6d36edec36f9ca45a1d5b`; its `phase1/raw-inventory.json` is 59051 bytes, SHA-256 `8e55e93d009f24e9fe33e369730d8994203abca076c80493c9f8a51452a428f4`. Only these two machine artifacts were read for this stage. No extractor cognition/private rationale, scripts or new graph were opened.

An independent walk of the pinned original HTML enumerated every p/table/h1–h6 element inside exactly `S4.SS1`, `S4.Thmtheorem5` and `A3.SS3`. It produced the same 64 units: 34 paragraphs, 21 top-level display tables, two h3 and seven h6 headings. Missing units: 0. Extra units: 0.

For every unit, the source ID (or exact heading locator), scope, tag, original line bounds, whitespace-normalized source text, all attached math IDs/alttext/display attributes and all link href/text/title fields match the independent parse. All 124 math attachments and all 10 links are present with no discrepancy. Formula-row groups remain losslessly attached through their individual math IDs; their eventual per-ingredient node/exclusion mapping must still be checked in phase2.

The critical actual-law and means content is intact: the complete source law U∼N(0,Λ⁻¹), Dₙ, M and μₙ definitions; p4.1's E[Uᵢ²]=1/λᵢ; Ex140's two finite-grid expectations; p4.2's **finite-grid**/series exchange; p6.1's zero constant mode and product-to-sum; and Ex144's genuine μₙ precursor. The raw inventory has not replaced these expectations by a deterministic-sum definition.

One annotation needs care at the later projection: the non-source `reason` for `S4.Thmtheorem5.p1.1` says “centered Gaussian inverse covariance.” That wording is ambiguous; the actual attached formula is exact and unambiguous: Λ is precision, and Λ⁻¹ is covariance. This is not a raw-content failure or a requested rewrite of the frozen inventory. Phase2's actual law/covariance nodes must state the correct convention explicitly, consistent with the accepted seal and standard-definition boundary.

The inventory's scope includes neighboring closed C8, variance and bias text because whole raw roots were captured. Their presence is context, not packet credit. Their final EXCLUDED/OPEN dispositions, the p4 unnamed moment/integration obligations, positive spectrum/inverse covariance discharge, and the full producer/private-consumer AND closures remain subject to the separate frozen phase2 review. No whole-paper coverage or theorem completion is inferred from the counts.

This stage read no candidate implementation, proof/API, old/new source graph or author verdict. The freeze manifest contains filenames/hashes of extra stored extracts; those filenames are exposure only and were not treated as additional admitted source regions. Own raw and seal freezes remain unchanged. No build, source V, ledger, frontier, queue, site or shared mutation occurred.
