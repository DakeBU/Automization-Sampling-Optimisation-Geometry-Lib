#!/opt/anaconda3/bin/python
import datetime
import hashlib
import json
import pathlib
import subprocess
import sys

BASE=pathlib.Path(__file__).resolve().parent
argv=['/opt/anaconda3/bin/python',str(BASE/'freeze_phase1.py')]
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
proc=subprocess.run(argv,cwd='/Users/zhouhuanjian/ASTIS-GC',capture_output=True)
out=BASE/'freeze_execution.stdout'
err=BASE/'freeze_execution.stderr'
out.write_bytes(proc.stdout)
err.write_bytes(proc.stderr)
record={'argv':argv,'cwd':'/Users/zhouhuanjian/ASTIS-GC','started_utc':started,
        'returncode':proc.returncode,'stdout_file':out.name,'stderr_file':err.name,
        'stdout_bytes':len(proc.stdout),'stderr_bytes':len(proc.stderr),
        'stdout_sha256':hashlib.sha256(proc.stdout).hexdigest(),
        'stderr_sha256':hashlib.sha256(proc.stderr).hexdigest()}
if proc.returncode==0:
    observed=json.loads(proc.stdout)
    record['observed_freeze_result']=observed
    receipt=BASE/'phase1/freeze_receipt.json'
    record['receipt_sha256_observed']=hashlib.sha256(receipt.read_bytes()).hexdigest()
    assert record['receipt_sha256_observed']==observed['receipt_sha256']
path=BASE/'freeze_execution.json'
path.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
for p in [out,err,path]: p.chmod(0o444)
print(json.dumps(record,ensure_ascii=False,indent=2))
sys.stdout.write(proc.stdout.decode(errors='replace'))
sys.stderr.write(proc.stderr.decode(errors='replace'))
raise SystemExit(proc.returncode)
