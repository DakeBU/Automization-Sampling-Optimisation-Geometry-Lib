"""Record exact normal-once execution streams and receipt; never replay an existing run."""
from pathlib import Path
import datetime,hashlib,json,subprocess,sys
O=Path(__file__).resolve().parent
assert sys.argv[1:]==['normal-once']
command_dir=O/'commands/normal-once';command_dir.mkdir(parents=True,exist_ok=False)
argv=[sys.executable,str(O/'execute_normal_once.py')]
start=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (command_dir/'stdout').open('xb') as out,(command_dir/'stderr').open('xb') as err:
    result=subprocess.run(argv,stdout=out,stderr=err)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
receipt={'argv':argv,'started_at':start,'ended_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
         'exit_code':result.returncode,'executed_script_sha256':sha(O/'execute_normal_once.py'),
         'stdout_sha256':sha(command_dir/'stdout'),'stderr_sha256':sha(command_dir/'stderr'),
         'existing_execution_must_never_be_replayed':True}
(command_dir/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
print((command_dir/('stderr' if result.returncode else 'stdout')).read_text())
raise SystemExit(result.returncode)
