"""Run the normal exploration intake after the independent topology review."""
from pathlib import Path
import hashlib
import json
import stat
import subprocess
import sys

assert sys.flags.optimize == 0
sys.dont_write_bytecode = True
sys.path.insert(0, 'tools')
import astis_advance as advance

workspace = Path(__file__).resolve().parent.relative_to(Path.cwd())
paper = Path('research-wiki/paper-contributions/GaussianComplexity')
evidence = paper / 'truncated-radial-moment-semantic-evidence'
seal_path = paper / 'truncated-radial-moment-statement-seal.json'
cell_path = Path('research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-truncated-radial-moment.json')
ledger_path = Path('runs/substantive_advances.jsonl')
advance_id = 'ASTIS-SA-20261110-GaussianComplexityTruncatedRadialMoment'
owner = 'huanjian_gc_20261110_truncated_radial_moment'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def dump(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode()


def put(path, raw):
    with path.open('xb') as output:
        output.write(raw)


def replay(raw):
    return advance._replay_advances([json.loads(line) for line in raw.splitlines()])


def verify_file_hashes(rows):
    for name, digest in rows.items():
        assert sha(Path(name).read_bytes()) == digest, name


def controls():
    previous = Path('.astis/huanjian-gc-radial-exponential-20261110/intake-baseline.private.json')
    known = set(json.loads(previous.read_bytes())['foreign_control_hashes'])
    known.add('website/content/samplewiki_companion_frontiers.json')
    known.update(str(p) for p in Path('runs').iterdir())
    for n in ['control', 'queues', 'runtime', 'harness', 'state', 'locks']:
        path = Path('.astis') / n
        if path.is_dir() and not path.is_symlink():
            known.update(str(p) for p in path.rglob('*'))
    for p in Path('.astis').iterdir():
        if any(word in p.name.lower() for word in ['queue', 'control', 'goal', 'steer', 'execution']):
            known.add(str(p))
    untracked = subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard', '-z'])
    known.update(raw.decode() for raw in untracked.split(b'\0') if raw)
    result = {}
    for name in sorted(known):
        path = Path(name)
        if path in {cell_path, ledger_path, seal_path} or path.is_relative_to(evidence):
            continue
        if name.startswith('.atlas-upstream/') or not path.exists():
            continue
        info = path.lstat()
        if stat.S_ISREG(info.st_mode) and info.st_size < 100_000_000:
            result[name] = sha(path.read_bytes())
    return result


assert len(sys.argv) == 3, 'exact review admission record and its SHA256'
review_path = Path(sys.argv[1])
review_bytes = review_path.read_bytes()
assert sha(review_bytes) == sys.argv[2]
review = json.loads(review_bytes)
assert review['topology_review_status'] == 'accepted'
verify_file_hashes({row['path']: row['sha256'] for row in review['independent_inputs']})
assert sha(seal_path.read_bytes()) == review['statement_seal_sha256'] == '387aa7a644c79f304dc86667b2b70b87a911011ebf61a6efdc3202e550f17fc8'
seal = json.loads(seal_path.read_bytes())
baseline_path = workspace / 'preproof-baseline.private.json'
assert sha(baseline_path.read_bytes()) == review['private_baseline_sha256']
baseline = json.loads(baseline_path.read_bytes())
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == baseline['head']
producer = seal['producer']['planned_file']
consumer = seal['actual_private_consumer']['planned_file']
assert not Path(producer).exists() and not Path(consumer).exists()
cell_before = cell_path.read_bytes()
assert sha(cell_before) == review['reserved_cell_sha256']
cell = json.loads(cell_before)
assert cell['owner_id'] == owner and cell['status'] == 'claimed'
before = ledger_path.read_bytes()
assert len(before) == baseline['ledger_bytes'] and sha(before) == baseline['ledger_sha256']
states = replay(before)
assert states == baseline['all_foreign_states'] and advance_id not in states
verify_file_hashes(baseline['all_tracked_regular_file_hashes'])
verify_file_hashes(baseline['all_existing_frontier_hashes'])
foreign_controls = controls()
put(workspace / 'intake-controls.private.json', dump(foreign_controls))

name = seal['producer']['name']
boundary = seal['boundary']
proposal = advance.AdvanceProposal(
    advance_id=advance_id, task_id='ASTIS-SW-GAUSSIAN-COMPLEXITY-2026',
    goal='Prove the actual strict row tail first moment and consume it in the scalar bias identity and bound.',
    source_anchor=cell['source_anchor'], theorem_delta=seal['producer']['signature'],
    truth_boundary=boundary, created_by=owner,
    dag_inputs=(cell['source_anchor'], 'Actual standard Gaussian quadratic exponential moment and exact squared-norm mean are candidate compiled parents. Layer cake and all finiteness conditions are internal.'),
    proposed_files=tuple(p for p in cell['owned_files'] if not p.endswith('/')),
    focused_checks=('lake env lean ' + producer, 'lake build Tests.GaussianComplexityFixedSpectrumTruncatedRadialMoment'),
    modes=('source-reading', 'proof-design', 'compiler-diagnosis'), priority=50,
    frontier_cell=cell_path.stem, target_declarations=(name,),
)
proposal.validate()
put(workspace / 'normal-intake-attempted.once.json', dump({
    'advance_id': advance_id, 'before_ledger_sha256': sha(before), 'review_evidence_sha256': sha(review_bytes),
    'no_replay': True,
}))
admission = evidence / 'preproof-source-admission.json'
put(admission, review_bytes)
event_evidence = {'independent_topology': {'file': str(admission), 'sha256': sha(review_bytes)},
                  'statement_seal_sha256': sha(seal_path.read_bytes()), 'truth_boundary': boundary}
advance.propose_advance(proposal)
advance.transition_advance(advance_id, 'CLAIMED', worker_id=owner, evidence=event_evidence)
advance.transition_advance(advance_id, 'EXPLORING', worker_id=owner, evidence=event_evidence)
after = ledger_path.read_bytes()
assert after.startswith(before)
append = after[len(before):]
events = [json.loads(line) for line in append.splitlines()]
assert len(events) == 3 and all(event['advance_id'] == advance_id for event in events)
assert [event.get('state', event.get('to_state')) for event in events] == ['PROPOSED', 'CLAIMED', 'EXPLORING']
now = replay(after)
assert now.pop(advance_id)['state'] == 'EXPLORING' and now == states
verify_file_hashes({n: h for n, h in baseline['all_tracked_regular_file_hashes'].items() if n != str(ledger_path)})
verify_file_hashes(baseline['all_existing_frontier_hashes'])
verify_file_hashes(foreign_controls)
assert cell_path.read_bytes() == cell_before
cell['evidence']['preproof_source_admission'] = event_evidence['independent_topology']
cell['statement_seal']['status'] = 'EXACT_LITERAL_TYPES;INDEPENDENT_TOPOLOGY_ACCEPTED;UNPROVED'
cell['reservation_only'] = 'The normal ledger records EXPLORING under the named owner.'
cell_path.write_bytes(dump(cell))
put(evidence / 'normal-EXPLORING-append.exact.jsonl', append)
summary = {'state': 'EXPLORING', 'append_sha256': sha(append), 'actual_normal_API_calls': 3,
    'foreign_states_preserved': len(states), 'foreign_frontiers_preserved': len(baseline['all_existing_frontier_hashes']),
    'foreign_controls_preserved': len(foreign_controls), 'target_proof_or_sourceV': False}
put(evidence / 'normal-intake-preservation.json', dump(summary))
print(json.dumps(summary))
