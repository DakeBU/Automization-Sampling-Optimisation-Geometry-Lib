import Tests.GaussianComplexityBernsteinWeightedMgf
import NativeLiteralApplications
import Lean

open Lean Elab Command

set_option maxRecDepth 32768
set_option maxHeartbeats 0

namespace NativeAudit8c2d

def tag (s : String) (xs : Array Json := #[]) : Json := .arr (#[toJson s] ++ xs)

def nameJ : Name → Json
  | .anonymous => tag "anonymous"
  | .str p s => tag "str" #[nameJ p, toJson s]
  | .num p n => tag "num" #[nameJ p, toJson n]

def levelJ : Level → Json
  | .zero => tag "zero"
  | .succ l => tag "succ" #[levelJ l]
  | .max a b => tag "max" #[levelJ a, levelJ b]
  | .imax a b => tag "imax" #[levelJ a, levelJ b]
  | .param n => tag "param" #[nameJ n]
  | .mvar n => tag "mvar" #[nameJ n.name]

def subJ (s : Substring.Raw) : Json :=
  tag "substring" #[toJson s.str, toJson s.startPos.byteIdx, toJson s.stopPos.byteIdx]

def sourceJ : SourceInfo → Json
  | .none => tag "none"
  | .original leading pos trailing endPos =>
    tag "original" #[subJ leading, toJson pos.byteIdx, subJ trailing, toJson endPos.byteIdx]
  | .synthetic pos endPos canonical =>
    tag "synthetic" #[toJson pos.byteIdx, toJson endPos.byteIdx, toJson canonical]

def preJ : Syntax.Preresolved → Json
  | .namespace n => tag "namespace" #[nameJ n]
  | .decl n fs => tag "decl" #[nameJ n, toJson fs]

partial def syntaxJ : Syntax → Json
  | .missing => tag "missing"
  | .node i k a => tag "node" #[sourceJ i, nameJ k, .arr (a.map syntaxJ)]
  | .atom i v => tag "atom" #[sourceJ i, toJson v]
  | .ident i r n p => tag "ident" #[sourceJ i, subJ r, nameJ n, .arr (p.toArray.map preJ)]

def dataJ : DataValue → Json
  | .ofString v => tag "ofString" #[toJson v]
  | .ofBool v => tag "ofBool" #[toJson v]
  | .ofName v => tag "ofName" #[nameJ v]
  | .ofNat v => tag "ofNat" #[toJson v]
  | .ofInt v => tag "ofInt" #[toJson v]
  | .ofSyntax v => tag "ofSyntax" #[syntaxJ v]

def metadataJ (d : MData) : Json :=
  .arr (d.entries.toArray.map fun (n, v) => .arr #[nameJ n, dataJ v])

def binderJ : BinderInfo → Json
  | .default => toJson "default"
  | .implicit => toJson "implicit"
  | .strictImplicit => toJson "strictImplicit"
  | .instImplicit => toJson "instImplicit"

structure Dag where
  seen : ExprStructMap Nat := {}
  nodes : Array Json := #[]
  metadataNodes : Nat := 0
  deriving Inhabited

partial def emit (e : Expr) : StateM Dag Nat := do
  if let some n := (← get).seen.get? ⟨e⟩ then return n
  let node ← match e with
    | .bvar i => pure <| tag "bvar" #[toJson i]
    | .fvar i => pure <| tag "fvar" #[nameJ i.name]
    | .mvar i => pure <| tag "mvar" #[nameJ i.name]
    | .sort l => pure <| tag "sort" #[levelJ l]
    | .const n ls => pure <| tag "const" #[nameJ n, .arr (ls.toArray.map levelJ)]
    | .app f a => do pure <| tag "app" #[toJson (← emit f), toJson (← emit a)]
    | .lam n t b i => do pure <| tag "lam" #[nameJ n, toJson (← emit t), toJson (← emit b), binderJ i]
    | .forallE n t b i => do pure <| tag "forallE" #[nameJ n, toJson (← emit t), toJson (← emit b), binderJ i]
    | .letE n t v b nd => do pure <| tag "letE" #[nameJ n, toJson (← emit t), toJson (← emit v), toJson (← emit b), toJson nd]
    | .lit (.natVal n) => pure <| tag "natVal" #[toJson n]
    | .lit (.strVal s) => pure <| tag "strVal" #[toJson s]
    | .mdata d b => do
      modify fun s => { s with metadataNodes := s.metadataNodes + 1 }
      pure <| tag "mdata" #[metadataJ d, toJson (← emit b)]
    | .proj n i b => do pure <| tag "proj" #[nameJ n, toJson i, toJson (← emit b)]
  let s ← get
  let id := s.nodes.size
  set { s with seen := s.seen.insert ⟨e⟩ id, nodes := s.nodes.push node }
  return id

def kind (c : ConstantInfo) : String :=
  match c with
  | .axiomInfo _ => "axiom"
  | .defnInfo _ => "definition"
  | .thmInfo _ => "theorem"
  | .opaqueInfo _ => "opaque"
  | .quotInfo _ => "quotient"
  | .inductInfo _ => "inductive"
  | .ctorInfo _ => "constructor"
  | .recInfo _ => "recursor"

def firstOwner (env : Environment) (n : Name) : Json :=
  match env.getModuleIdxFor? n with
  | none => .null
  | some i => toJson env.header.modules[i.toNat]!.module.toString

def checkExpr (env : Environment) (e : Expr) : CommandElabM Expr := do
  if e.hasFVar || e.hasMVar || e.hasLooseBVars then
    throwError "Nonclosed expression in native export"
  match Kernel.check env {} e with
  | .ok t => return t
  | .error ex => throwError (ex.toMessageData {})

def checkValue (env : Environment) (value expected : Expr) : CommandElabM Unit := do
  let inferred ← checkExpr env value
  match Kernel.isDefEq env {} inferred expected with
  | .ok true => pure ()
  | .ok false => throwError "Kernel-inferred value type differs from full expected type"
  | .error ex => throwError (ex.toMessageData {})

def ownRoot := "/Users/zhouhuanjian/ASTIS-GC/.astis/semantic-neutral-20261114/weighted_mgf_native_8c2d"

def modules : Array String := #[
  "AutoSamplingTheory.TechnicalLemmas.Probability.MatrixBernsteinExponential",
  "AutoSamplingTheory.TechnicalLemmas.Probability.RealMatrixPositiveIntegral",
  "AutoSamplingTheory.TechnicalLemmas.Probability.MatrixBernsteinMgf",
  "AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumSourceRowLaw",
  "AutoSamplingTheory.TechnicalLemmas.Probability.StdGaussianMoment",
  "AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumTruncatedRowMoment",
  "AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumSourceMatrixMean",
  "AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumGridAlias",
  "AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumCosineGram",
  "AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumSourceMatrixRadius",
  "AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumSourceRowIndependence",
  "AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumSourceMatrixStructure",
  "Tests.GaussianComplexityBernsteinWeightedMgf",
  "NativeLiteralApplications"]

def atJ (a : Array Json) (i : Nat) : Except String Json :=
  match a[i]? with
  | some j => .ok j
  | none => .error s!"Missing JSON argument {i}"

def payload (j : Json) : Except String (String × Array Json) := do
  let a ← j.getArr?
  let k ← (← atJ a 0).getStr?
  return (k, a.extract 1 a.size)

partial def nameD (j : Json) : Except String Name := do
  let (k, a) ← payload j
  match k with
  | "anonymous" => return .anonymous
  | "str" => return .str (← nameD (← atJ a 0)) (← (← atJ a 1).getStr?)
  | "num" => return .num (← nameD (← atJ a 0)) (← (← atJ a 1).getNat?)
  | _ => throw s!"Unknown name constructor {k}"

partial def levelD (j : Json) : Except String Level := do
  let (k, a) ← payload j
  match k with
  | "zero" => return .zero
  | "succ" => return .succ (← levelD (← atJ a 0))
  | "max" => return .max (← levelD (← atJ a 0)) (← levelD (← atJ a 1))
  | "imax" => return .imax (← levelD (← atJ a 0)) (← levelD (← atJ a 1))
  | "param" => return .param (← nameD (← atJ a 0))
  | "mvar" => return .mvar ⟨← nameD (← atJ a 0)⟩
  | _ => throw s!"Unknown level constructor {k}"

def subD (j : Json) : Except String Substring.Raw := do
  let (k, a) ← payload j
  unless k == "substring" do throw "Expected substring"
  return ⟨← (← atJ a 0).getStr?, ⟨← (← atJ a 1).getNat?⟩, ⟨← (← atJ a 2).getNat?⟩⟩

def sourceD (j : Json) : Except String SourceInfo := do
  let (k, a) ← payload j
  match k with
  | "none" => return .none
  | "original" => return .original (← subD (← atJ a 0)) ⟨← (← atJ a 1).getNat?⟩ (← subD (← atJ a 2)) ⟨← (← atJ a 3).getNat?⟩
  | "synthetic" => return .synthetic ⟨← (← atJ a 0).getNat?⟩ ⟨← (← atJ a 1).getNat?⟩ (← (← atJ a 2).getBool?)
  | _ => throw s!"Unknown source-info constructor {k}"

def preD (j : Json) : Except String Syntax.Preresolved := do
  let (k, a) ← payload j
  match k with
  | "namespace" => return .namespace (← nameD (← atJ a 0))
  | "decl" => return .decl (← nameD (← atJ a 0)) (← (← (← atJ a 1).getArr?).toList.mapM Json.getStr?)
  | _ => throw s!"Unknown preresolved constructor {k}"

partial def syntaxD (j : Json) : Except String Syntax := do
  let (k, a) ← payload j
  match k with
  | "missing" => return .missing
  | "node" => return .node (← sourceD (← atJ a 0)) (← nameD (← atJ a 1)) (← (← (← atJ a 2).getArr?).mapM syntaxD)
  | "atom" => return .atom (← sourceD (← atJ a 0)) (← (← atJ a 1).getStr?)
  | "ident" => return .ident (← sourceD (← atJ a 0)) (← subD (← atJ a 1)) (← nameD (← atJ a 2)) (← (← (← atJ a 3).getArr?).toList.mapM preD)
  | _ => throw s!"Unknown syntax constructor {k}"

def dataD (j : Json) : Except String DataValue := do
  let (k, a) ← payload j
  match k with
  | "ofString" => return .ofString (← (← atJ a 0).getStr?)
  | "ofBool" => return .ofBool (← (← atJ a 0).getBool?)
  | "ofName" => return .ofName (← nameD (← atJ a 0))
  | "ofNat" => return .ofNat (← (← atJ a 0).getNat?)
  | "ofInt" => return .ofInt (← (← atJ a 0).getInt?)
  | "ofSyntax" => return .ofSyntax (← syntaxD (← atJ a 0))
  | _ => throw s!"Unknown metadata-value constructor {k}"

def metadataD (j : Json) : Except String MData := do
  let entries ← (← j.getArr?).toList.mapM fun entry => do
    let a ← entry.getArr?
    return (← nameD (← atJ a 0), ← dataD (← atJ a 1))
  return ⟨entries⟩

def binderD (j : Json) : Except String BinderInfo := do
  match ← j.getStr? with
  | "default" => return .default
  | "implicit" => return .implicit
  | "strictImplicit" => return .strictImplicit
  | "instImplicit" => return .instImplicit
  | x => throw s!"Unknown binder constructor {x}"

def exprD (prev : Array Expr) (j : Json) : Except String Expr := do
  let (k, a) ← payload j
  let child (i : Nat) : Except String Expr := do
    let n ← (← atJ a i).getNat?
    match prev[n]? with
    | some e => return e
    | none => throw s!"DAG child {n} is not earlier than its parent"
  match k with
  | "bvar" => return .bvar (← (← atJ a 0).getNat?)
  | "fvar" => return .fvar ⟨← nameD (← atJ a 0)⟩
  | "mvar" => return .mvar ⟨← nameD (← atJ a 0)⟩
  | "sort" => return .sort (← levelD (← atJ a 0))
  | "const" => return .const (← nameD (← atJ a 0)) (← (← (← atJ a 1).getArr?).toList.mapM levelD)
  | "app" => return .app (← child 0) (← child 1)
  | "lam" => return .lam (← nameD (← atJ a 0)) (← child 1) (← child 2) (← binderD (← atJ a 3))
  | "forallE" => return .forallE (← nameD (← atJ a 0)) (← child 1) (← child 2) (← binderD (← atJ a 3))
  | "letE" => return .letE (← nameD (← atJ a 0)) (← child 1) (← child 2) (← child 3) (← (← atJ a 4).getBool?)
  | "natVal" => return .lit (.natVal (← (← atJ a 0).getNat?))
  | "strVal" => return .lit (.strVal (← (← atJ a 0).getStr?))
  | "mdata" => return .mdata (← metadataD (← atJ a 0)) (← child 1)
  | "proj" => return .proj (← nameD (← atJ a 0)) (← (← atJ a 1).getNat?) (← child 2)
  | _ => throw s!"Unknown expression constructor {k}"

def decodeDag (nodes : Array Json) : Except String (Array Expr) := do
  let mut result := #[]
  for node in nodes do result := result.push (← exprD result node)
  return result

def audit : CommandElabM Unit := do
  let env := (← getEnv).setExporting false
  let dir : System.FilePath := ownRoot ++ "/native-raw-roundtrip"
  liftIO <| IO.FS.createDirAll dir
  let mut summaries : Array Json := #[]
  let mut allNames : NameSet := {}
  for mod in modules do
    let file : System.FilePath := ownRoot ++ "/native-output/" ++ mod.replace "." "/" ++ ".olean"
    let (data, _) ← liftIO <| readModuleData file
    unless data.constNames == data.constants.map (·.name) do
      throwError "Raw ModuleData constant name/value arrays disagree for {mod}"
    let mut dag : Dag := {}
    let mut records : Array Json := #[]
    let mut values := 0
    for c in data.constants do
      allNames := allNames.insert c.name
      let _ ← checkExpr env c.type
      let (typeId, ds) := (emit c.type).run dag
      dag := ds
      let mut valueId : Json := .null
      if let some v := c.value? (allowOpaque := true) then
        checkValue env v c.type
        let (id, ds) := (emit v).run dag
        dag := ds
        valueId := toJson id
        values := values + 1
      let axioms ← collectAxioms c.name
      for ax in axioms do
        unless ax == ``propext || ax == ``Classical.choice || ax == ``Quot.sound do
          throwError "Nonstandard axiom {ax} reachable from {c.name}"
      let direct := c.type.getUsedConstants ++ (c.value? true |>.map Expr.getUsedConstants |>.getD #[])
      records := records.push <| Json.mkObj [
        ("name", toJson c.name.toString), ("raw_name", nameJ c.name),
        ("emitter", toJson mod), ("first_owner", firstOwner env c.name),
        ("kind", toJson (kind c)), ("unsafe", toJson c.isUnsafe),
        ("level_params", .arr (c.levelParams.toArray.map nameJ)),
        ("type_root", toJson typeId), ("value_root", valueId),
        ("kernel_type_checked", toJson true), ("kernel_value_checked", toJson valueId.isNull.not),
        ("axioms", toJson (axioms.map Name.toString)),
        ("direct_dependencies", .arr (direct.map fun n => Json.mkObj [
          ("name", toJson n.toString), ("first_owner", firstOwner env n)]))]
    let raw := Json.mkObj [
      ("schema", toJson "lossless-raw-module-expression-dag-v1"),
      ("module", toJson mod), ("isModule", toJson data.isModule),
      ("constNames", toJson (data.constNames.map Name.toString)),
      ("extraConstNames", toJson (data.extraConstNames.map Name.toString)),
      ("imports", toJson (data.imports.map fun i => i.module.toString)),
      ("declarations", .arr records), ("expression_nodes", .arr dag.nodes),
      ("metadata_nodes", toJson dag.metadataNodes)]
    liftIO <| IO.FS.writeFile (dir / (mod ++ ".json")) raw.compress
    let parsed ← match Json.parse (← liftIO <| IO.FS.readFile (dir / (mod ++ ".json"))) with
      | .ok j => pure j
      | .error e => throwError "JSON parse failed: {e}"
    let decoded ← match do decodeDag (← (← parsed.getObjVal? "expression_nodes").getArr?) with
      | .ok es => pure es
      | .error e => throwError "DAG decode failed: {e}"
    for c in data.constants, record in records do
      let typeId ← match (record.getObjVal? "type_root").bind Json.getNat? with
        | .ok n => pure n
        | .error e => throwError "Type root decode failed: {e}"
      unless Expr.equal decoded[typeId]! c.type do
        throwError "Lossy type DAG round trip for {c.name}"
      let _ ← checkExpr env decoded[typeId]!
      if let some value := c.value? true then
        let valueId ← match (record.getObjVal? "value_root").bind Json.getNat? with
          | .ok n => pure n
          | .error e => throwError "Value root decode failed: {e}"
        unless Expr.equal decoded[valueId]! value do
          throwError "Lossy value DAG round trip for {c.name}"
        checkValue env decoded[valueId]! decoded[typeId]!
    summaries := summaries.push <| Json.mkObj [
      ("module", toJson mod), ("raw_declarations", toJson data.constants.size),
      ("extra_names", toJson data.extraConstNames.size), ("checked_values", toJson values),
      ("expression_nodes", toJson dag.nodes.size), ("metadata_nodes", toJson dag.metadataNodes)]
    logInfo "Raw native module checked: {mod}; declarations {data.constants.size}; values {values}"
  let p := `AutoSamplingTheory.TechnicalLemmas.Probability.MatrixBernsteinMgf.centered_bounded_matrix_mgf
  let found := allNames.toArray.filter fun n => n.toString.endsWith ".actual_source_weighted_normalized_single_summand_mgf"
  unless found.size == 1 do throwError "Expected exactly one raw actual private T"
  let t := found[0]!
  let mut targetChecks : Array Json := #[]
  for (actual, literal) in #[(p, `NativeLiteralApplications.literal_P), (t, `NativeLiteralApplications.literal_T)] do
    let some a := env.find? actual | throwError "Missing actual target {actual}"
    let some l := env.find? literal | throwError "Missing literal target {literal}"
    checkValue env (a.value! true) l.type
    targetChecks := targetChecks.push <| Json.mkObj [
      ("actual", toJson actual.toString), ("literal_expected", toJson literal.toString),
      ("full_actual_proof_value_kernel_checked_against_literal", toJson true)]
  for n in #[`NativeLiteralApplications.literal_T_q0, `NativeLiteralApplications.literal_T_q0_d2] do
    let some c := env.find? n | throwError "Missing application {n}"
    checkValue env (c.value! true) c.type
    targetChecks := targetChecks.push <| Json.mkObj [
      ("application", toJson n.toString), ("full_value_kernel_checked", toJson true)]
  let summary := Json.mkObj [
    ("pinned_candidate", toJson "4869db55d340cee39f0ba4d49fb0a7a4309ba2d6"),
    ("modules", .arr summaries), ("literal_target_checks", .arr targetChecks),
    ("JSON_DAG_full_structural_roundtrip_and_decoded_value_kernel_checks", toJson true),
    ("only_standard_axioms", toJson true)]
  liftIO <| IO.FS.writeFile (dir / "native-kernel-summary.json") summary.pretty

run_cmd audit

end NativeAudit8c2d

def main : IO Unit := pure ()
