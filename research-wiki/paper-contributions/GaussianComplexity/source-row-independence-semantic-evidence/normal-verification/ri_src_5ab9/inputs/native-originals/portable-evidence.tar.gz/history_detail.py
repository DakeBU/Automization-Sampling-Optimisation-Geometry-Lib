import json,re,tarfile
from run import ROOT,sha
I=ROOT/'inputs';m=json.loads((ROOT/'input-manifest.json').read_text());E=m['E'];items={}
with tarfile.open(I/E/'preproof-source-types-topology-local-build.original-files.tar.gz','r:gz') as tar:
    for z in tar.getmembers():
        if z.isfile():items[z.name]=tar.extractfile(z).read()
out=[]
for path,b in items.items():
    if not path.endswith('.receipt.json'):continue
    if not any(x in path for x in ['product-and-map-API','preliminary-literal-Prop-formation','literal-Prop-formation-v2','explicit-entry-carrier-Prop-formation-v3','final-literal-Prop-formation-v4']):continue
    v=json.loads(b);lp=path[:-len('.receipt.json')]+'.log';log=items[lp];assert sha(log)==v['log_sha256']
    errors=[x for x in log.decode().splitlines() if re.search(r': error(?:\(|:)',x)]
    if 'product-and-map-API' in path:
        assert v['exit_code']==1 and len(errors)==3
        assert all('Unknown identifier `'+n+'`' in log.decode() for n in ['infinitePi_map_curry','infinitePi_map_curry_symm','infinitePi_eq_pi'])
        cls='API_BLOCKED';reason='Exactly three unqualified names; production qualified Measure namespace APIs pass own native compile.'
    elif 'formation-v3' in path or 'formation-v4' in path:
        assert v['exit_code']==0 and not errors;cls='NONE';reason='Literal proposition formation only; no theorem proof credited.'
    else:
        assert v['exit_code']==1 and len(errors)==1;cls='IMPLEMENTATION_FAILED';reason='Preseal Matrix alias instance / letI auxiliary typing, before theorem proof.'
    d=ROOT/'bounded-original-streams';d.mkdir(exist_ok=True)
    for p,z in [(path,b),(lp,log)]: (d/p.rsplit('/',1)[-1]).write_bytes(z)
    out.append({'receipt_origin':path,'receipt_sha256':sha(b),'exit_code':v['exit_code'],'log_origin':lp,'log_sha256':sha(log),'errors':errors,'failure_class':cls,'reason':reason})
assert len(out)==5
(ROOT/'historical-failure-detail.json').write_text(json.dumps({'originals':out,'mathematical_refutation_claimed':False},indent=2)+'\n')
print(json.dumps({'original_formation_and_API_receipts_checked':len(out)}))
