import json, os, pathlib, time
from verify import D,R,C,G,P,T,E,put,js,run,sha

cfg=json.loads((D/'native-environment.json').read_text())
src=D/'fresh-src'; out=D/'fresh-olean'
assert not src.exists() and not out.exists(), 'Fresh paths must not preexist'
src.mkdir(); out.mkdir()
env=os.environ.copy()
env['LEAN_PATH']=os.pathsep.join([str(out)]+[p['library'] for p in cfg['packages']])
env.pop('LEAN_SYSROOT', None)
assert str(R/'.lake/build/lib/lean') not in env['LEAN_PATH']
js('fresh-build-plan.json', {'candidate':C,'source_root':str(src),'olean_root':str(out),
    'source_paths_preexisted':False,'olean_path_preexisted':False,'LEAN_PATH':env['LEAN_PATH'],
    'project_cache_excluded':str(R/'.lake/build/lib/lean'),'order':[G,P,T]})
lean=cfg['lean_binary']
run('lean_help',[lean,'--help'])
artifacts=[]
for ix,rel in enumerate([G,P,T]):
    b=(D/'inputs'/rel).read_bytes()
    f=src/rel; f.parent.mkdir(parents=True,exist_ok=True); f.write_bytes(b)
    target=out/pathlib.Path(rel).with_suffix('.olean'); target.parent.mkdir(parents=True,exist_ok=True)
    assert not target.exists()
    start=time.time()
    result=run('fresh_'+str(ix)+'_'+f.stem,[lean,'--root='+str(src),'-o',str(target),'-i',str(target.with_suffix('.ilean')),str(f)],cwd=src,env=env,timeout=1200)
    assert target.exists() and target.stat().st_mtime >= start
    deps=run('fresh_'+str(ix)+'_'+f.stem+'_resolved_deps',[lean,'--deps',str(f)],cwd=src,env=env).stdout.decode().splitlines()
    if rel==P:
        assert str(out/pathlib.Path(G).with_suffix('.olean')) in deps, deps
    if rel==T:
        assert str(out/pathlib.Path(P).with_suffix('.olean')) in deps, deps
    assert not any(str(R/'.lake/build/lib/lean') in p for p in deps)
    artifacts.append({'source':rel,'source_bytes':len(b),'source_sha256':sha(b),
        'olean':str(target.relative_to(D)),'olean_sha256':sha(target.read_bytes()),
        'olean_mtime':target.stat().st_mtime,'start_unix':start,'preexisting':False,
        'resolved_deps':deps,'exit_code':result.returncode})
    js('fresh-build-results.json',artifacts)
    print(f'FRESH_PASS {rel}: {len(b)}B {sha(b)}; output {sha(target.read_bytes())}',flush=True)
