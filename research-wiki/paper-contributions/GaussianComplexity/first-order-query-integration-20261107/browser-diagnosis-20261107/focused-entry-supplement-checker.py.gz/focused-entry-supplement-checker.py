"""Bounded real-browser acceptance of the actual first-order observation reconstruction reader."""
import functools
import datetime
import hashlib
import http.server
import json
from pathlib import Path
import re
import subprocess
import sys
import threading
from urllib.parse import quote, urljoin, urlsplit

from playwright.sync_api import sync_playwright

ROOT = Path.cwd()
SITE = ROOT / '_site'
OUT = ROOT / '.astis/huanjian-gc-first-order-query-integration-20261107/browser' / ('live-' + datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ'))
OUT.mkdir(parents=True, exist_ok=True)
sys.path.insert(0, str(ROOT / 'website/scripts'))
sys.path.insert(0, str(ROOT / 'tools'))
import inline_lean

PREFIX = 'AutoSamplingTheory.ExampleCases.GaussianComplexity.'
TARGETS = {'actual': PREFIX + 'FirstOrderQuery.actual_first_order_query'}
rows = {r['declaration']: r for r in json.loads((SITE / 'data/declaration-exposition.json').read_text())}
declarations = inline_lean.declarations()
report = {'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
          'mode': 'HTTP with installed headless Chrome, isolated temporary profile; external requests blocked',
          'pages': [], 'graphs': [], 'errors': [], 'screenshots': []}


class Quiet(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *_):
        pass


server = http.server.ThreadingHTTPServer(('127.0.0.1', 0), functools.partial(Quiet, directory=str(SITE)))
threading.Thread(target=server.serve_forever, daemon=True).start()
base = f'http://127.0.0.1:{server.server_port}/'
expected_commit = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
metadata_path = SITE / 'data/build-metadata.json'
metadata = json.loads(metadata_path.read_text())
assert metadata['git']['commit'] == expected_commit
actual_gate = json.loads((ROOT / '.astis/site-lean-gate.json').read_text())
assert actual_gate['passed'] and metadata['source_digest'] == actual_gate['source_digest']
assert metadata['gate']['passed'] and metadata['gate']['current']
report['mode'] = 'Actual local final site over HTTP with isolated installed Chrome; external hosts blocked'
report['site_metadata'] = metadata
report['site_metadata_sha256'] = hashlib.sha256(metadata_path.read_bytes()).hexdigest()
report['actual_compiled_gate_commit'] = actual_gate['commit']
report['actual_compiled_source_digest'] = actual_gate['source_digest']
report['compilation_boundary'] = 'Actual canonical gate at the separately named immutable commit; exact current Lean source digest matches. Current metadata-only HEAD is not relabeled as an additional build.'
report['visible_source_index_clicks'] = []
report['external_GitHub_HTML_checked'] = False
report['external_source_route'] = 'Historical GitHub HTML504 host route remains frozen; Own-site complete module/downloads are checked against actual source and an immutable Git object; external GitHub URL syntax is separately conditional and external HTML is not checked.'

def screenshot(page, name):
    path = OUT / (name + '.png')
    page.screenshot(path=str(path))
    report['screenshots'].append({'file': path.name, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()})


def math_ready(page):
    page.wait_for_function('Boolean(window.MathJax?.startup?.promise)', timeout=30000)
    page.evaluate('() => MathJax.startup.promise')
    assert page.locator('mjx-container').count() > 0
    assert page.locator('mjx-merror, [data-mjx-error]').count() == 0


def no_page_overflow(page):
    assert not page.evaluate('document.documentElement.scrollWidth > innerWidth + 1'), page.url



report['mode']='SUPPLEMENT ONLY: actual readable focused graph deep-links; main22-image acceptance remains separate'
try:
    with sync_playwright() as p:
        browser=p.chromium.launch(headless=True,executable_path='/Applications/Google Chrome.app/Contents/MacOS/Google Chrome')
        report['browser_version']=browser.version
        context=browser.new_context();context.route(re.compile(r'https?://(?!127\.0\.0\.1:)'),lambda route:route.abort());page=context.new_page();page.on('pageerror',lambda e:report['errors'].append(str(e)))
        for width in (1440,390):
            page.set_viewport_size({'width':width,'height':1000 if width>400 else 844})
            for view,ident,query in [('lean','decl:'+TARGETS['actual'],TARGETS['actual']),('functor','transport:gaussian-quadratic-oracle-factorization','Quadratic observations factor')]:
                route='lean-foundations.html?view='+view+'&focus='+quote(ident,safe='')+'&q='+quote(query,safe='')
                assert page.goto(base+route,wait_until='domcontentloaded').status==200
                page.wait_for_selector('.ulg-canvas[data-local="true"]')
                selected=page.locator(f'.ulg-node.selected[data-id="{ident}"]');selected.wait_for()
                page.wait_for_function("document.querySelector('.ulg-canvas>small').textContent.includes('Focused result at readable scale')")
                math_ready(page);page.locator('[data-graph-canvas]').scroll_into_view_if_needed()
                node_box=selected.locator('rect').bounding_box();canvas_box=page.locator('[data-graph-canvas]').bounding_box()
                assert node_box['width']>=160 and node_box['x']>=canvas_box['x'] and node_box['x']+node_box['width']<=canvas_box['x']+canvas_box['width']+1
                selected.click();assert page.locator('[data-graph-detail]').locator('h2').text_content().strip()
                no_page_overflow(page);page.locator('[data-graph-canvas]').scroll_into_view_if_needed();screenshot(page,f'{view}-{width}-readable-focused-entry')
                report['graphs'].append({'view':view,'target':ident,'width':width,'route':route,'actual_node_width_px':node_box['width'],'node_box':node_box,'canvas_box':canvas_box,'readable_deep_link_caption':page.locator('.ulg-canvas>small').text_content(),'actual_selected_node_click':True,'selected_detail_heading':page.locator('[data-graph-detail] h2').text_content(),'boundary':'Readable focused entry only. Explicit Fit remains all-nodes overview; no claim all labels simultaneously readable or touch gesture tested.'})
        assert not report['errors'];browser.close();report['status']='focused-supplement-passed'
finally:
    server.shutdown();server.server_close();(OUT/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'status':report.get('status'),'screenshots':len(report['screenshots']),'graphs':len(report['graphs']),'report':str(OUT/'report.json')}))
