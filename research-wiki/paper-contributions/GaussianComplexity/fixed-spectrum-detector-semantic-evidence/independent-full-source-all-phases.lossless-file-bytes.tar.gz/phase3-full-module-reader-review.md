# Phase 3 independent source, complete-code and reader-content review

Reviewer: `/root/detector_fresh_source`, distinct from the formalizer and blind decoder. Candidate commit: `65776f88e92b9680e6afe0d4c20b7390e4521241`; parent: `8c88749c51c87ce54c22e7910b366c0f9f3fba6d`.

**Finding: accept the declared auxiliary's source semantics, complete source-code argument, and supplied reader content, with the explicit remaining boundary below.** No substantive source/code mismatch was found. This is an independent source review proposal, not a registry transition, native/kernel check, rendered-site/browser check, or full-source-theorem acceptance.

## Immutable inputs and two different packet digests

The public P module and complete Test were read from `git show COMMIT:path`, with raw SHA256 respectively `98d055da8ca5a10fe56874b19a58fb523511b9fc7c5ae13e20225e18340ed75a` and `f7732afeb3cac55734dc2b05fd68e72f353d9bae6f2be2bbfa0bc499788cbe3d`. Their working-tree bytes were identical to those commit bytes. The source map, lesson, publication and schema tool were also fixed and compared in this way.

The first packet byte check stopped before displaying packet content because the parent's initial raw-SHA description did not match. The raw packet SHA is `1d9d7688662ec3129522431a5f974a7c7b11408d3adc7eed9de953939e401555`, both in the candidate commit and working tree. The parent then clarified that `9525ebc96a14c49ea7694c6997103ac371ae5942b83356718ccaf05ce5aa751b` is its **canonical** `packet_sha256`. I independently reproduced that digest by removing `packet_sha256` and hashing UTF-8 JSON with sorted keys, compact separators and `ensure_ascii=False`, exactly as the schema's `sha256_json` specifies. Neither packet nor any canonical file was changed. This was a labeling diagnosis, not a candidate mutation.

Phase 1 and Phase 2 remain byte-for-byte frozen. Their source-first and selective findings are not overwritten. In particular the raw-source proof uses `n=2q+1`; the all-natural-n statement remains an explicit auxiliary generalization. The final five-field proposal compares the exact **declared auxiliary contract** with Lean/reconstruction; its `explicit-elaboration` quantifier relation does not recast the raw paper as a printed all-n theorem. That raw-source generalization remains an informational delta.

## Complete public module P

The module has one public theorem and only local proof ingredients. Its signature is the exact previously reviewed type. It exposes the actual midpoint grid, actual hard-family precision and scalar affine normalization as local definitions, rather than assuming any of their desired identities. There is no project-owned Prop alias, free diagonalization, event/moment/probability/cost certificate, synthetic statistic, determinant-one condition, axiom, sorry, admit, or fake theorem closure in the complete text inspected.

The proof's algebra is correct:

1. `Unitary.conjStarAlgAut` supplies `Φ(M)=OMOᵀ`. Its actual Mathlib definition is a star-algebra automorphism induced by a unitary element, and the real matrix star reduces to transpose. Thus preservation of I, scalar action and addition is genuine, and both determinant signs are admitted.
2. `hκ` produces `κ−1≠0` internally. Entrywise diagonal calculation proves `(κ−1)⁻¹ • (2Λ−(κ+1)I)=diag(cos θ_i)`. Off-diagonal entries vanish; diagonal entries are exactly the affine Eq. 11 scalar calculation. `hA` and `hB` transport it by the same Φ. `hd` retains the source domain even though this algebra does not use it.
3. Actual matrix polynomial evaluation commutes with Φ and `Matrix.diagonalAlgHom`; tuple evaluation is componentwise. The inspected Mathlib first-kind T has `T₀=1`, `T₁=X` and the usual recurrence. Its integer-index `T_real_cos` applies to the integer cast of natural n, yielding the intended `cos(nθ_i)`. No entrywise evaluation of a general matrix is substituted.
4. The final rewrite combines the genuine normalized-matrix equality, polynomial transport, diagonal evaluation and the actual same-O conjugation. The result holds for all natural n, including zero, without n<d or oddness. Those latter source ranges belong to distinct moment/Krylov uses.

This is a substantive direct algebraic implementation of the selected source bridge, not a wrapper accepting the desired conclusion as a premise. It asserts no Gaussian law or probability bound.

## Complete private Test and actual P → Test use

The entire 123-line Test was read, not merely the selected signature. Its only theorem is `private`, and it imports the actual P module. At Test lines 63–65, `hT` directly invokes

`AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumDetector.actual_chebyshev_matrix_cosine hd hκ O n`.

The actual θ/A/B definitions agree with P. `hquad` rewrites by this hT at Test line 98; `hstat` then uses hquad and norm preservation; the right event-mass branch finally rewrites the preimage with hstat. Therefore the public output is actually consumed in a reachable proof of the exact private root. This finding is based on the code, not an import edge or a prose claim. It is source-code call verification, not compiler/kernel dependency extraction.

The conjunction's branches have distinct proof ingredients:

- **Borel branch:** hSc treats the fixed matrix `T=T_n(B)` as a continuous linear map. `Matrix.inner_toEuclideanCLM T x x` supplies a typed pointwise equality between the real inner product and the exact coordinate quadratic form. Continuity of the inner product and norm square gives continuity of S, and `measurableSet_lt` gives its strict positive set. This branch does not use hT, hquad or the cosine identity. R's measurability is separately derived from the actual continuous linear matrix map.
- **Right event-mass branch:** `hO` obtains `OᵀO=I` from the full orthogonal group. `hundo` cancels the actual matvec composition. `Unitary.map_mem` through the star-algebra map to Euclidean continuous linear operators supplies genuine norm preservation. With hT, the bilinear transpose identity and diagonal matvec calculation give `hquad` for every z. Combining the sign and norm correction yields `S(Rz)=(−1)^n Σ_i cos(nθ_i)z_i²−2τ‖z‖²`. `Measure.map_apply hR hEvent` consumes the independently proved measurable R and Borel event; set extensionality and hstat prove the exact strict preimage identity.

The scalar reciprocal in B and the matrix inverse Λ⁻¹ in μ remain different operations. μ is the actual Mathlib `multivariateGaussian 0 Λ⁻¹`, a standard-Gaussian pushforward by the square-root linear operator. The inspected definition documents its non-PSD fallback to a Dirac measure; this is not used to manufacture the desired result. In the source domain the literal diagonal eigenvalues are strictly >1, so Λ⁻¹ is positive definite by ordinary diagonal linear algebra. The inspected covariance theorem requires PosSemidef, consistently with that interpretation. The private proof itself uses no covariance or moment theorem: its event transport is valid for the literal measure, and indeed the same algebra would work for an arbitrary measure.

The `Measure.map` definition's zero fallback for a non-AEMeasurable function is avoided by the actual hR. There is no hidden nonmeasurable-map simplification. The equality is in ENNReal masses with no toReal conversion or numerical probability claim.

Strictness and zero are exact: both sets use `0 < ...`; hstat holds at z=0, both statistics there are zero, and zero is excluded by strict positivity. There is no boundary-null assumption and no division by squared norm. Full O(d), natural n including zero, and arbitrary real τ are used throughout. The source specialization remains n=2q+1 and τ=τ_dq; negative τ is not given the source's nonnegative-threshold sign interpretation.

## Reader's six formulas and literal adjacent code

The lesson has one `progressive` unit. Its statement is the matrix identity; the displayed assumptions retain d≥2, κ≥2, the literal grid, full O(d), ordinary matrix evaluation, all-n/all-τ helper ranges and the source specialization. The publication marks the wording **faithful paraphrase**, not a verbatim source quotation. It declares only the auxiliary identity plus private literal event-transport component, and explicitly keeps π_A identification and Ex26 outside the claim.

Every one of the six `steps[i].lean` strings is a literal substring of the fixed actual P or Test. The exact source ranges are: step 1 P52–60; step 2 P61–79; step 3 P80–92; step 4 Test66–83; step 5 Test84–112; step 6 Test1–123. **Step 6 equals the entire Test byte-for-byte**, including imports, private signature, local definitions, actual hT call and proof through the final namespace. The packet's `current_lean_module` also equals the entire fixed P, and the packet lesson fields agree with the actual lesson fields.

The formulas and natural-language mathematical moves are accurate:

1. Conjugation is an algebra automorphism, with nonzero κ−1 derived from κ≥2.
2. Literal scalar/diagonal normalization is transported to the actual B; no caller certificate is assumed.
3. Polynomial evaluation through conjugation and diagonal maps gives the stated same-O cosine diagonal.
4. The exact quadratic form is continuous, so the strict event is Borel; this does not need the producer identity.
5. The exact rotated statistic transforms on every vector, including zero. The producer call appears in the complete Test folded at step 6; its hT is then used by the literal step-5 hquad code.
6. The actual pushforward is evaluated on the Borel event and its preimage replaced exactly. The text correctly distinguishes equality of event masses from any target-probability estimate or π_A law identification.

The supplied JSON attaches code to the corresponding mathematical step and puts complete Test at step 6. This review accepts that **content/data correspondence**. It does not verify a rendered frontend, an initially collapsed DOM state, line wrapping, desktop/mobile delivery, or the generated public-statement source fold: `lean_statement` in this JSON is explanatory prose, and any separately generated exact statement fold requires its own renderer/delivery check. No browser or renderer was inspected in this authorized phase. This is an explicit delivery boundary, not evidence of a mathematical mismatch in the supplied content.

## All 27 correspondence rows

All 27 rows were independently read. The claimed source-code blocks and all associated full-file hashes, start markers and block hashes match the actual source. The two type hashes are the literal declaration text before `:= by`, right-trimmed. P/C proof blocks are literal substrings ending at the next block boundary and retain their terminal LF; their `end_line` is a boundary line. Mathlib excerpt blocks are inclusive line spans joined with LF without a terminal LF. Initially trying one uniform line-span hashing convention produced mismatches; verifying the actual literal spans resolved every one, without changing any file or supplied hash.

The 16 P/Test rows correctly describe the two signatures, literal definitions and actual internal algebra/measurability/event steps. The 11 Mathlib rows point to real existing canonical definitions/theorems genuinely used in those arguments. Their complete relevant declaration/proof contexts were inspected, rather than crediting a source-paper author or a new ASTIS declaration for Mathlib substrate. No separate graph/topology verdict or prior review was opened or used. The table's `source_or_overlay_node` identifiers and embedded historical graph-status/hash strings were visible because they occur in the explicitly whitelisted table; their truth was not independently assessed and supplies no evidence for this review.

The table's selected paper anchors describe the matrix/event bridge. For the literal μ notation the more direct raw-source provenance is additionally §4.2 Lemma 4.5 and `S4.SS2.SSS0.Px3.p2.1`, read independently from the pinned paper. This extra locator refines provenance without extending the helper's conclusions to target-law or moment claims.

## Remaining boundary and authority

Accepted here: the explicitly generalized source-extracted public matrix identity; its complete mathematical source-code argument; the private Borel and literal rotated-pushforward strict-event equality with its real call; the supplied six-step exposition's formulas and exact code correspondence.

Not supplied or accepted: μ.map R = π_A / covariance-A⁻¹ law identification; normalized eigenvector-energy fractions as a separate theorem; Lemma 4.5 moment/variance proof; τ-smallness/asymptotic thresholds or concentration-valid absolute C; target pass probability; Krylov/Haar/adaptive-output law; algorithm/oracle/TV/query/cost adapters; either main lower bound; native/kernel/axiom acceptance; full-registry metadata admission; a V/API/STAB transition; serialized integration; generated browser delivery; purification or Exposition Seal; global/whole-Goal completion.

No mathematical source repair or new source assumption is proposed. The final five-field object is a proposal for subsequent authorized admission only. Its run hash binds this independent inspection and its input/exposure manifest; it is not a claim that any canonical state has already changed.
