# R18 successor reader checker DRAFT

No browser or server was started. This directory contains only the unexecuted successor runner, an additional regression helper, exact original geometry/passive-anchor helpers, the exact runner diff, and an assignment template with actual v2 preview/input hashes left null. ROOT must review this code and supply the exact actual assignment and launch window. The original 485-check packet remains FAIL and all original files/results/screenshots are preserved.

The successor runner is an additions-only copy of original runner SHA `e1fdbb3731486f240d10fb47683df2665656910cb8e407182a466d64006fc550`. Removing its three inserted blocks recovers the original runner text exactly: one helper import, one helper-hash assertion and one isolated regression try/except block after the retained `proof-expanded` layout check. No original assertion, check call, visibility/geometry predicate, threshold, source-anchor action, source/index/parent/graph/copy/download branch, receipt mechanism or file-byte constraint was removed or changed. The new block catches its own exception and records a failure while allowing the retained context/source/graph checks to continue. Geometry and natural-anchor helper bytes remain identical. The unused original `REPO` constant is retained.

The new helper selects only top-level inline MathJax roots directly owned by assumption list items, excluding recursive containers within assistive MML. It locates the measured matrix formula by its native MathML content beginning `A=Odiag(` and ending `O⊤`, rather than by a line number or nth-child source anchor. It records the actual parent content box and complete visible glyph boxes, audits each native MathML namespace/text and ancestor visibility/aria state, and checks the original 108.9% font relationship (including the independently measured 17.424 px mobile floor). It requires a real mobile local overflow, exercises the local scroll container to its right edge, identifies the final *visible CHTML* transpose glyph separately from assistive contents, and checks its real clipped bounds with the existing 1 CSS px horizontal and strict vertical limits. Every visible glyph must also remain vertically inside the actual clip. All assumption roots' native MathML must remain nonempty and available, with unchanged texts/counts across the scroll action.

The formula is centered using the existing GLYPH/geometry reading mechanics solely for this new formula reachability case. The added action then changes only the owning formula's local `scrollLeft`, as the original code already does for formula/source reachability. Source-anchor observation and navigation remain untouched; no source line receives a forced position. No stylesheet, font, animation, transform, viewport, formula, assistive subtree or source content is changed by the regression helper. Two actual screenshots per viewport are requested, before and after the local right-edge exercise; the original screenshots remain requested too. A new strict document containment check follows the added regression action.

Python AST syntax and both geometry JavaScript expression forms were checked without executing them. The runner/helper are not runtime-verified yet. In particular, the new target's actual visible-glyph boxes and assistive availability must be checked in the real successor; syntax and intended CSS cannot certify those properties.

Files and SHA256:

- Runner: `eb6c70e85d71b96cf4f659b7e18e255e36b13e161e8f635a20148273bc08e7d7`
- Inline regression helper: `881b189adbe8a561a2da2c77ca3a34e6663c0802eeba7e1dd9550a97e4a04d4e`
- Geometry: `cc7eb67308d24fd5dbf87345b9e48ac1140ff7879bb05a96e08bc01a13d9efd4`
- Natural anchor observer: `6b29bfff8201a6cb34503c0de8de5da1cf84b4285be104074f38254b51f6ec96`
- Exact runner diff: `253550b9826fa347ff6fc404a3bfb4cedaab0fe85e032bf86285603eae75ebfa`
- Unfilled assignment template: `c970f435170e695edf2615b6998f294b1ab2669ac21cb8c42cb42df60d716190`
