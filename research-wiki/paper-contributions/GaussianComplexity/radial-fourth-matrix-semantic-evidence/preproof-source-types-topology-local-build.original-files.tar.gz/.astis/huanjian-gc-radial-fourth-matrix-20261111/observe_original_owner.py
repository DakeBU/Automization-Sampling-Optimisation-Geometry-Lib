"""Read the formal remote ledger after the actual foreground fetch."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import subprocess
import sys

sys.dont_write_bytecode = True
sys.path.insert(0, 'tools')
import astis_advance as advance

observations = []
target = 'ASTIS-SA-20261110-SlcLsiWeightedRadialMGF'
for ref in ['origin/main', 'origin/codex/slc-lsi-weighted-radial-mgf-release']:
    commit = subprocess.check_output(['git', 'rev-parse', ref]).decode().strip()
    raw = subprocess.check_output(['git', 'show', f'{commit}:runs/substantive_advances.jsonl'])
    states = advance._replay_advances([json.loads(line) for line in raw.splitlines()])
    original = states[target]
    observations.append({
        'ref': ref, 'commit': commit,
        'ledger_sha256': hashlib.sha256(raw).hexdigest(),
        'original_owner_state': original['state'],
        'original_owner_id': original.get('worker_id', original.get('owner_id')),
        'active_stabilizing': [key for key, value in states.items() if value['state'] == 'STABILIZING'],
    })
record = {
    'checked_utc': datetime.now(timezone.utc).isoformat(),
    'actual_fetch': {'command': ['git', 'fetch', 'origin'], 'start_tool_chunk': '773d77',
                     'completed_tool_chunk': 'fad0d5', 'exit_code': 0},
    'refs': observations,
    'boundary': 'A merged PR or matching display name alone does not release the existing stabilization owner.',
}
path = Path(__file__).resolve().parent / 'latest-original-owner-after-row-moment-V.json'
with path.open('x') as out:
    out.write(json.dumps(record, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(record))
