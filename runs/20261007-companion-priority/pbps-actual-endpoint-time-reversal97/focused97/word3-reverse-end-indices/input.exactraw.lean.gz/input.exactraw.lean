import AutoSamplingTheory.ExampleCases.ProximalBPS.ActualPhaseReversalVolume
import Mathlib.Data.Fin.Rev
import Mathlib.Data.Fin.Tuple.Basic

namespace PBPSWordWork97
open MeasureTheory
open scoped Classical
noncomputable section
set_option autoImplicit false

/-- Cancellation of a finite word against its reverse under a common reversing map. -/
theorem reverse_fold_cancel {X : Type*} (C : X → X) (n : ℕ)
    (f : Fin n → X → X) (hf : ∀ i x, f i (C (f i x)) = C x) (x : X) :
    Fin.foldr n f (C (Fin.foldl n (fun z i => f i z) x)) = C x := by
  induction n generalizing x with
  | zero => simp
  | succ n ih =>
    rw [Fin.foldl_succ, Fin.foldr_succ]
    rw [ih (fun i => f i.succ) (fun i => hf i.succ)]
    exact hf 0 x

/-- Finite recursion is the corresponding left fold, without assuming an endpoint. -/
theorem fold_of_sequence {X : Type*} (n : ℕ) (f : Fin n → X → X)
    (r : Fin (n + 1) → X) (x : X) (hzero : r 0 = x)
    (hstep : ∀ i : Fin n, r i.succ = f i (r i.castSucc)) :
    Fin.foldl n (fun z i => f i z) x = r (Fin.last n) := by
  induction n with
  | zero => simpa using hzero.symm
  | succ n ih =>
    rw [Fin.foldl_succ_last]
    have ht := ih (fun i => f i.castSucc) (fun i => r i.castSucc) hzero
      (fun i => hstep i.castSucc)
    rw [ht]
    exact (hstep (Fin.last n)).symm

def gaps {n : ℕ} (T : ℝ) (t : Fin n → ℝ) (i : Fin (n + 1)) : ℝ :=
  (Fin.snoc t T : Fin (n + 1) → ℝ) i - (Fin.cons (0 : ℝ) t : Fin (n + 1) → ℝ) i

theorem gaps_reversed (n : ℕ) (T : ℝ) (t : Fin n → ℝ) (i : Fin (n + 1)) :
    gaps T (fun j => T - t j.rev) i = gaps T t i.rev := by
  have hl : (Fin.cons (0 : ℝ) (fun j : Fin n => T - t j.rev) : Fin (n + 1) → ℝ) i = T - (Fin.snoc t T : Fin (n + 1) → ℝ) i.rev := by
    induction i using Fin.cases with
    | zero => simp
    | succ j => simp [Fin.rev_succ]
  have hr : (Fin.snoc (fun j : Fin n => T - t j.rev) T : Fin (n + 1) → ℝ) i = T - (Fin.cons (0 : ℝ) t : Fin (n + 1) → ℝ) i.rev := by
    induction i using Fin.lastCases with
    | last => simp
    | cast j => simp [Fin.rev_castSucc]
  unfold gaps
  rw [hl, hr]
  ring

#print axioms gaps_reversed
#print axioms fold_of_sequence
#print axioms reverse_fold_cancel
end
end PBPSWordWork97
