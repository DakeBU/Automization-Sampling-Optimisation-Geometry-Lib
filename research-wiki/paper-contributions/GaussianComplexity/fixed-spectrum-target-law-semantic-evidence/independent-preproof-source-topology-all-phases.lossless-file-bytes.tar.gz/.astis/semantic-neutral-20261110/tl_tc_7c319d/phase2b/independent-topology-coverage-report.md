# Target-law phase2b independent topology/consumer/coverage challenge

**HOLD(TL-COV-1) the candidate's complete coverage-alignment acceptance.** The source-selector topology, exact seven-step delta, fixed-O law scope and possible substantive producer use in both private conjunction branches are acceptable at their declared unproved specification boundary. Two per-original-element scope-role labels incorrectly attribute pure normalizer context to a selected mean/target-law component. This is a narrow alignment correction, not a refutation of the paper, exact types or mathematical law.

The phase1 raw-source cognition and phase2a exact-type/binder/definition judgment remain frozen. This continuing reviewer is not fresh: old Detector/source/type/graph/process exposure remains declared, and no old ACCEPT is taken as authority for this packet. I did not open the full seal, root plans/reuse/process material, SG cognition/verdict/report, SG manifest verdict fields, implementation or proof/API material. Graph status/digest/assertion fields are visible metadata only, never independent acceptance evidence.

## Versions independently checked

* New phase1 source selector: SHA256 `5c433ebe49be188db05bad6c91dac3903a5767539ee18939e36860d1cabac1df`.
* Candidate selector v2: SHA256 `3448a14a9634474f6e7855c7e899e5b0631c14cde0a1118158db2dedc3ab56bd`.
* Exact selector delta: SHA256 `660724759634bdc66d7082815ccaf0e6c139a173000cf64d67c0cd6f41387700`.
* Type-semantic-use overlay: SHA256 `991816a8f58b34509474606e48f7cd29751c1248717e51def9847ca47db0be47`.
* Coverage checkpoint: SHA256 `d473ec821c3c489d204e908400149b5472f729dd490ec951a90a051f3c9da667`.
* Coverage alignment: SHA256 `755076e7d113736233ca0717dcd5365b510d06e47f45dbebf2eeef2333028495`.
* Target binding: SHA256 `b33d7bd876b4a4a7ca6114a521544b28110a5ee0bc64266b8950d6a2b1ddd1fa`.

The referenced full author graph remains exactly SHA256 `a3d876092b9854614c6d09bba8f1fa4add8d772ba030fa2358526b9c55ac6449`, and the full original coverage inventory remains exactly `63f9a219a6b0d20cbe40acfcdae91f4049c4666363fbfddc48e0f0f4285e377a`. Only applicable mathematical nodes/edges and original coverage rows were used; no old TC verdict/HOLD/grant file was opened.

## TL-COV-1: two normalizer-only original elements mislabeled

In `coverage_alignment.json`, these two exact `source_id` rows have `exact_type_scope_role` set to:

`Mixed source region: selected mean/target-law statement only; other outputs preserved outside exact type`.

That attribution is incorrect for the individual original elements:

| Source element | Complete mathematical content | Correct scope role |
|---|---|---|
| `A3.Ex160` | `Z_A=(2π)^(d/2)(det A)^(-1/2)=(2π)^(d/2)(detΛ)^(-1/2)` | Pure Gaussian partition-function/normalizer context, outside the exact law/norm-sum component. |
| `A3.SS4.p3.2` | Λ fixed implies Z_A independent of O and known when the spectrum is public. | Pure public-normalizer context, outside the exact law/norm-sum component. |

Neither row contains a selected norm mean or Gaussian linear-image-law substatement. The preceding `A3.SS4.p3.1` does state the associated target N(0,A⁻¹), so it can legitimately be mixed target-definition/normalizer context; its neighbors must not inherit a nonexistent selected suboutput merely because they share `bg:C4-normalizer`.

The original checkpoint had the correct role, “normalizer context, not sufficient Gaussian-law proof.” The target binding also correctly leaves the Z identity outside these exact types. The scope-role regression is therefore specifically in the two alignment row labels. Their original NODE dispositions, node `bg:C4-normalizer`, byte spans and raw hashes are intact. `coverage-role-witness.json` preserves exact source text, hashes, old role and candidate role.

**Minimal requested revision:** preserve the candidate and create an author-owned successor that changes only those two `exact_type_scope_role` strings to accurately retained normalizer context/sibling outside the exact law/norm-sum claim. Do not delete NODE coverage, change source text/hash, add the normalizer as a law/mean premise, change a type/binder, rewrite the old full graph, or alter the already correct seven-step source-selector delta. This reviewer has not edited or supplied a candidate graph/alignment repair. After that narrow correction, independent rereview can check it without reopening root process material.

The finding is an exact source-component attribution defect, not a missing source paragraph, missing Gaussian proof, or numerical counterexample. All broader mathematical/proof implications remain at their prior boundaries.

## Delta and raw coverage verification

I independently recursively compared the two selectors and independently applied the supplied operations to the old selector. The candidate is exactly the result of **seven** operations: one status replacement, one appended target-norm-sum root, one appended source-use hyperedge, and four appended matching consumer-use backlinks. There are six adds and one replace; no other selector field changes. This selects the finite inverse-spectrum norm sum independently from the already retained closed-M formula.

Using the pinned original HTML (951991 bytes / SHA256 `6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915`), a separate DOM enumeration from the five declared source scopes found 67 original paragraph/display/heading elements. Exact source IDs, spans and raw hashes match every checkpoint row. All 57 NODE and 10 EXCLUDED dispositions, node IDs and reasons exactly match the canonical original inventory; all alignment rows preserve those dispositions. These counts follow exact original-element comparison and do not confer mathematical proof coverage.

Complete source law, C.3 mean/series/cosine/variance/bias and C.4 positivity/normalizer context were read at raw phase1 and reused with this fixed hash. Sibling cosine/variance/bias/normalizer regions remain represented rather than disappearing because the selected exact type is narrower. Heading and roadmap exclusions remain appropriate. The only failed alignment judgments are the two role labels identified above.

## Source nodes and edges: independently accepted bounded meanings

* `tl:fixed-O-law` selects §4.2's target/latent Gaussian-law relationship. `tl:e-law` consumes the literal grid/target/rotation, positive spectrum, inverse-conjugation algebra and standard Gaussian linear-image rule. The explicit field selection from the hard-family node consumes fixed A and target, not its Haar/algorithm experiment. The source's backward map U=OᵀY and the forward fixed-O pushforward are equivalent via the same invertible orthogonal map. This does not manufacture a random-O joint law, measurable parameter kernel or pointwise conditional representative.
* `tl:latent-norm-sum` selects only C.3 p4's `M=Σ_i 1/λ_i`. `tl:e-norm-sum` needs positive diagonal covariance and actual Gaussian finite second moments plus the finite norm-square identity. Fourth moments, coordinate independence for variance, inverse-spectrum series interchange and n-dependent cosine estimates are not forced into this finite-sum output.
* `tl:latent-norm-mean` / `tl:e-exact-M` retain the separate refinement by the absolutely convergent inverse-spectrum expansion, midpoint aliases and displayed geometric summation. It is sequential source evaluation, not an alternative full proof or a new premise of the finite-sum helper.
* `tl:target-norm-mean` preserves the target transfer of that closed M context. The appended `tl:target-norm-sum` and `tl:e-target-norm-sum` instead transfer only the finite latent inverse-spectrum mean using the actual law, all-vector norm isometry and measurable/integrable expectation transport. Independently computed ancestors of the appended root exclude the closed-M selector and inverse-spectrum series node. All four appended backlinks match their forward edge's consumer and premise.

All referenced source/background/type IDs exist and all recorded backlinks point to genuine forward uses. The backlink lists are selected-use summaries, not a claim to enumerate a compiler dependency graph. No false AND of complete alternative proofs is introduced. Both the finite-sum root and exact-M refinement are preserved without making the stronger evaluation necessary for the weaker exact consumer.

## Background gaps, actual types and consumer branches

The six source-only background records correctly separate Gaussian linear law, inverse/conjugation, norm isometry, Gaussian second moments, expectation transport and Gaussian normalization. Their general proofs are unexpanded; a SOURCE_GAP_GENERAL_PROOF label here denotes an author-invoked standard theorem whose general proof is omitted, not a false paper statement or a new public assumption. In particular covariance transport and properness are not established merely by knowing a partition function.

The typed overlay's producer is the exact full actual-measure law of phase2a, not the old one-event Detector helper. Actual constructor/proper-covariance recognition, the literal Euclidean rotation's measurability/isometry, latent norm-square L1 and actual integral transfer are explicit **unproved** semantic obligations. The standard linear-map law includes the ordinary measurable-law interpretation; typing a literal `Measure.map` is not itself proof that this interpretation has been discharged. No source author edge is fabricated from CFC internals, a library API name or an implementation proof. This overlay is a semantic binding/possible route, not a completed fine-grained implementation proof DAG.

`type:e-L1` legitimately uses actual law equality, measurable norm-square pullback, latent L1 and expectation-transport background to derive the private consumer's left Integrable output. `type:e-mean` uses the same actual law/isometry and the latent real inverse-sum integral for the right output. Recomputed ancestry confirms the exact producer reaches both branches in this specified possible source-coordinate route. `type:e-root` is AND because both conclusions are requested. Unlike the previous Detector measurability conjunct, this new left L1 conclusion can genuinely be transported through the law. This is not a claim that every valid proof must do so or that actual code has called the producer; actual invocation, branch use and test reachability stay **UNOBSERVED**.

Parameter/definition adaptation is faithful: d≥2,κ≥2; all fixed full O including determinant −1; midpoint Fin indexing; precision Λ,A versus matrix-inverse covariance; real scalar reciprocal terms in the mean; Euclidean WithLp matvec/norm; actual proper Gaussian/map/real integral meanings under internally derived source positivity and measurability. The output Integrable prevents a totalized nonintegrable integral from being treated as the source mean. There is no n/q/δ/C/τ/ε/bias-gap premise for the norm-only component, no nonzero-vector restriction, and no Haar/conditional-history conclusion. No MAIN theorem hypothesis is added.

## Frozen result and remaining limits

Source-selector/possible typed-use topology: **ACCEPT_BOUNDED_SPECIFICATION**, including exact seven-step replay. Raw coverage/disposition preservation: **PASS**. Complete candidate coverage alignment: **HOLD(TL-COV-1)** pending the two role-label corrections. The phase2a type/binder/definition verdict is unchanged.

No source/library background is thereby proved. Full closed-M/cosine/variance/bias results, actual joint/conditional Gaussian experiment, target probability, algorithm law/rejection, concentration, TV/query/cost lower bound, compiled producer use, Lean/native/proof status and normal intake/process/SAU/sourceV/V/STAB/global/wholeGoal authority remain ungranted. Freeze this mathematical judgment before process disclosures; the original SG author must issue any minimal successor, followed by independent rereview.
