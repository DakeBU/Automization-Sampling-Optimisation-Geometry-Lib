# Mode-gap packet: independent raw-source cognition, phase1

This phase contains raw observations only, before any new exact statement/signature or extractor record. It gives no statement ACCEPT/HOLD, target-specific NODE/EXCLUDED coverage or graph admission. The actor remembers earlier C7/grid/means/Variances/Bias source-challenge roles, old decisions and process exposure from the existing conversation; no pristine paper-ignorance is claimed. No old verdict artifact was reopened to produce this record.

Fresh source reads cover complete S2, complete S4 including limitations, complete C.3, and the genuinely cited local bibliography object `bib.bib3`. The input is the original 951991-byte HTML, SHA-256 `6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915`. The reused unchanged own helper parses this HTML only. Current relevant governance was reread separately; no frontier, ledger, exact new statement, actor graph, implementation, API body or lesson was read.

## Source meanings before the asymptotic application

S2 fixes Euclidean norm, matrix PSD order and real orthogonal group/Haar law. For d≥1 and κ≥1, the precision class consists of symmetric A with I≤A≤κI. The target is the actual centered Gaussian π_A=N(0,A⁻¹), with A a precision matrix. The exact first-order oracle returns (xᵀAx/2,Ax); value-and-gradient, gradient-only and matrix-vector access are equivalent on this quadratic class.

Algorithm randomness is independent of input. Queries, stopping decisions and output are Borel functions of seed/history. A query budget is an integer deterministic per-run cap on every input/seed, not an expectation. ρ_A^Alg includes seed averaging, and the sampling requirement is a uniform-in-input TV bound. These definitions matter to the eventual lower-bound theorem; a scalar mode-range fact is not itself an oracle or TV result.

S4.1 defines the fixed spectrum for d≥2 and κ≥2:

```text
θ_i=(i−1/2)π/d, i=1,…,d;
λ_i=(κ+1)/2+(κ−1)cosθ_i/2;
Λ=diag(λ_i); O Haar and independent of algorithm seed; A=OΛOᵀ.
```

The spectrum and normalizing constant may be supplied to the algorithm; the eigenbasis is hidden. κ=2 recovers the older fixed-spectrum family, and the affine relation between the precision matrices preserves matrix-vector query information. Those historical facts do not change the general κ domain or make source-name correspondence a checked implication.

Lemmas4.3–4.4 use q an integer ≥0, the mode n=2q+1, and the requirement 2q+1<d. The block Krylov space is spanned by Λ^j g_a for a≤q+1 and j≤q, using q+1 independent standard Gaussian starting vectors. The additional vector accounts for the output. Polynomial coefficients may depend on the full experiment; uniformity over the whole space, not independence of the output, makes the statistic estimate applicable. The coupling must preserve the joint law of (O,X).

Lemma4.4 defines the particular threshold τ_dq with an absolute C>0 and is conditional on τ_dq≤1/2. Its conclusion is a simultaneous bound |uᵀD_nu|≤2τ_dq||u||² with probability ≥0.99. The source says its estimate is independent of κ after changing to cosine polynomial coordinates. Neither a generic arbitrary threshold nor an event certificate is a source-wide input.

## Exact outer regime and the mode/separation use sites

Theorem4.1 has the order of quantifiers: for each fixed δ∈(0,1), there exists d0(δ), then for every integer d≥d0(δ), every 2≤κ≤d^(1−δ), and 0<ε≤1/10, its query lower bound holds. The proof supposes a q-query algorithm with

```text
q≤(δ/256)√κ log d,
n=2q+1,
τ=τ_dq.
```

The raw source does not replace these with a fixed κ/q sequence depending arbitrarily on d. The large-d statements are asserted uniformly over the admitted κ and q range; their thresholds depend on δ (and the fixed absolute constants), not on an individual κ, q, algorithm, seed or ε. That dependence must not be changed silently.

`S4.SS3.SSS0.Px1.p1.1` first uses the q bound and κ≤d^(1−δ) to state q+1≤d^((1−δ)/2)log d and n=o(d). The displayed Ex20 bounds τ by quantities tending to zero. Then p1.2 obtains **n<d and τ≤1/2 for sufficiently large d depending only on δ**, allowing Lemmas4.3–4.4 to be applied. These are produced applicability facts in this main-theorem argument, not extra assumptions on the algorithm theorem.

`S4.SS3.SSS0.Px2.p2.1` separately observes

```text
n=o(d),
√κ≤d^((1−δ)/2)=o(d),
therefore d−n≥√κ for sufficiently large d.
```

The positive δ range and fixed upper growth exponent are used in these uniform little-o statements. “For sufficiently large d” is not “for every d≥2.” The paper does not give an explicit numerical dimension threshold for this conclusion. It also does not state an intermediate fixed fraction such as n≤d/2 as a theorem premise. Such internal arithmetic or asymptotic details are omitted background, not source-provided certificates.

There are several distinct range facts: n=2q+1≥1 from the nonnegative integer query count; n<d for the positive finite-grid mode; and the stronger **d−n≥√κ** for the normalized-bias remainder. The stronger inequality implies a strictly positive gap since κ≥2, but the source uses the first upper-range fact earlier on the algorithm side. They should not be merged with τ smallness or with later probability thresholds just because one final d0 can satisfy them together.

The source mode n is a positive integer in Lemma4.5/C8, while q is a nonnegative integer in the query application. A zero-based coordinate index is different again: i_source=i.val+1, preserving the midpoint. Any real-valued gap inequality concerns the real difference d−n; natural subtraction or casts need the already established source range before identities involving that difference are used. No source rounding, ceiling, floor or hidden truncation convention is supplied.

At the level of Lemma4.5, d−n≥√κ is an **explicit conditional premise** for the displayed two-sided bias estimate. At the level of Theorem4.1, it is an **internally obtained applicability conclusion** of the outer parameter regime. The semantic role of the same inequality depends on the source anchor. The source does not permit turning an omitted proof of this applicability step into a new premise of the main theorem.

The common later choice of d0 also retains algorithmic applicability and ensures τ≤β/4 and Mβ²≥320. The existence of a local mode/separation threshold alone does not establish that common choice or the complete main theorem. Conversely, those probability conditions are not necessary source premises for the scalar mode-gap observation itself.

## C.3 context and why the mode range matters

Lemma4.5 fixes U~N(0,Λ⁻¹), with covariance the inverse of precision. M=E||U||² and μ_n=E[UᵀD_nU] are actual means, with D_n=diag cos(nθ_i), ρ=(√κ−1)/(√κ+1), and integer 1≤n<d. This general mode range does not require n odd, a query relation, δ or a κ-versus-d growth regime.

C7 expands the inverse spectrum in cosine modes, absolutely and uniformly in θ for each κ≥2. The majorant ρ/(1−ρ) is κ-dependent. C8 first states the grid identity for every integer frequency k, including negative k and zero: the sum vanishes off 2dZ, while at k=2ad it equals d(−1)^a. Its nonmultiple case needs a nonzero sine denominator. Actual Gaussian second moments give the finite mean sums; the Gaussian finite-expectation/sum identification is distinct from the scalar absolute-series/finite-grid interchange.

For the norm mean, only j=2ad terms survive. For μ_n, product-to-sum and the source range yield the disjoint positive classes j=n, j=2ad+n and j=2ad−n, with a≥1 for the latter two. That range and parity must be retained even when a higher-level proof reuses the resulting source mean formulas. C8 yields

```text
M=(d/√κ)(1−ρ^(2d))/(1+ρ^(2d)),
(−1)^n μ_n=(d/√κ)(ρ^n−ρ^(2d−n))/(1+ρ^(2d)).
```

The complete C.3 variance paragraph derives independence from the diagonal Gaussian law, fourth moments E U_i^4=3/λ_i², and Var(U_i²)=2/λ_i². The exact variance sums have squared coefficients and denominator λ_i²; both are ≤2M since λ_i≥1. M≤d/√κ is then obtained separately from the exact mean. These are neither assumptions nor consequences of the query-mode-gap estimate. Actual integrability/L2, diagonal inverse/covariance and finite variance identities are omitted internal bridges, not free public inputs.

For 1≤n<d, 0<ρ<1 gives positive M and strictly positive signed mean (−1)^n μ_n. The numerator ordering depends on n<d. Dividing the exact means gives the ratio of means, not the expectation of a samplewise ratio:

```text
β=|μ_n|/M=ρ^n(1−ρ^(2(d−n)))/(1−ρ^(2d)).
```

The correction ratio lies between 1−ρ^(2(d−n)) and 1. C.3's log-integral identity on the nonsingular interval [0,1/√κ] gives

```text
2/√κ≤log(1/ρ)≤(2/√κ)(1+1/(3(κ−1)))≤8/(3√κ)<3/√κ,
exp(−3n/√κ)≤ρ^n≤exp(−2n/√κ).
```

The signs, log domains, denominators, continuity/integrability and power/cast identities are internal background. The order reversal is associated with a negative exponent multiplier; no API surface is inferred from the source formulas.

Only the separated tail estimate additionally uses d−n≥√κ, bounding ρ^(2(d−n))≤exp(−4). This yields the exact factor 1−exp(−4) in the final paired inequality. The exponential upper bias already follows from an earlier intermediate range without that extra gap, though the displayed source two-sided theorem is conditional. At n=d the strict signed numerator vanishes, so that boundary cannot inherit the source positivity/lower-bias conclusion. Off-range/default semantics are not specified by the paper.

## Downstream probability mechanism remains separate

Section4 defines the genuine test

```text
S_A(x)=(−1)^n xᵀT_n((2A−(κ+1)I)/(κ−1))x−2τ||x||²,
E_A={x:S_A(x)>0}.
```

The geometric normalized weights require x≠0 only for their presentation. The polynomial statistic is defined at zero and the strict passing event excludes it. The source uses orthogonal conjugation and T_n(cosθ_i)=cos(nθ_i). For an exact sample Y|O~π_A, U=OᵀY has N(0,Λ⁻¹) law. This conditional transport is distinct from the scalar gap and does not assert Y is independent of O.

The algorithm-side good event plus the law-preserving Krylov coupling gives E_A[ρ_A^Alg(E_A)]≤0.01, an input-averaged statement. The target-side source β bound, the q bound and an additional M lower estimate lead to β≥b d^(−δ/4), τ/β→0 and Mβ²→∞, uniformly. Here b=(1−exp(−4))exp(−3) is a source scalar constant, not the target quadratic mean. The M lower estimate uses a small ρ^(2d) and the actual closed mean; it does not follow from n<d alone.

After choosing a common d0 with τ≤β/4 and Mβ²≥320, the fixed-A contrast has EZ≥βM/2>0. The centered L2 triangle, not independence of the whole quadratic statistics, gives VarZ≤8M using 0≤τ≤1/2. Chebyshev's positive-threshold condition is then supplied by the actual positive mean, and the strict event complement is Z≤0. The source concludes each target passes with probability ≥0.9. Uniform per-input TV and averaging with the algorithm-side ≤0.01 then produce the 0.89 contradiction. None of these law, mean, concentration, event or oracle steps is replaced by a mode-gap fact.

## Complete Section4 limitations and bibliography scope

Section4.4 states limits of this method, not impossibility of stronger lower bounds for the family. Lemma4.7 gives dim K_q=min{d,(q+1)²} almost surely. If the enlarged space is full, the source grid cosine-square identity provides a coordinate yielding a uniform-statistic lower bound ≥1/√2. Its text's “supremum at most1/2” limitation threshold is stronger than the standalone Lemma4.4 condition τ≤1/2 followed by a 2τ bound; the latter alone gives at most1. Earlier τ→0 can support a stricter numerical choice, but those two guards are not literally identical.

The accuracy limitation compares an algorithmic threshold a with β and cites the Bernstein calculation of FactC6 to require a≥c/√d. Together with the exponential bias upper bound and n=2q+1, it yields an O(√κ log d) ceiling for this proof method independent of ε. FactC6's proof and Appendices C.1/C.2/C.4 were not newly read here; their named source uses are inventoried but not independently certified. The method's limitations do not rule out stronger results by a different analysis.

There are four actual [22] citation occurrences in S4, all resolving to the same local bibliography entry. Its title, publication identifier, local backlinks and external download URL are preserved. No linked external work was opened. Internal theorem/proof references outside S2/S4/C3 are likewise preserved as references, not silently treated as newly read proofs.

## Protocol, exposure and stop boundary

Current protocol reads reaffirm exact statement sealing before proof search, recursive SOURCE/STANDING/TYPING/RULED/EXCESS binder audit, literal/characterized/representative definition semantics, source-only topology independent of Lean, exhaustive source dispositions, exact consumer-use sites, explicit conditional discharge and SOURCE_GAP bookkeeping. Different source-audit uncertainty is authorized separately from root's sole proof work; this actor does not construct or delegate a competing target proof. Process constraints and source hypotheses remain distinct.

Protocol files contain unrelated project paths/status handoff text; those incidental cues were not followed or used as source mathematics. The normal scheduling/frontier/harness workflow is not run by this raw-only role and is explicitly outside the parent-authorized scope. Root reports exact new statements already sealed/type-formed and withheld; that report is not an independently checked proof fact here.

Earlier own C7/grid/means/Variances/Bias source/statement/topology decisions, related conceptual-mirror roles and process-disclosure experience remain part of prior exposure. In particular earlier API-name/signature-line and informal-planning disclosures are known from those roles. They are not imported as new mathematical evidence; old verdict files, statements and graphs were not reopened. The current packet's title/assignment and the old helper path are additional cues, so no zero-cue or pristine-naivety certificate is claimed.

This new raw inventory records 367 distinct source units, unique tag/line/column keys, 350 actual math elements and 54 link occurrences (53 internal and one external), with raw hashes and ordinal-disambiguated same-line anonymous locators. It assigns no target NODE/EXCLUDED or ACCEPT/HOLD. Only the new private phase1 directory was written. No new exact statement, extractor output, root proof plan, Lean/API/Mathlib body, lesson/audit, prior verdict artifact, frontier/ledger/global record, browser/network action, normal ASTIS, source V or Goal completion was accessed or executed. Stop after the raw freeze and await exact phase2 authority.
