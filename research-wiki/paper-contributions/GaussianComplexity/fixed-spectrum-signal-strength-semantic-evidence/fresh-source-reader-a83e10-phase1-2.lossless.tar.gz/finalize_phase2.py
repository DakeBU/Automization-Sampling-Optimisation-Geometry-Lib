from pathlib import Path
import datetime
import hashlib
import json

ROOT=Path('/Users/zhouhuanjian/ASTIS-GC')
OUT=ROOT/'.astis/semantic-neutral-20261110/src_a83e10'
INPUT=ROOT/'.astis/huanjian-gc-fixed-spectrum-signal-strength-20261110/strict-selective-phase2-input.json'
INPUT_SHA='d9581ca48d0ac393fffa07a20a587bdb6d540b1b8e92257fd2a296c482cf4674'
PHASE1_SHA='f4b7e781a584005ade0a21cb0d1df46b1d154b9b94df33d2f83bced7ffe9f822'
SOURCE_SHA='6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def textsha(s): return hashlib.sha256(s.encode()).hexdigest()
def write(name,data):
    (OUT/name).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
assert sha(INPUT)==INPUT_SHA
assert sha(OUT/'phase1.freeze.json')==PHASE1_SHA
phase1=json.loads((OUT/'phase1.freeze.json').read_text())
assert all(sha(OUT/f['path'])==f['sha256'] for f in phase1['files'])
p=json.loads(INPUT.read_text())
assert textsha(p['source']['original_text'])==p['source']['text_sha256']
assert textsha(p['lean_statement']['statement'])==p['lean_statement']['statement_sha256']
assert textsha(p['blind_reconstruction']['text'])==p['blind_reconstruction']['text_sha256']

public_slots=[
 {'slot':'objects','assessment':'match','source_evidence':['S4.E11','S4.Thmtheorem5.p1.1','S4.SS3.SSS0.Px2.p1.1','A3.Ex140'],
  'judgment':'Fin d reindexes the same midpoint grid. Lambda is precision, Lambda inverse covariance; Q is the cosine-weighted diagonal quadratic. M and b are actual integrals under this one Gaussian.',
  'reconstruction':'Preserves all literal objects and actual-law meanings.'},
 {'slot':'domains','assessment':'match','source_evidence':['S4.SS3.p2.1','S4.Thmtheorem5.p1.1','A3.SS3.p10.3'],
  'judgment':'delta,kappa real; d,q natural; 0<delta<1, 2<=kappa<=d^(1-delta), q<=delta/256 sqrt(kappa) log(d). q=0 and both inclusive kappa/cap endpoints are retained. Positive dimension, valid n and d-n gap are internally attainable uniformly at large d.',
  'reconstruction':'Preserves natural-zero and real-cast conventions; no endpoint omission.'},
 {'slot':'quantifiers','assessment':'match','source_evidence':['S4.Thmtheorem1.p1.1','S4.SS3.SSS0.Px2.p2.3'],
  'judgment':'For every delta in the open interval, one natural d0(delta) precedes all varying d,kappa,q. This is uniform in kappa and q and may be enlarged. It is not a supplied witness/certificate.',
  'reconstruction':'Explicitly states d0 depends only on delta.'},
 {'slot':'assumptions','assessment':'match','source_evidence':['S4.SS3.SSS0.Px2.p2.1','S4.SS3.SSS0.Px2.p2.2','A3.SS3.p8.1'],
  'judgment':'Only numeric source regime and literal standard definitions are inputs. Moments, law validity, gap, signal growth, positivity and finite-integral facts are internal proof ingredients. No extra public premise appears. Implementation discharge is unreviewed.',
  'reconstruction':'Adds no hidden assumption or certificate.'},
 {'slot':'conclusion','assessment':'source-faithful-bounded-consequence','source_evidence':['S4.SS3.SSS0.Px2.p2.2','S4.Ex24','A3.SS3.p9.1','A3.Ex150'],
  'judgment':'The three numerical lower bounds match the unnumbered source M estimates and Ex24 signal branch; M>0 and beta>0 are source-supported Gaussian/mode consequences. No b>0 assertion is made; odd n gives negative b.',
  'reconstruction':'Lists exactly the five formal conjuncts.'},
 {'slot':'scopes/senses','assessment':'match-with-explicit-bounded-scope','source_evidence':['S4.SS3.SSS0.Px2.p1.1','S4.Thmtheorem5.p1.1','A3.Ex140','A3.Ex150'],
  'judgment':'Full squared norm, ratio of target expectations, same diagonal inverse-precision Gaussian, finite actual moments. No samplewise ratio, algorithm-output bound, shifted probability, TV conclusion, expected-query-cost claim or whole Theorem 4.1 credit.',
  'reconstruction':'Retains actual integrals and full norm rather than normalized surrogates.'},
 {'slot':'constant dependencies','assessment':'match','source_evidence':['S4.Ex23','S4.SS3.SSS0.Px2.p2.2','S4.Ex24'],
  'judgment':'Formal b is source mu_n; formal B is source b=(1-exp(-4))*exp(-3)>0. Coefficients delta/256 and B^2/2 are exact. d0 depends only on delta; B is absolute; no epsilon-dependent strengthening.',
  'reconstruction':'Preserves constant formulas and the distinction between b and B.'}
]
private_slots=[
 {'slot':'objects','assessment':'match','judgment':'Same actual diagonal target-law mu and cosine quadratic Q; no rotation or algorithm law.'},
 {'slot':'domains','assessment':'match','judgment':'Same numeric regime, including q=0. The closed nonpositive quadratic event is Borel; n is odd.'},
 {'slot':'quantifiers','assessment':'match','judgment':'Own d0(delta) before d,kappa,q; may enlarge without asserting identity with the public witness.'},
 {'slot':'assumptions','assessment':'match','judgment':'No probability/moment/gap/signal certificate input. Finite probability semantics for toReal must be internally established from positive-definite inverse covariance.'},
 {'slot':'conclusion','assessment':'valid-bounded-local-consequence','judgment':'Probability of (-1)^n Q<=0 is <=1/10, including equality at zero. No atomlessness claim is needed.'},
 {'slot':'scopes/senses','assessment':'accurate-private-non-anchor-scope','judgment':'Zero-threshold bad event is contained in the source shifted bad event when tau>=0. A zero-event bound does not imply the shifted detector bound, full Ex26 or TV lower bound.'},
 {'slot':'constant dependencies','assessment':'match','judgment':'Chebyshev gives <=2/(M beta^2); source B>0 and M beta^2 >= (B^2/2)sqrt(d) allow an enlarged common d0 giving M beta^2>=20. No new public assumption or epsilon dependence.'}
]
write('phase2_selective_judgment.json',{
 'schema_version':1,'reviewer':'/root/source_reader_a83e10','phase':'phase2-selective-statement-source-reconstruction',
 'phase1_freeze_sha256':PHASE1_SHA,'selective_input_sha256':INPUT_SHA,'primary_source_sha256':SOURCE_SHA,
 'source_authority':'Previously independently read original S2/S4/A3.SS3, not the projected source paraphrase.',
 'public_statement_sha256':p['lean_statement']['statement_sha256'],
 'source_paraphrase_sha256':p['source']['text_sha256'],
 'blind_reconstruction_sha256':p['blind_reconstruction']['text_sha256'],
 'private_statement_sha256':textsha(p['private_consumer_statement']),
 'source_blind_decoder_identity_as_supplied':p['blind_reconstruction']['decoder'],
 'decoder_packet_sha256_as_supplied':p['blind_reconstruction']['decoder_packet_sha256'],
 'decoder_run_sha256_as_supplied':p['blind_reconstruction']['decoder_run_sha256'],
 'public_slots':public_slots,'private_slots':private_slots,
 'public_statement_reconstruction_comparison':'equivalent under approved standard definitions',
 'public_source_comparison':'source-faithful bounded target-signal consequence, including source-supported positivity outputs',
 'private_source_comparison':'valid further local zero-threshold target-law consequence; expressly not the shifted detector or an Anchor',
 'blocking_deltas':[],
 'scope_differences_requiring_preservation':[
  'This is a bounded analytic branch of S4.3, not the whole lower-bound theorem.',
  'M and b integrate under the identical literal inverse-precision Gaussian; beta is a ratio of expectations.',
  'Private zero-threshold probability is not shifted Ex26; no such substitution is accepted.',
  'Finite/invertible/probability/integrability/gap facts must be internal derivations, not assumed certificates.'
 ],
 'repair_proposed':False,'implementation_seen':False,'exposition_seen':False,'prior_verdict_content_seen':False,
 'canonical_packet_opened':False,'canonical_audit_updated':False,
 'decision':'SELECTIVE_STATEMENT_SOURCE_RECONSTRUCTION_PASS',
 'not_certified':['Lean truth','whole-module definition implementation','proof-ingredient discharge','authored proof/exposition','source graph coverage','publication binding freshness','full canonical audit acceptance','whole-paper closure'],
 'narrative':'phase2_selective_judgment.md'
})

write('phase2_run_provenance.json',{
 'schema_version':1,'reviewer':'/root/source_reader_a83e10',
 'authorization':'Parent followup expressly authorized the strict selective projection only after unchanged phase1 freeze; implementation/exposition and full canonical packet withheld.',
 'input_artifacts_read':[{'path':str(INPUT.relative_to(ROOT)),'sha256':INPUT_SHA}],
 'previous_cognition':{'path':str((OUT/'phase1.freeze.json').relative_to(ROOT)),'sha256':PHASE1_SHA,'payload_count':len(phase1['files']),'payload_hashes_reverified':True},
 'primary_source':{'path':'.astis/huanjian-resume-20261103/2610.20492v1.html','sha256':SOURCE_SHA,'content_read_in':'phase1'},
 'derived_extraction_clarification':'phase2_extraction_provenance_clarification.md',
 'internal_text_hashes_verified':{'source_paraphrase':p['source']['text_sha256'],'public_statement':p['lean_statement']['statement_sha256'],'reconstruction':p['blind_reconstruction']['text_sha256']},
 'parent_canonical_packet_sha256_as_supplied_unopened':p['parent_canonical_packet_sha256'],
 'judgment_sha256':sha(OUT/'phase2_selective_judgment.json'),
 'narrative_sha256':sha(OUT/'phase2_selective_judgment.md'),
 'source_independence':'Raw source cognition predated the candidate projection. Older incidental filenames remain disclosed; no prior review content was opened.',
 'new_reads_not_performed':['full canonical reviewer packet','candidate implementation','candidate lesson/exposition','candidate graph','binder-audit verdicts','earlier reviews','code/API','native/browser/site surfaces'],
 'new_external_or_canonical_mutations':False,
 'bounded_mathematical_reasoning':'Statement-level Chebyshev consequence is explained without constructing or inspecting implementation proof.',
 'stop_boundary':'Separate selective phase2 freeze before any implementation/exposition judgment.'
})

# Phase1 and every payload remain byte-identical. Only new phase2 files are sealed.
assert sha(OUT/'phase1.freeze.json')==PHASE1_SHA
assert all(sha(OUT/f['path'])==f['sha256'] for f in phase1['files'])
names=['phase2_extraction_provenance_clarification.md','phase2_selective_judgment.md',
       'phase2_selective_judgment.json','phase2_run_provenance.json','finalize_phase2.py']
manifest={
 'schema_version':1,'phase':'phase2-selective-cognition-judgment-frozen','reviewer':'/root/source_reader_a83e10',
 'frozen_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'phase1_freeze_sha256':PHASE1_SHA,'phase1_all20_payloads_unchanged':True,
 'selective_input':{'path':str(INPUT.relative_to(ROOT)),'sha256':INPUT_SHA},
 'primary_source_sha256':SOURCE_SHA,
 'reviewer_run_sha256':sha(OUT/'phase2_run_provenance.json'),
 'judgment_sha256':sha(OUT/'phase2_selective_judgment.json'),
 'files':[{'path':name,'bytes':(OUT/name).stat().st_size,'sha256':sha(OUT/name)} for name in names],
 'decision':'SELECTIVE_STATEMENT_SOURCE_RECONSTRUCTION_PASS','blocking_deltas':[],
 'implementation_exposition_phase_begun':False,'full_canonical_packet_opened':False,
 'freeze_semantics':'These exact phase2 bytes remain unchanged. Future implementation/exposition judgments require separate authorization and separate artifacts.'}
write('phase2.freeze.json',manifest)
digest=sha(OUT/'phase2.freeze.json')
(OUT/'phase2.freeze.sha256').write_text(digest+'  phase2.freeze.json\n')
for name in names+['phase2.freeze.json','phase2.freeze.sha256']:
    (OUT/name).chmod(0o444)
print(json.dumps({'freeze_path':str(OUT/'phase2.freeze.json'),'freeze_sha256':digest,
 'reviewer_run_sha256':manifest['reviewer_run_sha256'],'judgment_sha256':manifest['judgment_sha256'],
 'blocking_deltas':[],'phase1_preserved':True},indent=2))
