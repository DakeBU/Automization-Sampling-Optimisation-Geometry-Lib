# Frozen source-only cognition: cosine frame and Gaussian Gram means

Status: source cognition only, prepared before candidate/type/decoder/code exposure. This report certifies neither a Lean statement nor a proof implementation. The assigned packet's intended general role was supplied in the task; no claim of pretrained zero knowledge, pristine cognition, or absence of all prior mathematical knowledge is made.

## Source and reading boundary

The pinned input is *On Complexity of Gaussian Sampling*, arXiv:2610.20492v1, local bytes 951991, SHA256 6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915. The complete bytes are retained at inputs/2610.20492v1.html. Model-visible mathematical readings came from S4.SS1, S4.SS2.SSS0.Px1, S4.SS2.SSS0.Px2, S4.Thmtheorem4, A3.SS2, and A3.Thmtheorem5, with full proofs A3.SS2.2–A3.SS2.4. Related Lemma 4.3 was read solely because its paragraph defines the Krylov space. No local Lean, candidate seal/type/draft, anonymous decoder, old semantic/native/source verdict, controlled index, ledger, site, or ATLAS content was read.

Exact source HTML slices, UTF-8 byte offsets with exclusive ends, source fragment hashes, and MathML alttext with their own source locators are retained under raw/. extraction-locators.json covers the initial six source regions; proof-detail-locators.json covers all C.2 proof paragraphs and proof wrappers. These are byte slices of the original input, not BeautifulSoup reserializations. The latex-text files are convenience renderings that replace each math node with its alttext; the exact HTML and original input remain authoritative. All 167 C.2 math nodes have alttext. All procedural input snapshots and initial tool results are preserved.

## Objects, indices, normalization, and standing setting

1. The source hard family fixes integers d >= 2 and real kappa >= 2 (S4.SS1). Its half-grid is theta_i = (i - 1/2) pi / d for i = 1,...,d. Thus theta_i lies strictly between 0 and pi; neither endpoint is a sample. In a zero-based row carrier the same angle is (i + 1/2) pi / d, not (i - 1/2) pi / d.
2. The spectral values are lambda_i = (kappa+1)/2 + ((kappa-1)/2) cos(theta_i), and Lambda is their diagonal matrix. K_q(g_1,...,g_{q+1}) = span {Lambda^j g_a : 1 <= a <= q+1, 0 <= j <= q}. This definition is recorded as context, not a completed range theorem.
3. q is a nonnegative integer query budget. Although the displayed Lemma 4.4 says q >= 0 without repeating “integer”, the preceding Lemma 4.3 explicitly fixes an integer q, and the coordinate/vector/power notation requires it. The source condition is 2q+1 < d. Set r = q+1 and n = 2q+1 before defining the C.2 objects. In this integer setting r >= 1, d >= 2, and 2r <= d. The last consequence is explicitly used in C.6; it is not an extra premise.
4. D_n = diag(cos(n theta_1),...,cos(n theta_d)); its weights are deterministic and may have either sign. D_n is distinct from Lambda. n is the specified high frequency 2q+1, not an arbitrary frequency parameter.
5. t_i is a real r-vector with coordinates j = 0,...,q:
   t_i,0 = 1, and t_i,j = sqrt(2) cos(j theta_i) for 1 <= j <= q.
   The constant coordinate is not sqrt(2); the nonconstant coordinates are not unscaled cosines.
6. g_1,...,g_r are independent N(0,I_d) vectors. gamma_i = ((g_1)_i,...,(g_r)_i) is a real r-vector. C.2 states that gamma_1,...,gamma_d are independent N(0,I_r). This is a consequence of the actual product standard Gaussian law, not a substitute definition of arbitrary rows.
7. B is a random real d by r^2 matrix with row i equal to d^(-1/2) (gamma_i tensor t_i)^T. The tensor order is Gaussian coordinate first and cosine coordinate second. In pair coordinates (a,j), B_i,(a,j) = d^(-1/2) gamma_i,a t_i,j. A consistent permutation of pair coordinates is an adapter issue; changing the scale changes the source object.
8. All norms of t_i and u here are Euclidean. The source row bound is a bound on the *squared* norm. C.6's matrix norms are operator norms. Expectations are unconditional expectations with respect to the actual Gaussian law of B.

The deterministic t_i identities do not involve kappa or O. The nonconstant affine dependence on cos(theta_i), hence kappa != 1, matters to the separate range(B)=K_q proof. Source kappa >= 2 supplies that fact. Lemma 4.4's estimates and the deterministic cosine frame calculations themselves are kappa-independent.

## Exact source claims relevant to this packet

Fact C.5 (A3.Thmtheorem5, displays A3.Ex86 and A3.Ex87) states the conjunction
  range(B) = K_q,
  E[B^T B] = I_(r^2),
  E[B^T D_n B] = 0,
and moreover
  ||t_i||^2 <= 2r  for every i = 1,...,d,
  sum_(i=1)^d t_i t_i^T = d I_r,
  sum_(i=1)^d cos(n theta_i) t_i t_i^T = 0.

For the assigned bounded packet, the three deterministic assertions and the two Gaussian mean assertions are the relevant source content. The range equality is independently present in the source and is required by the full Lemma 4.4 route; recognizing or recording it does not complete it. None of these identities is a concentration theorem.

The frame Gram identity is unnormalized: sum t_i t_i^T = d I_r. Normalizing the sum by 1/d produces I_r. The Gaussian Gram mean is already normalized by B's d^(-1/2) row factor, hence E[B^T B] = I_(r^2), not d I_(r^2). The weighted identity is zero as an entire r by r matrix, not only trace zero.

These statements are exact equalities for each permitted deterministic d,q and frame, and exact Gaussian integrals. They are not assertions that B^T B = I pointwise, nor that the matrices equal their means with high probability. Gaussian integrability must be established for the actual matrix-valued integrands, not encoded as a default-value interpretation of an integral.

## Source proof reading, without candidate implementation

A3.SS2.p3: The range proof uses cos(j theta)=T_j(cos theta), the nonzero affine slope between lambda and cos(theta), and an invertible triangular change of polynomial basis for each a. Nonzero column normalizations preserve range. This is a separate deterministic linear algebra branch. No Gaussian moment is used in that argument.

A3.SS2.p4, displays A3.Ex88–A3.Ex89: For every integer k with 0 < |k| < 2d, the author multiplies sum_i cos(k theta_i) by 2 sin(k pi/(2d)), writes a telescoping sum of sine differences, and obtains sin(k pi)-sin(0)=0. The sine factor is nonzero in that strict frequency range. Therefore sum_i cos(k theta_i)=0. k=0 is separate and has sum d. The proof does not license division by this factor at k=0 or |k|=2d.

A3.SS2.p5, displays A3.Ex90–A3.Ex93: The constant-constant Gram entry sums to d; constant/nonconstant entries vanish by the preceding cosine sum. For j,k >= 1, the sqrt(2) factors give
  2 cos(j theta_i) cos(k theta_i)
    = cos((j-k) theta_i) + cos((j+k) theta_i).
When j=k, the zero-frequency sum contributes d and the sum-frequency term vanishes. When j!=k, both frequencies are nonzero in the admitted range, so both sums vanish. Symmetry completes all matrix entries. This produces sum_i t_i t_i^T = d I_r.

A3.SS2.p6, displays A3.Ex94–A3.Ex95: Using E[gamma_i gamma_i^T] = I_r, the author takes expectation of the finite row-outer-product expansion:
  E[B^T B]
    = (1/d) sum_i (E[gamma_i gamma_i^T] tensor t_i t_i^T)
    = (1/d) (I_r tensor sum_i t_i t_i^T)
    = I_(r^2).
This source branch consumes the deterministic Gram identity and the actual Gaussian second moment.

A3.SS2.p7, displays A3.Ex96–A3.Ex101: For 0 <= j,k <= q and n=2q+1, all four frequencies n +/- j +/- k lie between 1 and 4q+1, strictly below 2d. The triple product expands into one quarter of the four corresponding cosines. The previous cosine sum therefore kills every term. Every entry of the weighted frame sum is a constant multiple of such a triple product sum, including constant-coordinate cases via cos(0 theta)=1. Hence the entire weighted frame sum is zero. The row formula plus E[gamma_i gamma_i^T]=I_r then gives E[B^T D_n B]=0. This weighted mean logically consumes weighted cancellation and the Gaussian second moment; it does not need to assume the unweighted mean identity.

A3.SS2.p8, display A3.Ex102: The author records
  ||t_i||^2 = 1 + 2 sum_(j=1)^q cos^2(j theta_i)
             <= 1+2q <= 2r.
This is a deterministic pointwise estimate. The exact intermediate 1+2q is one less than 2r. It does not need a Gaussian event.

The source proof uses standard trigonometric and finite matrix/tensor algebra. This report records the author's route and its necessary background; it supplies no new Lean proof, candidate repair, or alternate mathematical proof.

## Quantifier order and endpoint checks

For each fixed permitted d,q (and kappa in the hard-family context), the grid/frame and weights are deterministic. The deterministic identities hold for every frame coordinate or matrix entry, and the norm bound holds for every row. They do not depend on the realization of the Gaussian vectors.

After fixing those deterministic objects, choose the independent standard Gaussian family. B is then the matrix-valued random variable given by the row formula. The two mean identities integrate over that family. There is no existential choice of a covariance witness in place of this law and no conditioning on an event.

At q=0, r=1, n=1, d>=2, t_i=(1); the nonconstant-coordinate sums are empty, the frame Gram is sum_i 1=d, and weighted cancellation is the single frequency-one cosine sum. The squared row norm is 1 <= 2. q=0 is included, so a signature requiring q>0 would strengthen the source. d=0 or d=1 is outside the standing/2q+1<d source setting; no fallback semantics is suggested.

The strict source condition 2q+1<d is retained. A weaker condition might suffice for some deterministic subclaims, but that would be a separately stated generalization and is not silently inferred as the source contract. Equality at the frequency cutoff and use of integer frequencies are genuine mathematical issues, not mere indexing choices.

For full Lemma 4.4, the absolute constant C>0 is chosen uniformly before the varying dimensions/budgets; tau_d,q is then defined from C,d,q. Under tau_d,q<=1/2, the probability is at least 0.99 of a *single event on which every u in the random K_q* satisfies the quadratic-form bound. It is not a separate probability statement for each prechosen u. Fact C.6 supplies simultaneous matrix bounds with probability 0.995; A3.SS2.p19 obtains the uniform all-u result from them and the separate range theorem.

## Mean, measurability, moment, and independence dependencies

The source writes E[gamma_i gamma_i^T]=I_r without proving analytic bookkeeping. Under the actual standard Gaussian law this means coordinate products have finite expectations and E[gamma_i,a gamma_i,b]=delta_ab. Since B is a finite linear coordinate expression and its two Grams are finite quadratic polynomial expressions, their measurability and integrability are necessary internal background obligations. The source does not add them as conditional hypotheses.

Only second moments are needed for the C.5 means: coordinate Gaussian squares are integrable, and absolute coordinate products are integrable by standard L2/product control. Deterministic scalar multiples and finite sums preserve integrability. A finite-dimensional matrix-valued expectation also needs the corresponding finite-dimensional norm-integrability bridge; entrywise integrability and the finite carrier provide it. No fourth moment, exponential moment, radial truncation, concentration event, or matrix Bernstein theorem is needed to justify the C.5 mean identities.

The independent g_a together with the standard d-dimensional covariance law give the row laws used in C.2. Within a gamma_i row, the standard Gaussian coordinates have zero means and identity uncentered second-moment matrix. Across different i the rows are independent; that independence is needed for C.6's Bernstein application, but linearity of the C.5 expectation expansion itself does not multiply random quantities from distinct rows. An internal reusable mean lemma could use weaker hypotheses, but the actual source consumer must instantiate the real standard Gaussian family, not leave the desired covariance/Gram mean as an unproved hypothesis.

No independence between t_i and gamma_i is an additional random requirement: t_i is deterministic. No independence of a representation coefficient c from B is asserted. In the preceding Lemma 4.3 paragraph the polynomial coefficients may depend on the entire extended experiment. The C.5 mean formulas therefore do not license E[c^T B^T B c] = E[||c||^2] for such a random c. The author uses simultaneous operator-norm bounds to handle all coefficients on one event.

Lemma 4.4 does not introduce O as a random argument or require a new “g independent of O” hypothesis. Any coupling involved in Lemma 4.3 must be handled by that separate source result. It must not be invented as a premise of a cosine-frame or Gaussian-mean claim.

## Consumers and exclusions

C.2's strategy paragraph A3.SS2.p2 uses B^T B to control ||Bc||^2 and B^T D_n B to control the weighted quadratic form. A3.SS2.p9 moves from exact means to deviations.

Fact C.6 and its complete proof were read as source context, not accepted as completed mathematics in this packet:
- p10–p11 use a Gaussian exponential moment, a tail bound, and a tail integral.
- p12 uses radial symmetry and the same row law/cutoff for a common scalar a, obtaining sum E[Y_i]=a I and weighted sum E[Y_i]=0. The latter consumes deterministic weighted cancellation; plain C.5 untruncated means alone do not prove the radial truncation statement.
- p13 uses the deterministic squared row-norm bound.
- p14 uses Gaussian fourth moments and both the row-norm and deterministic Gram identities to bound the variance.
- p15–p17 use independent centered self-adjoint summands, two-sided matrix Bernstein, union bounds, and recovery of original sums on the truncation event.
- p18 simplifies constants using 2r<=d.
- p19 uses Fact C.6, range(B)=K_q, and tau<=1/2 to prove the source uniform estimate.

Thus this packet cannot claim range(B)=K_q, C.6, or full Lemma 4.4 merely by establishing the deterministic identities and Gaussian means. It also cannot claim the later algorithmic lower bound, admissibility result, target quadratic-form comparison, or C.1 coupling.

## Source gaps, risks, and present assessment

No contradiction in the bounded C.5 formulas or their displayed frequency/norm arithmetic was identified in this source reading. This is an initial source assessment, not a formal verification or a prior-verdict-equivalence claim.

Background not expanded by the author remains explicit: standard Gaussian second moments and finite moments; measurable polynomial maps; finite-dimensional Bochner/coordinate expectation compatibility; finite-sum linearity under integrability; tensor/outer-product identities; trigonometric product-to-sum and sine nonvanishing; and, for the separate range branch, Chebyshev leading coefficient and triangular invertibility. These are internal dependencies rather than new source binders. C.6 additionally omits a precise citation/formulation for its bounded matrix Bernstein invocation; no external source was consulted within this phase.

Potential semantic drifts to test only after this source cognition is frozen are wrong half-grid indexing, wrong constant-coordinate normalization, missing 1/d in Gram scaling, arbitrary-frequency replacement of n=2q+1, q>0 instead of q>=0, norm instead of squared norm, Gaussian law replaced by an abstract moment assumption without a real consumer, an integrability conclusion hidden as a premise, or a pointwise-in-u probability replacing the single simultaneous event. These are risks derived from the raw source, not allegations about an unseen candidate.

The source cognition is now ready for immutable freezing. The next phase may compare selectively supplied sealed types and anonymous decoder text; full implementation access remains deferred until that separate phase is frozen.
