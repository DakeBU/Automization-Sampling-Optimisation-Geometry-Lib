import AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumGaussianMoments
import AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumCosineExpansion
import AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumGridAlias
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Tactic
open Lean
-- Retrieval only, never a mathematical consumer or proof claim.
run_cmd do
  let env ← getEnv
  let exactNames := ["Function.Injective.tsum_eq", "tsum_eq_tsum_of_ne_zero_bij",
    "Summable.sum_add_tsum_nat_add", "Int.mul_ediv_cancel'", "zpow_add₀",
    "zpow_add_one₀", "dvd_add_right", "dvd_add_left", "Int.ediv_eq_of_eq_mul_left",
    "Int.ediv_eq_of_eq_mul_right", "Int.toNat_of_nonneg", "Int.natCast_ofNat",
    "Int.natCast_ofNat", "Int.natCast_toNat", "Int.eq_zero_of_dvd_of_nonneg_of_lt"]
  for (n, ci) in env.constants.toList do
    let s := n.toString
    if exactNames.contains s || s.startsWith "Int.add_ediv" ||
        s.startsWith "Int.add_mul_ediv" || s.startsWith "Int.mul_add_ediv" then
      logInfo m!"{n}: {ci.type}"
