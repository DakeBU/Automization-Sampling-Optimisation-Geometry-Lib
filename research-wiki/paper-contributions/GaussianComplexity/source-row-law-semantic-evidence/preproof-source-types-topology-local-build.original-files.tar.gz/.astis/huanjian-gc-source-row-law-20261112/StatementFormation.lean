import Mathlib
noncomputable section
open MeasureTheory ProbabilityTheory
set_option autoImplicit false

def ProducerStatement : Prop := ∀ {d q : ℕ} (hq : 2 * q + 1 < d),
  let D := EuclideanSpace ℝ (Fin d)
  let E := EuclideanSpace ℝ (Fin (q + 1))
  let Ω := Fin (q + 1) → D
  let μ : Measure Ω := Measure.pi (fun _ : Fin (q + 1) => stdGaussian D)
  let row : Fin d → Ω → E := fun i ω =>
    WithLp.toLp 2 (fun a : Fin (q + 1) => ω a i)
  ∀ i : Fin d, MeasurePreserving (row i) μ (stdGaussian E)

#check ProducerStatement

def ConsumerStatement : Prop := ∀ {d q : ℕ} (hq : 2 * q + 1 < d),
  let D := EuclideanSpace ℝ (Fin d)
  let E := EuclideanSpace ℝ (Fin (q + 1))
  let Ω := Fin (q + 1) → D
  let μ : Measure Ω := Measure.pi (fun _ : Fin (q + 1) => stdGaussian D)
  let row : Fin d → Ω → E := fun i ω =>
    WithLp.toLp 2 (fun a : Fin (q + 1) => ω a i)
  let r : ℝ := ((q + 1 : ℕ) : ℝ)
  let L : ℝ := 2 * r + 3 * Real.log (1000 * (d : ℝ))
  let good : Set Ω := {ω | ∀ i : Fin d, ‖row i ω‖ ^ 2 ≤ L}
  ENNReal.ofReal (999 / 1000 : ℝ) ≤ μ good

#check ConsumerStatement

