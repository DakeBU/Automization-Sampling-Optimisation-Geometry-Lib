"""Build a read-only Phase 1 source-review snapshot in this owned directory.

This script reads only the four explicitly authorized original files plus its
own authored extraction/cognition files. It performs no repository or API work.
"""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import runpy
import stat

ROOT = Path('/Users/zhouhuanjian/ASTIS-GC')
OUT = ROOT / '.astis/semantic-neutral-20261110/d_fresh_a6c943'
SOURCE = ROOT / '.astis/huanjian-resume-20261103/2610.20492v1.html'
EXPECTED_BYTES = 951991
EXPECTED_SHA = '6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'

def digest(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data),
            'sha256': hashlib.sha256(data).hexdigest()}

def write_json(path, obj):
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n')

source_bytes = SOURCE.read_bytes()
assert len(source_bytes) == EXPECTED_BYTES
assert hashlib.sha256(source_bytes).hexdigest() == EXPECTED_SHA
source_text = source_bytes.decode('utf-8')
loaded = runpy.run_path(str(OUT / 'extract_source.py'))
nodes, render = loaded['p'].nodes, loaded['render']

def raw_subtree(ident):
    start_pattern = re.compile(
        r'<(?P<tag>[A-Za-z][\w:-]*)\b[^>]*\bid="' + re.escape(ident) + r'"[^>]*>')
    start = start_pattern.search(source_text)
    assert start is not None, ident
    tag = start.group('tag')
    tag_pattern = re.compile(r'</?' + re.escape(tag) + r'\b[^>]*>')
    depth = 0
    end = None
    for match in tag_pattern.finditer(source_text, start.start()):
        if match.group().startswith('</'):
            depth -= 1
        elif not match.group().endswith('/>'):
            depth += 1
        if depth == 0:
            end = match.end()
            break
    assert end is not None
    byte_start = len(source_text[:start.start()].encode('utf-8'))
    byte_end = len(source_text[:end].encode('utf-8'))
    raw = source_bytes[byte_start:byte_end]
    assert raw.decode('utf-8') == source_text[start.start():end]
    return raw, byte_start, byte_end

excerpt_dir = OUT / 'phase1-selected-source'
excerpt_dir.mkdir(exist_ok=True)
snippets = []
for ident in ['abstract1', 'S1', 'S2', 'S4', 'A3', 'bib.bib3']:
    raw, byte_start, byte_end = raw_subtree(ident)
    raw_path = excerpt_dir / (ident + '.raw.html')
    raw_path.write_bytes(raw)
    node = next(n for n in nodes if n.attrs.get('id') == ident)
    rendered = render(node)
    rendered = re.sub(r'[^\S\n]+', ' ', rendered)
    rendered = re.sub(r'\n[ \t]+', '\n', rendered)
    rendered = re.sub(r'\n{3,}', '\n\n', rendered).strip() + '\n'
    text_path = excerpt_dir / (ident + '.math-alttext.txt')
    text_path.write_text(rendered)
    snippets.append({
        'source_anchor': ident,
        'original_file': str(SOURCE),
        'original_byte_range_half_open': [byte_start, byte_end],
        'raw_exact_subtree': digest(raw_path),
        'rendered_derivative': digest(text_path),
        'rendering': 'complete subtree; every MathML math replaced by its full alttext; whitespace normalized; no formula clipping',
    })

originals = [
    ROOT / 'AGENTS.md',
    ROOT / 'docs/proof-digestion-protocol.md',
    ROOT / 'docs/evidence-routed-memory-protocol.md',
    SOURCE,
]
absent_agents = [
    '/AGENTS.md', '/Users/AGENTS.md', '/Users/zhouhuanjian/AGENTS.md',
    str(ROOT / 'docs/AGENTS.md'),
    str(ROOT / '.astis/AGENTS.md'),
    str(ROOT / '.astis/huanjian-resume-20261103/AGENTS.md'),
    str(ROOT / '.astis/semantic-neutral-20261110/AGENTS.md'),
    str(OUT / 'AGENTS.md'),
]

manifest = {
    'schema': 'fresh-source-review-phase1-input-exposure-v1',
    'reviewer_task': '/root/detector_fresh_source',
    'owned_output_directory': str(OUT),
    'scope_authority': 'parent Phase 1 assignment; source reviewer only; no exact candidate supplied',
    'original_content_inputs': [digest(p) for p in originals],
    'original_source_identity': {
        'title': 'On Complexity of Gaussian Sampling',
        'authors': ['Huanjian Zhou', 'Taiji Suzuki'],
        'version': 'arXiv:2610.20492v1',
        **digest(SOURCE),
    },
    'agents_existence_checks_absent': absent_agents,
    'deliberate_complete_source_reading': [
        'abstract1', 'S1 (including S1.SS1)', 'S2',
        'S4 (including S4.SS1, S4.SS2, S4.SS3, S4.SS4)',
        'A3.SS1, A3.SS2, A3.SS3, A3.SS4 (full Appendix C)',
        'title/authors', 'bib.bib3 (displayed [22])',
    ],
    'programmatic_ingestion': {
        'raw_HTML': 'the full pinned file was read to hash and parse; selected complete scopes were deliberately emitted/read',
        'application_original_content_files': 'only the four original files in original_content_inputs',
        'runtime': 'standard Python and standard-library parser/hash/path modules; these are tool machinery, not mathematical project evidence',
    },
    'actual_exposure_events_in_order': [
        {
            'event': 1,
            'action': 'checked the listed ancestor/relevant AGENTS paths; read the sole present repository AGENTS in full',
            'incidental': 'AGENTS includes unrelated scheduling/status/paths/process lessons. No referenced implementation, graph, ledger, plan or review was opened.',
        },
        {
            'event': 2,
            'action': 'parallel read of both authorized protocols plus full-source byte/hash calculation and first 16000 source bytes',
            'incidental': 'combined tool output was truncated; the protocol reading was subsequently repeated separately to ensure full visibility. Source prefix includes page metadata and navigation, not implementation.',
        },
        {
            'event': 3,
            'action': 'read evidence-routed-memory protocol separately; attempted to import bs4 to enumerate source headings',
            'result': 'ModuleNotFoundError: no bs4; no package installed, no network used',
        },
        {
            'event': 4,
            'action': 'standard-library HTMLParser enumerated all h1/h2/h3/h4 source heading titles/IDs',
            'incidental': 'this reveals the paper section titles outside the deliberate scope; not their full contents',
        },
        {
            'event': 5,
            'action': 'authored local extract_source.py; emitted/read full abstract1, S1 and S2 using complete math alttext',
        },
        {
            'event': 6,
            'action': 'emitted/read full S4.SS1 and S4.SS2',
        },
        {
            'event': 7,
            'action': 'emitted/read full S4, followed by repeated S4.SS3 and S4.SS4; no output clipping in that call',
        },
        {
            'event': 8,
            'action': 'emitted/read complete A3.SS1 and A3.SS2',
        },
        {
            'event': 9,
            'action': 'emitted/read complete A3.SS3 and A3.SS4',
        },
        {
            'event': 10,
            'action': 'metadata lookup with overly broad ltx_authors substring match; read proof-digestion protocol again in full',
            'accident': 'substring matched a whole-document container and emitted the full rendered raw article into a truncated tool result (reported original output about 30635 tokens), followed by authors and mistaken bibliography IDs bib.bib22 / bib.bib10 (displayed [19] / [23]). This exposes additional raw-paper portions including S3/A1/A2/bibliography. Not every line of the truncated result was available or fully read.',
            'effect_on_independence': 'no implementation, exact candidate, sourcegraph, old review, decoder or native verdict exposed. All accidental content came from the same permitted pinned paper.',
        },
        {
            'event': 11,
            'action': 'corrected exact class-token metadata lookup; followed the within-S4.SS1 source citation href to bib.bib3, displayed [22]; read title/authors and that bibliography item only',
            'external_followup': 'none; the cited OpenAI preprint was not read or fetched',
        },
        {
            'event': 12,
            'action': 'authored source cognition; generated exact raw selected-subtree copies, full math-alttext derivatives, this manifest and freeze receipt; verified byte ranges against original',
        },
    ],
    'parent_prompt_exposure': {
        'provided': [
            'role and owned output path',
            'fixed paper locator, bytes and SHA',
            'broad source anchors and topics: Eq11, intrinsic statistic/strict event, eigenvector geometry, target coordinate/probability',
            'unverified statement that a focused Lean plus native check passed',
            'staged whitelist and prohibition on candidate/old artifacts',
        ],
        'not_provided_or_read': [
            'exact candidate Lean type or names', 'candidate proof', 'candidate definition bodies',
            'candidate consumer', 'statement seal', 'source-blind decoder output',
            'prior source verdict', 'native verdict content', 'source graph',
            'root process plan', 'other chat transcript',
        ],
        'treatment': 'only scope steering; no candidate correctness inferred from the reported successful checks',
    },
    'prior_knowledge_disclosure': 'General existing mathematical knowledge of real orthogonal linear algebra, polynomial evaluation, Chebyshev polynomials, Gaussian transformations/moments, and probability inequalities. No claim of pretrained ignorance. Source-specific claims here derive from the pinned reading. No search of prior artifacts or external mathematical source was performed.',
    'prohibited_project_content_reads': [],
    'actions_not_performed': [
        'no AutoSamplingTheory, Tests or Mathlib implementation read',
        'no canonical/ledger/frontier mutation', 'no git command or mutation',
        'no API, STAB, network or browser operation', 'no Lean code/proof/check',
        'no graph/plan/lesson/audit/old-review lookup',
        'no PBPS, SPHMC, Bench or ATLAS data opened',
        'no agent delegation',
    ],
    'selected_source_snippets': snippets,
    'verdict_authority': 'NONE: cognition and source-only checklist, not PROVED/sourceV/global/wholeGoal acceptance',
    'next_phase': 'PAUSE; receive only explicit anonymous exact type and source-blind reconstruction whitelist for Phase 2',
}

manifest_path = OUT / 'phase1-input-exposure-manifest.json'
write_json(manifest_path, manifest)

artifacts = [OUT / 'extract_source.py', OUT / 'freeze_phase1.py',
             OUT / 'phase1-source-cognition.md', manifest_path]
artifacts.extend(sorted(excerpt_dir.iterdir()))
receipt = {
    'schema': 'fresh-source-review-phase1-freeze-v1',
    'frozen_at_utc': datetime.now(timezone.utc).isoformat(),
    'source': digest(SOURCE),
    'status': 'PHASE1_FROZEN_AWAITING_PHASE2_WHITELIST',
    'artifacts': [digest(p) for p in artifacts],
    'freeze_policy': 'All listed artifacts and this receipt set to POSIX mode 0444; selected-source directory set to 0555. Parent output directory stays writable for later separately named phase artifacts. Hash changes invalidate this phase freeze.',
    'mathematical_or_source_candidate_acceptance': False,
}
receipt_path = OUT / 'phase1-freeze-receipt.json'
write_json(receipt_path, receipt)
for path in artifacts + [receipt_path]:
    path.chmod(0o444)
excerpt_dir.chmod(0o555)
assert all(stat.S_IMODE(p.stat().st_mode) == 0o444 for p in artifacts + [receipt_path])
assert stat.S_IMODE(excerpt_dir.stat().st_mode) == 0o555
print(json.dumps({
    'receipt': digest(receipt_path),
    'cognition': digest(OUT / 'phase1-source-cognition.md'),
    'input_exposure_manifest': digest(manifest_path),
    'artifact_count_in_receipt': len(artifacts),
    'readonly_files_checked': len(artifacts) + 1,
    'exact_raw_subtree_ranges_checked': len(snippets),
}, ensure_ascii=False, indent=2))
