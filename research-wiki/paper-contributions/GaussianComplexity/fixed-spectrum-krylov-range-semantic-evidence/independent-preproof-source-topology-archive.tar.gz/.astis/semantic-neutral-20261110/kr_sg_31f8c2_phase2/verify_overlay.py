from pathlib import Path
import hashlib,json,stat,datetime
ROOT=Path(__file__).resolve().parent;REPO=ROOT.parents[2];P1=ROOT.with_name('kr_sg_31f8c2')
sha=lambda b:hashlib.sha256(b).hexdigest()
dump=lambda n,x:(ROOT/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
base=json.loads((ROOT/'phase1-baseline.json').read_bytes())
current=[]
for p in sorted([P1]+list(P1.rglob('*'))):
    assert not p.is_symlink();st=p.stat();r={'path':'.' if p==P1 else str(p.relative_to(P1)),'type':'directory' if p.is_dir() else 'file','mode':format(stat.S_IMODE(st.st_mode),'04o'),'mtime_ns':st.st_mtime_ns,'ctime_ns':st.st_ctime_ns,'inode':st.st_ino}
    if p.is_file():
        b=p.read_bytes();r.update(bytes=len(b),sha256=sha(b))
    current.append(r)
changed=[]
old={r['path']:r for r in base['items']};new={r['path']:r for r in current}
for key in sorted(set(old)|set(new)):
    if old.get(key)!=new.get(key):changed.append({'path':key,'before':old.get(key),'after':new.get(key)})
preservation={'checked_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'phase1_root':str(P1),'compared_fields':['path','type','mode','mtime_ns','ctime_ns','inode','bytes','sha256'],'atime_deliberately_not_compared':'Read access may change atime; it is not content or filesystem mutation by this task.','changed':changed,'unchanged_file_count':sum(r['type']=='file' for r in current),'unchanged_directory_count':sum(r['type']=='directory' for r in current),'baseline_snapshot_sha256':sha(json.dumps(base['items'],sort_keys=True).encode()),'final_snapshot_sha256':sha(json.dumps(current,sort_keys=True).encode()),'status':'preserved exactly' if not changed else 'ACTUAL PRESERVATION FAILURE'}
dump('phase1-preservation-final.json',preservation)
assert not changed
assert preservation['unchanged_file_count']==111 and preservation['unchanged_directory_count']==6
packet_path=REPO/'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-krylov-range-semantic-evidence/selective-preproof-types-and-definitions.json'
raw=packet_path.read_bytes();assert raw==(ROOT/'exact-selective-packet.json').read_bytes() and sha(raw)=='471d8f4351d80f33d478049a0a2d8716689b2140c043aa324d8132f9b3fb79cb'
packet=json.loads(raw);seal=(REPO/packet['sealed_statement_file_for_hash_and_signature_fields_only']).read_bytes();assert sha(seal)==packet['sealed_statement_raw_sha256']
selected=json.loads((ROOT/'selected-seal-fields.json').read_bytes())['permitted_fields_only']
source_seal=json.loads(seal)
for key in ['producer','actual_private_consumer']:
    for field,value in selected[key].items():assert source_seal[key][field]==value
for k,item in enumerate(packet['minimal_definitions']):
    b=(REPO/item['file']).read_bytes();assert sha(b)==item['wholefile_raw_sha256']
    raw=b[item['byte_start_inclusive']:item['byte_end_exclusive']]
    assert raw==(ROOT/'canonical-literal-spans'/(str(k)+'.literal.txt')).read_bytes()==item['literal'].encode()
overlay=json.loads((ROOT/'type-source-overlay.json').read_bytes())
graph=json.loads((P1/'source-graph.json').read_bytes());nodeids={x['id'] for x in graph['nodes']}
for root,item in zip(overlay['roots'],packet['lean']):
    assert root['exact_signature']==item['signature'] and sha(root['exact_signature'].encode())==root['exact_signature_sha256']==item['signature_sha256']
    assert set(root['source_root_nodes'])<=nodeids
    assert root['public_hypothesis_audit']['EXCESS']==[]
    for binder in root['binders']:
        assert binder['classification'] in ['SOURCE','STANDING','TYPING','RULED','EXCESS']
        assert set(binder['source_nodes'])<=nodeids
assert len(overlay['roots'][0]['literal_local_definitions'])==7
assert len(overlay['roots'][1]['literal_local_definitions'])==8
assert not overlay['compile_and_review_status']['target_theorem_compiled']
assert not overlay['compile_and_review_status']['sourceV_issued']
assert not overlay['compile_and_review_status']['independent_topology_approval_issued']
for c in (ROOT/'commands').glob('*.receipt.json'):
    rec=json.loads(c.read_bytes());prefix=c.name[:-len('.receipt.json')]
    for stream in ['stdout','stderr']:
        raw=(c.parent/(prefix+'.'+stream)).read_bytes();assert sha(raw)==rec[stream+'_sha256'] and len(raw)==rec[stream+'_bytes']
    for script in rec['script_inputs']:assert sha((REPO/script['path']).read_bytes())==script['sha256']
exposures={'phase2_permitted_model_exposure':['Exact selective packet including two planned signatures,10 canonical literal/header spans and supplied context','Authorized name/planned_file/signature/signature_sha256 only from the core seal','Own frozen Phase1 artifacts and own Phase2 artifacts'],'fullfile_hashing_only':['Full core-seal raw bytes (JSON selected fields only, no other field output)','Supplied pinned Mathlib files raw bytes for wholefile hash and exact specified span/header-context checks'],'target_implementation_read':False,'generic_API_search':False,'other_role_records_read':False,'root_binder_audit_or_plan_or_prior_verdict_displayed':False,'restricted_ATLAS_read':False,'subagents_or_background_ASTIS_started':False,'phase2_failures_observed':[],'phase2_truncations_observed':[],'historical_limits':'Phase1 exposure-and-command-history.json remains frozen and authoritative for earlier truncations, incidental source exposure, and labelled later replays. Phase2 does not erase those limitations.','pretraining':'Ordinary pretrained mathematical knowledge was available; no zero-pretraining or absolute-pristine assertion.','no_completion_claim':'The exact types are planned only. No actual theorem proof/compiled parents/sourceV/topology approval claimed.'}
dump('phase2-exposure-record.json',exposures)
result={'phase1_preserved':True,'phase1_files':111,'phase1_directories':6,'selective_input_and_core_seal_hashes_rechecked':True,'exact_two_signature_hashes_rechecked':True,'canonical_spans_rechecked':10,'source_node_references_checked':True,'all_recorded_command_stream_and_script_hashes_checked':True,'target_presence_without_read':[{'path':x['planned_file'],'exists_now':(REPO/x['planned_file']).exists(),'contents_read':False} for x in packet['lean']],'scope':'structural/exact-input verification only; no mathematical topology approval or sourceV'}
print(json.dumps(result,ensure_ascii=False,indent=2))
