from pathlib import Path
import datetime, gzip, hashlib, json, shutil, subprocess, sys
sys.dont_write_bytecode = True
sys.path.insert(0, 'tools')
import astis_advance as advance
W = Path('.astis/huanjian-gc-fixed-spectrum-exact-means-20261110')
sha = lambda b: hashlib.sha256(b).hexdigest()
def ref(p):
    return {'path': str(p), 'sha256': sha(p.read_bytes()), 'bytes': p.stat().st_size}
def put(p, x):
    assert not p.exists(), p
    p.write_text(json.dumps(x, ensure_ascii=False, indent=2) + '\n')
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == '8bec676ecdade94d82112066d27970bcba4dea8c'
assert not subprocess.check_output(['git', 'status', '--porcelain', '--untracked-files=no']).strip()
receipt = Path('.astis/huanjian-resume-20261103/20261109T170438104607Z-exact-means-literal-statement-type-formation-only-v1.receipt.json')
d = json.loads(receipt.read_bytes())
assert d['exit_code'] == 0 and sha(Path(d['log']).read_bytes()) == d['log_sha256']
leanpath = Path(subprocess.check_output(['elan', 'which', 'lean'], text=True).strip())
version = subprocess.check_output([str(leanpath), '--version'], text=True).strip()
assert '4.33.0' in version and 'd8b18978322de05a8f3dba51ef03cf5461676c17' in version
assert sha(leanpath.read_bytes()) == '1b370cfcbf44e80d1b004ab1b1ab9a4c73951f9f7c242140bcff9bc577576554'
manifest = Path('lake-manifest.json')
assert sha(manifest.read_bytes()) == 'b83ca83b9cf7caa85fa8b023c2ff9a3fb7a7cce7e1c332e810c348535ec49c37'
packages = []
for p in json.loads(manifest.read_bytes())['packages']:
    folder = Path('.lake/packages') / p['name']
    head = subprocess.check_output(['git', '-C', str(folder), 'rev-parse', 'HEAD'], text=True).strip()
    clean = not subprocess.check_output(['git', '-C', str(folder), 'status', '--porcelain', '--untracked-files=no']).strip()
    assert head == p['rev'] and clean, p['name']
    packages.append({'name': p['name'], 'actual_HEAD': head, 'manifest_rev': p['rev'], 'tracked_clean': clean})
raw = Path('.astis/huanjian-resume-20261103/2610.20492v1.html')
assert sha(raw.read_bytes()) == '6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
ledger = Path('runs/substantive_advances.jsonl')
states = advance._replay_advances([json.loads(x) for x in ledger.read_bytes().splitlines()])
assert states['ASTIS-SA-20261110-GaussianComplexityFixedSpectrumGaussianMoments']['state'] == 'VERIFIED'
assert not [k for k, v in states.items() if v['state'] == 'STABILIZING']
context = json.loads((W / 'statement-design-context.json').read_bytes())
baseline = {'observed_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'working_HEAD': '8bec676ecdade94d82112066d27970bcba4dea8c', 'actual_Lean': version,
    'Lean_binary': ref(leanpath), 'manifest': ref(manifest), 'packages': packages,
    'ledger': ref(ledger), 'all_current_SAU_states': states,
    'all_frontier_hashes': {str(p): sha(p.read_bytes()) for p in sorted(Path('research-wiki/frontier-cells').glob('*.json'))},
    'protected_shared_hashes': {p: sha(Path(p).read_bytes()) for p in ['runs/substantive_discoveries.jsonl', 'website/content/graph_memory_index.json', 'website/content/functor_hypergraph.json']},
    'official_main_ref': subprocess.check_output(['git', 'rev-parse', 'origin/main'], text=True).strip(),
    'known_foreign_live_ref': subprocess.check_output(['git', 'rev-parse', 'origin/codex/slc-lsi-coefficient-blocks'], text=True).strip(),
    'actual_latest_fetch_observation': ref(Path('.astis/huanjian-gc-fixed-spectrum-gaussian-moments-20261110/coordination-observation-after-sourceV8bec.json')),
    'foreign_lane_still_occupied_no_transfer': True,
    'preseal_exposure': context['preseal_exposure']}
put(W / 'preproof-baseline.json', baseline)
standard = Path('.astis/huanjian-gc-fixed-spectrum-gaussian-moments-20261110/multivariateGaussian-standard-definition.txt')
assert sha(standard.read_bytes()) == '512ddbd6cb835fbf4bd28967f04a22cb0c0afe42e57036932fbbe27f3a2cf2cd'
copy = W / standard.name
assert not copy.exists()
copy.write_bytes(standard.read_bytes())
producer = (W / 'producer-signature.txt').read_text()
consumer = (W / 'consumer-signature.txt').read_text()
seal = {'schema_version': 1, 'seal_id': 'GC-FIXED-SPECTRUM-EXACT-MEANS-20261110-v1',
    'state': 'EXACT_LITERAL_TYPES_FORMED_INDEPENDENT_SOURCE_TOPOLOGY_ADMISSION_PENDING_NO_PROOF',
    'source': {'title': 'On Complexity of Gaussian Sampling', 'version': 'arXiv2610.20492v1', 'raw': ref(raw),
        'standing_anchors': ['S4.SS1.p1.1', 'S4.E11', 'S4.Thmtheorem5.p1.1'],
        'producer_anchors': context['producer_source'], 'producer_prerequisite_anchors': ['A3.Ex137', 'A3.Ex139', 'A3.Ex140', 'A3.SS3.p4.2', 'A3.Ex144'],
        'consumer_anchors': context['consumer_source'],
        'source_scope': context['scope']},
    'producer': {'name': 'AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumExactMeans.actual_diagonal_gaussian_exact_means',
        'planned_file': context['producer_planned_file'], 'signature': producer, 'signature_sha256': sha(producer.encode()),
        'definition_kind': 'literal', 'outputs': ['Actual norm/Q integrability', 'Actual closed C8 norm-square mean', 'Actual signed closed C8 cosine-quadratic mean'],
        'public_ASTIS_parents': 'Not claimed before actual proof inspection; canonical GaussianMoments/C7/GridAlias are available substrates, not public hypotheses.'},
    'actual_private_consumer': {'name': 'actual_gaussian_closed_means_bias_ratio',
        'planned_file': context['consumer_planned_file'], 'signature': consumer, 'signature_sha256': sha(consumer.encode()),
        'definition_kind': 'literal',
        'actual_use_required': 'Materially consume BOTH new actual closed mean equalities, on the literal Gaussian measure, to produce positive actual norm mean, its d/sqrt(kappa) upper bound, signed quadratic positivity and the exact normalized absolute-bias ratio. No free m/b symbols, moment certificates, r-range/positivity/summability/denominator witnesses, variance condition, d-n>=sqrt(kappa), oddness or query relation as hypotheses. No #check/wrapper consumer.',
        'expected_public_ASTIS_parents': 'New exact means producer; actual sets only after compiled proof inspection.'},
    'binder_audit': [
        {'binder': 'producer and consumer d:Nat', 'class': 'TYPING', 'reason': 'Finite real Euclidean dimension carrier.'},
        {'binder': 'producer and consumer hd:2<=d', 'class': 'STANDING', 'reason': 'Literal hard-family domain at S4.SS1.p1.1.'},
        {'binder': 'producer and consumer kappa:Real', 'class': 'TYPING', 'reason': 'Real condition parameter carrier.'},
        {'binder': 'producer and consumer hkappa:2<=kappa', 'class': 'STANDING', 'reason': 'Literal hard-family and Lemma4.5 domain.'},
        {'binder': 'producer and consumer n:Nat', 'class': 'TYPING', 'reason': 'Positive integer source mode represented with exact bounds.'},
        {'binder': 'producer and consumer hn:1<=n', 'class': 'SOURCE', 'reason': 'Exact C8/Lemma4.5 positive-mode lower bound.'},
        {'binder': 'producer and consumer hnd:n<d', 'class': 'SOURCE', 'reason': 'Exact C8/Lemma4.5 strict upper mode bound; no asymptotic/query or bias-gap premise.'}],
    'EXCESS_binders': [],
    'definition_audit': [
        {'object': 'theta/eigenvalue/Lambda', 'kind': 'literal', 'meaning': 'Exact source midpoint grid and diagonal precision; Fin i.val+1 is source one-based index.'},
        {'object': 'mu', 'kind': 'literal', 'meaning': 'Existing actual multivariateGaussian0 Lambda inverse on EuclideanSpace Real (Fin d). Its argument is covariance Lambda inverse; precision is Lambda. Standard covariance-square-root map; no new constructor/fallback or arbitrary law.', 'standard_definition': ref(copy)},
        {'object': 'norm squared and Q', 'kind': 'literal', 'meaning': 'Actual Euclidean norm squared and finite cosine diagonal quadratic form, not deterministic sums by definition. Integrability is produced; coordinate/matrix correspondence uses the already audited canonical Euclidean/diagonal meaning.'},
        {'object': 'r', 'kind': 'literal', 'meaning': 'Exact (sqrt(kappa)-1)/(sqrt(kappa)+1). Its strict interval, normalization and every denominator/series fact are internal proof obligations, not input witnesses.'},
        {'object': 'closed powers and divisions', 'kind': 'literal', 'meaning': 'All powers shown are Nat powers. Source n<d internally implies d-n and2*d-n equal the intended positive integer differences; no truncation can be used without discharge. Standard real divisions; denominators/positive m must be proved internally.'},
        {'object': 'consumer m,b', 'kind': 'literal', 'meaning': 'Actual Gaussian Bochner integrals of norm squared and Q. They are not set equal to the desired formulas. The absolute-bias ratio is |b|/m for these actual integrals.'}],
    'internal_dependencies_not_premises': ['Actual Gaussian integrability/expectation-to-grid bridge from canonical GaussianMoments',
        'Source r interval and nonzero/positive square-root, geometric and moment denominators',
        'C7 normalization and genuine finite-grid/series interchange',
        'All signed alias cases, supported-class selection and positive-mode reindexing',
        'Unweighted multiple-of2d tail resummation',
        'Weighted j=n, j=2ad+n and j=2ad-n classes, their disjointness and parity',
        'All convergent geometric tails and subtraction/exponent arithmetic',
        'Actual m positivity/upper bound, signed b positivity and normalized absolute ratio'],
    'shared_floor_audit': {'searched_before_seal': ['Samplinglib/ASTIS current FixedSpectrum declaration-name inventory and already reviewed GaussianMoments/C7/GridAlias exact interfaces',
        'Actual origin/main3c31 FixedSpectrum public-declaration inventory (no matching entries in that path slice)',
        'Pinned Mathlib geometric/Chebyshev/infinite-sum filename inventory only; no new tail/residue proof/API contents read'],
        'classification': 'provisional-adapt', 'decision': 'Reuse identical canonical declarations when found after independent admission; no duplicate wrapper. A genuinely missing reusable generic leaf with multiple real consumers requires the shared-cell protocol.',
        'candidate_reuse': ['FixedSpectrumGaussianMoments.actual_diagonal_gaussian_quadratic_means', 'FixedSpectrumCosineExpansion.actual_inverse_spectrum_cosine_expansion', 'FixedSpectrumGridAlias.actual_midpoint_grid_cosine_alias']},
    'statement_formation': {'actual_receipt': ref(receipt), 'actual_exit_code': 0,
        'proof_credit': False, 'warning_scope': 'Unused proof binders in Prop-valued formation definitions only; no theorem proof.'},
    'preseal_exposure': context['preseal_exposure'] + ' Root also reread the raw author closed-sum/ratio formulas and source proof paragraphs to pin exact anchors; this is disclosed source-background exposure, not zero exposure.',
    'coordination_boundary': context['coordination'],
    'truth_boundary': 'Only actual closed FactC8 mean formulas and a genuine actual Gaussian sign/normalization consumer. Fourth moments, independence/variances, logarithmic/exponential bias bounds, orthogonal/Krylov/adaptive/output laws, exact oracle/TV/precision/deterministic-cap/expected-cost adapters and both full main lower bounds remain open. Shared integration/website/remote/purification/wholeGoal remain separate.',
    'roles': 'Root sole mathematical worker. Independent raw-first source graph and distinct topology/binder/definition challenge must admit exact seal before new target proof/API retrieval.',
    'new_SAU_claim_proof_or_sourceV': False}
put(W / 'statement-seal-v1.json', seal)
formation = W / 'StatementFormation.lean'
archive = W / 'StatementFormation.lean.gz'
assert not archive.exists()
archive.write_bytes(gzip.compress(formation.read_bytes(), mtime=0))
formation.unlink()
print(json.dumps({'seal_sha256': sha((W / 'statement-seal-v1.json').read_bytes()),
    'producer_signature_sha256': seal['producer']['signature_sha256'],
    'consumer_signature_sha256': seal['actual_private_consumer']['signature_sha256'],
    'existing_SAU_states_preserved': len(states), 'existing_frontier_raw_files': len(baseline['all_frontier_hashes']),
    'Lean': version, 'packages_verified': len(packages), 'new_target_proof_or_API_search': False}))
