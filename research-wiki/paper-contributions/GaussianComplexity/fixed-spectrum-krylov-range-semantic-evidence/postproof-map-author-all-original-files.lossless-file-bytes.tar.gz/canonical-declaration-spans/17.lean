theorem eval_C : (C a).eval x = a :=
  eval₂_C _ _
