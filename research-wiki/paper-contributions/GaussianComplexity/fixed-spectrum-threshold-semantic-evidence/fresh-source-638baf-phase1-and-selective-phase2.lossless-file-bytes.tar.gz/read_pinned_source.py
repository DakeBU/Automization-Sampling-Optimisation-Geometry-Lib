from pathlib import Path
from html.parser import HTMLParser
import hashlib
import json
import re

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT.parents[1] / 'huanjian-resume-20261103/2610.20492v1.html'
EXPECTED = '6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'

class Index(HTMLParser):
    VOID = {'area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr'}
    def __init__(self, text):
        super().__init__(convert_charrefs=False)
        self.text = text
        self.lines = [0] + [m.end() for m in re.finditer('\n', text)]
        self.stack = []
        self.entries = {}
        self.feed(text)
    def char_offset(self):
        line, col = self.getpos()
        return self.lines[line - 1] + col
    def handle_starttag(self, tag, attrs):
        ident = dict(attrs).get('id')
        begin = self.char_offset()
        if tag in self.VOID:
            if ident: self.entries[ident] = (begin, begin + len(self.get_starttag_text()))
        else:
            self.stack.append((tag, ident, begin))
    def handle_startendtag(self, tag, attrs):
        ident = dict(attrs).get('id')
        if ident:
            begin = self.char_offset()
            self.entries[ident] = (begin, begin + len(self.get_starttag_text()))
    def handle_endtag(self, tag):
        for i in range(len(self.stack) - 1, -1, -1):
            if self.stack[i][0] == tag:
                finish = self.text.index('>', self.char_offset()) + 1
                for _, ident, begin in self.stack[i:]:
                    if ident: self.entries[ident] = (begin, finish)
                del self.stack[i:]
                return

class Plain(HTMLParser):
    def __init__(self, raw):
        super().__init__(convert_charrefs=True)
        self.out = []
        self.math = 0
        self.feed(raw)
    def handle_starttag(self, tag, attrs):
        if tag == 'math':
            self.math += 1
            if self.math == 1: self.out.append(' $' + dict(attrs).get('alttext', '') + '$ ')
        elif not self.math and tag in {'p','h2','h3','h4','h5','h6','tr','li'}:
            ident = dict(attrs).get('id')
            self.out.append('\n' + ('[' + ident + '] ' if ident else ''))
    def handle_endtag(self, tag):
        if tag == 'math': self.math -= 1
        elif not self.math and tag in {'p','h2','h3','h4','h5','h6','tr','li'}: self.out.append('\n')
    def handle_data(self, data):
        if not self.math: self.out.append(data)
    def text(self):
        return re.sub(r'\n\s*\n+', '\n\n', ''.join(self.out)).strip()

def load():
    data = SOURCE.read_bytes()
    digest = hashlib.sha256(data).hexdigest()
    assert digest == EXPECTED, digest
    text = data.decode('utf-8')
    return data, text, Index(text)

if __name__ == '__main__':
    import sys
    data, text, index = load()
    for ident in sys.argv[1:]:
        start, end = index.entries[ident]
        print('\nELEMENT', ident)
        print(Plain(text[start:end]).text())
