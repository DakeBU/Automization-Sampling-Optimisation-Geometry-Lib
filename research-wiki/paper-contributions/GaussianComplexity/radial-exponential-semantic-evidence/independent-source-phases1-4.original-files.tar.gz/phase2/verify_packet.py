"""Recheck the selectively exposed packet and its exact embedded literals."""

import hashlib
import json
from pathlib import Path


PACKET = Path(".astis/huanjian-gc-radial-exponential-20261110/selective-type-definition-packet.json")
EXPECTED_SHA256 = "44cecb47245a0d1ab06d634f8b1dcd408c8368437e37cea1f0bde46fc2669ae3"


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def verify_literal(label: str, literal: str, expected: str) -> bytes:
    raw = literal.encode("utf-8")
    actual = sha256(raw)
    if actual != expected or not raw.endswith(b"\n"):
        raise ValueError(f"Literal mismatch for {label}: {actual}")
    print(f"{label} sha256={actual} bytes={len(raw)}")
    return raw


def main() -> None:
    raw_packet = PACKET.read_bytes()
    actual = sha256(raw_packet)
    if actual != EXPECTED_SHA256:
        raise ValueError(f"Packet pin mismatch: {actual}")
    print(f"packet={PACKET} sha256={actual}")
    packet = json.loads(raw_packet)
    for key in ("producer", "private_consumer"):
        entry = packet[key]
        verify_literal(entry["name"], entry["signature"], entry["signature_sha256"])

    definitions = packet["minimal_definition_context"]["definitions"]
    if len(definitions) != 11:
        raise ValueError(f"Unexpected definition count: {len(definitions)}")
    for entry in definitions:
        literal = entry["literalLF"]
        data = verify_literal(entry["name"], literal, entry["literal_sha256"])
        char_start, char_end = entry["character_span_0based_halfopen"]
        byte_start, byte_end = entry["utf8_byte_span_0based_halfopen"]
        line_start, line_end = entry["lf_lines_1based_inclusive"]
        if (len(literal), len(data), data.count(b"\n")) != (
            char_end - char_start,
            byte_end - byte_start,
            line_end - line_start + 1,
        ):
            raise ValueError(f"Span length mismatch for {entry['name']}")
    print("Both exact signature literals and all eleven definition literals matched.")


if __name__ == "__main__":
    main()
