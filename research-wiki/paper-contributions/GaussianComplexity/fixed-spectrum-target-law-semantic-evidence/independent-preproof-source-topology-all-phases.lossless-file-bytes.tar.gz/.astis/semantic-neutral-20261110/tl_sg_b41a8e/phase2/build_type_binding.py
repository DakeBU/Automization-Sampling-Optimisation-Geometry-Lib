"""Bounded source/type verdict; no target implementation or proof/API search."""
from pathlib import Path
from copy import deepcopy
import hashlib,json

REPO=Path('/Users/zhouhuanjian/ASTIS-GC')
OWN=Path(__file__).parent;P1=OWN.parent
sha=lambda b:hashlib.sha256(b).hexdigest()
def dump(name,data):(OWN/name).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
payloadp=REPO/'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-target-law-semantic-evidence/preproof-types-and-definitions-selective.json'
pb=payloadp.read_bytes();assert sha(pb)=='ec350a9cfb9bbc0658fd9884d507a74114a3eb5ac0cedebddc22b2a0ae750415'
p=json.loads(pb)
typeinfo=[]
for key,out in [('producer','producer-signature.txt'),('private_consumer','consumer-signature.txt')]:
 b=p[key]['signature'].encode();assert sha(b)==p[key]['signature_sha256'];(OWN/'exact_types'/out).write_bytes(b)
 typeinfo.append({'owner':key,'name':p[key]['name'],'signature_file':'exact_types/'+out,'sha256':sha(b)})
defs=[]
for d in p['definition_semantics_audit']:
 ep=REPO/d['excerpt_path'];eb=ep.read_bytes();assert sha(eb)==d['excerpt_sha256']
 fp=REPO/d['file'];fb=fp.read_bytes();assert sha(fb)==d['whole_file_sha256']
 block=b''.join(fb.splitlines(keepends=True)[d['first']-1:d['last']]);assert block==eb
 fn='definition_blocks/'+ep.name;(OWN/fn).write_bytes(block)
 defs.append({'symbol':d['name'],'excerpt_path':d['excerpt_path'],'excerpt_sha256':sha(eb),
  'actual_file':d['file'],'actual_file_sha256':sha(fb),'first':d['first'],'last':d['last'],
  'copied_block':fn,'block_sha256':sha(block),'authority':'Necessary literal definition only; no theorem proof imported.'})
dump('definition_context_index.json',defs)

sourcev1b=(P1/'source_root_map.json').read_bytes();assert sha(sourcev1b)=='5c433ebe49be188db05bad6c91dac3903a5767539ee18939e36860d1cabac1df'
sourcev1=json.loads(sourcev1b);sourcev2=deepcopy(sourcev1)
newroot={'id':'tl:target-norm-sum','source_nodes':['sg:target-coordinate-transfer','bg:C3-means'],
 'anchors':['S4.SS2.SSS0.Px3.p2.1 last sentence','A3.SS3.p4 / Ex140 first equality'],
 'output':'Under the actual fixed-O target, finite E||Y||^2=sum_i 1/lambda_i.',
 'scope':'Norm-only finite-sum component; integrability is necessary expectation well-definedness supplied by Gaussian second-moment background, not an extra public premise. No closed-M/cosine/variance/bias conclusion.'}
newedge={'id':'tl:e-target-norm-sum','logic':'AND',
 'premises':['tl:fixed-O-law','tl:bg-norm-isometry','tl:latent-norm-sum','tl:bg-expectation-transport'],
 'consumer':'tl:target-norm-sum','consumer_use_site':'S4.SS2.SSS0.Px3.p2.1 last sentence, using A3.SS3.p4 first M equality',
 'consumed_outputs':'Actual target/latent law, all-vector norm identity, finite latent second-moment norm sum, and measurable/integrable expectation transport. Closed-M summation is not a premise.'}
newlinks=[
 {'producer':'tl:fixed-O-law','consumer':'tl:target-norm-sum','edge':'tl:e-target-norm-sum','consumed_output':'Actual target measure equals the rotated latent Gaussian law.'},
 {'producer':'tl:bg-norm-isometry','consumer':'tl:target-norm-sum','edge':'tl:e-target-norm-sum','consumed_output':'Norm square unchanged by the same O on the entire vector carrier.'},
 {'producer':'tl:latent-norm-sum','consumer':'tl:target-norm-sum','edge':'tl:e-target-norm-sum','consumed_output':'Finite norm expectation sum_i 1/lambda_i; only second moments, no fourth moments.'},
 {'producer':'tl:bg-expectation-transport','consumer':'tl:target-norm-sum','edge':'tl:e-target-norm-sum','consumed_output':'Transfer integrability and the real integral through the actual measurable law map.'}]
sourcev2['status']='SOURCE_OUTPUT_SELECTOR_SUCCESSOR_AFTER_EXACT_TYPE_EXPOSURE_NO_PROOF'
sourcev2['selected_source_roots'].append(newroot)
sourcev2['source_use_hyperedges'].append(newedge)
sourcev2['consumer_use_backlinks'].extend(newlinks)
dump('source_root_map_v2.json',sourcev2)
ops=[{'op':'replace','path':'/status','value':sourcev2['status']},
 {'op':'add','path':'/selected_source_roots/-','value':newroot},
 {'op':'add','path':'/source_use_hyperedges/-','value':newedge}]
ops.extend({'op':'add','path':'/consumer_use_backlinks/-','value':z} for z in newlinks)
dump('exact_source_selector_delta.json',{
 'base_file':'../source_root_map.json','base_sha256':sha(sourcev1b),
 'successor_file':'source_root_map_v2.json','successor_sha256':sha((OWN/'source_root_map_v2.json').read_bytes()),
 'operations':ops,
 'why':'The exact private consumer asks for a finite inverse-eigenvalue norm mean, so select the source p4 norm-sum output independently of the already retained p5 closed-M output. No old source graph/coverage is rewritten.',
 'full_author_graph_unchanged_sha256':'a3d876092b9854614c6d09bba8f1fa4add8d772ba030fa2358526b9c55ac6449',
 'independent_rereview':'PENDING','proof_credit':False})

audit=[]
for owner in ['producer','private_consumer']:
 for binder,kind,reason in [
  ('d : Nat','TYPING','Natural finite dimension carrier.'),
  ('hd : 2 <= d','SOURCE','Eq.(11) hard-family domain, retained by this auxiliary component.'),
  ('kappa : Real','TYPING','Real construction parameter carrier.'),
  ('hkappa : 2 <= kappa','SOURCE','Eq.(11) hard-family parameter range; positivity/inverse facts are internal ingredients.'),
  ('O : Matrix.orthogonalGroup (Fin d) Real','SOURCE','The source hard eigenbasis is a full real orthogonal matrix; the selected identities are at each fixed O, with no det=1 or random-law condition.')]:
  audit.append({'owner':owner,'binder':binder,'class':kind,'independent_reason':reason})
dump('independent_binder_audit.json',{'items':audit,'EXCESS':[],
 'local_lets':'theta,Lambda,A,R,mu are literal definitions, not caller-supplied result certificates.',
 'output_not_binder':['Gaussian measure equality','Integrable norm square','real norm integral equality'],
 'source_hypothesis_vs_ingredient':'No positivity, invertibility, map law, measurability, integrability or moment estimate may be added as a new public premise.'})

binding={
 'status':'EXACT_TYPE_TO_SOURCE_COMPONENT_MAPPING_ONLY','exact_types':typeinfo,
 'producer':{'source_root':'tl:fixed-O-law','source_node':'sg:target-coordinate-transfer',
  'source_anchor':'S4.SS2.SSS0.Px3.p2.1','actual_statement':'Map of actual latent Mathlib Gaussian under the same forward O equals actual target Mathlib Gaussian at A inverse.',
  'source_adapter':'The paper writes U=O^T Y and its latent Gaussian law. The producer is the equivalent forward fixed-O law formulation after inverse/conjugation and Gaussian law recognition.',
  'unproved_background':['tl:bg-Gaussian-linear-law','tl:bg-inverse-conjugation','proper covariance/constructor-to-source law recognition','linear rotation measurability'],
  'not_a_claim':['No Haar/joint conditional kernel','No algorithm law','No probability estimate','No observed code call']},
 'consumer':{'source_root':'tl:target-norm-sum','source_nodes':['sg:target-coordinate-transfer','bg:C3-means'],
  'source_anchors':['S4.SS2.SSS0.Px3.p2.1 last sentence','A3.SS3.p4.1 / A3.Ex140 first equality'],
  'left_conjunct':'Integrable (norm squared) under the ACTUAL target Gaussian with covariance A inverse.',
  'left_source_relation':'Finite Gaussian second moments are an implicit well-definedness ingredient of the source norm expectation, not a separately printed Integrable theorem and not a caller premise.',
  'right_conjunct':'Real target norm-square integral equals finite sum of REAL scalar reciprocal eigenvalues.',
  'source_suboutput':'M=E||U||^2=sum_i 1/lambda_i only; not C.3.p5 closed finite-grid M formula, cosine mean, variance or bias.',
  'semantic_producer_use':'Rewrite target measure via the actual producer law equality, transport norm-square integrability and integral through the measurable rotation, use pointwise orthogonal norm identity and latent second-moment norm sum.',
  'implementation_use':'UNOBSERVED: signatures permit a genuine semantic consumption; no proof body/call/test reachability was read.'},
 'quantifier_adapter':{'d_kappa':'Both exact types retain d>=2,kappa>=2 from the hard family.',
  'O':'Both are universal over each fixed full O(d), including determinant -1; source Haar/private seed independence is neither a binder nor a conclusion.',
  'n':'No n binder is needed for this extracted norm-only p4 component: the written p4 norm-sum calculation is independent of n. The 1<=n<d wrapper and d-n>=sqrt(kappa) bias condition remain on the sibling joint source lemma, not transplanted to this helper.',
  'scope':'No delta,q,C,tau,epsilon,TV,query or cost condition is introduced or discharged.'},
 'definition_semantics':[
  {'object':'theta','mapping':'Fin d index i corresponds to source j=i.val+1; (i.val+1/2)pi/d matches (j-1/2)pi/d.'},
  {'object':'Lambda,A','mapping':'Literal precision matrices: Lambda diagonal affine cosine eigenvalues, A=O Lambda O^T with the same full O.'},
  {'object':'Lambda inverse,A inverse','mapping':'MATRIX inverses used as covariances; must have source positive-definite meaning. They are not real reciprocal entries by notation alone.'},
  {'object':'scalar mean terms','mapping':'Each RHS inverse is a REAL scalar eigenvalue reciprocal, matching 1/lambda_i in Ex140.'},
  {'object':'R','mapping':'Actual WithLp-coordinate matvec by forward O; source backward coordinate map uses O^T. Isometry and measurability are internal mathematical ingredients.'},
  {'object':'multivariateGaussian','mapping':'Actual constructor is stdGaussian mapped by mean plus covariance CFC.sqrt. Its documented non-PSD fallback is Dirac. Source positivity must select the proper positive covariance branch internally; definition name alone is not a law certificate.'},
  {'object':'Integrable and real integral','mapping':'Two substantive outputs: L1 norm-square integrability and its real integral. The integrability output prevents interpreting a totalized nonintegrable integral as the intended finite source mean.'}],
 'zero_and_denominators':'No nonzero-vector binder or division by vector norm. d>0,lambda_i>0,kappa>=2 give meaningful source matrix covariances/scalar inverse mean; all positivity facts are proof ingredients, not added public assumptions.',
 'unclaimed':['Exact closed M=(d/sqrt(kappa))*(1-varrho^(2d))/(1+varrho^(2d))','Cosine statistic mean or variance','Normalized bias and its gap condition','Target detector event/high acceptance','Concentration C, Haar/adaptive/Krylov experiment, algorithm rejection','TV, precision/cost, minimax/full lower bound','Compiler proof, native/sourceV/STAB/publication/wholeGoal'],
 'supplied_audit_boundary':'The payload already contains audits. This separate classification was made from its exact signatures, the literal definition blocks and frozen raw source, and is not proof acceptance.'}
dump('target_binding.json',binding)

overlay={
 'kind':'TYPE_SPECIFICATION_OVERLAY_SEPARATE_FROM_SOURCE_GRAPH','source_successor':'source_root_map_v2.json',
 'source_successor_sha256':sha((OWN/'source_root_map_v2.json').read_bytes()),
 'compiler_implementation_graph':None,
 'nodes':[
  {'id':'type:law-producer','source':'tl:fixed-O-law','signature_sha256':typeinfo[0]['sha256'],'output':'Actual Gaussian MEASURE equality','proof_status':'UNOBSERVED'},
  {'id':'type:proper-covariance','kind':'BACKGROUND_OBLIGATION','inputs':['source positive eigenvalues','orthogonal conjugation/inverse algebra','actual Gaussian constructor characterization'],'output':'Lambda inverse and A inverse have intended proper Gaussian covariance meanings','not_public_hypothesis':True},
  {'id':'type:R-measurable-isometry','kind':'BACKGROUND_OBLIGATION','inputs':['same fixed full O','literal Euclidean/WithLp matvec'],'outputs':['R measurable','norm(R z)^2=norm(z)^2 for all z'],'not_public_hypothesis':True},
  {'id':'type:latent-L1-sum','source':'tl:latent-norm-sum','background':'tl:bg-Gaussian-second-moment','outputs':['latent norm-square Integrable','latent real integral=sum_i 1/lambda_i'],'proof_status':'UNOBSERVED'},
  {'id':'type:target-L1','source':'tl:target-norm-sum','output':'consumer left Integrable conjunct','proof_status':'UNOBSERVED'},
  {'id':'type:target-mean','source':'tl:target-norm-sum','output':'consumer right real finite-sum mean conjunct','proof_status':'UNOBSERVED'},
  {'id':'type:consumer-root','signature_sha256':typeinfo[1]['sha256'],'output':'target L1 AND finite-sum norm mean','source_anchor':False,'proof_status':'UNOBSERVED'}],
 'semantic_use_edges':[
  {'id':'type:e-law','logic':'AND','premises':['tl:fixed-O-law','type:proper-covariance'],'consumer':'type:law-producer','use':'Bind actual constructors to the source fixed-O Gaussian law; general rule remains unproved background.'},
  {'id':'type:e-L1','logic':'AND','premises':['type:law-producer','type:R-measurable-isometry','type:latent-L1-sum','tl:bg-expectation-transport'],'consumer':'type:target-L1','use':'Use actual measure equality and norm-square pullback to transfer latent integrability. No Integrable premise is supplied by caller.'},
  {'id':'type:e-mean','logic':'AND','premises':['type:law-producer','type:R-measurable-isometry','type:latent-L1-sum','tl:bg-expectation-transport'],'consumer':'type:target-mean','use':'Use actual measure equality and norm-square pullback plus the latent real integral=sum inverse spectrum.'},
  {'id':'type:e-root','logic':'AND','premises':['type:target-L1','type:target-mean'],'consumer':'type:consumer-root','use':'Both substantive exact outputs required; not an OR proof.'}],
 'producer_consumer_use_backlinks':[
  {'producer':'type:law-producer','consumer':'type:target-L1','edge':'type:e-L1','output_consumed':'Actual target measure identification for integrability transport.'},
  {'producer':'type:law-producer','consumer':'type:target-mean','edge':'type:e-mean','output_consumed':'Actual target measure identification for real expectation transport.'}],
 'scope':'Possible genuine semantic use following the source coordinate route. No assertion that every proof needs this route or that compiled code has made these calls.',
 'standard_input_boundary':'All Gaussian law, positive covariance, inverse algebra, measurability, integrability and real expectation-transfer obligations remain obligations; no source premise or Lean proof credit.'}
dump('type_semantic_use_overlay.json',overlay)

covb=(P1/'coverage_checkpoint.json').read_bytes();assert sha(covb)=='d473ec821c3c489d204e908400149b5472f729dd490ec951a90a051f3c9da667'
cov=json.loads(covb);alignment=[]
selected={'sg:grid11','sg:hard-rotation','sg:target-coordinate-transfer','bg:C3-means','bg:C4-spectrum'}
mixed={'sg:target-moments','bg:C4-normalizer'}
for r in cov['items']:
 alignment.append({'source_id':r['source_id'],'byte_start_inclusive':r['byte_start_inclusive'],'byte_end_exclusive':r['byte_end_exclusive'],'raw_sha256':r['raw_sha256'],
  'unchanged_disposition':r['disposition'],'unchanged_node':r.get('node'),'unchanged_exclusion_reason':r.get('reason'),
  'exact_type_scope_role':'Explicit inherited exclusion' if r['disposition']=='EXCLUDED' else 'Selected source law/norm-sum support; consume only named output' if r['node'] in selected
    else 'Mixed source region: selected mean/target-law statement only; other outputs preserved outside exact type' if r['node'] in mixed
    else 'Preserved substantive context/sibling, outside exact finite-sum norm component; no erased coverage'})
dump('coverage_alignment.json',{'base_coverage_sha256':sha(covb),'base_coverage_file':'../coverage_checkpoint.json',
 'all_original_regions_preserved':True,'items':alignment,
 'source_gap_alignment':[{'id':g['id'],'classification':g['classification'],'consumer_use_site':g['use_site'],'status':'UNCHANGED_UNPROVED_BACKGROUND'} for g in json.loads((P1/'standard_background_and_gaps.json').read_text())],
 'additional_type_boundary':'Proper-covariance/actual-constructor recognition is a library semantic obligation, not a newly printed paper paragraph or caller assumption.',
 'authority':'Alignment checkpoint, not independent coverage approval or proof count.'})

verdict={
 'state':'INDEPENDENT_SOURCE_TYPE_MATHEMATICAL_VERDICT_FROZEN_PENDING_TOPOLOGY_CHALLENGE',
 'verdict':'ACCEPT_BOUNDED_SOURCE_COMPONENT_SPECIFICATIONS_WITH_UNPROVED_BACKGROUND',
 'producer_statement':'Matches fixed full-O actual target law component, as a forward formulation of the printed backward coordinate law.',
 'consumer_statement':'Matches n-independent finite inverse-spectrum norm mean with its necessary integrability output; is a private component, not the full Lemma4.5.',
 'binders':'All ten classified SOURCE/TYPING; no EXCESS input found in these literal signatures.',
 'M_only_judgment':'No n or bias-gap binder is required for the selected p4 norm component; exact consumer does not claim the p5 closed formula.',
 'genuine_semantic_consumer':'Producer measure equality can supply both consumer conjuncts through actual-law integrability/mean transport and norm isometry; compiled consumption UNOBSERVED.',
 'proper_covariance':'Source positive spectrum must justify actual inverse covariances internally; no Dirac fallback may be used as a substitute for the source Gaussian branch.',
 'standard_background':'General Gaussian linear law, inverse/conjugation, constructor law recognition, measurability, finite second moments and expectation transport remain explicitly unproved/source-gap inputs, not extra public assumptions.',
 'no_mathematical_proof_credit':True,'no_implementation_compiler_proof_seen':True,
 'source_coverage_status':'All frozen selected source regions/dispositions preserved; new component selection and GAP alignment exported. Independent topology review pending.',
 'unchanged':['old full v1/v2 source graphs','all old coverage bytes','new packet raw phase1 freeze','all previous role evidence'],
 'not_read':['canonical full seal','root reuse/proof/control/process plans','old/new topology verdicts or grants','new target implementation/API route'],
 'process_qualification':'NOT_ASSESSED; requires later separately authorized process-only phase after this mathematical freeze.'}
dump('mathematical_source_type_verdict.json',verdict)

ex={'phase':'NEW_PACKET_PHASE2_SOURCE_TYPE_ONLY','actor_not_fresh':True,
 'new_inputs':[{'path':str(payloadp.relative_to(REPO)),'bytes':len(pb),'sha256':sha(pb)}],
 'necessary_definition_blocks':defs,'actual_lines_semantically_read_only':True,
 'new_neighboring_proof_API_exposure':False,
 'own_source_inputs':['../phase1_manifest.json','../source_root_map.json','../coverage_checkpoint.json','../standard_background_and_gaps.json','../selected_snippets/*.html'],
 'prior_exposure':'Retained exactly as phase1 actual_inputs_and_prior_exposure.json; not forgotten or recast as new source evidence.',
 'supplied_audits':'Selective payload contains binder/definition audit assertions; recorded as exposure and checked independently against literal signatures/source.',
 'canonical_full_seal_sha_known_not_opened':'a8b81776536741394f2e163d041f9b19f463c573759aa52dc7e6397b26065ccb',
 'forbidden_not_read':['full seal containing root process/plan','foreign cognition/review/verdict/grants','root implementation/API/reuse plan','target Lean/Tests'],
 'no_operations':['No proof/API search or compiler experiment','No SAU/V/STAB/global/frontier mutation'],
 'next_action':'Freeze mathematical judgement/exposure and pause before any process-only history/control review.'}
dump('actual_inputs_and_exposure.json',ex)
dump('topology_reviewer_packet.json',{
 'purpose':'Different-actor source/type topology challenge; no process history or implementation proof.',
 'read_whitelist':['../selected_snippets/index.json','../selected_snippets/*.html','../coverage_checkpoint.json','../standard_background_and_gaps.json','../source_root_map.json','source_root_map_v2.json','exact_source_selector_delta.json','exact_types/*.txt','definition_context_index.json','definition_blocks/*.txt','independent_binder_audit.json','target_binding.json','type_semantic_use_overlay.json','coverage_alignment.json'],
 'base_full_source_graph':'.astis/semantic-neutral-20261110/d_sg_48e2c0/phase2c_tc_b1_successor/source_graph_v2.json',
 'base_full_source_graph_sha256':'a3d876092b9854614c6d09bba8f1fa4add8d772ba030fa2358526b9c55ac6449',
 'withhold':['raw source cognition','prior/private exposure and process notes','mathematical_source_type_verdict.json until independent judgement','selective payload audit metadata','canonical full seal','old/new verdict/grants','implementation/API/proof material'],
 'challenge':['Fixed full O law direction and actual constructor/positive covariance boundary','M-only n-free scope at p4 rather than whole joint lemma or p5 closed formula','Integrability as output and expectation-transport ingredient, not caller premise','Genuine possible producer use for both conjuncts, without claiming implementation call','All selected NODE/EXCLUDED/GAP coverage preserved and all unproved background visible'],
 'status':'PENDING_INDEPENDENT_CHALLENGE','proof_credit':False})

# Integrity only: preserve raw checkpoint and reconstruct the exact local selector delta.
mf=json.loads((P1/'phase1_manifest.json').read_text());assert sha((P1/'phase1_manifest.json').read_bytes())=='d610a5424dcf5106393e735c793c7a8ae41a1844038e7506a1043addaaca58dd'
for f in mf['files']:assert sha((P1/f['file']).read_bytes())==f['sha256']
assert len(alignment)==len(cov['items'])
dump('artifact_integrity_checks.json',{'raw_phase1_manifest_all_files_unchanged':True,'selective_payload_and_two_definition_hashes_matched':True,
 'definition_excerpts_equal_actual_exact_lines':True,'signature_copies_match_supplied_digests':True,
 'coverage_regions_all_aligned_without_mutation':True,'source_selector_delta_operations':len(ops),
 'checks_are_not_mathematical_proof_or_independent_topology_acceptance':True})
print(json.dumps({'verdict':verdict['verdict'],'raw_phase1_preserved':True,'source_selector_delta_operations':len(ops),'proof_credit':False,'process_qualification':'NOT_ASSESSED'}))
