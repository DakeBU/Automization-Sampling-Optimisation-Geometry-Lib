from pathlib import Path
import ast, hashlib, json, subprocess, sys
sys.dont_write_bytecode = True
W = Path('.astis/huanjian-gc-fixed-spectrum-gaussian-moments-20261110')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
b = json.loads((W / 'preproof-baseline.json').read_text())
assert subprocess.check_output(['git','rev-parse','HEAD'], text=True).strip() == b['working_HEAD']
assert sha(Path(b['ledger']['path'])) == b['ledger']['sha256']
for p, h in b['all_frontier_hashes'].items():
    assert sha(Path(p)) == h, p
for p, h in b['protected_shared_hashes'].items():
    assert sha(Path(p)) == h, p
s = json.loads((W / 'statement-seal-v2.json').read_text())
assert sha(W / 'statement-seal-v2.json') == 'eed0782fa32075cdf6313e802293764bd6b07ca991974b9e56c8d520a8e13354'
assert sha(W / 'statement-seal-v1.json') == s['predecessor']['sha256']
assert not (W / 'StatementFormation.lean').exists()
assert (W / 'StatementFormation.lean.gz').is_file()
assert not Path(s['producer']['planned_file']).exists()
assert not Path(s['actual_private_consumer']['planned_file']).exists()
assert not (W / 'root-preproof-admission-grant.json').exists()
assert sha(Path(s['source']['raw']['path'])) == s['source']['raw']['sha256']
assert sha(Path('lake-manifest.json')) == b['manifest']['sha256']
ast.parse((W / 'admit_normal_intake.py').read_text())
print(json.dumps({'state':'PREPROOF_PRESERVATION_PASS', 'existing_SAU_states':len(b['all_current_SAU_states']),
    'frontier_raw_files':len(b['all_frontier_hashes']), 'seal_v2_sha256':sha(W / 'statement-seal-v2.json'),
    'no_production_proof_or_consumer_or_grant_or_new_API_event':True,
    'official_main_foreign_STAB_observed_at_baseline':b['official_foreign_STAB'],
    'no_fresh_official_fetch_claim':True, 'mathematical_result_credit':False}, ensure_ascii=False))
