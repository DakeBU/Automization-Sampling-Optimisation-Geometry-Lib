from pathlib import Path
import datetime,gzip,hashlib,json,subprocess,tarfile
P=Path('.astis/huanjian-gc-fixed-spectrum-moments-20261109')
E=Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-cosine-expansion-semantic-evidence')
sha=lambda b:hashlib.sha256(b).hexdigest()
dump=lambda x:(json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode()
def ref(p):return {'path':str(p),'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size}
def put(p,raw):
    assert not p.exists(),p
    p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
seal=Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-cosine-expansion-statement-seal.json')
assert sha(seal.read_bytes())=='748538057656b235eed54272a87e66f4bf87bdbeb79a9831795b53e72ae74a36'
frozen=[]
for phase,digest in [(1,'215fe8eba52b906f54c08471d9d0e896b956cb6726af15a335f4815bac60c6d3'),
                     (2,'59591f5af29d038fe097bc563bda7a39b4f77d02dff1a34f45ea653d31b86361'),
                     (3,'1ef1151b46bdbc8502b7838f5170afe4d1b75ebb7c0f1444686736002610a9f4')]:
    base=P/f'source-only-review/phase{phase}';m=base/'manifest.json';assert sha(m.read_bytes())==digest
    frozen.append(m)
    for r in json.loads(m.read_bytes())['files']:
        q=base/r['path'];assert sha(q.read_bytes())==r['sha256'] and q.stat().st_size==r['bytes'];frozen.append(q)
checks=P/'cosine-topology-challenge'
for name,digest in [('phase1/SHA256SUMS','a1d2707c62f0637bdf7d6272da3140546db2b9c98d69f05b40477be73f3798a4'),
                    ('phase2/SHA256SUMS.projection-v1','5c9451592cfc278ff8821b89fd7fb07428deb8fd27aad70ae3b08880134b80fe'),
                    ('phase3/SHA256SUMS','d6769c063a5948c123d59d56be51ab9700f8fc815ff7a04b1f816307ee461bb2')]:
    q=checks/name;assert sha(q.read_bytes())==digest
for q in checks.rglob('*'):
    if not q.is_file() or '__pycache__' in q.parts or q.suffix=='.pyc':continue
    frozen.append(q)
    if q.name.startswith('SHA256SUMS'):
        for line in q.read_text().splitlines():
            h,name=line.split(maxsplit=1);src=q.parent/name.lstrip('*')
            assert sha(src.read_bytes())==h,src
receipt=checks/'phase3/admission-receipt.json'
r=json.loads(receipt.read_bytes())
assert sha(receipt.read_bytes())=='ed84f9890a326c70f3e618d08eafbcfd3039dee586308c24326938e9b9cc5ac3'
assert r['verdict']=='ACCEPT' and r['remaining_preproof_holds']==[] and r['unchanged_seal_sha256']==sha(seal.read_bytes())
for x in r['inputs']:assert sha(Path(x['path']).read_bytes())==x['sha256']
assert set(r['producer_AND_closure']).isdisjoint({'source.standing','hard.grid','moment.definitions','background.gaussian'})
archive=E/'preproof-source-and-challenge.lossless.tar.gz';assert not archive.exists()
frozen=sorted(set(frozen))
with tarfile.open(archive,'w:gz') as t:
    for q in frozen:t.add(q,arcname=str(q.relative_to(P)),recursive=False)
with tarfile.open(archive,'r:gz') as t:
    for q in frozen:assert t.extractfile(str(q.relative_to(P))).read()==q.read_bytes()
artifacts=[{'original':ref(q),'archive_member':str(q.relative_to(P))} for q in frozen]
put(E/'preproof-archive-manifest.json',dump({'archive':ref(archive),'files':artifacts,'all_exact_originals_retained':True}))
inputs=[ref(P/'source-only-review/phase2/seal_source_comparison.json'),ref(P/'source-only-review/phase3/manifest.json'),
        ref(P/'source-only-review/phase3/source-graph-v3.json'),ref(receipt),ref(checks/'phase3/SHA256SUMS'),
        ref(checks/'phase2/projection-v1-review.md')]
admission={'state':'EXACT_PREPROOF_SOURCE_TOPOLOGY_BINDER_MEANING_ADMITTED_NO_PROOF',
 'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'recording_actor':'/root','source_graph_actor':'/root/moments_source_graph','different_challenger':'/root/cosine_topology_challenge',
 'seal':ref(seal),'exact_independent_inputs':inputs,'accepted_source_graph':ref(P/'source-only-review/phase3/source-graph-v3.json'),
 'actual_independent_admission':ref(receipt),'lossless_archive':ref(archive),'archive_manifest':ref(E/'preproof-archive-manifest.json'),
 'HOLD_history':'Original full graph and phase2 projection retained. Distinct H-KAPPA-ONLY-PORT was repaired by original author in phase3, independently version-reviewed. No theorem signature or binder change.',
 'source_and_Lean_graphs_separate':True,'actual_implementation_or_consumer_use_certified':False,
 'Lean_proof_or_sourceV_or_local_integration_or_purification_or_Goal_credit':False,
 'next':'Normal new SAU proposal/CLAIMED/EXPLORING, then one root mathematical worker retrieves exact proof APIs and proves sealed producer and real finite-grid consumer.'}
put(E/'preproof-source-admission.json',dump(admission))
put(P/'cosine-expansion/root-preproof-admission-grant-v1.json',dump({
 'source_graph_and_distinct_topology_admitted':True,'target_proof_or_API_search_has_started':False,
 'seal_sha256':sha(seal.read_bytes()),'actual_frozen_review_inputs':inputs,
 'scope':'Only normal new proposal/claim/exploring intake and own new frontier, preserving every existing state/frontier/model; no V, STAB or mathematical credit.'}))
print(json.dumps({'admission':ref(E/'preproof-source-admission.json'),'archived_frozen_artifacts':len(frozen),'new_source_verdict_or_proof_credit':False}))
