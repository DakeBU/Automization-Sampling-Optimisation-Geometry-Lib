# Independent scalar and boundary reading

This is a raw-source-only preparation note, not an acceptance, proof seal, Lean result, or reviewed source repair. No implementation Lean, authored Bernstein graph, prior Bernstein conclusions, candidate signatures, R12 lessons, or private guard maps were read. Scope: the scalar calculation in Lemma 6.7 and the analytic/endpoint conventions of its native Theorem 6.1 consumer.

Primary source: Joel A. Tropp, *User-Friendly Tail Bounds for Sums of Random Matrices*, author preprint, revised 15 June 2011, https://tropp.caltech.edu/papers/Tro11-User-Friendly-preprint.pdf. Local primary PDF `.astis/semantic-neutral-20261113/bernstein_raw_intake_74ab/Tro11-User-Friendly-preprint.pdf`, SHA-256 `f4c3cff8661011395e793972a1f8d9a199fae4ca0fd098535d7a42166cf8fc86`. I inspected rendered printed pages 7, 23, 24, 25, 26; PDF and printed page indices coincide here. Text extraction is auxiliary.

## Scalar omitted port

On printed page 25 Lemma 6.7 fixes real theta > 0 and defines the smooth real function

    f_theta(x) = (exp(theta*x) - theta*x - 1)/x^2, x != 0;
    f_theta(0) = theta^2/2.

The source says differential calculus shows f is increasing, then uses this for every real x <= 1. Thus the relevant domain is the whole half-line (-infinity, 1], including negative x and x = 0; it is not [0,1].

A direct reconstruction of the omitted calculus is the real identity

    f_theta(x) = theta^2 * integral_0^1 (1-s)*exp(s*theta*x) ds,

valid also at x = 0. Differentiating under this finite-interval smooth integral gives

    f_theta'(x) = theta^3 * integral_0^1 s*(1-s)*exp(s*theta*x) ds > 0

for every real x when theta > 0. This supplies a mathematically sound omitted internal calculus step, not a new source hypothesis and not a formally supplied certificate. The source itself does not print this integral route. It would be incorrect to treat the positive-x power-series argument alone as coverage of the stated domain.

The scalar coefficient f_theta(1) = exp(theta) - theta - 1 is nonnegative. The source's matrix estimate uses scalar functional calculus on the spectrum, followed by the congruence inequality X*f_theta(X)*X <= f_theta(1)*X^2. It does not use operator monotonicity of f, or of the matrix exponential.

## One-sided bound and regularity

Lemma 6.7 explicitly displays only E X = 0 and lambda_max(X) <= 1. Its conclusion is for every real theta > 0. Independence is absent and unnecessary at this single-variable mgf step. The displayed eigenvalue relation is almost sure by the global probability convention on printed page 7, Section 2.2.

Theorem 6.1 explicitly takes a finite independent sequence of random self-adjoint d-dimensional matrices, E X_k = 0 and lambda_max(X_k) <= R almost surely. Printed page 24 stresses that no lower eigenvalue bound is assumed; the minimum eigenvalues may be arbitrarily small, and applying to -X_k can change R. Consequently the source hypothesis is not an operator-norm bound. A norm bound is a stronger specialization that controls both signs and requires a separate adapter if used.

Section 2.2 gives an intentionally unquantified standing assumption: random variables have enough regularity to compute expectations and interchange limits. The source does not state a finite second-moment hypothesis separately in Lemma 6.7 or Theorem 6.1, although E(X^2) and the finite matrix variance parameter are used. Their meaningful finite-matrix interpretation therefore relies on that standing regularity, not merely on the displayed centering and one-sided spectral bound.

The distinction is substantive: for a scalar nonnegative Pareto variable Y with finite mean m and infinite second moment (tail exponent between 1 and 2), X = 1 - Y/m satisfies X <= 1 and E X = 0 but E(X^2) is infinite. This illustrates why one-sided boundedness plus centering alone does not derive a finite second moment. It does not refute the paper under Section 2.2's regularity convention. It must not be converted silently into an added explicit public source premise.

For theta > 0, a measurable self-adjoint X with lambda_max(X) <= 1 has 0 < exp(theta X) <= exp(theta) I almost surely. Its mgf integrability is thus bounded in finite dimension once measurability is supplied; unlike E(X^2), it is not threatened by an arbitrarily negative tail. The expectation step still needs the regularity and linearity necessary to handle the affine/quadratic majorant. These are internal analytic discharge requirements / source-imprecision notes, not source-given ingredient certificates.

## Theorem 6.1 parameter and endpoint imprecision

The printed statement defines sigma^2 = ||sum_k E(X_k^2)||, gives all t >= 0, and displays R and sigma^2 in denominators. It does not explicitly add R > 0 or sigma^2 > 0. The proof normalizes R to 1 by homogeneity, so its written calculation presumes positive R. In a nonempty positive-dimensional centered family the nontrivial case has R > 0; R = 0 forces zero summands under regularity, and negative R is incompatible with centering. Those observations do not supply a printed source convention for the zero denominators.

Likewise sigma^2 = 0 is a degenerate zero-variance case not separately discussed in the printed proof. A future faithful interface must preserve this as a source boundary / separately reviewed endpoint interpretation, rather than assert that positivity was explicitly stated.

At sigma^2 > 0 and t > 0, the optimizer theta = log(1 + t/sigma^2) is positive and is the genuine minimum of exp(-theta*t + sigma^2*(exp(theta)-theta-1)). At t = 0 it equals 0, outside Corollary 3.7's theta > 0 domain; the infimum is reached only as theta tends down to zero. Thus the page-26 sentence that the right side attains its minimum at that formula is imprecise at the included endpoint t = 0. The probability bound there follows from the limiting infimum (or the elementary probability bound) in positive dimension. This is omitted endpoint bookkeeping, not a reason to change the printed t >= 0 domain.

At t = sigma^2/R with R > 0 and sigma^2 > 0, both displayed split cases in Theorem 6.1(iii) apply and give the same exponent -3*sigma^2/(8*R^2). There is no mismatch at that interface. The source's monotonicity arguments for the rational functions are valid in the positive-parameter regime.

## Remaining status

No target signature was proposed, no API search or build was run, and no formal proof ingredient is supplied. The source-only calculus reconstruction above does not close Lieb, master-tail, conditional-expectation, or matrix-functional-calculus infrastructure. Independent review of the parent source graph remains a separate task.
