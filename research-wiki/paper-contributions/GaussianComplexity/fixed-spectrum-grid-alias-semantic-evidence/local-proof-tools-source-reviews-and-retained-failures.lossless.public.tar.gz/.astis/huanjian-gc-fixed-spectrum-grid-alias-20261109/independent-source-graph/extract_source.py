from pathlib import Path
from hashlib import sha256
from html.parser import HTMLParser
import json, datetime
ROOT=Path('/Users/zhouhuanjian/ASTIS-GC')
OUT=ROOT/'.astis/huanjian-gc-fixed-spectrum-grid-alias-20261109/independent-source-graph'
class N:
 def __init__(self,t,a): self.tag=t; self.attrs=dict(a); self.children=[]
 def walk(self):
  yield self
  for c in self.children:
   if isinstance(c,N): yield from c.walk()
 def text(self):
  if self.tag=='math': return '$'+self.attrs.get('alttext','')+'$'
  return ''.join(c.text() if isinstance(c,N) else c for c in self.children)
class P(HTMLParser):
 def __init__(self): super().__init__(); self.root=N('root',[]); self.stack=[self.root]; self.ids={}
 def handle_starttag(self,t,a):
  n=N(t,a); self.stack[-1].children.append(n)
  if 'id' in n.attrs: self.ids[n.attrs['id']]=n
  if t not in ['area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr']: self.stack.append(n)
 def handle_endtag(self,t):
  for k in range(len(self.stack)-1,0,-1):
   if self.stack[k].tag==t: self.stack=self.stack[:k]; break
 def handle_data(self,d): self.stack[-1].children.append(d)
raw=ROOT/'.astis/huanjian-resume-20261103/2610.20492v1.html'; data=raw.read_bytes();p=P();p.feed(data.decode())
inputs=['AGENTS.md','docs/proof-digestion-protocol.md','docs/evidence-routed-memory-protocol.md','.agents/skills/astis-source-dependency-audit/SKILL.md',str(raw.relative_to(ROOT))]
manifest=[]
for i,rel in enumerate(inputs):
 b=(ROOT/rel).read_bytes(); dest=OUT/'phase1/inputs'/f'{i:02d}-{Path(rel).name}.raw';dest.write_bytes(b)
 manifest.append({'source':rel,'snapshot':str(dest.relative_to(OUT)),'sha256':sha256(b).hexdigest(),'bytes':len(b)})
(OUT/'phase1/input-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
records=[]
for anchor in ['S4.SS1','S4.Thmtheorem5','A3.SS3']:
 n=p.ids[anchor]
 (OUT/'phase1'/f'{anchor}.source.txt').write_text(n.text())
 for x in n.walk():
  classes=x.attrs.get('class','').split();id=x.attrs.get('id')
  if id and (x.tag=='p' or 'ltx_equation' in classes or 'ltx_equationgroup' in classes or 'ltx_theorem' in classes):
   records.append({'anchor':anchor,'source_id':id,'tag':x.tag,'classes':classes,'text':' '.join(x.text().split())})
  if x.tag=='a':
   records.append({'anchor':anchor,'source_id':id or anchor+'::ref-'+str(len(records)),'tag':'a','target':x.attrs.get('href'),'text':' '.join(x.text().split())})
(OUT/'phase1/source-item-inventory.json').write_text(json.dumps(records,indent=2,ensure_ascii=False)+'\n')
for r in records: print(r['source_id'],r.get('target',''),r['text'])
