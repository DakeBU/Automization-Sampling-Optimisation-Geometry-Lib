import Mathlib.LinearAlgebra.UnitaryGroup
import Mathlib.LinearAlgebra.Matrix.Determinant.Basic
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Basic
open Matrix
open scoped BigOperators
set_option autoImplicit false
#check (
∀ {d : ℕ} (hd : 2 ≤ d)
    {κ : ℝ} (hκ : 2 ≤ κ)
    (O : Matrix.orthogonalGroup (Fin d) ℝ),
    let θ : Fin d → ℝ := fun i => ((i.val : ℝ) + 1 / 2) * Real.pi / (d : ℝ)
    let diagonalValue : Fin d → ℝ := fun i =>
      (κ + 1) / 2 + (κ - 1) / 2 * Real.cos (θ i)
    let A : Matrix (Fin d) (Fin d) ℝ :=
      (O : Matrix (Fin d) (Fin d) ℝ) * Matrix.diagonal diagonalValue *
        (O : Matrix (Fin d) (Fin d) ℝ).transpose
    A.det = ∏ i : Fin d, diagonalValue i
 : Prop)
