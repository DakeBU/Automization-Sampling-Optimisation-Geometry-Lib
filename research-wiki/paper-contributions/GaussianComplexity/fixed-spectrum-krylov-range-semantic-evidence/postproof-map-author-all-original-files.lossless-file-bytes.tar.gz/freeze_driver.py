from pathlib import Path
import os,sys,stat,json,hashlib,subprocess,datetime,traceback
ROOT=Path(__file__).resolve().parent;REPO=ROOT.parents[2]
utc=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
sha=lambda b:hashlib.sha256(b).hexdigest()
enc=lambda x:(json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode()
started=utc();envelope={'payload-manifest.json','freeze-execution.receipt.json','freeze-execution.stdout','freeze-execution.stderr','freeze-envelope-hashes.json'}
assert not any((ROOT/x).exists() for x in envelope)
argv=[sys.executable,str(ROOT/'check_mapping_integrity.py')];r=subprocess.run(argv,cwd=REPO,capture_output=True)
(ROOT/'freeze-integrity-check.stdout').write_bytes(r.stdout);(ROOT/'freeze-integrity-check.stderr').write_bytes(r.stderr)
assert r.returncode==0,r.stderr.decode(errors='replace')
summary=json.loads((ROOT/'mapping-integrity-summary.json').read_bytes());assert summary['status']=='AUTHOR_MAPPING_INTEGRITY_CHECKS_ONLY'
payload=[]
for path in sorted(ROOT.rglob('*')):
    assert not path.is_symlink()
    if path.is_file() and path.name not in envelope:
        b=path.read_bytes();payload.append({'path':str(path.relative_to(ROOT)),'bytes':len(b),'sha256':sha(b),'frozen_mode':'0444'})
manifest={'schema':'postproof-source-map-author-proposal-v1-payload-manifest','created_utc':utc(),'root':str(ROOT),'role':'mapping author proposal only; no independent/sourceV/publication approval','files':payload,'envelope_files':sorted(envelope),'hash_contract':'All original input snapshots are exact raw copies, including logs/receipts with no normalization. This manifest covers all static inputs/outputs/scripts/command captures; the five freeze-envelope files are excluded, and freeze-envelope-hashes.json covers the other four while excluding itself. Only this assigned author directory is chmodded/written, never original production/preproof/Mathlib/public metadata paths.'}
(ROOT/'payload-manifest.json').write_bytes(enc(manifest));manifest_sha=sha((ROOT/'payload-manifest.json').read_bytes())
handles={name:(ROOT/name).open('w+b') for name in envelope if name!='payload-manifest.json'}
try:
    files=sorted(x for x in ROOT.rglob('*') if x.is_file());dirs=sorted([ROOT]+[x for x in ROOT.rglob('*') if x.is_dir()],key=lambda x:len(x.parts),reverse=True);actions=[]
    for path in files:
        os.chmod(path,0o444);actions.append({'path':str(path.relative_to(ROOT)),'operation':'chmod','requested_mode':'0444','actual_mode':format(stat.S_IMODE(path.stat().st_mode),'04o')})
    for path in dirs:
        os.chmod(path,0o555);actions.append({'path':'.' if path==ROOT else str(path.relative_to(ROOT)),'operation':'chmod','requested_mode':'0555','actual_mode':format(stat.S_IMODE(path.stat().st_mode),'04o')})
    assert all(x['requested_mode']==x['actual_mode'] for x in actions)
    for rec in payload:
        b=(ROOT/rec['path']).read_bytes();assert len(b)==rec['bytes'] and sha(b)==rec['sha256']
    receipt={'schema':'actual-postproof-source-map-author-freeze-v1','status':'FROZEN_PROPOSED_SOURCE_TO_LEAN_MAP_V1','started_utc':started,'chmod_and_payload_recheck_completed_utc':utc(),'cwd':str(REPO),'invocation':['python3',str(Path(__file__).relative_to(REPO))],'actual_interpreter':sys.executable,'payload_manifest_sha256':manifest_sha,'static_payload_files':len(payload),'files_including_envelope':len(files),'directories_including_root':len(dirs),'integrity_check_command':argv,'integrity_check_returncode':r.returncode,'integrity_stdout_sha256':sha(r.stdout),'integrity_stderr_sha256':sha(r.stderr),'original_input_preservation_sha256':sha((ROOT/'original-input-preservation.json').read_bytes()),'actions':actions,'envelope_finalization':'Four non-manifest envelope descriptors preopened before actual chmod, finalized only after mode/content checking, then closed. No permission relaxation or writing outside this author directory.','scope':'Author mapping proposal; no Lean execution/proving, generic API proof search, sourceV, independent topology/exposition acceptance, normal transition, Git/ledger/public metadata mutation or publication approval.'}
    rb=enc(receipt);handles['freeze-execution.receipt.json'].write(rb);handles['freeze-execution.receipt.json'].flush()
    log=enc({'status':'FROZEN_PROPOSED_SOURCE_TO_LEAN_MAP_V1','root':str(ROOT),'payload_manifest_sha256':manifest_sha,'freeze_receipt_sha256':sha(rb),'source_to_lean_map_v1_sha256':sha((ROOT/'source-to-lean-map.v1.json').read_bytes()),'candidate_exposition_map_sha256':sha((ROOT/'candidate-exposition-source-map.json').read_bytes()),'canonical_actual_declaration_inventory_sha256':sha((ROOT/'canonical-declaration-inventory.json').read_bytes()),'actual_kernel_constant_inventory_sha256':sha((ROOT/'actual-kernel-constant-inventory.json').read_bytes()),'capsule_sha256':sha((ROOT/'capsule.md').read_bytes()),'publication_binding_sha256':'7b97440eda9692f238e20ad1f0e985b5c38b4fc4f358ccffb02535b92df14ea7','original_inputs_unchanged':16,'mapping_records':11,'canonical_actual_declaration_spans':50,'all_unique_actual_constants_classified':554,'exact_candidate_code_blocks':6,'files_0444':len(files),'directories_0555':len(dirs),'scope':'proposal awaiting independent exact-candidate mapping/source/exposition review; no sourceV/publication approval'})
    handles['freeze-execution.stdout'].write(log);handles['freeze-execution.stdout'].flush();handles['freeze-execution.stderr'].write(b'');handles['freeze-execution.stderr'].flush()
    env={'schema':'nonrecursive-source-map-author-freeze-envelope-hashes-v1','self_excluded':'freeze-envelope-hashes.json','files':[]}
    for name in sorted(envelope-{'freeze-envelope-hashes.json'}):
        b=(ROOT/name).read_bytes();env['files'].append({'path':name,'bytes':len(b),'sha256':sha(b),'mode':format(stat.S_IMODE((ROOT/name).stat().st_mode),'04o')})
    handles['freeze-envelope-hashes.json'].write(enc(env));handles['freeze-envelope-hashes.json'].flush()
    for h in handles.values():h.close()
    assert all(stat.S_IMODE(x.stat().st_mode)==0o444 for x in files);assert all(stat.S_IMODE(x.stat().st_mode)==0o555 for x in dirs)
    sys.stdout.buffer.write(log)
except BaseException:
    tb=traceback.format_exc().encode();h=handles.get('freeze-execution.stderr')
    if h and not h.closed:h.write(tb);h.flush()
    for h in handles.values():
        if not h.closed:h.close()
    sys.stderr.buffer.write(tb);raise
