"""Derive a bounded independent R16 native outcome from this actor's real evidence only."""
import json
from native_common import *
from scan_policy import FORBIDDEN_REGEX,strip_lean_comments_and_strings

def main():
    completed=json.loads((OWN/'native-sequence.completed.json').read_text());assert completed['all_v3_actual_commands_exit_zero']
    closure=json.loads((OWN/'actual-import-closure.json').read_text())
    summary=json.loads((OWN/'native-raw-roundtrip/native-kernel-summary.json').read_text())
    recursive=json.loads((OWN/'complete-transitive-type-value-graph.json').read_text())
    assert summary['pinned_candidate']==recursive['candidate_commit']==COMMIT
    graph={x['name']:x for x in recursive['declarations']};assert len(graph)==len(recursive['declarations'])
    assert sorted(x['name'] for x in graph.values() if x['is_axiom'])==['Classical.choice','Quot.sound','propext']
    assert not any(x['is_unsafe'] for x in graph.values())
    for row in graph.values():assert all(d in graph for d in row['type_dependencies']+row['value_dependencies'])
    raw={};modules=[];raw_files=[]
    for module in closure['topological_order']+['NativeLiteralApplications']:
        path=OWN/'native-raw-roundtrip'/(module+'.json');data=json.loads(path.read_text());raw_files.append(path)
        assert data['constNames']==[r['name'] for r in data['declarations']]
        if module!='NativeLiteralApplications':
            assert not data['extraConstNames']
            source=next(r for r in closure['modules'] if r['module']==module)
            assert [x for x in data['imports'] if x.startswith(('AutoSamplingTheory','Tests'))]==source['actual_ASTIS_imports']
        for r in data['declarations']:
            assert r['kernel_type_checked'] and r['kernel_value_checked'] and not r['unsafe']
            assert set(r['axioms'])<={'propext','Classical.choice','Quot.sound'}
            raw[r['name']]=r
        modules.append({'module':module,'raw_declarations':len(data['declarations']),'full_expression_nodes':len(data['expression_nodes']),'extra_compiler_names':len(data['extraConstNames'])})
    p,t=recursive['roots'];assert t.startswith('_private.Tests.GaussianComplexityTraceMgfDomain.')
    assert t.endswith('.actual_source_four_trace_mgfs_integrable_positive_and_bounded')
    own_graph={n:r for n,r in graph.items() if (r['first_owner'] or '').startswith(('AutoSamplingTheory','Tests'))}
    assert all(n in raw for n in own_graph)
    assert {x['first_owner'] for x in own_graph.values()}<=set(closure['topological_order'])
    external_P=[n for n in graph[p]['value_dependencies'] if (graph[n]['first_owner'] or '').startswith(('AutoSamplingTheory','Tests')) and graph[n]['first_owner']!=closure['P']]
    assert not external_P
    expected=[p,'AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumSourceMatrixRadius.actual_source_truncated_matrix_norm_bounds','AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumSourceMatrixStructure.actual_source_centered_matrix_structure']
    assert all(n in graph[t]['value_dependencies'] for n in expected)
    semantics=[n for n in graph[p]['type_dependencies'] if any(x in n for x in ['L2Op','Norm.norm','NormedSpace.exp','Matrix.trace','Fintype.card','Real.exp'])]
    assert {'Matrix.trace','NormedSpace.exp','Fintype.card','Real.exp','Norm.norm','Matrix.instL2OpNormedRing'}<=set(semantics)
    witness={'candidate_commit':COMMIT,'actual_P':p,'actual_private_T_mangled_name':t,'P_direct_ASTIS_mathematical_parents_from_actual_value':external_P,'T_direct_actual_value_parents':[{'name':n,'first_owner':graph[n]['first_owner'],'value_edge_present':True} for n in expected],'all_T_direct_project_value_edges':[n for n in graph[t]['value_dependencies'] if (graph[n]['first_owner'] or '').startswith(('AutoSamplingTheory','Tests'))],'actual_P_type_semantic_constants':semantics,'norm_interface_kernel_checked':'NativeLiteralApplications.literal_P_explicit_L2_operator','negative_dominant_mixed_interface_kernel_checked':['NativeLiteralApplications.mixed_diagonal_entries','NativeLiteralApplications.mixed_operator_norm_three','NativeLiteralApplications.mixed_negative_parameter_exact_norm_cap'],'imports_never_used_as_theorem_parent_evidence':True}
    write_json(OWN/'actual-type-and-parent-witnesses.v1.json',witness)
    scan=[]
    for row in closure['modules']:
        source=CAND/row['path'];assert file_sha(source)==row['sha256']
        hits=[{'line':i,'text':line} for i,line in enumerate(strip_lean_comments_and_strings(source.read_text()).splitlines(),1) if FORBIDDEN_REGEX.search(line)]
        assert not hits,(row['path'],hits)
        scan.append({'module':row['module'],'source_sha256':row['sha256'],'fake_closure_hits':hits})
    write_json(OWN/'fake-closure-scan.v1.json',{'candidate_commit':COMMIT,'policy_provenance':json.loads((OWN/'scan-policy-provenance.json').read_text()),'scope':'Only the exact 11-module actual ASTIS source closure, not a whole-repository gate','modules':scan,'passed':True})
    receipts=[]
    for path in sorted((OWN/'command-receipts').glob('*.receipt.json')):
        r=json.loads(path.read_text())
        for stream in ['stdout','stderr']:assert file_sha(OWN/r[stream]['path'])==r[stream]['sha256']
        receipts.append((path,r))
    successes={r['label']:r for _,r in receipts if r['exit_code']==0}
    assert all(f'compile-{i:02d}' in successes for i in range(11))
    for label in ['lean-version','literal-types-and-boundaries-v3','lossless-raw-type-value-kernel-v3','complete-recursive-type-value-graph-v3']:assert label in successes
    version=(OWN/successes['lean-version']['stdout']['path']).read_text().strip()
    assert 'version 4.33.0' in version and 'd8b189' in version
    for label in ['literal-types-and-boundaries','literal-types-and-boundaries-v2']:
        assert any(r['label']==label and r['exit_code']==1 for _,r in receipts)
    packages=json.loads((OWN/'verified-package-inputs.json').read_text())
    astis=modules[:-1];harness=modules[-1]
    report={
      'schema':'independent-immutable-trace-exponential-native-audit-v1',
      'status':'NATIVE_MATH_TYPE_VALUE_KERNEL_CHECKS_PASSED;NO_NORMAL_V_AUTHORIZED_OR_CALLED',
      'candidate_commit':COMMIT,'lean_version_actual':version,'compiler_binary_sha256_observed_after_run':file_sha(LEAN),
      'fixed_toolchain_sha256':file_sha(CAND/'lean-toolchain'),'fixed_manifest_sha256':file_sha(CAND/'lake-manifest.json'),
      'P':{'declaration':p,'source_sha256':closure['modules'][0]['sha256'],'lines':60,'generic_quantifiers':'finite nonempty real square matrix, Hermitian A, every real s; no probability/regularity/radius premise','trace':'ordinary unnormalized Matrix.trace','exponential':'NormedSpace.exp on the matrix algebra','actual_type_instances':semantics,'norm':'Actual Matrix.instL2OpNormedRing plus kernel-checked reexpression as norm of Matrix.toEuclideanCLM (𝕜:=ℝ)(n:=ι) A, hence L2 operator norm.','dimension_factor':'Fintype.card ι, not normalized trace','actual_value_kernel_checked_against_exact_sealed_literal_type':True,'external_ASTIS_parents_from_actual_value':[]},
      'T':{'actual_private_mangled_name':t,'private':True,'source_sha256':closure['modules'][-1]['sha256'],'lines':183,'external_premise':'2*q+1<d only; s is every real and useCos/minus are arbitrary Bool','literal_model':'Unconditional product stdGaussian on q+1 Euclidean Fin d vectors; inclusive own-row norm²≤L cutoff; true full-law Bochner means; gamma-first/feature-second paired matrix index; ordinary/cos((2q+1)α) weights and two global signs.','cap':'B=r²*exp(|s|*((d:ℝ)*Rstar)), Rstar=2*r*(L+1)/d','conclusion':'Integrable scalar f; pointwise all ω strict positivity and cap; ordinary scalar integral strictly positive and ≤B','no_regularity_radius_integrability_or_finiteness_premise_added':True,'actual_value_kernel_checked_against_exact_literal_type':True,'direct_value_parents':expected},
      'actual_application_checks':{'generic_P':True,'explicit_L2_continuous_linear_operator_norm_P':True,'generic_full_literal_T':True,'allreal_four_families':4,'q0_for_every_d_gt1':True,'q0_d2_for_allreal_and_Bool':True,'q0_d2_s_zero_negative1_positive1_cross_all_four_Bool_cases':12,'mixed_spectrum':'diag(-3,2), actual L2 operator norm=3, all real s and explicit s=0,-1,+1 applications; s=-1 cap2*exp3 checked. This negative-dominant matrix separates operator norm3 from largest algebraic diagonal eigenvalue2.','tests_repackage_only_actual_theorem_applications_and_basic_matrix_norm_identities':True},
      'independent_rebuild':{'ASTIS_source_modules':11,'all_actual_ASTIS_import_sources_extracted_from_exact_commit':True,'all_ASTIS_modules_freshly_recompiled_exit0':True,'prior_ASTIS_olean_reused':False,'fresh_output_initially_empty':True,'debug_skipKernelTC':False,'whole_repository_or_root_Tests_build_claimed':False,'global_repository_inventory_extracted':False},
      'upstream':{'mathlib_revision':'db584cd6d46c92f209a44c0f1c829460d327499d','packages':9,'source_revisions_manifest_exact_and_tracked_clean':True,'actual_cache_files_freshly_rehashed_for_this_assignment':sum(x['artifact_files_freshly_rehashed'] for x in packages['packages']),'actual_cache_bytes_freshly_rehashed_for_this_assignment':sum(x['artifact_bytes_freshly_rehashed'] for x in packages['packages']),'read_only_reused':True,'upstream_recompiled':False,'prior_R15_verdicts_or_receipts_reused_as_current_results':False},
      'raw_type_value_level_DAG':{'ASTIS_module_count':11,'ASTIS_raw_declarations':sum(x['raw_declarations'] for x in astis),'ASTIS_values_checked':sum(x['raw_declarations'] for x in astis),'ASTIS_expression_nodes':sum(x['full_expression_nodes'] for x in astis),'ASTIS_extraConstNames_all_empty':True,'harness_logical_declarations_checked':harness['raw_declarations'],'harness_expression_nodes':harness['full_expression_nodes'],'harness_extra_compiler_IR_names_not_logical_ConstantInfo_entries':harness['extra_compiler_names'],'full_structural_Expr_Level_Name_Metadata_roundtrip':True,'decoded_types_and_values_kernel_checked':True},
      'complete_recursive_dependency_closure':{'declarations':len(graph),'type_edges':sum(len(x['type_dependencies']) for x in graph.values()),'value_edges':sum(len(x['value_dependencies']) for x in graph.values()),'all_references_resolved':True,'reachable_ASTIS_declarations':len(own_graph),'all_reachable_ASTIS_values_covered_by_fresh_raw_checks':True,'upstream_full_constant_edges_read_from_pinned_verified_cache':True},
      'axioms':['Classical.choice','Quot.sound','propext'],'unsafe_in_complete_actual_target_closure':0,'unauthorized_axioms_or_sorryAx_in_final_targets':False,'canonical_fake_closure_scan':'PASS in all11 exact source closure modules',
      'retained_private_harness_failures':[{'command':'literal-types-and-boundaries','actual_exit_code':1,'classification':'API_BLOCKED_IN_EXTRA_PRIVATE_TEST_INTERFACE','cause':'Matrix.toEuclideanCLM A required explicit 𝕜/n before coercion to a function; actual P/T source compiled unchanged.'},{'command':'literal-types-and-boundaries-v2','actual_exit_code':1,'classification':'IMPLEMENTATION_FAILED_IN_EXTRA_PRIVATE_NUMERIC_CAST_TEST','cause':'simpa only omitted Nat.cast_ofNat for card(Fin2) in a mixed-spectrum helper. Explicit L2 norm P and all T cases already typechecked; final v3 fixes cast and strengthens matrix to diag(-3,2).'}],
      'actual_build_identity_qualification':'This independent actor rebuilt the exact301728 immutable ASTIS source closure. ROOT earlier compiled exact then-untracked new bytes while HEAD1db9 before freezing301728; this report does not turn bare1db9 or a future metadata carrier into a new build identity.',
      'truth_boundary':'Only deterministic all-real strict scalar trace-exponential/cardinality/operator-norm envelope and the actual four-family scalar E tr exp finite-domain/pointwise cap/ordinary-positive-expectation consumer. No full matrix-valued MGF, Lieb/Jensen/independent-sum/mastertail/Bernstein/norm-tail/C6/main bound, browser/reader/source-fidelity review, normalV, production/integration/purification or whole-Goal acceptance.',
      'normal_API_calls':0,'browser_runs':0,'Git_or_production_or_old_R15_evidence_mutations':0
    }
    write_json(OWN/'native-mathematics-report.v1.json',report)
    notes={'candidate_commit':COMMIT,'P_native_mathematical_inspection':['CFC of exp(s*x) equals matrix-algebra exp(s*A) for real Hermitian A. Positive real scalar exp on the finite spectrum gives strictly positive matrix via cfc_isStrictlyPositive_iff; positive definiteness gives strictly positive ordinary trace because the index is nonempty.','For all real s and every spectral x, s*x≤|s*x|=|s|*|x|≤|s|*||A||op. CFC order bounds exp(s*A) by exp(|s|*||A||op) times identity; PSD trace monotonicity yields exact cardinality factorN.','The native type records Matrix.instL2OpNormedRing. The full literal interface with explicit continuous Euclidean linear-operator norm is kernel checked. Negative-dominant diag(-3,2) has kernel-checked norm3 and s=-1 bound2*exp3, so the check does not confuse norm with algebraic λmax2.'],'T_native_mathematical_inspection':['The full literal let-chain fixes the original unconditional product Gaussian law, row-local inclusive cutoff, actual Bochner means and gamma-first Kronecker coordinates before quantifying every real s and both Bool switches. There is no assumed regularity/integrability/radius output in the theorem binder list.','The actual value consumes Structure for measurability/pointwise Hermiticity and Radius for truncated Y and actual mean bounds. Triangle inequality gives ||Z||≤Rstar; absolute cosine weights≤1 and unit global signs give ||S||≤d*Rstar. These facts are discharged inside the proof.','The actual P gives strict positivity and cardinality exponential bound pointwise; card(Fin(q+1)×Fin(q+1))=r² produces the exact required B. Measurable composition of matrix exp and linear trace plus scalar absolute-value bound proves Integrable f.','Strict pointwise positivity makes support f the whole unconditional probability space, so integral_pos_iff_support_of_nonneg yields a strictly positive ordinary scalar integral. Monotonicity against constant B and μ(univ)=1 yields expectation≤B.','q0,d2, allreal parameter families and all12 combinations of zero/negative/positive parameter with the four signed/weighted cases are actual applications, not supplied proof premises.'],'native_finding':'No mathematical/type/value/closure defect found within the assigned immutable scope. Source fidelity and reader acceptance require their separate reviewers; no normalV is performed.'}
    write_json(OWN/'native-mathematical-inspection.v1.json',notes)
    selected=[OWN/name for name in ['native-mathematics-report.v1.json','native-mathematical-inspection.v1.json','actual-type-and-parent-witnesses.v1.json','fake-closure-scan.v1.json','actual-import-closure.json','verified-package-inputs.json','scan_policy.py','scan-policy-provenance.json','mechanism-provenance.json','native_common.py','prepare.py','freeze_and_build.py','run_successor.py','run_successor_v3.py','finalize.py','native-commands.json','native-assignment.json','native-successor-commands.json','native-successor-assignment.json','native-v3-commands.json','native-v3-assignment.json','native-sequence.completed.json','complete-transitive-type-value-graph.json','native-raw-roundtrip/native-kernel-summary.json']]
    selected+=raw_files+[CAND/r['path'] for r in closure['modules']]+[CAND/n for n in ['lean-toolchain','lake-manifest.json','lakefile.lean']]+list((OWN/'immutable-inputs').iterdir())
    for h in ['harness','harness-v2','harness-v3']:selected+=[OWN/h/n for n in ['NativeLiteralApplications.lean','NativeAudit.lean','NativeTransitiveGraph.lean']]
    for path,r in receipts:
        if r['label']=='canonical-policy-private':continue
        selected += [path,OWN/r['stdout']['path'],OWN/r['stderr']['path']]
    assert len(selected)==len({str(p) for p in selected})
    leaves=[]
    for path in selected:
        assert path.is_file() and path.resolve().is_relative_to(OWN)
        relative=str(path.relative_to(OWN));assert not any(x in relative for x in ['local-private','native-output/','__pycache__','canonical-policy-private'])
        leaves.append({'path':relative,'bytes':path.stat().st_size,'sha256':file_sha(path)})
    write_json(OWN/'public-safe-selected-originals.manifest.v1.json',{'schema':'explicit-own-R16-native-evidence-leaves-v1','candidate_commit':COMMIT,'global_inventory_index_foreign_guards_cache_ATLAS_credentials_excluded':True,'full_canonical_tools_policy_and_its_raw_preparation_streams_excluded':True,'raw_actual_compile_audit_failures_and_streams_unchanged':True,'all_actual_ASTIS_source_closure_and_raw_types_values_selected':True,'leaves':leaves})
    for leaf in leaves:assert file_sha(OWN/leaf['path'])==leaf['sha256']
    print(json.dumps({'native_actual_result':'PASS_WITH_PRIVATE_HARNESS_FAILURES_RETAINED','ASTIS_modules':11,'ASTIS_raw_declarations':report['raw_type_value_level_DAG']['ASTIS_raw_declarations'],'recursive_declarations':len(graph),'actual_report_sha256':file_sha(OWN/'native-mathematics-report.v1.json'),'public_manifest_sha256':file_sha(OWN/'public-safe-selected-originals.manifest.v1.json'),'explicit_evidence_leaves':len(leaves)}))

if __name__=='__main__':main()
