#!/usr/bin/env python3
"""Hash only explicitly frozen reader/runtime leaves; no browser, build, API or scan."""
from pathlib import Path
import datetime as dt
import hashlib
import json

ROOT = Path('/Users/zhouhuanjian/ASTIS-GC')
OWN = Path(__file__).resolve().parent
NATIVE = OWN.parent
W = ROOT / '.astis/huanjian-gc-weighted-mgf-20261114'
PFILE = 'AutoSamplingTheory/TechnicalLemmas/Probability/MatrixBernsteinMgf.lean'
TFILE = 'Tests/GaussianComplexityBernsteinWeightedMgf.lean'
PSHA = 'b46bb5a3eabbcadf31fee93d48c1fbabf9b5b42cf717a8a17c8c8cfdd210a3f3'
TSHA = '42f372143ffe52e4372271d09fbc6b67391739f2fe2a5fbfffe6cd9fa586936e'

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def read(p):
    return json.loads(p.read_text())

def write(name, value):
    p = OWN / name
    assert not p.exists(), f'Preserve existing evidence: {p}'
    p.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
    return p

def record(p, base):
    p = p.resolve()
    assert p.is_file() and not p.is_symlink()
    return {'path': str(p.relative_to(base)), 'bytes': p.stat().st_size, 'sha256': sha(p)}

checks_path = OWN / 'browser-output-v4/candidate/actual-checks.json'
receipt_path = OWN / 'browser-process-v4/candidate/process-receipt.json'
checks, receipt = read(checks_path), read(receipt_path)
contract = read(OWN / 'independent-browser-contract.v4.json')
assert sha(checks_path) == 'dd84dcee1105f455b1dd273f21187e8fe5c2539b515f8a1580b8888c614dd492'
assert sha(receipt_path) == '2cbc3228118bc7aabbd3c9e86c0ed87284171dfd490327b0b7198fed15df184b'
assert len(checks['checks']) == 343 and all(x['pass'] is True for x in checks['checks'])
assert len(checks['screenshots']) == 86 and checks['status'] == 'PASS'
assert receipt['exit_code'] == 0 and receipt['exception'] is None
assert not checks['javascript_errors'] and not checks['blocked_external_requests']
assert checks['browser_started'] and not checks['production_changes_applied']
assert receipt['wrapper_sha256'] == sha(OWN / 'browser_check.py') == contract['wrapper_sha256']
assert receipt['contract_sha256'] == sha(OWN / 'independent-browser-contract.v4.json')
for row in checks['screenshots']:
    assert sha(OWN / row['path']) == row['sha256']
for key in ['stdout', 'stderr']:
    row = receipt[key]
    assert sha(OWN / row['path']) == row['sha256']
    assert (OWN / row['path']).stat().st_size == row['bytes']
for row in contract['owned_inputs']:
    assert sha(Path(row['path'])) == row['sha256'], row['path']
for f, h in [(PFILE, PSHA), (TFILE, TSHA)]:
    assert sha(NATIVE / 'candidate-4869db55' / f) == h
    assert sha(W / 'reader-preview-v2/input-snapshot' / f) == h

# All historical leaves are selected from preservation manifests. If an actual
# location still contains those exact bytes, select it once and alias its mirror.
selected, preserved_aliases, historical = {}, [], []
def select(p):
    row = record(p, OWN)
    old = selected.setdefault(row['path'], row)
    assert old == row
    return row

for attempt in ['attempt1-originals', 'attempt2-originals', 'attempt3-originals']:
    ap = OWN / attempt
    pm = read(ap / 'preservation-manifest.json')
    select(ap / 'preservation-manifest.json')
    leaves = pm.get('all_files', pm.get('files'))
    assert len(leaves) == pm['file_count']
    for row in leaves:
        archived = ap / row['path']
        assert sha(archived) == row['sha256'] and archived.stat().st_size == row['bytes']
        original = OWN / row['path']
        target = original if original.is_file() and sha(original) == row['sha256'] else archived
        select(target)
        if target != archived:
            preserved_aliases.append({'archived_path': str(archived.relative_to(OWN)),
                'selected_path': str(target.relative_to(OWN)), 'bytes': row['bytes'], 'sha256': row['sha256']})
    historical.append({'attempt': attempt, 'preservation_manifest': record(ap / 'preservation-manifest.json', OWN),
                       'preserved_leaf_count': len(leaves)})

# Current run leaves are named by its actual result plus the exact sixteen
# downloaded module leaves, rather than selecting an output directory.
select(checks_path)
for row in checks['screenshots']:
    select(OWN / row['path'])
for viewport in ['desktop', 'mobile']:
    for step in range(1, 7):
        p = OWN / f'browser-output-v4/candidate/{viewport}-step-{step}-full-module.lean'
        assert sha(p) == (PSHA if step <= 3 else TSHA)
        select(p)
    for label, h in [('P', PSHA), ('T', TSHA)]:
        p = OWN / f'browser-output-v4/candidate/{viewport}-complete-{label}.lean'
        assert sha(p) == h
        select(p)
for name in ['process-receipt.json', 'stdout.raw', 'stderr.raw']:
    select(OWN / 'browser-process-v4/candidate' / name)

visual_names = [
    'desktop-proof-initial.png', 'mobile-proof-initial.png', 'mobile-step-6.png',
    'desktop-source-T-anchor.png', 'mobile-source-T-full.png',
    'mobile-source-T-glyph-segment-3.png', 'mobile-graph-default-fit-selected.png',
    'mobile-graph-public-P-actual-UI-zoom-pan.png', 'mobile-parent-3-detail.png',
    'desktop-step-3.png', 'mobile-formula-0-right-end.png', 'mobile-source-index.png',
    'desktop-graph-detail-reader-and-edges.png']
glyphs = [x for x in checks['checks'] if 'last-source-glyph-actually-visible' in x['name']]
assert len(glyphs) == 4
for x in glyphs:
    d = x['detail']
    assert d['selectedGlyph'] == ('d' if '-P-' in x['name'] else 's')
    assert d['lastGlyphWidth'] > 0 and d['lastGlyphHeight'] > 0
    assert d['glyphVerticallyVisible'] and d['lineVerticallyVisible']

report = {
    'schema': 'weighted-MGF-independent-native-runtime-interpretation-v1',
    'utc': dt.datetime.now(dt.timezone.utc).isoformat(),
    'status': 'ACCEPTED_BOUNDED_FROZEN_READER_V2_WITH_EXPLICIT_GRAPH_LIMITATIONS;NO_NORMAL_V',
    'actual_process_invoker': 'ROOT', 'interpreter': '/root/gaussian_push_audit_c7b1',
    'native_actor_aborted_prior_approval': 'One request aborted after1854.3s; no execution/start/session evidence; not counted as a browser run.',
    'actual_current': {'checks': record(checks_path, OWN), 'process': record(receipt_path, OWN),
        'check_count': 343, 'false_count': 0, 'PNG_count': 86, 'exit_code': 0, 'exception': None,
        'elapsed_seconds': receipt['elapsed_seconds'], 'raw_stdout': receipt['stdout'], 'raw_stderr': receipt['stderr'],
        'all86PNG_hashes_reverified': True, 'all373_frozen_contract_inputs_reverified': True,
        'all16_actual_downloads_equal_P_or_T': True},
    'identity': {'math_candidate': checks['mathematical_candidate'], 'P_sha256': PSHA, 'T_sha256': TSHA,
        'reader': checks['reader_identity'], 'observed_live_HEAD_before': receipt['root_HEAD_before'],
        'observed_live_HEAD_after': receipt['root_HEAD_after'], 'Chrome': checks['actual_chrome'],
        'viewports': contract['viewports'],
        'build_boundary': 'Native fresh closure/type+value/kernel/axiom execution belongs to Git4869 archived bytes. Neither browser observedHEAD56f8 nor a later carrier is relabelled as a newly compiled HEAD.'},
    'coverage': [
        'Desktop1440x1000 and mobile390x844: rendered formulas, layered folds and assumptions, six exact code disclosures partitioning P121+T159 source lines.',
        'All six adjacent actions per viewport: P/P/P/T/T/T source identity, exact displayed-code clipboard, actual complete-module downloads, real source navigation and line anchors below header.',
        'Complete P/T source DOM text and every source line layout; filename/header, exact complete-source clipboard/download; positive-width last actual glyph and horizontal reach.',
        'Mobile eight overflowing formula endpoints and source assumption table actually scrolled; no document horizontal overflow.',
        'Actual source-index to reader to Lean graph navigation; five selected parent/private-module detail and local source/reader navigations; solid formal versus dashed curated-source edges.'
    ],
    'actual_visible_glyph_measurements': glyphs,
    'native_actor_actual_PNGs_read': [record(OWN / 'browser-output-v4/candidate' / n, OWN) for n in visual_names],
    'visual_findings': [
        'Rendered formulas and readable prose/folds are present; long mobile formula/code/source rows use contained horizontal scroll. Screenshots show sampled viewports, not all280 code lines simultaneously.',
        'Source T filename is visible and wraps; source anchor and final visible characters are reachable below the mobile header.',
        'Default-fit graph is an overview: SVG labels are too small for full reading. Existing actual UI zoom/pan enlarges labels, but long SVG labels retain ellipses and mobile nodes can be clipped.',
        'Exact full node IDs and source/parent links are readable through the actual detail inspector. Acceptance is for this bounded overview plus zoom/pan and inspector flow, not default-fit full-label legibility.',
        'Frozen preview truth strips and PARTIAL/TODO statuses are pre-V snapshot metadata, not production publication or a newly recorded Lean gate.'
    ],
    'historical_real_failures_retained': [
        {'version': 'v1 original', 'exit_code': 1, 'PNG_count': 24, 'failure': "Own report serializer KeyError reader_commit; no actual-checks.json existed, no pass/fail flags reconstructed."},
        {'version': 'v2 original', 'checks': 162, 'false_count': 15, 'PNG_count': 24, 'failure': 'Twelve missing adjacent controls, mobile table/body overflow, blocked external Google font request.'},
        {'version': 'v2 candidate reader-v1', 'checks': 228, 'false_count': 12, 'PNG_count': 50, 'failure': 'Runtime highlighter destroyed source span anchors; actual navigation/source line timeouts retained.'},
        {'version': 'v3 candidate reader-v2', 'checks': 343, 'false_count': 8, 'PNG_count': 86, 'failure': 'Own final-glyph measurement selected retained LF; width0. Raw flags and PNGs retained.'}
    ],
    'v4_change_scope': 'Only measurement input selects final nonwhitespace actual UTF16 glyph and records glyph/offset/codepoints; all42 check ASTs and positive width/height/header/horizontal/vertical conditions unchanged. Unique output/process dirs; no reader input changes.',
    'fresh_source_visual_review': {
        'actor': '/root/mgf_fresh_source_5b7e', 'status': 'ACCEPTED_BOUNDED_READER_V2_NATIVE_V4',
        'report': record(ROOT / '.astis/semantic-neutral-20261114/mgf_fresh_source_5b7e/phase12_final_native_visual/final-reader-v4-independent-review.md', ROOT),
        'verdict': record(ROOT / '.astis/semantic-neutral-20261114/mgf_fresh_source_5b7e/phase12_final_native_visual/current-reader-independent-verdict.json', ROOT),
        'own_read_boundary': 'Native actor read this separate report; its54 viewed current PNGs are the fresh actor own observations, not attributed to native actor. ROOT separately carries its explicit originals.',
        'rendered_source_attribution_boundary': 'Actual rendered unit-source links and source-context drilldown were checked; generic renderer does not consume the per-step source_attribution metadata. No per-step metadata runtime-consumption claim.'},
    'exclusions_and_boundaries': ['No Chrome/Python/venv/package cache copied.', 'No full workspace/index/foreign-state guard or all-tracked map selected.',
        'Local frozen reader overlay only; not shared/production renderer change, whole-site deployment, main integration or whole Goal completion.',
        'No new Chrome, Lean, metadata gates or normal API/V calls in this finalization. Future V requires immutable pre-V carrier and specific once-only ROOT authorization.']
}
report_path = write('runtime-bounded-acceptance-report.v1.json', report)

# Portable reader leaves come only from exact frozen manifests and explicit
# top-level generator/overlay/render-receipt names. No recursive directory walk.
replay_roots = {
    'reader_preview_v1': W / 'reader-preview-v1',
    'reader_preview_v2': W / 'reader-preview-v2',
    'ROOT_render_receipts': ROOT / '.astis/huanjian-resume-20261103',
    'native_frozen_math': NATIVE / 'candidate-4869db55',
}
replay_files = {}
def replay_select(root_id, relative, expected=None):
    row = record(replay_roots[root_id] / relative, replay_roots[root_id])
    if expected:
        assert row['sha256'] == expected['sha256']
        if 'bytes' in expected: assert row['bytes'] == expected['bytes']
    row = {'root': root_id, **row}
    assert (root_id, row['path']) not in replay_files
    replay_files[root_id, row['path']] = row

for version in [1, 2]:
    rid = f'reader_preview_v{version}'
    base = replay_roots[rid]
    im, fm = read(base / 'input-freeze-manifest.json'), read(base / 'preview-freeze-manifest.json')
    tops = ['input-freeze-manifest.json', 'preview-freeze-manifest.json', 'render_preview.py', 'reader_overlay.py']
    tops += (['preview-design-manifest.json', 'static-comparison-report.v1.json', 'render-process.v1.receipt.json',
              'render-process.v1.stdout.raw', 'render-process.v1.stderr.raw'] if version == 1
             else ['anchor-repair-proposal.v2.json', 'reader-overlay.v1-to-v2.exact.diff'])
    for name in tops: replay_select(rid, name)
    assert len(im['files']) == 120
    for row in im['files']: replay_select(rid, 'input-snapshot/' + row['path'], row)
    for variant in ['original', 'candidate']:
        assert len(fm['variants'][variant]['files']) == (109 if variant == 'original' else 110)
        for row in fm['variants'][variant]['files']:
            replay_select(rid, f'fixtures/{variant}/' + row['path'], row)
    for row in fm['changed_files']: replay_select(rid, row['diff'])

for name in ['20261114T085512527140Z-matrix-mgf-reader-v2-minimal-anchor-repair-render.receipt.json',
             '20261114T085512527140Z-matrix-mgf-reader-v2-minimal-anchor-repair-render.log']:
    replay_select('ROOT_render_receipts', name)
for name, h in [(PFILE, PSHA), (TFILE, TSHA)]:
    replay_select('native_frozen_math', name, {'sha256': h})
replay_manifest = {
    'schema': 'weighted-MGF-explicit-reader-replay-multiroot-manifest-v1',
    'status': 'FROZEN_EXPLICIT_ALLOWLIST;NO_PACKAGE_CACHE_OR_GUARDS',
    'roots': {k: {'original_local_root': str(v), 'portable_root_locator': 'reader-replay/' + k} for k, v in replay_roots.items()},
    'selection': 'Only each120-entry input manifest,109/110 fixture manifests,listed changed-file diffs,explicit generator/overlay/top receipts and2 frozen native math leaves. No directory traversal selection.',
    'files': sorted(replay_files.values(), key=lambda x: (x['root'], x['path'])),
    'file_count': len(replay_files), 'total_bytes': sum(x['bytes'] for x in replay_files.values()),
    'native_math_portable_relation': [
        {'native_root': 'native_frozen_math', 'path': f, 'sha256': h,
         'same_reader_input_paths': [{'root': f'reader_preview_v{v}', 'path': 'input-snapshot/' + f} for v in [1, 2]],
         'native_originals_manifest': '../native-selected-originals.manifest.v1.json'} for f, h in [(PFILE, PSHA), (TFILE, TSHA)]],
    'environment_not_packaged': ['Installed Chrome157.0.8103.51', 'Python3.12.4 browser environment and Playwright', 'Python standard library plus frozen renderer Python inputs', 'No Lean/package environment needed merely to inspect/replay these frozen reader fixtures'],
    'renderer_replay_boundary': 'Existing input-freeze-manifest+all120 snapshot files select the renderer frozen-input branch. OLD_MANIFEST and Git4869 reachability are not required by that branch. Preserve raw historical paths; a relocated replay must explicitly map roots on copies, never modify evidence originals.',
    'browser_replay_boundary': 'Historical browser scripts contain original absolute root/environment locators. Restore these locators or explicitly adapt copies with recorded diff for relocation; preserved actual run receipts are not regenerated. Run only after separate execution authorization.'
}
replay_path = write('reader-replay-selected.manifest.v1.json', replay_manifest)

readme = OWN / 'RUNTIME-CUSTODY-AND-REPLAY.md'
assert not readme.exists()
readme.write_text('''# Frozen weighted MGF reader evidence\n\nROOT invoked every actual Chrome run. The native actor authored the harness and independently interpreted raw results and selected PNGs; sourcefresh independently reviewed the reader and images. The native actor\'s earlier1854.3s aborted approval has no browser execution evidence.\n\nv1 original crashed in the report serializer after24 PNGs, with no reconstructed check flags. v2 original retained15 failures; v2 candidate retained12 anchor failures. Author reader-v2 changed only six source code classes to preserve line IDs. v3 retained eight LF-probe failures. v4 changed only the measured actual final glyph and versioned output identity;343 checks passed with86 real PNGs and exit0. All preceding failures remain selected.\n\n`runtime-selected-originals.manifest.v4.json` lists each selected leaf relative to this runtime root with exact bytes/SHA256. `preservation_aliases` maps omitted attempt mirrors to selected byte-identical actual leaves; archived scripts whose original pathname changed remain selected under their attempt directory. Follow aliases to reconstruct full historical attempt layouts. The manifest itself is carried separately and is not self-hashed.\n\n`reader-replay-selected.manifest.v1.json` uses explicit root IDs and per-leaf relative locators. Restore each root into its listed portable locator, preserving all frozen bytes. It includes both frozen native P/T source leaves used by the actual harness, both120-input snapshots, both original/candidate fixtures, generators/overlays/diffs and actual render receipts. Existing renderer input-freeze manifests select the archived-input branch; OLD_MANIFEST and Git4869 reachability are not needed. No whole old worker directory is required.\n\nChrome, Python, venv/Playwright and package caches are environment dependencies, not archived payloads. Actual Chrome binary/version hashes and Python executable/version are in process receipts. Historical scripts include absolute original root/environment locators: a relocated future replay must explicitly map those roots or change copies with its own recorded diff and authorization; do not rewrite evidence or present replay as the original run. No Chrome or server is started by these manifests.\n\nAcceptance covers this localhost frozen reader overlay at desktop1440x1000/mobile390x844. Default-fit graph labels are too small for full reading; real UI zoom/pan enlarges still-ellipsized labels and may clip mobile nodes. Exact full IDs are available in the actually used detail inspector. No default-fit full-label readability, production publication, whole-site acceptance, main integration or whole Goal completion is claimed. Native Lean checks belong to Git4869 bytes, not later metadata/carrier commits. No normal V is performed here.\n''')

for name in ['browser_check.py', 'browser_extensions.py', 'independent-browser-contract.v1.json',
    'independent-browser-contract.v2.json', 'independent-browser-contract.v3.json', 'independent-browser-contract.v4.json',
    'browser-check.v1-to-v2.exact.diff', 'browser-check.v2-to-v3.exact.diff', 'browser-check.v3-to-v4.exact.diff',
    'browser-contract.v1-to-v2.exact.diff', 'browser-contract.v2-to-v3.exact.diff', 'browser-contract.v3-to-v4.exact.diff',
    'browser-v2-reporter-selfcheck.json', 'browser-v3-static-selfcheck.json', 'browser-v4-visible-glyph-selfcheck.json',
    'reader-freeze-verification.v1.json', 'reader-v2-minimal-anchor-repair-verification.json',
    'verify_reader_freeze.py', 'verify_reader_v2_delta.py', 'verify_reader_v2_delta.attempt1.original.py',
    'original-runtime-interpretation.v1.json', 'candidate-runtime-failure-diagnosis.v1.json',
    'runtime-failure-originals-selected.manifest.v2.json', 'normalV-plan.draft.v2.json',
    'runtime-bounded-acceptance-report.v1.json', 'reader-replay-selected.manifest.v1.json',
    'RUNTIME-CUSTODY-AND-REPLAY.md', 'finalize_runtime_evidence.py']:
    select(OWN / name)
manifest = {
    'schema': 'weighted-MGF-explicit-runtime-selected-originals-v4',
    'status': 'FROZEN_ACTUAL_V1_V2_V3_FAILURES_AND_BOUNDED_V4_PASS;NO_NORMAL_V',
    'root': str(OWN), 'portable_root_locator': 'native-runtime',
    'files': sorted(selected.values(), key=lambda x: x['path']),
    'file_count': len(selected), 'total_bytes': sum(x['bytes'] for x in selected.values()),
    'preservation_aliases': preserved_aliases, 'historical_attempts': historical,
    'actual_current_result': record(checks_path, OWN),
    'actual_current_process': record(receipt_path, OWN),
    'bounded_report': record(report_path, OWN), 'reader_replay_manifest': record(replay_path, OWN),
    'manifest_self_inclusion': False,
    'excluded': ['chrome-tmp', '__pycache__', 'Installed Chrome/Python/venv', 'Lean/package caches',
                 'Full workspace/foreign-state/all-tracked guards or raw index', 'Unselected filesystem leaves'],
    'selection_algorithm': 'Explicit preservation-manifest leaves plus result screenshot list,16 known actual module downloads,3 process leaves and explicitly named version/report files. No directory enumeration used for selection.',
    'unchanged_source_and_scope': 'Only this finalizer/report/manifests/README written. Frozen harness,contracts,fixtures,production,index,refs,ledgers unchanged; no browser/build/API call.'
}
assert all(not any(part in ['chrome-tmp', '__pycache__', '.lake'] for part in Path(x['path']).parts) for x in manifest['files'])
manifest_path = write('runtime-selected-originals.manifest.v4.json', manifest)
print(json.dumps({'report': record(report_path, OWN), 'runtime_manifest': record(manifest_path, OWN),
    'runtime_files': manifest['file_count'], 'runtime_bytes': manifest['total_bytes'], 'mirror_aliases': len(preserved_aliases),
    'reader_replay_manifest': record(replay_path, OWN), 'reader_files': replay_manifest['file_count'],
    'reader_bytes': replay_manifest['total_bytes'], 'new_browser_build_API_calls': 0}, indent=2))
