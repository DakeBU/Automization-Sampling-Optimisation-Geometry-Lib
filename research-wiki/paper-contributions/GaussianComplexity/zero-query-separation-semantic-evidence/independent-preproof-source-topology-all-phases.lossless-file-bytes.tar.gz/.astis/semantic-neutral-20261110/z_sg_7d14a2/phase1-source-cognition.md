# Phase 1 raw-source cognition freeze

This is a source author's reconstruction, not an implementation audit, proof, topology review, or verifier verdict. The exact target statements remain withheld. The original local HTML is primary; its exact bytes are duplicated as `raw-original.html`. `raw-fragment-index.json` supplies zero-based UTF-8 byte offsets and hashes; the five selected fragment files preserve exact raw HTML. The text files are explicitly derivative conveniences.

## Source conclusion and scope

The selected zero-query argument uses the Section 3 range: every integer dimension d ≥ 1, κ ≥ 4, and 0 < ε ≤ 1/16. An algorithm has a deterministic integer cap T and has output law ρ_A, averaged over all its seed, within TV distance ≤ ε of π_A for every A in the precision class. The source concludes **T ≥ 1**.

The source precision class is symmetric A with I_d ≼ A ≼ κI_d, and π_A = N(0,A⁻¹). The matrices are A₀ = I_d and A₁ = diag(κ,1,…,1). The zero-query algorithm has a common output law on these two inputs because its output can depend only on the input-independent seed when there are no responses. Borel dependence supplies an actual probability law. Uniform accuracy applies to both matrices.

For the event E = {|x₁| ≤ 1/2}, the source gives exactly

TV(π_A₀,π_A₁) ≥ 2∫_(1/2)^1 exp(−t²/2)/√(2π) dt ≥ exp(−1/2)/√(2π) > 1/8 ≥ 2ε.

It then invokes the triangle inequality to contradict the two accuracy bounds under the common output law. The strict > 1/8 comparison matters: the source allows ε = 1/16, and the accuracy condition is ≤ ε. The event uses ≤, not <.

The first-coordinate variances are 1 and 1/κ, so the second event probability integrates the standard normal density up to √κ/2. κ ≥ 4 places this endpoint at least at 1. The relevant event difference is π_A₁(E) − π_A₀(E) ≥ 0. The interval [1/2,1] has length 1/2; the displayed leading factor 2 cancels that length in the constant-density lower bound. These facts are omitted standard bridges of the source's displayed chain, not new public premises. The exact normalization is exp(−t²/2)/√(2π), not an arbitrary Gaussian kernel.

All natural dimensions d ≥ 1 are included. For d = 1, A₁ is simply [κ], and E is a set of the sole coordinate. No second coordinate, determinant-sign prior, or nontrivial orthogonal component is needed. The class has spectral inequalities, not exact prescribed smallest/largest eigenvalues. In particular, the one-dimensional matrix remains in the class even though its actual condition ratio is 1.

## Adjacent separate branch

The remainder of the same source paragraph says: if 2T + 1 > d, integrality gives T ≥ d/2, which proves the main theorem bound in that branch; henceforth assume 2T + 1 ≤ d. This is a separate conditional integer case. It is covered in this packet because its sentence shares the source paragraph block. It is not folded into the zero-query separation root.

The full main Theorem 3.1 has RHS (1/256) min{d, √κ log(1+d/(√κ ε))}. It is retained only as context and remains unclosed here. The easy branch dominates its RHS using min{d,…} ≤ d. The residual case is outside the selected extraction. No prior global graph, fixed-spectrum route, disclosed-eigenbasis route, frontier, seal, or verdict was opened, reset, or relabelled.

## Source topology and omissions

`source-graph.json` gives source-use edges with consumer locations. The zero-query proof has one displayed sufficient route; no source alternative proof is supplied. Its ingredients are the class/target definitions, input-independent Borel algorithm model, the two admissible matrices, Borel event, normalized Gaussian marginal/scaling calculation, integral lower bound, strict scalar numerical comparison, uniform accuracy, TV triangle inequality, and nonnegative-integer budget endpoint. These remain dependency edges. They are not additional source hypotheses.

`background-and-gap-ledger.json` distinguishes the explicitly author-invoked triangle inequality from omitted standard bridges. “SOURCE_GAP” here means an omitted mathematical bridge in the selected passage, not a claim that the source is false or needs repair. The source does not calculate the strict scalar numerical inequality or prove normal normalization/marginal facts in this passage. No independent proof of these leaves, no substitute route, and no source repair is supplied by this author.

`source-coverage.json` accounts for all 21 substantive paragraph/display units and all 65 math elements in the selected raw fragments. Haar/determinant-conditioned preliminaries, the exact positive-query response formula, and equivalence of positive-query oracle models are explicitly excluded from this extracted proof's dependencies. Mathematical context retained in a node is distinguished from the exact part used by an incoming source edge. There are no external citations in the selected fragments. Structural HTML and duplicated MathML/TeX renderings are excluded as presentation structure while their exact raw bytes remain preserved.

The source author's root traces are in `root-closure-map.json`. Their pending standard leaves are visible. This does not certify implementation dependencies, complete a Lean theorem, approve the author's own topology, or close the full main result. A distinct raw-source topology/coverage challenger and the root prover still own their respective next steps.

## Independence and freeze boundary

`exposure-ledger.json` lists all actual inputs, incidental procedural names, raw-source lookahead, and the inability to guarantee absence of pretrained recognition. No target signature, actual Lean/proof source, prior graph, review, or verdict was supplied or opened. No network call, normal SAU/API execution, or shared truth mutation occurred. One duplicate extraction output briefly used a task-specific temporary file and was moved into the owned directory; this procedural deviation is recorded.

All packet files are frozen at mode 0444 after the manifest and receipt are generated. The receipt binds the exact manifest, and the manifest binds every payload's exact bytes and digest. Stop here before any target/implementation/old-review exposure. This packet is an authored Phase 1 source cognition freeze only.
