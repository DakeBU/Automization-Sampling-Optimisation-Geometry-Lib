from pathlib import Path
import hashlib,json,subprocess
r=Path.cwd();d=Path(__file__).resolve().parent;c='8ee639d3aced826aa5b4e39fa6f8bedd3b830327'; mp=d/'candidate/research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-target-law-semantic-evidence/source-to-lean-map-v1.json';j=json.loads(mp.read_text());res=[];blocks=[]
for row in j['rows']:
 l=row['lean'];p=l['file'];b=(r/p).read_bytes() if p.startswith('.lake/') else subprocess.check_output(['git','show',c+':'+p]);s=b.decode('utf-8');a=l['start_character_offset'];z=l['end_character_offset_exclusive'];block=s[a:z]
 checks={'file_sha256':hashlib.sha256(b).hexdigest()==l['file_sha256'],'block_sha256':hashlib.sha256(block.encode()).hexdigest()==l['exact_locator_block_sha256'],'bounds':0<=a<z<=len(s),'start_marker':block.startswith(l['exact_start_marker']),'end_marker':l['exact_end_marker_exclusive'] is None or s[z:].startswith(l['exact_end_marker_exclusive']),'start_line':s[:a].count('\n')+1==l['line']}
 res.append({'id':row['id'],'file':p,'start':a,'end':z,'checks':checks,'ok':all(checks.values()),'actual_file_sha256':hashlib.sha256(b).hexdigest(),'actual_block_sha256':hashlib.sha256(block.encode()).hexdigest()});blocks.append('\n## '+row['id']+' '+row['claim']+'\n'+block)
 if p.startswith('.lake/'):
  dest=d/'dependency-sources'/p.removeprefix('.lake/packages/');dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b)
(d/'map.exact-blocks.txt').write_text(''.join(blocks));report={'candidate':c,'map_sha256':hashlib.sha256(mp.read_bytes()).hexdigest(),'rows':len(res),'all_pass':all(a['ok'] for a in res),'results':res};(d/'map.check.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2));print('\nACTUAL SUBSTRATE BLOCKS\n'+''.join(blocks[11:27]))
