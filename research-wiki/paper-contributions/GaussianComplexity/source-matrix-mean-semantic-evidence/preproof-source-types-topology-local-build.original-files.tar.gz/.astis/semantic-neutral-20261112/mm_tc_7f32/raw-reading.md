# Preliminary raw reading: actual truncated matrix means and mean sums

This is the independent raw-reading freeze for a prospective next packet. No
final exact Statement Seal, binder/definition packet, new type or new source
graph has been received. These notes admit no signature, topology, proof or
Mathlib applicability. The later distinct role is source-topology/applicability
challenge after the exact seal; this is not a second formal graph extraction.

## Source and bounded reading

The original source is *On Complexity of Gaussian Sampling*, arXiv
2610.20492v1. The local pinned HTML has 951991 bytes and SHA-256
`6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915`.
I freshly read Appendix C.2 p1 through p12 in full, including the intervening
Fact C.5/C.6 statements, plus the original grid and independent-column standing
clause in Section 4. This expanded source reading does not include p13 onward.

The original experiment has r=q+1 independent standard d-Gaussian columns and
the actual physical row gamma_i=((g_1)_i,...,(g_r)_i). The source explicitly
asserts that the rows are independent N(0,I_r). The new mean claim uses their
actual common marginal law; joint independence is source context for later
concentration, rather than an additional premise needed to infer the separate
matrix means or deterministic sums of those means.

The deterministic source data are n=2q+1, theta_i=(i-1/2)pi/d,
t_i=(1,sqrt(2)cos(theta_i),...,sqrt(2)cos(q theta_i))^T,
R_i=||gamma_i||^2 and L=2r+3log(1000d). The source object is the unconditioned
closed-cutoff matrix

    Y_i=(1/d)(gamma_i gamma_i^T tensor t_i t_i^T) 1_{R_i<=L}.

Source p12 uses radial symmetry for

    E[gamma_i gamma_i^T 1_{R_i<=L}] = a I_r,
    a=(1/r) E[R_i 1_{R_i<=L}],

then explicitly states that a is the same for every i. It gives the actual
matrix mean E[Y_i]=(a/d)(I_r tensor t_i t_i^T), invokes Fact C.5 and states both
sum_i E[Y_i]=a I_(r^2) and sum_i cos(n theta_i)E[Y_i]=0. The final sentence says
the truncated weighted sum has zero expectation.

## Exact source locators

HTML IDs refer to the exact pinned bytes. Granular element span hashes,
UTF-8/codepoint offsets and inclusive LF lines are recorded in locators.json.

| Source locator | Role in this raw reading |
| --- | --- |
| `S4.E11`, lines 1090-1097 | Exact physical midpoint grid; eigenvalue/Lambda clauses share the display and remain outside the new mean conclusion. |
| `S4.Thmtheorem4.p1.1`, lines 1210-1214 | q>=0, 2q+1<d and independent N(0,I_d) columns; C/Krylov context is not a mean premise. |
| `A3.SS2.p1`, lines 3317-3329; `A3.Ex85` | r/n, physical index range, actual rows, exact features, common row law, B context. |
| `A3.Thmtheorem5`, lines 3340-3360; `A3.Ex87` | Fact C.5 includes both deterministic t outer-product sums needed by the two later mean sums. Its B-range and B-mean claims are separate context. |
| `A3.SS2.p4`, lines 3377-3396 | Actual half-grid and cosine-sum identity, including the nonzero sine denominator/frequency restriction. |
| `A3.SS2.p5`, lines 3397-3432 | Feature-coordinate convention 0,...,q; constant/mixed/product-to-sum entries and frequency checks yield sum_i t_i t_i^T=d I_r. |
| `A3.SS2.p7`, lines 3450-3496 | n=2q+1, all frequencies n plus/minus j plus/minus k in the required range, weighted cosine cancellation yields sum_i cos(n theta_i)t_i t_i^T=0. Its B-mean conclusion is separate context. |
| `A3.SS2.p10`, lines 3532-3556 | Literal R/L definitions, alongside a tail/common-event argument that is not an added premise. |
| `A3.SS2.p12.1`, line 3571; `A3.Ex107`, lines 3572-3578 | Original actual Y matrices and inclusive local cutoff. |
| `A3.SS2.p12.2`, line 3579; `A3.Ex108`, lines 3580-3586 | Radial-symmetry invocation, exact truncated row moment and exact scalar a definition. |
| `A3.SS2.p12.3`, lines 3587-3588 | Explicit common a across physical rows. E R_i=r and 0<=a<=1 concern bounds rather than the equality sought. |
| `A3.SS2.p12.4`, lines 3596-3598 | Exact actual E[Y_i] formula and direct consumer invocation of Fact C.5. |
| `A3.Ex110`, lines 3599-3605; `A3.SS2.p12.5`, line 3606 | Both exact mean sums and the concluding zero-expectation sentence. |

## Potential hidden premises, endpoints and dimensions

- d,q are natural and 2q+1<d includes q=0. Thus r=q+1 is nonzero and d is
  nonzero internally. No q>0, separate positive-d/r certificate or kappa/tau
  condition should enter a source-facing signature for these means.
- Physical indices are 1,...,d; feature coordinates are 0,...,q and column
  coordinates are 1,...,r. Any future zero-based physical index must retain
  i.val+1 in the angle. The Gaussian coordinate precedes the feature coordinate
  in gamma tensor t and in paired matrix indices.
- Each outer product is r by r, Y_i is r^2 by r^2, and the identity in the
  summed mean is I_(r^2), equivalently I_r tensor I_r. Finite matrix expectation
  must refer to the same actual entry carrier and probability measure as Y_i.
- The source scale is exactly inverse d. It is not d^{-1/2}, which occurs in
  the adjacent B-row definition, and it must not be absorbed into a differently
  normalized scalar a.
- The cutoff is R_i<=L, not a strict inequality. This is an unconditioned
  truncated expectation. The common event that all rows pass the cutoff is
  not used to condition the law or replace each row's local indicator. Dividing
  by a truncation-event probability would change the coefficient.
- The scalar a is a common value determined by the common actual marginal
  standard-Gaussian law and the same r,L. A future producer may express its
  exact canonical scalar expectation, but must internally identify it with
  this source a. It may not assume equal per-row coefficients as new data.
- At q=0, r=1 and t_i=(1); the weighted sum still has n=1 and the literal
  midpoint cosine weights. Both sums, rather than a vacuous nonconstant
  feature subcase, remain the prospective consumer.
- Measurability and integrability of the actual closed-cutoff row products,
  finite matrix maps and scalar retained radius are internal obligations under
  the fixed Gaussian/product law. They cannot be replaced by new public
  integrability, row-law, row-mean, matrix-mean or finite-sum certificates.
- No independence premise is needed just to pass from individual mean
  identities to sums of means. A proof of the expectation of an actual sum,
  if that is the sealed consumer, must also discharge the applicable finite
  expectation-linearity conditions internally. The two formulations must not
  be silently exchanged before the exact seal.
- The common scalar bounds 0<=a<=1, omitted-mass bound 1-a and the tail
  probabilities are not hypotheses for the exact matrix-mean or mean-sum
  equalities. There is no hidden positivity-of-a or invertibility-of-mean
  requirement.

## Preliminary omitted source bridges for later sealed review

These are raw-reading concerns only, not admitted source-graph nodes or proved
edges:

1. The printed actual-row law must connect the source's literal gamma_i on
   the independent-column sample to the canonical r-dimensional Gaussian row
   moment. Expectation transport must retain the actual row map, the actual
   product sample measure and the exact cutoff integrand. The task does not
   request a theorem quantified over arbitrary extended ambient experiments.
2. Radial symmetry at Ex108 omits the full well-definedness/integrability and
   coefficient-identification argument. If an exact canonical moment result is
   reused, all hypotheses needed to apply it to the literal source integrand
   and transport it to the actual sample must be internally discharged. No
   existing record or theorem name is itself an applicability proof here.
3. The passage to E[Y_i]=(a/d)(I_r tensor t_i t_i^T) omits expectation transport
   and finite matrix-entry/tensor/scalar algebra. It must preserve Gaussian-first
   pair order, source inverse-d and inclusive cutoff. An abstract matrix with
   a supplied mean is not the actual source Y_i.
4. The direct Fact C.5 use in p12 needs the two deterministic feature sums,
   their exact n/grid/index conventions, and finite algebra turning d I_r into
   a I_(r^2) after the inverse-d normalization. The B-range or untruncated
   B-moment identities are not substitutes for those deterministic identities.
5. The final zero-expectation sentence and the displayed weighted sum of
   expectations require the usual internal finite-linearity bridge if a
   consumer is stated as an integral of the actual weighted sum. The exact
   selected endpoint awaits the seal and cannot be inferred from a planned
   consumer name.

## Exclusions, prior exposure and chronology

The reading includes p1-p12 in full. Range/B/Krylov, B-moment and concentration
claims in that window are source context rather than new conclusions. Tail,
common-event probability, bias-loss and scalar-a bounds are not new target
premises. No p13-onward PSD/variance/higher-moment/Bernstein/main-bound proof
was read in this phase.

This actor is independent of the prospective source-graph extractor, but is
not pristine to the paper: its completed R7 raw/type/topology work previously
exposed p1-p12, including mean formulas as then-excluded context. A separate
bounded conceptual packet also supplied metadata for the existing radial moment
correspondence, including the Ex108 formula and its actual-matrix-mean consumer
statement. That prior exposure is disclosed in exposure.json. It does not
constitute an API/implementation reading or an applicability result for this
new target. No new SG notes, other review verdicts, target types, APIs or
implementation have been opened in this phase.

The earlier R7 exclusions do not determine this new scope: n, the two
deterministic feature sums, the canonical-to-actual moment connection and the
actual matrix means are now pertinent source content. No prior topology
acceptance is replayed. All R7 artifacts remain byte-identical. This raw freeze
now stops pending the exact new seal and binder/definition packet.
