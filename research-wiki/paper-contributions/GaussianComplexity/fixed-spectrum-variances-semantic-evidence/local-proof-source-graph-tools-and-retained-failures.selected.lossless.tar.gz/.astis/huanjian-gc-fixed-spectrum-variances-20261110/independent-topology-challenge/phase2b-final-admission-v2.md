# Exact variance source topology and coverage admission v2

**ACCEPT_PREPROOF_SOURCE_TOPOLOGY_COVERAGE_ROOT_CLOSURES for the exact strict v2 interface and the exact machine graph identified below. No outstanding admission HOLD was found.** Prospective target proof/API work may proceed after this admission, with root remaining the sole mathematical worker and the recorded preseal API-exposure deviation retained. This decision is not a pristine-order certificate, mathematical proof, implementation-use check, compilation result, source V, or completion credit.

## Exact scope and authority

The semantic authority is the pinned 951991-byte raw HTML SHA-256 `6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915`, this actor's previously frozen independent raw cognition, and strict projection v2 SHA-256 `76136b7367d19fd1b98583adc5f4fae17330a817ad2c1a330300e399b0925b85`. Strict v2 statement/binder/definition admission was already frozen at `SHA256SUMS.phase2a-judgment-v2`, SHA-256 `3cca871484f5b54af1cde49743edbf990a7f2825ea6f7d646f24fffcb91181f9`. Its full-seal hash is a projection binding; no full seal was opened.

Only the six authorized JSON machine inputs under `independent-source-graph/v2-scope-correction/` were read:

| Input | SHA-256 |
| --- | --- |
| source-proof-graph-v2.json | 924e4c7073589434c4463c1e1fd29884ec0318b9cb9c75dd932fd74cbba44bf3 |
| exact-target-coverage-v2.json | 93f4a7cc11863bfaccc6a43a1d3462f346c12ed8338adeb21de66eace5c0554f |
| root-closures-v2.json | 4b1f0272827f9b61ae2b00078be328a9a888d9109522854c762ade62bc526a6e |
| machine-inputs-v2.json | dbaf95e4a4c9424a1eeae6cc753bf63552e9ff6a7696e114679c08ebf65d78a7 |
| freeze-v2.json | 55e4e0f6c59f6c615efca5f911e278ecf6bc99342fb0c9b9b30d2ebdd9740bf2 |
| binding-lineage-v2.json | 7cfc0cde1ba40ba3bfefab764bfb6ced8b6b2f5ed398bb6cf09636f00c32b324 |

The freeze/lineage metadata necessarily revealed filenames and reported statuses of excluded private artifacts. Those contents were not opened, and creator verdicts were not used as mathematical evidence. Historical component hashes were used as lineage bindings only. The current canonical components were independently rehashed against those bindings; no claim is made here to have opened historical private records to prove their asserted content. All of this actor's earlier raw, v1 HOLD, process audit and v2 statement checksum members were rechecked unchanged.

## Independent raw coverage reconstruction

Using this actor's frozen raw-only parser, I independently enumerated the graph's stated bounded coverage: S4 lines 1054–1500, the cited bibliography entry at 1847–1864, and complete C.3 at 3837–4134. This is the S4 statement/proof slice through its contradiction, not full S4 beyond that boundary. Every originally requested variance/contrast source anchor lies within it; C.3 is complete.

The resulting source traversal has exactly **294 units in the same raw order**, with no missing or extra unit: 68 paragraphs, 43 paragraph containers, 37 display tables, 47 TBODY units, 8 theorem blocks, 4 proof blocks, 24 headings, 12 section containers, 4 citations, 46 internal-reference occurrences and one bibliography entry. All 294 line-slice hashes match actual raw bytes. Graph hashes are whole original-line slices, distinct from this actor's earlier exact outer-element byte hashes; both conventions remain explicit.

All math attachment tuples (ID, original line, TeX, display mode) and all reference tuples (line, href, title, text) were rebound directly to raw elements. The 1103 attachment occurrences preserve **263 unique math IDs**, exactly the scoped raw union, including all 173 IDs in this actor's narrower frozen raw inventory. Text differs only in renderer whitespace at recorded ordinals; no mathematical text changed. Every graph node has an exact-target coverage mapping, and each raw ordinal has exactly one NODE or reasoned EXCLUDED disposition: **30 NODE, 264 EXCLUDED**. Repeated math attachments under containers are provenance attachments, not duplicate mathematical obligations.

The two same-line synthetic link-ID collisions are losslessly retained: ordinals 31/33 distinguish the Eq11 and bibliography links on line 1112; ordinals 146/147 distinguish the Lemma4.3 and Lemma4.4 links on line 1388. Raw traversal order and exact href/text were independently checked. IDs alone would not suffice; the actual ordinal keys do.

Ex148 and Ex149 are separate named TBODY NODEs, with the full formulas bound to their raw rows. Ex25's variance fragment is a NODE while its mean fragment is explicitly excluded; the duplicated anonymous TBODY carries its containing-display exclusion. Mean resummation, normalized-bias/exponential estimates, algorithmic probabilities, Chebyshev/event/TV steps and historical citations have explicit target exclusions. Ex140's actual norm-mean clause and the closed-M formula are retained only as specified opaque prerequisites. Those exclusions do not erase their source text or award new proof credit.

## Source premises, definitions and internal obligations

The public Anchor still has only the original seven inputs: d/κ/n carriers, d≥2, κ≥2 and 1≤n<d. The grouped graph node `D_domain` is a domain aggregate; its kind string does not override the exact v2 binder audit's separate TYPING/STANDING/SOURCE classifications. No moment, independence, integrability, covariance/PSD, inverse, variance or M-upper result is promoted into a public premise.

The actual law is centered Gaussian with covariance **Λ⁻¹**, where Λ is the source diagonal precision. `G_spectrum_domain` and `G_actual_gaussian_validity` retain the positivity, diagonal-inverse, positive-definiteness and intended constructor semantics internally. The definition of a mapped Gaussian is not a free covariance certificate, and totalized square-root behavior is not used to skip these obligations.

The source p8.1 route is faithfully expanded: actual marginal second moments and Gaussian fourth moments, coordinate independence from diagonal covariance, measurability/independence after squaring, coordinate-square L2 and variance, finite weighted-sum variance and literal Euclidean/diagonal quadratic identities. Deterministic weights are squared in Ex149; both exact variance sums have factor 2 and denominator λᵢ². This is an actual Gaussian moment route, not a deterministic cosine-sum identification or a new C7/alias proof.

Actual L2 facts are outputs and internal dependencies. Separate norm and Q finite-variance guards justify integrability, centered L2 and real-variance/evariance.toReal conversion before using variance identities. No bound is accepted because `toReal(∞)=0`. `N_Z_L2` precedes the centered-triangle obligation, so the contrast's own finite variance is also internally justified without a circular variance argument.

All **16 SOURCE_GAP nodes have incoming internal routes**, and no SOURCE_GAP is a free leaf or theorem binder. They remain unproved tasks for the eventual proof. The source-backed opaque prerequisites are semantically about this same actual law and M; their separate evidence must match at proof integration. They cannot be replaced by arbitrary mean laws or callback certificates.

## Entire root closures and each output subroot

I recomputed the directed backward closures from route records, detecting no cycle in any component. Every listed edge is AND; no synthetic OR alternative or falsely sufficient coarse summary is supplied. Seven-output producer conjunction and four-output consumer projection have distinct roles. Source anchors and route-use-site anchor sets were recomputed and frozen alongside complete node/edge sets.

| Target/subroot | Nodes | AND routes |
| --- | ---: | ---: |
| actual norm-square L2 | 12 | 8 |
| actual Q L2 | 12 | 8 |
| exact norm-square variance | 18 | 14 |
| exact Q variance | 18 | 14 |
| norm-square variance ≤2M | 21 | 17 |
| Q variance ≤2M | 22 | 18 |
| 2M≤2d/√κ branch | 7 | 3 |
| entire producer P_root | 28 | 24 |
| actual contrast Z L2 | 28 | 23 |
| entire private consumer C_root | 33 | 27 |

The supplied producer and consumer closure node/edge sets, SOURCE_GAP sets and opaque-prerequisite sets exactly match the independent traversal. Producer leaves are only the original domain and three literal-object nodes. Consumer adds the literal contrast definition and explicitly assumed **non-Anchor** private τ domain. This does not create a sixth Source Anchor bin or imply the guards were proved.

Ex148/149 bounds follow their actual exact variance branches, elementary inverse/cosine comparisons and actual mean-sum bridge. The producer's final numeric upper bound has its own closed-M branch; it is not a premise of either ≤2M estimate. Fact C7, finite-grid alias/resummation machinery and signed μ_n are not new obligations behind the explicitly opaque prior M formula. No new source credit is claimed for them.

The private projection AND-requires both new actual L2 outputs and both new ≤2M outputs. Its minimal mathematical closure does not require the closed-M upper branch or the entire bundled producer root. A later implementation may apply the bundled producer and project the four needed outputs; that is a Lean dependency, not a reason to invent a source-necessity edge for the unused upper output. Actual material use remains a postproof check.

The centered L2 triangle/homogeneity route is valid for the generally dependent whole statistics Q and norm-square. The graph never assumes their independence. The private n range remains 1≤n<d, with unit sign magnitude for every such mode; oddness/query assignment is not silently imposed. The only extra private domain is arbitrary 0≤τ≤1/2, explicit as assumed locally. No β, signed mean identity, τ≤β/4, Mβ²≥320 or 2d/√κ bound is needed for this variance-only private conclusion.

The context-only concrete-parameter and large-d nodes preserve the original source conditional guard origin, without feeding that context into either target closure or pretending to discharge the private assumptions. The context edge is not a certificate of a concrete q/δ/large-d selection. Those original conditions remain later application obligations.

## Actual versus rotated law and unclaimed conclusions

The graph does not transport diagonal U results to arbitrary rotated Y by assertion. S_A's polynomial sign/contrast formula and T_n(cosθ)=cos(nθ) are provenance for the numerical adapter; the orthogonal-conjugation, rotated-law and matrix-polynomial adapters remain outside this target. No Haar average, random-rotation independence or x≠0 condition is imported into the actual diagonal variance statements.

The source's ≥0.99 algorithm event and ≥0.9 target event are distinct excluded conclusions. Ex25 mean separation needs τ≤β/4 and the signed mean; Ex26 additionally needs positive mean and Mβ²≥320. Neither is smuggled into the generic variance closure or falsely claimed to follow from VarZ≤8M alone. No full Ex25, Chebyshev, TV contradiction, query lower bound or whole-paper credit is admitted.

## Preserved process limitation and stop boundary

The independent raw cognition preceded the strict projection; v1 statement judgment preceded detailed process disclosure; corrected v2 judgment preceded these graph inputs. Prior C7/grid/means context and root-relayed matching classification HOLD were disclosed. No zero-cue or verdict-blind claim is made.

The separate frozen process audit records an accidental broad preseal variance API-name/initial-signature-line query. That is a retained ordering deviation. Its no-proof-body/no-target-authorship assertions are attributed to the disclosure, without opening forbidden logs or implementation to prove negative claims. This topology admission permits **prospective** work on the admitted interface; it does not retroactively erase that exposure or certify pristine ordering.

No target proof/API retrieval, Lean compilation/build, normal transition, source V, Goal/queue credit, shared-model/frontier/site/ledger mutation, browser or network action was performed. No extractor private cognition, generator, evidence prose, statement-audit verdict file, full seal, root proof plan, actual API inventory, implementation or lesson was read. The bounded checker is structural/source identity only; its PASS is not a mathematical proof. The actual proof and all internal gaps remain the sole root worker's future obligations. This review stops here.
