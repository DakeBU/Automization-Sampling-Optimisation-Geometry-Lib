"""Own foreground subprocesses, exact argv and original streams."""
import datetime, hashlib, json, pathlib, subprocess, time, sys
ROOT=pathlib.Path(__file__).resolve().parent
REPO=ROOT.parents[2]
def sha(b): return hashlib.sha256(b).hexdigest()
def run(label,argv,*,cwd=None,env=None,timeout=240):
    out=ROOT/'receipts';out.mkdir(exist_ok=True)
    assert not (out/(label+'.json')).exists(),label
    before=subprocess.run(['git','rev-parse','HEAD'],cwd=REPO,capture_output=True,check=True).stdout.decode().strip()
    start=datetime.datetime.now(datetime.timezone.utc).isoformat();t=time.monotonic()
    try:p=subprocess.run(argv,cwd=cwd or REPO,env=env,capture_output=True,timeout=timeout)
    except subprocess.TimeoutExpired as e:p=subprocess.CompletedProcess(argv,124,e.stdout or b'',(e.stderr or b'')+b'\nTIMEOUT\n')
    streams={}
    for name,b in [('stdout',p.stdout),('stderr',p.stderr)]:
        f=out/(label+'.'+name);f.write_bytes(b)
        streams[name]={'path':str(f.relative_to(ROOT)),'bytes':len(b),'sha256':sha(b)}
    rec={'argv':argv,'cwd':str(cwd or REPO),'HEAD_at_start':before,'started_utc':start,'elapsed_seconds':time.monotonic()-t,'exit_code':p.returncode,**streams}
    if env:rec['LEAN_PATH']=env.get('LEAN_PATH')
    (out/(label+'.json')).write_text(json.dumps(rec,indent=2)+'\n')
    print(json.dumps({'label':label,'exit':p.returncode,'stdout_bytes':len(p.stdout),'stderr_bytes':len(p.stderr)}),flush=True)
    return p
if __name__=='__main__':sys.exit(run(sys.argv[1],sys.argv[2:]).returncode)
