from pathlib import Path
import difflib, hashlib, json
W = Path(__file__).parent
old = W/'reader-step-neighbor-proposal-v5/proposed/website/scripts/declaration_lessons.py'
D = W/'reader-step-neighbor-proposal-v6'
assert not D.exists()
sha = lambda b: hashlib.sha256(b).hexdigest()
assert sha(old.read_bytes()) == '64f7c70a7501b7143d16ef2317d8a0685c6ad37be6bd1f8cea2a021c7a6672e4'
production = Path('website/scripts/declaration_lessons.py')
assert sha(production.read_bytes()) == 'b22394faeb8de07109826174d05856f4a561b20f9301e1f1d031b466fd6f2596'
text = old.read_text()
assert text.count('base.esc(line)') == 1
text = text.replace('base.esc(line)', 'base.esc(line.removesuffix(chr(13)))')
compile(text, '<disabled-reader-v6>', 'exec')
dest = D/'proposed/website/scripts/declaration_lessons.py'
dest.parent.mkdir(parents=True)
dest.write_text(text)
patch = ''.join(difflib.unified_diff(production.read_text().splitlines(keepends=True), text.splitlines(keepends=True), fromfile='a/website/scripts/declaration_lessons.py', tofile='b/website/scripts/declaration_lessons.py'))
(D/'reader-step-neighbor.patch').write_text(patch)
record = {'production_sha256': sha(production.read_bytes()), 'prior_v5_proposed_sha256': sha(old.read_bytes()),
          'proposed_file': str(dest), 'proposed_sha256': sha(dest.read_bytes()), 'patch_sha256': sha(patch.encode()),
          'repair': 'Presentation only: strip one trailing CR from each logical LF source line before escaping and appending the generated HTML LF. This avoids the redundant CRLF/terminal-CR display break. Exact LF-based anchor indexing, source bytes, snippet matching, raw downloads and all mathematical/lesson/binding bytes remain unchanged.',
          'scope': 'DISABLED successor. All earlier frozen defects/HOLDs and genuine failures retained. No production/browser/clipboard/site/global adoption or reader-HOLD release.'}
(D/'proposal.json').write_text(json.dumps(record, indent=2)+'\n')
for p in [dest, D/'reader-step-neighbor.patch', D/'proposal.json']:
    p.chmod(0o444)
check = (W/'check_disabled_v5_static_cg.py').read_text()
check = check.replace('disabled-v5-cosine-gram-static', 'disabled-v6-cosine-gram-static')
check = check.replace('reader-step-neighbor-proposal-v5/', 'reader-step-neighbor-proposal-v6/')
check = check.replace('64f7c70a7501b7143d16ef2317d8a0685c6ad37be6bd1f8cea2a021c7a6672e4', record['proposed_sha256'])
check = check.replace('DISABLED v4 only', 'DISABLED v6 only')
with (W/'check_disabled_v6_static_cg.py').open('x') as f:
    f.write(check)
print(json.dumps(record))
