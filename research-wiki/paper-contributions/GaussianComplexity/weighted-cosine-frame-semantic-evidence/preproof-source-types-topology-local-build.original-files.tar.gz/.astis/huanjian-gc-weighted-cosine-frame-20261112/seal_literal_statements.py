"""Seal the weighted coefficient and marginal second-moment sum with literal definitions."""
from datetime import datetime, timezone
from html.parser import HTMLParser
from pathlib import Path
import hashlib
import json

workspace = Path(__file__).resolve().parent.relative_to(Path.cwd())
paper = Path('research-wiki/paper-contributions/GaussianComplexity')
evidence = paper / 'weighted-cosine-frame-semantic-evidence'
runner = Path('.astis/huanjian-resume-20261103')
source_path = runner / '2610.20492v1.html'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
dump = lambda value: (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode()


def create(path, raw):
    with path.open('xb') as out:
        out.write(raw)


def checked_run(stem):
    path = runner / (stem + '.receipt.json')
    raw = path.read_bytes()
    receipt = json.loads(raw)
    log = Path(receipt['log']).read_bytes()
    assert receipt['exit_code'] == 0 and sha(log) == receipt['log_sha256']
    return {'receipt': str(path), 'sha256': sha(raw), 'log_sha256': sha(log)}, log


raw_source = source_path.read_bytes()
assert len(raw_source) == 951991
assert sha(raw_source) == '6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
source = raw_source.decode()
offsets = [0] + [index + 1 for index, char in enumerate(source) if char == '\n']


class Locators(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=False)
        self.stack = []
        self.spans = {}

    def source_offset(self):
        line, column = self.getpos()
        return offsets[line - 1] + column

    def handle_starttag(self, tag, attrs):
        if tag in {'area', 'base', 'br', 'col', 'embed', 'hr', 'img', 'input', 'link', 'meta', 'param', 'source', 'track', 'wbr'}:
            return
        self.stack.append((tag, dict(attrs).get('id'), self.source_offset()))

    def handle_endtag(self, tag):
        for index in range(len(self.stack) - 1, -1, -1):
            if self.stack[index][0] == tag:
                _, identifier, first = self.stack[index]
                if identifier:
                    last = source.index('>', self.source_offset()) + 1
                    assert identifier not in self.spans
                    self.spans[identifier] = (first, last)
                del self.stack[index:]
                return


parser = Locators()
parser.feed(source)
anchor_ids = [
    'S4.Thmtheorem4.p1.m2', 'S4.Thmtheorem4.p1.m3',
    'S4.E11.m1', 'A3.SS2.p1', 'A3.SS2.p5.m2', 'A3.Ex85.m1',
    'A3.Ex87.m1', 'A3.Ex102.m1', 'A3.SS2.p10.m1', 'A3.SS2.p10.m2',
    'A3.Ex107.m1', 'A3.Ex113.m1', 'A3.SS2.p14.m2', 'A3.SS2.p14.m3',
    'A3.Ex114.m1', 'A3.SS2.p14.3', 'A3.EGx11',
    'A3.Ex115.m1', 'A3.Ex115.m2', 'A3.Ex116.m1', 'A3.SS2.p14.m5',
]
anchors = []
for identifier in anchor_ids:
    first, last = parser.spans[identifier]
    first_byte, last_byte = len(source[:first].encode()), len(source[:last].encode())
    raw = source[first:last].encode()
    assert raw_source[first_byte:last_byte] == raw
    anchors.append({
        'source_id': identifier, 'char_span': [first, last],
        'UTF8_byte_span': [first_byte, last_byte],
        'LF_lines_1based': [source.count('\n', 0, first) + 1, source.count('\n', 0, last) + 1],
        'span_sha256': sha(raw),
    })
formation, formation_log = checked_run('20261111T175138488235Z-weighted-cosine-frame-closed-literal-Prop-formation-v2')
meaning, meaning_log = checked_run('20261112T023026918505Z-weighted-cosine-frame-complete-definition-meaning-v2')
environment_receipt, _ = checked_run('20261112T023218265271Z-weighted-cosine-frame-current-exact-environment-v3')
assert b'ProducerStatement : Prop' in formation_log and b'ConsumerStatement : Prop' in formation_log
for name in ('Finset.sum', 'Finset.univ', 'Matrix.kroneckerMap', 'Matrix.smul', 'Matrix.PosSemidef'):
    assert name.encode() in meaning_log
previous_context_path = paper / 'radial-fourth-matrix-semantic-evidence/minimal-definition-context.json'
previous_context = json.loads(previous_context_path.read_bytes())
shared = previous_context['literal_shared_canonical_definition_prints']
assert sha(shared.encode()) == previous_context['literal_shared_canonical_definition_prints_sha256']
current_previous = previous_context['literal_current_prints_and_instances']
assert sha(current_previous.encode()) == previous_context['literal_current_prints_sha256']
context = {
    'allowed_only': 'Canonical definitions and meanings of domains, law, finite sums, matrix products, PSD order and Bochner integrability. No proposed proof or supplied proof certificate.',
    'mathlib_pin': 'db584cd6d46c92f209a44c0f1c829460d327499d',
    'imports_and_scope': ['import Mathlib', 'open MeasureTheory ProbabilityTheory', 'open scoped Matrix.Norms.L2Operator'],
    'literal_current_prints_and_instances': meaning_log.decode(),
    'literal_current_prints_sha256': sha(meaning_log), 'actual_current_print_receipt': meaning,
    'literal_shared_canonical_definition_prints': shared,
    'literal_shared_canonical_definition_prints_sha256': sha(shared.encode()),
    'literal_shared_PSD_and_product_prints': current_previous,
    'literal_shared_PSD_and_product_prints_sha256': sha(current_previous.encode()),
    'shared_definition_provenance': str(previous_context_path),
    'integral_definition_source': previous_context['integral_definition_source'],
    'matrix_multiplication_instance_source': previous_context['matrix_multiplication_instance_source'],
    'meaning': [
        'The carrier in the consumer is real Euclidean space in q+1 coordinates with its Euclidean norm and Borel structure. The actual measure is the canonical standard Gaussian defined from variance-one independent orthonormal coordinates.',
        'Fin d indexes exactly the d source rows under i_source=i.val+1. Fin(q+1) indexes frequencies0 through q. Every sum is a finite sum over the complete indicated index set.',
        'The feature squared length S i is the explicit sum of real coordinate squares. The first feature coordinate is1 and every higher coordinate is sqrt(2) cos(k theta_i). The midpoint angle is (i.val+1/2)pi/d.',
        'The real matrix outer product has entry t_i[a] t_i[b]. Identity is the diagonal identity. Kronecker paired indices place the identity/Gaussian coordinate first and feature coordinate second. Scalars multiply every entry.',
        'PosSemidef(upper-lower) requires Hermitian symmetry and nonnegative quadratic forms, so it is the stated Loewner upper bound. Its finite real index set tests every vector.',
        'The matrix norm is the Euclidean L2 operator norm. Bochner integrals have a nonintegrable zero default. Every individual squared-summand integrability is an explicit conclusion, protecting the complete finite sum of expectations.',
        'The cutoff is the closed event R≤L. The squared summand uses ordinary matrix multiplication with inverse-d scaling inside each Y. It introduces no retained-probability normalization.',
        'Each indexed summand expectation is computed against the canonical single-row law. The target concerns those marginal expectations and their finite sum. Original-family row-map and joint-law transport, independence and concentration remain separate obligations.',
        'The producer is deterministic. Its scalar coefficient r+2 is literal, and its PSD comparison requires geometry, positivity and scalar algebra. Its mathematical closure needs no Gaussian-law or fourth-moment premise.',
    ],
}
producer = (workspace / 'producer-signature.draft.txt').read_bytes()
consumer = (workspace / 'consumer-signature.draft.txt').read_bytes()
assert not any(token in producer + consumer for token in (b':= by', b'sorry', b'admit', b'axiom'))
environment = json.loads((workspace / 'actual-environment-before-seal.v3.json').read_bytes())
assert environment['manifest_sha256'] == sha(Path('lake-manifest.json').read_bytes())
assert environment['formalizer_API_pristine'] is False
exposure = json.loads((workspace / 'preseal-exposure.json').read_bytes())
assert exposure['formalizer_API_pristine'] is False and exposure['new_target_proof_implementation_attempts'] == 0
seal = {
    'schema_version': 1, 'seal_id': 'GAUSSIAN-COMPLEXITY-WEIGHTED-COSINE-FRAME-20261112-v1',
    'created_utc': datetime.now(timezone.utc).isoformat(),
    'state': 'EXACT_LITERAL_PROPS_FORMED;UNPROVED;INDEPENDENT_TYPE_TOPOLOGY_PENDING',
    'source': {'version': 'arXiv2610.20492v1', 'raw': str(source_path), 'raw_sha256': sha(raw_source),
               'anchors': anchors, 'scope': 'C.2 EGx11 deterministic weighted coefficient comparison and summed uncentered marginal second-moment bound.'},
    'producer': {
        'name': 'AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumWeightedFrameBound.actual_weighted_cosine_coefficient_bound',
        'planned_file': 'AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumWeightedFrameBound.lean',
        'signature': producer.decode(), 'signature_sha256': sha(producer),
        'outcome': 'The exact scaled weighted-cosine coefficient matrix is at most (2r(r+2)/d) times the paired-index identity in PSD order.',
    },
    'actual_private_consumer': {
        'name': 'AutoSamplingTheory.Tests.GaussianComplexityFixedSpectrumWeightedFrameBound.actual_uncentered_second_moment_sum_bound',
        'planned_file': 'Tests/GaussianComplexityFixedSpectrumWeightedFrameBound.lean',
        'signature': consumer.decode(), 'signature_sha256': sha(consumer),
        'outcome': 'Every actual squared truncated row summand is integrable, and the finite sum of its canonical marginal second moments has the source PSD upper bound.',
        'consumer_edge': 'Materially consume the deterministic producer, the existing canonical radial fourth matrix moment and its integrability. Derive square, PSD truncation and sum/integral transport internally.',
    },
    'binder_audit': [
        {'binder': 'd q : Nat', 'class': 'TYPING', 'meaning': 'Natural dimensions and query count, including q=0.'},
        {'binder': 'hq : 2*q+1<d', 'class': 'SOURCE_STANDING', 'source_ids': ['S4.Thmtheorem4.p1.m2', 'S4.Thmtheorem4.p1.m3'], 'meaning': 'The standing source range, which implies positive d and r=q+1.'},
        {'binder': 'all let-bound objects', 'class': 'DEFINITION', 'meaning': 'Literal source formulas or canonical real Euclidean/matrix/Gaussian constructions.'},
        {'binder': 'consumer forall i integrability', 'class': 'TARGET_CONCLUSION', 'meaning': 'An assertion to prove for every summand, with no extra premise.'},
    ],
    'EXCESS_public_binders': [],
    'proof_components_forbidden_as_extra_binders': [
        'Feature norm, Gram identity or weighted frame PSD certificate',
        'Gaussian law certificate, fourth-moment equation or integrability premise',
        'Matrix square identity, PSD truncation inequality or integral/sum interchange certificate',
        'Cross-row independence, concentration or centered-variance assumption',
        'Positive query count excluding q=0',
    ],
    'scope_boundary': 'Deterministic weighted coefficient and uncentered canonical marginal second-moment sum. Original-family row-law/expectation adapters, centering, variance norm, Bernstein, FactC.6, full Lemma4.4, both main bounds, oracle/TV/cost and integrated reader/public/purification remain open.',
    'shared_floor_audit': {
        'existing_canonical': 'AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumCosineGram.actual_cosine_frame_gram',
        'reuse_reason': 'The existing declaration already contains both exact Gram and uniform feature-norm conclusions. The new producer is their weighted PSD consequence.',
        'existing_fourth_matrix_parent': 'AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumRadialFourthMoment.actual_radial_fourth_moment_matrix',
        'compiled_parent_edges': 'Pending actual proof and kernel extraction.',
    },
    'actual_statement_formation': formation, 'actual_definition_meaning': meaning,
    'actual_environment': environment, 'actual_environment_receipt': environment_receipt,
    'preseal_exposure': exposure, 'formalizer_API_pristine': False,
    'new_target_proof_implementation_attempts': 0,
    'preseal_corrections': [
        'The first formation harness put the proposition in a return-type position without a body. Its actual failure is retained. Version2 forms both closed propositions.',
        'The copied environment scope sentence initially claimed no prior proof-API retrieval. The original is retained, and qualified versions2/3 disclose canonical reuse API exposure before this first seal.',
    ],
    'minimal_definition_context_sha256': sha(dump(context)),
}
evidence.mkdir(exist_ok=False)
create(evidence / 'minimal-definition-context.json', dump(context))
create(evidence / 'actual-definition-meaning.log', meaning_log)
create(evidence / 'StatementFormation.lean.raw.txt', (workspace / 'StatementFormationV2.lean').read_bytes())
create(evidence / 'DefinitionMeaning.lean.raw.txt', (workspace / 'DefinitionMeaning.lean').read_bytes())
seal_raw = dump(seal)
seal_path = paper / 'weighted-cosine-frame-statement-seal.json'
create(seal_path, seal_raw)
create(workspace / 'statement-seal-v1.json', seal_raw)
seal_path.chmod(0o444)
(workspace / 'statement-seal-v1.json').chmod(0o444)
packet = {
    'roles': 'Selective exact types and canonical definitions after independent raw-source freezes.',
    'producer': seal['producer'], 'actual_private_consumer': seal['actual_private_consumer'],
    'source': {'raw': str(source_path), 'sha256': sha(raw_source)},
    'minimal_definition_context': context, 'statement_seal_sha256': sha(seal_raw),
    'minimal_definition_context_sha256': sha(dump(context)),
}
create(workspace / 'selective-type-definition-packet.json', dump(packet))
print(json.dumps({
    'seal': str(seal_path), 'seal_sha256': sha(seal_raw),
    'producer_signature_sha256': sha(producer), 'consumer_signature_sha256': sha(consumer),
    'context_sha256': sha(dump(context)), 'selective_packet_sha256': sha(dump(packet)),
}))
