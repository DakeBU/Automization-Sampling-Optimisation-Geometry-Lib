from pathlib import Path
import json, hashlib, gzip, re, tarfile, sys
sys.dont_write_bytecode=True
sys.path.insert(0,'tools')
import astis_advance as adv
import astis_publication as pub
W=Path('.astis/huanjian-gc-fixed-spectrum-bias-20261110')
E=Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-bias-semantic-evidence')
C=Path('research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-bias.json')
L=Path('runs/substantive_advances.jsonl')
ADV='ASTIS-SA-20261110-GaussianComplexityFixedSpectrumBias'
OWNER='huanjian_gc_20261110_fixed_spectrum_bias'
sha=lambda b:hashlib.sha256(b).hexdigest()
dump=lambda x:(json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode()
def ref(p):
    p=Path(p);return {'path':str(p),'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size}
def put(p,b):
    assert not p.exists(),p
    p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
s=json.loads((W/'statement-seal-v1.json').read_bytes())
r=json.loads((E/'publication-draft-record.json').read_bytes())
b=json.loads((W/'preproof-baseline.json').read_bytes())
prod=Path(s['producer']['planned_file']);test=Path(s['actual_private_consumer']['planned_file']);name=s['producer']['name']
assert sha(prod.read_bytes())==r['producer_raw_sha256'] and sha(test.read_bytes())==r['Test_raw_sha256']
for p in [prod,test]:
    assert not re.search(r'\b(sorry|admit|axiom)\b|Prop\s*:=\s*True|:=\s*trivial\b',p.read_text())
checks=[]
for key in ['20261109T222454698836Z-bias-final-production-and-actual-probability-consumer',
            '20261109T222609397839Z-bias-kernel-exact-sealed-types-all-private-and-canonical-parents']:
    p=Path('.astis/huanjian-resume-20261103')/(key+'.receipt.json')
    d=json.loads(p.read_bytes());assert d['exit_code']==0 and sha(Path(d['log']).read_bytes())==d['log_sha256']
    checks.append({'receipt':ref(p),'raw_log_sha256':d['log_sha256'],'scope':'Actual focused native producer/Test or bounded all-owned kernel audit over8341 working files; not immutable candidate, aggregate, sourceV, browser or integration acceptance.'})
k=Path(json.loads(Path(checks[-1]['receipt']['path']).read_bytes())['log']).read_text()
reach=re.findall(r'OWNED_DECL_REACHABLE_FROM_ACTUAL_ROOT (.*?): (true|false)',k)
assert 'ALL_OWNED_DECLARATIONS_KERNEL_INSPECTED 27' in k and len(reach)==27
assert sum(v=='true' for n,v in reach)==12
assert all('._simp_' in n for n,v in reach if v=='false')
assert len([n for n,v in reach if '._simp_' not in n])==7
pub.check_advance([name],reviewed=False)

mapping={}
def group(ids,f,needle,text,kind='internal-local-discharge'):
    line=next(i+1 for i,l in enumerate(f.read_text().splitlines()) if needle in l)
    for node in ids.split():
        assert node not in mapping,node
        mapping[node]={'file':str(f),'line':line,'provider':needle,'implementation_map':text,'classification':kind,'independent_postproof_review':'pending'}
closed=Path('AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumExactMeans.lean')
mom=Path('AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumGaussianMoments.lean')
c7=Path('AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumCosineExpansion.lean')
grid=Path('AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumGridAlias.lean')
var=Path('AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumVariances.lean')
group('D_family D_mode D_gap D_objects D_actual P_root',prod,'theorem actual_diagonal_gaussian_exponential_bias','Exact unchanged source domain including explicit real source gap and literal Gaussian/integral definitions; four actual conclusions.','literal-sealed-root')
group('G_covariance_domain G_actual_second_integrability G_finite_quadratic_means N_actual_mean_sums',mom,'theorem actual_diagonal_gaussian_quadratic_means','Existing canonical actual Gaussian coordinate/moment and finite-sum means substrate, transitively reused through ExactMeans. No new independent domain or moment theorem emitted here. Source full upper-spectrum bound is not separately restated by this selected proof.','canonical-transitive-reuse')
group('G_actual_probability',test,'  have hc :=','The literal multivariateGaussian has its canonical probability-measure instance. Chebyshev is applied to this actual law, without an abstract law/probability input. No new covariance/marginal declaration is emitted here.','standard-actual-law-instance')
group('G_geometric_cosine N_cosine_expansion N_absolute_uniform',c7,'theorem actual_inverse_spectrum_cosine_expansion','Canonical existing actual uniformly/absolutely convergent inverse-spectrum cosine expansion, transitively reused by ExactMeans; no duplicate public node.','canonical-transitive-reuse')
group('G_grid_alias',grid,'theorem actual_midpoint_grid_cosine_alias','Canonical existing all-integer midpoint-grid alias, transitively reused by ExactMeans; not a new Bias theorem.','canonical-transitive-reuse')
group('G_series_grid_interchange N_exact_M G_signed_alias_classes N_exact_b',closed,'theorem actual_diagonal_gaussian_exact_means','Canonical actual exact means, including its convergent-series/grid interchange and alias-class resummation providers, are materially reused by hclosed. Only this public ExactMeans node is the producer first-public ASTIS parent.','canonical-actual-reuse')
group('G_rho_domain',prod,'private theorem spectral_ratio_log_bounds','Derives0<r<1, sqrtκ>1 and reciprocal-a domain; main body proves actual scale and1±r^(2d) denominator guards internally.')
group('G_positive_M N_positive_M',prod,'  have hMpos :','Actual closed norm mean has strictly positive scale, numerator and denominator; gives actual M>0.')
group('G_signed_positive N_signed_positive',prod,'  have hbpos :','Factoring r^n−r^(2d−n)=r^n(1−r^(2(d−n))) with n<d and0<r<1 yields actual signed-mean positivity.')
group('G_ratio_domains N_ratio',prod,'  have hratio :','Exact positive actual M/signed b, abs(-1)^n=1, exponent factorization and guarded cancellation yield the exact ratio of actual means. Not an expected ratio or supplied identity.')
group('N_correction_lower',prod,'  have hfraclower :','Uses positive denominator1−r^(2d)≤1 and nonnegative numerator to bound the ratio below by its numerator.')
group('N_correction_upper',prod,'  have hfracupper :','Exponent monotonicity for0<r<1 gives r^(2d)≤r^(2(d−n)); positive denominator gives ratio≤1.')
group('G_log_integral_domains N_log_integral',prod,'private theorem log_remainder_integral','Canonical exact logarithmic remainder derivative and FTC on the actual compact interval, for n=0 and1, prove both source integral identities. Continuity/nonzero denominator are internal. spectral_ratio_log_bounds proves a=1/sqrtκ∈(0,1) and exact log argument conversion.')
group('N_log_lower',prod,'private theorem log_integral_bounds','Actual integral comparison with1 proves2a≤log((1+a)/(1−a)); spectral_ratio_log_bounds substitutes a=1/sqrtκ. Source nonnegative-remainder route is the same scalar estimate, not a new hypothesis.')
group('N_log_upper',prod,'  have hrem :','SOURCE-INTERMEDIATE MAP: log_integral_bounds proves the unrelaxed2a+2a³/[3(1−a²)] estimate. spectral_ratio_log_bounds proves a²≤1/2 and bounds the remainder by a/3, obtaining8/(3sqrtκ). The implementation does not separately emit the equivalent κ−1 rational expression or the strict8/(3sqrtκ)<3/sqrtκ; spectral_ratio_power_bounds uses the sufficient nonstrict≤3/sqrtκ. All final sealed source constants remain exact.','explicit-sufficient-intermediate-variant')
group('G_power_log_exp N_power_lower N_power_upper',prod,'private theorem spectral_ratio_power_bounds','Actual log/exp identities and Real.exp_nat_mul give r^k=exp(−k log(1/r)); multiply by nonnegative k then negate to reverse order. Both power bounds hold for all natural k including0.')
group('N_tail_factor',prod,'  have htail :','Power upper bound at2(d−n), exact Nat.cast_sub under n<d, sqrtκ>0 and the explicit source real gap yield tail≤exp(−4).')
group('N_bias_lower N_bias_upper',prod,'  refine ⟨hMpos, hbpos, ?_, ?_⟩','Actual normalized ratio, finite-factor comparisons, exact positive1−exp(−4), power bounds and source-gap tail yield both exponential normalized-bias outputs.')
group('G_fourth G_independence G_weighted_L2 N_Q_L2 G_finite_Q_variance G_weighted_variance N_Q_exact_variance N_Q_variance_2M',var,'theorem actual_diagonal_gaussian_quadratic_variances','Existing canonical Variances node supplies actual Q L2 andVarQ≤2M to the consumer; its private square-L2/variance, actual diagonal Gaussian independence and canonical shared GaussianFourthMoment are transitive existing substrate. The consumer discards exact variance/dimension/norm branches, although the bundled compiled declaration contains them. No new fourth-moment or independence theorem credit.','canonical-actual-reuse')
group('C_zero_event C_root',test,'private theorem actual_gaussian_zero_threshold_probability_le','Exact unchanged literal actual Gaussian ZERO-THRESHOLD event and local numeric probability upper bound. PRIVATE NON-ANCHOR; not τ=0 in a source theorem and no Registry node.','private-non-Anchor-application')
group('G_sign_centered N_signed_actual_mean',test,'  have hmean :','Actual Q L2 scales to X L2; expectation scales to B, abs signed mean equals|b| and actual signed positivity is inherited from Bias. hsign/hV use sign²=1 to transfer actual variance2M.')
group('G_event_probability',test,'  have hm :','The implementation applies measure_mono to the literal event inclusion and an ENNReal Chebyshev upper bound; ofReal_ne_top justifies monotone toReal conversion. It does not separately emit polynomial event measurability or a probability≤1 lemma, which are source-valid but unnecessary to this outer-measure comparison. No default-infinity shortcut.','explicit-event-measure-route')
group('G_positive_factor N_signed_mean_lower',test,'  have hCpos :','hCpos/hLpos establish all strict positivity internally. hLB multiplies the new actual normalized lower bias by actual positiveM, using|b|=B, to get L≤B. No free numerical mean/certificate.')
group('G_Chebyshev N_zero_event_Chebyshev',test,'  have hsub :','Actual X≤0 implies|X−EX|≥B with B=EX>0. meas_ge_le_variance_div_sq uses actual X L2 andBpos; hprob converts its finite ENNReal bound. This is a genuine event application using the separate actual mean-positivity result.')
group('G_probability_constant',test,'  have hbsq :','PositiveL≤B givesL²≤B²; actual VarX≤2M, exact exp square/reciprocal identity and guarded field cancellation give2exp(6n/sqrtκ)/[(1−exp(−4))²M]. Local constants2,6 are derived, not quoted source constants.')
group('S_original_contrast S_original_probability',test,'private theorem actual_gaussian_zero_threshold_probability_le','OUTSIDE PACKET: concrete τ_dq,odd query mode,nonzero contrast mean/variance,rotated law,large-d/query guards,source .9/Ex26 and all exact oracle/TV/precision/cost adapters remain unproved here. Literal zero-threshold private event does not replace them.','outside-current-packet')
gp=W/'independent-source-graph/phase2/clarification-v2/source-proof-graph-v2.json'
g=json.loads(gp.read_bytes());assert set(mapping)=={n['id'] for n in g['nodes']},set(mapping)^{n['id'] for n in g['nodes']}
put(E/'source-to-lean-map-v1.json',dump({'source_graph':ref(gp),'seal':ref(W/'statement-seal-v1.json'),'nodes':mapping,'source_graph_unchanged':True,'source_graph_not_compiled_graph':True,'source_minimal_closure_not_bundled_Lean_dependency_closure':True,'no_extra_public_binders':True,'not_independent_verdict':True}))
mirror={'status':'none-found','discovery_ids':[],'reason':'Canonical actual means/variance, exact scalar FTC/logarithm and finite-factor Chebyshev composition are reused. No new independently supported cross-domain transport with hypothesis/key-estimate/conclusion/failure/source maps is established. Same compiled parents stay canonical; existing midpoint/Lobatto conceptual bridge gains no new Lean implication.'}
put(E/'postproof-conceptual-mirror-audit.json',dump(mirror))
put(E/'retained-failures-and-route-diagnosis.json',dump({'failure_class':'IMPLEMENTATION_FAILED','mathematical_refutation':False,'source_or_sealed_signature_change':False,'diagnosis':'Integral interval-integrability APIs required continuity rather than fun_prop; inverse-product scalar normalization required explicit div identities; positive scalar/constant-cast and addition-side inference required typed arguments. Log/power versions repaired redundant tactics and neg_mul normalization. First consumer required set-membership unfolding, local actual mean-positivity normalization, nat-cast2 after exp_nat_mul and removing solved-goal ring. Actual updated routes passed; all prior attempts retained.','same_unchanged_route_repeated_four_times':False,'preproof_process_deviation':'Both original exposure disclosures and old topology HOLD are immutable. Actual target Lean/API tools began only after final prospective independent admission; no pristine zero-planning history is claimed.','source_route_variants':'N_log_upper uses the sufficient a²≤1/2 intermediate; event conversion uses finite ofReal Chebyshev bound, not a separate measurability/probability≤1 lemma. Source map explicitly distinguishes these sufficient routes.'}))
payload=[]
for directory in [W/'independent-source-graph',W/'independent-topology-challenge']:
    payload += [p for p in sorted(directory.rglob('*')) if p.is_file() and '__pycache__' not in p.parts]
allow={'producer-signature.txt','consumer-signature.txt','statement-seal-v1.json','strict-preproof-seal-projection-v1.json','StatementFormation.lean.gz','root-preproof-admission-grant.json','preseal-exposure-disclosure.json','postseal-informal-route-exposure-disclosure.json'}
payload += [p for p in sorted(W.iterdir()) if p.is_file() and (p.name in allow or p.suffix in ['.lean','.py'])]
assert all(not re.search(rb'wxid_[a-z0-9]{8,}|/Library/Containers/com\.tencent',p.read_bytes()) for p in payload)
archive=E/'local-proof-source-graph-tools-and-retained-failures.selected.lossless.tar.gz'
assert not archive.exists()
with tarfile.open(archive,'w:gz') as t:
    for p in payload:t.add(p,arcname=str(p),recursive=False)
with tarfile.open(archive,'r:gz') as t:
    for p in payload:assert t.extractfile(str(p)).read()==p.read_bytes()
put(E/'local-proof-archive-manifest.json',dump({'archive':ref(archive),'files':[ref(p) for p in payload],'scope':'Lossless selected source/preproof/proof-tool/scratch-failure files. Private whole-baseline foreign ledgers and unrelated personal locators excluded. Not sourceV or integration.'}))
actual=[]
for p in sorted(Path('.astis/huanjian-resume-20261103').glob('*-bias-*.receipt.json')):
    d=json.loads(p.read_bytes());log=Path(d['log']);raw=log.read_bytes()
    assert sha(raw)==d['log_sha256'] and len(raw)<10_000_000
    q=E/'actual-local-checks'/p.name;put(q,p.read_bytes())
    z=E/'actual-local-checks'/(log.name+'.gz');put(z,gzip.compress(raw,mtime=0))
    actual.append({'receipt':ref(q),'log':ref(z),'exit_code':d['exit_code']})
put(E/'actual-local-checks-manifest.json',dump({'checks':actual,'scope':'All completed actual local attempts including retained failures before packaging. The current packaging command cannot archive its still-running own receipt; retain that separately. No aggregate/sourceV/site/browser/remote credit.'}))
for p,h in b['all_frontier_hashes'].items():assert sha(Path(p).read_bytes())==h,p
for p,h in b['protected_shared_hashes'].items():assert sha(Path(p).read_bytes())==h,p
put(E/'compact-preproof-environment-and-preservation.json',dump({key:b[key] for key in ['observed_utc','working_HEAD','Lean_actual','actual_Lean_binary','manifest','packages','ledger','protected_shared_hashes']}))
before=L.read_bytes();states=adv._replay_advances([json.loads(x) for x in before.splitlines()])
assert states[ADV]['state']=='EXPLORING' and states[ADV]['owner_id']==OWNER
cellraw=C.read_bytes();cell=json.loads(cellraw)
boundary='Exact unchanged actual Gaussian exponential normalized-bias source statement and genuine private actual zero-threshold Chebyshev consumer compile locally. Both sealed root types kernel-applied; all7handwritten declarations are root-reachable, with20generated simp auxiliaries (5reachable,15unreachable) separately audited and only standard3axioms. Fresh blind/source/whole-module/native/static review and actual sourceV remain pending. No foreign STAB takeover, latest-main/global/root/site/browser/remote/purification/whole-Goal credit. Original nonzero τ/query/TV/mode/large-d/rotated-law/full Lemma4.5,adaptive/Krylov laws and both main lower bounds remain open.'
ma={'status':'none-found','discovery_ids':[],'evidence':str(E/'postproof-conceptual-mirror-audit.json')}
evidence={'result_kind':'theorem-edge','theorem_delta':cell['target_statement'],'lean_files':[str(prod),str(test)],'lean_declarations':[name],'publication_declarations':[name],'focused_checks':checks,'truth_boundary':boundary,'conceptual_mirror_audit':ma,'actual_consumer':'Literal actual Gaussian zero-threshold event, using new lower actual bias, actual M/signed mean positivity and canonical Q L2/VarQ≤2M in centered-event Chebyshev and exact exponential probability algebra. No wrapper, supplied numeric certificate or source τ=0 claim.','source_VERIFIED_or_integration':False}
adv.transition_advance(ADV,'PROVED_LOCAL',worker_id=OWNER,evidence=evidence)
after=L.read_bytes();assert after.startswith(before)
app=after[len(before):];assert len(app.splitlines())==1
new=adv._replay_advances([json.loads(x) for x in after.splitlines()])
assert {k:v for k,v in states.items() if k!=ADV}=={k:v for k,v in new.items() if k!=ADV}
put(E/'frontier-before-PROVED_LOCAL.raw.json.gz',gzip.compress(cellraw,mtime=0))
put(E/'actual-PROVED_LOCAL-append.exact.jsonl',app)
put(E/'local-proof-capsule.json',dump({'state':'PROVED_LOCAL_NOT_SOURCE_VERIFIED','advance_id':ADV,'owner':OWNER,'normal_PROVED_LOCAL_API_calls':1,'append_sha256':sha(app),'foreign_SAU_states_preserved':len(states)-1,'foreign_frontiers_preserved':len(b['all_frontier_hashes']),'producer':{**ref(prod),'declaration':name,'actual_ASTIS_parents':r['actual_public_ASTIS_producer_parents']},'private_consumer':{**ref(test),'actual_ASTIS_parents':r['actual_public_ASTIS_private_consumer_parents'],'public_Anchor':False,'Registry_node':False},'actual_checks':checks,'exact_signatures_kernel_applied':True,'all_owned_declarations':27,'handwritten_private_scalar_providers':5,'handwritten_root_declarations':2,'generated_simp_auxiliaries':20,'root_reachable_owned':12,'unreachable_generated_simp_only':15,'all_handwritten_root_reachable':True,'recursive_axioms':['propext','Classical.choice','Quot.sound'],'authored_fake_closure_hits':0,'conceptual_mirror_audit':ma,'source_to_lean_map':ref(E/'source-to-lean-map-v1.json'),'truth_boundary':boundary,'source_VERIFIED_or_integration_or_purification_or_Goal':False}))
cell['status']='proved_locally'
cell['consumers'][0]='Compiled private actual_gaussian_zero_threshold_probability_le materially uses new lower exponential bias and actual canonical Q L2/VarQ≤2M in a real event-probability estimate.'
cell['evidence'].update({'execution_boundary':boundary,'focused_checks':[x['receipt']['path'] for x in checks],'local_proof_capsule':str(E/'local-proof-capsule.json'),'actual_compiled_public_ASTIS_producer_parents':r['actual_public_ASTIS_producer_parents'],'actual_compiled_public_ASTIS_consumer_parents':r['actual_public_ASTIS_private_consumer_parents'],'publication_binding_sha256':r['publication_binding_sha256']})
cell['statement_seal']['status']='EXACT_UNCHANGED_SIGNATURES_COMPILED;_EARLIER_PROCESS_DEVIATION_RETAINED;_INDEPENDENT_POSTPROOF_REVIEW_PENDING'
cell['source_proof_coverage'].update({'internal_obligation_list_is_preserved_preproof_history':True,'source_to_lean_map':ref(E/'source-to-lean-map-v1.json'),'current_compiled_scope':'ActualM/signedmean positivity,both exponential normalized-bias estimates;private zero-threshold actual probability bound. source_VERIFIED=false'})
cell['source_detail_audit']['gap']='Selected exponential normalized-bias subtree and private zero-threshold application locally discharged; explicit intermediate/event-route distinctions require independent review. Full original source application remains open.'
cell['source_detail_audit']['fidelity_boundary']=boundary
cell['reuse_plan']['reused_declarations']=r['actual_public_ASTIS_producer_parents']+r['actual_public_ASTIS_private_consumer_parents'][1:]
cell['reuse_plan']['known_consumers']=['Compiled private actual_gaussian_zero_threshold_probability_le materially consumes lower bias and actual Q L2/variance2M.']
cell['conceptual_mirror_audit']=ma
cell['learning_contract']['failure_class']='IMPLEMENTATION_FAILED'
cell['learning_contract']['salvage']['reason']='Typed Lean/API normalization and inference failures were diagnosed and repaired without source/binder/signature changes. All5private scalar providers are root-reachable. All prior source-graph HOLD, informal-planning deviation and compiler failures are retained; no unchanged fourth attempt or mathematical refutation claimed.'
C.write_bytes(dump(cell))
print(json.dumps({'state':'PROVED_LOCAL','append_sha256':sha(app),'owned_declarations':27,'producer':ref(prod),'consumer':ref(test),'source_VERIFIED':False,'archive':ref(archive)}))
