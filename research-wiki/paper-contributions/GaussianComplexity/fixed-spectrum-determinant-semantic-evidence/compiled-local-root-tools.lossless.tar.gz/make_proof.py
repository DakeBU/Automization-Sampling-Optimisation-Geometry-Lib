from pathlib import Path
import json,hashlib,subprocess
b=Path('.astis/huanjian-fixed-spectrum-determinant-20261108');seal=json.loads(Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-determinant-statement-seal.json').read_bytes())
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()=='bf35f70dfdd2a2ce9965b36aa34ab52f9eb1d991'
sig=seal['exact_signature_utf8'];assert hashlib.sha256(sig.encode()).hexdigest()=='1c55aaf1c9c11d4e1cdb1b565d3327fa8274e9a78f6440ca577b6c49b880f2dd'
header='''import AutoSamplingTheory.TechnicalLemmas.Measure.DisplacementJacobianEntropy
import Mathlib.LinearAlgebra.UnitaryGroup
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Basic
open Matrix
open scoped BigOperators
set_option autoImplicit false
namespace AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumDeterminant
'''
body=''' := by
  classical
  let θ : Fin d → ℝ := fun i => ((i.val : ℝ) + 1 / 2) * Real.pi / (d : ℝ)
  let diagonalValue : Fin d → ℝ := fun i =>
    (κ + 1) / 2 + (κ - 1) / 2 * Real.cos (θ i)
  let M : Matrix (Fin d) (Fin d) ℝ := O
  change (M * Matrix.diagonal diagonalValue * M.transpose).det =
    ∏ i : Fin d, diagonalValue i
  have hdet :=
    AutoSamplingTheory.TechnicalLemmas.Measure.DisplacementJacobianEntropy.det_conjStarAlgAut_eq
      (O : unitary (Matrix (Fin d) (Fin d) ℝ)) (Matrix.diagonal diagonalValue)
  rw [Unitary.conjStarAlgAut_apply] at hdet
  change (M * Matrix.diagonal diagonalValue * star M).det =
    (Matrix.diagonal diagonalValue).det at hdet
  have hstar : star M = M.transpose := by
    ext i j
    simp
  rw [hstar, Matrix.det_diagonal] at hdet
  exact hdet
'''
footer='''end AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumDeterminant
#print axioms AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumDeterminant.actual_precision_det
open Lean in
run_cmd do
  let env ← getEnv
  let some info := env.find? `AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumDeterminant.actual_precision_det | throwError "Missing source determinant theorem"
  let some value := info.value? (allowOpaque := true) | throwError "Missing determinant proof"
  let parents := value.getUsedConstants.filter fun n => n.toString.startsWith "AutoSamplingTheory"
  logInfo m!"ACTUAL COMPILED ASTIS PRODUCER PARENTS {parents}"
'''
p=b/'Proof.lean';assert not p.exists();p.write_text(header+sig.rstrip('\n')+body+footer)
print(json.dumps({'actual_proof_input':str(p),'raw_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'signature_exact':True,'canonical_reuse':'Existing public det_conjStarAlgAut_eq, actual O carrier confirmed by genuine Lean probe; no new generic invariant lemma or extra premise.','compilation':'pending'}))
