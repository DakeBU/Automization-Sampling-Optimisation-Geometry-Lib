from pathlib import Path
import copy, datetime, gzip, hashlib, json, subprocess, sys
sys.path.insert(0, 'tools')
import astis_advance as advance

P = Path('.astis/huanjian-gc-fixed-spectrum-geometry-20261109')
B = Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-geometry-semantic-evidence')
S = Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-geometry-statement-seal.json')
CELL_ID = 'ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-geometry'
ADV = 'ASTIS-SA-20261109-GaussianComplexityFixedSpectrumGeometry'
OWNER = 'huanjian_gc_20261109_fixed_spectrum_geometry'
DECL = 'AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumGeometry.actual_potential_geometry'
PROD = 'AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumGeometry.lean'
TEST = 'Tests/GaussianComplexityFixedSpectrumGeometry.lean'
CELL = Path('research-wiki/frontier-cells')/(CELL_ID+'.json')
sha = lambda b: hashlib.sha256(b).hexdigest()
dump = lambda x: (json.dumps(x, ensure_ascii=False, indent=2)+'\n').encode()
ref = lambda p: {'path': str(p), 'sha256': sha(p.read_bytes())}
def put(p, x):
    assert not p.exists(), str(p)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(dump(x))

assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == '54273a30ec293ce53f770905856c4322d291abb9'
assert not subprocess.check_output(['git', 'diff', 'HEAD', '--name-only']).strip()
assert not subprocess.check_output(['git', 'diff', '--cached', '--name-only']).strip()
assert subprocess.check_output(['git', 'rev-parse', 'origin/main'], text=True).strip() == 'd9bcd4231df69061c5221f8d557ee179a945c1eb'
subprocess.run(['git', 'merge-base', '--is-ancestor', 'origin/main', 'HEAD'], check=True)
assert not CELL.exists() and not Path(PROD).exists() and not Path(TEST).exists()
assert sha(S.read_bytes()) == '85bc4d02c970f21e144e776b3ad9a129539b5669beb4b0798c8da3cd4503e7fc'
seal = json.loads(S.read_bytes())
assert seal['producer']['signature_sha256'] == '832f0009d61ff4f9bb0e568a1350d1c8906b3cf029f6dd130987d6fa1f62281f'
assert seal['private_actual_consumer']['signature_sha256'] == '1ea7d90b1fd7d19e2d2839e0771f3edba30db262bd6cae7d24b9718aa46c6740'
manifest_refs = [
    (B/'source-only-review/phase1/phase1-freeze.json', '2a8155895c3f7e94113783e329e6c902e055c271adf023fd3edc46b86bd80169'),
    (B/'source-only-review/phase2/phase2-freeze.json', 'c78b6cb22364fa09feb8e967abff3a45e9aba95c470c97084c8292e92aacd17e'),
    (B/'topology-challenge/phase1/manifest.json', 'da6e262c62c354086cd9439e25795b4ab08c521d864165812a8a6226778eeeb4'),
    (B/'topology-challenge/phase2/manifest.json', '3b3c20df483a8f69a36acb799eb4654f87a4afe747ae7e52e82fc954718bae9a')]
n = 0
for p, h in manifest_refs:
    assert sha(p.read_bytes()) == h
    for row in json.loads(p.read_bytes())['files']:
        raw = Path(row['path']).read_bytes()
        assert sha(raw) == row['sha256'] and len(raw) == row['bytes']
        n += 1
review_path = B/'topology-challenge/phase2/final-review.json'
assert sha(review_path.read_bytes()) == '37b4eff523835cf71697d3f628b4ba3cfe8dd917d8edb831fdb5f1cabecebc26'
review = json.loads(review_path.read_bytes())
assert review['decision'] == 'PREPROOF_ADMIT_EXACT_PACKET_TO_BOUNDED_IMPLEMENTATION'
assert review['binder_finding']['noEXCESS'] and review['binder_finding']['EXCESS'] == []
assert review['producer_signature_sha256'] == seal['producer']['signature_sha256']
assert review['private_consumer_signature_sha256'] == seal['private_actual_consumer']['signature_sha256']
for role in ['reviewed_graph', 'reviewed_coverage']:
    r = review[role]
    assert sha(Path(r['path']).read_bytes()) == r['sha256']
baseline = json.loads(gzip.decompress((B/'existing-state-baseline.raw.json.gz').read_bytes()))
states = advance.current_advances()
assert states == baseline['all285_existing_SAU_states'] and ADV not in states
assert not any(v['state'] == 'STABILIZING' for v in states.values())
assert all(sha(Path(name).read_bytes()) == h for name, h in baseline['all444_existing_frontier_raw_hashes'].items())
ledger_path = Path('runs/substantive_advances.jsonl')
ledger_before = ledger_path.read_bytes()
assert sha(ledger_before) == baseline['ledger_sha256'] == '3cffc1120b532d9c8eac552bb317f14ead07ba72007fed3e93cf38b86513d5bd'
discovery_before = Path('runs/substantive_discoveries.jsonl').read_bytes()
boundary = ('Only literal actual source cosine-grid potential C-infinity, genuine gradient derivative/Hessian,1-strong convexity,kappa-gradient Lipschitzness and unique origin global minimizer, with a real fixed-input exact reply Borel consumer. Exactly local source d>=2,kappa>=2,allfullrealO. No assumed regularity/Hessian/norm/admissibility/minimizer/measurability/gradient-correctness premise. Actual gradient=query and real producer consumption remain internal proof obligations. No joint-in-O or adaptive/private-seed/transcript/output-law, Gaussian/TV, finiteprecision, deterministic worst-query cap, expected-cost, main lower bound, remote/purification/Seal or wholeGoal result follows from preproof admission.')
admission_path = B/'preproof-source-admission.json'
put(admission_path, {'state': 'UNCHANGED_EXACT_PACKET_DISTINCT_SOURCE_TOPOLOGY_ADMITTED_IMPLEMENTATION_NOT_STARTED',
    'statement_seal': ref(S), 'raw_interface': ref(B/'preproof-raw-interface-packet.json'),
    'producer_signature_sha256': seal['producer']['signature_sha256'],
    'private_consumer_signature_sha256': seal['private_actual_consumer']['signature_sha256'],
    'source_extractor': '/root/geometry_source_graph', 'distinct_challenger': '/root/geometry_topology_challenge',
    'source_manifests': [ref(p) for p, _ in manifest_refs], 'actual_payloads_verified': n,
    'independent_admission': ref(review_path), 'accepted_source_graph': review['reviewed_graph'],
    'accepted_source_coverage': review['reviewed_coverage'],
    'original_graph_two_challenges_preserved_and_v2_reviewed': True,
    'open_internal_obligations': review['open_internal_source_obligations'],
    'source_justification_is_compiled_proof': False, 'implementation_admission_commit_required_next': True,
    'new_sourceV_or_result_proved': False})
old = json.loads(Path('research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-first-order.json').read_bytes())
learning = copy.deepcopy(old['learning_contract'])
learning.update({'failure_class': 'IMPLEMENTATION_FAILED',
    'salvage': {'required': True, 'status': 'completed', 'reason': 'Preseal type-only uninstantiated matrix equivalence coercion failed; explicit Real/Fin d arguments corrected the same proposition. Both raw probes/logs are retained. No mathematical proof fragment was promoted or discarded.', 'promoted_fragments': [], 'discarded_fragments': []},
    'parallelism': {'decision': 'serial', 'direction_fingerprints': [], 'expected_information_gain': 'Root is sole proof worker; raw source graph and different-role topology/binder audits handle independent source uncertainty, not competing proof implementations.', 'shared_verified_context_digest': seal['producer']['signature_sha256']},
    'cross_route_blind_spot_audit': {'required': False, 'status': 'not-applicable', 'evidence': '', 'canonical_route': '', 'selection_reason': 'No parallel proof construction.'},
    'reader_backpressure': {'purification_status': 'pending', 'exposition_seal_status': 'pending', 'exposition_evidence': '', 'source_expansion_nodes': [], 'lean_expansion_nodes': [], 'assumptions_preserved': True, 'boundary_preserved': True}})
searched = ['Samplinglib GaussianComplexity module/statement inventory and existing regularity/minimizer/eigenbasis cells: old block determinant family differs from actual S4 cosine family; no current actualGeometry module/declaration exists.',
    'Mathlib pinned necessary standard definitions of ContDiff infinity, full orthogonalGroup, Euclidean/WithLp2, CLM action, StrongConvexOn1, IsMinOn and explicit Borel spaces audited; all incidental broader standard definition/name/action lookup exposure is disclosed in frozen records.',
    'Samplinglib shared generic HessianStrongConvexity, StrongConvexMinimizer and QuadraticGradientDescent filenames/declaration-name headers inventoried only. Target proof/API retrieval starts after this immutable admission. Existing actualAdmissibility and actualFirstOrder are canonical candidate dependencies, not new copies or already claimed kernel parents.']
cell = {'schema_version': 3, 'cell_id': CELL_ID, 'route': 'samplewiki-route', 'title': 'Actual fixed-spectrum potential geometry and Borel oracle', 'mode': 'faithfulPaper',
    'source_anchor': 'arXiv2610.20492v1 S4.SS1/E11; Lemma4.6 and AppendixC.4; S2.E1/Borel algorithm context for fixed-input exact reply',
    'target_statement': seal['producer']['signature'], 'status': 'claimed', 'owner_id': OWNER, 'advance_id': ADV,
    'parents': ['ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-admissibility', 'ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-first-order'],
    'consumers': [seal['private_actual_consumer']['real_downstream_use'], 'The sealed actual private same-A/f/query Borel consumer must genuinely consume this geometry producer; signature-only formation is not consumer evidence.'],
    'reader_contract': copy.deepcopy(old['reader_contract']), 'learning_contract': learning,
    'shared_floor_audit': {'searched': searched, 'classification': 'adapt', 'decision': 'adapt_existing', 'canonical_declaration': DECL, 'canonical_shared_cell': '', 'notes': 'Reuse exact compiled general parents after retrieval; prove source-family geometry internally, no assumed Hessian/regularity or duplicate generic wrapper.'},
    'reuse_plan': {'searched_existing': searched, 'reused_declarations': [], 'new_shared_declarations': [], 'known_consumers': ['Sealed same-source-input actual reply Borel Test; currently unimplemented'], 'planned_consumers': ['True fixed-input Borel oracle/seed-query composition and C4 function-class background; joint/adaptive/TV/caps/cost still separate'], 'no_duplicate_wrapper': True, 'decision_reason': 'Actual fixed family is built from source d/kappa/fullO; all analytic and matrix properties are outputs. Consumer must materially use produced regularity and canonical actual gradient identification.'},
    'graph_contribution': {'lean_view': 'new-node', 'overview_view': 'no-change-with-reason', 'functor_view': 'none-found', 'edge_semantics': 'formal-solid; overlays-dashed', 'color_semantics': 'evidence-status; library-scope', 'focus_targets': [DECL], 'visual_review': 'No compiled geometry node or actual website acceptance yet; source topology accepted only as preproof input.'},
    'source_detail_audit': {'primary_edition': 'arXiv2610.20492v1', 'primary_anchor': 'S4.SS1/E11;S4.Thmtheorem6;A3.SS4;S2.E1', 'detail_status': 'omitted', 'gap': 'C4 compresses literal quadratic calculus, Hessian/spectral/norm and direct minimizer bridges; fixed-input actual-oracle Borel continuity is an omitted source-model bridge.11 internal obligations remain unproved by source admission, never new public premises.', 'consulted': [{'source': 'Pinned raw primary source; independent source graphv2 and distinct source/topology/binder/definition challenge', 'anchor': 'S4.SS1/E11;C4;S2 exact oracle/Borel model', 'hypothesis_adapter': 'Exactly d>=2,kappa>=2,fullrealO; no derivative/norm/minimizer/measurability or main-delta/epsilon/query-cap premise.'}], 'fidelity_boundary': boundary},
    'statement_seal': {'path': str(S), 'sha256': sha(S.read_bytes()), 'signature_sha256': seal['producer']['signature_sha256'], 'status': 'EXACT_SEALED_TYPECHECKED_DISTINCT_PREPROOF_ADMITTED'},
    'evidence': {'execution_boundary': boundary, 'focused_checks': [seal['actual_type_elaboration']['receipt']['path']], 'preproof_source_admission': str(admission_path), 'actual_consumer_seal': seal['private_actual_consumer'], 'source_exposure_and_definition_supplement': [str(B/'preseal-exposure-terminology-clarification.json'), str(B/'definition-context-supplement-v1/manifest.json'), str(B/'definition-context-supplement-v1/PiLp-addendum.json')], 'independent_verification': '', 'root_build': '', 'graph_regeneration': '', 'pr': ''},
    'source_proof_coverage': {'accepted_graph': review['reviewed_graph'], 'accepted_coverage': review['reviewed_coverage'], 'distinct_topology_admission': ref(review_path), 'open_internal_obligations': review['open_internal_source_obligations'], 'actual_compiled_proof_credit': False},
    'conceptual_mirror_audit': {'status': 'none-found', 'discovery_ids': [], 'reason': 'Preproof provisional only. Reaudit actual proof before PLOC; same compiled facts share canonical identity and conceptual analogies never become Lean implication.', 'existing_family_ids_for_retrieval_only': ['family:curvature-growth', 'family:gaussian-oracle-hardness']},
    'purification': {'status': 'pending', 'reader_default_view': 'Concise rendered geometry/actual oracle result; full source conditions, formula proof and exact Lean progressively folded.'}, 'blocked': {'reason': '', 'children': []}}
put(CELL, cell)
(B/'before-normal-intake-ledger.lossless.jsonl.gz').write_bytes(gzip.compress(ledger_before, mtime=0))
put(P/'normal-intake-started.json', {'advance_id': ADV, 'owner': OWNER, 'ledger_before_sha256': sha(ledger_before), 'admission': ref(admission_path)})
advance.propose_advance(advance.AdvanceProposal(advance_id=ADV, task_id='GaussianComplexity-fixed-spectrum-geometry',
    goal='Actual C4 potential C-infinity/Hessian/strong-convexity/smoothness/unique-minimizer with genuine fixed-input Borel exact-oracle consumer',
    source_anchor=cell['source_anchor'], theorem_delta=seal['producer']['signature'], truth_boundary=boundary, created_by=OWNER,
    dag_inputs=('Literal source Eq11 precision/potential', 'Canonical actual admissibility and first-order interfaces', 'Standard Euclidean calculus/convexity/norm and Borel definitions'),
    proposed_files=(PROD, TEST, str(CELL), str(S)), focused_checks=('lake build Tests.GaussianComplexityFixedSpectrumGeometry',),
    modes=('source', 'Lean', 'reader'), priority=100, frontier_cell=CELL_ID, target_declarations=(DECL,)))
advance.transition_advance(ADV, 'CLAIMED', worker_id=OWNER, evidence={'statement_seal': cell['statement_seal'], 'independent_preproof_admission': ref(review_path), 'mathematical_proof_started': False})
advance.transition_advance(ADV, 'EXPLORING', worker_id=OWNER, evidence={'source_admission': ref(admission_path), 'producer_signature_sha256': seal['producer']['signature_sha256'], 'private_consumer_signature_sha256': seal['private_actual_consumer']['signature_sha256'], 'implementation_admission_commit_required_next': True, 'proof_started': False})
after = ledger_path.read_bytes()
now = advance.current_advances()
assert after.startswith(ledger_before) and len(after[len(ledger_before):].splitlines()) == 3
assert all(now[k] == v for k, v in states.items()) and len(now) == 286
assert Path('runs/substantive_discoveries.jsonl').read_bytes() == discovery_before
assert all(sha(Path(name).read_bytes()) == h for name, h in baseline['all444_existing_frontier_raw_hashes'].items())
assert all(sha(Path(name).read_bytes()) == h for name, h in baseline['graph_models'].items())
put(B/'normal-intake-preservation.json', {'state': now[ADV]['state'], 'append_events': 3, 'ledger_before_sha256': sha(ledger_before), 'ledger_after_sha256': sha(after), 'append_sha256': sha(after[len(ledger_before):]), 'all285_foreign_states_and444_frontier_bytes_preserved': True, 'old_ledger_prefix_exact': True, 'discovery_and_models_unchanged': True, 'new_source_verdict': False, 'mathematical_proof_started': False})
readme = Path('research-wiki/paper-contributions/GaussianComplexity/README.md')
old_readme = readme.read_bytes()
(B/'README-before-geometry-intake.lossless.md.gz').write_bytes(gzip.compress(old_readme, mtime=0))
prefix = ('## 2026-11-09 JST: exact C4 geometry and actual Borel consumer source admitted; proof next\n\n'
    'Read `fixed-spectrum-geometry-statement-seal.json` and `fixed-spectrum-geometry-semantic-evidence/preproof-source-admission.json`. Exact literal cosine-family C-infinity, genuine gradient derivative/Hessian,1-strong convexity,kappa gradient Lipschitzness,zero value and unique global minimizer interfaces, plus the same-input actual reply Borel consumer, have distinct raw-source/topology/binder/definition admission. Two original topology ambiguities were independently challenged and corrected in a versioned graph; all old graphs and source cognition remain. Eleven internal obligations still need real Lean proofs. No new producer/Test proof or sourceV exists; freeze this admission commit before target proof/API work.\n\n'
    'Prior FirstOrder final760daf77/acceptedcore9b remains locally accepted and normally released. Root is sole mathworker; all285 foreign states/444 raw frontiers, all old ledgers/results and other-paper queues are preserved. Both full main bounds, true joint/adaptive/seed/transcript/output-law, oracle/finiteprecision/TV/deterministic cap/expected-cost adapters, remote original-owner release and postmerge purification/ExpositionSeal remain open. Same foreground unbudgeted Goal, no reset or detached ASTIS. Earlier checkpoints remain phase history.\n\n')
readme.write_bytes(prefix.encode()+old_readme)
print(json.dumps({'new_state': now[ADV]['state'], 'actual_independent_payloads_verified': n,
    'foreign_states_preserved': len(states), 'foreign_frontiers_preserved': len(baseline['all444_existing_frontier_raw_hashes']),
    'new_ledger_sha256': sha(after), 'producer_or_Test_proof_exists': False,
    'next': 'Validate and commit this source admission before proof/API retrieval.'}))
