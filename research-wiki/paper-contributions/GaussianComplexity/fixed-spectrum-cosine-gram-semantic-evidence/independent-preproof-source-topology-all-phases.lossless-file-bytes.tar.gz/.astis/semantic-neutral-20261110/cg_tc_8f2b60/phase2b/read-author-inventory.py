from pathlib import Path
import hashlib
import json
import stat

base=Path(__file__).resolve().parent
repo=Path('/Users/zhouhuanjian/ASTIS-GC')
author=repo/'.astis/semantic-neutral-20261110/cg_sg_1d7a46'
expected={
 'phase1_receipt.json':'86869756bdcdb1dfe0a33cba6d572705ebee9c6784ecee5660db72c3c00bfd91',
 'phase1/manifest.json':'ededc4db5669a328807c9e0fbf9f719fdc92df4257c878bafd343965e25fb00b',
 'phase2_receipt.json':'7b0e78a7cca3ba7ce39fe90f479cb0d264405e6e964b5714cdb0b2b29c6ff801',
 'phase2/manifest.json':'d96ad3ac8e44b7f0621d62c620c1c9e4f8e38b626fa4aa2a5b94a0aa0eb02fc9'
}
inventory=[]
shown=[]
for stage in ['phase1','phase2']:
    (base/('author-'+stage)).mkdir()
    for path in sorted((author/stage).rglob('*')):
        if not path.is_file():continue
        rel=path.relative_to(author)
        b=path.read_bytes()
        digest=hashlib.sha256(b).hexdigest()
        if str(rel) in expected:assert digest==expected[str(rel)],str(rel)
        snapshot=base/('author-'+stage)/path.relative_to(author/stage)
        snapshot.parent.mkdir(parents=True,exist_ok=True)
        snapshot.write_bytes(b)
        inventory.append({'author_path':str(path),'relative_author_path':str(rel),'snapshot':str(snapshot.relative_to(base)),
                          'bytes':len(b),'sha256':digest,'original_mode':oct(stat.S_IMODE(path.stat().st_mode))})
        if path.name=='manifest.json':shown.append('MANIFEST '+str(rel)+'\n'+b.decode())
for name in ['phase1_receipt.json','phase2_receipt.json']:
    path=author/name;b=path.read_bytes();digest=hashlib.sha256(b).hexdigest()
    assert digest==expected[name],name
    (base/('author-'+name)).write_bytes(b)
    inventory.append({'author_path':str(path),'relative_author_path':name,'snapshot':'author-'+name,
                      'bytes':len(b),'sha256':digest,'original_mode':oct(stat.S_IMODE(path.stat().st_mode))})
    shown.append('RECEIPT '+name+'\n'+b.decode())
(base/'author-input-inventory.json').write_text(json.dumps(inventory,indent=2)+'\n')
out='AUTHOR FILE INVENTORY\n'+json.dumps(inventory,indent=2)+'\n\n'+'\n\n'.join(shown)+'\n'
(base/'read-author-inventory.stdout.txt').write_text(out)
print(out,end='')
