import AutoSamplingTheory.ExampleCases.ProximalBPS.ActualOrderedPrefix
import AutoSamplingTheory.ExampleCases.ProximalBPS.ActualConditionalNextWaitSurvival
import AutoSamplingTheory.ExampleCases.ProximalBPS.ActualPhysicalTimeMeasurability

/-! Internal proof ingredients for the sealed candidate93, not a public result.
The set-law premise below will be filled by the actual survival theorem88.
No premise is added to the sealed source-facing statement. -/
namespace PathInterfaces93
open InnerProductSpace MeasureTheory ProbabilityTheory Filter
open scoped ContDiff NNReal ENNReal Topology Interval
noncomputable section
set_option autoImplicit false

private theorem measurable_finite_fold {X Y : Type*}
    [MeasurableSpace X] [MeasurableSpace Y] (n : ℕ)
    (f : X → Y → Fin n → X)
    (hf : ∀ j, Measurable (fun p : X × Y => f p.1 p.2 j))
    (x : Y → X) (hx : Measurable x) :
    Measurable (fun y => Fin.foldl n (fun z j => f z y j) (x y)) := by
  induction n with
  | zero => simpa only [Fin.foldl_zero] using hx
  | succ n ih =>
    have hr := ih (fun z y j => f z y j.castSucc) (fun j => hf j.castSucc)
    simpa only [Fin.foldl_succ_last, Function.comp_def, id_eq] using
      (hf (Fin.last n)).comp (hr.prodMk measurable_id)

private theorem survival_history_measure {Ω H : Type*}
    [MeasurableSpace Ω] [MeasurableSpace H]
    (μ : Measure Ω) (history : Ω → H) (S : Set Ω) (weight : H → ℝ≥0∞)
    (hh : Measurable history)
    (hset : ∀ A : Set H, MeasurableSet A →
      μ (history ⁻¹' A ∩ S) = ∫⁻ h in A, weight h ∂Measure.map history μ) :
    Measure.map history (μ.restrict S) = (Measure.map history μ).withDensity weight := by
  apply Measure.ext
  intro A hA
  rw [Measure.map_apply hh hA, Measure.restrict_apply (hA.preimage hh),
    withDensity_apply weight hA]
  exact hset A hA

private theorem survival_history_all_tests {Ω H : Type*}
    [MeasurableSpace Ω] [MeasurableSpace H]
    (μ : Measure Ω) (history : Ω → H) (S : Set Ω) (weight : H → ℝ≥0∞)
    (hh : Measurable history) (hw : Measurable weight)
    (hset : ∀ A : Set H, MeasurableSet A →
      μ (history ⁻¹' A ∩ S) = ∫⁻ h in A, weight h ∂Measure.map history μ)
    (F : H → ℝ≥0∞) (hF : Measurable F) :
    (∫⁻ w in S, F (history w) ∂μ) =
      ∫⁻ h, F h * weight h ∂Measure.map history μ := by
  rw [← lintegral_map hF hh, survival_history_measure μ history S weight hh hset,
    lintegral_withDensity_eq_lintegral_mul _ hw hF]
  exact lintegral_congr fun _ => mul_comm _ _

/- A total history interpolation on arbitrary (possibly unrealizable) histories.
The path space has its coordinate-product measurable structure. -/
private theorem measurable_record_step {X Y : Type*}
    [MeasurableSpace X] [MeasurableSpace Y]
    (Φ : Y → ℝ≥0 → X → X)
    (hΦ : Measurable (fun p : Y × ℝ≥0 × X => Φ p.1 p.2.1 p.2.2))
    (s : ℝ≥0) :
    Measurable (fun p : ((ℝ≥0 × X) ⊕ Unit) × (X × Y) =>
      p.1.elim (fun a => if a.1 ≤ s then Φ p.2.2 (s - a.1) a.2 else p.2.1)
        (fun _ => p.2.1)) := by
  classical
  let e := MeasurableEquiv.sumProdDistrib (ℝ≥0 × X) Unit (X × Y)
  have hl : Measurable (fun p : (ℝ≥0 × X) × (X × Y) =>
      if p.1.1 ≤ s then Φ p.2.2 (s - p.1.1) p.1.2 else p.2.1) := by
    apply Measurable.ite (measurableSet_le measurable_fst.fst measurable_const)
    · exact hΦ.comp (measurable_snd.snd.prodMk
        ((measurable_const.sub measurable_fst.fst).prodMk measurable_fst.snd))
    · exact measurable_snd.fst
  convert (hl.sumElim (measurable_snd.fst :
    Measurable (fun p : Unit × (X × Y) => p.2.1))).comp e.measurable using 1
  funext p
  rcases p with ⟨a | a, q⟩ <;> rfl

private theorem measurable_history_interpolation {X Y : Type*}
    [MeasurableSpace X] [MeasurableSpace Y]
    (Φ : Y → ℝ≥0 → X → X)
    (hΦ : Measurable (fun p : Y × ℝ≥0 × X => Φ p.1 p.2.1 p.2.2))
    (n : ℕ) (T : ℝ≥0)
    (h : Y → Fin n → ((ℝ≥0 × X) ⊕ Unit)) (hh : Measurable h)
    (z₀ : Y → X) (hz₀ : Measurable z₀) :
    Measurable (fun y => fun s : {s : ℝ≥0 // s ≤ T} =>
      Fin.foldl n (fun z j => (h y j).elim
        (fun a => if a.1 ≤ s.val then Φ y (s.val - a.1) a.2 else z)
        (fun _ => z)) (z₀ y)) := by
  classical
  apply measurable_pi_lambda
  intro s
  apply measurable_finite_fold n _ _ z₀ hz₀
  intro j
  exact (measurable_record_step Φ hΦ s.val).comp
    (((measurable_pi_apply j).comp (hh.comp measurable_snd)).prodMk measurable_id)

/- The last eligible index, rather than a maximum chosen by an unmeasurable
path-space operation, determines each coordinate of the literal fold. -/
private theorem finite_fold_last_eligible {X : Type*} (n : ℕ)
    (b : Fin n → Prop) [DecidablePred b] (v : Fin n → X) (x : X)
    (j : Fin n) (hj : b j) (hafter : ∀ k : Fin n, j < k → ¬ b k) :
    Fin.foldl n (fun z k => if b k then v k else z) x = v j := by
  induction n with
  | zero => exact Fin.elim0 j
  | succ n ih =>
    induction j using Fin.lastCases with
    | last => simp only [Fin.foldl_succ_last, if_pos hj]
    | cast j =>
      rw [Fin.foldl_succ_last, if_neg (hafter (Fin.last n) (Fin.castSucc_lt_last j))]
      exact ih (fun k => b k.castSucc) (fun k => v k.castSucc) j hj
        (fun k hk => hafter k.castSucc (Fin.castSucc_lt_castSucc_iff.mpr hk))


private theorem finite_history_fold_eq_process {X : Type*}
    (Φ : ℝ≥0 → X → X) (r : ℕ → ((ℝ≥0 × X) ⊕ Unit)) (z₀ : X)
    (n : ℕ) (T : ℝ≥0)
    (hzero : r 0 = Sum.inl (0, z₀))
    (hlive : ∀ k : Fin (n + 1), ∃ a : ℝ≥0 × X, r k.val = Sum.inl a)
    (hend : (T : WithTop ℝ≥0) < (r (n + 1)).elim (fun a => (a.1 : WithTop ℝ≥0)) (fun _ => ⊤))
    (Z : ℝ≥0 → X)
    (hZ : ∀ s : ℝ≥0, ∀ k : ℕ, ∀ a : ℝ≥0 × X,
      (r k).elim (fun b => (b.1 : WithTop ℝ≥0)) (fun _ => ⊤) ≤ (s : WithTop ℝ≥0) →
      (s : WithTop ℝ≥0) < (r (k+1)).elim (fun b => (b.1 : WithTop ℝ≥0)) (fun _ => ⊤) →
      r k = Sum.inl a → Z s = Φ (s - a.1) a.2) :
    ∀ s : ℝ≥0, s ≤ T →
      Fin.foldl (n + 1) (fun z j => (r j.val).elim
        (fun a => if a.1 ≤ s then Φ (s - a.1) a.2 else z) (fun _ => z)) z₀ = Z s := by
  classical
  intro s hs
  let time : ℕ → WithTop ℝ≥0 := fun k =>
    (r k).elim (fun a => (a.1 : WithTop ℝ≥0)) (fun _ => ⊤)
  let p : ℕ → Prop := fun k => time k ≤ (s : WithTop ℝ≥0)
  have hp0 : p 0 := by
    simp only [p, time, hzero, Sum.elim_inl]
    exact WithTop.coe_le_coe.mpr zero_le
  let k := Nat.findGreatest p n
  have hkn : k ≤ n := Nat.findGreatest_le n
  have hkp : p k := Nat.findGreatest_spec (Nat.zero_le n) hp0
  have hnext : (s : WithTop ℝ≥0) < time (k+1) := by
    by_cases hlast : k = n
    · rw [hlast]
      exact lt_of_le_of_lt (WithTop.coe_le_coe.mpr hs) hend
    · exact lt_of_not_ge (Nat.findGreatest_is_greatest (Nat.lt_succ_self k)
        (by omega : k + 1 ≤ n))
  let j : Fin (n + 1) := ⟨k, by omega⟩
  let a : Fin (n + 1) → ℝ≥0 × X := fun i => Classical.choose (hlive i)
  have ha (i : Fin (n + 1)) : r i.val = Sum.inl (a i) := Classical.choose_spec (hlive i)
  have hj : (a j).1 ≤ s := by
    have h := hkp
    change time j.val ≤ (s : WithTop ℝ≥0) at h
    simpa only [time, ha, Sum.elim_inl, WithTop.coe_le_coe] using h
  have hafter (i : Fin (n+1)) (hji : j < i) : ¬ (a i).1 ≤ s := by
    intro hi
    have hpi : p i.val := by
      simp only [p, time, ha, Sum.elim_inl]
      exact WithTop.coe_le_coe.mpr hi
    exact (Nat.findGreatest_is_greatest (show k < i.val from hji) (by omega)) hpi
  calc
    _ = Fin.foldl (n+1) (fun z i => if (a i).1 ≤ s then Φ (s - (a i).1) (a i).2 else z) z₀ := by
      congr 1
      funext z i
      rw [ha]
      rfl
    _ = Φ (s - (a j).1) (a j).2 :=
      finite_fold_last_eligible (n+1) (fun i => (a i).1 ≤ s)
        (fun i => Φ (s - (a i).1) (a i).2) z₀ j hj hafter
    _ = Z s := (hZ s k (a j) hkp hnext (ha j)).symm

private theorem terminal_event_after (T a : ℝ≥0) (q : WithTop ℝ≥0)
    (hq : ((T-a : ℝ≥0) : WithTop ℝ≥0) < q) :
    (T : WithTop ℝ≥0) < (if q = ⊤ then ⊤ else ((a + q.untopD 0 : ℝ≥0) : WithTop ℝ≥0)) := by
  classical
  by_cases htop : q = ⊤
  · rw [if_pos htop]
    exact WithTop.coe_lt_top T
  lift q to ℝ≥0 using htop
  simp only [WithTop.coe_ne_top, if_false, WithTop.untopD_coe, WithTop.coe_lt_coe] at hq ⊢
  calc
    T ≤ (T-a) + a := le_tsub_add
    _ < q + a := by simpa only [add_comm] using add_lt_add_right hq a
    _ = a + q := add_comm _ _

set_option maxHeartbeats 1600000 in
private theorem actual_history_path_identification
    {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℝ E]
    [FiniteDimensional ℝ E] [MeasurableSpace E] [BorelSpace E]
    {V : E → ℝ} {α β : ℝ≥0} {η : ℝ}
    (hα : 0 < (α : ℝ)) (hαβ : α ≤ β) (hV : ContDiff ℝ 2 V)
    (hH : ∀ x v : E,
      (α : ℝ) * ‖v‖ ^ 2 ≤ (fderiv ℝ (fderiv ℝ V) x v) v ∧
      (fderiv ℝ (fderiv ℝ V) x v) v ≤ (β : ℝ) * ‖v‖ ^ 2)
    (hη : 0 < η) (hβη : (β : ℝ) * η ≤ 1) :
    let c : E → E → E := fun y xRef => y - η • gradient V xRef
    let Φ : E → E → ℝ → (E × E) → (E × E) := fun y xRef t z =>
      (c y xRef + Real.cos t • (z.1 - c y xRef) +
          (Real.sqrt η * Real.sin t) • z.2,
       (-Real.sin t / Real.sqrt η) • (z.1 - c y xRef) + Real.cos t • z.2)
    let S : E → (E × E) → (E × E) := fun xRef z =>
      (z.1, z.2 - (2 * inner ℝ z.2 (gradient V z.1 - gradient V xRef) /
        ‖gradient V z.1 - gradient V xRef‖ ^ 2) • (gradient V z.1 - gradient V xRef))
    let rate : E → (E × E) → ℝ := fun xRef z =>
      Real.sqrt η * max 0 (inner ℝ z.2 (gradient V z.1 - gradient V xRef))
    let Λ : E → E → (E × E) → ℝ≥0 → ℝ := fun y xRef z t =>
      ∫ s in (0 : ℝ)..(t : ℝ), rate xRef (Φ y xRef s z)
    let τ : E → E → (E × E) → ℝ≥0 → WithTop ℝ≥0 := fun y xRef z e =>
      MeasureTheory.hittingAfter
        (fun t : ℝ≥0 => fun a : (E × E) × (E × E) × ℝ≥0 =>
          Λ a.1.1 a.1.2 a.2.1 t - (a.2.2 : ℝ))
        (Set.Ici (0 : ℝ)) 0 ((y, xRef), z, e)
    let next : E → E → ℝ≥0 → ((ℝ≥0 × (E × E)) ⊕ Unit) →
        ((ℝ≥0 × (E × E)) ⊕ Unit) := fun y xRef e r =>
      match r with
      | Sum.inr _ => Sum.inr ()
      | Sum.inl a =>
        if τ y xRef a.2 e = ⊤ then Sum.inr () else
          Sum.inl (a.1 + (τ y xRef a.2 e).untopD 0,
            S xRef (Φ y xRef (((τ y xRef a.2 e).untopD 0 : ℝ≥0) : ℝ) a.2))
    let record : E → E → (E × E) → (ℕ → ℝ≥0) → ℕ →
        ((ℝ≥0 × (E × E)) ⊕ Unit) := fun y xRef z₀ e n =>
      Nat.rec (Sum.inl (0, z₀)) (fun k r => next y xRef (e k) r) n
    let P : Measure (ℕ → ℝ) := Measure.infinitePi (fun _ : ℕ => expMeasure (1 : ℝ))
    let ε : (ℕ → ℝ) → ℕ → ℝ≥0 := fun w k => Real.toNNReal (w k)
    let history : E → E → (E × E) → (n : ℕ) → (ℕ → ℝ) →
        (Fin (n + 1) → ((ℝ≥0 × (E × E)) ⊕ Unit)) :=
      fun y xRef z₀ n w j => record y xRef z₀ (ε w) j.val
    let Rec := (ℝ≥0 × (E × E)) ⊕ Unit
    let Hist : ℕ → Type _ := fun n => Fin (n + 1) → Rec
    let readTime : Rec → ℝ := fun r => match r with
      | Sum.inl q => (q.1 : ℝ)
      | Sum.inr _ => 0
    let A : (n : ℕ) → ℝ≥0 → Set (Hist n) := fun n T =>
      {h | (∀ j, ∃ a : ℝ≥0 × (E × E), h j = Sum.inl a) ∧
        StrictMono (fun j => readTime (h j)) ∧
        ∀ i : Fin n, readTime (h i.succ) < (T : ℝ)}
    let eventTime : E → E → (E × E) → (ℕ → ℝ) → ℕ → WithTop ℝ≥0 :=
      fun y xRef z₀ w j => (record y xRef z₀ (ε w) j).elim
        (fun a => (a.1 : WithTop ℝ≥0)) (fun _ => ⊤)
    let I : E → E → (E × E) → ℝ≥0 → ℕ → Set (ℕ → ℝ) :=
      fun y xRef z₀ T n => {w | eventTime y xRef z₀ w n ≤ (T : WithTop ℝ≥0) ∧
        (T : WithTop ℝ≥0) < eventTime y xRef z₀ w (n + 1)}
    let liveTime : Rec → ℝ≥0 := fun r => r.elim Prod.fst (fun _ => 0)
    let d : (n : ℕ) → ℝ≥0 → Hist n → ℝ≥0 :=
      fun n T h => T - liveTime (h ⟨n, Nat.lt_succ_self n⟩)
    let survival : E → E → Rec → ℝ≥0 → ℝ → Prop :=
      fun y xRef r u e => r.elim
        (fun a => (u : WithTop ℝ≥0) < τ y xRef a.2 (Real.toNNReal e)) (fun _ => False)
    let C : E → E → (E × E) → (n : ℕ) → ℝ≥0 → Set (ℕ → ℝ) :=
      fun y xRef z₀ n T => {w | history y xRef z₀ n w ∈ A n T ∧
        survival y xRef (record y xRef z₀ (ε w) n) (d n T (history y xRef z₀ n w)) (w n)}
    let Path : ℝ≥0 → Type _ := fun T => {s : ℝ≥0 // s ≤ T} → E × E
    let Ψ : E → E → (E × E) → (n : ℕ) → (T : ℝ≥0) → Hist n → Path T :=
      fun y xRef z₀ n T h s =>
        Fin.foldl (n + 1) (fun z j => (h j).elim
          (fun a => if a.1 ≤ s.val then Φ y xRef ((s.val - a.1 : ℝ≥0) : ℝ) a.2 else z)
          (fun _ => z)) z₀
    ∃ Z : E → E → (E × E) → ℝ≥0 → (ℕ → ℝ) → (E × E),
      Measurable (fun a : ((E × E) × (E × E)) × ℝ≥0 × (ℕ → ℝ) =>
        Z a.1.1.1 a.1.1.2 a.1.2 a.2.1 a.2.2) ∧
      (∀ y xRef : E, ∀ z₀ : E × E, ∀ w : ℕ → ℝ, ∀ s : ℝ≥0,
        ∀ n : ℕ, ∀ a : ℝ≥0 × (E × E), w ∈ I y xRef z₀ s n →
          record y xRef z₀ (ε w) n = Sum.inl a →
          Z y xRef z₀ s w = Φ y xRef ((s - a.1 : ℝ≥0) : ℝ) a.2) ∧
      (∀ y xRef : E, ∀ z₀ : E × E, ∀ w : ℕ → ℝ, ∀ s : ℝ≥0,
        (¬ ∃ n, w ∈ I y xRef z₀ s n) → Z y xRef z₀ s w = z₀) ∧
      (∀ y xRef : E, ∀ z₀ : E × E, ∀ᵐ w ∂P, Z y xRef z₀ 0 w = z₀) ∧
      (∀ n : ℕ, ∀ T : ℝ≥0, ∀ y xRef : E, ∀ z₀ : E × E,
        ∀ w ∈ C y xRef z₀ n T,
          Ψ y xRef z₀ n T (history y xRef z₀ n w) =
            (fun s : {s : ℝ≥0 // s ≤ T} => Z y xRef z₀ s.val w)) := by
  classical
  let c : E → E → E := fun y xRef => y - η • gradient V xRef
  let Φ : E → E → ℝ → (E × E) → (E × E) := fun y xRef t z =>
    (c y xRef + Real.cos t • (z.1 - c y xRef) +
        (Real.sqrt η * Real.sin t) • z.2,
     (-Real.sin t / Real.sqrt η) • (z.1 - c y xRef) + Real.cos t • z.2)
  let S : E → (E × E) → (E × E) := fun xRef z =>
    (z.1, z.2 - (2 * inner ℝ z.2 (gradient V z.1 - gradient V xRef) /
      ‖gradient V z.1 - gradient V xRef‖ ^ 2) • (gradient V z.1 - gradient V xRef))
  let rate : E → (E × E) → ℝ := fun xRef z =>
    Real.sqrt η * max 0 (inner ℝ z.2 (gradient V z.1 - gradient V xRef))
  let Λ : E → E → (E × E) → ℝ≥0 → ℝ := fun y xRef z t =>
    ∫ s in (0 : ℝ)..(t : ℝ), rate xRef (Φ y xRef s z)
  let τ : E → E → (E × E) → ℝ≥0 → WithTop ℝ≥0 := fun y xRef z e =>
    MeasureTheory.hittingAfter
      (fun t : ℝ≥0 => fun a : (E × E) × (E × E) × ℝ≥0 =>
        Λ a.1.1 a.1.2 a.2.1 t - (a.2.2 : ℝ))
      (Set.Ici (0 : ℝ)) 0 ((y, xRef), z, e)
  let next : E → E → ℝ≥0 → ((ℝ≥0 × (E × E)) ⊕ Unit) →
      ((ℝ≥0 × (E × E)) ⊕ Unit) := fun y xRef e r =>
    match r with
    | Sum.inr _ => Sum.inr ()
    | Sum.inl a =>
      if τ y xRef a.2 e = ⊤ then Sum.inr () else
        Sum.inl (a.1 + (τ y xRef a.2 e).untopD 0,
          S xRef (Φ y xRef (((τ y xRef a.2 e).untopD 0 : ℝ≥0) : ℝ) a.2))
  let record : E → E → (E × E) → (ℕ → ℝ≥0) → ℕ →
      ((ℝ≥0 × (E × E)) ⊕ Unit) := fun y xRef z₀ e n =>
    Nat.rec (Sum.inl (0, z₀)) (fun k r => next y xRef (e k) r) n
  let P : Measure (ℕ → ℝ) := Measure.infinitePi (fun _ : ℕ => expMeasure (1 : ℝ))
  let ε : (ℕ → ℝ) → ℕ → ℝ≥0 := fun w k => Real.toNNReal (w k)
  let history : E → E → (E × E) → (n : ℕ) → (ℕ → ℝ) →
      (Fin (n + 1) → ((ℝ≥0 × (E × E)) ⊕ Unit)) :=
    fun y xRef z₀ n w j => record y xRef z₀ (ε w) j.val
  let Rec := (ℝ≥0 × (E × E)) ⊕ Unit
  let Hist : ℕ → Type _ := fun n => Fin (n + 1) → Rec
  let readTime : Rec → ℝ := fun r => match r with
    | Sum.inl q => (q.1 : ℝ)
    | Sum.inr _ => 0
  let A : (n : ℕ) → ℝ≥0 → Set (Hist n) := fun n T =>
    {h | (∀ j, ∃ a : ℝ≥0 × (E × E), h j = Sum.inl a) ∧
      StrictMono (fun j => readTime (h j)) ∧
      ∀ i : Fin n, readTime (h i.succ) < (T : ℝ)}
  let eventTime : E → E → (E × E) → (ℕ → ℝ) → ℕ → WithTop ℝ≥0 :=
    fun y xRef z₀ w j => (record y xRef z₀ (ε w) j).elim
      (fun a => (a.1 : WithTop ℝ≥0)) (fun _ => ⊤)
  let I : E → E → (E × E) → ℝ≥0 → ℕ → Set (ℕ → ℝ) :=
    fun y xRef z₀ T n => {w | eventTime y xRef z₀ w n ≤ (T : WithTop ℝ≥0) ∧
      (T : WithTop ℝ≥0) < eventTime y xRef z₀ w (n + 1)}
  let liveTime : Rec → ℝ≥0 := fun r => r.elim Prod.fst (fun _ => 0)
  let d : (n : ℕ) → ℝ≥0 → Hist n → ℝ≥0 :=
    fun n T h => T - liveTime (h ⟨n, Nat.lt_succ_self n⟩)
  let survival : E → E → Rec → ℝ≥0 → ℝ → Prop :=
    fun y xRef r u e => r.elim
      (fun a => (u : WithTop ℝ≥0) < τ y xRef a.2 (Real.toNNReal e)) (fun _ => False)
  let C : E → E → (E × E) → (n : ℕ) → ℝ≥0 → Set (ℕ → ℝ) :=
    fun y xRef z₀ n T => {w | history y xRef z₀ n w ∈ A n T ∧
      survival y xRef (record y xRef z₀ (ε w) n) (d n T (history y xRef z₀ n w)) (w n)}
  let Path : ℝ≥0 → Type _ := fun T => {s : ℝ≥0 // s ≤ T} → E × E
  let Ψ : E → E → (E × E) → (n : ℕ) → (T : ℝ≥0) → Hist n → Path T :=
    fun y xRef z₀ n T h s =>
      Fin.foldl (n + 1) (fun z j => (h j).elim
        (fun a => if a.1 ≤ s.val then Φ y xRef ((s.val - a.1 : ℝ≥0) : ℝ) a.2 else z)
        (fun _ => z)) z₀
  change
    ∃ Z : E → E → (E × E) → ℝ≥0 → (ℕ → ℝ) → (E × E),
      Measurable (fun a : ((E × E) × (E × E)) × ℝ≥0 × (ℕ → ℝ) =>
        Z a.1.1.1 a.1.1.2 a.1.2 a.2.1 a.2.2) ∧
      (∀ y xRef : E, ∀ z₀ : E × E, ∀ w : ℕ → ℝ, ∀ s : ℝ≥0,
        ∀ n : ℕ, ∀ a : ℝ≥0 × (E × E), w ∈ I y xRef z₀ s n →
          record y xRef z₀ (ε w) n = Sum.inl a →
          Z y xRef z₀ s w = Φ y xRef ((s - a.1 : ℝ≥0) : ℝ) a.2) ∧
      (∀ y xRef : E, ∀ z₀ : E × E, ∀ w : ℕ → ℝ, ∀ s : ℝ≥0,
        (¬ ∃ n, w ∈ I y xRef z₀ s n) → Z y xRef z₀ s w = z₀) ∧
      (∀ y xRef : E, ∀ z₀ : E × E, ∀ᵐ w ∂P, Z y xRef z₀ 0 w = z₀) ∧
      (∀ n : ℕ, ∀ T : ℝ≥0, ∀ y xRef : E, ∀ z₀ : E × E,
        ∀ w ∈ C y xRef z₀ n T,
          Ψ y xRef z₀ n T (history y xRef z₀ n w) =
            (fun s : {s : ℝ≥0 // s ≤ T} => Z y xRef z₀ s.val w))
  obtain ⟨Z, hZM, hZarc, hZfallback, hZgood⟩ :=
    AutoSamplingTheory.ExampleCases.ProximalBPS.ActualPhysicalTimeMeasurability.actual_physical_time_measurable_phase
      hα hαβ hV hH hη hβη
  refine ⟨Z, hZM, ?_, hZfallback, ?_, ?_⟩
  · intro y xRef z₀ w s n a hi hr
    exact hZarc y xRef z₀ w s n a hi.1 hi.2 hr
  · intro y xRef z₀
    filter_upwards [hZgood y xRef z₀] with w hw
    exact hw.2
  · intro n T y xRef z₀ w hw
    have hlive (k : Fin (n+1)) : ∃ a : ℝ≥0 × (E × E),
        record y xRef z₀ (ε w) k.val = Sum.inl a := hw.1.1 k
    obtain ⟨a, ha⟩ := hlive ⟨n, Nat.lt_succ_self n⟩
    have hsurv : ((T - a.1 : ℝ≥0) : WithTop ℝ≥0) < τ y xRef a.2 (ε w n) := by
      have hh := hw.2
      change survival y xRef (record y xRef z₀ (ε w) n)
        (T - liveTime (record y xRef z₀ (ε w) n)) (w n) at hh
      rw [ha] at hh
      exact hh
    have hnext : eventTime y xRef z₀ w (n+1) =
        (if τ y xRef a.2 (ε w n) = ⊤ then ⊤ else
          ((a.1 + (τ y xRef a.2 (ε w n)).untopD 0 : ℝ≥0) : WithTop ℝ≥0)) := by
      change (next y xRef (ε w n) (record y xRef z₀ (ε w) n)).elim _ _ = _
      rw [ha]
      dsimp only [next]
      split_ifs <;> rfl
    have hend : (T : WithTop ℝ≥0) < eventTime y xRef z₀ w (n+1) := by
      rw [hnext]
      exact terminal_event_after T a.1 (τ y xRef a.2 (ε w n)) hsurv
    funext s
    exact finite_history_fold_eq_process (fun u => Φ y xRef (u : ℝ))
      (record y xRef z₀ (ε w)) z₀ n T rfl hlive hend
      (fun u => Z y xRef z₀ u w)
      (fun u k a hlo hhi hr => hZarc y xRef z₀ w u k a hlo hhi hr) s.val s.property

#print axioms actual_history_path_identification
end
end PathInterfaces93

namespace PathInterfaces93
set_option pp.explicit true in
set_option pp.fullNames true in
set_option pp.deepTerms true in
#check actual_history_path_identification
end PathInterfaces93
