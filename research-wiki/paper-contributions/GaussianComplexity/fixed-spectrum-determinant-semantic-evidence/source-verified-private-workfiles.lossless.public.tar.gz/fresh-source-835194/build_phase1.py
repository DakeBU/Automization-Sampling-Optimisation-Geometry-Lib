from pathlib import Path
import hashlib
import html
import json
import re
import shutil
from datetime import datetime, timezone

ROOT = Path('/Users/zhouhuanjian/ASTIS-GC')
PRIVATE = ROOT / '.astis/huanjian-fixed-spectrum-determinant-20261108/fresh-source-835194'
PUBLIC = ROOT / 'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-determinant-semantic-evidence/fresh-source-reader-835194/phase1'
SOURCE_REL = '.astis/huanjian-resume-20261103/2610.20492v1.html'
EXPECTED = '6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'

def digest(data):
    return hashlib.sha256(data).hexdigest()

def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

source = (ROOT / SOURCE_REL).read_bytes()
assert digest(source) == EXPECTED
PRIVATE.mkdir(parents=True, exist_ok=True)
PUBLIC.mkdir(parents=True, exist_ok=True)
raw_dir = PRIVATE / 'raw-inputs'
raw_dir.mkdir(exist_ok=True)
(raw_dir / '2610.20492v1.html').write_bytes(source)

instructions = [
    'AGENTS.md', 'CONTRIBUTING.md',
    'docs/theorem-publication-protocol.md',
    'docs/proof-digestion-protocol.md',
    'docs/evidence-routed-memory-protocol.md',
    'docs/contributor-codex-contract.md',
    '.agents/skills/astis-semantic-roundtrip/SKILL.md',
    '.agents/prompts/collaborator-contribution.md',
    '.agents/skills/astis-substantive-advance/SKILL.md',
    'LICENSE_SCOPE.md', '.agents/prompts/samplewiki-route.md',
    'docs/formalization-protocol.md',
]
input_items = []
for name in instructions:
    data = (ROOT / name).read_bytes()
    dest = raw_dir / 'instructions' / name
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(data)
    input_items.append({'original_path': str(ROOT / name), 'copy_path': str(dest), 'sha256': digest(data), 'bytes': len(data), 'kind': 'repository-process-instruction'})
input_items.append({'original_path': str(ROOT / SOURCE_REL), 'copy_path': str(raw_dir / '2610.20492v1.html'), 'sha256': digest(source), 'bytes': len(source), 'kind': 'sole-primary-mathematical-source'})

assignment = '''Fresh anti-anchored SOURCE reviewer, RAWPHASE1 ONLY before any candidate exposure, required by AGENTS publication/proof-digestion/semantic-roundtrip. cwd /Users/zhouhuanjian/ASTIS-GC. Read explicit instructions AGENTS.md, CONTRIBUTING.md, docs/theorem-publication-protocol.md, docs/proof-digestion-protocol.md, docs/evidence-routed-memory-protocol.md, docs/contributor-codex-contract.md, .agents/skills/astis-semantic-roundtrip/SKILL.md and necessary source-dependency instructions. Use explicit paths, no broad oldevidence discovery. Sole primary source .astis/huanjian-resume-20261103/2610.20492v1.html SHA6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915, selected S4.E11 + A3.SS4 AppendixC.4 determinant/public-spectrum normalizer context and relevant original setup. Independently freeze 7semantic slots/sourcecontract with exactobjects/domains/quantifiers/assumptions/conclusions/scopes/constants; distinguish actualprecision/det/eigenvalue product versus unweightedGaussianintegral/knownZ/actualdensity/fullC4/mainlowerbound; source fullrealO(d) bothsigns/d,kappa/endpoints, real powers/reference measure evidence vsinference. Do NOT inspect candidatecode/Test/seals/rootpreparedsource/prose/publications/audits/anonymouspacket/sourcegraphs/otherreviews/oldverdicts/currentfrontier beforephase1freeze. Root sole prover, you are source-review role only. Ownoutputs ONLY research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-determinant-semantic-evidence/fresh-source-reader-835194/phase1/ and private .astis/huanjian-fixed-spectrum-determinant-20261108/fresh-source-835194/. Pin/copy rawinputs losslessly, record exactexposure and actualsourcehash, freeze manifest+7slots+contract+rawsourcewindows. STOP with exacthashes. Phase2 selective anonymousstatement/approveddefinitions/genuineblind reconstruction comes only afteryourphase1freeze, then secondfreeze beforefullcode/prose/critical ancestry. No sourceverdict/API/ledger/shared edit now.'''
(raw_dir / 'assignment.txt').write_text(assignment)
input_items.append({'original_path': 'parent-agent assignment message', 'copy_path': str(raw_dir / 'assignment.txt'), 'sha256': digest(assignment.encode()), 'bytes': len(assignment.encode()), 'kind': 'verbatim-task-text-excluding-message-envelope'})

lines = source.splitlines(keepends=True)
windows = [
    ('01-title', 1, 8, 'Source identity; title only.'),
    ('02-introduction-target', 351, 370, 'Centered Gaussian, unknown precision, real vectors, query model.'),
    ('03-preliminaries', 636, 691, 'Euclidean notation; full real orthogonal group and both signs; precision class and potential.'),
    ('04-main-theorem-scope', 1054, 1080, 'Context only: the main lower bound has additional parameter restrictions.'),
    ('05-fixed-spectrum-family', 1081, 1107, 'Selected S4.E11, parameter range, Haar construction, potential/target, public spectrum.'),
    ('06-admissibility-statement', 1301, 1318, 'Universal quantifier over O(d) in Lemma 4.6.'),
    ('07-appendix-C4', 4135, 4170, 'Complete C.4 proof, including actual Gaussian normalization display.'),
]
window_records = []
for slug, first, last, reason in windows:
    raw = b''.join(lines[first-1:last])
    dest = PUBLIC / 'raw-source-windows' / (slug + '.html')
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(raw)
    window_records.append({'path': str(dest.relative_to(ROOT)), 'first_original_line_1_based': first, 'last_original_line_1_based_inclusive': last, 'sha256': digest(raw), 'bytes': len(raw), 'purpose': reason, 'transformation': 'None: exact concatenation of original byte lines, preserving all line endings.'})

# Preserve the wider raw requests actually issued before narrowing the windows.
for slug, first, last in [('requested-raw-1025-1145',1025,1145), ('requested-raw-4135-4269',4135,4269)]:
    (raw_dir / (slug + '.html')).write_bytes(b''.join(lines[first-1:last]))

write_json(PUBLIC / 'raw-source-windows.json', {'source_sha256': EXPECTED, 'line_numbering': 'Python splitlines(keepends=True), identical to the observed 4269-line source for these LF-terminated windows.', 'windows': window_records})

slots = {
 'schema_version': 1,
 'reviewer': '/root/reader_835194',
 'phase': 'RAWPHASE1_SOURCE_ONLY',
 'source_sha256': EXPECTED,
 'source_anchor': ['S4.E11', 'S4.SS1.p1', 'S4.Thmtheorem6', 'A3.SS4', 'A3.Ex160'],
 'candidate_exposure_before_freeze': False,
 'slots': {
  'objects': {
   'source_explicit': [
    'An integer dimension d and real spectral parameter kappa; indices i=1,...,d.',
    'theta_i=((i-1/2)*pi)/d; lambda_i=(kappa+1)/2+((kappa-1)/2)*cos(theta_i); Lambda=diag(lambda_1,...,lambda_d).',
    'O is a real d-by-d orthogonal matrix. A=O Lambda O^T is the actual precision matrix; it is not the covariance.',
    'f_A(x)=x^T A x/2 (called V_A in C.4); pi_A=N(0,A^(-1)); Z_A is the Gaussian normalizing constant.'
   ],
   'direct_mathematical_inference': ['det Lambda is the finite product of the actual lambda_i, i=1,...,d; a d-dimensional diagonal determinant identity, not an additional source parameter.'],
   'evidence': ['S4.E11, original lines 1089-1105', 'S2.p2 through S2.E1, original lines 660-680', 'A3.SS4.p2-p3, original lines 4147-4165']
  },
  'domains': {
   'source_explicit': [
    'The selected hard family assumes integer d>=2 and real kappa>=2, including d=2 and kappa=2.',
    'O(d)={O in R^(d x d): O^T O=I_d}; this is the full real orthogonal group, not SO(d), a complex unitary group, or a determinant-conditioned component.',
    'Real x in R^d. For every valid index: 0<theta_i<pi, -1<cos(theta_i)<1, and 1<lambda_i<kappa.',
    'The ambient precision class is symmetric real matrices I_d<=A<=kappa I_d, in positive-semidefinite order.'
   ],
   'direct_mathematical_inference': ['The actual Lambda and A are positive definite; det Lambda=det A>0. The powers in A3.Ex160 are ordinary real powers of positive real quantities. d/2 is real division, possibly a half-integer; (-1/2) is a real exponent.'],
   'scope_caution': 'Section 2 permits ambient d>=1 and kappa>=1; that does not replace the selected S4.E11 hard-family hypotheses. The grid has strictly interior eigenvalues, although the admissible matrix class uses closed endpoint bounds.',
   'evidence': ['Section 2 notation, original lines 639-667', 'S4.SS1.p1 and S4.E11, original lines 1089-1099', 'A3.SS4.p1, original lines 4141-4144']
  },
  'quantifiers': {
   'source_explicit': [
    'For every integer d>=2 and every real kappa>=2, define the deterministic theta_i, lambda_i and Lambda.',
    'For every O in O(d), form A=O Lambda O^T; the admissibility statement is universal in O.',
    'The hard-input distribution draws O from Haar probability on the full O(d), independently of the algorithm private randomness.',
    'For fixed Lambda, Z_A is independent of O; it is known whenever the spectrum is public.'
   ],
   'direct_mathematical_inference': ['The determinant/product statement is pointwise for every orthogonal O and does not need a random draw or an almost-everywhere qualifier. There is no determinant-sign restriction.'],
   'scope_caution': 'No delta, epsilon, algorithm, query count, or large-d threshold belongs in the local algebraic determinant contract. Those occur in the separate main lower bound.',
   'evidence': ['S4.SS1.p1, original lines 1089-1106', 'S4.Thmtheorem6, original lines 1314-1315', 'A3.SS4.p3, original lines 4161-4165']
  },
  'assumptions': {
   'source_explicit': [
    'd>=2; kappa>=2; exact S4.E11 grid; O real orthogonal; A literally O Lambda O^T.',
    'Spectrum public is a condition for the knowledge assertion, not a hypothesis needed for determinant invariance or the mathematical value of the normalizer.'
   ],
   'proof_ingredients_not_additional_premises': [
    'Strict cosine/grid eigenvalue bounds, positive definiteness and positive determinant follow from the source construction.',
    'Orthogonal determinant identities, diagonal determinant/product identity and Gaussian integration are dependencies to establish inside the corresponding proof; they must not become user-supplied conclusion-shaped assumptions.',
    'Gaussian integrability/normalization for a positive definite real quadratic is mathematical content of an integral-level result, not something the source asks an algorithm to provide.'
   ],
   'forbidden_unjustified_restrictions': ['det O=+1 only', 'd even', 'kappa>2 only', 'large-d or kappa<=d^(1-delta) for this local component', 'assuming det A=det Lambda or assuming the target integral value as a binder'],
   'evidence': ['S4.E11 and S4.Thmtheorem6', 'A3.SS4.p1-p3']
  },
  'conclusion': {
   'bounded_determinant_component_direct_inference': 'For actual A=O Lambda O^T, det A=det Lambda=product_{i=1}^d lambda_i>0; this scalar depends on d,kappa through the fixed grid and is independent of O.',
   'source_explicit_normalizer_display': 'Z_A=(2*pi)^(d/2)*(det A)^(-1/2)=(2*pi)^(d/2)*(det Lambda)^(-1/2).',
   'source_explicit_knowledge_conclusion': 'Since Lambda is fixed, Z_A is independent of O and is known whenever the spectrum is public.',
   'reference_measure_inference': 'The intended unweighted normalizing integral is integral_{R^d} exp(-x^T A x/2) dx, with Euclidean Lebesgue measure. The selected C.4 text does not itself write this integral or explicitly name Lebesgue measure; this interpretation follows from its Gaussian-integration statement, potential, Gaussian target, and usual density convention.',
   'not_interchangeable': ['The actual matrix determinant/product identity alone is not an integral evaluation.', 'A scalar defined by the displayed formula is not, merely by definition, proved equal to the unweighted integral.', 'Known Z does not imply that the full density at x is known from the spectrum alone.', 'This local component does not prove the full C.4 admissibility/smoothness/minimizer argument or the main query lower bound.'],
   'evidence': ['A3.Ex160, original line 4161', 'A3.SS4.p3, original lines 4155-4165', 'S4.SS1.p1, original lines 1100-1106']
  },
  'scopes_senses': {
   'source_explicit': ['Full real O(d) has determinant +1 and -1 components, each Haar probability 1/2. The universal hard-family/admissibility claim covers both.', 'A is the precision of N(0,A^(-1)). Lambda and its spectrum are deterministic; O is the hidden random eigenbasis.', 'Independence of Z from O holds with d and kappa, hence Lambda, fixed.'],
   'mathematical_inferences': ['A density under the usual Euclidean convention is p_A(x)=Z_A^(-1)*exp(-x^T A x/2). Its quadratic factor generally depends on O, even though Z_A does not.', 'Unweighted Lebesgue integration must be distinguished from expectation under a normalized Gaussian reference measure or Haar probability. Changing the reference measure changes the normalizer identity.', 'No orientation-dependent absolute determinant factor remains: the actual conjugated precision determinant has det(O)^2=1. This does not require det(O)=+1.'],
   'outside_bounded_component': ['Full C.4 also establishes spectral admissibility, C-infinity regularity, Hessian A, 1-strong convexity, kappa-smoothness and unique minimizer 0.', 'Theorem 4.1 additionally has fixed delta in (0,1), d>=d0(delta), 2<=kappa<=d^(1-delta), 0<epsilon<=1/10, and a query lower bound delta*sqrt(kappa)*log(d)/256. These do not become local determinant assumptions or conclusions.'],
   'evidence': ['Section 2 notation, original lines 645-652', 'S4.SS1.p1, original lines 1098-1106', 'A3.SS4', 'S4.Thmtheorem1, original lines 1065-1074']
  },
  'constant_dependencies': {
   'exact_constants': ['theta_i uses (i-1/2)*pi/d, not endpoint nodes.', 'lambda_i uses (kappa+1)/2 and (kappa-1)/2.', 'The potential has factor 1/2.', 'The unweighted Gaussian normalizer factor is (2*pi)^(d/2); determinant exponent is -1/2.'],
   'dependencies': ['The finite product det Lambda and the corresponding positive scalar normalizer depend on d and kappa via the fixed grid; they have no O-dependence.', 'No algorithm seed, query budget, epsilon or delta enters the bounded determinant/normalizer identity.', 'Public spectrum is sufficient knowledge of eigenvalues with multiplicities to compute the determinant and normalizer; no particular cost model for that computation is asserted here.'],
   'endpoints': ['d=2 and kappa=2 are included.', '1<lambda_i<kappa for the selected family; 1 and kappa are comparison constants, not attained eigenvalues.', 'The source has no parity assumption: odd d makes d/2 half-integral.'],
   'evidence': ['S4.E11', 'S4.SS1.p1', 'A3.SS4.p1', 'A3.Ex160']
  }
 }
}
write_json(PUBLIC / 'semantic-slots.json', slots)

contract = r'''# Source-only contract frozen before candidate exposure

Reviewer: `/root/reader_835194`. Phase: `RAWPHASE1_SOURCE_ONLY`.
Sole primary mathematical source: *On Complexity of Gaussian Sampling*,
arXiv:2610.20492v1, original HTML SHA-256
`6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915`.
Selected anchors: S4.E11 and Appendix C.4 (A3.SS4 / A3.Ex160), with the
original Section 2 setup and Lemma 4.6 statement. This document makes no
candidate comparison or fidelity decision.

## Exact source objects and range

For every integer (dge2), real (kappage2), and (i=1,ldots,d),

[
	heta_i=rac{(i-	frac12)pi}{d},qquad
lambda_i=rac{kappa+1}{2}+rac{kappa-1}{2}cos	heta_i,qquad
Lambda=operatorname{diag}(lambda_1,ldots,lambda_d).
]

For every real orthogonal (Oinmathrm O(d)), put (A=OLambda O^	op).
Here (A) is the **actual precision**, and the covariance is (A^{-1}).
The source's full real orthogonal group is
({Oinmathbb R^{d	imes d}:O^	op O=I_d}). Its two determinant-sign
components each have Haar probability (1/2); neither component is excluded.
The hard-input law draws (O) from the full Haar probability, independently
of algorithm randomness. The algebraic statement below is pointwise for every
(O), requiring no probability or almost-everywhere qualification.

The original formulas and Appendix C.4 give
(0<	heta_i<pi), (-1<cos	heta_i<1), and
(1<lambda_i<kappa). Thus the family's eigenvalues are strictly interior
even though admissibility is the closed comparison (I_dpreceq Apreceqkappa I_d).
Both (d=2) and (kappa=2) are included. No parity restriction occurs.
The ambient Section 2 class permits (dge1,kappage1); that broader
ambient range must not silently replace the selected hard-family range.

## Bounded determinant component

From these actual source objects, the direct finite-dimensional algebraic
consequence is

[
det(OLambda O^	op)=det A=detLambda
=prod_{i=1}^dlambda_i>0.
]

The determinant and eigenvalue product depend on (d,kappa), and are
independent of (O). The display of the finite product is a direct
linear-algebra expansion, **not a verbatim display in C.4**. The orthogonal
determinant cancellation is ((det O)^2=1); it does not assume positive
orientation. The determinant is of the actual conjugated precision, rather
than an unrelated scalar named after that matrix.

The grid formula and orthogonality are source inputs. Positive definiteness,
positive determinant, the diagonal determinant product and the conjugation
determinant identity are consequences/dependencies, not extra public premises.
No (delta,arepsilon), query budget, algorithm, large-(d) threshold,
or restriction (kappale d^{1-delta}) belongs in this local contract.

## Separate normalization levels

The source explicitly identifies (f_A(x)=V_A(x)=x^	op A x/2),
(pi_A=N(0,A^{-1})), and states by Gaussian integration

[
Z_A=(2pi)^{d/2}(det A)^{-1/2}
   =(2pi)^{d/2}(detLambda)^{-1/2}.
]

It then states that (Z_A) is independent of (O), since (Lambda) is
fixed, and is known whenever the spectrum is public. Public spectrum is a
condition of this **knowledge assertion**, not an assumption needed for the
determinant identity or the mathematical value of the normalizer.

These levels must remain distinct:

| Level | Mathematical meaning and source status |
|---|---|
| Actual determinant/product | The algebraic identity above follows from the actual S4.E11 precision construction. |
| Formula scalar | The positive real expression ((2pi)^{d/2}(prod_ilambda_i)^{-1/2}); giving this scalar a name does not itself evaluate an integral. |
| Unweighted Gaussian integral | (int_{mathbb R^d}exp(-x^	op A x/2),dx=Z_A). C.4 explicitly invokes Gaussian integration, but does not itself print this integral or name its reference measure. The unweighted Euclidean Lebesgue interpretation is a mathematical convention inferred from the potential, target and displayed normalizer. |
| Known normalizer | The explicit conditional statement: the normalizer is known whenever the fixed spectrum is public. This requires no recovery of the hidden eigenbasis. |
| Actual density | Under the Euclidean convention, (p_A(x)=Z_A^{-1}exp(-x^	op A x/2)). This density formula is an inference from the source Gaussian convention, not a separately printed C.4 formula. Its quadratic factor generally depends on (O). |
| Full C.4 | Also includes admissibility, (C^infty) regularity, Hessian (A), strong convexity, smoothness and unique minimizer 0. |
| Main lower bound | A separate statistical/oracle conclusion with additional (delta,arepsilon,d_0) and (kappa)-range restrictions. |

In particular, determinant invariance alone does not evaluate the actual
integral; a closed-form scalar definition alone does not prove it is that
integral. No Gaussian probability reference measure or Haar expectation may
replace unweighted (dx) while retaining the same displayed normalizer.

The source's fractional powers are ordinary real powers on positive bases.
In ((2pi)^{d/2}), (d/2) is real division and may be half-integral; it is
not integer truncation. The exponent (-1/2) is real, so for the positive
determinants here it means reciprocal positive square root. Positivity follows
from the construction and is not an independent mathematical restriction.

## Source context kept outside the bounded component

Lemma 4.6 says universally that (I_dpreceq OLambda O^	oppreceqkappa I_d).
C.4 proves this, then shows the potential has Hessian (A), is 1-strongly
convex and (kappa)-smooth, and has unique minimizer 0. A determinant-only
result supplies none of those whole-proof completion claims on its own.

Theorem 4.1 fixes (deltain(0,1)), has a threshold (d_0(delta)), assumes
(dge d_0(delta)), (2lekappale d^{1-delta}), and
(0<arepsilonle1/10), then lower-bounds query complexity by
(deltasqrtkappalog(d)/256). Those restrictions and that query conclusion
are contextual only. No local determinant theorem can be counted as that
lower bound or as the full Appendix C.4 proof.

## Exposure boundary

Before this freeze, the reviewer read only the assignment, the listed
repository process instructions and the one pinned primary HTML source.
No candidate Lean, test, statement seal, prepared source card, lesson, prose,
publication record, semantic audit, anonymous decoder packet, source graph,
other review, earlier verdict or current frontier was inspected. The exact
read/query ranges, wider initially requested source windows, and resulting
truncation limits are recorded in `exposure-log.json`. The seven canonical
slots are independently recorded in `semantic-slots.json`.

This is a raw-source contract freeze, not an implementation review, an API
recommendation, a source-fidelity verdict, or a source-proof-graph approval.
Phase 2 requires a separately authorized selective anonymous statement,
approved definitions and genuine blind reconstruction, followed by its own
freeze before full code/prose/critical ancestry exposure.
'''
(PUBLIC / 'source-contract.md').write_text(contract)

exposure = {
 'schema_version': 1,
 'reviewer': '/root/reader_835194',
 'phase': 'RAWPHASE1_SOURCE_ONLY',
 'sole_primary_source': {'path': str(ROOT / SOURCE_REL), 'expected_sha256': EXPECTED, 'actual_sha256': digest(source), 'bytes': len(source), 'observed_wc_lines': 4269},
 'assignment_exposure': 'The parent assignment identifies the requested source anchors and distinctions to audit; it contains no candidate signature, code, test, prior verdict, or reconstruction. Its exact text excluding the message envelope is pinned privately.',
 'process_instructions_read': instructions,
 'instruction_read_details': [
  'AGENTS.md: full cat (495 lines). CONTRIBUTING.md: full cat (209 lines).',
  'Initial combined cat of CONTRIBUTING/theorem-publication/semantic skill and proof-digestion/evidence-routed/contributor contract returned truncated combined tool output. No mathematical candidate artifact was involved.',
  'Semantic skill was then read fully. Proof-digestion was then reread as original lines 1-245 and 246-455, completely.',
  'Theorem-publication was reread as original lines 130-231 then 1-129, completely. Evidence-routed-memory and contributor-codex-contract were reread fully in the final instruction-read command.',
  'Additional explicit process dependencies read fully: collaborator-contribution prompt, substantive-advance skill, LICENSE_SCOPE, SampleWiki route prompt, formalization protocol.',
  'No scheduling command, current dashboard/frontier, publication packet, shared library search, build, or Lean tool was run; these would be outside this source-only phase.'
 ],
 'explicit_instruction_existence_checks': {p: False for p in [
  '/Users/zhouhuanjian/AGENTS.md',
  '/Users/zhouhuanjian/ASTIS-GC/research-wiki/AGENTS.md',
  '/Users/zhouhuanjian/ASTIS-GC/research-wiki/paper-contributions/AGENTS.md',
  '/Users/zhouhuanjian/ASTIS-GC/research-wiki/paper-contributions/GaussianComplexity/AGENTS.md',
  '/Users/zhouhuanjian/ASTIS-GC/research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-determinant-semantic-evidence/AGENTS.md',
  '/Users/zhouhuanjian/ASTIS-GC/.astis/AGENTS.md',
  '/Users/zhouhuanjian/ASTIS-GC/.astis/huanjian-resume-20261103/AGENTS.md',
  '/Users/zhouhuanjian/ASTIS-GC/.astis/huanjian-fixed-spectrum-determinant-20261108/AGENTS.md']},
 'source_exposure_sequence': [
  {'operation': 'sha256, wc and anchor-only rg', 'patterns': ['id="S4.E11"','id="A3.SS4"','<title>','id="S4"','id="S1"'], 'result': 'Supplied hash confirmed; title and line locations printed; 951991 bytes, 4269 lines.'},
  {'operation': 'raw sed requests', 'requested_inclusive_line_ranges': [[1025,1145],[4135,4269]], 'truncation': 'Combined raw output was truncated by the orchestration output limit (tool reported 12108 original tokens). The exact wider requested bytes are pinned privately; not every requested character was rendered to the reviewer. The output included preceding S3 tail, Theorem 4.1, family, C.4, and the source footer. No repository-authored source summary was used.'},
  {'operation': 'source-only heading/setup locator script', 'filters': 'For original lines below 800, h2/h3 headings or alttext containing Z_{, mathcal F, mathcal G, O(d), mathbb R; plus location of S4.Thmtheorem6 anywhere. Math alttext substituted and tags stripped.', 'rendered_original_lines': [352,366,428,636,646,667,673,700,755,789,1311]},
  {'operation': 'own source-to-readable transformation; no other source used', 'requested_inclusive_line_ranges': [[351,395],[636,754],[1081,1135],[1295,1365],[4135,4188]], 'method': 'Per original line, replace complete same-line math by alttext; strip HTML tags; unescape entities; collapse whitespace; print nonempty text with original line numbers.', 'limitations': 'The multi-line S2.E2 math and a footer img/a fragment did not fully normalize in this display. They are outside the determinant contract. The selected grid and C.4 formulas normalized completely.'},
  {'operation': 'source-only keyword locator', 'patterns': ['normaliz','Lebesgue','density','Z_{A}','dx','det','prod'], 'filter': 'Print only matching original lines containing p-start, alttext or heading tags; same own per-line math-alttext/tag-stripping method.', 'rendered_original_lines': [649,650,652,660,1422,1934,2056,2347,2348,2355,2357,2369,2378,2404,2409,2414,2415,2421,2430,2437,2445,2446,2451,2455,2463,2468,2522,2553,2568,2575,2580,2583,2758,2794,2796,2802,2811,2816,2832,2837,3374,4039,4161,4164], 'scope': 'This locator also exposed isolated normalization/density/dx/determinant hits from other sections of the same primary source, notably the different hidden-determinant-sign family. They were not read as candidate material or used to replace S4.E11/C.4. Because of its line filter this scan is not evidence that a phrase is absent from the entire source.'}
 ],
 'excluded_material_not_inspected': ['candidate code','candidate tests','statement seals','root-prepared source cards or extracts','candidate prose or declaration lessons','publication metadata','semantic audit registries','anonymous statement/decoder packets','source graphs','other reviewers','old verdicts','current frontier','Mathlib/local API inventory','Git status/diff/log'],
 'file_write_scope': [str(PUBLIC), str(PRIVATE)],
 'independence': 'Root is the sole proving actor. This actor only reads the raw primary source and process instructions and creates its disjoint source-freeze evidence. No other reviewer output has been accessed.',
 'source_claim_status': 'No implementation-fidelity verdict or repair ruling is issued in phase 1.'
}
write_json(PUBLIC / 'exposure-log.json', exposure)
write_json(PRIVATE / 'raw-inputs-manifest.json', {'inputs': input_items, 'raw_source_is_byte_identical': True, 'source_sha256': EXPECTED})

# Manifest is written last; it intentionally does not hash itself or the receipt.
artifacts = []
for base in [PUBLIC, PRIVATE]:
    for path in sorted(base.rglob('*')):
        if path.is_file() and path.name not in {'phase1-manifest.json', 'freeze-receipt.json'}:
            data = path.read_bytes()
            artifacts.append({'path': str(path.relative_to(ROOT)), 'sha256': digest(data), 'bytes': len(data)})
manifest = {
 'schema_version': 1,
 'freeze_id': 'fresh-source-reader-835194-RAWPHASE1-v1',
 'frozen_at_utc': datetime.now(timezone.utc).isoformat(),
 'source_title': 'On Complexity of Gaussian Sampling',
 'source_version': '2610.20492v1',
 'source_path': SOURCE_REL,
 'actual_source_sha256': EXPECTED,
 'candidate_exposure_before_freeze': False,
 'phase1_scope': 'Independent raw-source seven-slot/contract freeze only; no candidate comparison, API work, source verdict, shared-state edit, or proof search.',
 'artifacts': artifacts,
 'manifest_hash_rule': 'This file does not hash itself. Its exact SHA-256 and the principal artifact hashes appear in freeze-receipt.json and the return message.'
}
write_json(PUBLIC / 'phase1-manifest.json', manifest)
receipt = {'freeze_id': manifest['freeze_id'], 'source_sha256': EXPECTED}
for key, path in [
 ('manifest_sha256', PUBLIC / 'phase1-manifest.json'),
 ('seven_slots_sha256', PUBLIC / 'semantic-slots.json'),
 ('source_contract_sha256', PUBLIC / 'source-contract.md'),
 ('exposure_log_sha256', PUBLIC / 'exposure-log.json'),
 ('raw_windows_index_sha256', PUBLIC / 'raw-source-windows.json'),
 ('raw_inputs_manifest_sha256', PRIVATE / 'raw-inputs-manifest.json')]:
    receipt[key] = digest(path.read_bytes())
write_json(PUBLIC / 'freeze-receipt.json', receipt)
print(json.dumps(receipt, indent=2))
