from pathlib import Path
import hashlib
import json
import re
from bs4 import BeautifulSoup
from extract_source import ROOT, SOURCE, OUT, EXPECTED, normalized

def digest(b):
    return hashlib.sha256(b).hexdigest()

def write(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

raw = SOURCE.read_bytes()
assert digest(raw) == EXPECTED
soup = BeautifulSoup(raw, 'html.parser')
(OUT / 'source-original.html').write_bytes(raw)

instruction_paths = [
    'AGENTS.md', 'docs/proof-digestion-protocol.md',
    'docs/evidence-routed-memory-protocol.md', 'docs/theorem-publication-protocol.md',
    '.agents/skills/astis-semantic-roundtrip/SKILL.md',
    '.agents/skills/astis-source-dependency-audit/SKILL.md',
    '.agents/skills/astis-proof-dag/SKILL.md',
]
instructions = []
for p in instruction_paths:
    b = (ROOT / p).read_bytes()
    name = 'instruction-' + p.replace('/', '__')
    (OUT / name).write_bytes(b)
    instructions.append({'path': p, 'sha256': digest(b), 'snapshot': name, 'exposure': 'full-text'})

N = []
def node(key, kind, anchors, claim, role='source-assertion', notes=None):
    item = {'id': 'sg:fs-admiss:' + key, 'kind': kind, 'source_anchors': anchors,
            'claim_or_meaning': claim, 'evidence_role': role,
            'formal_status': 'not-assessed-source-only'}
    if notes:
        item['notes'] = notes
    N.append(item)

node('notation', 'definition', ['S2.p1.1'], 'Euclidean norm; I_d is the real d by d identity; for symmetric A,B, A ≼ B means B−A is positive semidefinite.')
node('orthogonal', 'definition', ['S2.p2.1'], 'O(d) = {O ∈ R^(d×d) : OᵀO = I_d}. Haar probability and determinant components are separate distributional context.', notes='For Lemma 4.6 only the real square orthogonal-matrix predicate is used. Haar law and determinant component are not hypotheses.')
node('precision-class', 'definition', ['S2.SS0.SSS0.Px1.p1.1', 'S2.Ex1'], 'For integer d≥1 and κ≥1, A_(d,κ) = {real d×d A : A=Aᵀ and I_d ≼ A ≼ κ I_d}.')
node('target-potential', 'definition', ['S2.SS0.SSS0.Px1.p1.2', 'S2.E1'], 'On the precision class, f_A(x)=xᵀAx/2, π_A=N(0,A^(−1)), FO_A(x)=(xᵀAx/2, Ax).')
node('oracle-equivalence', 'source-claim', ['S2.SS0.SSS0.Px1.p2.1'], 'Exact value-and-gradient, gradient-only and matrix–vector access have equal query complexity because Ax determines xᵀAx/2.', role='independent-background-context', notes='The heading Admissibility and oracle equivalence does not make oracle equivalence a premise of Lemma 4.6.')
node('uniform-accuracy', 'definition', ['S2.SS0.SSS0.Px2.p1.1', 'S2.E2', 'S2.SS0.SSS0.Px4.p1.1', 'S2.SS0.SSS0.Px4.p1.2'], 'Algorithm output law averages internal randomness. Accuracy is uniform over A∈A_(d,κ), and query budget is a deterministic cap in each run.', role='consumer-context')
node('hard-parameters', 'standing-assumptions', ['S4.SS1.p1.1'], 'The cosine hard family is introduced for integer d≥2 and real κ≥2. These inherited assumptions remain in force at Lemma 4.6.')
node('cosine-grid', 'literal-definition', ['S4.E11'], 'For i=1,…,d: θ_i=((i−1/2)π)/d; λ_i=(κ+1)/2 + ((κ−1)/2)cos θ_i; Λ=diag(λ_1,…,λ_d).', notes='One-based indexing is conveyed by diag(λ_1,…,λ_d). This is the actual cosine grid, not an arbitrary spectrum with an assumed envelope.')
node('rotated-precision', 'literal-definition', ['S4.SS1.p1.2'], 'For the hard family draw O from Haar(O(d)) independently of the algorithm seed and set A=OΛOᵀ, f_A(x)=xᵀAx/2, π_A=N(0,A^(−1)).', notes='The matrix formula is deterministic once O is given. The pointwise lemma quantifies over every O∈O(d), requiring neither Haar randomness nor seed independence.')
node('public-spectrum', 'source-claim', ['S4.SS1.p2.1', 'S1.SS1.p4.1'], 'The spectrum is deterministic and may be known to the algorithm; the normalizing constant is known; the unknown component is the eigenbasis.', role='consumer-context')
node('lemma-4.6', 'source-anchor', ['S4.Thmtheorem6', 'S4.Thmtheorem6.p1.1'], 'For every O∈O(d), A=OΛOᵀ satisfies I_d ≼ A ≼ κ I_d.', notes='This is the literal numbered conclusion, under the family assumptions d≥2, κ≥2. It is not a claim about all arbitrary matrices or all arbitrary fixed spectra.')
node('angles-open', 'unnamed-proof-step', ['A3.SS4.p1.1'], 'For each source coordinate i, 0<θ_i<π.')
node('cosine-open', 'unnamed-proof-step', ['A3.SS4.p1.1'], 'From 0<θ_i<π, −1<cos θ_i<1.')
node('eigenvalues-open', 'unnamed-proof-step', ['A3.SS4.p1.1'], 'From the affine cosine formula with κ≥2, 1<λ_i<κ.')
node('conjugated-bounds', 'unnamed-proof-step', ['A3.SS4.p1.1'], 'Since A=OΛOᵀ and O is orthogonal, the strict scalar bounds imply the non-strict Loewner bounds I_d ≼ A ≼ κ I_d.', notes='Symmetry of A and the quadratic-form/norm-preservation calculation are internal derivations; neither is an added public premise.')
node('class-membership', 'implicit-consumer-bridge', ['S2.Ex1', 'S4.SS3.p2.1'], 'The defined rotated matrix is symmetric and satisfies the two bounds, hence belongs to A_(d,κ).', notes='The lemma writes the bounds; the precision-class definition also requires symmetry. The source consumer calls the whole hard family admissible.')
node('quadratic-calculus', 'unnamed-proof-step', ['A3.SS4.p2.1'], 'V_A(x)=xᵀAx/2 is C∞ and has Hessian ∇²V_A(x)=A.', notes='V_A is a notational rename of f_A, not a second potential formula.')
node('strong-convex-smooth', 'unnamed-proof-step', ['A3.SS4.p2.1'], 'The potential is 1-strongly convex and κ-smooth.')
node('origin-minimizer', 'unnamed-proof-step', ['A3.SS4.p2.1'], 'V_A(0)=0 and V_A(x)≥||x||²/2>0 for x≠0; the origin is the unique minimizer.')
node('gaussian-target', 'source-claim', ['A3.SS4.p3.1'], 'The associated target is N(0,A^(−1)).')
node('normalizer-integral', 'unnamed-proof-step', ['A3.SS4.p3.1', 'A3.Ex160'], 'Gaussian integration gives Z_A=(2π)^(d/2)(det A)^(−1/2).')
node('determinant-invariance', 'unnamed-proof-step', ['A3.Ex160'], 'det(OΛOᵀ)=det Λ, hence Z_A=(2π)^(d/2)(det Λ)^(−1/2).')
node('known-normalizer', 'unnamed-proof-step', ['A3.SS4.p3.2'], 'Because Λ is fixed, Z_A is independent of O and is known whenever the spectrum is public.')
node('consumer-theorem-context', 'source-statement-context', ['S4.Thmtheorem1.p1.1', 'S4.Ex9', 'S4.p2.1'], 'Theorem 4.1: for fixed δ∈(0,1), d≥d0(δ), 2≤κ≤d^(1−δ), 0<ε≤1/10, Q_G≥(δ/256)√κ log d; the family can have a public spectrum.', role='consumer-context', notes='The lower-bound proof is not claimed from admissibility alone. Its distinct Krylov/moment/test arguments are excluded from this bounded target closure.')
node('consumer-admissibility-use', 'consumer-use-site', ['S4.SS3.p2.1'], 'A sampler accurate for every admissible A is accurate on every matrix in this hard family, by Lemma 4.6 and symmetry/class membership.', role='consumer-context', notes='This is the exact consumer use site. The consumer’s δ, q, ε, and κ upper bound do not flow backwards into the admissibility lemma.')
node('slc-context', 'source-statement-context', ['S1.Thmtheorem3.p1.1'], 'The lower bounds also apply to exact first-order sampling from exp(−V) under Hessian bounds I_d ≼ ∇²V ≼ κ I_d, even with the minimizer known.', role='consumer-context', notes='Only the first assertion explains why Appendix C.4 records the potential and minimizer. Other comparison claims in this paragraph are excluded from the target closure.')

gaps = [
 ('gap-grid-arithmetic', ['S4.E11','A3.SS4.p1.1'], 'The arithmetic derivation of 0<((i−1/2)π)/d<π for integer 1≤i≤d is not expanded.', 'An internal index/cast/positive-denominator derivation is required; do not assume angle bounds.'),
 ('gap-cosine-background', ['A3.SS4.p1.1'], 'The standard strict cosine bound on the open interval (0,π) is invoked without a cited proof.', 'Provide the elementary real-analysis fact internally; do not assume cosine/eigenvalue bounds.'),
 ('gap-affine-envelope', ['S4.E11','A3.SS4.p1.1'], 'The positive-slope affine calculation yielding 1<λ_i<κ is not expanded.', 'Use κ≥2 and the literal formula; the scalar envelope is a conclusion, not a source binder.'),
 ('gap-orthogonal-congruence', ['S2.p2.1','A3.SS4.p1.1'], 'The source compresses diagonal symmetry, conjugate symmetry, diagonal quadratic-form estimates and norm preservation into “this gives” the Loewner bounds.', 'Discharge these matrix bridges internally; square orthogonality is sufficient and no independent PSD/Loewner/symmetry assumption is licensed.'),
 ('gap-quadratic-calculus', ['A3.SS4.p2.1'], 'C∞ regularity and the Hessian identity for the symmetric quadratic are asserted without derivative calculations.', 'This is an unproved internal calculus bridge in this source-only evidence, not an extra smoothness or Hessian premise.'),
 ('gap-hessian-adapters', ['A3.SS4.p2.1'], 'The Hessian criterion for global strong convexity and smoothness and the minimizer deduction are not expanded.', 'These belong only to the appended potential branch; they are not prerequisites for the literal Lemma 4.6 conclusion.'),
 ('gap-gaussian-normalization', ['A3.SS4.p3.1','A3.Ex160'], 'Gaussian integration, positive-definite invertibility and the usual Lebesgue normalizer convention are not developed here. Z_A is used without an explicit standalone integral definition in the selected paper text.', 'Keep the target-law/normalizer convention visible and prove normalization internally if claimed. No finite-integral, determinant, or Gaussian-normalizer assumption may be added.'),
 ('gap-determinant', ['A3.Ex160'], 'The determinant invariance under orthogonal conjugation is used without an expanded determinant calculation.', 'Derive det A=det Λ internally. This branch is not required by the numbered Loewner conclusion.'),
]
for key, anchors, claim, boundary in gaps:
    node(key, 'SOURCE_GAP', anchors, claim, role='unproved-internal-bridge', notes=boundary)

E = []
def edge(key, parents, child, use_site, purpose, kind='proof-ingredient', conditional=None):
    E.append({'id':'edge:fs-admiss:'+key, 'parents':['sg:fs-admiss:'+p for p in parents], 'child':'sg:fs-admiss:'+child,
              'logic':'AND', 'kind':kind, 'consumer_use_site':use_site, 'purpose':purpose,
              'conditional_premise_discharge':conditional or 'No additional conditional premise asserted.'})

edge('grid-angle', ['hard-parameters','cosine-grid','gap-grid-arithmetic'], 'angles-open', 'A3.SS4.p1.1', 'Derive the open angle interval from the actual grid.', conditional='Each i is one of 1,…,d; d≥2 gives a positive denominator and π>0 is standard background.')
edge('angle-cos', ['angles-open','gap-cosine-background'], 'cosine-open', 'A3.SS4.p1.1', 'Use the strict cosine range on (0,π).', conditional='The open-angle antecedent is supplied by angles-open.')
edge('cos-eigenvalue', ['hard-parameters','cosine-grid','cosine-open','gap-affine-envelope'], 'eigenvalues-open', 'A3.SS4.p1.1', 'Evaluate the positive-slope affine map of cosine.', conditional='κ≥2 implies κ−1>0; no envelope binder.')
edge('eigenvalue-conjugation', ['orthogonal','rotated-precision','eigenvalues-open','gap-orthogonal-congruence'], 'conjugated-bounds', 'A3.SS4.p1.1', 'Transport the diagonal envelope through orthogonal conjugation.', conditional='O∈O(d) is the explicit source input; A and Λ are the literal definitions, with symmetry derived.')
edge('bounds-lemma', ['conjugated-bounds'], 'lemma-4.6', 'A3.SS4.p1.1', 'Conclude exactly the numbered non-strict Loewner assertion.')
edge('class-adapter', ['precision-class','conjugated-bounds','gap-orthogonal-congruence'], 'class-membership', 'S4.SS3.p2.1', 'Supply both symmetry and the bounds in the class definition.')
edge('quadratic-regularity', ['target-potential','rotated-precision','gap-orthogonal-congruence','gap-quadratic-calculus'], 'quadratic-calculus', 'A3.SS4.p2.1', 'Differentiate the literal symmetric quadratic.')
edge('convex-smooth', ['conjugated-bounds','quadratic-calculus','gap-hessian-adapters'], 'strong-convex-smooth', 'A3.SS4.p2.1', 'Apply the Hessian lower/upper criteria.')
edge('minimizer', ['target-potential','conjugated-bounds','gap-hessian-adapters'], 'origin-minimizer', 'A3.SS4.p2.1', 'Use the lower quadratic bound and positive norm away from zero.')
edge('target', ['target-potential','class-membership','gap-gaussian-normalization'], 'gaussian-target', 'A3.SS4.p3.1', 'Ensure the associated Gaussian covariance/integration is meaningful.')
edge('normalizer', ['gaussian-target','conjugated-bounds','gap-gaussian-normalization'], 'normalizer-integral', 'A3.Ex160', 'Use positive-definite Gaussian integration.')
edge('determinant', ['rotated-precision','orthogonal','gap-determinant'], 'determinant-invariance', 'A3.Ex160', 'Preserve determinant under the orthogonal conjugation.')
edge('normalizer-independent', ['normalizer-integral','determinant-invariance','cosine-grid'], 'known-normalizer', 'A3.SS4.p3.2', 'Remove O from the normalizing constant expression.')
edge('public-normalizer', ['known-normalizer'], 'public-spectrum', 'S4.SS1.p2.1', 'Explain the claim that the normalizer is known whenever the spectrum is public.', kind='explanatory-context')
edge('admissibility-consumer', ['lemma-4.6','class-membership','uniform-accuracy'], 'consumer-admissibility-use', 'S4.SS3.p2.1', 'Restrict the uniform input guarantee to the actual hard family.', kind='consumer-application', conditional='The target consumer fixes a large enough d and κ≥2. Its remaining lower-bound proof is a separate branch, not an input to this lemma.')
edge('slc-explanation', ['strong-convex-smooth','origin-minimizer','oracle-equivalence'], 'slc-context', 'S1.Thmtheorem3.p1.1', 'Explain this family’s compatibility with the strongly log-concave/known-minimizer setting.', kind='explanatory-context', conditional='This explains compatibility only; it does not discharge the whole lower-bound result or the unrelated comparisons in Remark 1.3.')

write('source-graph.json', {'schema_version':1, 'role':'independent-source-only-extractor', 'source_sha256':EXPECTED,
    'target_anchors':['S4.E11','S4.Thmtheorem6'], 'phase':'phase1-frozen-before-candidate-exposure',
    'status':'source-only-extracted-pending-distinct-coverage-review',
    'nodes':N, 'edges':E,
    'route_semantics':{'lemma_route':'One source route: literal cosine grid → open scalar envelope → orthogonal congruence → Loewner bounds.',
      'appended_branches':'The potential and normalizer assertions in C.4 are downstream/parallel consequences, never additional parents of lemma-4.6.',
      'alternative_routes':[], 'no_false_AND':'No Krylov, moment, test-event, calculus or Gaussian-integration premise is used to infer the numbered Loewner conclusion.'},
    'truth_boundary':'A source-only graph is not Lean evidence, proof completion, accepted source fidelity or a self-approved coverage review. Every SOURCE_GAP remains unproved here.'})

write('source-contract.json', {
 'source_title':'On Complexity of Gaussian Sampling', 'authors':['Huanjian Zhou','Taiji Suzuki'],
 'source_version':'arXiv:2610.20492v1', 'source_path':str(SOURCE.relative_to(ROOT)), 'source_sha256':EXPECTED,
 'literal_anchor':'S4.Thmtheorem6',
 'literal_statement':'For every O∈O(d), the matrix A=OΛOᵀ satisfies I_d ≼ A ≼ κ I_d.',
 'seven_slots':{
  'objects':'A real finite-dimensional orthogonal matrix O; the source cosine grid θ_i and λ_i; diagonal Λ; rotated precision A.',
  'domains':'Integer d≥2; real κ≥2; source indices i=1,…,d; O∈O(d)⊂R^(d×d).',
  'quantifiers':'For each allowed d and κ, define the deterministic grid and Λ. For every orthogonal O, set A=OΛOᵀ and conclude the two bounds.',
  'assumptions':'d≥2 and κ≥2 are standing hard-family assumptions from S4.SS1.p1.1; orthogonality is the explicit lemma premise. The actual grid formulas define θ,λ,Λ,A.',
  'conclusion':'The two non-strict symmetric-matrix/Loewner inequalities I_d≼A≼κ I_d. Symmetry of A is internally obtained from the literal conjugated diagonal matrix.',
  'scopes_senses':'Deterministic pointwise in O. The Haar draw and seed independence define the randomized hard input but are not needed for this lemma. Euclidean geometry and real matrices follow S2.',
  'constant_dependencies':'No hidden constants. The source lower/upper numbers are exactly 1 and κ. Theorem 4.1’s δ,d0,q,ε and upper bound on κ are not lemma hypotheses.'},
 'source_binder_classification':[
  {'item':'d integer and source coordinate carrier','class':'TYPING','anchor':'S2.SS0.SSS0.Px1.p1.1 / S4.E11'},
  {'item':'d≥2','class':'STANDING','anchor':'S4.SS1.p1.1'},
  {'item':'κ real','class':'TYPING','anchor':'S2 / spectral parameter convention'},
  {'item':'κ≥2','class':'STANDING','anchor':'S4.SS1.p1.1'},
  {'item':'O∈O(d)','class':'SOURCE','anchor':'S4.Thmtheorem6.p1.1'}],
 'definitions':[
  {'object':'θ_i, λ_i, Λ','kind':'literal','anchor':'S4.E11'},
  {'object':'A=OΛOᵀ','kind':'literal','anchor':'S4.SS1.p1.2'},
  {'object':'O(d)','kind':'literal','anchor':'S2.p2.1'},
  {'object':'A_(d,κ) and Loewner notation','kind':'literal','anchor':'S2.Ex1 / S2.p1.1'},
  {'object':'f_A / V_A quadratic','kind':'literal','anchor':'S2.SS0.SSS0.Px1.p1.2 / A3.SS4.p2.1'},
  {'object':'π_A=N(0,A^(−1))','kind':'source-defined-associated-Gaussian','anchor':'S2.SS0.SSS0.Px1.p1.2 / A3.SS4.p3.1','boundary':'Invertibility and normalization are internally justified from positive definiteness if this appended branch is claimed.'}],
 'not_licensed_as_extra_binders':['a supplied eigenvalue envelope', 'angle/cosine bounds', 'positive definiteness or Loewner bounds', 'A∈A_(d,κ)', 'symmetry of the defined A', 'smoothness/Hessian properties of the quadratic', 'finite normalizer or determinant identity', 'Haar probability law', 'algorithmic query or accuracy conditions'],
 'appended_source_claims':['C∞ quadratic and Hessian A','1-strong convexity and κ-smoothness','unique minimizer 0','target N(0,A^(−1))','Gaussian normalizer and independence from O'],
 'independence':'No candidate Statement Seal, Lean module, target API, root preseal audit, old review result or authored publication has been opened in phase1.'})

# Explicit source-block coverage. Source paragraphs with multiple assertions are
# mapped to several nodes; no assertion outside the target closure is inferred.
mapping = {
 'S1.p2.1':['precision-class','target-potential','uniform-accuracy'],
 'S1.SS1.p3.1':['consumer-theorem-context'],
 'S1.Thmtheorem2.p1.1':['consumer-theorem-context'],
 'S1.SS1.p4.1':['public-spectrum','consumer-theorem-context'],
 'S1.Thmtheorem3.p1.1':['slc-context'],
 'S2.p1.1':['notation'], 'S2.p2.1':['orthogonal'],
 'S2.SS0.SSS0.Px1.p1.1':['precision-class'], 'S2.Ex1':['precision-class'],
 'S2.SS0.SSS0.Px1.p1.2':['target-potential'], 'S2.E1':['target-potential'],
 'S2.SS0.SSS0.Px1.p2.1':['oracle-equivalence'],
 'S2.SS0.SSS0.Px2.p1.1':['uniform-accuracy'],
 'S2.SS0.SSS0.Px4.p1.1':['uniform-accuracy'], 'S2.E2':['uniform-accuracy'],
 'S2.SS0.SSS0.Px4.p1.2':['uniform-accuracy'],
 'S4.Thmtheorem1.p1.1':['consumer-theorem-context'], 'S4.Ex9':['consumer-theorem-context'], 'S4.p2.1':['consumer-theorem-context'],
 'S4.SS1.p1.1':['hard-parameters'], 'S4.E11':['cosine-grid'],
 'S4.SS1.p1.2':['rotated-precision'], 'S4.SS1.p2.1':['public-spectrum'],
 'S4.SS2.p1.1':['lemma-4.6'], 'S4.SS2.SSS0.Px4.p1.1':['lemma-4.6'],
 'S4.Thmtheorem6.p1.1':['lemma-4.6'],
 'S4.SS3.p2.1':['consumer-admissibility-use'],
 'A3.SS4.p1.1':['angles-open','cosine-open','eigenvalues-open','conjugated-bounds','lemma-4.6'],
 'A3.SS4.p2.1':['quadratic-calculus','strong-convex-smooth','origin-minimizer'],
 'A3.SS4.p3.1':['gaussian-target','normalizer-integral'],
 'A3.Ex160':['normalizer-integral','determinant-invariance'],
 'A3.SS4.p3.2':['known-normalizer'],
}

def exclude_reason(source_id, kind, text):
    if kind.startswith('h'):
        return 'Structural heading only; mathematical content is inventoried in its statement/proof paragraph and display units.'
    if source_id.startswith('S1.'):
        return 'Introductory motivation, comparative bounds, or the separate hidden-determinant-sign result; not a prerequisite or exact use site for the cosine-grid admissibility statement.'
    if source_id.startswith('S2.'):
        return 'TV measure details are used by the downstream lower-bound test, not by the pointwise matrix admissibility proof. Uniform-accuracy context is retained separately.'
    if source_id.startswith('S4.SS4') or source_id in ['S4.Thmtheorem7.p1.1','S4.Ex28','S4.Ex29','S4.Ex30','S4.Thmtheorem8.p1.1']:
        return 'Limitations/Krylov-dimension/accuracy analysis is downstream of the fixed-family lower bound and supplies no premise for Lemma 4.6.'
    if source_id.startswith('S4.SS3') or source_id in ['S4.Ex18','S4.Ex19','S4.Ex20','S4.Ex21','S4.Ex22','S4.Ex23','S4.Ex24','S4.Ex25','S4.Ex26','S4.Ex27']:
        return 'Remaining Theorem 4.1 test-event/Krylov/moment/TV-contradiction branch. The exact admissibility application is S4.SS3.p2.1; these later steps do not feed back into it.'
    if source_id == 'S4.p1.1' or source_id == 'S4.Thmtheorem2.p1.1':
        return 'Prior-work comparison and explanation of the √κ lower-bound improvement; no dependency of the pointwise admissibility proof.'
    return 'Sibling Krylov or target-moment statement, definition, display, or proof overview. The raw source gives no edge from this material into the cosine-grid admissibility proof.'

coverage = []
for subtree in ['S1','S2','S4','A3.SS4']:
    blocks = json.loads((OUT / ('source-'+subtree+'.json')).read_text())
    for i, block in enumerate(blocks):
        source_id = block['id'] or subtree + '::' + block['kind'] + '::' + str(i)
        row = {'coverage_id':source_id, 'source_id':block['id'], 'subtree':subtree,
               'kind':block['kind'], 'text_sha256':digest(block['text'].encode()), 'text':block['text']}
        if source_id in mapping:
            row['disposition'] = 'NODE'
            row['nodes'] = ['sg:fs-admiss:'+x for x in mapping[source_id]]
            if source_id == 'S2.p2.1':
                row['excluded_subclaims'] = 'Haar component probabilities and μ_(n,b) notation concern another branch; only the definition of the real orthogonal group is used.'
            if source_id == 'S4.SS2.p1.1':
                row['excluded_subclaims'] = 'The overview of Lemmas 4.3–4.5 is sibling proof context, not a premise of Lemma 4.6.'
            if source_id == 'S1.Thmtheorem3.p1.1':
                row['excluded_subclaims'] = 'The κ=2 upper-bound comparison and general expected-gradient upper bound are unrelated comparisons, not admissibility inputs.'
        else:
            row['disposition'] = 'EXCLUDED'
            row['reason'] = exclude_reason(source_id, block['kind'], block['text'])
        coverage.append(row)

# Whole theorem wrappers are explicit coverage items too (their mathematical
# text is repeated in the atomic source units above).
for subtree in ['S1','S4']:
    for theorem in soup.find(id=subtree).select('.ltx_theorem'):
        source_id = theorem['id']
        inside = [r for r in coverage if r.get('source_id') and r['source_id'].startswith(source_id+'.') and r['disposition']=='NODE']
        nodes = sorted({x for r in inside for x in r['nodes']})
        row = {'coverage_id':source_id,'source_id':source_id,'kind':'theorem-wrapper','text_sha256':digest(normalized(theorem).encode())}
        if nodes:
            row.update({'disposition':'NODE','nodes':nodes,'reason':'Whole-source statement wrapper; proof status is not asserted.'})
        else:
            row.update({'disposition':'EXCLUDED','reason':'Separate sibling theorem/remark with no premise in the admissibility closure; its paragraphs/displays are separately inventoried.'})
        coverage.append(row)

citation_rows = []
bib_ids = set()
for subtree in ['S1','S2','S4','A3.SS4']:
    for i, cite in enumerate(soup.find(id=subtree).find_all('cite')):
        refs = sorted({a['href'][1:] for a in cite.find_all('a',href=True) if a['href'].startswith('#bib.')})
        bib_ids.update(refs)
        parent = next((p.get('id') for p in cite.parents if p.get('id')), subtree)
        citation_rows.append({'coverage_id':subtree+'::citation::'+str(i),'kind':'external-citation-occurrence','consumer_use_site':parent,'source_refs':refs,
          'text':normalized(cite),'disposition':'EXCLUDED',
          'reason':('Reference [22] is provenance for the construction/prior lower-bound and supplies the separate Krylov representation, not the elementary proof of Lemma 4.6. No external theorem text or API has been opened.' if 'bib.bib3' in refs else 'Introductory or comparison citation outside the bounded admissibility closure; not a mathematical input to its source proof.')})

supplemental_ids = ['A2.SS2.p2.1','A2.SS2.SSS1.p1.1','A2.SS2.SSS1.p2.2','A3.SS2.p3.1']
supplemental = []
for source_id in supplemental_ids:
    t = soup.find(id=source_id)
    assert t is not None
    supplemental.append({'coverage_id':source_id,'source_id':source_id,'kind':'keyword-search-exposure','text':normalized(t),'disposition':'EXCLUDED',
      'reason':'This raw-source paragraph was incidentally returned by the normalizer/Hessian keyword search. It belongs to the separate determinant-sign or Krylov proof branch and is not a premise for Lemma 4.6.'})
    (OUT / ('supplemental-'+source_id+'.html')).write_text(str(t))

# bib.bib22 was inspected before discovering bibliography element IDs differ
# from displayed reference numbers. Preserve that exposure honestly.
bib_ids.add('bib.bib22')
bibliography=[]
for source_id in sorted(bib_ids):
    t=soup.find(id=source_id)
    assert t is not None
    bibliography.append({'coverage_id':source_id,'source_id':source_id,'kind':'bibliography-entry','text':normalized(t),'disposition':'EXCLUDED',
      'reason':'Bibliographic identity only; the linked external document has not been accessed and no theorem from it is used in the elementary admissibility route.'})
    (OUT / ('bibliography-'+source_id+'.html')).write_text(str(t))

coverage.extend(citation_rows)
coverage.extend(supplemental)
coverage.extend(bibliography)
write('coverage.json', {'source_sha256':EXPECTED,'scope':'Full raw S1, S2, S4, and C.4 (A3.SS4), with explicit exclusions for sibling/background content; plus incidental raw-source keyword-search paragraphs and bibliography identities.',
  'status':'extracted-not-self-approved','units':coverage,
  'coverage_counts':{d:sum(x['disposition']==d for x in coverage) for d in ['NODE','EXCLUDED']},
  'caution':'Inventory exhaustiveness is for selected source regions only. No claim of paper coverage, Lean closure, source acceptance or theorem completion.'})

write('exposure-manifest.json', {
 'role':'source-only graph extractor; not a proof worker',
 'agent_task':'/root/fs_admiss_source_graph',
 'assignment_exposure':'Parent supplied the pinned full raw-source path/hash, source target IDs, output directories and procedural restrictions. No candidate signature/body/API or prior verdict was supplied.',
 'raw_source':{'path':str(SOURCE.relative_to(ROOT)),'bytes':len(raw),'sha256':EXPECTED,'full_copy':'source-original.html',
  'selected_reading':['Full normalized S1 introduction/results','Full normalized S2 preliminaries','Full normalized S4 statement/family/properties/proof/limitations','Full raw and normalized C.4 proof','Raw Eq.11 first paragraph and raw exact Theorem4.1 admissibility-use paragraph','Raw S4.Ex16, S4.Ex18, S4.Ex19 missed by the first equation-table extractor, then included in corrected inventory','Direct-source-link inventory for Eq.11 / Lemma4.6 / C.4','Incidental source paragraphs listed in coverage supplemental entries','Bibliography #bib.bib3 ([22]) and mistaken #bib.bib22 identity; other bibliography entries snapshotted for citation coverage only']},
 'instructions_read':instructions,
 'partial_instruction_search_exposure':[{'path':'docs/formalization-protocol.md','exposure':'Only matched semantic/encoder/denoiser/source-review lines returned by bounded rg; no theorem or implementation content.'}],
 'directory_name_only_exposure':'Bounded rg --files under docs and .agents listed protocol/skill/prompt names; an exact-ancestor AGENTS existence check found no extra AGENTS files. No candidate subtree was listed.',
 'generated_own_artifacts_exposure':'Own extraction helper and own phase1 raw/normalized source snapshots were read while constructing this packet.',
 'explicit_non_exposure':['Current candidate Statement Seal','Any current candidate Lean module or Test','Root preseal audit','Authored publication or declaration lesson','Previous reviewer result or old semantic evidence','Target API or proof search','SAU/discovery/capsule/Registry/ledger state','Website/site/browser/remote interfaces','.atlas-upstream or derivatives','Any model trial/evaluation'],
 'mutation_boundary':'Only the assigned phase1 subtree and .astis/huanjian-fixed-spectrum-admissibility-20261107/source-graph helpers were written. No shared/canonical audit, ledger, Registry, Lean, test, site or remote state was changed.',
 'interpretation':'This manifest reports actual exposure. Source-author assertions and procedural instructions are not proof certificates.',
 'phase2_boundary':'Candidate comparison is prohibited until the phase1 freeze hashes are sent to root and root provides the exact candidate and necessary meanings.'})

raw_inputs=json.loads((OUT/'raw-inputs.json').read_text())
raw_inputs.update({'full_original_copy':'source-original.html','full_original_copy_sha256':EXPECTED,
 'instruction_inputs':instructions,
 'supplemental_source_ids':supplemental_ids,
 'bibliography_source_ids':sorted(bib_ids)})
write('raw-inputs.json',raw_inputs)

