import Tests.GaussianComplexityRadialExponential
import Lean

open MeasureTheory ProbabilityTheory
open scoped ENNReal
set_option autoImplicit false

def LiteralSealedProducer : Prop := ∀ {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℝ E]
    [FiniteDimensional ℝ E] [MeasurableSpace E] [BorelSpace E],
  Integrable (fun x : E => Real.exp (‖x‖ ^ 2 / 3)) (stdGaussian E) ∧
    (∫ x : E, Real.exp (‖x‖ ^ 2 / 3) ∂stdGaussian E) =
      (3 : ℝ) ^ ((Module.finrank ℝ E : ℝ) / 2)

def LiteralSealedConsumer : Prop := ∀ {d q : ℕ} (hq : 2 * q + 1 < d),
  let E := EuclideanSpace ℝ (Fin (q + 1))
  let μ : Measure E := stdGaussian E
  let L : ℝ := 2 * ((q + 1 : ℕ) : ℝ) + 3 * Real.log (1000 * (d : ℝ))
  μ {x : E | L < ‖x‖ ^ 2} ≤ ENNReal.ofReal ((1000 * (d : ℝ))⁻¹)


open Lean Elab Command

def producerName : Name :=
  `AutoSamplingTheory.TechnicalLemmas.Probability.StdGaussianRadialExponential.integrable_exp_norm_sq_div_three_and_integral_stdGaussian

def consumerUserName : Name :=
  `AutoSamplingTheory.Tests.GaussianComplexityRadialExponential.actual_source_row_truncation_tail

def consumerName : Name :=
  (Name.num `_private.Tests.GaussianComplexityRadialExponential 0) ++ consumerUserName

def densityName : Name :=
  `AutoSamplingTheory.TechnicalLemmas.Measure.IsotropicGaussianDensity.map_sqrt_smul_stdGaussian_eq_withDensity

def astisName (name : Name) : Bool :=
  (`AutoSamplingTheory).isPrefixOf ((privateToUserName? name).getD name)

def publicAstisName (name : Name) : Bool :=
  astisName name && (privateToUserName? name).isNone

structure Dependencies where
  visited : NameHashSet := {}
  astis : NameHashSet := {}
  first : NameHashSet := {}
  missing : NameHashSet := {}

partial def walkDependencies (env : Environment) (stopAtPublic : Bool)
    (pending : List Name) (result : Dependencies := {}) : Dependencies :=
  match pending with
  | [] => result
  | name :: rest =>
    if result.visited.contains name then
      walkDependencies env stopAtPublic rest result
    else
      let result := {result with visited := result.visited.insert name}
      let result := if astisName name then {result with astis := result.astis.insert name} else result
      match env.find? name with
      | none => walkDependencies env stopAtPublic rest {result with missing := result.missing.insert name}
      | some decl =>
        if stopAtPublic && publicAstisName name then
          walkDependencies env stopAtPublic rest {result with first := result.first.insert name}
        else
          let children := decl.getUsedConstantsAsSet.toList
          walkDependencies env stopAtPublic (children ++ rest) result

def ordered (names : NameHashSet) : Array Name :=
  names.toArray.qsort Name.quickLt

def isClosed (value : Expr) : Bool :=
  !value.hasFVar && !value.hasMVar && !value.hasLooseBVars

def checkedDefEq (env : Environment) (left right : Expr) : CommandElabM Bool :=
  match Kernel.isDefEq env {} left right with
  | .ok equal => pure equal
  | .error ex => throwError (ex.toMessageData {})

def inspect (name literal parent : Name) (expectedUniverses : Nat) : CommandElabM Unit := do
  let env ← getEnv
  let some (.thmInfo actual) := env.find? name
    | throwError m!"Expected compiled theorem value: {name}"
  let some (.defnInfo sealed) := env.find? literal
    | throwError m!"Expected literal proposition definition: {literal}"
  unless actual.levelParams.length == expectedUniverses && sealed.levelParams.length == expectedUniverses do
    throwError m!"Wrong universe count: {actual.levelParams} vs {sealed.levelParams}"
  unless isClosed actual.value && isClosed actual.type && isClosed sealed.value do
    throwError m!"Loose term variable or metavariable: {name}"
  let universes := if expectedUniverses == 0 then [] else [Level.param `radialAuditUniverse]
  let normalizedActual := actual.type.instantiateLevelParams actual.levelParams universes
  let normalizedSeal := sealed.value.instantiateLevelParams sealed.levelParams universes
  let kernelDefEq ← checkedDefEq env normalizedActual normalizedSeal
  unless kernelDefEq do throwError m!"Kernel rejected literal interface equality: {name}"
  let axiomNames ← collectAxioms name
  let axioms := axiomNames.qsort Name.quickLt
  unless axioms.all (fun ax => #[`propext, `Classical.choice, `Quot.sound].contains ax) do
    throwError m!"Nonstandard axioms: {axioms}"
  let direct := actual.value.getUsedConstants
  let directAstis := (direct.filter astisName).qsort Name.quickLt
  unless direct.contains parent do throwError m!"No actual value reference to {parent}"
  let reachable := walkDependencies env false (direct ++ actual.type.getUsedConstants).toList
  let first := walkDependencies env true (direct ++ actual.type.getUsedConstants).toList
  unless ordered first.first == #[parent] do throwError m!"Unexpected public ASTIS parents: {ordered first.first}"
  unless reachable.missing.isEmpty do throwError m!"Unresolved declarations: {ordered reachable.missing}"
  logInfo m!"theorem={name}\nproof_value=present\nclosed_type_value_and_seal=true\nactual_universe_params={actual.levelParams}\nsealed_universe_params={sealed.levelParams}\ncomparison_universes={universes}\nkernel_def_eq={kernelDefEq}\nraw_ExprStructEq={ExprStructEq.mk actual.type == ExprStructEq.mk sealed.value}\ncommon_universe_ExprStructEq={ExprStructEq.mk normalizedActual == ExprStructEq.mk normalizedSeal}\naxioms={axioms}\ndirect_value_constant_count={direct.size}\ndirect_value_ASTIS={directAstis}\nfirst_public_ASTIS={ordered first.first}\nreachable_constant_count={reachable.visited.size}\nreachable_ASTIS={ordered reachable.astis}\nmissing={ordered reachable.missing}"

run_cmd do
  let env ← getEnv
  unless (env.find? consumerUserName).isNone && privateToUserName? consumerName == some consumerUserName do
    throwError "Private consumer name or visibility changed"
  inspect producerName `LiteralSealedProducer densityName 1
  inspect consumerName `LiteralSealedConsumer producerName 0
