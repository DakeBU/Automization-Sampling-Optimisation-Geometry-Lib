from verify import *
m=json.loads((D/'candidate'/E/'source-to-lean-map-v1.json').read_text()); names=[r['canonical_existing_declaration'] for r in m['rows'] if r.get('canonical_existing_declaration')]
assert len(names)==len(set(names))
code='''import Tests.GaussianComplexityZeroQuerySeparation
import Lean
open Lean
set_option maxRecDepth 8192
set_option maxHeartbeats 0
run_cmd do
  let env := (← getEnv).setExporting false
  setEnv env
  let roots := env.constants.toList.filter fun (n, _) =>
    n == `AutoSamplingTheory.ExampleCases.GaussianComplexity.ZeroQuerySeparation.actual_zero_query_gaussian_event_gap ||
    n.toString.endsWith ".no_common_zero_query_output"
  let requested : List Name := ['''+', '.join('`'+n for n in names)+''']
  for name in requested do
    unless (env.find? name).isSome do throwError "Mapped canonical declaration absent: {name}"
  let mut globalReach : NameSet := {}
  for (root,_) in roots do
    let mut todo := [root]
    let mut seen : NameSet := {}
    while !todo.isEmpty do
      let n := todo.head!
      todo := todo.tail!
      unless seen.contains n do
        seen := seen.insert n
        let some ci := env.find? n | throwError "Dependency missing {n}"
        todo := ci.type.getUsedConstants.toList ++ todo
        if let some v := ci.value? true then todo := v.getUsedConstants.toList ++ todo
    logInfo m!"FULL_RECURSIVE_CONSTANT_CLOSURE_SIZE {root}: {seen.size}"
    for name in requested do
      logInfo m!"MAPPED_CANONICAL_REACHABILITY {root} => {name}: {seen.contains name}"
    globalReach := seen.toList.foldl (fun a n => a.insert n) globalReach
  for name in requested do
    unless globalReach.contains name do throwError "Mapped canonical name is not actually used: {name}"
  logInfo m!"ALL_MAPPED_CANONICAL_NAMES_EXIST_AND_ARE_REACHABLE={requested.length}"
'''
write('fresh-strict/source/CanonicalDependencyReachability.lean',code)
cfg=json.loads((D/'environment.json').read_text()); env=os.environ.copy(); env['LEAN_PATH']=json.loads((D/'fresh-strict/import-path.json').read_text())['LEAN_PATH']
r=run('canonical-dependency-reachability',[cfg['lean_binary'],'-o',str(D/'fresh-strict/lib/CanonicalDependencyReachability.olean'),'CanonicalDependencyReachability.lean'],cwd=D/'fresh-strict/source',env=env); sys.exit(r.returncode)
