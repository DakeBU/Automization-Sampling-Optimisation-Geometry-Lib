# R17 independent SOURCE-only topology review

**Verdict: admit the exact statement seal and the source topology only as the
original graph/bridge plus the explicitly accepted v2 repair overlay.** There
are no remaining blocking source, binder, definition, scope, coverage or route
findings in that bounded stack. This is a pre-proof admission, not a theorem,
Lean-build, source-gap-discharge or publication verdict.

## Exact review stack

All values below were independently rehashed:

| Artifact | SHA-256 |
| --- | --- |
| Exact statement seal | `1b52776e9793f302109cb649dd0c82c666193086aa7546006e36651ee389e638` |
| Exact binder/definition audit | `ab17ddb4d2b402194af7b4668054d580956a80a103da938a25978d94e03e7744` |
| Original `matrix_domain_sg_48bc/source-graph.v1.json` | `884f7970347129bf75f3a15feb6bcbcb4c0c427a2cdefbf3a5cc90abef75cf09` |
| Original `matrix_domain_sg_48bc/author-derived-bridges.v1.json` | `3a66bd5bef0858fe57a01e15231851808f0c54da196cba918e012db7283dd9c1` |
| Original review capsule | `773e6701c7bd475a8da066f4a361524856314bb50b0dc1cb82db4c3d661f5627` |
| Original manifest | `b27220319b8c65898896d6aacd306e2e0242b0fa7d66dc772fa8cc7b703ffbce` |
| Accepted `W17/source-topology-repair.proposed-v2.json` | `9ed5bb1da14afee5ba43c074456293fb706e7d6d60dec132c97fc43de34362c4` |

Here W17 is `.astis/huanjian-gc-matrix-mgf-domain-20261115/`.
The accepted overlay has exactly two parent-list appends and no mathematical
statement or literal-definition changes. The originals remain unmodified.
The v1 proposal was read and found correct for its single repair, but v2 is the
sole overlay used for final admission; do not apply both as cumulative edits.

## Independence and integrity

I first read the repository instructions, rehashed and read the raw Tropp PDF
and Gaussian HTML, and froze `raw-first-checklist.v1.md` at SHA-256
`231688bf13f19918a7972c4767c88df17df384b77afb896e4b5b84aa03095077`.
The freeze predates graph exposure. The raw source digests match the seal:
Tropp `f4c3cff8661011395e793972a1f8d9a199fae4ca0fd098535d7a42166cf8fc86`;
Gaussian `6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915`.
Tropp PDF pages 8–11 received complete visual inspection in addition to the
raw text read; the relevant Gaussian HTML math and consumer ids were read
directly.

The parent's first graph digest was `5435c2ad…`; the on-disk final graph already
hashed `884f7970…`. I reported the mismatch before reading graph content.
The parent then explicitly designated final `884f7970…` and manifest
`b2722031…`. Only that designated final graph was read. No draft graph content,
implementation Lean, old graph/verdict, extractor script or private rationale
was read. No target proof search ran.

## Independent findings and accepted repairs

1. **TC-F1: omitted order-integration parent.** `R-T-UNIFORM` says it integrates
   the PSD lower-envelope inequality, but its original `all_of` omits
   `TR-EXPECT-ORDER`. Raw Tropp §2.7/(2.13) supplies precisely this ingredient.
   Appending that existing source node is correct. This preserves the optional
   direct route as an OR alternative to `R-T-P`.
2. **TC-F2: omitted literal Y parent.** `GC-RADIAL-MEAN` includes the actual
   `EY_i=(a/d)(I_r⊗t_i t_iᵀ)` clause at `A3.SS2.p12.4`. Its `GC-E3` edge
   originally lists setup and cutoff only. That clause also consumes the
   literal `Y_i` definition at Ex107. Appending existing `GC-Y` is correct.

I checked both old parent lists byte-for-byte against their original records.
The v2 overlay appends exactly the two named existing nodes. Neither operation
adds a premise, source claim, proof result, route, definition, constant or
public binder. The unoverlaid originals retain these two findings and are not
silently treated as repaired.

## Coverage and backward closure

An independent raw-HTML tag/id audit found all 93 C.2 records: 50 paragraphs,
37 display tables, one subsection heading and five run-in headings. Their
inventory ids match exactly, with no missing or duplicate id. The complete
bounded inventory has 118 dispositions: 55 NODE and 63 EXCLUDED. I read their
mathematical content and exclusion reasons, rather than treating this count
as a coverage proof. The 32 source/gap nodes, 18 original source edges and ten
separate author-bridge nodes cover the selected domain slice.

The retained source route covers the literal setup, cosine-vector norm,
truncation and radial mean, the distinction between `0≤a≤1` and quantitative
bias, actual individual means, centered and cosine-weighted radii, and the
Ex121/p15.2 consumer boundary. Frame and tail/bias nodes have their own scoped
routes; they do not become unnecessary inputs to the domain envelope.
The exclusions for untruncated Gram/range results, fourth-moment variance,
Bernstein optimization, probability budgets, asymptotic constants and final
Krylov transfer are sound for this target.

Tropp's regularity convention, spectral matrix exponential/PD fact, logarithm
PD domain, non-strict expectation order, MGF definition and explicit possible
nonexistence caveat are represented. Formal moment series do not discharge
exponential integrability. Neither scalar MGF multiplication nor Lieb,
master-tail, matrix-log or Bernstein theorems become proof inputs here.

Backward checks reach each sealed conjunct: bounded measurable Y establishes
its actual mean; symmetric Z and all four signed weighted sums have the
deterministic radius `d R*`; the continuous matrix exponential has an all-real
finite envelope and is pointwise PD; P (or the separate optional uniform
route) yields PD of the true matrix mean; finite-dimensional trace commutation,
nonempty dimension and the scalar envelope supply the final three trace
claims. In implementing this route, the pointwise Y-bound clause of Ex111
must establish Y integrability before invoking its actual mean clause; no
mean-integrability premise is supplied externally.

## Binder, definition, direction and constant checks

The embedded P and T strings are exactly the sealed strings and their statement
digests match. P remains the author-stated generic Level B AE-PD probability
integral problem, not a theorem printed by Tropp. Its integrability and AE-PD
inputs are legitimate P data and must be produced internally in T. Empty
finite indices are allowed in P; positive trace in T uses `q+1≥1`.

T keeps only `2q+1<d` as its mathematical premise, with all real s, both Bool
choices and q=0. I found no EXCESS binder or literal-definition drift. The full
product Gaussian law, actual unconditional means, own-row inclusive cutoff,
zero branch, midpoint grid, zeroth feature 1, Gaussian-first Kronecker order,
dimension r² and source d⁻¹ scaling are unchanged. No conditioning or
replacement law is introduced.

The exact radius uses separate bounds `2rL/d` and `2r/d`, hence
`R*=2r(L+1)/d`. The sum radius is `d R*`. The trace bound is the unnormalized
`r² exp(|s| d R*)`, not a variance bound. All signs, s=0 and negative s are
covered without symmetry-in-law assumptions. No sufficiently-large constant,
τ restriction, event, covariance witness or tail premise enters T.

Consumer sites and edge directions are sound after the two repairs. The
Bernstein call is explicitly a downstream, insufficient boundary edge.
`R-T-P OR R-T-UNIFORM` remains an OR: the graph does not require both PD
arguments. The strict-integral route does not infer PD from positive trace or
from PSD plus positive trace, and does not assume a uniform spectral lower
bound for generic P.

## Unchanged truth boundary

The four visible SOURCE_GAP nodes remain unproved source omissions:
`GAP-FINITE-MATRIX-INTEGRATION`, `GAP-STRICT-MEAN-PD`,
`GAP-FOUR-MGF-ENVELOPE`, and `GAP-TRACE-COMMUTE`. Their separate author-derived
records are mathematical obligations and candidate routes, not printed-source
attribution or Lean discharge. Probability normalization, Gaussian row law,
measurability, norm/symmetry facts, strict scalar-integral positivity and trace
linearity are named obligations, not hidden public premises.

This review permits advancing the **exact sealed interface** to proof search
under the accepted explicit overlay stack. It proves no Lean declaration and
claims no matrix-log theorem, Lieb/master-tail/Bernstein or C.6 result, lower
bound, oracle/precision/cost adapter, intake/PL/V transition, shared metadata,
publication, purification or Goal completion. All reviewer writes are confined
to the assigned `matrix_domain_tc_79ad/` directory.
