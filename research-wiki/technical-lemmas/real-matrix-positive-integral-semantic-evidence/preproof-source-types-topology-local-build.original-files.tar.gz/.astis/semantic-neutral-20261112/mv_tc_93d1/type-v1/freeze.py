from pathlib import Path
import datetime
import hashlib
import json

ROOT = Path('/Users/zhouhuanjian/ASTIS-GC')
OWN = ROOT/'.astis/semantic-neutral-20261112/mv_tc_93d1'
DEST = OWN/'type-v1'
PACKET = ROOT/'.astis/huanjian-gc-source-matrix-variance-20261112/selective-type-definition-packet.json'

def sha(b):
    return hashlib.sha256(b).hexdigest()

def digest(path):
    b = path.read_bytes()
    return {'path':str(path.relative_to(ROOT)), 'bytes':len(b), 'sha256':sha(b)}

def write(name,obj):
    (DEST/name).write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n')

assert digest(PACKET)['sha256'] == 'b9b93126880486157e88e9a59abcd2b89d81b4cf34d46fa9dc51f88d2b6e0170'
p = json.loads(PACKET.read_text())
assert p['statement_seal_sha256'] == '5f905cafe6035238cebdedd4f841e87b703e741b4c8aa204471d89e4c07e8a14'
assert p['minimal_definition_context_sha256'] == 'c8f86ad1db7cf3798073ff5bde1d859cd2f95dcd54dbe7f759fa4b2022c5383a'
assert p['producer']['signature_sha256'] == 'd5ac54443c79ea7b35b09ddcd6b5e3c40bef081bbe4f196cae5ab3ead35aa2ea'
assert p['actual_private_consumer']['signature_sha256'] == '95e81a02e5302de9a42e3b60038ffad6195315ac2eca99a4e6abb39978609f7e'
for key in ['producer','actual_private_consumer']:
    assert sha(p[key]['signature'].encode()) == p[key]['signature_sha256']
c = p['minimal_definition_context']
assert sha(c['literal_current_prints_and_instances'].encode()) == c['literal_current_prints_sha256']
assert len(c['literal_definition_excerpts']) == 8
assert all(sha(a['literal_source'].encode()) == a['literal_source_sha256'] for a in c['literal_definition_excerpts'])
sourcepath = ROOT/p['source']['raw']
raw = sourcepath.read_bytes()
assert sha(raw) == p['source']['raw_sha256'] == '6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
assert len(p['source']['anchors']) == 8
for a in p['source']['anchors']:
    assert sha(raw[a['raw_utf8_start']:a['raw_utf8_end']]) == a['span_sha256']
    assert raw.decode()[a['char_start']:a['char_end']].encode() == raw[a['raw_utf8_start']:a['raw_utf8_end']]
assert digest(OWN/'raw-freeze.json')['sha256'] == 'c0bf670eba58674aac8b29d8fd313428955e76f13c20680ae47c84f1f4b536db'
preserved = []
for line in (OWN/'SHA256SUMS').read_text().splitlines():
    expected,name = line.split('  ',1)
    assert digest(OWN/name)['sha256'] == expected
    preserved.append(digest(OWN/name))
rawinput = json.loads((OWN/'input-manifest.json').read_text())
older_counts = {}
for label,records in rawinput['prior_R7_R8_preserved_by_checksum_manifests'].items():
    for record in records:
        assert digest(ROOT/record['path'])['sha256'] == record['sha256']
    older_counts[label] = len(records)
write('input-manifest.json',{
    'packet':digest(PACKET),'assignment':digest(DEST/'assignment.txt'),
    'statement_seal_sha256_as_named':p['statement_seal_sha256'],
    'definition_context_sha256_as_named':p['minimal_definition_context_sha256'],
    'producer_signature_sha256_recomputed':p['producer']['signature_sha256'],
    'consumer_signature_sha256_recomputed':p['actual_private_consumer']['signature_sha256'],
    'literal_print_sha256_recomputed':c['literal_current_prints_sha256'],
    'all_eight_standard_excerpt_hashes_match':True,
    'all_eight_raw_source_span_hashes_and_char_byte_maps_match':True,
    'prior_raw_records_preserved':preserved,
    'older_R7_R8_preservation_counts':older_counts,
    'no_SG_graph_opinion_implementation_or_other_review_input':True,
})
names = ['assignment.txt','audit.md','exposure.json','freeze.py','input-manifest.json']
freeze = {
    'version':1,'kind':'independent-fixed-type-binder-definition-source-scope-audit',
    'actor':'/root/row_indep_topology_24a6','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'finding':'NO_TYPE_BINDER_DEFINITION_OR_SOURCE_SCOPE_ISSUE_FOUND',
    'genuine_type_or_source_blockers':[],
    'packet':digest(PACKET),
    'statement_seal_sha256':p['statement_seal_sha256'],
    'definition_context_sha256':p['minimal_definition_context_sha256'],
    'producer_signature_sha256':p['producer']['signature_sha256'],
    'consumer_signature_sha256':p['actual_private_consumer']['signature_sha256'],
    'explicit_semantic_checks':{
        'ordinary_matrix_product_not_entrywise':True,
        'PosSemidef_includes_Hermitian_and_finite_quadratic_positivity':True,
        'actual_L2Operator_Euclidean_operator_norm':True,
        'same_original_mu_for_Y_mean_Z_and_both_second_moment_sums':True,
        'both_actual_centered_variance_norm_bounds_not_squared_sum_expectations':True,
        'q0_included_and_no_EXCESS_public_binders_found':True,
    },
    'local_records':[digest(DEST/name) for name in names],
    'prior_raw_freeze':digest(OWN/'raw-freeze.json'),
    'raw_and_R7_R8_originals_preserved':True,
    'unproved_internal_boundaries':[
        'Actual first-moment integrability and mean validity, including totalized mean integral and centering algebra.',
        'Actual physical-row law, Gaussian fourth-moment integrability/coefficient and same-mu transport.',
        'Literal rank-one/tensor matrix square formula, PSD truncation removal and source unweighted frame bound/identity.',
        'Hermitian/PSD facts for actual matrices and expected centered squares; deterministic cosine-square comparison.',
        'PSD/order/integral/finite-sum compatibility and the Euclidean operator-norm bridge.',
        'Exact actual producer-to-consumer calls and API applications after a genuine proof exists.',
    ],
    'new_SG_graph_or_opinion_seen':False,
    'new_target_implementation_or_proof_seen':False,
    'target_proof_API_search_or_Lean_attempts':0,
    'topology_applicability_compiled_edge_verification_normal_intake_or_permission_grant':False,
    'next_boundary':'Wait for the separately authorized post-seal SG source graph, then perform a distinct topology/applicability-coverage challenge without implementation.',
}
write('freeze.json',freeze)
records = [digest(DEST/name) for name in names]+[digest(DEST/'freeze.json')]
(DEST/'SHA256SUMS').write_text(''.join(f"{a['sha256']}  {Path(a['path']).name}\n" for a in records))
print(json.dumps({'freeze':digest(DEST/'freeze.json'),'audit':digest(DEST/'audit.md'),
                  'exposure':digest(DEST/'exposure.json'),'input_manifest':digest(DEST/'input-manifest.json'),
                  'finding':freeze['finding'],'raw_and_R7_R8_originals_preserved':True},indent=2))
