from pathlib import Path
import json, hashlib, gzip, datetime, sys, shutil
sys.path.insert(0, 'tools')
import astis_advance as a

sha = lambda b: hashlib.sha256(b).hexdigest()
def put(p, x):
    Path(p).write_text(json.dumps(x, ensure_ascii=False, indent=2)+'\n')
b = Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-admissibility-semantic-evidence')
aid = 'ASTIS-SA-20261107-GaussianComplexityFixedSpectrumAdmissibility'
owner = 'huanjian_gc_20261107_fixed_spectrum_admissibility'
decl = 'AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumAdmissibility.actual_precision_admissible'
files = {'AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumAdmissibility.lean':'0e3fea5e779787d9a5365b639fdb5bff8e4a76d9e53a6dba811531db321f2241',
         'Tests/GaussianComplexityFixedSpectrumAdmissibility.lean':'59a064649635a38002d752d4e42ae0051700c415e5ab9f323fb007576b2226d1'}
for p,h in files.items(): assert sha(Path(p).read_bytes()) == h
out = b/'actual-checks'
archives = []
for p in sorted(Path('.astis/huanjian-resume-20261103').glob('*-fixed-spectrum-admissibility-*.receipt.json')):
    r = json.loads(p.read_bytes()); q = Path(r['log']); raw = q.read_bytes()
    assert sha(raw) == r['log_sha256']
    # Earlier frozen snapshots are preserved; complete executions get a separate namespace.
    dest = out/'completed-executions'; dest.mkdir(exist_ok=True)
    shutil.copy2(p, dest/p.name)
    z = dest/(q.name+'.gz'); z.write_bytes(gzip.compress(raw, mtime=0))
    assert gzip.decompress(z.read_bytes()) == raw
    archives.append({'receipt':str(dest/p.name),'receipt_raw_sha256':sha(p.read_bytes()),'exit_code':r['exit_code'],
                     'head_before':r['head_before'],'raw_log_sha256':sha(raw),'gzip':str(z),'gzip_sha256':sha(z.read_bytes())})
put(out/'completed-executions-manifest.json', {'scope':'Completed genuine executions only; original frozen snapshots/failed routes retained without normalization.', 'checks':archives})
def check(label):
    rows = [x for x in archives if x['receipt'].endswith('-'+label+'.receipt.json')]
    assert len(rows) == 1 and rows[0]['exit_code'] == 0
    return rows[0]
build = check('fixed-spectrum-admissibility-explicit-actual-consumer')
anon = check('fixed-spectrum-admissibility-anonymous-meaning-and-application')
publication = check('fixed-spectrum-admissibility-author-publication-draft')
probe = Path('.astis/huanjian-fixed-spectrum-admissibility-20261107/AnonymousProbe.lean').read_bytes()
z = b/'proof-attempts/anonymous-meaning.raw.lean.txt.gz'; z.write_bytes(gzip.compress(probe,mtime=0)); assert gzip.decompress(z.read_bytes()) == probe
mapping = {
 'sg:fs-admiss:gap-grid-arithmetic':'The public constructor is the literal Fin d half-grid; focused Test ring proves zero-/one-based source-index equality. This is a compiled meaning adapter, not a false producer dependency; the cosine envelope requires no angle restriction and source hd is retained unused.',
 'sg:fs-admiss:gap-cosine-background':'hcoef and hvalue use the canonical real cosine bounds and nonnegative coefficient derived from hκ.',
 'sg:fs-admiss:gap-affine-envelope':'hvalue derives both source scalar endpoints internally with exact real arithmetic; hdiaglo/hdiaghi and canonical PSD.diagonal yield the actual positive diagonal differences.',
 'sg:fs-admiss:gap-orthogonal-congruence':'hO comes from full actual orthogonal-group membership; hstar identifies real transpose, hloweq/hhigheq identify actual conjugates, and hAlo/hAhi use canonical PSD conjugation. hpos adds the positive identity to the proved lower PSD difference.'}
record = {'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'state':'COMPILED_LOCAL_INDEPENDENT_SOURCE_REVIEW_PENDING',
 'mathematical_result':'The literal source cosine-grid precision has both quadratic-form bounds I<=A<=κI and internally produced positive definiteness for source d>=2, κ>=2 and every full real orthogonal O.',
 'actual_consumer':'The same literal A defines actual N(0,Ainv); focused Test obtains hA from the new producer and invokes the existing canonical GaussianPrecisionDensity.multivariateGaussian_eq_withDensity_of_posDef A hA, giving its actual Euclidean-Lebesgue quadratic density with real d/2.',
 'source_gap_implementation_map':mapping,'production_and_Test_sha256':files,
 'ASTIS_proof_parents':[], 'consumer_canonical_dependency':'AutoSamplingTheory.TechnicalLemmas.Measure.GaussianPrecisionDensity.multivariateGaussian_eq_withDensity_of_posDef',
 'dependency_boundary':'The existing GaussianPrecisionDensity leaf is reused literally in the consumer, not duplicated and not a producer proof parent. FixedSpectrumAffine and FirstOrderQuery are not producer parents.',
 'actual_standard_axioms':['propext','Classical.choice','Quot.sound'],
 'actual_checks':{'production_and_real_consumer':build,'anonymous_definition_meaning_and_application':anon,'publication_draft':publication},
 'failed_routes':'Actual missing Real StarOrderedRing instance import, Test parser layout and implicit-A isDefEq timeout are implementation failures. Canonical instance import, valid syntax and explicit actual let-bound θ/A/typed hA fix them without changing source binders, adding hypotheses, increasing heartbeat caps or treating failures as mathematical counterexamples. Failed raw inputs and logs remain.',
 'not_mathematical_novelty':'3120 focused build jobs are observability only. The actual matrix bounds/positive precision and actual law-density consumer are mathematical content.',
 'source_fidelity':'Draft; independent blind reconstruction and fresh raw-first source/whole-module/static-reader review pending.',
 'boundaries_open':['independent sourceV and canonicalroot/site/graph/desktop-mobile immutable acceptance','C4 quadratic calculus/Hessian/minimizer and basis-independent determinant/known-normalizer product; actual density consumer does not close these','moments/Krylov/full fixed-spectrum lower bound and determinant-sign main lower bound','actual adaptive/private-seed/transcript/output, Gaussian target/TV, finite precision, deterministic cap and explicit expected-cost adapters','remote original-owner hold/publication, postmerge purification/Exposition Seal and wholeGoal']}
put(b/'local-proof-capsule.json',record)
p = Path('research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-admissibility.json')
x = json.loads(p.read_bytes()); x['status']='proved_locally'
x['conceptual_mirror_audit']['reason']='Actual proof/consumer audit finds no NEW conceptual mirror. The identical existing GaussianPrecisionDensity declaration is canonical formal reuse in the actual consumer, not a weaker mechanism or duplicate lemma. The existing oracle-factorization hyperedge concerns a different mechanism and remains unchanged; no borrowed discovery id or admissibility-to-oracle transport is claimed.'
x['evidence']['execution_boundary']=record['mathematical_result']+' Actual same-A Gaussian density consumer and anonymous exact finite-support meaning/application compile. Independent sourceV, canonical integration, main bounds, remote/purification/wholeGoal remain pending.'
x['evidence']['local_proof_capsule']=str(b/'local-proof-capsule.json')
x['evidence']['focused_checks']=[build['receipt'],anon['receipt']]
x['evidence']['actual_consumer_interface']['status']='EXACT_SEALED_REAL_CONSUMER_COMPILED_INDEPENDENT_SOURCE_REVIEW_PENDING'
x['source_proof_coverage']['current_implementation_mapping']=str(b/'local-proof-capsule.json')+'#/source_gap_implementation_map'
x['source_proof_coverage']['source_only_files_unchanged']=True
x['source_proof_coverage']['scope']='Exact named Lemma4.6 precision sandwich and produced PosDef now compiled, with actual same-A law-density consumer. Original frozen source graphs and eight preproof gaps remain historical inputs; the four core bridges are mapped to actual implementation above. Full C4 and known-normalizer product remain open.'
x['source_detail_audit']['fidelity_boundary']=x['evidence']['execution_boundary']
x['learning_contract']['failure_class']='IMPLEMENTATION_FAILED'
x['learning_contract']['salvage']={'required':True,'status':'completed','reason':record['failed_routes'],'promoted_fragments':['Actual producer, actual same-A law-density consumer and finite-support meaning/index adapters compile.'],'discarded_fragments':[]}
put(p,x)
state=a.current_advances(); assert state[aid]['state']=='EXPLORING'
ledger=Path('runs/substantive_advances.jsonl'); before=ledger.read_bytes(); db=Path('runs/substantive_discoveries.jsonl').read_bytes()
a.transition_advance(aid,to_state='PROVED_LOCAL',worker_id=owner,evidence={'result_kind':'integration-node','theorem_delta':record['mathematical_result'],'lean_files':list(files),'lean_declarations':[decl],'publication_declarations':[decl],'focused_checks':[build,anon,{'publication_draft':publication,'independent_source_review':'pending'}],'truth_boundary':record['boundaries_open'],'conceptual_mirror_audit':x['conceptual_mirror_audit'],'capsule':str(b/'local-proof-capsule.json')})
after=ledger.read_bytes(); now=a.current_advances(); assert after.startswith(before) and len(after[len(before):].splitlines())==1 and all(now[k]==v for k,v in state.items() if k!=aid) and Path('runs/substantive_discoveries.jsonl').read_bytes()==db
put(b/'normal-proved-local-preservation.json',{'actual_state':now[aid]['state'],'before_sha256':sha(before),'after_sha256':sha(after),'append_sha256':sha(after[len(before):]),'append_events':1,'exact_prefix_preserved':True,'all_foreign_states_preserved':len(state)-1,'discovery_ledger_unchanged':True,'sourceV_created_by_root':False,'canonical_integration':False})
readme=Path('research-wiki/paper-contributions/GaussianComplexity/README.md'); old=readme.read_bytes()
intro='# Current continuation: actual precision admissibility and Gaussian consumer compiled local\n\nRead `fixed-spectrum-admissibility-semantic-evidence/local-proof-capsule.json`. Literal source precision satisfies I<=A<=κI with internally produced PosDef for exact source d>=2,κ>=2/fullO. Actual same-A inverse-precision Gaussian law-density consumer reuses the canonical GaussianPrecisionDensity leaf; producer ASTIS proof parents are empty. Exact finite-support meaning, index alignment, actual theorem application and draft publication validate. Normal state is PROVED_LOCAL, independent blind decoder/fresh raw-first source/whole-module/static-reader review pending. Source graph/topology and exact consumer admission preceded target implementation. Full C4 known-normalizer/calculus, both main lower bounds, true oracle/precision/TV/cost adapters, canonical integration, remote/purification/wholeGoal remain open. Root is the sole mathworker. Every older checkpoint is retained phase history.\n\n'
readme.write_bytes(intro.encode()+old)
print(json.dumps({'state':now[aid]['state'],'foreign_states_preserved':len(state)-1,'actual_archived_checks':len(archives),'sourceV':'pending'}))
