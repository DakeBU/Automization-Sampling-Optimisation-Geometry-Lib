from pathlib import Path
from datetime import datetime,timezone
import ast,copy,json,sys
sys.dont_write_bytecode=True
from park_common import *

context_path=R/'root-final-browser-context-v3.json'
raw=context_path.read_bytes();assert sha(raw)==CONTEXT_SHA
ctx=json.loads(raw)
assert ctx['accepted_immutable_core']==CORE and ctx['parking_authorized'] is False
assert ctx['integration_owner']==INTEGRATOR
assert git('rev-parse','HEAD').decode().strip()==CORE
assert not git('diff','--name-only',CORE).strip()
for parent,child in [(CHECKED,SOURCEV_COMMIT),(SOURCEV_COMMIT,CORE)]:
 assert subprocess.run(['git','merge-base','--is-ancestor',parent,child],cwd=ROOT).returncode==0
ledger=LEDGER.read_bytes();assert ledger.endswith(b'\n')
v=ref_bytes(ctx['source_V_append']);stab=ref_bytes(ctx['STAB_append'])
assert sha(v)==V_SHA and sha(stab)==STAB_SHA
assert ledger.count(v)==ledger.count(stab)==1 and ledger.index(v)<ledger.index(stab)
V=json.loads(v);STAB=json.loads(stab)
assert V['evidence']['verified_commit']==CHECKED and V['worker_id']==ACTOR
assert STAB['worker_id']==INTEGRATOR and STAB['evidence']['integration_owner']==INTEGRATOR
assert STAB['from_state']=='VERIFIED' and STAB['to_state']=='STABILIZING'
assert sha(AUDIT.read_bytes())==AUDIT_SHA
s=states();assert len(s)==285
own=s[ADV];assert own['owner_id']==OWNER and own['state']=='STABILIZING'
assert own['latest_evidence']['integration_owner']==INTEGRATOR
assert [k for k,v in s.items() if v['state']=='STABILIZING']==[ADV]
f=frontiers();assert len(f)==444 and len({k:v for k,v in f.items() if k!=OWN_CELL})==443
critical={context_path.relative_to(ROOT).as_posix():CONTEXT_SHA}
def addref(ref):
 data=ref_bytes(ref);critical[ref['path']]=sha(data)
for k in ['source_V_append','accepted_source_audit','source_review_run','actual_gate','site_metadata','own_frontier_current','own_frontier_projection_review','STAB_append','source_V_actual_execution_manifest','additional_actual_standalone_root_check']:
 addref(ctx[k])
for ref in ctx['actual_checks_before_browser'].values():
 addref(ref);receipt=json.loads(ref_bytes(ref))
 assert receipt['exit_code']==0 and receipt['head_before']==receipt['head_after']==CORE
 log=Path(receipt['log']).resolve();assert log.is_relative_to(ROOT)
 assert sha(log.read_bytes())==receipt['log_sha256']
 critical[log.relative_to(ROOT).as_posix()]=receipt['log_sha256']
for rel in [
 'website/content/graph_memory_index.json','website/content/functor_hypergraph.json',
 'research-wiki/paper-contributions/GaussianComplexity/README.md',
 'lake-manifest.json','lean-toolchain',
 'AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumFirstOrder.lean',
 'Tests/GaussianComplexityFixedSpectrumFirstOrder.lean',
 'AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumAdmissibility.lean',
 'AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumAffine.lean',
 'website/content/declaration_lessons/huanjian-fixed-spectrum-first-order.json',
 'website/content/publications/huanjian-fixed-spectrum-first-order.json']:
 critical[rel]=sha((ROOT/rel).read_bytes())
for name,h in [('check_final_reader_v3.py',ctx['browser_checker_sha256']),('first_order_browser_common_v3.py',ctx['browser_common_sha256'])]:
 p=R/'independent-reader'/name;assert sha(p.read_bytes())==h
 critical[p.relative_to(ROOT).as_posix()]=h
frozen={}
for d in ['phase1','phase2','phase3','verification-transition-preparation','verification-transition-execution']:
 for p in (BASE/d).rglob('*'):
  if p.is_file():frozen[p.relative_to(ROOT).as_posix()]=sha(p.read_bytes())
public=ROOT/'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-first-order-semantic-evidence/fresh-source-reader-4e8f6a'
for p in public.rglob('*'):
 if p.is_file():frozen[p.relative_to(ROOT).as_posix()]=sha(p.read_bytes())
(PREP/'original-V306.exact.jsonl').write_bytes(v)
(PREP/'original-STAB621.exact.jsonl').write_bytes(stab)
(PREP/'ledger-before-park.exact.jsonl').write_bytes(ledger)
dump(PREP/'original-V-evidence.exact-values.json',V['evidence'])
baseline={'created_utc':datetime.now(timezone.utc).isoformat(),'accepted_immutable_core':CORE,
 'checked_source_commit_to_preserve':CHECKED,'source_V_first_carrying_commit':SOURCEV_COMMIT,
 'actor':ACTOR,'proof_owner':OWNER,'current_STAB_owner':INTEGRATOR,
 'own_STAB_state':own,'SAU_count':285,'foreign_SAU_count':284,
 'foreign_284_SAU_state_sha256':foreign_state_digest(s),
 'frontier_raw_hashes':f,'foreign_frontier_count':443,'own_frontier_path':OWN_CELL,
 'discovery_sha256':sha((ROOT/'runs/substantive_discoveries.jsonl').read_bytes()),
 'git_index_entries_sha256':sha(git('ls-files','-s','-z')),
 'ledger_before_sha256':sha(ledger),'ledger_before_bytes':len(ledger),
 'original_V_append_sha256':V_SHA,'STAB_append_sha256':STAB_SHA,
 'original_V_evidence_canonical_sha256':sha(canonical(V['evidence'])),
 'source_audit_sha256_to_preserve':AUDIT_SHA,
 'critical_raw_pins':critical,'frozen_originals':frozen,
 'tracked_preservation':'HEAD/index plus exact tracked diff guard: clean before, only one ledger path after. All tracked source/config/models/README preserved; no125k path sweep.',
 'normal_API_called':False}
dump(PREP/'preservation-baseline.json',baseline)
protected(baseline)
template={'state':'MISSING_EXTERNAL_ACCEPTANCE_INPUTS','accepted_immutable_core':CORE,
 'artifacts':{k:{'path':None,'sha256':None} for k in ['bound_context_review','browser_report','browser_command_receipt','pixel_review','local_acceptance','parking_eligibility']},
 'note':'Preparation only. Do not set ready or add accepted claims until actual bound independent context review, actual38 original PNGs and independent pixel review, local acceptance and eligibility exist. The helper validates the exact typed artifact contract in acceptance-contract.md; differing schemas fail closed.'}
dump(PREP/'acceptance-inputs.template.json',template)
for p in PREP.glob('*.py'):ast.parse(p.read_text())
assert not (BASE/'normalpark-execution').exists()
assert not (PREP/'root-authorization.json').exists()
dump(PREP/'baseline-receipt.json',{'prepared_utc':datetime.now(timezone.utc).isoformat(),
 'core':CORE,'current_state':'STABILIZING','current_STAB_owner':INTEGRATOR,
 'original_V_raw_sha256':V_SHA,'original_V_evidence_keys':sorted(V['evidence']),
 'all_original_V_evidence_values_will_be_exact':True,
 'only_future_new_evidence_key':'post_integration_normalpark',
 'SAUs':285,'foreign_SAUs':284,'all_frontier_JSON':444,'foreign_frontiers':443,
 'critical_raw_pin_count':len(critical),'frozen_original_count':len(frozen),
 'external_acceptance_inputs_supplied':False,'canonical_mutation':False,'normal_API_called':False})
print(json.dumps({'baseline_sha256':sha((PREP/'preservation-baseline.json').read_bytes()),
 'helper_sha256':sha((PREP/'normalpark_once.py').read_bytes()),
 'original_evidence_preserved':True,'critical_raw_pins':len(critical),'frozen_originals':len(frozen),
 'external_inputs':'MISSING; template fail-closed','API_called':False},indent=2))
