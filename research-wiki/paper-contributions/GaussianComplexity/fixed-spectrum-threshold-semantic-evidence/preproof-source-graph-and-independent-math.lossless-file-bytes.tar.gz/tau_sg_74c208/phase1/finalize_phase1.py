from pathlib import Path
import hashlib
import json
import runpy
import shutil
import stat

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'phase1'
M=runpy.run_path(str(ROOT/'extract_raw_source.py'))
P=M['PARSER']


def save(name,obj):
    (OUT/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')


def refs(*ids):
    return [{'source_id':i,**P.by_id[i].locator()} for i in ids]


quantifiers=[
 {'id':'Q-theorem-4-1','source':refs('S4.Thmtheorem1.p1'),
  'literal_order':'For every fixed delta in (0,1), there exists d0(delta), such that for every integer d>=d0(delta), every 2<=kappa<=d^(1-delta), and every 0<epsilon<=1/10, the lower bound holds.',
  'scope_note':'This is the surrounding source theorem, not a completed target of this extraction. The raw text does not give a domain or explicit numeric formula for d0.'},
 {'id':'Q-hard-family','source':refs('S4.SS1.p1','S4.SS1.p2'),
  'literal_order':'For d>=2 and kappa>=2 define deterministic theta_i, lambda_i, Lambda; draw O Haar on O(d), independent of algorithm private randomness; A=O Lambda O^T.',
  'scope_note':'Spectrum may be supplied to algorithm. Randomness of the hidden eigenbasis is the input randomness.'},
 {'id':'Q-krylov-boundary','source':refs('S4.Thmtheorem3.p1','S4.SS2.SSS0.Px1.p3','S4.SS3.SSS0.Px1.p1'),
  'literal_order':'Fix integer q>=0 with 2q+1<d and output X; there exist independent standard Gaussian g_1,...,g_(q+1) so O^T X lies in K_q almost surely.',
  'scope_note':'Polynomial coefficients may depend on the entire extended experiment. Section 4.3 states extension preserves joint law of (O,X). No stronger independence of g from O, X, or adaptive coefficients is introduced.'},
 {'id':'Q-tau-lemma','source':refs('S4.Thmtheorem4.p1','S4.SS2.SSS0.Px2.p2'),
  'literal_order':'There is an absolute constant C>0 such that: let q>=0 satisfy 2q+1<d, independent standard Gaussian g_1,...,g_(q+1), and K_q as defined. Define literal tau_(d,q). If tau_(d,q)<=1/2 then probability>=0.99 of the bound simultaneously for every u in K_q.',
  'scope_note':'The lemma sentence writes q>=0 without repeating the word integer. The surrounding query-budget and Krylov convention is integer q. C precedes d,q and all random vectors; tau contains no kappa.'},
 {'id':'Q-target-moments','source':refs('S4.Thmtheorem5.p1','S4.Thmtheorem5.p2'),
  'literal_order':'Let kappa>=2 and U~N(0,Lambda^-1); define rho_kappa. For integer 1<=n<d define D_n, M and mu_n. Exact moments and both variance bounds hold. If additionally d-n>=sqrt(kappa), the normalized-bias bounds hold.',
  'scope_note':'The gap condition is specific to the bias estimate, not an additional premise of the exact moment or variance formulas. Positivity/sign is made explicit in C.3 p9.'},
 {'id':'Q-section-4-3-fixed-range','source':refs('S4.SS3.p2','S4.SS3.p3'),
  'literal_order':'Fix delta in (0,1), 2<=kappa<=d^(1-delta), 0<epsilon<=1/10. Suppose algorithm uses at most q<=(delta/256)*sqrt(kappa)*log d and has the per-input TV guarantee for every admissible A. Set n=2q+1 and tau=tau_(d,q).',
  'scope_note':'q is the deterministic query cap of a Borel randomized algorithm; the TV hypothesis belongs to the surrounding contradiction, not the shifted-variable moment calculation.'},
 {'id':'Q-algorithmic-event','source':refs('S4.SS3.SSS0.Px1.p1'),
  'literal_order':'For sufficiently large d depending only on fixed delta, n<d and tau<=1/2, so Lemmas 4.3 and 4.4 apply. A single event of probability>=0.99 bounds the actual output, hence averaged pass probability over random A is <=0.01.',
  'scope_note':'Source says these are eventual estimates. The q+1 bound and n=o(d) are not claimed for every small d. The probability statement here is averaged over the hard input, not a 0.01 bound for each A.'},
 {'id':'Q-target-feasibility','source':refs('S4.SS3.SSS0.Px2.p1','S4.SS3.SSS0.Px2.p2'),
  'literal_order':'Uniformly over the stated kappa and q range for fixed delta, choose d0(delta) so algorithmic conditions hold, d-n>=sqrt(kappa), tau<=beta/4 and M*beta^2>=320.',
  'scope_note':'All estimates are explicitly said to be uniform. The source fixes absolute C before this threshold. It does not choose C after d, delta, kappa or q.'},
 {'id':'Q-shifted-detector','source':refs('S4.SS3.SSS0.Px2.p3'),
  'literal_order':'Now fix A in the hard family, draw Y~pi_A, and set Z=S_A(Y). Signed cosine mean is beta*M, norm mean is M, both variances<=2M. E[Z]>=beta*M/2 and Var(Z)<=8M; Chebyshev then yields pi_A(E_A)=P(Z>0)>=0.9 for every hard A.',
  'scope_note':'Mean lower bound uses tau<=beta/4; final variance bound also uses the algorithmic tau<=1/2. The two quadratic forms need not be independent: the source uses the centered L2 triangle inequality.'},
 {'id':'Q-C-2-simultaneous','source':refs('A3.Thmtheorem6.p1','A3.SS2.p17','A3.SS2.p18','A3.SS2.p19'),
  'literal_order':'For sufficiently large absolute C in tau, both Gram bounds hold on a common event of probability>=0.995. For all coefficient c on that event, and hence simultaneously all u in K_q, tau<=1/2 gives the desired quadratic bound.',
  'scope_note':'All constants in z=O(log d), L+3=O(r+log d), and c>0 are explicitly absolute. 2q+1<d plus integer dimensions/budget yields d>=2 and 2r<=d.'},
 {'id':'Q-C-3-series-aliases','source':refs('A3.Thmtheorem7.p1','A3.SS3.p3','A3.SS3.p6','A3.SS3.p9','A3.SS3.p11'),
  'literal_order':'C.7 is for every real theta, with absolute and uniform series convergence. The grid cosine-sum rule is for every integer k. For integer 1<=n<d the three alias classes are disjoint, signed mu_n is positive, and the exact normalized ratio holds. The tail factor estimate uses d-n>=sqrt(kappa).',
  'scope_note':'Do not erase the finite-grid correction, the sign (-1)^n, or the additional gap condition.'},
]
save('quantifier-scope-inventory.json',quantifiers)

constants=[
 {'id':'C','source':refs('S4.Ex13','S4.Thmtheorem4.p1','A3.Thmtheorem6.p1','A3.SS2.p18','A3.SS2.p19'),
  'meaning':'One absolute positive concentration constant in literal tau_(d,q).',
  'selection_order':'Source existential in Lemma 4.4; Appendix C.2 chooses C sufficiently large, specifically C>=c for an absolute c>0; then Section 4.3 keeps that C fixed while fixing delta and choosing d0(delta).',
  'allowed_dependencies':'No dependence on delta, d, kappa, q, Gaussian draws, or a dimension cutoff. No numeric value is specified.',
  'not_arbitrary':'The source does not assert the concentration theorem for every positive C. An arbitrary positive scale parameter and the sufficiently large source concentration constant have different quantifiers.'},
 {'id':'literal-tau','source':refs('S4.Ex13'),
  'formula':r'tau_(d,q)=C[(q+1)*sqrt(log(d)/d)+(q+1)*(q+1+log(d))*log(d)/d]',
  'meaning':'Both displayed terms, additive q+1+log d, parentheses and one common factor C are literal. kappa does not occur.'},
 {'id':'c','source':refs('A3.SS2.p18'),
  'meaning':'Absolute c>0 bounding Delta+(1-a); C>=c absorbs it. Not the constant C-prime from Section 4.3.'},
 {'id':'C-prime','source':refs('S4.Ex24','S4.SS3.SSS0.Px2.p2'),
  'meaning':'Unspecified fixed comparison constant in tau/beta upper bound, inherited from the earlier tau bound with fixed absolute C.',
  'scope_note':'The source does not separately quantify C-prime or make it a free target hypothesis. It can depend on the previously fixed numerical C; it cannot be chosen depending on d, kappa, or q while claiming the displayed uniform limit.'},
 {'id':'delta-and-d0','source':refs('S4.Thmtheorem1.p1','S4.SS3.SSS0.Px2.p2'),
  'meaning':'0<delta<1 fixed first in the lower bound theorem. d0(delta) is selected after the absolute concentration constant is fixed, uniformly over remaining parameters.',
  'scope_note':'The selected raw source has no scalar cutoff named capital D. D_n denotes a cosine diagonal matrix; Delta denotes a concentration radius. No target-projection meaning of D is assumed in Phase 1.'},
 {'id':'budget','source':refs('S4.SS3.p2','S4.SS3.SSS0.Px2.p2'),
  'values':['q<=(delta/256)*sqrt(kappa)*log d','n=2q+1','3n/sqrt(kappa)<=3+(3delta/128)*log d'],
  'meaning':'256 and 128 retained exactly; additive 3 absorbs the n=2q+1 contribution.'},
 {'id':'bias-scale','source':refs('S4.Ex23','S4.Ex24'),
  'values':['b=(1-exp(-4))*exp(-3)','beta>=b*d^(-delta/4)','tau/beta<=(C-prime/b)*d^(-delta/4)*(log d)^3','M*beta^2>=(b^2/2)*sqrt(d)'],
  'meaning':'b is a positive absolute numeric constant, independent of delta and other parameters. The source relaxes the budget exponent to delta/4.'},
 {'id':'thresholds-and-detector','source':refs('S4.Ex13','S4.EGx2','S4.Ex25','S4.Ex26','S4.SS3.SSS0.Px2.p2'),
  'values':['tau<=1/2','S_A=signed cosine quadratic - 2*tau*norm^2','E_A={S_A>0}','tau<=beta/4','M*beta^2>=320','E[Z]>=(beta*M)/2','Var(Z)<=8*M','Chebyshev loss<=32/(M*beta^2)','target pass>=0.9'],
  'meaning':'Strict >0 event; algorithmic bound supplies <=0 complement. 320 is used for 32/320=0.1. The L2 variance estimate uses the coefficient 2*tau.'},
 {'id':'probability-budgets','source':refs('S4.Ex22','A3.SS2.p10','A3.SS2.p16','A3.SS2.p17','A3.SS2.p19'),
  'values':['0.999 truncation','0.002 each Bernstein tail','0.996 simultaneous Bernstein','0.995 after truncation intersection','0.99 source Lemma 4.4 conclusion','0.01 algorithmic average pass'],
  'meaning':'Keep common events and union bounds; do not convert simultaneous bounds into independent events.'},
 {'id':'C-2-auxiliary-scales','source':refs('A3.SS2.p10','A3.SS2.p13','A3.SS2.p14','A3.SS2.p16'),
  'values':['r=q+1','L=2r+3log(1000d)','R_*=2r(L+1)/d','v_*=2r(r+2)/d','z=log(1000r^2)','Delta=sqrt(2v_* z)+(2R_* z)/3'],
  'meaning':'1000, 2, 3, r+2 and 1-a are retained; absolute C comes from simplifying these scales.'},
 {'id':'C-3-bias-scales','source':refs('S4.Thmtheorem5.p1','A3.SS3.p10','A3.SS3.p11'),
  'values':['rho=(sqrt(kappa)-1)/(sqrt(kappa)+1)','2/sqrt(kappa)<=log(1/rho)<3/sqrt(kappa)','(1-exp(-4))*exp(-3n/sqrt(kappa))<=beta<=exp(-2n/sqrt(kappa))'],
  'meaning':'kappa>=2 and d-n>=sqrt(kappa) have different uses. Section 4.3 uses the weaker rho<=exp(-1/sqrt(kappa)) for its M lower bound.'},
]
save('constant-scope-inventory.json',constants)

definitions=[
 ('notation','S2.p1','Euclidean norm; I_d; A preceq B means B-A PSD.'),
 ('orthogonal-group','S2.p2','O(n) real orthogonal group with Haar probability; determinant-conditioned measure unused here.'),
 ('target-class','S2.SS0.SSS0.Px1.p1','A_(d,kappa) symmetric with I<=A<=kappa I; f_A(x)=x^T A x/2; pi_A=N(0,A^-1).'),
 ('algorithm-convention','S2.SS0.SSS0.Px2.p1','Borel adaptive algorithm/output, independent private randomness and deterministic query cap.'),
 ('output-law','S2.SS0.SSS0.Px4.p1','rho_A^Alg includes all private randomness.'),
 ('grid-and-hard-family','S4.SS1.p1','theta_i=(i-1/2)pi/d; lambda_i=(kappa+1)/2+(kappa-1)cos(theta_i)/2; Lambda diag; A=O Lambda O^T.'),
 ('krylov','S4.Ex10','K_q=span{Lambda^j g_a:1<=a<=q+1,0<=j<=q}.'),
 ('cosine-detector-matrix','S4.Ex12','n=2q+1; D_n=diag(cos(n theta_i)).'),
 ('tau','S4.Ex13','Literal two-term tau with a single fixed positive absolute C, including additive q+1+log d.'),
 ('rho-and-target-moments','S4.Thmtheorem5.p1','rho_kappa=(sqrt(kappa)-1)/(sqrt(kappa)+1); M=E||U||^2; mu_n=E[U^T D_n U].'),
 ('shifted-statistic-and-event','S4.EGx2','S_A(x)=(-1)^n x^T T_n((2A-(kappa+1)I)/(kappa-1))x -2tau||x||^2; E_A={x:S_A(x)>0}.'),
 ('normalized-energy-weights','S4.SS3.p4','w_i(x)=|<x,Oe_i>|^2/||x||^2 for x!=0 only; no off-domain fallback is supplied or needed for S_A.'),
 ('target-normalized-bias','S4.SS3.SSS0.Px2.p1','M=tr(Lambda^-1), mu_n=tr(D_n Lambda^-1), beta=|mu_n|/M.'),
 ('shifted-random-variable','S4.SS3.SSS0.Px2.p3','For fixed A and Y~pi_A, Z=S_A(Y).'),
 ('cosine-design','A3.SS2.p1','r=q+1, n=2q+1; t_i=(1,sqrt2 cos(theta_i),...,sqrt2 cos(q theta_i)); gamma_i row of g coordinates; B row=d^-1/2(gamma_i tensor t_i)^T.'),
 ('truncation','A3.SS2.p10','L=2r+3log(1000d), R_i=||gamma_i||^2, T={R_i<=L for all i}.'),
 ('truncated-matrices','A3.SS2.p12','Independent Y_i and radial scalar a defined literally in p12; 0<=a<=1 and same a for all i.'),
 ('centered-summands','A3.SS2.p13','Z_i=Y_i-E Y_i; R_* bound defined in p13. This Z_i is distinct from scalar detector variable Z.'),
 ('variance-radius','A3.SS2.p14','v_*=2r(r+2)/d; common matrix variance upper bound.'),
 ('bernstein-radius','A3.SS2.p16','z=log(1000r^2), Delta=sqrt(2v_*z)+2R_*z/3.'),
]
save('definition-inventory.json',[{'id':name,'source':refs(sid),'source_meaning':meaning,
 'audit_kind':'source literal/convention only; no project-owned definition was inspected'} for name,sid,meaning in definitions])

gaps=[
 {'id':'SOURCE_GAP-tau-eventual-bookkeeping','source':refs('S4.SS3.SSS0.Px1.p1','S4.Ex20'),
  'kind':'source-abbreviated-bookkeeping','visible_boundary':'The source gives q+1<=d^((1-delta)/2) log d, n=o(d), the two-term tau substitution, and eventual n<d/tau<=1/2, but no explicit threshold or full uniform quantifier calculation.',
  'handling':'Keep this as an unnamed producer obligation; do not add its conclusion as an extra source hypothesis. It is an omitted detail, not a claimed contradiction in the source.'},
 {'id':'SOURCE_GAP-target-joint-cutoff','source':refs('S4.SS3.SSS0.Px2.p2','S4.Ex23','S4.Ex24'),
  'kind':'source-abbreviated-bookkeeping','visible_boundary':'The source asserts uniform limits and selects one d0(delta) making the gap, algorithmic conditions, tau<=beta/4, and M beta^2>=320 hold; no numeric cutoff witness or explicit derivation of the common uniform cutoff is supplied.',
  'handling':'Preserve the uniform threshold-selection node and its constituent estimates. Source C is already fixed before this selection.'},
 {'id':'SOURCE_GAP-detector-matrix-algebra','source':refs('S4.SS3.p3','S4.SS3.p4','S4.SS2.SSS0.Px3.p2'),
  'kind':'source-omitted-matrix-bridge','visible_boundary':'The source states T_n(cos theta_i)=cos(n theta_i), the detector formula and rotated target identities; it does not separately display/prove T_n((2A-(kappa+1)I)/(kappa-1))=O D_n O^T.',
  'handling':'Retain this finite-dimensional spectral-polynomial bridge explicitly if the sealed interface needs it; do not silently identify the two detector formulas without provenance.'},
 {'id':'SOURCE_GAP-matrix-Bernstein-provenance','source':refs('A3.SS2.p15','A3.Ex121'),
  'kind':'external-result-without-bibliographic-citation','visible_boundary':'The two-sided bounded matrix Bernstein inequality is invoked by name and with an exact formula. No bibliographic citation or proof of that external inequality occurs in the selected paragraph.',
  'handling':'Keep the external theorem input visible; this extraction does not certify or replace it.'},
]
save('source-gaps.json',gaps)

standard_inputs=[
 ('matrix-Bernstein','A3.SS2.p15','two-sided bounded independent centered self-adjoint matrix Bernstein, for t>0'),
 ('Gaussian-exponential-moment-and-Markov','A3.SS2.p10','E exp(R_i/3)=3^(r/2), then Markov and union bound'),
 ('tail-expectation-integration','A3.SS2.p11','tail integration identity for E[R_i 1_(R_i>L)]'),
 ('Gaussian-fourth-moments-matrix','A3.SS2.p14','E[R_i gamma_i gamma_i^T]=(r+2)I_r, with source coordinate calculation'),
 ('cosine-polynomial-identity','A3.SS2.p3','cos(j theta)=T_j(cos theta), nonzero leading coefficient and triangular polynomial change of basis'),
 ('cosine-product-identities','A3.SS2.p5','product-to-sum and triple product expansions, each used at explicit frequencies'),
 ('geometric-series','A3.SS3.p2','0<rho<1 permits complex geometric-series identity and uniform majorant'),
 ('Gaussian-diagonal-coordinate-moments','A3.SS3.p8','independent centered diagonal Gaussian coordinates; fourth moment=3/lambda_i^2'),
 ('centered-L2-triangle','S4.SS3.SSS0.Px2.p3','triangle inequality for centered variables to bound shifted quadratic variance, without independence'),
 ('Chebyshev','S4.SS3.SSS0.Px2.p3','P(Z<=0)<=Var(Z)/(E Z)^2 when E Z>0'),
]
save('standard-external-input-use-sites.json',[{'id':name,'consumer_source':refs(sid),'statement_role':role,
 'source_proof_status':'Source-invoked or source-calculated; no local implementation or external proof searched in Phase 1.'} for name,sid,role in standard_inputs])

ambient='''Role required by AGENTS.md / proof-digestion: independent SOURCE-ONLY extractor for one next bounded GaussianComplexity packet. Repo /Users/zhouhuanjian/ASTIS-GC. Do NOT prove Lean or read implementation Lean, target drafts, root's proof notes, candidate exposition, prior packet verdicts or ledgers. Own only .astis/semantic-neutral-20261110/tau_sg_74c208/. Read repository AGENTS.md, docs/proof-digestion-protocol.md and relevant source audit instructions. Phase1 FIRST independently inspect pinned raw source .astis/huanjian-resume-20261103/2610.20492v1.html (SHA2566bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915). Scope planning only: Section4 Lemma4.4 literal tau definition; Section4.3 algorithmic tau-small and target tau/beta-small + shifted detector mean/variance/Cheb paragraphs; necessary AppendixC.2/C.3 provenance and necessary definitions. Exhaustively inventory source regions in your explicitly selected slice with raw source byte locators, NODE/EXCLUDED reasons, preserve source gaps. Freeze source-first paragraph/display/quantifier/constant scope inventory BEFORE requesting sealed target. Numeric C is absolute positive concentration constant in source; pay attention to where fixed relative to delta/d/kappa/q and D. Do not get topology from Lean or earlier SNR graph. No normal APIs/Git/fetch/build/browser/shared/frontier writes. Phase1 output include exact raw bytes losslessly, SHA256 manifest, exposure disclosure (including ambient message), own run manifest+freeze read-only. Then STOP and ask for exact sealed target projection, to reconstruct graph phase2. Independent distinct topology challenger will reread raw source. This is source graph extraction only, not self-approval.'''
(OUT/'ambient-task-message.txt').write_text(ambient+'\n')
exposure={
 'role':'independent SOURCE-ONLY extractor, Phase 1 only',
 'sealed_target_seen':False,'implementation_Lean_seen':False,'candidate_exposition_seen':False,
 'parent_proof_notes_seen':False,'prior_packet_verdict_contents_seen':False,'prior_ledgers_seen':False,
 'ambient_message_file':'ambient-task-message.txt',
 'ambient_semantic_steering':['Topic and source anchor/range were supplied.', 'Parent message explicitly characterized numeric C as absolute positive concentration constant and asked attention to order relative to delta/d/kappa/q/D.', 'No exact sealed theorem signature, Lean declaration, target projection, prior SNR graph, prior verdict, or proposed exposition was supplied.'],
 'instruction_exposure':['Full repository AGENTS.md across cat plus follow-up sed for tool truncation.', 'Full docs/proof-digestion-protocol.md.', 'Source dependency audit SKILL.md.', 'Semantic roundtrip SKILL.md.', 'Source/audit/encoder/blind/semantic rg matches from substantive-advance SKILL.md; whole raw file copied as input only when packaging, not used for theorem topology.'],
 'opening_discovery_exposure':{'command':"pwd && rg --files -g 'AGENTS.md' -g '*audit*' -g '*proof-digestion*' -g '!node_modules' -g '!.git' .",'effect':'Unnecessarily broad filename listing, tool output truncated. It exposed filenames from older proof/audit packets, including GaussianComplexity-related audit/topology evidence path names. No such contents were opened or used. This is disclosed rather than described as a perfectly blind environment.'},
 'additional_source_exposure':['Raw source heading scan included names and offsets across the whole paper.', 'Initial source paragraph text scan included all Section 4, so Section 4.4 limitations text was seen even though excluded from selected proof scope.', 'A later source command explicitly printed the raw-rendered S4.SS4 node along with requested boundary nodes; this repeated full Section 4.4 source text.', 'An incorrect bibliography-ID probe printed bib.bib22, which is numbered [19], Lindgren/Rue/Lindstrom (2011), an unrelated bibliography item. Its content was not used.', 'The entire pinned raw source was copied byte-for-byte into the package but only the disclosed source regions and heading/source probes were inspected.'],
 'negative_access_statement':'No implementation .lean file, target draft, root proof note, candidate exposition, earlier SNR graph, prior packet verdict content, ledger, Git data/command, browser, network, ASTIS normal API, compiler, build, shared aggregation, or frontier write was used.',
 'write_boundary':'Only .astis/semantic-neutral-20261110/tau_sg_74c208/ was created or modified.',
 'self_approval':False,
 'independence_limit':'Source-only inventory is an extractor proposal requiring a distinct raw-source topology challenger. Structural packaging checks are not mathematical approval.'
}
save('exposure-disclosure.json',exposure)

run={
 'run_id':'tau_sg_74c208','agent_task':'/root/tau_source_graph','phase':'1',
 'status':'source-first inventory frozen; awaiting exact sealed target projection for Phase 2',
 'source_sha256':M['EXPECTED'],'source_bytes':len(M['RAW']),
 'source_reading_order':['AGENTS and proof-digestion process instructions','source-audit instructions','raw pin verification','raw source heading and paragraph scans','exact selected-section parse with byte locators','source-only inventory and scope records'],
 'owned_path':str(ROOT),'target_projection_available':False,'proof_graph_edges_built':False,
 'checks':['Pinned SHA256 equality asserted.', 'UTF-8 source parsed with strict balanced element stack and unique source IDs.', 'All 71 selected ltx_para IDs have explicit NODE/EXCLUDED assignments.', 'All selected theorem blocks, source prose subparagraphs, display tables/groups, headings, bibliography/citation items explicitly inventoried.', 'All five selected raw byte ranges partitioned without omission; exact source copy and slices saved.', 'Every inventory raw locator SHA matches the original bytes.'],
 'known_packaging_failures_corrected':['Initial helper path used one excessive parent level, corrected before running extraction.', 'HTMLParser offset method name collided with its internal integer offset attribute; renamed position_offset. Failed parse produced no source inventory.'],
 'no_Lean_or_proof_claim':'No proof, build, theorem fidelity approval, or completed graph review is claimed.',
 'next_required_input':'Exact sealed target projection and only the minimal meaning-carrying definition context allowed to this source-topology role; pin file path and SHA256.',
 'next_phase_constraint':'Preserve this source-first freeze. Create Phase 2 separately, reconstruct nodes and consumer-site hyperedges from source inventory and sealed target, disclose the newly seen projection, and await independent topology challenge.'
}
save('run-manifest.json',run)

readme='''# Frozen source-first Phase 1

The pinned raw HTML SHA256 is 6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915 (951991 bytes).

Selected regions are Section 2 definition context, Section 4 through Section 4.3, Appendix C.2, Appendix C.3, and bibliography item [22]. Surplus comparison, oracle, roadmap, TV contradiction, and other selected contextual material has an explicit EXCLUDED disposition. Appendix C.1/C.4 proofs and the external [22] document are not extracted.

The inventory has 71 paragraph blocks, plus nested exact statement/prose/display/citation records. Source locators are raw UTF-8 byte intervals, 0-based and half-open. source.raw.html and raw/*.raw.html preserve bytes without normalization. inventory-reader.md uses math alttext only as a reading aid.

The source fixes a sufficiently large absolute positive concentration constant C before the Section 4.3 choice of d0(delta). C is uniform in d, q, kappa, delta and the cutoff. The source does not assert the concentration lemma for every positive C. Both literal tau terms and the 2*tau shifted detector are preserved.

The shifted detector mean bound uses tau<=beta/4. Its final variance bound also consumes tau<=1/2 and uses the centered L2 triangle inequality; it does not assume the two quadratic forms independent. Chebyshev is for each fixed hard-family A, whereas the 0.01 algorithmic pass probability is averaged over the random input.

source-gaps.json preserves abbreviated eventual-cutoff bookkeeping, the spectral-polynomial detector bridge, and uncited matrix Bernstein provenance. These are visible source boundaries, not claims that an inconsistent theorem was found.

No sealed target was available. No proof graph edges, Lean implementation, proof, build, source-fidelity approval, or self-review is included. Phase 2 must preserve this freeze and begin only after the exact sealed target projection is supplied. A distinct reviewer must reread the raw source and challenge topology.

The exposure disclosure records the ambient parent steering, opening broad filename-list exposure, Section 4.4 source exposure, and irrelevant bibliography-ID probe. Read it before assessing independence.
'''
(OUT/'README.md').write_text(readme)
shutil.copyfile(ROOT/'finalize_phase1.py',OUT/'finalize_phase1.py')

# Verify every inventory and selected-region exact raw locator before freezing.
inventory=json.loads((OUT/'inventory.json').read_text())
for row in inventory['records']:
    b=M['RAW'][row['start_byte']:row['end_byte_exclusive']]
    assert len(b)==row['length']
    assert hashlib.sha256(b).hexdigest()==row['sha256']
scope=json.loads((OUT/'scope-and-raw-locators.json').read_text())
for row in scope['regions']:
    b=M['RAW'][row['start_byte']:row['end_byte_exclusive']]
    assert b==(OUT/row['raw_path']).read_bytes()
assert (OUT/'source.raw.html').read_bytes()==M['RAW']
files=[]
for path in sorted(OUT.rglob('*')):
    if path.is_file() and path.name not in ['SHA256SUMS','freeze.json']:
        b=path.read_bytes()
        files.append({'path':str(path.relative_to(OUT)), 'length':len(b),'sha256':hashlib.sha256(b).hexdigest()})
save('artifact-manifest.json',files)
files.append({'path':'artifact-manifest.json','length':(OUT/'artifact-manifest.json').stat().st_size,
              'sha256':hashlib.sha256((OUT/'artifact-manifest.json').read_bytes()).hexdigest()})
sums=''.join(x['sha256']+'  '+x['path']+'\n' for x in sorted(files,key=lambda x:x['path']))
(OUT/'SHA256SUMS').write_text(sums)
freeze={'status':'FROZEN_SOURCE_FIRST_PHASE1','source_sha256':M['EXPECTED'],
        'sha256sums_sha256':hashlib.sha256(sums.encode()).hexdigest(),
        'inventory_sha256':hashlib.sha256((OUT/'inventory.json').read_bytes()).hexdigest(),
        'run_manifest_sha256':hashlib.sha256((OUT/'run-manifest.json').read_bytes()).hexdigest(),
        'exposure_disclosure_sha256':hashlib.sha256((OUT/'exposure-disclosure.json').read_bytes()).hexdigest(),
        'target_projection_seen':False,'proof_graph_edges_built':False,'self_approval':False,
        'read_only_policy':'All Phase 1 regular files mode 0444 and directories mode 0555 after writing freeze. No later edits; Phase 2 must be separate.'}
save('freeze.json',freeze)
for path in sorted(OUT.rglob('*'), key=lambda p:len(p.parts),reverse=True):
    path.chmod(0o555 if path.is_dir() else 0o444)
OUT.chmod(0o555)
for script in ['extract_raw_source.py','build_phase1.py','finalize_phase1.py']:
    (ROOT/script).chmod(0o444)
print(json.dumps({'freeze':freeze,'freeze_sha256':hashlib.sha256((OUT/'freeze.json').read_bytes()).hexdigest(),
                  'files':len(files)+2,'phase1_path':str(OUT)},indent=2))
