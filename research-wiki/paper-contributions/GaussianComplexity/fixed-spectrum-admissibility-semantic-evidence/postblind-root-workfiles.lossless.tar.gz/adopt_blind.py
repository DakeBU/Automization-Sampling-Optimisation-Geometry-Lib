from pathlib import Path
import json,hashlib,sys,shutil
sys.path.insert(0,'tools');import astis_semantic_roundtrip as rt
b=Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-admissibility-semantic-evidence');n=Path('.astis/semantic-neutral-20261108/d6a1c703');d=n/'decoded-918537'
rawsha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sha=lambda s:hashlib.sha256(s.encode()).hexdigest()
canon=lambda x:sha(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')))
def put(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
pkt=json.loads((n/'input.json').read_bytes());assert pkt==json.loads((b/'decoder-input.json').read_bytes()) and canon({k:v for k,v in pkt.items() if k!='packet_sha256'})==pkt['packet_sha256']=='255d9aa7729ef4ab791199024074f21618ce2d1b3fa28648d8d29d2ab8729285'
assert rawsha(n/'input.json')=='a83392e166b7fc40cb0abf052f5acc8c8a93f128b714cd637156e85fe42fa933'
assert rawsha(d/'decoded.json')=='c5e75307da7e5ac4b6a93e217f9a12e7cd46e80029ee20bd22c7cebde100a0e8'
assert rawsha(d/'independent-run.json')=='3349cabb596d3544a2cc3cfcb28f5df8fae8889ad04bb3740f2ba59ae05091b3'
assert rawsha(d/'output-canonical.json')==sys.argv[1] and rawsha(d/'projection-manifest.json')==sys.argv[2]
x=json.loads((d/'output-canonical.json').read_bytes());original=json.loads((d/'decoded.json').read_bytes())
assert x['decoder']=='/root/decode_918537' and x['source_text_visible'] is False and x['packet_sha256']==pkt['packet_sha256'] and x['input_artifacts']==pkt['input_artifacts'] and x['decoder_run_sha256']==rawsha(d/'independent-run.json') and sha(x['reconstructed_theorem_text'])==x['reconstructed_text_sha256']=='205efbc539703ab9e8cf408f24e9d3b56524ff428cf24bc1dc38b147a225c731'
assert all(x[k]==v for k,v in original.items())
copy=b/'blind-918537';copy.mkdir(exist_ok=False)
for p in [n/'input.json',*[p for p in d.iterdir() if p.is_file()]]:
 shutil.copy2(p,copy/p.name);assert (copy/p.name).read_bytes()==p.read_bytes()
ap=Path('research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-admissibility.json');a=json.loads(ap.read_bytes());assert a['state']=='draft' and rt.decoder_packet(a)==pkt
a['reconstruction']={'text':x['reconstructed_theorem_text'],'text_sha256':x['reconstructed_text_sha256'],'decoder':x['decoder'],'decoder_run_sha256':x['decoder_run_sha256'],'decoder_packet_sha256':x['packet_sha256'],'source_text_visible':False,'lean_statement_sha256':a['lean']['statement_sha256'],'input_artifacts':x['input_artifacts'],'run_artifact':str(copy/'output-canonical.json')};a['state']='blind-reconstructed';put(ap,a);assert rt.decoder_packet(a)==pkt
phase1=b/'fresh-source-reader-742806/phase1';m=json.loads((phase1/'manifest.json').read_bytes());assert rawsha(phase1/'manifest.json')=='146f481aaf35414e07619113050d547e8a75c85da2d868571f7f4a19c05fa50c'
for row in m['files']:assert rawsha(phase1/row['path'])==row['sha256']
selective={'schema_version':1,'stage':'SELECTIVE_SOURCE_VS_BLIND_COMPARISON_BEFORE_FULL_CANONICAL_MODULE_CONTEXT','input_scope':'Only actual anonymous statement/approved definition contexts and genuine independent blind reconstruction. No proof/module/authored publication context/previous verdicts or repairs.','anonymous_decoder_packet':pkt,'blind_reconstruction':x,'provenance':{'actual_neutral_input_path':str(n/'input.json'),'neutral_input_raw_sha256':rawsha(n/'input.json'),'exact_decoder_result_raw_sha256':rawsha(d/'output-canonical.json'),'exact_decoder_run_raw_sha256':rawsha(d/'independent-run.json'),'original_decoder_raw_sha256':rawsha(d/'decoded.json'),'schema_projection_only':True,'copied_artifacts_lossless':True}}
put(b/'phase2-selective-input.json',selective)
put(b/'blind-adoption-receipt.json',{'independent_actor':x['decoder'],'actual_neutral_input':str(n/'input.json'),'all_raw_canonical_statement_context_output_run_hashes_verified':True,'canonical_hash_excludes_self_field':True,'phase1_raw_first_freeze_verified':rawsha(phase1/'manifest.json'),'currentstate':a['state'],'selective_input_raw_sha256':rawsha(b/'phase2-selective-input.json'),'source_review':'pending','root_source_verdict_created':False})
print(json.dumps({'state':a['state'],'selective_input_raw_sha256':rawsha(b/'phase2-selective-input.json'),'reconstruction_sha256':x['reconstructed_text_sha256'],'sourceV':False}))
