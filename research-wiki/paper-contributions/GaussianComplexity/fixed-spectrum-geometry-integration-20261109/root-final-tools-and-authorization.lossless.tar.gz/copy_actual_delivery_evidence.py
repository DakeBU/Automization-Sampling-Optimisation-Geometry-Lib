from pathlib import Path
import gzip,hashlib,json,shutil,subprocess
P=Path('.astis/huanjian-gc-fixed-spectrum-geometry-integration-20261109')
B=Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-geometry-integration-20261109')
facts=json.loads((P/'actual-prebrowser-facts-v1.json').read_bytes())
sha=lambda b:hashlib.sha256(b).hexdigest()
dump=lambda x:(json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode()
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==facts['accepted_immutable_core']=='b3581af0fc7e517e6cf5b883f4af064ddaa72aa2'
assert not subprocess.check_output(['git','diff','HEAD','--name-only']).strip()
checks=B/'actual-core8-checks';checks.mkdir()
rows={}
for role,ref in facts['actual_checks_before_browser'].items():
    q=Path(ref['path']);raw=q.read_bytes();assert sha(raw)==ref['sha256'];r=json.loads(raw)
    assert r['exit_code']==0 and r['head_before']==r['head_after']==facts['accepted_immutable_core']
    log=Path(r['log']).read_bytes();assert sha(log)==r['log_sha256']
    (checks/q.name).write_bytes(raw);z=checks/(Path(r['log']).name+'.gz');z.write_bytes(gzip.compress(log,mtime=0));assert gzip.decompress(z.read_bytes())==log
    rows[role]={'original_receipt':ref,'public_receipt':str(checks/q.name),'raw_log_sha256':sha(log),'public_log_gzip':str(z),'elapsed_seconds_actual':r['elapsed_seconds']}
for key,name in [('actual_gate','actual-current-lean-gate.json'),('site_metadata','actual-site-metadata.json')]:
    q=Path(facts[key]['path']);assert sha(q.read_bytes())==facts[key]['sha256'];(B/name).write_bytes(q.read_bytes())
source=P/'independent-reader/browser/live-20261109T023719009047Z'
rp=source/'report.json';assert sha(rp.read_bytes())=='303524312bf5933ed8746ea2730d73d53e21e1255cf86c25386e3d80461fb997'
r=json.loads(rp.read_bytes());assert r['status']=='passed' and len(r['screenshots'])==44 and len(r['native_selection_geometry'])==12
dest=B/'actual-browser-v1-originals';dest.mkdir();(dest/'report.json').write_bytes(rp.read_bytes())
for row in r['screenshots']:
    raw=(source/row['file']).read_bytes();assert sha(raw)==row['sha256'];(dest/row['file']).write_bytes(raw)
    assert (dest/row['file']).read_bytes()==raw
bp=Path('.astis/huanjian-resume-20261103/20261109T023702713942Z-geometry-final-browser-v1.receipt.json')
br=json.loads(bp.read_bytes());log=Path(br['log']).read_bytes();assert br['exit_code']==0 and sha(log)==br['log_sha256']
(checks/bp.name).write_bytes(bp.read_bytes());(checks/(Path(br['log']).name+'.gz')).write_bytes(gzip.compress(log,mtime=0))
for name in ['actual-prebrowser-facts-v1.json','root-browser-execution-authorization-v1.json',
    'root-actual-browser-context-review-v1.json','root-original44-hash-and-dimensions.json','root-actual-original8-review.json']:
    (B/name).write_bytes((P/name).read_bytes())
src=P/'independent-reader/actual-browser-context-v1';dst=B/'actual-browser-context-v1';assert not dst.exists();shutil.copytree(src,dst)
for q in src.rglob('*'):
    if q.is_file():assert (dst/q.relative_to(src)).read_bytes()==q.read_bytes()
(B/'actual-delivery-evidence-manifest.json').write_bytes(dump({
    'scope':'Actual same-core8gates and executed approvedChrome44originals only. Independent44pixel acceptance/local acceptance/normalpark/remote/purification/Goal completion remain separate.',
    'immutable_core':facts['accepted_immutable_core'],'source_digest':facts['source_digest'],
    'actual_eight_same_core_checks':rows,'actual_browser_receipt':str(checks/bp.name),
    'actual_browser_report':str(dest/'report.json'),'actual_browser_report_sha256':sha(rp.read_bytes()),
    'all44_original_PNG_hashes_and_copy_bytes_verified':True,'actual12_native_geometry_rows':True,
    'root_actually_opened8_review_sha256':sha((P/'root-actual-original8-review.json').read_bytes()),
    'independent44pixel_acceptance':'pending separate report; script PASS not pixels',
    'local_acceptance_or_normalpark_or_new_source_verdict':False}))
print(json.dumps({'actual8gates_public_copied':True,'approvedChrome_actual44originals_public_copied':True,
    'root_actual8review_copied':True,'independent44pixels':'pending','source_and_shared_files_unchanged':True}))
