import Tests.GaussianComplexityFixedSpectrumGridAlias
import Lean

open Lean Elab Command
open scoped BigOperators

namespace IndependentSourceReview82a91d

def expressionConstants (e : Expr) (acc : Std.HashSet Name := {}) : Std.HashSet Name :=
  match e with
  | .const n _ => acc.insert n
  | .app f a => expressionConstants a (expressionConstants f acc)
  | .lam _ t b _ => expressionConstants b (expressionConstants t acc)
  | .forallE _ t b _ => expressionConstants b (expressionConstants t acc)
  | .letE _ t v b _ => expressionConstants b (expressionConstants v (expressionConstants t acc))
  | .mdata _ e => expressionConstants e acc
  | .proj _ _ e => expressionConstants e acc
  | _ => acc

def constantBody? : ConstantInfo → Option Expr
  | .defnInfo d => some d.value
  | .thmInfo d => some d.value
  | .opaqueInfo d => some d.value
  | _ => none

def dependencies (ci : ConstantInfo) : Std.HashSet Name :=
  let names := expressionConstants ci.type
  match constantBody? ci with
  | some body => expressionConstants body names
  | none => names

partial def recursiveClosure (env : Environment) (todo : List Name)
    (seen : Std.HashSet Name := {}) : Std.HashSet Name :=
  match todo with
  | [] => seen
  | n :: rest =>
    if seen.contains n then recursiveClosure env rest seen
    else
      match env.find? n with
      | none => recursiveClosure env rest (seen.insert n)
      | some ci => recursiveClosure env ((dependencies ci).toList ++ rest) (seen.insert n)

def hasText (s t : String) : Bool := (s.splitOn t).length > 1

def isGenerated (n : Name) : Bool := hasText n.toString "_proof_"

def isASTIS (n : Name) : Bool :=
  n.toString.startsWith "AutoSamplingTheory." || hasText n.toString "_private.Tests."

partial def publicASTISFrontier (env : Environment) (root : Name) (todo : List Name)
    (seen : Std.HashSet Name := {}) (parents : Std.HashSet Name := {})
    (expanded : Std.HashSet Name := {}) : Std.HashSet Name × Std.HashSet Name :=
  match todo with
  | [] => (parents, expanded)
  | n :: rest =>
    if seen.contains n then publicASTISFrontier env root rest seen parents expanded
    else
      let seen := seen.insert n
      if n != root && isASTIS n && !isGenerated n then
        publicASTISFrontier env root rest seen (parents.insert n) expanded
      else if n == root || isGenerated n then
        match env.find? n with
        | some ci => publicASTISFrontier env root ((dependencies ci).toList ++ rest)
            seen parents (expanded.insert n)
        | none => publicASTISFrontier env root rest seen parents expanded
      else publicASTISFrontier env root rest seen parents expanded

def isAxiom : ConstantInfo → Bool
  | .axiomInfo _ => true
  | _ => false

elab "auditTargets82a91d" : command => do
  let env ← getEnv
  let publicName := `AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumGridAlias.actual_midpoint_grid_cosine_alias
  let privateMatches := env.constants.toList.filter fun pair =>
    pair.1.toString.endsWith ".actual_weighted_inverse_grid_alias_series"
  unless privateMatches.length == 1 do throwError "expected one private target, found {privateMatches.length}"
  let privateName := privateMatches.head!.1
  logInfo m!"PRIVATE_TARGET {privateName}"
  for (n, expected) in [(publicName, `IndependentSourceReview82a91d.expectedProducerType),
                         (privateName, `IndependentSourceReview82a91d.expectedConsumerType)] do
    let some ci := env.find? n | throwError "missing target {n}"
    let some ei := env.find? expected | throwError "missing expected type {expected}"
    let some expectedType := constantBody? ei | throwError "expected type body unavailable"
    let typesMatch ← liftTermElabM do Meta.isDefEq ci.type expectedType
    unless typesMatch do throwError "literal type mismatch for {n}"
    logInfo m!"LITERAL_TYPE_MATCH {n}: true"
    logInfo m!"ACTUAL_TYPE {n}: {ci.type}"
    let closure := recursiveClosure env [n]
    let ax := closure.toList.filter fun k => (env.find? k).any isAxiom
    let astis := closure.toList.filter isASTIS
    logInfo m!"RECURSIVE_CLOSURE_COUNT {n}: {closure.size}"
    logInfo m!"RECURSIVE_AXIOMS {n}: {ax}"
    logInfo m!"RECURSIVE_ASTIS_CONSTANTS {n}: {astis}"
    if closure.contains `sorryAx then throwError "sorryAx in recursive closure"
    for a in ax do
      unless [``propext, ``Classical.choice, ``Quot.sound].contains a do
        throwError "unexpected axiom {a}"
    let (parents, expanded) := publicASTISFrontier env n [n]
    logInfo m!"PUBLIC_ASTIS_FRONTIER_AFTER_AUX_EXPANSION {n}: {parents.toList}"
    for localName in expanded.toList do
      if localName != n then
        let some li := env.find? localName | throwError "missing local generated constant"
        logInfo m!"GENERATED_AUX_TYPE {localName}: {li.type}"
        logInfo m!"GENERATED_AUX_BODY {localName}: {constantBody? li}"
        logInfo m!"GENERATED_AUX_DIRECT_CONSTANTS {localName}: {(dependencies li).toList}"
  logInfo m!"AUDIT_COMPLETE all actual literal types, recursive axioms, and generated-auxiliary expansion checked"


def expectedProducerType : Prop :=
∀ {d : ℕ} (hd : 2 ≤ d) (k : ℤ),
  let θ : Fin d → ℝ := fun i => ((i.val : ℝ) + 1 / 2) * Real.pi / (d : ℝ)
  (∑ i : Fin d, Real.cos ((k : ℝ) * θ i)) =
    (d : ℝ) * (if (2 * (d : ℤ)) ∣ k then
      (-1 : ℝ) ^ (k / (2 * (d : ℤ))) else 0)


def expectedConsumerType : Prop :=
∀ {d : ℕ} (hd : 2 ≤ d)
    {κ : ℝ} (hκ : 2 ≤ κ) (n : ℕ) (hn : 1 ≤ n) (hnd : n < d),
  let θ : Fin d → ℝ := fun i => ((i.val : ℝ) + 1 / 2) * Real.pi / (d : ℝ)
  let eigenvalue : Fin d → ℝ := fun i => (κ + 1) / 2 + (κ - 1) / 2 * Real.cos (θ i)
  let r : ℝ := (Real.sqrt κ - 1) / (Real.sqrt κ + 1)
  let a : ℤ → ℝ := fun k =>
    if (2 * (d : ℤ)) ∣ k then (-1 : ℝ) ^ (k / (2 * (d : ℤ))) else 0
  Summable (fun j : ℕ => (-r) ^ (j + 1) *
    (a (((j + 1 : ℕ) : ℤ) - (n : ℤ)) +
      a (((j + 1 : ℕ) : ℤ) + (n : ℤ)))) ∧
  (∑ i : Fin d, Real.cos ((n : ℝ) * θ i) / eigenvalue i) =
    ((d : ℝ) / Real.sqrt κ) * ∑' j : ℕ, (-r) ^ (j + 1) *
      (a (((j + 1 : ℕ) : ℤ) - (n : ℤ)) +
        a (((j + 1 : ℕ) : ℤ) + (n : ℤ)))


auditTargets82a91d

end IndependentSourceReview82a91d

#print axioms AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumGridAlias.actual_midpoint_grid_cosine_alias
