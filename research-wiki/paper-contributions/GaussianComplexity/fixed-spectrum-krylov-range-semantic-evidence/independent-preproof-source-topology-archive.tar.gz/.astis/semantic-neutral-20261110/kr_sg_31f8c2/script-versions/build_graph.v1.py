from audit_raw import ROOT, load_source, pin, dump, readable
from collections import Counter
import json

b,s,p=load_source()
sections=[next(n for n in p.nodes if n['id']==x) for x in ['S4.SS1','S4.SS2','A3.SS2']]
inside=lambda n:any(a['start']<=n['start'] and n['end']<=a['end'] for a in sections)
ns=[n for n in p.nodes if inside(n)]
byid={n['id']:n for n in ns if n['id']}
nodes=[]; edges=[]
def N(i,kind,statement,anchors=(),needed=(),context=(),note=''):
    nodes.append({'id':i,'kind':kind,'statement':statement,'source_ids':list(anchors),'necessary_conditions':list(needed),'standing_context_not_automatically_a_necessary_parent':list(context),'note':note,'evidence_status':'source-reconstruction-only; no Lean check or target fidelity judgment'})
def E(i,consumer,parents,use,discharge='unconditional pointwise algebra under the stated object definitions'):
    edges.append({'id':i,'consumer':consumer,'operator':'AND','parents':list(parents),'consumer_use_source_ids':list(use),'conditional_premises_and_discharge':discharge,'truth_contract':'source-level mathematical dependency; not a Lean dependency'})

N('HF.grid','source-definition','d integer >=2, kappa>=2; theta_i=(i-1/2)pi/d, lambda_i=(kappa+1)/2+(kappa-1)cos(theta_i)/2, Lambda=diag(lambda_i), i=1..d.', ['S4.SS1.p1','S4.E11'])
N('HF.experiment','source-context','O is Haar orthogonal and independent of private randomness; A=O Lambda O^T; f_A=x^T A x/2; pi_A=N(0,A^-1); spectrum and normalizing constant known, eigenbasis hidden.',['S4.SS1.p1','S4.SS1.p2'])
N('K.definition','source-definition','K_q=span{Lambda^j g_a: a=1..q+1,j=0..q}; supplied g_a lie in R^d.',['S4.Ex10','S4.SS2.SSS0.Px1.p2'])
N('K.output-context','internal-paper-result-outside-proof-scope','Lemma4.3: for integer q>=0 with 2q+1<d, independent g_a~N(0,I_d) can represent O^T X in K_q almost surely; coefficients of degree<=q may depend on extended experiment.',['S4.Thmtheorem3','S4.SS2.SSS0.Px1.p3'],note='Appendix C.1 not read as a selected section; this result is an application-context leaf, not proved here.')
N('D.definition','source-definition','n=2q+1; D_n=diag(cos(n theta_i)), i=1..d.',['S4.Ex12'])
N('tau.definition','source-definition','One absolute C>0 defines tau=C[(q+1)sqrt(log d/d)+(q+1)(q+1+log d)log d/d].',['S4.Ex13'])
N('L44.statement','source-anchor-context','There exists one absolute C>0 such that for all admissible d,q and independent standard Gaussian g_a, if tau<=1/2 then with probability >=.99 every u in K_q satisfies |u^T D_n u|<=2tau ||u||^2.',['S4.Thmtheorem4'])
N('C2.features','source-definition','r=q+1; t_i[0]=1, t_i[j]=sqrt(2)cos(j theta_i) for j=1..q; gamma_i[a]=(g_a)_i. B row i=d^-1/2(gamma_i tensor t_i)^T, B:R^(r^2)->R^d.',['A3.SS2.p1','A3.Ex85'],needed=['d>0 for the displayed nonzero normalization'],context=['d>=2,kappa>=2,q>=0,2q+1<d'])
N('G.rows-law','standard-probability-representation-leaf','Independent vectors g_a~N(0,I_d) imply that the row vectors gamma_i are independent N(0,I_r).',['A3.SS2.p1'],needed=['standard Gaussian product coordinates','independence of starting vectors'])
N('E.chebyshev','external-uncited-representation-leaf','cos(j theta)=T_j(cos theta); T_0=1 and T_j has degree j with nonzero leading coefficient 2^(j-1) for j>=1.',['A3.SS2.p3.m3'],note='Invoked source identity and standard degree fact; no external document read, no claim of in-slice proof.')
N('C5.polynomials','representation-conversion','P_j(x)=T_j((2x-(kappa+1))/(kappa-1)) has degree j and nonzero leading coefficient; cos(j theta_i)=P_j(lambda_i).',['A3.SS2.p3'],needed=['kappa-1 !=0'],context=['2q+1<d and Gaussianity are not used'])
N('E.triangular','external-uncited-linear-algebra-leaf','An invertible triangular coefficient transformation with nonzero diagonal preserves the span of an evaluated finite family; no evaluated-vector independence is required.',['A3.SS2.p3'])
N('C5.span-conversion','algebraic-span-step','For every a, span{((g_a)_i cos(j theta_i))_i:0<=j<=q}=span{Lambda^j g_a:0<=j<=q}; joining all a preserves equality.',['A3.SS2.p3'],needed=['polynomial coefficient matrix triangular with nonzero diagonal'],context=['g_a may be arbitrary deterministic vectors'])
N('E.range-columns','definition-conversion-leaf','The range of a finite real matrix equals the span of its columns; multiplying individual columns by nonzero real scalars preserves that span.',['A3.SS2.p3'],note='Representation/definition conversion, not a source hypothesis.')
N('C5.columns','algebraic-column-normalization','Column (a,j) of B is d^-1/2 eta_j ((g_a)_i cos(j theta_i))_i, eta_0=1, eta_j=sqrt(2) for j>=1; every factor is nonzero.',['A3.SS2.p1','A3.SS2.p3'],needed=['d>0','sqrt(2)!=0'])
N('C5.range','focal-source-component','range(B)=K_q for every supplied family g_a under the source definitions.',['A3.Ex86','A3.SS2.p3','S4.SS2.SSS0.Px2.p2'],needed=['nonconstant affine lambda-cos relation','nonzero column normalizations'],context=['no Gaussianity, independence, probability event, tau bound or full column rank required'])
N('E.trig','external-uncited-trigonometric-leaf','Sine subtraction/telescoping; sin(k pi)=0 for integer k; sin(k pi/(2d))!=0 for integer 0<|k|<2d; cosine product-to-sum and |cos|<=1.',['A3.SS2.p4','A3.SS2.p5','A3.SS2.p7','A3.SS2.p8'])
N('C5.cos-sum','internal-paper-step','For integer k, 0<|k|<2d implies sum_i cos(k theta_i)=0; the zero-frequency sum is d.',['A3.SS2.p4','A3.EGx5'],needed=['specified midpoint grid','integer nonzero frequency with |k|<2d'])
N('C5.feature-gram','internal-paper-step','sum_i t_i t_i^T=d I_r, after treating coordinate0 separately and using product-to-sum on positive coordinates.',['A3.SS2.p5','A3.EGx6','A3.Ex90'],needed=['positive frequencies j+k<=2q<2d','difference zero exactly when j=k'])
N('C5.feature-weighted','internal-paper-step','sum_i cos(n theta_i)t_i t_i^T=0; triple-product frequencies n+-j+-k lie in [1,4q+1] subset (0,2d).',['A3.SS2.p7','A3.Ex96','A3.EGx8'],needed=['n=2q+1','2q+1<d','0<=j,k<=q'])
N('C5.feature-norm','internal-paper-step','||t_i||^2=1+2 sum_{j=1}^q cos^2(j theta_i)<=1+2q<=2r.',['A3.SS2.p8','A3.Ex102'])
N('E.gaussian-second','external-uncited-probability-leaf','E[gamma_i gamma_i^T]=I_r with finite coordinate second moments.',['A3.SS2.p6'])
N('E.gram-expectation','representation-conversion-leaf','B^T W B=(1/d)sum_i w_i(gamma_i gamma_i^T tensor t_i t_i^T) for diagonal W; finite entrywise expectation and Kronecker linearity apply.',['A3.SS2.p6','A3.SS2.p7'])
N('C5.gram-expectation','internal-paper-step','E[B^T B]=I_(r^2).',['A3.SS2.p6','A3.EGx7'])
N('C5.weighted-expectation','internal-paper-step','E[B^T D_n B]=0.',['A3.SS2.p7','A3.EGx9'])
N('C5.aggregate','source-fact','Fact C.5 asserts range equality, two matrix expectations, feature norm, feature Gram, and weighted feature cancellation.',['A3.Thmtheorem5','A3.Ex86','A3.Ex87'])
N('E.gaussian-tail','external-uncited-probability-leaves','For standard gamma in R^r, E exp(||gamma||^2/3)=3^(r/2), E||gamma||^2=r; exponential Markov, tail integration and union bound are applicable.',['A3.SS2.p10','A3.SS2.p11'])
N('C6.truncation','internal-paper-step','L=2r+3log(1000d), R_i=||gamma_i||^2. P(all R_i<=L)>=.999 and E[R_i 1_(R_i>L)]<=(L+3)/(1000d).',['A3.SS2.p10','A3.SS2.p11','A3.EGx10'])
N('E.radial','external-uncited-symmetry-leaf','Rotational/sign symmetry of a radial Gaussian truncation gives E[gamma gamma^T 1_(R<=L)]=a I_r, a=E[R1_(R<=L)]/r.',['A3.SS2.p12'],needed=['radial indicator','r>=1'])
N('C6.bias','internal-paper-step','Y_i=(1/d)(gamma_i gamma_i^T tensor t_i t_i^T)1_(R_i<=L) are independent; 0<=a<=1, 1-a<=(L+3)/(1000rd); sum E Y_i=aI, weighted sum E Y_i=0.',['A3.SS2.p12','A3.Ex107','A3.Ex108','A3.Ex109','A3.Ex110'])
N('C6.norm-bound','internal-paper-step','Z_i=Y_i-EY_i and cos(n theta_i)Z_i obey operator norm <=R*=2r(L+1)/d.',['A3.SS2.p13','A3.Ex111','A3.Ex112'])
N('E.gaussian-fourth','external-uncited-moment-leaf','E[R_i gamma_i gamma_i^T]=(r+2)I_r: sign symmetry kills off diagonals and diagonal fourth moment is 3+(r-1).',['A3.SS2.p14','A3.Ex113'])
N('E.psd','external-uncited-matrix-leaves','Rank-one square formulas, Kronecker positivity, positive-semidefinite expectation monotonicity, and E Z_i^2=E Y_i^2-(E Y_i)^2 <= E Y_i^2.',['A3.SS2.p14','A3.Ex114','A3.Ex118'])
N('C6.variance','internal-paper-step','Both centered sequences have variance parameter <=v*=2r(r+2)/d, from sum E Y_i^2<=v* I and cos^2<=1.',['A3.SS2.p14','A3.EGx11','A3.Ex119','A3.Ex120'])
N('E.bernstein','external-uncited-analytic-result','Independent centered self-adjoint m by m matrices, each norm<=R*, with variance parameter<=v*, satisfy P(||sum Z_i||op>t)<=2m exp(-t^2/[2(v*+R*t/3)]) for t>0. Here m=r^2.',['A3.SS2.p15','A3.Ex121'],note='Named bounded two-sided matrix Bernstein invoked without an in-slice bibliographic citation; not proved in this payload.')
N('C6.bernstein-application','internal-paper-step','Apply the bounded two-sided matrix Bernstein inequality to Z_i and cos(n theta_i)Z_i, each of dimension r^2.',['A3.SS2.p15'],needed=['independent, centered, self-adjoint','norm and variance bounds'])
N('C6.threshold','internal-paper-step','z=log(1000r^2), Delta=sqrt(2v*z)+2R*z/3; Delta^2-2z(v*+R*Delta/3)>=0; each failure <=.002 and simultaneous centered bounds hold with probability>=.996.',['A3.SS2.p16','A3.Ex122','A3.Ex123','A3.Ex124'])
N('C6.untruncate','internal-paper-step','On T, B^T B-I=sum Z_i-(1-a)I and B^T D_n B=sum cos(n theta_i)Z_i. Intersection gives probability>=.995 and bounds Delta+(1-a),Delta.',['A3.SS2.p17','A3.Ex125','A3.Ex126'])
N('C6.simplify','internal-paper-bookkeeping','2q+1<d implies d>=2,2r<=d; z=O(log d),L+3=O(r+log d),r+2<=3r; one absolute C dominates Delta+(1-a) by tau.',['A3.SS2.p18','A3.EGx12'],note='Source suppresses an absolute numerical constant; no extra theorem premise may replace this estimate.')
N('C6.event','source-fact','For sufficiently large universal C, one event of probability>=.995 satisfies ||B^T B-I||op<=tau AND ||B^T D_n B||op<=tau.',['A3.Thmtheorem6','A3.Ex103','A3.Ex129'])
N('C2.witness','focal-representation-conversion','For every u in K_q, there exists c in R^(r^2) with u=Bc; that same c is available for both quadratic expressions.',['A3.SS2.p19.m3','A3.SS2.p19.m4'],needed=['K_q subset range(B)'],note='No uniqueness or full column rank required; reverse range inclusion alone is insufficient.')
N('E.coefficient-algebra','external-uncited-elementary-linear-algebra-leaf','For real B,D,c and u=Bc, ||u||^2=c^T B^T Bc and u^T D u=c^T B^T D Bc by Euclidean norm, transpose product and associativity.',['A3.SS2.p19','A3.EGx13'],note='Exact identities require no distribution, tau estimate, D symmetry, or rank assumption.')
N('C2.energy-equality','focal-exact-algebra','For the selected witness u=Bc, ||u||^2=c^T B^T Bc.',['A3.Ex130','A3.Ex130.m1','A3.Ex130.m2'])
N('C2.form-equality','focal-exact-algebra','For the same witness u=Bc, u^T D_n u=c^T B^T D_n Bc, so their absolute values agree.',['A3.Ex131','A3.Ex131.m1','A3.Ex131.m2'])
N('E.quad-norm','external-uncited-operator-norm-leaf','For a real operator H, |c^T Hc|<=||H||op ||c||^2; hence ||B^T B-I||op<=tau gives c^T B^T Bc>=(1-tau)||c||^2.',['A3.SS2.p19'])
N('C2.energy-bound','internal-paper-step','On the Gram event, ||u||^2>=(1-tau)||c||^2 for the chosen witness.',['A3.Ex130.m2'])
N('C2.form-bound','internal-paper-step','On the weighted event, |u^T D_n u|<=tau||c||^2 for the same witness.',['A3.Ex131.m2'])
N('C2.finish','internal-paper-step','Since tau<=1/2, 1-tau>=1/2>0; obtain |u^T D_n u|<=tau/(1-tau)||u||^2<=2tau||u||^2 simultaneously for every u in K_q; probability>=.995>=.99.',['A3.SS2.p19','A3.Ex132'],needed=['same coefficient in both bounds','tau<=1/2','one event uniform in all c'])
N('C2.output-application','application-context','Lemma4.3 plus Lemma4.4 on its event and orthogonality of O give |X^T O D_n O^T X|<=2tau||X||^2.',['S4.SS2.SSS0.Px2.p3','S4.Ex15'])

E('e-polynomial','C5.polynomials',['HF.grid','E.chebyshev'],['A3.SS2.p3'],'kappa>=2 from hard-family standing context discharges kappa-1!=0.')
E('e-span','C5.span-conversion',['C5.polynomials','E.triangular'],['A3.SS2.p3'])
E('e-columns','C5.columns',['C2.features'],['A3.SS2.p3'],'d>=2 gives nonzero d^-1/2 and sqrt(2)!=0; t[0]=1 is treated separately.')
E('e-range','C5.range',['K.definition','C5.span-conversion','C5.columns','E.range-columns'],['A3.SS2.p3'])
E('e-cos-sum','C5.cos-sum',['HF.grid','E.trig'],['A3.SS2.p4'],'The source explicitly restricts the integer frequency to 0<|k|<2d, so the sine divisor is nonzero.')
E('e-feature-gram','C5.feature-gram',['C2.features','C5.cos-sum','E.trig'],['A3.SS2.p5'],'Standing 2q+1<d yields the required positive sum and nonzero difference frequency ranges; j=k zero mode contributes d.')
E('e-feature-weighted','C5.feature-weighted',['C2.features','D.definition','C5.cos-sum','E.trig'],['A3.SS2.p7'],'Explicit check 1<=n-j-k<=n+-j+-k<=4q+1<2d discharges every triple-product frequency condition.')
E('e-feature-norm','C5.feature-norm',['C2.features','E.trig'],['A3.SS2.p8'])
E('e-gram-mean','C5.gram-expectation',['E.gaussian-second','E.gram-expectation','C5.feature-gram'],['A3.SS2.p6'],'Standard Gaussian second moments are finite; finite matrix expectations and sums require no limiting argument.')
E('e-weighted-mean','C5.weighted-expectation',['E.gaussian-second','E.gram-expectation','C5.feature-weighted'],['A3.SS2.p7'])
E('e-C5-aggregate','C5.aggregate',['C5.range','C5.gram-expectation','C5.weighted-expectation','C5.feature-norm','C5.feature-gram','C5.feature-weighted'],['A3.Thmtheorem5'])
E('e-tail','C6.truncation',['G.rows-law','E.gaussian-tail'],['A3.SS2.p10','A3.SS2.p11'],'d>=2,r>=1 make all thresholds finite; tail integral converges by the exponential bound.')
E('e-bias','C6.bias',['C6.truncation','E.radial','C5.feature-gram','C5.feature-weighted','G.rows-law'],['A3.SS2.p12'],'The indicator depends only on each row radius and the row laws are identical, so the scalar a is common; independence is preserved under separate rowwise truncations.')
E('e-norm-bound','C6.norm-bound',['C6.bias','C5.feature-norm','E.trig'],['A3.SS2.p13'],'R_i<=L on the truncated summand; 0<=a<=1; absolute cosine weights <=1.')
E('e-variance','C6.variance',['G.rows-law','E.gaussian-fourth','E.psd','C5.feature-norm','C5.feature-gram','C6.bias'],['A3.SS2.p14'],'All fourth moments exist; remove the indicator only in a PSD expression; cos^2<=1 transfers the variance bound.')
E('e-Bernstein','C6.bernstein-application',['E.bernstein','G.rows-law','C6.bias','C6.norm-bound','C6.variance'],['A3.SS2.p15'],'Rowwise independence, centering by definition of Z, symmetry of outer products and Kronecker products, and deterministic real cosine weights supply the named inequality hypotheses.')
E('e-threshold','C6.threshold',['C6.bernstein-application'],['A3.SS2.p16'],'r>=1 gives z>0; the displayed nonnegative expansion gives the exponent bound, and a union bound combines two failures without requiring their independence.')
E('e-untruncate','C6.untruncate',['C6.threshold','C6.truncation','C6.bias'],['A3.SS2.p17'],'On T every indicator equals1. Union bound costs .001+.004; the weighted mean is exactly zero and the unweighted mean is aI.')
E('e-simplify','C6.simplify',['C6.untruncate','tau.definition'],['A3.SS2.p18'],'Integer q>=0 and 2q+1<d yield 2r<=d and d>=2; choose one absolute C>=c after absolute logarithmic estimates.')
E('e-C6','C6.event',['C6.untruncate','C6.simplify'],['A3.Thmtheorem6','A3.SS2.p19'],'The same C is chosen sufficiently large once, as allowed by the source existential absolute constant.')
E('e-witness','C2.witness',['C5.range','E.range-columns'],['A3.SS2.p19.m4'],'Given u in K_q, equality of ranges supplies a coefficient; this uses K_q subset range(B).')
E('e-energy-equality','C2.energy-equality',['C2.witness','E.coefficient-algebra'],['A3.Ex130.m2'],'Use exactly the witness with u=Bc. No event or tau assumption is used in the equality.')
E('e-form-equality','C2.form-equality',['C2.witness','E.coefficient-algebra','D.definition'],['A3.Ex131.m2'],'Use the same witness; taking absolute values preserves exact equality. No event is used in this equality.')
E('e-energy-bound','C2.energy-bound',['C2.energy-equality','C6.event','E.quad-norm'],['A3.Ex130.m2'],'On the simultaneous C6 event, apply the unweighted operator bound to the chosen c.')
E('e-form-bound','C2.form-bound',['C2.form-equality','C6.event','E.quad-norm'],['A3.Ex131.m2'],'On the same C6 event, apply the weighted operator bound to the same c.')
E('e-finish','C2.finish',['C2.energy-bound','C2.form-bound','tau.definition'],['A3.Ex132','A3.SS2.p19'],'The source condition tau<=1/2 gives a strictly positive denominator; both inequalities hold for every c on one event, and .995>=.99.')
E('e-L44','L44.statement',['C2.finish'],['A3.SS2.p19'])
E('e-output','C2.output-application',['K.output-context','L44.statement','HF.experiment'],['S4.SS2.SSS0.Px2.p3'],'Apply the uniform estimate to O^T X on the probability-one representation event; O orthogonal preserves norm and transposes give the conjugated quadratic.')

graph={'schema':'source-only-proof-graph-phase1-v1','source_sha256':'6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915','author_role':'independent source extractor, blinded to target signatures and implementation','review_status':'extractor proposal; distinct topology review pending','nodes':nodes,'and_hyperedges':edges,'or_routes':[],'or_route_explanation':'The selected source gives one range-conversion route and one concentration-to-uniform-estimate route. Span inclusions and the two quadratic bounds are conjunctive components, not alternatives.','not_parent_edges':[{'consumer':'C5.range','not_parents':['C6.event','C5.gram-expectation','C5.weighted-expectation','G.rows-law','K.output-context'],'reason':'Range conversion is deterministic polynomial/column-span algebra.'},{'consumer':'C2.energy-equality and C2.form-equality','not_parents':['C6.event','tau<=1/2','full column rank','unique coefficient'],'reason':'Exact substitution identities hold for any witness u=Bc.'},{'consumer':'C6.event','not_parents':['C5.range','K.output-context'],'reason':'Concentration uses deterministic feature moment identities and Gaussian rows, not the kappa-dependent basis conversion.'}],'source_gaps':[{'scope':'external leaves','status':'exposed, not proved in this payload','description':'Standard Chebyshev degree, finite-dimensional algebra, Gaussian moment facts, probability inequalities, and bounded matrix Bernstein are invoked/explained leaves. Bernstein has no bibliography citation at its use site; no claim of its in-slice derivation.'},{'scope':'constant simplification','status':'explicit bookkeeping expansion obligation','description':'The source suppresses a universal numerical constant in the O(log d) simplification; the graph retains its use and conditions rather than treating a desired estimate as a premise.'}]}
dump('source-graph.json',graph)

owner={
'S4.SS1.p1':['HF.grid','HF.experiment'],'S4.SS1.p2':['HF.experiment'],
'S4.SS2.SSS0.Px1.p1':['K.output-context'],'S4.SS2.SSS0.Px1.p2':['K.definition'],'S4.Thmtheorem3.p1':['K.output-context'],'S4.SS2.SSS0.Px1.p3':['K.output-context'],
'S4.SS2.SSS0.Px2.p1':['D.definition'],'S4.Thmtheorem4.p1':['L44.statement','tau.definition'],'S4.SS2.SSS0.Px2.p2':['C5.range'],'S4.SS2.SSS0.Px2.p3':['C2.output-application'],
'A3.SS2.p1':['C2.features','G.rows-law'],'A3.SS2.p2':['C5.range','C2.energy-equality','C2.form-equality'],'A3.Thmtheorem5.p1':['C5.aggregate'],
'A3.SS2.p3':['C5.range','C5.span-conversion'],'A3.SS2.p4':['C5.cos-sum'],'A3.SS2.p5':['C5.feature-gram'],'A3.SS2.p6':['C5.gram-expectation'],'A3.SS2.p7':['C5.feature-weighted','C5.weighted-expectation'],'A3.SS2.p8':['C5.feature-norm'],
'A3.SS2.p9':['C6.event'],'A3.Thmtheorem6.p1':['C6.event'],'A3.SS2.p10':['C6.truncation'],'A3.SS2.p11':['C6.truncation'],'A3.SS2.p12':['C6.bias'],'A3.SS2.p13':['C6.norm-bound'],'A3.SS2.p14':['C6.variance'],'A3.SS2.p15':['C6.bernstein-application','E.bernstein'],'A3.SS2.p16':['C6.threshold'],'A3.SS2.p17':['C6.untruncate'],'A3.SS2.p18':['C6.simplify'],'A3.SS2.p19':['C2.witness','C2.energy-equality','C2.form-equality','C2.energy-bound','C2.form-bound','C2.finish']}
excluded={
'S4.Thmtheorem2.p1':'Remark4.2 comparison, oracle-affine relation and eventual lower-bound mechanism are fully read context outside the focal C5 range/coefficient algebra; no necessary parent edge.',
'S4.SS2.p1':'Overview of four lemmas; navigation/context only, with each mathematical lemma separately inventoried.',
'S4.SS2.SSS0.Px3.p1':'Target-statistic transition outside the focal algebra; target law is not a parent of range equality or coefficient substitution.',
'S4.Thmtheorem5.p1':'Lemma4.5 target moments and variance are outside this scope; complete statement read for context, no use in the focal deterministic algebra.',
'S4.Thmtheorem5.p2':'Lemma4.5 target-mean ratio bound is outside this scope and not a parent of the focal algebra.',
'S4.SS2.SSS0.Px3.p2':'Target rotation and moment application outside this scope; no necessary parent edge to the focal algebra.',
'S4.SS2.SSS0.Px4.p1':'Admissibility transition outside this scope; no necessary parent edge.',
'S4.Thmtheorem6.p1':'Lemma4.6 admissibility outside this scope; positive-definiteness is not required by the focal algebra.'}
overrides={
'S4.E11':['HF.grid'],'S4.Ex10':['K.definition'],'S4.Ex11':['K.output-context'],'S4.Ex12':['D.definition'],'S4.Ex13':['tau.definition'],'S4.Ex14':['L44.statement'],'S4.Ex15':['C2.output-application'],
'A3.Ex85':['C2.features'],'A3.Ex86':['C5.range','C5.gram-expectation','C5.weighted-expectation'],'A3.Ex87':['C5.feature-norm','C5.feature-gram','C5.feature-weighted'],
'A3.Ex130':['C2.energy-equality','C2.energy-bound'],'A3.Ex131':['C2.form-equality','C2.form-bound'],'A3.Ex132':['C2.finish'],'A3.Ex129':['C6.event']}
coverage=[]
for n in ns:
    if not n['id']:continue
    rec=pin(n,s);match=None;refs=None;reason=None
    for pre,ids in overrides.items():
        if n['id']==pre or n['id'].startswith(pre+'.'):refs=ids;match=pre;break
    if refs is None:
        owners=[x for x in owner if byid[x]['start']<=n['start'] and n['end']<=byid[x]['end']]
        ex=[x for x in excluded if byid[x]['start']<=n['start'] and n['end']<=byid[x]['end']]
        if owners:match=min(owners,key=lambda x:byid[x]['end']-byid[x]['start']);refs=owner[match]
        elif ex:match=min(ex,key=lambda x:byid[x]['end']-byid[x]['start']);reason=excluded[match]
        elif n['id'] in ['S4.Thmtheorem3','S4.Thmtheorem4','A3.Thmtheorem5','A3.Thmtheorem6']:
            refs={'S4.Thmtheorem3':['K.output-context'],'S4.Thmtheorem4':['L44.statement'],'A3.Thmtheorem5':['C5.aggregate'],'A3.Thmtheorem6':['C6.event']}[n['id']];match=n['id']
        elif n['id'].startswith('S4.Thmtheorem5') or n['id'].startswith('S4.Thmtheorem6') or n['id'].startswith('S4.Thmtheorem2'):
            reason='Theorem/remark container or title of explicitly excluded contextual comparison, target moments or admissibility; substantive descendants independently covered.'
        else:reason='Section/proof/title or typographical container; carries no additional substantive claim beyond individually inventoried descendants.'
    if refs is not None:rec.update(disposition='NODE',node_ids=refs,assignment_basis=match)
    else:rec.update(disposition='EXCLUDED',reason=reason,assignment_basis=match)
    coverage.append(rec)

anonymous=[]
for n in ns:
    cl=n['attrs'].get('class','')
    if 'ltx_cite' in cl.split():
        rec=pin(n,s);rec['locator']='anonymous-cite:'+str(n['start']);rec['raw_id']=None;rec['readable_derived']=readable(s[n['start']:n['end']])
        rec['disposition']='NODE' if n['start']>byid['S4.SS2']['start'] else 'EXCLUDED'
        if rec['disposition']=='NODE':rec['node_ids']=['K.output-context'];rec['classification']='external citation [22,Lemma9.2], contextual output theorem source, not used for focal algebra'
        else:rec['reason']='Construction/comparison provenance citation [22,Section9.2] or [22]; context not a necessary focal algebra parent.'
        anonymous.append(rec)
dump('coverage.json',{'schema':'complete-id-dispositions-phase1-v1','source_sha256':graph['source_sha256'],'scope_ids':['S4.SS1','S4.SS2','A3.SS2'],'records':coverage,'anonymous_citations':anonymous,'coverage_status':'mechanically exhaustive IDs, extractor-authored mathematical dispositions, independent topology review pending'})

# Source content cannot inherit a NODE by mere proximity: every mathematical,
# paragraph, and table element must have a semantic owner or explicit context exclusion.
ids={n['id'] for n in ns if n['id']};covids={x['id'] for x in coverage};assert ids==covids and len(ids)==len(coverage)
nodeids={n['id'] for n in nodes}
for rec in coverage:
    assert rec['disposition'] in ['NODE','EXCLUDED']
    if rec['disposition']=='NODE':assert rec['node_ids'] and set(rec['node_ids'])<=nodeids
    else:assert rec['reason']
    if rec['tag'] in ['math','p','table']:
        assert rec['assignment_basis'] is not None or rec['id'].startswith(('S4.Thmtheorem2','S4.Thmtheorem5','S4.Thmtheorem6'))
for e in edges:
    assert e['consumer'] in nodeids and set(e['parents'])<=nodeids
    assert set(e['consumer_use_source_ids'])<=ids
for n in nodes:assert set(n['source_ids'])<=ids
todo={n['id']:set() for n in nodes}
for e in edges:todo[e['consumer']].update(e['parents'])
seen=set()
while True:
    new={i for i,ps in todo.items() if ps<=seen}-seen
    if not new:break
    seen|=new
assert seen==nodeids,'cycle in proposed source graph'
summary={'id_elements':len(coverage),'math_elements':sum(x['tag']=='math' for x in coverage),'block_math_elements':sum(x['tag']=='math' and x['display']=='block' for x in coverage),'inline_math_elements':sum(x['tag']=='math' and x['display']=='inline' for x in coverage),'paragraph_divs':sum('ltx_para' in (x['class'] or '').split() for x in coverage),'paragraph_p_elements':sum(x['tag']=='p' for x in coverage),'tables':sum(x['tag']=='table' for x in coverage),'equation_tables':sum(x['tag']=='table' and 'ltx_equation' in (x['class'] or '').split() for x in coverage),'equationgroup_tables':sum(x['tag']=='table' and 'ltx_equationgroup' in (x['class'] or '').split() for x in coverage),'tbody_display_row_ids':sum(x['tag']=='tbody' for x in coverage),'anonymous_citations':len(anonymous),'dispositions':dict(Counter(x['disposition'] for x in coverage)),'nodes':len(nodes),'and_hyperedges':len(edges),'or_routes':0,'missing_ids':[],'source_graph_is_acyclic':True,'not_mathematical_approval':'These counts and structural checks certify inventory bookkeeping only.'}
dump('coverage-summary.json',summary)
print(json.dumps(summary,indent=2))
