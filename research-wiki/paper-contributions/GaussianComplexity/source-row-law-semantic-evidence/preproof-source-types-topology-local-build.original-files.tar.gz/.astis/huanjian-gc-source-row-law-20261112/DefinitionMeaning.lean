import Mathlib
open MeasureTheory ProbabilityTheory

#print MeasureTheory.MeasurePreserving
#print MeasureTheory.Measure.pi
#print EuclideanSpace
#print WithLp.toLp
#print ProbabilityTheory.stdGaussian
#print Measurable
#print MeasurableSpace.pi
#print ENNReal.ofReal
#print Real.toNNReal
#check EuclideanSpace.real_norm_sq_eq

variable (d q : ℕ)
#synth IsProbabilityMeasure (stdGaussian (EuclideanSpace ℝ (Fin d)))
#synth SigmaFinite (stdGaussian (EuclideanSpace ℝ (Fin d)))
#synth IsProbabilityMeasure
  (Measure.pi (fun _ : Fin (q + 1) => stdGaussian (EuclideanSpace ℝ (Fin d))))
