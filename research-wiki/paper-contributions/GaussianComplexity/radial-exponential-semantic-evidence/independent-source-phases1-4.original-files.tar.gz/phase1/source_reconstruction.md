# Independent source reconstruction

Huanjian Zhou and Taiji Suzuki, *On Complexity of Gaussian Sampling*, arXiv:2610.20492v1, Appendix C.2. Workspace-relative original HTML at `.astis/huanjian-resume-20261103/2610.20492v1.html`. The original has 951991 bytes and SHA-256 `6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915`. All locators below are original HTML element or MathML IDs. The executable extraction and its output identify the original line ranges, byte ranges and digests.

## Standing setup and the two row objects

Fix ambient dimension \(d\) and integer \(q\ge 0\) with \(2q+1<d\), and take \(g_1,\ldots,g_{q+1}\) independent with law \(N(0,I_d)\) on \(\mathbb R^d\) (Lemma 4.4, `S4.Thmtheorem4.p1.1`). The section's hard family has \(d\ge 2\), \(\kappa\ge 2\), and the deterministic grid \(\theta_i=(i-\tfrac12)\pi/d\) (`S4.E11.m1`). The integer constraint implies \(d\ge 2\) and \(2(q+1)\le d\). Appendix C.2 sets \(r=q+1\) and \(n=2q+1\) (`A3.SS2.p1.m1`, `A3.SS2.p1.m2`). For each \(1\le i\le d\), set

\[
 \gamma_i=((g_1)_i,\ldots,(g_r)_i)^\top,\qquad
 t_i=(1,\sqrt 2\cos(\theta_i),\ldots,\sqrt 2\cos(q\theta_i))^\top.
\]

The coordinate conventions are \(a=1,\dots,r\) for the Gaussian starts and \(j=0,\dots,q\) for the cosine basis. Its constant entry at \(j=0\) is \(1\), and its entries for \(j\ge 1\) have factor \(\sqrt 2\). Both \(\gamma_i,t_i\) lie in \(\mathbb R^r\) (`A3.Ex85.m1`). Within any \(\gamma_i\), the \(r\) coordinates are independent one-dimensional standard Gaussians. Across different \(i\), the \(\gamma_i\) are independent \(N(0,I_r)\) vectors, by independence of the entries of each identity-covariance Gaussian start and independence across the starts (`A3.SS2.p1.2`, `A3.SS2.p1.m4–m5`). All expectations and probabilities in the excerpt use the law of these starts or the induced row law.

The actual \(i\)-th row of \(B\in\mathbb R^{d\times r^2}\) is \(d^{-1/2}(\gamma_i\otimes t_i)^\top\) (`A3.SS2.p1.m6–m8`). Its coordinate \((a,j)\) is \(d^{-1/2}(\gamma_i)_a(t_i)_j\). The row as a column has covariance \(d^{-1}(I_r\otimes t_it_i^\top)\), and its squared norm is \(d^{-1}\|t_i\|^2\|\gamma_i\|^2\). These are consequences of the row formula. The source radial variable \(R_i\) below is the squared Euclidean norm of \(\gamma_i\), with \(r\) summands and no ambient-dimension or cosine normalization. The covariance of the target Gaussian, the hidden rotation, the cosine weights and the condition \(\tau_{d,q}\le\tfrac12\) from the parent lemma play no role in the scalar moment and tail. The scalar argument uses the standard marginal law, and the simultaneous estimate also uses the number \(d\) of rows.

## Exact scalar assertions

Under the setup, put \(R_i=\|\gamma_i\|^2=\sum_{a=1}^r(\gamma_i)_a^2\) and \(L=2r+3\log(1000d)\), using the natural logarithm (`A3.SS2.p10.m1–m2`). For each \(i\) the paper uses the ordinary finite expectation

\[
 \mathbb E\!\left[\exp(R_i/3)\right]=3^{r/2}.
\]

This is the exact assertion at `A3.SS2.p10.m3`. The exponent \(r/2\) is real division. For every real \(x\ge 0\) and each such \(i\), the displayed chain at `A3.Ex104.m1` is

\[
 \mathbb P\!\left(R_i>2r+3x\right)
 \ \le\ \exp\!\left(\frac r2\log 3-\frac{2r}{3}-x\right)
 \ \le\ e^{-x}.
\]

The event is a strict upper tail, the two comparisons are non-strict, and \(x=0\) is included (`A3.SS2.p10.m4`). The final comparison uses \(\tfrac12\log 3<\tfrac23\) (`A3.SS2.p10.m5`). The all-rows event is

\[
 \mathcal T=\bigcap_{i=1}^d\{R_i\le L\},
 \qquad
 \mathbb P(\mathcal T)\ge 1-\frac d{1000d}=\frac{999}{1000}=0.999.
\]

The same cutoff \(L\) applies to each row, and equality with \(L\) is retained. The anchors are `A3.Ex105.m1` and `A3.SS2.p10.m6`. These assertions concern the actual law, exact constants and a single joint event.

## Mathematical background compressed in the paper

The paragraph states the exponential moment and invokes Markov's inequality. It gives the logarithm comparison but omits its proof and the detailed Gaussian integration and union-bound steps. The following supplies that background.

Write \(Z\sim N(0,1)\) with density \(\varphi_1(z)=(2\pi)^{-1/2}e^{-z^2/2}\). For a real exponent \(\lambda<1/2\), let \(b=1-2\lambda>0\). The tilted integrand satisfies

\[
 e^{\lambda z^2}\varphi_1(z)
  =(2\pi)^{-1/2}e^{-bz^2/2}
  =b^{-1/2}\varphi_{1/b}(z),\qquad
 \varphi_v(z)=(2\pi v)^{-1/2}e^{-z^2/(2v)}.
\]

Here \(v\) is the variance. This integrates to \(b^{-1/2}\). Equivalently, the substitution \(y=\sqrt b\,z\) contributes the factor \(1/\sqrt b\) to the standard normalized Gaussian integral. At \(\lambda=1/3\), \(b=1/3\), the residual Gaussian has variance \(3\) and standard deviation \(\sqrt 3\), and the one-coordinate exponential moment is \(\sqrt 3\). Independence and finite product integration of the nonnegative factors give

\[
 \mathbb E\exp(\lambda R_i)=\prod_{a=1}^r\mathbb E\exp\!\bigl(\lambda(\gamma_i)_a^2\bigr)
  =(1-2\lambda)^{-r/2},\qquad
 \mathbb E\exp(R_i/3)=(\sqrt 3)^r=3^{r/2}.
\]

The variable-parameter identity is an auxiliary reconstruction. The paper uses only the fixed \(\lambda=1/3\) instance here. In chi-square terminology the degrees of freedom are \(r\). For \(r>0\), the equivalent density is \(u^{r/2-1}e^{-u/2}/(2^{r/2}\Gamma(r/2))\) on \(u>0\), which gives the same tilt factor by changing the rate from \(1/2\) to \(1/2-\lambda\). Coordinate product integration already supplies the exact equality.

To obtain the first comparison, the strict event can be written as \(\{\exp(R_i/3)>\exp(2r/3+x)\}\), by strict monotonicity of the exponential. The random variable is nonnegative, measurable and integrable by the moment calculation, and the threshold \(\exp(2r/3+x)\) is positive. The pointwise Markov bound gives

\[
 \mathbb P(R_i>2r+3x)
 \le e^{-2r/3-x}\mathbb E e^{R_i/3}
 =\exp\!\left(\tfrac r2\log 3-\tfrac{2r}{3}-x\right).
\]

For the second comparison, \(e^{4/3}\ge 1+\tfrac43+\tfrac12(\tfrac43)^2=\tfrac{29}{9}>3\), so \(\log 3<4/3\). As \(r\ge 0\), the deterministic factor \(\exp(r(\tfrac12\log 3-\tfrac23))\) is at most one.

Finally, \(d\ge 2\) ensures \(x=\log(1000d)\ge 0\). Substituting it into the single-row tail gives \(\mathbb P(R_i>L)\le 1/(1000d)\). The complement of \(\mathcal T\) is the union of the \(d\) strict upper-tail events. Finite subadditivity gives \(\mathbb P(\mathcal T^c)\le d/(1000d)=1/1000\). This step uses marginal tail bounds and holds for any coupling of the \(d\) rows with those marginals. Independence within a row matters for the product derivation of its moment. Independence across rows is explicit source setup and is subsequently used for independent truncated matrix summands.

## Endpoints and scope

- The source includes \(q=0\), so \(r=1\), \(n=1\), \(t_i=(1)\), \(\gamma_i=((g_1)_i)\), and the exponential moment equals \(\sqrt 3\). The case \(d=2,q=0\) is admissible. For the all-rows probability alone \(d\ge 1\) suffices. For the single-row statements any positive integer \(r\) with the stated marginal law suffices.
- The stated \(x\) range is \([0,\infty)\), including the threshold \(2r\) when \(x=0\). Markov and the displayed deterministic comparison in fact remain valid for real \(x\) because the exponential threshold stays positive. The source range is the bounded reconstruction. The source cutoff convention keeps the \(\le L\) event and uses the strict \(>L\) complement.
- The product identity's auxiliary range includes \(\lambda=0\), where it equals \(1\), and all negative \(\lambda\). At \(\lambda=1/2\), the one-coordinate tilted integrand is constant and has infinite integral, and at \(\lambda>1/2\) it grows. Hence for positive \(r\) there is no finite extension at or above \(1/2\). If the ambient product is independently extended to \(r=0\), the zero-dimensional law is a unit mass on the empty vector, \(R_i=0\), and the actual exponential moment is \(1\) for every \(\lambda\). The fixed moment and \(x\ge0\) tail hold in that degenerate case, including the empty strict event at \(x=0\). In the paper \(r=q+1\ge 1\), and the downstream factor \(1/r\) relies on that positivity.
- The variable \(x\) is quantified per row, while \(\mathcal T\) is a simultaneous event in the same experiment. Constants \(2,3,1000,0.999\) and the moment parameter \(1/3\) are absolute. The row moment depends on \(r\), the cutoff depends on \(r,d\), and there is no \(n,\kappa,\tau_{d,q}\), covariance-estimation error or concentration constant in either scalar assertion.

## First consumers and coverage boundary

1. `A3.SS2.p11.m1–m2` and `A3.Ex106.m1–m2` consume the single-row tail with \(x=\log(1000d)+s/3\) for real \(s\ge 0\), obtaining \(\mathbb P(R_i>L+s)\le e^{-s/3}/(1000d)\). The \(s=0\) case is the single-row bound at the cutoff. The displayed bias bound follows from
   \[
   \mathbb E[R_i\,\mathbf1_{\{R_i>L\}}]
   =L\,\mathbb P(R_i>L)+\int_0^\infty\mathbb P(R_i>L+s)\,ds
   \le \frac{L+3}{1000d}.
   \]
   The identity expands \(R_i\mathbf1_{R_i>L}=L\mathbf1_{R_i>L}+(R_i-L)_+\) and uses the nonnegative tail integral. The term \(3\) is the integral of \(e^{-s/3}\).
2. `A3.Ex107–Ex110` use this bound for the independent truncated matrices \(Y_i=d^{-1}(\gamma_i\gamma_i^\top\otimes t_it_i^\top)\mathbf1_{\{R_i\le L\}}\). The scalar \(a=r^{-1}\mathbb E[R_i\mathbf1_{\{R_i\le L\}}]\) is shared by the identical row marginals. The radial symmetry identity is \(\mathbb E[\gamma_i\gamma_i^\top\mathbf1_{\{R_i\le L\}}]=aI_r\). Coordinate sign flips eliminate off-diagonal terms, permutations equate the diagonals, and the trace fixes the coefficient. From \(\mathbb ER_i=r\), the paper obtains \(0\le a\le 1\) and \(1-a\le (L+3)/(1000rd)\). Fact C.5 supplies the deterministic cosine identities used to obtain expectations \(aI_{r^2}\) and \(0\) for the unweighted and weighted truncated sums.
3. `A3.SS2.p17.1–p17.2` and `A3.Ex125–Ex126` consume the simultaneous event \(\mathcal T\) and its error budget \(0.001\). On that event both truncated sums agree with the originals. Intersecting with the two matrix concentration events yields the paper's \(0.995\) bound, with a bias \(1-a\) only for the unweighted matrix. The matrix concentration estimates and the final uniform quadratic-form inequality of Lemma 4.4 are downstream of this scalar excerpt.

The primary source coverage is the row-law paragraph `A3.SS2.p1` and the scalar truncation paragraph `A3.SS2.p10`, including `A3.Ex104` and `A3.Ex105`. The input law and deterministic grid are standing context. The first scalar bias step and its matrix consumers identify the outgoing source edges. The cosine moment proofs, matrix Bernstein argument, and rest of Appendix C.2 remain outside this review.
