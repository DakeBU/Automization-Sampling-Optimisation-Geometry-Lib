from pathlib import Path
import sys,json,hashlib,html,re,traceback,time
from html.parser import HTMLParser
sys.dont_write_bytecode=True
ROOT=Path('/Users/zhouhuanjian/ASTIS-GC');BASE=ROOT/'.astis/semantic-neutral-20261110/src_a74f20';OUT=BASE/'phase3-reader-v2';SRC=OUT/'snapshot';SITE=OUT/'static-site'
def sha(b):return hashlib.sha256(b).hexdigest()
def save(name,o):(OUT/name).write_text(json.dumps(o,indent=2,ensure_ascii=False)+'\n')
sys.path[:0]=[str(ROOT/'tools'),str(ROOT/'website/scripts')]
import astis_site as base
import inline_lean,declaration_lessons,library_shelves,source_lineage
base.ROOT=SRC;declaration_lessons.ROOT=SRC
base._ACTIVE_GIT=base.GitContext('64922804e1f7f0927e85bb6a26aeb24d06eea6f7','64922804e1f7f0927e85bb6a26aeb24d06eea6f7','','',False,False,set())
base._ACTIVE_GATE=base.GateEvidence(False,False,'','', '',[],'Bounded independent static fixture only; native results are explicitly reused from frozen d823, not a current aggregate gate.')
relprod='AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumExactMeans.lean';reltest='Tests/GaussianComplexityFixedSpectrumExactMeans.lean'
rels=[relprod,reltest]
for stem in ['FixedSpectrumGaussianMoments','FixedSpectrumCosineExpansion','FixedSpectrumGridAlias']:
 rel='AutoSamplingTheory/ExampleCases/GaussianComplexity/'+stem+'.lean';target=SRC/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((BASE/'phase3/native-src'/rel).read_bytes());rels.append(rel)
base.project_lean_paths=lambda:[SRC/x for x in rels]
_,decls=base.scan_project_sources();base._SOURCE_BY_NAME={d.full_name:d for d in decls}
packet=json.loads((OUT/'canonical-reviewer-packet.json').read_text())
unit=json.loads((SRC/'website/content/declaration_lessons/huanjian-fixed-spectrum-exact-means.json').read_text())['units'][0]
old=json.loads((BASE/'phase3/native-src/website/content/declaration_lessons/huanjian-fixed-spectrum-exact-means.json').read_text())['units'][0]
packet_lesson=packet['candidate_publication_context']['lesson']
assert all(unit.get(k)==v for k,v in packet_lesson.items())
assert set(unit)-set(packet_lesson)=={'boundary'} and unit['boundary']==old['boundary']
prod=(SRC/relprod).read_text();test=(SRC/reltest).read_text()
step_records=[]
for index,(s,oldstep) in enumerate(zip(unit['steps'],old['steps']),1):
 code=s['lean'];owner=reltest if index==6 else relprod;source=test if index==6 else prod
 start=source.find(code)
 row={'step':index,'source':owner,'code_sha256':sha(code.encode()),'code_bytes':len(code.encode()),'exact_contiguous_source':start>=0,'unique_occurrence':source.count(code)==1,'first_line':None if start<0 else source[:start].count('\n')+1,'full_Test_file':index==6 and code==test,'title_text_formula_unchanged':all(s[k]==oldstep[k] for k in ['title','text','formula']),'previous_correspondence_prose_preserved_in_detail':s.get('detail','').startswith(oldstep['lean'])}
 assert row['exact_contiguous_source'] and row['unique_occurrence'] and row['title_text_formula_unchanged'] and row['previous_correspondence_prose_preserved_in_detail']
 if index==6:assert row['full_Test_file'] and row['code_bytes']==4155 and row['code_sha256']=='d30744e67541fa07729002f06fde01f84a4fa1984b6f24d1014285db50ccc696'
 step_records.append(row)
save('step-literal-source-checks.json',step_records)

class Node:
 def __init__(self,tag='',attrs=()):self.tag=tag;self.attrs=dict(attrs);self.children=[]
 def text(self):return ''.join(c if isinstance(c,str) else c.text() for c in self.children)
 def walk(self):
  yield self
  for c in self.children:
   if isinstance(c,Node):yield from c.walk()
class Parser(HTMLParser):
 def __init__(self):super().__init__(convert_charrefs=True);self.root=Node();self.stack=[self.root]
 def handle_starttag(self,t,a):
  n=Node(t,a);self.stack[-1].children.append(n)
  if t not in ['area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr']:self.stack.append(n)
 def handle_endtag(self,t):
  for i in range(len(self.stack)-1,0,-1):
   if self.stack[i].tag==t:self.stack=self.stack[:i];break
 def handle_data(self,d):self.stack[-1].children.append(d)

SITE.mkdir(parents=True,exist_ok=True)
# Deliberately small, explicit shell fixture. It exercises existing source export
# without implying a real themed site, browser, CSS, network, or aggregate gate.
fixture=SITE/library_shelves.CANONICAL_THEME_PAGE;fixture.parent.mkdir(parents=True,exist_ok=True)
fixture.write_text('<!doctype html><html><head><link rel="stylesheet" href="../assets/site.css"><link rel="stylesheet" href="../assets/information-architecture.css"></head><body><main>Controlled static theme-stack fixture; no rendered site acceptance.</main></body></html>\n')
save('static-fixture-scope.json',{'path':str(fixture.relative_to(ROOT)),'sha256':sha(fixture.read_bytes()),'purpose':'Supply only the two required canonical-theme stylesheet names to the existing source exporter. This is a controlled structural fixture, not reused/live production theme or CSS evidence.','aggregate_gate':False,'browser':False,'network':False,'fresh_native':False,'CSS_assets_loaded':False})
page='lessons/exact-means-reader-v2.html'
article=declaration_lessons.render_unit(unit,page)
target=SITE/page;target.parent.mkdir(parents=True,exist_ok=True);target.write_text(base.page(unit['title'],page,article))
declaration_lessons.export_sources(SITE,[unit])
export=SITE/('data/lesson-sources/'+reltest+'.html')
assert export.is_file()
p=Parser();p.feed(article);nodes=list(p.root.walk())
steps=[n for n in nodes if n.tag=='details' and 'proof-reader-step' in n.attrs.get('class','').split()]
assert len(steps)==6
for n,record,step in zip(steps,step_records,unit['steps']):
 codes=[x for x in n.walk() if x.tag=='code' and x.attrs.get('class')=='language-lean']
 record['rendered_exact_code_panel_count']=len(codes);record['rendered_code_equals_authored_and_source']=len(codes)==1 and codes[0].text()==step['lean']
 assert record['rendered_code_equals_authored_and_source']
 nested=[x for x in n.walk() if x.tag=='details' and x is not n]
 record['corresponding_Lean_fold_initially_closed']=len(nested)==1 and 'open' not in nested[0].attrs
 assert record['corresponding_Lean_fold_initially_closed']
save('step-literal-source-checks.json',step_records)
q=Parser();q.feed(export.read_text());pre=[n for n in q.root.walk() if n.tag=='pre'];assert len(pre)==1
exported=pre[0].text();assert exported==test
source_href='../data/lesson-sources/'+reltest+'.html#L15'
source_links=[n.attrs.get('href') for n in nodes if n.tag=='a']
details=[n for n in nodes if n.tag=='details']
formulas=[unit['formula']]+[x['formula'] for x in unit['steps']]+[x['formula'] for x in unit.get('notation',[])]
def balanced(t):
 depth=0
 for i,c in enumerate(t):
  if i and t[i-1]=='\\':continue
  if c=='{':depth+=1
  if c=='}':depth-=1
  if depth<0:return False
 return depth==0
name=unit['declaration'];decl=base._SOURCE_BY_NAME[name];signature,_=inline_lean.split_statement(inline_lean.display_source(decl.source_text));codes=[n.text() for n in nodes if n.tag=='code']
checks={
 'six_exact_step_panels':len(step_records)==6 and all(x['rendered_code_equals_authored_and_source'] for x in step_records),
 'step6_entire_unchanged_Test_bytes':step_records[-1]['full_Test_file'],
 'all_original_mathematical_prose_and_formulas_preserved':all(x['title_text_formula_unchanged'] and x['previous_correspondence_prose_preserved_in_detail'] for x in step_records),
 'all_original_non_step_non_source_lesson_fields_preserved':all(unit.get(k)==old.get(k) for k in set(unit)|set(old) if k not in ['steps','sources']),
 'original_mathematical_source_entry_preserved':unit['sources'][:-1]==old['sources'],
 'new_Test_source_entry_implementation_only':unit['sources'][-1]['path']==reltest and 'no additional mathematical source or public lemma node' in unit['sources'][-1]['scope'],
 'Test_source_link_to_existing_export_path':source_href in source_links,
 'Test_numbered_source_export_exists':export.is_file(),
 'Test_export_complete_bytes_after_HTML_unescape':exported==test,
 'Test_line15_anchor_is_private_theorem':any(n.tag=='span' and n.attrs.get('id')=='L15' and n.text().startswith('private theorem actual_gaussian_closed_means_bias_ratio') for n in q.root.walk()),
 'all_details_initially_closed':all('open' not in n.attrs for n in details),
 'exact_producer_statement_and_declaration_present':signature in codes and inline_lean.display_source(decl.source_text) in codes,
 'formulas_preserved_and_balanced':all(x in html.unescape(article) and balanced(x) for x in formulas),
 'all_assumptions_present':all(declaration_lessons.inline_text(x) in article for x in unit['assumptions']),
 'copy_download_status_hooks_present':all(x in article for x in ['data-lean-copy','data-lean-copy-status','downloads/lean/'+relprod]),
 'source_lean_fold_follows_each_formula':all(n.text().find(unit['steps'][i]['formula'])<n.text().find('Corresponding Lean step') for i,n in enumerate(steps)),
}
assert all(checks.values()),checks
tool_paths=['tools/astis_site.py','website/scripts/declaration_lessons.py','website/scripts/inline_lean.py','website/scripts/source_lineage.py','website/scripts/library_shelves.py','website/scripts/formalization_progress.py']
oldhash=json.loads((BASE/'phase3/static-reader-checks.json').read_text())['tool_hashes']
hashes={s:sha((ROOT/s).read_bytes()) for s in tool_paths};assert all(hashes[k]==v for k,v in oldhash.items())
result={'status':'PASS_EXACT_READER_REPAIR_BOUNDED_STATIC','checked_commit':'64922804e1f7f0927e85bb6a26aeb24d06eea6f7','lesson_sha256':'4252152a1df92598351878fe7a0089feebd400de30f8398f7752b19d958c69d6','checks':checks,'details_count':len(details),'formula_count':len(formulas),'rendered_lesson_sha256':sha(target.read_bytes()),'exported_Test_source_HTML_sha256':sha(export.read_bytes()),'exact_Test_source_sha256':sha(test.encode()),'tool_hashes':hashes,'shared_renderer_unchanged_from_original_review':True,'fixture_scope':'static-fixture-scope.json','original_hold_resolution':'Original missing exact Test consumer code is now present as the entire unchanged Test file in step6. Its exact numbered repository-source context is linked/exported using the established source mechanism. No Test download/new helper/public lemma/dependency claim is needed.','limits':['No fresh native builds at successor; unchanged d823 native/kernel/cache acceptance explicitly reused.','No browser/desktop/mobile/visual typesetter/CSS/site acceptance. Static preservation, fold adjacency, exact source panels and export only.','Theme fixture carries stylesheet names only; no production theme or aggregate gate claim.']}
save('static-reader-checks.json',result)
print(json.dumps(result,indent=2,ensure_ascii=False))
