# Independent source-only cognition, frozen phase 1

This is the source-graph author's reconstruction from the pinned raw paper, not a theorem proof, verification verdict, Statement Seal, implementation plan or completion certificate. The graph author has not seen any implementation Lean, statement draft/seal, other packet or graph, old semantic record, native result, ledger, model index or ATLAS material. Parent instructions identify the proposed bounded packet, but the mathematics below was reconstructed from the raw paper and checked against its actual locators.

The paper is *On Complexity of Gaussian Sampling*, Huanjian Zhou and Taiji Suzuki, arXiv:2610.20492v1. The input is 951991 bytes with SHA256 6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915. Raw byte spans and exact HTML IDs are in source_index.json; each span hash is into the original UTF-8 bytes, not BeautifulSoup reserialization. The source/*.html extracts are original contiguous bytes. The human-readable source/*.txt is secondary: MathML visual text and TeX annotation often appear twice, and it must not replace the raw HTML or exact alttext.

## What the source actually fixes

Section 4.1, S4.SS1.p1.1 and Eq. (11), assumes integer dimension d>=2 and kappa>=2 and defines theta_i=(i-1/2)pi/d for i=1,...,d, lambda_i=(kappa+1)/2+(kappa-1)cos(theta_i)/2 and Lambda=diag(lambda_i). The deterministic roots use theta only. The lambda/Lambda and kappa assumptions support the separate range/Krylov branch and do not become premises merely because they share Eq. (11)'s math ID.

Section 4.2 explicitly calls q a nonnegative integer in S4.Thmtheorem3.p1.1; S4.Thmtheorem4 uses q>=0, 2q+1<d, independent g_1,...,g_(q+1) distributed N(0,I_d), and the already defined K_q. The integer interpretation is also forced by the displayed q+1-vector family and degree/coordinate endpoints; it is not a newly invented analytic premise. C.2 inherits this setting, sets r=q+1 and n=2q+1, and defines t_i=(1,sqrt(2)cos(theta_i),...,sqrt(2)cos(q theta_i))^T. Its coordinate convention is exactly 0,...,q. The constant coordinate has scaling 1, while each positive coordinate has scaling sqrt(2). Treating every coordinate as sqrt(2)cos(j theta_i) would give a wrong (0,0) Gram entry.

The three bounded deterministic clauses of Fact C.5 are: sum_i t_i t_i^T=dI_r, sum_i cos(n theta_i)t_i t_i^T=0, and ||t_i||^2<=2r. D_n in S4.Ex12 is exactly diag(cos(n theta_1),...,cos(n theta_d)), so the weighted identity is the frame Gram with this literal high-frequency diagonal. A generic arbitrary diagonal weight is not its source meaning.

All constants here are exact: the half-grid shift 1/2; pi/d; r=q+1; n=2q+1; the constant coordinate 1; positive-coordinate factor sqrt(2); unweighted matrix dI_r; weighted matrix 0; and the row bound 2r. The intermediate norm estimate is 1+2q=2r-1, but the published conclusion is the weaker <=2r. The triple-product expansion has coefficient 1/4. B has dimension d by r^2 and has normalization d^(-1/2), yielding 1/d in its Gram. The source factor order is gamma_i tensor t_i, so a natural entry is indexed by (a,j), a=1,...,r and j=0,...,q.

The allowed endpoints include q=0. Then r=n=1, t_i=(1), the positive-coordinate Gram cases are empty, sum_i t_i t_i^T=d, the weighted identity is sum_i cos(theta_i)=0, and the row norm is 1<=2. Integer 2q+1<d implies d>=2, 2r<=d, and q<=floor((d-2)/2). Thus d=2,q=0 is included; the source does not require q>=1, d odd, d>=3, a strict concentration threshold or a logarithm bound for these identities. The endpoint 2q+1=d is excluded by the source hypotheses even though separate stronger/generalized identities could be investigated; this packet does not silently generalize the public source domain.

## Author proof topology, retaining all local frequency premises

The author first proves range(B)=K_q in A3.SS2.p3 by Chebyshev polynomials and an invertible triangular change of basis. This paragraph is an independent parallel conclusion of C.5 and is outside the current three roots. It is not a premise of their Gram computation. The source invokes cos(j theta)=T_j(cos theta), the degree j and nonzero leading coefficient, lambda being a nonconstant affine function of cos(theta), and invariance of range under nonzero column normalization. None of those range claims receives proof completion here.

The deterministic Gram route starts under the boxed expected-unweighted-Gram heading in A3.SS2.p4. For every integer k with 0<|k|<2d, A3.Ex88--89 proves

2 sin(k pi/(2d)) sum_i cos(k theta_i)
=sum_i[sin(k i pi/d)-sin(k(i-1)pi/d)]
=sin(k pi)-sin(0)=0.

The integer endpoint sine values and finite telescoping are essential. The nonzero sine factor in A3.SS2.p4.2 is essential too: 0<|k|<2d puts k pi/(2d) in (-pi,pi) except 0, so cancellation is valid. The signed interval is intentional; the later j-k frequency may be negative. At k=0, the cosine sum is d rather than 0. At |k|=2d, the sine factor vanishes and this cancellation proof cannot be used. These endpoint facts are local dependency statements, not extra root hypotheses.

A3.SS2.p5 indexes coordinates 0,...,q and first handles the constant coordinate: (0,0) sums to d, and (0,j), 1<=j<=q, sums to sqrt(2) times a zero nonzero-frequency sum. Symmetry handles (j,0). Then for 1<=j,k<=q, product-to-sum makes the entry sum the sum of the j-k and j+k cosine sums. Here 0<j+k<=2q<2d. The difference j-k is zero exactly in the diagonal case, producing d; otherwise 0<|j-k|<2d, producing 0. The author's final matrix identity relies on all entry cases and ordinary matrix extensionality. No rank argument, Gaussian property, random event or concentration is involved.

A3.SS2.p6 consumes that identity to compute the actual Gaussian expectation. This paragraph occurs before the weighted deterministic calculation; it is a downstream consumer, not a prerequisite of the weighted proof.

A3.SS2.p7 next proves the weighted route. Its exact frequency check A3.Ex96 says, for 0<=j,k<=q,

1<=n-j-k<=n +/- j +/- k<=n+j+k<=4q+1<2d.

There are four actual integers, n+j+k, n+j-k, n-j+k and n-j-k. The lower endpoint is at least (2q+1)-2q=1; the upper endpoint follows from 2q+1<d. Thus no zero frequency can arise even when j=k or a coordinate is 0. A3.Ex97--99 applies product-to-sum twice to obtain the quarter-sum of their four cosine sums and cancels every term. Each matrix entry is a constant multiple of this triple sum: use scale s_0=1, s_j=sqrt(2) when j>0, and cos(0 theta)=1. This explicitly includes the (0,0), mixed and positive-positive cases; positive-index-only reasoning would miss part of the matrix. A3.SS2.p7.3 then concludes weighted matrix 0 and only afterwards computes E[B^T D_n B]=0.

A3.SS2.p8 proves the row norm last, by the exact finite sum of squares and cos^2<=1. This branch needs no Gram orthogonality or Gaussian input. In particular the author order is range; cosine cancellation/unweighted Gram; first expectation; weighted frequency/Gram; second expectation; row norm. The graph records mathematical dependencies, not a falsely forced linear AND chain or the implementation's possible order.

## Actual Gaussian consumers and implicit dependencies

C.2 defines gamma_i=((g_1)_i,...,(g_r)_i)^T and states that these d vectors are independent N(0,I_r). This is compatible with the independent N(0,I_d) columns. For both C.5 expectation identities the only probabilistic identity used is E[gamma_i gamma_i^T]=I_r. Independence across i is not needed to take a finite sum of expectations. It becomes needed later for C.6, which is excluded.

The row formula gives B^T B=(1/d)sum_i (gamma_i gamma_i^T) tensor (t_i t_i^T). Standard Gaussian finite second moments justify entrywise expectation and pulling out all deterministic t factors. A3.Ex94--95 substitutes I_r and the unweighted deterministic Gram to get (1/d)(I_r tensor dI_r)=I_(r^2). A3.Ex100--101 has the additional deterministic factor cos(n theta_i) and uses the weighted deterministic Gram to get 0. The matrices are the actual row-defined B Grams, rather than abstract assumptions that their expectations happen to be I and 0. The source normalization and index factor order must survive any later typed overlay.

Uncited/background leaves needed by the author's displayed route are recorded explicitly: sine subtraction, sine at integer pi, nonvanishing sine in the stated interval, finite telescoping and scalar cancellation, two-cosine product-to-sum, cos(0)=1, cos^2<=1, (sqrt(2))^2=2, finite sum/norm/outer-product entry algebra, symmetry and matrix extensionality, Kronecker outer-product/identity/distributivity algebra, and Gaussian zero mean/covariance plus finite second moments. These are local mathematical obligations, not newly cited external theorems or checked Lean facts. The raw proof has no active external citation for C.5. No missing source hypothesis or source-contract gap was identified in these bounded formulas. That is the author's finding, pending independent review; it is not an accepted verdict.

Citation [22], OpenAI (2026), *Subpolynomial query complexity for well-conditioned log-concave sampling*, appears in the expanded Section 4 hard-family/deferred-rotation background. The bibliography is at bib.bib3. It supports background/excluded algorithm/range context and does not become a dependency of a cosine sum or Gaussian expectation because of proximity. No external work was opened, and no OpenAI Math implementation/intake or other forbidden source was read.

## Downstream boundary that remains open

C.6 applies the deterministic unweighted/weighted identities to truncated expectations sum_i E Y_i=aI and sum_i cos(n theta_i)E Y_i=0 (A3.Ex110). It applies the row bound in operator-norm bounds (A3.Ex111) and applies both norm and unweighted Gram in the variance estimate (A3.Ex115--117 and A3.SS2.p14.4). Its truncation tail, radial symmetry, Gaussian fourth moments, PSD inequalities, matrix Bernstein, union bounds, and asymptotic constant simplifications are all outside this packet.

For clarity, the excluded source fixes L=2r+3log(1000d), truncation event probability at least .999, R_*=2r(L+1)/d, v_*=2r(r+2)/d, z=log(1000r^2), Delta=sqrt(2v_*z)+2R_*z/3. It gets each matrix failure at most .002, their joint event at least .996, and after truncation at least .995, then absorbs bias and constants into tau_(d,q). None of these probability or absolute-C choices is needed as a binder for deterministic C.5 or its Gaussian second moments.

The full Lemma 4.4 additionally needs the excluded range identity to write u=Bc, C.6's shared event, and tau<=1/2 to turn the two matrix estimates into |u^T D_n u|<=tau/(1-tau)||u||^2<=2tau||u||^2; .995>=.99 supplies the printed probability. Its tau is C[(q+1)sqrt(log d/d)+(q+1)(q+1+log d)log d/d], with an absolute C>0. The two main results, full Lemma 4.4, C.6, Range(B)=K_q, and rotated algorithm-output consequences all remain outside the bounded completion claim. This artifact is source topology only and establishes no compiled edge at all.

## Coverage, exposure, and review handoff

The raw extraction inventories all 463 IDs in the five expanded read windows, including 227 math IDs. Every ID has exactly one NODE or EXCLUDED(reason) disposition; seven explicit semantic clauses partition the mixed Eq. (11), Ex86 and Ex87 displays, and three external citation occurrences are separately excluded. There are 473 total coverage rows. A NODE on Fact C.5 or its mixed display is a partition/coverage node, not a certificate of all six clauses. Structural/typographic duplicates and all C.6/final-lemma regions are explicitly excluded. This exhaustive inventory does not turn excluded regions into completed mathematics.

Only the allowed raw paper, the five exact protocol files, the received task, and this agent's own derived artifacts were read. Additional background was located only within the same raw paper: S4.SS1 for Eq. (11), S4.SS2.SSS0.Px1 for the Krylov definition/integer q convention, S4.SS2.SSS0.Px2 for D_n/domain/consequence context, and bib.bib3 for the nearby cited source identity. No full-repository search was performed. The initial combined protocol print and one broad ID print were output-truncated; the relevant protocol sections and in-scope math IDs were re-read in bounded successful calls. The extraction failed once due to an HTMLParser helper-name collision and succeeded after that implementation-only correction; failed script and exact traceback are preserved. These limitations do not create mathematical failure evidence.

The structural self-check only confirms unique inventory dispositions, source-ID existence, graph shape and core DAG acyclicity. A distinct reviewer must re-read raw bytes plus graph/coverage without this private cognition to accept topology. A separate global root-closure reviewer is appropriate if the eventual parent packet claims a larger source slice. A later typed overlay may read only the exact sealed types/minimal definitions supplied after this freeze. It must be a new artifact and must never modify source_graph.json, coverage.json, cognition.md or any other phase1 bytes.
