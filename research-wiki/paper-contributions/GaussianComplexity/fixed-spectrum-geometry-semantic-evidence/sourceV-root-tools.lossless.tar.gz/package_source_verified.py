from pathlib import Path
import argparse,gzip,hashlib,json,shutil,subprocess,tarfile
parser=argparse.ArgumentParser();parser.add_argument('--projection-review',required=True);args=parser.parse_args()
B=Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-geometry-semantic-evidence')
P=Path('.astis/huanjian-gc-fixed-spectrum-geometry-20261109')
V=Path('.astis/semantic-neutral-20261109/src_9a6d2f/normal-V-preparation')
X=V/'execution'
sha=lambda b:hashlib.sha256(b).hexdigest()
dump=lambda x:(json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode()
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()=='ab8b47caed9f781191f8408154cd355c7e7c104c'
assert not subprocess.check_output(['git','diff','--cached','--name-only']).strip()
assert sha((X/'execution-manifest.json').read_bytes())=='4d56c5efebdb787bf9fd71d9213259b2d5ff7f1f7ff726e217b6554ca37fe07a'
assert sha((X/'execution-payload-manifest.json').read_bytes())=='588b60f159671a3282a307f86aed6696fbbbe384a3199dba94c68619d1433558'
for row in json.loads((X/'execution-payload-manifest.json').read_bytes())['files']:
    raw=(X/row['path']).read_bytes();assert len(raw)==row['bytes'] and sha(raw)==row['sha256']
m=json.loads((X/'execution-manifest.json').read_bytes())
assert m['actor']=='/root/source_reader_9a6d2f' and m['normal_API_calls']==1
vraw=(X/'actual-V-append.raw.jsonl').read_bytes();assert sha(vraw)==m['exact_append_sha256']=='7cd55a70605e1db1c8198f5f7a2eec6dbcb62b562becf539a80a9e5c632a501c'
lp=Path('runs/substantive_advances.jsonl'); before=subprocess.check_output(['git','show','HEAD:'+str(lp)])
assert lp.read_bytes()==before+vraw and sha(lp.read_bytes())=='fc0ede4ba8ab651476231137e5077f23fdd8fc794a689571141811c3be5846f4'
ap=Path('research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-geometry.json')
cp=Path('research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-geometry.json')
assert sha(ap.read_bytes())=='a101634a005e20e54c8791cf340b871a3adf79807b75b607f422957392b0bc6c'
assert sha(cp.read_bytes())=='b040beefc7779754ff075dbd8de3c553f35d217a8923b193ebeeddcfe5465174'
review=Path(args.projection_review); r=json.loads(review.read_bytes())
assert r['reviewer']=='/root/geometry_integration_reader' and r['verdict']=='ACCEPT_EXACT_MECHANICAL_SOURCE_V_PROJECTION'
assert r['source_V_append_sha256']==sha(vraw) and r['after_sha256']==sha(cp.read_bytes())
dest=B/'original-source-verifier/normal-V-preparation';assert not dest.exists();shutil.copytree(V,dest)
for q in V.rglob('*'):
    if q.is_file():assert (dest/q.relative_to(V)).read_bytes()==q.read_bytes()
(B/'actual-source-V-append.exact.json').write_bytes(vraw)
(B/'source-V-own-frontier-projection-independent-review.json').write_bytes(review.read_bytes())
(B/'source-V-adoption-and-preservation.json').write_bytes(dump({
    'scope':'Mechanical adoption of actual original independent verifier V; root did not issue a source verdict or V.',
    'checked_candidate_commit':'ab8b47caed9f781191f8408154cd355c7e7c104c',
    'future_first_carrying_commit':'This upcoming metadata/evidence commit; not a fresh Lean build or checked candidate.',
    'source_verifier':m['actor'],'normal_API_calls':1,'exact_append_sha256':sha(vraw),
    'ledger_after_sha256':sha(lp.read_bytes()),'accepted_audit_sha256':sha(ap.read_bytes()),
    'own_cell_sha256':sha(cp.read_bytes()),'original_execution_manifest_sha256':sha((X/'execution-manifest.json').read_bytes()),
    'independent_sourceV_own_cell_projection_review_sha256':sha(review.read_bytes()),
    'foreign_state_preservation':m['foreign_state_preservation'],
    'static_only_not_root_site_browser_remote_purification_Goal_complete':True}))
checks=B/'sourceV-actual-checks';checks.mkdir()
labels=['geometry-sourceV-publication','geometry-sourceV-contributor','geometry-sourceV-semantic','geometry-sourceV-frontier']
for label in labels:
    matches=list(Path('.astis/huanjian-resume-20261103').glob('*-'+label+'.receipt.json'));assert len(matches)==1
    q=matches[0];rr=json.loads(q.read_bytes());raw=Path(rr['log']).read_bytes()
    assert rr['exit_code']==0 and sha(raw)==rr['log_sha256']
    (checks/q.name).write_bytes(q.read_bytes());(checks/(Path(rr['log']).name+'.gz')).write_bytes(gzip.compress(raw,mtime=0))
archive=B/'sourceV-root-tools.lossless.tar.gz';tools=[P/'prepare_selective_review.py',Path(__file__)]
with tarfile.open(archive,'w:gz') as t:
    for q in tools:t.add(q,arcname=q.name,recursive=False)
with tarfile.open(archive,'r:gz') as t:
    for q in tools:assert t.extractfile(q.name).read()==q.read_bytes()
(B/'sourceV-root-tools.manifest.json').write_bytes(dump({'archive':str(archive),'sha256':sha(archive.read_bytes()),'originals_retained':True,'files':[{'original':str(q),'member':q.name,'sha256':sha(q.read_bytes())} for q in tools]}))
old_wrapped=set(json.loads((B/'admission-staging-readback.json').read_bytes())['unsafe_or_ignored_raw_originals_not_staged_directly'])
old_wrapped|={x['original_path'] for x in json.loads((B/'postproof-frozen-raw-packaging/manifest.json').read_bytes())['files']}
tracked=set(subprocess.check_output(['git','ls-files','-z']).decode().split('\0'))
files=sorted(q for q in B.rglob('*') if q.is_file());safe=[];wrapped=[];pack=B/'sourceV-frozen-raw-packaging';pack.mkdir()
for q in files:
    if str(q) in old_wrapped:continue
    raw=q.read_bytes()
    if str(q) in tracked and subprocess.check_output(['git','show','HEAD:'+str(q)])==raw:continue
    ignored=subprocess.run(['git','check-ignore','-q','--',str(q)]).returncode==0
    binary=q.suffix in ['.gz','.png','.zip','.olean','.ilean'] or b'\0' in raw
    bad=not binary and (b'\r\n' in raw or raw.endswith(b'\n\n') or any(line.endswith((b' ',b'\t')) for line in raw.splitlines()))
    if ignored or bad:
        z=pack/(str(len(wrapped)).zfill(3)+'-'+q.name+'.gz');z.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(z.read_bytes())==raw
        wrapped.append({'original_path':str(q),'raw_sha256':sha(raw),'raw_bytes':len(raw),'gzip_path':str(z),'gzip_sha256':sha(z.read_bytes()),'ignored':ignored,'raw_whitespace_or_blank_EOF':bad,'original_retained_unchanged':True});safe.append(z)
    else:safe.append(q)
mp=pack/'manifest.json';mp.write_bytes(dump({'scope':'Frozen raw only is wrapped losslessly; old originals retained. Mutable canonical records staged directly.','files':wrapped}));safe.append(mp)
mutable=[lp,ap,cp];safe=sorted(set(safe+mutable))
subprocess.run(['git','add','--',*map(str,safe)],check=True)
staged=subprocess.check_output(['git','diff','--cached','--name-only','-z']).decode().strip('\0').split('\0')
assert set(staged)==set(map(str,safe))
for name in staged:assert subprocess.check_output(['git','show',':'+name])==Path(name).read_bytes(),name
subprocess.run(['git','diff','--cached','--check'],check=True)
assert Path('research-wiki/paper-contributions/GaussianComplexity/README.md').read_bytes()==subprocess.check_output(['git','show','HEAD:research-wiki/paper-contributions/GaussianComplexity/README.md'])
print(json.dumps({'staged_paths':len(staged),'new_raw_wrappers':len(wrapped),'actual_original_source_V':True,'exact_one_API_call':True,'all_staged_index_bytes_equal_live':True,'README_and_shared_paths_untouched':True,'actual_root_site_runtime_remote_purification_Goal_complete':False}))
