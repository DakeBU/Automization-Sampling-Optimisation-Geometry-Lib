from pathlib import Path
import sys,subprocess,json,datetime,hashlib,time
P=Path("/Users/zhouhuanjian/ASTIS-GC/.astis/semantic-neutral-20261111/kr_src_c47e12/phase6-metadata-link-only");label=sys.argv[1];argv=sys.argv[2:];start=datetime.datetime.now(datetime.timezone.utc).isoformat();t0=time.monotonic()
r=subprocess.run(argv,cwd='/Users/zhouhuanjian/ASTIS-GC',stdout=subprocess.PIPE,stderr=subprocess.PIPE)
(P/'audit'/(label+'.stdout')).write_bytes(r.stdout);(P/'audit'/(label+'.stderr')).write_bytes(r.stderr)
out={'label':label,'argv':argv,'cwd':'/Users/zhouhuanjian/ASTIS-GC','started_utc':start,'ended_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'elapsed_seconds':time.monotonic()-t0,'exit_code':r.returncode}
for k,b in [('stdout',r.stdout),('stderr',r.stderr)]:out[k]={'path':label+'.'+k,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
(P/'audit'/(label+'.receipt.json')).write_text(json.dumps(out,indent=2)+'\n')
sys.stdout.buffer.write(r.stdout);sys.stdout.buffer.flush();sys.stderr.buffer.write(r.stderr);sys.stderr.buffer.flush();raise SystemExit(r.returncode)

