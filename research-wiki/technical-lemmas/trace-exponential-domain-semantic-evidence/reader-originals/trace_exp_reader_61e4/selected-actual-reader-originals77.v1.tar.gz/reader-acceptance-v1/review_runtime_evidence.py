"""Independent read-only custody/measurement review of an already completed browser run. Never launches a browser."""
import datetime as dt
import hashlib
import json
import math
import os
from pathlib import Path
import struct
import sys
import time
import traceback

OUT=Path(__file__).resolve().parent
OWN=OUT.parent
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def load(p):return json.loads(Path(p).read_text())
def main():
    checks=[]
    def check(name,ok,detail=None):
        checks.append({'name':name,'pass':bool(ok),'detail':detail})
        if not ok:raise AssertionError(name)
    rp=OWN/'actual-result.json';ap=OWN/'execution-assignment.json';receipt_path=OWN/'runtime-process/receipt.json'
    r=load(rp);a=load(ap);receipt=load(receipt_path);notes=load(OUT/'visual-review-notes.json')
    check('exact-original-result',sha(rp)=='17654105a8a14921e275ba90191df0ab125a297b7a94032155eab08b577d27c2')
    check('exact-authorized-assignment',sha(ap)=='4712040efee18f87c7b9ed77b7e2c7acf22b84b55fb5d592c53bbd303e659725')
    check('exact-runner-and-geometry',sha(OWN/'browser_check.py')==a['runner_sha256']=='478e1e0bab4c4dfef37d69bd9b7a670065671545851607b56c0984a9cac37de6' and sha(OWN/'browser_geometry.py')==a['geometry_sha256']=='ab0acbd15849263974ba4ee9a9b85c88d35c779c8e99e78b9376b0456ca6eba0')
    check('actual-runtime-exit0-not-reconstructed',receipt['actual_exit_code']==0 and receipt['exception'] is None and receipt['actual_OS_fd1_fd2_until_exit'] and receipt['actual_result_sha256']==sha(rp) and receipt['assignment_sha256']==sha(ap))
    for key in ['stdout','stderr']:
        p=OWN/receipt[key]['path'];check('original-fd-'+key+'-unchanged',p.stat().st_size==receipt[key]['bytes'] and sha(p)==receipt[key]['sha256'])
    stdout=load(OWN/'runtime-process/stdout.raw')
    check('original-stdout-matches-result',stdout['checks']==len(r['checks'])==389 and stdout['actual_PNGs']==len(r['screenshots'])==36 and stdout['false_checks']==[] and stdout['actual_result_sha256']==sha(rp))
    check('runtime-reports-no-failed-checks',all(c['pass'] for c in r['checks']))
    prep=load(OWN/'preparation-selected-originals.manifest.json')
    check('all17-preparation-original-leaves-unchanged',len(prep['files'])==17 and all(sha(OWN/row['path'])==row['sha256'] for row in prep['files']))
    check('static-PATH-failure-retained',load(OWN/'static-process/receipt.json')['actual_exit_code']==1 and load(OWN/'static-process-v2/receipt.json')['actual_exit_code']==0)
    check('all10-frozen-input-leaves-unchanged',len(a['frozen_inputs'])==10 and all(sha(x['path'])==x['sha256'] for x in a['frozen_inputs']))
    preview=Path(a['preview_root']);manifest=load(preview/'preview-freeze-manifest.json');fixture=preview/'fixtures/candidate';snapshot=preview/'input-snapshot';selected=manifest['variants']['candidate']
    check('candidate104-file-set-exact',{str(p.relative_to(fixture)) for p in fixture.rglob('*') if p.is_file()}=={x['path'] for x in selected['files']})
    check('all104-candidate-served-bytes-unchanged',len(selected['files'])==104 and all(sha(fixture/x['path'])==x['sha256'] for x in selected['files']))
    originals=[*[(OWN/x['path']) for x in prep['files']],OWN/'preparation-selected-originals.manifest.json',rp,ap,receipt_path,OWN/'runtime-process/stdout.raw',OWN/'runtime-process/stderr.raw']
    images=[]
    check('visual-notes-actually-cover-exact-original36',notes['all36_original_PNGs_actually_viewed'] and [x['path'] for x in notes['images']]==[x['path'] for x in r['screenshots']] and all(x['viewed_original'] for x in notes['images']))
    for x in r['screenshots']:
        p=OWN/x['path'];raw=p.read_bytes();check('original-image-sha:'+p.name,sha(p)==x['sha256'])
        check('actual-PNG-signature:'+p.name,raw[:8]==b'\x89PNG\r\n\x1a\n')
        width,height=struct.unpack('>II',raw[16:24]);v=p.name.split('-')[0]
        check('actual-image-viewport-width:'+p.name,width==(1440 if v=='desktop' else 390) and height>0)
        images.append({**x,'width':width,'height':height,'manually_viewed_original':True});originals.append(p)
    unit=load(snapshot/'website/content/declaration_lessons/huanjian-trace-exponential-domain.json')['units'][0]
    downloads=[]
    for v in ['desktop','mobile']:
        for i,s in enumerate(unit['steps'],1):
            p=OWN/'runtime-output'/f'{v}-step{i}-whole-module.lean';exact=(snapshot/s['lean_source_path']).read_bytes()
            check('saved-actual-download-byte-exact:'+p.name,p.read_bytes()==exact)
            downloads.append({'path':str(p.relative_to(OWN)),'sha256':sha(p),'bytes':len(exact),'source':s['lean_source_path']});originals.append(p)
    d={c['name']:c for c in r['checks']};clip=[];glyphs=[];flows=[]
    for v in ['desktop','mobile']:
        for n in ['P','Radius','Structure']:
            detail=d[f'{v}-graph-{n}-node-and-core-label-inside-actual-SVG-clip']['detail'];g=detail['after_native_UI'];c=g['clip'];node=g['node'];label=g['labelRect']
            def frac(b):
                width=max(0,min(b['right'],c['right'])-max(b['left'],c['left']));height=max(0,min(b['bottom'],c['bottom'])-max(b['top'],c['top']))
                return width*height/(b['width']*b['height']),width,height
            nf,nw,nh=frac(node);lf,lw,lh=frac(label)
            check(v+'-'+n+'-recomputed-actual-clip-node-label',nf==lf==1 and abs(g['intersectionFraction']-nf)<1e-8 and abs(g['labelVisibleFraction']-lf)<1e-8 and 12.9<=g['effectiveFontPx']<=13.1 and lw>=80 and lh>=12)
            check(v+'-'+n+'-actual-wheel-and-pointer-recorded',any('native_pointer' in x for x in detail['interactions']) and any('native_wheel' in x for x in detail['interactions']))
            h=d[f'{v}-graph-{n}-full-ID-detail-real-visible-area']['detail']
            check(v+'-'+n+'-complete-detail-heading-fully-visible',h['intersectionWidth']==h['width'] and h['intersectionHeight']==h['height']==90)
            clip.append({'viewport':v,'target':n,'actual_clip':c,'node_fraction_recomputed':nf,'label_fraction_recomputed':lf,'effective_font_px':g['effectiveFontPx'],'label_width':lw,'label_height':lh,'complete_detail_visible':True,'actual_pointer_and_wheel_events':len(detail['interactions'])})
        for n in ['P','T','Radius','Structure']:
            for suffix in ['widest-line-final-full-codepoint-visible','bottom-full-codepoint-visible']:
                g=d[f'{v}-{n}-{suffix}']['detail'];b=g['glyph'];c=g['actualVisibleClip'];overhang=max(0,b['right']-c['right'],c['left']-b['left'])
                width=max(0,min(b['right'],c['right'])-max(b['left'],c['left']));height=max(0,min(b['bottom'],c['bottom'])-max(b['top'],c['top']))
                check(v+'-'+n+'-'+suffix+'-raw-codepoint-and-readability',g['visible'] and g['lineVisible'] and len(g['codePoints'])==1 and g['selectedGlyph'].strip() and overhang<=1 and width/b['width']>=.96 and height==b['height'])
                glyphs.append({'viewport':v,'source':n,'kind':suffix,'line':g['lineId'],'glyph':g['selectedGlyph'],'codepoints':g['codePoints'],'actual_horizontal_scroll':g['container']['scroll'],'max_horizontal_scroll':g['container']['max'],'bbox_overhang_css_px':overhang,'glyph_box_visible_width_fraction':width/b['width'],'measurement_tolerance_css_px':1})
        for i in range(7):
            x=d[f'{v}-formula{i}-right-reachable-if-overflow']['detail'];check(v+'-formula'+str(i)+'-actual-local-scroll-reachable',x['actual']==x['max'] and x['overflow']=='auto');flows.append({'viewport':v,'formula_index':i,**x})
        for i in range(1,6):
            g=d[f'{v}-step{i}-actual-source-anchor-navigation']['detail'];check(v+'-step'+str(i)+'-anchor-fully-vertically-visible',g['intersectionHeight']==g['height'] and g['top']>=g['header'])
    copies=[c for c in r['checks'] if c['name'].endswith('-actual-copy-byte-exact') or c['name'].endswith('-actual-complete-source-copy-exact')]
    check('18-actual-clipboard-equality-records-present',len(copies)==18 and all(c['pass'] for c in copies))
    graph=load(fixture/'data/underlying-lean-graph.json');nodes=[n['id'] for n in graph['nodes']];private_module='module:Tests.GaussianComplexityTraceMgfDomain';public='decl:AutoSamplingTheory.TechnicalLemmas.Analysis.MatrixTraceExponentialBounds.trace_exp_pos_and_le_card_mul_exp_abs_mul_norm'
    check('unique-canonical-public-P-private-T-module-only',len(nodes)==len(set(nodes))==7 and nodes.count(private_module)==nodes.count(public)==1 and not any(n.startswith('decl:') and 'actual_source_four_trace_mgfs' in n for n in nodes))
    check('three-explicit-reference-overlays-not-value-implications',len(graph['edges'])==9 and sum(e['relation']=='source reference (scanner)' for e in graph['edges'])==3 and 'do not assert theorem implication' in graph['reference_contract'])
    check('no-runtime-request-or-console-error',len(r['requests'])==len(r['responses'])==1328 and r['console']==r['page_errors']==r['blocked_external_requests']==[] and all(x['status']<400 for x in r['responses']))
    baseline={str(p.relative_to(OWN)):sha(p) for p in originals}
    inspection={'schema':'r16-reader-independent-original-runtime-inspection-v1','checks':checks,'runtime_status_separate_from_visual':r['status'],'actual_runtime_check_count':389,'actual_runtime_false_count':0,'original_images':images,'saved_downloads_independently_recompared':downloads,'actual_graph_clip_recomputation':clip,'actual_glyph_measurements_with_honest_subpixel_tolerance':glyphs,'actual_formula_local_scroll':flows,'clipboard_evidence':{'actual_equal_comparisons':len(copies),'original_records':[c['name'] for c in copies],'raw_copied_strings_separately_retained':False,'qualification':'Frozen runner compared the actual clipboard string against exact code/module bytes in the one real run; this inspection verifies records/custody and saved downloads, not a replay of a stopped clipboard session.'},'protected_original_selected_files':baseline,'no_browser_render_or_server_executed_by_inspection':True}
    dump(OUT/'evidence-inspection.json',inspection)
    report={'schema':'r16-independent-isolated-reader-acceptance-v1','reviewer_id':'laplace_native_61e4_independent_reader','status':'PASS_BOUNDED_ISOLATED_READER','reader_blocking_residual_count':0,'basis':'All36 actual original PNGs manually viewed, raw OS receipt and actual DOM/action measurements reviewed, independently recomputed node/label intersections and saved10 downloads; not inferred from zero false flags.','actual_browser_run':{'result_path':'actual-result.json','result_sha256':sha(rp),'receipt_path':'runtime-process/receipt.json','receipt_sha256':sha(receipt_path),'actual_exit_code':0,'actual_checks':389,'actual_false_checks':0,'actual_PNGs':36,'Chrome_version':r['actual_Chrome_version'],'headless':True,'viewports':[{'width':1440,'height':1000},{'width':390,'height':844}],'execution_initiated_and_polled_by':'ROOT under newly approved exact scoped prefix; this acceptance inspection did not launch or rerun it','server_thread_shutdown':'Recorded true by original runner after server.shutdown/server_close/thread.join; no detached testing lifecycle claimed'},'binding':{'preview_manifest_sha256':a['preview_manifest_sha256'],'lesson_sha256':a['lesson_sha256'],'publication_sha256':a['publication_sha256'],'source_reviewed_binding':a['source_reviewed_publication_binding_sha256'],'immutable_mathematics':'30172847ec40c24426f0b39afc4887719810eca0','production_or_future_metadata_commit_build_claim':False},'accepted':{'proof':'Real Hermitian/nonempty/all-real-s ordinary trace exponential main formula readable; initial statement/proof/assumption and five steps folded; expanded prose/formulas and condition comparison available. Conditions/four signed ordinary/cosine Gaussian sums remain in unchanged exact lesson; no extra public premise introduced by presentation.','adjacent_code':'All5 P/P/P/T/T spans:60+183=243 exact lines; all10 viewport/step copies, anchor navigations and complete-file downloads exercised. Saved10 downloaded files independently byte-compared again.','source_pages':'P60/T183/Radius226/Structure148 source bodies, header/declaration anchors, line layout, bottom/widest codepoint reachability, exact whole-module clipboard comparisons and4-label source-index targets.','graph':'Exactly one canonical public P, one private T module and no public private-T declaration. P has no claimed ASTIS mathematical parent; private consumer context lists P/Radius/Structure. All6 actual focus PNGs show readable node/core label inside real SVG clip: both fractions1, effective font13px. Complete90px detail headings fully visible in all6 raw records; P detail original PNGs viewed. Actual primary-context navigation passed. Solid structure and dashed scanner references remain distinct, not value-implication certificates.'},'nonblocking_limits':notes['visual_findings']['nonblocking_limits']+['Glyph Range bboxes permit the original1CSSpx raster/scroll rounding tolerance; measured worst right bbox overhang is '+str(max(g['bbox_overhang_css_px'] for g in glyphs))+'px. Viewed glyphs remain readable; this is not a claim of pixel-zero Range-box clipping.','Only representative steps1/5 have expanded prose PNGs; all5 code/actions and7 formula scroll containers have actual runtime records. The mobile step5 formula is below the representative viewport, not claimed visible in that one PNG.','Clipboard equality is an actual frozen-runner observation; raw copied strings were not separately persisted. Exact source bytes, comparison code,18 equality records and10 downloaded artifacts are retained.'],'unmeasured_boundaries':['Physical phone/touch gestures, headed OS window behavior, other browsers/OS/fonts/viewports, assistive technology and full keyboard-only accessibility.','Whole-site or production deployment, shared global graph integration, external citation page/network content and backend publication state.','New Lean compilation, kernel/type/value/source re-review, normal PL/V, stabilization, purification or main/Goal completion. This reader report supplies none of these.'],'original_failures_preserved':{'preparation_PATH_node_exit1':'static-process/receipt.json','repaired_static_v2_exit0':'static-process-v2/receipt.json','root_initial_render_KeyError_scope':'ROOT-owned v1 failed render remains separately retained; no foreign failure tree copied into this packet'},'new_run_custody':{'inspection_script':'reader-acceptance-v1/review_runtime_evidence.py','inspection_script_sha256':sha(__file__),'inspection_data_sha256':sha(OUT/'evidence-inspection.json'),'visual_notes_sha256':sha(OUT/'visual-review-notes.json'),'all_original_selected_bytes_unchanged':all(sha(OWN/path)==digest for path,digest in baseline.items())},'authority':'Independent reader acceptance only. No API/V/Git/source/site-production operation or status upgrade performed. No old acceptance inherited.'}
    check('all-protected-selected-originals-still-byte-identical',report['new_run_custody']['all_original_selected_bytes_unchanged'])
    dump(OUT/'reader-acceptance-report.json',report)
    print(json.dumps({'status':report['status'],'blocking_reader_residuals':0,'inspection_checks':len(checks),'original_PNGs_manually_viewed':36,'report_sha256':sha(OUT/'reader-acceptance-report.json'),'inspection_sha256':sha(OUT/'evidence-inspection.json')}))

if __name__=='__main__':
    process=OUT/'process';process.mkdir(exist_ok=False);out=process/'stdout.raw';err=process/'stderr.raw';start=time.monotonic();started=dt.datetime.now(dt.timezone.utc).isoformat();code=0
    for fd,p in [(1,out),(2,err)]:
        f=p.open('xb',buffering=0);os.dup2(f.fileno(),fd);f.close()
    try:main()
    except BaseException:traceback.print_exc();code=1
    sys.stdout.flush();sys.stderr.flush()
    dump(process/'receipt.json',{'schema':'r16-independent-reader-inspection-actual-OS-receipt-v1','argv':[sys.executable,*sys.argv],'cwd':str(Path.cwd()),'pid':os.getpid(),'ppid':os.getppid(),'started_utc':started,'ended_utc':dt.datetime.now(dt.timezone.utc).isoformat(),'elapsed_seconds':time.monotonic()-start,'actual_exit_code':code,'stdout':{'path':str(out.relative_to(OWN)),'bytes':out.stat().st_size,'sha256':sha(out)},'stderr':{'path':str(err.relative_to(OWN)),'bytes':err.stat().st_size,'sha256':sha(err)},'script_sha256':sha(__file__),'scope':'Only independent read/parse/hash/arithmetic audit of a stopped original reader run; no browser/server/render/Lean/API/Git/site operation'})
    sys.exit(code)
