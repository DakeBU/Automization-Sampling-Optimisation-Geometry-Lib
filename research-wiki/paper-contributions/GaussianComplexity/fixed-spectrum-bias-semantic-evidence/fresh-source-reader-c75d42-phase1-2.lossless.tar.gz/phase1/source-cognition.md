# Independent raw-source cognition — phase 1

This record was constructed without a supplied target theorem, candidate statement, candidate seal, implementation, decoder output, previous review, lesson, audit, or publication packet. Its mathematical input is the pinned original paper, restricted to Section 2, complete Section 4, and complete Appendix C.3. Required process protocols were also read. The exact read/exposure manifests disclose an accidental broad source search; no candidate-related input was exposed. This is a source reconstruction, not a candidate comparison, fidelity verdict, repair acceptance, build claim, or source-completion certificate.

The original is arXiv:2610.20492v1, *On Complexity of Gaussian Sampling*, local HTML SHA-256 `6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915`. All line numbers below refer to that exact original file. The machine inventory records every substantive paragraph/display in the three complete slices and their original MathML alt-text formulas, IDs, reference uses, and line spans. Navigation headings and proof terminators are explicitly excluded as nonmathematical, while theorem headings and their contents remain represented. No external citation or deferred appendix proof outside C.3 was consulted.

## Standing objects, laws, oracle, and cost

Section 2, lines 635–753, fixes finite-dimensional Euclidean norm and the Loewner order on real symmetric matrices (`S2.p1.1`, 639–642). The group O(d) has Haar probability, and determinant components have mass one half (`S2.p2.1`, 645–652). No determinant conditioning is used in Section 4's stated hard distribution.

For integer d≥1 and real κ≥1, the admissible precision class is A=Aᵀ with I≤A≤κI (`S2.Ex1`, 663–669). The potential is f_A(x)=xᵀAx/2 and the target is the centered Gaussian π_A=N(0,A⁻¹) (`S2.SS0.SSS0.Px1.p1.2`, 670–673). Thus A is a precision matrix; its inverse is the covariance. The exact first-order reply is (xᵀAx/2,Ax) (`S2.E1`, 674–681). Exact value-and-gradient, gradient-only, and matrix–vector queries have the same cost on this class: the gradient reply contains Ax, and Ax determines the value using x (`S2.SS0.SSS0.Px1.p2.1`, 684–690). These are exact real replies, not noisy/finite-precision oracle claims.

The algorithm's randomness is independent of the input; queries, stopping, and the Rᵈ-valued output are Borel functions of that seed and observed replies. A cap T holds for every admissible input and every seed realization (`S2.SS0.SSS0.Px2.p1.1`, 697–704). Arbitrary adaptive/randomized algorithms are allowed; outputs need not lie in the span of queries and responses. Cost is a deterministic pathwise cap, not expected cost. The accuracy requirement applies to the output law after averaging over the seed and is uniform over inputs (`S2.SS0.SSS0.Px4.p1.1`, `S2.E2`, `S2.SS0.SSS0.Px4.p1.2`, 732–750). Q_G(d,κ,ε) is the infimum of nonnegative integer feasible caps, for 0<ε<1.

TV(P,Q)=sup over measurable B of |P(B)−Q(B)|, with the half-L¹ density normalization (`S2.Ex2`, 713–719). The [0,1]-valued test-function inequality uses that same normalization (`S2.SS0.SSS0.Px3.p1.2`, 720–725). A test event may depend on the fixed input A; TV is applied separately for that A before averaging. There is no requirement that the algorithm be able to evaluate the separating test.

## Section 4: contracts and quantifier/constant scope

Theorem 4.1 (`S4.Thmtheorem1.p1.1`, `S4.Ex9`, 1065–1074): for every fixed δ∈(0,1), there exists d₀(δ) such that for every integer d≥d₀(δ), every 2≤κ≤d^(1−δ), and every 0<ε≤1/10,

Q_G(d,κ,ε) ≥ (δ/256)√κ log d.

d₀ is uniform over κ, ε, and all eligible query caps/algorithms in that range; it may depend on δ and the absolute constants in preceding bounds. This is a lower bound, permits known spectrum, includes κ below four, and has no growing dependence on decreasing ε (`S4.p2.1`, 1078–1080). The discussion compares with a different theorem/source; neither was inspected here.

The hard family (`S4.SS1.p1.1`, `S4.E11`, `S4.SS1.p1.2`, 1086–1101) uses d≥2 and κ≥2, i=1,…,d,

θ_i=(i−1/2)π/d, λ_i=(κ+1)/2+(κ−1)cos θ_i/2, Λ=diag(λ_i), A=OΛOᵀ,

with O Haar on O(d), independent of the private seed. The precision eigenvalues and therefore the Gaussian normalizer are deterministic and may be given to the algorithm; only the eigenbasis is unknown (`S4.SS1.p2.1`, 1104–1106). The affine relation with the κ=2 family in Remark 4.2 is A=(κ−1)A₂−(κ−2)I; one matrix–vector reply converts in either direction for κ≥2 (`S4.Thmtheorem2.p1.1`, 1111–1124). That remark previews a comparison between a uniform Krylov statistic and its target normalized mean; it does not assert a new output moment identity.

The block Krylov space is K_q(g₁,…,g_{q+1})=span{Λʲg_a:1≤a≤q+1, 0≤j≤q} (`S4.Ex10`, 1153–1159). Lemma 4.3 (`S4.Thmtheorem3.p1.1`, `S4.Ex11`, 1164–1172), in the hard-family/randomized-algorithm context, quantifies over integer q≥0 with 2q+1<d and the output X of a q-query algorithm. On a suitable extension there exist mutually independent g_a∼N(0,I_d) with OᵀX∈K_q almost surely. The extension preserves the joint law of (O,X), as explicitly used at lines 1387–1394. Independence of the g_a from O, X, or the adaptive coefficients is not asserted. Each coordinate polynomial p_a has degree≤q, and its coefficients may depend on the entire extended experiment. The extra q+1-st Gaussian accounts for outputs outside the query/reply span (`S4.SS2.SSS0.Px1.p3.1`, 1176–1187). A uniform-in-u estimate is therefore essential to its consumption. Deferred-rotation input [22, Lemma 9.2] and Appendix C.1 are cited but not inspected.

Set n=2q+1 and D_n=diag(cos(nθ_i)) (`S4.Ex12`, 1197–1203). Lemma 4.4 (`S4.Thmtheorem4.p1.1` through `S4.Ex14`, 1210–1229) provides one absolute C>0. For integer q≥0, 2q+1<d, and mutually independent standard Gaussian g_a, define

τ_{d,q}=C[(q+1)√(log d/d)+(q+1)(q+1+log d)log d/d].

If τ≤1/2, an event of probability≥0.99 simultaneously satisfies |uᵀD_nu|≤2τ||u||² for every u∈K_q. This is a joint high-probability bound for all vectors, not a separate 0.99 probability for each chosen vector. The constant is κ-independent because the nonconstant affine map from cos θ_i to λ_i identifies the polynomial spans (`S4.SS2.SSS0.Px2.p2.1`, 1233–1240). The statement does not require the random u/coefficients to be independent of the g_a. Its use with Lemma 4.3 gives |XᵀOD_nOᵀX|≤2τ||X||² (`S4.Ex15`, 1246–1252). Its deferred proof, Appendix C.2, was not inspected.

Lemma 4.5 (`S4.Thmtheorem5.p1.1`, 1264–1270) inherits the cosine-grid definitions and d≥2. It assumes κ≥2, U∼N(0,Λ⁻¹), and integer 1≤n<d; it defines ρ=(√κ−1)/(√κ+1), M=E||U||², μ_n=E[UᵀD_nU]. Here 0<ρ<1 and M>0. It states the exact means (`S4.EGx1`, 1271–1278),

M=(d/√κ)(1−ρ^(2d))/(1+ρ^(2d)),
(−1)ⁿμ_n=(d/√κ)(ρⁿ−ρ^(2d−n))/(1+ρ^(2d)),

and each of Var(||U||²), Var(UᵀD_nU) is ≤2M≤2d/√κ (`S4.Thmtheorem5.p1.2`, 1279–1281). The additional hypothesis d−n≥√κ is attached to the exponential normalized-bias conclusion only (`S4.Thmtheorem5.p2.1`, `S4.Ex17`, 1284–1291):

(1−e^(−4))e^(−3n/√κ) ≤ |μ_n|/M ≤ e^(−2n/√κ).

In particular, that guard is not a premise of the exact moments or variances. The upper bias estimate actually follows without this extra guard from the C.3 proof. If Y|O∼π_A and U=OᵀY, then U has covariance Λ⁻¹ and the two corresponding quadratic forms match, which transfers all these statements to every fixed hard-family A (`S4.SS2.SSS0.Px3.p2.1`, 1295–1299). The standalone lemma allows even n; the theorem proof later takes odd n=2q+1.

Lemma 4.6 (`S4.Thmtheorem6.p1.1`, 1314–1315) states admissibility I≤OΛOᵀ≤κI for every O∈O(d), under the hard family. Appendix C.4 is the declared proof location. It was not deliberately inspected; accidental source-search exposure of some C.4 text is disclosed in the exposure manifest and was not used as a proof source for this cognition.

Lemma 4.7 (`S4.Thmtheorem7.p1.1`, `S4.Ex28`, 1529–1537) states that for every integer q≥0 and independent standard Gaussian g_a, dim K_q=min{d,(q+1)²} almost surely. Distinctness of λ_i is the stated preceding reason. It has no 2q+1<d premise in its own statement. No proof of this rank fact is supplied in the permitted Section 4/C.3 slices; it remains an unverified source input for the limitations discussion in this record.

## Appendix C.3: reconstructed calculation and analytic guards

Fact C.7 (`A3.Thmtheorem7.p1.1`, `A3.Ex133`, `A3.Thmtheorem7.p1.2`, 3851–3859) states for every real θ, with κ≥2 inherited from Lemma 4.5,

2/[κ+1+(κ−1)cos θ]=(1/√κ)[1+2Σ_{j≥1}(−ρ)ʲcos(jθ)],

and absolute/uniform convergence in θ. The geometric-series calculation in `A3.EGx14` (3867–3879) gives (1−ρ²)/(1+2ρcosθ+ρ²) for the bracket. `A3.Ex136` (3881–3887) supplies (1−ρ)/(1+ρ)=1/√κ and identifies the remaining denominator with the affine inverse spectrum. Nonzero denominators follow from 0<ρ<1 and |cosθ|≤1; the inverse precision denominator is at least 2. The majorant Σρʲ=ρ/(1−ρ) (`A3.Ex137`, 3890–3896) proves absolute and uniform convergence for each fixed κ. The source does not claim one convergence bound uniform as κ→∞.

Fact C.8 (`A3.Thmtheorem8.p1.1`, `A3.Ex138`, 3904–3911) states the same exact moment formulas for 1≤n<d. Its proof first establishes, for every integer k,

Σ_{i=1}^d cos(kθ_i)=d(−1)^a if k=2ad with integer a, and 0 otherwise (`A3.Ex139`, 3918–3926).

For k not divisible by 2d the denominator in sin(kπ)/(2sin(kπ/(2d))) is nonzero and its numerator vanishes; for k=2ad each summand is (−1)^a (`A3.SS3.p3.2`, 3927–3930). The rule includes k=0 and negative k.

The coordinate second moments give M=Σ1/λ_i and μ_n=Σcos(nθ_i)/λ_i (`A3.Ex140`, 3934–3940). Absolute convergence justifies exchanging the inverse-spectrum series with the finite grid sum (`A3.SS3.p4.2`, 3941–3943). For M only j=2ad, a≥1 survive. The resulting geometric series in −ρ^(2d) yields `A3.EGx15` (3948–3965).

For μ_n the constant grid sum vanishes because 1≤n<d. Product-to-sum yields `A3.Ex144` (3970–3976). The first inner grid sum is nonzero for j=n or j=2ad+n (a≥1); the second is nonzero for j=2ad−n (a≥1). Positivity of the indices and disjointness use 1≤n<d. In particular, these classes cannot be copied unmodified to n=0 or n=d. The powers have parity (−ρ)^(2ad±n)=(−1)ⁿρ^(2ad±n). Summing gives `A3.EGx16` (3986–4003), with denominator 1+ρ^(2d). No asymptotic approximation replaces this finite-grid alias correction.

The variance argument (`A3.SS3.p8.1`, `A3.EGx17`, 4014–4035) uses diagonal Gaussian covariance, hence independent coordinates, E U_i⁴=3/λ_i² and Var(U_i²)=2/λ_i². Finite Gaussian fourth moments supply the square-integrability needed for all variances. Since λ_i≥1 and cos²≤1,

Var(||U||²)=2Σλ_i^(−2)≤2Σλ_i^(−1)=2M,
Var(UᵀD_nU)=2Σcos²(nθ_i)λ_i^(−2)≤2M.

The exact M formula gives M≤d/√κ (`A3.SS3.p8.2`, 4036). There is no need to assume independence between the two quadratic forms themselves.

For the normalized bias, ρⁿ>ρ^(2d−n) because n<d and 0<ρ<1. Thus (−1)ⁿμ_n>0 and |μ_n|=(−1)ⁿμ_n. Dividing the two exact means, with positive M and denominators, gives

β:=|μ_n|/M=ρⁿ[1−ρ^(2(d−n))]/[1−ρ^(2d)] (`A3.Ex150`, 4045–4051).

Because 0<ρ^(2d)<ρ^(2(d−n))<1, the residual ratio is between 1−ρ^(2(d−n)) and 1 (`A3.Ex151`, 4055–4061). This sign/order check is essential; the numerator correction is smaller than the denominator correction, so β≤ρⁿ. In fact β>0 and β<1 in the source range.

The log calculation (`A3.EGx18`, 4065–4082) is

L:=log(1/ρ)=log[(√κ+1)/(√κ−1)]
=2∫₀^(1/√κ)1/(1−t²)dt
=2/√κ+2∫₀^(1/√κ)t²/(1−t²)dt.

Its interval is contained in [0,1/√2], so the denominator is strictly positive, the rational integrands are continuous, and the logarithms have positive arguments. The integral identity follows by differentiating log[(1+t)/(1−t)] and evaluating at the endpoints. The remainder is nonnegative, giving L≥2/√κ. Since 1−t²≥1−κ⁻¹>0,

L≤(2/√κ)[1+1/(3(κ−1))]≤8/(3√κ)<3/√κ (`A3.EGx19`, 4087–4099).

The final two comparisons use κ≥2. For positive integer n, multiplying by −n reverses order and exponentiating gives

e^(−3n/√κ)≤ρⁿ≤e^(−2n/√κ) (`A3.Ex157`, 4102–4108).

Under the extra guard d−n≥√κ,

ρ^(2(d−n))=exp[−2(d−n)L]≤exp[−4(d−n)/√κ]≤e^(−4) (`A3.Ex158`, 4113–4119).

Combining this with the residual-ratio bounds gives (1−e^(−4))ρⁿ≤β≤ρⁿ, and then `A3.Ex159` (4124–4130). Thus the constants 1−e^(−4), 3, 2 arise from distinct operations: tail suppression, an upper log bound, and a lower log bound. They are absolute, independent of d, n, κ within the source range. No missing mathematical premise was found in this inspected C.3 route; the elementary analytic/Gaussian steps described above must still be discharged in any full proof rather than promoted to public assumptions.

## Actual probability application in Section 4.3

The contradiction starts with a single algorithm, integer cap q≥0, q≤(δ/256)√κ log d, and uniform TV≤ε on the full admissible class (`S4.SS3.p2.1`, 1330–1337). Define n=2q+1 and τ=τ_{d,q}. The signed polynomial statistic is

S_A(x)=(−1)ⁿxᵀT_n((2A−(κ+1)I)/(κ−1))x−2τ||x||²,
E_A={x:S_A(x)>0} (`S4.EGx2`, 1343–1355).

The divisor κ−1 is positive. Spectral calculus and T_n(cosθ_i)=cos(nθ_i) identify this with (−1)ⁿxᵀOD_nOᵀx−2τ||x||². The event is Borel in x and jointly measurable in A because the defining expression is polynomial in A and x. This expression also makes the test independent of any sign choices for eigenvectors. The geometric weights in lines 1360–1370 are used only for x≠0. At x=0 the polynomial statistic is zero and the event fails; no division by the algorithm output norm is needed for the proof.

The following are derived internally and uniformly for sufficiently large d depending only on δ, not assumed of the arbitrary algorithm:

* q+1≤d^((1−δ)/2)log d, n=o(d), and therefore 1≤n<d (`S4.SS3.SSS0.Px1.p1.1`, 1377–1379).
* Substitution in τ gives τ≲d^(−δ/2)(log d)^(3/2)+d^(−δ)(log d)³≲d^(−δ/2)(log d)³→0 (`S4.Ex20`, 1380–1386). The cross term d^(−(1+δ)/2)(log d)³ is bounded by the displayed d^(−δ)(log d)³ since 0<δ<1. Thus τ≤1/2 and Lemmas 4.3–4.4 apply on the joint extension (`S4.SS3.SSS0.Px1.p1.2`, 1387–1394).
* With probability≥0.99, |XᵀOD_nOᵀX|≤2τ||X||², so S_A(X)≤0 (`S4.Ex21`, 1395–1401). The uniform bound handles random coefficients. Hence E_A[ρ_A^Alg(E_A)]≤0.01 (`S4.Ex22`, 1405–1411). This is a probability averaged over hard input and seed, not a per-input 0.99 statement about the algorithm.
* n=o(d) and √κ≤d^((1−δ)/2)=o(d) imply d−n≥√κ (`S4.SS3.SSS0.Px2.p2.1`, 1425–1428). This explicitly discharges the guard on the lower bias estimate.
* β≥(1−e^(−4))exp(−3n/√κ)≥b d^(−δ/4), b=(1−e^(−4))e^(−3)>0 (`S4.Ex23`, 1429–1435). Indeed 3n/√κ≤3+(3δ/128)log d, and 3δ/128≤δ/4 with d≥1.
* The log lower bound also implies the weaker ρ≤exp(−1/√κ). Since d≥√κ, ρ^(2d)≤e^(−2)<1/3. The exact mean formula then gives M≥d/(2√κ)≥d^((1+δ)/2)/2 (`S4.SS3.SSS0.Px2.p2.2`, 1436–1444).
* Therefore τ/β≤(C′/b)d^(−δ/4)(log d)³→0, and Mβ²≥(b²/2)√d→∞ (`S4.Ex24`, 1445–1451). C′ is an absolute bound from the τ estimates. Choose one d₀(δ) making all earlier guards hold and τ≤β/4, Mβ²≥320 (`S4.SS3.SSS0.Px2.p2.3`, 1452–1455). No random event is used to establish these deterministic parameter inequalities.

For each fixed hard-family A, let Y∼π_A and Z=S_A(Y). The target law transfer and moment lemma give E Z=(β−2τ)M≥βM/2>0, with finite variance. The L² triangle inequality applied to the centered cosine form and centered norm yields

Var(Z)≤(√(2M)+2τ√(2M))²≤8M (`S4.Ex25`, 1464–1470).

This uses τ≥0 and τ≤1/2; the already derived τ≤β/4 and β≤1 are even stronger. It does not assume the two quadratic forms are independent and does not discard their covariance by fiat. Positive expectation gives {Z≤0}⊆{|Z−E Z|≥E Z}; Chebyshev at that positive threshold is legitimate. Hence, for every fixed A,

π_A(E_A)=P(Z>0)≥1−Var(Z)/(E Z)²≥1−32/(Mβ²)≥0.9 (`S4.Ex26`, 1472–1478).

Finally per-input TV implies π_A(E_A)−ρ_A^Alg(E_A)≤ε; averaging and the two different senses of probability give 0.9−0.01=0.89≤ε≤0.1 (`S4.Ex27`, 1489–1495), a contradiction. The source consequently excludes every integer cap q up to the real stated threshold, which implies the displayed lower bound for the infimum of feasible caps. This is a uniform law-level argument, not a deterministic statement that every target draw passes.

## Limitations and bounded source gaps

Section 4.4's limitation on κ (`S4.SS4.SSS0.Px1.p1.1`, 1516–1524) concerns the enlargement to a whole block Krylov space. The source rank assertion makes K_q=Rᵈ almost surely once (q+1)²≥d. When additionally n=2q+1<d, Σcos²(nθ_i)=d/2 gives a coordinate with |cos(nθ_i)|≥1/√2, hence the supremum normalized quadratic form is at least 1/√2 (`S4.Ex29`, 1547–1553). This defeats a small uniform bound; it does not show that a particular algorithm realizes that vector or that the hard family has no stronger lower bound. The asymptotic κ≳d/log²d statement is a limitation of the proposed q≈√κ log d route with constants, not an exact finite parameter equivalence.

There is a minor constant wording issue in `S4.SS4.SSS0.Px1.p2.2` (1554–1558): it says the separating test requires this supremum at most 1/2, whereas Lemma 4.4 as stated gives 2τ, and its premise τ≤1/2 alone yields at most 1. Section 4.3 actually drives τ→0 and imposes τ≤β/4≤1/4, so its selected regime does yield at most 1/2. This wording is not a counterexample to Theorem 4.1 and does not justify changing its public premises.

For accuracy (`S4.SS4.SSS0.Px2.p1.1`, 1565–1576), the source argues a threshold must satisfy a≤t<β, where a is a uniform Krylov bound. It invokes a Bernstein calculation in Fact C.6 to assert a≥c/√d, and combines β≤exp(−2n/√κ) to obtain c/√d≤a<β≤exp(−2(2q+1)/√κ) (`S4.Ex30`, 1577–1583). Its logarithmic consequence is q=O(√κ log d), independent of ε. Fact C.6 was outside the permitted reading scope and is therefore a recorded external-to-slice proof obligation, not independently validated here. The conclusion concerns this threshold/concentration route, not an impossibility theorem for all tests.

Remaining bounded inputs, without inventing new hypotheses: the deferred-rotation/Krylov representation (Appendix C.1 and [22]); uniform concentration with its absolute C (Appendix C.2); admissibility proof (declared Appendix C.4); and the almost-sure full-rank statement of Lemma 4.7. Their statements and consumer sites were read, but no source-completion claim is made for their unavailable proofs. The elementary Gaussian fourth-moment, finite-series rearrangement, log integral, spectral polynomial and measurability steps used in the inspected proof were reconstructed above as proof ingredients. They are not additional source binders. Remark 4.8 (`S4.Thmtheorem8.p1.1`, 1592–1595) expressly leaves open stronger fixed-spectrum-family lower bounds.

No target statement has been supplied at freeze time. All seven comparison slots—objects, domains, quantifiers, assumptions, conclusions, scope/sense, and constant dependence—have source-only content above. No comparison slots have been filled against any candidate or decoder reconstruction. This phase ends at a single immutable source freeze.
