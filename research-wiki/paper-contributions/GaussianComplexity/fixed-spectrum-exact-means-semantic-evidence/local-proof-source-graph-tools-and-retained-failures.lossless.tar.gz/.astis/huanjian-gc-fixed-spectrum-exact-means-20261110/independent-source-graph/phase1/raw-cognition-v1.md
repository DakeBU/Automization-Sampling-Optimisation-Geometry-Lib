# Raw cognition v1 — before seal or candidate interface access

Source read: pinned local arXiv 2610.20492v1 HTML, SHA256
`6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915`.
Read S4.SS1.p1.1, S4.E11, the whole S4.Thmtheorem5 statement,
and the whole Appendix C.3 (A3.SS3), including all equation TBODYs.
Bibliography bib.bib3 was read only to identify the construction-provenance
citation [22, §9.2]; no result from that work is used here.

No Statement Seal, target Lean signature, implementation Lean, candidate proof,
old source graph, cognition, audit, frontier, ledger verdict, or private
rationale was opened before this document. A broad initial `rg --files` returned
names of older evidence paths; their contents were not opened. Process files
read were AGENTS.md, docs/proof-digestion-protocol.md, and
docs/evidence-routed-memory-protocol.md. No proof/API search was performed.

## Objects and scope

S4 construction fixes d >= 2, kappa >= 2, theta_i=(i-1/2)pi/d,
lambda_i=(kappa+1)/2+(kappa-1)cos(theta_i)/2, and diagonal precision Lambda.
Lemma 4.5 takes the actual law U ~ N(0,Lambda^-1), not N(0,Lambda).
For the source integer 1 <= n < d, D_n=diag(cos(n theta_i)),
M=E ||U||^2, mu_n=E[U^T D_n U], and r=(sqrt(kappa)-1)/(sqrt(kappa)+1).
M and mu_n are actual means, not freely chosen numbers or law callbacks.
The source's d,kappa,n conditions imply d>0, sqrt(kappa)>1 and 0<r<1.

The selected producer is the pair of exact means in Fact C.8/Ex138:

M = d/sqrt(kappa) * (1-r^(2d))/(1+r^(2d));
(-1)^n mu_n = d/sqrt(kappa) * (r^n-r^(2d-n))/(1+r^(2d)).

The selected consumer uses p8.2 for M <= d/sqrt(kappa), and p9.1/Ex150
for (-1)^n mu_n > 0 and
|mu_n|/M = r^n (1-r^(2(d-n)))/(1-r^(2d)).
M>0 is an implicit denominator guard derived from the exact M formula.
The ratio genuinely consumes both means. The M upper-bound subroot uses only
the exact M branch, and the signed positivity subroot only the exact mu branch.
The paired producer is supported by this coupled ratio consumer; neither a
variance theorem nor the whole Lemma 4.5 is needed for these selected outputs.

## Source route, reconstructed from raw text

1. Fact C.7/Ex133 gives the inverse spectrum expansion. Its proof first sums
   two complex geometric series (Ex134), combines them (Ex135), normalizes via
   the two r/kappa identities (Ex136), and proves absolute/uniform convergence
   by |(-r)^j cos(j theta)| <= r^j and sum r^j=r/(1-r) (Ex137).
   Geometric convergence uses 0<r<1; complex denominators 1+r exp(±i theta)
   cannot vanish because their variable part has norm r<1. The real denominator
   is |1+r exp(i theta)|^2 >= (1-r)^2>0. These are internal proof checks.
2. The grid alias formula Ex139 is for every integer k, including negative k
   and zero. k=2ad gives d(-1)^a for a in Z. Otherwise the finite cosine sum
   has numerator sin(k pi)=0 and nonzero denominator 2 sin(k pi/(2d)). The
   relation between a vanishing denominator and k in 2d Z is suppressed in
   prose but necessary to justify this displayed quotient.
3. p4.1/Ex140 use E U_i^2=1/lambda_i to identify the actual two means with
   the two grid sums. This second-moment identity uses covariance Lambda^-1.
   Finite linearity/integrability and the diagonal quadratic-form expansion
   are implicit analytic bookkeeping. Fourth moments, offdiagonal mixed
   products, upper-spectrum bounds, or independence are not required here.
4. p4.2 exchanges the absolutely convergent inverse-spectrum series with a
   finite grid sum. The cosine-weighted version is absolutely summable because
   |cos(n theta_i)| <= 1. Uniform convergence is source-present but absolute
   convergence plus finiteness is sufficient for this exchange.
5. p5.1/Ex141 retain exactly j=2ad with a>=1 in the positive-index expansion;
   j=0 is the separately written constant mode, never an a=0 term in that
   series. The alias sign (-1)^a survives, while (-r)^(2ad)=r^(2ad).
   Ex142 sums ratio -r^(2d) (absolute value <1); Ex143 simplifies, dividing by
   1+r^(2d)>0. This proves M's exact formula.
6. p6.1 uses the zero alias of n (0<n<d<2d) to remove the constant mode,
   and 2cos(n theta)cos(j theta)=cos((j-n)theta)+cos((j+n)theta) to obtain
   Ex144. The alias at j-n must remain an integer-frequency statement.
7. p6.2 classifies the nonzero aliases as exactly three disjoint positive-j
   classes: j=n, j=2ad+n (a>=1), and j=2ad-n (a>=1). The last class is positive
   since 2ad>n. Negative multiples in j-n cannot occur for j>=1 and 0<n<d.
   Pairwise disjointness uses 0<n<d; an overlap of + and - classes would force
   n to be a positive multiple of d. Their alias values are d, d(-1)^a,
   d(-1)^a. The identity (-r)^(2ad±n)=(-1)^n r^(2ad±n) requires parity and
   valid nonnegative exponents. Source integer subtraction must be justified
   before any translation to truncated natural subtraction.
8. Ex145 assembles the three classes. Ex146 resums the two shifted geometric
   series, each with ratio -r^(2d); the minus shift uses
   2ad-n=(2d-n)+2d(a-1), with a>=1 and 2d-n>0. Ex147 simplifies the numerator
   using r^(2d+n)=r^n r^(2d). This proves the exact signed mu formula.
9. p7.1 applies Fact C.8's pair as the two means of Lemma 4.5. p8.2 uses only
   the exact M formula: 0<r^(2d)<1, so 0<(1-r^(2d))/(1+r^(2d))<=1.
   Hence 0<M<=d/sqrt(kappa). This does not use p8.1 or Ex148/149.
10. p9.1 has n<2d-n and 0<r<1, hence r^n>r^(2d-n). Positive d/sqrt(kappa)
    and 1+r^(2d) make (-1)^n mu_n positive. Its sign gives
    |mu_n|=(-1)^n mu_n. Dividing the two exact means cancels only nonzero
    factors: d/sqrt(kappa)>0, 1+r^(2d)>0, M>0, 1-r^(2d)>0.
    Factoring r^n-r^(2d-n)=r^n(1-r^(2(d-n))) requires d-n>0 and
    2d-n=n+2(d-n). The resulting identity is Ex150.

## Exhaustive outside-scope disposition

The construction citation is historical provenance, not a proof input. The
full Lemma 4.5 bundles additional variance and exponential-bias assertions;
its exact-mean components and definitions supply selected source anchors,
but no full-Lemma completion is claimed. C.3 p8.1/Ex148-149 explicitly use
coordinate independence and fourth moments for variances, an excluded branch.
p9.2/Ex151 estimate the ratio factor after Ex150 and are excluded from the
selected exact ratio. p10.1-p10.3/Ex152-157 derive logarithmic/exponential
power bounds, and p11.1-p11.2/Ex158-159 combine them under d-n>=sqrt(kappa);
all are excluded downstream branches. End-proof glyph paragraphs are
structural. Equation-group tables enclosing aligned TBODY equations are
structural containers; the individual Ex134-135, Ex141-143, Ex145-147,
Ex148-149, Ex152-156 remain separately covered.

## Gaps and alternatives

The source is mathematically explicit about its frequency classes, parity,
absolute convergence, and both geometric resummations. It suppresses details
of sine-denominator nonvanishing, finite/infinite exchange justification,
index bijections/disjointness arithmetic, actual Gaussian finite-moment
bookkeeping, and cancellation/normalization positivity. These should be
visible internal bookkeeping/guard nodes, with SOURCE_GAP labels for omitted
proof details, not new theorem hypotheses. No contradiction or source repair
is identified by this raw reading.

No alternative proof of the exact means is supplied by this source slice.
Absolute convergence and uniform convergence should not become a false AND
for finite-grid exchange: the absolute route suffices; the uniform route is
a possible separate OR route requiring its own convergence justification.
The selected consumer should not acquire every downstream Lemma 4.5 branch
as an AND dependency merely because the source states a bundled lemma.

This is unreviewed source cognition, not source-topology approval, a compiled
proof, proof seal, VERIFIED credit, or a shared-lane ownership claim.
