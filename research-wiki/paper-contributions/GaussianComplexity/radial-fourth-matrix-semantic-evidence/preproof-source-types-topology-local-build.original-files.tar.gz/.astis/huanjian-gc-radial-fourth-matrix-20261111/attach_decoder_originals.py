"""Attach exact decoder originals and freeze the fresh anti-anchored review packet."""
from pathlib import Path
import hashlib
import json
import sys

sys.dont_write_bytecode = True
sys.path.insert(0, 'tools')
import astis_publication as publication
import astis_semantic_roundtrip as semantic

workspace = Path(__file__).resolve().parent.relative_to(Path.cwd())
evidence = Path('research-wiki/paper-contributions/GaussianComplexity/radial-fourth-matrix-semantic-evidence')
slug = 'huanjian-gaussian-radial-fourth-matrix'
audit_path = Path('research-wiki/semantic-roundtrip/audits') / (slug + '.json')
lesson_path = Path('website/content/declaration_lessons') / (slug + '.json')
pub_path = Path('website/content/publications') / (slug + '.json')
phase = Path('.astis/semantic-neutral-20261111/r4_decode_72b6')
sha = lambda raw: hashlib.sha256(raw).hexdigest()
dump = lambda value: (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode()


def create(path, raw):
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        assert path.read_bytes() == raw, str(path)
        return
    with path.open('xb') as out:
        out.write(raw)


run_raw = (phase / 'decoder_run.json').read_bytes()
text_raw = (phase / 'reconstruction.md').read_bytes()
assert sha(run_raw) == '38c130185832c9cf4d38ceac74f5e7ea9934ea5af5c9f0bf4eaa412a6610917a'
assert sha(text_raw) == '9ebf1bed71264f56e5bc70504b47be48e40726bcd6777a11299387b6ac2a4c0b'
run = json.loads(run_raw)
canonical = {key:value for key,value in run.items() if key != 'decoder_run_sha256'}
canonical_hash = sha(json.dumps(canonical, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode())
assert canonical_hash == run['decoder_run_sha256'] == '2a303de3240dd383f27fae32b7282c1535d423c66b33254595e259995caeebdc'
assert run['reconstructed_theorem_text'].encode() == text_raw
assert run['source_text_visible'] is False
assert run['input_artifacts'] == ['lean-statement', 'approved-definition-context']
assert run['decoder']['actor_identity'] == '/root/neutral_decoder_72b6'
input_raw = (phase / 'input.json').read_bytes()
assert sha(input_raw) == run['input_raw_sha256']
packet = json.loads(input_raw)
assert packet['packet_sha256'] == run['canonical_packet_sha256']
audit = json.loads(audit_path.read_bytes())
assert not audit['reconstruction'] and audit['verdict'] == 'pending'
assert sha(audit['lean']['statement'].encode()) == run['anonymous_statement_sha256']
create(evidence / 'decoder-original-run.json', run_raw)
create(evidence / 'decoder-original-reconstruction.md', text_raw)
create(evidence / 'decoder-original-custody.json', dump({
    'original_input_raw_sha256': sha(input_raw), 'original_run_raw_sha256': sha(run_raw),
    'canonical_run_sha256': canonical_hash, 'original_reconstruction_sha256': sha(text_raw),
    'run_object_unchanged': True, 'independent_actor': run['decoder']['actor_identity'],
    'input_categories': run['input_artifacts'], 'source_text_visible': False,
}))

# Keep mathematical scope stable when review phases later advance.
for path in (audit_path, lesson_path, pub_path, evidence / 'publication-draft-record.json'):
    create(workspace / 'publication-draft-v1-originals' / path, path.read_bytes())
lesson = json.loads(lesson_path.read_bytes())
pub = json.loads(pub_path.read_bytes())
item = pub['items'][0]
binding = item['bindings'][0]
boundary = (
    'The canonical row fourth matrix moment and the individual uncentered squared-summand PSD bound are compiled. '
    'The individual bound is the source-supported inference preceding the first aggregate inequality. '
    'Original-family law/integral transport, summed and centered variance, matrix concentration, full Lemma 4.4, '
    'both main lower bounds and oracle/TV/cost adapters remain open. Serialized integration, actual '
    'desktop/mobile delivery and purification remain pending.'
)
lesson['units'][0]['boundary'] = boundary
binding['boundary'] = boundary
lesson_path.write_bytes(dump(lesson))
pub_path.write_bytes(dump(pub))
publication.inputs.cache_clear()
publication.load.cache_clear()
audit['publication_binding_sha256'] = publication.binding_digest(item, binding)
audit['publication_context'] = publication.review_context(item, binding)
audit['state'] = 'blind-reconstructed'
audit['reconstruction'] = {
    'text': text_raw.decode(), 'text_sha256': sha(text_raw),
    'decoder': run['decoder']['actor_identity'], 'decoder_run_sha256': canonical_hash,
    'decoder_packet_sha256': packet['packet_sha256'], 'source_text_visible': False,
    'lean_statement_sha256': run['anonymous_statement_sha256'],
    'input_artifacts': run['input_artifacts'],
    'run_artifact': str(evidence / 'decoder-original-run.json'),
}
audit_path.write_bytes(dump(audit))
assert semantic.decoder_packet(audit) == packet
review_packet = semantic.semantic_reviewer_packet(audit)
review_path = evidence / 'anti-anchored-reviewer-packet.json'
create(review_path, dump(review_packet))
draft = json.loads((evidence / 'publication-draft-record.json').read_bytes())
draft['publication_binding_sha256'] = audit['publication_binding_sha256']
draft['exposition_revision'] = 'v2 removes transient review-phase status from mathematical scope; original v1 retained locally.'
(evidence / 'publication-draft-record.json').write_bytes(dump(draft))
publication.check_advance([audit['lean']['declaration']], reviewed=False)
create(evidence / 'publication-boundary-v2-readback.json', dump({
    'change': 'Removed transient independent-review phase status from the mathematical scope boundary.',
    'original_drafts': str(workspace / 'publication-draft-v1-originals'),
    'Lean_code_and_literal_statement_changed': False, 'decoder_packet_changed': False,
    'publication_binding_sha256': audit['publication_binding_sha256'],
    'reviewer_packet_sha256': review_packet['packet_sha256'],
}))
print(json.dumps({
    'decoder_original_raw_run_sha256': sha(run_raw), 'decoder_canonical_run_sha256': canonical_hash,
    'publication_binding_sha256': audit['publication_binding_sha256'],
    'anti_anchored_packet': str(review_path), 'anti_anchored_raw_sha256': sha(review_path.read_bytes()),
    'anti_anchored_packet_sha256': review_packet['packet_sha256'],
}))
