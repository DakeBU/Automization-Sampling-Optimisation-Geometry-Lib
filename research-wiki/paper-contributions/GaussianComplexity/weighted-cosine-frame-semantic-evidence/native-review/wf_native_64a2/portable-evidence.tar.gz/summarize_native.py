import collections,gzip,hashlib,json,pathlib
from run import ROOT
j=json.loads((ROOT/'native-environment-v2.json').read_text());by={x['name']:x for x in j}
assert len(j)==44
for c in j:
    assert c['body']!='NO_BODY'
    assert set(c['closure_axioms'])<={'propext','Classical.choice','Quot.sound'}
names=[n for n in by if not ('._proof_' in n or '._simp_' in n or '._abel_' in n)]
assert len(names)==6
producer=next(n for n in names if n.endswith('.actual_weighted_cosine_coefficient_bound'))
consumer=next(n for n in names if n.endswith('.actual_uncentered_second_moment_sum_bound'))
cosine=next(n for n in names if n.endswith('.actual_cosine_frame_gram'))
radial=next(n for n in names if n.endswith('.actual_radial_fourth_moment_matrix'))
assert cosine in by[producer]['direct_owned']
assert producer in by[consumer]['direct_owned'] and radial in by[consumer]['direct_owned']
assert set(names)<=set(by[consumer]['transitive_owned'])
unused=sorted(set(by)-set(by[consumer]['transitive_owned']))
assert all('._simp_' in n or '._proof_' in n or '._abel_' in n for n in unused)
assert consumer=='_private.Tests.GaussianComplexityFixedSpectrumWeightedFrameBound.0.AutoSamplingTheory.Tests.GaussianComplexityFixedSpectrumWeightedFrameBound.actual_uncentered_second_moment_sum_bound'
summary=[]
types=[]
for c in sorted(j,key=lambda c:c['name']):
    row={k:v for k,v in c.items() if k not in {'body','type','transitive_owned'}}
    row['full_body_utf8_bytes']=len(c['body'].encode());row['full_body_sha256']=hashlib.sha256(c['body'].encode()).hexdigest()
    row['full_type_sha256']=hashlib.sha256(c['type'].encode()).hexdigest()
    row['pretty_type_ellipsis_count']=c['type'].count('⋯')+c['type'].count('…')
    row['pretty_body_ellipsis_count']=c['body'].count('⋯')+c['body'].count('…')
    summary.append(row)
    if c['name'] in names:types.append(c['name']+'\n'+c['type']+'\n')
(ROOT/'native-six-authored-types.txt').write_text('\n'.join(types))
data={'candidate_commit':'401a3e1faa08fe2173d52017672831d2edbad38f','owned_constant_count':44,'authored_declarations':names,'module_counts':dict(collections.Counter(c['module'] for c in j)),'all_authored_reachable_from_private_consumer':True,'actual_private_name':consumer,'all_axioms':sorted({a for c in j for a in c['closure_axioms']}),'unreachable_compiler_auxiliaries':unused,'closure_count_consumer':by[consumer]['closure_constant_count'],'producer_direct_owned':by[producer]['direct_owned'],'consumer_direct_owned':by[consumer]['direct_owned'],'owned_constant_full_type_body_inventory':summary,'full_native_environment_file':'native-environment-v2.json.gz','status':'Native closure clean; no purification claim.'}
(ROOT/'native-inspection-summary.json').write_text(json.dumps(data,indent=2)+'\n')
with gzip.open(ROOT/'native-environment-v2.json.gz','wb') as f:f.write((ROOT/'native-environment-v2.json').read_bytes())
print(json.dumps({k:v for k,v in data.items() if k!='owned_constant_full_type_body_inventory'},indent=2))
