"""Local raw-source extraction only; no proof or implementation inspection."""
from pathlib import Path
from html.parser import HTMLParser
import hashlib, json, re, shutil

ROOT = Path('/Users/zhouhuanjian/ASTIS-GC')
OUT = ROOT / '.astis/huanjian-gc-fixed-spectrum-geometry-20261109/source-auditor'
RAW = ROOT / '.astis/huanjian-resume-20261103/2610.20492v1.html'
OUT.mkdir(parents=True, exist_ok=True)
(OUT/'inputs').mkdir(exist_ok=True)
source = RAW.read_text()

class Node:
    def __init__(self, tag, attrs, start, parent=None):
        self.tag, self.attrs, self.start, self.parent = tag, dict(attrs), start, parent
        self.end, self.children = start, []
    @property
    def id(self): return self.attrs.get('id')
    def walk(self):
        yield self
        for c in self.children:
            if isinstance(c, Node): yield from c.walk()
    def text(self):
        if self.tag == 'math': return '$'+self.attrs.get('alttext', '')+'$'
        if self.tag in ('annotation', 'annotation-xml'): return ''
        text = ''.join(c.text() if isinstance(c, Node) else c for c in self.children)
        if self.tag in ('p','section','div','table','tr','li','h2','h3','h4','h5'): text += '\n'
        return text

class Parser(HTMLParser):
    void = {'area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr'}
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.root=Node('ROOT', [], 0); self.stack=[self.root]; self.ids={}
        self.lines=[0]
        self.lines.extend(m.end() for m in re.finditer('\n',source))
    def pos(self):
        line,col=self.getpos(); return self.lines[line-1]+col
    def handle_starttag(self,tag,attrs):
        n=Node(tag,attrs,self.pos(),self.stack[-1]); self.stack[-1].children.append(n)
        if n.id: self.ids[n.id]=n
        if tag not in self.void: self.stack.append(n)
        else: n.end=self.pos()+len(self.get_starttag_text())
    def handle_startendtag(self,tag,attrs):
        self.handle_starttag(tag,attrs)
        if tag not in self.void: self.stack.pop().end=self.pos()+len(self.get_starttag_text())
    def handle_endtag(self,tag):
        for i in range(len(self.stack)-1,0,-1):
            if self.stack[i].tag==tag:
                end=source.find('>',self.pos())+1
                for n in self.stack[i:]: n.end=end
                del self.stack[i:]; return
    def handle_data(self,data): self.stack[-1].children.append(data)

p=Parser(); p.feed(source)
def clean(t): return re.sub(r'[ \t]+',' ',re.sub(r'\n\s*\n+','\n',t)).strip()
def sha(b): return hashlib.sha256(b).hexdigest()

instructions = ['AGENTS.md','docs/contributor-codex-contract.md','docs/theorem-publication-protocol.md',
                'docs/proof-digestion-protocol.md','docs/evidence-routed-memory-protocol.md',
                '.agents/skills/astis-source-dependency-audit/SKILL.md']
read_manifest=[]
for rel in instructions+[str(RAW.relative_to(ROOT))]:
    path=ROOT/rel; b=path.read_bytes()
    dst=OUT/'inputs'/('paper.html' if path==RAW else rel.replace('/','__'))
    shutil.copyfile(path,dst)
    read_manifest.append({'path':rel,'sha256':sha(b),'bytes':len(b),'preserved':str(dst.relative_to(ROOT))})
(OUT/'read-hashes.json').write_text(json.dumps({'phase':'PHASE1_SOURCE_ONLY','files':read_manifest},indent=2)+'\n')

anchors=['S2','S4.SS1','S4.Thmtheorem6','A3.SS4',
         'S4.SS2.SSS0.Px4.p1.1','S4.Thmtheorem1','bib.bib3']
regions=[]
for anchor in anchors:
    n=p.ids[anchor]
    raw=source[n.start:n.end].encode()
    (OUT/f'{anchor}.raw.html').write_bytes(raw)
    (OUT/f'{anchor}.source.txt').write_text(clean(n.text())+'\n')
    regions.append({'anchor':anchor,'raw_sha256':sha(raw),'raw_bytes':len(raw),
                    'source_start_line':source.count('\n',0,n.start)+1,'source_end_line':source.count('\n',0,n.end)+1})

items=[]
selected=set()
for anchor in anchors:
    for n in p.ids[anchor].walk():
        cls=n.attrs.get('class','')
        isunit=(n.tag=='p' or ('ltx_equation' in cls and n.id) or 'ltx_theorem' in cls or 'ltx_bibitem' in cls)
        if isunit and n.id not in selected:
            selected.add(n.id)
            raw=source[n.start:n.end].encode()
            items.append({'anchor':n.id,'tag':n.tag,'class':cls,'source_region':anchor,
                          'line_start':source.count('\n',0,n.start)+1,'line_end':source.count('\n',0,n.end)+1,
                          'raw_sha256':sha(raw),'text':clean(n.text()),
                          'links':[{'href':c.attrs.get('href'),'text':clean(c.text())} for c in n.walk() if c.tag=='a']})
(OUT/'source-regions.json').write_text(json.dumps(regions,indent=2)+'\n')
(OUT/'source-items.raw.json').write_text(json.dumps(items,indent=2,ensure_ascii=False)+'\n')
atoms=[]
seen=set()
for anchor in anchors:
    for n in p.ids[anchor].walk():
        if n.tag not in ('math','a') or n.start in seen: continue
        seen.add(n.start)
        parent=n.parent
        while parent and parent.tag!='p' and not (parent.tag=='table' and parent.id and 'ltx_equation' in parent.attrs.get('class','').split()):
            parent=parent.parent
        atoms.append({'atom_id':n.id or 'link@'+str(n.start),'kind':n.tag,
                      'source_region':anchor,'container':parent.id if parent else anchor,
                      'line_start':source.count('\n',0,n.start)+1,
                      'raw_sha256':sha(source[n.start:n.end].encode()),
                      'text':n.attrs.get('alttext') if n.tag=='math' else clean(n.text()),
                      'href':n.attrs.get('href')})
(OUT/'source-atoms.raw.json').write_text(json.dumps(atoms,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'paper_sha256':sha(RAW.read_bytes()),'regions':regions,'source_units':len(items)},indent=2))
