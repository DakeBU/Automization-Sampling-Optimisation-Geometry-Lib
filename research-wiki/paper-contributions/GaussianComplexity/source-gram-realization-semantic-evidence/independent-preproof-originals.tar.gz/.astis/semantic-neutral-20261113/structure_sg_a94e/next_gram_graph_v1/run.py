from pathlib import Path
import datetime,hashlib,json,subprocess,sys
ROOT=Path('/Users/zhouhuanjian/ASTIS-GC');OUT=Path(__file__).resolve().parent
def run(label,argv):
 started=datetime.datetime.now(datetime.timezone.utc).isoformat();p=subprocess.run(argv,cwd=ROOT,capture_output=True)
 (OUT/f'{label}.stdout').write_bytes(p.stdout);(OUT/f'{label}.stderr').write_bytes(p.stderr)
 (OUT/f'{label}.receipt.json').write_text(json.dumps({'started_utc':started,'cwd':str(ROOT),'argv':argv,'exit_code':p.returncode,'stdout_sha256':hashlib.sha256(p.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(p.stderr).hexdigest()},indent=2)+'\n')
 sys.stdout.buffer.write(p.stdout);sys.stderr.buffer.write(p.stderr);return p.returncode
if __name__=='__main__':raise SystemExit(run(sys.argv[1],sys.argv[2:]))
