from pathlib import Path
import json, hashlib, subprocess, datetime, gzip, sys
sys.dont_write_bytecode=True
sys.path.insert(0,'tools')
import astis_advance as adv
W=Path(__file__).parent
sha=lambda b:hashlib.sha256(b).hexdigest()
def ref(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def put(p,o):
 assert not p.exists(),p
 p.write_text(json.dumps(o,ensure_ascii=False,indent=2)+'\n')
def git(*args):return subprocess.check_output(['git',*args],text=True).strip()
assert git('rev-parse','HEAD')=='e8427141e6119012745a8913596c38c3b0600dbc'
probe=W/'StatementFormation.lean'; raw=probe.read_bytes()
assert sha(raw)=='9283deca044ecbe34936a0688b999e95035ecac2ddff951bb7e239e77247ceca'
preserved=W/'statement-formation-probe.raw.lean.txt'; assert not preserved.exists();preserved.write_bytes(raw)
compressed=W/'StatementFormation.lean.gz';assert not compressed.exists();compressed.write_bytes(gzip.compress(raw,mtime=0))
assert gzip.decompress(compressed.read_bytes())==raw
probe.unlink()
assert not probe.exists()
rp=Path('.astis/huanjian-resume-20261103/20261110T033018075465Z-threshold-literal-Prop-only-statement-formation.receipt.json')
rr=json.loads(rp.read_bytes());assert rr['exit_code']==0 and sha(Path(rr['log']).read_bytes())==rr['log_sha256']
source=Path('.astis/huanjian-resume-20261103/2610.20492v1.html')
assert sha(source.read_bytes())=='6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
version=subprocess.check_output(['lake','env','lean','--version'],text=True).strip()
prefix=subprocess.check_output(['lake','env','lean','--print-prefix'],text=True).strip();binary=Path(prefix)/'bin/lean'
assert '4.33.0' in version and sha(binary.read_bytes())=='1b370cfcbf44e80d1b004ab1b1ab9a4c73951f9f7c242140bcff9bc577576554'
manifest=Path('lake-manifest.json');assert sha(manifest.read_bytes())=='b83ca83b9cf7caa85fa8b023c2ff9a3fb7a7cce7e1c332e810c348535ec49c37'
packages=[]
for row in json.loads(manifest.read_bytes())['packages']:
 p=Path('.lake/packages')/row['name']; h=git('-C',str(p),'rev-parse','HEAD');st=git('-C',str(p),'status','--porcelain')
 assert h==row['rev'] and not st
 packages.append({'name':row['name'],'actual_HEAD':h,'manifest_rev':row['rev'],'clean':True})
L=Path('runs/substantive_advances.jsonl');states=adv._replay_advances([json.loads(x) for x in L.read_bytes().splitlines()])
put(W/'preproof-baseline.json',{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'working_HEAD':git('rev-parse','HEAD'),'Lean_actual':version,'binary':ref(binary),'manifest':ref(manifest),'packages':packages,'ledger':ref(L),'all_current_SAU_states':states,'all_frontier_hashes':{str(p):sha(p.read_bytes()) for p in Path('research-wiki/frontier-cells').glob('*.json')},'no_new_SAU_API_STAB_or_proof':True})
prod=(W/'producer-signature.txt').read_text();cons=(W/'consumer-signature.txt').read_text()
assert not Path('AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumThreshold.lean').exists()
assert not Path('Tests/GaussianComplexityFixedSpectrumThreshold.lean').exists()
producer={'name':'AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumThreshold.eventual_actual_gaussian_threshold_small','planned_file':'AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumThreshold.lean','signature':prod,'signature_sha256':sha(prod.encode()),'definition_kind':'literal'}
consumer={'name':'actual_gaussian_source_query_shifted_event_le_tenth','planned_file':'Tests/GaussianComplexityFixedSpectrumThreshold.lean','signature':cons,'signature_sha256':sha(cons.encode()),'definition_kind':'literal','is_source_anchor':False,'Registry_node':False,'scope_difference':'PRIVATE actual diagonal Gaussian bad-event probability for the concrete shifted contrast, corresponding to the source target-side probability step before rotation transport. Not the rotated matrix-polynomial detector or a full algorithmic statement.'}
binders=[]
for owner in ['producer','private_consumer']:
 for binder,kind,reason in [
  ('C:Real','TYPING','Fixed numeric coefficient of the literal tau formula, quantified before delta and before cutoff.'),
  ('0<C','SOURCE','Source tau coefficient is positive. This PARAMETERIZED NUMERIC FAMILY proves a stronger for-each-positive-scale property; it does NOT assume or assert any concentration theorem or witness for C, or change the MAIN lower-bound premises.'),
  ('delta:Real','TYPING','Fixed real parameter.'),('0<delta;delta<1','SOURCE','Original fixed delta in(0,1).'),
  ('FORALL d:Nat','TYPING','Natural dimension.'),('d0<=d','SOURCE','Sufficiently large dimension after internally produced cutoff.'),
  ('FORALL kappa:Real','TYPING','Condition number.'),('2<=kappa;kappa<=(d:Real)^(1-delta)','SOURCE','Original closed condition range.'),
  ('FORALL q:Nat','TYPING','Nonnegative integer deterministic query cap, including0.'),
  ('(q:Real)<=(delta/256)*sqrt(kappa)*log(d:Real)','SOURCE','Original exact worst-case query cap; not expected cost.')]:
  binders.append({'owner':owner,'binder':binder,'class':kind,'reason':reason})
defs=[
 {'object':'C,delta,d0,d,kappa,q,n','definition_kind':'literal','meaning':'Fixed positive numerical C before fixed delta; natural output cutoff d0(C,delta) before ALL varying d,kappa,q. Literal n=2*q+1. No existential choice/default C and no assertion C satisfies an unproved probability bound.'},
 {'object':'theta,eigenvalue,Lambda','definition_kind':'literal','meaning':'Source midpoint grid, Fin d zero-based i.val corresponds to source i=i.val+1; Lambda is diagonal precision.'},
 {'object':'mu','definition_kind':'literal','meaning':'Actual centered multivariateGaussian with covariance Lambda inverse. Spectral positivity, inverse identity, Gaussian law semantics and integrability are internal dependencies, never new premise.'},
 {'object':'Q,M,b,beta','definition_kind':'literal','meaning':'Actual cosine quadratic Q; actual Bochner norm-square and cosine means M,b; beta=abs(b)/M. M positivity/sign/real quotient domain internally established.'},
 {'object':'tau','definition_kind':'literal','meaning':'Exact C*((q+1)*sqrt(log(d)/d)+(q+1)*(q+1+log(d))*log(d)/d), with REAL casts before +1. No asymptotic proxy substituted in the statement.'},
 {'object':'event,toReal','definition_kind':'standard literal','meaning':'Actual bad event sign(Q)-2*tau*norm^2<=0 under literal diagonal law; real mass converted only after finite-measure justification. No arbitrary input random law, free integrability or probability certificates.'}]
boundary=['No existence/concentration validity of the absolute C in Lemma4.4','No Krylov/deferred rotation/Haar/adaptive history/algorithm output law','No rotated Gaussian transport or Chebyshev matrix-polynomial detector identity','No full Ex26/Theorem4.1 or determinant-sign lower bound','No TV/precision/oracle/cost adapters or expected/worst-cap comparison','No global integration, site/browser/public delivery, purification/Exposition Seal or whole-Goal completion']
seal={'schema_version':1,'seal_id':'GC-FIXED-SPECTRUM-CONCRETE-THRESHOLD-20261110-v1','state':'EXACT_LITERAL_TYPES_FORMED_PREPROOF_SOURCE_TOPOLOGY_PENDING','source':{'title':'On Complexity of Gaussian Sampling','version':'arXiv2610.20492v1','raw':ref(source),'standing_anchors':['S4.SS1','S4.Thmtheorem4','S4.Thmtheorem5','S4.SS3'],'scope':'Concrete tau scalar-family smallness against actual Gaussian beta, plus PRIVATE genuine shifted diagonal-law bad-event probability. C is universally fixed numeric scale; no concentration witness or new main-bound assumption.'},'producer':producer,'actual_private_consumer':consumer,'binder_audit':binders,'existential_output_audit':[{'owner':o,'output':'EXISTS d0:Nat','is_input_assumption':False,'class':None,'depends_only_on':['C','delta','fixed universal numerical/source constants'],'order':'After C positivity and fixed delta guards; before all d,kappa,q. If future concentration theorem produces one absolute C before delta, this instantiates d0(delta), not a new MAIN hypothesis.'} for o in ['producer','private_consumer']],'EXCESS_public_binders':[],'no_project_owned_Prop_alias_inputs':True,'definition_audit':defs,'internal_dependencies_not_extra_binders':['tau finite/power/log estimates and smallness','mode/gap validity','actual Gaussian positivity/integrability/signed bias polynomial lower','actual contrast moments/variance and signal strength','finite measure and Chebyshev/event inclusion'],'source_generalization_explicit':'Numeric C-family only; not a claimed full transcription of Lemma4.4 or Theorem4.1. The existence of a source-valid absolute concentration C remains open and must later be proved as dependency, never put on MAIN premises.','scope_boundary':boundary,'statement_formation':{'receipt':ref(rp),'proof_credit':False,'exit_code':0,'preserved_probe':ref(preserved),'lossless_gzip':ref(compressed),'temporary_Lean_probe_currently_absent':True},'preseal_exposure':ref(W/'preseal-exposure-disclosure.json'),'shared_floor_audit':{'exact_name_search':'No existing FixedSpectrumThreshold/eventual_actual_gaussian_threshold_small/source_query_shifted_event match in GaussianComplexity,Tests/frontier cells. Generic log asymptotic name search only; no proof experiment or new theorem body.','decision':'provisional reuse existing canonical actual Gaussian spine; exact parents and any repeated estimate audited after compilation','new_shared_node':False},'role_boundary':'Root sole proof worker. Independent source graph and different topology/binder/definition admission required before target proof/API search. No normal SAU or transition by this seal.'}
put(W/'statement-seal-v1.json',seal)
projection={'purpose':'After own raw-first freeze: exact target and literal definition context ONLY. No implementation, root proof plan, dependency suggestions or verdicts. Independently audit C family and cutoff semantics.','source':seal['source'],'producer':producer,'actual_private_consumer':consumer,'definition_audit':defs,'scope_boundary':boundary}
put(W/'strict-preproof-seal-projection-v1.json',projection)
print(json.dumps({'seal':ref(W/'statement-seal-v1.json'),'projection':ref(W/'strict-preproof-seal-projection-v1.json'),'states':len(states),'frontiers':len(list(Path('research-wiki/frontier-cells').glob('*.json'))),'temporary_probe_absent':True,'proof_or_API_started':False}))
