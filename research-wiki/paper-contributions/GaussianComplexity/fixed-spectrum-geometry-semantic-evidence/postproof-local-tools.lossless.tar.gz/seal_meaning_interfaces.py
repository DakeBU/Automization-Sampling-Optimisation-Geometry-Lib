from pathlib import Path
import datetime, gzip, hashlib, json, re, subprocess, sys

P = Path('.astis/huanjian-gc-fixed-spectrum-geometry-20261109')
B = Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-geometry-semantic-evidence')
BASE = '760daf7772fbb26932791a55a6f24ed27f8c533a'
sha = lambda b: hashlib.sha256(b).hexdigest()
dump = lambda x: (json.dumps(x, ensure_ascii=False, indent=2)+'\n').encode()
ref = lambda p: {'path': str(p), 'sha256': sha(p.read_bytes())}
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == BASE
assert not subprocess.check_output(['git', 'diff', 'HEAD', '--name-only']).strip()
assert subprocess.check_output(['git', 'rev-parse', 'origin/main'], text=True).strip() == 'd9bcd4231df69061c5221f8d557ee179a945c1eb'
subprocess.run(['git', 'merge-base', '--is-ancestor', 'origin/main', 'HEAD'], check=True)
version = subprocess.check_output(['/Users/zhouhuanjian/.elan/bin/lake', 'env', 'lean', '--version'], text=True)
assert 'version 4.33.0' in version and 'd8b18978322de05a8f3dba51ef03cf5461676c17' in version
assert sha(Path('lake-manifest.json').read_bytes()) == 'b83ca83b9cf7caa85fa8b023c2ff9a3fb7a7cce7e1c332e810c348535ec49c37'
assert subprocess.check_output(['git', '-C', '.lake/packages/mathlib', 'rev-parse', 'HEAD'], text=True).strip() == 'db584cd6d46c92f209a44c0f1c829460d327499d'
assert not subprocess.check_output(['git', '-C', '.lake/packages/mathlib', 'status', '--short', '--untracked-files=no']).strip()
source = Path('.astis/huanjian-resume-20261103/2610.20492v1.html')
assert sha(source.read_bytes()) == '6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
assert len(source.read_bytes()) == 951991
sys.path.insert(0, 'tools')
import astis_advance
states = astis_advance.current_advances()
assert len(states) == 285 and not any(v['state'] == 'STABILIZING' for v in states.values())
frontiers = {str(p): sha(p.read_bytes()) for p in Path('research-wiki/frontier-cells').rglob('*.json')}
assert len(frontiers) == 444
B.mkdir(parents=True)
baseline = {'base_commit': BASE, 'origin_main': 'd9bcd4231df69061c5221f8d557ee179a945c1eb',
    'all285_existing_SAU_states': states, 'all444_existing_frontier_raw_hashes': frontiers,
    'all_discovery_states': astis_advance.current_discoveries(),
    'ledger_sha256': sha(Path('runs/substantive_advances.jsonl').read_bytes()),
    'discovery_ledger_sha256': sha(Path('runs/substantive_discoveries.jsonl').read_bytes()),
    'git_index_sha256': sha(subprocess.check_output(['git', 'ls-files', '-s', '-z'])),
    'graph_models': {name: sha(Path(name).read_bytes()) for name in
        ['website/content/graph_memory_index.json', 'website/content/functor_hypergraph.json']}}
z = B/'existing-state-baseline.raw.json.gz'
z.write_bytes(gzip.compress(dump(baseline), mtime=0))
assert gzip.decompress(z.read_bytes()) == dump(baseline)
checks = B/'preseal-actual-checks'
checks.mkdir()
receipt_names = [
    '20261108T163234421218Z-fixed-spectrum-preintegration-origin-main-network',
    '20261108T163643251577Z-fixed-spectrum-geometry-statement-meaning-only',
    '20261108T163841968508Z-fixed-spectrum-geometry-statement-meaning-explicit-matrix-types']
actual = []
for name in receipt_names:
    p = Path('.astis/huanjian-resume-20261103')/(name+'.receipt.json')
    d = json.loads(p.read_bytes())
    raw = Path(d['log']).read_bytes()
    assert sha(raw) == d['log_sha256'] and d['head_before'] == d['head_after'] == BASE
    (checks/p.name).write_bytes(p.read_bytes())
    q = checks/(Path(d['log']).name+'.gz')
    q.write_bytes(gzip.compress(raw, mtime=0))
    assert gzip.decompress(q.read_bytes()) == raw
    actual.append({'receipt': ref(p), 'exit_code': d['exit_code'], 'raw_log_sha256': sha(raw)})
assert [r['exit_code'] for r in actual] == [0, 1, 0]
probe = P/'StatementMeaningProbe.lean'
probe_raw = probe.read_bytes()
text = probe_raw.decode()
producer = re.search(r'def producerStatement([\s\S]*?)(?=\ndef consumerStatement)', text).group(1)
consumer = re.search(r'def consumerStatement([\s\S]*?)(?=\n#check producerStatement)', text).group(1)
producer = ('theorem actual_potential_geometry'+producer.replace(': Prop :=', ':', 1)).rstrip()+'\n'
consumer = ('private theorem actual_first_order_oracle_measurable'+consumer.replace(': Prop :=', ':', 1)).rstrip()+'\n'
for name, raw in [('successful-meaning-probe.raw.lean.gz', gzip.compress(probe_raw, mtime=0)),
                  ('failed-v1-meaning-probe.raw.lean.gz', (P/'StatementMeaningProbe.v1-failed.raw.lean.gz').read_bytes())]:
    (B/name).write_bytes(raw)
definitions = B/'necessary-definition-context'
definitions.mkdir()
windows = [
    ('StrongConvexOn', 'Analysis/Convex/Strong.lean', 118, 119),
    ('UniformConvexOn', 'Analysis/Convex/Strong.lean', 41, 43),
    ('ContDiff', 'Analysis/Calculus/ContDiff/Defs.lean', 1068, 1072),
    ('gradient', 'Analysis/Calculus/Gradient/Basic.lean', 82, 83),
    ('HasFDerivAt', 'Analysis/Calculus/FDeriv/Defs.lean', 118, 122),
    ('toEuclideanCLM', 'Analysis/CStarAlgebra/Matrix.lean', 103, 108),
    ('IsMinFilter', 'Order/Filter/Extr.lean', 98, 99),
    ('IsMinOn', 'Order/Filter/Extr.lean', 110, 111),
    ('Measurable', 'MeasureTheory/MeasurableSpace/Defs.lean', 490, 494),
    ('borel', 'MeasureTheory/Constructions/BorelSpace/Basic.lean', 49, 52)]
meaning_refs = []
for name, rel, first, last in windows:
    p = Path('.lake/packages/mathlib/Mathlib')/rel
    raw = b''.join(p.read_bytes().splitlines(keepends=True)[first-1:last])
    q = definitions/(name+'.raw.txt')
    q.write_bytes(raw)
    meaning_refs.append({'name': name, 'file': str(p), 'first_line': first, 'last_line': last,
                         'raw_window': ref(q), 'full_file_sha256': sha(p.read_bytes())})
binder_audit = [
    {'binder': 'd : Nat', 'classification': 'TYPING', 'meaning': 'Source Euclidean dimension; the source family range is hd.'},
    {'binder': 'hd : 2 <= d', 'classification': 'SOURCE', 'meaning': 'S4.1 actual cosine-grid hard-family standing range, retained for both interfaces.'},
    {'binder': 'kappa : Real', 'classification': 'TYPING', 'meaning': 'Source real condition parameter.'},
    {'binder': 'h_kappa : 2 <= kappa', 'classification': 'SOURCE', 'meaning': 'S4.1 hard-family range; positivity, finiteness and any Hessian bounds are produced internally.'},
    {'binder': 'O : full real orthogonalGroup (Fin d)', 'classification': 'SOURCE', 'meaning': 'Every source O in O(d), including both determinant signs; no special-orthogonal restriction or Haar/algorithm assumption.'}]
definition_audit = [
    {'name': 'theta/A/f/query local lets', 'definition_kind': 'literal', 'meaning': 'Exactly the0-based reindexing of source one-based cosine nodes, full OLambdaOtranspose, half quadratic and actual same-A matvec. Definitions are total literal formulas, with no default/fallback branch.'},
    {'name': 'ContDiff Real infinity f', 'definition_kind': 'standard', 'meaning': 'Ordinary C-infinity (all finite differentiability orders), not analytic omega; its conclusion must be proved internally.'},
    {'name': 'HasFDerivAt (gradient f) (Matrix.toEuclideanCLM A)', 'definition_kind': 'standard-characterized-under-produced-regularity', 'meaning': 'Genuine Frechet derivative of the Euclidean gradient, i.e. source Hessian A in the standard Euclidean basis. Explicit Real/Fin d type arguments resolve the matrix equivalence coercion. Do not exploit default fderiv/gradient values: genuine first derivative existence and new C-infinity/second derivative must be internally established.'},
    {'name': 'StrongConvexOn univ1', 'definition_kind': 'standard', 'meaning': 'Uniform convexity with modulus r^2/2. The coefficient1/2 agrees with source1-strong convexity, and all-space convexity is a conclusion rather than a premise.'},
    {'name': 'kappa-smooth norm inequality', 'definition_kind': 'literal', 'meaning': 'Global Euclidean gradient Lipschitz bound with the source real kappa itself; no toNNReal/default off-domain interpretation.'},
    {'name': 'IsMinOn f univ x iff x=0', 'definition_kind': 'standard', 'meaning': 'All and only global minimizers are0; univ makes the predicate lack-of-membership convention harmless. Separate f0=0 is also produced.'},
    {'name': 'explicit @Measurable between borel Euclidean and borel Real-times-Euclidean', 'definition_kind': 'literal-standard', 'meaning': 'Actual preimages between the standard topologically generated Borel sigma algebras, for each fixed source O. No arbitrary sigma algebra, assumed regularity, input seed, probability measure or joint-in-O statement is inserted.'}]
exposure = {
    'status': 'DISCLOSED_PRESEAL_MEANING_AND_NAME_INVENTORY_ONLY',
    'source_and_parent_memory': 'Root already authored/knows the accepted earlier admissibility and first-order packets; this cannot be represented as zero ambient cues. Independent source-only roles will receive no implementation proof or this reuse/exposure rationale before their raw source cognition freezes.',
    'actual_inventory': ['GaussianComplexity filename inventory and existing regularity/minimizer/eigenbasis metadata targets (different sign/block family, not duplicate actual cosine-grid geometry)',
        'Generic shared filenames and declaration-name/first-header-line inventory only in HessianStrongConvexity, StrongConvexMinimizer and QuadraticGradientDescent; no theorem proof bodies or full target proof APIs retrieved',
        'Necessary standard definition windows above, and earlier actualFirstOrder public signature only'],
    'incidental_adjacent_exposure': ['ContDiff definition read1068-1077 also exposed generic HasFTaylorSeriesUpTo.contDiff header and its two-line existential constructor proof.',
        'Borel definition read49-54 exposed borel_anti header only; no body.',
        'Matrix.toEuclideanCLM complete literal equivalence body includes its structure map_mul/map_star fields.'],
    'implementation_started': False, 'target_proof_search_started': False,
    'independent_source_admission_required_before_further_proof_API_retrieval': True,
    'type_scaffold_failure': 'Initial uninstantiated toEuclideanCLM equivalence application failed type elaboration; explicit Real/Fin d arguments fixed the same mathematical proposition. Both raw probes/logs retained. hd/hkappa unused warnings in proposition-only probes do not remove source premises.'}
seal = {'schema': 'exact-source-statement-and-binder-definition-seal-v1',
    'status': 'ELABORATED_ROOT_SEALED_INDEPENDENT_SOURCE_GRAPH_AND_TOPOLOGY_PENDING',
    'sealed_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'base_commit': BASE,
    'source_revision': 'arXiv:2610.20492v1', 'source': ref(source),
    'source_bytes': len(source.read_bytes()), 'source_anchors': ['S4.SS1/S4.E11', 'S4.Thmtheorem6 (Lemma4.6)', 'A3.SS4 (AppendixC.4)', 'S2 exact-oracle/Borel-algorithm context'],
    'producer': {'declaration': 'AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumGeometry.actual_potential_geometry',
        'planned_file': 'AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumGeometry.lean',
        'signature': producer, 'signature_sha256': sha(producer.encode())},
    'private_actual_consumer': {'name': 'actual_first_order_oracle_measurable',
        'planned_file': 'Tests/GaussianComplexityFixedSpectrumGeometry.lean',
        'signature': consumer, 'signature_sha256': sha(consumer.encode()),
        'actual_use_required': 'Substantively consume new producer C-infinity and genuine gradient derivative to establish regularity, and reuse the canonical actualFirstOrder gradient/reply identification on the SAME literal O/A/f/query. Produce Borel measurability of the real exact reply. Not a wrapper, assumed measurability input, Registry node, joint-(O,x) claim or operational cost theorem.',
        'real_downstream_use': 'Fixed-input Borel composition of seed/query/response in the actual adaptive oracle model; full history/joint/prior/precision/cap/TV/expected-cost adapters still pending.'},
    'binder_audit': binder_audit, 'EXCESS_binders': [], 'definition_audit': definition_audit,
    'necessary_standard_definitions': meaning_refs, 'preseal_exposure_audit': exposure,
    'actual_type_elaboration': actual[-1], 'mathematical_proof_or_Lean_theorem_compiled': False,
    'remaining_truth_boundary': 'No next mathematical proof, source graph/topology admission, SAU claim, PLOC/V, production/publication/Registry/model/shared edit or main-bound/remote/purification/wholeGoal completion yet. Both original main dimension/condition/TV ranges, exact matvec access and deterministic worst-query caps remain separate. Expected costs require explicit later adaptation.'}
seal_path = Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-geometry-statement-seal.json')
assert not seal_path.exists()
seal_path.write_bytes(dump(seal))
intake = {'base_commit': BASE, 'origin_main': baseline['origin_main'],
    'lean_actual_version_stdout': version, 'manifest': ref(Path('lake-manifest.json')),
    'Mathlib_commit': 'db584cd6d46c92f209a44c0f1c829460d327499d', 'Mathlib_tracked_clean': True,
    'source': ref(source), 'source_bytes': len(source.read_bytes()), 'existing_state_baseline': ref(z),
    'existing_SAUs': len(states), 'existing_raw_frontiers': len(frontiers), 'STAB': [],
    'process_memory': ref(Path('research-wiki/process-memory.json')),
    'process_memory_selection': 'All3 entries read; measure-role and zero/inverse-domain lessons are scoped process/negative knowledge, not new mathematical premises. None supplies a theorem for this packet.',
    'remote_PR385_actual_tool_readback_summary': {'head': '5a257960edfbeff0905d1ee938db32bb7303ea7e', 'state': 'OPEN', 'mergeStateStatus': 'UNSTABLE', 'native-runtime': 'FAILURE', 'formalization': 'SUCCESS', 'deploy': 'SKIPPED', 'owner_release_confirmed': False,
        'evidence_kind': 'Summary of actual foreground gh pr view tool output during this intake; not represented as a newly captured raw command log. No CI retry, owner edit, push or merge.'},
    'actual_checks': actual, 'statement_seal': ref(seal_path),
    'new_proof_or_source_verdict_or_claim': False, 'Goal_complete': False}
(B/'preseal-intake-and-preservation.json').write_bytes(dump(intake))
assert gzip.decompress((B/'successful-meaning-probe.raw.lean.gz').read_bytes()) == probe_raw
probe.unlink()
assert not probe.exists()
print(json.dumps({'statement_seal': ref(seal_path), 'producer_signature_sha256': seal['producer']['signature_sha256'],
    'consumer_signature_sha256': seal['private_actual_consumer']['signature_sha256'],
    'intake': ref(B/'preseal-intake-and-preservation.json'), 'source_admission': 'PENDING',
    'temporary_probe_deleted_after_lossless_freeze': True, 'mathematical_proof_or_state_API': False}))
