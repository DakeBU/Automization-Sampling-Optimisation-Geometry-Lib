from pathlib import Path
import hashlib
import json
import shutil

ROOT = Path('/Users/zhouhuanjian/ASTIS-GC')
BASE = ROOT / '.astis/semantic-neutral-20261110/src_a74f20'
OUT = BASE / 'phase1'

def digest(data):
    return hashlib.sha256(data).hexdigest()

def write_json(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')

commands = [
    {'kind':'exec_command','command':'for p in /AGENTS.md /Users/AGENTS.md /Users/zhouhuanjian/AGENTS.md /Users/zhouhuanjian/ASTIS-GC/AGENTS.md; do if [ -f "$p" ]; then printf \'\\nFILE %s\\n\' "$p"; cat "$p"; fi; done','output_chunk_id':'ce447d','exit_code':0,'note':'Only repository AGENTS existed and was emitted.'},
    {'kind':'exec_command','command':"rg -n 'source reviewer|source-review|anti.anchor|encoder|denois|round.trip|SKILL|source cognition|freeze|blind' docs/proof-digestion-protocol.md docs/theorem-publication-protocol.md docs/evidence-routed-memory-protocol.md",'output_chunk_id':'8e0361','exit_code':0},
    {'kind':'exec_command','command':'cat .agents/skills/astis-semantic-roundtrip/SKILL.md','output_chunk_id':'9204c0','exit_code':0},
    {'kind':'exec_command','command':"sed -n '1,100p' docs/proof-digestion-protocol.md\nsed -n '156,190p' docs/theorem-publication-protocol.md",'output_chunk_id':'b1744d','exit_code':0},
    {'kind':'apply_patch','change':'Add own extract_source.py','output_id':None,'actual_result':{},'note':'No tool-generated output ID or process exit code was exposed for this patch.'},
    {'kind':'exec_command','command':'python3 .astis/semantic-neutral-20261110/src_a74f20/extract_source.py S4.SS1 S4.Thmtheorem5 A3.SS3','output_chunk_id':'415b94','exit_code':0,'note':'Complete selected source sections emitted, no truncation.'},
    {'kind':'apply_patch','change':'Add metadata mode to own extract_source.py','output_id':None,'actual_result':{}},
    {'kind':'exec_command','command':'python3 .astis/semantic-neutral-20261110/src_a74f20/extract_source.py --metadata S4.SS1 S4.Thmtheorem5 A3.SS3','output_chunk_id':'1ad7dc','exit_code':0,'note':'Metadata output was truncated. Full own metadata JSON files were written. The preceding complete source section output was not truncated.'},
    {'kind':'exec_command','command':'python3 .astis/semantic-neutral-20261110/src_a74f20/extract_source.py bib.bib3','output_chunk_id':'450e6f','exit_code':0},
    {'kind':'exec_command','command':"python3 - <<'PY'\nimport json\nfrom pathlib import Path\np=Path('.astis/semantic-neutral-20261110/src_a74f20/phase1/A3.SS3.metadata.json')\nfor x in json.loads(p.read_text()):\n    if x['tag'] in ['table','tbody'] or x['id'] in ['A3.Thmtheorem7','A3.Thmtheorem8','A3.SS3.2','A3.SS3.3','A3.SS3.4']:\n        print(x['tag'],x['id'],x['text'])\nPY",'output_chunk_id':'62d689','exit_code':0,'note':'Ran independently in same functions.exec as the bibliography extraction.'},
    {'kind':'apply_patch','change':'Add own phase1/source-cognition.md','output_id':None,'actual_result':{}},
    {'kind':'apply_patch','change':'Add own freeze_phase1.py (this file)','output_id':None,'actual_result':{}},
    {'kind':'exec_command','command':'for p in .astis/AGENTS.md .astis/semantic-neutral-20261110/AGENTS.md .astis/semantic-neutral-20261110/src_a74f20/AGENTS.md .astis/semantic-neutral-20261110/src_a74f20/phase1/AGENTS.md; do if [ -f "$p" ]; then printf \'\\nFILE %s\\n\' "$p"; cat "$p"; fi; done','output_chunk_id':'9bdffd','exit_code':0,'note':'No applicable nested AGENTS files existed at these explicit paths; output empty.'},
    {'kind':'apply_patch','change':'Record actual nested AGENTS check in own seal tooling','output_id':None,'actual_result':{}},
    {'kind':'exec_command','command':'python3 .astis/semantic-neutral-20261110/src_a74f20/freeze_phase1.py','output_chunk_id':None,'exit_code':None,'note':'Seal invocation recorded here without fabricated completion data. Its actual tool result is recorded in the separate post-seal receipt and final delivery; the manifest does not self-hash that receipt.'},
]
write_json('tool-commands.json', {'workdir':str(ROOT),'commands':commands,'tool_result_policy':'chunk IDs above are actual exec_command output IDs from this reviewer run. Null is not an invented ID. Patches exposed an empty object result. No transcript IDs are inferred.'})

raw_path = ROOT / '.astis/huanjian-resume-20261103/2610.20492v1.html'
raw_bytes = raw_path.read_bytes()
assert digest(raw_bytes) == '6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
(OUT / 'source-input.html').write_bytes(raw_bytes)

protocols = [
    ('AGENTS.md',None,'protocol-AGENTS.txt'),
    ('.agents/skills/astis-semantic-roundtrip/SKILL.md',None,'protocol-semantic-roundtrip.txt'),
    ('docs/proof-digestion-protocol.md',(1,100),'protocol-proof-digestion-lines1-100.txt'),
    ('docs/theorem-publication-protocol.md',(156,190),'protocol-publication-lines156-190.txt'),
]
protocol_records=[]
for relative, interval, output in protocols:
    data=(ROOT/relative).read_bytes()
    selected=data if interval is None else b''.join(data.splitlines(keepends=True)[interval[0]-1:interval[1]])
    (OUT/output).write_bytes(selected)
    protocol_records.append({'path':relative,'full_file_sha256_mechanically_hashed':digest(data),'semantic_read_range':'whole file' if interval is None else list(interval),'snapshot':output,'snapshot_sha256':digest(selected)})

rg_text = '''docs/evidence-routed-memory-protocol.md:115:## 6. Cross-route common-blind-spot audit
docs/evidence-routed-memory-protocol.md:124:required common-blind-spot audit is accepted or every alternative but one has
docs/evidence-routed-memory-protocol.md:129:After the common-blind-spot audit, if more than one route remains verified, a comparator selects the **default reader route**, not the only true route. It may compare source fidelity, assumption strength, reuse of canonical primitives, proof compression, and pedagogical readability. The selected route and reason are recorded, while all other verified alternatives remain explicit OR-routes in the Source Proof Graph.
docs/evidence-routed-memory-protocol.md:164:- common-blind-spot audit status;
docs/theorem-publication-protocol.md:106:| Semantic mismatch or proposed repair | Existing round-trip audit → Semantic fidelity & repair view |
docs/theorem-publication-protocol.md:146:Each requirement protects one boundary: Lean checks truth, round trips check
docs/theorem-publication-protocol.md:156:## Encoder–denoiser: required semantic round trip
docs/theorem-publication-protocol.md:158:Follow [.agents/skills/astis-semantic-roundtrip/SKILL.md](../.agents/skills/astis-semantic-roundtrip/SKILL.md).
docs/theorem-publication-protocol.md:173:3. Export the anonymous `decoder-packet` using the existing round-trip tool.
docs/theorem-publication-protocol.md:174:   Give **only this packet** to a distinct source-blind decoder. The publication
docs/theorem-publication-protocol.md:176:4. Export a fresh anti-anchored `reviewer-packet` for a reviewer distinct from
docs/theorem-publication-protocol.md:181:   Expose the gap and its reason publicly. A repair requires its own blinded-to-
docs/theorem-publication-protocol.md:230:historical round-trip debt. This is a fixed file-hash allowlist, not a contributor
docs/proof-digestion-protocol.md:7:`docs/theorem-publication-protocol.md`, and the semantic round-trip protocol.
docs/proof-digestion-protocol.md:33:- semantic round trip;
docs/proof-digestion-protocol.md:322:- the semantic encoder–denoiser review is accepted or the mismatch is published
docs/proof-digestion-protocol.md:449:encoder-denoiser/source review remains mandatory, and the four-view
docs/proof-digestion-protocol.md:455:The post-proof lifecycle is coupled to [the evidence-routed research-memory protocol](evidence-routed-memory-protocol.md). A failed route is not discarded until its salvage audit runs; non-mathematical failures never become negative mathematical evidence; process standing instructions are evidence-bound and cannot invent theorem content; parallel workers require distinct direction fingerprints; and parallel serious routes trigger a common-blind-spot audit. PURIFICATION additionally carries reader-backpressure state and an Exposition Seal so compressed prose cannot silently drop hypotheses or boundaries.
'''
(OUT/'protocol-rg-output-represented.txt').write_text(rg_text)

write_json('read-exposure.json', {
    'reviewer':'/root/source_reader_a74f20',
    'phase':'1/source-only/pre-candidate',
    'source':{'path':str(raw_path),'sha256':digest(raw_bytes),'byte_count':len(raw_bytes),'complete_snapshot':'source-input.html','mechanical_read':'Full bytes parsed by stdlib HTMLParser; full bytes also copied and hashed by seal tooling.','semantic_read_anchors':['S4.SS1','S4.Thmtheorem5','A3.SS3','bib.bib3'],'selected_source_complete_output_chunk_ids':['415b94','450e6f']},
    'protocol_inputs':protocol_records,
    'additional_protocol_matching_lines':{'snapshot':'protocol-rg-output-represented.txt','actual_output_chunk_id':'8e0361','note':'Text represented from actual bounded rg output; not claimed to be a separately captured process stdout file. Full bytes of searched files were searched mechanically, only matching lines emitted.'},
    'explicit_pre_read_cues':['Parent task named source identity and hash, Section4.1/Eq11, Lemma4.5, C.3, C.7/C.8, two means, variance and normalized bias scopes.','Parent task mentioned tbody rather than only table for Ex141-143/145-149.','Repository AGENTS and semantic roundtrip/proof-digestion protocols supplied review criteria.'],
    'incidental_exposures':['Entire AGENTS.md includes unrelated project scheduling, general source/Lean rules, conceptual mirrors and handoff prose. No candidate for this lemma was supplied there.','Raw Section4.1 includes the whole Remark4.2 with asymptotic comparison and references to Lemma4.4 and Theorem4.1, which were not opened.','Raw bibliography entry includes citation backlink labels to other sections; those sections were not opened.','Metadata run emitted a truncated duplicate representation of already-read source; own metadata follow-up emitted bounded display anchor map.'],
    'other_read_inputs':['Own extraction tooling, own generated metadata, own phase1 inventory and seal tooling.','Inherited general agent/system/developer instructions and parent assignment.'],
    'not_read_or_used':['candidate statement/definitions','candidate Lean/module/proof/runtime','source-blind reconstruction','previous source graphs/reviews/cognitions','semantic registry/frontier/ledger','other agents or private mathematical artifacts','Mathlib APIs','external cited reference package'],
    'no_zero_cue_claim':True,
    'authority_boundary':'Stop after freezing phase1. Need later strict-whitelist authority for candidate/reconstruction; no candidate verdict now.',
    'no_side_effects':'Only new files under own allowed phase1 directory and extraction/seal tooling under its parent. No ledger/API/sourceV/production/sharedgraph/site/Git mutation, build, browser, network, goal, or proof worker.'
})

paths = sorted(p for p in OUT.iterdir() if p.is_file() and p.name not in {'freeze-manifest.json','seal-receipt.json'})
paths += [BASE/'extract_source.py', BASE/'freeze_phase1.py']
manifest={'reviewer':'/root/source_reader_a74f20','phase':'1','status':'FROZEN_SOURCE_ONLY_NO_CANDIDATE_VERDICT','files':[{'path':str(p.relative_to(ROOT)),'sha256':digest(p.read_bytes()),'bytes':p.stat().st_size} for p in paths],'receipt_policy':'seal-receipt.json is a post-seal tool-result receipt outside this non-self-referential manifest. All source/cognition/exposure/commands/tooling artifacts above are frozen before next phase.'}
write_json('freeze-manifest.json',manifest)
print(json.dumps({'freeze_manifest_path':str(OUT/'freeze-manifest.json'),'freeze_manifest_sha256':digest((OUT/'freeze-manifest.json').read_bytes()),'source_cognition_sha256':digest((OUT/'source-cognition.md').read_bytes()),'read_exposure_sha256':digest((OUT/'read-exposure.json').read_bytes()),'tool_commands_sha256':digest((OUT/'tool-commands.json').read_bytes()),'file_count':len(paths),'raw_source_sha256':digest(raw_bytes),'status':manifest['status']},indent=2))
