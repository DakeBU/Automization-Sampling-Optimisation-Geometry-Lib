import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Tactic

open scoped BigOperators
noncomputable section
namespace ExactMeansScalarProbe

private def signedAlias (D : ℕ) (k : ℤ) : ℝ :=
  if (D : ℤ) ∣ k then (-1 : ℝ) ^ (k / (D : ℤ)) else 0

private theorem signedAlias_norm (D : ℕ) (k : ℤ) : ‖signedAlias D k‖ ≤ 1 := by
  unfold signedAlias
  split_ifs <;> simp

private theorem signedAlias_period {D : ℕ} (hD : 0 < D) (k : ℤ) :
    signedAlias D (k + D) = -signedAlias D k := by
  have hDne : (D : ℤ) ≠ 0 := by exact_mod_cast (Nat.ne_of_gt hD)
  have hdiv : (k + (D : ℤ)) / (D : ℤ) = k / (D : ℤ) + 1 := by
    simpa using Int.add_mul_ediv_right k 1 hDne
  have hdvd : ((D : ℤ) ∣ k + (D : ℤ)) ↔ (D : ℤ) ∣ k :=
    dvd_add_left (dvd_refl (D : ℤ))
  by_cases hk : (D : ℤ) ∣ k
  · simp only [signedAlias, hdvd, hk, if_true]
    rw [hdiv, zpow_add_one₀ (by norm_num : (-1 : ℝ) ≠ 0)]
    ring
  · simp [signedAlias, hdvd, hk]

private theorem summable_signedAlias (D : ℕ) {q : ℝ} (hq : ‖q‖ < 1) (c : ℤ) :
    Summable (fun j : ℕ => q ^ (j + 1) * signedAlias D (((j + 1 : ℕ) : ℤ) - c)) := by
  have hg : Summable (fun j : ℕ => ‖q‖ ^ (j + 1)) :=
    (summable_nat_add_iff 1).2 (summable_geometric_of_lt_one (norm_nonneg q) hq)
  have hbound (j : ℕ) :
      ‖q ^ (j + 1) * signedAlias D (((j + 1 : ℕ) : ℤ) - c)‖ ≤ ‖q‖ ^ (j + 1) := by
    rw [norm_mul, norm_pow]
    exact (mul_le_mul_of_nonneg_left (signedAlias_norm D _) (pow_nonneg (norm_nonneg _) _)).trans_eq (mul_one _)
  exact (Summable.of_nonneg_of_le (fun j => norm_nonneg _) hbound hg).of_norm

private theorem offset_alias_tsum {D c : ℕ} (hD : 0 < D) (hc : 1 ≤ c) (hcD : c ≤ D)
    {q : ℝ} (hq : ‖q‖ < 1) :
    (∑' j : ℕ, q ^ (j + 1) * signedAlias D (((j + 1 : ℕ) : ℤ) - (c : ℤ))) =
      q ^ c / (1 + q ^ D) := by
  classical
  let f : ℕ → ℝ := fun j => q ^ (j + 1) * signedAlias D (((j + 1 : ℕ) : ℤ) - (c : ℤ))
  let emb : ℕ → ℕ := fun a => D * a + (c - 1)
  have hDpos : (0 : ℤ) < D := by exact_mod_cast hD
  have hDne : (D : ℤ) ≠ 0 := ne_of_gt hDpos
  have hinj : Function.Injective emb := by
    intro a b h
    change D * a + (c - 1) = D * b + (c - 1) at h
    exact mul_left_cancel₀ (Nat.ne_of_gt hD) (Nat.add_right_cancel h)
  have hsupport : Function.support f ⊆ Set.range emb := by
    intro j hj
    change f j ≠ 0 at hj
    have hdiv : (D : ℤ) ∣ ((j + 1 : ℕ) : ℤ) - (c : ℤ) := by
      by_contra hn
      have ha0 : signedAlias D (((j + 1 : ℕ) : ℤ) - (c : ℤ)) = 0 := by
        simp only [signedAlias, if_neg hn]
      apply hj
      dsimp only [f]
      rw [ha0, mul_zero]
    obtain ⟨z, hz⟩ := hdiv
    have hz0 : 0 ≤ z := by
      by_contra hn
      have hzneg : z ≤ -1 := by omega
      have hm := mul_le_mul_of_nonneg_left hzneg hDpos.le
      have hcint : (c : ℤ) ≤ D := by exact_mod_cast hcD
      have hjint : (0 : ℤ) < ((j + 1 : ℕ) : ℤ) := by omega
      nlinarith
    have hcast : (((j + 1 : ℕ) : ℤ)) = (D : ℤ) * (z.toNat : ℤ) + (c : ℤ) := by
      rw [Int.toNat_of_nonneg hz0]
      linarith
    have hjnat : j + 1 = D * z.toNat + c := by exact_mod_cast hcast
    refine ⟨z.toNat, ?_⟩
    dsimp [emb]
    omega
  have hterm (a : ℕ) : f (emb a) = q ^ c * (-q ^ D) ^ a := by
    have he : emb a + 1 = D * a + c := by dsimp [emb]; omega
    have hcast : (((D * a + c : ℕ) : ℤ) - (c : ℤ)) = (D : ℤ) * (a : ℤ) := by
      push_cast
      ring
    have ha : signedAlias D ((D : ℤ) * (a : ℤ)) = (-1 : ℝ) ^ a := by
      unfold signedAlias
      rw [if_pos (dvd_mul_right _ _), Int.ediv_eq_of_eq_mul_right hDne rfl]
      simp
    dsimp only [f]
    rw [he, hcast, ha, pow_add, pow_mul, neg_pow]
    ring
  have hratio : ‖-q ^ D‖ < 1 := by
    rw [norm_neg, norm_pow]
    exact pow_lt_one₀ (norm_nonneg q) hq (Nat.ne_of_gt hD)
  have hgeom := summable_geometric_of_norm_lt_one hratio
  calc
    (∑' j : ℕ, f j) = ∑' a : ℕ, f (emb a) := (hinj.tsum_eq hsupport).symm
    _ = ∑' a : ℕ, q ^ c * (-q ^ D) ^ a := tsum_congr hterm
    _ = q ^ c * (∑' a : ℕ, (-q ^ D) ^ a) := hgeom.tsum_mul_left _
    _ = q ^ c / (1 + q ^ D) := by
      rw [tsum_geometric_of_norm_lt_one hratio, sub_neg_eq_add, div_eq_mul_inv]

end ExactMeansScalarProbe
