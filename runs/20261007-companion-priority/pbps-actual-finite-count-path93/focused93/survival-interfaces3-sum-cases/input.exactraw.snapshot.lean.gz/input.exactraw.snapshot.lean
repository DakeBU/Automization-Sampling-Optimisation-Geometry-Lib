import AutoSamplingTheory.ExampleCases.ProximalBPS.ActualOrderedPrefix
import AutoSamplingTheory.ExampleCases.ProximalBPS.ActualConditionalNextWaitSurvival
import AutoSamplingTheory.ExampleCases.ProximalBPS.ActualPhysicalTimeMeasurability

/-! Internal proof ingredients for the sealed candidate93, not a public result.
The set-law premise below will be filled by the actual survival theorem88.
No premise is added to the sealed source-facing statement. -/
namespace PathInterfaces93
open InnerProductSpace MeasureTheory ProbabilityTheory
open scoped ContDiff NNReal ENNReal Topology Interval
noncomputable section
set_option autoImplicit false

private theorem measurable_finite_fold {X Y : Type*}
    [MeasurableSpace X] [MeasurableSpace Y] (n : ℕ)
    (f : X → Y → Fin n → X)
    (hf : ∀ j, Measurable (fun p : X × Y => f p.1 p.2 j))
    (x : Y → X) (hx : Measurable x) :
    Measurable (fun y => Fin.foldl n (fun z j => f z y j) (x y)) := by
  induction n with
  | zero => simpa only [Fin.foldl_zero] using hx
  | succ n ih =>
    have hr := ih (fun z y j => f z y j.castSucc) (fun j => hf j.castSucc)
    simpa only [Fin.foldl_succ_last, Function.comp_def, id_eq] using
      (hf (Fin.last n)).comp (hr.prodMk measurable_id)

private theorem survival_history_measure {Ω H : Type*}
    [MeasurableSpace Ω] [MeasurableSpace H]
    (μ : Measure Ω) (history : Ω → H) (S : Set Ω) (weight : H → ℝ≥0∞)
    (hh : Measurable history)
    (hset : ∀ A : Set H, MeasurableSet A →
      μ (history ⁻¹' A ∩ S) = ∫⁻ h in A, weight h ∂Measure.map history μ) :
    Measure.map history (μ.restrict S) = (Measure.map history μ).withDensity weight := by
  apply Measure.ext
  intro A hA
  rw [Measure.map_apply hh hA, Measure.restrict_apply (hA.preimage hh),
    withDensity_apply weight hA]
  exact hset A hA

private theorem survival_history_all_tests {Ω H : Type*}
    [MeasurableSpace Ω] [MeasurableSpace H]
    (μ : Measure Ω) (history : Ω → H) (S : Set Ω) (weight : H → ℝ≥0∞)
    (hh : Measurable history) (hw : Measurable weight)
    (hset : ∀ A : Set H, MeasurableSet A →
      μ (history ⁻¹' A ∩ S) = ∫⁻ h in A, weight h ∂Measure.map history μ)
    (F : H → ℝ≥0∞) (hF : Measurable F) :
    (∫⁻ w in S, F (history w) ∂μ) =
      ∫⁻ h, F h * weight h ∂Measure.map history μ := by
  rw [← lintegral_map hF hh, survival_history_measure μ history S weight hh hset,
    lintegral_withDensity_eq_lintegral_mul _ hw hF]
  exact lintegral_congr fun _ => mul_comm _ _


private theorem localized_survival_history_measure {Ω H : Type*}
    [MeasurableSpace Ω] [MeasurableSpace H]
    (μ : Measure Ω) (history : Ω → H) (S : Set Ω) (weight : H → ℝ≥0∞)
    (hh : Measurable history)
    (hset : ∀ A : Set H, MeasurableSet A →
      μ (history ⁻¹' A ∩ S) = ∫⁻ h in A, weight h ∂Measure.map history μ)
    (A : Set H) (hA : MeasurableSet A) :
    Measure.map history (μ.restrict (history ⁻¹' A ∩ S)) =
      ((Measure.map history μ).restrict A).withDensity weight := by
  apply Measure.ext
  intro B hB
  rw [Measure.map_apply hh hB, Measure.restrict_apply (hB.preimage hh),
    withDensity_apply weight hB, Measure.restrict_restrict hB,
    ← hset (B ∩ A) (hB.inter hA)]
  congr 1
  ext w
  simp only [Set.mem_inter_iff, Set.mem_preimage]
  exact and_assoc.symm

set_option maxHeartbeats 1600000 in
private theorem actual_terminal_survival_history_tests
    {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℝ E]
    [FiniteDimensional ℝ E] [MeasurableSpace E] [BorelSpace E]
    {V : E → ℝ} {α β : ℝ≥0} {η : ℝ}
    (hα : 0 < (α : ℝ)) (hαβ : α ≤ β) (hV : ContDiff ℝ 2 V)
    (hH : ∀ x v : E,
      (α : ℝ) * ‖v‖ ^ 2 ≤ (fderiv ℝ (fderiv ℝ V) x v) v ∧
      (fderiv ℝ (fderiv ℝ V) x v) v ≤ (β : ℝ) * ‖v‖ ^ 2)
    (hη : 0 < η) (hβη : (β : ℝ) * η ≤ 1) :
    let c : E → E → E := fun y xRef => y - η • gradient V xRef
    let Φ : E → E → ℝ → (E × E) → (E × E) := fun y xRef t z =>
      (c y xRef + Real.cos t • (z.1 - c y xRef) +
          (Real.sqrt η * Real.sin t) • z.2,
       (-Real.sin t / Real.sqrt η) • (z.1 - c y xRef) + Real.cos t • z.2)
    let S : E → (E × E) → (E × E) := fun xRef z =>
      (z.1, z.2 - (2 * inner ℝ z.2 (gradient V z.1 - gradient V xRef) /
        ‖gradient V z.1 - gradient V xRef‖ ^ 2) • (gradient V z.1 - gradient V xRef))
    let rate : E → (E × E) → ℝ := fun xRef z =>
      Real.sqrt η * max 0 (inner ℝ z.2 (gradient V z.1 - gradient V xRef))
    let Λ : E → E → (E × E) → ℝ≥0 → ℝ := fun y xRef z t =>
      ∫ s in (0 : ℝ)..(t : ℝ), rate xRef (Φ y xRef s z)
    let τ : E → E → (E × E) → ℝ≥0 → WithTop ℝ≥0 := fun y xRef z e =>
      MeasureTheory.hittingAfter
        (fun t : ℝ≥0 => fun a : (E × E) × (E × E) × ℝ≥0 =>
          Λ a.1.1 a.1.2 a.2.1 t - (a.2.2 : ℝ))
        (Set.Ici (0 : ℝ)) 0 ((y, xRef), z, e)
    let next : E → E → ℝ≥0 → ((ℝ≥0 × (E × E)) ⊕ Unit) →
        ((ℝ≥0 × (E × E)) ⊕ Unit) := fun y xRef e r =>
      match r with
      | Sum.inr _ => Sum.inr ()
      | Sum.inl a =>
        if τ y xRef a.2 e = ⊤ then Sum.inr () else
          Sum.inl (a.1 + (τ y xRef a.2 e).untopD 0,
            S xRef (Φ y xRef (((τ y xRef a.2 e).untopD 0 : ℝ≥0) : ℝ) a.2))
    let record : E → E → (E × E) → (ℕ → ℝ≥0) → ℕ →
        ((ℝ≥0 × (E × E)) ⊕ Unit) := fun y xRef z₀ e n =>
      Nat.rec (Sum.inl (0, z₀)) (fun k r => next y xRef (e k) r) n
    let P : Measure (ℕ → ℝ) := Measure.infinitePi (fun _ : ℕ => expMeasure (1 : ℝ))
    let ε : (ℕ → ℝ) → ℕ → ℝ≥0 := fun w k => Real.toNNReal (w k)
    let history : E → E → (E × E) → (n : ℕ) → (ℕ → ℝ) →
        (Fin (n + 1) → ((ℝ≥0 × (E × E)) ⊕ Unit)) :=
      fun y xRef z₀ n w j => record y xRef z₀ (ε w) j.val
    let Rec := (ℝ≥0 × (E × E)) ⊕ Unit
    let Hist : ℕ → Type _ := fun n => Fin (n + 1) → Rec
    let liveTime : Rec → ℝ≥0 := fun r => r.elim Prod.fst (fun _ => 0)
    let d : (n : ℕ) → ℝ≥0 → Hist n → ℝ≥0 :=
      fun n T h => T - liveTime (h ⟨n, Nat.lt_succ_self n⟩)
    let survival : E → E → Rec → ℝ≥0 → ℝ → Prop :=
      fun y xRef r u e => r.elim
        (fun a => (u : WithTop ℝ≥0) < τ y xRef a.2 (Real.toNNReal e)) (fun _ => False)
    let weight : E → E → Rec → ℝ≥0 → ℝ≥0∞ :=
      fun y xRef r u => r.elim
        (fun a => ENNReal.ofReal (Real.exp (-Λ y xRef a.2 u))) (fun _ => 0)
    ∀ y xRef : E, ∀ z₀ : E × E, ∀ n : ℕ, ∀ T : ℝ≥0,
      ∀ A : Set (Hist n), MeasurableSet A →
      let H := history y xRef z₀ n
      let W : Hist n → ℝ≥0∞ := fun h =>
        weight y xRef (h ⟨n, Nat.lt_succ_self n⟩) (d n T h)
      let C : Set (ℕ → ℝ) := {w | H w ∈ A ∧
        survival y xRef (record y xRef z₀ (ε w) n) (d n T (H w)) (w n)}
      Measurable H ∧ Measurable W ∧ MeasurableSet C ∧
      Measure.map H (P.restrict C) = ((Measure.map H P).restrict A).withDensity W ∧
      (∀ F : Hist n → ℝ≥0∞, Measurable F →
        (∫⁻ w in C, F (H w) ∂P) = ∫⁻ h in A, F h * W h ∂Measure.map H P) := by
  classical
  let c : E → E → E := fun y xRef => y - η • gradient V xRef
  let Φ : E → E → ℝ → (E × E) → (E × E) := fun y xRef t z =>
    (c y xRef + Real.cos t • (z.1 - c y xRef) +
        (Real.sqrt η * Real.sin t) • z.2,
     (-Real.sin t / Real.sqrt η) • (z.1 - c y xRef) + Real.cos t • z.2)
  let S : E → (E × E) → (E × E) := fun xRef z =>
    (z.1, z.2 - (2 * inner ℝ z.2 (gradient V z.1 - gradient V xRef) /
      ‖gradient V z.1 - gradient V xRef‖ ^ 2) • (gradient V z.1 - gradient V xRef))
  let rate : E → (E × E) → ℝ := fun xRef z =>
    Real.sqrt η * max 0 (inner ℝ z.2 (gradient V z.1 - gradient V xRef))
  let Λ : E → E → (E × E) → ℝ≥0 → ℝ := fun y xRef z t =>
    ∫ s in (0 : ℝ)..(t : ℝ), rate xRef (Φ y xRef s z)
  let τ : E → E → (E × E) → ℝ≥0 → WithTop ℝ≥0 := fun y xRef z e =>
    MeasureTheory.hittingAfter
      (fun t : ℝ≥0 => fun a : (E × E) × (E × E) × ℝ≥0 =>
        Λ a.1.1 a.1.2 a.2.1 t - (a.2.2 : ℝ))
      (Set.Ici (0 : ℝ)) 0 ((y, xRef), z, e)
  let next : E → E → ℝ≥0 → ((ℝ≥0 × (E × E)) ⊕ Unit) →
      ((ℝ≥0 × (E × E)) ⊕ Unit) := fun y xRef e r =>
    match r with
    | Sum.inr _ => Sum.inr ()
    | Sum.inl a =>
      if τ y xRef a.2 e = ⊤ then Sum.inr () else
        Sum.inl (a.1 + (τ y xRef a.2 e).untopD 0,
          S xRef (Φ y xRef (((τ y xRef a.2 e).untopD 0 : ℝ≥0) : ℝ) a.2))
  let record : E → E → (E × E) → (ℕ → ℝ≥0) → ℕ →
      ((ℝ≥0 × (E × E)) ⊕ Unit) := fun y xRef z₀ e n =>
    Nat.rec (Sum.inl (0, z₀)) (fun k r => next y xRef (e k) r) n
  let P : Measure (ℕ → ℝ) := Measure.infinitePi (fun _ : ℕ => expMeasure (1 : ℝ))
  let ε : (ℕ → ℝ) → ℕ → ℝ≥0 := fun w k => Real.toNNReal (w k)
  let history : E → E → (E × E) → (n : ℕ) → (ℕ → ℝ) →
      (Fin (n + 1) → ((ℝ≥0 × (E × E)) ⊕ Unit)) :=
    fun y xRef z₀ n w j => record y xRef z₀ (ε w) j.val
  let Rec := (ℝ≥0 × (E × E)) ⊕ Unit
  let Hist : ℕ → Type _ := fun n => Fin (n + 1) → Rec
  let liveTime : Rec → ℝ≥0 := fun r => r.elim Prod.fst (fun _ => 0)
  let d : (n : ℕ) → ℝ≥0 → Hist n → ℝ≥0 :=
    fun n T h => T - liveTime (h ⟨n, Nat.lt_succ_self n⟩)
  let survival : E → E → Rec → ℝ≥0 → ℝ → Prop :=
    fun y xRef r u e => r.elim
      (fun a => (u : WithTop ℝ≥0) < τ y xRef a.2 (Real.toNNReal e)) (fun _ => False)
  let weight : E → E → Rec → ℝ≥0 → ℝ≥0∞ :=
    fun y xRef r u => r.elim
      (fun a => ENNReal.ofReal (Real.exp (-Λ y xRef a.2 u))) (fun _ => 0)
  change
    ∀ y xRef : E, ∀ z₀ : E × E, ∀ n : ℕ, ∀ T : ℝ≥0,
      ∀ A : Set (Hist n), MeasurableSet A →
      let H := history y xRef z₀ n
      let W : Hist n → ℝ≥0∞ := fun h =>
        weight y xRef (h ⟨n, Nat.lt_succ_self n⟩) (d n T h)
      let C : Set (ℕ → ℝ) := {w | H w ∈ A ∧
        survival y xRef (record y xRef z₀ (ε w) n) (d n T (H w)) (w n)}
      Measurable H ∧ Measurable W ∧ MeasurableSet C ∧
      Measure.map H (P.restrict C) = ((Measure.map H P).restrict A).withDensity W ∧
      (∀ F : Hist n → ℝ≥0∞, Measurable F →
        (∫⁻ w in C, F (H w) ∂P) = ∫⁻ h in A, F h * W h ∂Measure.map H P)
  intro y xRef z₀ n T A hA
  let H := history y xRef z₀ n
  let W : Hist n → ℝ≥0∞ := fun h =>
    weight y xRef (h ⟨n, Nat.lt_succ_self n⟩) (d n T h)
  let S₀ : Set (ℕ → ℝ) := {w |
    survival y xRef (record y xRef z₀ (ε w) n) (d n T (H w)) (w n)}
  let C : Set (ℕ → ℝ) := H ⁻¹' A ∩ S₀
  change Measurable H ∧ Measurable W ∧ MeasurableSet C ∧
    Measure.map H (P.restrict C) = ((Measure.map H P).restrict A).withDensity W ∧
    (∀ F : Hist n → ℝ≥0∞, Measurable F →
      (∫⁻ w in C, F (H w) ∂P) = ∫⁻ h in A, F h * W h ∂Measure.map H P)
  have hH : Measurable H :=
    (AutoSamplingTheory.ExampleCases.ProximalBPS.ActualFiniteHistoryTailLaw.actual_finite_history_tail_law
      hα hαβ hV hH hη hβη y xRef z₀ n).1
  have hd : Measurable (d n T) :=
    measurable_const.sub (((measurable_fst : Measurable
      (fun p : ℝ≥0 × (E × E) => p.1)).sumElim measurable_const).comp
        (measurable_pi_apply (⟨n, Nat.lt_succ_self n⟩ : Fin (n + 1))))
  have h88 := AutoSamplingTheory.ExampleCases.ProximalBPS.ActualConditionalNextWaitSurvival.actual_conditional_next_wait_survival
    hα hαβ hV ‹∀ x v : E, (α : ℝ) * ‖v‖ ^ 2 ≤ (fderiv ℝ (fderiv ℝ V) x v) v ∧
      (fderiv ℝ (fderiv ℝ V) x v) v ≤ (β : ℝ) * ‖v‖ ^ 2› hη hβη y xRef z₀ n (d n T) hd
  have hweight (r : Rec) (u : ℝ≥0) :
      (match r with
       | Sum.inl a => ENNReal.ofReal (Real.exp (-Λ y xRef a.2 u))
       | Sum.inr _ => 0) = weight y xRef r u := by
    cases r <;> rfl
  have hsurvival (r : Rec) (u : ℝ≥0) (e : ℝ) :
      (match r with
       | Sum.inl a => (u : WithTop ℝ≥0) < τ y xRef a.2 (Real.toNNReal e)
       | Sum.inr _ => False) = survival y xRef r u e := by
    cases r <;> rfl
  have hW : Measurable W := by
    simpa only [hweight] using h88.2.1
  have hS : MeasurableSet S₀ := by
    have hm : Measurable (fun w : ℕ → ℝ => (H w, fun k : ℕ => w (n + k))) :=
      hH.prodMk (measurable_pi_lambda _ fun k => measurable_pi_apply (n + k))
    simpa only [Set.preimage_setOf_eq, hsurvival, Nat.add_zero] using h88.1.preimage hm
  have hC : MeasurableSet C := (hA.preimage hH).inter hS
  have hset : ∀ B : Set (Hist n), MeasurableSet B →
      P (H ⁻¹' B ∩ S₀) = ∫⁻ h in B, W h ∂Measure.map H P := by
    simpa only [hsurvival, hweight] using h88.2.2.2
  have hlaw := localized_survival_history_measure P H S₀ W hH hset A hA
  refine ⟨hH, hW, hC, hlaw, ?_⟩
  intro F hF
  rw [← lintegral_map hF hH, hlaw,
    lintegral_withDensity_eq_lintegral_mul _ hW hF]
  exact lintegral_congr fun h => mul_comm _ _

#print axioms actual_terminal_survival_history_tests
end
end PathInterfaces93
