"""Targeted actual Chrome parent visibility checks using SVG's real clipped visible area."""
import datetime as dt
from functools import partial
import hashlib
from http.server import SimpleHTTPRequestHandler,ThreadingHTTPServer
import json
import os
from pathlib import Path
import sys
import tempfile
import threading
import time
import traceback

OWN=Path(__file__).resolve().parent
REPO=OWN.parents[3]

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

GEOMETRY=r'''el=>{
  const svg=el.closest('[data-graph-svg]')||document.querySelector('[data-graph-svg]');
  const rect=r=>({left:r.left,right:r.right,top:r.top,bottom:r.bottom,width:r.width,height:r.height});
  const sr=svg.getBoundingClientRect(),nr=el.getBoundingClientRect();
  let header=0;const hs=[...document.querySelectorAll('header,.mobile-bar,.verification-strip')];
  for(let pass=0;pass<hs.length+1;pass++)for(const h of hs){const s=getComputedStyle(h),r=h.getBoundingClientRect();if(['fixed','sticky'].includes(s.position)&&s.display!=='none'&&s.visibility!=='hidden'&&r.width>0&&r.height>0&&r.right>0&&r.left<innerWidth&&r.bottom>0&&r.top<=header+1)header=Math.max(header,r.bottom);}
  let clip={left:Math.max(0,sr.left),right:Math.min(innerWidth,sr.right),top:Math.max(header+8,sr.top),bottom:Math.min(innerHeight-8,sr.bottom)};
  const ancestors=[];
  for(let p=svg.parentElement;p;p=p.parentElement){const s=getComputedStyle(p),r=p.getBoundingClientRect();const x=['hidden','clip','scroll','auto'].includes(s.overflowX),y=['hidden','clip','scroll','auto'].includes(s.overflowY);if(x){clip.left=Math.max(clip.left,r.left+p.clientLeft);clip.right=Math.min(clip.right,r.left+p.clientLeft+p.clientWidth);}if(y){clip.top=Math.max(clip.top,r.top+p.clientTop);clip.bottom=Math.min(clip.bottom,r.top+p.clientTop+p.clientHeight);}if(x||y)ancestors.push({tag:p.tagName,className:p.className,overflowX:s.overflowX,overflowY:s.overflowY,rect:rect(r)});}
  clip.width=Math.max(0,clip.right-clip.left);clip.height=Math.max(0,clip.bottom-clip.top);
  const intersection={left:Math.max(nr.left,clip.left),right:Math.min(nr.right,clip.right),top:Math.max(nr.top,clip.top),bottom:Math.min(nr.bottom,clip.bottom)};
  intersection.width=Math.max(0,intersection.right-intersection.left);intersection.height=Math.max(0,intersection.bottom-intersection.top);intersection.area=intersection.width*intersection.height;
  const text=el.querySelector('text.label');const tm=text?text.getScreenCTM():null;
  const effectiveFont=text?parseFloat(getComputedStyle(text).fontSize)*Math.hypot(tm.a,tm.b):null;
  const tr=text?text.getBoundingClientRect():{left:0,right:0,top:0,bottom:0,width:0,height:0};
  const li={width:Math.max(0,Math.min(tr.right,clip.right)-Math.max(tr.left,clip.left)),height:Math.max(0,Math.min(tr.bottom,clip.bottom)-Math.max(tr.top,clip.top))};
  li.area=li.width*li.height;
  return {svg:rect(sr),node:rect(nr),clip,clipAncestors:ancestors,headerBottom:header,viewport:{width:innerWidth,height:innerHeight},scroll:{x:scrollX,y:scrollY},intersection,intersectionFraction:nr.width>0&&nr.height>0?intersection.area/(nr.width*nr.height):0,effectiveFontPx:effectiveFont,label:text?text.textContent:null,labelRect:rect(tr),labelIntersection:li,labelVisibleFraction:tr.width>0&&tr.height>0?li.area/(tr.width*tr.height):0,positiveSVGClippedIntersection:clip.width>0&&clip.height>0&&intersection.area>0};
}'''

VISIBLE=r'''el=>{
  const r=el.getBoundingClientRect();let header=0;const hs=[...document.querySelectorAll('header,.mobile-bar,.verification-strip')];
  for(let pass=0;pass<hs.length+1;pass++)for(const h of hs){const s=getComputedStyle(h),q=h.getBoundingClientRect();if(['fixed','sticky'].includes(s.position)&&s.display!=='none'&&s.visibility!=='hidden'&&q.width>0&&q.height>0&&q.right>0&&q.left<innerWidth&&q.bottom>0&&q.top<=header+1)header=Math.max(header,q.bottom);}
  let c={left:0,right:innerWidth,top:header+4,bottom:innerHeight-4};
  for(let p=el.parentElement;p;p=p.parentElement){const s=getComputedStyle(p),q=p.getBoundingClientRect();if(['hidden','clip','scroll','auto'].includes(s.overflowX)){c.left=Math.max(c.left,q.left+p.clientLeft);c.right=Math.min(c.right,q.left+p.clientLeft+p.clientWidth);}if(['hidden','clip','scroll','auto'].includes(s.overflowY)){c.top=Math.max(c.top,q.top+p.clientTop);c.bottom=Math.min(c.bottom,q.top+p.clientTop+p.clientHeight);}}
  const iw=Math.max(0,Math.min(r.right,c.right)-Math.max(r.left,c.left)),ih=Math.max(0,Math.min(r.bottom,c.bottom)-Math.max(r.top,c.top));
  return {left:r.left,right:r.right,top:r.top,bottom:r.bottom,width:r.width,height:r.height,header,clip:c,intersectionWidth:iw,intersectionHeight:ih,positive:iw>0&&ih>0};
}'''

class QuietHandler(SimpleHTTPRequestHandler):
    def log_message(self,*_):pass

def main():
    contract_path=OWN/'contract.v1.json';c=json.loads(contract_path.read_text())
    assert c['status']=='FROZEN_ROOT_EXPLICITLY_AUTHORIZED_TARGETED_SUPPLEMENT'
    assert sha(__file__)==c['runner_sha256']
    for row in c['inputs']:assert sha(row['path'])==row['sha256']
    assert sha(c['chrome']['path'])==c['chrome']['binary_sha256']
    output=OWN/'output';output.mkdir(exist_ok=False)
    tmp=OWN/'chrome-tmp';tmp.mkdir(exist_ok=True);os.environ['TMPDIR']=str(tmp);tempfile.tempdir=str(tmp)
    checks=[];screenshots=[];requests=[];responses=[];console=[];page_errors=[];blocked=[];cases=[]
    def check(name,ok,detail=None):checks.append({'name':name,'pass':bool(ok),'detail':detail})
    def screenshot(page,name,clip=None,full=False):
        p=output/(name+'.png');page.screenshot(path=str(p),clip=clip,full_page=full);screenshots.append({'path':str(p.relative_to(OWN)),'sha256':sha(p)})
    server=ThreadingHTTPServer(('127.0.0.1',0),partial(QuietHandler,directory=c['fixture']));thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
    origin='http://127.0.0.1:'+str(server.server_port);browser_started=False;browser_version=None
    try:
        from playwright.sync_api import sync_playwright
        with sync_playwright() as playwright:
            browser=playwright.chromium.launch(executable_path=c['chrome']['path'],headless=True);browser_started=True;browser_version=browser.version
            for viewport in c['viewports']:
                context=browser.new_context(viewport={'width':viewport['width'],'height':viewport['height']},device_scale_factor=1)
                def route(route):
                    url=route.request.url
                    if url.startswith(origin+'/') or url.startswith(('data:','blob:')):route.continue_()
                    else:blocked.append(url);route.abort()
                context.route('**/*',route)
                for target in c['targets']:
                    label=viewport['label']+'-'+target['label'];page=context.new_page()
                    page.on('request',lambda r:requests.append({'url':r.url,'method':r.method,'resource_type':r.resource_type}))
                    page.on('response',lambda r:responses.append({'url':r.url,'status':r.status}))
                    page.on('console',lambda m:console.append({'type':m.type,'text':m.text}))
                    page.on('pageerror',lambda e:page_errors.append(str(e)))
                    case={'label':label,'target':target['id'],'interactions':[]}
                    try:
                        page.goto(origin+'/lean-foundations.html?view=lean',wait_until='networkidle')
                        page.locator('[data-graph-search]').fill(target['full_name'])
                        node=page.locator('.ulg-node[data-id="'+target['id']+'"]');node.wait_for();node.click()
                        page.wait_for_timeout(150)
                        check(label+'-exact-parent-selected',page.locator('.ulg-node.selected').get_attribute('data-id')==target['id'])
                        svg=page.locator('[data-graph-svg]')
                        case['before_correct_scroll']=node.evaluate(GEOMETRY)
                        # Native scroll only; no SVG/node transform or layout mutation.
                        svg.evaluate("el=>el.scrollIntoView({behavior:'instant',block:'center',inline:'nearest'})")
                        page.wait_for_timeout(200)
                        case['after_correct_scroll']=node.evaluate(GEOMETRY)
                        check(label+'-actual-visible-SVG-region-nonempty',case['after_correct_scroll']['clip']['width']>40 and case['after_correct_scroll']['clip']['height']>40,case['after_correct_scroll'])

                        def pan_to_clip_center(force=False):
                            geometry=node.evaluate(GEOMETRY);clip=geometry['clip'];n=geometry['node']
                            dx=(clip['left']+clip['right'])/2-(n['left']+n['right'])/2
                            dy=(clip['top']+clip['bottom'])/2-(n['top']+n['bottom'])/2
                            if abs(dx)<1 and abs(dy)<1:
                                if not force:return False
                                dx=10;dy=0
                            start=svg.evaluate('''(el,c)=>{const xs=[c.left+12,c.right-12,(c.left+c.right)/2],ys=[c.top+12,c.bottom-12,(c.top+c.bottom)/2];for(const y of ys)for(const x of xs){const hit=document.elementFromPoint(x,y);if(hit&&hit.closest('[data-graph-svg]')===el&&!hit.closest('.ulg-node'))return{x,y};}return null;}''',clip)
                            if start is None:raise RuntimeError('No real visible SVG background point for native pointer pan')
                            dx=max(clip['left']+4-start['x'],min(clip['right']-4-start['x'],dx))
                            dy=max(clip['top']+4-start['y'],min(clip['bottom']-4-start['y'],dy))
                            page.mouse.move(start['x'],start['y']);page.mouse.down();page.mouse.move(start['x']+dx,start['y']+dy,steps=10);page.mouse.up();page.wait_for_timeout(100)
                            case['interactions'].append({'native_pointer_pan':{'start':start,'dx':dx,'dy':dy},'desired_center_basis':'actual SVG clipped visible area','after':node.evaluate(GEOMETRY)})
                            return True

                        for attempt in range(8):
                            if not pan_to_clip_center(force=attempt==0):break
                        before_wheel=node.evaluate(GEOMETRY)
                        clip=before_wheel['clip'];n=before_wheel['node']
                        wx=max(clip['left']+8,min(clip['right']-8,(n['left']+n['right'])/2));wy=max(clip['top']+8,min(clip['bottom']-8,(n['top']+n['bottom'])/2))
                        page.mouse.move(wx,wy);page.mouse.wheel(0,-100);page.wait_for_timeout(150)
                        case['interactions'].append({'native_wheel':{'x':wx,'y':wy,'deltaY':-100},'after':node.evaluate(GEOMETRY)})
                        for _ in range(8):
                            if not pan_to_clip_center():break
                        final=node.evaluate(GEOMETRY);case['final_node_geometry']=final
                        check(label+'-native-wheel-and-pointer-exercised',any('native_pointer_pan' in x for x in case['interactions']) and any('native_wheel' in x for x in case['interactions']))
                        check(label+'-node-positive-intersection-inside-actual-SVG-clip',final['positiveSVGClippedIntersection'],final)
                        check(label+'-node-at-least-98percent-inside-actual-SVG-clip',final['intersectionFraction']>=.98,final)
                        check(label+'-effective-label-font-at-least-12px',final['effectiveFontPx']>=12,final)
                        check(label+'-rendered-core-label-readable-inside-SVG-clip',
                              final['labelVisibleFraction']>=.95
                              and final['labelIntersection']['width']>=min(80,final['labelRect']['width'])
                              and final['labelIntersection']['height']>=min(12,final['labelRect']['height'])
                              and final['effectiveFontPx']>=12,final)
                        screenshot(page,label+'-node-after-real-wheel-pointer')
                        clip=final['clip'];s=final['scroll'];screenshot(page,label+'-actual-visible-SVG',clip={'x':clip['left']+s['x'],'y':clip['top']+s['y'],'width':clip['width'],'height':clip['height']})
                        detail=page.locator('[data-graph-detail]');h2=detail.locator('header h2')
                        check(label+'-complete-exact-parent-name-in-detail',h2.text_content()==target['full_name'],h2.text_content())
                        sections=detail.locator('header,dl.ulg-details,.ulg-links,.ulg-neighbors')
                        detail_measurements=[]
                        check(label+'-complete-detail-regions-present',sections.count()>=4,sections.count())
                        for i in range(sections.count()):
                            region=sections.nth(i);region.scroll_into_view_if_needed();page.wait_for_timeout(80)
                            geometry=region.evaluate(VISIBLE);detail_measurements.append({'index':i,'text':region.text_content(),'geometry':geometry})
                            check(label+'-detail-region-'+str(i)+'-actually-visible-through-clip',geometry['positive'],geometry)
                            screenshot(page,label+'-detail-region-'+str(i))
                        case['detail_regions']=detail_measurements
                        screenshot(page,label+'-detail-full-page',full=True)
                        link=detail.locator('.ulg-links a.primary').first
                        check(label+'-exact-primary-parent-source-link',link.get_attribute('href')==target['source_path'],link.get_attribute('href'))
                        with page.expect_navigation(wait_until='networkidle'):link.click()
                        check(label+'-actual-parent-source-navigation',page.url==origin+'/'+target['source_path'],page.url)
                        raw=Path(c['fixture']).parents[1]/'input-snapshot'/target['raw'];exact=raw.read_bytes()
                        check(label+'-complete-source-body-byte-exact',page.locator('pre').text_content().encode()==exact)
                        check(label+'-source-header-and-file-correct',page.locator('h1').first.text_content()=='Exact source context' and target['raw'] in page.title() and target['raw'] in page.locator('[data-exact-source-file]').text_content())
                        anchor=page.locator('#L'+str(target['anchor']));geometry=anchor.evaluate(VISIBLE)
                        check(label+'-actual-source-anchor-below-header-visible',geometry['positive'] and geometry['top']>=geometry['header']-1,geometry)
                        check(label+'-complete-source-line-count',page.locator('pre span[id^="L"]').count()==target['lines'])
                        screenshot(page,label+'-actual-source-anchor');screenshot(page,label+'-source-full-page',full=True)
                        case['status']='PASS' if all(x['pass'] for x in checks if x['name'].startswith(label+'-')) else 'MEASUREMENT_OR_PAGE_FAILURE'
                    except Exception:
                        case['status']='RUNTIME_MEASUREMENT_FAILED';case['exception']=traceback.format_exc();check(label+'-targeted-case-completed',False,case['exception']);screenshot(page,label+'-actual-case-failure')
                    cases.append(case);page.close()
                context.close()
            browser.close()
    except Exception:
        check('browser-process-completed',False,traceback.format_exc())
    finally:
        server.shutdown();server.server_close();thread.join()
    for row in c['inputs']:check('unchanged-input:'+row['path'].split('/fixtures/candidate/')[-1],sha(row['path'])==row['sha256'])
    check('no-external-browser-requests',not blocked,blocked)
    check('no-page-javascript-errors',not page_errors,page_errors)
    check('no-console-errors',not [m for m in console if m['type']=='error'],console)
    check('no-localhost-HTTP-error-responses',not [x for x in responses if x['status']>=400],responses)
    check('all-four-targeted-cases-executed',len(cases)==4,len(cases))
    result={'schema':'independent-parent-SVG-clip-native-browser-supplement-result-v1','actual_browser_target':c['actual_browser_target'],'contract_sha256':sha(contract_path),'runner_sha256':sha(__file__),'checks':checks,'cases':cases,'screenshots':screenshots,'requests':requests,'responses':responses,'console':console,'page_errors':page_errors,'blocked_external_requests':blocked,'browser_started':browser_started,'actual_chrome_version':browser_version,'actual_chrome_binary_sha256':c['chrome']['binary_sha256'],'status':'ENV_BLOCKED' if not browser_started else 'PASS' if all(x['pass'] for x in checks) else 'FAIL','server_and_thread_stopped_before_result':True,'old_398_flags_not_rewritten':True,'old356_manifest_unchanged':sha(OWN.parent/'reader-runtime-v3/presentation-selected-originals.manifest.v1.json')=='3cea83cd0e61df11cba9ab36dca51f1f64c79b18df1238b836d8f9c05f301451','fresh_independent_visual_acceptance':'PENDING_laplace_fresh_source_8d2a','production_Git_ledger_API_writes':0}
    (OWN/'actual-result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'status':result['status'],'checks':len(checks),'false_checks':[x['name'] for x in checks if not x['pass']],'PNGs':len(screenshots),'actual_result_sha256':sha(OWN/'actual-result.json')}))
    return 0 if result['status']=='PASS' else 2 if result['status']=='ENV_BLOCKED' else 1

def captured():
    directory=OWN/'process';directory.mkdir(exist_ok=False)
    out=directory/'stdout.raw';err=directory/'stderr.raw'
    sys.stdout.flush();sys.stderr.flush()
    o=out.open('xb',buffering=0);e=err.open('xb',buffering=0);os.dup2(o.fileno(),1);os.dup2(e.fileno(),2);o.close();e.close()
    started=dt.datetime.now(dt.timezone.utc).isoformat();start=time.monotonic();exception=None;code=1
    try:code=main()
    except BaseException as ex:exception={'type':type(ex).__name__,'message':str(ex)};traceback.print_exc();code=130 if isinstance(ex,KeyboardInterrupt) else 1
    sys.stdout.flush();sys.stderr.flush()
    receipt={'schema':'actual-OS-streams-native-parent-supplement-process-v1','argv':[sys.executable,*sys.argv],'cwd':str(Path.cwd()),'pid':os.getpid(),'ppid':os.getppid(),'started_utc':started,'ended_utc':dt.datetime.now(dt.timezone.utc).isoformat(),'elapsed_seconds':time.monotonic()-start,'exit_code':code,'exception':exception,'stdout':{'path':str(out.relative_to(OWN)),'bytes':out.stat().st_size,'sha256':sha(out)},'stderr':{'path':str(err.relative_to(OWN)),'bytes':err.stat().st_size,'sha256':sha(err)},'contract_sha256':sha(OWN/'contract.v1.json'),'runner_sha256':sha(__file__),'actual_result_sha256':sha(OWN/'actual-result.json') if (OWN/'actual-result.json').exists() else None,'OS_fd1_fd2_captured_until_exit':True}
    (directory/'receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
    return code

if __name__=='__main__':sys.exit(captured())
