from pathlib import Path
import json,hashlib,gzip,subprocess,tarfile,shutil
sha=lambda b:hashlib.sha256(b).hexdigest();b=Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-determinant-semantic-evidence');checks=b/'actual-checks'
for p in sorted(Path('.astis/huanjian-resume-20261103').glob('*-fixed-spectrum-determinant-*.receipt.json')):
 if (checks/p.name).exists():continue
 r=json.loads(p.read_bytes());raw=Path(r['log']).read_bytes();assert sha(raw)==r['log_sha256'];shutil.copy2(p,checks/p.name);z=checks/(Path(r['log']).name+'.gz');z.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(z.read_bytes())==raw
roots=[checks,b/'fresh-source-reader-835194/phase3',b/'fresh-source-reader-835194/phase3-verification-transition',Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-determinant-integration-20261108/independent-integration-reader-review/proposal')];paths=[p for root in roots for p in root.rglob('*') if p.is_file()]+[b/'full-anti-anchored-reviewer-packet.json',b/'full-review-input-pins.json',b/'mechanical-existing-source-V-projection.json']
private=Path('.astis/huanjian-fixed-spectrum-determinant-20261108');files=sorted(p for p in private.rglob('*') if p.is_file());archive=b/'source-verified-private-workfiles.lossless.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz') as t:
 for p in files:t.add(p,arcname=str(p.relative_to(private)),recursive=False)
with tarfile.open(archive,'r:gz') as t:
 for p in files:assert t.extractfile(str(p.relative_to(private))).read()==p.read_bytes()
manifest=b/'source-verified-private-workfiles.manifest.json';manifest.write_text(json.dumps({'archive':str(archive),'sha256':sha(archive.read_bytes()),'all_members_roundtrip_verified':True,'files':[{'path':str(p),'member':str(p.relative_to(private)),'sha256':sha(p.read_bytes())} for p in files]},indent=2)+'\n');paths += [archive,manifest]
pack=b/'source-verified-frozen-raw-packaging';pack.mkdir(exist_ok=False);rows=[];safe=[]
for p in paths:
 raw=p.read_bytes();tracked=subprocess.run(['git','ls-files','--error-unmatch','--',str(p)],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode==0;ignored=subprocess.run(['git','check-ignore','-q','--',str(p)]).returncode==0;binary=p.suffix in ['.gz','.zip','.png'] or b'\0' in raw;bad=not binary and (any(line.endswith((b' ',b'\t',b'\r')) for line in raw.split(b'\n')) or raw.endswith(b'\n\n'))
 if not tracked and (ignored or bad):
  z=pack/(str(len(rows)).zfill(3)+'-'+p.name+'.gz');z.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(z.read_bytes())==raw;rows.append({'original_path':str(p),'raw_sha256':sha(raw),'raw_bytes':len(raw),'gzip_path':str(z),'gzip_sha256':sha(z.read_bytes()),'original_retained_unmodified':True});safe.append(z)
 else:safe.append(p)
manifest=pack/'manifest.json';manifest.write_text(json.dumps({'rule':'Lossless frozen-input packaging only. Mutable audit/frontier/ledger staged DIRECTLY below; never replaced by archives. All private phase1/2/3 exact inputs retained in replay archive.','files':rows},indent=2)+'\n');safe.append(manifest)
mutable=[Path(x) for x in ['research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-determinant.json','research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-determinant.json','runs/substantive_advances.jsonl']];safe+=mutable;subprocess.run(['git','add','--',*[str(p) for p in safe]],check=True);r=subprocess.run(['git','diff','--cached','--check'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT);print(r.stdout.decode());assert r.returncode==0
for p in mutable:assert subprocess.check_output(['git','show',':'+str(p)])==p.read_bytes()
print(json.dumps({'owned_paths_staged':len(safe),'frozen_raw_packaged':len(rows),'all3canonicalmutable_paths_exactly_staged':True,'new_source_verdict_by_root':False}))
