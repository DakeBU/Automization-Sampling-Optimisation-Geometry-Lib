"""Source-to-exact-type binding only; no theorem/API/proof experiment."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json

REPO=Path('/Users/zhouhuanjian/ASTIS-GC')
OWN=Path(__file__).parent
P1=OWN.parent
W=REPO/'.astis/huanjian-gc-fixed-spectrum-detector-20261110'

def sha(b):return hashlib.sha256(b).hexdigest()
def dump(name,data):
    (OWN/name).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')

allowed=[('strict-preproof-seal-projection-v1.json','f1e34ef583a965957cbde49e2005636c338f37615ad153777875438f5433fc9f'),
 ('producer-signature.txt','c1abe1c57e12337dc3592297e624edd757deb18f9eae17ecdc9faca40e2609f4'),
 ('consumer-signature.txt','364843a1d3e581a3b9498eed483b0dff44faad722a67d90c46566da038fc4d2e')]
authorized=[]
for f,h in allowed:
    b=(W/f).read_bytes();assert sha(b)==h
    authorized.append({'path':str((W/f).relative_to(REPO)),'bytes':len(b),'sha256':h,
                       'permission':'Exact type/projection only, no implementation body.'})
    if f.endswith('-signature.txt'):(OWN/'exact_types'/f).write_bytes(b)

projection=json.loads((W/allowed[0][0]).read_text())
assert projection['producer']['signature'].encode()==(OWN/'exact_types/producer-signature.txt').read_bytes()
assert projection['actual_private_consumer']['signature'].encode()==(OWN/'exact_types/consumer-signature.txt').read_bytes()

blocks=[
 ('multivariateGaussian','Probability/Distributions/Gaussian/Multivariate.lean',163,170,
  'Literal covariance-parametrized measure constructor, including documented non-PSD totalization; no covariance/law theorem imported.'),
 ('ChebyshevT','RingTheory/Polynomial/Chebyshev.lean',69,75,
  'First-kind polynomial with integer index; the auxiliary input is a Nat explicitly cast to Int.'),
 ('aeval','Algebra/Polynomial/AlgebraMap.lean',253,258,
  'Polynomial evaluation as real-algebra homomorphism in the matrix algebra, not entrywise evaluation.'),
 ('aevalEquiv','Algebra/Polynomial/AlgebraMap.lean',246,251,
  'Definition unfolded only to identify the aeval constructor; not used for a target proof.'),
 ('matrixInverse','LinearAlgebra/Matrix/NonsingularInverse.lean',169,170,
  'The inverse notation at Lambda is matrix inverse, distinct from the real scalar reciprocal used in B.'),
 ('orthogonalGroup','LinearAlgebra/UnitaryGroup.lean',293,295,
  'Full orthogonal group, with transpose inverse; no determinant-one constraint.'),
 ('unitaryGroup','LinearAlgebra/UnitaryGroup.lean',60,61,
  'Immediate alias underlying orthogonalGroup; no group theorem/proof imported.'),
 ('measureMap','MeasureTheory/Measure/Map.lean',91,93,
  'Literal map is totalized to zero outside AEMeasurable; no supplied map certificate is a theorem input.')
]
defs=[]
for name,rel,a,b,purpose in blocks:
    p=REPO/'.lake/packages/mathlib/Mathlib'/rel
    raw=p.read_bytes();lines=raw.splitlines(keepends=True);part=b''.join(lines[a-1:b])
    fn='definition_blocks/'+name+'.lean.txt';(OWN/fn).write_bytes(part)
    defs.append({'symbol':name,'file':str(p.relative_to(REPO)),'first_line':a,'last_line':b,
                 'block_file':fn,'block_sha256':sha(part),'file_sha256':sha(raw),
                 'purpose':purpose,'authority':'Definition semantics only; not source theorem or target-proof evidence.'})
dump('definition_block_index.json',defs)

binding={
 'kind':'SOURCE_TO_EXACT_TYPE_BINDING_ONLY',
 'authority':'No proof, implementation dependency, Statement Seal acceptance, or coverage verdict.',
 'frozen_phase1_manifest_sha256':'71d3bf703026ca41943bf19af1212a1eabfd72c02a6d1fe2fe72b8d7c11521cc',
 'producer':{
  'name':projection['producer']['name'],'signature_file':'exact_types/producer-signature.txt',
  'signature_sha256':allowed[1][1],
  'source_nodes':['sg:grid11','sg:hard-rotation','br:polynomial-conjugation'],
  'source_use_sites':['S4.E11','S4.SS3.p3.1 / S4.EGx2','S4.SS3.p4.1'],
  'source_output_bound':'The matrix polynomial in the source S_A is the conjugated cosine diagonal O D_n O^T.',
  'root_kind':'Uniform auxiliary algebraic identity expanding an implicit standard source bridge.',
  'output_consumer':{
    'name':projection['actual_private_consumer']['name'],
    'use':'Substitute the actual matrix-polynomial output into S(R z), then apply orthogonal coordinate and norm identities to obtain the latent-coordinate scalar statistic.',
    'not_used_by':'Fixed-A event measurability needs continuity of the literal quadratic statistic; it does not require the cosine-diagonal identity.',
    'implementation_use_status':'Not observed. Exact signatures alone cannot certify that a proof calls the producer.'}},
 'consumer':{
  'name':projection['actual_private_consumer']['name'],'signature_file':'exact_types/consumer-signature.txt',
  'signature_sha256':allowed[2][1],'source_anchor_claim':False,
  'source_nodes':['sg:test','sg:energy-geometry','sg:target-coordinate-transfer','br:event-measurability','br:orthogonal-energy'],
  'source_output_bound':'Conjunction of fixed-O Borel measurability and literal pushforward measure event equality.',
  'root_kind':'Private source-supporting coordinate/pushforward helper, not a printed theorem or full target-probability result.',
  'outputs':[
    {'id':'consumer:borel','meaning':'MeasurableSet {x | 0 < S x}; this is output, not a supplied hypothesis.'},
    {'id':'consumer:map-equality','meaning':'(mu.map R){x|0<S x}=mu{z|0<signed cosine quadratic(z)-2*tau*norm(z)^2}; equality of ENNReal measure values.'}],
  'measure_boundary':'mu is the literal multivariateGaussian 0 Lambda^-1. Its pushforward is not identified with pi_A or with multivariateGaussian 0 A^-1 by this signature.',
  'no_probability_credit':['No IsProbability/covariance identification conclusion','No finite-moment/variance estimate','No pass probability >=.9','No algorithm rejection probability <=.01']},
 'quantifier_map':[
  {'binder':'d:Nat, hd:2<=d','source':'Eq.(11) d>=2; theorem later chooses sufficiently large d','difference':'Retains family domain. Any later large-d discharge is an internal proof edge, not an added MAIN premise.'},
  {'binder':'kappa:Real, hkappa:2<=kappa','source':'Eq.(11) kappa>=2','difference':'Retains closed family domain; positive scalar denominator and positive spectrum must be derived rather than provided as extra inputs.'},
  {'binder':'O:Matrix.orthogonalGroup(Fin d) Real','source':'Hard family O lies in full O(d); source experiment additionally draws Haar independent of seed','difference':'Auxiliary result is pointwise for every fixed full O, including determinant -1. It asserts no Haar/randomness/conditional-history law.'},
  {'binder':'n:Nat in both auxiliaries','source':'Source sets n=2q+1; later ensures 1<=n<d','difference':'Uniform family includes n=0 and all other natural frequencies. Source specialization must be recorded explicitly; no claim that arbitrary n is a source theorem parameter.'},
  {'binder':'tau:Real in consumer','source':'Source sets tau=tau_(d,q), built from an absolute C and q,d','difference':'Uniform literal event equality for all real tau, including negative tau. No positivity, smallness, concentration or source-valid C witness is provided or needed for the equality.'}],
 'definition_map':[
  {'object':'theta / Fin d','source':'i_source=1,...,d','exact':'i_source=i.val+1; (i.val+1/2)pi/d=(i_source-1/2)pi/d','boundary':'No off-by-one or endpoint replacement.'},
  {'object':'Lambda and A','source':'Lambda=diag(lambda_i), A=O Lambda O^T','exact':'Literal same affine cosine spectrum and SAME full O in every occurrence','boundary':'Lambda is precision; the hidden quantity is eigenbasis, not eigenvalues.'},
  {'object':'B','source':'(2A-(kappa+1)I)/(kappa-1)','exact':'(kappa-1)^(-1) is REAL SCALAR reciprocal, acting by scalar multiplication on the MATRIX difference','boundary':'B is not a matrix inverse, a covariance inverse, entrywise division, or a supplied diagonalization certificate.'},
  {'object':'Chebyshev.T and aeval','source':'Degree-n first-kind polynomial T_n','exact':'Polynomial.Chebyshev.T Real (n:Int), evaluated in the real matrix algebra by Polynomial.aeval B','boundary':'Not entrywise cosine or entrywise scalar polynomial application. Scalar identity plus matrix conjugation is a standard source bridge, not proved by this mapping.'},
  {'object':'Lambda^-1 in mu','source':'N(0,Lambda^-1) covariance in hidden coordinates','exact':'MATRIX inverse inside literal multivariateGaussian measure constructor','boundary':'Constructor totalizes non-PSD inputs, as its definition documentation says. Law/covariance recognition under source positivity is a separate obligation; no arbitrary supplied Gaussian-law hypothesis.'},
  {'object':'R and Euclidean wrappers','source':'x=O z, equivalently latent u=O^T x','exact':'WithLp.toLp 2 (O *v WithLp.ofLp z), from EuclideanSpace to itself','boundary':'Rotation is O, not O^T; norm/coordinate transport must be justified. No quotient or noncanonical representative is introduced.'},
  {'object':'S and event','source':'Source matrix-polynomial S_A and E_A={x:S_A(x)>0}','exact':'Literal real quadratic form using dotProduct/matvec, minus 2*tau*Euclidean-norm squared; strict 0<S','boundary':'No x!=0 binder. At zero S=0 for every natural n and real tau, so zero is excluded.'},
  {'object':'RHS coordinate statistic','source':'Energy geometry after applying T_n(cos theta_i)=cos(n theta_i)','exact':'Unnormalized sum_i cos(n theta_i)*z_i^2, signed by (-1)^n, minus 2*tau*norm(z)^2','boundary':'Not the normalized w_i energy coefficient. The normalized source explanation still requires x!=0 and remains a separate preserved source node.'},
  {'object':'mu.map R','source':'Unwritten pushforward transport supporting the displayed coordinate identities','exact':'Actual Measure.map. Its literal definition uses AEMeasurable and otherwise zero; event values have type ENNReal','boundary':'R/event measurability must be established internally to use ordinary pushforward semantics. No toReal conversion, target identification, concentration, or probability estimate follows just from the equality.'}],
 'source_specialization':{
  'substitution':['n:=2*q+1','tau:=tau_(d,q)','O:=the same realized Haar orthogonal matrix of the hard input'],
  'conditions_not_transferred_to_auxiliary_binders':['q>=0 and bounded-query assumption','n<d eventually','absolute C and tau smallness','d-n>=sqrt(kappa)','beta/M positivity and variance budget','Haar/input-seed independence'],
  'reason':'These belong to the downstream source probability proof; widening the helper parameters neither discharges nor deletes them.'},
 'literal_to_true_law_obligations':[
  {'id':'law:latent','needed_for':'Treat literal mu as the mathematical latent N(0,Lambda^-1) with source Gaussian moments','inputs':['source eigenvalue positivity','matrix-inverse positivity/covariance meaning','library constructor-to-Gaussian law characterization'],'status':'Not asserted or proved by these types/mapping.'},
  {'id':'law:rotated-target','needed_for':'Identify mu.map R with actual pi_A=N(0,A^-1)','inputs':['same O orthogonal','matrix inverse compatibility A^-1=O Lambda^-1 O^T','linear Gaussian pushforward covariance law','measurable rotation'],'status':'Separate source/library bridge, not the consumer conclusion.'}],
 'unclaimed_source_descendants':[
  'Absolute concentration C witness and Lemma 4.4 good event',
  'Haar/deferred-rotation/adaptive Krylov law and algorithm output rejection',
  'Lemma 4.5 moment formulas/beta scale and source d0(delta)',
  'Target acceptance >=.9, including Ex25 centered-L2 and Ex26 Chebyshev',
  'Per-input TV comparison, averaging contradiction, precision/cost/worst-cap/expected-cost/minimax lower bound',
  'STAB/integration/publication/site/PURIFIED/wholeGoal'],
 'projection_metadata_boundary':'Supplied binder/definition audits and empty EXCESS lists are input metadata, not an independent verdict by this extractor.'
}
dump('target_binding.json',binding)

overlay={
 'kind':'NONDESTRUCTIVE_SOURCE_GRAPH_OVERLAY','version':'phase2-v1','base_graph':'../source_graph.json',
 'base_graph_sha256':'2d47aa63ead6a81895dd7f81e0a3f854ec9c5041a42dc4d48faa66687ccfe2c1',
 'base_coverage':'../coverage_inventory.json','all_base_nodes_edges_dispositions_preserved':True,
 'implementation_dependency_graph':None,
 'selected_root_scope':'Auxiliary producer identity and private fixed-O literal-pushforward event equality only.',
 'transparent_refinements':[
  {'base':'br:polynomial-conjugation','refinement':'Bind the exact producer output to this existing implicit source bridge; no formal proof credit.'},
  {'base':'br:event-measurability','refinement':'Split fixed-A event Borel property used locally from joint input/event measurability needed for the full source average.'},
  {'base':'br:law-extension','refinement':'Add a generic literal Measure.map bridge for this consumer; do not import the algorithm probability-extension node as a premise of a pointwise pushforward identity.'},
  {'base':'br:Gaussian-laws / sg:target-coordinate-transfer','refinement':'Distinguish constructor measure, latent Gaussian law recognition and rotated-target law recognition. The exact consumer establishes neither law recognition.'},
  {'base':'sg:energy-geometry','refinement':'Add all-carrier unnormalized statistic transport plus explicit zero boundary; preserve nonzero-only normalized energy explanation.'}],
 'nodes':[
  {'id':'ov:aux-parameters','kind':'type-parameter-family','inputs':['hd:2<=d','hkappa:2<=kappa','full fixed O','arbitrary n:Nat','arbitrary tau:Real where used'],'outputs':['literal auxiliary parameter family'],'source_binding':'n=2q+1, tau=tau_(d,q) only on source specialization'},
  {'id':'ov:producer','kind':'exact-output-specification','source_node':'br:polynomial-conjugation','signature_sha256':allowed[1][1],'inputs':['literal grid/rotation/scalar-normalized matrix','all natural n'],'outputs':['actual matrix Chebyshev evaluation = O diag(cos(n theta_i)) O^T'],'proof_status':'UNOBSERVED'},
  {'id':'ov:S-literal','kind':'literal-source-definition','source_node':'sg:test','inputs':['same grid, O, matrix B; arbitrary n,tau'],'outputs':['intrinsic matrix-polynomial S; strict event E'],'zero_boundary':'S(0)=0; 0 outside E; no x!=0 binder'},
  {'id':'ov:event-borel','kind':'consumer-output-specification','source_node':'br:event-measurability','inputs':['fixed matrix coefficients; Euclidean quadratic and norm continuity'],'outputs':['MeasurableSet E'],'proof_status':'UNOBSERVED','not_required':['producer cosine identity','Gaussian moments','Haar law']},
  {'id':'ov:coordinate-isometry','kind':'STANDARD_BRIDGE_OBLIGATION','source_node':'br:orthogonal-energy','inputs':['full O; WithLp coordinate interpretation; real matvec/dotProduct'],'outputs':['S(R z) has signed coordinate cosine quadratic and norm(z)^2 after producer substitution'],'proof_status':'Not supplied by source graph or exact types'},
  {'id':'ov:mu-literal','kind':'literal-measure-definition','inputs':['Lambda matrix inverse; EuclideanSpace'],'outputs':['mu=multivariateGaussian 0 Lambda^-1'],'law_status':'Constructor only; latent law/covariance identification separate'},
  {'id':'ov:R-measurable','kind':'STANDARD_BRIDGE_OBLIGATION','inputs':['literal finite-dimensional linear R(z)=O z'],'outputs':['R measurable, hence AEMeasurable for literal mu'],'proof_status':'Not supplied by exact types'},
  {'id':'ov:map-evaluation','kind':'STANDARD_BRIDGE_OBLIGATION','inputs':['literal mu; measurable R; measurable strict event'],'outputs':['(mu.map R)(E)=mu(preimage R E)'],'definition_boundary':'Measure.map totalizes to zero without AEMeasurable; ordinary pushforward use needs discharge','proof_status':'No Lean API/proof imported'},
  {'id':'ov:map-equality','kind':'consumer-output-specification','inputs':['map preimage evaluation; pointwise unnormalized coordinate identity'],'outputs':['Literal ENNReal map-event equality in exact consumer'],'proof_status':'UNOBSERVED'},
  {'id':'ov:consumer-root','kind':'exact-private-conjunction','signature_sha256':allowed[2][1],'outputs':['MeasurableSet E AND literal map-event equality'],'source_anchor':False,'proof_status':'UNOBSERVED'},
  {'id':'ov:latent-law','kind':'SOURCE_LIBRARY_LAW_OBLIGATION','inputs':['source positive spectrum; matrix inverse/covariance constructor recognition'],'outputs':['literal mu recognized as source latent Gaussian'],'selected_root_input':False,'status':'OUTSIDE_LOCAL_EQUALITY'},
  {'id':'ov:rotated-target-law','kind':'SOURCE_LIBRARY_LAW_OBLIGATION','inputs':['latent law; same orthogonal O; inverse/covariance transport'],'outputs':['mu.map R = pi_A = actual N(0,A^-1)'],'selected_root_input':False,'status':'OUTSIDE_LOCAL_EQUALITY'},
  {'id':'ov:source-instance','kind':'parameter-specialization','inputs':['auxiliary family','n=2q+1','tau=tau_(d,q)'],'outputs':['source statistic coordinate/pushforward adapter at its actual parameters'],'status':'No d0/concentration/moment/probability side conditions discharged'}
 ],
 'hyperedges':[
  {'id':'ov:e-grid','logic':'AND','premises':['sg:grid11','sg:hard-rotation','ov:aux-parameters'],'consumer':'ov:producer','use_site':'S4.E11 plus S4.SS3.p3/p4','consumed_outputs':'same literal spectrum/rotation and scalar-normalized matrix; arbitrary natural frequency','status':'TARGET_BINDING_NOT_IMPLEMENTATION'},
  {'id':'ov:e-S','logic':'AND','premises':['sg:test','ov:aux-parameters'],'consumer':'ov:S-literal','use_site':'exact consumer S let','consumed_outputs':'literal S with source n/tau widened uniformly, not coordinate statistic substituted as definition'},
  {'id':'ov:e-borel','logic':'AND','premises':['ov:S-literal','br:event-measurability'],'consumer':'ov:event-borel','use_site':'consumer left conjunct','consumed_outputs':'fixed-A continuous statistic gives strict Borel event; no joint-A average assertion'},
  {'id':'ov:e-coordinate','logic':'AND','premises':['ov:producer','ov:S-literal','br:orthogonal-energy'],'consumer':'ov:coordinate-isometry','use_site':'S(R z) feeding consumer right conjunct','consumed_outputs':'actual polynomial identity plus same-O coordinate/norm preservation, valid also z=0'},
  {'id':'ov:e-map','logic':'AND','premises':['ov:mu-literal','ov:R-measurable','ov:event-borel'],'consumer':'ov:map-evaluation','use_site':'consumer right conjunct measure-map use','consumed_outputs':'literal measure, measurability of R and fixed event; no Gaussian law, moment or probability assumption'},
  {'id':'ov:e-equality','logic':'AND','premises':['ov:map-evaluation','ov:coordinate-isometry'],'consumer':'ov:map-equality','use_site':'consumer right conjunct exact output','consumed_outputs':'preimage event evaluation and all-carrier pointwise statistic correspondence'},
  {'id':'ov:e-root','logic':'AND','premises':['ov:event-borel','ov:map-equality'],'consumer':'ov:consumer-root','use_site':'exact consumer final conjunction','consumed_outputs':'both stated outputs; branches are not alternative proofs'},
  {'id':'ov:e-specialize','logic':'AND','premises':['ov:consumer-root','ov:aux-parameters'],'consumer':'ov:source-instance','use_site':'source S4.SS3 uses n=2q+1,tau=tau_(d,q)','consumed_outputs':'only the literal coordinate/pushforward adapter; all source probability descendants retained separately'},
  {'id':'ov:e-law-latent','logic':'AND_OBLIGATION_OUTSIDE_SELECTED_ROOT','premises':['ov:mu-literal','sg:grid11','br:Gaussian-laws'],'consumer':'ov:latent-law','use_site':'future actual source latent-Gaussian recognition','consumed_outputs':'constructor semantics under source covariance positivity; not inferred from its name'},
  {'id':'ov:e-law-rotated','logic':'AND_OBLIGATION_OUTSIDE_SELECTED_ROOT','premises':['ov:latent-law','sg:hard-rotation','ov:R-measurable','br:Gaussian-laws'],'consumer':'ov:rotated-target-law','use_site':'source target-coordinate law paragraph, when tied to exact measure','consumed_outputs':'orthogonal covariance/inverse law; not the private map-event equality'}
 ],
 'excluded_from_selected_local_root':[
  {'base_nodes':['sg:krylov','sg:uniform-krylov','sg:algorithm-rates','sg:algorithm-apply','sg:algorithm-probability'],'reason':'Algorithm probability branch, not needed by pointwise fixed-O algebra/map identity; preserved in full author graph.'},
  {'base_nodes':['sg:target-moments','sg:target-bias','sg:bias-scale','sg:target-scale','sg:choose-d0','sg:target-L2','sg:target-probability'],'reason':'Target moments/rates/high acceptance require additional source steps; no claim they are established by exact consumer.'},
  {'base_nodes':['sg:TV-average','sg:contradiction','sg:anchor','scope:QG-definition'],'reason':'TV/minimax conclusion and upstream query definition are outside local helper scope; retained without mutation.'},
  {'base_nodes':['sg:energy-geometry'],'reason':'Normalized energy weights remain substantive source explanation; local all-carrier unnormalized event transport supplies no separate normalized-weights theorem.'}],
 'alternative_OR_routes':[],
 'review_status':'NOT_REVIEWED; graph topology counts have no mathematical authority'
}
dump('source_graph_overlay_v1.json',overlay)

packet={
 'purpose':'Different-actor exact topology challenge from source and type specifications; no implementation proof.',
 'source_sha256':'6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915',
 'phase1_graph_sha256':overlay['base_graph_sha256'],
 'reviewer_exact_read_whitelist':[
  {'path':'.astis/huanjian-resume-20261103/2610.20492v1.html','scope':'S4.p1, S4.Thmtheorem1, S4.p2, S4.SS1, S4.SS2, S4.SS3, A3.SS1–A3.SS4 only; source raw reread permitted'},
  {'path':str((P1/'selected_snippets/index.json').relative_to(REPO))},
  {'path':str((P1/'selected_snippets').relative_to(REPO))+'/*.html'},
  {'path':str((P1/'source_graph.json').relative_to(REPO))},
  {'path':str((P1/'coverage_inventory.json').relative_to(REPO))},
  {'path':str((P1/'standard_bridges.json').relative_to(REPO))},
  {'path':str((OWN/'exact_types/producer-signature.txt').relative_to(REPO)),'sha256':allowed[1][1]},
  {'path':str((OWN/'exact_types/consumer-signature.txt').relative_to(REPO)),'sha256':allowed[2][1]},
  {'path':str((OWN/'definition_block_index.json').relative_to(REPO))},
  {'path':str((OWN/'definition_blocks').relative_to(REPO))+'/*.lean.txt','scope':'Only indexed exact definition blocks, no surrounding Mathlib proofs'},
  {'path':str((OWN/'target_binding.json').relative_to(REPO))},
  {'path':str((OWN/'source_graph_overlay_v1.json').relative_to(REPO))}
 ],
 'withheld':['phase1_raw_cognition.md','phase2_private_process_notes.md','phase2_actual_inputs_and_exposure.json',
             'supplied strict-preproof-seal-projection-v1.json audit metadata/conclusions','all other actors verdicts/notes','all implementation Lean/Tests and proof/API artifacts'],
 'challenge_questions':[
  'Does every selected substantive original paragraph/display remain NODE or EXCLUDED(reason), including the initial test and full eigenvector-energy paragraph?',
  'Is the exact producer genuinely a matrix-polynomial/conjugated-cosine source bridge and is its output used at the mathematical consumer right conjunct, without falsely making it necessary for the left measurability conjunct?',
  'Are source n=2q+1,tau=tau_(d,q), fixed full O, and the widened auxiliary n:Nat,tau:Real scopes mapped without deleting source probability side conditions?',
  'Are scalar reciprocal in B, matrix inverse in mu, real matrix polynomial evaluation and all-carrier strict zero semantics kept distinct?',
  'Does the selected-root map improperly identify literal mu.map R with actual pi_A, or claim probability/moment/algorithm/TV/cost results?',
  'Are standard bridges and uninspected/upstream definition boundaries explicit, with no false AND or hidden additional theorem hypothesis?'
 ],
 'authority':'Reviewer must independently reread source; no proof/coverage credit from counts or supplied audit metadata.',
 'status':'READY_FOR_INDEPENDENT_CHALLENGE_NOT_ACCEPTED'
}
dump('exact_topology_reviewer_packet.json',packet)

exposure={
 'phase':'PHASE2','authorized_new_inputs':authorized,
 'mathlib_definition_exception':{'purpose':'Only type-semantics explanation, no target-proof experiment','indexed_blocks':defs,
   'whole_file_byte_access':'Definition extraction/search tooling byte-read these Mathlib files; only indexed blocks and stated accidental text were semantically displayed.'},
 'unexpected_text_exposure':[
  {'file':'Probability/Distributions/Gaussian/Multivariate.lean','displayed_ranges':[[152,177]],'outside_requested_definition':['152–154 previous proof tail','173–177 next lemma/proof'],'policy':'Not used as source edge, proof evidence or target implementation direction.'},
  {'file':'RingTheory/Polynomial/Chebyshev.lean','displayed_ranges':[[60,79]],'outside_requested_definition':['77–79 beginning of following induct declaration'],'policy':'Not used.'},
  {'file':'Algebra/Polynomial/AlgebraMap.lean','displayed_ranges':[[245,262]],'outside_requested_definition':['260–261 following aevalEquiv_apply rfl lemma'],'policy':'Not used as proof evidence.'},
  {'file':'Algebra/Polynomial/Laurent.lean','displayed_ranges':[[155,155]],'outside_requested_definition':['unrelated definition T matched same short name'],'policy':'Not used.'},
  {'file':'LinearAlgebra/Matrix/NonsingularInverse.lean','displayed_ranges':[[221,221],[448,448]],'outside_requested_definition':['Invertible A inverse instance declaration start','nonsingInvUnit definition declaration start'],'policy':'Not used.'},
  {'file':'LinearAlgebra/UnitaryGroup.lean','displayed_lines':[23,31,288,293,295,297,298,301,302,324,334],
   'outside_requested_definition':'Definition locator pattern additionally displayed membership declarations and one simp proof line; no target proof built from them.','policy':'Not used.'},
  {'file':'MeasureTheory/Measure/Map.lean','displayed_lines':[14,16,74,91,96,99,105,108,113,118,129,149,158,162,166,171,189,194,198,204,208,213,215,216,218,221,226,229,237,241,245,253,269,282,285,303,307,311,314,319,322],
   'outside_requested_definition':'An overbroad definition locator also displayed map API declarations and several inline proof fragments. This is actual unintended API/proof-text exposure despite the definition-only intention.','policy':'All further Mathlib search stopped; no theorem names/proof fragments imported into graph or selected target proof.'}
 ],
 'search_intent':'Exact necessary definitions only; no Lean target proof, compiler, experiment or target API selection was run.',
 'claim_boundary':'Does not claim zero Mathlib proof/API exposure in phase 2; accidental exposure was immediately disclosed to parent.',
 'phase1_immutability':'All phase1 frozen files remain unchanged; overlay is additive and separate.',
 'no_other_inputs':['implementation Lean/Tests','root pre/postseal plans/exposure','topology verdict','other review/lesson/publication','other private work'],
 'projection_audit_exposure':'Supplied projection includes binder/definition audit assertions and no-EXCESS metadata; recorded as input, not independent endorsement.',
 'stopped_at':'Phase2 mapping/input/reviewer-packet freeze; await parent.'
}
dump('phase2_actual_inputs_and_exposure.json',exposure)

# Validate only local artifact shape and preservation; do not run Lean or assess proofs.
mf=json.loads((P1/'phase1_manifest.json').read_text())
assert sha((P1/'phase1_manifest.json').read_bytes())=='71d3bf703026ca41943bf19af1212a1eabfd72c02a6d1fe2fe72b8d7c11521cc'
for f in mf['files']:assert sha((P1/f['file']).read_bytes())==f['sha256']
base=json.loads((P1/'source_graph.json').read_text());baseids={n['id'] for n in base['nodes']}
newids={n['id'] for n in overlay['nodes']}
for e in overlay['hyperedges']:
    assert e['consumer'] in newids|baseids
    assert set(e['premises'])<=newids|baseids
for group in overlay['excluded_from_selected_local_root']:assert set(group['base_nodes'])<=baseids
dump('artifact_integrity_checks.json',{'phase1_manifest_and_all_frozen_file_hashes_unchanged':True,
 'authorized_input_hashes_matched':True,'signature_copies_byte_identical':True,
 'overlay_references_resolve':True,'definition_blocks_have_exact_line_ranges_and_hashes':True,
 'checks_are_artifact_integrity_only':True,'independent_topology_review':'PENDING','mathematical_proof_or_coverage_verdict':False})
print(json.dumps({'phase1_unchanged':True,'definition_blocks':len(defs),'new_overlay_nodes':len(overlay['nodes']),
                  'notice':'No mathematical proof or source-coverage acceptance; graph sizes are observability only.'}))
