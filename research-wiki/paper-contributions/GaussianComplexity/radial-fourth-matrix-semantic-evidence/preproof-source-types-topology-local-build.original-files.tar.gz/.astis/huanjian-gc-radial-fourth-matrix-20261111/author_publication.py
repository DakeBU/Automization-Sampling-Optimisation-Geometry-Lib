"""Author the source explanation once and create the anonymous decoder input."""
from pathlib import Path
import hashlib
import json
import sys

sys.dont_write_bytecode = True
sys.path.insert(0, 'tools')
import astis_publication as publication
import astis_semantic_roundtrip as semantic

workspace = Path(__file__).resolve().parent.relative_to(Path.cwd())
evidence = Path('research-wiki/paper-contributions/GaussianComplexity/radial-fourth-matrix-semantic-evidence')
cell_path = Path('research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-radial-fourth-matrix.json')
runner = Path('.astis/huanjian-resume-20261103')
sha = lambda raw: hashlib.sha256(raw.encode() if isinstance(raw, str) else raw).hexdigest()


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x') as out:
        json.dump(value, out, ensure_ascii=False, indent=2)
        out.write('\n')


def checked_receipt(stem):
    path = runner / (stem + '.receipt.json')
    receipt = json.loads(path.read_bytes())
    log = Path(receipt['log']).read_bytes()
    assert receipt['exit_code'] == 0 and sha(log) == receipt['log_sha256']
    return {'path': str(path), 'sha256': sha(path.read_bytes()), 'log_sha256': sha(log)}, log.decode()


seal = json.loads((workspace / 'statement-seal-v1.json').read_bytes())
P, T = [Path(seal[key]['planned_file']) for key in ('producer', 'actual_private_consumer')]
p_text, t_text = P.read_text(), T.read_text()
name = seal['producer']['name']
private_name = '_private.Tests.GaussianComplexityFixedSpectrumRadialFourthMoment.0.' + seal['actual_private_consumer']['name']
for key, text in [('producer', p_text), ('actual_private_consumer', t_text)]:
    short = seal[key]['name'].split('.')[-1]
    literal = text.split('theorem ' + short, 1)[1].split(' := by', 1)[0].lstrip() + '\n'
    assert literal == seal[key]['signature']
build, _ = checked_receipt('20261111T165523297193Z-radial-fourth-matrix-final-producer-consumer-build')
kernel, log = checked_receipt('20261111T165605138713Z-radial-fourth-matrix-literal-kernel-and-closure')
scalar_parent = 'AutoSamplingTheory.TechnicalLemmas.StochasticProcesses.GaussianFourthMoment.integral_pow_four_gaussianReal_zero'
parents = {name: [scalar_parent], private_name: [name]}
for target, required in parents.items():
    assert 'ACTUAL_SEALED_LITERAL_KERNEL_TYPE_APPLICATION_PASS ' + target in log
    first = log.index('ACTUAL_PUBLIC_ASTIS_PARENTS ' + target + ': [')
    last = log.index(']', first)
    assert all(item in log[first:last] for item in required)
assert 'ALL_OWNED_DECLARATIONS_KERNEL_INSPECTED 4' in log
title = 'The radial fourth matrix moment of a Gaussian row'
statement = r'A standard Gaussian row in dimension \(r\) satisfies \(\mathbb E[\|Z\|^2ZZ^\top]=(r+2)I_r\).'
formula = r'\mathbb E[RZZ^\top]=(r+2)I_r,\qquad R=\|Z\|^2.'
square_formula = (
    r'\begin{aligned}Y_i&=\frac1d(ZZ^\top\otimes t_it_i^\top)\mathbf1_{\{R\le L\}},\\'
    r'Y_i^2&=\frac{R\|t_i\|^2}{d^2}(ZZ^\top\otimes t_it_i^\top)\mathbf1_{\{R\le L\}}.\end{aligned}'
)
bound_formula = (
    r'\mathbb E[Y_i^2]\preceq'
    r'\frac{(r+2)\|t_i\|^2}{d^2}(I_r\otimes t_it_i^\top).'
)
assumptions = [
    r'Let \(d,q\in\mathbb N\), \(2q+1<d\), and \(r=q+1\). The case \(q=0\) has \(r=1\).',
    r'The row has the canonical standard Gaussian law \(Z\sim N(0,I_r)\) on real Euclidean space. Put \(R=\|Z\|^2\).',
    r'For each fixed row \(i\), use \(\theta_j=(j-\tfrac12)\pi/d\) and \(t_j=(1,\sqrt2\cos\theta_j,\ldots,\sqrt2\cos(q\theta_j))\). Lean row \(i\in\mathrm{Fin}(d)\) corresponds to source row \(j=i.val+1\), and feature frequencies are \(0,\ldots,q\).',
    r'The truncation uses the closed event \(R\le L\), where \(L=2r+3\log(1000d)\). The feature length is \(\|t_i\|^2=\sum_{k=0}^q t_i[k]^2\).',
    r'Both matrix integrability assertions are proved conclusions in the Euclidean operator norm. Expectations use the original Gaussian probability measure, and \(\preceq\) is the positive semidefinite order.',
]
boundary = (
    'The canonical row fourth matrix moment and the individual uncentered squared-summand PSD bound are compiled. '
    'The individual bound is the source-supported inference preceding the first aggregate inequality. '
    'Original-family law/integral transport, summed and centered variance, matrix concentration, full Lemma 4.4, '
    'both main lower bounds and oracle/TV/cost adapters remain open. Independent code/source/native review, '
    'serialized integration, actual desktop/mobile delivery and purification remain pending.'
)
source = {
    'url': 'https://arxiv.org/html/2610.20492v1#A3.Ex113',
    'edition': 'arXiv:2610.20492v1; pinned HTML SHA256 ' + seal['source']['raw_sha256'],
    'anchor': 'Appendix C.2 Ex113, Ex114 and p14.3 before the first EGx11 inequality; p1/p10, S4.E11 and Ex85 feature definitions',
    'wording_status': 'faithful paraphrase',
    'attribution': 'On Complexity of Gaussian Sampling, arXiv:2610.20492v1.',
    'scope': 'Exact radial fourth matrix moment and its individual squared-summand consequence.',
}
mathlib = [
    'ProbabilityTheory.IsGaussian.memLp_id', 'MeasureTheory.MemLp.integrable_norm_pow',
    'ProbabilityTheory.stdGaussian_map', 'ProbabilityTheory.map_pi_eq_stdGaussian',
    'LinearIsometryEquiv.piLpCongrRight', 'MeasureTheory.integral_map',
    'MeasureTheory.integral_comp_eval', 'MeasureTheory.measurePreserving_eval',
    'ProbabilityTheory.iIndepFun_pi', 'ProbabilityTheory.IndepFun.integrable_mul',
    'ProbabilityTheory.IndepFun.integral_fun_mul_eq_mul_integral',
    'MeasureTheory.Integrable.mono\x27', 'MeasureTheory.Integrable.indicator',
    'MeasureTheory.Integrable.of_eval', 'MeasureTheory.eval_integral',
    'Matrix.ofLinearEquiv', 'LinearEquiv.toContinuousLinearEquiv',
    'ContinuousLinearMap.integrable_comp', 'ContinuousLinearMap.integral_comp_comm',
    'ContinuousLinearEquiv.integral_comp_comm', 'EuclideanSpace.real_norm_sq_eq',
    'MeasureTheory.integral_finsetSum', 'Matrix.kroneckerBilinear',
    'Matrix.vecMulVec_mul_vecMulVec', 'Matrix.mul_kronecker_mul',
    'Matrix.posSemidef_vecMulVec_self_star', 'Matrix.PosSemidef.smul',
    'Matrix.posSemidef_iff_dotProduct_mulVec', 'Convex.integral_mem',
]


def code(text, first, last):
    return ''.join(text.splitlines(keepends=True)[first - 1:last])


steps = [
    {'title': 'Establish quartic and matrix integrability',
     'text': 'Gaussian finite moments give an integrable fourth power of the Euclidean norm. Each weighted entry is dominated by that fourth power. Finite entry integrability and continuous linear matrix evaluation give the matrix Bochner integral and its entries.',
     'formula': r'|RZ_aZ_b|\le R\|Z\|^2=\|Z\|^4,\qquad \|Z\|^4\in L^1.',
     'lean': code(p_text, 35, 78)},
    {'title': 'Cancel the off-diagonal entries',
     'text': 'Reflect coordinate a while fixing a distinct coordinate b. The standard Gaussian law and squared radius are invariant. The weighted product changes sign, so its integral vanishes.',
     'formula': r'\mathbb E[RZ_aZ_b]=0\qquad(a\ne b).',
     'lean': code(p_text, 80, 103)},
    {'title': 'Evaluate the diagonal fourth and mixed moments',
     'text': 'Transport the canonical Gaussian to its product-coordinate realization. Scalar Gaussian moments give the second moment one and fourth moment three, and independence gives each distinct-coordinate mixed square moment one. Expand the radius in each diagonal entry and combine all entries. The mixed sum is empty when r=1.',
     'formula': r'\mathbb E[RZ_a^2]=\mathbb E[Z_a^4]+\sum_{b\ne a}\mathbb E[Z_a^2Z_b^2]=3+(r-1)=r+2.',
     'lean': code(p_text, 105, 188)},
    {'title': 'Square the actual truncated tensor summand',
     'text': 'Apply the rank-one square identities to the Gaussian and deterministic feature matrices, and use Kronecker multiplication and indicator idempotence. Tensoring the integrable weighted matrix through a fixed continuous linear map proves integrability of the actual square. This fold includes the complete private statement and its algebraic setup.',
     'formula': square_formula,
     'lean': code(t_text, 1, 101)},
    {'title': 'Remove the indicator in positive semidefinite order',
     'text': 'The untruncated matrix W is a nonnegative multiple of the tensor vector outer product. Hence W minus the truncated square is positive semidefinite at every point. The PSD cone is closed and convex, so its integrable residual has PSD expectation. Transport the exact producer mean through the same fixed linear map to obtain the displayed upper matrix.',
     'formula': bound_formula,
     'lean': code(t_text, 103, 160)},
]
unit = {
    'kind': 'theorem', 'reading_layout': 'progressive', 'declaration': name, 'title': title,
    'reader_note': 'Open the assumptions and source steps for the exact objects and Lean.',
    'statement': statement, 'formula': formula, 'assumptions': assumptions, 'steps': steps,
    'astis_dependencies': [scalar_parent], 'mathlib_dependencies': mathlib,
    'dependency_notes': 'The scalar fourth moment reuses the same canonical compiled lemma used by Brownian quadratic variation. The private consumer uses both the new matrix integrability and exact mean. All remaining Gaussian and matrix integration steps use pinned Mathlib facts and internal proofs.',
    'lean_statement': 'Integrable radial fourth matrix moment with its exact scalar-identity expectation.',
    'lean_proof': 'Prove quartic domination, reflect off-diagonal entries, evaluate diagonal Gaussian products, then integrate the PSD residual of the actual squared tensor summand.',
    'boundary': boundary,
    'sources': [{**source, 'label': 'Appendix C.2 fourth moment and PSD truncation step'},
                {'path': str(T), 'line': 14, 'label': 'Complete private squared-summand proof',
                 'scope': 'The individual PSD consequence with the literal cosine feature.'}],
    'tests': ['lake build Tests.GaussianComplexityFixedSpectrumRadialFourthMoment'],
}
slug = 'huanjian-gaussian-radial-fourth-matrix'
audit_id = 'ASTIS-RT-20261111-HuanjianGaussianRadialFourthMatrix'
lesson_path = Path('website/content/declaration_lessons') / (slug + '.json')
pub_path = Path('website/content/publications') / (slug + '.json')
audit_path = Path('research-wiki/semantic-roundtrip/audits') / (slug + '.json')
write(lesson_path, {'schema_version': 1, 'units': [unit]})
binding = {
    'declaration': name, 'cell': cell_path.stem, 'role': 'proof-edge',
    'supports': ['c2-radial-fourth-matrix'], 'boundary': boundary, 'audit_id': audit_id,
    'assumption_deltas': [
        {'source': 'Standard Gaussian row in r=q+1 dimensions with the standing source query range.',
         'lean': 'Actual stdGaussian on real Euclidean Fin(q+1), with 2q+1<d and q=0 included.',
         'classification': 'same', 'reason': 'The local statement realizes the canonical single-row marginal. Original-family transport remains open.'},
        {'source': 'The fourth weighted matrix expectation is (r+2) I_r.',
         'lean': 'Matrix integrability is also an explicit proved conclusion.',
         'classification': 'source-implicit', 'reason': 'The source uses finite Gaussian fourth and mixed moments. No moment or regularity certificate is a premise.'},
        {'source': 'The PSD indicator-removal argument precedes the displayed sum over rows.',
         'lean': 'The private consumer proves the individual bound with exact deterministic feature length.',
         'classification': 'source-implicit', 'reason': 'The individual inference is labeled explicitly. The aggregate and centered variance remain open.'},
    ],
}
item = {
    'id': slug, 'library': 'samplewiki', 'chapter': 'gaussian-sampling-complexity',
    'chapter_path': 'example-cases/samplewiki/companions/gaussian-sampling-complexity.html',
    'title': title, 'source': source, 'statement': statement,
    'formulae': [{'label': 'Radial fourth matrix moment', 'tex': formula},
                 {'label': 'Actual squared summand', 'tex': square_formula},
                 {'label': 'Individual positive semidefinite bound', 'tex': bound_formula}],
    'assumptions': assumptions,
    'obligations': [{'id': 'c2-radial-fourth-matrix', 'label': 'Ex113 with the actual individual squared-summand consumer.'}],
    'bindings': [binding],
}
write(pub_path, {'schema_version': 1, 'items': [item]})
binders, conclusion = seal['producer']['signature'].split(' :\n', 1)
literal = '∀ ' + binders + ',\n' + conclusion
source_text = r'For a standard Gaussian row Z in dimension r=q+1, put R=||Z||^2. In the standing range 2q+1<d, Gaussian fourth moments give E[R Z Z^T]=(r+2)I_r. Off-diagonal entries vanish by sign symmetry, and every diagonal entry equals 3+(r-1)=r+2.'
audit = {
    'id': audit_id, 'state': 'draft',
    'source': {'source_id': 'arxiv2610.20492v1-c2-radial-fourth-matrix', 'url': source['url'],
               'anchor': source['anchor'], 'original_text': source_text,
               'text_sha256': sha(source_text), 'source_snapshot_sha256': seal['source']['raw_sha256']},
    'lean': {'declaration': name, 'file': str(P), 'statement': literal,
             'statement_sha256': sha(literal), 'formalizer': 'huanjian_gc_20261111_radial_fourth_matrix',
             'compiled': True, 'decoder_context': [
                 'EuclideanSpace real Fin n is real Euclidean n-space with the Euclidean norm and Borel structure. stdGaussian is the canonical centered probability law with independent variance-one orthonormal coordinates.',
                 'WithLp.ofLp exposes Euclidean coordinates. Matrix m n real is a finite real array. Matrix.vecMulVec w v has entry w_i v_j. Matrix.one is the diagonal identity and scalar multiplication acts on each entry.',
                 'The matrix norm is the Euclidean L2 operator norm, with its usual finite-dimensional topology. Integrable means a.e. strong measurability and finite norm integral. The matrix integral is the real Bochner integral, whose nonintegrable default is zero.',
             ]},
    'reconstruction': {}, 'semantic_slots': {}, 'deltas': [], 'verdict': 'pending',
    'source_review': {'state': 'pending'}, 'repairs': [],
}
publication.inputs.cache_clear()
publication.load.cache_clear()
audit['publication_binding_sha256'] = publication.binding_digest(item, binding)
audit['publication_context'] = publication.review_context(item, binding)
write(audit_path, audit)
cell = json.loads(cell_path.read_bytes())
cell['parents'] = [scalar_parent]
cell['evidence']['actual_compilation'] = build
cell['evidence']['actual_kernel'] = kernel
cell['evidence']['actual_public_ASTIS_parents'] = parents
cell['evidence'].pop('target_proof_calls', None)
cell['reuse_plan']['reused_declarations'] = [scalar_parent, *mathlib]
cell['reuse_plan']['known_consumers'] = [private_name]
for key in ['source_ordered', 'source_statement_adjacent', 'natural_language_formula_proof',
            'hidden_assumptions_visible', 'lean_collapsed', 'external_dependencies_visible']:
    cell['reader_contract'][key] = True
cell['reader_contract']['status'] = 'Five authored adjacent Lean folds, including the complete private proof split across two adjacent steps. Independent reader and public delivery acceptance pending.'
cell_path.write_text(json.dumps(cell, ensure_ascii=False, indent=2) + '\n')
publication.check_advance([name], reviewed=False)
packet = semantic.decoder_packet(audit)
neutral = Path('.astis/semantic-neutral-20261111/r4_decode_72b6/input.json')
write(neutral, packet)
write(evidence / 'decoder-input.json', packet)
record = {
    'producer_sha256': sha(P.read_bytes()), 'private_consumer_sha256': sha(T.read_bytes()),
    'build': build, 'kernel': kernel, 'actual_public_ASTIS_parents': parents,
    'both_exact_literal_types_kernel_applied': True, 'raw_Expr_structural_equality': False,
    'owned_theorems': 4, 'handwritten': 2, 'generated_internal': 2,
    'publication_binding_sha256': audit['publication_binding_sha256'],
    'neutral_input': str(neutral), 'neutral_input_raw_sha256': sha(neutral.read_bytes()),
    'neutral_canonical_packet_sha256': packet['packet_sha256'], 'anonymous_statement_sha256': sha(literal),
    'step_code_sha256': [sha(step['lean']) for step in steps], 'source_review': 'pending',
}
write(evidence / 'publication-draft-record.json', record)
print(json.dumps(record))
