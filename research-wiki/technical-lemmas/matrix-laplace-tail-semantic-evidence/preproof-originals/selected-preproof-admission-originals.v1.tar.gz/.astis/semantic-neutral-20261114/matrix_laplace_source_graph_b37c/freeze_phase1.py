import datetime, hashlib, json, pathlib
B=pathlib.Path(__file__).resolve().parent
def node(i,kind,anchor,claim,role='source-step',obligation=None):
    return dict(id=i,kind=kind,source_anchor=anchor,claim=claim,role=role,formal_status='UNPROVED_IN_THIS_AUDIT',proof_obligation=obligation or claim)
nodes=[
node('TR.CONVENTIONS','source-definition','Tropp §2.1 p7','Finite square complex self-adjoint matrices; lambda_max is algebraic largest eigenvalue. The spectral norm is largest singular value, a different object. Positive matrix dimension is implicit in existence of lambda_max.','typing-standing'),
node('TR.REGULARITY','standing-assumption','Tropp §2.2 p7','Random objects are sufficiently regular for expectations and operations used; source often suppresses almost-sure qualifiers.','standing'),
node('BG.MEAS','external-background','Tropp §2.2; implicit analytic detail','Specify probability space, measurable matrix map up to AE, measurable algebraic lambda_max, matrix exponential and ordinary trace; events and nonnegative integrals must be well-defined. This is the exact regularity needed here, not all future integrability.','external-background'),
node('BG.SPECTRAL','external-background','Tropp §2.3 p7 / eq(2.1)','Finite-dimensional self-adjoint diagonalization, spectral mapping and ordinary trace as sum of eigenvalues. Real symmetric specialization is valid.','external-background'),
node('TR.EXP','source-definition','Tropp §2.4 p8','Matrix exponential via functional calculus or power series; exp(A) is positive definite for self-adjoint A; tr exp(A) is the unnormalized sum of positive eigenvalues.','definition'),
node('TR.DOMAIN','source-warning','Tropp §3.1 p9 / eq(3.1)','The matrix mgf/cgf discussion starts from an X with all moments, but expressly allows expectations to fail to exist for some real theta. Proposition 3.1 separately takes random self-adjoint Y; all-moment hypotheses must not be imported as a public premise.','domain-warning'),
node('BG.HOMOG','external-background','Tropp Prop3.1 proof p9–10','For theta>0, lambda_max(theta Y)=theta lambda_max(Y). Negative theta would reverse spectral order; theta=0 cannot support the tail transform.','external-background'),
node('TR.EVENT','substantive-proof-step','Tropp Prop3.1 first chain p9','For every t in R and theta>0, {lambda_max(Y)>=t}={lambda_max(theta Y)>=theta t}={exp(lambda_max(theta Y))>=exp(theta t)}.','proof-step'),
node('BG.MARKOV','external-background','Tropp Prop3.1 proof p9–10','For a nonnegative measurable scalar V and a>0, P(V>=a)<=E[V]/a. It remains mathematically valid with canonical nonnegative extended expectation when the integral is infinite; default-zero Bochner integral is not this extension.','external-background'),
node('TR.FIXED.MARKOV','substantive-proof-step','Tropp Prop3.1 first chain p9','P(lambda_max(Y)>=t)<=exp(-theta*t) E exp(lambda_max(theta Y)).','proof-step'),
node('TR.TRACE.DOMINATION','substantive-proof-step','Tropp Prop3.1 proof p10','exp(lambda_max(theta Y))=lambda_max(exp(theta Y))<=tr exp(theta Y), by spectral mapping and positivity of every exp eigenvalue. No normalized trace, norm replacement, Lieb theorem or independent-sum theorem enters.','proof-step'),
node('BG.NONNEG.EXPECTATION','external-background','Tropp Prop3.1 proof p10 / §2.2 and §3.1 domain','Monotonicity of nonnegative scalar expectation yields E exp(lambda_max(theta Y)) <= E tr exp(theta Y). For infinite mgf use the extended nonnegative integral, whose value is infinity, not zero. Finite-Bochner specialization requires an internally established integrability bridge. Source does not name ENNReal or explicitly define extended arithmetic.','external-background'),
node('TR.FIXED','source-derived-interface','Tropp Prop3.1 penultimate display p10','For every theta>0 and every t in R, P(lambda_max(Y)>=t)<=exp(-theta*t) E tr exp(theta Y).','target'),
node('BG.INF','external-background','Tropp Prop3.1 final sentence p10','A scalar lower bound valid for every positive theta is below the infimum over positive theta. In an extended nonnegative codomain, top-valued terms and top-valued infima are meaningful. The index set is nonempty.','external-background'),
node('TR.PROP3.1','source-proposition','Tropp Prop3.1 pp9–10','P(lambda_max(Y)>=t)<=inf_{theta>0} exp(-theta*t) E tr exp(theta Y), for every real t.','target'),
node('GC.MODEL','source-definition','Gaussian S4.SS1.p1; S4.Thmtheorem4.p1; A3.SS2.p1 / Ex85','q is a nonnegative integer; n=2q+1<d, r=q+1; theta_i=(i-1/2)pi/d; g_1,...,g_r are independent N(0,I_d) vectors; gamma_i=((g_1)_i,...,(g_r)_i); t_i=(1,sqrt(2)cos theta_i,...,sqrt(2)cos(q theta_i)). Rows gamma_i have N(0,I_r) laws. r>=1 and d>=2 imply nonempty r^2-dimensional matrices.','model'),
node('GC.TRUNC','source-definition','Gaussian A3.SS2.p10 and A3.Ex107','R_i=||gamma_i||^2, L=2r+3 log(1000d); Y_i=d^{-1}(gamma_i gamma_i^T tensor t_i t_i^T) 1_{R_i<=L}. Radial cutoff uses <=.','definition'),
node('GC.TRUNC.TAIL','substantive-proof-step','Gaussian A3.SS2.p10','For x>=0, P(R_i>2r+3x)<=exp(r log(3)/2-2r/3-x)<=exp(-x); all-row truncation event has probability >=0.999. This strict radial tail is unrelated to the lambda_max tail endpoint.','out-of-current-target'),
node('GC.MEAN','source-step','Gaussian A3.SS2.p12','E[gamma_i gamma_i^T 1_{R_i<=L}]=a I_r, a=r^{-1}E[R_i 1_{R_i<=L}], 0<=a<=1; E Y_i=(a/d)(I_r tensor t_i t_i^T). The quoted Fact C.5 sum identities are not needed for fixed-s tail.','proof-step'),
node('GC.CENTER','source-definition','Gaussian A3.SS2.p13','Z_i=Y_i-E Y_i; second sequence is cos(n theta_i) Z_i. Finite ordinary sums H0=sum_i Z_i and H1=sum_i cos(n theta_i)Z_i.','definition'),
node('GC.RADIUS','substantive-proof-step','Gaussian A3.SS2.p13 / Ex112','||t_i||^2<=2r, ||Y_i||op<=2rL/d, ||E Y_i||op<=2r/d, hence ||Z_i||op<=R*=2r(L+1)/d; same bound for cos(n theta_i) Z_i because |cos|<=1. These are ingredients to prove, not additional public assumptions.','proof-step'),
node('GC.SELFADJOINT','source-step','Gaussian A3.SS2.p15, with literal A3.Ex107','Both centered sequences consist of self-adjoint matrices. Expand from real rank-one tensor symmetry, scalar cutoff, expectation and centering; independence and centeredness are also asserted here for later Bernstein, but not needed for the universal Laplace inequality.','proof-step'),
node('GC.SUM.BOUND','source-gap','implicit bridge from A3.SS2.p13 to trace mgf','Triangle inequality and finite d give ||Hj||op<=d R* for j=0,1; the same holds for -Hj. Must derive measurability, integrability of the centered ordinary matrix expectation and the actual source-defined matrices.','internal-bookkeeping'),
node('GC.FINITE.MGF','source-gap','implicit bridge required for fixed-s finite expectation','For each fixed real s and each Hj with global sign epsilon in {+1,-1}, symmetry and ||Hj||op<=dR* imply 0<tr exp(s epsilon Hj)<=r^2 exp(|s|dR*); constants are finite since d>0. Thus trace exponential is integrable under the original Gaussian probability law. No s-dependent public integrability binder is allowed.','internal-bookkeeping'),
node('GC.FOUR','source-derived-interface','consumer of Tropp fixed-theta at Gaussian A3.SS2.p15 / Ex121 and p15.2','Four fixed-theta consumers: H0,-H0,H1,-H1. For every s>0 and every real u, P(lambda_max(epsilon Hj)>=u)<=exp(-s*u) E tr exp(s epsilon Hj), with finite ordinary expectation. This is an intermediate interface; the source does not print it as its own theorem.','target'),
node('GC.NORM.EVENT','source-gap','bridge to Gaussian A3.Ex121 / p15.2','For self-adjoint Hj, ||Hj||op=max(lambda_max(Hj),lambda_max(-Hj)). For t>0 the strict norm event is the union of strict largest-eigenvalue events, each contained in the corresponding >=t event. Apply a union bound. Do not identify ||Hj||op with lambda_max(Hj), and do not claim equality of > and >= probabilities.','internal-bookkeeping'),
node('GC.BERNSTEIN.CONSUMER','source-consumer','Gaussian A3.SS2.p15 / Ex121 / p15.2','For t>0, source states P(||H0||op>t)<=2r^2 exp(-t^2/[2(v*+R*t/3)]), and the same for H1. Requires separate centered independent-sum mgf / Bernstein route plus variance and optimization, all outside this audit target and unproved here.','downstream-open')
]
def edge(a,b,use): return {'producer':a,'consumer':b,'consumer_use_site':use,'status':'SOURCE_TOPOLOGY_ONLY_NOT_COMPILED'}
edges=[]
def ins(b,aa,use): edges.extend(edge(a,b,use) for a in aa)
ins('TR.EXP',['TR.CONVENTIONS','BG.SPECTRAL'],'§2.4 exponential definition / positivity')
ins('TR.EVENT',['TR.CONVENTIONS','BG.HOMOG','BG.MEAS'],'Prop3.1 first two event equalities')
ins('TR.FIXED.MARKOV',['TR.EVENT','BG.MARKOV','TR.REGULARITY'],'Prop3.1 first inequality')
ins('TR.TRACE.DOMINATION',['TR.EXP','BG.SPECTRAL'],'Prop3.1 p10 displayed spectral mapping and trace bound')
ins('TR.FIXED',['TR.FIXED.MARKOV','TR.TRACE.DOMINATION','BG.NONNEG.EXPECTATION'],'Prop3.1 p10 combine inequalities')
ins('TR.PROP3.1',['TR.FIXED','BG.INF'],'Prop3.1 p10 any positive theta => infimum')
ins('GC.TRUNC',['GC.MODEL'],'A3.p10 / Ex107 literal model construction')
ins('GC.TRUNC.TAIL',['GC.TRUNC','BG.MARKOV'],'A3.p10 Markov at x=log(1000d), then union bound')
ins('GC.MEAN',['GC.TRUNC'],'A3.p12 radial symmetry and mean calculation')
ins('GC.CENTER',['GC.TRUNC','GC.MEAN'],'A3.p13 centered summand definition')
ins('GC.RADIUS',['GC.MODEL','GC.TRUNC','GC.MEAN','GC.CENTER'],'A3.p13 pointwise triangle bound / cosine contraction')
ins('GC.SELFADJOINT',['GC.MODEL','GC.TRUNC','GC.CENTER'],'A3.p15 asserts self-adjoint; definitions provide producer route')
ins('GC.SUM.BOUND',['GC.RADIUS','GC.CENTER','BG.MEAS'],'finite-sum triangle and regularity bridge')
ins('GC.FINITE.MGF',['GC.SUM.BOUND','GC.SELFADJOINT','TR.EXP','BG.SPECTRAL','BG.MEAS'],'fixed real s spectral bound under Gaussian probability measure')
ins('GC.FOUR',['TR.FIXED','GC.CENTER','GC.SELFADJOINT','GC.FINITE.MGF','GC.MODEL'],'four separate j/sign instantiations; finite/extended expectation agreement')
ins('GC.NORM.EVENT',['GC.CENTER','GC.SELFADJOINT','BG.SPECTRAL'],'A3.p15 two-sided spectral union with strict-to-nonstrict inclusion')
ins('GC.BERNSTEIN.CONSUMER',['GC.NORM.EVENT'],'A3.p15 indicates consumer location only; Bernstein numerical estimate still has other open prerequisites')
excluded=[
{'anchor':'Tropp p7 §1.4 roadmap','reason':'Navigation, no proof ingredient.'},
{'anchor':'Tropp §2 opening reference paragraph','reason':'General matrix-analysis background bibliography mapped below, not theorem premises.'},
{'anchor':'Tropp §2.3 eq(2.2)','reason':'Transfer rule is true background, but Prop3.1 only uses diagonalization/spectral mapping and exp positivity; no separate semidefinite comparison needed.'},
{'anchor':'Tropp §2.4 eq(2.3), eq(2.4)','reason':'I+A<=exp A and cosh A<=exp(A^2/2) belong to other mgf estimates; not Prop3.1 or four bounded-consumer interface.'},
{'anchor':'Tropp §2.4 convexity, order monotonicity eq(2.5), Golden–Thompson eq(2.6), triple-matrix warning','reason':'No trace convexity, order monotonicity or product formula is used in Prop3.1 proof; excluded as non-ancestors.'},
{'anchor':'Tropp §2.5–2.7 on rendered pages8–9','reason':'Incidentally visible whole-page context; logarithms, dilation, operator Jensen/expectation order not needed for Prop3.1.'},
{'anchor':'Tropp §3 opening independent-sum context','reason':'Section motivation is not an independence hypothesis of Prop3.1.'},
{'anchor':'Tropp §3.1 formal moment/cumulant series and first/second cumulants','reason':'Coverage retains mgf-domain warning; all-moment X and cumulant expansions are not ingredients for random Y Prop3.1.'},
{'anchor':'Tropp §3.2 attribution [AW02], [Oli10b]','reason':'External provenance, internal proof is actually provided; no opaque producer proposition is assumed.'},
{'anchor':'Tropp §3.3–3.4 / eq(3.2),eq(3.3), Lieb3.2, Cor3.3','reason':'Incidentally visible rendered p10; independent-sum mgf failure, Lieb concavity and trace Jensen are downstream routes, not needed or completed.'},
{'anchor':'Gaussian A3.SS2.p12 Fact C.5 sum-mean identities','reason':'Not necessary for fixed-s trace-integrability / Laplace interface; ordinary EYi is retained, centering each summand is literal.'},
{'anchor':'Gaussian A3.SS2.p13 independence/centeredness beyond symmetry','reason':'Source asserts these for Bernstein; not used as hypotheses for universal Prop3.1 or finite trace-integrability.'},
{'anchor':'Gaussian A3.SS2 variance region / v* derivation / C.6 / broader Lemma C.2 conclusion','reason':'Not read or audited here; separate exact Bernstein/variance and error-budget obligations remain open.'},
{'anchor':'Context extraction matches S4.Thmtheorem3, S4.Thmtheorem7, S4.SS4.SSS0.Px1.p2; A3.SS1.p2/Px1.p10/Px1.p11','reason':'Raw-only automated context matcher emitted extra g/angle mentions; these proof paragraphs were not used as target proof premises. Their contents remain in original command log and are explicitly out of current graph.'}
]
external=[
{'source':'Bhatia [Bha97,Bha07]; Horn–Johnson [HJ85,HJ94]; Higham [Hig08] in §2 intro','use':'Finite-dimensional spectral decomposition / matrix functions / trace eigenvalue sum. Individual formal import availability deliberately unexamined.'},
{'source':'[Par87] in §2.1','use':'Notation provenance only; excluded mathematical dependency.'},
{'source':'Scalar Markov inequality named Prop3.1','use':'Nonnegative scalar tail bound, with measurability and positive scalar threshold; external-background node BG.MARKOV.'},
{'source':'[AW02], [Oli10b] in §3.2','use':'Result provenance only; no unexpanded circular producer used.'},
{'source':'[Pet94], [Bha97 IX.3] in §2.4','use':'Trace convexity/order and Golden–Thompson sources mapped as excluded non-ancestors.'},
{'source':'Gaussian A3.p12 radial symmetry; A3.p10 chi-square mgf','use':'Source-internal producers for center bound / truncation tail. Their Lean availability and completion are unknown.'}
]
data={'schema':'independent-source-only-graph-v1','phase':'PHASE1_FROZEN_SOURCE_ONLY','frozen_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_hashes':{'Tropp.pdf':'f4c3cff8661011395e793972a1f8d9a199fae4ca0fd098535d7a42166cf8fc86','Gaussian.html':'6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'},'independence':{'sealed_P_T_read':False,'seal_audit_read':False,'implementation_read':False,'R14_verdict_read':False,'root_intake_read':False,'Lean_or_Chrome_or_API_or_ledger_or_git_mutation':False},'expectation_ruling_before_candidate':{'source_literal':'Scalar E tr exp, no explicit ENNReal definition; source regularity convention and explicit warning that mgfs may not exist for all theta.','mathematical_completion':'For measurable finite-dimensional self-adjoint Y, trace exp is positive measurable, so its canonical nonnegative extended expectation exists in [0,infinity]. Prop3.1 argument remains valid even if infinite. This is a justified transparent completion of suppressed expectation-domain detail, not a claim that Tropp literally defines ENNReal.','reject':'Replacing nonintegrable real Bochner expectation by its library default zero; assuming finite mgf for every theta as a premise; importing all moments from the separate X discussion; failing to disclose the extension.'},'nodes':nodes,'edges':edges,'exclusions':excluded,'external_background_map':external,'proof_status':'NO_PROOF_OR_FORMAL_API_AVAILABILITY_CLAIM','source_gaps':['BG.MEAS','BG.NONNEG.EXPECTATION','GC.SUM.BOUND','GC.FINITE.MGF','GC.NORM.EVENT'],'downstream_open':['Independent-sum/Lieb trace-mgf bound','variance/Bernstein optimization','C.6 and complete C.2 result','strict-tail probability boundary handled only by inclusion, no atom-free assertion']}
ids={n['id'] for n in nodes}; assert len(ids)==len(nodes)
for e in edges: assert e['producer'] in ids and e['consumer'] in ids
pending=set(ids); done=set()
while pending:
    ready={v for v in pending if all(e['producer'] in done for e in edges if e['consumer']==v)}
    assert ready, 'cycle in source topology'
    pending-=ready; done|=ready
target=B/'phase1.source-only.graph.frozen.v1.json'
assert not target.exists(), 'never overwrite initial freeze'
target.write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n')
manifest={'phase':'PHASE1_FROZEN_SOURCE_ONLY','frozen_utc':data['frozen_utc'],'file':target.name,'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'node_count':len(nodes),'edge_count':len(edges),'exclusion_count':len(excluded),'acyclic':True,'note':'Independent mathematical topology only; not self-approved coverage or completed proof.'}
(B/'phase1.freeze.receipt.v1.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(manifest,indent=2))
