import Tests.GaussianComplexityFixedSpectrumSourceMatrixRadius
import Lean
open Lean Meta Elab Command
open MeasureTheory ProbabilityTheory
open scoped BigOperators Matrix Kronecker Matrix.Norms.L2Operator
set_option autoImplicit false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace RadiusSeal5bf8
def P : Prop := ∀ {d q : ℕ} (hq : 2 * q + 1 < d),
  let D := EuclideanSpace ℝ (Fin d)
  let E := EuclideanSpace ℝ (Fin (q + 1))
  let Ω := Fin (q + 1) → D
  let μ : Measure Ω := Measure.pi (fun _ : Fin (q + 1) => stdGaussian D)
  let r : ℝ := ((q + 1 : ℕ) : ℝ)
  let L : ℝ := 2 * r + 3 * Real.log (1000 * (d : ℝ))
  let θ : Fin d → ℝ := fun i => ((i.val : ℝ) + 1 - 1 / 2) * Real.pi / (d : ℝ)
  let t : Fin d → Fin (q + 1) → ℝ := fun i k =>
    if k.val = 0 then 1 else Real.sqrt 2 * Real.cos ((k.val : ℝ) * θ i)
  let row : Fin d → Ω → E := fun i ω =>
    WithLp.toLp 2 (fun b : Fin (q + 1) => ω b i)
  let Y : Fin d → Ω →
      Matrix (Fin (q + 1) × Fin (q + 1)) (Fin (q + 1) × Fin (q + 1)) ℝ := fun i ω =>
    if ‖row i ω‖ ^ 2 ≤ L then
      (d : ℝ)⁻¹ • Matrix.kronecker
        (Matrix.vecMulVec (WithLp.ofLp (row i ω)) (WithLp.ofLp (row i ω)))
        (Matrix.vecMulVec (t i) (t i))
    else 0
  (∀ i : Fin d, ∀ ω : Ω, ‖Y i ω‖ ≤ 2 * r * L / (d : ℝ)) ∧
    (∀ i : Fin d, ‖∫ ω, Y i ω ∂μ‖ ≤ 2 * r / (d : ℝ))

def T : Prop := ∀ {d q : ℕ} (hq : 2 * q + 1 < d),
  let D := EuclideanSpace ℝ (Fin d)
  let E := EuclideanSpace ℝ (Fin (q + 1))
  let Ω := Fin (q + 1) → D
  let μ : Measure Ω := Measure.pi (fun _ : Fin (q + 1) => stdGaussian D)
  let r : ℝ := ((q + 1 : ℕ) : ℝ)
  let L : ℝ := 2 * r + 3 * Real.log (1000 * (d : ℝ))
  let θ : Fin d → ℝ := fun i => ((i.val : ℝ) + 1 - 1 / 2) * Real.pi / (d : ℝ)
  let t : Fin d → Fin (q + 1) → ℝ := fun i k =>
    if k.val = 0 then 1 else Real.sqrt 2 * Real.cos ((k.val : ℝ) * θ i)
  let row : Fin d → Ω → E := fun i ω =>
    WithLp.toLp 2 (fun b : Fin (q + 1) => ω b i)
  let Y : Fin d → Ω →
      Matrix (Fin (q + 1) × Fin (q + 1)) (Fin (q + 1) × Fin (q + 1)) ℝ := fun i ω =>
    if ‖row i ω‖ ^ 2 ≤ L then
      (d : ℝ)⁻¹ • Matrix.kronecker
        (Matrix.vecMulVec (WithLp.ofLp (row i ω)) (WithLp.ofLp (row i ω)))
        (Matrix.vecMulVec (t i) (t i))
    else 0
  let mean : Fin d → Matrix (Fin (q + 1) × Fin (q + 1)) (Fin (q + 1) × Fin (q + 1)) ℝ :=
    fun i => ∫ ω, Y i ω ∂μ
  let Z : Fin d → Ω → Matrix (Fin (q + 1) × Fin (q + 1)) (Fin (q + 1) × Fin (q + 1)) ℝ :=
    fun i ω => Y i ω - mean i
  let w : Fin d → ℝ := fun i => Real.cos (((2 * q + 1 : ℕ) : ℝ) * θ i)
  let Rstar : ℝ := 2 * r * (L + 1) / (d : ℝ)
  (∀ i : Fin d, ∀ ω : Ω, ‖Z i ω‖ ≤ Rstar) ∧
    (∀ i : Fin d, ∀ ω : Ω, ‖w i • Z i ω‖ ≤ Rstar)


theorem qzeroHyp : 2 * 0 + 1 < 2 := by decide
example {n : Type*} [Fintype n] [DecidableEq n] (A : Matrix n n ℝ) :
    ‖A‖ = ‖Matrix.toEuclideanCLM (n := n) (𝕜 := ℝ) A‖ := rfl
example {n : Type*} [Fintype n] [DecidableEq n] (A : Matrix n n ℝ)
    (x : EuclideanSpace ℝ n) :
    WithLp.ofLp (Matrix.toEuclideanCLM (n := n) (𝕜 := ℝ) A x) =
      A *ᵥ WithLp.ofLp x := rfl

run_meta do
  let env ← getEnv
  let tnames := env.constants.toList.filterMap fun (n,_) =>
    if n.toString.endsWith ".actual_source_centered_summand_radius" then some n else none
  unless tnames.length == 1 do throwError "private consumer not unique"
  let pn := ``AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumSourceMatrixRadius.actual_source_truncated_matrix_norm_bounds
  let tn := tnames.head!
  let mut rows := #[]
  for (n,sn) in [(pn,``P),(tn,``T)] do
    let ci ← getConstInfo n
    let seal := (← getConstInfo sn).value!
    unless Kernel.isDefEqGuarded env {} ci.type seal do throwError "full sealed type mismatch: {n}"
    let v := ci.value! true
    unless !v.hasFVar && !v.hasMVar && !v.hasLooseBVars do throwError "open proof"
    let d : Declaration := .thmDecl {name := Name.str `RadiusSealedClone n.toString,
      levelParams := ci.levelParams, type := seal, value := v}
    match env.addDeclCore 0 100000 d none true with
    | .ok _ => pure ()
    | .error e => throwError "actual proof rejected at exact sealed universal type: {e.toMessageData (← getOptions)}"
    let app := mkAppN (mkConst n) #[mkNatLit 2,mkNatLit 0,mkConst ``qzeroHyp]
    let stype := seal.bindingBody!.instantiate1 (mkNatLit 2)
    let stype := stype.bindingBody!.instantiate1 (mkNatLit 0)
    let stype := stype.bindingBody!.instantiate1 (mkConst ``qzeroHyp)
    let zd : Declaration := .thmDecl {name := Name.str `RadiusZeroClone n.toString,
      levelParams := [], type := stype, value := app}
    match env.addDeclCore 0 100000 zd none true with
    | .ok _ => pure ()
    | .error e => throwError "genuine q=0 application rejected: {e.toMessageData (← getOptions)}"
    rows := rows.push <| Json.mkObj [("actual",toJson n.toString),("sealed",toJson sn.toString),
      ("fullUniversalTypeKernelDefEq",toJson true),("actualProofAtSealedTypeKernelChecked",toJson true),
      ("genuineQ0ApplicationD",toJson (2 : Nat)),("genuineQ0ApplicationKernelChecked",toJson true)]
  IO.FS.writeFile "/Users/zhouhuanjian/ASTIS-GC/.astis/semantic-neutral-20261113/radius_native_5bf8/seal-result.json" (Json.arr rows).pretty
end RadiusSeal5bf8
