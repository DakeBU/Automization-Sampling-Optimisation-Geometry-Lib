"""Capture two actual foreground OS processes; stop on any failure without retry or rollback."""
from common import *
import traceback

def run_window(label,script):
    out=OWN/(label+'.stdout.raw');err=OWN/(label+'.stderr.raw')
    assert not out.exists() and not err.exists() and not (OWN/(label+'-process.receipt.json')).exists()
    argv=[sys.executable,str(OWN/script)]
    env={'HOME':'/Users/zhouhuanjian','PATH':str(Path(sys.executable).parent)+':/usr/bin:/bin','LC_ALL':'C','PYTHONDONTWRITEBYTECODE':'1','PYTHONIOENCODING':'utf-8','GIT_OPTIONAL_LOCKS':'0','ASTIS_ATLAS_ROOT':str(REPO/'.atlas-upstream/v1')}
    started=dt.datetime.now(dt.timezone.utc).isoformat();start=time.monotonic()
    with out.open('xb') as o,err.open('xb') as e:
        process=subprocess.Popen(argv,cwd=REPO,env=env,stdin=subprocess.DEVNULL,stdout=o,stderr=e);pid=process.pid;code=process.wait()
    receipt={'schema':'actual-independent-normal-V-two-window-OS-process-v1','window':label,'argv':argv,'cwd':str(REPO),'environment':env,'pid':pid,'parent_pid':os.getpid(),'started_utc':started,'ended_utc':dt.datetime.now(dt.timezone.utc).isoformat(),'elapsed_seconds':time.monotonic()-start,'exit_code':code,'stdout':{'file':str(out.relative_to(REPO)),'bytes':out.stat().st_size,'sha256':file_sha(out)},'stderr':{'file':str(err.relative_to(REPO)),'bytes':err.stat().st_size,'sha256':file_sha(err)},'executed_script':ident(OWN/script),'common_guard_script':ident(OWN/'common.py'),'streams':'Actual child OS fd1/fd2 redirected into separate raw files; not reconstructed from check flags.','automatic_retry_or_rollback':False}
    write(OWN/(label+'-process.receipt.json'),receipt)
    print(json.dumps({'window':label,'actual_exit_code':code,'receipt_sha256':file_sha(OWN/(label+'-process.receipt.json'))}),flush=True)
    return code

def main():
    assert not (OWN/'normal-V-outcome.public-summary.json').exists()
    first_code=run_window('window1','window1_normal_V.py')
    if first_code:
        write(OWN/'execution-stopped.failure.json',{'status':'STOPPED_AFTER_ACTUAL_WINDOW1_FAILURE;NO_RETRY_OR_WINDOW2','actual_exit_code':first_code,'normal_V_success_not_claimed':True,'inspect_actual_ledger_and_private_marker_before_any_future_action':True})
        return first_code
    first=read(OWN/'window1-success.json');receipt=read(OWN/'window1-process.receipt.json')
    assert first['all_window1_postguards_passed'] and receipt['exit_code']==0
    outcome={
      'schema':'actual-independent-normal-V-public-outcome-v1','status':'NORMAL_VERIFIED_ACTUALLY_RECORDED;API_WINDOW_POSTGUARDS_PASSED',
      'advance_id':ADV,'verified_commit':CARRIER,'verifier_id':VERIFIER,'normal_API_calls':1,'actual_exit_code':receipt['exit_code'],'original24_top_level_fields_unchanged':first['original24_top_level_fields_unchanged'],'exact_appended_record_sha256':first['exact_appended_record_sha256'],
      'exact_appended_record_bytes':first['exact_appended_record_bytes'],'actual_normal_API_returned':True,
      'exact_append':ident(OWN/'normal-V-exact-target-append.jsonl'),'full_V_payload':ident(OWN/'normal-V-final-payload.full.json'),'actual_OS_process_receipt':ident(OWN/'window1-process.receipt.json'),'actual_OS_stdout':ident(OWN/'window1.stdout.raw'),'actual_OS_stderr':ident(OWN/'window1.stderr.raw'),'executed_script':ident(OWN/'window1_normal_V.py'),
      'original24_PL_payload_sha256':PL_SHA,'original24_field_count':24,'verified_public_declarations':[P],'prover_owner':PROVER,'verifier_independent_from_prover':True,
      'immutable_math_build_commit':MATH,'new_build_at_verified_metadata_carrier_claimed':False,
      'current_reader_acceptance_sha256':READER_SHA,'supplemental_reader_actual_exit1_and_2false_retained':True,'wrong_crops_excluded_and_unexecuted_actions_not_claimed':True,'optional_v3_not_executed':True,
      'all_window1_postguards_passed':True,'all_frontiers_including_target_unchanged_in_API_window':True,'all_foreign_states_and_discovery_bytes_unchanged':True,'HEAD_and_exact_index_unchanged':True,'all_other_tracked_bytes_unchanged':True,
      'only_tracked_mutation_in_API_window':'runs/substantive_advances.jsonl exact one target append',
      'target_cell_projection':'Separate subsequent window; this normal-V outcome is based only on the completed API window.',
      'public_guard_scope':'Only target-scoped preservation booleans/counts; full tracked/index/foreign/frontier guard maps remain local-private.',
      'truth_boundary':'One independent normal proof VERIFIED for public P with private T as checked material consumer. No extra public T node, new unchanged-source audit/build/browser run, production/main/global graph/site integration, purification or whole-Goal completion.'
    }
    assert file_sha(OWN/'normal-V-exact-target-append.jsonl')==outcome['exact_appended_record_sha256']
    write(OWN/'normal-V-outcome.public-summary.json',outcome)
    second_code=run_window('window2','window2_target_cell.py')
    if second_code:
        write(OWN/'execution-stopped.failure.json',{'status':'NORMAL_V_RECORDED;STOPPED_AFTER_ACTUAL_WINDOW2_FAILURE;NO_RETRY_OR_ROLLBACK','normal_API_calls':1,'window1_actual_exit_code':0,'window2_actual_exit_code':second_code,'inspect_actual_target_cell_and_guards':True})
        return second_code
    second=read(OWN/'window2-success.json');second_receipt=read(OWN/'window2-process.receipt.json')
    assert second['all_window2_postguards_passed'] and second_receipt['exit_code']==0
    projection={**second,'schema':'actual-independent-target-cell-projection-public-outcome-v1','status':'TARGET_CELL_PROJECTED_IN_SEPARATE_GUARDED_WINDOW','actual_exit_code':second_receipt['exit_code'],'actual_OS_process_receipt':ident(OWN/'window2-process.receipt.json'),'actual_OS_stdout':ident(OWN/'window2.stdout.raw'),'actual_OS_stderr':ident(OWN/'window2.stderr.raw'),'executed_script':ident(OWN/'window2_target_cell.py'),'actual_target_cell_copy':ident(OWN/'target-cell.projected.exact.json'),'actual_field_delta':ident(OWN/'target-cell.projection-delta.json'),'normal_V_public_outcome':ident(OWN/'normal-V-outcome.public-summary.json'),'normal_API_calls_total_across_two_windows':1,'no_Git_or_other_production_mutation':True}
    write(OWN/'target-cell-projection.public-summary.json',projection)
    names=['common.py','window1_normal_V.py','window2_target_cell.py','run_authorized_two_windows.py','normal-V-final-payload.full.json','normal-V-exact-target-append.jsonl','normal-V-outcome.public-summary.json','input-identity-check.public.json','window1-success.json','window1-process.receipt.json','window1.stdout.raw','window1.stderr.raw','window2-success.json','window2-process.receipt.json','window2.stdout.raw','window2.stderr.raw','target-cell.before.exact.json','target-cell.projected.exact.json','target-cell.projection-delta.json','target-cell-projection.public-summary.json']
    paths=[OWN/n for n in names]+sorted((OWN/'input-originals').iterdir())
    assert len(paths)==len({str(p) for p in paths})
    leaves=[]
    for path in paths:
        assert path.is_file() and path.resolve().is_relative_to(OWN)
        relative=str(path.relative_to(OWN));assert 'local-private' not in relative and 'cache' not in relative
        leaves.append({'path':relative,'bytes':path.stat().st_size,'sha256':file_sha(path)})
    write(OWN/'public-safe-selected-originals.manifest.v1.json',{'schema':'explicit-own-normal-V-and-separate-cell-projection-evidence-v1','source_root':str(OWN),'advance_id':ADV,'verified_commit':CARRIER,'normal_API_calls':1,'window1_actual_exit_code':0,'window2_actual_exit_code':0,'private_guards_foreign_maps_whole_ledgers_Git_outputs_index_cache_excluded':True,'raw_process_streams_scripts_append_original24_never_rewritten':True,'leaves':leaves})
    print(json.dumps({'status':'NORMAL_V_ONCE_AND_SEPARATE_CELL_PROJECTION_COMPLETED','advance_id':ADV,'normal_API_calls':1,'cell_status':'independently_verified','normal_V_outcome_sha256':file_sha(OWN/'normal-V-outcome.public-summary.json'),'cell_outcome_sha256':file_sha(OWN/'target-cell-projection.public-summary.json'),'public_manifest_sha256':file_sha(OWN/'public-safe-selected-originals.manifest.v1.json'),'explicit_public_leaves':len(leaves)}),flush=True)
    return 0

if __name__=='__main__':sys.exit(main())
