"""Pin renderer bytes, focused fake-closure scan, explicit held-carrier binding."""
import json,sys
from run import ROOT,REPO,run,sha
I=ROOT/'inputs';m=json.loads((ROOT/'input-manifest.json').read_text());C=m['candidate_commit']
runtime=json.loads((ROOT/'reader-static.json').read_text())['production_runtime']
for i,x in enumerate(runtime):
    r=run('renderer-candidate-'+str(i),['git','show',C+':'+x['path']]);assert r.returncode==0
    assert sha(r.stdout)==x['sha256'] and r.stdout==(REPO/x['path']).read_bytes()==(ROOT/'runtime'/x['path']).read_bytes()
sys.path.insert(0,str(REPO/'tools'));import astis
hits=[];scan=[]
for p in m['modules']:
    t=(I/p).read_text();clean=astis.strip_lean_comments_and_strings(t)
    local=[{'line':i,'text':s.strip()} for i,s in enumerate(clean.splitlines(),1) if astis.FORBIDDEN_REGEX.search(s)]
    assert not local,(p,local)
    scan.append({'path':p,'sha256':sha((I/p).read_bytes()),'forbidden_hits':local})
b=(REPO/'tools/astis.py').read_bytes();(ROOT/'runtime/tools/astis.py').write_bytes(b)
rr=run('fake-scan-runtime-candidate',['git','show',C+':tools/astis.py']);assert rr.stdout==b and rr.returncode==0
(ROOT/'fake-closure-scan.json').write_text(json.dumps({'scope':'exact five frozen local modules only','production_strip_and_FORBIDDEN_REGEX':True,'runtime_sha256':sha(b),'files':scan,'zero_hits':True},indent=2)+'\n')
# Preserve preproof archive as provenance only; its verdicts confer no native credit.
E='research-wiki/paper-contributions/GaussianComplexity/source-row-law-semantic-evidence'
archive=[]
for suffix in ['preproof-source-types-topology-local-build.original-files.tar.gz','preproof-source-types-topology-local-build.original-manifest.json']:
    p=E+'/'+suffix;r=run('preproof-archive-'+str(len(archive)),['git','show',C+':'+p]);assert r.returncode==0
    dest=I/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(r.stdout)
    archive.append({'path':p,'sha256':sha(r.stdout),'bytes':len(r.stdout),'status':'preserved provenance; prior verdicts not reused'})
# Every tracked relevant input needed by a later held metadata carrier byte check.
tracked=[]
for p,v in m['files'].items():
    if not p.startswith('private:'):tracked.append({'path':p,'sha256':v['sha256'],'bytes':v['bytes']})
tracked+=runtime+[{'path':'tools/astis.py','sha256':sha(b)}]
result={'compile_candidate_only':C,'later_carrier_compilation_claimed':False,'tracked_relevant_input_hashes':tracked,'private_probe':m['files']['private:SourceRowLawKernelProbe.lean'],'source_html':{'path':'.astis/huanjian-resume-20261103/2610.20492v1.html','sha256':sha((I/'paper-source.html').read_bytes())},'preproof_originals':archive,'renderer_all_equal_to_candidate':True,'controls':'No ledger, shared imports, Registry, UI source, root Tests, global metadata, git commit or push mutations.'}
(ROOT/'relevant-input-binding.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'tracked_exact_inputs':len(tracked),'renderer_candidate_bytes_equal':True,'fake_closure_hits':0,'preproof_originals':archive},indent=2))
