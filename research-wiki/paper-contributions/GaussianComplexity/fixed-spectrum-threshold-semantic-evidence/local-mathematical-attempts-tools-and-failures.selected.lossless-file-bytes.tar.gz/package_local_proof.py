from pathlib import Path
import json,hashlib,gzip,tarfile,io,re,sys
sys.dont_write_bytecode=True
sys.path.insert(0,'tools')
import astis_advance as adv
W=Path(__file__).parent
E=Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-threshold-semantic-evidence')
C=Path('research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-threshold.json')
L=Path('runs/substantive_advances.jsonl')
ADV='ASTIS-SA-20261110-GaussianComplexityFixedSpectrumThreshold';OWNER='huanjian_gc_20261110_fixed_spectrum_threshold'
sha=lambda b:hashlib.sha256(b).hexdigest()
dump=lambda o:(json.dumps(o,ensure_ascii=False,indent=2)+'\n').encode()
def ref(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def put(p,b):
 p=Path(p);assert not p.exists(),p
 p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
b=json.loads((W/'intake-tracked-private-preservation.json').read_bytes())
S=json.loads((W/'statement-seal-v1.json').read_bytes());prod=Path(S['producer']['planned_file']);test=Path(S['actual_private_consumer']['planned_file']);name=S['producer']['name']
r=json.loads((E/'publication-draft-record-v2-final-Borel.json').read_bytes())
assert sha(prod.read_bytes())==r['producer_raw_sha256']=='b502c1c19e158cf5012d7eb8f374164bac582011c41b9f0bcbc68a32f442b28f'
assert sha(test.read_bytes())==r['Test_raw_sha256']=='a14b973691a8185b3d247b940f364b998cd22dc32e775f90fce6eaab78880ea8'
inventory=E/'actual-kernel-owned-inventory-v2-final-Borel.json';k=json.loads(inventory.read_bytes());assert k['all6_reachable'] and k['both_exact_sealed_types_kernel_applied']
assert not re.search(rb'\b(sorry|admit|axiom)\b',prod.read_bytes()+test.read_bytes())
checks=[]
for stem in ['20261110T043139475706Z-threshold-owned-producer-native','20261110T044718800107Z-threshold-final-explicit-Borel-consumer-native','20261110T044856585176Z-threshold-final-Borel-kernel-exact-types-owned-parents']:
 p=Path('.astis/huanjian-resume-20261103')/(stem+'.receipt.json');d=json.loads(p.read_bytes());assert d['exit_code']==0 and sha(Path(d['log']).read_bytes())==d['log_sha256'];checks.append({'receipt':ref(p),'raw_log_sha256':d['log_sha256'],'scope':'Actual final producer/Test/kernel source bytes on HEADe842 working layer; no new immutable/sourceV/global/site/browser acceptance.'})
put(E/'postproof-conceptual-mirror-audit.json',dump({'status':'none-found','reason':'The source-specific concrete threshold/bias comparison uses the existing Gaussian/L2/Chebyshev spine. No new independently supported cross-domain transport is identified; existing midpoint/Lobatto mechanism bridge stays separate and no SPHMC/PBPS formal edge is claimed. Repeated internal numerical bookkeeping does not create a second compiled public lemma node.','new_Lean_transport_or_global_graph_change':False}))
put(E/'actual-shared-floor-reuse-search-audit.json',dump({'actual_public_producer_parents':r['actual_public_ASTIS_producer_parents'],'actual_private_consumer_parents':r['actual_public_ASTIS_private_consumer_parents'],'source_Tests_inspected':'Prior private Variances contrast and ModeGap/SNR tests were inspected as interface/history context, not invoked as public APIs or copied as the new consumer proof.','actual_reuse':'Canonical ModeGap/Bias are genuinely called by Threshold; the private actual event additionally calls SignalStrength/Variances. Existing canonical actual means/C7/Grid/FourthMoment nodes remain unique in the transitive spine.','Mathlib_retrieval':['log-rpow asymptotics and explicit real-power identities','MemLp.sub with memLp_const; actual integrable squares and integral_mono_ae','variance_eq_integral, integral_const_mul, meas_ge_le_variance_div_sq','EuclideanSpace.proj continuous measurability, finite measurable sum and norm polynomials'],'no_duplicate_wrapper':True,'abstraction_boundary':'Only source-specific tau/query numerical providers are private inside the new module. Generic measure, polynomial, integral, variance and Chebyshev infrastructure is reused from canonical Mathlib/ASTIS. No new shared public leaf or wrapper is claimed.','purification_debt':'Inline source query/bias bookkeeping also occurs inside earlier proofs; this is not claimed as reuse of a private compiled Test or a newly canonical public node. Later purification must audit any shared extraction against real consumers.'}))
payload=[]
explicit={'preseal-exposure-disclosure.json','postseal-process-actions-and-C-family-qualification.json','postseal-additional-informal-planning-exposure.json','preproof-typed-route-diagnosis.json','strict-prospective-process-review-input.json','natural-language-statement-only-draft.json'}
for p in W.iterdir():
 if p.is_file() and (p.suffix in ['.lean','.py'] or p.name.endswith('.lean.txt') or p.name in explicit):payload.append(p)
assert all(not re.search(rb'wxid_[a-z0-9]{8,}|/Library/Containers/com\.tencent',p.read_bytes(),re.I) for p in payload)
buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w') as tar:
 for p in sorted(payload):
  raw=p.read_bytes();ti=tarfile.TarInfo(p.name);ti.size=len(raw);ti.mode=0o444;ti.mtime=0;tar.addfile(ti,io.BytesIO(raw))
archive=E/'local-mathematical-attempts-tools-and-failures.selected.lossless-file-bytes.tar.gz';put(archive,gzip.compress(buf.getvalue(),mtime=0))
with tarfile.open(archive,'r:gz') as tar:
 for p in payload:assert tar.extractfile(p.name).read()==p.read_bytes()
put(E/'local-proof-archive-manifest.json',dump({'archive':ref(archive),'files':[ref(p) for p in payload],'scope':'Exact selected own proof/statement attempts and tools; normalized archive headers, not filesystem metadata. Full raw foreign baselines/states excluded. Frozen source/topology/process bundles separate.'}))
actual=[]
for p in sorted(Path('.astis/huanjian-resume-20261103').glob('20261110T*-threshold-*.receipt.json')):
 d=json.loads(p.read_bytes());raw=Path(d['log']).read_bytes();assert sha(raw)==d['log_sha256'] and len(raw)<10_000_000
 assert not re.search(rb'wxid_[a-z0-9]{8,}|/Library/Containers/com\.tencent',p.read_bytes()+raw,re.I)
 q=E/'actual-local-checks'/p.name;put(q,p.read_bytes());z=E/'actual-local-checks'/(Path(d['log']).name+'.gz');put(z,gzip.compress(raw,mtime=0))
 actual.append({'receipt':ref(q),'log_gzip':ref(z),'exit_code':d['exit_code'],'final_mathematical_proof_credit':any(c['receipt']['sha256']==sha(p.read_bytes()) for c in checks)})
put(E/'actual-local-checks-manifest.json',dump({'checks':actual,'scope':'All actual completed own checks, including failures and before-Borel historical passes. Formation/seal/intake/metadata/static do not acquire mathematical proof credit. Final native Test and final kernel are distinct actual receipts.'}))
put(E/'implementation-and-failure-boundary.json',dump({'failure_class':'IMPLEMENTATION_FAILED','mathematical_refutation':False,'sealed_signatures_changed':False,'source_graph_history':'Original TC2B-1/TC2B-2 HOLD retained; only append-onlyv2 repaired and independently accepted. Pre/postseal planning disclosed; prospective permission does not certify retrospective clean history.','actual_attempts':'ScalarV1 applied a power lemma after gcongr had already reduced to exponent order; ScalarV2 used an inapplicable unbundled monotonicity instance. Combined asymptoticV1 additionally needed explicit Function.comp/rpow_ofNat normalization;V2 passed. ProducerV1 needed explicit negated-division normalization and a nonpositive multiplication lemma;V2 passed. ConsumerV1 used missing MemLp.sub_const and a redundant rfl;V2 used MemLp.sub/memLp_const but function subtraction/pointwise forms and unrestricted rewriting led to mismatches/heartbeats. V3 uses explicit centered integrable types, pointwise change, typed integral equalities and bounded nlinarith context and passed. Explicit polynomial Borel measurability was then separately proved and consumed in final MemLp; final Test/native/kernel pass.','metadata_attempt':'First source-map script used lemma instead of the actual theorem marker for Chebyshev and failed before outputs; v2 uses the exact line397 theorem marker.','no_blind_retry':'Every failed route changed API/representation or exact local diagnosis; no fourth identical unchanged attempt or premise mutation.','remaining':'Independent code/source/native/reader acceptance and normal sourceV pending; global integration and original-owner release separate.'}))
baseline=json.loads((W/'preproof-baseline.json').read_bytes())
put(E/'compact-pinned-environment-and-preservation.json',dump({'environment':{k:baseline[k] for k in ['utc','working_HEAD','Lean_actual','binary','manifest','packages']},'private_baseline_sha256':sha((W/'preproof-baseline.json').read_bytes()),'foreign_frontier_count':len(b['all_frontier_hashes']),'foreign_state_count':len(b['all_foreign_states']),'protected_tracked_files_count':len(b['all_tracked_hashes_except_own_ledger']),'raw_foreign_data_published':False}))
for p,h in b['all_tracked_hashes_except_own_ledger'].items():assert sha(Path(p).read_bytes())==h,p
before=L.read_bytes();states=adv._replay_advances([json.loads(x) for x in before.splitlines()])
assert states[ADV]['state']=='EXPLORING' and states[ADV]['owner_id']==OWNER
assert {k:v for k,v in states.items() if k!=ADV}==b['all_foreign_states']
cellraw=C.read_bytes();cell=json.loads(cellraw)
boundary='Exact positive-numeric-C family and original uniform delta/d/kappa/Natq regime: literal tau>=0,tau<=1/2,tau<=actual Gaussian beta/4, plus a genuine PRIVATE actual shifted diagonal-Gaussian <=0 bad-event probability<=1/10 locally compile. Both exact sealed types kernel-applied;4handwritten+2generated proof declarations all reachable, standard3axioms only. Explicit polynomial Borel measurability is consumed. Sufficient2Rlog/8C envelope, actual-bias half route, and centered Young variance route are distinct from unemitted exact author limiting/L2 intermediates. Fresh full source/native/reader and normal sourceV remain pending. Source absolute-C concentration, rotated detector/law,Krylov/Haar/adaptive algorithm/TV/oracle/precision/cost and both main bounds,shared/latest-main/public-site/desktop-mobile/purification/ExpositionSeal/wholeGoal remain open.'
ma={'status':'none-found','discovery_ids':[],'evidence':str(E/'postproof-conceptual-mirror-audit.json')}
evidence={'result_kind':'theorem-edge','theorem_delta':cell['target_statement'],'lean_files':[str(prod),str(test)],'lean_declarations':[name],'publication_declarations':[name],'focused_checks':checks,'truth_boundary':boundary,'conceptual_mirror_audit':ma,'actual_consumer':'The new actual tau<=beta/4 andtau<=1/2 outputs materially bound the same-law shifted mean/variance; canonical strength produces320 internally and genuine Chebyshev gives real bad-event mass<=1/10. Actual polynomial measurability and finite ofReal conversion are proved, no law/moment/event/strength/smallness certificate input.','source_VERIFIED_or_integration':False}
adv.transition_advance(ADV,'PROVED_LOCAL',worker_id=OWNER,evidence=evidence)
after=L.read_bytes();assert after.startswith(before);app=after[len(before):];assert len(app.splitlines())==1
new=adv._replay_advances([json.loads(x) for x in after.splitlines()]);assert {k:v for k,v in new.items() if k!=ADV}==b['all_foreign_states']
for p,h in b['all_tracked_hashes_except_own_ledger'].items():assert sha(Path(p).read_bytes())==h,p
put(E/'frontier-before-PROVED_LOCAL.raw.json.gz',gzip.compress(cellraw,mtime=0));put(E/'actual-PROVED_LOCAL-append.exact.jsonl',app)
capsule={'state':'PROVED_LOCAL_NOT_SOURCE_VERIFIED','advance_id':ADV,'owner':OWNER,'normal_PROVED_LOCAL_API_calls':1,'append_sha256':sha(app),'foreign_states_preserved':len(b['all_foreign_states']),'foreign_frontiers_preserved':len(b['all_frontier_hashes']),'protected_tracked_files_preserved':len(b['all_tracked_hashes_except_own_ledger']),'producer':{**ref(prod),'declaration':name,'actual_ASTIS_parents':r['actual_public_ASTIS_producer_parents']},'private_consumer':{**ref(test),'actual_ASTIS_parents':r['actual_public_ASTIS_private_consumer_parents'],'source_Anchor':False,'Registry_node':False},'actual_checks':checks,'owned_inventory':ref(inventory),'exact_signatures_kernel_applied':True,'source_to_lean_map':ref(E/'source-to-lean-map-v1.json'),'conceptual_mirror_audit':ma,'truth_boundary':boundary,'sourceV_or_global_or_Goal_complete':False}
put(E/'local-proof-capsule.json',dump(capsule))
cell['status']='proved_locally';cell['parents']=['ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-mode-gap','ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-bias']
cell['consumers'][0]='Compiled private actual_gaussian_source_query_shifted_event_le_tenth: genuine concrete shifted diagonal-Gaussian bad-event probability<=1/10, no caller estimates.'
cell['evidence'].update({'execution_boundary':boundary,'focused_checks':[c['receipt']['path'] for c in checks],'local_proof_capsule':str(E/'local-proof-capsule.json'),'actual_compiled_public_ASTIS_producer_parents':r['actual_public_ASTIS_producer_parents'],'actual_compiled_public_ASTIS_consumer_parents':r['actual_public_ASTIS_private_consumer_parents'],'publication_binding_sha256':r['publication_binding_sha256']})
cell['statement_seal']['status']='EXACT_UNCHANGED_TYPES_COMPILED;_SOURCE_GRAPH_V1_HOLD_AND_V2_REPAIR_RETAINED;_FULL_POSTPROOF_REVIEW_PENDING'
cell['source_proof_coverage'].update({'internal_obligation_list_is_preserved_preproof_history':True,'source_to_lean_map':ref(E/'source-to-lean-map-v1.json'),'current_compiled_scope':'Finite numeric C-family threshold and actual shifted diagonal event only. Exact source n little-o/tau-over-beta limits/early scalar half/L2 triangle intermediates not all emitted; source concentration/rotation/main branches remain open.'})
cell['source_detail_audit']['gap']='Selected numeric threshold and actual shifted diagonal-law probability locally proved; full independent source/provider/native/reader review pending. Source concentration witness/rotated detector/algorithmic/main bounds remain separate.'
cell['source_detail_audit']['fidelity_boundary']=boundary
cell['reuse_plan']['reused_declarations']=list(dict.fromkeys(r['actual_public_ASTIS_producer_parents']+r['actual_public_ASTIS_private_consumer_parents']+['isLittleO_log_rpow_rpow_atTop','MeasureTheory.integral_mono_ae','ProbabilityTheory.variance_eq_integral','ProbabilityTheory.meas_ge_le_variance_div_sq']))
cell['reuse_plan']['known_consumers']=['Compiled private actual_gaussian_source_query_shifted_event_le_tenth: numerical-family actual probability application, NON-ANCHOR.']
cell['reuse_plan']['searched_existing'].append('Actual canonical/pinned Mathlib retrieval and limits: '+str(E/'actual-shared-floor-reuse-search-audit.json'))
cell['conceptual_mirror_audit']=ma;cell['learning_contract']['failure_class']='IMPLEMENTATION_FAILED'
cell['learning_contract']['salvage']['reason']='Exact signatures unchanged through diagnosed scalar/API/pointwise-function/integral representation failures. Both internal providers/public producer/private actual event compile; all6 owned declarations reachable, no dead handwritten/provider copy. Source graph predecessor HOLDs/repair and non-pristine planning preserved; final explicit Borel revision separately bound.'
C.write_bytes(dump(cell))
print(json.dumps({'state':'PROVED_LOCAL','append_sha256':sha(app),'producer_sha256':sha(prod.read_bytes()),'Test_sha256':sha(test.read_bytes()),'sourceV':False,'global':False}))
