import hashlib,json,os,pathlib,platform,subprocess,sys
from run import ROOT,REPO,run
COMMIT='401a3e1faa08fe2173d52017672831d2edbad38f'
def sha(b): return hashlib.sha256(b).hexdigest()
paths=subprocess.check_output(['git','ls-tree','-r','--name-only',COMMIT],cwd=REPO).decode().splitlines()
names=['GaussianFourthMoment','FixedSpectrumGridAlias','FixedSpectrumCosineGram','FixedSpectrumRadialFourthMoment','FixedSpectrumWeightedFrameBound','GaussianComplexityFixedSpectrumWeightedFrameBound']
modules=[next(p for p in paths if p.endswith('/'+n+'.lean')) for n in names]
protocols=['AGENTS.md','CONTRIBUTING.md','docs/proof-digestion-protocol.md','docs/evidence-routed-memory-protocol.md','docs/theorem-publication-protocol.md','docs/contributor-codex-contract.md','.agents/prompts/collaborator-contribution.md','.agents/skills/astis-substantive-advance/SKILL.md','.agents/skills/astis-semantic-roundtrip/SKILL.md']
selected=modules+protocols+['lean-toolchain','lake-manifest.json','lakefile.lean','research-wiki/paper-contributions/GaussianComplexity/weighted-cosine-frame-statement-seal.json','research-wiki/paper-contributions/GaussianComplexity/weighted-cosine-frame-semantic-evidence/source-lean-map.draft.json','website/content/declaration_lessons/huanjian-gaussian-weighted-cosine-frame.json','website/content/publications/huanjian-gaussian-weighted-cosine-frame.json']
manifest={'candidate_commit':COMMIT,'initial_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO).decode().strip(),'platform':platform.platform(),'machine':platform.machine(),'files':{},'modules':modules}
for p in selected:
    r=run('v2-freeze-'+str(len(manifest['files'])),['git','show',COMMIT+':'+p]); assert r.returncode==0,p
    dst=ROOT/'inputs'/p;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(r.stdout)
    manifest['files'][p]={'sha256':sha(r.stdout),'bytes':len(r.stdout),'worktree_same':(REPO/p).read_bytes()==r.stdout}
manifestBytes=(ROOT/'inputs/lake-manifest.json').read_bytes()
assert sha(manifestBytes)=='b83ca83b9cf7caa85fa8b023c2ff9a3fb7a7cce7e1c332e810c348535ec49c37'
dependencies=[]
for p in json.loads(manifestBytes)['packages']:
    dep=REPO/'.lake/packages'/p['name']; h=run('v2-dependency-'+p['name']+'-head',['git','rev-parse','HEAD'],cwd=dep); s=run('v2-dependency-'+p['name']+'-status',['git','status','--porcelain=v1','--untracked-files=all'],cwd=dep)
    assert h.returncode==s.returncode==0 and h.stdout.decode().strip()==p['rev'] and not s.stdout,p['name']
    dependencies.append({'name':p['name'],'head':p['rev'],'clean_including_untracked':True,'cache_path':str(dep/'.lake/build/lib/lean')})
manifest['dependencies']=dependencies
lean=pathlib.Path.home()/'.elan/toolchains/leanprover--lean4---v4.33.0/bin/lean'
manifest['lean_binary']={'path':str(lean),'sha256':sha(lean.read_bytes())}
r=run('v2-lean-version',[str(lean),'--version']);assert r.returncode==0 and b'4.33.0' in r.stdout and b'd8b1897' in r.stdout
r=run('v2-lean-binary-file',['file',str(lean)]);assert r.returncode==0 and b'arm64' in r.stdout
scratch=ROOT/'scratch';scratch.mkdir(exist_ok=True)
for p in modules:
    dest=scratch/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes((ROOT/'inputs'/p).read_bytes())
olean=ROOT/'native-olean';olean.mkdir(exist_ok=True)
assert not list(olean.rglob('*.olean'))
manifest['olean_root_initially_empty']=True
manifest['lean_path']=[str(olean)]+[d['cache_path'] for d in dependencies]
manifest['lean_path_excludes_astis_repo_cache']=str(REPO/'.lake/build/lib/lean') not in manifest['lean_path']
(ROOT/'input-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'frozen_files':len(selected),'native_modules':modules,'dependencies':dependencies,'lean_binary':manifest['lean_binary']},indent=2))
