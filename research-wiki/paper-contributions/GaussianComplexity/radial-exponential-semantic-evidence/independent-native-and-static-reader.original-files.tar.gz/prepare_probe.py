import json
from native import HERE, SOURCE, SEAL, digest


def prop_definition(name, data):
    signature = data['signature']
    assert digest(signature.encode()) == data['signature_sha256']
    binders, proposition = signature.split(' :\n', 1)
    return f'def {name} : Prop := ∀ {binders},\n{proposition}\n'


seal = json.loads((SOURCE / SEAL).read_text())
header = '''import Tests.GaussianComplexityRadialExponential
import Lean

open MeasureTheory ProbabilityTheory
open scoped ENNReal
set_option autoImplicit false

'''
definitions = prop_definition('LiteralSealedProducer', seal['producer']) + \
    prop_definition('LiteralSealedConsumer', seal['actual_private_consumer'])
tail = (HERE / 'probe-body.lean').read_text()
(SOURCE / 'NativeAudit.lean').write_text(header + definitions + tail)
