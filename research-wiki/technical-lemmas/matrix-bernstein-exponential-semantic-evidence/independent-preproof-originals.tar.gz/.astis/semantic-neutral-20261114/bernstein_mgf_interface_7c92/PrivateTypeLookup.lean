import Tests.GaussianComplexityFixedSpectrumSourceMatrixRadius
import Tests.GaussianComplexityFixedSpectrumSourceMatrixStructure
import Lean.Elab.Command

-- Correct the initial numeric-name source-syntax diagnostic without import all.
-- Inspect only constant names and TYPES; never inspect values or dependencies.
open Lean Elab Command in
run_cmd do
  let env ← getEnv
  let suffixes := [
    "AutoSamplingTheory.Tests.GaussianComplexityFixedSpectrumSourceMatrixRadius.actual_source_centered_summand_radius",
    "AutoSamplingTheory.Tests.GaussianComplexityFixedSpectrumSourceMatrixStructure.actual_source_weighted_centered_matrix_structure"]
  for suffix in suffixes do
    let mut found := false
    for (name, info) in env.constants.toList do
      if name.toString.endsWith suffix then
        found := true
        logInfo m!"TYPE_ONLY {name} : {info.type}"
    if !found then
      logInfo m!"TYPE_ONLY_NO_IMPORTED_CONSTANT_WITH_SUFFIX {suffix}"
