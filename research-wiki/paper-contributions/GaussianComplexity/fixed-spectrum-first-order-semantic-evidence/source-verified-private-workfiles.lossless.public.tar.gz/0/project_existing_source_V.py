from pathlib import Path
import copy, datetime, gzip, hashlib, json, shutil, subprocess, sys
sys.path.insert(0, 'tools')
import astis_advance as adv
sha = lambda b: hashlib.sha256(b).hexdigest()
put = lambda p,x: p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
N = Path('.astis/semantic-neutral-20261108/src_4e8f6a')
E = N / 'verification-transition-execution'; P = N / 'verification-transition-preparation'
B = Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-first-order-semantic-evidence')
mf = E / 'execution-manifest.json'
assert sha(mf.read_bytes()) == '5d89d6ac516abf66824b90d7a12fbeb64a70c5aaa46ffb921ee97af565d01fff'
m = json.loads(mf.read_bytes()); assert m['normal_API_calls'] == 1 and len(m['artifacts']) == 14
for row in m['artifacts']:
    raw = (E / row['path']).read_bytes(); assert sha(raw) == row['sha256'] and len(raw) == row['bytes']
before = (E/'substantive_advances.before.jsonl').read_bytes()
after = (E/'substantive_advances.after.jsonl').read_bytes()
append = (E/'normal-api.exact-append.jsonl').read_bytes()
assert after == before + append and len(append.splitlines()) == 1
assert sha(append) == m['exact_append_sha256'] == '306b3ebcc5e659b5f2877a9ebe8ff010c09183a47c4b65be767b4ed489e9a99f'
lp = Path('runs/substantive_advances.jsonl'); assert lp.read_bytes() == after
event = json.loads(append)
assert event['worker_id'] == event['evidence']['verifier_id'] == m['actor'] == '/root/source_reader_4e8f6a'
assert event['evidence']['verified_commit'] == m['checked_candidate_commit'] == '9d306d837fbddf1518b0035494baaf5c21c24488'
ap = Path('research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-first-order.json')
audit_raw = ap.read_bytes(); audit = json.loads(audit_raw)
assert sha(audit_raw) == m['accepted_successor_audit_sha256'] == 'a14867ad5fd8723933500d4c264c91c05d6b11ef510090c3b6da216fcb402b57'
assert json.loads(subprocess.check_output(['git','show',m['checked_candidate_commit']+':'+str(ap)]))['state'] == 'blind-reconstructed'
baseline = json.loads((P/'preservation-baseline.json').read_bytes())
assert all(sha(Path(p).read_bytes()) == h for p,h in baseline['frontier_hashes'].items())
auth = json.loads((P/'root-authorization.json').read_bytes())
assert all(sha(Path(p).read_bytes()) == h for p,h in auth['additional_raw_preservation_pins'].items())
for s, name in [(P,'verification-transition-preparation'),(E,'verification-transition-execution')]:
    dst = B/'fresh-source-reader-4e8f6a'/name; assert not dst.exists(); shutil.copytree(s,dst)
    for q in s.rglob('*'):
        if q.is_file(): assert (dst/q.relative_to(s)).read_bytes() == q.read_bytes()
aid = m['advance_id']; states = adv.current_advances(); assert states[aid]['state'] == 'VERIFIED'
assert states[aid]['owner_id'] == m['proof_owner']
assert not [k for k,v in states.items() if v['state'] == 'STABILIZING']
cp = Path('research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-first-order.json')
old_raw = cp.read_bytes(); cell = json.loads(old_raw)
foreign = {str(p):p.read_bytes() for p in cp.parent.glob('*.json') if p != cp}
dp = Path('runs/substantive_discoveries.jsonl'); discovery = dp.read_bytes()
readme = Path('research-wiki/paper-contributions/GaussianComplexity/README.md'); readme_raw = readme.read_bytes()
cell['evidence'].setdefault('source_phase_history',[]).append({k:copy.deepcopy(cell[k]) for k in ['status','statement_seal','source_detail_audit','graph_contribution']})
cell['status'] = 'independently_verified'
cell['statement_seal']['status'] = 'EXACT_PRODUCER_AND_REAL_CONSUMER_COMPILED_INDEPENDENT_SOURCE_ACCEPTED_CANONICAL_INTEGRATION_PENDING'
cell['evidence']['existing_source_V'] = {
    'actor':m['actor'], 'checked_immutable_commit':m['checked_candidate_commit'],
    'accepted_audit_sha256':sha(audit_raw), 'actual_unique_normal_V_append_sha256':sha(append),
    'execution_manifest':str(B/'fresh-source-reader-4e8f6a/verification-transition-execution/execution-manifest.json'),
    'execution_manifest_sha256':sha(mf.read_bytes()),
    'source_review_run_sha256':'c7524efc49a5193ba912807ecd56c4b2669a65a7b3f04e7af7079ccb10c289e1',
    'accepted_bytes_in_checked_commit':False, 'accepted_bytes_first_carrying_commit':'Next sourceV metadata commit, not retroactively checked9d.',
    'root_source_verdict_or_API_created':False, 'runtime_pixel_acceptance':False}
boundary = 'The exact actual fixed-spectrum genuine derivative/value-gradient producer and real same-O forward affine consumer are independently source/module/freshLean/kernel/anonymous/both-sign/fakeclosure/STATIC-reader VERIFIED by the original independent actor. Checked9d contains the blind predecessor; accepteda148 bytes and actualV306b append are later successor metadata. Actual producer1/Test2 canonical ASTIS parents and standard3axioms remain exact. Canonical immutable-core Lean/rootTests/site/graph/desktop-mobile/runtime acceptance, remote delivery, purification/Seal and full Goal remain open. Remaining C4 C-infinity/Hessian/strong-convexity/smoothness/minimizer, true adaptive/oracle/precision/TV/deterministic/expected-cost adapters and both complete main lower bounds are separate.'
cell['evidence']['execution_boundary'] = boundary
cell['source_detail_audit']['gap'] = 'Selected local first-order source meaning, genuine derivative existence and consequential same-O forward-affine consumption are independently accepted. Wider C4 and operational/adaptive/precision/TV/cost/main results remain separate; actual runtime reader acceptance is pending integration.'
cell['source_detail_audit']['fidelity_boundary'] = boundary
cell['source_proof_coverage']['independent_implementation_review'] = {
    'path':str(B/'fresh-source-reader-4e8f6a/phase3/independent_source_semantic_verdict.json'),
    'sha256':sha((N/'phase3/independent_source_semantic_verdict.json').read_bytes()),
    'scope':'Selected actual derivative/value-gradient producer and real same-O forward private consumer. Original sourcegraph/preproof obligations remain phase history, not new compiled credit.',
    'ancestor_sourceV_upgraded':False}
cell['graph_contribution']['visual_review'] = 'Independent source V covers owned STATIC reader only. Actual immutable-core graph/desktop-mobile Chrome/pixel acceptance is pending; preserve one canonical producer parent, two actual private Test parents and typed nonformal mechanism supplement.'
put(cp,cell)
assert lp.read_bytes() == after and ap.read_bytes() == audit_raw and dp.read_bytes() == discovery
assert adv.current_advances() == states and all(Path(p).read_bytes() == raw for p,raw in foreign.items())
assert readme.read_bytes() == readme_raw
(B/'frontier-before-existing-V-projection.lossless.json.gz').write_bytes(gzip.compress(old_raw,mtime=0))
put(B/'mechanical-existing-source-V-projection.json', {
    'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'kind':'Own-cell mechanical projection of existing independent normal V; no new source verdict/API',
    'before_sha256':sha(old_raw),'after_sha256':sha(cp.read_bytes()),
    'source_verifier':m['actor'],'checked_commit':m['checked_candidate_commit'],
    'actual_source_V_append_sha256':sha(append),'accepted_audit_sha256':sha(audit_raw),
    'foreign_frontiers_preserved':len(foreign),'all_SAU_states_and_both_ledgers_unchanged':True,
    'README_and_models_unchanged':True,'source_verdict_created':False,
    'actual_root_site_runtime_acceptance':False})
print(json.dumps({'projected_existing_independent_V':True,'foreign_frontiers_preserved':len(foreign),
    'actual_V_append_sha256':sha(append),'no_root_source_verdict_or_API':True}))
