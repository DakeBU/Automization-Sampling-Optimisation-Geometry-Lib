from pathlib import Path
import subprocess, hashlib, json, datetime
OUT=Path(__file__).parent
ROOT=Path.cwd()
cmds=[
 ('procedural-agents-first',['sed','-n','1,239p','AGENTS.md']),
 ('procedural-agents-last',['sed','-n','240,499p','AGENTS.md']),
 ('procedural-digestion',['cat','docs/proof-digestion-protocol.md']),
 ('procedural-publication',['cat','docs/theorem-publication-protocol.md']),
 ('procedural-evidence',['cat','docs/evidence-routed-memory-protocol.md']),
 ('procedural-skill',['cat','.agents/skills/astis-source-dependency-audit/SKILL.md']),
 ('source-sections-read',['python3',str(OUT/'read_source.py'),'S4.SS1','S4.SS2','A3.SS2']),
 ('source-range-raw',['sed','-n','3363,3376p','.astis/huanjian-resume-20261103/2610.20492v1.html']),
 ('source-final-raw',['sed','-n','3791,3836p','.astis/huanjian-resume-20261103/2610.20492v1.html']),
]
receipts=[]
for name,argv in cmds:
 t=datetime.datetime.now(datetime.timezone.utc).isoformat()
 p=subprocess.run(argv,capture_output=True)
 (OUT/(name+'.captured.stdout')).write_bytes(p.stdout)
 (OUT/(name+'.captured.stderr')).write_bytes(p.stderr)
 receipts.append({'name':name,'argv':argv,'cwd':str(ROOT),'started_utc':t,'returncode':p.returncode,
 'stdout_bytes':len(p.stdout),'stdout_sha256':hashlib.sha256(p.stdout).hexdigest(),
 'stderr_bytes':len(p.stderr),'stderr_sha256':hashlib.sha256(p.stderr).hexdigest(),
 'provenance':'actual capture of this rerun, not a retrospective claim to have captured the initial tool call'})
(OUT/'read_capture_receipts.json').write_text(json.dumps(receipts,indent=2)+'\n')
print(json.dumps(receipts,indent=2))
