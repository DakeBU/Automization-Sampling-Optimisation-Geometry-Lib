# Independent raw-source cognition — Phase 1

Identity: source reviewer `/root/source_reader_c24a61`. This record was formed from the pinned HTML and the applicable process instructions before any candidate statement, implementation, blind reconstruction, audit, lesson, repository graph, other reviewer artifact, or earlier verdict was supplied. This is a source cognition record, not a source-versus-candidate verdict or an acceptance decision. It proposes no repair.

Pinned source: Huanjian Zhou and Taiji Suzuki, *On Complexity of Gaussian Sampling*, arXiv:2610.20492v1; original local HTML `.astis/huanjian-resume-20261103/2610.20492v1.html`, SHA-256 `6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915`. All line references below are original HTML lines, not a rendered or reconstructed version. Exact fragments are retained alongside the reading projections. The projection renders each original MathML `alttext` as mathematical text, including multiline attributes.

## 1. Reading boundary and mathematical objects

The complete mathematical slice read is Section 4 (`S4`, lines 1054–1600) and Appendix C.3 (`A3.SS3`, lines 3837–4134). The actual standing definitions are Section 2, lines 636–752. Source title/authors and the adjacent abstract were exposed in lines 281–308; the abstract is outside the proof slice and is not used as proof evidence. The complete paper heading inventory was exposed for navigation. The exact in-paper bibliography item linked as reference [22] was read at lines 1847–1855. No external preprint was opened. Deferred proofs in C.1, C.2, and C.4 were not read and receive no proof acceptance from this Phase 1.

Section 2 fixes Euclidean norm, identity matrices, the Loewner ordering, and real orthogonal groups with Haar probability (`S2.p1`, `S2.p2`, lines 638–653). Its determinant-conditioned Haar measures are background definitions, not an ingredient of the hidden-eigenbasis argument read here.

The precision class is the literal set

`A_{d,k} = { A in R^{d x d} : A=A^T and I_d <= A <= k I_d }`,

for integer `d>=1` and real `k>=1` (`S2.Ex1`, lines 663–669). The target attached to an input is the literal centered Gaussian law `pi_A=N(0,A^{-1})`; the potential is `f_A(x)=x^T A x/2` (lines 670–672). These are actual measures and matrices, not objects characterized only by a finite list of moment equations.

The Section 4 hard family specializes to integer `d>=2`, real `k>=2`, indices `i=1,...,d`, and

`theta_i=(i-1/2) pi/d`, `lambda_i=(k+1)/2+(k-1)cos(theta_i)/2`, `Lambda=diag(lambda_i)`.

This is Eq. (11), `S4.E11`, lines 1090–1097. Its random input is `O~Haar(O(d))`, independent of the algorithm's seed, with `A=O Lambda O^T` (1098–1101). The spectrum is fixed, may be revealed to the algorithm, and determines the Gaussian normalization; only the eigenbasis is hidden (1103–1107). The eigenvalues are distinct because the midpoint angles lie strictly increasingly in `(0,pi)` and the cosine coefficient `(k-1)/2` is positive. Their bounds `1<=lambda_i<=k` are elementary from `|cos|<=1`. Lemma 4.6 states admissibility for every orthogonal O, not just almost every O.

For a query count `q`, the literal block Krylov space is

`K_q(g_1,...,g_{q+1}) = span { Lambda^j g_a : 1<=a<=q+1, 0<=j<=q }`

(`S4.Ex10`, 1153–1159). Here q is a nonnegative integer query budget; q+1 seeds account for arbitrary output vectors. For `n=2q+1`, the test matrix in eigen-coordinates is `D_n=diag(cos(n theta_i))` (`S4.Ex12`, 1197–1203). Later target-moment statements allow every integer `1<=n<d`, beyond the odd frequency used by the lower-bound proof.

The target-moment law is `U~N(0,Lambda^{-1})`, with

`r=r_k=(sqrt(k)-1)/(sqrt(k)+1)`, `M=E ||U||^2`, and `mu_n=E[U^T D_n U]`

(`S4.Thmtheorem5`, 1261–1293). The standing `k>=2` implies `0<r<1`. Inverse-spectrum series and log formulas below depend on this domain. They are not source statements for arbitrary real k, k=1, or arbitrary probability laws.

## 2. Oracle, randomness, accuracy, and cost meanings

At any real vector x, the exact first-order oracle returns `(x^T A x/2, A x)` (`S2.E1`, 674–681). A first-order reply contains Ax, and a matrix-vector reply Ax determines the value through the inner product. Thus exact value-and-gradient, gradient-only, and matrix-vector query costs coincide (683–691). Queries are unrestricted real vectors; there is no imposed norm bound or finite numerical precision in these definitions.

Algorithms choose queries and stopping decisions as Borel functions of private randomness and past replies; their output may be any R^d-valued Borel function of the same information (696–705). The seed is independent of the input. Fixed budget T means at most T queries for every admissible input and every seed realization. A random stopping rule is allowed subject to this deterministic cap. The source does not use expected query count, tail-bounded query count, bit cost, arithmetic-operation cost, or finite-precision oracle access here.

For fixed A, `rho_A^Alg` averages over all algorithm randomness. Total variation is `sup_B |P(B)-Q(B)|`, equivalently one half of the L1 density difference (`S2.Ex2`, 713–719). The requirement in `Q_G(d,k,epsilon)` is a uniform bound over every A in the precision class on this output law; its definition is an infimum over integer deterministic caps admitting an algorithm (`S2.E2`, 736–745). It is not a pathwise accuracy requirement for each seed. Section 2 defines it for `0<epsilon<1`; Theorem 4.1 specializes to `0<epsilon<=1/10`.

No distribution-free lower bound for an arbitrary law with matching means is asserted. Neither known normalization nor known eigenvalues remove the hidden-eigenbasis difficulty. Remark 4.2 gives the exact affine relation `A=(k-1)A_2-(k-2)I` for the same O, hence mutual simulation of single matrix-vector replies. This is an information equivalence of the two matrix oracles, not an assertion that their target Gaussian laws coincide or that sampling costs follow from mere rescaling of outputs.

## 3. Exact Section 4 statement inventory and quantifiers

**Theorem 4.1** (`S4.Thmtheorem1`, 1062–1076): for every fixed real `delta in (0,1)` there is `d_0(delta)` such that for every integer `d>=d_0(delta)`, every `2<=k<=d^{1-delta}`, and every `0<epsilon<=1/10`,

`Q_G(d,k,epsilon) >= (delta/256) sqrt(k) log d`.

The threshold d_0 depends only on delta. The coefficient delta/256 is explicit; the paper gives no explicit numerical d_0. The guarantee includes algorithms that are given the fixed spectrum. It has no improving dependence on epsilon as epsilon decreases. Section 4 p2 compares parameter coverage with Theorem 3.1; this comparison is contextual only, and Theorem 3.1's proof is outside this read.

**Lemma 4.3** (`S4.Thmtheorem3`, 1161–1174): fix integer `q>=0` with `2q+1<d`; for the output X of the q-query algorithm on the random hard input there exist independent `g_1,...,g_{q+1}~N(0,I_d)` such that `O^T X in K_q` almost surely. Section 4's application specifies an extension preserving the joint law of `(O,X)` (1391–1393). The g's are independent of each other; the stated conclusion does not assert they are independent of `(O,X)` or all extended information. Polynomial coefficients may depend on the entire extended experiment. One must not add a Krylov-output restriction to the public algorithm class: this is a derived coupling/representation ingredient.

**Lemma 4.4** (`S4.Thmtheorem4`, 1207–1231): there exists an absolute positive constant C such that with integer `q>=0`, `2q+1<d`, and independent standard Gaussian g's, put

`tau_{d,q}= C[(q+1)sqrt(log d/d) + ((q+1)(q+1+log d) log d)/d]`.

If `tau_{d,q}<=1/2`, with probability at least .99 every u in K_q satisfies `|u^T D_n u|<=2 tau_{d,q} ||u||^2`. The event is simultaneous over all vectors; consequently adaptive random polynomial coefficients are covered. Since lambda is a nonconstant affine function of cosine, K_q can be generated by `(g_a)_i cos(j theta_i)` for `j<=q`. The estimate is independent of k (1232–1241). The bound then applies to X through Lemma 4.3, not by an assumed independent relation between X and the g's.

**Lemma 4.5** (`S4.Thmtheorem5`, 1261–1293): with the standing finite grid, `k>=2`, the literal Gaussian U, and integer `1<=n<d`,

`M=(d/sqrt(k)) (1-r^{2d})/(1+r^{2d})`,

`(-1)^n mu_n=(d/sqrt(k)) (r^n-r^{2d-n})/(1+r^{2d})`.

Both `Var(||U||^2)` and `Var(U^T D_n U)` are at most `2M<=2d/sqrt(k)`. The exact means and variance bounds require no additional gap condition. If `d-n>=sqrt(k)`, the further bound is

`(1-exp(-4)) exp(-3n/sqrt(k)) <= |mu_n|/M <= exp(-2n/sqrt(k))`.

For an exact conditional target sample `Y|O~pi_A`, `U=O^T Y` has the fixed Gaussian law above, and the norm and cosine quadratic form agree (1294–1300). This supplies target probabilities for every fixed rotation/input, not just an average target moment over Haar O.

**Lemma 4.6** (`S4.Thmtheorem6`, 1311–1317) is the every-O admissibility statement. Its proof is deferred to C.4, not included in this read.

**Lemma 4.7** (`S4.Thmtheorem7`, 1526–1539): for every integer `q>=0` and independent standard Gaussian vectors, `dim K_q=min{d,(q+1)^2}` almost surely. This statement uses the fixed distinct spectrum. It is not restricted by `2q+1<d` or a small-tau guard. No proof of this dimension assertion occurs in the in-scope slice, and no proof is credited here.

**Remarks 4.2 and 4.8** are substantive source items. The former describes the affine oracle relation and the source of sqrt(k) through different target bias. The latter explicitly limits the limitations to this proof and leaves stronger lower bounds for the same fixed-spectrum family open.

## 4. Complete Appendix C.3 proof cognition

The introduction `A3.SS3.p1` (3840–3847) recalls the literal grid and specifies the route: inverse-spectrum Fourier expansion, finite-grid summation, variance estimates, then normalized bias.

**Fact C.7**, `A3.Thmtheorem7` and `A3.Ex133` (3848–3861): for every real theta,

`2/[k+1+(k-1)cos(theta)] = (1/sqrt(k))[1+2 sum_{j>=1} (-r)^j cos(j theta)]`,

and the series converges absolutely and uniformly in theta. The domain k>=2 and the meaning of r are inherited from Section 4/Lemma 4.5. This is a pointwise formula for a specified reciprocal function over every real theta, with a uniform convergence conclusion. A mere coefficient identity on the finite grid or an unproved infinite-sum placeholder would omit part of this source conclusion.

The proof `A3.SS3.p2` (3864–3899) uses the two complex geometric series to obtain `(1-r^2)/(1+2r cos(theta)+r^2)`. The two displayed identities `A3.Ex136` are `(1-r)/(1+r)=1/sqrt(k)` and `(1+2r cos(theta)+r^2)/(1-r)^2=[k+1+(k-1)cos(theta)]/2`. Together they give the reciprocal-spectrum formula. Since the absolute summands are bounded by r^j and `sum_{j>=1}r^j=r/(1-r)`, convergence is absolute and uniform. The ordinary geometric-series identity, complex exponential/cosine relation, and uniform geometric tail bound are background mathematical ingredients, not extra source hypotheses. No probabilistic expectation interchange is used here.

**Fact C.8**, `A3.Thmtheorem8` and `A3.Ex138` (3901–3913): for integer `1<=n<d` the two exact formulas for M and signed mu_n above hold. Its proof is fully present at 3914–4006.

First, for every integer kappa_index (a frequency, unrelated to the condition-number k), the midpoint-grid cosine sum is d(-1)^a if that frequency equals 2ad for integer a, and zero otherwise (`A3.Ex139`, 3918–3926). In the nonmultiple case the finite cosine sum is `sin(frequency*pi)/(2 sin(frequency*pi/(2d)))=0`; in the multiple case each summand is (-1)^a. The multiple case includes frequency zero and negative multiples.

The literal Gaussian marginals give `M=sum_i 1/lambda_i` and `mu_n=sum_i cos(n theta_i)/lambda_i` (`A3.Ex140`, 3934–3940). Absolute convergence of C.7 permits exchanging its series and the finite grid sum (`A3.SS3.p4`). For M, only modes j=2ad, a>=1 remain; summing their alternating geometric series gives `A3.EGx15`, 3948–3965.

For mu_n, the unweighted n mode sums to zero. The cosine product-to-sum identity yields the two sums at frequencies j-n and j+n (`A3.Ex144`, 3970–3976). Surviving positive j are the disjoint classes j=n, j=2ad+n, and j=2ad-n, a>=1. The restriction `1<=n<d` is used in this disjointness and in excluding negative/overlapping extra classes. Powers at 2ad±n have parity sign (-1)^n. Summing the resulting geometric series gives `A3.EGx16`, 3986–4003, hence the signed moment formula. These aliasing and parity steps are substantive proof ingredients, not assumptions about the moments.

**Proof of Lemma 4.5**, `A3.SS3.4` (4007–4133), first invokes C.8 for the means (`A3.SS3.p7`). Its variance paragraph `A3.SS3.p8` uses independence of U's coordinates, centered Gaussian fourth moments `E U_i^4=3/lambda_i^2`, and `Var(U_i^2)=2/lambda_i^2`. Thus

`Var(||U||^2)=2 sum_i lambda_i^{-2}` and `Var(U^T D_n U)=2 sum_i cos^2(n theta_i)lambda_i^{-2}`

(`A3.EGx17`, 4023–4035). The spectral lower bound lambda_i>=1 and `cos^2<=1` give both <=2M. C.8 gives `M<=d/sqrt(k)`. Fourth-moment finiteness and independence are consequences of the specified Gaussian, not extra public moment/variance premises.

The bias paragraph `A3.SS3.p9` (4038–4062) uses `n<d` and `0<r<1` to prove `(-1)^n mu_n>0`, then divides by the positive M to get

`|mu_n|/M = r^n [1-r^{2(d-n)}]/[1-r^{2d}]` (`A3.Ex150`).

The bracketed ratio lies between `1-r^{2(d-n)}` and 1 (`A3.Ex151`). In particular the upper bound by r^n already holds throughout `1<=n<d`.

Next `A3.SS3.p10` (4063–4109) proves

`log(1/r)=log((sqrt(k)+1)/(sqrt(k)-1)) = 2 integral_0^{1/sqrt(k)} dt/(1-t^2)`

and separates `2/sqrt(k)+2 integral t^2/(1-t^2)`. The remaining integral is nonnegative. Since `1-t^2>=1-1/k` and k>=2, the log lies between `2/sqrt(k)` and `8/(3 sqrt(k))<3/sqrt(k)`. Exponentiation yields

`exp(-3n/sqrt(k)) <= r^n <= exp(-2n/sqrt(k))` (`A3.Ex157`).

Finally, `A3.SS3.p11` (4110–4132) uses the additional guard `d-n>=sqrt(k)` to obtain `r^{2(d-n)}<=exp(-4)` (`A3.Ex158`). Combining the bracketed-ratio bounds with the power bounds gives the precise final two-sided inequality (`A3.Ex159`). The constants 2, 3, 4, and `1-exp(-4)` are absolute. No large-d limit, q bound, small-tau event, or algorithmic premise is needed for C.3's finite-dimensional statements.

## 5. Section 4.3 proof route and application guards

The proof is a test-event separation, not transcript indistinguishability. Assume a deterministic query cap integer q satisfying `q<=(delta/256)sqrt(k)log d` and uniform per-input TV error <=epsilon. Lemma 4.6 makes the random family an admissible subfamily. Let n=2q+1 and tau=tau_{d,q}.

`S4.EGx2` (1343–1355) literally defines

`S_A(x)=(-1)^n x^T T_n((2A-(k+1)I)/(k-1))x -2 tau ||x||^2`,

`E_A={x:S_A(x)>0}`,

where T_n is the first-kind Chebyshev polynomial. Since `T_n(cos(theta_i))=cos(n theta_i)`, the polynomial matrix is `O D_n O^T`. For x!=0, the energy weights along the eigenvectors sum to one and describe the cosine statistic in the prose at 1359–1371. x=0 fails the strict event by the literal polynomial definition; no division-by-zero convention is needed. The test may depend on A: the per-input TV guarantee allows choosing a measurable event for each input before averaging. It need not be computable from q oracle queries by the algorithm. Polynomial dependence on (A,x) supplies ordinary measurability; no special algorithmic event-evaluation oracle is assumed.

**Algorithmic side**, `S4.SS3.SSS0.Px1.p1`, 1376–1412: the q bound and k<=d^{1-delta} imply n=o(d) and

`tau <= constant [d^{-delta/2}(log d)^{3/2} + d^{-delta}(log d)^3] <= constant d^{-delta/2}(log d)^3 ->0`.

The implicit constants are absolute, while the sufficiently-large-d threshold depends on delta. Thus `n<d` and `tau<=1/2`; Lemmas 4.3 and 4.4 apply. Their extension preserves the joint input/output law. With probability >=.99, `|X^T O D_n O^T X|<=2 tau ||X||^2`, so `S_A(X)<=0`. Therefore the input-averaged algorithmic passing probability is <=.01 (`S4.Ex22`). This does not require a .99 statement separately for each fixed input.

**Target side**, `S4.SS3.SSS0.Px2.p1`–`.p3`, 1417–1479: let beta=|mu_n|/M. Since n=o(d) and sqrt(k)=o(d), the separate C.3 guard `d-n>=sqrt(k)` holds uniformly at sufficiently large d. Lemma 4.5 gives

`beta >= b d^{-delta/4}`, `b=(1-exp(-4))exp(-3)>0`.

The source uses `3n/sqrt(k)<=3+(3delta/128)log d`; weakening its exponent to delta/4 is valid. The weaker bound `r<=exp(-1/sqrt(k))`, together with d>=sqrt(k), gives `r^{2d}<=exp(-2)<1/3`, hence `M>=d/(2sqrt(k))>=d^{(1+delta)/2}/2`. Consequently `tau/beta ->0` and `M beta^2 >=(b^2/2)sqrt(d)->infinity` uniformly. Choose the same d_0(delta) to enforce all prior guards and additionally `tau<=beta/4`, `M beta^2>=320`.

For every fixed hard-family A, draw Y from its exact target and put Z=S_A(Y). Signed cosine mean is beta M, norm mean is M, and both variances are <=2M. The L2 triangle inequality for centered random variables, without any independence assertion between these two quadratic forms, gives `E Z>=(beta M)/2` and `Var Z<=8M` (`S4.Ex25`). Chebyshev's inequality yields `pi_A(E_A)>=1-32/(M beta^2)>=.9` (`S4.Ex26`). These are finite-dimensional mean/variance inequalities; target and algorithm distributions have not been identified.

**Contradiction**, `S4.SS3.SSS0.Px3.p1` (1484–1498): the per-input TV premise bounds `pi_A(E_A)-rho_A^Alg(E_A)` by epsilon. Averaging the target and algorithmic inequalities yields `.89<=epsilon<=.1`, impossible (`S4.Ex27`). This excludes the alleged q-cap algorithm. The printed theorem gives the weaker non-strict real lower bound on the integer-valued query complexity, so no rounding addition is required.

## 6. Complete Section 4.4 limitations and source boundaries

The limitation discussion is about this analysis. It is not a mathematical upper bound on the hardness of the fixed-spectrum family, nor a counterexample to stronger sampling lower bounds.

For large k, q on the proposed sqrt(k)log d scale causes `(q+1)^2>=d` around k of order d/(log d)^2. Lemma 4.7 then makes K_q all of R^d almost surely. Under `n=2q+1<d`, the finite grid satisfies `sum_i cos^2(n theta_i)=d/2`, so one coordinate has magnitude at least 1/sqrt(2). Its coordinate vector forces the uniform Rayleigh-quotient supremum to be >=1/sqrt(2) (`S4.Ex29`). The source describes its separating test as requiring a bound <=1/2 and says uniform control over K_q cannot work past saturation. Literal Lemma 4.4 permits the larger bound 2tau with tau<=1/2; the useful separating proof chooses tau<=beta/4 and beta<1, so its actual threshold is below 1/2. The limitation is the failure of useful small uniform control, not the false assertion that the small-tau hypothesis alone always implies 2tau<=1/2.

For accuracy, the single ratio test requires a threshold t at least a (the uniform algorithmic certificate) and strictly less than beta (the target bias), hence a<beta. Section 4.4 invokes the Bernstein calculation in Fact C.6 to require `a>=c/sqrt(d)` even to certify failure probability below one. Fact C.6's proof was not read in this task, so that floor is recorded as a deferred source input with unspecified absolute positive c, not independently established here. Combining it with the upper bias bound yields

`c/sqrt(d) <= a < beta <= exp(-2(2q+1)/sqrt(k))` (`S4.Ex30`).

Taking logarithms forces `q=O(sqrt(k)log d)` independently of epsilon. The source says changing this threshold or these constants does not produce an epsilon-growing bound. This concerns a proof certificate and a particular statistic; it is not a universal lower bound on all actual cosine suprema, every conceivable test, or all algorithms.

Remark 4.8 explicitly leaves open whether the same fixed-spectrum family supports stronger lower bounds. Both copies of that open-boundary sentence at lines 1592–1595 are retained in coverage rather than silently dropped as a proof theorem.

## 7. Gaps, deferred ingredients, and review limits

No unresolved algebraic or domain gap was found in the in-scope C.3 derivation when its actual standing assumptions are kept. This records source cognition, not a formal proof or an accepted semantic-equivalence result.

The following boundaries remain explicit:

1. Lemma 4.3's Haar/deferred-rotation representation proof is deferred to C.1, and the cited prior deferred-rotation argument is external. Its proof has not been accepted in this Phase 1.
2. Lemma 4.4's simultaneous concentration proof and the Section 4.4 Bernstein certificate floor are deferred to C.2 / Fact C.6. Their detailed inequalities have not been audited here.
3. Lemma 4.6's proof is deferred to C.4. Admissibility is easily motivated by the displayed spectral interval, but the deferred proof has not been read or substituted into this record.
4. Lemma 4.7's almost-sure dimension statement is given without proof in this reviewed slice. The required omitted bridge is a generic-rank argument for the matrix with columns Lambda^j g_a using distinct lambda_i. This is a visible source gap at that use site, not a new assumption on Gaussian samples or a verdict that the mathematical statement is false.
5. Theorem 4.1's sufficiently-large-d choice and uniform asymptotic domination are explained in source prose rather than a numerical d_0 formula. They are proof obligations with dependence only on delta; they cannot be moved into public hypotheses or allowed to depend on k or epsilon.
6. C.3 relies on standard geometric-series, finite trigonometric-sum, Gaussian moment/independence, and elementary integration facts. The proof states enough formulas to locate each use, but their fully foundational proofs are not printed. They are background dependencies, not grounds for replacing the literal objects by assumed identities.

There is no comparison to any candidate declaration, no inspection of a candidate body's definitions or axioms, no claim that source hypotheses are represented by a particular formal binder, and no approval of a source repair. A later phase must supply its own strict statement/reconstruction whitelist before any such comparison begins.
