# One-field scope-label successor

The original raw source paragraph `S3.SS3.SSS0.Px1.p1.2` explicitly makes the large-budget argument conditional on **2T + 1 > d**. Its following sentence proceeds under the complementary range 2T + 1 ≤ d. The existing root statement already names the conditional branch; this correction only carries that same scope into its standalone metadata label.

The derived `corrected-root-closure-map.json` replaces exactly `/roots/2/conditional_scope`:

- Old: `Unconditional within H:ranges, H:fixed-budget, and H:uniform-accuracy where applicable`
- New: `Conditional on 2T + 1 > d, within H:ranges, H:fixed-budget, and H:uniform-accuracy where applicable`

Every other JSON scalar value and every container shape/key order is preserved. Bytes outside this single value span are identical. The original generic-label map is retained both in its unchanged Phase 1 location and as the exact-byte snapshot `original-root-closure-map.json` here. This adds no mathematical assumption: the branch condition was already explicit in the source, root statement and relevant source graph edges.

The Phase 1 and Phase 2 graphs, raw coverage and exact types remain unchanged. No theorem is repaired, no branch is closed, and no source topology is rebuilt. This author-created derived artifact has not yet been accepted by the distinct topology challenger. No HOLD is introduced or implied.
