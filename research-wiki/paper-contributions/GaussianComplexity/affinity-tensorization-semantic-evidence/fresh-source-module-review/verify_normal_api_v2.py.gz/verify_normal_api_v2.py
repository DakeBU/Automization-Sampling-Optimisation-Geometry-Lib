import contextlib
import gzip
import hashlib
import io
import json
import subprocess
import sys
import time
import traceback
from pathlib import Path

ROOT=Path('/Users/zhouhuanjian/ASTIS-GC')
sys.path.insert(0,str(ROOT))
from tools import astis_advance as advance
BASE=ROOT/'research-wiki/paper-contributions/GaussianComplexity/affinity-tensorization-semantic-evidence/fresh-source-module-review'
TARGET='ASTIS-SA-20261107-GaussianComplexityAffinityTensorization'
DECL='AutoSamplingTheory.ExampleCases.GaussianComplexity.AffinityTensorization.actual_affinity_tensorization'
VERIFIER='/root/ex71_fresh_source_module_review'
CANDIDATE='4014feb9c6dff0b4e0dcb9fb49ae1b961cf3cf0b'
sha=lambda b:hashlib.sha256(b).hexdigest()
canon=lambda v:json.dumps(v,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()

def put(name,v):(BASE/name).write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
def ref(name):
    p=BASE/name
    return {'path':str(p.relative_to(ROOT)),'sha256':sha(p.read_bytes())}

def main():
    ledger_path=ROOT/'runs/substantive_advances.jsonl'
    before=ledger_path.read_bytes()
    assert before==gzip.decompress((BASE/'ledger-prefix-before-projection.jsonl.gz').read_bytes())
    state=advance._replay_advances(json.loads(x) for x in before.splitlines())
    foreign_before={k:v for k,v in state.items() if k!=TARGET}
    assert len(foreign_before)==277
    assert state[TARGET]['state']=='PROVED_LOCAL'
    assert state[TARGET]['owner_id']=='huanjian_gc_20261107_ex71'
    assert not [x for x in state.values() if x['state']=='STABILIZING']
    pre=json.loads((BASE/'projection-preflight-v1.json').read_text())
    for s,h in pre['frontier_bytes'].items():assert sha((ROOT/s).read_bytes())==h,s
    disc_path=ROOT/'runs/substantive_discoveries.jsonl';discovery_before=disc_path.read_bytes()
    audit_path=ROOT/'research-wiki/semantic-roundtrip/audits/huanjian-affinity-tensorization.json'
    audit=audit_path.read_bytes()
    assert sha(audit)=='54d514e0ef022d17201311a28f1eb59366ee9ac0a217b215ef33c05b4224cd87'
    valid=json.loads((BASE/'postprojection-validation-v2.json').read_text())
    assert valid['semantic_exit_code']==valid['reviewed_publication_exit_code']==0
    assert json.loads((BASE/'source-review-result-v2.json').read_text())['review_run_sha256']=='0b79a4d39ab94e801c977aa8fb29fb695bd121ca9023f64724b69ca17d74b8bc'
    evidence={
        'verifier_id':VERIFIER,'verified_commit':CANDIDATE,
        'publication_declarations':[DECL],'lean_declarations':[DECL],
        'proof_owner_retained':'huanjian_gc_20261107_ex71',
        'gate':{
            'status':'passed-independent-actual-source-and-reviewed-admission',
            'direct_production':ref('candidate-source.receipt.json'),
            'direct_test_actual_ambient_RN_decay_consumer':ref('test-source.receipt.json'),
            'direct_ProductDensity_parent':ref('product-parent-source.receipt.json'),
            'direct_MixtureDensities_parent':ref('mixture-parent-source.receipt.json'),
            'anonymous_expanded_equivalence_and_axioms':ref('anonymous-equivalence-and-axioms.receipt.json'),
            'postprojection_semantic':ref('postprojection-semantic-v2.receipt.json'),
            'postprojection_reviewed_publication':ref('postprojection-reviewed-publication-v2.receipt.json'),
            'frozen_actual_evidence_revalidation':ref('frozen-evidence-revalidation-v2.json'),
            'scope':'Fresh direct source elaborations (target 4.186s, actual Test 3.488s, Ex70 parent 5.437s, block-density parent 8.920s) and expanded statement equivalence, followed by real source-reviewed admission. Imported dependency oleans reused; receipts do not contain head_before/head_after, so no compilation HEAD is inferred. Exact source/Test/parent hashes match the mathematical candidate Gitobjects. Not root/site/browser/remote acceptance.'},
        'source_audit':{
            'status':'accepted','verdict':'equivalent-after-elaboration',
            'audit':str(audit_path.relative_to(ROOT)),'audit_sha256':sha(audit),
            'reviewer_packet_sha256':'ca61048cb47a11d9f6cb941d8b4f3c56f56ef4d2c4ca52bdc11979d6687ed34a',
            'publication_binding_sha256':'9104d934f897b788965a51b8681eb96cf568a43d3a7b7dc5ed743ffe0469533d',
            'review_result':ref('source-review-result-v2.json'),
            'review_run':ref('review-run-v2.json'),
            'review_run_sha256':'0b79a4d39ab94e801c977aa8fb29fb695bd121ca9023f64724b69ca17d74b8bc',
            'independent_raw_prefreeze_sha256':'0180f0190eaadce263df6799e9354e5bd5cbb1a60691aa38ff173e294ae7e43c',
            'independent_reconstruction_prefreeze_sha256':'ad347b270fa85d6a727361f81675b78567d8e6f13a82af1758d06f88b574f4e7',
            'canonical_projection':ref('canonical-audit-projection-v2.json'),
            'preserved_v1_result':ref('source-review-result-v1.json'),
            'preserved_v1_real_validation_failure':ref('projection-semantic-preflight-v1.receipt.json'),
            'independent_source_based_classification_correction':ref('conclusion-classification-correction-v2.md'),
            'phase_scope':'Source acceptance is the current mechanical projection of frozen independent v2 review; candidate commit 4014 audit was draft then, not retrospectively source-reviewed.'},
        'semantic_roundtrip_audit':{
            'id':'ASTIS-RT-20261107-HuanjianAffinityTensorization','state':'source-reviewed',
            'verdict':'equivalent-after-elaboration','review_run_sha256':'0b79a4d39ab94e801c977aa8fb29fb695bd121ca9023f64724b69ca17d74b8bc',
            'accepted_independent_reviewer':VERIFIER,'real_semantic_validation':ref('postprojection-semantic-v2.receipt.json')},
        'fake_closure_scan':{
            'status':'passed','record':ref('fake-closure-scan-v1.json'),'whole_modules':16,'hits':[],
            'only_axioms':['propext','Classical.choice','Quot.sound'],
            'recursive_axiom_log':ref('anonymous-equivalence-and-axioms.log'),
            'actual_Test_axiom_and_compiled_parent_log':ref('test-source.log')},
        'preservation_preflight':ref('canonical-projection-preflight-v2.json'),
        'remaining_truth_boundary':'Actual Ex71 tensorization/AC/genuine ambient L1, actual-law RN-integral exponential-decay Test and candidate static reader only. No canonical frontier edit. Ex72 actual TV, oracle/transcript/TV-precision/deterministic worst-case cap/expected-cost/hidden-eigenbasis/main lower bounds, root import/Registry/site/root gate, browser/Chrome/public/remote delivery, merge/purification/Exposition Seal and whole Goal remain separate.'}
    put('verified-normal-api-request-v2.json',{'advance_id':TARGET,'to_state':'VERIFIED','worker_id':VERIFIER,'modes':['independent-verification'],'evidence':evidence})
    output=io.StringIO();start=time.time();code=0
    with contextlib.redirect_stdout(output),contextlib.redirect_stderr(output):
        try:
            advance.transition_advance(TARGET,'VERIFIED',worker_id=VERIFIER,
                modes=['independent-verification'],evidence=evidence)
            print('PASS normal tools.astis_advance.transition_advance PROVED_LOCAL -> VERIFIED')
        except Exception:
            traceback.print_exc();code=1
    log=output.getvalue().encode();(BASE/'verified-normal-api-v2.log').write_bytes(log)
    after=ledger_path.read_bytes();suffix=after[len(before):] if after.startswith(before) else b''
    receipt={'command':'tools.astis_advance.transition_advance','request':ref('verified-normal-api-request-v2.json'),
        'api_invocations':1,'exit_code':code,'elapsed_seconds':time.time()-start,'log_sha256':sha(log),
        'mathematical_candidate_commit':CANDIDATE,'metadata_head_at_api':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
        'no_compilation_head_inferred':True,'ledger_before_bytes':len(before),'ledger_before_sha256':sha(before),
        'ledger_after_bytes':len(after),'ledger_after_sha256':sha(after),'prefix_exact':after.startswith(before),
        'appended_bytes':len(suffix),'append_sha256':sha(suffix),'no_direct_ledger_edit':True}
    put('verified-normal-api-v2.receipt.json',receipt)
    if code:
        print(json.dumps(receipt,indent=2));print(output.getvalue());return code
    assert after.startswith(before)
    assert len(suffix.splitlines())==1
    event=json.loads(suffix)
    assert event['advance_id']==TARGET and event['from_state']=='PROVED_LOCAL' and event['to_state']=='VERIFIED'
    assert event['worker_id']==VERIFIER and event['evidence']['verifier_id']==VERIFIER
    assert event['evidence']['verified_commit']==CANDIDATE
    (BASE/'verified-append-v2.jsonl').write_bytes(suffix)
    (BASE/'verified-append-v2.jsonl.gz').write_bytes(gzip.compress(suffix,mtime=0))
    current=advance._replay_advances(json.loads(x) for x in after.splitlines())
    foreign_after={k:v for k,v in current.items() if k!=TARGET}
    assert foreign_before==foreign_after
    assert current[TARGET]['owner_id']=='huanjian_gc_20261107_ex71'
    assert current[TARGET]['state']=='VERIFIED'
    assert not [x for x in current.values() if x['state']=='STABILIZING']
    unchanged_frontiers=all(sha((ROOT/s).read_bytes())==h for s,h in pre['frontier_bytes'].items())
    assert unchanged_frontiers and disc_path.read_bytes()==discovery_before and audit_path.read_bytes()==audit
    protection={
        'ledger_prefix_before_bytes':len(before),'ledger_prefix_before_sha256':sha(before),'prefix_exact':True,
        'ledger_prefix_archive':ref('ledger-prefix-before-projection.jsonl.gz'),
        'append':ref('verified-append-v2.jsonl'),'append_gzip':ref('verified-append-v2.jsonl.gz'),
        'appended_events':1,'only_event':'PROVED_LOCAL -> VERIFIED for the owned target via normal API',
        'foreign_states_count':len(foreign_after),'foreign_states_unchanged':True,'foreign_states_sha256':sha(canon(foreign_after)),
        'old_frontier_count':436,'all_437_frontier_bytes_unchanged':True,'canonical_target_frontier_unchanged':True,
        'frontier_lossless_archive':ref('frontier-bytes-before-projection.tar.gz'),
        'discoveries_ledger_unchanged':True,'discoveries_ledger_sha256':sha(discovery_before),
        'proof_owner_retained':current[TARGET]['owner_id'],'target_state':'VERIFIED','single_stabilization_lane':[],
        'canonical_audit_unchanged_during_api':True,'canonical_audit_sha256':sha(audit),
        'normal_api_receipt':ref('verified-normal-api-v2.receipt.json'),
        'no_root_import_Registry_browser_remote_purification_claim':True}
    put('verified-prefix-foreign-frontier-protection-v2.json',protection)
    print(json.dumps({'api':receipt,'protection':protection},indent=2));return 0

if __name__=='__main__':raise SystemExit(main())
