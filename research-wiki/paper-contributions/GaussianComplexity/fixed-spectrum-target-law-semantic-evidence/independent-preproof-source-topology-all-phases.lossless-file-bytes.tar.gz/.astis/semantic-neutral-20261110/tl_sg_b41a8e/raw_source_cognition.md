# Target law / norm mean — raw-source checkpoint

Phase: RAW_SOURCE_ONLY before this packet's exact-type exposure. This is the
same extractor with prior history, not a fresh or fully blind actor. No new
seal, type, implementation, API or proof plan has been read for this packet.
No proof, statement verdict, independent coverage approval or VERIFIED/STAB
credit is claimed.

## Actual source scope and prior cognition

The sole current mathematical source is arXiv:2610.20492v1 HTML, 951991 bytes,
SHA256 6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915.
Complete raw elements reread and repinned are S4.SS1.p1 (including Eq.11 and
the hard target construction), S4.SS2.SSS0.Px3 (all of Lemma 4.5 and its
explanation), A3.SS3 (all C.3), A3.SS4.p3 (including p3.1 and the complete
normalizer display), plus A3.SS4.p1 as directly necessary positivity context.
Their original-byte copies are controlling; readable text is derivative.

Reusable source knowledge is my own frozen source_graph_v2.json,
SHA256 a3d876092b9854614c6d09bba8f1fa4add8d772ba030fa2358526b9c55ac6449,
and its unchanged node/paragraph correspondence. It is reused as source topology,
not a compiling library. No old v1/HOLD/v2 artifact is changed. This checkpoint
adds a narrow source-output selection and explicit background granularity; it
does not rebuild or replace the full author graph.

Prior session exposure is real and remains relevant: repository process
instructions; the previously selected §4.1–4.3/C.1–C.4 source; my old Detector
exact producer/private-consumer types and seal-projection audit metadata;
literal Mathlib definitions for multivariateGaussian, Chebyshev.T, aeval,
matrix inverse, full orthogonal group and Measure.map; accidental adjacent
Mathlib API/short proof text already recorded in the old phase2 exposure log;
and the previously authorized TC-B1 mathematical feedback that led to my v2
edge correction. I do not reread the old/new verdicts or those library/type
materials now and do not treat them as source evidence for this packet.
The task also reports a new Prop-only seal/probe lifecycle; that narrative is
process exposure only, not an inspected type, law or mathematical dependency.
The actor has no claim of pretrained/source ignorance.

## Raw source objects and domains

The source uses integer d>=2 and real kappa>=2. Source index i=1,...,d has
theta_i=(i-1/2)pi/d and
lambda_i=(kappa+1)/2+(kappa-1)cos(theta_i)/2. Lambda is the diagonal PRECISION
matrix, A=O Lambda O^T, and the centered target is pi_A=N(0,A^-1). The
covariances are Lambda^-1 or A^-1, not Lambda or A. C.4 supplies
0<theta_i<pi, 1<lambda_i<kappa and I<=A<=kappa I. Inverses of those matrices
and real reciprocals 1/lambda_i must remain distinct notions.

The hard-input experiment draws O from Haar on the full real O(d), independent
of algorithm randomness. The current branch fixes/conditions on O; its law and
norm identities hold pointwise at that full orthogonal matrix. No determinant
one restriction is present. The fixed-O assertions do not require a Haar,
algorithmic, adaptive-history or seed-independence premise. Those remain in the
larger source experiment but are not magically proved by a fixed-O helper.

For an exact target sample Y conditional on O, the source explicitly says
U=O^T Y has law N(0,Lambda^-1), ||Y||^2=||U||^2 and
Y^T O D_n O^T Y=U^T D_n U. The preceding Lemma 4.5 defines
M=E||U||^2 and mu_n=E[U^T D_n U]. Its displayed formula is
M=(d/sqrt(kappa))(1-varrho^(2d))/(1+varrho^(2d)),
varrho=(sqrt(kappa)-1)/(sqrt(kappa)+1).

The source then says the lemma gives target means and variances. This is the
actual consumer use: the latent Gaussian moments are transferred to the true
target sample after law recognition and pointwise orthogonal norm/form
identities. A pushforward-measure expression is a mathematical reformulation
of this relationship, not a printed source constructor or a library theorem.
In the forward direction the map is z -> O z; in the source's written backward
direction it is y -> O^T y. The same O and the same Lambda are required.

All vectors, including zero, are in the norm identity. This branch introduces
no normalized energy weights or division by ||x||^2, no test event, no sign test
and no positivity event at zero. Division here involves d, sqrt(kappa),
lambda_i, sqrt(kappa)+1, 1-varrho and 1+varrho^(2d), with their source-domain
positivity requirements. Since 0<varrho<1, M is positive and finite in the
source formula. Gaussian second moments have their ordinary finite mathematical
meaning; no nonintegrable real-integral fallback is part of the paper.

## Actual mean branch and output consumption

C.3.p4 uses E U_i^2=1/lambda_i and writes M=sum_i 1/lambda_i. The covariance
meaning and one-dimensional Gaussian second moment are background inputs, not
new theorem hypotheses. Finite-dimensional squared norm expands as a finite
sum. The expected norm and coordinate expectations require finite second
moments/integrability when written as real integrals.

C.3 Fact C.7 expands the inverse spectrum in an absolutely and uniformly
convergent cosine series. C.3.p3 gives the finite-grid alias sum. C.3.p5 uses
those outputs and geometric summation to evaluate M, with only j=2ad aliases
surviving. That is the norm-only source route to the exact finite-grid
correction; it does not need the separate cosine-moment summation at C.3.p6,
the variance proof at p8, or the normalized-bias argument at p9–p11.

Lemma 4.5 packages these sibling results under an integer 1<=n<d, and its bias
clause adds d-n>=sqrt(kappa). The norm mean M and the p4–p5 derivation are
independent of n. A later n-free norm-mean helper must be bound to that precise
source sub-output/derivation, rather than treating the whole joint lemma and
all its sibling hypotheses as inseparable. No new helper type is assumed here.

The target norm-mean consumer therefore needs (i) actual target/latent Gaussian
law relationship, (ii) the all-carrier orthogonal norm identity, and (iii) the
latent norm mean output, together with expectation-law transport. To consume
the closed M formula it also uses the inverse-spectrum and finite-grid constant
mode branch. The full source Gaussian law relation is essential; an arbitrary
measure called mu and its literal map-event equality alone would not supply it.
This last distinction is retained from prior exposure, but is supported here
by the actual source's specified laws, not by old Detector types.

C.4.p3 states again that the actual target is N(0,A^-1) and gives the Gaussian
normalizer (2pi)^(d/2)det(A)^(-1/2)=(2pi)^(d/2)det(Lambda)^(-1/2). This supports
the actual target and public-normalization context. Knowing the normalizer
alone does not prove the Gaussian linear-image law or its second moment.

## Necessary standard inputs and precise gaps

The selected paper invokes but does not generally prove the Gaussian affine/
linear transformation rule. At S4.SS2.SSS0.Px3.p2.1 it is consumed with L=O^T,
mean zero and covariance A^-1, together with
O^T A^-1 O=Lambda^-1. The forward formulation
(z -> O z)_# N(0,Lambda^-1)=N(0,A^-1) additionally uses inverse-map/reexpression
and A^-1=O Lambda^-1 O^T. These covariance/inverse identities and general
Gaussian-law transport are required STANDARD_BACKGROUND / SOURCE_GAP(general
proof omitted), not already proved source leaves and not a source refutation.
No exact external source for the general rule is supplied at that use site;
none has been searched or invented in this phase.

Likewise ordinary pushforward/expectation transport requires measurable linear
maps and integrability of norm squared. Orthogonal norm preservation is a
finite-dimensional algebra bridge; the source prints the norm equality but
does not prove its general theorem. Gaussian coordinate second/fourth moments,
diagonal-coordinate independence and Gaussian integration are invoked standard
facts. Only the second-moment part feeds the selected norm-mean root; fourth
moments/variance and normalizer integrals must not become false AND premises.

The source's convergence/alias/geometric computations for exact M ARE supplied
in C.3, with denominators and absolute convergence explicit. They remain
source-derived equations rather than compiler/library evidence. Any future
library constructor-to-Gaussian law recognition, matrix inverse definition,
real-integral well-definedness or coordinate-wrapper meaning must be examined
after an exact type is authorized. Old Mathlib/Detector exposure is not a
certificate for a new type. No such new type or API has been inspected now.

## Scope and route semantics

The full newly selected source region is inventoried in coverage_checkpoint.json
using the exact old node IDs and original byte spans/hashes. The law/norm-mean
selected-root map adds only source-output selectors and necessary background
obligations. All C.3 sibling cosine/variance/bias paragraphs remain NODE records
with a declared outside-selected-root role; they are not silently lost. Roadmap
and heading exclusions retain explicit reasons.

Law recognition AND orthogonal norm transport AND latent mean/expectation
transport compose one author route. The forward/backward coordinate versions
are equivalent descriptions, not competing OR proofs. No compiler import,
library constructor, implementation dependency or proof-bookkeeping node is
presented as an author mathematical proof edge. No target acceptance, detector
event, concentration C, algorithm/Krylov/Haar proof, TV, cost or full lower-bound
claim is made. Independent review remains pending. Freeze this raw checkpoint
and pause before new exact types.
