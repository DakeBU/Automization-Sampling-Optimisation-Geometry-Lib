from pathlib import Path
import sys, hashlib, json, re, html

HERE = Path(__file__).resolve().parent
SOURCE = HERE / 'pinned_source.html'
assert hashlib.sha256(SOURCE.read_bytes()).hexdigest() == '6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
start, end, label = int(sys.argv[1]), int(sys.argv[2]), sys.argv[3]
lines = SOURCE.read_text().splitlines(keepends=True)
raw = ''.join(lines[start-1:end])
def readable(line):
    def math(m):
        a = re.search(r'\balttext="([^"]*)"', m.group(0))
        return ' $' + html.unescape(a.group(1)) + '$ ' if a else m.group(0)
    line = re.sub(r'<math\b.*?</math>', math, line)
    line = re.sub(r'<[^>]+>', ' ', line)
    return re.sub(r'\s+', ' ', html.unescape(line)).strip()
projection = '\n'.join(f'{i}: {t}' for i in range(start, end+1) if (t := readable(lines[i-1]))) + '\n'
raw_path = HERE / f'{label}.raw.html'
read_path = HERE / f'{label}.read.txt'
assert not raw_path.exists() and not read_path.exists(), 'Read artifact already exists'
raw_path.write_text(raw)
read_path.write_text(projection)
record = {'operation':'read-pinned-source-lines','argv':sys.argv,'source':'pinned_source.html','line_start':start,'line_end':end,'raw_artifact':raw_path.name,'raw_sha256':hashlib.sha256(raw.encode()).hexdigest(),'projection_artifact':read_path.name,'projection_sha256':hashlib.sha256(projection.encode()).hexdigest(),'ids':re.findall(r'\bid="([^"]+)"',raw)}
with (HERE/'raw_read_log.jsonl').open('a') as f: f.write(json.dumps(record)+'\n')
print(projection)
