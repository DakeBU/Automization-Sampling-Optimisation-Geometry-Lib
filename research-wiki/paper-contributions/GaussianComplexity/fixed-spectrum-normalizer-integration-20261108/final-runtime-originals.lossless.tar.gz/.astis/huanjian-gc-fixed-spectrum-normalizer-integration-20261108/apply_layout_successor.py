from pathlib import Path
import datetime, gzip, hashlib, json, subprocess, sys

sys.path.insert(0, 'tools')
import astis_advance, astis_site

sha = lambda raw: hashlib.sha256(raw).hexdigest()
dump = lambda obj: (json.dumps(obj, ensure_ascii=False, indent=2) + '\n').encode()
B = Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-normalizer-integration-20261108')
P = B / 'independent-reader/mobile-debt-layout-proposal-v6'
CORE = 'c8c157a69aaad4007cb801a781e980a27005bb02'
ADV = 'ASTIS-SA-20261108-GaussianComplexityFixedSpectrumNormalizer'
REPORT = '9e5ace010535e879abafb81ac71e0281c756d84311845d0ad15d2bd0a318eeec'
FREEZE = 'eda10bb9841cf9b44a88dc6593fb8505da8613ee5a678d28bef481efe13ab81e'
cmd = lambda *args: subprocess.check_output(args)
assert cmd('git', 'rev-parse', 'HEAD').decode().strip() == CORE
assert not cmd('git', 'diff', '--cached', '--name-only').strip()
assert sha((P / 'proposal-report.json').read_bytes()) == REPORT
assert sha((P / 'freeze.json').read_bytes()) == FREEZE
report = json.loads((P / 'proposal-report.json').read_bytes())
assert report['reviewer'] == '/root/norm_integration_reader'
assert report['state'] == 'EXACT_ONE_LINE_LAYOUT_CANDIDATE_REVIEWED_NOT_APPLIED'
assert report['permitted_foreign_protection_exception']['paths'] == [report['path']]

def unpack(row):
    raw = Path(row['path']).read_bytes()
    assert sha(raw) == row['gzip_sha256']
    data = gzip.decompress(raw)
    assert sha(data) == row['raw_sha256'] and len(data) == row['raw_bytes']
    return data

before = unpack(report['before_archive'])
after = unpack(report['after_archive'])
diff = unpack(report['exact_diff'])
old_line = b'.theorem-grid > *,\n'
assert before.count(old_line) == 1
assert after == before.replace(old_line, old_line + b'.theorem-layout > article,\n', 1)
assert len(after) - len(before) == 27
print(diff.decode())
path = Path(report['path'])
assert path.read_bytes() == before == cmd('git', 'show', CORE + ':' + str(path))
assert cmd('git', 'rev-parse', CORE + ':' + str(path)).decode().strip() == report['before_blob']
states = astis_advance.current_advances()
assert [k for k, v in states.items() if v['state'] == 'STABILIZING'] == [ADV]
assert states[ADV]['owner_id'] == 'huanjian_gc_20261108_fixed_spectrum_normalizer'
assert states[ADV]['latest_evidence']['integration_owner'] == 'huanjian_gc_20261108_fixed_spectrum_normalizer_integration'
ledger_paths = ['runs/substantive_advances.jsonl', 'runs/substantive_discoveries.jsonl']
ledger_before = {p: Path(p).read_bytes() for p in ledger_paths}
frontiers_before = {str(p): sha(p.read_bytes()) for p in Path('research-wiki/frontier-cells').glob('*.json')}
readme_path = Path('research-wiki/paper-contributions/GaussianComplexity/README.md')
readme_before = readme_path.read_bytes()
models_before = {p: sha(Path(p).read_bytes()) for p in ['website/content/graph_memory_index.json', 'website/content/functor_hypergraph.json']}
math_paths = ['AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumNormalizer.lean', 'Tests/GaussianComplexityFixedSpectrumNormalizer.lean', 'website/content/declaration_lessons/huanjian-fixed-spectrum-normalizer.json', 'website/content/publications/huanjian-fixed-spectrum-normalizer.json']
math_before = {p: Path(p).read_bytes() for p in math_paths}
digest_before = astis_site.source_digest()
assert digest_before == '92a908be0defdf1b5994f5ff4fe8a0e545cdca0f6c229cd1141c36338129bd21'
auth_path = B / 'root-exact-layout-successor-authorization.json'
result_path = B / 'exact-layout-successor-application.json'
assert not auth_path.exists() and not result_path.exists()
auth_path.write_bytes(dump({'authorized_by': '/root', 'recorded_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'authorization_kind': 'exact-reviewed-one-line-layout-application-only', 'base_core': CORE, 'independent_report': {'path': str(P / 'proposal-report.json'), 'sha256': REPORT}, 'independent_freeze': {'path': str(P / 'freeze.json'), 'sha256': FREEZE}, 'permitted_single_path': str(path), 'exact_before_sha256': sha(before), 'exact_after_sha256': sha(after), 'exact_diff_sha256': sha(diff), 'sourceV_or_lifecycle_API_authorized': False, 'acceptance_or_parking_authorized': False, 'scope': 'Root reviewed the exact one-line diff and scope. Apply only this min-width grid-item correction. All previous source/Lean results remain unchanged. Freeze a successor immutable HEAD and obtain genuine new exact-HEAD gates/site/Chrome/original visual review; c8 success is not transferred.'}))
path.write_bytes(after)
assert path.read_bytes() == after
for p, raw in ledger_before.items(): assert Path(p).read_bytes() == raw
assert frontiers_before == {str(p): sha(p.read_bytes()) for p in Path('research-wiki/frontier-cells').glob('*.json')}
assert readme_path.read_bytes() == readme_before
assert all(sha(Path(p).read_bytes()) == h for p, h in models_before.items())
assert all(Path(p).read_bytes() == raw for p, raw in math_before.items())
assert astis_site.source_digest() == digest_before
changed = cmd('git', 'diff', '--name-only').decode().splitlines()
assert changed == [str(path)], changed
result_path.write_bytes(dump({'state': 'EXACT_ONE_LINE_LAYOUT_APPLIED_NEW_CORE_GATES_PENDING', 'recorded_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'base_core': CORE, 'authorization': {'path': str(auth_path), 'sha256': sha(auth_path.read_bytes())}, 'path': str(path), 'before_sha256': sha(before), 'after_sha256': sha(after), 'raw_diff_sha256': sha(diff), 'all_ledger_and_443_frontier_bytes_preserved': True, 'foreign_states_preserved': len(states) - 1, 'README_models_and_source_Test_lesson_publication_preserved': True, 'source_digest_before': digest_before, 'source_digest_after': astis_site.source_digest(), 'new_source_verdict': False, 'lifecycle_API_called': False, 'pixels_or_new_core_gate_claimed': False, 'foreign_protection_truth': 'All original protected bytes remain except the separately independently reviewed exact one-line CSS change.'}))
print(json.dumps({'application': str(result_path), 'sha256': sha(result_path.read_bytes()), 'next': 'Freeze successor core, then fresh real exact-HEAD gates and browser.'}))
