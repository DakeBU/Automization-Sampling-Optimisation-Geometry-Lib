from pathlib import Path
import gzip
import hashlib
import json
import sys
sys.dont_write_bytecode = True
sys.path.insert(0, 'tools')
import astis_publication as pub
import astis_semantic_roundtrip as rt

W = Path(__file__).parent
E = Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-target-law-semantic-evidence')
sha = lambda b: hashlib.sha256(b.encode() if isinstance(b,str) else b).hexdigest()
def put(path, value):
    path = Path(path)
    assert not path.exists(), path
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')

x = json.loads((W/'author-payload.json').read_bytes())
s = json.loads((W/'statement-seal-v1.json').read_bytes())
k = json.loads((E/'actual-kernel-owned-inventory.json').read_bytes())
P = Path(s['producer']['planned_file'])
T = Path(s['actual_private_consumer']['planned_file'])
name = s['producer']['name']
assert sha(P.read_bytes())==k['actual_producer_sha256'] and sha(T.read_bytes())==k['actual_Test_sha256']
assert k['all2_reachable'] and k['both_exact_sealed_types_kernel_applied']
pr, tr = P.read_text(), T.read_text()
for text, key, begin in [(pr,'producer','theorem actual_rotated_gaussian_target'),
                         (tr,'actual_private_consumer','private theorem actual_target_gaussian_norm_mean')]:
    start = text.index(begin)
    finish = text.index('\n:= by',start)+1
    assert text[start:finish]==s[key]['signature']
admiss = 'AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumAdmissibility.actual_precision_admissible'
moments = 'AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumGaussianMoments.actual_diagonal_gaussian_quadratic_means'
deps = ['Matrix.mem_orthogonalGroup_iff','Matrix.mem_orthogonalGroup_iff\'',
        'Matrix.inv_eq_left_inv','Matrix.nonsing_inv_mul','Matrix.toEuclideanCLM',
        'ContinuousLinearMap.integral_id_map','ProbabilityTheory.integral_id_multivariateGaussian',
        'ProbabilityTheory.covarianceBilin_map','ProbabilityTheory.covarianceBilin_multivariateGaussian',
        'ProbabilityTheory.IsGaussian.ext','Unitary.map_mem',
        'ContinuousLinearMap.norm_map_of_mem_unitary','MeasureTheory.integrable_map_measure',
        'MeasureTheory.integral_map']
C = Path('research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-target-law.json')
cellraw = C.read_bytes()
cell = json.loads(cellraw)
assert cell['shared_floor_audit']['canonical_declaration']==name
assert not (E/'frontier-before-publication-reuse-details.raw.json.gz').exists()
(E/'frontier-before-publication-reuse-details.raw.json.gz').write_bytes(gzip.compress(cellraw,mtime=0))
cell['reuse_plan']['reused_declarations'] = [admiss,moments,*deps]
cell['reuse_plan']['known_consumers'] = ['Compiled private actual_target_gaussian_norm_mean; actual producer call feeds both target L1 and target finite inverse-spectrum mean.']
cell['reuse_plan']['decision_reason'] = 'Literal hard-family full-measure adapter. Canonical admissibility supplies positive precision twice; generic Gaussian covariance/uniqueness and inverse algebra are reused. Private application materially consumes this new law and the canonical diagonal moment producer; no proof certificate input or duplicated generic Gaussian theorem.'
cell['evidence']['actual_compiled_first_public_ASTIS_parents'] = k['actual_first_public_ASTIS_parents']
C.write_text(json.dumps(cell,ensure_ascii=False,indent=2)+'\n')

ranges = [(P,pr.index('  have hApos'),pr.index('  have hOleft')),
          (P,pr.index('  have hOleft'),pr.index('  have hstar')),
          (P,pr.index('  have hstar'),pr.index('  change μ.map T')),
          (P,pr.index('  change μ.map T'),pr.index('\nend AutoSamplingTheory')),
          (T,tr.index('  have hLaw'),tr.index('  change Integrable g ν')),
          (T,0,len(tr))]
records = []
assert len(x['steps'])==len(ranges)==6
for step,(path,a,b) in zip(x['steps'],ranges):
    text = path.read_text()
    code = text[a:b].rstrip()+'\n'
    assert code in text
    step['lean']=code
    records.append({'file':str(path),'line':text[:a].count('\n')+1,
                    'code_sha256':sha(code),'exact_contiguous_source':True})
assert x['steps'][-1]['lean']==tr
source = {
    'url':'https://arxiv.org/html/2610.20492v1#S4.SS2.SSS0.Px3',
    'edition':'arXiv2610.20492v1; pinned raw HTML SHA2566bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915',
    'anchor':'Eq11; Section4.2 Lemma4.5 coordinate-law explanation S4.SS2.SSS0.Px3.p2.1; AppendixC.3 norm component; A3.SS4.p3.1 target definition',
    'wording_status':'faithful paraphrase',
    'attribution':'On Complexity of Gaussian Sampling, arXiv2610.20492v1.',
    'scope':'Extracted pointwise full Gaussian-law auxiliary and genuine PRIVATE target norm-L1/finite inverse-spectrum mean component; not full Lemma4.5 or Theorem4.1.'}
unit = {
    'kind':'theorem','reading_layout':'progressive','declaration':name,'title':x['title'],
    'reader_note':'Conditions, formula steps and exact Lean open beside the concise claim. The complete private target-moment application is folded at step6.',
    'statement':x['statement'],'formula':x['formula'],'assumptions':x['assumptions'],
    'notation':[
        {'symbol':r'\(\mu_\Lambda,\pi_A,R_O\)',
         'text':'Actual centered Gaussians on real Euclidean space and the fixed orthogonal coordinate map.',
         'formula':r'\mu_\Lambda=N(0,\Lambda^{-1}),\quad\pi_A=N(0,A^{-1}),\quad R_Oz=Oz.'},
        {'symbol':r'\(g,M\)','text':'The squared Euclidean norm and its finite inverse-spectrum mean.',
         'formula':r'g(x)=\|x\|^2,\qquad M=\sum_{i=1}^d\lambda_i^{-1}.'}],
    'steps':x['steps'],'astis_dependencies':[admiss,moments],'mathlib_dependencies':deps,
    'dependency_notes':'Canonical admissibility is the public law producer parent. Canonical diagonal moments are an additional private application parent; the new law is actually used by that application. These roles do not create a second public Anchor or a duplicate generic Gaussian node.',
    'lean_statement':'The literal precision family, full real orthogonal matrix and actual Gaussian constructors are expanded in the exact statement. Matrix inverses are covariance parameters; no positive-definiteness, law, moment or measurability certificate is an input.',
    'lean_proof':'The actual inverse-conjugation identity and canonical Gaussian mean/covariance uniqueness prove the full law. The complete private application derives measurable norm-preserving transport and consumes both the new law and existing latent moments.',
    'boundary':x['boundary'],
    'sources':[{**source,'label':'Lemma4.5 coordinate-law and norm-moment source component'},
               {'path':str(T),'line':tr[:tr.index('private theorem')].count('\n')+1,
                'label':'Complete actual private target norm-L1 and finite-mean application',
                'scope':'Private non-Anchor proof context; no full moment/variance/probability or complexity claim.'}],
    'tests':['lake build Tests.GaussianComplexityFixedSpectrumTargetLaw']}
put('website/content/declaration_lessons/huanjian-fixed-spectrum-target-law.json',{'schema_version':1,'units':[unit]})
aid = 'ASTIS-RT-20261110-HuanjianFixedSpectrumTargetLaw'
deltas = [
    {'source':'The coordinate explanation states that a target sample transformed by O transpose has the diagonal Gaussian law.',
     'lean':'The extracted auxiliary states the forward pushforward full-measure identity for every fixed full orthogonal O.',
     'classification':'source-implicit','reason':'Orthogonality makes the two pointwise coordinate statements equivalent. No random-O joint kernel or conditional representative is asserted.'},
    {'source':'The hard family uses the actual conjugated precision and its inverse covariance.',
     'lean':'Identical midpoint grid, full real O, d>=2 and kappa>=2; proper covariance is justified by canonical admissibility inside the proof.',
     'classification':'same','reason':'No determinant1 restriction, alternative covariance scale or additional positive-definiteness premise.'},
    {'source':'The norm component has mean equal to the finite sum of inverse eigenvalues, independent of the cosine frequency.',
     'lean':'PRIVATE actual target norm-square Integrable output and that exact finite mean, with no frequency binder.',
     'classification':'source-implicit','reason':'The paired latent moment API uses an internally selected valid frequency1. No frequency/query/bias condition is added to the norm component.'},
    {'source':'A finite Gaussian second moment is implicit in the displayed norm expectation.',
     'lean':'The private application derives L1 from the existing actual diagonal-Gaussian theorem and measurable norm-preserving transport.',
     'classification':'source-implicit','reason':'Integrability is an output and consumed proof ingredient, not an extra public or private hypothesis.'},
    {'source':'The complete source argument also needs quadratic moments, target pass probability, concentration, adaptive/Krylov laws and oracle/TV/cost comparisons.',
     'lean':'This Anchor supplies only the full fixed-basis Gaussian law and its genuine private norm-moment application.',
     'classification':'same','reason':'The attributed auxiliary contract explicitly stops at these prerequisites and does not claim the entire lemma or main lower bound.'}]
binding = {'declaration':name,'cell':'ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-target-law',
    'role':'prerequisite','supports':['orthogonal-target-law'],'boundary':x['boundary'],
    'audit_id':aid,'assumption_deltas':deltas}
original = ' '.join([x['statement'],x['formula'],*x['assumptions']])
item = {'id':'huanjian-fixed-spectrum-target-law','library':'samplewiki','chapter':'gaussian-sampling-complexity',
    'chapter_path':'example-cases/samplewiki/companions/gaussian-sampling-complexity.html',
    'title':x['title'],'source':source,'statement':original,
    'formulae':[{'label':'Actual fixed-basis Gaussian target law','tex':x['formula']}],
    'assumptions':x['assumptions'],
    'obligations':[{'id':'orthogonal-target-law','label':'Actual orthogonal pushforward diagonal Gaussian equals the actual inverse-precision target; covariance facts derived internally.'}],
    'bindings':[binding]}
put('website/content/publications/huanjian-fixed-spectrum-target-law.json',{'schema_version':1,'items':[item]})
head,body = s['producer']['signature'].split(' :\n',1)
statement = '∀ '+head.removeprefix('theorem actual_rotated_gaussian_target').strip()+',\n'+body
context = [
    'Natural dimensions use Fin d={0,...,d-1}. All displayed casts, real fractions, pi and cosine have their standard meanings.',
    'EuclideanSpace Real(Fin d) is the finite real Euclidean space with its ordinary L2 norm. WithLp.toLp 2 and WithLp.ofLp convert between its bundled form and coordinate functions.',
    'Matrix.orthogonalGroup(Fin d) Real is the full real orthogonal group. Its real matrix transpose is its inverse on both sides; it imposes no determinant1 condition. Matrix multiplication and mulVec are the usual exact operations.',
    'Matrix.diagonal has the displayed diagonal and zero off it. An inverse of a displayed square matrix is the existing nonsingular matrix inverse; it is distinct from a real scalar reciprocal.',
    'multivariateGaussian m S is the existing Gaussian probability measure obtained by mapping the standard covariance-one Euclidean Gaussian by x->m+sqrt(S)x. For positive semidefinite S its mean is m and covariance matrix is S. A non-positive-semidefinite parameter uses the documented zero-square-root Dirac fallback.',
    'Measure.map f denotes pushforward by f when f is measurable. Universal quantification and local let definitions have their usual dependent meanings; the displayed coordinate matvec is a continuous linear map.']
audit = {'id':aid,'state':'draft',
    'source':{'source_id':'arxiv2610.20492v1-orthogonal-gaussian-target-law-auxiliary','url':source['url'],
              'anchor':source['anchor'],'original_text':original,'text_sha256':sha(original),
              'source_snapshot_sha256':s['source']['raw']['sha256']},
    'lean':{'declaration':name,'file':str(P),'statement':statement,'statement_sha256':sha(statement),
            'formalizer':'huanjian_gc_20261110_fixed_spectrum_target_law','compiled':True,'decoder_context':context},
    'reconstruction':{},'semantic_slots':{},'deltas':[],'verdict':'pending',
    'source_review':{'state':'pending'},'repairs':[]}
pub.inputs.cache_clear()
pub.load.cache_clear()
audit['publication_binding_sha256'] = pub.binding_digest(item,binding)
audit['publication_context'] = pub.review_context(item,binding)
put('research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-target-law.json',audit)
pub.check_advance([name],reviewed=False)
packet = rt.decoder_packet(audit)
neutral = Path('.astis/semantic-neutral-20261110/p_c0e827')
put(neutral/'input.json',packet)
put(E/'decoder-input.json',packet)
record = {'producer_raw_sha256':sha(P.read_bytes()),'Test_raw_sha256':sha(T.read_bytes()),
    'producer_signature_sha256':s['producer']['signature_sha256'],
    'private_consumer_signature_sha256':s['actual_private_consumer']['signature_sha256'],
    'publication_binding_sha256':audit['publication_binding_sha256'],
    'anonymous_statement_sha256':sha(statement),'anonymous_packet_canonical_sha256':packet['packet_sha256'],
    'neutral_input':str(neutral/'input.json'),'neutral_input_raw_sha256':sha((neutral/'input.json').read_bytes()),
    'exact_step_code_records':records,'actual_first_public_ASTIS_parents':k['actual_first_public_ASTIS_parents'],
    'actual_owned_declarations':2,'all2_root_reachable':True,'generated_auxiliaries':0,
    'source_review':'pending','decoder':'pending','sourceV_global_Goal_complete':False}
put(E/'publication-draft-record.json',record)
print(json.dumps(record))
