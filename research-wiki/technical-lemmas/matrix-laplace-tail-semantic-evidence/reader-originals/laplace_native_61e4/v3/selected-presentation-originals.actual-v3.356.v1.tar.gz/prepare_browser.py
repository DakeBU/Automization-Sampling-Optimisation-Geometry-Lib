"""New Laplace reader contract; reuse browser mechanisms only, never old outcomes."""
import ast
import hashlib
from html.parser import HTMLParser
import json
from pathlib import Path
import plistlib
import re

OWN=Path(__file__).resolve().parent
REPO=OWN.parents[3]
PREVIEW=REPO/'.astis/huanjian-gc-matrix-laplace-20261114/reader-preview-v3'
OLD=REPO/'.astis/semantic-neutral-20261114/weighted_mgf_native_8c2d/runtime'
PFILE='AutoSamplingTheory/TechnicalLemmas/Probability/MatrixLaplaceTail.lean'
TFILE='Tests/GaussianComplexityLaplaceTail.lean'
RFILE='AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumSourceMatrixRadius.lean'
SFILE='AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumSourceMatrixStructure.lean'
P='AutoSamplingTheory.TechnicalLemmas.Probability.MatrixLaplaceTail.max_eigenvalue_tail_le_iInf_trace_exp'

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,d):Path(p).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')

class PreText(HTMLParser):
    def __init__(self):super().__init__(convert_charrefs=True);self.depth=0;self.texts=[];self.current=''
    def handle_starttag(self,t,a):
        if t=='pre':self.depth+=1;self.current=''
    def handle_data(self,s):
        if self.depth:self.current+=s
    def handle_endtag(self,t):
        if t=='pre':self.depth-=1;self.texts.append(self.current)

class StepCode(HTMLParser):
    def __init__(self):super().__init__(convert_charrefs=True);self.steps=[];self.details=[];self.in_pre=False;self.current=''
    def handle_starttag(self,t,a):
        attrs=dict(a)
        if t=='details':self.details.append(bool(self.details and self.details[-1]) or 'proof-reader-step' in attrs.get('class','').split())
        if t=='pre' and self.details and self.details[-1]:self.in_pre=True;self.current=''
    def handle_data(self,s):
        if self.in_pre:self.current+=s
    def handle_endtag(self,t):
        if t=='pre' and self.in_pre:self.steps.append(self.current);self.in_pre=False
        if t=='details':self.details.pop()

def main():
    assert not (OWN/'independent-browser-contract.v1.json').exists()
    assert sha(PREVIEW/'preview-freeze-manifest.json')=='9209609b560905e6cd11a69082ac4bdb89e752a66fe3e99ba38e17508d2103b7'
    manifest=json.loads((PREVIEW/'preview-freeze-manifest.json').read_text())
    assert manifest['proof_commit']=='1d1103af694b9663a72b0d610004ed85c7c6b527'
    verified=[]
    for variant in ['original','candidate']:
        root=PREVIEW/'fixtures'/variant
        for row in manifest['variants'][variant]['files']:
            assert sha(root/row['path'])==row['sha256']
            verified.append({'path':str(root/row['path']),'sha256':row['sha256']})
    sources=[]
    for label,raw,anchor,count in [('P',PFILE,55,96),('T',TFILE,44,193),('Radius',RFILE,101,226),('Structure',SFILE,13,148)]:
        source=PREVIEW/'input-snapshot'/raw
        assert len(source.read_text().splitlines())==count
        for variant in ['original','candidate']:
            page=PREVIEW/'fixtures'/variant/('data/lesson-sources/'+raw+'.html')
            parser=PreText();parser.feed(page.read_text())
            assert len(parser.texts)==1 and parser.texts[0].encode()==source.read_bytes()
        # The source is exactly the same immutable input already audited independently.
        frozen=OWN.parent/'candidate-1d1103af6'/raw
        assert source.read_bytes()==frozen.read_bytes()
        sources.append({'label':label,'raw':raw,'anchor':anchor,'lines':count,'sha256':sha(source),'byte_exact_both_source_pages':True})
    proof=PREVIEW/'fixtures/candidate'/manifest['variants']['candidate']['proof_path']
    parsed=PreText();parsed.feed(proof.read_text())
    # Proof page has six exact step pre blocks plus possible full statement disclosures.
    html=proof.read_text()
    folds=re.findall(r'<details class="proof-reader-step".*?</details>\s*</details>',html,re.S)
    # Direct code extraction is independently checked again by the live browser.
    step_parser=StepCode();step_parser.feed(html);code=step_parser.steps
    assert len(code)==6
    assert ''.join(code[:3]).encode()==(PREVIEW/'input-snapshot'/PFILE).read_bytes()
    assert ''.join(code[3:]).encode()==(PREVIEW/'input-snapshot'/TFILE).read_bytes()
    starts=[1,53,86,1,77,165]
    tags=re.findall(r'<a data-step-source href="([^"]+)">',html)
    assert len(tags)==6
    assert all(tags[i].endswith(([PFILE]*3+[TFILE]*3)[i]+'.html#L'+str(starts[i])) for i in range(6))
    write(OWN/'sourcebody-byte-exact.v1.json',{'preview_manifest_sha256':sha(PREVIEW/'preview-freeze-manifest.json'),'all_fixture_files_independently_rehashed':len(verified),'sources':sources,'six_folds_byte_exact_P96_T193':True,'starts':starts,'prior_results_used':False})
    text=(OLD/'browser_check.py').read_text()
    replacements={
      '.astis/huanjian-gc-weighted-mgf-20261114/reader-preview-v2':'.astis/huanjian-gc-matrix-laplace-20261114/reader-preview-v3',
      'MatrixBernsteinMgf.lean':'MatrixLaplaceTail.lean','Tests/GaussianComplexityBernsteinWeightedMgf.lean':TFILE,
      'MatrixBernsteinMgf.centered_bounded_matrix_mgf':'MatrixLaplaceTail.max_eigenvalue_tail_le_iInf_trace_exp',
      'Tests.GaussianComplexityBernsteinWeightedMgf':'Tests.GaussianComplexityLaplaceTail',
      'independent-browser-contract.v4.json':'independent-browser-contract.v1.json','browser-output-v4':'browser-output-v1','browser-process-v4':'browser-process-v1',
      'candidate-4869db55':'candidate-1d1103af6','exact-P121':'exact-P96','exact-T159':'exact-T193','all280':'all289',
      '== 121 and':'== 96 and','== 159)':'== 193)',
      "[('P', PFILE, 46, 121), ('T', TFILE, 21, 159)]":"[('P', PFILE, 55, 96), ('T', TFILE, 44, 193), ('Radius', '"+RFILE+"', 101, 226), ('Structure', '"+SFILE+"', 13, 148)]",
      'theorem centered_bounded_matrix_mgf':'theorem max_eigenvalue_tail_le_iInf_trace_exp',
      'private theorem actual_source_weighted_normalized_single_summand_mgf':'private theorem actual_source_four_sums_laplace_tail',
      "else 'private theorem actual_source_four_sums_laplace_tail'":"else 'private theorem actual_source_four_sums_laplace_tail' if source_label == 'T'\n                                  else 'theorem actual_source_truncated_matrix_norm_bounds' if source_label == 'Radius'\n                                  else 'theorem actual_source_centered_matrix_structure'",
      "module = PMOD if source_label == 'P' else TMOD":"module = raw[:-5].replace('/', '.')",
      "'actual_source_weighted_normalized_single_summand_mgf'":"'actual_source_four_sums_laplace_tail'",
      'independent-native-weighted-mgf-browser-result-v4':'independent-native-laplace-tail-browser-result-v1',
      'independent-native-actual-browser-process-receipt-v4':'independent-native-laplace-browser-process-receipt-v1',
      'frozen-MGF-scoped-reader-overlay-v2-anchor-repair':'frozen-Laplace-reader-preview-v3',
    }
    for before,after in replacements.items():
        assert before in text,before
        text=text.replace(before,after)
    text=text.replace('from browser_extensions import step_actions, source_extra, graph_extra','from browser_extensions import step_actions, source_extra, graph_extra, source_bottom, parent_context')
    text=text.replace("                        source_extra(page, raw, exact, output, label, check)","                        source_extra(page, raw, exact, output, label, check)\n                        source_bottom(page, source_label, line_count, label, check, screenshot)")
    text=text.replace("                    graph = context.request.get(origin + '/data/underlying-lean-graph.json').json()","                    graph = context.request.get(origin + '/data/underlying-lean-graph.json').json()\n                    check(label + '-exact-seven-graph-nodes-nine-edges',len(graph['nodes'])==7 and len(graph['edges'])==9)\n                    check(label + '-public-P-no-ASTIS-declaration-parent',not any(e['target']=='decl:'+P and e['source'].startswith('decl:') for e in graph['edges']))")
    text=text.replace("                    graph_extra(page, context, origin, selected, label, check, screenshot, P, PMOD, TMOD)","                    graph_extra(page, context, origin, selected, label, check, screenshot, P, PMOD, TMOD)\n                    parent_context(page, origin, label, check, screenshot)")
    ast.parse(text)
    (OWN/'browser_check.py').write_text(text)
    ext=(OLD/'browser_extensions.py').read_text().replace('MatrixBernsteinMgf.lean','MatrixLaplaceTail.lean').replace('Tests/GaussianComplexityBernsteinWeightedMgf.lean',TFILE).replace('[1, 45, 88, 1, 120, 139]','[1, 53, 86, 1, 77, 165]').replace('huanjian-matrix-bernstein-mgf','huanjian-matrix-laplace-tail')
    ext=ext.replace("('P' if raw == PFILE else 'T')","({'"+PFILE+"':'P','"+TFILE+"':'T','"+RFILE+"':'Radius','"+SFILE+"':'Structure'}[raw])")
    ext=ext.replace("    if button.count() == 1:","    check(label + '-source-copy-control-present-' + raw, button.count() == 1)\n    if button.count() == 1:")
    ext += (OWN/'extra_measurements.py').read_text()
    ast.parse(ext)
    (OWN/'browser_extensions.py').write_text(ext)
    chrome=Path('/Applications/Google Chrome.app/Contents/MacOS/Google Chrome')
    info=Path('/Applications/Google Chrome.app/Contents/Info.plist')
    meta=plistlib.loads(info.read_bytes())
    paths=[PREVIEW/n for n in ['preview-freeze-manifest.json','input-freeze-manifest.json','render_preview.py','reader_overlay.py']]
    paths += [p for p in (PREVIEW/'input-snapshot').rglob('*') if p.is_file()]
    paths += [OWN/'browser_extensions.py',OWN/'sourcebody-byte-exact.v1.json',OWN/'extra_measurements.py']
    inputs=[{'path':str(p),'sha256':sha(p)} for p in paths]+verified
    contract={'schema':'independent-laplace-native-browser-contract-v1','status':'FROZEN_INDEPENDENT_NATIVE_BROWSER_APPROVED_BY_ROOT',
      'mathematical_candidate':manifest['proof_commit'],'reader_freeze_sha256':sha(PREVIEW/'preview-freeze-manifest.json'),'wrapper_sha256':sha(OWN/'browser_check.py'),'owned_inputs':inputs,
      'reader_identity':{'frozen_fixture_manifest_sha256':sha(PREVIEW/'preview-freeze-manifest.json'),'input_snapshot_manifest_sha256':sha(PREVIEW/'input-freeze-manifest.json'),'metadata_version':manifest['metadata_version'],'lesson_sha256':manifest['lesson_sha256'],'publication_sha256':manifest['publication_sha256'],'reader_generated_at_git_commit':None,'generation_commit_boundary':'No generation commit inferred; exact frozen manifest and bytes identify this isolated reader.'},
      'execution_custody':{'actual_process_invoker':'independent laplace_native_61e4 actor under explicit ROOT delegation','old_results_or_PNGs_reused':False,'root_and_fresh_source_visual_review':'pending real new PNGs'},
      'installed_chrome':{'executable_path':str(chrome),'binary_sha256':sha(chrome),'Info_plist_path':str(info),'Info_plist_sha256':sha(info),'app_short_version':meta.get('CFBundleShortVersionString'),'app_build_version':meta.get('CFBundleVersion')},
      'viewports':[{'name':'desktop','width':1440,'height':1000},{'name':'mobile','width':390,'height':844}],
      'exact_commands':{'candidate':[str(REPO/'.astis/huanjian-gc-integration-20261105/browser-venv/bin/python'),str(OWN/'browser_check.py'),'candidate']},
      'scope':'Fresh actual Chrome candidate reader test: six initially folded exact P/P/P/T/T/T code steps, formulas and overflow, six real clipboard/full-module download/source-anchor actions, all four complete exact source pages with header, longest full codepoint and bottom-glyph measurements, module downloads, source-index navigation, public P with no ASTIS theorem parent, private T three actual parents, exact graph seven nodes/nine edges and real wheel/pointer zoom-detail navigation.',
      'sources':sources,'six_fold_source_starts':starts,'expected_graph_nodes':7,'expected_graph_edges':9,
      'measurement_input':'trimEnd only to choose last non-whitespace complete Unicode codepoint in actual Text node; no source/body text modification; preserve positive glyph width/height, fixed-header, horizontal and viewport bounds assertions',
      'all_writes_beneath_owned_runtime':True,'only_localhost_requests_permitted':True,'no_other_user_tabs_opened':True,'server_lifecycle':'same foreground process, shutdown/server_close/worker.join in finally','normal_API_calls':0,'production_writes':0,'GUI_execution_requires_tool_escalation':True,
      'mechanism_reuse':[{'path':str(OLD/n),'sha256':sha(OLD/n)} for n in ['browser_check.py','browser_extensions.py']],
      'prior_contract_acceptance_flags_copied':False,'prior_result_or_PNG_read_or_copied':False}
    write(OWN/'independent-browser-contract.v1.json',contract)
    print(json.dumps({'contract_sha256':sha(OWN/'independent-browser-contract.v1.json'),'wrapper_sha256':sha(OWN/'browser_check.py'),'sourcebody_byte_exact':True,'browser_started':False}))

if __name__=='__main__':main()
