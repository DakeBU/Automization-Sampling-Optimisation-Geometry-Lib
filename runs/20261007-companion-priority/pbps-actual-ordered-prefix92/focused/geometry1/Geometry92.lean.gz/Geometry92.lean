import AutoSamplingTheory.ExampleCases.ProximalBPS.ActualAbsoluteNextEventTime
import Mathlib.MeasureTheory.Constructions.Pi

/-! Internal proof development for sealed92, not a completed public theorem. -/
namespace OrderedPrefix92
open MeasureTheory ProbabilityTheory InnerProductSpace
open scoped NNReal ENNReal Topology ContDiff Interval
noncomputable section
set_option autoImplicit false

private theorem measurable_cons_zero (n : ℕ) (j : Fin (n + 1)) :
    Measurable (fun t : Fin n → ℝ => (Fin.cons (0 : ℝ) t : Fin (n + 1) → ℝ) j) := by
  induction j using Fin.cases with
  | zero => simpa only [Fin.cons_zero] using (measurable_const : Measurable (fun _ : Fin n → ℝ => (0 : ℝ)))
  | succ i => simpa only [Fin.cons_succ] using (measurable_pi_apply i : Measurable (fun t : Fin n → ℝ => t i))

private theorem simplex_measurable (n : ℕ) (T : ℝ≥0) :
    MeasurableSet {t : Fin n → ℝ |
      StrictMono (Fin.cons (0 : ℝ) t) ∧ ∀ i, t i < (T : ℝ)} := by
  apply MeasurableSet.inter
  · change MeasurableSet {t : Fin n → ℝ | ∀ i j : Fin (n + 1), i < j →
      (Fin.cons (0 : ℝ) t : Fin (n + 1) → ℝ) i < (Fin.cons (0 : ℝ) t : Fin (n + 1) → ℝ) j}
    exact measurableSet_setOf_forall fun i => measurableSet_setOf_forall fun j =>
      measurableSet_setOf_forall fun _ => measurableSet_lt (measurable_cons_zero n i) (measurable_cons_zero n j)
  · exact measurableSet_setOf_forall fun i => measurableSet_lt (measurable_pi_apply i) measurable_const

private def readTime {Z : Type*} (r : (ℝ≥0 × Z) ⊕ Unit) : ℝ :=
  match r with
  | Sum.inl q => q.1
  | Sum.inr _ => 0

private theorem readTime_measurable {Z : Type*} [MeasurableSpace Z] :
    Measurable (@readTime Z) := by
  apply Measurable.sumElim
  · exact NNReal.measurable_coe.comp measurable_fst
  · exact measurable_const

private theorem live_measurable {Z : Type*} [MeasurableSpace Z] :
    MeasurableSet {r : (ℝ≥0 × Z) ⊕ Unit | ∃ a, r = Sum.inl a} := by
  have heq : {r : (ℝ≥0 × Z) ⊕ Unit | ∃ a, r = Sum.inl a} = Set.range Sum.inl := by
    ext r
    simp only [Set.mem_setOf_eq, Set.mem_range, eq_comm]
  rw [heq]
  exact measurableSet_range_inl

private theorem history_guard_measurable {Z : Type*} [MeasurableSpace Z] (n : ℕ) (T : ℝ≥0) :
    MeasurableSet {h : Fin (n + 1) → ((ℝ≥0 × Z) ⊕ Unit) |
      (∀ j, ∃ a : ℝ≥0 × Z, h j = Sum.inl a) ∧
      StrictMono (fun j => readTime (h j)) ∧
      ∀ i : Fin n, readTime (h i.succ) < (T : ℝ)} := by
  apply MeasurableSet.inter
  · exact measurableSet_setOf_forall fun j => live_measurable.preimage (measurable_pi_apply j)
  · apply MeasurableSet.inter
    · change MeasurableSet {h : Fin (n + 1) → ((ℝ≥0 × Z) ⊕ Unit) |
        ∀ i j : Fin (n + 1), i < j → readTime (h i) < readTime (h j)}
      exact measurableSet_setOf_forall fun i => measurableSet_setOf_forall fun j =>
        measurableSet_setOf_forall fun _ => measurableSet_lt
          (readTime_measurable.comp (measurable_pi_apply i))
          (readTime_measurable.comp (measurable_pi_apply j))
    · exact measurableSet_setOf_forall fun i => measurableSet_lt
        (readTime_measurable.comp (measurable_pi_apply i.succ)) measurable_const

end
end OrderedPrefix92
