from pathlib import Path
import json,subprocess,os,datetime,hashlib
R=Path.cwd();O=R/'.astis/semantic-neutral-20261111/rc_native_68bc';e=json.loads((O/'environment.json').read_text()); env=os.environ.copy();env['LEAN_PATH']=str(O/'native-lib')+':'+':'.join(x['lib'] for x in e['packages']);env.pop('LEAN_SRC_PATH',None)
results=[]
for n,m in enumerate(e['modules'],1):
 src=O/'native-src'/m['path'];dst=O/'native-lib'/Path(m['path']).with_suffix('.olean');dst.parent.mkdir(parents=True,exist_ok=True);args=[e['binary'],'-R',str(O/'native-src'),'-o',str(dst),str(src)];start=datetime.datetime.now(datetime.timezone.utc).isoformat();p=subprocess.run(args,cwd=O/'native-src',env=env,capture_output=True);(O/f'build-{n}.stdout.log').write_bytes(p.stdout);(O/f'build-{n}.stderr.log').write_bytes(p.stderr);r={'command':args,'LEAN_PATH':env['LEAN_PATH'],'started_utc':start,'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':p.returncode,'source_sha256':m['sha256'],'stdout_log':f'build-{n}.stdout.log','stderr_log':f'build-{n}.stderr.log','olean_sha256':hashlib.sha256(dst.read_bytes()).hexdigest() if dst.exists() else None};results.append(r);(O/'native-build.json').write_text(json.dumps(results,indent=2)+'\n'); print(json.dumps(r),flush=True)
 if p.returncode:raise SystemExit(p.returncode)
