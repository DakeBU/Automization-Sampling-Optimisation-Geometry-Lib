# Independent v3 browser-contract binding check

Reviewer: `mgf_fresh_source_5b7e`.
Decision: **The exact v3 contract is accepted for ROOT's candidate-only actual execution against the independently accepted static reader-preview-v2. This is not runtime acceptance.**

Exact runner SHA `a00b0b144d94257e88f7b054d43acaf3e771b7409cf895d02daa32c2863e0416`.
Exact contract SHA `fbd604768689df98986ecfa1fa2de691bc3e851f4b6a4c7e9b41e3dbb56cc051`.
Exact self-check SHA `de43821be3c16973d2b01b210756b85ff3dd588948edad740b7100fd4d5b17e7`.
Exact script diff SHA `7404e09c994086d71a86334ae447d09e64b2cb9a7bdf00a57d75887afe95a87e`.
Preview manifest SHA `c93f60d6b51a0da491bd748d54bdbc68fbdbc2f86653de5914539afb2aaee7d1`.

The phase7 real failure review was frozen first; the exact minimal class repair was separately accepted and frozen in phase8. This v3 check then read the actual new contract, runner, exact diffs and self-check without executing or importing them. ROOT reported starting its actual run while this independent pre-interpretation check was being completed. No v3 result flags or PNGs were read before this record.

`independent-v3-binding-checks.json` records15 independent checks, all passing:

- The supplied script diff is the exact diff between the independently archived v2 runner and actual v3 runner.
- All42 literal `check(...)` ASTs are identical in order and content.
- The entire runner AST is identical after normalizing only the explicit preview pointer, contract/output/process version paths and result/receipt identity string literals. No assertion, status calculation, browser interaction, stream capture or cleanup is removed from this comparison.
- The complete extension bytes are unchanged.
- Chrome identity, viewports, localhost-only routing, no-other-tabs, output-write boundary, server cleanup and no-normal-API contract fields are unchanged.
- All372 actual owned-input file hashes match the contract.
- New preview and repaired overlay match the exact phase8-reviewed files; actual render receipt hash and observed generation HEAD match, with no invented generation commit.
- The command set contains candidate only and uses separate v3 output/process directories.
- Both old preservation manifests and all archived v1/v2 files retain their exact bytes.
- The unchanged baseline has109 original fixture files. Its real v2 result remains162 checks with15 failures; it is not reclassified as a pass. Since those original fixture bytes are identical, no original rerun is required by this bounded repair comparison.

The accepted execution scope is only ROOT's existing frozen candidate command under the contract. This reviewer did not run/poll/restart Chrome, start a server, call an API or request a proof-state transition. A new actual receipt, raw streams, complete check record, source-anchor geometry and desktop/mobile images must still be examined before any candidate reader-runtime acceptance.

Graph qualification remains unchanged: default fit is an overview with tiny labels; zoomed SVG labels may remain elliptical/clipped; exact identifiers require the actual detail inspector. The minimal anchor repair does not purport to redesign that graph or alter mathematics.

No proof VERIFIED, production renderer/site integration, main, purification or whole-goal completion is granted here. Earlier failed runtime results and reports remain immutable originals.
