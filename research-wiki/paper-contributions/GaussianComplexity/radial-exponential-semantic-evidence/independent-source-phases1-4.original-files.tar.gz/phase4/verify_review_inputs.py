"""Check canonical packet, mapped source/code spans, and lesson code bindings."""

import hashlib
import json
from pathlib import Path


EVIDENCE = Path("research-wiki/paper-contributions/GaussianComplexity/radial-exponential-semantic-evidence")
SOURCE = Path(".astis/huanjian-resume-20261103/2610.20492v1.html")
SNAPSHOTS = Path(".astis/huanjian-gc-radial-exponential-20261110/fresh-source-immutable-modules")
EXPECTED_PACKET_RAW = "21955808b56a1a6b6747f6d64086073a232b18c1b79dfdd6ba0a1c8bc3c9da63"
EXPECTED_PACKET_CANONICAL = "493fe1dce4a3cdea9af2ca791c5a637036ae66f1611aa86f8fb0220809386148"
EXPECTED_BINDING = "73a244cdf93dd12673339c0345e56a4db555b6d0b11811642c66f224c15ee1fb"
EXPECTED_MAP = "b5b129bccf1fc2ecec251aa62843dbdbaaa7f5f99025875e2182cb2ef3ae6b47"
EXPECTED_SOURCE = "6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915"
EXPECTED_PRODUCER = "c44b2840eb91a3abf29434bdf2baa9859b503f7a30c24c10ed3296e7f41c88e4"
EXPECTED_CONSUMER = "d80698f914312d2953bb1ac1a8f0a92d43a752389f0e14f6abcfa01563345443"
PRODUCER = "AutoSamplingTheory/TechnicalLemmas/Probability/StdGaussianRadialExponential.lean"
CONSUMER = "Tests/GaussianComplexityRadialExponential.lean"


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def canonical(data: object) -> bytes:
    return json.dumps(data, sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode("utf-8")


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def pinned(path: Path, expected: str) -> bytes:
    raw = path.read_bytes()
    actual = sha256(raw)
    require(actual == expected, f"Raw digest mismatch for {path}: {actual}")
    print(f"{path} sha256={actual} bytes={len(raw)}")
    return raw


def span(
    raw: bytes, char_range: list[int], byte_range: list[int], line_range: list[int], expected: str
) -> str:
    text = raw.decode("utf-8")
    char_start, char_end = char_range
    byte_start, byte_end = byte_range
    start_line, end_line = line_range
    require(0 <= char_start < char_end <= len(text), "Invalid character span")
    require(0 <= byte_start < byte_end <= len(raw), "Invalid byte span")
    require(len(text[:char_start].encode("utf-8")) == byte_start, "Byte start mismatch")
    fragment = text[char_start:char_end]
    data = fragment.encode("utf-8")
    require(data == raw[byte_start:byte_end], "Character and byte spans disagree")
    require(text.count("\n", 0, char_start) + 1 == start_line, "Start line mismatch")
    require(text.count("\n", 0, char_end - 1) + 1 == end_line, "End line mismatch")
    require(sha256(data) == expected, "Span digest mismatch")
    return fragment


def main() -> None:
    packet = json.loads(pinned(EVIDENCE / "anti-anchored-reviewer-packet.exact.json", EXPECTED_PACKET_RAW))
    packet_digest = packet.pop("packet_sha256")
    require(packet_digest == EXPECTED_PACKET_CANONICAL == sha256(canonical(packet)), "Canonical packet mismatch")
    print(f"canonical_reviewer_packet_sha256={packet_digest}")
    require(packet["publication_binding_sha256"] == EXPECTED_BINDING, "Publication binding field mismatch")
    context = packet["candidate_publication_context"]
    print(f"canonical_packet_bound_publication_binding_sha256={EXPECTED_BINDING}")
    for section, text_key, hash_key in (
        ("source", "original_text", "text_sha256"),
        ("lean", "statement", "statement_sha256"),
        ("blind_reconstruction", "text", "text_sha256"),
    ):
        entry = packet[section]
        require(sha256(entry[text_key].encode("utf-8")) == entry[hash_key], f"{section} text digest mismatch")
        print(f"{section} text_sha256={entry[hash_key]}")

    mapping = json.loads(pinned(EVIDENCE / "source-lean-map.draft.json", EXPECTED_MAP))
    source_raw = pinned(SOURCE, EXPECTED_SOURCE)
    require(mapping["source_snapshot_sha256"] == EXPECTED_SOURCE, "Map source pin mismatch")
    producer_raw = pinned(SNAPSHOTS / "StdGaussianRadialExponential.lean.txt", EXPECTED_PRODUCER)
    consumer_raw = pinned(SNAPSHOTS / "GaussianComplexityRadialExponential.lean.txt", EXPECTED_CONSUMER)
    modules = {PRODUCER: producer_raw, CONSUMER: consumer_raw}

    producer = producer_raw.decode("utf-8")
    require(context["file"] == EXPECTED_PRODUCER, "Publication context code pin mismatch")
    require(context["current_lean_module"] == producer, "Publication context code bytes mismatch")
    heading = "theorem integrable_exp_norm_sq_div_three_and_integral_stdGaussian\n    "
    literal = producer.split(heading, 1)[1].split(" := by\n", 1)[0] + "\n"
    quantified = "∀ " + literal.replace("[BorelSpace E] :\n", "[BorelSpace E],\n", 1)
    require(packet["lean"]["statement"] == quantified, "Quantified statement differs from exact snapshot type")
    for row in mapping["mappings"]:
        for item in row["source"]:
            chars = [item["char_start"], item["char_end"]]
            bytes_ = [item["raw_utf8_start"], item["raw_utf8_end"]]
            lines = [item["lf_line_start"], item["lf_line_end"]]
            fragment = span(source_raw, chars, bytes_, lines, item["span_sha256"])
            require(f'id="{item["source_id"]}"' in fragment, "Mapped source ID absent")
            source_prefix = source_raw[: bytes_[0]].decode("utf-8")
            require(len(source_prefix.rsplit("\n", 1)[-1]) == item["lf_column0_start"], "Column mismatch")
            print(f"source {item['source_id']} lines={lines} bytes={bytes_} sha256={item['span_sha256']}")
        for item in row["lean"]:
            raw = modules[item["path"]]
            lines = item["LF_lines_1based"]
            bytes_ = item["raw_UTF8_byte_span"]
            require(sha256(raw) == item["file_sha256"], "Map module digest mismatch")
            fragment = span(raw, item["decoded_char_span"], bytes_, lines, item["span_sha256"])
            complete_lines = b"".join(raw.splitlines(keepends=True)[lines[0] - 1 : lines[1]])
            require(fragment.encode("utf-8") == complete_lines, "Lean span is not the indicated full lines")
            print(f"Lean {item['path']} lines={lines} bytes={bytes_} sha256={item['span_sha256']}")

    steps = context["lesson"]["steps"]
    require(len(steps) == 4, "Unexpected proof step count")
    producer_lines = producer_raw.splitlines(keepends=True)
    for index, (step, (start, end)) in enumerate(zip(steps[:3], ((27, 53), (54, 77), (78, 98))), start=1):
        expected = b"".join(producer_lines[start - 1 : end])
        require(step["lean"].encode("utf-8") == expected, f"Lesson step {index} code mismatch")
        print(f"lesson_step={index} producer_lines={start}-{end} code_sha256={sha256(expected)}")
    require(steps[3]["lean"].encode("utf-8") == consumer_raw, "Lesson step 4 differs from the private module")
    print(f"lesson_step=4 complete_consumer_sha256={EXPECTED_CONSUMER}")
    print("All exact reviewer packet, correspondence spans and lesson code bindings matched.")


if __name__ == "__main__":
    main()
