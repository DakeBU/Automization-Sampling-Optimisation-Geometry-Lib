from pathlib import Path
import sys,subprocess,json,datetime,time,hashlib,base64,os,stat
root=Path("/Users/zhouhuanjian/ASTIS-GC/.astis/semantic-neutral-20261111/kr_src_c47e12");p=root/'phase4';h=lambda b:hashlib.sha256(b).hexdigest()
child_code=r"""from pathlib import Path
import json,hashlib,stat,datetime
root=Path("/Users/zhouhuanjian/ASTIS-GC/.astis/semantic-neutral-20261111/kr_src_c47e12");p=root/'phase4';h=lambda b:hashlib.sha256(b).hexdigest()
prior=[]
for name,sha in [('phase1','a167e2a7d8d37008db6c3ba80e23598c86479896be084604ce46bdb9b16b3741'),('phase2','9c019cdbac59fdc3675474f0434573cb812e44350f63af017153fa2487dbddd2'),('phase3','374d4c22223d8acb1054c67f58b401aa73e58065ff568ad23dec963cabd5f33b')]:
 ep=root/name;mp=ep/'hash-manifest.json';assert h(mp.read_bytes())==sha;m=json.loads(mp.read_text())
 for row in m['files']:
  path=ep/row['path'];b=path.read_bytes();assert len(b)==row['bytes']and h(b)==row['sha256']and stat.S_IMODE(path.stat().st_mode)==0o444
 assert {str(x.relative_to(ep))for x in ep.rglob('*')if x.is_file()}=={r['path']for r in m['files']}|{'hash-manifest.json'}
 assert all(stat.S_IMODE(x.stat().st_mode)==(0o555 if x.is_dir() else 0o444)for x in [ep]+list(ep.rglob('*')))
 prior.append({'phase':name,'files':len(m['files'])+1,'manifest_sha256':sha,'all_unchanged':True})
(p/'earlier-phases-unchanged-at-final-freeze.json').write_text(json.dumps({'time_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':prior},indent=2)+'\n')
fp=p/'process-adapter-freeze.json';assert h(fp.read_bytes())=='51570715d281b248954fb658b992330e8c315c4eff57232330206cb7a3d20d05';f=json.loads(fp.read_text())
for row in f['core_artifacts']:
 b=(p/row['path']).read_bytes();assert len(b)==row['bytes']and h(b)==row['sha256'],row['path']
counts={'raw_command_receipts':0,'failed_executions_retained':0,'git_show_receipts':0}
for rp in sorted((p/'audit').glob('*.receipt.json')):
 r=json.loads(rp.read_text())
 for k in ['stdout','stderr']:
  b=(rp.parent/r[k]['path']).read_bytes();assert len(b)==r[k]['bytes']and h(b)==r[k]['sha256']
 counts['raw_command_receipts']+=1;counts['failed_executions_retained']+=int(r['exit_code']!=0)
for rp in sorted((p/'git-snapshots').glob('*.receipt.json')):
 r=json.loads(rp.read_text());assert r['argv'][:2]==['git','show']and r['exit_code']==0
 assert h((rp.parent/r['stdout_path']).read_bytes())==r['stdout_sha256']
 assert h((rp.parent/r['stderr_path']).read_bytes())==r['stderr_sha256']
 counts['git_show_receipts']+=1
assert counts['git_show_receipts']==7 and counts['failed_executions_retained']==1
print(json.dumps({'final_preparation':'PASS','earlier_phase_files_unchanged':163,'core_adapter_and_math_unchanged':True,**counts,'native_or_reader_outcomes_seen':False,'normal_transition':False},indent=2))
"""
start=datetime.datetime.now(datetime.timezone.utc).isoformat();t0=time.monotonic();argv=['/opt/anaconda3/bin/python','-c',child_code]
r=subprocess.run(argv,cwd='/Users/zhouhuanjian/ASTIS-GC',stdout=subprocess.PIPE,stderr=subprocess.PIPE)
receipt={'schema':'original-phase4-final-execution-receipt-v1','wrapper_argv':sys.argv,'wrapper_file_sha256':h(Path(__file__).read_bytes()),'child_argv':argv,'cwd':'/Users/zhouhuanjian/ASTIS-GC','started_utc':start,'ended_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'elapsed_seconds':time.monotonic()-t0,'exit_code':r.returncode,'stdout_raw_base64':base64.b64encode(r.stdout).decode('ascii'),'stderr_raw_base64':base64.b64encode(r.stderr).decode('ascii'),'stdout_sha256':h(r.stdout),'stderr_sha256':h(r.stderr),'note':'Exact byte streams retained; this receipt is included in the following detached complete hash manifest. Final closure hashes appear in the original tool transcript.','original_phase3_review_run_receipt_sha256':'e9147c56d0e646c93284d1b1b6477f5f29119f5f776bd6afb7ac676fb2ca1f5d','candidate_commit':'972d8994a816bc63d2dd6fb2db1c2c638fa9a48f','native_or_reader_outcomes_seen':False,'normal_transition':False}
rp=p/'original-execution-receipt.json';rp.write_text(json.dumps(receipt,indent=2)+'\n')
sys.stdout.buffer.write(r.stdout);sys.stdout.buffer.flush();sys.stderr.buffer.write(r.stderr);sys.stderr.buffer.flush()
if r.returncode:raise SystemExit(r.returncode)
rows=[]
for path in sorted(p.rglob('*')):
 if path.is_file()and path.name!='hash-manifest.json':
  assert not path.is_symlink(),str(path)
  os.chmod(path,0o444);b=path.read_bytes();rows.append({'path':str(path.relative_to(p)),'bytes':len(b),'sha256':h(b),'mode':'0444'})
m={'schema':'immutable-phase4-complete-manifest-v1','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reviewer':'/root/krylov_fresh_source_c47e12','scope':'All phase4 files except this detached manifest; includes original inputs, later schema supplement, seven exact permitted Git blobs/receipts, snapshots, original and final adapters, preserved nonmatching trials, failed execution/addendum, core freeze and actual final execution receipt.','core_freeze_sha256':'51570715d281b248954fb658b992330e8c315c4eff57232330206cb7a3d20d05','candidate_commit':'972d8994a816bc63d2dd6fb2db1c2c638fa9a48f','canonical_packet_sha256':'fa176cb7c2ff06fd19a0fdbc721b8dc64069eb3902a6012d41fe52a5f12f90d1','publication_binding_independently_reproduced':'7b97440eda9692f238e20ad1f0e985b5c38b4fc4f358ccffb02535b92df14ea7','source_review_overlay_unapplied':True,'all163_prior_phase_files_unchanged':True,'files':rows,'file_mode':'0444','directory_mode':'0555','native_or_reader_outcomes_seen':False,'normal_transition':False}
mp=p/'hash-manifest.json';mp.write_text(json.dumps(m,indent=2)+'\n');os.chmod(mp,0o444)
for d in sorted([x for x in p.rglob('*')if x.is_dir()],key=lambda x:len(x.parts),reverse=True):os.chmod(d,0o555)
os.chmod(p,0o555)
for path in [p]+list(p.rglob('*')):assert stat.S_IMODE(path.stat().st_mode)==(0o555 if path.is_dir() else 0o444),str(path)
for row in rows:
 b=(p/row['path']).read_bytes();assert len(b)==row['bytes']and h(b)==row['sha256']
print(json.dumps({'phase4_complete_manifest_sha256':h(mp.read_bytes()),'phase4_core_freeze_sha256':'51570715d281b248954fb658b992330e8c315c4eff57232330206cb7a3d20d05','original_actual_execution_receipt_sha256':h(rp.read_bytes()),'source_review_overlay_sha256':h((p/'source-review-overlay.json').read_bytes()),'canonical_result_v2_sha256':h((p/'canonical-semantic-review-result.v2.json').read_bytes()),'files_in_manifest':len(rows),'total_frozen_files':len(rows)+1,'all_files_0444_and_directories_0555':True,'all163_prior_phase_files_unchanged':True,'native_or_reader_outcomes_seen':False,'normal_transition':False,'exit_code':0},indent=2))

