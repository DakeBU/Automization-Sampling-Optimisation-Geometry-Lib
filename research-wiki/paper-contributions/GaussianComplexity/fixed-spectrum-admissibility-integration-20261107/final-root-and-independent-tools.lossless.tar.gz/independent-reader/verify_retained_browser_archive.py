from pathlib import Path
import json,hashlib,tarfile,datetime
R=Path('/Users/zhouhuanjian/ASTIS-GC');B=R/'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-admissibility-integration-20261107';O=B/'independent-integration-reader-review'
sha=lambda b:hashlib.sha256(b).hexdigest()
p=B/'browser-lossless-archive-manifest.json';m=json.loads(p.read_bytes());a=R/m['archive'];assert sha(a.read_bytes())==m['archive_sha256']=='d9991e7ebf4aaed5fddec47c05ed9c8dd4550f0286d85f80417d4980b108a05f'
assert len(m['files'])==37
with tarfile.open(a,'r:gz') as t:
 assert len(t.getmembers())==37 and set(t.getnames())=={x['member'] for x in m['files']}
 for row in m['files']:
  raw=(R/row['original']).read_bytes();assert sha(raw)==row['raw_sha256'] and t.extractfile(row['member']).read()==raw
c=B/'browser-global-prose-caveat.json';assert sha(c.read_bytes())=='2a97329c7450febcc546e21a8ab105a7c0474e6a3ce00081db9ea7acf2901d7a'
accept=O/'actual-local-integration-acceptance.json';assert sha(accept.read_bytes())=='710e350d2d72112b252084a09c8c2bca6cdb1e9bacbb94bca8ed37791f873bdf'
out={'reviewer':'/root/admiss_integration_reader','recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'local_acceptance_sha256':sha(accept.read_bytes()),'scope':'Separate evidence-retention completion and root caveat acknowledgement; frozen local acceptance/report/script remain unchanged.','lossless_archive':str(a.relative_to(R)),'archive_sha256':sha(a.read_bytes()),'manifest_sha256':sha(p.read_bytes()),'all37members_independently_roundtrip_compared_to_retained_originals':True,'root_caveat':str(c.relative_to(R)),'root_caveat_sha256':sha(c.read_bytes()),'actual_external_GitHub_HTML_or_link_syntax_or_HTTP200_or_publicpublication_credited':False,'source_code_ownsite_download_and_localimmutableGit_acceptance_unchanged':True,'no_build_browser_API_shared_or_ledger_mutation':True,'no_parking_authorization_or_execution':True}
q=O/'browser-evidence-retention-and-root-caveat.json';assert not q.exists();q.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'state':'ALL37_ARCHIVE_MEMBERS_VERIFIED_ROOT_CAVEAT_ACKNOWLEDGED','supplement_sha256':sha(q.read_bytes())}))
