cat .astis/semantic-neutral-20261110/src_d63b90/phase1/A3.SS3.txt
