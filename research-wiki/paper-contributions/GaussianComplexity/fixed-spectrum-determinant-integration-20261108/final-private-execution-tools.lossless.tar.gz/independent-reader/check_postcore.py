"""Future resumable read-only protection/source-V/gate/site/browser readback."""
import sys
sys.dont_write_bytecode=True
from det_acceptance_common import *

def main():
 args=parse_args(__doc__,lambda p:p.add_argument('--phase',choices=['protection-only','final-readback'],default='protection-only'))
 kind='determinant-postcore-protection-context' if args.phase=='protection-only' else 'determinant-postcore-context'
 authorization,ref=load_authorization(args,kind)
 if args.phase=='protection-only':
  report={'sourceV_lineage':source_lineage(authorization),'protection':protections(authorization),**origin_readback(authorization),'actual_Lean_site_browser_checks_claimed':False,'new_source_verdict':False}
 else: report,_,_=all_readonly_checks(authorization)
 report['readback_phase']=args.phase
 report.update({'reviewer':ACTOR,'state':'POSTCORE_READBACK_PASS_NOT_LOCAL_SITE_ACCEPTANCE','authorization':ref,'accepted_immutable_core':authorization['accepted_immutable_core'],'publication_binding_sha256':BINDING,'readonly_scope':'Repository/source/ledger/API/build/site/browser state is read only. Optional --output writes a new own report only; identical evidence can resume without overwrite.','actual_original_images_viewed_by_this_helper':0,'parking_authorized_or_executed':False,'source_fidelity_verdict_issued':False})
 emit(args,report)

if __name__=='__main__': main()
