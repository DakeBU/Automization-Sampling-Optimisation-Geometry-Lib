"""Explicit selected portable evidence; never recurse across private roots."""
from pathlib import Path
import datetime, hashlib, io, json, subprocess, sys, tarfile
O = Path(__file__).resolve().parent
ROOT = Path.cwd()
F = ROOT/'.astis/semantic-neutral-20261113/structure_final_native_f30b'
E = ROOT/'research-wiki/paper-contributions/GaussianComplexity/source-matrix-structure-semantic-evidence'
sha = lambda b: hashlib.sha256(b).hexdigest()
outcome = json.loads((O/'normal-VERIFIED-outcome.bounded.json').read_bytes())
assert outcome['status'] == 'VERIFIED_LOCAL_ONCE_OWNER_AND_GLOBAL_HOLD_RETAINED'
selected = {}
def add(name, source):
    assert name not in selected and '..' not in Path(name).parts
    source = Path(source); assert source.is_file()
    assert '.private.' not in source.name and source.name not in ['preflight.py','check_snapshot.py','preservation_guard.py']
    selected[name] = source
own_files = [
    'ROOT-READY.received.json','VERIFICATION-JUDGMENT.md','VERIFIED-evidence.full.json',
    'candidate-cell.exact.json','cell-before.exact.json','actual-VERIFIED-append.exact.jsonl',
    'normal-API.receipt.json','normal-VERIFIED-call.once.json','normal-VERIFIED-outcome.bounded.json',
    'before-normalV-preservation.bounded.json','after-normalV-preservation.bounded.json',
    'preliminary-readiness.bounded.json','final-package-review.bounded.json',
    'prepare_normal_verification.py','execute_normal_once.py','recorded_run.py','final_package_review.py',
    'package_verifier.py']
for name in own_files: add('verifier-originals/'+name,O/name)
for label in ['final-package-review','prepare-normal','normal-once','postwrite-frontier']:
    for name in ['stdout','stderr','receipt.json']:
        add('verifier-originals/commands/'+label+'/'+name,O/'commands'/label/name)
add('historical-originals/PROVED_LOCAL-evidence.full.json',E/'actual-PROVED_LOCAL-evidence.full.json')
add('historical-originals/PROVED_LOCAL-append.exact.jsonl',E/'actual-PROVED_LOCAL-append.exact.jsonl')
add('native-reader-selected-evidence.tar.gz',F/'selected-evidence.tar.gz')
add('source-review-selected-originals.tar.gz',E/'source-review/structure_src_c24d/enum_successor_v1/selected-source-originals.tar.gz')
for name in ['JUDGMENT.md','reader-assessment.json','gate-summary.json','native-inheritance-check.json','archive-closure.json']:
    add('final-peer-originals/'+name,F/name)
add('tinycheck.py',O/'package_tinycheck.py'); add('README.md',O/'PACKAGE-README.md')
records = [{'path':name,'bytes':source.stat().st_size,'sha256':sha(source.read_bytes()),
            'source_relative_to_repo':str(source.relative_to(ROOT))} for name,source in sorted(selected.items())]
manifest = {'scope':'Selected complete normal-verifier evidence with exact native/reader package once and accepted selected source-review archive once',
    'verifier_id':'structure_final_verifier_c91e','held_commit':outcome['verified_commit'],
    'files':records,'payload_file_count':len(records),
    'exclusions':['all full private preservation maps','whole repository indexes','foreign/control snapshots','private checker implementations'],
    'original_PL_fields_inline_unchanged':26,'normal_API_calls':1}
mb = (json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode()
seal = {'payload_manifest_sha256':sha(mb),'payload_file_count':len(records),
    'archive_regular_file_count':len(records)+2,'self_reference_policy':'Terminal internal metadata; archive hash is external.'}
sb = (json.dumps(seal,indent=2)+'\n').encode()
archive = O/'complete-verifier-evidence.tar.gz'
assert not archive.exists(), 'do not overwrite an immutable archive'
def put(tf,name,data):
    info = tarfile.TarInfo('verifier-complete/'+name); info.size = len(data); info.mode = 0o644
    info.mtime = 0; info.uid=0; info.gid=0; info.uname=''; info.gname=''
    tf.addfile(info,io.BytesIO(data))
with tarfile.open(archive,'w:gz') as tf:
    for name,source in sorted(selected.items()): put(tf,name,source.read_bytes())
    put(tf,'payload-manifest.json',mb); put(tf,'manifest-seal.json',sb)
extracted = O/'package-check'; extracted.mkdir(exist_ok=False)
with tarfile.open(archive,'r:gz') as tf:
    members = tf.getmembers(); names = [x.name for x in members]
    assert len(names) == len(set(names)) == len(records)+2
    assert all(x.isfile() and '..' not in Path(x.name).parts for x in members)
    for item in records:
        b = tf.extractfile('verifier-complete/'+item['path']).read()
        assert len(b) == item['bytes'] and sha(b) == item['sha256']
    # Only these two selected, already byte-checked reproduction archives nest.
    assert sorted(x for x in names if x.endswith(('.gz','.zip','.tar'))) == ['verifier-complete/native-reader-selected-evidence.tar.gz','verifier-complete/source-review-selected-originals.tar.gz']
    # Check nested source member JSON for forbidden full preservation map keys.
    source_bytes = tf.extractfile('verifier-complete/source-review-selected-originals.tar.gz').read()
    with tarfile.open(fileobj=io.BytesIO(source_bytes),mode='r:gz') as source_tf:
        assert len(source_tf.getmembers()) == 70
        forbidden = {'all_foreign_states','all_existing_tracked_fingerprints','actual_control_fingerprints','tracked_git_index','advance_states','index_exact'}
        def contains_private(x):
            if isinstance(x,dict): return any(k in forbidden for k in x) or any(contains_private(v) for v in x.values())
            return isinstance(x,list) and any(contains_private(y) for y in x)
        for m in source_tf.getmembers():
            assert m.isfile() and '..' not in Path(m.name).parts
            if m.name.endswith('.json'):
                assert not contains_private(json.loads(source_tf.extractfile(m).read()))
    tf.extractall(extracted,filter='data')
d = O/'commands/package-tinycheck'; d.mkdir(parents=True,exist_ok=False)
argv = [sys.executable,str(extracted/'verifier-complete/tinycheck.py')]
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
r = subprocess.run(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
(d/'stdout').write_bytes(r.stdout); (d/'stderr').write_bytes(r.stderr)
receipt = {'argv':argv,'started_at':started,'ended_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'exit_code':r.returncode,'stdout_sha256':sha(r.stdout),'stderr_sha256':sha(r.stderr)}
(d/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
assert r.returncode == 0, r.stderr.decode()
closure = {'status':'PASS','archive':str(archive.relative_to(ROOT)),'bytes':archive.stat().st_size,
    'sha256':sha(archive.read_bytes()),'payload_manifest_sha256':sha(mb),'manifest_seal_sha256':sha(sb),
    'payload_files':len(records),'archive_regular_members':len(records)+2,
    'exact_all_members_and_payload_bytes_checked':True,
    'exact_native_reader_package_occurrences':1,'exact_selected_source_review_archive_occurrences':1,
    'private_full_maps_indexes_guard_implementations_foreign_control_snapshots_exported':False,
    'tinycheck_exit':r.returncode,'tinycheck_receipt_sha256':sha((d/'receipt.json').read_bytes()),
    'normal_API_calls':1,'normal_VERIFIED_append_sha256':outcome['actual_VERIFIED_append_sha256'],
    'owner_and_global_HOLD_retained':True}
(O/'complete-archive-closure.json').write_text(json.dumps(closure,indent=2)+'\n')
print(json.dumps(closure,indent=2))
