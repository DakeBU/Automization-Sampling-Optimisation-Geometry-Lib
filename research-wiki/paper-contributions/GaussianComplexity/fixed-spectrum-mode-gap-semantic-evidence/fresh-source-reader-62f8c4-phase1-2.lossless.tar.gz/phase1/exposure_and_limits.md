# Ambient exposure and Phase 1 limits

Reviewer identity for this run: `/root/source_reader_62f8c4`. I was assigned a source-first reviewer role, not a mathematical implementation task. I did not construct or inspect any Lean proof, and did not invoke another agent.

## Exposure present before and during the source read

I do **not** claim zero ambient cues or zero prior mathematical familiarity.

* The assignment supplied the repository name/path `ASTIS-GC`, the original source filename/arXiv-style identity, its exact SHA-256, the selected scope (Section 2, Section 4 and Appendix C.3), the neutral output path and the intended later anti-anchored comparison role. Merely selecting these sections can focus attention on their relationship. No exact target declaration, target statement, anonymous reconstruction or target-specific minimal definition context was supplied in this phase.
* The inherited tool/developer/permission context included approved command prefixes whose names mention Gaussian affinity, block law, first-order query, fixed-spectrum query/determinant/admissibility/geometry/first-order/cosine expansion, `eq6`, `ex70`/`ex71`/`ex72`, and various browser-check scripts. These are ambient topic and workflow cues. I did not run those commands or open their script/file destinations. I did not use them as mathematical evidence.
* The authorized `AGENTS.md` includes broad project priorities and handoffs (several sampling papers, Gaussian Complexity/Optimisation/lower-bounds lanes, graph/publication/semantic-review processes, and an unrelated latest Bench/LSI-extension handoff). These process instructions contain mathematical topic names and fragments. They were read as authorized process exposure, not as a target statement or a substitute for the original source.
* The other four authorized process files describe statement sealing, binder and definition audits, source-proof topology, independent semantic round trips, common blind spots, failure classes, and publication/reader gates. They include general examples involving regularity, normalization/Fisher integration laws, gradient-flow domain repairs and standard proof mechanisms. These are additional ambient conceptual cues.
* I have ordinary model familiarity with Gaussian moments, orthogonal invariance, Krylov spaces, Chebyshev/cosine expansions, geometric series, TV and concentration arguments. I cannot certify the absence of training-data familiarity with the source. This record claims a fresh run-level source read, not an impossible claim about all prior model exposure.
* A structural boundary scan of the original HTML printed **section IDs and character offsets** across the whole file. It did not print out-of-scope section titles or prose. The selected source slices themselves contain internal-reference labels and HTML `title` attributes; those are original in-scope markup. In particular, Appendix C.3's heading carries the referenced lemma's identity, and hyperlink titles incidentally expose the paper title and its navigation ancestry. The allowed bibliography entry contains backlinks to other sections/table/remark labels. I saw those raw entry backlinks without following them.
* The raw-source title/name, source theorem numbers, all Section 4 statements, and Appendix C.3's stated purpose became visible through the **authorized original source**. They were not received from a target/implementation packet. The source cognition accordingly records all in-scope results and does not nominate an eventual comparison target.

## Read boundary

The only pre-existing repository files whose semantic content I read were:

1. `AGENTS.md` (current complete 499-line file).
2. `docs/theorem-publication-protocol.md` (complete 231 lines).
3. `docs/proof-digestion-protocol.md` (complete 455 lines).
4. `docs/evidence-routed-memory-protocol.md` (complete 191 lines).
5. `.agents/skills/astis-semantic-roundtrip/SKILL.md` (complete 89 lines).
6. `.astis/huanjian-resume-20261103/2610.20492v1.html`: complete original `S2`, complete original `S4`, complete original `A3.SS3`, and the sole genuinely cited bibliography item `bib.bib3`. Hashing and structural parsing necessarily processed the original file's bytes; semantic source exposure was restricted as stated above.

The first combined process-file print was truncated by the tool output budget. I then read the files in separate bounded calls, including `AGENTS.md` lines 1–260 and 261–499, proof-digestion lines 1–240 and 241–455, and the other complete files. The truncation therefore does not stand in for a complete read.

I authored an extractor using only Python standard-library facilities. It selected exact nested `<section>` boundaries, saved byte-identical raw slices, and made a reading view by retaining ordinary text and using each original MathML element's **original `alttext` LaTeX** once. I read the complete resulting S2, S4 and C.3 views, including all displayed and inline formulas. I also read the exact raw bibliography entry. A second, separately authored mechanical pass indexed every paragraph, equation table, math element, citation and theorem/proof wrapper in the selected sections, with exact source offsets and raw-element hashes; it found no missing math `alttext`. This was another programmatic pass by the same reviewer, not a second human/model review. These are source-derived convenience views, not a received paraphrase, audit or graph.

I did not read a Lean file, theorem/API signature, source graph, prior audit, prior reviewer report, authored lesson, publication metadata, registry, source correspondence, frontier/capsule/ledger, other memory file, or target reconstruction. No such file was opened merely because a process document linked to it. I did not search other local source caches or browse the internet.

Only bibliography `[22]` is cited in the selected sections. Its entry was read; the external document was not. Its title alone supplies no theorem hypotheses or proof evidence. The source's internal references to Theorem 3.1, Appendix C.1, C.2, C.4 and Fact C.6 were not followed. Their contents must remain unavailable/attributed in any later use of this phase's record.

## Scope of the freeze

The freeze covers my original-source cognition, the source-unit inventory, exact source slices, derivation/reading scripts, input hashes, and this exposure record. No canonical file, proof, ledger or publication/audit registry was modified. All artifacts written by this agent are confined to the new Phase 1 directory.

No source-completion/native-source/equivalence verdict is issued. There has been no seven-slot comparison with an exact target or reconstructed theorem. No source repair has been proposed or accepted, and no claim is made that an implementation proves any recorded dependency. Phase 2 must preserve the Phase 1 freeze and record its newly supplied inputs separately.
