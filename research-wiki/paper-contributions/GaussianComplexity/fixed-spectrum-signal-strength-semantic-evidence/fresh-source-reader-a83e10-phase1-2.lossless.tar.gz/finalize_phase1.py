from pathlib import Path
import datetime
import hashlib
import json

ROOT = Path('/Users/zhouhuanjian/ASTIS-GC')
OUT = ROOT / '.astis/semantic-neutral-20261110/src_a83e10'
SOURCE = ROOT / '.astis/huanjian-resume-20261103/2610.20492v1.html'
PIN = '6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def write(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

assert sha(SOURCE) == PIN
raw = json.loads((OUT / 'raw_source_inventory.json').read_text())

# Interpretation labels derive only from the raw source already read.
TOPICS = {
    'preliminaries': 'Real Euclidean/Loewner/Haar conventions, exact oracle, Borel algorithms, TV, and fixed-budget uniform minimax complexity.',
    'hard-family': 'Finite cosine precision grid, random hidden Haar eigenbasis, known spectrum and exact affine oracle comparison.',
    'theorem-scope': 'For each fixed delta, a dimension threshold uniform in kappa and epsilon, with delta/256 sqrt(kappa) log(d) lower bound.',
    'krylov-representation': 'Existence on an extension of mutually independent Gaussian starts representing arbitrary adaptive output; coefficients may depend on the entire experiment.',
    'uniform-krylov-bound': 'A common event of probability at least .99 controls all Krylov vectors when tau <= 1/2; C is absolute and the space is independent of kappa.',
    'target-moment-interface': 'Exact signed means, both variance bounds and conditional two-sided normalized-bias estimate for 1 <= n < d and kappa >= 2.',
    'admissibility': 'Every hidden rotation gives an input in the normalized spectral precision class.',
    'test-definition': 'Polynomial-in-A Borel test, including x=0 without division; its geometric ratio explanation applies only to x != 0.',
    'algorithm-test-probability': 'The query bound implies n < d and small tau uniformly for sufficiently large d, yielding averaged algorithm test probability <= .01.',
    'target-test-probability': 'Moment/bias estimates produce tau <= beta/4 and M beta^2 >= 320, then centered L2 variance and Chebyshev give target probability >= .9 for every hard input.',
    'tv-contradiction': 'Per-input TV inequality, averaged over the hard input, conflicts with the .89 test-probability gap.',
    'method-limit-kappa': 'Asserted full Krylov dimension and high-frequency coordinate weight obstruct uniformly small control once (q+1)^2 >= d.',
    'method-limit-accuracy': 'The source invokes unread Fact C.6 for a >= c/sqrt(d); a < beta and exponential beta upper bound limit this threshold method independently of epsilon.',
    'inverse-spectrum-expansion': 'Absolutely/uniformly theta-convergent infinite cosine expansion using geometric summation and the rho normalization.',
    'finite-grid-aliasing': 'Exact integer cosine-grid identity and disjoint alias classes produce finite-d means with denominator 1+rho^(2d).',
    'gaussian-variance': 'Independent diagonal Gaussian coordinates and fourth moments yield both variances <= 2M <= 2d/sqrt(kappa).',
    'normalized-bias': 'Positivity and exact ratio, log-integral power bounds for kappa >= 2, and the additional d-n >= sqrt(kappa) tail suppression.',
    'bibliography-only': 'Displayed [22] is OpenAI (2026) preprint metadata; its external mathematical content has not been read or certified.'
}

def topic(anchor, ident, text):
    ident = ident or ''
    if anchor == 'S2':
        return 'preliminaries'
    if anchor == 'S4':
        if 'S4.Thmtheorem1.' in ident or ident in ('S4.Ex9', 'S4.p2.1'):
            return 'theorem-scope'
        if ident.startswith('S4.SS1') or ident.startswith('S4.Thmtheorem2') or ident == 'S4.E11':
            return 'hard-family'
        if ident.startswith('S4.Thmtheorem3') or ident.startswith('S4.SS2.SSS0.Px1') or ident in ('S4.Ex10','S4.Ex11'):
            return 'krylov-representation'
        if ident.startswith('S4.Thmtheorem4') or ident.startswith('S4.SS2.SSS0.Px2') or ident in ('S4.Ex12','S4.Ex13','S4.Ex14','S4.Ex15'):
            return 'uniform-krylov-bound'
        if ident.startswith('S4.Thmtheorem5') or ident.startswith('S4.SS2.SSS0.Px3') or ident in ('S4.EGx1','S4.Ex17'):
            return 'target-moment-interface'
        if ident.startswith('S4.Thmtheorem6') or ident.startswith('S4.SS2.SSS0.Px4'):
            return 'admissibility'
        if ident.startswith('S4.SS3.SSS0.Px1') or ident in ('S4.Ex20','S4.Ex21','S4.Ex22'):
            return 'algorithm-test-probability'
        if ident.startswith('S4.SS3.SSS0.Px2') or ident in ('S4.Ex23','S4.Ex24','S4.Ex25','S4.Ex26'):
            return 'target-test-probability'
        if ident.startswith('S4.SS3.SSS0.Px3') or ident == 'S4.Ex27':
            return 'tv-contradiction'
        if ident.startswith('S4.Thmtheorem7') or ident.startswith('S4.SS4.SSS0.Px1') or ident in ('S4.Ex28','S4.Ex29'):
            return 'method-limit-kappa'
        if ident.startswith('S4.Thmtheorem8') or ident.startswith('S4.SS4.SSS0.Px2') or ident == 'S4.Ex30' or ident.startswith('S4.SS4.'):
            return 'method-limit-accuracy'
        if ident.startswith('S4.SS3.') or ident == 'S4.EGx2':
            return 'test-definition'
        return 'hard-family'
    if anchor == 'A3.SS3':
        if ident.startswith('A3.Thmtheorem7') or ident.startswith('A3.SS3.p2.') or ident in ('A3.Ex133','A3.EGx14','A3.Ex136','A3.Ex137'):
            return 'inverse-spectrum-expansion'
        if ident.startswith('A3.SS3.p8.') or ident == 'A3.EGx17':
            return 'gaussian-variance'
        if any(ident.startswith(f'A3.SS3.p{i}.') for i in (9,10,11)) or ident in ('A3.Ex150','A3.Ex151','A3.EGx18','A3.EGx19','A3.Ex157','A3.Ex158','A3.Ex159'):
            return 'normalized-bias'
        return 'finite-grid-aliasing'
    return 'bibliography-only'

coverage = []
for sec in raw['sections']:
    last_topic = None
    for index, unit in enumerate(sec['units'], 1):
        ident = unit['id']
        key = ident if ident else f"{sec['anchor']}:unit-{index:03d}"
        label = topic(sec['anchor'], ident, unit['text'])
        if unit['kind'] == 'citation' and last_topic:
            label = last_topic
        if unit['kind'] == 'heading':
            disposition = 'EXCLUDED'
            why = 'Structural heading; the following substantive statement/proof paragraphs and formulas are separately inventoried.'
        elif unit['text'] == '∎':
            disposition = 'EXCLUDED'
            why = 'Terminal proof symbol only; no substantive content.'
        else:
            disposition = 'NODE'
            why = TOPICS[label]
        coverage.append({'source_key':key, 'section':sec['anchor'], 'ordinal':index,
                         'kind':unit['kind'], 'original_dom_id':ident,
                         'text_sha256':hashlib.sha256(unit['text'].encode()).hexdigest(),
                         'disposition':disposition, 'reason_or_meaning':why,
                         'topic':label, 'mathematical_content':unit['text'],
                         'source_links':unit['links']})
        if unit['kind'] not in ('heading','citation'):
            last_topic = label
coverage.append({'source_key':'bib.bib3','section':'bib.bib3','ordinal':1,'kind':'bibliography-entry',
                 'original_dom_id':'bib.bib3','text_sha256':raw['sections'][-1]['text_sha256'],
                 'disposition':'NODE','reason_or_meaning':TOPICS['bibliography-only'],
                 'topic':'bibliography-only','mathematical_content':(OUT/'bib.bib3.txt').read_text().strip(),
                 'source_links':raw['sections'][-1]['links']})
write('coverage.json', {'schema':1, 'reviewer':'/root/source_reader_a83e10','source_sha256':PIN,
                       'coverage_scope':['FULL S2','FULL S4','FULL A3.SS3','displayed [22] actual DOM bib.bib3'],
                       'method':'Every extracted paragraph/display/citation is NODE unless a sole end-proof marker; structural headings are explicit exclusions. All formulas remain preserved in raw_source_inventory.json.',
                       'units':coverage})

groups=[]
for name, meaning in TOPICS.items():
    groups.append({'id':name,'meaning':meaning,'source_units':[u['source_key'] for u in coverage if u['disposition']=='NODE' and u['topic']==name]})
unread = [
 {'id':'unread-C1','kind':'INTERNAL_SOURCE_PROOF_OUTSIDE_READ_SCOPE','anchor':'A3.SS1','consumer':'S4.Thmtheorem3','status':'unread','meaning':'Deferred proof of Lemma 4.3; source credits [22, Lemma 9.2].'},
 {'id':'unread-C2','kind':'INTERNAL_SOURCE_PROOF_OUTSIDE_READ_SCOPE','anchor':'A3.SS2','consumer':'S4.Thmtheorem4','status':'unread','meaning':'Deferred proof of Lemma 4.4 and the Fact C.6 calculation invoked by the accuracy limitation.'},
 {'id':'unread-C4','kind':'INTERNAL_SOURCE_PROOF_OUTSIDE_READ_SCOPE','anchor':'A3.SS4','consumer':'S4.Thmtheorem6','status':'unread','meaning':'Deferred admissibility proof.'},
 {'id':'external-22','kind':'EXTERNAL_CITED_RESULT','anchor':'bib.bib3','consumer':'S4.SS2.SSS0.Px1.p1.1','status':'bibliography-only','meaning':'External deferred-rotation lemma/construction; no content or pinning certified.'},
 {'id':'dimension-proof-unchecked','kind':'SOURCE_PROOF_BOUNDARY','anchor':'S4.Thmtheorem7','consumer':'S4.SS4.SSS0.Px1.p2.1','status':'no-proof-in-read-S4-slice; elsewhere-unknown','meaning':'Lemma 4.7 dimension formula is asserted in S4; its proof has not been independently reconstructed here.'},
 {'id':'standard-background','kind':'UNNAMED_BACKGROUND_INGREDIENTS','anchor':['A3.SS3.p2.1','A3.SS3.p2.4','A3.SS3.p3.2','A3.SS3.p6.1','A3.SS3.p8.1','A3.SS3.p10.1','S4.SS3.SSS0.Px2.p3.1','S4.SS3.SSS0.Px2.p3.2'], 'status':'source-use-read; no-Lean-or-external-library-certification', 'meaning':'Geometric series, uniform majorant, finite cosine identity/product-to-sum, Gaussian second/fourth moments and coordinate independence, log integral identity, centered L2 triangle inequality and Chebyshev.'}
]

def edge(parents, consumer, use, meaning, discharge):
    return {'parents':parents,'consumer':consumer,'consumer_use_sites':use,
            'logical_kind':'AND' if len(parents)>1 else 'direct-use',
            'meaning':meaning,'conditional_premise_discharge':discharge}

edges = [
edge(['preliminaries'],'hard-family',['S4.SS1.p1.2'],'The hard family uses real precision targets and a Haar eigenbasis independent of the seed.','d>=2,kappa>=2 are the family domain.'),
edge(['external-22'],'hard-family',['S4.p1.1','S4.SS1.p1.1','S4.Thmtheorem2.p1.1'],'External provenance/comparison, not independent certification.','Not discharged by bibliography; outside content unread.'),
edge(['hard-family','external-22','unread-C1'],'krylov-representation',['S4.SS2.SSS0.Px1.p1.1','S4.Thmtheorem3.p1.1'],'Source representation route, including the extra output start.','q integer >=0 and 2q+1<d; C1 proof unread.'),
edge(['hard-family','unread-C2'],'uniform-krylov-bound',['S4.Thmtheorem4.p1.1','S4.Thmtheorem4.p1.2','S4.SS2.SSS0.Px2.p2.1'],'Uniform concentration over all vectors in the polynomial span.','Mutually independent standard Gaussian starts, 2q+1<d and tau<=1/2; C2 proof unread.'),
edge(['hard-family','standard-background'],'inverse-spectrum-expansion',['A3.SS3.p2.1','A3.SS3.p2.2','A3.SS3.p2.3','A3.SS3.p2.4'],'Geometric complex series plus rho algebra and a theta-uniform majorant.','Inherited kappa>=2 implies 0<rho<1; denominator positive.'),
edge(['inverse-spectrum-expansion','hard-family','standard-background'],'finite-grid-aliasing',['A3.SS3.p3.1','A3.SS3.p4.1','A3.SS3.p4.2','A3.SS3.p5.1','A3.SS3.p6.1','A3.SS3.p6.2'],'Expand reciprocal eigenvalues, sum exactly on midpoint grid and sum disjoint alias classes.','Integer d>=2 and 1<=n<d; absolute convergence justifies finite-sum interchange; disjoint aliases use n range.'),
edge(['hard-family','finite-grid-aliasing','standard-background'],'gaussian-variance',['A3.SS3.p8.1','A3.SS3.p8.2'],'Diagonal Gaussian independence and fourth moments, lambda_i>=1, exact M upper bound.','Gaussian moments/independence are source background, not caller-supplied variance hypotheses.'),
edge(['finite-grid-aliasing','hard-family','standard-background'],'normalized-bias',['A3.SS3.p9.1','A3.SS3.p9.2','A3.SS3.p10.1','A3.SS3.p10.2','A3.SS3.p10.3','A3.SS3.p11.1','A3.SS3.p11.2'],'Exact positive ratio plus logarithmic bounds and tail suppression.','kappa>=2 and 1<=n<d; d-n>=sqrt(kappa) only for final two-sided bound.'),
edge(['finite-grid-aliasing','gaussian-variance','normalized-bias'],'target-moment-interface',['A3.SS3.p7.1','A3.SS3.p8.1','A3.SS3.p11.2'],'The separate mean, variance and conditional bias parts form Lemma 4.5.','No additional random-output assumption or finite-query assumption required for target moment identities.'),
edge(['hard-family','unread-C4'],'admissibility',['S4.Thmtheorem6.p1.1'],'All rotations preserve the prescribed spectral bounds.','Every O in O(d); proof is deferred outside scope.'),
edge(['hard-family'],'test-definition',['S4.SS3.p3.1','S4.SS3.p3.2','S4.SS3.p4.1'],'Chebyshev-polynomial test in A equals signed D_n statistic after rotation.','kappa>=2 makes denominator kappa-1 nonzero; x=0 defined without ratio.'),
edge(['theorem-scope','krylov-representation','uniform-krylov-bound','test-definition'],'algorithm-test-probability',['S4.SS3.SSS0.Px1.p1.1','S4.SS3.SSS0.Px1.p1.2','S4.SS3.SSS0.Px1.p1.3'],'The q cap and kappa range make n<d,tau<=1/2, then the common event excludes the test.','For sufficiently large d depending only on delta; joint-law-preserving extension retained; probability averaged over hard input.'),
edge(['theorem-scope','target-moment-interface','test-definition','standard-background'],'target-test-probability',['S4.SS3.SSS0.Px2.p2.1','S4.SS3.SSS0.Px2.p2.2','S4.SS3.SSS0.Px2.p2.3','S4.SS3.SSS0.Px2.p3.1','S4.SS3.SSS0.Px2.p3.2'],'Uniform large-d bias/norm growth yields positive mean and Chebyshev separation for every target in the family.','d-n>=sqrt(kappa),tau<=beta/4,M beta^2>=320 are proved internally from the q/kappa regime, not public premises.'),
edge(['preliminaries','admissibility','algorithm-test-probability','target-test-probability'],'tv-contradiction',['S4.SS3.SSS0.Px3.p1.1','S4.SS3.SSS0.Px3.p1.2'],'One uniform per-input TV guarantee conflicts with the averaged .89 event gap.','epsilon<=.1 and common algorithm/fixed query cap; no expected-cost replacement.'),
edge(['tv-contradiction'],'theorem-scope',['S4.Thmtheorem1.p1.1'],'Rules out algorithms below the stated deterministic cap and gives the Q_G lower bound.','d0(delta) common over allowed kappa and epsilon.'),
edge(['hard-family','dimension-proof-unchecked'],'method-limit-kappa',['S4.SS4.SSS0.Px1.p1.1','S4.SS4.SSS0.Px1.p2.1','S4.SS4.SSS0.Px1.p2.2'],'Full enlarged Krylov space contains a coordinate with high-frequency weight >=1/sqrt(2).','(q+1)^2>=d and n=2q+1<d; scope is this uniform-space proof method.'),
edge(['uniform-krylov-bound','target-moment-interface','unread-C2'],'method-limit-accuracy',['S4.SS4.SSS0.Px2.p1.1','S4.SS4.SSS0.Px2.p1.2','S4.Thmtheorem8.p1.1'],'Bernstein-certified lower scale for a and bias upper decay limit the threshold method to O(sqrt(kappa)log d).','C6 requirement unread; target beta bound used under its stated source domain. No claim ruling out stronger fixed-spectrum lower bounds.')
]
write('source_only_graph.json', {'schema':1,'source_sha256':PIN,'built_before_candidate':True,
                               'semantics':'Source-derived bounded dependency account; never a Lean graph or a formal implication certificate.',
                               'nodes':groups,'unread_or_unexpanded_inputs':unread,'edges':edges,
                               'alternative_routes':[],
                               'alternative_route_note':'The read S4 proof supplies one sufficient route with separate conjunctive algorithm/target/admissibility branches. No alternative sufficient proof is asserted.',
                               'source_gap_claim':'No proved false source assertion or accepted repair is claimed. Unread deferred proofs, asserted dimension proof boundary and unnamed background ingredients remain explicit; no whole-paper root closure.'})

protocols = [
 'AGENTS.md','docs/contributor-codex-contract.md','docs/formalization-protocol.md',
 'docs/theorem-publication-protocol.md','docs/proof-digestion-protocol.md',
 'docs/evidence-routed-memory-protocol.md',
 '.agents/skills/astis-semantic-roundtrip/SKILL.md',
 '.agents/skills/astis-source-dependency-audit/SKILL.md',
 '.agents/skills/astis-substantive-advance/SKILL.md'
]
write('read_provenance.json', {
 'reviewer':'/root/source_reader_a83e10', 'phase':'first raw-source cognition only',
 'raw_source':{'path':str(SOURCE.relative_to(ROOT)),'sha256':PIN,'title':'On Complexity of Gaussian Sampling'},
 'fully_read_dom_subtrees':['S2','S4','A3.SS3','bib.bib3'],
 'source_extraction':'BeautifulSoup with installed /opt/anaconda3/bin/python, using MathML alttext TeX without duplicate rendered annotations.',
 'protocols_read':[{'path':p,'sha256':sha(ROOT/p)} for p in protocols],
 'incidental_exposure':{'zero_exposure_claim':False,'kind':'older contributor-log filenames and source section outline only',
  'full_disclosure':'phase1_source_cognition.md: Exposure and reading limits',
  'candidate_signature_seen':False,'candidate_content_seen':False,'prior_verdict_content_seen':False,
  'target_identity_inference':'Not attempted; cannot know whether an older label matches an as-yet-unsupplied target.',
  'parent_notified':True,'parent_directed_continuation':True},
 'not_read':['candidate signature/title/statement','candidate Lean module or proof','candidate lesson/exposition','candidate source graph','canonical audit/semantic slots','frontier state','anonymous reconstruction','prior reviewer verdict content','external cited-paper contents','full Appendix C.1/C.2/C.4','full S1/S3/other appendix content'],
 'actions_not_taken':['proof search','Lean/API retrieval','compilation','candidate verification','native app/browser work','canonical ledger/state mutation','production edit','astis sibling scan'],
 'write_scope':str(OUT.relative_to(ROOT)),
 'judgments_not_made':['candidate source equivalence','candidate implementation acceptance','exposition acceptance','repair acceptance','whole-paper completeness']
})

assert len(coverage) == sum(len(s['units']) for s in raw['sections']) + 1
assert len({u['source_key'] for u in coverage}) == len(coverage)
assert all(u['disposition'] in ('NODE','EXCLUDED') for u in coverage)
assert all(u['reason_or_meaning'] for u in coverage)
counts={a:{d:sum(u['section']==a and u['disposition']==d for u in coverage) for d in ('NODE','EXCLUDED')} for a in ('S2','S4','A3.SS3','bib.bib3')}
write('coverage_checks.json', {'coverage_unit_count':len(coverage),'counts':counts,
 'all_raw_units_dispositioned':True,'all_keys_unique':True,'all_dispositions_have_meaning_or_reason':True,
 'scope_only':'Checks verify extraction/coverage shape, not mathematical truth, independence or source equivalence.'})

files=sorted(p for p in OUT.iterdir() if p.is_file() and p.name not in ('phase1.freeze.json','phase1.freeze.sha256'))
manifest={'schema':1,'phase':'phase1-raw-source-cognition-frozen','reviewer':'/root/source_reader_a83e10',
 'frozen_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'candidate_projection_received_before_freeze':False,
 'source_sha256':PIN,'root':str(OUT),'incidental_filename_exposure_disclosed':True,
 'freeze_semantics':'These exact bytes remain unchanged in any later phase. Later candidate judgments are separate artifacts, not amendments to raw cognition.',
 'files':[{'path':p.name,'bytes':p.stat().st_size,'sha256':sha(p)} for p in files],
 'coverage_counts':counts,'canonical_or_production_mutation':False,
 'verdict_scope':'Independent source cognition only; no candidate verdict or whole-paper certification.'}
write('phase1.freeze.json',manifest)
digest=sha(OUT/'phase1.freeze.json')
(OUT/'phase1.freeze.sha256').write_text(digest+'  phase1.freeze.json\n')
for path in OUT.iterdir():
    if path.is_file():
        path.chmod(0o444)
print(json.dumps({'freeze_path':str(OUT/'phase1.freeze.json'),'freeze_sha256':digest,'coverage_counts':counts,'files':len(files)+2},indent=2))
