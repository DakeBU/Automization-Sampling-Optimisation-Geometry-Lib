from pathlib import Path
import re,json,hashlib,subprocess
R=Path.cwd(); W=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
P=Path('AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumDetector.lean'); C=Path('Tests/GaussianComplexityFixedSpectrumDetector.lean')
MAP=Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-detector-semantic-evidence/source-to-lean-map-v1.json')
m=json.loads(MAP.read_bytes()); assert len(m['rows'])==27
ends={'P-type':' := by','P-family':'  let Φ','P-conjugation':'  have hD','P-normalize':'  have hdiag','P-polynomial':'\nend AutoSamplingTheory','C-type':' := by','C-objects':'  have hT','C-call':'  have hR','C-R-meas':'  have hSc','C-continuity':'  have hEvent','C-event':'  have hO','C-inverse':'  have hnorm','C-norm':'  have hquad','C-quad':'  have hstat','C-S':'  change MeasurableSet','C-map':'\nend AutoSamplingTheory'}
rows=[]
for row in m['rows']:
 z=row['lean']; p=Path(z['file']); b=p.read_bytes(); t=b.decode(); start=z['exact_start_marker']
 scope=0 if row['role'] in ['public-root','private-root','canonical-Mathlib-substrate'] else t.index(' := by')+len(' := by')
 assert t.count(start,scope)==1,(row['id'],'ambiguous marker')
 a=t.index(start,scope); end=ends.get(row['id'],'\n\n'); e=t.index(end,a+len(start)); code=t[a:e]
 assert sha(b)==z['file_sha256'],(row['id'],'file bytes')
 assert t[:a].count('\n')+1==z['line'] and t[:e].count('\n')+1==z['end_line'],(row['id'],'line span')
 assert sha(code.encode())==z['exact_locator_block_sha256'],(row['id'],'exact substring')
 rows.append({'id':row['id'],'file':str(p),'file_size':len(b),'file_sha256':sha(b),'line':z['line'],'end_line':z['end_line'],'exact_locator_substring_sha256':sha(code.encode()),'locator_byte_length':len(code.encode()),'pass':True})
regex=re.compile(r"\bsorry\b|\badmit\b|^\s*(?:@\[[^\]]*\]\s*)*(?:(?:private|protected|noncomputable|local|unsafe|partial)\s+)*(?:axiom|constant|postulate)\b|Prop\s*:=\s*True|:=\s*trivial",re.MULTILINE)
scans=[]
for p,expected,name in [(P,False,'actual_chebyshev_matrix_cosine'),(C,True,'actual_rotated_gaussian_detector_event')]:
 t=p.read_text(); matches=[(t[:x.start()].count('\n')+1,x.group()) for x in regex.finditer(t)]
 assert not matches,(str(p),matches)
 decls=re.findall(r'^((?:private )?)(theorem|lemma|def|instance|structure|class|inductive)\s+(\S+)',t,re.MULTILINE)
 assert decls==[('private ' if expected else '', 'theorem',name)],decls
 assert len(p.read_bytes())==(6044 if expected else 4540)
 assert subprocess.check_output(['git','show','65776f88e92b9680e6afe0d4c20b7390e4521241:'+str(p)])==p.read_bytes()
 scans.append({'file':str(p),'raw_size':len(p.read_bytes()),'raw_sha256':sha(p.read_bytes()),'fake_closure_matches':matches,'handwritten_inventory':decls})
r={'scope':'Exact whole-module source text, 27 precise substring locators and focused fake-closure scan; no source semantic verdict or global gate.','locator_convention':'Exact start-marker through the beginning of explicit end-marker (or next blank line for Mathlib); end_line is a position, not an inclusive whole-line hash range.','rows':rows,'source_scans':scans}
(W/'input-locator-scan-results.json').write_text(json.dumps(r,indent=2,ensure_ascii=False)+'\n');print(json.dumps(r,indent=2,ensure_ascii=False))
