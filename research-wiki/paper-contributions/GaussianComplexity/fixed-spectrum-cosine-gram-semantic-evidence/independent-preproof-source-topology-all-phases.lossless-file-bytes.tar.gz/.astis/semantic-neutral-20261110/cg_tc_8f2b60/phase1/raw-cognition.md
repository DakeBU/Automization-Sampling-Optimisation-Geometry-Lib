# Independent raw-source cognition: cosine-frame topology challenger

Stage: source-only cognition freeze, before exact sealed types/minimal definitions and before the author's Source Proof Graph. This is a different-role adversarial source reading, not a Lean proof, semantic verdict, source-V review, or approval of any implementation. The root remains the mathematical prover. No author graph or implementation has been consulted.

Pinned input: `.astis/huanjian-resume-20261103/2610.20492v1.html`, 951991 bytes, SHA256 `6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915`. Exact byte intervals and HTML fragment hashes are in `source-spans-complete.json`; the entire C.2 fragment is `A3.SS2.html`. Text snapshots replace each MathML node with its source `alttext`, preserving formulas instead of counting presentation/annotation duplicates as separate mathematics.

## Objects and source boundary

S4.SS1, Eq. (11), gives the standing hard-family convention: integer dimension `d ≥ 2`, `κ ≥ 2`, one-based `1 ≤ i ≤ d`, `θ_i=((i-1/2)π)/d`, `λ_i=(κ+1)/2+((κ-1)/2)cos θ_i`, and `Λ=diag(λ_i)`. The grid consists of midpoints, so neither endpoint 0 nor π is a node. The orthogonal rotation, target law and algorithm context in that section do not enter the deterministic cosine identities.

The query budget is an integer `q ≥ 0` (explicit in Lemma 4.3 and implicit in Lemma 4.4's query-budget context). S4.SS2.SSS0.Px2 defines `n=2q+1` and `D_n=diag(cos(nθ_i))`; Lemma 4.4 assumes `2q+1<d`. Thus `n` is positive and is derived, not an unconstrained independent parameter. C.2 p1 sets `r=q+1`, and p5 explicitly indexes cosine coordinates by `0,…,q`. A zero-based implementation row index `i₀=0,…,d-1` must therefore use `θ=(i₀+1/2)π/d`; its frequency index remains `j=0,…,q`.

The source literals are

`t_i=(1, √2 cos θ_i, …, √2 cos(qθ_i))ᵀ ∈ R^r`,
`γ_i=((g_1)_i,…,(g_r)_i)ᵀ ∈ R^r`,
`B_i=d^(-1/2)(γ_i ⊗ t_i)ᵀ`, with `B ∈ R^(d × r²)`.

The constant coordinate is exactly 1. Writing `√2 cos(jθ_i)` for every `j` gives the wrong constant normalization. The tensor order is `γ_i ⊗ t_i`, so a natural coefficient index is the pair `(a,j)` with Gaussian index first. Reordering these pairs requires an explicit equivalence; merely matching the cardinality `r²` is insufficient to audit a literal definition.

The current bounded deterministic slice comprises three conclusions from Fact C.5/Ex87: `Σ_i t_i t_iᵀ=d I_r`, `Σ_i cos(nθ_i)t_i t_iᵀ=0`, and `‖t_i‖²≤2r`. The source's two Gaussian expectation identities are real downstream consumers, with their actual law and integrability obligations retained. They must not be presented as deterministic pointwise identities for `B`. The source's `range(B)=K_q`, Fact C.6 concentration, and complete Lemma 4.4 are explicitly excluded from closure by this packet. Fact C.5 as a whole therefore cannot receive a completion claim from these three conclusions alone.

## Source-only reconstruction of proof dependencies

1. C.2 p4, lines 3377–3396, is the common trigonometric leaf. For an integer frequency `k` with `0<|k|<2d`, the sine-difference telescoping display Ex88–89 shows `2 sin(kπ/(2d)) Σ_i cos(kθ_i)=sin(kπ)-sin0=0`. The paragraph separately discharges the nonzero sine factor. The zero-frequency sum is `d`, not zero. The restriction excludes the discrete alias boundary `2d`; an unbounded “all nonzero frequencies vanish” helper would change the mathematics.

2. C.2 p5, lines 3397–3432, proves the unweighted frame Gram entrywise. Ex90 treats `(0,0)` and `(0,j)` separately. Ex91–93 treat positive `j,k` with product-to-sum at `j-k` and `j+k`; equality `j=k` creates exactly the zero-frequency contribution `d`. The following prose checks `0<j+k≤2q<2d`, handles nonzero `j-k`, and invokes symmetry to cover transposed entries. These frequency and symmetry sentences are substantive proof regions, not expendable explanation.

3. C.2 p7, lines 3450–3496, independently proves the weighted frame Gram, reusing the cosine-sum leaf. Ex96 bounds all four signed frequencies: `1≤n-j-k≤n±j±k≤n+j+k≤4q+1<2d`. Ex97–99 expand the triple cosine with coefficient `1/4`, producing the four frequencies `n+j+k`, `n+j-k`, `n-j+k`, `n-j-k`. Every entry of the weighted outer-product sum is a constant multiple of this triple sum, including entries involving coordinate zero by `cos0=1`. Thus no cross term may be discarded merely because two indices differ. This argument uses both lower and upper frequency bounds; “n exceeds 2q” alone does not discharge aliasing.

4. C.2 p8, lines 3497–3507, gives the separate norm leaf Ex102: `‖t_i‖²=1+2Σ_(j=1)^q cos²(jθ_i)≤1+2q≤2r`. It is a bound on `t_i`, not on the unnormalized tensor row or on `B_i`. A bound for `B_i` also contains `‖γ_i‖²/d`. This leaf does not require the Gram conclusions as assumptions.

5. C.2 p6, lines 3433–3449, consumes the unweighted frame Gram and the Gaussian second moment `E[γ_iγ_iᵀ]=I_r` to get Ex94–95: `E[BᵀB]=(1/d)Σ_i(E[γ_iγ_iᵀ]⊗t_it_iᵀ)=I_(r²)`. The second half of p7 consumes the weighted frame Gram and the same second moment to get Ex100–101, `E[BᵀD_nB]=0`. These are separate consumers. At coefficient pair indices `(a,j),(b,k)`, the relevant integrand is `(1/d)Σ_i γ_(i,a)γ_(i,b)t_(i,j)t_(i,k)` with the extra `cos(nθ_i)` only for the weighted version. There are no cross-row products in `BᵀB`; independence across rows is not needed for these expectation sums, though it is used later by concentration. Off-diagonal Gaussian-coordinate second moments do need justification.

6. C.2 p1 asserts that the `γ_i` formed from independent `g_a∼N(0,I_d)` are independent `N(0,I_r)`. An actual-law private consumer should derive its coordinate second moments, measurability and integrability from this law/original product Gaussian construction. Replacing the law by a public premise consisting of the desired moments is a generalization or proof interface, not completion of this source obligation. Matrix expectation must have a specified meaning; finite-dimensional entrywise expectation is compatible with a Bochner expectation only after the required integrability bridge is supplied. Quadratic Gaussian-coordinate functions have the relevant second-moment ingredient; it belongs inside the proof dependency chain, not in new source-facing binders.

7. The excluded range proof, C.2 p3, depends on the nonconstant affine map from `cosθ_i` to `λ_i`, the Chebyshev identity with nonzero leading coefficient, triangular invertibility for every starting vector, and nonzero column normalizations. Standing `κ≥2` supplies nonconstancy. This is not a consequence of the deterministic frame Gram or expectation identities. Conversely, the three deterministic conclusions do not depend on the range proof.

## Consumer and exclusion topology

The strategy paragraph p2 explains the two uses of `B`: `u=Bc`, norm through `BᵀB`, and quadratic statistic through `BᵀD_nB`. It is retained as a consumer-boundary node rather than silently dropped. The p9 transition, Fact C.6 and p10–p18 are outside this packet's closure. Their exact sources were read to identify the real use sites:

- p12/Ex110 consumes the two deterministic frame sums after an additional radial-symmetry argument produces the same scalar `a` for all row laws. Weighted cancellation alone does not prove a truncated weighted expectation vanishes when row factors vary with `i`.
- p13/Ex111 consumes `‖t_i‖²≤2r` for summand norm bounds, together with truncation and tensor/operator-norm facts.
- p14/Ex115–117 consumes the row bound and unweighted frame Gram, together with fourth Gaussian moments and positive-semidefinite comparisons, to bound variance. These additional facts are outside the deterministic result.
- p19, the final Lemma 4.4 proof, needs the range result to choose `u=Bc`, both concentration bounds on one common event, and `τ≤1/2`. It then loses probability from `0.995` to the lemma's `0.99`. No expectation identity alone gives the uniform event or this conclusion.

There is one source route for the current deterministic conclusions; no source OR-alternative is claimed. They share the trigonometric leaf, but bundling their targets must not create a false dependency cycle or make the weighted conclusion depend on the unweighted Gram without a real source use. Source p6 and p7 moment consumers also remain separate from the deterministic provider's public interface.

## Adversarial checks reserved for exact-type/definition audit

- Check zero-based row indexing, one-based source indexing, midpoint half shift, real coercions and parentheses in `((i+1/2)π)/d`.
- Check `r=q+1`, `n=2q+1`, `t` coordinate count `q+1`, tensor coefficient dimension `(q+1)²`, and matrix identity dimension. Do not confuse `r²` with `d`.
- Preserve `q=0`. The positive-coordinate product cases are then empty, the constant coordinate remains, and the weighted `(0,0)` case still needs the positive frequency `n=1`. A `q>0` binder would exclude source input. The boundary `n<d` is strict in the source; no relaxation is asserted here.
- Preserve the `sqrt 2` normalization only for nonconstant modes and the `d^(-1/2)` normalization only when passing to `B`. Distinguish raw sum `dI` from normalized Gram `I`.
- Recursively unfold every meaningful alias and any bundled predicates. Orthogonality, weighted cancellation, row norms, Gaussian moments, integrability, concentration, or existence of `c` may not be silently installed as public source hypotheses.
- For weighted cancellation, require the four-frequency expansion and both no-zero/no-alias bounds to be represented, including zero coordinate cases. For the unweighted Gram, require all constant and mixed cases, the diagonal `j=k` zero-frequency case, and symmetry.
- For an actual Gaussian private consumer, require the law and its coordinate projection/transpose relation to the source `g_a` construction, expectation indexing, finite-sum interchange, second moments and integrability. An arbitrary measure with assumed target moments is not evidence that this source consumer was implemented.
- Do not import concentration estimates, a good-event premise, or a precomputed deterministic Gram as a new public assumption. A producer theorem must be called inside the proof; its existence does not legitimize a theorem-shaped assumption.
- Do not award Range/Krylov, Fact C.6, full Fact C.5 or full Lemma 4.4 credit to this slice. Exact types and author graph remain unseen, so no accept/reject verdict on them exists at this freeze.

## Read/exposure integrity

Read inputs were restricted to the exact pinned raw source, five explicitly permitted procedural files and this agent's own newly created artifacts. AGENTS contains unrelated procedural handoff text; that text was allowed but was not used as mathematical or implementation evidence. No repository search, website graph/index/ledger/ATLAS read, Lean/API/native/proof execution, source-V tool, author seal/type/SG packet or current/old semantic verdict was used. HTML parsing processed the fixed file, while the human-visible raw reading was bounded to the listed source excerpts and direct-child inventories. The section-4 preamble and neighboring source context seen by inventory are recorded as context exclusions, not hidden exposure.

The first combined tool output was truncated at the outer orchestrator. It is explicitly recorded in `initial-exposure.json`; all five procedures were then read in bounded complete calls from byte-exact snapshots. No later raw-reading output was truncated. This is an output-transport issue, not mathematical negative evidence. No mathematical failure, counterexample, Lean failure or closure claim is recorded.

Freeze condition: this cognition and the independent coverage map must be hashed and made read-only before receiving exact sealed types/minimal definitions. After a distinct type/definition-audit freeze, the author graph may be received for structural challenge. This file is not to be revised in place after those exposures.
