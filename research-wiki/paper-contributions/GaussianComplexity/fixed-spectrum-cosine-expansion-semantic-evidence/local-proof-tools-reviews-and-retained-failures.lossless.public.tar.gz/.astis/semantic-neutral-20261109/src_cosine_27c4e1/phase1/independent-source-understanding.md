# Phase 1: independently formed raw-source understanding

This is a frozen source-reading baseline, not a candidate comparison, Lean review,
source-fidelity verdict, source repair, proof result, or publication admission.
The only mathematical document used was the fixed local HTML of *On Complexity
of Gaussian Sampling*, arXiv:2610.20492v1, 951991 bytes, SHA-256
`6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915`.
Every source anchor below resolves to an exact UTF-8 byte span and raw-element
hash in `raw-source-regions.json`. The prose below was formed before receiving
any candidate/reconstruction/module text.

## Independence and cues

The assignment disclosed the topic “GaussianComplexity”, the role/path token
`cosine_27c4e1`, Fact C.7, Fact C.8, Ex133–137, Ex140/p4.2, the finite-grid use,
the need to distinguish assumptions from produced ingredients, convergence,
indexing/normalization, and the Gaussian-expectation boundary. These are real
topic/attention cues. I do not claim zero cues. The root later clarified that
“4.5” meant **Lemma 4.5** (`S4.Thmtheorem5`), consistent with my raw-source
location; there is no §4.5 in this HTML. No mathematical candidate, seal,
reconstruction, previous verdict, source graph, lesson, control-plane ledger,
Lean/Mathlib interface or proof was consulted. The six required process files
were read; their mathematical examples were not treated as evidence for C.7.

## Scope and definitions recovered from the source

At `S4.SS1` / `S4.E11`, the hard family has integer dimension d≥2 and κ≥2,
with i=1,…,d:

\[
\theta_i=(i-\tfrac12)\pi/d,\quad
\lambda_i=(\kappa+1)/2+(\kappa-1)\cos\theta_i/2,\quad
\Lambda=\operatorname{diag}(\lambda_1,\ldots,\lambda_d).
\]

The rotation O is Haar orthogonal and independent of algorithmic randomness;
A=OΛOᵀ, f_A(x)=xᵀAx/2, π_A=N(0,A⁻¹). The spectrum is deterministic and known;
the eigenbasis is hidden. These probability/oracle facts motivate this slice
but are not hypotheses needed for the scalar C.7 expansion.

At `S4.Thmtheorem5`, Lemma 4.5 explicitly defines

\[
\rho=\varrho_\kappa=(\sqrt\kappa-1)/(\sqrt\kappa+1),\quad
U\sim N(0,\Lambda^{-1}),\quad
D_n=\operatorname{diag}(\cos(n\theta_i)),
\]
\[
M=\mathbb E\|U\|^2,\qquad
\mu_n=\mathbb E[U^\top D_nU],\qquad n\in\mathbb Z,\;1\le n<d.
\]

C.3 recalls the grid and announces the sequence: expand inverse spectrum,
sum over the grid, then bound variances and normalized cosine bias
(`A3.SS3.p1`). C.7's short statement does not rebind κ or redefine ρ. Its
intended source context is the κ≥2 / ρ definition above. One should not turn
the omission into an unrestricted-κ claim. A possible broader valid parameter
range is outside this faithful baseline.

## Exact content of C.7, including the three convergence obligations

Let λ(θ)=(κ+1+(κ−1)cosθ)/2. C.7 (`A3.Thmtheorem7`, `A3.Ex133`) states,
for **every real θ**,

\[
F_\kappa(\theta):=1/\lambda(\theta)
=\frac2{\kappa+1+(\kappa-1)\cos\theta}
=\frac1{\sqrt\kappa}\left(1+2\sum_{j=1}^\infty
(-\rho)^j\cos(j\theta)\right).
\]

It explicitly adds absolute and uniform convergence. The source does not
number three separate convergence clauses; the following separates the exact
sum identity from its two stated convergence properties, so none is lost.
Set a_j(θ)=(-ρ)^j cos(jθ), T_N(θ)=Σ_{j=1}^N a_j(θ), and
R_N(θ)=(1+2T_N(θ))/√κ.

1. **Convergence to the stated value, not just existence of a sum.** For each
   fixed allowed κ and every θ∈ℝ, T_N(θ) tends to
   \(\sqrt\kappa/[\kappa+1+(\kappa-1)\cos\theta]-1/2\), equivalently
   R_N(θ)→F_κ(θ). The quantifiers are ∀θ ∀ε>0 ∃N ∀m≥N for pointwise
   convergence; the next uniform statement strengthens the N scope.
2. **Absolute convergence at every θ.** For each such κ and θ,
   Σ_{j=1}^∞ |a_j(θ)| is finite and at most ρ/(1−ρ) (`A3.Ex137`). An
   absolute-convergence statement alone would not identify the sum value.
3. **Uniform convergence on the whole real axis for fixed κ.** For every
   ε>0 there exists N=N(κ,ε), independent of θ, such that for all m≥N and
   all θ∈ℝ, |R_m(θ)−F_κ(θ)|<ε. Equivalently, T_N converges uniformly
   to the unscaled sum above. The source's domain is ℝ, not only the grid
   or a fixed compact interval. It makes no uniform-in-κ claim.

The geometric majorant underlying Ex137 gives the needed **tail** control:
Σ_{j>N}|a_j(θ)|≤ρ^{N+1}/(1−ρ), independent of θ; hence
|R_N(θ)−F_κ(θ)|≤2ρ^{N+1}/(√κ(1−ρ)). This is an explicit background
expansion of the source's final inference, not an additional source hypothesis.
The single total bound in Ex137 should be understood through this summable
majorant/tail argument when justifying uniform convergence.

Indexing matters: j starts at 1. The constant 1 and outer factor 2 are separate.
A zero-based reindexing must use a_{m+1}, or write
F_κ=(2Σ_{j=0}^∞(-ρ)^j cos(jθ)−1)/√κ. Simply starting the displayed sum
at zero while retaining “1+2Σ” changes the value. A range of N zero-based
terms corresponds to j=1,…,N, so its first omitted exponent is N+1.

## Assumptions and ingredients must not be interchanged

| Item | Source role in this slice |
|---|---|
| κ≥2 and ρ=(√κ−1)/(√κ+1) | Inherited source parameter and literal definition for C.7. |
| θ∈ℝ | Universally quantified argument in C.7. |
| d≥2, grid i=1,…,d | Standing hard-family context needed when C.7 is consumed by C.8; C.7 itself is scalar and does not depend on d. |
| Integer 1≤n<d | C.8 / Lemma 4.5 moment range; not a premise of C.7. |
| U∼N(0,Λ⁻¹), definitions of M, μ_n | Source inputs/definitions of Lemma 4.5; not inputs of the scalar C.7. |
| √κ>1, 0<ρ<1 | Produced from the source parameter/definition, used at the start of C.7's proof. |
| Nonzero denominators, geometric-series convergence, Ex136 identities, the geometric majorant | Produced analytical/algebraic ingredients; not extra public hypotheses. |
| E U_i²=1/λ_i, integrability of the finitely many squares | Gaussian second-moment bridge to be discharged from U's source law when interpreting Ex140 as expectations. |
| Exact finite-grid cosine sum, product-to-sum identity | Additional deterministic ingredients of C.8, not conclusions of C.7 alone. |

For example λ(θ)≥1 follows from κ≥2 and |cosθ|≤1; it need not be an
extra premise. Similarly |ρe^{±iθ}|=ρ<1 provides both complex geometric
series' convergence and their nonzero denominators.

## Complete C.7 source proof, recovered without implementation

The proof is the entire `A3.SS3.2` element, with no omitted substantive
paragraph between the theorem and C.8:

- `A3.SS3.p2.1` / `A3.Ex134`: use 0<ρ<1 and the geometric series for
  −ρe^{iθ} and −ρe^{−iθ}; Euler's cosine identity combines them as
  \(1-\rho e^{i\theta}/(1+\rho e^{i\theta})
  -\rho e^{-i\theta}/(1+\rho e^{-i\theta})\).
- `A3.Ex135`: combine these fractions to
  \((1-\rho^2)/(1+2\rho\cos\theta+\rho^2)\).
- `A3.SS3.p2.2` / `A3.Ex136`: substitute the ρ definition to obtain
  \((1-\rho)/(1+\rho)=1/\sqrt\kappa\) and
  \((1+2\rho\cos\theta+\rho^2)/(1-\rho)^2=\lambda(\theta)\).
  These give the exact inverse-spectrum normalization in Ex133.
- `A3.SS3.p2.3`, `A3.Ex137`, `A3.SS3.p2.4`: use |cos(jθ)|≤1 and
  Σ_{j≥1}ρ^j=ρ/(1−ρ), with its vanishing uniform tail, for absolute and
  uniform convergence.

Necessary ordinary background comprises real square-root/order algebra,
Euler's identity, the norm of e^{iθ}, convergent complex geometric series,
addition/scalar multiplication of convergent series, and the summable-majorant
criterion. There is no external citation inside this C.7 proof. This list is
not an API search or a proposed implementation route.

## Actual C.8 use, including its normalization

The direct consumer is `A3.SS3.p4.2`, after Ex140, within C.8's proof
(`A3.SS3.3`). Its explicit statement is that C.7 permits interchange of the
absolutely convergent series and the **finite** grid sum. At the grid nodes,
F_κ(θ_i)=1/λ_i exactly. There is no 1/d average and no integration over θ.

Write C_k=Σ_{i=1}^d cos(kθ_i). `A3.Ex139` states for **every integer k**:
C_{2ad}=d(−1)^a for a∈ℤ, and C_k=0 otherwise. The source proves this
using the finite cosine-sum formula in the nonalias case and direct evaluation
in the alias case (`A3.SS3.p3.2`). In particular C_0=d.

Before alias selection, the finite-sum interchange yields

\[
M=\frac1{\sqrt\kappa}\left(d+2\sum_{j\ge1}(-\rho)^jC_j\right),
\]
\[
\mu_n=\frac1{\sqrt\kappa}C_n+
\frac1{\sqrt\kappa}\sum_{j\ge1}(-\rho)^j(C_{j-n}+C_{j+n}).
\]

For 1≤n<d, C_n=0. The factor 2 in C.7 cancels the 1/2 in
cos(nθ)cos(jθ)=[cos((j−n)θ)+cos((j+n)θ)]/2, giving exactly the
coefficient of `A3.Ex144`. Weighting by the bounded cos(nθ_i) also preserves
absolute convergence at each of the finitely many nodes. Finite sums and
limits commute; this consumer does not need a Gaussian-space infinite-series
interchange, or a new domination/integrability premise. Uniform convergence
in θ is a stronger C.7 conclusion than this finite-grid exchange requires.

The rest of C.8 is separate source work:

- For M, j=2ad with a≥1 survive. Ex141–143 sum the alternating geometric
  progression and give
  \(M=(d/\sqrt\kappa)(1-\rho^{2d})/(1+\rho^{2d})\).
- For μ_n, the surviving indices are j=n, j=2ad+n (a≥1), and
  j=2ad−n (a≥1). Their disjointness and positive indices use 1≤n<d.
  `A3.SS3.p6.2` preserves the alias signs d(−1)^a and the identity
  (−ρ)^{2ad±n}=(−1)^nρ^{2ad±n}. Ex145–147 give
  \((-1)^n\mu_n=(d/\sqrt\kappa)(\rho^n-\rho^{2d-n})/(1+\rho^{2d})\).

Thus the finite-dimension correction terms ρ^{2d}, ρ^{2d−n} and the sign
(−1)^n belong to the actual source result. Infinite-grid/integral or
asymptotic approximations would lose this exact content. The C.8 range excludes
n=0 and n=d; C.7 has no such exclusions on θ.

## Gaussian identification and remaining boundaries

Ex140's names are already probabilistic in Lemma 4.5. The source's short
“Since E U_i²=1/λ_i” in `A3.SS3.p4.1` expands as follows: the centered
Gaussian with diagonal covariance Λ⁻¹ has finite second moments
E U_i²=1/λ_i; ||U||²=Σ_i U_i² and UᵀD_nU=Σ_i cos(nθ_i)U_i²;
linearity of expectation over a finite sum gives the two deterministic sums
in Ex140. The λ_i are positive. Independence is not needed just for these
two means, but is used in the later variance proof. A bare deterministic
grid identity does not by itself establish this Gaussian identification.

`S4.SS2.SSS0.Px3.p2` supplies the rotation-to-target adapter: for an exact
target sample Y conditional on O, U=OᵀY has law N(0,Λ⁻¹), preserves squared
norm, and transforms YᵀOD_nOᵀY to UᵀD_nU. This is another genuine bridge,
not a conclusion of C.7.

The adjacent source proof `A3.SS3.4` uses C.8 for the two means, then separately
proves fourth-moment/independence variance bounds, positivity of (−1)^nμ_n,
the exact normalized ratio, logarithmic estimates for ρ, and the conditional
lower bias estimate when d−n≥√κ. These are not supplied merely by C.7.
The main-text direct downstream consumer `S4.SS3.SSS0.Px2` uses **all of
Lemma 4.5**, including variance and bias, to show target samples pass a test
with probability at least 0.9. It introduces β=|μ_n|/M, uses large-d and
parameter-range estimates, and applies Chebyshev's inequality. C.7 alone
does not prove target concentration, the algorithmic Krylov bound, TV
separation, or Theorem 4.1's query lower bound.

The separate roles remain: the scalar expansion, deterministic finite-grid
evaluation, Gaussian expectation identification, rotation adapter, variance
and bias estimates, and the final probabilistic test. This baseline records
their source meaning and boundaries; it certifies none as implemented.

## Coverage limit

I read all of C.3, the complete C.7 proof and C.8 proof, §4.1, Lemma 4.5,
the D_n/n definition, its target rotation paragraph, and the downstream
target-sample proof subsection. The S4 heading/ID inventory exposed brief
snippets of other S4 material, and an A3.Ex13* inventory exposed Ex130–132
at the preceding C.2 boundary; those were not used to infer C.7/C.8 content.
Other paper results, external reference [22], all existing project source
graphs and all implementation artifacts were outside this phase. No general
framework or whole-paper dependency graph was built. Phase 1 now stops at
this source-only baseline, pending a separately authorized selective Phase 2.
