from pathlib import Path
import hashlib,json,datetime,shutil
ROOT=Path('/Users/zhouhuanjian/ASTIS-GC');BASE=ROOT/'.astis/semantic-neutral-20261112/mp_sg_52ad';OUT=BASE/'type-freeze-v1';PACKET=ROOT/'.astis/huanjian-real-matrix-positive-integral-20261112/selective-type-definition-packet.json'
def sha(b):return hashlib.sha256(b).hexdigest()
assert not OUT.exists()
pb=PACKET.read_bytes();assert sha(pb)=='d2d9493c6fd09222fbe183fcb296bd0c104328a462a03f28b7c9930caa9b9e95';p=json.loads(pb)
for k in ['producer','actual_consumer']:assert sha(p[k]['signature'].encode())==p[k]['signature_sha256']
c=p['minimal_definition_context'];assert sha(c['literal_current_prints_and_instances'].encode())==c['literal_current_prints_sha256']
for x in c['literal_definition_excerpts']:assert sha(x['literal_source'].encode())==x['literal_source_sha256']
assert p['statement_seal_sha256']=='a5179ed392ef8e55ab470a3a98ebd542e35301f51472e9cdd7bc168a88bafa26'
assert p['actual_consumer']['signature_sha256']=='d5ac54443c79ea7b35b09ddcd6b5e3c40bef081bbe4f196cae5ab3ead35aa2ea'
OUT.mkdir();(OUT/'inputs').mkdir()
def dump(n,v):(OUT/n).write_text(json.dumps(v,ensure_ascii=False,sort_keys=True,indent=2)+'\n',encoding='utf-8')
def write(n,t):(OUT/n).write_text(t,encoding='utf-8')
(OUT/'inputs/selective-type-definition-packet.json').write_bytes(pb);shutil.copyfile(BASE/'working/build_type_freeze.py',OUT/'inputs/build_type_freeze.py')
for k,n in [('producer','producer.signature.txt'),('actual_consumer','consumer.signature.txt')]:write('inputs/'+n,p[k]['signature'])
bind={'packet_sha256':sha(pb),'statement_seal_sha256':p['statement_seal_sha256'],'producer_signature_sha256':p['producer']['signature_sha256'],'unchanged_R9_consumer_signature_sha256':p['actual_consumer']['signature_sha256'],'definition_context_sha256':p['minimal_definition_context_sha256'],'mathlib_pin':c['mathlib_pin']}
ba=[
 {'binder':'n,Omega : Type*','class':'TYPING','meaning':'Arbitrary finite matrix index carrier and arbitrary sample carrier; no nonempty or positive-dimension restriction.'},
 {'binder':'Fintype n','class':'TYPING','meaning':'Finite square matrix indexing; empty n allowed.'},
 {'binder':'DecidableEq n','class':'TYPING','meaning':'Standard finite matrix/identity infrastructure, not positivity or spectral information.'},
 {'binder':'MeasurableSpace Omega','class':'TYPING','meaning':'Actual measurable sample carrier; no Borel/smoothness restriction on Omega.'},
 {'binder':'mu : Measure Omega; IsProbabilityMeasure mu','class':'AUTHORED_BACKGROUND_HYPOTHESIS','meaning':'A genuine arbitrary probability law contract of this selected background theorem. Probability is available internally for the actual product-Gaussian application. No claim that this is a maximally general arbitrary-measure theorem.'},
 {'binder':'f : Omega -> Matrix n n Real','class':'TYPING_ARBITRARY_DATA','meaning':'Actual arbitrary real matrix-valued function. Its expectation is computed, not supplied as symbolic data.'},
 {'binder':'hf : Integrable f mu','class':'AUTHORED_BACKGROUND_HYPOTHESIS','meaning':'Bona fide analytic assumption on arbitrary f: AE strongly measurable representative and finite extended-norm integral. It is not a conclusion of the generic theorem and is not added to the unchanged Gaussian target.'},
 {'binder':'hpos : AE omega,PosSemidef(f omega)','class':'AUTHORED_BACKGROUND_HYPOTHESIS','meaning':'Bona fide AE full Hermitian/quadratic PSD condition on arbitrary f; null exceptions permitted. It is not a premise certificate on the integral itself. Actual Gaussian consumers must derive it internally.'}]
defs=[
 ('Matrix n n Real','Finite real square matrices, with n arbitrary finite including empty. Scalar field real only; no complex-matrix generality is claimed.'),
 ('Matrix PosSemidef','The supplied literal predicate is IsHermitian AND every Finsupp quadratic form nonnegative. Over real finite n, this is the complete finite-dimensional PSD property, not entrywise nonnegativity and not merely one conjunct.'),
 ('AE hypothesis','hpos holds outside a mu-null exceptional set, not at every sample. That is exactly the authored contract, compatible with integral invariance under AE equality and hf AE strongly measurable representatives. The AE/representative application remains an internal port.'),
 ('Integrable','Actual L2Operator matrix norm integrability with AEStronglyMeasurable plus finite extended norm integral. It is legitimate generic input, not Gaussian input.'),
 ('Matrix L2Operator and completeness','The packet explicitly states Euclidean operator norm semantics. For arbitrary finite n the standard real matrix space has the appropriate complete normed structure internally; no additional positive-dimension/nonempty hypothesis is needed.'),
 ('Bochner integral','Actual integral_mu f in the standard finite matrix space. Supplied definition has default-zero branches outside completeness/integrability, but hf and finite complete matrix structure require the genuine integral branch. No fake proof of a nonintegrable f is endorsed.'),
 ('Generic conclusion','Full PosSemidef(integral_mu f), exactly the authored positivity-preservation contract; no additional moment, concrete variance, operator-norm concentration or source-paper theorem follows.'),
 ('Empty n','Matrix on an empty finite index has its unique empty matrix; Hermitian and quadratic PSD are meaningful (zero quadratic form). No Nonempty n binder is silently inserted. Empty sample carriers are constrained only by the probability-instance contract, not a new assumption.'),
 ('Actual Gaussian consumer','The packet repeats the unchanged R9 producer: exact original product mu, physical row, literal closed cutoff, ordinary matrix square integrability and PSD sum difference. Its sole source premise is still hq, not generic hf/hpos. Application-specific residual/square integrability and PSD are internal proof outputs.'),
 ('Scope attribution','This arbitrary-f/probability lemma is ROOT-selected ASTIS-authored background expansion. The paper p14 only motivates an integration-of-PSD application; it does not print this general theorem, and this is neither a paper-source repair nor a new Gaussian assumption.')]
audit={'version':1,'phase':'INDEPENDENT_TYPE_FREEZE_BEFORE_BACKGROUND_SOURCE_GRAPH','bindings':bind,'actor':'/root/row_indep_source_graph_78c2','owned_root_full_path':str(BASE),
 'classification':'ASTIS_AUTHORED_CANONICAL_BACKGROUND_NOT_PRIMARY_PAPER_GENERAL_THEOREM',
 'verdict':'NO_GENUINE_GENERIC_CONTRACT_OR_CONSUMER_SCOPE_ISSUE_FOUND','genuine_target_issues':[],
 'binder_audit':ba,'EXCESS_generic_binders':[],'Gaussian_binder_additions':[],
 'definitions':[{'object':o,'audit':m,'meaning_match':True} for o,m in defs],
 'generic_vs_source_binder_rule':'The authored arbitrary-f hf/hpos hypotheses are genuine mathematical contract inputs, not proof-result smuggling. They must be discharged at each concrete use. The source-hypothesis=Gaussian-binder invariant is preserved because R9 exact consumer signature is unchanged.',
 'consumer_digest_check':'Actual consumer signature rehashed to the prior supplied unchanged R9 seal digest; no old proof/verdict was opened to assess it.',
 'probability_scope_note':'No defect arises because the selected reusable background contract is probability-only. No arbitrary infinite-measure generality or necessity/minimality of probability is claimed.',
 'paper_attribution_boundary':'Own R9 p14 raw source reading predates this new generic type exposure; that source contains application need only, not the general arbitrary-f theorem.',
 'internal_ports_for_next_phase':['PSD cone closedness and convexity in the actual L2Operator matrix topology.','AE membership, arbitrary Omega/probability/integrability and generic convex-integral theorem exact applicability.','Alternative direct Hermitian/quadratic integral derivation with continuous entry/quadratic maps.','Exact concrete residual/square hf and AE hpos discharge; equality between integral residual and desired source difference.'],
 'genuine_source_gaps':[],'source_defect_claim':False,'compiled_parents':[],'shared_new_target_proof_seen':False,
 'permission_or_status_grant':False}
dump('type-audit.json',audit)
write('type-meaning-verdict.md','No genuine generic-contract or concrete-consumer scope issue found. Arbitrary f, probability measure, hf integrability and AE full PSD are genuine authored-background inputs. They cannot become new binders of the unchanged Gaussian theorem. Empty finite n is allowed. Full Hermitian-plus-quadratic positivity, L2Operator norm and actual Bochner integral meanings match the contract; hf prevents default-zero credit. The paper p14 motivates an application, not this general theorem. Closed/convex cone and convex-integral applicability or direct Hermitian/quadratic alternatives remain unproved internal ports. Type verdict frozen before reading the newly authorized Mathlib background source for graph extraction. No proof, parent-dependency, theorem status or permission granted.\n')
dump('input-exposure-chronology.json',{'bindings':bind,'only_new_type_input':str(PACKET.relative_to(ROOT)),
 'first_type_freeze_before_background_source_read':True,
 'prior_raw_context':'This actor already read the original R9 p14 raw source before this new shared type. R9 raw v1/v2 and exact seal remain unchanged; no prior graph/verdict was reopened in this shared type audit.',
 'formalizer_API_pristine':False,'exposure_disclosure':'Parent reports complete old local proof/API exposure and no new shared proof file/API attempt yet. This actor neither erases that history nor claims pristine formalization; it has not opened ROOT old/new implementation or TC opinions.',
 'allowed_next_background_source':'After this type freeze, fixed Mathlib db584cd6d46c92f209a44c0f1c829460d327499d Mathlib/Analysis/Convex/Integral.lean plus the supplied literal PosSemidef definition may be read as background source, not a new shared implementation.',
 'digest_checks':'Exact packet and literal signature/definition strings rehashed. Seal/context identifiers are supplied labels bound by packet bytes; separate underlying serialization not independently rehashed.',
 'no_changes':'Only own new mp_sg_52ad output/builder writes; no old raw/type artifact, C/ledger/registry/Git/shared mutation.',
 'no_grant':True})
write('README.md','Independent shared-background type audit frozen BEFORE Mathlib source/graph extraction. This is an ASTIS-authored arbitrary-f probability contract, not a printed paper theorem. hf/hpos never add binders to R9. No implementation/API/TC/prior-verdict read, proof or permission/status grant.\n')
m={'format':'astis-real-matrix-positive-integral-type-freeze-v1','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'phase':'TYPE_BEFORE_BACKGROUND_SOURCE_GRAPH','bindings':bind,'files':[]}
for f in sorted(OUT.rglob('*')):
 if f.is_file():b=f.read_bytes();m['files'].append({'path':str(f.relative_to(OUT)),'bytes':len(b),'sha256':sha(b)})
dump('freeze-manifest.json',m);dig=sha((OUT/'freeze-manifest.json').read_bytes());write('freeze-manifest.sha256',dig+'  freeze-manifest.json\n')
for f in OUT.rglob('*'):
 if f.is_file():f.chmod(0o444)
for d in sorted([d for d in OUT.rglob('*') if d.is_dir()],key=lambda d:len(d.parts),reverse=True):d.chmod(0o555)
OUT.chmod(0o555)
print(json.dumps({'type_freeze_path':str(OUT),'type_audit_sha256':sha((OUT/'type-audit.json').read_bytes()),'type_manifest_sha256':dig,'producer_signature_sha256':p['producer']['signature_sha256'],'genuine_target_issues':[]},indent=2))
