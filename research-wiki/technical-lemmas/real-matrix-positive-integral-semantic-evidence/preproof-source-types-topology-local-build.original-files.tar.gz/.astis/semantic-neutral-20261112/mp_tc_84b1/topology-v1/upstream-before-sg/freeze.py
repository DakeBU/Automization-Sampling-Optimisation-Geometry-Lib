from pathlib import Path
import datetime
import hashlib
import json

ROOT = Path('/Users/zhouhuanjian/ASTIS-GC')
OWN = ROOT/'.astis/semantic-neutral-20261112/mp_tc_84b1'
DEST = OWN/'topology-v1/upstream-before-sg'
SOURCE = ROOT/'.lake/packages/mathlib/Mathlib/Analysis/Convex/Integral.lean'

def sha(b):
    return hashlib.sha256(b).hexdigest()

def digest(p):
    b=p.read_bytes()
    return {'path':str(p.relative_to(ROOT)),'bytes':len(b),'sha256':sha(b)}

raw=SOURCE.read_bytes()
assert len(raw)==21375 and sha(raw)=='1b3115887fabf0dccc2fed689d1f1ddc7a114b5de4594e752c02908a445aafb4'
text=raw.decode()
start=text.index('theorem Convex.integral_mem')
end=text.index('/-- If `μ` is a non-zero finite measure',start)
byend=text.index(':= by',start)+len(':= by')
lines=text.splitlines(keepends=True)

def span(a,b):
    return {'unicode_char_start':a,'unicode_char_end_exclusive':b,
            'utf8_byte_start':len(text[:a].encode()),'utf8_byte_end_exclusive':len(text[:b].encode()),
            'lf_line_start_1based':text[:a].count('\n')+1,
            'lf_line_end_1based':text[:max(a,b-1)].count('\n')+1,
            'raw_fragment_sha256':sha(text[a:b].encode())}

assert digest(OWN/'type-v1/freeze.json')['sha256']=='87c37fa423e8b8d8725a5d7253b97d313be94bb2c25652461d3363aca27d3335'
obj={
    'kind':'independent-fixed-upstream-raw-reading-before-SG-exposure',
    'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'source':digest(SOURCE),'all_344_lines_read':True,
    'source_pin_as_supplied':'db584cd6d46c92f209a44c0f1c829460d327499d',
    'ambient_variable_lines_46_47':span(len(''.join(lines[:45])),len(''.join(lines[:47]))),
    'Convex_integral_mem_statement':span(start,byend),
    'Convex_integral_mem_statement_and_printed_proof':span(start,end),
    'reading':digest(DEST/'reading.md'),'reader_script':digest(DEST/'freeze.py'),
    'own_fixed_type_freeze':digest(OWN/'type-v1/freeze.json'),
    'new_SG_graph_inventory_or_opinion_seen':False,
    'new_ASTIS_implementation_or_root_old_proof_seen':False,
    'source_is_printed_generic_convex_set_integral_theorem':True,
    'source_is_printed_PSD_matrix_specialization':False,
    'actual_matrix_application_or_proof_verified':False,
    'topology_or_permission_grant':False,
}
(DEST/'freeze.json').write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'freeze':digest(DEST/'freeze.json'),'reading':digest(DEST/'reading.md')},indent=2))
