"""Execute only after exact independent preproof source/topology admission."""
from pathlib import Path
import hashlib, json, sys
sys.dont_write_bytecode = True
W = Path('.astis/huanjian-gc-fixed-spectrum-gaussian-moments-20261110')
B = Path('research-wiki/paper-contributions/GaussianComplexity')
E = B / 'fixed-spectrum-gaussian-moments-semantic-evidence'
C = Path('research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-gaussian-moments.json')
L = Path('runs/substantive_advances.jsonl')
ADV = 'ASTIS-SA-20261110-GaussianComplexityFixedSpectrumGaussianMoments'
OWNER = 'huanjian_gc_20261110_fixed_spectrum_gaussian_moments'
sha = lambda b: hashlib.sha256(b).hexdigest()
dump = lambda x: (json.dumps(x, ensure_ascii=False, indent=2) + '\n').encode()
def ref(p):
    return {'path': str(p), 'sha256': sha(p.read_bytes()), 'bytes': p.stat().st_size}
def put(p, b):
    assert not p.exists(), p
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(b)

grant = json.loads((W / 'root-preproof-admission-grant.json').read_bytes())
assert grant['source_graph_and_distinct_topology_admitted'] is True
assert grant['target_proof_or_API_search_has_started'] is False
sealpath = W / 'statement-seal-v2.json'
sealraw = sealpath.read_bytes()
assert sha(sealraw) == grant['seal_sha256'] == 'eed0782fa32075cdf6313e802293764bd6b07ca991974b9e56c8d520a8e13354'
for r in grant['actual_frozen_review_inputs']:
    assert sha(Path(r['path']).read_bytes()) == r['sha256'], r['path']
seal = json.loads(sealraw)
baseline = json.loads((W / 'preproof-baseline.json').read_bytes())
latest_hold_path = W / 'coordination-HOLD-official-main-3c31b46765d7.json'
latest_hold = json.loads(latest_hold_path.read_bytes())
assert latest_hold['foreign_STAB']
before = L.read_bytes()
assert sha(before) == baseline['ledger']['sha256']
for name, h in baseline['all_frontier_hashes'].items():
    assert sha(Path(name).read_bytes()) == h, name
for name, h in baseline['protected_shared_hashes'].items():
    assert sha(Path(name).read_bytes()) == h, name
assert not C.exists() and not E.exists()
sys.path.insert(0, 'tools')
import astis_advance as advance
states = advance._replay_advances([json.loads(x) for x in before.splitlines()])
assert states == baseline['all_current_SAU_states'] and ADV not in states
assert not [k for k, v in states.items() if v['state'] == 'STABILIZING']
# This is foreground mathematical intake, not integration authority. The real
# official-main foreign STAB remains occupied even though absent in local history.
assert baseline['official_foreign_STAB']
declaration = seal['producer']['name']
prod = seal['producer']['planned_file']
test = seal['actual_private_consumer']['planned_file']
assert not Path(prod).exists() and not Path(test).exists()
boundary = seal['truth_boundary']
publicseal = B / 'fixed-spectrum-gaussian-moments-statement-seal.json'
put(publicseal, sealraw)
put(E / 'preproof-source-admission.json', dump(grant))
put(E / 'producer.signature.lean.txt', seal['producer']['signature'].encode())
put(E / 'consumer.signature.lean.txt', seal['actual_private_consumer']['signature'].encode())
searched = seal['shared_floor_audit']['searched_before_seal']
cell = {
    'schema_version': 3, 'cell_id': C.stem, 'route': 'samplewiki-route', 'mode': 'faithfulPaper',
    'title': 'Actual diagonal Gaussian quadratic means and their cosine alias series',
    'source_anchor': 'arXiv2610.20492v1 S4.E11/S4.Thmtheorem5; A3.SS3.p4.1/Ex140 and p4.2,p6.1/Ex144',
    'target_statement': seal['producer']['signature'], 'status': 'claimed',
    'owner_id': OWNER, 'advance_id': ADV, 'parents': [],
    'consumers': ['Sealed actual private Gaussian cosine alias-series identity, unproved at intake.',
                  'Planned closed FactC8 means and Lemma4.5, not certified by this packet.'],
    'shared_floor_audit': {'searched': searched, 'classification': 'adapt', 'decision': 'adapt_existing',
        'canonical_declaration': declaration, 'canonical_shared_cell': '',
        'notes': 'Post-admission actual Gaussian moment API/canonicality search required. Reuse existing canonical nodes; do not manufacture wrappers.'},
    'reuse_plan': {'searched_existing': searched, 'reused_declarations': [], 'new_shared_declarations': [],
        'known_consumers': [], 'planned_consumers': ['actual_gaussian_cosine_alias_series; materially consume actual Gaussian means, C7 and GridAlias.'],
        'no_duplicate_wrapper': True,
        'decision_reason': 'Actual fixed Gaussian integral bridge, with integrability produced. Deterministic finite sums alone do not prove it.'},
    'reader_contract': {'reference_standard': 'textbook/chapter-01/section-1-3.html',
        'source_ordered': True, 'source_statement_adjacent': True, 'natural_language_formula_proof': True,
        'hidden_assumptions_visible': True, 'lean_collapsed': True, 'external_dependencies_visible': True},
    'graph_contribution': {'lean_view': 'new-node', 'overview_view': 'no-change-with-reason',
        'functor_view': 'none-found', 'edge_semantics': 'formal-solid; overlays-dashed',
        'color_semantics': 'evidence-status; library-scope', 'focus_targets': [declaration],
        'visual_review': 'Independent preproof source topology only. No compiled node, sourceV, site, integration or conceptual acceptance.'},
    'source_detail_audit': {'primary_edition': 'arXiv2610.20492v1',
        'primary_anchor': 'S4.E11;S4.Thmtheorem5;A3.SS3.p4.1;A3.Ex140;A3.SS3.p4.2;A3.SS3.p6.1;A3.Ex144',
        'detail_status': 'omitted',
        'gap': 'Actual inverse covariance, coordinate second moments, norm and quadratic integrability and finite integral linearity must be discharged internally. Absolute weighted convergence and finite-tsum exchange must support the actual Gaussian consumer. Closed tail partitions/resummation, fourth moments, variance and bias remain outside this packet.',
        'consulted': [{'source': 'Pinned raw source, independent raw-first graph and distinct topology/binder/definition challenge',
            'anchor': 'A3.SS3.p4,p6;S4.E11;S4.Thmtheorem5',
            'hypothesis_adapter': 'Literal d>=2,kappa>=2 and Nat mode1<=n<d, actual centered multivariateGaussian covariance Lambda inverse; no covariance or moment certificate premise.'}],
        'fidelity_boundary': boundary},
    'learning_contract': {'control_plane_math_authority': False, 'process_memory_checked': True,
        'process_memory_ids': ['ASTIS-PM-QUADRATIC-TILT-MEASURE-ROLES', 'ASTIS-NK-GRADIENT-FLOW-ZERO-TIME', 'ASTIS-NK-GD-INVERSE-DOMAIN'],
        'failure_class': 'IMPLEMENTATION_FAILED',
        'salvage': {'required': True, 'status': 'completed',
            'reason': 'Preproof source-graph condition prose confused covariance with inverse covariance. Original graph/HOLD retained; only an independently accepted append-only condition successor permits this intake. Exact target signatures/formulas unchanged; no moment-target proof was attempted.',
            'promoted_fragments': ['No proved mathematical fragment; accepted exact statement and corrected source topology only.'],
            'discarded_fragments': []},
        'parallelism': {'decision': 'serial', 'direction_fingerprints': [],
            'expected_information_gain': 'Root sole proof worker; independent graph extractor and challenger address distinct source/coverage uncertainties only.',
            'shared_verified_context_digest': seal['producer']['signature_sha256']},
        'cross_route_blind_spot_audit': {'required': False, 'status': 'not-applicable', 'evidence': '',
            'canonical_route': '', 'selection_reason': 'No parallel proof routes.'},
        'reader_backpressure': {'purification_status': 'pending', 'exposition_seal_status': 'pending',
            'exposition_evidence': '', 'source_expansion_nodes': [], 'lean_expansion_nodes': [],
            'assumptions_preserved': True, 'boundary_preserved': True}},
    'statement_seal': {'path': str(publicseal), 'sha256': sha(sealraw),
        'signature_sha256': seal['producer']['signature_sha256'],
        'status': 'EXACT_TYPE_FORMED_INDEPENDENT_PREPROOF_ADMITTED_NO_PROOF'},
    'source_proof_coverage': {'preproof_admission': ref(E / 'preproof-source-admission.json'),
        'internal_obligations_still_unproved': seal['internal_dependencies_not_premises']},
    'evidence': {'execution_boundary': boundary, 'focused_checks': [],
        'preproof_source_admission': str(E / 'preproof-source-admission.json'),
        'actual_consumer_seal': seal['actual_private_consumer'], 'independent_verification': '',
        'root_build': '', 'graph_regeneration': '', 'pr': '',
        'official_main_foreign_stabilization_HOLD': ref(latest_hold_path)},
    'blocked': {'reason': '', 'children': []}}
proposal = advance.AdvanceProposal(advance_id=ADV, task_id='ASTIS-SW-GAUSSIAN-COMPLEXITY-2026',
    goal='Prove actual centered inverse-precision diagonal Gaussian norm/cosine quadratic expectations and consume them in an actual Gaussian alias-supported summable series.',
    source_anchor=cell['source_anchor'], theorem_delta=seal['producer']['signature'], truth_boundary=boundary,
    created_by=OWNER, dag_inputs=('source:arXiv2610.20492v1:A3.SS3.p4.1/Ex140',
        'canonical:C7 and GridAlias for actual private Gaussian consumer'),
    proposed_files=(prod, test, str(C), 'website/content/declaration_lessons/huanjian-fixed-spectrum-gaussian-moments.json',
        'website/content/publications/huanjian-fixed-spectrum-gaussian-moments.json'),
    focused_checks=('lake env lean ' + prod, 'lake build Tests.GaussianComplexityFixedSpectrumGaussianMoments'),
    modes=('source-reading', 'proof-design', 'compiler-diagnosis'), priority=50, frontier_cell=C.stem,
    target_declarations=(declaration,))
proposal.validate()
advance.propose_advance(proposal)
advance.transition_advance(ADV, 'CLAIMED', worker_id=OWNER,
    evidence={'exact_statement_seal': ref(publicseal), 'preproof_admission': ref(E / 'preproof-source-admission.json'), 'truth_boundary': boundary})
advance.transition_advance(ADV, 'EXPLORING', worker_id=OWNER,
    evidence={'preproof_admission': ref(E / 'preproof-source-admission.json'), 'source_graph_and_distinct_topology_admitted': True,
        'target_proof_API_work_starts_after_this_event': True, 'shared_integration_authorized': False, 'truth_boundary': boundary})
C.write_bytes(dump(cell))
after = L.read_bytes()
assert after.startswith(before)
appended = after[len(before):]
assert len(appended.splitlines()) == 3
newstates = advance._replay_advances([json.loads(x) for x in after.splitlines()])
assert newstates[ADV]['state'] == 'EXPLORING' and newstates[ADV]['owner_id'] == OWNER
assert {k: v for k, v in newstates.items() if k != ADV} == states
for name, h in baseline['all_frontier_hashes'].items():
    assert sha(Path(name).read_bytes()) == h, name
for name, h in baseline['protected_shared_hashes'].items():
    assert sha(Path(name).read_bytes()) == h, name
put(E / 'normal-EXPLORING-append.exact.jsonl', appended)
put(E / 'normal-intake-preservation.json', dump({'normal_API_calls': 3, 'state': 'EXPLORING',
    'advance_id': ADV, 'owner': OWNER, 'before_ledger_sha256': sha(before), 'after_ledger_sha256': sha(after),
    'raw_prefix_preserved': True, 'foreign_SAU_states_preserved': len(states),
    'foreign_frontier_files_preserved': len(baseline['all_frontier_hashes']), 'shared_models_and_discovery_unchanged': True,
    'local_STAB': [], 'official_main_foreign_STAB': latest_hold['foreign_STAB'],
    'latest_actual_official_main':latest_hold['actual_main'],
    'integration_authorized': False, 'append': ref(E / 'normal-EXPLORING-append.exact.jsonl'), 'new_cell': ref(C),
    'proof_consumer_sourceV_or_integration_credit': False}))
print(json.dumps({'normal_state': 'EXPLORING', 'normal_API_calls': 3, 'append_sha256': sha(appended),
    'foreign_states_preserved': len(states), 'foreign_frontiers_preserved': len(baseline['all_frontier_hashes']),
    'new_source_verdict_or_mathematical_result': False}))
