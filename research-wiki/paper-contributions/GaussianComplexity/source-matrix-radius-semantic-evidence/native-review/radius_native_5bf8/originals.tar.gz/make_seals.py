from runner import *
seal=json.loads((OUT/'snapshot/research-wiki/paper-contributions/GaussianComplexity/source-matrix-radius-statement-seal.json').read_text())
prefix='''import Tests.GaussianComplexityFixedSpectrumSourceMatrixRadius
import Lean
open Lean Meta Elab Command
open MeasureTheory ProbabilityTheory
open scoped BigOperators Matrix Kronecker Matrix.Norms.L2Operator
set_option autoImplicit false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace RadiusSeal5bf8
'''
for key,label in [('producer','P'),('actual_private_consumer','T')]:
    sig=seal[key]['signature'];assert hashlib.sha256(sig.encode()).hexdigest()==seal[key]['signature_sha256']
    body=sig.split(':\n',1)[1]
    prefix+=f'def {label} : Prop := ∀ {{d q : ℕ}} (hq : 2 * q + 1 < d),\n'+body+'\n'
prefix+='''
theorem qzeroHyp : 2 * 0 + 1 < 2 := by decide
example {n : Type*} [Fintype n] [DecidableEq n] (A : Matrix n n ℝ) :
    ‖A‖ = ‖Matrix.toEuclideanCLM (n := n) (𝕜 := ℝ) A‖ := rfl
example {n : Type*} [Fintype n] [DecidableEq n] (A : Matrix n n ℝ)
    (x : EuclideanSpace ℝ n) :
    WithLp.ofLp (Matrix.toEuclideanCLM (n := n) (𝕜 := ℝ) A x) =
      A *ᵥ WithLp.ofLp x := rfl

run_meta do
  let env ← getEnv
  let tnames := env.constants.toList.filterMap fun (n,_) =>
    if n.toString.endsWith ".actual_source_centered_summand_radius" then some n else none
  unless tnames.length == 1 do throwError "private consumer not unique"
  let pn := ``AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumSourceMatrixRadius.actual_source_truncated_matrix_norm_bounds
  let tn := tnames.head!
  let mut rows := #[]
  for (n,sn) in [(pn,``P),(tn,``T)] do
    let ci ← getConstInfo n
    let sealedTy := (← getConstInfo sn).value!
    unless Kernel.isDefEqGuarded env {} ci.type sealedTy do throwError "full sealed type mismatch: {n}"
    let v := ci.value! true
    unless !v.hasFVar && !v.hasMVar && !v.hasLooseBVars do throwError "open proof"
    let d : Declaration := .thmDecl {
      name := Name.str `RadiusSealedClone n.toString
      levelParams := ci.levelParams
      type := sealedTy
      value := v }
    match env.addDeclCore 0 100000 d none true with
    | .ok _ => pure ()
    | .error e => throwError "actual proof rejected at exact sealed universal type: {e.toMessageData (← getOptions)}"
    let app := mkAppN (mkConst n) #[mkNatLit 2,mkNatLit 0,mkConst ``qzeroHyp]
    let stype := sealedTy.bindingBody!.instantiate1 (mkNatLit 2)
    let stype := stype.bindingBody!.instantiate1 (mkNatLit 0)
    let stype := stype.bindingBody!.instantiate1 (mkConst ``qzeroHyp)
    let zd : Declaration := .thmDecl {
      name := Name.str `RadiusZeroClone n.toString
      levelParams := []
      type := stype
      value := app }
    match env.addDeclCore 0 100000 zd none true with
    | .ok _ => pure ()
    | .error e => throwError "genuine q=0 application rejected: {e.toMessageData (← getOptions)}"
    rows := rows.push <| Json.mkObj [("actual",toJson n.toString),("sealed",toJson sn.toString),
      ("fullUniversalTypeKernelDefEq",toJson true),("actualProofAtSealedTypeKernelChecked",toJson true),
      ("genuineQ0ApplicationD",toJson (2 : Nat)),("genuineQ0ApplicationKernelChecked",toJson true)]
  IO.FS.writeFile "/Users/zhouhuanjian/ASTIS-GC/.astis/semantic-neutral-20261113/radius_native_5bf8/seal-result.json" (Json.arr rows).pretty
end RadiusSeal5bf8
'''
(OUT/'Seals.lean').write_text(prefix)
