"""Run only after separately pinned real source V, fresh main and root authorization."""
from pathlib import Path
import datetime, gzip, hashlib, json, subprocess, sys
sys.path.insert(0, 'tools')
import astis_advance as adv
import astis_publication as pub
sha = lambda b: hashlib.sha256(b).hexdigest()
put = lambda p, x: p.write_text(json.dumps(x, ensure_ascii=False, indent=2) + '\n')
P = Path('.astis/huanjian-gc-fixed-spectrum-first-order-integration-20261108')
B = Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-first-order-integration-20261108')
Q = P / 'independent-reader/conditional-proposal-v1'
auth_path = P / 'root-sole-STAB-application-authorization.json'
auth = json.loads(auth_path.read_bytes())
assert auth['authorized_by'] == '/root' and auth['exact_eight_path_application_authorized'] is True
assert auth['new_source_verdict'] is False
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
assert head == auth['source_V_first_carrying_commit']
assert not subprocess.check_output(['git', 'diff', 'HEAD', '--name-only'], text=True).strip()
main = subprocess.check_output(['git', 'rev-parse', 'origin/main'], text=True).strip()
assert main == auth['fresh_origin_main']
subprocess.run(['git', 'merge-base', '--is-ancestor', main, head], check=True)
report, freeze = Q / 'proposal-report.json', Q / 'freeze.json'
assert sha(report.read_bytes()) == auth['proposal_report_sha256'] == '43bff1329cd5b697a845184e1ff9d27004c93d46edb2251f855c4a90d92e5604'
assert sha(freeze.read_bytes()) == auth['proposal_freeze_sha256'] == '00333a58d298cf2003f23d6aa4e2e6fe4a5d6b8308c5d683c0acf2c6fa6ad27f'
for row in json.loads(freeze.read_bytes())['files']:
    assert sha(Path(row['path']).read_bytes()) == row['sha256']
r = json.loads(report.read_bytes()); assert len(r['shared_paths']) == 8
ap = Path('research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-first-order.json')
audit_raw = ap.read_bytes(); audit = json.loads(audit_raw)
assert sha(audit_raw) == auth['accepted_audit_sha256']
assert audit['state'] == 'accepted' and audit['source_review']['reviewer'] == auth['source_verifier']
assert audit['publication_binding_sha256'] == r['publication_binding_sha256']
assert subprocess.check_output(['git', 'show', head + ':' + str(ap)]) == audit_raw
aid = 'ASTIS-SA-20261108-GaussianComplexityFixedSpectrumFirstOrder'
owner = 'huanjian_gc_20261108_fixed_spectrum_first_order_integration'
states = adv.current_advances()
assert states[aid]['state'] == 'VERIFIED'
assert states[aid]['owner_id'] == 'huanjian_gc_20261108_fixed_spectrum_first_order'
assert not [k for k,v in states.items() if v['state'] == 'STABILIZING']
lp = Path('runs/substantive_advances.jsonl'); before = lp.read_bytes()
assert sha(before) == auth['ledger_before_STAB_sha256']
vraw = Path(auth['actual_source_V_append_path']).read_bytes()
assert sha(vraw) == auth['actual_source_V_append_sha256'] and before.endswith(vraw)
v = json.loads(vraw)
assert v['advance_id'] == aid and (v['from_state'], v['to_state']) == ('PROVED_LOCAL', 'VERIFIED')
assert v['worker_id'] == v['evidence']['verifier_id'] == auth['source_verifier']
assert v['evidence']['verified_commit'] == r['candidate_commit']
assert all(v['evidence'][k] for k in ['gate', 'source_audit', 'fake_closure_scan'])
pub.check_advance([audit['lean']['declaration']], reviewed=True)
dp = Path('runs/substantive_discoveries.jsonl'); discovery = dp.read_bytes()
cp = Path('research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-first-order.json')
foreign = {str(p): p.read_bytes() for p in cp.parent.glob('*.json') if p != cp}
readme = Path('research-wiki/paper-contributions/GaussianComplexity/README.md'); readme_raw = readme.read_bytes()
payloads = []
for row in r['shared_paths']:
    p = Path(row['path']); assert p.exists() == row['before_exists']
    assert not p.exists() or sha(p.read_bytes()) == row['before_sha256']
    a = row['planned_after_archive']; z = Path(a['path']).read_bytes(); raw = gzip.decompress(z)
    assert sha(z) == a['gzip_sha256'] and sha(raw) == row['planned_after_sha256'] and len(raw) == a['raw_bytes']
    payloads.append((p, raw))
for path, digest in r['source_Test_lesson_publication_pins'].items(): assert sha(Path(path).read_bytes()) == digest
assert sha(Path('website/static/information-architecture.css').read_bytes()) == r['CSS_unchanged_sha256']
assert not B.exists(); B.mkdir()
(B / 'root-sole-STAB-application-authorization.json').write_bytes(auth_path.read_bytes())
adv.transition_advance(aid, 'STABILIZING', worker_id=owner, evidence={
    'integration_owner': owner, 'canonical_branch': subprocess.check_output(['git','branch','--show-current'],text=True).strip(),
    'verifier_id': auth['source_verifier'], 'verified_commit': r['candidate_commit'],
    'source_V_first_carrying_commit': head,
    'publication_declarations': [audit['lean']['declaration']], 'lean_declarations': [audit['lean']['declaration']],
    'independent_proposal': str(report), 'proposal_sha256': sha(report.read_bytes()),
    'root_exact_diff_review': auth['root_conditional_review'],
    'scope': 'Exactly eight reviewed shared paths; one new producer and existing typed conceptual bridge supplement. No old ancestor sourceV or private Test Registry credit.',
    'truth_boundary': 'Existing genuine independent source/module/freshLean/STATIC-reader V preserved. Actual immutable-core root/site/graph/desktop-mobile acceptance, remote, purification/Seal and both complete mains remain open.'})
after = lp.read_bytes(); assert after.startswith(before)
append = after[len(before):]; assert len(append.splitlines()) == 1
for p, raw in payloads: p.write_bytes(raw)
now = adv.current_advances()
assert [k for k,v in now.items() if v['state'] == 'STABILIZING'] == [aid]
assert now[aid]['owner_id'] == states[aid]['owner_id']
assert all(now[k] == value for k,value in states.items() if k != aid)
assert all(Path(p).read_bytes() == raw for p, raw in foreign.items())
assert dp.read_bytes() == discovery and ap.read_bytes() == audit_raw and readme.read_bytes() == readme_raw
for row in r['shared_paths']: assert sha(Path(row['path']).read_bytes()) == row['planned_after_sha256']
cell = json.loads(cp.read_bytes())
cell['evidence']['canonical_integration'] = {
    'state': 'SOLE_STAB_EXACT_EIGHT_PATHS_APPLIED_ACTUAL_CORE_GATES_PENDING',
    'owner': owner, 'source_V_first_carrying_commit': head,
    'source_verifier_preserved': auth['source_verifier'], 'proposal_report_sha256': sha(report.read_bytes()),
    'new_mathematical_results': 1, 'private_Test_Registry_node': False,
    'same_existing_typed_bridge_supplement': True, 'cross_route_formal_transport': False,
    'actual_STAB_append_sha256': sha(append)}
put(cp, cell)
for name, raw in [('before-STAB-ledger.lossless.jsonl.gz',before), ('after-STAB-ledger.lossless.jsonl.gz',after), ('sole-STAB-append.exact.jsonl.gz',append)]:
    q = B / name; q.write_bytes(gzip.compress(raw,mtime=0)); assert gzip.decompress(q.read_bytes()) == raw
(B / 'sole-STAB-append.exact.jsonl').write_bytes(append)
put(B / 'exact-shared-application-receipt.json', {
    'recorded_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'normal_state': now[aid]['state'], 'integration_owner': owner, 'normal_STAB_append_events': 1,
    'ledger_before_sha256': sha(before), 'ledger_after_sha256': sha(after), 'append_sha256': sha(append),
    'old_ledger_prefix_preserved': True, 'foreign_states_preserved': len(states)-1,
    'foreign_frontier_files_preserved': len(foreign), 'README_discovery_source_audit_unchanged': True,
    'exact_shared_paths': [{'path':row['path'],'sha256':row['planned_after_sha256']} for row in r['shared_paths']],
    'new_source_verdict': False, 'actual_core_build_site_browser_acceptance': False})
print(json.dumps({'state': now[aid]['state'], 'exact_shared_paths_applied': 8,
    'foreign_states_preserved': len(states)-1, 'foreign_frontiers_preserved': len(foreign),
    'existing_source_V_preserved': True, 'next': 'Freeze immutable integration core, then real eight gates and actual browser.'}))
