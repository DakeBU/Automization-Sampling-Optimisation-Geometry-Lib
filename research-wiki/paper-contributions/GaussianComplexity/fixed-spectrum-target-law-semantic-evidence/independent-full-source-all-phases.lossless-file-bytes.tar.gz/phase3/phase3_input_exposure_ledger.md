# Phase-3 input/exposure/action ledger

Reader/run: `/root/targetlaw_fresh_source_9c7d21`.
New write directory: `.astis/semantic-neutral-20261110/tl_src_e028af/phase3/` only.

The phase-1 and phase-2 files and their exact immutable receipts are retained; none was edited. Their original prior-directory-name, additional-raw-formula, and pretraining-recognition caveats remain in force. The original source-only cognition and selective comparison preceded all implementation/exposition exposure in this run.

## New exact inputs

The full text of both production and test modules, the authored lesson, and the authored publication were read and saved from `git show 8ee639d3aced826aa5b4e39fa6f8bedd3b830327:<exact path>`. These snapshots include complete module/import/scoped context; no current-working-tree production source was substituted.

The whitelisted full reviewer packet and source-to-Lean map were read from their named evidence paths only after raw SHA-256 verification. They are preserved as exact bytes in this phase directory. Their canonical/whole-file hashes and candidate correspondences were independently checked. No files adjacent to those named inputs were inventoried or opened.

All 29 map rows were processed, using each exact named canonical source path. Production, test, admissibility, and Gaussian-moment modules came from the immutable candidate; Mathlib files came from the named canonical paths and were matched against the map's exact whole-file hashes. Each full file and selected locator block is saved in this phase directory. Only necessary statements/proofs, definitions, headers, and surrounding context were printed for human mathematical inspection. The original map's graph hash fields were seen as metadata; graph contents were not read.

Additional necessary canonical definitions were inspected: Gaussian `Basic.lean` for the definition of `IsGaussian`, its probability/Gaussian-map instances and moment interface; matrix `PosDef.lean` for actual positive-definite meaning, invertibility and inverse positivity; and `PiL2.lean` for ordinary Euclidean/L2 and norm-square semantics. Their exact bytes/hashes are preserved. No alternative theorem/proof-route search was performed: searches were for exact definitions or calls already appearing in the candidate and its canonical substrate.

The candidate `lean-toolchain` and `lake-manifest.json` were obtained by exact `git show` and matched the reviewer packet's digests. No Lean toolchain process or dependency update was run.

Canonical audit-tool sources were read for schema and packet hashing: `tools/astis_semantic_roundtrip.py`, `tools/astis_semantic_roundtrip_core.py`. The source of `tools/astis_publication.py` was read only for `binding_payload`, `binding_digest`, `review_context`, their digest convention and the immediate import/function context; its global inputs/load functions were not called. Exact source snapshots/hashes are preserved. The publication binding was manually reproduced from the authorized exact candidate snapshots, without reading any registry, frontier inventory, or site graph.

The original source was not replaced by the attributed auxiliary paraphrase. Relevant source facts remain the already pinned raw sections and exact anchors retained in phase 1. No new external mathematical source, browser page, or web/API resource was consulted.

## Unexpected status exposure from an authorized file

The map's `source_normalizer_boundary` field contains the exact sentence:

> Original TC HOLD and exact source-author two-string successor both retained.

I saw this sentence while reading the explicitly authorized complete map, so an old TC status label was exposed. I immediately reported the exposure to the parent. I did not open a TC verdict, sourcegraph verdict, predecessor/successor graph, source-author review, or prior review result. The parent instructed me to retain this exposure and continue from the existing freezes, not to treat the sentence as evidence, and to identify/pause any specific code point if the status actually affected my judgment.

The phase-3 review's conclusion about the normalizer boundary is based on the previously frozen raw source and literal `P`/`T` conclusions, not the map's old-status sentence. No specific code point was left dependent on that status to resolve. I cannot guarantee absence of latent/subconscious anchoring, and I make no pristine-recognition or zero-anchoring claim. The full map is retained unchanged, including this exposure; it was not rewritten to conceal the line.

The actual authored publication contains author-supplied `assumption_deltas` classifications/reasons. Reading that exact file was explicitly authorized. I treated these as candidate claims to check, not independent source verdicts. The full reviewer packet itself omits prior semantic slots/deltas/verdicts/repairs; its empty output template and candidate mathematical context were visible.

## Explicitly unobserved or unperformed

I did not read root local check logs, kernel/native verdicts, independent native evidence, sourcegraph/TC verdict files, global registry audit contents, any other prior source-review contents, or generated/public reader artifacts. I did not run Lean, root tests, a build, ASTIS control-plane/check commands, sourceV, V, API/intake, STAB, global publication, purification, git staging/commit/push, a browser, network retrieval, or a background process. I did not spawn another agent or edit any candidate/global file.

Any schema check in this phase uses the exact copied canonical core validator against a newly assembled **own singleton fixture** from the authorized packet and this independent five-field proposal. It never calls `load_registry`, never reads the real registry, never mutates an audit, and disables Python bytecode output. Its `compiled:true` input is inherited packet metadata, not a compiler/native result newly established by this reviewer. The check is schema/packet-binding evidence only.

## Frozen result identity and next boundary

The reviewer has not acted as formalizer or blind decoder in this run and differs from both supplied role identities. Ordinary pretraining familiarity remains unverifiable; the supplied decoder blindness metadata is not independently audited here. Parent messages contained no proof transcript or root native judgment, and the status prompt asked only for progress/minimal diagnoses without a prior verdict.

This phase freezes an independent source/code/exposition semantic judgment and a canonical five-field proposal. It applies no global audit and issues no native/delivery/completion credit. Subsequent normal V requires independent exact-candidate native evidence plus a reviewed carrier in a separate explicitly authorized step.
