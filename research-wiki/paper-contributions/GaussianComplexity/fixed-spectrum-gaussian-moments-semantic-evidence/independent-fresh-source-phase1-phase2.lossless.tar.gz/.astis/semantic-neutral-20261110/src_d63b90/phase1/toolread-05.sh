rg -n 'semantic|round.trip|denois|decoder' docs/theorem-publication-protocol.md docs/formalization-protocol.md
