from pathlib import Path
import gzip, hashlib, json, re, sys, tarfile
sys.dont_write_bytecode = True
sys.path.insert(0, 'tools')
import astis_advance as adv
import astis_publication as pub
W = Path('.astis/huanjian-gc-fixed-spectrum-gaussian-moments-20261110')
E = Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-gaussian-moments-semantic-evidence')
C = Path('research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-gaussian-moments.json')
L = Path('runs/substantive_advances.jsonl')
ADV = 'ASTIS-SA-20261110-GaussianComplexityFixedSpectrumGaussianMoments'
OWNER = 'huanjian_gc_20261110_fixed_spectrum_gaussian_moments'
sha = lambda b: hashlib.sha256(b).hexdigest()
dump = lambda x: (json.dumps(x, ensure_ascii=False, indent=2) + '\n').encode()
def ref(p):
    p = Path(p)
    return {'path': str(p), 'sha256': sha(p.read_bytes()), 'bytes': p.stat().st_size}
def put(p, b):
    assert not p.exists(), p
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(b)
seal = json.loads((W / 'statement-seal-v2.json').read_text())
prod = Path(seal['producer']['planned_file'])
test = Path(seal['actual_private_consumer']['planned_file'])
name = seal['producer']['name']
record = json.loads((E / 'publication-draft-record.json').read_text())
assert sha(prod.read_bytes()) == record['producer_raw_sha256']
assert sha(test.read_bytes()) == record['Test_raw_sha256']
for p in [prod, test]:
    assert not re.search(r'\b(sorry|admit|axiom)\b|Prop\s*:=\s*True|:=\s*trivial\b', p.read_text())
checks = []
for key in ['actual_focus_receipt', 'actual_kernel_receipt']:
    p = Path(record[key])
    d = json.loads(p.read_bytes())
    assert d['exit_code'] == 0 and sha(Path(d['log']).read_bytes()) == d['log_sha256']
    checks.append({'receipt': ref(p), 'raw_log_sha256': d['log_sha256'], 'exit_code': 0})
pub.check_advance([name], reviewed=False)
mapping = {
 'gap:actual-law-identification': (prod, 'let μ :', 'Literal actual multivariateGaussian0 Λ inverse; its standard IsGaussian instance, actual mean/covariance APIs and internally proved SPD domain identify the law. No law callback or witness binder.'),
 'gap:coordinate-second-moment': (prod, 'have hmoment', 'Actual coordinate L², zero mean and variance_eval_multivariateGaussian plus the true inverse diagonal give the integral of each coordinate square.'),
 'gap:finite-expectation-linearity': (prod, 'rw [hnorm, integral_finsetSum', 'Produced coordinate integrability justifies actual finite Bochner integral linearity and constant-multiple integration.'),
 'gap:gaussian-quadratic-integrability': (prod, 'have hnormint', 'hcoordint, hnormint and hQint produce square/norm/quadratic integrability; no default-zero or free regularity premise.'),
 'gap:gaussian-second-order-analysis': (prod, 'have hcoordL2', 'IsGaussian.memLp_dual gives actual coordinate L². hmean is the projection of the actual vector mean; hmoment invokes the exact covariance on the internally proved SPD domain.'),
 'gap:inverse-diagonal': (prod, 'have hinv', 'An actual diagonal reciprocal left inverse is multiplied by Λ and Matrix.inv_eq_left_inv proves the matrix inverse; every eigenvalue is nonzero internally.'),
 'gap:norm-quadratic-coordinate-identities': (prod, 'have hnorm :', 'EuclideanSpace.real_norm_sq_eq is applied. Q is the sealed literal coordinate presentation; ordinary diagonal multiplication and dot-product expansion justify its source U^T D_n U meaning in the authored lesson, not an additional public wrapper theorem.'),
 'gap:spectral-admissibility': (prod, 'have heigenlower', 'Real cosine lower bound and κ>=2 produce λ>=1, hΛpos and hΛpos.inv.posSemidef. No supplied precision/covariance certificate.'),
 'gap:alias-series-summability': (test, 'have hF :', 'hsgnorm explicitly proves weighted absolute summability; hsumG and the actual pointwise2G=dF identity produce supported-series Summable using nonzero d.'),
 'gap:finite-grid-tsum-exchange': (test, 'have hexchange', 'Actual Summable.tsum_finsetSum over the finite weighted grid, separate from Gaussian finite-integral linearity.'),
 'gap:normalized-integer-alias': (test, 'have hcos', 'Canonical all-Int actual_midpoint_grid_cosine_alias is applied at n and both signed shifts, with exact quotient/zpow guard and the factor d.'),
 'gap:positive-mode-series-indexing': (test, 'have hprod', 'F uses Nat j+1 for the positive source series. It is cast to Int before subtraction; hprod push_cast transports the exact signed real angles without Nat truncated subtraction.'),
 'gap:weighted-c7-series': (test, 'have hmajor', 'Canonical C7 heq/habs supply the literal normalized reciprocal spectrum and absolute convergence; cosine norm<=1, hsgnorm and hlin transport the weights.'),
}
graphpath = W / 'independent-source-graph/phase3/source-graph.resolved.json'
g = json.loads(graphpath.read_bytes())
assert set(mapping) == {n['id'] for n in g['nodes'] if n['id'].startswith('gap:')}
rows = []
for node, (p, needle, explanation) in mapping.items():
    line = next(i + 1 for i, text in enumerate(p.read_text().splitlines()) if needle in text)
    rows.append({'source_node': node, 'lean_file': str(p), 'line': line, 'local_provider': needle,
                 'implementation_map': explanation, 'independent_whole_module_review': 'pending'})
put(E / 'source-to-lean-map.json', dump({'source_graph': ref(graphpath), 'statement_seal': ref(W / 'statement-seal-v2.json'),
    'obligations': rows, 'no_extra_binders': True, 'no_new_canonical_nodes_for_local_haves': True,
    'not_an_independent_source_verdict': True, 'outside_scope': seal['truth_boundary']}))
mirror = {'status': 'none-found', 'discovery_ids': [],
    'searched': ['Current GraphMemory families and FunctorHypergraph objects/transports for Gaussian/covariance/second-moment/quadratic-trace mechanisms',
        'Canonical StdGaussianMoment.integrable_norm_sq_and_integral_stdGaussian and exact Mathlib Gaussian variance/coordinate APIs',
        'Compiled current producer/private consumer parent sets'],
    'reason': 'This is an actual specialization/composition of the existing Gaussian covariance, L² and finite integral APIs, joined to the already canonical C7 and GridAlias. No new cross-domain hypothesis/conclusion transport is established. Gaussian symmetry/hidden-information/quadratic-oracle families do not imply these moments; no conceptual or formal edge to those families is invented.',
    'same_compiled_declaration_policy': 'One new actual Gaussian means node; existing C7/GridAlias declarations reused, private consumer is not a Registry node. No conceptual edge substitutes for an exact compiled call.'}
put(E / 'postproof-conceptual-mirror-audit.json', dump(mirror))
baseline = json.loads((W / 'preproof-baseline.json').read_bytes())
put(E / 'compact-preproof-environment-and-preservation.json', dump({k: baseline[k] for k in
    ['observed_utc', 'working_HEAD', 'Lean_actual', 'manifest', 'packages', 'ledger', 'protected_shared_hashes', 'meaning_lookup_exposure']}))
payload = []
for folder in [W / 'independent-source-graph', W / 'independent-topology-challenge']:
    payload.extend(p for p in sorted(folder.rglob('*')) if p.is_file() and '__pycache__' not in p.parts)
allowed = {'statement-seal-v1.json', 'statement-seal-v2.json', 'producer-signature.txt', 'consumer-signature.txt',
    'multivariateGaussian-standard-definition.txt', 'StatementFormation.lean.gz', 'retained-producer-v1.lean.gz',
    'retained-producer-v2.lean.gz', 'root-preproof-admission-grant.json', 'KernelAndExactMeaning.lean',
    'root-raw-source-scope-readback.json'}
payload.extend(p for p in sorted(W.iterdir()) if p.is_file() and (p.name in allowed or p.suffix == '.py'))
assert all(not re.search(rb'wxid_[a-z0-9]{8,}', p.read_bytes()) for p in payload)
archive = E / 'local-proof-source-graph-and-retained-failures.lossless.tar.gz'
assert not archive.exists()
with tarfile.open(archive, 'w:gz') as t:
    for p in payload:
        t.add(p, arcname=str(p), recursive=False)
with tarfile.open(archive, 'r:gz') as t:
    for p in payload:
        assert t.extractfile(str(p)).read() == p.read_bytes(), p
put(E / 'local-proof-archive-manifest.json', dump({'archive': ref(archive), 'files': [ref(p) for p in payload],
    'scope': 'Selected mathematical source/coverage/topology/HOLD-successor, statement formation, proof failure history and tools. Private full-ledger/foreign ownership snapshots intentionally remain local; compact hash preservation summary is separate. No blind decoder/source verdict or integration credit.'}))
actual = []
checkdir = E / 'actual-local-checks'
for p in sorted(Path('.astis/huanjian-resume-20261103').glob('*-gaussian-moments-*.receipt.json')):
    d = json.loads(p.read_bytes())
    log = Path(d['log'])
    raw = log.read_bytes()
    assert sha(raw) == d['log_sha256']
    put(checkdir / p.name, p.read_bytes())
    put(checkdir / (log.name + '.gz'), gzip.compress(raw, mtime=0))
    actual.append({'receipt': ref(checkdir / p.name), 'actual_exit_code': d['exit_code'], 'raw_log_sha256': sha(raw)})
put(E / 'actual-local-checks-manifest.json', dump({'actual_checks': actual,
    'scope': 'Individual real exit codes/logs, including two producer elaboration failures; no aggregate/site/sourceV credit.'}))
before = L.read_bytes()
states = adv._replay_advances([json.loads(x) for x in before.splitlines()])
assert states[ADV]['state'] == 'EXPLORING' and states[ADV]['owner_id'] == OWNER
for p, h in baseline['all_frontier_hashes'].items():
    assert sha(Path(p).read_bytes()) == h, p
for p, h in baseline['protected_shared_hashes'].items():
    assert sha(Path(p).read_bytes()) == h, p
cellraw = C.read_bytes()
cell = json.loads(cellraw)
boundary = 'Actual diagonal Gaussian norm/Q integrability and both expectation-to-grid identities, plus a genuine Gaussian alias-supported summable series consumer, compile with exact literal types and standard recursive axioms. Independent blind decoding/fresh source/whole-module/sourceV remain pending; no source verification, shared latest-main integration/site/browser/remote publication or purification is claimed. Closed C8 means, fourth moments/independence/variances/bias, rotated/Krylov/adaptive laws, both full main bounds and real oracle/TV/precision/deterministic-cap/expected-cost adapters remain open.'
ma = {'status': 'none-found', 'discovery_ids': [], 'evidence': str(E / 'postproof-conceptual-mirror-audit.json')}
evidence = {'result_kind': 'theorem-edge', 'theorem_delta': cell['target_statement'],
    'lean_files': [str(prod), str(test)], 'lean_declarations': [name], 'publication_declarations': [name],
    'focused_checks': checks, 'truth_boundary': boundary, 'conceptual_mirror_audit': ma,
    'actual_consumer': 'Actual private Gaussian alias series materially uses new means producer, canonical C7 and GridAlias; actual Q-integrability/Gaussian integral, weighted absolute convergence, finite scalar exchange and supported Summable are produced.',
    'source_VERIFIED_or_integration': False}
adv.transition_advance(ADV, 'PROVED_LOCAL', worker_id=OWNER, evidence=evidence)
after = L.read_bytes()
assert after.startswith(before)
append = after[len(before):]
assert len(append.splitlines()) == 1
new = adv._replay_advances([json.loads(x) for x in after.splitlines()])
assert new[ADV]['state'] == 'PROVED_LOCAL'
assert {k: v for k, v in new.items() if k != ADV} == {k: v for k, v in states.items() if k != ADV}
put(E / 'frontier-before-PROVED_LOCAL.raw.json.gz', gzip.compress(cellraw, mtime=0))
put(E / 'actual-PROVED_LOCAL-append.exact.jsonl', append)
capsule = {'state': 'PROVED_LOCAL_NOT_SOURCE_VERIFIED', 'advance_id': ADV, 'owner': OWNER,
    'actual_normal_PROVED_LOCAL_API_calls': 1, 'append_sha256': sha(append), 'foreign_SAU_states_preserved': len(states) - 1,
    'producer': {**ref(prod), 'declaration': name, 'actual_public_ASTIS_parents': []},
    'private_consumer': {**ref(test), 'actual_public_ASTIS_parents': record['actual_public_ASTIS_private_consumer_parents'], 'Registry_node': False},
    'actual_checks': checks, 'exact_literal_signatures_kernel_applied': True,
    'actual_recursive_kernel_axioms': ['propext', 'Classical.choice', 'Quot.sound'],
    'generated_auxiliaries': 'Actual types, direct constants, complete proof Expr representations and recursive axioms retained in the actual kernel log; not extra public canonical nodes.',
    'authored_fake_closure_scan': {'files': [str(prod), str(test)], 'hits': 0},
    'source_to_lean_map': ref(E / 'source-to-lean-map.json'), 'conceptual_mirror_audit': ma,
    'compile_scope': record['compile_scope'], 'truth_boundary': boundary,
    'source_VERIFIED_or_integration_or_purification_or_Goal': False}
put(E / 'local-proof-capsule.json', dump(capsule))
cell['status'] = 'proved_locally'
cell['evidence'].update({'execution_boundary': boundary, 'focused_checks': [x['receipt']['path'] for x in checks],
    'local_proof_capsule': str(E / 'local-proof-capsule.json'), 'actual_compiled_public_ASTIS_producer_parents': [],
    'actual_compiled_public_ASTIS_consumer_parents': record['actual_public_ASTIS_private_consumer_parents'],
    'publication_binding_sha256': record['publication_binding_sha256']})
cell['statement_seal']['status'] = 'EXACT_ORIGINAL_SIGNATURES_COMPILED_LOCAL_INDEPENDENT_WHOLE_MODULE_REVIEW_PENDING'
cell['source_proof_coverage'].update({'preproof_internal_obligation_list_is_preserved_phase_history': True,
    'source_to_lean_map': ref(E / 'source-to-lean-map.json'), 'current_compiled_scope': {
        'producer': 'Actual Gaussian norm/Q integrability and expectation-to-grid means',
        'consumer': 'Actual Gaussian supported alias-series expectation with Summable', 'source_VERIFIED': False}})
search = 'Post-admission local and fresh3c31 official-main declaration search found no identical actual diagonal Gaussian means node. Reused pinned Mathlib multivariateGaussian coordinate variance, IsGaussian.memLp_dual, integral_id_multivariateGaussian, diagonal positive-definite/inverse and finite-integral APIs. StdGaussianMoment is only standard covariance identity and is not a duplicate adapter; no generic private copy was created.'
cell['reuse_plan']['searched_existing'].append(search)
cell['shared_floor_audit']['searched'].append(search)
cell['reuse_plan']['known_consumers'] = ['Actual compiled private actual_gaussian_cosine_alias_series; new Gaussian means+C7+GridAlias all materially used.']
cell['reuse_plan']['planned_consumers'] = ['Closed FactC8 Gaussian means and Lemma4.5, not yet compiled.']
cell['shared_floor_audit']['notes'] = 'Reuse canonical Mathlib Gaussian/covariance/L² primitives. One literal source adapter; no duplicate moment wrapper or new generic shared leaf.'
cell['conceptual_mirror_audit'] = ma
cell['source_detail_audit']['gap'] = 'Selected actual Gaussian means and Gaussian alias-series precursor locally discharged. Closed tails/fourth moments/variance/bias and broader laws remain outside. Independent whole-module source review and sourceV pending.'
cell['source_detail_audit']['fidelity_boundary'] = boundary
C.write_bytes(dump(cell))
print(json.dumps({'state': 'PROVED_LOCAL', 'append_sha256': sha(append), 'producer': ref(prod), 'consumer': ref(test),
    'source_VERIFIED': False, 'archive_sha256': sha(archive.read_bytes())}))
