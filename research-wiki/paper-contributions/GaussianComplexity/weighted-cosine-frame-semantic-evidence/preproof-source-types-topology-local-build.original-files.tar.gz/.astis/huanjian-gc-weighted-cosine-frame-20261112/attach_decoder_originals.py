"""Attach exact source-blind originals and export a fresh anti-anchored packet."""
from pathlib import Path
import hashlib
import json
import sys

sys.dont_write_bytecode = True
sys.path.insert(0, 'tools')
import astis_semantic_roundtrip as semantic
import astis_publication as publication

evidence = Path('research-wiki/paper-contributions/GaussianComplexity/weighted-cosine-frame-semantic-evidence')
phase = Path('.astis/semantic-neutral-20261112/wf_decode_3be7')
slug = 'huanjian-gaussian-weighted-cosine-frame'
audit_path = Path('research-wiki/semantic-roundtrip/audits') / (slug + '.json')
sha = lambda raw: hashlib.sha256(raw).hexdigest()
dump = lambda value: (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode()


def create(path, raw):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as out:
        out.write(raw)


manifest_raw = (phase / 'manifest.json').read_bytes()
assert sha(manifest_raw) == '1e25d191dfa1d935d047ff7fe6bd824dcd8dcd9f6abf568a17e4a8ba700d111b'
manifest = json.loads(manifest_raw)
for item in manifest['artifacts']:
    path = Path(item['path'])
    raw = path.read_bytes()
    assert path.parent.resolve() == phase.resolve()
    assert len(raw) == item['bytes'] and sha(raw) == item['sha256']
run_raw = (phase / 'run_transcript.json').read_bytes()
text_raw = (phase / 'reconstructed_theorem.txt').read_bytes()
assert sha(run_raw) == '0532c467b40cfc0d3b70d22d0def8cba818d6302aab01e753d3d8f66ddbf1143'
assert sha(text_raw) == 'd95ee97cf14b15bf76b2ef1e2946c5d6e7b49b072a2700a80b2b94bdfb14c279'
run = json.loads(run_raw)
reconstruction = json.loads((phase / 'reconstruction.json').read_bytes())
input_raw = (phase / 'input.json').read_bytes()
packet = json.loads(input_raw)
assert run['input_raw_sha256'] == sha(input_raw)
assert run['input_canonical_packet_sha256'] == packet['packet_sha256']
assert run['actor_identity']['agent_task_path'] == '/root/neutral_decode_3be7'
assert run['source_text_visible'] is False
assert reconstruction['reconstructed_theorem_text'].encode() == text_raw
assert reconstruction['decoder_run_sha256'] == sha(run_raw)
audit = json.loads(audit_path.read_bytes())
assert not audit['reconstruction'] and audit['verdict'] == 'pending'
assert sha(audit['lean']['statement'].encode()) == run['anonymous_statement_sha256']
for filename in ('input.json', 'reconstructed_theorem.txt', 'run_transcript.json',
                 'reconstruction.json', 'manifest.json', 'hash_receipt.json'):
    create(evidence / 'decoder-originals/wf_decode_3be7' / filename, (phase / filename).read_bytes())
audit['state'] = 'blind-reconstructed'
audit['reconstruction'] = {
    'text': text_raw.decode(), 'text_sha256': sha(text_raw),
    'decoder': run['actor_identity']['agent_task_path'],
    'decoder_run_sha256': sha(run_raw),
    'decoder_packet_sha256': packet['packet_sha256'],
    'source_text_visible': False,
    'lean_statement_sha256': run['anonymous_statement_sha256'],
    'input_artifacts': ['lean-statement', 'approved-definition-context'],
    'run_artifact': str(evidence / 'decoder-originals/wf_decode_3be7/run_transcript.json'),
}
audit_path.write_bytes(dump(audit))
assert semantic.decoder_packet(audit) == packet
review_packet = semantic.semantic_reviewer_packet(audit)
review_path = evidence / 'anti-anchored-reviewer-packet.json'
create(review_path, dump(review_packet))
publication.check_advance([audit['lean']['declaration']], reviewed=False)
record = {
    'original_input_sha256': sha(input_raw), 'original_run_sha256': sha(run_raw),
    'original_reconstructed_text_sha256': sha(text_raw),
    'original_manifest_sha256': sha(manifest_raw), 'all_originals_unchanged': True,
    'run_hash_convention': 'SHA256 of exact original frozen run_transcript.json bytes. No root-authored replacement decoder run.',
    'independent_decoder': run['actor_identity']['agent_task_path'],
    'source_text_visible': False,
    'publication_binding_sha256': audit['publication_binding_sha256'],
    'anti_anchored_packet': str(review_path),
    'anti_anchored_raw_sha256': sha(review_path.read_bytes()),
    'anti_anchored_packet_sha256': review_packet['packet_sha256'],
}
create(evidence / 'decoder-original-custody.json', dump(record))
print(json.dumps(record))
