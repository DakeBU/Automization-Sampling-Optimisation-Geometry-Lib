from pathlib import Path
from html.parser import HTMLParser
import hashlib, json, sys
sys.dont_write_bytecode = True
from extract_phase1 import ROOT, Readable

manifest=json.loads((ROOT/'raw_slice_manifest.json').read_text())

class Inventory(HTMLParser):
    VOID={'area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr'}
    def __init__(self,sid,text,base):
        super().__init__(convert_charrefs=True)
        self.sid=sid; self.text=text; self.base=base; self.stack=[]; self.rows=[]
        self.lines=[0]
        for i,c in enumerate(text):
            if c=='\n': self.lines.append(i+1)
    def pos(self):
        line,column=self.getpos()
        return self.lines[line-1]+column
    def wanted(self,t,a):
        return t in ['h2','h3','h4','h5','h6','p','math','cite'] or (t=='table' and 'ltx_equation' in a.get('class','')) or (t=='div' and any(c in a.get('class','').split() for c in ['ltx_theorem','ltx_proof']))
    def handle_starttag(self,t,attrs):
        a=dict(attrs); start=self.pos()
        rec={'tag':t,'attrs':a,'start':start,'ancestor_ids':[v['attrs']['id'] for v in self.stack if v['attrs'].get('id')]}
        if t not in self.VOID:self.stack.append(rec)
    def handle_startendtag(self,t,attrs):
        pass
    def handle_endtag(self,t):
        if t in self.VOID:return
        assert self.stack and self.stack[-1]['tag']==t,(self.sid,t,self.stack[-1] if self.stack else None)
        rec=self.stack.pop(); a=rec['attrs']
        if not self.wanted(t,a):return
        end=self.text.index('>',self.pos())+1
        raw=self.text[rec['start']:end].encode('utf-8')
        parser=Readable(); parser.feed(raw.decode('utf-8'))
        record={'source_section':self.sid,'tag':t,'id':a.get('id'),'class':a.get('class'),'ancestor_ids':rec['ancestor_ids'],'section_byte_start':len(self.text[:rec['start']].encode()),'section_byte_end':len(self.text[:end].encode()),'raw_sha256':hashlib.sha256(raw).hexdigest(),'readable':parser.result().strip()}
        record['source_byte_start']=self.base+record['section_byte_start']
        record['source_byte_end']=self.base+record['section_byte_end']
        if t=='math':
            record['latex_alttext']=a.get('alttext')
            record['display']=a.get('display')
        if t=='cite':record['bibliography_links']=[v.split('"')[0] for v in raw.decode().split('href="#')[1:]]
        record['disposition']='NAVIGATION' if t.startswith('h') else 'SOURCE_RECORDED'
        self.rows.append(record)

rows=[]; summary={}
for rec in manifest['slices']:
    if rec['id']=='bib.bib3':continue
    p=Inventory(rec['id'],(ROOT/rec['file']).read_text(),rec['byte_start'])
    p.feed(p.text)
    assert not p.stack
    p.rows.sort(key=lambda r:(r['source_byte_start'],-r['source_byte_end']))
    rows+=p.rows
    summary[rec['id']]={tag:sum(r['tag']==tag for r in p.rows) for tag in ['p','table','math','cite','div','h2','h3','h5','h6']}
assert all(r.get('latex_alttext') is not None for r in rows if r['tag']=='math')
payload={'schema':'phase1-independent-source-inventory-v1','scope':'S2, S4, A3.SS3 only; bibliography entry separately pinned','notes':['Paragraphs and displays are separate source units. Math entries include inline formulas and displayed subexpressions. Nested records intentionally preserve exact source positions; they do not claim separate theorem credit.','NAVIGATION records are heading structure only. Every paragraph, equation table, math expression, citation and theorem/proof wrapper in the authorized sections is SOURCE_RECORDED.','No implementation, target reconstruction, canonical source graph, audit, lesson or publication metadata was read to construct this inventory.'],'summary':summary,'units':rows}
(ROOT/'source_unit_inventory.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(summary,indent=2))
