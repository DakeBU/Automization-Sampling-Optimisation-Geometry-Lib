import AutoSamplingTheory.ExampleCases.ProximalBPS.ActualAbsoluteNextEventTime
import Mathlib.MeasureTheory.Constructions.Pi

/-! Private algebra for the finite-prefix induction. All inputs here will be
instantiated by the literal flow/bounce/rate/hazard of the sealed target. -/
namespace OrderedAlgebra92
open MeasureTheory
open scoped NNReal ENNReal
noncomputable section
set_option autoImplicit false

private def state {Z : Type*} (step : ℝ → Z → Z) (z₀ : Z) (n : ℕ) (t : Fin n → ℝ) :
    Fin (n+1) → Z :=
  Fin.induction z₀ (fun i z => step
    (t i - (Fin.cons (0 : ℝ) t : Fin (n+1) → ℝ) i.castSucc) z)

private theorem state_snoc_prefix {Z : Type*} (step : ℝ → Z → Z) (z₀ : Z)
    (n : ℕ) (t : Fin n → ℝ) (u : ℝ) (j : Fin (n+1)) :
    state step z₀ (n+1) (Fin.snoc t u) j.castSucc = state step z₀ n t j := by
  induction j using Fin.induction with
  | zero => rfl
  | succ i ih =>
    rw [← Fin.succ_castSucc]
    change step ((Fin.snoc t u : Fin (n+1) → ℝ) i.castSucc -
      (Fin.cons (0 : ℝ) (Fin.snoc t u) : Fin (n+2) → ℝ) i.castSucc.castSucc)
      (state step z₀ (n+1) (Fin.snoc t u) i.castSucc.castSucc) =
      step (t i - (Fin.cons (0 : ℝ) t : Fin (n+1) → ℝ) i.castSucc)
        (state step z₀ n t i.castSucc)
    rw [ih, Fin.snoc_castSucc, Fin.cons_snoc_eq_snoc_cons, Fin.snoc_castSucc]

private theorem state_snoc_last {Z : Type*} (step : ℝ → Z → Z) (z₀ : Z)
    (n : ℕ) (t : Fin n → ℝ) (u : ℝ) :
    state step z₀ (n+1) (Fin.snoc t u) (Fin.last (n+1)) =
      step (u - (Fin.cons (0 : ℝ) t : Fin (n+1) → ℝ) (Fin.last n))
        (state step z₀ n t (Fin.last n)) := by
  rw [show Fin.last (n+1) = (Fin.last n).succ from rfl]
  change step ((Fin.snoc t u : Fin (n+1) → ℝ) (Fin.last n) -
    (Fin.cons (0 : ℝ) (Fin.snoc t u) : Fin (n+2) → ℝ) (Fin.last n).castSucc)
    (state step z₀ (n+1) (Fin.snoc t u) (Fin.last n).castSucc) = _
  rw [Fin.snoc_last, Fin.cons_snoc_eq_snoc_cons, Fin.snoc_castSucc, state_snoc_prefix]

private def weight {Z : Type*} (step : ℝ → Z → Z) (factor : Z → ℝ → ℝ)
    (z₀ : Z) (n : ℕ) (t : Fin n → ℝ) : ℝ :=
  ∏ i : Fin n, factor (state step z₀ n t i.castSucc)
    (t i - (Fin.cons (0 : ℝ) t : Fin (n+1) → ℝ) i.castSucc)

private theorem weight_snoc {Z : Type*} (step : ℝ → Z → Z) (factor : Z → ℝ → ℝ)
    (z₀ : Z) (n : ℕ) (t : Fin n → ℝ) (u : ℝ) :
    weight step factor z₀ (n+1) (Fin.snoc t u) = weight step factor z₀ n t *
      factor (state step z₀ n t (Fin.last n))
        (u - (Fin.cons (0 : ℝ) t : Fin (n+1) → ℝ) (Fin.last n)) := by
  simp only [weight, Fin.prod_univ_castSucc]
  rw [state_snoc_prefix, Fin.snoc_last, Fin.cons_snoc_eq_snoc_cons, Fin.snoc_castSucc]
  congr 1
  apply Finset.prod_congr rfl
  intro i _
  simp only [state_snoc_prefix, Fin.snoc_castSucc]


private def timedHistory {Z : Type*} (step : ℝ → Z → Z) (z₀ : Z)
    (n : ℕ) (t : Fin n → ℝ) : Fin (n+1) → ((ℝ≥0 × Z) ⊕ Unit) :=
  fun j => Sum.inl (Real.toNNReal ((Fin.cons (0 : ℝ) t : Fin (n+1) → ℝ) j),
    state step z₀ n t j)

private theorem timedHistory_snoc {Z : Type*} (step : ℝ → Z → Z) (z₀ : Z)
    (n : ℕ) (t : Fin n → ℝ) (u : ℝ)
    (ht : 0 ≤ (Fin.cons (0 : ℝ) t : Fin (n+1) → ℝ) (Fin.last n))
    (hu : (Fin.cons (0 : ℝ) t : Fin (n+1) → ℝ) (Fin.last n) ≤ u) :
    timedHistory step z₀ (n+1) (Fin.snoc t u) =
      Fin.snoc (timedHistory step z₀ n t)
        (Sum.inl (Real.toNNReal ((Fin.cons (0 : ℝ) t : Fin (n+1) → ℝ) (Fin.last n)) +
          Real.toNNReal (u - (Fin.cons (0 : ℝ) t : Fin (n+1) → ℝ) (Fin.last n)),
          step (u - (Fin.cons (0 : ℝ) t : Fin (n+1) → ℝ) (Fin.last n))
            (state step z₀ n t (Fin.last n)))) := by
  funext j
  induction j using Fin.lastCases with
  | last =>
    simp only [timedHistory, Fin.snoc_last, Fin.cons_snoc_eq_snoc_cons, state_snoc_last]
    congr 2
    apply NNReal.eq
    simp only [NNReal.coe_add, Real.coe_toNNReal _ ht,
      Real.coe_toNNReal _ (sub_nonneg.mpr hu), Real.coe_toNNReal _ (ht.trans hu)]
    ring
  | cast i =>
    simp only [timedHistory, Fin.snoc_castSucc, Fin.cons_snoc_eq_snoc_cons,
      state_snoc_prefix]

private theorem ordered_last_nonneg (n : ℕ) (t : Fin n → ℝ)
    (ht : StrictMono (Fin.cons (0 : ℝ) t)) :
    0 ≤ (Fin.cons (0 : ℝ) t : Fin (n+1) → ℝ) (Fin.last n) := by
  have h := ht.monotone (Fin.zero_le (Fin.last n))
  simpa only [Fin.cons_zero] using h

private theorem weight_snoc_ofReal {Z : Type*} (step : ℝ → Z → Z)
    (factor : Z → ℝ → ℝ) (z₀ : Z) (n : ℕ) (t : Fin n → ℝ) (u : ℝ)
    (hweight : 0 ≤ weight step factor z₀ n t) :
    ENNReal.ofReal (weight step factor z₀ (n+1) (Fin.snoc t u)) =
      ENNReal.ofReal (weight step factor z₀ n t) *
      ENNReal.ofReal (factor (state step z₀ n t (Fin.last n))
        (u - (Fin.cons (0 : ℝ) t : Fin (n+1) → ℝ) (Fin.last n))) := by
  rw [weight_snoc, ENNReal.ofReal_mul hweight]

end
end OrderedAlgebra92
