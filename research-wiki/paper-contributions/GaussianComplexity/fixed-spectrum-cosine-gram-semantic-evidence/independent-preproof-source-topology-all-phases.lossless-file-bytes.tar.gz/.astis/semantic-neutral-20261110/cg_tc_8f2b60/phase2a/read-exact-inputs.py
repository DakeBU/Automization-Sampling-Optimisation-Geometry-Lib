from pathlib import Path
import hashlib
import json
import stat

base = Path(__file__).resolve().parent
repo = Path('/Users/zhouhuanjian/ASTIS-GC')
input_dir = repo / '.astis/huanjian-gc-fixed-spectrum-cosine-gram-20261110'
specs = [
 ('strict-statement-projection.json',6296,'8c881cf422b5c637472f868839a93849468c203a8e0f8cedabcf40139136c549'),
 ('additional-canonical-Gaussian-definitions.json',1299,'70d5c296f08f41d214fa9baae07f5601787e0d4ffcb087756e0d22743ef0ca51'),
 ('multivariateGaussian-literal-definition.txt',566,'0d32e6c37ec13dc0bdbce701ed77a7e2da591a748c8d8f92eb81a72cc2228171')
]
records = []
lines = []
for name, size, digest in specs:
    path = input_dir / name
    b = path.read_bytes()
    actual = hashlib.sha256(b).hexdigest()
    assert len(b) == size, (name,len(b),size)
    assert actual == digest, (name,actual,digest)
    (base / name).write_bytes(b)
    item = {'path':str(path),'snapshot':name,'bytes':len(b),'sha256':actual}
    records.append(item)
    lines += ['INPUT '+json.dumps(item),b.decode()]
raw = repo / '.astis/huanjian-resume-20261103/2610.20492v1.html'
raw_bytes = raw.read_bytes()
assert len(raw_bytes)==951991
assert hashlib.sha256(raw_bytes).hexdigest()=='6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
phase1 = base.parent / 'phase1'
manifest = phase1 / 'manifest.json'
manifest_bytes = manifest.read_bytes()
assert hashlib.sha256(manifest_bytes).hexdigest()=='d67f2864ba332e90e91cc8ba16c09db822f5229e0526b9223e6e920b607bca91'
frozen = json.loads(manifest_bytes)
for entry in frozen['artifacts']:
    p = phase1 / entry['path']
    assert hashlib.sha256(p.read_bytes()).hexdigest()==entry['sha256'],entry['path']
    assert len(p.read_bytes())==entry['bytes'],entry['path']
    assert stat.S_IMODE(p.stat().st_mode)==0o444,entry['path']
assert stat.S_IMODE(manifest.stat().st_mode)==0o444
assert stat.S_IMODE(phase1.stat().st_mode)==0o555
checks = {'raw_sha256':hashlib.sha256(raw_bytes).hexdigest(),'raw_bytes':len(raw_bytes),
          'phase1_manifest_sha256':hashlib.sha256(manifest_bytes).hexdigest(),
          'phase1_all_artifact_bytes_hashes_modes_match':True,
          'phase1_files_0444':len(frozen['artifacts'])+1,'phase1_directory_mode':'0555'}
lines.append('PRIOR FREEZE AND RAW VERIFICATION '+json.dumps(checks))
(base / 'input-verification.json').write_text(json.dumps({'inputs':records,'prior_freeze_check':checks},indent=2)+'\n')
stdout='\n\n'.join(lines)+'\n'
(base / 'read-exact-inputs.stdout.txt').write_text(stdout)
print(stdout,end='')
