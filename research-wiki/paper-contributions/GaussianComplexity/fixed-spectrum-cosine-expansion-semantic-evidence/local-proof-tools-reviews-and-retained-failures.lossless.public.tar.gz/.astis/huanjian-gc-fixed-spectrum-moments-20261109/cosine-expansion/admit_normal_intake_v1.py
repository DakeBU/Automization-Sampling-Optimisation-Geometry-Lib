"""Run only after exact independent preproof admission, before proof/API search."""
from pathlib import Path
import gzip, hashlib, json, subprocess, sys
sys.dont_write_bytecode = True
P=Path('.astis/huanjian-gc-fixed-spectrum-moments-20261109/cosine-expansion')
B=Path('research-wiki/paper-contributions/GaussianComplexity')
E=B/'fixed-spectrum-cosine-expansion-semantic-evidence'
C=Path('research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-cosine-expansion.json')
L=Path('runs/substantive_advances.jsonl')
ADV='ASTIS-SA-20261109-GaussianComplexityFixedSpectrumCosineExpansion'
OWNER='huanjian_gc_20261109_fixed_spectrum_cosine_expansion'
sha=lambda b:hashlib.sha256(b).hexdigest()
dump=lambda x:(json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode()
def ref(p):return {'path':str(p),'sha256':sha(p.read_bytes())}
assert not C.exists()
grant=json.loads((P/'root-preproof-admission-grant-v1.json').read_bytes())
assert grant['source_graph_and_distinct_topology_admitted'] is True
assert grant['target_proof_or_API_search_has_started'] is False
sealpath=B/'fixed-spectrum-cosine-expansion-statement-seal.json'
sealraw=sealpath.read_bytes(); assert sha(sealraw)==grant['seal_sha256']=='748538057656b235eed54272a87e66f4bf87bdbeb79a9831795b53e72ae74a36'
seal=json.loads(sealraw)
for r in grant['actual_frozen_review_inputs']:
    assert sha(Path(r['path']).read_bytes())==r['sha256'],r['path']
baseline=json.loads((P/'baseline.json').read_bytes()); before=L.read_bytes()
assert sha(before)==baseline['ledger']['sha256']
for name,h in baseline['all_existing_frontier_raw_hashes'].items():assert sha(Path(name).read_bytes())==h,name
for name,h in baseline['protected_shared_raw_hashes'].items():assert sha(Path(name).read_bytes())==h,name
sys.path.insert(0,'tools');import astis_advance as advance
states=advance._replay_advances([json.loads(x) for x in before.splitlines()])
assert states==baseline['all_existing_SAU_states'] and ADV not in states
assert not [k for k,v in states.items() if v['state']=='STABILIZING']
declaration=seal['producer']['name']; prod=seal['producer']['planned_file']; test=seal['actual_private_consumer']['planned_file']
boundary=seal['truth_boundary']
searched=[seal['reuse_boundary'], 'Source-only C7 graph and distinct raw-first topology/binder/definition challenge admitted before target proof/API search; exact Mathlib proof retrieval remains next.']
cell={
 'schema_version':3,'cell_id':C.stem,'route':'samplewiki-route','mode':'faithfulPaper',
 'title':'Actual inverse-spectrum cosine expansion and finite-grid interchange',
 'source_anchor':'arXiv2610.20492v1 FactC.7/A3.Ex133-137; C8 A3.Ex140 and A3.SS3.p4.2 actual finite-grid consumer',
 'target_statement':seal['producer']['signature'],'status':'claimed','owner_id':OWNER,'advance_id':ADV,'parents':[],
 'consumers':['Sealed actual private finite-grid reciprocal-eigenvalue cosine-series consumer; not compiled yet.','Future C8 exact finite-grid moments and Lemma4.5 target-moment calculation; not certified by this packet.'],
 'shared_floor_audit':{'searched':searched,'classification':'adapt','decision':'adapt_existing','canonical_declaration':declaration,'canonical_shared_cell':'','notes':'Source-parameter adapter; reuse actual canonical geometric/convergence APIs after admission, with no extra public radius/convergence premise.'},
 'reuse_plan':{'searched_existing':searched,'reused_declarations':[],'new_shared_declarations':[],
    'known_consumers':[],'planned_consumers':['actual_inverse_grid_cosine_series; genuine finite-sum/tsum interchange required.'],
    'no_duplicate_wrapper':True,'decision_reason':'Literal kappa-only source C7 plus real hard-grid interchange. No implementation or certified library dependency claimed yet.'},
 'reader_contract':{'reference_standard':'textbook/chapter-01/section-1-3.html','source_ordered':True,'source_statement_adjacent':True,'natural_language_formula_proof':True,'hidden_assumptions_visible':True,'lean_collapsed':True,'external_dependencies_visible':True},
 'graph_contribution':{'lean_view':'new-node','overview_view':'no-change-with-reason','functor_view':'none-found','edge_semantics':'formal-solid; overlays-dashed','color_semantics':'evidence-status; library-scope','focus_targets':[declaration],'visual_review':'Preproof source topology only; no compiled node or website acceptance. Postproof conceptual audit pending; no new overlay is asserted.'},
 'source_detail_audit':{'primary_edition':'arXiv2610.20492v1','primary_anchor':'A3.Thmtheorem7;A3.Ex133-137;A3.SS3.p4.2','detail_status':'omitted',
    'gap':'Short source proof invokes real/complex geometric convergence, parameter/nonzero algebra, geometric majorant uniform-tail test and finite weighted sum/tsum interchange. All remain internally produced obligations, not source binders.',
    'consulted':[{'source':'Pinned raw original and independently reconstructed source graph plus distinct topology/binder review','anchor':'C7 and bounded C8 consumer','hypothesis_adapter':'Exactly source kappa>=2; literal grid d>=2 for private consumer. Frequency-all-n is a private generalized intermediate, not the C8 moment claim.'}],
    'fidelity_boundary':boundary},
 'learning_contract':{'control_plane_math_authority':False,'process_memory_checked':True,'process_memory_ids':[],
    'failure_class':'IMPLEMENTATION_FAILED','salvage':{'required':True,'status':'completed','reason':'Only initial type-formation parser rejected reserved lambda let-name. v2 alpha-renamed eigenvalue and formed both exact Prop types; failed recovery output retained and carries no proof credit. No mathematical proof attempt yet.','promoted_fragments':['Exact v2 interfaces only, not a proved declaration.'],'discarded_fragments':[]},
    'parallelism':{'decision':'serial','direction_fingerprints':[],'expected_information_gain':'Root sole mathematical worker; source author and distinct raw-first challenger handle source uncertainty only.','shared_verified_context_digest':seal['producer']['signature_sha256']},
    'cross_route_blind_spot_audit':{'required':False,'status':'not-applicable','evidence':'','canonical_route':'','selection_reason':'No parallel proof construction.'},
    'reader_backpressure':{'purification_status':'pending','exposition_seal_status':'pending','exposition_evidence':'','source_expansion_nodes':[],'lean_expansion_nodes':[],'assumptions_preserved':True,'boundary_preserved':True}},
 'statement_seal':{'path':str(sealpath),'sha256':sha(sealraw),'signature_sha256':seal['producer']['signature_sha256'],'status':'EXACT_TYPE_FORMED_INDEPENDENT_PREPROOF_SOURCE_TOPOLOGY_ADMITTED_NO_PROOF'},
 'source_proof_coverage':{'preproof_admission':ref(E/'preproof-source-admission.json'),'internal_obligations_still_unproved':seal['internal_dependencies_not_premises']},
 'evidence':{'execution_boundary':boundary,'focused_checks':[seal['statement_formation']['receipt']['path']],
    'preproof_source_admission':str(E/'preproof-source-admission.json'),'actual_consumer_seal':seal['actual_private_consumer'],
    'independent_verification':'','root_build':'','graph_regeneration':'','pr':''},'blocked':{'reason':'','children':[]}}
assert (E/'preproof-source-admission.json').exists()
proposal=advance.AdvanceProposal(advance_id=ADV,task_id='ASTIS-SW-GAUSSIAN-COMPLEXITY-2026',
 goal='Prove exact source FactC7 with absolute/uniform convergence and actual finite-grid series-interchange consumer.',
 source_anchor=cell['source_anchor'],theorem_delta=seal['producer']['signature'],truth_boundary=boundary,created_by=OWNER,
 dag_inputs=('source:arXiv2610.20492v1:A3.Thmtheorem7/A3.Ex133-137',),
 proposed_files=(prod,test,str(C),'website/content/declaration_lessons/huanjian-fixed-spectrum-cosine-expansion.json','website/content/publications/huanjian-fixed-spectrum-cosine-expansion.json'),
 focused_checks=('lake env lean '+prod,'lake env lean '+test),modes=('source-reading','proof-design','compiler-diagnosis'),
 priority=50,frontier_cell=C.stem,target_declarations=(declaration,))
proposal.validate()
advance.propose_advance(proposal)
advance.transition_advance(ADV,'CLAIMED',worker_id=OWNER,evidence={'exact_statement_seal':ref(sealpath),'preproof_admission':ref(E/'preproof-source-admission.json'),'truth_boundary':boundary})
advance.transition_advance(ADV,'EXPLORING',worker_id=OWNER,evidence={'preproof_admission':ref(E/'preproof-source-admission.json'),'source_graph_and_distinct_topology_admitted':True,'target_proof_API_work_starts_after_this_event':True,'truth_boundary':boundary})
C.write_bytes(dump(cell))
after=L.read_bytes(); assert after.startswith(before); appended=after[len(before):]
assert len(appended.splitlines())==3
newstates=advance._replay_advances([json.loads(x) for x in after.splitlines()])
assert newstates[ADV]['state']=='EXPLORING' and newstates[ADV]['owner_id']==OWNER
assert {k:v for k,v in newstates.items() if k!=ADV}==states
assert not [k for k,v in newstates.items() if v['state']=='STABILIZING']
for name,h in baseline['all_existing_frontier_raw_hashes'].items():assert sha(Path(name).read_bytes())==h,name
for name,h in baseline['protected_shared_raw_hashes'].items():assert sha(Path(name).read_bytes())==h,name
put=E/'normal-EXPLORING-append.exact.jsonl';assert not put.exists();put.write_bytes(appended)
(E/'normal-intake-preservation.json').write_bytes(dump({'normal_API_calls':3,'state':'EXPLORING','advance_id':ADV,'owner':OWNER,
    'before_ledger_sha256':sha(before),'after_ledger_sha256':sha(after),'raw_prefix_preserved':True,
    'foreign_SAU_states_preserved':len(states),'foreign_frontier_files_preserved':len(baseline['all_existing_frontier_raw_hashes']),
    'shared_models_and_discovery_unchanged':True,'STAB':[],'append':ref(put),'new_cell':ref(C),
    'proof_consumer_sourceV_or_integration_credit':False}))
print(json.dumps({'normal_state':'EXPLORING','normal_API_calls':3,'append_sha256':sha(appended),
    'foreign_states_preserved':len(states),'foreign_frontiers_preserved':len(baseline['all_existing_frontier_raw_hashes']),
    'new_source_verdict_or_mathematical_result':False}))
