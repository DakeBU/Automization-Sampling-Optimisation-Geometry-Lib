"""Exact separator-aware conditional guard repair; no helper/browser/API execution."""
from pathlib import Path
import ast, copy, datetime, difflib, gzip, hashlib, io, json, subprocess, tarfile
R=Path('/Users/zhouhuanjian/ASTIS-GC');S=R/'.astis/huanjian-gc-fixed-spectrum-determinant-integration-20261108/independent-reader'
P=R/'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-determinant-integration-20261108/independent-integration-reader-review/proposal'
BASE=P/'canonical-dje-index-supplement/guard-overlay-preparation';O=BASE/'separator-guard-repair'
CORE='55b7b53921b430056db42ef04186d92074f0c49b'
DJE='AutoSamplingTheory.TechnicalLemmas.Measure.DisplacementJacobianEntropy.det_conjStarAlgAut_eq'
DECL='AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumDeterminant.actual_precision_det'
sha=lambda b:hashlib.sha256(b).hexdigest()
assert not O.exists() and subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==CORE
basepath=BASE/'updated-preparation-manifest.json';assert sha(basepath.read_bytes())=='97481c2d6661474125ad1eb69e51848209ec02527bcac9a8ec47d8783df7bee5'
base=json.loads(basepath.read_bytes());before={row['path']:(R/row['path']).read_bytes() for row in base['helpers']}
for row in base['helpers']:assert sha(before[row['path']])==row['raw_sha256']
commonpath=str((S/'det_acceptance_common.py').relative_to(R));parkpath=str((S/'park_existing_verified_once.py').relative_to(R))
assert sha(before[commonpath])=='cb8a5e4306356d4bcf2ae3505836d13e3f3e62176eacb839f62d95565b2461fd'
text=before[commonpath].decode()
needle=" assert now['details']==details and now['search'].replace(DJE.lower(),'',1)==prior['search']"
replacement=""" assert now['details']==details
 inserted=' '+DJE.lower()
 assert now['search'].count(inserted)==1 and now['search'].replace(inserted,'',1)==prior['search']"""
assert text.count(needle)==1;aftercommon=text.replace(needle,replacement,1).encode();ast.parse(aftercommon)
text=before[parkpath].decode();needle="expected=P/'canonical-dje-index-supplement/guard-overlay-preparation/updated-preparation-manifest.json'";replacement="expected=P/'canonical-dje-index-supplement/guard-overlay-preparation/separator-guard-repair/updated-preparation-manifest.json'"
assert text.count(needle)==1;afterpark=text.replace(needle,replacement,1).encode();ast.parse(afterpark)
oldraw=gzip.decompress((BASE/'held-original-39798-graph.json.raw.gz').read_bytes());assert sha(oldraw)=='1a9b4835847a4f587da14989d65a5f7eea3caa4c271783e605903f4caa4098a5'
newraw=(R/'_site/data/underlying-lean-graph.json').read_bytes();old=json.loads(oldraw);new=json.loads(newraw)
oldnodes={x['id']:x for x in old['nodes']};newnodes={x['id']:x for x in new['nodes']};parent='decl:'+DJE;child='decl:'+DECL;module='module:AutoSamplingTheory.TechnicalLemmas.Measure.DisplacementJacobianEntropy'
assert parent not in oldnodes and set(newnodes)==set(oldnodes)|{parent}
assert newnodes[parent]['kind']=='declaration' and newnodes[parent]['status']=='compiled'
assert 'compilation-only-index' in newnodes[parent]['summary'] and 'legacy-source-audit-debt' in newnodes[parent]['summary']
for ident,value in oldnodes.items():
 if ident!=child:assert newnodes[ident]==value,ident
prior=oldnodes[child];now=newnodes[child]
assert set(prior)==set(now) and all(prior[k]==now[k] for k in prior if k not in ['details','search'])
details=copy.deepcopy(prior['details']);refs=[x for x in details if x['label']=='References (name scan; incomplete)'];assert len(refs)==1 and refs[0]['value']=='';refs[0]['value']=DJE
assert now['details']==details
assert now['search'].replace(DJE.lower(),'',1)!=prior['search']
inserted=' '+DJE.lower();assert now['search'].count(inserted)==1 and now['search'].replace(inserted,'',1)==prior['search']
triples=lambda graph:{(x['source'],x['target'],x['relation']) for x in graph['edges']}
oldedges=triples(old);newedges=triples(new);assert oldedges<=newedges and newedges-oldedges=={(module,parent,'declares'),(parent,child,'source reference (scanner)')}
assert all(old[k]==new[k] for k in old if k not in ['nodes','edges','counts','publication_inputs_sha256'])
expected=dict(old['counts']);expected['registry_declarations']+=1;expected['nodes']+=1;expected['edges']+=2;assert new['counts']==expected
builderpath='website/scripts/underlying_lean_graph_model_core.py';builder=(R/builderpath).read_bytes();assert builder==subprocess.check_output(['git','show',CORE+':'+builderpath],cwd=R)
buildertext=builder.decode();assert 'node["search"] = short(" ".join(map(str, tags)), 12000).lower()' in buildertext
assert 'text = re.sub(r"\\s+", " ", str(value or "")).strip()' in buildertext
failedpath=R/'.astis/huanjian-resume-20261103/20261108T033827796109Z-fixed-spectrum-determinant-regenerated-parent-graph-preflight.receipt.json';failedraw=failedpath.read_bytes();failed=json.loads(failedraw);failedlogpath=Path(failed['log']);failedlog=failedlogpath.read_bytes()
assert failed['exit_code']==1 and failed['head_before']==failed['head_after']==CORE
assert sha(failedlog)==failed['log_sha256']=='9a94009fd12c4fbca909075bfbc29798175916ce86dcbf9b14a64450836baaf3'
assert 'unchanged_foreign_graph_guard' in failed['command'][-1] and 'AssertionError' in failedlog.decode()
O.mkdir(exist_ok=False)
def archive(name,raw):
 path=O/name;assert not path.exists();data=gzip.compress(raw,mtime=0);path.write_bytes(data);assert gzip.decompress(data)==raw
 return {'path':str(path.relative_to(R)),'raw_sha256':sha(raw),'gzip_sha256':sha(data),'raw_bytes':len(raw)}
after={commonpath:aftercommon,parkpath:afterpark};rows=[];diff=b''
for i,(path,raw) in enumerate(after.items(),1):
 rows.append({'path':path,'before_sha256':sha(before[path]),'proposed_after_sha256':sha(raw),'before_archive':archive(f'path-{i}.before.raw.gz',before[path]),'proposed_after_archive':archive(f'path-{i}.proposed-after.raw.gz',raw)})
 diff+=b''.join(difflib.diff_bytes(difflib.unified_diff,before[path].splitlines(keepends=True),raw.splitlines(keepends=True),fromfile=('a/'+path).encode(),tofile=('b/'+path).encode()))
current={path:after.get(path,raw) for path,raw in before.items()};buf=io.BytesIO();helperrows=[]
with tarfile.open(fileobj=buf,mode='w') as tar:
 for path,raw in current.items():
  if path.endswith('.py'):ast.parse(raw,filename=path)
  if path.endswith('.json'):json.loads(raw)
  info=tarfile.TarInfo(Path(path).name);info.size=len(raw);info.mode=0o644;info.mtime=0;info.uid=info.gid=0;info.uname=info.gname='';tar.addfile(info,io.BytesIO(raw))
  helperrows.append({'path':path,'raw_sha256':sha(raw),'raw_bytes':len(raw),'syntax_check':'ast.parse only' if path.endswith('.py') else 'JSON syntax only' if path.endswith('.json') else 'Preparation documentation only'})
tarraw=gzip.compress(buf.getvalue(),mtime=0);tarpath=O/'updated-conditional-helpers.tar.gz';tarpath.write_bytes(tarraw)
with tarfile.open(fileobj=io.BytesIO(tarraw),mode='r:gz') as tar:
 for path,raw in current.items():assert tar.extractfile(Path(path).name).read()==raw
manifest={'state':'PREPARATION_ONLY_AST_PARSED_NOT_EXECUTED','role':'/root/det_integration_reader','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_verifier_to_preserve':'/root/reader_835194','proof_owner_to_preserve':'huanjian_gc_20261108_fixed_spectrum_determinant','helpers':helperrows,'conditional_application_only':True,'previous_preparation_manifest_sha256':sha(basepath.read_bytes()),'held_graph_archive':base['held_graph_archive'],'supplementary_index_proposal_sha256':base['supplementary_index_proposal_sha256'],'lossless_preparation_archive':{'path':str(tarpath.relative_to(R)),'sha256':sha(tarraw),'members':len(current)},'actual_updated_helper_executions':0,'new_source_verdict_or_parking_authorization':False}
manifestpath=O/'updated-preparation-manifest.json';manifestpath.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
diagnosis={'immutable_core':CORE,'builder_source_sha256':sha(builder),'held_graph_raw_sha256':sha(oldraw),'new_graph_raw_sha256':sha(newraw),'parent_token':inserted,'old_search':prior['search'],'new_search':now['search'],'actual_search_delta':'Exactly one leading-space plus canonicalparent lowercase token; no normalization or strip is used by the proposed equality.','builder_reason':'GraphBuilder.add delegates joined tags to short(), which collapses whitespace and strips before lowercasing. An empty old reference contributes no retained token. The new nonempty reference therefore contributes exactly one separator plus parent name.','all_foreign_nodes_exactly_preserved':len(oldnodes)-1,'only_old_node_changed':child,'parent_node_status':'Existing compilation-only Registry index, visible legacy-source-audit debt','all_old_edges_preserved':len(oldedges),'only_new_edges':[list(x) for x in sorted(newedges-oldedges)],'old_counts':old['counts'],'actual_new_counts':new['counts'],'all_other_graph_metadata_exactly_unchanged':True,'root_failed_preflight_preserved':{'receipt':archive('original-failed-preflight.receipt.json.raw.gz',failedraw),'stdout':archive('original-failed-preflight.stdout.raw.gz',failedlog),'actual_failed_command':failed['command']},'immutable_builder_source':archive('immutable-graph-builder.py.raw.gz',builder),'actual_new_graph_snapshot':archive('actual55b7-graph.json.raw.gz',newraw)}
report={'reviewer':'/root/det_integration_reader','recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'phase':'Bounded exact separator construction diagnosis and conditional privateguard repair; not reader acceptance','verdict':'NO_BLOCKING_OBJECTION_TO_EXACT_SEPARATOR_AWARE_GUARD_REPAIR','diagnosis':diagnosis,'proposed_changes':rows,'raw_diff':archive('exact-separator-guard-repair.diff.raw.gz',diff),'updated_conditional_preparation_manifest':str(manifestpath.relative_to(R)),'updated_conditional_preparation_manifest_sha256':sha(manifestpath.read_bytes()),'updated_archive_sha256':sha(tarraw),'unchanged_guards':['Exact canonical parent identity/uniqueness/compilation-only legacy tags','Exact old foreign node values, child other fields and reference-details insertion','All old edges plus exactly module ownership and one true dashed scanner edge','Exact registry/node/edge counts and all other graph metadata','All prior sourceV/owner/sourceDigest/core/exit/log/foreign protection/38original/39archive/explicit root parking guards'],'browser_checker_unchanged_sha256':'d191bcb9ea513e71e0c2357315dee1821fdcccdab6dc6a2f473d5289589f0766','actual_fixed_helper_import_or_execution':False,'actual_build_site_browser_API_shared_or_ledger_mutations':False,'full_visual_or_local_acceptance_or_sourceV_or_parking_claim':False,'live_common_cb8_and_original_failed_input_preserved':True,'next_root_action':'Review exact two private after payloads and updated manifest; root may explicitly apply. Use the new prepared manifest/parking SHA in later explicit authorization. Source/core55b7 and checker d191 stay unchanged; no full build rerun is needed for this private guard compatibility repair.'}
archive('repair-preparation-driver.py.raw.gz',Path(__file__).read_bytes())
reportpath=O/'conditional-separator-repair-review.json';reportpath.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
for path,raw in before.items():assert (R/path).read_bytes()==raw
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==CORE
print(json.dumps({'review_sha256':sha(reportpath.read_bytes()),'updated_manifest_sha256':sha(manifestpath.read_bytes()),'common_proposed_after_sha256':sha(aftercommon),'park_proposed_after_sha256':sha(afterpark),'updated_archive_sha256':sha(tarraw),'old_graph_nodes':len(oldnodes),'unchanged_foreign_nodes':len(oldnodes)-1,'old_edges_retained':len(oldedges),'exact_new_edges':len(newedges-oldedges),'all_remaining_graph_contracts_pass':True,'live_original_helpers_unchanged':True,'fixed_helper_executions':0},indent=2))
