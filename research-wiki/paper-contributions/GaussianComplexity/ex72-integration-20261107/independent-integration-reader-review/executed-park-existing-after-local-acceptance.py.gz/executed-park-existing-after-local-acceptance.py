"""One explicitly authorized normal API release to the existing source V.

No new mathematical/source verdict, build/browser/remote run, shared write or
frontier mutation is performed. Failure is recorded and never blindly retried.
"""
from pathlib import Path
import contextlib
import datetime
import gzip
import hashlib
import io
import json
import os
import subprocess
import sys
import time
import traceback

sys.dont_write_bytecode = True
ROOT = Path('/Users/zhouhuanjian/ASTIS-GC')
DIR = ROOT / 'research-wiki/paper-contributions/GaussianComplexity/ex72-integration-20261107'
OUT = DIR / 'independent-integration-reader-review'
SOURCE = ROOT / 'research-wiki/paper-contributions/GaussianComplexity/tv-amplification-semantic-evidence/fresh-source-v2'
ADV = 'ASTIS-SA-20261107-GaussianComplexityTVAmplification'
ACTOR = '/root/ex72_integration_reader_review'
PROOF_OWNER = 'huanjian_gc_20261107_ex72'
INTEGRATION_OWNER = 'huanjian_gc_20261107_ex72_integration'
SOURCE_VERIFIER = '/root/ex72_fresh_source_v2'
CORE = 'eff84aa2f702efc804f84066b73b75f47d3d1e56'
MATH = 'ebf76119351b23ef0718fc69aa5081515bab0b52'
SOURCE_METADATA = 'e4a1b8d60822706df62a7d4bab23814d7187c622'
DIGEST = '07faa921512467cb741b614687f132b18f1d8d952acb9807a7a56f7549eda529'
DECL = 'AutoSamplingTheory.ExampleCases.GaussianComplexity.TVAmplification.actual_averaged_tv_lower_bound'
LEDGER = ROOT / 'runs/substantive_advances.jsonl'
DISCOVERIES = ROOT / 'runs/substantive_discoveries.jsonl'
AUDIT = ROOT / 'research-wiki/semantic-roundtrip/audits/huanjian-tv-amplification.json'
CELL = ROOT / 'research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-tv-amplification.json'
REQUEST_PATH = OUT / 'local-integration-parking.request.json'
RECEIPT_PATH = OUT / 'local-integration-parking.normal-api.receipt.json'
assert not REQUEST_PATH.exists() and not RECEIPT_PATH.exists(), 'A parking attempt already exists; never automatically repeat'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def canonical(obj):
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()


def descriptor(path):
    return {'path': str(path.relative_to(ROOT)), 'sha256': sha(path.read_bytes())}


def write_json(path, obj):
    assert not path.exists(), str(path)
    path.write_bytes((json.dumps(obj, ensure_ascii=False, indent=2) + '\n').encode())


def archive(path, raw):
    assert not path.exists(), str(path)
    packed = gzip.compress(raw, compresslevel=9, mtime=0)
    path.write_bytes(packed)
    assert gzip.decompress(path.read_bytes()) == raw
    return {'path': str(path.relative_to(ROOT)), 'sha256': sha(packed), 'raw_sha256': sha(raw), 'raw_bytes': len(raw)}


def head():
    return subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT).decode().strip()


sys.path.insert(0, str(ROOT / 'tools'))
import astis_advance as advance
import astis_publication as publication
import astis_site
assert head() == CORE and astis_site.source_digest() == DIGEST
authorization_path = DIR / 'primary-local-integration-acceptance-and-parking-authorization.json'
authorization_raw = authorization_path.read_bytes()
authorization = json.loads(authorization_raw)
assert authorization['authorized_SAU'] == ADV and authorization['authorized_integration_owner'] == INTEGRATION_OWNER
assert authorization['independent_reader_report_raw_sha256'] == '5ccafe2570f832032cfafae92d7011ecd45dcce44c93151444c69010c9cc0336'
assert authorization['core'] == CORE and authorization['root_actual_original_image_views'] == 5
acceptance_path = OUT / 'actual-local-integration-reader-acceptance.json'
acceptance_raw = acceptance_path.read_bytes()
assert sha(acceptance_raw) == authorization['independent_reader_report_raw_sha256']
acceptance = json.loads(acceptance_raw)
assert len(acceptance['all_14_originals_independently_viewed']) == 14
assert acceptance['core_commit'] == CORE and acceptance['actual_compiled_source_digest'] == DIGEST
assert not acceptance['source_verdict_originated'] and not acceptance['parking_performed']
primary_path = DIR / 'primary-image-inspection.json'
primary = json.loads(primary_path.read_bytes())
assert len(primary['images']) == 5 and primary['core'] == CORE
ledger_before = LEDGER.read_bytes()
assert sha(ledger_before) == 'a47b939e2ad017a9fc5b9ed102455bd996bb9096ec0c7d85bb55d5713cb2dfec' and ledger_before.endswith(b'\n')
states_before = advance._replay_advances(json.loads(r) for r in ledger_before.splitlines())
assert states_before[ADV]['state'] == 'STABILIZING' and states_before[ADV]['owner_id'] == PROOF_OWNER
assert states_before[ADV]['latest_evidence']['integration_owner'] == INTEGRATION_OWNER
assert [k for k, v in states_before.items() if v['state'] == 'STABILIZING'] == [ADV]
foreign_before = {k: v for k, v in states_before.items() if k != ADV}
assert len(foreign_before) == 278
assert canonical(foreign_before) == gzip.decompress((OUT / 'substantive_advances.jsonl.foreign-projection.json.gz').read_bytes())
discoveries_before = DISCOVERIES.read_bytes()
audit_before = AUDIT.read_bytes()
assert sha(audit_before) == '67b1c0484faf78ca170cc65a407bac46d26b40a316daf3cb19edc1cefb6933ab'
audit = json.loads(audit_before)
assert audit['source_review']['reviewer'] == SOURCE_VERIFIER and audit['source_review']['state'] == 'accepted'
source_append = gzip.decompress((SOURCE / 'phase3/verified-append.raw.jsonl.gz').read_bytes())
assert sha(source_append) == '504cc436c70a4e893bf8fcbf1f307061dd365d53945a4f810f7b886e4409bb72'
source_event = json.loads(source_append)
assert source_event['worker_id'] == SOURCE_VERIFIER
source_evidence = source_event['evidence']
assert source_evidence['verified_commit'] == SOURCE_METADATA and source_evidence['gate']['math_candidate_commit'] == MATH
item = next(i for i in publication.load() if i['id'] == 'huanjian-tv-amplification')
binding = publication.binding_digest(item, item['bindings'][0])
assert binding == 'fdfc58efe464c10868cac35682d8bd5202e0fc69f46880f957582e707b667265'
gate_path = DIR / 'actual-root-gate-at-core-commit.json'
gate_raw = gate_path.read_bytes()
gate = json.loads(gate_raw)
assert gate['passed'] and gate['commit'] == CORE and gate['source_digest'] == DIGEST
assert gate_raw == (ROOT / '.astis/site-lean-gate.json').read_bytes()
site_before = (ROOT / '_site/data/build-metadata.json').read_bytes()
assert sha(site_before) == '2705932d9caa6ad459511b5af5bb9e35e858e5208e024f4f93cefa0bf990aa60'
proposal = json.loads((OUT / 'preparation-report-v3.json').read_bytes())
for path, expected in proposal['source_test_publication_lesson_pins'].items():
    raw = (ROOT / path).read_bytes()
    assert sha(raw) == expected and subprocess.check_output(['git', 'show', MATH + ':' + path], cwd=ROOT) == raw
manifest = json.loads((DIR / 'shared-integration-manifest.json').read_bytes())
for row in manifest['paths']:
    assert sha((ROOT / row['path']).read_bytes()) == row['after_sha256']
protected_inputs = json.loads(gzip.decompress((OUT / 'protected-source-content-sha256.json.gz').read_bytes()))
for path, row in protected_inputs.items():
    p = ROOT / path
    raw = os.fsencode(os.readlink(p)) if p.is_symlink() else p.read_bytes()
    assert sha(raw) == row['sha256'], path
frontier_before = {str(p.relative_to(ROOT)): p.read_bytes() for p in (ROOT / 'research-wiki/frontier-cells').glob('*.json')}
assert len(frontier_before) == 438
cell_before = CELL.read_bytes()
assert sha(cell_before) == '4f8ea3fda67573054297f3b66b41673768090ed3a0d7b76b677b59136cf4fc5a'
source_files_before = {str(p.relative_to(ROOT)): sha(p.read_bytes()) for p in SOURCE.rglob('*') if p.is_file()}
assert len(source_files_before) > 100
source_manifest = json.loads((SOURCE / 'phase3/manifest.json').read_bytes())
assert sha((SOURCE / 'phase3/manifest.json').read_bytes()) == '29ac9b98a1736b6c2ba2d08becd30ab3048666a833b6e2d9ea24ca7d49a9a352'
for filename, row in source_manifest['files'].items():
    assert sha((SOURCE / 'phase3' / filename).read_bytes()) == row['sha256'], filename
prefix_archive = archive(OUT / 'before-parking-ledger-prefix.raw.jsonl.gz', ledger_before)
foreign_archive = archive(OUT / 'before-parking-foreign-states.json.gz', canonical(foreign_before))
frontier_archive = archive(OUT / 'before-parking-frontier-hashes.json.gz', canonical({p: sha(raw) for p, raw in frontier_before.items()}))
source_archive = archive(OUT / 'before-parking-source-phase1-3-hashes.json.gz', canonical(source_files_before))

evidence = {
    'verifier_id': ACTOR, 'verified_commit': CORE,
    'parking_kind': 'mechanical-existing-verification-parking-after-local-root-reader-acceptance',
    'authorization': descriptor(authorization_path),
    'original_source_verifier_id': SOURCE_VERIFIER,
    'original_source_verified_metadata_commit': SOURCE_METADATA,
    'original_immutable_mathematical_candidate': MATH,
    'proving_owner_preserved': PROOF_OWNER,
    'released_integration_owner': INTEGRATION_OWNER,
    'publication_declarations': [DECL],
    'gate': {'kind': 'reuse actual core root9646/site/graph/Chrome plus accepted independent14-original image review',
             'actual_core_commit': CORE, 'actual_source_digest': DIGEST,
             'actual_root_certificate': descriptor(gate_path),
             'actual_core_bound_receipts': acceptance['actual_core_bound_receipts'],
             'independent_local_reader_acceptance': descriptor(acceptance_path),
             'primary_five_original_views': descriptor(primary_path),
             'scope': 'Normal reviewed-publication admission now against unchanged targets. No new compilation, browser run or mathematical verdict.'},
    'source_audit': {'kind': 'reuse existing independent fresh source V; zero new source verdicts',
                     'original_source_verifier': SOURCE_VERIFIER,
                     'existing_source_V_receipt': descriptor(SOURCE / 'phase3/actual-source-V-and-preservation-receipt.json'),
                     'existing_source_closeout': descriptor(SOURCE / 'phase3/closeout.json'),
                     'existing_source_review_run': descriptor(SOURCE / 'phase3/independent-review-run.json'),
                     'current_accepted_audit': descriptor(AUDIT), 'publication_binding_sha256': binding,
                     'candidate_audit_was_draft_then': True, 'new_source_verdict': False},
    'semantic_roundtrip_audit': source_evidence['semantic_roundtrip_audit'],
    'fake_closure_scan': {'kind': 'reuse original fresh source scan and actual current-core canonical ASTIS success',
                          'original_source_verifier': SOURCE_VERIFIER,
                          'existing_source_scan': source_evidence['fake_closure_scan'],
                          'actual_root_ASTIS_success_at': CORE,
                          'actual_source_bytes_unchanged': True, 'new_scan_or_source_verdict_created': False},
    'local_acceptance_scope': 'Actual Ex72 local root/Registry615/site/graph/Chrome156.0.8078.80 at1440/390 and independent14-original PNG review are accepted at the exact named core/source digest. This releases only the local integration lease.',
    'source_link_boundary': 'Own-site complete module/download and local immutable Git-object bytes checked. Public-source links false; external GitHub link route null/not_executed; no external HTML or HTTP200 claimed.',
    'remote_hold': 'All foreign PR385/Bench/PBPS/SPHMC and other queue states retain their existing owners/evidence. No remote action, retry, CI rerun, PR edit, merge/deployment or provider trial.',
    'truth_boundary': 'Existing fresh source V and current accepted audit remain unchanged. Both main lower bounds and oracle/transcript/TV-precision/deterministic worst-case cap/expected-cost/hidden-basis adapters, remote publication/merge/live-public delivery, postmerge purification/Exposition Seal and whole Goal remain open.',
    'new_mathematical_source_or_semantic_verdict': False,
    'reclaim_rule': 'A later authorized normal STABILIZING claim is required before further serialized shared integration or actual remote delivery.'
}
request = {'advance_id': ADV, 'to_state': 'VERIFIED', 'worker_id': ACTOR,
           'modes': ['mechanical-existing-verification-parking', 'release-local-integration-lease-after-local-acceptance'], 'evidence': evidence}
write_json(REQUEST_PATH, request)
write_json(OUT / 'local-integration-parking.preflight.json', {
    'head': CORE, 'source_digest': DIGEST, 'state': 'STABILIZING', 'single_lane': [ADV],
    'proof_owner': PROOF_OWNER, 'source_verifier': SOURCE_VERIFIER, 'released_integration_owner': INTEGRATION_OWNER,
    'ledger_before_sha256': sha(ledger_before), 'request': descriptor(REQUEST_PATH),
    'exact_prefix_archive': prefix_archive, 'foreign_states': foreign_archive, 'frontier_hashes': frontier_archive,
    'source_phase1_3_hashes': source_archive, 'protected_live_inputs': len(protected_inputs),
    'normal_API_not_yet_invoked': True})

# Exactly one real mutating normal API call. Failure is persisted, not retried.
buffer = io.StringIO()
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
tick = time.monotonic()
error = None
with contextlib.redirect_stdout(buffer), contextlib.redirect_stderr(buffer):
    try:
        advance.transition_advance(ADV, to_state='VERIFIED', worker_id=ACTOR, modes=request['modes'], evidence=evidence)
        print('Normal tools.astis_advance.transition_advance returned successfully after its current reviewed-publication admission. No compilation or browser was run.')
    except Exception:
        error = traceback.format_exc()
        print(error)
elapsed = time.monotonic() - tick
raw_stdout = buffer.getvalue().encode()
stdout_path = OUT / 'local-integration-parking.normal-api.log'
assert not stdout_path.exists()
stdout_path.write_bytes(raw_stdout)
stdout_archive = archive(OUT / 'local-integration-parking.normal-api.log.gz', raw_stdout)
ledger_after = LEDGER.read_bytes()
append = ledger_after[len(ledger_before):] if ledger_after.startswith(ledger_before) else b''
api_receipt = {
    'command': 'tools.astis_advance.transition_advance',
    'driver_command': ['python3', '-B', str(Path(__file__).relative_to(ROOT))],
    'request': descriptor(REQUEST_PATH), 'actual_API_invocations': 1,
    'started_utc': started, 'elapsed_seconds': elapsed, 'exit_code': 1 if error else 0, 'error': error,
    'head_before': CORE, 'head_after': head(), 'source_digest_before': DIGEST,
    'raw_stdout_sha256': sha(raw_stdout), 'lossless_raw_stdout': stdout_archive,
    'ledger_before_bytes': len(ledger_before), 'ledger_before_sha256': sha(ledger_before),
    'ledger_after_bytes': len(ledger_after), 'ledger_after_sha256': sha(ledger_after),
    'exact_before_prefix_preserved': ledger_after.startswith(ledger_before),
    'append_bytes': len(append), 'append_sha256': sha(append),
    'existing_source_verifier_retained': SOURCE_VERIFIER,
    'reviewed_publication_admission': 'Performed by the normal schema-v4 API for the unchanged exact publication target set; no source re-review/build/browser run.'}
write_json(RECEIPT_PATH, api_receipt)
assert error is None, error
assert ledger_after.startswith(ledger_before) and len(append.splitlines()) == 1
event = json.loads(append)
assert event['advance_id'] == ADV and event['worker_id'] == ACTOR
assert event['from_state'] == 'STABILIZING' and event['to_state'] == 'VERIFIED' and event['evidence'] == evidence
append_path = OUT / 'local-integration-parking.exact-append.jsonl'
assert not append_path.exists()
append_path.write_bytes(append)
append_archive = archive(OUT / 'local-integration-parking.exact-append.jsonl.gz', append)
states_after = advance._replay_advances(json.loads(r) for r in ledger_after.splitlines())
assert states_after[ADV]['state'] == 'VERIFIED' and states_after[ADV]['owner_id'] == PROOF_OWNER
assert {k: v for k, v in states_after.items() if k != ADV} == foreign_before
assert not any(v['state'] == 'STABILIZING' for v in states_after.values())
assert LEDGER.read_bytes() == ledger_after and DISCOVERIES.read_bytes() == discoveries_before
assert AUDIT.read_bytes() == audit_before and CELL.read_bytes() == cell_before
assert (ROOT / '_site/data/build-metadata.json').read_bytes() == site_before
assert astis_site.source_digest() == DIGEST and head() == CORE
for path, row in protected_inputs.items():
    p = ROOT / path
    raw = os.fsencode(os.readlink(p)) if p.is_symlink() else p.read_bytes()
    assert sha(raw) == row['sha256'], path
for row in manifest['paths']:
    assert sha((ROOT / row['path']).read_bytes()) == row['after_sha256']
for path, expected in proposal['source_test_publication_lesson_pins'].items():
    assert sha((ROOT / path).read_bytes()) == expected, path
frontier_after = {str(p.relative_to(ROOT)): p.read_bytes() for p in (ROOT / 'research-wiki/frontier-cells').glob('*.json')}
assert frontier_after == frontier_before
source_files_after = {str(p.relative_to(ROOT)): sha(p.read_bytes()) for p in SOURCE.rglob('*') if p.is_file()}
assert source_files_after == source_files_before
assert acceptance_path.read_bytes() == acceptance_raw and authorization_path.read_bytes() == authorization_raw
protection_path = OUT / 'local-integration-parking.protection.json'
write_json(protection_path, {
    'original_ledger_prefix_preserved': True, 'ledger_before_sha256': sha(ledger_before), 'ledger_after_sha256': sha(ledger_after),
    'exact_append_events': 1, 'exact_append_sha256': sha(append), 'append_archive': append_archive,
    'all_278_foreign_projected_states_unchanged': True, 'all_437_foreign_frontiers_and_own_cell_byte_unchanged': True,
    'all_438_frontier_JSON_files_unchanged': True, 'no_cell_prose_or_evidence_mutation': True,
    'proof_owner_retained': PROOF_OWNER, 'original_source_verifier_retained': SOURCE_VERIFIER,
    'released_integration_owner': INTEGRATION_OWNER, 'single_stabilization_lane_after': [],
    'protected_source_content_inputs_unchanged': len(protected_inputs), 'all_seven_shared_after_hashes_preserved': True,
    'math_candidate_code_Test_lesson_publication_preserved': True, 'source_phase1_3_files_unchanged': len(source_files_after),
    'canonical_audit_unchanged_sha256': sha(audit_before), 'discovery_ledger_unchanged_sha256': sha(discoveries_before),
    'actual_source_digest_unchanged': DIGEST, 'actual_site_metadata_unchanged_sha256': sha(site_before),
    'no_remote_or_other_queue_operation': True})
summary_path = OUT / 'local-integration-release-summary.json'
write_json(summary_path, {
    'actor': ACTOR, 'operation': 'One explicitly authorized normal API STABILIZING->existing VERIFIED local parking/release',
    'authorization': descriptor(authorization_path), 'request': descriptor(REQUEST_PATH),
    'normal_API_receipt': descriptor(RECEIPT_PATH), 'protection': descriptor(protection_path),
    'proof_owner_retained': PROOF_OWNER, 'released_integration_owner': INTEGRATION_OWNER,
    'source_verdict_originator_retained': SOURCE_VERIFIER,
    'original_immutable_mathematical_candidate': MATH, 'original_source_verified_metadata_commit': SOURCE_METADATA,
    'current_accepted_audit_sha256': sha(audit_before), 'current_publication_binding_sha256': binding,
    'actual_local_acceptance_core': CORE, 'actual_source_digest': DIGEST,
    'independent_local_reader_acceptance': descriptor(acceptance_path),
    'own_cell_unchanged_sha256': sha(cell_before),
    'cell_current_integration_evidence': 'Not modified in this release. Root may separately project actual current integration facts and retain earlier phase prose as history.',
    'final_projected_state': 'VERIFIED', 'single_stabilization_lane': [],
    'ledger_after_sha256': sha(ledger_after), 'unique_append_sha256': sha(append),
    'normal_parking_API_invocations': 1, 'new_mathematical_source_or_semantic_verdicts': 0,
    'new_compilation_or_browser_or_remote_runs': 0,
    'remote_merge_live_public_purification_ExpositionSeal_or_Goal_claim': False,
    'remaining': 'Both main lower bounds and oracle/transcript/TV-precision/deterministic worst-case cap/expected-cost/hidden-eigenbasis adapters, remote publication/merge/live-public delivery and postmerge purification/Exposition Seal/full Goal remain open.',
    'writes_stop_after_summary': True})
archive(OUT / 'executed-park-existing-after-local-acceptance.py.gz', Path(__file__).read_bytes())
print(json.dumps({'state': 'VERIFIED', 'single_stab': [], 'normal_API_calls': 1,
    'receipt_sha256': sha(RECEIPT_PATH.read_bytes()), 'ledger_after_sha256': sha(ledger_after),
    'append_sha256': sha(append), 'own_cell_unchanged_sha256': sha(cell_before),
    'protection_sha256': sha(protection_path.read_bytes()), 'summary_sha256': sha(summary_path.read_bytes()),
    'new_source_verdicts': 0, 'writes_stopped': True}, indent=2))
