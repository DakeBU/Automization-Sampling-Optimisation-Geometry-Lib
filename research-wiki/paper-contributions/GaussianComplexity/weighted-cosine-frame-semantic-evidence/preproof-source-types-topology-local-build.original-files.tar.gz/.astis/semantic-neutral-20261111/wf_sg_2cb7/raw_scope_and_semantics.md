# Frozen raw mathematical reading

This is a source-only reconstruction of a bounded component of *On Complexity
of Gaussian Sampling*, arXiv:2610.20492v1, pinned to the local HTML with SHA-256
`6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915`.
No proposed type, project definition, Lean proof, API, earlier source graph,
earlier verdict, or compiler history was used. This is not a type judgment or
acceptance of a completed theorem. A distinct-role topology challenge is pending.

The primary source inventory covers C.2 p1–p14, marking adjacent unused
components explicitly. The two claim endpoints are the deterministic coefficient
comparison inside Ex116 and the uncentered second-moment upper bound ending at
Ex117. The first sentence of p14.4 identifies the two deterministic ingredients.
Its following “Since” starts the downstream centering step, Ex118.

## Exact source chain and constants

The source uses `r=q+1`, `n=2q+1`, integer `q>=0`, and `2q+1<d`. Therefore
`r>=1`, `d>=2`, and `2r<=d`. The physical row index is `1<=i<=d`; feature
coordinates are `0,...,q`. The grid is
`theta_i=(i-1/2) pi/d`, and
`t_i=(1,sqrt(2)cos(theta_i),...,sqrt(2)cos(q theta_i))^T` belongs to `R^r`.

Fact C.5 supplies two actual proof dependencies:

```
||t_i||^2 <= 2r,
sum_i t_i t_i^T = d I_r.
```

The second identity is proved in p4–p5 by the sine telescope, constant-coordinate
cases, product-to-sum, and all diagonal/off-diagonal frequency checks. The first
is proved at Ex102 by `1+2 sum_(j=1)^q cos^2(j theta_i)<=1+2q<=2r`.
Neither identity is a new premise justified merely by the existence of Fact C.5.

The deterministic coefficient matrix in the Ex116 comparison is

```
C_t = sum_i ||t_i||^2 t_i t_i^T,
C_t ≼ 2r sum_i t_i t_i^T = 2rd I_r.
```

Here “weighted cosine” refers to squared norms of the cosine feature vectors
as weights of their rank-one matrices. It does not mean the high-frequency
weights `cos(n theta_i)` used for `D_n` and the later weighted centered sequence.
Tensoring the coefficient comparison with `I_r` is the form inside Ex116.

The source row is `gamma_i=((g_1)_i,...,(g_r)_i)^T`, individually `N(0,I_r)`.
It sets `R_i=||gamma_i||^2` and `L=2r+3 log(1000d)`, then defines

```
Y_i = (1/d) (gamma_i gamma_i^T ⊗ t_i t_i^T) 1_{R_i<=L}.
```

The numerical cutoff constants `2`, `3`, and `1000` are fixed source data. The
sum-bound argument needs the cutoff indicator to be `0` or `1`; it does not use
the cutoff-tail estimates, bias estimate, or a concentration probability.

Ex113 gives `E[R_i gamma_i gamma_i^T]=(r+2)I_r`. The source explains that
off-diagonal entries vanish by sign symmetry and each diagonal is
`3+(r-1)=r+2`. The invoked coordinate facts are the standard Gaussian fourth
moment `3` and mixed squared-coordinate moment `1` within a row. These moment
facts also supply the finite polynomial moments needed to interpret the matrix
expectations; moment integrability is an internal analytic dependency.

The two rank-one-square formulas immediately preceding Ex114 give

```
Y_i^2 = (R_i ||t_i||^2/d^2)
        (gamma_i gamma_i^T ⊗ t_i t_i^T) 1_{R_i<=L}.
```

EGx11, whose rows are Ex115, Ex116 and Ex117, is exactly

```
sum_i E[Y_i^2]
  ≼ ((r+2)/d^2) sum_i ||t_i||^2 (I_r ⊗ t_i t_i^T)
  ≼ (2r(r+2)/d^2) (I_r ⊗ sum_i t_i t_i^T)
  = (2r(r+2)/d) I_(r^2).
```

The first comparison drops the indicator from a PSD expression and applies
Ex113 under each individual expectation. The second uses the deterministic
coefficient comparison. The equality uses the unweighted Gram identity and
`I_r ⊗ I_r = I_(r^2)`. The exact upper-bound constant is `2r(r+2)/d`, with no
unspecified absolute constant and no dependence on `kappa`, `C`, or `tau`.

## Standing data and internal proof components

The source dimensions, grid, feature formula, row law, and cutoff/matrix formulas
specify the mathematical objects. The real vector/matrix carriers, finite index
sets, transpose, identity, and tensor carrier are typing/convention data.
The norm bound, Gram identity, fourth moment identity, matrix-square identity,
PSD domination, integrability, expectation monotonicity, and finite-sum algebra
are proof components to discharge internally. They cannot be moved into extra
public hypotheses to make the source component easier to prove.

The enclosing Lemma 4.4 assumes independent `N(0,I_d)` starting vectors, and C.2
states that the rows `gamma_1,...,gamma_d` are independent `N(0,I_r)`. That full
source setup is retained, but the present endpoint mathematically consumes only
each individual row law. Kappa's hard-family restrictions and the Chebyshev
change of basis are relevant to the range/Krylov result; they do not enter the
two endpoints here. `tau<=1/2`, concentration probabilities, tail bounds,
truncation bias, first moments, `Z_i`, variance parameters, and Bernstein are
outside this packet's conclusion and backward necessity closure.

The graph marks elementary justifications not expanded by the source as
`SOURCE_GAP`: PSD/tensor order, tensor/indicator multiplication, Gaussian
polynomial integrability, expectation/order bookkeeping, and tensor identity
normalization. It also records the unexpanded adapter from the original source
columns to each stated Gaussian row marginal. This label records omitted
exposition; it does not assert a source error and does not authorize extra
assumptions.

## Marginal versus joint scope

The deterministic coefficient comparison has no probability input. Ex113 and
each expected square use one standard Gaussian row law. Summing the resulting
individual expected matrices uses only finite deterministic matrix addition;
cross-row independence is unused. Within-row standard Gaussian coordinate
structure remains essential for the exact `r+2` identity.

The source's common experiment gives all rows and matrices on one probability
space. A sum of their individual expectations is meaningful without joint
independence. Writing `E[sum_i Y_i^2]` additionally presupposes a common space,
although finite-sum linearity still does not require independence.

A canonical row-law integral can represent each individual expected matrix and
their finite sum after the corresponding individual law/expectation
identifications. That scope does not construct the original column family,
establish its original-family joint law, or transfer its concentration events.
Using the same integration variable in each row template must not be mistaken
for a proof that the original rows are identical or for a jointly independent
realization. Original-family joint-law transport remains separately open.

The graph therefore preserves both the full original-source backward closure
(including the original columns and the individual-marginal adapter) and a
separate sufficient closure cut at the individual row law. The latter says
which data the EGx11 calculation uses after a marginal is known; it does not
certify that a formal object already has that marginal or the original joint law.

The source's simultaneous truncation event, independent truncated family and
matrix Bernstein step genuinely use a joint family. They are downstream and
receive no completion claim here.

## Endpoint `q=0`

The source includes `q=0`. Then `r=1`, `n=1`, and `d>=2`; the feature is
`t_i=(1)` and its nonconstant-coordinate sums are empty. Its exact norm squared
is `1`, its unweighted Gram is `d I_1`, and Ex113 is the one-dimensional fourth
moment `3`. The deterministic comparison and the source upper bound remain
valid with their stated loose factor `2`; the final source coefficient is
`2*1*(1+2)/d=6/d`. No division by `q`, nonempty nonconstant-coordinate case, or
extra `q>0` hypothesis is justified.

## Meanings that must remain distinct

`||t_i||` is the Euclidean norm from Section 2. The coefficient comparison and
EGx11 use Loewner order on real symmetric matrices, meaning PSD differences.
They do not yet assert an operator-norm or concentration theorem. Source
`Y_i^2` is a square matrix product; `E[Y_i^2]` is its entrywise expectation,
not `(E Y_i)^2` or an entrywise square. The outer Kronecker matrix is
`r^2` by `r^2`, with coordinate pair `(a,j)`; `t_i t_i^T` alone is `r` by `r`.
The final bound is uncentered. Ex118's centered second-moment comparison,
Ex119's variance parameter, Ex120's high-frequency weighted centered-square
comparison, Bernstein, Fact C.6, and full Lemma 4.4 remain outside the endpoint.

## Access disclosure and next phase

Initial instruction discovery used an overbroad `rg --files` search under
`.agents` and `.astis`. It returned filenames under prior packet directories.
This was filename-only exposure: no prior graph/report/verdict/type/Lean/API/
history contents were opened or used. The parent was informed and instructed
that the exact disclosure be preserved while the raw task continued.

All written artifacts are confined to this task directory. No normal ledger,
commit, integration, ATLAS, subagent, proof/API search, or type judgment was
performed. The raw packet is frozen before receipt of a selective type and
meaning-carrying-definition packet. The extractor does not approve its own
coverage or topology.
