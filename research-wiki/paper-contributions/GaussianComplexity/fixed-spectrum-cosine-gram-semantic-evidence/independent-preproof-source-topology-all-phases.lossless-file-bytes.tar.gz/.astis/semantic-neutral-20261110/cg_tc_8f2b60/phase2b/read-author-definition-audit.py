from pathlib import Path
import hashlib

base=Path(__file__).resolve().parent
p=base/'author-phase2/binder_definition_audit.json'
b=p.read_bytes()
assert hashlib.sha256(b).hexdigest()=='0774fcaf60d069523db6b8ec4cf2b73addfe4068b3e796b78e2cf91f01158577'
out='AUTHOR ASSERTIONS FOR STRUCTURAL REVIEW; NOT INDEPENDENT AUTHORITY\n'+b.decode()+'\n'
(base/'read-author-definition-audit.stdout.txt').write_text(out)
print(out,end='')
