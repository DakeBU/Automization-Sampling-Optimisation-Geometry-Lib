"""Freeze independently viewed v5 images, bounded reader acceptance, and explicit own public leaves."""
import ast,datetime as dt,hashlib,importlib.util,json
from pathlib import Path
OUT=Path(__file__).resolve().parent;OWN=OUT.parent;REPO=OWN.parents[2]
PREVIEW=REPO/'.astis/huanjian-gc-matrix-mgf-domain-20261115/reader-preview-v1/static-closure-v5';FIXTURE=PREVIEW/'fixtures/candidate';SNAPSHOT=PREVIEW/'input-snapshot'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,x):
    with Path(p).open('x') as f:f.write(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
spec=importlib.util.spec_from_file_location('own_readonly_parser',OUT/'review_actual.py');parser=importlib.util.module_from_spec(spec);spec.loader.exec_module(parser)
data=json.loads((OUT/'actual-data-audit.json').read_text());actual=json.loads((OWN/'actual-result.json').read_text());receipt=json.loads((OWN/'runtime-process/receipt.json').read_text())
assert len(data['checks'])==261 and all(c['pass'] for c in data['checks'])
names={}
for n in ast.parse((OWN/'browser_check.py').read_text()).body:
    if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id in ['ITEM','PFILE','TFILE','P','T','PSD','TRACE','SOURCES']:names[n.targets[0].id]=eval(compile(ast.Expression(n.value),'<pure literal checker targets>','eval'),{'__builtins__':{}},names)
sources=names['SOURCES'];target={s[2]:'data/lesson-sources/'+s[1]+'.html#L'+str(s[3]) for s in sources}
navigation=[]
for path,expected in [('source-index.html',[s[2] for s in sources]),('parent-context.html',[names['PSD'],names['P'],names['TRACE'],sources[4][2],sources[5][2]])]:
    dom=parser.Parse((FIXTURE/path).read_text()).root;main=dom.find(lambda n:n.tag=='main')[0]
    links=[a for li in main.find(lambda n:n.tag=='li') for a in li.find(lambda n:n.tag=='a')]
    assert [a.text() for a in links]==expected
    assert all(a.attrs['href']==target[a.text()] for a in links)
    navigation.append({'page':path,'sha256':sha(FIXTURE/path),'actual_frozen_links':[{'label':a.text(),'href':a.attrs['href']} for a in links],'exact_labels_and_target_anchors_checked':True})
graph=json.loads((FIXTURE/'data/underlying-lean-graph.json').read_text());unit=json.loads((SNAPSHOT/'website/content/declaration_lessons/huanjian-matrix-mgf-domain.json').read_text())['units'][0]
module_contexts=[]
for raw in [names['PFILE'],names['TFILE']]:
    name=raw[:-5].replace('/','.');url=next(n['url'] for n in graph['nodes'] if n['id']=='module:'+name);dom=parser.Parse((FIXTURE/url).read_text()).root
    assert dom.find(lambda n:n.tag=='h1')[0].text()==name and dom.find(lambda n:n.tag=='pre')[-1].text().encode()==(SNAPSHOT/raw).read_bytes()
    module_contexts.append({'module':name,'page':url,'page_sha256':sha(FIXTURE/url),'full_last_pre_equals_original_source':True,'source_sha256':sha(SNAPSHOT/raw)})
canonical=next(n['url'] for n in graph['nodes'] if n['id']=='decl:'+names['P']);dom=parser.Parse((FIXTURE/canonical).read_text()).root;steps=dom.find(lambda n:n.tag=='details' and n.has('proof-reader-step'))
assert len(steps)==5 and [s.find(lambda n:n.tag=='pre')[0].text() for s in steps]==[s['lean'] for s in unit['steps']]
write(OUT/'navigation-inspection.json',{'schema':'R17-v5-independent-frozen-link-and-context-inspection-v1','selected_source_index_and_parent_links':navigation,'P_T_full_module_contexts':module_contexts,'canonical_P_reader':{'page':canonical,'sha256':sha(FIXTURE/canonical),'five_exact_steps':True},'actual_browser_navigation_boundary':'Original actual runtime includes12 source-index link clicks,22 source-anchor readability paths,6 graph-primary context clicks and2 P whole-module context links, plus2 T module full-source downloads. Parent-context five hrefs are independently checked statically and their exact destinations were visited through source-index/source controls; no additional parent-list click loop is claimed.','no_new_browser_run':True})
views=[]
for s in data['actual_original_screenshots']:
    name=Path(s['path']).name
    if 'actual-node-viewport' in name:
        note='Actual selected node rectangle and readable core label lie inside the visible SVG. Native pan/zoom produced a legible selected target, rather than a clipped or blank graph. Long P/PSD SVG identifiers stay ellipsized; full IDs are read in detail.'
    elif 'full-ID-detail' in name:
        note='Full selected P/PSD/private-module ID is readable in wrapped detail, with source/context and neighbor controls. This frame does not show every neighbor simultaneously; recorded DOM neighbor sets/directions cover the remaining detail content.'
    elif 'proof-initial-folded' in name:
        note='Actual full-page image shows initially closed source statement, assumptions, all five proof steps and Lean disclosures. Main mathematical formula is visibly rendered. Mobile long formula has an explicit instruction and a local horizontal scroll pane.'
    elif 'representative-step1' in name:
        note='Expanded first proof argument and rendered formula are readable. Desktop adjacent Lean action controls are visible. Mobile long formula is locally scrollable, and the remaining adjacent code controls continue below this representative viewport.'
    elif 'representative-step5' in name:
        note='Expanded fifth argument is readable and distinguishes ordinary trace, true mean and finite cap. Desktop rendered trace formula and source link are visible. Mobile lower formula/actions continue below viewport; this representative image is not an instantaneous/settled L187 destination image.'
    elif 'expanded-assumption-comparison' in name:
        note='Expanded source-versus-formal assumptions are readable. Mobile is the actual right-scrolled table region, not a global-page width expansion. The other columns are reachable through the recorded local table scroll geometry.'
    elif 'module-full-source-context' in name:
        note='Complete-source code and module action region are readable and bounded. Mobile code has local horizontal/vertical scrolling; its upper copy control is partly above the current screenshot header after centering the pre, so this frame alone is not a claim that every action fits at once.'
    elif 'widest-right-glyph' in name:
        note='Actual local horizontal source scroll exposes ending code glyphs. Left prefixes intentionally leave the local pre viewport. Raw codepoint and Range geometry were independently checked under the original explicit1 CSSpx horizontal bbox tolerance.'
    elif 'source-T-bottom' in name:
        note='Private-T last namespace line and document bottom are visibly reachable. Long source identifiers remain locally scrollable; the complete file is also verified by actual downloaded bytes.'
    elif 'source-index' in name:
        note='All six source labels are readable with wrapping. Private application is explicitly identified as having no public node; exact anchors match the frozen sources.'
    elif 'parent-context' in name:
        note='Public P points to the PSD parent; associated private application lists P/trace/radius/structure. All labels wrap readably, and the text explicitly denies a separate public private-T theorem node.'
    elif '-source-' in name and '-anchor' in name:
        note='Correct source declaration header and following source are readable below the actual header after natural settling. Long horizontal code is intentionally local-scroll content, not text wrapping or hidden source bytes.'
    else:raise AssertionError(name)
    views.append({**s,'actually_viewed_this_new_original_PNG':True,'method':'tools.view_image, each original file; no old screenshot or contact-sheet substitution','visual_observation':note,'blocking_visual_finding':None})
assert len(views)==50
write(OUT/'visual-observations.json',{'schema':'R17-v5-independent-all50-new-original-PNG-review-v1','reviewer':'matrix_domain_reader_successor_61e4','observations':views,'all50_new_actual_originals_viewed':True,'visual_status':'PASS_WITH_EXPLICIT_LOCAL_SCROLL_AND_ELLIPSIS_LIMITS','no_old_packet_verdict_or_image_transfer':True})
step5=[t for t in data['natural_stability_trace_summaries'] if t['case'].endswith('step5')]
report={
 'schema':'R17-v5-independent-bounded-isolated-reader-acceptance-v1',
 'reviewer':'matrix_domain_reader_successor_61e4',
 'status':'PASS_BOUNDED_ISOLATED_READER',
 'necessary_reader_residual_count':0,
 'blocking_findings':[],
 'actual_run':{'OS_exit_code':receipt['actual_exit_code'],'runtime_status':actual['status'],'runtime_checks':523,'runtime_false_checks':0,'actual_original_PNGs':50,'actual_Chrome_version':actual['actual_Chrome_version'],'started_utc':receipt['started_utc'],'ended_utc':receipt['ended_utc'],'elapsed_seconds':receipt['elapsed_seconds'],'server_and_worker_stopped':actual['server_and_worker_stopped']},
 'exact_binding':{'preview':'static-closure-v5/fixtures/candidate','preview_manifest_sha256':actual['preview_manifest_sha256'],'actual_assignment_sha256':data['actual_runtime_pins']['execution-assignment.json'],'actual_result_sha256':data['actual_runtime_pins']['actual-result.json'],'actual_OS_receipt_sha256':sha(OWN/'runtime-process/receipt.json'),'runner_sha256':data['actual_runtime_pins']['browser_check.py'],'geometry_sha256':data['actual_runtime_pins']['browser_geometry.py'],'anchor_wait_sha256':data['actual_runtime_pins']['browser_anchor_wait.py'],'mathematical_source_commit':'a8bb8ea5b4474be5214bd83ae380a612e2cecb78','source_reviewed_publication_binding_sha256':'5e79fa3d4390c4d1e689174b0c014d67fb8dbfb550f986b4af7d8474ef644691','P_source_sha256':'d3c6e5a194fecf1ae1abe45c70310f4f47d66e903b098019c326ee0d3018b024','T_source_sha256':'60e9f7b928ebc1b8a0d9efad93f39f1b172fe0a871893d67eb1015582c5d5c61','lesson_sha256':sha(SNAPSHOT/'website/content/declaration_lessons/huanjian-matrix-mgf-domain.json'),'publication_sha256':sha(SNAPSHOT/'website/content/publications/huanjian-matrix-mgf-domain.json')},
 'independent_basis':{'all50_new_original_PNGs_actually_viewed':True,'actual_data_audit_checks':261,'all22_natural_stability_traces_recomputed_from_samples':True,'all24_actual_downloads_independently_byte_compared':True,'all22_actual_clipboard_equality_records_checked':True,'all6_graph_clip_cases_recomputed':True,'all24_actual_codepoint_glyph_cases_recomputed':True,'navigation_and_full_context_inspection_sha256':sha(OUT/'navigation-inspection.json'),'actual_data_audit_sha256':sha(OUT/'actual-data-audit.json'),'visual_observations_sha256':sha(OUT/'visual-observations.json'),'audit_OS_receipt_sha256':sha(OUT/'process/receipt.json'),'not_inferred_from_523_true_flags_alone':True},
 'accepted_reader_scope':[
  'Desktop1440x1000 and mobile390x844 headless Chrome CSS viewports. Main statement, assumptions, five proof steps and Lean disclosures start closed; actual summary interactions expand the proof and code. Local MathJax3.2.2 CHTML renders the mathematical formula/proof without recorded errors.',
  'Five adjacent exact P/P/T/T/T Lean spans retain all P50+T212=262 source lines. Ten actual step copies and12 complete-source copies compare exact UTF8 bytes in the frozen runner. All24 real module download files independently match frozen source bytes, including private T. No source text was trimmed/normalized.',
  'All22 source-anchor readability paths retain immediate geometry and natural-window/pre-scroll samples. Four final samples100ms apart are independently stable within.25 CSSpx after at least500ms and before5s. Original strict positive visible intersection and header predicate are unchanged and pass for every target.',
  'All six selected source pages have exact headers/line counts/full bodies, directly opened anchors, local long-line scrolling, widest ending codepoint and final line. Source-index six labels/actual click destinations and parent-context exact labels/anchors match. Canonical P and full P/T module navigation expose original full-source context.',
  'Bounded graph has exactly11 unique nodes/15 directed edges, only one private-T module and no private-T public theorem. Actual native wheel/pointer focuses P, PSD and private module in each viewport. Recomputed selected node and core-label visible area fractions are1; font approximately13 CSSpx, visible label height approximately33.727px. Full IDs are readable in detail. Solid structural edges and dashed scanner/source references preserve their distinct truth boundaries.',
  'Actual final private-T module document width is desktop1440/html1440/body1440 and mobile390/html390/body390 after disclosures, closing the measured body expansion in this v5 run. All110 fixture leaves remain byte-exact.1646 requests/responses have no recorded HTTP/page/console/external-request errors; server/thread stopped.'
 ],
 'old_findings_resolution_for_this_successor_only':{'step5_actual_this_run':step5,'mechanism':'Immediate L187 intersection is still0 in both viewports; natural settling then gives desktop top95.609375/height20 and mobile top111.703125/height19 below header60.578125. No forced target scroll or disabled smooth animation is introduced.','mobile_grid':'The only v3→v5 served delta is scoped declaration-grid CSS; this run independently measures body/html390. No new owner geometry or counterfactual experiment beyond the global containment measurement is claimed.','original_v3_result_sha256':'74fd21200be988619c1ff27fd253049cc84c96641461aaf3fb54ca52beb9384f','original_v3_status_remains':'FAIL,OSexit1,501checks/3false/50PNG','original_diagnostic_sha256':'f5774f5c3c4f2b04b375b934c700de93b2fa17e9a54cf8a57648dc095a68a9f2','original_independent_diagnosis_sha256':'03a48583970387e6b52549534c5bfa98ec8be0f40e551e4899682d67109420e6','old_originals_or_verdicts_rewritten':False},
 'explicit_limits':{
  'headless_CSS_viewport_not_physical_touch_or_external_device':True,
  'horizontal_Range_bbox_glyph_tolerance_css_px':1,
  'max_actual_horizontal_Range_bbox_overhang_css_px':data['max_horizontal_Range_bbox_overhang_css_px'],
  'zero_pixel_clipping_claim':False,
  'trimEnd_only_selects_last_nonwhitespace_codepoint_no_source_mutation':True,
  'long_formula_table_code_scroll_panes_need_local_horizontal_scroll':True,
  'long_P_PSD_SVG_identifiers_remain_ellipsized_full_ID_in_detail':True,
  'every_neighbor_and_all_source_actions_fit_one_viewport_claim':False,
  'clipboard_equality_records_preserved_but_raw_clipboard_payloads_not_separately_serialized':True,
  'parent_list_links_statically_checked_destinations_actually_visited_elsewhere_no_extra_click_loop_claim':True,
  'historical_pending_gate_source_progress_annotations_are_frozen_snapshot_not_current_normal_stage':True,
  'no_aggregate_full_site_production_deployment_or_global_graph_acceptance':True,
  'no_new_Lean_build_source_fidelity_proof_VERIFIED_or_PURIFIED_credit':True,
  'mathematical_native_build_identity_remains_a8bb_only_not_v5_or_metadata_HEAD':True,
  'normal_API_V_cell_ledger_Git_actions_by_reader_review':0
 },
 'created_utc':dt.datetime.now(dt.timezone.utc).isoformat()
}
write(OUT/'independent-reader-acceptance.json',report)
write(OUT/'independent-reader-acceptance-run.json',{'schema':'R17-v5-immutable-independent-reader-acceptance-run-v1','status':'PASS_BOUNDED_ISOLATED_READER','report_sha256':sha(OUT/'independent-reader-acceptance.json'),'actual_result_sha256':sha(OWN/'actual-result.json'),'actual_OS_receipt_sha256':sha(OWN/'runtime-process/receipt.json'),'actual_data_audit_sha256':sha(OUT/'actual-data-audit.json'),'visual_observations_sha256':sha(OUT/'visual-observations.json'),'navigation_inspection_sha256':sha(OUT/'navigation-inspection.json'),'audit_receipt_sha256':sha(OUT/'process/receipt.json'),'actual_original_PNGs_viewed':50,'necessary_reader_residual_count':0,'no_new_browser_or_normal_API_V_Lean_action_by_review':True})
prep=json.loads((OWN/'preparation-public-selected-originals.manifest.json').read_text());paths={r['path'] for r in prep['files']}
for r in prep['files']:assert sha(OWN/r['path'])==r['sha256']
paths.update(['preparation-public-selected-originals.manifest.json','execution-assignment.json','actual-result.json','runtime-process/receipt.json','runtime-process/stdout.raw','runtime-process/stderr.raw'])
paths.update(s['path'] for s in data['actual_original_screenshots']);paths.update(d['path'] for d in data['actual_downloads'])
paths.update('acceptance-review-v1/'+p for p in ['review_actual.py','freeze_review.py','actual-data-audit.json','visual-observations.json','navigation-inspection.json','independent-reader-acceptance.json','independent-reader-acceptance-run.json','process/receipt.json','process/stdout.raw','process/stderr.raw'])
assert not any(any(x in p.split('/') for x in ['chrome-tmp','__pycache__','cache','local-private-guards']) for p in paths)
files=[{'path':p,'bytes':(OWN/p).stat().st_size,'sha256':sha(OWN/p)} for p in sorted(paths)]
write(OUT/'public-selected-originals.manifest.json',{'schema':'R17-v5-actual-reader-independent-acceptance-explicit-own-public-leaves-v1','base':'matrix_domain_reader_successor_61e4','status':'PASS_BOUNDED_ISOLATED_READER','files':files,'explicit_exact_leaf_copy_only_no_recursive_directory_copy':True,'all_original_streams_results_downloads_PNGs_must_remain_byte_exact_no_trim_normalize':True,'known_absolute_path_references_and_localhost_logs_retained':True,'no_Chrome_cache_tmp_privateguards_fullforeignmaps_inventory_index_ATLAS_or_credentials_selected':True,'old_v3_FAIL105_and_diagnostic24_are_separate_preserved_custody_not_replaced_or_union_copied_here':True})
print(json.dumps({'status':report['status'],'report_sha256':sha(OUT/'independent-reader-acceptance.json'),'run_sha256':sha(OUT/'independent-reader-acceptance-run.json'),'manifest_sha256':sha(OUT/'public-selected-originals.manifest.json'),'explicit_leaves':len(files),'selected_bytes':sum(r['bytes'] for r in files)}))
