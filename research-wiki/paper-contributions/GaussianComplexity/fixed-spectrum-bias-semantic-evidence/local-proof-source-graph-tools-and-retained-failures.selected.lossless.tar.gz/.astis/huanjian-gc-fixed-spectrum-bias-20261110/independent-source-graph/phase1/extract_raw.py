from html.parser import HTMLParser
from pathlib import Path
from collections import Counter
import hashlib,json,re
root=Path('/Users/zhouhuanjian/ASTIS-GC')
out=root/'.astis/huanjian-gc-fixed-spectrum-bias-20261110/independent-source-graph/phase1'
source=root/'.astis/huanjian-resume-20261103/2610.20492v1.html'
data=source.read_bytes();raw=data.decode();lines=raw.splitlines()
source_sha=hashlib.sha256(data).hexdigest()
assert source_sha=='6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
class Node:
 def __init__(self,tag,attrs,line,column,parent=None):
  self.tag=tag;self.attrs=dict(attrs);self.line=line;self.column=column;self.end=line;self.parent=parent;self.parts=[];self.children=[]
 def text(self):
  if self.tag=='math':return '$'+self.attrs.get('alttext','')+'$'
  if self.tag=='annotation':return ''
  return re.sub(r'\s+',' ',''.join(x.text() if isinstance(x,Node) else x for x in self.parts)).strip()
 def walk(self):
  yield self
  for x in self.children:yield from x.walk()
class Parser(HTMLParser):
 def __init__(self):super().__init__(convert_charrefs=True);self.root=Node('root',[],1,0);self.stack=[self.root]
 def handle_starttag(self,tag,attrs):
  n=Node(tag,attrs,*self.getpos(),self.stack[-1]);self.stack[-1].children.append(n);self.stack[-1].parts.append(n)
  if tag not in ('meta','link','img','br','hr','input','wbr','source','area','base','embed','param','track','col'):self.stack.append(n)
 def handle_endtag(self,tag):
  for i in range(len(self.stack)-1,0,-1):
   if self.stack[i].tag==tag:
    for n in self.stack[i:]:n.end=self.getpos()[0]
    del self.stack[i:];return
 def handle_data(self,s):self.stack[-1].parts.append(s)
p=Parser();p.feed(raw);allnodes=list(p.root.walk());byid={n.attrs['id']:n for n in allnodes if n.attrs.get('id')}
scopes=[{'name':name,'root_id':ident,'original_lines':[byid[ident].line,byid[ident].end]} for name,ident in [('section2-complete','S2'),('section4-complete','S4'),('appendixC3-complete','A3.SS3')]]
cited=set()
for name in ['S2','S4','A3.SS3']:
 for n in byid[name].walk():
  href=n.attrs.get('href','')
  if href.startswith('#bib.'):cited.add(href[1:])
for ident in sorted(cited):
 n=byid[ident];scopes.append({'name':'cited-bibliography-entry:'+ident,'root_id':ident,'original_lines':[n.line,n.end]})
prior_path=root/'.astis/huanjian-gc-fixed-spectrum-variances-20261110/independent-source-graph/raw-unit-inventory.json'
prior=json.loads(prior_path.read_text())
# A source row's frozen prior ordinal remains attached where its content is identical.
prior_lookup={}
for j,u in enumerate(prior['units']):
 key=(u['id'],tuple(u['original_lines']),u['kind'],u['text_with_tex'])
 prior_lookup.setdefault(key,[]).append(j)
units=[]
for n in allnodes:
 scope=next((s for s in scopes if s['original_lines'][0]<=n.line<=s['original_lines'][1]),None)
 if scope is None:continue
 classes=n.attrs.get('class','').split();kind=None
 if n.tag=='section':kind='section-context'
 elif 'ltx_bibitem' in classes:kind='bibliography-entry'
 elif 'ltx_theorem' in classes:kind='theorem-block'
 elif 'ltx_proof' in classes:kind='proof-block'
 elif n.tag in ('h2','h3','h4','h5','h6'):kind='heading'
 elif n.tag=='div' and 'ltx_para' in classes:kind='paragraph-container'
 elif n.tag=='p':kind='paragraph'
 elif n.tag=='table' and ('ltx_equation' in classes or 'ltx_equationgroup' in classes):kind='display'
 elif n.tag=='tbody':kind='tbody'
 elif 'ltx_cite' in classes:kind='external-citation'
 elif n.tag=='a' and n.attrs.get('href','').startswith('#'):kind='internal-reference'
 elif n.tag in ('dt','dd'):kind='definition-term' if n.tag=='dt' else 'definition-description'
 elif n.tag=='li':kind='list-item'
 if kind is None:continue
 ident=n.attrs.get('id')
 if ident is None:
  anc=n.parent
  while anc and not anc.attrs.get('id'):anc=anc.parent
  ident=(anc.attrs.get('id') if anc else 'source')+'::'+n.tag+'@'+str(n.line)
 table=n.parent
 while table and table.tag!='table':table=table.parent
 parent_table=table.attrs.get('id') if table else None
 parent_id=n.parent
 while parent_id and not parent_id.attrs.get('id'):parent_id=parent_id.parent
 maths=[{'id':m.attrs.get('id'),'line':m.line,'tex':m.attrs.get('alttext'),'display':m.attrs.get('display')} for m in n.walk() if m.tag=='math']
 refs=[{'line':a.line,'href':a.attrs.get('href'),'title':a.attrs.get('title'),'text':a.text()} for a in n.walk() if a.tag=='a' and a.attrs.get('href','').startswith('#')]
 u={'raw_unit_ordinal':len(units),'id':ident,'original_html_id':n.attrs.get('id'),'kind':kind,'scope':scope['name'],'original_lines':[n.line,n.end],'original_start_column':n.column,'source_unit_key':f'{n.tag}@{n.line}:{n.column}','containing_display_id':parent_table,'parent_original_html_id':parent_id.attrs.get('id') if parent_id else None,'text_with_tex':n.text(),'math':maths,'references':refs,'raw_html_sha256':hashlib.sha256(('\n'.join(lines[n.line-1:n.end])+'\n').encode()).hexdigest()}
 key=(ident,tuple(u['original_lines']),kind,u['text_with_tex'])
 u['prior_variances_raw_ordinals']=prior_lookup.get(key,[])
 units.append(u)
# Every unit has one target-independent raw disposition; no mathematical target has been supplied.
rows=[]
for u in units:
 k=u['kind'];reason=None;disposition='NODE'
 if k in ('section-context','proof-block','paragraph-container','heading'):
  disposition='EXCLUDED';reason='Structural wrapper or heading. Every substantive descendant paragraph, theorem, source formula row, display and reference is separately inventoried. No target-dependent scope decision.'
 elif k=='paragraph' and u['text_with_tex'].strip()=='∎':
  disposition='EXCLUDED';reason='Standalone proof-end marker contains no mathematical assertion.'
 elif k=='tbody' and u['original_html_id'] is None:
  disposition='EXCLUDED';reason='Anonymous rendering subcontainer; its complete mathematical content is retained here and captured by display NODE '+str(u['containing_display_id'])+'.'
 elif k=='internal-reference' and (u['scope'].startswith('cited-bibliography') or u['parent_original_html_id'] in ['S2','S4','A3.SS3']):
  disposition='EXCLUDED';reason='Bibliography cited-by or section-heading navigation. Mathematical reference use sites elsewhere remain raw NODEs with href, line and containing context.'
 rows.append({'raw_unit_ordinal':u['raw_unit_ordinal'],'id':u['id'],'source_unit_key':u['source_unit_key'],'disposition':disposition,'reason':reason,'raw_node_id':('bias-phase1-raw:'+str(u['raw_unit_ordinal'])) if disposition=='NODE' else None,'kind':k,'original_lines':u['original_lines'],'containing_display_id':u['containing_display_id'],'prior_variances_raw_ordinals':u['prior_variances_raw_ordinals']})
inv={'schema':2,'phase':'NEW_BIAS_RAW_ONLY_BEFORE_NEW_TARGET_EXPOSURE','source_path':str(source.relative_to(root)),'source_sha256':source_sha,'scopes':scopes,'raw_unit_identity':'Unique current raw_unit_ordinal and source_unit_key(tag,line,column); original/synthetic id retained without collapsing same-line links. prior_variances_raw_ordinals records identical historical source rows.','prior_raw_snapshot':{'path':str(prior_path.relative_to(root)),'sha256':hashlib.sha256(prior_path.read_bytes()).hexdigest()},'units':units}
(out/'raw-unit-inventory.json').write_text(json.dumps(inv,indent=2,ensure_ascii=False)+'\n')
(out/'raw-unit-dispositions.json').write_text(json.dumps({'schema':2,'raw_only':True,'target_dependent_projection':False,'rows':rows,'counts':dict(Counter(r['disposition'] for r in rows)),'kind_counts':dict(Counter(r['kind'] for r in rows)),'named_TBODY_rule':'Named original TBODY equation rows are source NODEs, with true containing display IDs. This deliberately avoids the historical generic-TBODY exclusion mistake. No earlier bytes are changed.'},indent=2,ensure_ascii=False)+'\n')
with (out/'raw-source-reading.txt').open('w') as f:
 for u in units:
  if u['kind'] in ('heading','paragraph','display','definition-term','definition-description','list-item','bibliography-entry'):
   f.write(f"#{u['raw_unit_ordinal']} {u['id']} [{u['original_lines'][0]}-{u['original_lines'][1]}] {u['kind']}\n{u['text_with_tex']}\n\n")
for s in scopes:
 lo,hi=s['original_lines'];name=s['name'].replace(':','-')
 (out/(name+'.raw.html')).write_text('\n'.join(lines[lo-1:hi])+'\n')
print(json.dumps({'scopes':scopes,'raw_units':len(units),'dispositions':dict(Counter(r['disposition'] for r in rows)),'cited_bibliography_ids':sorted(cited)},indent=2))
