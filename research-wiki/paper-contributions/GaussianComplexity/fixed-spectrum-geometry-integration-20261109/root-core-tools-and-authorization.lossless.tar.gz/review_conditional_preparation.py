from pathlib import Path
import copy,gzip,hashlib,json,subprocess
P=Path('.astis/huanjian-gc-fixed-spectrum-geometry-integration-20261109')
Q=P/'independent-reader/conditional-proposal-v1'
sha=lambda b:hashlib.sha256(b).hexdigest()
dump=lambda x:(json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode()
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()=='ab8b47caed9f781191f8408154cd355c7e7c104c'
assert not subprocess.check_output(['git','diff','HEAD','--name-only']).strip()
rp=Q/'proposal-report.json'; assert sha(rp.read_bytes())=='6f9045472dc9f11da494942d065b093efab12c2cf385f6d83a379ad771a5e904'
r=json.loads(rp.read_bytes()); assert len(r['shared_paths'])==6
assert sha((Q/'freeze.json').read_bytes())=='3bebcf376f16376e2225accf6db7fb679034923a7e7a9b8a526dccf5334e3bda'
for row in json.loads((Q/'freeze.json').read_bytes())['files']:
    assert sha(Path(row['path']).read_bytes())==row['sha256']
assert sha((Q/'exact-shared-proposal.diff').read_bytes())=='4315b27035690db57a2ec3b617345bc582222aef55b0c9a3853d5cca212abcd5'
before={}; after={}
for row in r['shared_paths']:
    path=row['path']; p=Path(path)
    assert p.exists()==row['before_exists']
    before[path]=p.read_bytes() if p.exists() else None
    assert before[path] is None or sha(before[path])==row['before_sha256']
    z=Path(row['planned_after_archive']['path']).read_bytes()
    assert sha(z)==row['planned_after_archive']['gzip_sha256']
    raw=gzip.decompress(z); assert sha(raw)==row['planned_after_sha256']
    after[path]=raw
root='AutoSamplingTheory.lean'; test='Tests.lean'; basic='Tests/Basic.lean'; reg='AutoSamplingTheory/TechnicalLemmas/Registry.lean'
module='AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumGeometry'
assert after[root].replace(('import '+module+'\n').encode(),b'',1)==before[root]
assert after[test].replace(b'import Tests.GaussianComplexityFixedSpectrumGeometry\n',b'',1)==before[test]
assert after[basic].replace(b'formalizedTechnicalLemmaCount = 624',b'formalizedTechnicalLemmaCount = 623',1)==before[basic]
start=after[reg].index(b'  {\n    key := "gaussian-complexity.fixed-spectrum-geometry",')
end=after[reg].index(b'  {\n    key := "gaussian-complexity.single-block-separation",',start)
entry=after[reg][start:end]
assert after[reg].replace(entry,b'',1).replace(('import '+module+'\n').encode(),b'',1)==before[reg]
assert after[reg].count(b'status := LemmaMemoryStatus.formalizedLocal')==624
case='website/content/samplewiki_companion_frontiers.json'
old=json.loads(before[case]); new=json.loads(after[case]); maskedold=copy.deepcopy(old); maskednew=copy.deepcopy(new)
for x in [maskedold,maskednew]:
    x['cases'][4]['reader_guide'][3]='<OWN>'; x['cases'][4]['theorems'][1]['boundary']='<OWN>'
assert maskedold==maskednew
oldguide=old['cases'][4]['reader_guide'][3]; newguide=new['cases'][4]['reader_guide'][3]
oldbound=old['cases'][4]['theorems'][1]['boundary']; newbound=new['cases'][4]['theorems'][1]['boundary']
raw=before[case]
for a,b in [(oldguide,newguide),(oldbound,newbound)]:
    token=json.dumps(a,ensure_ascii=False).encode(); assert raw.count(token)==1
    raw=raw.replace(token,json.dumps(b,ensure_ascii=False).encode(),1)
assert raw==after[case]
suffix=oldbound[oldbound.index(' Section 4.4 limits'):]; assert newbound.endswith(suffix)
assert not any(chr(92)*2 in s for s in [newguide,newbound])
card=next(p for p in after if p.startswith('research-wiki/sampling-sde-library/cards/'))
assert before[card] is None
assert 'No new conceptual transport' in after[card].decode() and 'A TV bound alone does not transfer an unbounded expected query cost' in after[card].decode()
static=P/'independent-reader/conditional-static-readback-v1.json'
assert sha(static.read_bytes())=='21ac218fbf03de8d2e5c95ad853bd47c1a95c9be8fb575f67470818069e6bc5d'
assert json.loads(static.read_bytes())['state']=='ACCEPTED_SCOPED_CONDITIONAL_PREPARATION_ONLY'
browser=P/'independent-reader/conditional-browser-preparation-v1/freeze.json'
assert sha(browser.read_bytes())=='3d595e704c1fc08770dc1ec8c66039bff0b4285c2dea2f3966e81bd085e1e1d4'
for row in json.loads(browser.read_bytes())['files']:
    assert sha(Path(row['path']).read_bytes())==row['sha256']
assert sha((P/'independent-reader/check_final_reader_v1.py').read_bytes())=='e579e632b218e028310130e068230db3be8d0cca4d0e01714ea0f4b49c46268c'
assert sha((P/'independent-reader/geometry_browser_common_v1.py').read_bytes())=='2be36d2794fa949989bbeee2db10606c68ff966ef1de27c2337b5b6a4c90ace0'
record={'reviewer':'/root','state':'EXACT_CONDITIONAL_SIX_PATHS_REVIEWED_UNAPPLIED',
    'candidate_commit':r['candidate_commit'],'proposal_report_sha256':sha(rp.read_bytes()),
    'exact_diff_sha256':sha((Q/'exact-shared-proposal.diff').read_bytes()),
    'scope':'One genuinely new public geometry node; exact root/import/Registry/count synchronization and own case two scalar tokens plus new module card. Private Test remains private; all three parents canonical. No conceptual-model/discovery/source-index duplication.',
    'raw_byte_checks':'Six planned payloads and frozen proposal/browser payload hashes verified; exact removal restores all old root/Tests/Registry bytes; only two old case scalar tokens change; all other case values and Section4.4 suffix retained; decoded TeX has no doubled backslashes.',
    'independent_static_readback_sha256':sha(static.read_bytes()),
    'browser_preparation':'Inspected new guards/checker and frozen preparation; actual sourceV/soleSTAB/core/gates/own metadata review/new root+OS authorization and independent original-image acceptance required. No old browser approval reuse.',
    'future_application_requires':['Genuine same-binding independent whole-module/sourceV by separate verifier, exact checked candidate and accepted audit','Fresh main is an ancestor, normal soleSTAB, concrete root actual six-path application authorization','Actual immutable-core official Lean/publication/contributor/semantic/frontier/site/graph gates','New separately scoped OS browser approval and actual desktop/mobile originals independently reviewed'],
    'application_or_browser_or_sourceV_or_Goal_complete':False}
out=P/'root-conditional-six-path-review.json'; assert not out.exists(); out.write_bytes(dump(record))
print(json.dumps({'state':record['state'],'record':str(out),'sha256':sha(out.read_bytes()),'six_payloads_only':True,'applied':False}))
