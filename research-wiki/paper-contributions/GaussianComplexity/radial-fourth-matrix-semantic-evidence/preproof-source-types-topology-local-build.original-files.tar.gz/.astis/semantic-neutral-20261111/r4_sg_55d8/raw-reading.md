# Frozen independent raw reading

Role: independent raw-source topology extractor. This packet contains no Lean/API search, implementation reading, prior source graph/report, typed theorem, proof construction, verification grant, intake grant, or process grant. It is frozen before receiving any type-only packet. It does not approve its own source topology.

The only mathematical source inspected is the pinned local HTML of *On Complexity of Gaussian Sampling*, arXiv:2610.20492v1: 951991 UTF-8 bytes, SHA-256 `6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915`. Locator and coverage claims are bounded to five exact windows. The whole C.2 window is inventoried, so downstream proof text remains visible as excluded context.

## Minimal mathematical boundary

Let d be an integer dimension, q an integer with q >= 0 and 2q+1 < d, r=q+1, and 1 <= i <= d. In this source regime d >= 2 and r >= 1. Let the g_a be independent N(0,I_d) vectors as in Lemma 4.4. The C.2 row variables gamma_i=((g_1)_i,...,(g_r)_i)^T are independent N(0,I_r). The calculation for a fixed i uses its row law, not independence between different rows.

The deterministic grid is theta_i=(i-1/2)pi/d. The source vector t_i has coordinates indexed by j=0,...,q: t_i[0]=1 and t_i[j]=sqrt(2)cos(j theta_i) for j>=1. Set R_i=||gamma_i||^2 and L=2r+3 log(1000d). Define

\[
Y_i=\frac1d(\gamma_i\gamma_i^\top\otimes t_it_i^\top)\mathbf1_{\{R_i\le L\}}.
\]

Three roots delimit this packet:

\[
\mathbb E[R_i\gamma_i\gamma_i^\top]=(r+2)I_r, \tag{source Ex113}
\]

\[
Y_i^2=\frac{R_i\|t_i\|^2}{d^2}
(\gamma_i\gamma_i^\top\otimes t_it_i^\top)
\mathbf1_{\{R_i\le L\}}, \tag{source Ex114}
\]

\[
\boxed{\mathbb E[Y_i^2]\preceq
\frac{(r+2)\|t_i\|^2}{d^2}
(I_r\otimes t_it_i^\top).} \tag{individual consumer}
\]

The last root is the **source-supported termwise inference** immediately underlying the first inequality in EGx11, motivated by p14.3's instruction to drop the indicator. It is not separately displayed as an individual theorem in the paper. No sum is part of this root. The exact deterministic factor ||t_i||^2 is retained. Replacing it by 2r is a later coarsening and is outside this minimal packet.

The cutoff is non-strict (`<=`), exactly as Ex107/Ex114. Its specific finite value is retained as a literal source definition; the moment and indicator-deletion calculation itself does not use L's positivity, tail formula, numerical size, or a high-probability truncation event.

## Coordinate expansion and omitted obligations

Write X_a=gamma_i[a], with a=1,...,r. A standard normal has second moment 1 and fourth moment 3. For a!=c, row-coordinate independence gives E[X_c^2 X_a^2]=1. Consequently

\[
\mathbb E[R_i X_a^2]
=\mathbb E[X_a^4]+\sum_{c\ne a}\mathbb E[X_c^2X_a^2]
=3+(r-1)=r+2.
\]

This is the diagonal argument stated in p14.2. The scalar moment evaluations and mixed-moment factorization are background facts used without proof in this bounded source. They are dependency obligations, not assumptions to append to a source-facing theorem.

For a!=b, flipping X_a preserves the N(0,I_r) law and R_i, and negates R_i X_a X_b. Once absolute integrability is established, its expectation is zero. This is the source's sign-symmetry argument. In particular the zero entries are off-diagonal entries of the weighted radial moment matrix; no covariance-only shortcut would establish the degree-four expression.

All polynomial entries are measurable. Diagonal degree-four terms are integrable by the scalar/mixed moments above. Off-diagonal integrability follows, for example, from

\[
|R_iX_aX_b|\le \tfrac12R_i(X_a^2+X_b^2).
\]

Thus all entries of R_i gamma_i gamma_i^T have genuine finite expectations before symmetry and finite-sum linearity are applied. The packet records this omitted analytic bookkeeping explicitly. The source supplies no separate citation for scalar fourth moments, sign invariance, or these integrability details.

The rank-one square identities in p14.2, Kronecker multiplication, and indicator idempotence produce Ex114. Define

\[
W_i=\frac{\|t_i\|^2}{d^2}
((R_i\gamma_i\gamma_i^\top)\otimes t_it_i^\top).
\]

The scalar R_i is nonnegative; rank-one outer products are symmetric PSD; their Kronecker product is symmetric PSD. Hence W_i is symmetric PSD and Y_i^2=W_i 1_{R_i<=L} preceq W_i pointwise. This is a Loewner inequality: B-A is PSD for A preceq B. It is not an entrywise inequality. Individual entries of the rank-one factors may be negative.

The fixed deterministic tensor coefficients preserve entrywise absolute integrability; truncation cannot enlarge absolute entry values. Finite-dimensional expectation preserves Loewner order by integrating v^T(W_i-Y_i^2)v>=0 for each deterministic v. Fixed scalar/tensor factors commute with expectation. Applying Ex113 yields the boxed individual bound. These are explicitly marked omitted-in-source bookkeeping nodes in the graph.

## Tensor order, meaning, and endpoint audit

- Gaussian coordinates form the **first** tensor factor, and cosine coordinates form the second, matching Ex85's row gamma_i tensor t_i and Ex107. In pair indices ((a,j),(b,k)), the tensor entry is X_a X_b t_i[j] t_i[k]. On the bound's right side it is delta_ab t_i[j] t_i[k]. The source does not specify a numeric flattening order beyond its tensor convention; any changed flattening requires an explicit permutation adapter.
- Y_i is an r^2 by r^2 real symmetric matrix. Y_i^2 denotes matrix multiplication, not entrywise squaring. E[Y_i^2] is not (E[Y_i])^2, and the packet does not introduce centered matrices Z_i.
- The bound holds separately for every permitted i. It is deterministic after expectation; it has no probability event, failure budget, confidence parameter, or exceptional set conclusion. Constants are exactly d^(-2), r+2, and the deterministic factor ||t_i||^2.
- q=0 gives r=1, t_i=(1), gamma_i=(G), R_i=G^2, and L=2+3 log(1000d). The diagonal is E[G^4]=3; the mixed sum is empty; no off-diagonal case exists. The consumer becomes E[d^(-2)G^4 1_{G^2<=L}]<=3/d^2. This case remains in scope.
- r=0 is outside the source's r=q+1 with q>=0. No q>=1 restriction is permitted. The source's 2q+1<d condition and midpoint definition are retained as standing source context even though this local Gaussian calculation does not need their full strength.
- No kappa, spectral eigenvalue, n=2q+1, D_n, tau, algorithm output, Krylov representation, norm bound ||t_i||^2<=2r, Gram sum identity, radial truncated mean a, or cross-row independence is an ingredient of the exact individual estimate.

## Bounded coverage and graph closure

`coverage.json` inventories every paragraph, equation table, heading, and every mathematical DOM member in the five specified windows. A multi-clause NODE paragraph states which clauses are excluded. `locators.json` gives exact raw substring hashes and LF/UTF-8-byte/Unicode-codepoint intervals for all atoms and mathematical DOM members, plus structural containers. `raw/*.html` are exact source substrings; the corresponding TXT files are a readable extraction using each math element's alttext, with entities decoded and markup removed. TXT extraction is not the authoritative source hash.

The source graph has 18 nodes and 38 prerequisite edges, with complete backward closures for all three roots. Its single route follows p14's coordinate moments, rank-one square and PSD indicator deletion. All 18 nodes are in the primary root's backward closure. Source gaps are omitted justifications, not declarations of source invalidity or of Lean impossibility.

Explicitly excluded downstream: every sum in EGx11, its use of 2r and the cosine Gram sum, centered-square subtraction Ex118, v_* Ex119, weighted centered-square Ex120, matrix Bernstein, event combination, simplified bound, Fact C.6 and the final Lemma 4.4 argument. No mathematical completion, compiled result, or source-fidelity acceptance is asserted.

Frozen disposition: await a fresh **type-only** packet for comparison. Do not supply implementation bodies, proof transcripts, compiler repairs, prior verdicts, or existing graph reports to this role.
