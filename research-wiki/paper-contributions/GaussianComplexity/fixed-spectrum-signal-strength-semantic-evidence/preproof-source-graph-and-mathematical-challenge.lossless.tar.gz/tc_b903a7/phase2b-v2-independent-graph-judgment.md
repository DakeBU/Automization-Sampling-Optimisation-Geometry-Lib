# Append-only v2 mathematical source-topology judgment

Actor: `/root/signal_topology`. This is a new judgment of the repaired graph;
it does not edit, replace or retrospectively approve the predecessor graph.
All Phase 1 cognition, Phase 2a statement review, and Phase 2b graph/HOLD
freezes remain intact.

## Decision

**ACCEPT the repaired v2 mathematical source topology and scoped raw-source
coverage. H1 and H2 are resolved in v2. The C.7 raw0043 refinement is also
resolved. No additional mathematical topology HOLD is identified for the
reviewed v2 scope.**

The exact public numerical root and private actual-law zero-event root remain
accepted as mathematical source/adaptation routes with explicitly unresolved
standard inputs. The general C.8 and Lemma 4.5 source boundaries now retain
their arbitrary integer-frequency domain independently of the selected
odd-frequency interface. The conditional remark forecast cannot be read as
an unconditional proof edge.

This acceptance does not discharge the named source gaps, inspect a Lean
implementation, certify a proof, certify the whole paper, prove full Ex26,
or give source-Anchor/Registry status to the private zero-threshold application.
It is not process/chronology admission. The older graph's H1/H2 disposition
remains the correct frozen judgment of that older artifact.

## Evidence and exposure

New mathematical data were read only from the authorized repair directory
`.astis/semantic-neutral-20261110/sg_41e7c9/phase2_v2_a91d3f/`:

| File | Independently verified SHA-256 |
| --- | --- |
| `source_graph.json` | `13a94a04bd05dfc0f7952b37e240c4bb965f43e084985abd19e72d536baa3ff9` |
| `source_unit_dispositions.json` | `cd33ebd900582527e5c512bc8c4dc01d9708294e416ea170604513470097f350` |
| `root_closures.json` | `7b4ae2378429b277e518cbc52aa81ce832c74fbe7de5e127ea4bc9312e7259ff` |
| `generic_source_boundary_closures.json` | `25308ea731d51ebeb4569620d46fcef8d55755c43af3a9afb5b59c90ea03e779` |
| `conditional_discharge_audit.json` | `1a5b523d8ae19b5cee6f62783273937adf100b90da5df0bd7625a5c7c736e8ba` |
| `exact_field_diff.json` | `08b9a6f793b1ca85c6c072e879b4007a3cc9c26dcc938f0aea93f382e950c58e` |

I compared them with the previously authorized predecessor mathematical
records, my own frozen source cognition and my exact sealed-statement review.
I did not open `repair_rationale.md`: the actual revised nodes, edges,
dispositions and mathematical conditional entries were sufficient to judge
the repair directly. I did not open any extractor verdict artifact,
provenance, cognition, build script or freeze, any implementation/API, any
parent process-planning metadata or a process/chronology audit. The authorized
field-diff contains references to my own prior H1/H2 judgment and pending
review labels; those metadata are not mathematical authority and were not
used to decide this review.

## H1 resolution: source generality is upstream

The new `s:generic-cosine-statistic` defines the source D_n and quadratic for
an arbitrary integer 1<=n<d. The new `s:generic-moment-law` gives the original
Euclidean Gaussian law and expected moments on the source positive spectral
domain. Its inputs contain no q, delta, query cap, Fin-coordinate translation
or Bochner-interface adapter. The `gap:gaussian-semantics` input remains
explicit, rather than being silently proved by introducing a generic node.

`e:trace` now consumes this generic source law plus C.7. Thus the second-moment
finite sums, the grid aliases and both C.8 mean calculations apply throughout
the source integer-frequency domain. `e:variance` likewise consumes the
generic law, M formula, grid and Gaussian standard-input gap; it has no
odd-frequency or selected-interface prerequisite. The generic law also
replaces the selected adapter in `e:rotation`, so the original orthogonal
target transport is upstream of specialization too.

The relevant source-fact/component nodes explicitly retain arbitrary integer
1<=n<d. In particular, the even frequencies allowed by C.8 and Lemma 4.5
are no longer restricted by an n=2q+1 ancestor. The additional distance
condition remains attached to the lower-bias conclusion; it is not added to
the exact means or variances. M is correctly described as independent of n.

The selected `a:literal-law` is now reached by
`s:generic-moment-law` together with the query-frequency definition,
normalization and `a:domain`. It is expressly a downstream literal-interface
specialization. That is the right mathematical direction: first the author's
general Gaussian/moment semantics, then the selected n=2q+1 instance and
Fin/Bochner identification. No general author-source node depends on that
selected interface.

I independently traversed the dependency-true backward closures for `c:c8`,
`c:variance`, `s:lemma45-means-variance` and `s:lemma45-bias`. All submitted
node/edge/leaf/source-gap sets and outside-closure complements match the
independent traversal. None contains `a:literal-law`, `a:domain`,
`s:cosine-statistic`, `s:scalar-regime` or `s:moment-normalization`. Reading
the actual node statements and uses, not merely checking these absent IDs,
confirms that their remaining parents carry generic source semantics.

H1 is therefore resolved for this successor graph. This is a topology/scope
repair; it does not add a source correction or require a new public binder.

## H2 resolution: affine comparison and conditional forecast are distinct

`s:kappa2-comparison` now contains only the same-rotation affine matrix identity
and exact reply simulation. Its proof-input edge no longer concludes the
signal forecast from the construction alone.

The separate `s:kappa2-preview` is explicitly a conditional explanatory
forecast. It retains q natural, n=2q+1<d, the independent-start Krylov/output
representation, sufficiently small tau including tau<=1/2, the bias-distance
condition, and the eventual fixed-delta/query-cap regime for the power-law
algorithm-versus-target comparison. These are exactly the kinds of conditions
whose absence prompted H2; they are not claimed as discharged at the preview.

The actual `e:kappa2-preview` has `dependency:false` and
`logic:non-implicational`. Its use description keeps the quantitative forecast
conditional and points to the later theorem route for the relevant domain,
algorithm-event and common-threshold discharges. CD21 agrees with that
mathematical distinction and keeps the C.1/C.2 consultation boundaries visible.
It does not assert an arbitrary-q implication or invent an alternative route.

Thus the remark can remain fully represented without implying an unconditional
consequence. It is outside both exact selected proof closures. H2 is resolved
in v2.

## C.7 raw0043 refinement and raw coverage preservation

`A3.SS3:raw:0043`, source ID `A3.SS3.p2.3`, is now mapped to both `c:c7` and
`c:majorant`. The reason explicitly distinguishes the sentence combining the
identities to prove the expansion from the transition to the majorant. Its
unchanged raw hash is
`de66c96be6e1cc62cc1da3891f2fa2ba0200bce86f7683a03bc05606fab78a3a`.
The node association now matches the already-present `e:c7` consumer use and
does not conflate the algebraic conclusion with convergence.

The remark's source units are associated with the two separate remark nodes.
The general Lemma 4.5 introductory paragraph is also associated with the new
generic source definitions. No raw source unit was deleted or changed:
predecessor and v2 unit sets, source IDs, raw SHA-256 values and NODE/EXCLUDED
dispositions are identical. The referenced inventory digest is unchanged.
The original substantive paragraph/display coverage judgment therefore
continues to apply, with the reviewed scope refinements. The changes do not
convert a previously omitted source region into a false completion claim.

## Selected roots and named gaps remain unchanged in meaning

Both exact root-node records are identical as JSON values to their
predecessors. Their signature digests remain:

- public: `4ba04efc22eb664771b1b2f471dc62cd50694a12f70712010287908788362d91`;
- private: `e24c33732826ea528bfd2d9f959b8963a022b35989f6e5740e3f7445a23de7d5`.

The graph's source and sealed-projection digests also remain unchanged. No
successor statement or let-body modification is proposed, so the independently
frozen Phase 2a statement/binder/definition acceptance still applies.

I recomputed both exact selected closures from the revised dependency edges.
Their node, edge, leaf and source-gap sets and outside-closure complements
match the submitted records. The added generic source semantics sit upstream
of the selected adapter and roots. The public route still excludes the
variance/Chebyshev, tau, rotated detector and algorithm/TV branches. The
private route still adds the actual diagonal variance/sign and zero-threshold
probability adaptation, without claiming the original shifted detector.

Every SOURCE_GAP node record is unchanged. The public closure still has the
Gaussian semantics, geometric-series, trigonometry, logarithmic calculus and
power/asymptotic standard inputs. The private closure still adds the
Chebyshev/probability input. C.1, C.2, C.4, the dimension proof, C.6 and [22]
have not been newly read or discharged. The numerical wording caution in the
off-root Section 4.4 limitation remains a preserved boundary; the repair does
not newly certify it as an unconditional <=1/2 consequence of Lemma 4.4.

All v2 NODE-unit root memberships agree with independent recomputed closures.
The supplied field diff exactly matches an independently computed recursive
JSON diff for each predecessor/successor mathematical file it covers, with
matching before/after hashes. This establishes the limited edit scope, not
mathematical truth by itself. The acceptance above follows from reviewing the
actual source meanings, edge directions and retained conditions.

## Append-only HOLD disposition

- H1 in the predecessor freeze: preserved; resolved by v2 generic source
  semantics and downstream selected specialization.
- H2 in the predecessor freeze: preserved; resolved by the conditional,
  dependency-false explanatory preview and separated affine comparison.
- C.7 raw0043 refinement: resolved by the two-component mapping.
- New mathematical topology HOLD for this exact v2 scope: none found.
- Named source/proof gaps: remain unresolved and are not upgraded by review.

No process or chronology conclusion is made here. Any later prospective
process-admission review must be separately recorded after this mathematical
judgment is frozen, without editing these mathematical freezes.
