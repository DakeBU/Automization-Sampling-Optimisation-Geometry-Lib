# Phase 1 independent source cognition

This record was written from the pinned original HTML, before receipt of an exact target, anonymous reconstruction, Lean statement, implementation, API context, source graph, semantic audit, authored lesson, publication packet or prior review. It covers the complete original Section 2, Section 4 and Appendix C.3. It is source cognition, not a source-completion, native-source or equivalence verdict. The exhaustive mechanically indexed source units and exact raw locations are in `source_unit_inventory.json`; the source slices are preserved byte for byte alongside this file.

## Section 2: conventions and the sampling problem

1. `S2.p1.1`: The norm is Euclidean; `I_d` is the `d × d` identity. For symmetric matrices, `A ≼ B` means `B-A` is positive semidefinite.
2. `S2.p2.1`: `O(n)={O∈R^{n×n}:OᵀO=I_n}` carries Haar **probability** measure. Its determinant `+1` and `-1` components each have Haar probability `1/2`. For `b∈{-1,+1}`, `μ_{n,b}` is Haar probability conditioned on `det O=b`. This measure notation is different from the later scalar target moment `μ_n`.
3. `S2.SS0.SSS0.Px1.p1.1` and `S2.Ex1`: The target class is centered Gaussians, expressly removing the separate problem of locating the target. For integer `d≥1` and parameter `κ≥1`, spectral rescaling normalizes the precision class to

   `A_{d,κ}={A∈R^{d×d}: A=Aᵀ, I_d≼A≼κI_d}`.

4. `S2.SS0.SSS0.Px1.p1.2`, equation (1), and `...Px1.p2.1`: An input precision `A` defines `f_A(x)=xᵀAx/2` and `π_A=N(0,A^{-1})`. The **exact** first-order response at `x∈R^d` is `(f_A(x),∇f_A(x))=(xᵀAx/2,Ax)`. A matrix-vector response determines both components, while a first-order response contains `Ax`. Exact value-and-gradient, gradient-only and matrix-vector query complexities therefore coincide on this class. This does not assert the equivalence for approximate/noisy oracles or a broader target class.
5. `...Px2.p1.1`: Queries and stopping decisions are Borel functions of private randomness and prior responses; that randomness is independent of the input. The output is any `R^d`-valued Borel function of the same information. A fixed budget `T` means at most `T` queries **for every admissible input and every realization of the randomness**. It is a runwise deterministic cap, not an expected-cost bound. The output is not assumed to lie in the observed query/reply span.
6. `...Px3.p1.1`, `S2.Ex2`, `...Px3.p1.2`: For probabilities on a common measurable space,

   `TV(P,Q)=sup_{measurable B}|P(B)-Q(B)|=(1/2)∫|p-q|dλ`,

   with any common dominating measure `λ`. Every measurable `h` valued in `[0,1]` obeys `|E_P h-E_Q h|≤TV(P,Q)`.
7. `...Px4.p1.1`, equation (2), `...Px4.p1.2`: For fixed `A`, `ρ_A^Alg` is the entire output law, averaging all internal randomness. For `0<ε<1`,

   `Q_G(d,κ,ε)=inf{T∈Z_{≥0}: ∃Alg with fixed budget T, sup_{A∈A_{d,κ}}TV(ρ_A^Alg,π_A)≤ε}`.

   Accuracy is uniform over inputs after averaging over the seed. A per-seed success claim or an input-average accuracy guarantee is a different scope. The source does not state a separate convention here for an empty infimum.

## Section 4: the fixed-spectrum hidden-eigenbasis construction

8. `S4.p1.1`: The source attributes to `[22]` an `Ω(log d)` lower bound for centered Gaussian sampling with `I_d≼A≼2I_d` at TV error `ε=1/10`. This is an attributed fact; I did not consult `[22]` beyond its original bibliography entry.
9. Theorem 4.1 (`S4.Thmtheorem1`, `S4.Ex9`): **For every fixed** `δ∈(0,1)`, **there exists** `d₀(δ)` such that **for every integer** `d≥d₀(δ)`, **every** `2≤κ≤d^{1-δ}` and **every** `0<ε≤1/10`,

   `Q_G(d,κ,ε)≥(δ/256)√κ log d`.

10. `S4.p2.1`: Relative to the internally referenced Theorem 3.1, the claimed improvement also covers `2≤κ<4` and `1/16<ε≤1/10`. The lower bound remains valid if the spectrum is supplied to the algorithm. It does not diverge as `ε→0`; the condition-number range is restricted. I did not inspect Theorem 3.1 outside this authorized slice.
11. Section 4.1 (`S4.SS1.p1.1`, equation (11), `...p1.2`): For `d≥2`, `κ≥2`,

   `θ_i=(i-1/2)π/d`, `λ_i=(κ+1)/2+((κ-1)/2)cosθ_i`, `Λ=diag(λ_1,…,λ_d)`.

   The grid is described as cosine/Chebyshev nodes, extending a construction attributed to `[22, Section 9.2]` from spectral interval `[1,2]` to `[1,κ]`. Draw `O~Haar(O(d))` independently of the private seed, set `A=OΛOᵀ`, and use `f_A(x)=xᵀAx/2`, `π_A=N(0,A^{-1})`.
12. `S4.SS1.p2.1`: The spectrum is deterministic and may be revealed; the Gaussian normalizing constant is consequently known. The hidden information is the eigenbasis `O`.
13. Remark 4.2 (`S4.Thmtheorem2`): At `κ=2`, equation (11) is the construction attributed to `[22]`. With the same rotation, `A=(κ-1)A_2-(κ-2)I_d`, so a matrix-vector reply for either matrix determines the reply for the other. The proof compares `Σ_i cos(nθ_i)⟨x,Oe_i⟩²` with `||x||²`, for `n=2q+1`. The algorithm-output ratio is stated to be `d^{-Ω(1)}` in absolute value by Lemma 4.4, while the absolute ratio of target means is `e^{-Θ(n/√κ)}` by Lemma 4.5. This motivates frequencies of order `√κ log d` and the `√κ` gain.

## Section 4.2: four stated inputs to the lower-bound proof

14. `S4.SS2.p1.1`: The author assigns four separate roles: Lemma 4.3 represents the algorithm output, Lemma 4.4 uniformly bounds the cosine quadratic form on that representation space, Lemma 4.5 evaluates target means/variances, and Lemma 4.6 establishes admissibility. Their proofs are deferred to Appendix C. Only C.3 is authorized/read in this phase.
15. `S4.SS2.SSS0.Px1.p1.1`: The deferred-rotation/Krylov argument is attributed to `[22, Lemma 9.2]` and uses rotational symmetry of the unexposed eigenbasis.
16. `...Px1.p2.1`, `S4.Ex10`: Given vectors `g_1,…,g_{q+1}∈R^d`,

   `K_q(g_1,…,g_{q+1})=span{Λ^j g_a:1≤a≤q+1, 0≤j≤q}`.

17. Lemma 4.3 (`S4.Thmtheorem3`, `S4.Ex11`): Fix integer `q≥0` with `2q+1<d`; in the surrounding `q`-query algorithm experiment, if `X` is the output, **there exist** independent vectors `g_1,…,g_{q+1}~N(0,I_d)` such that `OᵀX∈K_q` almost surely. The adjacent explanatory paragraph and the proof use an extension preserving the joint law of `(O,X)`. The source asserts independence among the Gaussian starting vectors; it does not here assert their independence from every other variable of the extended experiment.
18. `...Px1.p3.1`: The extra starting vector accounts for an output outside the query/reply span. Equivalently `OᵀX=Σ_{a=1}^{q+1}p_a(Λ)g_a`, with degree at most `q`; coefficients may depend on the **entire extended experiment**. The next estimate must therefore hold simultaneously for all vectors of `K_q`. Appendix C.1 is referenced but not read.
19. `...Px2.p1.1`, `S4.Ex12`, `...Px2.p1.2`: Define `n=2q+1` and `D_n=diag(cos(nθ_1),…,cos(nθ_d))`. This frequency is above all frequencies produced by products of degree-`q` cosine polynomials.
20. Lemma 4.4 (`S4.Thmtheorem4`, `S4.Ex13`, `S4.Ex14`): There exists **one absolute** `C>0` with the following property. For `q≥0`, `2q+1<d`, independent standard Gaussian `g_1,…,g_{q+1}`, and their `K_q`, define

   `τ_{d,q}=C[(q+1)√(log d/d)+((q+1)(q+1+log d)log d)/d]`.

   **If** `τ_{d,q}≤1/2`, then with probability at least `0.99`, **for every** `u∈K_q`,

   `|uᵀD_nu|≤2τ_{d,q}||u||²`.

   The probability is outside the universal quantifier over `u`; it is a uniform event. Appendix C.2 is referenced but not read.
21. `...Px2.p2.1`: Since `λ_i` is a **nonconstant** affine function of `cosθ_i`, the same space is spanned by `((g_a)_i cos(jθ_i))_{i=1}^d`, for `a≤q+1`, `j≤q`. The resulting estimate is independent of `κ`.
22. `...Px2.p3.1`, `S4.Ex15`: On that event, the output representation implies `|XᵀOD_nOᵀX|≤2τ_{d,q}||X||²`.
23. `...Px3.p1.1`, Lemma 4.5 (`S4.Thmtheorem5`, `S4.EGx1`, `S4.Ex17`): For `κ≥2`, take `U~N(0,Λ^{-1})` and `r=ρ_κ=(√κ-1)/(√κ+1)`. For integer `1≤n<d`, define `D_n=diag(cos(nθ_i))`, `M=E||U||²`, `μ_n=E[UᵀD_nU]`. Then

   `M=(d/√κ)(1-r^{2d})/(1+r^{2d})`,

   `(-1)^n μ_n=(d/√κ)(r^n-r^{2d-n})/(1+r^{2d})`.

   Both `Var(||U||²)` and `Var(UᵀD_nU)` are at most `2M≤2d/√κ`. **If additionally** `d-n≥√κ`,

   `(1-e^{-4})e^{-3n/√κ}≤|μ_n|/M≤e^{-2n/√κ}`.

   The general moment frequency is not restricted to odd `n`; oddness is imposed by the later query-budget test. The exact means and variance bounds have no `d-n≥√κ` premise. The normalized lower bound has this extra premise. Appendix C.3 supplies the proof below.
24. `...Px3.p2.1`: For an exact conditional target sample `Y|O~π_A`, `U=OᵀY` has law `N(0,Λ^{-1})`, with `||Y||²=||U||²` and `YᵀOD_nOᵀY=UᵀD_nU`. This transfers the stated means and variances to the original coordinates.
25. `...Px4.p1.1`, Lemma 4.6 (`S4.Thmtheorem6`): **For every** `O∈O(d)`, `A=OΛOᵀ` obeys `I_d≼A≼κI_d`. Appendix C.4 is referenced but not read.

## Section 4.3: the manuscript's test-event proof

26. `S4.SS3.p1.1`, `...p2.1`: Fix `δ∈(0,1)`, `2≤κ≤d^{1-δ}`, `0<ε≤1/10`. Suppose an algorithm uses **at most** `q≤(δ/256)√κ log d` queries and satisfies per-input `TV(ρ_A^Alg,π_A)≤ε` for **every** admissible `A`. Lemma 4.6 permits the random hard input.
27. `...p3.1`, `S4.EGx2`, `...p3.2`: Set `n=2q+1`, `τ=τ_{d,q}`. With the first-kind degree-`n` Chebyshev polynomial `T_n`, define

   `S_A(x)=(-1)^n xᵀT_n((2A-(κ+1)I_d)/(κ-1))x-2τ||x||²`,

   `E_A={x:S_A(x)>0}`.

28. `...p4.1`: For `x≠0`, `w_i(x)=|⟨x,Oe_i⟩|²/||x||²` is the eigenvector energy fraction. `T_n(cosθ_i)=cos(nθ_i)`, so membership is equivalent to `(-1)^nΣ_iw_i(x)cos(nθ_i)>2τ`. The event selects a large cosine coefficient with the target's sign. The divided-energy explanation is restricted to `x≠0`; the original quadratic test itself is defined also at zero.
29. `...SSS0.Px1.p1.1`, `S4.Ex20`: The query bound gives `q+1≤d^{(1-δ)/2}log d` and hence `n=o(d)`; substitution gives

   `τ≲d^{-δ/2}(log d)^{3/2}+d^{-δ}(log d)^3≲d^{-δ/2}(log d)^3→0`.

30. `...Px1.p1.2`, `S4.Ex21`, `...Px1.p1.3`, `S4.Ex22`: For sufficiently large `d` depending only on `δ`, `n<d` and `τ≤1/2`. Lemma 4.3 places `OᵀX` in `K_q` on a law-preserving extension; Lemma 4.4 gives `|XᵀOD_nOᵀX|≤2τ||X||²` with probability `≥0.99`, hence `S_A(X)≤0` there. Therefore `E_A[ρ_A^Alg(E_A)]≤0.01`.
31. `...Px2.p1.1`, `...Px2.p2.1`, `S4.Ex23`: Put `M=tr(Λ^{-1})`, `μ_n=tr(D_nΛ^{-1})`, `β=|μ_n|/M`. Since `n=o(d)` and `√κ≤d^{(1-δ)/2}=o(d)`, eventually `d-n≥√κ`. Lemma 4.5 yields

   `β≥(1-e^{-4})e^{-3n/√κ}≥b d^{-δ/4}`, `b=(1-e^{-4})e^{-3}`,

   using `3n/√κ≤3+(3δ/128)log d`.
32. `...Px2.p2.2`, `S4.Ex24`: The source uses `r≤e^{-1/√κ}` and `d≥√κ` to obtain `r^{2d}≤e^{-2}<1/3`, then `M≥d/(2√κ)≥d^{(1+δ)/2}/2`. Together with the bound on `τ`,

   `τ/β≤(C'/b)d^{-δ/4}(log d)^3→0`,

   `Mβ²≥(b²/2)√d→∞`.

33. `...Px2.p2.3`: These estimates are asserted uniformly over the specified parameter range. Choose `d₀(δ)` so all preceding conditions hold, and also `τ≤β/4`, `Mβ²≥320`. This is why the dimension threshold depends on `δ` alone, rather than on a particular admissible `κ` or `ε`.
34. `...Px2.p3.1`, `S4.Ex25`: For **fixed** hard-family `A`, draw `Y~π_A`, put `Z=S_A(Y)`. The signed cosine quadratic form has mean `βM`; the squared norm has mean `M`; both variances are `≤2M`. The centered `L²` triangle inequality gives

   `EZ=(β-2τ)M≥βM/2`,

   `Var(Z)≤(√(2M)+2τ√(2M))²≤8M`.

35. `...Px2.p3.2`, `S4.Ex26`: Chebyshev gives **for every** hard-family `A`,

   `π_A(E_A)=P(Z>0)≥1-Var(Z)/(EZ)²≥1-32/(Mβ²)≥0.9`.

36. `...Px3.p1.1`, `S4.Ex27`, `...Px3.p1.2`: The uniform per-input TV guarantee implies `π_A(E_A)-ρ_A^Alg(E_A)≤ε`; average in `A` to obtain

   `0.89≤E_A[π_A(E_A)-ρ_A^Alg(E_A)]≤ε≤0.1`,

   the source's contradiction. The test event depends on `A`, but is used as a measurable distinguishing event, not as an additional oracle capability of the algorithm.

## Section 4.4: limits the author assigns to this proof

37. `S4.SS4.p1.1`: The dimension/condition-number restriction and absence of error dependence are limitations of the analysis, discussed separately.
38. `...SSS0.Px1.p1.1`: A uniform-`K_q` approach is said not to extend the `Ω(√κ log d)` bound to `κ≳d/log²d`. The enlarged space has `(q+1)²` generating vectors; distinct eigenvalues enter the dimension claim.
39. Lemma 4.7 (`S4.Thmtheorem7`, `S4.Ex28`): **For every integer** `q≥0` and independent standard Gaussian starting vectors,

   `dim K_q=min{d,(q+1)²}` almost surely.

40. `...Px1.p2.1`, `S4.Ex29`, `...Px1.p2.2`: When `(q+1)²≥d`, the space is a.s. all of `R^d`. If `n=2q+1<d`, `Σ_{i=1}^d cos²(nθ_i)=d/2`; at least one coordinate has absolute cosine at least `1/√2`. Its unit vector gives

   `sup_{u∈K_q\{0}}|uᵀD_nu|/||u||²≥1/√2`.

   The text says its separating test requires this supremum at most `1/2`, and concludes a uniform-space bound cannot apply after saturation. This statement is recorded at its source scope, not promoted to a lower-bound impossibility for every technique.
41. `...Px2.p1.1`, `S4.Ex30`, `...Px2.p1.2`: For a threshold `t`, the source says the uniform algorithm estimate requires `t≥a`, while target separation via Lemma 4.5 and Chebyshev requires `t<β=|μ_n|/M`. It attributes to the Bernstein calculation in **Fact C.6** the requirement `a≥c/√d` even for a certified failure probability below one. C.6 was referenced but not read. With `β≤e^{-2n/√κ}`, the necessary displayed chain is

   `c/√d≤a<|μ_n|/M≤e^{-2(2q+1)/√κ}`.

   Logarithms give `q=O(√κ log d)` independently of `ε`, so changing this threshold or constants does not supply a bound diverging as `ε→0`.
42. Remark 4.8 (`S4.Thmtheorem8`): The author explicitly limits these obstructions to the proof and leaves open stronger bounds from the same fixed-spectrum family. The final open-question sentence is repeated in the raw source; it does not add another claim.

## Appendix C.3: source proof of the target-moment calculation

43. `A3.SS3.p1.1`: Recall exactly the grid and eigenvalues above. The announced order is inverse-spectrum cosine expansion, finite-grid summation, then variance and normalized-bias estimates. The ambient hard-family setting supplies `d≥2`, `κ≥2`, and the Lemma 4.5 definitions. These are contextual premises, not conditions invented by this record.
44. Fact C.7 (`A3.Thmtheorem7`, `A3.Ex133`): For **every real** `θ`,

   `2/[κ+1+(κ-1)cosθ]=(1/√κ)[1+2Σ_{j≥1}(-r)^j cos(jθ)]`.

   The series converges **absolutely and uniformly in θ**.
45. `A3.SS3.p2.1`, `A3.EGx14`: Since `0<r<1`, geometric series give

   `1+2Σ_{j≥1}(-r)^jcos(jθ)`

   `=1-r e^{iθ}/(1+r e^{iθ})-r e^{-iθ}/(1+r e^{-iθ})`

   `=(1-r²)/(1+2r cosθ+r²)`.

46. `...p2.2`, `A3.Ex136`, `...p2.3`: Use

   `(1-r)/(1+r)=1/√κ`,

   `[1+2r cosθ+r²]/(1-r)²=[κ+1+(κ-1)cosθ]/2`

   to obtain the expansion.
47. `A3.Ex137`, `...p2.4`: The uniform majorant is `Σ_{j≥1}|(-r)^jcos(jθ)|≤Σ_{j≥1}r^j=r/(1-r)`, independent of `θ`; it supplies the absolute/uniform convergence assertion.
48. Fact C.8 (`A3.Thmtheorem8`, `A3.Ex138`): For `1≤n<d`, the exact two moment formulas are the same as those stated in Lemma 4.5. The finite-size correction has denominator **`1+r^{2d}`**, and the signed cosine numerator is **`r^n-r^{2d-n}`**.
49. `A3.SS3.p3.1`, `A3.Ex139`, `...p3.2`: For **every integer** `k`,

   `Σ_{i=1}^d cos(kθ_i)=d(-1)^a` if `k=2ad`, `a∈Z`, and is `0` otherwise.

   Off `2dZ`, the finite sum is `sin(kπ)/[2sin(kπ/(2d))]=0`. At `k=2ad`, each term is `cos(2aiπ-aπ)=(-1)^a`. Thus aliases include alternating signs at the multiples `2d`.
50. `...p4.1`, `A3.Ex140`, `...p4.2`: From `EU_i²=1/λ_i`, `M=Σ_i1/λ_i`, `μ_n=Σ_i cos(nθ_i)/λ_i`. Fact C.7 allows interchange of the absolutely convergent series with this **finite** grid sum.
51. `...p5.1`, `A3.EGx15`: For `M`, only `j=2ad`, `a≥1`, survive:

   `M=(d/√κ)[1+2Σ_{a≥1}(-1)^a r^{2ad}]`

   `=(d/√κ)[1-2r^{2d}/(1+r^{2d})]`

   `=(d/√κ)(1-r^{2d})/(1+r^{2d})`.

52. `...p6.1`, `A3.Ex144`: Since `Σ_i cos(nθ_i)=0`, product-to-sum yields

   `μ_n=(1/√κ)Σ_{j≥1}(-r)^j[Σ_i cos((j-n)θ_i)+Σ_i cos((j+n)θ_i)]`.

53. `...p6.2`: The first inner sum survives at `j=n` (value `d`) or `j=2ad+n`, `a≥1` (value `d(-1)^a`). The second survives at `j=2ad-n`, `a≥1` (value `d(-1)^a`). These three positive-index classes are **disjoint because `1≤n<d`**. Also `(-r)^{2ad±n}=(-1)^n r^{2ad±n}`.
54. `A3.EGx16`, `...p6.3`: Therefore

   `(-1)^nμ_n=(d/√κ)[r^n+Σ_{a≥1}(-1)^a(r^{2ad+n}+r^{2ad-n})]`

   `=(d/√κ)[r^n-(r^{2d+n}+r^{2d-n})/(1+r^{2d})]`

   `=(d/√κ)(r^n-r^{2d-n})/(1+r^{2d})`.

55. `...p7.1`: The Lemma 4.5 proof first invokes Fact C.8 for both means.
56. `...p8.1`, `A3.EGx17`, `...p8.2`: Diagonal covariance makes the coordinates independent. Each centered Gaussian coordinate has variance `1/λ_i`, fourth moment `3/λ_i²`, and squared-coordinate variance `2/λ_i²`. Since `λ_i≥(κ+1)/2-(κ-1)/2=1`,

   `Var(||U||²)=2Σ_i1/λ_i²≤2Σ_i1/λ_i=2M`,

   `Var(UᵀD_nU)=2Σ_i cos²(nθ_i)/λ_i²≤2M`.

   The exact `M` formula yields `M≤d/√κ`. No extra Gaussian independence from the external input is asserted in this calculation.
57. `...p9.1`, `A3.Ex150`: Since `n<d` and `0<r<1`, `r^n>r^{2d-n}`, hence `(-1)^nμ_n>0`. Dividing the exact moments gives

   `|μ_n|/M=r^n(1-r^{2(d-n)})/(1-r^{2d})`.

58. `...p9.2`, `A3.Ex151`: From `0<r^{2d}<r^{2(d-n)}<1`,

   `1-r^{2(d-n)}≤(1-r^{2(d-n)})/(1-r^{2d})≤1`.

59. `...p10.1`, `A3.EGx18`, `...p10.2`: The real logarithm is bounded using

   `log(1/r)=log[(√κ+1)/(√κ-1)]`

   `=2∫_0^{1/√κ}dt/(1-t²)`

   `=2/√κ+2∫_0^{1/√κ}t²/(1-t²)dt`.

   Nonnegativity gives `log(1/r)≥2/√κ`.
60. `A3.EGx19`, `...p10.3`, `A3.Ex157`: On that interval `1-t²≥1-κ^{-1}`. Therefore

   `log(1/r)≤2/√κ+[2/(1-κ^{-1})]∫_0^{1/√κ}t²dt`

   `=(2/√κ)[1+1/(3(κ-1))]≤8/(3√κ)<3/√κ`,

   where the last bounds use **`κ≥2`**. Exponentiating gives `e^{-3n/√κ}≤r^n≤e^{-2n/√κ}`.
61. `...p11.1`, `A3.Ex158`: If additionally `d-n≥√κ`,

   `r^{2(d-n)}=exp[-2(d-n)log(1/r)]≤e^{-4(d-n)/√κ}≤e^{-4}`.

62. `...p11.2`, `A3.Ex159`, `...p11.3`: Hence `(1-e^{-4})r^n≤|μ_n|/M≤r^n`. Combining with the power bounds proves exactly `(1-e^{-4})e^{-3n/√κ}≤|μ_n|/M≤e^{-2n/√κ}`.

## Source-only dependency and scope notes

The source's lower-bound route composes the Section 2 model/TV definition, hard-family definition, Lemma 4.6 admissibility, Lemma 4.3 output representation and Lemma 4.4 uniform event, and Lemma 4.5 target moments plus elementary asymptotics/variance/Chebyshev calculations. The cited deferred-rotation input is distinct from the newly displayed moment calculation. Lemma 4.7 and the reference to Fact C.6 belong to the limitations discussion, not extra premises of Theorem 4.1. C.3 obtains the exact means from Fact C.7 plus the grid alias sum, then obtains variances and normalized-bias bounds. This is my manuscript-derived cognition, not a read of any repository source graph and not a claim that any formal implementation discharges those edges.

Only bibliography `[22]` is genuinely cited in these three slices (four citation elements, all in Section 4). Its original entry identifies OpenAI (2026), *Subpolynomial query complexity for well-conditioned log-concave sampling*, an OpenAI Math Release preprint, with the original GitHub PDF URL preserved in `bib.bib3.raw.html`. I read that entry but did not open the PDF, GitHub page or any external content. The entry's title is not evidence for unstated hypotheses or proofs. Internal references to Theorem 3.1, Appendix C.1/C.2/C.4 and Fact C.6 were recorded without reading their destinations. There are no external citations in Section 2 or C.3.

This phase makes no conclusion about an as-yet-unseen exact target or anonymous reconstruction. Any later seven-slot comparison must be an additional phase bound to this frozen record, rather than an edit to it.
