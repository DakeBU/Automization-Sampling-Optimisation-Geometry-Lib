"""Read-only process checks. Never export private foreign baseline values."""
from pathlib import Path
import ast, gzip, hashlib, json, stat, subprocess

ROOT = Path.cwd()
OUT = Path(__file__).parent
W = Path('.astis/huanjian-gc-zero-query-20261110')
E = Path('research-wiki/paper-contributions/GaussianComplexity/zero-query-separation-semantic-evidence')
C = Path('research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-zero-query-separation.json')
L = Path('runs/substantive_advances.jsonl')
ADV = 'ASTIS-SA-20261110-GaussianComplexityZeroQuerySeparation'
OWNER = 'huanjian_gc_20261110_zero_query_separation'
sha = lambda data: hashlib.sha256(data).hexdigest()

assert sha((W/'intake-baseline.private.json').read_bytes()) == 'b72ba04b3d49fed86f42f9ecc33c5d7e6049e92e383da47b369882d535b6137e'
assert sha((W/'preproof-baseline.private.json').read_bytes()) == '16ac260352a553f3609979923ad599876387a625dd4262eb7a999baea38b3205'
b = json.loads((W/'intake-baseline.private.json').read_bytes())
pre = json.loads((W/'preproof-baseline.private.json').read_bytes())
assert Path(b['preproof_snapshot']['path']) == W/'preproof-baseline.private.json'
assert b['preproof_snapshot']['sha256'] == sha((W/'preproof-baseline.private.json').read_bytes())
assert stat.S_IMODE((W/'intake-baseline.private.json').stat().st_mode) == 0o444
assert stat.S_IMODE((W/'preproof-baseline.private.json').stat().st_mode) == 0o444
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip() == pre['head'] == '37eea55086ce04651d5b8f8a7348bc16d1b157cb'

# Pure local replay mirrors only the already inspected read-only replay semantics.
# No import or invocation of astis_advance / normal intake APIs occurs here.
def replay(records):
    states = {}
    for record in records:
        aid = record.get('advance_id')
        if not isinstance(aid,str) or not aid:
            continue
        event = record.get('event')
        if event == 'proposal':
            item = dict(record)
            for key,value in [('frontier_cell','global'),('target_declarations',[]),('checkpoint_count',0),('no_progress_streak',0),('needs_diagnosis',False)]:
                item.setdefault(key,value)
            states[aid] = item
        elif aid in states:
            current = states[aid]
            if event == 'transition':
                to_state = record.get('to_state', current.get('state'))
                current['state'] = to_state
                current['last_actor'] = record.get('worker_id',current.get('last_actor',''))
                if to_state == 'CLAIMED':
                    current['owner_id'] = record.get('worker_id','')
                    current['no_progress_streak'] = 0
                    current['needs_diagnosis'] = False
                current['modes'] = list(record.get('modes') or current.get('modes') or [])
                if record.get('evidence'):
                    current['latest_evidence'] = record['evidence']
                    if to_state == 'PROVED_LOCAL' and record['evidence'].get('publication_declarations'):
                        current['publication_declarations'] = record['evidence']['publication_declarations']
                current['updated_at'] = record.get('created_at',current.get('updated_at'))
            elif event == 'checkpoint':
                previous = current.get('latest_checkpoint') or {}
                same = previous.get('route_fingerprint') == record.get('route_fingerprint') and previous.get('progress_signature') == record.get('progress_signature')
                streak = int(current.get('no_progress_streak',0))+1 if same else 1
                current['checkpoint_count'] = int(current.get('checkpoint_count',0))+1
                current['no_progress_streak'] = streak
                current['needs_diagnosis'] = streak >= 3
                current['latest_checkpoint'] = dict(record)
                current['updated_at'] = record.get('created_at',current.get('updated_at'))
    return states

ledger = L.read_bytes()
assert sha(ledger) == pre['ledger_sha256'] and len(ledger) == pre['ledger_bytes']
assert ledger.endswith(b'\n')
records = [json.loads(line) for line in ledger.splitlines()]
states = replay(records)
assert states == pre['all_foreign_states']
assert ADV not in states
tracked = {p.decode() for p in subprocess.check_output(['git','ls-files','-z']).split(b'\0') if p}
assert tracked == set(pre['all_tracked_regular_file_hashes'])

def mismatch_count(mapping):
    count = 0
    for path,digest in mapping.items():
        try:
            equal = sha(Path(path).read_bytes()) == digest
        except OSError:
            equal = False
        count += not equal
    return count

tracked_mismatches = mismatch_count(pre['all_tracked_regular_file_hashes'])
frontier_mismatches = mismatch_count(pre['all_existing_frontier_hashes'])
control_mismatches = mismatch_count(b['foreign_control_hashes'])
assert tracked_mismatches == frontier_mismatches == control_mismatches == 0
assert sha(C.read_bytes()) == b['own_frontier']['sha256']
cell = json.loads(C.read_bytes())
assert cell['owner_id'] == OWNER and cell['advance_id'] == ADV

def controls():
    names = {str(p) for p in Path('research-wiki/frontier-cells').rglob('*') if p.is_file()}
    names |= {str(p) for p in Path('runs').iterdir() if p.is_file()}
    names.add('website/content/samplewiki_companion_frontiers.json')
    for p in Path('.astis').iterdir():
        if p.is_file() and any(t in p.name.lower() for t in ['queue','control','global','goal','steer','execution']):
            names.add(str(p))
    for name in ['control','queues','runtime','harness','state','locks']:
        folder = Path('.astis')/name
        if folder.is_dir():
            names |= {str(p) for p in folder.rglob('*') if p.is_file()}
    return names
current_controls = controls()
assert set(b['control_paths']) <= current_controls

script = (W/'admit_normal_intake_prepared.py').read_bytes()
assert sha(script) == '399feef8926c66d4a5957bdb907a67a6cd46480ccb94723f40ea9c9eda29d460'
assert stat.S_IMODE((W/'admit_normal_intake_prepared.py').stat().st_mode) == 0o444
tree = ast.parse(script)
normal_calls = []
for node in ast.walk(tree):
    if isinstance(node,ast.Call) and isinstance(node.func,ast.Attribute) and isinstance(node.func.value,ast.Name) and node.func.value.id == 'adv' and node.func.attr in ['propose_advance','transition_advance']:
        normal_calls.append({'line':node.lineno,'function':node.func.attr,'literal_transition':node.args[1].value if node.func.attr=='transition_advance' else None})
assert [x['function'] for x in sorted(normal_calls,key=lambda x:x['line'])] == ['propose_advance','transition_advance','transition_advance']
assert [x['literal_transition'] for x in sorted(normal_calls,key=lambda x:x['line'])] == [None,'CLAIMED','EXPLORING']

seal_bytes = (W/'statement-seal-v1.json').read_bytes()
assert sha(seal_bytes) == 'c4c83b1287b9b7ab5cabc8aa7e4f901e4702bd4c2aec99c63957b74db31d4195'
assert seal_bytes == Path('research-wiki/paper-contributions/GaussianComplexity/zero-query-separation-statement-seal.json').read_bytes()
seal = json.loads(seal_bytes)
assert not Path(seal['producer']['planned_file']).exists()
assert not Path(seal['actual_private_consumer']['planned_file']).exists()
assert not (W/'DraftLiteralStatementFormation.lean').exists()
assert not (W/'normal-intake-attempted.once.json').exists()
assert not (E/'preproof-source-admission.json').exists()
assert (W/'preseal-planning.json').read_bytes() == (E/'preseal-planning.raw.json').read_bytes()
formation = gzip.decompress((E/'Prop-only-statement-formation.raw.lean.txt.gz').read_bytes())
assert formation == (E/'Prop-only-statement-formation.raw.lean.txt').read_bytes()
assert sha(formation) == seal['actual_statement_formation']['probe_raw_sha256']
assert sha(gzip.decompress((E/'actual-statement-formation.log.gz').read_bytes())) == seal['actual_statement_formation']['log_raw_sha256']
assert formation.count(b': Prop :=') == 2
assert all(token not in formation for token in [b' theorem ',b'axiom ',b'sorry',b'admit',b'by\n'])

summary = {
    'schema':'private-safe-readonly-process-binding-check-v1',
    'private_intake_baseline_sha256':sha((W/'intake-baseline.private.json').read_bytes()),
    'private_preproof_baseline_sha256':sha((W/'preproof-baseline.private.json').read_bytes()),
    'private_baseline_contents_exported':False,
    'private_baseline_link_matches':True,
    'ledger_raw_equals_private_preproof_snapshot':True,
    'all_foreign_replayed_states_nested_values_equal':True,
    'foreign_state_count':len(states),
    'historical_VERIFIED_transition_count':sum(x.get('event')=='transition' and x.get('to_state')=='VERIFIED' for x in records),
    'current_VERIFIED_state_count':sum(x.get('state')=='VERIFIED' for x in states.values()),
    'tracked_regular_file_count':len(tracked),
    'tracked_file_hash_mismatch_count':tracked_mismatches,
    'prior_frontier_count':len(pre['all_existing_frontier_hashes']),
    'prior_frontier_hash_mismatch_count':frontier_mismatches,
    'private_control_path_count':len(b['control_paths']),
    'foreign_control_hash_count':len(b['foreign_control_hashes']),
    'foreign_control_hash_mismatch_count':control_mismatches,
    'new_control_paths_count':len(current_controls-set(b['control_paths'])),
    'old_control_paths_subset_current':True,
    'own_frontier_exactly_matches_private_intake_baseline':True,
    'new_advance_absent_from_current_ledger':True,
    'target_proof_files_and_deleted_formation_probe_absent':True,
    'intake_marker_and_portable_admission_absent':True,
    'normal_calls_static_only':sorted(normal_calls,key=lambda x:x['line']),
    'formation_exactly_two_Prop_definitions_no_proofs':True,
    'all_checks_readonly_no_normal_or_target_API_execution':True
}
OUT.mkdir(exist_ok=True)
(OUT/'private-safe-binding-checks.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
