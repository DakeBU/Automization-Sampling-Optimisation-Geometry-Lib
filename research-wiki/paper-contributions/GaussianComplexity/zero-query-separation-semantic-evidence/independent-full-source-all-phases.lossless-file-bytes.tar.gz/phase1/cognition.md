# Phase 1 — independent source-only cognition

Reviewer: `/root/zeroquery_fresh_source_2f8a71`. This record precedes all candidate-type, reconstruction, code, lesson, audit, source-graph-package and native-check exposure. It is a source reconstruction, not a fidelity verdict or a verification transition. The separate exposure disclosure is an essential qualification of this statement.

## Pinned object and selected boundary

The sole mathematical authority consulted is the original local arXiv:2610.20492v1 HTML, title *On Complexity of Gaussian Sampling*, 951991 bytes, SHA-256 `6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915`. Exact UTF-8 byte offsets and fragment hashes are in `source_inventory.json`; the original file and exact fragments are retained beside readable text derivatives whose formulas are taken from decoded original math alttext. Raw TeX annotations, including original entity spellings, are retained in the math inventories. These derivatives are text extraction, not browser visual-QA evidence.

The selected claim is the Section 3.3 zero-query argument: paragraph `S3.SS3.SSS0.Px1.p1.1`, display `S3.Ex3`, and the next paragraph only through “Thus T≥1.” The selected raw interval is `[172530,176488)`. The immediately adjoining `If 2T+1>d` branch is excluded from the claim reviewed here, even though it is retained in `zero_container.raw.html` for an exact boundary. Neither the full logarithmic lower bound nor the later prior comparison is proved by this selected paragraph.

## Source statement in my own words

Fix an integer d≥1, a real κ≥4, and an error 0<ε≤1/16. Let Alg be a randomized oracle algorithm in the Section 2 model. Suppose T is a nonnegative integer deterministic query cap valid for every admissible precision and every seed realization, and the output law, averaged over the internal randomness, is within TV distance ε of the target for every precision A with A=Aᵀ and I_d≼A≼κI_d. Then T≥1. Equivalently, there is no such uniformly accurate algorithm with cap zero.

The proof separately establishes a target-law separation, valid for every d≥1 and κ≥4:

\[
A_0=I_d,\quad A_1=\operatorname{diag}(\kappa,1,\ldots,1),\quad
\pi_A=N(0,A^{-1}),
\]
\[
\operatorname{TV}(\pi_{A_0},\pi_{A_1})
\ge 2\int_{1/2}^{1}\frac{e^{-t^2/2}}{\sqrt{2\pi}}\,dt
\ge\frac{e^{-1/2}}{\sqrt{2\pi}}>\frac18\ge2\varepsilon.
\]

The final inequality uses the error range; the preceding separation is independent of ε. The strict inequality is essential to rule out both non-strict accuracy bounds. No dimension-dependent constant occurs in this zero-query estimate.

## Seven semantic slots frozen before candidate exposure

1. **Objects:** admissible real symmetric precision matrices; centered Gaussian probability laws on Euclidean R^d; an oracle algorithm with a probability-distributed seed; its Borel output and pushforward probability law; the two displayed precisions and the closed coordinate slab E={x:|x₁|≤1/2}; ordinary total variation of probability laws.
2. **Domains:** d is an integer with d≥1; κ is a real parameter with κ≥4 here (Section 2 defines the class already for κ≥1); ε is real with 0<ε≤1/16 here; T is in Z_{≥0}; x∈R^d. The selected coordinate exists because d≥1. Real precision/covariance matrices and Borel probability spaces must retain these meanings in any encoding.
3. **Quantifiers:** for every permitted d,κ,ε, and every algorithm and cap T satisfying the model and uniform-in-A accuracy, T≥1. The randomness is averaged inside each fixed-input output law. Accuracy is not pathwise seed accuracy, average input accuracy, existence of a good input, or high-probability-over-input accuracy. The same algorithm and seed law are used for both A₀ and A₁.
4. **Assumptions:** d≥1, κ≥4, 0<ε≤1/16, the Section 2 algorithm/information model and deterministic cap, and uniform TV≤ε. Probability and Borel semantics are source-wide standing structure. Membership of A₀,A₁, common zero-query law, Gaussian coordinate formulas, event measurability, the displayed separation, and TV triangle inequality are proof ingredients to derive/use, not additional mathematical hypotheses on the source-facing conclusion.
5. **Conclusion:** no zero-cap uniformly ε-accurate algorithm, hence T≥1 for any eligible cap. A lemma asserting only separation of the two Gaussian laws, or impossibility of one common approximating law, is a useful proof component but does not by itself state the whole algorithm-cap conclusion. It must be linked to the actual source model if advertised as the entire selected argument.
6. **Scopes/senses:** exact oracle; arbitrary Borel randomized adaptive algorithms; fixed deterministic worst-run cap; probability-law TV normalized as sup over measurable events, equivalently one-half L¹; unknown precision accessed through oracle responses. This is a bounded component of Theorem 3.1, not all of Theorem 3.1 and not the separate disclosed-spectrum theorem.
7. **Constants/dependencies:** thresholds 4, 1/16, 1/2, 1, and 1/8 are literal. No hidden constants depending on d,κ,ε, algorithm or seed occur. The integral lower bound and strict numerical estimate are dependencies discharged internally. The selected proof calls no numbered lemma or external citation.

## Algorithm model and the common-law bridge

Section 2 says that queries, stopping decisions and output are Borel functions of the internal randomness and previous oracle responses, and that randomness is independent of the input. At cap zero there are no responses. Once the public problem parameters d,κ,ε are fixed, the output is therefore a single Borel function F of the seed ω alone. If the seed probability measure is μ, the output law is ρ=F_*μ, independent of A. Thus ρ_{A₀}=ρ=ρ_{A₁}. Source Borelness makes these pushforward laws well-defined; seed independence and the information restriction justify commonness.

An arbitrary common Borel probability law ρ on R^d supports a stronger probabilistic impossibility statement: no such ρ can be ε-close to both targets. This is the exact law-level core of the source contradiction. Conversely any such law can be realized as a zero-query output on its own probability space via the identity random variable, if one needs a law/model equivalence. That converse is not used in the source paragraph. A definition of zero-query algorithms directly as seed-to-output Borel maps can express the source zero-response case. An unrestricted A-indexed family of laws cannot be called a zero-query algorithm without the independence/common-law bridge: it could assign ρ_A=π_A and encode full input information for free.

The paper does not prescribe a particular seed carrier or a uniform-[0,1] seed representation. Its model does not license adding a convenient specific seed-space restriction without justification. Likewise the lower bound is not a premise that a common law exists or that a separation/accuracy contradiction has already been proved. These are mathematical consequences and proof edges.

## Reconstructed proof and omitted standard bridges

1. A₀ and A₁ are symmetric and have all eigenvalues in [1,κ]. In quadratic-form terms, ||v||²≤κv₁²+Σ_{j>1}v_j²≤κ||v||². Their inverses exist, with inverse diagonal entries 1/κ,1,…,1 for A₁. These facts show both are admissible inputs and fix the intended target laws.
2. The coordinate map x↦x₁ is continuous, so E is Borel. Under π_{A₀}, x₁ has law N(0,1). Under π_{A₁}, it has law N(0,1/κ), where 1/κ is variance, not standard deviation. Equivalently, x₁=Z/√κ in law for Z standard normal. Other coordinates do not enter the event; no full multivariate density or product-TV equality is necessary.
3. Write φ(t)=e^{-t²/2}/√(2π). The event-mass difference equals P(|Z|≤√κ/2)−P(|Z|≤1/2). Since κ≥4, √κ/2≥1. Nonnegativity and symmetry of the normal density imply this is at least P(1/2<|Z|≤1)=2∫_{1/2}^1 φ(t)dt. Endpoint choices do not change the normal probabilities because singletons have measure zero. The TV event supremum dominates this nonnegative difference.
4. For t∈[1/2,1], φ(t)≥φ(1). The interval length is 1/2, so twice the integral is at least φ(1)=e^{-1/2}/√(2π). The estimate φ(1)>1/8 is elementary (for example, 2πe<64 from ordinary π<4 and e<4 implies 1/√(2πe)>1/8). This illustrates a proof route for the omitted numerical bridge, not a citation already present in the source and not a new assumption. ε≤1/16 gives 2ε≤1/8.
5. If T=0, the source model gives one common probability law ρ. Uniform accuracy applies at the two admissible inputs. TV symmetry and triangle inequality yield TV(π_{A₀},π_{A₁})≤TV(π_{A₀},ρ)+TV(ρ,π_{A₁})≤2ε, contradicting the strict displayed lower bound. Since T is a nonnegative integer and cannot be zero, T≥1.

The source leaves the admissibility, coordinate-normal projection/scaling, event/Borel, density-symmetry/integration, elementary constants, and zero-response/common-law steps compressed. They are standard expansion obligations; I see no source defect in this paragraph from these omissions. I have not consulted a background textbook or external reference in this phase, and do not represent any unconsulted citation as evidence. No Lean/API proposition is being assumed here.

## Source-only dependency shape and scope boundaries

The proof is one sufficient route, with conjunction of model/common-law, two admissible targets, uniform accuracy, target separation, and triangle inequality. Haar conditioning, determinant signs, hard priors, indistinguishability/separation/regularity lemmas for those priors, mixing and the later logarithmic arithmetic are not dependencies of this selected zero-query argument. They belong to other proof components. The `2T+1>d` integrality branch is also separate: its conclusion T≥d/2 does not appear in my selected claim.

The original Section 1 and Section 4 boundary paragraphs explicitly distinguish the fixed-spectrum result that remains valid when the precision spectrum is supplied to the algorithm. The selected pair has different spectra for κ≥4: all ones versus one eigenvalue κ. Consequently, with spectrum supplied as input-dependent free side information, the no-response output may depend on that information and need not be the same for these two matrices. This particular two-input common-law proof does not establish a zero-query lower bound in that strengthened information model. In d=1 a disclosed precision eigenvalue determines the entire precision, so zero oracle calls can produce its exact Gaussian using internal randomness. This is a boundary counterexample to extending this argument, not a defect of Section 3's undisclosed-input model. No fixed-spectrum or disclosed-normalizer claim may be silently attached to this selected source claim.

The full source theorem states Q_G≥(1/256)min{d,√κ log(1+d/(√κ ε))}. That is context only. The selected paragraph supplies the positive-query preliminary case. Any downstream infimum formulation of Q_G≥1 must preserve the definition's algorithm/existence and infimum semantics; the selected source proof directly proves the cap statement above.

## Review status frozen now

No candidate has been compared. No source-fidelity verdict, repair decision, native/compiler verdict, VERIFIED/STAB transition, publication/site claim, or Goal-completion claim is issued. Later selective statement/reconstruction comparison must be recorded in a new phase and cannot alter this cognition record.
