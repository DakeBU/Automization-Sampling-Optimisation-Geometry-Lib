from pathlib import Path
import json,hashlib,subprocess,gzip,sys,datetime
sys.dont_write_bytecode=True
R=Path('/Users/zhouhuanjian/ASTIS-GC');sys.path.insert(0,str(R));O=R/'.astis/semantic-neutral-20261110/src_d63b90/normal-sourceV-runtime';E=R/'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-gaussian-moments-semantic-evidence';C='4ba69b8fe4c494d326c4bbd30397c249e7b78204';M='25922bb4c3b5a14ec882ebd4d876ed4a309b8843';ADV='ASTIS-SA-20261110-GaussianComplexityFixedSpectrumGaussianMoments';F=R/'research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-gaussian-moments.json'
def sha(b):return hashlib.sha256(b).hexdigest()
def canon(v):return json.dumps(v,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()
def save(n,v):(O/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def git(*args):p=subprocess.run(['git',*args],cwd=R,capture_output=True);assert p.returncode==0,p.stderr.decode();return p.stdout
assert git('rev-parse','HEAD').decode().strip()==C
proposal=json.loads((O.parent/'phase3/canonical-application-proposal.json').read_text());auditp=R/'research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-gaussian-moments.json';ab=auditp.read_bytes();a=json.loads(ab);old=json.loads(git('show',M+':'+str(auditp.relative_to(R))))
assert a['state']=='source-reviewed'
for k,v in proposal.items():assert a[k]==v,k
for k in ['source','lean','reconstruction','repairs','publication_binding_sha256','publication_context']:assert a[k]==old[k],k
(O/'canonical-audit.before.raw.json').write_bytes(ab)
from tools import astis_semantic_roundtrip_core as rt
packet=rt.semantic_reviewer_packet(a);assert packet['packet_sha256']=='e1adea42232f6dd227d77cf8cf1696fd211b85993d3939f2dbe02032586e2f22';save('current-canonical-reviewer-packet.json',packet)
assert a['publication_binding_sha256']=='a9b67ab0b35b750530b517e14f081f53ccb1d70e1bc39d769d15a8737d2bad17'
initial=json.loads((O.parent/'phase3/initial-input-manifest.json').read_text());files=[]
for x in initial['candidate_files']:
    before=git('show',M+':'+x['path']);carrier=git('show',C+':'+x['path']);actual=(R/x['path']).read_bytes();assert before==carrier==actual;assert sha(actual)==x['sha256'];files.append({'path':x['path'],'sha256':sha(actual),'native_static_commit':M,'metadata_carrier_commit':C,'unchanged':True})
unit=json.loads((R/files[2]['path']).read_text())['units'][0];item=json.loads((R/files[3]['path']).read_text())['items'][0];binding=item['bindings'][0];prod=(R/files[0]['path']).read_text();payload={'file':sha(prod.encode()),'current_lean_module':prod,'toolchain':sha((R/'lean-toolchain').read_bytes()),'dependencies':sha((R/'lake-manifest.json').read_bytes()),'source':item['source'],'statement':item['statement'],'formulae':item['formulae'],'assumptions':item['assumptions'],'obligations':item['obligations'],'lesson':unit,'binding':{k:v for k,v in binding.items() if k not in {'audit_id','legacy_audit_debt'}}};assert sha(canon(payload))==a['publication_binding_sha256']
mp=E/'source-to-lean-map-v3-line-locators.json';mb=mp.read_bytes();m=json.loads(mb);v2=json.loads((E/'source-to-lean-map-v2.json').read_text());assert sha((E/'source-to-lean-map-v2.json').read_bytes())==m['line_locator_successor_of']['sha256'];rows=[];v2by={x['source_node']:x for x in v2['obligations']};changes=[]
for row in m['obligations']:
    src=(R/row['lean_file']).read_text().splitlines();line=src[row['line']-1];assert row['local_provider'] in line,(row['source_node'],line);prev=v2by[row['source_node']];assert row['local_provider']==prev['local_provider'];assert row['lean_file']==prev['lean_file'];assert row['implementation_map']==prev['implementation_map']
    if row['line']!=prev['line']:changes.append((row['source_node'],prev['line'],row['line']))
    rows.append({'source_node':row['source_node'],'file':row['lean_file'],'file_sha256':sha((R/row['lean_file']).read_bytes()),'line':row['line'],'provider':row['local_provider'],'actual_line':line,'provider_condition_checked':'PASS within already-reviewed Ex140/actual-Gaussian-alias consumed scope; no extra graph theorem credit'})
assert len(rows)==13;assert len(changes)==4;assert {x[0] for x in changes}=={x['source_node'] for x in m['line_locator_corrections']}
for x in m['line_locator_corrections']:assert (x['source_node'],x['old_line'],x['new_line']) in changes;assert sha((R/'Tests/GaussianComplexityFixedSpectrumGaussianMoments.lean').read_bytes())==x['source_sha256']
assert json.loads((F).read_text())['source_proof_coverage']['source_to_lean_map']['sha256']==sha(mb)
gates=[];cp=json.loads((E/'source-review-carrier-preflight.json').read_text())
for ref in cp['actual_gate_receipts']:
    p=R/ref['receipt'];b=p.read_bytes();assert sha(b)==ref['receipt_sha256'];v=json.loads(b);gz=p.with_name(p.name.replace('.receipt.json','.log.gz'));raw=gzip.decompress(gz.read_bytes());assert sha(raw)==v['log_sha256']==ref['raw_log_sha256'];assert v['exit_code']==0;assert v['head_before']==v['head_after']==M;gates.append({'receipt':ref['receipt'],'receipt_sha256':sha(b),'command':v['command'],'exit_code':v['exit_code'],'elapsed_seconds':v['elapsed_seconds'],'actual_HEAD':M,'raw_log_sha256':sha(raw),'scope':'Actual checks at25922 HEAD plus accepted metadata overlay, retained on metadata-only carrier; no fresh native carrier build'})
cap=json.loads((E/'local-proof-capsule-v3-reviewed.json').read_text());ownsum=json.loads((O.parent/'phase3/runtime/inspection-summary.json').read_text());assert set(cap['private_consumer']['actual_public_ASTIS_parents'])==set(ownsum['actual_direct_ASTIS_consumer_parents']);assert cap['producer']['actual_public_ASTIS_parents']==[]
from tools import astis_advance as adv
ledger=R/'runs/substantive_advances.jsonl';raw=ledger.read_bytes();assert raw.endswith(b'\n');records=[json.loads(x) for x in raw.splitlines() if x.strip()];assert all(isinstance(x,dict) for x in records);states=adv._replay_advances(records);own=states[ADV];assert own['state']=='PROVED_LOCAL';assert own['owner_id']=='huanjian_gc_20261110_fixed_spectrum_gaussian_moments';assert own['target_declarations']==[packet['lean']['declaration']];assert own['publication_declarations']==[packet['lean']['declaration']];assert not any(x.get('advance_id')==ADV and x.get('to_state')=='VERIFIED' for x in records)
(O/'ledger.before.raw.jsonl').write_bytes(raw);save('own-SAU.before.json',own);save('foreign-SAU-state-hashes.before.json',{k:sha(canon(v)) for k,v in states.items() if k!=ADV});(O/'frontier.before.raw.json').write_bytes(F.read_bytes())
preserved={}
for p in sorted((R/'research-wiki/frontier-cells').glob('*.json')):
    if p!=F:preserved[str(p.relative_to(R))]=sha(p.read_bytes())
for name in ['runs/substantive_discoveries.jsonl','website/content/samplewiki_companion_frontiers.json','website/content/graph_memory_index.json','website/content/functor_hypergraph.json','Libraries/frontloaded-shared-spine.json']:
    p=R/name
    if p.exists():preserved[name]=sha(p.read_bytes())
save('foreign-frontier-discovery-shared-model-hashes.before.json',preserved)
result={'status':'PASS','checked_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'verified_carrier_commit':C,'native_Lean_static_checked_commit':M,'four_exact_candidate_files':files,'exact_four_proposal_fields_match_canonical_audit':True,'canonical_audit_source_lean_reconstruction_repairs_binding_context_unchanged':True,'current_canonical_packet_sha256':packet['packet_sha256'],'publication_binding_sha256':a['publication_binding_sha256'],'source_to_lean_map_path':str(mp.relative_to(R)),'source_to_lean_map_sha256':sha(mb),'mapping_rows':rows,'line_changes':changes,'graph_association_scope':'Source graph/map association only. Broader upper-spectrum/offdiagonal/product/variance prose is not upgraded, counted as new theorem, or made a required compiled parent. All actually consumed producer/private target conditions are checked by the frozen whole-module/native evidence.','gate_receipts':gates,'original_ledger_sha256':sha(raw),'original_ledger_bytes':len(raw),'original_ledger_records':len(records),'foreign_SAU_count':len(states)-1,'all_SAU_count':len(states),'foreign_frontier_discovery_shared_files':len(preserved),'target_before_state':own['state'],'no_tail_repair_needed_or_permitted':True,'single_API_call_authorized_next':True,'allowed_frontier_projection_paths':['/status','/evidence/independent_verification','/evidence/independent_source_review/normal_sourceV_transition','/evidence/normal_sourceV','/source_proof_coverage/current_compiled_scope/source_VERIFIED']}
save('preflight-result.json',result);print(json.dumps({k:v for k,v in result.items() if k not in ['mapping_rows','gate_receipts']},ensure_ascii=False,indent=2))
