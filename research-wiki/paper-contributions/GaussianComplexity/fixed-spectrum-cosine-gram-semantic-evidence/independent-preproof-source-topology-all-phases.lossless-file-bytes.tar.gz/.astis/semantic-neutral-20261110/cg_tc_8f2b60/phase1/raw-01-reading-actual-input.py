from pathlib import Path
from bs4 import BeautifulSoup
from html.parser import HTMLParser
import hashlib,json
base=Path('.astis/semantic-neutral-20261110/cg_tc_8f2b60/phase1')
raw=Path('.astis/huanjian-resume-20261103/2610.20492v1.html').read_text()
soup=BeautifulSoup(raw,'html.parser')
class Spans(HTMLParser):
 def __init__(self):
  super().__init__(convert_charrefs=False); self.stack=[]; self.spans={}; self.starts=[0]
  self.starts.extend(i+1 for i,c in enumerate(raw) if c=='\n')
 def pos(self):
  l,c=self.getpos(); return self.starts[l-1]+c
 def handle_starttag(self,tag,attrs):
  ident=dict(attrs).get('id'); start=self.pos(); end=start+len(self.get_starttag_text())
  if tag in {'area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr'}:
   if ident:self.spans[ident]=(start,end)
  else:self.stack.append((tag,ident,start))
 def handle_startendtag(self,tag,attrs):
  ident=dict(attrs).get('id'); start=self.pos()
  if ident:self.spans[ident]=(start,start+len(self.get_starttag_text()))
 def handle_endtag(self,tag):
  for i in range(len(self.stack)-1,-1,-1):
   if self.stack[i][0]==tag:
    matches=self.stack[i:]; self.stack=self.stack[:i]
    end=raw.index('>',self.pos())+1
    for _,ident,start in matches:
     if ident:self.spans[ident]=(start,end)
    break
p=Spans();p.feed(raw)
keys=['S4.Thmtheorem4','A3.SS2.p1','A3.SS2.p2','A3.Thmtheorem5','A3.SS2.2']
meta=[]; output=[]
for key in keys:
 a,z=p.spans[key]; fragment=raw[a:z]; b=fragment.encode(); tag=BeautifulSoup(fragment,'html.parser')
 for math in tag.find_all('math'):
  math.replace_with(' $'+math.get('alttext',math.get_text(' ',strip=True))+'$ ')
 txt=tag.get_text(' ',strip=True)
 (base/(key+'.html')).write_bytes(b);(base/(key+'.txt')).write_text(txt+'\n')
 item={'id':key,'byte_start':len(raw[:a].encode()),'byte_end_exclusive':len(raw[:z].encode()),'line_start':raw.count('\n',0,a)+1,'line_end':raw.count('\n',0,z)+1,'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
 meta.append(item);output.append(json.dumps(item)+'\n'+txt)
(base/'source-spans-01.json').write_text(json.dumps(meta,indent=2)+'\n')
ctx=soup.find(id='S4.SS2'); inv=[]
for c in ctx.find_all(recursive=False):
 x=BeautifulSoup(str(c),'html.parser')
 for math in x.find_all('math'):math.replace_with(' $'+math.get('alttext','')+'$ ')
 inv.append((c.name,c.get('id'),x.get_text(' ',strip=True)[:700]))
output.append('S4.SS2 DIRECT CHILD INVENTORY\n'+json.dumps(inv,ensure_ascii=False,indent=2))
out='\n\n'.join(output)+'\n';(base/'raw-01-reading-output.txt').write_text(out);print(out)
