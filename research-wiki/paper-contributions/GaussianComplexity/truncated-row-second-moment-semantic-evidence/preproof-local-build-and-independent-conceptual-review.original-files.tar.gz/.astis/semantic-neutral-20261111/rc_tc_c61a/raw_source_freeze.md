# Independent raw-source freeze: rc_tc_c61a

This freeze precedes receipt of the root's exact type/definition packet or Source Proof Graph. It does not approve an implementation, grant a process transition, or record theorem completion. No Lean implementation, previous graph/verdict, or proof/API search has been consulted. The root remains the mathematical prover.

## Source pin and bounded claim

The only mathematical source is the local raw HTML `2610.20492v1.html`, 951991 bytes, SHA-256 `6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915`. Exact raw element copies accompany this freeze.

The bounded source target is Appendix C.2, paragraph 12's radial truncated covariance identity, its specified scalar, the common-scalar statement, and the immediately stated formula for the expectation of one truncated matrix:

\[
\mathbb E[\gamma_i\gamma_i^\top\mathbf1_{R_i\le L}]=aI_r,
\quad a=\frac1r\mathbb E[R_i\mathbf1_{R_i\le L}],
\quad \mathbb E Y_i=\frac ad(I_r\otimes t_it_i^\top).
\]

Source context in C.2 paragraph 1 sets `r=q+1`, `n=2q+1`, `1≤i≤d`, `t_i=(1,√2 cos θ_i,…,√2 cos(qθ_i))ᵀ`, and `γ_i=((g₁)_i,…,(g_r)_i)ᵀ`. It states that the rows `γ₁,…,γ_d` are independent `N(0,I_r)` vectors. Paragraph 10 sets `L=2r+3 log(1000d)` and `R_i=‖γ_i‖²`. Paragraph 12 literally defines

\[
Y_i=d^{-1}(\gamma_i\gamma_i^\top\otimes t_it_i^\top)\mathbf1_{R_i\le L}.
\]

The standing Lemma 4.4 assumptions at `S4.Thmtheorem4` are `q≥0`, `2q+1<d`, and independent `g₁,…,g_{q+1}∼N(0,I_d)`. Here `q` and `d` count iterations/dimensions. Thus the source carrier is nonnegative integral `q`, positive integral `d`, with `r=q+1≥1`; in fact `d≥2`. The smallness premise on `τ_{d,q}` belongs to the final Krylov conclusion and is not needed for this bounded expectation identity.

## Semantic slots and actual prerequisites

1. **Objects/domains.** Expectations are real finite-dimensional vector/matrix expectations under the underlying probability law of the Gaussian inputs. `γ_i∈ℝ^r`; `R_i` is the Euclidean squared norm, not a norm or a single coordinate square. The indicator uses the inclusive closed-ball condition `R_i≤L`. `t_i∈ℝ^r` is deterministic. Both tensor factors are real rank-one matrices, and `Y_i` is indexed by pairs of coordinates, equivalently an `r²×r²` matrix.
2. **Quantifiers.** The formulas hold for every valid row `i`. One scalar `a` works for all these rows, at the same `r` and `L`. There is no probabilistic exceptional event in either expectation equality.
3. **Assumptions.** The standard Gaussian row marginal law supplies spherical symmetry, measurability, and finite moments. The common marginal law and common cutoff supply the common scalar. Family independence is source context and later concentration input; it is not needed by the single-row expectation calculation or by commonality of `a`.
4. **Conclusion.** The covariance is the whole matrix identity, including zero off-diagonal entries. The scalar is fixed by the displayed truncated second moment divided by `r`, not merely some witness satisfying a covariance equation. The `Y_i` formula follows with the same scalar and tensor order.
5. **Scope/sense.** The cutoff truncates the outer-product integrand by an unnormalized indicator. This is neither covariance under the conditional law given the ball nor a normalized conditional expectation. Integration is entrywise, equivalently the ordinary finite-dimensional Bochner integral after integrability is established.
6. **Constants.** `a` depends on dimension `r`, cutoff `L` and the common standard Gaussian law; with the source definitions it depends on `(q,d)`. It does not depend on the row index, the realized sample, or `t_i`. The factor is exactly `a/d`, not `a/r`, `a/(dr)`, or a probability-normalized factor.
7. **Definitions.** `R_i`, the indicator-weighted outer product, `a`, and `Y_i` are literal formula definitions. A characterization premise, existence fallback, or branch returning an arbitrary default would change the source semantics. A separate standard-Gaussian-law integral can define the same scalar if the identification with every row's expectation is discharged internally.

## Omitted mathematical bridges requiring explicit coverage

These are obligations in the source reconstruction, not extra public premises licensed by this review.

- **Row-law bridge.** The array of independent standard `d`-dimensional Gaussian inputs gives each `γ_i` the `r`-dimensional standard Gaussian law and gives the same marginal law at every `i`. The stronger joint row-family statement is useful later but must not be confused with this marginal identification.
- **Symmetry bridge.** Standard Gaussian measure is invariant under orthogonal coordinate transformations. The radial event and squared norm remain unchanged. Coordinate sign reflection gives each off-diagonal entry zero; coordinate permutations give equal diagonal entries. This finite symmetry route suffices. A complete orthogonal-invariance/commutant route is an alternative sufficient route, not an additional conjunct that must be piled onto the finite symmetry route.
- **Measurability and integrability.** Polynomial coordinate products and squared norm are measurable; the ball is measurable. The truncated scalar/matrix integrands are integrable. The source's finite positive `L` bounds the truncated squared norm and its coordinate products; Gaussian finite second moments give another sufficient domination route. These are derived dependencies, not independent source assumptions.
- **Entrywise integral bridge.** A matrix expectation must agree with the integrals of entries, and equal entry integrals determine the matrix. Product indexing and evaluation maps must be preserved. A theorem proving only diagonal entries does not establish the matrix equality.
- **Trace and scalar identification.** The trace of `γγᵀ` is `Σ_j γ_j²=R`. Finite-sum/integral interchange identifies the trace of the truncated covariance with `E[R 1_{R≤L}]`. The trace of `aI_r` is `ra`. Positive `r=q+1` permits division by `r`. The covariance shape and the specified formula for `a` are both needed.
- **Common scalar.** Integrating the same measurable radial function against the same marginal law yields the same value for every row. No appeal to independence between different rows is necessary here.
- **Deterministic tensor expectation.** For coordinate indices `(α,k),(β,ℓ)`, the integrand entry is `d⁻¹ γ_α γ_β (t_i)_k(t_i)_ℓ 1_{R≤L}`. Deterministic scalar extraction and the covariance identity give `d⁻¹ a δ_{αβ}(t_i)_k(t_i)_ℓ`. Finite-dimensional integrability, scalar extraction, tensor order, and `d>0` must be justified internally. There is no random `t_i` and no assumption that `t_i` is independent of `γ_i`.

## Coverage inventory and boundaries

- `S4.Thmtheorem4`: NODE for the dimension/Gaussian standing context; EXCLUDED for the final probability, `τ` smallness, and Krylov quadratic bound because these are downstream of this bounded identity.
- `A3.SS2.p1`: NODE for `r`, `γ_i`, deterministic `t_i`, and the row-law/common-marginal statements. The definition of `n` and the row representation of `B` are EXCLUDED as unused by the bounded identity; they remain context for later weighted sums and Gram matrices.
- `A3.SS2.p10`: NODE for literal `L` and `R_i`. The exponential moment calculation, Markov bound, and simultaneous event probability `0.999` are EXCLUDED because no tail estimate is required for the two expectation equalities.
- `A3.SS2.p11`: EXCLUDED. Its tail-integral estimate controls the subsequent numerical bias bound; it is not needed to compute the truncated covariance shape or one `E[Y_i]`.
- `A3.SS2.p12`, first display: NODE for `Y_i`; family independence of these matrices is EXCLUDED from the bounded equality claim and remains a distinct concentration obligation.
- `A3.SS2.p12`, radial symmetry display: NODE for covariance, specified scalar, and the omitted symmetry/integrability/entrywise/trace bridges above.
- `A3.SS2.p12`, “same for every i”: NODE; this requires common marginals/common cutoff, not the full independent row-family conclusion.
- `A3.SS2.p12`, `E R_i=r`, `0≤a≤1`, and `1−a≤(L+3)/(1000rd)`: EXCLUDED numerical-bias region. `E R_i=r` may separately be chosen as one sufficient integrability route, but the bias estimates are not conjunctive prerequisites of this bounded target.
- `A3.SS2.p12`, “Moreover” formula: NODE for the single-matrix expectation and its deterministic tensor bridge.
- `A3.SS2.p12`, invocation of Fact C.5, the two sums, and “truncated weighted sum has zero expectation”: EXCLUDED downstream aggregate identities. The cosine orthogonality identities and weighted zero-sum do not feed back into the single-row covariance or `E[Y_i]`.
- `A3.Thmtheorem5`: EXCLUDED as a needed dependency for this bounded target; its deterministic cosine identities are consumed only by the excluded aggregate region. The basic literal `t_i` is already supplied by paragraph 1.
- `A3.Thmtheorem6` and `A3.SS2.p13`: EXCLUDED concentration conclusion and centered-summand norm bounds. They consume the present identities but are not their prerequisites.
- External citations: none is invoked in the bounded paragraph for this symmetry-to-expectation step. “By radial symmetry” is an omitted mathematical bridge, not a citation or a premise.

## Endpoint and failure boundaries

At `q=0`, `r=1`, `n=1`, `d>1`, `t_i=(1)`, `γ_i=((g₁)_i)`, `R_i=γ_i²`, and `L=2+3 log(1000d)`. The covariance statement reduces to the one-entry identity `E[γ_i² 1_{γ_i²≤L}]=a`; here `a` is exactly that expectation because `r=1`. The matrix `Y_i` has one entry `d⁻¹γ_i²1_{γ_i²≤L}`, and its expectation is `a/d`. There are no distinct coordinates in dimension one, so an off-diagonal argument must be vacuous and an argument requiring two distinct indices cannot be a global prerequisite.

The source never needs `r=0`; division by `r` loses scalar identification there. A generalized finite-cutoff identity may hold beyond the standing `2q+1<d` or for negative cutoffs (where the truncated integrand is zero), but that generality is not permission to rewrite the source carrier or source constants.

Mean zero and untruncated identity covariance alone do not imply radial truncated covariance. A nonspherical law may have isotropic second moments while a ball selects unequal coordinate variances or nonzero cross moments. A nonradial cutoff can break the symmetry even for a standard Gaussian. A coordinate-sign symmetry alone kills cross moments but does not equate diagonal entries; coordinate-permutation symmetry alone does not generally kill cross moments. A radial law with different scales in different rows need not admit the same `a`. A random `t_i` cannot be moved outside expectation by the deterministic bridge without a new argument. Reversing tensor factors changes the literal indexed matrix unless a reviewed index permutation is supplied. Replacing `≤L` by `<L` requires a separate boundary-mass argument. Conditional normalization changes the displayed scalar.

This raw-source freeze authorizes only a later type/definition comparison and subsequent independent source-topology challenge. It grants no admission, intake, `VERIFIED`, publication, or proof status.
