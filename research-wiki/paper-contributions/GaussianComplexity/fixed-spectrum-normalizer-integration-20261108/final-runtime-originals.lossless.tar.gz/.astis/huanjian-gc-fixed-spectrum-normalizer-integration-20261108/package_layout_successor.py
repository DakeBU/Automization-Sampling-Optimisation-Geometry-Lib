from pathlib import Path
import datetime, gzip, hashlib, json, shutil, subprocess
sha = lambda raw: hashlib.sha256(raw).hexdigest()
B = Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-normalizer-integration-20261108')
D = B / 'process-diagnostics'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD']).decode().strip() == 'c8c157a69aaad4007cb801a781e980a27005bb02'
label = 'fixed-spectrum-normalizer-exact-reviewed-layout-application'
p = list(Path('.astis/huanjian-resume-20261103').glob('*-' + label + '.receipt.json'))
assert len(p) == 1
receipt = json.loads(p[0].read_bytes())
assert receipt['exit_code'] == 0
lograw = Path(receipt['log']).read_bytes()
assert sha(lograw) == receipt['log_sha256']
shutil.copy2(p[0], D / p[0].name)
lp = D / (Path(receipt['log']).name + '.gz')
assert not lp.exists()
lp.write_bytes(gzip.compress(lograw, mtime=0))
assert gzip.decompress(lp.read_bytes()) == lograw
helper = Path('.astis/huanjian-gc-fixed-spectrum-normalizer-integration-20261108/apply_layout_successor.py')
hz = D / 'apply_layout_successor.py.raw.gz'
hz.write_bytes(gzip.compress(helper.read_bytes(), mtime=0))
assert gzip.decompress(hz.read_bytes()) == helper.read_bytes()
checkpoint = B / 'resume-checkpoint.json'
old = checkpoint.read_bytes()
archive = D / 'resume-checkpoint-before-layout-successor.raw.json.gz'
assert not archive.exists()
archive.write_bytes(gzip.compress(old, mtime=0))
a = json.loads(old)
a.update({'recorded_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'state': 'REVIEWED_ONE_LINE_LAYOUT_APPLIED_SUCCESSOR_CORE_PENDING_FRESH_GATES', 'accepted': False, 'base_core_for_layout_repair': a['active_core'], 'exact_layout_application_sha256': sha((B / 'exact-layout-successor-application.json').read_bytes()), 'next': 'Freeze new immutable successor core. Run genuinely new exact-HEAD Lean/publication/contributor/semantic/frontier/sitebuild/sitecheck/graph/Chrome. Preserve unchanged actual Lean-only sourceDigest and separately pin CSS. Require independent fresh original46 plus two bounded old-long-Lean regression originals, ordinary text-range bounds and accepted reader; only then separate normal existing-V park and next math packet. No c8 success transfer, no new sourceV/STAB, no wholeGoal completion.'})
checkpoint.write_text(json.dumps(a, ensure_ascii=False, indent=2) + '\n')
names = ['actual-browser-original47.lossless.tar.gz', 'actual-browser-original47.manifest.json', 'actual-gates-browser-context.json', 'actual-gates-browser-navigation-v4-context.json', 'actual-gates-browser-visibility-v5-context.json', 'actual-originals-independent-review-context.json', 'postcore-protection-context.json', 'primary-original-v5-inspection.json', 'root-exact-layout-successor-authorization.json', 'exact-layout-successor-application.json', 'resume-checkpoint.json']
paths = [Path('website/static/information-architecture.css')] + [B / x for x in names]
for relative in ['process-diagnostics', 'independent-reader/browser-navigation-repair-v4', 'independent-reader/browser-visibility-repair-v5', 'independent-reader/original46-independent-review-v5', 'independent-reader/mobile-debt-layout-proposal-v6']:
    paths += sorted(x for x in (B / relative).rglob('*') if x.is_file())
subprocess.run(['git', 'add', '--', *map(str, paths)], check=True)
subprocess.run(['git', 'diff', '--cached', '--check'], check=True)
for path in paths:
    assert subprocess.check_output(['git', 'show', ':' + str(path)]) == path.read_bytes(), path
assert subprocess.check_output(['git', 'diff', '--name-only']).strip() == b''
assert sha(Path('website/static/information-architecture.css').read_bytes()) == 'a41ffd9d41e8c281aa716fcff25e42e5cb8d14208badff456a0dff7dfbb1b766'
print(json.dumps({'staged_paths': len(set(map(str, paths))), 'index_matches_exact_live_bytes': True, 'only_shared_change': 'one independently reviewed CSS line', 'README_ledger_frontiers_untouched': True, 'new_core_gates_pending': True}))
