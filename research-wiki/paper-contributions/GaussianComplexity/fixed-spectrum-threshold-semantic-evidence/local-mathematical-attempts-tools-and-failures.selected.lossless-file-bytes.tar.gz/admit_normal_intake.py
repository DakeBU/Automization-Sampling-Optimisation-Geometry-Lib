"""Prepared control-plane script; execute only after independent prospective admission."""
from pathlib import Path
import json, hashlib, sys, datetime, subprocess
sys.dont_write_bytecode=True
sys.path.insert(0,'tools')
import astis_advance as adv
W=Path(__file__).parent
E=Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-threshold-semantic-evidence')
C=Path('research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-threshold.json')
L=Path('runs/substantive_advances.jsonl')
ADV='ASTIS-SA-20261110-GaussianComplexityFixedSpectrumThreshold'
OWNER='huanjian_gc_20261110_fixed_spectrum_threshold'
sha=lambda b:hashlib.sha256(b).hexdigest()
dump=lambda o:(json.dumps(o,ensure_ascii=False,indent=2)+'\n').encode()
def ref(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def put(p,b):
 assert not p.exists(),p
 p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
gpath=Path(sys.argv[1]);assert sha(gpath.read_bytes())==sys.argv[2]
g=json.loads(gpath.read_bytes())
assert g['prospective_target_Lean_proof_API_allowed_after_this_grant'] is True
assert g['root_sole_mathematical_worker'] is True
for row in g['independent_inputs']:
 p=Path(row['path']);assert sha(p.read_bytes())==row['sha256'],p
sp=W/'statement-seal-v1.json';assert sha(sp.read_bytes())=='90646c0406b88f94af56d5b6f874e0e6a0eeb6f07b5efe73f14ff8474ade1b05'
s=json.loads(sp.read_bytes());prod=s['producer']['planned_file'];test=s['actual_private_consumer']['planned_file'];name=s['producer']['name']
assert not Path(prod).exists() and not Path(test).exists() and not C.exists() and not E.exists()
assert not (W/'StatementFormation.lean').exists()
baseline=json.loads((W/'preproof-baseline.json').read_bytes())
before=L.read_bytes();assert sha(before)==baseline['ledger']['sha256']
states=adv._replay_advances([json.loads(x) for x in before.splitlines()])
assert states==baseline['all_current_SAU_states'] and ADV not in states
assert states['ASTIS-SA-20261110-GaussianComplexityFixedSpectrumSignalStrength']['state']=='VERIFIED'
for p,h in baseline['all_frontier_hashes'].items(): assert sha(Path(p).read_bytes())==h,p
tracked=subprocess.check_output(['git','ls-files','-z']).decode().split('\0')
protected={p:sha(Path(p).read_bytes()) for p in tracked if p and p!=str(L) and Path(p).is_file()}
put(W/'intake-tracked-private-preservation.json',dump({'all_tracked_hashes_except_own_ledger':protected,'all_foreign_states':states,'all_frontier_hashes':baseline['all_frontier_hashes'],'ledger_before':ref(L),'raw_private_not_for_public_copy':True}))
put(E/'preproof-source-admission.json',gpath.read_bytes())
publicseal=Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-threshold-statement-seal.json');put(publicseal,sp.read_bytes())
for src,dst in [('producer-signature.txt','producer.signature.lean.txt'),('consumer-signature.txt','consumer.signature.lean.txt'),('preseal-exposure-disclosure.json','preseal-exposure-disclosure.json'),('postseal-process-actions-and-C-family-qualification.json','postseal-process-actions-and-C-family-qualification.json'),('postseal-additional-informal-planning-exposure.json','postseal-additional-informal-planning-exposure.json')]:
 put(E/dst,(W/src).read_bytes())
old=json.loads(Path('research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-signal-strength.json').read_bytes())
boundary='; '.join(s['scope_boundary'])
searched=['Exact new module/target/event name search in GaussianComplexity,Tests/frontier cells: no exact match before seal; no semantic-absence claim.','Prior canonical actual-Gaussian Bias/ModeGap/Variances/SignalStrength spine known; new mathematical proof/API retrieval begins only after prospective independent admission.']
cell={
 'schema_version':3,'cell_id':C.stem,'route':'samplewiki-route','mode':'faithfulPaper',
 'title':'Concrete numeric threshold smallness against actual Gaussian bias',
 'source_anchor':'arXiv2610.20492v1 S4 Lemma4.4 literal tau and S4.3 unnamed tau/beta estimates: numeric auxiliary C-family only; private shifted diagonal-Gaussian bad-event application',
 'target_statement':s['producer']['signature'],'status':'claimed','owner_id':OWNER,'advance_id':ADV,'parents':[],
 'consumers':['Sealed PRIVATE actual Gaussian shifted-event bad probability<=1/10 under the original scalar query/condition regime; unproved at intake.','A future actual source concentration C must be produced independently before specializing this family; main/rotation/oracle work remains open.'],
 'shared_floor_audit':{'searched':searched,'classification':'adapt','decision':'adapt_existing','canonical_declaration':name,'canonical_shared_cell':'','notes':'Reuse canonical actual Gaussian nodes. This is an auxiliary numeric family, not literal Lemma4.4 or Theorem4.1. No proof certificates are public premises.'},
 'reuse_plan':{'searched_existing':searched,'reused_declarations':[],'new_shared_declarations':[],'known_consumers':[],'planned_consumers':['actual_gaussian_source_query_shifted_event_le_tenth: genuine probability event with concrete tau and actual shared-sample contrast, not a wrapper.'],'no_duplicate_wrapper':True,'decision_reason':'Produce actual tau<=beta/4 and tau<=1/2 internally for every fixed positive numeric C, then consume in a real shifted-event probability estimate. Absolute concentration validity is a separate dependency; no source main premise is added.'},
 'reader_contract':old['reader_contract'],
 'graph_contribution':{'lean_view':'new-node','overview_view':'no-change-with-reason','functor_view':'none-found','edge_semantics':'formal-solid; overlays-dashed','color_semantics':'evidence-status; library-scope','focus_targets':[name],'visual_review':'Preproof exact source/statement/topology only; no compiled graph or website/UI acceptance.'},
 'source_detail_audit':{'primary_edition':'arXiv2610.20492v1','primary_anchor':'S4.Thmtheorem4 tau formula; S4.SS3 tau envelope/ratio and shifted target contrast','detail_status':'omitted','gap':'All eventual uniform scalar estimates, actual Gaussian semantics/integrability/sign, private shifted variance/signal/Chebyshev are internal obligations; source absolute concentration C is outside this numerical packet.','consulted':[{'source':'Independently frozen raw source, exact statements, source graph and distinct topology challenge','anchor':'S4.3 tau<=beta/4 and target contrast probability; AppendixC.2/C.3 provenance','hypothesis_adapter':'Generic fixed positive numerical C is quantified before delta and D(C,delta); later specialization at a separately proved absolute source C restores source delta-only cutoff. Natural q and exact deterministic query cap, real kappa range, actual inverse-precision Gaussian and actual means are literal. No concentration witness/mean/variance/smallness certificate is assumed.'}],'fidelity_boundary':boundary},
 'learning_contract':{'control_plane_math_authority':False,'process_memory_checked':True,'process_memory_ids':old['learning_contract']['process_memory_ids'],'failure_class':'NONE','salvage':{'required':True,'status':'completed','reason':'No target Lean proof experiment before intake. Original graph v1 TC2B-1 missing local frequency discharge and TC2B-2 Markov/union input HOLDs retained; admission requires separately repaired and independently accepted successor. These are source-graph adequacy findings, not refutations of sealed statements. Pre/postseal informal planning remains disclosed.','promoted_fragments':[],'discarded_fragments':[]},'parallelism':{'decision':'serial','direction_fingerprints':[],'expected_information_gain':'Root sole mathematical worker; independent source graph/topology/blind decoder/fresh source/native roles have distinct uncertainty. Foreign global lease remains untouched.','shared_verified_context_digest':s['producer']['signature_sha256']},'cross_route_blind_spot_audit':{'required':False,'status':'not-applicable','evidence':'','canonical_route':'','selection_reason':'No competing proof workers/routes.'},'reader_backpressure':{'purification_status':'pending','exposition_seal_status':'pending','exposition_evidence':'','source_expansion_nodes':[],'lean_expansion_nodes':[],'assumptions_preserved':True,'boundary_preserved':True}},
 'statement_seal':{'path':str(publicseal),'sha256':sha(sp.read_bytes()),'signature_sha256':s['producer']['signature_sha256'],'status':'Exact numeric auxiliary statements and independent source/topology prospectively admitted; no target proof yet'},
 'source_proof_coverage':{'preproof_admission':ref(E/'preproof-source-admission.json'),'source_gaps_are_not_public_assumptions':True,'private_consumer_non_Anchor':True,'numeric_family_is_not_concentration_or_main_anchor':True,'internal_obligations_still_unproved':s['internal_dependencies_not_extra_binders']},
 'evidence':{'execution_boundary':boundary,'focused_checks':[],'preproof_source_admission':str(E/'preproof-source-admission.json'),'actual_consumer_seal':s['actual_private_consumer'],'independent_verification':'','root_build':'','graph_regeneration':'','pr':'','process_order_exposure':str(E/'postseal-additional-informal-planning-exposure.json')},
 'blocked':{'reason':'','children':[]}
}
p=adv.AdvanceProposal(advance_id=ADV,task_id='ASTIS-SW-GAUSSIAN-COMPLEXITY-2026',goal='Prove literal numeric threshold smallness against actual Gaussian beta, with a genuine private shifted-event probability consumer.',source_anchor=cell['source_anchor'],theorem_delta=s['producer']['signature'],truth_boundary=boundary,created_by=OWNER,dag_inputs=('source:arXiv2610.20492v1:S4.3 tau formula/smallness/shifted target step','canonical:actual Gaussian Bias/ModeGap and downstream Variances/SignalStrength; no assumed proof certificates'),proposed_files=(prod,test,str(C),'website/content/declaration_lessons/huanjian-fixed-spectrum-threshold.json','website/content/publications/huanjian-fixed-spectrum-threshold.json'),focused_checks=('lake env lean '+prod,'lake build Tests.GaussianComplexityFixedSpectrumThreshold'),modes=('source-reading','proof-design','compiler-diagnosis'),priority=50,frontier_cell=C.stem,target_declarations=(name,))
p.validate();adv.propose_advance(p)
adv.transition_advance(ADV,'CLAIMED',worker_id=OWNER,evidence={'exact_statement_seal':ref(sp),'preproof_admission':ref(E/'preproof-source-admission.json'),'numeric_family_not_main_or_concentration_anchor':True,'truth_boundary':boundary})
adv.transition_advance(ADV,'EXPLORING',worker_id=OWNER,evidence={'preproof_admission':ref(E/'preproof-source-admission.json'),'target_Lean_proof_API_starts_after_this_event':True,'preseal_and_postseal_informal_planning_retained':True,'no_pristine_zero_planning_claim':True,'no_own_STAB_authority':True,'truth_boundary':boundary})
C.write_bytes(dump(cell))
after=L.read_bytes();assert after.startswith(before);app=after[len(before):];assert len(app.splitlines())==3
new=adv._replay_advances([json.loads(x) for x in after.splitlines()]);assert new[ADV]['state']=='EXPLORING' and {k:v for k,v in new.items() if k!=ADV}==states
for p,h in protected.items():assert sha(Path(p).read_bytes())==h,p
put(E/'normal-EXPLORING-append.exact.jsonl',app)
put(E/'normal-intake-preservation.json',dump({'normal_API_calls':3,'state':'EXPLORING','advance_id':ADV,'owner':OWNER,'append_sha256':sha(app),'foreign_SAU_states_preserved':len(states),'foreign_frontiers_preserved':len(baseline['all_frontier_hashes']),'protected_tracked_files_preserved':len(protected),'raw_foreign_snapshots_private':True,'no_own_STAB_global_or_sourceV_or_proof_credit':True}))
print(json.dumps({'state':'EXPLORING','append_sha256':sha(app),'foreign_states_preserved':len(states),'foreign_frontiers_preserved':len(baseline['all_frontier_hashes']),'protected_tracked_files_preserved':len(protected),'sourceV_or_proof_credit':False}))
