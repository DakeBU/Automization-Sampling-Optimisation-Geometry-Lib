from pathlib import Path
import json,hashlib,subprocess
out=Path(__file__).resolve().parent
repo=Path('/Users/zhouhuanjian/ASTIS-GC')
inputs=out/'phase3-inputs'
def digest(b): return hashlib.sha256(b).hexdigest()
def sha_json(x): return digest(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())
mp=json.loads((inputs/'research-wiki/paper-contributions/GaussianComplexity/source-matrix-structure-semantic-evidence/source-lean-map.authored-v1.json').read_text())
source=(out/'originals/.astis/huanjian-resume-20261103/2610.20492v1.html').read_bytes(); txt=source.decode()
paths={
 'AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumSourceMatrixStructure.lean':(out/'phase2-raw/001-immutable-whole-production.stdout').read_bytes(),
 'Tests/GaussianComplexityFixedSpectrumSourceMatrixStructure.lean':(out/'phase2-raw/002-immutable-whole-tests.stdout').read_bytes()}
issues=[]; checks=[]; coverage={k:[0]*len(v.splitlines()) for k,v in paths.items()}
for mindex,mapping in enumerate(mp['mappings']):
 for span in mapping['source']:
  a,b=span['char_start'],span['char_end']; c,d=span['raw_utf8_start'],span['raw_utf8_end']; actual=source[c:d]
  tests={'whole_source_sha':digest(source)==span['file_sha256'],'char_byte_agreement':txt[a:b].encode()==actual,'span_sha':digest(actual)==span['span_sha256'],'source_id':('id="'+span['source_id']+'"') in txt[a:b], 'line_start':txt.count('\n',0,a)+1==span['lf_line_start'],'line_end':txt.count('\n',0,b-1)+1==span['lf_line_end'],'column0':a-(txt.rfind('\n',0,a)+1)==span['lf_column0_start']}
  checks.append({'mapping':mindex,'source_id':span['source_id'],'checks':tests})
  if not all(tests.values()): issues.append(checks[-1])
 for span in mapping['lean']:
  blob=paths[span['path']]; t=blob.decode(); s,e=span['LF_lines_1based']; lines=blob.splitlines(keepends=True); a,b=span['raw_UTF8_byte_span']; c,d=span['decoded_char_span']
  tests={'whole_file_sha':digest(blob)==span['file_sha256'],'span_sha':digest(blob[a:b])==span['span_sha256'],'line_byte_agreement':b''.join(lines[s-1:e])==blob[a:b],'char_byte_agreement':t[c:d].encode()==blob[a:b]}
  checks.append({'mapping':mindex,'code_path':span['path'],'lines':[s,e],'checks':tests})
  if not all(tests.values()): issues.append(checks[-1])
  for j in range(s-1,e): coverage[span['path']][j]+=1
lesson=json.loads((inputs/'website/content/declaration_lessons/huanjian-gaussian-source-matrix-structure.json').read_text())['units'][0]
steps=lesson['steps']
lesson_checks={'six_steps':len(steps)==6,'P_all_148_lines_exact_once':''.join(s['lean'] for s in steps[:4]).encode()==paths[list(paths)[0]],'T_all_108_lines_exact_once':''.join(s['lean'] for s in steps[4:]).encode()==paths[list(paths)[1]]}
coverage_checks={p:{'lines':len(count),'each_line_once':all(x==1 for x in count),'missing':[i+1 for i,x in enumerate(count) if x==0],'multiply_covered':[i+1 for i,x in enumerate(count) if x>1]} for p,count in coverage.items()}
packets={r:json.loads((inputs/f'.astis/huanjian-gc-source-matrix-structure-20261113/fresh-{r}-review.v1.json').read_text()) for r in ['P','T']}
packet_checks={}
for r,p in packets.items():
 core={k:v for k,v in p.items() if k!='packet_sha256'}
 anon='anon_328a' if r=='P' else 'anon_96ec'; e=inputs/'research-wiki/paper-contributions/GaussianComplexity/source-matrix-structure-semantic-evidence/decoder-originals'/anon
 inp=json.loads((e/'input.json').read_text()); res=json.loads((e/'result.json').read_text()); recon=(e/'reconstruction.md').read_bytes()
 packet_checks[r]={'canonical_packet_hash':sha_json(core)==p['packet_sha256'],'source_text_sha':digest(p['source']['original_text'].encode())==p['source']['text_sha256'],'statement_sha':digest(p['lean']['statement'].encode())==p['lean']['statement_sha256'],'decoder_input_statement_same':inp['lean']['statement']==p['lean']['statement'],'decoder_reconstruction_text_same':res['reconstructed_theorem_text']==p['blind_reconstruction']['text'],'decoder_reconstruction_text_hash':digest(res['reconstructed_theorem_text'].encode())==p['blind_reconstruction']['text_sha256'],'decoder_original_run_hash':digest(recon)==p['blind_reconstruction']['decoder_run_sha256'],'decoder_packet_hash':inp['packet_sha256']==p['blind_reconstruction']['decoder_packet_sha256'],'decoder_sourcefalse':res['source_text_visible'] is False,'input_no_source_identity_flags':not any(inp['non_disclosure'][k] for k in ['source_text_included','source_anchor_included','source_identity_included','audit_identity_included','lean_declaration_identity_included'])}
ctx=json.loads((inputs/'.astis/huanjian-gc-source-matrix-structure-20261113/candidate-publication-context.v1.json').read_text())
context_checks={'P_saved_current_context_equals_packet_context':ctx['publication_context']==packets['P']['candidate_publication_context'],'P_binding_equal':ctx['publication_binding_sha256']==packets['P']['publication_binding_sha256'],'T_public_producer_context_equals_P':packets['T']['candidate_publication_context']['canonical_public_producer_context']==packets['P']['candidate_publication_context'],'P_whole_module_matches_immutable':packets['P']['candidate_publication_context']['current_lean_module'].encode()==paths[list(paths)[0]],'T_whole_module_matches_immutable':packets['T']['candidate_publication_context']['private_consumer']['whole_module_text'].encode()==paths[list(paths)[1]],'T_source_lean_map_matches_authored':packets['T']['candidate_publication_context']['source_lean_correspondence']==mp}
commit='6577db458215516666fe25aed73566f5b09767f0'
commit_checks=[]
for rel in list(paths)+['website/content/declaration_lessons/huanjian-gaussian-source-matrix-structure.json','website/content/publications/huanjian-gaussian-source-matrix-structure.json','research-wiki/paper-contributions/GaussianComplexity/source-matrix-structure-semantic-evidence/source-lean-map.authored-v1.json','research-wiki/paper-contributions/GaussianComplexity/source-matrix-structure-semantic-evidence/conceptual-mirror-audit.authored-v1.json']:
 p=subprocess.run(['git','show',commit+':'+rel],cwd=repo,capture_output=True); dest=out/'phase3-inputs/commit6577'/rel; dest.parent.mkdir(parents=True,exist_ok=True); dest.write_bytes(p.stdout)
 expected=paths[rel] if rel in paths else (inputs/rel).read_bytes()
 commit_checks.append({'path':rel,'exact_commit':commit,'sha256':digest(p.stdout),'exit_code':p.returncode,'exact_saved_input_bytes':p.stdout==expected,'stderr':p.stderr.decode()})
report={'source_span_checks':checks,'source_span_issues':issues,'source_map_line_coverage':coverage_checks,'lesson_exact_coverage':lesson_checks,'packet_identity_checks':packet_checks,'publication_context_identity_checks':context_checks,'immutable_reader_commit_checks':commit_checks,'scope':'independent byte/custody/source-map checks; no compiler or native result read or inferred'}
(out/'phase3-v1-independent-byte-span-checks.json').write_text(json.dumps(report,indent=2)+'\n'); print(json.dumps(report,indent=2))
