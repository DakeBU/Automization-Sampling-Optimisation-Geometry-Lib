# Raw-source expectations freeze: Tropp Lemma 6.7

This is a source-reading freeze made before any candidate signature, header,
implementation Lean, proof search, authored R12 lesson, decode, verdict, or prior
Bernstein conclusion was inspected. No target signature is supplied or proposed.
This is bounded source preparation, not intake, a Statement Seal, proof,
acceptance, publication, or verified result. The owning R12 lane remains closing
local V. Only this preparation directory is written.

## Primary originals and reading boundary

- Joel A. Tropp, *User-Friendly Tail Bounds for Sums of Random Matrices*, author
  preprint, revised 15 June 2011. Original URL:
  https://tropp.caltech.edu/papers/Tro11-User-Friendly-preprint.pdf
- Local original:
  `.astis/semantic-neutral-20261113/bernstein_raw_intake_74ab/Tro11-User-Friendly-preprint.pdf`.
  SHA-256 `f4c3cff8661011395e793972a1f8d9a199fae4ca0fd098535d7a42166cf8fc86`.
- Visually inspected complete PDF pages 7-12 and 23-26, with layout text used
  only as an extraction aid. PDF page numbers equal printed page numbers here.
- Gaussian original:
  `.astis/huanjian-resume-20261103/2610.20492v1.html`,
  SHA-256 `6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915`.
  Read only raw source anchors `A3.Thmtheorem6`, `A3.SS2.p12` through
  `A3.SS2.p16`, including `A3.Ex121`, to identify the intended downstream use.

## Exact expected source statement and domains

Lemma 6.7, pp. 25-26, assumes a random self-adjoint matrix X with

    E X = 0,          lambda_max(X) <= 1,

and concludes, for every real theta > 0,

    E exp(theta X) <=_L exp((exp(theta) - theta - 1) E(X^2)).

Here `<=_L` is the Loewner order. The source does not put an explicit dimension,
probability-space binder, measurability predicate, finite-second-moment
predicate, norm bound, lower-eigenvalue bound, independence premise, or
all-orders moment-growth premise in Lemma 6.7. The source convention in Section
2.1 is finite complex square matrices, self-adjoint meaning conjugate transpose
equals the matrix; real symmetric matrices form a specialization. Matrices in
one comparison have the same finite size. The algebraic largest eigenvalue is
not the operator norm. The norm used elsewhere in the source is the Euclidean
operator/spectral norm.

Section 2.2, p. 7, expressly assumes all random variables sufficiently regular
to justify expectations, interchanging limits, and similar operations, and says
the paper often omits the qualification almost surely. Therefore the spectral
bound in Lemma 6.7 is an almost-sure bound. Its centering is a deterministic
matrix-expectation equality. No named base space, sigma algebra, law, or
integral construction is specified. Section 2.7 says expectation preserves
Loewner order; Section 2.3 defines matrix functions spectrally; Section 2.4
defines matrix exponential spectrally or by its power series. X^2 is the matrix
product X X, and E(X^2) is a matrix expectation, not (E X)^2.

The broad Section 2.2 regularity convention is part of the raw source boundary;
it is not an enumerated analytic hypothesis. A one-sided eigenvalue cap plus
finite mean does not imply a finite second moment: negative spectral tails may
be heavy. The source displays E(X^2) as a finite matrix without spelling out
exact integrability. Record this imprecision; do not silently add a public
finite-moment or measurability premise and label it source-explicit. Section
3.1's illustrative introduction of mgfs for variables with moments of all orders
does not insert an all-orders moment premise into Lemma 6.7.

## Expected proof fragments, in their source order

1. The introductory sentence says the lemma bounds a zero-mean matrix mgf using
   a bound on its largest eigenvalue.
2. The unnumbered attribution says the proof parallels a classical method
   learned through correspondence with Yao-Liang Yu. This is provenance, not a
   separately supplied theorem or proof certificate.
3. Fix theta > 0 and define a smooth real-line function

       f(x) = (exp(theta x) - theta x - 1)/x^2, x != 0;
       f(0) = theta^2/2.

4. The source leaves differential calculus verifying that f is increasing as an
   exercise; hence f(x) <= f(1) for all real x <= 1.
5. The eigenvalues of X do not exceed 1. The transfer rule (2.2) yields
   f(X) <=_L f(1) I, outcome by outcome on the almost-sure event.
6. Expand the exponential, including the removable-zero value, and apply that
   matrix inequality by congruence with X:

       exp(theta X) = I + theta X + X f(X) X
                    <=_L I + theta X + f(1) X^2.

7. Take expectations, use centering and order preservation (2.13):

       E exp(theta X) <=_L I + f(1) E(X^2).

8. Apply I+A <=_L exp(A), equation (2.3), to A=f(1)E(X^2), then evaluate f(1):

       I + f(1)E(X^2) <=_L exp(f(1)E(X^2))
                       = exp((exp(theta)-theta-1)E(X^2)).

The omitted scalar calculus, spectral identity at zero, congruence-order step,
expectation linearity/integrability justification, and self-adjointness of the
deterministic exponent are internal mathematical ports. They are not new
source hypotheses or supplied ingredients.

## Expected native consumer and background boundary

The native intended consumer is Theorem 6.1, pp. 23-24 and proof p. 26:
a finite independent family X_k of random self-adjoint d by d matrices with
E X_k=0 and lambda_max(X_k)<=R almost surely. It defines
sigma^2 = ||sum_k E(X_k^2)|| and asserts for every t>=0

    P(lambda_max(sum_k X_k)>=t)
      <= d exp(-(sigma^2/R^2) h(Rt/sigma^2))
      <= d exp(-t^2/(2(sigma^2+Rt/3)))
      <= d exp(-3t^2/(8sigma^2))  if t<=sigma^2/R,
         d exp(-3t/(8R))         if t>=sigma^2/R,

where h(u)=(1+u)log(1+u)-u for u>=0. The source expressly permits arbitrarily
negative minimum eigenvalues and says applying the theorem to X_k and -X_k can
require different R. Thus Theorem 6.1 is not itself a two-sided bounded-norm
theorem.

The proof first sets R=1 by homogeneity, uses Lemma 6.7 with
g(theta)=exp(theta)-theta-1 and A_k=E(X_k^2) in Corollary 3.7, identifies
lambda_max(sum A_k)=sigma^2 using positivity, and optimizes the scalar bound at
theta=log(1+t/sigma^2). It then uses the unnamed scalar estimate
h(u)>=u^2/(2(1+u/3)) and two monotonicity comparisons for the split bound.

Corollary 3.7 invokes Master Tail Theorem 3.6, which invokes Proposition 3.1
(Laplace/Markov) and Lemma 3.4 (matrix-cgf subadditivity). Lemma 3.4 invokes
Corollary 3.3, which invokes Theorem 3.2 (Lieb [Lie73, Theorem 6]). These remain
open background dependencies in this packet. A source graph records their use;
it does not certify any of them.

Source-exact domain imprecision: Theorem 6.1 does not explicitly write R>0 or
sigma^2>0 although its normalization/formulas divide by these quantities. At
t=0 with sigma^2>0, the displayed minimizer is theta=0, outside the positive
theta domain; the infimum is approached at the boundary. The zero-scale cases
and this endpoint need explicit interpretation in any later interface ruling.
No such ruling, changed source statement, or new public premise is made here.

## Gaussian use and non-attribution boundary

Gaussian Appendix C.2, Fact C.6 proof, `A3.SS2.p15` / `A3.Ex121`, says a
two-sided bounded matrix Bernstein inequality applies to the independent,
centered, self-adjoint sequences Z_i and cos(n theta_i)Z_i. Its raw source gives
dimension r^2, a common operator-norm cap R_*, variance upper bound v_*, t>0,
and

    P(||sum_i Z_i||_op > t)
      <= 2 r^2 exp(-t^2/(2(v_*+R_* t/3))),

with the same bound for the weighted sequence. There is no citation at that
invocation. Tropp is an external background source chosen for possible future
preparation, not an author attribution found in the Gaussian paper.

A route from Tropp's one-sided result to that background form must still
discharge the negative-sequence bound, the two-tail union/spectral-norm bridge,
variance-envelope monotonicity, real-to-complex specialization as applicable,
and strict versus non-strict event inclusion. None is an extra Gaussian source
hypothesis, none is an existing supplied certificate in this packet, and no
formal target is assigned here.

## Freeze scope

No Lean API lookup is needed for this source reading and none was performed.
The subsequent graph may refine fragment inventory and dependency use sites,
but this raw-source statement boundary may not be changed to fit a candidate.
No shared queue, private guardmap, frontier, ledger, source index, site, import,
proof, or R12 record is edited. No browser is launched and no ASTIS background
process is run.
