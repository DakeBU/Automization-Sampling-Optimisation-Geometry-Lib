"""Exact public statement/full proof folds and every bounded module source/download link."""
import html,json,re
from html.parser import HTMLParser
from run import ROOT,sha
m=json.loads((ROOT/'input-manifest.json').read_text());I=ROOT/'inputs';out=ROOT/'reader'
page=out/'proofs/source-huanjian-gaussian-source-row-independence.html';text=page.read_text()
raw=(I/m['P']).read_text();decl=raw[raw.index('theorem actual_source_rows_independent'):].strip()
folds={role:html.unescape(re.search(r'<pre[^>]*><code[^>]*>(.*?)</code>',chunk,re.S).group(1)) for role,chunk in re.findall(r'<details class="inline-lean inline-lean-(statement|proof)"(.*?)(?=<details class="(?:reader-ledger|proof-reader-provenance))',text,re.S)}
assert folds['statement']==decl.split(' := by\n',1)[0]
assert folds['proof']==decl
class Links(HTMLParser):
    def __init__(self):super().__init__();self.links=[]
    def handle_starttag(self,t,a):
        if t=='a':self.links.append(dict(a))
checked=[]
for p in [page]+list((out/'modules').glob('*.html')):
    q=Links();q.feed(p.read_text())
    for a in q.links:
        href=a.get('href','')
        if not any(z in href for z in ['downloads/lean/','modules/','data/lesson-sources/']):continue
        d=(p.parent/href.split('#')[0]).resolve();assert d.is_relative_to(out) and d.exists(),(str(p),href)
        if '#' in href:assert 'id="'+href.split('#')[1]+'"' in d.read_text(),href
        if 'downloads/lean/' in href:
            src=href[href.index('downloads/lean/')+len('downloads/lean/'):]
            assert d.read_bytes()==(I/src).read_bytes()
            assert a['download']==src.rsplit('/',1)[-1]
        checked.append({'page':str(p.relative_to(ROOT)),'href':href,'download_name':a.get('download')})
result={'public_folded_statement_exact':True,'public_folded_complete_proof_exact_to_scanner_source':True,'statement_sha256':sha(folds['statement'].encode()),'full_folded_proof_sha256':sha(folds['proof'].encode()),'all_bounded_source_download_and_complete_module_links_checked':checked,'download_runtime_claimed':False,'note':'Files locally materialized from exact frozen source bytes; production source action targets and static download names/bytes checked. No click or browser claim.'}
(ROOT/'static-extra.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'extra_source_links_checked':len(checked),'public_folds_exact':True}))
