import ast
import copy
import difflib
from hashlib import sha256
import json
from pathlib import Path

ROOT = Path('/Users/zhouhuanjian/ASTIS-GC')
BASE = ROOT / '.astis/semantic-neutral-20261114/mgf_fresh_source_5b7e'
NATIVE = ROOT / '.astis/semantic-neutral-20261114/weighted_mgf_native_8c2d/runtime'
OUT = BASE / 'phase11_v4_measurement_preflight/attempt2'
OUT.mkdir(exist_ok=False)


def sha(data):
    return sha256(data).hexdigest()


def archive(name, data):
    target = OUT / 'originals' / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)


old = (BASE / 'phase9_v3_contract_preflight/originals/browser_check.v3.py').read_bytes()
new = (NATIVE / 'browser_check.py').read_bytes()
contract_bytes = (NATIVE / 'independent-browser-contract.v4.json').read_bytes()
old_contract_bytes = (BASE / 'phase9_v3_contract_preflight/originals/independent-browser-contract.v3.json').read_bytes()
diff_bytes = (NATIVE / 'browser-check.v3-to-v4.exact.diff').read_bytes()
contract_diff_bytes = (NATIVE / 'browser-contract.v3-to-v4.exact.diff').read_bytes()
selfcheck_bytes = (NATIVE / 'browser-v4-visible-glyph-selfcheck.json').read_bytes()
extension = (NATIVE / 'browser_extensions.py').read_bytes()
assert sha(old) == 'a00b0b144d94257e88f7b054d43acaf3e771b7409cf895d02daa32c2863e0416'
assert sha(new) == '89170589853cf1eed161d98e5a3438614688e68902c91ab876e68baa06af1c03'
assert sha(contract_bytes) == '123942888e8864a4a4e2acce653fd431c8f6e007c4af89d5aa6fb7bdcb0000d4'
assert sha(diff_bytes) == '2a2818526cac6d54607db77c1610ef868f1c50873b4afba9527585ae41b640f6'
assert sha(selfcheck_bytes) == '3d5458c8b4f9a6bc25f7d0416de8877cf2c5d102306489f1583c0b57463ddb1c'
for name, data in [('browser_check.v4.py', new), ('independent-browser-contract.v4.json', contract_bytes),
                   ('browser-check.v3-to-v4.exact.diff', diff_bytes),
                   ('browser-contract.v3-to-v4.exact.diff', contract_diff_bytes),
                   ('browser-v4-visible-glyph-selfcheck.json', selfcheck_bytes),
                   ('browser_extensions.unchanged.py', extension)]:
    archive(name, data)

old_contract = json.loads(old_contract_bytes)
contract = json.loads(contract_bytes)
checks = {}
checks['exact_script_diff_regenerated_matches'] = ''.join(difflib.unified_diff(
    old.decode().splitlines(keepends=True), new.decode().splitlines(keepends=True),
    fromfile='attempt3-originals/browser_check.py', tofile='browser_check.py-v4')).encode() == diff_bytes
checks['exact_contract_diff_regenerated_matches'] = ''.join(difflib.unified_diff(
    old_contract_bytes.decode().splitlines(keepends=True), contract_bytes.decode().splitlines(keepends=True),
    fromfile='independent-browser-contract.v3.json', tofile='independent-browser-contract.v4.json')).encode() == contract_diff_bytes

old_ast, new_ast = ast.parse(old), ast.parse(new)
def calls(tree):
    return [ast.dump(n, include_attributes=False) for n in ast.walk(tree)
            if isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id == 'check']
checks['all42_check_call_ASTs_identical'] = calls(old_ast) == calls(new_ast) and len(calls(old_ast)) == 42

def measurement_constant(tree):
    return [n.value for n in ast.walk(tree) if isinstance(n, ast.Constant) and isinstance(n.value, str)
            and 'lastGlyphWidth:r.width' in n.value]
old_constants, new_constants = measurement_constant(old_ast), measurement_constant(new_ast)
assert len(old_constants) == len(new_constants) == 1
old_js, new_js = old_constants[0], new_constants[0]
old_selection = 'range.setStart(text, Math.max(0,text.length-1));range.setEnd(text,text.length);'
new_selection = '''const rawText=text.textContent, visibleText=rawText.trimEnd();
                            const end=visibleText.length;
                            let start=Math.max(0,end-1);
                            if(start>0 && rawText.charCodeAt(start)>=0xDC00 && rawText.charCodeAt(start)<=0xDFFF
                                && rawText.charCodeAt(start-1)>=0xD800 && rawText.charCodeAt(start-1)<=0xDBFF) start--;
                            const selectedGlyph=rawText.slice(start,end);
                            range.setStart(text,start);range.setEnd(text,end);'''
old_return = 'return {scroll:p.scrollLeft,max:p.scrollWidth-p.clientWidth,\n'
new_return = '''return {scroll:p.scrollLeft,max:p.scrollWidth-p.clientWidth,
                                sourceLineId:el.id,sourceTextLengthUTF16:rawText.length,
                                selectedGlyphStartUTF16:start,selectedGlyphEndUTF16:end,selectedGlyph,
                                selectedGlyphCodePoints:Array.from(selectedGlyph,c=>c.codePointAt(0)),
                                trailingWhitespaceCodeUnitsSkipped:rawText.length-end,
                                oldLastCodeUnit:rawText.slice(-1),
'''
checks['only_final_selection_and_added_diagnostics_change_inside_measurement_JS'] = (
    old_js.count(old_selection) == 1 and old_js.count(old_return) == 1 and
    old_js.replace(old_selection, new_selection).replace(old_return, new_return) == new_js)

versions = {}
for stem in ['independent-browser-contract.v{}.json', 'browser-output-v{}', 'browser-process-v{}',
             'independent-native-weighted-mgf-browser-result-v{}',
             'independent-native-actual-browser-process-receipt-v{}']:
    for v in [3, 4]:
        versions[stem.format(v)] = stem.format('VERSION')
class Normalize(ast.NodeTransformer):
    def visit_Constant(self, node):
        if isinstance(node.value, str):
            node.value = old_js if node.value == new_js else versions.get(node.value, node.value)
        return node
checks['entire_other_pipeline_AST_identical_after_exact_selection_and_version_normalization'] = (
    ast.dump(Normalize().visit(copy.deepcopy(old_ast)), include_attributes=False) ==
    ast.dump(Normalize().visit(copy.deepcopy(new_ast)), include_attributes=False))
checks['extension_byte_identical_to_frozen_v3'] = extension == (
    BASE / 'phase9_v3_contract_preflight/originals/browser_extensions.unchanged.py').read_bytes()

allowed_changed = {'schema', 'wrapper_sha256', 'owned_inputs', 'runtime_output_root', 'runtime_process_root', 'runtime_readiness'}
added = {'version4_change_scope', 'measurement_input', 'supersedes_v3_measurement_input_failure_only'}
checks['contract_other_fields_exactly_unchanged'] = (
    set(contract) - set(old_contract) == added and not (set(old_contract) - set(contract)) and
    all(contract[k] == old_contract[k] for k in old_contract if k not in allowed_changed))
checks['all372_old_inputs_unchanged_plus_one_v3_preservation_manifest'] = (
    contract['owned_inputs'][:-1] == old_contract['owned_inputs'] and len(contract['owned_inputs']) == 373 and
    contract['owned_inputs'][-1]['path'] == str(NATIVE / 'attempt3-originals/preservation-manifest.json'))
checks['all373_actual_owned_input_hashes_match'] = all(
    sha((NATIVE / row['path']).read_bytes()) == row['sha256'] for row in contract['owned_inputs'])
checks['same_reader_v2_and_math_binding'] = (
    contract['reader_freeze_sha256'] == 'c93f60d6b51a0da491bd748d54bdbc68fbdbc2f86653de5914539afb2aaee7d1' and
    contract['reader_identity'] == old_contract['reader_identity'] and
    contract['mathematical_candidate'] == '4869db55d340cee39f0ba4d49fb0a7a4309ba2d6' and
    contract['wrapper_sha256'] == sha(new))
checks['candidate_only_and_unique_output_paths'] = (
    set(contract['exact_commands']) == {'candidate'} and
    contract['exact_commands']['candidate'][-1] == 'candidate' and
    contract['runtime_output_root'] == 'browser-output-v4' and contract['runtime_process_root'] == 'browser-process-v4')

preservation_bytes = (NATIVE / 'attempt3-originals/preservation-manifest.json').read_bytes()
archive('attempt3-preservation-manifest.json', preservation_bytes)
preservation = json.loads(preservation_bytes)
checks['all115_v3_preserved_files_still_match'] = (
    sha(preservation_bytes) == 'a47ac29fe5019b8b6ce429a91635377ae75fec84bfe67ea2e20c0231543e0211' and
    len(preservation['all_files']) == 115 and all(
        sha((NATIVE / 'attempt3-originals' / row['path']).read_bytes()) == row['sha256'] for row in preservation['all_files']))
actual_old = BASE / 'phase10_native_glyph_failure/originals/candidate/actual-checks.json'
receipt_old = BASE / 'phase10_native_glyph_failure/originals/process/process-receipt.json'
supersedes = contract['supersedes_v3_measurement_input_failure_only']
checks['v3_real_failure_binding_matches_independent_frozen_originals'] = (
    supersedes['actual_result_sha256'] == sha(actual_old.read_bytes()) and
    supersedes['actual_process_receipt_sha256'] == sha(receipt_old.read_bytes()) and
    supersedes['checks'] == 343 and supersedes['false_count'] == 8 and supersedes['PNG_count'] == 86)
cause = json.loads((BASE / 'phase10_native_glyph_failure/independent-measurement-causality.json').read_text())
expected = contract['measurement_input']['independent_expected_source_glyphs']
checks['expected_glyphs_match_own_source_first_causality'] = all(
    entry['source'] == own['source'] and entry['line_id'] == 'L' + str(own['longest_line']) and
    entry['last_non_whitespace_character'] == own['last_nonwhitespace_character'] and
    entry['actual_frozen_line_text'] == ast.literal_eval(own['exact_line_repr']) and
    (entry['new_probe_UTF16_start'],entry['new_probe_UTF16_end']) == bounds
    for entry, own, bounds in zip(expected, cause['frozen_source_analysis'], [(120,121),(128,129)])) and len(expected) == 2

result = {'reviewer':'mgf_fresh_source_5b7e',
    'verdict':'accepted-exact-v4-measurement-input-repair-and-contract-for-one-ROOT-candidate-run;not-runtime-acceptance',
    'all_checks_passed':all(checks.values()), 'checks':checks,
    'script_sha256':sha(new), 'contract_sha256':sha(contract_bytes),
    'previous_failure_frozen_before_this_diff_opened':True,
    'new_reader_or_math_changes':False, 'reviewer_browser_build_API_calls':0,
    'actual_v4_result_or_PNG_seen':False, 'proof_VERIFIED_authorized_or_called':False,
    'Unicode_boundary_scope':'Last full Unicode code point, not a general grapheme-cluster algorithm. Actual frozen selected suffixes are ASCII d/s; empty/whitespace-only text remains zero-width and must fail the unchanged positive-width predicate.'}
(OUT / 'independent-v4-measurement-checks.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'all_checks_passed':result['all_checks_passed'],'check_count':len(checks),
                  'failed':[k for k,v in checks.items() if not v]}, indent=2))
assert result['all_checks_passed']
