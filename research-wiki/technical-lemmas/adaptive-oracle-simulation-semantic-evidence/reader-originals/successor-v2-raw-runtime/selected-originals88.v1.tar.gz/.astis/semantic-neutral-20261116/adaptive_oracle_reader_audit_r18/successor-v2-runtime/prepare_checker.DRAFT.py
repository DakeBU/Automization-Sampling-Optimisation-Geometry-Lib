"""Build unexecuted successor checker with additions only; no browser import or launch."""
from pathlib import Path
import ast
import difflib
import hashlib
import json

OWN=Path(__file__).resolve().parent
BASE=OWN.parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
old=(BASE/'browser_check.py').read_text()
assert sha(BASE/'browser_check.py')=='e1fdbb3731486f240d10fb47683df2665656910cb8e407182a466d64006fc550'
insertions=[
 ('from browser_anchor_wait import wait_for_natural_anchor\n',
  'from browser_inline_regression import run_inline_regression\n'),
 ("    assert sha(OWN/'browser_anchor_wait.py')==a['anchor_wait_sha256']\n",
  "    assert sha(OWN/'browser_inline_regression.py')==a['inline_regression_sha256']\n"),
 ("                    layout('proof-expanded')\n",
  "                    try:\n"
  "                        run_inline_regression(page,label,check,shot)\n"
  "                        layout('inline-regression-expanded')\n"
  "                    except Exception:\n"
  "                        check(label+'-inline-regression-stage-completed',False,traceback.format_exc());shot(page,label+'-inline-regression-stage-failure')\n")]
new=old
for anchor,addition in insertions:
    assert new.count(anchor)==1
    new=new.replace(anchor,anchor+addition)
restored=new
for anchor,addition in insertions:
    restored=restored.replace(anchor+addition,anchor)
assert restored==old
(OWN/'browser_check.py').write_text(new)
for name in ['browser_geometry.py','browser_anchor_wait.py']:
    (OWN/name).write_bytes((BASE/name).read_bytes())
diff=''.join(difflib.unified_diff(old.splitlines(keepends=True),new.splitlines(keepends=True),
    fromfile='R18-original-485check/browser_check.py',tofile='R18-successor-v2-DRAFT/browser_check.py'))
(OWN/'browser_check.py.exact.diff').write_text(diff)
checks=[]
for name in ['browser_check.py','browser_geometry.py','browser_anchor_wait.py','browser_inline_regression.py']:
    ast.parse((OWN/name).read_text())
    checks.append({'path':name,'sha256':sha(OWN/name),'syntax':'AST parsed without execution'})
geometry_tree=ast.parse((OWN/'browser_geometry.py').read_text())
visible=next(ast.literal_eval(n.value) for n in geometry_tree.body if isinstance(n,ast.Assign) and n.targets[0].id=='VISIBLE')
regression_tree=ast.parse((OWN/'browser_inline_regression.py').read_text())
measure_template=next(ast.literal_eval(n.value) for n in regression_tree.body if isinstance(n,ast.Assign) and n.targets[0].id=='MEASURE_TEMPLATE')
measure=measure_template.replace('$VISIBLE$',visible)
(OWN/'geometry-expression.syntax.DRAFT.js').write_text('('+measure+');\n(xs=>xs.map('+measure+'));\n')
template={
 'authorization':'DRAFT_ONLY_NOT_AUTHORIZED',
 'preview_root':None,
 'runner_sha256':sha(OWN/'browser_check.py'),
 'geometry_sha256':sha(OWN/'browser_geometry.py'),
 'anchor_wait_sha256':sha(OWN/'browser_anchor_wait.py'),
 'inline_regression_sha256':sha(OWN/'browser_inline_regression.py'),
 'preview_manifest_sha256':None,
 'source_reviewed_publication_binding_sha256':None,
 'actual_source_review_artifact':{'path':None,'sha256':None},
 'frozen_inputs':[],
 'selected_served_leaf_count':None,
 'lesson_sha256':None,
 'publication_sha256':None,
 'chrome':{'path':None,'binary_sha256':None},
 'execution_custody':'DRAFT ONLY: ROOT will provide actual fresh v2 preview/hash and source-reviewed assignment. Original485-check code retained byte-for-byte with additions only, geometry/anchor byte-identical; added regression checks actual top-level inline math local overflow, visible right-end/superscript and all-glyph vertical clip, original font ratio, and all-assumption nonempty available MathML. All outputs derive from this new owned directory. No browser/server has been started by this preparation.'}
(OWN/'execution-assignment.TEMPLATE.DRAFT.json').write_text(json.dumps(template,indent=2)+'\n')
# A local successor schema, with the same original runtime authorization value.
schema={'$schema':'https://json-schema.org/draft/2020-12/schema','title':'R18 successor exact actual assignment; DRAFT cannot authorize execution','type':'object',
 'required':list(template),'properties':{'authorization':{'const':'ROOT_AUTHORIZED_AFTER_SOURCE_REVIEW'},
 'preview_root':{'type':'string','minLength':1},'execution_custody':{'type':'string','minLength':1},
 'selected_served_leaf_count':{'type':'integer','minimum':1},
 'frozen_inputs':{'type':'array','minItems':10,'items':{'type':'object','required':['path','sha256'],'properties':{'path':{'type':'string','minLength':1},'sha256':{'type':'string','pattern':'^[0-9a-f]{64}$'}}}},
 'actual_source_review_artifact':{'type':'object','required':['path','sha256'],'properties':{'path':{'type':'string','minLength':1},'sha256':{'type':'string','pattern':'^[0-9a-f]{64}$'}}},
 'chrome':{'type':'object','required':['path','binary_sha256'],'properties':{'path':{'type':'string','minLength':1},'binary_sha256':{'type':'string','pattern':'^[0-9a-f]{64}$'}}}}}
for key in ['runner_sha256','geometry_sha256','anchor_wait_sha256','inline_regression_sha256','preview_manifest_sha256',
            'source_reviewed_publication_binding_sha256','lesson_sha256','publication_sha256']:
    schema['properties'][key]={'type':'string','pattern':'^[0-9a-f]{64}$'}
(OWN/'execution-assignment.schema.DRAFT.json').write_text(json.dumps(schema,indent=2)+'\n')
out={'schema':'r18-successor-v2-checker-additions-only-preparation-v1','base_runner_sha256':sha(BASE/'browser_check.py'),
 'all_original_code_recovered_exactly_after_removing_three_additions':restored==old,
 'original_geometry_byte_identical':(OWN/'browser_geometry.py').read_bytes()==(BASE/'browser_geometry.py').read_bytes(),
 'original_anchor_wait_byte_identical':(OWN/'browser_anchor_wait.py').read_bytes()==(BASE/'browser_anchor_wait.py').read_bytes(),
 'files':checks,'exact_diff_sha256':sha(OWN/'browser_check.py.exact.diff'),
 'assignment_template_sha256':sha(OWN/'execution-assignment.TEMPLATE.DRAFT.json'),
 'actual_v2_preview_and_input_hashes':None,'browser_or_server_executed':False,
 'source_fidelity_verdict':'NOT PRODUCED; unchanged independent source gate remains separate',
 'original_complete_reader_packet_status':'FAIL; preserved',
 'acceptance':'NONE: preparation only, awaits ROOT review and exact actual assignment/launch window'}
(OWN/'CHECKER-PREFLIGHT.DRAFT.v1.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
