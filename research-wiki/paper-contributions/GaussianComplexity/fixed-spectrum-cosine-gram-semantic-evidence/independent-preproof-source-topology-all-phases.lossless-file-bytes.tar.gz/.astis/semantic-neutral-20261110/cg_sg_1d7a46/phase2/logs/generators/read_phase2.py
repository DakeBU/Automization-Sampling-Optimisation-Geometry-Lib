from pathlib import Path
from hashlib import sha256
import json
import stat

R=Path('/Users/zhouhuanjian/ASTIS-GC')
O=R/'.astis/semantic-neutral-20261110/cg_sg_1d7a46'
P=O/'phase2'
(P/'inputs').mkdir(parents=True)
(P/'logs').mkdir()
manifest_path=O/'phase1_manifest.json'
receipt_path=O/'phase1_receipt.json'
assert sha256(manifest_path.read_bytes()).hexdigest()=='ededc4db5669a328807c9e0fbf9f719fdc92df4257c878bafd343965e25fb00b'
assert sha256(receipt_path.read_bytes()).hexdigest()=='86869756bdcdb1dfe0a33cba6d572705ebee9c6784ecee5660db72c3c00bfd91'
m=json.loads(manifest_path.read_text())
for item in m['files']:
    p=O/'phase1'/item['path']
    assert p.stat().st_size==item['bytes']
    assert sha256(p.read_bytes()).hexdigest()==item['sha256']
    assert stat.S_IMODE(p.stat().st_mode)==0o444
assert sha256((O/'phase1/inputs/2610.20492v1.html').read_bytes()).hexdigest()=='6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
for d in [O/'phase1',*[x for x in (O/'phase1').rglob('*') if x.is_dir()]]:
    assert stat.S_IMODE(d.stat().st_mode)==0o555
report={'status':'PHASE1_ALL_HASHES_AND_MODES_UNCHANGED','phase1_manifest_sha256':sha256(manifest_path.read_bytes()).hexdigest(),
 'phase1_receipt_sha256':sha256(receipt_path.read_bytes()).hexdigest(),'phase1_files_checked':len(m['files']),
 'raw_source_sha256':'6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915',
 'inputs_read_after_raw_pin_verification':True}
(P/'logs/phase1_before.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
parts=[json.dumps(report,ensure_ascii=False)]
records=[]
for rel,size,digest in [
 ('.astis/huanjian-gc-fixed-spectrum-cosine-gram-20261110/strict-statement-projection.json',6296,'8c881cf422b5c637472f868839a93849468c203a8e0f8cedabcf40139136c549'),
 ('.astis/huanjian-gc-fixed-spectrum-cosine-gram-20261110/additional-canonical-Gaussian-definitions.json',1299,'70d5c296f08f41d214fa9baae07f5601787e0d4ffcb087756e0d22743ef0ca51')]:
    p=R/rel
    data=p.read_bytes()
    assert len(data)==size
    assert sha256(data).hexdigest()==digest
    target=P/'inputs'/p.name
    target.write_bytes(data)
    target.chmod(0o444)
    records.append({'path':str(p),'bytes':size,'sha256':digest,'snapshot':'inputs/'+p.name})
    parts.extend(['INPUT '+rel+' bytes='+str(size)+' SHA256='+digest,data.decode('utf-8')])
(P/'inputs.json').write_text(json.dumps({'raw_sha256':report['raw_source_sha256'],'exact_inputs':records,
 'phase1_reference':str(O/'phase1'),'parent_permission':'Only these two exact types/minimal-definitions packets and own phase1; no implementation/producerAPI/native/verdict/TC/other packet.'},ensure_ascii=False,indent=2)+'\n')
stdout='\n'.join(parts)+'\n'
(P/'logs/read_inputs.stdout').write_text(stdout)
(P/'logs/read_inputs.stderr').write_bytes(b'')
print(stdout,end='')
