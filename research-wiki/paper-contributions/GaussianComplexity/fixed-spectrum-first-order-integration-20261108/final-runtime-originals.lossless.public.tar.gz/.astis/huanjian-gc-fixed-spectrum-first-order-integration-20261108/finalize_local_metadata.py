from pathlib import Path
import copy, datetime, gzip, hashlib, json, shutil, subprocess, sys

R = Path('.astis/huanjian-gc-fixed-spectrum-first-order-integration-20261108')
J = Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-first-order-integration-20261108')
N = Path('.astis/semantic-neutral-20261108/src_4e8f6a')
X = N/'normalpark-execution-v2'
CORE = '9b1e90d25711668203c6e252cfe5a748f95c8ad4'
ADV = 'ASTIS-SA-20261108-GaussianComplexityFixedSpectrumFirstOrder'
CELL = Path('research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-first-order.json')
README = Path('research-wiki/paper-contributions/GaussianComplexity/README.md')
sha = lambda b: hashlib.sha256(b).hexdigest()
dump = lambda x: (json.dumps(x, ensure_ascii=False, indent=2)+'\n').encode()
ref = lambda p: {'path': str(p), 'sha256': sha(p.read_bytes())}
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == CORE
assert not subprocess.check_output(['git', 'diff', '--cached', '--name-only']).strip()
assert subprocess.check_output(['git', 'diff', 'HEAD', '--name-only'], text=True).splitlines() == ['runs/substantive_advances.jsonl']
m = X/'closeout-manifest.json'
assert sha(m.read_bytes()) == '61522e21b56e917fc81b5e3a49dd4d20c48aae3a797d665f9450f7db86e3a171'
manifest = json.loads(m.read_bytes())
assert manifest['normal_API_calls'] == 1 and manifest['sole_STAB_empty'] is True
for row in manifest['artifacts']:
    raw = (X/row['path']).read_bytes()
    assert sha(raw) == row['sha256'] and len(raw) == row['bytes']
receipt = json.loads((X/'foreground-command-receipt.json').read_bytes())
assert receipt['returncode'] == 0 and receipt['helper_executions'] == 1
assert sha((X/receipt['raw_log']).read_bytes()) == receipt['raw_log_sha256']
before = (X/'before-ledger.exact.jsonl').read_bytes()
append = (X/'normalpark-append.exact.jsonl').read_bytes()
ledger = Path('runs/substantive_advances.jsonl').read_bytes()
assert ledger == before+append and len(append.splitlines()) == 1
assert sha(append) == 'df9c84531299014b30148eccfbaba1a462714f78b98957823cda40c196da4da8'
assert sha(ledger) == '3cffc1120b532d9c8eac552bb317f14ead07ba72007fed3e93cf38b86513d5bd'
original = json.loads((N/'normalpark-preparation-v2/original-V306.exact.jsonl').read_bytes())
event = json.loads(append)
assert event['worker_id'] == original['worker_id'] == '/root/source_reader_4e8f6a'
assert {k:v for k,v in event['evidence'].items() if k != 'post_integration_normalpark'} == original['evidence']
assert set(event['evidence']) == set(original['evidence']) | {'post_integration_normalpark'}
sys.path.insert(0, str((N/'normalpark-preparation-v2').resolve()))
import park_common
baseline = json.loads((N/'normalpark-preparation-v2/preservation-baseline.json').read_bytes())
states = park_common.protected(baseline, after=True)
assert states[ADV]['state'] == 'VERIFIED' and not any(v['state'] == 'STABILIZING' for v in states.values())
sys.path.insert(0, 'tools')
import astis_site
assert astis_site.source_digest() == '18bcbfebf85cdf214e00cff1fa6d72c4bbf344a6c09bc76340efc783a3803c39'
public_execution = J/'original-source-verifier/normalpark-execution-v2'
assert not public_execution.exists()
shutil.copytree(X, public_execution)
for p in X.rglob('*'):
    if p.is_file(): assert (public_execution/p.relative_to(X)).read_bytes() == p.read_bytes()
accepted = J/'independent-reader/local-v4-acceptance.json'
eligible = J/'independent-reader/normalpark-v4-eligibility.json'
assert sha(accepted.read_bytes()) == '616f2ab62991c784d20261935b0b37aa5791bdd15f37b761ebd8b67079a31aea'
assert sha(eligible.read_bytes()) == '0f96f3523ba9f9b9b286144621c935305846e9fe08dab911328b4bf15cf265d0'
models = {name: sha(Path(name).read_bytes()) for name in ['website/content/graph_memory_index.json', 'website/content/functor_hypergraph.json']}
foreign = {str(p): sha(p.read_bytes()) for p in Path('research-wiki/frontier-cells').rglob('*.json') if p != CELL}
assert len(foreign) == 443
old_cell, old_readme = CELL.read_bytes(), README.read_bytes()
assert sha(old_cell) == 'ae7c1f5b7d59553a84966ae46b4181067fe58e014d481ee190ed2d9bc0fc7b3c'
diag = J/'finalmetadata-diagnostics'
diag.mkdir()
for name, raw in [('own-frontier-before-final-local-projection.raw.json.gz', old_cell),
                  ('README-before-final-local-projection.raw.md.gz', old_readme)]:
    p = diag/name
    p.write_bytes(gzip.compress(raw, mtime=0))
    assert gzip.decompress(p.read_bytes()) == raw
boundary = ('The literal full-O source cosine-grid quadratic has a genuinely constructed Frechet gradient Ax and actual value-and-gradient pair at every point. The same-O private reference2-to-kappa consumer uses the actual canonical affine provider; producer has ONE canonical admissibility parent and Test has TWO actual kernel parents. Independent source-checked candidate9d/sourceV first-carryingf45/accepted-audita148 remain distinct. Exact immutable integration/UI core9b passed official9658-job Lean/Tests/fakeclosure and all8 actual gates, real approved Chrome1440/390 and independent actual38-original review; root viewed8. The mobile native module selection HOLD is repaired by one independently reviewed exact JS camera exception, with8 actual native geometry rows. Extra4 preset/cross-view and2 old DensityAffinity rows are DOM/UI-only. Every other protected raw byte, foreign284 states and443 frontiers is preserved. The ORIGINAL source verifier made one normal existing-V STAB release preserving all10 original V evidence fields and proofowner; only post_integration_normalpark was added. This adds no target Gaussian/TV, adaptive/Borel-history, finiteprecision, deterministic worst-query cap, expected-cost or main-bound theorem. Remaining C4 calculus/strongconvexity/smoothness/unique-minimizer, moments/Krylov, necessary-background standalone audit debt, original-owner remote release, both full main lower bounds, remote delivery and postmerge purification/ExpositionSeal/wholeGoal remain open.')
c = json.loads(old_cell)
c['evidence'].setdefault('integration_phase_history', []).append(copy.deepcopy(c['evidence']['canonical_integration']))
integration = {'state': 'LOCAL_ACCEPTED_NORMAL_EXISTING_V_PARKED_REMOTE_AND_PURIFICATION_OPEN',
    'accepted_immutable_core': CORE, 'source_digest': astis_site.source_digest(),
    'owner': 'huanjian_gc_20261108_fixed_spectrum_first_order_integration',
    'independent_reader_acceptance': ref(accepted), 'independent_normalpark_eligibility': ref(eligible),
    'original_verifier_normalpark_closeout': ref(public_execution/'closeout-manifest.json'),
    'unique_park_append_sha256': sha(append), 'original_source_V_append_sha256': manifest['original_V_append_sha256'],
    'original_source_V_all10_evidence_fields_preserved': True, 'new_source_verdict': False,
    'source_Test_lesson_publication_unchanged': True, 'historical_parent_audits_upgraded': False,
    'qualified_UI_exception': json.loads(accepted.read_bytes())['reviewed_UI_repair'],
    'foreign_tracked_raw_bytes_preserved': False, 'all_other_foreign_tracked_raw_bytes_preserved': True,
    'remote_merge_publication_purification_or_wholeGoal_credit': False}
c['evidence']['canonical_integration'] = integration
c['evidence']['execution_boundary'] = boundary
c['source_detail_audit']['fidelity_boundary'] = boundary
c['source_detail_audit']['gap'] = 'Selected exact actual gradient/value and same-O forward reference precision response obligations are proved, independently source-reviewed and locally accepted. Remaining C4 geometry, full algorithm/oracle/precision/TV/cap/expected-cost and both main-bound/remote/purification obligations are not closed.'
c['statement_seal']['status'] = 'EXACT_STATEMENT_COMPILED_INDEPENDENT_SOURCE_VERIFIED_AND_LOCAL_INTEGRATION_ACCEPTED'
c['graph_contribution']['visual_review'] = 'Actual immutable9b desktop/mobile native graph navigation, source index, adjacent exactLean/module and actual38 original screenshots independently reviewed; root8. Mobile selected module camera HOLD corrected by exact reviewed JS only;8 native geometry rows and extra4 DOM-only routes preserve scope. ONE canonical producer parent and TWO private Test parents remain real kernel evidence; name-scan edges remain dashed/incomplete. Same existing conceptual bridge is a typed candidate supplement, never Lean transport/cost credit.'
c['source_proof_coverage']['selected_unproved_math_is_preimplementation_history'] = True
c['source_proof_coverage']['current_implementation_and_integration'] = integration
CELL.write_bytes(dump(c))
prefix = (f'## 2026-11-08 UTC: fixed-spectrum actual first-order reply locally accepted\n\n'
    f'The genuine gradient/value producer and same-O forward affine first-order consumer are independently source-VERIFIED and locally accepted at immutable core `{CORE}`. Actual official9658-job root Lean/Tests, all8 gates, real Chrome1440/390 and independent viewing of all38 current originals passed; root viewed8. A narrowly reviewed graph-camera JS repair fixes the mobile native module selection. The old HOLD and all original images remain. Extra preset/cross-view and old DensityAffinity checks retain their DOM-only scope.\n\n'
    'The ORIGINAL source verifier performed one normal existing-V release, preserving every original V evidence field, checked9d and proof owner; soleSTAB is empty. SourceV first-carryingf45 and accepted-audita148 remain metadata successors, not retroactive source-checked bytes. This later metadata commit receives no fresh-build, new source verdict or parent historical-audit credit.\n\n'
    'Both full main lower bounds, remaining C4 geometry/calculus/minimizer, moments/Krylov, actual Borel adaptive/private-seed/transcript/output, oracle/finiteprecision/TV/deterministic worst-cap and explicit expected-cost adapters, remote original-owner release/publication and postmerge purification/ExpositionSeal remain open. Last actual remote check retained main d9bcd423 and PR385 OPEN/UNSTABLE; no unchanged Bench retry, merge or other-owner edit occurred.\n\n'
    'Continue the SAME foreground Goal with root as sole mathematical worker. Next C4 candidate is source/meaning planning only: source C4, filename/name inventory and minimal StrongConvexOn/IsMinOn definitions were read; no next exact seal, source admission, SAU claim, proof-body/API retrieval or implementation has occurred. Existing foreign queues/frontiers and all earlier checkpoints remain intact.\n\n')
README.write_bytes(prefix.encode()+old_readme)
checkpoint = {'recorded_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'state': 'LOCAL_INTEGRATION_ACCEPTED_EXISTING_V_NORMALLY_PARKED_FINAL_METADATA_ONLY',
    'accepted_immutable_core': CORE, 'source_digest': astis_site.source_digest(),
    'source_checked_commit': '9d306d837fbddf1518b0035494baaf5c21c24488',
    'source_V_first_carrying_commit': 'f45ba48f7dc74db28f648c38c5a486615723a513',
    'accepted_source_audit_sha256': 'a14867ad5fd8723933500d4c264c91c05d6b11ef510090c3b6da216fcb402b57',
    'local_reader_acceptance': ref(accepted), 'normalpark_eligibility': ref(eligible),
    'normalpark_closeout': ref(public_execution/'closeout-manifest.json'),
    'normalpark_append_sha256': sha(append), 'current_ledger_sha256': sha(ledger), 'STAB': [],
    'actual_eight_same_core_gates': ref(J/'actual-v4-public-evidence-manifest.json'),
    'actual_browser_report': ref(J/'actual-v4-browser-originals/report.json'),
    'independent_actual38_pixel_review': ref(J/'independent-reader/original38-independent-review-v4/pixel-review.json'),
    'root_actual8_original_review': ref(J/'root-actual-v4-original8-review.json'),
    'remaining_truth_boundary': boundary, 'metadata_only_successor_is_not_a_fresh_build': True,
    'remote_owner_release_confirmed': False, 'Goal_complete': False,
    'next': 'Commit exact final metadata/evidence/normalpark append after focused metadata checks. Then seal the source C4 geometry and genuine oracle/Borel consumer interfaces, audit definitions/binders and obtain independent sourcegraph plus different-role topology admission before proof/API work. Continue both full main lower bounds and required adapters; no detached/background ASTIS.'}
cp = J/'resume-checkpoint.json'
assert not cp.exists()
cp.write_bytes(dump(checkpoint))
assert README.read_bytes().endswith(old_readme)
assert Path('runs/substantive_advances.jsonl').read_bytes() == ledger
assert foreign == {str(p): sha(p.read_bytes()) for p in Path('research-wiki/frontier-cells').rglob('*.json') if p != CELL}
assert all(sha(Path(name).read_bytes()) == h for name, h in models.items())
assert astis_site.source_digest() == checkpoint['source_digest']
result = {'state': 'ROOT_MECHANICAL_METADATA_PROJECTION_OF_EXISTING_INDEPENDENT_ACCEPTANCE_AND_ORIGINAL_ACTOR_NORMALPARK',
    'accepted_immutable_core': CORE, 'execution_manifest_verified_payloads': len(manifest['artifacts']),
    'sourceV_all10_fields_exact': True, 'original_verifier_normal_API_calls': 1,
    'root_lifecycle_API_calls': 0, 'new_source_verdict': False,
    'old_README_bytes_preserved_as_exact_suffix': True, 'foreign443frontiers_and_models_unchanged': True,
    'ledger_after_actual_original_verifier_park': sha(ledger), 'frontier_after': ref(CELL),
    'README_after': ref(README), 'checkpoint': ref(cp), 'source_digest_unchanged': astis_site.source_digest(),
    'fresh_build_or_remote_or_wholeGoal_credit': False}
p = J/'final-local-metadata-projection.json'
assert not p.exists()
p.write_bytes(dump(result))
print(json.dumps({'metadata_projection': str(p), 'sha256': sha(p.read_bytes()),
                  'foreign_frontiers_preserved': len(foreign), 'source_digest_unchanged': True,
                  'Goal_complete': False}))
