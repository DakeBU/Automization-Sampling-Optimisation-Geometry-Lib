#!/opt/anaconda3/bin/python
import hashlib
import json
import pathlib
BASE=pathlib.Path(__file__).resolve().parent
path=pathlib.Path('/Users/zhouhuanjian/ASTIS-GC/.astis/huanjian-gc-fixed-spectrum-cosine-gram-20261110/minimal-requested-orthonormal-normalization-context.json')
data=path.read_bytes();digest=hashlib.sha256(data).hexdigest()
assert len(data)==3571 and digest=='9af7f1de95198297be6a385134419d1ed00fb780809c79db5662822ea0ad2933'
(BASE/'inputs'/path.name).write_bytes(data)
rec={'path':str(path),'bytes':len(data),'sha256':digest,'snapshot':'inputs/'+path.name}
(BASE/'requested_input_inventory.json').write_text(json.dumps(rec,indent=2)+'\n')
print(json.dumps(rec));print(data.decode())
