#!/usr/bin/env python3
"""Actual type/value constant-node witnesses, not inferred import dependencies."""
from collections import deque
import hashlib
import json
from pathlib import Path

OWN = Path(__file__).resolve().parent
RAW = OWN / 'native-raw-roundtrip'
CANDIDATE = '4869db55d340cee39f0ba4d49fb0a7a4309ba2d6'

def name(raw):
    if raw[0] == 'anonymous':
        return ''
    prefix = name(raw[1])
    return prefix + '.' + str(raw[2]) if prefix else str(raw[2])

def children(node):
    positions = {'app': [(1, 'function'), (2, 'argument')], 'lam': [(2, 'binder_type'), (3, 'body')], 'forallE': [(2, 'binder_type'), (3, 'body')], 'letE': [(2, 'let_type'), (3, 'let_value'), (4, 'body')], 'mdata': [(2, 'metadata_body')], 'proj': [(3, 'projected_value')]}
    return [(node[index], label) for index, label in positions.get(node[0], [])]

def references(nodes, root):
    todo = deque([(root, [root], [])])
    seen = set()
    found = {}
    while todo:
        index, path, labels = todo.popleft()
        if index in seen:
            continue
        seen.add(index)
        node = nodes[index]
        if node[0] == 'const':
            found.setdefault(name(node[1]), {'node_path': path, 'edge_labels': labels})
        for child, label in children(node):
            todo.append((child, path + [child], labels + [label]))
    return found

def main():
    declarations = {}
    modules = {}
    for path in sorted(RAW.glob('*.json')):
        data = json.loads(path.read_text())
        if 'declarations' not in data:
            continue
        modules[data['module']] = (data, path, hashlib.sha256(path.read_bytes()).hexdigest())
        if data['module'] != 'NativeLiteralApplications':
            for row in data['declarations']:
                declarations[row['name']] = row
    p = 'AutoSamplingTheory.TechnicalLemmas.Probability.MatrixBernsteinMgf.centered_bounded_matrix_mgf'
    candidates = [n for n in declarations if n.endswith('.actual_source_weighted_normalized_single_summand_mgf')]
    assert len(candidates) == 1
    t = candidates[0]
    result = []
    for target in [p, t]:
        emitter = declarations[target]['emitter']
        todo = deque([(target, [])])
        seen = set()
        parents = {}
        direct = []
        while todo:
            current, chain = todo.popleft()
            if current in seen:
                continue
            seen.add(current)
            row = declarations[current]
            data, path, digest = modules[row['emitter']]
            for field, root_key in [('type', 'type_root'), ('proof_value', 'value_root')]:
                root = row[root_key]
                if root is None:
                    continue
                for dependency, witness in references(data['expression_nodes'], root).items():
                    if dependency not in declarations or dependency == current:
                        continue
                    actual = declarations[dependency]
                    link = {'declaration': current, 'field': field, 'root_node': root, 'constant': dependency, 'constant_node': witness['node_path'][-1], 'node_path': witness['node_path'], 'edge_labels': witness['edge_labels'], 'raw_DAG_file': str(path.relative_to(OWN)), 'raw_DAG_sha256': digest}
                    if current == target:
                        direct.append({'constant': dependency, 'field': field, 'first_owner': actual['first_owner'], 'emitter': actual['emitter'], 'witness': link})
                    # The candidate P file has one authored public theorem; every
                    # other same-emitter declaration is private/compiler support,
                    # including public-shaped generated _abel theorem names.
                    local_support = actual['first_owner'] == emitter and actual['emitter'] == emitter
                    if local_support:
                        todo.append((dependency, chain + [link]))
                    elif actual['first_owner'].startswith('AutoSamplingTheory.'):
                        parent = parents.setdefault(dependency, {'parent': dependency, 'first_owner': actual['first_owner'], 'emitter': actual['emitter'], 'witnesses': []})
                        parent['witnesses'].append({'target_start_field': chain[0]['field'] if chain else field, 'same_module_private_or_generated_support_chain': chain + [link]})
        result.append({'target': target, 'root_emitter': emitter, 'same_module_support_walked': sorted(seen - {target}), 'direct_constants_in_actual_target_type_or_value': direct, 'canonical_public_ASTIS_parents': [parents[key] for key in sorted(parents)], 'imports_are_not_used_as_edge_evidence': True, 'walk_stops_at_first_external_public_ASTIS_parent': True})
    expected_p = {'AutoSamplingTheory.TechnicalLemmas.Probability.MatrixBernsteinExponential.bernstein_exponential_quadratic_bound', 'AutoSamplingTheory.TechnicalLemmas.Probability.RealMatrixPositiveIntegral.integral_posSemidef'}
    expected_t = {p, 'AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumSourceMatrixRadius.actual_source_truncated_matrix_norm_bounds', 'AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumSourceMatrixStructure.actual_source_centered_matrix_structure'}
    assert {row['parent'] for row in result[0]['canonical_public_ASTIS_parents']} == expected_p
    assert {row['parent'] for row in result[1]['canonical_public_ASTIS_parents']} == expected_t
    assert all(any(witness['target_start_field'] == 'proof_value' for witness in parent['witnesses']) for target in result for parent in target['canonical_public_ASTIS_parents'])
    report = {'schema': 'actual-kernel-checked-type-value-parent-node-witnesses-v1', 'candidate_commit': CANDIDATE, 'raw_kernel_summary_sha256': hashlib.sha256((RAW / 'native-kernel-summary.json').read_bytes()).hexdigest(), 'method': 'Offline constant-node traversal of structurally roundtripped complete kernel-checked type/value DAGs; same-module private/compiler supports expanded; first external public ASTIS theorem retained with exact node paths. Imports not used as theorem edges.', 'public_shaped_generated_abel_support_is_not_counted_as_canonical_parent': True, 'targets': result, 'weighted_T_materially_consumes_new_public_P': True, 'new_public_P_materially_consumes_existing_canonical_deterministic_exponential_bound': True, 'all_recorded_parents_have_actual_proof_value_witnesses': True}
    dest = OWN / 'actual-canonical-parent-witnesses.v1.json'
    dest.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({'report': str(dest), 'sha256': hashlib.sha256(dest.read_bytes()).hexdigest(), 'actual_canonical_parents': {row['target']: [x['parent'] for x in row['canonical_public_ASTIS_parents']] for row in result}}, indent=2))

if __name__ == '__main__':
    main()
