from pathlib import Path
import json, hashlib, shutil, subprocess, sys, datetime

R=Path.cwd(); W=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
C='65776f88e92b9680e6afe0d4c20b7390e4521241'
initial=json.loads((W/'initial-bindings.json').read_bytes())
final=json.loads((W/'final-context-results.json').read_bytes())
scan=json.loads((W/'input-locator-scan-results.json').read_bytes())
static=json.loads((W/'static-reader-results.json').read_bytes())
assert final['actual_head']==C and final['tracked_diff_from_candidate']==''
assert all(x['tracked_dirty_porcelain']=='' for x in final['dependencies'])

instructions=['AGENTS.md','docs/contributor-codex-contract.md','docs/theorem-publication-protocol.md',
              'docs/proof-digestion-protocol.md','docs/evidence-routed-memory-protocol.md',
              'docs/samplewiki-reader-navigation.md','.agents/skills/astis-substantive-advance/SKILL.md',
              '.agents/skills/astis-semantic-roundtrip/SKILL.md','.agents/skills/astis-source-dependency-audit/SKILL.md']
files=set(instructions+[x['path'] for x in initial['bindings']]+[x['file'] for x in scan['rows']])
files.update(['tools/astis.py','website/scripts/declaration_lessons.py','website/scripts/inline_lean.py',
              'tools/astis_site.py','website/scripts/source_lineage.py',
              '.astis/huanjian-gc-fixed-spectrum-detector-20261110/check_isolated_static_reader.py',
              '.astis/huanjian-gc-fixed-spectrum-detector-20261110/package_correspondence.py',
              '_site/textbook/index.html'])
inputs=[]
for raw in sorted(files):
    p=Path(raw); b=p.read_bytes(); target=W/'inputs'/raw
    target.parent.mkdir(parents=True,exist_ok=True); target.write_bytes(b)
    tracked=subprocess.run(['git','ls-files','--error-unmatch',raw],capture_output=True).returncode==0
    binding=None
    if tracked:
        gb=subprocess.check_output(['git','show',C+':'+raw]); assert gb==b,raw
        binding=C
    elif raw.startswith('.lake/packages/mathlib/'):
        gb=subprocess.check_output(['git','-C','.lake/packages/mathlib','show','HEAD:'+raw.removeprefix('.lake/packages/mathlib/')]); assert gb==b
        binding=next(d['head'] for d in final['dependencies'] if d['name']=='mathlib')
    inputs.append({'original_path':raw,'snapshot_relative_to_bundle':str(target.relative_to(W)),
                   'byte_length':len(b),'raw_sha256':sha(b),'pinned_git_commit':binding,
                   'role':('instructions' if raw in instructions else
                           'reused_old_theme_fixture_only' if raw=='_site/textbook/index.html' else
                           'referenced_formalizer_helper_code_no_verdict_credit' if raw.startswith('.astis/') else
                           'candidate_or_dependency_source')})

bootstrap={'scope':'Read-only instruction discovery and local receipt-runner bootstrap before run.py existed. These are not native/compiler verification receipts.',
           'note':'Original tool responses remain in the conversation. Instruction bytes are now copied losslessly with candidate binding; earlier instruction reads were not separately captured as command-log files at execution time. No pre-runner compiler/source/math verdict is claimed.',
           'observed_commands':[{'command':'pwd','exit_code':0},
             {'command':'cat AGENTS.md docs/contributor-codex-contract.md docs/theorem-publication-protocol.md docs/proof-digestion-protocol.md docs/evidence-routed-memory-protocol.md docs/samplewiki-reader-navigation.md','exit_code':0},
             {'command':'cat AGENTS.md','exit_code':0},
             {'command':'cat docs/contributor-codex-contract.md docs/theorem-publication-protocol.md','exit_code':0},
             {'command':"rg --files -g 'AGENTS.md' -g 'SKILL.md' .agents AutoSamplingTheory Tests website research-wiki | head -120",'exit_code':0},
             {'command':"sed -n '290,520p' AGENTS.md",'exit_code':0},
             {'command':'cat .agents/skills/astis-substantive-advance/SKILL.md .agents/skills/astis-semantic-roundtrip/SKILL.md .agents/skills/astis-source-dependency-audit/SKILL.md','exit_code':0},
             {'command':'cat docs/contributor-codex-contract.md','exit_code':0},
             {'command':'cat docs/proof-digestion-protocol.md','exit_code':0}],
           'head_at_first_explicit_git_capture':initial['actual_head'],
           'earlier_command_HEAD_not_independently_captured':True}
(W/'bootstrap-read-receipt.json').write_text(json.dumps(bootstrap,indent=2,ensure_ascii=False)+'\n')
exposure={'verifier_id':'detector_module_reader_72c9e4','role':'Independent native + whole-module and isolated static reader verification; not prover, source-blind decoder or source-facing semantic reviewer.',
          'parent_assignment':'Read scoped candidate P/Test, exact witness and 27-row map; perform focused native and static reader acceptance. No API/V/STAB, global root Tests, source edits, server/browser, git add/commit/push.',
          'source_semantic_review_independence':'No other independent source reviewer verdict was read or used; no parent/root success was accepted as my evidence.',
          'author_material_seen':['Complete P/Test code','author 27-row correspondence map and its 42-line packaging implementation','author ExpectedProducer/ExpectedPrivate literal witness code','author isolated static check helper code','lesson/publication source text and boundary prose'],
          'incidental_exposure':[{'receipt':'inspect-locator-provenance.receipt.json','description':'An rg search over author helper Python files also printed lines of record_proved_local.py, including author self-reported local status and publication/frontier update code. This was not executed, not adopted as independent evidence, and is preserved verbatim in that log.'}],
          'mechanical_read_scope':'The unmodified renderer obtains its source inventory with inline_lean.declarations/base.scan_project_sources, which reads the tracked production Lean corpus. Only the named candidate declaration and exact P/Test snippets were selected for this static result. No broad inventory was promoted to theorem acceptance.',
          'bootstrap':bootstrap,'input_snapshots':inputs,
          'external_context_not_archived':['The complete dependency .olean cache and Lean runtime/dylibs are reused in place. Toolchain executable hashes, manifest and nine exact dependency heads are recorded, but this bundle is not a hermetic archive of the runtime or all transitive source files.',
                                           'The pinned original arXiv source/topology review is assigned to the separate independent source lane. This report checks Lean/source-code and reader correspondence; it is not its semantic verdict.'],
          'prohibited_actions_taken':False}
(W/'input-exposure-manifest.json').write_text(json.dumps(exposure,indent=2,ensure_ascii=False)+'\n')

receipts=[]
for p in sorted(W.glob('*.receipt.json')):
    d=json.loads(p.read_bytes()); raw=(R/d['log']).read_bytes()
    assert sha(raw)==d['log_sha256'] and len(raw)==d['log_size']
    assert d['exit_code']==({'prepare-evidence':1}.get(d['label'],0))
    assert d['head_before']==d['head_after']==C
    receipts.append({'receipt':p.name,'argv':d['argv'],'exit_code':d['exit_code'],'head':C,
                     'log':str(Path(d['log']).relative_to(W.relative_to(R))),
                     'log_byte_length':len(raw),'log_raw_sha256':sha(raw)})
report={'schema':1,'verifier_id':'detector_module_reader_72c9e4','candidate_commit':C,
        'candidate_parent':'8c88749c51c87ce54c22e7910b366c0f9f3fba6d','actual_final_head':final['actual_head'],
        'verdict':'ACCEPTED_SCOPED_NATIVE_WHOLE_MODULE_AND_ISOLATED_STATIC_READER',
        'verdict_scope':'Two exact unchanged modules only, plus this candidate lesson/publication static rendering. No sourceV/STAB transition or whole-paper/Goal/global/site/browser/purification credit.',
        'native':{'lake_build_P':'exit 0; actual call, target REPLAYED/up-to-date; dependency artifacts reused',
                  'lake_build_Test':'exit 0; actual call, target up-to-date; dependency artifacts reused',
                  'fresh_P':'exit 0; direct lake env lean on original P source; own new output',
                  'fresh_Test':'exit 0; original Test source, own freshlib P first in explicit LEAN_PATH; own new output',
                  'kernel_checks':'Fresh own module-index inventory, direct root proof-body addDecl re-kernel checks and exact literal sealed-type applications; repeated on actual .lake build context. Existing witness also independently executed for cross-context inventory.',
                  'expected_type_provenance':'Expected literals transparently retained from pinned KernelExactTypesAndAllOwnedBounded.lean after independent code/signature reading. No prior success log/result was reused. Own checker adds proof-body re-kernel checks and module-index ownership rather than relying on name prefixes.',
                  'owned_declarations_count_each_context':2,'handwritten_count':2,'generated_owned_declarations':0,
                  'all_owned_reachable':True,'producer_ASTIS_parents':[],
                  'private_consumer_ASTIS_parents':['AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumDetector.actual_chebyshev_matrix_cosine'],
                  'recursive_axioms_each':['propext','Classical.choice','Quot.sound'],
                  'forbidden_closures':[],'Exprrepr_dumped':False,
                  'warning':'Unused hd in P is a source-range premise retained as sealed. Auxiliary expected-type definitions also trigger harmless unused premise warnings. Full warning text is kept in logs.'},
        'whole_module_review':{'P_bytes':4540,'P_sha256':'98d055da8ca5a10fe56874b19a58fb523511b9fc7c5ae13e20225e18340ed75a',
                               'Test_bytes':6044,'Test_sha256':'f7732afeb3cac55734dc2b05fd68e72f353d9bae6f2be2bbfa0bc499788cbe3d',
                               'all_27_exact_locators':True,'all_27_full_file_hashes':True,'all_27_pinned_git_source_bindings':True,
                               'input_certificates':'P has only d>=2,kappa>=2,O in the full real orthogonal group and n natural. Test adds only tau real. No event measurability, diagonalization, moment, covariance-law or probability estimate is supplied as a theorem hypothesis.',
                               'literal_definitions':'Grid, precision, affine normalized B, scalar reciprocal, covariance matrix inverse, forward rotation and strict S>0 event are local literal lets. Proof by_cases is algebraic entry calculation, not an object-level fallback.',
                               'consumer':'Test hT genuinely uses P; hR/hSc/hEvent derive rotation/event measurability; hundo and unitary norm preservation support hquad and hstat for every vector; map_apply consumes hR/hEvent and exact preimage equality. Equality is ENNReal event mass, without toReal.',
                               'purification_local':'Only the public identity and private concrete consumer exist in the two actual module inventories. Both are reachable roots; C reaches P. No unreachable helper, duplicate generic conjugation wrapper, separate private source credit or assumed theorem certificate was found. This is a bounded local audit, not global PURIFIED.'},
        'reader':static,
        'reader_formula_audit':['Step 1 is the canonical conjugation and nonzero scalar denominator derived from kappa>=2.',
                                'Step 2 explicitly normalizes the actual diagonal eigenvalues and transports the calculation through the same O.',
                                'Step 3 uses aeval naturality, diagonal algebra homomorphism, tuple evaluation and scalar first-kind cosine identity at the natural-to-integer index.',
                                'Step 4 produces continuity/Borelness from the fixed quadratic continuous linear form and norm square, independently of P.',
                                'Step 5 uses the actual producer and orthogonality to preserve both the quadratic statistic and Euclidean norm, including the zero vector.',
                                'Step 6 evaluates the exact pushed-forward diagonal Gaussian on the strict event; 0 remains excluded by positivity on both sides. It claims no pass probability or law recognition.'],
        'reader_assumptions_scope':'Lesson and publication assumption arrays and boundary strings are identical. Full O(d) with both determinant signs, all natural n including 0, all real tau, source n=2q+1/tau_dq specialization, scalar-vs-matrix inverse, all-vector transport and strict event are retained. mu.map R is explicitly not yet identified with pi_A.',
        'truth_boundary':'No pi_A identification, concentration/high-probability constant, Krylov/deferred-rotation/adaptive/Haar law, algorithm/oracle/TV/precision/query/cost adapter, full main lower bounds, original-source semantic verdict, normal sourceV/STAB, canonical site build, graph publication, browser desktop/mobile/pixel review, Exposition Seal, whole-Goal completion or global purification is certified here.',
        'failures_and_repairs':'No native/compiler/kernel/static assertion failed. Three preliminary whole-line locator hash probes printed mismatches because the map hashes exact marker-delimited substrings. The corrected explicit 27-marker checker passed without changing map/source. An out-of-range sed printed an empty output and was corrected by reading lines 1-115. First archive preparation exited 1 because it addressed tools/astis_site.py under website/scripts; original script and traceback are retained, then only this bookkeeping path was fixed. All these diagnostic logs remain verbatim. No mathematical source was repaired.',
        'runtime_and_dependencies':{'manifest_sha256':'b83ca83b9cf7caa85fa8b023c2ff9a3fb7a7cce7e1c332e810c348535ec49c37',
                                    'lean':'4.33.0 arm64-apple-darwin24.6.0; Lean commit d8b18978322de05a8f3dba51ef03cf5461676c17',
                                    'lean_binary_sha256':'1b370cfcbf44e80d1b004ab1b1ab9a4c73951f9f7c242140bcff9bc577576554',
                                    'nine_dependencies':final['dependencies'],'all_nine_tracked_clean':True,
                                    'native_cache_scope':'All transitive dependency compiled artifacts reused. Only P/Test and small checkers were freshly compiled here. No claim of fresh full-root or dependency rebuild.'},
        'commands_and_evidence':receipts,'input_exposure_manifest':'input-exposure-manifest.json',
        'noninterference':'Final tracked git diff from candidate is empty. This lane wrote only its assigned directory and normal Lake build outputs; no foreign untracked files modified, no staging, commit, push, API state transition or background process. Pre-existing foreign untracked status is retained verbatim in initial/final context.'}
(W/'independent-report.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')

text=f'''# Independent native, whole-module and static-reader report

Verifier: detector_module_reader_72c9e4. Verdict: **ACCEPTED within the exact scope below**.

Candidate and actual final HEAD: `{C}`. Parent: `8c88749c51c87ce54c22e7910b366c0f9f3fba6d`. P is the unchanged full 4540-byte `FixedSpectrumDetector.lean`, SHA-256 `98d055da8ca5a10fe56874b19a58fb523511b9fc7c5ae13e20225e18340ed75a`. Test is the unchanged full 6044-byte `GaussianComplexityFixedSpectrumDetector.lean`, SHA-256 `f7732afeb3cac55734dc2b05fd68e72f353d9bae6f2be2bbfa0bc499788cbe3d`. The working bytes equal `git show` bytes both initially and finally. All nine pinned dependency heads match the manifest and are tracked-clean; the manifest raw SHA-256 is `b83ca83b9cf7caa85fa8b023c2ff9a3fb7a7cce7e1c332e810c348535ec49c37`.

Actual focused Lake builds for P and Test both exited 0. P was explicitly REPLAYED and Test up-to-date; neither invocation is represented as fresh compilation. I separately compiled original P afresh, then original Test with my fresh P output placed first in explicit LEAN_PATH. I newly compiled my checker against this fresh context and against the actual Lake context. It enumerates declarations by owning module index, kernel-rechecks each actual root proof body, applies both roots to literal complete expected types, checks actual ASTIS parent reachability and recursively collects axioms. Both contexts contain exactly two owned declarations, both handwritten, zero extra generated declarations. P has no ASTIS parent; private C has exactly P. All owned declarations are reachable. Recursive axioms are only `propext`, `Classical.choice`, `Quot.sound`. Names/types/used-constant lists were bounded; no Exprrepr was dumped. The expected-type literals were transparently retained from the pinned witness after inspecting the actual signatures; I do not reuse its prior result as mine.

The public theorem retains only source-range d>=2, kappa>=2, a full real orthogonal O and arbitrary natural n. Test adds only arbitrary real tau. It genuinely consumes P, derives continuity and both measurability facts internally, preserves the norm and quadratic statistic for every vector including zero, and consumes these facts in map_apply. The final claim is exact ENNReal strict-event mass equality. No theorem-shaped diagonalization, event, moment, law-recognition or probability certificate has been moved into the hypotheses. The literal local definitions distinguish scalar reciprocal from covariance matrix inverse. There is no public wrapper, duplicate generic conjugation lemma, dead helper or separate source credit for the private Test. This local inventory review does not claim global purification.

All 27 correspondence rows passed full-file raw hashes, exact start/end positions, exact substring hashes and pinned Git-byte equality. The map hashes marker-delimited substrings; end_line records an end position rather than an inclusive whole-line range. Preliminary whole-line probes printed mismatches; these diagnostics and the corrected explicit-marker check remain verbatim. There was no mathematical source/map repair, compiler failure, kernel failure or static assertion failure. An empty out-of-range sed response and its corrected read are also preserved. The first archive-preparation run exited 1 on a wrong path for tools/astis_site.py; that traceback and the original script are retained, and only the bookkeeping path was corrected.

The unmodified renderer actually produced an isolated static lesson fragment and exact local Test source export. All six displayed formula steps have their own adjacent literal source snippets; step 6 includes the entire raw 6044-byte Test, and the exported source reconstructs the exact same bytes. The public statement and complete proof folds are extracted from real P source. All 17 details blocks are initially closed. Lesson/publication assumption arrays and boundary strings match. Full O(d), both determinant signs, every natural n including zero, every real tau, source specializations, strict positivity, all-vector transport and the two different inverses remain visible. The reader says mu.map R has not yet been identified with pi_A. The six mathematical steps correctly describe conjugation, scalar normalization, polynomial evaluation, independent Borelness, statistic transport and strict-event pushforward evaluation. The static fragment SHA-256 is `{static['literal_fragment_sha256']}`. The old `_site/textbook/index.html` is a recorded theme fixture only.

This verdict certifies the two exact unchanged Lean modules and the scoped isolated static reader correspondence. It certifies no pi_A law recognition, concentration/pass probability, adaptive/Haar/Krylov/algorithm/query/cost statement, complete main lower bound, independent original-source semantic review, sourceV/STAB transition, canonical site or graph build, browser/desktop/mobile/pixel review, Exposition Seal, whole-Goal completion or global PURIFIED status. No global root Tests were run. All transitive dependency oleans remain reused artifacts.

Every substantive native/static command, actual HEAD, exit code, full raw log hash and byte length is in its `.receipt.json` and `independent-report.json`. Input snapshots and provenance/exposure are in `input-exposure-manifest.json`. Read-only instruction discovery preceded the receipt runner; its original tool outputs remain in the conversation and `bootstrap-read-receipt.json` states this recording boundary without inventing an earlier HEAD/timestamp. A helper-code search incidentally exposed author's self-reported local status/update code; it was never executed or treated as independent success evidence. No other independent source reviewer's verdict was read or used. The renderer mechanically reads the tracked Lean inventory; only the selected P/Test content receives this static result.

Final tracked diff from the candidate is empty. Only this assigned directory and standard Lake outputs were written. No source edit, foreign-untracked edit, API/V/STAB, staging, commit, push, background ASTIS or browser/server action occurred. Lossless carry items and in-place native cache exclusions will be enumerated by the freeze manifest. Complete runtime/dylibs, transitive dependency caches and unrelated source corpus are not a hermetic archive; the exact executable, manifest, dependency heads and reused/fresh boundary remain explicit.
'''
(W/'independent-report.md').write_text(text)
print(json.dumps({'input_snapshots':len(inputs),'substantive_command_receipts':len(receipts),'report_json_sha256':sha((W/'independent-report.json').read_bytes()),'report_md_sha256':sha((W/'independent-report.md').read_bytes()),'candidate':C,'tracked_diff_empty':True,'scope':report['verdict_scope']},indent=2))
