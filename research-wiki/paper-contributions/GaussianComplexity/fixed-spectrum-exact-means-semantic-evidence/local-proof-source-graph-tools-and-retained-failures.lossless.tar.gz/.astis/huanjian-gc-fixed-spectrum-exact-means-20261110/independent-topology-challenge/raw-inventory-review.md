# Raw machine-inventory check — PASS within declared unit rule

Only the exact phase1 freeze, machine inventory and pinned source were read for this stage. The freeze hash is `c447aab6715d9f316bb3d34a1754df15c8078a3da743def7d79a2047639f7a78`; the 27087-byte inventory hash is `c943d19d11a03478a6da3e3916c1b3f0288f9361b11cf239c665a5a791c75575`. No private extractor cognition, rationale or script was opened.

An independent source walk over S4.SS1.p1.1, S4.E11, S4.Thmtheorem5 and full A3.SS3 reproduced all **72 unique units** under the stated paragraph/theorem/display/citation rule: 31 paragraphs, 37 displays, three theorem statements and one citation. Scope, tag/class, ID, original line bounds, source text and ordered link targets match exactly after whitespace normalization. Missing, extra and mismatched units: **0**.

All 103 unique MathML formulas in those roots occur in the preserved unit text. All three unique link occurrences inside mathematical units are retained. Two additional links are only structural headings pointing to Lemma 4.5 (lines 3838 and 4008), outside the declared unit rule; they do not carry an omitted mathematical premise. This is bounded inventory completeness, not a whole-paper assertion or final disposition approval.

The inventory includes the 16 identified TBODY display rows separately from their grouped table containers, including Ex141–143, Ex145–147 and Ex148–149. Thus the closed-mean steps are not lost under aligned-table wrappers; their later individual graph dispositions still require review.

Raw p8.2 explicitly derives M≤d/√κ from the exact M formula. Adjacent Ex148–149 are variance displays and must not become its proof parents. Raw p9.1 and Ex150 consume both actual means plus radius/sign/denominator facts; Ex151 and p10–p11 remain outside the private exact-ratio target. These boundaries are source observations, not yet approval of extractor edges.

The actual Gaussian versus deterministic-sum distinction, full weighted class partition/disjointness/parity, convergent reindexing and geometric normalization are reserved for phase2 graph/root-closure review. The exact seal ACCEPT and earlier raw freeze remain unchanged. No proof/API, build, ledger, shared mutation or source V occurred.
