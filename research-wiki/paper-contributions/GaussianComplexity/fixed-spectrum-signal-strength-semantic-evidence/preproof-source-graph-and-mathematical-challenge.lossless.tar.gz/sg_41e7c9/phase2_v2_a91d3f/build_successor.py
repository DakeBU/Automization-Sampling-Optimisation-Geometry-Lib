from pathlib import Path
from datetime import datetime, timezone
from collections import Counter
from copy import deepcopy
import hashlib
import json

BASE=Path(__file__).resolve().parent
P1=BASE.parent
OLD=P1/'phase2_c34b8a'
ROOT=P1.parents[2]
CHALLENGE=ROOT/'.astis/semantic-neutral-20261110/tc_b903a7/phase2b-independent-graph-judgment.md'
sha=lambda b:hashlib.sha256(b).hexdigest()
def write(name,x):
    (BASE/name).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def oldread(name): return json.loads((OLD/name).read_text())
challenge_bytes=CHALLENGE.read_bytes()
assert sha(challenge_bytes)=='d3eff5947e4b01cf24258cba849dd6c04b3b828a1a9ac3b0dabe00b910e2e28c'
assert sha((OLD/'phase2_freeze.json').read_bytes())=='956452028bad9e1892f1af17bd20f68b59adea53302f8c4f56cd19e527f6deeb'
assert sha((P1/'phase1_freeze.json').read_bytes())=='69372fb70615bbc7cc6ddc0fe9a6baa96177126d2eb67647882d19626ca67509'
f1=json.loads((P1/'phase1_freeze.json').read_text())
f2=oldread('phase2_freeze.json')
for directory,manifest in [(P1,f1),(OLD,f2)]:
    for r in manifest['files']:
        b=(directory/r['path']).read_bytes()
        assert sha(b)==r['sha256'] and len(b)==r['bytes']
projection_bytes=(OLD/'sealed_projection.exact.json').read_bytes()
assert sha(projection_bytes)=='e8322849cd533289522de2de96ae5913364b1446dee114d4224956c1ced02fca'
(BASE/'sealed_projection.exact.json').write_bytes(projection_bytes)
(BASE/'authorized_challenge.exact.md').write_bytes(challenge_bytes)

original_graph=oldread('source_graph.json')
original_coverage=oldread('source_unit_dispositions.json')
original_roots=oldread('root_closures.json')
original_audit=oldread('conditional_discharge_audit.json')
g=deepcopy(original_graph)
c=deepcopy(original_coverage)
a=deepcopy(original_audit)
nodes={n['id']:n for n in g['nodes']}
edges={e['id']:e for e in g['hyperedges']}

# H1: source mathematics has arbitrary integer frequency; the selected public
# interface is a downstream odd-frequency coordinate/integral specialization.
generic_cos=dict(id='s:generic-cosine-statistic',kind='generic-source-definition',
    source_anchors=['S4.Thmtheorem5.p1'],
    statement='For an arbitrary integer n with 1<=n<d, D_n=diag(cos(n theta_i)) and the source quadratic is U transpose D_n U. No query q or n=2q+1 restriction is part of this generic source definition.',
    frequency_scope='arbitrary integer 1<=n<d',evidence='raw-pinned-source-only')
generic_law=dict(id='s:generic-moment-law',kind='generic-source-law-and-mean-semantics',
    source_anchors=['S4.Thmtheorem5.p1','A3.SS3.p4','A3.SS3.p8'],
    statement='For the grid with d>=2,kappa>=2 and arbitrary integer 1<=n<d, the actual source law is U~N(0,Lambda inverse), M=E||U||², and mu_n=E[U transpose D_n U]. Lambda is the positive diagonal precision; its inverse is covariance. Fin/Bochner syntax and the selected query-frequency choice are not author-source prerequisites.',
    frequency_scope='arbitrary integer 1<=n<d; M itself is independent of n',
    meaning_scope='original-paper Euclidean Gaussian law and expectations, not a project interface adapter',
    evidence='raw-pinned-source-only')
g['nodes'].extend([generic_cos,generic_law])
nodes[generic_cos['id']]=generic_cos
nodes[generic_law['id']]=generic_law
g['hyperedges'].extend([
 dict(id='e:generic-cosine-definition',parents=['s:grid'],child='s:generic-cosine-statistic',
      logic='AND',kind='AND-source-definition-input',dependency=True,
      consumer_use_sites=['S4.Thmtheorem5.p1'],
      use='The author defines the cosine diagonal for general integer 1<=n<d, separately from the earlier query-frequency choice.',
      conditional_discharge=['Source frequency range is the explicit local parameter domain; it is not derived from a query specialization.']),
 dict(id='e:generic-law-semantics',parents=['s:grid','s:target-oracle','s:generic-cosine-statistic','gap:gaussian-semantics'],child='s:generic-moment-law',
      logic='AND',kind='AND-source-definition-input',dependency=True,
      consumer_use_sites=['S4.Thmtheorem5.p1','A3.SS3.p4','A3.SS3.p8'],
      use='Positive diagonal precision gives the actual original-paper Gaussian covariance/expectation semantics for arbitrary source frequency. Standard Gaussian foundational input remains named; no Fin or odd-frequency adapter is used.',
      conditional_discharge=['d>=2,kappa>=2 and integer 1<=n<d are the explicit generic source domain; standard moment/integrability input remains gap:gaussian-semantics.'])
])
edges={e['id']:e for e in g['hyperedges']}
edges['e:literal-law'].update(
    parents=['s:generic-moment-law','s:cosine-statistic','s:moment-normalization','a:domain'],
    kind='AND-downstream-literal-interface-specialization',
    use='Only after the generic author-source semantics: select n=2q+1 on the discharged scalar domain, reindex source coordinates by i_source=i.val+1, and identify the sealed Fin/Bochner actual law, Q,M,b,beta. This adapter is not a prerequisite of C.8 or the source variance proof.',
    conditional_discharge=['The source generic integer-frequency range is supplied to this selected instance by a:domain; the selected signature and definition bodies are unchanged.'])
nodes['a:literal-law'].update(
    statement='Downstream sealed-interface specialization of s:generic-moment-law: n=2q+1 on a:domain; Fin d reindexing i_source=i.val+1; covariance Lambda inverse; Q, Bochner means M,b and beta have exactly the source actual-law meanings. The generic author proof never depends on this adapter.',
    frequency_scope='selected odd-frequency instance n=2q+1 only',
    provenance_direction='generic source semantics -> selected literal-interface adapter')
for edge_id in ['e:trace','e:variance','e:rotation']:
    edges[edge_id]['parents']=['s:generic-moment-law' if x=='a:literal-law' else x for x in edges[edge_id]['parents']]
edges['e:trace']['use']='Original-paper general-frequency Gaussian second moments identify the finite sums, and C.7 absolute convergence permits interchange. The author step has no Fin/Bochner or query-frequency prerequisite.'
edges['e:variance']['use']='Original-paper general-frequency diagonal-Gaussian independence/fourth moments, lambda>=1 and cos²<=1; exact M formula bounds M. No selected interface or odd-frequency premise is used.'
edges['e:rotation']['use']='Original-paper orthogonal transport between a rotated target and the generic diagonal Gaussian; same norm and generic cosine quadratic. This precedes any selected-interface specialization.'
generic_ids=['s:lemma45-means-variance','s:lemma45-bias','c:c8','c:trace-means','c:mean-M','c:mean-b','c:variance','c:ratio','c:bias-upper','c:bias']
for n in generic_ids:
    nodes[n]['frequency_scope']='generic source integer 1<=n<d; not restricted to n=2q+1'
nodes['s:lemma45-means-variance']['statement']='For d>=2,kappa>=2 and any integer 1<=n<d, actual U~N(0,Lambda inverse) has the exact M and signed mu_n means and both variances<=2M<=2d/sqrt(kappa); no query-frequency restriction.'
nodes['s:lemma45-bias']['statement']='For the same generic integer frequency domain, if d-n>=sqrt(kappa), (1-exp(-4))exp(-3n/sqrt(kappa))<=abs(mu_n)/M<=exp(-2n/sqrt(kappa)); no query-frequency restriction.'
nodes['c:c8']['statement']='Exact finite-grid M and signed mu_n formulas for every integer 1<=n<d, independent of whether n can be written as 2q+1.'

# H2: separate the affine relation from the conditional explanatory forecast.
nodes['s:kappa2-comparison']['statement']='Affine kappa=2 comparison only: the same-rotation family obeys A=(kappa-1)A_2-(kappa-2)I, and one matrix-vector reply determines the other. The conditional signal forecast is represented separately by s:kappa2-preview.'
preview=dict(id='s:kappa2-preview',kind='conditional-explanatory-preview',
    source_anchors=['S4.Thmtheorem2'],evidence='raw-pinned-source-only',
    statement='Remark4.2 forecasts the algorithm/target cosine contrast under the eventual small-query regime. It is not an unconditional implication from Lemmas4.4/4.5 for arbitrary q.',
    retained_conditions=['integer q>=0 and n=2q+1<d','independent Gaussian starts and actual output Krylov representation of Lemma4.3',
       'tau small with tau<=1/2 for the simultaneous Lemma4.4 estimate','d-n>=sqrt(kappa) for the lower normalized bias',
       'the fixed-delta source range and eventual query cap when asserting d^{-Omega(1)} versus the target exponential bias'],
    evidence_type='explanatory forecast with conditions retained, not a theorem implication')
g['nodes'].append(preview)
nodes[preview['id']]=preview
edges['e:kappa2']['use']='Only the affine kappa=2 matrix identity and corresponding exact reply simulation are concluded here; the signal forecast is a separate conditional explanatory node.'
edges['e:kappa2-preview'].update(child='s:kappa2-preview',dependency=False,logic='non-implicational',
    kind='conditional-explanatory-preview-not-implication',
    use='The source remark refers forward to the two lemmas as an explanatory forecast. Their quantitative contrast is asserted only with the retained small-query/domain/event conditions; this edge grants no unconditional consequence for arbitrary q.',
    conditional_discharge=[
       'RETAINED, not discharged at this preview: q natural,n=2q+1<d; Lemma4.3 output representation with independent Gaussian starts.',
       'RETAINED: tau sufficiently small and tau<=1/2 for Lemma4.4, and d-n>=sqrt(kappa) for the lower-bias part of Lemma4.5.',
       'The eventual theorem route discharges these in s:algorithm-test, s:distance-domain and s:common-source-threshold; the preview is not itself a proof of that regime.'])

# Raw-unit dispositions remain exhaustive over the identical809-unit inventory.
for x in c['units']:
    if x['disposition']=='NODE' and x.get('mapping_region')=='S4.Thmtheorem2':
        x['node_ids'].append('s:kappa2-preview')
        x['reason']='The exact raw remark region contains the affine comparison and a distinct conditional explanatory preview; both components are represented without an unconditional lemma-to-preview implication.'
    if x['unit']=='A3.SS3:raw:0043':
        assert x['source_id']=='A3.SS3.p2.3' and x['node_ids']==['c:majorant']
        x['node_ids']=['c:c7','c:majorant']
        x['reason']='The source paragraph first combines the identities to prove the expansion and then says Finally before the majorant. Both source components are associated; the original raw bytes are unchanged.'
    if x['disposition']=='NODE' and x['source_id'] in {'S4.Thmtheorem5.p1','S4.Thmtheorem5.p1.1'}:
        x['node_ids'].extend(['s:generic-cosine-statistic','s:generic-moment-law'])
        x['reason']='The generic source statement introduces arbitrary integer n, D_n, actual diagonal Gaussian law and means; its generic semantics precede the selected Fin/Bochner specialization.'

# The prior whole-slice HOLD is preserved as history; no repaired coverage is
# self-approved by this extractor.
history=dict(challenge_path=str(CHALLENGE.relative_to(ROOT)),challenge_sha256=sha(challenge_bytes),
    original_whole_slice_topology_judgment='HOLD for H1 general-frequency/adapter scope and H2 conditional preview; selected root topology was not refuted.',
    repair_state='CORRECTIONS_PROPOSED_PENDING_SAME_DISTINCT_CHALLENGER',
    old_artifacts_preserved=True,source_statement_changed=False,sealed_projection_changed=False)
g['successor_version']=2
g['predecessor_graph_sha256']=sha((OLD/'source_graph.json').read_bytes())
g['authorized_challenge_and_hold_history']=history
g['important_separation']='Generic author-source law/cosine/moment semantics are upstream of C.8 and variance. The selected Fin/Bochner odd-frequency adapter is downstream. The conditional remark forecast is non-implicational. Private zero-event adaptation remains distinct from Ex26/shifted detector and from the source Anchor.'
c['successor_version']=2
c['predecessor_coverage_sha256']=sha((OLD/'source_unit_dispositions.json').read_bytes())
c['authorized_challenge_and_hold_history']=history
c['mathematical_coverage_judgment']='CORRECTED_EXTRACTOR_PROPOSAL_ONLY; requires same distinct challenger, not self-approved'

for x in a['entries']:
    if x['id']=='CD03':
        x['discharge']='The generic author C.8/Lemma4.5 keeps arbitrary integer 1<=n<d as its own explicit source domain. Separately, the selected instance has q natural,n=2q+1>=1 and cast n=2*(q:real)+1; CD02 gives n<d. The downstream adapter instantiates the general source domain and is not a premise of its proof.'
    if x['id']=='CD05':
        x['discharge']='Generic source semantics first: cosine range and kappa>=2 give 1<=lambda_i<=kappa; Lambda inverse is the positive diagonal covariance of the actual original-paper U, with general integer 1<=n<d. Standard independence, covariance, second/fourth moments and polynomial integrability are gap:gaussian-semantics. Only downstream does a:literal-law select n=2q+1 and identify the unchanged Fin/Bochner interface. No selected adapter is an input to C.8 or the generic variance proof.'
a['entries'].extend([
 dict(id='CD20',premise='H1: author C.8 and Lemma4.5 retain arbitrary integer-frequency source semantics independently of a selected odd-frequency interface.',
      consumer_use_sites=['S4.Thmtheorem5.p1','A3.SS3.p4','A3.SS3.p8'],
      resolution='SOURCE_GENERALITY_RETAINED_ADAPTER_MOVED_DOWNSTREAM_PENDING_REVIEW',
      discharge='s:generic-cosine-statistic and s:generic-moment-law have no q/Fin/Bochner prerequisite. e:trace and e:variance now consume that generic source semantics; e:rotation also remains source-generic. The selected a:literal-law consumes generic semantics plus the discharged n=2q+1 instance and normalization. Generic C.8 and both Lemma4.5 component closures are mechanically checked to exclude the selected adapter and query-frequency regime.',
      source_gap_ids=['gap:gaussian-semantics']),
 dict(id='CD21',premise='H2: Remark4.2 signal forecast must not be an unconditional consequence at arbitrary q.',
      consumer_use_sites=['S4.Thmtheorem2'],
      resolution='CONDITIONS_EXPLICITLY_RETAINED_NON_IMPLICATION_PENDING_REVIEW',
      discharge='The affine comparison and conditional forecast are separate source nodes. e:kappa2-preview is non-implicational and retains n=2q+1<d, independent-start Krylov representation, small tau/tau<=1/2, d-n>=sqrt(kappa), and the eventual fixed-delta small-query regime. It identifies where the theorem route later discharges these conditions and does not assert their discharge at the forecast itself.',
      source_gap_ids=['gap:C1','gap:C2'])])
a['successor_version']=2
a['predecessor_conditional_audit_sha256']=sha((OLD/'conditional_discharge_audit.json').read_bytes())
a['authorized_challenge_and_hold_history']=history
a['coverage_approval']='PENDING_SAME_DISTINCT_CHALLENGER; extractor cannot self-approve'

def closure(root):
    seen=set(); chosen=set(); todo=[root]
    while todo:
        n=todo.pop()
        if n in seen: continue
        seen.add(n)
        for e in g['hyperedges']:
            if e['dependency'] and e['child']==n:
                chosen.add(e['id']);todo.extend(e['parents'])
    leafs=sorted(n for n in seen if not any(e['dependency'] and e['child']==n for e in g['hyperedges']))
    return dict(root=root,node_ids=sorted(seen),edge_ids=sorted(chosen),leaf_ids=leafs,
      source_gap_ids=sorted(n for n in seen if n.startswith('gap:')),
      outside_closure=[dict(node_id=n['id'],reason='Source context or a different downstream branch; no dependency path into this exact root. Its raw units remain covered.') for n in g['nodes'] if n['id'] not in seen],
      closure_semantics='Backward closure follows only dependency=true AND proof/definition/adaptation hyperedges. Attribution/comparison/conditional explanatory previews and shared source-position alone do not create dependencies.',
      formal_closure_status='NOT_CLAIMED; implementation/API not inspected',independent_coverage_approval='PENDING_SAME_DISTINCT_CHALLENGER')
roots=[closure('root:public-signal'),closure('root:private-zero-event')]
for x in c['units']:
    if x['disposition']=='NODE':
        x['root_membership']=[r['root'] for r in roots if set(x['node_ids'])&set(r['node_ids'])]
root_artifact=dict(roots=roots,successor_version=2,
    predecessor_closures_sha256=sha((OLD/'root_closures.json').read_bytes()),
    authorized_challenge_and_hold_history=history)
write('source_graph.json',g)
write('source_unit_dispositions.json',c)
write('root_closures.json',root_artifact)
write('generic_source_boundary_closures.json',dict(
    roots=[closure(r) for r in ['c:c8','c:variance','s:lemma45-means-variance','s:lemma45-bias']],
    purpose='H1 source-generality witness: backward author-source closures retain arbitrary integer 1<=n<d and must exclude all selected interface/query-regime nodes. This is structural evidence, not independent coverage approval.',
    forbidden_selected_prerequisites=['a:literal-law','a:domain','s:cosine-statistic','s:scalar-regime','s:moment-normalization'],
    independent_review='PENDING_SAME_DISTINCT_CHALLENGER'))
write('conditional_discharge_audit.json',a)

# Lossless recursive exact-field differences, preserving the old JSON alongside
# the successor rather than replacing any prior evidence.
def diff(old,new,path=''):
    out=[]
    if type(old)!=type(new): return [dict(path=path,operation='replace',before=old,after=new)]
    if isinstance(old,dict):
        for k in sorted(set(old)|set(new)):
            q=path+'/'+k.replace('~','~0').replace('/','~1')
            if k not in old: out.append(dict(path=q,operation='add',after=new[k]))
            elif k not in new: out.append(dict(path=q,operation='remove',before=old[k]))
            else: out.extend(diff(old[k],new[k],q))
    elif isinstance(old,list):
        for i in range(min(len(old),len(new))): out.extend(diff(old[i],new[i],path+'/'+str(i)))
        for i in range(len(old),len(new)): out.append(dict(path=path+'/'+str(i),operation='add',after=new[i]))
        for i in range(len(new),len(old)): out.append(dict(path=path+'/'+str(i),operation='remove',before=old[i]))
    elif old!=new: out.append(dict(path=path,operation='replace',before=old,after=new))
    return out
pairings=[('source_graph.json',original_graph,g),('source_unit_dispositions.json',original_coverage,c),
          ('root_closures.json',original_roots,root_artifact),('conditional_discharge_audit.json',original_audit,a)]
write('exact_field_diff.json',dict(schema='exact-json-field-diff-v1',
    predecessor_directory='../phase2_c34b8a',files=[dict(path=name,before_sha256=sha((OLD/name).read_bytes()),after_sha256=sha((BASE/name).read_bytes()),changes=diff(before,after)) for name,before,after in pairings]))
closure_changes=[]
for before,after in zip(original_roots['roots'],roots):
    closure_changes.append(dict(root=after['root'],
        before_nodes=len(before['node_ids']),after_nodes=len(after['node_ids']),
        added_nodes=sorted(set(after['node_ids'])-set(before['node_ids'])),removed_nodes=sorted(set(before['node_ids'])-set(after['node_ids'])),
        before_edges=len(before['edge_ids']),after_edges=len(after['edge_ids']),
        added_edges=sorted(set(after['edge_ids'])-set(before['edge_ids'])),removed_edges=sorted(set(before['edge_ids'])-set(after['edge_ids'])),
        gaps_before=before['source_gap_ids'],gaps_after=after['source_gap_ids'],
        interpretation='Two generic author-source semantic nodes and their edges are now upstream; the selected adapter remains downstream. No new mathematical lemma or formal discharge is claimed.'))
write('repair_scope_and_provenance.json',dict(schema='append-only-source-graph-repair-v2',
    authorized_challenge_and_hold_history=history,
    source_cognition_basis='Unchanged independently frozen phase1 original-source reading; the actual distinct challenge is newly authorized repair input.',
    original_phase1_freeze_sha256='69372fb70615bbc7cc6ddc0fe9a6baa96177126d2eb67647882d19626ca67509',
    original_phase2_freeze_sha256='956452028bad9e1892f1af17bd20f68b59adea53302f8c4f56cd19e527f6deeb',
    parent_reported_challenge_manifest_sha256='304a90c3bba0ac5e8892b1cc62b84834e980e784c62589af76d51e17d2c0b8de',
    challenge_manifest_read=False,
    exact_signature_hashes_unchanged={k:json.loads(projection_bytes)[k]['signature_sha256'] for k in ['producer','actual_private_consumer']},
    changes=[
      'H1: explicit generic integer-frequency source law/cosine/mean nodes replace the selected literal adapter as inputs of C.8, variance, and generic target rotation. The unchanged selected Fin/Bochner adapter is downstream.',
      'H2: affine kappa=2 reply comparison is separated from a conditional, non-implicational explanatory preview; all real domain/event/query conditions are retained.',
      'Minor raw mapping: A3.SS3:raw:0043 is associated with both c:c7 and c:majorant, matching its two sentences.'],
    closure_changes=closure_changes,
    raw_inventory_sha256=sha((P1/'raw_unit_inventory.json').read_bytes()),
    raw_units=809,dispositions=dict(Counter(x['disposition'] for x in c['units'])),
    independent_coverage_approval='PENDING_SAME_DISTINCT_CHALLENGER; no extractor self-approval',
    source_statement_HOLD=False,
    historical_whole_slice_topology_HOLD_preserved=True,
    new_mathematical_proof_or_source_correction=False,
    implementation_Lean_API_proof_search_exposure=False,
    root_implementation_or_route_expectation_exposure=False,
    unrelated_prior_verdict_exposure=False,
    authorized_new_evidence_only='Exact distinct challenge, old own immutable graph/coverage/conditional/closure artifacts, and unchanged original raw-unit inventory. No other reviewer artifacts or source bodies were opened.',
    all_prior_payloads_rehashed_unchanged=dict(phase1=len(f1['files']),phase2=len(f2['files'])),
    unresolved_gap_change='No selected-root SOURCE_GAP added, removed, or discharged. They remain standard-input obligations, not evidence of source invalidity.'))
print(json.dumps(dict(nodes=len(g['nodes']),edges=len(g['hyperedges']),dispositions=dict(Counter(x['disposition'] for x in c['units'])),closure_changes=closure_changes),indent=2))
