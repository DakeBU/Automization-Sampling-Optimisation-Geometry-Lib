import json,os
from run import ROOT,run
m=json.loads((ROOT/'input-manifest.json').read_text());env=dict(os.environ);env['LEAN_PATH']=os.pathsep.join(m['lean_path'])
r=run('native-environment-inspection',[m['lean_binary']['path'],'-R',str(ROOT/'scratch'),str(ROOT/'scratch/InspectNative.lean')],cwd=ROOT/'scratch',env=env)
assert r.returncode==0
