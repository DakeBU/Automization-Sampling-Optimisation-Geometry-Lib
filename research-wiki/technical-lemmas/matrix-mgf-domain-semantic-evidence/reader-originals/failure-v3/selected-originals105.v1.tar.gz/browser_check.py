"""R17 isolated-reader checker. Preparation only until a separate ROOT execution assignment exists."""
import argparse
import datetime as dt
from functools import partial
import hashlib
from http.server import SimpleHTTPRequestHandler,ThreadingHTTPServer
import json
import os
from pathlib import Path
import re
import sys
import tempfile
import threading
import time
import traceback
from urllib.parse import urljoin,quote
from browser_geometry import GEOMETRY,VISIBLE,GLYPH,scroll_center,zoom_pan_actual_ui,core_label_readable

OWN=Path(__file__).resolve().parent
REPO=OWN.parents[2]
ITEM='huanjian-matrix-mgf-domain'
PFILE='AutoSamplingTheory/TechnicalLemmas/Probability/RealMatrixPositiveDefIntegral.lean'
TFILE='Tests/GaussianComplexityMatrixMgfDomain.lean'
P='AutoSamplingTheory.TechnicalLemmas.Probability.RealMatrixPositiveDefIntegral.integral_posDef'
T='AutoSamplingTheory.Tests.GaussianComplexityMatrixMgfDomain.actual_source_four_matrix_mgfs_integrable_posDef_and_trace_bounded'
PSD='AutoSamplingTheory.TechnicalLemmas.Probability.RealMatrixPositiveIntegral.integral_posSemidef'
TRACE='AutoSamplingTheory.TechnicalLemmas.Analysis.MatrixTraceExponentialBounds.trace_exp_pos_and_le_card_mul_exp_abs_mul_norm'
SOURCES=[('P',PFILE,P,17,50),('T',TFILE,T,18,212),
 ('PSD','AutoSamplingTheory/TechnicalLemmas/Probability/RealMatrixPositiveIntegral.lean',PSD,18,44),
 ('TRACE','AutoSamplingTheory/TechnicalLemmas/Analysis/MatrixTraceExponentialBounds.lean',TRACE,18,60),
 ('Radius','AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumSourceMatrixRadius.lean','AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumSourceMatrixRadius.actual_source_truncated_matrix_norm_bounds',101,226),
 ('Structure','AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumSourceMatrixStructure.lean','AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumSourceMatrixStructure.actual_source_centered_matrix_structure',13,148)]

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,d):Path(p).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')

def open_reading_disclosures(root):
    for detail in root.locator('details').all():
        if not detail.evaluate('(e)=>e.open'):
            summary=detail.locator(':scope>summary');scroll_center(summary);summary.click()

class QuietHandler(SimpleHTTPRequestHandler):
    def log_message(self,*_):pass

def parse():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--preview-root',type=Path,required=True)
    parser.add_argument('--assignment',type=Path,default=OWN/'execution-assignment.json')
    return parser.parse_args()

def main(args,a):
    preview=args.preview_root.resolve();manifest_path=preview/'preview-freeze-manifest.json'
    assert preview==Path(a['preview_root']).resolve()
    assert sha(__file__)==a['runner_sha256'] and sha(OWN/'browser_geometry.py')==a['geometry_sha256']
    assert sha(manifest_path)==a['preview_manifest_sha256']
    assert re.fullmatch('[0-9a-f]{64}',a['source_reviewed_publication_binding_sha256'])
    for row in a['frozen_inputs']:assert sha(row['path'])==row['sha256']
    manifest=json.loads(manifest_path.read_text());assert manifest['proof_commit']=='a8bb8ea5b4474be5214bd83ae380a612e2cecb78'
    assert manifest['lesson_sha256']==a['lesson_sha256'] and manifest['publication_sha256']==a['publication_sha256']
    selected=manifest['variants']['candidate'];fixture=preview/'fixtures/candidate';snapshot=preview/'input-snapshot'
    assert len(selected['files'])==110
    fixture_paths=lambda:{str(p.relative_to(fixture)) for p in fixture.rglob('*') if p.is_file()}
    assert fixture_paths()=={row['path'] for row in selected['files']}
    for row in selected['files']:assert sha(fixture/row['path'])==row['sha256']
    unit=json.loads((snapshot/'website/content/declaration_lessons'/f'{ITEM}.json').read_text())['units'][0]
    assert len(unit['steps'])==5
    assert [s['lean_source_path'] for s in unit['steps']]==[PFILE]*2+[TFILE]*3
    assert [s['lean_source']['LF_lines_1based'] for s in unit['steps']]==[[1,28],[29,50],[1,137],[138,186],[187,212]]
    for label,raw,name,anchor,lines in SOURCES:
        exact=(snapshot/raw).read_bytes();assert len(exact.decode().splitlines())==lines
        if label=='P':assert hashlib.sha256(exact).hexdigest()=='d3c6e5a194fecf1ae1abe45c70310f4f47d66e903b098019c326ee0d3018b024'
        if label=='T':assert hashlib.sha256(exact).hexdigest()=='60e9f7b928ebc1b8a0d9efad93f39f1b172fe0a871893d67eb1015582c5d5c61'
    chrome=Path(a['chrome']['path']);assert sha(chrome)==a['chrome']['binary_sha256']
    output=OWN/'runtime-output';output.mkdir(exist_ok=False)
    tmp=OWN/'chrome-tmp';tmp.mkdir(exist_ok=True,mode=0o700);os.chmod(tmp,0o700);os.environ['TMPDIR']=str(tmp);tempfile.tempdir=str(tmp)
    checks=[];screenshots=[];requests=[];responses=[];console=[];errors=[];blocked=[]
    def check(name,ok,detail=None):checks.append({'name':name,'pass':bool(ok),'detail':detail})
    def shot(page,name,full=False):
        path=output/(name+'.png');page.screenshot(path=str(path),full_page=full)
        screenshots.append({'path':str(path.relative_to(OWN)),'sha256':sha(path)})
    server=ThreadingHTTPServer(('127.0.0.1',0),partial(QuietHandler,directory=str(fixture)))
    worker=threading.Thread(target=server.serve_forever,daemon=True);worker.start()
    origin='http://127.0.0.1:'+str(server.server_port);started=False;version=None
    try:
        from playwright.sync_api import sync_playwright
        with sync_playwright() as playwright:
            browser=playwright.chromium.launch(executable_path=str(chrome),headless=True);started=True;version=browser.version
            for label,width,height in [('desktop',1440,1000),('mobile',390,844)]:
                context=browser.new_context(permissions=['clipboard-read','clipboard-write'],viewport={'width':width,'height':height},device_scale_factor=1,accept_downloads=True)
                def route(route):
                    url=route.request.url
                    if url.startswith(origin+'/') or url.startswith(('data:','blob:')):route.continue_()
                    else:blocked.append(url);route.abort()
                context.route('**/*',route);page=context.new_page()
                page.on('request',lambda r:requests.append({'url':r.url,'method':r.method,'resource_type':r.resource_type}))
                page.on('response',lambda r:responses.append({'url':r.url,'status':r.status}))
                page.on('console',lambda m:console.append({'type':m.type,'text':m.text}))
                page.on('pageerror',lambda e:errors.append(str(e)))
                def goto(path,math=False):
                    page.goto(urljoin(origin+'/',path),wait_until='networkidle')
                    if math:
                        page.wait_for_function('!!(window.MathJax&&MathJax.startup&&MathJax.startup.promise)')
                        page.evaluate('async()=>{await MathJax.startup.promise;await MathJax.typesetPromise();}')
                def layout(stage):
                    g=page.evaluate('()=>({viewport:innerWidth,html:document.documentElement.scrollWidth,body:document.body.scrollWidth})')
                    check(label+'-'+stage+'-document-horizontal-containment',g['html']<=g['viewport']+1 and g['body']<=g['viewport']+1,g)
                try:
                    goto(selected['proof_path'],math=True);article=page.locator('article.proof-reader')
                    steps=article.locator('details.proof-reader-step')
                    check(label+'-exactly-five-progressive-proof-steps',steps.count()==5)
                    check(label+'-five-steps-initially-folded',steps.evaluate_all('(xs)=>xs.length===5&&xs.every(x=>!x.open)'))
                    assumptions=article.locator('details.assumption-ledger')
                    check(label+'-assumptions-initially-folded',assumptions.count()==1 and not assumptions.evaluate('(e)=>e.open'))
                    check(label+'-statement-and-proof-initially-folded',article.locator('details.inline-lean').evaluate_all('(xs)=>xs.length>=2&&xs.every(x=>!x.open)'))
                    check(label+'-main-mathematical-formula-rendered',article.locator('.reader-main-equation mjx-container').count()>0)
                    check(label+'-all-main-reading-disclosures-initially-closed',page.locator('main details').evaluate_all('(xs)=>xs.length>0&&xs.every(x=>!x.open)'))
                    check(label+'-actual-local-MathJax-3.2.2-CHTML',page.evaluate('MathJax.version')=='3.2.2' and page.locator('mjx-container[jax="CHTML"]').count()>0)
                    check(label+'-unselected-global-navigation-stays-disabled',page.locator('a[data-preview-unserved-href]').evaluate_all('(xs)=>xs.length>0&&xs.every(x=>!x.hasAttribute("href")&&x.getAttribute("aria-disabled")==="true")'))
                    check(label+'-initial-MathJax-no-errors',page.locator('mjx-merror,[data-mjx-error]').count()==0)
                    layout('proof-initial');shot(page,label+'-proof-initial-folded',full=True)
                    open_reading_disclosures(article);page.evaluate('async()=>{await MathJax.typesetPromise();}')
                    code=steps.locator('pre.code-block>code').all_text_contents()
                    check(label+'-five-adjacent-source-code-spans',len(code)==5)
                    check(label+'-P50-first-two-folds-exact',''.join(code[:2]).encode()==(snapshot/PFILE).read_bytes())
                    check(label+'-T212-last-three-folds-exact',''.join(code[2:]).encode()==(snapshot/TFILE).read_bytes())
                    check(label+'-all262-source-lines-exact',len(''.join(code).splitlines())==262)
                    for i,stepdata in enumerate(unit['steps']):
                        step=steps.nth(i);raw=stepdata['lean_source_path'];first=stepdata['lean_source']['LF_lines_1based'][0]
                        check(label+'-step'+str(i+1)+'-rendered-title',step.locator(':scope>summary').text_content().strip()==str(i+1)+'. '+stepdata['title'])
                        check(label+'-step'+str(i+1)+'-visible-mathematical-prose-and-formula',bool(step.locator('.reader-step-body>p').first.text_content().strip()) and step.locator('.proof-reader-equation mjx-container').count()>0)
                        check(label+'-step'+str(i+1)+'-exact-displayed-Lean',code[i]==stepdata['lean'])
                        source=step.locator('a[data-step-source]');download=step.locator('a[download]');copy=step.locator('button[data-lean-copy]')
                        check(label+'-step'+str(i+1)+'-one-adjacent-copy-source-download',source.count()==download.count()==copy.count()==1)
                        check(label+'-step'+str(i+1)+'-correct-source-and-start-anchor',source.get_attribute('href').endswith(raw+'.html#L'+str(first)) and download.get_attribute('href').endswith('downloads/lean/'+raw) and step.locator('details[data-step-source-path]').get_attribute('data-step-source-path')==raw)
                        copy.click();copied=page.evaluate('navigator.clipboard.readText()')
                        check(label+'-step'+str(i+1)+'-actual-copy-byte-exact',copied.encode()==stepdata['lean'].encode())
                        with page.expect_download() as pending:download.click()
                        destination=output/(label+'-step'+str(i+1)+'-whole-module.lean');pending.value.save_as(str(destination))
                        check(label+'-step'+str(i+1)+'-actual-whole-module-download-exact',destination.read_bytes()==(snapshot/raw).read_bytes())
                        prior=page.url
                        with page.expect_navigation(wait_until='networkidle'):source.click()
                        anchor=page.locator('#L'+str(first));g=anchor.evaluate(VISIBLE)
                        check(label+'-step'+str(i+1)+'-actual-source-anchor-navigation',page.url.endswith(raw+'.html#L'+str(first)) and g['positive'] and g['top']>=g['header']-1,g)
                        page.go_back(wait_until='networkidle');page.wait_for_url(prior)
                        open_reading_disclosures(page.locator('article.proof-reader'));page.evaluate('async()=>{await MathJax.startup.promise;await MathJax.typesetPromise();}')
                        if i in [0,4]:
                            scroll_center(page.locator('details.proof-reader-step').nth(i).locator(':scope>summary'));shot(page,label+'-representative-step'+str(i+1))
                    equations=page.locator('.proof-reader-equation');formula_geometry=[]
                    for i in range(equations.count()):
                        g=equations.nth(i).evaluate("""el=>{const max=el.scrollWidth-el.clientWidth;el.scrollLeft=max;return{max,actual:el.scrollLeft,overflow:getComputedStyle(el).overflowX};}""")
                        formula_geometry.append(g)
                        check(label+'-formula'+str(i)+'-right-reachable-if-overflow',g['max']<=1 or (g['actual']>=g['max']-1 and g['actual']>0 and g['overflow'] in ['auto','scroll']),g)
                    check(label+'-expanded-MathJax-no-errors',page.locator('mjx-merror,[data-mjx-error]').count()==0)
                    table=page.locator('[data-source-comparison] .table-scroll')
                    check(label+'-source-assumption-comparison-present',table.count()==1)
                    if table.count():
                        scroll_center(table);g=table.evaluate("el=>{el.scrollLeft=el.scrollWidth-el.clientWidth;return{max:el.scrollWidth-el.clientWidth,actual:el.scrollLeft,overflow:getComputedStyle(el).overflowX};}")
                        check(label+'-source-table-right-reachable',g['max']<=1 or (g['actual']>=g['max']-1 and g['overflow'] in ['auto','scroll']),g)
                        shot(page,label+'-expanded-assumption-comparison')
                    layout('proof-expanded')
                    context_link=article.locator('details.inline-lean a[href*="modules/"]').first
                    check(label+'-whole-module-context-link-present',context_link.count()==1)
                    prior=page.url
                    with page.expect_navigation(wait_until='networkidle'):context_link.click()
                    check(label+'-actual-P-whole-module-context',page.locator('h1').first.text_content()==PFILE[:-5].replace('/','.') and page.locator('pre').last.text_content().encode()==(snapshot/PFILE).read_bytes())
                    open_reading_disclosures(page.locator('main'));scroll_center(page.locator('pre').last);shot(page,label+'-P-module-full-source-context')
                    page.go_back(wait_until='networkidle');page.wait_for_url(prior)
                except Exception:
                    check(label+'-proof-stage-completed',False,traceback.format_exc());shot(page,label+'-proof-stage-failure')

                for source_label,raw,name,anchor,line_count in SOURCES:
                    try:
                        path='data/lesson-sources/'+raw+'.html#L'+str(anchor);goto(path)
                        exact=(snapshot/raw).read_bytes();spans=page.locator('pre span[id^="L"]')
                        check(label+'-'+source_label+'-whole-source-body-exact',page.locator('pre').text_content().encode()==exact)
                        check(label+'-'+source_label+'-source-line-count',spans.count()==line_count)
                        prefix=('private theorem ' if source_label=='T' else 'theorem ')+name.split('.')[-1]
                        check(label+'-'+source_label+'-correct-file-and-declaration-header',page.locator('h1').first.text_content()=='Exact source context' and raw in page.title() and raw in page.locator('[data-exact-source-file]').text_content() and page.locator('#L'+str(anchor)).text_content().strip().startswith(prefix))
                        g=page.locator('#L'+str(anchor)).evaluate(VISIBLE)
                        check(label+'-'+source_label+'-actual-anchor-visible-below-header',g['positive'] and g['top']>=g['header']-1,g)
                        shot(page,label+'-source-'+source_label+'-anchor')
                        measured=spans.evaluate_all("""xs=>xs.map(el=>{const t=el.firstChild,r=document.createRange();r.setStart(t,0);r.setEnd(t,t.textContent.trimEnd().length);const b=r.getBoundingClientRect(),q=el.getBoundingClientRect();return{id:el.id,textWidth:b.width,lineHeight:q.height};})""")
                        check(label+'-'+source_label+'-all-source-lines-have-real-layout',len(measured)==line_count and all(x['lineHeight']>0 for x in measured),measured)
                        widest=max(measured,key=lambda x:x['textWidth']);glyph=page.locator('#'+widest['id']).evaluate(GLYPH,'rightmost')
                        check(label+'-'+source_label+'-widest-line-final-full-codepoint-visible',glyph['visible'] and glyph['lineVisible'],glyph)
                        if glyph['container']['max']>1:shot(page,label+'-source-'+source_label+'-widest-right-glyph')
                        bottom=page.locator('#L'+str(line_count)).evaluate(GLYPH,'targeted')
                        check(label+'-'+source_label+'-bottom-full-codepoint-visible',bottom['visible'] and bottom['lineVisible'],bottom)
                        if source_label=='T':shot(page,label+'-source-T-bottom')
                        copy=page.locator('.native-source-context button[data-lean-copy]');check(label+'-'+source_label+'-complete-source-copy-present',copy.count()==1)
                        copy.click();check(label+'-'+source_label+'-actual-complete-source-copy-exact',page.evaluate('navigator.clipboard.readText()').encode()==exact)
                        download=page.locator('.native-source-context a[download]');check(label+'-'+source_label+'-full-source-download-link-present',download.count()==1)
                        with page.expect_download() as pending:download.click()
                        destination=output/(label+'-source-'+source_label+'-whole-module.lean');pending.value.save_as(str(destination))
                        check(label+'-'+source_label+'-actual-full-source-download-exact',destination.read_bytes()==exact)
                        layout('source-'+source_label)
                    except Exception:
                        check(label+'-'+source_label+'-source-stage-completed',False,traceback.format_exc());shot(page,label+'-source-'+source_label+'-failure')

                try:
                    goto('source-index.html');links=page.locator('main li a')
                    check(label+'-source-index-six-exact-labels',links.all_text_contents()==[x[2] for x in SOURCES])
                    check(label+'-source-index-private-T-explicitly-not-public','associated private application; no public node' in links.nth(1).locator('..').text_content())
                    shot(page,label+'-source-index',full=True)
                    for i,(_,raw,name,anchor,_) in enumerate(SOURCES):
                        goto('source-index.html');link=page.locator('main li a').nth(i)
                        with page.expect_navigation(wait_until='networkidle'):link.click()
                        check(label+'-source-index-link'+str(i)+'-actual-exact-anchor',page.url.endswith(raw+'.html#L'+str(anchor)) and page.locator('#L'+str(anchor)).count()==1)
                    goto('parent-context.html');main_content=page.locator('main')
                    check(label+'-public-P-PSD-parent-and-private-T-four-parents','directly calls the existing generic PSD-integral node' in main_content.text_content() and main_content.locator('li a').all_text_contents()==[PSD,P,TRACE,SOURCES[4][2],SOURCES[5][2]] and 'It has no separate public theorem node' in main_content.text_content())
                    shot(page,label+'-parent-context',full=True)
                    graph=context.request.get(origin+'/data/underlying-lean-graph.json').json()
                    nodes={n['id']:n for n in graph['nodes']};edges={(e['source'],e['target'],e['relation']) for e in graph['edges']}
                    modules=[x[1][:-5].replace('/','.') for x in SOURCES]
                    expected_nodes={'module:'+m for m in modules}|{'decl:'+SOURCES[i][2] for i in [0,2,3,4,5]}
                    check(label+'-exact-bounded-11graph-node-identities',len(nodes)==len(graph['nodes'])==11 and set(nodes)==expected_nodes)
                    check(label+'-one-private-T-module-no-private-T-declaration',list(nodes).count('module:'+modules[1])==1 and not any(T.split('.')[-1] in n for n in nodes))
                    expected_edges={('module:'+modules[2],'module:'+modules[0],'imports')}|{('module:'+modules[i],'module:'+modules[1],'imports') for i in [0,3,4,5]}|{('module:'+modules[i],'decl:'+SOURCES[i][2],'declares') for i in [0,2,3,4,5]}|{('decl:'+PSD,'decl:'+P,'source reference (scanner)')}|{('decl:'+SOURCES[i][2],'module:'+modules[1],'source reference (scanner)') for i in [0,3,4,5]}
                    check(label+'-exact15-structure-and-directed-reference-edges',len(graph['edges'])==15 and edges==expected_edges and 'do not assert theorem implication' in graph['reference_contract'])
                    focuses=[('P','decl:'+P,P),('PSD','decl:'+PSD,PSD),('private-T-module','module:'+modules[1],modules[1])]
                    for focus_label,node_id,full_name in focuses:
                        goto('lean-foundations.html?view=lean&focus='+quote(node_id,safe=''))
                        page.wait_for_selector('.ulg-node.selected')
                        check(label+'-graph-'+focus_label+'-actual-exact-focus',page.locator('.ulg-node.selected').get_attribute('data-id')==node_id)
                        actual_node_ids=page.locator('.ulg-node').evaluate_all('(xs)=>xs.map(x=>x.dataset.id)')
                        check(label+'-graph-'+focus_label+'-actual-11unique-rendered-nodes',len(actual_node_ids)==len(set(actual_node_ids))==11 and set(actual_node_ids)==expected_nodes)
                        measured=zoom_pan_actual_ui(page,page.locator('.ulg-node.selected'))
                        check(label+'-graph-'+focus_label+'-native-wheel-pointer-exercised',measured['native_pointer_and_wheel_exercised'],measured)
                        check(label+'-graph-'+focus_label+'-readable-node-core-label-inside-real-SVG-clip',measured['core_label_readable_inside_actual_SVG_clip'],measured)
                        shot(page,label+'-graph-'+focus_label+'-actual-node-viewport')
                        styles=page.locator('path.ulg-edge').evaluate_all("xs=>xs.map(e=>({formal:e.classList.contains('formal-edge'),overlay:e.classList.contains('overlay-edge'),dash:getComputedStyle(e).strokeDasharray,relation:e.dataset.relation,arrow:e.getAttribute('marker-end')}))")
                        check(label+'-graph-'+focus_label+'-formal-solid-reference-dashed-arrows',any(x['formal'] and x['dash']=='none' for x in styles) and any(x['overlay'] and x['dash']!='none' for x in styles) and all(x['arrow'] for x in styles),styles)
                        incoming=[e['source'] for e in graph['edges'] if e['target']==node_id];outgoing=[e['target'] for e in graph['edges'] if e['source']==node_id]
                        check(label+'-graph-'+focus_label+'-actual-directed-related-arrows',page.locator('path.ulg-edge.related.incoming').count()==len(incoming) and page.locator('path.ulg-edge.related.outgoing').count()==len(outgoing),{'expected_incoming':incoming,'expected_outgoing':outgoing})
                        detail=page.locator('[data-graph-detail]');heading=detail.locator('header h2')
                        check(label+'-graph-'+focus_label+'-full-exact-ID-in-detail',heading.text_content()==full_name)
                        for title,expected in [('Immediate prerequisites',incoming),('Immediate consumers',outgoing)]:
                            section=detail.locator('section').filter(has=page.get_by_role('heading',name=title,exact=True))
                            actual=section.locator('button[data-jump]').evaluate_all('(xs)=>xs.map(x=>x.dataset.jump)') if section.count() else []
                            check(label+'-graph-'+focus_label+'-'+title.replace(' ','-')+'-exact-neighbor-directions',sorted(actual)==sorted(expected),{'actual':actual,'expected':expected})
                        scroll_center(heading);visible=heading.evaluate(VISIBLE)
                        check(label+'-graph-'+focus_label+'-full-ID-detail-real-visible-area',visible['positive'] and visible['intersectionHeight']>=min(visible['height']-1,120),visible)
                        shot(page,label+'-graph-'+focus_label+'-full-ID-detail')
                        link=detail.locator('.ulg-links a.primary').first;expected=nodes[node_id]['url']
                        check(label+'-graph-'+focus_label+'-exact-local-context-link',link.get_attribute('href')==expected)
                        with page.expect_navigation(wait_until='networkidle'):link.click()
                        check(label+'-graph-'+focus_label+'-actual-context-navigation',page.url==urljoin(origin+'/',expected))
                        if focus_label=='P':
                            page.wait_for_function('!!(window.MathJax&&MathJax.startup&&MathJax.startup.promise)')
                            page.evaluate('async()=>{await MathJax.startup.promise;await MathJax.typesetPromise();}')
                            canonical=page.locator('article.proof-reader')
                            check(label+'-canonical-P-reader-same-five-folds-initially-closed',canonical.locator('details.proof-reader-step').evaluate_all('(xs)=>xs.length===5&&xs.every(x=>!x.open)'))
                            check(label+'-canonical-P-reader-rendered-main-formula',canonical.locator('.reader-main-equation mjx-container').count()>0 and page.locator('mjx-merror,[data-mjx-error]').count()==0)
                            check(label+'-canonical-P-reader-exact-five-source-spans',canonical.locator('details.proof-reader-step pre.code-block>code').all_text_contents()==[s['lean'] for s in unit['steps']])
                        elif focus_label=='private-T-module':
                            check(label+'-private-T-module-whole-source-exact',page.locator('h1').first.text_content()==modules[1] and page.locator('pre').last.text_content().encode()==(snapshot/TFILE).read_bytes())
                            open_reading_disclosures(page.locator('main'));scroll_center(page.locator('pre').last);shot(page,label+'-private-T-module-full-source-context')
                            with page.expect_download() as pending:page.locator('main a[download]').click()
                            destination=output/(label+'-private-T-module-context-download.lean');pending.value.save_as(str(destination))
                            check(label+'-private-T-module-context-actual-download-exact',destination.read_bytes()==(snapshot/TFILE).read_bytes())
                    layout('final-context')
                except Exception:
                    check(label+'-source-index-parent-graph-stage-completed',False,traceback.format_exc());shot(page,label+'-graph-stage-failure')
                context.close()
            browser.close()
    except Exception:
        check('browser-stage-completed',False,traceback.format_exc())
    finally:
        server.shutdown();server.server_close();worker.join()
    check('fixture-file-set-unchanged',fixture_paths()=={row['path'] for row in selected['files']})
    for row in selected['files']:check('fixture-unchanged:'+row['path'],sha(fixture/row['path'])==row['sha256'])
    check('no-external-browser-requests',not blocked,blocked);check('no-page-javascript-errors',not errors,errors)
    check('no-console-errors',not [x for x in console if x['type']=='error'],console)
    check('no-HTTP-error-responses',not [x for x in responses if x['status']>=400],responses)
    result={'schema':'r17-independent-actual-isolated-reader-result-v1','actual_preview_root':str(preview),'preview_manifest_sha256':sha(manifest_path),'source_reviewed_binding':a['source_reviewed_publication_binding_sha256'],'mathematical_commit':manifest['proof_commit'],'actual_assignment_sha256':sha(args.assignment),'runner_sha256':sha(__file__),'checks':checks,'screenshots':screenshots,'requests':requests,'responses':responses,'console':console,'page_errors':errors,'blocked_external_requests':blocked,'actual_Chrome_version':version,'browser_started':started,'status':'ENV_BLOCKED' if not started else 'PASS' if all(x['pass'] for x in checks) else 'FAIL','all_screenshots_are_actual_full_viewport_or_full_page_no_optional_crops':True,'old_packet_acceptance_inherited':False,'headless_Chrome_CSS_viewports_not_physical_touch':True,'glyph_Range_bbox_horizontal_tolerance_css_px':1,'render_executed_by_this_checker':False,'normal_API_Lean_production_Git_shared_writes':0,'server_and_worker_stopped':True,'independent_visual_acceptance':'PENDING actual PNG review; check flags alone are not independent acceptance'}
    dump(OWN/'actual-result.json',result)
    print(json.dumps({'status':result['status'],'checks':len(checks),'false_checks':[x['name'] for x in checks if not x['pass']],'actual_PNGs':len(screenshots),'actual_result_sha256':sha(OWN/'actual-result.json')}))
    return 0 if result['status']=='PASS' else 2 if result['status']=='ENV_BLOCKED' else 1

def captured():
    os.umask(0o077)
    args=parse()
    if not args.assignment.is_file():raise RuntimeError('Preparation only: no ROOT post-source-review execution assignment. No browser/render/server may start.')
    a=json.loads(args.assignment.read_text())
    if a.get('authorization')!='ROOT_AUTHORIZED_AFTER_SOURCE_REVIEW':raise RuntimeError('ROOT post-review authorization required before browser execution.')
    process=OWN/'runtime-process';process.mkdir(exist_ok=False)
    out=process/'stdout.raw';err=process/'stderr.raw';sys.stdout.flush();sys.stderr.flush()
    o=out.open('xb',buffering=0);e=err.open('xb',buffering=0);os.dup2(o.fileno(),1);os.dup2(e.fileno(),2);o.close();e.close()
    start=time.monotonic();started=dt.datetime.now(dt.timezone.utc).isoformat();code=1;exception=None
    try:code=main(args,a)
    except BaseException as ex:exception={'type':type(ex).__name__,'message':str(ex)};traceback.print_exc();code=130 if isinstance(ex,KeyboardInterrupt) else 1
    sys.stdout.flush();sys.stderr.flush()
    dump(process/'receipt.json',{'schema':'r17-actual-reader-OS-process-receipt-v1','argv':[sys.executable,*sys.argv],'cwd':str(Path.cwd()),'pid':os.getpid(),'ppid':os.getppid(),'started_utc':started,'ended_utc':dt.datetime.now(dt.timezone.utc).isoformat(),'elapsed_seconds':time.monotonic()-start,'actual_exit_code':code,'exception':exception,'stdout':{'path':str(out.relative_to(OWN)),'bytes':out.stat().st_size,'sha256':sha(out)},'stderr':{'path':str(err.relative_to(OWN)),'bytes':err.stat().st_size,'sha256':sha(err)},'runner_sha256':sha(__file__),'assignment_sha256':sha(args.assignment),'actual_result_sha256':sha(OWN/'actual-result.json') if (OWN/'actual-result.json').exists() else None,'actual_OS_fd1_fd2_until_exit':True,'no_reconstructed_success_receipt':True})
    return code

if __name__=='__main__':sys.exit(captured())
