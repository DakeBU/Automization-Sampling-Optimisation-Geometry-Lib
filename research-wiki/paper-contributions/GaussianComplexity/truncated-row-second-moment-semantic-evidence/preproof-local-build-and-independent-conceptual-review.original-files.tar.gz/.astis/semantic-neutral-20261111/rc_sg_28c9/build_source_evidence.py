from pathlib import Path
from html.parser import HTMLParser
import hashlib, json, re
from datetime import datetime, timezone

BASE=Path('/Users/zhouhuanjian/ASTIS-GC')
OUT=BASE/'.astis/semantic-neutral-20261111/rc_sg_28c9'
RAW=BASE/'.astis/huanjian-resume-20261103/2610.20492v1.html'
b=RAW.read_bytes(); s=b.decode('utf-8')
H=lambda x:hashlib.sha256(x).hexdigest()
assert len(b)==951991 and H(b)=='6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
line_starts=[0]+[m.end() for m in re.finditer('\n',s)]
byte_prefix=[0]
for c in s: byte_prefix.append(byte_prefix[-1]+len(c.encode('utf-8')))
import bisect

def location(a,z):
    li=bisect.bisect_right(line_starts,a)-1
    le=bisect.bisect_right(line_starts,z)-1
    return dict(source_path=str(RAW),char_start=a,char_end_exclusive=z,utf8_byte_start=byte_prefix[a],utf8_byte_end_exclusive=byte_prefix[z],start_line_1based=li+1,start_column_0based=a-line_starts[li],end_line_1based=le+1,end_column_0based=z-line_starts[le],sha256=H(s[a:z].encode('utf-8')))

class Index(HTMLParser):
    def __init__(self): super().__init__(convert_charrefs=False); self.stack=[]; self.ids={}
    def off(self):
        l,c=self.getpos();return line_starts[l-1]+c
    def handle_starttag(self,t,attrs):
        if t in {'area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr'}:return
        self.stack.append((t,dict(attrs).get('id'),self.off()))
    def handle_endtag(self,t):
        for j in range(len(self.stack)-1,-1,-1):
            if self.stack[j][0]==t:
                x=self.stack[j:];self.stack=self.stack[:j]
                for _,i,a in x:
                    if i:self.ids[i]=(a,s.index('>',self.off())+1)
                break
p=Index();p.feed(s); ids=p.ids
blocks=['S4.Thmtheorem4','A3.SS2.p1','A3.SS2.p10','A3.SS2.p12']
(OUT/'raw-blocks').mkdir(exist_ok=True)
block_info=[]
for k in blocks:
 a,z=ids[k];f=OUT/'raw-blocks'/f'{k}.html';f.write_bytes(s[a:z].encode('utf-8'));block_info.append({'id':k,'saved_path':str(f),'locator':location(a,z)})

def write(name,x):
 f=OUT/name
 if isinstance(x,str): f.write_text(x,encoding='utf-8')
 else:f.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

def ref(k):return {'html_id':k,**location(*ids[k])}
coverage=[]
def cov(a,z,disp,meaning,nodes=None):
 assert a<z
 coverage.append(dict(disposition=disp,meaning=meaning,node_ids=nodes or [],locator=location(a,z)))
def whole(k,disp,meaning,nodes=None):cov(*ids[k],disp,meaning,nodes)
def findin(k,substr):return s.index(substr,ids[k][0],ids[k][1])
# Full, disjoint inventory of the bounded raw-source universe. HTML scaffolding
# is filled after the mathematical/prose dispositions below.
whole('S4.Thmtheorem4.2','EXCLUDED','Lemma 4.4 title is context; its uniform bound is outside this packet.')
whole('S4.Thmtheorem4.3','EXCLUDED','Title spacing.')
whole('S4.Thmtheorem4.4','EXCLUDED','Uniform-bound title is context outside both selected conclusions.')
a,z=ids['S4.Thmtheorem4.p1.1'];q=findin('S4.Thmtheorem4.p1.1','Let <math');g=ids['S4.Thmtheorem4.p1.m4'][0];k=ids['S4.Thmtheorem4.p1.m6'][0]
cov(a,q,'EXCLUDED','Existential absolute C belongs to Lemma 4.4 bounds; neither selected identity depends on C.')
cov(q,g,'NODE','Standing natural q ≥ 0 and 2q+1<d, with no q>0 restriction.',['S.qd'])
cov(g,k,'NODE','Standing independent g_1,...,g_(q+1) ~ N(0,I_d).',['S.g'])
cov(k,z,'EXCLUDED','Krylov-space assignment and display introduction are not prerequisites of the selected identities.')
whole('S4.Ex13','EXCLUDED','Definition of tau and its constants belongs to the excluded main uniform bound.')
whole('S4.Thmtheorem4.p1.2','EXCLUDED','tau ≤ 1/2 and probability ≥ 0.99 are conditions/conclusion of the excluded uniform bound.')
whole('S4.Ex14','EXCLUDED','Main uniform quadratic-form bound is excluded.')
a,z=ids['A3.SS2.p1.1'];n=findin('A3.SS2.p1.1',' and <math');i=findin('A3.SS2.p1.1','For <math')
cov(a,n,'NODE','Definition r=q+1.',['D.r'])
cov(n,i,'EXCLUDED','Frequency n=2q+1 is used by later weighted sums, not either selected root.')
cov(i,z,'NODE','Source row index convention 1 ≤ i ≤ d.',['D.index'])
whole('A3.Ex85','NODE','Literal cosine feature vector t_i and coordinate vector gamma_i definitions.',['D.vectors'])
a,z=ids['A3.SS2.p1.2'];end=ids['A3.SS2.p1.m5'][1]+1
cov(a,end,'NODE','The gamma_i are independent N(0,I_r); marginal standard law and common law are used, cross-i independence is not needed by either selected root.',['S.gamma'])
cov(end,z,'EXCLUDED','B and its normalized tensor rows belong to the later frame/Gram argument.')
a,z=ids['A3.SS2.p10.1'];h=ids['A3.SS2.p10.1.1'][1];since=findin('A3.SS2.p10.1','Since <math')
cov(a,h,'EXCLUDED','Sectional heading: truncation and its bias.')
cov(h,since,'NODE','Literal finite threshold L=2r+3 log(1000d) and squared norm R_i=||gamma_i||².',['D.LR'])
cov(since,z,'EXCLUDED','Gaussian exponential moment, Markov inequality, and tail parameter x belong to tail/concentration bounds.')
whole('A3.Ex104','EXCLUDED','Chi-square tail inequality is not used by these expectation identities.')
whole('A3.SS2.p10.2','EXCLUDED','Numerical log estimate and global truncation-event introduction serve the excluded tail bound.')
whole('A3.Ex105','EXCLUDED','Global event T is not a premise of an unconditional truncated expectation.')
whole('A3.SS2.p10.3','EXCLUDED','Probability of global event T is outside the two identity roots.')
whole('A3.SS2.p12.1','EXCLUDED','Introductory wording; the side assertion that Y_i are independent serves later concentration and is not a prerequisite of either root. Definition itself is separately covered at Ex107.')
whole('A3.Ex107','NODE','Literal truncated rank-one Kronecker matrix Y_i definition.',['D.Y'])
whole('A3.SS2.p12.2','NODE','The author names radial symmetry but omits its derivation and the matrix/trace argument.',['G.radial','G.coordinates','G.trace'])
whole('A3.Ex108','NODE','First source root: truncated covariance a I_r and scalar formula a=E[R_i 1]/r.',['D.a','C.cov'])
a,z=ids['A3.SS2.p12.3'];since=findin('A3.SS2.p12.3','Since <math')
cov(a,since,'NODE','The scalar a is the same for every i.',['C.common'])
cov(since,z,'EXCLUDED','E R_i=r and 0≤a≤1 are used here for the subsequent bias estimate; neither bound is part of either selected conclusion. Gaussian finite-moment background is recorded separately.')
whole('A3.Ex109','EXCLUDED','Scalar tail-bias identity/inequality is a separate auxiliary estimate, not either selected root.')
a,z=ids['A3.SS2.p12.4'];fact=findin('A3.SS2.p12.4','Fact\u00a0')
cov(a,fact,'NODE','Immediate consumer and second source root: E Y_i=(a/d)(I_r⊗t_i t_iᵀ).',['C.EY','G.EY'])
cov(fact,z,'EXCLUDED','Fact C.5 is invoked only for the later summed frame identities, not E Y_i.')
whole('A3.Ex110','EXCLUDED','Both summed frame identities are explicitly outside this packet.')
whole('A3.SS2.p12.5','EXCLUDED','Zero expectation of the weighted sum is downstream of the excluded summed identities.')

class Plain(HTMLParser):
 def __init__(self):super().__init__();self.math=0;self.out=[]
 def handle_starttag(self,t,at):
  if t=='math':self.math+=1;self.out.append('$'+dict(at).get('alttext','')+'$')
 def handle_endtag(self,t):
  if t=='math':self.math-=1
 def handle_data(self,d):
  if not self.math:self.out.append(d)
def plain(a,z):
 p=Plain();p.feed(s[a:z]);return ''.join(p.out)
coverage.sort(key=lambda x:x['locator']['char_start'])
for k in blocks:
 ba,bz=ids[k]; rows=[x for x in coverage if ba<=x['locator']['char_start'] and x['locator']['char_end_exclusive']<=bz];cur=ba
 for row in rows:
  a=row['locator']['char_start'];z=row['locator']['char_end_exclusive'];assert cur<=a,(k,cur,a)
  if cur<a:
   t=plain(cur,a).strip()
   assert not t or t in {'(',').'},(k,'uncovered semantic text',t)
   cov(cur,a,'EXCLUDED','HTML scaffolding, whitespace, and title punctuation; no additional mathematical assertion.')
  cur=z
 if cur<bz:
  assert not plain(cur,bz).strip(),(k,'uncovered tail',plain(cur,bz))
  cov(cur,bz,'EXCLUDED','Closing HTML scaffolding and whitespace.')
coverage.sort(key=lambda x:x['locator']['char_start'])
for j,x in enumerate(coverage):x['coverage_id']=f'cov-{j+1:03d}'
# Verify exact character and UTF-8 byte partitions, not just positive counts.
checks=[]
for k in blocks:
 a,z=ids[k];rr=[x for x in coverage if a<=x['locator']['char_start'] and x['locator']['char_end_exclusive']<=z];cur=a
 for x in rr:assert x['locator']['char_start']==cur;cur=x['locator']['char_end_exclusive']
 assert cur==z
 checks.append({'block':k,'char_count':z-a,'utf8_byte_count':byte_prefix[z]-byte_prefix[a],'coverage_rows':len(rr),'gap_chars':0,'overlap_chars':0})
write('coverage.json',{'schema':'independent-source-exhaustive-coverage-v1','source_sha256':H(b),'coordinate_convention':'0-based Unicode character and UTF-8 byte offsets; end exclusive; physical lines 1-based; columns 0-based. All offsets refer to full pinned raw HTML, never rendered text.','bounded_universe':block_info,'checks':checks,'rows':coverage,'scope_warning':'Exclusions claim no formalization or theorem completion; all source outside the four bounded blocks is outside the audit universe.'})
# Exhaustive HTML-id membership map; covering rows may split a prose element.
members=[]
for key,(a,z) in ids.items():
 if any(ba<=a and z<=bz for ba,bz in (ids[k] for k in blocks)):
  rr=[x for x in coverage if x['locator']['char_start']<z and a<x['locator']['char_end_exclusive']]
  members.append({'html_id':key,'locator':location(a,z),'coverage_ids':[x['coverage_id'] for x in rr],'node_ids':sorted({n for x in rr for n in x['node_ids']})})
write('source-memberships.json',{'source_sha256':H(b),'note':'Membership records indicate raw source attribution/coverage only. They are not compiled theorem dependencies. Background gap-node attachment means the source omits that bridge at the quoted use site.','elements':sorted(members,key=lambda x:x['locator']['char_start'])})

nodes=[]
def node(n,kind,statement,source_ids=None,status='explicit-source',notes=''):
 nodes.append({'id':n,'kind':kind,'statement':statement,'source_memberships':[ref(i) for i in source_ids or []],'source_status':status,'compiled_lean_dependencies':'unseen; none asserted','notes':notes})
node('S.qd','standing-assumptions','d,q are natural numbers, q≥0, 2q+1<d.',['S4.Thmtheorem4.p1.m2','S4.Thmtheorem4.p1.m3'],notes='Natural q includes 0; infer r=q+1≥1 and d≥2 internally. Do not introduce q>0, r≥2, log/tau gates, or probability events.')
node('S.g','standing-law','g_1,...,g_(q+1) are independent N(0,I_d) random column vectors.',['S4.Thmtheorem4.p1.m4','S4.Thmtheorem4.p1.m5'])
node('D.r','definition','r=q+1.',['A3.SS2.p1.m1'])
node('D.index','typing-convention','i ranges over 1,...,d; coordinate indices a,b range over 1,...,r.',['A3.SS2.p1.m3'],'explicit-source-and-implicit-typing')
node('D.vectors','definition','t_i=(1,√2 cos θ_i,...,√2 cos(q θ_i))ᵀ∈R^r is deterministic; gamma_i=((g_1)_i,...,(g_r)_i)ᵀ∈R^r.',['A3.Ex85.m1'],notes='At q=0, t_i=(1), with the cosine tail empty. The exact values/orthogonality of theta_i are unnecessary for the selected expectation transport.')
node('S.gamma','source-asserted-law','gamma_1,...,gamma_d are independent N(0,I_r); in particular every gamma_i has the same standard r-dimensional Gaussian law.',['A3.SS2.p1.m4','A3.SS2.p1.m5'],notes='Source asserts this after the vector definition. Cross-i independence is a source side fact, not used to infer either selected expectation.')
node('D.LR','definition','L=2r+3 log(1000d), R_i=||gamma_i||².',['A3.SS2.p10.m1','A3.SS2.p10.m2'])
node('D.a','definition','a_i=(1/r) E[R_i 1_{R_i≤L}]; after common-law identification the source uses the unindexed scalar a.',['A3.Ex108.m1'],notes='The scalar formula is literal. Division is real division by the cast of positive natural r; no totalized r=0 interpretation is being attributed to the source.')
node('D.Y','definition','Y_i=(1/d)(gamma_i gamma_iᵀ⊗t_i t_iᵀ)1_{R_i≤L}∈R^(r²×r²).',['A3.Ex107.m1'])
node('G.positive','source-gap','From natural q≥0 and r=q+1, obtain r>0; from 2q+1<d obtain d>0. Casts of r,d into R are nonzero.',['S4.Thmtheorem4.p1.m2','S4.Thmtheorem4.p1.m3','A3.SS2.p1.m1'],'omitted-elementary-bridge')
node('G.radial','source-gap','The N(0,I_r) law is invariant under orthogonal maps; sign flips/permutations preserve the squared norm and event R_i≤L.',['A3.SS2.p12.2','A3.SS2.p1.m5','A3.SS2.p10.m2'],'source-named-bridge-with-omitted-derivation')
node('G.integrable','source-gap','gamma_i is measurable with finite Gaussian second moments; R_i and each truncated coordinate product gamma_(i,a)gamma_(i,b)1_{R_i≤L} are integrable; finite-dimensional matrix expectation exists entrywise.',['A3.SS2.p1.m5','A3.Ex108.m1'],'omitted-analytic-bridge',notes='One sufficient route: E R_i<∞ for standard Gaussian; |gamma_a gamma_b|≤(gamma_a²+gamma_b²)/2≤R_i. Event is Borel because R_i is continuous in gamma_i. A finite-cutoff boundedness route also exists but is not an additional AND prerequisite.')
node('G.coordinates','source-gap','For M_i=E[gamma_i gamma_iᵀ1_{R_i≤L}], a sign flip gives M_i(a,b)=0 for a≠b; coordinate permutations give all diagonal entries equal; thus M_i=b_i I_r.',['A3.SS2.p12.2','A3.Ex108.m1'],'omitted-linear-algebra-bridge',notes='r=1 has no off-diagonal pairs; the equal-diagonal requirement is vacuous. Radial truncation alone cannot replace rotational/sign/permutation invariance of the law.')
node('G.trace','source-gap','Finite trace/expectation interchange gives tr M_i=E[||gamma_i||²1_{R_i≤L}]; with M_i=b_i I_r and r>0, b_i=(1/r)E[R_i1_{R_i≤L}].',['A3.Ex108.m1'],'omitted-trace-normalization-bridge')
node('C.common','source-claim','The coefficient a_i is the same for every i, hence a may be written without an index.',['A3.SS2.p12.m1','A3.SS2.p12.m2'],notes='Identical marginal standard Gaussian law and common deterministic L suffice; independence is not required. This is part of the unindexed-a source interface.')
node('C.cov','source-root','For every 1≤i≤d, E[gamma_i gamma_iᵀ1_{R_i≤L}]=a I_r, with a=(1/r)E[R_i1_{R_i≤L}] common across i.',['A3.Ex108.m1','A3.SS2.p12.m1','A3.SS2.p12.m2'])
node('G.EY','source-gap','For deterministic t_i, integrate Y_i entrywise: E Y_i=(1/d)(E[gamma_i gamma_iᵀ1_{R_i≤L}]⊗t_i t_iᵀ). Finite entries are integrable, and Kronecker multiplication is bilinear in the random factor.',['A3.Ex107.m1','A3.SS2.p12.m5'],'omitted-expectation-transport-bridge',notes='The indicator multiplies the random covariance factor and can be moved across the fixed tensor factor. The scalar 1/d is deterministic. No independence between random factors is asserted or needed.')
node('C.EY','source-root','For every 1≤i≤d, E Y_i=(a/d)(I_r⊗t_i t_iᵀ).',['A3.SS2.p12.m5'])

edges=[]
def edge(frm,to,use,why):edges.append({'prerequisites':frm,'consumer':to,'logic':'AND within this one source-expansion route','consumer_use_site':[ref(x) for x in use],'reason':why})
edge(['S.qd','D.r'],'G.positive',['A3.Ex108.m1','A3.SS2.p12.m5'],'Discharge positive real denominators r,d internally; these are not extra public premises.')
edge(['S.g','D.r','D.index','D.vectors'],'S.gamma',['A3.SS2.p1.m4','A3.SS2.p1.m5'],'Coordinate assembly of independent standard Gaussian draws; source states the resulting gamma law.')
edge(['S.gamma','D.LR'],'G.radial',['A3.SS2.p12.2'],'The cited radial symmetry is the standard Gaussian law; the radial event must be preserved too.')
edge(['S.gamma','D.LR'],'G.integrable',['A3.Ex108.m1'],'Derive measurability/second-moment and truncation integrability rather than bind them publicly.')
edge(['G.radial','G.integrable'],'G.coordinates',['A3.Ex108.m1'],'Symmetry of integrable truncated entries gives off-diagonal cancellation and common diagonal.')
edge(['G.coordinates','G.integrable','D.LR','G.positive'],'G.trace',['A3.Ex108.m1'],'Take finite trace, exchange it with expectation, and divide by r.')
edge(['S.gamma','D.LR','D.a'],'C.common',['A3.SS2.p12.m1','A3.SS2.p12.m2'],'Same marginal law and same cutoff give same scalar coefficient across row indices.')
edge(['D.a','G.trace','C.common'],'C.cov',['A3.Ex108.m1'],'Identify the scalar in the isotropic covariance with the displayed a and use the common coefficient convention.')
edge(['D.Y','D.vectors','G.integrable','G.positive'],'G.EY',['A3.SS2.p12.m5'],'Expand literal Y entries and pull deterministic scalar/rank-one entries through expectation.')
edge(['G.EY','C.cov'],'C.EY',['A3.SS2.p12.m5'],'Substitute the truncated covariance into the immediate Kronecker consumer and combine scalars.')
roots=['C.cov','C.EY']
parents={x['id']:set() for x in nodes}
for e in edges:parents[e['consumer']].update(e['prerequisites'])
def close(root):
 seen=set();todo=[root]
 while todo:
  x=todo.pop()
  if x in seen:continue
  seen.add(x);todo.extend(parents[x])
 return sorted(seen)
closures={r:close(r) for r in roots}
assert set.union(*(set(x) for x in closures.values()))==set(parents)
write('source-graph.json',{'schema':'independent-source-proof-graph-v1','scope':'Appendix C.2 radial truncated covariance Ex108 and its immediate E Y_i consumer p12.m5; source-only expansion','source_sha256':H(b),'roots':roots,'nodes':nodes,'hyperedges':edges,'root_backward_closure':closures,'root_closure_orphans':[],'topology_claim':'This is the independently reconstructed source route with explicit omitted bridges. It is not a Lean dependency graph. One sufficient Gaussian finite-moment integrability route is represented; bounded-cutoff integrability is an alternative background route, not a second conjunct.','compiled_lean_seen':False,'types_seen':False,'review_authority':'Extractor evidence only: requires distinct topology challenge; grants no VERIFIED, intake, normal-acceptance, publication, or theorem-completion status.'})

reading='''# Frozen independent source reading

The pinned input is arXiv 2610.20492v1, raw HTML SHA256 6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915, exactly 951991 bytes. This reading and its graph were constructed from the raw source without Lean, declaration signatures, existing source graphs, reviewer reports, or earlier mathematical artifacts. The only additional reads were AGENTS.md and the two source/evidence process protocols. A filename inventory exposed locations of historical AGENTS files; none of those historical files was opened. No network was used.

The bounded universe consists of the complete S4.Thmtheorem4 statement and complete C.2 paragraphs p1, p10, p12. The selected mathematical result is smaller than this universe: Ex108 and the immediate p12.m5 expectation formula, with the definitions and standing source assumptions needed to read them. Every remaining mathematical clause in those blocks is explicitly excluded in coverage.json. Source outside those four blocks is not claimed covered.

The source assumptions are natural q≥0 and 2q+1<d, with independent g_1,...,g_(q+1)~N(0,I_d). Set r=q+1 and form gamma_i from the ith coordinates across the g vectors. The source expressly states that all gamma_i~N(0,I_r), independently. In particular r≥1, d≥2, and q=0 is included. The one-dimensional q=0 case has t_i=(1) and no cosine tail; it does not create a two-coordinate requirement. Cross-row independence is standing source information but is unnecessary for these marginal expectation identities.

Set R_i=||gamma_i||² and L=2r+3 log(1000d). L is one deterministic finite real threshold, shared by i. Its positivity and Gaussian tails are unnecessary for the radial identity: any fixed finite real threshold would permit the same symmetry identity, with an empty event for L<0. The source-facing theorem must still match its displayed L unless a generic library lemma is separately labeled. No tail bound, global event T, tau≤1/2, C, or high-probability condition is a premise of either selected identity.

The first conclusion is E[gamma_i gamma_iᵀ 1_{R_i≤L}]=a I_r with a=(1/r)E[R_i 1_{R_i≤L}]. The following source sentence makes a common across all i. A precise generic decomposition may first call the coefficient a_i and then prove it is common from identical marginal laws and the shared cutoff. A family of unrelated a_i values would omit that source clause.

The author's phrase “By radial symmetry” omits several mathematical moves. Standard Gaussian law is invariant under orthogonal maps. The squared norm, and hence the cutoff event, is invariant under these maps. Sign flips kill off-diagonal expected products. Coordinate permutations make all diagonal expected products equal. Therefore the expected matrix is b_i I_r. The trace equals E[sum_a gamma_(i,a)² 1]=E[R_i1], so r b_i=E[R_i1] and b_i equals the displayed coefficient. At r=1 the off-diagonal and diagonal-comparison obligations are vacuous, while the trace step still applies.

Measurability and integrability are also omitted. They are derived ingredients, not source binders. A standard Gaussian has finite second moments; the squared norm is integrable and dominates the absolute truncated coordinate products using |xy|≤(x²+y²)/2. A Borel cutoff event preserves measurability. Finite-dimensional expectation, finite sums, and trace interchange then exist. Alternatively a finite cutoff bounds the truncated entries; that is a sufficient alternative route and is not an additional conjunct in the graph. The source's later E R_i=r is covered but excluded from the selected route because its explicit local use is the separate bias estimate.

The second conclusion is E Y_i=(a/d)(I_r⊗t_i t_iᵀ), for Y_i=(1/d)(gamma_i gamma_iᵀ⊗t_i t_iᵀ)1_{R_i≤L}. The t_i are deterministic real vectors. For each pair of tensor indices ((a,j),(b,k)), the Y entry is d^-1 gamma_(i,a)gamma_(i,b)t_(i,j)t_(i,k)1. Pull the deterministic factors through expectation, use the first conclusion, and obtain (a/d)delta_(a,b)t_(i,j)t_(i,k). This is the literal Kronecker expression in the source. No random-factor independence is required by this transport. The actual values or frame orthogonality of the cosines are not needed; the values appear because the source defines those t_i.

The matrix and tensor conventions matter. All vectors are columns, and xxᵀ is the real rank-one matrix with (j,k) entry x_j x_k. The symbol ⊗ is matrix Kronecker product, with gamma coordinates first and feature coordinates second. Each factor is r×r and Y_i is r²×r². On product indices (a,j),(b,k), (A⊗B) has entry A(a,b)B(j,k). Reversing factors requires an explicit permutation conjugacy, not definitional equality. I_r is the identity with delta entries; matrix expectation is entrywise (equivalently finite-dimensional Bochner expectation once integrability is proved). The real indicator is 1 on R_i≤L and 0 otherwise, including the boundary R_i=L in the retained event. The complement is R_i>L. Scalar products a I_r and (a/d)(...) mean scalar multiplication. Natural r,d are cast into reals before division; positivity is derived from standing assumptions. No complex transpose/conjugation convention is involved.

The packet excludes later summed frame identities, Fact C.5 as a prerequisite of either root, the centered summands, operator norms, concentration, scalar bias bounds, and the two main bounds elsewhere in the paper. The phrase about independent Y_i is covered as a side assertion outside these roots. This source graph neither certifies a Lean dependency nor proves any source gap has been compiled. It exposes the missing bridges for later typed comparison and independent topology review. No final acceptance, VERIFIED transition, normal intake, publication permission, or completion is granted.
'''
write('mathematical-reading.md',reading)
write('assumption-convention-audit.json',{'source_assumptions':[{'claim':'d,q natural; q≥0; 2q+1<d','classification':'STANDING','source_refs':['S4.Thmtheorem4.p1.m2','S4.Thmtheorem4.p1.m3']},{'claim':'g vectors independent N(0,I_d)','classification':'STANDING','source_refs':['S4.Thmtheorem4.p1.m4','S4.Thmtheorem4.p1.m5']},{'claim':'vectors and matrices over real finite dimensional coordinate spaces; i in 1,...,d; tensor indices ordered gamma then feature','classification':'TYPING','source_refs':['A3.Ex85.m1','A3.Ex107.m1']},{'claim':'gamma_i standard normal marginal and common law','classification':'SOURCE-DERIVED LAW, not an independent added premise','source_refs':['A3.SS2.p1.m4','A3.SS2.p1.m5']}],'derived_not_public_binders':['r>0 and d>0','nonzero real casts of denominators','measurability of gamma/R/cutoff/truncated products','integrability of truncated covariance and Y entries','orthogonal/sign/permutation invariance of standard Gaussian law','invariance of the radial cutoff','off-diagonal cancellation and equality of diagonals','finite trace/expectation interchange','deterministic-factor expectation linearity and Kronecker entry transport','common coefficient across identical Gaussian marginals'],'forbidden_additions':['q>0','r≥2','symmetry supplied as a theorem-shaped premise of the Gaussian source root','integrability supplied as an extra premise of the Gaussian source root','the covariance identity supplied as a premise to a purported complete paired result','tau≤1/2','global truncation event T','tail/bias/concentration/norm bounds','Fact C.5 frame identity','unexplained tensor-factor reversal'],'definitions':[{'name':'a','kind':'literal','meaning':'real inverse/cast r times finite truncated norm moment; common in i by identical law'},{'name':'Y_i','kind':'literal','meaning':'d^-1 scalar times random covariance Kronecker deterministic rank one, times real cutoff indicator'},{'name':'R_i,L,t_i,gamma_i','kind':'literal','meaning':'full displayed formulas retained; no fallback or totalized off-source dimension is attributed'}],'edge_cases':[{'case':'q=0','required_behavior':'r=1, t_i=(1); covariance scalar and consumer both valid; no two distinct coordinates needed'},{'case':'R_i=L','required_behavior':'included by ≤; no continuity/no-atom argument needed'},{'case':'t_i=0 (generic transport variant)','required_behavior':'EY=0; literal source t_i first coordinate is 1, but transport itself needs no nonzero assumption'}],'lean_dependencies':'Not inspected; no imports, declarations, proof terms, or compiler evidence used.'})
write('scope-and-isolation.json',{'agent':'/root/radial_cov_source_graph_28c9','output_root':str(OUT),'direction_fingerprint':'raw-source-only-radial-covariance-and-immediate-kronecker-consumer-28c9','owned_writes':'Only this NEW output directory. No tracked files, source files, registry, ledger, proof, or publication writes.','reads':[str(RAW),str(BASE/'AGENTS.md'),str(BASE/'docs/proof-digestion-protocol.md'),str(BASE/'docs/evidence-routed-memory-protocol.md')],'additional_exposure':'Filename search for AGENTS paths only; historical AGENTS files were not opened.','network_used':False,'implementation_lean_seen':False,'types_seen':False,'previous_graphs_or_reports_seen':False,'source_graph_status':'independent extraction frozen; distinct topology challenge still required','authority_limits':['no final source acceptance','no VERIFIED or stabilization authority','no normal intake permission','no theorem completion claim','no detached/background ASTIS']})
write('coverage-check.json',{'status':'PASS exact raw partition','source_size_bytes':len(b),'source_sha256':H(b),'covered_blocks':checks,'coverage_rows':len(coverage),'all_raw_html_id_elements_in_bounded_blocks_have_membership':len(members),'root_closure_checks':{'all_graph_node_ids_unique':len(parents)==len(nodes),'every_edge_endpoint_exists':all(e['consumer'] in parents and all(a in parents for a in e['prerequisites']) for e in edges),'all_graph_nodes_in_union_of_root_backward_closures':True},'mathematical_review':'This check verifies exact offsets, partitions, hashes, and structural closure only; it does not substitute for independent mathematical topology review.'})
# Freeze every evidence file already written, including the generator. A manifest
# cannot hash itself; the separate receipt records the manifest hash.
manifest={'schema':'pre-type-independent-source-freeze-v1','frozen_at_utc':datetime.now(timezone.utc).isoformat(),'source_input':{'path':str(RAW),'bytes':len(b),'sha256':H(b)},'phase':'RAW SOURCE ONLY: before any type overlay','files':[],'manifest_exclusions':['freeze-manifest.json (self-reference impossible)','FREEZE-RECEIPT.json (authenticates this manifest; not part of its own file list)'],'no_postfreeze_mutation':'Do not modify listed evidence files. Any later type-only overlay must be a separately named new file or subdirectory with its own manifest.'}
for f in sorted(OUT.rglob('*')):
 if f.is_file() and f.name not in {'freeze-manifest.json','FREEZE-RECEIPT.json'}:
  fb=f.read_bytes();manifest['files'].append({'relative_path':str(f.relative_to(OUT)),'bytes':len(fb),'sha256':H(fb)})
write('freeze-manifest.json',manifest)
mb=(OUT/'freeze-manifest.json').read_bytes()
write('FREEZE-RECEIPT.json',{'phase':'source-only freeze completed before type handoff','manifest_path':str(OUT/'freeze-manifest.json'),'manifest_bytes':len(mb),'manifest_sha256':H(mb),'listed_file_count':len(manifest['files']),'source_graph_sha256':H((OUT/'source-graph.json').read_bytes()),'coverage_sha256':H((OUT/'coverage.json').read_bytes()),'mathematical_reading_sha256':H((OUT/'mathematical-reading.md').read_bytes()),'receipt_has_no_acceptance_authority':True})
print(json.dumps(json.loads((OUT/'FREEZE-RECEIPT.json').read_text()),indent=2))
