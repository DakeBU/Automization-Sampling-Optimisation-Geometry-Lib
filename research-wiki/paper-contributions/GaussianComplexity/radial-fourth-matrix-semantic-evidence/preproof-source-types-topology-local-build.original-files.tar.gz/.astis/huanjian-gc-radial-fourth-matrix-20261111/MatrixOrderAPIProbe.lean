import Mathlib
open MeasureTheory
open scoped Matrix.Norms.L2Operator MatrixOrder

#synth ClosedIciTopology (Matrix (Fin 2) (Fin 2) ℝ)
#synth PosSMulMono ℝ (Matrix (Fin 2) (Fin 2) ℝ)
#check integral_mono
#check integral_sub
#check Matrix.vecMulVec_mul_vecMulVec
#check Matrix.vecMulVec_smul
#check Matrix.smul_vecMulVec
#check Matrix.mul_kronecker_mul
#check Matrix.kronecker_smul
#check Matrix.smul_kronecker
#check Matrix.PosSemidef.smul
#check Matrix.le_iff
#check Matrix.posSemidef_vecMulVec_self_star
