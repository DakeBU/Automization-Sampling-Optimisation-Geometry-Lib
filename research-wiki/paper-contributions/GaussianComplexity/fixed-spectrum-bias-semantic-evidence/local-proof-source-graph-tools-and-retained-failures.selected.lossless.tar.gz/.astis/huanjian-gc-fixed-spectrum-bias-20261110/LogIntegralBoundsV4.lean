import Mathlib.Analysis.SpecialFunctions.Log.Deriv
import Mathlib.Analysis.SpecialFunctions.Integrals.Basic
import Mathlib.Tactic
noncomputable section
open MeasureTheory Set
open scoped Interval BigOperators

private theorem log_remainder_integral {a : ℝ} (ha0 : 0 ≤ a) (ha1 : a < 1) (n : ℕ) :
    (∫ t : ℝ in 0..a, (t ^ 2) ^ n / (1 - t ^ 2)) =
      1 / 2 * Real.log ((1 + a) / (1 - a)) -
        (∑ i ∈ Finset.range n, a ^ (2 * i + 1) / (2 * i + 1)) := by
  have hden (t : ℝ) (ht : t ∈ Set.uIcc 0 a) : 1 - t ^ 2 ≠ 0 := by
    rw [Set.uIcc_of_le ha0] at ht
    have ht0 : 0 ≤ t := ht.1
    have ht1 : t < 1 := ht.2.trans_lt ha1
    nlinarith
  have hi : IntervalIntegrable (fun t : ℝ => (t ^ 2) ^ n / (1 - t ^ 2)) volume 0 a := by
    apply ContinuousOn.intervalIntegrable
    exact ContinuousOn.div (by fun_prop) (by fun_prop) hden
  have hd (t : ℝ) (ht : t ∈ Set.uIcc 0 a) : HasDerivAt
      (fun x : ℝ => 1 / 2 * Real.log ((1 + x) / (1 - x)) -
        (∑ i ∈ Finset.range n, x ^ (2 * i + 1) / (2 * i + 1)))
      ((t ^ 2) ^ n / (1 - t ^ 2)) t := by
    rw [Set.uIcc_of_le ha0] at ht
    exact Real.hasDerivAt_half_log_one_add_div_one_sub_sub_sum_range n
      (by linarith [ht.1]) (ht.2.trans_lt ha1)
  have h := intervalIntegral.integral_eq_sub_of_hasDerivAt hd hi
  simpa using h

private theorem log_integral_identities {a : ℝ} (ha0 : 0 ≤ a) (ha1 : a < 1) :
    Real.log ((1 + a) / (1 - a)) = 2 * (∫ t : ℝ in 0..a, 1 / (1 - t ^ 2)) ∧
    Real.log ((1 + a) / (1 - a)) =
      2 * a + 2 * (∫ t : ℝ in 0..a, t ^ 2 / (1 - t ^ 2)) := by
  have h0 := log_remainder_integral ha0 ha1 0
  have h1 := log_remainder_integral ha0 ha1 1
  simp only [pow_zero, Finset.range_zero, Finset.sum_empty, sub_zero] at h0
  simp only [pow_one, Finset.range_one, Finset.sum_singleton] at h1
  constructor <;> linarith

private theorem log_integral_bounds {a : ℝ} (ha0 : 0 ≤ a) (ha1 : a < 1) :
    2 * a ≤ Real.log ((1 + a) / (1 - a)) ∧
    Real.log ((1 + a) / (1 - a)) ≤ 2 * a + 2 * a ^ 3 / (3 * (1 - a ^ 2)) := by
  have hpos (t : ℝ) (ht : t ∈ Set.Icc 0 a) : 0 < 1 - t ^ 2 := by
    have h0 := ht.1
    have h1 := ht.2.trans_lt ha1
    nlinarith
  have hcont (n : ℕ) : ContinuousOn (fun t : ℝ => (t ^ 2) ^ n / (1 - t ^ 2))
      (Set.uIcc 0 a) := by
    apply ContinuousOn.div (by fun_prop) (by fun_prop)
    intro t ht
    exact ne_of_gt (hpos t (by simpa only [Set.uIcc_of_le ha0] using ht))
  have hint0 : IntervalIntegrable (fun t : ℝ => 1 / (1 - t ^ 2)) volume 0 a := by
    simpa using (hcont 0).intervalIntegrable
  have hint1 : IntervalIntegrable (fun t : ℝ => t ^ 2 / (1 - t ^ 2)) volume 0 a := by
    simpa using (hcont 1).intervalIntegrable
  have hm0 : a ≤ (∫ t : ℝ in 0..a, 1 / (1 - t ^ 2)) := by
    calc
      a = (∫ _t : ℝ in 0..a, (1 : ℝ)) := by simp
      _ ≤ _ := intervalIntegral.integral_mono_on ha0
        ((by fun_prop : Continuous (fun _t : ℝ => (1 : ℝ))).intervalIntegrable 0 a) hint0 (by
        intro t ht
        apply (le_div_iff₀ (hpos t ht)).2
        nlinarith [sq_nonneg t])
  have hapos : 0 < 1 - a ^ 2 := hpos a ⟨ha0, le_rfl⟩
  have hm1 : (∫ t : ℝ in 0..a, t ^ 2 / (1 - t ^ 2)) ≤ a ^ 3 / (3 * (1 - a ^ 2)) := by
    calc
      _ ≤ (∫ t : ℝ in 0..a, t ^ 2 / (1 - a ^ 2)) :=
        intervalIntegral.integral_mono_on ha0 hint1
          ((by fun_prop : Continuous (fun t : ℝ => t ^ 2 / (1 - a ^ 2))).intervalIntegrable 0 a) (by
          intro t ht
          have hs : t ^ 2 ≤ a ^ 2 := pow_le_pow_left₀ ht.1 ht.2 2
          apply div_le_div_of_nonneg_left (sq_nonneg t) hapos
          linarith)
      _ = _ := by
        rw [intervalIntegral.integral_div, integral_pow]
        simp only [zero_pow (by norm_num : (3 : ℕ) ≠ 0), sub_zero]
        rw [div_div]
        norm_num
  rcases log_integral_identities ha0 ha1 with ⟨h0, h1⟩
  constructor
  · rw [h0]
    linarith
  · rw [h1]
    calc
      _ ≤ 2 * a + 2 * (a ^ 3 / (3 * (1 - a ^ 2))) :=
        add_le_add le_rfl (mul_le_mul_of_nonneg_left hm1 (show (0 : ℝ) ≤ 2 by norm_num))
      _ = _ := by ring
