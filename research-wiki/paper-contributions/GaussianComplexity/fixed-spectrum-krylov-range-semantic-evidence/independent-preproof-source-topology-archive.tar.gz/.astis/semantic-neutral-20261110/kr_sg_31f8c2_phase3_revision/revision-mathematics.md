# Source/dependency revision v2: R1 and R2

This is a new author version of the source graph and planned-type overlay. It supersedes only the identified representation/use-site records of the previously frozen versions; it does not overwrite them. The independent challenge was read as a challenge, followed by a fresh check of the original raw source and the exact image definition. The two requested revisions are supported for the reasons below. This judgment is not sourceV, independent topology approval, a statement repair, or evidence of any Lean proof or compiled edge. Exact-overlay rechecking remains for a distinct reviewer.

`source-graph.v2.json` and `type-source-overlay.v2.json` are full successor objects. `structured-delta-and-lineage.json` carries exact before/after records, immutable parent/input hashes, output hashes, source use sites and repair dispositions. All original coverage and source pins remain unchanged and referenced by hash. New directional and representation nodes refine already covered source passages; they do not create a new uncovered source region or alter any disposition.

## R1: the witness consumes reverse inclusion and the actual image definition

The reread original paragraph A3.SS2.p19.2, LF3804–3806, says to let u∈K_q and use Fact C.5 to write u=Bc. Its exact raw UTF8 SHA256 is `88c2408fcc6109c1d89566ee9a192425acd47e771f9410f7e270bd46fbd3f044`. The frozen P's actual `Set.range` definition was also rechecked at its pinned source bytes:

`range(f)={x | exists y, f(y)=x}`.

Thus the immediate representation step needs K_q⊆range(B), then existential-image definition unfolding. Once range(B)=K_q has been supplied, no second column-scaling or matrix-image/column-span theorem is needed at this use site. The original edge's parents C5.range and E.range-columns formed a sufficient conjunction, but represented a surplus immediate mathematical ingredient under this graph's necessity/use-site contract. This is a dependency-account correction, not a refutation of the mathematical conclusion.

The successor graph records `C5.range-reverse`, supplied by an explicit projection edge from `C5.range`. Its `e-witness` parents are now `C5.range-reverse` and `E.range-existential`, where the latter is expressly definition-only. The original `E.range-columns` and its parent occurrence inside `e-range` remain exactly unchanged. Accordingly, column-span/scaling facts still occur in the full backward closure through the source's range proof, while no longer masquerading as a second immediate witness theorem.

The full typed successor retains `P.reverse -> T.witness` and explicitly adds the same image-definition conversion. T still chooses one c for Bc=v and both exact quadratic identities. No new source or caller premise has been added.

The failure boundary is precise. Knowing only range(B)⊆K_q would not supply c for arbitrary u∈K_q. If range meant the linear span of an arbitrary nonlinear image, membership would not itself be a single image witness; this is excluded by the supplied literal `Set.range`, whose actual elements are Bc. Nonzero column scalings can matter to the earlier range proof without becoming a separate witness-use condition. No rank, uniqueness, distribution, event, or positivity assumption enters this definition conversion.

## R2: diagonal powers identify the actual matrix generators

The source explicitly defines Λ=diag(λ_i) in S4.E11 and K_q by actual Λ^j g_a generators in S4.Ex10. The reread A3.SS2.p3, LF3363–3376, uses the cosine-feature family and Λ^j g_a for every0≤j≤q. Its exact raw UTF8 SHA256 is `70a50b8444b84fbd1c589f08cfc7406de60df80ef880fbbaf0be8043a31b0d77`.

The scalar Chebyshev formula cos(jθ_i)=P_j(λ_i) does not by itself identify a scalar monomial evaluation with the actual matrix-power generator in K. That identification is elementary but meaning-carrying. The revised graph exposes `E.diagonal-power-action`:

((Λ^j).mulVec g)_i = λ_i^j g_i, for every natural j, including0.

The exact zero case is (Λ⁰g)_i=g_i=λ_i⁰g_i. No invertibility, nonzero g or nonzero λ_i is needed, since natural exponent0 gives1 and matrix exponent0 gives the identity matrix. For a successor power, diagonal row multiplication gives (Λh)_i=λ_i h_i; ordinary matrix composition and the preceding-power identity therefore give λ_i^(j+1)g_i. This is a mathematical justification of the missing representation bridge, not a Lean/API construction or a compiler-checked result.

For a finite polynomial P_j(X)=Σ_{m=0}^j h_jm X^m, finite distributivity then gives

((g_a)_i P_j(λ_i))_i = Σ_{m=0}^j h_jm (Λ^m).mulVec(g_a).

This weighted lift includes the constant term m=0 and is valid for every supplied g_a, including the zero vector. Now the scalar cosine/eigenvalue identity is expressed in the actual Krylov family. The triangular coefficient matrix with nonzero diagonal can then compare those two evaluated vector families. This neither requires nor proves independence of the evaluated vectors; its invertibility is at coefficient level.

The successor `e-span` explicitly consumes this bridge alongside scalar polynomial evaluation and the triangular span transformation. The typed successor adds internal `P.diagonal-action` and binds it at P.objects, P.polynomial and P.triangular. Every exact root signature, binder classification and literal local definition is unchanged. In particular, no `hdiag`, polynomial-evaluation certificate, range certificate or other caller hypothesis has been introduced. The bridge remains internal mathematical proof content, with no target/Lean/compiled discharge claimed.

The failure boundary is also exact. The formula needs the actual diagonal relation and ordinary matrix natural powers. For example, the nondiagonal real matrix [[0,1],[0,0]], vector g=(0,1), and j=1 give first coordinate1, whereas the diagonal-entry scalar formula with λ=(0,0) gives0. Treating exponent0 entrywise instead of as ordinary matrix power generally produces an all-ones matrix in dimension≥2, which is not the identity action. Negative exponents are outside the natural-power obligation. By contrast, q=0, zero g and zero eigenvalues cause no problem for this abstract bridge. The source's κ≥2 remains necessary for its separate nonconstant affine change of variables, not for the diagonal-power fact itself.

## Unchanged boundaries and remaining work

The core seal hash remains `f47e23a601d1a8e0ff4760224676313e0f1999877a97156841a65c01847e5d82`. P remains byte-identical at signature hash `4d5056d57aa0536b95af7aa9f7c3b6860ab7c9652b0bb306b6bad42434235ab6`, and T at `082eda7b36ecff3e87a62358e4f234b6d6c129b491405de3761fa83f79412969`. The full seal was hashed and only authorized name/file/signature/hash fields were programmatically compared; other seal fields were not displayed. The original selective packet and the source snapshot were rehashed. No target implementation or generic API was searched or read.

All C.5 conjuncts, its aggregate edge, the complete C.6 route, expectation-law projections, external leaves, probability/event assumptions, source contexts, target/output-use distinctions, literal metrics/normalizations, and zero cases remain separate and unchanged. The existing generic assembly wording on aggregate edges must still be read under their already stated source experiment and conditional conclusions; this revision does not turn a probabilistic aggregate into probability-free algebra. The two revisions introduce no OR-route. Both span inclusions and the common-coefficient quadratic conclusions remain conjunctive components.

All actual target proofs, compilation, axiom checks and observed compiler dependencies remain open, including the newly explicit internal diagonal-power/weighted-polynomial obligation. Source-only mathematical explanation does not discharge those future checks. No conclusion that the independent exact-overlay challenger has accepted this new version is made here.

Original Phase1 and Phase2 roots are read-only inputs. Their full file bytes/hashes, modes, inode, mtime and ctime were snapshotted at entry and are compared again at freeze. All writes and chmod operations are restricted to this new Phase3 sibling. Commands, exact executed scripts, raw stdout/stderr, exposure limits, and any actual failure are retained. No Phase3 failure or tool truncation had occurred when this mathematical report was authored; earlier Phase1 limitations remain preserved rather than rewritten.
