# Independent type-only freeze

Verdict: **SOURCE/TYPES ALIGNED AT THE STATEMENT LEVEL**. No source mismatch or extra mathematical premise is present in the two supplied signatures. This verdict applies only to the exact packet and definitions below. It does not certify a proof, the material use of the producer by the consumer, completeness of an unseen graph, compilation, source publication, or any process permission.

The raw freeze remains unchanged. Before this judgment I read only the new selective type/definition packet, my prior raw source material, and the already-read repository instructions. I did not read any supplied source graph, overlay, implementation, proof API, compiler history, prior packet report, or acceptance verdict. Receipt and provenance paths printed inside the packet were treated as identifying strings and were not opened.

## Exact evidence binding

- Selective packet: `.astis/huanjian-gc-radial-fourth-matrix-20261111/selective-type-definition-packet.json`, 16402 bytes, SHA256 `899221eab62ec75aa1eb8d90f62c4a2e86c154037b934042433b11acce08b6d2`.
- Statement seal named by the packet: `cc628d801ed367e1e57e99d69449d36a90b2803f7371986b964b4864409f6dec`. The separate seal document was not opened; this is the exact packet's binding, not an independently recomputed seal payload.
- Producer signature: 528 UTF-8 bytes, independently recomputed SHA256 `249edf1f3d15639eca0c0db2f827bca4981faf3648653ef83fb731abe564af32`.
- Consumer signature: 1237 UTF-8 bytes, independently recomputed SHA256 `d177e72a66ec143642b0518887a170f7906d9fc528a87ea399d02ee00842bfac`.
- Full canonical definition context: independently recomputed SHA256 `6e519e17615212c920c3e18e57c9dd416ac5addf2511a949c1bb8050b1adee43` using UTF-8 JSON with `ensure_ascii=False`, insertion-order keys, indentation 2, and one trailing newline.
- Current literal definition/instance print string: independently recomputed SHA256 `566cb351c515d58318f165c7cd2add1a6fba5994cb84ab241ae7b44b93e3a99d`.
- Shared canonical definition print string: independently recomputed SHA256 `f8da081a8f6886773ab72e7adf793fc042f9fa540467b57560db775c4b1bef10`.
- Raw source SHA256 remains `6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915`; raw judgment SHA256 remains `a1c17e48cc7f0e0c15fce3fca3329d68235aa7c944247dd598d8ec29a6b1b8e3`.

## Producer signature judgment

The only binders are natural `d`, natural `q`, and the source condition `hq : 2*q+1<d`. In particular, no fourth moment, mixed moment, radial identity, integrability certificate, independence certificate, or matrix expectation formula has been added as a public premise. The source natural-number context already has `q>=0`; `r=q+1` is positive and the source condition implies `d>=2`.

`E=EuclideanSpace R (Fin(q+1))` is the correct real Euclidean row space. Its radius `R x=||x||^2` is the unnormalized squared Euclidean radius in dimension `r`, independent of the number of rows `d`. The coordinate exposure `WithLp.ofLp x` leaves the coordinate values unchanged. `G x=vecMulVec(ofLp x)(ofLp x)` has entries `x_a*x_b`, so `weighted x=R x • G x` is precisely the source matrix `R gamma gamma^T`.

The measure is fixed to the actual `stdGaussian E`, whose supplied literal definition is the orthonormal-basis pushforward of a product of scalar `gaussianReal 0 1` laws. Thus the type selects the joint standard Gaussian law; it does not merely postulate normal marginals or isotropic covariance. The proof must still connect that definition to needed moments, symmetry, and integrability. These are implementation obligations, not missing source-facing binders.

The conclusion includes `Integrable weighted mu` as a result. The expectation is the matrix Bochner integral in the finite-dimensional real L2 operator-norm topology. The identity is the ordinary diagonal identity, and scalar multiplication by `r+2` has the required coefficient. This matches equation Ex113 and strengthens the source's implicit regularity by making it explicit as a conclusion. It prevents the nonintegrable-default-zero convention from substituting for the intended expectation.

Although the radial equality itself does not need `d` or `hq`, retaining the source's context is faithful and does not add a non-source premise.

## Consumer signature judgment

The only additional binder is `i : Fin d`. The canonical Gaussian variable `x` represents one source row `gamma_i`; all source rows have that same law. Cross-row independence is unnecessary for this individual expectation. There is no public cutoff-bound, tail-bound, feature-norm-bound, source sum identity, bias scalar, centering identity, or variance premise.

The supplied row angle is `((i.val : R)+1/2)*pi/d`. With source row `i_src=i.val+1`, this is exactly `(i_src-1/2)*pi/d`. The frequency index `k : Fin(q+1)` runs through `0,...,q`. Its zero coordinate is exactly 1, and each positive coordinate is `sqrt(2)*cos(k*theta_i)`. There is no midpoint shift, omitted constant coordinate, accidental last frequency `q+1`, or erroneous `sqrt(2)` multiplier on the constant coordinate.

`feature=vecMulVec(t i)(t i)` is the deterministic `t_i t_i^T`. The explicit finite sum `sum_k (t i k)^2` is the source squared Euclidean length. It avoids depending on any norm selected for a function type.

The cutoff `L=2*r+3*log(1000*d)` and closed event `R<=L` match the source. `Y` is `Set.indicator` of that event applied to `d^-1 • kronecker(G x,feature)`. It is zero outside the event and unnormalized inside. The paired matrix index is `(Gaussian coordinate, feature coordinate)`, agreeing with the source order `gamma tensor t`. The row's `d^-1/2` normalization is correctly squared in `Y` to `d^-1`.

`squared x=Y x * Y x` uses ordinary finite matrix multiplication. The supplied multiplication instance explicitly sums over the shared index. This is the actual matrix square, with the `d^-2` factor and one idempotent indicator after expansion; it is not the entrywise square.

The upper matrix is

\[
\frac{(r+2)\sum_k t_{i,k}^2}{d^2}
(I_r\otimes t_it_i^\top),
\]

exactly the frozen individual upper bound. The coefficient has one factor of squared feature length in addition to the outer-product feature matrix. It has no missing denominator, extra power of `d`, or extra scalar `r`.

`Matrix.PosSemidef (upper - integral squared)` is the correct Loewner statement. The supplied literal definition requires Hermitian symmetry and nonnegative quadratic forms against every finitely supported vector. Since the paired index set is finite and the scalar field is real, this tests every vector and reduces Hermitian symmetry to matrix symmetry. The statement does not confuse PSD order with entrywise order or an operator-norm scalar bound.

`Integrable squared mu` is a conclusion, so the consumer also cannot obtain its claimed expectation solely through the Bochner integral's nonintegrable default. The source-supported individual inference is correctly distinguished from the later displayed sum in the packet's attribution. Nothing in this type asserts the source sum, centering/variance bound, simultaneous event, Bernstein concentration, or Lemma 4.4.

## Zero-query test

For `q=0`, the assumptions allow every `d>=2`, `r=1`, and `i : Fin d`. There is one Gaussian coordinate and one feature coordinate. The only feature frequency is zero, so `t_i=(1)` and its explicit squared length is 1. The producer becomes the integrable scalar fourth moment with mean 3. The consumer becomes the integrable square of `d^-1 gamma^2 1_{gamma^2<=L}` with mean at most `3/d^2`. No binder or definition requires `q>0`, a second coordinate, or an off-diagonal case.

`r=0` is excluded by construction, matching the source. The `Fin d` binder is inhabited under `hq`; a vacuous row type at `d=0` cannot bypass the source assumptions.

## Deferred proof/topology challenges

The types themselves cannot show that the consumer materially uses both conjuncts of the producer, or that a supplied proof graph covers all ingredients. Those checks are deferred until a distinct graph challenge handoff. The previously frozen obligations remain: fourth and mixed Gaussian moments, quartic integrability, sign-symmetry cancellation, the exact square identity, indicator idempotence, tensor PSD, Loewner expectation transport, and deterministic tensor/scalar expectation extraction. The signatures introduce no premise that would discharge these obligations automatically.

TYPE-ONLY JUDGMENT FROZEN before any source-graph handoff. Awaiting the separately assigned topology challenge.
