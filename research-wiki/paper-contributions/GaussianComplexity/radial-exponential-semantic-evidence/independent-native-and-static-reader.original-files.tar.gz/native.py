import hashlib
import json
import os
from pathlib import Path
import shlex
import subprocess
import sys

REPO = Path('/Users/zhouhuanjian/ASTIS-GC')
HERE = Path(__file__).resolve().parent
COMMIT = 'c0bb993e3674181e33813d4b25fe655865e5ad0b'
SOURCE = HERE / 'snapshot'
OBJECTS = HERE / 'oleans'
P = 'AutoSamplingTheory/TechnicalLemmas/Probability/StdGaussianRadialExponential.lean'
T = 'Tests/GaussianComplexityRadialExponential.lean'
RN = 'AutoSamplingTheory/TechnicalLemmas/Measure/RadonNikodym.lean'
IG = 'AutoSamplingTheory/TechnicalLemmas/Measure/IsotropicGaussianDensity.lean'
SEAL = 'research-wiki/paper-contributions/GaussianComplexity/radial-exponential-statement-seal.json'
MAP = 'research-wiki/paper-contributions/GaussianComplexity/radial-exponential-semantic-evidence/source-lean-map.draft.json'
LESSON = 'website/content/declaration_lessons/huanjian-std-gaussian-radial-exponential.json'
FILES = ['lean-toolchain', 'lake-manifest.json', RN, IG, P, T, SEAL, MAP, LESSON]
EXPECTED = {P: 'c44b2840eb91a3abf29434bdf2baa9859b503f7a30c24c10ed3296e7f41c88e4',
            T: 'd80698f914312d2953bb1ac1a8f0a92d43a752389f0e14f6abcfa01563345443'}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def git(*args, cwd=REPO):
    return subprocess.check_output(['git', *args], cwd=cwd)


def snapshot(path):
    data = git('show', f'{COMMIT}:{path}')
    out = SOURCE / path
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_bytes(data)
    return {'path': path, 'git_blob': git('rev-parse', f'{COMMIT}:{path}').decode().strip(),
            'bytes': len(data), 'sha256': digest(data)}


def write_json(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')


def environment():
    toolchain = (SOURCE / 'lean-toolchain').read_text().strip()
    assert toolchain == 'leanprover/lean4:v4.33.0'
    lean = Path('/Users/zhouhuanjian/.elan/toolchains') / toolchain.replace('/', '--').replace(':', '---') / 'bin/lean'
    version = subprocess.check_output([lean, '--version'], cwd=REPO, text=True).strip()
    assert version.startswith('Lean (version 4.33.0,')
    package_root = REPO / '.lake/packages'
    packages = []
    for pin in json.loads((SOURCE / 'lake-manifest.json').read_text())['packages']:
        location = package_root / pin['name']
        head = git('rev-parse', 'HEAD', cwd=location).decode().strip()
        objects = location / '.lake/build/lib/lean'
        assert head == pin['rev'], (pin['name'], head, pin['rev'])
        packages.append({'name': pin['name'], 'pinned': pin['rev'], 'head': head,
                         'oleans': str(objects) if objects.is_dir() else None})
    assert len(packages) == 9
    paths = [str(OBJECTS), *(p['oleans'] for p in packages if p['oleans'])]
    env = os.environ.copy()
    for key in ('LEAN_SRC_PATH', 'LEAN_SYSROOT', 'LEAN_PATH'):
        env.pop(key, None)
    env['LEAN_PATH'] = os.pathsep.join(paths)
    return lean, env, {'toolchain': toolchain, 'lean': str(lean), 'version': version,
                       'lean_sha256': digest(lean.read_bytes()), 'packages': packages,
                       'LEAN_PATH': paths}


def compile_one(lean, env, path, logfile, emit=True):
    command = [str(lean), '--root=' + str(SOURCE)]
    if emit:
        out = (OBJECTS / path).with_suffix('.olean')
        out.parent.mkdir(parents=True, exist_ok=True)
        assert not out.exists()
        command += ['-o', str(out)]
    command += [str(SOURCE / path)]
    print(shlex.join(command), flush=True)
    result = subprocess.run(command, cwd=REPO, env=env, capture_output=True)
    logfile.write_bytes((f'cwd={REPO}\nLEAN_PATH={env["LEAN_PATH"]}\n' + shlex.join(command) +
                         f'\nexit_code={result.returncode}\n').encode() + result.stdout + result.stderr)
    print(f'exit={result.returncode} log={logfile.name}', flush=True)
    if result.returncode:
        print((result.stdout + result.stderr).decode(), flush=True)
        result.check_returncode()
    if emit:
        return {'path': path, 'olean': str(out.relative_to(HERE)), 'sha256': digest(out.read_bytes()),
                'bytes': out.stat().st_size, 'log': logfile.name}
    return result.stdout.decode()


if __name__ == '__main__':
    if len(sys.argv) == 1:
        assert not OBJECTS.exists(), 'Native compilation requires a fresh output directory'
        blobs = [snapshot(path) for path in FILES]
        for blob in blobs:
            if blob['path'] in EXPECTED:
                assert blob['sha256'] == EXPECTED[blob['path']], blob
        lean, env, details = environment()
        details.update(commit=COMMIT, blobs=blobs, cwd=str(REPO))
        write_json(HERE / 'environment.json', details)
        results = [compile_one(lean, env, path, HERE / f'compile-{index}-{Path(path).stem}.log')
                   for index, path in enumerate([RN, IG, P, T], start=1)]
        write_json(HERE / 'native-compilation.json', results)
    else:
        path, logfile = sys.argv[1:]
        lean, env, _ = environment()
        print(compile_one(lean, env, path, HERE / logfile, emit=False), end='')
