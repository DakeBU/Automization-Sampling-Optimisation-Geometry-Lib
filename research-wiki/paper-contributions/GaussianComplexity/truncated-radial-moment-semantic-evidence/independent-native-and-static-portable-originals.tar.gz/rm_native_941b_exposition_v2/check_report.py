from hashlib import sha256
import json
from pathlib import Path

out = Path(__file__).resolve().parent
prior = out.parent / 'rm_native_941b'
report = json.loads((out / 'static-result.json').read_text())
old = json.loads(next((prior / 'blobs/research-wiki').rglob('source-lean-map.draft.json')).read_text())
new = json.loads(next((out / 'blobs/research-wiki').rglob('source-lean-map.exposition-v2.json')).read_text())
assert old['actual_ASTIS_proof_parents'] == new['actual_ASTIS_proof_parents']
assert report['assertions'] and all(report['assertions'].values())
print('authored map parents identical', len(new['actual_ASTIS_proof_parents']))
print('source locators', sum(len(x['source']) for x in new['mappings']))
print('Lean spans', sum(len(x['lean']) for x in new['mappings']))
print('static assertions', len(report['assertions']))
for file in sorted((out / 'static-site').rglob('*.html')):
    data = file.read_bytes()
    print(file.relative_to(out), len(data), sha256(data).hexdigest())
