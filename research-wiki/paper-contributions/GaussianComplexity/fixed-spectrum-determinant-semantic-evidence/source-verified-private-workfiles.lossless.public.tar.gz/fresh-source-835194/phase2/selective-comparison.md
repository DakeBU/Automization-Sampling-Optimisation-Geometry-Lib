# Phase 2 selective source comparison

Reviewer `/root/reader_835194`; decoder `/root/decode_627304`; proving actor
`/root`. This is the second freeze before full-module exposure.

The frozen raw-source contract remains the independent baseline. The only new
input opened is the authorized `phase2-selective-input.json`, raw SHA-256
`524c23dd2fdd5e98c2e11c37de7f3aae4a3d7eb06e577700696e157ed103f38e`.

The anonymous statement and genuine independent reconstruction preserve the
bounded **actual-precision determinant/eigenvalue-product component**. No
blocking semantic delta is found for that component under the supplied
approved definition contexts. This does not issue a full-module fidelity
verdict or certify any normalizer/integral claim.

| Slot | Selective comparison |
|---|---|
| Objects | The actual (A=Ooperatorname{diag}(lambda)O^	op) is built locally and its genuine determinant is used. No conclusion-shaped determinant/eigenvalue premise is supplied. |
| Domains | (dinmathbb N, dge2), real (kappage2), and the full real orthogonal group match the source, including both determinant signs and both endpoints. |
| Quantifiers | Every allowed (d,kappa,O); every coordinate appears exactly once. The source random input draw is unnecessary to this pointwise identity. |
| Assumptions | The source numerical bounds are preserved. The square orthogonal carrier's two inverse identities are equivalent to the source one-equation definition. No integrability, spectrum-public or normalizer assumption appears. |
| Conclusion | Exactly the equality between the actual precision determinant and the full grid product. Separate positivity and normalization conclusions are outside its coverage. |
| Scopes/senses | Genuine determinant, full real (O(d)), no orientation filter, no absolute determinant, no probability/measure assertion. |
| Constants | Exact half-step grid, real fractions/casts, usual real (pi) and cosine. No additional constants or statistical parameters. |

The one-based source index (j=1,ldots,d) and anonymous zero-based index
(i=0,ldots,d-1) match by (j=i+1):

[
rac{(j-	frac12)pi}{d}
=rac{(i+	frac12)pi}{d}.
]

This bijection also preserves every factor in the finite product. All local
definitions use the same dimension, parameter and orthogonal element.

The source C.4 Gaussian normalizer, its unweighted integral interpretation,
conditional knowledge from a public spectrum, and actual density are absent
from the anonymous conclusion. This absence is appropriate to a bounded
determinant component; attributing those further results to this theorem alone
would exceed its content. The source real powers (d/2) and (-1/2) do not
occur in this determinant-only statement and receive no implementation
certification here. Full C.4 and the main query lower bound remain separate.

The blind reconstruction accurately states the anonymous theorem. Its
source-blind exposure is reported in the authorized file by the distinct
decoder; this reviewer has not opened the external neutral input or decoder
run. The raw approved-input, canonical packet, statement-string and
reconstruction-string hashes were recomputed and match. The supplied
`compiled=true` metadata has not been independently rechecked and is not
source-fidelity evidence.

Full production definitions, proof, module scope, canonical audit, authored
prose and publication coverage remain unexposed. Their consistency with this
selective statement and its approved contexts is deferred until explicit
Phase 3 authorization. No ledger, registry or shared file was changed. All
Phase 2 outputs are confined to the reviewer's previously authorized private
directory; the Phase 1 freeze is untouched.
