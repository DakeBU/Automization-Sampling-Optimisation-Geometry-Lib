from pathlib import Path
from html import unescape
import json,hashlib,re,datetime,stat
OWN=Path('/Users/zhouhuanjian/ASTIS-GC/.astis/semantic-neutral-20261110/z_sg_7d14a2')
def digest(b):return hashlib.sha256(b).hexdigest()
idx=json.loads((OWN/'raw-fragment-index.json').read_text())
raw=(OWN/'raw-original.html').read_bytes()
assert len(raw)==idx['source_bytes']==951991
assert digest(raw)==idx['source_sha256']=='6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
for e in idx['elements']+idx['fragments']:
 chunk=raw[e['start_byte']:e['end_byte_exclusive']]
 assert len(chunk)==e['bytes'] and digest(chunk)==e['sha256'],e['anchor']
 if 'file' in e:assert (OWN/e['file']).read_bytes()==chunk,e['file']
 if e['tag']=='math':
  m=re.search(rb'<annotation encoding="application/x-tex">(.*?)</annotation>',chunk,re.S)
  assert m and unescape(m.group(1).decode())==e['alttext'],e['anchor']
cov=json.loads((OWN/'source-coverage.json').read_text())
graph=json.loads((OWN/'source-graph.json').read_text())
units={e['anchor'] for e in idx['elements'] if e['tag'] in ('p','table')}
assert units=={e['anchor'] for e in cov['units']} and len(units)==21
assert len(cov['inline_and_display_formula_coverage'])==65
ids={n['id'] for n in graph['nodes']}
assert len(ids)==len(graph['nodes'])
for e in graph['edges']:
 assert e['consumer'] in ids and all(p in ids for p in e['parents'])
 assert e['consumer'] not in e['parents']
for u in cov['units']:
 assert u['disposition'] in ('NODE','EXCLUDED')
 assert (u['disposition']=='NODE' and u['nodes'] and all(n in ids for n in u['nodes'])) or (u['disposition']=='EXCLUDED' and u.get('reason'))
assert not any('C:main-theorem' in e['parents'] for e in graph['edges'])
# Mechanical DAG check only; it is not a mathematical/topology verdict.
adj={n:[] for n in ids}
for e in graph['edges']:
 for p in e['parents']:adj[p].append(e['consumer'])
visited=set();active=set()
def walk(n):
 assert n not in active,('cycle',n)
 if n in visited:return
 active.add(n)
 for c in adj[n]:walk(c)
 active.remove(n);visited.add(n)
for n in ids:walk(n)
report={'status':'PASS_MECHANICAL_ONLY','checked':'Exact raw bytes/offsets/hashes; five fragment byte equality; 65 math alttexts equal exact raw TeX annotations; exhaustive 21 substantive source units; node references and acyclic source-use structure.','not_checked':'Independent source fidelity/topology, mathematical proof validity, Lean statements/implementation/compilation, full main root closure.','counts':{'source_nodes':len(ids),'source_use_edges':len(graph['edges']),'substantive_units':len(units),'node_units':cov['node_units'],'excluded_units':cov['excluded_units'],'math_elements':65},'raw_source_sha256':digest(raw)}
(OWN/'mechanical-validation.json').write_text(json.dumps(report,indent=2)+'\n')
# Explicit own-directory enumeration only, after all authored payloads are complete.
payload=[]
for p in sorted(OWN.iterdir()):
 assert p.is_file(),p
 if p.name not in ('phase1-manifest.json','phase1-receipt.json'):
  b=p.read_bytes();payload.append({'file':p.name,'bytes':len(b),'sha256':digest(b),'frozen_mode':'0444'})
manifest={'schema':'phase1-source-freeze-manifest-v1','phase':'PHASE1_RAW_SOURCE_COGNITION_FROZEN','source_pin':idx['source_sha256'],'owned_directory':str(OWN),'payload_count':len(payload),'payloads':payload,'manifest_excludes':'Itself and phase1-receipt.json to avoid a self-hash cycle; receipt binds this manifest, and receipt digest is returned to coordinator out of band.','role_boundary':'SOURCE AUTHOR only; stop before target/Lean/code/old graph/old verdict exposure; independent review pending.'}
mb=(json.dumps(manifest,indent=2,ensure_ascii=False)+'\n').encode();(OWN/'phase1-manifest.json').write_bytes(mb)
receipt={'schema':'phase1-source-freeze-receipt-v1','phase':'PHASE1_RAW_SOURCE_COGNITION_FROZEN','frozen_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'manifest':{'file':'phase1-manifest.json','bytes':len(mb),'sha256':digest(mb)},'payload_count':len(payload),'source':{'bytes':len(raw),'sha256':digest(raw)},'all_packet_files_mode':'0444','directory_mode':'0555','prohibited_exposure_received':False,'independent_topology_or_source_acceptance':'not asserted; pending distinct reviewer','receipt_self_digest':'Delivered out of band after creation; not embedded here.'}
rb=(json.dumps(receipt,indent=2,ensure_ascii=False)+'\n').encode();(OWN/'phase1-receipt.json').write_bytes(rb)
for p in OWN.iterdir():p.chmod(0o444)
OWN.chmod(0o555)
for p in OWN.iterdir():assert stat.S_IMODE(p.stat().st_mode)==0o444
print(json.dumps({'receipt_path':str(OWN/'phase1-receipt.json'),'receipt_bytes':len(rb),'receipt_sha256':digest(rb),'manifest_path':str(OWN/'phase1-manifest.json'),'manifest_bytes':len(mb),'manifest_sha256':digest(mb),'payload_count':len(payload),'all_files_0444':True,'directory_0555':True,'mechanical_report':report},indent=2))
