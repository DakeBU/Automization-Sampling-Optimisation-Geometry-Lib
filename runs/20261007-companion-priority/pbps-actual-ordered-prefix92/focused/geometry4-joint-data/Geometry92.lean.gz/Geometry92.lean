import AutoSamplingTheory.ExampleCases.ProximalBPS.ActualAbsoluteNextEventTime
import Mathlib.MeasureTheory.Constructions.Pi

/-! Internal proof development for sealed92, not a completed public theorem. -/
namespace OrderedPrefix92
open MeasureTheory ProbabilityTheory InnerProductSpace
open scoped NNReal ENNReal Topology ContDiff Interval
noncomputable section
set_option autoImplicit false

private theorem measurable_cons_zero (n : ℕ) (j : Fin (n + 1)) :
    Measurable (fun t : Fin n → ℝ => (Fin.cons (0 : ℝ) t : Fin (n + 1) → ℝ) j) := by
  induction j using Fin.cases with
  | zero => simpa only [Fin.cons_zero] using (measurable_const : Measurable (fun _ : Fin n → ℝ => (0 : ℝ)))
  | succ i => simpa only [Fin.cons_succ] using (measurable_pi_apply i : Measurable (fun t : Fin n → ℝ => t i))

private theorem simplex_measurable (n : ℕ) (T : ℝ≥0) :
    MeasurableSet {t : Fin n → ℝ |
      StrictMono (Fin.cons (0 : ℝ) t) ∧ ∀ i, t i < (T : ℝ)} := by
  simp only [StrictMono, Set.ofPred_and, Set.ofPred_forall]
  apply MeasurableSet.inter
  · exact MeasurableSet.iInter fun i => MeasurableSet.iInter fun j =>
      MeasurableSet.iInter fun _ => measurableSet_lt (measurable_cons_zero n i) (measurable_cons_zero n j)
  · exact MeasurableSet.iInter fun i => measurableSet_lt (measurable_pi_apply i) measurable_const

private def readTime {Z : Type*} (r : (ℝ≥0 × Z) ⊕ Unit) : ℝ :=
  match r with
  | Sum.inl q => q.1
  | Sum.inr _ => 0

private theorem readTime_measurable {Z : Type*} [MeasurableSpace Z] :
    Measurable (@readTime Z) := by
  apply Measurable.sumElim
  · exact measurable_coe_nnreal_real.comp measurable_fst
  · exact measurable_const

private theorem live_measurable {Z : Type*} [MeasurableSpace Z] :
    MeasurableSet {r : (ℝ≥0 × Z) ⊕ Unit | ∃ a, r = Sum.inl a} := by
  have heq : {r : (ℝ≥0 × Z) ⊕ Unit | ∃ a, r = Sum.inl a} = Set.range Sum.inl := by
    ext r
    simp only [Set.mem_ofPred_eq, Set.mem_range, eq_comm]
  rw [heq]
  exact measurableSet_range_inl

private theorem history_guard_measurable {Z : Type*} [MeasurableSpace Z] (n : ℕ) (T : ℝ≥0) :
    MeasurableSet {h : Fin (n + 1) → ((ℝ≥0 × Z) ⊕ Unit) |
      (∀ j, ∃ a : ℝ≥0 × Z, h j = Sum.inl a) ∧
      StrictMono (fun j => readTime (h j)) ∧
      ∀ i : Fin n, readTime (h i.succ) < (T : ℝ)} := by
  simp only [StrictMono, Set.ofPred_and, Set.ofPred_forall]
  apply MeasurableSet.inter
  · exact MeasurableSet.iInter fun j => live_measurable.preimage (measurable_pi_apply j)
  · apply MeasurableSet.inter
    · exact MeasurableSet.iInter fun i => MeasurableSet.iInter fun j =>
        MeasurableSet.iInter fun _ => measurableSet_lt
          (readTime_measurable.comp (measurable_pi_apply i))
          (readTime_measurable.comp (measurable_pi_apply j))
    · exact MeasurableSet.iInter fun i => measurableSet_lt
        (readTime_measurable.comp (measurable_pi_apply i.succ)) measurable_const


private theorem ordered_prefix_borel_data
    {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℝ E]
    [FiniteDimensional ℝ E] [MeasurableSpace E] [BorelSpace E]
    {V : E → ℝ} {α β : ℝ≥0} {η : ℝ}
    (hα : 0 < (α : ℝ)) (hαβ : α ≤ β) (hV : ContDiff ℝ 2 V)
    (hH : ∀ x v : E,
      (α : ℝ) * ‖v‖ ^ 2 ≤ (fderiv ℝ (fderiv ℝ V) x v) v ∧
      (fderiv ℝ (fderiv ℝ V) x v) v ≤ (β : ℝ) * ‖v‖ ^ 2)
    (hη : 0 < η) (hβη : (β : ℝ) * η ≤ 1) :
    let c : E → E → E := fun y xRef => y - η • gradient V xRef
    let Φ : E → E → ℝ → (E × E) → (E × E) := fun y xRef t z =>
      (c y xRef + Real.cos t • (z.1 - c y xRef) +
          (Real.sqrt η * Real.sin t) • z.2,
       (-Real.sin t / Real.sqrt η) • (z.1 - c y xRef) + Real.cos t • z.2)
    let S : E → (E × E) → (E × E) := fun xRef z =>
      (z.1, z.2 - (2 * inner ℝ z.2 (gradient V z.1 - gradient V xRef) /
        ‖gradient V z.1 - gradient V xRef‖ ^ 2) • (gradient V z.1 - gradient V xRef))
    let rate : E → (E × E) → ℝ := fun xRef z =>
      Real.sqrt η * max 0 (inner ℝ z.2 (gradient V z.1 - gradient V xRef))
    let Λ : E → E → (E × E) → ℝ≥0 → ℝ := fun y xRef z t =>
      ∫ s in (0 : ℝ)..(t : ℝ), rate xRef (Φ y xRef s z)
    let τ : E → E → (E × E) → ℝ≥0 → WithTop ℝ≥0 := fun y xRef z e =>
      MeasureTheory.hittingAfter
        (fun t : ℝ≥0 => fun a : (E × E) × (E × E) × ℝ≥0 =>
          Λ a.1.1 a.1.2 a.2.1 t - (a.2.2 : ℝ))
        (Set.Ici (0 : ℝ)) 0 ((y, xRef), z, e)
    let next : E → E → ℝ≥0 → ((ℝ≥0 × (E × E)) ⊕ Unit) →
        ((ℝ≥0 × (E × E)) ⊕ Unit) := fun y xRef e r =>
      match r with
      | Sum.inr _ => Sum.inr ()
      | Sum.inl a =>
        if τ y xRef a.2 e = ⊤ then Sum.inr () else
          Sum.inl (a.1 + (τ y xRef a.2 e).untopD 0,
            S xRef (Φ y xRef (((τ y xRef a.2 e).untopD 0 : ℝ≥0) : ℝ) a.2))
    let record : E → E → (E × E) → (ℕ → ℝ≥0) → ℕ →
        ((ℝ≥0 × (E × E)) ⊕ Unit) := fun y xRef z₀ e n =>
      Nat.rec (Sum.inl (0, z₀)) (fun k r => next y xRef (e k) r) n
    let P : Measure (ℕ → ℝ) := Measure.infinitePi (fun _ : ℕ => expMeasure (1 : ℝ))
    let ε : (ℕ → ℝ) → ℕ → ℝ≥0 := fun w k => Real.toNNReal (w k)
    let history : E → E → (E × E) → (n : ℕ) → (ℕ → ℝ) →
        (Fin (n + 1) → ((ℝ≥0 × (E × E)) ⊕ Unit)) :=
      fun y xRef z₀ n w j => record y xRef z₀ (ε w) j.val
    let Rec := (ℝ≥0 × (E × E)) ⊕ Unit
    let Hist : ℕ → Type _ := fun n => Fin (n + 1) → Rec
    let readTime : Rec → ℝ := fun r => match r with
      | Sum.inl q => (q.1 : ℝ)
      | Sum.inr _ => 0
    let Δ : (n : ℕ) → ℝ≥0 → Set (Fin n → ℝ) := fun n T =>
      {t | StrictMono (Fin.cons (0 : ℝ) t) ∧ ∀ i, t i < (T : ℝ)}
    let Prefix : (n : ℕ) → ℝ≥0 → Type := fun n T => {t : Fin n → ℝ // t ∈ Δ n T}
    let m : (n : ℕ) → (T : ℝ≥0) → Measure (Prefix n T) := fun n T =>
      Measure.comap (fun t : Prefix n T => t.val) (volume : Measure (Fin n → ℝ))
    let zAt : E → E → (E × E) → (n : ℕ) → (T : ℝ≥0) →
        Prefix n T → Fin (n + 1) → (E × E) := fun y xRef z₀ n T t =>
      Fin.induction z₀ (fun i z =>
        S xRef (Φ y xRef (t.val i - (Fin.cons (0 : ℝ) (t.val : Fin n → ℝ) : Fin (n + 1) → ℝ) i.castSucc) z))
    let K : E → E → (E × E) → (n : ℕ) → (T : ℝ≥0) →
        Prefix n T → Hist n := fun y xRef z₀ n T t j =>
      Sum.inl (Real.toNNReal ((Fin.cons (0 : ℝ) (t.val : Fin n → ℝ) : Fin (n + 1) → ℝ) j), zAt y xRef z₀ n T t j)
    let qReal : E → E → (E × E) → (n : ℕ) → (T : ℝ≥0) →
        Prefix n T → ℝ := fun y xRef z₀ n T t =>
      ∏ i : Fin n,
        rate xRef (Φ y xRef (t.val i - (Fin.cons (0 : ℝ) (t.val : Fin n → ℝ) : Fin (n + 1) → ℝ) i.castSucc)
          (zAt y xRef z₀ n T t i.castSucc)) *
        Real.exp (-Λ y xRef (zAt y xRef z₀ n T t i.castSucc)
          (Real.toNNReal (t.val i - (Fin.cons (0 : ℝ) (t.val : Fin n → ℝ) : Fin (n + 1) → ℝ) i.castSucc)))
    let q : E → E → (E × E) → (n : ℕ) → (T : ℝ≥0) →
        Prefix n T → ℝ≥0∞ := fun y xRef z₀ n T t =>
      ENNReal.ofReal (qReal y xRef z₀ n T t)
    let A : (n : ℕ) → ℝ≥0 → Set (Hist n) := fun n T =>
      {h | (∀ j, ∃ a : ℝ≥0 × (E × E), h j = Sum.inl a) ∧
        StrictMono (fun j => readTime (h j)) ∧
        ∀ i : Fin n, readTime (h i.succ) < (T : ℝ)}
    ∀ n : ℕ, ∀ T : ℝ≥0,
      MeasurableSet (Δ n T) ∧ MeasurableSet (A n T) ∧
      Measurable (fun p : ((E × E) × (E × E)) × Prefix n T =>
        K p.1.1.1 p.1.1.2 p.1.2 n T p.2) ∧
      Measurable (fun p : ((E × E) × (E × E)) × Prefix n T =>
        q p.1.1.1 p.1.1.2 p.1.2 n T p.2) ∧
      (∀ y xRef : E, ∀ z₀ : E × E, ∀ t : Prefix n T, 0 ≤ qReal y xRef z₀ n T t) := by
  classical
  let c : E → E → E := fun y xRef => y - η • gradient V xRef
  let Φ : E → E → ℝ → (E × E) → (E × E) := fun y xRef t z =>
    (c y xRef + Real.cos t • (z.1 - c y xRef) +
        (Real.sqrt η * Real.sin t) • z.2,
     (-Real.sin t / Real.sqrt η) • (z.1 - c y xRef) + Real.cos t • z.2)
  let S : E → (E × E) → (E × E) := fun xRef z =>
    (z.1, z.2 - (2 * inner ℝ z.2 (gradient V z.1 - gradient V xRef) /
      ‖gradient V z.1 - gradient V xRef‖ ^ 2) • (gradient V z.1 - gradient V xRef))
  let rate : E → (E × E) → ℝ := fun xRef z =>
    Real.sqrt η * max 0 (inner ℝ z.2 (gradient V z.1 - gradient V xRef))
  let Λ : E → E → (E × E) → ℝ≥0 → ℝ := fun y xRef z t =>
    ∫ s in (0 : ℝ)..(t : ℝ), rate xRef (Φ y xRef s z)
  let τ : E → E → (E × E) → ℝ≥0 → WithTop ℝ≥0 := fun y xRef z e =>
    MeasureTheory.hittingAfter
      (fun t : ℝ≥0 => fun a : (E × E) × (E × E) × ℝ≥0 =>
        Λ a.1.1 a.1.2 a.2.1 t - (a.2.2 : ℝ))
      (Set.Ici (0 : ℝ)) 0 ((y, xRef), z, e)
  let next : E → E → ℝ≥0 → ((ℝ≥0 × (E × E)) ⊕ Unit) →
      ((ℝ≥0 × (E × E)) ⊕ Unit) := fun y xRef e r =>
    match r with
    | Sum.inr _ => Sum.inr ()
    | Sum.inl a =>
      if τ y xRef a.2 e = ⊤ then Sum.inr () else
        Sum.inl (a.1 + (τ y xRef a.2 e).untopD 0,
          S xRef (Φ y xRef (((τ y xRef a.2 e).untopD 0 : ℝ≥0) : ℝ) a.2))
  let record : E → E → (E × E) → (ℕ → ℝ≥0) → ℕ →
      ((ℝ≥0 × (E × E)) ⊕ Unit) := fun y xRef z₀ e n =>
    Nat.rec (Sum.inl (0, z₀)) (fun k r => next y xRef (e k) r) n
  let P : Measure (ℕ → ℝ) := Measure.infinitePi (fun _ : ℕ => expMeasure (1 : ℝ))
  let ε : (ℕ → ℝ) → ℕ → ℝ≥0 := fun w k => Real.toNNReal (w k)
  let history : E → E → (E × E) → (n : ℕ) → (ℕ → ℝ) →
      (Fin (n + 1) → ((ℝ≥0 × (E × E)) ⊕ Unit)) :=
    fun y xRef z₀ n w j => record y xRef z₀ (ε w) j.val
  let Rec := (ℝ≥0 × (E × E)) ⊕ Unit
  let Hist : ℕ → Type _ := fun n => Fin (n + 1) → Rec
  let readTime : Rec → ℝ := fun r => match r with
    | Sum.inl q => (q.1 : ℝ)
    | Sum.inr _ => 0
  let Δ : (n : ℕ) → ℝ≥0 → Set (Fin n → ℝ) := fun n T =>
    {t | StrictMono (Fin.cons (0 : ℝ) t) ∧ ∀ i, t i < (T : ℝ)}
  let Prefix : (n : ℕ) → ℝ≥0 → Type := fun n T => {t : Fin n → ℝ // t ∈ Δ n T}
  let m : (n : ℕ) → (T : ℝ≥0) → Measure (Prefix n T) := fun n T =>
    Measure.comap (fun t : Prefix n T => t.val) (volume : Measure (Fin n → ℝ))
  let zAt : E → E → (E × E) → (n : ℕ) → (T : ℝ≥0) →
      Prefix n T → Fin (n + 1) → (E × E) := fun y xRef z₀ n T t =>
    Fin.induction z₀ (fun i z =>
      S xRef (Φ y xRef (t.val i - (Fin.cons (0 : ℝ) (t.val : Fin n → ℝ) : Fin (n + 1) → ℝ) i.castSucc) z))
  let K : E → E → (E × E) → (n : ℕ) → (T : ℝ≥0) →
      Prefix n T → Hist n := fun y xRef z₀ n T t j =>
    Sum.inl (Real.toNNReal ((Fin.cons (0 : ℝ) (t.val : Fin n → ℝ) : Fin (n + 1) → ℝ) j), zAt y xRef z₀ n T t j)
  let qReal : E → E → (E × E) → (n : ℕ) → (T : ℝ≥0) →
      Prefix n T → ℝ := fun y xRef z₀ n T t =>
    ∏ i : Fin n,
      rate xRef (Φ y xRef (t.val i - (Fin.cons (0 : ℝ) (t.val : Fin n → ℝ) : Fin (n + 1) → ℝ) i.castSucc)
        (zAt y xRef z₀ n T t i.castSucc)) *
      Real.exp (-Λ y xRef (zAt y xRef z₀ n T t i.castSucc)
        (Real.toNNReal (t.val i - (Fin.cons (0 : ℝ) (t.val : Fin n → ℝ) : Fin (n + 1) → ℝ) i.castSucc)))
  let q : E → E → (E × E) → (n : ℕ) → (T : ℝ≥0) →
      Prefix n T → ℝ≥0∞ := fun y xRef z₀ n T t =>
    ENNReal.ofReal (qReal y xRef z₀ n T t)
  let A : (n : ℕ) → ℝ≥0 → Set (Hist n) := fun n T =>
    {h | (∀ j, ∃ a : ℝ≥0 × (E × E), h j = Sum.inl a) ∧
      StrictMono (fun j => readTime (h j)) ∧
      ∀ i : Fin n, readTime (h i.succ) < (T : ℝ)}
  change ∀ n : ℕ, ∀ T : ℝ≥0,
      MeasurableSet (Δ n T) ∧ MeasurableSet (A n T) ∧
      Measurable (fun p : ((E × E) × (E × E)) × Prefix n T =>
        K p.1.1.1 p.1.1.2 p.1.2 n T p.2) ∧
      Measurable (fun p : ((E × E) × (E × E)) × Prefix n T =>
        q p.1.1.1 p.1.1.2 p.1.2 n T p.2) ∧
      (∀ y xRef : E, ∀ z₀ : E × E, ∀ t : Prefix n T, 0 ≤ qReal y xRef z₀ n T t)
  have hΦ : Measurable (fun a : (E × E) × ℝ × (E × E) =>
      Φ a.1.1 a.1.2 a.2.1 a.2.2) :=
    (AutoSamplingTheory.ExampleCases.ProximalBPS.ActualHarmonicFlow.actual_harmonic_flow_laws
      hα hαβ hV hH hη hβη).2.1
  have hb := AutoSamplingTheory.ExampleCases.ProximalBPS.ActualBounceRate.actual_bounce_rate_energy_laws
    hα hαβ hV hH hη hβη
  have hS : Measurable (fun a : E × (E × E) => S a.1 a.2) := hb.1
  have hr : Measurable (fun a : E × (E × E) => rate a.1 a.2) := hb.2.2.1
  have hΛ : Measurable (fun a : ((E × E) × (E × E)) × ℝ≥0 =>
      Λ a.1.1.1 a.1.1.2 a.1.2 a.2) :=
    (AutoSamplingTheory.ExampleCases.ProximalBPS.ActualHazardClock.actual_integrated_hazard_clock_laws
      hα hαβ hV hH hη hβη).2.1
  intro n T
  have hd (i : Fin n) : Measurable (fun p : ((E × E) × (E × E)) × Prefix n T =>
      p.2.val i - (Fin.cons (0 : ℝ) (p.2.val : Fin n → ℝ) : Fin (n+1) → ℝ) i.castSucc) :=
    ((measurable_pi_apply i).comp measurable_snd.subtype_val).sub
      ((measurable_cons_zero n i.castSucc).comp measurable_snd.subtype_val)
  have hz (j : Fin (n + 1)) :
      Measurable (fun p : ((E × E) × (E × E)) × Prefix n T =>
        zAt p.1.1.1 p.1.1.2 p.1.2 n T p.2 j) := by
    induction j using Fin.induction with
    | zero => simpa only [zAt, Fin.induction_zero] using
        (measurable_fst.snd : Measurable (fun p : ((E × E) × (E × E)) × Prefix n T => p.1.2))
    | succ i ih =>
      change Measurable (fun p : ((E × E) × (E × E)) × Prefix n T =>
        S p.1.1.2 (Φ p.1.1.1 p.1.1.2
          (p.2.val i - (Fin.cons (0 : ℝ) (p.2.val : Fin n → ℝ) : Fin (n+1) → ℝ) i.castSucc)
          (zAt p.1.1.1 p.1.1.2 p.1.2 n T p.2 i.castSucc)))
      exact hS.comp (measurable_fst.fst.snd.prodMk
        (hΦ.comp (measurable_fst.fst.prodMk ((hd i).prodMk ih))))
  have hf (i : Fin n) : Measurable (fun p : ((E × E) × (E × E)) × Prefix n T =>
      Φ p.1.1.1 p.1.1.2
        (p.2.val i - (Fin.cons (0 : ℝ) (p.2.val : Fin n → ℝ) : Fin (n+1) → ℝ) i.castSucc)
        (zAt p.1.1.1 p.1.1.2 p.1.2 n T p.2 i.castSucc)) :=
    hΦ.comp (measurable_fst.fst.prodMk ((hd i).prodMk (hz i.castSucc)))
  refine ⟨simplex_measurable n T, history_guard_measurable n T, ?_, ?_, ?_⟩
  · apply measurable_pi_lambda
    intro j
    exact measurable_inl.comp (((measurable_cons_zero n j).comp
      measurable_snd.subtype_val).real_toNNReal.prodMk (hz j))
  · apply Measurable.ennreal_ofReal
    apply Finset.measurable_prod
    intro i _
    exact (hr.comp (measurable_fst.fst.snd.prodMk (hf i))).mul
      ((hΛ.comp ((measurable_fst.fst.prodMk (hz i.castSucc)).prodMk
        (hd i).real_toNNReal)).neg.exp)
  · intro y xRef z₀ t
    apply Finset.prod_nonneg
    intro i _
    exact mul_nonneg (mul_nonneg (Real.sqrt_nonneg η) (le_max_left 0 _))
      (Real.exp_pos _).le

end
end OrderedPrefix92
