"""Verify and read bounded slices of the pinned original arXiv HTML."""

import hashlib
import re
from html import unescape
from pathlib import Path


SOURCE = Path(".astis/huanjian-resume-20261103/2610.20492v1.html")
EXPECTED_BYTES = 951991
EXPECTED_SHA256 = "6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915"

# The ranges are one-based and inclusive. Each names a raw locator to check.
SPANS = (
    ("source title", 281, 281, "On Complexity of Gaussian Sampling"),
    ("hard-family grid", 1082, 1104, 'id="S4.E11"'),
    ("Krylov Gaussian input", 1157, 1177, 'id="S4.Thmtheorem3"'),
    ("parent Lemma 4.4 setup", 1191, 1233, 'id="S4.Thmtheorem4"'),
    ("Gaussian rows and deterministic tensor factor", 3314, 3329, 'id="A3.Ex85"'),
    ("Fact C.5 dimensions and matrix moments", 3330, 3360, 'id="A3.Ex87"'),
    ("Fact C.6 concentration boundary", 3509, 3531, 'id="A3.Ex103"'),
    ("scalar moment, strict tail, simultaneous event", 3532, 3556, 'id="A3.Ex104"'),
    ("shifted tail and scalar bias consumer", 3557, 3569, 'id="A3.Ex106"'),
    ("truncated matrices and bias consumer", 3570, 3607, 'id="A3.Ex109"'),
    ("original versus truncated sums", 3743, 3763, 'id="A3.Ex126"'),
)

MATH = re.compile(r'<math\s+id="([^"]+)"[^>]*?\balttext="([^"]*)"[^>]*>.*?</math>', re.DOTALL)
ELEMENT = re.compile(r'<(?:p|div|table|section|tbody)\s+id="([^"]+)"[^>]*>')
TAG = re.compile(r"<[^>]+>")


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def compact_view(fragment: str) -> str:
    with_placeholders = []

    def preserve_math(match: re.Match[str]) -> str:
        with_placeholders.append(f"[{match[1]} | {unescape(match[2])}]")
        return f"__MATH_{len(with_placeholders) - 1}__"

    fragment = MATH.sub(preserve_math, fragment)
    fragment = ELEMENT.sub(lambda m: f"{{{m[1]}}} ", fragment)
    fragment = unescape(TAG.sub("", fragment))
    fragment = re.sub(r"__MATH_(\d+)__", lambda m: with_placeholders[int(m[1])], fragment)
    return "\n".join(line.strip() for line in fragment.splitlines() if line.strip())


def main() -> None:
    raw = SOURCE.read_bytes()
    actual_sha256 = sha256(raw)
    if len(raw) != EXPECTED_BYTES or actual_sha256 != EXPECTED_SHA256:
        raise RuntimeError(f"Source pin mismatch: {len(raw)} bytes, {actual_sha256}")
    print(f"source={SOURCE}")
    print(f"bytes={len(raw)} sha256={actual_sha256}")
    print("Read view uses original MathML alttext; the byte ranges bind the original HTML.")

    lines = raw.splitlines(keepends=True)
    for label, first, last, locator in SPANS:
        start = sum(map(len, lines[: first - 1]))
        block = b"".join(lines[first - 1 : last])
        fragment = block.decode("utf-8")
        if locator not in fragment:
            raise RuntimeError(f"Locator {locator!r} absent from {first}-{last}")
        print(f"\n{label}\nlines={first}-{last} bytes=[{start},{start + len(block)}) sha256={sha256(block)}")
        print(compact_view(fragment))
    print("\nAll source slices matched.")


if __name__ == "__main__":
    main()
