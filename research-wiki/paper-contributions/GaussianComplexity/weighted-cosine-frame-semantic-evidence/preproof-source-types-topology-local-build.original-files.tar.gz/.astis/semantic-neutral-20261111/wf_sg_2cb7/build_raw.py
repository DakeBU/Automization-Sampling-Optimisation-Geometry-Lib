from pathlib import Path
from html.parser import HTMLParser
import hashlib
import html
import json
import re
import shutil

ROOT = Path('/Users/zhouhuanjian/ASTIS-GC')
OUT = ROOT / '.astis/semantic-neutral-20261111/wf_sg_2cb7'
SRC = ROOT / '.astis/huanjian-resume-20261103/2610.20492v1.html'
OUT.mkdir(parents=True, exist_ok=True)
blob = SRC.read_bytes()
text = blob.decode('utf-8')
assert len(blob) == 951991
assert hashlib.sha256(blob).hexdigest() == '6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'

def sha(b):
    return hashlib.sha256(b).hexdigest()

def write(name, obj):
    (OUT / name).write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n')

line_offsets = [0]
line_offsets.extend(m.end() for m in re.finditer('\n', text))
byte_offsets = [0]
for c in text:
    byte_offsets.append(byte_offsets[-1] + len(c.encode('utf-8')))

class Spans(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=False)
        self.stack = []
        self.items = {}
    def pos(self):
        line, col = self.getpos()
        return line_offsets[line - 1] + col
    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag in {'area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr'}:
            return
        self.stack.append((tag, attrs.get('id'), self.pos(), attrs))
    def handle_startendtag(self, tag, attrs):
        attrs = dict(attrs)
        if attrs.get('id'):
            self.items[attrs['id']] = (self.pos(), self.pos() + len(self.get_starttag_text()), tag, attrs)
    def handle_endtag(self, tag):
        if not self.stack:
            return
        idx = next((i for i in range(len(self.stack)-1,-1,-1) if self.stack[i][0] == tag), None)
        if idx is None:
            return
        ending = text.find('>', self.pos()) + 1
        closing = self.stack[idx:]
        self.stack = self.stack[:idx]
        for open_tag, identity, start, attrs in closing:
            if identity:
                self.items[identity] = (start, ending, open_tag, attrs)

parser = Spans()
parser.feed(text)

def locator(identity):
    a, b, tag, attrs = parser.items[identity]
    return {
        'source_html_id': identity,
        'tag': tag,
        'char_start_0': a,
        'char_end_0_exclusive': b,
        'byte_start_0': byte_offsets[a],
        'byte_end_0_exclusive': byte_offsets[b],
        'line_start_1': text.count('\n', 0, a) + 1,
        'line_end_1_inclusive': text.count('\n', 0, b - 1) + 1,
        'raw_utf8_sha256': sha(text[a:b].encode()),
    }

def readable(identity):
    a,b,_,_ = parser.items[identity]
    t = text[a:b]
    t = re.sub(r'<math\b[^>]*alttext="([^"]*)".*?</math>', lambda m: m.group(1), t, flags=re.S)
    return html.unescape(re.sub(r'<[^>]*>', '', t)).strip()

instructions = [
    'AGENTS.md',
    'docs/formalization-protocol.md',
    'docs/theorem-publication-protocol.md',
    'docs/proof-digestion-protocol.md',
    'docs/evidence-routed-memory-protocol.md',
    '.agents/skills/astis-semantic-roundtrip/SKILL.md',
    '.agents/skills/astis-source-dependency-audit/SKILL.md',
    '.agents/skills/astis-conversion-window/SKILL.md',
]
(OUT / 'inputs').mkdir(exist_ok=True)
(OUT / 'inputs/2610.20492v1.html').write_bytes(blob)
instruction_manifest = []
for p in instructions:
    b = (ROOT / p).read_bytes()
    destination = 'inputs/' + p.replace('/', '__') + '.raw'
    (OUT / destination).write_bytes(b)
    instruction_manifest.append({'source_path': p, 'snapshot': destination, 'bytes':len(b), 'sha256':sha(b)})

ids = ['S2.p1','S4.SS1.p1','S4.E11','S4.Ex10','S4.Ex12','S4.Thmtheorem3.p1','S4.Thmtheorem4','S4.Thmtheorem4.p1',
       'A3.SS2.p1','A3.Ex85','A3.SS2.p2','A3.Thmtheorem5','A3.Ex86','A3.Ex87',
       'A3.SS2.p3','A3.SS2.p4','A3.EGx5','A3.SS2.p5','A3.Ex90','A3.EGx6',
       'A3.SS2.p6','A3.EGx7','A3.SS2.p7','A3.Ex96','A3.EGx8','A3.EGx9',
       'A3.SS2.p8','A3.Ex102','A3.SS2.p9','A3.Thmtheorem6','A3.Ex103',
       'A3.SS2.p10','A3.Ex104','A3.Ex105','A3.SS2.p11','A3.EGx10',
       'A3.SS2.p12','A3.Ex107','A3.Ex108','A3.Ex109','A3.Ex110',
       'A3.SS2.p13','A3.Ex111','A3.Ex112','A3.SS2.p14','A3.SS2.p14.1',
       'A3.Ex113','A3.SS2.p14.2','A3.Ex114','A3.SS2.p14.3','A3.EGx11',
       'A3.Ex115','A3.Ex116','A3.Ex117','A3.SS2.p14.4','A3.Ex118',
       'A3.SS2.p14.5','A3.Ex119','A3.SS2.p14.6','A3.Ex120']
write('source_locators.json', {'convention':'UTF-8 bytes; Unicode code-point chars; 0-based half-open byte/char spans; 1-based inclusive lines. Hash is exact raw element bytes.', 'items':{i:locator(i) for i in ids}})

start = parser.items['A3.SS2.p1'][0]
end = parser.items['A3.SS2.p14'][1]
prefix = text[start:end]
(OUT / 'bounded_C2_p1_p14.raw.html').write_text(prefix)
readings = []
for identity in ['S2.p1','S4.SS1.p1','S4.Ex10','S4.Ex12','S4.Thmtheorem3.p1','S4.Thmtheorem4.p1'] + ['A3.SS2.p'+str(i) for i in range(1,15)]:
    readings.append('SOURCE ID ' + identity + '\n' + readable(identity))
(OUT / 'raw_reading.txt').write_text('\n\n'.join(readings) + '\n')

nodes = []
def node(identity, kind, statement, anchors, status='SOURCE_PRESENT', note=None):
    item={'id':identity,'kind':kind,'raw_statement_or_component':statement,'source_anchors':anchors,'evidence_status':status}
    if note: item['scope_note']=note
    nodes.append(item)

node('conventions','source-definition','Real Euclidean vector norm; I_m is the m-by-m identity; A ≼ B for symmetric matrices means B-A is PSD. Expectations of finite matrices are understood entrywise. Matrix products, transpose and Kronecker products have their ordinary real finite-dimensional meaning.',['S2.p1','A3.Ex107','A3.Ex113','A3.EGx11'],note='Entrywise matrix expectation / Kronecker ordering is implicit notation, not a new premise; explicit required bridges are separately visible.')
node('dimensions','standing-and-typing','q is an integer >=0; d is a positive integer dimension; 2q+1<d; r=q+1; n=2q+1. Thus r>=1, d>=2 and 2r<=d. i runs from 1 to d; feature coordinate j runs from 0 to q.',['S4.Thmtheorem3.p1','S4.Thmtheorem4.p1','A3.SS2.p1'])
node('source-g-carriers','typing','g_1,...,g_r are real d-coordinate vectors in the original source construction.',['S4.Thmtheorem4.p1','A3.Ex85'])
node('original-source-g-law','source-standing-input','In the original source experiment, g_1,...,g_r are independent N(0,I_d) vectors.',['S4.Thmtheorem4.p1'],note='This is the original source setup, not a claim that a future canonical individual-row integral realization has transported the source joint family.')
node('row-carrier','source-definition','gamma_i=((g_1)_i,...,(g_r)_i)^T is a real r-coordinate vector for each physical row i.',['A3.Ex85'])
node('grid','source-definition','theta_i=(i-1/2)pi/d for 1<=i<=d.',['S4.E11','A3.SS2.p4'])
node('features','source-definition','t_i=(1,sqrt(2)cos(theta_i),...,sqrt(2)cos(q theta_i))^T in R^r; it is deterministic.',['A3.Ex85','A3.SS2.p5'])
node('cosine-sum','source-proof-step','For each integer k with 0<|k|<2d, sum_i cos(k theta_i)=0, from the displayed telescoping sine identity and sin(k pi/(2d)) != 0.',['A3.SS2.p4','A3.EGx5'])
node('gram-entrywise','source-proof-step','Constant/constant sum=d; constant/nonconstant sum=0; nonconstant/nonconstant entry is d on diagonal and 0 off diagonal, using product-to-sum and the frequency bounds 0<j+k<=2q<2d and 0<|j-k|<2d when j!=k.',['A3.SS2.p5','A3.Ex90','A3.EGx6'])
node('gram','reused-display-component','sum_i t_i t_i^T = d I_r.',['A3.Ex87','A3.SS2.p5'])
node('feature-norm','reused-display-and-proof','||t_i||^2=1+2 sum_(j=1)^q cos^2(j theta_i)<=1+2q<=2r.',['A3.Ex87','A3.Ex102','A3.SS2.p8'])
node('rank-one-and-kronecker-order','implicit-elementary-bridge','t_i t_i^T and gamma gamma^T are PSD; tensoring a PSD matrix with I_r or another PSD matrix preserves PSD; nonnegative scalar multiplication and finite sums preserve Loewner order.',['A3.SS2.p14.3','A3.Ex115','A3.Ex116'],status='SOURCE_GAP',note='Elementary algebra/order justifications are used but not expanded in the source. This is an omitted proof bridge, not evidence of a false source statement or a license for extra theorem assumptions.')
node('coefficient-comparison','deterministic-root','C_t := sum_i ||t_i||^2 t_i t_i^T ≼ 2r sum_i t_i t_i^T = 2rd I_r.',['A3.Ex116','A3.SS2.p14.4'],note='This r-by-r coefficient comparison is the deterministic content inside Ex116, not a separately named source display. The weights are feature squared norms, not the high-frequency cos(n theta_i).')
node('lifted-coefficient-comparison','source-proof-step','sum_i ||t_i||^2 (I_r tensor t_i t_i^T) ≼ 2r (I_r tensor sum_i t_i t_i^T).',['A3.Ex116'])
node('row-marginal','standing-random-input','For each i, gamma_i=((g_1)_i,...,(g_r)_i)^T has N(0,I_r) law.',['S4.Thmtheorem4.p1','A3.Ex85','A3.SS2.p1'],note='Only each individual N(0,I_r) law is consumed in the present expectation/sum closure. The original source additionally states across-row independence, obtained from independent N(0,I_d) columns; that stronger joint context is explicitly excluded from the present necessary-input closure.')
node('individual-row-law-from-source-family','implicit-probability-bridge','The coordinate vector across independent standard Gaussian columns has the N(0,I_r) marginal law for each fixed i.',['S4.Thmtheorem4.p1','A3.Ex85','A3.SS2.p1'],status='SOURCE_GAP',note='C.2 asserts the row laws without expanding this finite Gaussian coordinate-law adapter. The original-source backward closure includes it; the separately labelled marginal-sufficient closure stops at row-marginal. No formal adapter or full joint-law transport is certified by this raw graph.')
node('radial-and-threshold','source-definition','R_i=||gamma_i||^2 and L=2r+3 log(1000d).',['A3.SS2.p10'],note='Natural logarithm is the ordinary analytic convention. The numerical 3 and 1000 specify the source cutoff; the uncentered domination step does not use a tail estimate or its numerical optimization.')
node('Y-definition','source-definition','Y_i=(1/d)(gamma_i gamma_i^T tensor t_i t_i^T) 1_{R_i<=L}, a real symmetric r^2-by-r^2 matrix.',['A3.Ex107','A3.SS2.p12'],note='The source adjective independent refers to a common family; it is not needed by the individual marginal integral or the sum of such integrals.')
node('gaussian-fourth-components','source-proof-step','Off-diagonal entries of E[R_i gamma_i gamma_i^T] vanish by sign symmetry; each diagonal equals 3+(r-1)=r+2.',['A3.SS2.p14.1','A3.SS2.p14.2'],note='Uses within-row standard Gaussian coordinate structure: E gamma_a^4=3 and E gamma_a^2 gamma_b^2=1 for a!=b. It does not use independence of different rows.')
node('gaussian-polynomial-integrability','implicit-analytic-bridge','The standard finite-dimensional Gaussian has finite fourth-degree coordinate moments, so R_i gamma_a gamma_b and each untruncated square entry are integrable; truncated square entries are measurable and integrable as well.',['A3.Ex113','A3.Ex114','A3.Ex115'],status='SOURCE_GAP',note='Source invokes Gaussian fourth moments and expectations without expanding measurable/integrable bookkeeping. These are internal dependencies, not standing moment hypotheses.')
node('Ex113','source-equation','E[R_i gamma_i gamma_i^T]=(r+2)I_r.',['A3.Ex113'])
node('rank-one-square-algebra','source-proof-step','(gamma_i gamma_i^T)^2=R_i gamma_i gamma_i^T; (t_i t_i^T)^2=||t_i||^2 t_i t_i^T.',['A3.SS2.p14.2'])
node('square-tensor-indicator-algebra','implicit-elementary-bridge','(A tensor T)^2=A^2 tensor T^2 and 1_{R_i<=L}^2=1_{R_i<=L}; all products are square matrix products.',['A3.Ex107','A3.Ex114'],status='SOURCE_GAP',note='The tensor multiplication and indicator idempotence used to obtain Ex114 are implicit source algebra.')
node('Ex114','source-equation','Y_i^2=(R_i ||t_i||^2/d^2)(gamma_i gamma_i^T tensor t_i t_i^T)1_{R_i<=L}.',['A3.Ex114'])
node('pointwise-truncation-domination','source-proof-step','Removing the indicator from the nonnegative-scalar PSD expression for Y_i^2 increases it in Loewner order.',['A3.SS2.p14.3','A3.Ex114','A3.Ex115'])
node('expectation-and-finite-sum-order','implicit-analytic-bridge','Entrywise integrable PSD matrix inequalities remain inequalities after expectation; deterministic coefficients and tensors commute with expectation; finite sums preserve these inequalities.',['A3.Ex115'],status='SOURCE_GAP',note='Finite-dimensional integration/order bookkeeping is implicit at the source use site. No joint row law is needed to sum individual expectations.')
node('Ex115','source-proof-step','sum_i E[Y_i^2] ≼ (r+2)/d^2 sum_i ||t_i||^2 (I_r tensor t_i t_i^T).',['A3.Ex115'])
node('Ex116','source-proof-step','The preceding RHS ≼ 2r(r+2)/d^2 (I_r tensor sum_i t_i t_i^T).',['A3.Ex116'])
node('tensor-normalization','implicit-elementary-bridge','I_r tensor (d I_r)=d I_{r^2}; since d>0, (2r(r+2)/d^2)d=2r(r+2)/d.',['A3.Ex117','A3.SS2.p14.4'],status='SOURCE_GAP',note='The tensor carrier is the ordered pair of two r-coordinate indices, of cardinality r^2; a scalar or r-by-r identity cannot replace I_{r^2}.')
node('uncentered-sum-bound','source-root','sum_(i=1)^d E[Y_i^2] ≼ (2r(r+2)/d) I_{r^2}.',['A3.EGx11','A3.Ex117'],note='E[Y_i^2] means the expectation of the matrix square, not (E Y_i)^2, not entrywise square, and not covariance/variance. This packet ends here.')

edges=[]
def edge(identity, inputs, output, at, discharge):
    edges.append({'id':identity,'kind':'AND','inputs':inputs,'output':output,'consumer_use_site':at,'condition_discharge':discharge})
edge('d01',['dimensions'],'source-g-carriers',['S4.Thmtheorem4.p1','A3.Ex85'],'There are r=q+1 starting vectors, each of physical dimension d.')
edge('d02',['source-g-carriers','dimensions'],'row-carrier',['A3.Ex85'],'For fixed i in 1..d, collect one coordinate from each of the r columns.')
edge('d03',['dimensions'],'grid',['S4.E11','A3.SS2.p4'],'Positive d makes the midpoint-grid denominator legitimate.')
edge('d04',['dimensions','grid'],'features',['A3.Ex85'],'The constant coordinate and q cosine coordinates give r=q+1 deterministic real entries.')
edge('d05',['row-carrier','dimensions'],'radial-and-threshold',['A3.SS2.p10'],'R_i is the Euclidean square of the row and L is the stated finite deterministic cutoff.')
edge('d06',['row-carrier','features','radial-and-threshold','dimensions','conventions'],'Y-definition',['A3.Ex107'],'The rank-one tensors have r^2-by-r^2 shape and source scale 1/d.')
edge('d07',['original-source-g-law','source-g-carriers','row-carrier','dimensions'],'individual-row-law-from-source-family',['A3.SS2.p1'],'For fixed i, each column coordinate is standard normal and independence of the source columns gives independent row coordinates; full across-row independence is not needed for this inference.')
edge('d08',['individual-row-law-from-source-family'],'row-marginal',['A3.SS2.p1'],'This is the marginal law stated in the source; the graph records the original-source derivation as an unexpanded adapter, not as a checked transport theorem.')
edge('e01',['grid','dimensions'],'cosine-sum',['A3.SS2.p4','A3.EGx5'],'Integer frequency in 0<|k|<2d makes sine factor nonzero; telescope gives zero numerator.')
edge('e02',['features','dimensions','cosine-sum'],'gram-entrywise',['A3.Ex90','A3.EGx6','A3.SS2.p5'],'For nonconstant coordinates, j+k<=2q<2d; j-k=0 exactly on diagonal. Constant-coordinate cases handled separately.')
edge('e03',['gram-entrywise','conventions'],'gram',['A3.SS2.p5'],'Symmetry and exhaustive 0..q coordinate cases cover every matrix entry.')
edge('e04',['features','dimensions','conventions'],'feature-norm',['A3.Ex102'],'cos^2<=1, r=q+1; q=0 is the empty-sum case.')
edge('e05',['feature-norm','gram','rank-one-and-kronecker-order','dimensions','conventions'],'coefficient-comparison',['A3.Ex116','A3.SS2.p14.4'],'Each coefficient 2r-||t_i||^2 is nonnegative; sum PSD differences; use Gram identity.')
edge('e06',['coefficient-comparison','rank-one-and-kronecker-order','conventions'],'lifted-coefficient-comparison',['A3.Ex116'],'Kronecker lift by I_r and finite-sum linearity; this is the deterministic r^2-by-r^2 form appearing in the chain.')
edge('e07',['row-marginal','dimensions','radial-and-threshold','conventions'],'gaussian-fourth-components',['A3.SS2.p14.2'],'Use standard Gaussian coordinate fourth/mixed moments and sign symmetry within a fixed row.')
edge('e08',['row-marginal','features','dimensions','radial-and-threshold','Y-definition'],'gaussian-polynomial-integrability',['A3.Ex113','A3.Ex114','A3.Ex115'],'Finite Gaussian polynomial moments and measurable radial cutoff supply the integrals; no separate integrability premise.')
edge('e09',['gaussian-fourth-components','gaussian-polynomial-integrability','radial-and-threshold','conventions'],'Ex113',['A3.Ex113'],'Entrywise fourth moment computation; r>=1 includes r=1 with zero mixed-coordinate summands.')
edge('e10',['radial-and-threshold','features','Y-definition','conventions'],'rank-one-square-algebra',['A3.SS2.p14.2'],'Pure pointwise finite-dimensional algebra using the row carrier, with no distributional condition.')
edge('e11',['Y-definition','conventions'],'square-tensor-indicator-algebra',['A3.Ex114'],'Pure tensor multiplication and 0/1 indicator algebra.')
edge('e12',['Y-definition','rank-one-square-algebra','square-tensor-indicator-algebra','dimensions'],'Ex114',['A3.Ex114'],'Scalar factor squares to 1/d^2; Gram factors square by rank-one identities.')
edge('e13',['Ex114','rank-one-and-kronecker-order','radial-and-threshold','conventions'],'pointwise-truncation-domination',['A3.SS2.p14.3','A3.Ex115'],'R_i>=0 and ||t_i||^2>=0; indicator is 0 or 1. No positivity requirement on L is needed to remove it.')
edge('e14',['gaussian-polynomial-integrability','conventions'],'expectation-and-finite-sum-order',['A3.Ex115'],'All individual matrix entries are integrable; order can be checked on deterministic quadratic forms or finite-dimensional PSD cone integration.')
edge('e15',['pointwise-truncation-domination','Ex113','expectation-and-finite-sum-order','features','dimensions'],'Ex115',['A3.Ex115'],'Apply each individual expectation, substitute (r+2)I_r, and sum i=1..d; independence is unused.')
edge('e16',['Ex115','lifted-coefficient-comparison','dimensions'],'Ex116',['A3.Ex116'],'Multiply deterministic coefficient comparison by the nonnegative scalar (r+2)/d^2.')
edge('e17',['gram','dimensions','conventions'],'tensor-normalization',['A3.Ex117','A3.SS2.p14.4'],'Use d>0 and cardinality r*r; no probabilistic input.')
edge('e18',['Ex116','tensor-normalization'],'uncentered-sum-bound',['A3.Ex117'],'Transitivity of Loewner order gives the exact source upper bound.')

by_output={}
for e in edges:
    by_output.setdefault(e['output'],[]).append(e)
def closure(target, stop_at=()):
    found=set()
    used=set()
    def visit(n):
        if n in found:return
        found.add(n)
        if n in stop_at:return
        for e in by_output.get(n,[]):
            used.add(e['id'])
            for dep in e['inputs']:visit(dep)
    visit(target)
    return {'root':target,'nodes':sorted(found),'edges':sorted(used),'closed_relative_to_named_primitives':True,'terminal_boundary':list(stop_at)}

write('source_proof_graph.json',{
    'schema':'raw-source-graph-v1',
    'author_role':'independent raw source reconstructor, not mathematical prover or type reviewer',
    'phase':'RAW_READING_FROZEN_BEFORE_SELECTIVE_TYPES',
    'source_digest':sha(blob),
    'review_status':'extractor frozen; distinct-role topology challenge required; no self-approval',
    'scope':{'roots':['coefficient-comparison','uncentered-sum-bound'], 'source_primary':'Appendix C.2 p14, Ex113, Ex114, EGx11 (Ex115/116/117), and explicit Here-we-used sentence in p14.4', 'support':'Only backward source dependencies plus explicitly excluded adjacent original context.', 'does_not_claim':['centering','centered variance bound','variance operator norm','matrix Bernstein','Fact C.6','full Lemma 4.4','original-family joint-law transport']},
    'nodes':nodes,'edges':edges,
    'root_backward_closures':[closure('coefficient-comparison'),closure('uncentered-sum-bound')],
    'marginal_sufficient_backward_closure':closure('uncentered-sum-bound',stop_at=['row-marginal']),
    'closure_scope_note':'The full original-source closure includes the source g-family law and its individual-row marginal adapter. The marginal-sufficient closure treats the individual row law as the input boundary and makes no original-family transport claim. Across-row independence is not a calculation dependency in either closure.',
    'alternative_routes':[],
    'alternative_route_note':'No alternative sufficient source route is present in the bounded source chain; ordinary algebraic implementations are not additional source OR-routes.',
    'source_gap_semantics':'SOURCE_GAP identifies unexpanded elementary/algebraic/integration bridges in the pinned exposition, not a declared mathematical error or an additional public assumption.'
})

coverage=[]
def cover(identity, component, disposition, targets=None, reason=None):
    d={'source_html_id':identity,'component':component,'disposition':disposition}
    if targets:d['nodes']=targets
    if reason:d['reason']=reason
    coverage.append(d)
cover('A3.SS2.p1','r,n; t_i,gamma_i; individual Gaussian law','NODE',['dimensions','features','row-carrier','row-marginal','individual-row-law-from-source-family'])
cover('A3.SS2.p1','Across-row independence and B row d^(-1/2)(gamma_i tensor t_i)^T','EXCLUDED',reason='Original joint-family/B context retained; not a necessary hypothesis or conclusion of individual moment integrals and their sum. B has d rows and r^2 columns.')
cover('A3.SS2.p2','Strategy u=Bc, norms, full uniform concentration','EXCLUDED',reason='Downstream motivation; no proof ingredient for EGx11.')
cover('A3.Ex86','range(B)=K_q; E B^TB=I; E B^TD_nB=0','EXCLUDED',reason='Distinct C.5 conclusions, not prerequisites of uncentered second moments.')
cover('A3.Ex87','||t_i||^2<=2r and sum_i t_it_i^T=dI_r','NODE',['feature-norm','gram'])
cover('A3.Ex87','sum_i cos(n theta_i)t_it_i^T=0','EXCLUDED',reason='High-frequency weighted cancellation is not used in EGx11; feature squared-norm weights are different.')
cover('A3.SS2.p3','Chebyshev polynomial / triangular change of basis / range proof','EXCLUDED',reason='Only establishes range(B)=K_q. Kappa and Krylov representation are outside this closure.')
cover('A3.SS2.p4','Boxed E[B^TB]=I heading','EXCLUDED',reason='Proof label is contextual; only its cosine-sum subargument is reused.')
cover('A3.SS2.p4','Grid recall; telescope; nonzero sine; cosine sum; EGx5','NODE',['grid','cosine-sum'])
cover('A3.SS2.p5','All coordinate cases Ex90, EGx6, frequency checks, symmetry conclusion','NODE',['features','gram-entrywise','gram'])
cover('A3.SS2.p6','E gamma_i gamma_i^T=I and EGx7 B Gram expectation','EXCLUDED',reason='Second moments and B expectation are unnecessary for Ex113/114/EGx11 closure; no missing fourth moment premise is imported from here.')
cover('A3.SS2.p7','n-band check Ex96; triple-cosine expansion EGx8; weighted Gram zero; B weighted expectation EGx9','EXCLUDED',reason='Used for high-frequency weighted mean, not uncentered square sum.')
cover('A3.SS2.p8','Feature norm equality/bounds Ex102','NODE',['feature-norm'])
cover('A3.SS2.p9','Operator-norm deviation motivation','EXCLUDED',reason='This packet claims a Loewner upper bound only, not an operator-norm concentration statement.')
cover('A3.Thmtheorem6','Fact C.6 full statement / Ex103','EXCLUDED',reason='Concentration result remains downstream.')
cover('A3.SS2.p10','Definitions R_i=||gamma_i||^2 and L=2r+3 log(1000d)','NODE',['radial-and-threshold'])
cover('A3.SS2.p10','Gaussian exponential moment, Markov tail Ex104, numeric log3 comparison, event T Ex105, union probability .999','EXCLUDED',reason='Tail probability and joint truncation event are not needed to upper-bound the uncentered second moments.')
cover('A3.SS2.p11','Tail integral / truncation-bias estimate EGx10','EXCLUDED',reason='Bias belongs to first-moment/centering/concentration route.')
cover('A3.SS2.p12','Truncated-matrix definition Ex107','NODE',['Y-definition'])
cover('A3.SS2.p12','Independent adjective','EXCLUDED',reason='Retained as original-family context; no across-row independence needed for this endpoint.')
cover('A3.SS2.p12','Radial first-moment scalar a Ex108; 0<=a<=1; bias Ex109; EY_i; sums Ex110 and weighted zero','EXCLUDED',reason='Mean and bias estimates do not enter Ex113/Ex114/EGx11.')
cover('A3.SS2.p13','Centered Z_i definition; norm bounds Ex111/112; cosine-weighted centered norm','EXCLUDED',reason='Centered bounded-summand step is outside the endpoint, even though it precedes p14 in source order.')
cover('A3.SS2.p14.1','Fourth moment introduction and Ex113','NODE',['gaussian-fourth-components','Ex113'])
cover('A3.SS2.p14.2','Sign symmetry, diagonal constant 3+(r-1), rank-one squares','NODE',['gaussian-fourth-components','rank-one-square-algebra'])
cover('A3.Ex114','Pointwise formula for Y_i^2','NODE',['Ex114'])
cover('A3.SS2.p14.3','Dropping indicator in PSD expression','NODE',['pointwise-truncation-domination'])
cover('A3.Ex115','First expectation/sum comparison','NODE',['Ex115'])
cover('A3.Ex116','Deterministic feature squared-norm weighted coefficient comparison and its tensor lift','NODE',['coefficient-comparison','lifted-coefficient-comparison','Ex116'])
cover('A3.Ex117','Exact final scalar times I_(r^2)','NODE',['tensor-normalization','uncentered-sum-bound'])
cover('A3.SS2.p14.4','First sentence: Here we used feature norm and unweighted Gram','NODE',['feature-norm','gram'])
cover('A3.SS2.p14.4','The trailing Since introducing Ex118','EXCLUDED',reason='Starts the downstream centering step.')
cover('A3.Ex118','E Z_i^2 = E Y_i^2 - (E Y_i)^2 ≼ E Y_i^2','EXCLUDED',reason='Centering remains a separate unclaimed endpoint.')
cover('A3.SS2.p14.5','Variance-parameter sentence and Ex119','EXCLUDED',reason='Variance parameter/operator-norm interpretation remains downstream.')
cover('A3.SS2.p14.6','Weighted centered-square comparison and Ex120','EXCLUDED',reason='This is cos(n theta_i) Z_i, not the deterministic feature squared-norm coefficient comparison.')
write('component_coverage.json',{
    'scope_policy':'Bounded primary source inventory is Appendix C.2 p1-p14 inclusive; adjacent material in this original source is explicitly NODE/EXCLUDED by component. The claim endpoints remain only coefficient-comparison and uncentered-sum-bound. C.2 p15 onward is a separately excluded downstream region.',
    'inventory':coverage,
    'outside_primary_support':[{'source_html_id':'S2.p1','disposition':'NODE','nodes':['conventions']},{'source_html_id':'S4.E11','disposition':'NODE','nodes':['grid'],'other_components_excluded':'lambda_i, Lambda, kappa and random O hard-family definitions do not enter current endpoints.'},{'source_html_id':'S4.Thmtheorem3.p1','disposition':'NODE','nodes':['dimensions'],'other_components_excluded':'The integer-query-budget convention is used; the algorithm-output representation is outside this packet.'},{'source_html_id':'S4.Thmtheorem4.p1','disposition':'NODE','nodes':['dimensions','source-g-carriers','original-source-g-law'],'other_components_excluded':'absolute C, tau<=1/2, event probability .99 and full K_q conclusion remain downstream.'},{'source_html_id':'S4.Ex10','disposition':'EXCLUDED','reason':'Original Krylov definition retained as adjacent context, not a dependency.'},{'source_html_id':'S4.Ex12','disposition':'EXCLUDED','reason':'D_n and n context only; no high-frequency cosine statistic occurs in the coefficient comparison.'}],
    'outside_primary_downstream':[{'source_range':'Appendix C.2 p15-p19 inclusive, ending immediately before C.3','disposition':'EXCLUDED','reason':'Bernstein, concentration-event intersections, asymptotic simplification and full Lemma 4.4 proof are downstream of the frozen endpoint.'}],
    'coverage_status':'extractor-complete bounded inventory; independent challenge pending; no self-certified exhaustive-review acceptance',
    'source_gap_nodes':[n['id'] for n in nodes if n['evidence_status']=='SOURCE_GAP'],
    'external_citations':{'in_target_closure':[],'excluded_context':'[22] in the hard-family/Krylov-range context does not supply the coefficient or fourth-moment upper-bound proof.'}
})

write('input_manifest.json',{
    'phase':'RAW_ONLY',
    'source':{'path':str(SRC.relative_to(ROOT)),'snapshot':'inputs/2610.20492v1.html','bytes':len(blob),'characters':len(text),'lines':text.count('\n')+1,'sha256':sha(blob)},
    'instructions':instruction_manifest,
    'instruction_precedence':'The exact current parent task authorizes only the pinned source, applicable instructions and local raw artifacts. It forbids normal ledgers/commits/integration/ATLAS/subagents and defers all type/definition judgments until an exact selective packet. Hence procedural instructions to search APIs or update canonical ledgers are outside this role.',
    'exposure_disclosure':{'event':'Initial instruction discovery used an overbroad rg --files search under .agents and .astis. It returned filenames under prior packet directories.','scope':'Filename-only exposure; no prior graph/report/verdict/type/Lean/API/history contents were opened or used.','parent_notified':True,'parent_direction':'Preserve the exact filename-only exposure disclosure and continue independent raw-source reading; adjacent original source may be retained with explicit out-of-scope labels.'},
    'explicitly_not_read':['proposed types or definitions','Lean code or APIs','prior packet graph/report/verdict contents','implementation/compiler history','source-blind decoder inputs'],
    'explicitly_not_performed':['proof/API search','normal ledger calls','commits','integration','ATLAS','subagents','mathematical proof construction','type judgment'],
    'pending':'Wait for exact selective type/definition packet; distinct-role topology challenge remains separately required.'
})

print(json.dumps({'output':str(OUT),'nodes':len(nodes),'edges':len(edges),'coverage_components':len(coverage),'source_sha256':sha(blob)},indent=2))
