import Mathlib

open scoped BigOperators
open Filter

private theorem radius_bounds {κ : ℝ} (hκ : 2 ≤ κ) :
    1 < Real.sqrt κ ∧
    0 < (Real.sqrt κ - 1) / (Real.sqrt κ + 1) ∧
    (Real.sqrt κ - 1) / (Real.sqrt κ + 1) < 1 := by
  have hsq : (Real.sqrt κ) ^ 2 = κ := Real.sq_sqrt (by linarith)
  have hs : 1 < Real.sqrt κ := by nlinarith [Real.sqrt_nonneg κ]
  have hp : 0 < Real.sqrt κ + 1 := by linarith
  exact ⟨hs, div_pos (by linarith) hp, (div_lt_one hp).2 (by linarith)⟩

private theorem cosine_series_value {r : ℝ} (hr0 : 0 ≤ r) (hr1 : r < 1) (θ : ℝ) :
    1 + 2 * (∑' j : ℕ, (-r) ^ (j + 1) * Real.cos (((j + 1 : ℕ) : ℝ) * θ)) =
      (1 - r ^ 2) / (1 + 2 * r * Real.cos θ + r ^ 2) := by
  let z : ℂ := (-r : ℂ) * Complex.exp ((θ : ℂ) * Complex.I)
  have hz : ‖z‖ < 1 := by
    simpa [z, norm_mul, Real.norm_eq_abs, abs_of_nonneg hr0] using hr1
  have hterm (j : ℕ) : (z ^ j).re = (-r) ^ j * Real.cos ((j : ℝ) * θ) := by
    dsimp [z]
    rw [mul_pow, ← Complex.ofReal_neg, ← Complex.ofReal_pow, ← Complex.exp_nat_mul]
    have he : (j : ℂ) * ((θ : ℂ) * Complex.I) =
        ((((j : ℝ) * θ : ℝ) : ℂ) * Complex.I) := by push_cast; ring
    rw [he]
    simp [Complex.mul_re]
  have hreal : HasSum (fun j : ℕ => (-r) ^ j * Real.cos ((j : ℝ) * θ))
      ((1 - z)⁻¹).re := by
    simpa only [hterm] using Complex.hasSum_re (hasSum_geometric_of_norm_lt_one hz)
  have hre : z.re = -r * Real.cos θ := by simp [z, Complex.mul_re]
  have him : z.im = -r * Real.sin θ := by simp [z, Complex.mul_im]
  have hnorm : Complex.normSq (1 - z) = 1 + 2 * r * Real.cos θ + r ^ 2 := by
    rw [Complex.normSq_apply]
    simp only [Complex.sub_re, Complex.one_re, Complex.sub_im, Complex.one_im, hre, him]
    have ht := congrArg (fun x : ℝ => r ^ 2 * x) (Real.sin_sq_add_cos_sq θ)
    nlinarith
  have hD : 0 < 1 + 2 * r * Real.cos θ + r ^ 2 := by
    have hm : 0 ≤ r * (1 + Real.cos θ) :=
      mul_nonneg hr0 (by linarith [Real.neg_one_le_cos θ])
    have hp : 0 < (1 - r) ^ 2 := sq_pos_of_pos (by linarith)
    nlinarith
  have hinv : ((1 - z)⁻¹).re =
      (1 + r * Real.cos θ) / (1 + 2 * r * Real.cos θ + r ^ 2) := by
    rw [Complex.inv_re, hnorm]
    simp [hre]
  have hsplit :
      1 + (∑' j : ℕ, (-r) ^ (j + 1) * Real.cos (((j + 1 : ℕ) : ℝ) * θ)) =
        (1 + r * Real.cos θ) / (1 + 2 * r * Real.cos θ + r ^ 2) := by
    rw [← hinv, ← hreal.tsum_eq]
    simpa using hreal.summable.tsum_eq_zero_add.symm
  apply (eq_div_iff (ne_of_gt hD)).2
  have hmul := (eq_div_iff (ne_of_gt hD)).1 hsplit
  calc
    _ = 2 * ((1 + (∑' j : ℕ, (-r) ^ (j + 1) *
        Real.cos (((j + 1 : ℕ) : ℝ) * θ))) *
        (1 + 2 * r * Real.cos θ + r ^ 2)) -
        (1 + 2 * r * Real.cos θ + r ^ 2) := by ring
    _ = 1 - r ^ 2 := by rw [hmul]; ring
