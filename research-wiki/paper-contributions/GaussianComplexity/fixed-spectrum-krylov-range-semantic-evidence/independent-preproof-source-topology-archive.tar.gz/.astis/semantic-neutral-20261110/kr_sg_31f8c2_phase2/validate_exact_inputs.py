from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parent;REPO=ROOT.parents[2]
sha=lambda b:hashlib.sha256(b).hexdigest()
dump=lambda n,x:(ROOT/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
packet=json.loads((ROOT/'exact-selective-packet.json').read_bytes())
for item in packet['lean']:
    assert sha(item['signature'].encode())==item['signature_sha256']
    assert item['literal_Prop_formation_only'] and not item['target_theorem_compiled']
seal_path=REPO/packet['sealed_statement_file_for_hash_and_signature_fields_only']
b=seal_path.read_bytes();assert sha(b)==packet['sealed_statement_raw_sha256']=='f47e23a601d1a8e0ff4760224676313e0f1999877a97156841a65c01847e5d82'
seal=json.loads(b)
# No root binder audit, plan, previous verdict, or any other seal field is emitted.
allowed=['name','declaration','lean_declaration','file','lean_file','planned_file','signature','lean_signature','signature_sha256']
selected={}
for key,item in zip(['producer','actual_private_consumer'],packet['lean']):
    entry=seal[key]
    fields={k:entry[k] for k in allowed if k in entry}
    assert item['name'] in fields.values(),(key,'name not found in authorized fields')
    assert item['planned_file'] in fields.values(),(key,'file not found in authorized fields')
    assert item['signature'] in fields.values(),(key,'exact signature not found in authorized fields')
    assert item['signature_sha256'] in fields.values(),(key,'signature hash not found in authorized fields')
    selected[key]=fields
dump('selected-seal-fields.json',{'seal_path':str(seal_path),'whole_seal_sha256':sha(b),'permitted_fields_only':selected,'other_fields_not_exposed':True})
records=[]
outdir=ROOT/'canonical-literal-spans';outdir.mkdir(exist_ok=True)
for k,item in enumerate(packet['minimal_definitions']):
    file=REPO/item['file'];raw=file.read_bytes();assert sha(raw)==item['wholefile_raw_sha256']
    s=raw.decode();a,z=item['start_character_inclusive'],item['end_character_exclusive'];ba,bz=item['byte_start_inclusive'],item['byte_end_exclusive'];span=raw[ba:bz]
    assert s[a:z].encode()==span==item['literal'].encode()
    assert sha(span)==item['literal_sha256']
    assert s.count('\n',0,a)+1==item['start_line_1based']
    assert s.count('\n',0,z-1)+1==item['end_line_1based_inclusive']
    assert span.endswith(b'\n')==item['source_LF_included_exactly']
    (outdir/(str(k)+'.literal.txt')).write_bytes(span)
    context_locations=[]
    if isinstance(item['context'],list):
        for ctx in item['context']:
            loc=s.rfind(ctx,0,a)
            context_locations.append({'exact_header':ctx,'found_before_literal':loc>=0,'character_start':loc if loc>=0 else None,'line_1based':s.count('\n',0,loc)+1 if loc>=0 else None})
    records.append({'ordinal':k,'path':str(file),'wholefile_bytes':len(raw),'wholefile_raw_sha256':sha(raw),'kind':item['kind'],'literal_sha256':sha(span),'character_span':[a,z],'utf8_byte_span':[ba,bz],'lf_lines_1based_inclusive':[item['start_line_1based'],item['end_line_1based_inclusive']],'terminal_LF_included':span.endswith(b'\n'),'provided_context':item['context'],'exact_header_context_locations':context_locations,'literal':span.decode(),'validation':'exact original bytes, character and byte offsets, LF lines and supplied fullfile hash match; no proof body emitted'})
dump('canonical-definition-validation.json',{'records':records,'scope_limit':'Full files were read as bytes for supplied fullfile hashing and exact specified span/context validation only. Model-visible output contains only authorized definition literals/characterization header and their contexts; no theorem proof body or general API search.'})
existence=[{'path':x['planned_file'],'exists_at_validation':(REPO/x['planned_file']).exists(),'contents_read':False} for x in packet['lean']]
dump('target-presence-only.json',existence)
print(json.dumps({'seal_selective_fields':selected,'definition_span_count':len(records),'all_definition_spans_match':True,'definition_spans':[{'ordinal':x['ordinal'],'literal_sha256':x['literal_sha256'],'exact_context_headers':x['exact_header_context_locations']} for x in records],'planned_targets':existence},ensure_ascii=False,indent=2))
