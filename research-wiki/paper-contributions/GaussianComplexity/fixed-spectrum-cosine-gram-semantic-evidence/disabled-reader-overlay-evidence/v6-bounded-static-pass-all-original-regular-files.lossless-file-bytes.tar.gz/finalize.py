"""Freeze every v6 review input/output and bounded independent judgment."""
import datetime, hashlib, json, os, pathlib, stat

D=pathlib.Path(__file__).resolve().parent
def sha(b):return hashlib.sha256(b).hexdigest()
def put(rel,b):
 p=D/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b if isinstance(b,bytes) else b.encode());return p
def js(rel,o):return put(rel,json.dumps(o,ensure_ascii=False,indent=2)+'\n')
progress=json.loads((D/'scope-and-progress.json').read_bytes())
receipt=json.loads((D/'review.receipt.json').read_bytes());assert receipt['exit_code']==0
unicode_replay=json.loads((D/'replay-original-Unicode/result.json').read_bytes())
CR_replays=json.loads((D/'replay-v5-regressions/results.json').read_bytes())
findings={
 'schema':'astis-independent-disabled-v6-ui-review/v1',
 'candidate':'72e5d1405284f729f4eb600c5ae5dd556365b7e2',
 'reviewer':'reader-step-neighbor-v6-independent-0a91de',
 'proposal_sha256':sha((D/'proposal.py').read_bytes()),
 'v5_sha256':sha((D/'proposal-v5.exact.py').read_bytes()),
 'production_sha256':sha((D/'production.py').read_bytes()),
 'patch_sha256':sha((D/'reader-step-neighbor.patch').read_bytes()),
 'decision':'PASS within bounded prospective static scope; no defect found in tested scope; all earlier HOLDs unchanged',
 'exact_delta':'Exact complete v5 renderer with only base.esc(line) replaced by base.esc(line.removesuffix(chr(13))) in sourceHTML line presentation equals complete supplied v6 bytes. LF partition/anchors, matching, source candidates, downloads, copy hooks and path/URL/symlink logic remain byte-identical.',
 'frozen_original_replays':{
   'Unicode_source_and_literal':unicode_replay,
   'v5_CRLF_and_CR_only_regressions':CR_replays,
   'scope':'Same original frozen source bytes/hashes replayed in this new v6 output; old records and decisions were not altered.'},
 'real_C5_static':{
   'routes':['P34','P54','P125','P156','T59','T13'],
   'six_exact_code_and_formula_folds_initially_closed':True,
   'six_copy_button_panel_live_status_structures_meet_unchanged_actual_JS_selectors':True,
   'full_T_bytes':7494,'full_T_sha256':'90b43f488d3fe9b6c95d4c039d0f771ee5bfecdd699b72dfa52465643f0b0dee',
   'P_and_T_sourceHTML_targets_and_raw_downloads_correct':True,
   'no_hidden_current_C5_change':'Lesson render and complete P/T sourceHTML byte-identical to v5 under the same fixture. Both raw files byte-identical to candidate Git inputs.',
   'copy_contract_scope':'Actual candidate handler selectors read code from the nearest panel direct pre/code and status from the button parent; generated six panels satisfy this structurally. No JS/clipboard execution claimed.'},
 'independent_controls':{
   'newline_cases_passed':progress['newline_cases_passed'],
   'newline_scope':'Previous20 cases plus multiple/embedded CR, CRLF/final-CR, blank CR/CRCRLF, LF-then-CR, and CR adjacent to Unicode separators. Every LF anchor/span count, inclusive end-line, normalized presentation and raw-download equality passes.',
   'matching_controls_passed':progress['matching_controls_passed'],
   'matching_scope':'Previous15 controls plus raw CRLF versus LF and Unicode NFC versus NFD sources with equivalent presentation; matching distinguishes original bytes and does not invent ambiguity or equality.',
   'path_URL_symlink_controls_passed':progress['path_URL_symlink_controls_passed'],
   'path_validation_scope':'Bounded invalid path/URL, invalid path beside URL and outside-root source-symlink fixtures reject; safe internal symlink and valid HTTPS controls pass. No broad security proof claimed.',
   'canonical_export_controls_passed':progress['canonical_export_controls_passed'],
   'canonical_scope':'Canonical-only and canonical-plus-explicit-local-source export fixtures preserve raw files; no whole-site compatibility claim.',
   'strict_UTF8_negative_control':'Invalid UTF8 export raises the expected UnicodeDecodeError before complete sourceHTML/raw targets exist. Exact invalid input and exception record retained.'},
 'presentation_and_bytes_boundary':{
   'raw_matching_and_downloads':'Strict original UTF8 byte matching and raw source downloads retain exact original bytes.',
   'sourceHTML':'Numbered anchors follow raw LF partition. Presentation removes one redundant terminal CR per generated LF line and supplies the existing display LF for a nonempty unterminated final line. Embedded/additional CRs and Unicode separators retain their appropriate normalized display behavior.',
   'equality_claim':'No raw-byte equality claimed for CR-normalized or terminal-LF-adjusted sourceHTML presentation. Every tested v5/v6 HTML difference is restricted to the authorized redundant terminal-CR removal; current C5 LF-only pages remain byte-identical.'},
 'real_attempt_accounting':{
   'new_driver_exit_code':0,'new_failed_verifier_attempts':0,
   'expected_negative_UTF8_exception':'Recorded as a passing fail-closed control, not a renderer success or unexplained failed attempt.',
   'raw_outputs':['review.stdout.raw.txt','review.stderr.raw.txt','review.receipt.json'],
   'unavailable_runtime':'No new JS/clipboard/browser attempt or success asserted; previous unavailable attempts remain in their original freeze and were not relabeled.'},
 'fixture_limits':'Exact production/proposed functions and actual export_sources/base.page used with identity source_lineage global shell, unpublished Git and passed=false gate. HTML CR preprocessing simulated statically; no browser/MathJax/desktop/mobile/global delivery acceptance.',
 'preservation':'Only the requested exact own v5 renderer, previous verifier fixture scripts and frozen Unicode/CR sources and records were copied read-only. No prior freeze, tracked/shared code or publication metadata changed. No reviewer renderer repair implemented.',
 'authority_boundary':'Prospective disabled overlay review only. No shared adoption, mathematical/sourceV/native build/global acceptance and no release of earlier HOLDs. Stop after freeze.'
}
js('findings.json',findings)
put('findings.txt',
 'v6 PASS within bounded prospective static review; no defect found in tested scope; earlier freezes/HOLDs unchanged.\n'
 'Only advertised sourceHTML trailing-CR presentation expression differs from exact v5; raw LF anchors, matching/downloads and other logic unchanged.\n'
 'Frozen original Unicode, CRLF and CR-only inputs replay successfully. 34 newline,19 matching,35 path/URL/symlink,2 canonical-export controls and strict UTF8 negative export control pass.\n'
 'Real C5 P34/P54/P125/P156/T59/T13, six exact formula/code/closed/copy-panel structures, fullT7494B and exact source downloads pass; current C5 lesson/sourceHTML bytes equal v5.\n'
 'Raw download/matching bytes remain exact; CR-normalized/terminal-LF-adjusted sourceHTML presentation is not claimed byte-identical to raw source.\n'
 'No JS/clipboard/browser/MathJax/desktop/mobile/global/native/sourceV acceptance; no shared adoption or reviewer repair implementation.\n')
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
js('freeze-invocation.json',{'command':['python3',str(D/'finalize.py')],'started_at_utc':now,
 'scope':'Every descendant without payload truncation: exact proposals/patch, prior frozen original inputs, independent fixture scripts, all static pages/raw source downloads, controls including invalid UTF8 and all raw execution records. Only two explicit envelope files outside recursive payload hash list.',
 'regular_file_mode':'0444','directory_mode':'0555','symlink_policy':'Retain actual link texts and own-root target hashes; targets0444 and parent directories0555.'})
envelope={'freeze-manifest.json','freeze-outer-receipt.json'}
allpaths=sorted(D.rglob('*'))
links=[p for p in allpaths if p.is_symlink()]
files=[p for p in allpaths if p.is_file() and not p.is_symlink() and p.relative_to(D).as_posix() not in envelope]
dirs=[D]+[p for p in allpaths if p.is_dir() and not p.is_symlink()]
for p in links:assert p.resolve().is_relative_to(D) and p.resolve().is_file()
manifest={'schema':'astis-full-ui-v6-review-freeze/v1','scope':'Every descendant; no payload truncation; exactly two explicit envelope files outside recursive hash list.',
 'explicit_envelope_files':sorted(envelope),
 'regular_files':[{'path':p.relative_to(D).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes()),'mode':'0444'} for p in files],
 'directories':[{'path':'.' if p==D else p.relative_to(D).as_posix(),'mode':'0555'} for p in dirs],
 'symbolic_link_fixtures':[{'path':p.relative_to(D).as_posix(),'link_text':os.readlink(p),'link_text_sha256':sha(os.readlink(p).encode()),
   'resolved_target':p.resolve().relative_to(D).as_posix(),'resolved_target_sha256':sha(p.resolve().read_bytes()),'containment':'own review root; target0444/parent0555'} for p in links]}
mf=js('freeze-manifest.json',manifest)
outerreceipt={'schema':'astis-ui-v6-freeze-outer-receipt/v1','created_at_utc':now,
 'manifest_sha256':sha(mf.read_bytes()),'findings_sha256':sha((D/'findings.json').read_bytes()),
 'payload_regular_files':len(files),'payload_bytes':sum(p.stat().st_size for p in files),'directories':len(dirs),'symbolic_link_fixtures':len(links),
 'regular_file_mode':'0444','directory_mode':'0555','decision':'PASS bounded prospective static scope; all earlier HOLDs unchanged','earlier_freezes':'untouched'}
outer=js('freeze-outer-receipt.json',outerreceipt)
for p in files+[mf,outer]:p.chmod(0o444)
for p in sorted(dirs,key=lambda p:len(p.parts),reverse=True):p.chmod(0o555)
for row in manifest['regular_files']:
 p=D/row['path'];assert sha(p.read_bytes())==row['sha256'] and stat.S_IMODE(p.stat().st_mode)==0o444
for p in dirs:assert stat.S_IMODE(p.stat().st_mode)==0o555
for p in links:assert stat.S_IMODE(p.resolve().stat().st_mode)==0o444 and stat.S_IMODE(p.parent.stat().st_mode)==0o555
assert sha(mf.read_bytes())==outerreceipt['manifest_sha256']
print(json.dumps({**outerreceipt,'outer_receipt_sha256':sha(outer.read_bytes()),'frozen':True},indent=2))
