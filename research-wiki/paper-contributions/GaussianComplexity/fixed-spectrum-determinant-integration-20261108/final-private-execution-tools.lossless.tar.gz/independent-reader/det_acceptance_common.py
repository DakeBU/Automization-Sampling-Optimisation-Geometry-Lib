"""Future determinant acceptance guards. Definitions only; no evidence is made on import."""
from pathlib import Path
import argparse, datetime, gzip, hashlib, json, os, re, struct, subprocess, sys, tarfile

R = Path('/Users/zhouhuanjian/ASTIS-GC')
B = R/'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-determinant-integration-20261108'
OWN = B/'independent-integration-reader-review'
P = OWN/'proposal'
S = R/'.astis/huanjian-gc-fixed-spectrum-determinant-integration-20261108/independent-reader'
SOURCE = R/'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-determinant-semantic-evidence'
ADV = 'ASTIS-SA-20261108-GaussianComplexityFixedSpectrumDeterminant'
ACTOR = '/root/det_integration_reader'
PROOF = 'huanjian_gc_20261108_fixed_spectrum_determinant'
VERIFIER = '/root/reader_835194'
INTEGRATOR = 'huanjian_gc_20261108_fixed_spectrum_determinant_integration'
DECL = 'AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumDeterminant.actual_precision_det'
DJE = 'AutoSamplingTheory.TechnicalLemmas.Measure.DisplacementJacobianEntropy.det_conjStarAlgAut_eq'
ADMISS = 'AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumAdmissibility.actual_precision_admissible'
GPD = 'AutoSamplingTheory.TechnicalLemmas.Measure.GaussianPrecisionDensity.multivariateGaussian_eq_withDensity_of_posDef'
CONSUMER_PARENTS = [ADMISS, DECL, GPD]
MATH = 'a0310046dc10c06ce9f61959094322fb9016be1e'
BINDING = 'c70bb9b23e335acf768bb889f8229fcdf2a7af160e10fa89779d00dcba58374b'
CHECKER = R/'.astis/huanjian-gc-fixed-spectrum-determinant-integration-20261108/check_final_reader.py'
CHECKER_SHA = 'd191bcb9ea513e71e0c2357315dee1821fdcccdab6dc6a2f473d5289589f0766'
PROPOSAL_SHA = 'ab826ff9e6fbbd2db0f0fa766ceadaccf470448152727e48b987bab0ae7161ac'
PROPOSAL_FREEZE_SHA = 'bd6fa76e2469cc23222ed70d4a8443e82adb39df3735cacdfcb9d595be071723'
AUDIT_PATH = 'research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-determinant.json'
CELL_PATH = 'research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-determinant.json'
LEDGER = R/'runs/substantive_advances.jsonl'
DISC = R/'runs/substantive_discoveries.jsonl'
HEX64 = re.compile(r'[0-9a-f]{64}\Z')
COMMIT = re.compile(r'[0-9a-f]{40}\Z')
sha = lambda b: hashlib.sha256(b).hexdigest()
canon = lambda x: json.dumps(x, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()
def dump(value): return (json.dumps(value, ensure_ascii=False, indent=2)+'\n').encode()
def cmd(*args): return subprocess.check_output(args, cwd=R)
def head(): return cmd('git','rev-parse','HEAD').decode().strip()
def gitraw(commit,path): return cmd('git','show',commit+':'+path)
def rel(path): return str(path.relative_to(R))
def resolve(path):
 assert isinstance(path,str) and path and not '\x00' in path
 p=Path(path); p=p if p.is_absolute() else R/p
 p=p.resolve(); assert p.is_relative_to(R),str(p)
 return p
def descriptor(path): return {'path':rel(path),'sha256':sha(path.read_bytes())}
def read_ref(ref):
 assert isinstance(ref,dict) and set(ref)>={'path','sha256'} and HEX64.fullmatch(ref['sha256'])
 path=resolve(ref['path']); raw=path.read_bytes(); assert sha(raw)==ref['sha256'],str(path)
 return raw
def decoded_ref(ref):
 raw=read_ref(ref)
 encoding=ref.get('encoding','raw'); assert encoding in ('raw','gzip')
 return gzip.decompress(raw) if encoding=='gzip' else raw
def read_json_ref(ref): return json.loads(read_ref(ref))
def unpack(row):
 raw=resolve(row['path']).read_bytes(); assert sha(raw)==row['gzip_sha256']
 data=gzip.decompress(raw); assert sha(data)==row['raw_sha256'] and len(data)==row['raw_bytes']
 return data
def parse_args(description,configure=None):
 p=argparse.ArgumentParser(description=description)
 p.add_argument('--authorization-json',required=True)
 p.add_argument('--authorization-sha256',required=True)
 p.add_argument('--output',help='Optional new result/draft under this packet independent review directory; no overwrite.')
 if configure is not None: configure(p)
 return p.parse_args()
def load_authorization(args,kind='determinant-postcore-context'):
 assert HEX64.fullmatch(args.authorization_sha256)
 ref={'path':args.authorization_json,'sha256':args.authorization_sha256}
 raw=read_ref(ref); a=json.loads(raw)
 assert a['authorized_by']=='/root' and a['authorization_kind']==kind
 assert a['advance_id']==ADV and a['proof_owner_to_preserve']==PROOF and a['source_verifier_to_preserve']==VERIFIER
 assert a['integration_owner']==INTEGRATOR
 assert COMMIT.fullmatch(a['accepted_immutable_core']) and HEX64.fullmatch(a['source_digest'])
 assert a['publication_binding_sha256']==BINDING and a['new_source_verdict'] is False
 assert a['proposal_report_sha256']==PROPOSAL_SHA and a['browser_checker_sha256']==CHECKER_SHA
 return a, {'path':rel(resolve(ref['path'])),'sha256':sha(raw)}
def write_new_or_resume(path,value):
 p=resolve(path); assert p.is_relative_to(OWN) and p.suffix=='.json'
 value=dict(value); value['evidence_fingerprint']=sha(canon(value))
 if p.exists():
  old=json.loads(p.read_bytes())
  assert old['evidence_fingerprint']==value['evidence_fingerprint'],'Existing output differs; preserve it and choose a fresh path.'
  return {'path':rel(p),'sha256':sha(p.read_bytes()),'resumed_unchanged':True}
 value['recorded_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('xb') as stream: stream.write(dump(value))
 return {'path':rel(p),'sha256':sha(p.read_bytes()),'resumed_unchanged':False}
def emit(args,value):
 print(json.dumps(write_new_or_resume(args.output,value) if args.output else value,ensure_ascii=False,indent=2))
def modules():
 sys.dont_write_bytecode=True
 if str(R/'tools') not in sys.path: sys.path.insert(0,str(R/'tools'))
 import astis_advance, astis_publication, astis_site
 return astis_advance,astis_publication,astis_site
def source_lineage(a):
 adv,_,_=modules(); lineage=a['source_lineage']; core=a['accepted_immutable_core']
 checked=lineage['checked_commit']; accepted=lineage['accepted_audit_first_commit']; firstV=lineage['source_V_first_commit']
 for commit in [checked,accepted,firstV]: assert COMMIT.fullmatch(commit)
 for x,y in [(MATH,checked),(checked,accepted),(accepted,firstV),(firstV,core)]: cmd('git','merge-base','--is-ancestor',x,y)
 auditraw=read_ref(lineage['accepted_audit']); assert rel(resolve(lineage['accepted_audit']['path']))==AUDIT_PATH
 assert (R/AUDIT_PATH).read_bytes()==gitraw(core,AUDIT_PATH)==gitraw(accepted,AUDIT_PATH)==gitraw(firstV,AUDIT_PATH)==auditraw
 audit=json.loads(auditraw); assert audit['state']=='accepted' and audit['publication_binding_sha256']==BINDING
 assert audit['source_review']['reviewer']==VERIFIER and audit['lean']['formalizer']==PROOF
 assert audit['reconstruction']['decoder'] not in (PROOF,VERIFIER,ACTOR,'/root')
 assert json.loads(gitraw(checked,AUDIT_PATH))['state']=='blind-reconstructed'
 run=read_ref(lineage['source_review_run']); assert sha(run)==audit['source_review']['review_run_sha256']
 assert resolve(lineage['source_review_run']['path'])==resolve(audit['source_review']['run_artifact'])
 before=decoded_ref(lineage['source_V_before']); after=decoded_ref(lineage['source_V_after']); append=decoded_ref(lineage['source_V_append'])
 assert before.endswith(b'\n') and append.endswith(b'\n') and len(append.splitlines())==1 and after==before+append
 assert gitraw(checked,'runs/substantive_advances.jsonl')==before
 assert gitraw(firstV,'runs/substantive_advances.jsonl')==after
 event=json.loads(append); evidence=event['evidence']
 assert event['advance_id']==ADV and event['worker_id']==VERIFIER
 assert event['from_state']=='PROVED_LOCAL' and event['to_state']=='VERIFIED'
 assert evidence['verifier_id']==VERIFIER and evidence['verified_commit']==checked
 for key in ['gate','source_audit','fake_closure_scan']: assert evidence[key]
 api=read_json_ref(lineage['source_V_API_receipt'])
 assert api.get('returncode',api.get('exit_code'))==0
 raw=LEDGER.read_bytes(); assert raw.startswith(after) and raw.count(append)==1
 tail=raw[len(after):]; assert len(tail.splitlines())==1,'Expected exactly the one original normal STAB append after source V.'
 stab=json.loads(tail); assert stab['advance_id']==ADV and stab['worker_id']==INTEGRATOR
 assert stab['from_state']=='VERIFIED' and stab['to_state']=='STABILIZING'
 assert len([json.loads(line) for line in raw.splitlines() if json.loads(line).get('advance_id')==ADV and json.loads(line).get('to_state')=='VERIFIED'])==1
 own=adv.current_advances()[ADV]; assert own['owner_id']==PROOF and own['state']=='STABILIZING'
 return {'checked_commit':checked,'accepted_audit_first_commit':accepted,'source_V_first_commit':firstV,'accepted_audit_sha256':sha(auditraw),'source_review_run_sha256':sha(run),'actual_original_source_verifier':VERIFIER,'proof_owner':PROOF,'source_V_append_sha256':sha(append),'source_V_append_bytes':len(append),'source_V_API_receipt':lineage['source_V_API_receipt'],'source_V_existing_unique':True,'new_source_verdict':False}
def protections(a):
 adv,pub,site=modules(); core=a['accepted_immutable_core']; assert head()==core
 rp=P/'proposal-report.json'; assert sha(rp.read_bytes())==PROPOSAL_SHA and sha((P/'freeze.json').read_bytes())==PROPOSAL_FREEZE_SHA
 plan=json.loads(rp.read_bytes()); assert len(plan['shared_paths'])==6 and plan['formal_ASTIS_producer_parents']==[DJE]
 supplement_ref=a['supplementary_index_proposal']
 assert supplement_ref['sha256']=='f34ddae19da4c5b6980ce20bd08a99ee1c112b5e95bdc34c9e0e552af720f7ed'
 supplement=read_json_ref(supplement_ref)
 assert resolve(supplement_ref['path'])==P/'canonical-dje-index-supplement/supplementary-index-proposal.json'
 assert supplement['original_six_path_proposal_report_sha256']==PROPOSAL_SHA
 assert supplement['new_mathematical_declarations']==0 and supplement['new_SAUs_or_source_verdicts']==0
 assert supplement['actual_formalizedLocal_records_before']==619 and supplement['proposed_administrative_count_after']==620
 overlay={row['path']:row for row in supplement['shared_paths']}
 assert len(supplement['shared_paths'])==2 and set(overlay)=={'AutoSamplingTheory/TechnicalLemmas/Registry.lean','Tests/Basic.lean'}
 for row in plan['shared_paths']:
  if row['path'] in overlay:
   extra=overlay[row['path']]
   assert extra['before_sha256']==row['planned_after_sha256'] and unpack(extra['before_archive'])==unpack(row['planned_after_archive'])

 firstV=a['source_lineage']['source_V_first_commit']
 for row in plan['shared_paths']:
  path=row['path']; raw=(R/path).read_bytes()
  if path in overlay:
   extra=overlay[path]
   assert sha(raw)==extra['proposed_after_sha256'] and raw==unpack(extra['proposed_after_archive'])==gitraw(core,path)
  else: assert sha(raw)==row['planned_after_sha256'] and raw==unpack(row['planned_after_archive'])==gitraw(core,path)
  if row['before_exists']: assert unpack(row['before_archive'])==gitraw(firstV,path)
  else: assert subprocess.run(['git','cat-file','-e',firstV+':'+path],cwd=R,stdout=subprocess.PIPE,stderr=subprocess.PIPE).returncode!=0
 for path,digest in {**plan['source_Test_lesson_publication_pins'],**plan['unchanged_models']}.items():
  raw=(R/path).read_bytes(); assert sha(raw)==digest and gitraw(core,path)==raw,path
 item=next(x for x in pub.load() if x['id']=='huanjian-fixed-spectrum-determinant')
 assert pub.binding_digest(item,item['bindings'][0])==BINDING
 frontier=json.loads((R/'website/content/samplewiki_companion_frontiers.json').read_bytes()); protected=plan['protected_case_values']
 assert sha(canon(frontier['execution']))==protected['execution_sha256']
 assert sha(canon(frontier['cases'][4]['theorems'][0]))==protected['determinant_theorem_index0_sha256']
 assert frontier['cases'][4]['theorems'][1]['boundary'].endswith(protected['Section4_4_limitation_suffix'])
 frontier['cases'][4]['reader_guide'][3]='<OWN_DETERMINANT_SCALAR>';frontier['cases'][4]['theorems'][1]['boundary']='<OWN_DETERMINANT_SCALAR>'
 assert sha(canon(frontier))==protected['all_other_case_values_sha256']
 registry=(R/plan['shared_paths'][3]['path']).read_bytes()
 assert registry.count(b'status := LemmaMemoryStatus.formalizedLocal')==620
 assert registry.count(b'key := "gaussian-complexity.fixed-spectrum-determinant"')==1
 assert registry.count(b'key := \"measure.det-conj-star-alg-aut-existing-canonical\"'.replace(b'\\',b''))==1
 assert (R/'Tests/Basic.lean').read_bytes().count(b'formalizedTechnicalLemmaCount = 620')==1
 states=adv.current_advances(); own=states[ADV]
 assert own['owner_id']==PROOF and own['state']=='STABILIZING' and own['latest_evidence']['integration_owner']==INTEGRATOR
 assert [k for k,v in states.items() if v['state']=='STABILIZING']==[ADV]
 counts={}
 for path,row in plan['ledger_protection'].items():
  raw=(R/path).read_bytes(); assert raw.startswith(unpack(row['raw_prefix'])) and raw.endswith(b'\n')
  expected=json.loads(unpack(row['foreign_projection']))
  now={k:v for k,v in states.items() if k!=ADV} if 'advances' in path else {k:v for k,v in adv.current_discoveries().items() if v.get('advance_id')!=ADV}
  assert now==expected,path
  counts[path]=len(now)
 assert counts['runs/substantive_advances.jsonl']==282
 inputs=json.loads(unpack(plan['protected_foreign_content']))
 for path,row in inputs.items():
  q=R/path; raw=os.fsencode(os.readlink(q)) if q.is_symlink() else q.read_bytes()
  assert sha(raw)==row['sha256'] and len(raw)==row['bytes'],path
 gitmap=json.loads(unpack(plan['protected_git_objects'])); nowmap={}
 for line in cmd('git','ls-files','--stage','-z').split(b'\0'):
  if not line: continue
  md,path=line.split(b'\t',1);mode,blob,stage=md.decode().split();assert stage=='0'
  nowmap[os.fsdecode(path)]=[mode,blob]
 for path,row in gitmap.items(): assert nowmap.get(path)==row,path
 foreignfrontiers=json.loads(unpack(plan['foreign_frontiers']))
 currentfrontiers={rel(p):sha(p.read_bytes()) for p in (R/'research-wiki/frontier-cells').glob('*.json') if p.name!=Path(CELL_PATH).name}
 assert currentfrontiers==foreignfrontiers and len(foreignfrontiers)==441
 oldgc=json.loads(unpack(plan['older_GaussianComplexity_evidence']))
 for path,digest in oldgc.items(): assert sha((R/path).read_bytes())==digest,path
 readme=plan['README_preservation']; assert sha((R/readme['path']).read_bytes())==readme['sha256']
 atlas=(R/'.atlas-upstream').stat(); oldatlas=plan['untracked_Atlas']
 assert (atlas.st_dev,atlas.st_ino,atlas.st_mtime_ns)==(oldatlas['device'],oldatlas['inode'],oldatlas['mtime_ns'])
 assert head()==core and site.source_digest()==a['source_digest']
 return {'original_six_after_plus_exact_two_path_index_overlay_and_old_Registry_preserved':True,'supplementary_index_proposal':supplement_ref,'canonical_Registry_count':620,'producer_ASTIS_parents':[DJE],'consumer_ASTIS_parents':CONSUMER_PARENTS,'no_new_public_or_Registry_consumer':True,'foreign_advances':282,'foreign_discoveries':counts['runs/substantive_discoveries.jsonl'],'foreign_frontiers':441,'protected_foreign_content':len(inputs),'protected_git_objects':len(gitmap),'older_GC_evidence':len(oldgc),'README_unchanged':True,'Atlas_directory_stat_only_unchanged':True,'both_models':plan['unchanged_models'],'determinant_index0_execution_other_case_values_Section4_4_suffix_unchanged':True,'ledger_prefixes_and_exact_foreign_projections_preserved':True}
def actual_checks(a):
 _,_,site=modules(); core=a['accepted_immutable_core']
 assert sha(CHECKER.read_bytes())==CHECKER_SHA
 gate=read_json_ref(a['actual_gate']); metadata=read_json_ref(a['site_metadata'])
 assert resolve(a['actual_gate']['path'])==R/'.astis/site-lean-gate.json'
 assert resolve(a['site_metadata']['path'])==R/'_site/data/build-metadata.json'
 assert gate['passed'] and metadata['gate']['passed'] and metadata['gate']['current']
 assert gate['commit']==metadata['git']['commit']==head()==core
 assert gate['source_digest']==metadata['source_digest']==site.source_digest()==a['source_digest']
 required={'canonical_lean':'tools/astis.py','site_build':'website/scripts/build_site.py','site_check':'website/scripts/check_site.py','graph_check':'graph-check','browser':rel(CHECKER)}
 assert set(a['actual_checks'])==set(required)
 receipts=[]
 for role,needle in required.items():
  ref=a['actual_checks'][role]; receipt=read_json_ref(ref)
  assert receipt['exit_code']==0 and receipt['head_before']==receipt['head_after']==core
  assert receipt['elapsed_seconds']>=0
  rawlog=resolve(receipt['log']).read_bytes(); assert sha(rawlog)==receipt['log_sha256']
  if role=='canonical_lean':
   command=receipt['command']
   assert isinstance(command,list) and command and all(isinstance(x,str) for x in command)
   assert re.fullmatch(r'python(?:3(?:\.\d+)?)?',Path(command[0]).name)
   output=rawlog.decode('utf-8'); lines=output.splitlines()
   assert lines.count('ASTIS check passed')==1
   if command[1:]==['tools/astis.py','check']:
    pass  # The original direct canonical entry point, with its genuine success log.
   elif command[1:]==['website/scripts/lean_gate.py']:
    wrapper='website/scripts/lean_gate.py'; wrapperraw=(R/wrapper).read_bytes()
    assert wrapperraw==gitraw(core,wrapper)
    assert sha(wrapperraw)=='d69c42b3aee3a60775646711f220e8c558fb447af741616d88bdb8df82d18f91'
    assert gate['commands']==['python3 tools/astis.py check']
    marker='Recorded current Lean gate evidence at .astis/site-lean-gate.json'
    assert lines.count(marker)==1 and output.rstrip().endswith(marker)
    assert 'Lean gate failed; no site evidence was written.' not in output
    assert '::error title=ASTIS Lean gate failed::' not in output
    start=datetime.datetime.strptime(receipt['started_utc'],'%Y%m%dT%H%M%S%fZ').replace(tzinfo=datetime.timezone.utc)
    recorded=datetime.datetime.fromisoformat(gate['generated_at'])
    assert recorded.tzinfo is not None and 0 <= (recorded-start).total_seconds() <= receipt['elapsed_seconds']+2
   else: raise AssertionError('Unrecognized canonical Lean gate entry point; no receipt-shape shortcut.')
  else: assert needle in str(receipt['command'])
  receipts.append({'role':role,'receipt':ref,'raw_log_sha256':sha(rawlog),'elapsed_seconds':receipt['elapsed_seconds'],'command':receipt['command']})
 return {'core':core,'source_digest':a['source_digest'],'actual_gate':a['actual_gate'],'site_metadata':a['site_metadata'],'receipts':receipts}
def expected_png_names():
 names=set()
 for width in (1440,390):
  for name in ['first','assumptions',*[f'proof-step{i}' for i in range(1,6)],'standard-reuse','exact-statement','exact-proof','module','source-index-open','graph-focused','graph-module-native-click']:
   names.add(f'actual-{width}-{name}.png')
  for name in [f'case-boundary-{width}',f'source-index-{width}',f'canonical-DJE-{width}-graph-native-parent-click',f'canonical-Gaussian-{width}-graph-focused',f'existing-conceptual-{width}-unchanged']:
   names.add(name+'.png')
 assert len(names)==38
 return names
def unchanged_foreign_graph_guard():
 # Preserve the held39798 graph as historical evidence. This supplementary
 # admission is exactly one canonical existing node and two labelled edges.
 archive=P/'canonical-dje-index-supplement/guard-overlay-preparation/held-original-39798-graph.json.raw.gz'
 oldraw=gzip.decompress(archive.read_bytes())
 assert sha(oldraw)=='1a9b4835847a4f587da14989d65a5f7eea3caa4c271783e605903f4caa4098a5'
 old=json.loads(oldraw);new=json.loads((R/'_site/data/underlying-lean-graph.json').read_bytes())
 oldnodes={x['id']:x for x in old['nodes']};newnodes={x['id']:x for x in new['nodes']}
 parent='decl:'+DJE;child='decl:'+DECL;module='module:AutoSamplingTheory.TechnicalLemmas.Measure.DisplacementJacobianEntropy'
 assert parent not in oldnodes and set(newnodes)==set(oldnodes)|{parent}
 assert newnodes[parent]['kind']=='declaration' and newnodes[parent]['status']=='compiled'
 assert 'compilation-only-index' in newnodes[parent]['summary'] and 'legacy-source-audit-debt' in newnodes[parent]['summary']
 for ident,value in oldnodes.items():
  if ident!=child: assert newnodes[ident]==value,ident
 prior=oldnodes[child];now=newnodes[child]
 assert set(prior)==set(now) and all(prior[k]==now[k] for k in prior if k not in ['details','search'])
 details=json.loads(json.dumps(prior['details']))
 refs=[x for x in details if x['label']=='References (name scan; incomplete)']
 assert len(refs)==1 and refs[0]['value']=='';refs[0]['value']=DJE
 assert now['details']==details
 inserted=' '+DJE.lower()
 assert now['search'].count(inserted)==1 and now['search'].replace(inserted,'',1)==prior['search']
 triples=lambda graph:{(x['source'],x['target'],x['relation']) for x in graph['edges']}
 oldedges=triples(old);newedges=triples(new)
 assert oldedges<=newedges and newedges-oldedges=={(module,parent,'declares'),(parent,child,'source reference (scanner)')}
 assert all(old[k]==new[k] for k in old if k not in ['nodes','edges','counts','publication_inputs_sha256'])
 expected=dict(old['counts']);expected['registry_declarations']+=1;expected['nodes']+=1;expected['edges']+=2
 assert new['counts']==expected
 return {'held39798_graph_sha256':sha(oldraw),'one_existing_canonical_compilation_only_node_added':parent,'all_older_foreign_nodes_and_edges_exactly_preserved':True,'only_prior_node_change':child,'two_new_edges':'Owning-module declares plus true source-name scan only; no formal proof or conceptual edge.'}

def browser_evidence(a):
 browser=read_json_ref(a['browser_report']); core=a['accepted_immutable_core']; path=resolve(a['browser_report']['path'])
 assert path.name=='report.json' and path.parent.is_relative_to(R/'.astis/huanjian-gc-fixed-spectrum-determinant-integration-20261108/browser')
 assert browser['status']=='passed' and not browser['errors']
 unchanged_foreign_graph_guard()
 assert browser['head']==browser['actual_gate_commit']==browser['site_commit']==core
 assert browser['source_digest']==a['source_digest'] and browser['publication_binding_sha256']==BINDING
 assert browser['site_metadata_sha256']==a['site_metadata']['sha256'] and browser['actual_gate_sha256']==a['actual_gate']['sha256']
 assert browser['producer_ASTIS_parents']==[DJE] and browser['consumer_ASTIS_parents']==CONSUMER_PARENTS
 assert browser['external_GitHub_HTML_checked'] is False
 assert len(browser['pages'])==2 and {x['width'] for x in browser['pages']}=={1440,390}
 for row in browser['pages']:
  for key in ['closed_initially','five_formula_steps_opened','adjacent_exact_statement_and_proof','full_module_download_immutable_git_bytes_verified','consumer_private_name_only']:
   assert row[key] is True
  assert row['target']==DECL and row['producer_ASTIS_parents']==[DJE] and row['consumer_ASTIS_parents']==CONSUMER_PARENTS
  assert row['fullpage_overflow'] is False and row['external_GitHub_HTML_checked'] is False
  link=row['immutable_link_syntax_checked']
  if link is None: assert row['module_link_branch']=='own-site module only; GitHub syntax branch not executed'
  else:
   assert row['module_link_branch']=='GitHub commit/path syntax plus local own-site module'
   assert re.fullmatch(r'https://github\.com/[^/]+/[^/]+/blob/'+core+r'/AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumDeterminant\.lean#L\d+(?:-L\d+)?',link)
 assert len(browser['visible_source_index_clicks'])==2 and all(x['actual_click'] for x in browser['visible_source_index_clicks'])
 assert len(browser['graphs'])==4
 ownrows=[x for x in browser['graphs'] if x['target']=='decl:'+DECL]
 assert len(ownrows)==2
 for row in ownrows:
  assert row['producer_ASTIS_parents']==[DJE] and row['native_canonical_DJE_parent_click'] and row['source_scanner_edge_not_kernel_evidence'] and row['native_neighbor_module_click']
 screenshots=browser['screenshots']; assert len(screenshots)==38
 assert {x['file'] for x in screenshots}==expected_png_names()=={p.name for p in path.parent.glob('*.png')}
 images=[]
 for row in screenshots:
  p=path.parent/row['file']; assert p.parent==path.parent
  raw=p.read_bytes(); assert sha(raw)==row['sha256'] and raw[:8]==b'\x89PNG\r\n\x1a\n'
  width,height=struct.unpack('>II',raw[16:24]); assert (width,height) in [(1440,1000),(390,844)]
  assert f'-{width}' in p.name
  images.append({'path':rel(p),'sha256':sha(raw),'bytes':len(raw),'width':width,'height':height})
 for path,digest in browser['input_pins'].items(): assert sha((R/path).read_bytes())==digest and gitraw(core,path)==(R/path).read_bytes()
 return browser,images
def verify_archive(a):
 browser,images=browser_evidence(a)
 ref=a['retained_archive_manifest']; manifest=read_json_ref(ref)
 archive=resolve(manifest['archive']); raw=archive.read_bytes(); assert sha(raw)==manifest['archive_sha256']
 expected={x['path']:x['sha256'] for x in images};expected[rel(resolve(a['browser_report']['path']))]=a['browser_report']['sha256']
 rows=manifest['files']; assert len(rows)==39 and {x['original'] for x in rows}==set(expected)
 assert len({x['member'] for x in rows})==39
 with tarfile.open(archive,'r:gz') as tar:
  members=tar.getmembers(); assert len(members)==39 and {x.name for x in members}=={x['member'] for x in rows}
  for member in members:
   assert member.isfile() and not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
  for row in rows:
   original=resolve(row['original']).read_bytes(); assert sha(original)==row['raw_sha256']==expected[row['original']]
   member=tar.getmember(row['member']); assert member.size==len(original)
   assert tar.extractfile(member).read()==original
 return {'state':'LOSSLESS_RETAINED_BROWSER_ARCHIVE_VERIFIED','archive':rel(archive),'archive_sha256':sha(raw),'manifest':ref,'all_39_original_members_losslessly_compared':True,'original_PNG_count':38,'visual_review_performed_by_this_checker':False,'external_GitHub_HTML_or_public_HTTP_credited':False,'original_hashes':expected}
def validate_image_review(a,images):
 review=read_json_ref(a['independent_original_image_review'])
 assert review['state']=='ORIGINAL38_REVIEW_COMPLETED' and review['reviewer']==ACTOR
 assert review['accepted_immutable_core']==a['accepted_immutable_core'] and review['browser_report_sha256']==a['browser_report']['sha256']
 assert review['blocking_objections']==[] and len(review['images'])==38
 expected={x['path']:x for x in images}; assert {x['path'] for x in review['images']}==set(expected)
 for row in review['images']:
  original=expected[row['path']]
  assert row['sha256']==original['sha256'] and row['width']==original['width'] and row['height']==original['height']
  assert row['actually_viewed_original'] is True and row['reviewer']==ACTOR
  assert row['view_method']=='tools.view_image detail=original; direct original file'
  assert row['decision'] in ['ACCEPTED','ACCEPTED_WITH_RECORDED_LIMITS']
  assert isinstance(row['observation'],str) and len(row['observation'].strip())>=25
  assert not re.search(r'\b(TODO|PLACEHOLDER|UNREVIEWED|PENDING)\b',row['observation'],re.I)
  assert isinstance(row['viewport_limits'],list) and row['viewport_limits'] and all(isinstance(x,str) and x.strip() for x in row['viewport_limits'])
 assert review['parent_status_caveat_acknowledged'] is True and review['per_row_source_link_scope_acknowledged'] is True
 return review
def origin_readback(a):
 origin=read_json_ref(a['origin_main_readback'])
 assert origin['this_file_is_structured_readback_not_a_retroactive_run_check_receipt'] is True
 assert origin['preceding_actual_tool_command']==['git','fetch','origin'] and origin['preceding_actual_tool_exit_code']==0
 assert origin['origin_main_after_fetch']=='d9bcd4231df69061c5221f8d557ee179a945c1eb'
 assert origin['fixed_checked_HEAD']=='15fbef72d04a1e9d1e647289a099a6ff8f829125' and origin['main_is_ancestor_of_checked_HEAD'] is True
 assert origin['remote_owner_release_or_PR_merge_checked'] is False
 assert cmd('git','rev-parse','origin/main').decode().strip()==origin['origin_main_after_fetch']
 cmd('git','merge-base','--is-ancestor',origin['origin_main_after_fetch'],a['accepted_immutable_core'])
 return {'origin_main_readback':a['origin_main_readback'],'origin_main_scope':'Preserve the real earlier fetch/readback as structured historical evidence. No repeated fetch, new origin freshness, remote owner release or PR merge claim.'}
def all_readonly_checks(a):
 lineage=source_lineage(a); protection=protections(a); checks=actual_checks(a); browser,images=browser_evidence(a)
 origin=origin_readback(a)
 assert head()==a['accepted_immutable_core']
 return {'sourceV_lineage':lineage,'protection':protection,'actual_checks':checks,'browser_report':a['browser_report'],'original_image_hashes':images,**origin,'new_source_verdict':False},browser,images
