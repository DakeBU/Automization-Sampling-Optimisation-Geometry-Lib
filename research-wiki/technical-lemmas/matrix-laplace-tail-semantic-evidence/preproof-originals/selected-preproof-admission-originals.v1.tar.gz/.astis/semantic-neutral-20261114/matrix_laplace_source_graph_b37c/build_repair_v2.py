import copy, datetime, hashlib, json, pathlib, re
B=pathlib.Path(__file__).resolve().parent
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def put(name,obj):
    p=B/name; assert not p.exists(),f'append-only: {name} exists'
    p.write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n'); return sha(p)
v1=B/'phase1.source-only.graph.frozen.v1.json'
assert sha(v1)=='fef1100b26718cce7884f745a2cea3f75cb8a2c3897b885a660123b6c149758d'
challenge=pathlib.Path('/Users/zhouhuanjian/ASTIS-GC/.astis/semantic-neutral-20261114/matrix_laplace_topology_4c9e/phase2/original-challenge.findings.v1.json')
assert sha(challenge)=='271c8c258f0be2f1e2c28ff1bb3c076f35c328933b66710903123bd3cd28ccc2'
supp=pathlib.Path('/Users/zhouhuanjian/ASTIS-GC/.astis/huanjian-gc-matrix-laplace-20261114/binder-inventory-singleton.supplement.v1.json')
assert sha(supp)=='174a4297cc2e600a5bcca92586f38759f8b24c9dbfd4533fb4cfb35761b23af8'
g=copy.deepcopy(json.loads(v1.read_text())); g['schema']='independent-source-graph-reviewed-repair-proposal-v2'; g['phase']='V2_APPEND_ONLY_GRAPH_REPAIR_PROPOSAL_PENDING_DISTINCT_TC'; g['repair_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
g['v1_source_only_freeze']={'file':v1.name,'sha256':sha(v1),'preserved':True}
g['review_challenge']={'file':str(challenge),'sha256':sha(challenge),'findings_addressed':['TC15-F1','TC15-F2']}
g['source_only_freeze_not_retroactively_rewritten']=True
removed={'GC.TRUNC.TAIL','GC.BERNSTEIN.CONSUMER'}
g['nodes']=[n for n in g['nodes'] if n['id'] not in removed]
g['edges']=[e for e in g['edges'] if e['producer'] not in removed and e['consumer'] not in removed]
def newnode(i,kind,anchor,claim,role):
    return {'id':i,'kind':kind,'source_anchor':anchor,'claim':claim,'role':role,'formal_status':'UNPROVED_IN_THIS_AUDIT','proof_obligation':claim}
added=[
newnode('GC.FEATURE.NORM','substantive-proof-step','Gaussian FactC5 statement A3.Thmtheorem5.p1/Ex87 first inequality; proof A3.SS2.p8/Ex102; consumer p13','From the literal t_i definition, ||t_i||^2=1+2 sum_{j=1}^q cos^2(j theta_i)<=1+2q<=2r. This proof uses only the finite cosine bound and q>=0, including q=0.','source-proof-step'),
newnode('GC.Y.REGULARITY','source-gap','Gaussian A3.Ex107 literal cutoff, A3.SS2.p13/Ex111 Y_i norm subformula; prerequisite omitted before A3.p12 mean','Before computing or using any ordinary mean: source model has d>=2 and finite nonnegative L; coordinates, row norm, rank-one outer products and Kronecker product are measurable; cutoff {R_i<=L} is measurable; ||Y_i||op=d^{-1}R_i||t_i||^2 1_{R_i<=L}<=2rL/d. Hence each literal Y_i is integrable under the unconditional probability law. The cutoff scalar R_i 1_{R_i<=L} and truncated row outer product also have finite genuine expectations by the same cutoff bound. Establish symmetry pointwise and preservation by the actual finite expectation. No centered sum or mean formula is a producer of this node.','internal-bookkeeping-before-mean'),
newnode('BG.GAUSSIAN.ROW.MEAN','source-gap','Gaussian A3.SS2.p1 row law and p12 radial-symmetry / E R_i=r use','For the literal original independent standard-Gaussian columns, the reordered row has N(0,I_r) law. Its isotropic/radial invariance yields the scalar-identity form of the truncated row outer expectation; its coordinate second moments give E R_i=r. These are explicit unproved background producers for the source mean formula and a<=1, separate from the excluded chi-square exponential-mgf tail calculation. The truncated expectation domain is already supplied by GC.Y.REGULARITY.','external-background')
]
g['nodes']+=added
by={n['id']:n for n in g['nodes']}
updates={
'GC.MEAN':('Gaussian A3.SS2.p12 retained radial/mean subregions: Ex108, E R_i=r and 0<=a<=1, inline E Y_i formula; Ex109/Ex110 excluded','After GC.Y.REGULARITY establishes genuine finite expectations, radial invariance gives E[gamma_i gamma_i^T 1_{R_i<=L}]=a I_r with a=r^{-1}E[R_i 1_{R_i<=L}]. Standard Gaussian second moments E R_i=r imply 0<=a<=1. Therefore E Y_i=(a/d)(I_r tensor t_i t_i^T). Bias tail and FactC5 sum-mean identities are not part of this node.'),
'GC.CENTER':('Gaussian A3.SS2.p13 centering clause; cosine summand clause','With the actual finite mean justified upstream by GC.Y.REGULARITY and GC.MEAN, define Z_i=Y_i-E Y_i and its deterministic cosine multiple. H0=sum_i Z_i and H1=sum_i cos(n theta_i)Z_i are finite ordinary sums.'),
'GC.RADIUS':('Gaussian A3.SS2.p13: feature-bound reuse, Ex111 mean bound, Ex112 centered bound and cosine bound','Use upstream GC.FEATURE.NORM and GC.Y.REGULARITY for the source Y bound, and the already genuine mean formula for ||E Y_i||op=a||t_i||^2/d<=2r/d. Triangle inequality gives ||Z_i||op<=R*=2r(L+1)/d; cosine multiplication preserves this bound because |cos|<=1. Mean existence is not deferred to a downstream sum.'),
'GC.SELFADJOINT':('Gaussian A3.SS2.p15 self-adjoint subclaim; literal Ex107 and p13','Pointwise real rank-one tensor symmetry and scalar cutoff make Y_i symmetric; GC.Y.REGULARITY supplies its actual finite expectation and permits expectation to preserve symmetry. Thus each Z_i, deterministic cosine multiple, finite sum and global negative is self-adjoint. The independent/centered assertions in p15 belong to the excluded Bernstein application.'),
'GC.SUM.BOUND':('implicit finite-sum bridge after genuine means and centered bounds','Only after Y and its true mean are supplied upstream: finite-sum measurability and triangle inequality give ||Hj||op<=dR* for j=0,1 and the same for -Hj. This node does not supply Y/mean integrability and cannot feed back into GC.MEAN.'),
'GC.NORM.EVENT':('downstream inferred adapter at Gaussian A3.Ex121 / p15.2 consumer locations; numerical source claims excluded','DOWNSTREAM OPEN ONLY: ||Hj||op=max(lambda_max Hj,lambda_max(-Hj)); for t>0 the strict norm event is a union of strict largest-eigenvalue events, each contained in the corresponding >=t event. A future union-bound adapter must prove this. No equality of > and >= probabilities; this is not a P/T ancestor or an Eq121 proof.')
}
for i,(anchor,claim) in updates.items(): by[i]['source_anchor']=anchor; by[i]['claim']=claim; by[i]['proof_obligation']=claim
def edge(a,b,use): return {'producer':a,'consumer':b,'consumer_use_site':use,'status':'SOURCE_TOPOLOGY_ONLY_NOT_COMPILED'}
newedges=[]
for a in ['GC.MODEL']:
    newedges.append(edge(a,'GC.FEATURE.NORM','A3.p8 / Ex102 feature-norm expansion'))
for a in ['GC.MODEL','GC.TRUNC','BG.MEAS','GC.FEATURE.NORM']:
    newedges.append(edge(a,'GC.Y.REGULARITY','Before A3.p12 actual mean: measurable cutoff/rank-one tensor and uniform Y bound from p13 first formula'))
newedges.append(edge('GC.MODEL','BG.GAUSSIAN.ROW.MEAN','A3.p12 radial invariance and E R_i=r use'))
for a in ['GC.Y.REGULARITY','BG.GAUSSIAN.ROW.MEAN']:
    newedges.append(edge(a,'GC.MEAN','A3.p12 finite genuine radial and matrix expectations before their use'))
for consumer in ['GC.CENTER','GC.RADIUS','GC.SELFADJOINT']:
    newedges.append(edge('GC.Y.REGULARITY',consumer,'Actual finite source mean supplied before centered/norm/symmetry use'))
newedges.append(edge('GC.FEATURE.NORM','GC.RADIUS','A3.p13 explicit reuse of p8 feature norm'))
g['edges']+=newedges
# Replace Gaussian coarse coverage exclusions by exact coverage below. Tropp and accidental raw-context exclusions remain unchanged.
g['exclusions']=[x for x in g['exclusions'] if not x['anchor'].startswith('Gaussian A3.SS2')]
g['exclusions'].append({'anchor':'Exact Gaussian C2 coverage inventory','reason':'See coverage.exact.v2.json. It partitions mixed paragraphs, C5/C6 statements and all displays Ex85–Ex132; no whole-C6 exclusion overlaps retained C6 proof subregions.'})
g['external_background_map'].append({'source':'Gaussian A3.SS2.p12 radial symmetry and E R_i=r','use':'BG.GAUSSIAN.ROW.MEAN, explicit open background producer; truncated expectation domain must come from predecessor GC.Y.REGULARITY.'})
g['source_gaps']=['BG.MEAS','BG.NONNEG.EXPECTATION','GC.Y.REGULARITY','BG.GAUSSIAN.ROW.MEAN','GC.SUM.BOUND','GC.FINITE.MGF','GC.NORM.EVENT']
g['excluded_downstream_source_consumers']=[{'source_anchor':'A3.Ex121 / A3.SS2.p15 / p15.2','use':'Actual consumer location for the two sums and their implicit two-sided sign split. Numerical Bernstein claim excluded from P/T graph; no edge from the excluded result feeds back to GC.FOUR.'}]
g['coverage_inventory']='coverage.exact.v2.json'
g['independent_topology_admission']='PENDING_DISTINCT_TC_REVIEW_NOT_SELF_ADMITTED'
ids={n['id'] for n in g['nodes']}; assert len(ids)==len(g['nodes'])
pending=set(ids); done=set(); order=[]
while pending:
    ready={v for v in pending if all(e['producer'] in done for e in g['edges'] if e['consumer']==v)}
    assert ready,'cycle'; order+=sorted(ready); pending-=ready; done|=ready
assert order.index('GC.Y.REGULARITY')<order.index('GC.MEAN')<order.index('GC.RADIUS')<order.index('GC.SUM.BOUND')
assert not any(e['consumer'] in {'GC.MEAN','GC.Y.REGULARITY'} and e['producer'] in {'GC.CENTER','GC.RADIUS','GC.SUM.BOUND','GC.FINITE.MGF','GC.FOUR'} for e in g['edges'])
graphsha=put('source-graph.repaired.v2.json',g)
units=[]
def cov(i,anchor,region,disp,detail,node=None,displays=None):
    u={'unit_id':i,'source_anchor':anchor,'subregion':region,'disposition':disp,'detail':detail}
    if node:u['node_id']=node
    if displays:u['display_ids']=displays
    units.append(u)
def N(i,a,r,n,d='',ds=None):cov(i,a,r,'NODE',d or 'Source item retained as an open proof/definition obligation.',n,ds)
def X(i,a,r,reason,ds=None):cov(i,a,r,'EXCLUDED',reason,None,ds)
X('C2.HEADINGS','A3.SS2 headings','C.2 / Fact C.5 / Fact C.6 / Proof / Proof of Lemma4.4 labels','Presentation labels only; substantive statements separately classified.')
N('C2.P1.MODEL','A3.SS2.p1','r=q+1,n=2q+1; t_i/gamma_i definitions and independent N(0,I_r) row-law sentence','GC.MODEL',ds=['A3.Ex85'])
X('C2.P1.B','A3.SS2.p1','Let B in R^{d x r^2} have ith row d^-1/2(gamma_i tensor t_i)^T','B/Gram/Krylov representation is not in the sealed fixed-s actual-sum interface.')
X('C2.P2.STRATEGY','A3.SS2.p2','whole paragraph','B c representation and uniform Krylov concentration strategy are beyond P/T.')
X('C2.C5.GRAM','A3.Thmtheorem5.p1','range(B)=Kq and two Gram expectation identities','Source C5 range/Gram statements are not used to establish bounded literal Y or fixed-s Laplace tail.',ds=['A3.Ex86'])
N('C2.C5.FEATURE','A3.Thmtheorem5.p1','Ex87 first clause ||t_i||^2<=2r','GC.FEATURE.NORM',ds=['A3.Ex87'])
X('C2.C5.SUMS','A3.Thmtheorem5.p1','Ex87 remaining clauses sum t_i t_i^T=dI and weighted sum=0','Discrete orthogonality identities are unnecessary for individual centered-sum finite-mgf interface.',ds=['A3.Ex87'])
X('C2.P3.RANGE','A3.SS2.p3','whole paragraph','Chebyshev triangular change of basis proving range(B)=Kq is outside P/T.')
N('C2.P4.ANGLES','A3.SS2.p4','Recall theta_i=(i-1/2)pi/d','GC.MODEL')
X('C2.P4.COSSUM','A3.SS2.p4','boxed Gram expectation label and cosine telescoping sum/sine nonzero derivation','The recalled angle definition is retained separately; cosine-grid orthogonality proof is not needed for feature pointwise bound or fixed-s tail.',ds=['A3.Ex88','A3.Ex89'])
X('C2.P5.ORTHOGONAL','A3.SS2.p5','whole paragraph','Entrywise cosine orthogonality and sum featureouter=dI are outside P/T.',ds=['A3.Ex90','A3.Ex91','A3.Ex92','A3.Ex93'])
X('C2.P6.GRAMMEAN','A3.SS2.p6','whole paragraph','Expectation of B^T B via full Gaussian covariance and discrete orthogonality is outside P/T.',ds=['A3.Ex94','A3.Ex95'])
X('C2.P7.WEIGHTEDGRAM','A3.SS2.p7','whole paragraph','Frequency-range/product-to-sum and weighted Gram expectation cancellation are outside P/T.',ds=['A3.Ex96','A3.Ex97','A3.Ex98','A3.Ex99','A3.Ex100','A3.Ex101'])
N('C2.P8.FEATUREPROOF','A3.SS2.p8','whole mathematical line and Ex102','GC.FEATURE.NORM','Actual source producer of feature bound, reused at p13 and prior Y-regularity bridge.',ds=['A3.Ex102'])
X('C2.P9.TRANSITION','A3.SS2.p9','whole paragraph','Transition to simultaneous operator-norm Gram deviations and uniform coefficient-vector controls; no fixed-s proof ingredient.')
X('C2.C6.STATEMENT','A3.Thmtheorem6.p1','whole Fact C6 mathematical statement','Simultaneous Gram concentration with probability .995 and tau bound is not established here.',ds=['A3.Ex103'])
N('C2.P10.CUTOFF','A3.SS2.p10','Set L=2r+3log(1000d), R_i=||gamma_i||^2','GC.TRUNC')
X('C2.P10.TAIL','A3.SS2.p10','Since E exp(R_i/3)=3^(r/2), scalar Markov for x>=0, log3 inequality, and all-row event probability .999','Complete exponential-mgf/truncation-event tail route excluded from current P/T ancestry. Its mgf is neither assumed proved nor introduced as a P/T prerequisite.',ds=['A3.Ex104','A3.Ex105'])
X('C2.P11.BIASTAIL','A3.SS2.p11','whole paragraph','Tail shifted by s>=0 and layer-cake bias E[R 1_{R>L}]<=(L+3)/(1000d) are not needed for finite cutoff means or fixed-s tail.',ds=['A3.Ex106'])
N('C2.P12.Y','A3.SS2.p12','truncated Y_i formula Ex107 (independence assertion separately excluded)','GC.TRUNC',ds=['A3.Ex107'])
X('C2.P12.INDEPENDENT','A3.SS2.p12','word independent in truncated matrices introduction','Independence is only needed for later independent-sum/Bernstein route, not finite-mgf existence or universal Laplace bound.')
N('C2.P12.RADIAL','A3.SS2.p12','By radial symmetry, Ex108 formula and same-a sentence','GC.MEAN','Source mean formula only after GC.Y.REGULARITY and explicit BG.GAUSSIAN.ROW.MEAN.',ds=['A3.Ex108'])
N('C2.P12.ABOUND','A3.SS2.p12','Since E R_i=r, we have 0<=a<=1','GC.MEAN','Gaussian second-moment producer is BG.GAUSSIAN.ROW.MEAN; no untracked default-zero expectation.')
X('C2.P12.BIAS','A3.SS2.p12','and 1-a=(1/r)E[R_i 1_{R_i>L}]<=(L+3)/(1000rd)','Exact bias expression/bound uses excluded p11; it is not used for source mean radius <=2r/d.',ds=['A3.Ex109'])
N('C2.P12.MEANFORMULA','A3.SS2.p12','Moreover E Y_i=(a/d)(I_r tensor t_i t_i^T)','GC.MEAN')
X('C2.P12.SUMMEAN','A3.SS2.p12','Fact C5 therefore gives Ex110 and truncated weighted sum zero-expectation sentence','Sum means and weighted cancellation are not needed for sums of individually centered Z_i.',ds=['A3.Ex110'])
N('C2.P13.CENTER','A3.SS2.p13','Put Z_i=Y_i-E Y_i','GC.CENTER')
N('C2.P13.FEATUREUSE','A3.SS2.p13','Using ||t_i||^2<=2r','GC.FEATURE.NORM','Consumer of the distinct p8/Ex102 source producer.')
N('C2.P13.YBOUND','A3.SS2.p13','Ex111 first subformula: ||Y_i||=R_i||t_i||^2/d 1_{R_i<=L}<=2rL/d','GC.Y.REGULARITY','This subformula is moved before genuine mean computation as a prerequisite, without using the second subformula.',ds=['A3.Ex111'])
N('C2.P13.MEANBOUND','A3.SS2.p13','Ex111 second subformula: ||E Y_i||=a||t_i||^2/d<=2r/d','GC.RADIUS','Requires already genuine mean and source mean formula.',ds=['A3.Ex111'])
N('C2.P13.CENTERBOUND','A3.SS2.p13','Hence Ex112 bound ||Z_i||<=R* and cosine contraction sentence','GC.RADIUS',ds=['A3.Ex112'])
X('C2.P14.VARIANCE','A3.SS2.p14','whole paragraph','Fourth moments, square identities, PSD truncation drop, centered square inequality, v* and cosine variance comparison are the separate variance/Bernstein route and unproved here.',ds=['A3.Ex113','A3.Ex114','A3.Ex115','A3.Ex116','A3.Ex117','A3.Ex118','A3.Ex119','A3.Ex120'])
X('C2.P15.INDEPENDENTCENTERED','A3.SS2.p15','Applying matrix Bernstein label; both sequences independent and centered subclaims','These source claims are later Bernstein inputs, not P/T universal-tail premises or fixed-s-integrability prerequisites.')
N('C2.P15.SELFADJOINT','A3.SS2.p15','self-adjoint matrices subclaim','GC.SELFADJOINT','Actual expectation domain supplied upstream by GC.Y.REGULARITY.')
X('C2.P15.BERNSTEIN','A3.SS2.p15 and A3.SS2.p15.2','For t>0, two-sided bounded Bernstein Ex121 and same numerical bound for weighted sum','Numerical Bernstein/norm result is excluded from current graph; its two actual sum locations remain annotated as consumers of the intended four-case intermediate interface.',ds=['A3.Ex121'])
X('C2.P16.OPTIMIZE','A3.SS2.p16','whole paragraph','z/Delta substitution, quadratic expansion, each failure .002 and union bound .996 are beyond fixed-s P/T.',ds=['A3.Ex122','A3.Ex123','A3.Ex124'])
X('C2.P17.TRUNCATEBACK','A3.SS2.p17','whole paragraph','Equality of original/truncated Gram sums on all-row event and bias/concentration event budget .995 are not proved here.',ds=['A3.Ex125','A3.Ex126'])
X('C2.P18.SIMPLIFY','A3.SS2.p18','whole paragraph','Although d>=2 also follows directly from hq in GC.MODEL, this source paragraph uses it to simplify z,L,Delta,bias into tau and conclude C6; whole source use excluded as downstream optimization.',ds=['A3.Ex127','A3.Ex128'])
X('C2.P19.LEMMA44','A3.SS2.p19','whole paragraph','FactC5/C6 composition, inverse Gram coercivity, tau<=1/2 and final uniform Krylov quadratic-form result are beyond P/T.',ds=['A3.Ex129','A3.Ex130','A3.Ex131','A3.Ex132'])
raw=json.loads((B/'gaussian-C2-full-scope.raw.v2.json').read_text())['rows']
source_paras={x['id'] for x in raw if x['id']}
covered_paras={u['source_anchor'].split(' and ')[0] for u in units}
assert source_paras<=covered_paras,(source_paras-covered_paras)
all_displays=set()
for r in raw:all_displays.update(re.findall(r'id="(A3.Ex[0-9]+)"',r['raw_html']))
covered_displays={x for u in units for x in u.get('display_ids',[])}
assert all_displays==covered_displays,(all_displays-covered_displays,covered_displays-all_displays)
for u in units:
    assert (u['disposition']=='NODE')==('node_id' in u)
    if 'node_id' in u:assert u['node_id'] in ids
covdoc={'schema':'exact-source-region-coverage-repair-v2','status':'PROPOSED_PENDING_DISTINCT_TC','graph_sha256':graphsha,'scope':'Complete pinned original A3.SS2 C2 proof subsection inventory, with retained target ingredients and exact exclusions; external S4 original model anchors remain in v1/model record.','source_html_sha256':'6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915','paragraph_block_count':len(source_paras),'display_count':len(all_displays),'unit_count':len(units),'partition_contract':'Each semantic subregion has exactly one NODE or EXCLUDED disposition. Mixed displays Ex87 and Ex111 are explicitly partitioned by distinct clauses, not counted as whole overlapping items. Wrapper tags, whitespace, labels and QED marks carry no separate mathematical claim. The C5/C6 enclosing theorem/proof containers inherit the individual subregion dispositions; there is no whole-C6 exclusion.','units':units,'display_inventory':{x:[u['unit_id'] for u in units if x in u.get('display_ids',[])] for x in sorted(all_displays,key=lambda s:int(s.split('Ex')[-1]))},'source_parse':'gaussian-C2-full-scope.raw.v2.json','no_completion_claim':True}
covsha=put('coverage.exact.v2.json',covdoc)
cross=copy.deepcopy(json.loads((B/'phase2.source-vs-seal.v1.json').read_text()))
cross['schema']='independent-source-vs-seal-reviewed-graph-repair-v2';cross['phase']='POST_TC_APPEND_ONLY_GRAPH_REPAIR_PENDING_REVIEW';cross['repaired_graph_sha256']=graphsha;cross['coverage_sha256']=covsha
cross['root_singleton_supplement']={'file':str(supp),'sha256':sha(supp),'classification_scope':'14 singleton bins; original seal/audit/P/T bytes unchanged; T actual finite-expectation obligations remain internal and open.','distinct_TC_assessment':'original challenge admits classification hygiene only; no mathematical reseal needed.'}
cross['graph_repair']={'challenge_sha256':sha(challenge),'TC15-F1':'GC.FEATURE.NORM and GC.Y.REGULARITY now precede GC.MEAN/CENTER/RADIUS/symmetry. Actual mean exists before source mean formula or bound; GC.SUM.BOUND is restricted to already well-defined centered sums. BG.GAUSSIAN.ROW.MEAN makes radial/second-moment inputs visible.','TC15-F2':'Exact 21-block/48-display C2 inventory partitions mixed p1/C5/p4/p10/p12/p13/p15 and excludes bias, variance, Bernstein and final Gram/Krylov regions without a whole-C6 overlap.','out_of_target_blackboxes_removed':['GC.TRUNC.TAIL removed: full p10 mgf/Markov/all-row probability route explicitly EXCLUDED, no Gaussian mgf parent introduced into P/T.','GC.BERNSTEIN.CONSUMER removed as numerical-result graph node: exact source Ex121/p15.2 excluded, real use sites preserved as downstream metadata; strict norm bridge remains open and not a T ancestor.'],'all_proofs_remain_open':True,'independent_TC_admission':'PENDING_NOT_SELF_ADMITTED'}
cross['source_admission_recommendation']['independent_topology_coverage_approval']='PENDING_DISTINCT_REVIEW_OF_V2_GRAPH_ONLY_REPAIR'
cross['root_audit_schema_hygiene']['resolution']='Exact root singleton supplement SHA174a4297cc2e600a5bcca92586f38759f8b24c9dbfd4533fb4cfb35761b23af8 independently accepted as classification hygiene; original mathematical seal remains pinned.'
for o in cross['remaining_proof_obligations']:
    if o['id']=='T2.MEAN_DOMAIN':o['source_nodes']=['GC.FEATURE.NORM','GC.Y.REGULARITY','BG.GAUSSIAN.ROW.MEAN','GC.MEAN','GC.CENTER'];o['obligation']='First prove literal Y and truncated row outer measurable and uniformly bounded from model/cutoff/feature norm, so their true finite expectations exist. Only then prove radial source mean/a<=1, centering and preservation of symmetry. No downstream centered-sum bound discharges an upstream mean domain.'
    if o['id']=='T3.SYMMETRY_AND_BOUND':o['source_nodes']=['GC.Y.REGULARITY','GC.SELFADJOINT','GC.RADIUS','GC.SUM.BOUND']
    if o['id']=='DOWNSTREAM.STRICT_NORM':o['source_nodes']=['GC.NORM.EVENT'];o['obligation']='Downstream open only, outside P/T ancestry: strict-norm to both-sign spectral events and union bound. Source Ex121/p15.2 numerical Bernstein results are explicitly excluded; no numerical Bernstein, variance, Lieb, independent-sum or C6 proof is supplied.'
crosssha=put('source-vs-seal.repaired.v2.json',cross)
overlay={'schema':'append-only-source-graph-repair-overlay-v2','status':'PROPOSED_PENDING_DISTINCT_TC_NOT_SELF_ADMITTED','base_graph_sha256':sha(v1),'repaired_graph_sha256':graphsha,'coverage_sha256':covsha,'source_vs_seal_sha256':crosssha,'challenge_sha256':sha(challenge),'singleton_supplement_sha256':sha(supp),'removed_out_of_target_nodes':sorted(removed),'new_nodes':[n['id'] for n in added],'updated_nodes':list(updates),'added_edges':newedges,'mechanical_checks':{'acyclic':True,'nodes':len(g['nodes']),'edges':len(g['edges']),'Y_REGULARITY_before_MEAN_before_RADIUS_before_SUM_BOUND':True,'all_C2_paragraph_blocks_inventoried':len(source_paras),'all_C2_displays_inventoried':len(all_displays)},'mathematical_statement_changes':False,'new_public_binders':False,'P_T_proofs_or_API_checks':False,'v1_graph_preserved_sha256':sha(v1),'initial_v2_extraction_failure_preserved':{'script':'extract_c2_scope_v2.py','receipt':'gaussian-C2-scope-v2.receipt.json','result':'Original source JSON completed; printing id-less heading failed. gaussian-C2-read-v2 command printed the preserved JSON successfully. No source/mathematical route refutation.'}}
overlaysha=put('graph-repair.overlay.v2.json',overlay)
print(json.dumps({'graph':graphsha,'coverage':covsha,'crosswalk':crosssha,'overlay':overlaysha,'mechanical_checks':overlay['mechanical_checks']},indent=2))
