import AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumSourceRowLaw
import Mathlib.Probability.Independence.Basic
import Mathlib.Probability.ProductMeasure

open MeasureTheory ProbabilityTheory
#check infinitePi_map_curry
#check infinitePi_map_curry_symm
#check infinitePi_eq_pi
#check Measure.pi_map_piCongrLeft
#check MeasurableEquiv.curry
#check measurePreserving_pi
#check iIndepFun_iff_map_fun_eq_pi_map
#check iIndepFun.comp
#check MeasurePreserving.comp
#check Measurable.ite
#check Measurable.piecewise
#check measurable_pi_lambda
