# Provenance, actual observations, and exposure/truncation record

This role was assigned a fresh anti-anchored source-only phase by /root. The
role prompt itself named the forthcoming deterministic Gram, weighted
cancellation, row-square, Gaussian means/integrability comparison scope and
the out-of-scope range/C.6/full-Lemma boundaries. That scope information was
known before reading; no proposition/signature/code or prior verdict was given.
No global inventory, collaboration agent inventory, repository search, Lean,
candidate, decoder, API, existing graph, ledger, audit, seal, draft, W, TC, native,
or old conversation result was read. No sub-agent was spawned. This role is not
the Lean prover. Reading whole raw bytes for hashing/parsing does not mean I
semantically read the entire paper: only the bounded extracted source was shown.

The five exact permitted process paths were read. AGENTS.md contains unrelated
project priorities and historical status prose; these were incidental process
exposure, not used to infer any mathematical statement or candidate verdict.
I followed the explicit bounded role restriction instead of opening files linked
from those process documents. The source-dependency-audit skill was present and
read; no other skill was opened. No external background source was consulted.
Pretrained knowledge cannot be audited away, and I do not claim zero prior
knowledge or pristine cognition.

The exact-definition context extraction printed the adjacent source Lemma 4.3
and the subsection overview along with the required K_q definition. This was an
overbroad source-context exposure, fully retained in
`exact-definition-context.stdout`; it exposed no candidate or other role's
result. The relevant cognition uses the definition and records range=Krylov and
deferred rotation as separate boundaries, not as completed mathematics. The
spectral definition paragraph likewise contains unrelated O, A, potential and
target definitions; its original slice is retained. The two extraction tools
only searched the fixed pinned HTML in memory and did not search repository
filenames or other mathematical files.

## Actual command/output records

`actual_commands.jsonl` is produced by capture.py after each subprocess exits.
It records the exact argv, cwd, observed exit code, raw stdout/stderr paths,
byte sizes and SHA256. The corresponding `.stdout` and `.stderr` files contain
the actual subprocess streams without display truncation. Every captured
subprocess so far exited 0 with empty captured stderr. Empty stderr files are
real capture results, not guessed receipts.

Two bootstrap native exec commands preceded capture.py:

1. cwd=/Users/zhouhuanjian/ASTIS-GC, cmd=`pwd`, tool chunk `8ff6ce`:
   exit_code=0, wall_time_seconds=0.000010709, original_token_count=8,
   observed tool output `/Users/zhouhuanjian/ASTIS-GC\n`.
2. same cwd, cmd=`cat AGENTS.md`, tool chunk `b399e0`:
   exit_code=0, wall_time_seconds=0.00001025, original_token_count=6942.
   The complete displayed output was the AGENTS.md content preserved as
   `inputs/0-AGENTS.md`; its output retained CRLF source bytes. These tool
   results expose a single combined `output` field; separate stdout/stderr
   streams were not observable for these two bootstrap calls, so no independent
   empty-stderr assertion is made. The native tool transcript remains the
   authoritative original observation.

The first process-doc batch native result (chunk `2f75a7`) explicitly showed
`Warning: truncated output (original token count: 10556)` and a middle gap in
the theorem-publication document. Actual subprocess stdout was fully captured
as `protocol-files.stdout`, 40515 bytes, SHA256
`69c90d73991d919b6e8fa85452bd61b9374258eca38bd209b954dd21e7ed38e8`.
The full theorem-publication document was then read separately as
`publication-protocol-full.stdout` (14188 bytes), without a display truncation.
The opening anchor summary intentionally printed only the first 1400 Unicode
characters of each source derivative; it was a locator preview, not a claimed
complete reading. The complete C.2 was subsequently printed and read from
`C2-full-text.stdout` (10393 bytes), with no display truncation observed.

Source-span extraction v1 omitted equationgroup containers from its standalone
container inventory although all paragraphs, complete proof slices, and full
C.2 were present. v2 added them and every C.2 math locator. Both actual command
outputs are retained. The original v1 script is retained separately as
`pin_spans.initial.py` by subtracting the exact later patch from the preserved
v2 script; this is an explicitly reconstructed command-input version, not a
claim to a previously measured file hash. No source calculation failure or
nonzero command exit was observed. No receipt is invented for an unrun check.

Apply-patch calls created the capture/extraction/cognition/provenance/freeze
scripts and returned `{}`. Those script bodies are retained here; the only
in-place script revision before phase 1 is the equationgroup/math-inventory
addition to pin_spans.py just described. Files were written only under the
assigned cg_src_7e41d9 path. Finalizer execution and chmod results are recorded
by the actual external `freeze_execution` capture, outside the frozen phase
to avoid a manifest/receipt/log hash cycle.

## Freeze scheme

Phase-1 payload copies include original source/process snapshots, exact raw
source spans, source cognition, all source/math locators, scripts, and command
captures up to the finalizer. `manifest.json` hashes each payload file but
excludes itself and `freeze_receipt.json`. `freeze_receipt.json` hashes the
manifest and cognition and records observed verification and file modes.
`freeze_execution.json` outside phase1 binds the receipt and records the actual
finalizer process outcome and output streams. Thus no object includes its own
hash and no pair mutually hashes one another. Payload/receipt/manifest files
are chmod 0444 and phase1/subdirectories chmod 0555. Parent task directory
remains writable for separately staged future input.
