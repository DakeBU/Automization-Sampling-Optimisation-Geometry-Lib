import subprocess,sys,json,datetime,hashlib,os
from pathlib import Path
root=Path(__file__).resolve().parent
label=sys.argv[1]; cmd=sys.argv[2:]
start=datetime.datetime.now(datetime.timezone.utc).isoformat()
env=os.environ.copy()
if label.startswith("isolated-"):
 env["LEAN_PATH"]=str(root/"oleans")+os.pathsep+env.get("LEAN_PATH","")
r=subprocess.run(cmd,cwd=root.parents[2],env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
(root/(label+".stdout.log")).write_bytes(r.stdout)
(root/(label+".stderr.log")).write_bytes(r.stderr)
rec={"label":label,"argv":cmd,"cwd":str(root.parents[2]),"start_utc":start,"end_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"exit_code":r.returncode,"stdout_sha256":hashlib.sha256(r.stdout).hexdigest(),"stderr_sha256":hashlib.sha256(r.stderr).hexdigest(),"lean_path_prefix":str(root/"oleans") if label.startswith("isolated-") else None}
(root/(label+".receipt.json")).write_text(json.dumps(rec,indent=2)+"\n")
print(json.dumps(rec,indent=2)); print(r.stdout.decode(errors="replace"));print(r.stderr.decode(errors="replace"),file=sys.stderr)
sys.exit(r.returncode)
