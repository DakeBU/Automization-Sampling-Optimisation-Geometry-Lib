"""Freeze the complete prospective review including the concrete counterexample."""
import datetime, hashlib, json, os, pathlib, stat

D=pathlib.Path(__file__).resolve().parent
def sha(b):return hashlib.sha256(b).hexdigest()
def put(rel,b):
 p=D/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b if isinstance(b,bytes) else b.encode());return p
def js(rel,o):return put(rel,json.dumps(o,ensure_ascii=False,indent=2)+'\n')

# Preserve the second failed runtime attempt and its consequential missing-output error.
put('failed-attempts/node-repl-dynamic-compilation/dependent-python-error.raw.txt',
 'Traceback (most recent call last):\n  File "<stdin>", line 2, in <module>\n  File "/opt/homebrew/Cellar/python@3.14/3.14.6/Frameworks/Python.framework/Versions/3.14/lib/python3.14/pathlib/__init__.py", line 787, in read_text\n    with self.open(mode=\'r\', encoding=encoding, errors=errors, newline=newline) as f:\n         ~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File "/opt/homebrew/Cellar/python@3.14/3.14.6/Frameworks/Python.framework/Versions/3.14/lib/python3.14/pathlib/__init__.py", line 771, in open\n    return io.open(self, mode, buffering, encoding, errors, newline)\n           ~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\nFileNotFoundError: [Errno 2] No such file or directory: \'.astis/huanjian-gc-fixed-spectrum-cosine-gram-20261110/reader-step-neighbor-v4-independent-0a91de/copy-handler-contract-results.json\'\n')
progress=json.loads((D/'scope-and-progress.json').read_bytes())
bug=json.loads((D/'counterexample/observed-defect.json').read_bytes())
assert bug['wrong_context']
findings={
 'schema':'astis-independent-disabled-v4-ui-review/v1',
 'candidate':'72e5d1405284f729f4eb600c5ae5dd556365b7e2',
 'reviewer':'reader-step-neighbor-v4-independent-0a91de',
 'proposal_sha256':sha((D/'proposal.py').read_bytes()),
 'production_sha256':sha((D/'production.py').read_bytes()),
 'patch_sha256':sha((D/'reader-step-neighbor.patch').read_bytes()),
 'decision':'DEFECT in general exact-context routing; no prospective acceptance or whole-HOLD release',
 'real_C5_static_result':{
   'routes':['P34','P54','P125','P156','T59','T13'],
   'six_exact_code_blocks_and_formulas':True,'six_initially_closed_code_and_proof_folds':True,
   'six_adjacent_copy_panel_button_status_structures':True,
   'existing_copy_JS_contract':'Actual unchanged candidate site.js uses nearest data-lean-code-panel, direct :scope > pre > code, and status in button parent. All6 generated DOM panels satisfy these selectors. No successful JS runtime or clipboard execution is claimed.',
   'full_T_bytes':7494,'full_T_sha256':'90b43f488d3fe9b6c95d4c039d0f771ee5bfecdd699b72dfa52465643f0b0dee',
   'sourceHTML_and_raw_downloads':'Both P and T companion sourceHTML and byte-identical raw downloads exist in the isolated proposed output; every C5 context anchor points at the correct displayed source line.',
   'scope':'These current-input structural results do not release either earlier frozen HOLD.'},
 'independent_counterexample':bug,
 'required_minimal_concrete_repair_boundary':[
   'Use one explicit line-partition convention for byte matching and generated sourceHTML anchors. Under the existing raw LF convention, do not let Python splitlines() introduce extra numbered lines for U+2028/U+2029 or other Unicode separators that the matcher does not count.',
   'Preserve strict UTF8 bytes and raw source downloads. Add a focused check that an exact snippet after a U+2028-containing source comment links to the actual first numbered sourceHTML code line; cover LF/CRLF and repeated/ambiguous exact matches under the same convention.',
   'Review the repair as another disabled overlay. Do not replace the earlier mathematical/native review, adopt a shared renderer, claim native build credit or release reader/global delivery from these static results.'
 ],
 'defect_fairness_boundary':'export_sources already used splitlines() in production. The defect is a mismatch in v4’s new exact byte-to-sourceHTML routing contract and its newly exported canonical-module candidate path; it is not a claim that v4 first introduced splitlines(). The current C5 LF-only inputs pass.',
 'other_independent_controls':{
   'exact_matching_controls_passed':progress['exact_match_controls_passed'],
   'details':'Unique UTF8/LF and CRLF literal matches route correctly; LF versus CRLF is not normalized into a match; repeated overlapping/nonoverlapping and cross-file occurrences yield copy-only; duplicate same-path citations count once; canonical-only source works; missing literal yields copy-only. Removed final LF is a valid exact substring match, not whole-file equality.',
   'path_URL_symlink_controls_passed':progress['path_URL_symlink_controls_passed'],
   'validation_scope':'Unsafe path/URL fixtures, invalid path beside valid URL, and outside-root source symlinks reject; safe internal symlink and valid HTTPS fixtures pass. This is bounded regression evidence, not a security proof.',
   'new_canonical_export_controls_passed':progress['canonical_export_controls_passed'],
   'canonical_export_scope':'Canonical-only and canonical-plus-explicit-local-citation fixtures export correct raw files; broad existing-lesson/site compatibility was not claimed.'},
 'real_failed_verifier_attempts':[
   'Node executable absent from PATH: retained original review.py, generated fixture, stdout/stderr and traceback.',
   'Available Node REPL rejected dynamic compilation with Code generation from strings disallowed for this context. Its generated driver, raw tool result and consequential missing-results traceback retained. No JavaScript runtime PASS invented.'
 ],
 'fixture_limits':'Exact unchanged proposed/production functions and candidate input bytes used. source_lineage.canonical_shell identity only; actual export_sources/base.page generated sourceHTML body. Unpublished Git and passed=false gate fixtures; no live browser or global sourceHTML shell acceptance.',
 'preservation':'Prior two frozen directories were not read/imported or written. No tracked/shared file or publication metadata changed; no renderer repair implemented.',
 'authority_boundary':'UI-only prospective overlay review, no mathematical/sourceV/native build/browser/global acceptance. Stop after freeze.'
}
js('findings.json',findings)
put('findings.txt',
 'v4 real C5 static routes P34/P54/P125/P156/T59/T13 and all6 code/formula/closed/copy-panel structures pass. FullT7494B and both raw source downloads retained.\n'
 'Concrete general defect: U+2028 inside a preceding source comment is not counted by the matcher but is split by sourceHTML export; returned #L2 lands on still-comment, actual code is #L3.\n'
 'Minimal repair: one raw-LF line-partition convention for matcher and sourceHTML anchors; preserve exact UTF8/raw-download bytes and add the retained counterexample regression.\n'
 '15 exact-match,35 path/URL/symlink,2 canonical-export controls pass. Existing copy-JS selector contract structurally satisfied; runtime tests unavailable with real failures retained.\n'
 'Earlier freezes/HOLD unchanged; no shared adoption, mathematical/sourceV/native/browser/global acceptance. Stop after this freeze.\n')
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
js('freeze-invocation.json',{'command':['python3',str(D/'finalize.py')],'started_at_utc':now,
 'scope':'Every follow-up descendant including exact inputs, proposal/patch, static exports, counterexample, all actual verifier failures, and symbolic-link fixture entries. Exactly two envelope files excluded from recursive payload hash list.',
 'regular_file_mode':'0444','directory_mode':'0555','symlink_policy':'Preserve each link text in manifest and actual filesystem. Every target is another frozen regular file under this review root; parent directories are0555. Symbolic links are not regular files.'})
envelope={'freeze-manifest.json','freeze-outer-receipt.json'}
allpaths=sorted(D.rglob('*'))
links=[p for p in allpaths if p.is_symlink()]
files=[p for p in allpaths if p.is_file() and not p.is_symlink() and p.relative_to(D).as_posix() not in envelope]
dirs=[D]+[p for p in allpaths if p.is_dir() and not p.is_symlink()]
for p in links:assert p.resolve().is_relative_to(D) and p.resolve().is_file()
manifest={'schema':'astis-full-ui-review-freeze/v1','payload_scope':'Every descendant; no arbitrary payload truncation; exactly two envelope files outside payload hash list.',
 'explicit_envelope_files':sorted(envelope),
 'regular_files':[{'path':p.relative_to(D).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes()),'mode':'0444'} for p in files],
 'directories':[{'path':'.' if p==D else p.relative_to(D).as_posix(),'mode':'0555'} for p in dirs],
 'symbolic_link_fixtures':[{'path':p.relative_to(D).as_posix(),'link_text':os.readlink(p),'link_text_sha256':sha(os.readlink(p).encode()),
    'resolved_target':p.resolve().relative_to(D).as_posix(),'resolved_target_sha256':sha(p.resolve().read_bytes()),'containment':'under review root, target0444, parent0555'} for p in links]}
mf=js('freeze-manifest.json',manifest)
receipt={'schema':'astis-ui-review-freeze-outer-receipt/v1','created_at_utc':now,
 'manifest_sha256':sha(mf.read_bytes()),'findings_sha256':sha((D/'findings.json').read_bytes()),
 'payload_regular_files':len(files),'payload_bytes':sum(p.stat().st_size for p in files),'directories':len(dirs),'symbolic_link_fixtures':len(links),
 'regular_file_mode':'0444','directory_mode':'0555','decision':'DEFECT; consistent line-partition repair required; no HOLD release',
 'earlier_freezes':'untouched'}
outer=js('freeze-outer-receipt.json',receipt)
for p in files+[mf,outer]:p.chmod(0o444)
for p in sorted(dirs,key=lambda p:len(p.parts),reverse=True):p.chmod(0o555)
for row in manifest['regular_files']:
 p=D/row['path'];assert sha(p.read_bytes())==row['sha256'] and stat.S_IMODE(p.stat().st_mode)==0o444
for p in dirs:assert stat.S_IMODE(p.stat().st_mode)==0o555
for p in links:assert stat.S_IMODE(p.resolve().stat().st_mode)==0o444 and stat.S_IMODE(p.parent.stat().st_mode)==0o555
assert sha(mf.read_bytes())==receipt['manifest_sha256']
print(json.dumps({**receipt,'outer_receipt_sha256':sha(outer.read_bytes()),'frozen':True},indent=2))
