"""One normal sole-STAB claim after the original independent source V is committed."""
from pathlib import Path
import gzip
import hashlib
import json
import subprocess
import sys
sys.dont_write_bytecode = True

ADV = 'ASTIS-SA-20261109-GaussianComplexityFixedSpectrumCosineExpansion'
OWNER = 'huanjian_gc_20261109_fixed_spectrum_cosine_expansion'
ACTOR = OWNER + '_integration'
VERIFIER = '/root/cosine_fresh_source_5d8c2a'
CANDIDATE = '37645c774481c4cad19fc29bcaa76799da64db7d'
MAIN = '95322cd2c762e5969c560815a803c4e15a424007'
DECL = 'AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumCosineExpansion.actual_inverse_spectrum_cosine_expansion'
E = Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-cosine-expansion-semantic-evidence')
B = Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-cosine-expansion-integration-20261109')
LP = Path('runs/substantive_advances.jsonl')
DP = Path('runs/substantive_discoveries.jsonl')
sha = lambda b: hashlib.sha256(b).hexdigest()
dump = lambda x: (json.dumps(x, ensure_ascii=False, indent=2) + '\n').encode()
git = lambda *args: subprocess.check_output(['git', *args])

before = LP.read_bytes()
assert before.endswith(b'\n')
records = [json.loads(line) for line in before.splitlines()]
assert all(isinstance(x, dict) for x in records)
discovery = DP.read_bytes()
assert discovery.endswith(b'\n')
assert all(isinstance(json.loads(x), dict) for x in discovery.splitlines())
head = git('rev-parse', 'HEAD').decode().strip()
assert not git('diff', 'HEAD', '--name-only').strip(), 'Commit the actual source-V carrier first'
assert git('show', head + ':' + str(LP)) == before
assert git('rev-parse', 'origin/main').decode().strip() == MAIN
receipt = json.loads((E / 'actual-source-V/VERIFIED-actual-receipt.json').read_bytes())
append = (E / 'actual-source-V/actual-append-observed.exact.jsonl').read_bytes()
assert receipt['normal_API_calls'] == 1 and receipt['worker_and_verifier'] == VERIFIER
assert receipt['actual_append_sha256'] == sha(append) and before.endswith(append)
assert receipt['checked_commit'] == CANDIDATE
audit = json.loads(Path('research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-cosine-expansion.json').read_bytes())
assert audit['state'] == 'source-reviewed' and audit['source_review']['state'] == 'accepted'
assert audit['source_review']['reviewer'] == VERIFIER
assert audit['source_review']['checked_commit'] == CANDIDATE
frontiers = {str(p): sha(p.read_bytes()) for p in sorted(Path('research-wiki/frontier-cells').rglob('*.json'))}
assert len(frontiers) == 446
models = {str(p): p.read_bytes() for p in (Path('website/content/functor_hypergraph.json'), Path('website/content/graph_memory_index.json'))}
sys.path.insert(0, str(Path.cwd()))
from tools import astis_advance as adv
states = adv._replay_advances(records)
assert states[ADV]['state'] == 'VERIFIED' and states[ADV]['owner_id'] == OWNER
assert states[ADV]['latest_evidence']['verifier_id'] == VERIFIER
assert states[ADV]['latest_evidence']['verified_commit'] == CANDIDATE
assert not [k for k, v in states.items() if v['state'] == 'STABILIZING']
foreign = {k: v for k, v in states.items() if k != ADV}
assert len(foreign) == 286
B.mkdir(exist_ok=False)
(B / 'before-STAB-ledger.exact.jsonl.gz').write_bytes(gzip.compress(before, mtime=0))
(B / 'before-STAB-protection.json.gz').write_bytes(gzip.compress(dump({'foreign_states': foreign, 'all_frontier_hashes': frontiers, 'discovery_sha256': sha(discovery), 'models': {k: sha(v) for k, v in models.items()}, 'source_V_carrier': head}), mtime=0))
(B / 'normal-STAB-attempt.once.json').write_bytes(dump({'actor': ACTOR, 'source_V_carrier': head, 'max_normal_API_calls': 1}))
try:
    adv.transition_advance(ADV, 'STABILIZING', worker_id=ACTOR, evidence={
        'canonical_branch': git('branch', '--show-current').decode().strip(),
        'integration_owner': ACTOR, 'verifier_id': VERIFIER, 'verified_commit': CANDIDATE,
        'source_V_first_carrying_commit': head, 'publication_declarations': [DECL], 'lean_declarations': [DECL],
        'required_main_ancestor': MAIN,
        'independent_conditional_payload_manifest_sha256': '6dc1f5f6ae23b60723cc4ca5f52c3152a2a7bb37f64759d29d01ad8594a8bf2d',
        'scope': 'Real current-main merge, exact reviewed eight shared payloads and explicit own lifecycle projections only. Original sourceV is unchanged.',
        'truth_boundary': 'Actual immutable integration core/root/site/graph/desktop-mobile acceptance, remote owner release/publication, purification/Exposition Seal, C8 and both complete main bounds remain pending.'})
finally:
    observed = LP.read_bytes()
    (B / 'after-STAB-observed-ledger.exact.jsonl.gz').write_bytes(gzip.compress(observed, mtime=0))
assert observed.startswith(before)
added = observed[len(before):]
assert added.endswith(b'\n') and len(added.splitlines()) == 1
event = json.loads(added)
assert (event['advance_id'], event['from_state'], event['to_state'], event['worker_id']) == (ADV, 'VERIFIED', 'STABILIZING', ACTOR)
post = adv._replay_advances([json.loads(x) for x in observed.splitlines()])
assert {k: v for k, v in post.items() if k != ADV} == foreign
assert [k for k, v in post.items() if v['state'] == 'STABILIZING'] == [ADV]
assert {str(p): sha(p.read_bytes()) for p in Path('research-wiki/frontier-cells').rglob('*.json')} == frontiers
assert DP.read_bytes() == discovery and all(Path(k).read_bytes() == v for k, v in models.items())
(B / 'sole-STAB-append.exact.jsonl').write_bytes(added)
result = {'state': 'OBSERVED_ONE_NORMAL_SOLE_STAB', 'actor': ACTOR, 'source_V_carrier': head, 'source_verifier_preserved': VERIFIER, 'normal_API_calls': 1, 'actual_append_sha256': sha(added), 'foreign_states_preserved': 286, 'foreign_frontiers_preserved': 445, 'raw_old_prefix_preserved': True, 'main_merge_or_shared_payload_application_yet': False}
(B / 'sole-STAB-actual-receipt.json').write_bytes(dump(result))
print(json.dumps(result))
