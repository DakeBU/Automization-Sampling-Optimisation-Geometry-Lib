"""Prepared control plane only. Do not execute without independent admission."""
from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import sys

sys.dont_write_bytecode = True
sys.path.insert(0, 'tools')
import astis_advance as adv

W = Path(__file__).parent
E = Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-detector-semantic-evidence')
C = Path('research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-detector.json')
L = Path('runs/substantive_advances.jsonl')
ADV = 'ASTIS-SA-20261110-GaussianComplexityFixedSpectrumDetector'
OWNER = 'huanjian_gc_20261110_fixed_spectrum_detector'
sha = lambda b: hashlib.sha256(b).hexdigest()
dump = lambda o: (json.dumps(o, ensure_ascii=False, indent=2) + '\n').encode()

def put(p, b):
    assert not p.exists(), p
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(b)

def ref(p):
    p = Path(p)
    b = p.read_bytes()
    return {'path': str(p), 'bytes': len(b), 'sha256': sha(b)}

assert len(sys.argv) == 4, 'grant path, exact grant SHA256, exact private baseline SHA256'
gp = Path(sys.argv[1])
assert sha(gp.read_bytes()) == sys.argv[2]
g = json.loads(gp.read_bytes())
assert g['prospective_target_Lean_proof_API_allowed_after_this_grant'] is True
assert g['root_sole_mathematical_worker'] is True
assert g['prepared_intake_script_sha256'] == sha(Path(__file__).read_bytes())
assert g['private_baseline_sha256'] == sys.argv[3]
for row in g['independent_inputs']:
    assert sha(Path(row['path']).read_bytes()) == row['sha256'], row['path']
sp = W / 'statement-seal-v1.json'
assert sha(sp.read_bytes()) == '011376bdd5d1edb66cedb434f8cd7bec7a5f108cc7c653011a7f10cab89ac701'
s = json.loads(sp.read_bytes())
prod = s['producer']['planned_file']
test = s['actual_private_consumer']['planned_file']
name = s['producer']['name']
assert not Path(prod).exists() and not Path(test).exists() and not E.exists()
assert not (W / 'StatementFormation.lean').exists()
bp = W / 'preproof-baseline.json'
assert sha(bp.read_bytes()) == sys.argv[3]
b = json.loads(bp.read_bytes())
assert sha(L.read_bytes()) == b['ledger']['sha256']
assert sha(C.read_bytes()) == b['own_frontier']['sha256']
for p, h in b['foreign_frontier_hashes'].items():
    assert sha(Path(p).read_bytes()) == h, p
before = L.read_bytes()
states = adv._replay_advances([json.loads(v) for v in before.splitlines()])
assert states == b['all_current_SAU_states'] and ADV not in states
assert states['ASTIS-SA-20261110-GaussianComplexityFixedSpectrumThreshold']['state'] == 'VERIFIED'
publicseal = Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-detector-statement-seal.json')
assert publicseal.read_bytes() == sp.read_bytes()
tracked = subprocess.check_output(['git', 'ls-files', '-z']).decode().split('\0')
protected = {p: sha(Path(p).read_bytes()) for p in tracked if p and p not in {str(L), str(C)} and Path(p).is_file()}
put(W / 'intake-tracked-private-preservation.json', dump({'all_tracked_hashes_except_own_ledger_and_frontier': protected, 'all_foreign_states': states, 'raw_private_not_for_public_copy': True}))
put(E / 'preproof-source-admission.json', gp.read_bytes())
for fn in ['producer-signature.txt', 'consumer-signature.txt', 'preseal-exposure-disclosure.json', 'postseal-process-actions-disclosure.json', 'postseal-additional-informal-planning-exposure.json', 'seal-writer-first-error-diagnostic.json', 'mathematical-parallelism-schema-correction.json']:
    put(E / fn, (W / fn).read_bytes())
boundary = '; '.join(s['scope_boundary'])
cell = json.loads(C.read_bytes())
p = adv.AdvanceProposal(
    advance_id=ADV, task_id='ASTIS-SW-GAUSSIAN-COMPLEXITY-2026',
    goal='Prove the literal actual matrix-Chebyshev cosine identity, consumed by the actual rotated-pushforward Gaussian strict event equality.',
    source_anchor=cell['source_anchor'], theorem_delta=s['producer']['signature'],
    truth_boundary=boundary, created_by=OWNER,
    dag_inputs=('source:arXiv2610.20492v1:Eq11 and S4.SS3.p3.1-p4.1', 'Existing Mathlib polynomial, matrix, cosine and measure-map substrate; exact API use to be checked, no supplied proof certificates.'),
    proposed_files=(prod, test, str(C), str(publicseal), 'website/content/declaration_lessons/huanjian-fixed-spectrum-detector.json', 'website/content/publications/huanjian-fixed-spectrum-detector.json'),
    focused_checks=('lake env lean ' + prod, 'lake build Tests.GaussianComplexityFixedSpectrumDetector'),
    modes=('source-reading', 'proof-design', 'compiler-diagnosis'), priority=50,
    frontier_cell=C.stem, target_declarations=(name,))
p.validate()
adv.propose_advance(p)
adv.transition_advance(ADV, 'CLAIMED', worker_id=OWNER, evidence={'exact_statement_seal': ref(sp), 'preproof_admission': ref(E / 'preproof-source-admission.json'), 'truth_boundary': boundary})
adv.transition_advance(ADV, 'EXPLORING', worker_id=OWNER, evidence={'preproof_admission': ref(E / 'preproof-source-admission.json'), 'target_proof_API_search_starts_only_after_this_event': True, 'preseal_planning_and_upstream_exposure_retained': True, 'no_pristine_zero_planning_claim': True, 'no_own_STAB_authority': True, 'truth_boundary': boundary})
cell['owner_id'] = OWNER
cell['advance_id'] = ADV
cell['evidence']['preproof_source_admission'] = ref(E / 'preproof-source-admission.json')
C.write_bytes(dump(cell))
after = L.read_bytes()
assert after.startswith(before)
app = after[len(before):]
assert len(app.splitlines()) == 3
new = adv._replay_advances([json.loads(v) for v in after.splitlines()])
assert new[ADV]['state'] == 'EXPLORING' and {k: v for k, v in new.items() if k != ADV} == states
for p, h in protected.items():
    assert sha(Path(p).read_bytes()) == h, p
for p, h in b['foreign_frontier_hashes'].items():
    assert sha(Path(p).read_bytes()) == h, p
put(E / 'normal-EXPLORING-append.exact.jsonl', app)
put(E / 'normal-intake-preservation.json', dump({'actual_normal_API_calls': 3, 'state': 'EXPLORING', 'advance_id': ADV, 'owner': OWNER, 'append_sha256': sha(app), 'foreign_states_preserved': len(states), 'foreign_frontiers_preserved': len(b['foreign_frontier_hashes']), 'protected_tracked_files_preserved': len(protected), 'foreign_raw_private': True, 'no_sourceV_STAB_or_proof_credit': True}))
print(json.dumps({'state': 'EXPLORING', 'append_sha256': sha(app), 'foreign_states_preserved': len(states), 'foreign_frontiers_preserved': len(b['foreign_frontier_hashes']), 'protected_tracked_files_preserved': len(protected), 'proof_or_sourceV_credit': False}))
