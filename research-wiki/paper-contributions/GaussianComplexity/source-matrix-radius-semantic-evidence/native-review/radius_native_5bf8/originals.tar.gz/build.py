from runner import *
s=json.loads((OUT/'settings.json').read_text());snap=Path(s['snapshot']);native=Path(s['native'])
lean='/Users/zhouhuanjian/.elan/toolchains/leanprover--lean4---v4.33.0/bin/lean'
for m in s['order']:
    rel=m.replace('.','/')
    o=native/(rel+'.olean');o.parent.mkdir(parents=True,exist_ok=True)
    run('native-build-'+m,[lean,'-o',o,snap/(rel+'.lean')],cwd=snap,env={'LEAN_PATH':s['LEAN_PATH']})
    run('native-deps-'+m,[lean,'--deps',snap/(rel+'.lean')],cwd=snap,env={'LEAN_PATH':s['LEAN_PATH']})
(OUT/'native-hashes.json').write_text(json.dumps({str(p.relative_to(native)):sha(p) for p in sorted(native.rglob('*')) if p.is_file()},indent=2)+'\n')
