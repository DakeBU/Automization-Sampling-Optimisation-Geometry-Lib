"""Prepare exact Ex72 shared-path bytes without changing any shared path.

This is an integration/reader proposal, never a source verdict or lifecycle
transition. Only the review's own staging and evidence directories are written.
The proposed source-reviewed wording is conditional on later genuine source V.
"""
from pathlib import Path
import datetime
import difflib
import gzip
import hashlib
import json
import os
import subprocess
import sys

sys.dont_write_bytecode = True
ROOT = Path('/Users/zhouhuanjian/ASTIS-GC')
STAGE = ROOT / '.astis/huanjian-gc-ex72-integration-20261107/independent-reader-preparation'
OUT = ROOT / 'research-wiki/paper-contributions/GaussianComplexity/ex72-integration-20261107/independent-integration-reader-review'
ADV = 'ASTIS-SA-20261107-GaussianComplexityTVAmplification'
AUDIT = 'ASTIS-RT-20261107-HuanjianTVAmplification'
CANDIDATE = 'ebf76119351b23ef0718fc69aa5081515bab0b52'
DECL = 'AutoSamplingTheory.ExampleCases.GaussianComplexity.TVAmplification.actual_averaged_tv_lower_bound'
SEVEN = [
    'AutoSamplingTheory.lean',
    'Tests.lean',
    'Tests/Basic.lean',
    'AutoSamplingTheory/TechnicalLemmas/Registry.lean',
    'website/content/samplewiki_companion_frontiers.json',
    'research-wiki/sampling-sde-library/cards/AutoSamplingTheory.ExampleCases.GaussianComplexity.AffinityTensorization.md',
    'research-wiki/sampling-sde-library/cards/AutoSamplingTheory.ExampleCases.GaussianComplexity.TVAmplification.md',
]
PINS = {
    'AutoSamplingTheory/ExampleCases/GaussianComplexity/TVAmplification.lean': '9c96a4b80420bf114e700ed61f4adf88f79b85d24c4d21848e466d67b93ba431',
    'Tests/GaussianComplexityTVAmplification.lean': '6bd58c4010c81dfa7948c9de1632c35fb0b14385bbdef5e5c28f5e1f2ca10cee',
    'website/content/publications/huanjian-tv-amplification.json': '1c4249f550a5e8bfcbc6b57c029c4176a770369bc70d38ccc790ff7a58136c97',
    'website/content/declaration_lessons/huanjian-tv-amplification.json': '2c0722c3565a914f98cb29609f67e9a3be6b4c4aa7f1a53663bff62491f50dba',
}
BINDING = 'fdfc58efe464c10868cac35682d8bd5202e0fc69f46880f957582e707b667265'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def canonical(obj):
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()


def command(*args):
    return subprocess.check_output(args, cwd=ROOT)


def save_json(path, obj):
    assert not path.exists(), f'Do not overwrite frozen evidence: {path}'
    path.write_bytes((json.dumps(obj, ensure_ascii=False, indent=2) + '\n').encode())


def gz(path, raw):
    assert not path.exists(), f'Do not overwrite frozen evidence: {path}'
    packed = gzip.compress(raw, compresslevel=9, mtime=0)
    path.write_bytes(packed)
    assert gzip.decompress(path.read_bytes()) == raw
    return {'path': str(path.relative_to(ROOT)), 'raw_sha256': sha(raw),
            'gzip_sha256': sha(packed), 'raw_bytes': len(raw), 'gzip_bytes': len(packed)}


def replace_once(raw, old, new):
    old_b, new_b = old.encode(), new.encode()
    assert raw.count(old_b) == 1, old
    return raw.replace(old_b, new_b, 1)


def differences(before, after, pointer=''):
    assert type(before) is type(after)
    if isinstance(before, dict):
        assert before.keys() == after.keys()
        return sum((differences(before[k], after[k], pointer + '/' + str(k)) for k in before), [])
    if isinstance(before, list):
        assert len(before) == len(after)
        return sum((differences(a, b, pointer + '/' + str(i)) for i, (a, b) in enumerate(zip(before, after))), [])
    return [] if before == after else [pointer]


STAGE.mkdir(parents=True, exist_ok=True)
OUT.mkdir(parents=True, exist_ok=True)
assert not (OUT / 'preparation-report.json').exists()
head = command('git', 'rev-parse', 'HEAD').decode().strip()
assert command('git', 'merge-base', '--is-ancestor', CANDIDATE, head) == b''
for path, expected in PINS.items():
    raw = (ROOT / path).read_bytes()
    assert sha(raw) == expected, path
    assert command('git', 'show', CANDIDATE + ':' + path) == raw, path
context = json.loads((ROOT / '.astis/huanjian-ex72-20261107/current-publication-context.json').read_bytes())
assert context['publication_binding_sha256'] == BINDING

before = {p: (ROOT / p).read_bytes() if (ROOT / p).exists() else None for p in SEVEN}
assert before[SEVEN[6]] is None
for path in SEVEN[:-1]:
    assert before[path] == command('git', 'show', head + ':' + path), path
plans = {}
plans[SEVEN[0]] = replace_once(before[SEVEN[0]],
    'import AutoSamplingTheory.ExampleCases.GaussianComplexity.AffinityTensorization\n',
    'import AutoSamplingTheory.ExampleCases.GaussianComplexity.AffinityTensorization\nimport AutoSamplingTheory.ExampleCases.GaussianComplexity.TVAmplification\n')
plans[SEVEN[1]] = replace_once(before[SEVEN[1]],
    'import Tests.GaussianComplexityAffinityTensorization\n',
    'import Tests.GaussianComplexityAffinityTensorization\nimport Tests.GaussianComplexityTVAmplification\n')
plans[SEVEN[2]] = replace_once(before[SEVEN[2]],
    'formalizedTechnicalLemmaCount = 614', 'formalizedTechnicalLemmaCount = 615')

registry = before[SEVEN[3]]
old_ex71_entry = registry.split(b'    key := "gaussian-complexity.affinity-tensorization",', 1)[1].split(b'\n  },', 1)[0]
old_ex71_note = old_ex71_entry.split(b'    note := ', 1)[1]
registry = replace_once(registry,
    'import AutoSamplingTheory.ExampleCases.GaussianComplexity.AffinityTensorization\n',
    'import AutoSamplingTheory.ExampleCases.GaussianComplexity.AffinityTensorization\nimport AutoSamplingTheory.ExampleCases.GaussianComplexity.TVAmplification\n')
registry = replace_once(registry,
    '    saldUse := "Actual all-source-parameter ambient Gaussian-mixture RN-affinity exponential-decay consumer; producer for actual Ex72 amplified TV",',
    '    saldUse := "Actual all-source-parameter ambient Gaussian-mixture RN-affinity exponential-decay consumer and canonical production consumer TVAmplification.actual_averaged_tv_lower_bound for actual measurable-event TV Ex72",')
entry = '''  {
    key := "gaussian-complexity.tv-amplification",
    localDecl := "AutoSamplingTheory.ExampleCases.GaussianComplexity.TVAmplification.actual_averaged_tv_lower_bound",
    upstreamDecl := "arXiv2610.20492v1 AppendixB.2.3 Ex72 final actual Gaussian-mixture TV inequality",
    upstreamFile := "S2.Ex2 TV convention; S3.E4-E6; A2.E25/Ex71/Ex72 and zero-residual omission",
    status := LemmaMemoryStatus.formalizedLocal,
    tags := ["GaussianComplexity", "actual-mixture-law", "measurable-event-TV", "Radon-Nikodym", "Ex72"],
    saldUse := "Actual all-source-parameter measurable-event TV amplification and actual-TV>=1/2 Test consumer under the explicit scale>=log2 threshold",
    note := "Mathematical source candidateebf76119351b23ef0718fc69aa5081515bab0b52; independent source/whole-module review and normal source V are pinned by separate exact receipts. Exactly3<=n<=d,kappa>=4. For the actual two common-sign matrix-prior inverse-precision Gaussian binds, measurable-event TV is at least1-exp(-floor(d/n)/8*exp(-10n/sqrt(kappa))). Actual Eq6 probability, RN L1/unit mass/event integration, the canonical normalized-density TV comparison, actual Ex71 tensorization and actual Eq25 are genuinely consumed internally; no probability/density/integrability/scalar-affinity or positive-remainder premise is added. Both residual cases are retained. The focused Test has actual TV>=1/2 under the explicit scale>=log2 condition. Oracle/transcript/precision/deterministic worst-case cap/expected-cost, hidden eigenbasis, both main bounds, remote publication and purification remain separate."
  },
'''
assert b'key := "gaussian-complexity.tv-amplification"' not in registry
registry = replace_once(registry, '  {\n    key := "gaussian-complexity.single-block-separation",',
    entry + '  {\n    key := "gaussian-complexity.single-block-separation",')
new_ex71_entry = registry.split(b'    key := "gaussian-complexity.affinity-tensorization",', 1)[1].split(b'\n  },', 1)[0]
assert new_ex71_entry.split(b'    note := ', 1)[1] == old_ex71_note
assert entry.count('localDecl :=') == 1 and DECL in entry
assert registry.count(b'key := "gaussian-complexity.tv-amplification"') == 1
plans[SEVEN[3]] = registry

frontier_raw = before[SEVEN[4]]
frontier = json.loads(frontier_raw)
guide = frontier['cases'][4]['reader_guide'][3]
boundary = frontier['cases'][4]['theorems'][0]['boundary']
newguide = 'Both main lower bounds remain open. Independently reviewed local Lean results are linked below. Actual common-sign Eq6, Ex70 density/coordinate volume, Ex71 intrinsic ambient-law RN-affinity tensorization and Ex72 actual measurable-event TV amplification are compiled and independently source-reviewed, reusing the same actual conditional laws and block-density nodes. All main-route oracle/transcript/precision/deterministic-cap/expected-cost and hidden-eigenbasis adapters remain separate.'
oldboundary = 'Amplified TV Ex72 still requires an explicit proof, as do the source-specific oracle/transcript/TV-precision/deterministic-query-cap composition and expected-cost reduction.'
newboundarypart = 'Actual amplified TV Ex72 is now also compiled and independently source-reviewed: for exactly3<=n<=d and kappa>=4, the measurable-event TV of the actual two common-sign matrix-prior Gaussian binds has the explicit exponential lower bound1-exp(-floor(d/n)/8*exp(-10n/sqrt(kappa))). Actual-law probability, RN L1/unit mass/event integration, the same normalized-density TV comparison, actual Ex71 tensorization and actual Eq25 are internally consumed, including both residual cases. The focused actual-TV>=1/2 consumer requires the explicit scale floor(d/n)/8*exp(-10n/sqrt(kappa))>=log2. The source-specific oracle/transcript/TV-precision/deterministic-query-cap composition and expected-cost reduction still require explicit proofs.'
assert boundary.count(oldboundary) == 1
newboundary = boundary.replace(oldboundary, newboundarypart, 1)
changed = frontier_raw
for old, new in ((guide, newguide), (boundary, newboundary)):
    old_raw, new_raw = (json.dumps(s, ensure_ascii=False).encode() for s in (old, new))
    assert changed.count(old_raw) == 1
    changed = changed.replace(old_raw, new_raw, 1)
after_frontier = json.loads(changed)
delta = differences(frontier, after_frontier)
assert set(delta) == {'/cases/4/reader_guide/3', '/cases/4/theorems/0/boundary'}
assert frontier['execution'] == after_frontier['execution']
for phrase in ('The full Theorem 3.1 lower bound remains open.',
               'worst-case deterministic query cap',
               'not an expected-cost lower bound without a separate reduction'):
    assert phrase in newboundary
plans[SEVEN[4]] = changed

card = before[SEVEN[5]]
oldremaining = '- Remaining: actual Ex72 TV; determinant-sign exact oracle/transcript/TV-precision/deterministic worst-case cap and explicit expected-cost adapters; fixed-spectrum hidden eigenbasis and both main lower bounds. Local root/site/Chrome, remote publication, purification/Exposition Seal and full Goal acceptance remain separate.'
newremaining = '- Direct production consumer: the same canonical actual RN-affinity tensorization is genuinely called by `TVAmplification.actual_averaged_tv_lower_bound`, the independently source-reviewed Ex72 measurable-event TV bound for the actual Gaussian-prior binds. This does not enlarge the scope of Ex71 itself.\n- Remaining route: determinant-sign exact oracle/transcript/TV-precision/deterministic worst-case cap and explicit expected-cost adapters; fixed-spectrum hidden eigenbasis and both main lower bounds. Remote publication, purification/Exposition Seal and full Goal acceptance remain separate.'
plans[SEVEN[5]] = replace_once(card, oldremaining, newremaining)
plans[SEVEN[6]] = '''# AutoSamplingTheory.ExampleCases.GaussianComplexity.TVAmplification

- File: `AutoSamplingTheory/ExampleCases/GaussianComplexity/TVAmplification.lean`.
- Sole declaration: `actual_averaged_tv_lower_bound`; one canonical compiled node.
- Mathematical source candidate: `ebf76119351b23ef0718fc69aa5081515bab0b52`; its audit was draft. The later independently source-reviewed audit and normal source V have separate exact receipts. No candidate/current audit byte equality is inferred.
- Domain: exactly `3 <= n <= d`, `kappa >= 4`, both actual common-sign conditioned full-Haar priors.
- Actual laws: the independent-block matrix priors pushed through the literal block precision, bound to true inverse-precision Gaussian measures. TV is the supremum over measurable event-probability discrepancies.
- Result: actual measurable-event `TV >= 1 - exp(-floor(d/n)/8 * exp(-10n/sqrt(kappa)))`, with the source probability normalization.
- Analytic adapters: actual law probabilities, RN-density L1/unit mass, finite event integration and the event-supremum comparison are discharged internally. No supplied density, integrability, probability, scalar-affinity or positive-remainder premise is added.
- Proof spine: actual Eq6 probability -> canonical ambient RN densities/event masses -> normalized-density TV/affinity comparison -> actual Ex71 tensorization -> actual Eq25 block estimate -> exact exponential lower bound. Both residual cases remain included.
- Real consumer: `Tests.GaussianComplexityTVAmplification` proves actual `TV >= 1/2` under the explicit threshold `floor(d/n)/8 * exp(-10n/sqrt(kappa)) >= log 2`; the production theorem has no such extra threshold premise.
- Reuse: the same actual Eq6, actual Ex71, actual Eq25 and canonical normalized-density TV comparison nodes, with pinned Mathlib RN integration and exponential-power facts. No duplicate wrapper or new conceptual transport.
- Source: Zhou--Suzuki arXiv2610.20492v1 S2.Ex2, S3.E4-E6, A2.E25/Ex70-Ex72 and the zero-residual omission. This is the selected final Ex72 inequality.
- Authored mathematics: `website/content/declaration_lessons/huanjian-tv-amplification.json`, bound by `website/content/publications/huanjian-tv-amplification.json`.
- Remaining: determinant-sign exact oracle/transcript/TV-precision/deterministic worst-case cap and explicit expected-cost adapters; fixed-spectrum hidden eigenbasis and both main lower bounds. Local root/site/Chrome, remote publication, purification/Exposition Seal and full Goal acceptance remain separate.
'''.encode()
assert set(plans) == set(SEVEN)

path_rows, raw_diff = [], b''
for i, path in enumerate(SEVEN):
    old = before[path]
    after = plans[path]
    assert old != after
    row = {'path': path, 'before_exists': old is not None,
           'before_sha256': sha(old) if old is not None else None,
           'planned_after_sha256': sha(after), 'planned_after_bytes': len(after)}
    if old is not None:
        row['before_archive'] = gz(OUT / f'shared-path-{i+1}.before.raw.gz', old)
    row['planned_after_archive'] = gz(STAGE / f'shared-path-{i+1}.planned-after.raw.gz', after)
    path_rows.append(row)
    raw_diff += b''.join(difflib.diff_bytes(difflib.unified_diff,
        (old or b'').splitlines(keepends=True), after.splitlines(keepends=True),
        fromfile=(('a/' + path).encode() if old is not None else b'/dev/null'),
        tofile=('b/' + path).encode()))
diff_raw_path = STAGE / 'reviewed-planned-shared.original.diff'
assert not diff_raw_path.exists()
diff_raw_path.write_bytes(raw_diff)
diff_archive = gz(OUT / 'reviewed-planned-shared.diff.gz', raw_diff)
assert diff_raw_path.read_bytes() == gzip.decompress((ROOT / diff_archive['path']).read_bytes())
save_json(OUT / 'raw-artifact-manifest.json', {
    'rule': 'Lossless raw-byte snapshots. Do not rewrite/normalize frozen diff context whitespace.',
    'diff': {'original_path': str(diff_raw_path.relative_to(ROOT)), **diff_archive},
    'shared_paths': path_rows,
})

sys.path.insert(0, str(ROOT / 'tools'))
import astis_advance as advance
ledger_protection, projected = {}, {}
own_state = None
for path, replayer in [('runs/substantive_advances.jsonl', advance._replay_advances),
                       ('runs/substantive_discoveries.jsonl', advance._replay_discoveries)]:
    raw = (ROOT / path).read_bytes()
    assert raw.endswith(b'\n')
    rows = [json.loads(line) for line in raw.splitlines() if line.strip()]
    states = replayer(rows)
    if path.endswith('substantive_advances.jsonl'):
        own_state = states.pop(ADV)
    else:
        states = {k: v for k, v in states.items() if v.get('advance_id') != ADV}
    projected[path] = states
    name = Path(path).name
    ledger_protection[path] = {
        'raw_prefix': gz(OUT / (name + '.prefix.raw.gz'), raw), 'rows': len(rows),
        'foreign_projection': gz(OUT / (name + '.foreign-projection.json.gz'), canonical(states)),
        'foreign_projected_records': len(states),
    }
single_stab = [k for k, v in projected['runs/substantive_advances.jsonl'].items() if v['state'] == 'STABILIZING']
if own_state['state'] == 'STABILIZING':
    single_stab.append(ADV)
assert single_stab == [], single_stab
assert own_state['state'] in ('PROVED_LOCAL', 'VERIFIED')

semantic_path = 'research-wiki/semantic-roundtrip/registry.json'
semantic_raw = (ROOT / semantic_path).read_bytes()
semantic = json.loads(semantic_raw)
semantic['audits'] = [a for a in semantic['audits'] if a.get('audit_id', a.get('id')) != AUDIT]
semantic_protection = gz(OUT / 'foreign-semantic-registry.json.gz', canonical(semantic))
semantic_protection['whole_file_before_sha256'] = sha(semantic_raw)
frontier_protection = gz(OUT / 'old-frontier.exact.raw.json.gz', frontier_raw)
frontier_protection['execution_sha256'] = sha(canonical(frontier['execution']))
foreign_frontier = json.loads(frontier_raw)
foreign_frontier['cases'][4]['reader_guide'][3] = '<AUTHORIZED_EX72_SCALAR>'
foreign_frontier['cases'][4]['theorems'][0]['boundary'] = '<AUTHORIZED_EX72_SCALAR>'
frontier_protection['all_other_values_sha256'] = sha(canonical(foreign_frontier))

own_markers = ('TVAmplification', 'tv-amplification', 'ex72-integration-20261107',
               'huanjian-ex72', 'huanjian-gc-ex72')
git_map, input_map = {}, {}
for line in command('git', 'ls-files', '--stage', '-z').split(b'\0'):
    if not line:
        continue
    metadata, raw_path = line.split(b'\t', 1)
    path = os.fsdecode(raw_path)
    mode, blob, stage = metadata.decode().split()
    assert stage == '0'
    if path in SEVEN or path in ledger_protection or path == semantic_path or any(m in path for m in own_markers):
        continue
    git_map[path] = [mode, blob]
    if not path.startswith('runs/'):
        p = ROOT / path
        raw = os.fsencode(os.readlink(p)) if p.is_symlink() else p.read_bytes()
        input_map[path] = {'sha256': sha(raw), 'bytes': len(raw)}
tracked = gz(OUT / 'protected-tracked-git-objects.json.gz', canonical(git_map))
inputs = gz(OUT / 'protected-source-content-sha256.json.gz', canonical(input_map))
atlas_stat = (ROOT / '.atlas-upstream').stat()
atlas_marker = {'path': '.atlas-upstream', 'status': 'pre-existing untracked; no content opened or traversed',
                'device': atlas_stat.st_dev, 'inode': atlas_stat.st_ino, 'mtime_ns': atlas_stat.st_mtime_ns}
for path in SEVEN:
    now = (ROOT / path).read_bytes() if (ROOT / path).exists() else None
    assert now == before[path], path
for path, expected in PINS.items():
    assert sha((ROOT / path).read_bytes()) == expected, path
status = command('git', 'status', '--short', '--untracked-files=normal')
(OUT / 'initial-worktree-status.txt').write_bytes(status)
report = {
    'reviewer': '/root/ex72_integration_reader_review',
    'phase': 'read-only shared integration and reader preparation',
    'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'head_at_start': head, 'head_at_end': command('git', 'rev-parse', 'HEAD').decode().strip(),
    'mathematical_source_candidate': CANDIDATE,
    'preparation_verdict': 'No blocking integration objection to this exact bounded proposal; conditional on genuine independent source V and later actual root/site/Chrome evidence.',
    'no_mathematical_or_source_verdict_originated': True,
    'no_shared_or_lifecycle_write': True,
    'build_browser_remote_or_integration_scripts_executed': [],
    'source_reviewed_wording_is_future_conditional_on_actual_source_v': True,
    'application_preconditions': ['Actual normal independent VERIFIED/source review for the exact pinned module/test/lesson/publication binding.',
        'Sole normal STABILIZING owner acquired by parent; reviewer owns no stabilization lease.',
        'Every before hash and new-file absence still matches; apply exact planned bytes, do not normalize raw diff context.',
        'Root alone applies seven paths, then freezes core for actual canonical gate, graph/site and Chrome evidence.'],
    'source_test_publication_lesson_pins': PINS,
    'publication_binding_sha256': BINDING,
    'own_sau_state_at_snapshot': own_state['state'],
    'single_stabilization_lane_at_snapshot': single_stab,
    'shared_paths': path_rows,
    'shared_path_count': len(SEVEN),
    'canonical_registry_nodes_added': 1,
    'inventory_count_delta': '614->615; administrative only',
    'existing_ex71_registry_note_byte_preservation': True,
    'frontier_scalar_pointer_delta': delta,
    'execution_and_all_other_frontier_values_preserved': True,
    'raw_diff': diff_archive,
    'ledger_protection': ledger_protection,
    'foreign_semantic_registry': semantic_protection,
    'old_frontier': frontier_protection,
    'tracked_git_objects': {'count': len(git_map), **tracked},
    'source_content_input_hashes': {'count': len(input_map), **inputs},
    'mutable_exclusions': {'seven_shared_paths': SEVEN, 'own_sau_markers': own_markers,
                           'own_ledger_projection_and_own_audit': [ADV, AUDIT]},
    'untracked_atlas': atlas_marker,
    'false_completion_boundary': 'Both main lower bounds; oracle/transcript/precision/deterministic worst-case cap/expected-cost/hidden-basis adapters; remote publication; purification/Exposition Seal; full Goal remain open.',
    'later_reader_acceptance_required': ['Exact adjacent folded Lean statement/proof, attributed formula/assumptions and authored stepwise proof.',
        'Actual desktop/mobile Chrome screenshots, every original inspected independently.',
        'Exact complete module, download and local immutable Git-object bytes; do not claim external GitHub HTML visibility without actual evidence.',
        'Source-index click to focused reader; canonical TV node and existing Eq6/Ex71/Eq25/normalized-TV nodes with proper solid/dashed semantics.',
        'Actual core-bound canonical Lean gate/site/graph receipts and preservation readback.'],
}
save_json(OUT / 'preparation-report.json', report)
print(json.dumps({'status': 'proposal prepared without shared writes', 'report': str((OUT / 'preparation-report.json').relative_to(ROOT)),
                  'report_sha256': sha((OUT / 'preparation-report.json').read_bytes()),
                  'raw_diff_sha256': sha(raw_diff), 'shared_paths': len(SEVEN),
                  'state': own_state['state'], 'single_stabilization_lane': single_stab,
                  'protected_tracked_objects': len(git_map), 'protected_live_inputs': len(input_map)}, indent=2))
