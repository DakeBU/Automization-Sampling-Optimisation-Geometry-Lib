#!/usr/bin/env python3
"""Freeze the production renderer's transitive local Python imports, without control data."""
import ast
from runner import *
directories=[REPO/'website/scripts',REPO/'tools']
lookup={}
for d in reversed(directories):
    for p in d.glob('*.py'):lookup[p.stem]=p
graph={};paths={}
def visit(name):
    if name in graph:return
    p=lookup[name];raw=p.read_bytes();relative=p.relative_to(REPO).as_posix()
    committed=must('renderer-v2-code-'+name,['git','show',CANDIDATE+':'+relative])
    assert committed==raw,relative
    imports=set()
    for node in ast.walk(ast.parse(raw.decode())):
        if isinstance(node,ast.Import):imports.update(x.name.split('.')[0] for x in node.names)
        if isinstance(node,ast.ImportFrom) and node.module:imports.add(node.module.split('.')[0])
    deps=sorted(imports & lookup.keys());graph[name]=deps
    paths[name]={'path':relative,'bytes':len(raw),'sha256':sha(raw),'all_import_names':sorted(imports)}
    target=OWN/'renderer-code'/relative;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
    for child in deps:visit(child)
for seed in ['declaration_lessons','publication_reader','astis_site']:visit(seed)
for path in json.loads((OWN/'closure.json').read_text())['modules'].values():
    source=path['path'];dest=OWN/'renderer-code'/source;dest.parent.mkdir(parents=True,exist_ok=True)
    dest.write_bytes((OWN/'fresh/src'/source).read_bytes())
for rel in ['website/content/declaration_lessons/huanjian-gaussian-source-matrix-mean.json',
            'website/content/publications/huanjian-gaussian-source-matrix-mean.json',
            'lean-toolchain','lake-manifest.json']:
    raw=must('renderer-v2-input-'+rel.replace('/','_').replace('.','_'),['git','show',CANDIDATE+':'+rel])
    assert raw==(REPO/rel).read_bytes()
    dest=OWN/'renderer-code'/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw)
save('renderer-python-closure.json',{'candidate':CANDIDATE,'seeds':['declaration_lessons','publication_reader','astis_site'],
    'modules':paths,'edges':graph,'count':len(paths),'method':'Recursive AST local-import closure, including function-local imports; runtime imported-module subset checked separately.'})
print('FROZEN PYTHON MODULES',len(paths))
