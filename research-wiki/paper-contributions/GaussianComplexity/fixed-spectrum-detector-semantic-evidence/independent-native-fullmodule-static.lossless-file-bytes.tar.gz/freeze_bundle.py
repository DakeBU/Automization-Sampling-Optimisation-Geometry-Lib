from pathlib import Path
import sys, json, hashlib, os, subprocess, datetime

W=Path(__file__).resolve().parent
R=W.parents[2]
C='65776f88e92b9680e6afe0d4c20b7390e4521241'
sha=lambda b:hashlib.sha256(b).hexdigest()
start=datetime.datetime.now(datetime.timezone.utc).isoformat()
assert not (W/'freeze-manifest.json').exists()
assert not (W/'freeze-receipt.json').exists()
commands=[]
def run(argv):
    p=subprocess.run(argv,cwd=R,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    commands.append({'argv':argv,'exit_code':p.returncode,'stdout':p.stdout.decode(errors='replace'),
                     'stderr':p.stderr.decode(errors='replace')})
    assert p.returncode==0,commands[-1]
    return p.stdout
head=run(['git','rev-parse','HEAD']).decode().strip(); assert head==C
diff=run(['git','diff','--name-status',C]); assert diff==b''
inputs=json.loads((W/'input-exposure-manifest.json').read_bytes())
for x in inputs['input_snapshots']:
    raw=(W/x['snapshot_relative_to_bundle']).read_bytes()
    assert len(raw)==x['byte_length'] and sha(raw)==x['raw_sha256']
    actual=(R/x['original_path']).read_bytes()
    assert actual==raw,x['original_path']
receipts=[]
for p in sorted(W.glob('*.receipt.json')):
    d=json.loads(p.read_bytes()); raw=(R/d['log']).read_bytes()
    assert sha(raw)==d['log_sha256'] and len(raw)==d['log_size']
    assert d['head_before']==d['head_after']==C
    assert d['exit_code']==({'prepare-evidence':1}.get(d['label'],0))
    receipts.append({'receipt':str(p.relative_to(W)),'byte_length':p.stat().st_size,
                     'raw_sha256':sha(p.read_bytes()),'exit_code':d['exit_code'],
                     'command':d['argv'],'head':C,'log_path':d['log'],
                     'log_byte_length':len(raw),'log_raw_sha256':sha(raw)})
run_index={'scope':'All post-bootstrap command receipts, including preserved diagnostic failure and preparation tail.',
           'candidate':C,'receipts':receipts,'retained_failure_receipts':['prepare-evidence.receipt.json'],
           'bootstrap_boundary':'bootstrap-read-receipt.json','self_seal_run':'freeze-receipt.json'}
(W/'run-index.json').write_text(json.dumps(run_index,indent=2,ensure_ascii=False)+'\n')

external=[]
for prefix in ['.lake/build/lib/lean/AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumDetector',
               '.lake/build/lib/lean/Tests/GaussianComplexityFixedSpectrumDetector',
               '.lake/build/ir/AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumDetector',
               '.lake/build/ir/Tests/GaussianComplexityFixedSpectrumDetector']:
    pp=R/prefix
    for p in sorted(pp.parent.glob(pp.name+'.*')):
        if p.is_file():
            b=p.read_bytes()
            external.append({'path_relative_to_repo':str(p.relative_to(R)),'byte_length':len(b),
                             'raw_sha256':sha(b),'disposition':'In-place standard Lake native cache; not lossless-carry requirement; not chmod/frozen by this lane.'})
native_context={'scope':'Explicit native-context retention/exclusion. The carried logs and source snapshots remain lossless; this is not a hermetic cache/runtime archive.',
                'external_focused_Lake_artifacts_at_freeze':external,
                'unarchived_runtime':'Lean/lake executable hashes and exact version are in check-lake-binary-stats.log. Runtime libraries, all transitive .olean caches and full package working trees are reused in place and not frozen/copied. Nine pinned heads, tracked-clean states, manifest bytes and focused locator source bytes are carried.',
                'no_deletion':'No cache/artifact is deleted. Own compiled files are separately enumerated below as retained-in-place native cache.'}
(W/'native-context-manifest.json').write_text(json.dumps(native_context,indent=2,ensure_ascii=False)+'\n')
log=json.dumps({'argv':[sys.executable,str(Path(__file__).resolve())],
                'started_utc':start,'head':head,'tracked_diff_from_candidate':'',
                'input_snapshots_read_back':len(inputs['input_snapshots']),
                'command_receipts_read_back':len(receipts),
                'commands':commands,
                'operation':'All hashes checked; writing complete carry/cache manifest then freezing own files to 0444.',
                'metadata_only':True},indent=2,ensure_ascii=False)+'\n'
(W/'freeze-run.log').write_text(log)
carry=[]; caches=[]
for p in sorted(W.rglob('*')):
    if not p.is_file(): continue
    raw=p.read_bytes(); rel=str(p.relative_to(W))
    row={'path_relative_to_bundle':rel,'path_relative_to_repo':str(p.relative_to(R)),
         'byte_length':len(raw),'raw_sha256':sha(raw),'frozen_mode':'0444'}
    cache=('.olean' in p.name or p.name.endswith('.ilean') or p.name.endswith('.o'))
    row['disposition']='retain_in_place_native_cache' if cache else 'lossless_carry_required'
    (caches if cache else carry).append(row)
manifest={'schema':1,'candidate_commit':C,'actual_head':head,
          'carry_contract':'Copy every lossless_carry_required item byte-for-byte, retaining relative paths or an explicit lossless path map. Parent must exact re-extract/read back; never rewrite a verifier verdict. No silent omission of logs, failed predecessors, scripts, receipts, source snapshots or static HTML.',
          'lossless_carry_required':carry,'native_cache_retained_in_place':caches,
          'external_context':'native-context-manifest.json',
          'self_reference_boundary':'This manifest cannot hash itself. freeze-receipt.json binds its exact raw bytes; the final tool response reports the freeze-receipt raw hash. Both files are carry-required control records.',
          'carry_control_files':['freeze-manifest.json','freeze-receipt.json']}
mf=W/'freeze-manifest.json'; mf.write_text(json.dumps(manifest,indent=2,ensure_ascii=False)+'\n')
for row in carry+caches:
    p=W/row['path_relative_to_bundle']; assert sha(p.read_bytes())==row['raw_sha256']; p.chmod(0o444)
mf.chmod(0o444)
for row in carry+caches:
    p=W/row['path_relative_to_bundle']
    assert (p.stat().st_mode & 0o777)==0o444 and sha(p.read_bytes())==row['raw_sha256']
receipt={'schema':1,'verifier_id':'detector_module_reader_72c9e4','candidate_commit':C,'actual_head':head,
         'command':[sys.executable,str(Path(__file__).resolve())],
         'started_utc':start,'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
         'exit_status':0,'freeze_log':{'path':'freeze-run.log','byte_length':len((W/'freeze-run.log').read_bytes()),'raw_sha256':sha((W/'freeze-run.log').read_bytes())},
         'freeze_manifest':{'path':'freeze-manifest.json','byte_length':mf.stat().st_size,'raw_sha256':sha(mf.read_bytes()),'mode':'0444'},
         'carry_items_read_back_and_0444':len(carry),'in_place_native_cache_items_read_back_and_0444':len(caches),
         'all_manifest_entries_verified':True,'tracked_diff_empty':True,
         'report':{'path':'independent-report.json','byte_length':(W/'independent-report.json').stat().st_size,'raw_sha256':sha((W/'independent-report.json').read_bytes())},
         'report_md':{'path':'independent-report.md','byte_length':(W/'independent-report.md').stat().st_size,'raw_sha256':sha((W/'independent-report.md').read_bytes())},
         'self_binding':'The parent/tool final message supplies this receipt raw SHA-256 and byte length. This receipt is frozen 0444 and must itself be carried losslessly.',
         'scope':'Metadata sealing only; does not add a native, source, global, browser or publication success.'}
rf=W/'freeze-receipt.json'; rf.write_text(json.dumps(receipt,indent=2,ensure_ascii=False)+'\n');rf.chmod(0o444)
print(json.dumps({'candidate':C,'actual_head':head,'carry_items':len(carry),'native_cache_items':len(caches),
                  'freeze_manifest_byte_length':mf.stat().st_size,'freeze_manifest_raw_sha256':sha(mf.read_bytes()),
                  'freeze_receipt_byte_length':rf.stat().st_size,'freeze_receipt_raw_sha256':sha(rf.read_bytes()),
                  'report_json_byte_length':(W/'independent-report.json').stat().st_size,'report_json_raw_sha256':sha((W/'independent-report.json').read_bytes()),
                  'report_md_raw_sha256':sha((W/'independent-report.md').read_bytes()),'all_own_files_frozen_0444':True},indent=2))
