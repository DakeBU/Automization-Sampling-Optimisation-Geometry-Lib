# Phase 2a actual-input / exposure record

Phase1 is preserved and not edited. Its incidental filename exposure remains in its original log. This phase starts only after the parent authorized the exact three added inputs and bounded standard-definition reads. Other-actor graph and process/root-exposure review have not begun.

## Authorized mathematical/interface inputs

1. Read and hash-verified the complete authorized `strict-preproof-seal-projection-v1.json` (8689 bytes, SHA256 f1e34ef583a965957cbde49e2005636c338f37615ad153777875438f5433fc9f), `producer-signature.txt` (786 bytes, SHA256 c1abe1c57e12337dc3592297e624edd757deb18f9eae17ecdc9faca40e2609f4), and `consumer-signature.txt` (1339 bytes, SHA256 364843a1d3e581a3b9498eed483b0dff44faad722a67d90c46566da038fc4d2e). The projection includes proposed binder/definition classifications, metadata of planned files, and a claimed real consumer. These are visible candidate claims, not independent evidence of correctness or actual implementation dependency.
2. Compared them with frozen phase1 raw-source cognition/snippets. No additional paper, external theorem source, source graph, root proofplan, full-seal process fields, previous review/lesson or implementation was read.
3. Read the local pinned Mathlib necessary definition windows. Actual file paths, file SHA256, line ranges and verbatim window content are preserved in `phase2a/mathlib-read-ranges.json` and `phase2a/mathlib-definition-evidence.txt`.

## Definition-location searches and adjacent text

Definition-location queries were limited to the named standard definitions and immediate unfolding candidates in pinned Mathlib. They included filenames containing WithLp/PiLp/Euclidean/Matrix Defs/Basic/Algebra/measure Map, targeted declaration-name searches for aeval/eval₂, Chebyshev T, orthogonal/unitary carriers, Euclidean/WithLp/PiLp, Matrix/diagonal/transpose/map/scalar/multiplication/dotProduct/mulVec/inverse, and Measure.map/MeasurableSet. These searches printed some additional standard-library declaration names/one-line signatures in the same files and Matrix subdirectories, but no target declarations or implementation proofs. `Data/Matrix/Defs.lean` was an unsuccessful guessed path; it did not exist and no content was read there. The actual matrix carrier definition was found under `LinearAlgebra/Matrix/Defs.lean`.

Some selected line windows were too broad for a definition-only ideal and exposed adjacent **standard-library** proof text or proof-bearing structure fields. This is retained rather than erased:

* Authorized initial Multivariate lines 160–175 include the first lines of `multivariateGaussian_of_not_posSemidef` at 172–175.
* AlgebraMap 237–259 includes the inverse fields of the aeval equivalence; 150–164 includes the adjacent `eval₂_intCastRingHom_X` proof term at 150–153 and the defining homomorphism proof field.
* UnitaryGroup 285–304 includes two direct equivalence theorem proof terms; 44–66 includes `inferInstance` examples.
* WithLp 45–81 includes inverse-equivalence proof fields and a definitional rfl lemma at 78–79. PiL2 103–121 includes the direct rfl inner-product identity at 103–105. PiLp 335–350 ends at the signature of a norm theorem, without its body.
* Measure/Map 58–88 includes adjacent `liftLinear` theorem terms and `mapₗ_congr` proof at 81–85. Map 87–101 includes the defining map plus `mapₗ_mk_apply_of_aemeasurable` and `mapₗ_apply_of_measurable` proof lines 95–101.
* Polynomial/Eval/Defs 48–60 ends at a theorem's `:= by`; 174–182 begins with one preceding proof line and includes defining ring-hom law fields.
* NonsingularInverse 148–174 includes adjacent determinant/inverse theorem proof terms as well as the inverse definition; no target matrix-polynomial or detector proof occurs there.
* Matrix Basic 224–232 includes defining Algebra law fields. Matrix Mul 290–303 includes `mul_apply`'s rfl proof. Algebra/Star/Unitary 31–38 includes defining submonoid closure fields.

The parent was informed of adjacent standard-proof exposure during the phase, before the mathematical verdict freeze. No target proving API experiment was run. No full Mathlib target proof, ASTIS target proof, target test, source graph, or root process record was read. Standard-library exposure is not represented as zero exposure and any process-qualification decision remains for phase3.

## Output drafting and revisions

The first unsealed `phase2a-source-statement-verdict.md` draft explicitly contained a producer-digest transcription error alongside its correction. It remains preserved. `phase2a-source-statement-verdict-v2.md` removes that erroneous spelling and supersedes the draft for reporting; mathematical judgments are unchanged. Both are included in the output manifest. No phase1 artifact or earlier HOLD was overwritten.

All phase2a outputs are under the assigned neutral directory. There was no normal API, ledger, frontier, shared, site or Git mutation, no Lean invocation, no target proof experiment, no background ASTIS or other worker launch. Process/graph/proof/sourceV/global credit remains HOLD.
