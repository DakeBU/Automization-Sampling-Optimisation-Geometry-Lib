#!/opt/anaconda3/bin/python
import datetime
import hashlib
import json
import pathlib
import stat
BASE=pathlib.Path(__file__).resolve().parent
assert not (BASE/'manifest.json').exists(),'Refuse to refreeze.'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
inputs=json.loads((BASE/'input_inventory.json').read_text())
inputs.append(json.loads((BASE/'requested_input_inventory.json').read_text()))
for row in inputs:
    path=BASE/row['snapshot']
    assert len(path.read_bytes())==row['bytes'] and sha(path)==row['sha256']
commands=[json.loads(x) for x in (BASE/'actual_commands.jsonl').read_text().splitlines()]
for row in commands:
    for stream in ['stdout','stderr']:
        path=BASE/row[stream+'_file']
        assert len(path.read_bytes())==row[stream+'_bytes'] and sha(path)==row[stream+'_sha256']
    assert row['returncode']==0
phase1=BASE.parent/'phase1'
assert sha(phase1/'manifest.json')=='80d4eefdb9d3d733e60d4ea52d00207c5ca62e03c1964b94e404525c2e472079'
assert sha(phase1/'raw_first_cognition.md')=='3b4d1066754e4798eca86acbab56e5d16779d5ea8f2e7936a1af88f3de30f75b'
assert sha(phase1/'freeze_receipt.json')=='8834e685793c01200a664e1bb1f439b6e77e132a16134241a23ea92e780f2452'
for row in json.loads((phase1/'manifest.json').read_text())['payloads']:
    path=phase1/row['path']
    assert sha(path)==row['sha256'] and stat.S_IMODE(path.stat().st_mode)==0o444
assert stat.S_IMODE(phase1.stat().st_mode)==0o555
entries=[]
for path in sorted(BASE.rglob('*')):
    if path.is_file():
        path.chmod(0o444)
        entries.append({'path':str(path.relative_to(BASE)),'bytes':len(path.read_bytes()),
                        'sha256':sha(path),'mode':'0444'})
manifest={'phase':'phase2-selective-before-code','payloads':entries,
          'excluded_self_and_receipt':['manifest.json','freeze_receipt.json'],
          'phase1_cognition_sha256':'3b4d1066754e4798eca86acbab56e5d16779d5ea8f2e7936a1af88f3de30f75b'}
mp=BASE/'manifest.json';mp.write_text(json.dumps(manifest,indent=2)+'\n');mp.chmod(0o444)
receipt={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
         'phase':'phase2-selective-before-code','manifest_sha256':sha(mp),
         'judgment_sha256':sha(BASE/'selective_phase2_judgment.md'),
         'phase1_verified_unchanged':True,'authorized_input_count':len(inputs),
         'authorized_inputs':inputs,'payload_count':len(entries),
         'actual_captured_command_count':len(commands),
         'all_captured_returncodes_observed':[r['returncode'] for r in commands],
         'candidate_implementation_seen':False,'compiler_run_by_this_role':False,
         'freeze_execution_record_outside_phase':'../phase2_freeze_execution.json',
         'manifest_excludes_itself_and_receipt':True}
rp=BASE/'freeze_receipt.json';rp.write_text(json.dumps(receipt,indent=2)+'\n');rp.chmod(0o444)
for path in sorted(BASE.rglob('*'),reverse=True):
    if path.is_dir():path.chmod(0o555)
BASE.chmod(0o555)
assert all(stat.S_IMODE(p.stat().st_mode)==0o444 for p in BASE.rglob('*') if p.is_file())
assert all(stat.S_IMODE(p.stat().st_mode)==0o555 for p in BASE.rglob('*') if p.is_dir())
assert stat.S_IMODE(BASE.stat().st_mode)==0o555
print(json.dumps({'manifest_sha256':sha(mp),'judgment_sha256':sha(BASE/'selective_phase2_judgment.md'),
                  'receipt_sha256':sha(rp),'phase_directory':str(BASE),
                  'phase_directory_mode_observed':'0555','all_phase_file_modes_observed':'0444',
                  'all_phase_subdirectory_modes_observed':'0555',
                  'payload_count':len(entries),'authorized_input_count':len(inputs),
                  'phase1_verified_unchanged':True},indent=2))
