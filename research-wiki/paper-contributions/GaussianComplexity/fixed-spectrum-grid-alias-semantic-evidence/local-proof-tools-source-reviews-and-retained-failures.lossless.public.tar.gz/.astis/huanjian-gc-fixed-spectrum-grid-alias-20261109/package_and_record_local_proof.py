from pathlib import Path
import gzip,hashlib,json,re,subprocess,sys,tarfile
sys.dont_write_bytecode=True
sys.path.insert(0,'tools');import astis_advance as adv;import astis_publication as pub
W=Path('.astis/huanjian-gc-fixed-spectrum-grid-alias-20261109')
E=Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-grid-alias-semantic-evidence')
C=Path('research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-grid-alias.json')
L=Path('runs/substantive_advances.jsonl')
ADV='ASTIS-SA-20261109-GaussianComplexityFixedSpectrumGridAlias';OWNER='huanjian_gc_20261109_fixed_spectrum_grid_alias'
sha=lambda b:hashlib.sha256(b).hexdigest()
dump=lambda x:(json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode()
def ref(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'sha256':sha(b),'bytes':len(b)}
def put(p,b):
 assert not p.exists(),p;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()=='71375dfbf73e209f49ae637317626de2e934ef2b'
assert not subprocess.check_output(['git','diff','--cached','--name-only']).strip()
seal=json.loads((W/'statement-seal-v2.json').read_text());name=seal['producer']['name']
prod=Path(seal['producer']['planned_file']);test=Path(seal['actual_private_consumer']['planned_file'])
for p,s,n in [(prod,seal['producer']['signature'],'theorem actual_midpoint_grid_cosine_alias'),(test,seal['actual_private_consumer']['signature'],'private theorem actual_weighted_inverse_grid_alias_series')]:
 assert p.read_text().split(n,1)[1].split(' := by',1)[0]==s.split(n,1)[1].rstrip()
 assert not re.search(r'\b(sorry|admit|axiom)\b|Prop\s*:=\s*True|:=\s*trivial\b',p.read_text()),p
stems=['20261109T135103546819Z-grid-alias-consumer-explicit-absolute-and-denominator-background-v3','20261109T135234666258Z-grid-alias-final-consumer-background-kernel-and-sealed-types']
checkrows=[]
for stem in stems:
 p=Path('.astis/huanjian-resume-20261103')/(stem+'.receipt.json');r=json.loads(p.read_text());b=Path(r['log']).read_bytes();assert r['exit_code']==0 and sha(b)==r['log_sha256'];checkrows.append({'receipt':ref(p),'raw_log_sha256':sha(b),'exit_code':0})
klog=Path(json.loads(Path(checkrows[-1]['receipt']['path']).read_text())['log']).read_text()
assert 'ACTUAL_PRIVATE_SEALED_LITERAL_KERNEL_TYPE_APPLICATION_PASS' in klog and 'sorryAx' not in klog
pub.check_advance([name],reviewed=False)
for base,f in [(W/'independent-source-graph','FINAL-MANIFEST.json'),(W/'independent-source-graph/phase3-topology-clarification','SUCCESSOR-MANIFEST.json'),(Path('.astis/semantic-neutral-20261109/src_82a91d/phase1'),'FREEZE.json'),(Path('.astis/semantic-neutral-20261109/src_82a91d/phase2'),'FREEZE.json')]:
 for row in json.loads((base/f).read_text())['files']:
  p=base/row['path'];assert sha(p.read_bytes())==row['sha256'] and p.stat().st_size==row['bytes'],p
mapping={
 'gap-d-nonzero':(prod,'have hd0','Source hd internally yields nonzero real dimension; integer divisor positivity follows the same source range, with no extra binder.'),
 'gap-grid-index-transport':(prod,'have hgrid','Literal Fin index i.val corresponds to source i+1; canonical Fin.sum_univ_eq_sum_range transports the actual finite sum.'),
 'gap-nonmultiple-sine-denominator':(prod,'have hsin','Sin zero-set yields an integer multiple and contradicts the current nonalias guard.'),
 'gap-finite-cosine-ratio':(prod,'have hsum','Canonical Real.sin_mul_sum_cos gives the equivalent multiplication identity. With internally proved nonzero sine this discharges the quoted quotient route without unsafe division at aliases.'),
 'gap-integer-sine-zero':(prod,'have hzero','Real.sin_int_mul_pi, sin_two_mul and exact endpoint algebra, including negative/zero k.'),
 'gap-exact-int-quotient':(prod,'have hq :','Int.mul_ediv_cancel\' under the true divisibility guard; exact quotient remains Int.'),
 'gap-integer-cosine-parity':(prod,'have hterm','hangle and canonical integer-periodic cosine give real zpow at the exact quotient.'),
 'gap-consumer-denominators':(test,'have hsqrt','hsqrt and heigenlower produce square-root positivity and lambda_i>=1. heigenlower is materially used for reciprocal normalization; hsqrt is used in final coefficient algebra.'),
 'gap-cosine-weight-bounded':(test,'have hmajor','Real.abs_cos_le_one bounds the literal weight; hmajor and hsgnorm explicitly produce absolute weighted summability, then hsg.'),
 'gap-finite-tsum-interchange':(test,'have hexchange','C7 heq/habs are genuinely consumed; actual Summable.tsum_finsetSum exchanges the finite weighted grid and infinite series.'),
 'gap-n-nonmultiple':(test,'have hnnon','Source1<=n<d and Int.le_of_dvd derive n not divisible by2d; hcos at n produces hzero.'),
 'gap-product-to-sum-background':(test,'have hprod','Real.two_mul_cos_mul_cos at real grid angles; cast to Int before difference, then use the new alias at both shifted frequencies.'),
 'gap-summability-transport':(test,'have hFpoint','hterm proves2G_j=dF_j; nonzero d transports actual Summable to F and hseries transports the sums.')}
graph=json.loads((W/'independent-source-graph/phase3-topology-clarification/lossless-topology-successor.json').read_text())
gapids={n['id'] for n in graph['expanded_nodes'] if n.get('kind')=='INTERNAL_SOURCE_GAP'};assert gapids==set(mapping)
rows=[]
for node,(p,needle,explanation) in mapping.items():
 lines=p.read_text().splitlines();line=next(i+1 for i,s in enumerate(lines) if needle in s)
 rows.append({'source_node':node,'lean_file':str(p),'line':line,'local_provider':needle,'implementation_map':explanation,'classification':'compiled-local-source-obligation-map-independent-whole-module-review-pending'})
put(E/'source-to-lean-map.json',dump({'seal':ref(W/'statement-seal-v2.json'),'source_graph':ref(W/'independent-source-graph/phase3-topology-clarification/lossless-topology-successor.json'),'obligations':rows,'unproved_outside_packet':['Gaussian expectation-to-grid adapter','Unweighted/weighted alias tail partitions and closed resummations','FullC8, Lemma4.5 variance/bias, mainbounds and true model/cost adapters'],'no_extra_binders':True,'not_an_independent_source_verdict':True}))
for src,dst in [(W/'independent-source-graph/phase1/raw-first-author-graph.json',E/'source-only-review/raw-first-author-graph.json'),(W/'independent-source-graph/phase1/exhaustive-bounded-coverage.json',E/'source-only-review/exhaustive-bounded-coverage.json'),(W/'independent-source-graph/phase2/exact-interface-projection.json',E/'source-only-review/exact-interface-projection.json'),(W/'independent-source-graph/phase3-topology-clarification/lossless-topology-successor.json',E/'source-only-review/lossless-topology-successor.json'),(W/'independent-topology-challenge/graph-review-initial-hold.md',E/'topology-review/initial-hold.md'),(W/'independent-topology-challenge/successor-final-admission.md',E/'topology-review/successor-final-admission.md'),(W/'independent-topology-challenge/successor-final-input-manifest.json',E/'topology-review/successor-final-input-manifest.json')]:put(dst,src.read_bytes())
roots=[W/'independent-source-graph',W/'independent-topology-challenge',W/'type-formation-history',Path('.astis/semantic-neutral-20261109/src_82a91d/phase1'),Path('.astis/semantic-neutral-20261109/src_82a91d/phase2'),Path('.astis/semantic-neutral-20261109/src_82a91d/phase2-inputs')]
payload=[p for root in roots for p in sorted(root.rglob('*')) if p.is_file() and '__pycache__' not in p.parts]
payload += [p for p in sorted(W.iterdir()) if p.is_file()]
archive=E/'local-proof-tools-source-reviews-and-retained-failures.lossless.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz') as t:
 for p in payload:t.add(p,arcname=str(p),recursive=False)
with tarfile.open(archive,'r:gz') as t:
 for p in payload:assert t.extractfile(str(p)).read()==p.read_bytes(),p
put(E/'local-proof-archive-manifest.json',dump({'archive':ref(archive),'files':[{'member':str(p),**ref(p)} for p in payload],'scope':'Frozen preproof source graph/HOLD+successor, exact formation/failure history, actual independent source phase1/statement-only phase2, root tools/probes. Whole-module source review, V and integration remain pending.'}))
checks=E/'actual-local-checks';assert not checks.exists();checks.mkdir();actual=[]
for p in sorted(Path('.astis/huanjian-resume-20261103').glob('*-grid-alias-*.receipt.json')):
 r=json.loads(p.read_text());raw=Path(r['log']).read_bytes();assert sha(raw)==r['log_sha256'];put(checks/p.name,p.read_bytes());put(checks/(Path(r['log']).name+'.gz'),gzip.compress(raw,mtime=0));actual.append({'receipt':ref(checks/p.name),'actual_exit_code':r['exit_code'],'raw_log_sha256':sha(raw)})
put(E/'actual-local-checks-manifest.json',dump({'actual_checks':actual,'scope':'Actual command exit codes preserved individually, including parser, consumer cast and initial kernel-instrumentation failures. No aggregate/site or sourceV credit.'}))
mirror=json.loads((E/'postproof-conceptual-mirror-audit.json').read_text());ma={'status':'candidates-published','discovery_ids':mirror['discovery_ids']}
before=L.read_bytes();states=adv._replay_advances([json.loads(x) for x in before.splitlines()]);assert states[ADV]['state']=='EXPLORING' and states[ADV]['owner_id']==OWNER
cellraw=C.read_bytes();cell=json.loads(cellraw)
boundary='Exact original all-Int midpoint alias and actual private summable weighted inverse-grid alias series compiled with literal sealed types and standard recursive axioms. Source-blind decoding and independent fresh source statement-only comparison complete with disclosed ambient filename-cue limits. Independent whole-module/current-reader/fresh-runtime source review, sourceV, latest-main sole-STAB integration/site/browser/remote acceptance and purification remain pending. Gaussian expectation identification, closed alias tails, fullC8/variance/bias/Krylov, both full main bounds and actual oracle/precision/TV/deterministic-cap/expected-cost adapters remain open. The midpoint/Lobatto relation is conceptual, not a Lean implication; foreign queues are untouched.'
evidence={'result_kind':'theorem-edge','theorem_delta':cell['target_statement'],'lean_files':[str(prod),str(test)],'lean_declarations':[name],'publication_declarations':[name],'focused_checks':checkrows,'truth_boundary':boundary,'conceptual_mirror_audit':ma,'actual_consumer':'Actual private weighted inverse-grid series materially consumes C7 and the new alias, explicit weighted absolute convergence, denominator bounds, product-to-sum and finite-series exchange. Exactly these2 public ASTIS parents after generated-local-auxiliary expansion.','source_blind_decoder':'/root/decoder_6c92f7','source_VERIFIED_or_integration':False}
adv.transition_advance(ADV,'PROVED_LOCAL',worker_id=OWNER,evidence=evidence)
after=L.read_bytes();assert after.startswith(before);append=after[len(before):];assert len(append.splitlines())==1
new=adv._replay_advances([json.loads(x) for x in after.splitlines()]);assert new[ADV]['state']=='PROVED_LOCAL' and {k:v for k,v in new.items() if k!=ADV}=={k:v for k,v in states.items() if k!=ADV}
put(E/'frontier-before-PROVED_LOCAL.raw.json.gz',gzip.compress(cellraw,mtime=0));put(E/'actual-PROVED_LOCAL-append.exact.jsonl',append)
capsule={'state':'PROVED_LOCAL_NOT_SOURCE_VERIFIED','advance_id':ADV,'owner':OWNER,'actual_normal_PROVED_LOCAL_API_calls':1,'append_sha256':sha(append),'foreign_SAU_states_preserved':len(states)-1,'producer':{**ref(prod),'declaration':name,'actual_public_ASTIS_parents':[]},'private_consumer':{**ref(test),'actual_public_ASTIS_parents':[name,'AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumCosineExpansion.actual_inverse_spectrum_cosine_expansion'],'Registry_node':False},'generated_auxiliaries':'Actual compiler-generated theorem bodies recursively expanded and checked; raw direct constants preserved in exact kernel log. Generated helpers are not extra canonical public nodes.','actual_checks':checkrows,'exact_literal_signatures_kernel_applied':True,'actual_recursive_kernel_axioms':['propext','Classical.choice','Quot.sound'],'targeted_authored_fake_closure_scan':{'files':[str(prod),str(test)],'hits':0,'scope':'Actual authored-text scan plus recursive actual proof axioms; official full gate remains integration work.'},'source_to_lean_map':ref(E/'source-to-lean-map.json'),'conceptual_mirror_audit':ma,'truth_boundary':boundary,'source_VERIFIED_or_integration_or_purification_or_Goal':False}
put(E/'local-proof-capsule.json',dump(capsule))
cell['status']='proved_locally';cell['evidence'].update({'execution_boundary':boundary,'focused_checks':[x['receipt']['path'] for x in checkrows],'local_proof_capsule':str(E/'local-proof-capsule.json'),'actual_compiled_public_ASTIS_producer_parents':[],'actual_compiled_public_ASTIS_consumer_parents':capsule['private_consumer']['actual_public_ASTIS_parents'],'publication_binding_sha256':json.loads(Path('research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-grid-alias.json').read_text())['publication_binding_sha256']})
cell['statement_seal']['status']='EXACT_ORIGINAL_SIGNATURES_COMPILED_LOCAL_INDEPENDENT_WHOLE_MODULE_REVIEW_PENDING'
cell['source_proof_coverage'].update({'preproof_internal_obligation_list_is_preserved_phase_history':True,'source_to_lean_map':ref(E/'source-to-lean-map.json'),'current_compiled_scope':{'producer':'Exact all-integer midpoint alias','consumer':'Actual weighted inverse-grid alias series with produced Summable, absolute weighting and denominator backgrounds','evidence':str(E/'local-proof-capsule.json'),'source_VERIFIED':False}})
cell['source_detail_audit']['gap']='Selected alias and private series scope locally discharged, including denominator/weighted absolute convergence. Gaussian expectation/closed alias tail/moment/variance/bias bridges remain outside. Independent whole-module review and sourceV pending.';cell['source_detail_audit']['fidelity_boundary']=boundary
search='Post-admission exact search reused pinned Real.sin_mul_sum_cos/sin_eq_zero_iff/integer cosine period and Real.two_mul_cos_mul_cos. Mathlib Chebyshev sumZeroes_T_of_not_dvd provides a polynomial-grid nonalias fact; the direct canonical sine-product route preserves the source two-case argument without copying a finite-sum lemma. Existing ASTIS endpoint-weighted Lobatto helper has different grid/weights/alias sign/domains, so is not an identical canonical alias.'
cell['reuse_plan']['searched_existing'].append(search);cell['shared_floor_audit']['searched'].append(search);cell['shared_floor_audit']['notes']='Reuse canonical Mathlib trigonometric primitives; one literal source all-Int adapter with a materially stronger actual private weighted consumer. No duplicate generic trigonometric wrapper.'
cell['reuse_plan'].update({'known_consumers':['Actual compiled private actual_weighted_inverse_grid_alias_series: canonical C7+new alias, convergence, product-to-sum and genuine finite-grid/tsum exchange.'],'planned_consumers':['Future exact unweighted/weighted closed grid moments and Gaussian expectation identification, not compiled by this packet.'],'decision_reason':'One source all-integer midpoint node and a genuine alias-supported reciprocal-grid consumer; exact compiled declarations stay canonical.'})
cell['graph_contribution']['functor_view']='candidate-published';cell['graph_contribution']['visual_review']='No site acceptance yet. Midpoint/Lobatto typed conceptual candidate published for distinct review; no shared model edits or formal certificate.';cell['conceptual_mirror_audit']=ma
C.write_bytes(dump(cell))
p=Path('research-wiki/paper-contributions/GaussianComplexity/README.md');old=p.read_bytes()
note=('## 2026-11-09: midpoint alias mathematical candidate; independent whole-module review pending\n\nThe exact all-integer midpoint cosine alias and a genuine summable weighted inverse-grid series consumer compile locally. The consumer materially uses canonical C7 and the new alias; its absolute convergence and denominator backgrounds are produced internally. The original signatures are unchanged. Source-blind decoding and fresh statement-only source comparison are frozen; whole-module/source V, latest-main integration, website/browser/remote acceptance and purification remain pending. Gaussian expectation identification, closed C8 sums, variance/bias, both main bounds and actual oracle/precision/cost adapters remain open. See `fixed-spectrum-grid-alias-semantic-evidence/local-proof-capsule.json`. This is the same continuing Goal; old results, foreign queues and append-only prefixes are preserved.\n\n').encode()
p.write_bytes(note+old)
print(json.dumps({'state':'PROVED_LOCAL','append_sha256':sha(append),'producer':ref(prod),'consumer':ref(test),'source_VERIFIED':False,'archive_sha256':sha(archive.read_bytes())}))
