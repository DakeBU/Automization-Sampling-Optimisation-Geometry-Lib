from pathlib import Path
import gzip, hashlib, json, subprocess, tarfile
sha = lambda raw: hashlib.sha256(raw).hexdigest()
B = Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-normalizer-integration-20261108')
S = Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-normalizer-semantic-evidence/fresh-source-reader-640251')
ROOT_TOOLS = Path('.astis/huanjian-gc-fixed-spectrum-normalizer-integration-20261108')
CORE = 'a5ec44836422e56ca5cfab14f951ed84bbfc9324'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD']).decode().strip() == CORE
assert not subprocess.check_output(['git', 'diff', '--cached', '--name-only']).strip()
out = B / 'finalmetadata-checks'
out.mkdir(exist_ok=True)
labels = ['fixed-spectrum-normalizer-final-local-metadata-projection', 'fixed-spectrum-normalizer-finalmetadata-publication', 'fixed-spectrum-normalizer-finalmetadata-contributor-edge-enum-corrected', 'fixed-spectrum-normalizer-finalmetadata-frontier', 'fixed-spectrum-normalizer-finalmetadata-semantic']
for label in labels:
    rows = list(Path('.astis/huanjian-resume-20261103').glob('*-' + label + '.receipt.json'))
    assert len(rows) == 1
    p = rows[0]
    r = json.loads(p.read_bytes())
    assert r['exit_code'] == 0 and r['head_before'] == r['head_after'] == CORE
    lograw = Path(r['log']).read_bytes()
    assert sha(lograw) == r['log_sha256']
    (out / p.name).write_bytes(p.read_bytes())
    z = out / (Path(r['log']).name + '.gz')
    z.write_bytes(gzip.compress(lograw, mtime=0))
    assert gzip.decompress(z.read_bytes()) == lograw
prefixes = [B, S / 'post-integration-normalpark-preparation', S / 'post-integration-normalpark-execution']
files = sorted({p for base in prefixes for p in base.rglob('*') if p.is_file()})
tracked = set(subprocess.check_output(['git', 'ls-files', '-z']).decode().split('\0'))
ignore = subprocess.run(['git', 'check-ignore', '-z', '--stdin'], input=b'\0'.join(str(p).encode() for p in files) + b'\0', capture_output=True)
assert ignore.returncode in (0, 1)
ignored = set(ignore.stdout.decode().split('\0'))
def unsafe(raw):
    return b'\r\n' in raw or raw.endswith(b'\n\n') or any(line.endswith((b' ', b'\t')) for line in raw.splitlines())
excluded = [p for p in files if str(p) not in tracked and (str(p) in ignored or (p.suffix not in ['.gz', '.png'] and unsafe(p.read_bytes())))]
private = sorted(ROOT_TOOLS.glob('*.py'))
originals = sorted(set(excluded + private))
archive = B / 'final-runtime-originals.lossless.tar.gz'
manifest = B / 'final-runtime-originals.manifest.json'
assert not archive.exists() and not manifest.exists()
with tarfile.open(archive, 'w:gz') as t:
    for p in originals: t.add(p, arcname=str(p), recursive=False)
with tarfile.open(archive, 'r:gz') as t:
    assert len(t.getmembers()) == len(originals)
    for p in originals: assert t.extractfile(str(p)).read() == p.read_bytes()
manifest.write_text(json.dumps({'archive': str(archive), 'archive_sha256': sha(archive.read_bytes()), 'originals_retained_without_normalization_or_deletion': True, 'files': [{'original': str(p), 'member': str(p), 'raw_sha256': sha(p.read_bytes()), 'raw_bytes': p.stat().st_size} for p in originals], 'reason': 'Preserve ignored log/raw whitespace/CRLF/blank-EOF payloads and root execution helpers losslessly; immutable originals remain in place. Metadata-only final packaging, no new mathematical/source/build verdict.'}, ensure_ascii=False, indent=2) + '\n')
mutable = [Path('runs/substantive_advances.jsonl'), Path('research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-normalizer.json'), Path('research-wiki/paper-contributions/GaussianComplexity/README.md')]
paths = sorted(set([p for p in files if p not in excluded] + mutable + [archive, manifest]))
subprocess.run(['git', 'add', '--', *map(str, paths)], check=True)
subprocess.run(['git', 'diff', '--cached', '--check'], check=True)
staged = subprocess.check_output(['git', 'diff', '--cached', '--name-only', '-z']).decode().strip('\0').split('\0')
for name in staged:
    p = Path(name)
    assert p in mutable or any(p.is_relative_to(root) for root in prefixes), name
    assert subprocess.check_output(['git', 'show', ':' + name]) == p.read_bytes(), name
for p in mutable: assert subprocess.check_output(['git', 'show', ':' + str(p)]) == p.read_bytes()
result = {'accepted_immutable_core': CORE, 'stage': 'FINAL_METADATA_ONLY_NO_FRESH_BUILD_CREDIT', 'staged_paths_before_this_result': len(staged), 'all_staged_bytes_match_live_exactly': True, 'mutable_ledger_frontier_README_staged_directly_and_exact': {str(p): sha(p.read_bytes()) for p in mutable}, 'frozen_originals_lossless_archive': str(archive), 'archive_sha256': sha(archive.read_bytes()), 'raw_originals_retained': len(originals), 'ignored_or_raw_unsafe_originals_excluded_from_direct_git_stage': [str(p) for p in excluded], 'no_new_sourceV_or_lifecycle_API': True, 'Goal_complete': False}
p = B / 'final-staging-readback.json'
assert not p.exists()
p.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
subprocess.run(['git', 'add', '--', str(p)], check=True)
assert subprocess.check_output(['git', 'show', ':' + str(p)]) == p.read_bytes()
subprocess.run(['git', 'diff', '--cached', '--check'], check=True)
print(json.dumps({'stage': result['stage'], 'staged_paths': len(staged) + 1, 'raw_originals_losslessly_retained': len(originals), 'unsafe_or_ignored_direct_stage_exclusions': len(excluded), 'index_bytes_exact': True, 'no_next_packet_or_foreign_path_staged': True}))
