# New target-law / norm-mean packet: phase1 raw-source cognition

Actor: the continuing distinct topology/binder/definition reviewer `/root/detector_topology`, new output identity `tl_tc_7c319d`. This is a raw-source checkpoint, before this packet's exact types, definitions, graph/delta, implementation or root planning are exposed. It is **not** a fresh blank-context review. Prior exposure is recorded separately and retained; no earlier cognition or verdict is edited.

Only the pinned original mathematical source was newly read: *On Complexity of Gaussian Sampling*, arXiv:2610.20492v1 HTML, 951991 bytes, SHA256 `6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915`. Complete raw snippets newly preserved/read are §2, §4.1, the target-moments paragraph/Lemma4.5/coordinate-transfer paragraph in §4.2, all C.3, and all C.4. The first two and C.4's earlier paragraphs provide the target definition, matrix conventions, hard-family construction and positivity context for the requested anchors. This expands only raw-paper context; it does not open another record.

## Source objects and standing domains

The source uses real Euclidean `R^d`, Euclidean norm, real symmetric precision matrices and the full orthogonal group O(d). The target at a fixed input is `π_A=N(0,A^{-1})`, with potential `f_A(x)=x^T A x/2`; A is precision and A⁻¹ is covariance. Neither A nor Λ is itself the covariance. A centered Gaussian's vector mean is zero; the scalar M below is its **mean squared norm**, not its vector mean.

In Eq.(11), integer d≥2 and real κ≥2 determine indices i=1,…,d, midpoint angles `θ_i=(i−1/2)π/d`, positive eigenvalues `λ_i=(κ+1)/2+((κ−1)/2)cosθ_i`, and precision `Λ=diag λ_i`. For a fixed full orthogonal O, set `A(O)=OΛOᵀ`. A zero-based coordinate encoding must use `(i+1/2)π/d`. C.4 first shows `0<θ_i<π`, hence `1<λ_i<κ`, then `I≼A≼κI`; in particular Λ,A are positive definite and invertible. Positivity/invertibility are consequences of the literal family, not extra source assumptions to add for convenience to an actual-family theorem.

The hard experiment samples O Haar independently of the algorithm seed. That randomness is relevant to the complete lower-bound experiment, not needed for the deterministic distribution identity attached to each fixed O. Both determinant components are in the carrier; SO(d) would be an unjustified restriction.

## Exact source law statement and its probability spaces

`S4.SS2.SSS0.Px3.p2.1` states: for an exact sample `Y|O~π_A`, `U=OᵀY` has law `N(0,Λ^{-1})`, with `‖Y‖²=‖U‖²` and `YᵀOD_nOᵀY=UᵀD_nU`. Thus the target moments in Lemma4.5 transfer to the actual target.

For a **fixed** O, this is a statement about measures on Euclidean Borel space: if `ν_Λ=N(0,Λ^{-1})` and `R_O(z)=Oz`, the natural complete law bridge is `(R_O)_*ν_Λ=π_{A(O)}`, equivalently `(Oᵀ)_*π_{A(O)}=ν_Λ`. The source's printed direction applies the inverse coordinate map to an exact target; the forward pushforward formulation is its equivalent deterministic law adapter. The covariance calculation behind it is `OΛ^{-1}Oᵀ=A(O)^{-1}`, using OᵀO=OOᵀ=I and the same O on both sides, plus linear transformation of centered Gaussian laws. Mean remains zero.

This is an equality of full measures, not equality at one detector event and not merely matching a scalar expectation. It should work for every fixed O in the literal family. Its deterministic matrix/covariance content supplies a stronger pointwise family than an unspecified a.e. representative of a conditional distribution.

The source also uses **random** O and a target draw conditional on O. To turn a pointwise measure family into a claim on an actual joint experiment, one must specify/measurably realize the Gaussian kernel `O↦π_{A(O)}` and the joint law. Conditional-law identities ordinarily have an a.e.-O interpretation relative to the conditioning law unless a particular pointwise kernel version is explicitly chosen. A fixed-O theorem alone does not define this joint experiment, certify conditional-law representatives, prove Haar/seed independence, or license swapping all conditional/unconditional probabilities. Once an actual measurable joint law with the displayed conditional target is given, the constant latent conditional law can be averaged; independence conclusions require that joint-law reasoning and must not be inferred just from an isolated measure symbol.

Algorithm output `ρ_A^Alg`, its private seed and the law-preserving Krylov extension are different experiments. They supply no inputs to this fixed-O target-law/norm-mean bridge. The source's target expectation is over the Gaussian draw at a fixed input, not a Haar expectation and not an algorithm output expectation.

## Norm mean branch: exact identities and minimum route

Lemma4.5 defines `M=E‖U‖²` and `μ_n=E[UᵀD_nU]` under `U~N(0,Λ^{-1})`. The law's covariance and Gaussian finite second moments give, at `A3.SS3.p4.1` / Ex140,

`E U_i²=1/λ_i`, `M=Σ_i 1/λ_i=tr(Λ^{-1})`.

Only finite linearity of expectation and the norm-square coordinate identity are needed for M; coordinate independence is not needed to sum those second moments. Gaussian integrability/finite second moments must be established internally when working with actual measures or integrals, rather than supplied as an unexplained extra premise. In particular an integral that is totalized off its integrability domain does not by its notation alone certify the source expectation.

For each fixed source O and exact target Y, the full target law adapter plus orthogonal norm preservation yields

`E_{π_A}‖Y‖²=E_{ν_Λ}‖U‖²=M=tr(Λ^{-1})`.

Equivalently the general centered-Gaussian second-moment identity gives `E_{π_A}‖Y‖²=tr(A^{-1})`, and orthogonal conjugation/trace invariance identifies that trace with `trΛ^{-1}`. The source paragraph transports the latent moments through coordinates. A direct target-trace argument can be a valid alternative implementation route, but it should not be falsely conjoined as an additional necessary author route or a new source premise.

C.3 gives the stronger exact scalar mean formula, including the finite-grid correction. With `r=(√κ−1)/(√κ+1)∈(0,1)`, FactC.7 expands the inverse spectrum into cosine modes with absolute/uniform convergence. The midpoint-grid alias sum is `Σ_i cos(kθ_i)=d(−1)^a` for k=2ad and zero otherwise. Summing the inverse expansion's constant mode at `A3.SS3.p5` / EGx15 gives

`M=(d/√κ)(1−r^{2d})/(1+r^{2d})`.

It is not exactly d/√κ at finite d. The displayed denominator is positive, M>0, and M≤d/√κ. The Gaussian law and trace/finite sum identity identify which expectation this scalar formula describes; the trigonometric sum alone is not an actual-law identification.

The combined source lemma states `1≤n<d` because it also evaluates the frequency-n cosine mean. M and the literal target covariance do not depend on n. For a norm-mean-only auxiliary statement, a free frequency assumption or query-budget condition would not be a needed premise merely because it appears in the combined printed lemma. The extra `d−n≥√κ` condition belongs to the normalized cosine-bias estimate, not the target law or M identity.

The variance calculations in C.3 p8 additionally use independent Gaussian coordinates and fourth moments. The sign/bias calculations in p9–p11 use n<d, positive r and finite-grid terms. These remain separate descendants; target law/norm mean alone does not give their full statements or a high-probability acceptance result.

## Partition function branch is distinct

At C.4 p3.1 / Ex160, Gaussian integration gives

`Z_A=(2π)^{d/2}(det A)^{-1/2}=(2π)^{d/2}(detΛ)^{-1/2}`.

This Z is the normalization of `exp(−xᵀAx/2)` against Lebesgue measure. It is not M, not the zero vector mean and not a probability or a normalizer for a second-moment integral. Its O-independence follows from orthogonal determinant invariance. Sharing determinant/partition function does not identify oriented Gaussian laws; covariance orientation still matters. This is a separate source use of positive definiteness and Gaussian integration, not a substitute for the full linear Gaussian pushforward bridge.

## Minimum source consumers and unexpanded background

1. **Literal family/admissibility:** Eq.(11), same-O rotation, C.4 positivity. Consumer: treating Λ⁻¹ and A⁻¹ as true Gaussian covariances and applying the target definition.
2. **Linear Gaussian covariance transport plus inverse conjugation:** consumer: §4.2 p2.1's `U=OᵀY` law, or the equivalent fixed-O forward pushforward measure identity. This is an author-used standard bridge, not a printed detailed covariance proof.
3. **Orthogonal norm/quadratic transport:** consumer: the same paragraph's norm equality and cosine-form equality. Norm mean uses the norm part; a detector polynomial identity is not needed just to identify the target Gaussian law or the norm mean.
4. **Actual Gaussian second moments and integrability:** consumer: C.3 p4.1's M finite sum/trace and its transfer to π_A. Do not add these as public actual-family premises if a concrete Gaussian is already the intended input.
5. **Inverse-spectrum expansion + midpoint-grid alias sums + legitimate finite-sum/series exchange + geometric sum:** consumer: C.3 p5's exact M scalar formula. The n-dependent product-to-sum/alias classes for μ_n are not all necessary for this M branch.
6. **Positive Gaussian density integration + determinant conjugation:** consumer: C.4 p3's partition function, separate from norm mean and law transport.

These identify the minimum mathematical background questions without importing a library proof direction. Characteristic functions, densities, square-root constructions or other library mechanisms may later implement the standard law bridge; the paper does not print such a route here, and no API/implementation choice is a source-author dependency merely because formalization uses it.

## Pending exact-type / definition / graph uncertainty checkpoint

The new exact signatures, names, public carriers and definition bodies are unseen. All new statement/binder/definition acceptance is therefore **HOLD awaiting the explicit next whitelist**. In particular I must later check whether an asserted law is a full measure equality or one event, whether the Gaussian argument denotes covariance or precision, forward versus inverse rotation, real Euclidean norm versus function sup norm, same-O inverse compatibility, full O(d), zero/totalized inverse semantics, and exact expectation/integrability interpretation.

Prior Detector-stage knowledge includes Mathlib Gaussian constructor/measure-map totalization and matrix-inverse/Euclidean wrapper definitions. It is declared prior exposure, not a newly read or independently checked definition for this packet. Any new use must pass the later definition-only audit. No new library/API source or target proof was read now. The old Detector event-equality/type/topology acceptance does not establish a full target law or norm mean; those were expressly outside that old boundary and remain unaccepted for this new packet.

The raw source supports the mathematical distinctions above, but cannot by itself establish what the unseen new interfaces actually claim or how a future graph routes them. No uncertainty requires pretending to be fresh: I can independently compare the raw mathematics with forthcoming types while candidly retaining my old context. Any requested source-blindness relative to the entire old Detector conversation would be unavailable and must stay explicitly disclaimed. No sourceV/Lean/proof/native/SAU/V/STAB/global credit is given.
