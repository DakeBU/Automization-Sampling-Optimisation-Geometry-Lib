#!/usr/bin/env python3
"""Invoke frozen owned native commands sequentially; stop on first actual failure."""
import hashlib
import json
import pathlib
import subprocess
import sys

OWN = pathlib.Path(__file__).resolve().parent

def main():
    assignment = json.loads((OWN / 'native-command-assignment.json').read_text())
    commands_file = OWN / assignment['commands']['path']
    assert hashlib.sha256(commands_file.read_bytes()).hexdigest() == assignment['commands']['sha256']
    commands = json.loads(commands_file.read_text())
    for label, command in commands.items():
        if label != 'lean-version':
            assert (OWN / 'native-output-initialized.json').is_file()
            argv = command['argv']
            if '-o' in argv:
                pathlib.Path(argv[argv.index('-o') + 1]).parent.mkdir(parents=True, exist_ok=True)
        print(json.dumps({'native_command_started': label, 'candidate': assignment['candidate_commit']}), flush=True)
        result = subprocess.run([sys.executable, str(OWN / 'native_runner.py'), label], cwd=OWN, env={'PATH': '/usr/bin:/bin', 'LC_ALL': 'C'}, stdin=subprocess.DEVNULL, check=False)
        if result.returncode:
            raise SystemExit(result.returncode)
    print(json.dumps({'all_native_commands_completed': True, 'command_count': len(commands)}), flush=True)

if __name__ == '__main__':
    main()
