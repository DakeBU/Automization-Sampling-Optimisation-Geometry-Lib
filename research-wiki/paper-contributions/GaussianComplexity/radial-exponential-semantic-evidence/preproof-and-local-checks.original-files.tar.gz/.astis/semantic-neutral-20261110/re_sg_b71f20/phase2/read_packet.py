from pathlib import Path
import json,hashlib,datetime,sys
BASE=Path(__file__).resolve().parent
P=Path('/Users/zhouhuanjian/ASTIS-GC/.astis/huanjian-gc-radial-exponential-20261110/selective-type-definition-packet.json')
b=P.read_bytes();digest=hashlib.sha256(b).hexdigest()
assert digest=='44cecb47245a0d1ab06d634f8b1dcd408c8368437e37cea1f0bde46fc2669ae3'
(BASE/'inputs').mkdir(exist_ok=True);(BASE/'execution').mkdir(exist_ok=True)
(BASE/'inputs'/'selective-type-definition-packet.json').write_bytes(b)
out=b.decode('utf-8')
receipt={'argv':sys.argv,'time_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'actual_status':0,'input_path':str(P),'input_bytes':len(b),'input_sha256':digest,'stdout':out,'stderr':'','outputs':['inputs/selective-type-definition-packet.json']}
(BASE/'execution'/'read-packet-execution.json').write_text(json.dumps(receipt,indent=2,ensure_ascii=False)+'\n')
print(out,end='')
