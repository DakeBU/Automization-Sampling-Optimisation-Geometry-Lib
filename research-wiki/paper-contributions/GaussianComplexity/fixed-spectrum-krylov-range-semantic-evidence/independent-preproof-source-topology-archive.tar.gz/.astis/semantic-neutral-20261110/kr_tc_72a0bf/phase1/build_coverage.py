from pathlib import Path
import json, re, html, hashlib
OUT=Path(__file__).parent
P=json.loads((OUT/'source_pins.json').read_text())
pins=P['pins'];byid={p['id']:p for p in pins}
S=Path(P['source']).read_bytes().decode('utf8')
units={
 'S4.SS1.p1':('NODE','hard-family-definitions','literal-grid-spectrum-and-rotated-Gaussian','The source fixes d>=2,kappa>=2, cosine nodes, diagonal spectrum and random rotation; the grid and affine slope feed the C.2 construction, while Haar rotation and target law are wider context.'),
 'S4.SS1.p2':('EXCLUDED','hard-family-information-context','context-only','Known spectrum/normalizer and unknown eigenbasis are algorithmic context, with no necessary parent role in the deterministic range or final algebra identities.'),
 'S4.Thmtheorem2.p1':('EXCLUDED','kappa-two-comparison','context-only','Remark compares later lower-bound tests and rates, not a proof ingredient of C.5, C.6 or Lemma 4.4.'),
 'S4.SS2.p1':('EXCLUDED','four-lemma-overview','navigation-only','Lists four peer roles; adjacency does not make target moments or admissibility necessary parents of the Krylov uniform bound.'),
 'S4.SS2.SSS0.Px1.p1':('NODE','external-krylov-route-context','context-only-external-citation','Cites [22, Lemma 9.2] for the deferred-rotation output representation; applies to algorithm-output context, not the proof of deterministic range(B)=K_q or Lemma 4.4.'),
 'S4.SS2.SSS0.Px1.p2':('NODE','krylov-definition','literal-definition','K_q spans Lambda^j g_a for a=1,...,q+1 and j=0,...,q; includes the zero power.'),
 'S4.Thmtheorem3.p1':('NODE','lemma-4-3-context','contextual-theorem','Almost-sure Krylov representation for q-query output with 2q+1<d; external source proof C.1 not read. It is used only when applying the uniform bound to output.'),
 'S4.SS2.SSS0.Px1.p3':('NODE','adaptive-coefficients-context','contextual-representation','q+1-th start handles output; degree-at-most-q coefficients may depend on entire experiment, explaining why the next theorem must be simultaneous.'),
 'S4.SS2.SSS0.Px2.p1':('NODE','weighted-cosine-definition','literal-definition-and-frequency-choice','n=2q+1 and D_n diagonal cosine weights; the frequency exceeds products of two degree-q cosine polynomials.'),
 'S4.Thmtheorem4.p1':('NODE','lemma-4-4-statement','source-anchor','Absolute C, source tau formula, independent standard Gaussian starts, 2q+1<d, tau<=1/2 and probability>=.99 of the simultaneous all-u bound.'),
 'S4.SS2.SSS0.Px2.p2':('NODE','cosine-span-precursor','representation-equivalence','Nonconstant affine spectrum permits an equivalent cosine generating family and explains kappa independence; proved explicitly in A3.SS2.p3.'),
 'S4.SS2.SSS0.Px2.p3':('NODE','output-application-context','contextual-application','Combines Lemmas 4.3 and 4.4 and orthogonality for X; consumer of the uniform theorem rather than its prerequisite.'),
 'S4.SS2.SSS0.Px3.p1':('EXCLUDED','target-moment-introduction','peer-context','Introduces the separate target-moment calculation; not a C.2 input.'),
 'S4.Thmtheorem5.p1':('EXCLUDED','lemma-4-5-moments','peer-theorem','Target Gaussian expectation/variance identities, including split table S4.EGx1/S4.Ex16; no necessary parent edge into range, Gram concentration or Lemma 4.4.'),
 'S4.Thmtheorem5.p2':('EXCLUDED','lemma-4-5-ratio','peer-theorem','Additional target mean-ratio estimate for later testing; no necessary parent edge into C.2.'),
 'S4.SS2.SSS0.Px3.p2':('EXCLUDED','target-rotation-context','peer-application','Transfers target moments under Y|O and U=O^T Y; not an input to C.2.'),
 'S4.SS2.SSS0.Px4.p1':('EXCLUDED','admissibility-introduction','peer-context','Introduces C.4 proof of the separate admissibility lemma; no C.2 input.'),
 'S4.Thmtheorem6.p1':('EXCLUDED','lemma-4-6-admissibility','peer-theorem','Rotated spectral Loewner bounds are peer inputs for the wider lower bound, not parents of C.2.'),
 'A3.SS2.p1':('NODE','c2-matrix-construction','literal-definitions-and-Gaussian-reindexing','r=q+1,n=2q+1,t_i with constant mode 1 and higher modes sqrt(2),gamma_i, row_i(B)=d^(-1/2)(gamma_i tensor t_i)^T; independent Gaussian row law follows by array reindexing.'),
 'A3.SS2.p2':('NODE','c2-strategy','substantive-proof-plan','Names coefficient representation, energy/weighted-form pullback and the two different matrix expectations; all are represented later, not collapsed into one assumed bound.'),
 'A3.Thmtheorem5.p1':('NODE','fact-c5-statement','compound-source-fact','Separate conjuncts: range equality, two expectations, t norm, unweighted t sum and weighted t sum. Shared label does not make every conjunct depend on every other.'),
 'A3.SS2.p3':('NODE','c5-range-proof','deterministic-polynomial-generating-list-change','Chebyshev cosine identity, nonzero affine slope, triangular invertible polynomial coefficient transform, nonzero column normalization and range/column-span correspondence prove range(B)=K_q.'),
 'A3.SS2.p4':('NODE','c5-cosine-sum','telescoping-trigonometric-identity','For integer 0<|k|<2d, a sine telescoping sum and nonzero sine factor prove sum_i cos(k theta_i)=0; does not cover k=0.'),
 'A3.SS2.p5':('NODE','c5-unweighted-t-sum','entrywise-orthogonality','Constant-coordinate entries plus product-to-sum and j=k versus j!=k cases yield sum t_i t_i^T=dI; split table Ex91--93 included.'),
 'A3.SS2.p6':('NODE','c5-unweighted-Gram-expectation','finite-expectation-and-tensor-algebra','E gamma_i gamma_i^T=I_r and unweighted t sum give E B^T B=I_(r^2); split table Ex94--95 included.'),
 'A3.SS2.p7':('NODE','c5-weighted-cancellation','frequency-bound-and-triple-product-to-sum','All n+/-j+/-k are in [1,2d); triple product-to-sum gives weighted t sum zero, then row covariance gives weighted Gram expectation zero; all split-table pieces Ex97--101 included.'),
 'A3.SS2.p8':('NODE','c5-t-norm','elementary-norm-bound','1+2 sum cos^2<=1+2q<=2r, valid also q=0.'),
 'A3.SS2.p9':('NODE','c6-strategy','substantive-uniformity-bridge','Announces simultaneous operator norms control ||Bc||^2 and c^T B^T D_n Bc for every coefficient vector.'),
 'A3.Thmtheorem6.p1':('NODE','fact-c6-statement','simultaneous-matrix-concentration','One event probability>=.995 bounds both Gram deviation and weighted Gram operator norms by source tau.'),
 'A3.SS2.p10':('NODE','c6-truncation-event','Gaussian-mgf-Markov-and-union','R_i norm square, L cutoff, exp moment, Markov tail and union bound give T with probability>=.999.'),
 'A3.SS2.p11':('NODE','c6-truncation-tail-bias','tail-integral-expectation','Ex106 split table integrates the same tail to bound the discarded first moment.'),
 'A3.SS2.p12':('NODE','c6-truncated-means','radial-symmetry-and-C5-identities','Independent Y_i; shared scalar a from radial symmetry; bounds on 1-a; C.5 t sums give sum E Y_i=aI and weighted expectation zero.'),
 'A3.SS2.p13':('NODE','c6-summand-norm','rank-one-tensor-norm-and-centering','Using t norm gives bounds for Y_i,EY_i,Z_i, and fixed cosine-weighted Z_i; defines R_*.'),
 'A3.SS2.p14':('NODE','c6-variance','Gaussian-fourth-moments-and-PSD-algebra','Fourth moment, outer-product square identities, positive truncation removal, sum t t^T=dI, centered second moment and cosine contraction give variance v_* for both sequences; split Ex115--117 included.'),
 'A3.SS2.p15':('NODE','c6-external-matrix-Bernstein','external-result-no-numbered-citation-here','Independent centered self-adjoint summands with R_*,v_* invoke two-sided bounded matrix Bernstein with ambient prefactor 2r^2; same theorem applies to cosine-weighted sequence.'),
 'A3.SS2.p16':('NODE','c6-concentration-probability','threshold-algebra-and-union','z,Delta choice, direct expansion and union bound give simultaneous centered event probability>=.996.'),
 'A3.SS2.p17':('NODE','c6-return-to-original-matrices','truncation-intersection-and-bias','On T original/truncated sums agree; unweighted shift -(1-a)I, weighted shift zero; intersection gives probability>=.995.'),
 'A3.SS2.p18':('NODE','c6-absolute-constant-simplification','integer-parameter-and-absolute-estimate-bookkeeping','2q+1<d yields d>=2,2r<=d, log/cutoff bounds; Delta+(1-a) absorbed by tau for absolute C, with split Ex127--128 covered.'),
 'A3.SS2.p19':('NODE','lemma-4-4-final-proof','range-witness-and-deterministic-quadratic-pullback','Matrix event AND range witness AND energy/weighted quadratic pullbacks AND operator-norm estimates AND tau<=1/2 imply uniform all-u bound. Ex130/131 inline math inside table is substantive. Probability .995 weakened to .99.'),
}
assert {p['id'] for p in pins if p['tag']=='div' and re.search(r'\.p\d+$',p['id'])} == set(units)
theorems={
 'S4.Thmtheorem2':('EXCLUDED','remark-4-2-wrapper','Remark is contextual comparison; its substantive paragraph separately excluded with an explicit scope reason.'),
 'S4.Thmtheorem3':('NODE','lemma-4-3-context','Contextual source theorem whose exact mathematical statement is covered by S4.Thmtheorem3.p1.'),
 'S4.Thmtheorem4':('NODE','lemma-4-4-statement','Source anchor whose exact mathematical statement is covered by S4.Thmtheorem4.p1.'),
 'S4.Thmtheorem5':('EXCLUDED','lemma-4-5-peer-wrapper','Peer target-moment theorem; both substantive paragraphs explicitly excluded from C.2 dependencies.'),
 'S4.Thmtheorem6':('EXCLUDED','lemma-4-6-peer-wrapper','Peer admissibility theorem; substantive paragraph explicitly excluded from C.2 dependencies.'),
 'A3.Thmtheorem5':('NODE','fact-c5-statement','Compound source fact with separately covered conjuncts and proof branches.'),
 'A3.Thmtheorem6':('NODE','fact-c6-statement','Simultaneous matrix concentration source fact with every proof paragraph covered.'),
}
rows=[]
for p in pins:
 x=p['id']
 owners=[u for u in units if byid[u]['char_start']<=p['char_start'] and p['char_end_exclusive']<=byid[u]['char_end_exclusive']]
 if owners:
  owner=min(owners,key=lambda u:byid[u]['char_end_exclusive']-byid[u]['char_start'])
  disposition,unit,kind,reason=units[owner]
 elif x in theorems:
  disposition,unit,reason=theorems[x];owner=x;kind='theorem-or-remark-container'
 else:
  disposition='EXCLUDED';unit='structural-label';owner=None;kind='formatting-or-section-structure'
  reason='Section/proof/paragraph wrapper or heading label. All substantive mathematical paragraph and table contents are separately covered; this label adds no premise or proof edge.'
  if p['tag']=='math':
   assert x=='S4.Thmtheorem2.m1',x
   unit='remark-4-2-heading';kind='context-only-heading-math';reason='The kappa=2 expression in the Remark heading is a contextual label, not a proof ingredient of C.2.'
 rows.append({'source_id':x,'disposition':disposition,'source_unit':unit,'kind':kind,'owner_paragraph_or_statement':owner,'reason':reason,'raw_pin':p})
assert len(rows)==520 and len({x['source_id'] for x in rows})==len(rows)
maths=[x for x in rows if x['raw_pin']['tag']=='math']
assert len(maths)==252
table_rows=[x for x in rows if x['raw_pin']['tag'] in {'table','tbody'}]
assert all(x['owner_paragraph_or_statement'] for x in table_rows)
(OUT/'coverage.json').write_text(json.dumps({'scope':'S4.SS1,S4.SS2,A3.SS2 only','status':'independent baseline before candidate-seal and SG exposure; not acceptance','all_ids_explicitly_disposed':True,'id_elements':len(rows),'math_elements':len(maths),'table_and_tbody_elements':len(table_rows),'counts_are_coverage_bookkeeping_not_mathematical_progress':True,'records':rows},ensure_ascii=False,indent=2)+'\n')
(OUT/'coverage.tsv').write_text('source_id\tdisposition\tsource_unit\towner\treason\n'+'\n'.join('\t'.join([x['source_id'],x['disposition'],x['source_unit'],x['owner_paragraph_or_statement'] or '',x['reason']]) for x in rows)+'\n')
checks=[]
for p in pins:
 if p['tag']!='math':continue
 raw=S[p['char_start']:p['char_end_exclusive']]
 ann=re.findall(r'<annotation encoding="application/x-tex">(.*?)</annotation>',raw,re.S)
 checks.append({'id':p['id'],'alt_matches_tex_annotation':len(ann)==1 and html.unescape(ann[0])==p['alttext'],'annotation_count':len(ann),'display':p['display']})
(OUT/'math_encoding_check.json').write_text(json.dumps(checks,indent=2)+'\n')
assert all(x['alt_matches_tex_annotation'] for x in checks)
print(json.dumps({'all_ids_disposed':len(rows),'math_ids':len(maths),'table_and_tbody_ids':len(table_rows),'missing':[],'alttext_annotation_mismatch':[],'coverage_sha256':hashlib.sha256((OUT/'coverage.json').read_bytes()).hexdigest()},indent=2))
