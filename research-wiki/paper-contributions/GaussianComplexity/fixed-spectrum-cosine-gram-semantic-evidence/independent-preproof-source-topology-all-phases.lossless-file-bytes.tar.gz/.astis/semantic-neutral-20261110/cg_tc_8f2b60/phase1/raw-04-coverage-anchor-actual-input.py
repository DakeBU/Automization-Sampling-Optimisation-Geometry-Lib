from pathlib import Path
from bs4 import BeautifulSoup
import json
base=Path('.astis/semantic-neutral-20261110/cg_tc_8f2b60/phase1')
spans={x['id']:x for x in json.loads((base/'source-spans-complete.json').read_text())}
s=BeautifulSoup((base/'A3.SS2.html').read_bytes(),'html.parser')
lines=[]
for tag in s.find_all(id=True):
 if 'ltx_para' in tag.get('class',[]) or 'ltx_theorem' in tag.get('class',[]):
  key=tag['id']; item=spans[key]
  lines.append(json.dumps({'id':key,'source_lines':[item['line_start'],item['line_end']],'byte_span':[item['byte_start'],item['byte_end_exclusive']],'sha256':item['sha256'],'display_ids':[x.get('id') for x in tag.find_all(class_='ltx_equation') if x.get('id')]},ensure_ascii=False))
for key in ['S4.SS1','S4.SS2.SSS0.Px1','S4.SS2.SSS0.Px2']:
 tag=BeautifulSoup((base/(key+'.html')).read_bytes(),'html.parser')
 lines.append('SOURCE CONTEXT ANCHORS '+key+' '+json.dumps([(x.name,x.get('id')) for x in tag.find_all(id=True) if 'ltx_para' in x.get('class',[]) or 'ltx_equation' in x.get('class',[])],ensure_ascii=False))
out='\n'.join(lines)+'\n';(base/'raw-04-coverage-anchor-output.txt').write_text(out);print(out)
