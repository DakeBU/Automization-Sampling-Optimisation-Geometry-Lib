"""Local raw-only preservation. No repository implementation is imported."""
from pathlib import Path
from html.parser import HTMLParser
from hashlib import sha256
import json
import shutil

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[2]
SOURCE = REPO / '.astis/huanjian-resume-20261103/2610.20492v1.html'
EXPECTED = '6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
raw = SOURCE.read_bytes()
assert len(raw) == 951991 and sha256(raw).hexdigest() == EXPECTED
source = raw.decode('utf-8')

class Index(HTMLParser):
    def __init__(self, text):
        super().__init__(convert_charrefs=True)
        self.text = text
        self.lines = [0]
        for n, c in enumerate(text):
            if c == '\n':
                self.lines.append(n + 1)
        self.stack, self.nodes = [], {}
    def pos(self):
        line, col = self.getpos()
        return self.lines[line - 1] + col
    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        item = {'tag': tag, 'start': self.pos(), 'attrs': a}
        if a.get('id'):
            assert a['id'] not in self.nodes
            self.nodes[a['id']] = item
        if tag not in {'area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr'}:
            self.stack.append(item)
        else:
            item['end'] = self.pos() + len(self.get_starttag_text())
    def handle_startendtag(self, tag, attrs):
        a = dict(attrs)
        item = {'tag': tag, 'start': self.pos(), 'end': self.pos() + len(self.get_starttag_text()), 'attrs': a}
        if a.get('id'):
            assert a['id'] not in self.nodes
            self.nodes[a['id']] = item
    def handle_endtag(self, tag):
        for n in range(len(self.stack) - 1, -1, -1):
            if self.stack[n]['tag'] == tag:
                end = self.text.index('>', self.pos()) + 1
                for item in self.stack[n:]:
                    item['end'] = end
                del self.stack[n:]
                return

class MathAlt(HTMLParser):
    """Preserve decoded math alttext verbatim; normalize prose whitespace only."""
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.output, self.math_depth, self.skip_depth = [], 0, 0
        self.citations = set()
    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if self.math_depth:
            self.math_depth += 1
            return
        if tag == 'math':
            self.output.append(' $' + a.get('alttext', '[MISSING ALTTEXT]') + '$ ')
            self.math_depth = 1
            return
        if tag in {'script', 'style'}:
            self.skip_depth += 1
            return
        if tag == 'a' and a.get('href','').startswith('#bib'):
            self.citations.add(a['href'][1:])
        if tag in {'section','div','p','h1','h2','h3','h4','h5','h6','table','tr','li','br'}:
            self.output.append('\n')
        if a.get('id') and tag in {'section','div','table','figure'}:
            self.output.append('\n[' + a['id'] + ']\n')
    def handle_startendtag(self, tag, attrs):
        if tag == 'br' and not self.math_depth:
            self.output.append('\n')
    def handle_endtag(self, tag):
        if self.math_depth:
            self.math_depth -= 1
            return
        if tag in {'script','style'} and self.skip_depth:
            self.skip_depth -= 1
        if tag in {'section','div','p','h1','h2','h3','h4','h5','h6','table','tr','li'}:
            self.output.append('\n')
    def handle_data(self, data):
        if not self.math_depth and not self.skip_depth:
            self.output.append(data)
    def rendered(self):
        # Do not split or normalize math alttext. Only trim structural blank lines.
        text = ''.join(self.output)
        out = []
        for line in text.splitlines():
            if line.strip():
                out.append(line.strip())
        return '\n'.join(out) + '\n'

index = Index(source)
index.feed(source)
(ROOT / 'raw').mkdir(exist_ok=True)
(ROOT / 'rendered').mkdir(exist_ok=True)
(ROOT / 'procedure').mkdir(exist_ok=True)
anchors = ['S2','S4.SS1','S4.SS2','S4.SS2.SSS0.Px3','A3.SS3','A3.SS4']
inventory = []
citations = set()
for anchor in anchors:
    node = index.nodes[anchor]
    selected = source[node['start']:node['end']]
    selected_raw = selected.encode('utf-8')
    output = ROOT / 'raw' / (anchor + '.html')
    output.write_bytes(selected_raw)
    render = MathAlt()
    render.feed(selected)
    (ROOT / 'rendered' / (anchor + '.txt')).write_text(render.rendered())
    citations.update(render.citations)
    inventory.append({'id':anchor, 'tag':node['tag'], 'byte_start_inclusive':len(source[:node['start']].encode('utf-8')), 'byte_end_exclusive':len(source[:node['end']].encode('utf-8')), 'bytes':len(selected_raw), 'sha256':sha256(selected_raw).hexdigest()})
for anchor in sorted(citations):
    node = index.nodes[anchor]
    selected = source[node['start']:node['end']]
    selected_raw = selected.encode('utf-8')
    (ROOT / 'raw' / (anchor + '.html')).write_bytes(selected_raw)
    render = MathAlt()
    render.feed(selected)
    (ROOT / 'rendered' / (anchor + '.txt')).write_text(render.rendered())
    inventory.append({'id':anchor, 'tag':node['tag'], 'byte_start_inclusive':len(source[:node['start']].encode('utf-8')), 'byte_end_exclusive':len(source[:node['end']].encode('utf-8')), 'bytes':len(selected_raw), 'sha256':sha256(selected_raw).hexdigest()})
procedure = ['AGENTS.md','docs/contributor-codex-contract.md','docs/theorem-publication-protocol.md','docs/proof-digestion-protocol.md','docs/evidence-routed-memory-protocol.md','docs/samplewiki-reader-navigation.md','.agents/skills/astis-semantic-roundtrip/SKILL.md']
for path in procedure:
    dst = ROOT / 'procedure' / path
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(REPO / path, dst)
(ROOT / 'source_inventory.json').write_text(json.dumps({'source_path':str(SOURCE),'source_bytes':len(raw),'source_sha256':EXPECTED,'selection_method':'HTMLParser tag bounds; UTF-8 byte-for-byte source slices; no DOM serialization','rendering_method':'decoded math alttext replaces entire MathML subtree; decoded prose, structural ID labels; no inferred mathematics','subtrees':inventory},indent=2)+'\n')
print(json.dumps({'selected':inventory,'citations':sorted(citations)},indent=2))
