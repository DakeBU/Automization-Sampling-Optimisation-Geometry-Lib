import Mathlib.Analysis.SpecialFunctions.Pow.Asymptotics
import Mathlib.Tactic
open Filter Asymptotics
noncomputable section

private theorem threshold_envelope {C δ κ : ℝ} (hC : 0 ≤ C)
    (hδ0 : 0 ≤ δ) (hδ1 : δ ≤ 1) (d q : ℕ)
    (hd : 1 ≤ (d : ℝ)) (hlog : 1 ≤ Real.log (d : ℝ))
    (hκ : 0 ≤ κ) (hκcap : κ ≤ (d : ℝ) ^ (1 - δ))
    (hq : (q : ℝ) ≤ (δ / 256) * Real.sqrt κ * Real.log (d : ℝ)) :
    C * (((q : ℝ) + 1) * Real.sqrt (Real.log (d : ℝ) / (d : ℝ)) +
      (((q : ℝ) + 1) * ((q : ℝ) + 1 + Real.log (d : ℝ)) * Real.log (d : ℝ)) / (d : ℝ))
      ≤ 8 * C * (d : ℝ) ^ (-δ / 2) * (Real.log (d : ℝ)) ^ 3 := by
  let x : ℝ := d
  let L : ℝ := Real.log x
  let R : ℝ := x ^ ((1 - δ) / 2)
  let A : ℝ := (q : ℝ) + 1
  change C * (A * Real.sqrt (L / x) + A * (A + L) * L / x) ≤
    8 * C * x ^ (-δ / 2) * L ^ 3
  have hx1 : 1 ≤ x := hd
  have hx : 0 < x := by linarith
  have hL1 : 1 ≤ L := hlog
  have hL0 : 0 ≤ L := by linarith
  have hR0 : 0 ≤ R := Real.rpow_nonneg hx.le _
  have hR1 : 1 ≤ R := by
    dsimp [R]
    exact Real.one_le_rpow hx1 (by linarith)
  have hs : Real.sqrt κ ≤ R := by
    calc
      _ ≤ Real.sqrt (x ^ (1 - δ)) := Real.sqrt_le_sqrt hκcap
      _ = R := by
        rw [Real.sqrt_eq_rpow, ← Real.rpow_mul hx.le]
        congr 1
        ring
  have hqR : (q : ℝ) ≤ R * L := by
    calc
      _ ≤ (δ / 256) * Real.sqrt κ * L := hq
      _ ≤ 1 * R * L := by gcongr; linarith
      _ = R * L := by ring
  have hRL : 1 ≤ R * L := by
    calc
      1 ≤ 1 * L := by linarith
      _ ≤ R * L := mul_le_mul_of_nonneg_right hR1 hL0
  have hA : A ≤ 2 * R * L := by dsimp [A]; linarith
  have hsum : A + L ≤ 3 * R * L := by
    have hLR : L ≤ R * L := by nlinarith
    linarith
  have hsL : Real.sqrt L ≤ L := (Real.sqrt_le_iff).2 ⟨hL0, by nlinarith⟩
  have hsdiv : Real.sqrt (L / x) ≤ L / Real.sqrt x := by
    rw [Real.sqrt_div hL0]
    exact div_le_div_of_nonneg_right hsL (Real.sqrt_nonneg _)
  have hRdiv : R / Real.sqrt x = x ^ (-δ / 2) := by
    rw [Real.sqrt_eq_rpow, ← Real.rpow_sub hx]
    congr 1
    ring
  have hR2div : R ^ 2 / x = x ^ (-δ) := by
    have he : R ^ 2 = x ^ (((1 - δ) / 2) * 2) := by
      dsimp [R]
      rw [Real.rpow_mul hx.le]
      norm_num
    rw [he, ← Real.rpow_sub_one (ne_of_gt hx)]
    congr 1
    ring
  have hLpow : L ^ 2 ≤ L ^ 3 := by
    calc
      _ ≤ L ^ 2 * L := le_mul_of_one_le_right (sq_nonneg L) hL1
      _ = L ^ 3 := by ring
  have hfirst : A * Real.sqrt (L / x) ≤ 2 * x ^ (-δ / 2) * L ^ 3 := by
    calc
      _ ≤ (2 * R * L) * (L / Real.sqrt x) := by gcongr
      _ = 2 * (R / Real.sqrt x) * L ^ 2 := by ring
      _ = 2 * x ^ (-δ / 2) * L ^ 2 := by rw [hRdiv]
      _ ≤ _ := mul_le_mul_of_nonneg_left hLpow (by positivity)
  have hsecond : A * (A + L) * L / x ≤ 6 * x ^ (-δ / 2) * L ^ 3 := by
    calc
      _ ≤ (2 * R * L) * (3 * R * L) * L / x := by gcongr
      _ = 6 * (R ^ 2 / x) * L ^ 3 := by ring
      _ = 6 * x ^ (-δ) * L ^ 3 := by rw [hR2div]
      _ ≤ _ := by
        have hp : x ^ (-δ) ≤ x ^ (-δ / 2) :=
          Real.rpow_le_rpow_of_exponent_le hx1 (by linarith)
        exact mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_left hp (by norm_num))
          (pow_nonneg hL0 3)
  calc
    _ ≤ C * (2 * x ^ (-δ / 2) * L ^ 3 + 6 * x ^ (-δ / 2) * L ^ 3) :=
      mul_le_mul_of_nonneg_left (add_le_add hfirst hsecond) hC
    _ = _ := by ring

private theorem eventual_threshold_power_small (C B : ℝ) (hC : 0 < C) (hB : 0 < B)
    {δ : ℝ} (hδ0 : 0 < δ) (hδ1 : δ < 1) :
  ∃ D : ℕ, ∀ d : ℕ, D ≤ d → ∀ κ : ℝ, 2 ≤ κ →
    κ ≤ (d : ℝ) ^ (1 - δ) → ∀ q : ℕ,
    (q : ℝ) ≤ (δ / 256) * Real.sqrt κ * Real.log (d : ℝ) →
    let τ : ℝ := C * (((q : ℝ) + 1) * Real.sqrt (Real.log (d : ℝ) / (d : ℝ)) +
      (((q : ℝ) + 1) * ((q : ℝ) + 1 + Real.log (d : ℝ)) * Real.log (d : ℝ)) / (d : ℝ))
    0 ≤ τ ∧ τ ≤ (B / 4) * (d : ℝ) ^ (-δ / 4) := by
  have hlo : (fun d : ℕ => Real.log (d : ℝ) ^ (3 : ℕ)) =o[atTop]
      (fun d : ℕ => (d : ℝ) ^ (δ / 4)) := by
    simpa only [Function.comp_def, Real.rpow_ofNat] using
      (isLittleO_log_rpow_rpow_atTop (3 : ℝ) (by linarith : 0 < δ / 4)).comp_tendsto
        tendsto_natCast_atTop_atTop
  have heps : 0 < B / (32 * C) := by positivity
  have hlogevent : ∀ᶠ d : ℕ in atTop, 1 ≤ Real.log (d : ℝ) :=
    (Real.tendsto_log_atTop.comp tendsto_natCast_atTop_atTop).eventually
      (eventually_ge_atTop 1)
  have hev : ∀ᶠ d : ℕ in atTop,
      1 ≤ d ∧ 1 ≤ Real.log (d : ℝ) ∧
      Real.log (d : ℝ) ^ (3 : ℕ) ≤ (B / (32 * C)) * (d : ℝ) ^ (δ / 4) := by
    filter_upwards [hlo.def heps, hlogevent, eventually_ge_atTop (1 : ℕ)] with d hd hl hd1
    have hl0 : 0 ≤ Real.log (d : ℝ) := by linarith
    refine ⟨hd1, hl, ?_⟩
    simpa only [Real.norm_eq_abs, abs_of_nonneg (pow_nonneg hl0 3),
      abs_of_nonneg (Real.rpow_nonneg (Nat.cast_nonneg d) _)] using hd
  rcases eventually_atTop.1 hev with ⟨D, hD⟩
  refine ⟨D, ?_⟩
  intro d hd κ hκ hκcap q hq
  rcases hD d hd with ⟨hd1, hlog, hsmall⟩
  have hd1real : (1 : ℝ) ≤ (d : ℝ) := by exact_mod_cast hd1
  have hdpos : 0 < (d : ℝ) := by linarith
  have hlog0 : 0 ≤ Real.log (d : ℝ) := by linarith
  constructor
  · positivity
  · have he := threshold_envelope hC.le hδ0.le hδ1.le d q hd1real hlog
      (by linarith : 0 ≤ κ) hκcap hq
    have hp : (d : ℝ) ^ (-δ / 2) * (d : ℝ) ^ (δ / 4) =
        (d : ℝ) ^ (-δ / 4) := by
      rw [← Real.rpow_add hdpos]
      congr 1
      ring
    have hc : 8 * C * (B / (32 * C)) = B / 4 := by
      field_simp [ne_of_gt hC] <;> ring
    calc
      _ ≤ 8 * C * (d : ℝ) ^ (-δ / 2) * Real.log (d : ℝ) ^ 3 := he
      _ ≤ 8 * C * (d : ℝ) ^ (-δ / 2) *
          ((B / (32 * C)) * (d : ℝ) ^ (δ / 4)) :=
        mul_le_mul_of_nonneg_left hsmall (by positivity)
      _ = (8 * C * (B / (32 * C))) *
          ((d : ℝ) ^ (-δ / 2) * (d : ℝ) ^ (δ / 4)) := by ring
      _ = _ := by rw [hc, hp]
