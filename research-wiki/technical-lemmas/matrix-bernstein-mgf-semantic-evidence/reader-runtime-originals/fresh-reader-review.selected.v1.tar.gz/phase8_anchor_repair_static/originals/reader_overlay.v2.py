"""Presentation-only overlay, scoped to the new MGF reader in an isolated tree."""
from html import escape
from pathlib import Path

ITEM = 'huanjian-matrix-bernstein-mgf'
PFILE = 'AutoSamplingTheory/TechnicalLemmas/Probability/MatrixBernsteinMgf.lean'
TFILE = 'Tests/GaussianComplexityBernsteinWeightedMgf.lean'

SCOPED_CSS = r'''
/* Isolated MGF candidate only; no production/global stylesheet is changed. */
body[data-mgf-preview="huanjian-matrix-bernstein-mgf"][data-preview-variant="candidate"] main,
body[data-mgf-preview="huanjian-matrix-bernstein-mgf"][data-preview-variant="candidate"] .proof-reader,
body[data-mgf-preview="huanjian-matrix-bernstein-mgf"][data-preview-variant="candidate"] .reader-step-body {
  min-width: 0; max-width: 100%; box-sizing: border-box;
}
body[data-mgf-preview="huanjian-matrix-bernstein-mgf"] .mgf-preview-nav {
  display: flex; flex-wrap: wrap; gap: .55rem 1.2rem; margin: 0 0 1.2rem;
  font-size: .9rem; overflow-wrap: anywhere;
}
body[data-mgf-preview="huanjian-matrix-bernstein-mgf"][data-preview-variant="candidate"] .table-scroll {
  display: block; width: 100%; max-width: 100%; min-width: 0; overflow-x: auto;
}
body[data-mgf-preview="huanjian-matrix-bernstein-mgf"][data-preview-variant="candidate"] .table-scroll table { min-width: 42rem; }
body[data-mgf-preview="huanjian-matrix-bernstein-mgf"][data-preview-variant="candidate"] .proof-reader-equation {
  box-sizing: border-box; max-width: 100%; min-width: 0; overflow-x: auto;
}
body[data-mgf-preview="huanjian-matrix-bernstein-mgf"][data-preview-variant="candidate"] .proof-reader-equation mjx-container[display="true"] { min-width: max-content; }
body[data-mgf-preview="huanjian-matrix-bernstein-mgf"][data-preview-variant="candidate"] .native-source-context {
  min-width: 0; max-width: 100%; overflow-wrap: anywhere;
}
body[data-mgf-preview="huanjian-matrix-bernstein-mgf"][data-preview-variant="candidate"] pre {
  box-sizing: border-box; width: 100%; max-width: 100%; min-width: 0;
  overflow-x: auto; white-space: pre; tab-size: 2;
}
body[data-mgf-preview="huanjian-matrix-bernstein-mgf"][data-preview-variant="candidate"] pre code {
  white-space: pre; overflow-wrap: normal; word-break: normal;
}
body[data-mgf-preview="huanjian-matrix-bernstein-mgf"][data-preview-variant="candidate"] .native-source-context pre span[id^="L"] { scroll-margin-top: 6rem; }
body[data-mgf-preview="huanjian-matrix-bernstein-mgf"][data-preview-variant="candidate"] .native-source-file,
body[data-mgf-preview="huanjian-matrix-bernstein-mgf"][data-preview-variant="candidate"] .mgf-step-source,
body[data-mgf-preview="huanjian-matrix-bernstein-mgf"][data-preview-variant="candidate"] h1,
body[data-mgf-preview="huanjian-matrix-bernstein-mgf"][data-preview-variant="candidate"] h2 { overflow-wrap: anywhere; }
@media (max-width: 760px) {
  body[data-mgf-preview="huanjian-matrix-bernstein-mgf"][data-preview-variant="candidate"] .native-source-context pre span[id^="L"] { scroll-margin-top: 7rem; }
}
'''


def add_step_actions(body, unit, page, base, lessons):
    paths = [step['lean_source_path'] for step in unit['steps']]
    if paths != [PFILE] * 3 + [TFILE] * 3:
        raise ValueError('Expected exactly P/P/P/T/T/T code folds')
    for number, step in enumerate(unit['steps'], 1):
        loc = step['lean_source']
        path = step['lean_source_path']
        if path != loc['path'] or loc['download_path'] != 'downloads/lean/' + path:
            raise ValueError('A step source/download path differs from its literal code locator')
        exact = '<details><summary>Corresponding Lean step</summary>' + base.code_html(step['lean'])
        if body.count(exact) != 1:
            raise ValueError(f'Expected one unique literal opening for step{number}')
        first, last = loc['LF_lines_1based']
        source_href = lessons.source_link({'path': path, 'line': first}, page)
        actions = (base.lean_source_actions(path, page=page, copy_label='Copy displayed Lean step')
            + '<p class="mgf-step-source"><a data-step-source href="'
            + escape(source_href, quote=True) + '">Exact module source · lines '
            + str(first) + '–' + str(last) + '</a> · <code>' + escape(path) + '</code></p>')
        replacement = ('<details data-lean-code-panel data-mgf-step="' + str(number)
            + '" data-step-source-path="' + escape(path, quote=True)
            + '"><summary>Corresponding Lean step</summary>' + actions + base.code_html(step['lean']))
        body = body.replace(exact, replacement, 1)
    return body


def enhance_source(body, path, page, base):
    if body.count('<h1>Exact source context</h1>') != 1 or body.count('<pre>') != 1:
        raise ValueError('Expected one literal production source context')
    intro = ('<div class="native-source-context" data-lean-code-panel>'
        '<h1>Exact source context</h1><p class="native-source-file" data-exact-source-file>'
        '<code>' + escape(path) + '</code></p>'
        + base.lean_source_actions(path, page=page, copy_label='Copy complete module'))
    body = body.replace('<h1>Exact source context</h1>', intro, 1)
    return body.replace('<pre>', '<pre><code class="native-anchored-lean">', 1).replace('</pre>', '</code></pre></div>', 1)


def shell(text, rel, variant):
    text = text.replace('<body>', '<body data-mgf-preview="' + ITEM + '" data-preview-variant="' + variant + '">', 1)
    if variant == 'candidate':
        prefix = '../' * len(Path(rel).parent.parts)
        text = text.replace('</head>', '<link rel="stylesheet" href="' + prefix + 'assets/mgf-reader-overlay.css">\n</head>', 1)
    return text
