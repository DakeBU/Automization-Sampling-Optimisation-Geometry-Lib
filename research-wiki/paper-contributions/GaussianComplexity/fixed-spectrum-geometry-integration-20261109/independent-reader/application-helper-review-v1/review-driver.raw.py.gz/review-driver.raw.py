"""Freeze static defects in root application helper. Never import or execute it."""
from pathlib import Path
import ast, datetime, gzip, hashlib, json, subprocess
R = Path('/Users/zhouhuanjian/ASTIS-GC')
S = R / '.astis/huanjian-gc-fixed-spectrum-geometry-integration-20261109/independent-reader'
O = S / 'application-helper-review-v1'
SCRIPT = R / '.astis/huanjian-gc-fixed-spectrum-geometry-integration-20261109/apply_reviewed_shared.py'
EXPECTED = '4fc3f6e5ce97512f2b742428dc6ff1225f5e56e8a545fb9acda83feb49d482a2'
sha = lambda b: hashlib.sha256(b).hexdigest()
dump = lambda x: (json.dumps(x, ensure_ascii=False, indent=2) + '\n').encode()
raw = SCRIPT.read_bytes(); assert sha(raw) == EXPECTED and not O.exists()
text = raw.decode(); tree = ast.parse(text)
calls = [n for n in ast.walk(tree) if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute)
         and n.func.attr == 'transition_advance']
assert len(calls) == 1 and calls[0].args[1].value == 'STABILIZING'
assert 'protected_baseline' not in text and 'source_V_actual_execution_manifest' not in text
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R).decode().strip() == 'ab8b47caed9f781191f8408154cd355c7e7c104c'
assert not subprocess.check_output(['git', 'diff', 'HEAD', '--name-only'], cwd=R)
proposal = json.loads((S / 'conditional-proposal-v1/proposal-report.json').read_bytes())
audit_path = R / 'research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-geometry.json'
audit = json.loads(audit_path.read_bytes())
assert audit['verdict'] == 'pending' and audit['state'] == 'blind-reconstructed'
findings = [
 {'id': 'R1', 'severity': 'BLOCKING', 'lines': [33, 55, 56, 66, 84, 85],
  'title': 'No full candidate-baseline preservation check before the normal STAB/application',
  'evidence': 'The helper freezes current-head foreign frontier/model/README snapshots at lines55-58 and checks those snapshots afterward. It never opens proposal protected_baseline. The selected exact_inputs loop does not contain the full models/README/frontiers/other tracked source set.',
  'counterexample_scope': 'A clean sourceV-carrying commit could already change one foreign frontier, GraphMemory/Functor, GaussianComplexity README, or another baseline tracked source outside exact_inputs. The later snapshots would preserve those changed bytes and still pass. This is a static logical counterexample; no such mutation was performed.',
  'important_distinction': 'The exact candidate_ledger + one own V equality at line51 DOES protect foreign SAU event history and hence replayed foreign states; that guard is sound. Do not describe all foreign states as unprotected.',
  'required_fix': 'Decompress and hash-verify the frozen full protected baseline before any shared/lifecycle mutation. Compare every protected tracked current raw byte/symlink to the candidate baseline except exactly the separately bound own accepted audit, own ledger, and—only if explicitly separately reviewed—the own sourceV mechanical frontier projection. Assert exact baseline foreign states, discovery states/ledger, all foreign frontier raw hashes, models, README, source/toolchain and old audit bytes. Recheck after application with the only intended deltas.'},
 {'id': 'R2', 'severity': 'BLOCKING', 'lines': [34, 36, 39, 43, 47, 49, 54],
  'title': 'Claimed sourceV bytes are not tied here to the actual one-call normal API execution manifest and all role identities',
  'evidence': 'The append file, accepted audit and reviewer string are checked, and pub.check_advance invokes semantic/publication validation. However no actual execution-manifest reference/hash, normal_API_calls==1, exact_append_sha256 or source-review-run reference is checked by this helper. The source verifier is not explicitly excluded from root/integration-reader/integrator/decoder identities.',
  'existing_guard_credit': 'pub.check_advance calls roundtrip.validate_registry, so ordinary formalizer/decoder/source-review distinctions and current binding validation are not absent. Additional requested actual normal-transition provenance and the known root/integration-reader role exclusions are still needed here.',
  'required_fix': 'Require the real separately emitted sourceV execution manifest and exact append reference with immutable hashes. Check actor==audit.source_review.reviewer==V.worker_id==V.evidence.verifier_id; normal_API_calls==1; manifest exact_append_sha256 and actual verified candidate/binding/audit/run references match. Require verifier distinct from formalizer OWNER, decoder, INTEGRATOR, /root and /root/geometry_integration_reader. Preserve original actual audit/source review evidence without reissuing sourceV or substituting a projected verdict.'},
 {'id': 'R3', 'severity': 'BLOCKING_SCOPE_AND_LOSSLESSNESS', 'lines': [19, 87, 88, 93, 97, 102],
  'title': 'Own frontier is an additional unfrozen JSON rewrite outside the six byte payloads',
  'evidence': 'After applying six reviewed payloads the helper loads the own cell and writes json.dumps(cell) over it. It adds or overwrites evidence.canonical_integration without asserting absence, freezing exact pre/post raw bytes, binding an explicitly authorized projection, or checking that only that one new object changed. The receipt names six paths but does not disclose this extra own metadata write.',
  'required_fix': 'Treat the own cell as an explicit, separately authorized mechanical metadata projection, never a seventh new mathematical payload or blanket baseline exception. Freeze the actual sourceV own-cell raw before bytes, require any sourceV candidate→frontier deltas to be exact separately reviewed metadata, assert no existing canonical_integration result is overwritten, insert only the actual new canonical integration object losslessly, and archive exact raw before/after plus changed JSON paths. Check that removing the new object restores exact sourceV pre-application bytes and mathematical/source/seal/parents/old coverage/evidence tokens remain unchanged. Name this own metadata delta honestly in authorization/receipt. Later browser projection review must bind actual V and STAB appends and exact own-cell raw hashes.'},
 {'id': 'R4', 'severity': 'GUARD_ORDER_HARDENING', 'lines': [39, 41, 78, 81],
  'title': 'Read/recovery ordering and the returned STAB append need exact readback',
  'evidence': 'adv.current_advances() can invoke durable interrupted-tail recovery before the helper pins/compares raw ledger bytes. After transition only line count/prefix and replayed state are checked, rather than parsing the one new append record.',
  'required_fix': 'Read and validate raw candidate-prefix+soleV, valid complete JSONL and hashes before calling a potentially recovering loader; preferably use pure replay for preflight. After the one normal transition parse the one newline-terminated append and require event=transition, advance_id exact, VERIFIED→STABILIZING, worker_id=integration_owner=INTEGRATOR, original verifier/candidate/publication declarations exact, no owner change, and no other byte/event. Preserve exact sourceV prefix and all foreign states. The normal API should still be called exactly once; do not hand-append STAB.'}
]
guard_contract = {
 'candidate_and_head': ['Fixed mathematical candidate ab8b47caed9f781191f8408154cd355c7e7c104c remains the reviewed theorem/Test/lesson/publication identity.',
    'Actual sourceV first-carrying HEAD is a real descendant of candidate and fresh observed origin/main; current tracked tree clean and root authorization hashes this exact successor helper.',
    'No push/merge or remote-owner release inferred. Existing PR385/owner boundary stays separate.'],
 'frozen_payload': ['Verify exact proposal report/freeze/root review and all six before/after raw archives before mutation.',
    'Root import, Tests import, Basic623→624, Registry one new public node, own case two scalar tokens, new canonical module card only.',
    'Exactly three existing canonical ASTIS producer parents; real private Borel Test stays private with Geometry+FirstOrder parents, no extra Registry/public node.'],
 'baseline_allowed_exceptions': {
    'own_audit': 'Candidate old draft bytes must equal frozen candidate pin. Live/head accepted bytes must equal separately actual sourceV accepted audit hash, current binding and full source-review-run evidence. Only this exact own audit successor is allowed; every old/foreign audit remains raw exact.',
    'own_ledger': 'Candidate entire raw prefix exact; live pre-STAB ledger is that prefix plus exactly one actual distinct sourceV append; live post-STAB is that exact sequence plus exactly one normal VERIFIED→STABILIZING append. No foreign or historical prefix edits, retries, projected V or park.',
    'own_frontier': 'No broad exemption. The actual sourceV candidate→own-cell metadata projection, if any, needs separately pinned raw before/after and independently reviewed exact leaf paths; mathematical fields/source/seal/binders/parents/old coverage preserved. Application may add only one explicitly authorized canonical_integration object and freeze its exact actual raw delta. All445 frontier baselines, including444 foreign frontiers, remain protected except those exact own metadata deltas.',
    'all_other_tracked': 'Compare all other frozen protected125846 entries to their raw candidate hashes/symlink bytes before and after, not only current-head snapshots. Six reviewed shared existing/new payloads are separately checked. No general source/audit/model exception.'},
 'role_and_actual_sourceV': ['Proof ownership remains huanjian_gc_20261109_fixed_spectrum_geometry; new sole integration ownership is separate.',
    'Actual source reviewer is distinct from source-blind decoder, proving OWNER, root, integration reader and integrator; V worker/evidence verifier equals that original source reviewer.',
    'Require real sourceV execution manifest, one normal API call, exact unique append, current accepted audit and source review run hashes, exact candidate and publication binding. No future value is fabricated in preparation.',
    'Normal API creates only one STAB transition after this actual V. No sourceV is issued by the integration script.'],
 'own_frontier_raw_algorithm': ['Do not reserialize the entire own cell. Work on exact raw token spans or reviewed exact byte replacement; preserve old CRLF/loneLF and all old tokens.',
    'Assert the new canonical_integration key was absent. Freeze exact before/after and inverse restoration, validate JSON and only authorized path delta.',
    'Record actual STAB append hash and original source reviewer/candidate/proposal with status actual-core-gates-pending; no runtime acceptance or new source theorem is claimed.'],
 'after_application': ['All six after raw hashes equal frozen payloads; source/Test/lesson/publication and actual accepted audit unchanged; ledger one exact new STAB; sole STAB state and proofowner preserved; all foreign state/raw baselines exact.',
    'Actual source digest equals frozen predicted6905b946089555464e4eedadfad3644fb4df3ee5d49ffc8445c16bb7fd997108 after exact Lean payloads.',
    'Immutable integration core, official8 actual gates/site/graph, newly scoped Chrome/OS execution,44 original PNGs/12 native geometry rows and separate independent original-image acceptance remain later prerequisites.',
    'Script PASS or static review never grants pixels, remote publication, purification/Exposition Seal, either full lower bound or whole-Goal completion.']}
O.mkdir()
(O / 'apply-reviewed-shared.original.raw.py.gz').write_bytes(gzip.compress(raw, mtime=0))
root_review = R / '.astis/huanjian-gc-fixed-spectrum-geometry-integration-20261109/root-conditional-six-path-review.json'
(O / 'root-six-path-review.raw.json.gz').write_bytes(gzip.compress(root_review.read_bytes(), mtime=0))
record = {'state': 'HOLD_EXACT_ORIGINAL_HELPER_STATIC_DEFECTS_REQUIRING_SUCCESSOR', 'reviewer': '/root/geometry_integration_reader',
 'reviewed_script': str(SCRIPT.relative_to(R)), 'reviewed_script_sha256': EXPECTED,
 'root_six_payload_review_sha256': sha(root_review.read_bytes()),
 'proposal_report_sha256': sha((S / 'conditional-proposal-v1/proposal-report.json').read_bytes()),
 'candidate_commit': 'ab8b47caed9f781191f8408154cd355c7e7c104c', 'findings': findings, 'required_successor_guards': guard_contract,
 'sound_parts': ['Exact six archived planned-after payload decompression and raw hashes; six current before-byte pins; one actual transition_advance call to STABILIZING; no call issuing sourceV.',
    'Candidate ledger+sole own V equality protects historical/foreign event history; proofowner remains OWNER; existing source review/publication validator checks current binding.',
    'All planned changes remain unapplied and current candidate tracked tree clean.'],
 'sourceV_status': 'PENDING; source actor phase3 not replaced or judged by this review',
 'root_script_executed_or_shared_mutated': False, 'sourceV_application_runtime_pixel_acceptance_granted': False,
 'successor_instruction': 'Retain this exact original helper; patch a separately named/pinned successor after this frozen report and request independent exact-successor review before any execution.',
 'recorded_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
(O / 'static-review-HOLD.json').write_bytes(dump(record))
(O / 'review-driver.raw.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
freeze = {'state': record['state'], 'report_sha256': sha((O / 'static-review-HOLD.json').read_bytes()),
 'files': [{'path': str(q.relative_to(R)), 'sha256': sha(q.read_bytes())} for q in sorted(O.iterdir()) if q.is_file()], 'execution_authorized': False}
(O / 'freeze.json').write_bytes(dump(freeze))
assert SCRIPT.read_bytes() == raw
assert not subprocess.check_output(['git', 'diff', 'HEAD', '--name-only'], cwd=R)
print(json.dumps({'report': str((O / 'static-review-HOLD.json').relative_to(R)),
 'report_sha256': freeze['report_sha256'], 'freeze_sha256': sha((O / 'freeze.json').read_bytes()),
 'reviewed_original_script_sha256': EXPECTED, 'helper_executed': False, 'status': record['state']}, indent=2))
