from pathlib import Path
import json, hashlib, os, stat, sys
from bs4 import BeautifulSoup

phase=Path(__file__).resolve().parent.parent
source=(phase/"inputs/2610.20492v1.html").read_bytes()
expected="6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915"
sha=lambda b:hashlib.sha256(b).hexdigest()
assert len(source)==951991
assert sha(source)==expected
soup=BeautifulSoup(source,"html.parser")
check={"source_bytes":len(source),"source_sha256":sha(source),"input_snapshots":0,"exact_fragments":0,"math_locators":0,"fragment_dom_equivalence":0}
for item in json.loads((phase/"inputs/input-index.json").read_text()):
    data=(phase/item["snapshot"]).read_bytes()
    assert len(data)==item["bytes"],item
    assert sha(data)==item["sha256"],item
    check["input_snapshots"]+=1
for name in ("extraction-locators.json","proof-detail-locators.json"):
    for rec in json.loads((phase/"raw"/name).read_text()):
        data=(phase/rec["snapshot"]).read_bytes()
        sl=source[rec["byte_start"]:rec["byte_end_exclusive"]]
        assert data==sl,rec["source_id"]
        assert len(data)==rec["bytes"],rec["source_id"]
        assert sha(data)==rec["sha256"],rec["source_id"]
        fragment=BeautifulSoup(data,"html.parser").find(id=rec["source_id"])
        original=soup.find(id=rec["source_id"])
        assert fragment is not None and original is not None,rec["source_id"]
        assert str(fragment)==str(original),rec["source_id"]
        check["fragment_dom_equivalence"]+=1
        check["exact_fragments"]+=1
for p in sorted((phase/"raw").glob("*.math-alttext.json")):
    for rec in json.loads(p.read_text()):
        if "locator" not in rec:
            raise AssertionError(("missing math locator",p.name,rec["id"]))
        loc=rec["locator"]
        data=source[loc["byte_start"]:loc["byte_end_exclusive"]]
        assert len(data)==loc["bytes"] and sha(data)==loc["sha256"],rec["id"]
        m=BeautifulSoup(data,"html.parser").find("math",id=rec["id"])
        assert m is not None and m.get("alttext")==rec["alttext"],rec["id"]
        check["math_locators"]+=1
assert len(soup.find(id="A3.SS2").find_all("math"))==167
assert soup.find(id="S4.E11") is not None
g=json.loads((phase/"analysis/source-proof-cognition-graph-v2.json").read_text())
assert g["nodes"][0]["source_locator"]=="S4.SS1 / S4.E11"
assert all(any(("A3.SS2.p"+str(i)) in n["source_locator"] for n in g["nodes"]) for i in range(1,20))
assert "source-proof-cognition-graph-v2.json" in (phase/"README.md").read_text()
check["authoritative_graph"]="analysis/source-proof-cognition-graph-v2.json"
check["preserved_graph_v1_metadata_correction"]=True
check["validation_kind"]="artifact/source-byte integrity only; no Lean or theorem proof"
check["files_before_freeze_records"]=sum(1 for p in phase.rglob("*") if p.is_file())
def newjson(path,value):
    with path.open("x",encoding="utf-8") as f:
        json.dump(value,f,ensure_ascii=False,indent=2)
        f.write("\n")
newjson(phase/"logs/pre-freeze-validation-v1.json",check)
newjson(phase/"logs/freeze-child-command-v1.json",{
    "python_orig_argv":sys.orig_argv,"cwd":str(Path.cwd()),"program":str(Path(__file__)),
    "stdout_stderr":"Captured separately by outer finalizer and retained in sibling receipt/output files.",
    "payload_mutation":"Only new freeze records and manifest, then modes0444/0555. No previous payload overwritten."
})
files=sorted(p for p in phase.rglob("*") if p.is_file())
assert not (phase/"MANIFEST.json").exists()
assert not any(p.is_symlink() for p in phase.rglob("*"))
entries=[{"path":str(p.relative_to(phase)),"bytes":p.stat().st_size,"sha256":sha(p.read_bytes()),"frozen_mode":"0444"} for p in files]
cognition_sha=sha((phase/"analysis/source-cognition-v1.md").read_bytes())
graph_sha=sha((phase/"analysis/source-proof-cognition-graph-v2.json").read_bytes())
manifest={
    "schema":"cg-source-only-phase-manifest-v1","phase":"phase1-source-only","source_sha256":expected,
    "source_bytes":951991,"authoritative_cognition":"analysis/source-cognition-v1.md","cognition_sha256":cognition_sha,
    "authoritative_graph":"analysis/source-proof-cognition-graph-v2.json","graph_sha256":graph_sha,
    "files":entries,"manifest_self_excluded":True,
    "receipt":"../phase1-source-only.receipt.json",
    "hash_cycle_policy":"Manifest hashes all other phase payloads; sibling receipt hashes manifest and captures seal result; receipt never hashes itself.",
    "scope":"Source cognition only, prior to candidate/types/decoder/full code. Not a theorem proof or pristine/pretrained zero-knowledge guarantee.",
    "final_patch_events":[
        {"tool":"apply_patch","action":"add README, final tools/correction log, graph v2; all successful"},
        {"tool":"apply_patch","action":"add validate-and-freeze-v1.py and finalization-plan-v1.json; all successful"}
    ]
}
newjson(phase/"MANIFEST.json",manifest)
manifest_sha=sha((phase/"MANIFEST.json").read_bytes())
for p in files+[phase/"MANIFEST.json"]:p.chmod(0o444)
directories=sorted([p for p in phase.rglob("*") if p.is_dir()],key=lambda p:len(p.parts),reverse=True)
for p in directories+[phase]:p.chmod(0o555)
for rec in entries:
    p=phase/rec["path"]
    assert sha(p.read_bytes())==rec["sha256"],rec["path"]
    assert stat.S_IMODE(p.stat().st_mode)==0o444,rec["path"]
assert stat.S_IMODE((phase/"MANIFEST.json").stat().st_mode)==0o444
for p in directories+[phase]:
    assert stat.S_IMODE(p.stat().st_mode)==0o555,str(p)
assert sha((phase/"MANIFEST.json").read_bytes())==manifest_sha
summary={
    "phase":str(phase),"status":"FROZEN_SOURCE_COGNITION_ONLY",
    "source_sha256":expected,"source_bytes":951991,
    "manifest_sha256":manifest_sha,"cognition_sha256":cognition_sha,"graph_sha256":graph_sha,
    "payload_files_including_manifest":len(entries)+1,"directories_including_phase":len(directories)+1,
    "all_payload_modes":"0444","all_phase_directory_modes":"0555",
    "exact_fragments_checked":check["exact_fragments"],"math_locators_checked":check["math_locators"],
    "candidate_types_decoder_code_read":False,
    "first_failure_preserved":"ENV_BLOCKED exec argv too long; process never created",
    "display_truncations_preserved":2,
    "boundary":"No range(B)=Krylov, C6 concentration, or full Lemma4.4 completion claim."
}
print(json.dumps(summary,ensure_ascii=False,indent=2))
