from html.parser import HTMLParser
from html import unescape
from pathlib import Path
import hashlib
import json
import re

SOURCE = Path('/Users/zhouhuanjian/ASTIS-GC/.astis/huanjian-resume-20261103/2610.20492v1.html')
OWN = Path(__file__).parent
RAW = SOURCE.read_bytes()
assert len(RAW) == 951991
assert hashlib.sha256(RAW).hexdigest() == '6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
TEXT = RAW.decode('utf-8')

class Node:
    def __init__(self, tag, attrs, start, parent):
        self.tag, self.attrs, self.start, self.parent = tag, dict(attrs), start, parent
        self.children, self.end = [], None

class Parser(HTMLParser):
    VOID = {'area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr'}
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.offsets = [0]
        for m in re.finditer('\n', TEXT): self.offsets.append(m.end())
        self.root = Node('ROOT', [], 0, None)
        self.stack, self.ids, self.nodes = [self.root], {}, []
    def pos(self):
        line, col = self.getpos()
        return self.offsets[line-1]+col
    def handle_starttag(self, tag, attrs):
        n=Node(tag,attrs,self.pos(),self.stack[-1])
        self.stack[-1].children.append(n)
        self.nodes.append(n)
        if 'id' in n.attrs:self.ids[n.attrs['id']]=n
        if tag in self.VOID:n.end=self.pos()+len(self.get_starttag_text())
        else:self.stack.append(n)
    def handle_startendtag(self, tag, attrs):
        self.handle_starttag(tag,attrs)
        if tag not in self.VOID:self.stack.pop().end=self.pos()+len(self.get_starttag_text())
    def handle_endtag(self, tag):
        for i in range(len(self.stack)-1,0,-1):
            if self.stack[i].tag == tag:
                end=TEXT.index('>',self.pos())+1
                for n in self.stack[i:]:n.end=end
                del self.stack[i:]
                break
    def handle_data(self, data):self.stack[-1].children.append(data)

PARSER=Parser()
PARSER.feed(TEXT)

def textext(n):
    if isinstance(n,str):return n
    if n.tag=='math':return ' $'+n.attrs.get('alttext','[MISSING_ALTTEXT]')+'$ '
    return ''.join(textext(c) for c in n.children)

def normalized(n):return re.sub(r'\s+',' ',unescape(textext(n))).strip()

def descendants(n):
    for c in n.children:
        if isinstance(c,Node):
            yield c
            yield from descendants(c)

def raw_slice(n):
    assert n.end is not None
    return TEXT[n.start:n.end].encode('utf-8')

if __name__=='__main__':
    import sys
    mode=sys.argv[1]
    for key in sys.argv[2:]:
        n=PARSER.ids[key]
        if mode=='structure':
            for c in [n,*descendants(n)]:
                if c.attrs.get('id') and c.tag in {'section','div','p','table','h2','h3','h4','h5'}:
                    print(c.tag,c.attrs.get('id'),c.attrs.get('class',''))
        elif mode=='text':
            print('SOURCE_ID',key,'TAG',n.tag)
            for c in [n,*descendants(n)]:
                if c.tag in {'p','h2','h3','h4','h5','table'}:
                    a=c.parent
                    if any(a.tag==t for t in {'table'}):continue
                    print('\nID',c.attrs.get('id'), 'TAG',c.tag)
                    print(normalized(c))
        elif mode=='exact':print(raw_slice(n).decode())
