from pathlib import Path
import json,hashlib
b=Path('.astis/huanjian-fixed-spectrum-query-20261107');out=Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-query-semantic-evidence')
sig='''theorem actual_affine_precision_query {d : ℕ} (hd : 2 ≤ d)
    {κ : ℝ} (hκ : 2 ≤ κ)
    (O : Matrix.orthogonalGroup (Fin d) ℝ) :
    let θ : Fin d → ℝ := fun i => ((i.val : ℝ) + 1 / 2) * Real.pi / (d : ℝ)
    let A : ℝ → Matrix (Fin d) (Fin d) ℝ := fun η =>
      (O : Matrix (Fin d) (Fin d) ℝ) *
        Matrix.diagonal (fun i => (η + 1) / 2 + (η - 1) / 2 * Real.cos (θ i)) *
        (O : Matrix (Fin d) (Fin d) ℝ).transpose
    let query : ℝ → EuclideanSpace ℝ (Fin d) → EuclideanSpace ℝ (Fin d) :=
      fun η x => WithLp.toLp 2 (A η *ᵥ WithLp.ofLp x)
    ∀ x : EuclideanSpace ℝ (Fin d),
      query κ x = (κ - 1) • query 2 x - (κ - 2) • x ∧
      query 2 x = (κ - 1)⁻¹ • (query κ x + (κ - 2) • x)
'''
prop='∀ '+sig[len('theorem actual_affine_precision_query '):].replace('    (O : Matrix.orthogonalGroup (Fin d) ℝ) :','    (O : Matrix.orthogonalGroup (Fin d) ℝ),',1)
head='''import Mathlib.Analysis.CStarAlgebra.Matrix
import Mathlib.Analysis.InnerProductSpace.PiL2
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Basic
open Matrix
set_option autoImplicit false
'''
p=b/'SignatureOnly.lean';p.write_text(head+'#check (\n'+prop+' : Prop)\n')
(out/'candidate-exact-signature.txt').write_text(sig)
(out/'preseal-meaning-and-binder-inventory.json').write_text(json.dumps({'signature_sha256':hashlib.sha256(sig.encode()).hexdigest(),'source_domain':'For source S4 hardfamily d>=2,kappa>=2. Existing eigenbasis parentcell Theorem4.1 keptclaimed/unmodified; pointwise precursor createsno Haar/adaptive/precision/cost/main-bound fact.','binder_classes':{'d':'Natural ambientdimension, source d>=2 exact.','hd':'Source dimension premise; no positive-cosine estimate or Gaussian condition is added.','κ':'Real precisionintervalparameter, source>=2 exact.','hκ':'Source parameter premise. κ-1 nonzero must be internally derived before interpreting reverse division.','O':'Arbitrary actual full realorthogonalgroup element, same SINGLE hiddenrotation for Aκ andA2; not supplied as an accessible algorithm input.','θ/A/query':'Local literalsource definitions, not premisebundles. i.val is source i-1, hence i_source-1/2=i.val+1/2.','x':'Every actual Euclidean querypoint; no nonzero-vector or randomness assumption.'},'definition_senses':['Realcos andRealpi use pinnedrealtrigonometric meanings; actualChebyshevgrid theta=((i+.5)pi)/d. hd gives nonzero d, so no total-division fallback supplies source meaning.','Realreciprocal is totalat0; reverse coefficient valid because sourceκ>=2 ensures κ-1≠0, to be derived internally.','Matrix.orthogonalGroup full O(d) includes eitherdeterminantsign; Otranspose=Oinverse, fullidentity product not supplied as extra premise.','Matrix.diagonal and actual matrixproducts construct OΛηOtranspose; no arbitrary Aκ/A2, abstractaffine relation, fixedresponse equality or answeridentity is assumed.','EuclideanSpace real(Fin d) is l2 realvectors; WithLp preservesentries and queryreturns actualprecisionmatvec. No derivative/valueoracle/normalizingconstant/TVdistance is asserted.'],'intended_actual_consumer':'Two actual hiddenrotations O1,O2 atsameactualx: equality of actualκ2precision replies iff equality of actualκprecision replies. Must consume newproducer twice; no hypothesized affine identity or fullsimulation conclusion.','preproof_boundary':'Signature-only type elaboration next; target proof/API search forbidden until exactseal plus distinct sourcegraph/topology/meaning admission. No mathematicalclosure claimed.'},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'signature_sha256':hashlib.sha256(sig.encode()).hexdigest(),'signature_only_Prop_no_proof':str(p)}))
