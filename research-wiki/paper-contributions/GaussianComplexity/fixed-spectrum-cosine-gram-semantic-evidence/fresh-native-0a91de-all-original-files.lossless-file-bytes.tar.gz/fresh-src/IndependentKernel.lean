import Tests.GaussianComplexityFixedSpectrumCosineGram
open Matrix MeasureTheory ProbabilityTheory Lean
open scoped BigOperators
set_option autoImplicit false

def IndependentExpectedProducer : Prop := ∀ {d q : ℕ} (hq : 2 * q + 1 < d),
  let θ : Fin d → ℝ := fun i => ((i.val : ℝ) + 1 / 2) * Real.pi / (d : ℝ)
  let t : Matrix (Fin d) (Fin (q + 1)) ℝ := fun i k =>
    if k.val = 0 then 1 else Real.sqrt 2 * Real.cos ((k.val : ℝ) * θ i)
  let D : Matrix (Fin d) (Fin d) ℝ :=
    Matrix.diagonal (fun i => Real.cos (((2 * q + 1 : ℕ) : ℝ) * θ i))
  t.transpose * t = (d : ℝ) • (1 : Matrix (Fin (q + 1)) (Fin (q + 1)) ℝ) ∧
    t.transpose * D * t = 0 ∧
    ∀ i : Fin d, ∑ k : Fin (q + 1), (t i k) ^ 2 ≤ 2 * ((q : ℝ) + 1)


def IndependentExpectedConsumer : Prop := ∀ {d q : ℕ} (hq : 2 * q + 1 < d),
  let θ : Fin d → ℝ := fun i => ((i.val : ℝ) + 1 / 2) * Real.pi / (d : ℝ)
  let t : Matrix (Fin d) (Fin (q + 1)) ℝ := fun i k =>
    if k.val = 0 then 1 else Real.sqrt 2 * Real.cos ((k.val : ℝ) * θ i)
  let D : Matrix (Fin d) (Fin d) ℝ :=
    Matrix.diagonal (fun i => Real.cos (((2 * q + 1 : ℕ) : ℝ) * θ i))
  let μ : Measure (EuclideanSpace ℝ (Fin d × Fin (q + 1))) :=
    multivariateGaussian (0 : EuclideanSpace ℝ (Fin d × Fin (q + 1)))
      (1 : Matrix (Fin d × Fin (q + 1)) (Fin d × Fin (q + 1)) ℝ)
  let B : EuclideanSpace ℝ (Fin d × Fin (q + 1)) →
      Matrix (Fin d) (Fin (q + 1) × Fin (q + 1)) ℝ := fun x i a =>
    (Real.sqrt (d : ℝ))⁻¹ * WithLp.ofLp x (i, a.1) * t i a.2
  ∀ a b : Fin (q + 1) × Fin (q + 1),
    Integrable (fun x => ((B x).transpose * B x) a b) μ ∧
    Integrable (fun x => ((B x).transpose * D * B x) a b) μ ∧
    (∫ x, ((B x).transpose * B x) a b ∂μ) = (if a = b then 1 else 0) ∧
    (∫ x, ((B x).transpose * D * B x) a b ∂μ) = 0


run_cmd do
  setEnv ((← getEnv).setExporting false)
  let env ← getEnv
  let producerModule := `AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumCosineGram
  let consumerModule := `Tests.GaussianComplexityFixedSpectrumCosineGram
  let some pi := env.getModuleIdx? producerModule | throwError "Producer module absent"
  let some ti := env.getModuleIdx? consumerModule | throwError "Consumer module absent"
  let isOwned := fun n => env.getModuleIdxFor? n == some pi || env.getModuleIdxFor? n == some ti
  let owned := env.constants.toList.filter (fun (n, _) => isOwned n)
  let producer := `AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumCosineGram.actual_cosine_frame_gram
  let roots := owned.filter (fun (n, _) => n == producer || n.toString.endsWith ".actual_gaussian_gram_means")
  unless roots.length == 2 do throwError "Wrong root inventory {roots.map Prod.fst}"
  let allowed := [`propext, `Classical.choice, `Quot.sound]
  let mut allReach : NameSet := {}
  for (root, ci) in roots do
    match ci with
    | .thmInfo _ => pure ()
    | _ => throwError "Root is not a theorem {root}"
    unless !ci.type.hasFVar && !ci.type.hasMVar && !ci.type.hasLooseBVars do
      throwError "Nonclosed root type {root}"
    let expected := if root == producer then `IndependentExpectedProducer else `IndependentExpectedConsumer
    let checked := if root == producer then `IndependentProducerKernelChecked else `IndependentConsumerKernelChecked
    Lean.Elab.Command.liftCoreM <| addDecl <| Declaration.thmDecl {
      name := checked, levelParams := [], type := mkConst expected, value := mkConst root }
    logInfo m!"ROOT_CLOSED_EXACT_PROP_KERNEL_PASS {root}"
    logInfo m!"ROOT_ACTUAL_TYPE {root}: {ci.type}"
    let some proof := ci.value? true | throwError "Missing root proof {root}"
    let direct := proof.getUsedConstants.toList
    let mut pending := direct ++ ci.type.getUsedConstants.toList
    let mut seen : NameSet := {}
    let mut parents : NameSet := {}
    let mut rootOwned : NameSet := {}
    rootOwned := rootOwned.insert root
    while !pending.isEmpty do
      let u := pending.head!
      pending := pending.tail!
      unless seen.contains u do
        seen := seen.insert u
        if u == producer && root != producer then
          parents := parents.insert u
        else if isOwned u then
          rootOwned := rootOwned.insert u
          let some provider := env.find? u | throwError "Missing owned provider {u}"
          let some body := provider.value? true | throwError "Missing owned body {u}"
          pending := body.getUsedConstants.toList ++ provider.type.getUsedConstants.toList ++ pending
        else if u.toString.startsWith "AutoSamplingTheory." then
          parents := parents.insert u
    let required := if root == producer then
      [`AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumGridAlias.actual_midpoint_grid_cosine_alias]
      else [producer]
    unless parents.toList.length == required.length && required.all parents.contains do
      throwError "Wrong first-public ASTIS parents {root}: {parents.toList}"
    allReach := rootOwned.toList.foldl (fun acc n => acc.insert n) allReach
    logInfo m!"ROOT_FIRST_PUBLIC_ASTIS_PARENTS {root}: {parents.toList}"
    logInfo m!"ROOT_REACHABLE_OWNED {root}: {rootOwned.toList}"
    logInfo m!"ROOT_DIRECT_USED_CONSTANTS {root}: {direct}"
  for (n, ci) in owned do
    let some body := ci.value? true | throwError "Owned no body {n}"
    match ci with
    | .thmInfo _ => pure ()
    | .defnInfo v => unless v.safety == .safe do throwError "Unsafe owned definition {n}"
    | _ => throwError "Unreviewed owned constant kind {n}"
    unless !ci.type.hasFVar && !ci.type.hasMVar && !ci.type.hasLooseBVars do
      throwError "Owned nonclosed type {n}"
    let axioms ← Lean.collectAxioms n
    unless axioms.all allowed.contains do throwError "Unexpected recursive axiom {n}: {axioms}"
    unless allReach.contains n do throwError "Unreachable owned constant {n}"
    logInfo m!"OWNED_RECURSIVE_AXIOMS_REACHABLE_CLOSED {n}: {axioms}"
    logInfo m!"OWNED_PROVIDER_CONSTANTS {n}: {body.getUsedConstants.toList}"
  logInfo m!"OWNED_MODULE_PROVENANCE_INVENTORY_COUNT {owned.length}"

#print axioms IndependentProducerKernelChecked
#print axioms IndependentConsumerKernelChecked
