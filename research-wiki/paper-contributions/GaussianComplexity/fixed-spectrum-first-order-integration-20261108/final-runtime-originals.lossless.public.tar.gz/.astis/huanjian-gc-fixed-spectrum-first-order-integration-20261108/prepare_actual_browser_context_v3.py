from pathlib import Path
import argparse, datetime, hashlib, json, subprocess, sys
R = Path('.astis/huanjian-gc-fixed-spectrum-first-order-integration-20261108')
I = R/'independent-reader'; L = Path('.astis/huanjian-resume-20261103')
sha = lambda b: hashlib.sha256(b).hexdigest()
ref = lambda p: {'path':str(p),'sha256':sha(p.read_bytes())}
head = subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert head == '87ecd4d421de0146a062435f63e9dcb1f815c807'
assert not subprocess.check_output(['git','diff','HEAD','--name-only'],text=True).strip()
a = json.loads((I/'UNAUTHORIZED-final-browser-context-v3.template.json').read_bytes())
a.update({'state':'ROOT_AUTHORIZED_BOUND_LOCAL_BROWSER_EXECUTION_ONLY_NOT_ACCEPTANCE',
    'authorized_by':'/root','execute_browser_authorized':True,'accepted_immutable_core':head,
    'authorized_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()})
a['actual_gate'] = ref(Path('.astis/site-lean-gate.json'))
a['site_metadata'] = ref(Path('_site/data/build-metadata.json'))
a['own_frontier_projection_review'] = ref(R/'root-exact-own-frontier-projection-review-v3.json')
names = {
 'canonical_lean':'20261108T141231962476Z-fixed-spectrum-first-order-final-canonical-site-lean-gate',
 'publication':'20261108T140941645829Z-fixed-spectrum-first-order-final-publication',
 'contributor':'20261108T140941645824Z-fixed-spectrum-first-order-final-contributor',
 'semantic':'20261108T140941645729Z-fixed-spectrum-first-order-final-semantic',
 'frontier':'20261108T140941645781Z-fixed-spectrum-first-order-final-frontier',
 'site_build':'20261108T141400548309Z-fixed-spectrum-first-order-final-site-build',
 'site_check':'20261108T141606991519Z-fixed-spectrum-first-order-final-site-check',
 'graph_check':'20261108T141606991618Z-fixed-spectrum-first-order-final-graph-check'}
a['actual_checks_before_browser'] = {}
for role, name in names.items():
    p = L/(name+'.receipt.json'); r = json.loads(p.read_bytes())
    assert r['exit_code'] == 0 and r['head_before'] == r['head_after'] == head
    assert sha(Path(r['log']).read_bytes()) == r['log_sha256']
    a['actual_checks_before_browser'][role] = ref(p)
a['additional_actual_standalone_root_check'] = ref(L/'20261108T140940477461Z-fixed-spectrum-first-order-final-canonical-lean.receipt.json')
a['instruction'] = 'Execute only the separately reviewed v3 checker on the genuine current canonical _site artifact built at this exact core. Local HTTP and headless installed Chrome require separate scoped OS permission. This is actual site acceptance work, separate from the earlier owned STATIC source-review preview; no file-URL or denied BrowserUse transport is used. No source verdict, normalpark, remote or wholeGoal acceptance is authorized.'
out = R/'root-final-browser-context-v3.json'; assert not out.exists()
out.write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n')
sys.path.insert(0,str(I.resolve()))
import first_order_browser_common_v3 as common
args = argparse.Namespace(authorization_json=str(out),authorization_sha256=sha(out.read_bytes()))
value, reference = common.load_authorization(args)
readback = common.authorized_context(value)
p = R/'actual-browser-context-v3-readonly-preflight.json'; assert not p.exists()
p.write_text(json.dumps({'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'kind':'Exact sourceV/STAB/core/8actualreceipts/foreign-preservation authorization preflight only',
    'authorization':reference,'readback':readback,'browser_launched':False,'acceptance_created':False},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'actual_context':str(out),'raw_sha256':sha(out.read_bytes()),
                  'readonly_preflight':str(p),'preflight_sha256':sha(p.read_bytes()),
                  'all8_actual_receipts_same_core':True,'browser_launched':False}))
