from pathlib import Path
from collections import Counter
import hashlib,json
root=Path('/Users/zhouhuanjian/ASTIS-GC')
out=root/'.astis/huanjian-gc-fixed-spectrum-variances-20261110/independent-source-graph'
inventory=json.loads((out/'raw-unit-inventory.json').read_text())
rows=[]
for u in inventory['units']:
 kind=u['kind'];ident=u['id']; node=True;reason=None
 if kind in ['heading','section-context','proof-block','paragraph-container']:
  node=False;reason='Structural/rendering container or heading. Substantive original paragraphs, theorem blocks and displays inside the bounded scope are separately inventoried as raw nodes.'
 elif kind=='tbody':
  node=False;reason='Rendering subcontainer; complete mathematics, original span and references are preserved here and in the containing display raw node '+ident.split('::')[0]+'.'
 elif kind=='paragraph' and u['text_with_tex'].strip()=='∎':
  node=False;reason='Standalone proof-end marker contains no mathematical assertion.'
 elif kind=='internal-reference' and u['scope']=='cited-bibliography-entry':
  node=False;reason='Bibliography cited-by navigation backlink; the cited work identity is recorded in bibliography-entry bib.bib3.'
 elif kind=='internal-reference' and '::h' in ident:
  node=False;reason='Heading navigation reference; the theorem heading and substantive theorem/proof units are separately inventoried.'
 rows.append({'raw_unit_id':ident,'kind':kind,'scope':u['scope'],'original_lines':u['original_lines'],'disposition':'NODE' if node else 'EXCLUDED','raw_node_id':'raw:'+ident if node else None,'reason':reason,'references':u['references']})
(out/'phase1-raw-unit-dispositions.json').write_text(json.dumps({'schema':1,'status':'raw-first-frozen','interpretation':'Raw-level exhaustive inventory dispositions; semantic graph and target alignment deferred until phase 2 whitelist authorization.','rows':rows,'counts':dict(Counter(r['disposition'] for r in rows)),'kind_counts':dict(Counter(r['kind'] for r in rows))},indent=2,ensure_ascii=False)+'\n')
inputs=[
'AGENTS.md',
'docs/proof-digestion-protocol.md',
'docs/theorem-publication-protocol.md',
'.agents/skills/astis-source-dependency-audit/SKILL.md',
'.astis/huanjian-resume-20261103/2610.20492v1.html']
manifest={'schema':1,'phase':'phase1-raw-first','authority':'Parent assignment authorizes these source/process inputs only. No candidate/target/seal/implementation authority yet.','inputs':[{'path':p,'sha256':hashlib.sha256((root/p).read_bytes()).hexdigest()} for p in inputs], 'raw_source_ranges_read':[[1054,1500],[3837,4134],[1847,1864]],'other_exposure':['Parent task message with raw source locator/hash, anchor IDs, scope and independence restrictions; no candidate theorem or other agent mathematics.','Tool definitions and global system/developer instructions.','Own extraction script, own raw source reading and own phase-1 artifacts.'], 'not_inspected':['Statement Seal or target signature','candidate/source-graph/frontier/ledger from another worker','Lean source or APIs','lessons or implementation','prior audit or handoff packets','other agent mathematical findings'],'actions':['Read files listed under inputs','Verified original HTML SHA256','Extracted bounded raw source with Python standard-library HTML parser','Wrote only artifacts under the assigned independent-source-graph directory'],'not_run':['Lean/compiler/build','ASTIS API or harness','network or external reference fetch','shared repository mutation','GUI/OS automation','other-worker file inspection'],'line_convention':'Original HTML 1-based lines. Extracted fragments preserve the line range with LF normalization; original source digest is over original bytes.','self_review_limit':'This extractor does not approve its own final mathematical coverage. Independent challenge remains required.'}
(out/'phase1-exposure-input-manifest.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False)+'\n')
artifacts=[p for p in out.iterdir() if p.is_file() and p.name!='phase1-freeze.json']
freeze={'schema':1,'status':'PHASE1_FROZEN_STOPPED','source_sha256':inventory['source_sha256'],'raw_units':len(inventory['units']),'dispositions':dict(Counter(r['disposition'] for r in rows)),'artifacts':[{'path':str(p.relative_to(root)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in sorted(artifacts)],'next_authority':'Stop. Await exact phase-2 seal whitelist; do not inspect other packet material. Preserve all listed artifacts unchanged.'}
(out/'phase1-freeze.json').write_text(json.dumps(freeze,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'raw_units':freeze['raw_units'],'dispositions':freeze['dispositions'],'freeze_sha256':hashlib.sha256((out/'phase1-freeze.json').read_bytes()).hexdigest(),'cognition_sha256':hashlib.sha256((out/'phase1-raw-cognition.md').read_bytes()).hexdigest(),'inventory_sha256':hashlib.sha256((out/'raw-unit-inventory.json').read_bytes()).hexdigest(),'manifest_sha256':hashlib.sha256((out/'phase1-exposure-input-manifest.json').read_bytes()).hexdigest()},indent=2))
