from pathlib import Path
import json,hashlib,stat,collections,datetime
ROOT=Path(__file__).resolve().parent;REPO=ROOT.parents[2];I=ROOT/'input-originals'
sha=lambda b:hashlib.sha256(b).hexdigest()
dump=lambda n,x:(ROOT/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
inputs=json.loads((ROOT/'input-manifest.json').read_bytes())['inputs']+json.loads((ROOT/'additional-input-manifest.json').read_bytes())['inputs'];labels={x['label']:x for x in inputs}
pres=[]
for item in inputs:
    b=(ROOT/item['snapshot_path']).read_bytes();orig=Path(item['original_path']).read_bytes();mode=format(stat.S_IMODE(Path(item['original_path']).stat().st_mode),'04o')
    assert sha(b)==item['raw_sha256'] and len(b)==item['bytes'] and orig==b and mode==item['original_mode']
    pres.append({'path':item['original_path'],'sha256_unchanged':True,'original_mode_unchanged':True,'snapshot_raw_sha256':sha(b)})
dump('original-input-preservation.json',{'checked_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'records':pres,'scope':'Only copied input snapshots are frozen by this task. Original production/canonical/preproof/public metadata inputs are read-only and are not chmodded or changed.'})
def check_span(rec,raw=None):
    path=rec.get('file') or rec.get('original_file');b=Path(path).read_bytes() if raw is None else raw;s=b.decode();a,z=rec.get('character_span_0based_halfopen');ba,bz=rec.get('utf8_byte_span_0based_halfopen');frag=b[ba:bz]
    assert sha(b)==rec['file_raw_sha256'] and s[a:z].encode()==frag and sha(frag)==rec['raw_span_sha256']
    assert rec['lf_lines_1based_inclusive']==[s.count('\n',0,a)+1,s.count('\n',0,z-1)+1]
    assert rec['terminal_LF_included']==frag.endswith(b'\n')
    return frag
canonical=json.loads((ROOT/'canonical-declaration-inventory.json').read_bytes())['records']
actual=json.loads((ROOT/'actual-kernel-constant-inventory.json').read_bytes());used=set().union(*(set(x['direct_proof_term_constants']) for x in actual['owned_declarations']))
for rec in canonical:
    frag=check_span(rec['span']);assert frag==(ROOT/rec['snapshot_path']).read_bytes() and rec['name'] in used
for rec in json.loads((ROOT/'owned-declaration-spans.json').read_bytes()):
    for field in ['declaration_span','signature_span','proof_body_span']:check_span(rec[field])
for rec in json.loads((ROOT/'lean-proof-region-spans.json').read_bytes()).values():check_span(rec)
log=(I/'kernel-log.log').read_bytes();receipt=json.loads((I/'kernel-receipt.json').read_bytes());assert sha(log)==receipt['log_sha256'] and receipt['exit_code']==0
for rec in actual['owned_declarations']:check_span(rec['raw_log_record_span'],log)
for rec in actual['observed_first_public_ASTIS_parents']:check_span(rec['raw_log_span'],log)
owned=json.loads((I/'actual-owned-inventory.json').read_bytes())
assert owned['actual_producer_sha256']==labels['production']['raw_sha256'] and owned['actual_Test_sha256']==labels['consumer']['raw_sha256']
assert {x['consumer']:x['first_public_ASTIS_parents'] for x in actual['observed_first_public_ASTIS_parents']}==owned['actual_first_public_ASTIS_parents']
assert len(actual['owned_declarations'])==4 and len(actual['generated_owned_providers'])==2
classifications=json.loads((ROOT/'all-actual-constant-classifications.json').read_bytes())['records'];assert len(classifications)==len(used)==554 and {x['name'] for x in classifications}==used
sourcepins=json.loads((I/'source-pins.json').read_bytes());sp={x['id']:x for x in sourcepins['elements']};labels_by_section={'S4.SS1':'raw-S4SS1','S4.SS2':'raw-S4SS2','A3.SS2':'raw-C2'};checked=set()
for sec in sourcepins['sections']:
    b=(ROOT/labels[labels_by_section[sec['id']]]['snapshot_path']).read_bytes();s=b.decode();sa,sz=sec['utf8_span_0based_halfopen'];sca,scz=sec['char_span_0based_halfopen'];line0=sec['lf_lines_1based_inclusive'][0]
    assert sha(b)==sec['sha256_raw_utf8']
    for p in sourcepins['elements']:
        a,z=p['utf8_span_0based_halfopen'];ca,cz=p['char_span_0based_halfopen']
        if sa<=a and z<=sz:
            frag=b[a-sa:z-sa];assert sha(frag)==p['sha256_raw_utf8'] and s[ca-sca:cz-sca].encode()==frag
            assert p['lf_lines_1based_inclusive']==[line0+s.count('\n',0,ca-sca),line0+s.count('\n',0,cz-sca-1)]
            checked.add(p['id'])
assert len(checked)==520
proposal=json.loads((ROOT/'source-to-lean-map.v1.json').read_bytes());nodes={x['id'] for x in json.loads((I/'source-graph-v2.json').read_bytes())['nodes']};cannames={x['name'] for x in canonical}
for row in proposal['mapping_records']:
    assert set(row['source_graph_nodes'])<=nodes
    for rec in row['source_spans']:assert rec['raw_pin']==sp[rec['source_id']]
    for rec in row['lean_regions']:check_span(rec['span'])
    for rec in row['canonical_mathlib_actual_facts']:assert rec['name'] in cannames and rec['name'] in used;check_span(rec['declaration_span'])
exposition=json.loads((ROOT/'candidate-exposition-source-map.json').read_bytes());assert len(exposition['steps'])==6 and exposition['private_application_full_code_in_step6']
for step in exposition['steps']:
    frag=check_span(step['contiguous_lean_span']);assert sha(frag)==step['exact_code_sha256']
    literal=check_span(step['exact_json_string_span']);assert json.loads(literal).encode()==frag
assert exposition['steps'][-1]['exact_code_sha256']==labels['consumer']['raw_sha256']
failures=[]
for path in sorted((ROOT/'commands').glob('*.receipt.json')):
    rec=json.loads(path.read_bytes());prefix=path.name[:-len('.receipt.json')]
    for stream in ['stdout','stderr']:
        b=(path.parent/(prefix+'.'+stream)).read_bytes();assert len(b)==rec[stream+'_bytes'] and sha(b)==rec[stream+'_sha256']
    for script in rec['script_inputs']:assert sha((REPO/script['path']).read_bytes())==script['sha256']
    if rec['returncode']!=0:failures.append({'label':rec['label'],'returncode':rec['returncode'],'stdout':str(path.parent/(prefix+'.stdout')),'stderr':str(path.parent/(prefix+'.stderr')),'classification':'exact-symbol locator missing-path/no-match; no theorem proof was attempted'})
assert len(failures)==4
dump('exposure-failures-and-scope.json',{'captured_locator_nonzero_exits':failures,'canonical_span_corrections':'canonical-span-tightening-record.json; five initial overrun raw fragments and first inventory retained','tool_output_truncations_observed':[],'kernel_log_and_receipt_normalized':False,'read_scope':'Own source graphs/raw snapshots/repaired graph; exact target+Test; exact bounded kernel probe/log/receipt; canonical declarations selected from actual constants; four subsequently authorized exposition/publication/inventory inputs.','authorized_metadata_paths_not_followed':['ATLAS_ROOT path in exact kernel receipt','neutral review input path in exact publication draft record'],'ATLAS_contents_index_projection_read':False,'other_role_review_or_root_plan_read':False,'Lean_proof_or_API_search_or_target_changes':False,'publication_Git_ledger_Goal_or_status_mutation':False,'new_sourceV_topology_exposition_or_publication_verdict':False,'preproof_limits':'Earlier frozen source-phase exposure/capture limitations remain unchanged and are not erased. Current authorized target exposition makes this a mapping-author phase, not an anti-anchored independent verdict.','pretraining_limit':'Ordinary pretrained mathematical knowledge; no zero-pretraining or absolute-pristine claim.'})
summary={'status':'AUTHOR_MAPPING_INTEGRITY_CHECKS_ONLY','original_input_snapshots_and_hashes_checked':len(inputs),'exact_source_fragments_checked':len(checked),'exact_canonical_actual_declaration_spans_checked':len(canonical),'all_actual_direct_constants_classified':len(used),'exact_Lean_mapping_records_checked':len(proposal['mapping_records']),'candidate_exact_contiguous_code_blocks':len(exposition['steps']),'actual_kernel_log_and_parent_metadata_bound':True,'captured_locator_nonzero_exits':len(failures),'sourceV_or_publication_approval':False,'new_Lean_execution':False}
dump('mapping-integrity-summary.json',summary);print(json.dumps(summary,indent=2))
