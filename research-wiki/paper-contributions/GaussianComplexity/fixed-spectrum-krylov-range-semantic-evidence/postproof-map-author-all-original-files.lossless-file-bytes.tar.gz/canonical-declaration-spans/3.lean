theorem degree_X : degree (X : R[X]) = 1 :=
  degree_monomial _ one_ne_zero
