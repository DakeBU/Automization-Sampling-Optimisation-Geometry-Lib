"""Reuse the kernel inspector with independent propositions from the preproof seal."""
from pathlib import Path
import hashlib

workspace = Path(__file__).resolve().parent
header = 'import Tests.GaussianComplexityFixedSpectrumRadialFourthMoment\nopen MeasureTheory ProbabilityTheory Lean\nopen scoped Matrix.Norms.L2Operator\nset_option autoImplicit false\n\n'
for name, filename, digest in [
    ('ExpectedProducer', 'producer-signature.draft.txt', '249edf1f3d15639eca0c0db2f827bca4981faf3648653ef83fb731abe564af32'),
    ('ExpectedPrivate', 'consumer-signature.draft.txt', 'd177e72a66ec143642b0518887a170f7906d9fc528a87ea399d02ee00842bfac'),
]:
    raw = (workspace / filename).read_bytes()
    assert hashlib.sha256(raw).hexdigest() == digest
    binders, body = raw.decode().split(' :\n', 1)
    header += f'def {name} : Prop := ∀ {binders},\n{body}\n'
previous = Path('.astis/huanjian-gc-truncated-radial-covariance-20261111/TruncatedRowMomentKernelProbe.lean').read_text()
inspector = 'run_cmd do\n' + previous.split('run_cmd do\n', 1)[1]
for old, new in [
    ('FixedSpectrumTruncatedRowMoment', 'FixedSpectrumRadialFourthMoment'),
    ('actual_truncated_row_second_moment', 'actual_radial_fourth_moment_matrix'),
    ('actual_truncated_matrix_summand_mean', 'actual_truncated_summand_second_moment_bound'),
    ('AutoSamplingTheory.TechnicalLemmas.Probability.StdGaussianMoment.integrable_norm_sq_and_integral_stdGaussian',
     'AutoSamplingTheory.TechnicalLemmas.StochasticProcesses.GaussianFourthMoment.integral_pow_four_gaussianReal_zero'),
]:
    assert old in inspector
    inspector = inspector.replace(old, new)
output = workspace / 'RadialFourthMomentKernelProbe.lean'
with output.open('x') as out:
    out.write(header + inspector)
print(str(output))
