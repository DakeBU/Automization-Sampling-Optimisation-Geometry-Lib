python3 - <<'PY'
from pathlib import Path
import hashlib,json
p=Path('.astis/semantic-neutral-20261110/src_d63b90/phase2-inputs/manifest.json');b=p.read_bytes();h=hashlib.sha256(b).hexdigest();assert h=='67444172f33625e9c495418a47a574e41c59907e8bb6bd73ccda7b7047200701';print('raw_sha256',h);print(b.decode())
q=Path('.astis/semantic-neutral-20261110/src_d63b90/phase2-inputs/selective-input.json');j=json.loads(q.read_text())
for name,value,digest in [('source.original_text',j['source']['original_text'],j['source']['text_sha256']),('lean_statement.statement',j['lean_statement']['statement'],j['lean_statement']['statement_sha256']),('blind_reconstruction.text',j['blind_reconstruction']['text'],j['blind_reconstruction']['text_sha256'])]:
    actual=hashlib.sha256(value.encode()).hexdigest();print(name,actual,'matches',actual==digest);assert actual==digest
PY
