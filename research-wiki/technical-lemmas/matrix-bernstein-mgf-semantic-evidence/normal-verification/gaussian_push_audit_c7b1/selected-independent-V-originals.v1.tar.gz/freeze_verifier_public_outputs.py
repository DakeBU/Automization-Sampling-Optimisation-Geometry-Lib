#!/usr/bin/env python3
"""Freeze explicit public verifier originals; private preservation maps excluded."""
from pathlib import Path
import hashlib
import json

OWN = Path(__file__).resolve().parent
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
payload = json.loads((OWN / 'VERIFIED-evidence.full.v2.json').read_text())
event = json.loads((OWN / 'VERIFIED-exact-canonical-append.jsonl').read_text())
receipt = json.loads((OWN / 'normal-V-actual-process-receipt.v1.json').read_text())
summary = json.loads((OWN / 'normal-V-preservation-summary.v1.json').read_text())
assert event['evidence'] == payload and event['worker_id'] == payload['verifier_id']
assert receipt['exit_code'] == 0 and receipt['observed_target_VERIFIED_events_after_process'] == 1
assert summary['canonical_append_events'] == 1
assert sha(OWN / 'VERIFIED-exact-canonical-append.jsonl') == summary['canonical_append_sha256']
assert sha(OWN / 'VERIFIED-evidence.full.v2.json') == receipt['full_payload']['sha256']
for key in ['stdout', 'stderr']:
    assert sha(OWN / receipt[key]['path']) == receipt[key]['sha256']

readme = OWN / 'VERIFIER-CUSTODY-AND-SCOPE.md'
with readme.open('x') as f:
    f.write('''# Independent normal VERIFIED custody\n\nThe actual normal API verifier is `/root/gaussian_push_audit_c7b1`, distinct from proving owner `huanjian_20261114_matrix_bernstein_mgf` and ROOT. After its own acceptance of exact immutable pre-V commit6abc79ed4c012c1d506c17b9824257769c18c635, this actor executed exactly one authorized `transition_advance` call. The actual OS process exited0; the canonical ledger gained exactly one target PROVED_LOCAL→VERIFIED event at2026-11-14T09:55:00+00:00. ROOT did not invoke this API. No retry, STABILIZING, merge or site operation was performed. Do not rerun the spent API driver.\n\n`VERIFIED-evidence.full.v2.json` is the exact public full payload used by the API. All24 original PL key/value trees are retained inline, including their historical runtime-pending snapshot. New post-PL fields bind accepted current runtime/source evidence and exact6abc. `VERIFIED-exact-canonical-append.jsonl` is the actual raw single appended canonical line, not a reformatted reconstruction. The stdout/stderr files are actual subprocess OS streams, with their independent process receipt.\n\nThe new payload field `post_PL_carrier_acceptance.portable_byte_review.file` is a leaf locator relative to this explicit verifier evidence bundle; resolve it through the selected manifest. Other carried proof/source/runtime paths refer to the immutable repository tree at6abc. Every selected leaf has its original relative path/bytes/SHA. The manifest is separately carried and does not self-hash.\n\nCore review checked exact P/T/lesson/publication bytes, all24 original PL values and19 explicit PL evidence blob references. The frontier failure was real: a rich focused_checks dictionary was invalid where a list was required. The repair preserved that entire bundle and original PL bytes, and used only two real original compile receipts for the list. Original failure, repair and actual refreshed frontier/contributor PASS logs were independently read. Refreshed metadata gates belong to56f8 worktree state, earlier four CLI gates to2cc25; no new gate execution at6abc is claimed.\n\nNative compilation/type+value/kernel/standard-axiom evidence belongs to archived Git4869 bytes. ROOT original Lean checks ran at107eb with those exact worktree bytes. Neither later6abc nor any export/carrier/metadata commit is retroactively called a newly compiled HEAD. Source-first/reader review remains credited to the distinct mgf_fresh_source_5b7e actor.\n\nPortable runtime originals were mechanically packed by ROOT, not recreated by the independent actors. A helper independently streamed all360/737/335 selected tar members against exact manifests/custody; its byte-only audit did not authorize V. A bounded public projection omits the helper original before/after fingerprint envelope, while retaining exact member/hash results and the static documentation false-positive adjudication. The original helper report remains local unchanged.\n\nPrivate before/after preservation maps compared all tracked worktree bytes/modes, branch/HEAD/index, all foreign advance/discovery states, discovery ledger bytes and the original advance ledger prefix. Exactly the target canonical one-line append changed; all other protected identities remained equal during this actual operation. Full snapshots and any global private fingerprints remain local, excluded from the explicit public selection. The small preservation summary reports equalities and exact append identity only. It describes this operation, not later ROOT changes.\n\nAcceptance is bounded to the exact local reader-v2/native-v4 desktop/mobile workflows. Default-fit graph labels remain small; zoomed SVG labels may be ellipsized and mobile nodes clipped; exact IDs are read through the actual detail inspector. The snapshot is pre-V, not a production/post-V render. There is no claim of physical phone/touch, whole-site deployment, shared integration, main merge, purification or whole Goal completion.\n''')

names = [
    'preflight_carrier.py', 'pre-V-carrier-core-review.v1.json',
    'pre-V-carrier-portable-byte-review.public.v1.json', 'pre-V-independent-acceptance.v1.json',
    'VERIFIED-evidence.full.v2.json', 'execute_normal_V_once.py',
    'run_normal_V_with_raw_receipt.py', 'normal-V-api-attempt-begun.json',
    'normal-V.stdout.raw', 'normal-V.stderr.raw', 'normal-V-actual-process-receipt.v1.json',
    'VERIFIED-exact-canonical-append.jsonl', 'normal-V-preservation-summary.v1.json',
    'VERIFIER-CUSTODY-AND-SCOPE.md', 'freeze_verifier_public_outputs.py']
files = []
for name in names:
    p = OWN / name
    assert p.is_file() and not p.is_symlink() and '.private.' not in name
    files.append({'path': name, 'bytes': p.stat().st_size, 'sha256': sha(p)})
manifest = {
    'schema': 'independent-weighted-MGF-one-normal-V-explicit-public-originals-v1',
    'status': 'EXACT_ONE_INDEPENDENT_NORMAL_V_COMPLETED_WITH_PRESERVATION',
    'original_local_root': str(OWN), 'portable_root_locator': 'independent-verifier-6abc',
    'files': files, 'file_count': len(files), 'total_bytes': sum(x['bytes'] for x in files),
    'verified_commit': payload['verified_commit'], 'actual_verifier_actor': payload['verifier_id'],
    'canonical_append_sha256': summary['canonical_append_sha256'],
    'payload_relative_leaf_resolution': {
        'field': 'post_PL_carrier_acceptance.portable_byte_review.file',
        'base': 'this explicit verifier evidence bundle root',
        'path': 'pre-V-carrier-portable-byte-review.public.v1.json'},
    'selection': 'Only15 explicitly listed original files. No directory scan/packing, no private guard inclusion.',
    'excluded_private_local_files': ['before.private.guard.json', 'after.private.guard.json'],
    'unselected_draft': 'VERIFIED-evidence.full.v1.json was a pre-container-review preparation output, not the actual API payload.',
    'no_full_guards_or_global_private_fingerprints_exported': True,
    'manifest_self_inclusion': False,
    'normal_API_invocations': 1, 'normal_API_retries': 0,
    'new_Chrome_Lean_or_old_four_CLI_runs': 0,
    'no_STABILIZING_merge_site_purification_or_Goal_completion': True}
out = OWN / 'normal-V-public-selected-originals.manifest.v1.json'
with out.open('x') as f:
    json.dump(manifest, f, ensure_ascii=False, indent=2)
    f.write('\n')
print(json.dumps({'manifest': str(out), 'sha256': sha(out), 'file_count': len(files),
    'total_bytes': manifest['total_bytes'], 'exact_append_sha256': summary['canonical_append_sha256'],
    'actual_payload_sha256': sha(OWN / 'VERIFIED-evidence.full.v2.json'),
    'preservation_summary_sha256': sha(OWN / 'normal-V-preservation-summary.v1.json'),
    'actual_receipt_sha256': sha(OWN / 'normal-V-actual-process-receipt.v1.json')}, indent=2))
