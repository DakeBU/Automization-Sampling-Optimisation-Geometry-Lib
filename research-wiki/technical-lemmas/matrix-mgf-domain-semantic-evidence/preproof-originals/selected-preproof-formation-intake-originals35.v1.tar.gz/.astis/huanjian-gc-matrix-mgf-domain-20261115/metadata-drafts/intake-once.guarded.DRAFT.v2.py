"""UNEXECUTED ROOT-review draft: three normal advance calls, no Discovery/cell writes.
Default prints a plan. --execute requires a separately authored exact-input contract.
No retry/rollback: inspect partial actual state after any marked attempt.
"""
from pathlib import Path
import argparse, datetime, hashlib, json, os, subprocess, sys

A = "ASTIS-SA-20261115-MatrixExponentialDomain"
O = "huanjian_20261115_matrix_exponential_domain"
C = "ASTIS-SHARED-REAL-MATRIX-EXPONENTIAL-DOMAIN"
W = ".astis/huanjian-gc-matrix-mgf-domain-20261115"
SEAL = "1b52776e9793f302109cb649dd0c82c666193086aa7546006e36651ee389e638"
BINDER = "ab17ddb4d2b402194af7b4668054d580956a80a103da938a25978d94e03e7744"
PUBLIC = "eaca3074c0599067e0d6c6e6d9ab13a42030e780"
AL = "runs/substantive_advances.jsonl"
DL = "runs/substantive_discoveries.jsonl"
sha = lambda b: hashlib.sha256(b).hexdigest()

def check(ok, message):
    if not ok:
        raise RuntimeError(message)

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--execute", action="store_true")
    ap.add_argument("--contract", type=Path)
    args = ap.parse_args()
    if not args.execute:
        print("DRAFT ONLY: ROOT must review/install the cell and seal, bind real SG/TC admission, then explicitly authorize exactly proposal/CLAIMED/EXPLORING. Actual SG/TC/accepted-overlay are hard-pinned in this v2 draft. No Discovery, PL, V, Goal, cell, source, archive, or Git writes by this script.")
        return
    check(args.contract is not None, "An actual ROOT exact-input contract is required")
    root = Path(__file__).resolve().parents[3]
    draft = root / W / "metadata-drafts"
    k = json.loads(args.contract.read_bytes())
    check(k["advance_id"] == A and k["owner"] == O, "Wrong target/owner")
    env = dict(os.environ, GIT_OPTIONAL_LOCKS="0", PYTHONDONTWRITEBYTECODE="1")
    def git(*a):
        return subprocess.check_output(["git", *a], cwd=root, env=env)
    def path(p):
        x = root / p
        check(not x.is_symlink() and x.resolve().is_relative_to(root), "Unsafe input path")
        return x
    def pinned(p, h):
        b = path(p).read_bytes()
        check(sha(b) == h, "Input identity mismatch: " + p)
        return b
    check(k["expected_public_ref_oid"] == PUBLIC, "Unexpected public baseline")
    def git_identity():
        return [git("rev-parse", "HEAD"), git("symbolic-ref", "-q", "HEAD"),
                git("rev-parse", k["public_ref"]), git("ls-files", "--stage", "-z"),
                path(git("rev-parse", "--git-path", "index").decode().strip()).read_bytes()]
    before_git = git_identity()
    check(before_git[0].decode().strip() == k["expected_HEAD"], "ROOT HEAD changed")
    check(before_git[2].decode().strip() == PUBLIC, "Public ref changed")
    pinned(W + "/statement-seal.sealed.v1.json", SEAL)
    pinned(W + "/binder-definition-audit.sealed.v1.json", BINDER)
    # Exact original artifacts; identities are role deliveries, not invented JSON fields.
    sg_file = ".astis/semantic-neutral-20261115/matrix_domain_sg_48bc/source-graph.v1.json"
    sg_sha = "884f7970347129bf75f3a15feb6bcbcb4c0c427a2cdefbf3a5cc90abef75cf09"
    bridge_file = ".astis/semantic-neutral-20261115/matrix_domain_sg_48bc/author-derived-bridges.v1.json"
    bridge_sha = "3a66bd5bef0858fe57a01e15231851808f0c54da196cba918e012db7283dd9c1"
    tc_file = ".astis/semantic-neutral-20261115/matrix_domain_tc_79ad/topology-review.v1.json"
    tc_sha = "7d02c7990fd8e25172e643be800380011745d5377321bd01ec142fb3f4a4a6ad"
    verdict = "ADMIT_EXACT_SEAL_AND_SOURCE_TOPOLOGY_WITH_EXPLICIT_ACCEPTED_V2_OVERLAY"
    overlay_file = W + "/source-topology-repair.proposed-v2.json"
    overlay_sha = "9ed5bb1da14afee5ba43c074456293fb706e7d6d60dec132c97fc43de34362c4"
    admission_file = W + "/preproof-admission.v1.json"
    admission_sha = "2d601df41af7d4b03931a05d9c001edee78dc73aac653974eb8deddffad8bb10"
    sg = json.loads(pinned(sg_file, sg_sha))
    pinned(bridge_file, bridge_sha)
    tc = json.loads(pinned(tc_file, tc_sha))
    overlay = json.loads(pinned(overlay_file, overlay_sha))
    admission = json.loads(pinned(admission_file, admission_sha))
    check(sg["seal_sha256"] == SEAL, "SG exact seal mismatch")
    check(tc["verdict"] == verdict and tc["P_T_bytes_equal_exact_seal"] is True
          and tc["blocking_findings_after_overlay"] == [], "Actual TC admission mismatch")
    expected_inputs = {(W + "/statement-seal.sealed.v1.json", SEAL),
                       (W + "/binder-definition-audit.sealed.v1.json", BINDER),
                       (sg_file, sg_sha), (bridge_file, bridge_sha), (overlay_file, overlay_sha)}
    check(expected_inputs <= {(x["path"], x["sha256"]) for x in tc["inputs"]}, "TC input closure mismatch")
    check(overlay["original_source_graph_file"] == sg_file and overlay["original_source_graph_sha256"] == sg_sha
          and overlay["original_bridge_file"] == bridge_file and overlay["original_bridge_sha256"] == bridge_sha
          and overlay["originals_preserved"] is True and overlay["sealed_statement_or_definition_changes"] == 0,
          "Accepted overlay original binding mismatch")
    check(admission["seal_sha256"] == SEAL and admission["independent_report"] == tc_file
          and admission["independent_report_sha256"] == tc_sha and admission["independent_verdict"] == verdict
          and admission["source_graph_sha256"] == sg_sha and admission["author_bridge_sha256"] == bridge_sha
          and admission["accepted_overlay"] == overlay_file and admission["accepted_overlay_sha256"] == overlay_sha
          and admission["target_proof_calls_before_admission"] == 0, "ROOT actual-admission pointer mismatch")
    # ROOT's pointer transcribes the delivered distinct TC actor; SG/TC originals
    # have no synthetic actor fields. Pinning ROOT's transcription is not a new verdict.
    check(admission["independent_actor"] == "/root/matrix_domain_topology_79ad", "ROOT actor transcription mismatch")
    proposal = json.loads(pinned(W + "/metadata-drafts/proposal-kwargs.candidate.v1.json", k["proposal_sha256"]))
    check(proposal["advance_id"] == A and proposal["created_by"] == O and proposal["frontier_cell"] == C, "Wrong proposal")
    seal = json.loads(path(W + "/statement-seal.sealed.v1.json").read_bytes())
    cell_path = "research-wiki/frontier-cells/" + C + ".json"
    cell = json.loads(pinned(cell_path, k["installed_cell_sha256"]))
    check(cell["cell_id"] == C and cell["status"] in ("queued", "claimed"), "Install reviewed initial cell first")
    check(cell["target_statement"] == seal["canonical_producer"]["exact_proposition"] and cell["private_consumer_statement"] == seal["private_real_consumer"]["exact_proposition"], "Cell statement differs from seal")
    check(not cell.get("draft_only") and not cell.get("registration_pending"), "ROOT must explicitly install reviewed metadata")
    for key in ("canonical_producer", "private_real_consumer"):
        check(not path(seal[key]["file"]).exists(), "Unexpected prior target implementation")
    # Keep preservation inventories in memory; do not emit private maps/guards.
    def tracked_snapshot():
        return {p: (path(p).lstat().st_mode, sha(path(p).read_bytes()))
                for p in git("ls-files", "-z").decode().split("\0") if p and p != AL}
    before_tracked = tracked_snapshot()
    before_frontiers = {str(p.relative_to(root)): sha(p.read_bytes())
                        for p in (root / "research-wiki/frontier-cells").glob("*.json")}
    old_a, old_d = path(AL).read_bytes(), path(DL).read_bytes()
    def rows(b):
        check(not b or b.endswith(b"\n"), "Incomplete ledger tail; do not auto-recover")
        return [json.loads(x) for x in b.splitlines()]
    rows(old_a); rows(old_d)
    sys.dont_write_bytecode = True
    sys.path.insert(0, str(root))
    from tools import astis_advance as api
    old_as = api.current_advances()
    old_ds = api.current_discoveries()
    check(path(AL).read_bytes() == old_a and path(DL).read_bytes() == old_d, "Read unexpectedly recovered ledger")
    check(A not in old_as, "Target already exists; never retry automatically")
    proposal_object = api.AdvanceProposal(**proposal)
    proposal_object.validate()
    marker = draft / "intake-attempted.once.PRIVATE.json"
    with marker.open("x") as f:
        os.chmod(marker, 0o600)
        json.dump({"utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
                   "advance_id": A, "contract_sha256": sha(args.contract.read_bytes()),
                   "calls": ["proposal", "CLAIMED", "EXPLORING"], "Discovery_calls": 0}, f)
        f.write("\n")
    evidence = {"preproof_source_admission": {"root_pointer": admission_file, "root_pointer_sha256": admission_sha,
                  "source_graph": sg_file, "source_graph_sha256": sg_sha,
                  "independent_report": tc_file, "independent_report_sha256": tc_sha, "actual_verdict": verdict,
                  "accepted_overlay": overlay_file, "accepted_overlay_sha256": overlay_sha},
                "target_proof_not_started": True, "no_new_conceptual_Discovery": "ROOT scoped none-found author audit; may be reopened by later proof/source review"}
    api.propose_advance(proposal_object)
    api.transition_advance(A, "CLAIMED", worker_id=O, evidence=evidence)
    api.transition_advance(A, "EXPLORING", worker_id=O,
                           modes=["proof-design", "library-retrieval", "compiler-diagnosis"], evidence=evidence)
    new_a, new_d = path(AL).read_bytes(), path(DL).read_bytes()
    check(new_a.startswith(old_a) and new_d == old_d, "Old ledger prefix/Discovery changed")
    added = rows(new_a[len(old_a):])
    check(len(added) == 3 and all(x["advance_id"] == A for x in added), "Unexpected advance append")
    new_as = api.current_advances()
    check({q:v for q,v in new_as.items() if q != A} == old_as and api.current_discoveries() == old_ds, "Foreign replay state changed")
    check(new_as[A]["state"] == "EXPLORING" and new_as[A]["owner_id"] == O, "Unexpected target state/owner")
    check(git_identity() == before_git and tracked_snapshot() == before_tracked, "Git/index/other tracked bytes changed")
    check({str(p.relative_to(root)): sha(p.read_bytes()) for p in (root / "research-wiki/frontier-cells").glob("*.json")} == before_frontiers, "A frontier changed")
    result = {"advance_id": A, "state": "EXPLORING", "normal_advance_calls": 3,
              "Discovery_calls": 0, "normal_PL": 0, "normal_V": 0,
              "old_ledger_prefix_preserved": True, "foreign_states_and_frontiers_preserved": True,
              "HEAD_branch_publicref_index_and_other_tracked_bytes_preserved": True,
              "cell_updated_by_script": False}
    out = draft / "intake-actual-result.PRIVATE.json"
    with out.open("x") as f:
        os.chmod(out, 0o600)
        json.dump(result, f, indent=2)
        f.write("\n")
    print(json.dumps(result))

if __name__ == "__main__":
    main()
