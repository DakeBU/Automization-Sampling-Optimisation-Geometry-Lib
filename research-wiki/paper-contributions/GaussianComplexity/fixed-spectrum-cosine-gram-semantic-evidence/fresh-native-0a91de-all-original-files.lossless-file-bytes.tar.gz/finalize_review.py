import json, re, shutil
from verify import *

# Preserve failed checker implementation and raw outputs instead of retrying invisibly.
bad='failed-attempts/bootstrap-attempt1/'
put(bad+'command.txt','python3 '+str(D.relative_to(R)/'verify.py')+'\n')
shutil.copyfile(D/'verify.bootstrap-attempt1.py',put(bad+'verify.py',b''))
for suffix in ['stdout','stderr','receipt.json']:
    shutil.copyfile(D/('raw/candidate_matching_seal_audit_paths.'+suffix),put(bad+'git-ls-tree.'+suffix,b''))
js(bad+'diagnosis.json',{'exit_code':128,'cause':'Verifier path discovery used unsupported Git ls-tree glob pathspec magic.',
   'repair':'Used the two exact allowed seal/audit paths supplied by parent. No candidate mathematical change.'})
bad='failed-attempts/shell-glob-discovery/'
put(bad+'command.txt',"python3 -c '<print first22000 Unicode characters of json.dumps(source-to-lean-map-v1.json, ensure_ascii=False, indent=2)>' && rg -n 'def .*lesson|def .*proof|def .*lean|declaration_lessons|reading_layout' website/scripts/astis_publication* website/scripts/*publication* tools/astis_publication.py\n")
rawmap=json.loads((D/'inputs'/E/'source-to-lean-map-v1.json').read_text())
put(bad+'stdout.raw.txt',json.dumps(rawmap,ensure_ascii=False,indent=2)[:22000]+'\n')
put(bad+'stderr.raw.txt','zsh:1: no matches found: website/scripts/astis_publication*\n')
js(bad+'diagnosis.json',{'exit_code':1,'cause':'Verifier shell pathname expansion found no website/scripts/astis_publication*; bounded path discovery resumed with rg --files.',
   'stdout_origin':'Exact deterministic map prefix printed by the real initial command; full unchanged map is retained under inputs.',
   'repair':'Used exact discovered declaration_lessons.py, inline_lean.py and astis_site.py paths. No renderer or candidate change.'})
js('failed-attempts/kernel-attempt1/diagnosis.json',{'exit_code':1,
  'causes':['Verifier selected unsupported pp.width and pp.maxDepth options.',
    'Verifier initially classified public-prefix compiler certificates as first-public ASTIS mathematical parents before module-provenance ownership recursion.'],
  'repair':'Removed unsupported display options and traversed module-owned generated certificates before stopping at the actual public producer or external public ASTIS declaration.',
  'scope':'Verifier-only repair; exact failed probe, script, compile stdout/stderr and receipt are retained. Candidate P/T/G never changed.'})

cfg=json.loads((D/'native-environment.json').read_text())
final=[]
for package in cfg['packages']:
    n=package['name']; p=pathlib.Path(package['path'])
    head=run('final_package_'+n+'_HEAD',['git','rev-parse','HEAD'],cwd=p).stdout.decode().strip()
    status=run('final_package_'+n+'_full_porcelain',['git','status','--porcelain=v1','--untracked-files=all'],cwd=p).stdout.decode()
    final.append({'name':n,'HEAD':head,'expected_HEAD':package['expected_rev'],'full_porcelain':status})
    assert head==package['expected_rev'] and status==''
assert sha(pathlib.Path(cfg['lean_binary']).read_bytes())==cfg['lean_binary_sha256']
js('final-dependency-state.json',{'all_nine_exact_HEAD_full_porcelain_clean':True,'packages':final,
   'lean_binary_unchanged':True,'manifest_sha256':cfg['manifest_sha256']})
bounded=[P,T,G,L,U,'lake-manifest.json','lean-toolchain']
run('final_bounded_tracked_inputs_unchanged',['git','diff','--exit-code',C,'--']+bounded)
for entry in json.loads((D/'input-hashes.json').read_text()):
    assert sha((D/'inputs'/entry['path']).read_bytes())==entry['sha256']
    assert sha(blob(entry['path']))==entry['sha256']

findings={
  'schema':'astis-independent-native-whole-module-static-reader-review/v1',
  'candidate':C,'parent':PARENT,'reviewer':'independent-native-reader-0a91de',
  'native_result':'PASS for this bounded immutable candidate',
  'reader_delivery':'HOLD',
  'input_hashes':{'P':'88f29461fcac1825675e417a1bc3f3952404f1cd08183d6e484162aefe9f5d54',
    'T':'90b43f488d3fe9b6c95d4c039d0f771ee5bfecdd699b72dfa52465643f0b0dee',
    'G':'c98c899bd8b596388ae433e9241a7827e01d29c3ffcc945719238fa2e96f7d60',
    'manifest':cfg['manifest_sha256'],'lean_binary':cfg['lean_binary_sha256']},
  'native_evidence':{'version':cfg['lean_version'],'all_nine_dependencies_exact_HEAD_and_full_porcelain_clean':True,
    'fresh_compile_order':[G,P,T,'IndependentKernel.lean','OwnedTypes.lean'],
    'fresh_build':'Git candidate bytes copied into new fresh-src; new fresh-olean began absent. LEAN_PATH is only fresh-olean plus the nine external dependency lib directories. Entire project .lake/build/lib/lean excluded. Producer --deps resolves canonical alias to the freshly rebuilt own output; consumer --deps resolves P there too.',
    'owned_constants':26,'authored_roots':2,'compiler_certificates':24,
    'all_owned_types':'Actual closed Prop types, recursively collected axioms limited to propext/Classical.choice/Quot.sound, all owned constants reachable from the actual roots.',
    'root_types':'Kernel checked against independently reconstructed closed Prop definitions from exact sealed signatures; no hidden bundles or extra caller premises.',
    'first_public_ASTIS_parents':{'P':['AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumGridAlias.actual_midpoint_grid_cosine_alias'],
       'T':['AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumCosineGram.actual_cosine_frame_gram']},
    'canonical_direct_observations':20,'locator_checks_passed':57,
    'whole_module_scan':'Complete P/T manually and mechanically examined; no fake closure, unsafe/axiom/sorry/admit/opaque/trivial wrapper. Actual consumer uses both produced Gram identities and derives actual Gaussian product integrability/moments and normalization internally.',
    'existing_parent_credit':'No new mathematical credit for rebuilding canonical GridAlias or for compiler-generated certificates.'},
  'reader_evidence':{'unchanged_production_renderer':True,'isolated_static_only':True,
     'concise_claim_assumptions_formula_preserved':True,'six_initially_closed_exact_code_and_formula_folds':True,
     'step6_full_actual_T_bytes':7494,'step6_sha256':'90b43f488d3fe9b6c95d4c039d0f771ee5bfecdd699b72dfa52465643f0b0dee',
     'private_theorem_starts_line':13,
     'actual_source_and_download_neighbors':'Standalone public statement/proof disclosures include controls. All six corresponding-step code disclosures have only summary/pre content, lacking adjacent copy/download/exact-module-source controls. Complete private consumer has a source citation at #L13 in provenance, but no adjacent step6 controls.',
     'hold_reason':'Unchanged production renderer lacks per-step source/download/copy neighbors, including the actual private consumer. Global owner unreleased: no private renderer proposal applied and no shared site/source-index/graph changes made.',
     'browser_MathJax_desktop_mobile':'NOT_TESTED; static output supplies no browser acceptance.'},
  'failed_verifier_attempts':['Unsupported ls-tree glob pathspec discovery','Unmatched zsh renderer filename glob','Initial probe display options and compiler-provider parent ordering'],
  'source_review_boundary':'Matching audit remains blind-reconstructed/source_review pending. This review issues no source-fidelity verdict, does not fill source review slots and is not a VERIFIED/SourceV/STAB/global/Goal claim.',
  'separation':'No other reviewer verdict/workspace was read, no agent listing was used, and no verdict was sent to the separate source reviewer. Only the specifically allowed E source-map, probe proposal and signature bodies were read. An initial tracked E tree listing exposed filenames only; no other E artifact body was opened.',
  'restrictions':'No restricted ATLAS contents/index/derivatives, ledger/sourceV/STAB command, background service, whole-site build, shared tracked-file edit, or private foreign baseline inventory.'
}
js('findings.json',findings)
put('findings.txt',
 'Independent native/type/whole-module verification PASS for '+C+'.\n'
 'Reader delivery HOLD: all six exact production step folds lack adjacent copy/download/module-source controls; no browser/MathJax/desktop/mobile claim.\n'
 'Fresh canonical GridAlias -> P -> T and independent kernel probes; cache excluded; all nine exact dependency HEADs/full porcelain clean.\n'
 '26 owned closed Prop theorems = 2 actual roots + 24 generated certificates; recursive axioms standard only; exact sealed root types and first-public ASTIS parents checked.\n'
 '57/57 Unicode-character/byte/literal/line locators match; 20 claimed direct canonical observations match actual bodies.\n'
 'All failed verifier attempts retained. No source fidelity/VERIFIED/SourceV/STAB/global/Goal assertion.\n')
print(json.dumps({'native':'PASS','reader':'HOLD','candidate':C,'findings_sha256':sha((D/'findings.json').read_bytes()),'all_nine_final_clean':True},indent=2))
