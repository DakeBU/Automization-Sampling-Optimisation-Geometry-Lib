from pathlib import Path
import bisect,datetime,hashlib,json,re
OUT=Path(__file__).resolve().parent;ROOT=Path('/Users/zhouhuanjian/ASTIS-GC')
def H(p):return hashlib.sha256(p.read_bytes()).hexdigest()
sealpath=ROOT/'.astis/huanjian-gc-source-gram-realization-20261113/statement-seal-v1.unclaimed.json';seal=json.loads(sealpath.read_text());assert H(sealpath)=='7b2f71cf9e89a41da4f66b2b3908222c875cd2fec2f8b2ca6533fe61b3bb3ce9'
g=json.loads((OUT/'SOURCE-GRAPH.RAWFIRST.v1.json').read_text());c=json.loads((OUT/'SOURCE-COVERAGE.RAWFIRST.v1.json').read_text())
bs=json.loads((OUT/'source-blocks.RAWFIRST.json').read_text());B={b['id']:b for b in bs};s=(OUT/'original.2610.20492v1.RAW.html').read_text();starts=[0]+[m.end() for m in re.finditer('\n',s)]
def R(ids):return [{'source_id':i,**{k:v for k,v in B[i].items() if k not in ['id','tag','text']}} for i in ids]
g['version']='GRAM-source-only-v2-exact-seal-bound';g['before_exact_new_Gram_seal_read']=False
g['predecessor']={'path':'SOURCE-GRAPH.RAWFIRST.v1.json','sha256':H(OUT/'SOURCE-GRAPH.RAWFIRST.v1.json'),'raw_first_preserved':True}
g['seal_sha256']=H(sealpath);g['producer_signature_sha256']=seal['producer']['signature_sha256'];g['consumer_signature_sha256']=seal['actual_private_consumer']['signature_sha256']
g['nodes'] += [
 {'id':'gap-angle-index-transport','kind':'SOURCE_GAP-TYPING','statement':'At Fin zero-based index i, source (i.val+1-1/2)pi/d equals (i.val+1/2)pi/d used by the body-free existing cosine-frame parent. Prove real arithmetic equality and transport t,w,frame; no theorem name alone supplies syntactic identity.','source_anchors':R(['S4.E11','A3.Ex85'])},
 {'id':'gap-standard-norm-moment','kind':'SOURCE_GAP-INTERNAL','statement':'For E=EuclideanSpace R (Fin(q+1)), derive actual Integrable(norm^2)(stdGaussian E) and integral(norm^2)=r from the canonical standard Gaussian moment theorem and finrank E=q+1. This is an internal theorem application, never a new source premise.','source_anchors':R(['A3.SS2.p12.3'])}
]
for e in g['edges']:
 if e['id']=='e04':e['parents'].append('gap-standard-norm-moment')
 if e['id']=='e06':e['parents'].append('gap-angle-index-transport')
g['edges'] += [
 {'id':'e00-angle','parents':['grid-objects'],'consumer':'gap-angle-index-transport','logic':'AND','consumer_use_sites':R(['A3.Ex110']),'discharge':'Exact zero/one-based real arithmetic transport for body-free frame interface.'},
 {'id':'e00-moment','parents':['regime'],'consumer':'gap-standard-norm-moment','logic':'AND','consumer_use_sites':R(['A3.SS2.p12.3']),'discharge':'Instantiate canonical standard moment on actual E and compute finite dimension; retained integrand is dominated internally.'}
]
g['permitted_exposure_after_rawfreeze']=['Exact new sealed P/T and proof-free Prop formation/import scopes','Body-free actual_source_truncated_matrix_means and actual_cosine_frame_gram signatures','Body-free canonical StdGaussianMoment.integrable_norm_sq_and_integral_stdGaussian signature','One bounded wrong Moment filename selection exposed only an inapplicable body-free target-covariance signature; no proof body read and no mathematical negative inference.']
g['coverage_path']='SOURCE-COVERAGE.v2.json'
c['version']='GRAM-coverage-v2-exact-mixed-scope';c['predecessor']={'path':'SOURCE-COVERAGE.RAWFIRST.v1.json','sha256':H(OUT/'SOURCE-COVERAGE.RAWFIRST.v1.json')}
for b in c['blocks']:
 if b['disposition']=='NODE':b['node_ids']=[n['id'] for n in g['nodes'] if any(a['source_id']==b['id'] for a in n['source_anchors'])]
 if b['id']=='A3.SS2.p12.1':b['reason']='The independent truncated-family assertion is not needed for deterministic Gram identities; literal Y formula itself is retained at Ex107.'
 if b['id']=='A3.SS2.p13.3':b['note']='Weighted family expression is reused, while the radius assertion is outside this packet; exact clause partition below separates them.'
def part(sid,a,z,disp,why,j):return {'source_id':sid,'fragment':j,'char_start':a,'char_end_exclusive':z,'byte_start':len(s[:a].encode()),'byte_end_exclusive':len(s[:z].encode()),'line_start_1based':bisect.bisect_right(starts,a),'line_end_1based':bisect.bisect_right(starts,max(a,z-1)),'raw_sha256':hashlib.sha256(s[a:z].encode()).hexdigest(),'disposition':disp,'reason':why}
# The source p7 header is the untruncated expectation claim, not the needed frequency argument.
b=B['A3.SS2.p7.1'];a,z=b['char_start'],b['char_end_exclusive'];k=s.index('Since ',a,z)
c['mixed_fragments'] += [part(b['id'],a,k,'EXCLUDED','Boxed untruncated weighted Gram expectation is not a prerequisite.',1),part(b['id'],k,z,'NODE','n=2q+1 and product-frequency domain needed for exact frame cancellation.',2)]
# Reuse only the exact math element identifying w_i Z_i; exclude its surrounding norm assertion.
b=B['A3.SS2.p13.3'];a,z=b['char_start'],b['char_end_exclusive'];raw=s[a:z]
m=re.search(r'<math\b[^>]*alttext="\\cos\(n\\theta_\{i\}\)Z_\{i\}"[^>]*>.*?</math>',raw,re.S)
assert m,'Expected literal weighted-family math element'
u,v=a+m.start(),a+m.end()
c['mixed_fragments'] += [part(b['id'],a,u,'EXCLUDED','Quantitative same-radius-bound sentence prefix is outside this packet.',1),part(b['id'],u,v,'NODE','Exact deterministic weighted family expression only.',2),part(b['id'],v,z,'EXCLUDED','Radius comparison and absolute-cosine bound are outside this packet.',3)]
for name,d in [('SOURCE-GRAPH.v2.json',g),('SOURCE-COVERAGE.v2.json',c)]: (OUT/name).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')

audit={'version':'Gram-binder-definition-audit-v1','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'seal_path':str(sealpath.relative_to(ROOT)),'seal_sha256':H(sealpath),
 'producer_signature_sha256':seal['producer']['signature_sha256'],'consumer_signature_sha256':seal['actual_private_consumer']['signature_sha256'],
 'binder_audit':[
 {'location':'P and private T','binder':'d q:Nat','classification':'TYPING','meaning':'Finite integer indices; q>=0 is represented by Nat. q=0 retained.'},
 {'location':'P and private T','binder':'hq:2*q+1<d','classification':'SOURCE','meaning':'Exact original regime. d>=2,r>0,sqrt normalization,nonempty matrix identity and any positivity are internal.'},
 {'location':'P and private T conclusion','binder':'omega:Omega','classification':'TYPING','meaning':'Actual source sample, not an arbitrary Gaussian-row certificate.'},
 {'location':'P and private T conclusion antecedent','binder':'G omega','classification':'SOURCE','expanded':'forall i:Fin d, norm(row i omega)^2<=L','meaning':'Exact source-local inclusive cutoff condition On T. No law conditioning, global/a.s. statement, or probability premise.'},
 {'location':'private T only','binder':'Delta:Real','classification':'TYPING','source_relation':'Explicit universally quantified PRIVATE deterministic threshold generalization, not the fixed printed numeric Delta. This is an unrestricted value parameter, not an analytic assumption; it has no separate public source/API credit.'},
 {'location':'private T conclusion antecedent only','binder':'norm(sum Z_i)<=Delta AND norm(sum w_i smul Z_i)<=Delta','classification':'SOURCE','source_relation':'Source-local event conditions generalized to the same private arbitrary threshold. They restrict pointwise samples for a deterministic implication; they are not assumed probability bounds or Bernstein certificates.'}
 ],
 'private_generalization_limit':'The private helper is honestly stronger in threshold quantification than the source fixed-Delta deterministic implication. It is not an exact textual restatement of the printed0.995 stochastic conclusion. Publishing it as such would require explicit generalization labeling and a new public semantic review.',
 'recursive_Prop_expansion':'G is the only project-owned/local Prop-valued definition used as input; it expands completely to own-row closed cutoff inequalities. The norm-event conjunction is already explicit. No Prop aliases hide mean/frame/Gram/variance/Bernstein certificates.',
 'EXCESS_public_P_binders':[],
 'definitions':[
 {'name':'D,E,Omega,mu','kind':'literal','meaning':'Canonical realization of original independent standard Gaussian columns: Omega=Fin(q+1)->EuclideanSpace R(Fin d), mu=pi stdGaussian D; actual physical rows under that same original unconditional mu.'},
 {'name':'r,L,theta,t,row','kind':'literal','meaning':'Source r=q+1,L=2r+3log(1000d), midpoint theta; Fin index i.val corresponds to source i+1. WithLp.toLp2 row is exactly coordinate regrouping with squared Euclidean norm R_i. No q>0 alteration.'},
 {'name':'Y','kind':'literal','meaning':'Exact d^-1 Kronecker tensor outer-product retained when norm(row)^2<=L, else0. The else branch is the source inclusive indicator, not off-source fallback. Pair indices are Gaussian first,cosine second.'},
 {'name':'mean,Z','kind':'literal','meaning':'Actual same-mu Bochner mean, then Y minus that mean. True Y integrability must be applied internally; a totalized nonintegrable integral0 is not acceptable source expectation. P/T have no new matrix MeasurableSpace binder.'},
 {'name':'a','kind':'literal','meaning':'Retained squared-radius integral under standard Gaussian on actual E divided by r. Its equality to the physical-row coefficient uses actual row marginal. Not a supplied arbitrary scalar/mean certificate. a<=1 must be derived internally.'},
 {'name':'w','kind':'literal','meaning':'Real deterministic cos(((2q+1):Nat):Real*theta_i), with possible zero/negative values.'},
 {'name':'B','kind':'literal','meaning':'Actual rectangular d by(r*r) matrix, B(omega)i(a,j)=sqrt(d)^-1*row_i(omega)_a*t_i_j. On source d>0 this is precisely d^-1/2(gamma_i tensor t_i)^T. Squared scaling is an internal bridge.'},
 {'name':'G','kind':'literal','meaning':'Conjunction of the exact same per-row inclusive cutoff used in Y, on actual original sample. No external event or certificate.'},
 {'name':'matrix norm','kind':'literal','meaning':'The exact Prop formation opens Matrix.Norms.L2Operator; its square matrix norm is the real Euclidean operator norm required by Ex126. No alternative norm or norm-equivalence premise is introduced. This audit reads the formation scope but runs no new API/type/proof search.'}
 ],
 'q0':'r=1,m=1,n=1,d>=2; B is d by1, t_i=(1), actual a is one-dimensional retained Gaussian norm square; frame cancellation at n=1 and all pointwise conditions remain meaningful.',
 'Delta_negative':'Both norm antecedents<=negative Delta cannot hold because norms are nonnegative. The helper is vacuous there; no extra Delta>=0 hypothesis is needed or allowed for convenience.',
 'must_remain_internal':['Actual true mean and integrability','Actual row-law/coefficient equality','theta frame interface transport and finite frame sums','Both aggregate means','d sqrt normalization and literal Gram coordinate identities','0<=a<=1 via retained-norm domination and actual standard moment','Identity operator norm/triangle/rebias algebra'],
 'forbidden_stochastic_premises':['unproved Bernstein theorem','tail probability estimate','probability of G or norm event','radius/variance-ready certificate'],
 'formation_evidence':{'receipt':'.astis/huanjian-resume-20261103/20261113T083451243190Z-unclaimed-source-gram-realization-v1-literal-Prop-formation.receipt.json','exit_code':0,'log_sha256':'15b6d904cd1c3347b1ffa99146addac4314c044e08f0543b358d23ad802e543c','meaning':'Only Prop formation; unused hq warnings do not prove P/T or justify dropping source regime.'},
 'exposure_and_failures':{'old_R11_implementation_audit_native_verdict':'not read','new_target_proof':'not read or attempted','permitted_body_free_interfaces':'Mean,cosine frame,canonical norm-square moment; all exact signatures/whole-file digests captured without proof bodies.','wrong_moment_selection':'FixedSpectrumGaussianMoments exposed only a body-free target-covariance quadratic-mean signature. Classification: retrieval/API identity mismatch, not mathematical negative evidence. It is not used. Root then supplied exact canonical StdGaussianMoment parent.','local_path_failure':'Initial extraction script chose .astis/.astis due to nested parent count. Failed command/read outputs and v1 script preserved; v2 fixes only repository-root resolution.'},
 'status':'Independent extractor audit only. No topology self-approval/source verdict/normalV/SAU or theorem proof.'}
(OUT/'BINDER-DEFINITION-AUDIT.v1.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n')

ports=[
 {'id':'I01-actual-mean','graph_nodes':['actual-mean','gap-row-law-integrability'],'type':'(forall i:Fin d, Integrable(Y i) mu) AND forall i, integral_mu(Y i)=(a/d) smul kronecker I_r (vecMulVec(t i)(t i))','existing_interface':'AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumSourceMatrixMean.actual_source_truncated_matrix_means hq','exact_match':'Same D,E,Omega,mu,r,L,a,theta,t,row,Y. Its actual a is exactly sealed retained stdGaussian E norm integral/r. Body not read.','certificate_policy':'Apply parent internally; never add its conclusions as caller assumptions.'},
 {'id':'I02-theta-frame','graph_nodes':['gap-angle-index-transport','frame'],'type':'theta_seal i=theta_frame i; then sum_i vecMulVec(t i)(t i)=d smul I_r AND sum_i w i smul vecMulVec(t i)(t i)=0','existing_interface':'AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumCosineGram.actual_cosine_frame_gram hq','exact_match':'Parent theta is(i.val+1/2)pi/d versus seal(i.val+1-1/2)pi/d. Must derive real arithmetic equality, transport features/weights, and expand parent t.transpose*t and t.transpose*diag(w)*t into the required outer-product sums. Parent also includes a norm bound; that extra conclusion is not consumed. Body not read.'},
 {'id':'I03-aggregate-means','graph_nodes':['aggregate-means'],'type':'(sum_i mean i)=a smul I_M AND(sum_i w i smul mean i)=0','internal_dependencies':['I01-actual-mean','I02-theta-frame'],'discharge':'Finite Kronecker/scalar sum linearity; divide by actual positive d; kronecker I_r I_r=I_M. Same mu,actual means,not proxy.'},
 {'id':'I04-sqrt','graph_nodes':['gap-d-sqrt'],'type':'0<(d:Real) AND ((Real.sqrt(d:Real))^(-1))^2=(d:Real)^(-1)','internal_dependencies':['source hq only'],'discharge':'Derive d>=2 from Nat regime, then sqrt squared/inverse arithmetic. No supplied normalization equality.'},
 {'id':'I05-literal-Grams','graph_nodes':['gap-Gram-expansion','gap-cutoff-agreement'],'type':'For every omega in G, B(omega).transpose*B(omega)=sum_i Y i omega AND B(omega).transpose*diagonal(w)*B(omega)=sum_i w i smul Y i omega','internal_dependencies':['I04-sqrt','literal sealed B,Y,G,w'],'discharge':'Entrywise finite matrix multiplication; gaussian-first tensor coordinate ordering; every Y retained branch follows from same G omega. No arbitrary B or assumed Gram equality.'},
 {'id':'I06-P','graph_nodes':['P-Ex125'],'type':'forall omega, G omega -> (sum_i Z i omega=B^T B-a smul I_M) AND(sum_i w i smul Z i omega=B^T diagonal(w)B)','internal_dependencies':['I03-aggregate-means','I05-literal-Grams'],'discharge':'Expand Z=Y-mean and finite sums; source plus/minus sign preserved. Exact public producer P, sole source hq.'},
 {'id':'I07-a-bounds','graph_nodes':['gap-standard-norm-moment','gap-a-le-one','a-bounds'],'type':'0<=a AND a<=1','existing_interface':'AutoSamplingTheory.TechnicalLemmas.Probability.StdGaussianMoment.integrable_norm_sq_and_integral_stdGaussian (E:=EuclideanSpace Real(Fin(q+1)))','exact_match':'Parent gives Integrable norm^2 (stdGaussian E) AND integral norm^2=Module.finrank Real E. Derive finrank=q+1,cast=r. Retained f=indicator{norm^2<=L}(norm^2) satisfies0<=f<=norm^2; derive its measurability/integrability and integral domination internally, then divide by r>0. Body not read.','not_used':'Wrong FixedSpectrumGaussianMoments target-covariance interface.'},
 {'id':'I08-bias-norm','graph_nodes':['gap-bias-norm'],'type':'norm((1-a) smul I_M)=1-a; B^T B-I_M=sumZ-(1-a)smul I_M','internal_dependencies':['I06-P','I07-a-bounds'],'discharge':'M is nonempty finite product-index square matrix (q+1>=1); real L2 identity norm=1 and1-a>=0; exact algebra rebiases public P.'},
 {'id':'I09-private-T','graph_nodes':['T-Ex126-deterministic'],'type':'forall Delta:Real,forall omega,G omega -> ((norm(sumZ)<=Delta) AND(norm(sum w smul Z)<=Delta)) -> ((norm(B^TB-I_M)<=Delta+(1-a)) AND(norm(B^Tdiagonal(w)B)<=Delta))','internal_dependencies':['I06-P','I08-bias-norm'],'discharge':'Triangle inequality plus actual antecedent bounds. Delta arbitrary; negative antecedents impossible. No concentration probability or unproved Bernstein input.'}
]
p={'version':'GRAM-internal-ports-v1','seal_sha256':H(sealpath),'source_graph_path':'SOURCE-GRAPH.v2.json','source_graph_sha256':H(OUT/'SOURCE-GRAPH.v2.json'),'source_coverage_path':'SOURCE-COVERAGE.v2.json','source_coverage_sha256':H(OUT/'SOURCE-COVERAGE.v2.json'),'ports':ports,'evidence':['body-free-parent-signatures.stdout','exact-standard-moment-signature.stdout'],'status':'Typed mathematical obligation ports only; no existing parent proof inspection or new target proof. Independent source graph was frozen before these interface exposures.'}
(OUT/'INTERNAL-PORTS.v1.json').write_text(json.dumps(p,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({n:H(OUT/n) for n in ['SOURCE-GRAPH.v2.json','SOURCE-COVERAGE.v2.json','BINDER-DEFINITION-AUDIT.v1.json','INTERNAL-PORTS.v1.json']},indent=2))
