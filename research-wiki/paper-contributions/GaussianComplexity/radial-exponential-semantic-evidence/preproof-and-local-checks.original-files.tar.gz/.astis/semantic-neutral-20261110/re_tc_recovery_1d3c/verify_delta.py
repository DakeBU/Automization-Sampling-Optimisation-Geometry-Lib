"""Verify named frozen inputs and replay the topology corrections in memory."""

import hashlib
import json
import sys
from pathlib import Path


def digest(data):
    return hashlib.sha256(data).hexdigest()


def by_id(records, value):
    matches = [record for record in records if record["id"] == value]
    assert len(matches) == 1, (value, len(matches))
    return matches[0]


def replay(records, operation, site=None):
    value = operation["id"]
    if operation["op"] == "add_record":
        assert all(record["id"] != value for record in records), value
        record = dict(operation["record"])
        assert record["id"] == value
        if site:
            record["consumer_use_site"] = site
        records.append(record)
        return
    assert operation["op"] == "replace_fields", operation
    record = by_id(records, value)
    for key, old_value in operation["expect"].items():
        assert record[key] == old_value, (value, key)
    record.update(operation["fields"])


def check_manifest(path, records_key, selected, snapshots):
    manifest = json.loads(snapshots[path])
    for name in selected:
        record, = [item for item in manifest[records_key] if item["path"] == name]
        data = snapshots[path.parent / name]
        assert record["bytes"] == len(data), name
        assert record["sha256"] == digest(data), name
    return manifest


def ancestors(node, parents, path=()):
    assert node not in path, path + (node,)
    lineage = {node}
    for parent in parents[node]:
        lineage |= ancestors(parent, parents, path + (node,))
    return lineage


workspace = Path("/Users/zhouhuanjian/ASTIS-GC")
assert Path.cwd() == workspace
packet = Path(".astis/semantic-neutral-20261110")
sg = packet / "re_sg_b71f20"
tc = packet / "re_tc_f92a64"
recovery = packet / "re_tc_recovery_1d3c"
delta_path = recovery / "corrected-overlay-delta.json"
delta = json.loads(delta_path.read_bytes())
bound_paths = {
    "source_graph": sg / "phase1/source-graph.json",
    "typed_overlay": sg / "phase2/typed-source-overlay.json",
    "typed_coverage": sg / "phase2/typed-coverage.json",
}
groups = (
    (sg / "phase1/phase1-manifest.json", "files",
     ["source-graph.json", "mathematics.md", "coverage.json", "inputs/2610.20492v1.html"]),
    (sg / "phase2/phase2-manifest.json", "file_records",
     ["typed-source-overlay.json", "typed-coverage.json", "typed-mathematics.md"]),
    (tc / "phase1/frozen-manifest.json", "files",
     ["independent-math-freeze.md", "inputs/2610.20492v1.html"]),
    (tc / "phase2a/frozen-manifest.json", "files", ["independent-typed-judgment.md"]),
)
snapshots = {}
for manifest_path, _, names in groups:
    snapshots[manifest_path] = manifest_path.read_bytes()
    for name in names:
        path = manifest_path.parent / name
        snapshots[path] = path.read_bytes()
assert {
    name: digest(snapshots[path]) for name, path in bound_paths.items()
} == delta["base_sha256"]
manifests = [check_manifest(*group, snapshots) for group in groups]
assert manifests[0]["frozen_before_target_types"] is True
assert manifests[1]["phase1_binding"]["graph_sha256"] == delta["base_sha256"]["source_graph"]
assert manifests[1]["phase1_binding"]["manifest_sha256"] == digest(snapshots[groups[0][0]])
assert manifests[2]["target_types_exposed"] is False
assert manifests[2]["other_author_graph_exposed"] is False
assert manifests[3]["other_graph_exposed"] is False
assert manifests[3]["source_math_freeze_sha256"] == digest(
    snapshots[tc / "phase1/independent-math-freeze.md"]
)
raw = snapshots[sg / "phase1/inputs/2610.20492v1.html"]
assert raw == snapshots[tc / "phase1/inputs/2610.20492v1.html"]
raw_digest = digest(raw)
assert raw_digest == "6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915"

bases = {name: json.loads(snapshots[path]) for name, path in bound_paths.items()}
graph = bases["source_graph"]
overlay = bases["typed_overlay"]
coverage = bases["typed_coverage"]
assert graph["source"]["source_sha256"] == raw_digest
assert overlay["selective_packet_sha256"] == manifests[3]["packet_sha256"]
signature_digests = {}
for target, record in overlay["literal_targets"].items():
    literal_sha = digest(record["literal_signature"].encode("utf-8"))
    assert literal_sha == record["literal_anchor"]["decoded_literal_sha256"]
    signature_digests[target] = literal_sha
assert signature_digests == delta["literal_signature_sha256"]
for record in overlay["literal_definitions"]:
    assert digest(record["literal"].encode("utf-8")) == record["literal_anchor"]["decoded_literal_sha256"]
assert len(overlay["literal_definitions"]) == 11
assert [binder["classification"] for binder in overlay["binders"]] == ["TYPING"] * 9 + ["STANDING"]

nodes = {node["id"]: node for node in graph["nodes"]}
raw_coverage = json.loads(snapshots[sg / "phase1/coverage.json"])
anchor_ids = {
    "A3.SS2.p1", "A3.SS2.p10", "A3.SS2.p10.3", "A3.Ex104.m1", "A3.SS2.p11",
    "A3.Ex106.m2", "A3.Ex108.m1", "A3.SS2.p12", "A3.Ex109.m1", "A3.SS2.p13", "A3.SS2.p17",
}
anchors = {}
for item in raw_coverage["items"]:
    if item["source_id"] in anchor_ids:
        anchor = item["anchor"]
        span = raw[anchor["raw_utf8_start"]:anchor["raw_utf8_end"]]
        assert digest(span) == anchor["span_sha256"], item["source_id"]
        anchors[item["source_id"]] = digest(span)
assert set(anchors) == anchor_ids

for operation in delta["operations"]:
    site = None
    if "source_anchor_id" in operation:
        anchor_id = operation["source_anchor_id"]
        site, = [anchor for anchor in nodes[operation["source_anchor_from_node"]]["source_anchors"]
                 if anchor["source_id"] == anchor_id]
        assert site["span_sha256"] == anchors[anchor_id]
    replay(bases[operation["artifact"]][operation["collection"]], operation, site)
    if mirror := operation.get("mirror"):
        replay(bases[mirror["artifact"]][mirror["collection"]], operation, site)
for artifact, changes in delta["coverage_count_updates"].items():
    for key, change in changes.items():
        assert bases[artifact]["counts"][key] == change["expect"]
        bases[artifact]["counts"][key] = change["value"]
assert coverage["type_components"] == overlay["typed_components"]
assert coverage["unproved_background_bridges"] == overlay["background_bridges"]
assert coverage["counts"]["unproved_typed_bridges"] == len(overlay["background_bridges"])

parents = {node: set() for node in nodes}
for edge in graph["edges"]:
    assert set(edge["premises"]) <= nodes.keys(), edge["id"]
    parents[edge["conclusion"]].update(edge["premises"])
assert len({edge["id"] for edge in graph["edges"]}) == len(graph["edges"])
lineage = {node: ancestors(node, parents) for node in nodes}
for node in graph["selected_scalar_nodes"]:
    assert lineage[node].isdisjoint(graph["prohibited_scalar_parents"]), node
assert parents["a-definition"] == {"L-definition", "R-definition", "row-definition-law", "standing-parameters"}
assert all("second-moment" not in lineage[node] for node in ("a-definition", "radial-covariance-consumer"))
assert "second-moment" in parents["scalar-bias"]
assert by_id(graph["edges"], "e-p13-a-upper-use")["logic"] == "CONSUMER_CONTEXT"
source_moment_routes = [edge["route"] for edge in graph["edges"] if edge["conclusion"] == "moment-one-third"]
assert source_moment_routes == graph["OR_routes"][0]["alternatives"]
routes = {route["id"]: route for route in overlay["planned_mathematical_routes"]}
assert set(routes) == {"P-positive-density", "P-positive-product", "P-zero", "T-use-P", "T-transport-to-source-row"}
assert routes["P-positive-density"]["route_relation"] == "OR with P-positive-product; unproved"
assert routes["P-positive-product"]["route_relation"] == "OR with P-positive-density; unproved"
assert routes["P-zero"]["guard"] == "finrank ℝ E=0"
assert "bridge-rpow" in routes["T-use-P"]["premises"]
assert "bridge-source-row-law" in routes["T-transport-to-source-row"]["premises"]
for route_id in ("P-positive-density", "P-positive-product", "P-zero", "T-use-P"):
    assert "bridge-source-row-law" not in routes[route_id]["premises"]
assert "row-definition-law" not in by_id(overlay["background_bridges"], "bridge-canonical-law")["source_graph_references"]
for path, contents in snapshots.items():
    assert path.read_bytes() == contents, str(path)

print(json.dumps({
    "status": "PASS",
    "argv": sys.argv,
    "cwd": str(workspace),
    "inputs_verified_unchanged": {str(path): digest(data) for path, data in snapshots.items()},
    "literal_signature_sha256": signature_digests,
    "literal_definition_hashes_verified": len(overlay["literal_definitions"]),
    "raw_anchors_verified": anchors,
    "delta_sha256": digest(delta_path.read_bytes()),
    "applied_operations": [operation["id"] for operation in delta["operations"]],
    "verified": ["exact named manifest payloads", "literal hashes and binder classes",
                 "anchor byte hashes", "strict replay and typed coverage mirrors",
                 "source graph acyclicity and bounded ancestor exclusions", "OR and endpoint guards",
                 "generic/source-row bridge separation", "T-use-P rpow premise"],
}, ensure_ascii=False, indent=2))
