# Target-law / norm-mean phase2a: exact type, binder and definition judgment

**ACCEPT_BOUNDED_SOURCE_COMPONENT_TYPES_AND_DEFINITIONS.** Both exact interfaces express faithful extracted source components with no EXCESS binder found. This accepts their bounded mathematical meanings, not a proof, graph/coverage verdict, actual producer invocation, conditional experiment, process qualification or sourceV/STAB/global result.

The raw-first phase1 manifest remains frozen at `fabee8d9a5972004405ae2cf8be377c8f25a9ee4e7ab35fd06017c42776f9d35`. The current review is continuing-context, not fresh: old Detector type/topology/process exposures remain declared in phase1 and are not used as a new-law acceptance certificate.

The sole new exact-type payload is the selectively authorized JSON, SHA256 `ec350a9cfb9bbc0658fd9884d507a74114a3eb5ac0cedebddc22b2a0ae750415`. Its proposed audits and no-EXCESS statements are visible candidate assertions, not independent authority. I recomputed the two signature-string digests and compared their actual contents with raw-source cognition. The full canonical seal, new/old SG graph/delta/verdict, root planning/process history and implementation were not opened in this phase. The full seal SHA `a8b81776536741394f2e163d041f9b19f463c573759aa52dc7e6397b26065ccb` is known only as supplied metadata.

Exact producer: `actual_rotated_gaussian_target`, signature SHA256 `531a3651e3640057ea29a0ccce6b7fd2cf7689ecb126be71d7460af125d2b9fb`.

Exact private consumer: `actual_target_gaussian_norm_mean`, signature SHA256 `a54682278c1ba728a1ea4ad03f735f997787a733b8dd9c02856280de749e6b3a`.

## Seven semantic slots: source against exact type

| Slot | Source reading | Exact-type finding |
|---|---|---|
| 1. Anchor and mathematical component | Eq11 fixes the family; §4.2 p2.1 transports an exact target into hidden coordinates; C.3 Ex140 identifies M as the finite inverse-spectrum sum. | Producer states the equivalent forward **full measure** law. Private consumer states the actual target's norm-square L1 and finite-sum mean component. It does not claim the closed-form grid sum, μ_n, variance or full Lemma4.5. |
| 2. Objects and carriers | Real Euclidean vectors, full O(d), diagonal precision Λ and rotated precision A=OΛOᵀ; Gaussian covariance is the corresponding matrix inverse. | `Fin d`, real matrices, `EuclideanSpace ℝ (Fin d)` and the actual orthogonal group preserve those meanings. Same O is used in A and forward R. No SO restriction or arbitrary substituted law. |
| 3. Quantifiers and parameter ranges | Hard family d≥2, κ≥2. The deterministic law/mean identities are pointwise in O; source's random draw is additional experiment context. | `{d:Nat} (2≤d) {κ:Real} (2≤κ) (O:full orthogonalGroup)`, universally parameterized; no existential coupling or implicit random O. d=2 and κ=2 remain included. No δ, q, n, ε or d0 premise is added. |
| 4. Hypotheses and internal obligations | Source positivity follows from the grid; inversion/conjugation, Gaussian transport, map measurability, finite moments and integrability are proof ingredients. | Only family-domain/orthogonal-carrier inputs occur. There is no supplied PosDef/invertibility/law/map/moment/Integrable certificate. `Integrable` is an output. No project-owned Prop alias hides additional inputs. |
| 5. Definitions and normalization | θ_i=(i−1/2)π/d for i=1,…,d; centered normalized Gaussian with covariance A⁻¹; ordinary Euclidean squared norm. | `i.val+1/2` reindexes exactly. Λ⁻¹/A⁻¹ are matrix inverses; RHS λ_i⁻¹ are **real scalar reciprocals**. No extra normalization by d, determinant or partition function enters the mean. WithLp converts coordinates without rescaling. |
| 6. Conclusions and probability space | Fixed-O latent/target law adapter; E_target‖Y‖²=M=Σ1/λ_i. Random-O conditional laws require an actual joint/kernel interpretation. | Producer equates actual measures `(multivariateGaussian 0 Λ⁻¹).map R` and `multivariateGaussian 0 A⁻¹`. Consumer's μ is the actual RHS target measure and outputs integrability plus its real Bochner integral. Neither signature creates a Haar law, joint experiment or conditional representative. |
| 7. Endpoints, consumer and scope | M branch is n-independent; zero vector is included in the Gaussian carrier with norm-square zero. Law transport can feed target moment transfer; normalizer Z is separate. | No nonzero-vector restriction, frequency/bias condition or arbitrary off-domain extension premise. The private norm mean is a genuine source component and a possible substantive consumer of the law via source coordinate transport, not a source-anchor/full-moment claim. Actual proof invocation/reachability remains unobserved. |

## Every logical binder

| Interface | Binder | Class | Reason |
|---|---|---|---|
| producer | `{d : ℕ}` | TYPING | Natural finite dimension and coordinate carrier. |
| producer | `hd : 2 ≤ d` | SOURCE | Literal Eq11 hard-family domain. |
| producer | `{κ : ℝ}` | TYPING | Real construction/condition parameter. |
| producer | `hκ : 2 ≤ κ` | SOURCE | Literal Eq11 spectral-family range. |
| producer | `O : Matrix.orthogonalGroup (Fin d) ℝ` | SOURCE | Source fixed full orthogonal eigenbasis, with both inverse products; no determinant-one or law restriction. |
| private consumer | `{d : ℕ}` | TYPING | Same finite dimension. |
| private consumer | `hd : 2 ≤ d` | SOURCE | Same source family domain. |
| private consumer | `{κ : ℝ}` | TYPING | Same real parameter. |
| private consumer | `hκ : 2 ≤ κ` | SOURCE | Same source spectral range. |
| private consumer | `O : Matrix.orthogonalGroup (Fin d) ℝ` | SOURCE | Same full fixed rotation/eigenbasis. |

Totals: SOURCE=6, TYPING=4, STANDING=0, RULED=0, EXCESS=0. Local θ/Λ/A/R/μ `let`s are literal expressions, not assumptions. Standard carrier group obligations expand to orthogonality, not a project theorem certificate. There are no existential output witnesses or hidden project definitions to recursively expand. This count is an independent classification of the actual text, not acceptance of the supplied schema's labels.

## Definition expansion, proper Gaussian and totalization

All new local definitions are **literal**. The two authorized excerpts were byte/hash checked against the exact minimal original definition lines. Additional necessary standard definitions were read in bounded windows, recorded exactly in the definition manifest; no target-proof API retrieval was performed.

* **Gaussian constructor:** `multivariateGaussian m S` literally maps standard Gaussian by `x↦m+toEuclideanCLM(CFC.sqrt S)x`. Its documentation explicitly states the non-PSD covariance fallback becomes a Dirac law. Here S is Λ⁻¹ or A⁻¹. Independently of that documentation's proposed audit, the source grid gives θ∈(0,π), 1<λ_i<κ, hence Λ and A positive definite, and their ordinary inverses positive definite. Thus the source domain is the proper centered Gaussian branch, not that fallback. These properties must be proved/reused inside an implementation; they are not caller premises and have not been Lean-verified here.
* **Nonvacuity:** d≥2 and every λ_i>0 imply `Σ_i λ_i⁻¹>0`. A zero-covariance/Dirac-zero fallback would have norm-square mean zero, so it cannot silently satisfy the private component's positive RHS. The full-law producer and the actual norm-mean consumer therefore have substantive meanings beyond a common-fallback equality.
* **Two inverse meanings:** Λ⁻¹ and A⁻¹ use the square-matrix inverse instance `det(A)⁻¹ʳ • adjugate(A)`; source nonsingularity makes this the usual inverse. The RHS finite sum in the consumer instead applies the real-field scalar reciprocal separately to each λ_i. No inversion is applied to O as a scalar. The covariance identity needed for the law is A⁻¹=OΛ⁻¹Oᵀ; this is a proof ingredient, not an assumed binder.
* **Full O:** `orthogonalGroup` uses trivial scalar star and abbreviates unitaryGroup; the underlying unitary carrier has `star O*O=1` and `O*star O=1`. For real matrices this is OᵀO=OOᵀ=I. There is no determinant filter. The chosen forward map R is Oz, consistent with the inverse source coordinate description U=OᵀY.
* **Euclidean model:** EuclideanSpace is PiLp 2, PiLp is the WithLp wrapper of coordinate functions, and its p=2 norm is the ℓ² norm. `toLp`/`ofLp` are constructor/projection conversions. Matrix matvec and dot product are ordinary finite contractions. The signature uses Euclidean norm, not the sup norm of the unwrapped function space.
* **Measure.map:** the actual map constructor uses an a.e.-measurable representative and totalizes to zero when AEMeasurable fails. R is finite-dimensional linear/continuous, so its measurability is an internally derivable obligation. A target proof must discharge it to justify ordinary pushforward semantics; the signature correctly does not accept a map-law witness as an input.
* **Integrable and integral:** `Integrable f μ` expands to a.e. strong measurability plus `HasFiniteIntegral`; the latter is finite lower integral of the extended norm. The real Bochner integral is totalized to zero outside Integrable (and outside complete codomain). The consumer explicitly **concludes** Integrable alongside the integral identity, so it does not exploit that zero fallback as the source expectation. The real codomain is complete. The explicit μ argument avoids any default-volume ambiguity.

No new characterized/choice/quotient definition is introduced. Standard Gaussian covariance/probability recognition remains standard-library semantic/proof background; a definition-only reading does not certify the actual implementation or the source-law bridge. The new type-level meaning is now reviewed independently, without upgrading those proof obligations.

## Actual consumer, conjunction and source limits

The private theorem is a real component of C.3 Ex140 and §4.2 target moment transport: it asks for a true norm-square expectation under the actual target μ, not an arbitrary measure certificate or an assumption rewrapped as a conclusion. Its parameter range is appropriate: the n restriction in combined Lemma4.5 is needed for the cosine branch, while this finite sum M component does not depend on n. κ=2 and d=2 are valid source endpoints; no high-dimensional/asymptotic hypothesis is needed for this fixed-family identity.

A mathematically legitimate source-coordinate consumer route uses the producer's full law to replace μ by the rotated latent law, then transports integrability and the integral through the Euclidean isometry and Gaussian second moments. Another possible implementation could derive the target Gaussian trace directly. A signature cannot prove which route is used. Accordingly actual invocation, whether either/both conjunction branches consume the producer, and source-graph placement remain HOLD for the distinct graph challenge and eventual implementation evidence. The old Detector branch split is not mechanically copied onto this different consumer.

These types do not assert the exact finite-grid scalar closed form, cosine mean/sign/variance/bias, target acceptance, algorithm rejection, random-O conditional kernel, Haar/seed independence, TV/query/cost lower bound, normalizer Z identity or full Lemma4.5. A fixed-O full-law equality is a valid deterministic source component; it does not by itself manufacture an actual joint conditional experiment. No old or new source-specific ACCEPT is substituted for that distinction.

## Freeze boundary

Bounded type/binder/definition judgment: **ACCEPT** as above. New source-graph/coverage/consumer topology, Lean/proof/API validity, actual called dependency, process/intake qualification, sourceV/V/STAB/native/global/wholeGoal statuses remain **HOLD**. Freeze this judgment before any graph or root process material is read; subsequent corrections require preserved successor records rather than editing the raw cognition or this judgment.
