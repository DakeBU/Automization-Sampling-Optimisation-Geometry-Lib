"""Repeat actual immutable postcore protection reads into a fresh output directory."""
from pathlib import Path
p=Path('.astis/huanjian-gc-fixed-spectrum-admissibility-integration-20261107/independent-reader/check_postcore.py')
raw=p.read_text()
a="O=P.parent/'postcore';O.mkdir(exist_ok=False)"
b="O=P.parent/'final-protection-readback';O.mkdir(exist_ok=False)"
assert raw.count(a)==1
exec(compile(raw.replace(a,b,1),str(p)+'::fresh-final-protection-readback','exec'))
