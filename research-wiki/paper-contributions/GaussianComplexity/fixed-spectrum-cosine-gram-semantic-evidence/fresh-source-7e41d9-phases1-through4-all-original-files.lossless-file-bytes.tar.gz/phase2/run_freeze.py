#!/opt/anaconda3/bin/python
import datetime
import hashlib
import json
import pathlib
import subprocess
import sys
BASE=pathlib.Path(__file__).resolve().parent
ROLE=BASE.parent
argv=['/opt/anaconda3/bin/python',str(BASE/'freeze_phase2.py')]
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
proc=subprocess.run(argv,cwd='/Users/zhouhuanjian/ASTIS-GC',capture_output=True)
out=ROLE/'phase2_freeze_execution.stdout';err=ROLE/'phase2_freeze_execution.stderr'
out.write_bytes(proc.stdout);err.write_bytes(proc.stderr)
record={'argv':argv,'cwd':'/Users/zhouhuanjian/ASTIS-GC','started_utc':started,
        'returncode':proc.returncode,'stdout_file':out.name,'stderr_file':err.name,
        'stdout_bytes':len(proc.stdout),'stderr_bytes':len(proc.stderr),
        'stdout_sha256':hashlib.sha256(proc.stdout).hexdigest(),
        'stderr_sha256':hashlib.sha256(proc.stderr).hexdigest()}
if proc.returncode==0:
    record['observed_freeze_result']=json.loads(proc.stdout)
    receipt=BASE/'freeze_receipt.json'
    record['receipt_sha256_observed']=hashlib.sha256(receipt.read_bytes()).hexdigest()
    assert record['receipt_sha256_observed']==record['observed_freeze_result']['receipt_sha256']
path=ROLE/'phase2_freeze_execution.json';path.write_text(json.dumps(record,indent=2)+'\n')
for p in [path,out,err]:p.chmod(0o444)
print(json.dumps(record,indent=2))
sys.stdout.write(proc.stdout.decode(errors='replace'))
sys.stderr.write(proc.stderr.decode(errors='replace'))
raise SystemExit(proc.returncode)
