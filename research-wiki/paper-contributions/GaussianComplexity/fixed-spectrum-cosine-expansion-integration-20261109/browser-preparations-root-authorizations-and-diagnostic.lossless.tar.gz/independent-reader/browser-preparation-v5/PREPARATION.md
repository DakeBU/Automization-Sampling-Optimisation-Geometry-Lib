# Minimal C7 browser v5 — canonical destinations, disabled

The actual v4 run completed24 desktop originals and10 native rows, including Lower Bounds, before failing on an unrelated Discrete link uniqueness assumption. Actual built Discrete HTML has two `random-scan-law` links and two `random-scan-reversibility` links: one in the subject introduction, one in the existing proof index. For each theorem both hrefs and both labels are identical. They are navigation reuse, not duplicate proof nodes.

The only DOM assertion change now requires at least one link for each canonical proof, every matching href normalized to the same expected own-site URL, and HTTP200 from that own-site target. It does not require unique product links or review either proof anew. Other view/geometry assertions and48/20 counts are unchanged; v4's exact short-label rule and native failure g0/PNG capture remain.

Before freezing, a bounded standard-library HTMLParser audit inspected the four actual subject pages, SLC–LSI source-outline page and two canonical proof target files. All remaining new static assertions match: each subject has one main H1 and one four-link Subjects nav with exact labels/order/normalized targets; Lower Bounds has its unique nonlinear section/open-main boundary and canonical SLC link; the outline has12 list items, the `not Lean` boundary and a native summary-bearing ancestor; all three planned theorem IDs are unique and retain `local proof open`. The audit is `bounded-built-HTML-static-subject-audit.json`. It neither executes a browser/model nor certifies runtime MathJax, mobile overflow, source mathematics or new proof completion.

The context copies actual unchanged7ad/core/eight-gate/122test/site/pin records from the real v4 authorization, with root execution flags reset disabled. v4/failures/all24 originals remain exact and have not been viewed for pixel acceptance in this preparation. No core/UI/source/Lean/Test/lesson/publication file changes, browser/server/OS/build/API/stage/commit or source verdict occurs. Only source inspection, bounded HTML parsing and AST syntax parsing were used.

Root can review the exact diff/context and request the existing new scoped approval flow for:

```text
/opt/anaconda3/bin/python .astis/huanjian-resume-20261103/run_check.py cosine-expansion-final-browser-v5 .astis/huanjian-gc-integration-20261105/browser-venv/bin/python .astis/huanjian-gc-fixed-spectrum-cosine-expansion-integration-20261109/independent-reader/browser-preparation-v5/check_final_reader_v5.py --authorization-json <ACTUAL_NEW_ROOT_AUTHORIZATION_PATH> --authorization-sha256 <ACTUAL_NEW_ROOT_AUTHORIZATION_SHA256>
```

The placeholders are documentation, and old approvals give no v5 execution authority. Actual complete48 originals and independent pixel review remain required. No full integration/park/remote/purification/main-bound acceptance is granted here.
