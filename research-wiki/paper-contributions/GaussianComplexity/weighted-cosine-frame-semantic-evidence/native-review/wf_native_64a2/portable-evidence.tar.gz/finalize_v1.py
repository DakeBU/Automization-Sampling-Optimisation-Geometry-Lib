import datetime,hashlib,json,pathlib,subprocess
from run import ROOT,REPO,run
sha=lambda b:hashlib.sha256(b).hexdigest()
im=json.loads((ROOT/'input-manifest.json').read_text())
runtime=json.loads((ROOT/'reader-static.json').read_text())['production_renderer_runtime']
head=run('final-head',['git','rev-parse','HEAD']).stdout.decode().strip()
assert head=='48023c9e2f6c8f822050a64b7462b7e66f549ba1',head
relevant=im['modules']+[p for p in im['files'] if p.startswith('website/') or p.endswith('statement-seal.json') or p.endswith('source-lean-map.draft.json') or p in {'lean-toolchain','lake-manifest.json','lakefile.lean'}]+[x['path'] for x in runtime]
comparisons=[]
for i,p in enumerate(relevant):
    a=run('final-candidate-bytes-'+str(i),['git','show',im['candidate_commit']+':'+p]);b=run('final-metadata-bytes-'+str(i),['git','show',head+':'+p])
    assert a.returncode==b.returncode==0 and a.stdout==b.stdout==(REPO/p).read_bytes(),p
    comparisons.append({'path':p,'sha256':sha(a.stdout),'candidate_and_metadata_head_and_worktree_identical':True})
for d in im['dependencies']:
    dep=REPO/'.lake/packages'/d['name']
    h=run('final-dependency-'+d['name']+'-head',['git','rev-parse','HEAD'],cwd=dep)
    s=run('final-dependency-'+d['name']+'-status',['git','status','--porcelain=v1','--untracked-files=all'],cwd=dep)
    assert h.returncode==s.returncode==0 and h.stdout.decode().strip()==d['head'] and not s.stdout
assert sha(pathlib.Path(im['lean_binary']['path']).read_bytes())==im['lean_binary']['sha256']
(ROOT/'metadata-head-byte-comparison.json').write_text(json.dumps({'compiled_candidate':im['candidate_commit'],'later_metadata_head':head,'new_native_compile_claimed_for_metadata_head':False,'unchanged_relevant_inputs':comparisons},indent=2)+'\n')
native=json.loads((ROOT/'native-inspection-summary.json').read_text());reader=json.loads((ROOT/'reader-static.json').read_text());loc=json.loads((ROOT/'locator-checks.json').read_text())
history=[
 {'class':'IMPLEMENTATION_FAILED','driver':'prepare.py','receipt':'receipts/prepare.json','reason':'Incorrect source-map path; corrected in prepare_v2.py; immutable inputs unchanged.'},
 {'class':'API_BLOCKED','driver':'scratch/InspectNative.lean','receipt':'receipts/native-environment-inspection.json','reason':'pp.maxDepth is not an available Lean4.33 option; corrected inspector v2 exits0, original output retained.'},
 {'class':'IMPLEMENTATION_FAILED','driver':'reader_static_v1.py','receipt':'receipts/reader-static.json','reason':'Overstrong concatenation assertion rejected the single omitted blank separator between exact source folds; all six folds individually exact.'},
 {'class':'ENV_BLOCKED','driver':'reader_static_v2.py','receipt':'receipts/reader-static-v2.json','reason':'Bounded export lacked canonical textbook theme reference; copied and hashed current theme without shared generation.'},
 {'class':'IMPLEMENTATION_FAILED','driver':'reader_static_v3.py','receipt':'receipts/reader-static-v3.json','reason':'Minimal harness module target lacked declaration anchor; switched to actual production render_source_module.'},
 {'class':'ENV_BLOCKED','receipt':'receipts/inspect-process-v2.json','reason':'Optional process inventory prohibited by sandbox; not needed or used for acceptance.'},
 {'class':'IMPLEMENTATION_FAILED','reason':'An interactive Python one-liner for runner snapshot failed syntactically before writes; corrected with direct cp and apply_patch; tool transcript preserves failure.'}
]
report={'verifier':'independent-native-whole-module-reader-wf_native_64a2','completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'mathematical_candidate_commit':im['candidate_commit'],'later_metadata_head':head,'later_metadata_byte_transfer':'23 relevant files identical, see metadata-head-byte-comparison.json; compilation remains401a3e1 only.','publication_binding_sha256':reader['binding_sha256'],'verdict':'PASS bounded native six-module closure, sealed literal applications, source-locator integrity and static production reader; HOLD browser/public integration/purification.','native':{'lean_binary':im['lean_binary'],'version':'Lean4.33.0 arm64 commit d8b18978322de05a8f3dba51ef03cf5461676c17','manifest_sha256':im['files']['lake-manifest.json']['sha256'],'all9_dependencies_exact_and_clean':im['dependencies'],'six_modules_fresh':im['modules'],'no_cached_ASTIS_olean':True,'owned_constants':44,'all6_authored_reachable_from_consumer':True,'axioms':native['all_axioms'],'producer_direct_canonical_cosine_parent':True,'consumer_direct_producer_and_radial_parent':True,'actual_private_name':native['actual_private_name'],'frozen_signature_applications':'Both literal sealed signatures compile as actual theorem applications in LiteralApplications.lean; no new mathematical premise.','generated_auxiliaries_outside_consumer_closure':native['unreachable_compiler_auxiliaries'],'full_types_bodies':'All44 types and bodies exported with zero pretty ellipses and hashes; no body missing.','proof_judgment':'Producer forms the PSD sum of (2r-S_i)(I⊗F_i), uses the exact canonical Gram and feature norm bounds and positive scaling. Consumer proves Y_i²=1_good W_i by rank-one/Kronecker squares, gets each integrability from the canonical radial fourth moment, integrates the summed PSD residual in the closed convex real PSD cone, evaluates its mean and adds the producer residual. The only public premise is2q+1<d; q=0 retained; no Gram/moment/integrability theorem is hidden as an input.'},'reader':reader,'source_locators':{'checked':len(loc['checked_locators']),'unique_source_spans':loc['unique_source_spans'],'raw_sha256':loc['source_raw_sha256'],'scope':'Locator integrity only; independent source semantic/topology decisions were neither read nor replaced.'},'typed_historical_harness_failures':history,'HOLD':['independent source fidelity/topology acceptance is a separate lane','real desktop browser','real mobile browser','copy/download runtime','graph interaction/layout','public delivery and integration','whole repository/rootTests/ASTIS gate','post-merge purification and Exposition Seal'],'evidence_capture':'All substantive environment/freeze/build/inspection/literal/locator/renderer/transfer subprocesses have argv/cwd/exit/raw stdout/raw stderr receipts. Initial interactive read-only source/protocol views and inventories remain in the tool transcript; one overbroad preliminary file inventory was truncated and supplied no acceptance evidence. Frozen exact protocol inputs are retained.','ownership':'Only .astis/semantic-neutral-20261112/wf_native_64a2 was written; no source/global/registry/site/ledger edit, no commit, subagent or detached task.'}
report['later_metadata_byte_transfer']=report['later_metadata_byte_transfer'].replace('23 relevant',str(len(comparisons))+' relevant')
(ROOT/'report.json').write_text(json.dumps(report,indent=2)+'\n')
md=f'''Independent native and static reader verification

Candidate compiled: `{im['candidate_commit']}`. Later metadata HEAD `{head}` has identical bytes for all {len(comparisons)} relevant inputs and renderer files. No new compilation is credited to that HEAD.

PASS: six modules compiled topologically from frozen candidate bytes into an initially empty private olean directory; LEAN_PATH contained only that directory and pinned dependency caches. Actual Lean4.33.0 arm64 binary reports commit d8b18978322de05a8f3dba51ef03cf5461676c17. Manifest `{im['files']['lake-manifest.json']['sha256']}` and all nine exact clean dependency HEADs were independently checked twice.

Native inspection covers44 owned constants across all six modules, including all38 compiler auxiliaries. Full types and proof bodies have no pretty ellipses; all axiom closures are subsets of propext, Classical.choice and Quot.sound. All six authored declarations are reachable from the private consumer. Seven unreachable GridAlias simp auxiliaries are listed separately; this is not a purification acceptance. The producer directly consumes the canonical cosine-frame theorem; the private consumer directly consumes the producer and canonical radial fourth matrix moment.

Actual private name: `{native['actual_private_name']}`. Both exact frozen literal propositions were separately kernel-applied without extra hypotheses. Whole-module token scans are clean. The consumer proves each square integrable and uses unnormalized canonical marginal expectations; no original-family, centering or concentration credit is inferred.

Static reader PASS: actual production render_unit/export_sources/render_source_module reproduce binding `{reader['binding_sha256']}`. All six adjacent Lean step folds are exact source substrings and initially closed. The private module has181 lines and starts its theorem atL14. Its four folds preserve every nonblank source line, omitting one blank separator only. Assumptions, formulas and exact local source/download anchors were checked. The shared site was not generated. Current theme reference is hashed and retained solely for bounded source-page shell generation.

HOLD: real desktop/mobile browser and MathJax layout, graph interaction/layout, copy/download runtime, public/integrated delivery, whole-repository gates, source semantic/topology acceptance, and post-merge purification. Infrastructure/API/test-harness failures are retained with typed reasons in report.json and never treated as mathematical refutation.

Reproducible native/static evidence and exact command streams are under receipts/, with frozen inputs, versioned drivers, full bounded native exports and hashes. Initial interactive read-only views remain in the tool transcript; the single truncated preliminary inventory was not acceptance evidence. No source or shared metadata was edited by this verifier.
'''
(ROOT/'report.md').write_text(md)
print(json.dumps({'report':'report.json','compiled_candidate':im['candidate_commit'],'metadata_head':head,'unchanged_relevant_files':len(comparisons),'native':'PASS','static_reader':'PASS','HOLD':report['HOLD']},indent=2))
