import Mathlib.Probability.Distributions.Gaussian.Multivariate
import Mathlib.Probability.Moments.MGFAnalytic
import Mathlib.Probability.Distributions.Gaussian.HasGaussianLaw.Independence
import Mathlib.Tactic
noncomputable section
open MeasureTheory ProbabilityTheory
open scoped ProbabilityTheory ENNReal NNReal Topology
set_option pp.all true
#check (id : ℝ → ℝ)
#check (_root_.id : ℝ → ℝ)
example : (id : ℝ → ℝ) = (fun x : ℝ => x) := rfl
example (v : ℝ≥0) : mgf (fun x : ℝ => x) (gaussianReal 0 v) =
    fun t => Real.exp ((v : ℝ) * t ^ 2 / 2) := by
  simpa only [zero_mul, zero_add] using (mgf_fun_id_gaussianReal (μ := 0) (v := v))
example (v : ℝ≥0) : mgf (id : ℝ → ℝ) (gaussianReal 0 v) =
    fun t => Real.exp ((v : ℝ) * t ^ 2 / 2) := by
  change mgf (fun x : ℝ => x) (gaussianReal 0 v) = _
  simpa only [zero_mul, zero_add] using (mgf_fun_id_gaussianReal (μ := 0) (v := v))
example (a t : ℝ) (f : ℝ → ℝ) (hf : HasDerivAt f (a * t * f t) t) :
    HasDerivAt (fun u => a * u * f u) ((a + a ^ 2 * t ^ 2) * f t) t := by
  have hp := ((hasDerivAt_id t).const_mul a).mul hf
  convert hp using 1 <;> simp only [id_eq, Pi.mul_apply] <;> first | (funext u; ring) | ring
