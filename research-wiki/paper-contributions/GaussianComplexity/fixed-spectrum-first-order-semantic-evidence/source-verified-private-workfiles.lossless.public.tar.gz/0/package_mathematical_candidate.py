from pathlib import Path
import datetime, gzip, hashlib, json, shutil, subprocess, tarfile

sha = lambda b: hashlib.sha256(b).hexdigest()
dump = lambda x: (json.dumps(x, ensure_ascii=False, indent=2) + '\n').encode()
B = Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-first-order-semantic-evidence')
P = Path('.astis/huanjian-gc-fixed-spectrum-first-order-20261108')
HEAD = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
assert HEAD == '6b2d0748e999d98e4453634de85090e26c40b77a'
src = Path('.astis/semantic-neutral-20261108/src_4e8f6a/phase2')
manifest = src / 'freeze_manifest.json'
assert sha(manifest.read_bytes()) == '85a0e1542ce93bd0f65203f136fbe8879f2f9be1713f0c05861ab3885af5971c'
m = json.loads(manifest.read_bytes())
assert len(m['artifacts']) == 9 and not m['final_acceptance']
for row in m['artifacts']:
    raw = (src / row['path']).read_bytes()
    assert len(raw) == row['bytes'] and sha(raw) == row['sha256']
dest = B / 'fresh-source-reader-4e8f6a/phase2'
assert not dest.exists()
shutil.copytree(src, dest)
for p in src.rglob('*'):
    if p.is_file(): assert (dest / p.relative_to(src)).read_bytes() == p.read_bytes()
(B / 'phase2-root-copy-receipt.json').write_bytes(dump({
    'copied_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'original_manifest_sha256': sha(manifest.read_bytes()), 'payloads_checked': 9,
    'all_originals_retained_unchanged': True, 'all_copy_bytes_equal': True,
    'scope': 'Independent provisional statement-level comparison, not sourceV or whole-module acceptance.'}))
cell_path = Path('research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-first-order.json')
cell = json.loads(cell_path.read_bytes())
cell['evidence']['fresh_source_selective_phase2'] = {
    'manifest': str(dest / 'freeze_manifest.json'), 'sha256': sha(manifest.read_bytes()),
    'status': m['status'], 'whole_module_review': 'pending', 'sourceV': False}
cell['source_detail_audit']['fidelity_boundary'] = cell['source_detail_audit']['fidelity_boundary'].replace(
    'is performing selective comparison', 'has separately frozen provisional selective comparison with no blocking local statement delta')
cell_path.write_bytes(dump(cell))
checks = B / 'actual-checks'
checks.mkdir(exist_ok=True)
for p in sorted(Path('.astis/huanjian-resume-20261103').glob('*-fixed-spectrum-first-order-*.receipt.json')):
    r = json.loads(p.read_bytes()); raw = Path(r['log']).read_bytes()
    assert sha(raw) == r['log_sha256']
    dst = checks / p.name
    if dst.exists(): assert dst.read_bytes() == p.read_bytes()
    else: dst.write_bytes(p.read_bytes())
    z = checks / (Path(r['log']).name + '.gz')
    gz = gzip.compress(raw, mtime=0)
    if z.exists(): assert gzip.decompress(z.read_bytes()) == raw
    else: z.write_bytes(gz)
files = sorted(p for p in P.rglob('*') if p.is_file())
archive = B / 'postproof-local-tools.lossless.tar.gz'
assert not archive.exists()
with tarfile.open(archive, 'w:gz') as t:
    for p in files: t.add(p, arcname=str(p.relative_to(P)), recursive=False)
with tarfile.open(archive, 'r:gz') as t:
    assert len(t.getmembers()) == len(files)
    for p in files: assert t.extractfile(str(p.relative_to(P))).read() == p.read_bytes()
(B / 'postproof-local-tools.manifest.json').write_bytes(dump({
    'archive': str(archive), 'archive_sha256': sha(archive.read_bytes()),
    'all_originals_retained': True, 'files': [
        {'original': str(p), 'member': str(p.relative_to(P)), 'bytes': p.stat().st_size,
         'raw_sha256': sha(p.read_bytes())} for p in files]}))
tracked = set(subprocess.check_output(['git', 'ls-files'], text=True).splitlines())
old_wrapped = {r['original_path'] for r in json.loads((B / 'preproof-frozen-raw-packaging/manifest.json').read_bytes())['files']}
pack = B / 'postproof-frozen-raw-packaging'; pack.mkdir()
safe, rows = [], []
for p in sorted(q for q in B.rglob('*') if q.is_file()):
    if str(p) in old_wrapped: continue
    if str(p) in tracked:
        if subprocess.check_output(['git', 'show', 'HEAD:' + str(p)]) == p.read_bytes(): continue
    raw = p.read_bytes()
    ignored = subprocess.run(['git', 'check-ignore', '-q', '--', str(p)]).returncode == 0
    binary = p.suffix in ['.gz', '.png', '.zip'] or b'\0' in raw
    bad = not binary and (b'\r\n' in raw or raw.endswith(b'\n\n') or any(x.endswith((b' ', b'\t')) for x in raw.splitlines()))
    if ignored or bad:
        z = pack / (str(len(rows)).zfill(3) + '-' + p.name + '.gz')
        z.write_bytes(gzip.compress(raw, mtime=0)); assert gzip.decompress(z.read_bytes()) == raw
        rows.append({'original_path': str(p), 'raw_sha256': sha(raw), 'raw_bytes': len(raw),
                     'gzip_path': str(z), 'gzip_sha256': sha(z.read_bytes()),
                     'ignored': ignored, 'raw_whitespace_or_blank_EOF': bad, 'original_retained_unchanged': True})
        safe.append(z)
    else: safe.append(p)
mp = pack / 'manifest.json'
mp.write_bytes(dump({'scope': 'Only frozen raw evidence is losslessly wrapped; all originals retained. Mutable records staged byte-exact.', 'files': rows}))
safe.append(mp)
mutable = [cell_path, Path('research-wiki/paper-contributions/GaussianComplexity/README.md'),
           Path('runs/substantive_advances.jsonl'), Path('runs/substantive_discoveries.jsonl')]
safe += mutable + [Path(x) for x in [
    'AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumFirstOrder.lean',
    'Tests/GaussianComplexityFixedSpectrumFirstOrder.lean',
    'website/content/declaration_lessons/huanjian-fixed-spectrum-first-order.json',
    'website/content/publications/huanjian-fixed-spectrum-first-order.json',
    'research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-first-order.json']]
subprocess.run(['git', 'add', '--', *map(str, safe)], check=True)
subprocess.run(['git', 'diff', '--cached', '--check'], check=True)
for p in mutable: assert subprocess.check_output(['git', 'show', ':' + str(p)]) == p.read_bytes()
for path, expected in {
 'AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumFirstOrder.lean': '1af1a71edf059edfe10a2b5069002fe703b6f2d1a30c153951e06afd3b8e6423',
 'Tests/GaussianComplexityFixedSpectrumFirstOrder.lean': '5d1e1787ea491bb5e0b433eaf1f22743ba9e1d3993becfd9439a0c9d822c4d69',
 'website/content/graph_memory_index.json': '019497faee75c5844ff3d3a08b0ce61c25256918cc29c45b2de5bbaca490b607',
 'website/content/functor_hypergraph.json': '94b56f87136ca97820893e5531d16d36334d44bc6b9e41981d39aa700f8fe782'
}.items(): assert sha(Path(path).read_bytes()) == expected
print(json.dumps({'staged_paths': len(safe), 'new_raw_wrappers': len(rows),
 'phase2_payloads_checked': 9, 'producer_and_consumer_unchanged': True,
 'shared_models_unchanged': True, 'sourceV': False}))
