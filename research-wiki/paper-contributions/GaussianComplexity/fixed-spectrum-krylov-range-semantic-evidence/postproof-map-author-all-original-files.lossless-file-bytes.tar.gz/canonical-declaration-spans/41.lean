def transpose (M : Matrix m n α) : Matrix n m α :=
  of fun x y => M y x
