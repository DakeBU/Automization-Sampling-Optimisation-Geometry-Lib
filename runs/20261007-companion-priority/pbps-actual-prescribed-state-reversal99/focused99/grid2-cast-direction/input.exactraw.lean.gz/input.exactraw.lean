import AutoSamplingTheory.ExampleCases.ProximalBPS.ActualEndpointTimeReversal

namespace PBPSGrid99
open scoped Classical
set_option autoImplicit false

theorem reversed_grid_gaps (n : ℕ) (T : ℝ) (t s : Fin n → ℝ)
    (hs : ∀ i, s i = T - t i.rev) :
    let grid : Fin (n+2) → ℝ := Fin.snoc (Fin.cons 0 t) T
    let barGrid : Fin (n+2) → ℝ := Fin.snoc (Fin.cons 0 s) T
    ∀ j : Fin (n+1),
      barGrid j.succ - barGrid j.castSucc =
        grid j.rev.succ - grid j.rev.castSucc := by
  intro grid barGrid j
  have hl : barGrid j.castSucc = T - grid j.rev.succ := by
    induction j using Fin.cases with
    | zero => simp [grid, barGrid]
    | succ i => simp [grid, barGrid, Fin.rev_succ, Fin.succ_castSucc, hs]
  have hr : barGrid j.succ = T - grid j.rev.castSucc := by
    induction j using Fin.lastCases with
    | last => simp [grid, barGrid]
    | cast i => simp [grid, barGrid, Fin.rev_castSucc, Fin.succ_castSucc, hs]
  rw [hl, hr]
  ring

#print axioms reversed_grid_gaps
end PBPSGrid99
