"""R18 diagnostic DRAFT: actual expanded-proof overflow only; ROOT authorization required."""
import argparse
import datetime as dt
from functools import partial
import hashlib
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
import json
import os
from pathlib import Path
import sys
import tempfile
import threading
import time
import traceback

OWN=Path(__file__).resolve().parent
PARENT=OWN.parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(path,value):
    Path(path).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')

SUMMARY=r'''()=>({viewport:{width:innerWidth,height:innerHeight},
 html:{clientWidth:document.documentElement.clientWidth,scrollWidth:document.documentElement.scrollWidth,offsetWidth:document.documentElement.offsetWidth},
 body:{clientWidth:document.body.clientWidth,scrollWidth:document.body.scrollWidth,offsetWidth:document.body.offsetWidth},
 windowScroll:{x:scrollX,y:scrollY},
 openDisclosures:[...document.querySelectorAll('article.proof-reader details')].map((e,i)=>({index:i,open:e.open,summary:e.querySelector(':scope>summary').textContent.trim()}))})'''

# Every operation in this expression reads DOM/style/ranges; it never changes scroll or CSS.
SCAN=r'''()=>{
 const viewport={width:innerWidth,height:innerHeight};
 const rect=r=>({left:r.left,right:r.right,top:r.top,bottom:r.bottom,width:r.width,height:r.height});
 const path=e=>{const a=[];for(let p=e;p&&p.nodeType===1;p=p.parentElement){let s=p.tagName.toLowerCase();
   if(p.id){a.unshift(s+'#'+p.id);break;}const ps=p.parentElement?[...p.parentElement.children].filter(x=>x.tagName===p.tagName):[];
   if(ps.length>1)s+=':nth-of-type('+(ps.indexOf(p)+1)+')';a.unshift(s);}return a.join(' > ');};
 const props=['display','position','width','min-width','max-width','height','box-sizing','overflow','overflow-x','overflow-y',
   'white-space','overflow-wrap','word-break','padding-left','padding-right','margin-left','margin-right','border-left-width',
   'border-right-width','font-size','line-height','contain','transform','grid-template-columns','flex','flex-shrink'];
 const computed=e=>{const s=getComputedStyle(e);return Object.fromEntries(props.map(p=>[p,s.getPropertyValue(p)]));};
 const basic=e=>({path:path(e),tag:e.tagName,id:e.id,className:typeof e.className==='string'?e.className:e.className.baseVal,
   rect:rect(e.getBoundingClientRect()),clientWidth:e.clientWidth,scrollWidth:e.scrollWidth,offsetWidth:e.offsetWidth,
   computed:computed(e),scroll:{left:e.scrollLeft,top:e.scrollTop}});
 const ancestry=e=>{const out=[];for(let p=e.parentElement;p;p=p.parentElement)out.push(basic(p));return out;};
 const clipBeforeBody=(e,r)=>{let left=r.left,right=r.right;const clips=[];
   for(let p=e.parentElement;p&&p!==document.body&&p!==document.documentElement;p=p.parentElement){
    const s=getComputedStyle(p);if(['auto','scroll','hidden','clip'].includes(s.overflowX)){
      const q=p.getBoundingClientRect();left=Math.max(left,q.left+p.clientLeft);right=Math.min(right,q.left+p.clientLeft+p.clientWidth);
      clips.push({path:path(p),overflowX:s.overflowX,left:q.left+p.clientLeft,right:q.left+p.clientLeft+p.clientWidth});}}
   return{left,right,width:Math.max(0,right-left),clips};};
 const pseudo=(e,which)=>{const s=getComputedStyle(e,which);return{which,content:s.content,display:s.display,width:s.width,
  position:s.position,left:s.left,right:s.right,whiteSpace:s.whiteSpace,transform:s.transform};};
 const matched=e=>{const out=[];const walk=(rules,href,conditions=[],active=true)=>{for(const rule of rules){
   if(rule.selectorText){try{if(e.matches(rule.selectorText)){
    const relevant=props.filter(p=>rule.style.getPropertyValue(p)).map(p=>[p,rule.style.getPropertyValue(p),rule.style.getPropertyPriority(p)]);
    if(relevant.length)out.push({href,conditions,active,selector:rule.selectorText,properties:relevant});}}catch(_){}}
   if(rule.styleSheet){try{walk(rule.styleSheet.cssRules,rule.styleSheet.href,conditions,active);}catch(ex){out.push({href:rule.href,error:String(ex)});}}
   if(rule.cssRules){let conditionActive=true;
    if(rule.constructor.name==='CSSMediaRule')conditionActive=matchMedia(rule.conditionText).matches;
    if(rule.constructor.name==='CSSSupportsRule')conditionActive=CSS.supports(rule.conditionText);
    walk(rule.cssRules,href,[...conditions,{condition:rule.conditionText||rule.name||rule.constructor.name,active:conditionActive}],active&&conditionActive);}}};
   for(const sheet of document.styleSheets){try{walk(sheet.cssRules,sheet.href);}catch(ex){out.push({href:sheet.href,error:String(ex)});}}
   return out;};
 const all=[...document.querySelectorAll('*')],outliers=[],localScrollers=[],documentCandidates=[];
 for(const e of all){const r=e.getBoundingClientRect();if(r.width<=0||r.height<=0)continue;
   if(e.scrollWidth>e.clientWidth+1)localScrollers.push(basic(e));
   if(r.right>viewport.width+1||r.left<-1){const clipped=clipBeforeBody(e,r),b=basic(e);
    outliers.push({...b,bodyContributionClip:clipped});
    if(clipped.width>0&&(clipped.right>viewport.width+1||clipped.left<-1))documentCandidates.push({...b,
      bodyContributionClip:clipped,ancestors:ancestry(e),outerHTML:e.outerHTML.slice(0,1600),
      before:pseudo(e,'::before'),after:pseudo(e,'::after'),matchingLayoutRules:matched(e)});}}
 const textCandidates=[];const walk=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT);
 while(walk.nextNode()){const t=walk.currentNode;if(!t.textContent.trim())continue;const e=t.parentElement;
   if(!e||e.closest('script,style,noscript'))continue;const range=document.createRange();range.selectNodeContents(t);
   for(const rr of range.getClientRects()){if(rr.width<=0||rr.height<=0||!(rr.right>viewport.width+1||rr.left<-1))continue;
    const clipped=clipBeforeBody(e,rr);if(clipped.width>0&&(clipped.right>viewport.width+1||clipped.left<-1))
      textCandidates.push({text:t.textContent,rangeRect:rect(rr),bodyContributionClip:clipped,
        parent:basic(e),ancestors:ancestry(e),matchingParentLayoutRules:matched(e)});}}
 const inlineMath=[...document.querySelectorAll('mjx-container:not([display="true"])')].map(e=>({...basic(e),parentText:e.parentElement.textContent}));
 return{viewport,roots:[basic(document.documentElement),basic(document.body),basic(document.querySelector('main'))],
  windowScroll:{x:scrollX,y:scrollY},allElementCount:all.length,outliers,localScrollers,documentCandidates,textCandidates,inlineMath,
  noProgrammaticScrollStyleTransformAnimationMutation:true};
}'''

class QuietHandler(SimpleHTTPRequestHandler):
    def log_message(self,*_):
        pass

def main(args,a):
    assert a['runner_sha256']==sha(__file__)
    assert sha(PARENT/'actual-result.json')==a['original_result_sha256']
    assert sha(PARENT/'execution-assignment.ROOT.actual-v1.json')==a['original_assignment_sha256']
    preview=Path(a['preview_root']);manifest=preview/'preview-freeze-manifest.json'
    assert sha(manifest)==a['preview_manifest_sha256']
    m=json.loads(manifest.read_text()); fixture=preview/'fixtures/candidate'
    selected=m['variants']['candidate']
    assert {str(x.relative_to(fixture)) for x in fixture.rglob('*') if x.is_file()}=={r['path'] for r in selected['files']}
    for row in selected['files']:
        assert sha(fixture/row['path'])==row['sha256']
    chrome=Path(a['chrome']['path']);assert sha(chrome)==a['chrome']['binary_sha256']
    output=OWN/'diagnostic-runtime-v1';output.mkdir(exist_ok=False)
    tmp=output/'chrome-tmp';tmp.mkdir(mode=0o700);os.environ['TMPDIR']=str(tmp);tempfile.tempdir=str(tmp)
    events=[];scans=[];shots=[];requests=[];responses=[];errors=[];console=[];blocked=[]
    first_overflow=False
    handler=partial(QuietHandler,directory=str(fixture))
    server=ThreadingHTTPServer(('127.0.0.1',0),handler)
    worker=threading.Thread(target=server.serve_forever,daemon=True);worker.start()
    origin='http://127.0.0.1:'+str(server.server_port)
    started=False;version=None
    try:
        from playwright.sync_api import sync_playwright
        with sync_playwright() as pw:
            browser=pw.chromium.launch(executable_path=str(chrome),headless=True)
            started=True;version=browser.version
            context=browser.new_context(viewport={'width':390,'height':844},device_scale_factor=1)
            def route(route):
                if route.request.url.startswith(origin+'/') or route.request.url.startswith(('data:','blob:')):
                    route.continue_()
                else:
                    blocked.append(route.request.url);route.abort()
            context.route('**/*',route);page=context.new_page()
            page.on('request',lambda q:requests.append({'url':q.url,'method':q.method,'resource_type':q.resource_type}))
            page.on('response',lambda q:responses.append({'url':q.url,'status':q.status}))
            page.on('pageerror',lambda e:errors.append(str(e)))
            page.on('console',lambda e:console.append({'type':e.type,'text':e.text}))
            def inspect(stage,full=False):
                nonlocal first_overflow
                s=page.evaluate(SUMMARY);s.update({'stage':stage,'url':page.url});events.append(s)
                overflow=s['body']['scrollWidth']>s['viewport']['width']+1
                if full or (overflow and not first_overflow):
                    scan=page.evaluate(SCAN);p=output/(stage+'.geometry.json');dump(p,scan)
                    scans.append({'stage':stage,'path':str(p.relative_to(OWN)),'sha256':sha(p)})
                    png=output/(stage+'.png');page.screenshot(path=str(png),full_page=True)
                    shots.append({'stage':stage,'path':str(png.relative_to(OWN)),'sha256':sha(png)})
                if overflow:first_overflow=True
            def typeset():
                page.wait_for_function('!!(window.MathJax&&MathJax.startup&&MathJax.startup.promise)')
                page.evaluate('async()=>{await MathJax.startup.promise;await MathJax.typesetPromise();}')
            def open_article(prefix):
                article=page.locator('article.proof-reader')
                for i,detail in enumerate(article.locator('details').all()):
                    if not detail.evaluate('e=>e.open'):
                        # Normal browser actionability scrolling only; no force, JS scroll, or style mutation.
                        detail.locator(':scope>summary').click()
                        inspect(prefix+'-opened-'+str(i))
            page.goto(origin+'/'+selected['proof_path'],wait_until='networkidle');typeset()
            inspect('initial-folded',full=True)
            open_article('first-expansion');typeset();inspect('expanded-before-source-navigation',full=True)
            # Match the original source-link/back disclosure sequence without its intentional formula/table scrolling.
            for i in range(5):
                link=page.locator('article.proof-reader details.proof-reader-step').nth(i).locator('a[data-step-source]')
                prior=page.url
                with page.expect_navigation(wait_until='networkidle'):
                    link.click()
                events.append({'stage':'natural-source-link-'+str(i+1),'url':page.url})
                page.go_back(wait_until='networkidle');page.wait_for_url(prior)
                open_article('back-'+str(i+1));typeset();inspect('after-source-back-'+str(i+1))
            page.wait_for_timeout(500)
            inspect('expanded-final-natural-state',full=True)
            context.close();browser.close()
    finally:
        server.shutdown();server.server_close();worker.join()
    unchanged=all(sha(fixture/row['path'])==row['sha256'] for row in selected['files'])
    result={'schema':'r18-overflow-diagnostic-actual-v1','runner_sha256':sha(__file__),'assignment_sha256':sha(args.assignment),
        'original_result_sha256':sha(PARENT/'actual-result.json'),'preview_manifest_sha256':sha(manifest),
        'events':events,'scans':scans,'screenshots':shots,'requests':requests,'responses':responses,'page_errors':errors,
        'console':console,'blocked_external_requests':blocked,'browser_started':started,'actual_Chrome_version':version,
        'strict_limit_css_px':391,'overflow_reproduced':first_overflow,'fixture_bytes_unchanged':unchanged,
        'original_packet_reexecuted':False,'no_source_anchor_scroll_style_transform_animation_repair':True,
        'diagnostic_not_acceptance':True,'server_and_worker_stopped':True}
    dump(OWN/'diagnostic-result.actual-v1.json',result)
    print(json.dumps({'overflow_reproduced':first_overflow,'events':len(events),'scans':len(scans),'screenshots':len(shots),
        'actual_result_sha256':sha(OWN/'diagnostic-result.actual-v1.json'),'fixture_bytes_unchanged':unchanged}))
    return 0 if started and unchanged and not errors and not blocked else 1

def captured():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--assignment',type=Path,required=True);args=parser.parse_args()
    a=json.loads(args.assignment.read_text())
    if a.get('authorization')!='ROOT_AUTHORIZED_R18_OVERFLOW_DIAGNOSTIC':
        raise RuntimeError('DRAFT only: explicit ROOT authorization for this diagnostic is required; no browser/server starts.')
    os.umask(0o077);process=OWN/'diagnostic-process-v1';process.mkdir(exist_ok=False)
    out=process/'stdout.raw';err=process/'stderr.raw'
    sys.stdout.flush();sys.stderr.flush();o=out.open('xb',buffering=0);e=err.open('xb',buffering=0)
    os.dup2(o.fileno(),1);os.dup2(e.fileno(),2);o.close();e.close()
    started=dt.datetime.now(dt.timezone.utc).isoformat();begin=time.monotonic();code=1;exception=None
    try:code=main(args,a)
    except BaseException as ex:
        exception={'type':type(ex).__name__,'message':str(ex)};traceback.print_exc()
    sys.stdout.flush();sys.stderr.flush()
    dump(process/'receipt.json',{'schema':'r18-overflow-diagnostic-process-v1','argv':[sys.executable,*sys.argv],
        'cwd':str(Path.cwd()),'started_utc':started,'ended_utc':dt.datetime.now(dt.timezone.utc).isoformat(),
        'elapsed_seconds':time.monotonic()-begin,'actual_exit_code':code,'exception':exception,
        'stdout':{'bytes':out.stat().st_size,'sha256':sha(out)},'stderr':{'bytes':err.stat().st_size,'sha256':sha(err)},
        'runner_sha256':sha(__file__),'assignment_sha256':sha(args.assignment),'actual_OS_fd1_fd2_until_exit':True})
    return code

if __name__=='__main__':
    sys.exit(captured())
