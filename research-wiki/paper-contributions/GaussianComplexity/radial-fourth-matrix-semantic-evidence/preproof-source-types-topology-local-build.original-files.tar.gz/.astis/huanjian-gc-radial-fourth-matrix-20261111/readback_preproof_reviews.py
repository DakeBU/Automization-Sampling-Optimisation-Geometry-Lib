"""Bind exact, independently frozen source/type/topology originals for intake."""
from pathlib import Path
import hashlib
import json

workspace = Path(__file__).resolve().parent
sha = lambda raw: hashlib.sha256(raw).hexdigest()
manifests = [
    (Path('.astis/semantic-neutral-20261111/r4_sg_55d8/evidence-manifest.json'), '32fb1c7a85b209dab52ab69c8f73f009bf623a6b9af91c0a84418191d234d802'),
    (Path('.astis/semantic-neutral-20261111/r4_sg_55d8/typed-overlay-v1/typed-overlay-manifest.json'), 'bc82c04245246b7101d494dd09cbbdd0170d69bccdd41420f82a23a7649468ff'),
    (Path('.astis/semantic-neutral-20261111/r4_tc_d390/TOPOLOGY_CHALLENGE_MANIFEST.json'), '28c6b4ccf60d3f296b3647b749b1b410c0a656fbabf3fc6b930ecde1f135c9a7'),
]
originals = {}
for path, digest in manifests:
    raw = path.read_bytes()
    assert sha(raw) == digest, str(path)
    originals[str(path)] = {'path': str(path), 'bytes': len(raw), 'sha256': sha(raw)}
    manifest = json.loads(raw)
    for item in manifest['content_artifacts']:
        original = path.parent / item['path']
        content = original.read_bytes()
        assert len(content) == item['bytes'] and sha(content) == item['sha256'], str(original)
        originals[str(original)] = {'path': str(original), 'bytes': len(content), 'sha256': sha(content)}
typed = json.loads(manifests[1][0].read_bytes())
assert typed['status'] == 'FROZEN_ACCEPT_SOURCE_MATH_EQUIVALENT_CANONICAL_ONE_ROW_FORM'
for key in ('semantic_blockers', 'excess_binders', 'constant_or_index_drifts'):
    assert typed['substantive_verdict'][key] == []
tc_path = Path('.astis/semantic-neutral-20261111/r4_tc_d390/TOPOLOGY_CHALLENGE_VERDICT.json')
tc = json.loads(tc_path.read_bytes())
assert sha(tc_path.read_bytes()) == '9fb73f55ca6a34d0255ce5a56e127c766071fc2fe66a398d9a0618260fe6d188'
assert tc['verdict'].startswith('ACCEPT_MATHEMATICAL_SOURCE_TOPOLOGY')
for key in ('blocking_mathematical_gaps', 'blocking_source_provenance_gaps', 'required_repairs'):
    assert tc[key] == []
assert tc['independence']['prior_freezes_preserved']
assert not tc['independence']['implementation_seen'] and not tc['independence']['Lean_proof_API_seen']
assert not tc['authority']['process_permission_grant'] and not tc['authority']['compiled_truth']
record = {
    'source_type_verdict': 'accepted', 'independent_topology_verdict': 'accepted',
    'remaining_mathematical_source_topology_gaps': [], 'formalizer_API_pristine': False,
    'statement_seal_sha256': 'cc628d801ed367e1e57e99d69449d36a90b2803f7371986b964b4864409f6dec',
    'SG_original_verdict': typed['status'], 'TC_original_verdict': tc['verdict'],
    'independent_originals': list(originals.values()),
    'mathematical_obligations': 'All Gaussian moment/law, quartic integrability, matrix-square, tensor, Bochner and PSD bridges remain to be proved internally.',
    'source_scope': 'Exact canonical one-row bundles, including the source-supported individual inference and q=0. Original-family transport, aggregation, concentration and full-paper claims remain open.',
    'authority': 'Independent mathematical source/type/topology judgments only. Existing user authorization supports normal intake. This record is not a new permission grant or proof verdict.',
}
raw = (json.dumps(record, ensure_ascii=False, indent=2) + '\n').encode()
with (workspace / 'reviewed-preproof-inputs.json').open('xb') as out:
    out.write(raw)
print(json.dumps({'originals_rehashed': len(originals), 'record_sha256': sha(raw),
                  'source_type': 'accepted', 'topology': 'accepted', 'required_repairs': []}))
