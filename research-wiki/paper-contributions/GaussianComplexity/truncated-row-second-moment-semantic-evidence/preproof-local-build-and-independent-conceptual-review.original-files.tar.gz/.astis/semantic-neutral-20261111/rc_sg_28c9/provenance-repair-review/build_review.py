from pathlib import Path
from html import unescape
import hashlib,json,re,bisect
from datetime import datetime,timezone
B=Path('/Users/zhouhuanjian/ASTIS-GC'); OWN=B/'.astis/semantic-neutral-20261111/rc_sg_28c9'; OUT=OWN/'provenance-repair-review'; OTHER=B/'.astis/semantic-neutral-20261111/rc_tc_c61a'
H=lambda b:hashlib.sha256(b).hexdigest()
def write(n,x):
 f=OUT/n;f.parent.mkdir(parents=True,exist_ok=True)
 if isinstance(x,bytes):f.write_bytes(x)
 elif isinstance(x,str):f.write_text(x,encoding='utf-8')
 else:f.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
inputs={
'proposed_minimal_provenance_overlay.json':'a966b192841e30a00d6962e20b2ef2973e55b2e56225b2b4310eb065d8cae145',
'topology_challenge.md':'c88ed263da791dc81abce8eac4635f0f8ff018a6459c25bc782b5bb772b025e5',
'topology_challenge_verdict.json':'7f6d2b1afab961e6fd7e50eef81e59632cd4f558292830d75e2d494335f793c5',
'topology_additional_source_context.json':'49287ad3ebe4838227f30cb1fa55126aa41f12f7230032aab8403d4d7cc498df'}
for n,h in inputs.items():
 b=(OTHER/n).read_bytes();assert H(b)==h;write('reviewed-inputs/'+n,b)
proposal=json.loads((OTHER/'proposed_minimal_provenance_overlay.json').read_text());extra=json.loads((OTHER/'topology_additional_source_context.json').read_text())
# Verify and preserve both prior freezes; new files are not inserted into them.
previous=[]
for mp,want in [(OWN/'freeze-manifest.json','6ef5690685a487a0b2de8953221a434db6f761a0478786bd5b7cf45951dbfc3f'),(OWN/'type-overlay-v2/type-freeze-manifest.json','341c0a7d6e98ed1d62498ee8c74ee2a75d71eaeb7fab2b92eff1b1d46f5fa697')]:
 assert H(mp.read_bytes())==want;m=json.loads(mp.read_text())
 for f in m['files']:assert H((mp.parent/f['relative_path']).read_bytes())==f['sha256']
 previous.append({'path':str(mp),'sha256':want,'all_listed_files_unchanged':len(m['files'])})
g=json.loads((OWN/'source-graph.json').read_text())
raw=B/'.astis/huanjian-resume-20261103/2610.20492v1.html'; rb=raw.read_bytes();assert H(rb)=='6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915';s=rb.decode()
ls=[0]+[m.end() for m in re.finditer('\n',s)];bp=[0]
for c in s:bp.append(bp[-1]+len(c.encode()))
def loc(a,z):
 l=bisect.bisect_right(ls,a)-1;e=bisect.bisect_right(ls,z)-1
 return dict(source_path=str(raw),char_start=a,char_end_exclusive=z,utf8_byte_start=bp[a],utf8_byte_end_exclusive=bp[z],start_line_1based=l+1,start_column_0based=a-ls[l],end_line_1based=e+1,end_column_0based=z-ls[e],sha256=H(s[a:z].encode()))
anchors={}
for i in ['S4.E11.m1','A3.SS2.p5.m2','A3.Ex85.m1']:
 a=s.index('<math id="'+i+'"');z=s.index('</math>',a)+len('</math>');l=loc(a,z)
 supplied=extra['locators'][i]
 for k,v in l.items():
  if k!='source_path':assert supplied[k]==v,(i,k,supplied[k],v)
 write('additional-raw/'+i+'.html',s[a:z])
 anchors[i]={'html_id':i,'locator':l,'saved_path':str(OUT/'additional-raw'/f'{i}.html'),'alttext':unescape(re.search(r'alttext="([^"]*)"',s[a:z]).group(1))}
assert anchors['S4.E11.m1']['alttext'].startswith(r'\theta_{i}=\frac{(i-\tfrac{1}{2})\pi}{d},\qquad')
assert anchors['A3.SS2.p5.m2']['alttext']==r'0,\ldots,q'
assert anchors['A3.Ex85.m1']['alttext'].startswith(r't_{i}=(1,\sqrt{2}\cos\theta_{i},\ldots,\sqrt{2}\cos(q\theta_{i}))^{\top},\qquad')
write('independent-anchor-verification.json',{'source_sha256':H(rb),'anchors':anchors,'all_proposed_locator_coordinates_and_digests_match':True,'reading':'Theta is source (i-1/2)π/d; coordinates are 0,...,q; Ex85 itself gives constant coefficient 1 and higher coefficient sqrt(2). No source-named c_k is needed or attributed.','additional_exposure':'Read exact named elements plus three physical neighboring lines during first verification. A neighboring cosine-sum conclusion and aggregate-table introduction were seen but excluded. Challenge artifacts were read only at this separately authorized repair-review stage.'})
# Exact raw-character partition for each genuinely new math element. S4 shared
# display is divided by its duplicate alttext, MathML, and TeX-annotation layers.
coverage=[]
def cv(a,z,disp,meaning):
 if a<z:coverage.append({'disposition':disp,'meaning':meaning,'locator':loc(a,z)})
a=anchors['S4.E11.m1']['locator']['char_start'];z=anchors['S4.E11.m1']['locator']['char_end_exclusive']
altstart=s.index('alttext="',a)+len('alttext="');altend=s.index('"',altstart)
altsep=s.index(r',\qquad',altstart,altend)
mlstart=s.index('<mrow>',altend)+len('<mrow>');mlsep=s.index('<mo rspace="2.167em">,</mo>',mlstart)
annstart=s.index('<annotation encoding="application/x-tex">',mlsep)+len('<annotation encoding="application/x-tex">');annend=s.index('</annotation>',annstart);annsep=s.index(r',\qquad',annstart,annend)
cv(a,altstart,'EXCLUDED','Opening math tag and attribute scaffolding.')
cv(altstart,altsep,'NODE CTX.theta-grid','Exact midpoint-grid clause in alttext.')
cv(altsep,altend,'EXCLUDED','Alttext delimiter and eigenvalue/Lambda clauses; no kappa/eigenvalue dependency.')
cv(altend,mlstart,'EXCLUDED','Math/semantics wrapper scaffolding.')
cv(mlstart,mlsep,'NODE CTX.theta-grid','Exact midpoint-grid clause in rendered MathML.')
cv(mlsep,annstart,'EXCLUDED','Delimiter, eigenvalue/Lambda MathML clauses, and TeX annotation wrapper.')
cv(annstart,annsep,'NODE CTX.theta-grid','Exact midpoint-grid clause in TeX annotation.')
cv(annsep,annend,'EXCLUDED','Annotation delimiter and eigenvalue/Lambda clauses.')
cv(annend,z,'EXCLUDED','Closing annotation/semantics/math wrappers.')
a2=anchors['A3.SS2.p5.m2']['locator']['char_start'];z2=anchors['A3.SS2.p5.m2']['locator']['char_end_exclusive'];cv(a2,z2,'NODE CTX.feature-normalization','Entire explicit feature-coordinate index range 0,...,q, in all HTML representations.')
checks=[]
for i in ['S4.E11.m1','A3.SS2.p5.m2']:
 a=anchors[i]['locator']['char_start'];z=anchors[i]['locator']['char_end_exclusive'];rows=sorted([x for x in coverage if a<=x['locator']['char_start'] and x['locator']['char_end_exclusive']<=z],key=lambda x:x['locator']['char_start']);cur=a
 for row in rows:assert row['locator']['char_start']==cur;cur=row['locator']['char_end_exclusive']
 assert cur==z;checks.append({'html_id':i,'rows':len(rows),'gap_chars':0,'overlap_chars':0,'chars':z-a,'utf8_bytes':bp[z]-bp[a]})
write('supplemental-coverage.json',{'universe':'Only two new complete raw math elements; Ex85 is already exhaustively covered by the original raw freeze and is reused without changing that coverage. This does not expand coverage to whole neighboring sections.','checks':checks,'rows':coverage,'retained_existing_membership':'A3.Ex85.m1 t_i clause: first coordinate 1, positive-coordinate sqrt(2) cos(k theta_i), gamma clause remains the existing separate gamma-assembly component.','excluded_context':'No kappa/eigenvalue/Lambda, Haar rotation, Krylov range, cosine telescoping, product-to-sum, frame, norm, tail or concentration statement is introduced.'})
# Component ports make precise which portions of bundled original source nodes
# are mathematical prerequisites and which carry exact-definition attribution.
ports=[]
def port(i,node,meaning,channel='mathematical',refs=None):ports.append({'id':i,'source_node':node,'meaning':meaning,'channel':channel,'source_refs':refs or [],'compiled_status':'not implementation or compiled dependency'})
for i,n,m in [
('S.qd#standing','S.qd','Natural q,d and 2q+1<d.'),('S.g#joint-input-law','S.g','Source independent g_a~N(0,I_d) standing input.'),('D.r#dimension','D.r','r=q+1.'),('D.index#rows','D.index','Source rows 1,...,d.'),('D.vectors#gamma-assembly','D.vectors','Only gamma_i=((g_1)_i,...,(g_r)_i); no theta or feature data.'),('D.vectors#deterministic-feature','D.vectors','Only that the t_i factor is a fixed real r-vector; no grid or orthogonality theorem.'),('S.gamma#marginal-common-law','S.gamma','Standard Gaussian marginal and common marginals; cross-row independence not consumed.'),('D.LR#radius','D.LR','R_i=||gamma_i||².'),('D.LR#cutoff','D.LR','Shared L=2r+3 log(1000d).'),('D.a#coefficient','D.a','Displayed retained radial moment divided by r.'),('D.Y#formula','D.Y','Source summand formula in terms of gamma_i and a deterministic feature t_i.'),('G.positive#dimensions','G.positive','Derived positive r,d and nonzero casts.'),('G.radial#invariance','G.radial','Gaussian and cutoff symmetry.'),('G.integrable#moments','G.integrable','Measurability, scalar/coordinate/matrix integrability.'),('G.coordinates#isotropic','G.coordinates','Off-diagonal cancellation, equal diagonals, scalar identity form.'),('G.trace#normalization','G.trace','Trace/integral exchange identifies the literal scalar.'),('C.common#scalar','C.common','Same scalar for all rows.'),('C.cov#mathematical','C.cov','First source mathematical root.'),('G.EY#transport','G.EY','Deterministic-factor tensor expectation transport.'),('C.EY#mathematical','C.EY','Immediate source summand-mean mathematical root.')]:port(i,n,m)
port('D.vectors#feature-shape','D.vectors','Literal Ex85 feature shape in theta_i, with 1 and sqrt(2) coefficients.','definition-provenance',['A3.Ex85.m1'])
port('CTX.theta-grid#definition','CTX.theta-grid','theta_i=(i-1/2)π/d, first clause only.','definition-provenance',['S4.E11.m1'])
port('CTX.feature-normalization#coordinates','CTX.feature-normalization','Feature k=0,...,q, coefficient 1 at k=0 and sqrt(2) for k>0; c_k is only optional encoding.','definition-provenance',['A3.SS2.p5.m2','A3.Ex85.m1'])
port('CTX.fin-reindex#adapter','CTX.fin-reindex','j:Fin d ↦ source row j.val+1; k:Fin(q+1) ↦ source feature index k.val.','definition-provenance',['S4.E11.m1','A3.SS2.p5.m2','A3.Ex85.m1'])
port('T.literal-feature#attribution','T.literal-feature','The sealed consumer theta,t definitions are exactly the source feature after finite-index conversion.','definition-provenance',['A3.Ex107.m1','A3.SS2.p12.m5'])
port('C.EY#exact-source','C.EY','Mathematical mean result together with exact literal-feature source identification.','combined-root',['A3.SS2.p12.m5'])
edges=[]
def edge(fr,to,ch,why,original=None):edges.append({'prerequisites':fr,'consumer':to,'channel':ch,'reason':why,'original_hyperedge_1based':original,'semantics':'All listed inputs are used within this channel; provenance edges are not additional mathematical premises.'})
edge(['S.qd#standing','D.r#dimension'],'G.positive#dimensions','mathematical','Exact original arithmetic bridge.',1)
edge(['S.g#joint-input-law','D.r#dimension','D.index#rows','D.vectors#gamma-assembly'],'S.gamma#marginal-common-law','mathematical','Gamma projection only; feature/angle data are not consumed.',2)
edge(['S.gamma#marginal-common-law','D.LR#radius','D.LR#cutoff'],'G.radial#invariance','mathematical','Gaussian law and radial cutoff invariance.',3)
edge(['S.gamma#marginal-common-law','D.LR#radius','D.LR#cutoff'],'G.integrable#moments','mathematical','One sufficient Gaussian finite-moment route.',4)
edge(['G.radial#invariance','G.integrable#moments'],'G.coordinates#isotropic','mathematical','Integrable symmetry argument.',5)
edge(['G.coordinates#isotropic','G.integrable#moments','D.LR#radius','D.LR#cutoff','G.positive#dimensions'],'G.trace#normalization','mathematical','Trace normalization.',6)
edge(['S.gamma#marginal-common-law','D.LR#radius','D.LR#cutoff','D.a#coefficient'],'C.common#scalar','mathematical','Common marginal law and cutoff, without family independence.',7)
edge(['D.a#coefficient','G.trace#normalization','C.common#scalar'],'C.cov#mathematical','mathematical','Identify displayed covariance coefficient.',8)
edge(['D.Y#formula','D.vectors#deterministic-feature','G.integrable#moments','G.positive#dimensions'],'G.EY#transport','mathematical','Only deterministic feature-vector port; no grid/frame property.',9)
edge(['G.EY#transport','C.cov#mathematical'],'C.EY#mathematical','mathematical','Immediate source consumer.',10)
edge(['D.index#rows','D.r#dimension','CTX.theta-grid#definition','CTX.feature-normalization#coordinates'],'CTX.fin-reindex#adapter','definition-provenance','Algebraic row/coordinate conversion. i_src=j.val+1 gives i_src-1/2=j.val+1/2; k.val already spans 0,...,q.')
edge(['D.vectors#feature-shape','CTX.fin-reindex#adapter'],'T.literal-feature#attribution','definition-provenance','Literal t formula plus exact source angle/coordinate reindexing matches sealed T; no signature change.')
edge(['C.EY#mathematical','T.literal-feature#attribution'],'C.EY#exact-source','combined-root','Join the unchanged mathematical route with its exact-definition source attribution; these channels remain labeled separately.')
P={x['id'] for x in ports};assert len(P)==len(ports)
parents={x:set() for x in P};children={x:set() for x in P}
for e in edges:
 assert e['consumer'] in P
 for x in e['prerequisites']:assert x in P;parents[e['consumer']].add(x);children[x].add(e['consumer'])
# Complete port closure, with no partial/lazy referenced endpoints.
def close(r):
 seen=set();todo=[r]
 while todo:
  x=todo.pop()
  if x in seen:continue
  seen.add(x);todo.extend(parents[x])
 return sorted(seen)
roots=['C.cov#mathematical','C.EY#mathematical','C.EY#exact-source'];closures={r:close(r) for r in roots}
indeg={x:len(parents[x]) for x in P};queue=sorted(x for x in P if indeg[x]==0);order=[]
while queue:
 x=queue.pop(0);order.append(x)
 for y in sorted(children[x]):
  indeg[y]-=1
  if indeg[y]==0:queue.append(y);queue.sort()
assert len(order)==len(P)
assert set.union(*(set(v) for v in closures.values()))==P
cov=set(closures['C.cov#mathematical']);mean=set(closures['C.EY#mathematical']);exact=set(closures['C.EY#exact-source'])
assert not any(x.startswith('CTX.') or 'feature' in x or 'literal' in x for x in cov)
assert not any(x.startswith('CTX.') or 'literal' in x or 'feature-shape' in x for x in mean)
from collections import Counter
assert Counter(e['original_hyperedge_1based'] for e in edges if e['original_hyperedge_1based'] is not None)==Counter({i:1 for i in range(1,11)})
source_roots={r:sorted({next(x['source_node'] for x in ports if x['id']==n) for n in cl}) for r,cl in closures.items()}
assert set(source_roots['C.cov#mathematical'])==set(g['root_backward_closure']['C.cov'])
assert set(source_roots['C.EY#mathematical'])==set(g['root_backward_closure']['C.EY'])
write('reviewed-port-overlay.json',{'schema':'separately-reviewed-source-provenance-port-overlay-v1','status':'ACCEPTED_REPAIR_WITH_EXPLICIT_COMPONENT_PORTS','base_raw_graph_sha256':H((OWN/'source-graph.json').read_bytes()),'base_typed_overlay_sha256':H((OWN/'type-overlay-v2/typed-source-graph-overlay.json').read_bytes()),'reviewed_proposal_sha256':inputs['proposed_minimal_provenance_overlay.json'],'statement_seal_sha256':proposal['statement_seal_sha256'],'original_files_unchanged':True,'ports':ports,'hyperedges':edges,'root_ports':roots,'root_backward_port_closure':closures,'root_backward_source_node_closure':source_roots,'new_source_context_nodes':proposal['additional_context_nodes'],'root_interpretation':{'C.cov#mathematical':'Covariance mathematical root, with no theta or feature-provenance dependency.','C.EY#mathematical':'Unchanged minimal deterministic-feature mathematical mean route.','C.EY#exact-source':'Same mean route plus exact earlier-source attribution of sealed literal theta,t.'},'unconsumed_source_context':'Cross-row independence in the source S.gamma statement remains side context; kappa/eigenvalue/Lambda/Haar/range/frame/cosine-sum results remain excluded.','no_compiled_dependency_claim':True,'no_new_public_premises':True,'no_process_or_proof_grant':True})
checks={'all_port_ids_unique':True,'all_edge_endpoints_defined':True,'all_original_10_hyperedges_refined_exactly_once':True,'acyclic':True,'topological_order':order,'all_ports_in_some_complete_root_backward_closure':True,'orphan_ports':[],'root_closure_counts':{r:len(v) for r,v in closures.items()},'covariance_contains_no_theta_feature_or_literal_attribution_port':True,'mean_mathematical_closure_contains_no_added_grid_context':True,'original_source_node_closures_of_both_mathematical_roots_unchanged':True,'exact_source_delta_ports':sorted(exact-mean),'new_raw_coverage_checks':checks,'original_freezes_rechecked':previous,'scope':'Structural checks establish referenced closure, port separation, acyclicity and exact source locators. The mathematical acceptance of this narrow repair is the independent review judgment, not a consequence of structural lint.'}
write('closure-and-integrity-checks.json',checks)
write('repair-review-judgment.json',{'decision':'ACCEPT narrow exact-feature provenance repair; reviewed port refinement makes the proposed component separation mechanically explicit','reviewer':'/root/radial_cov_source_graph_28c9; separate from the proposer whose artifact namespace is rc_tc_c61a','proposal_sha256':inputs['proposed_minimal_provenance_overlay.json'],'accepted_facts':['Raw S4.E11.m1 gives theta_i=(i-1/2)π/d.','Raw A3.SS2.p5.m2 explicitly labels t coordinates 0,...,q.','Raw Ex85 itself gives constant coordinate 1 and higher coefficients sqrt(2); c_k is optional encoding, not an attributed source-named object.','The Fin row conversion i_src=j.val+1 gives exactly the sealed midpoint formula; feature frequency is k.val.','At q=0 the feature coordinate range is the singleton 0 and t=(1).','Theta and feature normalization are source-definition attribution, not covariance mathematical premises.'],'modification_to_proposal':'No source formula or target signature revised. Full named component ports and separate mathematical/exact-attribution root channels replace prose-only port annotations for mechanical closure and cycle checking.','source_mismatch_repaired':'The earlier exact-grid membership gap is closed by independently rechecked pinned raw anchors. Earlier frozen limitation remains truthful and unchanged as historical evidence.','all_prior_freezes_unchanged':True,'implementation_or_proof_apis_seen':False,'normal_intake_or_verification_granted':False,'new_status_scope':'Acceptance of this provenance repair only; no separate process grant, proof compilation, source theorem completion, VERIFIED, publication or stabilization.'})
write('repair-review.md','''# Independent review of the exact-feature provenance repair

I accept the narrow provenance supplement, with the mechanically explicit component-port refinement frozen in reviewed-port-overlay.json. This changes no target signature, mathematical route, source assumption, or existing frozen file.

I independently reopened the pinned raw source. S4.E11.m1 gives θ_i=(i−1/2)π/d. A3.SS2.p5.m2 explicitly labels feature coordinates 0,…,q. Ex85 itself gives constant coordinate 1 and higher coefficients √2. A name c_k is optional encoding; it is not a source-named object in these displays. For j:Fin d, source row i=j.val+1 yields precisely (j.val+1/2)π/d. Feature frequency k is k.val. At q=0 the single feature is 1.

The derivative uses gamma and feature component ports. The covariance root consumes only gamma assembly and the Gaussian marginal/common-law ports. Its complete backward closure has no midpoint or feature-attribution port. The mathematical E Y route needs only a deterministic feature vector and remains unchanged. A separately labeled exact-source root joins that mathematical route with the literal-feature provenance. This avoids turning the earlier grid, eigenvalues, frame identities, or cross-row independence into false mathematical prerequisites.

All ten original hyperedges are refined exactly once. All port endpoints exist, every port occurs in a complete root closure, and the graph is acyclic. Projecting the two mathematical root closures back to original node ids gives exactly the original source-node closures. The two new raw-element universes are fully partitioned with exact character/UTF-8 byte/line/column/hash locations; shared-display eigenvalue/Lambda clauses are explicitly excluded. Ex85 reuses its unchanged original coverage.

This accepts only the separately proposed provenance repair. No proof/API implementation was read; no process, intake, verification, publication, or mathematical completion status is granted. The original raw and typed freezes remain intact.
''')
manifest={'schema':'independent-provenance-repair-review-freeze-v1','frozen_at_utc':datetime.now(timezone.utc).isoformat(),'phase':'separate review of topology challenger proposed narrow provenance overlay','raw_freeze_sha256':previous[0]['sha256'],'type_freeze_sha256':previous[1]['sha256'],'challenge_full_manifest_sha256_as_supplied_by_root':'9d43828dabe00fd18dd53a2557cbd5dd547a4b4649d814d46d3118c405909a0d','challenge_full_manifest_note':'Identifier supplied by root; only the four explicitly authorized challenge files were opened and rehashed.','reviewed_input_hashes':inputs,'files':[],'exclusions':['repair-review-freeze-manifest.json (self-reference)','REPAIR-REVIEW-FREEZE-RECEIPT.json (authenticates manifest)'],'no_process_or_proof_grant':True}
for f in sorted(OUT.rglob('*')):
 if f.is_file() and f.name not in {'repair-review-freeze-manifest.json','REPAIR-REVIEW-FREEZE-RECEIPT.json'}:
  b=f.read_bytes();manifest['files'].append({'relative_path':str(f.relative_to(OUT)),'bytes':len(b),'sha256':H(b)})
write('repair-review-freeze-manifest.json',manifest)
receipt={'manifest_path':str(OUT/'repair-review-freeze-manifest.json'),'manifest_sha256':H((OUT/'repair-review-freeze-manifest.json').read_bytes()),'listed_files':len(manifest['files']),'reviewed_port_overlay_sha256':H((OUT/'reviewed-port-overlay.json').read_bytes()),'judgment_sha256':H((OUT/'repair-review-judgment.json').read_bytes()),'closure_checks_sha256':H((OUT/'closure-and-integrity-checks.json').read_bytes()),'root_closure_counts':checks['root_closure_counts'],'original_raw_and_type_freezes_unchanged':True,'no_process_grant':True}
write('REPAIR-REVIEW-FREEZE-RECEIPT.json',receipt)
print(json.dumps(receipt,indent=2))
