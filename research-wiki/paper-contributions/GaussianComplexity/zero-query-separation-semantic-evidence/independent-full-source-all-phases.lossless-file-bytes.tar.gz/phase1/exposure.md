# Phase 1 exposure disclosure

This reviewer is distinct from the source author, source-topology extractor/reviewer, formalizer and blind decoder by the assigned role. No implementation, candidate signature/seal, P/T package, anonymous reconstruction, lesson/publication/audit/registry, prior mathematical verdict, source graph package, producer runtime check or Lean/API search was opened. No Lean or native verification was run. Root supplied only the procedural fact that a locally checked producer exists; I do not use that as source-fidelity evidence. The root task supplied the source identifier, exact selected anchor and source hash, and explicitly named the model/common-law and disclosed-spectrum issues as questions. Those topics were therefore prompted, not discovered without prompting; my answers were reconstructed from the raw source.

I make no pristine/pretraining-zero-knowledge guarantee. My model has general prior mathematical knowledge. The procedural documents include project history, source-family names and workflow status; that is not hidden from this reviewer. Mathematical judgments above are tied to the pinned original, not to those historical status statements.

One avoidable scope error occurred while locating the contributor contract. The actual command was `rg --files -g '*CONTRIBUT*' -g '*contribut*' -g AGENTS.md docs .agents .`. The final `.` made this a broad filename inventory. The tool reported 694 output lines and 23557 original tokens, and returned a truncated excerpt; I did not receive or save the full stdout, and do not invent it here. No returned path was opened except explicitly requested current procedural files (`AGENTS.md`, `CONTRIBUTING.md`, contributor contract/bootstrap). I immediately informed the root and have not repeated any repository/runs/semantic-evidence inventory.

The following filename-only names were actually visible in the returned excerpt. They may suggest historical roles/status, so I do not characterize the run as zero-exposure. I saw no content of these files:

```text
docs/contributor-codex-contract.md
.agents/prompts/collaborator-contribution.md
./docs/contributor-codex-contract.md
./AGENTS.md
./CONTRIBUTING.md
./tools/astis_contributor_contract.py
./website/diagrams/contribution-route.mmd
./tools/tests/test_astis_contributor_contract.py
./research-wiki/technical-lemmas/quadratic-feature-risk-contribution.json
./research-wiki/technical-lemmas/gaussian-polynomial-joint-risk-contribution.json
./research-wiki/technical-lemmas/quadratic-probability-segment-contribution.json
./research-wiki/technical-lemmas/gaussian-polynomial-l2-differentiation-contribution.json
./research-wiki/technical-lemmas/gaussian-polynomial-ridge-contribution.json
./research-wiki/technical-lemmas/bochner-mean-quadratic-transport-contribution.json
./research-wiki/technical-lemmas/gaussian-polynomial-parameter-average-contribution.json
./research-wiki/technical-lemmas/unit-sphere-angular-cost-contribution.json
./research-wiki/technical-lemmas/quadratic-feature-tangent-gradient-contribution.json
./research-wiki/technical-lemmas/gaussian-polynomial-l2-continuity-contribution.json
./research-wiki/technical-lemmas/optimisation-contributor-audit.md
./research-wiki/technical-lemmas/quadratic-feature-law-gradient-contribution.json
./research-wiki/technical-lemmas/gaussian-polynomial-derivative-bounds-contribution.json
./research-wiki/technical-lemmas/joint-empirical-segment-risk-contribution.json
./research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-threshold-semantic-evidence/review-gates-before-schema-adapter/20261110T052454426020Z-threshold-reviewed-contributor.log.gz
./research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-threshold-semantic-evidence/review-gates-before-schema-adapter/20261110T052454426020Z-threshold-reviewed-contributor.receipt.json
./research-wiki/paper-contributions/GaussianComplexity/tv-amplification-semantic-evidence/actual-checks/20261107T054146325007Z-ex72-preproof-contributor.log.gz
./research-wiki/paper-contributions/GaussianComplexity/tv-amplification-semantic-evidence/actual-checks/20261107T054146325007Z-ex72-preproof-contributor.receipt.json
./research-wiki/paper-contributions/GaussianComplexity/tv-amplification-semantic-evidence/actual-checks/20261107T061130525946Z-ex72-local-contributor.log.gz
./research-wiki/paper-contributions/GaussianComplexity/tv-amplification-semantic-evidence/actual-checks/20261107T061130525946Z-ex72-local-contributor.receipt.json
./research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-first-order-semantic-evidence/fresh-source-reader-4e8f6a/phase1/inputs/AGENTS.md
./research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-threshold-semantic-evidence/review-gates-after-schema-adapter/20261110T053849678358Z-threshold-adapted-contributor.receipt.json
./research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-threshold-semantic-evidence/review-gates-after-schema-adapter/20261110T053849678358Z-threshold-adapted-contributor.log.gz
```

The output then contained an explicit truncation marker and the visible tail fragment `malization103/exact-commit-verification103/contributor.receipt.json`; its missing prefix is unknown and not reconstructed. The visible final names were:

```text
./runs/20261007-companion-priority/pbps-sharp-energy68/exact-science-verification/contributor.stderr.log
./runs/20261007-companion-priority/pbps-sharp-energy68/exact-science-verification/contributor.stdout.log
./runs/20261007-companion-priority/pbps-sharp-energy68/exact-science-verification/contributor.receipt.json
./runs/20261007-companion-priority/pbps-actual-bounded-test-continuity83/exact-commit-verification83/contributor.stderr.log.gz
./runs/20261007-companion-priority/pbps-actual-bounded-test-continuity83/exact-commit-verification83/contributor.stdout.log.gz
./runs/20261007-companion-priority/pbps-actual-bounded-test-continuity83/exact-commit-verification83/contributor.receipt.json
./runs/20261007-companion-priority/pbps-actual-phase-reversal-volume96/exact-commit-verification96/contributor.stderr.log.integration96.raw.gz
./runs/20261007-companion-priority/pbps-actual-phase-reversal-volume96/exact-commit-verification96/contributor.stdout.log.integration96.raw.gz
./runs/20261007-companion-priority/pbps-actual-phase-reversal-volume96/exact-commit-verification96/trial949bd4c/contributor.stderr.log.integration96.raw.gz
./runs/20261007-companion-priority/pbps-actual-phase-reversal-volume96/exact-commit-verification96/trial949bd4c/contributor.stdout.log.integration96.raw.gz
./runs/20261007-companion-priority/pbps-actual-phase-reversal-volume96/exact-commit-verification96/trial949bd4c/contributor.receipt.json
./runs/20261007-companion-priority/pbps-actual-phase-reversal-volume96/exact-commit-verification96/contributor.receipt.json
./runs/20261007-companion-priority/pbps-actual-finite-count-path93/exact-commit-verification93/contributor.stdout.log.integration93.raw.gz
./runs/20261007-companion-priority/pbps-actual-finite-count-path93/exact-commit-verification93/contributor.stderr.log.integration93.raw.gz
./runs/20261007-companion-priority/pbps-actual-finite-count-path93/exact-commit-verification93/contributor.receipt.json
./runs/20261007-companion-priority/pbps-centered-defect59/cell.0.before-contributor-completion.raw.snapshot.json
./runs/20261007-companion-priority/pbps-centered-defect59/cell.1.before-contributor-completion.raw.snapshot.json
./runs/20261007-companion-priority/pbps-centered-defect59/contributor.initial-negative.json
./runs/20261007-companion-priority/pbps-root-commutation67/exact-science-verification67/contributor.stderr.log
./runs/20261007-companion-priority/pbps-root-commutation67/exact-science-verification67/contributor.stdout.log
./runs/20261007-companion-priority/pbps-root-commutation67/exact-science-verification67/contributor.receipt.json
```

These names increased awareness that historical fixed-spectrum and contributor-check records exist. I cannot detect a specific resulting change in a mathematical judgment; all conclusions about spectra, common laws, targets and constants were independently derived from the raw original and are explained in `cognition.md`. This is a limited honest influence statement, not proof of absence of anchoring.

Original-source exposure is broader than the selected paragraph. Full Section 2 and the Section 3 statement were read, and initial bounded raw slices exposed the start of Section 3.1 construction and the next Section 3.3 comparison paragraph. A search confined to the original HTML for spectrum/disclosure/eigenvalue wording returned 14 source paragraphs, including fixed-spectrum and appendix context. Their IDs and the initial character slices are recorded in `raw_read_exposure.json`. No graph or contract paraphrase was used to supply the selected mathematical claim.

Procedural documents read are pinned in `procedural_inputs.json` and local copies. Their instructions requiring implementation/API searches or publication/native operations do not apply during this assigned anti-anchored source-only phase; performing them now would violate the root's stricter exposure boundary. This is a limited review subtask, not a new source implementation or scheduling action.
