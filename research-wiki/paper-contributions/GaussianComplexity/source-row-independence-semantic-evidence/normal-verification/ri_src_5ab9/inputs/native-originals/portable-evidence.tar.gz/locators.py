"""Recompute every byte, Unicode character, LF locator and archive-member hash."""
import json,tarfile
from run import ROOT,REPO,sha
I=ROOT/'inputs';m=json.loads((ROOT/'input-manifest.json').read_text());E=m['E']
mp=json.loads((I/E/'source-lean-map.draft.json').read_text());seal=json.loads((I/'research-wiki/paper-contributions/GaussianComplexity/source-row-independence-statement-seal.json').read_text())
raw=(REPO/seal['source']['raw']).read_bytes();assert sha(raw)==seal['source']['raw_sha256']==mp['source_sha256']
checks=[];files={}
def check(v,source=False):
    if source:b=raw;path='paper:'+v['source_id']
    else:
        path=v['path'];p=I/path
        b=(p if p.exists() else REPO/path).read_bytes()
        assert sha(b)==v['file_sha256'],path
        files[path]={'sha256':sha(b),'bytes':len(b)}
    t=b.decode();assert '\r' not in t
    bs,be=(v['raw_utf8_start'],v['raw_utf8_end']) if source else v['raw_UTF8_byte_span']
    cs,ce=(v['char_start'],v['char_end']) if source else v['decoded_char_span']
    part=b[bs:be];assert part.decode()==t[cs:ce]
    assert len(t[:cs].encode())==bs and len(t[:ce].encode())==be and sha(part)==v['span_sha256']
    start=t[:cs].count('\n')+1;end=t[:ce].count('\n')+(0 if t[:ce].endswith('\n') else 1)
    if source:
        assert start==v['lf_line_start'] and end==v['lf_line_end']
        assert cs-(t.rfind('\n',0,cs)+1)==v['lf_column0_start']
        assert 'id="'+v['source_id']+'"' in part.decode()
    else:assert [start,end]==v['LF_lines_1based'],(path,start,end)
    d=ROOT/'bounded-spans'/((v.get('source_id') or path.replace('/','__'))+'.'+str(bs)+'-'+str(be)+'.raw');d.parent.mkdir(exist_ok=True);d.write_bytes(part)
    checks.append({'origin':path,'bytes':[bs,be],'chars':[cs,ce],'LF_lines':[start,end],'span_sha256':sha(part),'portable_span':str(d.relative_to(ROOT))})
for x in mp['mappings']:
    for v in x['source']:check(v,True)
    for v in x['lean']:check(v)
for x in mp['proof_background']:
    for k in ['source','consumer']:
        for v in (x[k] if isinstance(x[k],list) else [x[k]]):check(v)
for v in seal['source']['anchors']:check(v,True)
native=json.loads((ROOT/'native-summary.json').read_text())
assert mp['actual_ASTIS_proof_parents']==native['canonical_ASTIS_parents']
pre=json.loads((I/E/'preproof-source-types-topology-local-build.original-manifest.json').read_text());archive=I/E/'preproof-source-types-topology-local-build.original-files.tar.gz'
members=[]
with tarfile.open(archive,'r:gz') as tar:
    for z in tar.getmembers():
        if not z.isfile():continue
        assert not z.name.startswith('/') and '..' not in z.name.split('/')
        b=tar.extractfile(z).read();want=pre['files'][z.name]
        assert len(b)==want['bytes'] and sha(b)==want['sha256'],z.name
        members.append({'name':z.name,'bytes':len(b),'sha256':sha(b)})
assert {x['name'] for x in members}==set(pre['files'])
result={'candidate_commit':m['candidate_commit'],'source_map_sha256':sha((I/E/'source-lean-map.draft.json').read_bytes()),'source_raw_sha256':sha(raw),'all_source_Lean_background_and_seal_spans_checked':len(checks),'checks':checks,'background_full_files_read_and_hashed_but_not_exported':files,'native_parent_comparison_equal':True,'preproof_archive':{'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),'all_members_reread':True,'member_count':len(members),'members':members},'source_fidelity_verdict':None}
(ROOT/'locator-checks.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'span_count':len(checks),'preproof_member_count':len(members),'native_parent_comparison_equal':True}))
