from pathlib import Path
import hashlib, json, sys
sys.dont_write_bytecode = True
sys.path.insert(0, 'tools')
import astis_semantic_roundtrip as rt
W = Path('.astis/huanjian-gc-fixed-spectrum-exact-means-20261110')
E = Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-exact-means-semantic-evidence')
D = Path('.astis/semantic-neutral-20261110/6f192b')
R = Path('.astis/semantic-neutral-20261110/src_a74f20')
sha = lambda b: hashlib.sha256(b).hexdigest()
dump = lambda x: (json.dumps(x, ensure_ascii=False, indent=2) + '\n').encode()
def put(p, b):
    assert not p.exists(), p
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(b)
assert sha((D / 'freeze-manifest.json').read_bytes()) == '1dca8314d80f3928185a9ae96eb70b82ae4b93f49e485834dbb51f71526eadd7'
run = json.loads((D / 'decoder-run.json').read_bytes())
text = run['reconstructed_theorem_text']
assert text in (D / 'reconstruction.md').read_text()
assert sha((D / 'decoder-run.json').read_bytes()) == 'eb1c65a2de75955cf06b5240227a47ecc1a320f23208642aee172f9e3792ff6a'
assert run['source_text_visible'] is False
assert run['decoder']['identity'] == '/root/decoder_6f192b'
for rel,h in json.loads((D/'freeze-manifest.json').read_bytes())['files'].items():
    assert sha((D/rel).read_bytes()) == h
assert run['input_artifacts'] == json.loads((D/'input.json').read_bytes())['input_artifacts']
assert sha((D / 'input.json').read_bytes()) == run['raw_input_artifact_sha256'] == 'f32a3109407773f28a081ed45a9c2b7aafac178b84ef4ac72f59860a05c839ea'
assert text == run['reconstructed_theorem_text'] and sha(text.encode()) == '804c03e9ed53e08d3bc0db8ac08cb60b0c2087a408ec9d9729f564193a02338e'
assert sha((R / 'phase1/freeze-manifest.json').read_bytes()) == '5afcacc0ea702615faed565f8b99ed770d712c9839c1bedde12f9bd7ca4591db'
for r in json.loads((R / 'phase1/freeze-manifest.json').read_bytes())['files']:
    p = Path(r['path'])
    assert sha(p.read_bytes()) == r['sha256'] and p.stat().st_size == r['bytes'], p
ap = Path('research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-exact-means.json')
old = ap.read_bytes()
a = json.loads(old)
assert a['state'] == 'draft' and a['reconstruction'] == {} and a['source_review'] == {'state': 'pending'}
packet = rt.decoder_packet(a)
assert packet['packet_sha256'] == run['packet_sha256']
a['state'] = 'blind-reconstructed'
a['reconstruction'] = {'text': text, 'text_sha256': sha(text.encode()), 'decoder': '/root/decoder_6f192b',
    'source_text_visible': False, 'lean_statement_sha256': a['lean']['statement_sha256'],
    'decoder_packet_sha256': packet['packet_sha256'], 'decoder_run_sha256': sha((D / 'decoder-run.json').read_bytes()),
    'input_artifacts': packet['input_artifacts'], 'ambient_cues_disclosed': run['ambient_exposure'], 'zero_ambient_cues_claimed': False}
for p in D.iterdir():
    if p.is_file():
        put(E / 'independent-decoder-6f192b' / p.name, p.read_bytes())
put(E / 'audit-before-independent-reconstruction.raw.json', old)
ap.write_bytes(dump(a))
full = rt.semantic_reviewer_packet(a)
assert all(v is False for v in full['anti_anchoring'].values())
put(E / 'fresh-source-reviewer-packet.json', dump(full))
seal = json.loads((W / 'statement-seal-v1.json').read_bytes())
head, body = seal['actual_private_consumer']['signature'].split(' :\n', 1)
consumer = '∀' + head.removeprefix('private theorem actual_gaussian_closed_means_bias_ratio') + ',\n' + body
white = {'schema_version': 1, 'task': 'selective-source-statement-reconstruction-comparison',
    'parent_canonical_packet_sha256': full['packet_sha256'],
    'source': {k: full['source'][k] for k in ['source_id', 'anchor', 'original_text', 'text_sha256']},
    'lean_statement': {k: full['lean'][k] for k in ['statement', 'statement_sha256']},
    'approved_definition_context': a['lean']['decoder_context'],
    'blind_reconstruction': {k: full['blind_reconstruction'][k] for k in
        ['text', 'text_sha256', 'decoder', 'decoder_packet_sha256', 'decoder_run_sha256', 'source_text_visible']},
    'private_consumer_statement': consumer}
def keys(x):
    if isinstance(x, dict):
        for k, v in x.items():
            yield k
            yield from keys(v)
    elif isinstance(x, list):
        for v in x:
            yield from keys(v)
for k in ['candidate_publication_context', 'current_lean_module', 'lean_proof', 'lesson', 'publication_context',
          'semantic_slots', 'deltas', 'verdict', 'repairs']:
    assert k not in set(keys(white)), k
raw = dump(white)
assert b' := by' not in raw
base = R / 'phase2-inputs'
assert not base.exists()
put(base / 'selective-input.json', raw)
manifest = {'scope': 'Exact whitelist statement/reconstruction only. Full canonical packet is only a hash reference until independent phase2 freezes.',
    'excluded': 'Implementation/proofs/lessons/publication context, declaration/file identities, prior semantic decisions/slots/deltas/repairs, graph and runtime evidence.',
    'phase1_freeze_sha256': sha((R / 'phase1/freeze-manifest.json').read_bytes()),
    'files': [{'path': 'selective-input.json', 'sha256': sha(raw), 'bytes': len(raw)}],
    'source_fidelity_or_independence_verdict': False}
put(base / 'manifest.json', dump(manifest))
put(E / 'strict-selective-phase2-input.json', raw)
put(E / 'strict-selective-phase2-manifest.json', dump(manifest))
print(json.dumps({'state': 'blind-reconstructed', 'full_reviewer_packet_canonical_sha256': full['packet_sha256'],
    'selective_payload_raw_sha256': sha(raw), 'selective_manifest_sha256': sha((base / 'manifest.json').read_bytes()),
    'source_review_or_actual_V_credit': False}))
