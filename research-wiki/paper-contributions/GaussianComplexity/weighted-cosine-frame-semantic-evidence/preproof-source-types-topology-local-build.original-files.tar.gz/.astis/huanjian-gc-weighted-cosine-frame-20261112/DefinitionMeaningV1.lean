import Mathlib
open MeasureTheory ProbabilityTheory
open scoped Matrix.Norms.L2Operator
set_option autoImplicit false

#print Finset.sum
#print Finset.univ
#print ProbabilityTheory.stdGaussian
#print EuclideanSpace
#print WithLp.ofLp
#print Matrix.vecMulVec
#print Matrix.kronecker
#print Matrix.PosSemidef
#print Matrix.IsHermitian
#print Set.indicator
#print MeasureTheory.Integrable
#print MeasureTheory.integral
#print Matrix.instL2OpNormedAddCommGroup
#print Matrix.instL2OpNormedSpace
#synth HMul (Matrix (Fin 2) (Fin 2) ℝ) (Matrix (Fin 2) (Fin 2) ℝ) (Matrix (Fin 2) (Fin 2) ℝ)
#synth SMul ℝ (Matrix (Fin 2) (Fin 2) ℝ)
