from pathlib import Path
from html.parser import HTMLParser
import bisect,datetime,hashlib,html,json,re
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[2]
SRC=ROOT/'.astis/huanjian-resume-20261103/2610.20492v1.html';b=SRC.read_bytes();s=b.decode()
assert hashlib.sha256(b).hexdigest()=='6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
(OUT/'original.2610.20492v1.RAW.html').write_bytes(b)
starts=[0]+[m.end() for m in re.finditer('\n',s)]
def loc(a,z):return {'char_start':a,'char_end_exclusive':z,'byte_start':len(s[:a].encode()),'byte_end_exclusive':len(s[:z].encode()),'line_start_1based':bisect.bisect_right(starts,a),'line_end_1based':bisect.bisect_right(starts,max(a,z-1)),'raw_sha256':hashlib.sha256(s[a:z].encode()).hexdigest()}
class P(HTMLParser):
 def __init__(self):super().__init__(convert_charrefs=False);self.stack=[];self.nodes=[]
 def at(self):l,c=self.getpos();return starts[l-1]+c
 def handle_starttag(self,t,attrs):
  self.stack.append({'tag':t,'attrs':dict(attrs),'a':self.at()})
  if t in {'meta','link','br','hr','img','input','source','wbr'}:self.stack.pop()
 def handle_endtag(self,t):
  for i in range(len(self.stack)-1,-1,-1):
   if self.stack[i]['tag']==t:
    n=self.stack[i];n['z']=self.at()+len(t)+3;self.nodes.append(n);self.stack=self.stack[:i];break
def txt(raw):
 ms=[]
 def f(m):ms.append(html.unescape(m[1]));return f' MATH{len(ms)-1} '
 raw=re.sub(r'<math\b[^>]*alttext="([^"]*)"[^>]*>.*?</math>',f,raw,flags=re.S)
 raw=re.sub('<[^>]+>',' ',raw);raw=re.sub(r'\s+',' ',html.unescape(raw)).strip()
 return re.sub(r'MATH(\d+)',lambda m:'$'+ms[int(m[1])]+'$',raw)
p=P();p.feed(s);c2=next(n for n in p.nodes if n['attrs'].get('id')=='A3.SS2')
extra={'S4.E11','S4.SS1.p1.1','S4.Ex12','S4.SS2.SSS0.Px2.p1.1','S4.SS2.SSS0.Px2.p1.2','S4.Thmtheorem4.p1.1','S4.Ex13','S4.Thmtheorem4.p1.2','S4.Ex14','S4.SS2.SSS0.Px2.p2.1'}
nodes=[]
for n in sorted(p.nodes,key=lambda n:n['a']):
 sid=n['attrs'].get('id')
 if(c2['a']<=n['a']<c2['z'] or sid in extra) and n['tag'] in {'p','table','h3','h6'}:
  if n['tag']=='table' and 'ltx_equation' not in n['attrs'].get('class',''):continue
  raw=s[n['a']:n['z']];nodes.append({'id':sid or f"heading-{n['a']}",'tag':n['tag'],**loc(n['a'],n['z']),'text':txt(raw)})
(OUT/'source-blocks.RAWFIRST.json').write_text(json.dumps(nodes,ensure_ascii=False,indent=2)+'\n')
(OUT/'source-readable.RAWFIRST.txt').write_text('\n\n'.join(f"{n['id']} | L{n['line_start_1based']}-{n['line_end_1based']} | chars[{n['char_start']},{n['char_end_exclusive']}) | bytes[{n['byte_start']},{n['byte_end_exclusive']})\n{n['text']}" for n in nodes)+'\n')
d={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_path':str(SRC.relative_to(ROOT)),'source_sha256':hashlib.sha256(b).hexdigest(),'c2_scope':loc(c2['a'],c2['z']),
 'raw_first':'Fresh original source before new exact Gram seal/signature/formation or any target implementation. No old R11 implementation/audit/verdict or new API/proof search.',
 'files':{n:hashlib.sha256((OUT/n).read_bytes()).hexdigest() for n in ['original.2610.20492v1.RAW.html','source-blocks.RAWFIRST.json','source-readable.RAWFIRST.txt']}}
(OUT/'SOURCE-RAWFREEZE.v1.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d,indent=2))
