# Phase 1 raw-first source cognition — d_sg_48e2c0

Status: source-only extraction, not independently reviewed and not a proof.
This packet does not authorize Lean edits, statement changes, a proof route,
VERIFIED/STAB transitions, publication, or a whole-Goal conclusion. Node counts,
coverage counts and graph shape do not establish mathematics.

## Input boundary and exposure

The sole mathematical input is the pinned original HTML
`.astis/huanjian-resume-20261103/2610.20492v1.html`, 951991 bytes,
SHA256 `6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915`.
The actual instruction reads were repository AGENTS.md,
docs/proof-digestion-protocol.md and docs/evidence-routed-memory-protocol.md.
Ancestor/owned-directory AGENTS paths were checked for existence; none existed.
The AGENTS read itself exposed its general scheduling, publication and historical
Bench handoff prose. Those are process/context exposure, not source evidence.

The task message supplied the source scopes, this role, the source digest, and
the existence/hash of a sealed statement. The sealed statement was neither
located nor opened. No Lean signature, implementation, Tests, Mathlib proof,
publication packet, lesson, old graph, old review, candidate plan, or other
private/root work was read. There is no claim of pretrained/source ignorance.

The complete HTML was byte-read, hashed and structurally parsed. A heading list
for the whole HTML was displayed, exposing section titles outside the selected
slice. Mathematical body text semantically inspected is exactly the selected
snippet list: S4.p1, S4.Thmtheorem1, S4.p2, S4.SS1, S4.SS2, S4.SS3,
A3.SS1, A3.SS2, A3.SS3, A3.SS4. These are complete DOM elements copied as
original UTF-8 bytes. The context scope includes all of §4.2 and C.1–C.4;
the principal requested scope is §4.1/Eq.(11) and the full §4.3 proof, including
the initial statistic/event and eigenvector-energy paragraph. Section 2 and
§4.4 body text were not inspected. Q_G's exact definition is consequently an
unexpanded upstream source interface in this phase, not an invented definition.

An attempted BeautifulSoup import failed before a source read in that command.
A local standard-library HTMLParser extractor then preserved the raw bytes and
used MathML `alttext` for readable text. No package was installed. Readable
text is only a derivative convenience; original-byte snippets control.

## First cognition of the author's argument

The author constructs a deterministic cosine spectrum on [1,kappa], hides only
its eigenbasis with a Haar rotation, and gives the algorithm the spectrum if
desired. A high-frequency quadratic statistic distinguishes the output of a
bounded-query algorithm from a target Gaussian sample. One branch controls
every vector of a random block Krylov space; the other branch computes the
target mean and bounds the target variance. Their conjunction creates a fixed
probability gap for an A-dependent test event. Per-input total variation
accuracy bounds this gap, and averaging over the random hard input gives the
contradiction. These are conjunctive branches of one source route, not two
alternative sufficient proofs.

The statistic is intrinsic to A through a matrix Chebyshev polynomial. Hidden
eigenbasis coordinates explain and estimate it; the normalized energy weights
are an interpretation restricted to x != 0. The event is a signed one-sided
test. Replacing it by an unsigned large-absolute-value event would drop its
target sign requirement.

## Notation, domains, denominators and probability spaces

* d is an integer, at least 2 in the hard family and eventually at least
  d0(delta) in the theorem. The coordinate index is i=1,...,d; this indexing
  must survive any later conversion. kappa >= 2. delta is fixed in (0,1).
  epsilon lies in (0,1/10]. q is a nonnegative integer query bound and may be 0.
  In the contradiction q <= (delta/256) sqrt(kappa) log d and
  2 <= kappa <= d^(1-delta).
* Eq.(11): theta_i=(i-1/2) pi/d;
  lambda_i=(kappa+1)/2+((kappa-1)/2) cos(theta_i);
  Lambda=diag(lambda_1,...,lambda_d). C.4 states 0<theta_i<pi and
  1<lambda_i<kappa. The author concludes I <= A <= kappa I by orthogonality.
* O has Haar probability law on O(d), independent of the algorithm seed R.
  A=O Lambda O^T, f_A(x)=x^T A x/2, pi_A=N(0,A^-1).
  C.4 calls the same displayed potential V_A. The spectrum and normalizer
  (2pi)^(d/2) det(Lambda)^(-1/2) are independent of O and may be public.
* K_q(g_1,...,g_(q+1)) is the span of Lambda^j g_a for
  1<=a<=q+1 and 0<=j<=q. The g_a are mutually independent N(0,I_d).
  Their construction is on an extension preserving (O,R,transcript,X).
  Neither independence from O/X nor deterministic polynomial coefficients is
  asserted. The coefficients may depend on the whole extended experiment.
* n=2q+1, D_n=diag(cos(n theta_i)), so 1<=n<d after the dimension check.
  C>0 in tau_(d,q) is an absolute constant fixed large enough for Lemma 4.4:
  tau=C[(q+1)sqrt(log d/d)+(q+1)(q+1+log d)log d/d].
  C and the resulting eventual-dimension threshold are not algorithm premises.
* T_n is the degree-n first-kind Chebyshev polynomial. Set
  H_A=(2A-(kappa+1)I)/(kappa-1). The denominator kappa-1 is positive.
  The source definition is S_A(x)=(-1)^n x^T T_n(H_A)x-2tau||x||^2,
  E_A={x:S_A(x)>0}. Euclidean norm and inner product are used.
* For x!=0, w_i(x)=|<x,Oe_i>|^2/||x||^2. The denominator is positive;
  the weights are nonnegative and sum to 1 by orthogonality/Parseval (standard
  expansion, not printed as a separate lemma). T_n(cos theta_i)=cos(n theta_i)
  gives x in E_A iff (-1)^n sum_i w_i(x)cos(n theta_i)>2tau.
  At x=0 the weights/ratio have no declared meaning; S_A(0)=0 and 0 is outside
  E_A. No zero-division fallback is inserted. Since n is odd, the signed
  preference is negative for the unsigned cosine form; retaining (-1)^n is the
  exact source notation.
* U~N(0,Lambda^-1), M=E||U||^2=tr(Lambda^-1),
  mu_n=E[U^T D_n U]=tr(D_n Lambda^-1),
  varrho=(sqrt(kappa)-1)/(sqrt(kappa)+1), beta=|mu_n|/M.
  Here sqrt(kappa)>0 and sqrt(kappa)+1>0, 0<varrho<1,
  1+varrho^(2d)>0 and 1-varrho^(2d)>0. The moment formulas give M>0.
  With n<d, the signed mean (-1)^n mu_n is positive, so beta>0.
  These domain facts are needed before forming tau/beta, beta itself,
  log(1/varrho), and the Chebyshev denominator (E Z)^2.
* Probability P_alg is the joint Haar-input/seed law, or its law-preserving
  extension. Lemma 4.4's event is a function of the jointly iid g_a and is
  simultaneous in all u in K_q. It is not a conditional-on-X concentration
  assertion. Pushforward back to (O,X) gives E_A[rho_A^Alg(E_A)].
* For fixed hard A, P_target,A is Y~pi_A. Equivalently, conditional on O,
  U=O^T Y~N(0,Lambda^-1). Norms and the cosine quadratic form transport through
  this orthogonal map. The source obtains the same constants for every A.
  This probability space is distinct from the algorithm extension.
* The final expectation E_A is over the pushforward of Haar O to random A.
  It averages two conditional probabilities. It does not require a coupling
  or independence between algorithm output X and target sample Y.
* The accuracy discrepancy consumed at the end is per-input total variation,
  with event probability difference <= epsilon. It is not a Euclidean norm,
  Wasserstein distance, or a bound on TV of two marginal mixtures. In
  particular E_A is permitted to depend on A because the guarantee is applied
  separately for each A before averaging.

## Core input-output inventory and consumer uses

The exact raw anchors and every paragraph/display disposition are in
coverage_inventory.json. Source node identities and hyperedges are in
source_graph.json. The following is the corresponding cognition before seeing
any sealed implementation interface.

1. `sg:grid11` consumes d>=2,kappa>=2 and produces theta,Lambda. Its outputs
   feed the hard rotation, D_n, cosine/polynomial coordinate adapter and all
   C.2/C.3 calculations. The family is public spectrum plus hidden eigenbasis,
   not hidden eigenvalues or a hidden normalizing constant.
2. `sg:hard-rotation` consumes grid, Haar O independent of seed and produces
   A,f_A,pi_A. `bg:C4-spectrum` supplies the admissibility conclusion consumed
   at §4.3 setup. `bg:C4-regularity` and `bg:C4-normalizer` are contextual
   admissibility support; the source Lemma 4.6 statement itself is the spectral
   bound and should not be silently enlarged to all these claims.
3. `sg:krylov` (Lemma 4.3) consumes the adaptive q-query experiment, iid seed
   independence from O and 2q+1<d. It supplies jointly iid Gaussian starts and
   a.s. O^T X in K_q on a law-preserving extension. The extra start vector is
   required because output need not lie in the span of queries/replies.
4. `sg:uniform-krylov` (Lemma 4.4) consumes those Gaussian-start laws,
   2q+1<d and tau<=1/2. It supplies one event of probability at least .99 on
   which every u in K_q obeys |u^T D_n u|<=2tau||u||^2.
   The event quantifier is outside the universal vector quantifier. Thus
   adaptive/random coefficients are allowed. The source's affine cosine
   change-of-basis paragraph explains independence of kappa.
5. `sg:test` defines the A-intrinsic S_A and strict event E_A.
   `sg:energy-geometry` uses the coordinate/Chebyshev identity for x!=0.
   Its role is substantive explanatory geometry, not a new assumption and not
   an extra sufficient route to the probability estimate.
6. `sg:algorithm-rates` consumes the theorem parameter range and query budget.
   The author states q+1<=d^((1-delta)/2)log d, n=o(d), and
   tau <= C' d^(-delta/2)(log d)^3 ->0. These bounds are eventual and uniform
   in kappa,q in the allowed range, with delta fixed. The suppressed +1 and
   logarithmic absorptions belong to a standard asymptotic bridge.
7. `sg:algorithm-apply` discharges n<d and tau<=1/2 for large d, invokes Lemmas
   4.3/4.4 and transports the uniform inequality to X without changing its
   joint input/output law. `sg:algorithm-probability` consumes the bound and
   S_A's definition: on the .99 good event S_A(X)<=0, hence
   E_A[rho_A^Alg(E_A)]<=.01. Strict positivity matters for the complement.
8. `sg:target-moments` (Lemma 4.5) supplies
   M=(d/sqrt(kappa))(1-varrho^(2d))/(1+varrho^(2d)),
   (-1)^n mu_n=(d/sqrt(kappa))(varrho^n-varrho^(2d-n))/(1+varrho^(2d)),
   Var(||U||^2),Var(U^T D_n U)<=2M<=2d/sqrt(kappa).
   `sg:target-bias` additionally requires d-n>=sqrt(kappa) and supplies
   (1-e^-4)e^(-3n/sqrt(kappa))<=beta<=e^(-2n/sqrt(kappa)).
9. `sg:bias-scale` discharges d-n>=sqrt(kappa) by n=o(d) and sqrt(kappa)=o(d).
   The author consumes the q bound to obtain beta>=b d^(-delta/4),
   b=(1-e^-4)e^-3>0, using 3n/sqrt(kappa)<=3+(3delta/128)log d.
10. `sg:target-scale` consumes the exact M formula and varrho bound, obtains
    varrho^(2d)<=e^-2<1/3, M>=d/(2sqrt(kappa))>=d^((1+delta)/2)/2,
    tau/beta<=(C'/b)d^(-delta/4)(log d)^3->0, and
    M beta^2>=b^2 sqrt(d)/2->infinity. The source's varrho<=e^(-1/sqrt(kappa))
    here is a deliberately weaker consequence of the C.3 log bound.
11. `sg:choose-d0` takes the conjunction of these uniform eventual conditions,
    n<d,tau<=1/2,d-n>=sqrt(kappa),tau<=beta/4,M beta^2>=320.
    A single d0(delta) works for all allowed kappa,q and epsilon. These are
    discharged proof conditions, never new public premises.
12. `sg:target-L2` fixes A and defines Z=S_A(Y). It consumes coordinate
    transport, signed target mean, both variance bounds, tau<=beta/4 and
    tau<=1/2. Source outputs E Z=(beta-2tau)M>=beta M/2 and Var(Z)<=8M.
    The L2 triangle inequality is for centered variables; it does not assume
    independence of ||Y||^2 and its cosine quadratic form.
13. `sg:target-probability` consumes E Z>0, finite variance and M beta^2>=320.
    Chebyshev gives pi_A(E_A)=P(Z>0)>=1-Var(Z)/(E Z)^2
    >=1-32/(M beta^2)>=.9, for every hard A. The zero boundary is included
    in the failure event Z<=0.
14. `sg:TV-average` consumes per-input TV accuracy on admissible A, the .9
    pointwise target probability and the .01 averaged output probability.
    It yields .89<=E_A[pi_A(E_A)-rho_A^Alg(E_A)]<=epsilon<=.1.
    `sg:contradiction` records the author's contradiction and theorem-bound
    conclusion. Translating that exclusion of a q-query algorithm into the
    exact Q_G interface awaits its unexpanded upstream definition/phase 2.

## Background topology actually read

C.1 is a proof of the imported Krylov result, not an implementation route.
It distinguishes original and latent coordinates, removes the function-value
oracle as redundant to (x,Ax), defines Haar states (history H, revealed E,
known OP_E, residual Haar isometry), and proves image/preimage revelation.
The preimage formula has explicit branches x^perp!=0 and x^perp=0; the latter
does not normalize a zero vector. Independent auxiliary Gaussian randomness
preserves Haar state. Gaussianizing a uniform complementary direction requires
dim E<d and an a.s. positive projected Gaussian radius. Padding by zero queries
allows exactly q queries. Histories increase E by u and Lambda u, with
dim E_i<=2i<d. Conditional Gaussian laws yield mutual independence of the g_i,
then a Krylov span induction and a final output preimage give the lemma.
The zero/nonzero branches are exhaustive cases, not alternative whole proofs.

C.2 builds B with rows d^(-1/2)(gamma_i tensor t_i)^T, r=q+1,
t_i=(1,sqrt(2)cos theta_i,...,sqrt(2)cos(q theta_i)). Fact C.5 joins the
invertible polynomial/cosine basis change, discrete cosine orthogonality,
high-frequency cancellation (1<=n±j±k<=4q+1<2d), and row norm bound.
Its outputs are range B=K_q, E B^T B=I and E B^T D_n B=0.
Fact C.6 joins truncation at L=2r+3log(1000d), a radial Gaussian bias bound,
centered summand norm and variance bounds, a named matrix Bernstein inequality,
and union/intersection probability budgets (.999,.996,.995). The chosen
absolute C absorbs the deviations and bias into tau. The final quadratic-form
comparison divides by 1-tau>0, gives tau/(1-tau)<=2tau, and is simultaneous
in all coefficients. Its .995 event is weakened to .99. It is the reason a
fixed-vector concentration argument is inadequate here.

C.3 expands the inverse spectrum by an absolutely/uniformly convergent cosine
series (Fact C.7), evaluates finite-grid alias sums for k in 2d Z versus other
k, and sums disjoint classes j=n,2ad+n,2ad-n (Fact C.8). Gaussian second/fourth
moments and independence of the diagonal target coordinates give the two
variance bounds. The sign of mu_n, positivity of M and the normalized bias
fraction are explicit. The integral expression for log(1/varrho) gives
2/sqrt(kappa)<=log(1/varrho)<3/sqrt(kappa); d-n>=sqrt(kappa) controls the
finite-grid tail by e^-4. All these are source equations, not new proofs here.

C.4 establishes interior eigenvalue bounds and orthogonal conjugation, states
smooth/strongly convex quadratic properties and a unique zero minimizer, then
uses Gaussian integration to give the normalizer. The latter two paragraphs
are recorded as contextual support with no false direct edge to the spectral
Lemma 4.6 statement.

## Standard bridges and source-scope gaps

`standard_bridges.json` records exact uses, required inputs and unexpanded
obligations. The distinction is between an author-mentioned standard input,
an implicit algebra/probability adapter, and a source interface not inspected
under the phase boundary. It does not claim these are false or formally proved.

* Polynomial functional calculus respects orthogonal conjugation; the affine
  H_A has eigenvalues cos theta_i, and T_n(H_A)=O D_n O^T. This bridge is used
  by both the first statistic definition and the algorithm/target estimates.
  Only the scalar Chebyshev identity is explicitly cited in the geometry.
* Orthogonal norm preservation and Parseval give the weight normalization and
  the quadratic-form coordinate identity. Zero must be treated separately.
* The parameter-rate display suppresses finite-dimensional absorptions,
  log-power asymptotics and the conjunction of uniform eventual thresholds.
  These are implicit standard bridges with no explicit d0 formula in source.
* Linear/Gaussian covariance transport, Gaussian second/fourth moments,
  finite L2 integrability and Gaussian integration are standard inputs used
  by the author, with no full proofs of their general forms in this slice.
* Law-preserving extensions, event measurability, integration of a conditional
  probability, expectation monotonicity and per-input-to-average TV control
  are probability bridges. For fixed A, S_A is continuous in x, so the event
  is Borel; joint measurability in A is required for the average. The author
  does not state these as standalone lemmas.
* The centered L2 triangle inequality and Chebyshev inequality are named
  external standard inputs. Their use requires finite second moments and,
  for the displayed ratio, positive E Z. The supplied moments and chosen d0
  discharge the mathematical side conditions in the author's route.
* C.2 names and displays bounded two-sided matrix Bernstein. Its general
  theorem is not proved and no exact numbered external citation is attached
  at that use site. Independence, centering, self-adjointness, deterministic
  R_* and v_* bounds, and matrix dimension r^2 are the required inputs.
* Haar conditional laws on varying complementary subspaces, existence of
  appropriate conditional distributions, and conditional-independence
  operations are used in C.1. The source provides its geometric argument;
  general measure-theoretic representation machinery is unexpanded.
* `scope:QG-definition` is an uninspected upstream interface: §2 was not read.
  The exact minimax/query-budget convention cannot be certified from this
  phase. This is a scope boundary rather than an assertion that the paper
  omits its definition. No implementation definition is substituted.
* The raw source includes comparison citations to [22] and §3/§4.4. They are
  inventoried as context/excluded dependencies; none is silently made an
  additional AND-premise of the §4.3 contradiction. No external bibliography
  text or cited paper was read.

## Coverage and route semantics

All selected substantive paragraphs and displayed equations have one NODE or
EXCLUDED(reason) disposition. Raw headings are EXCLUDED as navigation.
The inventory also records h6 theorem/lemma/fact headings as navigation whose
mathematical body is separately covered. Only pure roadmap/prior-comparison
text is excluded; the statistic, event, energy geometry, extension-law clause,
uniformity clause and final strict-event/TV steps are retained.

AND hyperedges mean every listed input is needed at that use site. No author
OR-route was found in this selected slice. Forward/backward coordinate
equivalences and zero/nonzero cases are explicitly not OR proof routes.
The graph is the author's source procedure; there is no Lean dependency
mapping, no proposed implementation topology and no statement-seal verdict.
Independent source-topology review and any later root-closure review remain
pending; this extractor does not approve its own coverage.

Phase 1 ends at the read-only hash freeze. Further statement/interface reads
require the parent-provided exact phase-2 whitelist.
