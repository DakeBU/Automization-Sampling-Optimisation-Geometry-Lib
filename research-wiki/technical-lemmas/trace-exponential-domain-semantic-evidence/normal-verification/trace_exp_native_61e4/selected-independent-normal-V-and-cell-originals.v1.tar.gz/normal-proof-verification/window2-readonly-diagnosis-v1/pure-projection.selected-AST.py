new = copy.deepcopy(old)
new['status'] = 'independently_verified'
e = new['evidence']
e['independent_verification'] = {'verifier_id': VERIFIER, 'normal_V': ident(OWN / 'normal-V-outcome.public.json'), 'current_reader': x['pins']['reader_carried'], 'actual_math_build_identity': MATH, 'source_binding': BINDING}
e['normal_V'] = {'state': 'VERIFIED', 'actual_calls': 1, 'actual_exact_append': ident(OWN / 'normal-V-exact-append.jsonl'), 'actual_normal_outcome': ident(OWN / 'normal-V-outcome.public.json'), 'verifier_id': VERIFIER, 'verified_source_carrier': a['carrier_commit']}
e['current_normal_stage'].update({'advance_state': 'VERIFIED', 'cell_status': 'independently_verified', 'theorem_VERIFIED': True, 'normal_independent_proof_VERIFIED_calls': 1, 'verifier_id': VERIFIER, 'verified_source_carrier': a['carrier_commit'], 'actual_math_build_identity': MATH})
e['reader_review'].update({'actual_browser_and_visual': 'PASS_BOUNDED_ISOLATED_READER', 'current_acceptance': x['pins']['reader_carried'], 'actual_browser_exit_code': 0, 'actual_checks': 389, 'actual_false_checks': 0, 'actual_original_PNGs': 36, 'blocking_reader_residuals': 0, 'physical_touch_or_production_acceptance': False})
new['consumer_scope']['first_realistic_consumer']['state'] = 'ACTUAL_PRIVATE_COMPILED_MATERIAL_CONSUMER; immutable301728 native/source and isolated reader accepted within one independent normal proof VERIFIED for public P; no separate public T node. Stabilization remains pending.'
new['reuse_plan']['new_shared_declarations_status'] = 'ACTUAL_IMMUTABLE301728_P_WITH_MATERIAL_PRIVATE_T; independent native/source/isolated reader accepted; normalPL1 and independent normal proofV1; integration/purification pending.'
prefix = x['pl']['truth_boundary'].split('Main/shared imports/Registry/sourceIndex/global graph/site integration', 1)[0]
assert old['truth_boundary'].startswith(prefix)
new['truth_boundary'] = prefix + 'One normal PROVED_LOCAL and one independent normal VERIFIED now exist for public P, with its private material consumer checked and no extra public T node. The verified source/evidence carrier is ' + a['carrier_commit'] + '; the actual fresh native Lean build remains immutable301728. The accepted isolated reader is separate from main/shared imports/Registry/sourceIndex/global graph/site integration, physical touch, purification and full-paper/whole-Goal completion; those remain held/open.'
new['phase_snapshot'] = 'PL1 and one independent normal proofV by ' + VERIFIER + ' at source/evidence carrier ' + a['carrier_commit'] + '. Immutable301728 native/source and the actual isolated reader are accepted; no new build or browser run. API window kept every frontier unchanged; only this cell is projected in this separately authorized second window. Main/site/global integration, original stabilization ownership and purification/full-paper remain held/open.'
changed = differences(old, new)
allowed = ['/status', '/evidence/independent_verification', '/evidence/normal_V', '/evidence/current_normal_stage', '/evidence/reader_review', '/consumer_scope/first_realistic_consumer/state', '/reuse_plan/new_shared_declarations_status', '/truth_boundary', '/phase_snapshot']
assert all((any((k == base or k.startswith(base + '/') for base in allowed)) for k in changed))
for k in ['target_statement', 'private_consumer_statement', 'statement_seal', 'source_anchor', 'source_proof_coverage', 'semantic_roundtrip', 'purification']:
    assert old[k] == new[k]
assert new['consumer_scope']['first_realistic_consumer']['public_node'] is False and new['consumer_scope']['second_realistic_consumer'] == old['consumer_scope']['second_realistic_consumer']
