"""Build closed propositions directly from the two current literal signatures."""
from pathlib import Path

workspace = Path(__file__).resolve().parent
text = 'import Mathlib\nopen MeasureTheory ProbabilityTheory\nopen scoped Matrix.Norms.L2Operator\nset_option autoImplicit false\n\n'
for name, filename in [('ProducerStatement', 'producer-signature.draft.txt'),
                       ('ConsumerStatement', 'consumer-signature.draft.txt')]:
    signature = (workspace / filename).read_text()
    assert ':= by' not in signature
    binders, body = signature.split(' :\n', 1)
    text += f'def {name} : Prop := ∀ {binders},\n{body}\n#check {name}\n\n'
path = workspace / 'StatementFormationV2.lean'
with path.open('x') as out:
    out.write(text)
print(str(path))
