from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess,sys,time,os
p=Path(__file__).parent
if (p/'chain-verifier.process-receipt.json').exists():raise SystemExit('Preserve the captured verifier run; do not overwrite')
start=datetime.now(timezone.utc).isoformat();t=time.monotonic()
with (p/'chain-verifier.stdout.raw').open('xb') as out,(p/'chain-verifier.stderr.raw').open('xb') as err:
 r=subprocess.run([sys.executable,str(p/'verify_actual_v2.py')],cwd='/Users/zhouhuanjian/ASTIS-GC',stdout=out,stderr=err,check=False)
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
rec={'role':'Independent read-only artifact-chain verifier; no Chrome/API/Git invocation','command':[sys.executable,str(p/'verify_actual_v2.py')],'cwd':'/Users/zhouhuanjian/ASTIS-GC','recording_actor_pid':os.getpid(),'started':start,'ended':datetime.now(timezone.utc).isoformat(),'elapsed_seconds':time.monotonic()-t,'exit_code':r.returncode,'script_sha256':sha(p/'verify_actual_v2.py'),'stdout':{'path':'chain-verifier.stdout.raw','bytes':(p/'chain-verifier.stdout.raw').stat().st_size,'sha256':sha(p/'chain-verifier.stdout.raw')},'stderr':{'path':'chain-verifier.stderr.raw','bytes':(p/'chain-verifier.stderr.raw').stat().st_size,'sha256':sha(p/'chain-verifier.stderr.raw')},'reason_for_recorded_invocation':'Preserve actual stdout/stderr/status requested for custody; new v2 receipt/hash/clip checks, no repeated browser process.'}
(p/'chain-verifier.process-receipt.json').write_text(json.dumps(rec,indent=2)+'\n');print(json.dumps({'exit_code':r.returncode,'receipt_sha256':sha(p/'chain-verifier.process-receipt.json'),'stdout_bytes':rec['stdout']['bytes'],'stderr_bytes':rec['stderr']['bytes']},indent=2));raise SystemExit(r.returncode)
