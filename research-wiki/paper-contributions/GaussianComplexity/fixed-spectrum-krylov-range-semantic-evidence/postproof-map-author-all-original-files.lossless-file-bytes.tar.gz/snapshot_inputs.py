from pathlib import Path
import hashlib,json,stat
ROOT=Path(__file__).resolve().parent;REPO=ROOT.parents[2]
sha=lambda b:hashlib.sha256(b).hexdigest()
out=ROOT/'input-originals';out.mkdir(exist_ok=True)
sources=[
('production','AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumKrylovRange.lean'),
('consumer','Tests/GaussianComplexityFixedSpectrumKrylovRange.lean'),
('kernel-probe','research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-krylov-range-semantic-evidence/KernelExactTypesAndAllOwnedBounded.lean'),
('kernel-log','.astis/huanjian-resume-20261103/20261110T194651267045Z-krylov-range-exact-sealed-types-all-owned-closed-kernel-and-actual-parents.log'),
('source-graph-v2','.astis/semantic-neutral-20261110/kr_sg_31f8c2_phase3_revision/source-graph.v2.json'),
('typed-overlay-v2','.astis/semantic-neutral-20261110/kr_sg_31f8c2_phase3_revision/type-source-overlay.v2.json'),
('source-pins','.astis/semantic-neutral-20261110/kr_sg_31f8c2/source-pins.json'),
('source-coverage','.astis/semantic-neutral-20261110/kr_sg_31f8c2/coverage.json'),
('raw-S4SS1','.astis/semantic-neutral-20261110/kr_sg_31f8c2/raw/S4.SS1.html'),
('raw-S4SS2','.astis/semantic-neutral-20261110/kr_sg_31f8c2/raw/S4.SS2.html'),
('raw-C2','.astis/semantic-neutral-20261110/kr_sg_31f8c2/raw/A3.SS2.html')]
log=REPO/sources[3][1]
receipt_candidates=[p for p in log.parent.glob(log.stem+'*') if 'receipt' in p.name and p.is_file()]
assert len(receipt_candidates)==1,[(p.name,p.stat().st_size) for p in receipt_candidates]
sources.append(('kernel-receipt',str(receipt_candidates[0].relative_to(REPO))))
records=[]
for label,rel in sources:
    path=REPO/rel;b=path.read_bytes();dest=out/(label+path.suffix);dest.write_bytes(b)
    records.append({'label':label,'original_path':str(path),'snapshot_path':str(dest.relative_to(ROOT)),'bytes':len(b),'raw_sha256':sha(b),'lf_count':b.count(b'\n'),'original_mode':format(stat.S_IMODE(path.stat().st_mode),'04o')})
assert next(x for x in records if x['label']=='source-graph-v2')['raw_sha256']=='9fdcb9e4965b41c5986475cc370548bcd018710dab634b899307ff1dc8132308'
assert next(x for x in records if x['label']=='typed-overlay-v2')['raw_sha256']=='70981af1f7df1034470edd46aafd63f1f8cdd109afe1792b1d4ef0bc9d4bed1d'
(ROOT/'input-manifest.json').write_text(json.dumps({'inputs':records,'log_handling':'Exact raw bytes copied; no newline normalization, trim or JSON reserialization of original logs/receipts.','scope':'Mapping-author input snapshots only; no verification/acceptance result.'},ensure_ascii=False,indent=2)+'\n')
print(json.dumps(records,ensure_ascii=False,indent=2))
