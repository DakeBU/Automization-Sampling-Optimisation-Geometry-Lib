from pathlib import Path
from html.parser import HTMLParser
import hashlib, json, shutil, datetime, re

ROOT = Path('/Users/zhouhuanjian/ASTIS-GC')
OUT = ROOT / '.astis/semantic-neutral-20261110/tau_tc_19abf4/phase1'
OUT.mkdir(parents=True, exist_ok=True)
RAW = OUT / 'raw-inputs'
RAW.mkdir(exist_ok=True)
source = ROOT / '.astis/huanjian-resume-20261103/2610.20492v1.html'
raw = source.read_bytes()
assert hashlib.sha256(raw).hexdigest() == '6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
snapshots = [
    ('source.html', source),
    ('AGENTS.md.raw', ROOT / 'AGENTS.md'),
    ('proof-digestion-protocol.md.raw', ROOT / 'docs/proof-digestion-protocol.md'),
    ('source-dependency-audit-SKILL.md.raw', ROOT / '.agents/skills/astis-source-dependency-audit/SKILL.md'),
]
for name, path in snapshots:
    (RAW / name).write_bytes(path.read_bytes())
s = raw.decode('utf-8')
line_starts = [0]
for m in re.finditer('\n', s):
    line_starts.append(m.end())
void = {'area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr'}

class Tree(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=False)
        self.stack=[]; self.elements=[]
    def source_offset(self):
        line,col = self.getpos(); return line_starts[line-1]+col
    def handle_starttag(self, tag, attrs):
        item={'tag':tag,'attrs':dict(attrs),'start':self.source_offset()}
        if tag in void:
            item['end']=self.source_offset()+len(self.get_starttag_text()); self.elements.append(item)
        else:
            self.stack.append(item)
    def handle_startendtag(self,tag,attrs):
        self.elements.append({'tag':tag,'attrs':dict(attrs),'start':self.source_offset(),'end':self.source_offset()+len(self.get_starttag_text())})
    def handle_endtag(self,tag):
        for j in range(len(self.stack)-1,-1,-1):
            if self.stack[j]['tag']==tag:
                item=self.stack[j]; del self.stack[j:]
                item['end']=s.index('>',self.source_offset())+1;self.elements.append(item);return

tree=Tree();tree.feed(s)
by_id={x['attrs']['id']:x for x in tree.elements if x['attrs'].get('id')}
scope_ids=['S2','S4.Thmtheorem1','S4.SS1','S4.SS2','S4.SS3','A3.SS2','A3.SS3','bib.bib3']
scope=[]
scope_dir=OUT/'source-regions';scope_dir.mkdir(exist_ok=True)
for ident in scope_ids:
    elem=by_id[ident];b=s[elem['start']:elem['end']].encode()
    dest=scope_dir/(ident+'.html.raw');dest.write_bytes(b)
    scope.append({'id':ident,'path':str(dest.relative_to(OUT)),'source_start_byte':len(s[:elem['start']].encode()),'source_end_byte':len(s[:elem['end']].encode()),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)})

def selected(elem):
    return any(a['start']<=elem['start'] and elem['end']<=a['end'] for a in [by_id[i] for i in scope_ids])

units_dir=OUT/'source-units';units_dir.mkdir(exist_ok=True)
inventory=[]
for elem in sorted(tree.elements,key=lambda x:(x['start'],x['end'])):
    if not selected(elem):continue
    tag=elem['tag'];attrs=elem['attrs'];cls=attrs.get('class','');ident=attrs.get('id')
    kind=None
    if tag=='p' and 'ltx_p' in cls:kind='substantive-paragraph'
    if tag=='math' and attrs.get('display')=='block':kind='display'
    if tag=='table' and 'ltx_equation' in cls:kind='display-group'
    if tag=='tbody' and ident and re.match(r'^(S[24]|A3)\.E',ident):kind='display-row'
    if tag=='cite':kind='citation-use'
    if tag=='div' and 'ltx_theorem' in cls:kind='theorem-or-lemma-or-fact'
    if not kind:continue
    if not ident:ident=f'anonymous-{elem["start"]}'
    b=s[elem['start']:elem['end']].encode()
    path=units_dir/(ident+'.'+kind+'.html.raw');path.write_bytes(b)
    context=ident.startswith(('S2.','S4.Thmtheorem1','S4.SS1.','S4.Thmtheorem2','S4.Thmtheorem3','S4.Thmtheorem6','S4.SS2.p1','S4.SS2.SSS0.Px1','S4.SS2.SSS0.Px4'))
    disposition='NODE'
    reason='required definition/standing convention or imported dependency interface' if context else 'in-scope statement, definition, reused equation, substantive proof step, or citation-use'
    if 'S4.Thmtheorem2' in ident:
        disposition='EXCLUDED';reason='comparison remark is context; no proof obligation for the bounded tau/target-statistic slice'
    if ident.startswith('S2.p2'):
        disposition='EXCLUDED';reason='conditioned determinant-component Haar convention is unused by this bounded slice'
    inventory.append({'id':ident,'kind':kind,'disposition':disposition,'reason':reason,'path':str(path.relative_to(OUT)),'source_start_byte':len(s[:elem['start']].encode()),'source_end_byte':len(s[:elem['end']].encode()),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)})
(OUT/'raw-source-inventory.json').write_text(json.dumps({'source_sha256':hashlib.sha256(raw).hexdigest(),'regions':scope,'units':inventory},indent=2)+'\n')

class Text(HTMLParser):
    def __init__(self):super().__init__();self.skip=0;self.parts=[]
    def handle_starttag(self,t,a):
        d=dict(a)
        if t=='math':self.skip+=1;self.parts.append(' $'+d.get('alttext','')+'$ ')
        elif not self.skip and t in ['p','h2','h3','h4','h5','h6','tr']:self.parts.append('\n['+d.get('id','')+'] ')
    def handle_endtag(self,t):
        if t=='math':self.skip-=1
    def handle_data(self,d):
        if not self.skip:self.parts.append(d)
for entry in scope:
    text=Text();text.feed((OUT/entry['path']).read_text());(scope_dir/(entry['id']+'.reading.txt')).write_text(''.join(text.parts))

(OUT/'freeze-input-report.json').write_text(json.dumps({'snapshots':[{'source_path':str(p.relative_to(ROOT)),'path':'raw-inputs/'+n,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for n,p in snapshots], 'regions':scope,'unit_count':len(inventory),'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2)+'\n')
print(json.dumps({'unit_count':len(inventory),'regions':scope},indent=2))
