from pathlib import Path
import json, hashlib, subprocess, sys
sys.path.insert(0, 'tools')
import astis_semantic_roundtrip as rt
import astis_publication as pub
import astis_advance as adv
sha = lambda b: hashlib.sha256(b).hexdigest()
B = Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-first-order-semantic-evidence')
ap = Path('research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-first-order.json')
a = json.loads(ap.read_bytes())
assert a['state'] == 'blind-reconstructed'
assert a['publication_binding_sha256'] == '51d5a5e9390a0d66c2d5b72d042a042eec8d3d60433043ea3909bf9320ccb31e'
assert adv.current_advances()['ASTIS-SA-20261108-GaussianComplexityFixedSpectrumFirstOrder']['state'] == 'PROVED_LOCAL'
head = subprocess.check_output(['git','rev-parse','HEAD'], text=True).strip()
assert head.startswith('9d306d837')
assert not subprocess.check_output(['git', 'diff', 'HEAD', '--name-only'], text=True).strip()
phase2 = B / 'fresh-source-reader-4e8f6a/phase2/freeze_manifest.json'
assert sha(phase2.read_bytes()) == '85a0e1542ce93bd0f65203f136fbe8879f2f9be1713f0c05861ab3885af5971c'
pub.check_advance([a['lean']['declaration']], reviewed=False)
packet = rt.semantic_reviewer_packet(a)
p = B / 'full-anti-anchored-reviewer-packet.json'
assert not p.exists(); p.write_text(json.dumps(packet, ensure_ascii=False, indent=2)+'\n')
paths = [ap, Path(a['lean']['file']), Path('Tests/GaussianComplexityFixedSpectrumFirstOrder.lean')]
paths += [Path('AutoSamplingTheory/ExampleCases/GaussianComplexity') / x for x in ['FixedSpectrumAdmissibility.lean', 'FixedSpectrumAffine.lean']]
paths += [Path(x) for x in [
 'website/content/declaration_lessons/huanjian-fixed-spectrum-first-order.json',
 'website/content/publications/huanjian-fixed-spectrum-first-order.json',
 'runs/substantive_advances.jsonl', 'runs/substantive_discoveries.jsonl']]
record = {'checked_candidate_commit': head, 'full_packet_path': str(p),
 'full_packet_raw_sha256': sha(p.read_bytes()), 'full_packet_canonical_sha256': packet['packet_sha256'],
 'publication_binding_sha256': a['publication_binding_sha256'],
 'independent_phase2_manifest_sha256': sha(phase2.read_bytes()),
 'exact_inputs': {str(q): sha(q.read_bytes()) for q in paths},
 'instruction': 'Only after separately frozen PHASE2. Actual producer has ONE canonical ASTIS parent (admissibility); actual private Test has TWO (new producer, affine provider). HEAD/audit/ledgers stay fixed throughout full review. Full module/critical ancestors, fresh independent Lean/kernel/application/fake-closure and owned static reader required. No current root/build/browser/site/remote acceptance or normal VERIFIED API is yet authorized. Root creates no source verdict.'}
(B / 'full-review-input-pins.json').write_text(json.dumps(record, indent=2)+'\n')
print(json.dumps(record))
