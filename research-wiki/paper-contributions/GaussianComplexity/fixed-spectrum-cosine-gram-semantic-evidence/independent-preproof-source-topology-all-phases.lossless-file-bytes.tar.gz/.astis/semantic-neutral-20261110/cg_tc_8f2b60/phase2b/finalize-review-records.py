from pathlib import Path
import hashlib
import json

base=Path(__file__).resolve().parent
doc=base/'independent-topology-review.md'
before=doc.read_text()
after=before.replace('expec\\-tation','expectation').replace('expec-tation','expectation')
(base/'independent-topology-review-v1.md').write_text(before)
doc.write_text(after)
(base/'review-editorial-change.json').write_text(json.dumps({'file':doc.name,'before_sha256':hashlib.sha256(before.encode()).hexdigest(),'after_sha256':hashlib.sha256(after.encode()).hexdigest(),'change':'Remove accidental hyphen/escape inside expectation; no mathematical change.','changed':before!=after},indent=2)+'\n')
graph=json.loads((base/'author-phase1/source_graph.json').read_bytes())
coverage=json.loads((base/'author-phase1/coverage.json').read_bytes())
typed=json.loads((base/'author-phase2/typed_overlay.json').read_bytes())
mechanical=json.loads((base/'mechanical-comparison.json').read_bytes())
assert mechanical['independent_raw_ID_count']==463
assert mechanical['independent_math_ID_count']==227
for key in ['coverage_duplicate_ids','coverage_missing_raw_ids','invalid_graph_anchor_refs','invalid_graph_edge_refs','invalid_coverage_node_refs','typed_ancestor_mismatches','invalid_obligation_refs']:
    assert not mechanical[key],key
assert mechanical['source_span_mismatches']==mechanical['coverage_span_mismatches']==0
assert all(mechanical['typed_signatures_match_immutable_phase2a'].values())

groups=[
 (['domain','theta','rn','frame','D'],'SOURCE_LITERAL_OR_STANDING_DOMAIN',
  'Full natural q range including zero; strict n<d; midpoint grid; constant coordinate scale1; positive modes sqrt2; actual diagonal weight. Matches immutable raw/type freezes.'),
 (['trig.sine-difference','finite.telescope','trig.integer-endpoints','trig.nonzero','algebra.scalar-cancel'],
  'UNPROVED_BACKGROUND_LEAF_OR_ELEMENTARY_ADAPTER',
  'The exact p4/Ex88-89 route uses these ingredients. Their local frequency assumptions are discharged downstream; no library/Lean proof is claimed.'),
 (['cosine.telescope','cosine.zero'],'SOURCE_PROOF_STEP',
  'p4 and every display/math/discharge region are represented. Signed nonzero integer frequency window excludes zero and alias endpoint2d.'),
 (['trig.product-to-sum','trig.zero-angle','linear.entry-algebra','algebra.sqrt-two'],
  'UNPROVED_BACKGROUND_LEAF_OR_ELEMENTARY_ADAPTER',
  'Explicit source uses in Ex90-93, Ex97-99 and Ex102; these are needed source algebra/normalization/entrywise adapters, not new caller assumptions.'),
 (['gram.constant-entries','gram.frequency-window','gram.nonconstant-entries','det.unweighted'],
  'SOURCE_PROOF_STEP_OR_BOUNDED_ROOT',
  'p5/Ex90-93 covers constant, mixed, diagonal/off-diagonal, signed differences, positive sums, symmetry and matrix equality; q0 remains valid.'),
 (['weighted.frequency-window','weighted.triple-expansion','weighted.triple-zero','det.weighted'],
  'SOURCE_PROOF_STEP_OR_BOUNDED_ROOT',
  'p7/Ex96-99 and final entrywise paragraph cover all four n+/-j+/-k frequencies in[1,2d), coefficient1/4, all zero-coordinate cases and signed real cosine weights.'),
 (['trig.cosine-square-bound','det.row-norm'],'SOURCE_BOUND_WITH_UNPROVED_ELEMENTARY_LEAF',
  'p8/Ex102 is the independent t row norm expansion and bound, including q0; neither Gram result nor random B row bound is smuggled in.'),
 (['gaussian.input','B'],'SOURCE_PRIVATE_CONSUMER_LAW_OR_LITERAL',
  'Source gamma/B setup is faithfully represented; exact typed consumer fixes actual canonical joint Gaussian, correct tensor order and inverse sqrt d. Law correspondence is internal and open.'),
 (['gaussian.second-moment','matrix.expectation-algebra'],'UNPROVED_PRIVATE_CONSUMER_INGREDIENT',
  'Actual-law coordinate moments, integrability, finite-sum expectation, tensor indexing and normalization remain required internal proof obligations; no assumed-moment binder.'),
 (['consumer.expected-unweighted','consumer.expected-weighted'],'SOURCE_PRIVATE_MEAN_CONSUMER',
  'Ex94-95 and Ex100-101 consume their respective deterministic root, actual Gaussian second moments and finite expectation algebra; no concentration/row independence premise.'),
 (['statement.C5.partition'],'COVERAGE_ONLY_PARTITION',
  'Mixed six-clause statement explicitly splits three deterministic roots, two private means and excluded range clause; no aggregate completion.')
]
node_rows=[]
for ids,kind,reason in groups:
    for ident in ids:
        node_rows.append({'node_id':ident,'independent_classification':kind,
                          'review':'SOURCE_SUPPORTED_WITH_PROOF_OPEN','basis':reason,
                          'source_anchors':next(n['anchors'] for n in graph['nodes'] if n['id']==ident)})
assert {r['node_id'] for r in node_rows}=={n['id'] for n in graph['nodes']}
assert len(node_rows)==33
(base/'independent-node-review.json').write_text(json.dumps(node_rows,ensure_ascii=False,indent=2)+'\n')

item_rows=[]
for item in coverage['items']:
    ident=item['item_id']
    if item['item_kind']=='semantic-clause':
        basis='Mixed source clause individually checked; excluded range/spectrum clauses are distinguished from five retained deterministic/private targets.'
    elif item['item_kind']=='external-citation':
        basis='Citation is historical/deferred-rotation context, outside the cosine/second-moment source route; explicit exclusion is appropriate.'
    elif ident.startswith('A3.') and any(ident=='A3.SS2.p'+str(i) or ident.startswith('A3.SS2.p'+str(i)+'.') for i in range(9,20)):
        basis='p9-p19 is explicitly outside deterministic/second-moment packet closure; source tail and conditional final conversion were independently read in raw phase1.'
    elif item['disposition']=='NODE':
        basis='Resolved core/standing/statement source content checked against immutable raw cognition; named consumer or semantic partition carries its proof region and background leaves.'
    else:
        basis='Explicit formatting, excluded range, excluded concentration/full-Lemma, hard-family/algorithm context or citation boundary; no required bounded-root proof region is silently omitted.'
    item_rows.append({'source_item_id':ident,'author_disposition':item['disposition'],
                      'independent_review':'ACCEPT_NODE_COVERAGE' if item['disposition']=='NODE' else 'ACCEPT_EXCLUSION',
                      'node_ids':item.get('node_ids',[]),'source_locator':item['source_locator'],
                      'raw_span_sha256':item['raw_span_sha256'],'basis':basis})
(base/'independent-source-item-review.json').write_text(json.dumps(item_rows,ensure_ascii=False,indent=2)+'\n')

roots=[
 {'root':'P.unweighted','critical_regions':['A3.SS2.p4','A3.Ex88','A3.Ex89','A3.Ex90','A3.Ex91','A3.Ex92','A3.Ex93','A3.SS2.p5.3'],
  'critical_cases':['nonzero signed cosine frequencies','constant constant','constant positive and transpose','positive diagonal zero-frequency','positive off-diagonal','symmetry','sqrt2 normalization','matrix entry equality','q0'],
  'review':'EXHAUSTIVE_SOURCE_ROUTE_WITH_UNPROVED_LEAVES'},
 {'root':'P.weighted','critical_regions':['A3.SS2.p4','A3.Ex88','A3.Ex89','A3.Ex96','A3.Ex97','A3.Ex98','A3.Ex99','A3.SS2.p7.3','S4.Ex12'],
  'critical_cases':['all four integer signed frequencies in[1,2d)','coefficient1/4','no alias/zero term','both zero-coordinate cases','signed cosine weights','literal D matrix-entry adapter','q0'],
  'review':'EXHAUSTIVE_SOURCE_ROUTE_WITH_UNPROVED_LEAVES'},
 {'root':'P.row-norm','critical_regions':['A3.Ex85','A3.Ex102'],
  'critical_cases':['constant scale1','sqrt2 square','cosine square bound','finite countq','1+2q<=2r','empty sumq0','t rather than B row'],
  'review':'EXHAUSTIVE_SOURCE_ROUTE_WITH_UNPROVED_LEAVES'},
 {'root':'Q.integrable-unweighted','critical_regions':['A3.SS2.p1','A3.SS2.p6.m1','A3.Ex94'],
  'critical_cases':['actual joint Gaussian law','valid identity covariance branch','coordinate product moments/integrability','finite sums','all pair indices','q0'],
  'review':'SOURCE_IMPLICIT_INTEGRABILITY_EXPLICATED_PROOF_OPEN'},
 {'root':'Q.integrable-weighted','critical_regions':['A3.SS2.p1','S4.Ex12','A3.Ex100'],
  'critical_cases':['actual joint Gaussian law','finite signed deterministic weights','coordinate product integrability','finite sums','all pair indices','q0'],
  'review':'SOURCE_IMPLICIT_INTEGRABILITY_EXPLICATED_PROOF_OPEN'},
 {'root':'Q.mean-unweighted','critical_regions':['A3.SS2.p6','A3.Ex94','A3.Ex95'],
  'critical_cases':['actual law not supplied covariance','explicit Integrable conclusion','B normalization','tensor order','pair identitydelta','unweighted frame consumer','finite integration'],
  'review':'SOURCE_CONSUMER_PROOF_OPEN'},
 {'root':'Q.mean-weighted','critical_regions':['A3.SS2.p7','A3.Ex100','A3.Ex101'],
  'critical_cases':['actual law not supplied covariance','explicit Integrable conclusion','B normalization','literal D','weighted frame consumer','finite integration'],
  'review':'SOURCE_CONSUMER_PROOF_OPEN'}
]
(base/'independent-root-proofspan-review.json').write_text(json.dumps(roots,ensure_ascii=False,indent=2)+'\n')
decision={
 'decision':'ACCEPT_BOUNDED_SOURCE_TOPOLOGY_WITH_OPEN_PROOFS',
 'material_HOLDs':[],'required_author_repairs':[],
 'source_coverage':{'raw_IDs':463,'math_IDs':227,'coverage_rows':473,'semantic_or_citation_rows':10,'missing_raw_IDs':[],'span_mismatches':0},
 'source_graph_nodes_reviewed':33,'core_AND_edges_reviewed':19,'typed_roots_reviewed':7,'typed_ancestor_set_mismatches':[],
 'exact_overlay_signature_match_to_phase2a':True,
 'actual_private_consumer_obligations':'Actual identity-Gaussian branch/law, coordinate moments, measurability/integrability, normalization, finite sum integral algebra and product index identity remain open internal obligations.',
 'context_advisory':{'location':'context_only_downstream_topology expected-unweighted/expected-weighted -> outside.C6 at p17/Ex125',
   'boundary':'Read as interpretation/provenance of original centers, not a necessary formal AND parent: p12 truncated centers aI/0 plus agreement onT suffice for Ex125 algebra.',
   'material_HOLD':False,'reason':'Explicit context-only block outside every bounded root; no core AND semantics or completion claim.'},
 'excluded_completion':['Range(B)=Krylov','full FactC5','C6 concentration','full Lemma4.4','main results','Lean implementation','sourceV','process/intake/global acceptance'],
 'initial_transport_issue':{'tool_chunk':'d59e73','outer_original_token_count':11424,'nested_original_token_count':10611,'complete_stdout_saved':'read-author-inventory.stdout.txt','recovery':'Bounded manifest/graph/typed/coverage reads; no mathematical input considered reviewed merely from truncated transport.'},
 'locator_correction':'Original manifests are author-root phase1_manifest.json/phase2_manifest.json; exact authorized root inventory located them, explicit hash checks and every-file validation completed afterward.',
 'proof_or_API_or_native_or_sourceV_execution':False,'root_process_history_received':False,
 'failures':[],'human_review_sha256':hashlib.sha256(doc.read_bytes()).hexdigest()
}
(base/'independent-topology-decision.json').write_text(json.dumps(decision,ensure_ascii=False,indent=2)+'\n')
out=json.dumps({'decision':decision['decision'],'material_HOLDs':[],'node_review_rows':len(node_rows),'source_item_review_rows':len(item_rows),'typed_root_review_rows':len(roots),'review_md_sha256':decision['human_review_sha256']},indent=2)+'\n'
(base/'finalize-review-records.stdout.txt').write_text(out);print(out,end='')
