"""Version a tiny new-reader prose correction; never rewrite frozen v1 bytes."""
from pathlib import Path
import difflib
import gzip
import hashlib
import json

ROOT = Path('/Users/zhouhuanjian/ASTIS-GC')
STAGE = ROOT / '.astis/huanjian-gc-ex72-integration-20261107/independent-reader-preparation'
OUT = ROOT / 'research-wiki/paper-contributions/GaussianComplexity/ex72-integration-20261107/independent-integration-reader-review'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def archive(path, raw):
    assert not path.exists()
    packed = gzip.compress(raw, compresslevel=9, mtime=0)
    path.write_bytes(packed)
    assert gzip.decompress(path.read_bytes()) == raw
    return {'path': str(path.relative_to(ROOT)), 'raw_sha256': sha(raw),
            'gzip_sha256': sha(packed), 'raw_bytes': len(raw), 'gzip_bytes': len(packed)}


raw_v1 = (OUT / 'preparation-report.json').read_bytes()
assert sha(raw_v1) == '37a9015f7d99889adb7d1b650b2e3b61ab7d15cf3da2587f54d52e533a10c30b'
report = json.loads(raw_v1)
rows = report['shared_paths']
row = rows[4]
old = gzip.decompress((ROOT / row['planned_after_archive']['path']).read_bytes())
old_text = b'has the explicit exponential lower bound1-exp('
new_text = b'has the explicit exponential lower bound 1-exp('
assert old.count(old_text) == 1
new = old.replace(old_text, new_text, 1)
assert json.loads(old)['execution'] == json.loads(new)['execution']
row['planned_after_archive'] = archive(STAGE / 'shared-path-5.planned-after.v2.raw.gz', new)
row['planned_after_sha256'] = sha(new)
row['planned_after_bytes'] = len(new)
raw_diff = b''
for item in rows:
    before = gzip.decompress((ROOT / item['before_archive']['path']).read_bytes()) if item['before_exists'] else b''
    after = gzip.decompress((ROOT / item['planned_after_archive']['path']).read_bytes())
    assert sha(after) == item['planned_after_sha256']
    raw_diff += b''.join(difflib.diff_bytes(difflib.unified_diff,
        before.splitlines(keepends=True), after.splitlines(keepends=True),
        fromfile=(('a/' + item['path']).encode() if item['before_exists'] else b'/dev/null'),
        tofile=('b/' + item['path']).encode()))
original = STAGE / 'reviewed-planned-shared.v2.original.diff'
assert not original.exists()
original.write_bytes(raw_diff)
diff_archive = archive(OUT / 'reviewed-planned-shared.v2.diff.gz', raw_diff)
report['raw_diff'] = diff_archive
report['proposal_version'] = 2
report['preserved_predecessor'] = {'path': str((OUT / 'preparation-report.json').relative_to(ROOT)),
                                   'sha256': sha(raw_v1),
                                   'change': 'Add a space between lower bound and its displayed value in the newly proposed boundary only. Frozen v1 diff, context whitespace and snapshots are unchanged.'}
report['raw_diff_original_path'] = str(original.relative_to(ROOT))
for filename, obj in [('preparation-report-v2.json', report),
                      ('raw-artifact-manifest-v2.json', {'rule': 'Use exact bytes; do not normalize frozen v1 or v2 raw diff context whitespace.',
                        'preserved_predecessor': report['preserved_predecessor'],
                        'diff': {'original_path': str(original.relative_to(ROOT)), **diff_archive}, 'shared_paths': rows})]:
    path = OUT / filename
    assert not path.exists()
    path.write_bytes((json.dumps(obj, ensure_ascii=False, indent=2) + '\n').encode())
archive(OUT / 'executed-prepare-integration-plan.py.gz', (STAGE / 'prepare_integration_plan.py').read_bytes())
archive(OUT / 'executed-refine-proposal-spacing-v2.py.gz', Path(__file__).read_bytes())
print(json.dumps({'report': 'preparation-report-v2.json',
                  'report_sha256': sha((OUT / 'preparation-report-v2.json').read_bytes()),
                  'raw_diff_sha256': sha(raw_diff),
                  'changed_since_v1': 'One inserted prose space; all six other planned files are byte-identical.'}, indent=2))
