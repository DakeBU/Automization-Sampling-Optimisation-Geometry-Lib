from pathlib import Path
import json, hashlib, shutil, re, sys, subprocess, datetime
from read_source import ROOT, SOURCE, B, S, element, plain, locator

BASE=ROOT/'.astis/semantic-neutral-20261112/ri_sg_78c2'
OUT=BASE/'raw-freeze-v1'
assert not OUT.exists(), 'Do not overwrite a frozen interpretation.'
OUT.mkdir()
(OUT/'inputs').mkdir(); (OUT/'source-fragments').mkdir()
def dump(name,obj):
    (OUT/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf-8')
def write(name,text): (OUT/name).write_text(text,encoding='utf-8')
def sha(b):return hashlib.sha256(b).hexdigest()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
assert head=='2c57883183937fdef1578a2b33e4ea892af2c694'

protocols=['AGENTS.md','CONTRIBUTING.md','.agents/prompts/collaborator-contribution.md',
 'docs/contributor-codex-contract.md','docs/theorem-publication-protocol.md',
 'docs/proof-digestion-protocol.md','docs/evidence-routed-memory-protocol.md',
 '.agents/skills/astis-substantive-advance/SKILL.md',
 '.agents/skills/astis-semantic-roundtrip/SKILL.md','.agents/prompts/samplewiki-route.md']
inputs=[]
for p in protocols:
    raw=(ROOT/p).read_bytes(); dest='inputs/'+p.replace('/','__')
    (OUT/dest).write_bytes(raw)
    inputs.append({'path':p,'snapshot':dest,'bytes':len(raw),'sha256':sha(raw),'role':'process protocol; no theorem/API evidence'})
(OUT/'inputs/2610.20492v1.html').write_bytes(B)
inputs.append({'path':str(SOURCE.relative_to(ROOT)),'snapshot':'inputs/2610.20492v1.html',
 'bytes':len(B),'unicode_characters':len(S),'lf_count':S.count('\n'),'sha256':sha(B),
 'role':'pinned source; only listed bounded regions interpreted'})
for name in ['read_source.py','build_raw_freeze.py']:
    shutil.copyfile(BASE/'working'/name,OUT/'inputs'/name)

units={}; inv=[]; locs={}
def unit(ident):
    if ident not in units:
        a,z=element(ident); units[ident]={'locator':locator(a,z),'text':plain(a,z),'atom_ids':[]}
        (OUT/'source-fragments'/f'{ident}.raw.html').write_bytes(S[a:z].encode())
    return units[ident]
def add(id,anchor,status,kind,meaning,reason=None,semantic_slice=None):
    u=unit(anchor)
    obj={'id':id,'disposition':status,'source_kind':kind,'source_element_id':anchor,
         'locator':u['locator'],'meaning':meaning,'evidence_class':'explicit source wording'}
    if reason:obj['reason']=reason
    if semantic_slice:obj['semantic_slice']=semantic_slice
    inv.append(obj);u['atom_ids'].append(id);locs[id]=u['locator']
def n(id,anchor,kind,meaning,sl=None):add(id,anchor,'NODE',kind,meaning,semantic_slice=sl)
def x(id,anchor,kind,meaning,reason,sl=None):add(id,anchor,'EXCLUDED',kind,meaning,reason,sl)

# Section 4 definition context: independently separate the needed half-grid.
x('s4.construction-provenance','S4.SS1.p1.1','external citation','Construction provenance [22, Section 9.2] and spectral interval extension.','No external theorem is needed to interpret the row independence target.','First sentence')
x('s4.spectral-parameters','S4.SS1.p1.1','standing context','d >= 2 and kappa >= 2 for the hard family.','kappa governs the spectral family, not the selected row or truncated-matrix maps. The retained natural standing inequality already implies d >= 2.','Second sentence')
n('theta.half-grid','S4.E11','source definition','theta_i = (i - 1/2) pi / d, 1 <= i <= d.','theta clause only')
x('s4.eigenvalues','S4.E11','source definition','lambda_i = (kappa+1)/2 + (kappa-1) cos(theta_i)/2.','No eigenvalue or spectral parameter is consumed by the selected independence assertions.','lambda clause only')
x('s4.diagonal-spectrum','S4.E11','source definition','Lambda = diag(lambda_1,...,lambda_d).','Krylov/spectral result is context only.','Lambda clause only')
x('s4.rotation-and-target','S4.SS1.p1.2','source definitions','Haar O independent of private randomness, A = O Lambda O^T, f_A and pi_A.','Original rotated/extended ambient experiment and algorithm transfer are expressly outside this canonical-column packet.')
x('s4.spectrum-information','S4.SS1.p2.1','substantive context','Deterministic spectrum, known normalizer, unknown eigenbasis.','Algorithm information model is not used.')
x('s4.remark42','S4.Thmtheorem2','remark and reused display','Comparison with kappa=2 and affine reply conversion.','Neither spectral transfer nor lower-bound testing is in the selected delta.')
# This paragraph is not given an id by the source; retain its exact raw interval.
a,z=element('S4.SS1'); ra,rz=element('S4.Thmtheorem2')
tail=S[rz:z]
if 'The proof compares' in tail:
    start=rz+tail.index('The proof compares'); end=z
    id='s4.testing-overview'
    inv.append({'id':id,'disposition':'EXCLUDED','source_kind':'unnamed substantive paragraph',
      'source_element_id':'S4.SS1 (unidentified tail after Remark 4.2)',
      'locator':locator(start,end),'meaning':'Cosine test, algorithm/target separation, and sqrt(kappa) lower-bound explanation.',
      'reason':'No main lower bound, testing or complexity claim is included.','evidence_class':'explicit source wording'})
    locs[id]=locator(start,end)

n('experiment.carriers','S4.SS2.SSS0.Px1.p2.1','source definition context','g_a in R^d, a=1,...,q+1; diagonal Lambda appears only as Krylov context.')
x('experiment.krylov-definition','S4.Ex10','source definition','K_q = span{Lambda^j g_a : 1 <= a <= q+1, 0 <= j <= q}.','Records the same source experiment context; neither span equality nor Krylov inclusion is a selected conclusion.')
x('lemma44.absolute-C','S4.Thmtheorem4.p1.1','statement quantifier','Existence of an absolute C>0.','C belongs to the omitted uniform-bound conclusion and tau, not row independence.','First sentence')
n('experiment.natural-standing','S4.Thmtheorem4.p1.1','standing assumption','q is a nonnegative integer/query count and 2q+1 < d; d is the finite dimension.','q and inequality clause; natural-number reading is interpretation context')
n('experiment.independent-columns','S4.Thmtheorem4.p1.1','source experiment','g_1,...,g_{q+1} are independent N(0,I_d) vectors.','independent column clause')
x('lemma44.K-alias','S4.Thmtheorem4.p1.1','source notation','K_q = K_q(g_1,...,g_{q+1}).','No Krylov theorem is selected.','K_q alias clause')
x('lemma44.tau','S4.Ex13','source definition','tau_dq = C[(q+1)sqrt(log(d)/d) + (q+1)(q+1+log d)log d/d].','No deviation scale, constant choice or concentration claim is selected.')
x('lemma44.event-premise','S4.Thmtheorem4.p1.2','conditional theorem premise','If tau_dq <= 1/2, probability at least 0.99.','This is conditional on the uniform-bound route and is not needed for independence.')
x('lemma44.uniform-conclusion','S4.Ex14','theorem conclusion','|u^T D_n u| <= 2 tau_dq ||u||^2 for every u in K_q.','Main uniform quadratic conclusion is outside the selected packet.')

n('c2.r','A3.SS2.p1.1','source definition','r=q+1.','r clause')
x('c2.n','A3.SS2.p1.1','source definition','n=2q+1.','Frequency is not used by Yi or row independence.','n clause')
n('c2.row-range','A3.SS2.p1.1','typing context','1 <= i <= d.','row index clause')
n('c2.literal-t','A3.Ex85','source definition','t_i = (1,sqrt(2)cos(theta_i),...,sqrt(2)cos(q theta_i))^T.','t_i clause')
n('c2.physical-gamma','A3.Ex85','source definition','gamma_i = ((g_1)_i,...,(g_r)_i)^T, the physical row of the same column sample.','gamma_i clause')
n('c2.row-joint-independence','A3.SS2.p1.2','unnamed source independence claim','The full finite family gamma_1,...,gamma_d is jointly independent.','First sentence, independence assertion')
n('c2.row-marginal-context','A3.SS2.p1.2','unnamed source law claim','Each gamma_i has law N(0,I_r).','First sentence, marginal assertion; context only, no dependency edge to joint independence')
n('c2.B-definition-context','A3.SS2.p1.2','source definition','B in R^{d x r^2} has i-th row d^{-1/2}(gamma_i tensor t_i)^T.','Second sentence; context, not an asserted downstream theorem')
x('c2.strategy-norm','A3.SS2.p2.1','substantive proof strategy','u=Bc; control ||u||^2 through B^T B.','Krylov/norm route is outside independence.')
x('c2.strategy-weighted','A3.SS2.p2.1','substantive proof strategy','Control u^T D_n u through B^T D_n B.','Weighted statistic is outside independence.')
x('c2.strategy-moments-concentration','A3.SS2.p2.1','substantive proof strategy','Span and matrix expectations followed by concentration imply the uniform bound.','No moments, concentration or uniform-bound claim is selected.')
for suffix,meaning in [('range','range(B)=K_q'),('gram-mean','E[B^T B]=I_{r^2}'),('weighted-mean','E[B^T D_n B]=0')]:
 x('c5.'+suffix,'A3.Ex86','fact conclusion',meaning,'Fact C.5 is retained only as definition/notation context; this conclusion is not needed for independence.',suffix+' clause')
for suffix,meaning in [('t-norm','||t_i||^2 <= 2r'),('t-gram','sum_i t_i t_i^T=d I_r'),('weighted-t-gram','sum_i cos(n theta_i)t_i t_i^T=0')]:
 x('c5.'+suffix,'A3.Ex87','fact conclusion',meaning,'No deterministic estimate or cosine-sum identity is used by the selected independence claim.',suffix+' clause')
x('c5.range-proof','A3.SS2.p3.1','substantive proof paragraph','Chebyshev polynomial change of basis is triangular invertible; normalizations preserve range.','No range theorem or eigenvalue polynomial bridge is selected.')
x('c5.gram-proof-heading','A3.SS2.p4.1','proof subgoal','E[B^T B]=I_{r^2}.','Means are excluded.','Boxed subgoal')
n('c5.theta-recall-context','A3.SS2.p4.m2','reused definition','Recall theta_i=(i-1/2)pi/d. Definition context only.')
x('c5.cosine-frequency-range','A3.SS2.p4.1','proof premise','Integer k with 0<|k|<2d.','Frequency constraints are used only for the omitted cosine identity.','Last sentence')
for ident,meaning in [('A3.Ex88','Sine-difference telescoping of the cosine sum'),('A3.Ex89','Endpoint sine difference is zero'),('A3.SS2.p4.2','Nonzero sine factor implies sum_i cos(k theta_i)=0')]:
 x('c5.'+ident,ident,'reused display or substantive proof step',meaning,'Cosine identity proof is outside the selected independence delta.')
n('c5.t-coordinate-context','A3.SS2.p5.1','typing context','Coordinates of t_i are indexed by 0,...,q.','First sentence only')
for ident,meaning in [('A3.Ex90','Constant-coordinate and mixed cosine sums'),('A3.SS2.p5.2','Product-to-sum step for j,k>=1'),('A3.Ex91','Rewrite t coordinate product as 2cos cos'),('A3.Ex92','Split into difference/sum frequencies'),('A3.Ex93','Diagonal/off-diagonal d/0 result'),('A3.SS2.p5.3','Frequency checks, symmetry and sum_i t_i t_i^T=d I_r')]:
 x('c5.'+ident,ident,'reused display or substantive proof step',meaning,'Deterministic orthogonality and its proof are excluded.')
x('c5.gaussian-second-moment','A3.SS2.p6.1','unnamed estimate','E[gamma_i gamma_i^T]=I_r and application of B row definition.','Second moments are excluded; they do not establish joint independence.')
for ident,meaning in [('A3.Ex94','Expected Gram sum via Gaussian second moments'),('A3.Ex95','Tensor factorization yields I_{r^2}'),('A3.SS2.p7.1','Weighted expectation subgoal and n=2q+1'),('A3.Ex96','Nonzero frequencies bounded by 4q+1<2d'),('A3.SS2.p7.2','Invoke preceding cosine sum'),('A3.Ex97','Triple cosine sum'),('A3.Ex98','Four product-to-sum frequencies'),('A3.Ex99','Triple cosine sum is zero'),('A3.SS2.p7.3','Weighted t Gram zero and consequent expectation step'),('A3.Ex100','Weighted expected B Gram sum'),('A3.Ex101','Tensor factorization gives zero'),('A3.Ex102','||t_i||^2=1+2sum cos^2 <=1+2q<=2r')]:
 x('c5.'+ident,ident,'reused display or substantive proof step',meaning,'Moment, weighted cosine or norm-estimate route is excluded.')
x('c6.strategy','A3.SS2.p9.1','substantive proof strategy','Simultaneous deviations control every coefficient vector.','Concentration route is excluded.')
x('c6.absolute-C-and-probability','A3.Thmtheorem6.p1.1','fact premise/conclusion','Sufficient absolute C gives probability at least 0.995.','No constant selection or concentration probability is selected.')
x('c6.concentration','A3.Ex103','fact conclusion','Both operator norm deviations are <= tau_dq.','Fact C.6 is not claimed by this packet.')
n('cutoff.literal-L','A3.SS2.p10.m1','source definition','L=2r+3 log(1000d).')
n('cutoff.literal-R','A3.SS2.p10.m2','source definition','R_i=||gamma_i||^2.')
x('cutoff.exponential-moment','A3.SS2.p10.m3','unnamed estimate','E exp(R_i/3)=3^{r/2}.','Exponential moments and tail arguments are unnecessary for joint independence.')
x('cutoff.markov-invocation','A3.SS2.p10.1','substantive proof step','Markov inequality for x>=0.','A fixed Borel cutoff can be defined without its tail probability proof.','Final clause')
x('cutoff.tail','A3.Ex104','unnamed estimate','P(R_i>2r+3x) <= exp((r/2)log3-2r/3-x) <= exp(-x).','No tail bound is selected.')
x('cutoff.log-constant','A3.SS2.p10.2','unnamed constant estimate','(log3)/2 < 2/3 and transition to common truncation event.','Tail constant and union-bound argument are excluded.')
x('cutoff.common-event','A3.Ex105','source event definition','T={R_i <= L for every i}.','Yi uses each local cutoff. It is not defined by conditioning on T or multiplying every Yi by one common event.')
x('cutoff.common-event-probability','A3.SS2.p10.3','unnamed estimate','P(T)>=0.999.','No common-event probability is needed or claimed.')
x('bias.shifted-tail','A3.SS2.p11.1','unnamed estimate','P(R_i>L+s)<=exp(-s/3)/(1000d).','Bias/tail route is excluded.')
x('bias.integrated-tail','A3.Ex106','reused display/unnamed estimate','E[R_i 1_{R_i>L}] <=(L+3)/(1000d), by layer cake.','Truncation bias is excluded.')
n('Yi.joint-independence-source-claim','A3.SS2.p12.1','unnamed source independence claim','The truncated matrices defined immediately next are independent.')
n('Yi.actual-literal-definition','A3.Ex107','source definition and direct consumer use','Y_i=(1/d)(gamma_i gamma_i^T tensor t_i t_i^T) 1_{R_i<=L}.')
x('bias.radial-symmetry','A3.SS2.p12.2','substantive proof invocation','By radial symmetry.','No mean or radial moment is selected.')
x('bias.radial-mean','A3.Ex108','reused display/source scalar definition','Truncated Gaussian outer-product mean = a I_r; a=(1/r)E[R_i 1_{R_i<=L}].','Radial symmetry and truncation means are outside independence.')
x('bias.same-a','A3.SS2.p12.3','unnamed law/moment consequences','a same for every i; E R_i=r; 0<=a<=1.','No moment or scalar-bias equality/bound is selected; common row laws do not imply joint independence.')
x('bias.loss-bound','A3.Ex109','unnamed estimate','1-a=(1/r)E[R_i1_{R_i>L}] <=(L+3)/(1000rd).','Bias bound excluded.')
x('bias.Yi-mean','A3.SS2.p12.4','unnamed mean/citation use','E Yi=(a/d)(I_r tensor t_i t_i^T); invokes Fact C.5.','Means and the C.5 consumer here are excluded; no false C.5 -> Yi-independence edge is permitted.')
x('bias.summed-means','A3.Ex110','reused display','sum E Yi=a I_{r^2}; weighted sum E Yi=0.','Means excluded.')
x('bias.weighted-mean-conclusion','A3.SS2.p12.5','substantive proof conclusion','Truncated weighted sum has zero expectation.','No mean, centering or weighted-statistic claim selected.')

# Coverage of the chosen continuous Appendix window by every substantive p/display.
wa,wz=element('A3.SS2');wz=element('A3.SS2.p12')[1]
coverage=[]
for m in re.finditer(r'<(p|table)\b[^>]*\bid="([^"]+)"[^>]*>',S[wa:wz]):
    ident=m.group(2);aa,zz=element(ident); txt=plain(aa,zz)
    ids=[i['id'] for i in inv if i['source_element_id']==ident]
    if ident=='A3.SS2.p4.1':ids += ['c5.theta-recall-context']
    if ident=='A3.SS2.p10.1':ids += ['cutoff.literal-L','cutoff.literal-R','cutoff.exponential-moment']
    if ident=='A3.SS2.p8.1':ids=['c5.A3.Ex102'];note='Pure connective Finally; mathematical content is in adjacent Ex102.'
    elif txt=='∎':ids=[];note='Proof-end punctuation only; no mathematical claim.'
    elif ident in ['A3.Thmtheorem5.p1.1','A3.Thmtheorem5.p1.2']:
        ids=['c5.range','c5.gram-mean','c5.weighted-mean'] if ident.endswith('.1') else ['c5.t-norm','c5.t-gram','c5.weighted-t-gram'];note='Pure statement connective; claims atomized in immediately adjacent display.'
    elif ident=='A3.SS2.p5.1':note='Second clause is a connective to Ex90; first sentence has its own context node.'
    elif not ids:
        # Multi-line display container: each source tbody is a separately inventoried row.
        kids=[(i['id'],element(i['source_element_id'])) for i in inv if i['source_element_id'].startswith('A3.Ex')]
        ids=[id for id,(ia,iz) in kids if aa<=ia and iz<=zz]
        note='Display container covered by its atomic display rows.'
    else:note='All substantive content represented by listed atoms; connective prose carries no additional claim.'
    assert ids or txt=='∎',ident
    coverage.append({'element_id':ident,'locator':locator(aa,zz),'atom_ids':list(dict.fromkeys(ids)),'coverage_note':note})

dump('inventory.json',{'status':'RAW_PRELIMINARY_UNACCEPTED','scope':'Named discontiguous S4 definition/experiment context plus continuous A3.SS2 start through p12 end; p13 onward is not read or inventoried.','items':inv,'continuous_appendix_window_coverage':coverage,
 'excluded_outside_window_topics':[{'topic':t,'reason':r,'source_locator':None,'claim':'Outside bounded raw reading; not a claim of exhaustive coverage of the later proof.'} for t,r in [
 ('positive semidefiniteness','Algebraic matrix-order property is not used to establish independence.'),('centered variance and higher moments','No variance, fourth moment or centering theorem is selected.'),('matrix Bernstein/concentration','A later consumer of independence remains unproved and outside this window.'),('main lower bounds or original ambient transfer','No algorithm-output/coupling/extended-ambient statement is selected.')]]})
dump('locators.json',{'convention':'Offsets are zero-based half-open UTF-8 byte and Unicode-codepoint intervals in exact original bytes. LF lines are one-based and inclusive; hashes cover raw unnormalized fragments. Shared element locators have explicit semantic_slice clauses in inventory.','source_sha256':sha(B),'locators':locs,'source_units':units})

gaps=[
 {'id':'SOURCE_GAP.gaussian-coordinate-product','consumer':'c2.row-joint-independence','meaning':'Relate the source standard d-Gaussian law to its scalar-coordinate product law, retaining within-column joint coordinate independence.','origin':'Source-supported inference needed for the omitted argument; not stated/proved in the bounded source.','status':'UNPROVED_SOURCE_GAP'},
 {'id':'SOURCE_GAP.product-regrouping','consumer':'c2.row-joint-independence','meaning':'Starting from the canonical product of r independent standard d-Gaussian columns, regroup the finite scalar coordinate array by physical row i and identify the joint row law, including measurable coordinate/reindexing maps.','origin':'Source-supported inference; no implementation or compiled parent inspected.','status':'UNPROVED_SOURCE_GAP'},
 {'id':'SOURCE_GAP.row-sigma-fields','consumer':'c2.row-joint-independence','meaning':'Translate the regrouped product-law conclusion into full finite joint independence of the actual vector-valued row maps (equivalently independent generated sigma-fields), rather than only pairwise or scalar assertions.','origin':'Omitted source bridge, separated for audit; may be absorbed by a future product-law theorem without changing the source claim.','status':'UNPROVED_SOURCE_GAP'},
 {'id':'SOURCE_GAP.Yi-measurable-row-map','consumer':'Yi.joint-independence-source-claim','meaning':'For each fixed i verify that F_i(x)=(1/d)(xx^T tensor t_i t_i^T)1_{||x||^2<=L} is Borel measurable into the finite real matrix space, including the closed cutoff at equality and the exact scalar/tensor normalization.','origin':'Source-supported inference omitted at the definition; not an extra hypothesis.','status':'UNPROVED_SOURCE_GAP'},
 {'id':'SOURCE_GAP.independent-measurable-images','consumer':'Yi.joint-independence-source-claim','meaning':'Apply preservation of full finite independence under the separate maps F_i to gamma_i, then identify these images with the actual Ex107 matrices. The maps may depend on i.','origin':'Source-supported inference connecting the source row claim to the actual consumer; no new theorem proved.','status':'UNPROVED_SOURCE_GAP'}]
dump('omitted-bridge-notes.json',{'status':'RAW_PREPARATION_ONLY','ports':gaps,'no_extra_hypotheses':True,'no_compiled_parent_claims':True})

# A dependency draft records only direct uses, never acceptance or Lean topology.
edges=[
 ('theta.half-grid','c2.literal-t','A3.Ex85','definition substitution'),
 ('c2.r','c2.physical-gamma','A3.Ex85','row carrier size'),
 ('experiment.independent-columns','SOURCE_GAP.gaussian-coordinate-product','A3.SS2.p1.2','inferred omitted prerequisite'),
 ('experiment.independent-columns','SOURCE_GAP.product-regrouping','A3.SS2.p1.2','canonical column product experiment'),
 ('SOURCE_GAP.gaussian-coordinate-product','SOURCE_GAP.product-regrouping','A3.SS2.p1.2','inferred omitted regrouping input'),
 ('c2.physical-gamma','SOURCE_GAP.product-regrouping','A3.SS2.p1.2','identification with the physical row maps'),
 ('SOURCE_GAP.product-regrouping','SOURCE_GAP.row-sigma-fields','A3.SS2.p1.2','inferred omitted independence interpretation'),
 ('SOURCE_GAP.row-sigma-fields','c2.row-joint-independence','A3.SS2.p1.2','full finite row independence'),
 ('c2.physical-gamma','c2.B-definition-context','A3.SS2.p1.2','literal row formula'),
 ('c2.literal-t','c2.B-definition-context','A3.SS2.p1.2','literal row formula'),
 ('c2.physical-gamma','cutoff.literal-R','A3.SS2.p10.m2','radius definition'),
 ('c2.r','cutoff.literal-L','A3.SS2.p10.m1','cutoff definition'),
 ('c2.literal-t','Yi.actual-literal-definition','A3.Ex107','deterministic tensor factor'),
 ('c2.physical-gamma','Yi.actual-literal-definition','A3.Ex107','physical row factor'),
 ('cutoff.literal-R','Yi.actual-literal-definition','A3.Ex107','row-local cutoff'),
 ('cutoff.literal-L','Yi.actual-literal-definition','A3.Ex107','fixed threshold'),
 ('Yi.actual-literal-definition','SOURCE_GAP.Yi-measurable-row-map','A3.SS2.p12.1 / A3.Ex107','inferred measurable row-map obligation'),
 ('c2.row-joint-independence','SOURCE_GAP.independent-measurable-images','A3.SS2.p12.1 / A3.Ex107','true downstream actual-Yi use; inferred omitted bridge'),
 ('SOURCE_GAP.Yi-measurable-row-map','SOURCE_GAP.independent-measurable-images','A3.SS2.p12.1 / A3.Ex107','map measurability must be discharged'),
 ('SOURCE_GAP.independent-measurable-images','Yi.joint-independence-source-claim','A3.SS2.p12.1 / A3.Ex107','identify actual source Yi images')]
dump('preliminary-direct-use-graph.json',{'status':'RAW_PRELIMINARY_DRAFT_NOT_TOPOLOGY_ACCEPTED','chronology':'Created only as source-first preparation before any new typed seal/type exposure. Parent sequence refinement explicitly defers final graph review and acceptance until the exact Statement Seal and binder/definition audit.','semantics':'Source/definition/inferred omitted-bridge edges only; no Lean/compiled/proof-status edges.','edges':[{'from':a,'to':b,'consumer_use_site':c,'meaning':d,'consumer_locator':units[c]['locator'] if c in units else {'anchors':[{'element_id':p,'locator':units[p]['locator']} for p in c.split(' / ')]}} for a,b,c,d in edges],
 'forbidden_edges':['c2.row-marginal-context -> c2.row-joint-independence','Fact C.5 mean/orthogonality -> Yi independence','tail probability or common event -> Yi independence'],
 'route_logic':'One inferred sufficient product/regrouping route is sketched with explicit unproved ports. It is not a claim that the source supplies every bridge or that every gap must be a separate formal lemma. No alternative routes are conjoined.'})

write('raw-interpretation.md',r'''# Raw source interpretation, version 1

This is a frozen source-only preliminary reading. It is neither a Statement Seal nor an accepted topology, semantic verdict, compiled proof, publication, or permission to formalize. It precedes every new typed signature and implementation exposure. Final topology review awaits the exact Statement Seal and binder/definition audit.

The source is *On Complexity of Gaussian Sampling*, arXiv:2610.20492v1, pinned by the complete HTML input hash in the manifest. The chosen source assertion is the unnamed C.2 p1 claim that the vectors gamma_1,...,gamma_d are independent. The actual downstream consumer is the unnamed independence assertion immediately preceding Ex107, attached to those very truncated matrices.

The intended canonical specialization uses natural d,q with 2q+1<d and r=q+1. A sample is a tuple of r vectors in R^d, endowed with the product of r standard d-Gaussian laws; g_a is its a-th column projection. This canonical realization is the task's chosen boundary for the source's independent-column experiment. The source is not being asserted to restrict all possible realizations to this one space, and no arbitrary ambient/coupling transfer is claimed. No library/API for this realization has been inspected. The physical vector gamma_i=((g_a)_i)_(a=1,...,r) always uses the same column sample.

“Independent” means full finite joint independence of the vector-valued random maps, equivalently factorization for every family of Borel row events. It is stronger than pairwise independence. The source simultaneously gives each gamma_i the standard r-Gaussian marginal law. Those marginals are recorded as context; they do not establish the joint assertion and have no edge into it.

For i=1,...,d take theta_i=(i-1/2)pi/d and t_i=(1,sqrt(2)cos(theta_i),...,sqrt(2)cos(q theta_i))^T, with t coordinates indexed by j=0,...,q. The leading coordinate is exactly 1. The tensor order is gamma first and t second, as in the source B row. Set R_i=||gamma_i||^2 and L=2r+3 log(1000d). The actual matrix is

    Y_i = (1/d)(gamma_i gamma_i^T tensor t_i t_i^T) 1_{R_i <= L}.

It takes values in r^2 by r^2 real matrices. With row/column indices (a,j),(b,k), its entry is (1/d)(gamma_i)_a(gamma_i)_b(t_i)_j(t_i)_k times that same row-local indicator. Equality at L is included. This is a deterministic Borel-map candidate F_i of gamma_i, with a fixed i-dependent t_i. The source calls the resulting Y_i independent. It does not call the Y_i identically distributed, and no iid claim is inferred because the deterministic t_i varies with i. Neither conditioning on the simultaneous event T nor replacing each local cutoff by a common-event indicator is the source definition.

The q=0 case is retained. Then r=1, d>=2, t_i=(1), and Y_i is the 1 by 1 matrix (1/d)(g_1)_i^2 1_{(g_1)_i^2 <= 2+3 log(1000d)}. No positive-q assumption is introduced. The inequality also gives d>=2, so the displayed division and logarithm input have their natural source domain. No tau<=1/2, concentration event, C, kappa, eigenvalue parameter, moment, norm bound on t_i, radial mean, bias estimate, or variance assumption is needed for the selected independence assertions.

The source omits the argument from independent Gaussian columns to joint physical rows, and then from rows to separate truncated row maps. The omitted-bridge file lists product-law, finite-coordinate regrouping, sigma-field interpretation, measurable-map and independence-preservation ports. These are source-supported mathematical inferences to be discharged after a future seal; they are not proved here, not claimed as compiled parents, and not added as hypotheses.

The bounded inventory covers every substantive paragraph/display in Appendix C.2 from its first paragraph through the end of p12, plus the listed Section 4 definition and experiment context. It explicitly excludes the C.5 moment/cosine/range/norm assertions, the C.6 concentration statement, the tail proof and common-event probability, and the p11/p12 bias/mean route. Later PSD, centered variance, concentration proofs, original extended-ambient transfer, and main lower bounds lie outside this raw window and outside the selected delta. This is not whole-paper or whole-Lemma-4.4 coverage.

Definition/substitution and direct source consumer uses appear only in a preliminary draft graph. No source topology is accepted by this extractor. Its contents must remain distinguishable from a future graph finalized after statement sealing and from a compiler-backed Lean dependency graph.
''')

dump('protocol-record.json',{'read_protocol_inputs':inputs[:-1],
 'applicability':'Bounded source-only extractor role. No new/changed production declarations, proof search, ledger admission or publication are authorized in this phase.',
 'required_later':['Exact new Statement Seal','Recursive binder and meaning-carrying definition audit','Independent source topology review after seal','Proof and compiler checks only after authorization/seal'],
 'not_run_with_reason':[{'action':a,'reason':r} for a,r in [
 ('Pull/fetch or checkout','Root HEAD is explicitly pinned and must not change.'),
 ('Global capsule/frontier/memory/ledger/inventory reads','Explicit source-only independence boundary forbids these inputs.'),
 ('Publication packet and local Lean/API search','Would expose typed signatures or old lesson/audit context before the raw freeze.'),
 ('Lean elaboration/build/proof search','No type or implementation exposure is authorized at this stage.'),
 ('Frontier/ledger/registry/status writes','Only this untracked assigned output directory is owned; no admission is authorized.')]],
 'review_state':'No independent acceptance or permission granted. Source gap ports remain open.'})

dump('exposure-record.json',{
 'actor':'/root/row_indep_source_graph_78c2','role':'independent source-only extractor',
 'new_lean_types_seen':False,'implementation_lean_seen':False,'prior_artifact_contents_opened':False,
 'prior_API_context':'No API-pristine assertion is made. The task states the formalizer will disclose known old API context later. This extractor has inspected no API in this run.',
 'allowed_inputs':'Current task and parent steering; exact protocol files snapshotted here; exact pinned source bounded text/fragments; git rev-parse HEAD; output-directory ancestor AGENTS existence checks.',
 'incidental_filename_only_exposure':{
  'command':"rg --files -g AGENTS.md -g '*CONTRIBUT*' -g '*PUBLICATION*' -g '*publication*' -g '*proof*digestion*' -g '*PROOF*DIGEST*' -g '*memory*' -g '*MEMORY*' -g '!GaussianComplexity/**' -g '!.astis/**' -g '!lake-packages/**' -g '!.lake/**' .",
  'workdir':'/Users/zhouhuanjian/ASTIS-GC','tool_chunk_id':'e53bb8','exit_code':0,
  'original_token_count':49252,'reported_output_lines':1529,'tool_max_output_tokens':4000,
  'reported_truncation':'Warning: truncated output (original token count: 49252)',
  'what_was_exposed':'Path metadata only, including prior semantic-evidence source-review/normal-verification/publication/memory artifact names under research-wiki, website and runs. No prior file contents were opened.',
  'exact_tool_evidence_location':'The authoritative initial functions.exec tool transcript in this actor run, result index 1, chunk e53bb8. The call was not persisted by the fresh functions isolate; no checksum or complete stdout reconstruction is fabricated here.',
  'visible_path_examples':['./CONTRIBUTING.md','./verifier-feedback/publication-protocol-20260909.md','./AGENTS.md','./tools/astis_process_memory.py','./tools/astis_publication.py','./website/scripts/publication_reader.py','./docs/theorem-publication-protocol.md','./docs/evidence-routed-memory-protocol.md','./docs/proof-digestion-protocol.md','./research-wiki/paper-contributions/GaussianComplexity/radial-fourth-matrix-semantic-evidence/source-review/r4_src_6aef/inputs/current-publication.json','./research-wiki/paper-contributions/GaussianComplexity/radial-fourth-matrix-semantic-evidence/normal-verification/r4_src_6aef/reviewed-publication-gate.stdout','./runs/20261007-companion-priority/pbps-actual-finite-count-path93/independent-whole-math93/inputs/004.theorem-publication-protocol.md.RAW'],
  'response':'Disclosed promptly to parent; continued with fixed protocol/source paths. No prior artifact content, conclusion, graph topology, verdict, or implementation was used.'},
 'other_exposure_notes':['Initial combined protocol output was tool-truncated; all required protocols were subsequently read through bounded exact-path calls.','Compact source extraction initially mishandled literal less-than signs after replacing math; the helper was corrected before interpretation and the relevant statements were reread. Exact raw bytes and locators, not that first compact view, are authoritative.','Additional source context S4.SS1 and short source-only paragraph/id previews near K_q/Lemma4.3 were read for definitions and excluded transfer boundaries. No source proof beyond the selected Appendix p12 boundary was inspected.'],
 'parent_steering':[{'instruction':'Continue source-only after incidental filename metadata; preserve disclosure; no invented blocker or grant.','effect':'Obeyed; no prior content opened.'},{'instruction':'Freeze raw reading/inventory/locators/omitted bridges now; defer final graph/typed topology acceptance until exact Statement Seal and binder/definition audit.','effect':'Graph file is explicitly preliminary and unaccepted; no new signature has been seen.'}],
 'no_actions':['No new GlobalGoal','No detached/background ASTIS','No tracked-file changes','No C/ledger/registry writes','No proof/status/permission grants','No source topology self-approval']})

dump('input-hashes.json',{'inputs':inputs,'root_HEAD_at_freeze':head,'read_source_helper_sha256':sha((BASE/'working/read_source.py').read_bytes()),'task_boundary':'Canonical independent columns -> full physical row joint independence -> actual Ex107 Yi joint independence only; raw pre-type/pre-seal preparation.'})
write('README.md','Frozen raw source extraction. Start with raw-interpretation.md, inventory.json and omitted-bridge-notes.json. preliminary-direct-use-graph.json is unaccepted preparation only. exposure-record.json records the filename-only discovery exposure and all stated boundaries. All inputs and raw HTML fragments are hashed by frozen-manifest.json. This bundle grants no mathematical/proof/publication status.\n')

manifest={'format':'astis-raw-source-freeze-v1','actor':'/root/row_indep_source_graph_78c2','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'root_HEAD':head,'source_sha256':sha(B),'state':'RAW_SOURCE_PREPARATION_FROZEN_NO_NEW_TYPE_EXPOSURE','statement_seal_seen':False,'topology_accepted':False,'files':[]}
for p in sorted(OUT.rglob('*')):
    if p.is_file():
        raw=p.read_bytes();manifest['files'].append({'path':str(p.relative_to(OUT)),'bytes':len(raw),'sha256':sha(raw)})
dump('frozen-manifest.json',manifest)
digest=sha((OUT/'frozen-manifest.json').read_bytes())
write('frozen-manifest.sha256',digest+'  frozen-manifest.json\n')
for p in OUT.rglob('*'):
    if p.is_file():p.chmod(0o444)
for p in sorted([p for p in OUT.rglob('*') if p.is_dir()],key=lambda p:len(p.parts),reverse=True):p.chmod(0o555)
OUT.chmod(0o555)
print(json.dumps({'freeze_path':str(OUT),'manifest_sha256':digest,'inventory_atoms':len(inv),'node_atoms':sum(i['disposition']=='NODE' for i in inv),'excluded_atoms':sum(i['disposition']=='EXCLUDED' for i in inv),'continuous_appendix_units':len(coverage),'source_gap_ports':len(gaps),'root_HEAD':head},indent=2))
