# Independent raw-source freeze

Role: RAW source/topology challenger. This is a source judgment and a list of necessary obligations, not a proof or an implementation grant. The root remains the sole mathematical prover. No next literal theorem types, definition packet, source-graph handoff, prior report, Lean implementation, or proof API was inspected before this freeze.

Pinned source: `.astis/huanjian-resume-20261103/2610.20492v1.html`, 951991 bytes, SHA256 `6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915`.

## Exact source scope

The primary anchor is `A3.SS2.p14`, equation `A3.Ex113`. The accepted delta stops at the individual squared-truncation bound implicit in the first PSD inequality of that paragraph, before any sum over rows, norm bound for the cosine vectors, variance parameter, weighted centered variance, or Bernstein inequality.

The source states

\[
\mathbb E[R_i\gamma_i\gamma_i^\top]=(r+2)I_r.
\]

Its explanation is: off-diagonal entries vanish by sign symmetry; a diagonal entry is the coordinate fourth moment 3 plus the `r-1` distinct-coordinate mixed second moments, each 1.

With the source definitions, the immediate individual conclusion is

\[
\mathbb E[Y_i^2]\preceq
\frac{(r+2)\|t_i\|^2}{d^2}
(I_r\otimes t_it_i^\top).
\]

This individual conclusion is reconstructed from the displayed formula for `Y_i^2` and the instruction to drop its PSD truncation indicator. It is not a separately numbered source equation. It does not assert equality for finite cutoff.

## Frozen assumptions and normalizations

1. Source context: integers `q >= 0`, `d` with `2q+1 < d`; hence `r=q+1 >= 1`, `n=2q+1`, `d>=2`. The Gaussian radial fourth-moment equality itself only needs one standard Gaussian row in finite dimension `r`; the individual bound only adds a deterministic finite vector `t` and a positive denominator `d`. Neither requires the global Krylov-space smallness condition `tau <= 1/2`.
2. `g_1,...,g_r` are independent `N(0,I_d)` vectors. `gamma_i=((g_1)_i,...,(g_r)_i)^T` is an `r`-dimensional standard Gaussian vector with independent variance-one coordinates. The row vectors are independent across `i`, but cross-row independence has no role in either individual conclusion.
3. Row index `i` runs from 1 to `d`. Gaussian coordinate index `a` runs from 1 to `r`. Cosine coordinate index `j` runs from 0 to `q`. Under a zero-based finite index implementation, these index shifts must be explicit in definitions; the midpoint is `(i+1/2) pi/d` for zero-based row `i`, not `(i-1/2) pi/d`.
4. `theta_i=(i-1/2) pi/d`. `t_i=(1,sqrt(2)cos(theta_i),...,sqrt(2)cos(q theta_i))^T` has exactly `r` coordinates. It is deterministic. The constant coordinate is 1, never `sqrt(2)`. `||t_i||^2=1+2 sum_{j=1}^q cos^2(j theta_i)`. The later bound `||t_i||^2 <= 2r` and sum identity `sum_i t_i t_i^T=d I_r` are outside this minimal delta.
5. The source row of `B` is `d^(-1/2) (gamma_i tensor t_i)^T`. The matrix `Y_i` is the uncentered outer product of this row after truncation: `d^(-1)(gamma_i gamma_i^T tensor t_i t_i^T) 1_{R_i <= L}`. Thus the scalar in `Y_i^2` is `d^(-2)`, and its matrix indices are ordered `(Gaussian coordinate, cosine coordinate)`.
6. `R_i=||gamma_i||^2=sum_a gamma_{i,a}^2`, not the norm, its square root, a normalized radius, the ambient `d`-dimensional radius, or the tensor-vector norm. The coefficient in the radial fourth-moment equality is `r+2`, not `d+2` or `r^2+2`.
7. `L=2r+3 log(1000d)` and the truncation is the closed event `R_i <= L`. Its complement in the source tail calculation is `R_i > L`. The fourth-moment equality has no truncation and no cutoff dependence. The individual PSD bound is valid for any deterministic measurable real cutoff, including a negative cutoff (then `Y_i=0`); the source cutoff is positive under its context. Cutoff positivity and Gaussian tail estimates are unnecessary premises for the individual bound.
8. All matrices and tensor products here are real. Transpose equals adjoint. `Y_i^2` means matrix multiplication `Y_i Y_i`, not the entrywise square. Expectation is with respect to the standard Gaussian probability law, equivalently the given source experiment pushed to this row. Standard probability mass 1 is necessary when integrating constant matrices.

## Necessary source ingredients and hidden regularity

The source compresses genuine mathematical dependencies into “Gaussian fourth moments.” The following must be established or supplied by an independently justified background theorem; they are not free public premises of the paper-facing result.

- Each coordinate has second moment 1 and fourth moment 3; each pair of distinct coordinates is independent, hence its product of coordinate squares has expectation 1. Marginal normality alone does not supply the mixed moment.
- The quartic polynomials `R gamma_a gamma_b` are absolutely integrable. All coordinate fourth powers are integrable. A finite-dimensional Gaussian has all polynomial moments, but this regularity must reach the matrix expectation through actual integrability arguments. A totalized nonintegrable integral that happens to return zero cannot justify the matrix equality or order passage.
- A coordinate reflection preserves the standard Gaussian law and `R`, while it negates every off-diagonal entry `R gamma_a gamma_b` upon reflection in coordinate `a`. Integrability is needed before using the resulting odd-integral cancellation. Full radial symmetry plus covariance shape alone does not determine the coefficient `r+2`.
- Finite-sum interchange with expectation is justified entrywise. Diagonal identification uses exactly one repeated-coordinate fourth moment and `r-1` mixed moments. Matrix extensionality then identifies the diagonal and off-diagonal entries of `(r+2) I_r`.
- `gamma gamma^T` and `t t^T` are PSD and symmetric; their tensor product is PSD and symmetric. `R`, `||t||^2`, and `d^-2` are nonnegative. The source's rank-one identities are `(gamma gamma^T)^2=R gamma gamma^T` and `(t t^T)^2=||t||^2 t t^T`.
- Tensor multiplication and the indicator's idempotence yield `Y_i^2=d^-2 R_i ||t_i||^2 (gamma_i gamma_i^T tensor t_i t_i^T) 1_{R_i<=L}`. The indicator must appear once, since its square equals itself.
- Dropping the indicator is a pointwise Loewner-order comparison of PSD matrices. It is not an entrywise comparison: off-diagonal entries can be negative.
- Integrability of the untruncated quartic matrix, and of its truncated version, must justify expectation preserving the PSD order. Truncated entries are dominated in absolute value by an integrable quartic envelope; PSD domination alone should not be mistaken for componentwise domination.
- The `t` factor is deterministic. Entrywise finite-dimensional expectation commutes with the constant tensor factor and real scalar factors; no probabilistic independence from a constant tensor is needed. Applying the radial equality then yields the individual coefficient `(r+2)||t_i||^2/d^2`.

## Independent expected topology

This topology is frozen before seeing any supplied graph. Labels describe mathematical obligations, not existing Lean declarations.

`standard Gaussian row law -> scalar fourth/second moments + coordinate independence + reflection invariance + quartic integrability`.

`scalar moments + coordinate independence -> diagonal entries of E[R gamma gamma^T]`.

`reflection invariance + quartic integrability -> off-diagonal entries vanish`.

`diagonal + off-diagonal identifications -> radial fourth-moment matrix equality`.

`source Y definition + rank-one square identities + tensor multiplication + indicator idempotence -> exact Y^2 formula`.

`rank-one PSD + tensor PSD + nonnegative scalars + indicator in [0,1] -> pointwise Y^2 <= untruncated quartic matrix`.

`quartic integrability + finite constant tensor/scalar extraction + expectation monotonicity + radial matrix equality -> individual E[Y^2] PSD upper bound`.

The cosine norm bound, cosine Gram sum, truncation-bias scalar `a`, cross-row independence, centering identity, weighted variance, and Bernstein theorem are consumers or neighboring facts. They are not parents of the two individual claims. A supplied graph that omits fourth or mixed moment inputs, absolute integrability, PSD order, constant-tensor extraction, or the exact square algebra needs a concrete coverage explanation; a graph that imports the target identity as its own ancestor is circular.

## Edge cases and failure boundaries

- `q=0`, `r=1`, `n=1`, `d>=2` is included. Then `t_i=(1)`, `R_i=gamma_i^2`, the matrix equality is scalar `E[gamma_i^4]=3`, and the individual bound is `E[Y_i^2] <= 3/d^2`. There are no off-diagonal entries and no distinct-coordinate mixed terms. A type requiring `q>0`, `r>=2`, or an existing distinct coordinate would drop this source case.
- `r=0` is not a source case because `r=q+1`. A generic zero-dimensional matrix equality is vacuous, but it must not be used to bypass the source's positive dimension or its neighboring `1/r` normalizations.
- Mean-zero isotropy alone is insufficient. An independent Rademacher vector has covariance `I_r` but radial coefficient `r`, not `r+2`. A rotationally invariant fixed-radius vector with radius `sqrt(r)` gives the same counterexample mechanism.
- Coordinatewise `N(0,1)` marginals without joint independence or a joint standard Gaussian law are insufficient. If all coordinates equal one scalar standard Gaussian, diagonal radial moments are `3r`, and off-diagonal entries need not vanish.
- A centered Gaussian of variance `sigma^2` has radial coefficient `sigma^4(r+2)`, not `r+2`; nonidentity covariance generally gives a nonidentity matrix expression. A nonzero mean changes the formula.
- With signed matrix entries, indicator removal is false as an entrywise inequality. Without the matrix PSD meaning or an equivalent quadratic-form condition, the claimed comparison is malformed.
- If `t` is random and correlated with the Gaussian row, pulling it outside expectation is unjustified. Treating source `t_i` as deterministic is essential.
- If the source radius is replaced by `||gamma tensor t||^2`, extra powers of `||t||` appear. If `Y` includes an extra scaling or is centered before squaring, the displayed individual formula changes.
- The individual upper bound need not be equality at finite cutoff; omitted Gaussian tails contribute a PSD remainder. The bound is distinct from the later sum and from the variance bound `2r(r+2)/d`.
- No theorem in this packet may silently assume the radial identity, its needed fourth/mixed moments, an expectation-tensor formula specialized to the conclusion, or the individual PSD bound itself as an extra paper-facing premise. A generic helper may expose abstract assumptions only if the source-facing theorem internally derives them from the source Gaussian law and its definitions.

## Status and next gate

RAW SOURCE FROZEN. The exact sealed type-and-definition packet is required next. Its type-only judgment must be frozen before any supplied source proof graph is read. This freeze does not certify a Lean proof, compilation, publication, topology exhaustiveness of an unseen graph, or process admission.
