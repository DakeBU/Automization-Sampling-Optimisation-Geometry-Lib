import re
FORBIDDEN_REGEX = re.compile('\\bsorry\\b|\\badmit\\b|^\\s*(?:@\\[[^\\]]*\\]\\s*)*(?:(?:private|protected|noncomputable|local|unsafe|partial)\\s+)*(?:axiom|constant|postulate)\\b|Prop\\s*:=\\s*True|:=\\s*trivial')

def strip_lean_comments_and_strings(text: str) -> str:
    """Remove Lean comments and string literals for policy scans.

    The forbidden-proof gate should reject executable proof closures, not the
    documentation that explains the policy or the string-valued policy table in
    `Core.lean`.
    """
    result: list[str] = []
    index = 0
    block_depth = 0
    in_string = False
    in_line_comment = False
    while index < len(text):
        char = text[index]
        nxt = text[index + 1] if index + 1 < len(text) else ''
        if in_line_comment:
            if char == '\n':
                in_line_comment = False
                result.append('\n')
            else:
                result.append(' ')
            index += 1
            continue
        if block_depth > 0:
            if char == '/' and nxt == '-':
                block_depth += 1
                result.extend('  ')
                index += 2
                continue
            if char == '-' and nxt == '/':
                block_depth -= 1
                result.extend('  ')
                index += 2
                continue
            result.append('\n' if char == '\n' else ' ')
            index += 1
            continue
        if in_string:
            if char == '\\' and nxt:
                result.extend('  ')
                index += 2
                continue
            if char == '"':
                in_string = False
            result.append('\n' if char == '\n' else ' ')
            index += 1
            continue
        if char == '-' and nxt == '-':
            in_line_comment = True
            result.extend('  ')
            index += 2
            continue
        if char == '/' and nxt == '-':
            block_depth = 1
            result.extend('  ')
            index += 2
            continue
        if char == '"':
            in_string = True
            result.append(' ')
            index += 1
            continue
        result.append(char)
        index += 1
    return ''.join(result)
