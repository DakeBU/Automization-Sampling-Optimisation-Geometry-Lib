"""One bounded interface-only Lean invocation with exact receipts."""
import datetime
import hashlib
import json
import subprocess
import sys
import time
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
probe = OUT / (sys.argv[1] if len(sys.argv) > 1 else "InterfaceVisibilityProbe.lean")
stem = sys.argv[2] if len(sys.argv) > 2 else "interface-probe"
cmd = ["lake", "env", "lean", str(probe.relative_to(ROOT))]
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
t0 = time.monotonic()
r = subprocess.run(cmd, cwd=ROOT, capture_output=True)
(OUT / (stem + ".stdout")).write_bytes(r.stdout)
(OUT / (stem + ".stderr")).write_bytes(r.stderr)
sha = lambda b: hashlib.sha256(b).hexdigest()
receipt = {
    "scope": "ordinary-import declaration types and typeclass synthesis only",
    "command": cmd,
    "started_utc": started,
    "elapsed_seconds": time.monotonic() - t0,
    "exit_code": r.returncode,
    "probe_sha256": sha(probe.read_bytes()),
    "stdout_sha256": sha(r.stdout),
    "stderr_sha256": sha(r.stderr),
    "lean_toolchain_sha256": sha((ROOT / "lean-toolchain").read_bytes()),
    "lake_manifest_sha256": sha((ROOT / "lake-manifest.json").read_bytes()),
    "target_proofs_supplied": 0,
    "proof_values_or_DAG_queried": False,
    "import_all_used": False,
}
(OUT / (stem + ".receipt.json")).write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps(receipt, indent=2))
print(r.stdout.decode(errors="replace")[-8500:])
