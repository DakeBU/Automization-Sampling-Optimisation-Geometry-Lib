import AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumThreshold
import Tests.GaussianComplexityFixedSpectrumThreshold
import Lean
noncomputable section
open Lean Meta Elab Command MeasureTheory ProbabilityTheory
open scoped BigOperators
set_option linter.unusedVariables false
def expectedProducer : Prop := ∀ (C : ℝ) (hC : 0 < C) {δ : ℝ} (hδ0 : 0 < δ) (hδ1 : δ < 1),
  ∃ d₀ : ℕ, ∀ (d : ℕ), d₀ ≤ d → ∀ (κ : ℝ), 2 ≤ κ →
    κ ≤ (d : ℝ) ^ (1 - δ) → ∀ (q : ℕ),
    (q : ℝ) ≤ (δ / 256) * Real.sqrt κ * Real.log (d : ℝ) →
    let n : ℕ := 2 * q + 1
    let θ : Fin d → ℝ := fun i => ((i.val : ℝ) + 1 / 2) * Real.pi / (d : ℝ)
    let eigenvalue : Fin d → ℝ := fun i => (κ + 1) / 2 + (κ - 1) / 2 * Real.cos (θ i)
    let Λ : Matrix (Fin d) (Fin d) ℝ := Matrix.diagonal eigenvalue
    let μ : Measure (EuclideanSpace ℝ (Fin d)) :=
      multivariateGaussian (0 : EuclideanSpace ℝ (Fin d)) Λ⁻¹
    let Q : EuclideanSpace ℝ (Fin d) → ℝ := fun x =>
      ∑ i : Fin d, Real.cos ((n : ℝ) * θ i) * (WithLp.ofLp x i) ^ 2
    let τ : ℝ := C * (((q : ℝ) + 1) * Real.sqrt (Real.log (d : ℝ) / (d : ℝ)) +
      (((q : ℝ) + 1) * ((q : ℝ) + 1 + Real.log (d : ℝ)) * Real.log (d : ℝ)) / (d : ℝ))
    let M : ℝ := ∫ x : EuclideanSpace ℝ (Fin d), ‖x‖ ^ 2 ∂μ
    let b : ℝ := ∫ x : EuclideanSpace ℝ (Fin d), Q x ∂μ
    let β : ℝ := |b| / M
    0 ≤ τ ∧ τ ≤ 1 / 2 ∧ τ ≤ β / 4

def expectedConsumer : Prop := ∀ (C : ℝ) (hC : 0 < C) {δ : ℝ} (hδ0 : 0 < δ) (hδ1 : δ < 1),
  ∃ d₀ : ℕ, ∀ (d : ℕ), d₀ ≤ d → ∀ (κ : ℝ), 2 ≤ κ →
    κ ≤ (d : ℝ) ^ (1 - δ) → ∀ (q : ℕ),
    (q : ℝ) ≤ (δ / 256) * Real.sqrt κ * Real.log (d : ℝ) →
    let n : ℕ := 2 * q + 1
    let θ : Fin d → ℝ := fun i => ((i.val : ℝ) + 1 / 2) * Real.pi / (d : ℝ)
    let eigenvalue : Fin d → ℝ := fun i => (κ + 1) / 2 + (κ - 1) / 2 * Real.cos (θ i)
    let Λ : Matrix (Fin d) (Fin d) ℝ := Matrix.diagonal eigenvalue
    let μ : Measure (EuclideanSpace ℝ (Fin d)) :=
      multivariateGaussian (0 : EuclideanSpace ℝ (Fin d)) Λ⁻¹
    let Q : EuclideanSpace ℝ (Fin d) → ℝ := fun x =>
      ∑ i : Fin d, Real.cos ((n : ℝ) * θ i) * (WithLp.ofLp x i) ^ 2
    let τ : ℝ := C * (((q : ℝ) + 1) * Real.sqrt (Real.log (d : ℝ) / (d : ℝ)) +
      (((q : ℝ) + 1) * ((q : ℝ) + 1 + Real.log (d : ℝ)) * Real.log (d : ℝ)) / (d : ℝ))
    (μ {x | (-1 : ℝ) ^ n * Q x - 2 * τ * ‖x‖ ^ 2 ≤ 0}).toReal ≤ (1 : ℝ) / 10
def auditReachable (env : Environment) (owned : NameSet) (roots : Array Name) : MetaM NameSet := do
  let mut pending := roots
  let mut seen : NameSet := {}
  for _ in [:1000] do
    if pending.isEmpty then break
    let n := pending.back!
    pending := pending.pop
    if seen.contains n then continue
    seen := seen.insert n
    let ci ← getConstInfo n
    for d in ci.getUsedConstantsAsSet.toList do
      if owned.contains d && !seen.contains d then pending := pending.push d
  unless pending.isEmpty do throwError "Bounded local closure exceeded 1000 steps"
  return seen

def auditFirstPublic (env : Environment) (root : Name) : MetaM NameSet := do
  let mut pending := #[root]
  let mut seen : NameSet := {}
  let mut parents : NameSet := {}
  for _ in [:1000] do
    if pending.isEmpty then break
    let n := pending.back!
    pending := pending.pop
    if seen.contains n then continue
    seen := seen.insert n
    let ci ← getConstInfo n
    for d in ci.getUsedConstantsAsSet.toList do
      if d.toString.startsWith "AutoSamplingTheory." && d != root &&
          (d.toString.splitOn "_proof_").length == 1 && (d.toString.splitOn "_simp_").length == 1 then
        parents := parents.insert d
      else if d.toString.startsWith "AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumThreshold." ||
          d.toString.startsWith "_private.AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumThreshold." ||
          d.toString.startsWith "_private.Tests.GaussianComplexityFixedSpectrumThreshold." then
        if !seen.contains d then pending := pending.push d
  unless pending.isEmpty do throwError "First-public closure exceeded 1000 steps"
  return parents

run_elab do
  let env ← getEnv
  let modNames := #[`AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumThreshold,
    `Tests.GaussianComplexityFixedSpectrumThreshold]
  let ownedPairs := env.constants.toList.filter fun (n, _) =>
    match env.getModuleIdxFor? n with
    | none => false
    | some idx => modNames.contains env.header.moduleNames[idx.toNat]!
  let owned := NameSet.ofList (ownedPairs.map Prod.fst)
  let suffixes := ["eventual_actual_gaussian_threshold_small", "threshold_envelope", "eventual_threshold_power_small", "actual_gaussian_source_query_shifted_event_le_tenth"]
  let mut roots : Array Name := #[]
  for suffix in suffixes do
    let candidates := ownedPairs.filter fun (n, _) => n.toString.endsWith ("." ++ suffix) || n.toString == suffix
    unless candidates.length == 1 do throwError "Expected one handwritten declaration {suffix}, found {candidates.length}"
    roots := roots.push candidates.head!.1
  let producer ← getConstInfo roots[0]!
  let consumer ← getConstInfo roots[3]!
  let ep ← getConstInfo ``expectedProducer
  let ec ← getConstInfo ``expectedConsumer
  unless ← isDefEq producer.type (ep.value? (allowOpaque := true)).get! do throwError "Producer seal mismatch"
  unless ← isDefEq consumer.type (ec.value? (allowOpaque := true)).get! do throwError "Consumer seal mismatch"
  logInfo "EXACT_SIGNATURES producer=true consumer=true"
  let reach ← auditReachable env owned #[roots[0]!, roots[3]!]
  let producerReach ← auditReachable env owned #[roots[0]!]
  logInfo m!"OWNED_COUNT {ownedPairs.length}"
  logInfo m!"ROOT_REACHABLE_COUNT {reach.toList.length}"
  for (n, ci) in ownedPairs.mergeSort (fun a b => a.1.toString < b.1.toString) do
    let category := if roots.contains n then "handwritten" else if (n.toString.splitOn "_proof_").length > 1 then "generated-proof" else if (n.toString.splitOn "_simp_").length > 1 then "generated-simp" else "OTHER"
    let axs ← Lean.collectAxioms n
    logInfo m!"OWNED {n}\nCATEGORY {category} REACHABLE {reach.contains n} PRODUCER_REACHABLE {producerReach.contains n}\nAXIOMS {axs}"
    if category == "handwritten" && n != roots[0]! && n != roots[3]! then
      logInfo m!"PRIVATE_HELPER_TYPE {← ppExpr ci.type}"
    if category != "handwritten" then
      let t := (← ppExpr ci.type).pretty
      logInfo m!"GENERATED_TYPE {t.take 300}"
  for n in [roots[0]!, roots[3]!] do
    logInfo m!"FIRST_PUBLIC {n}\nPARENTS {(← auditFirstPublic env n).toList}"
    let ci ← getConstInfo n
    let relevant := ci.getUsedConstantsAsSet.toList.filter fun d =>
      d.toString.startsWith "AutoSamplingTheory." || d.toString.startsWith "_private.AutoSamplingTheory." ||
      d.toString.startsWith "ProbabilityTheory." || d.toString.startsWith "ENNReal." ||
      d.toString.startsWith "MeasureTheory.MemLp." ||
      (d.toString.splitOn "measur").length > 1 || (d.toString.splitOn "Measur").length > 1 ||
      d.toString.startsWith "EuclideanSpace.proj"
    logInfo m!"DIRECT_RELEVANT {relevant}"
    let directProject := ci.getUsedConstantsAsSet.toList.filter fun d =>
      (d.toString.startsWith "AutoSamplingTheory." || d.toString.startsWith "_private.AutoSamplingTheory.") &&
      (d.toString.splitOn "_proof_").length == 1 && (d.toString.splitOn "_simp_").length == 1
    logInfo m!"DIRECT_PROJECT_NON_GENERATED {directProject}"
  logInfo m!"PRODUCER_TYPE {← ppExpr producer.type}"
  logInfo m!"CONSUMER_TYPE {← ppExpr consumer.type}"
