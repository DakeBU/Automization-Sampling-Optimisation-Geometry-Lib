from pathlib import Path
import sys,json,hashlib,subprocess,gzip,copy
sys.dont_write_bytecode=True;sys.path.insert(0,'tools')
import astis_advance as adv
W=Path(__file__).resolve().parent.relative_to(Path.cwd())
E=Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-cosine-gram-semantic-evidence')
S=E.parent/'fixed-spectrum-cosine-gram-statement-seal.json'
C=Path('research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-cosine-gram.json')
L=Path('runs/substantive_advances.jsonl')
ADV='ASTIS-SA-20261110-GaussianComplexityFixedSpectrumCosineGram'
OWNER='huanjian_gc_20261110_fixed_spectrum_cosine_gram'
sha=lambda b:hashlib.sha256(b).hexdigest();dump=lambda x:(json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode()
assert not C.exists() and not E.exists() and not S.exists() and not (W/'preproof-baseline.private.json').exists()
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()=='75dcc0c9c7d9591384c6e0705e118b1ab440cd6c'
raw=L.read_bytes();states=adv._replay_advances(json.loads(z) for z in raw.splitlines())
assert ADV not in states and states['ASTIS-SA-20261110-GaussianComplexityZeroQuerySeparation']['state']=='VERIFIED'
fronts={str(p):sha(p.read_bytes()) for p in Path('research-wiki/frontier-cells').glob('*.json')}
tracked={}
for n in subprocess.check_output(['git','ls-files','-z']).decode().split('\0'):
    if n and Path(n).is_file():tracked[n]=sha(Path(n).read_bytes())
baseline={'state':'PRIVATE_RAW_FOREIGN_NEVER_ARCHIVE','head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'ledger_bytes':len(raw),'ledger_sha256':sha(raw),'all_foreign_states':states,'all_existing_frontier_hashes':fronts,'all_tracked_regular_file_hashes':tracked,'scope':'Tracked regular files only. Foreign untracked nested ATLAS repository contents are excluded, never read as proof data; additional exact control-file guards are prepared separately.'}
bp=W/'preproof-baseline.private.json';bp.write_bytes(dump(baseline));bp.chmod(0o444)
E.mkdir();sealraw=(W/'statement-seal-v1.json').read_bytes()
assert sha(sealraw)=='a5e464a34ee276e62267d21f0965c1a0b1ef905bed27e679a85ecee3cd7fd45c'
S.write_bytes(sealraw);s=json.loads(sealraw)
copy_names={'producer-signature.draft.txt':'producer-signature.txt','consumer-signature.draft.txt':'consumer-signature.txt','StatementFormation.raw.lean.txt':'Prop-only-statement-formation.raw.lean.txt','statement-formation.json':'actual-statement-formation.json','actual-environment-at-seal.json':'actual-environment-at-seal.json','preseal-planning.json':'preseal-planning.raw.json','postseal-informal-planning.json':'postseal-informal-planning.raw.json','additional-preseal-source-role-exposure.json':'additional-preseal-source-role-exposure.raw.json','strict-statement-projection.json':'selective-preproof-types-and-definitions.json','multivariateGaussian-literal-definition.txt':'necessary-definition-context/multivariateGaussian-literal-definition.txt','additional-canonical-Gaussian-definitions.json':'necessary-definition-context/additional-canonical-Gaussian-definitions.json','additional-canonical-Gaussian-density-definitions.json':'necessary-definition-context/additional-canonical-Gaussian-density-definitions.json'}
portable=[]
for n,dest in copy_names.items():
    p=E/dest;p.parent.mkdir(parents=True,exist_ok=True);b=(W/n).read_bytes();p.write_bytes(b)
    portable.append({'original_private_path':str(W/n),'portable_exact_copy':str(p),'sha256':sha(b),'bytes':len(b)})
(E/'private-origin-portable-definition-and-input-index.json').write_bytes(dump({'scope':'Original immutable seal refers to actual historical private input paths; these are exact-byte portable copies, never fabricated source URLs or changed seal meanings.','copies':portable}))
for stem in ['20261110T141130894994Z-cosine-gram-draft-two-literal-Prop-only-formation','20261110T141739878001Z-cosine-gram-exact-statement-binder-definition-seal-no-proof']:
    p=Path('.astis/huanjian-resume-20261103')/(stem+'.receipt.json');x=json.loads(p.read_bytes());log=Path(x['log']).read_bytes()
    assert x['exit_code']==0 and sha(log)==x['log_sha256']
    (E/p.name).write_bytes(p.read_bytes());(E/(stem+'.log.gz')).write_bytes(gzip.compress(log,mtime=0))
template=json.loads(Path('research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-zero-query-separation.json').read_bytes())
reader=copy.deepcopy(template['reader_contract'])
learning=copy.deepcopy(template['learning_contract'])
learning['failure_class']='NONE'
learning['salvage']={'required':False,'status':'not-applicable','reason':'Only actual literal Prop formation has run and passed; no target mathematical implementation route has failed. Earlier related source-extraction tooling exposure is recorded separately.','promoted_fragments':[],'discarded_fragments':[]}
learning['parallelism']['expected_information_gain']='Root is the sole mathematical prover; raw source author, distinct topology challenger and later fresh source/blind/native reviews answer independent uncertainties, not parallel proof implementations.'
floor='Known prior canonical finite-grid alias packet and earlier Gaussian-moment background; root prior related proof knowledge is disclosed. Exact new-target API retrieval waits for independent source/topology/process admission.'
boundary='Selected FactC.5 deterministic cosine-frame Gram, D_(2q+1)-weighted cancellation and row-norm component, with a real private actual standard-Gaussian entrywise Gram integrability/mean consumer. Range(B)=Krylov, C6 concentration/absoluteC, full Lemma4.4, Haar/adaptive/oracle/TV/precision/deterministic-cap/expected-cost adapters, both main lower bounds and all integration/delivery/purification/Goal acceptance remain separate.'
c={'schema_version':3,'cell_id':C.stem,'route':'samplewiki-route','mode':'faithfulPaper','title':'Gaussian complexity: cosine-frame Gram and actual Gaussian centering','source_anchor':'arXiv:2610.20492v1 S4.Thmtheorem4; AppendixC.2 A3.Thmtheorem5 deterministic frame/Gram means','target_statement':s['producer']['signature'],'status':'claimed','owner_id':OWNER,'advance_id':ADV,'parents':[],
'consumers':['Planned compiled private actual_gaussian_gram_means: actual Gaussian Gram-entry integrability and both mean matrices.','FactC.6 simultaneous Gram concentration uses these centers and row norm; concentration remains open.'],
'shared_floor_audit':{'searched':[floor,'Necessary literal multivariateGaussian/stdGaussian/gaussianReal/PDF definitions inspected; no new target proof APIs or implementation yet.'],'classification':'adapt','decision':'new_route_local','canonical_declaration':'','canonical_shared_cell':''},
'reuse_plan':{'searched_existing':[floor],'reused_declarations':[],'new_shared_declarations':[],'known_consumers':[],'planned_consumers':['Private actual_gaussian_gram_means','FactC.6 actual random Gram concentration'],'no_duplicate_wrapper':True,'decision_reason':'Prove actual deterministic matrix identities consumed in actual Gaussian expectation computation. Canonical finite-grid and Gaussian primitives must be reused as exact compiled nodes; no supplied Gram/moment/count witness or wrapper gives mathematical credit.'},
'reader_contract':reader,
'graph_contribution':{'lean_view':'new-node','overview_view':'no-change-with-reason','functor_view':'none-found','edge_semantics':'formal-solid; overlays-dashed','color_semantics':'evidence-status; library-scope','focus_targets':[s['producer']['name']],'visual_review':'Prospective contract only. Source graph is not an actual compiled edge; shared graph/site/Registry/source-index delivery requires original-owner release and the true serialized lease.'},
'learning_contract':learning,
'source_detail_audit':{'primary_edition':'arXiv:2610.20492v1','primary_anchor':'A3.Thmtheorem5','detail_status':'sufficient','gap':'For this selected public deterministic component, the raw source explicitly supplies finite cosine cancellation, Gram/weighted product-to-sum and row-norm arguments. Independent coverage/topology acceptance and all Lean proofs remain pending. The private actual Gaussian law/moment/integrability background must be proved internally; no complete FactC.5 range or C6 credit is asserted.','fidelity_boundary':boundary},
'statement_seal':{'status':'EXACT_LITERAL_PROP_FORMED_UNREVIEWED_NO_TARGET_PROOF','file':str(S),'sha256':sha(sealraw),'signature_sha256':s['producer']['signature_sha256']},
'evidence':{'focused_checks':[str(E/'20261110T141130894994Z-cosine-gram-draft-two-literal-Prop-only-formation.receipt.json')],'independent_verification':'','source_review':'Pending distinct independent source/topology review; raw-first source author typed overlay is not an implementation or V.','execution_boundary':'Only preproof frontier reservation; no normal proposal/CLAIMED/EXPLORING API, target proof/API or sourceV before exact prospective independent admission.','prior_results_preserved':'All eleven queued locally source-verified Gaussian packets, original sourceV nested values and privateT reader HOLD, older A1/HFT audit debt, PBPS/SPHMC and other ASTIS chat remain intact.'},
'blocked':{'reason':'','children':[]},'owned_files':[s['producer']['planned_file'],s['actual_private_consumer']['planned_file'],str(C),str(S),str(E),'website/content/declaration_lessons/huanjian-fixed-spectrum-cosine-gram.json','website/content/publications/huanjian-fixed-spectrum-cosine-gram.json','research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-cosine-gram.json'],
'forbidden_shared_files':['Tests.lean','AutoSamplingTheory/TechnicalLemmas/Registry.lean','website/content/graph_memory_index.json','website/content/functor_hypergraph.json'],'truth_boundary':boundary}
C.write_bytes(dump(c))
assert L.read_bytes()==raw
for f,h in fronts.items():assert sha(Path(f).read_bytes())==h,f
for f,h in tracked.items():assert sha(Path(f).read_bytes())==h,f
safe={'state':'PREPROOF_RESERVATION_NO_NORMAL_INTAKE_OR_PROOF','advance_id':ADV,'owner':OWNER,'private_foreign_baseline_sha256':sha(bp.read_bytes()),'foreign_states_preserved':len(states),'foreign_frontier_files_preserved':len(fronts),'tracked_regular_files_preserved':len(tracked),'raw_ledger_unchanged_sha256':sha(raw),'all_original_historical_and_current_V_values_preserved':True,'private_foreign_baseline_not_exported':True,'exact_seal_sha256':sha(sealraw),'same_Global_Goal_and_original_owner_preserved':True}
(E/'preproof-reservation-preservation.json').write_bytes(dump(safe));print(json.dumps(safe))
