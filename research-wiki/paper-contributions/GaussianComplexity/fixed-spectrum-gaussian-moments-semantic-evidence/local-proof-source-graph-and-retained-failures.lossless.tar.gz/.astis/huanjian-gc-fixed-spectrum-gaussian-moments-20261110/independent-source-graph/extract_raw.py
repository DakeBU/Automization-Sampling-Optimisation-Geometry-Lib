from pathlib import Path
from html.parser import HTMLParser
import json,re
BASE=Path(__file__).resolve().parent
SOURCE=BASE/'phase1/inputs/2610.20492v1.html'
raw=SOURCE.read_text()
line_starts=[0]
for m in re.finditer(r'\n',raw):line_starts.append(m.end())
class Node:
 def __init__(self,tag,attrs,start,parent=None):
  self.tag=tag;self.attrs=dict(attrs);self.start=start;self.end=start;self.parent=parent;self.children=[]
 def walk(self):
  yield self
  for c in self.children:
   if isinstance(c,Node):yield from c.walk()
 def render(self):
  if self.tag=='math':return ' ⟦'+self.attrs.get('alttext','MISSING_ALTTEXT')+'⟧ '
  return ''.join(c.render() if isinstance(c,Node) else c for c in self.children)
 def normalized(self):return re.sub(r'\s+',' ',self.render()).strip()
 def record(self):
  return {'id':self.attrs.get('id'),'tag':self.tag,'class':self.attrs.get('class'),'source_lines':[raw.count('\n',0,self.start)+1,raw.count('\n',0,self.end)+1],'text':self.normalized(),'math':[{'id':n.attrs.get('id'),'alttext':n.attrs.get('alttext'),'display':n.attrs.get('display')} for n in self.walk() if n.tag=='math'],'links':[{'href':n.attrs['href'],'text':n.normalized(),'title':n.attrs.get('title')} for n in self.walk() if 'href' in n.attrs]}
class Parser(HTMLParser):
 def __init__(self):super().__init__(convert_charrefs=True);self.root=Node('ROOT',[],0);self.stack=[self.root];self.byid={}
 def source_offset(self):line,col=self.getpos();return line_starts[line-1]+col
 def handle_starttag(self,tag,attrs):
  n=Node(tag,attrs,self.source_offset(),self.stack[-1]);self.stack[-1].children.append(n)
  if 'id' in n.attrs:self.byid[n.attrs['id']]=n
  if tag not in {'meta','link','br','hr','img','input','area','base','col','embed','param','source','track','wbr'}:self.stack.append(n)
  else:n.end=n.start+len(self.get_starttag_text())
 def handle_startendtag(self,tag,attrs):self.handle_starttag(tag,attrs)
 def handle_endtag(self,tag):
  for j in range(len(self.stack)-1,0,-1):
   if self.stack[j].tag==tag:
    end=raw.find('>',self.source_offset())+1
    for n in self.stack[j:]:n.end=end
    del self.stack[j:];break
 def handle_data(self,s):self.stack[-1].children.append(s)
p=Parser();p.feed(raw)
if __name__=='__main__':
 import sys
 scopes=sys.argv[1:] or ['S4.SS1','S4.Thmtheorem5','A3.SS3']
 for scope in scopes:
  n=p.byid[scope]
  blocks=[x.record() for x in n.walk() if (x.tag=='p' and 'ltx_p' in x.attrs.get('class','')) or (x.tag=='table' and ('ltx_equation' in x.attrs.get('class','') or 'ltx_eqn_table' in x.attrs.get('class',''))) or x.tag in {'h2','h3','h4','h5','h6'}]
  # Top-level paragraphs and displays are the inventory units; their inline MathML and citations are losslessly attached.
  result={'scope':scope,'source_lines':n.record()['source_lines'],'blocks':blocks}
  (BASE/'phase1/extracted'/f'{scope}.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
  (BASE/'phase1/extracted'/f'{scope}.html').write_text(raw[n.start:n.end])
  out='\n\n'.join(f"[{b['id'] or b['tag']}] lines {b['source_lines']}\n{b['text']}" for b in blocks)
  (BASE/'phase1/extracted'/f'{scope}.txt').write_text(out+'\n')
  print(out+'\n')
