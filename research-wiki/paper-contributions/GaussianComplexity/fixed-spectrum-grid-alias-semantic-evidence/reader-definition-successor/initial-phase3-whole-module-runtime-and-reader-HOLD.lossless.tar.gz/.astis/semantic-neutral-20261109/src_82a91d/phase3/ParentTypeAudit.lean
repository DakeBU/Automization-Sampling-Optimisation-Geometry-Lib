import Tests.GaussianComplexityFixedSpectrumGridAlias
import Lean

open Lean Elab Command

run_cmd do
  let env ← getEnv
  let n := `AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumCosineExpansion.actual_inverse_spectrum_cosine_expansion
  let some ci := env.find? n | throwError "missing actual C7 parent"
  logInfo m!"ACTUAL_C7_PARENT_TYPE {ci.type}"

#print axioms AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumCosineExpansion.actual_inverse_spectrum_cosine_expansion
