# Phase 1 frozen source-first reconstruction

Reviewer: `/root/laplace_fresh_source_8d2a`. Role: independent source / later whole-module / later reader reviewer, not a proving worker. This file contains no verdict about a candidate formalization: no candidate type, definition, module, statement seal, decoder reconstruction, earlier audit, earlier graph, ledger, or root proof route has been supplied or read. Its mathematical reconstruction was made from the two raw inputs before any such exposure.

## Raw sources and scope

1. Joel A. Tropp, *User-Friendly Tail Bounds for Sums of Random Matrices*, author preprint, revised 15 June 2011. Supplied PDF SHA-256 `f4c3cff8661011395e793972a1f8d9a199fae4ca0fd098535d7a42166cf8fc86`. Author/PDF pages 7–10 were read as extracted text and as all four page images. Focus: §§2.1–2.4 and Proposition 3.1, including its proof continued on p.10. Nearby pp.11–13 and introductory material were also exposed in the raw text window and are recorded as source context, not candidate information.
2. *On Complexity of Gaussian Sampling*, arXiv:2610.20492v1 (14 October 2026). Supplied original HTML SHA-256 `6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915`. The complete Appendix C.2, raw anchor `A3.SS2`, including Facts C.5 and C.6 and the final proof of Lemma 4.4, was read. Original §4.1 and §4.2 supplied the grid, Krylov-space, diagonal-weight, and theorem definitions. Neighboring §4.2 statements encountered in this contextual read are outside the C.2 proof graph.

The original files are byte-copied under `inputs/`; hashes and paths are in `input_manifest.json`. The HTML reader retains each original formula's `alttext` once rather than concatenating both MathML and TeX encodings. The extracted text is auxiliary evidence, never a replacement source.

## Seven semantic slots: Tropp Proposition 3.1

**Objects.** A random finite-dimensional self-adjoint matrix Y on a probability space. Matrices are complex and square by §2.1; real symmetric matrices are a special case. The matrix dimension is fixed. The notation λ_max means the algebraically largest eigenvalue, not the operator norm. Standard maximum-eigenvalue notation presupposes positive dimension; no value on an empty spectrum is specified by the source.

**Domains.** The threshold t ranges over all real numbers. The Laplace parameter η is positive real. Scalar exp is the ordinary real exponential; exp(ηY) is the spectral matrix exponential (equivalently its matrix power series). Expectations and probabilities refer to the law of Y, with ordinary probability normalization.

**Quantifiers.** For every such Y and every real t,

    P{λ_max(Y) ≥ t} ≤ inf_{η>0} [exp(-ηt) E tr exp(ηY)].

The proof first establishes the displayed upper bound for each fixed η>0, then takes the infimum. No sign condition on t is present.

**Assumptions.** The proposition expressly assumes only that Y is a random self-adjoint matrix, subject to the source-wide regularity convention. §2.2 assumes enough regularity to justify expectations and limit interchanges, and explains that relations stated for random variables may implicitly hold almost surely. Proposition 3.1 does not require independent summands, centering, positivity of Y, bounded Y, a variance parameter, or an exponential-moment estimate. §3.1's separate introduction of formal moment/cumulant expansions begins with moments of all orders but explicitly allows the matrix mgf not to exist at all parameter values. That introductory all-moments phrase is not repeated as a Proposition 3.1 premise and does not amount to finite exponential moments at every η.

For a rigorous expectation convention, tr exp(ηY) is nonnegative. The probability inequality has its usual extended-nonnegative reading, with an infinite right side allowed; a finite-real expectation presentation must make the relevant expectation meaningful. The source's regularity prose and nonexistence warning should both remain visible. Neither a nonintegrable signed integral with an invented default value nor a silent assertion that every random matrix has finite exponential moments matches this source. This observation is about the raw source, not any candidate implementation.

**Conclusion.** A one-sided spectral-tail probability is bounded by a scalar exponential factor times the expected scalar trace of a matrix exponential. The optimized infimum and the fixed-η precursor are distinct statements; the latter is a source-proved intermediate result.

**Scopes and senses.** E tr exp(ηY) means expectation of the trace of the spectral matrix exponential. It is not exp(E tr(ηY)), exp(tr(ηY)), an entrywise exponential, a maximum entry, or tr of a totalized undefined matrix expectation. The tail uses ≥. The positivity required by Markov is supplied by scalar exp, regardless of the sign of t or eigenvalues of Y.

**Constants and dependencies.** There is no dimension factor in Proposition 3.1 itself. No numerical universal constant or independence parameter enters it. A dimension factor can arise later when bounding a trace by dimension times a largest eigenvalue, or from a separate matrix-mgf estimate. These are later proof ingredients.

## Standard source definitions and analytic meaning

- Self-adjoint means A*=A; in C.2 the matrices are real symmetric, so *=transpose.
- λ_max(A) is the largest real spectral value of A. The operator norm of a self-adjoint matrix is max of the absolute values of all eigenvalues. These are different functions.
- exp(A) is defined by functional calculus A=QΛQ*, exp(A)=Q diag(exp λ_j)Q*. Its eigenvalues are exp λ_j>0.
- tr exp(A)=Σ_j exp λ_j is a real nonnegative scalar and dominates exp(λ_max(A)). This is the spectral/trace comparison actually used in Proposition 3.1.
- Positive homogeneity of λ_max is used for positive scalar η. The scalar exponential preserves order, and exp(ηt)>0.
- A matrix square in C.2 means matrix multiplication, not an entrywise square. Matrix expectations are entrywise expectations when integrable; scalar trace-exponential expectation is a scalar probabilistic expectation. Semidefinite inequalities compare quadratic forms.
- Source regularity includes the measurability needed for random matrices, eigenvalue/trace-exponential functions, and tail events. A proof graph must discharge additional finite-integrability facts when using a finite-real expectation presentation; they are not arbitrary new theorem-shaped premises for the Gaussian consumer.

## Source proof topology for Proposition 3.1

This is the source's proof, reconstructed without implementation topology:

1. Fix η>0. Positive homogeneity changes the event to λ_max(ηY)≥ηt.
2. Scalar exponential monotonicity changes it to exp(λ_max(ηY))≥exp(ηt).
3. Scalar Markov inequality bounds that event by exp(-ηt) E exp(λ_max(ηY)).
4. Spectral mapping and positivity of exp(ηY) supply exp(λ_max(ηY))=λ_max(exp(ηY))≤tr exp(ηY).
5. Monotonicity of scalar expectation yields the fixed-η bound.
6. Since the bound holds for every η>0, infimum gives the proposition.

The proof does not use Golden–Thompson, Lieb concavity, the matrix logarithm, matrix cgf subadditivity, a Bernstein moment bound, or independent summands. Those belong to later bounds on E tr exp of sums. In particular, the source explicitly warns in §3.3 that scalar exponential multiplicativity cannot simply be reused for matrix sums.

## Gaussian C.2: objects, assumptions, and exact two matrix families

The ambient raw-source setup is d≥2, κ≥2, integer q≥0 with 2q+1<d; r=q+1 and n=2q+1. The deterministic grid is θ_i=(i-1/2)π/d, and λ_i=(κ+1)/2+(κ-1)cos(θ_i)/2. The starting vectors g_1,…,g_r are independent N(0,I_d). The row vectors γ_i=((g_1)_i,…,(g_r)_i) are independent N(0,I_r).

Set

    t_i=(1, sqrt(2)cos θ_i,…,sqrt(2)cos(qθ_i))ᵀ,
    B[i,:]=d^(-1/2)(γ_i⊗t_i)ᵀ,
    D_n=diag(cos(nθ_1),…,cos(nθ_d)).

Thus B is d×r² and both Gram matrices BᵀB and BᵀD_nB have matrix dimension D=r². Their dimension is not the number d of summands. C.5 proves range(B)=K_q, E[BᵀB]=I_D, E[BᵀD_nB]=0, ||t_i||²≤2r, Σ_i t_it_iᵀ=dI_r, and Σ_i cos(nθ_i)t_it_iᵀ=0.

The actual truncation is per row, not conditioning the whole law on a good event:

    R_i=||γ_i||²,       L=2r+3 log(1000d),
    T={R_i≤L for all i},
    Y_i=(1/d)(γ_iγ_iᵀ⊗t_it_iᵀ) 1_{R_i≤L},
    a=(1/r) E[R_i 1_{R_i≤L}],
    Z_i=Y_i-EY_i.

The deterministic scalar a is common to all rows, 0≤a≤1, and 1-a≤(L+3)/(1000rd). The identities are ΣEY_i=aI_D and Σcos(nθ_i)EY_i=0. In particular, truncating does not give ΣEY_i=I_D; the unweighted bias must be retained. Each Y_i and Z_i is a function only of its own γ_i, so independence across row index survives truncation and centering.

The two sequences to which the source applies a two-sided matrix Bernstein inequality are exactly

    X_i^(0)=Z_i,
    X_i^(1)=cos(nθ_i) Z_i.

Their common bounds are

    ||X_i^(h)||op ≤ R_* := 2r(L+1)/d,
    Σ_i E[(X_i^(h))²] ≼ v_* I_D,     v_* := 2r(r+2)/d,

with independent centered self-adjoint summands in each sequence. The weights are fixed real cosines of absolute value at most one. The weighted and unweighted sequences share the same row randomness; the proof does not need independence between the two sequences or their concentration events.

## Four signed applications of the Laplace probability bridge

The following notation merely makes explicit what a two-sided bound for each actual C.2 family requires. Let h∈{0,1}, σ∈{+1,-1}, and w_i^(0)=1, w_i^(1)=cos(nθ_i). Then the four signed sums are

    S_h=Σ_i w_i^(h)Z_i,        Q_(h,σ)=σ S_h.

All four are real symmetric D×D random matrices. For each fixed η>0, the source-proved probability bridge applies to Q_(h,σ):

    P{λ_max(Q_(h,σ))≥t}
      ≤ exp(-ηt) E tr exp(η Q_(h,σ)).

An ordinary operator-norm upper tail needs both signs. For t>0, {||S_h||op>t} is covered by the two one-sided events {λ_max(S_h)>t} and {λ_max(-S_h)>t}; their strict events are contained in the ≥ events used by Proposition 3.1. An upper-tail statement for just λ_max(S_h) cannot by itself give the claimed operator-norm bound. No independence of the two sign events is required; a union bound suffices. The factor 2 in the C.2 Bernstein prefactor is a two-sided factor, distinct from subsequently union-bounding the two families h.

Finite analytic side conditions for these actual consumers follow from source inputs rather than a new Gaussian hypothesis: truncation makes each Y_i bounded, the displayed bound makes Z_i and its deterministic signed/weighted variants bounded, and their finite sums are bounded. Continuous finite-dimensional spectral calculus therefore gives measurable bounded trace exponentials for every fixed real η, hence finite integrable scalar expectations on the probability space. These facts are internal dependencies needed to instantiate a finite-real version of the bridge. The probability bridge itself does not derive the required Bernstein mgf estimate.

## C.2 remainder and constants

C.2 derives P(T)≥0.999 by the Gaussian radial exponential moment and a row union bound. Tail integration gives the bound on 1-a. Gaussian fourth moments and the outer-product square identities give the variance bound for Z_i; deterministic squared cosine weights give the same upper bound for X_i^(1).

The external two-sided bounded matrix Bernstein theorem is used at `A3.SS2.p15` / display `A3.Ex121`, with threshold t>0, dimension D=r², norm bound R_*, and variance bound v_*. It yields, for each h,

    P{||S_h||op>t} ≤ 2r² exp(-t²/[2(v_*+R_*t/3)]).

The raw C.2 paragraph gives no bibliographic link or named theorem reference for this standard inequality. The supplied Tropp source is an independent original reference for the Laplace probability step; do not report that C.2 explicitly cites Tropp Proposition 3.1.

Set z=log(1000r²) and Δ=sqrt(2v_*z)+2R_*z/3. The source expansion gives a failure bound 0.002 per family, so simultaneous centered concentration has probability at least 0.996. On T,

    BᵀB-I_D = S_0-(1-a)I_D,
    BᵀD_nB = S_1.

Intersecting with T yields probability at least 0.995 and deviations Δ+(1-a), Δ. The deterministic simplification uses 2r≤d, d≥2, r+2≤3r and absolute logarithmic bounds to absorb Δ+(1-a) into the source τ_(d,q) after choosing one sufficiently large absolute C. This C is independent of d,q,κ and the random draw. τ≤1/2 is needed in the final Lemma 4.4 division by 1-τ, not as a premise of the intermediate C.6 concentration estimate.

Finally, range(B)=K_q and the same two matrix inequalities control all coefficient vectors c simultaneously. The source compares ||Bc||²≥(1-τ)||c||² and |cᵀBᵀD_nBc|≤τ||c||², obtains the factor 2 when τ≤1/2, and weakens probability 0.995 to 0.99. There is no coefficient-wise union bound and no need for the coefficients of u=Bc to be independent of B.

## Boundaries and unresolved source expansions

This phase has reconstructed source meaning and source topology. It has not proved any new theorem or audited a formal implementation. The standard Markov/spectral/expectation facts in Proposition 3.1 are identified dependency nodes, not missing source assumptions. The independent-sum trace-mgf estimate and two-sided bounded Bernstein theorem used by C.2 remain an external theorem dependency at this scope; Proposition 3.1 alone does not discharge it. C.2's uncited invocation should remain visible as an external source dependency, not be silently replaced by a hypothesis that its tail conclusion already holds.

There is no source-only reason to assume all Gaussian starting vectors are bounded. Their per-row truncated versions are bounded by construction, while the original Gaussian law stays unchanged. There is likewise no source-only reason to assume a one-sided spectral tail controls a two-sided operator norm without the sign step. Any later comparison must inspect these exact standard definitions and four signed actual consumers.

Status: PHASE1_SOURCE_FIRST_FROZEN. Await phase 2 formal input. No candidate fidelity / whole-module / reader / decoder verdict is issued here.
