from pathlib import Path
import gzip,hashlib,json,re,sys,tarfile
sys.dont_write_bytecode=True;sys.path.insert(0,'tools')
import astis_advance as adv
import astis_publication as pub
W=Path('.astis/huanjian-gc-fixed-spectrum-exact-means-20261110');E=Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-exact-means-semantic-evidence')
C=Path('research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-exact-means.json');L=Path('runs/substantive_advances.jsonl')
ADV='ASTIS-SA-20261110-GaussianComplexityFixedSpectrumExactMeans';OWNER='huanjian_gc_20261110_fixed_spectrum_exact_means'
sha=lambda b:hashlib.sha256(b).hexdigest();dump=lambda x:(json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode()
def ref(p):
 p=Path(p);return {'path':str(p),'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size}
def put(p,b):
 assert not p.exists(),p;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
seal=json.loads((W/'statement-seal-v1.json').read_bytes());prod=Path(seal['producer']['planned_file']);test=Path(seal['actual_private_consumer']['planned_file']);name=seal['producer']['name']
record=json.loads((E/'publication-draft-record.json').read_bytes())
assert sha(prod.read_bytes())==record['producer_raw_sha256'];assert sha(test.read_bytes())==record['Test_raw_sha256']
for p in [prod,test]:assert not re.search(r'\b(sorry|admit|axiom)\b|Prop\s*:=\s*True|:=\s*trivial\b',p.read_text())
checks=[]
for key in ['20261109T180722316257Z-exact-means-focused-native-production-build-v3','20261109T180840935500Z-exact-means-focused-native-actual-consumer-build-v1','20261109T181105677218Z-exact-means-kernel-exact-types-all-private-provider-closure-v2']:
 p=Path('.astis/huanjian-resume-20261103')/(key+'.receipt.json');d=json.loads(p.read_bytes());assert d['exit_code']==0
 checks.append({'receipt':ref(p),'raw_log_sha256':d['log_sha256'],'exit_code':0,'scope':'Focused native module/consumer or actual all-owned kernel audit; not aggregate build. Final comment header changed after native compilation; proof bodies/types unchanged and fresh independent build is required.'})
k=json.loads((W/'actual-kernel-v2-bounded-view-manifest.json').read_bytes());assert k['actual_exit_code']==0 and k['owned_reachable_true']==30 and k['owned_unreachable_elaboration_simp']==7
pub.check_advance([name],reviewed=False)
# Every raw-first graph node is either mapped to an actual implementation or explicitly unselected.
mapping={}
def group(ids,p,needle,explanation,kind='local-discharge'):
 for i in ids.split():
  assert i not in mapping
  line=next(j+1 for j,l in enumerate(p.read_text().splitlines()) if needle in l)
  mapping[i]={'file':str(p),'line':line,'provider':needle,'implementation_map':explanation,'classification':kind,'independent_postproof_review':'pending'}
c7=Path('AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumCosineExpansion.lean');grid=Path('AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumGridAlias.lean');mom=Path('AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumGaussianMoments.lean')
group('standing grid actual_objects r_def',prod,'theorem actual_diagonal_gaussian_exact_means','Unchanged sealed literal objects and exact d≥2,κ≥2,Nat1≤n<d; all source-domain guards remain public and no proof ingredient is an extra binder.','literal')
group('r_interval',prod,'have hsqrt :','hsqrt/hr0/hr1/hq prove sqrtκ>1 and0<r<1 and norm(−r)<1 internally.')
group('scalar_guards tail_geometric_guards',test,'have hscale :','hscale/hτ0/hτ1/hden/hmpos and source bounds discharge positive scalar/exponent/denominator conditions; production hD/hnD/hqD/hden cover the mean resummations as well.')
group('gap_complex_denominators c7_complex_geometric c7_rational c7_normalization c7_expansion c7_majorant c7_absolute',c7,'theorem actual_inverse_spectrum_cosine_expansion','Delegated without duplicate credit to already source-verified canonical C7, actually called in inverse_grid_alias_series. Existing producer supplies reciprocal normalization and absolute convergence; no new review of its internal source proof is claimed.','canonical-reuse')
group('c7_uniform',c7,'theorem actual_inverse_spectrum_cosine_expansion','Uniform convergence is an existing C7 output, but it is not the selected finite-exchange route in either current root. No use or new credit claimed.','unselected-alternative')
group('gap_alias_sine_denominator alias_nonmultiple alias_multiple alias_all_int',grid,'theorem actual_midpoint_grid_cosine_alias','Delegated to already source-verified canonical all-integer GridAlias; inverse_grid_alias_series actually calls it at the base and both signed frequencies. Full integer divisibility quotient semantics preserved.','canonical-reuse')
group('actual_gaussian_to_grid',mom,'theorem actual_diagonal_gaussian_quadratic_means','Canonical actual GaussianMoments supplies actual integrability and both expectation-to-grid equalities, consumed in hactual. No extra moment premise or new coordinate API is invented.','canonical-reuse')
group('gap_finite_series_exchange expanded_grid_sums',prod,'have hmajor (i :','C7 habs and cosine-weight norm≤1 produce hsgnorm/hsg; hsumG, hlin and hexchange justify the actual scalar finite-grid/tsum exchange, with hprod/hseries preserving factors. Gaussian integrals have already become finite sums.')
group('m_positive_alias_support gap_m_reindex',prod,'private theorem offset_alias_tsum','The general injective support embedding at c=D gives j=D(a+1), a≥0, exactly the source positive multiples j=Da′,a′≥1; support completeness rules out negative quotient and converts the true nonnegative integer quotient to Nat.')
group('m_tail_series m_tail_summed',prod,'private theorem unweighted_alias_tsum','Anti-periodicity changes the positive unshifted support to c=D; the convergent offset geometric series gives −q^D/(1+q^D). hs0/ht0 provide the factor2 and the separate constant A(0)=1. The source alternating-tail expression is compressed by this exact equality, not assumed as a counting premise.')
group('m_exact',prod,'have hgrid0 :=','hgrid0 at zero, ht0 and hactual.2.2.1 give the actual closed M; the final field arithmetic is guarded by hden.')
group('weighted_constant_zero',prod,'have han :','The nonmultiple guard follows from0<n<2d using Int.le_of_dvd; a(n)=0 in hgridN, with no implicit mode-zero omission.')
group('weighted_product_to_sum weighted_series',prod,'have hprod (j :','The actual product-to-sum identity evaluates both Int shifts before the finite sum and yields2G=dF. hsN is then supplied to the all-integer grid series provider.')
group('weighted_class_center weighted_class_plus gap_weighted_reindex',prod,'private theorem offset_alias_tsum','At c=n, emb(a)=Da+n−1 in Nat j+1 has a=0 giving the singleton j=n and a≥1 giving the plus family. Exhaustiveness/injectivity and sign are proved, then Function.Injective.tsum_eq and actual geometric convergence perform the sum. No separate singleton wrapper is introduced.')
group('weighted_class_minus gap_shifted_geometric_indices',prod,'private theorem plus_alias_tsum','At c=D−n the positive support is j=D(a+1)−n, a≥0. Internal Nat subtraction guards and anti-periodicity transport its alias to the actual j+n coefficient. offset_alias_tsum proves its convergent shifted geometric value; both tails have ratio−q^D.')
group('weighted_disjoint_parity',prod,'private theorem weighted_alias_summable','The actual two-support intersection would give D dividing2n, impossible from0<2n<D. This bounds |A(j−n)+A(j+n)|≤1 and is consumed by hgridN through hsN. Singleton/plus disjointness follows from injectivity and a=0 versus a≥1. hparity/hsignsq separately prove source (−1)^n parity with exact Nat exponent guards.')
group('weighted_three_class_series weighted_tails_summed',prod,'private theorem weighted_alias_tsum','The c=n series combines singleton and positive-plus classes as one exhaustive geometric series, while plus_alias_tsum evaluates the positive-minus class. Summable splitting and the two exact values produce(q^n−q^(D−n))/(1+q^D). This is an algebraically compressed source three-class route, not a new public claim that the source intermediate displays have standalone theorem constants.')
group('mu_exact',prod,'have hgridN :=','hactual weighted finite mean, hgridN/htN, han, hqD and hparity/hsignsq give the actual signed closed mean without extra hypotheses.')
group('producer_root',prod,'theorem actual_diagonal_gaussian_exact_means','Exact sealed conjunction applied by the kernel: actual integrability plus both literal closed mean equalities.')
group('m_positive_upper',test,'have hmpos :','hmpos and hmupper use the first actual mean and0≤r^(2d)<1; no variance/fourth moment ingredient.')
group('mu_signed_positive',test,'have hbpos :','hbpos uses the second actual mean, hgap/hfactor and0<r<1 with d−n>0 to give positive signed bias.')
group('gap_absolute_sign',test,'have habs :','abs_mul/abs_neg_one_pow and positive signed actual integral remove the absolute value exactly.')
group('gap_ratio_normalization ratio_exact consumer_root',test,'have hfactor :','The source exponent identity n+2(d−n)=2d−n is guarded by n<d. Actual positive m, scale and denominators justify field_simp after both closed mean outputs are used, proving the exact literal private consumer.')
gp=W/'independent-source-graph/phase2/source-proof-graph-v1.json';g=json.loads(gp.read_bytes());assert set(mapping)=={n['id'] for n in g['nodes']}
put(E/'source-to-lean-map-v1.json',dump({'source_graph':ref(gp),'seal':ref(W/'statement-seal-v1.json'),'nodes':mapping,'no_extra_public_binders':True,'canonical_nodes_shared':True,'source_graph_not_compiled_graph':True,'not_independent_verdict':True,'scope':seal['truth_boundary']}))
mirror={'status':'none-found','discovery_ids':[],'reason':'Exact reindexing uses canonical Mathlib injective-support and geometric-series facts. New actual C8 composition reuses the SAME GaussianMoments/C7/GridAlias nodes. The previously validated midpoint/Lobatto conceptual cancellation mirror remains unchanged and gains no closed-mean or Gaussian transport certificate. No additional cross-domain hypothesis/key-estimate/conclusion map with a new source-backed failure boundary is established.','same_compiled_declaration_policy':'One new public exact actual means node; all private helper/consumer declarations are implementation only and have real root uses, not Registry nodes. Existing conceptual bridges stay dashed.'}
put(E/'postproof-conceptual-mirror-audit.json',dump(mirror))
failures={'classification':'implementation/API-tooling; mathematical target retained unchanged','failed_routes':[
 {'receipt_glob':'*-exact-means-scalar-support-and-offset-geometric-v1.receipt.json','diagnosis':'Missing noncomputable context and cast-normalization mismatch in simp; replaced by explicit zero-alias witness before multiplication.'},
 {'receipt_glob':'*-exact-means-actual-three-alias-tail-providers-v2.receipt.json','diagnosis':'Extra parenthesis and unsuccessful convert/ring on divisibility; corrected syntax and explicit Int difference equality.'},
 {'receipt_glob':'*-exact-means-sealed-full-Gaussian-closed-means-v1.receipt.json','diagnosis':'dsimp made no progress on already expanded numerator; removed the vacuous tactic, kept exact signature.'},
 {'receipt_glob':'*-exact-means-kernel-exact-types-all-private-provider-closure-v1.receipt.json','diagnosis':'Tooling-only Lean pipeline/comparison precedence; added parentheses.'}],
 'successful_but_oversized_tooling':{'receipt':checks[-1]['receipt'],'actual_exit_code':0,'raw_log_bytes':k['original_raw_log_bytes'],'raw_sha256':k['original_raw_log_sha256'],'diagnosis':'Printing all complete Expr reprs produced a 2.29GB raw log; no mathematical or kernel failure. It actually finished in57.6s before an attempted interrupt was delivered. Original raw log retained privately; bounded lossy projection and its explicit omission manifest are public. Future independent check uses identical logic without unbounded pretty-printing.'},
 'salvage':'All completed private support/geometric providers are materially used by the public theorem; all source/compiled statements unchanged. No route retired as false, no source premise added, no unchanged retry.'}
put(E/'retained-failures-and-tooling-diagnosis.json',dump(failures))
for f in ['actual-kernel-v2-bounded-lossy-view.txt','actual-kernel-v2-bounded-view-manifest.json','KernelExactTypesAndAllPrivateProvidersBounded.lean']:
 put(E/f,(W/f).read_bytes())
# Preserve selected source graph/topology/proof tools and failures; private baselines/foreign ledgers and giant log are excluded explicitly.
payload=[]
for folder in [W/'independent-source-graph',W/'independent-topology-challenge']:
 payload.extend(p for p in sorted(folder.rglob('*')) if p.is_file() and '__pycache__' not in p.parts)
allow={'producer-signature.txt','consumer-signature.txt','statement-seal-v1.json','StatementFormation.lean.gz','multivariateGaussian-standard-definition.txt','root-preproof-admission-grant.json','ApiTypes.lean','ScalarHelpersV1.lean','ScalarHelpersV2.lean'}
payload.extend(p for p in sorted(W.iterdir()) if p.is_file() and (p.name in allow or p.suffix=='.py' or p.name.startswith('retained-')))
assert all(not re.search(rb'wxid_[a-z0-9]{8,}',p.read_bytes()) for p in payload)
archive=E/'local-proof-source-graph-tools-and-retained-failures.lossless.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz') as t:
 for p in payload:t.add(p,arcname=str(p),recursive=False)
with tarfile.open(archive,'r:gz') as t:
 for p in payload:assert t.extractfile(str(p)).read()==p.read_bytes()
put(E/'local-proof-archive-manifest.json',dump({'archive':ref(archive),'files':[ref(p) for p in payload],'scope':'Lossless SELECTED source/admission/proof-tools/failure payloads. Full private baseline/foreign ledgers and oversized raw Expr log are excluded; public bounded view is explicitly lossy. No independent fidelity or publication acceptance.'}))
actual=[]
for p in sorted(Path('.astis/huanjian-resume-20261103').glob('*-exact-means-*.receipt.json')):
 d=json.loads(p.read_bytes());log=Path(d['log']);put(E/'actual-local-checks'/p.name,p.read_bytes())
 row={'receipt':ref(E/'actual-local-checks'/p.name),'actual_exit_code':d['exit_code'],'raw_log_sha256':d['log_sha256']}
 if log.stat().st_size<10_000_000:
  b=log.read_bytes();assert sha(b)==d['log_sha256'];q=E/'actual-local-checks'/(log.name+'.gz');put(q,gzip.compress(b,mtime=0));row['lossless_log']=ref(q)
 else:row['raw_log_kept_privately_bounded_projection']=str(E/'actual-kernel-v2-bounded-view-manifest.json')
 actual.append(row)
put(E/'actual-local-checks-manifest.json',dump({'actual_checks':actual,'scope':'Individual real receipts including retained failures; huge successful log explicitly projected, not falsely called lossless. No aggregate/site/browser/sourceV credit.'}))
baseline=json.loads((W/'preproof-baseline.json').read_bytes())
for p,h in baseline['all_frontier_hashes'].items():assert sha(Path(p).read_bytes())==h,p
for p,h in baseline['protected_shared_hashes'].items():assert sha(Path(p).read_bytes())==h,p
put(E/'compact-preproof-environment-and-preservation.json',dump({k:baseline[k] for k in ['observed_utc','working_HEAD','Lean_actual','manifest','packages','ledger','protected_shared_hashes'] if k in baseline}))
before=L.read_bytes();states=adv._replay_advances([json.loads(x) for x in before.splitlines()]);assert states[ADV]['state']=='EXPLORING' and states[ADV]['owner_id']==OWNER
cellraw=C.read_bytes();cell=json.loads(cellraw)
boundary='Actual closed C8 Gaussian norm/Q integrability and both exact means, with a real actual-integral normalized-bias/sign/mean-upper consumer, compile locally. Exact original signatures and every private provider/def/generated auxiliary were kernel-inspected; standard3axioms only. Independent source-only comparison/whole-module/fresh native/static reader/sourceV pending. No latest-main/shared/site/browser/remote/purification/wholeGoal acceptance. Fourth moments/independence/variances, exponential bias bounds, rotated/Krylov/adaptive laws, both main bounds and real oracle/TV/precision/deterministic-cap/expected-cost adapters remain open.'
ma={'status':'none-found','discovery_ids':[],'evidence':str(E/'postproof-conceptual-mirror-audit.json')}
evidence={'result_kind':'theorem-edge','theorem_delta':cell['target_statement'],'lean_files':[str(prod),str(test)],'lean_declarations':[name],'publication_declarations':[name],'focused_checks':checks,'truth_boundary':boundary,'conceptual_mirror_audit':ma,'actual_consumer':'The sealed literal actual Gaussian norm/Q integrals are used. Both new closed means materially produce m>0,m≤d/sqrtκ,signed b>0 and exact |b|/m ratio; no free m/b, positivity, variance, denominator or asymptotic premise.','source_VERIFIED_or_integration':False}
adv.transition_advance(ADV,'PROVED_LOCAL',worker_id=OWNER,evidence=evidence)
after=L.read_bytes();assert after.startswith(before);append=after[len(before):];assert len(append.splitlines())==1
new=adv._replay_advances([json.loads(x) for x in after.splitlines()]);assert new[ADV]['state']=='PROVED_LOCAL';assert {k:v for k,v in states.items() if k!=ADV}=={k:v for k,v in new.items() if k!=ADV}
put(E/'frontier-before-PROVED_LOCAL.raw.json.gz',gzip.compress(cellraw,mtime=0));put(E/'actual-PROVED_LOCAL-append.exact.jsonl',append)
capsule={'state':'PROVED_LOCAL_NOT_SOURCE_VERIFIED','advance_id':ADV,'owner':OWNER,'actual_normal_PROVED_LOCAL_API_calls':1,'append_sha256':sha(append),'foreign_SAU_states_preserved':len(states)-1,'producer':{**ref(prod),'declaration':name,'actual_public_ASTIS_parents':record['actual_public_ASTIS_producer_parents']},'private_consumer':{**ref(test),'actual_public_ASTIS_parents':[name],'Registry_node':False},'actual_checks':checks,'exact_literal_signatures_kernel_applied':True,'all_owned_kernel_declarations':37,'all_handwritten_private_providers_reachable':True,'elaboration_only_unreachable_simp_auxiliaries':7,'recursive_kernel_axioms':['propext','Classical.choice','Quot.sound'],'bounded_actual_kernel_log':ref(E/'actual-kernel-v2-bounded-view-manifest.json'),'source_to_lean_map':ref(E/'source-to-lean-map-v1.json'),'conceptual_mirror_audit':ma,'authored_fake_closure_scan':{'files':[str(prod),str(test)],'hits':0},'truth_boundary':boundary,'source_VERIFIED_or_integration_or_purification_or_Goal':False}
put(E/'local-proof-capsule.json',dump(capsule))
cell['status']='proved_locally';cell['evidence'].update({'execution_boundary':boundary,'focused_checks':[x['receipt']['path'] for x in checks],'local_proof_capsule':str(E/'local-proof-capsule.json'),'actual_compiled_public_ASTIS_producer_parents':record['actual_public_ASTIS_producer_parents'],'actual_compiled_public_ASTIS_consumer_parents':[name],'publication_binding_sha256':record['publication_binding_sha256']})
cell['statement_seal']['status']='EXACT_ORIGINAL_SIGNATURES_COMPILED_LOCAL_INDEPENDENT_WHOLE_MODULE_REVIEW_PENDING';cell['source_proof_coverage'].update({'preproof_internal_obligation_list_is_preserved_phase_history':True,'source_to_lean_map':ref(E/'source-to-lean-map-v1.json'),'current_compiled_scope':{'producer':'Both actual closed C8 means and integrability','consumer':'Actual positive/upper mean, signed bias positivity and exact normalized absolute ratio','source_VERIFIED':False}})
cell['reuse_plan']['known_consumers']=['Actual compiled private actual_gaussian_closed_means_bias_ratio materially consumes BOTH new actual closed means.'];cell['reuse_plan']['planned_consumers']=['Variance and exponential bias bounds for full Lemma4.5 remain open.'];cell['conceptual_mirror_audit']=ma
cell['source_detail_audit']['gap']='Selected closed C8 means and exact normalized-bias actual-integral consumer locally discharged. Independent whole-module/native/source/sourceV pending. Variances, further bias bounds and broader laws remain outside.';cell['source_detail_audit']['fidelity_boundary']=boundary
cell['learning_contract']['failure_class']='IMPLEMENTATION';cell['learning_contract']['salvage'].update({'required':True,'status':'promoted-fragments','reason':'Retained scalar/cast/tactic/kernel-tooling failures were repaired with unchanged statements; all completed private providers used. Successful unbounded Expr logging retained with bounded projection.','promoted_fragments':['Actual private support/reindex/geometric providers, all kernel-reachable from target'],'discarded_fragments':[]})
C.write_bytes(dump(cell))
print(json.dumps({'state':'PROVED_LOCAL','append_sha256':sha(append),'producer':ref(prod),'consumer':ref(test),'source_VERIFIED':False,'archive_sha256':sha(archive.read_bytes())}))
