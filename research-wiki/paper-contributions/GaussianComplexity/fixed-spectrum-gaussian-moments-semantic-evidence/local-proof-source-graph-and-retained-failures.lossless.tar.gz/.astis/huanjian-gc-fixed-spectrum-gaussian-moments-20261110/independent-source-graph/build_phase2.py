from pathlib import Path
import json, hashlib, datetime, runpy

B = Path(__file__).resolve().parent
P2 = B / 'phase2'
P2.mkdir(exist_ok=True)
source = runpy.run_path(str(B / 'extract_raw.py'))
dom = source['p']
raw_inventory = json.loads((B / 'phase1/raw-inventory.json').read_text())['items']
standing = json.loads((B / 'phase1/extracted/standing-items.json').read_text())
seal_path = P2 / 'inputs/statement-seal-v2.json'
seal = json.loads(seal_path.read_text())
SEAL_SHA = hashlib.sha256(seal_path.read_bytes()).hexdigest()
RAW_SHA = '6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'

def write(name, obj):
    (P2 / name).write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n')

nodes = []
def node(id, kind, anchors, claim, **extra):
    nodes.append(dict(id=id, kind=kind, source_anchors=anchors, claim=claim,
                      formal_status='NOT_INSPECTED_OR_CERTIFIED_BY_EXTRACTOR', **extra))

node('src:euclidean-convention', 'source-definition', ['S2.p1.1'],
     'The norm is the real Euclidean norm; I_d is the identity and Loewner order is positive-semidefinite order.')
node('src:precision-target-convention', 'source-definition', ['S2.SS0.SSS0.Px1.p1.1','S2.Ex1','S2.SS0.SSS0.Px1.p1.2'],
     'A real symmetric precision A with I<=A<=kappa I has target pi_A=N(0,A^-1); covariance is inverse precision.')
node('src:family-domain', 'standing-assumptions', ['S4.SS1.p1.1'], 'd>=2 and kappa>=2.')
node('src:hard-spectrum', 'source-definition', ['S4.E11'],
     'For i=1,...,d: theta_i=(i-1/2)pi/d; lambda_i=(kappa+1)/2+(kappa-1)cos(theta_i)/2; Lambda=diag(lambda_i).')
node('src:rotated-target-context', 'source-definition-context', ['S4.SS1.p1.2'],
     'O is Haar orthogonal, independent of algorithm randomness; A=O Lambda O^T, f_A=x^T A x/2, pi_A=N(0,A^-1).',
     use_in_bounded_root='Only the precision/covariance convention; no Haar law or transport proof used.')
node('src:known-spectrum-context', 'substantive-context', ['S4.SS1.p2.1'],
     'Spectrum is deterministic and may be supplied; normalizer known; hidden object is eigenbasis.',
     use_in_bounded_root='Context only; no implication edge into Gaussian moments.')
node('src:external-prior-construction', 'external-citation-context', ['S4.SS1.p1.1','bib.bib3'],
     '[22], OpenAI (2026), Subpolynomial query complexity for well-conditioned log-concave sampling; construction comparison.',
     external_content_read=False, use_in_bounded_root='No external theorem dependency; Appendix C.3 supplies the present computations.')
node('src:target-moment-definitions', 'source-definition', ['S4.Thmtheorem5.p1.1'],
     'U~N(0,Lambda^-1), rho=(sqrt(kappa)-1)/(sqrt(kappa)+1), integer 1<=n<d, D_n=diag(cos(n theta_i)), M=E||U||^2, mu_n=E[U^T D_n U].')
node('src:appendix-roadmap', 'substantive-proof-paragraph', ['A3.SS3.p1.1'],
     'Author first expands inverse spectrum and sums over grid, then treats variance and normalized bias.',
     use_in_bounded_root='Ordering evidence, not an extra proof hypothesis.')
node('src:rho-geometric-route', 'substantive-proof-paragraph', ['A3.SS3.p2.1'],
     '0<rho<1 permits geometric-series evaluation.')
node('src:poisson-geometric-identity', 'reused-display', ['A3.EGx14'],
     '1+2 sum_{j>=1}(-rho)^j cos(j theta) = 1-rho e^{i theta}/(1+rho e^{i theta})-rho e^{-i theta}/(1+rho e^{-i theta}) = (1-rho^2)/(1+2rho cos theta+rho^2).')
node('src:rho-normalization', 'reused-display-and-proof', ['A3.SS3.p2.2','A3.Ex136'],
     '(1-rho)/(1+rho)=1/sqrt(kappa), and [1+2rho cos theta+rho^2]/(1-rho)^2 = [kappa+1+(kappa-1)cos theta]/2.')
node('src:expansion-proof-composition', 'substantive-proof-paragraph', ['A3.SS3.p2.3'],
     'Compose geometric fraction and rho-normalization identities to prove inverse-spectrum expansion.')
node('src:inverse-spectrum-expansion', 'source-theorem-and-display', ['A3.Thmtheorem7','A3.Thmtheorem7.p1.1','A3.Ex133'],
     'For every real theta, 2/[kappa+1+(kappa-1)cos theta] = (1/sqrt(kappa)) [1+2 sum_{j>=1}(-rho)^j cos(j theta)].')
node('src:expansion-convergence', 'source-assertion-and-unnamed-estimate', ['A3.Thmtheorem7.p1.2','A3.Ex137','A3.SS3.p2.4'],
     'sum_{j>=1}|(-rho)^j cos(j theta)| <= sum_{j>=1}rho^j = rho/(1-rho), so convergence is absolute and uniform in theta.')
node('src:finite-grid-proof', 'substantive-proof-paragraph', ['A3.SS3.p3.1','A3.SS3.p3.2'],
     'For integer k not divisible by 2d, sin(k pi)/(2 sin(k pi/(2d)))=0; if k=2ad, each cosine is (-1)^a.')
node('src:finite-grid-orthogonality', 'reused-display', ['A3.Ex139'],
     'For all integer k, sum_i cos(k theta_i)=d(-1)^a when k=2ad (a integer), otherwise zero; k=0 lies in alias branch.')
node('src:gaussian-coordinate-second-moment', 'source-unnamed-moment-assertion', ['A3.SS3.p4.1'],
     'For the actual centered Gaussian with covariance Lambda^-1, E U_i^2 = 1/lambda_i.')
node('src:means-to-grid', 'reused-display', ['A3.Ex140'],
     'M=sum_i 1/lambda_i, and mu_n=sum_i cos(n theta_i)/lambda_i.')
node('src:finite-grid-series-interchange', 'substantive-proof-paragraph', ['A3.SS3.p4.2'],
     'Fact C.7 allows interchange of an absolutely convergent scalar series and the finite grid sum; expectation was already removed in Ex140.')
node('src:weighted-product-to-sum', 'substantive-proof-paragraph', ['A3.SS3.p6.1'],
     'sum_i cos(n theta_i)=0; use 2cos(n theta_i)cos(j theta_i)=cos((j-n)theta_i)+cos((j+n)theta_i).')
node('src:weighted-alias-series', 'reused-display', ['A3.Ex144'],
     'mu_n=(1/sqrt(kappa)) sum_{j>=1}(-rho)^j [sum_i cos((j-n)theta_i)+sum_i cos((j+n)theta_i)], before resummation.')
node('src:gaussian-marginal-law-and-open-variance-route', 'source-proof-paragraph-with-delimited-subclaims', ['A3.SS3.p8.1'],
     'Source says each U_i is centered Gaussian of variance 1/lambda_i; it also proceeds to independence, fourth moments, and variances.',
     bounded_subclaim='Only centered marginal/variance semantic assertion corroborates p4.1.',
     open_subclaims=['coordinate independence','E U_i^4=3/lambda_i^2','Var(U_i^2)=2/lambda_i^2','variance bounds'])

# Named source omissions remain visible, and carry no assertion that an API or proof exists.
node('gap:spectral-admissibility', 'SOURCE_GAP', ['S4.E11','A3.SS3.p8.1'],
     'Derive 1<=lambda_i<=kappa, strict positivity, diagonal Lambda positive definite/invertible from source parameters and |cos|<=1.',
     omitted_bridge='Source prints lower bound later in variance paragraph but not a construction proof before U-law.')
node('gap:inverse-diagonal', 'SOURCE_GAP', ['S4.E11','A3.SS3.p4.1'],
     'Lambda^-1=diag(lambda_i^-1); it is a positive definite real symmetric covariance on the same coordinate carrier.')
node('gap:actual-law-identification', 'SOURCE_GAP', ['S4.Thmtheorem5.p1.1','A3.SS3.p4.1'],
     'Identify the literal multivariateGaussian 0 Lambda^-1 with actual N(0,Lambda^-1) on the positive-definite domain; totalized matrix/CFC behavior outside that domain proves nothing here.',
     definition_projection='Exact sealed standard definition is stdGaussian.map (fun x => 0 + toEuclideanCLM(CFC.sqrt(Lambda^-1)) x).',
     proof_route_status='No Gaussian moment API or implementation inspected.')
node('gap:gaussian-second-order-analysis', 'SOURCE_GAP', ['A3.SS3.p4.1','A3.SS3.p8.1'],
     'Under this actual Gaussian law, coordinates have finite second moments, zero means, and centered product moments E[U_i U_j]=(Lambda^-1)_ij. Coordinate products and squares are integrable.',
     alternatives='Direct actual Gaussian second-moment characterization OR affine standard-Gaussian moment transport; not simultaneous prerequisites and no chosen API.')
node('gap:coordinate-second-moment', 'SOURCE_GAP', ['A3.SS3.p4.1'],
     'Specialize actual Gaussian second-order law to i=i, or use centered variance identity with E U_i=0, to obtain E U_i^2=lambda_i^-1.',
     alternatives='Direct second-moment specialization OR centered variance identity; two sufficient completions of an omitted source bridge.')
node('gap:norm-quadratic-coordinate-identities', 'SOURCE_GAP', ['S2.p1.1','S4.Thmtheorem5.p1.1','A3.Ex140'],
     'Pointwise Euclidean ||x||^2=sum_i x_i^2 and x^T D_n x=sum_i cos(n theta_i)x_i^2; reconcile source one-based grid with Fin d using i_source=i.val+1.')
node('gap:gaussian-quadratic-integrability', 'SOURCE_GAP', ['A3.Ex140'],
     'Finite sums of integrable coordinate squares, with fixed real cosine weights, produce integrable actual norm-square and diagonal quadratic Q. No free integrability premise.')
node('gap:finite-expectation-linearity', 'SOURCE_GAP', ['A3.SS3.p4.1','A3.Ex140'],
     'Use termwise integrability and pointwise finite identities to exchange actual probability integral and finite sum, then constants and E U_i^2=lambda_i^-1. Distinct from finite/tsum interchange.')
node('gap:weighted-c7-series', 'SOURCE_GAP', ['A3.Ex133','A3.Ex137','A3.SS3.p4.2'],
     'At each literal grid point, the C7 series is absolutely summable; multiply by fixed cos(n theta_i) and scalar 1/sqrt(kappa). |cos|<=1 and 0<rho<1 discharge weighted summability.')
node('gap:finite-grid-tsum-exchange', 'SOURCE_GAP', ['A3.SS3.p4.2','A3.SS3.p6.1','A3.Ex144'],
     'Exchange finite i-sum with scalar infinite j-series using weighted absolute convergence; distribute sums/scalars and use product-to-sum. This is after Ex140, with no expectation/infinite-series exchange.')
node('gap:normalized-integer-alias', 'SOURCE_GAP', ['A3.Ex139','A3.SS3.p6.1','A3.Ex144'],
     'Define a(k)=if (2d)|k then (-1)^(k/(2d)) else 0 for all k in Z, so sum_i cos(k theta_i)=d*a(k). For 1<=n<d, (2d) does not divide n and constant grid sum vanishes.',
     signed_frequency_obligation='j-n may be negative; cast positive source j and n to Int before subtraction. Keep k=0 in alias branch and use integer division only in the divisible branch.')
node('gap:alias-series-summability', 'SOURCE_GAP', ['A3.Ex137','A3.SS3.p4.2','A3.Ex144'],
     '|a(k)|<=1 for all signed integer k, so |(-rho)^j(a(j-n)+a(j+n))|<=2rho^j for j>=1; geometric summability yields supported-series Summable as an output.')
node('gap:positive-mode-series-indexing', 'SOURCE_GAP', ['A3.Ex144'],
     'Source j>=1 corresponds to Nat index j+1; shifts are Int(j+1)-Int(n) and Int(j+1)+Int(n). Pull d out of the inner alias sums, converting 1/sqrt(kappa) to d/sqrt(kappa), without resumming any alias class.')
node('root:producer', 'sealed-root-projection', ['A3.SS3.p4.1','A3.Ex140'],
     'Exact sealed actual_diagonal_gaussian_quadratic_means: actual norm/Q integrability and the two finite reciprocal-eigenvalue expectation formulas.',
     signature_sha256=seal['producer']['signature_sha256'], definition_kind='literal')
node('root:private-consumer', 'sealed-root-projection', ['A3.SS3.p4.2','A3.SS3.p6.1','A3.Ex144'],
     'Exact sealed actual_gaussian_cosine_alias_series: supported scalar series Summable, actual Q integrability, and actual Gaussian integral equal to (d/sqrt(kappa))*tsum supported coefficients.',
     signature_sha256=seal['actual_private_consumer']['signature_sha256'], definition_kind='literal')

conditions = {}
def condition(id, required, discharge, anchors, provider):
    conditions[id] = dict(required=required, source_mathematical_discharge=discharge,
                          anchors=anchors, proposed_provider=provider,
                          formal_discharge_status='NOT_INSPECTED; required internal dependency, not a new public binder')
condition('C-d', 'Finite d, d>=2, d>0, cast d nonzero', 'hd:2<=d gives d>=1 and positive real/integer casts; Fin d is finite.', ['S4.SS1.p1.1'], 'src:family-domain')
condition('C-kappa', 'kappa>=2, kappa>0, sqrt(kappa)>1 and sqrt(kappa) nonzero', 'h_kappa implies all square-root and denominator positivity claims.', ['S4.SS1.p1.1','S4.Thmtheorem5.p1.1'], 'src:family-domain')
condition('C-n', 'Integer 1<=n<d', 'hn/hnd are the exact source mode range; Nat n embeds injectively as a positive Int. No oddness/q/bias-gap premise.', ['S4.Thmtheorem5.p1.1'], 'src:target-moment-definitions')
condition('C-index', 'Literal grid coordinate agreement', 'Source i in 1..d corresponds to Fin i.val+1; ((i.val+1)-1/2)pi/d=(i.val+1/2)pi/d.', ['S4.E11'], 'src:hard-spectrum')
condition('C-eigen', '1<=lambda_i<=kappa; positive-definite Lambda', 'kappa-1>=0 and -1<=cos(theta_i)<=1 imply scalar bounds; diagonal positive entries give SPD/invertibility.', ['S4.E11','A3.SS3.p8.1'], 'gap:spectral-admissibility')
condition('C-inverse', 'Inverse covariance is diagonal with entries lambda_i^-1 and positive definite', 'All lambda_i>0, so diagonal inverse identity and positive reciprocals apply; symmetry retained.', ['S4.E11','A3.SS3.p4.1'], 'gap:inverse-diagonal')
condition('C-law', 'The fixed mu really is centered Gaussian with covariance Lambda^-1', 'Sealed standard affine-map definition plus SPD covariance identifies its intended N(0,Lambda^-1) law; must be established internally.', ['S4.Thmtheorem5.p1.1'], 'gap:actual-law-identification')
condition('C-L2', 'Coordinate squares/products integrable and zero mean/inverse covariance exact', 'Actual Gaussian second-order moments on finite-dimensional Euclidean space; mean zero comes from the actual zero-mean law, not postulation.', ['A3.SS3.p4.1','A3.SS3.p8.1'], 'gap:gaussian-second-order-analysis')
condition('C-second', 'E U_i^2=lambda_i^-1', 'Specialize actual second moment/covariance to i=i with zero mean; diagonal inverse entry is lambda_i^-1.', ['A3.SS3.p4.1'], 'gap:coordinate-second-moment')
condition('C-coordinate', 'Pointwise norm/diagonal quadratic equal the stated finite coordinate sums', 'Euclidean norm square and diagonal matrix multiplication give literal pointwise identities on EuclideanSpace, with WithLp coordinates.', ['S2.p1.1','S4.Thmtheorem5.p1.1'], 'gap:norm-quadratic-coordinate-identities')
condition('C-integrable', 'Actual norm-square, Q and every finite summand integrable', 'Finite summation and fixed real scalar multiplication preserve coordinate-square integrability; no bound on n needed.', ['A3.Ex140'], 'gap:gaussian-quadratic-integrability')
condition('C-finite-expect', 'Integral/finite-sum and scalar exchanges valid', 'Apply finite integral linearity only after termwise integrability; substitute C-second and pointwise identities.', ['A3.SS3.p4.1','A3.Ex140'], 'gap:finite-expectation-linearity')
condition('C-rho', '0<rho<1; 1+-rho and geometric denominators nonzero', 'sqrt(kappa)>1 and rho=(sqrt(kappa)-1)/(sqrt(kappa)+1) give strict interval; |rho e^(+-i theta)|=rho<1.', ['A3.SS3.p2.1','S4.Thmtheorem5.p1.1'], 'src:rho-geometric-route')
condition('C-normalization', 'Scalar C7 fraction matches reciprocal literal eigenvalue', 'Use both Ex136 identities and positive sqrt(kappa), lambda_i, 1-rho; denominator kappa+1+(kappa-1)cos(theta_i)=2lambda_i.', ['A3.Ex136','S4.E11'], 'src:rho-normalization')
condition('C-geometric', 'Absolute geometric series converges uniformly in theta', '|cos(j theta)|<=1 and 0<rho<1 give bound sum rho^j=rho/(1-rho).', ['A3.Ex137'], 'src:expansion-convergence')
condition('C-C7', 'Expansion at each exact real grid theta_i', 'Fact C.7 is universal in real theta, so specialize literal theta_i and use reciprocal normalization.', ['A3.Thmtheorem7.p1.1','A3.Ex133'], 'src:inverse-spectrum-expansion')
condition('C-weight', 'Each weighted grid series summable', '|cos(n theta_i)|<=1 for all real angles; multiply C7 absolute summability by fixed scalar.', ['A3.Ex137','A3.SS3.p4.2'], 'gap:weighted-c7-series')
condition('C-finite-tsum', 'Finite grid and scalar series interchange valid', 'Fin d finite and each weighted j-series summable; exchange sums and distribute fixed constants. This does not exchange expectation and infinite series.', ['A3.SS3.p4.2'], 'gap:finite-grid-tsum-exchange')
condition('C-grid-sine', 'Finite cosine-sum formula handles zero and nonzero denominators separately', 'If 2d does not divide k, sin(kpi/(2d))!=0 and sin(kpi)=0; if 2d divides k, write k=2ad, including a=0.', ['A3.SS3.p3.2'], 'src:finite-grid-proof')
condition('C-integer-k', 'k is an arbitrary signed integer', 'The source paragraph quantifies every integer k; k may be negative or zero, and d>0 is already standing.', ['A3.SS3.p3.1'], 'src:finite-grid-proof')
condition('C-allint', 'Grid alias holds for every signed integer frequency', 'Ex139 quantifies k in Z; evenness handles negative angle while alias sign uses integer exponent. No Nat truncation of subtraction.', ['A3.Ex139'], 'src:finite-grid-orthogonality')
condition('C-zero-mode', 'sum_i cos(n theta_i)=0', '0<n<d<2d rules out (2d)|n; apply Ex139 nonalias branch at k=n. The shifted k=0 branch remains allowed.', ['A3.SS3.p6.1','A3.Ex139'], 'gap:normalized-integer-alias')
condition('C-product', 'Weighted cosine product-to-sum identity', '2cos(n theta_i)cos(j theta_i)=cos((j-n)theta_i)+cos((j+n)theta_i), all real angles; cancels the factor 2 from C7.', ['A3.SS3.p6.1'], 'src:weighted-product-to-sum')
condition('C-alias', 'Normalized guarded a(k) matches Ex139', 'd>0; in divisible branch integer k/(2d) is exact quotient a, otherwise both expressions zero; sum_i cos(k theta_i)=d*a(k).', ['A3.Ex139','A3.Ex144'], 'gap:normalized-integer-alias')
condition('C-alias-bound', 'Supported series summable, not merely formal tsum', '|a(k)|<=1 for all signed k because nonzero branches are integer powers of -1; sum of two absolute coefficients <=2; dominate by 2rho^(j+1).', ['A3.Ex137','A3.Ex144'], 'gap:alias-series-summability')
condition('C-positive-j', 'Positive source j and signed shifts preserved', 'Reindex j>=1 by Nat index j+1; coerce to Int before subtracting n; pull finite dimension factor d out of aliases.', ['A3.Ex144'], 'gap:positive-mode-series-indexing')

edges = []
def edge(id, parents, target, uses, mechanism, cs=(), role='mathematical-AND', **extra):
    edges.append(dict(id=id, prerequisites=parents, target=target, edge_semantics=role,
                      consumer_use_sites=uses, mechanism=mechanism,
                      conditional_discharge=[dict(id=c, **conditions[c]) for c in cs],
                      formal_dependency_evidence='NONE; source proposal only', **extra))

edge('E01',['src:family-domain','src:hard-spectrum'],'gap:spectral-admissibility',
     ['S4.Thmtheorem5.p1.1','A3.SS3.p4.1'], 'Ensure the precision and inverse covariance are nondegenerate from literal source inputs.', ['C-d','C-kappa','C-eigen'])
edge('E02',['gap:spectral-admissibility','src:hard-spectrum'],'gap:inverse-diagonal',
     ['A3.SS3.p4.1'], 'Diagonal matrix inverse with nonzero positive entries.', ['C-eigen','C-inverse'])
edge('E03',['src:precision-target-convention','src:target-moment-definitions','gap:inverse-diagonal'],'gap:actual-law-identification',
     ['S4.Thmtheorem5.p1.1','A3.SS3.p4.1'], 'Interpret exact sealed affine Gaussian constructor on SPD domain as actual centered inverse-precision law.', ['C-inverse','C-law'])
edge('E04',['gap:actual-law-identification'],'gap:gaussian-second-order-analysis',
     ['A3.SS3.p4.1','A3.SS3.p8.1'], 'Actual Gaussian law provides finite second moments, mean zero, and covariance, rather than assuming a law predicate.', ['C-law','C-L2'])
edge('E05',['gap:gaussian-second-order-analysis','gap:inverse-diagonal'],'gap:coordinate-second-moment',
     ['A3.SS3.p4.1'], 'Omitted second-moment specialization, with centeredness if covariance identity is used.', ['C-L2','C-inverse','C-second'],
     route_note='Source does not specify a proof. Direct second-moment specialization OR zero-mean covariance identity are alternatives inside this single SOURCE_GAP; neither is asserted to be the author tactic.')
edge('E06',['gap:coordinate-second-moment'],'src:gaussian-coordinate-second-moment',
     ['A3.SS3.p4.1','A3.Ex140'], 'Fill omitted Gaussian statement used by author.', ['C-second'])
edge('E07',['src:family-domain','src:euclidean-convention','src:hard-spectrum','src:target-moment-definitions'],'gap:norm-quadratic-coordinate-identities',
     ['A3.Ex140'], 'Euclidean norm square and diagonal quadratic literal identities; coordinate indexing adapter.', ['C-d','C-index','C-coordinate'])
edge('E08',['gap:gaussian-second-order-analysis','gap:norm-quadratic-coordinate-identities'],'gap:gaussian-quadratic-integrability',
     ['A3.Ex140'], 'Finite sum of integrable squares and real weighted squares.', ['C-d','C-L2','C-coordinate','C-integrable'])
edge('E09',['src:gaussian-coordinate-second-moment','gap:gaussian-quadratic-integrability','gap:norm-quadratic-coordinate-identities'],'gap:finite-expectation-linearity',
     ['A3.Ex140'], 'Exchange finite sum and actual integral after proving integrability, then evaluate each term.', ['C-coordinate','C-integrable','C-second','C-finite-expect'])
edge('E10',['gap:finite-expectation-linearity'],'src:means-to-grid',
     ['A3.Ex140'], 'Both expectation-to-grid identities including fixed cosine weights.', ['C-finite-expect'])
edge('E11',['src:means-to-grid','gap:gaussian-quadratic-integrability'],'root:producer',
     ['A3.SS3.p4.1','A3.Ex140'], 'Project exact four-conjunct producer with literal theta/eigenvalue/Lambda/mu/Q definitions.', ['C-d','C-kappa','C-n','C-index','C-law','C-integrable','C-finite-expect'])

edge('E12',['src:family-domain','src:target-moment-definitions'],'src:rho-geometric-route',
     ['A3.SS3.p2.1','A3.EGx14'], 'Source rho lies strictly between zero and one.', ['C-kappa','C-rho'])
edge('E13',['src:rho-geometric-route'],'src:poisson-geometric-identity',
     ['A3.EGx14'], 'Evaluate the two complex geometric series and simplify; the geometric convergence condition is |rho exp(+-i theta)|<1.', ['C-rho'])
edge('E14',['src:family-domain','src:target-moment-definitions','src:rho-geometric-route'],'src:rho-normalization',
     ['A3.Ex136','A3.SS3.p2.3'], 'Substitute literal rho and simplify the two scalar identities.', ['C-kappa','C-rho','C-normalization'])
edge('E15',['src:poisson-geometric-identity','src:rho-normalization'],'src:expansion-proof-composition',
     ['A3.SS3.p2.3'], 'Combine geometric fraction and normalization identities.', ['C-normalization'])
edge('E16',['src:expansion-proof-composition'],'src:inverse-spectrum-expansion',
     ['A3.Ex133','A3.SS3.p4.2'], 'Universal real-theta reciprocal expansion.', ['C-kappa','C-rho','C-normalization'])
edge('E17',['src:rho-geometric-route'],'src:expansion-convergence',
     ['A3.Ex137','A3.SS3.p2.4','A3.SS3.p4.2'], 'Uniform absolute domination by convergent positive geometric series.', ['C-rho','C-geometric'])
edge('E18',['src:family-domain','src:hard-spectrum'],'src:finite-grid-proof',
     ['A3.SS3.p3.2'], 'Finite sine-sum formula off alias lattice and termwise evaluation on lattice; denominator cases separated.', ['C-d','C-index','C-grid-sine','C-integer-k'])
edge('E19',['src:finite-grid-proof'],'src:finite-grid-orthogonality',
     ['A3.Ex139','A3.SS3.p6.1','A3.Ex144'], 'All-integer finite alias formula.', ['C-d','C-allint'])
edge('E20',['src:inverse-spectrum-expansion','src:expansion-convergence','src:hard-spectrum','src:target-moment-definitions'],'gap:weighted-c7-series',
     ['A3.SS3.p4.2'], 'Specialize universal C7 at each literal grid point; multiply by finite cosine weights with absolute summability.', ['C-C7','C-normalization','C-geometric','C-weight'])
edge('E21',['gap:weighted-c7-series','src:means-to-grid'],'gap:finite-grid-tsum-exchange',
     ['A3.SS3.p4.2'], 'Fill the omitted analytic bookkeeping: weighted absolute convergence and finite grid permit the finite/series exchange after Ex140.', ['C-d','C-weight','C-finite-tsum'])
edge('E22',['gap:finite-grid-tsum-exchange'],'src:finite-grid-series-interchange',
     ['A3.SS3.p4.2','A3.SS3.p6.1','A3.Ex144'], 'The filled finite/series exchange supplies the source paragraph assertion.', ['C-weight','C-finite-tsum','C-normalization'])
edge('E23',['src:finite-grid-orthogonality','src:family-domain','src:target-moment-definitions'],'gap:normalized-integer-alias',
     ['A3.SS3.p6.1','A3.Ex144'], 'Normalize inner sums by d and derive zero n-mode from exact source range; preserve integer shifts.', ['C-d','C-n','C-allint','C-zero-mode','C-alias'])
edge('E24',['gap:normalized-integer-alias'],'src:weighted-product-to-sum',
     ['A3.SS3.p6.1'], 'Source zero constant grid mode and real product-to-sum identity.', ['C-zero-mode','C-product'])
edge('E25',['src:finite-grid-series-interchange','src:weighted-product-to-sum'],'src:weighted-alias-series',
     ['A3.Ex144'], 'Remove zero baseline, cancel factor 2 using product-to-sum, distribute finite sums.', ['C-finite-tsum','C-zero-mode','C-product'])
edge('E26',['gap:normalized-integer-alias','src:expansion-convergence','src:rho-geometric-route'],'gap:alias-series-summability',
     ['A3.Ex144'], 'Supported normalized alias series dominated in absolute value by 2rho^j.', ['C-rho','C-alias','C-alias-bound'])
edge('E27',['src:weighted-alias-series','gap:normalized-integer-alias','gap:alias-series-summability'],'gap:positive-mode-series-indexing',
     ['A3.Ex144'], 'Convert positive source index to Nat successor and the signed shifted aliases to guarded a(k); factor d.', ['C-positive-j','C-alias','C-alias-bound'])
edge('E28',['root:producer','gap:positive-mode-series-indexing','gap:alias-series-summability'],'root:private-consumer',
     ['A3.SS3.p4.2','A3.SS3.p6.1','A3.Ex144'], 'Use the NEW actual Gaussian mean/integrability producer to turn deterministic alias series into an actual Gaussian integral equality.', ['C-d','C-kappa','C-n','C-law','C-integrable','C-finite-tsum','C-alias-bound','C-positive-j'])

for e in edges:
    for c in e['conditional_discharge']:
        c['logical_role'] = ('INTERNAL_DERIVATION_TO_BE_PROVED, not an assumed premise' if c['proposed_provider']==e['target']
                             else 'SOURCE_PARAMETER_OR_UPSTREAM_OBLIGATION, with mathematical discharge described; not a new binder')

graph = dict(schema_version=1, artifact_kind='SOURCE_ONLY_PROOF_GRAPH_EXTRACTOR_PROPOSAL',
    status='PENDING_DISTINCT_TOPOLOGY_REVIEW; no self-approval', source_sha256=RAW_SHA,
    statement_seal_sha256=SEAL_SHA, raw_first_freeze_sha256=hashlib.sha256((B/'phase1/FREEZE.json').read_bytes()).hexdigest(),
    implementation_lean_read=False, moment_API_search=False,
    terminology='Lambda is the precision; Lambda^-1 is the covariance. The sealed actual Gaussian is stdGaussian mapped by CFC.sqrt(Lambda^-1), with zero translation. Inverse covariance wording in frozen phase1 is not a claim that Lambda is the covariance.',
    graph_semantics='Each listed hyperedge is an AND of its prerequisites. Unspecified source-gap completion alternatives are recorded inside the gap and are OR choices, not additional prerequisites. Context-only nodes do not imply roots.',
    nodes=nodes, edges=edges, conditional_requirements=conditions,
    root_ids=['root:producer','root:private-consumer'],
    source_gaps=[n['id'] for n in nodes if n['kind']=='SOURCE_GAP'],
    alternative_routes=[dict(target='gap:gaussian-second-order-analysis',type='unselected SOURCE_GAP completion OR',
       routes=['direct actual Gaussian mean/covariance/second-moment characterization','affine standard-Gaussian second-moment transport'],
       warning='No API or implementation route has been inspected or attributed to the author.'),
      dict(target='gap:coordinate-second-moment',type='unselected SOURCE_GAP completion OR',
       routes=['direct second-moment specialization at equal coordinates','zero-mean covariance/variance identity plus diagonal inverse entry'])],
    open_boundary=['closed C8 finite-grid resummations','fourth moments','coordinate independence','variance bounds','normalized bias and its logarithmic/exponential estimates','rotated target transport','Krylov and adaptive algorithm/output laws','oracle/TV/cost adapters','full lower-bound theorems','shared integration/publication/purification'])
write('source-graph.json',graph)

# Exhaustive leaf inventory: every scoped paragraph/display/header, each math object, each link,
# additional logical theorem wrappers, source definitions, and excluded clauses is explicit.
coverage=[]
def item(id, kind, anchors, disposition, node_id=None, reason=None, **extra):
    record=dict(item_id=id, kind=kind, anchors=anchors, disposition=disposition, **extra)
    if node_id:record['node_id']=node_id
    if reason:record['reason']=reason
    coverage.append(record)

def record_children(b,parent_id,disp,node_id,reason):
    for j,m in enumerate(b['math']):
        mid=m['id'] or f'{parent_id}::math#{j}'
        # A source paragraph is allowed a delimited NODE with explicit excluded subclaims below.
        if parent_id=='A3.SS3.p8.1' and any(x in (m.get('alttext') or '') for x in ['U_{i}^{4}','operatorname{Var}']):
            item(mid,'inline-or-display-math',[parent_id,mid],'EXCLUDED',reason='Fourth-moment/variance clause is outside bounded second-moment bridge and remains OPEN.',source_math=m,boundary_status='OPEN')
        else:
            item(mid,'inline-or-display-math',[parent_id,mid],disp,node_id,reason,source_math=m)
    for j,l in enumerate(b['links']):
        lid=f'{parent_id}::link#{j}'
        if l['href']=='#bib.bib3':
            item(lid,'external-citation-occurrence',[parent_id],'NODE','src:external-prior-construction',
                 'Contextual construction/comparison citation, no active theorem dependency.',source_link=l)
        elif disp=='NODE' and l['href']=='#S4.Thmtheorem5':
            item(lid,'internal-source-reference',[parent_id],'NODE','src:target-moment-definitions','Source proof points to its lemma statement; does not discharge full lemma.',source_link=l)
        else:
            item(lid,'source-reference-occurrence',[parent_id],'EXCLUDED',reason=reason or 'Navigation reference belongs to structural/excluded context; no selected proof dependency.',source_link=l)

for b in raw_inventory:
    bid=b['item_id'];disp=b['disposition'];nid=b.get('node');reason=b['reason']
    # Phase1 id included the open variance route. Keep its exact name while delimiting subclaims.
    item(bid,'core-'+('paragraph' if b['tag']=='p' else 'display' if b['tag']=='table' else 'heading'),[bid],disp,nid,reason,
         source_lines=b['source_lines'],source_text=b['text'],phase1_disposition_unchanged=True)
    record_children(b,bid,disp,nid,reason)

standing_nodes={
 'S2.p1.1':'src:euclidean-convention',
 'S2.SS0.SSS0.Px1.p1.1':'src:precision-target-convention',
 'S2.Ex1':'src:precision-target-convention',
 'S2.SS0.SSS0.Px1.p1.2':'src:precision-target-convention',
 'bib.bib3':'src:external-prior-construction'}
for b in standing:
    bid=b['id'];nid=standing_nodes.get(bid)
    reason='Standing Euclidean/precision-covariance convention or contextual citation.' if nid else 'Context-only query/Haar/global-bound comparison; outside selected Gaussian moments/alias roots and remains OPEN where mathematical.'
    disp='NODE' if nid else 'EXCLUDED'
    item(bid,'supplementary-standing-source',[bid],disp,nid,reason,source_lines=b['source_lines'],source_text=b['text'])
    record_children(b,bid,disp,nid,reason)

for id,disp,nid,reason in [
 ('S4.Thmtheorem2','EXCLUDED',None,'Full comparison Remark 4.2 concerns query test/lower-bound architecture, outside roots.'),
 ('S4.Thmtheorem5','EXCLUDED',None,'Full Lemma 4.5 includes closed sums, variance and bias, all OPEN beyond selected partial precursor; its objects/assumptions are separate nodes.'),
 ('A3.Thmtheorem7','NODE','src:inverse-spectrum-expansion','Fact C.7 full mathematical assertion used before alias precursor, with proof/convergence nodes.'),
 ('A3.Thmtheorem8','EXCLUDED',None,'Fact C.8 full resummed means remain OPEN; Ex140/Ex144 are earlier proof steps, not completion of C8.')]:
    item(id+'::logical-assertion','logical-theorem-or-remark',[id],disp,nid,reason)

for id,nid,anchors,claim in [
 ('DEF:theta','src:hard-spectrum',['S4.E11'],'Exact midpoint grid, one-based/zero-based correspondence.'),
 ('DEF:lambda','src:hard-spectrum',['S4.E11'],'Exact cosine spectrum, not arbitrary supplied eigenvalues.'),
 ('DEF:Lambda','src:hard-spectrum',['S4.E11'],'Exact diagonal precision.'),
 ('DEF:U-law','src:target-moment-definitions',['S4.Thmtheorem5.p1.1'],'Actual centered Gaussian with precision Lambda and covariance Lambda^-1, realized using sqrt(Lambda^-1).'),
 ('DEF:rho','src:target-moment-definitions',['S4.Thmtheorem5.p1.1'],'Exact square-root ratio.'),
 ('DEF:D_n','src:target-moment-definitions',['S4.Thmtheorem5.p1.1'],'Exact diagonal cosine weights.'),
 ('DEF:M','src:target-moment-definitions',['S4.Thmtheorem5.p1.1'],'Actual expectation of Euclidean squared norm.'),
 ('DEF:mu_n','src:target-moment-definitions',['S4.Thmtheorem5.p1.1'],'Actual expectation of diagonal cosine quadratic.'),
 ('DEF:alias-a','gap:normalized-integer-alias',['A3.Ex139','A3.Ex144'],'Sealed normalized all-Int supported alias is an explicit translation bridge, not a separate paper definition.')]:
    item(id,'source-definition-or-literal-translation',anchors,'NODE',nid,claim)
item('A3.SS3.p8.1::independence','excluded-mathematical-subclaim',['A3.SS3.p8.1'],'EXCLUDED',reason='Coordinate independence only used in later variance route; remains OPEN.')
item('A3.SS3.p8.1::fourth-moments','excluded-mathematical-subclaim',['A3.SS3.p8.1'],'EXCLUDED',reason='Fourth Gaussian moments and square variances beyond selected second-order bridge remain OPEN.')
item('A3.SS3.p8.1::centered-inverse-variance','bounded-mathematical-subclaim',['A3.SS3.p8.1'],'NODE','src:gaussian-marginal-law-and-open-variance-route','Source corroboration only, not a dependency on the whole variance proof.')
coverage_document=dict(schema_version=1,source_sha256=RAW_SHA,statement_seal_sha256=SEAL_SHA,
    core_scope=['S4.SS1','S4.Thmtheorem5','A3.SS3'],
    scope_rule='All paragraph/display/header blocks in full core regions; all associated MathML and links; logical wrappers/definitions/subclaims explicit. Supplementary read scopes individually listed. Structural spans/MathML descendants are represented by their containing formula and not counted as independent mathematical claims.',
    items=coverage,counts=dict(total=len(coverage),nodes=sum(x['disposition']=='NODE' for x in coverage),excluded=sum(x['disposition']=='EXCLUDED' for x in coverage)),
    independent_review_status='PENDING; extractor cannot approve own coverage',formalized_coverage_claim=False)
write('coverage-inventory.json',coverage_document)

# Backward closures, mechanically derived from the proposed source graph, not implementation.
def closure(root):
    seen=set();es=set();stack=[root]
    while stack:
        cur=stack.pop()
        if cur in seen:continue
        seen.add(cur)
        for e in edges:
            if e['target']==cur:
                es.add(e['id']);stack.extend(e['prerequisites'])
    return dict(root=root,nodes=sorted(seen),edges=sorted(es),
                source_gaps=sorted(n['id'] for n in nodes if n['id'] in seen and n['kind']=='SOURCE_GAP'),
                closure_status='PROPOSED COMPLETE SOURCE PRECURSOR CLOSURE; all SOURCE_GAP obligations remain to be proved and independently reviewed')
closures=[closure(r) for r in graph['root_ids']]
write('root-closures.json',dict(schema_version=1,statement_seal_sha256=SEAL_SHA,roots=closures,
    no_false_AND='Unselected source-gap proof alternatives are prose OR routes and are not separate required graph parents. C7 and GridAlias are genuine simultaneous consumer ingredients.'))

projection=dict(schema_version=1,seal_id=seal['seal_id'],statement_seal_sha256=SEAL_SHA,
    signature_hashes=dict(producer=seal['producer']['signature_sha256'],private_consumer=seal['actual_private_consumer']['signature_sha256']),
    admission_recommendation='SOURCE-FAITHFUL BOUNDED STATEMENT; topology pending distinct reviewer, no proof credit',
    public_producer=dict(root='root:producer',source_use_sites=['A3.SS3.p4.1','A3.Ex140'],
      outputs=[dict(sealed=x,source_nodes=ns) for x,ns in [
       ('Integrable actual squared norm',['gap:gaussian-second-order-analysis','gap:norm-quadratic-coordinate-identities','gap:gaussian-quadratic-integrability']),
       ('Integrable actual Q',['gap:gaussian-second-order-analysis','gap:gaussian-quadratic-integrability']),
       ('Actual norm-square integral=sum reciprocal eigenvalues',['src:means-to-grid','gap:finite-expectation-linearity']),
       ('Actual Q integral=sum cos(n theta_i)/lambda_i',['src:means-to-grid','gap:finite-expectation-linearity'])]]),
    actual_private_consumer=dict(root='root:private-consumer',source_use_sites=['A3.SS3.p4.2','A3.SS3.p6.1','A3.Ex144'],
      outputs=[dict(sealed=x,source_nodes=ns) for x,ns in [
       ('Summable supported all-Int alias series',['gap:alias-series-summability']),
       ('Integrable actual Q',['root:producer']),
       ('Actual Q integral=(d/sqrt(kappa))*supported-tsum',['root:producer','src:weighted-alias-series','gap:positive-mode-series-indexing'])]],
      required_actual_use='NEW producer supplies the Gaussian integral and integrability; deterministic C7/GridAlias ingredients supply scalar normalization/series. Exact compiled dependency set must be inspected after proof; this source graph does not certify any reuse.'),
    binder_audit=[dict(binder='d:Nat, kappa:Real, n:Nat',classification='TYPING',source='Real finite dimension/parameter and positive integer mode represented in Nat'),
      dict(binder='hd:2<=d',classification='STANDING',source='S4.SS1.p1.1'),
      dict(binder='hkappa:2<=kappa',classification='STANDING',source='S4.SS1.p1.1 and S4.Thmtheorem5.p1.1'),
      dict(binder='hn:1<=n, hnd:n<d',classification='SOURCE',source='S4.Thmtheorem5.p1.1')],
    EXCESS_binders_found=[],
    definition_projection=[
      dict(object='theta/eigenvalue/Lambda',kind='literal',source='S4.E11',obligation='Index adapter i_source=i.val+1; internally derive SPD and correct inverse.'),
      dict(object='mu=multivariateGaussian 0 Lambda^-1',kind='literal',source='S4.Thmtheorem5.p1.1',obligation='Identify actual affine standard-Gaussian measure on SPD domain; retain zero mean/inverse covariance and finite moments as internal proof edges.'),
      dict(object='Q and squared Euclidean norm',kind='literal',source='S2.p1.1; S4.Thmtheorem5.p1.1; A3.Ex140',obligation='Prove pointwise finite coordinate identities and actual integrability.'),
      dict(object='r and a(k)',kind='literal',source='rho in S4.Thmtheorem5.p1.1; aliases A3.Ex139',obligation='Int quotient guarded by divisibility, signed subtraction before truncation can occur; |a|<=1.'),
      dict(object='positive-mode tsum',kind='literal',source='A3.Ex144',obligation='Nat successor reindex; actual summability produced and factor d normalization shown.')],
    distinct_obligations=['Gaussian actual-law / zero mean / covariance equals Lambda^-1 (precision Lambda) / finite moment analysis','finite integral/finite-sum linearity','C7 scalar cosine normalization','finite-grid/tsum exchange with weighted summability','all-integer alias normalization and signed indexing'],
    source_gap_policy='No omitted bridge may become a free producer or consumer hypothesis. Existing declaration names in seal are provisional reuse candidates; no proof/API search performed by extractor.',
    open_boundary=graph['open_boundary'], independent_review_status='PENDING; this recommendation is not extractor self-acceptance')
write('seal-projection.json',projection)

# Structural validation checks shape/counts only. It cannot perform mathematical topology review.
ids=[n['id'] for n in nodes]
assert len(ids)==len(set(ids))
assert all(x in ids for e in edges for x in e['prerequisites']+[e['target']])
assert all(e['consumer_use_sites'] and e['conditional_discharge'] for e in edges)
assert all(i['disposition'] in ('NODE','EXCLUDED') for i in coverage)
assert all(i.get('node_id') in ids for i in coverage if i['disposition']=='NODE')
assert all(i.get('reason') for i in coverage if i['disposition']=='EXCLUDED')
assert len({i['item_id'] for i in coverage})==len(coverage)
assert len([i for i in coverage if i['kind'].startswith('core-')])==64
def ancestors(id, active=None):
    active=set() if active is None else active
    assert id not in active, ('cycle',id)
    result=set()
    for e in edges:
        if e['target']==id:
            for parent in e['prerequisites']:
                result.add(parent)
                result.update(ancestors(parent,active|{id}))
    return result
guard_errors=[]
for e in edges:
    permitted=ancestors(e['target'])|{e['target']}
    guard_errors.extend((e['id'],c['id'],c['proposed_provider']) for c in e['conditional_discharge'] if c['proposed_provider'] not in permitted)
assert not guard_errors, guard_errors
assert hashlib.sha256(seal['producer']['signature'].encode()).hexdigest()==seal['producer']['signature_sha256']
assert hashlib.sha256(seal['actual_private_consumer']['signature'].encode()).hexdigest()==seal['actual_private_consumer']['signature_sha256']
for rec in json.loads((B/'phase1/FREEZE.json').read_text())['files']:
    assert hashlib.sha256((B/rec['path']).read_bytes()).hexdigest()==rec['sha256']
write('structural-validation.json',dict(status='PASS_STRUCTURAL_ONLY',checked_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    checks=['all phase1 frozen files hash unchanged','all exact seal signature hashes match','unique graph/coverage IDs','all edge references resolve','DAG acyclic; conditional provider names are upstream or explicit internal derivations, not new hidden graph premises','every edge has consumer-use-site and conditional discharge','all 64 core blocks retain phase1 disposition','all coverage items NODE or explicitly EXCLUDED'],
    counts=dict(nodes=len(nodes),edges=len(edges),source_gaps=len(graph['source_gaps']),coverage_items=len(coverage),core_blocks=64),
    not_a_substitute_for='Distinct raw-source mathematical coverage and backward root-closure review.'))

lines=['# Source graph review capsule','',
 'Extractor proposal only; distinct mathematical topology review is pending. No implementation Lean or moment API has been read.', '',
 'The public producer projects Appendix C.3 p4.1/Ex140: actual Gaussian integrability and both expectation-to-grid identities. The private consumer additionally projects p4.2/p6.1/Ex144: the genuine Gaussian weighted alias-series precursor, with supported summability.', '',
 f'Pinned raw SHA256: `{RAW_SHA}`. Exact statement seal SHA256: `{SEAL_SHA}`.', '',
 f'{len(nodes)} nodes, {len(edges)} consumer-use-site hyperedges, {len(graph["source_gaps"])} visible SOURCE_GAP bridges. Coverage has {len(coverage)} unique items, including all 64 core paragraph/display/header blocks and every attached formula/link occurrence.', '',
 'The analytic bridge is actual Gaussian law → zero mean / inverse covariance / integrable second moments → coordinate squares → finite integral linearity → Ex140. The scalar route is C7 normalization and absolute convergence + finite grid/tsum exchange + zero grid mode + product-to-sum → Ex144. All-integer aliases normalize its inner sums; |a|≤1 and a geometric bound produce supported-series summability.', '',
 'The source does not print the actual-law realization, the coordinate/norm/quadratic integrability arguments, or the finite expectation linearity details. They stay as SOURCE_GAP nodes. The literal standard Gaussian constructor must be justified on SPD covariance internally. These are proof ingredients, never extra source binders.', '',
 'Signed indexing matters: the source j≥1 becomes Nat j+1, cast to Int before subtracting n; j−n can be negative. k=0 remains in the divisible alias branch. The dimension factor d is extracted from each inner finite sum to give the sealed d/√κ coefficient.', '',
 'Closed C8 resummations, fourth moments, independence, variances, bias, rotated/Krylov/adaptive laws, global bounds and publication/integration/purification remain OPEN. The external [22] citation is contextual and supplies no selected proof dependency.', '',
 'Review `source-graph.json`, `coverage-inventory.json`, `root-closures.json`, and `seal-projection.json` against the pinned raw source and exact seal. `structural-validation.json` is only shape/hash checking. The phase1 private cognition is intentionally not required for independent review.', '']
(P2/'review-capsule.md').write_text('\n'.join(lines))
print(json.dumps({'nodes':len(nodes),'edges':len(edges),'source_gaps':len(graph['source_gaps']),'coverage':coverage_document['counts'],'root_closures':[{k:v for k,v in c.items() if k in ['root','source_gaps']} for c in closures]},indent=2))
