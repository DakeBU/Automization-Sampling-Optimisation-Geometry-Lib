"""Prepare new owned browser scripts only; never import/execute browser code."""
from pathlib import Path
import ast,difflib,gzip,hashlib,json
R=Path('/Users/zhouhuanjian/ASTIS-GC');S=R/'.astis/huanjian-gc-fixed-spectrum-first-order-integration-20261108/independent-reader';O=S/'conditional-browser-v1'
old=R/'.astis/huanjian-gc-fixed-spectrum-normalizer-integration-20261108/independent-reader/check_final_reader_v7.py'
sha=lambda b:hashlib.sha256(b).hexdigest();dump=lambda x:(json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode()
reportpath=S/'conditional-proposal-v1/proposal-report.json';rr=reportpath.read_bytes();r=json.loads(rr);assert sha(rr)=='43bff1329cd5b697a845184e1ff9d27004c93d46edb2251f855c4a90d92e5604'
assert not O.exists();O.mkdir()
common=S/'first_order_browser_common_v1.py';common.write_bytes(common.read_bytes().replace(b'UNBOUND_NOT_EXECUTABLE',sha(rr).encode(),1))
source=old.read_text();helpers=source[source.index('class Quiet'):source.index('try:\n    with sync_playwright()')];tail=source[source.index('try:\n    with sync_playwright()'):]
def replace(a,b):
 global tail
 assert tail.count(a)==1,a[:100];tail=tail.replace(a,b,1)
replace("        context = browser.new_context(viewport={'width': 1440, 'height': 1000})\n        context.route(re.compile(r'https?://(?!127\\.0\\.0\\.1:)'), lambda route: route.abort())\n        page = context.new_page()\n        page.on('pageerror', lambda error: report['errors'].append(str(error)))\n        for width in (1440, 390):\n            page.set_viewport_size({'width': width, 'height': 1000 if width > 400 else 844})", "        for width in (1440, 390):\n            context = browser.new_context(viewport={'width': width, 'height': 1000 if width > 400 else 844})\n            context.route(re.compile(r'https?://(?!127\\.0\\.0\\.1:)'), lambda route: route.abort())\n            page = context.new_page()\n            page.on('pageerror', lambda error: report['errors'].append(str(error)))")
replace("('either determinant sign', 'zero-based', 'unnormalized Euclidean Lebesgue', 'source-implicit', 'Only the normalizing scalar', 'odd dimensions')", "('either determinant sign', 'zero additive constant', 'Fréchet derivative existence', 'same hidden', 'Reference', 'Random seeds')")
replace('assert parent_list.count() == 3','assert parent_list.count() == 1')
replace("'consumer_uses_same_GPD': True", "'consumer_uses_same_O_forward_affine': True")
replace("            main.evaluate('(node) => { for (let p=node.parentElement;p;p=p.parentElement) if(p.matches(\"details\"))p.open=true; }')", "            ancestors = main.locator('xpath=ancestor::details')\n            for ancestor_index in reversed(range(ancestors.count())):\n                ancestor = ancestors.nth(ancestor_index)\n                if ancestor.get_attribute('open') is None:\n                    ancestor.locator(':scope > summary').click()\n                    assert ancestor.get_attribute('open') is not None")
replace("            determinant_text = page.locator('#gaussian-complexity-determinant').text_content()", "            for phrase in ('actual fixed-spectrum first-order reply', 'genuine derivative existence', 'sole producer parent is canonical actual admissibility', 'same-O affine provider', 'not an operational one-query or adaptive transcript theorem'):\n                assert phrase in boundary, phrase\n            determinant_text = page.locator('#gaussian-complexity-determinant').text_content()")
a=tail.index('            gaussian_focus = focused_entry');b=tail.index('            # One existing generic long-Lean card regression',a)
tail=tail[:a]+"            report['graphs'].append({'target': own_id, 'width': width, 'one_canonical_producer': True, 'producer_ASTIS_parents': PRODUCER_ASTIS_PARENTS, 'native_one_canonical_parent_click': True, 'source_scanner_edge_not_kernel_evidence': True, 'owner_module': module_id, 'focused_entry': focus, 'native_neighbor_module_click': True, 'semantic_boundary': 'ONE separately kernel-confirmed admissibility producer parent and TWO private Test parents: new producer plus same-O affine provider. Scanner references are dashed/incomplete, not complete kernel export. No old GPD source/audit change is part of this packet.'})\n\n"+tail[b:]
replace("            assert module_id not in nodes[bridge]['candidate_substrates']\n            assert page.locator(f'.ulg-node[data-id=\"{module_id}\"]').count() == 0", "            assert module_id in nodes[bridge]['candidate_substrates']\n            assert page.locator(f'.ulg-node[data-id=\"{module_id}\"]').count() == 1")
replace("            assert detail.locator(f'button[data-jump=\"{module_id}\"]').count() == 0", "            assert detail.locator(f'button[data-jump=\"{module_id}\"]').count() == 1\n            assert 'not a one-query operational cap theorem' in edge['critical_estimates'][-1]['status']\n            assert edge['critical_estimates'][-1]['supplement_review']['current_theorem_sourceV_granted_by_this_mechanism_review'] is False")
replace("screenshot(page, f'existing-conceptual-{width}-unchanged')", "screenshot(page, f'existing-conceptual-{width}-typed-supplement')")
replace("            report['graphs'].append({'target': bridge, 'width': width, 'focused_entry': bridge_focus, 'exact_model_and_memory_unchanged': True, 'no_new_normalizer_candidate_or_formal_transport': True, 'formal_refs': [], 'actual_semantic_rows_equal_preserved_model': True})", "            report['graphs'].append({'target': bridge, 'width': width, 'focused_entry': bridge_focus, 'same_existing_bridge_typed_supplement': True, 'old_model_binding_critical_estimate_review_history_retained': True, 'canonical_module_candidate_only': module_id, 'formal_refs': [], 'no_formal_transport_or_query_cost_credit': True, 'actual_semantic_rows_equal_reviewed_model': True})\n            context.close()")
replace("        assert not report['errors'], report['errors']", "        assert len(report['screenshots']) == 38\n        assert len(report['pages']) == 2 and len(report['graphs']) == 4 and len(report['old_long_Lean_layout_regressions']) == 2\n        assert not report['errors'], report['errors']")
# Both production and Test complete source bytes are checked through actual own-site DOM/download/Git.
replace("            chapter = 'example-cases/samplewiki/companions/gaussian-sampling-complexity.html'", "            test_rows = [row for row in site_data['modules'] if row['name'] == 'Tests.GaussianComplexityFixedSpectrumFirstOrder']\n            assert len(test_rows) == 1\n            assert page.goto(urljoin(base, test_rows[0]['page']), wait_until='domcontentloaded').status == 200\n            page.locator('#complete-module-source > details > summary').click()\n            test_source = (ROOT / test_rows[0]['source_file']).read_bytes()\n            assert page.locator('#complete-module-source pre > code').text_content().encode() == test_source\n            test_download = page.locator('#complete-module-source a[download]')\n            assert test_download.count() == 1\n            test_response = context.request.get(urljoin(page.url, test_download.get_attribute('href')))\n            assert test_response.status == 200 and test_response.body() == test_source\n            assert subprocess.check_output(['git','show',HEAD+':'+test_rows[0]['source_file']]) == test_source\n            assert subprocess.check_output(['git','show',CANDIDATE+':'+test_rows[0]['source_file']]) == test_source\n            report['pages'][-1]['private_Test_source_pin'] = {'route':test_rows[0]['page'],'sha256':sha(test_source),'DOM_download_candidate_and_current_Git_exact':True,'pixel_review_claim':False}\n\n            chapter = 'example-cases/samplewiki/companions/gaussian-sampling-complexity.html'")
pins=dict(r['source_Test_lesson_publication_pins']);pins['website/static/information-architecture.css']=r['CSS_unchanged_sha256']
pins.update({row['path']:row['planned_after_sha256'] for row in r['shared_paths'] if row['path'].startswith('website/content/') and row['path'].endswith('.json')})
preamble='''"""CONDITIONAL new FirstOrder browser helper: no actual run until fresh sourceV/soleSTAB/exact gates and separate root+OS authorization."""
import datetime,functools,hashlib,http.server,json,re,subprocess,sys,threading
from pathlib import Path
from urllib.parse import quote,urljoin,urlsplit
sys.dont_write_bytecode=True
from first_order_browser_common_v1 import parse_args,load_authorization,authorized_context
authorization_args=parse_args(__doc__)
authorization,authorization_ref=load_authorization(authorization_args)
authorization_readback=authorized_context(authorization)
from playwright.sync_api import sync_playwright
ROOT=Path.cwd();assert ROOT==Path('/Users/zhouhuanjian/ASTIS-GC')
SITE=ROOT/'_site';sys.path[:0]=[str(ROOT/'website/scripts'),str(ROOT/'tools')]
import inline_lean,astis_site,astis_publication
sha=lambda raw:hashlib.sha256(raw).hexdigest()
HEAD=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
CANDIDATE='9d306d837fbddf1518b0035494baaf5c21c24488'
PREFIX='AutoSamplingTheory.ExampleCases.GaussianComplexity.'
NAME=PREFIX+'FixedSpectrumFirstOrder.actual_first_order_query'
MODULE=PREFIX+'FixedSpectrumFirstOrder'
ITEM='huanjian-fixed-spectrum-first-order'
BINDING='51d5a5e9390a0d66c2d5b72d042a042eec8d3d60433043ea3909bf9320ccb31e'
ADMISSIBILITY=PREFIX+'FixedSpectrumAdmissibility.actual_precision_admissible'
AFFINE=PREFIX+'FixedSpectrumAffine.actual_affine_precision_query'
PRODUCER_ASTIS_PARENTS=[ADMISSIBILITY]
CONSUMER_ASTIS_PARENTS=[NAME,AFFINE]
PINS=__PINS__
for path,digest in PINS.items():
 raw=(ROOT/path).read_bytes();assert sha(raw)==digest,path;assert subprocess.check_output(['git','show',HEAD+':'+path])==raw,path
for path in ['AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumFirstOrder.lean','Tests/GaussianComplexityFixedSpectrumFirstOrder.lean']:
 assert subprocess.check_output(['git','show',CANDIDATE+':'+path])==(ROOT/path).read_bytes()
assert (SITE/'assets/information-architecture.css').read_bytes()==(ROOT/'website/static/information-architecture.css').read_bytes()
metadata_path=SITE/'data/build-metadata.json';metadata=json.loads(metadata_path.read_bytes())
gate_path=ROOT/'.astis/site-lean-gate.json';gate=json.loads(gate_path.read_bytes())
assert gate['passed'] and gate['commit']==metadata['git']['commit']==HEAD
assert metadata['gate']['passed'] and metadata['gate']['current']
assert gate['source_digest']==metadata['source_digest']==astis_site.source_digest()==authorization['source_digest']
unit=json.loads((ROOT/'website/content/declaration_lessons/huanjian-fixed-spectrum-first-order.json').read_bytes())['units'][0]
assert unit['declaration']==NAME and unit['reading_layout']=='progressive' and len(unit['steps'])==6 and unit['astis_dependencies']==PRODUCER_ASTIS_PARENTS and unit['mathlib_dependencies']
capsule_path=ROOT/'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-first-order-semantic-evidence/local-proof-capsule.json'
capsule=json.loads(capsule_path.read_bytes())
assert capsule['actual_direct_ASTIS_producer_parents']==PRODUCER_ASTIS_PARENTS and set(capsule['actual_direct_ASTIS_private_consumer_parents'])==set(CONSUMER_ASTIS_PARENTS)
assert capsule['production_raw_sha256']==PINS['AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumFirstOrder.lean'] and capsule['Test_raw_sha256']==PINS['Tests/GaussianComplexityFixedSpectrumFirstOrder.lean']
pub=next(x for x in astis_publication.load() if x['id']==ITEM);assert astis_publication.binding_digest(pub,pub['bindings'][0])==BINDING
astis_publication.check_advance([NAME],reviewed=True)
rows={x['declaration']:x for x in json.loads((SITE/'data/declaration-exposition.json').read_bytes())};declarations=inline_lean.declarations()
site_data=json.loads((SITE/'data/site-data.json').read_bytes())
assert not any('actual_reference_precision_first_order_consumer' in x['local_decl'] for x in site_data['registry_declarations'])
graph=json.loads((SITE/'data/underlying-lean-graph.json').read_bytes());nodes={x['id']:x for x in graph['nodes']}
own_id='decl:'+NAME;module_id='module:'+MODULE;parent_ids=['decl:'+ADMISSIBILITY]
for ident in [own_id,module_id,*parent_ids]:assert sum(x['id']==ident for x in graph['nodes'])==1
for parent,parent_id in zip(PRODUCER_ASTIS_PARENTS,parent_ids):
 assert nodes[parent_id]['kind']=='declaration'
 assert sum(e['source']=='module:'+parent.rsplit('.',1)[0] and e['target']==parent_id and e['relation']=='declares' for e in graph['edges'])==1
 refs=[e for e in graph['edges'] if e['source']==parent_id and e['target']==own_id];assert len(refs)==1 and refs[0]['relation']=='source reference (scanner)'
assert sorted(e['source'] for e in graph['edges'] if e['target']==own_id and e['relation']=='source reference (scanner)')==parent_ids
assert sum(e['source']==module_id and e['target']==own_id and e['relation']=='declares' for e in graph['edges'])==1
model=json.loads((ROOT/'website/content/functor_hypergraph.json').read_bytes());memory=json.loads((ROOT/'website/content/graph_memory_index.json').read_bytes())
bridge='transport:gaussian-quadratic-oracle-factorization';edge=next(x for x in model['hyperedges'] if x['id']==bridge);family=next(x for x in memory['families'] if x['id']=='family:gaussian-oracle-hardness')
assert edge['formal_refs']==[] and edge['status']=='not-Lean-certified'
assert sum(x['node']==MODULE for x in family['compiled_substrate_bindings'])==1
assert nodes[bridge]['hyperedge']==edge and module_id in nodes[bridge]['candidate_substrates']
incidence=[e for e in graph['edges'] if e['source']==module_id and e['target']==bridge]
assert len(incidence)==1 and 'candidate' in incidence[0]['relation'].lower()
OUT=ROOT/'.astis/huanjian-gc-fixed-spectrum-first-order-integration-20261108/independent-reader/browser'/('live-'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ'));OUT.mkdir(parents=True,exist_ok=False)
report={'head':HEAD,'candidate_commit':CANDIDATE,'candidate_source_digest':authorization['candidate_source_digest'],'mode':'Actual current local HTTP site, installed headless Chrome; external hosts blocked. This report exists only after explicit future authorization.','site_metadata_sha256':sha(metadata_path.read_bytes()),'actual_gate_sha256':sha(gate_path.read_bytes()),'actual_gate_commit':gate['commit'],'site_commit':metadata['git']['commit'],'source_digest':gate['source_digest'],'publication_binding_sha256':BINDING,'input_pins':PINS,'pages':[],'graphs':[],'old_long_Lean_layout_regressions':[],'site_layout_css_sha256':sha((SITE/'assets/information-architecture.css').read_bytes()),'visible_source_index_clicks':[],'errors':[],'screenshots':[],'authorization':authorization_ref,'authorization_readback':authorization_readback,'external_GitHub_HTML_checked':False,'external_source_boundary':'Own-site source/module/downloads checked against candidate/current immutable local Git. GitHub syntax only if that branch executes, never external HTML/public HTTP delivery.','producer_ASTIS_parents':PRODUCER_ASTIS_PARENTS,'consumer_ASTIS_parents':CONSUMER_ASTIS_PARENTS,'producer_parent_evidence':{'capsule':str(capsule_path.relative_to(ROOT)),'sha256':sha(capsule_path.read_bytes()),'scope':'Already existing genuine kernel inventory, not scanner export or fresh compilation by browser.'},'consumer_visibility':'Private Test only; exactly new producer and actual SAME-O affine provider. No Registry consumer or operational cost theorem.'}

'''.replace('__PINS__',repr(pins))
result=preamble+helpers+tail;compile(result,'check_final_reader_v1.py','exec');ast.parse(common.read_text())
assert "old_code = old_lens.locator(':scope > pre.code-block')" in result and 'assert old_code.count() == 1' in result and 'assert old_lines >= 100' in result
assert '.first pre' not in result and 'p.open=true' not in result and 'force=True' not in result
(S/'check_final_reader_v1.py').write_text(result)
for name,raw in [('normalizer-accepted-template.raw.py.gz',old.read_bytes()),('new-browser.raw.py.gz',result.encode()),('new-common.raw.py.gz',common.read_bytes()),('preparation-driver.raw.py.gz',Path(__file__).read_bytes())]:(O/name).write_bytes(gzip.compress(raw,mtime=0))
diff=''.join(difflib.unified_diff(source.splitlines(keepends=True),result.splitlines(keepends=True),fromfile='accepted-normalizer-v7-template',tofile='conditional-first-order-v1'));(O/'template-adaptation.diff').write_text(diff)
record={'state':'CONDITIONAL_BROWSER_PREPARED_NOT_EXECUTED_NOT_ACCEPTED','candidate_commit':r['candidate_commit'],'candidate_source_digest':r['candidate_source_digest'],'predicted_exact8payload_source_digest':r['predicted_source_digest_after_exact_proposed_Lean_payloads'],'proposal_report_sha256':sha(rr),'checker':{'path':str((S/'check_final_reader_v1.py').relative_to(R)),'sha256':sha(result.encode())},'common':{'path':str(common.relative_to(R)),'sha256':sha(common.read_bytes())},'main_originals_required_if_run':38,'widths':[[1440,1000],[390,844]],'old_DensityAffinity_regression':'Two widths native UI/DOM/Range geometry only, no additional image claim; direct unique fullproof pre.code-block and >=100 source lines retained.','CSS_unchanged':r['CSS_unchanged_sha256'],'mode_isolation':'Each width gets a fresh browser context. Native learner/summary clicks affect only old generic card, never mutate HTML open attributes by JS.','retained_guards':['Exact source/Test candidate and eventual immutable Git pins, own-site full DOM/download bytes','Main formula, default closed assumptions/Lean, six formula steps each with exact authored adjacent correspondence','ONE canonical producer parent native graph click and module navigation, incomplete scanner boundary','Same canonical typed bridge supplement remains proposal/not-Lean-certified with formal_refs=[]; old bindings/critical estimates/reviews protected byte-exact','Actual final same-HEAD Lean/site/graph eight receipts, accepted independent sourceV and soleSTAB guards mandatory before any browser starts','Actual originals require later separate independent image review; helper status never auto-certifies pixels'],'application_or_browser_authorized':False,'sourceV_granted':False,'actual_root_build_site_or_browser_run':False,'normal_lifecycle_API_called':False,'future_invocation_template':['.astis/huanjian-gc-integration-20261105/browser-venv/bin/python',str((S/'check_final_reader_v1.py').relative_to(R)),'--authorization-json','<new exact approved final-core context>','--authorization-sha256','<its raw SHA256>'],'OS_authorization':'New script path must be independently reviewed and explicitly OS-authorized later; no old Normalizer prefix reuse.','static_validation_only':'Python compile/AST parse of generated text; no imports or execution of the browser module.'}
(O/'browser-preparation-report.json').write_bytes(dump(record));freeze={'report_sha256':sha((O/'browser-preparation-report.json').read_bytes()),'files':[{'path':str(p.relative_to(R)),'sha256':sha(p.read_bytes())} for p in sorted(O.iterdir()) if p.is_file()],'executed':False};(O/'freeze.json').write_bytes(dump(freeze));print(json.dumps({'browser_report_sha256':freeze['report_sha256'],'browser_checker_sha256':record['checker']['sha256'],'browser_common_sha256':record['common']['sha256'],'freeze_sha256':sha((O/'freeze.json').read_bytes()),'actual_browser_executed':False},indent=2))
