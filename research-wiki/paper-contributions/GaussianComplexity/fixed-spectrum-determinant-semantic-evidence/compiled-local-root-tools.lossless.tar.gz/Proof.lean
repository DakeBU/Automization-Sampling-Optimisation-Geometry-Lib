import AutoSamplingTheory.TechnicalLemmas.Measure.DisplacementJacobianEntropy
import Mathlib.LinearAlgebra.UnitaryGroup
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Basic
open Matrix
open scoped BigOperators
set_option autoImplicit false
namespace AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumDeterminant
theorem actual_precision_det {d : ℕ} (hd : 2 ≤ d)
    {κ : ℝ} (hκ : 2 ≤ κ)
    (O : Matrix.orthogonalGroup (Fin d) ℝ) :
    let θ : Fin d → ℝ := fun i => ((i.val : ℝ) + 1 / 2) * Real.pi / (d : ℝ)
    let diagonalValue : Fin d → ℝ := fun i =>
      (κ + 1) / 2 + (κ - 1) / 2 * Real.cos (θ i)
    let A : Matrix (Fin d) (Fin d) ℝ :=
      (O : Matrix (Fin d) (Fin d) ℝ) * Matrix.diagonal diagonalValue *
        (O : Matrix (Fin d) (Fin d) ℝ).transpose
    A.det = ∏ i : Fin d, diagonalValue i := by
  classical
  let θ : Fin d → ℝ := fun i => ((i.val : ℝ) + 1 / 2) * Real.pi / (d : ℝ)
  let diagonalValue : Fin d → ℝ := fun i =>
    (κ + 1) / 2 + (κ - 1) / 2 * Real.cos (θ i)
  let M : Matrix (Fin d) (Fin d) ℝ := O
  change (M * Matrix.diagonal diagonalValue * M.transpose).det =
    ∏ i : Fin d, diagonalValue i
  have hdet :=
    AutoSamplingTheory.TechnicalLemmas.Measure.DisplacementJacobianEntropy.det_conjStarAlgAut_eq
      (O : unitary (Matrix (Fin d) (Fin d) ℝ)) (Matrix.diagonal diagonalValue)
  rw [Unitary.conjStarAlgAut_apply] at hdet
  change (M * Matrix.diagonal diagonalValue * star M).det =
    (Matrix.diagonal diagonalValue).det at hdet
  have hstar : star M = M.transpose := by
    ext i j
    simp
  rw [hstar, Matrix.det_diagonal] at hdet
  exact hdet
end AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumDeterminant
#print axioms AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumDeterminant.actual_precision_det
open Lean in
run_cmd do
  let env ← getEnv
  let some info := env.find? `AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumDeterminant.actual_precision_det | throwError "Missing source determinant theorem"
  let some value := info.value? (allowOpaque := true) | throwError "Missing determinant proof"
  let parents := value.getUsedConstants.filter fun n => n.toString.startsWith "AutoSamplingTheory"
  logInfo m!"ACTUAL COMPILED ASTIS PRODUCER PARENTS {parents}"
