# C7 conditional integration and reader preparation

Prepared independently by `/root/geometry_integration_reader` for the sole proof/integration owner. The exact eight payloads are ready for root's conditional diff review. They are unapplied. This is neither a source-fidelity verdict nor actual integration, runtime/pixel acceptance, park eligibility, remote publication or purification.

The checked mathematical candidate is `37645c774481c4cad19fc29bcaa76799da64db7d`; the tracked working tree remained clean before and after preparation. The actual SAU is `PROVED_LOCAL`, not VERIFIED/STABILIZING. The current audit remains `blind-reconstructed` with verdict/source review pending, at publication binding `8ddbbdb086becb57b2b8212154d9f607b121f7955cfcce132927210eaa04b95c`. The separate fresh source actor `5d8c2a` retains source-review ownership; no verdict from that unfinished work is assumed here.

## A: real-main reconciliation, before C7 payloads

Read the two navigation contracts from actual main commit `4f0e6584e26dc5226957f23108f0c2309296e0c5` using `git show`. The common ancestor is `d9bcd4231df69061c5221f8d557ee179a945c1eb`. The precise incoming delta is **22 paths: 20 main-only and two overlaps**. The earlier approximate count21 is superseded by the exact inventory in `stage-A/reconciliation-manifest.json`.

The old three-argument read-only `git merge-tree BASE CANDIDATE MAIN` produced no conflict markers. This does not prove reader compatibility or apply a merge. The later sole stabilization owner must perform a **real merge retaining main ancestry**, rather than copying22 blobs and describing that as a merge. Compare its results to the frozen expected bytes:

| Overlap | Main semantics to retain | Branch semantics to retain | Expected reconciled SHA256 |
|---|---|---|---|
| `website/content/functor_hypergraph.json` | Existing `concept:lower` label `Lower Bounds`, URL `lower-bounds/index.html`, including its exact changed-line LF bytes | All existing typed bridges, FirstOrder supplement, old source/review/critical-estimate history and all other mixed CRLF bytes | `58d932e0ca93735f0186fda81aed4b2f3b2d7632250ee41eba085a171709beda` |
| `website/static/underlying-lean-graph.js` | Atlas label `concept:lower` → `Lower Bounds` | Search selection's post-render readable fit and emitted Functor preset's `fit({readable:true})` callback; every other branch byte | `c0db9c5b0a91ecbc267929436d2f58308238e208a3183a4937509a60339681f8` |

The20 main-only paths retain their exact main bytes; the manifest archives every incoming main blob and each candidate predecessor that exists. They include Bench prose08/catalog/review changes, Lower Bounds reader/tests, canonical build/check integration and reader navigation. There are no incoming Lean, toolchain, manifest or governance changes. No Bench work is adopted as Gaussian proof credit. No other-chat historical snapshot or PR status is rewritten.

Main's Lower Bounds reader is a cross-library thematic entrance, not a second SampleWiki hierarchy, new proof registry, scheduling lane or completed lower bound. It reuses existing canonical readers and graph IDs. Its explicit selected IDs currently omit C7; no extra manual placement/source-index entry is needed for this scalar component. The Gaussian case's existing publication projection supplies the C7 source/lesson/index correspondence after a genuinely accepted binding. Preserve main's method-specific midpoint boundaries and typed oracle/algorithm/output/budget/overhead distinctions.

## B: eight exact C7 shared payloads, after A

The source/Test/lesson/publication/audit are inputs, not edited payloads. Seven payload predecessors are candidate bytes; **Functor's predecessor is the stage-A reconciled blob**, not today's branch blob. Applying the candidate-only Functor predecessor would drop incoming main's Lower Bounds changes and is wrong.

| Path | Exact minimal change |
|---|---|
| `AutoSamplingTheory.lean` | One producer module import after Geometry |
| `Tests.lean` | One real private Test module import after Geometry |
| `AutoSamplingTheory/TechnicalLemmas/Registry.lean` | One import and exactly one new C7 public producer entry |
| `Tests/Basic.lean` | Genuine public-node count624→625 |
| `website/content/samplewiki_companion_frontiers.json` | Only `cases[4].reader_guide[3]` and `cases[4].theorems[1].boundary` |
| `research-wiki/sampling-sde-library/cards/AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumCosineExpansion.md` | New canonical module card |
| `website/content/graph_memory_index.json` | Append `family:poisson-representation`, with the existing A1 and new C7 modules as dashed search substrates |
| `website/content/functor_hypergraph.json` | Append two conceptual domains, one `transport:poisson-boundary-to-cosine-spectrum` bridge, and three genuinely missing exact source-catalog IDs |

The source catalog entries support the conceptual model's required exact `source_ids`; they are not duplicate theorem publication/source-index bindings. Existing authored mathematics remains owned once by the C7 lesson/publication files. The private `actual_inverse_grid_cosine_series` is never added as a public or Registry node.

All before/after payloads are losslessly frozen as gzip archives with raw and archive hashes and CRLF/LF counts. The two own-case token substitutions were inversely restored byte-for-byte. Model additions are insertions after existing JSON tokens; each insertion's inverse restores the old raw bytes. Existing values, arrays, all old bridge/review/source history and main's Lower Bounds object are equal. Exact byte archives, rather than the human-readable diff's line presentation, are authoritative for CRLF preservation. `stage-B/conditional-exact.diff` records the complete eight-path proposal.

No README, mathematical source/Test/lesson/publication/seal, current audit/frontier, advance/discovery ledger, process memory, shared spine, foreign case/state or queue is changed by preparation. The bounded pin manifest includes the actual relevant evidence and selected raw control-plane inputs; it is deliberately **not** a new full protected-baseline/foreign-state audit. Future state/audit/own-frontier projections are separate exact lifecycle metadata operations, not hidden ninth payloads here.

## Actual compiler evidence and reader meaning

I inspected the original successful kernel receipt and raw log, including exact sealed type application. Receipt SHA256 `d24e442c1d7bd913f44ce21c1292dc5a3a303d434313c47c4dc48cc15cb915a0`; raw log SHA256 `7b24fe9bc4401069f2f3c2aa6cc5ba3fc8048493ef9c8f136eba67d0caab52f6`. The producer's `DIRECT_ASTIS` list is **empty**. The actual private Test's list contains **only** `FixedSpectrumCosineExpansion.actual_inverse_spectrum_cosine_expansion`. The recorded sealed private literal type application passed, with the standard three axioms. These are the original actual compilation receipts and their real historical heads, not fabricated current-head gates; nothing was rerun here.

The public interface assumes only real kappa≥2. Literal r, radius bounds, denominators, pointwise equality for all real theta, absolute summability and uniform convergence over all real angles for each fixed kappa are conclusions. There is no d/O/Gaussian/matrix/radius/convergence certificate premise. The reciprocal normalization is exactly `1/sqrt(kappa)`, the positive mode is `j+1` in Lean, and a partial sum indexed N has exactly N positive modes. There is no uniformity over unbounded kappa.

The private Test materially consumes identity and absolute summability, derives weighted summability, identifies the actual literal midpoint-grid reciprocal eigenvalue and invokes `Summable.tsum_finsetSum`. It is a deterministic all-natural-n intermediate. It does not evaluate aliases or prove C8 Gaussian moments; the future source restriction1≤n<d and finite corrections remain separate.

The current lesson has six coherent formula steps: radius; real part of the geometric sum; rational expression; exact normalization; absolute/uniform convergence; actual finite-grid interchange. No new mathematical exposition or premise was needed in this integration proposal. The eventual reader inspection must use this six-step C7 structure, not the earlier Geometry seven-step/three-parent browser assumptions. Exact initially folded Lean, local code scrolling, source/assumption disclosures, canonical case/index/declaration/module navigation and the private-consumer correspondence require actual inspection after application. No successful browser or pixel review is claimed here.

## Validated conceptual memory, with its original limits

The exact public candidate SHA256 is `bcd24a72d1409f6b0b6747d85116d3317cb51c0d0612d5789d0affd5b317cd1e`. The separate source/math reviewer `/root/cosine_topology_challenge` accepted it conceptually; review SHA256 `f2713fe98f49dab01172ca70b0a7489e2fa5fc93714239318d583f3eb5931c7d`. That original actor then issued one actual normal discovery validation. I checked its actual receipt, exact2096-byte sole append SHA256 `2df032e4ca73519ff924dc076a237e84f81a713b0ede6d35f190308fd4dab3d9`, and that today's discovery ledger equals its frozen original prefix plus that append. The actual receipt records39 preserved foreign discovery states; this preparation does not repeat or expand that earlier scan. Creator and validator are distinct. This is **not C7 source V**.

The new model preserves the reviewed formula, hypothesis/conclusion maps, key estimate and failure boundary. `status=not-Lean-certified`, `formal_refs=[]`, and explicit category identity/composition failures prevent a model label from becoming a certificate. A1 and C7 module links are candidate-substrate incidence, never producer parents. The existing A1 frontier keeps its full-statement source-underspecified verdict, n≥3 reviewed slice, n=2 mathematical extension and arbitrary-harmonic HFT-route debt. No old audit or historical candidate/capsule pending label is upgraded.

In particular: A1's positive pole, normalized surface law and denominator power n/2 differ from the auxiliary dimension2 circle/negative pole of C7. Pole rotation and angular/surface parametrization are missing adapters. Raw A1 integrals require the factor1−r² to obtain normalized mass1/mean r. The factor1/sqrt(kappa) remains in the inverse spectrum. Fixed-kappa convergence is not unbounded-kappa convergence. Continuous circle averaging is not the finite midpoint grid: aliases survive, and the bridge does not assert `M=d/sqrt(kappa)` or the source's corrected closed moments as a new theorem.

The eight payloads cite actual existing private review/validation originals with exact hashes; they do not invent public copies. `provenance-retention-plan.json` binds those originals. If root wants public lossless copies, exact destinations and the new model's evidence-path substitutions must be reviewed as a successor payload revision; absent public copies must never be presented as delivered artifacts.

## What actually remains before acceptance

1. The distinct source actor must finish actual whole-module/fresh Lean/source/standard-meaning review and issue a genuine normal current-binding V. Preserve original formalizer, decoder, verifier identities, candidate, publication binding and original evidence fields. This preparation grants no V or execution authority.
2. Sole stabilization owner must actually merge current main, retaining its ancestry, compare the two overlap results and all20 main-only files to A, and review the exact post-merge eight-path B patch. If either parent changes, rebind the affected exact bytes rather than project old checks forward. Genuine sole normal STAB and any reviewed lifecycle metadata follow actual sourceV; no event is assumed to exist now.
3. Run actual same-head official Lean/publication/fake-closure/site/graph gates on the immutable integrated core. Include main's existing Lower Bounds/SampleWiki and Bench focused regressions when exercising its merged reader changes. No unchanged4.8GB scan or broad source replay is supplied by this preparation; root's actual application guard remains responsible for preservation.
4. Obtain a separately scoped actual Chrome desktop/mobile reader run and independently inspect original images. Exercise C7's six steps, exact formulas, assumptions, folds/code/source paths, actual declaration/module native selections with zero producer ASTIS parents, the new dashed A1/C7 bridge, and main's Lower Bounds native selection/camera behavior while retaining old FirstOrder and DensityAffinity regressions. Script/DOM success is not pixel evidence. No old Geometry/FirstOrder screenshot count, approval prefix or acceptance is projected.

Both main lower bounds remain open. The unchanged determinant statement retains d≥1, kappa≥4, 0<epsilon≤1/16 and constant1/256. The unchanged fixed-spectrum statement retains fixed delta∈(0,1), d≥d0(delta),2≤kappa≤d^(1−delta),0<epsilon≤1/10 and delta/256. Both keep the actual centered Gaussian target, full real orthogonal family where applicable, exact precision/value-gradient oracle, Borel adaptive/private-seed/output model, uniform-input TV normalized by sup over measurable events, and a deterministic cap for every input/seed. TV alone does not transport unbounded expected cost. The old C4 strict-grid/Hessian-route residual text, all target/algorithm/precision/cost adapters and Section4.4 no-growing-log(1/epsilon)/Krylov-saturation limitation survive literally. Remote owner release, final publication, purification/Exposition Seal and the whole Goal are separate.

Preparation used only read-only Git/file operations and private archive generation. The first two private preparation attempts exposed a JSON actor-key mismatch and Python string/bytes concatenation error; both were corrected before the successful frozen run. They caused no shared mutation or mathematical finding. No source/API/build/browser/OS/network/model execution, actual merge, stage or commit occurred.
