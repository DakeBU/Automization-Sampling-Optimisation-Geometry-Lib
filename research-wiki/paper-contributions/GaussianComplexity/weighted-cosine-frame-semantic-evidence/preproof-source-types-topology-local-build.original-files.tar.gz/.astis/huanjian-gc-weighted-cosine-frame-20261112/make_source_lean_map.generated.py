"""Locate source formulas and the exact compiled proof and statement spans."""
from html.parser import HTMLParser
from pathlib import Path
import hashlib
import json

evidence = Path('research-wiki/paper-contributions/GaussianComplexity/weighted-cosine-frame-semantic-evidence')
raw = Path('.astis/huanjian-resume-20261103/2610.20492v1.html').read_bytes()
text = raw.decode()
sha = lambda data: hashlib.sha256(data).hexdigest()
assert sha(raw) == '6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
offsets = [0] + [i + 1 for i, char in enumerate(text) if char == '\n']


class SourceElements(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=False)
        self.stack = []
        self.elements = {}

    def source_offset(self):
        line, col = self.getpos()
        return offsets[line - 1] + col

    def handle_starttag(self, tag, attrs):
        if tag not in {'area', 'base', 'br', 'col', 'embed', 'hr', 'img', 'input', 'link', 'meta', 'param', 'source', 'track', 'wbr'}:
            self.stack.append((tag, dict(attrs).get('id'), self.source_offset()))

    def handle_endtag(self, tag):
        for i in range(len(self.stack) - 1, -1, -1):
            if self.stack[i][0] == tag:
                _, identifier, start = self.stack[i]
                if identifier:
                    self.elements[identifier] = (start, text.index('>', self.source_offset()) + 1)
                del self.stack[i:]
                return


parser = SourceElements()
parser.feed(text)


def source_span(identifier):
    first, last = parser.elements[identifier]
    data = text[first:last].encode()
    a, b = len(text[:first].encode()), len(text[:last].encode())
    assert raw[a:b] == data and f'id="{identifier}"'.encode() in data
    return {
        'source_id': identifier, 'char_start': first, 'char_end': last,
        'raw_utf8_start': a, 'raw_utf8_end': b,
        'lf_line_start': text.count('\n', 0, first) + 1,
        'lf_column0_start': first - text.rfind('\n', 0, first) - 1,
        'lf_line_end': text.count('\n', 0, last) + 1, 'span_sha256': sha(data),
    }


P = Path('AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumWeightedFrameBound.lean')
T = Path('Tests/GaussianComplexityFixedSpectrumWeightedFrameBound.lean')


def code_span(path, first, last):
    raw_code = path.read_bytes()
    lines = raw_code.splitlines(keepends=True)
    assert 1 <= first <= last <= len(lines)
    prefix, body = b''.join(lines[:first - 1]), b''.join(lines[first - 1:last])
    return {'path': str(path), 'file_sha256': sha(raw_code),
            'LF_lines_1based': [first, last],
            'raw_UTF8_byte_span': [len(prefix), len(prefix) + len(body)],
            'decoded_char_span': [len(prefix.decode()), len(prefix.decode()) + len(body.decode())],
            'span_sha256': sha(body)}


def mapping(identifiers, ranges, meaning):
    return {'source': [source_span(x) for x in identifiers],
            'lean': [code_span(*entry) for entry in ranges], 'meaning': meaning}



mappings = [
    mapping(['S4.Thmtheorem4.p1.m2', 'S4.Thmtheorem4.p1.m3'],
            [(P, 15, 16), (T, 15, 18)],
            'Standing source range, natural q including zero, r=q+1 and positive denominators.'),
    mapping(['S4.E11.m1', 'A3.SS2.p5.m2', 'A3.Ex85.m1'],
            [(P, 17, 22), (T, 21, 25)],
            'Literal half-grid, source row i.val+1, constant feature one and higher sqrt(2) cosine coordinates.'),
    mapping(['A3.Ex87.m1', 'A3.Ex102.m1'],
            [(P, 40, 51)],
            'Canonical compiled cosine-frame theorem supplies both squared feature norm and exact Gram. No new norm theorem.'),
    mapping(['A3.Ex116.m1', 'A3.Ex117.m1'],
            [(P, 14, 27), (P, 52, 61), (P, 62, 88)],
            'The source deterministic comparison is lifted by the identity tensor, positive scalar and exact d normalization. It has no Gaussian proof premise.'),
    mapping(['A3.SS2.p1.m1', 'A3.SS2.p1.m5', 'A3.SS2.p10.m1', 'A3.SS2.p10.m2'],
            [(T, 16, 20), (T, 36, 40), (T, 63, 69)],
            'Actual canonical single-row Gaussian, radius and closed cutoff. Original experiment row-map and marginal transport remain open.'),
    mapping(['A3.Ex107.m1'], [(T, 26, 33), (T, 44, 62)],
            'Actual Gaussian-first paired-index Kronecker row template, inverse-d scaling and sum of marginal second moments.'),
    mapping(['A3.Ex113.m1'],
            [(T, 63, 66), (T, 153, 166)],
            'The same canonical radial fourth matrix theorem supplies both actual integrability and exact mean, materially used through each tensor map.'),
    mapping(['A3.SS2.p14.m2', 'A3.SS2.p14.m3', 'A3.Ex114.m1'],
            [(T, 71, 105)],
            'Ordinary rank-one and Kronecker squares, indicator idempotence and the actual square integrability.'),
    mapping(['A3.SS2.p14.3', 'A3.Ex115.m1', 'A3.Ex115.m2'],
            [(T, 106, 152), (T, 167, 172)],
            'PSD truncation deletion, integrability of finite sums, real PSD cone integration and exact aggregate mean.'),
    mapping(['A3.Ex115.m2', 'A3.Ex116.m1', 'A3.Ex117.m1'],
            [(T, 173, 179)],
            'Actual compiled deterministic producer is consumed to close the uncentered marginal second-moment sum, with no original-family or centered-variance credit.'),
]
draft = json.loads((evidence / 'publication-draft-record.json').read_bytes())
record = {
    'kind': 'Root-authored exact source/Lean map for independent review',
    'source_sha256': sha(raw),
    'actual_ASTIS_proof_parents': draft['actual_public_ASTIS_parents'],
    'mappings': mappings,
    'proof_background': [
        {'declaration': 'AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumCosineGram.actual_cosine_frame_gram',
         'source': code_span(Path('AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumCosineGram.lean'), 14, 26),
         'consumer': code_span(P, 40, 51),
         'meaning': 'One canonical emitted node supplies both norm and Gram conclusions.'},
        {'declaration': 'Matrix.PosSemidef.kronecker',
         'source': code_span(Path('.lake/packages/mathlib/Mathlib/Analysis/Matrix/Order.lean'), 213, 220),
         'consumer': code_span(P, 62, 69), 'meaning': 'Tensoring positive matrices preserves PSD order.'},
        {'declaration': 'AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumRadialFourthMoment.actual_radial_fourth_moment_matrix',
         'source': code_span(Path('AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumRadialFourthMoment.lean'), 23, 34),
         'consumer': code_span(T, 63, 66), 'meaning': 'Actual canonical fourth matrix moment and its integrability.'},
        {'declaration': 'Convex.integral_mem',
         'source': code_span(Path('.lake/packages/mathlib/Mathlib/Analysis/Convex/Integral.lean'), 57, 65),
         'consumer': code_span(T, 134, 152), 'meaning': 'Closed convex real PSD cone contains the aggregate residual integral.'},
    ],
    'mathlib_pin': 'db584cd6d46c92f209a44c0f1c829460d327499d',
    'scope': 'Exact deterministic EGx11 coefficient and canonical integrable marginal second-moment sum. Original-family adapters, centered variance, concentration, main bounds and integrated reader remain open.',
}
path = evidence / 'source-lean-map.draft.json'
with path.open('x') as out:
    json.dump(record, out, ensure_ascii=False, indent=2)
    out.write(chr(10))
print(json.dumps({'path': str(path), 'sha256': sha(path.read_bytes()),
                  'source_locator_entries': sum(len(m['source']) for m in mappings),
                  'Lean_spans': sum(len(m['lean']) for m in mappings)}))
