"""Separately authorized owned local decisions only. Never calls a lifecycle API."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, struct, subprocess, sys
sys.dont_write_bytecode = True
R=Path('/Users/zhouhuanjian/ASTIS-GC')
B=R/'.astis/huanjian-gc-fixed-spectrum-first-order-integration-20261108'
S=B/'independent-reader'
P=R/'.astis/semantic-neutral-20261108/src_4e8f6a/normalpark-preparation-v2'
D=S/'local-acceptance-and-normalpark-eligibility-v4'
CORE='9b1e90d25711668203c6e252cfe5a748f95c8ad4'
CHECKED='9d306d837fbddf1518b0035494baaf5c21c24488'
FIRSTV='f45ba48f7dc74db28f648c38c5a486615723a513'
REVIEWER='/root/norm_integration_reader'
ACTOR='/root/source_reader_4e8f6a'
OWNER='huanjian_gc_20261108_fixed_spectrum_first_order'
INTEGRATOR='huanjian_gc_20261108_fixed_spectrum_first_order_integration'
ADV='ASTIS-SA-20261108-GaussianComplexityFixedSpectrumFirstOrder'
sha=lambda b:hashlib.sha256(b).hexdigest()
canonical=lambda x:json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
ref=lambda p:{'path':str(p.relative_to(R)),'sha256':sha(p.read_bytes())}
def readref(row):
 p=(R/row['path']).resolve();assert p.is_relative_to(R)
 raw=p.read_bytes();assert sha(raw)==row['sha256'];return json.loads(raw)
def git(*args):return subprocess.check_output(['git',*args],cwd=R)
def dump(p,value):
 assert not p.exists(),p
 p.write_bytes((json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode());return ref(p)

auth_path=B/'root-local-acceptance-v4-authorization.json'
assert sha(auth_path.read_bytes())=='fb86cc2f5ed175dd105dbb6721cb1da091e046c5f104c35959c4c1f56978d405'
a=json.loads(auth_path.read_bytes())
assert a['authorized_by']=='/root' and a['reviewer']==REVIEWER
assert a['authorization']=='SEPARATE_INDEPENDENT_LOCAL_ACCEPTANCE_AND_NORMALPARK_ELIGIBILITY_REVIEW_ONLY'
assert a['accepted_immutable_core']==CORE and a['candidate_source_checked_commit']==CHECKED
assert all(a[k] is False for k in ['normalpark_execution_authorized','lifecycle_API_authorized','new_source_verdict_authorized','browser_rerun_authorized','canonical_or_shared_edits_authorized'])
ctx=readref(a['context']);bound=readref(a['bound_context_review']);browser=readref(a['actual_browser_report']);receipt=readref(a['actual_browser_receipt']);pixel=readref(a['pixel_review']);pixel_freeze=readref(a['pixel_freeze']);root8=readref(a['root_actual8_review']);park_review=readref(a['root_guarded_park_preparation_review'])
assert bound['status']==pixel['status']=='accepted' and bound['scope']=='CONTEXT_CONSISTENCY_ONLY'
assert bound['accepted_immutable_core']==pixel['accepted_immutable_core']==ctx['accepted_immutable_core']==CORE
assert bound['context_raw_sha256']==a['context']['sha256']
assert bound['reviewer']==pixel['reviewer']==REVIEWER and REVIEWER not in [ACTOR,OWNER,INTEGRATOR,'/root']
assert bound['new_source_verdict'] is False and pixel['new_source_verdict'] is False and pixel['independent_from_browser_executor'] is True
assert pixel['blocking_objections']==bound['blocking_objections']==root8['blocking_objections_in_root_eight_actual_views']==park_review['blocking_objections_to_guarded_future_use']==[]
assert ctx['source_verifier_to_preserve']==ACTOR and ctx['source_V_first_carrying_commit']==FIRSTV
assert ctx['new_source_verdict'] is False and ctx['parking_authorized'] is False
assert browser['status']=='passed' and browser['errors']==[]
assert browser['head']==browser['site_commit']==browser['actual_gate_commit']==CORE
assert browser['candidate_commit']==CHECKED and browser['authorization']==a['context']
assert browser['source_digest']==ctx['source_digest']=='18bcbfebf85cdf214e00cff1fa6d72c4bbf344a6c09bc76340efc783a3803c39'
assert browser['actual_gate_sha256']==ctx['actual_gate']['sha256'] and browser['site_metadata_sha256']==ctx['site_metadata']['sha256']
assert browser['UI_repair']==ctx['reviewed_UI_repair'] and browser['external_GitHub_HTML_checked'] is False
assert receipt['exit_code']==0 and receipt['head_before']==receipt['head_after']==CORE
log=Path(receipt['log']);assert sha(log.read_bytes())==receipt['log_sha256']
summary=json.loads(log.read_bytes());assert summary['status']=='passed' and summary['screenshots']==38 and Path(summary['report'])==R/a['actual_browser_report']['path']
assert len(browser['pages'])==2 and len(browser['graphs'])==4 and len(browser['screenshots'])==38
image_map={x['file']:x['sha256'] for x in browser['screenshots']};assert len(image_map)==38
assert {x['file']:x['sha256'] for x in pixel['reviewed_images']}==image_map
for row in pixel['reviewed_images']:
 assert row['viewed_original'] is True and row['status']=='accepted'
 raw=(R/a['actual_browser_report']['path']).parent.joinpath(row['file']).read_bytes()
 assert sha(raw)==row['sha256'] and struct.unpack('>II',raw[16:24]) in [(1440,1000),(390,844)]
assert pixel['browser_report_sha256']==a['actual_browser_report']['sha256']
for row in root8['actually_viewed_originals']:assert row['viewed_original'] is True and image_map[row['file']]==row['sha256']
gate=readref(ctx['actual_gate']);meta=readref(ctx['site_metadata'])
assert gate['passed'] and meta['gate']['passed'] and meta['gate']['current'] and gate['commit']==meta['git']['commit']==CORE
assert set(ctx['actual_checks_before_browser'])=={'canonical_lean','publication','contributor','semantic','frontier','site_build','site_check','graph_check'}
for role,rr in ctx['actual_checks_before_browser'].items():
 r=readref(rr);assert r['exit_code']==0 and r['head_before']==r['head_after']==CORE
 assert sha(Path(r['log']).read_bytes())==r['log_sha256']
rb=browser['authorization_readback'];ui=ctx['reviewed_UI_repair']
assert rb['foreign_tracked_raw_bytes_preserved'] is False and rb['all_other_foreign_tracked_raw_bytes_preserved'] is True
assert rb['protected_other_raw_files_checked']==125206 and rb['unchanged_foreign_states']==284
assert all(rb['reviewed_one_path_UI_exception'][k]==v for k,v in ui.items())
assert sha((R/ui['source_path']).read_bytes())==ui['after_sha256']=='016c11a60392c449ebb28e8bedc7d3ab69134fff8dde4b438fd06c9f6c951a3a'
assert (R/ui['source_path']).read_bytes()==(R/ui['generated_asset_path']).read_bytes()==git('show',CORE+':'+ui['source_path'])
rows=browser['native_selection_geometry'];assert len(rows)==8
assert {(x['width'],x['route']) for x in rows}=={(w,r) for w in [1440,390] for r in ['native-Lean-parent','native-Lean-module','emitted-Functor-preset-with-query','native-Functor-to-Lean-module']}
inside=lambda x,y:x['left']>=y['left']-1 and x['right']<=y['right']+1 and x['top']>=y['top']-1 and x['bottom']<=y['bottom']+1
for row in rows:
 g=row['geometry'];assert g['ok'] and all(g['checks'].values()) and len(g['checks'])==14 and g['camera_actions_by_harness']==[]
 assert g['selected_main_rect']['width']>=160 and g['rendered_label_font_px']>=10
 for outer in ['svg','canvas','viewport']:assert inside(g['selected_main_rect'],g[outer]) and inside(g['rendered_label'],g[outer])
 assert inside(g['rendered_label'],g['selected_main_rect'])
 if row['route'] in ['emitted-Functor-preset-with-query','native-Functor-to-Lean-module']:assert row['pixel_review_claim'] is False and row['extra_screenshot'] is False and 'main_original' not in row

# Current bounded preservation readback. Replay is a pure read; no transition API.
b=json.loads((P/'preservation-baseline.json').read_bytes())
assert sha((P/'preservation-baseline.json').read_bytes())==park_review['bindings']['baseline_sha256']
assert git('rev-parse','HEAD').decode().strip()==CORE and not git('diff','--name-only',CORE).strip()
assert sha(git('ls-files','-s','-z'))==b['git_index_entries_sha256']
ledger=R/'runs/substantive_advances.jsonl';ledger_raw=ledger.read_bytes()
assert ledger_raw==(P/'ledger-before-park.exact.jsonl').read_bytes() and sha(ledger_raw)==b['ledger_before_sha256']
assert sha((R/'runs/substantive_discoveries.jsonl').read_bytes())==b['discovery_sha256']
for key in ['critical_raw_pins','frozen_originals']:
 for path,h in b[key].items():assert sha((R/path).read_bytes())==h,path
frontiers={p.relative_to(R).as_posix():sha(p.read_bytes()) for p in sorted((R/'research-wiki/frontier-cells').rglob('*.json'))}
assert frontiers==b['frontier_raw_hashes'] and len(frontiers)==444
sys.path.insert(0,str(R));from tools import astis_advance as advance
states=advance._replay_advances([json.loads(x) for x in ledger_raw.splitlines() if x.strip()])
assert len(states)==285 and sha(canonical({k:v for k,v in states.items() if k!=ADV}))==b['foreign_284_SAU_state_sha256']
assert states[ADV]==b['own_STAB_state'] and states[ADV]['state']=='STABILIZING'
assert [k for k,v in states.items() if v['state']=='STABILIZING']==[ADV]
assert states[ADV]['owner_id']==OWNER and states[ADV]['last_actor']==INTEGRATOR
vraw=(P/'original-V306.exact.jsonl').read_bytes();sraw=(P/'original-STAB621.exact.jsonl').read_bytes();V=json.loads(vraw)
assert sha(vraw)==ctx['source_V_append']['sha256']==b['original_V_append_sha256']
assert sha(sraw)==ctx['STAB_append']['sha256']==b['STAB_append_sha256']
assert ledger_raw.count(vraw)==ledger_raw.count(sraw)==1
assert V['worker_id']==V['evidence']['verifier_id']==ACTOR and V['evidence']['verified_commit']==CHECKED
assert sha(canonical(V['evidence']))==b['original_V_evidence_canonical_sha256'] and len(V['evidence'])==10
assert 'post_integration_normalpark' not in V['evidence']
audit=readref(ctx['accepted_source_audit']);assert audit['state']=='accepted' and sha((R/ctx['accepted_source_audit']['path']).read_bytes())==b['source_audit_sha256_to_preserve']
for p in ['AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumFirstOrder.lean','Tests/GaussianComplexityFixedSpectrumFirstOrder.lean']:
 assert (R/p).read_bytes()==git('show',CHECKED+':'+p)==git('show',CORE+':'+p)
for ancestor in [CHECKED,FIRSTV]:subprocess.check_call(['git','merge-base','--is-ancestor',ancestor,CORE],cwd=R)
prep_manifest=json.loads((P/'preparation-manifest.json').read_bytes())
for row in prep_manifest['artifacts']:assert sha((P/row['path']).read_bytes())==row['sha256']
assert len(prep_manifest['artifacts'])==23 and prep_manifest['bindings']==park_review['bindings']
assert not (P.parent/'normalpark-execution-v2/execution-started.json').exists()

D.mkdir(exist_ok=True);now=datetime.now(timezone.utc).isoformat()
preservation={'readback_utc':now,'core':CORE,'tracked_diff_clean':True,'ledger_sha256':sha(ledger_raw),'original_V_append_sha256':sha(vraw),'original_STAB_append_sha256':sha(sraw),'original_V_evidence_all10_fields_exact':True,'original_V_evidence_canonical_sha256':sha(canonical(V['evidence'])),'current_SAU_count':285,'foreign_SAU_count':284,'sole_STAB':ADV,'current_STAB_owner':INTEGRATOR,'frontier_bytes_checked':444,'critical_raw_pins_checked':len(b['critical_raw_pins']),'frozen_originals_checked':len(b['frozen_originals']),'park_v2_payloads_checked':23,'API_transition_calls':0,'new_source_verdict':False}
pr=dump(D/'actual-preservation-readback.json',preservation)
shared={'authorized_by':'/root','reviewer':REVIEWER,'recorded_utc':now,'authorization':ref(auth_path),'accepted_immutable_core':CORE,'source_checked_commit_to_preserve':CHECKED,'source_V_first_carrying_commit':FIRSTV,'original_source_verifier':ACTOR,'original_source_audit_scope':'Existing original STATIC source review preserved; no new source verdict.','new_source_verdict':False,'remote_acceptance':False,'wholeGoal_or_full_mains_claim':False,'postmerge_purification_or_Exposition_Seal_credit':False,'historical_parent_audit_upgrade':False,'lifecycle_API_called':False,'normalpark_execution_authorized':False,'preservation_readback':pr,'reviewed_UI_repair':ui,'foreign_tracked_raw_bytes_preserved':False,'all_other_foreign_tracked_raw_bytes_preserved':True,'preservation_qualification':ui['preservation_qualification']}
local={**shared,'schema':'independent-local-integration-acceptance-v4','status':'accepted','scope':'LOCAL_CURRENT_INTEGRATION_UI_ACCEPTANCE_ONLY','browser_report_sha256':a['actual_browser_report']['sha256'],'pixel_review_sha256':a['pixel_review']['sha256'],'bound_context_review_sha256':a['bound_context_review']['sha256'],'all38_original_pixels_reviewed':True,'bound_context_review':a['bound_context_review'],'actual_browser_report':a['actual_browser_report'],'actual_browser_receipt':a['actual_browser_receipt'],'pixel_review':a['pixel_review'],'root_actual8_review':a['root_actual8_review'],'all8_actual_same_core_gates':ctx['actual_checks_before_browser'],'native_geometry_rows':8,'extra_DOM_only_rows':4,'old_DensityAffinity_DOM_only_regressions':2,'blocking_objections':[],'limits':pixel['nonblocking_viewport_limits']}
local_ref=dump(S/'local-v4-acceptance.json',local)
eligible={**shared,'schema':'independent-existing-sourceV-normalpark-eligibility-v4','status':'eligible','eligible_for_normal_park':True,'scope':'READ_ONLY_MECHANICAL_EXISTING_VERIFIED_PARK_ELIGIBILITY_ONLY','from_state':'STABILIZING','to_state':'VERIFIED','source_V_append_sha256':sha(vraw),'STAB_append_sha256':sha(sraw),'accepted_source_audit_sha256':b['source_audit_sha256_to_preserve'],'local_acceptance_sha256':local_ref['sha256'],'pixel_review_sha256':a['pixel_review']['sha256'],'bound_context_review_sha256':a['bound_context_review']['sha256'],'local_acceptance':local_ref,'pixel_review':a['pixel_review'],'no_new_source_verdict':True,'required_executing_actor':ACTOR,'required_proof_owner':OWNER,'current_STAB_owner':INTEGRATOR,'advance_id':ADV,'original_verified_commit_to_preserve':CHECKED,'original_V_all10_evidence_fields_to_preserve':list(V['evidence']),'original_V_evidence_canonical_sha256':sha(canonical(V['evidence'])),'only_future_new_evidence_key':'post_integration_normalpark','future_park_bindings':prep_manifest['bindings'],'root_park_preparation_review':a['root_guarded_park_preparation_review'],'separate_actual_bundle_preflight_and_exact_root_execution_authorization_still_required':True,'blocking_objections':[]}
eligible_ref=dump(S/'normalpark-v4-eligibility.json',eligible)
assert ledger.read_bytes()==ledger_raw and not git('diff','--name-only',CORE).strip()
print(json.dumps({'local_acceptance':local_ref,'normalpark_eligibility':eligible_ref,'actual_preservation':pr,'normal_API_called':False,'new_source_verdict':False,'execution_of_park_authorized':False}))
