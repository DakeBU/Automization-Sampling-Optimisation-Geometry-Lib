from pathlib import Path
import subprocess,json,hashlib,datetime,sys,stat
BASE=Path(__file__).resolve().parent;ROOT=BASE.parent
def sha(b):return hashlib.sha256(b).hexdigest()
cmd=['/opt/anaconda3/bin/python','-B',str(BASE/'freeze.py')]
start=datetime.datetime.now(datetime.timezone.utc).isoformat()
r=subprocess.run(cmd,cwd='/Users/zhouhuanjian/ASTIS-GC',capture_output=True)
receipt={'schema':'original-actual-execution-receipt-v1','command':cmd,'cwd':'/Users/zhouhuanjian/ASTIS-GC','start_utc':start,'end_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'actual_returncode':r.returncode,'actual_stdout_utf8':r.stdout.decode('utf-8'),'actual_stderr_utf8':r.stderr.decode('utf-8'),'stdout_bytes':len(r.stdout),'stdout_sha256':sha(r.stdout),'stderr_bytes':len(r.stderr),'stderr_sha256':sha(r.stderr),'status_authority':'Actual subprocess result; not a synthesized success marker. It certifies execution/freezing only, not mathematics or source review.'}
rp=ROOT/'phase1-freeze-execution-receipt.json';rp.write_text(json.dumps(receipt,indent=2,ensure_ascii=False)+'\n');rp.chmod(0o444)
if r.returncode!=0:
    print(json.dumps(receipt,indent=2,ensure_ascii=False));sys.exit(r.returncode)
result=json.loads(r.stdout)
index={'schema':'source-only-phase1-freeze-index-v1','phase1_manifest':{'path':'phase1/phase1-manifest.json','bytes':(BASE/'phase1-manifest.json').stat().st_size,'sha256':sha((BASE/'phase1-manifest.json').read_bytes()),'mode':'0444'},'original_actual_execution_receipt':{'path':rp.name,'bytes':rp.stat().st_size,'sha256':sha(rp.read_bytes()),'mode':'0444'},'result':result,'self_binding':'Exact index SHA256 is printed by run_freeze.py and reported to parent; the index has no recursive self-hash. The Phase1 content manifest plus manifest/receipt bindings cover all original frozen Phase1 bytes.','post_freeze_phase2_rule':'Do not modify phase1; new selective-type artifacts go in a separate phase2 directory.'}
ip=ROOT/'phase1-freeze-index.json';ip.write_text(json.dumps(index,indent=2,ensure_ascii=False)+'\n');ip.chmod(0o444)
print(json.dumps({'index_path':str(ip),'index_sha256':sha(ip.read_bytes()),'manifest_sha256':index['phase1_manifest']['sha256'],'original_actual_receipt_sha256':index['original_actual_execution_receipt']['sha256'],'key_sha256':result['key_sha256'],'total_phase1_files':result['total_phase1_files'],'file_modes':'0444','directory_modes':'0555','write_scope_pristine':False,'actual_freeze_exit':r.returncode},indent=2))
