from pathlib import Path
from collections import Counter
import hashlib,json
root=Path('/Users/zhouhuanjian/ASTIS-GC')
base=root/'.astis/huanjian-gc-fixed-spectrum-mode-gap-20261110/independent-source-graph'
p1=base/'phase1';out=base/'phase2'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
load=lambda p:json.loads(p.read_text())
enc=lambda x:(json.dumps(x,indent=2,ensure_ascii=False)+'\n').encode()
canonical=lambda x:hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()
assert sha(p1/'phase1-freeze.json')=='dfbb1b9dd061aea5e4d846758c4a4174fd68b76d7e9e3ab7d501c98dc5af5359'
frozen=load(p1/'phase1-freeze.json')
for a in frozen['artifacts']:assert sha(root/a['path'])==a['sha256']
projection=root/'.astis/huanjian-gc-fixed-spectrum-mode-gap-20261110/strict-preproof-seal-projection-v2.json'
assert sha(projection)=='54b23ce1ccd86b780b8c2b38bb18ac3cf91b5102afefe15444b2231e1b65c0f9'
s=load(projection)
for role in ['producer','actual_private_consumer']:assert hashlib.sha256(s[role]['signature'].encode()).hexdigest()==s[role]['signature_sha256']
raw=load(p1/'raw-unit-inventory.json');hist=load(p1/'raw-unit-dispositions.json')['rows'];byid={u['id']:u for u in raw['units']}
seal_sha='1f9228d5caa180bc26ae9e47dc86b2d4be074c499b670a9a9a639da67457fb0c'
nodes=[];routes=[]
def node(i,kind,statement,anchors=(),role='source',note=None):
 nodes.append({'id':i,'kind':kind,'statement':statement,'role':role,'source_anchors':[{'id':a,'raw_unit_ordinal':byid[a]['raw_unit_ordinal'],'source_unit_key':byid[a]['source_unit_key'],'original_lines':byid[a]['original_lines'],'math':byid[a]['math'],'references':byid[a]['references'],'raw_fragment_sha256':byid[a]['raw_html_LF_fragment_sha256']} for a in anchors],'status':'OPEN_INTERNAL_OBLIGATION' if kind in ['SOURCE_GAP','LOCAL_INTERNAL_OBLIGATION'] else 'SOURCE_OR_TARGET_STATEMENT_NOT_CERTIFIED_PROVED','note':note})
def edge(i,consumer,inputs,sites,description):
 routes.append({'id':i,'consumer':consumer,'inputs':inputs,'logic':'AND','consumer_use_sites':[{'id':a,'raw_unit_ordinal':byid[a]['raw_unit_ordinal'],'original_lines':byid[a]['original_lines']} for a in sites],'description':description,'discharge':'Proof dependencies, including uniform threshold/domain guards, are established internally. They are never new public hypotheses, assumed callbacks or compiled-parent claims.'})
# Scalar source prerequisite: all bounds retain the original quantifier order.
node('S_delta','SOURCE_FIXED_PARAMETER','Fix real δ with 0<δ<1 before choosing any threshold.',('S4.Thmtheorem1.p1.1','S4.SS3.p2.1'),role='scalar-producer')
node('S_regime','SOURCE_CONDITIONAL_DOMAIN','After one d0(δ), quantify every natural d≥d0, every real κ with 2≤κ≤(d:ℝ)^(1−δ), and every natural q with (q:ℝ)≤(δ/256)√κ log(d:ℝ). All these conditional premises are inside the eventual universal conclusion.',('S4.SS3.p2.1',),role='scalar-producer')
node('S_mode','LITERAL_SOURCE_DEFINITION','n=2q+1 in Nat. The cast identity is (n:ℝ)=2(q:ℝ)+1; the mode is positive for every q:Nat.',('S4.Ex12','S4.SS3.p3.1'),role='scalar-producer')
node('G_large_dimension_domain','SOURCE_GAP','Choose a natural lower cutoff depending only on δ (it may be enlarged internally) so all considered d are≥2 and real d>0/log d≥0. Justify casts and ordinary real-power/sqrt domains before comparisons.',('S4.SS3.SSS0.Px1.p1.1','S4.SS3.SSS0.Px1.p1.2'),role='scalar-producer')
node('G_alpha_domain','SOURCE_GAP','Set α=(1−δ)/2 only as mathematical notation; derive 0<α<1 from the fixed source 0<δ<1. No new exponent premise.',('S4.SS3.SSS0.Px1.p1.1','S4.SS3.SSS0.Px2.p2.1'),role='scalar-producer')
node('N_sqrt_envelope','SOURCE_ESTIMATE','Uniformly over κ in the source range, √κ≤d^((1−δ)/2)=d^α for positive d.',('S4.SS3.SSS0.Px2.p2.1',),role='scalar-producer')
node('G_sqrt_rpow_order','SOURCE_GAP','Derive the square-root/power envelope from κ≤d^(1−δ) on the actual positive domain; establish real-power multiplication/sqrt identities and monotonicity.',('S4.SS3.SSS0.Px2.p2.1',),role='scalar-producer')
node('G_coarse_query_bridge','SOURCE_GAP','From the exact δ/256 query bound, √κ envelope and positive log d, obtain the source eventual coarse estimate q+1≤d^α log d uniformly in κ,q, including absorption of the natural +1. Its cutoff may depend on δ only.',('S4.SS3.SSS0.Px1.p1.1',),role='scalar-producer')
node('N_query_envelope','SOURCE_ESTIMATE','For sufficiently large d depending only on δ and all allowed κ,q, q+1≤d^α log d.',('S4.SS3.SSS0.Px1.p1.1',),role='scalar-producer')
node('G_power_log_growth','SOURCE_GAP','For the fixed 0<α<1, establish d^α log d/d→0 and d^α/d→0 along natural dimensions, with positive d and the required growth for the coarse +1 absorption.',('S4.SS3.SSS0.Px1.p1.1','S4.SS3.SSS0.Px2.p2.1'),role='scalar-producer')
node('N_uniform_mode_small','SOURCE_UNIFORM_ASYMPTOTIC','n=o(d) uniformly over all κ,q satisfying the original domain: for each η>0 there is a cutoff depending on δ,η only, after which n/d<η for every allowed κ,q.',('S4.SS3.SSS0.Px1.p1.1',),role='scalar-producer',note='The paper writes n=o(d). Its uniform envelope/cutoff interpretation must be proved internally, not inferred from separate per-κ or per-q limits.')
node('N_uniform_sqrt_small','SOURCE_UNIFORM_ASYMPTOTIC','√κ=o(d) uniformly over allowed κ via √κ≤d^α: each η>0 has a δ,η-only cutoff valid for every κ,q in the range.',('S4.SS3.SSS0.Px2.p2.1',),role='scalar-producer')
node('G_mode_eventual_lt','SOURCE_GAP','Discharge the uniform small-mode consequence n<d eventually, with one δ-only natural cutoff.',('S4.SS3.SSS0.Px1.p1.2',),role='scalar-producer')
node('N_mode_lt','SOURCE_EVENTUAL_ESTIMATE','For all sufficiently large d depending only on δ and all source κ,q, n<d.',('S4.SS3.SSS0.Px1.p1.2',),role='scalar-producer')
node('G_gap_eventual_bridge','SOURCE_GAP','Combine the two uniform o(d) controls into eventual n+√κ≤d, equivalently √κ≤(d:ℝ)−(n:ℝ), with a δ-only cutoff. The paper omits the threshold-intersection/rearrangement details.',('S4.SS3.SSS0.Px2.p2.1',),role='scalar-producer')
node('N_uniform_gap','SOURCE_EVENTUAL_ESTIMATE','For all sufficiently large d depending only on δ and every allowed κ,q, √κ≤(d:ℝ)−(n:ℝ).',('S4.SS3.SSS0.Px2.p2.1',),role='scalar-producer')
node('G_common_threshold','SOURCE_GAP','Select a common natural cutoff for large-d domains, mode bound and gap. Existential d0 precedes all d,κ,q universals; cannot choose it after κ,q or change ∀κ∀q to a fixed sequence.',('S4.SS3.SSS0.Px1.p1.2','S4.SS3.SSS0.Px2.p2.1'),role='scalar-producer')
node('P_root','EXACT_PRODUCER_ROOT','∃d0:Nat, ∀d≥d0 ∀κ with2≤κ≤d^(1−δ) ∀q:Nat with q≤(δ/256)√κ log d, let n=2q+1; 2≤d ∧1≤n ∧n<d ∧√κ≤(d:ℝ)−(n:ℝ).',('S4.SS3.SSS0.Px1.p1.1','S4.SS3.SSS0.Px1.p1.2','S4.SS3.SSS0.Px2.p2.1'),role='scalar-producer',note='Source prerequisite only. No Gaussian/variance/API dependency belongs to this scalar source root.')
node('P_source_domain_projection','PRODUCER_OUTPUT_PROJECTION','Use the produced uniform d≥2, positive source mode, n<d and real gap when applying the actual diagonal bias statement, under the same scalar conditional regime.',('S4.SS3.SSS0.Px2.p2.1',),role='private-consumer')
# Actual Gaussian/C.3 bias prerequisites, independent of scalar asymptotic construction.
node('A_objects','LITERAL_SOURCE_DEFINITIONS','θ_i=(i−1/2)π/d, λ_i=(κ+1)/2+(κ−1)cosθ_i/2, Λ=diag λ, ρ=(√κ−1)/(√κ+1), D_n=diag cos(nθ_i); μ=N(0,Λ⁻¹), actual Q=Σcos(nθ_i)x_i², M=∫‖x‖²dμ and b=∫Qdμ=source μ_n.',('S2.p1.1','S4.E11','S4.Thmtheorem5.p1.1'),role='actual-law-prerequisite')
node('G_actual_domains','SOURCE_GAP','From produced d≥2 and source κ≥2, derive 1≤λ_i≤κ, positive diagonal precision and inverse covariance, √κ>1 and0<ρ<1. No PSD/inverse/denominator certificate is a caller input.',('S4.E11','A3.SS3.p8.1','A3.SS3.p9.1'),role='actual-law-prerequisite')
node('G_actual_gaussian','SOURCE_GAP','Certify the displayed measure is the actual probability Gaussian with covariance Λ⁻¹ and centered coordinate variances1/λ_i; derive finite second moments/integrability of the two actual quadratics before using their real integrals.',('S4.Thmtheorem5.p1.1','A3.SS3.p4.1'),role='actual-law-prerequisite')
node('N_mean_sums','SOURCE_PREREQUISITE','M=Σ1/λ_i and b=Σcos(nθ_i)/λ_i, from actual Gaussian moments and finite-sum quadratic identities.',('A3.SS3.p4.1','A3.Ex140'),role='actual-law-prerequisite',note='Source prerequisite; no new compiled mean API or prior verification is certified.')
node('G_finite_mean_bridge','SOURCE_GAP','Measurable finite coordinate sums, Euclidean norm/diagonal quadratic expansion, and finite-sum expectation linearity establish actual mean identities. Totalized nonintegrable integral defaults cannot be used.',('A3.Ex140',),role='actual-law-prerequisite')
node('G_C7_series','SOURCE_GAP','Geometric complex series, cosine identities, algebraic ρ substitutions and geometric majorant establish Fact C.7 inverse-spectrum expansion with absolute/uniform convergence.',('A3.Thmtheorem7','A3.Ex133','A3.EGx14','A3.Ex136','A3.Ex137'),role='actual-law-prerequisite')
node('G_grid_alias','SOURCE_GAP','Evaluate Σcos(kθ_i) for every integer k, prove the finite-cosine formula and nonzero/special2d cases, and justify the source alias arithmetic.',('A3.Ex139','A3.SS3.p3.2'),role='actual-law-prerequisite')
node('G_finite_series_interchange','SOURCE_GAP','Use absolute convergence to interchange the cosine series with finite-grid sums, not a formal unjustified infinite rearrangement.',('A3.SS3.p4.2',),role='actual-law-prerequisite')
node('N_exact_M','SOURCE_PREREQUISITE','M=(d/√κ)(1−ρ^(2d))/(1+ρ^(2d)); retain only j=2ad and sum the convergent geometric series.',('S4.EGx1','A3.Ex138','A3.SS3.p5.1','A3.EGx15'),role='actual-law-prerequisite')
node('G_b_alias_classes','SOURCE_GAP','Use product-to-sum and the disjoint classes j=n,2ad+n,2ad−n under1≤n<d, including parity and convergent resummation.',('A3.SS3.p6.1','A3.Ex144','A3.SS3.p6.2'),role='actual-law-prerequisite')
node('N_exact_signed_b','SOURCE_PREREQUISITE','(−1)^n b=(d/√κ)(ρ^n−ρ^(2d−n))/(1+ρ^(2d)).',('S4.EGx1','A3.Ex138','A3.EGx16'),role='actual-law-prerequisite')
node('G_actual_positivity','SOURCE_GAP','Actual exact M>0 and signed b>0 follow from positive prefactors,0<ρ<1 and n<d. Justify every denominator and strict power-order comparison internally.',('A3.Ex138','A3.SS3.p9.1'),role='actual-law-prerequisite')
node('N_M_positive','SOURCE_IMPLICIT_OUTPUT','0<M for the displayed actual integral.',('A3.Ex138','A3.Ex150'),role='actual-law-prerequisite')
node('N_signed_b_positive','SOURCE_OUTPUT','0<(−1)^n b for the actual signed mean.',('A3.SS3.p9.1',),role='actual-law-prerequisite')
node('G_actual_ratio','SOURCE_GAP','Use actual positive M and signed b to convert sign to |b| and divide the exact mean formulas; prove power factoring and positive denominator identities.',('A3.SS3.p9.1','A3.Ex150'),role='actual-law-prerequisite')
node('N_ratio','SOURCE_IDENTITY','|b|/M=ρ^n(1−ρ^(2(d−n)))/(1−ρ^(2d)); a ratio of means, not an expected pointwise ratio.',('A3.Ex150',),role='actual-law-prerequisite')
node('N_correction_lower','SOURCE_ESTIMATE','1−ρ^(2(d−n))≤(1−ρ^(2(d−n)))/(1−ρ^(2d)), with positive denominator.',('A3.SS3.p9.2','A3.Ex151'),role='actual-law-prerequisite')
node('G_log_integral_domains','SOURCE_GAP','0<1/√κ<1; prove continuity/integrability on the nonsingular interval, log-ratio fundamental-theorem identity, integral split and elementary t² evaluation.',('A3.Ex152','A3.Ex153','A3.Ex154','A3.Ex155','A3.Ex156'),role='actual-law-prerequisite')
node('N_log_identity','SOURCE_IDENTITY','log(1/ρ)=2/√κ+2∫₀^(1/√κ)t²/(1−t²)dt.',('A3.Ex152','A3.Ex153','A3.Ex154'),role='actual-law-prerequisite')
node('N_log_lower','SOURCE_ESTIMATE','2/√κ≤log(1/ρ), by the nonnegative remainder.',('A3.SS3.p10.2',),role='actual-law-prerequisite')
node('N_log_upper','SOURCE_ESTIMATE','log(1/ρ)≤(2/√κ)(1+1/[3(κ−1)])≤8/(3√κ)<3/√κ, usingκ≥2.',('A3.Ex155','A3.Ex156','A3.SS3.p10.3'),role='actual-law-prerequisite')
node('G_power_order','SOURCE_GAP','ρ^k=exp(−k log(1/ρ)) for the positive source exponents. Multiply logarithmic inequalities by−k≤0 to reverse order; exp is increasing. Justify natural casts and real exponent identities.',('A3.Ex157','A3.Ex158'),role='actual-law-prerequisite')
node('N_power_lower','SOURCE_ESTIMATE','exp(−3n/√κ)≤ρ^n.',('A3.Ex157',),role='actual-law-prerequisite')
node('N_tail','SOURCE_ESTIMATE','Use the produced √κ≤d−n and log lower bound for ρ^(2(d−n))≤exp(−4(d−n)/√κ)≤exp(−4).',('A3.SS3.p11.1','A3.Ex158'),role='actual-law-prerequisite')
node('N_actual_bias_lower','SOURCE_PREREQUISITE','(1−exp(−4))exp(−3n/√κ)≤|b|/M for the actual Gaussian, given its source mode/gap domain.',('S4.Thmtheorem5.p2.1','S4.Ex17','A3.SS3.p11.2','A3.Ex159'),role='actual-law-prerequisite',note='This source-backed actual-bias ingredient is represented with its author route; no compiled/verified bias API claim is assumed.')
# Exact source query-regime scalar-to-power application.
node('G_query_exponent_bridge','SOURCE_GAP','With n=2q+1 and the exact q≤(δ/256)√κ log d, establish3n/√κ≤3+(3δ/128)log d. Cast the natural mode, divide only by positive√κ, and useκ≥2 for1/√κ≤1.',('S4.SS3.SSS0.Px2.p2.2',),role='private-consumer')
node('N_source_exponent','SOURCE_ESTIMATE','3n/√κ≤3+(3δ/128)log d under the exact scalar source regime and produced d≥2.',('S4.SS3.SSS0.Px2.p2.2',),role='private-consumer')
node('G_exponent_weakening','SOURCE_GAP','Forδ>0 and log d≥0, compare3δ/128≤δ/4, giving3n/√κ≤3+(δ/4)log d. This is a weaker inequality, never an equality of coefficients.',('S4.Ex23','S4.SS3.SSS0.Px2.p2.2'),role='private-consumer')
node('N_exponential_to_power','SOURCE_ESTIMATE','exp(−3n/√κ)≥exp(−3)(d:ℝ)^(−δ/4), with actual d≥2 and standard positive-base real powers.',('S4.Ex23','S4.SS3.SSS0.Px2.p2.2'),role='private-consumer')
node('G_positive_power_factor','SOURCE_GAP','Prove1−exp(−4)>0; all exp factors are positive, and d>0 permits exp(c log d)=d^c. These are internal domain/algebra facts, not caller premises.',('S4.Ex23','A3.Ex159'),role='private-consumer')
node('N_actual_polynomial_bias','SOURCE_NUMERICAL_COMPONENT','((1−exp(−4))exp(−3)) d^(−δ/4)≤|b|/M, from actual lower exponential bias and the exact source query exponent comparison.',('S4.Ex23',),role='private-consumer')
node('G_uniform_application_threshold','SOURCE_GAP','Apply actual Gaussian ingredients uniformly to every d,κ,q after the scalar producer threshold. Preserve one natural existential witness depending only onδ; no later choice depending onκ,q or actual-law samples.',('S4.SS3.SSS0.Px2.p2.1','S4.Ex23'),role='private-consumer')
node('C_root','EXACT_PRIVATE_CONSUMER_ROOT','∃d0(δ):Nat, for all d≥d0, κ and q in the original conditional scalar regime, the literal actual Gaussian has M>0, signed b>0, and ((1−exp(−4))exp(−3)) d^(−δ/4)≤|b|/M.',('S4.SS3.SSS0.Px2.p2.1','S4.Ex23'),role='private-non-anchor',note='Actual diagonal numerical Ex23 component, not Ex24τ/mean-growth, Ex25/26, rotated detector, algorithm, oracle, TV, cost or a new public Anchor.')
# Genuine source conjunctions only.
edge('r_dimension','G_large_dimension_domain',['S_delta'],['S4.SS3.SSS0.Px1.p1.2'],'Internal large-d cutoff domain, no new premise.')
edge('r_alpha','G_alpha_domain',['S_delta'],['S4.SS3.SSS0.Px1.p1.1','S4.SS3.SSS0.Px2.p2.1'],'Fixed exponent remains independent ofκ,q.')
edge('r_sqrt_order','G_sqrt_rpow_order',['S_regime','G_large_dimension_domain','G_alpha_domain'],['S4.SS3.SSS0.Px2.p2.1'],'Legitimate source sqrt/real-power comparison.')
edge('r_sqrt_envelope','N_sqrt_envelope',['G_sqrt_rpow_order'],['S4.SS3.SSS0.Px2.p2.1'],'Envelope uniform inκ.')
edge('r_growth','G_power_log_growth',['G_alpha_domain','G_large_dimension_domain'],['S4.SS3.SSS0.Px1.p1.1','S4.SS3.SSS0.Px2.p2.1'],'Standard scalar limiting ingredients omitted in source.')
edge('r_querybridge','G_coarse_query_bridge',['S_regime','N_sqrt_envelope','G_large_dimension_domain','G_power_log_growth'],['S4.SS3.SSS0.Px1.p1.1'],'Absorb+1 atδ-only threshold and retain originalδ/256 source premise.')
edge('r_queryenvelope','N_query_envelope',['G_coarse_query_bridge'],['S4.SS3.SSS0.Px1.p1.1'],'Author coarse envelope, not a uniform-inδ claim.')
edge('r_modesmall','N_uniform_mode_small',['N_query_envelope','S_mode','G_power_log_growth'],['S4.SS3.SSS0.Px1.p1.2','S4.SS3.SSS0.Px2.p2.1'],'n=o(d) in the original uniform scalar regime.')
edge('r_sqrtsmall','N_uniform_sqrt_small',['N_sqrt_envelope','G_power_log_growth'],['S4.SS3.SSS0.Px2.p2.1'],'sqrtκ=o(d), uniform overκ.')
edge('r_modeltbridge','G_mode_eventual_lt',['N_uniform_mode_small','G_large_dimension_domain'],['S4.SS3.SSS0.Px1.p1.2'],'Uniform eventual mode positivity/domain consequence.')
edge('r_modelt','N_mode_lt',['G_mode_eventual_lt'],['S4.SS3.SSS0.Px1.p1.2'],'Author explicit n<d applicability.')
edge('r_gapbridge','G_gap_eventual_bridge',['N_uniform_mode_small','N_uniform_sqrt_small','G_large_dimension_domain'],['S4.SS3.SSS0.Px2.p2.1'],'Both small-o controls are necessary author inputs to the stated gap discharge; no unrelated variance premise.')
edge('r_gap','N_uniform_gap',['G_gap_eventual_bridge'],['S4.SS3.SSS0.Px2.p2.1'],'Author gap prerequisite is proved internally.')
edge('r_commonthreshold','G_common_threshold',['G_large_dimension_domain','S_mode','N_mode_lt','N_uniform_gap'],['S4.SS3.SSS0.Px1.p1.2','S4.SS3.SSS0.Px2.p2.1'],'Combine all scalar outputs under oneδ-only natural witness.')
edge('r_producer','P_root',['S_delta','S_regime','S_mode','G_common_threshold'],['S4.SS3.SSS0.Px2.p2.1'],'Full exact producer quantifier/output structure.')
edge('r_domain_projection','P_source_domain_projection',['P_root'],['S4.SS3.SSS0.Px2.p2.1'],'Project source domain/gap for the actual Gaussian application; no compiled dependency asserted.')
edge('r_actualdomain','G_actual_domains',['P_source_domain_projection','S_regime','A_objects'],['A3.SS3.p4.1','A3.SS3.p9.1'],'Produced d/mode/gap and originalκ≥2 discharge literal object domains.')
edge('r_actualgaussian','G_actual_gaussian',['G_actual_domains','A_objects'],['A3.SS3.p4.1'],'Actual probability/covariance and finite second moments, never a callback.')
edge('r_meanbridge','G_finite_mean_bridge',['G_actual_gaussian','A_objects'],['A3.Ex140'],'Finite actual mean linearity.')
edge('r_meansums','N_mean_sums',['G_finite_mean_bridge'],['A3.SS3.p4.2'],'Source actual sums feed the cosine expansion.')
edge('r_C7','G_C7_series',['G_actual_domains','A_objects'],['A3.SS3.p4.2'],'Full source expansion/absolute-convergence prerequisite.')
edge('r_alias','G_grid_alias',['P_source_domain_projection','A_objects'],['A3.SS3.p5.1','A3.SS3.p6.2'],'Actual source midpoint grid, all integer alias cases.')
edge('r_interchange','G_finite_series_interchange',['G_C7_series','N_mean_sums'],['A3.SS3.p4.2'],'Source absolute convergence supplies internal interchange.')
edge('r_exactM','N_exact_M',['G_finite_series_interchange','G_grid_alias','G_actual_domains'],['A3.SS3.p9.1','A3.Ex150'],'Exact actual norm mean prerequisite.')
edge('r_bclasses','G_b_alias_classes',['G_finite_series_interchange','G_grid_alias','P_source_domain_projection','G_actual_domains'],['A3.SS3.p6.2'],'1≤n<d supplies alias disjointness; all regularity internal.')
edge('r_exactb','N_exact_signed_b',['G_b_alias_classes'],['A3.SS3.p9.1'],'Exact signed mean prerequisite.')
edge('r_positivity','G_actual_positivity',['N_exact_M','N_exact_signed_b','G_actual_domains','P_source_domain_projection'],['A3.SS3.p9.1','A3.Ex150'],'Actual positive M/signed mean, not totalized-default closure.')
edge('r_Mpositive','N_M_positive',['G_actual_positivity'],['A3.Ex150','S4.Ex23'],'First actual consumer output.')
edge('r_signedpositive','N_signed_b_positive',['G_actual_positivity'],['A3.Ex150','S4.Ex23'],'Second actual consumer output.')
edge('r_ratiobridge','G_actual_ratio',['N_exact_M','N_exact_signed_b','N_M_positive','N_signed_b_positive','G_actual_domains'],['A3.Ex150'],'Actual ratio/sign and denominator handling.')
edge('r_ratio','N_ratio',['G_actual_ratio'],['A3.SS3.p11.2'],'Normalized actual bias.')
edge('r_correction','N_correction_lower',['G_actual_domains','P_source_domain_projection'],['A3.SS3.p11.2'],'Positive denominator≤1 gives lower correction factor.')
edge('r_logdomain','G_log_integral_domains',['G_actual_domains','S_regime'],['A3.Ex152','A3.Ex153','A3.Ex154','A3.Ex155'],'No singular interval or unproved regularity premise.')
edge('r_logidentity','N_log_identity',['G_log_integral_domains'],['A3.SS3.p10.2'],'Source integral representation.')
edge('r_loglower','N_log_lower',['N_log_identity'],['A3.Ex158'],'Lower2 constant supplies tail control.')
edge('r_logupper','N_log_upper',['N_log_identity','S_regime'],['A3.Ex157'],'κ≥2 supplies exact upper3 constant.')
edge('r_powerdomains','G_power_order',['G_actual_domains','P_source_domain_projection'],['A3.Ex157','A3.Ex158'],'Negative exponent multiplier reverses log order; exp preserves it.')
edge('r_powerlower','N_power_lower',['N_log_upper','G_power_order'],['A3.SS3.p11.2'],'Exact source lower exp factor.')
edge('r_tail','N_tail',['N_log_lower','G_power_order','P_source_domain_projection'],['A3.SS3.p11.2'],'Use actual produced spacing; do not assume gap as new caller hypothesis.')
edge('r_actuallower','N_actual_bias_lower',['N_ratio','N_correction_lower','N_power_lower','N_tail','G_actual_domains'],['S4.SS3.SSS0.Px2.p2.1','S4.Ex23'],'Source Lemma4.5 lower bound application after internal domain discharge.')
edge('r_queryexponent','G_query_exponent_bridge',['S_regime','S_mode','P_source_domain_projection'],['S4.SS3.SSS0.Px2.p2.2'],'Retain exactδ/256 and n=2q+1 to derive3δ/128 coefficient.')
edge('r_sourceexponent','N_source_exponent',['G_query_exponent_bridge'],['S4.Ex23'],'Exact source numeric exponent bound.')
edge('r_weakening','G_exponent_weakening',['N_source_exponent','S_delta','P_source_domain_projection'],['S4.Ex23'],'Useδ>0/logd≥0 and3/128≤1/4, not equality.')
edge('r_positivefactor','G_positive_power_factor',['P_source_domain_projection'],['S4.Ex23'],'Derived factor/positive-base rpow semantics; no public assumption.')
edge('r_exptopower','N_exponential_to_power',['G_exponent_weakening','G_positive_power_factor'],['S4.Ex23'],'Negate exponent inequality, use increasing exp, split exp(−3−δlogd/4).')
edge('r_polybias','N_actual_polynomial_bias',['N_actual_bias_lower','N_exponential_to_power','G_positive_power_factor'],['S4.Ex23'],'Material actual lower-bias use, with exactconstant(1−e−4)e−3 and rate−δ/4.')
edge('r_uniformapplication','G_uniform_application_threshold',['P_root','N_M_positive','N_signed_b_positive','N_actual_polynomial_bias'],['S4.SS3.SSS0.Px2.p2.1','S4.Ex23'],'Lift every actual-law conclusion under the uniform scalar witness. The theorem permits anyδ-only witness, not aκ/q-dependent one.')
edge('r_consumer','C_root',['G_uniform_application_threshold'],['S4.Ex23'],'Private actual-law numerical component only; no full algorithm/source completion.')
# Structural and closure checks.
ids={n['id'] for n in nodes};assert len(ids)==len(nodes)
assert all(e['consumer'] in ids and all(x in ids for x in e['inputs']) for e in routes)
byconsumer={}
for e in routes:byconsumer.setdefault(e['consumer'],[]).append(e)
def closure(target):
 seen=set();active=set();used=set()
 def visit(k):
  assert k not in active,'cycle:'+k
  if k in seen:return
  active.add(k)
  for e in byconsumer.get(k,[]):
   used.add(e['id'])
   for q in e['inputs']:visit(q)
  active.remove(k);seen.add(k)
 visit(target)
 return {'root':target,'nodes':sorted(seen),'routes':sorted(used),'internal_SOURCE_GAP_nodes':sorted(n['id'] for n in nodes if n['id'] in seen and n['kind']=='SOURCE_GAP'),'declared_source_domain_nodes':sorted(n['id'] for n in nodes if n['id'] in seen and n['kind'] in ['SOURCE_FIXED_PARAMETER','SOURCE_CONDITIONAL_DOMAIN']),'no_compilation_or_completion_claim':True}
closures={'producer_all_outputs':closure('P_root'),'consumer_all_outputs':closure('C_root'),'consumer_scalar_domain_subroot':closure('P_source_domain_projection'),'consumer_actual_bias_subroot':closure('N_actual_bias_lower'),'consumer_query_exponent_subroot':closure('N_exponential_to_power')}
assert all(n['role']=='scalar-producer' for n in nodes if n['id'] in closures['producer_all_outputs']['nodes'])
assert all(x in closures['consumer_all_outputs']['nodes'] for x in ['P_root','N_M_positive','N_signed_b_positive','N_actual_bias_lower','N_exponential_to_power'])
# Exact target successors preserving every raw row/history.
selected={}
for n in nodes:
 for a in n['source_anchors']:selected.setdefault(a['raw_unit_ordinal'],[]).append(n['id'])
fragments={
'S4.Thmtheorem1.p1.1':{'included':'Fixedδ and existence of aδ-only threshold before all parameters.','excluded':'Full query lower bound,ε/TV completion and any explicit numeric d0 formula.'},
'S4.SS3.p2.1':{'included':'Exactδ/κ/q scalar regime, includingδ/256.','excluded':'Algorithm/TV assumption and admissibility argument as target results or extra premises of scalar producer.'},
'S4.SS3.p3.1':{'included':'Literal source n=2q+1.','excluded':'Concreteτ and test event; noτ binder or detector claim is added.'},
'S4.SS3.SSS0.Px1.p1.1':{'included':'Source coarse q+1 estimate and n=o(d),with uniform-domain/+1 bridges explicit.','excluded':'Any need to prove theτ-decay branch for the exact mode/gap targets.'},
'S4.SS3.SSS0.Px1.p1.2':{'included':'Eventualn<d withδ-only threshold.','excluded':'τ≤1/2, Krylov representation and output probability result.'},
'S4.SS3.SSS0.Px2.p2.1':{'included':'Uniform eventual√κ≤d−n and actual lower-bias applicability.','excluded':'Assuming that gap as an added public producer premise.'},
'S4.SS3.SSS0.Px2.p2.2':{'included':'3n/√κ≤3+(3δ/128)logd.','excluded':'ρ^(2d) and lower-M growth estimates; neither is needed for this exact polynomial normalized-bias output.'},
'S4.EGx1':{'included':'Both actual exact means as source prerequisites.','excluded':'Any prior compiled/verified API claim or new proof credit.'},
'S4.Thmtheorem5.p1.1':{'included':'ActualGaussian/ρ/mode/D/M/μ_n definitions andκ≥2.','excluded':'A free actual-law/moment certificate or new public hypothesis.'},
'S4.Thmtheorem5.p2.1':{'included':'Exact spacing condition, discharged by the scalar producer in consumer.','excluded':'Treating source conditional gap as a new main/prerequisite caller assumption.'},
'S4.Ex17':{'included':'Only lower exponential-bias branch with constants1−exp(−4),3.','excluded':'Upper exponential-bias output, not required by the exact consumer.'},
'A3.Ex151':{'included':'Lower correction-factor comparison.','excluded':'Upper correction-factor comparison as a required output.'},
'A3.Ex157':{'included':'Lower power estimate exp(−3n/√κ)≤ρ^n.','excluded':'Upper power estimate, unnecessary for current consumer; lower log bound is separately retained for tail.'},
'A3.Ex159':{'included':'Lower paired-bias clause as actual source prerequisite.','excluded':'Upper bias clause as an exact target output.'},
'A3.SS3.p8.1':{'included':'λ_i≥1/domain context only.','excluded':'Fourth moments, independence and variance/L² branch, unnecessary for these scalar/actual-mean bias targets.'},
'S4.Ex23':{'included':'Exactactualpolynomiallowercomponent withconstant(1−exp(−4))exp(−3),rate−δ/4.','excluded':'A bound for a rotated detector/event or full source probability theorem.'}}
excludes={'A3.EGx18':'Aggregate log-integral display; mathematical rowsA3.Ex152/153/154 are separate exact-target NODEs. Original aggregate math retained.','A3.EGx19':'Aggregate log-upper display; mathematical rowsA3.Ex155/156 are separate exact-target NODEs. Original aggregate math retained.'}
def reason(u):
 k=u['kind'];lo=u['original_lines'][0];ident=u['id']
 if k in ['section-context','heading','proof-block','paragraph-container']:return 'Structural container/heading. Substantive descendants have separate target successors; original context retained.'
 if k=='paragraph' and u['text_with_tex']=='∎':return 'Standalone proof-end marker; no mathematical statement. In particular A3.SS3.p11.3 is not the final estimate; that is A3.Ex159.'
 if k=='tbody':return 'Original equation row retained with identity/math/true parent '+str(u['containing_display_id'])+'; duplicated by selected display or outside exact target. Historical raw NODE→EXCLUDED is explicit, not deletion.'
 if k=='internal-reference':return 'Use-site/href preserved in raw fields and parent context; separately selected/excluded source region determines relevance, not an additional mathematical premise.'
 if k=='external-citation' or u['scope'].startswith('genuinely-cited-bibliography'):return 'Historical/Krylov provenance [22] outside scalar mode/gap and actual polynomial-bias roots. C.3 contains no external citation for its internal bias proof.'
 if u['scope']=='section2-complete':return 'Oracle/randomized-algorithm/TV/query-cost definitions are not proof inputs or outputs of the exact scalar prerequisite/private diagonal numerical component; Euclidean literal convention is separately selected.'
 if 1501<=lo<=1600:return 'Limitations/Krylov-dimension/accuracy-obstruction discussion is outside these exact targets; raw source and references preserved.'
 if 1452<=lo<=1500:return 'Commonτ/β/320 selection, shifted contrast mean/variance, Chebyshev .9 event,TV contradiction and main theorem are outside the exact current scalar/normalized-bias components.'
 if ident=='S4.Ex24':return 'τ/β decay and Mβ² growth are downstream and not needed for polynomial normalized-bias lower output.'
 if 1283<=lo<=1342:return 'Rotated-target transport,admissibility,full theorem/TV setup outside exact targets, except separately selected source scalar-regime/conditional-bias clauses.'
 if 1373<=lo<=1424:return 'Algorithm-output probability branch or redundant targetβ definition outside exact roots; selected asymptotic mode/domain paragraphs are separately represented.'
 if 1128<=lo<=1254:return 'Krylov construction/uniform event/τ bound is outside target; literal mode definition selected separately.'
 if 1054<=lo<=1127:return 'Full query lower bound,known-spectrum remarks or Haar-random rotation construction is outside exact roots; standing midpoint grid and fixedδ threshold provenance are selected separately.'
 if 4013<=lo<=4037:return 'Gaussian fourth-moment/independence/variance and closed-M-upper branch is unnecessary to these exact source mode/gap and actual normalized-mean components.'
 return 'Raw source statement/paragraph is outside exact selected roots or duplicated by selected source components. Its original fields remain preserved and no full-section proof obligation is silently imposed.'
rows=[]
for j,(u,h) in enumerate(zip(raw['units'],hist)):
 assert u['raw_unit_ordinal']==h['raw_unit_ordinal']==j
 keep=j in selected and u['id'] not in excludes
 succ={'disposition':'NODE' if keep else 'EXCLUDED','graph_nodes':selected.get(j,[]) if keep else [],'reason':None if keep else excludes.get(u['id'],reason(u)),'target_fragment':fragments.get(u['id']),'history_change':h['disposition']+' -> '+('NODE' if keep else 'EXCLUDED')}
 rows.append({'raw_unit_ordinal':j,'raw_source_unit':u,'phase1_disposition':h,'exact_target_successor':succ})
assert len(rows)==366 and len({r['raw_source_unit']['source_unit_key'] for r in rows})==366
# Binder/domain/definition and private scope review; no supplied binder verdict accepted on trust.
audit={'schema':1,'status':'SOURCE_EXTRACTOR_CANDIDATE_ASSESSMENT_PENDING_DISTINCT_CHALLENGE','projection':{'path':str(projection.relative_to(root)),'sha256':sha(projection),'full_exact_seal_sha256_unread':seal_sha,'projection_v1_read':False},'producer':{'name':s['producer']['name'],'exact_signature':s['producer']['signature'],'signature_sha256':s['producer']['signature_sha256'],'role':'Source prerequisite, not full main lower-bound theorem','top_level_binders':[{'binder':'δ:Real','class':'TYPING'},{'binder':'hδ0:0<δ','class':'SOURCE'},{'binder':'hδ1:δ<1','class':'SOURCE'}],'conclusion_binder_scope':[{'binder':'d0:Nat','kind':'EXISTENTIAL_OUTPUT','scope':'chosen after fixedδ and before everyd,κ,q; not caller-supplied hypothesis'},{'binder':'d:Nat','kind':'UNIVERSAL_TYPING','scope':'afterd0'},{'binder':'d0≤d','kind':'SOURCE_CONDITIONAL_DOMAIN','scope':'eventual universal dimension condition, not an extra free precondition'},{'binder':'κ:Real','kind':'UNIVERSAL_TYPING','scope':'afterd,d0'},{'binder':'2≤κ','kind':'SOURCE_CONDITIONAL_DOMAIN','scope':'originalκlower range'},{'binder':'κ≤(d:Real)^(1−δ)','kind':'SOURCE_CONDITIONAL_DOMAIN','scope':'originalκupper range'},{'binder':'q:Nat','kind':'UNIVERSAL_TYPING','scope':'nonnegative source integer query cap'},{'binder':'q≤(δ/256)√κ logd','kind':'SOURCE_CONDITIONAL_DOMAIN','scope':'exact source query inequality,not an expected-cost bound'}],'output_assessment':['d≥2 is an eventual output supplied by the natural threshold.','n≥1 follows from literaln=2q+1 and naturalq.','n<d is explicitly obtained atS4.SS3.SSS0.Px1.p1.2.','√κ≤d−n is explicitly discharged atS4.SS3.SSS0.Px2.p2.1,with uniform little-o/cutoff details omitted and retained as internal obligations.'],'EXCESS_public_inputs_found':[],'critical_quantifier_audit':'∃d0(δ)∀d∀κ∀q,not∀κ∀q∃d0. No claim that one numerical threshold works uniformly acrossδ∈(0,1). The theorem does not require the returned witness itself to be≥2; a proof may internally choose/enlarge it, whiled≥2 is delivered in the conclusion.','status':'SOURCE_ALIGNED_CANDIDATE_NOT_PROVED_OR_SELF_ADMITTED'},'private_consumer':{'name':s['actual_private_consumer']['name'],'exact_signature':s['actual_private_consumer']['signature'],'signature_sha256':s['actual_private_consumer']['signature_sha256'],'is_source_anchor':False,'Registry_node':False,'role':s['actual_private_consumer']['role'],'source_relation':'Actual diagonal version of the numerical Ex23 component in the originalδ/κ/q regime. It retains literaln=2q+1 and the source polynomial lowerconstant/rate. It is not a rotated detector,event bound,Ex24τbranch/Ex26,algorithm/oracle/TV/cost result or an additional source Anchor.','binder_scope':'Same fixedδ,eventual-uniformd/κ/q structure as producer. No new numeric,law,moment,integrability,variance,bias or denominator-positivity assumptions. Its own existential witness may be the scalar witness or aδ-only enlargement; the signature does not assert equality with a particular producer/full-main-theorem witness.','new_assumed_private_numeric_premises':[],'actual_domain_discharge':'The scalar producer must supplyd≥2,positive mode,n<d andgap internally. The source conditional gap is not inserted as a new public premise.','constant_audit':'Use exactδ/256 andn=2q+1 to get3δ/128; source usesκ≥2 to bound the remaining3/√κby3. Weakening3δ/128toδ/4 requiresδ>0 andlogd≥0. Exp is increasing; negation reverses the exponent inequality. The positive-base real-power identity yields exact(1−exp(−4))exp(−3) d^(−δ/4),not a rounded/replaced constant.','outputs_assessment':'ActualM>0 andsignedb>0are source Gaussian mean consequences; the polynomial bound materially uses the actual lowerbias and the scalar domain,not a free mean/law/bias certificate.','no_implementation_use_claim':'No proof/API/compiled-parent evidence has been inspected. This source map specifies mathematical obligations,not evidence that an implementation consumes them.','status':'COHERENT_PRIVATE_ACTUAL_SOURCE_REGIME_APPLICATION_PENDING_DISTINCT_REVIEW_AND_PROOF'},'literal_definition_audit':{'threshold':'Existential natural output depending only on fixedδ; not a free thresholdinput or a function chosen afterκ/q.','mode':'Literal naturaln=2*q+1; real casts exact. Real(d−n)expression is subtraction of casts,not truncated Nat subtraction.','realpowers':'Ordinary real powers; internally establishpositive reald for negative exponent−δ/4and power/log/sqrt identities. Totalizedzero-base branches cannot close the actual theorem.','midpointindex':'Fin indexj corresponds to sourcei=j.val+1,soi−1/2=j.val+1/2.','covariance':'DisplayedΛisprecision;Gaussian covariance isΛ⁻¹on internally established positive definite domain. No surrogateGaussian/callback.','integrals':'M,bareactual Bochner integrals;finiteactualsecond moments andintegrability are internal before exact means/positivity/ratio use. No nonintegrable-default closure.','signratio':'0<(−1)^n bpermitsabsconversion;M>0must be produced beforedivision. Ratioofmeans,notexpectationofpointwiseratio.'},'source_graph_boundary':'No source proof/coverage self-acceptance,Lean implication,compiled parent,new canonical result or fullmain theorem completion is asserted.'}
outputs={};outputs['statement-projection-audit.json']=enc(audit);asha=hashlib.sha256(outputs['statement-projection-audit.json']).hexdigest()
graph={'schema':1,'status':'SOURCE_FIRST_GRAPH_PROPOSED_OPEN_INTERNAL_OBLIGATIONS','source_sha256':raw['source_sha256'],'projection_sha256':sha(projection),'full_seal_sha256_unread':seal_sha,'phase1_freeze_sha256':sha(p1/'phase1-freeze.json'),'statement_audit_sha256':asha,'nodes':nodes,'routes':routes,'OR_routes':[],'logic':'The paper supplies one sufficient conjunctive scalar-domain route and one conjunctive actual-bias application. No source-supported alternative route is invented. Scalar producer has noGaussian/API dependencies. The private actual-law consumer is a separate root using source prerequisite subroots.','source_prerequisite_credit':'C.3actualmeans/biasauthorroutesareexpanded source prerequisites,not newlyproved/verified API facts. No older graph/reviewer verdict/Lean implementation was read as input.','independence_limit':'Priorrelatedsource/Variances/Biasexposureisdisclosed byownfrozenphase1manifest;thisnewprojectionwasreadonlyafterthatfreeze.','not_compiled_dependency_graph':True,'no_self_admission':True}
outputs['source-proof-graph.json']=enc(graph);gsha=hashlib.sha256(outputs['source-proof-graph.json']).hexdigest()
coverage={'schema':1,'status':'EXACT_TARGET_SUCCESSORS_PENDING_DISTINCT_SOURCE_REVIEW','projection_sha256':sha(projection),'graph_sha256':gsha,'phase1_freeze_sha256':sha(p1/'phase1-freeze.json'),'raw_units':366,'successor_counts':dict(Counter(r['exact_target_successor']['disposition'] for r in rows)),'rows':rows,'history':'Allrawsourcefields,ordinal/tag-line-columnidentities,math/references/trueparentdisplaysandearlier204NODE/162EXCLUDEDdispositionsarepreservedverbatim. Targetscopechangesareappend-onlysuccessorswithreason.','scope':'Uniformsource mode/gap prerequisite and actualdiagonal polynomial normalized-bias component only. NotfullS4,C3,τ/probability/rotated/oracle/TV/algorithm/cost proof.'}
outputs['exact-target-coverage.json']=enc(coverage);csha=hashlib.sha256(outputs['exact-target-coverage.json']).hexdigest()
closure_packet={'schema':1,'status':'SOURCE_ROOT_AND_SUBROOT_CLOSURES_WITH_OPEN_OBLIGATIONS','projection_sha256':sha(projection),'graph_sha256':gsha,'coverage_sha256':csha,'closures':closures,'uniformity_contract':'Eachscalarthresholdisafunctionofonlythefixedδ(andintermediateηbeforechoosingfixedtolerances),neverκorq.Onecommonnaturalcutoffservesallallowedd,κ,q.','consumer_required_parts':['Scalarproducerallsourceapplicabilityoutputs','ActualGaussianmeanpositivityandsignedpositivity','Actualconditionalexponentiallowerbias','Exactsourcequeryexponentboundandweakeningtopower'],'excluded_unneeded_branches':['τdefinition/decay/uniformKrylovprobability','Variance/fourthmoment/independence/L²sourcebranch','Upperexponentialbiasoutput','ClosedMupperorlowergrowth,Ex24,320threshold','Contrast/event/Chebyshev/.9/rotation/TV/querycosttheorem'],'compiled_dependency_claim':False,'independent_challenger_required':True}
outputs['root-subroot-closures.json']=enc(closure_packet)
inputs={'schema':1,'status':'EXACT_PROJECTION_V2_PLUS_OWN_FROZEN_RAW_ONLY','newinput':{'path':str(projection.relative_to(root)),'sha256':sha(projection),'unreadboundfullseal_sha256':seal_sha,'v1projection_read':False},'frozen_own_inputs':[{'path':str((p1/f).relative_to(root)),'sha256':sha(p1/f)} for f in ['phase1-freeze.json','raw-unit-inventory.json','raw-unit-dispositions.json','raw-cognition.md','exposure-input-manifest.json']],'allphase1artifacthashesrecheckedunchanged':True,'priorrelatedexposuremanifest_sha256':sha(p1/'exposure-input-manifest.json'),'otherauthorizedexposure':'Parentexactprojectionhash/scope/independencerestrictionsonly.','notread':['Fullseal/internaldependencysuggestions/rootplanningandexposurenotes','ImplementationLean/Tests/API/Mathlib/proofbodies','Anotherrolegraph/challenge/oldverdict','Oldrelatedgraph/API/proofartifactsascurrentinput'],'notrun':['Proof/Lean/build/APIretrieval','Normalintake/harness/canonical/global/site/ledgermutations','Network'],'script_sha256':sha(out/'build_source_packet.py'),'writeboundary':str(out.relative_to(root)),'nocompiledorindependentcoverageapproval':True}
outputs['machine-inputs.json']=enc(inputs)
lineage={'schema':1,'predecessorrawfreeze':{'path':str((p1/'phase1-freeze.json').relative_to(root)),'sha256':sha(p1/'phase1-freeze.json')},'newprojection':{'path':str(projection.relative_to(root)),'sha256':sha(projection),'unreadfullseal_sha256':seal_sha},'raw_rows_canonical_sha256':canonical(raw['units']),'successor_raw_rows_canonical_sha256':canonical([r['raw_source_unit'] for r in rows]),'history_rows_canonical_sha256':canonical(hist),'successor_history_rows_canonical_sha256':canonical([r['phase1_disposition'] for r in rows]),'all366rawrowsandprior204_162historypreserved':True,'outputs':[{'path':str((out/n).relative_to(root)),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)} for n,b in outputs.items()],'status':'Firstappend-onlyexact-targetsuccessorafterrawfreeze;notselfapproved;distincttopologychallengepending.'}
assert lineage['raw_rows_canonical_sha256']==lineage['successor_raw_rows_canonical_sha256']
assert lineage['history_rows_canonical_sha256']==lineage['successor_history_rows_canonical_sha256']
outputs['binding-lineage.json']=enc(lineage)
for a in frozen['artifacts']:assert sha(root/a['path'])==a['sha256']
for r in rows:
 x=r['exact_target_successor'];assert x['graph_nodes'] if x['disposition']=='NODE' else x['reason']
for n in list(outputs)+['phase2-freeze.json']:assert not (out/n).exists(),n
for n,b in outputs.items():
 with (out/n).open('xb') as f:f.write(b)
freeze={'schema':1,'status':'MODE_GAP_PHASE2_SOURCE_ONLY_FROZEN_PENDING_DISTINCT_CHALLENGE','phase1freeze_sha256':sha(p1/'phase1-freeze.json'),'projection_sha256':sha(projection),'unreadfullseal_sha256':seal_sha,'artifacts':[{'path':str((out/n).relative_to(root)),'sha256':sha(out/n),'bytes':(out/n).stat().st_size} for n in ['build_source_packet.py']+list(outputs)],'counts':{'nodes':len(nodes),'AND_routes':len(routes),'OR_routes':0,'raw_units':366,'targetsuccessors':coverage['successor_counts'],'producerclosure_nodes':len(closures['producer_all_outputs']['nodes']),'consumerclosure_nodes':len(closures['consumer_all_outputs']['nodes'])},'assessment':'Candidateexactsourcequantifiers/constants/actual-lawprivatescopecoherent;allomittedbridgesremaininternalopenobligations. Noprooforcoverageadmission.','phase1unchanged':True,'noAPIretrieval_proof_globalmutation':True}
with (out/'phase2-freeze.json').open('xb') as f:f.write(enc(freeze))
print(json.dumps({'freeze_sha256':sha(out/'phase2-freeze.json'),'counts':freeze['counts'],'artifacts':freeze['artifacts']},indent=2))
