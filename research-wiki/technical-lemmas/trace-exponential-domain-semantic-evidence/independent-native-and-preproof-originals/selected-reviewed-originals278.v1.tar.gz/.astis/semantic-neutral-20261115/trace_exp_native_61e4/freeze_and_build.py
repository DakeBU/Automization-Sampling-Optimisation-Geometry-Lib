"""Freeze new R16 literal/application and lossless-kernel audit mechanisms, then run real commands."""
import json
import re
from native_common import *

PUBLIC='AutoSamplingTheory.TechnicalLemmas.Analysis.MatrixTraceExponentialBounds.trace_exp_pos_and_le_card_mul_exp_abs_mul_norm'
SUFFIX='.actual_source_four_trace_mgfs_integrable_positive_and_bounded'

def main():
    assert not (OWN/'native-assignment.json').exists()
    closure=json.loads((OWN/'actual-import-closure.json').read_text())
    packages=json.loads((OWN/'verified-package-inputs.json').read_text())
    assert closure['candidate_commit']==packages['candidate_commit']==COMMIT
    p=(OWN/'immutable-inputs/P.literal.txt').read_text().strip();t=(OWN/'immutable-inputs/T.literal.txt').read_text().strip()
    harness=OWN/'harness';harness.mkdir(exist_ok=True)
    text='''import Tests.GaussianComplexityTraceMgfDomain
import Lean
open MeasureTheory ProbabilityTheory Lean Elab Term
open scoped BigOperators Matrix.Norms.L2Operator MatrixOrder ENNReal
noncomputable section
universe u
elab "native_actual_T" : term => do
  let env ← getEnv
  let found := env.constants.toList.filter fun (n, _) =>
    n.toString.endsWith ".actual_source_four_trace_mgfs_integrable_positive_and_bounded"
  unless found.length == 1 do throwError "Expected unique actual private R16 T, found {found.length}"
  return mkConst found.head!.1
namespace NativeLiteralApplications

'''
    text+='theorem literal_P :\n'+p+' := by\n  intro ι instF instD instN A hA s\n  exact '+PUBLIC+' A hA s\n\n'
    text+='''theorem literal_P_explicit_L2_operator :
∀ {ι : Type u} [Fintype ι] [DecidableEq ι] [Nonempty ι],
  ∀ (A : Matrix ι ι ℝ), A.IsHermitian → ∀ s : ℝ,
    0 < Matrix.trace (NormedSpace.exp (s • A)) ∧
      Matrix.trace (NormedSpace.exp (s • A)) ≤
        (Fintype.card ι : ℝ) * Real.exp (|s| * ‖Matrix.toEuclideanCLM A‖) := by
  intro ι instF instD instN A hA s
  simpa only [Matrix.cstar_norm_def] using
    '''+PUBLIC+''' A hA s

'''
    text+='theorem literal_T :\n'+t+' := by\n  intro d q hq\n  exact native_actual_T hq\n\n'
    body=t.split('\n',1)[1]
    q0=re.sub(r'\bq\b','0',body);d2=re.sub(r'\bd\b','2',q0)
    text+='theorem literal_T_q0 {d : ℕ} (hd : 1 < d) :\n'+q0+' := by\n  exact native_actual_T (d := d) (q := 0) hd\n\n'
    text+='theorem literal_T_q0_d2 :\n'+d2+' := by\n  exact native_actual_T (d := 2) (q := 0) (by norm_num)\n\n'
    case_names=[]
    for use_cos,minus in [(False,False),(False,True),(True,False),(True,True)]:
        label=('cos' if use_cos else 'ordinary')+('_negative' if minus else '_positive')
        generic=t.replace('∀ useCos minus : Bool,','let useCos := '+str(use_cos).lower()+'; let minus := '+str(minus).lower()+';')
        name='allreal_'+label;case_names.append(name)
        text+='theorem '+name+' :\n'+generic+' := by\n  intro d q hq\n  dsimp only\n  intro s\n  exact native_actual_T hq s '+str(use_cos).lower()+' '+str(minus).lower()+'\n\n'
        for sval,slabel in [('0','zero'),('(-1)','negative'),('1','positive')]:
            specialized=d2.replace('∀ s : ℝ, ∀ useCos minus : Bool,','let s : ℝ := '+sval+'; let useCos := '+str(use_cos).lower()+'; let minus := '+str(minus).lower()+';')
            name='q0_d2_'+label+'_s_'+slabel;case_names.append(name)
            text+='theorem '+name+' :\n'+specialized+' := by\n  exact native_actual_T (d := 2) (q := 0) (by norm_num) '+sval+' '+str(use_cos).lower()+' '+str(minus).lower()+'\n\n'
    text+='''def mixed : Matrix (Fin 2) (Fin 2) ℝ :=
  Matrix.diagonal (fun i => if i = 0 then -2 else 3)

theorem mixed_diagonal_entries : mixed 0 0 = -2 ∧ mixed 1 1 = 3 := by
  norm_num [mixed, Matrix.diagonal_apply]

theorem mixed_allreal (s : ℝ) :
    0 < Matrix.trace (NormedSpace.exp (s • mixed)) ∧
      Matrix.trace (NormedSpace.exp (s • mixed)) ≤
        2 * Real.exp (|s| * ‖Matrix.toEuclideanCLM mixed‖) := by
  simpa only [Matrix.cstar_norm_def, Fintype.card_fin] using
    '''+PUBLIC+''' mixed
      (Matrix.isHermitian_diagonal _) s

'''
    for sval,slabel in [('0','zero'),('(-1)','negative'),('1','positive')]:
        text+='theorem mixed_s_'+slabel+' :\n    0 < Matrix.trace (NormedSpace.exp (('+sval+' : ℝ) • mixed)) ∧\n      Matrix.trace (NormedSpace.exp (('+sval+' : ℝ) • mixed)) ≤\n        2 * Real.exp (|('+sval+' : ℝ)| * ‖Matrix.toEuclideanCLM mixed‖) :=\n  mixed_allreal '+sval+'\n\n'
    text+='end NativeLiteralApplications\n'
    for name in ['literal_P','literal_P_explicit_L2_operator','literal_T','literal_T_q0','literal_T_q0_d2']+case_names+['mixed_allreal','mixed_s_zero','mixed_s_negative','mixed_s_positive']:
        text+='#print axioms NativeLiteralApplications.'+name+'\n'
    text+='\nset_option pp.all true in\n#check @'+PUBLIC+'\nset_option pp.all true in\n#check native_actual_T\n'
    literal=harness/'NativeLiteralApplications.lean';literal.write_text(text)
    old=REPO/'.astis/semantic-neutral-20261114/laplace_native_61e4/harness-v2'
    original=(old/'NativeAudit.lean').read_text()
    kernel=original.replace('Tests.GaussianComplexityLaplaceTail','Tests.GaussianComplexityTraceMgfDomain').replace('NativeAudit61e4','NativeAuditR16')
    kernel=kernel.replace('AutoSamplingTheory.TechnicalLemmas.Probability.MatrixLaplaceTail.max_eigenvalue_tail_le_iInf_trace_exp',PUBLIC).replace('.actual_source_four_sums_laplace_tail',SUFFIX)
    kernel=kernel.replace(str(old.parent),str(OWN)).replace('1d1103af694b9663a72b0d610004ed85c7c6b527',COMMIT)
    modules='def modules : Array String := #[\n  '+',\n  '.join(json.dumps(m) for m in closure['topological_order']+['NativeLiteralApplications'])+']\n\n'
    kernel,count=re.subn(r'def modules : Array String := #\[.*?\]\s*\n(?=def atJ)',modules,kernel,count=1,flags=re.S);assert count==1
    (harness/'NativeAudit.lean').write_text(kernel)
    graph=(old/'NativeTransitiveGraph.lean').read_text().replace('Tests.GaussianComplexityLaplaceTail','Tests.GaussianComplexityTraceMgfDomain').replace('NativeTransitive61e4','NativeTransitiveR16')
    graph=graph.replace('AutoSamplingTheory.TechnicalLemmas.Probability.MatrixLaplaceTail.max_eigenvalue_tail_le_iInf_trace_exp',PUBLIC).replace('.actual_source_four_sums_laplace_tail',SUFFIX).replace(str(old.parent),str(OWN)).replace('1d1103af694b9663a72b0d610004ed85c7c6b527',COMMIT)
    (harness/'NativeTransitiveGraph.lean').write_text(graph)
    write_json(OWN/'mechanism-provenance.json',{'prior_sources_only':[{'path':str(old/name),'sha256':file_sha(old/name)} for name in ['NativeAudit.lean','NativeTransitiveGraph.lean']],'old_results_or_receipts_or_ASTIS_olean_reused':False,'new_literals_from_exact_current_seal':True,'harness_case_names':case_names,'allreal_P_norm_explicitly_reexpressed_as_toEuclideanCLM':True})
    assert not OUT.exists();OUT.mkdir()
    environment=lean_env(packages['packages']);flags=[str(LEAN),'-DmaxRecDepth=32768','-DmaxHeartbeats=0','-Ddebug.skipKernelTC=false']
    commands=[{'id':'lean-version','argv':[str(LEAN),'--version'],'cwd':str(CAND)}]
    for i,module in enumerate(closure['topological_order']):
        relative=module.replace('.','/')
        commands.append({'id':f'compile-{i:02d}','argv':flags+['-o',str(OUT/(relative+'.olean')),relative+'.lean'],'cwd':str(CAND)})
    commands += [{'id':'literal-types-and-boundaries','argv':flags+['-o',str(OUT/'NativeLiteralApplications.olean'),str(literal)],'cwd':str(harness)},{'id':'lossless-raw-type-value-kernel','argv':flags+['--run',str(harness/'NativeAudit.lean')],'cwd':str(harness)},{'id':'complete-recursive-type-value-graph','argv':flags+['--run',str(harness/'NativeTransitiveGraph.lean')],'cwd':str(harness)}]
    for command in commands:command['environment']=environment
    write_json(OWN/'native-commands.json',commands)
    paths=[p for p in CAND.rglob('*') if p.is_file()]+list((OWN/'immutable-inputs').iterdir())+list(harness.iterdir())+[OWN/x for x in ['native_common.py','prepare.py','freeze_and_build.py','actual-import-closure.json','verified-package-inputs.json','scan_policy.py','native-commands.json']]
    assignment={'candidate_commit':COMMIT,'all_ASTIS_output_initially_empty':not any(OUT.iterdir()),'ASTIS_source_modules':len(closure['modules']),'inputs':[{'path':str(p.relative_to(OWN)),'sha256':file_sha(p)} for p in paths]}
    write_json(OWN/'native-assignment.json',assignment)
    for command in commands:
        for row in assignment['inputs']:assert file_sha(OWN/row['path'])==row['sha256']
        if '-o' in command['argv']:Path(command['argv'][command['argv'].index('-o')+1]).parent.mkdir(parents=True,exist_ok=True)
        print(json.dumps({'native_command_started':command['id']}),flush=True)
        run(command['id'],command['argv'],cwd=command['cwd'],env=environment)
    write_json(OWN/'native-sequence.completed.json',{'candidate_commit':COMMIT,'actual_command_count':len(commands),'all_actual_commands_exit_zero':True,'ASTIS_modules_freshly_recompiled':len(closure['modules'])})

if __name__=='__main__':main()
