from pathlib import Path
import hashlib,json,subprocess
ROOT=Path('/Users/zhouhuanjian/ASTIS-GC')
OUT=ROOT/'.astis/semantic-neutral-20261110/src_a83e10'
E=ROOT/'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-signal-strength-semantic-evidence'
def h(b): return hashlib.sha256(b).hexdigest()
def digest(o): return h(json.dumps(o,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())
def load(p): return json.loads(p.read_text())
module='AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumSignalStrength.lean'
test='Tests/GaussianComplexityFixedSpectrumSignalStrength.lean'
lessonpath='website/content/declaration_lessons/huanjian-fixed-spectrum-signal-strength.json'
pubpath='website/content/publications/huanjian-fixed-spectrum-signal-strength.json'
lesson=load(ROOT/lessonpath)['units'][0]
item=load(ROOT/pubpath)['items'][0]
binding=item['bindings'][0]
payload={'file':h((ROOT/module).read_text().encode()),'current_lean_module':(ROOT/module).read_text(),
 'toolchain':h((ROOT/'lean-toolchain').read_text().encode()),
 'dependencies':h((ROOT/'lake-manifest.json').read_text().encode()),
 **{k:item[k] for k in ['source','statement','formulae','assumptions','obligations']},
 'lesson':lesson,'binding':{k:v for k,v in binding.items() if k not in {'audit_id','legacy_audit_debt'}}}
packet=load(E/'fresh-source-reviewer-packet.json')
context=dict(payload)
context['binding']={k:payload['binding'][k] for k in ['declaration','role','supports']}
context['lesson']={k:v for k,v in lesson.items() if k not in {'boundary','source_history_boundary'}}
context['candidate_assumptions']=[{k:r[k] for k in ['source','lean']} for r in binding['assumption_deltas']]
packetbody={k:v for k,v in packet.items() if k!='packet_sha256'}
snippet=[]
for number,step in enumerate(lesson['steps'],1):
    text=step['lean']
    owner=test if number==6 else module
    snippet.append({'step':number,'owner':owner,'title':step['title'],
      'exact_contiguous_substring':text in (ROOT/owner).read_text(),
      'full_test_byte_text_equality':text==(ROOT/test).read_text() if number==6 else None,
      'snippet_sha256':h(text.encode()),'formula':step['formula']})
paths=[module,test,lessonpath,pubpath,'lean-toolchain','lake-manifest.json']
paths += ['AutoSamplingTheory/ExampleCases/GaussianComplexity/'+n+'.lean' for n in [
 'FixedSpectrumModeGap','FixedSpectrumBias','FixedSpectrumExactMeans','FixedSpectrumGaussianMoments',
 'FixedSpectrumCosineExpansion','FixedSpectrumGridAlias','FixedSpectrumVariances']]
paths+=['AutoSamplingTheory/TechnicalLemmas/StochasticProcesses/GaussianFourthMoment.lean']
pins=[]
for path in paths:
    current=(ROOT/path).read_bytes()
    atcommit=subprocess.check_output(['git','show','df64aaa6088b6ac88c35696acfed906031964d72:'+path],cwd=ROOT)
    pins.append({'path':path,'sha256':h(current),'candidate_commit_sha256':h(atcommit),'same_as_candidate':current==atcommit})
result={'scope':'Bounded explicit artifact hashes/context/snippets only. No general scanner, gate, compilation, native or browser execution.',
 'candidate_commit':'df64aaa6088b6ac88c35696acfed906031964d72',
 'binding_digest':digest(payload),'expected_binding':'aa982161b75c7550ba8168b07d4c45218f497e7463c99e250d66012c622de195',
 'binding_matches':digest(payload)=='aa982161b75c7550ba8168b07d4c45218f497e7463c99e250d66012c622de195',
 'review_context_matches_packet_exactly':context==packet['candidate_publication_context'],
 'canonical_reviewer_packet_digest':digest(packetbody),
 'canonical_reviewer_packet_digest_matches':digest(packetbody)=='992f9be35a150ec4fd8f75bfc19adce51a93bfc19574b07d27c35eb1ca0cb3a0',
 'selected_lesson_steps':snippet,'whitelisted_candidate_files':pins}
(OUT/'phase3_bound_inputs.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False,indent=2))
