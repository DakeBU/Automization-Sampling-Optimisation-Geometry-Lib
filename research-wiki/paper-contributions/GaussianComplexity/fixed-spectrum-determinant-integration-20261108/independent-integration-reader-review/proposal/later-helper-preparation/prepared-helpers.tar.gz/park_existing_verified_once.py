"""Future exactly-one explicit-root-authorized STAB to existing VERIFIED parking.

PREPARED ONLY. No automatic execution, retry, source verdict or lifecycle shortcut.
"""
import sys
sys.dont_write_bytecode=True
import contextlib, io, time, traceback
from det_acceptance_common import *

O = OWN/'normal-release'
AUTH = B/'normal-existing-V-release-authorization.json'

def put(path,value):
 assert not path.exists(),str(path)
 with path.open('xb') as stream: stream.write(dump(value))
def archive(name,raw):
 path=O/name; assert not path.exists()
 data=gzip.compress(raw,mtime=0)
 with path.open('xb') as stream: stream.write(data)
 assert gzip.decompress(path.read_bytes())==raw
 return {'path':rel(path),'raw_sha256':sha(raw),'gzip_sha256':sha(data),'raw_bytes':len(raw)}
def folder_hashes(folder,excluded=None):
 return {rel(p):sha(p.read_bytes()) for p in sorted(folder.rglob('*')) if p.is_file() and (excluded is None or not p.is_relative_to(excluded))}
def verify_prepared_helpers(a):
 ref=a['prepared_helper_manifest']; manifest=read_json_ref(ref)
 expected=P/'later-helper-preparation/preparation-manifest.json'
 assert resolve(ref['path'])==expected and manifest['state']=='PREPARATION_ONLY_AST_PARSED_NOT_EXECUTED'
 assert manifest['source_verifier_to_preserve']==VERIFIER and manifest['proof_owner_to_preserve']==PROOF
 listed={row['path']:row for row in manifest['helpers']}
 assert rel(Path(__file__).resolve()) in listed and rel(S/'det_acceptance_common.py') in listed
 for path,row in listed.items(): assert sha(resolve(path).read_bytes())==row['raw_sha256'],path
 assert a['prepared_parking_helper_sha256']==sha(Path(__file__).read_bytes())

def main():
 args=parse_args(__doc__)
 assert args.output is None,'Parking uses only its fixed write-once normal-release directory.'
 assert not O.exists(),'Normal-release directory already exists: STOP; never automatically retry or remove its guard.'
 assert resolve(args.authorization_json)==AUTH
 a,authref=load_authorization(args,'determinant-normal-existing-V-parking')
 assert a['authorize_exactly_one_normal_API_call'] is True and a['allow_shared_path_writes'] is False
 assert a['new_source_verdict'] is False
 verify_prepared_helpers(a)
 report,browser,images=all_readonly_checks(a)
 review=validate_image_review(a,images)
 retained=verify_archive(a)
 archive_receipt=read_json_ref(a['retained_archive_verification'])
 assert archive_receipt['state']=='LOSSLESS_RETAINED_BROWSER_ARCHIVE_VERIFIED' and archive_receipt['reviewer']==ACTOR
 assert archive_receipt['accepted_immutable_core']==a['accepted_immutable_core']
 assert archive_receipt['archive_sha256']==retained['archive_sha256'] and archive_receipt['original_hashes']==retained['original_hashes']
 acceptance=read_json_ref(a['independent_acceptance'])
 assert acceptance['state']=='LOCAL_INTEGRATION_ACCEPTED' and acceptance['reviewer']==ACTOR
 assert acceptance['accepted_immutable_core']==a['accepted_immutable_core'] and acceptance['publication_binding_sha256']==BINDING
 assert acceptance['blocking_objections']==[] and acceptance['actual_original_image_count']==38
 assert acceptance['actual_original_images_viewed']==review['images'] and acceptance['browser_report']==a['browser_report']
 assert acceptance['fresh_protection']==report['protection'] and acceptance['sourceV_lineage']==report['sourceV_lineage']
 assert acceptance['source_verifier_preserved']==VERIFIER and acceptance['proof_owner_preserved']==PROOF and acceptance['new_source_verdict'] is False
 assert acceptance['archive_sha256']==retained['archive_sha256'] and acceptance['parking_authorized_or_executed'] is False
 postcore=read_json_ref(a['independent_postcore_readback'])
 assert postcore['state']=='POSTCORE_READBACK_PASS_NOT_LOCAL_SITE_ACCEPTANCE' and postcore['reviewer']==ACTOR
 assert postcore['readback_phase']=='final-readback'
 assert postcore['accepted_immutable_core']==a['accepted_immutable_core'] and postcore['protection']==report['protection'] and postcore['sourceV_lineage']==report['sourceV_lineage']
 adv,_,site=modules(); core=a['accepted_immutable_core']; digest=a['source_digest']
 before=LEDGER.read_bytes(); discovery=DISC.read_bytes()
 assert sha(before)==a['ledger_before_sha256'] and sha(discovery)==a['discovery_ledger_sha256']
 states=adv.current_advances(); foreign={k:v for k,v in states.items() if k!=ADV}; assert len(foreign)==282
 original=decoded_ref(a['source_lineage']['source_V_append']); event=json.loads(original); se=event['evidence']
 assert sha(original)==a['source_V_append_to_preserve']==report['sourceV_lineage']['source_V_append_sha256'] and before.count(original)==1
 assert event['worker_id']==VERIFIER and se['verifier_id']==VERIFIER
 allfrontiers={rel(p):sha(p.read_bytes()) for p in (R/'research-wiki/frontier-cells').glob('*.json')}; assert len(allfrontiers)==442
 sourcehashes=folder_hashes(SOURCE); ownhashes=folder_hashes(OWN,excluded=O)
 plan=json.loads((P/'proposal-report.json').read_bytes())
 fixedpaths=set(json.loads(unpack(plan['protected_foreign_content'])))|set(json.loads(unpack(plan['older_GaussianComplexity_evidence'])))
 fixedpaths.update(row['path'] for row in plan['shared_paths'])
 fixedpaths.update(plan['source_Test_lesson_publication_pins']);fixedpaths.update(plan['unchanged_models'])
 fixedpaths.update([AUDIT_PATH,CELL_PATH,rel(AUTH),a['actual_gate']['path'],a['site_metadata']['path'],a['independent_acceptance']['path'],a['retained_archive_verification']['path'],a['independent_original_image_review']['path']])
 fixed={path:sha(resolve(path).read_bytes()) for path in fixedpaths}
 request={'advance_id':ADV,'to_state':'VERIFIED','worker_id':ACTOR,'modes':['mechanical-existing-source-verification-parking','release-locally-accepted-integration-lease'],'evidence':{
  'verifier_id':ACTOR,'verified_commit':core,'publication_declarations':[DECL],
  'parking_kind':'Mechanical STABILIZING to existing VERIFIED after actual local acceptance; no new source, semantic or mathematical verification.',
  'authorization':authref,'original_source_verifier_id':VERIFIER,'source_verifier':VERIFIER,'original_source_checked_commit':se['verified_commit'],'original_accepted_audit_first_commit':a['source_lineage']['accepted_audit_first_commit'],'original_source_V_first_commit':a['source_lineage']['source_V_first_commit'],'original_source_V_append_sha256':sha(original),'proving_owner_preserved':PROOF,'released_integration_owner':INTEGRATOR,
  'gate':{'kind':'Reuse the actual exact immutable core canonical Lean/site/graph/Chrome38 receipts and separately recorded independent38original acceptance. The normal API performs its genuine reviewed publication admission. No new build/browser verdict.','passed':True,'actual_core_commit':core,'source_digest':digest,'actual_gate':a['actual_gate'],'actual_site_metadata':a['site_metadata'],'actual_checks':report['actual_checks'],'actual_local_acceptance':a['independent_acceptance'],'actual_archive_verification':a['retained_archive_verification']},
  'source_audit':{'kind':'Reuse only the unchanged genuine original independent source V. Mechanical actor does not replace the source reviewer.','original_verifier':VERIFIER,'original_source_V_append_sha256':sha(original),'original_source_evidence':se['source_audit'],'current_accepted_audit':a['source_lineage']['accepted_audit'],'publication_binding_sha256':BINDING,'new_source_verdict':False},
  'fake_closure_scan':{'kind':'Reuse original independent scan and actual immutable canonical ASTIS gate; no new scan or verdict.','original_verifier':VERIFIER,'original_scan':se['fake_closure_scan'],'actual_root_ASTIS_success_at':core,'source_and_Test_bytes_unchanged':True},
  'local_acceptance_scope':'Actual cosine-grid determinant product and same-A Gaussian density consumer only. ONE canonicalDJE producer parent; three private Test consumer parents; one new Registry producer, administrative619; both models unchanged. Canonical DJE/GPD legacy audit and graph statuses remain unchanged.',
  'truth_boundary':'Local lease release only. Full unweighted Gaussian integral/knownZ, fullC4 and moments/Krylov, actual oracle/precision/TV/deterministic-cap/expected-cost adapters, both main lower bounds, remote publication, MERGED/PURIFIED/ExpositionSeal and wholeGoal remain separate.',
  'actual_external_route_boundary':'Own-site source/module/download and local immutable Git bytes passed. Per-row conditional GitHub syntax evidence controls that limited claim; external GitHubHTML and publicHTTP publication are not credited.',
  'new_source_mathematical_or_semantic_verdict':False,'mechanical_release_actor_not_source_verifier':ACTOR,'other_queue_or_remote_mutation':False}}
 # Every validation above is read only. Creating this fixed directory starts a
 # persistent one-attempt record; no subsequent run may reuse/remove it.
 O.mkdir(exist_ok=False)
 put(O/'normal-api-request.json',request)
 pre={'core':core,'source_digest':digest,'authorization':authref,'request':descriptor(O/'normal-api-request.json'),'ledger_before':archive('advance-ledger.before.raw.jsonl.gz',before),'discovery_before':archive('discovery-ledger.before.raw.jsonl.gz',discovery),'all282_foreign_states':archive('foreign-states.before.json.gz',canon(foreign)),'all442_frontiers':archive('frontier-hashes.before.json.gz',canon(allfrontiers)),'all_source_evidence':archive('source-evidence-hashes.before.json.gz',canon(sourcehashes)),'earlier_own_reviews':archive('earlier-review-hashes.before.json.gz',canon(ownhashes)),'fixed_bytes':fixed,'normal_API_calls_so_far':0}
 put(O/'preflight.json',pre)
 assert LEDGER.read_bytes()==before and DISC.read_bytes()==discovery and head()==core and site.source_digest()==digest
 put(O/'attempt-guard.json',{'actor':ACTOR,'advance_id':ADV,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'request':descriptor(O/'normal-api-request.json'),'allowed_normal_API_invocations':1,'retry_policy':'After this persisted guard never retry automatically, including API rejection, process interruption or partial append. Preserve exact evidence and stop.'})
 stream=io.StringIO();error=None;started=datetime.datetime.now(datetime.timezone.utc).isoformat();clock=time.monotonic()
 with contextlib.redirect_stdout(stream),contextlib.redirect_stderr(stream):
  try:
   adv.transition_advance(ADV,to_state='VERIFIED',worker_id=ACTOR,modes=request['modes'],evidence=request['evidence'])
   print('Single normal API returned; mechanical existing-V parking only. No new source verdict.')
  except Exception:
   error=traceback.format_exc(); print(error)
 elapsed=time.monotonic()-clock;rawlog=stream.getvalue().encode()
 (O/'normal-api.stdout.raw').write_bytes(rawlog)
 after=LEDGER.read_bytes();prefixok=after.startswith(before);append=after[len(before):] if prefixok else b''
 receipt={'actual_API':'tools.astis_advance.transition_advance','actual_API_calls':1,'actual_actor':ACTOR,'started_utc':started,'completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'elapsed_seconds':elapsed,'exit_code':1 if error else 0,'error':error,'head_before':core,'head_after':head(),'request':descriptor(O/'normal-api-request.json'),'stdout':descriptor(O/'normal-api.stdout.raw'),'stdout_archive':archive('normal-api.stdout.raw.gz',rawlog),'ledger_before_sha256':sha(before),'ledger_after_sha256':sha(after),'exact_prefix_preserved':prefixok,'append_bytes':len(append),'append_sha256':sha(append),'new_source_verdict':False}
 put(O/'normal-api-execution.receipt.json',receipt)
 archive('advance-ledger.after.raw.jsonl.gz',after)
 archive('advance-ledger.append.raw.jsonl.gz',append)
 if error:
  print(json.dumps({'state':'NORMAL_API_REJECTED_STOP_NO_RETRY','receipt':descriptor(O/'normal-api-execution.receipt.json'),'append_bytes':len(append)}));return 1
 try:
  assert prefixok and len(append.splitlines())==1
  parked=json.loads(append);assert parked['advance_id']==ADV and parked['from_state']=='STABILIZING' and parked['to_state']=='VERIFIED'
  assert parked['worker_id']==ACTOR and parked['evidence']==request['evidence']
  now=adv.current_advances();assert now[ADV]['state']=='VERIFIED' and now[ADV]['owner_id']==PROOF
  assert now[ADV]['latest_evidence']['original_source_verifier_id']==VERIFIER
  assert not [k for k,v in now.items() if v['state']=='STABILIZING']
  assert {k:v for k,v in now.items() if k!=ADV}==foreign and DISC.read_bytes()==discovery
  assert folder_hashes(SOURCE)==sourcehashes and folder_hashes(OWN,excluded=O)==ownhashes
  assert {rel(p):sha(p.read_bytes()) for p in (R/'research-wiki/frontier-cells').glob('*.json')}==allfrontiers
  assert all(sha(resolve(path).read_bytes())==digest_ for path,digest_ in fixed.items())
  assert before.count(original)==after.count(original)==1 and LEDGER.read_bytes()==after
  assert head()==core and site.source_digest()==digest
 except Exception:
  put(O/'postcondition-failure.json',{'actual_API_already_returned':True,'error':traceback.format_exc(),'rule':'Do not retry, roll back, reset or reconstruct the ledger. Preserve exact append and stop.'});raise
 (O/'advance-ledger.append.raw.jsonl').write_bytes(append)
 protection={'all282_foreign_states_unchanged':True,'all442_frontiers_including441_foreign_byte_unchanged':True,'all_protected_foreign_inputs_and_old_GC_bytes_unchanged':True,'all_source_evidence_byte_unchanged':len(sourcehashes),'all_earlier_own_review_files_byte_unchanged':len(ownhashes),'canonical_audit_cell_sixpaths_models_README_byte_unchanged':True,'old_advance_prefix_and_entire_discovery_ledger_preserved':True,'exact_normal_append_events':1,'append_sha256':sha(append),'ledger_after_sha256':sha(after),'proof_owner_preserved':PROOF,'original_source_verifier_preserved':VERIFIER,'original_source_V_append_still_unique_and_unchanged':sha(original),'actual_final_state':'VERIFIED','STABILIZING_after':[]}
 put(O/'protection.json',protection)
 summary={'actor':ACTOR,'operation':'Exactly one explicitly root-authorized normal STABILIZING to existing VERIFIED parking/release','core':core,'authorization':authref,'actual_normal_API_receipt':descriptor(O/'normal-api-execution.receipt.json'),'protection':descriptor(O/'protection.json'),'actual_unique_append_sha256':sha(append),'ledger_after_sha256':sha(after),'final_state':'VERIFIED','proof_owner':PROOF,'original_source_verifier':VERIFIER,'normal_STAB_after':[],'new_source_verifications':0,'new_build_browser_remote_merge_or_purification_actions':0,'frontier_metadata_not_projected_here':True,'README_unchanged_here':True,'remote_publication_purification_ExpositionSeal_both_mainbounds_wholeGoal_complete':False,'writes_stopped_after_summary':True}
 put(O/'release-summary.json',summary)
 archive('executed-normal-release-driver.py.gz',Path(__file__).read_bytes())
 print(json.dumps({'state':'NORMAL_EXISTING_V_PARKED','normal_API_calls':1,'append_sha256':sha(append),'summary':descriptor(O/'release-summary.json'),'new_source_verdict':False,'writes_stopped':True}));return 0

if __name__=='__main__': sys.exit(main())
