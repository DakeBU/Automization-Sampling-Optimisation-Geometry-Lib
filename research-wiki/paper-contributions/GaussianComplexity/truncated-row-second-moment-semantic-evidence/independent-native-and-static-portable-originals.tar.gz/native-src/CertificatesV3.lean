import Tests.GaussianComplexityFixedSpectrumTruncatedRowMoment
import Lean.Util.CollectAxioms
import Lean.Util.FoldConsts
noncomputable section
open MeasureTheory ProbabilityTheory
open scoped Matrix.Norms.L2Operator
set_option autoImplicit false
elab "privateTarget68bc" : term => do
  let env ← Lean.getEnv
  let found := env.constants.toList.find? (fun (n, _) => n.toString.endsWith "actual_truncated_matrix_summand_mean")
  let some (n, _) := found | throwError "private consumer missing"
  return Lean.mkConst n
namespace Native68bcV3
theorem public_seal_certificate
    {d q : ℕ} (hq : 2 * q + 1 < d) :
  let E := EuclideanSpace ℝ (Fin (q + 1))
  let μ : Measure E := stdGaussian E
  let r : ℝ := ((q + 1 : ℕ) : ℝ)
  let R : E → ℝ := fun x => ‖x‖ ^ 2
  let L : ℝ := 2 * r + 3 * Real.log (1000 * (d : ℝ))
  let a : ℝ := (∫ x, Set.indicator {y : E | R y ≤ L} R x ∂μ) / r
  let G : E → Matrix (Fin (q + 1)) (Fin (q + 1)) ℝ :=
    fun x => Matrix.vecMulVec (WithLp.ofLp x) (WithLp.ofLp x)
  let kept : E → Matrix (Fin (q + 1)) (Fin (q + 1)) ℝ :=
    Set.indicator {y : E | R y ≤ L} G
  Integrable kept μ ∧
    (∫ x, kept x ∂μ) = a • (1 : Matrix (Fin (q + 1)) (Fin (q + 1)) ℝ) := by
  exact AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumTruncatedRowMoment.actual_truncated_row_second_moment hq

theorem private_seal_certificate
    {d q : ℕ} (hq : 2 * q + 1 < d) (i : Fin d) :
  let E := EuclideanSpace ℝ (Fin (q + 1))
  let μ : Measure E := stdGaussian E
  let r : ℝ := ((q + 1 : ℕ) : ℝ)
  let R : E → ℝ := fun x => ‖x‖ ^ 2
  let L : ℝ := 2 * r + 3 * Real.log (1000 * (d : ℝ))
  let a : ℝ := (∫ x, Set.indicator {y : E | R y ≤ L} R x ∂μ) / r
  let θ : Fin d → ℝ := fun j => ((j.val : ℝ) + 1 / 2) * Real.pi / (d : ℝ)
  let t : Fin d → Fin (q + 1) → ℝ := fun j k =>
    if k.val = 0 then 1 else Real.sqrt 2 * Real.cos ((k.val : ℝ) * θ j)
  let G : E → Matrix (Fin (q + 1)) (Fin (q + 1)) ℝ :=
    fun x => Matrix.vecMulVec (WithLp.ofLp x) (WithLp.ofLp x)
  let Y : E → Matrix (Fin (q + 1) × Fin (q + 1)) (Fin (q + 1) × Fin (q + 1)) ℝ :=
    Set.indicator {y : E | R y ≤ L}
      (fun x => (d : ℝ)⁻¹ • Matrix.kronecker (G x) (Matrix.vecMulVec (t i) (t i)))
  Integrable Y μ ∧
    (∫ x, Y x ∂μ) =
      (a / (d : ℝ)) • Matrix.kronecker
        (1 : Matrix (Fin (q + 1)) (Fin (q + 1)) ℝ) (Matrix.vecMulVec (t i) (t i)) := by
  exact privateTarget68bc hq i

end Native68bcV3

#print axioms Native68bcV3.public_seal_certificate
#print axioms Native68bcV3.private_seal_certificate
#check AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumTruncatedRowMoment.actual_truncated_row_second_moment

#print Matrix.instL2OpNormedAddCommGroup
#print Matrix.l2OpNormedAddCommGroupAux
#print Matrix.l2_opNorm_def
#print EuclideanSpace
#print ProbabilityTheory.stdGaussian
#print Matrix.vecMulVec
#print Set.indicator
#print Matrix.kronecker
#print WithLp.ofLp

open Lean Elab Command
private def owned68bc (n : Name) : Bool :=
  n.toString.startsWith "AutoSamplingTheory." || n.toString.startsWith "_private.Tests.GaussianComplexityFixedSpectrumTruncatedRowMoment."
run_elab do
  let env ← getEnv
  let found := env.constants.toList.find? (fun (n, _) => n.toString.endsWith "actual_truncated_matrix_summand_mean")
  let some (privateName, pc) := found | throwError "private missing"
  logInfo m!"ACTUAL_PRIVATE_NAME {privateName}"
  logInfo m!"ACTUAL_PRIVATE_TYPE {pc.type}"
  let targets := #[`AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumTruncatedRowMoment.actual_truncated_row_second_moment, privateName]
  let mut frontier := targets.toList
  let mut visited : NameSet := {}
  while !frontier.isEmpty do
    let n := frontier.head!
    frontier := frontier.tail!
    if !visited.contains n then
      visited := visited.insert n
      let some c := env.find? n | throwError "missing target {n}"
      let ds := c.getUsedConstantsAsSet.toList
      let bodyDs : List Name := match c.value? (allowOpaque := true) with
        | some v => v.getUsedConstants.toList
        | none => []
      let axs ← collectAxioms n
      logInfo m!"OWNED_DECL {n}"
      logInfo m!"BODY_DIRECT {n}: {bodyDs}"
      logInfo m!"OWNED_DIRECT {n}: {bodyDs.filter owned68bc}"
      logInfo m!"AXIOMS {n}: {axs}"
      for dep in ds do
        if owned68bc dep && !visited.contains dep then frontier := dep :: frontier
  logInfo m!"REACHABLE_OWNED {visited.toList}"
