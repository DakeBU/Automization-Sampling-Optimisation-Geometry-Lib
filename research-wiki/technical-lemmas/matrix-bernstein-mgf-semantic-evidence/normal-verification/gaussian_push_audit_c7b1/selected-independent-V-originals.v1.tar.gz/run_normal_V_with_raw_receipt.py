#!/usr/bin/env python3
"""Capture actual OS stdout/stderr of the sole independent normal-V driver."""
from pathlib import Path
import datetime as dt
import hashlib
import json
import os
import subprocess
import sys
import time

ROOT = Path('/Users/zhouhuanjian/ASTIS-GC')
OWN = Path(__file__).resolve().parent
driver = OWN / 'execute_normal_V_once.py'
receipt_path = OWN / 'normal-V-actual-process-receipt.v1.json'
assert not receipt_path.exists() and not (OWN / 'normal-V-api-attempt-begun.json').exists()
acceptance = json.loads((OWN / 'pre-V-independent-acceptance.v1.json').read_text())
sha = lambda b: hashlib.sha256(b).hexdigest()
assert sha(driver.read_bytes()) == acceptance['execution_script_sha256']
command = [sys.executable, str(driver)]
started = dt.datetime.now(dt.timezone.utc).isoformat()
clock = time.monotonic()
stdout, stderr = OWN / 'normal-V.stdout.raw', OWN / 'normal-V.stderr.raw'
with stdout.open('xb') as out, stderr.open('xb') as err:
    result = subprocess.run(command, cwd=ROOT,
        env=dict(os.environ, GIT_OPTIONAL_LOCKS='0', PYTHONDONTWRITEBYTECODE='1'), stdout=out, stderr=err)
def item(p):
    data = p.read_bytes()
    return {'path': p.name, 'bytes': len(data), 'sha256': sha(data)}
records = [json.loads(x) for x in (ROOT / 'runs/substantive_advances.jsonl').read_bytes().splitlines()]
vs = [x for x in records if x.get('advance_id') == 'ASTIS-SA-20261114-MatrixBernsteinMgf' and x.get('to_state') == 'VERIFIED']
receipt = {'schema': 'weighted-MGF-actual-one-normal-V-process-receipt-v1',
    'actual_process_invoker_and_normal_API_verifier': '/root/gaussian_push_audit_c7b1',
    'proving_owner': 'huanjian_20261114_matrix_bernstein_mgf', 'ROOT_invoked_this_API': False,
    'verified_commit': '6abc79ed4c012c1d506c17b9824257769c18c635',
    'command': command, 'cwd': str(ROOT), 'started_utc': started,
    'ended_utc': dt.datetime.now(dt.timezone.utc).isoformat(), 'elapsed_seconds': time.monotonic() - clock,
    'exit_code': result.returncode, 'stdout': item(stdout), 'stderr': item(stderr),
    'execution_script': item(driver), 'capture_script': item(Path(__file__).resolve()),
    'full_payload': item(OWN / 'VERIFIED-evidence.full.v2.json'),
    'attempt_marker_exists': (OWN / 'normal-V-api-attempt-begun.json').exists(),
    'observed_target_VERIFIED_events_after_process': len(vs),
    'preservation_summary_exists': (OWN / 'normal-V-preservation-summary.v1.json').exists(),
    'stream_capture': 'Real child OS stdout/stderr file descriptors, not reconstructed from ledger/check flags.',
    'retry_policy': 'No automatic retry even if exception/timeout. Reconcile exact canonical ledger first.',
    'full_private_guards_or_global_private_fingerprints_exported': False}
with receipt_path.open('x') as f:
    json.dump(receipt, f, ensure_ascii=False, indent=2)
    f.write('\n')
print(json.dumps({'actual_exit_code': result.returncode, 'observed_target_V_events': len(vs),
    'receipt': str(receipt_path), 'receipt_sha256': sha(receipt_path.read_bytes()),
    'stdout': item(stdout), 'stderr': item(stderr)}))
raise SystemExit(result.returncode)
