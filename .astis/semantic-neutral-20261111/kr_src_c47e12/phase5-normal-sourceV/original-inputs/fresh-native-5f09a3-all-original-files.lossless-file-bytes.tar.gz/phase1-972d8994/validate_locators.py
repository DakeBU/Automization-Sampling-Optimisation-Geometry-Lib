from driver import *
import re

E='research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-krylov-range-semantic-evidence'
INPUTS=['source-to-lean-map-v1.json','canonical-declaration-inventory.json','candidate-exposition-source-map.json']
RAW=REPO/'.astis/huanjian-resume-20261103/2610.20492v1.html'
assert (PHASE/'native-independent-boundary.json').exists()
native=json.loads((PHASE/'native-inventory.json').read_text())
constants={r['name']:r for r in native['owned']}
raw=RAW.read_bytes(); rawtext=raw.decode('utf-8')
assert sha(raw)=='6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
cache={str(RAW):raw}; rows=[]
def data_for(s):
    path=s.get('original_file',s.get('file'))
    if not path:return str(RAW),raw
    p=Path(path)
    if '/source-map-author-31f8c2/input-originals/kernel-log.log' in path:
        # This is the separately authorized post-freeze, bytes-only supplement.
        return path,p.read_bytes()
    rel=p.relative_to(REPO)
    if str(rel).startswith('.lake/packages/mathlib/'):
        if path not in cache:cache[path]=p.read_bytes()
        return path,cache[path]
    target=PHASE/'candidate'/rel
    if not target.is_file():raise ValueError('Unauthorized/unextracted span input '+path)
    return path,target.read_bytes()
def check(s,where):
    path,b=data_for(s); t=b.decode('utf-8'); chars=s.get('character_span_0based_halfopen',s.get('char_span_0based_halfopen')); bs=s.get('utf8_byte_span_0based_halfopen',s.get('utf8_span_0based_halfopen')); a,z=chars; l,h=bs; snippet=t[a:z]; piece=b[l:h]
    actual_lines=[t[:a].count('\n')+1,t[:z-(1 if snippet.endswith('\n') else 0)].count('\n')+1]
    checks={'bounds':0<=a<=z<=len(t) and 0<=l<=h<=len(b),'character_byte_identity':snippet.encode()==piece,'byte_start':len(t[:a].encode())==l,'byte_end':len(t[:z].encode())==h,'lf_lines':actual_lines==s['lf_lines_1based_inclusive'],'span_hash':sha(piece)==s.get('raw_span_sha256',s.get('sha256_raw_utf8'))}
    if 'file_raw_sha256' in s:checks['file_hash']=sha(b)==s['file_raw_sha256']
    if 'terminal_LF_included' in s:checks['terminal_LF']=snippet.endswith('\n')==s['terminal_LF_included']
    if s.get('id'):checks['source_id_present']=('id="'+s['id']+'"') in snippet
    r={'location':where,'original_file':path,'checks':checks,'passed':all(checks.values()),'actual_lines':actual_lines,'actual_span_sha256':sha(piece),'actual_file_sha256':sha(b),'root_kernel_log_bytes_only_after_native_freeze':'/kernel-log.log' in path}
    rows.append(r);return snippet
def walk(v,where):
    if isinstance(v,dict):
        if 'character_span_0based_halfopen' in v or 'char_span_0based_halfopen' in v:check(v,where)
        for k,x in v.items():walk(x,where+'/'+k)
    elif isinstance(v,list):
        for i,x in enumerate(v):walk(x,where+'/'+str(i))
objects={f:json.loads((PHASE/'candidate'/E/f).read_text()) for f in INPUTS}
for f,o in objects.items():walk(o,f)
canonical=[]
snips=PHASE/'canonical-selected-spans';snips.mkdir(exist_ok=True)
for i,r in enumerate(objects['canonical-declaration-inventory.json']['records']):
    path,b=data_for(r['span']);a,z=r['span']['character_span_0based_halfopen']; snippet=b.decode()[a:z]
    (snips/f'{i:02d}.lean').write_text(snippet)
    direct=[]
    for target in r['actual_direct_in']:
        ci=constants.get(target)
        if ci is None:ci=next((v for n,v in constants.items() if n.endswith('.'+target)),None)
        direct.append({'target':target,'target_found':ci is not None,'in_direct_value':r['name'] in ci['direct_value_constants'] if ci else False,'in_direct_type':r['name'] in ci['direct_type_constants'] if ci else False})
    short=r['name'].split('.')[-1]
    canonical.append({'name':r['name'],'selected_span':f'canonical-selected-spans/{i:02d}.lean','source_declaration_token':bool(re.search(r'\b(?:def|abbrev|theorem|lemma|structure|class|inductive)\s+(?:_root_\.)?'+re.escape(short)+r'(?:\b|\s|\{|\()',snippet)),'actual_direct_claims':direct,'direct_claims_valid':all(x['target_found'] and (x['in_direct_value'] or x['in_direct_type']) for x in direct),'enclosing_declaration_note':r.get('enclosing_declaration_note')})
lesson=json.loads((PHASE/'candidate/website/content/declaration_lessons/huanjian-fixed-spectrum-krylov-range.json').read_text())['units'][0]
steps=[]
for s,m in zip(lesson['steps'],objects['candidate-exposition-source-map.json']['steps']):
    _,b=data_for(m['contiguous_lean_span']);a,z=m['contiguous_lean_span']['character_span_0based_halfopen'];piece=b.decode()[a:z]
    _,jb=data_for(m['exact_json_string_span']);a,z=m['exact_json_string_span']['character_span_0based_halfopen'];jpiece=jb.decode()[a:z]
    try:decoded=json.loads(jpiece)
    except Exception:decoded=None
    steps.append({'step':m['step'],'title':s['title'],'lean_exact_contiguous':s['lean']==piece,'json_literal_decodes_exact':decoded==s['lean'],'code_hash':sha(s['lean'].encode())==m['exact_code_sha256'],'formula_matches_map':s['formula']==m['formula'],'prose_matches_map':s['text']==m['text']})
result={'candidate':CAND,'native_boundary_sha256':sha((PHASE/'native-independent-boundary.json').read_bytes()),'raw_source_file_sha256':sha(raw),'source_semantics_reviewed':False,'span_count':len(rows),'span_results':rows,'failed_spans':[r for r in rows if not r['passed']],'canonical_count':len(canonical),'canonical':canonical,'canonical_direct_claim_failures':[r for r in canonical if not r['direct_claims_valid']],'canonical_token_warnings':[r for r in canonical if not r['source_declaration_token']],'exposition_steps':steps,'root_kernel_log_supplement_scope':'Only raw file hashes and map-referenced byte/character/LF span arithmetic after native results frozen. No log content was used as proof/type/source authority.'}
(PHASE/'locator-and-canonical-validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['span_results','canonical']},ensure_ascii=False,indent=2))
