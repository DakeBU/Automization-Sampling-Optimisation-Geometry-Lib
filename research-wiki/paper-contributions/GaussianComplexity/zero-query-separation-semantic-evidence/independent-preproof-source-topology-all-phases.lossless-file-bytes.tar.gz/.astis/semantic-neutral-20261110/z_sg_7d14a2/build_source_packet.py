from pathlib import Path
import hashlib,json,datetime
ROOT=Path('/Users/zhouhuanjian/ASTIS-GC')
OWN=ROOT/'.astis/semantic-neutral-20261110/z_sg_7d14a2'
idx=json.loads((OWN/'raw-fragment-index.json').read_text())
elements={x['anchor']:x for x in idx['elements']}
def save(name,obj): (OWN/name).write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n')
def locus(anchor):
 e=elements[anchor];return {k:e[k] for k in ('anchor','start_byte','end_byte_exclusive','bytes','sha256')}
def node(id,kind,statement,anchors=(),**extra):return dict(id=id,kind=kind,statement=statement,source=[locus(a) for a in anchors],**extra)
nodes=[
 node('D:notational','SOURCE_DEFINITION','Euclidean norm, d-dimensional identity, symmetric-matrix Loewner order A ≼ B iff B − A is positive semidefinite.',['S2.p1.1'],logical_use='Identity and Loewner conventions enter pair admissibility; Euclidean norm is retained context, unused in this slice.'),
 node('D:class-context','SOURCE_CONTEXT','Centered Gaussians; integer d ≥ 1, real κ ≥ 1; normalized spectral bounds 1 and κ.',['S2.SS0.SSS0.Px1.p1.1']),
 node('D:precision-class','SOURCE_DEFINITION','𝒜(d,κ) = {A ∈ ℝ^(d×d) : A = Aᵀ and I_d ≼ A ≼ κ I_d}.',['S2.Ex1']),
 node('D:gaussian-target','SOURCE_DEFINITION','Input A specifies f_A(x) = xᵀAx/2 and π_A = N(0,A⁻¹). A is precision; A⁻¹ is covariance.',['S2.SS0.SSS0.Px1.p1.2'],logical_use='Only target-law meaning is a logical parent of the event estimate. The potential formula is retained source context.'),
 node('D:algorithm','SOURCE_DEFINITION','Queries, stopping decisions, and output are Borel functions of internal randomness and previous oracle responses; seed is independent of the input. A fixed budget T caps queries for every input and every seed.',['S2.SS0.SSS0.Px2.p1.1']),
 node('D:TV','SOURCE_DEFINITION','TV(P,Q) = sup over measurable B of |P(B) − Q(B)| = (1/2)∫|p − q|dλ.',['S2.SS0.SSS0.Px3.p1.1','S2.Ex2','S2.SS0.SSS0.Px3.p1.2'],logical_use='The event-supremum definition is used here. The density representation and [0,1]-test expectation estimate are retained context, not extra incoming analytic requirements.'),
 node('D:output-law','SOURCE_DEFINITION','ρ_A^Alg is the output law including all internal randomness; accuracy parameter is defined for 0 < ε < 1.',['S2.SS0.SSS0.Px4.p1.1']),
 node('D:query-complexity','SOURCE_DEFINITION','Q_G is the infimum of T ∈ ℤ_{≥0} for which a fixed-budget randomized algorithm has sup_A TV(ρ_A^Alg,π_A) ≤ ε.',['S2.E2']),
 node('D:accuracy-semantics','SOURCE_CONTEXT','Accuracy is uniform over inputs and averages over seed; budgets are deterministic per-run caps, not expected query costs.',['S2.SS0.SSS0.Px4.p1.2']),
 node('H:ranges','SOURCE_HYPOTHESES','d is an integer ≥ 1; κ ≥ 4; 0 < ε ≤ 1/16.',['S3.p1.1','S3.Thmtheorem1.p1.1']),
 node('C:main-theorem','CONTEXTUAL_UNCLOSED_ROOT','Q_G(d,κ,ε) ≥ (1/256) min{d, √κ log(1 + d/(√κ ε))}.',['S3.E3'],not_claimed_closed=True),
 node('H:fixed-budget','SOURCE_HYPOTHESES','Alg has fixed query budget T.',['S3.SS3.p1.1']),
 node('H:uniform-accuracy','SOURCE_HYPOTHESES','TV(ρ_A^Alg,π_A) ≤ ε for every A ∈ 𝒜(d,κ).',['S3.SS3.p1.1']),
 node('Z:pair','SOURCE_PROOF_STEP','A₀ = I_d and A₁ = diag(κ,1,…,1).',['S3.SS3.SSS0.Px1.p1.1']),
 node('G:pair-admissibility','SOURCE_GAP','A₀ and A₁ are in 𝒜(d,κ), with invertible positive covariance inverses.',['S3.SS3.SSS0.Px1.p1.1'],gap_type='omitted standard linear-algebra bridge; not a proposed repair',source_hypothesis=False),
 node('Z:common-law','SOURCE_PROOF_STEP','Under the temporary zero-query case T = 0, ρ_A₀^Alg = ρ_A₁^Alg =: μ.',['S3.SS3.SSS0.Px1.p1.1'],conditional='T = 0, discharged by contradiction'),
 node('G:no-information-law','SOURCE_GAP','With no responses, the output is a Borel function of the input-independent seed alone, hence has a common probability law.',['S3.SS3.SSS0.Px1.p1.1'],gap_type='omitted consequence of source algorithm definition',source_hypothesis=False),
 node('Z:event','SOURCE_PROOF_STEP','E = {x ∈ ℝ^d : |x₁| ≤ 1/2}.',['S3.SS3.SSS0.Px1.p1.1'],strictness='Source event uses ≤, not <. First coordinate exists for every d ≥ 1.'),
 node('G:event-measurable','SOURCE_GAP','E is Borel, so it is allowed in the TV supremum.',['S3.SS3.SSS0.Px1.p1.1'],gap_type='omitted standard measurability bridge',source_hypothesis=False),
 node('G:normal-law','SOURCE_GAP','The first marginals of π_A₀ and π_A₁ are N(0,1) and N(0,1/κ). The standard normal density is φ(t) = exp(−t²/2)/√(2π), with integral 1 and even symmetry.',['S3.Ex3'],gap_type='implicit standard Gaussian normalization/marginal/scaling facts',source_hypothesis=False),
 node('G:event-masses','SOURCE_GAP','π_A₀(E) = 2∫₀^(1/2) φ(t)dt and π_A₁(E) = 2∫₀^(√κ/2) φ(t)dt. Thus their difference is nonnegative, and κ ≥ 4 yields a difference at least 2∫_(1/2)^1 φ(t)dt.',['S3.SS3.SSS0.Px1.p1.1','S3.Ex3'],gap_type='omitted scaling, symmetry, interval subtraction, positivity and √κ/2 ≥ 1 bridge',source_hypothesis=False),
 node('Z:event-separation','SOURCE_DISPLAY_STEP','TV(π_A₀,π_A₁) ≥ 2∫_(1/2)^1 exp(−t²/2)/√(2π) dt.',['S3.Ex3']),
 node('G:integral-lower-bound','SOURCE_GAP','On t ∈ [1/2,1], φ(t) ≥ exp(−1/2)/√(2π); interval length is 1/2, canceled by the leading factor 2.',['S3.Ex3'],gap_type='omitted elementary integral bound',source_hypothesis=False),
 node('Z:integral-bound','SOURCE_DISPLAY_STEP','2∫_(1/2)^1 φ(t)dt ≥ exp(−1/2)/√(2π).',['S3.Ex3']),
 node('G:numerical-comparison','SOURCE_GAP','exp(−1/2)/√(2π) > 1/8.',['S3.Ex3'],gap_type='elementary strict numerical comparison asserted without calculation; no independent proof supplied by this source author',source_hypothesis=False),
 node('Z:strict-separation','EXTRACTED_SOURCE_CONCLUSION','TV(π_A₀,π_A₁) ≥ exp(−1/2)/√(2π) > 1/8.',['S3.Ex3']),
 node('Z:epsilon-endpoint','SOURCE_DISPLAY_STEP','1/8 ≥ 2ε, including ε = 1/16.',['S3.Ex3']),
 node('B:TV-triangle','AUTHOR_INVOKED_STANDARD_BACKGROUND','TV triangle inequality and symmetry for probability measures on the same measurable space.',['S3.SS3.SSS0.Px1.p1.2'],source_hypothesis=False),
 node('G:accuracy-instantiation','SOURCE_GAP','Uniform accuracy applies to both admissible A₀,A₁; with their common law μ, TV(π_A₀,π_A₁) ≤ TV(π_A₀,μ) + TV(μ,π_A₁) ≤ 2ε.',['S3.SS3.SSS0.Px1.p1.2'],gap_type='omitted instantiation and triangle-inequality bookkeeping',source_hypothesis=False),
 node('Z:contradiction','SOURCE_PROOF_STEP','Under T = 0, the displayed strict separation TV(π_A₀,π_A₁) > 1/8 ≥ 2ε contradicts the accuracy triangle upper bound.',['S3.SS3.SSS0.Px1.p1.2']),
 node('G:budget-integrality','SOURCE_GAP','T ∈ ℤ_{≥0}; excluding T = 0 gives T ≥ 1.',['S3.SS3.SSS0.Px1.p1.2'],gap_type='omitted elementary integer endpoint bridge',source_hypothesis=False),
 node('Z:positive-budget','EXTRACTED_SOURCE_CONCLUSION','Every algorithm in the Section 3 range with deterministic fixed budget and uniform TV accuracy has T ≥ 1.',['S3.SS3.SSS0.Px1.p1.2']),
 node('L:large-dimension-branch','CONDITIONAL_SOURCE_STEP','If 2T + 1 > d, integrality gives T ≥ d/2.',['S3.SS3.SSS0.Px1.p1.2'],conditional='2T + 1 > d'),
 node('G:large-branch-arithmetic','SOURCE_GAP','Integer T,d turn 2T + 1 > d into 2T ≥ d; T ≥ d/2 dominates the main theorem RHS because min{d,…} ≤ d and 1/2 ≥ 1/256.',['S3.SS3.SSS0.Px1.p1.2'],gap_type='omitted elementary integer and min/comparison bookkeeping',source_hypothesis=False),
 node('L:large-branch-conclusion','CONDITIONAL_SOURCE_CONCLUSION','The claimed main lower bound holds for the conditional branch 2T + 1 > d.',['S3.SS3.SSS0.Px1.p1.2'],not_global_closure=True),
 node('L:remaining-range','SOURCE_SCOPE_REDUCTION','Henceforth assume 2T + 1 ≤ d. Together with T ≥ 1 this prepares the later n = 2T + 1 ≥ 3 construction, whose proof is outside this extraction.',['S3.SS3.SSS0.Px1.p1.2'])
]
byid={n['id']:n for n in nodes}
edges=[]
def edge(parents,child,use,reason,condition=None):
 d=dict(parents=parents,consumer=child,consumer_use_site=locus(use),logic='AND within this edge',reason=reason)
 if condition:d['conditional_scope']=condition
 edges.append(d)
edge(['D:notational','D:class-context','D:precision-class','H:ranges','Z:pair'],'G:pair-admissibility','S3.SS3.SSS0.Px1.p1.1','Diagonal entries satisfy the source class bounds; d ≥ 1 supplies the first coordinate.')
edge(['D:algorithm','D:output-law','D:accuracy-semantics','H:fixed-budget'],'G:no-information-law','S3.SS3.SSS0.Px1.p1.1','No oracle response can enter a zero-query output.','T = 0')
edge(['G:no-information-law'],'Z:common-law','S3.SS3.SSS0.Px1.p1.1','The source explicitly asserts equal output distributions.','T = 0')
edge(['Z:event','H:ranges'],'G:event-measurable','S3.SS3.SSS0.Px1.p1.1','Continuous first-coordinate map and closed interval give a Borel event.')
edge(['D:gaussian-target','Z:pair','G:pair-admissibility'],'G:normal-law','S3.Ex3','Precision inverse fixes coordinate variances and the normalized scalar density.')
edge(['G:normal-law','Z:event','H:ranges'],'G:event-masses','S3.Ex3','Scale the first coordinate and use κ ≥ 4, not a d ≥ 2 assumption.')
edge(['D:TV','G:event-measurable','G:event-masses'],'Z:event-separation','S3.Ex3','The TV supremum bounds the nonnegative event mass difference.')
edge(['G:normal-law'],'G:integral-lower-bound','S3.Ex3','Lower bound the source density on the displayed interval.')
edge(['G:integral-lower-bound'],'Z:integral-bound','S3.Ex3','Integrate over length 1/2 and retain leading factor 2.')
edge(['Z:event-separation','Z:integral-bound','G:numerical-comparison'],'Z:strict-separation','S3.Ex3','The source display supplies the one sufficient separation route.')
edge(['H:ranges'],'Z:epsilon-endpoint','S3.Ex3','ε ≤ 1/16 implies 2ε ≤ 1/8; positive ε is retained source range.')
edge(['G:pair-admissibility','H:uniform-accuracy','Z:common-law','B:TV-triangle'],'G:accuracy-instantiation','S3.SS3.SSS0.Px1.p1.2','Instantiate source accuracy twice and apply the author-invoked triangle inequality.','T = 0')
edge(['Z:strict-separation','Z:epsilon-endpoint','G:accuracy-instantiation'],'Z:contradiction','S3.SS3.SSS0.Px1.p1.2','A strict lower bound and a weak upper bound conflict even at ε = 1/16.','T = 0')
edge(['D:query-complexity','H:fixed-budget','Z:contradiction'],'G:budget-integrality','S3.SS3.SSS0.Px1.p1.2','The budget domain is nonnegative integral; the temporary zero-query case is ruled out.','T = 0 assumption discharged')
edge(['G:budget-integrality'],'Z:positive-budget','S3.SS3.SSS0.Px1.p1.2','This is the explicit Thus T ≥ 1 conclusion.')
edge(['D:query-complexity','H:ranges'],'G:large-branch-arithmetic','S3.SS3.SSS0.Px1.p1.2','Use integral budget/dimension and the main RHS min bound.','2T + 1 > d')
edge(['G:large-branch-arithmetic'],'L:large-dimension-branch','S3.SS3.SSS0.Px1.p1.2','Source conditional integrality conclusion.','2T + 1 > d')
edge(['L:large-dimension-branch','G:large-branch-arithmetic'],'L:large-branch-conclusion','S3.SS3.SSS0.Px1.p1.2','Only the conditional easy branch dominates the source main RHS.','2T + 1 > d')
edge(['Z:positive-budget','L:large-branch-conclusion'],'L:remaining-range','S3.SS3.SSS0.Px1.p1.2','Source proof proceeds after excluding zero budget and closing the large-budget branch.','Complementary branch 2T + 1 ≤ d; subsequent proof excluded')
edges[-1]['logic']='proof case-split scope transition; not an unconditional mathematical implication'
edges[-1]['edge_kind']='proof-scope-control'
graph=dict(schema='source-author-phase1-v1',role='raw-source author only; not topology challenger, verifier, or mathematical prover',primary_source={k:idx[k] for k in ('primary_source','source_bytes','source_sha256')},phase='PHASE1_RAW_SOURCE_COGNITION_FROZEN',no_target_or_implementation_exposure=True,hypotheses_policy='Only H:ranges, H:fixed-budget, H:uniform-accuracy, and the source-wide definitions/standing model give source premises. SOURCE_GAP and STANDARD_BACKGROUND records are proof obligations/dependency edges, never additional theorem binders.',edge_semantics='Source-use topology only. No edge asserts a Lean dependency, compilation, theorem admission, necessity in every possible proof, or independent verification.',nodes=nodes,edges=edges,alternative_routes={'zero_query_root':'One source route is present. No OR proof alternative is supplied in the selected zero-query source.','main_theorem':'The easy conditional branch 2T + 1 > d and the residual branch 2T + 1 ≤ d are a case split, not an AND. The latter is outside this extraction; neither the full main theorem nor any fixed-spectrum/eigenbasis theorem is claimed closed.','invented_routes':[]},independent_topology_review='pending; source author cannot approve own graph')
save('source-graph.json',graph)
# Every substantive paragraph/display in every selected raw fragment receives one disposition.
assign={
'S2.p1.1':(['D:notational'],None),
'S2.p2.1':([], 'Orthogonal group, Haar components, determinant-conditioned μ_n,b are for the hidden-sign construction, unused by this elementary zero-query pair or the adjacent integer case.'),
'S2.SS0.SSS0.Px1.p1.1':(['D:class-context'],None),
'S2.Ex1':(['D:precision-class'],None),
'S2.SS0.SSS0.Px1.p1.2':(['D:gaussian-target'],None),
'S2.E1':([], 'Exact first-order response formula is retained in the raw context but no response is observed in the zero-query argument; the adjacent dimension arithmetic does not use it.'),
'S2.SS0.SSS0.Px1.p2.1':([], 'Equivalence among exact value-and-gradient, gradient-only and matrix-vector access is not used by the zero-query argument or adjacent dimension arithmetic.'),
'S2.SS0.SSS0.Px2.p1.1':(['D:algorithm'],None),
'S2.SS0.SSS0.Px3.p1.1':(['D:TV'],None),
'S2.Ex2':(['D:TV'],None),
'S2.SS0.SSS0.Px3.p1.2':(['D:TV'],None),
'S2.SS0.SSS0.Px4.p1.1':(['D:output-law'],None),
'S2.E2':(['D:query-complexity'],None),
'S2.SS0.SSS0.Px4.p1.2':(['D:accuracy-semantics'],None),
'S3.p1.1':(['H:ranges'],None),
'S3.Thmtheorem1.p1.1':(['H:ranges'],None),
'S3.E3':(['C:main-theorem'],None),
'S3.SS3.p1.1':(['H:fixed-budget','H:uniform-accuracy'],None),
'S3.SS3.SSS0.Px1.p1.1':(['Z:pair','Z:common-law','Z:event'],None),
'S3.Ex3':(['Z:event-separation','Z:integral-bound','Z:strict-separation','Z:epsilon-endpoint'],None),
'S3.SS3.SSS0.Px1.p1.2':(['B:TV-triangle','Z:contradiction','Z:positive-budget','L:large-dimension-branch','L:large-branch-conclusion','L:remaining-range'],None)
}
coverage=[]
for e in idx['elements']:
 if e['tag'] in ('p','table'):
  ns,why=assign[e['anchor']];r={**locus(e['anchor']),'disposition':'EXCLUDED' if why else 'NODE','nodes':ns}
  if why:r['reason']=why
  coverage.append(r)
formula_coverage=[]
for e in idx['elements']:
 if e['tag']=='math':
  owners=[c for c in coverage if c['start_byte']<=e['start_byte'] and e['end_byte_exclusive']<=c['end_byte_exclusive']]
  assert len(owners)==1,(e['anchor'],owners)
  o=owners[0];formula_coverage.append({**locus(e['anchor']),'alttext':e['alttext'],'substantive_owner':o['anchor'],'disposition':o['disposition'],'nodes':o['nodes'],**({'reason':o['reason']} if 'reason' in o else {})})
assert len(coverage)==21 and len(formula_coverage)==65
save('source-coverage.json',dict(schema='exhaustive-selected-raw-coverage-v1',scope='Full S2; S3 opening ranges and Theorem 3.1 as context; S3.SS3 initial algorithm premise; complete Zero-query cases paragraph block. Coverage is not for full S3 or the full paper.',raw_fragments=idx['fragments'],substantive_unit_count=len(coverage),node_units=sum(c['disposition']=='NODE' for c in coverage),excluded_units=sum(c['disposition']=='EXCLUDED' for c in coverage),units=coverage,inline_and_display_formula_coverage=formula_coverage,structural_exclusions=[{'region':'HTML section/div/span wrappers, table cells, headings, equation numbers, MathML rendering duplication and TeX annotations','disposition':'EXCLUDED','reason':'Structural/rendering matter. Complete bytes remain in raw snapshots; mathematical formulas are independently indexed through math alttext and substantive owners.'}],external_citations_in_selected_fragments=[],out_of_scope=[{'region':'S3.1, S3.2 and S3.3 after the Zero-query cases block','disposition':'EXCLUDED','reason':'The remaining hidden-sign prior construction and main theorem proof are outside the assigned elementary zero-query extraction.'},{'region':'Fixed-spectrum/disclosed-eigenbasis route and all existing graph/frontier/seal/review artifacts','disposition':'EXCLUDED','reason':'Not source dependencies of this extracted region, and no such artifacts were opened.'}],review_status='Authored exhaustive inventory only; independent raw-source topology/coverage review pending'))
gaps=[n for n in nodes if n['kind'] in ('SOURCE_GAP','AUTHOR_INVOKED_STANDARD_BACKGROUND')]
save('background-and-gap-ledger.json',dict(schema='source-background-omission-ledger-v1',interpretation='SOURCE_GAP means a mathematical bridge omitted in the selected raw passage. It does not assert source falsehood, add a source hypothesis, or establish a new Lean fact. All listed facts are source-route obligations, not independent proofs by this author.',entries=gaps,source_error_or_repair_claims=[],source_explicit_external_citations=[],implementation_alternatives=[],normalization_contract={'law':'N(0,A⁻¹), precision A','coordinate_variances':'1 for A₀; 1/κ for A₁','coordinate_standard_deviation':'1/√κ for A₁','density':'exp(−t²/2)/√(2π)','normalization':'Standard normal probability density; scalar normalization is an implicit background obligation, not an arbitrary unnormalized kernel.','event':'|x₁| ≤ 1/2','source_display':'TV ≥ 2∫_(1/2)^1 φ ≥ exp(−1/2)/√(2π) > 1/8 ≥ 2ε'}))
# Ancestor traces are graph-author bookkeeping, not an independent closure verdict.
def ancestors(root):
 found={root};todo=[root]
 while todo:
  c=todo.pop()
  for e in edges:
   if e['consumer']==c:
    for p in e['parents']:
     if p not in found:found.add(p);todo.append(p)
 return sorted(found)
roots=[]
for root in ['Z:strict-separation','Z:positive-budget','L:large-branch-conclusion']:
 trace=ancestors(root)
 roots.append({'root':root,'statement':byid[root]['statement'],'source_ancestor_ids':trace,'standard_or_omitted_bridge_leaves':[n for n in trace if byid[n]['kind'] in ('SOURCE_GAP','AUTHOR_INVOKED_STANDARD_BACKGROUND')],'source_reconstruction_status':'Author trace only; source standard bridges visible, no Lean or independent topology closure asserted','conditional_scope':byid[root].get('conditional','Unconditional within H:ranges, H:fixed-budget, and H:uniform-accuracy where applicable')})
save('root-closure-map.json',dict(schema='source-root-trace-v1',roots=roots,main_root={'id':'C:main-theorem','statement':byid['C:main-theorem']['statement'],'status':'UNCLOSED / contextual only','reason':'The selected paragraph supplies T ≥ 1 and closes the easy 2T + 1 > d branch only. The 2T + 1 ≤ d construction, comparisons, and numerical conclusion remain outside this source extraction.','case_split_logic':'easy conditional branch OR residual conditional branch, with exhaustive complementary integer inequalities; residual route not imported here.'},boundaries={'dimension_one':'d = 1 is included. A₁ is the 1×1 matrix [κ]; no trailing coordinates are required. The class imposes bounds I ≼ A ≼ κI, not the equalities λ_min(A)=1 and λ_max(A)=κ. A₁ therefore remains admissible when its actual one-dimensional spectral ratio is 1.','accuracy_endpoint':'≤ ε in the source accuracy condition; ε = 1/16 allowed; strict > 1/8 in the separation gives contradiction at the endpoint.','event_endpoint':'Source event is the closed coordinate slab, with ≤ 1/2.','query_budget':'T ∈ ℤ≥0 and caps every run/seed; no expected-cost statement follows from this extraction.','precision_covariance':'κ in A₁ is precision; covariance first entry is κ⁻¹.','graph_semantics':'No compiled dependency claims and no global graph reset/relabel.'}))
procedural=[ROOT/'AGENTS.md',ROOT/'docs/contributor-codex-contract.md',ROOT/'docs/theorem-publication-protocol.md',ROOT/'docs/proof-digestion-protocol.md',ROOT/'docs/evidence-routed-memory-protocol.md',ROOT/'.agents/skills/astis-source-dependency-audit/SKILL.md']
save('procedural-inputs.json',dict(files=[{'path':str(p),'bytes':len(p.read_bytes()),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in procedural],read_scope='Procedural instructions only; links and paths mentioned by these documents were not recursively opened. No normal SAU/API workflow was executed.'))
save('exposure-ledger.json',dict(role='SOURCE AUTHOR only',task_packet_exposure={'selected_anchor':'S3.SS3.SSS0.Px1.p1.1','source_pin':idx['source_sha256'],'reading_questions':'Parent named dimensions/endpoints, covariance-vs-precision, event, normal density and numerical bound, common output law, and deterministic cap as questions; no desired target/Lean signature was supplied.','parent_withheld_exact_target':True},actual_reads=[str(p) for p in procedural]+[idx['primary_source']]+['Own generated raw snapshots, index and derivatives'],discovery_commands=["rg --files docs -g '*contribut*' (returned only docs/contributor-codex-contract.md)",'No source-tree, graph, review, frontier or implementation inventory performed.'],incidental_context={'AGENTS_document':'Procedural AGENTS text names historical PBPS/SPHMC/Gaussian Cloud/midpoint, Gaussian Complexity, research/frontier/semantic/graph paths and old run names. Those names were visible in the required instructions; their referenced files were not opened.','source_lookahead':'A bounded raw-byte view through byte 180100 showed the heading Comparing the two priors and beginning of S3.SS3.SSS0.Px2, including n=2T+1, k=floor(d/n), 3≤n≤d, 2T<n, and references to Lemmas 3.2 and 3.4. No subsequent proof was extracted or used as a dependency of the zero-query argument. This is original source exposure, not a prior review.','parent_messages':'Parent task names semantic-neutral directory, raw source path and prohibited prior artifacts; no target-type, implementation, old verdict or old graph was received.','pretraining':'No guarantee is made that pretrained recognition or general mathematical prior knowledge is absent. Independence claim concerns actual inspected session inputs.'},prohibited_inputs_opened=[],network_calls=[],shared_truth_mutations=[],write_scope_deviation={'event':'An extraction command briefly redirected duplicate derivative output to /private/tmp/zeroquery-zsg-extraction-output.txt. It was immediately moved to the owned directory as extraction-output.txt; no shared repository truth was touched.','current_residual_outside_owned_directory':'none from this role'},freeze_boundary='After manifest/receipt creation, stop before target-type/Lean/code/old graph/old verdict exposure. Target comparison, topology challenge and final verification belong to distinct actors.'))
(OWN/'phase1-source-cognition.md').write_text(r'''# Phase 1 raw-source cognition freeze

This is a source author's reconstruction, not an implementation audit, proof, topology review, or verifier verdict. The exact target statements remain withheld. The original local HTML is primary; its exact bytes are duplicated as `raw-original.html`. `raw-fragment-index.json` supplies zero-based UTF-8 byte offsets and hashes; the five selected fragment files preserve exact raw HTML. The text files are explicitly derivative conveniences.

## Source conclusion and scope

The selected zero-query argument uses the Section 3 range: every integer dimension d ≥ 1, κ ≥ 4, and 0 < ε ≤ 1/16. An algorithm has a deterministic integer cap T and has output law ρ_A, averaged over all its seed, within TV distance ≤ ε of π_A for every A in the precision class. The source concludes **T ≥ 1**.

The source precision class is symmetric A with I_d ≼ A ≼ κI_d, and π_A = N(0,A⁻¹). The matrices are A₀ = I_d and A₁ = diag(κ,1,…,1). The zero-query algorithm has a common output law on these two inputs because its output can depend only on the input-independent seed when there are no responses. Borel dependence supplies an actual probability law. Uniform accuracy applies to both matrices.

For the event E = {|x₁| ≤ 1/2}, the source gives exactly

TV(π_A₀,π_A₁) ≥ 2∫_(1/2)^1 exp(−t²/2)/√(2π) dt ≥ exp(−1/2)/√(2π) > 1/8 ≥ 2ε.

It then invokes the triangle inequality to contradict the two accuracy bounds under the common output law. The strict > 1/8 comparison matters: the source allows ε = 1/16, and the accuracy condition is ≤ ε. The event uses ≤, not <.

The first-coordinate variances are 1 and 1/κ, so the second event probability integrates the standard normal density up to √κ/2. κ ≥ 4 places this endpoint at least at 1. The relevant event difference is π_A₁(E) − π_A₀(E) ≥ 0. The interval [1/2,1] has length 1/2; the displayed leading factor 2 cancels that length in the constant-density lower bound. These facts are omitted standard bridges of the source's displayed chain, not new public premises. The exact normalization is exp(−t²/2)/√(2π), not an arbitrary Gaussian kernel.

All natural dimensions d ≥ 1 are included. For d = 1, A₁ is simply [κ], and E is a set of the sole coordinate. No second coordinate, determinant-sign prior, or nontrivial orthogonal component is needed. The class has spectral inequalities, not exact prescribed smallest/largest eigenvalues. In particular, the one-dimensional matrix remains in the class even though its actual condition ratio is 1.

## Adjacent separate branch

The remainder of the same source paragraph says: if 2T + 1 > d, integrality gives T ≥ d/2, which proves the main theorem bound in that branch; henceforth assume 2T + 1 ≤ d. This is a separate conditional integer case. It is covered in this packet because its sentence shares the source paragraph block. It is not folded into the zero-query separation root.

The full main Theorem 3.1 has RHS (1/256) min{d, √κ log(1+d/(√κ ε))}. It is retained only as context and remains unclosed here. The easy branch dominates its RHS using min{d,…} ≤ d. The residual case is outside the selected extraction. No prior global graph, fixed-spectrum route, disclosed-eigenbasis route, frontier, seal, or verdict was opened, reset, or relabelled.

## Source topology and omissions

`source-graph.json` gives source-use edges with consumer locations. The zero-query proof has one displayed sufficient route; no source alternative proof is supplied. Its ingredients are the class/target definitions, input-independent Borel algorithm model, the two admissible matrices, Borel event, normalized Gaussian marginal/scaling calculation, integral lower bound, strict scalar numerical comparison, uniform accuracy, TV triangle inequality, and nonnegative-integer budget endpoint. These remain dependency edges. They are not additional source hypotheses.

`background-and-gap-ledger.json` distinguishes the explicitly author-invoked triangle inequality from omitted standard bridges. “SOURCE_GAP” here means an omitted mathematical bridge in the selected passage, not a claim that the source is false or needs repair. The source does not calculate the strict scalar numerical inequality or prove normal normalization/marginal facts in this passage. No independent proof of these leaves, no substitute route, and no source repair is supplied by this author.

`source-coverage.json` accounts for all 21 substantive paragraph/display units and all 65 math elements in the selected raw fragments. Haar/determinant-conditioned preliminaries, the exact positive-query response formula, and equivalence of positive-query oracle models are explicitly excluded from this extracted proof's dependencies. Mathematical context retained in a node is distinguished from the exact part used by an incoming source edge. There are no external citations in the selected fragments. Structural HTML and duplicated MathML/TeX renderings are excluded as presentation structure while their exact raw bytes remain preserved.

The source author's root traces are in `root-closure-map.json`. Their pending standard leaves are visible. This does not certify implementation dependencies, complete a Lean theorem, approve the author's own topology, or close the full main result. A distinct raw-source topology/coverage challenger and the root prover still own their respective next steps.

## Independence and freeze boundary

`exposure-ledger.json` lists all actual inputs, incidental procedural names, raw-source lookahead, and the inability to guarantee absence of pretrained recognition. No target signature, actual Lean/proof source, prior graph, review, or verdict was supplied or opened. No network call, normal SAU/API execution, or shared truth mutation occurred. One duplicate extraction output briefly used a task-specific temporary file and was moved into the owned directory; this procedural deviation is recorded.

All packet files are frozen at mode 0444 after the manifest and receipt are generated. The receipt binds the exact manifest, and the manifest binds every payload's exact bytes and digest. Stop here before any target/implementation/old-review exposure. This packet is an authored Phase 1 source cognition freeze only.
''')
print('authored',len(nodes),'source nodes;',len(edges),'source-use hyperedges;',len(coverage),'substantive source units;',len(formula_coverage),'math elements')
