from pathlib import Path
import json,re
p=Path(__file__).parent
nodes=[]
def add(i,anchor,meaning,kind='source-step'):
 nodes.append({'id':i,'raw_anchor':anchor,'disposition':'NODE','kind':kind,'meaning':meaning})
add('T-MATRIX','Tropp p7 §2.1','Finite square complex matrices, self-adjointness, algebraic eigenvalues, spectral norm; dimension fixed.','standing-definition')
add('T-PROB','Tropp p7 §2.2','Probability law and source standing regularity; random relations may be almost sure.','standing-convention')
add('T-CALC','Tropp p7 §2.3 / (2.1)','Spectral functional calculus and spectral mapping.','definition')
add('T-EXP','Tropp p8 §2.4','Spectral/power-series matrix exponential; positive definiteness; trace exponential.','definition')
add('T-MGF','Tropp p9 §3.1 / (3.1)','Matrix mgf/cgf definitions and warning that expectations need not exist at all parameters. Formal moment expansions are context.','definition')
add('T-SCALE','Tropp p9 Proposition 3.1 proof first equality','Positive homogeneity of algebraic λ_max for positive parameter.')
add('T-EVENT','Tropp p9 Proposition 3.1 proof second equality','Scalar exponential order converts spectral-tail event.')
add('T-MARKOV','Tropp p9 Proposition 3.1 proof third relation','Scalar Markov on nonnegative exp(λ_max(ηY)) with positive threshold.','standard-result')
add('T-TRACE','Tropp p10 Proposition 3.1 proof first display','Spectral mapping plus λ_max(P)≤tr(P) for positive-definite P.')
add('T-FIXED','Tropp p10 Proposition 3.1 proof second display','For each η>0, probability ≤ exp(-ηt) E tr exp(ηY).','source-intermediate')
add('T-INF','Tropp pp9–10 Proposition 3.1 statement and final sentence','All real t; take infimum over positive η.','source-theorem')
paragraphs={
1:('C2-SETUP','r,n,t_i,γ_i,B and independent Gaussian row law.'),
2:('C2-PLAN','Uniform quadratic-form strategy through two Gram matrices.'),
3:('C2-RANGE','Chebyshev polynomial triangular invertible basis change gives range(B)=K_q.'),
4:('C2-COSSUM','Finite cosine grid sum by telescoping sines and nonzero sine denominator.'),
5:('C2-GRID','Product-to-sum and frequency checks give Σt_it_iᵀ=dI_r.'),
6:('C2-GRAMMEAN','Gaussian second moments and row/Kronecker formula give E BᵀB=I.'),
7:('C2-WEIGHTMEAN','High-frequency bounds and product-to-sum yield weighted grid cancellation and E BᵀD_nB=0.'),
8:('C2-TNORM','||t_i||²≤1+2q≤2r.'),
9:('C2-UNIFORMPLAN','Explain why operator-norm deviations control every coefficient vector.'),
10:('C2-TRUNCATE','R_i,L, radial exponential moment, Markov radial tail and union bound P(T)≥.999.'),
11:('C2-TAILBIAS','Radial tail integration yields E[R_i 1_{R_i>L}]≤(L+3)/(1000d).'),
12:('C2-TRUNCATEDMEAN','Literal rowwise Y_i; radial aI expectation, common a and bias; sums aI and weighted zero.'),
13:('C2-CENTERBOUND','Z_i=Y_i-EY_i; bounds on Y_i, EY_i, Z_i and deterministic cosine-weighted Z_i.'),
14:('C2-VARIANCE','Gaussian fourth moments; outer-product square; PSD indicator drop; centering variance identity; weighted variance bound.'),
15:('C2-BERNSTEINUSE','Both independent centered self-adjoint sequences; two-sided bounded Bernstein with D=r²,R_*,v_* for t>0.'),
16:('C2-LEVEL','z,Δ; source scalar expansion, .002 per family, union gives simultaneous .996.'),
17:('C2-TRANSFER','On T original/truncated equality; unweighted bias (1-a)I and weighted zero; intersection gives .995.'),
18:('C2-SIMPLIFY','2r≤d and absolute logs absorb Δ+(1-a) into τ with absolute C.'),
19:('C2-LEMMA44','Common matrix event, range parametrization, τ≤1/2 and all c simultaneously give Lemma4.4 with probability≥.99.')}
for n,(i,m) in paragraphs.items():add(i,f'Gaussian A3.SS2.p{n}',m)
add('C2-FACT5','Gaussian A3.Thmtheorem5','Fact C.5, all three main identities and all three supplementary deterministic identities.','source-theorem')
add('C2-FACT6','Gaussian A3.Thmtheorem6','Fact C.6, simultaneous two Gram deviations ≤τ with probability≥.995 for large absolute C.','source-theorem')
add('E-BERNSTEIN','Gaussian A3.SS2.p15 / A3.Ex121','Uncited standard external two-sided bounded matrix Bernstein theorem; not proved inside C.2.','external-theorem')
add('E-SIGN','Standard expansion of operator-norm use at Gaussian A3.SS2.p15','Two signs for each actual family; no inter-family or inter-sign independence required.','standard-expansion')
add('E-REGULAR','Standard finite-dimensional side-condition expansion for C2-CENTERBOUND','Bounded signed weighted finite sums imply finite integrable scalar trace exponential for fixed parameter.','standard-expansion')
add('E-MGFCONTROL','External bounded matrix Bernstein proof not expanded in C.2','Independent-sum trace-mgf estimate and scalar optimization still required beyond Proposition3.1.','external-proof-frontier')

eq_ranges=[(85,85,'C2-SETUP'),(86,87,'C2-FACT5'),(88,89,'C2-COSSUM'),(90,93,'C2-GRID'),(94,95,'C2-GRAMMEAN'),(96,101,'C2-WEIGHTMEAN'),(102,102,'C2-TNORM'),(103,103,'C2-FACT6'),(104,105,'C2-TRUNCATE'),(106,106,'C2-TAILBIAS'),(107,110,'C2-TRUNCATEDMEAN'),(111,112,'C2-CENTERBOUND'),(113,120,'C2-VARIANCE'),(121,121,'C2-BERNSTEINUSE'),(122,124,'C2-LEVEL'),(125,126,'C2-TRANSFER'),(127,128,'C2-SIMPLIFY'),(129,132,'C2-LEMMA44')]
def equation_owner(k):
 for lo,hi,owner in eq_ranges:
  if lo<=k<=hi:return owner
 raise ValueError(k)
raw=json.loads((p/'C2_raw_regions.json').read_text())
raw_inventory=[]
for r in raw:
 i=r['id'];owner=None
 m=re.match(r'A3\.SS2\.p(\d+)(?:\.|$)',i)
 if m:owner=paragraphs[int(m[1])][0]
 m=re.match(r'A3\.Ex(\d+)',i)
 if m:owner=equation_owner(int(m[1]))
 if i.startswith('A3.Thmtheorem5'):owner='C2-FACT5'
 if i.startswith('A3.Thmtheorem6'):owner='C2-FACT6'
 groups={'A3.EGx5':'C2-COSSUM','A3.EGx6':'C2-GRID','A3.EGx7':'C2-GRAMMEAN','A3.EGx8':'C2-WEIGHTMEAN','A3.EGx9':'C2-WEIGHTMEAN','A3.EGx10':'C2-TAILBIAS','A3.EGx11':'C2-VARIANCE','A3.EGx12':'C2-SIMPLIFY','A3.EGx13':'C2-LEMMA44'}
 if i in groups:owner=groups[i]
 if owner:raw_inventory.append({'raw_id':i,'disposition':'NODE','owner_node':owner,'component_of_owner':True})
 else:raw_inventory.append({'raw_id':i,'disposition':'EXCLUDED','reason':'Structural proof wrapper; every substantive paragraph and formula descendant is inventoried separately.'})
math=json.loads((p/'A3_SS2_math.json').read_text())
formula_inventory=[]
for r in math:
 i=r['id'];owner=None
 m=re.match(r'A3\.Ex(\d+)',i)
 if m:owner=equation_owner(int(m[1]))
 m=re.match(r'A3\.SS2\.p(\d+)\.',i)
 if m:owner=paragraphs[int(m[1])][0]
 if i.startswith('A3.Thmtheorem5'):owner='C2-FACT5'
 if i.startswith('A3.Thmtheorem6'):owner='C2-FACT6'
 if not owner:raise ValueError(i)
 formula_inventory.append({'raw_math_id':i,'disposition':'NODE','owner_node':owner,'source_formula':r.get('alttext'),'source_display_attribute':r.get('display')})

excluded=[
('Tropp p7 §1.4 roadmap','Roadmap/navigation, not a proof input.'),
('Tropp p7 §2 introduction bibliography','General background books, not a theorem-specific citation for Proposition3.1.'),
('Tropp p7 (2.2) transfer rule','Not used in Proposition3.1 proof; spectral mapping (2.1) is retained.'),
('Tropp p8 (2.3),(2.4)','Matrix exponential Taylor/cosh inequalities; unused in the Laplace probability proof.'),
('Tropp p8 trace exponential convexity, monotonicity (2.5), Petz citation','Separate matrix analysis facts for later mgf estimates; unused in Proposition3.1.'),
('Tropp p8 Golden–Thompson (2.6), Bhatia citation and false three-matrix extension warning','Later mgf route context, not Proposition3.1 input; warning against invalid multiplication is retained in prose.'),
('Tropp p8 §2.5 logarithm (2.7)–(2.9), Bhatia references','Not used in Proposition3.1; later external Bernstein proof may require logarithmic machinery.'),
('Tropp p8 §2.6 dilation (2.10)–(2.12), Paulsen reference','Rectangular extension; C.2 actual matrices are square symmetric.'),
('Tropp p9 §2.7 expectation order (2.13), Jensen/Kadison (2.14), cited references','Not a necessary matrix-order step in Proposition3.1; C.2 directly states its centering variance identity. These are standard context, not a new proposition premise.'),
('Tropp p9 §3.1 formal power series and higher cumulants','Explanatory mgf context; all-moments introduction is not silently promoted to Proposition3.1.'),
('Tropp p10 §3.3 scalar factorization (3.2) and two-matrix comparison (3.3)','Different mgf analysis discussion; no full matrix product factorization is claimed.'),
('Tropp p10 §3.4 Lieb Theorem3.2, Corollary3.3 and cited alternative proof literature','Beyond narrow Laplace probability bridge; full independent-sum mgf theorem is an explicit external frontier.'),
('Tropp raw extra pp1–6 introduction and later pp11–13 context exposed by text windows','Original source context only; not candidate context and no exhaustive proof coverage outside assigned pp7–10 is claimed.'),
('Gaussian §4.1 hard-family potential/target and random orthogonal rotation','Original grid and κ-domain definitions retained; potential/target/rotation not needed in the C.2 matrix concentration proof.'),
('Gaussian §4.2 Lemma4.3 and adaptive algorithm discussion','Krylov definition retained; deferred-rotation proof in C.1 is outside C.2 and not needed to prove its standalone uniform Gaussian-span bound.'),
('Gaussian §4.2 Lemma4.5, Lemma4.6 and target/admissibility discussion','Neighboring contextual statements read but outside complete C.2 proof scope.')]

edges=[]
def edge(parents,consumer,site,kind='source-explicit',note=None):
 d={'parents':parents,'consumer':consumer,'consumer_use_site':site,'edge_semantics':'AND','provenance_kind':kind}
 if note:d['note']=note
 edges.append(d)
edge(['T-MATRIX','T-PROB','T-SCALE','T-EVENT','T-MARKOV','T-TRACE'],'T-FIXED','Tropp Prop3.1 pp9–10')
edge(['T-FIXED'],'T-INF','Tropp p10 final proof sentence')
edge(['T-CALC','T-EXP'],'T-TRACE','Tropp p10 first proof display')
edge(['C2-SETUP'],'C2-RANGE','Gaussian p3')
edge(['C2-SETUP'],'C2-COSSUM','Gaussian p4')
edge(['C2-COSSUM'],'C2-GRID','Gaussian p5')
edge(['C2-SETUP','C2-GRID'],'C2-GRAMMEAN','Gaussian p6')
edge(['C2-SETUP','C2-COSSUM'],'C2-WEIGHTMEAN','Gaussian p7; frequency bounds discharge nonzero frequencies')
edge(['C2-SETUP'],'C2-TNORM','Gaussian p8')
edge(['C2-RANGE','C2-GRID','C2-GRAMMEAN','C2-WEIGHTMEAN','C2-TNORM'],'C2-FACT5','Gaussian FactC.5 proof p3–8')
edge(['C2-TRUNCATE'],'C2-TAILBIAS','Gaussian p11')
edge(['C2-SETUP','C2-FACT5','C2-TAILBIAS'],'C2-TRUNCATEDMEAN','Gaussian p12; common a, unweighted bias and weighted cancellation')
edge(['C2-FACT5','C2-TRUNCATEDMEAN'],'C2-CENTERBOUND','Gaussian p13')
edge(['C2-FACT5','C2-TRUNCATEDMEAN'],'C2-VARIANCE','Gaussian p14; Gaussian fourth moments explicit here')
edge(['C2-SETUP','C2-CENTERBOUND','C2-VARIANCE','E-BERNSTEIN'],'C2-BERNSTEINUSE','Gaussian p15 / Ex121; independence, centering, symmetry, dimension and bound premises discharged by preceding construction')
edge(['C2-BERNSTEINUSE'],'C2-LEVEL','Gaussian p16; two separate family tail bounds then union')
edge(['C2-TRUNCATE','C2-TRUNCATEDMEAN','C2-LEVEL'],'C2-TRANSFER','Gaussian p17; on-T identities and failure budget')
edge(['C2-TAILBIAS','C2-CENTERBOUND','C2-VARIANCE','C2-LEVEL'],'C2-SIMPLIFY','Gaussian p18; 2q+1<d and r=q+1 give deterministic parameter bounds')
edge(['C2-TRANSFER','C2-SIMPLIFY'],'C2-FACT6','Gaussian FactC.6 conclusion')
edge(['C2-FACT5','C2-FACT6'],'C2-LEMMA44','Gaussian p19; additional source premise τ≤1/2 used here')
edge(['C2-CENTERBOUND'],'E-REGULAR','Instantiation of the probability bridge for four signed C.2 sums','standard-expansion','This is a source-implied analytic obligation; it is not a new Gaussian theorem premise.')
edge(['T-FIXED','E-REGULAR'],'E-SIGN','Two-sided operator-norm use at C2 p15','standard-expansion','Apply to σΣ_i w_iZ_i for each h and σ. This records the probability component only.')
edge(['E-SIGN','E-MGFCONTROL'],'E-BERNSTEIN','C2 p15 external theorem frontier','standard-expansion','This is an explanatory external-theorem decomposition, not a claim that C.2 explicitly proves Bernstein or that Prop3.1 alone proves it.')
obj={'phase':'phase1-source-only','reviewer':'/root/laplace_fresh_source_8d2a','candidate_inputs_seen':False,'self_approval_claim':False,'scope':'Complete Gaussian Appendix C.2; Tropp author pp7–10 focus Proposition3.1 and standing conventions.','nodes':nodes,'edges':edges,'raw_C2_region_dispositions':raw_inventory,'raw_C2_formula_dispositions':formula_inventory,'excluded_context':[{'anchor':a,'disposition':'EXCLUDED','reason':r} for a,r in excluded],'source_gaps':[{'id':'C2-EXTERNAL-BERNSTEIN-EXPANSION','type':'external-theorem-proof-not-expanded','anchor':'A3.SS2.p15 / A3.Ex121','detail':'The standard bounded two-sided Bernstein invocation has no citation link in C.2 and its independent-sum mgf/optimization proof is outside C.2. This is a visible external dependency, not evidence of an additional source assumption or a false statement.'},{'id':'T-REGULARITY-TYPING','type':'standing-convention-needs-explicit-meaning','anchor':'Tropp §2.2, §3.1','detail':'Source assumes sufficient regularity but allows mgf nonexistence for some parameters. A fully typed finite-expectation interface must retain these senses; actual bounded C.2 sums discharge finite integrability internally.'}],'alternative_routes':[],'alternative_route_note':'No competing sufficient proof route is introduced in phase1. All edges marked standard-expansion are explanatory decomposition of an external theorem, not an alternative formalization route.'}
(p/'source_coverage_graph.json').write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'nodes':len(nodes),'edges':len(edges),'raw_regions':len(raw_inventory),'formulas':len(formula_inventory),'all_equations':list(range(85,133))},indent=2))
