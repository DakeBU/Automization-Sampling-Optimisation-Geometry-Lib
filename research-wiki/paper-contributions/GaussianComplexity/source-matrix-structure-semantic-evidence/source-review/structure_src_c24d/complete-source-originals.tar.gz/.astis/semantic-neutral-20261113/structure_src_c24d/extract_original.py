from html.parser import HTMLParser
from pathlib import Path
import json, hashlib
class Node:
 def __init__(self,tag='',attrs=(),parent=None): self.tag=tag; self.attrs=dict(attrs); self.parent=parent; self.children=[]
 def render(self):
  if self.tag=='math': return '$'+self.attrs.get('alttext','MISSING-ALT')+'$'
  if self.tag in {'script','style'}: return ''
  return ''.join(x if isinstance(x,str) else x.render() for x in self.children)
 def walk(self):
  yield self
  for c in self.children:
   if isinstance(c,Node): yield from c.walk()
class Parser(HTMLParser):
 def __init__(self): super().__init__(convert_charrefs=True); self.root=Node(); self.current=self.root
 def handle_starttag(self,t,a):
  n=Node(t,a,self.current); self.current.children.append(n)
  if t not in {'area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr'}: self.current=n
 def handle_startendtag(self,t,a): self.current.children.append(Node(t,a,self.current))
 def handle_endtag(self,t):
  n=self.current
  while n.parent is not None and n.tag!=t: n=n.parent
  if n.parent is not None: self.current=n.parent
 def handle_data(self,s): self.current.children.append(s)
out=Path(__file__).resolve().parent
p=Parser(); p.feed((out/'originals/.astis/huanjian-resume-20261103/2610.20492v1.html').read_text()); nodes={n.attrs['id']:n for n in p.root.walk() if 'id' in n.attrs}
for key in ['A3.SS2','S4.Thmtheorem4','S4.SS1']:
 n=nodes[key]; lines=[]
 for c in n.walk():
  if c.tag in {'p','table','h3','h4','h5','h6'}:
   text=' '.join(c.render().split()); lines.append(f"[{c.attrs.get('id',c.tag)}] {text}")
 text='\n\n'.join(lines)+'\n'; dest=out/'raw'/f'original-{key}.math-alttext.txt'; dest.write_text(text); print(f'===== {key} =====\n{text}')
