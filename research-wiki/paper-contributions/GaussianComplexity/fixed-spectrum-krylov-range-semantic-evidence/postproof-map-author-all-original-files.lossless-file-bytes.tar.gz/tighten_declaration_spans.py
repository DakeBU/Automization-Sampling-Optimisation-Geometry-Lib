from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
path=ROOT/'canonical-declaration-inventory.json';raw=path.read_bytes();data=json.loads(raw)
(ROOT/'canonical-declaration-inventory.before-span-tightening.json').write_bytes(raw)
archive=ROOT/'canonical-span-tightening-originals';archive.mkdir(exist_ok=True)
ends={'isUnit_iff_ne_zero':265,'TrivialStar.star_trivial':120,'Matrix.diagonal':51,'dotProduct':73,'Matrix.transpose':173}
changes=[]
for rec in data['records']:
    if rec['name'] not in ends:continue
    p=Path(rec['span']['file']);b=p.read_bytes();s=b.decode();a=rec['span']['character_span_0based_halfopen'][0];z=sum(len(x) for x in s.splitlines(keepends=True)[:ends[rec['name']]])
    old=(ROOT/rec['snapshot_path']).read_bytes();(archive/Path(rec['snapshot_path']).name).write_bytes(old)
    span=s[a:z].encode();before=rec['span'].copy();rec['span'].update(character_span_0based_halfopen=[a,z],utf8_byte_span_0based_halfopen=[len(s[:a].encode()),len(s[:z].encode())],lf_lines_1based_inclusive=[s.count('\n',0,a)+1,s.count('\n',0,z-1)+1],raw_span_sha256=sha(span),terminal_LF_included=span.endswith(b'\n'))
    (ROOT/rec['snapshot_path']).write_bytes(span);changes.append({'name':rec['name'],'before':before,'after':rec['span'],'reason':'Initial lexical extractor retained a following alias/export or trailing unrelated comment. The authoritative span is tightened to the exact declaration. Original raw fragment and first inventory are preserved; no log is normalized.'})
path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
for group in sorted({x['group'] for x in data['records']}):
    content=[]
    for rec in data['records']:
        if rec['group']==group:content.extend([rec['name']+' | '+str(rec['span']['lf_lines_1based_inclusive']),(ROOT/rec['snapshot_path']).read_text()])
    (ROOT/('canonical-readable-'+group+'.txt')).write_text('\n'.join(content))
(ROOT/'canonical-span-tightening-record.json').write_text(json.dumps({'changes':changes,'status':'mapping-span extraction corrected; not a mathematical route failure'},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'tightened_exact_declarations':[x['name'] for x in changes],'original_extractor_fragments_preserved':True,'reason':'remove following alias/export or trailing unrelated comment from exact declaration extent'},indent=2))
