from html.parser import HTMLParser
from pathlib import Path
import json, hashlib
class N:
 def __init__(self,t,a,line,parent=None):self.tag=t;self.attrs=dict(a);self.line=line;self.parent=parent;self.children=[]
 def text(self):
  if self.tag=='math':return '$'+self.attrs.get('alttext','')+'$'
  return ''.join(c if isinstance(c,str) else c.text() for c in self.children)
 def descend(self):
  yield self
  for c in self.children:
   if isinstance(c,N):yield from c.descend()
class Parser(HTMLParser):
 def __init__(self):super().__init__();self.top=N('ROOT',[],1);self.stack=[self.top]
 def handle_starttag(self,t,a):
  n=N(t,a,self.getpos()[0],self.stack[-1]);self.stack[-1].children.append(n)
  if t not in {'meta','link','img','input','br','hr','source','area','base','embed','param','track','wbr'}:self.stack.append(n)
 def handle_startendtag(self,t,a):self.stack[-1].children.append(N(t,a,self.getpos()[0],self.stack[-1]))
 def handle_endtag(self,t):
  for j in range(len(self.stack)-1,0,-1):
   if self.stack[j].tag==t:self.stack=self.stack[:j];break
 def handle_data(self,d):self.stack[-1].children.append(d)
paper=Path('.astis/huanjian-resume-20261103/2610.20492v1.html')
p=Parser();p.feed(paper.read_text());ids={n.attrs['id']:n for n in p.top.descend() if 'id'in n.attrs}
a=Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-determinant-semantic-evidence/source-only-review/phase1')
g=json.loads((a/'source_graph_486201.proof_graph.json').read_text());c=json.loads((a/'source_graph_486201.coverage.json').read_text())
b=Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-determinant-semantic-evidence/topology-challenge/phase1/postfreeze-topology-challenge');b.mkdir(exist_ok=True)
records={e['locator']:e for e in c['regions_and_math_and_text_nodes']}
summary=[];missing=[]
for root in c['scope_roots']:
 n=ids[root]
 for n2 in n.descend():
  if n2.tag not in {'p','table','math','cite','li'}:continue
  nodeid=n2.attrs.get('id')
  if nodeid and nodeid not in records:missing.append({'root':root,'id':nodeid,'tag':n2.tag})
  if n2.tag in {'p','table'}:
   r=records.get(nodeid,{})
   summary.append({'root':root,'id':nodeid,'raw_line':n2.line,'tag':n2.tag,'raw_normalized_text':' '.join(n2.text().split()),'extractor_disposition':r.get('disposition'),'extractor_node_ids':r.get('node_ids'),'extractor_reason':r.get('reason')})
all_scoped_ids={n.attrs.get('id') for root in c['scope_roots'] for n in ids[root].descend()}
anchors=[]
for n in g['nodes']:
 for anchor in n['source_anchors']:
  if anchor not in all_scoped_ids:anchors.append({'node':n['id'],'anchor':anchor,'raw_id_exists':anchor in ids})
incoming={n['id']:[] for n in g['nodes']}
for e in g['edges']:incoming[e['consumer']]+=e['prerequisites']
def ancestors(n,seen=None):
 seen=set() if seen is None else seen
 for x in incoming.get(n,[]):
  if x not in seen:seen.add(x);ancestors(x,seen)
 return sorted(seen)
result={'method':'Independent standard-library HTMLParser from pinned whole raw bytes; did not use extractor generator/private rationale/structural verdict. Semantic findings are separate from these accounting checks.','raw_sha256':hashlib.sha256(paper.read_bytes()).hexdigest(),'raw_p_table_math_id_coverage_missing':missing,'graph_anchors_outside_scoped_roots':anchors,'paragraph_display_inventory':summary,'root_backward_ancestry':{k:{'root':v,'ancestors':ancestors(v)} for k,v in g['roots'].items()}}
(b/'independent-raw-coverage-accounting.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print('raw p/table/math IDs missing',missing)
print('graph anchors outside scopes',anchors)
print('paragraph/display regions independently reread',len(summary))
for k,v in result['root_backward_ancestry'].items():print(k,len(v['ancestors']),[x.split(':')[-1] for x in v['ancestors']])
