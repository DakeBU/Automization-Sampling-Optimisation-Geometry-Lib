from pathlib import Path
from html.parser import HTMLParser
import hashlib,json
ROOT=Path(__file__).resolve().parent;REPO=ROOT.parents[2];P1=ROOT.with_name('kr_sg_31f8c2');P2=ROOT.with_name('kr_sg_31f8c2_phase2')
sha=lambda b:hashlib.sha256(b).hexdigest()
dump=lambda n,x:(ROOT/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
source=REPO/'.astis/huanjian-resume-20261103/2610.20492v1.html';b=source.read_bytes();s=b.decode()
assert len(b)==951991 and sha(b)=='6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
pins=json.loads((P1/'source-pins.json').read_bytes());byid={p['id']:p for p in pins['elements']}
class R(HTMLParser):
    def __init__(self):super().__init__(convert_charrefs=True);self.out=[];self.math=0
    def handle_starttag(self,t,a):
        a=dict(a)
        if t=='math':
            if not self.math:self.out.append('$'+a.get('alttext','[missing alttext]')+'$')
            self.math+=1
        elif not self.math and t in ['p','div','table']:self.out.append('\n')
    def handle_endtag(self,t):
        if t=='math':self.math-=1
    def handle_data(self,x):
        if not self.math:self.out.append(x)
def readtext(x):
    r=R();r.feed(x);return '\n'.join(y.strip() for y in ''.join(r.out).splitlines() if y.strip())
outdir=ROOT/'source-spans';outdir.mkdir(exist_ok=True);records=[]
for ident in ['S4.E11','S4.Ex10','A3.SS2.p1','A3.SS2.p3','A3.SS2.p19.2','A3.EGx13']:
    p=byid[ident];ca,cz=p['char_span_0based_halfopen'];a,z=p['utf8_span_0based_halfopen'];raw=b[a:z]
    assert raw==s[ca:cz].encode() and sha(raw)==p['sha256_raw_utf8']
    assert p['lf_lines_1based_inclusive']==[s.count('\n',0,ca)+1,s.count('\n',0,cz-1)+1]
    (outdir/(ident+'.html')).write_bytes(raw);text=readtext(raw.decode());(outdir/(ident+'.readable.txt')).write_text(text+'\n')
    records.append(p);print(ident,json.dumps(p,ensure_ascii=False));print(text)
assert byid['A3.SS2.p3']['sha256_raw_utf8']=='70a50b8444b84fbd1c589f08cfc7406de60df80ef880fbbaf0be8043a31b0d77'
assert byid['A3.SS2.p19.2']['sha256_raw_utf8']=='88c2408fcc6109c1d89566ee9a192425acd47e771f9410f7e270bd46fbd3f044'
dump('source-use-pins.json',{'source_path':str(source),'raw_source_sha256':sha(b),'raw_source_bytes':len(b),'offsets':'Original Unicode-character and UTF8-byte zero-based half-open spans, LF1-based inclusive; terminal LF belongs to preceding line. Readable views are derived only.','records':records})
path=REPO/'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-krylov-range-semantic-evidence/selective-preproof-types-and-definitions.json';raw=path.read_bytes();assert sha(raw)=='471d8f4351d80f33d478049a0a2d8716689b2140c043aa324d8132f9b3fb79cb';assert raw==(P2/'exact-selective-packet.json').read_bytes();packet=json.loads(raw)
(ROOT/'exact-selective-packet.json').write_bytes(raw)
seal_path=REPO/packet['sealed_statement_file_for_hash_and_signature_fields_only'];rawseal=seal_path.read_bytes();assert sha(rawseal)=='f47e23a601d1a8e0ff4760224676313e0f1999877a97156841a65c01847e5d82';seal=json.loads(rawseal)
selected={}
for key,item in zip(['producer','actual_private_consumer'],packet['lean']):
    assert sha(item['signature'].encode())==item['signature_sha256']
    selected[key]={field:seal[key][field] for field in ['name','planned_file','signature','signature_sha256']}
    for field in ['name','planned_file','signature','signature_sha256']:assert selected[key][field]==item[field]
dump('sealed-root-pins.json',{'core_seal_path':str(seal_path),'core_seal_sha256':sha(rawseal),'selective_packet_path':str(path),'selective_packet_sha256':sha(raw),'authorized_fields_only':selected,'other_seal_fields_not_exposed':True})
definition=packet['minimal_definitions'][0];raw=(REPO/definition['file']).read_bytes();assert sha(raw)==definition['wholefile_raw_sha256'];literal=raw[definition['byte_start_inclusive']:definition['byte_end_exclusive']];assert literal.decode()==definition['literal']
dump('existential-image-definition-pin.json',definition)
print('SET.RANGE EXACT DEFINITION:',literal.decode())
print('TYPE PINS:',json.dumps({key:value['signature_sha256'] for key,value in selected.items()}))
