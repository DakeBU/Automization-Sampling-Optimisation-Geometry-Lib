#!/opt/anaconda3/bin/python
import copy,hashlib,json,pathlib,stat,tarfile
BASE=pathlib.Path(__file__).resolve().parent;ROLE=BASE.parent
ROOT=pathlib.Path('/Users/zhouhuanjian/ASTIS-GC')
def sha(data):return hashlib.sha256(data).hexdigest()
def canonical(data):return json.dumps(data,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()
phase3=ROLE/'phase3'
known={'mathematical_judgment.json':'9664e70ced3c4c5be22866341ba565f70522d0f1d799dada13554ec1a3be2589',
       'mathematical_source_module_exposition_judgment.md':'edec5fedd710bb4d29fe9ca19b80c162294033a5c1b7f98a9a1c32a691674f7d',
       'manifest.json':'3ce8cdccd41e6e93d361466e444efbde32e7de8bcac420e79ee322bc8435dbac',
       'freeze_receipt.json':'a68a91e85dabcea2c6db85ac9494705cc1edb2afe1fb83d63a8f2efc2a19e6a2'}
(BASE/'original-phase3').mkdir(exist_ok=True)
original_records=[]
for name,expected in known.items():
    data=(phase3/name).read_bytes();assert sha(data)==expected
    target=BASE/'original-phase3'/name;target.write_bytes(data)
    original_records.append({'original':str((phase3/name).relative_to(ROOT)),
                             'snapshot':str(target.relative_to(BASE)),'bytes':len(data),'sha256':sha(data)})
run_path=ROLE/'phase3_freeze_execution.json';run_bytes=run_path.read_bytes();run_hash=sha(run_bytes)
run=json.loads(run_bytes);assert run['returncode']==0
assert run['observed_freeze_result']['mathematical_judgment_sha256']==known['mathematical_judgment.json']
assert run['observed_freeze_result']['receipt_sha256']==known['freeze_receipt.json']
(BASE/'original-phase3/phase3_freeze_execution.json').write_bytes(run_bytes)
original_records.append({'original':str(run_path.relative_to(ROOT)),'snapshot':'original-phase3/phase3_freeze_execution.json',
                         'bytes':len(run_bytes),'sha256':run_hash,'purpose':'actual source-review execution record'})
judgment=json.loads((phase3/'mathematical_judgment.json').read_text())
audit=json.loads((BASE/'inputs/huanjian-fixed-spectrum-cosine-gram.json').read_text())
packet=json.loads((phase3/'inputs/fresh-source-reviewer-packet.json').read_text())
assert audit['state']=='blind-reconstructed' and audit['source_review']['state']=='pending'
assert audit['source']['original_text']==packet['source']['original_text']
assert audit['source']['source_snapshot_sha256']==judgment['pinned_raw_source_sha256']
assert audit['lean']['statement']==packet['lean']['statement']
assert audit['reconstruction']['text']==packet['blind_reconstruction']['text']
assert audit['publication_context']==packet['candidate_publication_context']
assert audit['publication_binding_sha256']==judgment['publication_binding_sha256_supplied']
review_evidence=(
    'Independent raw-first Phase1 and selective Phase2 were frozen before complete candidate code review; '
    'the unchanged Phase3 mathematical_judgment.json SHA256 '+known['mathematical_judgment.json']+
    ' and detailed narrative SHA256 '+known['mathematical_source_module_exposition_judgment.md']+
    ' accept only the selected deterministic Gram/weighted cancellation/row-square assertions and the private actual-Gaussian entrywise L1/two-mean application at candidate '+judgment['candidate_commit']+'. '
    'The genuine source-review execution artifact is '+str(run_path.relative_to(ROOT))+' with raw SHA256 '+run_hash+
    '; it records actual freeze execution exit0 and binds the original Phase3 manifest/receipt. '
    'Native 0a91de evidence was first read only after this Phase3 freeze, in separate Phase4; it supports bounded native PASS and retains reader HOLD for all six step copy/download/exact-source neighbors. '
    'No source correction or mathematical repair; range(B)=Krylov, C6/full FactC5/full Lemma4.4/main bounds, browser/global/purification/Goal acceptance remain open. '
    'SourceV/ledger has not been called by this phase.'
)
slot_choices=['domains','assumptions','scopes']
delta_evidence=[
    'Frozen Phase3 narrative sections1/3; phase1 source S4.SS1.p1/A3.Ex85 and full actual P/T literal definitions; actual canonical map_pi_eq_stdGaussian and Euclidean coordinate normalization.',
    'Frozen Phase3 narrative section3 and T59-82,109-151: actual Gaussian L2, Holder product L1, finite-sum integrability/integral interchange; no moment or integrability caller premise.',
    'Frozen Phase3 narrative sections2/4 and P49-50/G full proof; actual canonical sine-sum telescoping; T71-77 supplies Matrix.PosSemidef.one to canonical covariance. Correctly excludes the row bound and C6 from the mathematical parents of the two means.'
]
deltas=[{'slot':slot,'severity':'informational','description':old['description'],'evidence':ev}
        for slot,old,ev in zip(slot_choices,judgment['deltas'],delta_evidence)]
overlay={'state':'accepted','semantic_slots':copy.deepcopy(judgment['semantic_slots']),
         'deltas':deltas,'verdict':judgment['verdict'],
         'source_review':{'state':'accepted','reviewer':judgment['reviewer'],
                          'independent_from_formalizer':True,'independent_from_decoder':True,
                          'evidence':review_evidence,'review_run_sha256':run_hash,
                          'reviewer_packet_sha256':judgment['reviewer_packet_sha256'],
                          'run_artifact':str(run_path.relative_to(ROOT))},
         'repairs':[]}
slots={'objects','domains','quantifiers','assumptions','conclusion','scopes','constant_dependencies'}
assert set(overlay['semantic_slots'])==slots
for slot,row in overlay['semantic_slots'].items():
    assert row==judgment['semantic_slots'][slot]
    assert row['relation'] in ['same','equivalent','explicit-elaboration']
    assert all(isinstance(row[key],str) and row[key] for key in ['original','reconstructed','evidence'])
for row in deltas:
    assert set(row)=={'slot','severity','description','evidence'}
    assert row['slot'] in slots and row['severity']=='informational'
assert len(deltas)==3 and overlay['repairs']==[]
proposed=copy.deepcopy(audit);proposed.update(copy.deepcopy(overlay))
protected=[key for key in audit if key not in overlay]
assert all(audit[key]==proposed[key] for key in protected)
assert (ROOT/'research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-cosine-gram.json').read_bytes()==(BASE/'inputs/huanjian-fixed-spectrum-cosine-gram.json').read_bytes()
(BASE/'canonical-audit-attachment-overlay.json').write_text(json.dumps(overlay,ensure_ascii=False,indent=2)+'\n')
(BASE/'proposed-canonical-audit.json').write_text(json.dumps(proposed,ensure_ascii=False,indent=2)+'\n')
contract={'canonical_audit':'research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-cosine-gram.json',
          'baseline_audit_raw_sha256':sha((BASE/'inputs/huanjian-fixed-spectrum-cosine-gram.json').read_bytes()),
          'allowed_top_level_replacement_fields':list(overlay),'protected_unchanged_top_level_fields':protected,
          'protected_field_canonical_sha256':{key:sha(canonical(audit[key])) for key in protected},
          'overlay_sha256':sha((BASE/'canonical-audit-attachment-overlay.json').read_bytes()),
          'proposed_audit_sha256':sha((BASE/'proposed-canonical-audit.json').read_bytes()),
          'source_review_run_sha256':run_hash,'source_review_run_artifact':str(run_path.relative_to(ROOT)),
          'original_phase3_payload_copies':original_records,
          'semantic_slots_are_exact_frozen_phase3_values':True,
          'three_delta_descriptions_are_exact_frozen_phase3_values':True,
          'canonical_audit_not_modified':True,'SourceV_not_called':True}
(BASE/'attachment_contract.json').write_text(json.dumps(contract,indent=2)+'\n')
print(json.dumps(contract,indent=2))
print('OVERLAY',json.dumps(overlay,ensure_ascii=False,indent=2))
