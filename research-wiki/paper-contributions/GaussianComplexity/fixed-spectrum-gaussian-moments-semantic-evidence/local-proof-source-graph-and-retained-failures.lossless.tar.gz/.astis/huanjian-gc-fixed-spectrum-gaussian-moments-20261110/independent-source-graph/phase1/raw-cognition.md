# Independent raw-first cognition — frozen before statement interfaces

Extractor role: source-topology extraction only. No implementation Lean, prior packet source graph/review, source cognition, frontier/ledger, API result, or root proof design has been read. Parent supplied the source scope and a prospective mean/alias boundary, but no declaration signature. The parent reports its own earlier constructor exposure; that is not this extractor's exposure. The first file-discovery command enumerated names of old evidence folders; no content was opened. This is not total blindness to the task description: the source selection and intended bounded result were supplied by the parent.

Pinned input: `2610.20492v1.html`, SHA256 `6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915`. Read instructions: exact local AGENTS.md, proof-digestion-protocol.md, evidence-routed-memory-protocol.md. No external paper was fetched. Local raw HTML is the source, including its math `alttext`; the stdlib HTMLParser derivative keeps all raw snapshots available. Parser first failed because `HTMLParser.offset` shadowed the method; renaming to `source_offset` fixed extraction. This was an extraction implementation failure, not mathematical evidence.

## Exact read boundary

Full core regions: Section 4.1 `S4.SS1` raw lines 1082–1127, Lemma 4.5 `S4.Thmtheorem5` lines 1261–1293, Appendix C.3 `A3.SS3` lines 3837–4134. Supplementary standing content: S2.p1.1 (Euclidean norm, identity, Loewner order); S2.p2.1 (orthogonal/Haar definitions, excluded here); S2.SS0.SSS0.Px1 (centered Gaussian target/precision/oracle definitions); preceding S4 paragraphs plus theorem 4.1 introductory parameter paragraph; bib.bib3, the [22] bibliography entry. A read of the source parser's full document creates an internal DOM but only these regions/queries were emitted to the extractor. No other paper proof was inspected.

The raw inventory contains every paragraph/display/header in the three complete core regions. All attached MathML formulas and link occurrences are retained, even when the paragraph is excluded. Phase 2 will project each inline item explicitly and will not rewrite these raw-first dispositions.

## Source mathematical objects and binder boundary

For d≥2, κ≥2, source Eq. (11) defines θ_i=(i−1/2)π/d, λ_i=(κ+1)/2+(κ−1)cos θ_i/2, and Λ=diag(λ_1,…,λ_d), with i=1,…,d. Zero-based finite indexing would therefore use θ_(i+1)=(i+1/2)π/d. The source also forms A=OΛOᵀ using a Haar rotation; π_A=N(0,A⁻¹). The diagonal U-law in Lemma 4.5 is N(0,Λ⁻¹), not the Haar-random law and not an arbitrary measure carrying postulated moments. No orthogonal averaging, algorithm, or random matrix is needed for its diagonal moments.

Lemma 4.5 defines ρ=(√κ−1)/(√κ+1), integer 1≤n<d, D_n=diag(cos(nθ_i)), M=E‖U‖², μ_n=E[UᵀD_nU]. The closed formulas for M and μ_n are the full lemma/Fact C.8 conclusions; they are not the same result as Ex140's finite grid sums. The extra premise d−n≥√κ belongs only to the later normalized bias conclusion. It must not leak into a mean/covariance or alias precursor statement. Coordinate first/second moments do not intrinsically require n, and no coordinate law result needs the stronger algorithmic condition κ≤d^(1−δ) or an ε/query bound.

From Eq. (11), −1≤cos θ≤1 and κ−1≥0 imply 1≤λ_i≤κ. This is an omitted elementary positivity bridge needed to interpret Λ⁻¹ as a positive covariance. Appendix p8.1 later explicitly writes λ_i≥1. A theorem may use the positivity as an internal dependency; it is not a new source-facing premise.

## Author's route, ordered by actual consumer use sites

1. Fact C.7 (A3.Ex133) expands 1/λ(θ) = (1/√κ)[1+2 Σ_(j≥1)(−ρ)^j cos(jθ)]. Its proof first uses 0<ρ<1 in the geometric complex-exponential identity (A3.SS3.p2.1 / A3.EGx14); the scalar identities A3.Ex136 convert that fraction to inverse spectrum. A3.Ex137 bounds the absolute cosine series by ρ/(1−ρ), uniformly in θ. These are algebraic/trigonometric/series source dependencies, not Gaussian moment facts.
2. A3.Ex139 and A3.SS3.p3.2 prove Σ_(i=1)^d cos(kθ_i) = d(−1)^a for k=2ad, a∈ℤ, and zero otherwise. For k not divisible by 2d the sine-sum denominator is nonzero; sin(kπ)=0 gives zero. For k=2ad each cosine equals (−1)^a. The k=0 case is in the alias branch with a=0; it must not be divided by sin 0. For 1≤n<d the nonalias case k=n gives the zero unweighted mode needed at A3.SS3.p6.1.
3. A3.SS3.p4.1 states, without a local proof, E U_i²=1/λ_i. A3.Ex140 immediately consumes that fact to write M=Σ_i 1/λ_i and μ_n=Σ_i cos(nθ_i)/λ_i. Its omitted analytic obligations are the actual centered Gaussian realization, coordinate and quadratic integrability, and finite linearity of expectation. These are SOURCE_GAP bridges, not additional hypotheses to assume.
4. A3.SS3.p4.2 consumes the absolute convergence assertion of Fact C.7 to move the finite grid sum past the scalar infinite cosine series. This is finite-sum/series interchange. It is a different operation from the Bochner/probability integral/finite-sum interchange in Ex140. The source has already removed the expectation before it reaches this paragraph; there is no source need to exchange an expectation with an infinite series here.
5. A3.SS3.p6.1 additionally uses Σ_i cos(nθ_i)=0 and 2cos(nθ_i)cos(jθ_i)=cos((j−n)θ_i)+cos((j+n)θ_i). With Ex140 and Fact C.7, these give A3.Ex144:
   μ_n=(1/√κ) Σ_(j≥1)(−ρ)^j [Σ_i cos((j−n)θ_i)+Σ_i cos((j+n)θ_i)].
   Thus the actual Gaussian mean reaches the alias precursor through the expectation-to-grid bridge, plus independently established algebraic series normalization. No exact resummed closed formula is needed to reach this series.
6. A3.SS3.p5.1 / A3.EGx15 classify support and resum M. A3.SS3.p6.2 / A3.EGx16 classify the three disjoint weighted alias supports, use parity, and resum μ_n. Those are later mathematical steps, OPEN for this bounded packet. A3.SS3.p7.1 then uses Fact C.8 for the full lemma's means.
7. A3.SS3.p8.1 explicitly says that diagonal Λ makes coordinates independent and each U_i centered Gaussian with variance 1/λ_i, followed by fourth moments and variances. Only the centered marginal/variance semantic assertion is corroboration for p4.1 here. Independence, fourth moments, and A3.EGx17's variance bounds remain OPEN. A3.SS3.p9–p11's bias ratio, logarithmic integral, exponent bounds, and d−n≥√κ conditional estimate all remain OPEN.

## SOURCE_GAP bridge inventory, source-derived and implementation-free

SG-POS: hard-spectrum bounds ⇒ λ_i>0 ⇒ positive definite Λ, inverse diagonal entries λ_i⁻¹. Consumers: the U-law at S4.Thmtheorem5.p1.1 and the inverse coordinate variances at A3.SS3.p4.1. The source prints a λ_i≥1 check later in p8.1 but omits a dedicated construction proof here.

SG-LAW: a literal actual centered Gaussian law on ℝ^d with covariance Λ⁻¹ must be exhibited/identified, not represented only by an integrability-and-moment predicate. This is a translation/realization obligation for U~N(0,Λ⁻¹). The source does not specify a Lean measure constructor or density. An explicit independent product of centered scalar Gaussians or an affine image of a standard centered Gaussian are alternative realization routes, not simultaneous prerequisites. This extraction does not choose or search an API.

SG-L2: actual Gaussian finite second moments supply coordinate integrability, square integrability, coordinate-product integrability, norm-square integrability, and weighted diagonal quadratic integrability (finite d; fixed real weights). A finite-dimensional norm/quadratic is a finite sum of coordinate squares. Gaussian integrability is a proof ingredient and must not be a public hypothesis of a source anchor.

SG-MEAN-COV: the centered law supplies E U_i=0 and E[U_i U_j]=(Λ⁻¹)_ij=δ_ij/λ_i. To deduce E U_i², either specialize the actual Gaussian second-moment theorem directly, OR use Var(U_i)=E U_i²−(E U_i)² with centeredness and integrability. The two sufficient routes are OR alternatives, not one false AND. Independence is not needed for this first/second-moment bridge. Exact cross moments corroborate inverse covariance but Ex140 itself only needs the diagonal second moments.

SG-FINITE-EXPECT: pointwise ‖U‖²=Σ_i U_i² and UᵀD_nU=Σ_i cos(nθ_i)U_i², termwise integrability, then finite linearity of expectation and scalar multiplication yield Ex140. The literal source's i=1,…,d grid and any zero-based coordinate carrier must be reconciled explicitly.

SG-SERIES-BOOKKEEPING: after Ex140, the finite grid's constant coefficients and absolute convergence permit each finite weight to pass through the scalar series and finite i-sum/series commutation. The |cos|≤1 bounds and 0<ρ<1 give summability. Product-to-sum and zero constant grid mode yield Ex144. These are algebraic infinite-series operations after Gaussian integration, not Gaussian integrability/normalization.

These are named omitted bridges with a proposed dependency direction. None is claimed Lean-proved, reviewed, admitted, or source theorem-complete by this extractor.

## External and standing inputs

[22] is OpenAI (2026), “Subpolynomial query complexity for well-conditioned log-concave sampling”, cited at S4.SS1.p1.1 for construction similarity and Remark 4.2 for κ=2 comparison. The external preprint was not opened or used as a theorem. The moment/alias source proof in C.3 is explicit and has no external citation use site. Do not invent an external proof dependency from the contextual citation.

Euclidean norm and precision/covariance convention come from Section 2 and the literal N(0,Λ⁻¹) lemma premise. No random rotation, query/Krylov representation, adaptive law, TV threshold, or full lower-bound theorem is a prerequisite for the selected deterministic-spectrum mean/alias bridge. Their complete laws/theorems remain OPEN rather than being claimed absent from the paper.

## Delimited outcome and remaining review

The candidate source topology is (hard spectrum and actual centered Gaussian moment facts) ⇒ Ex140; (Ex140 AND inverse-spectrum expansion/convergence AND finite-series exchange AND zero grid mode AND product-to-sum) ⇒ Ex144. Closed finite sums, variances, normalized bias, Krylov/adaptive laws, and the global lower bound remain OPEN. This source graph is only an extractor proposal. A distinct reviewer must inspect raw source and nodes/edges without this private rationale or implementation Lean before SOURCE_TOPOLOGY_REVIEWED can be claimed. No implementation/API/build/browser or shared repository files were touched.
