from runner import *
import runpy
Q=OUT/'reader-conditional';candidate=json.loads((Q/'candidate.json').read_text())
assert candidate['patch_sha256']=='2442d520f5888f665b8bd76777334d36a3e3346888c4c9cb309ae891280a2bff'
assert candidate['changed_site_files']==['assets/proof-readers.css']
assert candidate['original_css_sha256']=='4509e56205aa4bb94c3fa32c7b2b0bd98a9b44a71c23e09f18d5affe038512ad'
assert not candidate['global_css_changed']
assert all(sha(OUT/p)==h for p,h in candidate['frozen_input_files'].items())
assert sha(OUT/'reader/original-browser-freeze.json')==candidate['original_browser_freeze_sha256']
assert sha(OUT/'math-freeze-manifest.json')==candidate['native_math_freeze_sha256']
assert json.loads((OUT/'reader/original-verdict.json').read_text())['original_reader_judgment'].startswith('FAIL')
sys.argv=[str(OUT/'check_browser.py'),'conditional']
runpy.run_path(str(OUT/'check_browser.py'),run_name='__main__')
