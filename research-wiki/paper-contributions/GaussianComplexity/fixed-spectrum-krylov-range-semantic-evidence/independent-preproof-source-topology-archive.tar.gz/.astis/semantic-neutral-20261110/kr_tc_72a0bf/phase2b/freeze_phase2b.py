from pathlib import Path
import os,stat,json,hashlib,datetime
ROOT=Path('/Users/zhouhuanjian/ASTIS-GC/.astis/semantic-neutral-20261110/kr_tc_72a0bf');PAYLOAD=ROOT/'phase2b'
sha=lambda b:hashlib.sha256(b).hexdigest()
def earlier():
 result=[]
 for stage,h in [('phase1','05c869d5248141c2cab0604796c0b18f5695d11c9fd272265ec6b65cd1f9475a'),('phase2a','ca0f7cb34ebb3296c9bbd2db344b2edb23fb8fab0adca4f0f59ef3da384365e7')]:
  b=(ROOT/f'{stage}.manifest.json').read_bytes();assert sha(b)==h;m=json.loads(b)
  assert all(sha((ROOT/stage/x['path']).read_bytes())==x['sha256'] and stat.S_IMODE((ROOT/stage/x['path']).stat().st_mode)==0o444 for x in m['files'])
  assert stat.S_IMODE((ROOT/stage).stat().st_mode)==0o555
  result.append({'stage':stage,'manifest_sha256':h,'all_hashes_and_modes_unchanged':True})
 return result
before=earlier()
files=sorted(p for p in PAYLOAD.rglob('*') if p.is_file());assert files
assert not any(p.is_symlink() for p in PAYLOAD.rglob('*'))
m={'stage':'phase2b-independent-mathematical-SG-challenge-before-process-control-exposure','files':[{'path':str(p.relative_to(PAYLOAD)),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in files]}
mp=ROOT/'phase2b.manifest.json';mp.write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n')
for p in files:os.chmod(p,0o444)
dirs=sorted([PAYLOAD]+[p for p in PAYLOAD.rglob('*') if p.is_dir()],key=lambda p:len(p.parts),reverse=True)
for p in dirs:os.chmod(p,0o555)
os.chmod(mp,0o444)
assert all(stat.S_IMODE(p.stat().st_mode)==0o444 for p in files)
assert all(stat.S_IMODE(p.stat().st_mode)==0o555 for p in dirs)
assert all(sha((PAYLOAD/x['path']).read_bytes())==x['sha256'] for x in m['files'])
after=earlier();assert before==after
receipt={'stage':'phase2b','action':'actually hash/chmod/recheck all payload files and directories; recheck both earlier frozen payloads before and after','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'payload':str(PAYLOAD),'payload_files':len(files),'payload_directories':len(dirs),'manifest':str(mp),'manifest_sha256':sha(mp.read_bytes()),'files_all_mode_0444':True,'directories_all_mode_0555':True,'manifest_mode_0444':True,'manifest_recheck_passed':True,'earlier_phases_unchanged':after,'mathematical_judgment':'two bounded repairs required; no source statement or target signature refuted','root_process_control_narrative_exposed':False,'candidate_Lean_or_API_read':False,'actual_execution_not_plan':True}
rp=ROOT/'phase2b.freeze.receipt.json';rp.write_text(json.dumps(receipt,indent=2)+'\n');os.chmod(rp,0o444)
print(json.dumps(receipt,indent=2))
