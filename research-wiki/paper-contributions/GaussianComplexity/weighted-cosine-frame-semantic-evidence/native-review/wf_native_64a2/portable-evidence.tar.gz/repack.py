import hashlib,json,tarfile
from run import ROOT
sha=lambda b:hashlib.sha256(b).hexdigest()
m=json.loads((ROOT/'portable-manifest.json').read_text())
selected={ROOT/f['path'] for f in m['files']}
selected.update((ROOT/'runtime').rglob('*.py'))
selected.add(ROOT/'repack.py')
selected.add(ROOT/'reader/proofs/source-huanjian-gaussian-weighted-cosine-frame.html')
selected.add(ROOT/'reader/data/lesson-sources/Tests/GaussianComplexityFixedSpectrumWeightedFrameBound.lean.html')
m['files']=[{'path':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in sorted(selected)]
m['portable_member_count']=len(m['files']);m['total_uncompressed_bytes']=sum(f['bytes'] for f in m['files'])
(ROOT/'portable-manifest.json').write_text(json.dumps(m,indent=2)+'\n')
with tarfile.open(ROOT/'portable-evidence.tar.gz','w:gz') as tar:
    for p in sorted(selected):tar.add(p,arcname=str(p.relative_to(ROOT)),recursive=False)
    tar.add(ROOT/'portable-manifest.json',arcname='portable-manifest.json',recursive=False)
with tarfile.open(ROOT/'portable-evidence.tar.gz') as tar:
    members=tar.getmembers();assert len(members)==len(m['files'])+1
    for f in m['files']:
        assert not f['path'].startswith('/') and '..' not in f['path'].split('/')
        b=tar.extractfile(f['path']).read();assert len(b)==f['bytes'] and sha(b)==f['sha256']
seal={'report_sha256':sha((ROOT/'report.json').read_bytes()),'portable_manifest_sha256':sha((ROOT/'portable-manifest.json').read_bytes()),'archive_sha256':sha((ROOT/'portable-evidence.tar.gz').read_bytes()),'archive_bytes':(ROOT/'portable-evidence.tar.gz').stat().st_size,'archive_members_verified':len(members),'compiled_candidate':m['compiled_candidate'],'metadata_byte_transfer_head':m['later_metadata_head'],'all_large_native_body_exports_retained_local_and_hashed':True}
(ROOT/'evidence-seal.json').write_text(json.dumps(seal,indent=2)+'\n');print(json.dumps(seal,indent=2))
