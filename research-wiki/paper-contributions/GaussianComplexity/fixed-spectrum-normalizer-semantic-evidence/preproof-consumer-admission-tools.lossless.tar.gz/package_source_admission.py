from pathlib import Path
import gzip, hashlib, json, subprocess, tarfile, shutil

sha = lambda raw: hashlib.sha256(raw).hexdigest()
base = Path('research-wiki/paper-contributions/GaussianComplexity')
evidence = base / 'fixed-spectrum-normalizer-semantic-evidence'
private = Path('.astis/huanjian-fixed-spectrum-normalizer-20261108')
seal_path = base / 'fixed-spectrum-normalizer-statement-seal.json'
seal = json.loads(seal_path.read_bytes())
admission = json.loads((evidence / 'producer-source-admission.json').read_bytes())
assert admission['state'] == 'ISOLATED_EXACT_PRODUCER_SOURCE_GATE_ADMITTED_ONLY_CONSUMER_INTERFACE_NEXT'
assert not admission['overall_implementation_admission']
assert not Path(seal['production_file']).exists()
assert not Path(seal['real_consumer']['file']).exists()
checks = evidence / 'actual-checks'
checks.mkdir(exist_ok=True)
for receipt in sorted(Path('.astis/huanjian-resume-20261103').glob('*-fixed-spectrum-normalizer-*.receipt.json')):
    data = json.loads(receipt.read_bytes())
    raw = Path(data['log']).read_bytes()
    assert sha(raw) == data['log_sha256']
    target = checks / receipt.name
    if target.exists():
        assert target.read_bytes() == receipt.read_bytes()
    else:
        shutil.copy2(receipt, target)
    target = checks / (Path(data['log']).name + '.gz')
    if target.exists():
        assert gzip.decompress(target.read_bytes()) == raw
    else:
        target.write_bytes(gzip.compress(raw, mtime=0))
    assert gzip.decompress(target.read_bytes()) == raw

files = sorted(p for p in private.rglob('*') if p.is_file())
archive = evidence / 'preproof-source-admission-tools.lossless.tar.gz'
assert not archive.exists()
with tarfile.open(archive, 'w:gz') as bundle:
    for path in files:
        bundle.add(path, arcname=str(path.relative_to(private)), recursive=False)
with tarfile.open(archive, 'r:gz') as bundle:
    for path in files:
        assert bundle.extractfile(str(path.relative_to(private))).read() == path.read_bytes()
manifest = evidence / 'preproof-source-admission-tools.manifest.json'
assert not manifest.exists()
manifest.write_text(json.dumps({
    'archive': str(archive), 'sha256': sha(archive.read_bytes()),
    'all_members_roundtrip_verified': True,
    'target_Lean_implementation_exists': False,
    'files': [{'path': str(p), 'member': str(p.relative_to(private)),
               'sha256': sha(p.read_bytes()), 'bytes': p.stat().st_size} for p in files]
}, indent=2) + '\n')

paths = sorted(p for p in evidence.rglob('*') if p.is_file())
pack = evidence / 'preproof-frozen-raw-packaging'
pack.mkdir(exist_ok=False)
safe, rows = [], []
for path in paths:
    raw = path.read_bytes()
    ignored = subprocess.run(['git', 'check-ignore', '-q', '--', str(path)]).returncode == 0
    binary = path.suffix in ['.gz', '.zip', '.png'] or b'\0' in raw
    bad = not binary and (any(line.endswith((b' ', b'\t', b'\r')) for line in raw.split(b'\n'))
                          or raw.endswith(b'\n\n'))
    if ignored or bad:
        target = pack / (str(len(rows)).zfill(3) + '-' + path.name + '.gz')
        target.write_bytes(gzip.compress(raw, mtime=0))
        assert gzip.decompress(target.read_bytes()) == raw
        rows.append({'original_path': str(path), 'raw_sha256': sha(raw),
                     'raw_bytes': len(raw), 'gzip_path': str(target),
                     'gzip_sha256': sha(target.read_bytes()),
                     'reason': {'ignored': ignored, 'frozen_whitespace_or_blank_EOF': bad},
                     'original_retained_unmodified': True})
        safe.append(target)
    else:
        safe.append(path)
manifest = pack / 'manifest.json'
manifest.write_text(json.dumps({
    'rule': 'Only frozen evidence under owned new packet folder is packaged losslessly; originals never normalized/deleted. Restore exact original paths before replaying source freezes. Mutable ledger/frontier/README staged directly.',
    'files': rows
}, indent=2) + '\n')
safe.append(manifest)
mutable = [Path(p) for p in [
    'runs/substantive_advances.jsonl',
    'research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-normalizer.json',
    'research-wiki/paper-contributions/GaussianComplexity/README.md']]
safe += mutable + [seal_path]
subprocess.run(['git', 'add', '--', *map(str, safe)], check=True)
result = subprocess.run(['git', 'diff', '--cached', '--check'], stdout=subprocess.PIPE,
                        stderr=subprocess.STDOUT)
print(result.stdout.decode())
assert result.returncode == 0
for path in mutable:
    assert subprocess.check_output(['git', 'show', ':' + str(path)]) == path.read_bytes()
assert subprocess.check_output(['git', 'rev-parse', 'HEAD']).decode().strip() == '000d64ead1bcf94a61ece6da48d87f548656b61f'
print(json.dumps({'owned_paths_staged': len(safe), 'frozen_raw_losslessly_packaged': len(rows),
                  'all3mutable_paths_exactly_staged': True,
                  'preproof_archive_sha256': sha(archive.read_bytes()),
                  'producer_Test_implementation_exists': False,
                  'overall_implementation_admission': False}))
