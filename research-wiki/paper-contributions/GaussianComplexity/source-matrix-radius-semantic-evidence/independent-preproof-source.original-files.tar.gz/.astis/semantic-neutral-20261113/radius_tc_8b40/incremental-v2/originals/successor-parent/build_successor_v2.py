"""Source-only TC-F1/F2 graph successor. Never reads Lean/API/proof bodies."""
from pathlib import Path
from copy import deepcopy
import hashlib,json,datetime
R=Path(__file__).parent
O=R/'successor-v2'
O.mkdir(exist_ok=False)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(name,j):
 with (O/name).open('x') as f:json.dump(j,f,ensure_ascii=False,indent=2);f.write('\n')
W=Path('/Users/zhouhuanjian/ASTIS-GC')
challenge=W/'.astis/semantic-neutral-20261113/radius_tc_8b40/independent-source-type-scope-topology-challenge-v1.json'
assert sha(challenge)=='decb5e606905f9c51e20cad710170505841e63e533721877f3abed07506722a0'
(O/'originals').mkdir()
(O/'originals/TC-challenge-v1.json').write_bytes(challenge.read_bytes())
oldseal=json.loads((R/'packet-seal-v1.json').read_text())
assert sha(R/'output-manifest-v1.json')==oldseal['output_manifest']['sha256']
old_manifest=json.loads((R/'output-manifest-v1.json').read_text())
assert all(sha(R/x['path'])==x['sha256'] for x in old_manifest['files'])
assert sha(R/'packet-seal-v1.json')=='ce59761f511cc2c9399fda45c04907e4cc87d33484fc90e30a7b9a63cbd57be0'
raw=(R/'originals/2610.20492v1.html').read_bytes();S=raw.decode()
idx=json.loads((R/'source-element-index.json').read_text())
newloc={}
def loc(k):
 if k in newloc:return deepcopy(newloc[k])
 u=deepcopy(idx[k]);a,b=u['char'];v=S[a:b].encode()
 p=O/'originals/source'/f'{k}.html';p.parent.mkdir(exist_ok=True)
 p.write_bytes(v)
 u.update(raw_utf8_byte=[len(S[:a].encode()),len(S[:b].encode())],LF_line=[S.count('\n',0,a)+1,S.count('\n',0,b)+1],
          sha256=hashlib.sha256(v).hexdigest(),original_path='successor-v2/'+str(p.relative_to(O)))
 newloc[k]=u
 return deepcopy(u)
g1=json.loads((R/'source-proof-graph-freeze-v1.json').read_text());g=deepcopy(g1)
c1=json.loads((R/'raw-source-coverage-freeze-v1.json').read_text());c=deepcopy(c1)
p1=json.loads((R/'internal-port-obligations-v1.json').read_text());p=deepcopy(p1)
N=g['nodes'];E=g['edges']
def addnode(id,kind,statement,anchors,note='',**kw):
 n=dict(id=id,kind=kind,statement=statement,anchors=[loc(k) for k in anchors],note=note);n.update(kw);N.append(n)
def addedge(a,b,site,usage,kind='internal-side-condition'):
 E.append(dict(prerequisite=a,consumer=b,consumer_use_site=loc(site),usage=usage,
               edge_kind=kind,semantics='source dependency overlay; not compiler-backed',
               status='source-only discharge/reference documented; independent successor challenge pending; formal applicability unproved'))

# TC-F1: side conditions are derived from source binders/definitions, never new binders.
addnode('int.dimension.positive','internal-side-condition-discharge',
 'd is a natural with d>=2, hence (d:Real)>0 and d!=0.',
 ['S4.Thmtheorem4.p1.m2','S4.Thmtheorem4.p1.m3','A3.SS2.p18.m1','A3.SS2.p18.m2'],
 'Source-only arithmetic: q>=0 gives 1<=2q+1; hq gives 1<d, so natural d>=2. Real coercion preserves strict positivity. p18 explicitly records d>=2. No hd binder.',
 derivation=dict(inputs=['q:Nat','hq:2q+1<d'],steps=['0<=q','1<=2q+1','1<d','2<=d','0<(d:Real)']))
addnode('int.rank.positive','internal-side-condition-discharge',
 'm=q+1 is a natural >=1; source r=(m:Real)>=1>0, so r!=0.',
 ['S4.Thmtheorem4.p1.m2','A3.SS2.p1.1'],
 'Successor positivity is internal even at q=0. No hr binder.',
 derivation=dict(inputs=['q:Nat','r=(q+1:Nat) cast to Real'],steps=['1<=q+1','1<=r','0<r','r!=0']))
addnode('int.index.nonempty','internal-side-condition-discharge',
 'Fin(q+1) and its square pair-index carrier are nonempty, including q=0.',
 ['A3.SS2.p1.1','A3.Ex85','A3.Ex111'],
 'The natural successor q+1 has coordinate0. Thus the identity block I_r has nonempty carrier; this supplies the side condition for identity-block norm1 in the mean-norm equality. No caller Nonempty instance/premise.',
 derivation=dict(inputs=['q+1>=1'],witness='coordinate0 of Fin(q+1); pair(0,0) for the r^2 matrix index'))
addnode('int.logargument.positive','internal-side-condition-discharge',
 '1000*(d:Real)>=2000>1; therefore log(1000*(d:Real))>0.',
 ['A3.SS2.p10.1','S4.Thmtheorem4.p1.m3'],
 'Uses d>=2 and the standard real-log positivity for arguments>1. This is a paper arithmetic discharge; corresponding library applicability is open and was not searched.',
 derivation=dict(inputs=['d>=2'],steps=['1000*(d:Real)>=2000','1<1000*(d:Real)','0<log(1000*(d:Real))']))
addnode('int.cutoff.positive','internal-side-condition-discharge',
 'L=2*r+3*log(1000*d)>0, hence L>=0.',
 ['A3.SS2.p10.1','A3.Ex111'],
 'Derive from r>=1 and positive logarithm; no hL binder or premise from a target estimate.',
 derivation=dict(inputs=['r>=1','log(1000*d)>0','literal L'],steps=['0<2*r','0<3*log(1000*d)','0<L','0<=L']))
addnode('int.normsquares.nonnegative','internal-side-condition-discharge',
 'R_i=||gamma_i||^2>=0 and ||t_i||^2>=0 for every i and every outcome.',
 ['A3.SS2.p10.1','A3.Ex111'],
 'Standard squared-norm nonnegativity; pointwise, no event/probability condition.')
addnode('int.scalars.nonnegative','internal-side-condition-discharge',
 '(d:Real)^-1>0, r^-1>0, C_Y=2*r*L/d>=0, C_mean=2*r/d>=0 and R_*=2*r*(L+1)/d>=0.',
 ['A3.Ex108','A3.Ex111','A3.Ex112'],
 'Discharged internally from positive d,r,L. |d^-1|=d^-1 and the normalized radial division by r use these conditions. No scalar/norm certificate binder.',
 derivation=dict(inputs=['d>0','r>0','L>=0'],steps=['0<d^-1','0<r^-1','0<=2*r*L/d','0<=2*r/d','0<=2*r*(L+1)/d']))

# TC-F1: guarded cutoff cases are jointly required for an all-outcome statement.
addnode('case.Y.kept','conditional-internal-step',
 'For arbitrary i,omega under R_i(omega)<=L, literal Y is d^-1 times the outer-product tensor, and its source norm expression is <=2*r*L/d.',
 ['A3.Ex107','A3.Ex111'],
 'Case premise is discharged by the selected branch of the closed-cutoff definition; it is not a public or standing assumption.',
 condition='R_i(omega)<=L',discharge_steps=[
 'The closed-cutoff if branch supplies Y=d^-1*(gamma gamma^T tensor t t^T).',
 'The rank-one/tensor operator-norm identity gives R_i*||t_i||^2/d; positive d removes absolute values on d^-1.',
 'R_i>=0 and ||t_i||^2<=2*r permit the feature-bound multiplication.',
 'R_i<=L, r>=0 and d>0 permit the cutoff-bound multiplication, yielding<=2*r*L/d.'],
 formal_status='OPEN_INTERNAL_PROOF_AND_LIBRARY_APPLICABILITY; source-only branch discharge recorded')
addnode('case.Y.dropped','conditional-internal-step',
 'For arbitrary i,omega under not(R_i(omega)<=L), literal Y=0 and ||Y||=0<=2*r*L/d.',
 ['A3.Ex107','A3.Ex111'],
 'The source indicator is zero off the closed cutoff. The off-cutoff upper bound requires C_Y>=0; it is supplied by int.scalars.nonnegative, not assumed.',
 condition='not(R_i(omega)<=L), equivalently L<R_i(omega)',
 discharge_steps=['The else branch gives literal Y=0.','The norm of zero is0.','d>0,r>=0,L>=0 give0<=2*r*L/d.'],
 formal_status='OPEN_INTERNAL_PROOF_APPLICABILITY; source-only branch discharge recorded')
g['conditional_case_routes']=[dict(id='cases.literal.Y.norm',target='src.Y.norm',
    variable_scope='for every original i and omega',case_partition=['R_i(omega)<=L','not(R_i(omega)<=L)'],
    guarded_obligations=['case.Y.kept','case.Y.dropped'],
    combination='Exhaustive case split: both guarded implications establish the universal target. This is not a pair of independent sufficient OR proof routes.',
    logical_form='forall i omega, ((R_i<=L -> bound(i,omega)) AND (not(R_i<=L) -> bound(i,omega))) plus excluded-middle cutoff partition implies forall i omega,bound(i,omega)',
    no_public_case_premise=True)]

# TC-F2: actual mean object is distinct from its source radial evaluation.
addnode('src.mean.object','source-definition-object',
 'For each i, mean_i is the actual expectation/integral of the literal Y_i under the original product law; this object is the term E[Y_i] in Z_i=Y_i-E[Y_i].',
 ['A3.SS2.p12.m5','A3.SS2.p13.m1'],
 'Object/reference only. Defining Z does not depend on the radial evaluation mean_i=(a/d)(I tensor tt^T). Actual integrability remains an internal applicability obligation for the intended source expectation, not a prerequisite binder for writing the totalized integral.')
removed=[e for e in E if e['prerequisite']=='src.Y.mean' and e['consumer']=='src.Z']
assert len(removed)==1
E[:]=[e for e in E if not(e['prerequisite']=='src.Y.mean' and e['consumer']=='src.Z')]
addedge('src.Y','src.mean.object','A3.SS2.p13.m1','The mean object refers to the actual literal Y and original experiment, without evaluation.','definition-object-reference')
addedge('src.mean.object','src.Z','A3.SS2.p13.m1','Literal centering refers to the actual mean object; no radial identity is needed to define Z.','definition-object-reference')
addedge('src.mean.object','src.Y.mean','A3.SS2.p12.m5','The source radial identity evaluates this actual mean object.','definition-object-reference')
addedge('src.mean.object','src.Ymean.norm','A3.Ex111','The right component bounds the actual mean object. Its radial evaluation remains a separate proof ingredient.','definition-object-reference')

for a,b,site,usage in [
 ('src.assumptions','int.dimension.positive','A3.Ex111','Natural q and source hq discharge positive denominator d at the norm-bound use.'),
 ('src.params','int.rank.positive','A3.Ex108','Literal r=q+1 discharges r>0 for normalized radial scalar.'),
 ('int.rank.positive','int.index.nonempty','A3.Ex111','Natural successor dimension supplies a nonempty identity block.'),
 ('int.dimension.positive','int.logargument.positive','A3.SS2.p10.1','d>=2 gives logarithm argument>1.'),
 ('src.cutoff','int.logargument.positive','A3.SS2.p10.1','Uses the literal log(1000d), not a changed cutoff.'),
 ('src.cutoff','int.cutoff.positive','A3.Ex111','Literal L=2r+3log(1000d) is the coefficient being checked.'),
 ('int.rank.positive','int.cutoff.positive','A3.Ex111','r>=1 supplies positive2r.'),
 ('int.logargument.positive','int.cutoff.positive','A3.Ex111','Positive log term yields L>0.'),
 ('src.cutoff','int.normsquares.nonnegative','A3.Ex111','R is the literal squared row norm.'),
 ('src.row','int.normsquares.nonnegative','A3.Ex111','The other factor is a squared Euclidean t norm.'),
 ('int.dimension.positive','int.scalars.nonnegative','A3.Ex111','Positive d controls inverse/scalar signs and denominator.'),
 ('int.rank.positive','int.scalars.nonnegative','A3.Ex108','Positive r controls normalized radial reciprocal and target coefficient signs.'),
 ('int.cutoff.positive','int.scalars.nonnegative','A3.Ex111','Nonnegative L makes off-cutoff zero bound valid; L+1 also nonnegative.'),
 ('int.rank.positive','src.radial.mean','A3.Ex108','r!=0 permits defining/evaluating normalized scalar a=(1/r)E[R indicator].'),
 ('int.rank.positive','gap.radial','A3.Ex108','Trace/radial division side condition r>0 is supplied internally.'),
 ('int.rank.positive','src.a.range','A3.SS2.p12.m4','Dividing0<=E[R indicator]<=E[R]=r by positive r gives the declared a range.'),
 ('int.normsquares.nonnegative','src.a.range','A3.SS2.p12.m4','0<=R indicator<=R is the nonnegative truncation input; not a tail bound.'),
 ('int.index.nonempty','gap.rankone.tensor','A3.Ex111','The I_r tensor norm equality uses nonempty r-block and norm(I_r)=1.'),
 ('int.dimension.positive','gap.rankone.tensor','A3.Ex111','d>0 removes |d^-1| in the scaled norm equalities.'),
 ('int.dimension.positive','src.Ymean.norm','A3.Ex111','Positive d and0<=a from src.a.range make a/d nonnegative.'),
 ('int.index.nonempty','src.Ymean.norm','A3.Ex111','Nonempty identity block supports equality||mean||=a||t||^2/d.'),
 ('src.Y','case.Y.kept','A3.Ex111','Literal closed-cutoff retained branch defines the pointwise matrix.'),
 ('src.cutoff','case.Y.kept','A3.Ex111','Use the actual R and L in the retained condition.'),
 ('src.t.bound','case.Y.kept','A3.Ex111','Feature squared norm<=2r.'),
 ('int.normsquares.nonnegative','case.Y.kept','A3.Ex111','R>=0 and squared-feature nonnegativity discharge order multiplications.'),
 ('int.dimension.positive','case.Y.kept','A3.Ex111','Positive d discharges division and norm-scalar sign.'),
 ('int.rank.positive','case.Y.kept','A3.Ex111','Nonnegative2r permits use of R<=L.'),
 ('gap.rankone.tensor','case.Y.kept','A3.Ex111','Source norm equality on the retained branch; formal applicability remains open.'),
 ('src.Y','case.Y.dropped','A3.Ex111','Literal else branch gives exactlyzero, not an arbitrary fallback.'),
 ('src.cutoff','case.Y.dropped','A3.Ex111','Negated closed-cutoff condition selects the else branch.'),
 ('int.scalars.nonnegative','case.Y.dropped','A3.Ex111','0<=2rL/d supplies the off-cutoff inequality.'),
 ('case.Y.kept','src.Y.norm','A3.Ex111','One guarded branch of exhaustive all-outcome cutoff cases.'),
 ('case.Y.dropped','src.Y.norm','A3.Ex111','The complementary guarded branch of exhaustive all-outcome cutoff cases.'),
 ('int.scalars.nonnegative','src.radius','A3.Ex112','Exact denominators/radius coefficients have internally discharged signs.'),
 ('int.scalars.nonnegative','src.weighted.radius','A3.SS2.p13.3','R_*>=0 supports contraction from|cos|<=1.')]:addedge(a,b,site,usage)

for n in N:
 if n['id']=='src.Y.mean':
  n['note']+=' V2 clarification: derived radial evaluation of src.mean.object; not a logical prerequisite for the literal definition src.Z.'
 if n['id']=='gap.rankone.tensor':
  n['note']+=' V2: d>0 and the nonempty I_r block are explicitly discharged by internal nodes. Norm-identity formal/library applicability itself remains open.'
 if n['id']=='src.Y.norm':
  n['note']+=' V2: all outcomes are covered by the two explicit guarded branches cases.literal.Y.norm; no cutoff-event assumption escapes.'
g['schema_version']=2
g['parent_graph']=dict(path='source-proof-graph-freeze-v1.json',sha256=sha(R/'source-proof-graph-freeze-v1.json'))
g['challenge']=dict(path='successor-v2/originals/TC-challenge-v1.json',sha256=sha(challenge))
g['status']='PROPOSED_SOURCE_TOPOLOGY_SUCCESSOR_V2; TC-F1/F2 response supplied; distinct incremental challenge pending; no self-approval'
g['route_semantics']+=' V2: cutoff cases are conditional branches, jointly covering an exhaustive partition; they are not alternate unguarded OR proofs. Existing sufficient mean/integrability alternatives remain explicit OR ports, not AND source prerequisites.'
g['source_only_discharge_status']='Paper-side derivation dependencies documented, not Lean proofs or target API availability claims.'
g['unchanged_source_binders_and_definitions']=True
g['formal_applicability_status']='All target norm/mean/integrability/radius proofs remain OPEN_INTERNAL_NOT_PREMISE; source-only numerical discharge is not compiled evidence.'
dump('source-proof-graph-v2.json',g)

covermap={x['source_unit']:x for x in c['coverage']}
mods={
 'A3.SS2.p1.1':(['src.params','src.row','int.rank.positive','int.index.nonempty'],'Retain source definitions; expose successor positivity/nonempty consequences internally.'),
 'A3.SS2.p10.1':(['src.cutoff','int.logargument.positive','int.cutoff.positive','int.normsquares.nonnegative'],'Retain only literal L,R definitions and their numerical side conditions; MGF/Markov/tail material remains excluded.'),
 'A3.Ex107':(['src.Y','case.Y.kept','case.Y.dropped'],'Literal indicator/closed-cutoff definition supplies the two guarded branches; no event premise.'),
 'A3.Ex108':(['src.radial.mean','gap.radial','int.rank.positive','int.scalars.nonnegative'],'Radial identity and normalized scalar, with r>0 explicit; symmetry/integration applicability remains open.'),
 'A3.SS2.p12.3':(['src.a.range','int.rank.positive','int.normsquares.nonnegative'],'0<=a<=1 uses nonnegative truncated R and positive r. Quantitative bias display remains excluded.'),
 'A3.SS2.p12.4':(['src.mean.object','src.Y.mean','gap.expectation.transport'],'Separate actual mean object from radial evaluation; only the formula clause is in scope, not the later sum-identity invocation.'),
 'A3.SS2.p13.1':(['src.mean.object','src.Z','src.Y.norm','src.Ymean.norm','gap.rankone.tensor'],'Literal Z references actual mean object; radial evaluation is needed for its norm bound, not for definingZ.'),
 'A3.Ex111':(['src.Y.norm','src.Ymean.norm','gap.rankone.tensor','int.dimension.positive','int.rank.positive','int.index.nonempty','int.cutoff.positive','int.scalars.nonnegative','case.Y.kept','case.Y.dropped'],'Both display components retained; exact numerical side-condition uses and both all-outcome cutoff branches explicit.'),
 'A3.Ex112':(['src.radius','gap.triangle','int.scalars.nonnegative'],'Exact radius arithmetic/sign discharge internal; no added bound premise.'),
 'A3.SS2.p13.3':(['src.weighted.radius','src.cos.abs','gap.scalar.norm','int.scalars.nonnegative'],'Weighted contraction with nonnegativeR_* explicit.'),
 'A3.SS2.p18.1':(['int.dimension.positive'],'Only the already-present sentence2q+1<d impliesd>=2 supplies a source confirmation of the internal numerical discharge. The2r<=d asymptotic simplification, z/L estimates and all concentration work remain excluded.')}
for k,(ns,reason) in mods.items():covermap[k].update(disposition='NODE',nodes=ns,reason=reason)
c['stage']='SOURCE_ONLY_SUCCESSOR_V2_AFTER_DISTINCT_CHALLENGE; original raw freeze unchanged'
c['schema_version']=2
c['parent_coverage']=dict(path='raw-source-coverage-freeze-v1.json',sha256=sha(R/'raw-source-coverage-freeze-v1.json'))
c['independent_topology_review']='REQUIRED: TC incremental challenge of changed nodes/edges; extractor does not approve successor.'
c['source_scope_extension']='No new source claim/target; p18.1 numerical confirmation split from previously excluded downstream paragraph. All original87 atomic units remain explicitly disposed.'
dump('source-proof-coverage-v2.json',c)

for x in p['ports']:
 if x['id']=='port.parameters':
  x['type']='SOURCE_ONLY_DISCHARGE_DOCUMENTED_FORMAL_APPLICABILITY_OPEN'
  x['status']='Internal derivation dependencies now explicit; independent incremental challenge pending; no Lean proof/target API search.'
  x['source_only_discharge_nodes']=['int.dimension.positive','int.rank.positive','int.index.nonempty','int.logargument.positive','int.cutoff.positive','int.normsquares.nonnegative','int.scalars.nonnegative']
 if x['id']=='port.Y.pointwise':
  x['conditional_cases']='cases.literal.Y.norm: case.Y.kept and case.Y.dropped are guarded implications covering the closed-cutoff partition, not two sufficient OR proof routes.'
  x['side_conditions_internal']=['d>0','r>=1','R_i>=0','L>=0','2rL/d>=0']
 if x['id']=='port.rankone.tensor.norm':
  x['side_conditions_internal']=['int.dimension.positive','int.index.nonempty','int.scalars.nonnegative']
 if x['id']=='port.actual.mean':
  x['object_evaluation_split']='src.mean.object is the actual integral; src.Y.mean evaluates it by the radial identity. The identity is a proof input to the norm bound, not the definition ofZ.'
 if x['id']=='port.centered.radius':
  x['definition_object_inputs']=['src.Y','src.mean.object']
  x['proof_inputs_for_bound']=['src.Y.norm','src.Ymean.norm','gap.triangle']
p['schema_version']=2
p['parent_ports']=dict(path='internal-port-obligations-v1.json',sha256=sha(R/'internal-port-obligations-v1.json'))
p['TC_F1']='Numerical and both branch side conditions documented as internal dependencies. No hd/hr/hL/Nonempty or certificate binder added.'
p['TC_F2']='Actual mean object and radial evaluation separated.'
p['TC_F3']='Remains OPEN_INTERNAL_NOT_PREMISE; the five SOURCE_GAP omitted derivations retain their source meaning and do not become theorem-falsity/API-failure evidence.'
dump('internal-port-obligations-v2.json',p)

# Exact structured before/after diff, including every changed object and edge.
def indexed(xs,k):return {x[k]:x for x in xs}
def objectdiff(a,b,key):
 ia,ib=indexed(a,key),indexed(b,key)
 return dict(added=[ib[k] for k in ib if k not in ia],removed=[ia[k] for k in ia if k not in ib],
             modified=[dict(id=k,before=ia[k],after=ib[k]) for k in ia.keys()&ib.keys() if ia[k]!=ib[k]])
def edgekey(e):return (e['prerequisite'],e['consumer'],e['consumer_use_site']['id'])
ia={edgekey(x):x for x in g1['edges']};ib={edgekey(x):x for x in g['edges']}
diff=dict(nodes=objectdiff(g1['nodes'],g['nodes'],'id'),
 edges=dict(added=[ib[k] for k in ib if k not in ia],removed=[ia[k] for k in ia if k not in ib],modified=[dict(key=k,before=ia[k],after=ib[k]) for k in ia.keys()&ib.keys() if ia[k]!=ib[k]]),
 coverage=objectdiff(c1['coverage'],c['coverage'],'source_unit'),ports=objectdiff(p1['ports'],p['ports'],'id'),
 added_conditional_case_routes=g['conditional_case_routes'],
 unchanged_downstream_consumer_edges=(g1['downstream_consumer_edges']==g['downstream_consumer_edges']),
 unchanged_source_gaps=(g1['source_gaps']==g['source_gaps']),
 metadata_changes=dict(graph={k:dict(before=g1.get(k),after=g.get(k)) for k in sorted(set(g1)|set(g)) if k not in ['nodes','edges','downstream_consumer_edges','source_gaps','conditional_case_routes'] and g1.get(k)!=g.get(k)},
                       coverage={k:dict(before=c1.get(k),after=c.get(k)) for k in sorted(set(c1)|set(c)) if k!='coverage' and c1.get(k)!=c.get(k)},
                       ports={k:dict(before=p1.get(k),after=p.get(k)) for k in sorted(set(p1)|set(p)) if k!='ports' and p1.get(k)!=p.get(k)}))
dump('exact-diff-v1-to-v2.json',diff)
dump('challenge-response-v2.json',dict(
 actor='radius_sg_2c71',challenge_sha256=sha(challenge),parent_packet_seal_sha256=sha(R/'packet-seal-v1.json'),
 finding_responses=[
 dict(id='TC-F1',response='SOURCE_ONLY_DISCHARGE_AND_CASE_RECORDS_SUPPLIED_PENDING_INDEPENDENT_CHALLENGE',
      nodes=['int.dimension.positive','int.rank.positive','int.index.nonempty','int.logargument.positive','int.cutoff.positive','int.normsquares.nonnegative','int.scalars.nonnegative','case.Y.kept','case.Y.dropped'],
      key_dependencies='Existing Nat/hq -> positive d; literal r=q+1 -> positive r/nonempty; positive d -> log argument>1; literal L plus r/log positivity -> L>=0; positive scalars -> kept/dropped case uses and radial/tensor/mean norm uses.',
      no_new_binder=True,formal_proof_or_API_status='OPEN; no target proof or retrieval attempted'),
 dict(id='TC-F2',response='OBJECT_AND_EVALUATION_SPLIT_SUPPLIED_PENDING_INDEPENDENT_CHALLENGE',
      removed_edge=removed[0],replacement='src.Y ->src.mean.object ->src.Z are definition/object references; src.Y.mean ->src.Ymean.norm remains the source radial proof ingredient. Actual mean object also points to its evaluation identity.'),
 dict(id='TC-F3',response='OPEN_BOUNDARY_RETAINED',meaning='Five omitted-derivation SOURCE_GAP nodes unchanged. Gaussian law, actual integrability, norm identities and consumer estimates remain internal formal applicability/proof obligations, never caller premises.')],
 unchanged=dict(statement_seal_sha256='49d5fa00c9ae90d65878d955fab59d6a4bc03e942501677719881f3d26bf1a72',source_sha256=hashlib.sha256(raw).hexdigest(),q0=True,source_binders=True,literal_experiment=True,exact_radius=True,p14_p15_exclusions=True,v1_bytes=True),
 no_self_approval=True,review_request='Distinct TC should incrementally challenge only exact changed nodes/edges/coverage/ports in exact-diff-v1-to-v2.json.',
 preserved_qualifications='All original exposure limitations, initial inline extractor nonverbatim-script qualification, V1 extraction correction, type-probe failure and no-proof/equivalence boundary remain in v1 evidence; no history fabricated.'))
dump('source-locator-addendum-v2.json',dict(source_sha256=hashlib.sha256(raw).hexdigest(),
 coordinate_convention='0-based half-open Unicode-code-point char/raw UTF8 byte offsets;1-based LF line endpoints inclusive',units=list(newloc.values())))
dump('read-trace-v2.json',dict(actor='radius_sg_2c71',purpose='Source-only incremental successor after actual distinct TC challenge.',
 actual_inputs=[dict(path='successor-v2/originals/TC-challenge-v1.json',sha256=sha(challenge)),
              *[dict(path=f,sha256=sha(R/f)) for f in ['source-proof-graph-freeze-v1.json','raw-source-coverage-freeze-v1.json','internal-port-obligations-v1.json','originals/2610.20492v1.html','source-element-index.json','packet-seal-v1.json','output-manifest-v1.json']]],
 commands=[dict(cmd="shasum -a 256 .astis/semantic-neutral-20261113/radius_tc_8b40/independent-source-type-scope-topology-challenge-v1.json && cat .astis/semantic-neutral-20261113/radius_tc_8b40/independent-source-type-scope-topology-challenge-v1.json",result='exit0; full actual challenge read; hash matched'),
           dict(argv=['python3','-'],role='Source-only bounded actual-v1 graph/coverage/port summary; printed nodes,edge endpoints/use anchors,affected coverage and port classifications.',result='exit0; no new external or implementation input'),
           dict(tool='apply_patch',input_original='build_successor_v2.py',result='Created own successor builder'),
           dict(cmd='python3 .astis/semantic-neutral-20261113/radius_sg_2c71/build_successor_v2.py',result='this reproducible source-only builder; no subprocess/Lean/API search')],
 new_exposure='Actual TC challenge findings. Source topology v1 and own source originals only. No other TC private rationale/artifacts, no new Lean/type/proof/API reads.',
 failed_attempts=[],v1_qualifications_retained=True,
 mutations=dict(all_new_files='own root/successor-v2 plus own build_successor_v2.py',v1_files=0,Lean_target=0,C=0,ledger=0,website=0,Git_index=0,new_Goal=0,spawns=0,proof_or_API_retrieval=0)))

# Structural validation is deliberately distinct from mathematical acceptance.
ids={n['id'] for n in N};assert len(ids)==len(N)
assert all(e['prerequisite'] in ids and e['consumer'] in ids for e in E)
assert len({edgekey(e) for e in E})==len(E)
assert len(c['coverage'])==len(c1['coverage'])==87
assert all(set(x['nodes'])<=ids for x in c['coverage'])
assert all(sha(R/x['path'])==x['sha256'] for x in old_manifest['files'])
assert sha(R/'packet-seal-v1.json')=='ce59761f511cc2c9399fda45c04907e4cc87d33484fc90e30a7b9a63cbd57be0'
for k,u in newloc.items():
 a,b=u['char'];x,y=u['raw_utf8_byte'];assert S[a:b].encode()==raw[x:y]==(R/u['original_path']).read_bytes()
dump('structural-validation-v2.json',dict(v1_sealed_files_unchanged=True,locators_roundtrip=True,coverage_units=87,nodes=len(N),edges=len(E),
 conditional_case_routes=len(g['conditional_case_routes']),source_gaps_unchanged=True,downstream_consumer_edges_unchanged=True,
 source_graph_cycles='not inferred from import structure; proof/reference edge separation explicit',
 no_mathematical_or_type_proof_claim=True,independent_incremental_TC='REQUIRED; no self-approval'))

dump('successor-manifest-v2.json',dict(parent_root='..',files=[dict(path=str(f.relative_to(O)),sha256=sha(f),bytes=f.stat().st_size) for f in sorted(O.rglob('*')) if f.is_file()],
 builder=dict(path='../build_successor_v2.py',sha256=sha(R/'build_successor_v2.py')),
 parent_seal=dict(path='../packet-seal-v1.json',sha256=sha(R/'packet-seal-v1.json')),
 excludes=['successor-manifest-v2.json','successor-seal-v2.json']))
dump('successor-seal-v2.json',dict(actor='radius_sg_2c71',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
 manifest=dict(path='successor-manifest-v2.json',sha256=sha(O/'successor-manifest-v2.json')),
 graph=dict(path='source-proof-graph-v2.json',sha256=sha(O/'source-proof-graph-v2.json')),
 coverage=dict(path='source-proof-coverage-v2.json',sha256=sha(O/'source-proof-coverage-v2.json')),
 ports=dict(path='internal-port-obligations-v2.json',sha256=sha(O/'internal-port-obligations-v2.json')),
 exact_diff=dict(path='exact-diff-v1-to-v2.json',sha256=sha(O/'exact-diff-v1-to-v2.json')),
 response=dict(path='challenge-response-v2.json',sha256=sha(O/'challenge-response-v2.json')),
 status='PROPOSED_SUCCESSOR; distinct incremental topology challenge pending; source-only numeric discharges documented, all target formal applicability/proofs open',
 immutable_from_here=True))
print(json.dumps(dict(root=str(O),nodes=len(N),edges=len(E),coverage_units=87,
 added_nodes=len(diff['nodes']['added']),modified_nodes=len(diff['nodes']['modified']),
 added_edges=len(diff['edges']['added']),removed_edges=len(diff['edges']['removed']),
 hashes={n:sha(O/n) for n in ['source-proof-graph-v2.json','source-proof-coverage-v2.json','internal-port-obligations-v2.json','exact-diff-v1-to-v2.json','challenge-response-v2.json','successor-manifest-v2.json','successor-seal-v2.json']}),indent=2))
