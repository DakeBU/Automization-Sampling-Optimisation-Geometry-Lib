import Tests.GaussianComplexityFixedSpectrumCosineExpansion
open scoped BigOperators
open Filter Lean
set_option autoImplicit false

example {κ : ℝ} (hκ : 2 ≤ κ) :
  let r : ℝ := (Real.sqrt κ - 1) / (Real.sqrt κ + 1)
  (∀ θ : ℝ,
    2 / (κ + 1 + (κ - 1) * Real.cos θ) =
      (1 / Real.sqrt κ) *
        (1 + 2 * ∑' j : ℕ, (-r) ^ (j + 1) * Real.cos (((j + 1 : ℕ) : ℝ) * θ))) ∧
  (∀ θ : ℝ,
    Summable (fun j : ℕ => ‖(-r) ^ (j + 1) * Real.cos (((j + 1 : ℕ) : ℝ) * θ)‖)) ∧
  TendstoUniformly
    (fun N : ℕ => fun θ : ℝ =>
      ∑ j ∈ Finset.range N, (-r) ^ (j + 1) * Real.cos (((j + 1 : ℕ) : ℝ) * θ))
    (fun θ : ℝ => ∑' j : ℕ, (-r) ^ (j + 1) * Real.cos (((j + 1 : ℕ) : ℝ) * θ))
    atTop := by
  exact AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumCosineExpansion.actual_inverse_spectrum_cosine_expansion hκ

def ExpectedPrivate : Prop := ∀ {d : ℕ} (hd : 2 ≤ d) {κ : ℝ} (hκ : 2 ≤ κ) (n : ℕ),
  let θ : Fin d → ℝ := fun i => ((i.val : ℝ) + 1 / 2) * Real.pi / (d : ℝ)
  let eigenvalue : Fin d → ℝ := fun i => (κ + 1) / 2 + (κ - 1) / 2 * Real.cos (θ i)
  let r : ℝ := (Real.sqrt κ - 1) / (Real.sqrt κ + 1)
  (∑ i : Fin d, Real.cos ((n : ℝ) * θ i) / eigenvalue i) =
    (1 / Real.sqrt κ) *
      ((∑ i : Fin d, Real.cos ((n : ℝ) * θ i)) +
        2 * ∑' j : ℕ, (-r) ^ (j + 1) *
          (∑ i : Fin d, Real.cos ((n : ℝ) * θ i) *
            Real.cos (((j + 1 : ℕ) : ℝ) * θ i)))


run_cmd do
  let env := (← getEnv).setExporting false
  setEnv env
  let target := `AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumCosineExpansion.actual_inverse_spectrum_cosine_expansion
  let wanted := env.constants.toList.filter fun (n, _) =>
    n == target || n.toString.endsWith ".actual_inverse_grid_cosine_series"
  unless wanted.length == 2 do throwError "Expected exactly two actual packet constants"
  let allowed := [`propext, `Classical.choice, `Quot.sound]
  for (n, ci) in wanted do
    let some proof := ci.value? true | throwError "Missing actual kernel proof term"
    let used := proof.getUsedConstants.toList
    let astis := used.filter fun k => k.toString.startsWith "AutoSamplingTheory."
    if n == target then
      unless astis.isEmpty do throwError "Unexpected public ASTIS producer parent: {astis}"
    else
      unless astis == [target] do throwError "Actual consumer must use exactly the new canonical producer: {astis}"
    let axs ← Lean.collectAxioms n
    unless axs.all (fun a => allowed.contains a) do throwError "Unexpected axiom: {axs}"
    logInfo m!"ACTUAL_TARGET {n}"
    logInfo m!"ACTUAL_TYPE {n}: {ci.type}"
    logInfo m!"DIRECT_ASTIS {n}: {astis}"
    logInfo m!"DIRECT_ALL {n}: {used}"
    logInfo m!"KERNEL_AXIOMS {n}: {axs}"
    if n != target then
      Lean.Elab.Command.liftCoreM <| addDecl <| Declaration.thmDecl {
        name := Name.mkSimple "ActualPrivateSealedTypeCheck"
        levelParams := []
        type := mkConst (Name.mkSimple "ExpectedPrivate")
        value := mkConst n
      }
      logInfo "ACTUAL_PRIVATE_SEALED_LITERAL_KERNEL_TYPE_APPLICATION_PASS"

#print axioms ActualPrivateSealedTypeCheck
#print axioms AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumCosineExpansion.actual_inverse_spectrum_cosine_expansion
