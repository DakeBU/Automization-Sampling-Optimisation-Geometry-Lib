import json
from pathlib import Path
p=Path('.astis/semantic-neutral-20261110/cg_sg_1d7a46/phase1/source_index.json')
x=json.loads(p.read_text())
for item in x['items']:
 if item['tag']=='math' and (item['root']!='A3.SS2' or item['id'].startswith(('A3.SS2.p1.','A3.SS2.p2.','A3.SS2.p3.','A3.SS2.p4.','A3.SS2.p5.','A3.SS2.p6.','A3.SS2.p7.','A3.SS2.p8.','A3.Ex85.','A3.Ex86.','A3.Ex87.','A3.Ex88.','A3.Ex89.','A3.Ex90.','A3.Ex91.','A3.Ex92.','A3.Ex93.','A3.Ex94.','A3.Ex95.','A3.Ex96.','A3.Ex97.','A3.Ex98.','A3.Ex99.','A3.Ex100.','A3.Ex101.','A3.Ex102.'))):
  print(item['id'],item['alttext_exact'])
