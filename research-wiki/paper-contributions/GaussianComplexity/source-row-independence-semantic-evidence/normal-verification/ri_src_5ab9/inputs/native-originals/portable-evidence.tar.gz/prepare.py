import json,os,pathlib,re,tarfile
from run import ROOT,REPO,run,sha
C='66e0bb9b748d68816a8443d60696656c9340222f'
P='AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumSourceRowIndependence.lean'
T='Tests/GaussianComplexityFixedSpectrumSourceRowIndependence.lean'
E='research-wiki/paper-contributions/GaussianComplexity/source-row-independence-semantic-evidence'
files={};modules=[];imports={}
def freeze(p):
    if p in files:return (ROOT/'inputs'/p).read_bytes()
    r=run('freeze-'+str(len(files)),['git','show',C+':'+p]);assert r.returncode==0,p
    d=ROOT/'inputs'/p;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(r.stdout)
    files[p]={'sha256':sha(r.stdout),'bytes':len(r.stdout),'worktree_equal_at_freeze':(REPO/p).read_bytes()==r.stdout}
    assert files[p]['worktree_equal_at_freeze'],p
    return r.stdout
def visit(p):
    if p in modules:return
    xs=re.findall(r'^import\s+(\S+)',freeze(p).decode(),re.M);imports[p]=xs
    for n in xs:
        if n.startswith(('AutoSamplingTheory.','Tests.')):visit(n.replace('.','/')+'.lean')
    modules.append(p)
visit(P);visit(T)
assert files[P]['sha256']=='f63b38ba191d22354f23cf7a518717f47be96728a72b2bb3c7fbd9292c47db86'
assert files[T]['sha256']=='7f138451e328360e9dcf049f3de0b267693be622818781705fdf4c6521a33dd0'
paths=['AGENTS.md','CONTRIBUTING.md','.agents/prompts/collaborator-contribution.md','.agents/prompts/samplewiki-route.md','docs/contributor-codex-contract.md','docs/theorem-publication-protocol.md','docs/proof-digestion-protocol.md','docs/evidence-routed-memory-protocol.md','.agents/skills/astis-substantive-advance/SKILL.md','.agents/skills/astis-semantic-roundtrip/SKILL.md','lean-toolchain','lake-manifest.json','lakefile.lean','research-wiki/paper-contributions/GaussianComplexity/source-row-independence-statement-seal.json',E+'/publication-draft-record.json',E+'/source-lean-map.draft.json',E+'/local-attempt-diagnoses.json',E+'/preproof-source-types-topology-local-build.original-manifest.json',E+'/preproof-source-types-topology-local-build.original-files.tar.gz','website/content/declaration_lessons/huanjian-gaussian-source-row-independence.json','website/content/publications/huanjian-gaussian-source-row-independence.json','tools/astis.py','tools/astis_site.py','tools/astis_publication.py','website/scripts/declaration_lessons.py','website/scripts/inline_lean.py','website/scripts/source_lineage.py','website/scripts/library_shelves.py','website/scripts/formalization_progress.py']
for p in paths:freeze(p)
assert files['research-wiki/paper-contributions/GaussianComplexity/source-row-independence-statement-seal.json']['sha256']=='88a55849ce9e13a9a04edff6aac13ce32d4370712b1b7a422fba0d570ff0b25e'
assert files[E+'/source-lean-map.draft.json']['sha256']=='6d4aea4726db237433e458bc5c31252da88f4724013c9b50570a26dbfd2ceeb0'
manifest=freeze('lake-manifest.json');assert sha(manifest)=='b83ca83b9cf7caa85fa8b023c2ff9a3fb7a7cce7e1c332e810c348535ec49c37'
deps=[]
for p in json.loads(manifest)['packages']:
    d=REPO/'.lake/packages'/p['name']
    h=run('package-'+p['name']+'-head',['git','rev-parse','HEAD'],cwd=d)
    s=run('package-'+p['name']+'-clean',['git','status','--porcelain=v1','--untracked-files=all'],cwd=d)
    assert h.returncode==s.returncode==0 and h.stdout.decode().strip()==p['rev'] and not s.stdout,p['name']
    cache=d/'.lake/build/lib/lean'
    assert not (cache/'AutoSamplingTheory').exists() and not (cache/'Tests').exists()
    deps.append({'name':p['name'],'head':p['rev'],'clean_including_untracked':True,'cache':str(cache)})
assert len(deps)==9
lean=pathlib.Path.home()/'.elan/toolchains/leanprover--lean4---v4.33.0/bin/lean'
assert sha(lean.read_bytes())=='1b370cfcbf44e80d1b004ab1b1ab9a4c73951f9f7c242140bcff9bc577576554'
v=run('native-lean-version',[str(lean),'--version']);assert v.returncode==0 and b'4.33.0' in v.stdout
assert run('native-lean-file',['file',str(lean)]).returncode==0
run('head-initial',['git','rev-parse','HEAD'])
scratch=ROOT/'scratch';scratch.mkdir(exist_ok=True)
for p in modules:
    d=scratch/p;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes((ROOT/'inputs'/p).read_bytes())
probe=REPO/'.astis/huanjian-gc-source-row-independence-20261112/SourceRowIndependenceKernelProbe.lean'
for d in [ROOT/'inputs/SourceRowIndependenceKernelProbe.lean',scratch/'SourceRowIndependenceKernelProbe.lean']:d.write_bytes(probe.read_bytes())
files['private:SourceRowIndependenceKernelProbe.lean']={'sha256':sha(probe.read_bytes()),'bytes':probe.stat().st_size,'origin':str(probe.relative_to(REPO))}
oleans=ROOT/'native-olean';oleans.mkdir(exist_ok=True);assert not list(oleans.rglob('*'))
pm=json.loads((REPO/'research-wiki/process-memory.json').read_text())
(ROOT/'process-memory-consulted.json').write_text(json.dumps({'registry_sha256':sha((REPO/'research-wiki/process-memory.json').read_bytes()),'record_ids':[x.get('id') for x in pm.get('records',[]) if any(w in json.dumps(x).lower() for w in ['failure','evidence','assumption','source','independen'])],'scope':'Process instructions consulted; no theorem truth imported.'},indent=2)+'\n')
m={'candidate_commit':C,'P':P,'T':T,'E':E,'modules':modules,'imports':imports,'files':files,'dependencies':deps,'lean_binary':{'path':str(lean),'sha256':sha(lean.read_bytes())},'lean_version':v.stdout.decode().strip(),'lean_path':[str(oleans)]+[d['cache'] for d in deps],'fresh_empty_ASTIS_output':True,'no_ASTIS_cached_olean_copied_or_reachable':True}
(ROOT/'input-manifest.json').write_text(json.dumps(m,indent=2)+'\n')
print(json.dumps({'closure':modules,'frozen_files':len(files),'packages':len(deps),'lean':m['lean_binary']},indent=2))
