import Tests.GaussianComplexityFixedSpectrumTruncatedRowMoment
import Lean.Util.FoldConsts
open Lean Elab Command
private def moduleName68bc (env : Environment) (n : Name) : Name :=
  match env.getModuleIdxFor? n with
  | some idx => env.allImportedModuleNames[idx.toNat]!
  | none => .anonymous
private def ownedModule68bc (env : Environment) (n : Name) : Bool :=
  let m := (moduleName68bc env n).toString
  m.startsWith "AutoSamplingTheory." || m.startsWith "Tests."
run_elab do
  let env ← getEnv
  let mut count := 0
  let mut authored : NameSet := {}
  for (n, c) in env.constants.toList do
    if ownedModule68bc env n then
      count := count + 1
      authored := authored.insert n
      let ds : List Name := match c.value? (allowOpaque := true) with
        | some v => v.getUsedConstants.toList
        | none => []
      logInfo m!"MODULE_OWNED {moduleName68bc env n}: {n}"
      logInfo m!"MODULE_OWNED_DIRECT {n}: {ds.filter (ownedModule68bc env)}"
  logInfo m!"MODULE_OWNED_COUNT {count}"
  if count != 3 then throwError "Unexpected owned declaration count {count}"
