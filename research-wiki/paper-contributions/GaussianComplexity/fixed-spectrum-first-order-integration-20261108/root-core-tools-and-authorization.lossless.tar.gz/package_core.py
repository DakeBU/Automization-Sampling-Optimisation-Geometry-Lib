from pathlib import Path
import gzip, hashlib, json, shutil, subprocess, tarfile
sha = lambda b: hashlib.sha256(b).hexdigest()
P = Path('.astis/huanjian-gc-fixed-spectrum-first-order-integration-20261108')
B = Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-first-order-integration-20261108')
S = Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-first-order-semantic-evidence')
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip() == 'f45ba48f7dc74db28f648c38c5a486615723a513'
proposal = json.loads((P/'independent-reader/conditional-proposal-v1/proposal-report.json').read_bytes())
receipt = json.loads((B/'exact-shared-application-receipt.json').read_bytes())
assert receipt['normal_state'] == 'STABILIZING' and receipt['normal_STAB_append_events'] == 1
for row in proposal['shared_paths']: assert sha(Path(row['path']).read_bytes()) == row['planned_after_sha256']
q = P/'independent-reader/conditional-proposal-v1'
dest = B/'independent-reader/conditional-proposal-v1'; assert not dest.exists(); shutil.copytree(q,dest)
for p in q.rglob('*'):
    if p.is_file(): assert (dest/p.relative_to(q)).read_bytes() == p.read_bytes()
shutil.copy2(P/'root-conditional-proposal-review-v1.json',B/'root-conditional-proposal-review-v1.json')
checks = B/'precore-actual-checks'; checks.mkdir()
names = ['20261108T140236334820Z-fixed-spectrum-preintegration-origin-main-network.receipt.json',
         '20261108T140429744232Z-fixed-spectrum-first-order-sole-STAB-exact-eight-path-application.receipt.json']
for name in names:
    p = Path('.astis/huanjian-resume-20261103')/name
    r = json.loads(p.read_bytes()); raw = Path(r['log']).read_bytes(); assert sha(raw) == r['log_sha256']
    (checks/name).write_bytes(p.read_bytes()); (checks/(Path(r['log']).name+'.gz')).write_bytes(gzip.compress(raw,mtime=0))
files = sorted(p for p in P.iterdir() if p.is_file())
arc = B/'root-core-tools-and-authorization.lossless.tar.gz'
with tarfile.open(arc,'w:gz') as t:
    for p in files: t.add(p,arcname=p.name,recursive=False)
with tarfile.open(arc,'r:gz') as t:
    for p in files: assert t.extractfile(p.name).read() == p.read_bytes()
(B/'root-core-tools-and-authorization.manifest.json').write_text(json.dumps({
    'archive':str(arc),'sha256':sha(arc.read_bytes()),'all_originals_retained':True,
    'scope':'Root integration tools only. Independent v3 browser successor still under separate review; no running helper or UI acceptance is claimed.',
    'files':[{'original':str(p),'member':p.name,'sha256':sha(p.read_bytes())} for p in files]},indent=2)+'\n')
pack = B/'frozen-raw-packaging'; pack.mkdir(); safe, rows = [], []
for p in sorted(q for q in B.rglob('*') if q.is_file()):
    raw = p.read_bytes(); binary = p.suffix in ['.gz','.zip','.png'] or b'\0' in raw
    ignored = subprocess.run(['git','check-ignore','-q','--',str(p)]).returncode == 0
    bad = not binary and (b'\r\n' in raw or raw.endswith(b'\n\n') or any(x.endswith((b' ',b'\t')) for x in raw.splitlines()))
    if ignored or bad:
        z = pack/(str(len(rows)).zfill(3)+'-'+p.name+'.gz'); z.write_bytes(gzip.compress(raw,mtime=0))
        assert gzip.decompress(z.read_bytes()) == raw
        rows.append({'original_path':str(p),'raw_sha256':sha(raw),'raw_bytes':len(raw),
                     'gzip_path':str(z),'gzip_sha256':sha(z.read_bytes()),'original_retained_unchanged':True})
        safe.append(z)
    else: safe.append(p)
mp = pack/'manifest.json'; mp.write_text(json.dumps({'scope':'Only frozen evidence is losslessly wrapped. Shared/mutable paths staged DIRECTLY and checked against live bytes.','files':rows},indent=2)+'\n'); safe.append(mp)
mutable = [Path(row['path']) for row in proposal['shared_paths']] + [
    Path('runs/substantive_advances.jsonl'),
    Path('research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-first-order.json')]
safe += mutable + [S/'preintegration-GitHub-PR385-actual-readback.json']
subprocess.run(['git','add','--',*map(str,safe)],check=True)
for p in mutable: assert subprocess.check_output(['git','show',':'+str(p)]) == p.read_bytes(), str(p)
subprocess.run(['git','diff','--cached','--check'],check=True)
print(json.dumps({'staged_paths':len(safe),'shared8_and_mutable2_index_equals_live':True,
                  'frozen_raw_wrapped':len(rows),'real_core_gates_browser_acceptance':False}))
