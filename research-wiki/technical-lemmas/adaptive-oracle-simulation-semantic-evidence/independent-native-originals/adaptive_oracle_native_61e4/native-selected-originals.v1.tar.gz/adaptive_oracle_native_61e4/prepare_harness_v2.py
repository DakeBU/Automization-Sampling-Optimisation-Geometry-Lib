"""R18 literal/native boundary applications; reuse only the prior lossless export and kernel mechanics."""
from native_common import *
import re
PUBLIC='AutoSamplingTheory.TechnicalLemmas.Probability.AdaptiveOracleSimulation.measurable_simulation_joint_law_and_cost'
SUFFIX='.actual_fixed_spectrum_first_order_matvec_joint_laws_and_costs'
def main():
    closure=json.loads((OWN/'actual-import-closure.json').read_text());h=OWN/'harness-v2';h.mkdir(exist_ok=False)
    p=(OWN/'immutable-inputs/P.literal.txt').read_text().strip();t=(OWN/'immutable-inputs/T.literal.txt').read_text().strip()
    text='''import Tests.GaussianComplexityAdaptiveFirstOrderSimulation
import Lean
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring
open MeasureTheory ProbabilityTheory Matrix Lean Elab Term Meta
open AutoSamplingTheory.TechnicalLemmas.Analysis.QuadraticRegularizationOracle
open AutoSamplingTheory.TechnicalLemmas.Probability.AdaptiveOracleSimulation
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
noncomputable section
universe uS uQ uA uB uX uΩ
elab "native_actual_T" : term => do
  let env ← getEnv
  let found := env.constants.toList.filter fun (n, _) =>
    n.toString.endsWith ".actual_fixed_spectrum_first_order_matvec_joint_laws_and_costs"
  unless found.length == 1 do throwError "Expected unique actual private R18 T, found {found.length}"
  mkConstWithFreshMVarLevels found.head!.1
namespace NativeLiteralApplications

'''
    text+='theorem literal_P :\n'+p+' := by\n  exact @'+PUBLIC+'\n\n'
    text+='theorem literal_T :\n'+t+' := by\n  intro d hd κ hκ\n  dsimp only\n  intro S Ω mS mΩ μ hμ next updateFO updateMV initial hn hf hm hi fuel O\n  exact native_actual_T (d := d) hd (κ := κ) hκ (S := S) (Ω := Ω) μ next updateFO updateMV initial hn hf hm hi fuel O\n\n'
    text+='''local instance : MeasurableSpace (Option ℝ) := MeasurableSpace.comap
  (fun x : Option ℝ => x.elim (Sum.inl () : Unit ⊕ ℝ) Sum.inr) inferInstance

def rNext (s : ℝ) : ℝ ⊕ ℝ := if s ≤ 0 then .inr (-s) else .inl s
def rUpdate (_ _ a : ℝ) : ℝ := a
def rOracle (q : ℝ) : ℝ := 2*q
def rTarget (q : ℝ) : ℝ := 3*q
def rDecode (q a : ℝ) : ℝ := a+q

theorem actual_reply_sensitive_joint_law :
    let b := fun ω : ℝ => run rNext (fun s q a => rUpdate s q (rDecode q a)) rOracle 7 (-ω)
    let t := fun ω : ℝ => run rNext rUpdate rTarget 7 (-ω)
    (Measure.dirac (2 : ℝ)).map b = (Measure.dirac (2 : ℝ)).map t := by
  have hn : Measurable rNext := by
    exact Measurable.ite (measurableSet_le measurable_id measurable_const)
      (measurable_inr.comp measurable_neg) measurable_inl
  have hu : Measurable (fun p : ℝ × ℝ × ℝ => rUpdate p.1 p.2.1 p.2.2) := measurable_snd.snd
  have ho : Measurable rOracle := by unfold rOracle; fun_prop
  have hd : Measurable (fun p : ℝ × ℝ => rDecode p.1 p.2) := by unfold rDecode; fun_prop
  have hi : Measurable (fun ω : ℝ => -ω) := measurable_neg
  have he (q : ℝ) : rDecode q (rOracle q) = rTarget q := by dsimp [rDecode,rOracle,rTarget]; ring
  have full := '''+PUBLIC+''' (Measure.dirac (2 : ℝ))
    rNext rUpdate rOracle rTarget rDecode (fun ω => -ω) hn hu ho hd hi he 7
  exact full.2.2.2.1

theorem zero_fuel_pending_is_none :
    run rNext (fun s q a => rUpdate s q (rDecode q a)) rOracle 0 (-2) =
      (((-2 : ℝ), none), 0) := by norm_num [run,rNext]

theorem initial_halt_even_at_zero_fuel :
    run rNext (fun s q a => rUpdate s q (rDecode q a)) rOracle 0 2 =
      (((2 : ℝ), some 2), 0) := by norm_num [run,rNext]

theorem initial_halt_positive_fuel_no_query :
    run rNext (fun s q a => rUpdate s q (rDecode q a)) rOracle 7 2 =
      (((2 : ℝ), some 2), 0) := by norm_num [run,rNext]

theorem fuel7_real_output6_cost1 :
    run rNext (fun s q a => rUpdate s q (rDecode q a)) rOracle 7 (-2) =
      (((6 : ℝ), some 6), 1) := by norm_num [run,rNext,rUpdate,rOracle,rDecode]

theorem changed_oracle_reply_changes_output :
    run rNext (fun s q a => rUpdate s q (rDecode q a)) (fun q => 3*q) 7 (-2) =
      (((8 : ℝ), some 8), 1) := by norm_num [run,rNext,rUpdate,rDecode]

theorem expected_cost_is_one :
    (∫ ω : ℝ, ((run rNext (fun s q a => rUpdate s q (rDecode q a)) rOracle 7 (-ω)).2 : ℝ)
      ∂Measure.dirac (2 : ℝ)) = 1 := by
  rw [integral_dirac]
  norm_num [run,rNext,rUpdate,rOracle,rDecode]

theorem expected_cost_is_not_fuel7 :
    (∫ ω : ℝ, ((run rNext (fun s q a => rUpdate s q (rDecode q a)) rOracle 7 (-ω)).2 : ℝ)
      ∂Measure.dirac (2 : ℝ)) ≠ 7 := by rw [expected_cost_is_one]; norm_num

abbrev E2 := EuclideanSpace ℝ (Fin 2)
local instance : MeasurableSpace E2 := borel E2
local instance : BorelSpace E2 := ⟨rfl⟩
local instance : MeasurableSpace (Option E2) := MeasurableSpace.comap
  (fun x : Option E2 => x.elim (Sum.inl () : Unit ⊕ E2) Sum.inr) inferInstance

def eNext (s : E2 × Bool) : E2 ⊕ E2 := if s.2 = true then .inl s.1 else .inr s.1
def eUpdateFO (_ : E2 × Bool) (_ : E2) (a : ℝ × E2) : E2 × Bool := (a.2, true)
def eUpdateMV (_ : E2 × Bool) (_ : E2) (a : E2) : E2 × Bool := (a, true)
def eInitial (_ : Unit) : E2 × Bool := (WithLp.toLp 2 (fun _ : Fin 2 => (1 : ℝ)), false)

theorem eNext_measurable : Measurable eNext := by
  exact Measurable.ite ((measurableSet_singleton true).preimage measurable_snd)
    (measurable_inl.comp measurable_fst) (measurable_inr.comp measurable_fst)
theorem eUpdateFO_measurable :
    Measurable (fun p : (E2 × Bool) × E2 × (ℝ × E2) => eUpdateFO p.1 p.2.1 p.2.2) :=
  (measurable_snd.snd.snd).prodMk measurable_const
theorem eUpdateMV_measurable :
    Measurable (fun p : (E2 × Bool) × E2 × E2 => eUpdateMV p.1 p.2.1 p.2.2) :=
  (measurable_snd.snd).prodMk measurable_const
theorem eInitial_measurable : Measurable eInitial := measurable_const

'''
    tail=t[t.index('∀ (fuel : ℕ) (O :'):]
    tail=re.sub(r'\bd\b','2',tail);tail=re.sub(r'\bκ\b','2',tail)
    prefix='''let μ : Measure Unit := Measure.dirac ();
  let next := eNext; let updateFO := eUpdateFO; let updateMV := eUpdateMV; let initial := eInitial;
  '''
    text+='theorem T_concrete_full :\n  '+prefix+tail+' := by\n  dsimp only\n  intro fuel O\n  exact native_actual_T (d := 2) (by norm_num) (κ := 2) (by norm_num)\n    (S := E2 × Bool) (Ω := Unit) (Measure.dirac ()) eNext eUpdateFO eUpdateMV eInitial\n    eNext_measurable eUpdateFO_measurable eUpdateMV_measurable eInitial_measurable fuel O\n\n'
    for fuel in [0,1,7]:
        specific=tail.replace('∀ (fuel : ℕ) (O : Matrix.orthogonalGroup (Fin 2) ℝ),','let fuel : ℕ := '+str(fuel)+'; ∀ (O : Matrix.orthogonalGroup (Fin 2) ℝ),')
        assert specific!=tail
        text+='theorem T_concrete_fuel'+str(fuel)+' :\n  '+prefix+specific+' := by\n  dsimp only\n  intro O\n  exact T_concrete_full '+str(fuel)+' O\n\n'
    text+='end NativeLiteralApplications\n'
    check_names=['literal_P','literal_T','actual_reply_sensitive_joint_law','zero_fuel_pending_is_none','initial_halt_even_at_zero_fuel','initial_halt_positive_fuel_no_query','fuel7_real_output6_cost1','changed_oracle_reply_changes_output','expected_cost_is_one','expected_cost_is_not_fuel7','T_concrete_full','T_concrete_fuel0','T_concrete_fuel1','T_concrete_fuel7']
    for name in check_names:text+='#print axioms NativeLiteralApplications.'+name+'\n'
    text+='\nset_option pp.all true in\n#check @'+PUBLIC+'\nset_option pp.all true in\n#check native_actual_T\n'
    (h/'NativeLiteralApplications.lean').write_text(text)
    prior=REPO/'.astis/semantic-neutral-20261115/matrix_domain_native_61e4/harness-v1'
    for name in ['NativeAudit.lean','NativeTransitiveGraph.lean']:
        s=(prior/name).read_text().replace('Tests.GaussianComplexityMatrixMgfDomain','Tests.GaussianComplexityAdaptiveFirstOrderSimulation').replace('NativeAuditR17','NativeAuditR18').replace('NativeTransitiveR17','NativeTransitiveR18')
        s=s.replace('AutoSamplingTheory.TechnicalLemmas.Probability.RealMatrixPositiveDefIntegral.integral_posDef',PUBLIC).replace('.actual_source_four_matrix_mgfs_integrable_posDef_and_trace_bounded',SUFFIX)
        s=s.replace(str(prior.parent),str(OWN)).replace('a8bb8ea5b4474be5214bd83ae380a612e2cecb78',COMMIT)
        if name=='NativeAudit.lean':
            modules='def modules : Array String := #[\n  '+',\n  '.join(json.dumps(x) for x in closure['topological_order']+['NativeLiteralApplications'])+']\n\n'
            s,count=re.subn(r'def modules : Array String := #\[.*?\]\s*\n(?=def atJ)',modules,s,count=1,flags=re.S);assert count==1
            s=s.replace('#[`NativeLiteralApplications.literal_T_q0, `NativeLiteralApplications.literal_T_q0_d2]','#[`NativeLiteralApplications.T_concrete_fuel0, `NativeLiteralApplications.T_concrete_fuel1, `NativeLiteralApplications.T_concrete_fuel7]')
        (h/name).write_text(s)
    fixture=REPO/'research-wiki/technical-lemmas/adaptive-oracle-simulation-semantic-evidence/root-math-originals/BoundaryChecks.v2.lean'
    write_json(OWN/'harness-mechanism-custody.json',{'candidate_commit':COMMIT,'prior_lossless_kernel_mechanics_only':[{'file':str(prior/n),'sha256':file_sha(prior/n)} for n in ['NativeAudit.lean','NativeTransitiveGraph.lean']],'Root_boundary_fixture_read_for_program_data_not_old_verdict':{'file':str(fixture),'sha256':file_sha(fixture)},'new_literal_and_application_checks':check_names,'actual_T_applications':'d2 κ2; same real reply-sensitive measurable state/update policies and fixed nonzero seed input before every full orthogonal O; both entire16conj components at everyfuel and0/1/7','no_old_ASTIS_output_checks_receipts_or_acceptance_inherited':True})
    packages=json.loads((OWN/'verified-package-inputs.json').read_text());env=lean_env(packages['packages']);flags=[str(LEAN),'-DmaxRecDepth=32768','-DmaxHeartbeats=0','-Ddebug.skipKernelTC=false']
    commands=[{'id':'literal-types-and-boundaries','argv':flags+['-o',str(OUT/'NativeLiteralApplications.olean'),str(h/'NativeLiteralApplications.lean')]},{'id':'lossless-raw-type-value-kernel','argv':flags+['--run',str(h/'NativeAudit.lean')]},{'id':'complete-recursive-type-value-graph','argv':flags+['--run',str(h/'NativeTransitiveGraph.lean')]}]
    write_json(OWN/'harness-commands.json',commands)
    files=list(h.iterdir())+[OWN/n for n in ['native_common.py','prepare_harness.py','prepare_harness_v2.py','harness-mechanism-custody.json','compile-assignment.json','compile-completed.json','harness-commands.json']]+[p for p in OUT.rglob('*') if p.is_file()]
    assignment={'candidate_commit':COMMIT,'only_fresh_this_assignment_ASTIS_output_present':True,'inputs':[{'path':str(p.relative_to(OWN)),'sha256':file_sha(p)} for p in files]};write_json(OWN/'harness-assignment.json',assignment)
    for c in commands:
        for row in assignment['inputs']:assert file_sha(OWN/row['path'])==row['sha256']
        run(c['id'],c['argv'],cwd=h,env=env)
    write_json(OWN/'harness-completed.json',{'candidate_commit':COMMIT,'all_actual_exit_zero':True,'literal_kernel_DAG_and_recursive_closure_complete':True})
if __name__=='__main__':main()
