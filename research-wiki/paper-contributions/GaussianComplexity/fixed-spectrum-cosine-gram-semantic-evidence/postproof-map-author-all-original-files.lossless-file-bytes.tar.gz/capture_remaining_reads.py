from pathlib import Path
from hashlib import sha256
import subprocess,json
R=Path('/Users/zhouhuanjian/ASTIS-GC')
O=R/'.astis/huanjian-gc-fixed-spectrum-cosine-gram-20261110/source-map-author-1d7a46'
M='.lake/packages/mathlib/Mathlib/'
queries=[
('gla-full','4d229d',['sed','-n','1,115p','AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumGridAlias.lean']),
('gaussian-dual','3a631d',['sed','-n','112,142p',M+'Probability/Distributions/Gaussian/Basic.lean']),
('gaussian-covariance-context','301fb5',['sed','-n','155,235p',M+'Probability/Distributions/Gaussian/Multivariate.lean']),
('kernel-inspector-source','3249f8',['cat','research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-cosine-gram-semantic-evidence/KernelExactTypesAndAllOwnedBounded.lean']),
('generated-integrability-origin','a450c3',['sed','-n','195,220p',M+'Probability/Distributions/Gaussian/Fernique.lean']),
('trig-context','71eab7',['sed','-n','615,680p',M+'Analysis/Complex/Trigonometric.lean']),
('finite-integral-source','bc330b',['sed','-n','235,255p',M+'MeasureTheory/Integral/Bochner/Basic.lean']),
('finite-L1-source','d10385',['sed','-n','435,455p',M+'MeasureTheory/Function/L1Space/Integrable.lean']),
('covariance-definition','03ba27',['sed','-n','35,53p',M+'Probability/Moments/Covariance.lean']),
('CLM-integral-source','9a704a',['sed','-n','60,75p',M+'MeasureTheory/Integral/Bochner/ContinuousLinearMap.lean']),
('Holder-product-source','dbfcf0',['sed','-n','1080,1100p',M+'MeasureTheory/Function/L1Space/Integrable.lean']),
('coefficient-integral-source','15bf96',['sed','-n','280,300p',M+'MeasureTheory/Integral/Bochner/Basic.lean']),
('identity-PSD-source','d96113',['sed','-n','103,121p',M+'LinearAlgebra/Matrix/PosDef.lean']),
('find-finite-and-covariance','9ac81a',['rg','-n','theorem integrable_mul|lemma integrable_mul|theorem integral_comp_comm|lemma integral_comp_comm|theorem integrable_finsetSum|lemma integrable_finsetSum|theorem integral_finsetSum|lemma integral_finsetSum|theorem integral_const_mul|lemma integral_const_mul|def covariance|def proj',M+'MeasureTheory',M+'Probability/Moments',M+'Analysis/InnerProductSpace/PiL2.lean']),
('find-sqrt-and-PSD','8e675b',['rg','-n','sq_sqrt|theorem.*integrable_mul|lemma.*integrable_mul|MemLp.integrable_mul|integrable_fun_id|to_fun integrable_fun_id|PosSemidef.one|theorem one|lemma one',M+'Analysis/Real/Sqrt.lean',M+'MeasureTheory/Function/LpSeminorm',M+'Probability/Distributions/Gaussian/Fernique.lean',M+'LinearAlgebra/Matrix/PosDef.lean']),
('find-generated-namespace','adb0a2',['rg','-n','Integrable.const_mul|theorem const_mul|lemma const_mul|namespace Real|namespace IsGaussian|namespace ProbabilityTheory',M+'MeasureTheory/Function/L1Space/Integrable.lean',M+'Probability/Distributions/Gaussian/Fernique.lean',M+'Analysis/Complex/Trigonometric.lean'])]
records=[]
for name,chunk,argv in queries:
 r=subprocess.run(argv,cwd=R,capture_output=True)
 (O/'logs'/(name+'.stdout')).write_bytes(r.stdout)
 (O/'logs'/(name+'.stderr')).write_bytes(r.stderr)
 records.append({'label':name,'original_chunk':chunk,'argv':argv,'cwd':str(R),'exit_code':r.returncode,'stdout_file':name+'.stdout','stderr_file':name+'.stderr','stdout_sha256':sha256(r.stdout).hexdigest(),'stderr_sha256':sha256(r.stderr).hexdigest(),'captured_as':'real later replay output'})
 assert r.returncode==0
(O/'logs/remaining_query_commands.json').write_text(json.dumps(records,ensure_ascii=False,indent=2)+'\n')
# Original final context query b6b009: exact equivalent block read, saved complete.
parts=[]
for path,a,b in [(M+'Analysis/InnerProductSpace/PiL2.lean',280,294),(M+'Analysis/Normed/Lp/PiLp.lean',1160,1179),(M+'MeasureTheory/Function/L1Space/Integrable.lean',1034,1048),(M+'Probability/Distributions/Gaussian/Multivariate.lean',57,77),(M+'Probability/Distributions/Gaussian/Real.lean',217,227)]:
 parts.append('CONTEXT '+path+' '+str(a)+' '+str(b)+'\n'+''.join((R/path).read_text().splitlines(keepends=True)[a-1:b]))
(O/'logs/final-context-query.stdout').write_text('\n'.join(parts)+'\n')
(O/'logs/final-context-query.stderr').write_bytes(b'')
report={'read_replays':len(records),'all_exit_codes_zero':True,'context_query':'b6b009 complete source contexts preserved','disk_truncation':False}
(O/'logs/capture.stdout').write_text(json.dumps(report)+'\n')
(O/'logs/capture.stderr').write_bytes(b'')
print(json.dumps(report))
