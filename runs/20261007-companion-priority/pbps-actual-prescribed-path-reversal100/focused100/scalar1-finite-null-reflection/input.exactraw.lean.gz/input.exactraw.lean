import Mathlib.MeasureTheory.Integral.IntervalIntegral.Basic

namespace PBPSScalarReflection100
open MeasureTheory Set
open scoped Interval
set_option autoImplicit false

theorem scalar_reflection (T : ℝ) (hT : 0 ≤ T) (f g : ℝ → ℝ)
    (N : Set ℝ) (hN : N.Finite)
    (he : ∀ s ∈ Icc 0 T, s ∉ N → g s = f (T-s))
    (hg : IntervalIntegrable g volume 0 T) :
    IntervalIntegrable f volume 0 T ∧
      (∫ s in (0 : ℝ)..T, g s) = ∫ s in (0 : ℝ)..T, f s := by
  have hae : g =ᵐ[volume.restrict (Ι (0 : ℝ) T)] (fun s => f (T-s)) := by
    filter_upwards [ae_restrict_mem measurableSet_uIoc,
      hN.countable.ae_notMem (volume.restrict (Ι (0 : ℝ) T))] with s hs hn
    rw [uIoc_of_le hT] at hs
    exact he s ⟨hs.1.le, hs.2⟩ hn
  have hi : IntervalIntegrable (fun s => f (T-s)) volume 0 T := hg.congr_ae hae
  have hf : IntervalIntegrable f volume 0 T := by
    simpa using (hi.comp_sub_left T).symm
  refine ⟨hf, ?_⟩
  rw [intervalIntegral.integral_congr_ae_restrict hae]
  simpa using intervalIntegral.integral_comp_sub_left f T (a := (0 : ℝ)) (b := T)

#print axioms scalar_reflection
end PBPSScalarReflection100
