from pathlib import Path
import hashlib,json,datetime,subprocess,sys,re
from bs4 import BeautifulSoup
sys.path.insert(0,'tools');import astis_advance as a
b=Path('.astis/huanjian-fixed-spectrum-determinant-20261108');out=Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-determinant-semantic-evidence');out.mkdir(exist_ok=False)
sha=lambda raw:hashlib.sha256(raw).hexdigest()
def command(*args):return subprocess.check_output(args)
def put(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
head=command('git','rev-parse','HEAD').decode().strip();main=command('git','rev-parse','origin/main').decode().strip();assert head=='ff5ff7f8a6fab5047f6ff89b943b41be320d59fb' and main=='d9bcd4231df69061c5221f8d557ee179a945c1eb';subprocess.run(['git','merge-base','--is-ancestor',main,head],check=True)
states=a.current_advances();assert not [k for k,v in states.items() if v['state']=='STABILIZING'];assert states['ASTIS-SA-20261107-GaussianComplexityFixedSpectrumAdmissibility']['state']=='VERIFIED'
manifest=Path('lake-manifest.json').read_bytes();assert sha(manifest)=='b83ca83b9cf7caa85fa8b023c2ff9a3fb7a7cce7e1c332e810c348535ec49c37';lean=command('lake','env','lean','--version').decode().strip();assert '4.33.0' in lean and 'd8b18978322de05a8f3dba51ef03cf5461676c17' in lean
packages=[]
for row in json.loads(manifest)['packages']:
 repo=Path('.lake/packages')/row['name'];actual=command('git','-C',str(repo),'rev-parse','HEAD').decode().strip();clean=command('git','-C',str(repo),'status','--porcelain','--untracked-files=no').decode();assert actual==row['rev'] and clean=='',row['name'];packages.append({'name':row['name'],'manifest_rev':row['rev'],'actual_HEAD':actual,'tracked_clean':True})
source=Path('.astis/huanjian-resume-20261103/2610.20492v1.html');raw=source.read_bytes();assert sha(raw)=='6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915';soup=BeautifulSoup(raw,'html.parser')
extracts={anchor:soup.find(id=anchor).get_text(' ',strip=True) for anchor in ['S4.E11','S4.Thmtheorem6','A3.SS4']};put(out/'root-selected-source-reading.json',{'source_raw_sha256':sha(raw),'scope':'Root source reading; not an independent sourcegraph or proof. Selected determinant part only; C4 integral normalizer/calculus remain downstream.','extracts':extracts})
names=[]
for root in [Path('AutoSamplingTheory/ExampleCases/GaussianComplexity'),Path('AutoSamplingTheory/TechnicalLemmas/Measure')]:
 for p in sorted(root.glob('*.lean')):
  for m in re.finditer(r'(?m)^(?:private )?(?:noncomputable )?(?:theorem|lemma|def)\s+(\S+)',p.read_text()):
   if any(t in m.group(1).lower() for t in ['det','normaliz']):names.append({'file':str(p),'name':m.group(1)})
assert not any('actual_precision_det'==x['name'] for x in names)
put(out/'name-only-shared-floor-inventory.json',{'method':'Only declaration names emitted; no target-specific API statements/proofs retrieved. Existing generic det_conjStarAlgAut_eq name flagged for exact canonical floor audit after seal/source admission, not yet claimed as proofparent.','names':names,'actual_ASTIS_proof_parents':'not determined; no implementation exists'})
defs=out/'necessary-definition-context';defs.mkdir();detpath=Path('.lake/packages/mathlib/Mathlib/LinearAlgebra/Matrix/Determinant/Basic.lean');grouppath=Path('.lake/packages/mathlib/Mathlib/LinearAlgebra/UnitaryGroup.lean')
for p,lo,hi,label in [(detpath,54,62,'determinant-definition.txt'),(grouppath,285,296,'orthogonal-carrier-alias.txt')]:
 lines=p.read_text().splitlines(keepends=True);(defs/label).write_text(''.join(lines[lo-1:hi]));assert hi<=len(lines)
sig='''theorem actual_precision_det {d : ℕ} (hd : 2 ≤ d)
    {κ : ℝ} (hκ : 2 ≤ κ)
    (O : Matrix.orthogonalGroup (Fin d) ℝ) :
    let θ : Fin d → ℝ := fun i => ((i.val : ℝ) + 1 / 2) * Real.pi / (d : ℝ)
    let diagonalValue : Fin d → ℝ := fun i =>
      (κ + 1) / 2 + (κ - 1) / 2 * Real.cos (θ i)
    let A : Matrix (Fin d) (Fin d) ℝ :=
      (O : Matrix (Fin d) (Fin d) ℝ) * Matrix.diagonal diagonalValue *
        (O : Matrix (Fin d) (Fin d) ℝ).transpose
    A.det = ∏ i : Fin d, diagonalValue i
'''
(out/'candidate-exact-signature.txt').write_text(sig)
prop='∀ '+sig[len('theorem actual_precision_det '):].replace('    (O : Matrix.orthogonalGroup (Fin d) ℝ) :','    (O : Matrix.orthogonalGroup (Fin d) ℝ),',1)
header='''import Mathlib.LinearAlgebra.UnitaryGroup
import Mathlib.LinearAlgebra.Matrix.Determinant.Basic
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Basic
open Matrix
open scoped BigOperators
set_option autoImplicit false
''';(b/'SignatureOnly.lean').write_text(header+'#check (\n'+prop+' : Prop)\n')
put(out/'preseal-binder-definition-and-exposure-audit.json',{'signature_sha256':sha(sig.encode()),'source_anchor':'S4.E11 literal family; A3.SS4 C4 detA=detLambda part underlying known normalizer; not full integral equality.','binder_classes':{'d/hd':'Natural source dimension with exact d>=2 retained; no upper dimension or larged restriction added.','κ/hκ':'Real exact source kappa>=2 retained; no newpositive/coefficient/eigenvalue premise.','O':'Actual full real orthogonal-group element, both determinant signs; NOT specialorthogonal or detO=1 assumption.','θ/diagonalValue/A':'Literal real half-grid and actual same-O diagonal conjugation, local definitions rather than supplied admissibility/identity certificates.'},'definition_senses':['Matrix.det is the genuine finite commutative-ring determinant via detRowAlternating/alternatization, not trace/absolute determinant/singular-value product or a supplied spectral value.','Product is over every Fin d coordinate once; source index i=1,...,d corresponds to zero-based i.val+1. Half and d are real divisions/casts in the displayed grid.','The conclusion is actual precision determinant equal to the explicit diagonal product, independent of O. Determinant invariance and the diagonal product must be internal proved dependencies, not theorem binders.','Full real O(d) uses actual inverse transpose; both determinant signs allowed. No Haar law, algorithm access, cap/error/precision cost or probability assertion is added.'],'real_consumer_plan':'Use this actual determinant value plus existing actual_precision_admissible and the identical canonical GaussianPrecisionDensity law-density theorem in a real same-A N(0,Ainv) Test, giving explicit spectrum-only density coefficient. Seal concrete consumer interface/definitions after producer source admission and before proof/API.','scope_decomposition':'Shrink broad next-source normalizer candidate to one minimal determinant/product packet with genuine density consumer. Full unweighted Lebesgue Gaussian integral/knownZ equality and full C4 calculus/minimizer stay explicit downstream; no normalizer-integral graph parent is silently erased from a combined det+Z source claim.','exposure':'Root read full fixed C4 raw source and exact statements, names-only existing ASTIS inventory, determinant definition lines54-62 and fullorthogonal alias285-296. No currenttarget implementation/proof or target-specific API statement/proof retrieval. Prior packet/source sharedcontext exists and is disclosed; fresh source-only independent roles must reconstruct rawsource before seeing candidate.','definition_lookup_failure':'Initial guessed Determinant/Defs.lean file absent; inventory identified actual Basic.lean. This is a path lookup failure, not mathematics.'})
put(out/'baseline.json',{'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'actual_branch':command('git','branch','--show-current').decode().strip(),'actual_HEAD':head,'latest_actual_fetch_origin_main':main,'main_ancestor_of_preserved_stack':True,'actual_Lean':lean,'manifest_raw_sha256':sha(manifest),'all_packages':packages,'source':str(source),'source_raw_sha256':sha(raw),'prior_locally_accepted_result':'fixed-spectrum-admissibility-integration-20261107/resume-checkpoint.json','actual_STAB':[],'all_old_advance_states':len(states),'all_old_frontier_files':len(list(Path('research-wiki/frontier-cells').glob('*.json'))),'advance_ledger_raw_sha256':sha(Path('runs/substantive_advances.jsonl').read_bytes()),'discovery_ledger_raw_sha256':sha(Path('runs/substantive_discoveries.jsonl').read_bytes()),'remote_owner_readback':'Actual20261108 PR385 OPEN/UNSTABLE unchangedhead5a257960; ownerreleaseunconfirmed; no retry/capwiden/push/merge.','state':'SOURCE_ONLY_UNCLAIMED; only exact signature/meaning prepared, no target proof/API search.'})
print(json.dumps({'actual_baseline':True,'all_packages_verified':len(packages),'signature_sha256':sha(sig.encode()),'target_proof_or_API_search':False,'next':'Signature-only Prop elaboration then seal and independent rawsourcegraph/distinct topology challenge.'}))
