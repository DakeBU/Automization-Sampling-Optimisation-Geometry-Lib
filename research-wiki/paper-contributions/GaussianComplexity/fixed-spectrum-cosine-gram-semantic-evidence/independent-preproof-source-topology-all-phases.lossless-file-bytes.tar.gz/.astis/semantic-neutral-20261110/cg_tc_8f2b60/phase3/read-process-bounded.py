from pathlib import Path
import hashlib
import json
import sys

base=Path(__file__).resolve().parent
mode=sys.argv[1]
options={
 'history':['W/preseal-planning.json','W/additional-preseal-source-role-exposure.json','W/postseal-informal-planning.json'],
 'formation':['W/actual-environment-at-seal.json','W/StatementFormation.raw.lean.txt','W/statement-formation.json'],
 'seal':['W/statement-seal-v1.json'],
 'seal-script':['W/seal_statements.py'],
 'reserve-script':['W/reserve_frontier_no_intake.py'],
 'prepare-script':['W/prepare_normal_intake.py'],
 'admit-script':['W/admit_normal_intake_prepared.py'],
 'C':['C.json'],
 'safe':['W/prepared-intake-safe-summary.json','private-hash-schema-count-checks.json']
}
out=[]
for name in options[mode]:
    b=(base/name).read_bytes()
    out.append('INPUT '+name+' rawSHA256 '+hashlib.sha256(b).hexdigest()+'\n'+b.decode())
stdout='\n\n'.join(out)+'\n';(base/('read-process-'+mode+'.stdout.txt')).write_text(stdout);print(stdout,end='')
