# Raw-first source cognition — phase 1, before candidate or decoder exposure

This is my independent source reconstruction, not a Lean verification, a verdict
on an unseen implementation, or approval of full Lemma 4.4. I have seen the
task's descriptive component names and selected scope, but no candidate Lean
signature, code, API, source graph, semantic audit, decoder, or another role's
result. General pretrained mathematical knowledge cannot be excluded; I make
no claim of pristine or zero-prior cognition.

The only mathematical source read is *On Complexity of Gaussian Sampling*,
arXiv:2610.20492v1, pinned HTML, 951991 bytes,
SHA256 `6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915`.
No internet or external bibliography item was consulted. The permitted process
documents were read as process instructions, not as mathematical evidence.
Original input and exact UTF-8 byte slices are retained. Byte intervals below
are zero-based, end-exclusive; line numbers are one-based. `source_spans.json`
and `all_C2_math.json` pin paragraph, display-container and math@alttext locators.
BeautifulSoup renderings are explicitly derivatives, not original byte slices.

## 1. Source objects, carriers, quantifiers, normalizations

1. The spectral grid is defined in `S4.SS1.p1` (bytes [204560,209900), lines
   1085–1102; source display (11)). For natural dimension d≥2 and κ≥2,
   θ_i=(i−1/2)π/d, λ_i=(κ+1)/2+(κ−1)cos(θ_i)/2,
   Λ=diag(λ_1,…,λ_d), with **i=1,…,d**. If a future encoding indexes from zero,
   θ_i must become (i+1/2)π/d. The grid is the interior half-grid, not integer
   multiples of π/d and not endpoints 0 and π.
2. `S4.SS2.SSS0.Px1.p2` (bytes [220995,223561), lines 1151–1160) defines
   K_q(g_1,…,g_{q+1})=span{Λ^j g_a : 1≤a≤q+1, 0≤j≤q}.
   The Gaussian row/frame results below do not need κ; κ enters range=Krylov.
3. `S4.SS2.SSS0.Px2.p1` (bytes [229463,232225), lines 1193–1206) sets
   n=2q+1 and D_n=diag(cos(nθ_1),…,cos(nθ_d)). The weight is cosine, with
   no √2 multiplier and no expectation normalization.
4. `S4.Thmtheorem4` is **Lemma 4.4**, not a theorem numbered 4.
   It asserts ∃ absolute C>0, uniformly in integer query budget q≥0,
   dimension d with 2q+1<d, and independent g_1,…,g_{q+1}~N(0,I_d).
   Write K_q as defined above and
   τ=C[(q+1)√(log(d)/d)+(q+1)(q+1+log(d))log(d)/d].
   If τ≤1/2, then with probability ≥0.99, simultaneously for **all** u∈K_q,
   |uᵀD_nu|≤2τ||u||². C is selected before d,q and the realization; it is
   not allowed to depend on those. The event is uniform in u, not a separate
   event for each fixed u. Span and norms are real Euclidean ones.
5. C.2 starts at `A3.SS2`, bytes [738696,864820), lines 3314–3836.
   `A3.SS2.p1`/`A3.Ex85` define r=q+1, n=2q+1 and
   t_i=(1,√2 cos θ_i,…,√2 cos(qθ_i))ᵀ∈R^r,
   γ_i=((g_1)_i,…,(g_r)_i)ᵀ∈R^r, for 1≤i≤d.
   Coordinates of t are j=0,…,q: **t_{i,0}=1**; √2 applies only for j≥1.
   B∈R^{d×r²} has row d^(−1/2)(γ_i⊗t_i)ᵀ.
   The tensor order is Gaussian coordinate first, cosine coordinate second.
   With paired column indices (a,j), B_{i,(a,j)}=γ_{i,a}t_{i,j}/√d.
   The source says γ_1,…,γ_d are independent N(0,I_r). This follows from the
   actual independent standard Gaussian input vectors, not an arbitrary array
   merely named Gaussian.

The source assumption 2q+1<d implies d≥2, r≥1, 2r≤d, and
4q+1<2d. It includes q=0: t_i=(1), r=n=1, and d≥2. τ≤1/2 is required
for the final uniform bound; it is **not** required for Fact C.5's deterministic
identities or its Gaussian means. Neither probability 0.99 nor concentration
appears in those deterministic identities.

## 2. Exact Fact C.5 content and its source proof

`A3.Thmtheorem5`, bytes [746809,751148), lines 3340–3360, is **Fact C.5**.
Its statement is not limited to the three deterministic assertions. It asserts:

* range(B)=K_q;
* E[BᵀB]=I_{r²}; E[BᵀD_nB]=0;
* ||t_i||²≤2r for every row i;
* Σ_{i=1}^d t_it_iᵀ=d I_r;
* Σ_{i=1}^d cos(nθ_i)t_it_iᵀ=0.

The sums in the last two displays are **unnormalized**. Dividing by d yields
I_r or 0. A normalized frame may encode this equivalently, but an identity
with an unnormalized t and sum equal to I_r would change the source.

The full proof is `A3.SS2.2`, bytes [751149,791243), lines 3361–3508:

1. `A3.SS2.p3` (range identity, lines 3363–3376) uses Chebyshev
   cos(jθ)=T_j(cos θ) and the nonconstant affine relation between λ and cos θ.
   For each Gaussian column a, changing from cos(jθ_i)(g_a)_i to Λ^j g_a
   is triangular and invertible for 0≤j≤q. Nonzero d^(−1/2), √2
   column scalings preserve range. This is a distinct mathematical obligation.
2. `A3.SS2.p4` / display group `A3.EGx5` (lines 3377–3396) proves the
   discrete cosine cancellation for **integer k** with 0<|k|<2d:
   2 sin(kπ/(2d)) Σ_i cos(kθ_i)
   =Σ_i[sin(kiπ/d)−sin(k(i−1)π/d)]
   =sin(kπ)−sin(0)=0.
   The prefactor is nonzero exactly under the stated restricted integer
   frequency range; cancellation cannot just divide by it at k=0 or ±2d.
3. `A3.SS2.p5` / `A3.Ex90`, `A3.EGx6` (lines 3397–3432) treats the
   constant coordinate separately: Σ_i t_{i,0}²=d and
   Σ_i t_{i,0}t_{i,j}=√2 Σ_i cos(jθ_i)=0 for 1≤j≤q.
   For 1≤j,k≤q, product-to-sum yields
   Σ_i t_{i,j}t_{i,k}=Σ_i cos((j−k)θ_i)+Σ_i cos((j+k)θ_i).
   When j=k the first sum is d; otherwise it is zero. The second is zero
   because 0<j+k≤2q<2d. Symmetry covers all entries, so Σ_i t_it_iᵀ=dI_r.
4. `A3.SS2.p6` / `A3.EGx7` (lines 3433–3449) invokes
   E[γ_iγ_iᵀ]=I_r and the row formula to obtain
   E[BᵀB]=(1/d)Σ_i(E[γ_iγ_iᵀ]⊗t_it_iᵀ)
   =(1/d)(I_r⊗Σ_i t_it_iᵀ)=I_{r²}.
5. `A3.SS2.p7` / `A3.Ex96`, `A3.EGx8`, `A3.EGx9` (lines 3450–3496)
   proves the weighted cancellation and weighted mean. For 0≤j,k≤q,
   all four frequencies n±j±k satisfy
   1≤n−j−k≤n±j±k≤n+j+k≤4q+1<2d.
   Triple product-to-sum gives
   Σ_i cos(nθ_i)cos(jθ_i)cos(kθ_i)
   =(1/4)Σ_i[cos((n+j+k)θ_i)+cos((n+j−k)θ_i)
             +cos((n−j+k)θ_i)+cos((n−j−k)θ_i)]=0.
   This holds also when j=0 or k=0, because cos(0)=1; the entries of t
   merely introduce fixed factors 1,√2,2. Thus the weighted deterministic
   matrix sum is zero. The same Gaussian second-moment computation gives
   E[BᵀD_nB]=(1/d)(I_r⊗Σ_i cos(nθ_i)t_it_iᵀ)=0.
6. `A3.SS2.p8` / `A3.Ex102` (lines 3497–3507) concludes
   ||t_i||²=1+2Σ_{j=1}^q cos²(jθ_i)≤1+2q≤2r.
   This is a bound on the deterministic cosine vector t_i, not a pointwise
   uniform bound on the Gaussian vector γ_i or on the full random B row.
   Squared Euclidean norm means sum of coordinate squares.

The strict upper frequency restriction is substantive. At k=0, the cosine
sum is d; at k=2d, cos(2dθ_i)=−1 so the sum is −d. A future encoding using
a ≤2d cancellation endpoint would be false. The source's 2q+1<d is sufficient
and need not be weakened to whatever a particular deterministic sublemma can
support in isolation. q=0 remains valid without a positive-mode coordinate.

## 3. Real Gaussian means: hidden analytic dependencies to discharge internally

The source uses genuine Gaussian expectations, not an abstract moment axiom
assumed by a public source theorem. In coordinates a,b=1,…,r, j,k=0,…,q:

  (BᵀB)_{(a,j),(b,k)}
    =(1/d)Σ_i γ_{i,a}γ_{i,b} t_{i,j}t_{i,k},
  (BᵀD_nB)_{(a,j),(b,k)}
    =(1/d)Σ_i cos(nθ_i)γ_{i,a}γ_{i,b}t_{i,j}t_{i,k}.

For standard Gaussian γ_i, Eγ_{i,a}=0 and Eγ_{i,a}²=1. For a≠b,
independence of the Gaussian coordinates gives E[γ_{i,a}γ_{i,b}]=0;
for a=b the value is 1. Therefore Eγ_{i,a}γ_{i,b}=δ_ab.
These are the actual inputs to the two matrix mean computations. Independence
between different rows is part of the source model and needed later for C.6,
but the mean identities themselves use only each row's covariance identity.

Measurability and integrability are implicit analytic obligations of the source
expectation notation. Gaussian coordinates are measurable with finite second
moments. Their product is integrable, for example because
|xy|≤(x²+y²)/2 (or Cauchy–Schwarz), hence E|γ_{i,a}γ_{i,b}|≤1.
This product-integrability argument does **not** require a≠b and does not need
independence. Multiplication by the finite deterministic t coefficients, by
cos(nθ_i), and by 1/d preserves integrability. Finite sums preserve it, and
finite-dimensional matrix-valued integrability follows entrywise.
Thus every entry of BᵀB and BᵀD_nB is integrable before exchanging finite
sum/scalar multiplication and expectation. The normalizations are valid
because d>0. Products are polynomials of Gaussian coordinates; no regularity,
domination, unknown finite-moment premise, or covariance premise needs to be
added to the source statement.

After these analytic obligations, the entrywise expectations are respectively
δ_ab·(1/d)Σ_i t_{i,j}t_{i,k}=δ_abδ_jk and
δ_ab·(1/d)Σ_i cos(nθ_i)t_{i,j}t_{i,k}=0.
The identity has r² coordinates, with matching tensor-pair indexing; a hidden
permutation must be accounted for explicitly if a different index order is used.
A generic algebraic theorem conditional on supplied second moments can be a
private intermediate, but genuine source completion of the means requires
the standard Gaussian law to produce those moments and integrability itself.
The existence of a producer does not justify adding its conclusions as new
public assumptions. A totalized integral returning a default value on a
nonintegrable function cannot certify these real expectations.

These integrability explanations are my elementary reconstruction of background
steps omitted in `A3.SS2.p6` and p7, not a claim that the source spells them out
or that a particular Lean lemma/API has been verified.

## 4. Complete C.2 coverage and remaining boundary

The complete C.2 prose and all math were read in `C2-full-text.stdout`. The
source contains 167 math elements, of which 28 have display="block"; display
groups may contain several math rows, so display containers and block-math
counts must not be confused. `all_C2_math.json` preserves every original
math@alttext and locator. `source_spans.json` inventories paragraph and
equation/group byte slices, including the complete proofs below.

| Source region | Source role | Present completion scope |
|---|---|---|
| C.2 p1–p2, Ex85 | Definitions and strategy | Objects audited here; no implementation seen |
| C.5 statement, Ex86–Ex87 | All six assertions | Only three deterministic assertions plus two Gaussian means are the stated upcoming comparison scope |
| p3 | range(B)=K_q via Chebyshev change of basis | Separate open obligation; no completion claim |
| p4–p5, EGx5/Ex90/EGx6 | Cosine cancellation and deterministic Gram | Source cognition frozen for later comparison |
| p6, EGx7 | Gaussian ordinary Gram mean | Source cognition plus integrability obligations frozen |
| p7, Ex96/EGx8/EGx9 | Weighted cancellation and Gaussian weighted mean | Source cognition plus integrability obligations frozen |
| p8, Ex102 | Deterministic row-square bound | Source cognition frozen |
| p9 | Transition to operator-norm deviations | Read as full-proof context; not supplied by the means |
| C.6 statement, Ex103 | Simultaneous concentration ≥0.995 | Separate open obligation |
| p10–p11, Ex104/105, EGx10 | Gaussian χ²/MGF truncation and tail integral | Separate open analytic obligations |
| p12–p13, Ex107–Ex112 | Truncated matrices, radial symmetry, bias and centered summand bounds | Separate open obligations |
| p14, Ex113/114, EGx11, Ex118–120 | Fourth moments and semidefinite variance estimates | Separate open obligations |
| p15–p17, Ex121–126 | Matrix Bernstein, Δ, union bound, undo truncation | Separate open obligations |
| p18, EGx12 | Absolute-constant simplification to τ | Separate open obligation |
| Final Lemma 4.4 proof p19, Ex129/EGx13/Ex132 | Combine range, two concentration bounds, τ≤1/2 | Full lemma remains open |

C.6's proof uses L=2r+3log(1000d), R_i=||γ_i||²,
E exp(R_i/3)=3^(r/2), P(R_i>2r+3x)≤e^(−x), the simultaneous truncation
event with probability ≥0.999, and a tail-integral bias ≤(L+3)/(1000d).
Radial symmetry supplies E[γ_iγ_iᵀ1_{R_i≤L}]=aI_r with the same a for all i,
0≤a≤1 and 1−a≤(L+3)/(1000rd). Centered truncated summands have norm bound
R_*=2r(L+1)/d. Gaussian fourth moments give E[R_iγ_iγ_iᵀ]=(r+2)I_r,
and C.5 gives variance bound v_*=2r(r+2)/d. Two-sided bounded matrix
Bernstein in dimension r² is invoked with failure bound
2r² exp(−t²/[2(v_*+R_*t/3)]). This is external background stated without a
nearby citation in C.2, not a consequence of the deterministic or mean identities.
With z=log(1000r²), Δ=√(2v_*z)+2R_*z/3, each failure is ≤0.002;
union and truncation losses produce probability ≥0.995. With absolute constants,
Δ+(1−a)≤c[r√(log d/d)+r(r+log d)log d/d]. These are read, not proved here.

Finally the full lemma uses range(B)=K_q to write u=Bc on the same event, gets
||u||²≥(1−τ)||c||² and |uᵀD_nu|≤τ||c||², then uses τ≤1/2 to obtain
τ/(1−τ)≤2τ. The universal quantifier over c makes the event simultaneous
for all u. The stronger achieved probability 0.995 implies the stated 0.99.
The three deterministic facts and Gaussian means alone do not supply this.

External/background inputs visible from this source reading are elementary
trigonometry and finite telescoping, the Chebyshev polynomial identity and
nonzero leading coefficient (range identity), actual standard Gaussian second
moments and elementary L²→product-L¹ reasoning (means), Gaussian MGF/radial
symmetry/fourth moments, tail integration, operator-norm/PSD algebra, bounded
matrix Bernstein, and elementary probability union bounds (C.6).
I did not inspect external references or local implementations for any of them.
The deferred-rotation citation [22, Lemma 9.2] belongs to the adjacent Krylov
representation lemma, outside this comparison and this completion boundary.

## 5. Phase boundary

This file must be frozen before any candidate/selective-type/decoder exposure.
Future comparisons should report differences against these raw-first objects,
all seven semantic slots (objects, domains, quantifiers, assumptions, conclusion,
normalization/constants, and dependency/boundary), and the exact immutable code
actually received. No candidate decision has been made in phase 1.
