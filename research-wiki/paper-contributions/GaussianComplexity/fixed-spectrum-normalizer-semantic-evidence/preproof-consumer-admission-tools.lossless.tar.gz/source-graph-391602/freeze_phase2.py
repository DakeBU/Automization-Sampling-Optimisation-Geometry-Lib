from pathlib import Path
from datetime import datetime, timezone
import hashlib, json

ROOT=Path('/Users/zhouhuanjian/ASTIS-GC')
PRIVATE=ROOT/'.astis/huanjian-fixed-spectrum-normalizer-20261108/source-graph-391602'
PHASE1=ROOT/'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-normalizer-semantic-evidence/source-only-review/phase1'
OUT=PHASE1/'phase2-overlay-v1'
OUT.mkdir(parents=True,exist_ok=True)
(OUT/'necessary-meaning-excerpts').mkdir(exist_ok=True)
EVIDENCE=ROOT/'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-normalizer-semantic-evidence'
sha=lambda b:hashlib.sha256(b).hexdigest()
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def describe(p):
 b=p.read_bytes();return {'path':str(p.relative_to(ROOT)),'sha256':sha(b),'bytes':len(b)}
now=datetime.now(timezone.utc).isoformat()
base_manifest=PHASE1/'manifest.json'
assert sha(base_manifest.read_bytes())=='bb527878ab86ded101b8b619a2ab770c43ac1247bdd1790f67eeb258415a5512'
base=json.loads(base_manifest.read_text())
for f in base['files']:
 assert sha((ROOT/f['path']).read_bytes())==f['sha256'],f['path']

seal_path=ROOT/'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-normalizer-statement-seal.json'
sig_path=EVIDENCE/'candidate-exact-signature.txt'
audit_path=EVIDENCE/'preseal-binder-definition-and-exposure-audit.json'
assert sha(seal_path.read_bytes())=='3b3c752a771f2d5481c4708f9f4821494c5598cbe48363ad91d0b9061f4127a2'
assert sha(sig_path.read_bytes())=='3e2c0dd72fce0a272a73b4ee7d8447cde4e6ce313f7a5ccda80744f8dc8fa7f0'
assert sha(audit_path.read_bytes())=='61d13768818fa3b04105093c2e6db7549a6923bdeed50f98d63331e9a54ce1e7'
seal=json.loads(seal_path.read_text());signature=sig_path.read_text();root_audit=json.loads(audit_path.read_text())
assert signature==seal['exact_signature_utf8']
for x in root_audit['necessary_definition_raw_windows']:
 assert sha((ROOT/x['excerpt']).read_bytes())==x['excerpt_raw_sha256']

meaning_file=ROOT/'.lake/packages/mathlib/Mathlib/MeasureTheory/Measure/Haar/OfBasis.lean'
meaning_raw=meaning_file.read_bytes();meaning_lines=meaning_raw.splitlines(keepends=True)
meaning_windows=[]
for a,b,name,role in [
 (310,313,'Euclidean-volume-instance.raw.txt','necessary definition: volume is addHaar of standard orthonormal basis'),
 (251,257,'Basis-addHaar-definition.raw.txt','necessary definition: basis Lebesgue normalization by unit parallelepiped'),
 (305,317,'incidental-volume-window-305-317.raw.txt','exact read window: includes preceding normalization comment tail and neighboring generic IsAddHaar instance; not used as a Gaussian proof')]:
 raw=b''.join(meaning_lines[a-1:b]);p=OUT/'necessary-meaning-excerpts'/name;p.write_bytes(raw)
 meaning_windows.append({'source_file':str(meaning_file.relative_to(ROOT)),'source_file_raw_sha256':sha(meaning_raw),'line_start':a,'line_end':b,'excerpt':str(p.relative_to(ROOT)),'excerpt_sha256':sha(raw),'role':role})

slot_comparisons=[
 {'slot':'objects','frozen_source_nodes':['N.theta','N.lambda','N.diagonal','N.rotation','N.quadratic','N.actual-integral'],
  'candidate':'Literal lets θ, diagonalValue, A and weight; integral over actual EuclideanSpace.',
  'analysis':'The vector sum Σ_i x.ofLp_i*(A.mulVec x.ofLp)_i is xᵀAx. Weight is exp(−xᵀAx/2), with no additive shift, normalization factor, chosen proxy or assumed certificate.',
  'judgment':'MATCH'},
 {'slot':'domains','frozen_source_nodes':['N.grid-domain','N.orthogonal'],
  'candidate':'d:ℕ, 2≤d; κ:ℝ, 2≤κ; O:Matrix.orthogonalGroup(Fin d) ℝ; x:EuclideanSpace ℝ (Fin d); volume.',
  'analysis':'Source one-based i=1,…,d is encoded by j:Fin d via i=j.val+1. Then i−1/2=j.val+1/2. The resolved measureSpaceOfInnerProductSpace volume is the Lebesgue measure of the standard orthonormal basis, whose unit parallelepiped has measure1. WithLp.ofLp is the coordinate view self.1. No Gaussian probability measure is substituted.',
  'judgment':'MATCH_WITH_DISCLOSED_SOURCE_IMPLICIT_LEBESGUE_CONVENTION'},
 {'slot':'quantifiers','frozen_source_nodes':['N.grid-domain','N.rotation','N.admissibility'],
  'candidate':'Universally quantified d,κ satisfying the two source lower bounds and every full real orthogonal O.',
  'analysis':'No determinant-one, Haar-almost-everywhere, algorithm-seed, upper-κ, sufficiently-large-d or ε qualification is added. The formula has no O on its RHS, so universal exact equality yields O-invariance.',
  'judgment':'MATCH'},
 {'slot':'assumptions','frozen_source_nodes':['N.grid-domain','N.orthogonal'],
  'candidate':'Only hd:2≤d, hκ:2≤κ and O in the full real orthogonal group, with d/κ carriers.',
  'analysis':'No supplied PD/admissibility, determinant identity, positive product, normalizer value, integrability, density or proof certificate occurs. These remain derived edges. Let-bound formulas are definitions, not additional hypotheses.',
  'judgment':'MATCH_NO_EXCESS_FOUND'},
 {'slot':'conclusion','frozen_source_nodes':['N.normalizer-detA','N.normalizer-detLambda','N.diagonal-product','N.actual-integral','N.finite-positive-mass'],
  'candidate':'Integrable weight volume ∧ actual Bochner integral = (2π)^((d:ℝ)/2)/sqrt(∏ diagonalValue).',
  'analysis':'Integrable is an output making the finite Gaussian-mass sense explicit. The formula follows from C4 detΛ^(−1/2) through determinant-of-diagonal and positive inverse-square-root identities. It is a faithful elaboration under the disclosed normalizer convention, not a verbatim source integral statement. The conjunction prevents the Bochner nonintegrable-zero branch from substituting for finite-mass content.',
  'judgment':'MATCH_AS_SOURCE_IMPLICIT_ELABORATION'},
 {'slot':'scopes_senses','frozen_source_nodes':['N.public-known','N.independent-O','G.integral-convention','G.real-half-powers'],
  'candidate':'Actual unweighted Euclidean-Lebesgue integral, real exponent, positive square-root denominator derived internally.',
  'analysis':'Real division ((d:ℝ)/2) handles odd dimensions. Since d≥2 and all λ_i>1, the product is positive and sqrt is nonzero; the candidate does not add these as assumptions. The theorem gives the value supporting the source known-normalizer statement, without encoding an algorithmic knowledge predicate, precision guarantee or evaluation cost.',
  'judgment':'MATCH_WITH_BOUNDARY_PRESERVED'},
 {'slot':'constant_dependencies','frozen_source_nodes':['N.fixed-spectrum','N.independent-O','N.public-known'],
  'candidate':'RHS depends only on d, κ through the fixed grid/eigenvalues; it is independent of O and any seed.',
  'analysis':'No δ, d0(δ), ε, TV tolerance, query budget, expected cost or numerical precision enters. Theorem4.1 scopes and Section4.4 limitations remain excluded.',
  'judgment':'MATCH'}
]

binder_audit={
 'schema':'astis-independent-candidate-binder-definition-overlay/v1','status':'source-only comparison; not sourceV, proof or topology acceptance',
 'candidate_signature_sha256':sha(sig_path.read_bytes()),'phase1_manifest_sha256':sha(base_manifest.read_bytes()),
 'binders':[
  {'syntax':'{d : ℕ}','class':'TYPING','reason':'Finite integer source dimension; source restriction separately supplied by hd.'},
  {'syntax':'(hd : 2 ≤ d)','class':'SOURCE','anchor':'S4.SS1.p1.1'},
  {'syntax':'{κ : ℝ}','class':'TYPING','reason':'Real spectral condition parameter.'},
  {'syntax':'(hκ : 2 ≤ κ)','class':'SOURCE','anchor':'S4.SS1.p1.1'},
  {'syntax':'(O : Matrix.orthogonalGroup (Fin d) ℝ)','class':'SOURCE','anchors':['S4.SS1.p1.2','S4.Thmtheorem6'],'reason':'Full real orthogonal group; no determinant sign restriction and no random-law assumption.'}],
 'STANDING':['Real Euclidean/centered-Gaussian convention from S2; unweighted normalizer interpretation explicitly inferred rather than quoted.'],
 'RULED':[],'EXCESS':[],'project_owned_assumption_bundles':[],
 'definitions':[
  {'syntax':'θ','kind':'literal','meaning':'((j.val:ℝ)+1/2)π/(d:ℝ)','audit':'Exact Eq11 under one-based index shift. d>0 follows from hd; no extra premise.'},
  {'syntax':'diagonalValue','kind':'literal','meaning':'(κ+1)/2+(κ−1)cosθ/2','audit':'Exact Eq11; κ≥2 yields positive affine coefficient and λ∈(1,κ) inside the proof.'},
  {'syntax':'A','kind':'literal','meaning':'O * Matrix.diagonal diagonalValue * O.transpose','audit':'Same real orthogonal rotation/transpose as source, no replacement by a determinant or characterized witness.'},
  {'syntax':'weight','kind':'literal','meaning':'Real.exp(−Σ_j x.ofLp_j*(A.mulVec x.ofLp)_j /2)','audit':'Literal unshifted quadratic exponential on every Euclidean x under the public source d/κ/O domain. No fallback or normalizer-defined weight.'},
  {'syntax':'EuclideanSpace ℝ (Fin d)','kind':'standard-carrier-meaning','audit':'Supplied exact definition is PiLp2 of d real coordinates; ofLp is inherited coordinate view self.1.'},
  {'syntax':'volume','kind':'standard-measure-meaning','audit':'Resolved to measureSpaceOfInnerProductSpace; raw definition is standard orthonormal-basis addHaar, whose basis parallelepiped has measure1. This is Euclidean Lebesgue volume.'},
  {'syntax':'Integrable weight volume','kind':'output-predicate','audit':'Raw definition is AEStronglyMeasurable ∧ HasFiniteIntegral. It is concluded, not assumed.'},
  {'syntax':'∫ weight ∂volume','kind':'standard-integral-meaning','audit':'Actual real Bochner integral; its fallback for nonintegrable functions is not exploited because output includes Integrable.'},
  {'syntax':'^ ((d:ℝ)/2), Real.sqrt product','kind':'standard-real-arithmetic-meaning','audit':'Real half-dimension, including odd d; positive base/product domains must be derived. Built-in total sqrt outside positive values creates no off-source theorem premise or project fallback.'}],
 'unseen_and_unreviewed':['Any production theorem/proof, Tests consumer statement/proof, ancestor project Lean, target proof API, proof search, prior reviews and challenger rationale.'],
 'consumer_boundary':'The real Gaussian-density consumer is planned/unsealed/unproved and has a separate gate. This audit makes no claim about it.'
}

new_nodes=[
 {'id':'P.index-shift','kind':'SOURCE_GAP','statement':'Relate Fin d index j to source i=j.val+1; transport the literal grid, product and full finite sums.','source_use_site':'S4.E11','candidate_use_site':'θ and diagonalValue lets'},
 {'id':'P.coordinate-quadratic','kind':'SOURCE_GAP','statement':'Expand real Matrix.mulVec and finite coordinate pairing; Σ x_i(Ax)_i=xᵀAx, so the exact candidate weight equals the source unnormalized quadratic weight.','source_use_site':'S2 quadratic / A3.SS4.p2.1','candidate_use_site':'weight let'},
 {'id':'P.euclidean-volume','kind':'meaning-adapter','statement':'The candidate volume is standard Euclidean Lebesgue volume through the resolved orthonormal-basis measure instance; this explicitly realizes the phase1 source-implicit convention.','source_use_site':'A3.Ex160 (implicit normalizer convention)','candidate_use_site':'explicit volume in both output conjuncts'},
 {'id':'P.literal-weight','kind':'sealed-definition-meaning','statement':'Exact candidate let-weight means exp(−xᵀAx/2) on actual Euclidean coordinates.','candidate_use_site':'weight let'},
 {'id':'P.integral-meaning','kind':'sealed-conclusion-meaning','statement':'Candidate Bochner integral is the actual inferred source Lebesgue Gaussian mass.','candidate_use_site':'integral equality conjunct'},
 {'id':'P.integrable-output','kind':'sealed-endpoint-obligation','statement':'AEStronglyMeasurable weight volume ∧ HasFiniteIntegral weight volume. Must be produced from source inputs, not added as premise.','source_use_site':'A3.SS4.p3.1 / A3.Ex160 Gaussian integration','candidate_use_site':'first output conjunct'},
 {'id':'P.product-positive','kind':'derived-bridge-obligation','statement':'The finite product of literal λ_i is positive (indeed every λ_i>1); sqrt(product)>0.','source_use_site':'A3.SS4.p1.1 and A3.Ex160','candidate_use_site':'sqrt denominator'},
 {'id':'P.power-product-sqrt','kind':'SOURCE_GAP','statement':'For positive finite spectrum, detΛ=∏λ and (2π)^(d/2)(detΛ)^(−1/2)=(2π)^((d:ℝ)/2)/sqrt(∏λ); interpret real division and positive roots.','source_use_site':'A3.Ex160 with S4.E11','candidate_use_site':'exact RHS'},
 {'id':'P.value-output','kind':'sealed-endpoint-obligation','statement':'Actual integral equals (2*Real.pi)^((d:ℝ)/2)/Real.sqrt(∏ diagonalValue).','source_use_site':'A3.Ex160','candidate_use_site':'second output conjunct'},
 {'id':'P.sealed-endpoint','kind':'exact-sealed-Prop','statement':signature,'signature_sha256':sha(sig_path.read_bytes()),'candidate_use_site':'whole proposition'}
]
overlay_edges=[
 {'id':'P.E01','operator':'AND','inputs':['N.theta','N.lambda','N.diagonal','N.rotation','N.quadratic','P.index-shift','P.coordinate-quadratic'],'output':'P.literal-weight','consumer_use_site':'candidate weight let / source S2 quadratic'},
 {'id':'P.E02','operator':'AND','inputs':['N.actual-integral','G.integral-convention','P.literal-weight','P.euclidean-volume'],'output':'P.integral-meaning','consumer_use_site':'candidate explicit ∂volume at actual integral'},
 {'id':'P.E03','operator':'AND','inputs':['N.symmetry','N.admissibility','P.literal-weight','P.integral-meaning','G.gaussian-integration'],'output':'P.integrable-output','consumer_use_site':'first output conjunct; source A3.SS4.p3.1','conditional_discharge':['SPD comes from actual symmetry and I≼A, not a candidate assumption.','Gaussian integration must provide measurability and finite integral.']},
 {'id':'P.E04','operator':'AND','inputs':['N.eigenvalue-bounds','N.diagonal-product','P.index-shift','G.det-diagonal'],'output':'P.product-positive','consumer_use_site':'candidate square-root denominator','conditional_discharge':['All λ_i>1 follow internally from the source grid; d is finite and ≥2.']},
 {'id':'P.E05','operator':'AND','inputs':['N.normalizer-detLambda','N.diagonal-product','P.product-positive','P.integral-meaning','G.real-half-powers','P.power-product-sqrt'],'output':'P.value-output','consumer_use_site':'second output conjunct; source A3.Ex160','conditional_discharge':['N.normalizer-detLambda must retain its phase1 E11→E12→E13 source closure: Gaussian integration, determinant conjugation, substitution.','2π>0; productλ>0; square root nonzero; real d/2, all internally established.']},
 {'id':'P.E06','operator':'AND','inputs':['P.integrable-output','P.value-output'],'output':'P.sealed-endpoint','consumer_use_site':'top-level conjunction','conditional_discharge':['Both conjuncts are proof obligations, never alternative OR routes and never premises.']}
]
overlay={
 'schema':'astis-source-graph-candidate-overlay/v1','version':'phase2-overlay-v1','status':'frozen source/statement mapping; no implementation or sourceV approval',
 'base_graph_sha256':sha((PHASE1/'source-proof-graph.json').read_bytes()),'base_contract_sha256':sha((PHASE1/'source-contract.json').read_bytes()),'base_coverage_sha256':sha((PHASE1/'coverage-inventory.json').read_bytes()),'base_graph_unchanged':True,
 'candidate_signature_sha256':sha(sig_path.read_bytes()),'nodes':new_nodes,'hyperedges':overlay_edges,
 'source_closure_required':[
  {'endpoint':'P.integrable-output','base_source_branch':['N.grid-domain','N.theta','N.lambda','N.diagonal','N.rotation','N.symmetry','N.admissibility','G.gaussian-integration','G.integral-convention'],'meaning':'Actual Gaussian integration must establish finite mass and measurability; no certificate assumption.'},
  {'endpoint':'P.value-output','base_source_branch':['N.normalizer-detA','N.det-invariance','N.normalizer-detLambda','N.diagonal-product','G.gaussian-integration','G.det-conjugation','G.det-diagonal','G.real-half-powers'],'meaning':'Actual integral value, determinant invariance, diagonal product and positive-root arithmetic stay distinct. Value must not be reduced to a normalizer-defined proxy.'}],
 'and_or_semantics':'No source alternative route has been added. Every overlay hyperedge is sufficient AND, and the exact endpoint is the AND of finite integrability and value. Optional source product representation becomes necessary only for this exact product/sqrt presentation; it is not retroactively made a premise of the source detA formula.',
 'explicit_exclusions':[
  {'source_nodes':['N.smooth-hessian','N.convex-smooth','N.coercivity-zero','N.unique-minimizer'],'reason':'Covered in phase1 full C4 inventory; not conclusions of this bounded producer. A proof route may reuse established generic Gaussian ingredients without this becoming whole-C4 completion.'},
  {'source_nodes':['N.target'],'reason':'The source target identifies the potential/normalizer convention. This producer does not construct a probability measure or prove a normalized density/target-law identity.'},
  {'source_nodes':['N.public-known'],'reason':'The exact O-independent value supports the information statement; no public-spectrum algorithm, numerical precision or cost theorem is supplied.'},
  {'source_regions':['S4.Thmtheorem1','S4.SS4'],'reason':'All main-bound ranges, Krylov/statistic/concentration/TV/query lower bounds and proof limitations remain phase1 EXCLUDED scope context.'},
  {'source_regions':['S2 oracle/randomized algorithms/TV/query complexity'],'reason':'Actual oracle, adaptive/precision, deterministic or expected-cost adapters and algorithm guarantees are not admitted here.'},
  {'object':'planned actual Gaussian-density consumer','reason':'Unsealed and unproved; separate exact-statement/definition/source gate remains required.'}],
 'coverage_result':'The sealed endpoint maps to the selected Gaussian-integration subcomponent with disclosed inference and added explicit output finiteness. It does not cover all C4 or the paper. No phase1 item is relabeled, removed, or self-approved.'
}

comparison={
 'schema':'astis-independent-seven-slot-comparison/v1','freeze_time_utc':now,'reviewer':'/root/norm_source_graph_391602',
 'source_sha256':'6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915',
 'candidate_signature_sha256':sha(sig_path.read_bytes()),'phase1_manifest_sha256':sha(base_manifest.read_bytes()),
 'exact_candidate_visible_only_after_phase1_freeze':True,'slots':slot_comparisons,
 'bounded_judgment':'MATCHES_FROZEN_RAW_CONTRACT_AS_DISCLOSED_SOURCE_IMPLICIT_ELABORATION',
 'blocking_semantic_deltas_found':[],
 'explicit_inferences':['The source does not explicitly define Z_A by an integral or name its base measure. The candidate makes ordinary unweighted Euclidean Lebesgue meaning explicit.','Finite integrability is an output elaborating finite Gaussian mass, not a new source hypothesis.','detΛ product and positive inverse-square-root algebra are omitted standard bridges, not explicit displayed source formulas.'],
 'not_claimed':['No production proof or proof API was inspected.','No compiler-backed theorem truth or sourceV status.','No independent global topology/coverage challenge acceptance.','No full C4, consumer, main theorem, paper, publication or Goal completion.'],
 'next_gate':'Distinct raw-source topology/coverage challenger and any required independent source-admission gate; this extractor does not approve its own original coverage.'
}

receipt=ROOT/'.astis/huanjian-resume-20261103/20261108T055855887481Z-fixed-spectrum-normalizer-standard-measure-meaning-only-corrected.receipt.json'
log=ROOT/'.astis/huanjian-resume-20261103/20261108T055855887481Z-fixed-spectrum-normalizer-standard-measure-meaning-only-corrected.log'
assert sha(log.read_bytes())=='8ed1d12ef2a779698bb17d96bd66fe8684a447674e339dd528b1d8ccd1098803'
inputs=[seal_path,sig_path,audit_path,receipt,log]+[ROOT/x['excerpt'] for x in root_audit['necessary_definition_raw_windows']]+[base_manifest,PHASE1/'source-contract.json',PHASE1/'source-proof-graph.json',PHASE1/'coverage-inventory.json',ROOT/'.astis/huanjian-resume-20261103/2610.20492v1.html']
provenance={
 'schema':'astis-phase2-input-provenance/v1','freeze_time_utc':now,'inputs':[describe(p) for p in inputs],
 'phase1_preservation':{'manifest_sha256':sha(base_manifest.read_bytes()),'all_original_manifest_files_verified_unchanged':True,'original_file_count':len(base['files']),'no_original_file_rewritten':True},
 'additional_necessary_meaning_windows':meaning_windows,
 'exposure_log':[
  {'sequence':1,'material':'Parent phase2 assignment','scope':'Candidate identity, producer scope, meaning-receipt location; no challenger rationale.'},
  {'sequence':2,'material':'Exact statement seal/signature and root preseal audit','scope':'Read exact proposition, binder/definition proposals, permitted context-clip references and exposure metadata. Root conclusions treated as proposals, not independent evidence.'},
  {'sequence':3,'material':'Three necessary-definition clips','scope':'Bochner integral, Integrable, EuclideanSpace only; hashes independently verified.'},
  {'sequence':4,'material':'Meaning-only receipt/log','scope':'Resolves measureSpaceOfInnerProductSpace, WithLp.measurableSpace and ofLp=self.1. Receipt read only; no probe rerun or source code opened.'},
  {'sequence':5,'material':'Narrow Mathlib necessary-definition lookup','scope':'Exact measureSpaceOfInnerProductSpace name lookup first in MeasureTheory/Measure/Lebesgue (no result), then Mathlib declaration headers only located OfBasis.lean:310. Read 305–317: preceding normalization comment tail and neighboring generic IsAddHaar instance incidentally visible. Exact addHaar definition-name lookup had two no-result regex attempts, then located OfBasis.lean:255; read251–257. No Gaussian integral theorem, target proof API or target ancestor project Lean was searched/read.'},
  {'sequence':6,'material':'Own frozen source contract/graph/inventory and exact original bytes','scope':'Used only for unchanged-base verification and semantic mapping. Original phase1 artifacts not rewritten.'},
  {'sequence':7,'material':'Overlay authoring','scope':'Wrote only versioned nested overlay within the owned phase1 public directory and private source-graph-391602 script.'}],
 'forbidden_material_exposure':{'production_or_Test_Lean':False,'ancestor_project_Lean':False,'target_proof_API':False,'previous_reviews_or_verdicts':False,'distinct_challenger_rationale':False,'global_frontier_ledgers_publication_lessons_site':False},
 'no_proof_or_shared_actions':'No build/probe rerun, proof search, production/Test edit, global/ledger/API action, new Goal, background ASTIS or sourceV transition.'}

dump(OUT/'matching-seven-slots.json',comparison)
dump(OUT/'candidate-binder-definition-audit.json',binder_audit)
dump(OUT/'graph-coverage-overlay.json',overlay)
dump(OUT/'input-provenance.json',provenance)
base_nodes={n['id'] for n in json.loads((PHASE1/'source-proof-graph.json').read_text())['nodes']}
new_ids={n['id'] for n in new_nodes}
assert len(new_ids)==len(new_nodes) and not new_ids&base_nodes
for e in overlay_edges:
 assert e['output'] in new_ids and set(e['inputs'])<=base_nodes|new_ids
 assert e['operator']=='AND' and e['consumer_use_site']

report=f'''# Phase 2 sealed-statement overlay freeze

Frozen UTC: {now}. Actor: `/root/norm_source_graph_391602`.

Judgment: **the exact sealed producer matches the frozen raw-source contract as a disclosed source-implicit elaboration**. No blocking semantic delta was found in the selected Gaussian-normalizer component. This is statement/meaning/coverage mapping only, not sourceV, proof truth, topology approval or theorem completion.

The exact candidate SHA-256 is `{sha(sig_path.read_bytes())}` and seal-file SHA-256 is `{sha(seal_path.read_bytes())}`. Phase1 manifest `{sha(base_manifest.read_bytes())}` and all {len(base['files'])} original manifest-bound files were verified unchanged. No phase1 graph, inventory, contract or disposition was altered.

All seven slots were compared independently after the raw-first freeze. The only substantive assumptions are the source d≥2, κ≥2 and full real orthogonal O. Fin d index j corresponds to source i=j.val+1, preserving the literal half-grid. A and exp(−xᵀAx/2) are literal lets. No PD/admissibility, determinant, normalizer, integrability or density certificate is assumed.

The selected source does not explicitly define Z_A by an integral or name its measure. The candidate expressly realizes the ordinary unweighted Euclidean-Lebesgue normalizer convention; it does not fabricate a quotation. The meaning-only log resolves volume to measureSpaceOfInnerProductSpace. The narrowly inspected raw definition uses the standard orthonormal-basis addHaar; addHaar is Lebesgue measure giving mass1 to the basis parallelepiped. Thus the candidate's volume has ordinary Euclidean normalization. The exact read windows and incidental generic neighboring instance are recorded.

The output is the **AND** of Integrable(weight,volume) and the actual integral value. Integrability is an output explaining finite Gaussian mass. The actual Bochner integral cannot be replaced by its nonintegrable-zero convention while satisfying both obligations. The value (2π)^((d:ℝ)/2)/sqrt(∏λ) is the source determinant expression after distinct omitted determinant/product and positive-half-power bridges. Real division retains odd dimensions. All positivity/nonzero facts remain derived from the source grid, not public premises.

The overlay preserves the author's compressed Gaussian-integration route, determinant conjugation, product identity, and power/square-root adapter separately. It supplies use sites and conditional discharge obligations without choosing an implementation proof route or claiming the bridges are proved. No alternative author proof or false AND across optional branches has been introduced.

Full C4 class/calculus/minimizer claims remain separately inventoried. Theorem4.1 parameter ranges, whole Section4.4 limitations, algorithms/oracles, precision, TV and deterministic/expected costs remain excluded. The candidate's explicit O-independent value supports the source public-spectrum known-normalizer statement but supplies no computation-cost guarantee. The actual Gaussian-density consumer remains planned, unsealed and unproved under its separate gate.

Files: `matching-seven-slots.json`, `candidate-binder-definition-audit.json`, `graph-coverage-overlay.json`, `input-provenance.json`, exact necessary-meaning windows, and this report. The phase2 manifest binds them plus the private authoring script; inputs are individually hashed. A distinct challenger must still reread source and graph coverage. The extractor cannot approve its own phase1 topology.

**STOP: phase2 frozen before any sourceV/proof/API/shared-state action.**
'''
(OUT/'PHASE2-FREEZE.md').write_text(report,encoding='utf-8')
manifest={'schema':'astis-phase2-overlay-manifest/v1','freeze_time_utc':now,'phase1_manifest_sha256':sha(base_manifest.read_bytes()),'candidate_signature_sha256':sha(sig_path.read_bytes()),'status':'FROZEN_STATEMENT_OVERLAY_NO_SOURCEV','files':[]}
for p in sorted(OUT.rglob('*')):
 if p.is_file() and p.name not in ['manifest.json','manifest.sha256']:manifest['files'].append(describe(p))
manifest['files'].append(describe(PRIVATE/'freeze_phase2.py'))
dump(OUT/'manifest.json',manifest)
digest=sha((OUT/'manifest.json').read_bytes())
(OUT/'manifest.sha256').write_text(digest+'  manifest.json\n',encoding='ascii')
print(json.dumps({'freeze_time_utc':now,'output':str(OUT),'manifest_sha256':digest,'artifact_sha256':{p.name:sha(p.read_bytes()) for p in [OUT/'matching-seven-slots.json',OUT/'candidate-binder-definition-audit.json',OUT/'graph-coverage-overlay.json',OUT/'input-provenance.json',OUT/'PHASE2-FREEZE.md']},'original_phase1_files_unchanged':len(base['files']),'overlay_nodes':len(new_nodes),'overlay_hyperedges':len(overlay_edges)},indent=2))
