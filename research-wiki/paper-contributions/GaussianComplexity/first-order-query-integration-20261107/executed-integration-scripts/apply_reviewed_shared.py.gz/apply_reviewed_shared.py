from pathlib import Path
import json,gzip,hashlib,subprocess,sys,datetime
sys.path.insert(0,'tools');import astis_advance as a;import astis_publication as pub
ADV='ASTIS-SA-20261107-GaussianComplexityFirstOrderQuery';OWNER='huanjian_gc_20261107_first_order_query_integration';DECL='AutoSamplingTheory.ExampleCases.GaussianComplexity.FirstOrderQuery.actual_first_order_query';OUT=Path('research-wiki/paper-contributions/GaussianComplexity/first-order-query-integration-20261107')
def sha(b):return hashlib.sha256(b).hexdigest()
def unpack(row):
 raw=Path(row['path']).read_bytes();assert sha(raw)==row['gzip_sha256'];data=gzip.decompress(raw);assert sha(data)==row['raw_sha256'];return data
states=a.current_advances();s=states[ADV];assert s['state']=='STABILIZING' and s['latest_evidence']['integration_owner']==OWNER and [k for k,v in states.items() if v['state']=='STABILIZING']==[ADV]
pub.check_advance([DECL],reviewed=True);report=OUT/'independent-integration-reader-review/preparation-report.json';assert sha(report.read_bytes())=='a23b751b67017e77a345e08b1cbd645c06f1898b09bfaf0ddbdeacf849eb16ea';x=json.loads(report.read_text());assert x['publication_binding_sha256']=='e8418238a48de3365b59035dc005bce611ec93a257f47229c54a6b847a1452aa'
for p,h in x['source_test_publication_lesson_pins'].items():assert sha(Path(p).read_bytes())==h
assert len(x['shared_paths'])==9 and not (OUT/'shared-integration-manifest.json').exists();head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();subprocess.run(['git','merge-base','--is-ancestor','origin/main','HEAD'],check=True)
plans=[]
for row in x['shared_paths']:
 p=Path(row['path']);old=p.read_bytes() if p.exists() else None;assert (old is not None)==row['before_exists'] and (sha(old) if old is not None else None)==row['before_sha256'],str(p)
 if old is not None:assert subprocess.check_output(['git','show',head+':'+str(p)])==old
 new=unpack(row['planned_after_archive']);assert sha(new)==row['planned_after_sha256'];plans.append((row,old,new))
for path,record in x['ledger_protection'].items():
 raw=Path(path).read_bytes();assert raw.startswith(unpack(record['raw_prefix']));foreign=json.loads(unpack(record['foreign_projection']));now=a.current_advances() if 'advances' in path else a.current_discoveries();assert all(now[k]==v for k,v in foreign.items())
protected=json.loads(unpack(x['source_content_input_hashes']));
for p,row in protected.items():
 q=Path(p);raw=__import__('os').fsencode(__import__('os').readlink(q)) if q.is_symlink() else q.read_bytes();assert sha(raw)==row['sha256'],p
frontier=next((old,new) for row,old,new in plans if row['path']=='website/content/samplewiki_companion_frontiers.json');old,new=map(json.loads,frontier)
for v in [old,new]:v['cases'][4]['reader_guide'][3]='<FOQ>';v['cases'][4]['theorems'][0]['boundary']='<FOQ>'
assert old==new
lb=Path('runs/substantive_advances.jsonl').read_bytes();db=Path('runs/substantive_discoveries.jsonl').read_bytes()
for row,old,new in plans:
 p=Path(row['path']);p.parent.mkdir(exist_ok=True,parents=True);p.write_bytes(new);assert sha(p.read_bytes())==row['planned_after_sha256']
assert Path('runs/substantive_advances.jsonl').read_bytes()==lb and Path('runs/substantive_discoveries.jsonl').read_bytes()==db and a.current_advances()==states
manifest={'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base_commit':head,'integration_owner':OWNER,'mathematical_candidate':'515f9401d4c324680bb2a1c010274cafa47efc02','actual_source_verified_metadata_commit':'214b6214c5b08bd52b6faa59a3ccd6ca35998420','accepted_source_V_first_carrying_commit':'756ae1a1c36a20146e551ff44f5b30d37e0cb1cd','source_verifier':'/root/reader_570298','reviewed_proposal_raw_sha256':sha(report.read_bytes()),'paths':[{'path':row['path'],'before_sha256':sha(old) if old is not None else None,'after_sha256':sha(new)} for row,old,new in plans],'case_scalar_pointer_delta':['/cases/4/reader_guide/3','/cases/4/theorems/0/boundary'],'all_other_case_values_and_execution_preserved':True,'all_old_Registry_entries_and_bytes_preserved':True,'new_canonical_entries':1,'count_change':'615->616 administrative inventory only','new_typed_conceptual_bridge':'transport:gaussian-quadratic-oracle-factorization','conceptual_formal_refs':[],'all_old_hyperedges_and_family_fields_preserved':True,'ledger_and_all_advance_states_unchanged_by_shared_write':True,'protected_foreign_source_inputs_checked':len(protected),'state':'Exact guarded9path STAB shared write completed; actual canonical gates/reader acceptance pending'}
(OUT/'shared-integration-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'shared_paths':len(plans),'one_canonical_node_added':True,'new_conceptual_bridge_not_Lean_implication':True,'all_other_case_values_and_execution_preserved':True,'protected_foreign_inputs':len(protected)}))
