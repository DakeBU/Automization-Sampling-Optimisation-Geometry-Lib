from pathlib import Path
from bs4 import BeautifulSoup
import json
base=Path('.astis/semantic-neutral-20261110/cg_tc_8f2b60/phase1')
s=BeautifulSoup((base/'A3.SS2.html').read_bytes(),'html.parser')
items=[]
for t in s.find_all(id=True):
 if '.Ex' in t['id']:
  p=t.find_parent(class_='ltx_para')
  text=t.get_text(' ',strip=True)
  alt=[m.get('alttext') for m in t.find_all('math')]
  items.append({'id':t['id'],'tag':t.name,'class':t.get('class'),'paragraph':p.get('id') if p else None,'math_alt':alt})
out=json.dumps(items,ensure_ascii=False,indent=2)+'\n';(base/'raw-05-display-inventory-output.json').write_text(out);print(out)
