from pathlib import Path
import datetime, hashlib, json
from bs4 import BeautifulSoup
sha = lambda b: hashlib.sha256(b).hexdigest()
lesson = Path('website/content/declaration_lessons/huanjian-fixed-spectrum-first-order.json')
html = Path('.astis/semantic-neutral-20261108/src_4e8f6a/phase3/reader/index.html')
x = json.loads(lesson.read_bytes()); formula = x['units'][0]['formula']; slash = chr(92)
suspect = []
def walk(value, path):
    if isinstance(value, dict):
        for k, v in value.items(): walk(v, path + [k])
    elif isinstance(value, list):
        for k, v in enumerate(value): walk(v, path + [k])
    elif isinstance(value, str) and slash + slash in value: suspect.append(path)
walk(x, [])
soup = BeautifulSoup(html.read_bytes(), 'html.parser')
text = soup.select_one('.reader-main-equation').get_text()
assert [ord(c) for c in formula[:8]] == [92,110,97,98,108,97,32,102]
assert len(formula) - len(formula.lstrip(slash)) == 1
assert not suspect and slash + slash not in text
assert text == slash + '[' + formula + slash + ']'
out = Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-first-order-semantic-evidence/root-literal-tex-byte-check.json')
assert not out.exists()
out.write_text(json.dumps({
    'checked_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'scope': 'Mechanical literal-byte check only; no mathematical/source verdict or rendered UI acceptance',
    'lesson_path': str(lesson), 'lesson_raw_sha256': sha(lesson.read_bytes()),
    'owned_source_review_HTML': str(html), 'owned_HTML_raw_sha256': sha(html.read_bytes()),
    'formula_initial_codepoints': [ord(c) for c in formula[:8]],
    'leading_backslashes': 1, 'lesson_string_paths_with_adjacent_backslashes': suspect,
    'owned_HTML_formula_backslash_offsets': [i for i,c in enumerate(text) if ord(c)==92],
    'owned_HTML_formula_exact_single_delimiters_and_literal_formula': True,
    'finding': 'Runtime TeX commands have a single backslash. JSON/repr tool transport escaping does not add another command character. No formula/source bytes changed.',
    'earlier_lookup_failure': 'System python3 lacked bs4. Retried existing /opt/anaconda3/bin/python; no install or environment/source modification.',
    'actual_browser_pixels': False, 'current_canonical_site_gate_or_sourceV': False
}, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'literal_TeX_is_single_escaped': True, 'evidence': str(out),
                  'sha256': sha(out.read_bytes()), 'no_formula_or_Lean_mutation': True}))
