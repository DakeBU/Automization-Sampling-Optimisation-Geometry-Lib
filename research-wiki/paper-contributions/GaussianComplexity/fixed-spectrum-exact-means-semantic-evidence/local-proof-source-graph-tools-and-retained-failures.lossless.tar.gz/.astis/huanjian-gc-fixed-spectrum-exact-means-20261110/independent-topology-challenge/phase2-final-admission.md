# C8 exact means — final independent preproof ACCEPT

**ACCEPT: exact preproof sourcegraph / topology / binders / literal definitions / source meaning. No HOLD remains.** This admits the bounded statement and source-obligation graph only. It does not certify target proof, compiled reuse, actual consumer implementation, source V, VERIFIED, intake or Goal/integration credit.

## Exact admitted inputs

| Input | SHA-256 |
|---|---|
| Unchanged statement-seal-v1.json | `81900673dcb74d8e5a321be926904feadd368478f651c619cb3675ee0cc92e3e` |
| Extractor phase2-freeze-v1.json | `3777ea0e62e9e19ccd8e8c573258b7d936b607b81c8ef9b0a7157e0a28de3ae8` |
| source-proof-graph-v1.json | `f56b618a28970707b00998c1aeef49b0c5c92701edbab137a59342bab5fe9861` |
| source-coverage-v1.json | `78f4913981b068ff572ee07b053f10cbd677301a93fc6c17c56580a2896c7445` |
| seal-projection-v1.json | `fc70aa835196c33385c34da8c90dbd3506c6ae352aaad6e6542f5641a055af14` |
| two-root-closures-v1.json | `04b2fcca23e1f08160211071dfd73bd90f762455dc5bf678a04891e112ffadfa` |

The independent raw cognition, seal ACCEPT and raw-inventory freezes preceded this graph reading and remain unchanged. Only the raw source and allowed machine artifacts were semantically read; private cognition, generators, handoff/rationale and structural-verdict files were not opened.

## Entire roots and exact subroots

Direct prerequisite traversal independently reproduced every supplied node/edge list, source-reference union and SOURCE_GAP list:

| Root | Nodes / edges | Key boundary |
|---|---:|---|
| Joint actual Gaussian closed means | 39 / 35 | Actual Gaussian-to-grid AND C7/absolute finite exchange AND signed aliases AND both scalar tail routes. |
| Actual m/b consumer | 45 / 41 | New producer, actual M upper/sign and exact absolute ratio; both closed mean values are required. |
| M positivity/upper bound | 27 / 23 | Unweighted exact M and guards; no weighted-tail classes or μ exact formula; no variance/fourth moments. |
| Signed μ positivity | 34 / 30 | Weighted exact mean and radius/exponent/denominator guards; no M exact formula. |
| Exact absolute ratio | 43 / 39 | Both closed means, signed absolute-value elimination and nonzero normalization. |

No root requires Ex148–149, Ex151, logarithmic/exponential bias bounds, a d−n≥√κ condition, oddness or query relation. Actual Gaussian objects retain precision Λ and covariance Λ⁻¹; neither m nor b is a formula-defined scalar placeholder. Both producer integrability outputs remain inherited internal facts.

## Positive-index and geometric topology

The M branch retains the separate constant mode and exactly j=2ad with a≥1. Its alternating geometric ratio is −r^(2d); the factor 2 and finite correction survive through Ex141→142→143.

The weighted branch retains both signed integer frequencies j−n and j+n. Its singleton j=n, positive-plus j=2ad+n and positive-minus j=2ad−n classes are individually represented, then combined through explicit completeness/injectivity/disjointness and parity obligations. Negative quotient possibilities are ruled out by the positive source j range and 1≤n<d rather than by truncating integer subtraction. The minus class begins at a=1 and its exponent is positive. The parity factor is (−1)^n for every allowed n.

The source ranges j≥1 and a≥1 are intrinsic quantified domains of the respective source sums. They are not assertions that the global dimension/radius guards imply positivity of an arbitrary free index, and they do not become public theorem hypotheses. The graph preserves their guarded scope and the internal Nat predecessor/subtraction/exponent obligations.

The two shifted tails have the same ratio −r^(2d), explicit initial powers r^(2d+n) and r^(2d−n), correct negative geometric values and denominator 1+r^(2d). The final r^(2d+n) cancellation is represented before the signed closed mean. Absolute summability, restriction/reindexing and regrouping are retained as internal obligations; neither geometric values nor class certificates are added as binders.

The source gives one route with conjunctive unweighted/weighted outputs. Both guarded alias cases are required for the universal integer formula, not two independent OR proofs. Absolute finite exchange is the selected route; the possible uniform-convergence exchange is explicitly unselected and does not enter either root closure. It is not misattributed as a second complete author proof.

## Source/implementation and gap boundary

There are 46 nodes, 42 edges and eight explicit SOURCE_GAP nodes. Every gap has an incoming internal obligation edge and `obligation_not_public_premise=true`; every graph node has `formal_credit=false`. The only public-hypothesis node is the exact source standing range. Remaining leaves are literal source definitions. All edge guards name upstream providers and source use sites, not free convergence/positivity witnesses.

The actual Gaussian-to-grid node is an opaque existing source-backed substrate with actual integrability and finite expectation identities. Its coordinate-moment sentence/source-implicit steps record source background; this review does not assert a new publicly exported coordinate-moment API or certify any compiled reuse. Exact available calls and material use of both closed mean equalities remain postproof checks.

Scalar series manipulations occur after Ex140's actual Gaussian expectations have become finite reciprocal-grid sums. The graph does not require a new Gaussian-integral/infinite-series Fubini hypothesis. Denominator, radius and positive covariance interpretation remain discharged internal dependencies, never substitute default-zero integral or off-domain matrix behavior.

## Exhaustive bounded coverage

All 72 unique raw units are preserved field-for-field and receive exactly one disposition: **38 NODE / 34 EXCLUDED**. Their independent prior source check preserved 103 unique math formulas and all mathematical-unit links. Formula-group containers are explicitly excluded while their individual TBODY rows retain separate coverage, including all Ex141–147 steps. The p6.2 compound paragraph maps to all three class nodes, disjointness/parity and reindexing.

The full Lemma 4.5/C8 containers are not treated as already-proved premises; their exact mean statement/conditions are covered separately, while variance and extra exponential assumptions are excluded. p8.2 maps directly to M positivity/upper; p9.1 and Ex150 map to sign/absolute/ratio facts. Aligned variance rows and Ex151/p10–p11 are explicitly excluded. Historical construction citation [22] is provenance only; no external theorem has been imported.

All node source references, edge consumer-use references and definition references resolve in the fixed original HTML. Seal projection contains the exact previously accepted producer/consumer signature strings and exact standard-definition snippet; their hashes were independently checked. There is no source-to-Lean implication inferred from a planned dependency name.

## Remaining work

The sole mathematical worker may proceed on this exact seal and source topology. Every tail/residue/geometric proof, actual material producer/consumer use, compilation and subsequent independent verification still remains to be done. Variances, full exponential normalized-bias bounds, rotated/adaptive laws, oracle/TV/precision/cost/main bounds and full Lemma 4.5/paper/Goal completion remain outside this admission. No build, proof/API search, ledger, queue or shared mutation was performed by this reviewer.
