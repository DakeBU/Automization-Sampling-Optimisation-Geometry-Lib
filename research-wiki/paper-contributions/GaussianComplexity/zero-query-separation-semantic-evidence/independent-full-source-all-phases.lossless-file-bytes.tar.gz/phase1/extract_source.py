from pathlib import Path
from html.parser import HTMLParser
import hashlib, json, re

BASE = Path(__file__).resolve().parent
# Resolve the explicitly assigned source without any repository inventory.
SRC = Path('/Users/zhouhuanjian/ASTIS-GC/.astis/huanjian-resume-20261103/2610.20492v1.html')
raw = SRC.read_bytes()
assert len(raw) == 951991
assert hashlib.sha256(raw).hexdigest() == '6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
src = raw.decode('utf-8')
lines = [0]
for m in re.finditer('\n', src): lines.append(m.end())

class Index(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.stack = []
        self.ids = {}
    def pos(self):
        line, col = self.getpos()
        return lines[line-1] + col
    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        rec = {'tag':tag, 'start':self.pos(), 'id':attrs.get('id'), 'attrs':attrs}
        if rec['id']: self.ids[rec['id']] = rec
        if tag not in {'area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr'}:
            self.stack.append(rec)
        else: rec['end'] = self.pos()+len(self.get_starttag_text())
    def handle_endtag(self, tag):
        for i in range(len(self.stack)-1,-1,-1):
            if self.stack[i]['tag'] == tag:
                end = src.index('>',self.pos())+1
                for rec in self.stack[i:]: rec['end'] = end
                del self.stack[i:]
                break
idx=Index(); idx.feed(src)

class Render(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True); self.out=[]; self.math=0; self.skip=0
    def handle_starttag(self,tag,attrs):
        a=dict(attrs)
        if tag=='math':
            if not self.math: self.out.append('$'+a.get('alttext','[MISSING ALTTEXT]')+'$')
            self.math+=1
        elif tag in {'script','style'}: self.skip+=1
        elif not self.math and not self.skip and tag in {'p','h1','h2','h3','h4','h5','h6','table','li'}: self.out.append('\n\n')
    def handle_endtag(self,tag):
        if tag=='math': self.math-=1
        elif tag in {'script','style'}: self.skip-=1
        elif not self.math and not self.skip and tag in {'p','h1','h2','h3','h4','h5','h6','table','li'}: self.out.append('\n\n')
    def handle_data(self,data):
        if not self.math and not self.skip: self.out.append(data)
    def text(self):
        return '\n\n'.join(re.sub(r'\s+',' ',p).strip() for p in ''.join(self.out).split('\n\n') if p.strip())+'\n'

def bytepos(n): return len(src[:n].encode())
fragments=[]
def save(name,start,end,scope):
    b=src[start:end].encode()
    assert b==raw[bytepos(start):bytepos(end)]
    (BASE/(name+'.raw.html')).write_bytes(b)
    r=Render();r.feed(b.decode());(BASE/(name+'.rendered.txt')).write_text(r.text())
    math=[]
    for rid,rec in idx.ids.items():
        if rec['tag']=='math' and rec['start']>=start and rec['end']<=end:
            raw_math=src[rec['start']:rec['end']]
            anns=re.findall(r'<annotation encoding="application/x-tex">(.*?)</annotation>',raw_math,re.S)
            math.append({'id':rid,'byte_start':bytepos(rec['start']),'byte_end_exclusive':bytepos(rec['end']), 'alttext_decoded':rec['attrs'].get('alttext'), 'tex_annotation_raw':anns,'raw_sha256':hashlib.sha256(raw_math.encode()).hexdigest()})
    (BASE/(name+'.math.json')).write_text(json.dumps(math,ensure_ascii=False,indent=2)+'\n')
    fragments.append({'name':name,'byte_start':bytepos(start),'byte_end_exclusive':bytepos(end),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'scope':scope})

def item(rid):
    r=idx.ids[rid];return r['start'],r['end']
(BASE/'original.raw.html').write_bytes(raw)
save('section2',*item('S2'),'Full standing notation, probability, TV, Borel measurability, oracle and deterministic-cap model context')
save('section3_statement',idx.ids['S3']['start'],idx.ids['S3.SS1']['start'],'Section3 heading, theorem and stated parameter/algorithm ranges; no construction proof')
save('proof_intro',*item('S3.SS3.p1'),'Uniform-accuracy and fixed-budget setup for proof')
save('zero_container',*item('S3.SS3.SSS0.Px1'),'Verbatim container; adjoining 2T+1>d branch retained only as boundary context')
start=idx.ids['S3.SS3.SSS0.Px1.p1.1']['start']
p2=idx.ids['S3.SS3.SSS0.Px1.p1.2']
stop=src.index('\nIf <math',p2['start'],p2['end'])
save('zero_selected',start,stop,'Selected zero-query statement, S3.Ex3 and contradiction/Thus T>=1 sentence only; stops before If 2T+1>d')
save('zero_display',*item('S3.Ex3'),'Selected exact unnumbered display')
for name,rid in [('spectrum_intro_boundary','S1.SS1.p4.1'),('spectrum_section4_boundary','S4.p2.1'),('spectrum_disclosure','S4.SS1.p2.1')]:
    save(name,*item(rid),'Raw-original-only boundary context: separate fixed-spectrum result; not a dependency of the selected zero-query proof')
(BASE/'raw_read_exposure.json').write_text(json.dumps({'scope':'Original arXiv HTML only; no candidate material','initial_direct_character_slices':[[0,3500],[112650,135750],[135550,151000],[169150,181000]],'direct_slice_note':'Initial tool result containing raw Section2/Section3/zero-query excerpts was aggregate-truncated. Saved exact relevant fragments and read full rendered derivatives subsequently. Initial direct slices also exposed start of construction and next proof paragraph, not used as dependencies of zero-query claim.','spectrum_search':'Paragraphs in original raw HTML matching case-insensitive spectrum|disclos|eigenvalue, rendered using math alttext','spectrum_search_paragraph_ids':['abstract1.1','S1.p3.1','S1.SS1.p4.1','S3.SS2.SSS0.Px3.p1.1','S4.p2.1','S4.SS1.p1.1','S4.SS1.p2.1','S4.Thmtheorem2.p1.1','S4.SS2.SSS0.Px1.p1.1','S4.SS4.SSS0.Px1.p1.1','S4.Thmtheorem8.p1.1','A3.SS3.p1.1','A3.SS3.p4.2','A3.SS4.p3.2']},ensure_ascii=False,indent=2)+'\n')
(BASE/'source_inventory.json').write_text(json.dumps({'source_path':str(SRC),'source_bytes':len(raw),'source_sha256':hashlib.sha256(raw).hexdigest(),'offset_unit':'UTF-8 bytes, zero-based, end-exclusive','fragments':fragments},ensure_ascii=False,indent=2)+'\n')
items=[]
for rid,rec in idx.ids.items():
    if rec['tag']=='p' and (rid.startswith('S2.') or rid.startswith('S3.Thmtheorem1.') or rid.startswith('S3.SS3.SSS0.Px1.')):
        r=Render();r.feed(src[rec['start']:rec['end']])
        items.append({'id':rid,'byte_start':bytepos(rec['start']),'byte_end_exclusive':bytepos(rec['end']),'sha256':hashlib.sha256(src[rec['start']:rec['end']].encode()).hexdigest(),'rendered':r.text()})
(BASE/'source_paragraph_index.json').write_text(json.dumps(items,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'source_sha256':hashlib.sha256(raw).hexdigest(),'fragments':fragments},ensure_ascii=False,indent=2))
