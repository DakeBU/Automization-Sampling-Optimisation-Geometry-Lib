from pathlib import Path
import datetime, gzip, hashlib, json, subprocess, tarfile

P = Path('.astis/huanjian-gc-fixed-spectrum-geometry-20261109')
B = Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-geometry-semantic-evidence')
S = Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-geometry-statement-seal.json')
sha = lambda b: hashlib.sha256(b).hexdigest()
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == '760daf7772fbb26932791a55a6f24ed27f8c533a'
assert not subprocess.check_output(['git', 'diff', 'HEAD', '--name-only']).strip()
assert sha(S.read_bytes()) == '85bc4d02c970f21e144e776b3ad9a129539b5669beb4b0798c8da3cd4503e7fc'
clarification = {'recorded_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'kind': 'PRESEAL_EXPOSURE_TERMINOLOGY_CLARIFICATION_NOT_A_STATEMENT_REPAIR',
    'statement_seal_sha256_unchanged': sha(S.read_bytes()),
    'meaning_of_no_target_proof_search': 'The seal flags refer to no target implementation, target-lemma proof/API retrieval, candidate Lean proof construction/test, or theorem result. Root did have ordinary conceptual interface/consumer planning based on previously authored parent mathematics and standard calculus, including interpreting the Hessian as the derivative of the gradient and why regularity could feed fixed-input Borel composition. They do not assert an absence of all mathematical route thoughts.',
    'name_inventory_exposure': 'The actual rg inventory showed declaration names/first header lines of generic HessianStrongConvexity, StrongConvexMinimizer and QuadraticGradientDescent; this is disclosed and not described as zero API ambient cues. The exact incidental definition-neighbor exposure is retained in the sealed audit.',
    'independence_barrier': 'Both separately spawned source-only roles begin with raw source and frozen cognition before seeing any interface, root rationale, reuse/exposure audit or implementation. Their topology does not depend on root planning.',
    'actual_target_proof_or_source_verdict': False, 'statement_or_binder_changed': False}
c = B/'preseal-exposure-terminology-clarification.json'
assert not c.exists()
c.write_text(json.dumps(clarification, ensure_ascii=False, indent=2)+'\n')
p = Path('.astis/huanjian-resume-20261103/20261108T164517725415Z-fixed-spectrum-geometry-exact-statement-binder-definition-seal.receipt.json')
r = json.loads(p.read_bytes())
raw = Path(r['log']).read_bytes()
assert r['exit_code'] == 0 and sha(raw) == r['log_sha256']
(B/'preseal-actual-checks'/p.name).write_bytes(p.read_bytes())
(B/'preseal-actual-checks'/(Path(r['log']).name+'.gz')).write_bytes(gzip.compress(raw, mtime=0))
helpers = sorted(P.glob('*.py'))
archive, manifest = B/'preseal-root-tools.lossless.tar.gz', B/'preseal-root-tools.manifest.json'
assert not archive.exists() and not manifest.exists()
with tarfile.open(archive, 'w:gz') as t:
    for h in helpers: t.add(h, arcname=str(h), recursive=False)
with tarfile.open(archive, 'r:gz') as t:
    for h in helpers: assert t.extractfile(str(h)).read() == h.read_bytes()
manifest.write_text(json.dumps({'archive': str(archive), 'sha256': sha(archive.read_bytes()),
    'files': [{'path': str(h), 'sha256': sha(h.read_bytes())} for h in helpers],
    'scope': 'Root meaning/seal/packaging only; no theorem proof or independent source verdict.'}, indent=2)+'\n')
paths = [S, c, archive, manifest, B/'existing-state-baseline.raw.json.gz',
         B/'successful-meaning-probe.raw.lean.gz', B/'failed-v1-meaning-probe.raw.lean.gz',
         B/'preseal-intake-and-preservation.json', B/'preproof-raw-interface-packet.json']
paths += sorted((B/'preseal-actual-checks').rglob('*'))
paths += sorted((B/'necessary-definition-context').rglob('*'))
paths = [p for p in paths if p.is_file()]
subprocess.run(['git', 'add', '--', *map(str, paths)], check=True)
staged = subprocess.check_output(['git', 'diff', '--cached', '--name-only', '-z']).decode().strip('\0').split('\0')
assert set(staged) == set(map(str, paths))
for name in staged: assert subprocess.check_output(['git', 'show', ':'+name]) == Path(name).read_bytes(), name
subprocess.run(['git', 'diff', '--cached', '--check'], check=True)
assert not any('/source-only-review/' in name or '/topology-challenge/' in name for name in staged)
print(json.dumps({'preseal_paths_staged_exactly': len(staged), 'independent_work_in_progress_not_staged': True,
                  'no_SAU_or_Registry_or_production_or_shared_paths': True,
                  'mathematical_proof_or_source_verdict': False}))
