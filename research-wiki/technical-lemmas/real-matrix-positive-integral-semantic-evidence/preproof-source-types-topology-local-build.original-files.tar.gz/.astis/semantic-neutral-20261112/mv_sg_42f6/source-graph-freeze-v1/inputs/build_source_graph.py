from pathlib import Path
import json,hashlib,re,datetime,shutil
ROOT=Path('/Users/zhouhuanjian/ASTIS-GC');BASE=ROOT/'.astis/semantic-neutral-20261112/mv_sg_42f6';RAW=BASE/'raw-freeze-v2';TYPE=BASE/'type-freeze-v1';OUT=BASE/'source-graph-freeze-v1'
def sha(b):return hashlib.sha256(b).hexdigest()
def j(p):return json.loads(p.read_text())
assert not OUT.exists()
rm=(RAW/'freeze-manifest.json').read_bytes();tm=(TYPE/'freeze-manifest.json').read_bytes();ta=j(TYPE/'type-audit.json')
assert sha(rm)=='e7e6ca17db84515ecfc8af6ff48f019a297a057c3e185e5e0ccb1cab590aa05f'
assert sha(tm)=='40d25d926a291fba12bbe7b77e79b35c658882f2b075414bb265562d8796e377'
assert sha((TYPE/'type-audit.json').read_bytes())=='fe0f281b09a49220b0896db169e3eaa4717fabee5d1d86317a686579a3e1ae4e'
for f in [RAW,TYPE]:
 for x in j(f/'freeze-manifest.json')['files']:
  b=(f/x['path']).read_bytes();assert len(b)==x['bytes'] and sha(b)==x['sha256']
inv=j(RAW/'atomic-inventory.json');units=j(RAW/'locators-and-source-units.json')['source_units'];packet=j(TYPE/'inputs/selective-type-definition-packet.json')
B=(RAW/'inputs/2610.20492v1.html').read_bytes();S=B.decode()
OUT.mkdir();(OUT/'inputs').mkdir()
def dump(n,v):(OUT/n).write_text(json.dumps(v,ensure_ascii=False,sort_keys=True,indent=2)+'\n',encoding='utf-8')
def write(n,t):(OUT/n).write_text(t,encoding='utf-8')
bindings=dict(ta['bindings'],type_manifest_sha256=sha(tm),type_audit_sha256=sha((TYPE/'type-audit.json').read_bytes()))
(OUT/'inputs/raw-v2-manifest.json').write_bytes(rm);(OUT/'inputs/type-manifest.json').write_bytes(tm);shutil.copyfile(TYPE/'type-audit.json',OUT/'inputs/type-audit.json');shutil.copyfile(BASE/'working/build_source_graph.py',OUT/'inputs/build_source_graph.py')

spec=[
 ('INTERNAL.row-law','Law applicability','Match the exact canonical mu,row with the source standard-r-Gaussian marginal law and row measurability. No extra ambient experiment or caller law certificate.'),
 ('INTERNAL.fourth-moment','Moment applicability','Match source E[R_i gamma_i gamma_i^T]=(r+2)I_r with actual row law, including fourth-moment integrability. R4/R5 are reported existing only; no exact provider application/proof has been inspected.'),
 ('INTERNAL.matrix-square','Literal algebra applicability','Prove actual ordinary Y*Y equals Ex114 using both rank-one square identities, Kronecker multiplication, indicator idempotence, WithLp coordinate equality and exact inverse-d squared.'),
 ('INTERNAL.square-integrability','Integrability applicability','Derive actual Y*Y and the untruncated fourth-moment tensor majorant integrability in the actual complete Matrix L2Operator norm. Measurability, norm estimates and all required moments are internal.'),
 ('INTERNAL.pointwise-PSD','Matrix positivity applicability','Derive Hermitian and full finite quadratic-form PSD facts for actual rank-one/tensor matrices, Y and Y*Y from their literal definitions. No entrywise-order or supplied PSD shortcut.'),
 ('INTERNAL.cutoff-order','Matrix-order applicability','Drop the row-local closed cutoff from Ex114 in true Loewner order with nonnegative scalar factors, using full Hermitian/quadratic positivity.'),
 ('INTERNAL.integral-order','Integral matrix-order applicability','Integrate pointwise PSD differences under justified integrability, retaining Hermitian and all quadratic forms, then sum the actual expectations. No Bochner default-zero credit.'),
 ('INTERNAL.tensor-CLM','Alternative integral transport','Use a justified continuous linear map for fixed feature tensor/scalar action to transport the actual fourth-moment matrix through the integral under actual norms/integrability.'),
 ('INTERNAL.tensor-entries','Alternative integral transport','Use continuous finite entry evaluations and finite-dimensional matrix integral reconstruction to transport the same actual fourth moment, with all integrability justified.'),
 ('INTERNAL.tensor-transport','OR-joined internal result','Obtain the same actual tensor-moment transport by either verified CLM or verified entrywise route. These alternatives are inferred implementation bookkeeping, not two source-authored proofs.'),
 ('INTERNAL.literal-frame','Deterministic applicability','Match literal half-grid t to source ||t_i||^2<=2r and sum_i t_i t_i^T=dI_r, including q=0 and exact normalizations. Weighted Gram is not required.'),
 ('INTERNAL.uncentered-algebra','Finite order/tensor algebra','Discharge Ex115–117 with exact source constants, positive d/nonnegative factors internally, finite tensor sums and I_r tensor I_r=I_(r^2). Obtain full PSD difference of the actual expectation sum.'),
 ('INTERNAL.Y-integrable-direct','Alternative actual-mean justification','Establish actual Y_i integrability directly from literal truncated maps and finite Gaussian/probability bounds, rather than silently using the default integral branch.'),
 ('INTERNAL.Y-integrable-reuse','Alternative actual-mean justification','A genuinely public existing actual-Y integrability provider may be reused only after exact applicability is verified. R8 reports are not proof inputs here; no private canonical-row test import is treated as public provider.'),
 ('INTERNAL.Y-integrable','OR-joined actual-mean justification','Actual Y_i integrability must be established by a verified direct route or a verified public-provider application. It is not a new theorem binder.'),
 ('INTERNAL.mean-Hermitian','Matrix mean applicability','Prove actual mean_i=integral_mu Y_i is Hermitian under actual integrability; then mean_i*mean_i is PSD. This follows from the actual definitions/positivity, not excluded p15 Bernstein context.'),
 ('INTERNAL.centered-square-integrable','Centered integrability algebra','Derive actual Z_i*Z_i and (w_i Z_i)*(w_i Z_i) integrability from actual square/linear/mixed terms; all left/right deterministic matrix multiplications and deterministic weights need justified applicability.'),
 ('INTERNAL.centering-algebra','Noncommutative integral algebra','With actual M_i=integral_mu Y_i, expand (Y_i-M_i)^2 including both Y_i M_i and M_i Y_i, transport deterministic left/right multiplication through integrals, and derive Ex118 equality. No commutativity certificate.'),
 ('INTERNAL.centered-order','Matrix-order applicability','Use PSD of actual mean square to prove E Z_i^2<=PSD E Y_i^2. Aggregate against the material uncentered producer bound under the same mu.'),
 ('INTERNAL.centered-PSD','Matrix positivity/integral applicability','Prove pointwise Z_i Hermitian, Z_i^2 PSD, and E Z_i^2/full sums PSD under actual integrability, including Finsupp-quadratic and finite-vector compatibility.'),
 ('INTERNAL.weighted-order','Weighted square applicability','With exact deterministic w_i=cos((2q+1)theta_i), derive E[(w_i Z_i)^2]=w_i^2 E Z_i^2<=PSD E Z_i^2 from |w_i|<=1 and actual centered-square PSD; aggregate without weighted-Gram cancellation or independence.'),
 ('INTERNAL.unweighted-PSD-to-norm','Operator norm applicability','From PSD of the actual unweighted centered second-moment sum and its Loewner upper bound C I, prove its true Euclidean L2Operator norm<=C. Establish C>=0 internally; PSD upper domination alone is not the norm conclusion.'),
 ('INTERNAL.weighted-PSD-to-norm','Operator norm applicability','Use PSD and the same C I upper bound for the actual weighted centered second-moment sum to derive the second true Euclidean operator norm<=C; exact norms and completeness must match.')]
ports=[{'id':id,'kind':k,'obligation':m,'status':'OPEN_UNPROVED_INTERNAL_APPLICABILITY','genuine_SOURCE_GAP':False,'compiled_parents':[]} for id,k,m in spec]
dump('internal-ports-and-source-gaps.json',{'bindings':bindings,'ports':ports,'genuine_source_gaps':[],
 'distinction':'Ordinary proof omissions, canonical theorem applicability, integrability, matrix positivity, integral/tensor algebra and PSD-to-operator-norm consequences are INTERNAL ports. No genuine source defect, missing source premise or ill-posed statement has been identified.',
 'OR_policy':'Alternative internal routes are explicit OR hyperedges. No requirement to prove every helper as a separate declaration, and no route option is promoted into a caller premise.',
 'public_provider_boundary':'No compiled parent inferred from import/name; no private canonical-row test assumed as public provider.'})

nodes=[{'id':x['id'],'kind':x['kind'],'meaning':x['meaning'],'source_element_id':x['source_element_id'],'locator':x['locator'],'status':'SOURCE_ITEM_REPRESENTED_UNPROVED'} for x in inv['items'] if x['disposition']=='NODE']
for x in nodes:
 if x['id']=='fourth.invocation':x['audited_meaning_clarification']='The following Ex113 moment is untruncated. Raw invocation wording retained-unrestricted is imprecise editorial wording; the source and exact Ex113 atom are unambiguous.'
nodes += [{'id':p['id'],'kind':p['kind'],'meaning':p['obligation'],'status':p['status']} for p in ports]
nodes += [
 {'id':'OUTPUT.Y-squares-integrable','kind':'Source-implicit output','meaning':'All actual Y_i*Y_i are integrable under exact mu.','status':'SEALED_TARGET_OUTPUT_UNPROVED'},
 {'id':'OUTPUT.uncentered-PSD','kind':'Source PSD output','meaning':'PosSemidef(C I-sum_i integral_mu(Y_i*Y_i)), with full Hermitian/quadratic meaning.','status':'SEALED_TARGET_OUTPUT_UNPROVED'},
 {'id':'FORMAL.producer','kind':'Exact sealed conjunction','name':packet['producer']['name'],'signature_sha256':packet['producer']['signature_sha256'],'status':'SEALED_UNPROVED_TARGET'},
 {'id':'OUTPUT.centered-integrability','kind':'Source-implicit output','meaning':'Both actual centered-square and weighted-centered-square families integrable.','status':'SEALED_TARGET_OUTPUT_UNPROVED'},
 {'id':'OUTPUT.unweighted-norm','kind':'Exact variance parameter output','meaning':'Norm(sum_i integral_mu(Z_i*Z_i))<=C in actual L2Operator norm.','status':'SEALED_TARGET_OUTPUT_UNPROVED'},
 {'id':'OUTPUT.weighted-norm','kind':'Exact variance parameter output','meaning':'Norm(sum_i integral_mu((w_i Z_i)*(w_i Z_i)))<=C in actual L2Operator norm.','status':'SEALED_TARGET_OUTPUT_UNPROVED'},
 {'id':'FORMAL.private-consumer','kind':'Exact sealed conjunction','name':packet['actual_private_consumer']['name'],'signature_sha256':packet['actual_private_consumer']['signature_sha256'],'status':'SEALED_UNPROVED_TARGET'}]
edges=[]
def locator(id):
 if id in units:return units[id]['locator']
 m=re.search(r'<([A-Za-z][\w:]*)\b[^>]*\bid="'+re.escape(id)+r'"[^>]*>',S);assert m,id;dep=1
 for z in re.finditer(r'</?'+re.escape(m[1])+r'\b[^>]*>',S[m.end():]):
  dep+=-1 if z[0].startswith('</') else 1
  if not dep:end=m.end()+z.end();break
 start=m.start();x=len(S[:start].encode());y=len(S[:end].encode());return {'utf8_byte_start':x,'utf8_byte_end_exclusive':y,'unicode_char_start':start,'unicode_char_end_exclusive':end,'lf_line_start_1based':S.count('\n',0,start)+1,'lf_line_end_1based':S.count('\n',0,end-1)+1,'raw_fragment_sha256':sha(B[x:y])}
def e(a,b,anchor,meaning,kind='Direct source consumer use'):
 if isinstance(anchor,str):anchor=[anchor]
 edges.append({'from':a,'to':b,'kind':kind,'meaning':meaning,'consumer_use_sites':[{'element_id':x,'locator':locator(x)} for x in anchor],'compiled_dependency':False})

# Source definition and deterministic norm/Gram proof slice.
e('grid.theta','c2.t','A3.Ex85','Literal half-grid in t.')
e('c2.r','c2.gamma','A3.Ex85','Actual row length r.')
e('experiment.columns','c2.row-law','A3.SS2.p1.2','Source marginal law assertion for original columns; no joint-independence prerequisite here.','Source-supported omitted row-law derivation')
e('c2.gamma','c2.row-law','A3.SS2.p1.2','The row law is about the actual physical maps.')
for a in ['c2.gamma','c2.t']:e(a,'c2.B-context','A3.SS2.p1.2','B formula preserves Gaussian-first tensor convention.')
e('c5.theta-recall','c5.A3.Ex88','A3.Ex88','Apply the half-grid sine-difference identity.')
e('c5.frequency-domain','c5.A3.Ex88','A3.Ex88','Source integer frequency range.')
e('c5.A3.Ex88','c5.A3.Ex89','A3.Ex89','Telescoping endpoint sine difference.')
for a in ['c5.A3.Ex89','c5.frequency-domain']:e(a,'c5.A3.SS2.p4.2','A3.SS2.p4.2','Zero endpoint and nonzero sine factor yield zero cosine sum.')
e('c2.t','c5.constant-sum','A3.Ex90','Constant coordinate1 contributes d.')
for a in ['c2.t','c5.A3.SS2.p4.2']:e(a,'c5.mixed-sum','A3.Ex90','Literal mixed coordinate and cosine-zero identity.')
e('c2.t','c5.A3.Ex91','A3.Ex91','Positive coordinates produce2cos cos.')
for a in ['c5.A3.SS2.p5.2','c5.A3.Ex91']:e(a,'c5.A3.Ex92','A3.Ex92','Product-to-sum split into j±k.')
for a in ['c5.A3.Ex92','c5.A3.SS2.p4.2']:e(a,'c5.A3.Ex93','A3.Ex93','Zero/nonzero frequencies give diagonal/off-diagonal cases.')
e('standing.range','c5.A3.Ex93','A3.SS2.p5.3','The following source sentence discharges the nonzero frequency ranges for the preceding entry calculation.','Explicit source arithmetic discharge at consumer')
for a in ['c5.constant-sum','c5.mixed-sum','c5.A3.Ex93','standing.range']:e(a,'c5.A3.SS2.p5.3','A3.SS2.p5.3','Entry cases, frequency checks and symmetry cover the full Gram matrix.')
e('c5.A3.SS2.p5.3','c5.t-Gram','A3.SS2.p5.3','Exact unweighted Gram identity.')
e('c2.t','c5.t-norm-proof','A3.Ex102','Literal feature norm and cos^2<=1.')
e('c5.t-norm-proof','c5.t-norm','A3.Ex102','Source2r norm bound.')
e('c2.gamma','cutoff.R','A3.SS2.p10.m2','Actual squared radius.')
e('c2.r','cutoff.L','A3.SS2.p10.m1','Exact cutoff cardinality.')
for a in ['c2.gamma','c2.t','cutoff.R','cutoff.L']:e(a,'Yi.literal','A3.Ex107','Literal actual-Y definition.')
e('Yi.literal','center.Z','A3.SS2.p13.1','Center actual Y by its own actual expectation.')

# Source author's fourth-moment, squared-expression, PSD and centering uses.
for a in ['c2.row-law','fourth.invocation']:e(a,'fourth.off-diagonal','A3.SS2.p14.2','Standard Gaussian sign symmetry for off-diagonal entries.')
for a in ['c2.row-law','fourth.invocation']:e(a,'fourth.diagonal','A3.SS2.p14.2','Gaussian fourth/second scalar moments give3+(r-1).')
for a in ['fourth.off-diagonal','fourth.diagonal']:e(a,'fourth.actual-row-moment','A3.SS2.p14.2','Indeed paragraph explains the full Ex113 matrix identity.')
for a in ['c2.gamma','cutoff.R']:e(a,'square.gaussian-rank-one','A3.SS2.p14.2','Actual Gaussian rank-one square identity.')
e('c2.t','square.feature-rank-one','A3.SS2.p14.2','Literal feature rank-one square identity.')
for a in ['Yi.literal','square.gaussian-rank-one','square.feature-rank-one']:e(a,'square.actual-Y','A3.Ex114','Both source rank-one square identities produce the actual matrix square.')
e('square.actual-Y','square.drop-indicator','A3.SS2.p14.3','Source PSD expression permits cutoff dropping; positivity proof remains internal.')
for a in ['square.drop-indicator','fourth.actual-row-moment']:e(a,'square.sum-first-order-bound','A3.Ex115','Drop cutoff, integrate and use r+2 moment matrix in finite sum.','Source-supported omitted matrix integral/order transport')
for a in ['square.sum-first-order-bound','c5.t-norm']:e(a,'square.sum-use-t-norm',['A3.Ex116','A3.SS2.p14.4'],'Explicit source t-norm use with PSD factors.')
for a in ['square.sum-use-t-norm','c5.t-Gram']:e(a,'square.sum-final',['A3.Ex117','A3.SS2.p14.4'],'Explicit source unweighted Gram use and tensor identity simplification.')
e('square.explicit-C5-use','square.sum-use-t-norm','A3.SS2.p14.4','Source explicitly attributes t-norm use.','Explicit source reuse marker')
e('square.explicit-C5-use','square.sum-final','A3.SS2.p14.4','Source explicitly attributes unweighted Gram use.','Explicit source reuse marker')
e('center.Z','center.square-mean-identity','A3.Ex118','Actual mean centering, with omitted noncommutative integral algebra.')
e('center.square-mean-identity','center.square-PSD-comparison','A3.Ex118','Subtract the actual mean square, whose PSD is an internal obligation.')
for a in ['center.square-PSD-comparison','square.sum-final','center.v']:e(a,'center.variance-assertion',['A3.SS2.p14.5','A3.Ex119'],'Source variance parameter uses the uncentered bound and centered comparison.')
for a in ['center.Z','c2.n']:e(a,'weighted.square-mean-identity','A3.Ex120','Deterministic cosine weight squares as source n=2q+1.')
for a in ['weighted.square-mean-identity','weight.cos-bound']:e(a,'weighted.square-PSD-comparison','A3.Ex120','Cosine-square factor<=1 and PSD of centered-square mean are required.')
for a in ['weighted.square-PSD-comparison','center.variance-assertion']:e(a,'weighted.variance-assertion','A3.SS2.p14.6','Same variance parameter for cosine-weighted centered sequence.')

# Explicit internal applicability ports and exact sealed target correspondence.
for a in ['c2.row-law','c2.gamma']:e(a,'INTERNAL.row-law','A3.Ex113','Match actual row-law application without caller certificate.','INTERNAL applicability')
for a in ['INTERNAL.row-law','fourth.actual-row-moment']:e(a,'INTERNAL.fourth-moment','A3.Ex113','Exact actual fourth-moment/integrability application.','INTERNAL applicability')
e('square.actual-Y','INTERNAL.matrix-square','A3.Ex114','Verify ordinary multiplication and exact source identity in sealed definitions.','INTERNAL literal algebra')
for a in ['INTERNAL.matrix-square','INTERNAL.fourth-moment']:e(a,'INTERNAL.square-integrability','A3.Ex115','Discharge actual-square and majorant integrability internally.','INTERNAL integrability')
e('Yi.literal','INTERNAL.pointwise-PSD','A3.SS2.p14.3','Hermitian/quadratic PSD from literal actual rank-one tensors.','INTERNAL positivity')
for a in ['INTERNAL.pointwise-PSD','INTERNAL.matrix-square','square.drop-indicator']:e(a,'INTERNAL.cutoff-order','A3.SS2.p14.3','Justify source cutoff dropping in full PSD order.','INTERNAL positivity/order')
for a in ['INTERNAL.cutoff-order','INTERNAL.square-integrability']:e(a,'INTERNAL.integral-order','A3.Ex115','Integrate and sum PSD differences under justified hypotheses.','INTERNAL integral order')
for route in ['INTERNAL.tensor-CLM','INTERNAL.tensor-entries']:
 for a in ['INTERNAL.fourth-moment','INTERNAL.square-integrability']:e(a,route,'A3.Ex115','Input for this alternative expectation-transport bookkeeping route.','INTERNAL alternative route')
for a in ['c5.t-norm','c5.t-Gram','c2.t','grid.theta']:e(a,'INTERNAL.literal-frame','A3.SS2.p14.4','Match exact literal definitions to required source identities.','INTERNAL applicability')
for a in ['INTERNAL.integral-order','INTERNAL.tensor-transport','INTERNAL.literal-frame','standing.range']:e(a,'INTERNAL.uncentered-algebra',['A3.Ex116','A3.Ex117'],'Exact finite tensor/order/denominator algebra for actual source sum.','INTERNAL algebra')
e('INTERNAL.square-integrability','OUTPUT.Y-squares-integrable','A3.Ex114','Producer all-actual-square integrability output.','Sealed target correspondence')
e('INTERNAL.uncentered-algebra','OUTPUT.uncentered-PSD','A3.Ex117','Producer full PSD difference output.','Sealed target correspondence')
for a in ['OUTPUT.Y-squares-integrable','OUTPUT.uncentered-PSD']:e(a,'FORMAL.producer','A3.Ex117','Exact producer conjunction, still unproved.','Sealed target correspondence')
e('Yi.literal','INTERNAL.Y-integrable-direct','A3.SS2.p13.1','Actual mean requires actual Y integrability, internally obtainable from literal maps.','INTERNAL alternative route')
e('Yi.literal','INTERNAL.Y-integrable-reuse','A3.SS2.p13.1','Exact verified public provider could justify this integrability; no provider has been inspected here.','INTERNAL alternative route, no compiled parent')
for a in ['INTERNAL.Y-integrable','INTERNAL.pointwise-PSD']:e(a,'INTERNAL.mean-Hermitian','A3.Ex118','Actual mean is Hermitian; actual mean square PSD.','INTERNAL integral/positivity')
for a in ['FORMAL.producer','INTERNAL.Y-integrable','center.Z']:e(a,'INTERNAL.centered-square-integrable','A3.Ex118','Material producer square-integrability plus actual mean linear/mixed terms.','INTERNAL intended consumer use')
for a in ['INTERNAL.Y-integrable','INTERNAL.centered-square-integrable','center.Z']:e(a,'INTERNAL.centering-algebra','A3.Ex118','Both noncommutative cross terms and actual mean identity, no commuting premise.','INTERNAL integral algebra')
for a in ['FORMAL.producer','INTERNAL.centering-algebra','INTERNAL.mean-Hermitian']:e(a,'INTERNAL.centered-order','A3.Ex118','Actual producer sum bound plus subtraction of PSD mean square.','INTERNAL intended consumer use')
for a in ['INTERNAL.pointwise-PSD','INTERNAL.mean-Hermitian','INTERNAL.centered-square-integrable']:e(a,'INTERNAL.centered-PSD','A3.Ex120','Actual centered squares and their expectations/sums are PSD.','INTERNAL positivity/integral')
for a in ['INTERNAL.centered-PSD','INTERNAL.centered-order','weight.cos-bound','INTERNAL.centered-square-integrable']:e(a,'INTERNAL.weighted-order','A3.Ex120','Exact cosine square scaling and finite sum comparison.','INTERNAL weighted order')
for a in ['INTERNAL.centered-PSD','INTERNAL.centered-order','center.v','standing.range']:e(a,'INTERNAL.unweighted-PSD-to-norm',['A3.SS2.p14.5','A3.Ex119'],'Upper and lower PSD, exact C>=0 and Euclidean operator-norm conversion.','INTERNAL norm applicability')
for a in ['INTERNAL.centered-PSD','INTERNAL.weighted-order','center.v','standing.range']:e(a,'INTERNAL.weighted-PSD-to-norm',['A3.SS2.p14.6','A3.Ex120'],'Weighted upper/lower PSD and true Euclidean operator-norm conversion.','INTERNAL norm applicability')
e('INTERNAL.centered-square-integrable','OUTPUT.centered-integrability','A3.Ex120','Both actual centered-square integrability conclusions.','Sealed target correspondence')
e('INTERNAL.unweighted-PSD-to-norm','OUTPUT.unweighted-norm','A3.SS2.p14.5','First exact variance-sum norm output.','Sealed target correspondence')
e('INTERNAL.weighted-PSD-to-norm','OUTPUT.weighted-norm','A3.SS2.p14.6','Second exact variance-sum norm output.','Sealed target correspondence')
for a in ['OUTPUT.centered-integrability','OUTPUT.unweighted-norm','OUTPUT.weighted-norm']:e(a,'FORMAL.private-consumer',['A3.Ex118','A3.Ex120'],'Exact private consumer conjunction, no implementation call observed.','Sealed target correspondence')

graph={'version':1,'phase':'SOURCE_GRAPH_AFTER_INDEPENDENT_TYPE_VERDICT_FREEZE','bindings':bindings,'source_root_full_path':str(BASE),'original_pinned_source_full_path':str(ROOT/'.astis/huanjian-resume-20261103/2610.20492v1.html'),'own_frozen_source_full_path':str(RAW/'inputs/2610.20492v1.html'),
 'roots':['FORMAL.producer','FORMAL.private-consumer'],'nodes':nodes,'edges':edges,
 'hyperedges':[{'id':'OR.tensor-integral-transport','premise_formula':'INTERNAL.tensor-CLM OR INTERNAL.tensor-entries','conclusion':'INTERNAL.tensor-transport','kind':'Alternative sufficient INTERNAL routes','status':'OPEN_UNPROVED','attribution':'Inferred formal bookkeeping options, not two source-author proofs.'},
 {'id':'OR.actual-Y-integrability','premise_formula':'INTERNAL.Y-integrable-direct OR INTERNAL.Y-integrable-reuse','conclusion':'INTERNAL.Y-integrable','kind':'Alternative sufficient INTERNAL routes','status':'OPEN_UNPROVED','attribution':'Direct derivation or exact public-provider applicability; no imported-name proof parent.'}],
 'genuine_source_gaps':[],'no_false_edges':['No joint row independence, weighted Gram, exact scalar-a/first-mean certificate or R* bound is a prerequisite.','No ordinary matrix square replaced by entrywise square.','No PSD upper bound alone relabelled an operator-norm conclusion.','No default-zero integral substitutes for actual integrability/mean algebra.','All p15 Bernstein atoms excluded; no concentration/independence credit.'],
 'actual_new_target_compiled':False,'implementation_seen':False,'compiled_parents':[],
 'independent_topology_coverage_acceptance':'PENDING_DISTINCT_REVIEWER; extractor cannot approve own coverage.','permission_or_status_grant':False}
dump('source-proof-graph.json',graph)
post=[]
for x in inv['items']:
 v=dict(x);v['post_seal_disposition']=x['disposition'];v['disposition_changed']=False;v['post_seal_status']='SOURCE_REPRESENTED_NOT_PROVED' if x['disposition']=='NODE' else 'OUTSIDE_SELECTED_TARGET'
 if x['id']=='fourth.invocation':v['audited_meaning_clarification']='Ex113 is the untruncated R_i gamma_i gamma_i^T mean. Raw retained-unrestricted wording is imprecise editorial wording only; exact source text, Ex113 atom and target are unambiguous.'
 post.append(v)
coverage=j(RAW/'coverage.json');dump('post-seal-coverage.json',{'bindings':bindings,'scope':inv['scope'],'items':post,'counts':inv['counts'],'window_locator':coverage['window_locator'],'units':coverage['units'],'source_numbering_note':coverage['source_numbering_note'],'type_induced_disposition_changes':[],'p15_all_excluded':True,'source_root_full_path':str(BASE),'independent_coverage_acceptance':'PENDING_DISTINCT_REVIEWER','whole_paper_coverage':False})
write('source-reading-report.md','Source graph constructed only after type-audit.json froze. All105 raw-v2 atom dispositions remain intact(50NODE/55EXCLUDED), including every p15 Bernstein context atom EXCLUDED. Source Ex113 fourth moment, Ex114 actual ordinary square, Ex115–117 PSD aggregate and Ex118/120 centered/weighted comparisons remain source-ordered with direct consumer-use locators. Exact typed roots add square-integrability outputs and real Euclidean operator-norm variance conclusions, with actual Yi integrability, noncommutative mean algebra, complete Hermitian/quadratic positivity and PSD-to-norm applicability left INTERNAL. No genuine SOURCE_GAP was found. Tensor integral and actual-Y integrability alternatives are OR, never false ANDs or guessed compiled parents. Raw phrase retained-unrestricted in the fourth-moment invocation is clarified as untruncated without rewriting originals. No target implementation/API/TC opinion or prior verdict was read to select topology. Distinct topology/coverage acceptance remains pending; no proof/status/permission grant.\n')
dump('graph-input-exposure-chronology.json',{'bindings':bindings,'chronology':'Own raw-v2 froze before this actor new type exposure; global seal existence before raw is not denied. Independent exact type verdict froze before this graph was constructed. Raw originals and type freeze preserved byte-for-byte.',
 'read_allowlist':'Own mv raw-v2 source/protocol artifacts and just-frozen type packet/verdict only. No implementation Lean, TC opinion, old verdict or other graph read to choose topology.',
 'formalizer_API_pristine':False,'new_target_attempts':'Parent reports root new-target proof/API attempts0 and no compiled P/T; this actor saw none and did not independently inspect repository history.',
 'compiled_parent_boundary':'Prior R4/R5/R8 canonical reports remain context. No declaration or import name certifies public applicability, and no private canonical-row test import is assumed as a public provider.',
 'changes':'Only own new source graph directory and builder; no ledger/registry/C/Git/shared mutation.','no_grant':True})
write('README.md','R9 source graph after independent type verdict freeze. Read source-proof-graph.json, post-seal-coverage.json and internal-ports-and-source-gaps.json. All ordinary applicability/algebra remains unproved INTERNAL, no genuine SOURCE_GAP found. OR options are explicit. Actual new P/T is unproved; no compiled parents or permission/status grant. Distinct source-topology/coverage review remains pending.\n')
m={'format':'astis-matrix-variance-source-graph-freeze-v1','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'phase':'GRAPH_AFTER_TYPE_VERDICT','bindings':bindings,'source_root_full_path':str(BASE),'files':[]}
for f in sorted(OUT.rglob('*')):
 if f.is_file():b=f.read_bytes();m['files'].append({'path':str(f.relative_to(OUT)),'bytes':len(b),'sha256':sha(b)})
dump('freeze-manifest.json',m);dig=sha((OUT/'freeze-manifest.json').read_bytes());write('freeze-manifest.sha256',dig+'  freeze-manifest.json\n')
for f in OUT.rglob('*'):
 if f.is_file():f.chmod(0o444)
for d in sorted([d for d in OUT.rglob('*') if d.is_dir()],key=lambda d:len(d.parts),reverse=True):d.chmod(0o555)
OUT.chmod(0o555)
print(json.dumps({'source_root_full_path':str(BASE),'graph_freeze_path':str(OUT),'graph_sha256':sha((OUT/'source-proof-graph.json').read_bytes()),'coverage_sha256':sha((OUT/'post-seal-coverage.json').read_bytes()),'ports_sha256':sha((OUT/'internal-ports-and-source-gaps.json').read_bytes()),'graph_manifest_sha256':dig,'nodes':len(nodes),'edges':len(edges),'OR_routes':len(graph['hyperedges']),'internal_ports':len(ports),'genuine_source_gaps':[]},indent=2))
