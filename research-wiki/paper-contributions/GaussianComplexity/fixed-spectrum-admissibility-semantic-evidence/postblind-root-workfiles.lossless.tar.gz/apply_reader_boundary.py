from pathlib import Path
import json,gzip,hashlib,sys
sys.path.insert(0,'tools'); import astis_publication as pub; import astis_semantic_roundtrip as rt
sha=lambda b:hashlib.sha256(b).hexdigest()
b=Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-admissibility-semantic-evidence/reader-boundary-correction')
proposal=b/'proposal.json'; assert sha(proposal.read_bytes())=='bbec9dc0e0939c711a7556d2e9646adb45e0cde3eab1a85ed339207c2a38a629'
review=Path(sys.argv[1]); assert sha(review.read_bytes())==sys.argv[2]
v=json.loads(review.read_bytes()); assert v['verdict']=='ACCEPT_EXACT_TWO_SCALAR_STATUS_CORRECTION_ONLY' and v['proposal_sha256']==sha(proposal.read_bytes()) and v['reviewer']=='/root/admiss_integration_reader'
ap=Path('research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-admissibility.json'); a=json.loads(ap.read_bytes()); assert a['state'] in ['draft','blind-reconstructed'] and a['source_review']['state']=='pending'
oldpacket=rt.decoder_packet(a); old_binding=a['publication_binding_sha256']
plans=[]
for row in json.loads(proposal.read_bytes())['paths']:
 p=Path(row['path']); assert sha(p.read_bytes())==row['before_sha256']; z=Path(row['planned_after_archive']); assert sha(z.read_bytes())==row['gzip_sha256']; raw=gzip.decompress(z.read_bytes()); assert sha(raw)==row['planned_after_sha256']; plans.append((p,raw))
for p,raw in plans:p.write_bytes(raw)
pub.inputs.cache_clear();pub.load.cache_clear(); item=next(x for x in pub.load() if x['id']=='huanjian-fixed-spectrum-admissibility'); binding=item['bindings'][0]
a['publication_binding_sha256']=pub.binding_digest(item,binding); a['publication_context']=pub.review_context(item,binding)
assert rt.decoder_packet(a)==oldpacket
ap.write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n');pub.check_advance([a['lean']['declaration']],reviewed=False)
record={'scope':'Independently reviewed authored status correction before source phase3; frozen historical seal unchanged.','proposal_sha256':sha(proposal.read_bytes()),'review':str(review),'review_sha256':sha(review.read_bytes()),'old_publication_binding_sha256':old_binding,'new_publication_binding_sha256':a['publication_binding_sha256'],'anonymous_packet_exactly_unchanged':True,'mathematical_code_unchanged':True,'source_review_pending':True,'paths':[{'path':str(p),'after_sha256':sha(raw)} for p,raw in plans]}
(b/'application-receipt.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
