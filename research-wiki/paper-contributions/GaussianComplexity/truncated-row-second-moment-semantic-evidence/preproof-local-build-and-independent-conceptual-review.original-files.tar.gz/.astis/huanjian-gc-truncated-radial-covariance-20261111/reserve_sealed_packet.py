"""Reserve the sealed source packet and preserve the current shared state."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys

sys.dont_write_bytecode = True
sys.path.insert(0, 'tools')
import astis_advance as advance
import astis_frontier_cells as frontiers

workspace = Path(__file__).resolve().parent.relative_to(Path.cwd())
paper = Path('research-wiki/paper-contributions/GaussianComplexity')
evidence = paper / 'truncated-row-second-moment-semantic-evidence'
seal_path = paper / 'truncated-row-second-moment-statement-seal-v2.json'
cell_path = Path('research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-truncated-row-second-moment.json')
ledger = Path('runs/substantive_advances.jsonl')
advance_id = 'ASTIS-SA-20261111-GaussianComplexityTruncatedRowMoment'
owner = 'huanjian_gc_20261111_truncated_row_moment'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def dump(obj):
    return (json.dumps(obj, ensure_ascii=False, indent=2) + '\n').encode()


def create(path, raw):
    with path.open('xb') as out:
        out.write(raw)


head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
assert head == 'dcf42d023d086798064d32758d2376d9d9a74c8a'
assert not subprocess.check_output(['git', 'diff', 'HEAD', '--name-only'])
seal_raw = seal_path.read_bytes()
assert sha(seal_raw) == 'ee9d261db9301f0fa750102f8105c27fbbbcef9e8a19f900636b705f461b18dd'
seal = json.loads(seal_raw)
P, T = [seal[key]['planned_file'] for key in ('producer', 'actual_private_consumer')]
assert not Path(P).exists() and not Path(T).exists() and not cell_path.exists()
ledger_raw = ledger.read_bytes()
assert sha(ledger_raw) == '5121a7cd12c33b690c651d1b0af8f7544071aebf9a90a1bcb98b40ed14165b24'
states = advance._replay_advances([json.loads(x) for x in ledger_raw.splitlines()])
assert advance_id not in states
assert states['ASTIS-SA-20261110-GaussianComplexityTruncatedRadialMoment']['state'] == 'VERIFIED'
frontier_hashes = {str(p): sha(p.read_bytes()) for p in cell_path.parent.rglob('*') if p.is_file() and not p.is_symlink()}
baseline = {
    'head': head, 'ledger_bytes': len(ledger_raw), 'ledger_sha256': sha(ledger_raw),
    'all_foreign_states': states,
    'all_existing_frontier_hashes': frontier_hashes,
    'tracked_git_index': subprocess.check_output(['git', 'ls-files', '--stage']).decode(),
    'scope': 'Private complete preservation state. Keep local. Never export the full replay.',
}
create(workspace / 'preproof-baseline.private.json', dump(baseline))
searches = [
    'Read the source-facing GaussianComplexity cosine-frame and Krylov declarations for the exact deterministic row conventions and actual downstream consumers.',
    'Reuse canonical stdGaussian, Euclidean norm and squared-norm moment nodes. This new source root is the unnormalized truncated matrix second moment.',
    'Audited actual Matrix vecMulVec/Kronecker/identity, canonical Gaussian, indicator, Bochner integral, and L2 operator norm definitions. Exact proof APIs remain for after accepted intake.',
]
slug = 'huanjian-gaussian-truncated-row-second-moment.json'
boundary = seal['scope_boundary']
cell = {
    'schema_version': 3, 'cell_id': cell_path.stem, 'route': 'samplewiki-route', 'mode': 'faithfulPaper',
    'title': 'Actual truncated Gaussian row second moment and single-summand mean',
    'source_anchor': 'arXiv2610.20492v1 C.2 Ex108 and p12.m5, with definitions in p1/p10 and the standing source range',
    'target_statement': seal['producer']['signature'] + '\nPrivate actual consumer\n' + seal['actual_private_consumer']['signature'],
    'status': 'claimed', 'owner_id': owner, 'advance_id': advance_id,
    'reservation_only': 'Exact-type reservation. Normal ledger intake has not occurred.',
    'parents': [], 'consumers': ['The actual private E[Y_i] Kronecker summand mean in C.2 p12.m5.'],
    'shared_floor_audit': {'searched': searches, 'classification': 'missing', 'decision': 'new_route_local',
                           'canonical_declaration': seal['producer']['name'], 'canonical_shared_cell': ''},
    'reuse_plan': {'searched_existing': searches, 'reused_declarations': [], 'new_shared_declarations': [],
                  'known_consumers': [], 'planned_consumers': [seal['actual_private_consumer']['name']],
                  'no_duplicate_wrapper': True,
                  'decision_reason': 'Prove the actual unnormalized truncated matrix second moment and consume it in the source single-row Y mean.'},
    'reader_contract': {'reference_standard': 'textbook/chapter-01/section-1-3.html',
                        **{k: False for k in ['source_ordered', 'source_statement_adjacent', 'natural_language_formula_proof',
                                             'hidden_assumptions_visible', 'lean_collapsed', 'external_dependencies_visible']},
                        'status': 'Prospective; exact source formula, assumptions, source steps and adjacent Lean will be authored after proof.'},
    'graph_contribution': {'lean_view': 'new-node', 'overview_view': 'no-change-with-reason', 'functor_view': 'pending-audit',
                          'edge_semantics': 'formal-solid; overlays-dashed', 'color_semantics': 'evidence-status; library-scope',
                          'focus_targets': [seal['producer']['name']],
                          'visual_review': 'Source graph/type review underway. Compiled parents require actual proof evidence.'},
    'learning_contract': {
        'control_plane_math_authority': False, 'process_memory_checked': True, 'process_memory_ids': [],
        'failure_class': 'NONE',
        'salvage': {'required': False, 'status': 'not-applicable', 'reason': 'No target proof attempted.',
                    'promoted_fragments': [], 'discarded_fragments': []},
        'parallelism': {'decision': 'serial', 'direction_fingerprints': [],
                        'expected_information_gain': 'One Lean prover with independent source graph and different-role topology reviewers.',
                        'shared_verified_context_digest': ''},
        'cross_route_blind_spot_audit': {'required': False, 'status': 'not-applicable', 'evidence': '',
                                       'canonical_route': '', 'selection_reason': 'One source-facing implementation packet.'},
        'reader_backpressure': {'purification_status': 'pending', 'exposition_seal_status': 'pending', 'exposition_evidence': '',
                               'source_expansion_nodes': [], 'lean_expansion_nodes': [],
                               'assumptions_preserved': False, 'boundary_preserved': True}},
    'source_detail_audit': {
        'primary_edition': 'arXiv2610.20492v1 raw SHA ' + seal['source']['raw_sha256'],
        'primary_anchor': 'C.2 Ex108 and p12.m5',
        'detail_status': 'omitted',
        'gap': 'The source invokes radial symmetry and writes the tensor expectation. Matrix integrability, symmetry consequences, scalar identification and deterministic Kronecker interchange need internal proofs.',
        'consulted': [{'source': 'Pinned canonical Gaussian, Matrix and Bochner definitions',
                       'anchor': 'Current v2 exact definition context and actual sixteen-definition print',
                       'hypothesis_adapter': 'Use the actual standard law and Euclidean L2 operator matrix norm. Derive all symmetry and integration facts inside the proof.'}],
        'fidelity_boundary': boundary},
    'statement_seal': {'status': seal['state'], 'file': str(seal_path), 'sha256': sha(seal_raw),
                       'signature_sha256': seal['producer']['signature_sha256'],
                       'private_consumer_signature_sha256': seal['actual_private_consumer']['signature_sha256']},
    'evidence': {'actual_literal_formation': seal['actual_statement_formation'],
                 'actual_definition_meaning': seal['actual_definition_meaning'],
                 'normal_API_and_target_proof_calls': 0},
    'blocked': {'reason': '', 'children': []},
    'owned_files': [P, T, str(seal_path), str(paper / 'truncated-row-second-moment-statement-seal.json'),
                    str(cell_path), str(evidence) + '/',
                    'website/content/declaration_lessons/' + slug, 'website/content/publications/' + slug,
                    'research-wiki/semantic-roundtrip/audits/' + slug],
    'forbidden_shared_files': ['AutoSamplingTheory.lean', 'Tests.lean', 'AutoSamplingTheory/TechnicalLemmas/Registry.lean',
                               'website/content/source_correspondence.json', 'website/content/graph_memory_index.json',
                               'website/content/functor_hypergraph.json'],
    'truth_boundary': boundary, 'conceptual_mirror_audit': {'status': 'pending'},
}
create(cell_path, dump(cell))
errors = frontiers.validate_cells(frontiers.load_cells())
assert not errors, errors
assert ledger.read_bytes() == ledger_raw
for name, digest in frontier_hashes.items():
    assert sha(Path(name).read_bytes()) == digest, name
summary = {
    'baseline_commit': head, 'exact_seal_sha256': sha(seal_raw), 'cell': str(cell_path),
    'cell_sha256': sha(cell_path.read_bytes()), 'foreign_full_states_guarded': len(states),
    'older_frontier_files_guarded': len(frontier_hashes),
    'normal_API_and_proof_calls': 0, 'independent_topology_acceptance': 'pending',
}
create(workspace / 'actual-seal-and-reservation-summary.json', dump(summary))
print(json.dumps(summary))
