# Bias packet: independent raw-source cognition, phase1

This is a raw-source reconstruction only. No new Bias statement, signature, binder classification, extractor graph or admission verdict has been read or issued. Prior C7/grid/C8/actual-Gaussian-means/exact-means/Variances source and topology exposure is disclosed; this actor is not unfamiliar with the paper. The parent assignment itself supplied the topic and requested focus. No pristine-unfamiliarity or zero-cue claim is made.

Fresh reads for this packet were complete §2 (`S2`), complete §4 (`S4`, including §4.4), complete Appendix C.3 (`A3.SS3`), and the local bibliography entry referenced by §4 (`bib.bib3`). The sole paper input is the pinned 951991-byte HTML SHA-256 `6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915`. The unchanged earlier raw-only HTML parser was reused; no prior theorem/source graph, target implementation, API inventory or lesson was consulted.

## Standing meanings and quantifier scope

§2 fixes the Euclidean norm and matrix order. In the precision class A_{d,κ}, d≥1 and κ≥1, A is symmetric and I≤A≤κI. The target is the actual centered Gaussian π_A=N(0,A⁻¹); A is precision, not covariance. The exact first-order oracle returns (xᵀAx/2,Ax), and exact gradient/matrix-vector/value-and-gradient query access are equivalent on this class.

A randomized algorithm uses Borel queries/stopping/output functions of seed and prior responses, with seed independent of input. A fixed query budget is a deterministic per-run cap for every input and every seed, not an expected budget. The law ρ_A^Alg averages over the internal seed. The TV requirement is uniform in A. TV is the supremum over measurable sets, with the bounded-test-function consequence stated in §2; the later selected event must be measurable to use it.

§4.1 specializes to d≥2 and κ≥2 and defines θ_i=(i−1/2)π/d for source i=1,…,d, λ_i=(κ+1)/2+(κ−1)cosθ_i/2, and precision Λ=diag λ_i. A=OΛOᵀ with Haar O independent of algorithm seed. Spectrum and normalizing constant may be given to the algorithm; only eigenbasis is hidden. A future zero-based coordinate must represent source i=j+1, without altering the midpoint shift.

Lemma4.5's actual diagonal law is U~N(0,Λ⁻¹). M=E||U||² and μ_n=E[UᵀD_nU] with D_n=diag cos(nθ_i). It has integer mode 1≤n<d. This range does not require oddness, n=2q+1, a query budget, δ, or a κ-versus-d growth bound. Its variance claims do not require d−n≥√κ. The displayed two-sided normalized-bias conclusion is introduced conditionally by d−n≥√κ.

Theorem4.1 has the separate outer regime: each fixed δ∈(0,1) admits d0(δ), then every integer d≥d0, 2≤κ≤d^(1−δ), and 0<ε≤1/10 obey the lower bound δ√κ log d/256. This global regime must not be silently used as a premise of the source's general scalar/moment identities, or dropped when claiming the full query lower bound.

## C.3: what is actually normalized

C.3 first proves C7's inverse-spectrum cosine expansion, then C8's exact actual means, then variance and normalized-bias estimates. The C7 series is absolutely and uniformly convergent in θ for each retained κ. Its majorant ρ/(1−ρ) depends on κ; no uniform-in-κ bound is asserted.

The C8 route uses all-integer grid aliasing, including negative frequencies; actual Gaussian second moments give M=Σ λ_i⁻¹ and μ_n=Σ cos(nθ_i)/λ_i. Finite Gaussian expectation/sum identification is distinct from the absolutely convergent scalar series/finite-grid interchange. The positive series indices split into j=n, j=2ad+n (a≥1), and j=2ad−n (a≥1). The range 1≤n<d makes these classes positive/disjoint and validates the displayed parity. This is raw context, not a new proof of those previously reviewed pieces.

The exact formulas retained by C8 and Lemma4.5 are

```text
ρ=(√κ−1)/(√κ+1),
M=(d/√κ)(1−ρ^(2d))/(1+ρ^(2d)),
(−1)^n μ_n=(d/√κ)(ρ^n−ρ^(2d−n))/(1+ρ^(2d)).
```

Under d≥2, κ≥2 and 1≤n<d, 0<ρ<1 and n<2d−n. Thus the signed mean is strictly positive and M is positive; the raw source uses the sign to remove the absolute value before division. μ_n itself is negative for odd n and positive for even n. No assertion that μ_n is always positive is warranted.

β=|μ_n|/M is a **ratio of actual means**. It is neither E[|Q(U)|/||U||²] nor E[Q(U)/||U||²], and it is not a pointwise bound on a sampled normalized quadratic form. M and μ_n are not defined by their desired closed formulas. The trace notation in §4.3 identifies the same actual means and requires the actual Gaussian mean bridge.

At `A3.SS3.p9.1`/Ex150, division of the two exact formulas yields

```text
β = ρ^n · (1−ρ^(2(d−n)))/(1−ρ^(2d)).
```

The real/natural/integer differences 2d−n and d−n must agree on the source range; no truncated-subtraction identity is valid without that range. Positive denominators and M>0 justify the division. From 0<ρ^(2d)<ρ^(2(d−n))<1, Ex151 gives

```text
1−ρ^(2(d−n)) ≤ (1−ρ^(2(d−n)))/(1−ρ^(2d)) ≤ 1.
```

The upper β≤ρ^n is already valid on the base source mode range. The constant lower prefactor 1−e^(−4) additionally uses the separation condition below. The original displayed two-sided Lemma4.5 is conditional; a future stronger standalone upper statement would need its intermediate-source provenance explicitly explained rather than pretending the displayed theorem had a different binder list.

## C.3: logarithm and exponential estimates

Ex152–154 are aligned TBODY rows, not standalone outer display tables. They state

```text
log(1/ρ) = log((√κ+1)/(√κ−1))
         = 2∫[0,1/√κ] 1/(1−t²) dt
         = 2/√κ + 2∫[0,1/√κ] t²/(1−t²) dt.
```

Here κ≥2 implies √κ>1 and the integration endpoint is strictly between 0 and 1. Every logarithm argument is positive; the integration denominator is positive throughout the interval. The source omits the antiderivative/change-of-expression, continuity/integrability and endpoint arithmetic details. These are internal background bridges, not new source assumptions or a free integral certificate.

The nonnegative remainder yields log(1/ρ)≥2/√κ. On the interval, 1−t²≥1−κ⁻¹>0. Ex155–156 therefore estimate the remainder by the integral of t² and obtain

```text
log(1/ρ) ≤ (2/√κ)(1+1/(3(κ−1)))
         ≤ 8/(3√κ) < 3/√κ.
```

The numerical 8/3 bound uses κ≥2. It is not a general κ>1 uniform constant. Ex157 weakens the strict upper log estimate and exponentiates to

```text
exp(−3n/√κ) ≤ ρ^n ≤ exp(−2n/√κ).
```

The log/power relation and reversal after multiplying by a negative scalar require their usual positivity and n≥0 facts; the source integer n is positive. No API/formalization route was inspected.

`A3.SS3.p11.1` and Ex158 use **d−n≥√κ** specifically to get

```text
ρ^(2(d−n)) = exp(−2(d−n) log(1/ρ))
          ≤ exp(−4(d−n)/√κ) ≤ exp(−4).
```

This is where the remainder factor becomes uniformly bounded below. Together with Ex150–151 and Ex157, Ex159 yields the source two-sided bound

```text
(1−exp(−4)) exp(−3n/√κ) ≤ β ≤ exp(−2n/√κ).
```

The ratio identity, log estimates, power estimates, separation remainder estimate and final two-sided bound are distinct source claims. The separation condition cannot be moved onto the earlier log-only estimate, nor omitted from the constant lower-bias conclusion. κ=1, n=d, M=0 or an off-range index do not inherit these derivations; in particular n=d destroys the strictly positive signed numerator. No off-domain fallback interpretation is provided by the raw source.

## Probability mechanism and its independent guards

§4.2's algorithm route first couples the adaptive output to a block Krylov space generated by q+1 independent standard Gaussian vectors. It uses n=2q+1 and q≥0, 2q+1<d. The polynomial coefficients may depend on the full experiment, so the subsequent bound is uniform over every vector in the space; independence of the output from its generators is not assumed. The coupling must preserve the joint (O,X) law.

The concrete threshold is τ_dq=C[(q+1)√(log d/d)+(q+1)(q+1+log d)log d/d], for an absolute C>0. Lemma4.4 is conditional on τ_dq≤1/2 and then gives the uniform **2τ_dq** bound with probability ≥0.99. In §4.3, the original q/κ/δ regime proves n=o(d) and τ→0 uniformly; sufficiently large d supplies n<d and the half-threshold, rather than introducing them as unproved new global assumptions.

The test is the actual polynomial statistic

```text
S_A(x)=(−1)^n xᵀ T_n((2A−(κ+1)I)/(κ−1))x − 2τ||x||²,
E_A={x:S_A(x)>0}.
```

The Chebyshev-polynomial identity T_n(cosθ_i)=cos(nθ_i), orthogonal conjugation and the actual law transport are needed to identify its diagonal form. The geometric normalized-energy description assumes x≠0 only to divide by ||x||²; S_A and its strict event are defined at zero, where S_A(0)=0 and zero does not pass. No x≠0 hypothesis is intrinsic to the polynomial statistic or its moment bound.

On the algorithm's ≥0.99 good event, |XᵀOD_nOᵀX|≤2τ||X||² implies S_A(X)≤0. This yields the **averaged-over-input** passing probability E_A[ρ_A^Alg(E_A)]≤0.01. It is not a pointwise-in-A algorithm bound and is not the target-law variance estimate.

The target sample has conditional law Y|O~π_A. For each fixed O/A, U=OᵀY has N(0,Λ⁻¹) law, ||Y||²=||U||², and the rotated cosine form becomes UᵀD_nU. Y is not asserted independent of O; no Haar averaging is needed for the pointwise target estimate. This actual-law transport and the polynomial identity are separate from the scalar β bound.

In §4.3, the q bound and κ≤d^(1−δ) first ensure d−n≥√κ for sufficiently large d. Ex23 uses the exponential lower-bias estimate and 3n/√κ≤3+(3δ/128)log d to obtain β≥b d^(−δ/4), with b=(1−e^(−4))e^(−3)>0. A weaker power estimate ρ≤e^(−1/√κ), together with d≥√κ, yields ρ^(2d)≤e^(−2)<1/3. The closed M formula then gives M≥d/(2√κ)≥d^((1+δ)/2)/2. These are additional source bridges; a β estimate alone gives neither M lower nor a passing probability.

Ex24 bounds τ/β→0 and Mβ²→∞ uniformly over the stated regime. The common d0(δ) is then chosen to retain original algorithmic applicability **and** ensure τ≤β/4 and Mβ²≥320. These two guards serve different later steps. Nonnegativity of concrete τ follows from its formula/C>0/d≥2; it is not a new arbitrary threshold parameter in the raw source.

For fixed A, Z=S_A(Y) has EZ=(β−2τ)M≥βM/2>0, using the signed mean, M>0, β>0 and τ≤β/4. Its variance uses both actual quadratic variances≤2M and the centered L2 triangle, with scalar coefficient magnitude |(−1)^n|=1:

```text
Var Z ≤ (√(2M)+2τ√(2M))² ≤ 8M.
```

The last variance constant uses 0≤τ≤1/2. Q(Y) and ||Y||² are generally dependent; their independence is not used. Actual L2/finiteness and linearity of centering are omitted analytic background. Neither the exact value of VarZ nor a new independent-Gaussian-coordinate assumption on the ambient rotated Y is stated.

Ex26 applies Chebyshev to the complement Z≤0 of the **strict** passing event. Positive EZ is necessary: on Z≤0, |Z−EZ|≥EZ. Its displayed chain is

```text
P(Z>0) ≥ 1−VarZ/(EZ)² ≥ 1−32/(Mβ²) ≥ 0.9.
```

The 320 threshold serves this final numerical probability bound, not the exponential-bias lemma or the contrast-variance bound. Event measurability, actual probability law and finite second moment are required internally. The source does not supply these as free theorem-shaped premises.

The final TV contradiction uses the per-input uniform guarantee to bound π_A(E_A)−ρ_A^Alg(E_A)≤ε, then averages over the hard-family input. Pointwise target ≥0.9 and averaged algorithm ≤0.01 give a gap ≥0.89, contradicting ε≤0.1. A local ratio/log estimate cannot be promoted to a TV/query lower bound without these separate probability, transport, admissibility and algorithmic obligations.

## Complete Section4 limitations and source boundaries

§4.4 explicitly concerns this proof method, not an impossibility theorem for the fixed-spectrum family. Lemma4.7 states dim K_q=min{d,(q+1)²} almost surely. Once the enlarged Krylov space is full, the midpoint identity Σ cos²(nθ_i)=d/2 (for 1≤n<d) supplies a coordinate with magnitude at least 1/√2 and hence a uniform supremum lower bound. The method then cannot sustain a vanishing small uniform threshold.

There is a literal threshold distinction to preserve: the §4.4 sentence says the separating test requires this supremum at most 1/2, whereas Lemma4.4's stated condition is τ≤1/2 with conclusion supremum≤2τ. The latter condition alone gives ≤1, not ≤1/2. The earlier large-d τ→0 could support a stricter small-τ choice; that additional numerical choice is not the same as the lemma's displayed guard. This is a raw-source clarification to retain, not a new target HOLD or an authorized source repair.

The accuracy limitation requires an algorithm-side threshold t≥a and target-side t<β. It also invokes the Bernstein calculation of FactC6 to require a≥c/√d even to certify failure probability below one. That FactC6 proof is outside this fresh C.3/§4/§2 read; its invocation is inventoried, not independently reconstructed here. Combining the exponential β upper bound with n=2q+1 yields q=O(√κ log d) irrespective of ε. The source's upper β estimate is available from its earlier general-range intermediate derivation; the full two-sided displayed bias theorem had an additional separation condition. The source does not claim stronger accuracy lower bounds for the same family are false, only that this method cannot obtain them by retuning its threshold/constants.

The raw text's historical [22] references are recorded, with their local bibliography identity. No external preprint was opened. Appendix C.1/C.2/C.4 and FactC6 proof contents were not newly read in this packet. Gaussian moment/rotation facts, scalar logarithm integration, continuity/integrability, positivity and concentration/probability interfaces are background obligations, not API evidence gathered in phase1.

## Stop boundary

The inventory is raw, with original offsets/hashes, math and link registries and ordinal-disambiguated anonymous locators. It makes no NODE/EXCLUDED target disposition, no statement verdict, no source-graph admission and no proof credit. The prior Variances process role disclosed accidental preseal variance API-name/signature-line exposure by root; this actor saw the disclosure, not that inventory. Earlier strict signatures/standard definitions and accepted source graphs were seen in their authorized stages. Those exposures are retained honestly, but no new Bias seal/signature, extractor input, implementation, API/Mathlib file, audit or lesson was opened for this raw freeze.

Only this new phase1 directory was written. No proof, Lean/build, normal API, ledger/frontier/shared/site mutation, browser/network action, source V, queue or Goal completion was performed. Stop after this raw-first freeze and wait for exact next-stage authority.
