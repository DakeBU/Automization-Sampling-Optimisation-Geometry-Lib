from pathlib import Path
from html.parser import HTMLParser
import hashlib,json,re,html

ROOT=Path('/Users/zhouhuanjian/ASTIS-GC')
OWN=ROOT/'.astis/semantic-neutral-20261110/tau_tc_19abf4'
OUT=OWN/'phase2b'
INPUT=OUT/'inputs';INPUT.mkdir(parents=True,exist_ok=True)
WHITELIST=ROOT/'.astis/semantic-neutral-20261110/tau_sg_74c208/phase2/reviewer-read-whitelist.json'
wraw=WHITELIST.read_bytes()
assert hashlib.sha256(wraw).hexdigest()=='d5e3a693fbaa89766feb54c14f247885e108994b3adaec000ffea5c0b6cea82b'
(INPUT/'reviewer-read-whitelist.json.raw').write_bytes(wraw)
whitelist=json.loads(wraw)
loaded={};input_log=[]
for row in whitelist['allowed_files']:
    p=Path(row['path']);b=p.read_bytes()
    assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256'],p.name
    (INPUT/(p.name+'.raw')).write_bytes(b)
    loaded[p.name]=b if p.name.endswith('.html') else json.loads(b)
    input_log.append(row)
source=loaded['source.raw.html'];text=source.decode()
inventory=loaded['inventory.json'];records={r['stable_id']:r for r in inventory['records']}
assert len(records)==len(inventory['records'])
for r in records.values():
    b=source[r['start_byte']:r['end_byte_exclusive']]
    assert len(b)==r['length'] and hashlib.sha256(b).hexdigest()==r['sha256'],r['stable_id']
intervals=loaded['raw-source-intervals.json']['selected_intervals']
partition=loaded['raw-coverage-partition.json'];residuals=[]
class Plain(HTMLParser):
    def __init__(self):super().__init__();self.data=[]
    def handle_data(self,d):self.data.append(d)
for interval in intervals:
    a=interval['start_byte'];z=interval['end_byte_exclusive'];b=source[a:z]
    assert len(b)==interval['length'] and hashlib.sha256(b).hexdigest()==interval['sha256']
    parts=[p for p in partition if p['region']==interval['name']]
    cursor=a
    for p in parts:
        assert p['start_byte']==cursor
        pb=source[p['start_byte']:p['end_byte_exclusive']]
        assert len(pb)==p['length'] and hashlib.sha256(pb).hexdigest()==p['sha256']
        for ident in p['inventory_covering']:
            r=records[ident];assert r['start_byte']<=p['start_byte'] and p['end_byte_exclusive']<=r['end_byte_exclusive']
        if not p['inventory_covering']:
            q=Plain();q.feed(pb.decode());t=' '.join(''.join(q.data).split())
            if t:residuals.append({'region':p['region'],'start_byte':p['start_byte'],'text':t})
        cursor=p['end_byte_exclusive']
    assert cursor==z

graph=loaded['source-graph.json'];nodes={n['id']:n for n in graph['nodes']};edges=graph['hyperedges']
assert len(nodes)==len(graph['nodes'])
for n in graph['nodes']:
    for row in n.get('source_use_regions',[]):
        r=records[row['inventory_id']]
        for k in ['source_id','start_byte','end_byte_exclusive','sha256']:assert row[k]==r[k],(n['id'],k)
for e in edges:
    assert e['conclusion'] in nodes
    for p in e['premises']:assert p in nodes
    for row in e.get('consumer_use_sites',[]):
        r=records[row['inventory_id']]
        for k in ['source_id','start_byte','end_byte_exclusive','sha256']:assert row[k]==r[k],(e['id'],k)
def closure(root):
    seen=set();seen_edges=set()
    def visit(node):
        if node in seen:return
        seen.add(node)
        for e in edges:
            if e['conclusion']==node:
                seen_edges.add(e['id'])
                for p in e['premises']:visit(p)
    visit(root)
    return {'nodes':sorted(seen),'hyperedges':sorted(seen_edges)}
for c in graph['closures']:
    computed=closure(c['root'])
    assert c['nodes']==computed['nodes'] and c['hyperedges']==computed['hyperedges'],c['root']
for filename,expected_ids in [('record-coverage.json',set(records)),('paragraph-coverage.json',{r['stable_id'] for r in records.values() if r['layer']=='paragraph'})]:
    coverage=loaded[filename];ids={r['inventory_id'] for r in coverage};assert ids==expected_ids and len(ids)==len(coverage)
    for row in coverage:
        assert row['disposition']==records[row['inventory_id']]['disposition']
        for node in row['graph_nodes']:assert node in nodes
        if row['disposition']=='NODE':assert row['graph_nodes']

statements=loaded['exact-statements.json'];prior=json.loads((OWN/'phase2a/projection-v1.json.raw').read_text())
assert statements['producer']['signature']==prior['producer']['signature']
assert statements['private_consumer']['signature']==prior['actual_private_consumer']['signature']
for k in ['producer','private_consumer']:
    assert hashlib.sha256(statements[k]['signature'].encode()).hexdigest()==statements[k]['signature_sha256']
assert nodes['producer']['claim']==statements['producer']['signature']
assert nodes['private-consumer']['claim']==statements['private_consumer']['signature']

line_starts=[0]+[m.end() for m in re.finditer('\n',text)]
class IndependentTree(HTMLParser):
    def __init__(self):super().__init__(convert_charrefs=False);self.stack=[];self.math_records=[]
    def pos(self):
        l,c=self.getpos();return line_starts[l-1]+c
    def handle_starttag(self,t,a):
        d=dict(a);r={'tag':t,'attrs':d,'start':self.pos()}
        if t not in {'area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr'}:self.stack.append(r)
    def handle_endtag(self,t):
        for j in range(len(self.stack)-1,-1,-1):
            if self.stack[j]['tag']==t:
                r=self.stack[j];del self.stack[j:];r['end']=text.index('>',self.pos())+1
                a=r['attrs'];cls=a.get('class','')
                if (t=='p' and 'ltx_p' in cls) or (t=='math' and a.get('display')=='block') or (t=='table' and 'ltx_equation' in cls) or t=='cite':
                    aa=len(text[:r['start']].encode());zz=len(text[:r['end']].encode())
                    if any(i['start_byte']<=aa and zz<=i['end_byte_exclusive'] for i in intervals):
                        covered=[v['stable_id'] for v in records.values() if v['start_byte']<=aa and zz<=v['end_byte_exclusive']]
                        self.math_records.append({'source_id':a.get('id'),'tag':t,'start_byte':aa,'end_byte_exclusive':zz,'inventory_covering':covered})
                return
t=IndependentTree();t.feed(text)
uncovered=[r for r in t.math_records if not r['inventory_covering']]

generic_closures={k:closure(k) for k in ['generic-means','generic-variance','generic-sign-ratio','generic-bias']}
result={'input_files':input_log,'source_sha256':hashlib.sha256(source).hexdigest(),'all_raw_record_interval_partition_digests_valid':True,'all_node_edge_raw_locators_valid':True,'all_declared_closures_match_independent_recomputation':True,'all_coverage_ids_and_dispositions_match':True,'exact_signatures_match_statement_phase':True,'independent_selected_p_display_citation_count':len(t.math_records),'uncovered_p_display_citation_elements':uncovered,'uncovered_readable_partition_residuals':residuals,'generic_closures':generic_closures,'boundary':'Structural and byte checks do not decide mathematical topology adequacy.'}
(OUT/'independent-structural-checks.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['input_files','generic_closures']},indent=2))
for k,v in generic_closures.items():print(k, 'has-selected-frequency', 'frequency' in v['nodes'] or 'selected-odd-adapter' in v['nodes'])
