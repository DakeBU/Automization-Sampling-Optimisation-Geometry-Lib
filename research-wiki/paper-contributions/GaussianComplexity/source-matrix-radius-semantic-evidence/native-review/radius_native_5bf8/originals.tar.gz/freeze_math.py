from runner import *
from collections import Counter
s=json.loads((OUT/'settings.json').read_text())
r=json.loads((OUT/'math-inspection-summary.json').read_text())
receipts=[(p,json.loads(p.read_text())) for p in (OUT/'receipts').glob('*.json')]
assert not list((OUT/'receipts').glob('*.pending.json'))
for p,x in receipts:
    assert sha(p.with_suffix('.stdout'))==x['stdout_sha256']
    assert sha(p.with_suffix('.stderr'))==x['stderr_sha256']
deps=[]
for p,x in receipts:
    if x['label'].startswith('native-deps-'):
        assert x['exit']==0
        lines=p.with_suffix('.stdout').read_text().splitlines()
        assert not any(str(ROOT/'.lake/build') in l for l in lines)
        actual=sorted(str(Path(s['native'])/(m.replace('.','/')+'.olean')) for m in s['imports'][x['label'][12:]] if m.startswith('AutoSamplingTheory.') or m.startswith('Tests.'))
        observed=sorted(l for l in lines if l.startswith(s['native']))
        assert observed==actual,(observed,actual)
        deps.append({'module':x['label'][12:],'actual_direct_native_imports':observed,'receipt':str(p.relative_to(OUT))})
assert len(deps)==8
builds=[x for p,x in receipts if x['label'].startswith('native-build-')];assert len(builds)==8 and all(x['exit']==0 for x in builds)
sv=json.loads((OUT/'seal-result.json').read_text());assert len(sv)==2 and all(x['fullUniversalTypeKernelDefEq'] and x['actualProofAtSealedTypeKernelChecked'] and x['genuineQ0ApplicationKernelChecked'] for x in sv)
failed=[{'label':x['label'],'exit':x['exit'],'receipt':str(p.relative_to(OUT))} for p,x in receipts if x['exit']]
# v1 was compiled before the source-save enhancement. Its exact source is reconstructed from the preserved patch and v2 bytes, not a fabricated rerun.
v2=(OUT/'Inspector.v2.lean').read_text()
v1=v2.replace('def jhints : ReducibilityHints → Json\n  | .opaque => toJson "opaque"\n  | .abbrev => toJson "abbrev"\n  | .regular h => Json.mkObj [("regular",toJson h)]\n','').replace('("reducibilityHints",jhints ci.hints)','("reducibilityHints",toJson (reprStr ci.hints))')
(OUT/'Inspector.v1.reconstructed.lean').write_text(v1)
judgment={
 'verifier_id':'radius_native_5bf8','math_candidate_commit':s['commit'],'toolchain':'Lean4.33.0 d8b18978322de05a8f3dba51ef03cf5461676c17',
 'manifest_packages':s['packages'],'initial_native_output_empty':True,'root_ASTIS_oleans_excluded':True,
 'actual_ASTIS_import_closure_rebuilt':s['order'],'actual_direct_import_resolutions':deps,
 'native_math_judgment':'ACCEPTED for bounded actual summand/actual mean and private centered/cosine-weighted radius only',
 'sealed_universal_statements':sv,'actual_declarations_kernel_checked':r['actual_declaration_count'],
 'owned_declarations':r['owned_declarations'],'owned_all_reachable':r['owned_all_reachable'],
 'actual_ASTIS_parents':{'P':r['actual_producer_ASTIS_parents'],'T':r['actual_consumer_ASTIS_parents']},
 'norm_meaning':'The complete P/T types kernel-match independently elaborated seal text under Matrix.Norms.L2Operator. Separate rfl kernel-compiled witnesses identify that norm with the continuous linear-map operator norm on EuclideanSpace ℝ, and identify its action with the actual matrix-vector product. The helpers prove outer-product and tensor identities for that actual norm.',
 'mathematical_route':'P proves the retained Gaussian radial moment lies in [0,r] and divides by r internally, gets literal Bochner means from the actual matrix-mean parent, obtains the feature squared-norm bound from the actual cosine-frame parent, and proves the pointwise/mean operator norm bounds using the three private rank-one helpers. T actually calls P, applies norm_sub_le to Y minus its actual integral, combines both bounds into exactly 2r(L+1)/d, then uses |cos|≤1 and norm_smul. No result is supplied as a binder.',
 'standard_axioms_only':['propext','Classical.choice','Quot.sound'],'open_expression_flags_all_false':True,
 'all_actual_ASTIS_type_and_value_inspections':'inspection/declarations.ndjson + inspection/expressions.ndjson are lossless DAG records, not truncated pretty printing. Exact names/levels/metadata use Lean repr; all expression constructors and child references are explicit.',
 'closure_reachability_scope':'All seven radius-owned declarations are reachable from P/T. The inspected eight-module closure contains44 declarations,37 reached from P/T; remaining7 are unchanged GridAlias declarations, separately kernel checked without calling them new radius credit.',
 'failed_attempts':failed,'failure_classification':'IMPLEMENTATION_FAILED for inspector serializer/syntax probes; ENV/API path discovery errors are retained separately. None refute mathematics.',
 'source_reconstruction_note':'Inspector v1 exact bytes reconstructed from preserved applied patch; v2 exact bytes retained as Inspector.v2.lean. Successful v3 and seal probes have pre-execution source snapshots. No approval wait or permission event is represented as a completed execution.',
 'receipt_scope':'All native rebuild, declaration, seal, q0 and norm acceptance executions have closed raw argv/cwd/HEAD/stdout/stderr/exit/hash receipts. Initial procedural discovery reads are tool-transcript observations, not acceptance receipts.',
 'remaining_boundary':'Independent source/reader/static metadata/publication/audit gates await exact packets. No Bernstein/probability tail/full Lemma4.4/main lower bounds/integration/purification/normalV credit.'}
(OUT/'math-judgment.json').write_text(json.dumps(judgment,indent=2)+'\n')
index={str(p.relative_to(OUT)):sha(p) for p in sorted(OUT.rglob('*')) if p.is_file() and p.name not in ['math-freeze-manifest.json']}
(OUT/'math-freeze-manifest.json').write_text(json.dumps({'frozen_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':index},indent=2)+'\n')
print(json.dumps({'judgment_sha256':sha(OUT/'math-judgment.json'),'math_freeze_sha256':sha(OUT/'math-freeze-manifest.json'),'source_sha256':sha(OUT/'snapshot-hashes.json'),'native_sha256':sha(OUT/'native-hashes.json'),'failed_attempt_count':len(failed),'actual_declarations':len(json.loads((OUT/'math-inspection-summary.json').read_text())['reachable_ASTIS_declarations'])},indent=2))
