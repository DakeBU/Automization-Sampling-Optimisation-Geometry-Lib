from pathlib import Path
import json, hashlib, gzip, tarfile, subprocess, shutil
sha=lambda b:hashlib.sha256(b).hexdigest()
b=Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-admissibility-semantic-evidence')
out=b/'actual-checks/completed-executions'
for p in sorted(Path('.astis/huanjian-resume-20261103').glob('*-fixed-spectrum-admissibility-*.receipt.json')):
 r=json.loads(p.read_bytes()); raw=Path(r['log']).read_bytes(); assert sha(raw)==r['log_sha256']
 if (out/p.name).exists(): continue
 shutil.copy2(p,out/p.name); z=out/(Path(r['log']).name+'.gz'); z.write_bytes(gzip.compress(raw,mtime=0)); assert gzip.decompress(z.read_bytes())==raw
private=Path('.astis/huanjian-fixed-spectrum-admissibility-20261107')
files=sorted(p for p in private.iterdir() if p.is_file())
archive=b/'compiled-local-root-workfiles.lossless.tar.gz'
assert not archive.exists()
with tarfile.open(archive,'w:gz') as t:
 for p in files:t.add(p,arcname=p.name,recursive=False)
with tarfile.open(archive,'r:gz') as t:
 for p in files:assert t.extractfile(p.name).read()==p.read_bytes()
manifest={'rule':'Root-authored fixed inputs/helpers only, no in-progress independent reviewer files. Lossless archive; originals retained.','archive':str(archive),'sha256':sha(archive.read_bytes()),'files':[{'path':str(p),'member':p.name,'sha256':sha(p.read_bytes())} for p in files]}
(b/'compiled-local-root-workfiles.manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
roots=[b/'actual-checks',b/'proof-attempts']
paths=[p for root in roots for p in root.rglob('*') if p.is_file()]
paths += [b/x for x in ['anonymous-statement.txt','decoder-input.json','publication-draft-record.json','local-proof-capsule.json','normal-proved-local-preservation.json','compiled-local-root-workfiles.lossless.tar.gz','compiled-local-root-workfiles.manifest.json']]
paths += [Path(x) for x in ['AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumAdmissibility.lean','Tests/GaussianComplexityFixedSpectrumAdmissibility.lean','website/content/declaration_lessons/huanjian-fixed-spectrum-admissibility.json','website/content/publications/huanjian-fixed-spectrum-admissibility.json','research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-admissibility.json','research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-admissibility.json','runs/substantive_advances.jsonl','research-wiki/paper-contributions/GaussianComplexity/README.md']]
subprocess.run(['git','add','--',*[str(p) for p in paths]],check=True)
r=subprocess.run(['git','diff','--cached','--check'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
print(r.stdout.decode()); assert r.returncode==0
print(json.dumps({'owned_paths_staged':len(paths),'archive_sha256':sha(archive.read_bytes()),'fresh_source_reviewer_paths_staged':False}))
