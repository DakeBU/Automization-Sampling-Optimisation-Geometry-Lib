from pathlib import Path
from bs4 import BeautifulSoup
from html.parser import HTMLParser
import hashlib
import json
import stat
from collections import Counter

base=Path(__file__).resolve().parent
author=Path('/Users/zhouhuanjian/ASTIS-GC/.astis/semantic-neutral-20261110/cg_sg_1d7a46')
raw=(base/'author-phase1/inputs/2610.20492v1.html').read_bytes()
assert len(raw)==951991
assert hashlib.sha256(raw).hexdigest()=='6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
text=raw.decode();soup=BeautifulSoup(text,'html.parser')

class IndependentSpans(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=False)
        self.stack=[];self.spans={};self.lines=[0]+[i+1 for i,c in enumerate(text) if c=='\n']
    def position(self):
        line,col=self.getpos();return self.lines[line-1]+col
    def handle_starttag(self,tag,attrs):
        ident=dict(attrs).get('id');a=self.position()
        if tag in {'area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr'}:
            if ident:self.spans[ident]=(a,a+len(self.get_starttag_text()))
        else:self.stack.append((tag,ident,a))
    def handle_startendtag(self,tag,attrs):
        ident=dict(attrs).get('id');a=self.position()
        if ident:self.spans[ident]=(a,a+len(self.get_starttag_text()))
    def handle_endtag(self,tag):
        for j in range(len(self.stack)-1,-1,-1):
            if self.stack[j][0]==tag:
                z=text.index('>',self.position())+1
                for _,ident,a in self.stack[j:]:
                    if ident:self.spans[ident]=(a,z)
                self.stack=self.stack[:j];break

p=IndependentSpans();p.feed(text)
coverage=json.loads((base/'author-phase1/coverage.json').read_bytes())
source_index=json.loads((base/'author-phase1/source_index.json').read_bytes())
graph=json.loads((base/'author-phase1/source_graph.json').read_bytes())
typed=json.loads((base/'author-phase2/typed_overlay.json').read_bytes())
obligations=json.loads((base/'author-phase2/proof_obligations.json').read_bytes())
raw_ids=set()
for root in coverage['scope_roots']:
    node=soup.find(id=root);assert node is not None,root
    raw_ids.add(root);raw_ids.update(t['id'] for t in node.find_all(id=True))
by_id={x['item_id']:x for x in coverage['items']}
duplicates=[x for x,n in Counter(r['item_id'] for r in coverage['items']).items() if n!=1]
missing=sorted(raw_ids-set(by_id))
source_idx={r['id']:r for r in source_index['items']}
index_ids_delta={'missing':sorted(raw_ids-set(source_idx)),'extra':sorted(set(source_idx)-raw_ids)}
spans_bad=[];coverage_bad=[];semantic=[]
for r in source_index['items']:
    a,z=p.spans[r['id']];b=text[a:z].encode()
    actual=(len(text[:a].encode()),len(text[:z].encode()),len(b),hashlib.sha256(b).hexdigest())
    expected=(r['byte_start'],r['byte_end_exclusive'],r['byte_length'],r['sha256'])
    if actual!=expected:spans_bad.append({'id':r['id'],'actual':actual,'expected':expected})
for r in coverage['items']:
    if r['item_id'] not in raw_ids:
        semantic.append(r);continue
    a,z=p.spans[r['item_id']];b=text[a:z].encode()
    actual=(len(text[:a].encode()),len(text[:z].encode()),hashlib.sha256(b).hexdigest())
    expected=(r['byte_start'],r['byte_end_exclusive'],r['raw_span_sha256'])
    if actual!=expected:coverage_bad.append({'id':r['item_id'],'actual':actual,'expected':expected})
nodes={n['id']:n for n in graph['nodes']}
invalid_anchors=[];anchor_mapping=[]
for n in graph['nodes']:
    for ident in n['anchors']:
        tag=soup.find(id=ident)
        if tag is None:invalid_anchors.append({'node':n['id'],'anchor':ident})
        else:
            row=by_id.get(ident)
            anchor_mapping.append({'node':n['id'],'anchor':ident,'tag':tag.name,
                'raw_alttext':tag.get('alttext'),
                'coverage_disposition':row.get('disposition') if row else None,
                'coverage_nodes':row.get('node_ids') if row else None,
                'node_is_listed_in_coverage':bool(row and n['id'] in row.get('node_ids',[]))})
invalid_node_refs=[]
for r in coverage['items']:
    for node in r.get('node_ids',[]):
        if node not in nodes:invalid_node_refs.append({'coverage_id':r['item_id'],'node':node})
parents={n:set() for n in nodes}
invalid_edges=[]
for edge in graph['edges']:
    if edge['consumer'] not in nodes:invalid_edges.append(edge);continue
    for parent in edge['parents']:
        if parent not in nodes:invalid_edges.append(edge)
        parents[edge['consumer']].add(parent)

def ancestors(targets):
    reached=set();visiting=set()
    def walk(node):
        assert node not in visiting,('cycle',node)
        visiting.add(node)
        for parent in parents[node]:
            if parent not in reached:
                reached.add(parent);walk(parent)
        visiting.remove(node)
    for node in targets:walk(node)
    return reached-set(targets)

closure=[]
for root in typed['typed_roots']:
    computed=ancestors(root['raw_source_nodes'])
    declared=set(root['true_raw_ancestors'])
    closure.append({'typed_root':root['typed_root'],'raw_source_nodes':root['raw_source_nodes'],
        'computed_raw_ancestors':sorted(computed),'missing_from_declared':sorted(computed-declared),
        'unsupported_declared':sorted(declared-computed)})
own_projection=json.loads((base.parent/'phase2a/strict-statement-projection.json').read_bytes())
signature_match={key:typed['exact_signatures'][key]==own_projection[key] for key in ['producer_signature','consumer_signature']}
invalid_obligation_refs=[]
ob_ids={r['id'] for r in obligations['obligations']}
for root in typed['typed_roots']:
    for obligation in root['internal_obligations']:
        if obligation not in ob_ids:invalid_obligation_refs.append({'root':root['typed_root'],'id':obligation})
manifest_checks=[]
for phase in ['phase1','phase2']:
    manifest=json.loads((base/('author-'+phase+'_manifest.json')).read_bytes())
    errors=[]
    for entry in manifest['files']:
        path=author/phase/entry['path'];b=path.read_bytes()
        if len(b)!=entry['bytes'] or hashlib.sha256(b).hexdigest()!=entry['sha256'] or stat.S_IMODE(path.stat().st_mode)!=0o444:
            errors.append(entry['path'])
    actual={str(x.relative_to(author/phase)) for x in (author/phase).rglob('*') if x.is_file()}
    expected={x['path'] for x in manifest['files']}
    dirs=[author/phase]+[x for x in (author/phase).rglob('*') if x.is_dir()]
    manifest_checks.append({'phase':phase,'file_count':len(expected),'file_hash_byte_mode_errors':errors,
        'missing_files':sorted(expected-actual),'unlisted_files':sorted(actual-expected),
        'directory_mode_errors':[str(d) for d in dirs if stat.S_IMODE(d.stat().st_mode)!=0o555]})
core=[];tail=[]
for ident in sorted(raw_ids,key=lambda k:p.spans[k][0]):
    tag=soup.find(id=ident);r=by_id[ident]
    root_para=tag if 'ltx_para' in tag.get('class',[]) else tag.find_parent(class_='ltx_para')
    para=root_para.get('id') if root_para else None
    record={'id':ident,'tag':tag.name,'paragraph':para,'raw_alttext':tag.get('alttext'),
        'disposition':r['disposition'],'node_ids':r.get('node_ids',[]),'reason':r['reason']}
    if para in ['A3.SS2.p'+str(i) for i in range(1,9)] or para=='A3.Thmtheorem5.p1':core.append(record)
    elif ident.startswith('A3.') and ('ltx_para' in tag.get('class',[]) or tag.name=='tbody' or tag.name=='table'):tail.append(record)
(base/'independent-source-ID-span-audit.json').write_text(json.dumps({'raw_ids':sorted(raw_ids),'source_index_mismatches':spans_bad,'coverage_span_mismatches':coverage_bad,'source_index_delta':index_ids_delta,'coverage_duplicates':duplicates,'coverage_missing':missing},indent=2)+'\n')
(base/'coverage-core-resolved.json').write_text(json.dumps(core,ensure_ascii=False,indent=2)+'\n')
(base/'coverage-tail-resolved.json').write_text(json.dumps(tail,ensure_ascii=False,indent=2)+'\n')
(base/'coverage-semantic-clauses.json').write_text(json.dumps(semantic,ensure_ascii=False,indent=2)+'\n')
(base/'node-anchor-resolution.json').write_text(json.dumps(anchor_mapping,ensure_ascii=False,indent=2)+'\n')
(base/'root-ancestor-audit.json').write_text(json.dumps(closure,indent=2)+'\n')
report={'source_roots':coverage['scope_roots'],'independent_raw_ID_count':len(raw_ids),
    'independent_math_ID_count':sum(soup.find(id=k).name=='math' for k in raw_ids),
    'coverage_row_count':len(coverage['items']),'coverage_semantic_clause_count':len(semantic),
    'coverage_duplicate_ids':duplicates,'coverage_missing_raw_ids':missing,
    'source_index_delta':index_ids_delta,'source_span_mismatches':len(spans_bad),'coverage_span_mismatches':len(coverage_bad),
    'invalid_graph_anchor_refs':invalid_anchors,'invalid_graph_edge_refs':invalid_edges,'invalid_coverage_node_refs':invalid_node_refs,
    'node_anchor_coverage_not_directly_listed':[r for r in anchor_mapping if not r['node_is_listed_in_coverage']],
    'typed_signatures_match_immutable_phase2a':signature_match,
    'typed_ancestor_mismatches':[r for r in closure if r['missing_from_declared'] or r['unsupported_declared']],
    'invalid_obligation_refs':invalid_obligation_refs,'author_manifest_checks':manifest_checks,
    'mechanical_check_limit':'IDs, spans, references and ancestor closure only; not mathematical coverage correctness or theorem proof.'}
(base/'mechanical-comparison.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
out=json.dumps(report,ensure_ascii=False,indent=2)+'\n';(base/'compare-source-and-topology.stdout.txt').write_text(out);print(out,end='')
