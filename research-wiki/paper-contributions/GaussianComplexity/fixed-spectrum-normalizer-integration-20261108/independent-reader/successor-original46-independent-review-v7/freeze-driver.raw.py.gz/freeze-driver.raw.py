#!/usr/bin/env python3
"""Freeze a human-performed ORIGINAL review; never execute browser, acceptance or API."""
import datetime, difflib, gzip, hashlib, json, pathlib, re, struct, subprocess, tarfile
from collections import Counter

R=pathlib.Path('/Users/zhouhuanjian/ASTIS-GC')
S=R/'.astis/huanjian-gc-fixed-spectrum-normalizer-integration-20261108/independent-reader'
B=R/'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-normalizer-integration-20261108'
O=B/'independent-reader/successor-original46-independent-review-v7'
ACTOR='/root/norm_integration_reader'
CORE='a5ec44836422e56ca5cfab14f951ed84bbfc9324'
CONTEXT=B/'actual-successor-originals-independent-review-context.json'
CONTEXT_SHA='5d639cda7941af9715af6fb2b4c6a1e44918b6903fa4e5d7ffa2ac3d75482131'
DECL='AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumNormalizer.actual_normalizing_integral'
GPD='AutoSamplingTheory.TechnicalLemmas.Measure.GaussianPrecisionDensity.multivariateGaussian_eq_withDensity_of_posDef'
CSS='website/static/information-architecture.css'
sha=lambda b:hashlib.sha256(b).hexdigest()
dump=lambda v:(json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode()
rel=lambda p:str(p.relative_to(R))
def write(name,raw):
 p=O/name
 assert p.is_relative_to(O) and not p.exists(),str(p)
 p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
 return {'path':rel(p),'sha256':sha(raw)}
def freeze(name,raw):
 ref=write(name,gzip.compress(raw,mtime=0));ref.update({'encoding':'gzip','raw_sha256':sha(raw),'raw_bytes':len(raw)});return ref
def pin(p):
 raw=p.read_bytes();return {'path':rel(p),'sha256':sha(raw)}
def refread(ref):
 p=R/ref['path'];raw=p.read_bytes();assert sha(raw)==ref['sha256'],str(p);return raw
def gitraw(commit,path):return subprocess.check_output(['git','show',commit+':'+path],cwd=R)

assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip()==CORE
craw=CONTEXT.read_bytes();assert sha(craw)==CONTEXT_SHA
c=json.loads(craw);assert c['accepted_immutable_core']==CORE and c['new_source_verdict'] is False and c['parking_authorized'] is False
manual_path=S/'successor-original46-manual-observations-v7.json';manual=json.loads(manual_path.read_bytes())
br=refread(c['browser_report']);browser=json.loads(br);assert browser['head']==CORE and browser['status']=='passed' and browser['errors']==[]
expected={str((R/c['browser_report']['path']).parent/x['file']):x for x in browser['screenshots']}
assert len(expected)==len(manual['images'])==46
for row in manual['images']:
 p=R/row['path'];raw=p.read_bytes();e=expected[str(p)]
 assert row['reviewer']==ACTOR and row['actually_viewed_original'] is True and len(row['observation'].strip())>=32
 assert row['sha256']==e['sha256']==sha(raw) and raw[:8]==b'\x89PNG\r\n\x1a\n'
 assert (row['width'],row['height'])==struct.unpack('>II',raw[16:24])
assert {str(R/x['path']) for x in manual['images']}==set(expected)
manual_ref=write('actual-opened-originals.observations.json',dump(manual))

# Retention is byte preservation, independently of the manual viewing above.
am=json.loads(refread(c['retained_archive_manifest']));ar=R/am['archive'];assert sha(ar.read_bytes())==am['archive_sha256']
expectedraw={x['path']:x['sha256'] for x in manual['images']};expectedraw[c['browser_report']['path']]=c['browser_report']['sha256']
assert len(am['files'])==47 and {x['original'] for x in am['files']}==set(expectedraw)
with tarfile.open(ar,'r:gz') as tar:
 members=tar.getmembers();assert len(members)==47 and all(x.isfile() and not pathlib.Path(x.name).is_absolute() and '..' not in pathlib.Path(x.name).parts for x in members)
 assert {x.name for x in members}=={x['member'] for x in am['files']}
 for row in am['files']:
  raw=(R/row['original']).read_bytes();assert sha(raw)==row['raw_sha256']==expectedraw[row['original']] and tar.extractfile(row['member']).read()==raw
pm=json.loads(refread(c['lossless_public_originals_manifest']));assert pm['immutable_core']==CORE and len(pm['files'])==46
assert {x['original'] for x in pm['files']}=={x['path'] for x in manual['images']}
for row in pm['files']:
 original=(R/row['original']).read_bytes();archive=refread(row['lossless_public_export'])
 assert gzip.decompress(archive)==original and sha(original)==row['raw_image_sha256']==expectedraw[row['original']]
retention=write('independent47archive-and46export-readback.json',dump({'reviewer':ACTOR,'archive_manifest':c['retained_archive_manifest'],'archive_sha256':am['archive_sha256'],'actual_originals_roundtripped':47,'lossless_public_originals_manifest':c['lossless_public_originals_manifest'],'public_exports_roundtripped':46,'manual_original_viewing_separate':True,'archive_or_manifest_certifies_pixel_readability':False}))

receipt_rows=[];canonical=None
interpretations={
 'canonical_lean':'Official wrapper ran canonical ASTIS check, production and root Tests, ATLAS consistency and fake-closure checks. New producer and real private consumer are printed with the standard three axioms; replay/cached jobs are honestly reported as replayed, not a clean rebuild.',
 'publication':'360 source items; code/prose/assumptions/semantic links pass with explicit legacy debt. This is not a historical GPD sourceV.',
 'contributor':'Exactly one affected declaration and one changed cell; affected metadata only, with other gates explicitly still required.',
 'semantic':'442 audits and8 repair proposals valid; no fresh source verdict is manufactured by registry validation.',
 'frontier':'440 registered cells pass the protocol check. This registered-count report is not the count of all443 protected JSON files.',
 'site_build':'12 chapters,622 compiled leaves,1122 modules,5273 declarations generated at exact a5ec.',
 'site_check':'Current exact-head generated site passes structural checks:12 chapters,1122 modules,5273 declarations,77 reviewed teaching declarations. Pixel readability is separately assessed from46 originals.',
 'graph_check':'Six target connections include exactly three displayed source-name scanner parents. Report explicitly disclaims completeness, proof certification and visual QA.',
 'browser':'Actual new v7 process returned0 with2widths/4graphs/46screenshots; full original visual judgement is separately performed by this reviewer.'}
for role,ref in c['actual_checks'].items():
 raw=refread(ref);r=json.loads(raw);log=pathlib.Path(r['log']).read_bytes()
 assert r['exit_code']==0 and r['head_before']==r['head_after']==CORE and sha(log)==r['log_sha256']
 rr=freeze('actual-'+role+'.receipt.raw.gz',raw);lr=freeze('actual-'+role+'.log.raw.gz',log)
 scope='Full receipt and full short raw log read by reviewer.'
 if role=='canonical_lean':
  scope='Full receipt and complete raw log bytes independently read/indexed; reviewer inspected first/final blocks, all target lines, all printed axiom sets, all warning-family census and all failed/error/sorry/admit/exception hits with context. No claim of verbatim manual reading of every repeated historical linter line.'
  s=log.decode();lines=s.splitlines();axioms=re.findall(r'depends on axioms: \[([^\]]+)\]',s,re.S)
  axc=Counter(tuple(re.findall(r'[A-Za-z_][A-Za-z0-9_.]*',x)) for x in axioms)
  assert axc==Counter({('propext','Classical.choice','Quot.sound'):506})
  families=Counter(re.findall(r'\blinter\.[A-Za-z0-9_.]+',s))
  exceptional={pat:[{'line':i+1,'text':line} for i,line in enumerate(lines) if re.search(pat,line)] for pat in [r'(?i)\berror\s*[:\[]',r'(?i)sorryAx',r'(?i)\bsorry\b',r'(?i)\badmit\b',r'(?i)\bfailed\b',r'(?i)Exception']}
  assert all(not v for k,v in exceptional.items() if k!=r'(?i)\bfailed\b')
  assert len(exceptional[r'(?i)\bfailed\b'])==8 and all('The `ring` tactic failed to close the goal' in x['text'] for x in exceptional[r'(?i)\bfailed\b'])
  target=[{'line':i+1,'context':'\n'.join(lines[max(0,i-1):i+7])} for i,line in enumerate(lines) if 'FixedSpectrumNormalizer' in line]
  assert len(target)==3 and s.count('ASTIS check passed')==1 and s.rstrip().endswith('Recorded current Lean gate evidence at .astis/site-lean-gate.json')
  canonical={'raw_log':lr,'read_scope':scope,'lines':len(lines),'warning_headings':sum(x.startswith('warning:') for x in lines),'linter_family_occurrences':dict(sorted(families.items())),'all506_printed_axiom_sets':{'propext, Classical.choice, Quot.sound':506},'exceptional_hits':exceptional,'ring_diagnostic_interpretation':'All8 are replayed informational Try this/ring_nf tactic suggestions in existing modules; their contexts were read. Neither process exit nor final build failed.','target_blocks':target,'first30':lines[:30],'last30':lines[-30:]}
 receipt_rows.append({'role':role,'receipt':ref,'frozen_receipt':rr,'raw_log_sha256':sha(log),'frozen_raw_log':lr,'raw_bytes':len(log),'raw_lines':len(log.splitlines()),'command':r['command'],'head_before':r['head_before'],'head_after':r['head_after'],'exit_code':r['exit_code'],'elapsed_seconds':r['elapsed_seconds'],'actually_read':True,'read_scope':scope,'reviewer_interpretation':interpretations[role]})
canonical_ref=write('canonical-raw-log-review.json',dump(canonical))
receipts_ref=write('actual-nine-receipts-review.json',dump({'reviewer':ACTOR,'accepted_immutable_core':CORE,'all9actual_receipts_and_rawlogs_read':True,'checks':receipt_rows,'canonical_detailed_review':canonical_ref,'new_execution_performed_by_this_review':False,'no_inference_of_pixel_review_from_exit0':True}))

# Inspect the actual generated graph, retaining full exact node/edge differences.
oldpin=B/'independent-reader/helper-preparation/preintegration-actual-generated-graph.json.raw.gz';oldraw=gzip.decompress(oldpin.read_bytes());newraw=(R/'_site/data/underlying-lean-graph.json').read_bytes()
assert sha(oldraw)=='4b98c48e475ca63d8437b4354ac32936022ecd00c7309b7023895b059a8209f9'
assert sha(newraw)=='aa59bff37a6e5bd39c7d12bacd592c76096a8448a986072e3546df72ca4799b6'
old=json.loads(oldraw);new=json.loads(newraw);on={x['id']:x for x in old['nodes']};nn={x['id']:x for x in new['nodes']}
assert len(on)==len(old['nodes'])==2750 and len(nn)==len(new['nodes'])==2754
changed={k:{'before':on[k],'after':nn[k]} for k in sorted(on.keys()&nn.keys()) if on[k]!=nn[k]}
added={k:nn[k] for k in sorted(nn.keys()-on.keys())};removed=sorted(on.keys()-nn.keys());assert len(changed)==9 and len(added)==4 and not removed
canon=lambda v:json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':'))
oe={canon(x):x for x in old['edges']};ne={canon(x):x for x in new['edges']};addededges=[ne[k] for k in sorted(ne.keys()-oe.keys())];removededges=[oe[k] for k in sorted(oe.keys()-ne.keys())]
assert len(addededges)==18 and not removededges
for key in ['hyperedges','conceptual_transport_contract','graph_memory_index']:assert old[key]==new[key]
assert len([x for x in new['nodes'] if x['id']=='decl:'+GPD])==1 and nn['decl:'+GPD]['url']==on['decl:'+GPD]['url']
parents=['AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumAdmissibility.actual_precision_admissible','AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumDeterminant.actual_precision_det',GPD]
assert sorted(x['source'] for x in new['edges'] if x['target']=='decl:'+DECL and x['relation']=='source reference (scanner)')==sorted('decl:'+x for x in parents)
case='case:ASTIS-SW-GAUSSIAN-COMPLEXITY-2026';ob=on[case]['details'];nb=nn[case]['details'];sm=difflib.SequenceMatcher(a=[canon(x) for x in ob],b=[canon(x) for x in nb],autojunk=False)
caseops=[{'operation':tag,'before_start':i,'before_end':j,'after_start':k,'after_end':l,'before':ob[i:j],'after':nb[k:l]} for tag,i,j,k,l in sm.get_opcodes() if tag!='equal'];assert len(caseops)==1 and caseops[0]['operation']=='insert' and len(caseops[0]['after'])==2
delta={'old_counts':old['counts'],'new_counts':new['counts'],'added_nodes':added,'removed_node_ids':removed,'changed_old_nodes':changed,'added_edges':addededges,'removed_edges':removededges,'case_details_insert':caseops,'unchanged_old_nodes':2741,'other_top_level_changes':{k:{'before':old[k],'after':new[k]} for k in old.keys()|new.keys() if k not in ['nodes','edges'] and old.get(k)!=new.get(k)}}
delta_ref=freeze('actual-exact-foreign-graph-delta.json.raw.gz',dump(delta));currentgraph_ref=freeze('actual-current-underlying-lean-graph.json.raw.gz',newraw)
models={p:sha((R/p).read_bytes()) for p in ['website/content/graph_memory_index.json','website/content/functor_hypergraph.json']}
assert list(models.values())==['019497faee75c5844ff3d3a08b0ce61c25256918cc29c45b2de5bbaca490b607','94b56f87136ca97820893e5531d16d36334d44bc6b9e41981d39aa700f8fe782']
frontpath=R/'research-wiki/frontier-cells/ASTIS-SHARED-gaussian-precision-density.json';front=json.loads(frontpath.read_bytes());assert front['status']=='proved_locally' and front['evidence']['independent_verification']==''
card=R/'_site/theorems/autosamplingtheory-technicallemmas-measure-gaussianprecisiondensity-multivariategaussian-eq-withdensity-of-posdef.html';cardraw=card.read_bytes();match=re.search(rb'<h2[^>]*>Proof architecture</h2>\s*<p>(.*?)</p>',cardraw,re.S);assert match
warning=match.group(1).decode();assert 'proved_locally without independent verification' in warning and 'no old sourceV or completed audit is claimed' in warning
graph_review={
 'reviewer':ACTOR,'accepted_immutable_core':CORE,'actual_generated_graph':{'path':'_site/data/underlying-lean-graph.json','sha256':sha(newraw),'frozen_raw':currentgraph_ref},'preintegration_graph_archive':pin(oldpin),'preintegration_graph_raw_sha256':sha(oldraw),'current_graph_equal_prior_c8_graph_raw':True,'exact_actual_delta':delta_ref,
 'actually_reviewed':True,'old_nodes_unchanged':2741,'old_nodes_changed':9,'new_nodes':4,'new_edges':18,'removed_nodes_or_edges':False,
 'changed_branch_judgement':'Exactly normalizer producer module/private Test module/declaration/own semantic audit are new. Existing case gains one mapped-source/boundary pair; root/Tests/Registry modules gain necessary imports. Admissibility and determinant gain normalizer consumers. Existing GPD gets compilation-only inventory, RN name-scanned parent and normalizer/Averaged consumers; RN gains the newly visible GPD consumer. This is natural inventory exposure, not broad cleanup or historical sourceV.',
 'canonical_GPD':{'id':'decl:'+GPD,'unique_in_actual_graph':True,'same_old_reader_url':nn['decl:'+GPD]['url'],'compiled_inventory_only':True,'old_frontier':pin(frontpath),'old_frontier_status':front['status'],'old_independent_verification':front['evidence']['independent_verification'],'no_historical_audit_upgrade':True,'own_site_card':pin(card),'actual_h2_adjacent_warning':warning,'warning_pixel_checked_in_originals':[22,45]},
 'scanner_edge_boundary':'Exactly3 displayed canonical source-name scanner references; scanner is incomplete and not a complete kernel export. The separately frozen source/kernel capsule provides3producer/4Test parent evidence, not this graph.',
 'conceptual_hyperedges_memory_contract_equal_preintegration':True,'models':models,'focused_old_bridge':'transport:gaussian-quadratic-oracle-factorization','focused_bridge_still_proposal_not_Lean_certified':True,'new_normalizer_candidate_or_formal_ref_added':False,
 'blocking_objections':[]}
graph_ref=write('actual-foreign-graph-review.json',dump(graph_review))

cssbefore=gitraw('c8c157a69aaad4007cb801a781e980a27005bb02',CSS);cssafter=(R/CSS).read_bytes();assert cssafter==cssbefore.replace(b'.theorem-grid > *,\n',b'.theorem-grid > *,\n.theorem-layout > article,\n',1)
assert sha(cssbefore)=='fff8768ceacf00e973d4170751b75a0bc1e6cd9c16b2765a24e45b22f1aabd3e' and sha(cssafter)==c['site_layout_css_sha256']=='a41ffd9d41e8c281aa716fcff25e42e5cb8d14208badff456a0dff7dfbb1b766'
assert cssafter==gitraw(CORE,CSS)==(R/'_site/assets/information-architecture.css').read_bytes()
post=json.loads((O/'postcore-readback.json').read_bytes());assert post['state']=='POSTCORE_READBACK_PASS_NOT_LOCAL_READER_ACCEPTANCE' and post['accepted_immutable_core']==CORE
assert post['protection']['all_foreign_tracked_bytes_preserved'] is False and post['protection']['all_other_foreign_tracked_bytes_preserved'] is True
v5=B/'independent-reader/original46-independent-review-v5/original46-review-completed-HOLD.json';assert sha(v5.read_bytes())=='4f9797c8f949e87eeea0e3178a1c8256a27e18e6b8427ed0a9cb37a02263fc42'
v6=B/'process-diagnostics/failed-browser-v6-old-regression-retention.json';assert v6.exists()
layout_review=write('actual-qualified-layout-and-preservation-review.json',dump({'reviewer':ACTOR,'exception':post['protection']['qualified_exact_one_line_layout_exception'],'all_foreign_tracked_bytes_preserved':False,'all_other_foreign_tracked_bytes_preserved':True,'source_and_generated_css_exact_same_after':True,'scope':'CSS affects all theorem-layout article grid items, allowing shrinkage around long Lean blocks. It changes no math, sourceDigest definition, sourceV or historical audit. Main46 originals include normalizer reader and canonical admissibility/determinant/GPD graph/native-reader branches. Exact-head sitecheck provides structural regression; it is not a claim that every old page was pixel-inspected.','old_DensityAffinity_two_widths':{'kind':'DOM/native-UI/geometry regression only','no_original_pixel_review_claim':True,'actual_report_rows':browser['old_long_Lean_layout_regressions'],'175line_fullproof_selected':True,'both_widths_prose_ranges_and_local_code_scroll':True},'postcore_readback':pin(O/'postcore-readback.json'),'old_v5_HOLD_immutable':pin(v5),'old_v6_failed22_retention_preserved':pin(v6),'no_new_sourceV_or_ledger_append':True,'README_and443frontiers_and_models':post['protection'],'blocking_objections':[]}))

for row in browser['GPD_debt_cards']:
 g=row['ordinary_prose_bounds'];w=row['width'];assert g['article']['left']>=0 and g['article']['right']<=w
 assert g['paragraph']['left']>=0 and g['paragraph']['right']<=w
 assert all(x['left']>=0 and x['right']<=w and x['top']>=g['unobscured_top'] and x['bottom']<=g['viewport_height'] for x in g['text_rects'])
mobile=next(x for x in browser['GPD_debt_cards'] if x['width']==390);assert len(mobile['ordinary_prose_bounds']['text_rects'])==14
review={
 'reviewer':ACTOR,'state':'ORIGINAL46_REVIEW_COMPLETED','accepted_immutable_core':CORE,'source_digest':c['source_digest'],'publication_binding_sha256':c['publication_binding_sha256'],'browser_report_sha256':c['browser_report']['sha256'],'authorization':{'path':rel(CONTEXT),'sha256':CONTEXT_SHA},
 'images':manual['images'],'original_view_method':manual['review_method'],'raw_receipts_actually_read':True,'foreign_graph_delta_actually_reviewed':True,'blocking_objections':[],
 'raw_receipt_review':receipts_ref,'foreign_graph_review':graph_ref,'qualified_CSS_and_preservation_review':layout_review,'lossless_retention_readback':retention,'manual_observation_record':manual_ref,
 'visual_judgement':'Current46 actual ORIGINALS at1440x1000 and390x844 have no blocking reader objection for this bounded normalizer integration. Mobile GPD ordinary warning is fully wrapped and readable through its final source-name references line. Its14 actual line-range boxes match the pixels, all right edges within319.5625px and final text bottom823.015625px in390x844 viewport below the60.578125px header. This repairs the c8 mobile prose-clipping HOLD on successor a5ec; it does not rewrite that old HOLD.',
 'mobile_GPD_pixel_and_range_concordance':{'image_index':45,'paragraph':mobile['ordinary_prose_bounds']['paragraph'],'actual_text_rects':mobile['ordinary_prose_bounds']['text_rects'],'unobscured_top':mobile['ordinary_prose_bounds']['unobscured_top'],'full_ordinary_warning_visually_readable':True,'code_horizontal_scroll_is_separate':True},
 'remaining_scope_limits':['All screenshots are viewport captures: long exact Lean statement/proof and full-module code are only partially shown; exact bytes come from current actual DOM/download/local immutable Git checks, not one full-code screenshot.','Long mathematics may use clearly signposted local horizontal scrolling. Ordinary GPD prose is fully visible without horizontal clipping after the reviewed CSS exception.','Focused graph canvases show cropped neighbors and shortened labels; no all-label Fit readability, manual touch-drag or whole-graph pixel review is claimed. Canonical identities and exact graph delta are separately inspected.','Old DensityAffinity175line page was checked in both widths only by native UI/DOM/geometry; there are no additional original screenshots or independent pixel-review claims for it.','Own-site source/module/download evidence is bound to a5ec. GitHub syntax branches did not execute and remain null; external GitHub HTML/public HTTP delivery is not checked.','Current review is reader/integration evidence only, no new math proof or sourceV verdict; historical GPD source/publication debt stays explicit and the old frontier remains proved_locally.'],
 'old_v5_HOLD_preserved':pin(v5),'old_v6_failed22_preserved':pin(v6),'new_source_verdict':False,'local_acceptance_executed':False,'parking_authorized_or_executed':False,'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
review_ref=write('original46-review-completed.json',dump(review))
inputs={'authorization':pin(CONTEXT),'browser_report':c['browser_report'],'actual_gate':c['actual_gate'],'site_metadata':c['site_metadata'],'manual_private_observations':pin(manual_path),'actual47manifest':c['retained_archive_manifest'],'actual46public_export_manifest':c['lossless_public_originals_manifest'],'helper_script':pin(pathlib.Path(__file__)),'postcore_readback':pin(O/'postcore-readback.json'),'old_v5_HOLD':pin(v5),'old_v6_failure_retention':pin(v6),'actual_current_graph_raw_sha256':sha(newraw),'generated_CSS_sha256':sha(cssafter),'original_source_lineage':c['source_lineage'],'no_browser_build_gate_acceptance_or_API_run_by_freezing_script':True}
write('inputs-and-provenance.json',dump(inputs));freeze('freeze-driver.raw.py.gz',pathlib.Path(__file__).read_bytes())
files=[pin(p) for p in sorted(O.rglob('*')) if p.is_file()]
fref=write('freeze.json',dump({'reviewer':ACTOR,'state':'FROZEN_INDEPENDENT_ORIGINAL46_REVIEW_ONLY','accepted_immutable_core':CORE,'review':review_ref,'files':files,'writes_scope':rel(O),'source_site_generator_ledger_README_modified':False,'sourceV_acceptance_park_API_executed':False}))
print(json.dumps({'review':review_ref,'freeze':fref,'raw_receipts':receipts_ref,'foreign_graph':graph_ref,'layout_and_preservation':layout_review,'actual46originals':46,'blocking_objections':[],'acceptance_or_park_executed':False},ensure_ascii=False))
