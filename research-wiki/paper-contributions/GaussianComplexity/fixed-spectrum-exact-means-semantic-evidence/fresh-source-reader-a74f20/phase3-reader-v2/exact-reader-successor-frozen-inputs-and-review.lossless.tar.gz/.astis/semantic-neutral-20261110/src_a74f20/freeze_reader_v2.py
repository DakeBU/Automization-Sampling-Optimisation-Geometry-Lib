from pathlib import Path
import hashlib,json,sys,os
sys.dont_write_bytecode=True
ROOT=Path('/Users/zhouhuanjian/ASTIS-GC');BASE=ROOT/'.astis/semantic-neutral-20261110/src_a74f20';OUT=BASE/'phase3-reader-v2'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,obj):
 p=OUT/name;p.write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n');return p
packet=json.loads((OUT/'canonical-reviewer-packet.json').read_text())
assert packet['packet_sha256']=='a5ad7c23afaa9804cdf88c8794e63304d3ed287ff33f0958794fa32190526040'
assert packet['publication_binding_sha256']=='782a2b00ab19c7773c613a275c9371427951632b4f1b1cb974490af25ff70816'
assert sha(OUT/'snapshot/website/content/declaration_lessons/huanjian-fixed-spectrum-exact-means.json')=='4252152a1df92598351878fe7a0089feebd400de30f8398f7752b19d958c69d6'
prior=json.loads((BASE/'phase3/canonical-audit-four-field-proposal.json').read_text())
reuse=json.loads((OUT/'prior-freezes-reuse-check.json').read_text())
static=json.loads((OUT/'static-reader-checks.json').read_text());assert all(static['checks'].values())
report=OUT/'independent-successor-review.md'
run=write('review-run.json',{
 'reviewer':'/root/source_reader_a74f20','checked_successor_commit':'64922804e1f7f0927e85bb6a26aeb24d06eea6f7','canonical_reviewer_packet_sha256':packet['packet_sha256'],'raw_reviewer_packet_sha256':sha(OUT/'canonical-reviewer-packet.json'),'publication_binding_sha256':packet['publication_binding_sha256'],
 'lesson_sha256':'4252152a1df92598351878fe7a0089feebd400de30f8398f7752b19d958c69d6','whole_module_sha256':'8dfb13585403a127830dfc841dafaf7e6f95057db10253f38b0ab7a66802b6c8','test_sha256':'d30744e67541fa07729002f06fde01f84a4fa1984b6f24d1014285db50ccc696',
 'source_fidelity_verdict':'equivalent-after-elaboration','static_reader_status':'ACCEPT_EXACT_SUCCESSOR_BOUNDED_STATIC_REPAIR','original_hold':'Preserved historically in original phase3 freeze4932582ef2ff7976624eaf2672910a11aeb447292b1a72e1f84e9b63a67ff621; resolved only for this exact independently checked successor lesson/context.',
 'reused_native_evidence':{'commit':'d823dddd8b7f203af3191b94ba2eb763fc0edc9b','review_run_sha256':'d7d691020732f44872aacde30b9a484c99a59662dba79dd3ebbcee40e66435f7','freeze_manifest_sha256':'4932582ef2ff7976624eaf2672910a11aeb447292b1a72e1f84e9b63a67ff621','reason':'Entire mathematical source/Test trees, toolchain/manifest, source, signatures, reconstruction and repairs unchanged. All original frozen files reverified byte-identical.','fresh_native_at_successor':False},
 'report_sha256':sha(report),'static_check_sha256':sha(OUT/'static-reader-checks.json'),'step_literal_checks_sha256':sha(OUT/'step-literal-source-checks.json'),'current_binding_check_sha256':sha(OUT/'current-binding-check.json'),'prior_freeze_reuse_check_sha256':sha(OUT/'prior-freezes-reuse-check.json'),'actual_tool_results_sha256':sha(OUT/'actual-tool-results.json'),
 'actual_fresh_static_receipt':{'command':'PYTHONDONTWRITEBYTECODE=1 python3 .astis/semantic-neutral-20261110/src_a74f20/static_reader_v2.py','exit_code':0,'actual_output_chunk_id':'8c250d'},
 'failure_preservation':{'first_static_exit_code':1,'first_static_output_chunk_id':'2be7a0','diagnosis_output_chunk_id':'8209c3','failed_script_snapshot':'static_reader_v2.attempt1.py.txt','diagnosis':'Whole lesson has unchanged boundary field deliberately omitted by documented packet review_context projection; all shared fields already matched. Corrected check verifies exact projection plus unchanged boundary. Candidate not modified.'},
 'fixture_scope':'Controlled static theme-stack fixture only; no loaded CSS, browser, visual typesetter, production theme or aggregate gate. Exact fixture bytes/hash retained.',
 'no_canonical_mutation_or_normal_V':True
})
slots=prior['semantic_slots']
slots['scopes']['evidence']='Unchanged source and exact code/types reuse the frozen d823 whole-module/kernel findings. The private consumer remains the same actual-integral ratio under base conditions. Original adjacent-Lean HOLD remains historically frozen and is resolved for this exact successor by six literal source panels, entire Test module at step6 and a complete linked numbered source export; no new mathematical credit.'
proposal=write('canonical-audit-four-field-proposal.json',{
 'semantic_slots':slots,'deltas':prior['deltas'],'verdict':'equivalent-after-elaboration',
 'source_review':{'state':'accepted','reviewer':'/root/source_reader_a74f20','independent_from_formalizer':True,'independent_from_decoder':True,'reviewer_packet_sha256':packet['packet_sha256'],'review_run_sha256':sha(run),'run_artifact':str(run.relative_to(ROOT)),'evidence':str(report.relative_to(ROOT))+'; exact successor source/whole-module correspondence and bounded static reader repair accepted; unchanged d823 native/kernel/cache evidence reused explicitly; no fresh native claim at64922804, browser acceptance or normalV action.','checked_commit':'64922804e1f7f0927e85bb6a26aeb24d06eea6f7','whole_module_sha256':'8dfb13585403a127830dfc841dafaf7e6f95057db10253f38b0ab7a66802b6c8','test_module_sha256':'d30744e67541fa07729002f06fde01f84a4fa1984b6f24d1014285db50ccc696','publication_binding_sha256':packet['publication_binding_sha256'],'source_native_evidence_commit':'d823dddd8b7f203af3191b94ba2eb763fc0edc9b','fresh_native_at_checked_successor':False,'static_reader_status':'ACCEPT_EXACT_SUCCESSOR_BOUNDED_STATIC_REPAIR'}})
assert set(json.loads(proposal.read_text()))=={'semantic_slots','deltas','verdict','source_review'}
assert set(slots)=={'objects','domains','quantifiers','assumptions','conclusion','scopes','constant_dependencies'}
assert not any(x['severity']=='blocking' for x in prior['deltas'])
write('read-exposure.json',{
 'reviewer':'/root/source_reader_a74f20','authority':'Exact64922804 own-lesson/context repair successor review and own bounded static/export checks; reuse d823 source/native evidence; no canonical/normalV/site/browser/network mutation.',
 'new_semantic_inputs':['Exact new canonical anti-anchored reviewer packet with independently verified raw/canonical hashes','Exact git-show successor production/Test/lesson/publication/pending audit/toolchain/manifest snapshots','Own original freezes/report/proposal and original lesson/source snapshots','Current relevant static renderer/source-export/theme-stack/projection-binding tools'],
 'mechanical_inputs':['Exact git diff restricted to mathematical source/Test trees and toolchain/manifest','Actual anonymous decoder packet bytes at d823 and64922804, verified identical and canonical digest checked','All167 original frozen file records rehashed and verified unchanged','Own new static output, exact per-step source comparisons, exported numbered Test source, controlled theme fixture'],
 'exposure_history':'Parent repair path/hash metadata was received only after the original HOLD finding; no repair contents were opened until original phase3 was frozen and strict successor authority arrived.','source_native_evidence_reused':True,'fresh_native_claim_at_successor':False,'prior_repairs_unchanged':True,'not_performed':['No Lean rebuild for JSON-only successor','No canonical audit/frontier/ledger/Registry mutation or normalV/STAB','No shared/global build/site or shared renderer edit','No browser/OS/network/push','No mathematical/source/public-node credit expansion'],
 'actual_tool_evidence':'actual-tool-results.json, current-binding-check.json, static-reader-checks.json and step-literal-source-checks.json','limitations':'Static source preservation/folds/adjacency/export only; no actual CSS/typesetting/desktop/mobile delivery acceptance.'
})
files=sorted(p for p in OUT.rglob('*') if p.is_file() and not p.is_symlink() and p.name not in ['freeze-manifest.json','seal-receipt.json'])+[BASE/'static_reader_v2.py',BASE/'freeze_reader_v2.py']
manifest=write('freeze-manifest.json',{'reviewer':'/root/source_reader_a74f20','phase':'3-reader-v2','checked_commit':'64922804e1f7f0927e85bb6a26aeb24d06eea6f7','status':'FROZEN_EXACT_READER_SUCCESSOR_ACCEPT_NATIVE_REUSED','original_phase3_hold_preserved':True,'files':[{'path':str(p.relative_to(ROOT)),'sha256':sha(p),'bytes':p.stat().st_size} for p in files],'terminal_command':'PYTHONDONTWRITEBYTECODE=1 python3 .astis/semantic-neutral-20261110/src_a74f20/freeze_reader_v2.py','receipt_policy':'Separate actual post-seal receipt is outside this non-self-referential freeze. All older freeze files remain byte-identical.'})
print(json.dumps({'status':'FROZEN_EXACT_READER_SUCCESSOR_ACCEPT_NATIVE_REUSED','manifest_sha256':sha(manifest),'review_run_sha256':sha(run),'four_field_proposal_sha256':sha(proposal),'report_sha256':sha(report),'static_reader_checks_sha256':sha(OUT/'static-reader-checks.json'),'file_count':len(files)},indent=2))
