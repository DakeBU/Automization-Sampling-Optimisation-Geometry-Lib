from pathlib import Path
from html.parser import HTMLParser
import hashlib
import json
import re
import sys

ROOT = Path('/Users/zhouhuanjian/ASTIS-GC')
SOURCE = ROOT / '.astis/huanjian-resume-20261103/2610.20492v1.html'
raw = SOURCE.read_bytes()
source_text = raw.decode()
line_starts = [0]
for m in re.finditer('\n', source_text):
    line_starts.append(m.end())

class Node:
    def __init__(self, tag, attrs, parent=None, start=0):
        self.tag, self.attrs, self.parent, self.start = tag, dict(attrs), parent, start
        self.children, self.end = [], None

    def text(self):
        if self.tag == 'math':
            return '$' + self.attrs.get('alttext', '') + '$'
        if self.tag in ('annotation', 'annotation-xml'):
            return ''
        return ''.join(x.text() if isinstance(x, Node) else x for x in self.children)

    def clean(self):
        return re.sub(r'\s+', ' ', self.text()).strip()

    def locator(self):
        assert self.end is not None
        a, b = self.start, self.end
        fragment = source_text[a:b].encode()
        return {
            'html_id':self.attrs.get('id'), 'unicode_char_start':a,
            'unicode_char_end_exclusive':b,
            'utf8_byte_start':len(source_text[:a].encode()),
            'utf8_byte_end_exclusive':len(source_text[:b].encode()),
            'lf_line_start_1based':source_text[:a].count('\n')+1,
            'lf_line_end_1based':source_text[:max(a,b-1)].count('\n')+1,
            'raw_fragment_sha256':hashlib.sha256(fragment).hexdigest(),
            'rendered_text_sha256':hashlib.sha256(self.clean().encode()).hexdigest(),
        }

class Reader(HTMLParser):
    void = {'area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr'}

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.root, self.nodes = Node('root', []), []
        self.stack = [self.root]

    def pos(self):
        line, col = self.getpos()
        return line_starts[line-1] + col

    def handle_starttag(self, tag, attrs):
        n = Node(tag, attrs, self.stack[-1], self.pos())
        self.stack[-1].children.append(n)
        self.nodes.append(n)
        if tag in self.void:
            n.end = self.pos() + len(self.get_starttag_text())
        else:
            self.stack.append(n)

    def handle_endtag(self, tag):
        end = source_text.index('>', self.pos()) + 1
        for i in range(len(self.stack)-1, 0, -1):
            if self.stack[i].tag == tag:
                for n in self.stack[i:]:
                    n.end = end
                self.stack = self.stack[:i]
                break

    def handle_data(self, data):
        self.stack[-1].children.append(data)

r = Reader()
r.feed(source_text)
by_id = {n.attrs['id']:n for n in r.nodes if 'id' in n.attrs}

if len(sys.argv) > 1 and sys.argv[1] == 'read':
    for ident in sys.argv[2:]:
        n = by_id[ident]
        print(json.dumps({'locator':n.locator(), 'text':n.clean()},ensure_ascii=False))
