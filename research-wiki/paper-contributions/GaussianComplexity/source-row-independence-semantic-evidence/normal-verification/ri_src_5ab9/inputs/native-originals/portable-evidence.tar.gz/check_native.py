import json,os
from run import ROOT,run,sha
m=json.loads((ROOT/'input-manifest.json').read_text());env=dict(os.environ);env['LEAN_PATH']=os.pathsep.join(m['lean_path']);env.pop('LEAN_SRC_PATH',None)
for label,p in [('inspect-all','InspectAll.lean'),('independent-literals','IndependentLiteralCheck.lean'),('standard-applicability','StandardApplicability.lean')]:
    r=run(label,[m['lean_binary']['path'],'-R',str(ROOT/'scratch'),str(ROOT/'scratch'/p)],cwd=ROOT/'scratch',env=env)
    assert r.returncode==0,label
rows=json.loads((ROOT/'native-all-bodies.json').read_text());mods={p[:-5].replace('/','.') for p in [m['P'],m['T']]}
new=[r for r in rows if r['module'] in mods]
producer=next(r for r in new if r['name'].endswith('.actual_source_rows_independent'))
consumer=next(r for r in new if r['name'].endswith('.actual_truncated_matrices_measurable_and_independent'))
assert len(new)==2
old='AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumSourceRowLaw.actual_source_row_marginal_law'
def parents(r):
    own={r['name']:r for r in new};todo=list(r['direct']);seen=set();out=set()
    while todo:
        n=todo.pop()
        if n in seen:continue
        seen.add(n)
        if n==producer['name']:out.add(n)
        elif n in own:todo.extend(own[n]['direct'])
        elif n.startswith('AutoSamplingTheory.'):out.add(n)
    return sorted(out)
ps={producer['name']:parents(producer),consumer['name']:parents(consumer)}
assert ps[producer['name']]==[old]
assert ps[consumer['name']]==sorted([old,producer['name']])
reach=set(producer['transitive_owned']+consumer['transitive_owned']);assert all(r['name'] in reach for r in rows)
assert all(r['kind']=='theorem' and r['type_closed'] and r['body_closed'] for r in rows)
assert all(set(r['axioms'])<= {'propext','Classical.choice','Quot.sound'} for r in rows)
summary=[{k:v for k,v in r.items() if k not in ['body','type','direct']}|{'type_sha256':sha(r['type'].encode()),'body_sha256':sha(r['body'].encode()),'type_chars':len(r['type']),'body_chars':len(r['body']),'reachable_from_new_roots':r['name'] in reach} for r in rows]
result={'candidate_commit':m['candidate_commit'],'closure_module_count':len(m['modules']),'module_owned_total':len(rows),'new_handwritten':len(new),'new_generated':0,'all_owned_reachable_from_new_roots':True,'canonical_ASTIS_parents':ps,'all_types_bodies_closed':True,'only_standard_axioms':['propext','Classical.choice','Quot.sound'],'independent_literal_kernel_applied_both':True,'exact_author_probe_pass':True,'probability_sigmafinite_and_physical_coordinate_map_specializations_pass':True,'declarations':summary,'large_full_dump':{'path':'native-all-bodies.json','bytes':(ROOT/'native-all-bodies.json').stat().st_size,'sha256':sha((ROOT/'native-all-bodies.json').read_bytes()),'portable_inclusion':False}}
(ROOT/'native-summary.json').write_text(json.dumps(result,indent=2)+'\n')
(ROOT/'native-authored-types.txt').write_text('\n\n'.join(r['name']+'\n'+r['type'] for r in rows)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='declarations'},indent=2))
