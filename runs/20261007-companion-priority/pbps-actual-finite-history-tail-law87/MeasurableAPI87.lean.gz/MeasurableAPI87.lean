import AutoSamplingTheory.ExampleCases.ProximalBPS.ActualFiniteJumpRecursion
import AutoSamplingTheory.TechnicalLemmas.Probability.UnitExponentialProduct
open MeasureTheory ProbabilityTheory
#check @measurable_pi_lambda
#check @Measurable.prodMk
#check @iIndepFun_iff_iIndep
#check @MeasurableSpace.comap_mono
#check @indep_of_indep_of_le
#check @Measure.map_infinitePi_infinitePi_of_inj
