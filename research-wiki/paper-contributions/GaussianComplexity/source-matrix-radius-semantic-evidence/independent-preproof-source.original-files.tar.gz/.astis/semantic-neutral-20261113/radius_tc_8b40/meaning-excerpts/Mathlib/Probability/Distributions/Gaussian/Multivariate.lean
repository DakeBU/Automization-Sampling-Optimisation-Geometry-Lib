open scoped RealInnerProductSpace MatrixOrder

namespace ProbabilityTheory

variable {ι : Type*} [Fintype ι]

section stdGaussian

/-! ### Standard Gaussian measure over a Euclidean space -/

variable {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℝ E] [FiniteDimensional ℝ E]
  [MeasurableSpace E]

variable (E) in
/-- Standard Gaussian distribution on a finite-dimensional real inner product space `E`.
This is the random vector whose coordinates in an orthonormal basis are independent standard
Gaussian.

The definition uses `stdOrthonormalBasis ℝ E` but does not actually depend on the
basis, see `stdGaussian_eq_map_pi_orthonormalBasis`. -/
noncomputable
def stdGaussian : Measure E :=
  (Measure.pi (fun _ : Fin (Module.finrank ℝ E) ↦ gaussianReal 0 1)).map
    (fun x ↦ ∑ i, x i • stdOrthonormalBasis ℝ E i)

variable [BorelSpace E]

instance isProbabilityMeasure_stdGaussian : IsProbabilityMeasure (stdGaussian E) :=
  Measure.isProbabilityMeasure_map (Measurable.aemeasurable (by fun_prop))

@[simp]
lemma integral_id_stdGaussian : ∫ x, x ∂(stdGaussian E) = 0 := by
  rw [stdGaussian, integral_map _ (by fun_prop), integral_finsetSum]
  · simp [integral_smul_const, integral_eval]
