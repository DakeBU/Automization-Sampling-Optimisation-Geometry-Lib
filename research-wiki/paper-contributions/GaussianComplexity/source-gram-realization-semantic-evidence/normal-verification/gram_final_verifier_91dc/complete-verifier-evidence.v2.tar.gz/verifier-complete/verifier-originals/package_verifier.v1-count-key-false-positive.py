"""Package explicitly selected originals only, after the one normal V is inspected."""
import datetime, io, json, subprocess, sys, tarfile
from guard import *
from evidence_preflight import E,S,HELD

outcome = read(O/'normal-VERIFIED-outcome.bounded.json')
assert outcome['normal_API_calls'] == 1 and outcome['verified_commit'] == HELD
assert outcome['status'] == 'VERIFIED_LOCAL_ONCE_OWNER_AND_GLOBAL_HOLD_RETAINED'
inputs = read(O/'packaging-inputs.json')
selected = {}
def add(name,path):
    path=Path(path)
    assert name not in selected and path.is_file() and not path.is_symlink()
    assert not any('.private.' in p or p.startswith('.PRIVATE') for p in path.parts)
    assert path.name != 'guard.py', 'private guard implementation must remain local'
    selected[name]=path
own_files = [
    'PREPARATION-PLAN.json','evidence_preflight.py','evidence-preflight.bounded.json',
    'verify_expression_evidence.py','expression-evidence-crosscheck.bounded.json',
    'verifier-preflight-hash-qualification.json','peer-wording-qualification.json','held-preflight.bounded.json',
    'prepare_normal_verification.py','execute_normal_once.py','recorded_run.py','final_reader_package_check.py',
    'final-reader-and-package-check.bounded.json','ROOT-READY.received.json','packaging-inputs.json',
    'VERIFIED-evidence.full.json','candidate-cell.exact.json','cell-before.exact.json',
    'before-normalV-preservation.bounded.json','normal-VERIFIED-call.once.json',
    'normal-API.receipt.json','actual-VERIFIED-append.exact.jsonl',
    'after-normalV-preservation.bounded.json','normal-VERIFIED-outcome.bounded.json',
    'VERIFICATION-JUDGMENT.md','package_verifier.py']
for name in own_files: add('verifier-originals/'+name,O/name)
for label in ['normal-once','postwrite-frontier']:
    for name in ['stdout','stderr','receipt.json']:
        add('verifier-originals/commands/'+label+'/'+name,O/'commands'/label/name)
add('historical-originals/PROVED_LOCAL-evidence.full.json',E/'actual-PROVED_LOCAL-evidence.full.json')
add('historical-originals/PROVED_LOCAL-append.exact.jsonl',E/'actual-PROVED_LOCAL-append.exact.jsonl')
add('source-review-selected-originals.tar.gz',S/'complete-source-originals.tar.gz')
add('source-review-selected-originals.manifest.json',S/'complete-source-originals.manifest.json')
for item in inputs['native_reader_selected_inputs']:
    path=ROOT/item['path']
    assert sha(path.read_bytes())==item['sha256'] and path.stat().st_size==item['bytes']
    add('native-reader-originals/'+item['portable_name'],path)
add('tinycheck.py',O/'package_tinycheck.py'); add('README.md',O/'PACKAGE-README.md')
records = [{'path':name,'bytes':path.stat().st_size,'sha256':sha(path.read_bytes()),
            'source_relative_to_repo':str(path.relative_to(ROOT))} for name,path in sorted(selected.items())]
manifest = {'verifier_id':VERIFIER,'held_commit':HELD,'payload_file_count':len(records),'files':records,
    'selection':'Explicit selected verifier originals plus one selected source-review archive and one selected native/reader archive.',
    'original_PL_fields_inline_unchanged':26,'normal_API_calls':1,
    'excluded':['private guard implementation','full private states/indexes/fingerprint maps','foreign/control snapshots']}
mb=dump(manifest); sb=dump({'payload_manifest_sha256':sha(mb),'payload_file_count':len(records),
                         'archive_regular_members':len(records)+2,'archive_hash_is_external':True})
archive=O/'complete-verifier-evidence.tar.gz'
assert not archive.exists(), 'immutable selected archive already exists'
def put(tf,name,raw):
    info=tarfile.TarInfo('verifier-complete/'+name);info.size=len(raw);info.mode=0o644
    info.mtime=0;info.uid=0;info.gid=0;info.uname='';info.gname=''
    tf.addfile(info,io.BytesIO(raw))
with tarfile.open(archive,'x:gz') as tf:
    for name,path in sorted(selected.items()):put(tf,name,path.read_bytes())
    put(tf,'payload-manifest.json',mb);put(tf,'manifest-seal.json',sb)
destination=O/'package-check';destination.mkdir(exist_ok=False)
with tarfile.open(archive,'r:gz') as tf:
    members=tf.getmembers();names=[m.name for m in members]
    assert len(names)==len(set(names))==len(records)+2
    assert all(m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts for m in members)
    for item in records:
        raw=tf.extractfile('verifier-complete/'+item['path']).read()
        assert len(raw)==item['bytes'] and sha(raw)==item['sha256']
    tf.extractall(destination,filter='data')
command_dir=O/'commands/package-tinycheck';command_dir.mkdir(parents=True,exist_ok=False)
argv=[sys.executable,str(destination/'verifier-complete/tinycheck.py')]
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
result=subprocess.run(argv,cwd=destination,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
create(command_dir/'stdout',result.stdout);create(command_dir/'stderr',result.stderr)
create(command_dir/'receipt.json',dump({'argv':argv,'started_at':started,
    'ended_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':result.returncode,
    'stdout_sha256':sha(result.stdout),'stderr_sha256':sha(result.stderr)}))
assert result.returncode==0, 'offline package tinycheck failed; do not replay V'
closure={'status':'PASS','archive':str(archive.relative_to(ROOT)),'bytes':archive.stat().st_size,
    'sha256':sha(archive.read_bytes()),'payload_manifest_sha256':sha(mb),'manifest_seal_sha256':sha(sb),
    'payload_files':len(records),'archive_regular_members':len(records)+2,
    'all_archive_member_names_membership_and_payload_bytes_verified':True,
    'recursive_private_map_scan_and_offline_tinycheck_exit':result.returncode,
    'tinycheck_receipt_sha256':sha((command_dir/'receipt.json').read_bytes()),
    'normal_API_calls':1,'actual_VERIFIED_append_sha256':outcome['actual_VERIFIED_append_sha256'],
    'owner_and_global_HOLD_retained':True,'full_private_maps_indexes_and_control_snapshots_exported':False}
create(O/'complete-archive-closure.json',dump(closure))
print(json.dumps(closure,indent=2))
