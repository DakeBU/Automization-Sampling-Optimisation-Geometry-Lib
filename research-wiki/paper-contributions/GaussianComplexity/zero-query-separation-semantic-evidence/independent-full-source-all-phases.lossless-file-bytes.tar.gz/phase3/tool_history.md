# Tool-record provenance

All candidate inputs were read at commit `eed870294de059136900110ade59b4a292a126ad` using the exact path-specific git commands listed in `tool_records/git_show_commands.json`. Raw complete stdout and stderr for every such git command are retained, including empty stderr. P/T/metadata input snapshots are byte-identical copies of those outputs.

After initialization, `record_command.py` recorded the actual argv, cwd, return code, UTC time, complete stdout/stderr bytes and hashes for each wrapped command before presenting output. Every resulting file, including empty stderr and the unsuccessful targeted lookup, is included in the final manifest. No evidence filename whitelist or failure-record deletion is used.

The initial commands before that wrapper existed were:

```text
mkdir -p .astis/semantic-neutral-20261110/z_src_2f8a71/phase3/inputs .astis/semantic-neutral-20261110/z_src_2f8a71/phase3/tool_records
python3 .astis/semantic-neutral-20261110/z_src_2f8a71/phase3/read_pinned.py
cat .astis/semantic-neutral-20261110/z_src_2f8a71/phase3/inputs/P.lean .astis/semantic-neutral-20261110/z_src_2f8a71/phase3/inputs/T.lean
```

All three returned0. The mkdir output was empty. read_pinned.py's individual git command outputs are preserved; its printed JSON command inventory and the cat's complete P+T display remain in the tool transcript. P/T original bytes are preserved in inputs and raw git outputs. I do not claim a captured raw tool-envelope file for these early unwrapped calls or invent one retrospectively.

`tools.apply_patch` was used only to create/update this reviewer's new phase3 files. Every resulting source script/report is in the manifest. The first version of audit_exact_inputs.py is retained as audit_exact_inputs.v1.py. Its diagnostic false for context_file survives in tool_records/exact_input_audit.stdout; the corrected v2 run survives separately. The failed lookup's full records use coordinate_def_targets.*. No candidate code was edited.

The mathematical judgment and full independent review files were frozen with:

```text
chmod 444 .astis/semantic-neutral-20261110/z_src_2f8a71/phase3/mathematical_judgment.md .astis/semantic-neutral-20261110/z_src_2f8a71/phase3/independent_review.md
```

That command returned0 with empty output. It followed the disclosed late root reader-observation messages. The final whole-directory freeze is executed directly with freeze_phase3.py so a command wrapper cannot create unmanifested output files after the freeze. Its receipt records the actual final hash/mode verification. Its final tool output is a digest receipt, not a mathematical/native verdict.
