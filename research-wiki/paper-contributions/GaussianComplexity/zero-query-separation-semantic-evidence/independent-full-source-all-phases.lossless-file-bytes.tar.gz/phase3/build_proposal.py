from pathlib import Path
import hashlib,json
BASE=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
slots={
 'objects':{
  'original':'Source-derived auxiliary: A0=I and A1=diag(kappa,1,...,1) are precisions, pi_j=N(0,A_j^-1), and B is the closed first-coordinate slab.',
  'reconstructed':'Actual inverse matrix covariances supplied to canonical multivariateGaussian on EuclideanSpace Real(Fin d); B uses Fin0 and real event masses.',
  'relation':'explicit-elaboration',
  'evidence':'Frozen phase1 source calculation and independent_review.md reachable-definition audit; canonical inverse, Gaussian, WithLp coordinate and Measure.real definitions directly inspected. PSD/probability guards rule out fallback artifacts.'},
 'domains':{
  'original':'All integer dimensions d>=1 and real kappa>=4; ordinary Borel probabilities on R^d.',
  'reconstructed':'Universal d:Nat with hd:1<=d and kappa:Real with hκ:4<=κ; no additional block/dimension or upper-kappa constraint.',
  'relation':'equivalent',
  'evidence':'Exact sealed P/T signatures, unchanged phase2 type and decoder, actual code positivity/inverse arguments. Both d=1 and kappa=4 remain; negative/zero covariance branches unreachable.'},
 'quantifiers':{
  'original':'For every allowed d,kappa the concrete target pair and event have the stated gap; law-level consequence quantifies any one common output probability.',
  'reconstructed':'Implicit universal d,kappa with source bounds and literal lets; private T universally quantifies arbitrary rho:ProbabilityMeasure.',
  'relation':'same',
  'evidence':'Whole-module review finds no scoped parameters, existential event/covariance witnesses or hidden project bundles. ProbabilityMeasure expands only Measure plus total mass one.'},
 'assumptions':{
  'original':'d>=1 and kappa>=4 suffice for the event-gap auxiliary; common-law consequence uses the ordinary probability-law domain.',
  'reconstructed':'Only hd,hκ in P; same bounds and rho probability in T. Positivity/inverse, coordinate laws, measurability, integrability, finite mass, density and supremum bounds are derived internally.',
  'relation':'same',
  'evidence':'P hκpos/heigenvaluepos/hApos/hinv/hp0/hp1, finite-volume and Gaussian-integrability arguments; T hB/hbounded/hsup0/hsup1. No excess theorem-shaped binder.'},
 'conclusion':{
  'original':'Evaluating the source slab yields the oriented event gap pi_A1(B)-pi_A0(B)>1/8, underlying the displayed TV/integral chain.',
  'reconstructed':'1/8 < nu1.real B-nu0.real B; actual private consumer excludes simultaneous event-sup TV errors <=1/16.',
  'relation':'explicit-elaboration',
  'evidence':'Signed direction was independently frozen in phase1, then matched by actual marginal/scaling/integral proof. T genuinely calls P and uses opposing abs_le bounds at the strict 1/8 versus non-strict 1/16 endpoint.'},
 'scopes':{
  'original':'Auxiliary component inside the undisclosed-input source zero-query proof; complete source paragraph also has actual algorithm common-law and T>=1 steps.',
  'reconstructed':'Public analytical event gap plus private arbitrary-common-probability-law obstruction, explicitly a prerequisite; algorithm/seed/cap/class/accuracy adapters and T>=1/Q_G are separate.',
  'relation':'explicit-elaboration',
  'evidence':'P/T module comments, seal, lesson/publication boundaries and correspondence remaining fields agree with independently frozen source scope. Different spectra prohibit free-disclosed-spectrum transfer. Static literal folds do not certify rendered adjacency/delivery.'},
 'constant_dependencies':{
  'original':'Literal kappa>=4, closed event radius1/2, strict gap>1/8 and source accuracy endpoint1/16; gap constant independent of dimension/kappa.',
  'reconstructed':'Same literal endpoints and inequalities; canonical exact pi/exp bounds establish a=phi(1)>1/8; T retains <=1/16.',
  'relation':'same',
  'evidence':'Actual P density/numeric segment and T endpoint contradiction; no floating point, hidden constants, extra kappa upper bound or excluded d1/kappa4. Δ is sup absolute event difference, source normalized TV without factor2.'}
}
proposal={
 'state':'source-reviewed',
 'verdict':'equivalent-after-elaboration',
 'semantic_slots':slots,
 'deltas':[
  {'slot':'conclusion','severity':'informational','description':'The public Anchor isolates a signed event-gap auxiliary implicit in the source event computation; it does not restate every inequality of the raw TV/integral display.','evidence':'Original raw S3.SS3.SSS0.Px1.p1.1 + S3.Ex3, frozen phase1 signed calculation; actual P coordinate laws/scaling/band/PDF proof and clearly auxiliary publication scope. No reverse inference from TV separation is used.'},
  {'slot':'scopes','severity':'informational','description':'The actual algorithm common-law adapter, uniform-accuracy/class instantiations and T>=1/Q_G conclusion remain unformalized by this candidate; the private theorem is a genuine arbitrary-common-law consequence.','evidence':'Exact P/T plus explicit seal/lesson/publication/map remaining boundaries. T calls P with hd,hκ and contains no algorithm/seed/stopping/T model. This matches the declared auxiliary scope, not full paragraph completion.'},
  {'slot':'scopes','severity':'informational','description':'Mathematical reader-text alignment and six literal folds are reviewed; source/download-button adjacency and full rendered delivery are not accepted here.','evidence':'fold_audit.json verifies six literal strings including full T. No renderer/browser inspected. Late root-relayed other-role reader finding is disclosed in exposure.json and root_messages.raw.txt; it is not independent delivery evidence.'}
 ],
 'source_review':{
  'state':'accepted',
  'reviewer':'/root/zeroquery_fresh_source_2f8a71',
  'independent_from_formalizer':True,
  'independent_from_decoder':True,
  'reviewer_packet_sha256':'698e80cd3f8ff7485ee94c15987e8c2c7b72f6bf49da88f792c3cafb81f0e6a6',
  'evidence':'Independent raw-source cognition frozen before type exposure; phase2 selective comparison frozen before whole-code exposure; exact-commit P/T and authored source/lesson reviewed against original source. All38 Unicode-character locator hashes and six literal folds pass, including full T; private consumer truly invokes producer; all meaning-bearing Gaussian/probability/inverse/TV branches audited. Acceptance is for the bounded signed-event auxiliary and private common-law consequence only, with explicit algorithm/cap/disclosed-spectrum and native/delivery limits. Phase1 filename-only caveat and late relayed reader observation are disclosed. No prior verdict/root/native log was used as mathematics; no normalV/sourceV/application/native check executed.',
  'review_run_sha256':sha(BASE/'independent_review.md'),
  'run_artifact':str(BASE/'independent_review.md')
 }
}
(BASE/'source_review_proposal.json').write_text(json.dumps(proposal,ensure_ascii=False,indent=2)+'\n')
assert set(proposal)=={'state','verdict','semantic_slots','deltas','source_review'}
assert set(slots)=={'objects','domains','quantifiers','assumptions','conclusion','scopes','constant_dependencies'}
assert all(set(x)=={'slot','severity','description','evidence'} for x in proposal['deltas'])
assert proposal['source_review']['reviewer'] not in {'huanjian_gc_20261110_zero_query_separation','/root/neutral_decoder_aa8270'}
print(json.dumps({'proposal':str(BASE/'source_review_proposal.json'),'proposal_sha256':sha(BASE/'source_review_proposal.json'),'review_run_sha256':proposal['source_review']['review_run_sha256'],'verdict':proposal['verdict'],'source_review_state':proposal['source_review']['state'],'blocking_deltas':sum(x['severity']=='blocking' for x in proposal['deltas'])},indent=2))
