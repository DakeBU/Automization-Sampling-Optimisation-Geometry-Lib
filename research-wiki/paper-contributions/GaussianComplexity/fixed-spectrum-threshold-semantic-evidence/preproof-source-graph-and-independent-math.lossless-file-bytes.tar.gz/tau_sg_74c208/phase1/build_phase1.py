"""Package source-only Phase 1; no target, Lean, API, Git, or ledger access."""
from pathlib import Path
import collections
import hashlib
import json
import re
import runpy
import shutil

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'phase1'
REPO = ROOT.parents[2]
M = runpy.run_path(str(ROOT / 'extract_raw_source.py'))
P, NODES, RAW = M['PARSER'], M['NODES'], M['RAW']
BYTE = M['BYTE']
OUT.mkdir(exist_ok=True)


def js(path, obj):
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n')


def digest(data):
    return hashlib.sha256(data).hexdigest()


notes = {
 'S2.p1': ('NODE', 'source_definition', 'Euclidean norm, identity matrix, and Loewner-order conventions.'),
 'S2.p2': ('NODE', 'source_definition', 'Orthogonal group and Haar measure; determinant-conditioned Haar convention is background, unused in this bounded slice.'),
 'S2.SS0.SSS0.Px1.p1': ('NODE', 'source_definition', 'Precision class and centered Gaussian target; exact first-order oracle formula is separately excluded.'),
 'S2.SS0.SSS0.Px1.p2': ('EXCLUDED', 'proof_paragraph', 'Oracle-model equivalence is outside the tau-small and shifted-detector moment boundary.'),
 'S2.SS0.SSS0.Px2.p1': ('NODE', 'source_definition', 'Borel algorithm/output, private randomness independent of input, deterministic per-run query cap.'),
 'S2.SS0.SSS0.Px3.p1': ('EXCLUDED', 'source_definition', 'TV definition is context for the later contradiction; bounded extraction stops at the two test-probability estimates.'),
 'S2.SS0.SSS0.Px4.p1': ('NODE', 'source_definition', 'Output law averages private randomness; Q_G definition separately excluded as surrounding theorem context.'),
 'S4.p1': ('EXCLUDED', 'external_citation', 'Historical lower bound and forward reference to limitations, not a producer of the bounded tau/detector estimates.'),
 'S4.Thmtheorem1.p1': ('NODE', 'theorem_statement', 'Ambient Theorem 4.1 quantifier order and parameter range; this packet does not claim the complete lower bound.'),
 'S4.p2': ('EXCLUDED', 'proof_paragraph', 'Comparison with Theorem 3.1 is not used in the bounded proof slice.'),
 'S4.SS1.p1': ('NODE', 'source_definition', 'Hard-grid theta/lambda/Lambda, independent Haar rotation O, A, potential, and target.'),
 'S4.SS1.p2': ('NODE', 'source_definition', 'Spectrum deterministic and available to algorithm; hidden random eigenbasis identifies input randomness.'),
 'S4.Thmtheorem2.p1': ('EXCLUDED', 'remark_statement', 'Remark 4.2 comparison and mechanism overview are not additional premises of the bounded estimates.'),
 'S4.SS2.p1': ('EXCLUDED', 'proof_paragraph', 'Roadmap to four lemmas, with no additional mathematical estimate.'),
 'S4.SS2.SSS0.Px1.p1': ('NODE', 'external_citation', 'Krylov argument attributed to [22, Lemma 9.2]; the external paper and Appendix C.1 proof are not opened.'),
 'S4.SS2.SSS0.Px1.p2': ('NODE', 'source_definition', 'Literal block-Krylov span definition.'),
 'S4.Thmtheorem3.p1': ('NODE', 'lemma_statement', 'Krylov representation, imported only as a source-named boundary; no extraction of its Appendix C.1 proof.'),
 'S4.SS2.SSS0.Px1.p3': ('NODE', 'proof_paragraph', 'Extra output vector, adaptive polynomial coefficients, simultaneous-control requirement, and C.1 provenance.'),
 'S4.SS2.SSS0.Px2.p1': ('NODE', 'source_definition', 'n=2q+1 and cosine diagonal D_n; source explains high-frequency choice above degree-2q products.'),
 'S4.Thmtheorem4.p1': ('NODE', 'lemma_statement', 'Absolute C>0, literal two-term tau, tau<=1/2 conditional, one probability event simultaneously for every Krylov vector.'),
 'S4.SS2.SSS0.Px2.p2': ('NODE', 'proof_paragraph', 'C.2 provenance; affine spectral change of basis; kappa-independent uniform estimate.'),
 'S4.SS2.SSS0.Px2.p3': ('NODE', 'unnamed_estimate', 'Algorithm-output quadratic bound consumes representation and the uniform event.'),
 'S4.SS2.SSS0.Px3.p1': ('EXCLUDED', 'proof_paragraph', 'Transition sentence introducing target moments.'),
 'S4.Thmtheorem5.p1': ('NODE', 'lemma_statement', 'Target law, rho_kappa, n range, M/mu_n, exact means, and both variance bounds.'),
 'S4.Thmtheorem5.p2': ('NODE', 'lemma_statement', 'Extra condition d-n>=sqrt(kappa) for the normalized target-bias bounds.'),
 'S4.SS2.SSS0.Px3.p2': ('NODE', 'proof_paragraph', 'C.3 provenance and rotation of target sample to diagonal coordinates, preserving norm and cosine quadratic form.'),
 'S4.SS2.SSS0.Px4.p1': ('EXCLUDED', 'proof_paragraph', 'Admissibility proof referral to C.4 is outside this selected proof slice.'),
 'S4.Thmtheorem6.p1': ('NODE', 'lemma_statement', 'Admissibility is a named surrounding input for the algorithm experiment only; Appendix C.4 is not extracted.'),
 'S4.SS3.p1': ('EXCLUDED', 'proof_paragraph', 'Roadmap sentence for comparing two probabilities.'),
 'S4.SS3.p2': ('NODE', 'standing_assumptions', 'Fix delta, kappa and epsilon; budget q bound; per-input TV guarantee; source invokes admissibility.'),
 'S4.SS3.p3': ('NODE', 'source_definition', 'Set n and tau; literal shifted polynomial detector S_A and strict test event E_A.'),
 'S4.SS3.p4': ('NODE', 'proof_paragraph', 'For nonzero x only, normalized spectral weights and Chebyshev identity explain the signed detector threshold.'),
 'S4.SS3.SSS0.Px1.p1': ('NODE', 'unnamed_estimate', 'q+1 bound, n=o(d), two-term tau substitution, uniform eventual n<d/tau<=1/2, extended experiment, 0.99 event and averaged 0.01 pass bound.'),
 'S4.SS3.SSS0.Px2.p1': ('NODE', 'source_definition', 'M=trace(Lambda^-1), mu_n=trace(D_n Lambda^-1), beta=|mu_n|/M.'),
 'S4.SS3.SSS0.Px2.p2': ('NODE', 'unnamed_estimate', 'Uniform gap condition, beta lower bound, fixed b, rho tail and M lower bound, tau/beta->0 and M beta^2->infinity, then d0(delta) with tau<=beta/4 and M beta^2>=320.'),
 'S4.SS3.SSS0.Px2.p3': ('NODE', 'unnamed_estimate', 'For each fixed A, shifted mean, centered-L2 variance estimate, and Chebyshev lower bound P(Z>0)>=0.9.'),
 'S4.SS3.SSS0.Px3.p1': ('EXCLUDED', 'proof_paragraph', 'Final TV averaging contradiction is beyond the selected bounded endpoint; retained verbatim as an explicit exclusion.'),
 'A3.SS2.p1': ('NODE', 'source_definition', 'r, n, normalized cosine row t_i, Gaussian row gamma_i, and row definition/dimensions of B.'),
 'A3.SS2.p2': ('EXCLUDED', 'proof_paragraph', 'Strategy roadmap repeats the two matrix controls and upcoming concentration.'),
 'A3.Thmtheorem5.p1': ('NODE', 'fact_statement', 'Fact C.5: range, expected Gram matrices, deterministic cosine moments and row norm bound.'),
 'A3.SS2.p3': ('NODE', 'proof_paragraph', 'Triangular invertible polynomial/cosine change of basis proves range(B)=K_q.'),
 'A3.SS2.p4': ('NODE', 'proof_paragraph', 'Telescoping sine identity and nonzero sine denominator give cosine-grid cancellation for 0<|k|<2d.'),
 'A3.SS2.p5': ('NODE', 'proof_paragraph', 'Constant and nonconstant coordinate cases plus product-to-sum give sum t_i t_i^T=d I_r.'),
 'A3.SS2.p6': ('NODE', 'proof_paragraph', 'Gaussian covariance and tensor sum give E[B^T B]=I_{r^2}.'),
 'A3.SS2.p7': ('NODE', 'proof_paragraph', 'Frequency interval 1..4q+1<2d gives weighted cosine cancellation and E[B^T D_n B]=0.'),
 'A3.SS2.p8': ('NODE', 'unnamed_estimate', 'Deterministic ||t_i||^2<=1+2q<=2r.'),
 'A3.SS2.p9': ('EXCLUDED', 'proof_paragraph', 'Concentration roadmap; no new bound beyond the following fact.'),
 'A3.Thmtheorem6.p1': ('NODE', 'fact_statement', 'Fact C.6 fixes sufficiently large absolute C; both Gram bounds hold on one event of probability >=0.995.'),
 'A3.SS2.p10': ('NODE', 'proof_paragraph', 'L and R_i definitions, Gaussian exponential moment, Markov tail, and 0.999 truncation event.'),
 'A3.SS2.p11': ('NODE', 'unnamed_estimate', 'Shifted tail integration controls truncation bias by (L+3)/(1000d).'),
 'A3.SS2.p12': ('NODE', 'proof_paragraph', 'Independent truncated Y_i, radial scalar a, 0<=a<=1 and bias bound; weighted truncated expectation stays zero.'),
 'A3.SS2.p13': ('NODE', 'unnamed_estimate', 'Centered Z_i and uniform summand norm R_*=2r(L+1)/d for both sequences.'),
 'A3.SS2.p14': ('NODE', 'proof_paragraph', 'Gaussian fourth moments, PSD truncation removal, tensor row sum, and common variance v_*=2r(r+2)/d.'),
 'A3.SS2.p15': ('NODE', 'external_result', 'Uncited two-sided bounded matrix Bernstein, explicitly independent/centered/self-adjoint, same tail bound for both matrix sequences.'),
 'A3.SS2.p16': ('NODE', 'proof_paragraph', 'z and Delta; explicit quadratic expansion; 0.002 failure each and 0.996 simultaneous Bernstein event.'),
 'A3.SS2.p17': ('NODE', 'proof_paragraph', 'On truncation, original/truncated identities; union bound 0.995; unweighted bias Delta+(1-a), weighted Delta.'),
 'A3.SS2.p18': ('NODE', 'unnamed_estimate', 'Integer budget yields d>=2 and 2r<=d; absolute O constants, absolute c>0, and choose absolute C>=c in tau.'),
 'A3.SS2.p19': ('NODE', 'proof_paragraph', 'Choose C for C.6; on one 0.995 event use range(B), Gram lower/coercive bound and weighted upper bound, tau<=1/2, simultaneous all-u, then relax to 0.99.'),
 'A3.SS3.p1': ('NODE', 'source_definition', 'Recall grid definitions and state cosine expansion/moments/variance/bias sequence.'),
 'A3.Thmtheorem7.p1': ('NODE', 'fact_statement', 'Fact C.7 inverse-spectrum cosine series for every real theta; absolute and uniform convergence.'),
 'A3.SS3.p2': ('NODE', 'proof_paragraph', '0<rho<1, geometric-series identities, rational algebra, and uniform majorant prove C.7.'),
 'A3.Thmtheorem8.p1': ('NODE', 'fact_statement', 'Fact C.8 exact finite-grid M and signed mu_n for 1<=n<d.'),
 'A3.SS3.p3': ('NODE', 'proof_paragraph', 'Cosine-grid sum for every integer k, including k=2ad alias classes.'),
 'A3.SS3.p4': ('NODE', 'proof_paragraph', 'Coordinate Gaussian second moments and absolute convergence justify finite-sum/series interchange.'),
 'A3.SS3.p5': ('NODE', 'proof_paragraph', 'Only j=2ad survive; geometric summation gives exact M.'),
 'A3.SS3.p6': ('NODE', 'proof_paragraph', 'Product-to-sum, three disjoint alias classes for 1<=n<d, sign and geometric summation give exact signed mu_n.'),
 'A3.SS3.p7': ('NODE', 'proof_paragraph', 'Lemma 4.5 explicitly consumes C.8 for both means.'),
 'A3.SS3.p8': ('NODE', 'proof_paragraph', 'Independent diagonal coordinates, Gaussian fourth moments and lambda_i>=1 give both variances <=2M; exact M<=d/sqrt(kappa).'),
 'A3.SS3.p9': ('NODE', 'proof_paragraph', 'n<d gives positive signed mu_n and literal normalized-bias ratio with bounding fraction.'),
 'A3.SS3.p10': ('NODE', 'proof_paragraph', 'Integral formula and kappa>=2 bound log(1/rho) between 2/sqrt(kappa) and 3/sqrt(kappa); exponentiation.'),
 'A3.SS3.p11': ('NODE', 'proof_paragraph', 'Extra d-n>=sqrt(kappa) gives rho tail<=e^-4 and two-sided normalized bias bound.'),
}

regions = []
for name, start, end, why in [
    ('preliminaries', P.by_id['S2'].start, P.by_id['S2'].end, 'Definition context, including explicit exclusions for surplus oracle/TV/query-complexity material.'),
    ('section4-through-4-3', P.by_id['S4'].start, P.by_id['S4.SS4'].start, 'Hard family, named lemma boundaries, literal tau, and both Section 4.3 test estimates; surrounding comparison/contradiction explicitly excluded.'),
    ('appendix-C-2', P.by_id['A3.SS2'].start, P.by_id['A3.SS2'].end, 'Complete selected concentration provenance and Lemma 4.4 proof, including constants and conditional discharge.'),
    ('appendix-C-3', P.by_id['A3.SS3'].start, P.by_id['A3.SS3'].end, 'Complete selected target moment/bias provenance and Lemma 4.5 proof.'),
    ('cited-item-22', P.by_id['bib.bib3'].start, P.by_id['bib.bib3'].end, 'Exact bibliography item for the in-scope source attribution to [22]; external source not opened.'),
]:
    chunk = RAW[BYTE[start]:BYTE[end]]
    path = OUT / 'raw' / (name + '.raw.html')
    path.parent.mkdir(exist_ok=True)
    path.write_bytes(chunk)
    regions.append({'name':name, 'start_byte':BYTE[start], 'end_byte_exclusive':BYTE[end],
                    'length':len(chunk), 'sha256':digest(chunk), 'raw_path':str(path.relative_to(OUT)), 'selection_reason':why})


def in_scope(n):
    return any(r['start_byte'] <= BYTE[n.start] and BYTE[n.end] <= r['end_byte_exclusive'] for r in regions)


def para_of(n):
    while n is not None:
        if 'ltx_para' in n.classes:
            return n
        n = n.parent
    return None


def disposition(n):
    para = para_of(n)
    if para:
        assert para.id in notes, para.id
        return notes[para.id]
    if 'ltx_theorem' in n.classes:
        child = next(x for x in n.descendants() if 'ltx_para' in x.classes)
        return notes[child.id]
    if 'ltx_bibitem' in n.classes:
        return ('NODE', 'external_citation', 'Bibliographic identity only; no external theorem or proof is admitted from this item.')
    return ('EXCLUDED', 'structural_heading', 'Structural source heading/label; substantive content is inventoried in adjacent statement/paragraph/display records.')


items = []
for n in NODES:
    if not in_scope(n):
        continue
    is_para = 'ltx_para' in n.classes
    is_prose = n.tag == 'p' and 'ltx_p' in n.classes
    is_theorem = 'ltx_theorem' in n.classes
    is_display = n.tag == 'table' and 'ltx_eqn_table' in n.classes
    is_heading = re.fullmatch('h[1-6]', n.tag) is not None
    is_bib = 'ltx_bibitem' in n.classes
    is_cite = n.tag == 'a' and n.attrs.get('href', '').startswith('#bib.')
    if not any([is_para, is_prose, is_theorem, is_display, is_heading, is_bib, is_cite]):
        continue
    status, semantic_kind, reason = disposition(n)
    layer = ('theorem' if is_theorem else 'paragraph' if is_para else 'prose_subparagraph'
             if is_prose else 'display' if is_display else 'heading' if is_heading else 'bibliography' if is_bib else 'citation')
    if is_display:
        semantic_kind = 'source_definition' if n.id in ['S2.Ex1','S4.E11','S4.Ex10','S4.Ex12','S4.Ex13','S4.EGx2','A3.Ex85','A3.Ex105','A3.Ex107','A3.Ex108','A3.Ex112','A3.Ex119','A3.Ex122'] else 'reused_display'
    if n.id in ['S2.E1', 'S2.E2', 'S2.Ex2']:
        status = 'EXCLUDED'
        reason = {'S2.E1':'Exact oracle reply formula is outside this bounded tau/detector packet.',
                  'S2.E2':'Definition of query-complexity infimum is surrounding theorem context, not proved by this packet.',
                  'S2.Ex2':'TV formula supports the explicitly excluded final contradiction.'}[n.id]
    ident = n.id or 'raw-byte-' + str(BYTE[n.start])
    math = [{'source_id':x.id, **x.locator(), 'tex':x.attrs.get('alttext',''), 'display':x.attrs.get('display')}
            for x in n.descendants() if x.tag == 'math']
    record = {'stable_id':'src:'+ident, 'source_id':n.id, 'layer':layer, 'kind':semantic_kind,
              'disposition':status, 'reason_or_role':reason, **n.locator(), 'text_with_math_alttext':n.normalized(),
              'paragraph_id':para_of(n).id if para_of(n) else None, 'math_occurrences':math}
    if is_cite:
        record['citation_target'] = n.attrs['href']
        record['kind'] = 'external_citation'
    items.append(record)

assert set(notes) == {n.id for n in NODES if in_scope(n) and 'ltx_para' in n.classes}

# Partition all selected raw bytes. Residual markup/whitespace is explicitly
# excluded only after every source heading, prose p, display, and bibliography
# region has been given its own inventory disposition above.
segments = []
for region in regions:
    a,b = region['start_byte'],region['end_byte_exclusive']
    local = [x for x in items if a <= x['start_byte'] and x['end_byte_exclusive'] <= b]
    cuts = sorted({a,b} | {x[k] for x in local for k in ['start_byte','end_byte_exclusive']})
    for x,y in zip(cuts,cuts[1:]):
        covering = [i['stable_id'] for i in local if i['start_byte'] <= x and y <= i['end_byte_exclusive']]
        blob = RAW[x:y]
        segments.append({'region':region['name'],'start_byte':x,'end_byte_exclusive':y,'length':y-x,
                         'sha256':digest(blob),'inventory_covering':covering,
                         'disposition':'COVERED' if covering else 'EXCLUDED',
                         'reason':None if covering else 'HTML wrappers, inter-element whitespace, or non-mathematical navigation markup outside inventoried prose/headings/displays.'})
    assert sum(s['length'] for s in segments if s['region']==region['name']) == b-a

js(OUT/'scope-and-raw-locators.json', {'source_path':str(M['SOURCE']), 'source_sha256':M['EXPECTED'],
 'byte_convention':'UTF-8 raw-file 0-based half-open [start_byte,end_byte_exclusive); exact original bytes, not DOM/re-rendered offsets.',
 'phase':'1: independently read source; no sealed target yet; no proof graph edges yet', 'regions':regions,
 'outside_selected_proof_scope':['Section 3','Section 4.4 limitations','Appendix C.1 proof of Lemma 4.3','Appendix C.4 proof of Lemma 4.6','external [22] content'],
 'bounded_endpoints':['algorithmic averaged test-pass probability <=0.01','per-hard-input target test-pass probability >=0.9'],
 'no_completion_claim':'Named Lemma 4.3/4.6 boundaries and external standard results remain visible; not whole Theorem 4.1 closure.'})
js(OUT/'inventory.json', {'source_sha256':M['EXPECTED'], 'records':items,
 'counts':dict(collections.Counter((x['layer']+':'+x['disposition']) for x in items)),
 'nesting_note':'Paragraph/theorem records contain child prose/display records. They are lossless nested source inventory, not multiple independent proof claims or graph edges.'})
js(OUT/'raw-coverage-partition.json',segments)
(OUT/'source.raw.html').write_bytes(RAW)

reader = ['# Phase 1 independent source inventory', '',
          'This reader uses source math alttext for readability. The raw HTML and byte locators are authoritative.',
          'No sealed target or implementation Lean was read. Proof graph reconstruction is intentionally deferred.', '']
for x in items:
    if x['layer'] not in ['paragraph','theorem','display','bibliography','citation']:
        continue
    reader += ['## '+x['disposition']+' '+x['stable_id'], '',
               f"{x['kind']}; raw bytes [{x['start_byte']},{x['end_byte_exclusive']}); SHA256 {x['sha256']}", '',
               x['reason_or_role'], '', x['text_with_math_alttext'], '']
(OUT/'inventory-reader.md').write_text('\n'.join(reader))

inputs = [Path('AGENTS.md'), Path('docs/proof-digestion-protocol.md'),
          Path('.agents/skills/astis-source-dependency-audit/SKILL.md'),
          Path('.agents/skills/astis-substantive-advance/SKILL.md'),
          Path('.agents/skills/astis-semantic-roundtrip/SKILL.md')]
instruction_manifest = []
for i,path in enumerate(inputs):
    data=(REPO/path).read_bytes()
    dest=OUT/'instruction-inputs'/f'{i:02d}-{path.name}.raw'
    dest.parent.mkdir(exist_ok=True)
    dest.write_bytes(data)
    instruction_manifest.append({'path':str(path),'copy':str(dest.relative_to(OUT)), 'sha256':digest(data),'length':len(data),
                                 'exposure':'AGENTS, protocol and source/semantic skills read for process; substantive-advance skill searched only for source/audit/encoder/blind/semantic lines.'})
js(OUT/'instruction-inputs-manifest.json',instruction_manifest)

# Packaging scripts are included so byte extraction and coverage shape are
# reviewable. Their successful checks are structural, never source approval.
for name in ['extract_raw_source.py','build_phase1.py']:
    shutil.copyfile(ROOT/name, OUT/name)
print(json.dumps({'paragraphs':len(notes),'items':len(items),'raw_segments':len(segments),
                  'regions':[(r['name'],r['start_byte'],r['end_byte_exclusive']) for r in regions]},indent=2))
