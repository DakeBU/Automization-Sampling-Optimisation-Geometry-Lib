# Independent phase-3 source, complete-module, and authored-mathematics review

Reviewer: `/root/targetlaw_fresh_source_9c7d21`.
Immutable mathematical candidate: `8ee639d3aced826aa5b4e39fa6f8bedd3b830327`.

## Judgment and its boundary

The exact public Gaussian-law theorem, complete private target-norm consumer, and authored mathematical explanation preserve the attributed **fixed-basis Gaussian-law auxiliary and private finite norm-mean component**. My source-fidelity judgment is **equivalent-after-elaboration**. I found no blocking source/code semantic delta within that declared boundary. This is an independent source/code judgment, not a compiler/kernel/native verdict and not delivery acceptance.

The public result proves equality of the actual Gaussian measures, with the source precision matrices inverted as covariance parameters. It supports every fixed full real orthogonal matrix, including either determinant sign. The private proof genuinely invokes this public equality and transports **both** squared-norm integrability and the inverse-spectrum mean to the actual target. The internal frequency choice `1` is source-valid from `d≥2` and imposes no extra public or private hypothesis.

The raw source was read and frozen before candidate exposure. Phase-1 cognition hash: `d80ae7b6e13f65663fa21fa3fcbe6509fd7b5e469adad6b121a85d93541fd1a2`. Phase-2 comparison JSON hash: `9af65d0b5a11fb38938a5fbb7a34f65c8bd8cafb74eee2e6c78cf91c0ac5bfe5`. These freezes and their caveats are retained unchanged. The attributed audit contract is a paraphrase extracting an auxiliary, not a quotation of all Lemma 4.5. The pinned raw source is primary throughout this review.

I have not read root local checks, kernel/native verdicts, sourcegraph/TC verdict files, other prior source-review contents, browser artifacts, or delivery results. One old TC status label was unexpectedly present in the explicitly authorized map; its exact exposure and limits are disclosed below and in `phase3_input_exposure_ledger.md`. No Lean process was run and no candidate/global file was changed.

## Exact candidate and binding

Let `P` denote `AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumTargetLaw.lean`, and `T` denote `Tests/GaussianComplexityFixedSpectrumTargetLaw.lean`. Both were read and preserved from `git show` of the exact candidate, including all imports, options, comments, namespaces, statements, proofs, and closing context.

- `P` whole-file SHA-256: `5b86b8aa5ef936e7f008c74bb8aab67a0483a61a1428a03a00790e5af6730805`.
- `T` whole-file SHA-256: `ad1bab1856d082f8c033e6f3a8a543e70c3610c11a7605aacc95ce39309fa849`.
- Full reviewer packet raw SHA-256: `7825279129ff5d926b4c2a206e80854cbab2810fbcd7459137982a6bc8dec999`.
- Its canonical packet digest was independently recomputed, excluding the digest field, as `87e0d4528bfb55d403f04a0a9a7181326dbd92bf1431d92a5c355dd699471767`.
- The publication binding was independently reconstructed from the exact candidate module, toolchain and manifest hashes, actual authored lesson, actual publication source/statement/assumptions/obligation, and actual binding payload. Its digest is `3f8f86b61bf73df0bf7a51f989239ca2246fa5c88de21364b468816869ee86bc`.

The module text in the packet is byte-identical to `P` at the candidate. The packet's lesson is the actual candidate lesson with the boundary field omitted by the canonical sanitization rule; I separately read and reviewed that actual boundary. The source statement and source metadata agree with the candidate publication. This was checked from snapshots without running global publication inputs or reading a registry.

## Complete module and binder audit

`P` contains one public theorem and no other new declaration. Its imports are canonical actual admissibility, multivariate Gaussian construction, the matrix/Euclidean continuous-linear-map equivalence, and adjoints. Its namespace does not introduce standing variables, local axioms, instances, notation redefinitions, fallback source objects, macros, or extra section binders. `autoImplicit` is disabled. Its only statement inputs are the natural dimension, real conditioning parameter, source bounds `2≤d`, `2≤κ`, and an element of the full real orthogonal group. All local objects in the statement are literal `let` formulas.

`T` contains exactly one private theorem. Its two imports are the new law and the existing actual diagonal Gaussian-moment theorem. There is no additional public Anchor, instance, axiom, section premise, or hypothesis carrying a moment/integrability/law certificate. The entire private signature has the same source parameter restrictions. Its target measure is literally `multivariateGaussian 0 A⁻¹`, and its conclusion is squared-norm `Integrable` together with the finite inverse-spectrum integral. Neither conclusion is smuggled into a binder.

Textual inspection of these complete modules reveals no `sorry`, `admit`, axiom declaration, `Prop := True`, unsafe surrogate, native decision shortcut, or theorem-shaped convenience assumption. This is a statement about inspected source text; it is not an independently run axiom/kernel check. Canonical imported declarations remain canonical background, not new proof credit for this candidate.

The exact admissibility and diagonal-moment parent modules were also read from the same immutable candidate and matched the map's whole-file hashes. They contain the stated mathematical proofs, not an assumed target law or moment certificate. The admissibility proof derives bounds from the cosine envelope and conjugates diagonal positive-semidefinite differences. The diagonal-moment proof derives scalar positivity, the diagonal inverse, Gaussian coordinate L2/variance/means, finite-sum integrability, and the actual integrals. Those are supplied dependencies, not extra conditions of `P` or `T`.

## On-domain Gaussian meaning, including the fallback challenge

The actual Mathlib definition is

\[
\operatorname{multivariateGaussian}(m,S)
=(\operatorname{stdGaussian})_\#\bigl(x\mapsto m+\operatorname{toEuclideanCLM}(\operatorname{CFC.sqrt}S)x\bigr).
\]

I read the construction, its standard-Gaussian source, probability/Gaussian instances, mean theorem, covariance theorem, and the explicit `multivariateGaussian_of_not_posSemidef` theorem. The last theorem confirms that a non-positive-semidefinite matrix parameter yields a Dirac law at `m`. It would be a serious semantic error to use the constructor's parameter as a covariance without proving the positive-semidefinite condition.

That error does not occur in `P`. The actual proof obtains `hApos : A.PosDef` by calling `actual_precision_admissible hd hκ O`. It obtains `hΛpos : Λ.PosDef` by calling the same result at the identity orthogonal matrix and simplifying. I checked the actual parent statement and proof. The parent derives `1≤λ_i≤κ` from `cos θ_i∈[−1,1]`; it adds the positive-definite identity to the nonnegative lower difference. This is sufficient even though the raw C.4 argument also establishes strict interior scalar bounds from the grid.

I also read the canonical positive-definite definition and its inverse theorem: positive definite means Hermitian with strictly positive quadratic form on nonzero finitely supported vectors; over the real field it yields invertibility, and the actual nonsingular matrix inverse remains positive definite. Consequently `hΛpos.inv.posSemidef` and `hApos.inv.posSemidef` are the real covariance-validity facts required by `covarianceBilin_multivariateGaussian`. The proof supplies them in the exact covariance rewrite. Both inverse covariance parameters are on-domain. No non-PSD Dirac branch or singular-inverse totalization is used to make the theorem true vacuously.

The standard-Gaussian source constructs a product of variance-one real Gaussians in an orthonormal basis, proves zero mean and identity covariance, and proves Gaussianity. The matrix map is the canonical star-algebra equivalence for the standard Euclidean basis; its `toLp` and `ofLp` equations identify it with the literal matvec in the public signature. `EuclideanSpace` is `PiLp 2`; the canonical real norm-square identity is `||x||²=Σ_i(x_i)²`. Thus the library construction has the source's ordinary Euclidean Gaussian and norm meaning rather than a different carrier or normalization.

## Both orthogonal signs and inverse precision

The actual orthogonal-group membership equations are `UUᵀ=I` and `UᵀU=I`. I checked their exact canonical definitions/lemmas. Neither the group nor either proof uses a determinant-one condition. There is no division by `det O`, orientation case, Haar component premise, or restriction to a connected subgroup.

The production proof constructs a genuine left inverse:

\[
(U\Lambda^{-1}U^\top)(U\Lambda U^\top)
=U\bigl(\Lambda^{-1}(U^\top U)\Lambda\bigr)U^\top
=I.
\]

The middle inverse cancellation is justified by positive-definite `Λ`, and the outside cancellation uses the other orthogonal identity. Canonical `Matrix.inv_eq_left_inv` identifies the actual inverse of `A`; this is not an elementwise inverse or an unproved covariance substitution. The target covariance is precisely `(OΛOᵀ)^{-1}=OΛ^{-1}Oᵀ`. Both full orthogonal signs are covered by exactly the same equations.

The zero-based `Fin d` grid agrees with the raw one-based grid under `j=i.val+1`. This preserves the half-grid shift, spectral scale, dimension, and all scalar divisions exactly.

## A full law, rather than an equality of selected moments

After representing the rotation by the canonical continuous linear map `T`, the proof identifies `T.adjoint` with the transposed matrix map through the star-algebra equivalence. It then proves the covariance-operator identity

\[
T\operatorname{toEuclideanCLM}(\Lambda^{-1})T^*
=\operatorname{toEuclideanCLM}(A^{-1}).
\]

It proves that the mean of the mapped Gaussian and that of the target are both zero, using integrability of the Gaussian identity function. It proves equality of their full covariance bilinear forms, using the canonical covariance-map formula, both positive-semidefinite inverse covariance facts, the adjoint inner-product identity, and the operator equality above.

The crucial final step is `IsGaussian.ext`, not a generic claim that two arbitrary measures with matching first and second moments are equal. I read its class hypotheses and proof: both measures must be Gaussian, and equality follows from their characteristic functions. The actual multivariate constructor is Gaussian, and the canonical continuous-linear-map instance proves that its image is Gaussian. Thus the candidate does prove equality of the whole Borel probability measures. It does not merely prove the norm mean, a covariance comparison, a density assertion, or a finite collection of tests.

At each fixed `O`, this forward measure equality is equivalent via the inverse map to the raw source sentence that `U=OᵀY` has law `N(0,Λ^{-1})` when `Y` is an exact target sample. This isolates the deterministic auxiliary; it does not construct the paper's random-basis joint/conditional experiment or a chosen conditional-law version. The raw every-rotation admissibility and per-input target definition support that pointwise auxiliary. The actual candidate and lesson keep this scope explicit.

## Genuine private consumption of both L1 and mean

The complete private proof contains the actual call

```lean
have hLaw : μ.map R = ν :=
  AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumTargetLaw.actual_rotated_gaussian_target hd hκ O
```

It obtains the diagonal Gaussian moment theorem at `n=1`. The side conditions are the closed arithmetic fact `1≤1` and `1<2≤d`; the latter is explicitly constructed from `hd`. There is no external frequency binder or assumed bias/separation condition. The norm component of that paired theorem is independent of the chosen frequency.

The private proof extracts `hm.1` as `Integrable g μ` and `hm.2.2.1` as the actual inverse-spectrum norm mean. The parent statement confirms these projections. It derives measurability of the actual matvec from its continuous-linear representation, and norm preservation from its membership in the unitary group of that representation. This uses the full orthogonal group through a star-monoid homomorphism, so it also applies to reflections.

With `g(x)=||x||²`, the actual `hcomp` proves `g∘R=g` for all vectors. `integrable_map_measure` transports the diagonal integrability into `hmapLint : Integrable g (μ.map R)`. The proof then changes its goal to `Integrable g ν ∧ integral_ν g = …` and uses `rw [← hLaw]`. This rewrites the target measure in **both conjuncts**, making the first exactly `hmapLint` and the second the mapped integral. `integral_map` and `hcomp` reduce the second conjunct to the actual diagonal `hmean`.

Thus the earlier phase-2 uncertainty about actual consumption is resolved by visible code: `hLaw` is not a dead fact or a superficial call, and the application genuinely transports both L1 and the mean to the actual target measure. There remains no moment or integrability certificate in the private theorem's inputs.

## Source anchors, source argument, and limits

The precise raw anchors have different roles:

- `S2.SS0.SSS0.Px1.p1`: precision-class potential and target `N(0,A^{-1})`.
- `S4.E11`: actual cosine grid and hard-family diagonal precision.
- `S4.SS2.SSS0.Px3.p2.1`: inverse-coordinate Gaussian law and orthogonal preservation of the norm/quadratic statistic.
- `A3.SS3.p4` / `A3.Ex140`: diagonal norm mean `M=Σ_i 1/λ_i`.
- `A3.SS3.p8`: finite Gaussian second/fourth-moment reasoning used in the source; this candidate needs only the finite second-moment component.
- `A3.SS4.p1`: admissibility/positive precision context.
- `A3.SS4.p3.1`: associated target definition. The neighboring `A3.Ex160` and `A3.SS4.p3.2` concern the partition-function/known-normalizer context, not the conclusion of `P` or `T`.

The last boundary follows directly from the preserved raw text and actual code: neither theorem concludes a determinant normalizer formula, public-spectrum knowledge, Gaussian density identification, or algorithmic access/cost. I did not infer it from the map's old status phrase. The map's repeated anchor triple provides global grid/law/norm provenance for its code locators; it is not an independently reviewed exhaustive source proof graph, and I make no topology/coverage acceptance claim about the withheld graphs whose hashes appear there.

The raw source invokes ordinary Gaussian linear transformations and moments; the implementation uses canonical Gaussian characteristic-function uniqueness and covariance transport to formalize the same fixed-basis law. This is a faithful implementation route for that auxiliary, not a claim that the raw author wrote this exact Lean-oriented decomposition. The norm parent uses canonical coordinate variances and finite sums to supply the source's `Σ_i λ_i^{-1}` step.

The closed formula for `M`, cosine-frequency means, fourth moments, variance bounds, normalized bias, target-pass probability, concentration, adaptive/Haar/Krylov laws, sampling/oracle/TV/cap/cost adapters, and main lower bounds are not conclusions of these exact modules. The authored boundary says so, and the publication binds only one prerequisite obligation. There is one public Anchor and one private consumer, not an invented second public source result.

## All 29 exact source-map locators

The map raw SHA-256 is `52c044e7ba4352549f710bdda2a99afb58cd2f4da27771a041333d84b4f90120`. I checked **all 29 rows**, including `P-type` and `C-type`, by decoding each exact source file as UTF-8 and slicing `text[start_character_offset:end_character_offset_exclusive]`. These are Unicode character offsets, start inclusive/end exclusive; no row was reinterpreted as byte offsets or an inclusive endpoint.

For every row I recomputed the whole-file byte hash, the UTF-8 hash of the selected character slice, the exact start marker, any supplied exclusive-end marker, and both line numbers. All 29 block hashes, all whole-file hashes, all markers, and all line numbers matched. There are 15 distinct mapped source files. Candidate/ASTIS sources came from the pinned commit; canonical Mathlib sources were checked against the map's exact whole-file hashes before use. Exact source files and all selected blocks are preserved, with the complete per-row results in `all29_locator_verification.json`.

This verifies locator identity, not prior compilation labels or sourcegraph truth. I independently read the relevant mapped canonical facts/parent proofs rather than treating successful hashing as a mathematical verdict.

## Authored lesson and publication

I read the actual lesson and publication at the candidate, including author-supplied assumption classifications; these are claims checked against the raw source and code, not prior independent verdicts. All six formula steps are mathematically faithful to the actual proof:

1. Derive both positive precisions through the admissibility parent, at `O` and identity.
2. Establish the actual inverse conjugation with both orthogonal identities.
3. Identify adjoint and transported covariance operator.
4. Identify the full Gaussian measure by Gaussianity, equal means, and the full covariance bilinear form.
5. Invoke the public law and diagonal moments at the valid internal frequency, and derive measurable norm-preserving transport and mapped L1.
6. Rewrite the actual target by `hLaw` and transport the finite expectation.

Each step's exact Lean text was checked as a contiguous substring of the pinned `P` or `T`; step 6 is exactly the **entire** pinned `T`, including imports and its private statement. The mathematical formulas agree with those code blocks. The dependency notes correctly distinguish the public admissibility parent from the additional diagonal-moment parent used by the private application. The source attribution is explicitly a paraphrase of the extracted component, and the current boundary accurately excludes the larger paper results.

The lesson stores the complete exact private test and the source-adjacent mathematical explanation needed for the proposed reader. I have not built or inspected generated HTML, folding behavior, MathJax, mobile layout, or a browser. Therefore this is authored-content semantic acceptance only; rendered reader delivery remains a separate check.

## Independence and exposure qualification

The exact prior freezes are retained. In phase 1 an `AGENTS.md` inventory printed three prior-review directory names without opening their contents, and a broad capital-Z scan displayed additional formulas only from the pinned original raw paper. Ordinary model pretraining familiarity or recognition cannot be guaranteed absent.

In phase 3 the expressly authorized map included this sentence in `source_normalizer_boundary`: “Original TC HOLD and exact source-author two-string successor both retained.” I saw that old status label, immediately disclosed it to the parent, and did not open any referenced graph or verdict. The parent instructed me to retain that exposure, not use it as evidence, and pause a specific item if it actually affected a code judgment. No specific code issue required that status label to resolve: the source/code reasoning and normalizer boundary above are independently grounded in the already frozen raw source, literal target constructors, theorem conclusions, and full proofs. I cannot certify absence of subconscious influence and make no zero-anchoring claim.

The reviewer is distinct from the supplied formalizer and decoder identities and has acted only as the original-source reviewer in this run. Decoder access-history claims remain supplied metadata; the phase-3 canonical packet and reconstruction hashes were verified, but this does not independently recreate the decoder's access history.

## Remaining process boundary

This review may support a **source-reviewed** audit proposal for the exact packet and candidate. It does not apply that proposal or authorize a normal V transition. Independent exact-candidate native evidence and a reviewed carrier must precede any later normal V in a separate explicit step. No registry application, API/intake action, STAB, global publication, purification, delivery, or Goal-completion credit is asserted. Phase 3 ends by freezing this judgment and pausing.
