import json, os, re
from verify import *

seal=json.loads((D/'inputs/research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-cosine-gram-statement-seal.json').read_text())
header='''import Tests.GaussianComplexityFixedSpectrumCosineGram
open Matrix MeasureTheory ProbabilityTheory Lean
open scoped BigOperators
set_option autoImplicit false
set_option pp.width 120
set_option pp.maxDepth 500
'''
for key, name, file, signature in [('producer','IndependentExpectedProducer',P,'producer-signature.txt'),
    ('actual_private_consumer','IndependentExpectedConsumer',T,'consumer-signature.txt')]:
    s=seal[key]['signature']
    assert sha(s.encode())==seal[key]['signature_sha256']
    assert s==(D/'inputs'/E/signature).read_text()
    assert s in (D/'inputs'/file).read_text()
    assert '{d q : ℕ} (hq : 2 * q + 1 < d) :' in s
    prefix=s.split(' {d q : ℕ}')[0]
    header+='\ndef '+name+' : Prop := ∀ {d q : ℕ} (hq : 2 * q + 1 < d),'+s.split(' {d q : ℕ} (hq : 2 * q + 1 < d) :',1)[1]+'\n'
probe=r'''
run_cmd do
  setEnv ((← getEnv).setExporting false)
  let env ← getEnv
  let producerModule := `AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumCosineGram
  let consumerModule := `Tests.GaussianComplexityFixedSpectrumCosineGram
  let some pi := env.getModuleIdx? producerModule | throwError "Producer module absent"
  let some ti := env.getModuleIdx? consumerModule | throwError "Consumer module absent"
  let isOwned := fun n => env.getModuleIdxFor? n == some pi || env.getModuleIdxFor? n == some ti
  let owned := env.constants.toList.filter (fun (n, _) => isOwned n)
  let producer := `AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumCosineGram.actual_cosine_frame_gram
  let roots := owned.filter (fun (n, _) => n == producer || n.toString.endsWith ".actual_gaussian_gram_means")
  unless roots.length == 2 do throwError "Wrong root inventory {roots.map Prod.fst}"
  let allowed := [`propext, `Classical.choice, `Quot.sound]
  let mut allReach : NameSet := {}
  for (root, ci) in roots do
    match ci with
    | .thmInfo _ => pure ()
    | _ => throwError "Root is not a theorem {root}"
    unless !ci.type.hasFVar && !ci.type.hasMVar && !ci.type.hasLooseBVars do
      throwError "Nonclosed root type {root}"
    let expected := if root == producer then `IndependentExpectedProducer else `IndependentExpectedConsumer
    let checked := if root == producer then `IndependentProducerKernelChecked else `IndependentConsumerKernelChecked
    Lean.Elab.Command.liftCoreM <| addDecl <| Declaration.thmDecl {
      name := checked, levelParams := [], type := mkConst expected, value := mkConst root }
    logInfo m!"ROOT_CLOSED_EXACT_PROP_KERNEL_PASS {root}"
    logInfo m!"ROOT_ACTUAL_TYPE {root}: {ci.type}"
    let some proof := ci.value? true | throwError "Missing root proof {root}"
    let direct := proof.getUsedConstants.toList
    let mut pending := direct ++ ci.type.getUsedConstants.toList
    let mut seen : NameSet := {}
    let mut parents : NameSet := {}
    let mut rootOwned : NameSet := {}
    rootOwned := rootOwned.insert root
    while !pending.isEmpty do
      let u := pending.head!
      pending := pending.tail!
      unless seen.contains u do
        seen := seen.insert u
        if u != root && u.toString.startsWith "AutoSamplingTheory." then
          parents := parents.insert u
        else if isOwned u then
          rootOwned := rootOwned.insert u
          let some provider := env.find? u | throwError "Missing owned provider {u}"
          let some body := provider.value? true | throwError "Missing owned body {u}"
          pending := body.getUsedConstants.toList ++ provider.type.getUsedConstants.toList ++ pending
    let required := if root == producer then
      [`AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumGridAlias.actual_midpoint_grid_cosine_alias]
      else [producer]
    unless parents.toList.length == required.length && required.all parents.contains do
      throwError "Wrong first-public ASTIS parents {root}: {parents.toList}"
    allReach := rootOwned.toList.foldl (fun acc n => acc.insert n) allReach
    logInfo m!"ROOT_FIRST_PUBLIC_ASTIS_PARENTS {root}: {parents.toList}"
    logInfo m!"ROOT_REACHABLE_OWNED {root}: {rootOwned.toList}"
    logInfo m!"ROOT_DIRECT_USED_CONSTANTS {root}: {direct}"
  for (n, ci) in owned do
    let some body := ci.value? true | throwError "Owned no body {n}"
    match ci with
    | .thmInfo _ => pure ()
    | .defnInfo v => unless v.safety == .safe do throwError "Unsafe owned definition {n}"
    | _ => throwError "Unreviewed owned constant kind {n}"
    unless !ci.type.hasFVar && !ci.type.hasMVar && !ci.type.hasLooseBVars do
      throwError "Owned nonclosed type {n}"
    let axioms ← Lean.collectAxioms n
    unless axioms.all allowed.contains do throwError "Unexpected recursive axiom {n}: {axioms}"
    unless allReach.contains n do throwError "Unreachable owned constant {n}"
    logInfo m!"OWNED_RECURSIVE_AXIOMS_REACHABLE_CLOSED {n}: {axioms}"
    logInfo m!"OWNED_PROVIDER_CONSTANTS {n}: {body.getUsedConstants.toList}"
  logInfo m!"OWNED_MODULE_PROVENANCE_INVENTORY_COUNT {owned.length}"

#print axioms IndependentProducerKernelChecked
#print axioms IndependentConsumerKernelChecked
'''
source=put('fresh-src/IndependentKernel.lean',header+probe)
cfg=json.loads((D/'native-environment.json').read_text())
env=os.environ.copy(); env.pop('LEAN_SYSROOT',None)
env['LEAN_PATH']=os.pathsep.join([str(D/'fresh-olean')]+[p['library'] for p in cfg['packages']])
r=run('independent_kernel', [cfg['lean_binary'],'--root='+str(D/'fresh-src'),'-o',str(D/'fresh-olean/IndependentKernel.olean'),str(source)],cwd=D/'fresh-src',env=env,timeout=1200,check=False)
js('independent-kernel-receipt.json',{'candidate':C,'source_sha256':sha(source.read_bytes()),'exit_code':r.returncode,
   'stdout_sha256':sha(r.stdout),'stderr_sha256':sha(r.stderr),'project_cache_excluded':True,
   'actual_module_provenance_ownership':True,'scope':'closed exact sealed Props, all owned recursively axioms/reachability, first public ASTIS parents'})
print(r.stdout.decode()); print(r.stderr.decode())
assert r.returncode==0
