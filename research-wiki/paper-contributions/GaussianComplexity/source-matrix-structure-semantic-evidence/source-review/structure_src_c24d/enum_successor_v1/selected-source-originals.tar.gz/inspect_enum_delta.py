from pathlib import Path
import json,hashlib,subprocess,datetime
out=Path(__file__).resolve().parent; parent=out.parent; repo=Path('/Users/zhouhuanjian/ASTIS-GC')
commit='7c364dbeaf44c1f23defe10534e6cd3dffdac172'
W=Path('.astis/huanjian-gc-source-matrix-structure-20261113'); E=Path('research-wiki/paper-contributions/GaussianComplexity/source-matrix-structure-semantic-evidence')
def H(b): return hashlib.sha256(b).hexdigest()
def J(x): return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
def diff(a,b,path='$'):
 if type(a)!=type(b):return [{'path':path,'old':a,'current':b}]
 if isinstance(a,dict):
  result=[]
  for k in sorted(set(a)|set(b)):
   if k not in a or k not in b:result.append({'path':path+'.'+k,'old':a.get(k),'current':b.get(k)})
   else:result+=diff(a[k],b[k],path+'.'+k)
  return result
 if isinstance(a,list):
  if len(a)!=len(b):return [{'path':path,'old':a,'current':b}]
  return sum((diff(x,y,path+f'[{i}]') for i,(x,y) in enumerate(zip(a,b))),[])
 return [] if a==b else [{'path':path,'old':a,'current':b}]
old=parent/'phase3-current-v3-inputs'; current=out/'inputs/current'; manifest=[]; deltas={}
artifact_requests=[(W/'fresh-P-review.v4.json',W/'fresh-P-review.v3.json'),(W/'fresh-T-review.v4.json',W/'fresh-T-review.v3.json'),(W/'candidate-publication-context.v3-enum.json',W/'candidate-publication-context.v2.json')]
for rel,prior in artifact_requests:
 blob=(repo/rel).read_bytes(); dest=current/rel; dest.parent.mkdir(parents=True,exist_ok=True); dest.write_bytes(blob); manifest.append({'input':str(rel),'copy':str(dest.relative_to(out)),'sha256':H(blob),'mode':'current exact packet artifact'})
 deltas[str(rel)]=diff(json.loads((old/prior).read_text()),json.loads(blob))
commit_rels=[Path('AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumSourceMatrixStructure.lean'),Path('Tests/GaussianComplexityFixedSpectrumSourceMatrixStructure.lean'),Path('website/content/declaration_lessons/huanjian-gaussian-source-matrix-structure.json'),Path('website/content/publications/huanjian-gaussian-source-matrix-structure.json'),E/'source-lean-map.authored-v1.json',E/'conceptual-mirror-audit.authored-v1.json',Path('lean-toolchain'),Path('lake-manifest.json')]
for rel in commit_rels:
 p=subprocess.run(['git','show',commit+':'+str(rel)],cwd=repo,capture_output=True)
 dest=current/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(p.stdout)
 manifest.append({'input':str(rel),'copy':str(dest.relative_to(out)),'sha256':H(p.stdout),'mode':'immutable git source','commit':commit,'exit_code':p.returncode,'stderr':p.stderr.decode()})
 if rel.parts[0]=='website' or rel.parts[0]=='research-wiki':deltas[str(rel)]=diff(json.loads((old/rel).read_text()),json.loads(p.stdout))
# Copy only selected original reviewer artifacts; never mutate the prior closed archives.
selected=['SOURCE-EXPECTATIONS-FROZEN.json','SOURCE-EXPECTATIONS-FROZEN.md','WHOLE-CODE-SOURCE-FROZEN.json','WHOLE-CODE-SOURCE-FROZEN.md','P-source-review-run.v3.json','P-source-review-result.v3.json','P-audit-overlay.v3.json','T-source-review-run.v3.json','T-source-review-result.v3.json','T-audit-overlay.v3.json','EXPOSITION-SOURCE-MAP-CONCEPTUAL-REVIEW.v3.json','phase3-v3-independent-byte-span-checks.json','phase1-closed-manifest.json','phase2-closed-manifest.json','phase3-closed-manifest.json','originals/.astis/huanjian-resume-20261103/2610.20492v1.html']
selected += ['phase3-current-v3-inputs/'+str(x) for x in [W/'fresh-P-review.v3.json',W/'fresh-T-review.v3.json',W/'candidate-publication-context.v2.json',Path('website/content/declaration_lessons/huanjian-gaussian-source-matrix-structure.json'),Path('website/content/publications/huanjian-gaussian-source-matrix-structure.json')]]
for rel in selected:
 src=parent/rel;b=src.read_bytes();dest=out/'originals'/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b)
 manifest.append({'input':str(src.relative_to(repo)),'copy':str(dest.relative_to(out)),'sha256':H(b),'mode':'unaltered selected original source/reviewer evidence'})
checks={}
for phase in [1,2,3]:
 m=json.loads((parent/f'phase{phase}-closed-manifest.json').read_text());bad=[f['path'] for f in m['files'] if H((parent/f['path']).read_bytes())!=f['sha256']]
 checks[f'phase{phase}_archive_unchanged']={'checked_files':len(m['files']),'mismatches':bad};assert not bad
p=json.loads((current/W/'fresh-P-review.v4.json').read_text());t=json.loads((current/W/'fresh-T-review.v4.json').read_text());cx=json.loads((current/W/'candidate-publication-context.v3-enum.json').read_text());lesson=json.loads((current/'website/content/declaration_lessons/huanjian-gaussian-source-matrix-structure.json').read_text())['units'][0];pub=json.loads((current/'website/content/publications/huanjian-gaussian-source-matrix-structure.json').read_text())['items'][0]
Pblob=(current/commit_rels[0]).read_bytes();Tblob=(current/commit_rels[1]).read_bytes();binding=pub['bindings'][0]
payload={'file':H(Pblob),'current_lean_module':Pblob.decode(),'toolchain':H((current/'lean-toolchain').read_bytes()),'dependencies':H((current/'lake-manifest.json').read_bytes()),'source':pub['source'],'statement':pub['statement'],'formulae':pub['formulae'],'assumptions':pub['assumptions'],'obligations':pub['obligations'],'lesson':lesson,'binding':{k:v for k,v in binding.items() if k not in {'audit_id','legacy_audit_debt'}}}
checks.update({'P_current_packet_canonical':H(J({k:v for k,v in p.items() if k!='packet_sha256'}))==p['packet_sha256'],'T_current_packet_canonical':H(J({k:v for k,v in t.items() if k!='packet_sha256'}))==t['packet_sha256'],'P_current_actual_binding':H(J(payload))==p['publication_binding_sha256']=='1185046d8ac28b7caff1c3b4a02527e3b56a7fefaafbc59602d04bc62a07c8da','T_current_actual_binding':H(J(t['candidate_publication_context']))==t['publication_binding_sha256']=='ad250e21bf49f797eb59e07e6bc8b900065ecefd9547bc5dced5f1d92c28de30','P_context_current':cx['publication_context']==p['candidate_publication_context'] and cx['publication_binding_sha256']==p['publication_binding_sha256'],'T_context_public_producer_current':t['candidate_publication_context']['canonical_public_producer_context']==p['candidate_publication_context'],'P_sourcebytes_9ed_unchanged':H(Pblob)=='b1d08b92b84b3d1b6d8fc53ebad7b991d9aa99ccfd955d51b96f3e2db52dfff6','T_sourcebytes_9ed_unchanged':H(Tblob)=='3bd0697423c61e4eadc530be53b0d402bf7bafeddb2272ff24c01f7ecfe7a7be','P_packet_fullmodule_matches':p['candidate_publication_context']['current_lean_module'].encode()==Pblob,'T_packet_fullmodule_matches':t['candidate_publication_context']['private_consumer']['whole_module_text'].encode()==Tblob,'lesson_six_steps_fullP_T_exact':len(lesson['steps'])==6 and ''.join(s['lean'] for s in lesson['steps'][:4]).encode()==Pblob and ''.join(s['lean'] for s in lesson['steps'][4:]).encode()==Tblob,'publication_enum_current':pub['source']['wording_status']=='faithful paraphrase','lesson_enum_current':lesson['sources'][0]['wording_status']=='faithful paraphrase'})
allowed_old='faithful paraphrase with explicit analytic prerequisites'
for rel,rows in deltas.items():
 for row in rows:
  if row['path'].endswith('.wording_status'):
   assert row['old']==allowed_old and row['current']=='faithful paraphrase',(rel,row)
  else:assert row['path'] in {'$.packet_sha256','$.publication_binding_sha256'},(rel,row)
checks['only_exact_enum_and_hash_deltas']=True
assert all(v is True for v in checks.values() if isinstance(v,bool))
report={'reviewer':'structure_src_c24d','reviewed_reader_commit':commit,'inspection_scope':'bounded incremental enum-only context/metadata successor; substantive v3 source/whole-code/seven-slot review retained unchanged','deltas':deltas,'independent_checks':checks,'current_packets':{role:{'packet_sha256':v['packet_sha256'],'packet_file_byte_sha256':H((current/W/f'fresh-{role}-review.v4.json').read_bytes()),'binding_sha256':v['publication_binding_sha256']} for role,v in [('P',p),('T',t)]},'input_manifest':manifest,'root_gate_results_not_inspected':True,'normal_verification_not_run':True}
(out/'EXACT-ENUM-DELTA-REVIEW-INPUTS.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps(report,ensure_ascii=False,indent=2))
