from pathlib import Path
sig=Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-query-semantic-evidence/candidate-exact-signature.txt').read_text();s=Path('.astis/huanjian-fixed-spectrum-query-20261107/Proof.lean').read_text().replace('field_simp [hd0] <;> ring','field_simp [hd0]; ring')
header='''/-!
# Actual same-rotation fixed-spectrum precision replies

Zhou--Suzuki arXiv:2610.20492v1, Section4.1 Equation11 and Remark4.2.
The two precision matrices use the literal cosine grid and the SAME hidden
orthogonal rotation. One exact precision-matvec reply reconstructs the other
at the same actual point in either direction. The number2 here is the
reference condition number, not a call count or inverse-covariance oracle.
All scalar/diagonal/orthogonal/conjugation/matvec and nonzero-reciprocal bridges
are proved internally. No supplied affine identity or reply-correctness premise.
Gaussian target/covariance/TV transport, operational adaptive/cost/precision
adapters, spectral/PosDef/normalizer background and both main lower bounds
remain separate.
-/

'''
s=s.replace('namespace AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumAffine',header+'namespace AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumAffine',1)
s=s.replace('  have hdpos :','  -- Align the zero-based indices with the literal one-based source grid.\n  have hdpos :',1).replace('  have hscalar (i','  -- Lift the actual entrywise identity through the diagonal and same O.\n  have hscalar (i',1).replace('  have hO :','  -- Full orthogonal membership supplies the actual right identity.\n  have hO :',1).replace('  have hnz :','  -- Reverse conversion uses a genuinely nonzero known scalar.\n  have hnz :',1)
p=Path('AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumAffine.lean');assert not p.exists();p.write_text(s)
theta=sig[sig.index('    let θ :'):sig.index('    let A :')]
a=sig[sig.index('    let A :'):sig.index('    let query :')]
query=sig[sig.index('    let query :'):sig.index('    ∀ x :')]
lets=theta+a.replace('let A :','let precision1 :').replace('(O :','(O1 :')+a.replace('let A :','let precision2 :').replace('(O :','(O2 :')+query.replace('query','reply1').replace('A η','precision1 η')+query.replace('query','reply2').replace('A η','precision2 η')
prop='''example {d : ℕ} (hd : 2 ≤ d) {κ : ℝ} (hκ : 2 ≤ κ)
    (O1 O2 : Matrix.orthogonalGroup (Fin d) ℝ) :
'''+lets+'''    ∀ x : EuclideanSpace ℝ (Fin d),
      reply1 κ x = reply2 κ x ↔ reply1 2 x = reply2 2 x := by
  classical
  dsimp only
'''
locallets='\n'.join(line[2:] if line.startswith('  ') else line for line in lets.splitlines())+'\n'
body='''  intro x
  have h1 := FixedSpectrumAffine.actual_affine_precision_query hd hκ O1
  have h2 := FixedSpectrumAffine.actual_affine_precision_query hd hκ O2
  dsimp only at h1 h2
  constructor
  · intro h
    calc
      reply1 2 x = (κ - 1)⁻¹ • (reply1 κ x + (κ - 2) • x) := (h1 x).2
      _ = (κ - 1)⁻¹ • (reply2 κ x + (κ - 2) • x) :=
        congrArg (fun y : EuclideanSpace ℝ (Fin d) =>
          (κ - 1)⁻¹ • (y + (κ - 2) • x)) h
      _ = reply2 2 x := (h2 x).2.symm
  · intro h
    calc
      reply1 κ x = (κ - 1) • reply1 2 x - (κ - 2) • x := (h1 x).1
      _ = (κ - 1) • reply2 2 x - (κ - 2) • x :=
        congrArg (fun y : EuclideanSpace ℝ (Fin d) =>
          (κ - 1) • y - (κ - 2) • x) h
      _ = reply2 κ x := (h2 x).1.symm

#print axioms FixedSpectrumAffine.actual_affine_precision_query
open Lean in
run_cmd do
  let env ← getEnv
  let some info := env.find? `AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumAffine.actual_affine_precision_query | throwError "Missing actual fixed-spectrum reply theorem"
  let some proof := info.value? (allowOpaque := true) | throwError "Missing actual fixed-spectrum proof"
  let parents := proof.getUsedConstants.filter fun n => n.toString.startsWith "AutoSamplingTheory"
  logInfo m!"ACTUAL COMPILED ASTIS PARENTS {parents}"
'''
head='''import AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumAffine
import Lean.Util.FoldConsts
open Matrix
open AutoSamplingTheory.ExampleCases.GaussianComplexity
set_option autoImplicit false

-- Actual two-hidden-rotation same-point precision-observation consumer.
-- The input matrices/replies are literal source objects; no assumed affine
-- identity or scalar stand-in. The equivalence is pointwise only, not a
-- Gaussian-target/TV/adaptive/deterministic-cap/expected-cost reduction.
'''
p=Path('Tests/GaussianComplexityFixedSpectrumAffine.lean');assert not p.exists();p.write_text(head+prop+locallets+body)
print('Exactsealedproducer promoted and genuineactualtwo-rotationreplyequivalence consumer authored.')
