# TL phase2b actual reads

Prior continuing-role exposure remains exactly as disclosed in raw phase1; no fresh or zero-exposure claim is made. The raw and type/definition freezes were not edited or reopened as source-specific acceptance authority.

New content reads were confined to the expressly whitelisted `tl_sg_b41a8e` phase1 source_root_map, coverage checkpoint, phase2 selector v2, exact delta, type-semantic-use overlay, coverage alignment, target binding, and the necessary source-only `standard_background_and_gaps.json`. The last filename was located by filename-only filtering of the direct SG directory for background/gap JSON objects; no cognition/verdict/report/manifest was opened.

The canonical old full source graph was byte/hash checked and its applicable mathematical node/edge fields read. The referenced canonical original coverage inventory was byte/hash checked and its original item fields used only to verify inherited dispositions, ranges/hashes and text. No old TC verdict/HOLD/grant was opened. Graph status/proof/independent-review/digest fields and supplied audit claims were visible graph metadata, not this actor's acceptance evidence.

The pinned raw HTML was newly read for a separate complete DOM enumeration of the five coverage scopes, comparing every original element with the checkpoint and alignment. Source mathematical content from the already-frozen raw phase1 was reused candidly, with the complete normalizer elements specifically rechecked against the candidate role labels. This reuses raw-source cognition, not an old law/math ACCEPT.

Performed only local JSON/source data checks: independent recursive seven-operation delta derivation/replay, canonical graph/coverage hash preservation, original DOM span/hash/disposition match, endpoint/backlink checks and selected-root/typed-branch ancestor traces. No Lean, target proof/API theorem search, implementation, normal SAU/intake/control API or second prover was run.

Did not read the new full canonical seal, root planning/reuse/process disclosures, SG cognition/mathematical verdict/report/manifest verdict fields, actual implementation/proof/API material, or other private work. Exact type strings/definition meanings are retained from the authorized frozen phase2a; target-binding signature digest references were matched to that known context without opening SG exact-type files or a full seal.

All writes are inside this actor's new phase2b output directory. No candidate graph, alignment, full source graph/coverage, other actor artifact, previous freeze, ledger/frontier/shared/site/Git state was edited. The narrow TL-COV-1 finding was sent to the parent before freeze for an original-author successor; this actor does not author the repair. Mathematical judgment freezes now; process eligibility remains separately withheld.
