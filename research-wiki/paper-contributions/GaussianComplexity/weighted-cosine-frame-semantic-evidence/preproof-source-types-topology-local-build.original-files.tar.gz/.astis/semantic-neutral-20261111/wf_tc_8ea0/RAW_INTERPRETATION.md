# Independent raw-source freeze — wf_tc_8ea0

This is a raw-source interpretation frozen before any proposed Lean statement, meaning-carrying Lean definition, supplied graph, implementation, prior packet verdict or decoder was read. It is not a type seal, graph acceptance, proof grant, process grant or source-completion claim. Root remains the mathematical prover. The immutable source is On Complexity of Gaussian Sampling, arXiv:2610.20492v1, pinned as 951,991 UTF-8 bytes with SHA-256 `6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915`.

The exact scope is Appendix C.2, HTML paragraph `A3.SS2.p14`, fourth moment Ex113, square formula Ex114 and uncentered comparison EGx11 (Ex115–Ex117), with the source definitions and deterministic frame facts needed to interpret them. “p14” is an HTML paragraph id. No PDF page number is inferred. The claim credited here ends at EGx11 and its explanation using the norm and Gram identities. Centered second moments, variance-operator norms, concentration, Bernstein and the full Lemma 4.4 proof are excluded. An accidental adjacent-source exposure is separately recorded in `read-boundary-and-exposure.json`; it supplies no credited conclusion.

## Exact objects and standing context

The section's ambient source dimensions are integers d >= 2 and q >= 0 with 2q+1 < d; q is explicitly called an integer in Lemma 4.3. Put r=q+1 (hence r>=1) and n=2q+1. Indices are i=1,...,d, Gaussian generator a=1,...,r and feature degree j=0,...,q. The deterministic half-grid is theta_i=(i-1/2) pi/d. Section 4.1 also assumes kappa>=2 and defines lambda_i=(kappa+1)/2+(kappa-1) cos(theta_i)/2 and Lambda=diag(lambda_i). Kappa and Lambda are needed to identify the Krylov range, but the uncentered coefficient comparison does not depend on their numerical values.

The feature t_i in R^r has coordinate 0 equal to 1 and coordinates j=1,...,q equal to sqrt(2) cos(j theta_i). These normalizations matter: neither the unnormalized cosine vector nor a vector including sqrt(2) on the constant coordinate gives the same Gram identity. The source has independent g_1,...,g_r ~ N(0,I_d), defines gamma_i=((g_1)_i,...,(g_r)_i) in R^r and states that the gamma_i are independent N(0,I_r). B is d by r^2 with ith row d^(-1/2) (gamma_i tensor t_i)^T. Tensor coordinate order is Gaussian index first, cosine feature index second. Matrix transpose and matrix square are ordinary real matrix operations; square does not mean entrywise square. The identity on the product coordinate space is I_(r^2)=I_r tensor I_r.

For context the source Krylov space is span{Lambda^j g_a : 1<=a<=r, 0<=j<=q}; range(B) equals this space. The nonconstant affine spectral map and cos(j theta)=T_j(cos theta) give an invertible triangular basis change for each a, while nonzero column normalizations preserve range. The frequency statistic is D_n=diag(cos(n theta_i)); it is the high-frequency signed Gram statistic. It does not appear as a multiplier in EGx11's uncentered second-moment sum.

## Source frame facts and their exact uses

Fact C.5 states ||t_i||^2<=2r, sum_i t_i t_i^T=d I_r and sum_i cos(n theta_i)t_i t_i^T=0. Its norm calculation is the sharper intermediate expression ||t_i||^2=1+2 sum_(j=1)^q cos^2(j theta_i)<=1+2q<=2r. Its Gram proof cancels every nonzero integer cosine frequency with absolute value <2d on the half-grid, using the telescoping sine identity and a nonzero sine divisor. The constant coordinate contributes d on its diagonal; the other coordinates use product-to-sum, with j-k=0 exactly on the diagonal. The high-frequency cancellation uses 1<=n-j-k<=n±j±k<=n+j+k<=4q+1<2d.

These frame equalities/inequalities are source proof results, not new assumptions to place on the final source-facing claim. The norm upper bound and unweighted Gram identity are consumed in p14; the signed high-frequency cancellation, range identity and first-moment B identities are standing context for the larger argument and are not extra premises needed for this particular estimate.

The deterministic coefficient matrix in EGx11 is the positive weighted sum H=sum_i ||t_i||^2 (I_r tensor t_i t_i^T), of size r^2 by r^2. Each I_r tensor t_i t_i^T is PSD. Replacing the scalar coefficient ||t_i||^2 by 2r gives H <= 2r (I_r tensor sum_i t_i t_i^T)=2rd I_(r^2), where <= is real symmetric Loewner order. The residual is a sum of PSD matrices with nonnegative coefficients 2r-||t_i||^2. This explains the deterministic middle comparison in EGx11 without importing a random-row estimate as an assumption. “Weighted” here is the feature squared-norm coefficient; the expression in this display has no signed cos(n theta_i) factor.

## Random matrix definition, Ex113, Ex114 and EGx11

The source fixes L=2r+3 log(1000d), R_i=||gamma_i||^2, and Y_i=d^(-1) (gamma_i gamma_i^T tensor t_i t_i^T) 1_{R_i<=L}. Thus Y_i is a real symmetric r^2 by r^2 PSD matrix and the cutoff uses <=. The exact source L is positive under the standing dimensions. The particular tail probability, truncation bias and lower bounds on L are not inputs to the uncentered PSD-indicator deletion: the deletion itself works for any real cutoff. This observation does not replace the source's definition of L.

Ex113 is E[R_i gamma_i gamma_i^T]=(r+2)I_r. The source's explanation is off-diagonal sign symmetry and diagonal value 3+(r-1)=r+2. Its mathematical content concerns one standard Gaussian row: independent standard normal coordinates give fourth moment 3 and the r-1 mixed products each give 1. Between-row independence is not used for this identity.

Ex114 is the exact pointwise square identity

Y_i^2 = d^(-2) R_i ||t_i||^2 (gamma_i gamma_i^T tensor t_i t_i^T) 1_{R_i<=L}.

It uses (gamma gamma^T)^2=||gamma||^2 gamma gamma^T, (t t^T)^2=||t||^2 t t^T, tensor multiplicativity, and 1_A^2=1_A. In particular, the indicator remains once and the scale is d^(-2).

EGx11 states the full chain

sum_i E[Y_i^2]
  <= (r+2)/d^2 sum_i ||t_i||^2 (I_r tensor t_i t_i^T)
  <= 2r(r+2)/d^2 (I_r tensor sum_i t_i t_i^T)
  = 2r(r+2)/d I_(r^2).

The first inequality drops the cutoff from a PSD integrand, transports Loewner order through expectation and the finite sum, and then uses Ex113. The second and third comparisons are exactly the deterministic frame comparison above and the Gram identity. The conclusion is a matrix Loewner bound for a sum of uncentered second moments. It is neither a centered variance conclusion, nor a bound for E[(sum_i Y_i)^2], nor an operator-norm assertion.

## Source hypotheses versus internal obligations

The source supplies the dimension/range restrictions, exact grid/features and Gaussian experiment; it defines all matrices literally by the displayed formulas. It does not assume Ex113, Ex114, PSDness, feature norm, frame Gram, integrability, the coefficient comparison, or EGx11 as premises of itself. A faithful implementation must discharge those results internally rather than move them to public binders. Real matrix sizes and real Euclidean inner products are typing information. Range(B)=K_q requires the affine spectral map with nonzero slope; the coefficient and uncentered moment comparisons themselves require no query/output representation.

Relevant internal analytic obligations are measurability of polynomial matrix functions and the Borel radial cutoff; integrability of the relevant matrix integrands; order preservation of finite-dimensional Bochner integration for integrable PSD differences; and linearity of integration through deterministic finite sums, scalar factors and fixed tensor factors. These are mathematical obligations implicit in the displayed source expectations, not newly discovered source hypotheses.

In a compatible finite-dimensional operator norm, the untruncated matrix in the Ex114 domination has norm d^(-2)||t_i||^4 R_i^2. A standard r-dimensional Gaussian has finite E[R_i^2]=r(r+2), so Gaussian degree-four integrability supplies the needed domination and integrability. This same integrable upper bound controls the cutoff matrix square. Alternatively, the source's positive finite L gives a bounded cutoff square directly. There are only d rows, so finite-sum transport has no infinite series, limit, uniform-integrability or Fubini obligation. Integrability must be established before using expectation monotonicity; one must not rely on a totalized undefined integral returning zero. PSD/order is applied to real symmetric matrices (equivalently Hermitian real matrices), with the tensor factors and scalar coefficients kept in their stated order and dimensions.

## Marginal sums and the original joint row experiment

The source writes expectations on the original family generated by all g_a. Let mu_r denote the standard Gaussian probability law on R^r, and for deterministic i let M_i(z)=d^(-1)(zz^T tensor t_i t_i^T)1_{||z||^2<=L}. The corresponding canonical row-law expression for this slice is the finite sum sum_i integral M_i(z)^2 dmu_r(z). Each term uses the same law but a different deterministic t_i. The untruncated fourth-moment identity likewise concerns integral ||z||^2 zz^T dmu_r(z).

Equality with the source's sum_i E[Y_i^2] requires the marginal law gamma_i#P=mu_r and an integrable measurable-map expectation transport for each i. No common sampled z is asserted to represent all rows jointly, and summing such integrals does not assert independent copies or equality in law of the entire family. The marginal sums are unchanged by a different coupling with the same marginal laws. Original-family independence, joint law, equality in law of the simultaneous family, and any subsequent concentration argument remain separate obligations and receive no credit from a canonical marginal-sum formula. This distinction is essential even though the source explicitly states its actual rows are independent.

## Endpoint q=0 and scope limits

At q=0, r=1, n=1, and 2q+1<d forces d>=2. The feature vector has just t_i=(1); the degree-1-through-q sum is empty. Its norm square is 1, its Gram sum is d and its signed cosine sum is zero. The Krylov space is span{g_1}; B is its normalized single column, and all product-coordinate matrices are 1 by 1. Ex113 becomes E[gamma_i^4]=3 and Ex114 remains the scalar truncated fourth power divided by d^2. EGx11 gives the valid loose bound sum_i E[Y_i^2]<=6/d; deletion of the cutoff and the exact norm 1 also show the tighter intermediate 3/d. Thus q>0, r>=2, a nonempty positive-frequency feature block or d>=3 must not be introduced as premises. No endpoint repair is needed.

No implication is claimed beyond this bounded uncentered result. No supplied type packet or graph has yet been read. The subsequent type-only freeze and distinct graph challenge remain pending.
