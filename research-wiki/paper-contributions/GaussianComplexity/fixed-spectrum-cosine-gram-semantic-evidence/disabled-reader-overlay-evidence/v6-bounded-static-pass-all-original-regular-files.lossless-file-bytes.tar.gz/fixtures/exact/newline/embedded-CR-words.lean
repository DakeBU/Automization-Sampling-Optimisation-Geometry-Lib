-- prefixinside
αmiddle
βend
