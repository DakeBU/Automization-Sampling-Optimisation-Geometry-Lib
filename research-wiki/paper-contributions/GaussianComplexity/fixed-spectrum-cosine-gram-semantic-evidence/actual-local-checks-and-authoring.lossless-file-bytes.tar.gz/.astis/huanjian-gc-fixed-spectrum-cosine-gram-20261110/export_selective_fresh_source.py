from pathlib import Path
import sys,json,hashlib
sys.dont_write_bytecode=True;sys.path.insert(0,'tools')
import astis_semantic_roundtrip as rt
W=Path(__file__).resolve().parent.relative_to(Path.cwd())
E=Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-cosine-gram-semantic-evidence')
dump=lambda x:(json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode()
sha=lambda b:hashlib.sha256(b).hexdigest()
a=json.loads(Path('research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-cosine-gram.json').read_bytes())
assert a['state']=='blind-reconstructed' and a['source_review']=={'state':'pending'}
packet=rt.semantic_reviewer_packet(a)
p=E/'fresh-source-reviewer-packet.json'
if p.exists():
    assert p.read_bytes()==dump(packet)  # reuse the exact pure export from attempt1
else:
    p.write_bytes(dump(packet))
s=json.loads((W/'statement-seal-v1.json').read_bytes())
defs=[{'name':'multivariateGaussian','literal_definition':(W/'multivariateGaussian-literal-definition.txt').read_text()}]
for n in ['additional-canonical-Gaussian-definitions.json','additional-canonical-Gaussian-density-definitions.json']:
    defs+=json.loads((W/n).read_bytes())['definitions']
minimal={'source':packet['source'],'lean':packet['lean'],'blind_reconstruction':packet['blind_reconstruction'],'publication_binding_sha256':packet['publication_binding_sha256'],'canonical_full_reviewer_packet_sha256':packet['packet_sha256'],'minimal_meaning_carrying_definitions':defs,'additional_definition_context':a['lean']['decoder_context'],'actual_private_consumer_literal_signature':s['actual_private_consumer']['signature'],'scope':'Selective statement/definition/reconstruction comparison only. Full current code and lesson are deliberately withheld until this independent phase freezes. No root/native/other-role verdict, source graph, actual compiler inventory, process history or original sourceV evidence supplied.'}
assert set(minimal['lean'])=={'declaration','file','statement','statement_sha256','compiled'}
q=E/'selective-fresh-source-phase2-input.json';assert not q.exists();q.write_bytes(dump(minimal))
x=json.loads((E/'source-to-lean-map-v1.json').read_bytes())
for row in x['locator_slices']:
    b=row['literalLF'].encode()
    assert sha(b)==row['exact_block_sha256'] and len(row['literalLF'])==row['character_length']
record={'canonical_full_reviewer_packet_sha256':packet['packet_sha256'],'canonical_full_packet_raw_sha256':sha(p.read_bytes()),'selective_packet':str(q),'selective_packet_raw_sha256':sha(q.read_bytes()),'selective_packet_bytes':q.stat().st_size,'five_literal_lean_fields_only':True,'full_code_lesson_other_verdicts_withheld':True,'all57_optional_stored_block_hashes_and_character_lengths_now_independently_checked':True,'no_source_verdict_or_sourceV':True}
r=E/'selective-fresh-source-phase2-export-record.json';assert not r.exists();r.write_bytes(dump(record))
print(json.dumps(record))
