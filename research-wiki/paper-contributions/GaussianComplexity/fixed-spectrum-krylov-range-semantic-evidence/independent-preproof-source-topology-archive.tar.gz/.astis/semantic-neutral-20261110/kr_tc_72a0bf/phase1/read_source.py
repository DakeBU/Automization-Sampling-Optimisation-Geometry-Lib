from pathlib import Path
from html.parser import HTMLParser
import hashlib, json, re, sys

OUT = Path(__file__).parent
SOURCE = Path('.astis/huanjian-resume-20261103/2610.20492v1.html')
RAW = SOURCE.read_bytes()
S = RAW.decode('utf8')
LINE = [0] + [m.end() for m in re.finditer('\n', S)]
VOID = {'area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr','mprescripts','none'}

class Index(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=False)
        self.stack=[]; self.items=[]
    def off(self):
        l,c=self.getpos(); return LINE[l-1]+c
    def handle_starttag(self, tag, attrs):
        a=dict(attrs); item={'tag':tag,'id':a.get('id'),'attrs':a,'char_start':self.off()}
        if tag in VOID:
            item['char_end']=self.off()+len(self.get_starttag_text()); self.items.append(item)
        else: self.stack.append(item)
    def handle_startendtag(self, tag, attrs):
        a=dict(attrs); self.items.append({'tag':tag,'id':a.get('id'),'attrs':a,'char_start':self.off(),'char_end':self.off()+len(self.get_starttag_text())})
    def handle_endtag(self, tag):
        for j in range(len(self.stack)-1,-1,-1):
            if self.stack[j]['tag']==tag:
                if j != len(self.stack)-1:
                    raise RuntimeError(('unclosed',tag,[q['tag'] for q in self.stack[j+1:]],self.getpos()))
                x=self.stack.pop(); x['char_end']=S.index('>',self.off())+1; self.items.append(x); return
        raise RuntimeError(('unmatched',tag,self.getpos()))

class Reading(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True); self.math=0; self.parts=[]
    def handle_starttag(self,tag,attrs):
        a=dict(attrs)
        if self.math:
            if tag=='math': self.math+=1
            return
        if tag=='math':
            self.math=1;self.parts.append('[MATH '+a.get('id','NO_ID')+' | '+a.get('alttext','NO_ALTTEXT')+']');return
        if tag in {'div','section','table','tr','p','li','h1','h2','h3','h4','h5','h6'}:
            self.parts.append('\n')
        if a.get('id'):self.parts.append('{ID '+a['id']+'} ')
    def handle_endtag(self,tag):
        if self.math:
            if tag=='math':self.math-=1
            return
        if tag in {'div','section','table','tr','p','li','h1','h2','h3','h4','h5','h6'}:self.parts.append('\n')
    def handle_data(self,data):
        if not self.math:self.parts.append(data)
    def result(self):
        return '\n'.join(re.sub('[ \\t\\r]+',' ',l).strip() for l in ''.join(self.parts).split('\n') if l.strip())+'\n'

idx=Index();idx.feed(S);idx.close()
if idx.stack:raise RuntimeError(('unclosed_at_eof',idx.stack))
byid={i['id']:i for i in idx.items if i['id']}
scope_ids=['S4.SS1','S4.SS2','A3.SS2']

def pin(x):
    a,b=x['char_start'],x['char_end'];b0=len(S[:a].encode('utf8'));b1=len(S[:b].encode('utf8'))
    # End LF belongs to previous line: the last included character determines end line.
    return {'id':x['id'],'tag':x['tag'],'char_start':a,'char_end_exclusive':b,
            'utf8_byte_start':b0,'utf8_byte_end_exclusive':b1,
            'line_start_1based':S.count('\n',0,a)+1,
            'line_end_inclusive_1based':S.count('\n',0,max(a,b-1))+1,
            'raw_utf8_sha256':hashlib.sha256(RAW[b0:b1]).hexdigest(),
            **({'alttext':x['attrs'].get('alttext'),'display':x['attrs'].get('display')} if x['tag']=='math' else {})}

selected=[]
for scope in scope_ids:
    z=byid[scope];a,b=z['char_start'],z['char_end']
    (OUT/(scope+'.raw.html')).write_bytes(S[a:b].encode('utf8'))
    rd=Reading();rd.feed(S[a:b]);rd.close();(OUT/(scope+'.reading.txt')).write_text(rd.result())
    selected.extend([x for x in idx.items if x['id'] and a<=x['char_start'] and x['char_end']<=b])
selected.sort(key=lambda x:(x['char_start'],-x['char_end']))
pins=[pin(x) for x in selected]
(OUT/'source_pins.json').write_text(json.dumps({'source':str(SOURCE),'source_bytes':len(RAW),'source_sha256':hashlib.sha256(RAW).hexdigest(),'coordinate_convention':'0-based half-open raw decoded Unicode character and UTF8 byte offsets; LF line numbers 1-based, terminal LF belongs to previous line; no DOM normalization used for pins','pins':pins},ensure_ascii=False,indent=2)+'\n')
(OUT/'source_id_inventory.txt').write_text('\n'.join(f"{p['id']} {p['tag']} L{p['line_start_1based']}-{p['line_end_inclusive_1based']} C[{p['char_start']},{p['char_end_exclusive']}) B[{p['utf8_byte_start']},{p['utf8_byte_end_exclusive']}) sha256={p['raw_utf8_sha256']}" for p in pins)+'\n')
print('source_bytes',len(RAW),'source_sha256',hashlib.sha256(RAW).hexdigest())
for scope in scope_ids:
    q=[x for x in selected if byid[scope]['char_start']<=x['char_start'] and x['char_end']<=byid[scope]['char_end']]
    print(scope,'id_elements',len(q),'math_elements',sum(x['tag']=='math' for x in q),'raw_pin',json.dumps(pin(byid[scope])))

if len(sys.argv)>1:
    for scope in sys.argv[1:]: print((OUT/(scope+'.reading.txt')).read_text(),end='')
