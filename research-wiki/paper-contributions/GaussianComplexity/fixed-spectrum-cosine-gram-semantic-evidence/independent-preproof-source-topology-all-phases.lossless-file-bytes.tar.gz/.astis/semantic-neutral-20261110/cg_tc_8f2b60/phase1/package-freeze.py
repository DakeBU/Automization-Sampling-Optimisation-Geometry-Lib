from pathlib import Path
import hashlib
import json
import os
import stat
from datetime import datetime, timezone

base = Path(__file__).resolve().parent
owner = base.parent
cwd = '/Users/zhouhuanjian/ASTIS-GC'
rel = '.astis/semantic-neutral-20261110/cg_tc_8f2b60/phase1/'
source = Path(cwd) / '.astis/huanjian-resume-20261103/2610.20492v1.html'
raw = source.read_bytes()
assert len(raw) == 951991
assert hashlib.sha256(raw).hexdigest() == '6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
(base / 'pinned-raw.html').write_bytes(raw)

assignment = '''独立 raw-source-first/different-role topology challenger，ASTIS AGENTS明确要求。Repo /Users/zhouhuanjian/ASTIS-GC，仅写 .astis/semantic-neutral-20261110/cg_tc_8f2b60/。下一boundedpacket涉及 arXiv2610.20492v1 Appendix C.2 FactC.5 cosine-frame deterministic Gram orthogonality / D_n-weighted cancellation / row norm界，真实 Gaussian Gram means将是privateconsumer；Range(B)=Krylov和C6 concentration/fullLemma4.4非本packet闭合。本阶段先独立raw-only cognition，暂不读draft/seal/type/SG/root规划/实现Lean/旧semantic/currentverdict/native/controlledgraph/index/ledger/ATLAS。Pinned raw .astis/huanjian-resume-20261103/2610.20492v1.html SHA6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915 951991B，/opt/anaconda3/bin/python有bs4；系统python3无bs4。允许fixedprocedural AGENTS.md、docs/proof-digestion-protocol.md、docs/theorem-publication-protocol.md、docs/evidence-routed-memory-protocol.md、.agents/skills/astis-source-dependency-audit/SKILL.md（若缺只report，不全库搜旧evidence路径）。从raw S4.Thmtheorem4、A3.SS2/C.2及A3.Thmtheorem5与其proof/defs independently读出精确d,q,n,r/角度/归一化/端点/依赖/consumer意义；以不同于author的角色挑战潜在aliasing、cross-term、q0、边界n<d、Gaussian law vs assumedmoments、tensorindex/expectation/integrability、proofingredient-smuggling、漏proofspan和unsupportedinference，不凭root预期判定。必须真实source-only freeze后再接精确sealedtypes/minimaldefs，先type/definition审计冻结，再看authorSGgraph作结构挑战；不要在rawphase先见authorgraph。完整真实输入/命令/输出/失败/截断/exposure、source anchors/spans与每in-scope substantive项NODE/EXCLUDED覆盖要求保留，原始artifacts0444、phase1dir0555，manifest+receipt不hashcycle。现在只freeze rawcognition并回报hash暂停，不运行proof/API/native/sourceV或shared修改；root sole数学prover。
'''
(base / 'assignment.txt').write_text(assignment)

old = """ ('S4.SS1', 'NODE', 'raw.cg.context.midpoint-grid', 'd>=2, kappa>=2 and Eq11 midpoint theta grid; lambda/Lambda retained as separate excluded-range context', 'source-standing-definitions'),
 ('S4.SS1.p2', 'EXCLUDED', 'raw.cg.context.random-rotation-target', 'Random O, precision A, potential and target law are outside deterministic frame packet', 'excluded-source-context'),
"""
new = """ ('S4.SS1', 'NODE', 'raw.cg.context.midpoint-grid', 'd>=2, kappa>=2 and Eq11 midpoint theta grid; lambda/Lambda retained as separate excluded-range context', 'source-standing-definitions'),
 ('S4.SS1.p1', 'NODE', 'raw.cg.context.grid-standing-paragraph', 'Standing d,kappa and midpoint grid component; other mathematical components of this paragraph explicitly split below', 'source-standing-definitions'),
 ('S4.E11', 'NODE', 'raw.cg.context.grid-display', 'theta component of Eq11; lambda/Lambda components separately excluded as range background', 'source-standing-definitions'),
 ('S4.SS1.p1', 'EXCLUDED', 'raw.cg.context.affine-eigenvalues', 'lambda_i and Lambda definitions are retained as background for the excluded range/Krylov proof', 'excluded-open-range'),
 ('S4.SS1.p1', 'EXCLUDED', 'raw.cg.context.construction-citation', '[22, Section9.2] construction attribution; no citation is invoked in the current cosine-identity proof', 'excluded-external-citation-context'),
 ('S4.SS1.p1', 'EXCLUDED', 'raw.cg.context.random-rotation-target', 'Random O, precision A, potential and target law are outside deterministic frame packet', 'excluded-source-context'),
 ('S4.SS1.p2', 'EXCLUDED', 'raw.cg.context.algorithm-information', 'Deterministic spectrum supplied to algorithm, known normalizing constant, and hidden eigenbasis', 'excluded-source-context'),
"""
body = (base / 'build-coverage.py').read_text()
assert body.count(new) == 1
(base / 'build-coverage-v1.py').write_text(body.replace(new, old))
repair_patch = ('*** Begin Patch\n*** Update File: ' + str(base / 'build-coverage.py') + '\n@@\n' +
                ''.join('-' + line + '\n' for line in old.splitlines()) +
                ''.join('+' + line + '\n' for line in new.splitlines()) + '*** End Patch')
(base / 'build-coverage-context-repair-actual.patch').write_text(repair_patch)
for target, snapshot in [('audit_reader.py', 'audit_reader.py'), ('raw-cognition.md', 'raw-cognition.md'),
                         ('build-coverage.py', 'build-coverage-v1.py'), ('capture-inputs.py', 'capture-inputs.py'),
                         ('package-freeze.py', 'package-freeze.py')]:
    patch = ('*** Begin Patch\n*** Add File: ' + str(base / target) + '\n' +
             ''.join('+' + line + '\n' for line in (base / snapshot).read_text().splitlines()) + '*** End Patch')
    (base / (target + '-actual-addfile.patch')).write_text(patch)

nodes = {
 'grid': 'Midpoint theta_i and source carriers',
 'frame': 'Literal t_i including special constant mode',
 'frequency': 'n=2q+1<d; r=q+1; signed-frequency bounds',
 'cosine_sum': 'C2p4 integer cosine sum on 0<|k|<2d',
 'unweighted': 'C2p5 sum t_i t_i^T=d I_r',
 'weighted': 'C2p7 sum cos(n theta_i)t_i t_i^T=0',
 'row_norm': 'C2p8 ||t_i||^2<=2r',
 'gaussian_law': 'C2p1 source independent g_a and transposed gamma_i law',
 'second_moments': 'Actual-law second moments and integrability, source p6/p7 ingredient',
 'B_row': 'Literal d^(-1/2)(gamma_i tensor t_i) row and tensor index order',
 'mean_unweighted': 'Open private Gaussian expectation consumer p6',
 'mean_weighted': 'Open private Gaussian expectation consumer p7',
 'truncated_means': 'Excluded C6 p12 radial-scalar consumer',
 'summand_norm': 'Excluded C6 p13 consumer',
 'variance': 'Excluded C6 p14 consumer',
 'range': 'Excluded C5p3 range/Krylov identity',
 'concentration': 'Excluded C6 independent full route',
 'uniform_lemma': 'Excluded p19 full Lemma4.4 route'
}
edges = [
 ('grid','cosine_sum','A3.SS2.p4'), ('frame','unweighted','A3.SS2.p5'),
 ('frequency','unweighted','A3.SS2.p5'), ('cosine_sum','unweighted','A3.SS2.p5'),
 ('frame','weighted','A3.SS2.p7'), ('frequency','weighted','A3.Ex96'),
 ('cosine_sum','weighted','A3.Ex97-A3.Ex99'), ('frame','row_norm','A3.Ex102'),
 ('gaussian_law','second_moments','A3.SS2.p6; actual-law bridge required'),
 ('B_row','mean_unweighted','A3.Ex94'), ('second_moments','mean_unweighted','A3.Ex94'),
 ('unweighted','mean_unweighted','A3.Ex95'), ('B_row','mean_weighted','A3.Ex100'),
 ('second_moments','mean_weighted','A3.Ex100'), ('weighted','mean_weighted','A3.Ex101'),
 ('unweighted','truncated_means','A3.Ex110 plus radial isotropy'),
 ('weighted','truncated_means','A3.Ex110 plus common scalar a'),
 ('row_norm','summand_norm','A3.Ex111 plus truncation'),
 ('row_norm','variance','A3.Ex115-A3.Ex117 plus fourth moments/PSD bounds'),
 ('unweighted','variance','A3.Ex116-A3.Ex117 plus fourth moments/PSD bounds'),
 ('range','uniform_lemma','A3.SS2.p19 u=Bc'),
 ('concentration','uniform_lemma','A3.Ex129-A3.Ex132 plus tau<=1/2')
]
(base / 'source-only-topology.json').write_text(json.dumps({
 'stage': 'raw cognition before exact types and author SG',
 'nodes': nodes, 'source_use_edges': [{'provider':a,'consumer':b,'source_use_site':c} for a,b,c in edges],
 'edge_semantics': 'Source-derived use/dependency expectation, not checked Lean implication; excluded consumers retain additional unsupplied ingredients.',
 'route_semantics': 'Single source route for each deterministic part; common cosine-sum leaf; no claimed OR-alternative or dependency cycle.'
}, ensure_ascii=False, indent=2) + '\n')

coverage = json.loads((base / 'source-only-coverage.json').read_text())
assert coverage['mechanical_completeness'] == {'C2_para_count':21,'C2_display_anchor_count':48,'missing':[]}
assert len(coverage['rows']) == 103
exposure = {
 'phase': 'source-only-pre-type-pre-author-SG',
 'author_packet_exposure': False, 'exact_sealed_types_exposure': False,
 'implementation_or_Lean_exposure': False, 'API_search_or_native_run': False,
 'current_or_prior_verdict_exposure': False, 'ATLAS_or_repository_index_ledger_exposure': False,
 'raw_inputs': [str(source)],
 'procedural_inputs': json.loads((base / 'procedural-inputs.json').read_text()),
 'context_exposure': ['parent assignment', 'environment/developer instructions',
                      'S4 direct-child preamble including Theorem4.1',
                      'S4.SS1 full hard-family/Remark4.2 text',
                      'S4.SS2 direct-child inventory including Lemma4.5/4.6 snippets',
                      'S4.SS2.SSS0.Px1 and Px2 including Lemma4.3/4.4', 'A3.SS2 all C2 paragraphs'],
 'scope_control': 'All incidental source context is explicitly excluded from deterministic closure. Processing a fixed raw file with BeautifulSoup is distinguished from displaying its whole text.',
 'transport_issue': 'Initial combined outer output was truncated; bounded full procedure rereads completed before raw cognition. No later output truncation.',
 'logging_caveat': 'raw-00-dom-inventory-input.py is the initial placeholder emitted by the first extraction script, not an actual command input. The exact actual heredoc is raw-00-dom-inventory-actual-input.py. The original initial combined procedure envelope is unknown after truncation; no status is invented.',
 'source_only_stage_result': 'Frozen independent cognition and exhaustive C2 source coverage; no verdict on unseen exact types or author graph.',
 'failure_class': 'NONE', 'mathematical_proof_executed': False,
 'next_exposure_order': ['exact sealed types plus minimal definitions', 'freeze independent type/definition audit', 'author Source Proof Graph for structural challenge']
}
(base / 'exposure-and-stage-receipt-input.json').write_text(json.dumps(exposure, ensure_ascii=False, indent=2) + '\n')

ledger = json.loads((base / 'command-transcript.json').read_text())
ledger['post_capture_events'] = [
 {'tool':'apply_patch','input_artifact':'capture-inputs.py-actual-addfile.patch','output':{},'scope':'own directory only'},
 {'tool':'exec_command','cwd':cwd,'command':'/opt/anaconda3/bin/python '+rel+'capture-inputs.py','output':'Retained exact Python heredoc inputs: 8\nObserved shell-command ledger entries: 20\n','exit_code':0,'tool_chunk_id':'3719d0'},
 {'tool':'apply_patch','input_artifact':'package-freeze.py-actual-addfile.patch','output':{},'scope':'own directory only'},
 {'tool':'exec_command','cwd':cwd,'command':'/opt/anaconda3/bin/python '+rel+'package-freeze.py','output_locator':'../phase1-freeze-receipt.json plus tool stdout manifest/receipt hashes','exit_code_policy':'Failure aborts before producing a receipt; successful output is the freeze receipt','operation':'package source-only records, hash, chmod0444 files, chmod0555 phase1, verify hashes and permissions'}
]
ledger['prior_patch_inputs'] = [
 {'input_artifact':'audit_reader.py-actual-addfile.patch','output':{}},
 {'input_artifact':'raw-cognition.md-actual-addfile.patch','output':{}},
 {'input_artifact':'build-coverage.py-actual-addfile.patch','output':{}},
 {'input_artifact':'build-coverage-context-repair-actual.patch','output':{},'reason':'Independent source context reread corrected p1/p2 source-anchor classification before freeze; no author input involved.'}
]
ledger['patch_reconstruction_note'] = 'Literal patch inputs are retained from unchanged file bodies and the exact context correction block. They are command input retention, not claimed independent tool-generated attestations.'
(base / 'command-transcript.json').write_text(json.dumps(ledger, ensure_ascii=False, indent=2) + '\n')

artifacts = []
for f in sorted(base.iterdir(), key=lambda p:p.name):
    if f.name == 'manifest.json':
        continue
    assert f.is_file(), str(f)
    content = f.read_bytes()
    artifacts.append({'path':f.name,'bytes':len(content),'sha256':hashlib.sha256(content).hexdigest(),'frozen_mode':'0444'})
manifest = {
 'kind':'independent-source-only-cognition-freeze',
 'stage':'phase1-raw-only', 'source_sha256':hashlib.sha256(raw).hexdigest(),
 'ownership':str(owner), 'artifacts':artifacts,
 'no_hash_cycle':'manifest.json excludes itself and the external phase1-freeze-receipt.json; the receipt hashes manifest.json; receipt SHA is printed only.',
 'requested_permissions':{'artifact_files':'0444','phase1_directory':'0555'},
 'unseen_until_after_this_freeze':['exact sealed types/minimaldefs','author SG','implementation Lean','current/prior semantic verdicts'],
 'coverage':coverage['mechanical_completeness'], 'coverage_rows':len(coverage['rows'])
}
(base / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
for f in base.iterdir():
    os.chmod(f, 0o444)
os.chmod(base, 0o555)
for item in artifacts:
    f = base / item['path']
    assert hashlib.sha256(f.read_bytes()).hexdigest() == item['sha256']
    assert stat.S_IMODE(f.stat().st_mode) == 0o444
assert stat.S_IMODE(base.stat().st_mode) == 0o555
assert stat.S_IMODE((base/'manifest.json').stat().st_mode) == 0o444
manifest_sha = hashlib.sha256((base/'manifest.json').read_bytes()).hexdigest()
receipt = {
 'kind':'phase1-source-only-freeze-receipt', 'utc':datetime.now(timezone.utc).isoformat(),
 'phase1_directory':str(base), 'manifest':str(base/'manifest.json'),'manifest_sha256':manifest_sha,
 'raw_cognition_sha256':hashlib.sha256((base/'raw-cognition.md').read_bytes()).hexdigest(),
 'coverage_sha256':hashlib.sha256((base/'source-only-coverage.json').read_bytes()).hexdigest(),
 'topology_sha256':hashlib.sha256((base/'source-only-topology.json').read_bytes()).hexdigest(),
 'artifact_count_excluding_manifest':len(artifacts), 'verified_files_0444':len(artifacts)+1,
 'verified_phase1_mode':'0555', 'all_manifest_hashes_match':True,
 'source_only_exposure_confirmed':True,'type_or_definition_audit_done':False,'author_SG_review_done':False,
 'source_sha256':hashlib.sha256(raw).hexdigest(),'source_bytes':len(raw),
 'coverage':manifest['coverage'],'coverage_rows':manifest['coverage_rows'],
 'commands':{'freeze_command':'/opt/anaconda3/bin/python '+rel+'package-freeze.py','cwd':cwd},
 'no_hash_cycle':'Receipt is outside phase1 and not an input to the manifest. Receipt hash is returned to coordinator without being embedded in itself.',
 'next_action':'Pause; only after this receipt may receive exact sealed types/minimaldefs. Author SG remains forbidden until a separate type/definition-audit freeze.'
}
receipt_path = owner / 'phase1-freeze-receipt.json'
receipt_path.write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
os.chmod(receipt_path, 0o444)
receipt_sha = hashlib.sha256(receipt_path.read_bytes()).hexdigest()
print(json.dumps({'receipt':str(receipt_path),'receipt_sha256':receipt_sha,**receipt},ensure_ascii=False,indent=2))
