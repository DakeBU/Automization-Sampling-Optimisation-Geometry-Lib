"""One normal discovery/proposal/claim/exploring intake after real preproof review."""
from pathlib import Path
import sys
import json
import hashlib
import datetime
sys.path.insert(0, str(Path.cwd()))
from tools import astis_advance as api

R = Path.cwd()
W = R / '.astis/huanjian-gc-matrix-laplace-20261114'
E = R / 'research-wiki/technical-lemmas/matrix-laplace-tail-semantic-evidence'
C = R / 'research-wiki/frontier-cells/ASTIS-SHARED-REAL-MATRIX-LAPLACE-TAIL.json'
A = 'ASTIS-SA-20261114-MatrixLaplaceTail'
O = 'huanjian_20261114_matrix_laplace_tail'
D = 'ASTIS-DISC-20261114-ScalarSelfadjointLaplaceTailMechanism'
SG = R / '.astis/semantic-neutral-20261114/matrix_laplace_source_graph_b37c'
TC = R / '.astis/semantic-neutral-20261114/matrix_laplace_topology_4c9e/final-admission.v1.json'
sha = lambda b: hashlib.sha256(b).hexdigest()
def read(p): return json.loads(p.read_text())
def identity(p): return {'file': str(p.relative_to(R)), 'sha256': sha(p.read_bytes())}
def digest_state(x): return sha(json.dumps(x, sort_keys=True, ensure_ascii=False, separators=(',', ':')).encode())
assert not (W / 'intake-attempted.once.json').exists(), 'Inspect actual ledgers before any retry.'
assert sha(TC.read_bytes()) == '90656020bee479f5e015a153ae5022fd012b96c06f5a2689fe6b14a41fd65f9f'
assert read(TC)['status'] == 'ADMITTED'
assert sha((SG / 'source-graph.repaired.v2.1.json').read_bytes()) == '71f8e77ffc3ef686997e42b96f268ab191591f53dd161f5507dc6024cb308ab9'
assert sha((SG / 'coverage.exact.v2.1.json').read_bytes()) == '16db57708e925faa818d02bd267dbee67a826ddfa9744fd578c4ff5b336afa57'
assert sha((W / 'statement-seal.sealed.v1.json').read_bytes()) == '747e5ddef4f51857c1d240add0313b1bfe498538f8d251d9bd126f3027a0db77'
assert sha((W / 'binder-inventory-singleton.supplement.v1.json').read_bytes()) == '174a4297cc2e600a5bcca92586f38759f8b24c9dbfd4533fb4cfb35761b23af8'
seal = read(W / 'statement-seal.sealed.v1.json')
for key in ['P', 'T']:
    assert sha((W / seal[key]['proposition_file']).read_bytes()) == seal[key]['sha256']
    assert not (R / seal[key]['proposed_file']).exists()
assert not C.exists() and not E.exists()
g = read(W / 'preservation-baseline.private.json')
for p, h in g['all_existing_frontier_sha256'].items(): assert sha((R / p).read_bytes()) == h
before_a = (R / 'runs/substantive_advances.jsonl').read_bytes()
before_d = (R / 'runs/substantive_discoveries.jsonl').read_bytes()
for raw, k in [(before_a, 'advance_prefix'), (before_d, 'discovery_prefix')]:
    assert len(raw) == g[k]['bytes'] and sha(raw) == g[k]['sha256'] and raw.endswith(b'\n')
states_a, states_d = api.current_advances(), api.current_discoveries()
assert A not in states_a and D not in states_d
assert {k: digest_state(v) for k, v in states_a.items()} == g['all_existing_advance_state_digests']
assert {k: digest_state(v) for k, v in states_d.items()} == g['all_existing_discovery_state_digests']
proposal = read(W / 'metadata-drafts/proposal-kwargs.candidate.v1.json')
public_floor = ['MeasureTheory.meas_ge_le_lintegral_div', 'Matrix.IsHermitian.cfc_eq',
    'Matrix.IsHermitian.spectrum_real_eq_range_eigenvalues', 'Matrix.trace_mul_cycle', 'Matrix.trace_diagonal']
private_floor = ['AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumSourceMatrixRadius.actual_source_truncated_matrix_norm_bounds',
    'AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumSourceMatrixStructure.actual_source_centered_matrix_structure']
# A produced P is the private consumer's parent, not an input of its own SAU.
proposal['dag_inputs'] = public_floor + private_floor
proposal['modes'] = ['source-review', 'library-retrieval', 'proof-design', 'compiler-diagnosis']
api.AdvanceProposal(**proposal).validate()
mirror = read(W / 'conceptual-mirror-proposal.authored-v1.json')
assert mirror['advance_id'] == A and mirror['discovery_id'] == D and mirror['created_by'] == O
api.Discovery(**mirror).validate()
admission = {'kind': 'Independent source-interface/topology/coverage admission only; no new mathematical proof',
    'seal': identity(W / 'statement-seal.sealed.v1.json'),
    'original_binder_audit': identity(W / 'binder-definition-audit.sealed.v1.json'),
    'singleton_binder_supplement': identity(W / 'binder-inventory-singleton.supplement.v1.json'),
    'source_graph': identity(SG / 'source-graph.repaired.v2.1.json'),
    'coverage': identity(SG / 'coverage.exact.v2.1.json'),
    'source_vs_seal': identity(SG / 'source-vs-seal.repaired.v2.1.json'),
    'distinct_TC': identity(TC), 'formation': seal['actual_type_formation'],
    'target_proof_calls_before_admission': 0}
E.mkdir(parents=True)
(E / 'preproof-source-admission.json').write_text(json.dumps(admission, ensure_ascii=False, indent=2) + '\n')
for source, dest in [(W / 'statement-seal.sealed.v1.json', R / 'research-wiki/technical-lemmas/matrix-laplace-tail-statement-seal.json'),
    (W / 'binder-definition-audit.sealed.v1.json', E / 'binder-definition-audit.original.v1.json'),
    (W / 'binder-inventory-singleton.supplement.v1.json', E / 'binder-inventory-singleton.supplement.v1.json'),
    (W / 'conceptual-mirror-proposal.authored-v1.json', E / 'conceptual-mirror-proposal.authored-v1.json'),
    (W / 'conceptual-mirror-and-process-audit.authored-v1.json', E / 'conceptual-mirror-and-process-audit.authored-v1.json')]:
    assert not dest.exists()
    dest.write_bytes(source.read_bytes())
cell = read(W / 'metadata-drafts/frontier-cell.candidate.v1.json')
for key in ['draft_only', 'registration_pending', 'draft_status_qualification']:
    cell.pop(key, None)
cell['conceptual_mirror_audit'] = {'status': 'candidates-published', 'discovery_ids': [D],
    'evidence': str((E / 'conceptual-mirror-and-process-audit.authored-v1.json').relative_to(R)),
    'scope': 'Raw source-backed mechanism only; not independently validated, not mathematical V or a certified formal transport. Actual compiler dependencies remain pending.'}
cell['graph_contribution']['functor_view'] = 'candidate-published'
cell['graph_contribution']['classification_qualification'] = 'Normal raw typed Discovery accompanies intake. No global graph file change, formal transport or new compilation is claimed.'
cell['learning_contract']['process_memory_ids'] = read(W / 'conceptual-mirror-and-process-audit.authored-v1.json')['process_memory_ids_consulted']
cell['evidence']['preproof_admission'] = admission
cell['evidence']['independent_verification'] = ''
cell['owned_files'] = proposal['proposed_files']
cell['forbidden_shared_files'] = ['AutoSamplingTheory.lean', 'AutoSamplingTheory/TechnicalLemmas/Probability.lean',
    'AutoSamplingTheory/TechnicalLemmas/Registry.lean', 'Tests.lean', 'research-wiki/source-index/',
    'research-wiki/semantic-roundtrip/registry.json', 'website/content/source_correspondence.json',
    'website/content/graph_memory_index.json', 'website/content/functor_hypergraph.json',
    'website/static/', 'website/scripts/build_site.py',
    'AutoSamplingTheory/TechnicalLemmas/Probability/MatrixBernsteinMgf.lean',
    'Tests/GaussianComplexityBernsteinWeightedMgf.lean',
    'research-wiki/frontier-cells/ASTIS-SHARED-MATRIX-BERNSTEIN-MGF.json',
    'research-wiki/technical-lemmas/matrix-bernstein-mgf-semantic-evidence/']
cell['phase_snapshot'] = 'Preproof source-interface/topology admitted; normal proposal/claim/exploring intake only. New public P and four-case private T proof not yet written. All postproof semantic/native/reader verification remains pending.'
C.write_text(json.dumps(cell, ensure_ascii=False, indent=2) + '\n')
(W / 'intake-attempted.once.json').write_text(json.dumps({'at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'planned_normal_calls': ['raw conceptual Discovery', 'advance proposal', 'CLAIMED', 'EXPLORING']}, indent=2) + '\n')
api.publish_discovery(api.Discovery(**mirror))
api.propose_advance(api.AdvanceProposal(**proposal))
api.transition_advance(A, 'CLAIMED', worker_id=O, evidence={'preproof_admission': admission})
api.transition_advance(A, 'EXPLORING', worker_id=O, modes=['proof-design', 'library-retrieval', 'compiler-diagnosis'],
    evidence={'preproof_admission': admission, 'proof_implementation_not_started': True})
after_a, after_d = (R / 'runs/substantive_advances.jsonl').read_bytes(), (R / 'runs/substantive_discoveries.jsonl').read_bytes()
assert after_a.startswith(before_a) and after_d.startswith(before_d)
delta_a = [json.loads(x) for x in after_a[len(before_a):].splitlines()]
delta_d = [json.loads(x) for x in after_d[len(before_d):].splitlines()]
assert len(delta_a) == 3 and all(x['advance_id'] == A for x in delta_a)
assert len(delta_d) == 1 and delta_d[0]['discovery_id'] == D and delta_d[0]['status'] == 'raw'
after_states_a, after_states_d = api.current_advances(), api.current_discoveries()
assert {k: v for k, v in after_states_a.items() if k != A} == states_a
assert {k: v for k, v in after_states_d.items() if k != D} == states_d
for p, h in g['all_existing_frontier_sha256'].items(): assert sha((R / p).read_bytes()) == h
(E / 'normal-intake-advance-append.exact.jsonl').write_bytes(after_a[len(before_a):])
(E / 'normal-intake-discovery-append.exact.jsonl').write_bytes(after_d[len(before_d):])
result = {'normal_advance_calls': 3, 'normal_raw_Discovery_calls': 1, 'state': after_states_a[A]['state'],
    'owner': after_states_a[A]['owner_id'], 'all_old_ledger_prefixes_exact': True,
    'all315_prior_advance_states_unchanged': True, 'all44_prior_discovery_states_unchanged': True,
    'all474_prior_frontiers_unchanged': True, 'target_proof_calls_before_admission': 0,
    'no_new_goal_or_background_ASTIS': True, 'no_self_concept_validation': True}
(E / 'normal-intake-result.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
