from verify import *
seal=json.loads((D/'candidate/research-wiki/paper-contributions/GaussianComplexity/zero-query-separation-statement-seal.json').read_text())
header='import Tests.GaussianComplexityZeroQuerySeparation\nimport Lean\nopen Matrix MeasureTheory ProbabilityTheory Set Lean\nopen scoped NNReal ENNReal\nset_option autoImplicit false\nset_option maxRecDepth 4096\nset_option maxHeartbeats 0\n'
for label,key in [('SealP','producer'),('SealT','actual_private_consumer')]:
 sig=seal[key]['signature']; start=sig.index('{d :'); binders,body=sig[start:].split(' :\n',1)
 header+='def '+label+' : Prop := ∀ '+binders+',\n'+body+'\n'
body=r'''
run_cmd do
  let env := (← getEnv).setExporting false
  setEnv env
  let pm := `AutoSamplingTheory.ExampleCases.GaussianComplexity.ZeroQuerySeparation
  let tm := `Tests.GaussianComplexityZeroQuerySeparation
  let some pi := env.getModuleIdx? pm | throwError "P module absent"
  let some ti := env.getModuleIdx? tm | throwError "T module absent"
  let owned := env.constants.toList.filter fun (n, _) =>
    env.getModuleIdxFor? n == some pi || env.getModuleIdxFor? n == some ti
  unless owned.length > 1 && owned.length < 500 do throwError "Unexpected owned inventory size"
  let p := `AutoSamplingTheory.ExampleCases.GaussianComplexity.ZeroQuerySeparation.actual_zero_query_gaussian_event_gap
  let ts := owned.filter fun (n, _) => n.toString.endsWith ".no_common_zero_query_output"
  unless ts.length == 1 do throwError "Consumer root inventory not singleton"
  let t := ts.head!.1
  let owns := fun n => env.getModuleIdxFor? n == some pi || env.getModuleIdxFor? n == some ti
  let mut totalReach : NameSet := {}
  for (root, expected, checked) in [(p, `SealP, `NativePSealApplied), (t, `SealT, `NativeTSealApplied)] do
    let some ci := env.find? root | throwError "Root missing {root}"
    match ci with
    | .thmInfo _ => pure ()
    | _ => throwError "Actual root not a theorem: {root}"
    Lean.Elab.Command.liftCoreM <| addDecl <| Declaration.thmDecl {
      name := checked, levelParams := [], type := mkConst expected, value := mkConst root }
    logInfo m!"EXACT_SEALED_PROP_KERNEL_APPLIED {root} as {checked}"
    let mut todo := [root]
    let mut seen : NameSet := {}
    let mut firstParents : NameSet := {}
    while !todo.isEmpty do
      let n := todo.head!
      todo := todo.tail!
      unless seen.contains n do
        seen := seen.insert n
        if n != root && (n == p || (n.toString.startsWith "AutoSamplingTheory." && !owns n)) then
          firstParents := firstParents.insert n
        else if owns n then
          let some c := env.find? n | throwError "Owned constant missing {n}"
          let some v := c.value? true | throwError "Owned body absent {n}"
          todo := c.type.getUsedConstants.toList ++ v.getUsedConstants.toList ++ todo
    totalReach := seen.toList.foldl (fun a n => a.insert n) totalReach
    logInfo m!"MEASURED_FIRST_PUBLIC_ASTIS_PARENTS {root}: {firstParents.toList}"
    let want := if root == p then [] else [p]
    unless firstParents.toList.length == want.length && want.all firstParents.contains do
      throwError "Measured first public ASTIS parents unexpected"
    logInfo m!"OWNED_REACHABLE_FROM_ROOT {root}: {seen.toList.filter owns}"
  let allowed := [`propext, `Classical.choice, `Quot.sound]
  for (n,c) in owned do
    let some v := c.value? true | throwError "No owned body {n}"
    let axioms ← Lean.collectAxioms n
    unless axioms.all allowed.contains do throwError "Forbidden recursive axiom for {n}: {axioms}"
    let used := (c.type.getUsedConstants.toList ++ v.getUsedConstants.toList).eraseDups
    unless used.length < 2000 do throwError "Direct dependency output would be too large"
    logInfo m!"OWNED_INVENTORY {n}; MODULE={if env.getModuleIdxFor? n == some pi then pm else tm}; TYPE_HASH={hash c.type}; VALUE_HASH={hash v}; ROOT_REACHABLE={totalReach.contains n}"
    logInfo m!"OWNED_DIRECT_CONSTANTS {n}: {used}"
    logInfo m!"OWNED_RECURSIVE_AXIOMS {n}: {axioms}"
    unless totalReach.contains n do throwError "Unreachable owned declaration {n}"
  logInfo m!"ALL_MODULE_OWNED_DECLARATIONS_INSPECTED={owned.length}; NO_UNEXPECTED_AXIOMS; ALL_REACHABLE"
#print axioms NativePSealApplied
#print axioms NativeTSealApplied
'''
probe=write('fresh/source/IndependentNativeKernel.lean',header+body)
config=json.loads((D/'environment.json').read_text()); env=os.environ.copy(); env['LEAN_PATH']=json.loads((D/'fresh/import-path.json').read_text())['LEAN_PATH']
r=run('independent-kernel-attempt2',[config['lean_binary'],'-o',str(D/'fresh/lib/IndependentNativeKernel.olean'),'-i',str(D/'fresh/lib/IndependentNativeKernel.ilean'),'IndependentNativeKernel.lean'],cwd=D/'fresh/source',env=env)
sys.exit(r.returncode)
