import Mathlib.Probability.Distributions.Gaussian.Multivariate
import Mathlib.Probability.Moments.MGFAnalytic
import Mathlib.Probability.Distributions.Gaussian.HasGaussianLaw.Independence
import Mathlib.Tactic
noncomputable section
open MeasureTheory ProbabilityTheory
open scoped ProbabilityTheory ENNReal NNReal Topology
example (a t : ℝ) (f : ℝ → ℝ) (hf : HasDerivAt f (a*t*f t) t) :
    HasDerivAt (fun u => a*u*f u) ((a+a^2*t^2)*f t) t := by
  have hp := ((hasDerivAt_id t).const_mul a).mul hf
  apply hp.congr_deriv
  dsimp
  ring
example (v : ℝ≥0) : mgf (id : ℝ → ℝ) (gaussianReal 0 v) =
    fun t => Real.exp ((v : ℝ) * t ^ 2 / 2) := by
  change mgf (fun x : ℝ => x) (gaussianReal 0 v) = _
  simpa only [zero_mul, zero_add] using
    (mgf_fun_id_gaussianReal (μ := 0) (v := v))
