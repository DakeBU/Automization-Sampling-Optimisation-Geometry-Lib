import pathlib, json, hashlib, datetime
r=pathlib.Path('/Users/zhouhuanjian/ASTIS-GC')
p=r/'.astis/semantic-neutral-20261110/cg_tc_8f2b60/phase1'
inputs=['AGENTS.md','docs/proof-digestion-protocol.md','docs/theorem-publication-protocol.md','docs/evidence-routed-memory-protocol.md','.agents/skills/astis-source-dependency-audit/SKILL.md']
records=[]
for i,f in enumerate(inputs):
 b=(r/f).read_bytes(); dst=p/f'procedure-{i}.txt'; dst.write_bytes(b)
 records.append({'path':f,'snapshot':dst.name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
(p/'procedural-inputs.json').write_text(json.dumps(records,ensure_ascii=False,indent=2)+'\n')
(p/'initial-exposure.json').write_text(json.dumps({'phase':'raw-only','before_snapshot':{'commands':['cat AGENTS.md','cat docs/proof-digestion-protocol.md docs/theorem-publication-protocol.md docs/evidence-routed-memory-protocol.md .agents/skills/astis-source-dependency-audit/SKILL.md','/opt/anaconda3/bin/python -c [fixed raw SHA/size verification]'],'tool_output':{'outer_warning':'truncated output (original token count: 17682)','displayed_total_output_lines':3,'call0_exit':0,'call0_original_token_count':6942,'call1':'output partly lost to outer tool truncation; re-read from full byte snapshots before any raw cognition','call2_exit':0,'call2_output':'.astis/huanjian-resume-20261103/2610.20492v1.html\n951991\n6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915\n'}},'exposure_exclusions':['No draft/seal/type/author SG/root implementation/current or old verdict/semantic registry/controlled graph/index/ledger/ATLAS read.','Only parent assignment, allowed procedures, and fixed raw SHA metadata seen.'],'remediation':'Full procedural files snapshotted separately; read them in bounded calls. No missing output represented as read.'},ensure_ascii=False,indent=2)+'\n')
print(json.dumps(records,ensure_ascii=False,indent=2))
