from pathlib import Path
import copy, datetime, hashlib, json, subprocess, sys
sys.path.insert(0, 'tools')
import astis_advance as advance
import astis_publication as pub
sha = lambda raw: hashlib.sha256(raw).hexdigest()
dump = lambda x: (json.dumps(x, ensure_ascii=False, indent=2) + '\n').encode()
B = Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-first-order-semantic-evidence')
DECL = 'AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumFirstOrder.actual_first_order_query'
ADV = 'ASTIS-SA-20261108-GaussianComplexityFixedSpectrumFirstOrder'
OWNER = 'huanjian_gc_20261108_fixed_spectrum_first_order'
DISC = 'ASTIS-DISC-20261108-GaussianQuadraticOracleFactorization-FixedSpectrumGradient'
CELL = Path('research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-first-order.json')
PROD = Path('AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumFirstOrder.lean')
TEST = Path('Tests/GaussianComplexityFixedSpectrumFirstOrder.lean')
assert subprocess.check_output(['git', 'rev-parse', 'HEAD']).decode().strip() == '6b2d0748e999d98e4453634de85090e26c40b77a'
assert sha(PROD.read_bytes()) == '1af1a71edf059edfe10a2b5069002fe703b6f2d1a30c153951e06afd3b8e6423'
assert sha(TEST.read_bytes()) == '5d1e1787ea491bb5e0b433eaf1f22743ba9e1d3993becfd9439a0c9d822c4d69'
labels = ['fixed-spectrum-first-order-producer-first', 'fixed-spectrum-first-order-focused-consumer-first', 'fixed-spectrum-first-order-kernel-parents', 'fixed-spectrum-first-order-anonymous-exact-application', 'fixed-spectrum-first-order-anonymous-decoder-statement']
checks = []
for label in labels:
    rows = list(Path('.astis/huanjian-resume-20261103').glob('*-' + label + '.receipt.json'))
    assert len(rows) == 1
    p = rows[0]
    r = json.loads(p.read_bytes())
    assert r['exit_code'] == 0 and r['head_before'] == r['head_after'] == '6b2d0748e999d98e4453634de85090e26c40b77a'
    raw = Path(r['log']).read_bytes()
    assert sha(raw) == r['log_sha256']
    checks.append({'receipt': str(p), 'receipt_sha256': sha(p.read_bytes()), 'raw_log_sha256': sha(raw), 'actual_elapsed_seconds': r['elapsed_seconds']})
focus = Path(json.loads(Path(checks[1]['receipt']).read_bytes())['log']).read_text()
assert focus.count('depends on axioms: [propext,') == 2 and 'sorryAx' not in focus
kernel = Path(json.loads(Path(checks[2]['receipt']).read_bytes())['log']).read_text()
assert kernel.count('ACTUAL_ASTIS_PARENT ') == 3 and 'Exact actual ASTIS producer1/private-consumer2 parents checked' in kernel
for p in [PROD, TEST]:
    import re
    assert not re.search(r'\b(sorry|admit|sorryAx)\b|^\s*(axiom|unsafe)\b', p.read_text(), re.M)
audit = json.loads(Path('research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-first-order.json').read_bytes())
assert audit['state'] == 'blind-reconstructed' and audit['publication_binding_sha256'] == '51d5a5e9390a0d66c2d5b72d042a042eec8d3d60433043ea3909bf9320ccb31e'
pub.check_advance([DECL], reviewed=False)
discovery = advance.current_discoveries()[DISC]
assert discovery['advance_id'] == ADV and discovery['kind'] == 'conceptual-mirror' and discovery['status'] == 'validated'
review = B / 'conceptual-oracle-factorization/independent-review/review-v1.json'
assert sha(review.read_bytes()) == 'd26df0070bed3549b90087003af5e26884d58788e6f23586db3f0476bcb23597'
capsule = {'recorded_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'state': 'ACTUAL_LOCAL_PRODUCER_AND_GENUINE_CONSUMER_COMPILED_SOURCE_REVIEW_PENDING', 'immutable_preproof_admission_commit': '6b2d0748e999d98e4453634de85090e26c40b77a', 'source_raw_sha256': '6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915', 'producer': DECL, 'production_raw_sha256': sha(PROD.read_bytes()), 'Test_raw_sha256': sha(TEST.read_bytes()), 'producer_signature_sha256': '452c547235344031f5f8c3035dc3f590a876741993c7ae9a1be2a7e129a948c1', 'consumer_signature_sha256': 'f0059bed1e49535a1dde0aba66a62bf371958bc8915d40a2b6c65c5df8366e4d', 'actual_direct_ASTIS_producer_parents': ['AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumAdmissibility.actual_precision_admissible'], 'actual_direct_ASTIS_private_consumer_parents': ['AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumAffine.actual_affine_precision_query', DECL], 'private_consumer': '_private.Tests.GaussianComplexityFixedSpectrumFirstOrder.0.actual_reference_precision_first_order_consumer', 'source_gap_implementation_map': {'actual_symmetry_and_source_class': 'Canonical actual_precision_admissible on exactly the literal source A; hA is its Hermitian projection.', 'real_geometry': 'hquery rfl and Matrix.inner_toEuclideanCLM identify actual coordinate/matrix and Euclidean meanings.', 'actual_Frechet_existence': 'hraw differentiates half of inner(id,H); hlin uses actual self-adjointness to identify the Riesz functional.', 'total_gradient_recovery': 'HasGradientAt is produced first; hg.gradient then identifies total gradient.', 'actual_affine_provider_consumption': 'Private Test hforward calls canonical actual_affine_precision_query and takes its forward projection for the SAME O; hfirst calls the new producer and simpa substitutes the actual reply.', 'unclaimed_source_C4_branches': 'No C-infinity/Hessian/SC/smoothness/minimizer output; source justification/provenance edges are not compiled proof credit.'}, 'canonical_reuse': 'One existing ASTIS producer parent, two genuine Test parents, canonical Mathlib CLM/inner-product/Riesz derivative facts. Old block FirstOrderQuery is neither imported nor an actual proof parent; the analogous mechanism belongs only to the typed existing conceptual bridge.', 'actual_checks': checks, 'standard_axioms_only': ['propext', 'Classical.choice', 'Quot.sound'], 'focused_new_files_fake_closure_scan': 'Actual target source scan and actual axiom printouts passed; canonical whole-root gate remains a separate later integration check.', 'target_proof_failure': 'NONE; producer and actual consumer both compiled on first attempts.', 'nonmathematical_diagnostics': ['Preproof frontier metadata required explicit Samplinglib/Mathlib labels; failed receipt and original bytes retained, no statement change.', 'One broad post-admission rg referenced a nonexistent Optimization directory and emitted partial/truncated matches; subsequent targeted actual floor lookup narrowed it. This is an API lookup issue, not a mathematical counterexample.'], 'conceptual_mirror_supplement': {'discovery_id': DISC, 'status': 'validated', 'review_path': str(review), 'review_sha256': sha(review.read_bytes()), 'shared_models_applied': False, 'cross_route_Lean_or_cost_transport': False}, 'publication_binding_sha256': audit['publication_binding_sha256'], 'sourceV_or_wholeGoal': False}
p = B / 'local-proof-capsule.json'
assert not p.exists()
p.write_bytes(dump(capsule))
cell = json.loads(CELL.read_bytes())
cell['evidence']['preproof_phase_history'] = {'execution_boundary': cell['evidence']['execution_boundary'], 'source_detail_gap': cell['source_detail_audit']['gap'], 'old_statement_seal_status': cell['statement_seal']['status']}
cell['status'] = 'proved_locally'
cell['statement_seal']['status'] = 'EXACT_PRODUCER_AND_ACTUAL_CONSUMER_COMPILED_POSTPROOF_REVIEW_PENDING'
cell['evidence']['execution_boundary'] = 'Exact source pointwise derivative existence and value/gradient pair, plus genuine same-O forward-affine consumer, are compiled with unchanged signatures and actual1/2ASTIS proof-parent inventory. Independent blind reconstruction completed with honest ambient disclosure; fresh source reviewer has frozen raw-source cognition and is performing selective comparison. Whole-module/freshLean/staticreader/sourceV/root/site/Chrome/remote/purification remain separate.'
cell['evidence']['local_proof_capsule'] = str(p)
cell['evidence']['actual_compiled_producer_parents'] = capsule['actual_direct_ASTIS_producer_parents']
cell['evidence']['actual_compiled_private_consumer_parents'] = capsule['actual_direct_ASTIS_private_consumer_parents']
cell['evidence']['publication_binding_sha256'] = audit['publication_binding_sha256']
cell['evidence']['focused_checks'] = [row['receipt'] for row in checks]
cell['source_detail_audit']['gap'] = 'Selected actual symmetry/geometry/Fréchet existence/gradient recovery and genuine forward-affine consumption obligations are locally discharged. Literal Eq1/source-class/forward-only boundaries remain explicit; independent postproof source and whole-module checks are pending. Remaining C4 and operational/adaptive/precision/TV/cost/main bounds remain separate.'
cell['source_detail_audit']['fidelity_boundary'] = cell['evidence']['execution_boundary']
cell['source_proof_coverage']['current_implementation_mapping'] = str(p) + '#/source_gap_implementation_map'
cell['source_proof_coverage']['original_open_obligations_are_preproof_history'] = True
cell['reuse_plan']['reused_declarations'] = capsule['actual_direct_ASTIS_producer_parents'] + ['AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumAffine.actual_affine_precision_query']
cell['conceptual_mirror_audit'] = {'status': 'candidates-published', 'discovery_ids': [DISC], 'reason': 'The already existing typed quadratic-oracle-factorization bridge acquires a narrow compiled fixed-spectrum gradient/value and actual forward-affine instance. Same bridge ID and canonical declarations are retained; independent conceptual validation adds no cross-route formal implication, operational/cost/TV result or current sourceV. Models remain unchanged until serialized post-sourceV integration.'}
CELL.write_bytes(dump(cell))
states = advance.current_advances()
assert states[ADV]['state'] == 'EXPLORING' and not any(v['state'] == 'STABILIZING' for v in states.values())
ledger = Path('runs/substantive_advances.jsonl')
before = ledger.read_bytes()
foreign_cells = {str(q): sha(q.read_bytes()) for q in CELL.parent.glob('*.json') if q != CELL}
advance.transition_advance(ADV, 'PROVED_LOCAL', worker_id=OWNER, evidence={'theorem_delta': 'Genuine actual fixed-spectrum Euclidean derivative/value-gradient pair and same-O forward reference2 reply consumer, with exact original signatures and actual canonical parent use.', 'result_kind': 'theorem-edge', 'lean_files': [str(PROD), str(TEST)], 'lean_declarations': [DECL], 'publication_declarations': [DECL], 'focused_checks': checks, 'truth_boundary': cell['source_detail_audit']['fidelity_boundary'], 'conceptual_mirror_audit': cell['conceptual_mirror_audit'], 'local_proof_capsule': str(p), 'source_review': 'Pending independent fresh selective comparison/whole-module/freshLean/staticreader and normal sourceV. Root does not mark VERIFIED.'})
after = ledger.read_bytes()
now = advance.current_advances()
assert after.startswith(before) and len(after[len(before):].splitlines()) == 1
assert all(now[k] == v for k, v in states.items() if k != ADV)
assert foreign_cells == {str(q): sha(q.read_bytes()) for q in CELL.parent.glob('*.json') if q != CELL}
(B / 'normal-PROVED_LOCAL-preservation.json').write_bytes(dump({'normal_state': now[ADV]['state'], 'before_ledger_sha256': sha(before), 'after_ledger_sha256': sha(after), 'append_sha256': sha(after[len(before):]), 'old_prefix_preserved': True, 'foreign_states_preserved': len(states) - 1, 'foreign_raw_frontiers_preserved': len(foreign_cells), 'sourceV_or_integration_or_Goal_complete': False}))
readme = B.parent / 'README.md'
old = readme.read_bytes()
readme.write_bytes(('## 2026-11-08: actual fixed-spectrum gradient/value and forward affine consumer PROVED_LOCAL\n\nThe exact original source interfaces compile on first attempts. The producer genuinely proves Frechet existence before identifying gradient Ax; the actual same-O private consumer reconstructs the kappa observation from its reference2 precision reply. Actual proof terms have ONE canonical admissibility producer parent and TWO Test parents (new producer plus existing affine provider), with only the standard three axioms. Progressive six-step source/Lean lesson and bound publication51d5a5e9 are drafted; blind reconstruction is independent with ambient cues disclosed. Fresh raw-source cognition was frozen before selective anonymous comparison, which is in progress.\n\nThe existing typed oracle-factorization bridge supplement is independently conceptually validated; models remain unapplied and no cross-route Lean implication/cap/TV/expected-cost theorem follows. Root only marked PROVED_LOCAL via the normal API. SourceV, independent whole-module/freshLean/reader and exact-root/site/graph/desktop-mobile acceptance, remote delivery, purification/Seal and both full main bounds remain open. Same foreground Goal, old284 states/443 frontiers and all earlier checkpoints retained.\n\n').encode() + old)
print(json.dumps({'state': now[ADV]['state'], 'actual_producer_parent_count': 1, 'actual_private_consumer_parent_count': 2, 'actual_independent_blind_reconstruction': True, 'mirror_supplement_validated_models_unapplied': True, 'sourceV': False}))
