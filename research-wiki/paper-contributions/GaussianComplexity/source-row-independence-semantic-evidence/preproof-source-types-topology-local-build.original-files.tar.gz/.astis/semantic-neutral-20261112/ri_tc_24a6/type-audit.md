# Independent type-only meaning audit

This audit followed the already frozen preliminary raw reading and the root's
handoff of the exact new seal and its binder/definition audit. The source graph
remained closed throughout. No current GaussianComplexity implementation,
target proof, previous audit or ledger was read, and no Lean command was run.

## Inputs and conclusion of this limited audit

The exact input packet is
`.astis/huanjian-gc-source-row-independence-20261112/selective-type-definition-packet.json`,
SHA-256 `c9f8312610515f2ebc067612c981889103e7d8a93a00aa5f75ec8c74feb1ab68`.
It names Statement Seal
`88a55849ce9e13a9a04edff6aac13ce32d4370712b1b7a422fba0d570ff0b25e`.
The producer and consumer signature strings independently hash to their exact
declared values:

- Producer: `2898f07e581afb8c38fa6dda16193a411dee6b9729a198b0a1437a98c726405a`.
- Consumer: `026e3d3282b502cb069c022ac844e86ed4613cf62a8be2a9948edf3f25f02cf8`.

The packet's declared context digest is
`bb8e77b15c4905a3b5d4aa37e482314e44a5d97886088c72b91f36050bcf9860`,
matching the root's handoff. Its literal-print digest, all five embedded literal
excerpt digests and all six raw-source byte-span digests were independently
recomputed and matched. This audit binds the packet bytes; it does not pretend
to recompute an unspecified serialization of the separately named seal/context.

**No type/source meaning issue was found within the prospective narrow
boundary.** This is a type-only fidelity finding, not source-topology admission,
an elaboration check, proof validation, proof permission or publication status.

## Meaning reconstructed from the types and definition context

The producer chooses natural d,q with the sole logical input 2q+1<d. Its sample
space consists of q+1 columns, each a vector in the real d-dimensional Euclidean
space. The measure is their finite product of canonical standard Gaussian
measures. For every physical i in Fin d, the row consists of the i-th actual
coordinate of every column, packaged as a Euclidean vector of dimension q+1.
The result says this entire physical-row family is jointly independent under
that explicitly written product measure.

The displayed standard definition of iIndepFun uses the sigma-algebras pulled
back by each row function. Through iIndep/iIndepSets and the constant kernel at
Unit under the point mass at (), its meaning is finite-family event
factorization, not pairwise independence, covariance cancellation, injectivity
or an iid assertion. There is no new random ambient parameter in the Unit
wrapper. The separate same-space measure is explicitly passed, so no default
volume law silently replaces the product law.

The private consumer repeats that exact sample space, measure and row. It
defines the source threshold, midpoint grid, deterministic features and literal
truncated matrices, then asks for two conclusions: every actual matrix-valued
map is measurable, and the full family of those maps is jointly independent
under the same measure. Neither field is a hypothesis. The result does not
assume the desired row independence or import a law-equality certificate as a
public premise.

## Literal formula, dimension and endpoint audit

The source physical index i=1,...,d corresponds to i.val+1. The typed midpoint
angle is ((i.val+1-1/2)pi)/d, so there is no zero-based half-grid shift. Feature
indices k=0,...,q have feature0=1 and featurek=sqrt(2)cos(k theta_i), matching
the source vector without a spurious cosine coefficient in its constant slot.
The threshold is 2(q+1)+3log(1000d), and truncation includes equality.

Both matrix index types are Fin(q+1) times Fin(q+1). The first paired component
is the Gaussian-row coordinate; the second is the feature coordinate. Thus the
literal matrix at paired row (a,k), paired column (b,l), inside the cutoff, has
entry d^{-1} gamma_i[a] gamma_i[b] t_i[k] t_i[l]. Outside the cutoff all entries
are zero. This matches the source outer-product/Kronecker formula and exact
1/d scale. The finite double-function carrier is definitionally a real Matrix
and carries its ordinary product measurable structure, so it has not silently
replaced matrix events by a trivial measurable space. This type statement makes
no operator-norm claim.

The norm in the cutoff is the Euclidean norm of the actual row, not a norm of
the sample-space column function. All quantities in the cutoff except that row
are deterministic. There is no conditioning on all rows passing the cutoff,
and a particular Y_i uses no other row's randomness.

The input inequality includes q=0: there is one Gaussian column, one feature
coordinate equal to 1 and a 1 by 1 matrix for every physical row. The source
range gives nonzero d internally; no separate positivity input has been added.
No q>0, row-norm, Gram, moment, tail, integrability, successful-truncation,
tau or kappa premise appears. Every local let defines the actual object; it
does not quantify over a substitute satisfying a desired certificate. In
reading the binder table, its label DEFINITION denotes this separate
definitional audit, not a sixth category of logical source premise.

## Remaining proof and coverage boundaries

The producer concludes independence only. It does not itself conclude the
N(0,I_r) law of each row or measurability of each row. This is faithful to the
narrow independence split being reviewed; it must not be advertised as covering
all content of source p1's independent-N(0,I_r) sentence. The earlier/raw source
law obligation remains distinct.

The needed internal scalar-array/regrouping bridge and row-map measurability
remain unproved in this audit. So does measurability of the closed cutoff and
each finite matrix-entry map. Although the consumer's type has the right
conclusions, that type cannot establish that the eventual proof materially
calls the producer or any canonical row-law node. The packet's consumer_edge
is an intended dependency only, pending actual proof/call verification.

In particular, iIndepFun alone does not certify measurability of arbitrary
functions; the consumer's explicit measurability conclusion is meaningful.
Different physical rows have differing deterministic t_i maps, so no generic
iid matrix claim is admitted. No arbitrary ambient-law transfer, centered
variance, expectation, moment, tail, concentration or main bound is covered.

The root disclosed prior API exposure and preseal type-only failed forms, and
the packet explicitly sets formalizer_API_pristine=false. This reviewer has
not inspected that history and does not rebrand it as a pristine formalizer
experiment. This review itself saw the exact final sealed types only, after
its raw freeze and before any source graph. No target proof was attempted here.

The next phase is the independent source-coverage/topology challenge on the
root-supplied formal graph, using these fixed types and raw-source evidence.
No source graph has yet been approved or even read by this actor.
