from pathlib import Path
import hashlib,json
R=Path.cwd();E=R/'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-detector-semantic-evidence'
P=Path('AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumDetector.lean');T=Path('Tests/GaussianComplexityFixedSpectrumDetector.lean')
rows=[]
def add(ident,role,f,start,end,node,claim):
 p=Path(f);text=p.read_text();scope=0 if role in ['public-root','private-root','canonical-Mathlib-substrate'] else text.index(' := by')+len(' := by')
 assert text.count(start,scope)==1,(str(p),start,scope)
 a=text.index(start,scope);b=text.index(end,a+len(start)) if end else text.index('\n\n',a)
 code=text[a:b];rows.append({'id':ident,'role':role,'source_anchors':['S4.E11','S4.EGx2','S4.SS3.p4.1'],'source_or_overlay_node':node,'claim':claim,'lean':{'file':str(p),'line':text[:a].count('\n')+1,'end_line':text[:b].count('\n')+1,'file_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'exact_start_marker':start,'exact_locator_block_sha256':hashlib.sha256(code.encode()).hexdigest()},'separate_new_Lean_node':False})
for ident,role,f,start,end,node,claim in [
 ('P-type','public-root',P,'theorem actual_chebyshev_matrix_cosine',' := by','ov:producer','Exact all-natural-frequency auxiliary matrix identity; source instance n=2q+1.'),
 ('P-family','definition',P,'  let θ','  let Φ','ov:aux-parameters','Actual literal grid/precision and scalar normalization; proof-body occurrence distinguished from signature.'),
 ('P-conjugation','producer-proof',P,'  let Φ','  have hD','br:polynomial-conjugation','Existing unitary star-algebra automorphism and real transpose; internal nonzero reciprocal.'),
 ('P-normalize','producer-proof',P,'  have hD','  have hdiag','br:polynomial-conjugation','Scalar diagonal calculation and actual lift through same O.'),
 ('P-polynomial','producer-proof',P,'  have hdiag','\nend AutoSamplingTheory','ov:producer','Canonical aeval/diagonal/tuple maps and first-kind cosine identity; final actual matrix equality.'),
 ('C-type','private-root',T,'private theorem actual_rotated_gaussian_detector_event',' := by','ov:consumer-root','Private strict Borel/map event equality, not pi_A or probability and not an Anchor.'),
 ('C-objects','definition',T,'  let E','  have hT','ov:S-literal','Actual Lambda-inverse Gaussian, forward O rotation and literal intrinsic S.'),
 ('C-call','consumer-proof',T,'  have hT','  have hR','ov:producer','Genuine invocation of the exact public compiled declaration.'),
 ('C-R-meas','consumer-proof',T,'  have hR','  have hSc','ov:R-measurable','Actual continuous linear rotation produces measurability.'),
 ('C-continuity','consumer-proof',T,'  have hSc','  have hEvent','ov:event-borel','Real-inner quadratic identity gives continuity, independently of producer.'),
 ('C-event','consumer-proof',T,'  have hEvent','  have hO','ov:event-borel','Strict Borel event produced internally and later consumed.'),
 ('C-inverse','consumer-proof',T,'  have hO','  have hnorm','ov:coordinate-isometry','Full orthogonal inverse matvec, with both determinant signs.'),
 ('C-norm','consumer-proof',T,'  have hnorm','  have hquad','ov:coordinate-isometry','Canonical unitary continuous-linear norm preservation.'),
 ('C-quad','consumer-proof',T,'  have hquad','  have hstat','ov:coordinate-isometry','Producer plus matrix/bilinear transpose algebra gives actual all-vector cosine sum.'),
 ('C-S','consumer-proof',T,'  have hstat','  change MeasurableSet','ov:coordinate-isometry','Exact signed shifted statistic and norm; zero remains included in transport.'),
 ('C-map','consumer-proof',T,'  change MeasurableSet','\nend AutoSamplingTheory','ov:map-equality','Actual event/rotation measurability consumed by map_apply, followed by exact preimage; no toReal or probability estimate.')]:add(ident,role,f,start,end,node,claim)
std=[
 ('Unitary.conjStarAlgAut','Algebra/Star/UnitaryStarAlgAut.lean','def conjStarAlgAut'),
 ('Matrix.diagonalAlgHom','Data/Matrix/Basic.lean','def diagonalAlgHom'),
 ('Polynomial.aeval_algHom_apply','Algebra/Polynomial/AlgebraMap.lean','theorem aeval_algHom_apply'),
 ('Polynomial.aeval_pi_apply','Algebra/Polynomial/AlgebraMap.lean','theorem aeval_pi_apply :'),
 ('Polynomial.Chebyshev.T_real_cos','Analysis/SpecialFunctions/Trigonometric/Chebyshev/Basic.lean','theorem T_real_cos :'),
 ('Matrix.toEuclideanCLM','Analysis/CStarAlgebra/Matrix.lean','def toEuclideanCLM :'),
 ('Matrix.inner_toEuclideanCLM','Analysis/CStarAlgebra/Matrix.lean','lemma inner_toEuclideanCLM'),
 ('Unitary.map_mem','Algebra/Star/Unitary.lean','lemma map_mem'),
 ('ContinuousLinearMap.norm_map_of_mem_unitary','Analysis/InnerProductSpace/Adjoint.lean','theorem norm_map_of_mem_unitary'),
 ('Matrix.dotProduct_transpose_mulVec','Data/Matrix/Mul.lean','theorem dotProduct_transpose_mulVec'),
 ('MeasureTheory.Measure.map_apply','MeasureTheory/Measure/Map.lean','theorem map_apply (hf : Measurable f)')]
for decl,f,marker in std:
 add('S-'+decl,'canonical-Mathlib-substrate',Path('.lake/packages/mathlib/Mathlib')/f,marker,None,'standard-library',decl+' is an existing canonical actual implementation dependency; locator excerpt, not new ASTIS/source-author proof credit.')
x={'schema':1,'scope':'Exact postproof public identity and private actual Gaussian pushforward event correspondence. Source graph was independently built before implementation; no import/count implication.','producer_sha256':hashlib.sha256(P.read_bytes()).hexdigest(),'Test_sha256':hashlib.sha256(T.read_bytes()).hexdigest(),'current_author_graph_sha256':'a3d876092b9854614c6d09bba8f1fa4add8d772ba030fa2358526b9c55ac6449','historical_overlay_sha256':'a71c6d355c792971abca484dbf784be6cbdf897a1a199e802d26c8b7ecca170d','graph_version_boundary':'V1/HOLD preserved; exact3append V2 independently accepted. Overlay historical base hash remains unchanged; successor packet explicitly binds V2.','rows':rows,'all_scope_remaining':['latent/rotated Gaussian law identification with pi_A','target probability/concentration/Krylov/Haar/adaptive algorithm/TV/oracle/precision/cost','both complete main lower bounds/upstream QG-definition closure','global integration/site/browser/publication/purification'],'actual_ASTIS_owned_declarations':2,'only_public_Anchor':'AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumDetector.actual_chebyshev_matrix_cosine','one_canonical_node_per_compiled_declaration':True}
p=E/'source-to-lean-map-v1.json';assert not p.exists();p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'rows':len(rows),'map_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'row_counts_not_math_credit':True}))
