from pathlib import Path
import sys,json,hashlib,os,subprocess
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent.relative_to(Path.cwd())
sha=lambda b:hashlib.sha256(b).hexdigest();dump=lambda x:(json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode()
assert os.environ.get('PYTHONOPTIMIZE')=='0' and sys.flags.optimize==0
target=W/'admit_normal_intake_prepared.py'
assert not target.exists() and not (W/'intake-baseline.private.json').exists()
s=Path('.astis/huanjian-gc-zero-query-20261110/admit_normal_intake_prepared.py').read_text()
s=s.replace('zero-query-separation','fixed-spectrum-cosine-gram').replace('ZeroQuerySeparation','FixedSpectrumCosineGram').replace('zero_query_separation','fixed_spectrum_cosine_gram')
s=s.replace('c4c83b1287b9b7ab5cabc8aa7e4f901e4702bd4c2aec99c63957b74db31d4195','a5e464a34ee276e62267d21f0965c1a0b1ef905bed27e679a85ecee3cd7fd45c')
s=s.replace('DraftLiteralStatementFormation.lean','StatementFormation.lean')
s=s.replace("assert states['ASTIS-SA-20261110-GaussianComplexityFixedSpectrumTargetLaw']['state'] == 'VERIFIED'","assert states['ASTIS-SA-20261110-GaussianComplexityFixedSpectrumTargetLaw']['state'] == 'VERIFIED'\nassert states['ASTIS-SA-20261110-GaussianComplexityZeroQuerySeparation']['state'] == 'VERIFIED'")
a=s.index('def controls():');b=s.index('\nassert len(sys.argv)',a)
controls='''def controls():
    names = {str(p) for p in Path('research-wiki/frontier-cells').rglob('*') if p.is_file()}
    names |= {str(p) for p in Path('runs').iterdir() if p.is_file()}
    names.add('website/content/samplewiki_companion_frontiers.json')
    for p in Path('.astis').iterdir():
        if p.is_file() and any(t in p.name.lower() for t in ['queue','control','global','goal','steer','execution']):
            names.add(str(p))
    for n in ['control','queues','runtime','harness','state','locks']:
        d = Path('.astis') / n
        if d.is_dir():
            names |= {str(p) for p in d.rglob('*') if p.is_file()}
    known = json.loads(Path('.astis/huanjian-gc-zero-query-20261110/sourceV-exact-foreign-control-paths.json').read_bytes())
    names |= set(known['exact_existing_foreign_control_paths'])
    prior = Path('.astis/semantic-neutral-20261110/z_src_2f8a71/normal-sourceV')
    names |= {str(p) for p in prior.rglob('*') if p.is_file() and not p.is_symlink()}
    own_roots = ['research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-cosine-gram-semantic-evidence/']
    own_exact = {'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-cosine-gram-statement-seal.json',
        'AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumCosineGram.lean',
        'Tests/GaussianComplexityFixedSpectrumCosineGram.lean',
        'website/content/declaration_lessons/huanjian-fixed-spectrum-cosine-gram.json',
        'website/content/publications/huanjian-fixed-spectrum-cosine-gram.json',
        'research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-cosine-gram.json'}
    # Ordinary foreign untracked regular files are guarded. Nested repositories
    # such as restricted ATLAS are directories and never traversed/read here.
    for raw in subprocess.check_output(['git','ls-files','--others','--exclude-standard','-z']).split(b'\\0'):
        if not raw:
            continue
        n=raw.decode()
        if n not in own_exact and not any(n.startswith(p) for p in own_roots) and Path(n).is_file():
            names.add(n)
    return sorted(n for n in names if Path(n).is_file())
'''
s=s[:a]+controls+s[b:]
a=s.index('boundary = (');b=s.index('\nproposal = ',a)
s=s[:a]+'''boundary = ('Selected FactC.5 deterministic cosine-frame Gram/weighted cancellation/row-norm '
    'identities, all natural q with2q+1<d, and a genuine private actual standard-Gaussian '
    'entrywise Gram integrability/mean consumer. No supplied Gram/moment/independence witness. '
    'Range(B)=Krylov, C6 concentration/absoluteC, full Lemma4.4, Haar/adaptive/oracle/TV/precision/'
    'deterministic worst-query-cap/explicit expected-cost adapters, both complete main lower bounds, '
    'sourceV/STAB/global/site/browser/publication/purification or Goal completion remain separate. '
    'All prior states/frontiers/queues and eleven locally source-verified packets including '
    'the ZeroQuery privateT reader-neighbor HOLD remain intact.')'''+s[b:]
s=s.replace("goal='Prove the actual zero-query Gaussian coordinate-event gap, materially consumed by an actual common-probability-output TV obstruction at the exact source endpoint.'","goal='Prove actual cosine-frame Gram orthogonality, weighted cancellation and row-norm identities, materially consumed by integrable actual Gaussian Gram means.'")
a=s.index('    dag_inputs=');b=s.index('    proposed_files=',a)
s=s[:a]+'''    dag_inputs=('source:arXiv2610.20492v1 S4.Thmtheorem4; A3.SS2; A3.Thmtheorem5 selected deterministic frame and actual Gaussian mean components',
        'Known prior canonical finite-grid alias and Gaussian background is reused only after admission; source topology is not an actual compiled dependency certificate.'),
'''+s[b:]
assert 'zero-query Gaussian coordinate-event' not in s
assert 'S3.SS3.SSS0' not in s
target.write_text(s);target.chmod(0o444)
# Execute definitions/imports only, never the grant check or the normal API body.
namespace={'__file__':str(target),'__name__':'prepared_controls_only'}
exec(compile(s.split('assert len(sys.argv)')[0],str(target),'exec'),namespace)
controls=namespace['controls']()
pre=W/'preproof-baseline.private.json';pb=pre.read_bytes();x=json.loads(pb)
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==x['head']
C=namespace['C'];L=namespace['L']
assert sha(L.read_bytes())==x['ledger_sha256']
b={'state':'PRIVATE_FOREIGN_CONTROL_SNAPSHOT_NEVER_EXPORT','preproof_snapshot':{'path':str(pre),'sha256':sha(pb)},'own_frontier':{'path':str(C),'sha256':sha(C.read_bytes())},'control_paths':controls,'foreign_control_hashes':{n:sha(Path(n).read_bytes()) for n in controls if n not in {str(C),str(L)}},'normal_API_calls_so_far':0,'restricted_nested_repositories':'Not traversed, read or hashed; no content-preservation claim beyond no writes. Ordinary foreign untracked regular files and exact ignored queue/control paths are guarded.'}
p=W/'intake-baseline.private.json';p.write_bytes(dump(b));p.chmod(0o444)
out={'prepared_intake_script':str(target),'prepared_intake_script_sha256':sha(target.read_bytes()),'private_baseline_sha256':sha(p.read_bytes()),'private_preproof_baseline_sha256':sha(pb),'control_path_count':len(controls),'foreign_control_count':len(b['foreign_control_hashes']),'normal_API_calls':0,'target_proof_API_authority':False,'rule':'Only exact qualified independent prospective grant after mathematical freezes may allow this script to execute normally. Assertions require explicit PYTHONOPTIMIZE=0; permanent once marker prevents replay.'}
(W/'prepared-intake-safe-summary.json').write_bytes(dump(out));print(json.dumps(out))
