theorem subset_span : s ⊆ span R s := fun _ h => mem_span.2 fun _ hp => hp h
