theorem eval_add : (p + q).eval x = p.eval x + q.eval x :=
  eval₂_add _ _
