"""Project an already observed independent source V; no transition API calls."""
from pathlib import Path
import gzip
import hashlib
import json
import shutil
import sys
import tarfile

P = Path('.astis/huanjian-gc-fixed-spectrum-moments-20261109/cosine-expansion')
E = Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-cosine-expansion-semantic-evidence')
C = Path('research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-cosine-expansion.json')
R = Path(sys.argv[1])
sha = lambda b: hashlib.sha256(b).hexdigest()
dump = lambda x: (json.dumps(x, ensure_ascii=False, indent=2) + '\n').encode()
receipt_raw = (R / 'VERIFIED-actual-receipt.json').read_bytes()
receipt = json.loads(receipt_raw)
assert receipt['status'] == 'OBSERVED_ONE_NORMAL_VERIFIED_TRANSITION'
assert receipt['normal_API_calls'] == 1
assert receipt['worker_and_verifier'] == '/root/cosine_fresh_source_5d8c2a'
assert receipt['checked_commit'] == '37645c774481c4cad19fc29bcaa76799da64db7d'
before = (R / 'before-ledger.exact.jsonl').read_bytes()
after = (R / 'after-observed-ledger.exact.jsonl').read_bytes()
append = (R / 'actual-append-observed.exact.jsonl').read_bytes()
assert after == before + append and after == Path('runs/substantive_advances.jsonl').read_bytes()
assert append.endswith(b'\n') and len(append.splitlines()) == 1
assert sha(append) == receipt['actual_append_sha256']
event = json.loads(append)
assert event['advance_id'] == 'ASTIS-SA-20261109-GaussianComplexityFixedSpectrumCosineExpansion'
assert (event['from_state'], event['to_state']) == ('PROVED_LOCAL', 'VERIFIED')
assert event['worker_id'] == event['evidence']['verifier_id'] == receipt['worker_and_verifier']
audit = json.loads(Path('research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-cosine-expansion.json').read_bytes())
assert audit['state'] == 'source-reviewed' and audit['source_review']['state'] == 'accepted'
assert audit['source_review']['reviewer'] == event['worker_id']
assert audit['source_review']['checked_commit'] == event['evidence']['verified_commit'] == receipt['checked_commit']
assert audit['publication_binding_sha256'] == '8ddbbdb086becb57b2b8212154d9f607b121f7955cfcce132927210eaa04b95c'
out = E / 'actual-source-V'
out.mkdir(exist_ok=False)
for name in ('VERIFIED-actual-receipt.json', 'preflight-receipt.json', 'API-observation.json',
             'normal-API-attempt.once.json', 'actual-call-evidence.json', 'actual-append-observed.exact.jsonl'):
    shutil.copyfile(R / name, out / name)
for name in ('before-ledger.exact.jsonl', 'after-observed-ledger.exact.jsonl', 'before-snapshot.json', 'after-snapshot.json'):
    (out / (name + '.gz')).write_bytes(gzip.compress((R / name).read_bytes(), mtime=0))
with tarfile.open(out / 'normal-V-preparations-and-root-application.lossless.tar.gz', 'w:gz') as archive:
    source = Path('.astis/semantic-neutral-20261109/src_cosine_5d8c2a')
    for path in sorted(source.glob('normal-V-preparation*')):
        if path.is_dir():
            archive.add(path, arcname=path.name)
    for path in sorted((source / 'normal-V-runtime').iterdir()):
        if path.resolve() != R.resolve():
            archive.add(path, arcname='retained-runtime-history/' + path.name)
    for name in ('actual-independent-audit-application-v2', 'actual-canonical-evidence-field-application'):
        archive.add(P / name, arcname=name)
    for path in sorted(P.glob('root-source-V-*-authorization.json')):
        archive.add(path, arcname=path.name)
old_raw = C.read_bytes()
old = json.loads(old_raw)
assert old['status'] == 'proved_locally' and old['evidence']['independent_verification'] == ''
(out / 'frontier-before-source-V-projection.raw.json.gz').write_bytes(gzip.compress(old_raw, mtime=0))
cell = json.loads(old_raw)
cell['status'] = 'independently_verified'
cell['evidence']['source_phase_history'] = {
    'pre_source_V_frontier_archive': str(out / 'frontier-before-source-V-projection.raw.json.gz'),
    'raw_sha256': sha(old_raw),
    'scope': 'Preserve all prior proof, input-exposure HOLD, source-review pending and conceptual-candidate phase history.'
}
cell['evidence']['independent_verification'] = {
    'verifier_id': event['worker_id'], 'verified_commit': receipt['checked_commit'],
    'actual_receipt': str(out / 'VERIFIED-actual-receipt.json'), 'receipt_sha256': sha(receipt_raw),
    'actual_append': str(out / 'actual-append-observed.exact.jsonl'), 'append_sha256': sha(append),
    'scope': 'Original independent fresh Lean/kernel/source/whole-module/static authored-reader review only; no aggregate or runtime acceptance.'
}
boundary = ('The original independent reviewer accepted the unchanged sealed full C7 scalar identity, '
            'absolute summability, fixed-kappa uniformity and actual private finite-grid interchange, '
            'and issued the observed normal source V at mathematical candidate37645. The earlier '
            'input-exposure HOLD remains historical evidence; the successful reviewer was a different '
            'source-first actor. The Poisson correspondence is independently conceptually validated '
            'but not yet model-stabilized and has no Lean implication. Canonical current-main '
            'integration, aggregate/site/graph/runtime desktop/mobile acceptance, remote delivery, '
            'purification/Exposition Seal, C8 Gaussian moments/alias corrections/variance/bias/Krylov, '
            'actual adaptive/seed/history/output laws, oracle/precision/TV/deterministic worst-cap '
            'and explicit expected-cost adapters and both main lower bounds remain open.')
cell['evidence']['execution_boundary'] = boundary
cell['statement_seal']['status'] = 'EXACT_ORIGINAL_SIGNATURES_COMPILED_AND_SOURCE_REVIEWED_AGGREGATE_PENDING'
cell['source_detail_audit']['gap'] = ('Selected C7 scalar identity/absolute/uniform and genuine private finite-grid '
                                     'interchange have independent source/whole-module/fresh-Lean acceptance. '
                                     'Gaussian expectation identification, grid alias closed moments and later '
                                     'Lemma4.5 estimates remain separate; aggregate/runtime/remote/purification pending.')
cell['source_detail_audit']['fidelity_boundary'] = boundary
cell['source_proof_coverage']['current_compiled_scope']['source_VERIFIED'] = True
cell['source_proof_coverage']['independent_implementation_review'] = {
    'reviewer': event['worker_id'], 'checked_commit': receipt['checked_commit'],
    'report': audit['source_review']['evidence'], 'review_run_sha256': audit['source_review']['review_run_sha256'],
    'actual_source_V_append_sha256': sha(append)
}
new_raw = dump(cell)
C.write_bytes(new_raw)
projection = {'actor': '/root', 'action': 'mechanical-projection-of-existing-independent-source-V-only',
              'before_sha256': sha(old_raw), 'after_sha256': sha(new_raw),
              'actual_source_V_append_sha256': sha(append), 'normal_API_calls': 0,
              'new_source_verdict': False, 'owner_and_all_other_frontiers_untouched': True}
(out / 'frontier-projection.json').write_bytes(dump(projection))
assert Path('runs/substantive_advances.jsonl').read_bytes() == after
print(json.dumps(projection))
