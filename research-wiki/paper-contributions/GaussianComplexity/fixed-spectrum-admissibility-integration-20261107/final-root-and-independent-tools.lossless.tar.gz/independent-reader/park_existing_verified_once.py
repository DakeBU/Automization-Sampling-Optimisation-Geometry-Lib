"""Exactly one explicitly authorized normal existing-V parking; no retry after guard."""
from pathlib import Path
import json,hashlib,gzip,datetime,subprocess,sys,contextlib,io,time,traceback,os
sys.dont_write_bytecode=True
R=Path('/Users/zhouhuanjian/ASTIS-GC');sys.path.insert(0,str(R/'tools'))
import astis_advance as adv,astis_publication as pub,astis_site as site
B=R/'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-admissibility-integration-20261107'
OWN=B/'independent-integration-reader-review';O=OWN/'normal-release'
SOURCE=R/'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-admissibility-semantic-evidence'
CORE='6483deccec5b721527d9102b7a57102c0205149d';DIGEST='a800967790651d635b025d7d6bdb8ca112f5e2a5ebdb9a50252789cd762f0e62'
ADV='ASTIS-SA-20261107-GaussianComplexityFixedSpectrumAdmissibility';ACTOR='/root/admiss_integration_reader';PROOF='huanjian_gc_20261107_fixed_spectrum_admissibility';VERIFIER='/root/reader_742806';INTEGRATOR='huanjian_gc_20261107_fixed_spectrum_admissibility_integration'
DECL='AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumAdmissibility.actual_precision_admissible';BINDING='e4e245c817d124b16e93b4f999df81132f1e50a9e38535903cb5c036417c0e94'
AUTH=B/'normal-existing-V-release-authorization.json';AUDIT=R/'research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-admissibility.json';CELL=R/'research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-admissibility.json';LEDGER=R/'runs/substantive_advances.jsonl';DISC=R/'runs/substantive_discoveries.jsonl'
sha=lambda b:hashlib.sha256(b).hexdigest()
canon=lambda x:json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
def cmd(*a):return subprocess.check_output(a,cwd=R)
def head():return cmd('git','rev-parse','HEAD').decode().strip()
def put(p,x):assert not p.exists(),str(p);p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def desc(p):return {'path':str(p.relative_to(R)),'raw_sha256':sha(p.read_bytes())}
def archive(name,raw):
 p=O/name;assert not p.exists(),str(p);p.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(p.read_bytes())==raw
 return {'path':str(p.relative_to(R)),'raw_sha256':sha(raw),'gzip_sha256':sha(p.read_bytes()),'raw_bytes':len(raw)}
def unpack(row):
 raw=(R/row['path']).read_bytes();assert sha(raw)==row['gzip_sha256'];data=gzip.decompress(raw);assert sha(data)==row['raw_sha256'];return data
def folder_hashes(p,exclude=None):return {str(q.relative_to(R)):sha(q.read_bytes()) for q in sorted(p.rglob('*')) if q.is_file() and (exclude is None or not q.is_relative_to(exclude))}
assert not O.exists(),'Persisted release directory already exists: STOP, do not retry automatically.'
assert sha(AUTH.read_bytes())=='439af1e90ee939ac3bbaeedf1bcb0de1976e1b8aef0d7bfe8846ce9a38af3035'
auth=json.loads(AUTH.read_bytes());assert auth['authorized_by']=='/root' and auth['accepted_immutable_core']==CORE and auth['source_verifier_to_preserve']==VERIFIER and auth['proof_owner_to_preserve']==PROOF
accept=OWN/'actual-local-integration-acceptance.json';assert sha(accept.read_bytes())==auth['independent_acceptance_sha256']=='710e350d2d72112b252084a09c8c2bca6cdb1e9bacbb94bca8ed37791f873bdf';assert json.loads(accept.read_bytes())['state']=='LOCAL_INTEGRATION_ACCEPTED'
assert sha((OWN/'browser-evidence-retention-and-root-caveat.json').read_bytes())==auth['independent_archive_and_caveat_receipt_sha256']=='4e8814ed475dc720b233de6c164d09bbd26d33e80c5dd56257bf083ef6b9187c'
assert head()==CORE and site.source_digest()==DIGEST
before=LEDGER.read_bytes();discovery=DISC.read_bytes();assert sha(before)==auth['ledger_before_sha256']=='4249562bddba8549eb26758affcfe6ad4e5c9255df2f041601370698ce66dd35' and before.endswith(b'\n')
assert sha(discovery)==auth['discovery_ledger_sha256']=='6a5a1f0ba4225e15ec2e5826e2774090820185479214eb024caa397f3bf339e6'
states=adv.current_advances();assert states[ADV]['state']=='STABILIZING' and states[ADV]['owner_id']==PROOF and states[ADV]['latest_evidence']['integration_owner']==INTEGRATOR
assert [k for k,v in states.items() if v['state']=='STABILIZING']==[ADV]
foreign={k:v for k,v in states.items() if k!=ADV};assert len(foreign)==281
original=[line for line in before.splitlines(keepends=True) if sha(line)==auth['source_V_append_to_preserve']];assert len(original)==1
source_event=json.loads(original[0]);se=source_event['evidence'];assert source_event['worker_id']==VERIFIER and source_event['from_state']=='PROVED_LOCAL' and source_event['to_state']=='VERIFIED' and se['verified_commit']=='83fec39dfa6202cdf9bc687affb10aafbc216ab8'
assert sha(AUDIT.read_bytes())=='02a2529fc9d4d50afc09e6d36cfb11f61bf37cb93988f1c072ab789dc7d01356' and json.loads(AUDIT.read_bytes())['source_review']['reviewer']==VERIFIER
plan=json.loads((OWN/'proposal/proposal-report.json').read_bytes());assert sha((OWN/'proposal/proposal-report.json').read_bytes())=='4aa865058b3c49a415e8e6d47c78da4885d90f5871d035d1cc79b0a46fbeb537'
for row in plan['shared_paths']:assert sha((R/row['path']).read_bytes())==row['planned_after_sha256']
for p,h in plan['source_Test_lesson_publication_pins'].items():assert sha((R/p).read_bytes())==h
for p,h in plan['unchanged_models'].items():assert sha((R/p).read_bytes())==h
protected=json.loads(unpack(plan['protected_foreign_content']))
for p,row in protected.items():
 q=R/p;raw=os.fsencode(os.readlink(q)) if q.is_symlink() else q.read_bytes();assert sha(raw)==row['sha256'],p
for path,row in plan['ledger_protection'].items():
 raw=(R/path).read_bytes();assert raw.startswith(unpack(row['raw_prefix']))
 expected=json.loads(unpack(row['foreign_projection']));now=states if 'advances' in path else adv.current_discoveries();assert all(now[k]==v for k,v in expected.items())
frontiers={str(p.relative_to(R)):sha(p.read_bytes()) for p in (R/'research-wiki/frontier-cells').glob('*.json')};assert len(frontiers)==441
oldforeignfrontiers=json.loads(unpack(plan['foreign_frontiers']));assert len(oldforeignfrontiers)==440 and all(frontiers[k]==v for k,v in oldforeignfrontiers.items())
source_hashes=folder_hashes(SOURCE);old_own=folder_hashes(OWN,exclude=O)
item=next(i for i in pub.load() if i['id']=='huanjian-fixed-spectrum-admissibility');assert pub.binding_digest(item,item['bindings'][0])==BINDING
gate=R/'.astis/site-lean-gate.json';metadata=R/'_site/data/build-metadata.json';g,m=json.loads(gate.read_bytes()),json.loads(metadata.read_bytes());assert g['commit']==m['git']['commit']==CORE and g['source_digest']==m['source_digest']==DIGEST and g['passed'] and m['gate']['passed'] and m['gate']['current']
fixed={str(p.relative_to(R)):sha(p.read_bytes()) for p in [AUDIT,CELL,AUTH,gate,metadata,accept,R/'research-wiki/paper-contributions/GaussianComplexity/README.md']}
O.mkdir(exist_ok=False)
request={'advance_id':ADV,'to_state':'VERIFIED','worker_id':ACTOR,'modes':['mechanical-existing-source-verification-parking','release-locally-accepted-integration-lease'],'evidence':{
 'verifier_id':ACTOR,'verified_commit':CORE,'publication_declarations':[DECL],
 'parking_kind':'Mechanical STABILIZING to existing VERIFIED after actual local acceptance; no new source/mathematical verification.',
 'authorization':desc(AUTH),'original_source_verifier_id':VERIFIER,'source_verifier':VERIFIER,'original_source_checked_commit':se['verified_commit'],'original_accepted_audit_first_commit':'96a6da3fe9d7fbe17af5624552a1152743587150','original_accepted_audit_and_V_first_commit':'4c1c45f7cecb6ac2351d328899848766c1683eb8','original_source_V_append_sha256':sha(original[0]),'proving_owner_preserved':PROOF,'released_integration_owner':INTEGRATOR,
 'gate':{'kind':'Reuse actual immutable6483 official9652job gate and exactmatching sourceDigest/site/graph/Chrome36 plus all36independently viewed originals; real schema-v4 publication gate runs through this normal API. No extra build/browser/new source verdict.','passed':True,'actual_gate':desc(gate),'actual_site_metadata':desc(metadata),'actual_local_acceptance':desc(accept),'archive_and_caveat':desc(OWN/'browser-evidence-retention-and-root-caveat.json'),'actual_core_commit':CORE,'source_digest':DIGEST},
 'source_audit':{'kind':'Reuse unchanged genuine original independent sourceV only; mechanical actor is not a replacement source reviewer.','original_verifier':VERIFIER,'original_source_V_append_sha256':sha(original[0]),'original_source_evidence':se['source_audit'],'current_accepted_audit':desc(AUDIT),'publication_binding_sha256':BINDING,'new_source_verdict':False},
 'fake_closure_scan':{'kind':'Reuse actual original independent standard-axiom/fake-closure review and genuine6483 canonical ASTIS gate; no new scan or verdict.','original_verifier':VERIFIER,'original_scan':se['fake_closure_scan'],'actual_root_ASTIS_success_at':CORE,'source_and_Test_bytes_unchanged':True},
 'local_acceptance_scope':'Actual literal cosine-grid I<=A<=kappaI and produced PosDef, genuine same-A Gaussian Test with canonical density reuse, one Registry618 producer and current source/Lean/reader/graph1440/390 acceptance. Empty producer ASTIS parents, same canonical Gaussian consumer declaration only.','truth_boundary':'Local lease release only; no MERGED/PURIFIED/ExpositionSeal/remote/publicreader or wholepaper/wholeGoal completion. C4 basis-independent knownnormalizer/determinant/calculus, moments/Krylov, true adaptive/oracle/precision/TV/deterministic-cap/expectedcost adapters and both main lower bounds remain open.','actual_external_route_boundary':'Own-site module/download and localimmutableGit bytes passed. Both per-page GitHub link-syntax fields null; no external GitHubHTML/linksyntax/HTTP200/publication credited. Original report caveat preserved.','new_source_mathematical_or_semantic_verdict':False,'mechanical_release_actor_not_source_verifier':ACTOR,'other_queue_or_remote_mutation':False}}
put(O/'normal-api-request.json',request)
pre={'core':CORE,'source_digest':DIGEST,'authorization':desc(AUTH),'request':desc(O/'normal-api-request.json'),'ledger_before':archive('advance-ledger.before.raw.jsonl.gz',before),'discovery_before':archive('discovery-ledger.before.raw.jsonl.gz',discovery),'all_foreign_states':archive('foreign-states.before.json.gz',canon(foreign)),'all_frontiers':archive('frontier-hashes.before.json.gz',canon(frontiers)),'all_source_evidence':archive('source-evidence-hashes.before.json.gz',canon(source_hashes)),'earlier_own_reviews':archive('earlier-review-hashes.before.json.gz',canon(old_own)),'fixed_bytes':fixed,'normal_API_calls_so_far':0}
put(O/'preflight.json',pre)
assert LEDGER.read_bytes()==before and DISC.read_bytes()==discovery and head()==CORE
put(O/'attempt-guard.json',{'actor':ACTOR,'advance_id':ADV,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'request':desc(O/'normal-api-request.json'),'allowed_normal_API_invocations':1,'retry_policy':'After this persisted guard never retry automatically, including API rejection or partial append. Preserve evidence and stop.'})
stream=io.StringIO();error=None;started=datetime.datetime.now(datetime.timezone.utc).isoformat();clock=time.monotonic()
with contextlib.redirect_stdout(stream),contextlib.redirect_stderr(stream):
 try:
  adv.transition_advance(ADV,to_state='VERIFIED',worker_id=ACTOR,modes=request['modes'],evidence=request['evidence'])
  print('The single normal transition API returned after its real reviewed publication gate; mechanical existing-V parking only.')
 except Exception:
  error=traceback.format_exc();print(error)
elapsed=time.monotonic()-clock;rawlog=stream.getvalue().encode();(O/'normal-api.stdout.raw').write_bytes(rawlog)
after=LEDGER.read_bytes();prefixok=after.startswith(before);append=after[len(before):] if prefixok else b''
receipt={'actual_API':'tools.astis_advance.transition_advance','actual_API_calls':1,'actual_actor':ACTOR,'started_utc':started,'completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'elapsed_seconds':elapsed,'exit_code':1 if error else 0,'error':error,'head_before':CORE,'head_after':head(),'request':desc(O/'normal-api-request.json'),'stdout':desc(O/'normal-api.stdout.raw'),'stdout_archive':archive('normal-api.stdout.raw.gz',rawlog),'ledger_before_sha256':sha(before),'ledger_after_sha256':sha(after),'exact_prefix_preserved':prefixok,'append_bytes':len(append),'append_sha256':sha(append),'new_source_verdict':False}
put(O/'normal-api-execution.receipt.json',receipt)
if error:print(json.dumps({'state':'NORMAL_API_REJECTED_STOP_NO_RETRY','append_bytes':len(append),'receipt':desc(O/'normal-api-execution.receipt.json')}));sys.exit(1)
try:
 assert prefixok and len(append.splitlines())==1
 event=json.loads(append);assert event['advance_id']==ADV and event['from_state']=='STABILIZING' and event['to_state']=='VERIFIED' and event['worker_id']==ACTOR and event['evidence']==request['evidence']
 now=adv.current_advances();assert now[ADV]['state']=='VERIFIED' and now[ADV]['owner_id']==PROOF and now[ADV]['latest_evidence']['original_source_verifier_id']==VERIFIER and not [k for k,v in now.items() if v['state']=='STABILIZING']
 assert {k:v for k,v in now.items() if k!=ADV}==foreign and DISC.read_bytes()==discovery
 assert folder_hashes(SOURCE)==source_hashes and folder_hashes(OWN,exclude=O)==old_own
 assert {str(p.relative_to(R)):sha(p.read_bytes()) for p in (R/'research-wiki/frontier-cells').glob('*.json')}==frontiers
 assert all(sha((R/p).read_bytes())==h for p,h in fixed.items())
 assert LEDGER.read_bytes()==after and before.count(original[0])==after.count(original[0])==1
 assert head()==CORE and site.source_digest()==DIGEST
 for p,row in protected.items():
  q=R/p;raw=os.fsencode(os.readlink(q)) if q.is_symlink() else q.read_bytes();assert sha(raw)==row['sha256'],p
except Exception:
 put(O/'postcondition-failure.json',{'actual_API_already_returned':True,'error':traceback.format_exc(),'rule':'Do not retry, roll back or reset; retain exact append and stop.'});raise
(O/'advance-ledger.append.raw.jsonl').write_bytes(append)
archive('advance-ledger.after.raw.jsonl.gz',after);archive('advance-ledger.append.raw.jsonl.gz',append);archive('discovery-ledger.after.raw.jsonl.gz',discovery)
protection={'all281_foreign_states_unchanged':True,'all441_frontiers_including_440_foreign_byte_unchanged':True,'all6892_protected_foreign_inputs_unchanged':True,'all_source_evidence_byte_unchanged':len(source_hashes),'all_earlier_own_review_files_byte_unchanged':len(old_own),'canonical_audit_cell_sixsharedpaths_models_and_README_byte_unchanged':True,'old_advance_and_discovery_prefixes_preserved':True,'discovery_ledger_entire_bytes_unchanged':True,'exact_normal_append_events':1,'append_sha256':sha(append),'ledger_after_sha256':sha(after),'proof_owner_preserved':PROOF,'original_source_verifier_preserved':VERIFIER,'original_source_V_append_still_unique_and_unchanged':sha(original[0]),'actual_final_state':'VERIFIED','STABILIZING_after':[]}
put(O/'protection.json',protection)
summary={'actor':ACTOR,'operation':'Exactly one explicitly authorized normal STABILIZING to existing VERIFIED parking/release after actual local acceptance','core':CORE,'authorization':desc(AUTH),'actual_normal_API_receipt':desc(O/'normal-api-execution.receipt.json'),'protection':desc(O/'protection.json'),'actual_unique_append_sha256':sha(append),'ledger_after_sha256':sha(after),'final_state':'VERIFIED','proof_owner':PROOF,'original_source_verifier':VERIFIER,'normal_STAB_after':[],'new_source_verifications':0,'new_build_browser_remote_merge_or_purification_actions':0,'frontier_metadata_not_projected_here':True,'README_unchanged_here':True,'remote_publication_purification_ExpositionSeal_both_mainbounds_wholeGoal_complete':False,'writes_stopped_after_summary':True}
put(O/'release-summary.json',summary);archive('executed-normal-release-driver.py.gz',Path(__file__).read_bytes())
print(json.dumps({'final_state':'VERIFIED','normal_API_calls':1,'STAB_after':[],'append_sha256':sha(append),'ledger_after_sha256':sha(after),'receipt_sha256':sha((O/'normal-api-execution.receipt.json').read_bytes()),'protection_sha256':sha((O/'protection.json').read_bytes()),'summary_sha256':sha((O/'release-summary.json').read_bytes()),'new_source_verifications':0,'writes_stopped':True}))
