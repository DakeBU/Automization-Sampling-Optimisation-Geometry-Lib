import AutoSamplingTheory.ExampleCases.ProximalBPS.ActualEndpointTimeReversal
import Mathlib.Analysis.InnerProductSpace.Calculus
import Mathlib.MeasureTheory.Integral.IntervalIntegral.FundThmCalculus

namespace PBPSGibbsSurvivalWork98
open MeasureTheory InnerProductSpace
open scoped ContDiff NNReal ENNReal Classical
noncomputable section
set_option autoImplicit false

theorem actual_arc_energy
    {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℝ E]
    [FiniteDimensional ℝ E] [MeasurableSpace E] [BorelSpace E]
    {V : E → ℝ} {α β : ℝ≥0} {η : ℝ}
    (hα : 0 < (α : ℝ)) (hαβ : α ≤ β) (hV : ContDiff ℝ 2 V)
    (hH : ∀ x v : E,
      (α : ℝ) * ‖v‖ ^ 2 ≤ (fderiv ℝ (fderiv ℝ V) x v) v ∧
      (fderiv ℝ (fderiv ℝ V) x v) v ≤ (β : ℝ) * ‖v‖ ^ 2)
    (hη : 0 < η) (hβη : (β : ℝ) * η ≤ 1) :
    let c : E → E → E := fun y r => y - η • gradient V r
    let Φ : E → E → ℝ → (E × E) → (E × E) := fun y r t z =>
      (c y r + Real.cos t • (z.1 - c y r) +
          (Real.sqrt η * Real.sin t) • z.2,
       (-Real.sin t / Real.sqrt η) • (z.1 - c y r) + Real.cos t • z.2)
    let R : E × E → E × E := fun z => (z.1, -z.2)
    let rate : E → E × E → ℝ := fun r z =>
      Real.sqrt η * max 0 (inner ℝ z.2 (gradient V z.1 - gradient V r))
    let U : E → E × E → ℝ := fun y z =>
      V z.1 + ‖z.1 - y‖ ^ 2 / (2 * η) + ‖z.2‖ ^ 2 / 2
    ∀ y r : E, ∀ z : E × E,
      (∀ s : ℝ, HasDerivAt (fun t => U y (Φ y r t z))
        (rate r (Φ y r s z) - rate r (R (Φ y r s z))) s) ∧
      (∀ a b : ℝ,
        IntervalIntegrable (fun s => rate r (Φ y r s z)) volume a b ∧
        IntervalIntegrable (fun s => rate r (R (Φ y r s z))) volume a b ∧
        U y (Φ y r b z) - U y (Φ y r a z) =
          (∫ s in a..b, rate r (Φ y r s z)) -
          (∫ s in a..b, rate r (R (Φ y r s z)))) := by
  intro c Φ R rate U y r z
  letI : CompleteSpace E := FiniteDimensional.complete ℝ E
  have hf := AutoSamplingTheory.ExampleCases.ProximalBPS.ActualHarmonicFlow.actual_harmonic_flow_laws
    hα hαβ hV hH hη hβη
  rcases hf with ⟨hc, _, _, _, _, ho, _⟩
  have hb := AutoSamplingTheory.ExampleCases.ProximalBPS.ActualBounceRate.actual_bounce_rate_energy_laws
    hα hαβ hV hH hη hβη
  have hrate : Continuous (fun q : E × (E × E) => rate q.1 q.2) := hb.2.1
  have hphi : Continuous (fun t => Φ y r t z) :=
    hc.comp ((continuous_const (y := (y,r))).prodMk
      (continuous_id.prodMk (continuous_const (y := z))))
  have hp : Continuous (fun t => rate r (Φ y r t z)) :=
    hrate.comp (continuous_const.prodMk hphi)
  have hm : Continuous (fun t => rate r (R (Φ y r t z))) :=
    hrate.comp (continuous_const.prodMk (hphi.fst.prodMk hphi.snd.neg))
  have hdiff (q : E × E) : rate r q - rate r (R q) =
      Real.sqrt η * inner ℝ q.2 (gradient V q.1 - gradient V r) := by
    dsimp [rate, R]
    rw [inner_neg_left]
    by_cases h : 0 ≤ inner ℝ q.2 (gradient V q.1 - gradient V r)
    · rw [max_eq_right h, max_eq_left (neg_nonpos.mpr h)]
      ring
    · rw [max_eq_left (le_of_not_ge h), max_eq_right (neg_nonneg.mpr (le_of_not_ge h))]
      ring
  have hd (s : ℝ) : HasDerivAt (fun t => U y (Φ y r t z))
      (rate r (Φ y r s z) - rate r (R (Φ y r s z))) s := by
    obtain ⟨hx, hv⟩ := ho y r s z
    have hx' : HasDerivAt (fun t => (Φ y r t z).1) (Real.sqrt η • (Φ y r s z).2) s := hx
    have hv' : HasDerivAt (fun t => (Φ y r t z).2)
        (-(Real.sqrt η)⁻¹ • ((Φ y r s z).1 - y) - Real.sqrt η • gradient V r) s := hv
    have hVd := ((hV.differentiable (by norm_num)).differentiableAt.hasGradientAt.hasFDerivAt).comp_hasDerivAt s hx'
    have hd0 := (hVd.add ((hx'.sub_const y).norm_sq.div_const (2 * η))).add
      (hv'.norm_sq.div_const 2)
    apply hd0.congr_deriv
    rw [hdiff]
    simp only [InnerProductSpace.toDual_apply_apply, real_inner_smul_right, real_inner_smul_left,
      inner_sub_right, inner_sub_left, real_inner_comm]
    have hs : (Real.sqrt η) ^ 2 = η := Real.sq_sqrt hη.le
    have hs0 : Real.sqrt η ≠ 0 := ne_of_gt (Real.sqrt_pos.mpr hη)
    field_simp [hs0, hη.ne']
    simp only [hs]
    ring
  refine ⟨hd, ?_⟩
  intro a b
  have hi : IntervalIntegrable (fun s => rate r (Φ y r s z)) volume a b := hp.intervalIntegrable a b
  have hj : IntervalIntegrable (fun s => rate r (R (Φ y r s z))) volume a b := hm.intervalIntegrable a b
  refine ⟨hi, hj, ?_⟩
  rw [← intervalIntegral.integral_sub hi hj]
  exact (intervalIntegral.integral_eq_sub_of_hasDerivAt (fun s _ => hd s) (hi.sub hj)).symm

end
end PBPSGibbsSurvivalWork98
#print axioms PBPSGibbsSurvivalWork98.actual_arc_energy
