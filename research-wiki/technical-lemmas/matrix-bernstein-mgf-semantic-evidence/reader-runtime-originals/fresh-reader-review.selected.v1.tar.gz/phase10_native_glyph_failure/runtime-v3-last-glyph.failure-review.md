# Independent actual v3 failure review — frozen before v4 diff

Reviewer: mgf_fresh_source_5b7e. This report reads ROOT's actual run originals, the previously frozen v3 measurement implementation, frozen P/T sources, unchanged reader-v2 source HTML, and 20 selected real PNGs. No Chrome, build, API, production/fixture edit, or repaired measurement execution was performed by this reviewer. The v4 proposal has not been opened for this review.

**Disposition: actual v3 candidate remains FAIL; whole-candidate runtime acceptance withheld.** This is a confirmed measurement-input error in the final-glyph check, not a mathematical counterexample and not an instruction to replace eight false flags with true.

## Actual run and preserved result

ROOT session 80705, exit 1, elapsed 67.820364 seconds; exception=null. The actual report contains 343 checks, 335 true, eight false, 86 original PNGs, no JavaScript errors, and no blocked external request. The process receipt records real separate OS stdout/stderr, exact wrapper/contract hashes, Chrome 157.0.8103.51, and unchanged ROOT HEAD. All 106 result/download/image/process files are copied byte-for-byte under originals/ and enumerated in actual-originals-manifest.json.

The eight actual failures are precisely the Cartesian product of desktop/mobile and P/T, each with two predicates: last-source-glyph-actually-visible-below-header and full-source-glyph-horizontal-reach. Their metrics have lastGlyphWidth=0, height 20 (desktop) or 19 (mobile), lineVerticallyVisible=true, and scroll=max. Because glyphVerticallyVisible requires positive width, both predicates correctly evaluate false for the selected Range. There is no missing-anchor exception in v3. The remaining recorded checks, including all six per-step source/copy/download/navigation actions in both viewports, full P/T source equality and line counts, source-anchor placement, local layouts, formula/table scrolling, source-index and graph workflows, are actual true flags. They are useful bounded evidence but do not turn this FAIL run into a qualified complete candidate.

## Independent cause, with original-source evidence

The frozen script selects longest by exact.splitlines(), then obtains that source span's first text child and sets Range [text.length-1,text.length). Reader source generation deliberately retains each original line ending inside its span.

P's selected line is L107, 121 characters before the newline. Its original suffix is bernstein_exponential_quadratic_bound followed by LF. The actual candidate HTML span L107 decodes exactly to that same raw line, contains no nested markup, ends U+000A, and has preceding character d (U+0064). T's selected line is L94, 129 characters before the newline; its suffix is actual_source_truncated_matrix_norm_bounds followed by LF, preceding character s (U+0073). Thus the actual v3 Range selects one UTF-16 unit consisting only of LF in all four viewport/module cases. The preserved zero-width measurements are consistent with selecting this line ending. This conclusion comes from frozen code and exact source/HTML, rather than an inference that Lean proved visibility.

The expected actual final visible characters are P d at UTF-16 [120,121) and T s at [128,129). Those characters and surrounding suffixes are visible in the actual terminal horizontal segments. A separate repaired actual measurement must still establish positive glyph width, positive height, vertical placement below the header, horizontal reach, and maximum scroll; screenshots alone do not generate replacement flags.

## Bounded visual findings

Twenty personally viewed files and their hashes are listed in viewed-images-and-observations.json; all 86 original PNGs are retained. The actual P/T terminal segments display the final letters and horizontally reachable suffixes. Source-anchor frames show real theorem declarations below the mobile header. Selected desktop/mobile steps show adjacent source/copy/module-download controls and readable text; the mobile formula7 right-end shows the actual second-moment MGF and s>0. Source index wraps full identifiers and identifies T as private. Actual graph inspectors wrap full identifiers/source metadata; default-fit graph text is still tiny, SVG labels retain ellipses, and mobile zoom can clip wide cards. The supported graph claim remains zoom-plus-full-detail inspection, not complete readable SVG labels at default fit. This limited review does not assert all 86 PNGs were personally viewed.

## Next repair boundary

A minimal measurement repair may select the last non-whitespace Unicode code point of the same first text child, translating its start/end to UTF-16 Range offsets and recording the actual selected glyph. It must preserve all positive-width/height, line visibility, header, viewport, horizontal containment, overflow, and maximum-scroll predicates; preserve the 42 literal check expressions and unchanged extensions; and leave reader-v2, all frozen source/input bytes, mathematical modules, formulas, and old run originals untouched. Such a repair requires its own independent static review and a new real ROOT execution. This report does not approve any uninspected v4 diff.

The earlier source/whole-module/seven-slot results and their restrictions remain frozen: normalized real finite nonempty single-matrix MGF, source-standing regularity, original unconditional Gaussian law/cutoff/mean, all s>0 including q=0, natural negative +cos handled by a norm bound. Tropp is independent matching background; Gaussian specialization is authored, not a printed citation/theorem, sum-tail, global ±cos statement, main lower bound, or whole-site acceptance. No proof VERIFIED transition is authorized or performed.
