from pathlib import Path
import subprocess
import json
from hashlib import sha256

R=Path('/Users/zhouhuanjian/ASTIS-GC')
O=R/'.astis/semantic-neutral-20261110/cg_sg_1d7a46'
L=O/'phase1/logs'
records=[]

def record(label, argv, stdin=None, original_chunks=None):
    result=subprocess.run(argv,input=stdin,cwd=R,capture_output=True)
    output=L/(label+'.stdout')
    error=L/(label+'.stderr')
    output.write_bytes(result.stdout)
    error.write_bytes(result.stderr)
    if stdin is not None:
        (L/(label+'.stdin.py')).write_bytes(stdin)
    rec={'label':label,'cwd':str(R),'argv':argv,
         'stdin_file':label+'.stdin.py' if stdin is not None else None,
         'exit_code':result.returncode,'stdout_file':output.name,
         'stdout_bytes':len(result.stdout),'stdout_sha256':sha256(result.stdout).hexdigest(),
         'stderr_file':error.name,'stderr_bytes':len(result.stderr),
         'stderr_sha256':sha256(result.stderr).hexdigest(),
         'original_read_chunks':original_chunks or [],
         'capture_note':'This is a real later replay read to preserve complete stdout/stderr. Original tool-output truncation is separately disclosed; no original bytes are pretended recovered from a clipped transcript.'}
    records.append(rec)
    assert result.returncode==0, rec

record('read_pwd',['pwd'],original_chunks=['e1f564'])
for label,path,ids in [
 ('read_agents','AGENTS.md',['4175c6','1757c1','6491a3']),
 ('read_proof_protocol','docs/proof-digestion-protocol.md',['59aa6e','447964']),
 ('read_publication_protocol','docs/theorem-publication-protocol.md',['6b3861']),
 ('read_memory_protocol','docs/evidence-routed-memory-protocol.md',['3361dd']),
 ('read_source_audit_skill','.agents/skills/astis-source-dependency-audit/SKILL.md',['b474c5'])]:
    record(label,['cat',path],original_chunks=ids)
record('read_wc',['wc','-l','AGENTS.md','docs/proof-digestion-protocol.md','docs/theorem-publication-protocol.md','docs/evidence-routed-memory-protocol.md','.agents/skills/astis-source-dependency-audit/SKILL.md'],original_chunks=['d05c01'])

prelude="""from pathlib import Path
from hashlib import sha256
from bs4 import BeautifulSoup
p=Path('.astis/huanjian-resume-20261103/2610.20492v1.html')
b=p.read_bytes()
s=BeautifulSoup(b,'html.parser')
"""
record('read_raw_anchors',['/opt/anaconda3/bin/python','-'],(prelude+"""print('raw',len(b),sha256(b).hexdigest())
for ident in ['S4.Thmtheorem4','A3.SS2','A3.Thmtheorem5']:
 e=s.find(id=ident)
 print('\\nANCHOR',ident,'FOUND',e is not None)
 if e:
  print('TAG',e.name,'class',e.get('class'),'ancestors',[(a.name,a.get('id')) for a in list(e.parents)[:4]])
  print(e.get_text(' ',strip=True))
""").encode(),['95af0a'])
record('read_structure_all_ids',['/opt/anaconda3/bin/python','-'],(prelude+"""for anchor in ['S4','S4.SS2','S4.SS2.SSS0.Px2','A3.SS2']:
 e=s.find(id=anchor)
 print('\\nSTRUCTURE',anchor)
 for c in e.children:
  if getattr(c,'name',None):
   print(c.name,c.get('id'),','.join(c.get('class',[])),len(str(c)),c.get_text(' ',strip=True)[:200])
print('\\nC2 IDS')
e=s.find(id='A3.SS2')
for c in e.find_all(id=True):
 print(c.name,c['id'],','.join(c.get('class',[])),len(str(c)), c.get('alttext','') or c.get_text(' ',strip=True)[:110])
""").encode(),['b85fce'])
record('read_standing_context',['/opt/anaconda3/bin/python','-'],(prelude+"""for ident in ['S4.SS1','S4.SS2.SSS0.Px1','S4.SS2.SSS0.Px2']:
 e=s.find(id=ident)
 print('\\nANCHOR',ident)
 print(e.get_text(' ',strip=True))
 print('PARAGRAPH_AND_DISPLAY_IDS',[(c.name,c.get('id')) for c in e.find_all(id=True) if c.name in ['div','p','table','tbody']])
""").encode(),['353a78'])
record('read_citations_and_defs',['/opt/anaconda3/bin/python','-'],(prelude+"""print('TITLE',s.title.get_text(' ',strip=True))
for m in s.find_all('meta'):
 if m.get('name','') in ['citation_title','citation_author','citation_date','citation_arxiv_id']:
  print(m)
for ident in ['A3.SS2.p8','A3.SS2.p9','S4.SS1.p1','S4.E11','S4.SS2.SSS0.Px1.p2','S4.Ex10','S4.Ex12']:
 e=s.find(id=ident)
 print('\\nANCHOR',ident, 'FOUND',e is not None)
 if e:
  print(e.get_text(' ',strip=True))
  print('MATH',[(m.get('id'),m.get('alttext')) for m in e.find_all('math')])
print('\\nCITATIONS')
for ident in ['S4.SS1','S4.SS2.SSS0.Px1','S4.SS2.SSS0.Px2','A3.SS2']:
 e=s.find(id=ident)
 print(ident,[(a.get('href'),a.get_text(' ',strip=True)) for a in e.find_all('a')])
""").encode(),['23cc3f'])
record('read_authors_bib_childspans',['/opt/anaconda3/bin/python','-'],(prelude+"""print('AUTHORS',[(x.get('class'),x.get_text(' ',strip=True)) for x in s.select('.ltx_authors')])
e=s.find(id='bib.bib3'); print('REFERENCE bib.bib3', e.get_text(' ',strip=True) if e else 'MISSING')
for ident in ['A3.SS2.p3','A3.SS2.p4','A3.SS2.p5','A3.SS2.p6','A3.SS2.p7','A3.SS2.p8']:
 e=s.find(id=ident)
 print(ident,'CHILDREN',[(x.name,x.get('id')) for x in e.children if getattr(x,'name',None)])
""").encode(),['ad57fd'])
record('read_selected_mathids',['/opt/anaconda3/bin/python','-'],("""import json
from pathlib import Path
p=Path('.astis/semantic-neutral-20261110/cg_sg_1d7a46/phase1/source_index.json')
x=json.loads(p.read_text())
for item in x['items']:
 if item['tag']=='math' and (item['root']!='A3.SS2' or item['id'].startswith(('A3.SS2.p1.','A3.SS2.p2.','A3.SS2.p3.','A3.SS2.p4.','A3.SS2.p5.','A3.SS2.p6.','A3.SS2.p7.','A3.SS2.p8.','A3.Ex85.','A3.Ex86.','A3.Ex87.','A3.Ex88.','A3.Ex89.','A3.Ex90.','A3.Ex91.','A3.Ex92.','A3.Ex93.','A3.Ex94.','A3.Ex95.','A3.Ex96.','A3.Ex97.','A3.Ex98.','A3.Ex99.','A3.Ex100.','A3.Ex101.','A3.Ex102.'))):
  print(item['id'],item['alttext_exact'])
""").encode(),['2dfae5'])

(L/'read_commands.json').write_text(json.dumps(records,ensure_ascii=False,indent=2)+'\n')
report={'status':'READ_STDOUT_CAPTURED','reads':len(records),'all_exit_codes_zero':True,
 'outputs_truncated_on_disk':False,'model_tool_return':'bounded metadata only'}
(L/'capture_reads_output.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(report,ensure_ascii=False))
