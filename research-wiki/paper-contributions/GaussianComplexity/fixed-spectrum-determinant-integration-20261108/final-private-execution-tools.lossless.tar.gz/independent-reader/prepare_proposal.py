"""Freeze a conditional six-path proposal only; never apply shared bytes or issue V."""
from pathlib import Path
import datetime, difflib, gzip, hashlib, json, os, subprocess, sys
sys.dont_write_bytecode = True
R = Path('/Users/zhouhuanjian/ASTIS-GC')
S = R / '.astis/huanjian-gc-fixed-spectrum-determinant-integration-20261108/independent-reader'
O = R / 'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-determinant-integration-20261108/independent-integration-reader-review/proposal'
ADV = 'ASTIS-SA-20261108-GaussianComplexityFixedSpectrumDeterminant'
CANDIDATE = 'a0310046dc10c06ce9f61959094322fb9016be1e'
DECL = 'AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumDeterminant.actual_precision_det'
PARENT = 'AutoSamplingTheory.TechnicalLemmas.Measure.DisplacementJacobianEntropy.det_conjStarAlgAut_eq'
GPD = 'AutoSamplingTheory.TechnicalLemmas.Measure.GaussianPrecisionDensity.multivariateGaussian_eq_withDensity_of_posDef'
ADMISS = 'AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumAdmissibility.actual_precision_admissible'
BINDING = 'c70bb9b23e335acf768bb889f8229fcdf2a7af160e10fa89779d00dcba58374b'
PATHS = ['AutoSamplingTheory.lean', 'Tests.lean', 'Tests/Basic.lean', 'AutoSamplingTheory/TechnicalLemmas/Registry.lean', 'website/content/samplewiki_companion_frontiers.json', 'research-wiki/sampling-sde-library/cards/AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumDeterminant.md']
PINS = {
 'AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumDeterminant.lean': 'adcf336b0774dbbd5f8976b25e50c8723d14a6dab2582faee6db4d365afac9dc',
 'Tests/GaussianComplexityFixedSpectrumDeterminant.lean': '2be2c84620313264b486e20ba84904403e2ee54706bcfa2b36f929d896d9e1ec',
 'website/content/declaration_lessons/huanjian-fixed-spectrum-determinant.json': '4a3a9a3de61c2a4ffe4a8be518dcfb206273df337d7eedbd30c931c832131b95',
 'website/content/publications/huanjian-fixed-spectrum-determinant.json': 'b0ac72466ffe28e2b890400514b67236e02389e6a25e9f3d58e14f1cf5910ece',
}
MODELS = {'website/content/graph_memory_index.json': '019497faee75c5844ff3d3a08b0ce61c25256918cc29c45b2de5bbaca490b607', 'website/content/functor_hypergraph.json': '94b56f87136ca97820893e5531d16d36334d44bc6b9e41981d39aa700f8fe782'}
sha = lambda b: hashlib.sha256(b).hexdigest()
canon = lambda x: json.dumps(x, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()
def dump(x): return (json.dumps(x, ensure_ascii=False, indent=2) + '\n').encode()
def cmd(*args): return subprocess.check_output(args, cwd=R)
def put(path, value):
 assert not path.exists(), str(path)
 path.write_bytes(dump(value))
def archive(name, raw):
 path = O / name
 assert not path.exists(), str(path)
 path.write_bytes(gzip.compress(raw, mtime=0))
 assert gzip.decompress(path.read_bytes()) == raw
 return {'path': str(path.relative_to(R)), 'raw_sha256': sha(raw), 'gzip_sha256': sha(path.read_bytes()), 'raw_bytes': len(raw)}
def replace_once(raw, old, new):
 a = old.encode(); assert raw.count(a) == 1, old
 return raw.replace(a, new.encode(), 1)
def differences(a, b, p=''):
 assert type(a) is type(b)
 if isinstance(a, dict):
  assert a.keys() == b.keys()
  return sum((differences(a[k], b[k], p + '/' + str(k)) for k in a), [])
 if isinstance(a, list):
  assert len(a) == len(b)
  return sum((differences(x, y, p + '/' + str(i)) for i, (x, y) in enumerate(zip(a, b))), [])
 return [] if a == b else [p]
head = cmd('git', 'rev-parse', 'HEAD').decode().strip()
cmd('git', 'merge-base', '--is-ancestor', CANDIDATE, head)
for path, digest in {**PINS, **MODELS}.items(): assert sha((R/path).read_bytes()) == digest, path
for path in list(PINS)[:2]: assert cmd('git', 'show', CANDIDATE + ':' + path) == (R/path).read_bytes()
sys.path.insert(0, str(R/'tools'))
import astis_advance as adv
import astis_publication as pub
item = next(x for x in pub.load() if x['id'] == 'huanjian-fixed-spectrum-determinant')
assert pub.binding_digest(item, item['bindings'][0]) == BINDING
lesson = json.loads((R/list(PINS)[2]).read_bytes())['units'][0]
assert lesson['astis_dependencies'] == [PARENT] and lesson['reading_layout'] == 'progressive' and len(lesson['steps']) == 5
capsule = json.loads((R/'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-determinant-semantic-evidence/local-proof-capsule.json').read_bytes())
assert capsule['actual_ASTIS_producer_parents'] == [PARENT]
assert set(capsule['actual_ASTIS_consumer_parents']) == {DECL, ADMISS, GPD}
before = {p: (R/p).read_bytes() if (R/p).exists() else None for p in PATHS}
assert before[PATHS[-1]] is None
for path in PATHS[:-1]: assert before[path] == cmd('git', 'show', head + ':' + path), path
plans = {}
plans[PATHS[0]] = replace_once(before[PATHS[0]], 'import AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumAdmissibility\n', 'import AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumAdmissibility\nimport AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumDeterminant\n')
plans[PATHS[1]] = replace_once(before[PATHS[1]], 'import Tests.GaussianComplexityFixedSpectrumAdmissibility\n', 'import Tests.GaussianComplexityFixedSpectrumAdmissibility\nimport Tests.GaussianComplexityFixedSpectrumDeterminant\n')
actual_count = before[PATHS[3]].count(b'status := LemmaMemoryStatus.formalizedLocal')
assert actual_count == 618
plans[PATHS[2]] = replace_once(before[PATHS[2]], 'formalizedTechnicalLemmaCount = 618', 'formalizedTechnicalLemmaCount = 619')
reg = replace_once(before[PATHS[3]], 'import AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumAdmissibility\n', 'import AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumAdmissibility\nimport AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumDeterminant\n')
entry = '''  {
    key := "gaussian-complexity.fixed-spectrum-determinant",
    localDecl := "AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumDeterminant.actual_precision_det",
    upstreamDecl := "arXiv2610.20492v1 Eq11 and AppendixC.4 actual cosine-grid precision determinant product",
    upstreamFile := "S4.E11 literal precision; A3.SS4 determinant equality component of Ex160",
    status := LemmaMemoryStatus.formalizedLocal,
    tags := ["GaussianComplexity", "fixed-spectrum", "actual-precision", "determinant", "canonical-reuse"],
    saldUse := "The actual same-A inverse-precision Gaussian density Test consumes this determinant product with existing actual admissibility and the identical canonical GaussianPrecisionDensity declaration",
    note := "Mathematical candidatea0310046dc10c06ce9f61959094322fb9016be1e and bindingc70bb9b23e335acf768bb889f8229fcdf2a7af160e10fa89779d00dcba58374b pin exact code and authored mathematics. Independent source/whole-module review and normal source V are separate application prerequisites. Exactlyd>=2,kappa>=2 and every actual full real orthogonal O, including either determinant sign. The actual O diagonal(lambda) Otranspose precision has determinant equal to its full literal cosine-grid finite product. Its ONE actual compiled ASTIS producer parent is existing DisplacementJacobianEntropy.det_conjStarAlgAut_eq; this is identical canonical formal reuse, not a new generic lemma or weaker concept transport. Real star/transpose and Matrix.det_diagonal are internal proof steps; no determinant, positivity, spectral-window or density certificate is added as a source premise. The actual Test-only private Gaussian consumer has this producer, existing FixedSpectrumAdmissibility.actual_precision_admissible and canonical GaussianPrecisionDensity.multivariateGaussian_eq_withDensity_of_posDef as its three kernel ASTIS parents. It creates no public declaration or Registry node. Only the Gaussian prefactor is orientation-independent; the exponent retains actual A and real d/2 includes odd dimensions. Full unweighted Gaussian integral/knownZ, C4 calculus/minimizer, moments/Krylov, target-law/TV and adaptive/seed/transcript/output simulation, finite precision, deterministic/expected costs, both main lower bounds, remote publication and purification remain separate."
  },
'''
assert entry.splitlines()[1].encode() not in reg
reg = replace_once(reg, '  {\n    key := "gaussian-complexity.single-block-separation",', entry + '  {\n    key := "gaussian-complexity.single-block-separation",')
assert reg.replace(entry.encode(), b'', 1).replace(b'import AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumDeterminant\n', b'', 1) == before[PATHS[3]]
assert reg.count(b'status := LemmaMemoryStatus.formalizedLocal') == actual_count + 1
plans[PATHS[3]] = reg
f = json.loads(before[PATHS[4]])
guide = f['cases'][4]['reader_guide'][3]; boundary = f['cases'][4]['theorems'][1]['boundary']
suffix = boundary[boundary.index(' Section 4.4 limits'):]
old_guide_end = 'Basis-independent known-normalizer products, C4 calculus/minimizer, moments/Krylov and all full lower-bound transports remain separate.'
assert guide.count(old_guide_end) == 1
new_guide_end = r'The actual determinant product \(\det A=\prod_i\lambda_i\) is also compiled and independently source-reviewed, reusing the existing canonical determinant-conjugation declaration. Its actual same-A Gaussian density Test consumes this product, the existing actual positivity result and the identical canonical density node. Only the density prefactor is independent of orientation; the exponent retains the hidden precision. The full unweighted Gaussian integral/known-normalizer proposition, C4 calculus/minimizer, moments/Krylov and all full lower-bound transports remain separate.'
newguide = guide.replace(old_guide_end, new_guide_end, 1)
old_pending = 'Basis-independent determinant/known-normalizer products, C4 calculus/minimizer, Gaussian target-law/TV parameter transport, operational adaptive/seed/transcript/output simulation, deterministic/expected costs, finite-precision adapters and Krylov/moment/main-bound composition remain separate.'
assert boundary.count(old_pending) == 1
new_pending = r'The actual source determinant product \(\det A=\prod_{i=1}^d\lambda_i\) is additionally compiled and independently source-reviewed at the same exact source bounds and every full real \(O\), by literal reuse of the existing canonical DisplacementJacobianEntropy determinant-conjugation declaration. The real same-A Gaussian density Test combines this result with actual admissibility and the identical canonical GaussianPrecisionDensity node: its prefactor is \(\sqrt{\prod_i\lambda_i}/(2\pi)^{d/2}\), independent of orientation, while \(\exp(-x^\top A x/2)\) retains the actual hidden \(A\). The exponent \(d/2\) is real. This mathematical density identity does not close the separate full unweighted Gaussian integral/known-normalizer proposition. C4 calculus/minimizer, Gaussian target-law/TV parameter transport, operational adaptive/seed/transcript/output simulation, deterministic/expected costs, finite-precision adapters and Krylov/moment/main-bound composition remain separate.'
newboundary = boundary.replace(old_pending, new_pending, 1)
assert newboundary.endswith(suffix)
changed = before[PATHS[4]]
for old, new in [(guide, newguide), (boundary, newboundary)]:
 a = json.dumps(old, ensure_ascii=False).encode(); b = json.dumps(new, ensure_ascii=False).encode()
 assert changed.count(a) == 1; changed = changed.replace(a, b, 1)
after = json.loads(changed); delta = differences(f, after)
assert set(delta) == {'/cases/4/reader_guide/3', '/cases/4/theorems/1/boundary'}
assert f['execution'] == after['execution'] and f['cases'][4]['theorems'][0] == after['cases'][4]['theorems'][0]
undo = changed
for old, new in [(guide, newguide), (boundary, newboundary)]: undo = undo.replace(json.dumps(new, ensure_ascii=False).encode(), json.dumps(old, ensure_ascii=False).encode(), 1)
assert undo == before[PATHS[4]]
plans[PATHS[4]] = changed
plans[PATHS[5]] = r'''# AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumDeterminant

- File: `AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumDeterminant.lean`.
- Sole public declaration: `actual_precision_det`; one canonical compiled node.
- Mathematical candidate: `a0310046dc10c06ce9f61959094322fb9016be1e`; publication binding `c70bb9b23e335acf768bb889f8229fcdf2a7af160e10fa89779d00dcba58374b`. Independent current source/whole-module review and normal source V are separate prerequisites for applying this integration proposal.
- Domain: exactly `d >= 2`, `kappa >= 2` and every actual full `O in O(d)`, including either determinant sign. This pointwise statement has no Haar-law premise or determinant-one restriction.
- Actual object: `A = O diagonal(lambda_i) O^T`, `lambda_i=(kappa+1)/2+(kappa-1)cos(theta_i)/2`, `theta_i=(i-1/2)pi/d`. Lean zero-based `j.val+1/2` corresponds to source one-based `i=j.val+1`.
- Result: \(\det A=\prod_{i=1}^d\lambda_i\). Every displayed diagonal value contributes exactly once. The source bounds are retained even though the determinant algebra works for arbitrary real diagonal values.
- Formal proof reuse: the ONE ASTIS producer parent is the already public canonical `DisplacementJacobianEntropy.det_conjStarAlgAut_eq`. The actual full real orthogonal matrix is accepted by its unitary carrier. Real star is identified with transpose internally, then `Matrix.det_diagonal` gives the full product. No new determinant, positivity, spectrum or density premise is added, and no duplicate generic invariant is introduced.
- Real consumer: the Test-only private `actual_gaussian_density_consumer` proves the same actual \(N(0,A^{-1})\) equals its Euclidean-Lebesgue density with prefactor \(\sqrt{\prod_i\lambda_i}/(2\pi)^{d/2}\). The compiled consumer's three actual ASTIS parents are this new determinant producer, existing `FixedSpectrumAdmissibility.actual_precision_admissible` and the identical canonical `GaussianPrecisionDensity.multivariateGaussian_eq_withDensity_of_posDef`. Its private name enables kernel reflection only; it receives no public or Registry node.
- Orientation boundary: only the Gaussian coefficient is independent of `O`; the exponent \(\exp(-x^\top A x/2)\) retains the actual hidden basis. The power `d/2` is real, including odd dimensions. No equality of differently oriented target laws, query simulation or TV transport follows.
- Conceptual graph: identical compiled determinant and density declarations remain their single canonical formal nodes. No weaker conceptual transport or new oracle-factorization substrate is proposed. Graph Memory and Functor Hypergraph remain byte-identical; source-reference scans are not kernel proof dependencies.
- Source: Zhou--Suzuki arXiv2610.20492v1 Eq11 and the determinant equality component of AppendixC.4 Ex160. The explicit finite-product bridge is internal; the full unweighted Gaussian integral/known-normalizer proposition remains separate.
- Authored mathematics: `website/content/declaration_lessons/huanjian-fixed-spectrum-determinant.json`, bound by `website/content/publications/huanjian-fixed-spectrum-determinant.json`. The short determinant conclusion precedes folded hypotheses, five formula steps and adjacent exact Lean.
- Remaining: full C4 unweighted Gaussian integral/knownZ, strict historical source angle/cosine/eigenvalue route, calculus/Hessian/minimizer, moments/Krylov, true adaptive/Borel/private-seed/transcript/output laws, exact matvec and finite precision, TV, deterministic worst-case query cap and explicit expected-cost comparison, and both complete main lower bounds. The fixed-spectrum main theorem retains fixed delta in(0,1), large d,2<=kappa<=d^(1-delta),0<epsilon<=1/10; determinant-sign source ranges remain distinct. Section4.4 limits the present uniform-Krylov proof, not every stronger possible lower bound. Local exact-commit acceptance, remote publication, postmerge purification/Exposition Seal and whole Goal remain separate.
'''.encode()
assert set(plans) == set(PATHS)
rows = []; diff = b''
for i, path in enumerate(PATHS):
 old = before[path]; new = plans[path]; assert old != new
 row = {'path': path, 'before_exists': old is not None, 'before_sha256': sha(old) if old is not None else None, 'planned_after_sha256': sha(new)}
 if old is not None: row['before_archive'] = archive(f'path-{i+1}.before.raw.gz', old)
 row['planned_after_archive'] = archive(f'path-{i+1}.planned-after.raw.gz', new); rows.append(row)
 diff += b''.join(difflib.diff_bytes(difflib.unified_diff, (old or b'').splitlines(keepends=True), new.splitlines(keepends=True), fromfile=('a/'+path).encode() if old is not None else b'/dev/null', tofile=('b/'+path).encode()))
(S/'exact-proposed-shared.diff').write_bytes(diff)
diffrow = archive('exact-proposed-shared.diff.gz', diff)
ledger = {}; foreign = {}
for path, replay in [('runs/substantive_advances.jsonl', adv._replay_advances), ('runs/substantive_discoveries.jsonl', adv._replay_discoveries)]:
 raw = (R/path).read_bytes(); assert raw.endswith(b'\n')
 ss = replay([json.loads(line) for line in raw.splitlines() if line.strip()])
 if 'advances' in path: own = ss.pop(ADV)
 else: ss = {k:v for k,v in ss.items() if v.get('advance_id') != ADV}
 foreign[path] = ss
 ledger[path] = {'raw_prefix': archive(Path(path).name+'.prefix.raw.gz', raw), 'foreign_projection': archive(Path(path).name+'.foreign-projection.json.gz', canon(ss)), 'foreign_projected_records': len(ss)}
assert own['state'] == 'PROVED_LOCAL' and len(foreign['runs/substantive_advances.jsonl']) == 282
assert not [k for k,v in foreign['runs/substantive_advances.jsonl'].items() if v['state'] == 'STABILIZING']
markers = ('FixedSpectrumDeterminant', 'fixed-spectrum-determinant', 'huanjian-fixed-spectrum-determinant', 'ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-determinant')
gitmap = {}; inputs = {}
for line in cmd('git', 'ls-files', '--stage', '-z').split(b'\0'):
 if not line: continue
 md, path = line.split(b'\t', 1); path = os.fsdecode(path); mode, blob, stage = md.decode().split(); assert stage == '0'
 if path in PATHS or path in ledger or any(m in path for m in markers): continue
 gitmap[path] = [mode, blob]
 if not path.startswith('runs/'):
  q = R/path; raw = os.fsencode(os.readlink(q)) if q.is_symlink() else q.read_bytes()
  inputs[path] = {'sha256': sha(raw), 'bytes': len(raw)}
tracked = archive('protected-tracked-git-objects.json.gz', canon(gitmap))
protected = archive('protected-foreign-content-sha256.json.gz', canon(inputs))
frontiers = {str(p.relative_to(R)): sha(p.read_bytes()) for p in (R/'research-wiki/frontier-cells').glob('*.json') if p.name != 'ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-determinant.json'}
assert len(frontiers) == 441
fp = archive('all-441-foreign-frontier-hashes.json.gz', canon(frontiers))
gc = {str(p.relative_to(R)): sha(p.read_bytes()) for p in (R/'research-wiki/paper-contributions/GaussianComplexity').rglob('*') if p.is_file() and not any(m in str(p.relative_to(R)) for m in markers)}
gcp = archive('all-older-GaussianComplexity-evidence-hashes.json.gz', canon(gc))
masked = json.loads(before[PATHS[4]])
masked['cases'][4]['reader_guide'][3] = '<OWN_DETERMINANT_SCALAR>'
masked['cases'][4]['theorems'][1]['boundary'] = '<OWN_DETERMINANT_SCALAR>'
atlas = (R/'.atlas-upstream').stat()
for path in PATHS: assert ((R/path).read_bytes() if (R/path).exists() else None) == before[path]
for path,digest in {**PINS, **MODELS}.items(): assert sha((R/path).read_bytes()) == digest
(O/'initial-worktree-status.txt').write_bytes(cmd('git', 'status', '--short', '--untracked-files=normal'))
input_archives = {path: archive('input-'+str(i+1)+'.raw.gz', (R/path).read_bytes()) for i,path in enumerate(PINS)}
report = {
 'reviewer': '/root/det_integration_reader', 'phase': 'Exact six-path conditional integration and readability proposal only',
 'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'head_at_start': head, 'head_at_end': cmd('git','rev-parse','HEAD').decode().strip(), 'mathematical_candidate': CANDIDATE,
 'verdict': 'NO_BLOCKING_OBJECTION_TO_EXACT_CONDITIONAL_PROPOSAL', 'sourceV': 'Not issued; independent current-binding source/whole-module review and normal source V are required before application.',
 'shared_source_audit_ledger_API_or_lifecycle_mutations': False, 'build_site_browser_runs': [], 'source_Test_lesson_publication_pins': PINS, 'input_archives': input_archives, 'publication_binding_sha256': BINDING,
 'shared_paths': rows, 'shared_path_count': 6, 'canonical_Registry_nodes_added': 1, 'administrative_count_only': f'{actual_count}->{actual_count+1}; actual existing formalizedLocal records counted{actual_count}', 'all_old_Registry_bytes_retained': True,
 'formal_ASTIS_producer_parents': [PARENT], 'formal_ASTIS_consumer_parents': capsule['actual_ASTIS_consumer_parents'], 'actual_consumer_visibility': 'Test-only private name for proof reflection; no public consumer or Registry node.',
 'actual_consumer_canonical_reuse': 'Identical existing GaussianPrecisionDensity declaration, actual admissibility and new determinant producer are genuine same-A kernel parents. GPD/admissibility are not determinant producer proof parents.',
 'frontier_scalar_pointer_delta': delta, 'protected_case_values': {'execution_sha256': sha(canon(f['execution'])), 'determinant_theorem_index0_sha256': sha(canon(f['cases'][4]['theorems'][0])), 'all_other_case_values_sha256': sha(canon(masked)), 'Section4_4_limitation_suffix': suffix, 'Section4_4_suffix_sha256': sha(suffix.encode())},
 'unchanged_models': MODELS, 'new_conceptual_bridge_or_oracle_substrate_binding': False, 'raw_diff': diffrow, 'ledger_protection': ledger, 'foreign_frontiers': {'count': len(frontiers), **fp}, 'older_GaussianComplexity_evidence': {'count': len(gc), **gcp}, 'protected_git_objects': {'count': len(gitmap), **tracked}, 'protected_foreign_content': {'count': len(inputs), **protected}, 'own_state_at_snapshot': own['state'],
 'README_preservation': {'path': 'research-wiki/paper-contributions/GaussianComplexity/README.md', 'sha256': sha((R/'research-wiki/paper-contributions/GaussianComplexity/README.md').read_bytes()), 'scope': 'Protected unchanged through acceptance; root may separately append after parking.'},
 'untracked_Atlas': {'path': '.atlas-upstream', 'scope': 'Directory stat only; no content opened or traversed.', 'device': atlas.st_dev, 'inode': atlas.st_ino, 'mtime_ns': atlas.st_mtime_ns},
 'reader_preflight': {'main_conclusion': 'Concise detA=productlambda first; folded exact full-O/source bounds/literal grid and five formula steps; exact Lean adjacent. Actual Gaussian prefactor only is orientation-independent; exponent keeps A.', 'ASTIS_parent_truth': 'Exactly one existing canonical compiled DJE producer parent, not zero or a mechanism mirror. Three actual consumer parents, consumer private reflection name only.', 'actual_render': 'Pending final exactHEAD desktop/mobile original images; no visual acceptance claimed.'},
 'application_preconditions': ['Independent current-binding sourceV and accepted whole-module/reader review; root does not selfV.', 'Sole normal root STAB lease, preserving other owners/queues.', 'All current before hashes match, newcard absent; apply only the six archived after payloads.', 'GraphMemory and Functor models remain exact unchanged bytes.', 'Freeze immutable core; actual exactHEAD official Lean/rootTests gate, site build/check and cell graph check; later actual desktop1440/mobile390/source-index/module/download/localGit and native canonical graph checks.'],
 'later_actual_acceptance': ['Open assumptions, all five formula steps, exact statement/proof Lean and local horizontal scroll at1440/390; inspect every originalPNG independently.', 'Actually click source index and graph child/parent/module/GPD entries; actual producer list must show ONE canonicalDJE parent. Source-scanner and structural links never become formal proof evidence.', 'Own-site source/module/download bytes compared to local immutable Git; GitHub commit/path syntax only if that branch actually executes in the particular row. ExternalHTML/publicHTTP not checked.', 'Fresh protection readback and actual gate/site/graph/browser receipts; later normal parking is separate.'],
 'remaining_open': ['Actual current sourceV and canonical local acceptance at proposal time', 'FullC4 unweighted Gaussian integral/knownZ, strict source route, calculus/minimizer and moments/Krylov', 'Both main bounds; exactmatvec, adaptive/seed/transcript/output, finiteprecision/TV and deterministic/expectedcost adapters', 'Remote original-owner release/publication, postmerge purification/ExpositionSeal and wholeGoal']
}
assert report['head_at_start'] == report['head_at_end']
put(O/'proposal-report.json', report)
put(O/'freeze.json', {'reviewer': report['reviewer'], 'phase': report['phase'], 'report_sha256': sha((O/'proposal-report.json').read_bytes()), 'diff_raw_sha256': sha(diff), 'all_shared_paths_frozen': rows, 'models_unchanged': MODELS})
print(json.dumps({'report': str((O/'proposal-report.json').relative_to(R)), 'report_sha256': sha((O/'proposal-report.json').read_bytes()), 'freeze_sha256': sha((O/'freeze.json').read_bytes()), 'diff_raw_sha256': sha(diff), 'shared_paths': 6, 'foreign_SAUs': len(foreign['runs/substantive_advances.jsonl']), 'foreign_frontiers': len(frontiers), 'protected_foreign_content': len(inputs), 'older_GC_evidence': len(gc)}, indent=2))
