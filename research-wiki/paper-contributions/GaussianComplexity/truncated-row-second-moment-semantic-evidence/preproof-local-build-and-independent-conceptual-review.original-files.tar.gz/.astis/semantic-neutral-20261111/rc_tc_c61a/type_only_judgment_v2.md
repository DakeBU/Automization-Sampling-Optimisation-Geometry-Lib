# Current frozen type/definition judgment: rc_tc_c61a, v2

**Accept the exact signatures and their now-embedded canonical definition meanings for the bounded canonical-marginal covariance and single-summand expectation packet. No EXCESS binder is present.** This remains a type/definition judgment only, prior to receipt of any source graph, proof/API retrieval, or implementation proof.

## Exact input and disclosed earlier exposure

The new input is `selective-type-definition-packet-v2.json`, 12169 bytes, SHA-256 `ca055c5b2b92df9c5426ff2ddcf8d91677971381a5f309320a3859be6235ee8b`. Its current statement seal is `ee9d261db9301f0fa750102f8105c27fbbbcef9e8a19f900636b705f461b18dd`; definition context is `d3517d6dbb577297688a00f792940dc691ed4c23f16ecc96d63d1239cc2a679a`.

I previously received v1 packet SHA-256 `c4e34c2162e9c9c2796edd9e3acf7ea45d0d58e1da0f06dd70c7dc9e5e810cde`, producing preserved `type_only_judgment.md` SHA-256 `cc74760fa46e6b9daad6acacb5780742f919fd0e84b08cd463be2072947d23ee` and `type_only_freeze.json` SHA-256 `b405b36f6fbf835cff810e37f7a3cc4e01e8e7dddb004b0fa2da4fde09e79c5c`. That judgment explicitly audited only the meanings supplied there and did not open the referenced print log. V2 adds the literal canonical print bodies and preserves both signatures. No prior source-review or topology verdict has been shown to me.

The independent pre-type raw-source freeze remains `raw_source_freeze.md` SHA-256 `c87801f54b055115af6025cacb96b4fbde7d90bb1a2be4103974396aba3f9635`.

## V2 definition verification

The exact signature string hashes independently recompute to producer `e231ce32f517936350efface8c277491562d1537dcc02441db6907410929ae05` and consumer `0395f749c993cc8ebad7f71d3feb36a10c84543fb54fb35dabfe81a6ded54323`. The embedded print-body string independently hashes to `f8da081a8f6886773ab72e7adf793fc042f9fa540467b57560db775c4b1bef10`, as declared.

The printed `stdGaussian` body is the pushforward of a product of `gaussianReal 0 1` coordinates through a standard orthonormal basis. It supplies an actual canonical Gaussian measure, not an arbitrary measure equipped with a theorem-shaped law assumption. The printed `EuclideanSpace` is `PiLp 2`; `WithLp.ofLp` exposes the underlying coordinate function. Thus the squared norm is the source Euclidean radius squared, while the rank-one entries remain ordinary coordinate products.

The printed `vecMulVec`, `Matrix`, `Matrix.of`, `Matrix.one`, and `Matrix.diagonal` bodies establish the intended coordinate outer product and diagonal-one identity. The printed Kronecker definition and supplied pair-index semantics retain the Gaussian index first and feature index second. The printed matrix norm instances explicitly transport the Euclidean continuous-linear-map operator norm; the scope is `Matrix.Norms.L2Operator`. This eliminates ambiguity over which norm controls the two `Integrable` conclusions.

The printed indicator is the literal in-set/zero-outside function. Its set is exactly `R≤L`. The printed `Integrable` body includes a.e. strong measurability and finite norm integral. The underlying supplied Bochner source definition states the complete-space and integrability branches: a nonintegrable integral would be totalized to zero. The target conclusions require both matrix integrabilities, and scalar-integrability/coordinate interchange facts remain internal proof obligations. There is no project-owned characterized object, hidden predicate alias, arbitrary choice witness, or off-source default definition.

## Current binder and semantic judgment

The producer and consumer have only natural `d,q`, the standing `hq : 2*q+1<d`, and, for the consumer, a valid row index `i : Fin d`. The natural counts and row index are TYPING; `hq` is STANDING. All positivity, cast, Gaussian symmetry, Gaussian/radial integrability, coordinate evaluation, trace, and tensor-extraction facts must be proved internally. Both matrix integrabilities are conclusions. The EXCESS list is empty.

The literal scalar is the unnormalized retained radius-squared integral divided by real `q+1`. The literal cutoff is `2*(q+1)+3*log(1000d)`. The covariance conclusion is the whole matrix `a I`, with no conditional-law normalization. The consumer is the source's deterministic `d⁻¹(γγᵀ⊗t_it_iᵀ)1_{R≤L}` in the correct pair order and concludes exactly `(a/d)(I⊗t_it_iᵀ)`.

At `q=0`, dimension is one, `hq` yields `d>1`, the only feature coordinate is `1`, and the producer and consumer reduce to the one-entry retained second moment and that moment divided by `d`. No distinct-coordinate existence or `r≥2` condition is hidden in the signatures.

The canonical-law formulation is faithful to the bounded source marginal calculation because raw C.2 states every `γ_i` has the same `N(0,I_r)` law. It does not itself assert joint row-family independence or construct the original Gaussian input array. The graph must preserve that scope distinction and the common-law reason that one `a` works for all `i`. If original-family identities are later advertised, their law-transport dependency remains necessary.

The full seven-slot and definition comparison in the preserved v1 judgment remains applicable because neither signature changed. Its angle-attribution boundary also remains: my raw freeze transcribed the displayed cosine vector but not the earlier global midpoint-angle definition. The present local expectation edge needs only the literal deterministic row. A separate claim that the displayed midpoint formula is the exact earlier source definition must carry its raw source anchor; this review does not silently certify that unread earlier formula.

## Next gate

Ready for independent source-topology challenge against this exact v2 seal. The graph must cover the source's Gaussian marginal/common-law input, omitted symmetry, truncated integrability, entrywise integration, trace and positive-dimension scalar identification, and deterministic tensor expectation. Equivalent sufficient symmetry/integrability routes must not become false AND dependencies. Excluded numerical-bias, cosine-sum, independent-family, and concentration regions must stay explicitly bounded. No process grant or proof status is issued here.
