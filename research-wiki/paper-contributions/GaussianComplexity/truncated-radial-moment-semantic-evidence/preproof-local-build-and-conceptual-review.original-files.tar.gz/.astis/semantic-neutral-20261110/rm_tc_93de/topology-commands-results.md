# Final challenge commands and results

All shell commands used the working directory `/Users/zhouhuanjian/ASTIS-GC`.

## Authorized author source artifacts

The first read batch ran these commands independently and each exited 0.

```sh
shasum -a 256 .astis/semantic-neutral-20261110/rm_sg_41bf/phase1/source-graph.json .astis/semantic-neutral-20261110/rm_sg_41bf/phase1/coverage.json .astis/semantic-neutral-20261110/rm_sg_41bf/phase1/source-math.md
cat .astis/semantic-neutral-20261110/rm_sg_41bf/phase1/source-graph.json
cat .astis/semantic-neutral-20261110/rm_sg_41bf/phase1/coverage.json .astis/semantic-neutral-20261110/rm_sg_41bf/phase1/source-math.md
rg -n -o 'id="S4\.Thmtheorem4\.p1(?:\.m[23])?"[^>]*' .astis/huanjian-resume-20261103/2610.20492v1.html
```

```text
1310e3e205d88ed776f238a8aa0892f2a434e0b5b8d91e9b2c25210572cd0813  .astis/semantic-neutral-20261110/rm_sg_41bf/phase1/source-graph.json
5c483c6891c115a2439a1b30702e13476f9218991c3fa18bac3dad1182b51c81  .astis/semantic-neutral-20261110/rm_sg_41bf/phase1/coverage.json
b5575294f8fc07c19a5e46ad02137ed0c3ec1e2b86483231d0aa0648bb2782ae  .astis/semantic-neutral-20261110/rm_sg_41bf/phase1/source-math.md
1209:id="S4.Thmtheorem4.p1" class="ltx_para"
1211:id="S4.Thmtheorem4.p1.m2" class="ltx_Math" alttext="q\geq 0" display="inline" intent=":literal"
1211:id="S4.Thmtheorem4.p1.m3" class="ltx_Math" alttext="2q+1&lt;d" display="inline" intent=":literal"
```

The `cat` outputs were the contents of the three digest-pinned artifacts. The combined `coverage.json` and `source-math.md` tool display truncated part of the coverage JSON. The following batch read the source-math file alone and used compact output for the coverage dispositions. All three commands exited 0.

```sh
cat .astis/semantic-neutral-20261110/rm_sg_41bf/phase1/source-math.md
rg -n -o 'id="A3\.(EGx10|Ex106(\.m[12])?)"[^>]*|id="S4\.Thmtheorem4\.p1\.m[23]"[^>]*' .astis/huanjian-resume-20261103/2610.20492v1.html
python3 - <<'PY'
from collections import Counter
from pathlib import Path
import json
p=Path('.astis/semantic-neutral-20261110/rm_sg_41bf/phase1')
g=json.loads((p/'source-graph.json').read_bytes())
c=json.loads((p/'coverage.json').read_bytes())
ids={n['id'] for n in g['nodes']}
seen=set(g['roots'])
while True:
    extended=seen | {x for e in g['edges'] if e['to'] in seen for x in e['from_all']}
    if extended==seen: break
    seen=extended
print('GRAPH',len(g['nodes']),'nodes',len(g['edges']),'edges',len(g['roots']),'roots')
print('Graph nodes outside backward closure:',sorted(ids-seen))
print('Invalid graph IDs:',sorted(seen-ids | {e['to'] for e in g['edges']}-ids))
print('Invalid coverage graph IDs:',sorted({item['graph_node'] for item in c['items'] if 'graph_node' in item}-ids))
print('COVERAGE',dict(Counter(item['disposition'] for item in c['items'])))
for item in c['items']:
    why=item.get('graph_node') or item.get('reason')
    if not why.startswith('HTML container'):
        print(item['source_id'],item['locator']['lf_line_start'],item['disposition'],why)
PY
```

```text
1211:id="S4.Thmtheorem4.p1.m2" class="ltx_Math" alttext="q\geq 0" display="inline" intent=":literal"
1211:id="S4.Thmtheorem4.p1.m3" class="ltx_Math" alttext="2q+1&lt;d" display="inline" intent=":literal"
3561:id="A3.EGx10" class="ltx_equationgroup ltx_eqn_align ltx_eqn_table"
3563:id="A3.Ex106"
3565:id="A3.Ex106.m1" class="ltx_math_unparsed" alttext="\displaystyle\mathbb{E}[R_{i}\mathbf{1}_{\{R_{i}&gt;L\}}]" display="inline" intent=":literal"
3566:id="A3.Ex106.m2" class="ltx_Math" alttext="\displaystyle=L\mathbb{P}(R_{i}&gt;L)+\int_{0}^{\infty}\mathbb{P}(R_{i}&gt;L+s)\,ds\leq\frac{L+3}{1000d}." display="inline" intent=":literal"
GRAPH 28 nodes 19 edges 8 roots
Graph nodes outside backward closure: ['row-definition']
Invalid graph IDs: []
Invalid coverage graph IDs: []
COVERAGE {'EXCLUDED': 52, 'NODE': 27}
```

The remaining compact rows printed the source ID, LF line, and disposition of every coverage item except mixed HTML containers. The pinned coverage JSON records their exact values. The final replay below independently checked every stored raw span, including the containers.

## Standing scope in the original HTML

The source extraction used the following command and exited 0.

```sh
python3 - <<'PY'
from html import unescape
from pathlib import Path
import re
lines=Path('.astis/huanjian-resume-20261103/2610.20492v1.html').read_text().splitlines()
line=lines[1210]
end=line.index('</math>',line.index('id="S4.Thmtheorem4.p1.m3"'))+len('</math>')
text=line[:end]
text=re.sub(r'<math\b[^>]*alttext="([^"]+)"[^>]*>.*?</math>',r' $\1$ ',text)
text=unescape(re.sub(r'<[^>]+>','',text))
print('1211',text.strip())
PY
```

```text
1211 Let  $q\geq 0$  satisfy  $2q+1<d$
```

## Authorized typed overlay

After authorization the following two commands ran independently and exited 0.

```sh
shasum -a 256 .astis/semantic-neutral-20261110/rm_sg_41bf/phase2/typed-overlay.md .astis/semantic-neutral-20261110/rm_sg_41bf/phase2/SHA256SUMS
cat .astis/semantic-neutral-20261110/rm_sg_41bf/phase2/typed-overlay.md .astis/semantic-neutral-20261110/rm_sg_41bf/phase2/SHA256SUMS
```

```text
9236a99e49ee26d75a4e122fa599effe73b3865f748e0cf500468e76e5043122  .astis/semantic-neutral-20261110/rm_sg_41bf/phase2/typed-overlay.md
0f6e199eeaad128d99b4390de46097e0dfb34fe8b5d74afd60043ff3a797fc02  .astis/semantic-neutral-20261110/rm_sg_41bf/phase2/SHA256SUMS
```

The read returned both complete digest-pinned files. Its manifest lines were as follows. The second listed artifact was not opened.

```text
9236a99e49ee26d75a4e122fa599effe73b3865f748e0cf500468e76e5043122  .astis/semantic-neutral-20261110/rm_sg_41bf/phase2/typed-overlay.md
c2b353ffa0c5f2977ddf3461f03a56a3dfe7d30ba418a6edd1f979954fa4ee80  .astis/semantic-neutral-20261110/rm_sg_41bf/phase2/commands-results.md
```

## Coverage verification and correction replay

This command exited 0. The edge delta was applied in memory and the author files were preserved.

```sh
python3 - <<'PY'
from collections import Counter
from graphlib import TopologicalSorter
from hashlib import sha256
from pathlib import Path
import json
p=Path('.astis/semantic-neutral-20261110/rm_sg_41bf/phase1')
g=json.loads((p/'source-graph.json').read_bytes())
c=json.loads((p/'coverage.json').read_bytes())
raw=Path(g['raw_source']).read_bytes()
source=raw.decode()
assert sha256(raw).hexdigest()==g['raw_source_sha256']
for item in c['items']:
    x=item['locator']
    a,b=x['char_start'],x['char_end']
    raw_span=raw[x['raw_utf8_start']:x['raw_utf8_end']]
    assert source[a:b].encode()==raw_span,item['source_id']
    assert sha256(raw_span).hexdigest()==x['span_sha256'],item['source_id']
    assert source.count('\n',0,a)+1==x['lf_line_start'],item['source_id']
    assert source.count('\n',0,b-1)+1==x['lf_line_end'],item['source_id']
    assert a-source.rfind('\n',0,a)-1==x['lf_column0_start'],item['source_id']
print('Coverage byte and character spans, SHA-256, and LF locations:',len(c['items']),'verified')
print('Dispositions:',dict(Counter(item['disposition'] for item in c['items'])))
ids={n['id'] for n in g['nodes']}
def closure(edges):
    ts=TopologicalSorter()
    for node in ids: ts.add(node)
    for edge in edges: ts.add(edge['to'],*edge['from_all'])
    assert set(ts.static_order())==ids
    seen=set(g['roots'])
    while True:
        extended=seen | {x for e in edges if e['to'] in seen for x in e['from_all']}
        if extended==seen: return seen
        seen=extended
print('Outside backward root closure:',sorted(ids-closure(g['edges'])))
delta={'from_all':['row-definition'],'to':'radial-variable','use_site':'A3.SS2.p10.m2','discharge_or_use':'Apply the squared Euclidean norm to the row defined in A3.Ex85.m1#row.'}
print('With the proposed edge in memory:',sorted(ids-closure(g['edges']+[delta])))
PY
```

```text
Coverage byte and character spans, SHA-256, and LF locations: 79 verified
Dispositions: {'EXCLUDED': 52, 'NODE': 27}
Outside backward root closure: ['row-definition']
With the proposed edge in memory: []
```

Absolute `apply_patch` wrote the final challenge, this record, and their manifest under the challenger directory.
