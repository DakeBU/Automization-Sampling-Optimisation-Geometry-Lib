"""Read-only reanalysis of preserved R17 v3 actual artifacts; never starts a browser."""
import ast, datetime as dt, hashlib, json, os, re, struct, sys, time, traceback
from pathlib import Path
from html.parser import HTMLParser

OUT = Path(__file__).resolve().parent
OWN = OUT.parent
REPO = OWN.parents[2]
PREVIEW = REPO / '.astis/huanjian-gc-matrix-mgf-domain-20261115/reader-preview-v1/static-closure-v3'
FIXTURE = PREVIEW / 'fixtures/candidate'
SNAPSHOT = PREVIEW / 'input-snapshot'
PINS = {
    'browser_check.py': '64101b5e78fe02d97a92650ff397750d387811a576f4932743972c682e183f94',
    'browser_geometry.py': 'cc7eb67308d24fd5dbf87345b9e48ac1140ff7879bb05a96e08bc01a13d9efd4',
    'execution-assignment.json': '8117656fe0e407aa172b812af3646349d0fbe50bd9b5b7b77dc8bced56845eb1',
    'actual-result.json': '74fd21200be988619c1ff27fd253049cc84c96641461aaf3fb54ca52beb9384f',
}

def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p, x):
    with Path(p).open('x') as f: f.write(json.dumps(x, ensure_ascii=False, indent=2) + '\n')

class Node:
    def __init__(self, tag='', attrs=()): self.tag, self.attrs, self.children = tag, dict(attrs), []
    def text(self): return ''.join(x if isinstance(x, str) else x.text() for x in self.children)
    def has(self, c): return c in self.attrs.get('class', '').split()
    def find(self, pred):
        out = []
        for x in self.children:
            if isinstance(x, Node):
                if pred(x): out.append(x)
                out.extend(x.find(pred))
        return out

class Parse(HTMLParser):
    def __init__(self, s):
        super().__init__(convert_charrefs=True); self.root = Node(); self.stack = [self.root]; self.feed(s)
    def handle_starttag(self, t, a):
        n = Node(t, a); self.stack[-1].children.append(n)
        if t not in {'area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr'}: self.stack.append(n)
    def handle_endtag(self, t):
        for i in range(len(self.stack)-1, 0, -1):
            if self.stack[i].tag == t: self.stack = self.stack[:i]; break
    def handle_data(self, s): self.stack[-1].children.append(s)

def intersection(a, b):
    w = max(0, min(a['right'], b['right']) - max(a['left'], b['left']))
    h = max(0, min(a['bottom'], b['bottom']) - max(a['top'], b['top']))
    return w, h, w*h

def main():
    checks = []
    def check(name, ok, detail=None):
        checks.append({'name': name, 'pass': bool(ok), 'detail': detail})
        if not ok: raise AssertionError(name)
    check('four-preserved-runtime-pins-exact', all(sha(OWN/p) == h for p,h in PINS.items()))
    result = json.loads((OWN/'actual-result.json').read_text())
    receipt = json.loads((OWN/'runtime-process/receipt.json').read_text())
    assignment = json.loads((OWN/'execution-assignment.json').read_text())
    check('OS-receipt-actual-exit1', receipt['actual_exit_code'] == 1 and receipt['exception'] is None)
    check('actual-fd-streams-byte-identities', all(sha(OWN/receipt[k]['path']) == receipt[k]['sha256'] and (OWN/receipt[k]['path']).stat().st_size == receipt[k]['bytes'] for k in ['stdout','stderr']))
    summary = json.loads((OWN/'runtime-process/stdout.raw').read_text())
    false = [c for c in result['checks'] if not c['pass']]
    false_names = [c['name'] for c in false]
    check('original-global-FAIL-501checks-3false-preserved', result['status'] == 'FAIL' and len(result['checks']) == 501 and false_names == ['desktop-step5-actual-source-anchor-navigation','mobile-step5-actual-source-anchor-navigation','mobile-final-context-document-horizontal-containment'] and summary['false_checks'] == false_names and summary['status'] == 'FAIL')
    check('current-v3-manifest-pin', sha(PREVIEW/'preview-freeze-manifest.json') == 'cb35d92094afe575fc6dfa96e2960508bd5c4e699f3c46e5d19c521afc697965')
    check('all-actual-assignment-input-pins-still-exact', all(sha(r['path']) == r['sha256'] for r in assignment['frozen_inputs']))
    manifest = json.loads((PREVIEW/'preview-freeze-manifest.json').read_text())
    check('candidate110-exact-file-set-and-bytes', {str(p.relative_to(FIXTURE)) for p in FIXTURE.rglob('*') if p.is_file()} == {r['path'] for r in manifest['variants']['candidate']['files']} and all(sha(FIXTURE/r['path']) == r['sha256'] for r in manifest['variants']['candidate']['files']))
    names = {}
    for n in ast.parse((OWN/'browser_check.py').read_text()).body:
        if isinstance(n, ast.Assign) and isinstance(n.targets[0], ast.Name) and n.targets[0].id in ['ITEM','PFILE','TFILE','P','T','PSD','TRACE','SOURCES']:
            names[n.targets[0].id] = eval(compile(ast.Expression(n.value), '<pure literal checker constants>', 'eval'), {'__builtins__':{}}, names)
    sources = names['SOURCES']; by_label = {s[0]:s for s in sources}
    source_doms = {}
    for label, raw, decl, anchor, count in sources:
        dom = Parse((FIXTURE/('data/lesson-sources/'+raw+'.html')).read_text()).root
        source_doms[label] = dom
        check(label+'-frozen-source-body-and-download-exact', dom.find(lambda n:n.tag == 'pre')[0].text().encode() == (SNAPSHOT/raw).read_bytes() == (FIXTURE/('downloads/lean/'+raw)).read_bytes())
    lesson_path = SNAPSHOT/'website/content/declaration_lessons/huanjian-matrix-mgf-domain.json'
    unit = json.loads(lesson_path.read_text())['units'][0]
    dom = Parse((FIXTURE/manifest['variants']['candidate']['proof_path']).read_text()).root
    steps = dom.find(lambda n:n.tag == 'details' and n.has('proof-reader-step'))
    check('five262-lines-whole-P-T-and-adjacent-HTML-byte-exact', len(steps) == 5 and [s.find(lambda n:n.tag == 'pre')[0].text() for s in steps] == [s['lean'] for s in unit['steps']] and ''.join(s['lean'] for s in unit['steps'][:2]).encode() == (SNAPSHOT/names['PFILE']).read_bytes() and ''.join(s['lean'] for s in unit['steps'][2:]).encode() == (SNAPSHOT/names['TFILE']).read_bytes())
    downloads = []
    for p in sorted((OWN/'runtime-output').glob('*.lean')):
        m = re.fullmatch(r'(desktop|mobile)-step([1-5])-whole-module.lean', p.name)
        if m: raw = unit['steps'][int(m[2])-1]['lean_source_path']
        else:
            m = re.fullmatch(r'(desktop|mobile)-source-(P|T|PSD|TRACE|Radius|Structure)-whole-module.lean', p.name)
            raw = by_label[m[2]][1] if m else names['TFILE'] if re.fullmatch(r'(desktop|mobile)-private-T-module-context-download.lean',p.name) else None
        check('actual-download-exact:'+p.name, raw is not None and p.read_bytes() == (SNAPSHOT/raw).read_bytes())
        downloads.append({'path':str(p.relative_to(OWN)), 'sha256':sha(p), 'bytes':p.stat().st_size, 'source_path':raw})
    check('exact24-actual-downloads', len(downloads) == 24)
    lookup = {c['name']:c for c in result['checks']}
    check('unique-original-check-names', len(lookup) == 501)
    graph = []
    for c in result['checks']:
        if not c['name'].endswith('-readable-node-core-label-inside-real-SVG-clip'): continue
        d = c['detail']; g = d['after_native_UI']; clip = g['clip']; node = g['node']; label = g['labelRect']; svg = g['svg']; vp = g['viewport']
        nw,nh,na = intersection(node, clip); lw,lh,la = intersection(label, clip)
        nf = na/(node['width']*node['height']); lf = la/(label['width']*label['height'])
        check(c['name']+'-independent-raw-bbox-recompute', abs(nf-g['intersectionFraction'])<1e-9 and abs(lf-g['labelVisibleFraction'])<1e-9 and nf>=.98 and lf>=.95 and g['effectiveFontPx']>=12 and lw>=min(80,label['width']) and lh>=min(12,label['height']) and clip['left']>=max(0,svg['left']) and clip['right']<=min(vp['width'],svg['right']) and clip['top']>=max(g['headerBottom']+8,svg['top']) and clip['bottom']<=min(vp['height']-8,svg['bottom']) and d['native_pointer_and_wheel_exercised'] and not d['direct_SVG_transform_or_node_style_writes'])
        graph.append({'name':c['name'],'node_fraction_recomputed':nf,'label_fraction_recomputed':lf,'effective_font_px':g['effectiveFontPx'],'core_label':g['label'],'label_visible_width':lw,'label_visible_height':lh,'initial_default_fit_fraction':d['default_fit_before_scroll']['intersectionFraction']})
    check('all-six-graph-focuses-recomputed',len(graph)==6)
    glyphs = []
    for c in result['checks']:
        if not c['name'].endswith('full-codepoint-visible'): continue
        d = c['detail']; g = d['glyph']; clip = d['actualVisibleClip']; source_label = c['name'].split('-')[1]
        raw = source_doms[source_label].find(lambda n:n.attrs.get('id') == d['lineId'])[0].text()
        selected = raw.encode('utf-16-le')[2*d['selectedGlyphStartUTF16']:2*d['selectedGlyphEndUTF16']].decode('utf-16-le')
        right = max(0, g['right']-clip['right']); left = max(0, clip['left']-g['left'])
        check(c['name']+'-raw-codepoint-and-geometry-recomputed', selected==d['selectedGlyph'] and [ord(x) for x in selected]==d['codePoints'] and len(selected)==1 and g['width']>0 and g['height']>0 and left<=1 and right<=1 and g['top']>=clip['top'] and g['bottom']<=clip['bottom'] and d['lineVisible'])
        glyphs.append({'name':c['name'],'line':d['lineId'],'codepoint':ord(selected),'left_bbox_overhang_css_px':left,'right_bbox_overhang_css_px':right,'horizontal_tolerance_css_px':1})
    check('24-actual-widest-bottom-glyph-records-recomputed',len(glyphs)==24)
    shots = []
    for r in result['screenshots']:
        p=OWN/r['path']; data=p.read_bytes(); w,h=struct.unpack('>II',data[16:24])
        check('actual-PNG-pin:'+p.name, sha(p)==r['sha256'] and data[:8]==b'\x89PNG\r\n\x1a\n' and w in [390,1440])
        shots.append({**r,'width':w,'height':h})
    check('exact50-original-PNGs', len(shots)==50 and len({s['path'] for s in shots})==50 and {str(p.relative_to(OWN)) for p in (OWN/'runtime-output').glob('*.png')}=={s['path'] for s in shots})
    for c in false[:2]:
        d=c['detail']; iw,ih,area=intersection(d,d['clip'])
        check(c['name']+'-zero-visible-intersection-confirmed',ih==0 and d['intersectionHeight']==0 and not d['positive'])
    check('mobile-699px-body-overflow-confirmed',false[2]['detail']=={'viewport':390,'html':390,'body':699})
    check('original-request-response-and-error-boundary',len(result['requests'])==1646 and len(result['responses'])==1646 and not result['console'] and not result['page_errors'] and not result['blocked_external_requests'] and all(r['status']<400 for r in result['responses']) and result['server_and_worker_stopped'])
    # These are static facts, never a claim about a settled browser geometry absent from the run.
    css=FIXTURE/'assets/site-base.css'; css_lines=css.read_text().splitlines()
    check('static-smooth-scroll-present',css_lines[82].strip()=='scroll-behavior: smooth;')
    lifecycle=[]
    for p in sorted((FIXTURE/'assets').glob('*.js')):
        for i,line in enumerate(p.read_text().splitlines(),1):
            if re.search(r'hashchange|location\.hash|scrollIntoView|scrollTo\(',line):lifecycle.append({'path':str(p.relative_to(FIXTURE)),'line':i,'text':line})
    check('no-selected-root-asset-source-hash-reveal-handler',not lifecycle)
    anchor_records=[c for c in result['checks'] if re.fullmatch('(desktop|mobile)-step[1-5]-actual-source-anchor-navigation',c['name'])]
    outcome={'schema':'R17-preserved-v3-readonly-failure-review-data-v1','review_is_not_a_new_browser_run':True,'original_runtime_status':'FAIL','original_OS_exit_code':1,'original_checks':501,'original_false':false,'own_readonly_checks':checks,'actual_downloads':downloads,'graph_raw_bbox_recomputations':graph,'glyph_raw_codepoint_recomputations':glyphs,'max_horizontal_Range_bbox_overhang_css_px':max(g['right_bbox_overhang_css_px'] for g in glyphs),'actual_original_screenshots':shots,'anchor_records':anchor_records,'static_facts':{'site_base_css_sha256':sha(css),'smooth_scroll_line':83,'no_source_hash_lifecycle_in_selected_root_JS':True,'settled_anchor_geometry_recorded':False,'overflow_owner_metric_recorded':False},'original_pins':PINS,'preview_manifest_sha256':sha(PREVIEW/'preview-freeze-manifest.json'),'source_reviewed_binding':result['source_reviewed_binding'],'mathematical_commit':result['mathematical_commit'],'server_and_worker_stopped_in_original':result['server_and_worker_stopped'],'no_new_browser_API_Lean_Git_site_or_source_action':True}
    write(OUT/'readonly-data-review.json',outcome)
    print(json.dumps({'readonly_audit':'COMPLETE','original_runtime_status':'FAIL','original_OS_exit_code':1,'original_false_checks':false_names,'checks':len(checks),'downloads_exact':len(downloads),'original_PNG_hashes_checked':len(shots),'graph_cases_recomputed':len(graph),'glyph_cases_recomputed':len(glyphs),'data_review_sha256':sha(OUT/'readonly-data-review.json')}))

if __name__=='__main__':
    process=OUT/'process';process.mkdir(exist_ok=False)
    for fd,name in [(1,'stdout.raw'),(2,'stderr.raw')]:
        f=(process/name).open('xb',buffering=0);os.dup2(f.fileno(),fd);f.close()
    start=time.monotonic();utc=dt.datetime.now(dt.timezone.utc).isoformat();code=0
    try:main()
    except BaseException:traceback.print_exc();code=1
    sys.stdout.flush();sys.stderr.flush()
    write(process/'receipt.json',{'schema':'R17-actual-readonly-artifact-review-process-receipt-v1','argv':[sys.executable,*sys.argv],'cwd':str(Path.cwd()),'pid':os.getpid(),'started_utc':utc,'ended_utc':dt.datetime.now(dt.timezone.utc).isoformat(),'actual_exit_code':code,'elapsed_seconds':time.monotonic()-start,'script_sha256':sha(__file__),'stdout_sha256':sha(process/'stdout.raw'),'stderr_sha256':sha(process/'stderr.raw'),'scope':'Only preserved actual runtime artifacts and frozen local fixture reads; writes only own new failure-review-v1. No browser/server/API/Lean/Git/site/source writes.'})
    sys.exit(code)
