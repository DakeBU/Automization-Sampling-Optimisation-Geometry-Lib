"""Portable replay: retarget already generated exact inspector output path only."""
import pathlib,re
root=pathlib.Path(__file__).resolve().parent
p=root/'scratch/InspectAll.lean'
s=p.read_text();s=re.sub(r'IO.FS.writeFile "[^"]+"','IO.FS.writeFile "'+str(root/'native-all-bodies.json')+'"',s)
(root/'scratch/InspectAllRelocated.lean').write_text(s)
