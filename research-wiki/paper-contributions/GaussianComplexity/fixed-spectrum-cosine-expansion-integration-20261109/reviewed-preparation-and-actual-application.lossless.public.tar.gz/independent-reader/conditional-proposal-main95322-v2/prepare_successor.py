"""Read-only main95322 reconciliation and exact two-payload conditional rebase; private output only."""
import sys
sys.dont_write_bytecode = True
import ast, copy, difflib, gzip, hashlib, json, subprocess
from pathlib import Path
R=Path('/Users/zhouhuanjian/ASTIS-GC')
O=Path(__file__).resolve().parent
OLD=O.parent/'conditional-proposal-v1'
C='37645c774481c4cad19fc29bcaa76799da64db7d'
B='d9bcd4231df69061c5221f8d557ee179a945c1eb'
M='95322cd2c762e5969c560815a803c4e15a424007'
M1='4f0e6584e26dc5226957f23108f0c2309296e0c5'
FH='website/content/functor_hypergraph.json'
CP='website/content/samplewiki_companion_frontiers.json'
JS='website/static/underlying-lean-graph.js'
GID='ASTIS-SW-GAUSSIAN-COMPLEXITY-2026'
SID='ASTIS-SW-SLC-LSI-COMPLEXITY-2026'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
def git(*args): return subprocess.check_output(['git',*args],cwd=R)
def data(rel,obj):
 p=O/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
def blob(rel,raw):
 p=O/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(p.read_bytes())==raw
 return {'archive':rel,'raw_sha256':sha(raw),'raw_bytes':len(raw),'archive_sha256':sha(p.read_bytes()),'CRLF':raw.count(b'\r\n'),'lone_LF':raw.count(b'\n')-raw.count(b'\r\n')}
def archived(row):return gzip.decompress((OLD/row['archive']).read_bytes())
# Reuse only the old private token-span parser and pure value-difference function,
# not the executable preparation module or its top-level writes/checks.
tree=ast.parse((OLD/'prepare_conditional_bytes.py').read_bytes())
functions=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in {'json_spans','changes'}]
assert len(functions)==2
scope={'json':json};exec(compile(ast.Module(body=functions,type_ignores=[]),'<pure-private-token-parser>','exec'),scope)
spans=scope['json_spans'];changes=scope['changes']
def token(raw,path):
 s,p=spans(raw);a,b=p[path];return s[a:b]
def transplant(raw,path,newtoken):
 s,p=spans(raw);a,b=p[path];out=(s[:a]+newtoken+s[b:]).encode()
 ns,np=spans(out);x,y=np[path];assert (ns[:x]+s[a:b]+ns[y:]).encode()==raw
 return out
def insert(raw,pos,text):
 s=raw.decode();out=(s[:pos]+text+s[pos:]).encode();assert (out.decode()[:pos]+out.decode()[pos+len(text):]).encode()==raw
 return out
def mapping_prefix(raw,path,newkey):
 s,p=spans(raw);a,b=p[path];obj=json.loads(s[a:b]);keys=list(obj);assert keys[0]==newkey
 first=s.index(json.dumps(keys[0]),a,b);old=s.index(json.dumps(keys[1]),first,b)
 return s[first:old],keys[1]
def prepend_mapping(raw,path,text,oldfirst):
 s,p=spans(raw);a,b=p[path];obj=json.loads(s[a:b]);assert next(iter(obj))==oldfirst
 pos=s.index(json.dumps(oldfirst),a,b);return insert(raw,pos,text)
assert git('rev-parse','HEAD').decode().strip()==C
assert not git('status','--porcelain=v1','--untracked-files=no')
assert git('merge-base',C,M).decode().strip()==B
original_freeze=(OLD/'freeze-manifest.json').read_bytes();assert sha(original_freeze)=='bc41f6194a7da20742a741b007145fb81f31cdac5116c52a4888070fedd1b0c1'
for row in json.loads(original_freeze)['files']:assert sha((OLD/row['path']).read_bytes())==row['sha256']
overlay=OLD/'public-review-path-overlay-v1'
for row in json.loads((overlay/'freeze-manifest.json').read_bytes())['files']:assert sha((overlay/row['path']).read_bytes())==row['sha256']
old=json.loads((overlay/'composed-eight-payload-manifest.json').read_bytes())
assert sha((overlay/'composed-eight-payload-manifest.json').read_bytes())=='4ddb3d51023d95e8cd2503ef8aefe1a32a5b1825e9e4f6eb06f00eb78e4b7cb4'
base_cp=git('show',B+':'+CP);main_cp=git('show',M+':'+CP);branch_cp=git('show',C+':'+CP)
bc,mc,cc=map(json.loads,[base_cp,main_cp,branch_cp])
reconciled_cp=branch_cp
for path in [('scope',),('execution','targets'),('execution','additional_lanes')]:
 assert token(branch_cp,path)==token(base_cp,path),path
 reconciled_cp=transplant(reconciled_cp,path,token(main_cp,path))
added,oldfirst=mapping_prefix(main_cp,('sources',),'slc-lsi-complexity-2026')
reconciled_cp=prepend_mapping(reconciled_cp,('sources',),added,oldfirst)
ms,mp=spans(main_cp);cs,cp=spans(reconciled_cp)
assert mc['cases'][0]['id']==SID and [x['id'] for x in mc['cases'][1:]]==[x['id'] for x in bc['cases']]
assert [x['id'] for x in cc['cases']]==[x['id'] for x in bc['cases']]
reconciled_cp=insert(reconciled_cp,cp[('cases',0)][0],ms[mp[('cases',0)][0]:mp[('cases',1)][0]])
rc=json.loads(reconciled_cp)
assert rc['scope']==mc['scope'] and rc['execution']==mc['execution']
assert rc['sources']=={'slc-lsi-complexity-2026':mc['sources']['slc-lsi-complexity-2026'],**cc['sources']}
assert rc['cases']==[mc['cases'][0]]+cc['cases']
assert all(rc[k]==cc[k] for k in cc if k not in {'scope','execution','sources','cases'})
gi=next(i for i,x in enumerate(rc['cases']) if x['id']==GID);assert gi==5

branch_fh=git('show',C+':'+FH);main_fh=git('show',M+':'+FH)
fd,md=map(json.loads,[branch_fh,main_fh]);fi=next(i for i,x in enumerate(fd['objects']) if x['id']=='concept:lower');mi=next(i for i,x in enumerate(md['objects']) if x['id']=='concept:lower')
reconciled_fh=transplant(branch_fh,('objects',fi),token(main_fh,('objects',mi)))
added,oldfirst=mapping_prefix(main_fh,('sources',),'slc-lsi-complexity-2026')
reconciled_fh=prepend_mapping(reconciled_fh,('sources',),added,oldfirst)
rf=json.loads(reconciled_fh)
assert rf['objects'][fi]==md['objects'][mi]
assert rf['sources']=={'slc-lsi-complexity-2026':md['sources']['slc-lsi-complexity-2026'],**fd['sources']}
assert rf['hyperedges']==fd['hyperedges']
branch_js=git('show',C+':'+JS);reconciled_js=branch_js.replace(b'"concept:lower":"Lower bounds / SampleWiki"',b'"concept:lower":"Lower Bounds"')
assert sha(reconciled_js)=='c0db9c5b0a91ecbc267929436d2f58308238e208a3183a4937509a60339681f8'
incoming=git('diff','--name-only',B,M).decode().splitlines();branch=set(git('diff','--name-only',B,C).decode().splitlines())
overlap=sorted(set(incoming)&branch)
assert len(incoming)==34 and overlap==[FH,CP,JS]
delta=git('diff','--name-only',M1,M).decode().splitlines();assert len(delta)==17
assert not any(p.endswith('.lean') or p in ['lean-toolchain','lake-manifest.json'] for p in incoming)
preview=git('merge-tree',B,C,M);assert b'<<<<<<<' not in preview and b'>>>>>>>' not in preview
candidate_paths=set(git('ls-tree','-r','--name-only',C).decode().splitlines())
staged={FH:reconciled_fh,CP:reconciled_cp,JS:reconciled_js};arows=[];adiff=[]
for i,path in enumerate(incoming):
 main=git('show',M+':'+path);before=git('show',C+':'+path) if path in candidate_paths else None;after=staged.get(path,main)
 row={'path':path,'main':blob('stage-A/main/%02d.raw.gz'%i,main),'candidate':blob('stage-A/candidate/%02d.raw.gz'%i,before) if before is not None else None,'expected_merged_raw_sha256':sha(after),'strategy':'preserve both disjoint deltas' if path in overlap else 'take exact current-main blob'}
 if path in overlap:row['reconciled']=blob('stage-A/reconciled/%02d.raw.gz'%i,after)
 arows.append(row)
 adiff.extend(difflib.unified_diff((before or b'').decode().splitlines(keepends=True),after.decode().splitlines(keepends=True),fromfile='a/'+path if before is not None else '/dev/null',tofile='b/'+path))
data('stage-A/reconciliation-manifest.json',{'candidate':C,'main':M,'superseded_main':M1,'merge_base':B,'actual_merge_performed':False,'required_later_action':'Real sole-owner git merge of main95322, retaining its ancestry, then exact readback against expected reconciled bytes','incoming_paths':34,'main_only_paths':31,'overlap':overlap,'additional_paths_since_old_main':delta,'no_incoming_Lean_toolchain_manifest_changes':True,'governance_delta':'AGENTS has four subject-reader/source-lane instructions and blueprint workflow changes; preserved exactly, not claimed unchanged','merge_tree':blob('stage-A/three-argument-merge-tree.raw.gz',preview),'text_conflict_markers_found':False,'Gaussian_case_stable_id':GID,'Gaussian_case_index_after_main':gi,'rows':arows})
(O/'stage-A/reconciliation-exact.diff').write_bytes(''.join(adiff).encode())

rows=[];diff=[]
for i,oldrow in enumerate(old['rows']):
 path=oldrow['path'];before=archived(oldrow['before']) if oldrow['before'] else None;after=archived(oldrow['after'])
 row=copy.deepcopy(oldrow);row.pop('review_evidence_path_overlay',None)
 if path==CP:
  old_before=json.loads(before);old_after_raw=after
  before=reconciled_cp;after=before
  for rel in [('reader_guide',3),('theorems',1,'boundary')]:
   p0=('cases',4)+rel;p1=('cases',gi)+rel
   assert token(before,p1)==token(archived(oldrow['before']),p0)
   after=transplant(after,p1,token(old_after_raw,p0))
  changed=changes(json.loads(before),json.loads(after));assert changed==[['cases',5,'reader_guide',3],['cases',5,'theorems',1,'boundary']]
  for rel in [('reader_guide',3),('theorems',1,'boundary')]:
   assert token(after,('cases',gi)+rel)==token(old_after_raw,('cases',4)+rel)
  restored=after
  for rel in [('reader_guide',3),('theorems',1,'boundary')]:restored=transplant(restored,('cases',gi)+rel,token(before,('cases',gi)+rel))
  assert restored==before
  row['changed_json_paths']=changed;row['baseline']='expected real-main95322 reconciled bytes, stable Gaussian case ID'
 elif path==FH:
  old_before=before;old_after=after;before=reconciled_fh;after=before;ob=json.loads(old_before);oa=json.loads(old_after)
  for key in ['objects','hyperedges']:
   oldlast=len(ob[key])-1;newlast=len(oa[key])-1
   s,p=spans(old_after);text=s[p[(key,oldlast)][1]:p[(key,newlast)][1]]
   s,p=spans(after);after=insert(after,p[(key,oldlast)][1],text)
  oldlast=list(ob['sources'])[-1];newlast=list(oa['sources'])[-1]
  s,p=spans(old_after);text=s[p[('sources',oldlast)][1]:p[('sources',newlast)][1]]
  s,p=spans(after);after=insert(after,p[('sources',oldlast)][1],text)
  a=json.loads(after)
  assert a['objects']==oa['objects'] and a['hyperedges']==oa['hyperedges']
  assert a['sources']=={'slc-lsi-complexity-2026':md['sources']['slc-lsi-complexity-2026'],**oa['sources']}
  row['changed_json_paths']=changes(json.loads(before),a);row['baseline']='expected real-main95322 reconciled bytes including actual SLC-LSI citation and main Lower Bounds label/URL'
 else:
  assert path not in incoming
  assert after==archived(oldrow['after'])
 row['before']=blob('stage-B/before/%02d.raw.gz'%i,before) if before is not None else None
 row['after']=blob('stage-B/after/%02d.raw.gz'%i,after)
 row['unchanged_from_prior_public_path_composed_payload']=path not in [CP,FH]
 row['supersedes_raw_after_sha256']=oldrow['after']['raw_sha256']
 rows.append(row)
 diff.extend(difflib.unified_diff((before or b'').decode().splitlines(keepends=True),after.decode().splitlines(keepends=True),fromfile='a/'+path if before is not None else '/dev/null',tofile='b/'+path))
assert len(rows)==8 and sum(r['unchanged_from_prior_public_path_composed_payload'] for r in rows)==6
data('stage-B/payload-manifest.json',{'state':'CONDITIONAL_UNAPPLIED_MAIN95322_SUCCESSOR','candidate':C,'main_required_ancestor':M,'publication_binding_sha256':old['publication_binding_sha256'],'source_V_exists_at_preparation':False,'normal_state_at_preparation':'PROVED_LOCAL','STAB_performed':False,'prior_composed_manifest_sha256':sha((overlay/'composed-eight-payload-manifest.json').read_bytes()),'payload_count':8,'rebound_payload_count':2,'unchanged_payload_count':6,'case_stable_id':GID,'case_changed_paths':[['cases',5,'reader_guide',3],['cases',5,'theorems',1,'boundary']],'public_producer_direct_ASTIS_parents':[],'private_Test_direct_public_ASTIS_parents':old['private_Test_direct_public_ASTIS_parents'],'actual_public_review_evidence_paths_retained':True,'rows':rows})
(O/'stage-B/conditional-exact.diff').write_bytes(''.join(diff).encode())
new_models={r['path']:json.loads(gzip.decompress((O/r['after']['archive']).read_bytes())) for r in rows if r['path'] in [CP,FH]}
new_case=new_models[CP];oldcase=json.loads(archived(next(r for r in old['rows'] if r['path']==CP)['after']))
assert new_case['cases']==[mc['cases'][0]]+oldcase['cases']
assert new_case['execution']==mc['execution'] and new_case['sources']==rc['sources']
new_fh=new_models[FH];of=json.loads(archived(next(r for r in old['rows'] if r['path']==FH)['after']))
assert new_fh['objects']==of['objects'] and new_fh['hyperedges']==of['hyperedges']
for r in json.loads((overlay/'overlay-manifest.json').read_bytes())['actual_lossless_copies_independently_verified']:
 assert (R/r['original']).read_bytes()==(R/r['public']).read_bytes() and sha((R/r['public']).read_bytes())==r['sha256']
assert git('rev-parse','HEAD').decode().strip()==C and not git('status','--porcelain=v1','--untracked-files=no')
data('successor-checks.json',{'exact_old_proposal_and_public_path_overlay_preserved':True,'real_merge_not_performed':True,'current_main_total_incoming_paths':34,'current_main_only_paths':31,'overlap_count':3,'newmain_additional_paths':17,'no_incoming_Lean_toolchain_manifest_changes':True,'AGENTS_and_workflow_changes_explicitly_preserved':True,'new_case_and_all_main_execution_source_scope_fields_preserved':True,'Gaussian_case_index_old4_new5_derived_by_stable_id':True,'only_same_two_exact_C7_scalar_tokens_transplanted':True,'all_Functor_old_values_and_new_SLC_citation_preserved':True,'six_other_payloads_exactly_unchanged':True,'19_actual_public_evidence_copies_rechecked':True,'no_API_STAB_build_browser_OS_network_or_shared_write':True})
print(json.dumps({'stage_A_manifest_sha256':sha((O/'stage-A/reconciliation-manifest.json').read_bytes()),'stage_B_manifest_sha256':sha((O/'stage-B/payload-manifest.json').read_bytes()),'exact_diff_sha256':sha((O/'stage-B/conditional-exact.diff').read_bytes()),'reconciled_case_sha256':sha(reconciled_cp),'reconciled_Functor_sha256':sha(reconciled_fh)},indent=2))
