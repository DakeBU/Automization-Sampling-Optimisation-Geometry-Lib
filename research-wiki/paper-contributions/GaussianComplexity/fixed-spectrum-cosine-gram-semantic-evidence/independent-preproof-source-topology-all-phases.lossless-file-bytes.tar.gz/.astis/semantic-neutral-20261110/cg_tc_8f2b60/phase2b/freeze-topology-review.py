from pathlib import Path
import hashlib
import json
import os
import stat
from datetime import datetime, timezone

base=Path(__file__).resolve().parent
owner=base.parent
repo=Path('/Users/zhouhuanjian/ASTIS-GC')
rel='.astis/semantic-neutral-20261110/cg_tc_8f2b60/phase2b/'
prior_specs=[
 ('phase1','d67f2864ba332e90e91cc8ba16c09db822f5229e0526b9223e6e920b607bca91','phase1-freeze-receipt.json','c717be0ef061eb6e41b9c06c53003529523a8500fc3e6b4c0e9891c9bd0f320b'),
 ('phase2a','e78c5dbf9db6caa7d8751c3913ef761a4faa8a3f5976b0463110bc73ec55df7c','phase2a-freeze-receipt.json','c0da5191cc33574686d0e97f03f9052c5927cbac0844615771b57db6031ffb16')
]
prior=[]
for name,msha,rname,rsha in prior_specs:
    root=owner/name;mb=(root/'manifest.json').read_bytes()
    assert hashlib.sha256(mb).hexdigest()==msha,name
    m=json.loads(mb)
    for entry in m['artifacts']:
        p=root/entry['path'];b=p.read_bytes()
        assert len(b)==entry['bytes'] and hashlib.sha256(b).hexdigest()==entry['sha256'],str(p)
        assert stat.S_IMODE(p.stat().st_mode)==0o444,str(p)
    assert stat.S_IMODE((root/'manifest.json').stat().st_mode)==0o444
    assert stat.S_IMODE(root.stat().st_mode)==0o555
    rp=owner/rname
    assert hashlib.sha256(rp.read_bytes()).hexdigest()==rsha,rname
    assert stat.S_IMODE(rp.stat().st_mode)==0o444
    prior.append({'phase':name,'manifest_sha256':msha,'receipt_sha256':rsha,
                  'all_bytes_hashes_modes_unchanged':True,'files_0444':len(m['artifacts'])+1,'directory_mode':'0555'})
author=repo/'.astis/semantic-neutral-20261110/cg_sg_1d7a46'
author_checks=[]
for name,msha in [('phase1','ededc4db5669a328807c9e0fbf9f719fdc92df4257c878bafd343965e25fb00b'),
                  ('phase2','d96ad3ac8e44b7f0621d62c620c1c9e4f8e38b626fa4aa2a5b94a0aa0eb02fc9')]:
    mb=(author/(name+'_manifest.json')).read_bytes()
    assert hashlib.sha256(mb).hexdigest()==msha
    m=json.loads(mb)
    for x in m['files']:
        p=author/name/x['path'];b=p.read_bytes()
        assert len(b)==x['bytes'] and hashlib.sha256(b).hexdigest()==x['sha256']
        assert stat.S_IMODE(p.stat().st_mode)==0o444
    ds=[author/name]+[p for p in (author/name).rglob('*') if p.is_dir()]
    assert all(stat.S_IMODE(p.stat().st_mode)==0o555 for p in ds)
    author_checks.append({'phase':name,'manifest_sha256':msha,'original_files_unchanged':len(m['files']),'all_modes_match':True})
raw=(repo/'.astis/huanjian-resume-20261103/2610.20492v1.html').read_bytes()
assert len(raw)==951991
raw_sha=hashlib.sha256(raw).hexdigest()
assert raw_sha=='6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
decision=json.loads((base/'independent-topology-decision.json').read_bytes())
assert decision['decision']=='ACCEPT_BOUNDED_SOURCE_TOPOLOGY_WITH_OPEN_PROOFS'
assert not decision['material_HOLDs'] and not decision['required_author_repairs']

task='''Phase2a freeze收到，现PHASE2b可接authorSG。仅允许 .astis/semantic-neutral-20261110/cg_sg_1d7a46/phase1/ 全部原source-only artifacts，outer phase1_receipt.json SHA86869756bdcdb1dfe0a33cba6d572705ebee9c6784ecee5660db72c3c00bfd91；phase1 manifest SHAededc4db5669a328807c9e0fbf9f719fdc92df4257c878bafd343965e25fb00b，rawsourcegraph SHAc4b19d5410db563d3211b148277a34d2181cbf1133bef0b9932f0eb117ab5d4c、coverage SHAda152a145bb41d16bd224196e12a6feaad160afb3b7ee86d68ee6c8765532e05。以及该S/phase2/所有原typed-overlay artifacts，outer phase2_receipt.json SHA7b0e78a7cca3ba7ce39fe90f479cb0d264405e6e964b5714cdb0b2b29c6ff801，phase2 manifest SHAd96ad3ac8e44b7f0621d62c620c1c9e4f8e38b626fa4aa2a5b94a0aa0eb02fc9，typed_overlay.json SHAe91185a610e691520fa0ca329d329e42ec2a825a36a3a19167c802a9257fc6cd。可只在此精确SG根目录inventory找到author实际文件名，不搜全仓库。不要根W/C/process/intakeprepared/native/implementation/其他verdict。请独立对照你已冻结rawcognition+phase2a、rawpaper与authorgraph/coverage，逐项sourceproofspan/display/tbody/mathIDs和root ancestors exhaustiveness、EDGE polarity/AND vs alternative、权重正负范围/normalization/quantifiers/含q0、每个privateconsumer真实law/moment/integrability内部义务，不把sourceGraph当proof成功。明示source/math/input边界并提出真正遗漏/不支持节点/extra hypotheses/false closure的独立结论，允许HOLD不要迁就root。保留旧raw+type freezes原bytes，所有实际inputs/commands/exposure/失败/截断完整存新phase2b，文件0444/dir0555+manifest/receipt无hashcycle。冻结后暂停；不要修author原图或proof/API/sourceV/intake/global。'''
coord='''仅需有实质结论/需要额外input时给进展；目前你phase2b source coverage/topology还在复核，root没有开始目标Lean proof/API retrieval。是否存在需要author修的真HOLD，或还在整理完整freeze？请保留自己独立判定，不因root等待改变结论。后续prospective process审查必须在phase2b数学冻结后才送root历史/C/preparedscript，当前未开放。'''
status='''当前独立复核未发现三个bounded roots或四个private typed roots需要author修的实质HOLD：463 raw IDs（227 math IDs）逐span核验无缺/错；473覆盖行含10混合语义分句；7个typed root的raw祖先集合重算一致，actual-law/moments/integrability等内部义务仍明确open。正核完逐项数学评语并整理freeze。一个仅context级细节会明确限定：C6 Ex125的代数可由p12截断中心aI/0直接推出，original Gaussian mean→C6链接应读作centering解释/来源联系，不能被提升为Ex125必需的formal AND父边；它不在本包bounded roots闭合路径。未读prospective process历史/C/preparedscript。'''
(base/'communications.json').write_text(json.dumps([
 {'direction':'received','sender':'/root','kind':'NEW_TASK','body':task},
 {'direction':'received','sender':'/root','kind':'MESSAGE','body':coord},
 {'direction':'sent','recipient':'/root','tool':'collaboration.send_message','body':status},
 {'direction':'received','sender':'user','kind':'environment_context','body':'Current date changed to 2026-11-11, timezone Asia/Tokyo; same workspace/permission profile. No new mathematical/process input.'}
],ensure_ascii=False,indent=2)+'\n')

script_names=['read-author-inventory.py','read-author-manifests.py','read-selected-author-records.py',
              'compare-source-and-topology.py','inspect-resolved-coverage.py','read-author-definition-audit.py',
              'finalize-review-records.py','freeze-topology-review.py']
for target in script_names+['independent-topology-review.md']:
    snapshot='independent-topology-review-v1.md' if target=='independent-topology-review.md' else target
    patch='*** Begin Patch\n*** Add File: '+str(base/target)+'\n'+''.join('+'+line+'\n' for line in (base/snapshot).read_text().splitlines())+'*** End Patch'
    (base/(target+'-actual-addfile.patch')).write_text(patch)
events=[]
def patch(name):
    events.append({'tool':'apply_patch','input_artifact':name+'-actual-addfile.patch','observed_output':{}})
def command(script,args,stdout,chunk,tokens,**extra):
    events.append({'tool':'exec_command','cwd':str(repo),'command':'/opt/anaconda3/bin/python '+rel+script+(' '+args if args else ''),
       'stdout_artifact':stdout,'chunk_id':chunk,'exit_code':0,'original_token_count':tokens,**extra})
patch('read-author-inventory.py')
command('read-author-inventory.py','','read-author-inventory.stdout.txt','d59e73',10611,
        transport_truncation={'outer_warning_original_token_count':11424,'complete_stdout_saved_before_print':True,'not_assumed_read':'Missing visible inventory suffix was not used as mathematical reading; bounded reads followed.'})
patch('read-author-manifests.py')
command('read-author-manifests.py','','read-author-manifests.stdout.txt','1553d1',550,
        locator_note='Author manifests actually live at exact SG root; both actual names/hashes independently checked. Root filename inventory only; no other root-file content read.')
patch('read-selected-author-records.py')
command('read-selected-author-records.py','raw','read-author-raw.stdout.txt','23fb5a',6813)
command('read-selected-author-records.py','typed','read-author-typed.stdout.txt','e836dd',4816)
command('read-selected-author-records.py','coverage-schema','read-author-coverage-schema.stdout.txt','11b450',1700)
patch('compare-source-and-topology.py')
events.append({'tool':'exec_command','cwd':str(repo),'command':'/opt/anaconda3/bin/python '+rel+'compare-source-and-topology.py','chunk_id':'8af757','session_id':91628,'original_token_count':0,'initial_output':'','exit_code':'not yet returned; running session'})
events.append({'tool':'write_stdin','session_id':91628,'chars':'','yield_time_ms':1000,'chunk_id':'5aa87c','exit_code':0,'original_token_count':2818,'stdout_artifact':'compare-source-and-topology.stdout.txt'})
patch('inspect-resolved-coverage.py')
for mode,chunk,tokens in [('core1','4316d5',1529),('core2','6ca3c0',827),('core3','077e0e',851),('semantic','18923a',1270),('tail','256e0e',2859)]:
    command('inspect-resolved-coverage.py',mode,'inspect-coverage-'+mode+'.stdout.txt',chunk,tokens)
patch('read-author-definition-audit.py')
command('read-author-definition-audit.py','','read-author-definition-audit.stdout.txt','4be562',2215)
events.append({'tool':'collaboration.send_message','input_locator':'communications.json sent status entry','observed_output':{}})
patch('independent-topology-review.md')
patch('finalize-review-records.py')
command('finalize-review-records.py','','finalize-review-records.stdout.txt','df6c4b',69,
        mutation='Own review cosmetic expectation hyphen correction only; exact initial body preserved in independent-topology-review-v1.md and mutation script preserved.')
patch('freeze-topology-review.py')
events.append({'tool':'exec_command','cwd':str(repo),'command':'/opt/anaconda3/bin/python '+rel+'freeze-topology-review.py',
               'stdout_locator':'External phase2b-freeze-receipt.json and tool stdout hashes','exit_code_policy':'Failure aborts before receipt; success verifies all hashes/modes.'})
(base/'command-transcript.json').write_text(json.dumps({'stage':'PHASE2b','events':events,
 'failures':[],'stderr':'','transport_truncations':['Initial author inventory outer output; complete actual stdout saved and bounded review inputs subsequently displayed.'],
 'command_scope':'Source text/hash/JSON/span/reference/graph-closure audits and owned artifact packaging only; no theorem proof or API/native/sourceV command.'},ensure_ascii=False,indent=2)+'\n')

exposure={
 'prior_freezes':prior,'author_original_checks':author_checks,
 'author_file_inputs_inventory':'author-input-inventory.json','author_manifest_inputs':'author-manifest-input-checks.json',
 'semantic_author_inputs':['source_graph.json','coverage.json resolved per source region and semantic clauses','source_index.json for comparison against independent raw parser','typed_overlay.json','proof_obligations.json','binder_definition_audit.json'],
 'author_cognition_or_generator_rationale_semantically_used':False,
 'own_raw_and_type_freezes_completed_before_author_SG':True,
 'root_W_C_process_intake_prepared_or_native_read':False,
 'implementation_API_or_proof_read_or_run':False,'sourceV_or_global_action':False,'other_verdict_read':False,
 'root_status_message_exposure':'Coordination status only; full message retained in communications.json. No root process history/C/prepared script was received.',
 'author_originals_modified':False,'prior_freeze_bytes_or_modes_modified':False,
 'structural_checks_are_not_proof_success':True,'failures':[],'transport_issue':'Initial large inventory output truncated; full stdout preserved; bounded reads recovered all semantic review inputs.',
 'mathematical_decision':decision['decision'],'required_author_repairs':[],
 'next_action':'Pause after mathematical freeze. Prospective process evidence remains unreceived.'
}
(base/'exposure.json').write_text(json.dumps(exposure,ensure_ascii=False,indent=2)+'\n')

artifacts=[]
for f in sorted(base.rglob('*'),key=lambda p:str(p.relative_to(base))):
    if not f.is_file() or f==base/'manifest.json':continue
    b=f.read_bytes()
    artifacts.append({'path':str(f.relative_to(base)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'frozen_mode':'0444'})
manifest={
 'kind':'independent-source-topology-challenger-mathematical-freeze','stage':'PHASE2b',
 'source_raw_sha256':raw_sha,'prior_freezes':prior,'author_original_checks':author_checks,
 'decision':decision['decision'],'material_HOLDs':[],'required_author_repairs':[],
 'artifacts':artifacts,'permissions':{'artifact_files':'0444','all_phase2b_directories':'0555'},
 'no_hash_cycle':'Manifest excludes itself and external receipt; receipt hashes manifest and does not hash itself. Receipt SHA printed only.',
 'not_a_proof_or_process_verdict':True
}
(base/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
for f in base.rglob('*'):
    if f.is_file():os.chmod(f,0o444)
dirs=[base]+[d for d in base.rglob('*') if d.is_dir()]
for d in sorted(dirs,key=lambda p:len(p.parts),reverse=True):os.chmod(d,0o555)
for x in artifacts:
    f=base/x['path']
    assert hashlib.sha256(f.read_bytes()).hexdigest()==x['sha256']
    assert stat.S_IMODE(f.stat().st_mode)==0o444
assert stat.S_IMODE((base/'manifest.json').stat().st_mode)==0o444
assert all(stat.S_IMODE(d.stat().st_mode)==0o555 for d in dirs)
receipt={
 'kind':'PHASE2b-independent-mathematical-topology-freeze-receipt','utc':datetime.now(timezone.utc).isoformat(),
 'directory':str(base),'manifest_sha256':hashlib.sha256((base/'manifest.json').read_bytes()).hexdigest(),
 'review_md_sha256':hashlib.sha256((base/'independent-topology-review.md').read_bytes()).hexdigest(),
 'decision_json_sha256':hashlib.sha256((base/'independent-topology-decision.json').read_bytes()).hexdigest(),
 'decision':decision['decision'],'material_HOLDs':[],'required_author_repairs':[],
 'context_advisory':'C6 p17/Ex125 original-mean link is context/centering provenance, not a necessary formal AND edge; outside bounded roots.',
 'coverage':decision['source_coverage'],'nodes_reviewed':33,'core_AND_edges_reviewed':19,'typed_roots_reviewed':7,
 'all_artifact_hashes_match':True,'verified_files_0444':len(artifacts)+1,'verified_directories_0555':len(dirs),
 'own_prior_raw_and_type_freezes_unchanged':True,'author_original_files_and_modes_unchanged':True,
 'proof_or_API_or_native_or_sourceV_run':False,'root_process_history_or_preparedscript_received':False,
 'not_a_Lean_proof_or_process_verdict':True,'failures':[],
 'transport_truncation':'Initial inventory outer output only; complete stdout preserved and bounded semantic input rereads completed.',
 'freeze_command':'/opt/anaconda3/bin/python '+rel+'freeze-topology-review.py',
 'no_hash_cycle':'Receipt outside phase2b, excluded from manifest; its SHA returned only in tool output.',
 'next_action':'Pause. Mathematical phase frozen before any prospective process evidence.'
}
rp=owner/'phase2b-freeze-receipt.json'
rp.write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n');os.chmod(rp,0o444)
print(json.dumps({'receipt':str(rp),'receipt_sha256':hashlib.sha256(rp.read_bytes()).hexdigest(),**receipt},ensure_ascii=False,indent=2))
