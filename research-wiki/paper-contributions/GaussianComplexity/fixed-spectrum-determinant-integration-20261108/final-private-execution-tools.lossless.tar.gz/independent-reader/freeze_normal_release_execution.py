"""Freeze completed one-call mechanical release; never invoke or repeat its API."""
from pathlib import Path
import datetime, gzip, hashlib, json, subprocess
R=Path('/Users/zhouhuanjian/ASTIS-GC')
OWN=R/'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-determinant-integration-20261108/independent-integration-reader-review'
RELEASE=OWN/'normal-release';O=OWN/'normal-release-outer-execution';assert not O.exists()
S=R/'.astis/huanjian-gc-fixed-spectrum-determinant-integration-20261108/independent-reader'
outerpath=R/'.astis/huanjian-resume-20261103/20261108T053344120838Z-fixed-spectrum-determinant-normal-existing-V-parking.receipt.json'
summarypath=RELEASE/'release-summary.json';apipath=RELEASE/'normal-api-execution.receipt.json';protectionpath=RELEASE/'protection.json'
CORE='55b7b53921b430056db42ef04186d92074f0c49b';sha=lambda b:hashlib.sha256(b).hexdigest()
summary=json.loads(summarypath.read_bytes());api=json.loads(apipath.read_bytes());protection=json.loads(protectionpath.read_bytes());outer=json.loads(outerpath.read_bytes())
assert sha(summarypath.read_bytes())=='3a95114cf5efb3c227bce4c709ac59a443366b88eb41c2daf76dbf4d342ad0d3'
assert sha(apipath.read_bytes())==summary['actual_normal_API_receipt']['sha256']=='73398b573fa68c85d577b2c77748ca259ab8c1466606869d72b94e350439631c'
assert sha(protectionpath.read_bytes())==summary['protection']['sha256']=='45ee9bf2875314fbde1e914b3c74aa7f57cbb0deff2cf0bfe931fd2c824653e5'
assert summary['core']==CORE and summary['final_state']=='VERIFIED' and summary['normal_STAB_after']==[]
assert summary['new_source_verifications']==0 and summary['writes_stopped_after_summary'] is True
assert summary['proof_owner']=='huanjian_gc_20261108_fixed_spectrum_determinant' and summary['original_source_verifier']=='/root/reader_835194'
assert api['actual_API_calls']==1 and api['exit_code']==0 and api['error'] is None and api['new_source_verdict'] is False
assert api['head_before']==api['head_after']==outer['head_before']==outer['head_after']==CORE and outer['exit_code']==0
outerlog=Path(outer['log']);assert sha(outerlog.read_bytes())==outer['log_sha256']=='aace0a9294c8a4b5352ca9db5183c9839c7f5d545bd9b5aea1dbc504e48c884a'
append=(RELEASE/'advance-ledger.append.raw.jsonl').read_bytes();before=gzip.decompress((RELEASE/'advance-ledger.before.raw.jsonl.gz').read_bytes());after=gzip.decompress((RELEASE/'advance-ledger.after.raw.jsonl.gz').read_bytes())
assert len(append.splitlines())==1 and after==before+append and after==(R/'runs/substantive_advances.jsonl').read_bytes()
assert sha(append)==api['append_sha256']==summary['actual_unique_append_sha256']=='30dd3ede5a44ddc5370ceadec54eabac3482c22aebad594cc2c4534321461880'
assert len(append)==8564 and sha(after)==summary['ledger_after_sha256']=='eee4bd7f2341fe4e28ce96854a14a8f6b900b021e3ab8e9c171270aa146f5cb2'
event=json.loads(append);assert event['from_state']=='STABILIZING' and event['to_state']=='VERIFIED' and event['worker_id']=='/root/det_integration_reader'
assert event['evidence']['new_source_mathematical_or_semantic_verdict'] is False and event['evidence']['original_source_verifier_id']=='/root/reader_835194'
assert protection['all282_foreign_states_unchanged'] and protection['all442_frontiers_including441_foreign_byte_unchanged'] and protection['canonical_audit_cell_sixpaths_models_README_byte_unchanged']
assert gzip.decompress((RELEASE/'discovery-ledger.before.raw.jsonl.gz').read_bytes())==(R/'runs/substantive_discoveries.jsonl').read_bytes()
assert sha((S/'park_existing_verified_once.py').read_bytes())=='6084811247a131c6ce81ceaf5e33e60f040d376b538b6bc704820fa965271e32'
assert sha((S/'det_acceptance_common.py').read_bytes())=='f3fefccfd197588845241075f8fb28c4fd599460e070c03dcdd01efa2bebedc3'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==CORE
releasefiles={str(p.relative_to(R)):sha(p.read_bytes()) for p in sorted(RELEASE.iterdir()) if p.is_file()}
O.mkdir(exist_ok=False);rows=[]
for name,path in [('outer-command.receipt.json.raw.gz',outerpath),('outer-command.stdout.raw.gz',outerlog),('actual-API.receipt.json.raw.gz',apipath),('release-summary.json.raw.gz',summarypath),('protection.json.raw.gz',protectionpath),('executed-parking-helper.py.raw.gz',S/'park_existing_verified_once.py'),('executed-common-helper.py.raw.gz',S/'det_acceptance_common.py'),('freeze-driver.py.raw.gz',Path(__file__))]:
 raw=path.read_bytes();data=gzip.compress(raw,mtime=0);dest=O/name;assert not dest.exists();dest.write_bytes(data);assert gzip.decompress(data)==raw
 rows.append({'original':str(path.relative_to(R)),'raw_sha256':sha(raw),'raw_bytes':len(raw),'archive':str(dest.relative_to(R)),'archive_sha256':sha(data)})
freeze={'actor':'/root/det_integration_reader','recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'phase':'Actual exactlyone normal existing-V parking completed; outer log/source packaging only','core':CORE,'actual_normal_API_calls':1,'actual_API_elapsed_seconds':api['elapsed_seconds'],'outer_actual_command':outer['command'],'outer_actual_started_utc':outer['started_utc'],'outer_actual_exit_code':outer['exit_code'],'outer_actual_elapsed_seconds':outer['elapsed_seconds'],'outer_receipt_sha256':sha(outerpath.read_bytes()),'outer_raw_log_sha256':sha(outerlog.read_bytes()),'API_receipt_sha256':sha(apipath.read_bytes()),'API_raw_stdout_sha256':api['stdout']['sha256'],'summary_sha256':sha(summarypath.read_bytes()),'protection_sha256':sha(protectionpath.read_bytes()),'exact_append_bytes':len(append),'exact_append_sha256':sha(append),'ledger_after_sha256':sha(after),'final_state':'VERIFIED','STABILIZING_after':[],'proof_owner':summary['proof_owner'],'original_source_verifier':summary['original_source_verifier'],'new_source_verdicts':0,'normal_release_directory_all_file_hashes':releasefiles,'lossless_outer_evidence_archives':rows,'normal_release_directory_unchanged_during_outer_freeze':True,'no_new_API_build_browser_remote_shared_frontier_audit_README_actions':True,'overall_Goal_or_both_mainbounds_or_remote_publication_or_purification_complete':False,'stopped_after_freeze':True}
dest=O/'freeze.json';dest.write_text(json.dumps(freeze,ensure_ascii=False,indent=2)+'\n')
assert {str(p.relative_to(R)):sha(p.read_bytes()) for p in sorted(RELEASE.iterdir()) if p.is_file()}==releasefiles
print(json.dumps({'state':'NORMAL_EXISTING_V_PARKED','normal_API_calls':1,'summary_sha256':sha(summarypath.read_bytes()),'protection_sha256':sha(protectionpath.read_bytes()),'API_receipt_sha256':sha(apipath.read_bytes()),'outer_receipt_sha256':sha(outerpath.read_bytes()),'outer_freeze_sha256':sha(dest.read_bytes()),'append_sha256':sha(append),'ledger_after_sha256':sha(after),'STAB_after':[],'new_source_verdicts':0},indent=2))
