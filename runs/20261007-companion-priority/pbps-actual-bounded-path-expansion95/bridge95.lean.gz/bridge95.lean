import AutoSamplingTheory.ExampleCases.ProximalBPS.ActualPrescribedPathDensity
import Mathlib.MeasureTheory.Integral.Bochner.Set

open MeasureTheory Set Filter
open scoped ENNReal

private theorem signed_sector
    {X U J Y : Type*} [MeasurableSpace X] [MeasurableSpace U]
    [MeasurableSpace J] [MeasurableSpace Y]
    {μ : Measure X} {ν : Measure U} {H : X → J} {Z : X → Y}
    {K : U → J} {Γ : U → Y} {ρ : U → ℝ≥0∞} {wgt : U → ℝ}
    (hH : Measurable H) (hZ : Measurable Z) (hK : Measurable K)
    (hΓ : Measurable Γ) (hρ : Measurable ρ)
    (hw : ∀ t, 0 ≤ wgt t) (heq : ∀ t, ρ t = ENNReal.ofReal (wgt t))
    (hlaw : Measure.map (fun x => (H x, Z x)) μ =
      Measure.map (fun t => (K t, Γ t)) (ν.withDensity ρ))
    {F : Y → ℝ} (hF : Measurable F) (hi : Integrable (fun x => F (Z x)) μ) :
    Integrable (fun t => F (Γ t) * wgt t) ν ∧
      (∫ x, F (Z x) ∂μ) = ∫ t, F (Γ t) * wgt t ∂ν := by
  have hG : Measurable (fun q : J × Y => F q.2) := hF.comp measurable_snd
  have hiMap : Integrable (fun q : J × Y => F q.2)
      (Measure.map (fun x => (H x, Z x)) μ) :=
    (integrable_map_measure hG.aestronglyMeasurable
      (hH.prodMk hZ).aemeasurable).2 hi
  rw [hlaw] at hiMap
  have hiW : Integrable (fun t => F (Γ t)) (ν.withDensity ρ) :=
    (integrable_map_measure hG.aestronglyMeasurable
      (hK.prodMk hΓ).aemeasurable).1 hiMap
  have htop : ∀ᵐ t ∂ν, ρ t < ⊤ := Filter.Eventually.of_forall
    (fun t => by rw [heq]; exact ENNReal.ofReal_lt_top)
  have hreal (t : U) : (ρ t).toReal = wgt t := by
    rw [heq, ENNReal.toReal_ofReal (hw t)]
  refine ⟨?_, ?_⟩
  · simpa only [hreal, smul_eq_mul, mul_comm] using
      (integrable_withDensity_iff_integrable_smul' hρ htop).1 hiW
  · calc
      (∫ x, F (Z x) ∂μ) = ∫ q : J × Y, F q.2
          ∂Measure.map (fun x => (H x, Z x)) μ :=
        (integral_map (hH.prodMk hZ).aemeasurable hG.aestronglyMeasurable).symm
      _ = ∫ q : J × Y, F q.2
          ∂Measure.map (fun t => (K t, Γ t)) (ν.withDensity ρ) := by rw [hlaw]
      _ = ∫ t, F (Γ t) ∂ν.withDensity ρ :=
        integral_map (hK.prodMk hΓ).aemeasurable hG.aestronglyMeasurable
      _ = ∫ t, F (Γ t) * wgt t ∂ν := by
        simpa only [hreal, smul_eq_mul, mul_comm] using
          integral_withDensity_eq_integral_toReal_smul hρ htop (fun t => F (Γ t))

private theorem signed_count_partition {X : Type*} [MeasurableSpace X]
    {μ : Measure X} {N : X → ℕ} (hN : Measurable N)
    {f : X → ℝ} (hi : Integrable f μ) :
    Summable (fun n : ℕ => |∫ x in {x | N x = n}, f x ∂μ|) ∧
      (∫ x, f x ∂μ) = ∑' n : ℕ, ∫ x in {x | N x = n}, f x ∂μ := by
  have hU : (⋃ n : ℕ, {x | N x = n}) = univ := by ext x; simp
  have hd : Pairwise (fun i j : ℕ => Disjoint {x | N x = i} {x | N x = j}) := by
    intro i j hij
    exact Set.disjoint_left.mpr (fun x hi hj => hij (hi.symm.trans hj))
  have hsum := hasSum_integral_iUnion
    (fun n : ℕ => measurableSet_eq_fun hN measurable_const) hd hi.integrableOn
  rw [hU, Measure.restrict_univ] at hsum
  exact ⟨hsum.summable.abs, hsum.tsum_eq.symm⟩
