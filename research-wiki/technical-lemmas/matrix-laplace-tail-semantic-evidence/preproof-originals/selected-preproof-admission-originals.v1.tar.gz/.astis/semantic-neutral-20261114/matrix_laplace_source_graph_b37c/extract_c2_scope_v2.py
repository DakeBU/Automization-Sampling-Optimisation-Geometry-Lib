import json, runpy, pathlib
B=pathlib.Path(__file__).resolve().parent
d=runpy.run_path(str(B/'extract_source_stdlib.py'))
p=d['p']; Node=d['Node']; record=d['record']
root=p.ids['A3.SS2']
rows=[]
def walk(n):
    ident=n.attrs.get('id','')
    classes=n.attrs.get('class','')
    if n.tag=='div' and 'ltx_para' in classes:
        rows.append(record(n)); return
    if n.tag in ['h2','h3','h4','h5','h6']:
        rows.append(record(n)); return
    for c in n.children:
        if isinstance(c,Node): walk(c)
walk(root)
out={'source':'pinned original Gaussian HTML','scope':'A3.SS2 mathematical C2 proof subsection','rows':rows}
(B/'gaussian-C2-full-scope.raw.v2.json').write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n')
print('C2 FULL SCOPE')
for r in rows: print(r['id']+'\n'+r['text']+'\n')
