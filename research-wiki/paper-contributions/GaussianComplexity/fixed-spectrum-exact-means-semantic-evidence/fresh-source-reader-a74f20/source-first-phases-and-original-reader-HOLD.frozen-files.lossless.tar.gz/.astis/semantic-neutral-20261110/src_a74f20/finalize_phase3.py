from pathlib import Path
import json,hashlib,os,re,sys
sys.dont_write_bytecode=True
ROOT=Path('/Users/zhouhuanjian/ASTIS-GC');BASE=ROOT/'.astis/semantic-neutral-20261110/src_a74f20';OUT=BASE/'phase3'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,obj):
 p=OUT/name;p.write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n');return p
packet=json.loads((OUT/'canonical-reviewer-packet.json').read_text())
snapshot=json.loads((OUT/'snapshot-manifest.json').read_text())
env=json.loads((OUT/'environment-and-direct-cache.json').read_text())
assert all(p['matches'] for p in env['packages'])
for path,expected in [('phase1/freeze-manifest.json','5afcacc0ea702615faed565f8b99ed770d712c9839c1bedde12f9bd7ca4591db'),('phase2/freeze-manifest.json','74b7234b3956027167581a37b3f8ddbf59ca62cfdf2a962490d9a548fa31a7ad')]:assert sha(BASE/path)==expected
checks={}
for label in ['fresh-production-attempt2','fresh-test','fresh-kernel','fresh-definition-probe-attempt2']:
 p=OUT/(label+'.receipt.json');r=json.loads(p.read_text());assert r['exit_code']==0
 checks[label]={'receipt':str(p.relative_to(ROOT)),'receipt_sha256':sha(p),'stdout_sha256':r['stdout_sha256'],'exit_code':r['exit_code']}

sys.path.insert(0,str(ROOT/'tools'))
import astis_site as site
owned=[OUT/'native-src/AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumExactMeans.lean',OUT/'native-src/Tests/GaussianComplexityFixedSpectrumExactMeans.lean']
scan=[]
for p in owned:
 clean=site.sanitize_lean(p.read_text())
 hits=[token for token,pat in [('sorry',r'\bsorry\b'),('admit',r'\badmit\b'),('axiom',r'^\s*axiom\s'),('unsafe',r'\bunsafe\b'),('Prop:=True',r'Prop\s*:=\s*True'),('trivial closure',r':=\s*trivial\b'),('implemented_by',r'implemented_by'),('extern',r'\bextern\b')] if re.search(pat,clean,re.M)]
 scan.append({'path':str(p.relative_to(ROOT)),'sha256':sha(p),'hits':hits});assert not hits
write('fake-closure-static-scan.json',scan)

slots={
 'objects':{'original':'The literal midpoint cosine precision Lambda, U~N(0,Lambda inverse), D_n, M=E norm-square and mu_n=E U-transpose D_n U.','reconstructed':'The same fixed grid and precision, centered Gaussian measure with covariance Lambda inverse, actual Euclidean norm-square integral and actual coordinate quadratic integral.','relation':'equivalent','evidence':'Raw S4.SS1/Eq11, Lemma4.5 and Ex140; frozen phases1/2. Whole module and pinned constructor/Gaussian parent inspected. Independent native coordinate quadratic/norm/constructor-rfl probe passed.'},
 'domains':{'original':'d is an integer dimension >=2; kappa real >=2; integer 1<=n<d; coordinates1..d in real Euclidean space.','reconstructed':'d,n natural with2<=d and1<=n<d; kappa real>=2; Fin d real Euclidean coordinates0..d-1.','relation':'equivalent','evidence':'i_source=i_Fin+1 exactly converts the half-step grid; positive integer modes and natural modes in the stated range coincide. Natural exponent differences are guarded. No covariance totalization branch is used because literal eigenvalues>=1.'},
 'quantifiers':{'original':'For every admissible d,kappa,n and a random vector with the specified Gaussian law.','reconstructed':'For every admissible d,kappa,n, both equalities hold for the canonical measure representing that law.','relation':'equivalent','evidence':'Law-specific expectation and measure-integral presentations agree. Exact kernel root applications and all-owned type inventory confirm no omitted/scoped quantifier, oddness, query count or existence/asymptotic change.'},
 'assumptions':{'original':'d>=2,kappa>=2,1<=n<d and the literal family/Gaussian definitions; all analytic/scalar guards are proof obligations.','reconstructed':'Exactly the same four bound premises with transparent let definitions; integrability, positivity, convergence and denominator guards derived internally.','relation':'explicit-elaboration','evidence':'Public root has no certificate hypothesis. The private Summable F premise is discharged by produced hs0/hsN and materially consumed by hseries. Actual constructor domain/inversion and integrability are inherited from the invoked literal Gaussian parent. All owned bodies/types inspected.'},
 'conclusion':{'original':'Both actual exact means: M=(d/sqrt kappa)(1-r^(2d))/(1+r^(2d)); (-1)^n mu_n=(d/sqrt kappa)(r^n-r^(2d-n))/(1+r^(2d)).','reconstructed':'Both integrands are Bochner integrable and the same two exact identities hold for their actual integrals.','relation':'explicit-elaboration','evidence':'Source C8/Ex138,140-147; integrability is source-implicit Gaussian regularity made an output, never an assumption. Both formulas and their actual-integral meanings pass the sealed literal kernel check and independent source comparison.'},
 'scopes':{'original':'Exact actual two-mean C8 subtarget; p8.2/p9.1/Ex150 normalization uses only the base conditions. Later variance and gap-conditioned exponential branches are separate.','reconstructed':'Exact two means/integrability plus a private actual-integral consumer of positivity, first-mean upper bound, signed positivity and exact normalized ratio.','relation':'equivalent','evidence':'Private consumer defines m,b by the same actual integrals, materially uses both new output equalities, and has the exact sealed type. No expectation-of-ratio or absolute-value-inside-integral substitution; no full Lemma4.5 credit. Original reader consumer-adjacent-code HOLD is separately recorded.'},
 'constant_dependencies':{'original':'Exact half-grid factors, d/sqrt kappa,(-1)^n, r=(sqrt kappa-1)/(sqrt kappa+1), 2d and2d-n powers; private ratio exponent2(d-n).','reconstructed':'The same exact constants/exponents; grid depends on d, measure on d,kappa, Q on d,n, r on kappa.','relation':'same','evidence':'Source Ex138-147/150 and exact source signature. Period/parity and guarded Nat factorization are internal. No unspecified constant, variance coefficient or later exponential bound is silently added or credited.'}
}
deltas=[{'slot':'domains','severity':'informational','description':'One-based raw coordinates become Fin d coordinates with the exactly corresponding half-step angle; positive integer n becomes natural n.','evidence':'Explicit bijection i_source=i_Fin+1; 1<=n<d.'},{'slot':'conclusion','severity':'informational','description':'Both source-implicit actual Gaussian integrability facts are explicit conclusions.','evidence':'Pinned Gaussian parent proves coordinate second moments/integrability and finite expectation-to-grid exchange; no extra premise.'},{'slot':'scopes','severity':'informational','description':'This audit covers actual C8 means and private exact normalization, excluding full variance/exponential Lemma4.5 coverage.','evidence':'Frozen raw-first phase1 and exact producer/Test statements and source graph exclusions.'}]
report=OUT/'whole-module-source-native-reader-review.md'
static=OUT/'static-reader-checks.json'
review_run=write('review-run.json',{
 'reviewer':'/root/source_reader_a74f20','formalizer':packet['roles']['formalizer'],'decoder':packet['roles']['blind_decoder'],
 'checked_commit':'d823dddd8b7f203af3191b94ba2eb763fc0edc9b','canonical_reviewer_packet_sha256':packet['packet_sha256'],'raw_reviewer_packet_sha256':sha(OUT/'canonical-reviewer-packet.json'),'publication_binding_sha256':packet['publication_binding_sha256'],
 'phase1_manifest_sha256':sha(BASE/'phase1/freeze-manifest.json'),'phase2_manifest_sha256':sha(BASE/'phase2/freeze-manifest.json'),
 'source_native_status':'ACCEPT_BOUNDED_SOURCE_AND_NATIVE','static_reader_status':'HOLD_PRIVATE_CONSUMER_EXACT_ADJACENT_LEAN','report_sha256':sha(report),'static_reader_checks_sha256':sha(static),'fresh_checks':checks,
 'whole_module_sha256':'8dfb13585403a127830dfc841dafaf7e6f95057db10253f38b0ab7a66802b6c8','test_sha256':'d30744e67541fa07729002f06fde01f84a4fa1984b6f24d1014285db50ccc696','snapshot_manifest_sha256':sha(OUT/'snapshot-manifest.json'),'actual_transitive_cache_hashes_sha256':sha(OUT/'actual-transitive-dependency-cache-hashes.json'),'all_owned_inventory_sha256':sha(OUT/'all-owned-kernel-inventory.json'),
 'failures_retained':['Initial canonical-packet raw-hash assertion; resolved by canonical JSON hash without self-field.','Initial isolated production import failure; resolved by read-only dependency namespace overlay excluding candidate outputs.','Own definition probe initial missing MatrixOrder scope; resolved using the pinned constructor scoped order, with failed source/output preserved.'],
 'new_unapplied_reader_repair_message':'Path/hash received only; no repair content or manifest opened. Current checked binding remains original d823.','no_normal_V_or_canonical_mutation':True
})
proposal=write('canonical-audit-four-field-proposal.json',{
 'semantic_slots':slots,'deltas':deltas,'verdict':'equivalent-after-elaboration',
 'source_review':{'state':'accepted','reviewer':'/root/source_reader_a74f20','independent_from_formalizer':True,'independent_from_decoder':True,'reviewer_packet_sha256':packet['packet_sha256'],'review_run_sha256':sha(review_run),'run_artifact':str(review_run.relative_to(ROOT)),'evidence':str(report.relative_to(ROOT))+'; bounded source/native accepted; consumer-specific exact adjacent Lean reader HOLD preserved in static-reader-checks.json; no normal V/publication acceptance.','checked_commit':'d823dddd8b7f203af3191b94ba2eb763fc0edc9b','whole_module_sha256':'8dfb13585403a127830dfc841dafaf7e6f95057db10253f38b0ab7a66802b6c8','test_module_sha256':'d30744e67541fa07729002f06fde01f84a4fa1984b6f24d1014285db50ccc696','publication_binding_sha256':packet['publication_binding_sha256'],'static_reader_status':'HOLD_PRIVATE_CONSUMER_EXACT_ADJACENT_LEAN'}})
assert set(json.loads(proposal.read_text()))=={'semantic_slots','deltas','verdict','source_review'}
import astis_semantic_roundtrip_core as core
audit=json.loads((OUT/'native-src/research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-exact-means.json').read_text())
assert core.semantic_reviewer_packet(audit)['packet_sha256']==packet['packet_sha256']
write('proposal-packet-binding-check.json',{'actual_check':'Pure in-memory current semantic_reviewer_packet on exact candidate pending audit; no registry loader/global check or mutation.','canonical_packet_sha256':packet['packet_sha256'],'four_fields_only':True,'passes':True,'core_tool_sha256':sha(ROOT/'tools/astis_semantic_roundtrip_core.py')})
write('read-exposure.json',{
 'reviewer':'/root/source_reader_a74f20','phase':'3','authority':'Parent phase3 exact d823 module/proof/publication/sourcegraph/pinned-context/tools/focused-native/static review; no browser/normalV/remote/shared mutation.',
 'prior_freezes_preserved':True,'new_inputs':['Exact candidate git-show production/Test and three direct ASTIS parents','Canonical reviewer packet, original authored lesson/publication record, canonical pending audit and source-to-Lean map','Hash-bound source graph referenced by that map','Bounded all-owned kernel probe supplied at exact candidate commit','Pinned Mathlib constructor/covariance, WithLp coordinate and matrix multiplication context','Existing static-renderer and semantic-roundtrip validation tools','Existing dependency caches and package/toolchain metadata mechanically read/hashed'],
 'actual_exposure_evidence':'outer-tool-results.json and native command-bearing receipt/stdout/stderr files; snapshot-manifest.json records full-path exact candidate inputs.',
 'incidental_exposures':['git-show name-only commit listing includes other retained artifact/frontier/ledger paths; their contents were not opened.','Some initial combined packet/source-map output was truncated; exact source/module snapshots and later bounded semantic summaries supplied the needed content.','Original publication context contains formalizer assumption-delta/coverage claims; these were encountered only after independent phase1/2 froze and were independently checked. Canonical audit slots/verdict remained pending.','Parent named an unapplied lesson repair path/hash after the HOLD finding; its contents and manifest were not opened.'],
 'not_read':['Unbounded Expr repr probe or 2.29GB output','Prior source reviewer verdicts/repair decisions','Unapplied lesson repair candidate/manifest contents','Aggregate/global Registry/frontier/ledger contents','Browser or remote content'],
 'writes':'Only own review tree and tooling under src_a74f20. Own output symlinks point read-only at caches; no cached source/artifact writes.','non_actions':['No aggregate/shared/root/site/global build','No source/Lean/Test/lesson/shared/canonical edit','No normal V/STAB','No remote/network/browser/OS','No publication/Goal completion inference']})

# Freeze only physical reviewer-owned files, never follow read-only dependency symlinks.
files=[]
for parent,dirs,names in os.walk(OUT,followlinks=False):
 dirs[:]=[d for d in dirs if not (Path(parent)/d).is_symlink()]
 for name in names:
  p=Path(parent)/name
  if p.is_symlink() or name in {'freeze-manifest.json','seal-receipt.json'}:continue
  files.append(p)
files += [BASE/x for x in ['phase3_runner.py','static_phase3.py','bind_phase3_cache.py','finalize_phase3.py']]
files=sorted(files)
manifest=write('freeze-manifest.json',{'phase':'3','reviewer':'/root/source_reader_a74f20','checked_commit':'d823dddd8b7f203af3191b94ba2eb763fc0edc9b','status':'FROZEN_SOURCE_NATIVE_ACCEPT_READER_CONSUMER_HOLD','files':[{'path':str(p.relative_to(ROOT)),'sha256':sha(p),'bytes':p.stat().st_size} for p in files],'receipt_policy':'Separate post-seal receipt captures actual finalize command result; excluded to avoid self-reference. Dependency symlinks not followed: their backing artifact hashes are explicitly frozen in the actual transitive dependency cache hash inventory.','terminal_command':'python3 .astis/semantic-neutral-20261110/src_a74f20/finalize_phase3.py'})
print(json.dumps({'status':'FROZEN_SOURCE_NATIVE_ACCEPT_READER_CONSUMER_HOLD','manifest_sha256':sha(manifest),'review_run_sha256':sha(review_run),'four_field_proposal_sha256':sha(proposal),'detailed_review_sha256':sha(report),'static_reader_checks_sha256':sha(static),'file_count':len(files)},indent=2))
