"""Minimal successor: preserve compiler partial data, check only safe logical values; target closure remains strict."""
from native_common import *
import difflib

def main():
    old=OWN/'harness-v2';new=OWN/'harness-v3';new.mkdir(exist_ok=False)
    (new/'NativeLiteralApplications.lean').write_bytes((old/'NativeLiteralApplications.lean').read_bytes())
    s=(old/'NativeAudit.lean').read_text()
    s=s.replace('/native-raw-roundtrip"','/native-raw-roundtrip-v3"')
    s=s.replace('    let mut values := 0','    let mut values := 0\n    let mut checkedValues := 0\n    let mut compilerPartial : Array String := #[]')
    s=s.replace('        checkValue env v c.type','        if !c.isPartial && !c.isUnsafe then\n          checkValue env v c.type\n          checkedValues := checkedValues + 1\n        else\n          compilerPartial := compilerPartial.push c.name.toString')
    s=s.replace('(\"unsafe\", toJson c.isUnsafe),','(\"unsafe\", toJson c.isUnsafe), (\"partial\", toJson c.isPartial),')
    s=s.replace('(\"kernel_value_checked\", toJson valueId.isNull.not)','(\"kernel_value_checked\", toJson (!valueId.isNull && !c.isPartial && !c.isUnsafe))')
    s=s.replace('        checkValue env decoded[valueId]! decoded[typeId]!','        if !c.isPartial && !c.isUnsafe then\n          checkValue env decoded[valueId]! decoded[typeId]!')
    s=s.replace('(\"checked_values\", toJson values),','(\"raw_values\", toJson values), (\"checked_values\", toJson checkedValues),\n      (\"compiler_partial_or_unsafe_values_not_kernel_checked\", toJson compilerPartial),')
    s=s.replace('(\"JSON_DAG_full_structural_roundtrip_and_decoded_value_kernel_checks\", toJson true),','(\"JSON_DAG_full_structural_roundtrip\", toJson true),\n    (\"safe_logical_decoded_value_kernel_checks\", toJson true),\n    (\"partial_compiler_implementations_preserved_but_not_claimed_kernel_checked\", toJson true),')
    assert s!=(old/'NativeAudit.lean').read_text()
    (new/'NativeAudit.lean').write_text(s)
    g=(old/'NativeTransitiveGraph.lean').read_text()
    g=g.replace('    let td := c.type.getUsedConstants','    if c.isUnsafe || c.isPartial then\n      throwError "Unsafe or partial declaration in actual target logical closure: {n}"\n    let td := c.type.getUsedConstants')
    g=g.replace('(\"is_unsafe\", toJson c.isUnsafe)]','(\"is_unsafe\", toJson c.isUnsafe), (\"is_partial\", toJson c.isPartial)]')
    g=g.replace('/complete-transitive-type-value-graph.json"','/complete-transitive-type-value-graph.v3.json"')
    (new/'NativeTransitiveGraph.lean').write_text(g)
    delta=''
    for n in ['NativeLiteralApplications.lean','NativeAudit.lean','NativeTransitiveGraph.lean']:
        delta+=''.join(difflib.unified_diff((old/n).read_text().splitlines(True),(new/n).read_text().splitlines(True),fromfile='harness-v2/'+n,tofile='harness-v3/'+n))
    (OWN/'harness-v3-classification.exact.diff').write_text(delta)
    write_json(OWN/'harness-v3-classification-rationale.json',{'candidate_commit':COMMIT,'predecessor_exit':1,'predecessor_failure':'Canonical run compiler-generated ._unsafe_rec partial executable value cannot be checked as a safe logical declaration. The old all-raw-value kernel call stopped, so no old raw-complete verdict is reused.','changes':'All raw declarations and full Expr/Level/metadata retained and round-tripped. Record actual partial status. Safe logical values still get original and decoded kernel checks. Compiler partial/unsafe value bodies are explicitly not claimed kernel checked. Full actual P/T recursive closure throws on either unsafe or partial. Literal/application harness byte-identical and its successful fresh olean reused only from this R18 assignment.','ASTIS_production_changes':0,'ASTIS_recompiles_for_classification_change':0,'old_raw_diagnostic_graph_and_failed_streams_preserved':True,'old_audit_sha256':file_sha(old/'NativeAudit.lean'),'new_audit_sha256':file_sha(new/'NativeAudit.lean'),'old_graph_sha256':file_sha(old/'NativeTransitiveGraph.lean'),'new_graph_sha256':file_sha(new/'NativeTransitiveGraph.lean'),'exact_diff_sha256':file_sha(OWN/'harness-v3-classification.exact.diff')})
    packages=json.loads((OWN/'verified-package-inputs.json').read_text());env=lean_env(packages['packages']);flags=[str(LEAN),'-DmaxRecDepth=32768','-DmaxHeartbeats=0','-Ddebug.skipKernelTC=false']
    commands=[{'id':'strict-logical-recursive-graph-v3','argv':flags+['--run',str(new/'NativeTransitiveGraph.lean')]},{'id':'lossless-allraw-safe-logical-kernel-v3','argv':flags+['--run',str(new/'NativeAudit.lean')]}]
    write_json(OWN/'harness-v3-commands.json',commands)
    files=list(new.iterdir())+[OWN/'prepare_harness_v3.py',OWN/'native_common.py',OWN/'harness-v3-classification.exact.diff',OWN/'harness-v3-classification-rationale.json',OWN/'harness-v3-commands.json']+[f for f in OUT.rglob('*') if f.is_file()]
    assignment={'candidate_commit':COMMIT,'inputs':[{'path':str(f.relative_to(OWN)),'sha256':file_sha(f)} for f in files]};write_json(OWN/'harness-v3-assignment.json',assignment)
    for c in commands:
        for r in assignment['inputs']:assert file_sha(OWN/r['path'])==r['sha256']
        run(c['id'],c['argv'],cwd=new,env=env)
    write_json(OWN/'harness-v3-completed.json',{'candidate_commit':COMMIT,'all_actual_exit_zero':True,'literal_and_boundaries_actual_v2_exit_zero_preserved':True,'all_raw_lossless_and_safe_logical_kernel_checked':True,'strict_target_recursive_unsafe_and_partial_zero':True})
if __name__=='__main__':main()
