# Source slice extraction and checks

Working directory for each command was `/Users/zhouhuanjian/ASTIS-GC`. The commands below ran against the pinned original HTML, the source protocol and the existing broad source-only scope files.

- `shasum -a 256 .astis/huanjian-resume-20261103/2610.20492v1.html .astis/semantic-neutral-20261110/re_sg_b71f20/phase1/source-graph.json .astis/semantic-neutral-20261110/re_sg_b71f20/phase1/coverage.json` returned `6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915`, `5cfcf774e44a2ca4a6f3656a30034a6f0bda1ccc04ce3d3fd40788e786bbfc57` and `502d2b23593418bb73607f3d1144cb3c584362eedb791503848bb3ece178173b`, respectively. The broad coverage record reports 447 items. This increment uses its outer scope and independently inventories the four local paragraphs.
- `cat docs/proof-digestion-protocol.md` exposed the source-topology, exclusion, use-site and omitted-bridge requirements. `shasum -a 256 docs/proof-digestion-protocol.md` returned `9872e5af21c382278eb2c0e9fa16bbe15741261464b13b3b79764462fc6ffb0b`.
- `sed -n '3316,3329p;3532,3607p' .astis/huanjian-resume-20261103/2610.20492v1.html` printed the original p1 setup and p10–p12 markup, including the Ex104–Ex110 math annotations and C.5 link. The extractor uses source lines 3317–3329 and 3532–3607 with the original LF convention.
- The initial extractor encountered a name collision with the standard HTML parser's `offset` attribute. Renaming the method to `source_offset` fixed the run. The locator checker then caught the common-$a$ edge still pointing to a prose wrapper. The final graph points directly to its sentence fragment.

The final generation and check command was

```sh
python3 .astis/semantic-neutral-20261110/rm_sg_41bf/phase1/build_source_slice.py && python3 .astis/semantic-neutral-20261110/rm_sg_41bf/phase1/check_source_slice.py
```

It exited 0 with this output.

```text
Verified 3 input pins, 951991 source bytes, 942139 Unicode codepoints.
Wrote 28 graph nodes (10 gaps), 19 immediate hyperedges, 8 roots.
Classified 79 exact raw locators: 27 NODE and 52 EXCLUDED.
Revalidated 79 byte/character spans, 19 hyperedges and scalar closure checks.
A3.Ex106.m2#identity line 3566 [804036,804106) 4b494b58ab315ac5c6465cbfab4eff63f4378b03024a2800150c91a2816c7ac6
A3.Ex106.m2#bound line 3566 [804106,804127) d0c042bc1fce25fdf1076e59cc925aaf844ce1cec009f87ee484d860c9237e98
A3.Ex108.m1#a line 3584 [807125,807183) 051cad5e44d1279d28667895a0affa2c8daf5c7b2f1a9fedf6cf66b819f0f032
A3.Ex109.m1#identity line 3593 [809440,809499) a179a9deec89b3ad342bcf8e0bee25041baaa3555e7b5f4bdfadbcd56513d842
A3.Ex109.m1#bound line 3593 [809499,809521) 3ad4d0c86193b2c1330c336ab6b832df0ea8ea06600009ae5236a5c5aef6c8da
```

The mechanical checks cover locators and dependency structure. The independent reviewer owns source topology approval.
