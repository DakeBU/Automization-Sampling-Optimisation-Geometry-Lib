from pathlib import Path
from datetime import datetime,timezone
import subprocess,sys,json,hashlib
BASE=Path(__file__).resolve().parent
REPO=Path('/Users/zhouhuanjian/ASTIS-GC')
label=sys.argv[1]
argv=sys.argv[2:]
r=subprocess.run(argv,cwd=REPO,capture_output=True)
for ext,data in [('stdout',r.stdout),('stderr',r.stderr)]:
    (BASE/'tool_records'/(label+'.'+ext)).write_bytes(data)
rec={'argv':argv,'cwd':str(REPO),'returncode':r.returncode,'time_utc':datetime.now(timezone.utc).isoformat(),'stdout_bytes':len(r.stdout),'stdout_sha256':hashlib.sha256(r.stdout).hexdigest(),'stderr_bytes':len(r.stderr),'stderr_sha256':hashlib.sha256(r.stderr).hexdigest()}
(BASE/'tool_records'/(label+'.command.json')).write_text(json.dumps(rec,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(rec,ensure_ascii=False))
sys.stdout.flush()
sys.stdout.buffer.write(r.stdout)
sys.stderr.buffer.write(r.stderr)
sys.exit(r.returncode)
