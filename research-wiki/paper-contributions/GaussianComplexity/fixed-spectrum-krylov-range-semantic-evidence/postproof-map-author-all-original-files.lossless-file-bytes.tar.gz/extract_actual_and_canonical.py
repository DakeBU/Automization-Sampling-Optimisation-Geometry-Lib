from pathlib import Path
import re,json,hashlib
ROOT=Path(__file__).resolve().parent;REPO=ROOT.parents[2];I=ROOT/'input-originals'
sha=lambda b:hashlib.sha256(b).hexdigest()
dump=lambda n,x:(ROOT/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def span(file,b,a,z):
    s=b.decode();raw=s[a:z].encode()
    return {'file':str(file),'file_raw_sha256':sha(b),'character_span_0based_halfopen':[a,z],'utf8_byte_span_0based_halfopen':[len(s[:a].encode()),len(s[:z].encode())],'lf_lines_1based_inclusive':[s.count('\n',0,a)+1,s.count('\n',0,z-1)+1],'raw_span_sha256':sha(raw),'terminal_LF_included':raw.endswith(b'\n'),'exact_contiguous':True}
log=(I/'kernel-log.log').read_bytes();text=log.decode();records=[]
for m in re.finditer(r'OWNED_DECL_USED ([^:\n]+): \[(.*?)\]',text,re.S):
    constants=[x.strip() for x in m[2].split(',') if x.strip()]
    z=m.end()+(m.end()<len(text) and text[m.end()]=='\n')
    records.append({'owned_declaration':m[1],'direct_proof_term_constants':constants,'raw_log_record_span':span(I/'kernel-log.log',log,m.start(),z)})
assert len(records)==4
used=set().union(*(set(x['direct_proof_term_constants']) for x in records))
parents=[]
for m in re.finditer(r'ACTUAL_PUBLIC_ASTIS_PARENTS ([^:\n]+): \[(.*?)\]',text,re.S):
    parents.append({'consumer':m[1],'first_public_ASTIS_parents':[x.strip() for x in m[2].split(',') if x.strip()],'raw_log_span':span(I/'kernel-log.log',log,m.start(),m.end())})
dump('actual-kernel-constant-inventory.json',{'scope':'Exact direct proof-term constants from the supplied bounded kernel log. Owned recursive/public-parent traversal is performed by the supplied probe, not by source topology. No new Lean execution or independent verification was performed by this mapping author.','owned_declarations':records,'observed_first_public_ASTIS_parents':parents,'unique_direct_constants':len(used),'raw_log_sha256':sha(log),'generated_owned_providers':[x['owned_declaration'] for x in records if x['owned_declaration'].endswith(('._proof_1_1','._simp_1_1'))],'public_mathematical_nodes_for_generated_providers':False})

# Every locator below was obtained from an exact actual-used constant query.
# Canonical declarations are mapping inputs, never proof-search candidates.
M='.lake/packages/mathlib/Mathlib/'
specs=[
('Polynomial.degree_C_mul','Algebra/Polynomial/Degree/Lemmas.lean',370,'basis'),
('Polynomial.degree_X_sub_C','Algebra/Polynomial/Degree/Operations.lean',756,'basis'),
('Polynomial.degree_pow','Algebra/Polynomial/Degree/Operations.lean',689,'basis'),
('Polynomial.degree_X','Algebra/Polynomial/Degree/Defs.lean',261,'basis'),
('Polynomial.degree_comp','Algebra/Polynomial/Degree/Lemmas.lean',432,'basis'),
('Polynomial.Chebyshev.degree_T','RingTheory/Polynomial/Chebyshev.lean',208,'basis'),
('Polynomial.Sequence.degree_eq','Algebra/Polynomial/Sequence.lean',66,'basis'),
('Polynomial.Sequence.ne_zero','Algebra/Polynomial/Sequence.lean',74,'basis'),
('Polynomial.Sequence.span_degreeLT','Algebra/Polynomial/Sequence.lean',90,'basis'),
('Polynomial.leadingCoeff_ne_zero','Algebra/Polynomial/Degree/Defs.lean',360,'basis'),
('isUnit_iff_ne_zero','Algebra/GroupWithZero/Units/Basic.lean',264,'basis'),
('Polynomial.mem_degreeLT','RingTheory/Polynomial/Basic.lean',88,'basis'),
('Polynomial.eval_add','Algebra/Polynomial/Eval/Defs.lean',307,'evaluation'),
('Polynomial.eval_smul','Algebra/Polynomial/Eval/SMul.lean',58,'evaluation'),
('Polynomial.eval_pow','Algebra/Polynomial/Eval/Defs.lean',624,'evaluation'),
('Polynomial.eval_X','Algebra/Polynomial/Eval/Defs.lean',295,'evaluation'),
('Polynomial.eval_mul','Algebra/Polynomial/Eval/Defs.lean',612,'evaluation'),
('Polynomial.eval_C','Algebra/Polynomial/Eval/Defs.lean',283,'evaluation'),
('Polynomial.eval_sub','Algebra/Polynomial/Eval/Defs.lean',766,'evaluation'),
('Polynomial.eval_comp','Algebra/Polynomial/Eval/Defs.lean',628,'evaluation'),
('Polynomial.Chebyshev.T_real_cos','Analysis/SpecialFunctions/Trigonometric/Chebyshev/Basic.lean',150,'evaluation'),
('inv_mul_cancel_left₀','Algebra/GroupWithZero/Basic.lean',366,'evaluation'),
('Matrix.diagonal_pow','Data/Matrix/Basic.lean',180,'matrix'),
('Matrix.mulVec_diagonal','Data/Matrix/Mul.lean',752,'matrix'),
('Matrix.range_mulVecLin','LinearAlgebra/Matrix/ToLin.lean',342,'matrix'),
('Submodule.span_le','LinearAlgebra/Span/Defs.lean',82,'matrix'),
('Submodule.subset_span','LinearAlgebra/Span/Defs.lean',77,'matrix'),
('Submodule.smul_mem_iff','Algebra/Module/Submodule/Basic.lean',173,'matrix'),
('Submodule.smul_mem','Algebra/Module/Submodule/Defs.lean',214,'matrix'),
('Real.sqrt_ne_zero\'','Analysis/Real/Sqrt.lean',273,'normalization'),
('inv_ne_zero','Algebra/GroupWithZero/NeZero.lean',48,'normalization'),
('EuclideanSpace.inner_toLp_toLp','Analysis/InnerProductSpace/PiL2.lean',218,'metric'),
('Matrix.dotProduct_transpose_mulVec','Data/Matrix/Mul.lean',1098,'metric'),
('real_inner_self_eq_norm_sq','Analysis/InnerProductSpace/Basic.lean',396,'metric'),
('Matrix.mulVec_mulVec','Data/Matrix/Mul.lean',879,'metric'),
('TrivialStar.star_trivial','Algebra/Star/Basic.lean',118,'metric'),
('Set.range','Data/Set/Operations.lean',174,'definitions'),
('Submodule.span','LinearAlgebra/Span/Defs.lean',48,'definitions'),
('Matrix.diagonal','Data/Matrix/Diagonal.lean',50,'definitions'),
('Matrix.mulVec','Data/Matrix/Mul.lean',698,'definitions'),
('dotProduct','Data/Matrix/Mul.lean',72,'definitions'),
('Matrix.transpose','LinearAlgebra/Matrix/Defs.lean',172,'definitions'),
('Matrix.col','LinearAlgebra/Matrix/Defs.lean',608,'definitions'),
('Matrix.mulVecLin','LinearAlgebra/Matrix/ToLin.lean',286,'definitions'),
('LinearMap.range','Algebra/Module/Submodule/Range.lean',57,'definitions'),
('Submodule.comap','Algebra/Module/Submodule/Map.lean',172,'definitions'),
('Polynomial.Sequence','Algebra/Polynomial/Sequence.lean',45,'definitions'),
('Polynomial.degreeLT','RingTheory/Polynomial/Basic.lean',56,'definitions'),
('EuclideanSpace','Analysis/InnerProductSpace/PiL2.lean',113,'definitions'),
('WithLp','Analysis/Normed/Lp/WithLp.lean',50,'definitions')]
out=ROOT/'canonical-declaration-spans';out.mkdir(exist_ok=True)
command=re.compile(r'^(?:@\[|/--|/-!|namespace\b|end\b|section\b|variable\b|attribute\b|(?:noncomputable\s+|protected\s+|private\s+)*(?:theorem|lemma|def|abbrev|structure|class|instance|example|notation|local notation)\b)')
canonical=[]
for ordinal,(name,rel,line,group) in enumerate(specs):
    assert name in used,(name,'not in actual proof constant inventory')
    path=REPO/(M+rel);b=path.read_bytes();s=b.decode();lines=s.splitlines(keepends=True);k=line-1
    short='TrivialStar' if name=='TrivialStar.star_trivial' else name.rsplit('.',1)[-1]
    assert re.search(r'\b'+re.escape(short)+r'(?![\w\u2080-\u2089])',lines[k]),(name,line,lines[k])
    a=sum(len(x) for x in lines[:k]);j=k+1
    while j<len(lines) and not command.match(lines[j]):j+=1
    while j>k+1 and not lines[j-1].strip():j-=1
    z=sum(len(x) for x in lines[:j]);raw=s[a:z].encode()
    rec={'name':name,'group':group,'actual_direct_in':[x['owned_declaration'] for x in records if name in x['direct_proof_term_constants']],'span':span(path,b,a,z),'snapshot_path':str((out/(str(ordinal)+'.lean')).relative_to(ROOT)),'enclosing_declaration_note':'Class declaration includes actual field star_trivial' if name=='TrivialStar.star_trivial' else None}
    (out/(str(ordinal)+'.lean')).write_bytes(raw);canonical.append(rec)
dump('canonical-declaration-inventory.json',{'criterion':'Named constants actually present in proof terms, with exact canonical source declaration spans. This is the meaningful representation/basis/normalization/metric inventory, not an imports list. Routine arithmetic/index identities and typing/automation constants are separately classified exhaustively.','records':canonical,'wholefile_hashing':'Canonical source files read only for exact selected actual declarations and their raw file hashes; unrelated matches from locator queries are not adopted.'})
for group in sorted({x['group'] for x in canonical}):
    content=[]
    for rec in canonical:
        if rec['group']==group:content.extend([rec['name']+' | '+str(rec['span']['lf_lines_1based_inclusive']), (ROOT/rec['snapshot_path']).read_text()])
    (ROOT/('canonical-readable-'+group+'.txt')).write_text('\n'.join(content))
print(json.dumps({'owned_declarations':len(records),'unique_actual_constants':len(used),'canonical_selected_actual_declarations':len(canonical),'groups':{x:sum(r['group']==x for r in canonical) for x in sorted({r['group'] for r in canonical})},'selection':'actual proof constants only, no imports/proof-search inference'},indent=2))
