#!/usr/bin/env python3
"""Freeze explicit hash-bound metadata, then render a bounded original/candidate pair.

No Lean build, whole-site build, browser, network, server, normal API, production
mutation or Git mutation. A metadata successor must use a fresh output directory.
"""
from __future__ import annotations

import argparse
import ast
import difflib
from html import escape
from html.parser import HTMLParser
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
from urllib.parse import quote

sys.dont_write_bytecode = True
OWN = Path(__file__).resolve().parent
ROOT = Path('/Users/zhouhuanjian/ASTIS-GC')
COMMIT = '4869db55d340cee39f0ba4d49fb0a7a4309ba2d6'
ITEM = 'huanjian-matrix-bernstein-mgf'
PFILE = 'AutoSamplingTheory/TechnicalLemmas/Probability/MatrixBernsteinMgf.lean'
TFILE = 'Tests/GaussianComplexityBernsteinWeightedMgf.lean'
P = 'AutoSamplingTheory.TechnicalLemmas.Probability.MatrixBernsteinMgf.centered_bounded_matrix_mgf'
T = 'AutoSamplingTheory.Tests.GaussianComplexityBernsteinWeightedMgf.actual_source_weighted_normalized_single_summand_mgf'
PARENTS = {
    'AutoSamplingTheory.TechnicalLemmas.Probability.MatrixBernsteinExponential.bernstein_exponential_quadratic_bound': 'AutoSamplingTheory/TechnicalLemmas/Probability/MatrixBernsteinExponential.lean',
    'AutoSamplingTheory.TechnicalLemmas.Probability.RealMatrixPositiveIntegral.integral_posSemidef': 'AutoSamplingTheory/TechnicalLemmas/Probability/RealMatrixPositiveIntegral.lean',
    'AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumSourceMatrixRadius.actual_source_truncated_matrix_norm_bounds': 'AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumSourceMatrixRadius.lean',
    'AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumSourceMatrixStructure.actual_source_centered_matrix_structure': 'AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumSourceMatrixStructure.lean',
}
OLD = ROOT / '.astis/semantic-neutral-20261114/bernstein_exp_native_72c4'
OLD_MANIFEST = OLD / 'reader-9a8b163f/reader-originals-manifest.json'
SNAP = OWN / 'input-snapshot'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def json_bytes(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode()


def frozen(path):
    return subprocess.run(['git', 'show', f'{COMMIT}:{path}'], cwd=ROOT,
        env=dict(os.environ, GIT_OPTIONAL_LOCKS='0'), capture_output=True, check=True).stdout


def inputs(args):
    manifest_path = OWN / 'input-freeze-manifest.json'
    if manifest_path.exists():
        manifest = json.loads(manifest_path.read_text())
        if manifest['lesson_sha256'] != args.lesson_sha256 or manifest['publication_sha256'] != args.publication_sha256:
            raise ValueError('Metadata successor requires a fresh own preview directory')
        for row in manifest['files']:
            if sha((SNAP / row['path']).read_bytes()) != row['sha256']:
                raise ValueError('Frozen input changed: ' + row['path'])
        return manifest
    if SNAP.exists():
        raise ValueError('Partial input snapshot exists; preserve it and use a fresh own directory')
    lesson_data, publication_data = args.lesson.read_bytes(), args.publication.read_bytes()
    if sha(lesson_data) != args.lesson_sha256 or sha(publication_data) != args.publication_sha256:
        raise ValueError('Explicit metadata hash mismatch; no preview generated')
    unit = json.loads(lesson_data)['units'][0]
    item = json.loads(publication_data)['items'][0]
    if unit['declaration'] != P or item['id'] != ITEM or [b['declaration'] for b in item['bindings']] != [P]:
        raise ValueError('Expected only the selected public MGF unit/binding')
    previous = json.loads(OLD_MANIFEST.read_text())
    selected = [row['path'] for row in previous['files']
        if row['path'].endswith('.py') or row['path'].startswith('website/static/')
        or row['path'] in ('lean-toolchain', 'lake-manifest.json')]
    files = {}
    for path in selected:
        files[path] = (ROOT / path).read_bytes()
    for path in [PFILE, TFILE, *PARENTS.values()]:
        files[path] = frozen(path)
    if sha(files[PFILE]) != 'b46bb5a3eabbcadf31fee93d48c1fbabf9b5b42cf717a8a17c8c8cfdd210a3f3':
        raise ValueError('Frozen P source mismatch')
    if sha(files[TFILE]) != '42f372143ffe52e4372271d09fbc6b67391739f2fe2a5fbfffe6cd9fa586936e':
        raise ValueError('Frozen T source mismatch')
    for path in [PFILE, TFILE]:
        joined = ''.join(s['lean'] for s in unit['steps'] if s['lean_source_path'] == path).encode()
        if joined != files[path]:
            raise ValueError('Metadata code folds are not the exact complete frozen module')
    files['website/content/declaration_lessons/' + ITEM + '.json'] = lesson_data
    files['website/content/publications/' + ITEM + '.json'] = publication_data
    SNAP.mkdir()
    rows = []
    for path, data in sorted(files.items()):
        destination = SNAP / path
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(data)
        rows.append({'path': path, 'sha256': sha(data), 'bytes': len(data)})
    manifest = {
        'schema': 'bounded-MGF-reader-input-freeze-v1', 'proof_commit': COMMIT,
        'lesson_input': str(args.lesson), 'lesson_sha256': args.lesson_sha256,
        'publication_input': str(args.publication), 'publication_sha256': args.publication_sha256,
        'metadata_version': args.metadata_version, 'files': rows,
        'canonical_theme_styles': previous['canonical_theme_styles'],
        'reuse_provenance': {'old_C2_renderer': str(OLD / 'render_bounded_reader.py'),
            'old_C2_overlay': str(OLD / 'reader_overlay.py'),
            'old_C2_font_only_transform': str(OLD / 'prepare_offline_c2.py'),
            'scope': 'Presentation architecture reused; no old mathematical verdict or metadata acceptance inherited.'},
        'production_writes': False, 'browser_or_source_verdict_loaded': False,
    }
    manifest_path.write_bytes(json_bytes(manifest))
    return manifest


class CodeParser(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.in_pre = 0
        self.parts, self.blocks = [], []
    def handle_starttag(self, tag, attrs):
        if tag == 'pre':
            self.in_pre += 1
            if self.in_pre == 1:
                self.parts = []
    def handle_endtag(self, tag):
        if tag == 'pre':
            self.in_pre -= 1
            if self.in_pre == 0:
                self.blocks.append(''.join(self.parts))
    def handle_data(self, data):
        if self.in_pre:
            self.parts.append(data)


def render(manifest):
    if (OWN / 'fixtures').exists():
        raise ValueError('Frozen fixtures already exist; do not overwrite them')
    sys.path[:0] = [str(SNAP / 'tools'), str(SNAP / 'website/scripts')]
    from reader_overlay import add_step_actions, enhance_source, shell, SCOPED_CSS
    import astis_site as base
    import declaration_lessons as lessons
    import inline_lean
    import source_lineage
    import publication_reader
    import astis_publication as publication
    import underlying_lean_graph as graph_view
    from underlying_lean_graph_model_core import GraphBuilder
    unit = json.loads((SNAP / 'website/content/declaration_lessons' / (ITEM + '.json')).read_text())['units'][0]
    item = json.loads((SNAP / 'website/content/publications' / (ITEM + '.json')).read_text())['items'][0]
    base.ROOT = lessons.ROOT = SNAP
    base._ACTIVE_GIT = base.GitContext(COMMIT, 'isolated MGF proof snapshot', '', '', False, False, set())
    base._ACTIVE_GATE = base.GateEvidence(False, False, COMMIT, '', '', [],
        'Bounded presentation fixture; no production publication/root gate run')
    modules, declarations = base.scan_project_sources()
    base._SOURCE_BY_NAME = {d.full_name: d for d in declarations}
    base._ALL_MODULES = modules
    inline_lean.declarations.cache_clear()
    known = base._SOURCE_BY_NAME
    if known[P].source_line != 46 or known[T].source_line != 21:
        raise ValueError('Exact theorem source locators drifted')
    bounded = {'declarations': known, 'lessons': {P: unit}, 'audits': {}}
    publication.inputs = lambda: bounded
    publication.load = lambda: [item]
    publication.verified_binding = lambda *args, **kwargs: False
    progress = {'status': 'partial', 'label': 'Isolated reader; source/publication acceptance pending',
        'proof_declarations': [], 'prerequisites': [], 'source_complete': False}
    publication.chapter_progress = lambda *args, **kwargs: progress
    publication_reader.chapter_path_progress = lambda *args, **kwargs: progress
    graph_view.cross_domain.graph_guide_html = lambda: ''
    attempt = Path(tempfile.mkdtemp(prefix='render-attempt-', dir=OWN))
    outputs = {}
    lesson_rel = lessons.lesson_path(P)
    proof_rel = 'proofs/' + ITEM + '.html'
    focus = 'lean-foundations.html?view=lean&focus=' + quote('decl:' + P, safe='')
    for variant in ['original', 'candidate']:
        out = attempt / variant
        (out / 'assets').mkdir(parents=True)
        for row in manifest['files']:
            path = row['path']
            if path.startswith('website/static/'):
                destination = out / 'assets' / path.removeprefix('website/static/')
                destination.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(SNAP / path, destination)
        if variant == 'candidate':
            (out / 'assets/mgf-reader-overlay.css').write_text(SCOPED_CSS)
            css = out / 'assets/site-base.css'
            data = css.read_bytes()
            first, separator, rest = data.partition(b'\n')
            if not separator or b'@import' not in first or b'https://fonts.googleapis.com/' not in first:
                raise ValueError('Expected only the copied first-line Google font import')
            css.write_bytes(rest)
        canonical = '<!doctype html><html><head>' + ''.join(
            '<link rel="stylesheet" href="../assets/' + name + '">' for name in manifest['canonical_theme_styles']) + '</head></html>'
        (out / 'textbook').mkdir()
        (out / 'textbook/index.html').write_text(canonical)

        def nav(rel):
            prefix = base.relative_prefix(rel)
            links = [(proof_rel, 'Reader'), ('source-index.html', 'Source index'),
                ('parent-context.html', 'Parents and private application'), (focus, 'Bounded graph')]
            return '<nav class="mgf-preview-nav" aria-label="MGF reader context">' + ' '.join(
                '<a href="' + escape(prefix + href, quote=True) + '">' + escape(label) + '</a>' for href, label in links) + '</nav>'

        def write(rel, title, body, proof=False, graph=False):
            heads = ''
            if proof:
                heads += '<link rel="stylesheet" href="' + base.relative_prefix(rel) + 'assets/proof-readers.css">'
            if graph:
                heads += ''.join('<link rel="stylesheet" href="' + base.relative_prefix(rel) + 'assets/' + name + '">'
                    for name in ['underlying-lean-graph.css', 'semantic-roundtrip-graph.css'])
            text = base.page(title, rel, nav(rel) + body, extra_head=heads,
                extra_scripts=('assets/underlying-lean-graph.js',) if graph else ())
            text = shell(source_lineage.canonical_shell(text, rel, out), rel, variant)
            destination = out / rel
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_text(text)

        body = lessons.render_unit(unit, lesson_rel)
        if variant == 'candidate':
            body = add_step_actions(body, unit, lesson_rel, base, lessons)
        write(lesson_rel, unit['title'], body, proof=True)
        body = publication_reader.source_card(item, proof_rel)
        if variant == 'candidate':
            body = add_step_actions(body, unit, proof_rel, base, lessons)
        write(proof_rel, unit['title'], body, proof=True)
        for module in modules:
            imported_by = [m.name for m in modules if module.name in m.imports]
            text = base.render_source_module(module, imported_by)
            rel = 'modules/' + base.slugify(module.name) + '.html'
            text = shell(source_lineage.canonical_shell(text, rel, out), rel, variant)
            destination = out / rel
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_text(text)
        all_sources = [PFILE, TFILE, *PARENTS.values()]
        for path in all_sources:
            data = (SNAP / path).read_bytes()
            download = out / 'downloads/lean' / path
            download.parent.mkdir(parents=True, exist_ok=True)
            download.write_bytes(data)
            lines = data.decode().splitlines(keepends=True)
            numbered = ''.join('<span id="L' + str(i) + '">' + escape(line) + '</span>' for i, line in enumerate(lines, 1))
            body = '<h1>Exact source context</h1><pre>' + numbered + '</pre>'
            rel = 'data/lesson-sources/' + path + '.html'
            if variant == 'candidate':
                body = enhance_source(body, path, rel, base)
            write(rel, path, body)
            parser = CodeParser()
            parser.feed((out / rel).read_text())
            if len(parser.blocks) != 1 or parser.blocks[0].encode() != data:
                raise ValueError('Full source HTML text is not byte-exact: ' + path)

        source_rows = []
        for name, path in [(P, PFILE), (T, TFILE), *PARENTS.items()]:
            d = known[name]
            href = lessons.source_link({'path': path, 'line': d.source_line}, 'source-index.html')
            source_rows.append('<li><a href="' + escape(href, quote=True) + '"><code>' + escape(name) + '</code></a>'
                + (' — associated private application; no public node' if name == T else '') + '</li>')
        write('source-index.html', 'MGF source index', '<h1>MGF source index</h1><ul>' + ''.join(source_rows) + '</ul>')
        public_parents = list(PARENTS)[:2]
        private_parents = [P, *list(PARENTS)[2:]]
        def parent_rows(names):
            return '<ul>' + ''.join('<li><a href="' + escape(lessons.source_link({'path': known[n].source_file, 'line': known[n].source_line}, 'parent-context.html'), quote=True)
                + '"><code>' + escape(n) + '</code></a></li>' for n in names) + '</ul>'
        write('parent-context.html', 'MGF parents and private application',
            '<h1>Parents and private application</h1><h2>Public MGF node</h2>' + parent_rows(public_parents)
            + '<h2>Associated private cosine-weighted application</h2>' + parent_rows(private_parents)
            + '<p>The private application is represented by its source module. It has no separate public theorem node.</p>')

        builder = GraphBuilder()
        for module in modules:
            builder.add('module:' + module.name, 'module', module.name, status='partial',
                subtitle='Exact source-present module structure in an isolated preview',
                url='modules/' + base.slugify(module.name) + '.html')
        for module in modules:
            for imported in module.imports:
                builder.edge('module:' + imported, 'module:' + module.name, 'imports')
        for name in [P, *PARENTS]:
            d = known[name]
            builder.add('decl:' + name, 'declaration', name, status='partial',
                subtitle='Exact source call/context; independent publication/source acceptance separate',
                url=lesson_rel if name == P else 'data/lesson-sources/' + d.source_file + '.html#L' + str(d.source_line),
                details=[{'label': 'Source', 'value': d.source_file + ':' + str(d.source_line)}])
            builder.edge('module:' + d.module, 'decl:' + name, 'declares')
        for name in public_parents:
            builder.edge('decl:' + name, 'decl:' + P, 'source reference (scanner)')
        for name in private_parents:
            builder.edge('decl:' + name, 'module:' + known[T].module, 'source reference (scanner)')
        publication_reader.project_graph(builder)
        graph = builder.export()
        graph.update(schema_version=3, hyperedges=[], graph_memory_index={'family_ids': []},
            generated_from='Bounded selected source/module/publication projection only; no global graph write',
            reference_contract='Imports/declares are solid module structure. Source-call reference overlays remain dashed and do not assert theorem implication. Private T has no declaration node.')
        (out / 'data').mkdir(exist_ok=True)
        (out / 'data/underlying-lean-graph.json').write_bytes(json_bytes(graph))
        write('lean-foundations.html', 'Bounded MGF branch', graph_view.main_html({}), graph=True)
        write('index.html', 'MGF isolated reader', '<h1>Centered bounded real matrix MGF</h1><p><a href="' + proof_rel + '">Open the mathematical reader</a></p>')
        for rel, value in [('data/search-index.json', []), ('data/site-data.json', {})]:
            (out / rel).write_bytes(json_bytes(value))
        html = (out / proof_rel).read_text()
        for step in unit['steps']:
            if base.code_html(step['lean']) not in html:
                raise ValueError('Literal code fold altered during rendering')
        if variant == 'candidate' and (html.count('data-mgf-step=') != 6 or html.count('data-step-source href=') != 6):
            raise ValueError('Expected six adjacent source/download action groups')
        outputs[variant] = {
            'files': [{'path': str(p.relative_to(out)), 'sha256': sha(p.read_bytes()), 'bytes': p.stat().st_size}
                for p in sorted(out.rglob('*')) if p.is_file()],
            'proof_path': proof_rel, 'lesson_path': lesson_rel,
            'P_source': 'data/lesson-sources/' + PFILE + '.html#L46',
            'T_source': 'data/lesson-sources/' + TFILE + '.html#L21', 'graph_focus': focus,
        }
    attempt.rename(OWN / 'fixtures')
    diffs = OWN / 'diffs'
    diffs.mkdir()
    original = {r['path']: r for r in outputs['original']['files']}
    candidate = {r['path']: r for r in outputs['candidate']['files']}
    changed = []
    for path in sorted(original.keys() | candidate.keys()):
        if original.get(path, {}).get('sha256') == candidate.get(path, {}).get('sha256'):
            continue
        before = (OWN / 'fixtures/original' / path).read_bytes() if path in original else b''
        after = (OWN / 'fixtures/candidate' / path).read_bytes() if path in candidate else b''
        record = {'path': path, 'original_sha256': sha(before) if path in original else None,
            'candidate_sha256': sha(after) if path in candidate else None}
        try:
            diff = ''.join(difflib.unified_diff(before.decode().splitlines(keepends=True), after.decode().splitlines(keepends=True),
                fromfile='original/' + path, tofile='candidate/' + path))
            destination = diffs / (path.replace('/', '__') + '.diff')
            destination.write_text(diff)
            record['diff'] = str(destination.relative_to(OWN))
        except UnicodeDecodeError:
            record['binary_changed'] = True
        changed.append(record)
    report = {
        'schema': 'bounded-MGF-original-candidate-reader-preview-v1',
        'status': 'GENERATED_AND_STATICALLY_CHECKED; BROWSER_AND_INDEPENDENT_OVERLAY_REVIEW_PENDING',
        'proof_commit': COMMIT, 'metadata_version': manifest['metadata_version'],
        'lesson_sha256': manifest['lesson_sha256'], 'publication_sha256': manifest['publication_sha256'],
        'input_freeze_manifest_sha256': sha((OWN / 'input-freeze-manifest.json').read_bytes()),
        'generator_sha256': sha(Path(__file__).read_bytes()), 'overlay_sha256': sha((OWN / 'reader_overlay.py').read_bytes()),
        'variants': outputs, 'changed_files': changed,
        'six_code_folds_exact_P121_T159': True,
        'six_adjacent_source_and_full_download_actions': True,
        'all_source_page_pre_text_equals_frozen_source_bytes': True,
        'mathematical_lesson_and_publication_payloads_changed': False,
        'original_qualification': 'Uses exact frozen production renderer functions with common bounded navigation and six selected source modules; it reproduces the missing per-step source/download actions. This is not a full-site or production acceptance claim.',
        'candidate_scope': 'Only selected MGF code/source adjacency, source filename/header/code and local table/formula/code containment; copied candidate site-base.css removes only its first Google font import line. No production renderer/CSS write.',
        'graph_scope': 'Only the selected public P, its two parents, private T module and its two Gaussian adapters. No private T declaration node, global graph mutation or theorem implication from references.',
        'limitations': ['No browser was opened; dimensions, glyphs, copy behavior, anchors, font fallback, formula/table horizontal scroll, graph UI and downloads still require actual independent runtime observation.',
            'No network or server was started; browser reviewer may serve the frozen fixture under its separately authorized workflow.',
            'Source metadata acceptance and any successor mathematical/source-locator proposal remain with ROOT and the independent source reviewer.'],
        'side_effects': 'Own snapshot/fixtures/diffs/manifests only. No proof search, Lean or whole-site build, normal API, production/shared renderer/CSS/Registry/root imports/source index/global graph write, refs, commit or push.',
    }
    (OWN / 'preview-freeze-manifest.json').write_bytes(json_bytes(report))
    print(json.dumps({'status': report['status'], 'fixture_root': str(OWN / 'fixtures'),
        'proof_path': proof_rel, 'preview_manifest_sha256': sha((OWN / 'preview-freeze-manifest.json').read_bytes()),
        'changed_file_count': len(changed), 'browser_opened': False, 'server_started': False}, indent=2))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--lesson', type=Path, required=True)
    parser.add_argument('--publication', type=Path, required=True)
    parser.add_argument('--lesson-sha256', required=True)
    parser.add_argument('--publication-sha256', required=True)
    parser.add_argument('--metadata-version', required=True)
    args = parser.parse_args()
    if not re.fullmatch(r'[0-9a-f]{64}', args.lesson_sha256) or not re.fullmatch(r'[0-9a-f]{64}', args.publication_sha256):
        raise ValueError('Both expected metadata hashes must be full SHA256 digests')
    render(inputs(args))


if __name__ == '__main__':
    main()
