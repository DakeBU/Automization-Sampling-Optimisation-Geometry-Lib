import AutoSamplingTheory.ExampleCases.ProximalBPS.ActualOrderedPrefix

set_option pp.universes true
set_option pp.proofs false
set_option pp.deepTerms true
set_option pp.maxSteps 1000000
#print axioms AutoSamplingTheory.ExampleCases.ProximalBPS.ActualOrderedPrefix.actual_ordered_prefix_law
#check AutoSamplingTheory.ExampleCases.ProximalBPS.ActualOrderedPrefix.actual_ordered_prefix_law
open Lean Elab Command in
run_cmd do
  let env ← getEnv
  let isProject := fun n : Name => n.toString.startsWith "AutoSamplingTheory." ||
    (n.toString.startsWith "_private." && (n.toString.splitOn ".").contains "AutoSamplingTheory")
  let isLocal := fun n : Name => (n.toString.splitOn ".").contains "ActualOrderedPrefix"
  let mut todo := #[`AutoSamplingTheory.ExampleCases.ProximalBPS.ActualOrderedPrefix.actual_ordered_prefix_law]
  let mut seen : Array Name := #[]
  let mut externalDeps : Array Name := #[]
  let mut genericDeps : Array Name := #[]
  while !todo.isEmpty do
    let name := todo.back!
    todo := todo.pop
    if !seen.contains name then
      seen := seen.push name
      logInfo m!"LOCAL_PROOF_CONSTANT {name}"
      let some ci := env.find? name | throwError "Missing owned constant"
      let mut expressions := #[ci.type]
      if let some value := ci.value? true then
        expressions := expressions.push value
      else
        logInfo m!"LOCAL_NO_VALUE {name}"
      for expr in expressions do
        for dep in expr.getUsedConstants do
          if isLocal dep then
            logInfo m!"LOCAL_EDGE {name} -> {dep}"
            todo := todo.push dep
          else if isProject dep && !externalDeps.contains dep then
            externalDeps := externalDeps.push dep
            logInfo m!"EXTERNAL_ASTIS_DEPENDENCY {dep}"
          else if !isProject dep && !genericDeps.contains dep then
            genericDeps := genericDeps.push dep
            logInfo m!"GENERIC_DEPENDENCY {dep}"
  logInfo m!"LOCAL_PROOF_CONSTANT_COUNT {seen.size}"
  let mut projectTodo := externalDeps
  let mut projectSeen : Array Name := #[]
  while !projectTodo.isEmpty do
    let name := projectTodo.back!
    projectTodo := projectTodo.pop
    if !projectSeen.contains name then
      projectSeen := projectSeen.push name
      logInfo m!"TRANSITIVE_ASTIS_CONSTANT {name}"
      let some ci := env.find? name | throwError "Missing ASTIS dependency"
      let mut expressions := #[ci.type]
      if let some value := ci.value? true then
        expressions := expressions.push value
      else
        logInfo m!"PROJECT_NO_VALUE {name}"
      for expr in expressions do
        for dep in expr.getUsedConstants do
          if isProject dep then
            logInfo m!"TRANSITIVE_ASTIS_EDGE {name} -> {dep}"
            projectTodo := projectTodo.push dep
  logInfo m!"TRANSITIVE_ASTIS_CONSTANT_COUNT {projectSeen.size}"

open Lean Elab Command in
run_cmd do
  let env ← getEnv
  let some ci := env.find? `AutoSamplingTheory.ExampleCases.ProximalBPS.ActualOrderedPrefix.actual_ordered_prefix_law | throwError "missing public theorem"
  logInfo m!"PUBLIC_TYPE {ci.type}"
  for dep in ci.type.getUsedConstants do
    if (dep.toString.splitOn ".").contains "actual_ordered_prefix_statement" then
      let some stmt := env.find? dep | throwError "missing private statement"
      let some body := stmt.value? true | throwError "statement has no body"
      logInfo m!"EXPANDED_PRIVATE_STATEMENT {body}"
