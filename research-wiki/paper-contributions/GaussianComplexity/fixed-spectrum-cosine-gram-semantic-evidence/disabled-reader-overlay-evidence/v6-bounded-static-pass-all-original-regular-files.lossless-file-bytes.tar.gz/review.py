"""Independent prospective UI-only review. No mutation of previous reviews."""
import dataclasses, hashlib, html, importlib.util, json, pathlib, re, subprocess, sys, time, types
from html.parser import HTMLParser
from urllib.parse import urlsplit

D=pathlib.Path(__file__).resolve().parent
R=pathlib.Path('/Users/zhouhuanjian/ASTIS-GC')
C='72e5d1405284f729f4eb600c5ae5dd556365b7e2'
P='AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumCosineGram.lean'
T='Tests/GaussianComplexityFixedSpectrumCosineGram.lean'
L='website/content/declaration_lessons/huanjian-fixed-spectrum-cosine-gram.json'
def sha(b):return hashlib.sha256(b).hexdigest()
def put(rel,b):
 p=D/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b if isinstance(b,bytes) else b.encode());return p
def js(rel,o):return put(rel,json.dumps(o,ensure_ascii=False,indent=2)+'\n')
def run(label,argv):
 start=time.time();p=subprocess.run(argv,cwd=D,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 put('raw/'+label+'.stdout',p.stdout);put('raw/'+label+'.stderr',p.stderr)
 js('raw/'+label+'.receipt.json',{'argv':list(map(str,argv)),'cwd':str(D),'start_unix':start,'elapsed_seconds':time.time()-start,'exit_code':p.returncode,
   'stdout_sha256':sha(p.stdout),'stderr_sha256':sha(p.stderr)})
 assert p.returncode==0,(label,p.stdout.decode(),p.stderr.decode())
 return p

sys.path[:0]=[str(D/'inputs/tools'),str(D/'inputs/website/scripts')]
shell=types.ModuleType('source_lineage');shell.canonical_shell=lambda text,rel,output:text
sys.modules['source_lineage']=shell
import astis_site as base, inline_lean
base._ACTIVE_GIT=base.GitContext(commit=C,ref='isolated-v6-ui-only',remote_url='',web_root='',commit_published=False,public_source_links=False,dirty_files=set())
base._ACTIVE_GATE=base.GateEvidence(passed=False,current=False,commit=C,source_digest='',generated_at='',commands=[],note='UI-only fixture, no build credit')
modules,decls=base.scan_project_sources();known={d.full_name:d for d in decls};base._SOURCE_BY_NAME=known
assert {m.source_file for m in modules}=={P,T,'AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumGridAlias.lean'}
unit=json.loads((D/'inputs'/L).read_bytes())['units'][0]
assert (D/'inputs'/L).read_bytes()==(R/L).read_bytes()
renderers={}
for kind in ['production','proposal']:
 spec=importlib.util.spec_from_file_location('review_'+kind,D/(kind+'.py'));mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);mod.ROOT=D/'inputs';renderers[kind]=mod
v6=renderers['proposal']

class Node:
 def __init__(self,tag,attrs=None,parent=None):self.tag,self.attrs,self.parent,self.children=tag,dict(attrs or []),parent,[]
 def text(self):return ''.join(c if isinstance(c,str) else c.text() for c in self.children)
 def descendants(self,tag=None):
  found=[]
  for c in self.children:
   if isinstance(c,Node):
    if tag is None or c.tag==tag:found.append(c)
    found+=c.descendants(tag)
  return found
 def cls(self,c):return c in self.attrs.get('class','').split()
class DOM(HTMLParser):
 void={'area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr'}
 def __init__(self):super().__init__(convert_charrefs=True);self.root=Node('root');self.stack=[self.root]
 def handle_starttag(self,tag,attrs):
  n=Node(tag,attrs,self.stack[-1]);self.stack[-1].children.append(n)
  if tag not in self.void:self.stack.append(n)
 def handle_endtag(self,tag):
  assert self.stack[-1].tag==tag,(self.stack[-1].tag,tag);self.stack.pop()
 def handle_data(self,data):self.stack[-1].children.append(data)
def parse(s):
 d=DOM();d.feed(s);assert len(d.stack)==1;return d.root

records={};page=renderers['production'].lesson_path(unit['declaration'])
source_export={}
for kind,mod in renderers.items():
 text=mod.render_unit(unit,page);put('static/'+kind+'/'+page,text);root=parse(text)
 steps=[n for n in root.descendants('details') if n.cls('proof-reader-step')];assert len(steps)==6
 observed=[]
 for i,(node,s) in enumerate(zip(steps,unit['steps']),1):
  fold=[n for n in node.descendants('details') if n.children[0].tag=='summary' and n.children[0].text()=='Corresponding Lean step'];assert len(fold)==1;fold=fold[0]
  code=fold.descendants('code');assert len(code)==1
  formula=[n for n in node.descendants('div') if n.cls('proof-reader-equation')];assert len(formula)==1
  buttons=[n for n in fold.descendants('button') if 'data-lean-copy' in n.attrs]
  direct_code=[n for n in fold.children if isinstance(n,Node) and n.tag=='pre' and len(n.descendants('code'))==1]
  observed.append({'step':i,'code_exact':code[0].text()==s['lean'],'code_bytes':len(code[0].text().encode()),'code_sha256':sha(code[0].text().encode()),
    'formula_exact':formula[0].text()=='\\['+s['formula']+'\\]','outer_initially_closed':'open' not in node.attrs,'code_initially_closed':'open' not in fold.attrs,
    'panel_attribute':'data-lean-code-panel' in fold.attrs,'copy_button_count':len(buttons),'direct_pre_code_count':len(direct_code),
    'status_in_button_parent':bool(buttons) and all(len([n for n in b.parent.descendants('span') if 'data-lean-copy-status' in n.attrs and n.attrs.get('role')=='status' and n.attrs.get('aria-live')=='polite'])==1 for b in buttons),
    'anchors':[{'text':n.text(),'href':n.attrs.get('href'),'download':'download' in n.attrs} for n in fold.descendants('a')],
    'direct_inner_tags':[n.tag for n in fold.children if isinstance(n,Node)]})
  assert all(observed[-1][k] for k in ['code_exact','formula_exact','outer_initially_closed','code_initially_closed'])
 records[kind]=observed
 out=D/'static'/kind;mod.export_sources(out,[unit]);source_export[kind]={}
 for rel in [P,T]:
  target=out/'data/lesson-sources'/rel;companion=target.with_suffix(target.suffix+'.html')
  data={'source_html_exists':companion.exists(),'raw_download_exists':target.exists()}
  if companion.exists():
   tree=parse(companion.read_text());pre=tree.descendants('pre');assert len(pre)==1
   data['full_source_text_exact']=pre[0].text().encode()==(D/'inputs'/rel).read_bytes()
   data['source_html_raw_download_hrefs']=[n.attrs['href'] for n in tree.descendants('a') if 'download' in n.attrs]
  if target.exists():data['raw_download_exact']=target.read_bytes()==(D/'inputs'/rel).read_bytes();data['raw_download_sha256']=sha(target.read_bytes())
  source_export[kind][rel]=data

routes=[(P,34),(P,54),(P,125),(P,156),(T,59),(T,13)]
for row,(rel,line) in zip(records['proposal'],routes):
 assert row['panel_attribute'] and row['copy_button_count']==1 and row['direct_pre_code_count']==1 and row['status_in_button_parent']
 assert len(row['anchors'])==2
 context,download=row['anchors'];assert not context['download'] and download['download']
 assert context['href']=='../data/lesson-sources/'+rel+'.html#L'+str(line)
 assert download['href']=='../data/lesson-sources/'+rel
 for link in row['anchors']:
  resolved=(D/'static/proposal'/pathlib.Path(page).parent/urlsplit(link['href']).path).resolve();assert resolved.is_file()
  if link['download']:assert resolved.read_bytes()==(D/'inputs'/rel).read_bytes()
  else:
   tree=parse(resolved.read_text());anchor=[n for n in tree.descendants('span') if n.attrs.get('id')=='L'+str(line)];assert len(anchor)==1
   expected=unit['steps'][row['step']-1]['lean'].splitlines()[0] if row['step']!=6 else 'private theorem actual_gaussian_gram_means'
   assert anchor[0].text().startswith(expected)
assert records['proposal'][5]['code_bytes']==7494
assert all(x['source_html_exists'] and x['raw_download_exists'] and x['full_source_text_exact'] and x['raw_download_exact'] for x in source_export['proposal'].values())
js('real-C5-static-folds.json',records);js('real-C5-source-exports.json',source_export)

# Execute only the unchanged existing click-handler in a mock-DOM contract fixture.
site=(D/'inputs/website/static/site.js').read_text();start=site.index('  document.addEventListener("click", async (event) => {');end=site.index('\n\n  filterCards();',start)
handler=site[start:end];put('copy-handler.exact.js',handler)
js('copy-handler-code-inputs.json',[s['lean'] for s in unit['steps']])
node=r'''
const fs=require('fs'),vm=require('vm'),assert=require('assert');
const source=fs.readFileSync('copy-handler.exact.js','utf8'),codes=JSON.parse(fs.readFileSync('copy-handler-code-inputs.json','utf8'));
(async()=>{const results=[];for(const [index,text] of codes.entries())for(const mode of ['clipboard','fallback','clipboard-failure']){
 let handler,written=null,status={textContent:''},calls=[];
 const code={textContent:text};const panel={querySelector:s=>{calls.push(s);assert.equal(s,':scope > pre > code');return code}};
 const parent={querySelector:s=>{calls.push(s);assert.equal(s,'[data-lean-copy-status]');return status}};
 const button={disabled:false,parentElement:parent,closest:s=>{assert.equal(s,'[data-lean-code-panel]');return panel}};
 const selection={removeAllRanges:()=>calls.push('removeAllRanges'),addRange:()=>calls.push('addRange')};
 const document={addEventListener:(event,fn)=>{assert.equal(event,'click');handler=fn},createRange:()=>({selectNodeContents:n=>{assert.equal(n,code);written=n.textContent}}),execCommand:s=>{assert.equal(s,'copy');return true}};
 const navigator=mode==='fallback'?{}:{clipboard:{writeText:async value=>{if(mode==='clipboard-failure')throw Error('fixture failure');written=value}}};
 vm.runInNewContext(source,{document,navigator,window:{getSelection:()=>selection}});
 await handler({target:{closest:s=>{assert.equal(s,'[data-lean-copy]');return button}}});
 assert.equal(button.disabled,false);
 if(mode==='clipboard-failure'){assert.equal(status.textContent,'Copy failed; select the Lean code below.');assert.equal(written,null)}
 else{assert.equal(written,text);assert.equal(status.textContent,'Copied')}
 results.push({step:index+1,mode,passed:true,utf8Bytes:Buffer.byteLength(text,'utf8')});
 }fs.writeFileSync('copy-handler-contract-results.json',JSON.stringify({scope:'Unchanged actual handler with mock DOM/clipboard; no live browser acceptance',results},null,2)+'\n');console.log(JSON.stringify({checks:results.length,passed:results.length}));})().catch(e=>{console.error(e);process.exit(1)});
'''
put('copy-handler-contract.js',node)
js('copy-contract-structural-scope.json',{'actual_candidate_JS_sha256':sha((D/'inputs/website/static/site.js').read_bytes()),
 'handler_sha256':sha(handler.encode()),'six_panels_meet_actual_handler_selectors':True,
 'selectors':['[data-lean-copy]','[data-lean-code-panel]',':scope > pre > code','[data-lean-copy-status]'],
 'runtime_execution':'NOT EXECUTED: node absent from PATH; Node REPL dynamic compilation disallowed. No runtime attempt repeated in this follow-up; previous failed attempts remain in their original freeze and are not relabeled as current evidence. No browser/clipboard acceptance inferred.'})

# Independent exact matching controls, without trusting author outputs.
fixture=D/'fixtures/exact';fixture.mkdir(parents=True)
v6.ROOT=fixture;v6.mathlib_pin.cache_clear();put('fixtures/exact/lake-manifest.json',(D/'inputs/lake-manifest.json').read_bytes())
def fixture_unit(paths,canonical=None,line=1):
 base._SOURCE_BY_NAME={'Fixture.root':types.SimpleNamespace(source_file=canonical,source_line=line)} if canonical else {}
 inline_lean.declarations.cache_clear()
 return {'declaration':'Fixture.root','sources':[{'path':p} if isinstance(p,str) else p for p in paths]}
def file(name,b):
 p=fixture/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b if isinstance(b,bytes) else b.encode());return p
controls=[]
def control(label,paths,wholefiles,literal,wanted_line=None,canonical=None,wanted_path=None):
 for name,b in wholefiles.items():file(name,b)
 u=fixture_unit(paths,canonical=canonical)
 actions=v6.exact_lean_step_actions(u,{'lean':literal},page);tree=parse(actions)
 anchors=tree.descendants('a');buttons=tree.descendants('button')
 actual={'control':label,'literal_sha256':sha(literal.encode()),'literal_bytes':len(literal.encode()),'copy_count':len(buttons),
    'anchors':[a.attrs for a in anchors],'expected_line':wanted_line,'expected_path':wanted_path,'pass':True}
 if '\n' not in literal:assert actions==''
 else:assert len(buttons)==1
 if wanted_line is None:assert len(anchors)==0
 else:
  assert len(anchors)==2
  assert anchors[0].attrs['href']=='../data/lesson-sources/'+wanted_path+'.html#L'+str(wanted_line)
 controls.append(actual);js('exact-match-controls.json',controls)

lit='λ step\nβ finish\n'
control('unique UTF8 occurrence, LF line2',['unique.lean'],{'unique.lean':'-- π\n'+lit+'-- tail\n'},lit,2,wanted_path='unique.lean')
control('absent literal gives copy only',['unique.lean'],{},'absent\n')
control('repeated nonoverlap gives copy only',['repeat.lean'],{'repeat.lean':lit+lit},lit)
control('repeated overlapping matches give copy only',['overlap.lean'],{'overlap.lean':'a\na\na\n'},'a\na\n')
control('same literal in two sources gives copy only',['a.lean','b.lean'],{'a.lean':lit,'b.lean':lit},lit)
control('duplicate citation same path counted once',['a.lean','a.lean'],{},lit,1,wanted_path='a.lean')
control('canonical candidate plus separate explicit citation is ambiguous',['b.lean'],{},lit,canonical='a.lean')
control('canonical-only module is a meaningful candidate',[],{'canonical.lean':'-- pre\n'+lit},lit,2,canonical='canonical.lean',wanted_path='canonical.lean')
control('CRLF source with LF literal does not normalize/match',['crlf.lean'],{'crlf.lean':'-- pre\r\nλ step\r\nβ finish\r\n'},lit)
control('CRLF exact literal matches line2',['crlf.lean'],{},'λ step\r\nβ finish\r\n',2,wanted_path='crlf.lean')
control('removed final LF remains a unique exact substring',['unique.lean'],{},lit[:-1],2,wanted_path='unique.lean')
control('extra final LF missing gives copy only',['unique.lean'],{},lit+'\n')
control('single line preserves old prose behavior',['unique.lean'],{},'λ step')
control('CR-only code has no LF and preserves old non-code behavior',['cronly.lean'],{'cronly.lean':'λ step\rβ finish\r'},'λ step\rβ finish\r')

# Path/URL and symlink checks use only files created inside this follow-up.
security=[]
bad_paths=['../outside.lean','/tmp/outside.lean','C:/drive.lean','a\\b.lean','a/../b.lean',' bad.lean','bad.lean ','a//b.lean','a/./b.lean','a.lean#x','a.lean?x','a%2f.lean','a:bad.lean','a\n.lean','a\x00.lean','a\x7f.lean','']
for raw in bad_paths:
 try:v6.source_link({'path':raw},page)
 except (ValueError,TypeError) as exc:security.append({'case':'unsafe path','value':raw,'rejected':True,'exception':type(exc).__name__})
 else:raise AssertionError(('Unsafe path accepted',repr(raw)))
bad_urls=['javascript:alert(1)','http://example.test','https://','https:///x','https://example.test:bad','https://example.test:65536','https:// example.test','https://example.test/a b','https://example.test/\nfoo','https://[bad','//example.test',123]
for url in bad_urls:
 try:v6.source_link({'url':url},page)
 except (ValueError,TypeError) as exc:security.append({'case':'unsafe URL','value':url,'rejected':True,'exception':type(exc).__name__})
 else:raise AssertionError(('Unsafe URL accepted',url))
for url in ['https://example.test/π#L2','HTTPS://example.test/x','https://example.test:443/a?q=b']:
 assert v6.source_link({'url':url},page)==url;security.append({'case':'valid URL','value':url,'accepted':True})
file('real.lean',lit);(fixture/'internal.lean').symlink_to('real.lean')
control('safe internal symlink preserves exact source routing',['internal.lean'],{},lit,1,wanted_path='internal.lean')
outside=D/'fixtures/outside.lean';outside.write_text(lit);(fixture/'escape.lean').symlink_to(outside)
for method in ['actions','export']:
 u=fixture_unit(['escape.lean'])
 try:
  if method=='actions':v6.exact_lean_step_actions(u,{'lean':lit},page)
  else:v6.export_sources(D/'fixtures/escape-export',[u])
 except ValueError as exc:security.append({'case':'outside-root symlink '+method,'rejected':True,'exception':str(exc)})
 else:raise AssertionError('outside symlink accepted '+method)
u=fixture_unit([{'url':'https://example.test/reference','path':'../outside.lean'}])
try:v6.export_sources(D/'fixtures/url-path-export',[u])
except ValueError as exc:security.append({'case':'unsafe path beside valid URL export','rejected':True,'exception':str(exc)})
else:raise AssertionError('unsafe path beside URL accepted')
js('path-url-symlink-controls.json',security)

# Newly exported canonical source compatibility: ordinary canonical-only and
# mixed explicit citations must produce exact raw bytes with stable line anchors.
compat=[]
for label,canonical,citations in [('canonical only','canonical.lean',[]),('canonical plus explicit cited private file','canonical.lean',['unique.lean'])]:
 u=fixture_unit(citations,canonical=canonical);out=D/'fixtures/compat'/label.replace(' ','-');v6.export_sources(out,[u]);expected=[canonical]+citations
 for raw in expected:
  assert (out/'data/lesson-sources'/raw).read_bytes()==(fixture/raw).read_bytes()
 compat.append({'case':label,'canonical_and_cited_exact_raw_exports':expected,'pass':True})
js('canonical-export-compatibility.json',compat)

