from pathlib import Path
import datetime
import hashlib
import json
import runpy
import sys

ROOT = Path('/Users/zhouhuanjian/ASTIS-GC')
OWN = ROOT / '.astis/semantic-neutral-20261112/mm_tc_7f32'
R7 = ROOT / '.astis/semantic-neutral-20261112/ri_tc_24a6'
SOURCE = ROOT / '.astis/huanjian-resume-20261103/2610.20492v1.html'

def sha(b):
    return hashlib.sha256(b).hexdigest()

def digest(p):
    b = p.read_bytes()
    return {'path':str(p.relative_to(ROOT)), 'bytes':len(b), 'sha256':sha(b)}

def write(name, value):
    (OWN/name).write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')

assert digest(SOURCE)['sha256'] == '6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
assert digest(SOURCE)['bytes'] == 951991
preserved = []
for rel in ['SHA256SUMS','TYPE-SHA256SUMS','GRAPH-SHA256SUMS-v1','conceptual-v1/SHA256SUMS']:
    manifest = R7/rel
    for line in manifest.read_text().splitlines():
        expected, name = line.split('  ',1)
        path = manifest.parent/name
        assert digest(path)['sha256'] == expected, str(path)
        preserved.append(digest(path))
    preserved.append(digest(manifest))
preserved = list({a['path']:a for a in preserved}.values())

sys.argv = [str(OWN/'read_raw.py'), 'silent']
reader = runpy.run_path(str(OWN/'read_raw.py'))
by_id = reader['by_id']
read_ids = ['S4.E11','S4.Thmtheorem4.p1.1'] + [f'A3.SS2.p{n}' for n in range(1,13)] + ['A3.Thmtheorem5','A3.Thmtheorem6']
key_ids = [
    'S4.E11.m1','A3.SS2.p1.1','A3.Ex85','A3.SS2.p1.2','A3.Ex87',
    'A3.SS2.p4','A3.SS2.p5','A3.SS2.p7','A3.Ex96',
    'A3.SS2.p10.m1','A3.SS2.p10.m2','A3.SS2.p12.1','A3.Ex107',
    'A3.SS2.p12.2','A3.Ex108','A3.SS2.p12.3','A3.SS2.p12.4','A3.Ex110','A3.SS2.p12.5',
]
locators = {ident:by_id[ident].locator() for ident in dict.fromkeys(read_ids+key_ids)}
raw = SOURCE.read_bytes()
for ident, loc in locators.items():
    assert sha(raw[loc['utf8_byte_start']:loc['utf8_byte_end_exclusive']]) == loc['raw_fragment_sha256']
write('locators.json', {
    'kind':'preliminary-raw-source-locators-not-admitted-topology',
    'source':digest(SOURCE),
    'convention':'Half-open zero-based UTF-8 byte/Unicode-codepoint spans; inclusive one-based LF lines; raw hashes cover unnormalized source fragments.',
    'full_elements_freshly_read':read_ids,
    'key_source_elements':key_ids,
    'locators':locators,
})
protocols = [
    'AGENTS.md','CONTRIBUTING.md','.agents/prompts/collaborator-contribution.md',
    'docs/contributor-codex-contract.md','docs/theorem-publication-protocol.md',
    'docs/proof-digestion-protocol.md','docs/evidence-routed-memory-protocol.md',
    '.agents/skills/astis-substantive-advance/SKILL.md','LICENSE_SCOPE.md',
]
protocol_records = [digest(ROOT/name) for name in protocols]
write('input-manifest.json', {
    'source':digest(SOURCE),
    'assignment':digest(OWN/'assignment.txt'),
    'assignment_note':'Whitespace-normalized task transcript, not unavailable transport bytes.',
    'protocol_files_previously_read_in_same_session_current_hash_snapshot':protocol_records,
    'protocol_manifest_sha256':sha(json.dumps(protocol_records,sort_keys=True,separators=(',',':')).encode()),
    'prior_R7_preserved_by_existing_checksum_manifests':preserved,
    'prior_record_access_note':'Checksum manifests/byte hashes only; no prior substantive review/graph content read anew.',
    'new_target_type_graph_API_implementation_inputs':[],
})
local_names = ['assignment.txt','read_raw.py','raw-reading.md','exposure.json','freeze.py','locators.json','input-manifest.json']
freeze = {
    'kind':'prospective-actual-matrix-means-independent-preliminary-raw-freeze',
    'version':1, 'actor':'/root/row_indep_topology_24a6',
    'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'source':digest(SOURCE),
    'owned_root':str(OWN.relative_to(ROOT)),
    'scope':'Actual canonical independent-column sample rows, literal Ex107 closed-cutoff Y, exact common-a matrix means and the two actual mean sums via Fact C.5.',
    'new_target_exact_seal_received':False,
    'new_target_binder_definition_packet_received':False,
    'new_target_types_graph_SG_notes_API_implementation_seen':False,
    'source_pristine_claim':False,
    'prior_exposure_record':digest(OWN/'exposure.json'),
    'raw_notes':digest(OWN/'raw-reading.md'),
    'local_records':[digest(OWN/name) for name in local_names],
    'prior_R7_originals_preserved_count':len(preserved),
    'prior_R7_originals_preserved':True,
    'formal_type_topology_or_applicability_admission':False,
    'proof_compiled_edge_source_status_or_permission_grant':False,
    'tracked_source_registry_C_L_Git_mutations':False,
    'stop_boundary':'Await exact new Statement Seal and binder/definition packet; later distinct source-graph/topology/applicability challenge only. No target proof or normal intake has begun here.',
}
write('raw-freeze.json', freeze)
records = [digest(OWN/name) for name in local_names] + [digest(OWN/'raw-freeze.json')]
(OWN/'SHA256SUMS').write_text(''.join(f"{a['sha256']}  {Path(a['path']).name}\n" for a in records))
print(json.dumps({'raw_freeze':digest(OWN/'raw-freeze.json'),
                  'raw_reading':digest(OWN/'raw-reading.md'),
                  'exposure':digest(OWN/'exposure.json'),
                  'input_manifest':digest(OWN/'input-manifest.json'),
                  'R7_preservation_checks':len(preserved)},indent=2))
