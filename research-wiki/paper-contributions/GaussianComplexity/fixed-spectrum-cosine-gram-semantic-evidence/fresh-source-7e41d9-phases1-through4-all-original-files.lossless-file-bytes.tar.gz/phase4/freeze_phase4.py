#!/opt/anaconda3/bin/python
import datetime,hashlib,json,pathlib,stat
BASE=pathlib.Path(__file__).resolve().parent;ROOT=pathlib.Path('/Users/zhouhuanjian/ASTIS-GC')
assert not (BASE/'manifest.json').exists(),'Refuse to refreeze phase4.'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
contract=json.loads((BASE/'attachment_contract.json').read_text())
overlay=json.loads((BASE/'canonical-audit-attachment-overlay.json').read_text())
assert sha(ROOT/contract['canonical_audit'])==contract['baseline_audit_raw_sha256']
assert sha(BASE/'canonical-audit-attachment-overlay.json')==contract['overlay_sha256']
assert sha(BASE/'proposed-canonical-audit.json')==contract['proposed_audit_sha256']
assert sha(ROOT/overlay['source_review']['run_artifact'])==overlay['source_review']['review_run_sha256']
for row in json.loads((BASE/'input_inventory.json').read_text()):
    path=BASE/row['snapshot'];assert sha(path)==row['sha256'] and len(path.read_bytes())==row['bytes']
for row in contract['original_phase3_payload_copies']:
    path=BASE/row['snapshot'];assert sha(path)==row['sha256'] and len(path.read_bytes())==row['bytes']
commands=[json.loads(x) for x in (BASE/'actual_commands.jsonl').read_text().splitlines()]
for row in commands:
    assert row['returncode']==0
    for stream in ['stdout','stderr']:
        path=BASE/row[stream+'_file']
        assert sha(path)==row[stream+'_sha256'] and len(path.read_bytes())==row[stream+'_bytes']
for phase,digest in [('phase1','80d4eefdb9d3d733e60d4ea52d00207c5ca62e03c1964b94e404525c2e472079'),
                     ('phase2','8a5ff1011acb383f99d2411649240d48023186cac33c24323d9e95402361625e'),
                     ('phase3','3ce8cdccd41e6e93d361466e444efbde32e7de8bcac420e79ee322bc8435dbac')]:
    directory=BASE.parent/phase;assert sha(directory/'manifest.json')==digest
    for row in json.loads((directory/'manifest.json').read_text())['payloads']:
        path=directory/row['path'];assert sha(path)==row['sha256'] and stat.S_IMODE(path.stat().st_mode)==0o444
    assert stat.S_IMODE(directory.stat().st_mode)==0o555
entries=[]
for path in sorted(BASE.rglob('*')):
    if path.is_file():
        path.chmod(0o444)
        entries.append({'path':str(path.relative_to(BASE)),'bytes':len(path.read_bytes()),'sha256':sha(path),'mode':'0444'})
manifest={'phase':'phase4-postfreeze-native-closure-and-canonical-attachment-proposal-no-SourceV',
          'candidate_commit':'72e5d1405284f729f4eb600c5ae5dd556365b7e2','payloads':entries,
          'excluded_self_and_receipt':['manifest.json','freeze_receipt.json']}
mp=BASE/'manifest.json';mp.write_text(json.dumps(manifest,indent=2)+'\n');mp.chmod(0o444)
receipt={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'phase':manifest['phase'],
         'manifest_sha256':sha(mp),'overlay_sha256':sha(BASE/'canonical-audit-attachment-overlay.json'),
         'proposed_audit_sha256':sha(BASE/'proposed-canonical-audit.json'),
         'attachment_contract_sha256':sha(BASE/'attachment_contract.json'),
         'own_phase3_actual_review_execution_sha256':overlay['source_review']['review_run_sha256'],
         'payload_count':len(entries),'captured_child_command_count':len(commands),
         'captured_child_returncodes':[r['returncode'] for r in commands],
         'original_native_archive_verified_files':264,'phase1_phase2_phase3_verified_unchanged':True,
         'canonical_audit_not_modified':True,'SourceV_or_ledger_called':False,
         'reader_HOLD_all_six_step_neighbors_preserved':True,
         'freeze_execution_record_outside_phase':'../phase4_freeze_execution.json',
         'manifest_excludes_itself_and_receipt':True}
rp=BASE/'freeze_receipt.json';rp.write_text(json.dumps(receipt,indent=2)+'\n');rp.chmod(0o444)
for path in sorted(BASE.rglob('*'),reverse=True):
    if path.is_dir():path.chmod(0o555)
BASE.chmod(0o555)
assert all(stat.S_IMODE(p.stat().st_mode)==0o444 for p in BASE.rglob('*') if p.is_file())
assert all(stat.S_IMODE(p.stat().st_mode)==0o555 for p in BASE.rglob('*') if p.is_dir())
assert stat.S_IMODE(BASE.stat().st_mode)==0o555
print(json.dumps({'manifest_sha256':sha(mp),'overlay_sha256':sha(BASE/'canonical-audit-attachment-overlay.json'),
                  'proposed_audit_sha256':sha(BASE/'proposed-canonical-audit.json'),
                  'attachment_contract_sha256':sha(BASE/'attachment_contract.json'),'receipt_sha256':sha(rp),
                  'own_phase3_actual_review_execution_sha256':overlay['source_review']['review_run_sha256'],
                  'phase_directory':str(BASE),'phase_directory_mode_observed':'0555',
                  'all_phase_file_modes_observed':'0444','all_phase_subdirectory_modes_observed':'0555',
                  'payload_count':len(entries),'captured_child_command_count':len(commands),
                  'prior_phases_verified_unchanged':True,'canonical_audit_not_modified':True,
                  'SourceV_or_ledger_called':False},indent=2))
