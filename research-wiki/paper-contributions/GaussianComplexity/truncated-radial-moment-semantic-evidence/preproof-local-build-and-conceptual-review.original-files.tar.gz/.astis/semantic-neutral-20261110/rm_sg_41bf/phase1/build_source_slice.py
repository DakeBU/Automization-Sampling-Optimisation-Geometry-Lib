"""Build source-only p11/p12 graph and exact raw HTML inventory."""

from bisect import bisect_right
from hashlib import sha256
from html.parser import HTMLParser
import json
from pathlib import Path
import re


OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[3]
RAW = ROOT / '.astis/huanjian-resume-20261103/2610.20492v1.html'
BROAD = ROOT / '.astis/semantic-neutral-20261110/re_sg_b71f20/phase1'
PINS = {
    RAW: '6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915',
    BROAD / 'source-graph.json': '5cfcf774e44a2ca4a6f3656a30034a6f0bda1ccc04ce3d3fd40788e786bbfc57',
    BROAD / 'coverage.json': '502d2b23593418bb73607f3d1144cb3c584362eedb791503848bb3ece178173b',
}


def digest(data):
    return sha256(data).hexdigest()


for path, pin in PINS.items():
    assert digest(path.read_bytes()) == pin, path

raw = RAW.read_bytes()
source = raw.decode('utf-8')
line_starts = [0, *(m.end() for m in re.finditer('\n', source))]
anchors = {}


class ScopedParser(HTMLParser):
    def __init__(self, first_line):
        super().__init__(convert_charrefs=False)
        self.first_line = first_line
        self.stacks = {}

    def source_offset(self):
        line, column = self.getpos()
        return line_starts[self.first_line + line - 2] + column

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        label = attrs.get('id')
        if tag == 'a' and attrs.get('href') == '#A3.Thmtheorem5':
            label = 'A3.SS2.p12.4#Fact-C.5-link'
        self.stacks.setdefault(tag, []).append((label, self.source_offset()))

    def handle_endtag(self, tag):
        label, start = self.stacks[tag].pop()
        if label:
            assert label not in anchors, label
            end = source.index('>', self.source_offset()) + 1
            anchors[label] = (start, end)


for first, last in ((3317, 3329), (3532, 3607)):
    parser = ScopedParser(first)
    parser.feed(source[line_starts[first - 1]:line_starts[last]])
    parser.close()
    assert not any(parser.stacks.values()), parser.stacks


def literal(label, parent, token):
    start, end = anchors[parent]
    assert source.count(token, start, end) == 1, (label, parent, token)
    left = source.index(token, start, end)
    anchors[label] = (left, left + len(token))


def tex_parts(parent, *parts):
    start, end = anchors[parent]
    start = source.index('<annotation encoding="application/x-tex">', start, end)
    start = source.index('>', start) + 1
    end = source.index('</annotation>', start, end)
    for label, token in parts:
        assert source.count(token, start, end) == 1, (label, token)
        left = source.index(token, start, end)
        anchors[parent + '#' + label] = (left, left + len(token))


literal('A3.SS2.p1.2#row-independence', 'A3.SS2.p1.2', ' are independent\n')
literal('A3.SS2.p10.1#Markov', 'A3.SS2.p10.1', 'Markov’s inequality gives')
literal('A3.SS2.p10.2#joint-transition', 'A3.SS2.p10.2', 'Consequently, the event')
literal('A3.SS2.p11.1#same-tail', 'A3.SS2.p11.1', 'the same tail bound gives')
literal('A3.SS2.p11.1#hence', 'A3.SS2.p11.1', 'Hence')
literal('A3.SS2.p12.3#common-a', 'A3.SS2.p12.3', ' is the same for every ')
tex_parts('A3.Ex85.m1',
          ('t', r't_{i}=(1,\sqrt{2}\cos\theta_{i},\ldots,\sqrt{2}\cos(q\theta_{i}))^{\top}'),
          ('row', r'\gamma_{i}=((g_{1})_{i},\ldots,(g_{r})_{i})^{\top}'))
tex_parts('A3.Ex106.m2',
          ('identity', r'=L\mathbb{P}(R_{i}&gt;L)+\int_{0}^{\infty}\mathbb{P}(R_{i}&gt;L+s)\,ds'),
          ('bound', r'\leq\frac{L+3}{1000d}'))
tex_parts('A3.Ex108.m1',
          ('covariance', r'\mathbb{E}[\gamma_{i}\gamma_{i}^{\top}\mathbf{1}_{\{R_{i}\leq L\}}]=aI_{r}'),
          ('a', r'a=\frac{1}{r}\mathbb{E}[R_{i}\mathbf{1}_{\{R_{i}\leq L\}}]'))
tex_parts('A3.Ex109.m1',
          ('identity', r'1-a=\frac{1}{r}\mathbb{E}[R_{i}\mathbf{1}_{\{R_{i}&gt;L\}}]'),
          ('bound', r'\leq\frac{L+3}{1000rd}'))


nodes = []
items = {}
edges = []


def assign(source_ids, disposition, **info):
    for source_id in source_ids.split():
        assert source_id in anchors and source_id not in items, source_id
        items[source_id] = {'disposition': disposition, **info}


def node(identifier, kind, content, source_ids, parents=(), discharge=None, use_site=None):
    source_ids = source_ids.split()
    assert source_ids and all(s in anchors for s in source_ids), source_ids
    nodes.append({'id': identifier, 'kind': kind, 'content': content, 'source_ids': source_ids})
    if kind != 'SOURCE_GAP':
        assign(' '.join(source_ids), 'NODE', graph_node=identifier)
    if parents:
        edges.append({'from_all': list(parents), 'to': identifier, 'use_site': use_site or source_ids[-1],
                      'discharge_or_use': discharge})


node('row-index-dimension', 'source-setup', 'r=q+1 and 1≤i≤d.', 'A3.SS2.p1.m1 A3.SS2.p1.m3')
node('row-definition', 'source-definition', 'γ_i=((g_1)_i,…,(g_r)_i)ᵀ ∈ ℝ^r.', 'A3.Ex85.m1#row')
node('row-marginal', 'source-standing', 'Each γ_i has marginal law N(0,I_r).',
     'A3.SS2.p1.m4 A3.SS2.p1.m5')
node('radial-variable', 'source-definition', 'R_i=‖γ_i‖².', 'A3.SS2.p10.m2')
node('cutoff', 'source-definition', 'L=2r+3 log(1000d).', 'A3.SS2.p10.m1')
node('exp-moment', 'source-upstream-input', 'E exp(R_i/3)=3^(r/2). Its Gaussian computation is upstream of this increment.',
     'A3.SS2.p10.m3')
node('markov', 'source-named-reuse', 'Markov’s inequality for a nonnegative integrable variable and positive threshold.',
     'A3.SS2.p10.1#Markov')
node('log3', 'source-upstream-input', '(log 3)/2<2/3.', 'A3.SS2.p10.m5')
node('row-dimension-positive', 'SOURCE_GAP', 'r≥1.', 'A3.SS2.p1.m1', ('row-index-dimension',),
     'Use r=q+1 and the standing nonnegativity of q.')
node('log-argument-positive', 'SOURCE_GAP', 'd≥1, so 1000d>0 and log(1000d)≥0.',
     'A3.SS2.p1.m3 A3.SS2.p10.m1', ('row-index-dimension',),
     'The fixed row index satisfies 1≤i≤d.')
node('row-tail', 'source-reused-display', 'For x≥0, P(R_i>2r+3x)≤exp((r/2)log 3−2r/3−x)≤exp(−x).',
     'A3.SS2.p10.m4 A3.Ex104.m1', ('exp-moment', 'markov', 'log3', 'row-dimension-positive'),
     'Use W=exp(R_i/3)≥0 and a=exp((2r+3x)/3)>0, with finite expectation from the moment. Exponential monotonicity converts the strict event. The exponent comparison uses r≥1.')
node('cutoff-nonnegative', 'SOURCE_GAP', 'L≥0.', 'A3.SS2.p10.m1',
     ('row-dimension-positive', 'log-argument-positive', 'cutoff'), 'Use r≥1 and log(1000d)≥0 in the source cutoff formula.')
node('shift-substitution', 'SOURCE_GAP', 'For s≥0 set x=log(1000d)+s/3; x≥0, 2r+3x=L+s, and exp(−x)=exp(−s/3)/(1000d).',
     'A3.SS2.p11.m1 A3.SS2.p11.1#same-tail', ('cutoff', 'log-argument-positive'),
     'Use the cutoff expression and 1000d>0. The consumer’s weak endpoint s≥0 and log(1000d)≥0 supply x≥0.')
node('shifted-tail', 'source-unnamed-estimate', 'For each i and real s≥0, P(R_i>L+s)≤exp(−s/3)/(1000d).',
     'A3.SS2.p11.m1 A3.SS2.p11.1#same-tail A3.SS2.p11.m2', ('row-tail', 'shift-substitution'),
     'Apply Ex104 at x=log(1000d)+s/3, whose admissibility is supplied by shift-substitution.')
node('radial-regularity', 'SOURCE_GAP', 'R_i is nonnegative and measurable; the strict and weak threshold sets are measurable. Squared Euclidean norm is continuous.',
     'A3.SS2.p1.m5 A3.SS2.p10.m2', ('row-marginal', 'radial-variable'),
     'The Gaussian row is a random vector and the radial map is Borel.')
node('nonnegative-layer-cake', 'SOURCE_GAP', 'Pointwise R_i 1_{R_i>L}=L 1_{R_i>L}+(R_i−L)_+ and (R_i−L)_+=∫₀∞1_{R_i>L+s}ds. Nonnegative Tonelli gives the displayed identity in extended nonnegative values.',
     'A3.Ex106.m1 A3.Ex106.m2#identity', ('radial-regularity', 'cutoff-nonnegative'),
     'L≥0 makes both terms nonnegative. The product indicator is measurable since (ω,s)↦R_i(ω)−L−s is measurable. Its strict s-section has length (R_i−L)_+.')
node('integrate-envelope', 'SOURCE_GAP', '∫₀∞exp(−s/3)ds=3. The shifted bound gives finite integrable tail with integral ≤3/(1000d) and L P(R_i>L)≤L/(1000d).',
     'A3.SS2.p11.1#hence A3.Ex106.m2#bound', ('shifted-tail', 'cutoff-nonnegative', 'log-argument-positive'),
     'Use s=0 for the boundary term and L≥0 to multiply. For the integral use the pointwise envelope on s≥0; the tail function is monotone and therefore Borel, and 1000d>0.')
node('tail-moment-identity', 'source-unnamed-identity', 'E[R_i 1_{R_i>L}]=L P(R_i>L)+∫₀∞P(R_i>L+s)ds.',
     'A3.Ex106.m1 A3.Ex106.m2#identity', ('nonnegative-layer-cake', 'integrate-envelope'),
     'The extended identity and finite right side give integrability of the nonnegative left-hand variable and identify all terms as finite reals.')
node('tail-moment-upper', 'source-unnamed-bound', 'E[R_i 1_{R_i>L}]≤(L+3)/(1000d).',
     'A3.SS2.p11.1#hence A3.Ex106.m2#bound', ('tail-moment-identity', 'integrate-envelope'),
     'Insert the two finite estimates into Ex106 and add.')
node('radial-second-moment', 'SOURCE_GAP', 'R_i is a finite sum of squared centered coordinates with variance one. Each square is integrable with mean one; hence R_i is integrable and E R_i=r.',
     'A3.SS2.p12.m3', ('row-marginal', 'radial-variable'),
     'Use N(0,I_r) coordinate mean and diagonal covariance. This needs no product of distinct coordinates.')
node('radial-mean', 'source-unnamed-estimate', 'E R_i=r, with the finite expectation supplied by the Gaussian second moment.',
     'A3.SS2.p12.m3', ('radial-second-moment',), 'The omitted coordinate calculation gives this source assertion.')
node('scalar-a', 'source-definition', 'a=(1/r)E[R_i 1_{R_i≤L}].', 'A3.Ex108.m1#a')
node('truncated-integrability', 'SOURCE_GAP', 'Both truncations R_i 1_{R_i≤L} and R_i 1_{R_i>L} are measurable, nonnegative, bounded by R_i and integrable.',
     'A3.Ex108.m1#a A3.Ex109.m1#identity', ('radial-regularity', 'radial-mean'),
     'Multiply by the indicated measurable event indicator and dominate by integrable R_i.')
node('common-a', 'source-assertion', 'The same a works for each i.',
     'A3.SS2.p12.m1 A3.SS2.p12.3#common-a A3.SS2.p12.m2', ('scalar-a', 'row-marginal', 'truncated-integrability'),
     'Apply the same measurable truncated squared norm to each identical marginal law. The proof of integrability is the same for each i.',
     use_site='A3.SS2.p12.3#common-a')
node('complementary-truncations', 'SOURCE_GAP', 'The two indicated variables sum to R_i pointwise, so their expectations add to r.',
     'A3.Ex108.m1#a A3.Ex109.m1#identity', ('truncated-integrability', 'radial-mean'),
     'The events {R_i≤L} and {R_i>L} partition the sample space, with equality in the retained event.')
node('scalar-range', 'source-unnamed-bound', '0≤a≤1.',
     'A3.SS2.p12.m4', ('scalar-a', 'truncated-integrability', 'radial-mean', 'row-dimension-positive'),
     'The retained variable is between 0 and R_i, so its expectation is between 0 and r. Divide by r>0.')
node('scalar-bias-identity', 'source-unnamed-identity', '1−a=(1/r)E[R_i 1_{R_i>L}].',
     'A3.Ex109.m1#identity', ('scalar-a', 'complementary-truncations', 'row-dimension-positive'),
     'Subtract the retained expectation from the total r and divide by r>0.')
node('scalar-bias-upper', 'source-unnamed-bound', '1−a≤(L+3)/(1000rd).',
     'A3.Ex109.m1#bound', ('scalar-bias-identity', 'tail-moment-upper', 'row-dimension-positive'),
     'Scale the p11 moment upper bound by 1/r>0 and combine the denominators.')

assign('A3.SS2.p1.m2 A3.Ex85.m1#t A3.SS2.p1.m6 A3.SS2.p1.m7 A3.SS2.p1.m8', 'EXCLUDED',
       reason='Cosine index, t_i and matrix B construction. Scalar R_i is the squared norm of γ_i alone.')
assign('A3.SS2.p1.2#row-independence', 'EXCLUDED',
       reason='Joint independence of different rows. The estimates use only fixed-row laws and equality of marginals for common a.')
assign('A3.SS2.p10.2#joint-transition A3.Ex105 A3.Ex105.m1 A3.SS2.p10.3 A3.SS2.p10.3.1 A3.SS2.p10.m6',
       'EXCLUDED', reason='Separate all-rows event T and its probability. p11 invokes Ex104; it is unconditional.')
assign('A3.SS2.p12.1 A3.SS2.p12.1.1 A3.Ex107 A3.Ex107.m1', 'EXCLUDED',
       reason='Definition and joint independence of truncated matrices Y_i.')
assign('A3.SS2.p12.2 A3.SS2.p12.2.1 A3.Ex108.m1#covariance', 'EXCLUDED',
       reason='Radial-symmetry matrix expectation. The accompanying scalar definition is an independent component of Ex108.')
assign('A3.SS2.p12.4 A3.SS2.p12.4.1 A3.SS2.p12.m5 A3.SS2.p12.4#Fact-C.5-link A3.Ex110 A3.Ex110.m1 A3.SS2.p12.5 A3.SS2.p12.5.1',
       'EXCLUDED', reason='Downstream per-matrix expectation and C.5 application to matrix sums, including the weighted zero expectation.')
assign('A3.SS2.p10.1.1', 'EXCLUDED', reason='Section-style title only.')

for source_id in anchors.keys() - items.keys():
    assign(source_id, 'EXCLUDED', reason='HTML container or mixed prose wrapper. Substantive content has its own item-level dispositions.')


def locator(source_id):
    start, end = anchors[source_id]
    byte_start = len(source[:start].encode('utf-8'))
    byte_end = len(source[:end].encode('utf-8'))
    line = bisect_right(line_starts, start)
    span = raw[byte_start:byte_end]
    assert span.decode('utf-8') == source[start:end]
    return {'char_start': start, 'char_end': end, 'raw_utf8_start': byte_start, 'raw_utf8_end': byte_end,
            'lf_line_start': line, 'lf_column0_start': start - line_starts[line - 1],
            'lf_line_end': bisect_right(line_starts, end - 1), 'span_sha256': digest(span)}


roots = ['shifted-tail', 'tail-moment-identity', 'tail-moment-upper', 'scalar-a', 'common-a', 'scalar-range',
         'scalar-bias-identity', 'scalar-bias-upper']
seen = set()
for record in nodes:
    identifier = record['id']
    assert identifier not in seen
    parents = next((e['from_all'] for e in edges if e['to'] == identifier), [])
    assert set(parents) <= seen, (identifier, parents)
    seen.add(identifier)
assert set(roots) <= seen
assert set(items) == set(anchors)

coverage = {
    'scope': ['A3.SS2.p1', 'A3.SS2.p10', 'A3.SS2.p11', 'A3.SS2.p12'],
    'scope_rule': 'Complete bounded HTML ID inventory plus exact substantive subspans. Existing broad inventory supplies the outer boundary.',
    'locators': 'Offsets are zero-based and end-exclusive, columns zero-based, LF lines one-based. Subspan labels use #.',
    'broad_coverage': {'path': str((BROAD / 'coverage.json').relative_to(ROOT)), 'sha256': PINS[BROAD / 'coverage.json']},
    'inventory_items': len(items),
    'NODE': sum(i['disposition'] == 'NODE' for i in items.values()),
    'EXCLUDED': sum(i['disposition'] == 'EXCLUDED' for i in items.values()),
    'items': [{'source_id': label, 'locator': locator(label), **items[label]}
              for label in sorted(items, key=anchors.__getitem__)],
}
graph = {
    'artifact_role': 'Bounded source-only reconstruction of the p11/p12 scalar increment',
    'raw_source': str(RAW.relative_to(ROOT)),
    'raw_source_sha256': PINS[RAW],
    'broad_source_graph': {'path': str((BROAD / 'source-graph.json').relative_to(ROOT)), 'sha256': PINS[BROAD / 'source-graph.json']},
    'standing_scope': 'The surrounding paper uses q a nonnegative integer and 2q+1<d. The local estimates use integer r=q+1≥1, positive integer d, a fixed row 1≤i≤d, and its N(0,I_r) marginal. Source context is indexed in the prior broad graph.',
    'roots': roots,
    'nodes': nodes,
    'edges': edges,
    'alternative_routes_in_this_slice': [],
    'coverage_file': 'coverage.json',
    'mathematics_file': 'source-math.md',
    'review_status': 'Author freeze for distinct source review',
}
for name, value in (('source-graph.json', graph), ('coverage.json', coverage)):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

print(f"Verified {len(PINS)} input pins, {len(raw)} source bytes, {len(source)} Unicode codepoints.")
print(f"Wrote {len(nodes)} graph nodes ({sum(n['kind'] == 'SOURCE_GAP' for n in nodes)} gaps), {len(edges)} immediate hyperedges, {len(roots)} roots.")
print(f"Classified {len(items)} exact raw locators: {coverage['NODE']} NODE and {coverage['EXCLUDED']} EXCLUDED.")
