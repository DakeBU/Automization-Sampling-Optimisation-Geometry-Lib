"""Source-only graph from phase1 raw reading; exact seal text projected after freeze."""
from pathlib import Path
import json, hashlib, datetime

ROOT=Path('/Users/zhouhuanjian/ASTIS-GC')
BASE=ROOT/'.astis/huanjian-gc-fixed-spectrum-exact-means-20261110'
OUT=BASE/'independent-source-graph'
P2=OUT/'phase2'
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def save(name, data): (P2/name).write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n')
inputs={
 'statement-seal-v1.json':'81900673dcb74d8e5a321be926904feadd368478f651c619cb3675ee0cc92e3e',
 'multivariateGaussian-standard-definition.txt':'512ddbd6cb835fbf4bd28967f04a22cb0c0afe42e57036932fbbe27f3a2cf2cd',
 'producer-signature.txt':'0fed0efb7d7e4170caca9a7006abae3f285561984424146ca2fed40359b9ad8e',
 'consumer-signature.txt':'769a50ba478485a62579b0d565e3118d41e4a165dfa43d519b3ae0f22a71b7ba'}
for f,h in inputs.items(): assert digest(BASE/f)==h
assert digest(OUT/'phase1-freeze-v1.json')=='c447aab6715d9f316bb3d34a1754df15c8078a3da743def7d79a2047639f7a78'
seal=json.loads((BASE/'statement-seal-v1.json').read_text())
inv=json.loads((OUT/'phase1/raw-inventory.json').read_text())
nodes=[]; edges=[]
def node(i,kind,stmt,refs,**kw):
    nodes.append(dict(id=i,kind=kind,statement=stmt,source_refs=refs,formal_credit=False,**kw))
def edge(i,fr,to,use,guards=None,**kw):
    edges.append(dict(id=i,logic='AND',from_nodes=fr,to_node=to,consumer_use_sites=use,guard_discharge=guards or [],proof_ingredients_are_internal_edges=True,**kw))
def guard(p,by,why): return dict(predicate=p,discharged_by=by,reason=why,status='source mathematical discharge specified; formal proof not audited')

# Standing definitions. Only these source/typing restrictions are public inputs.
node('standing','source_hypotheses','d>=2; kappa>=2; n integer with 1<=n<d.',['S4.SS1.p1.1','S4.Thmtheorem5.p1.1','A3.Thmtheorem8.p1.1'],public_input=True)
node('grid','source_definition','theta_i=(i-1/2)pi/d, i=1,...,d; lambda_i=(kappa+1)/2+(kappa-1)cos(theta_i)/2; Lambda=diag(lambda_i) is precision.',['S4.E11','A3.SS3.p1.1'])
node('actual_objects','source_definition','U~N(0,Lambda^-1); D_n=diag(cos(n theta_i)); M=E||U||^2; mu_n=E[U^T D_n U].',['S4.Thmtheorem5.p1.1'])
node('r_def','source_definition','r=(sqrt(kappa)-1)/(sqrt(kappa)+1).',['S4.Thmtheorem5.p1.1'])
node('r_interval','internal_guard','sqrt(kappa)>1; sqrt(kappa)+1>0; 0<r<1.',['A3.SS3.p2.1','A3.SS3.p9.1'],derivation='kappa>=2 implies sqrt(kappa)>1; the numerator is positive and smaller than positive denominator.')
edge('e-r-interval',['standing','r_def'],'r_interval',['A3.SS3.p2.1','A3.SS3.p9.1'])
node('scalar_guards','internal_guard','d/sqrt(kappa)>0; d>0; n>0; d-n>0; 2d-n>n; Nat differences d-n and 2d-n equal intended integer differences.',['S4.E11','A3.SS3.p6.2','A3.SS3.p9.1'],derivation='d>=2, 1<=n<d, kappa>=2. In Nat: n<=d and n<=2*d, then cast subtraction; 2*d-n=n+2*(d-n).')
edge('e-scalar-guards',['standing','r_interval'],'scalar_guards',['A3.SS3.p6.2','A3.SS3.p9.1'])

# C7, retaining normalization and convergence as different ingredients.
node('gap_complex_denominators','SOURCE_GAP','The two geometric complex denominators 1+r exp(±i theta) are nonzero; real 1+2r cos(theta)+r^2 >= (1-r)^2>0.',['A3.Ex134','A3.Ex135'],gap_type='source suppresses denominator proof',obligation_not_public_premise=True,discharge='|r exp(±i theta)|=r<1; norm reverse triangle inequality; squared norm identity.')
edge('e-complex-denominators',['r_interval'],'gap_complex_denominators',['A3.Ex134','A3.Ex135'],[guard('r<1',['r_interval'],'unit complex exponential preserves modulus')])
node('c7_complex_geometric','source_step','Positive-j geometric sums of (-r exp(i theta))^j and conjugate sum give Ex134.',['A3.SS3.p2.1','A3.Ex134'])
edge('e-c7-complex-geometric',['r_interval','gap_complex_denominators'],'c7_complex_geometric',['A3.Ex134'],[guard('|-r exp(±i theta)|<1',['r_interval'],'modulus equals r')])
node('c7_rational','source_step','1+2 sum_{j>=1}(-r)^j cos(j theta)=(1-r^2)/(1+2r cos(theta)+r^2).',['A3.Ex135'])
edge('e-c7-rational',['c7_complex_geometric','gap_complex_denominators'],'c7_rational',['A3.Ex135'])
node('c7_normalization','source_step','(1-r)/(1+r)=1/sqrt(kappa); (1+2r cos(theta)+r^2)/(1-r)^2=(kappa+1+(kappa-1)cos(theta))/2.',['A3.SS3.p2.2','A3.Ex136'])
edge('e-c7-normalization',['r_def','r_interval'],'c7_normalization',['A3.Ex136'],[guard('sqrt(kappa)>0 and 1±r>0',['r_interval'],'0<r<1 and kappa>=2')])
node('c7_expansion','source_result','2/(kappa+1+(kappa-1)cos(theta))=1/sqrt(kappa)*(1+2 sum_{j>=1}(-r)^j cos(j theta)), for every real theta.',['A3.Thmtheorem7.p1.1','A3.Ex133','A3.SS3.p2.3'])
edge('e-c7-expansion',['c7_rational','c7_normalization','gap_complex_denominators'],'c7_expansion',['A3.SS3.p2.3','A3.Ex133'])
node('c7_majorant','source_step','sum_{j>=1}|(-r)^j cos(j theta)| <= sum_{j>=1}r^j = r/(1-r), uniformly in theta.',['A3.Ex137'])
edge('e-c7-majorant',['r_interval'],'c7_majorant',['A3.Ex137'],[guard('0<=r<1; 1-r>0',['r_interval'],'absolute cos<=1; geometric positive-j series')])
node('c7_absolute','source_result','The inverse-spectrum cosine series is absolutely convergent for each theta.',['A3.Thmtheorem7.p1.2','A3.SS3.p2.4'])
edge('e-c7-absolute',['c7_majorant'],'c7_absolute',['A3.SS3.p2.4','A3.SS3.p4.2'])
node('c7_uniform','source_result','The inverse-spectrum cosine series converges uniformly in theta.',['A3.Thmtheorem7.p1.2','A3.SS3.p2.4'],selected_root_requirement=False)
edge('e-c7-uniform',['c7_majorant'],'c7_uniform',['A3.SS3.p2.4'],justification='Weierstrass geometric majorant; source states this conclusion, exact selected route uses absolute convergence.')

# All-integer alias, before any positive-index selection.
node('gap_alias_sine_denominator','SOURCE_GAP','For integer k not in 2d Z, sin(k*pi/(2d)) != 0; the finite cosine-sum quotient is legal.',['A3.SS3.p3.2'],gap_type='source suppresses denominator equivalence',obligation_not_public_premise=True,discharge='d>0; sin(pi*x)=0 iff x is integer; equivalently k=2ad for integer a.')
edge('e-alias-sine-denominator',['standing','scalar_guards'],'gap_alias_sine_denominator',['A3.SS3.p3.2'])
node('alias_nonmultiple','source_step','For k integer outside 2d Z: sum_i cos(k theta_i)=sin(k*pi)/(2 sin(k*pi/(2d)))=0.',['A3.SS3.p3.2'])
edge('e-alias-nonmultiple',['grid','gap_alias_sine_denominator'],'alias_nonmultiple',['A3.SS3.p3.2'],[guard('denominator nonzero',['gap_alias_sine_denominator'],'applies only outside 2d Z')])
node('alias_multiple','source_step','For k=2ad with a in Z, each cos(k theta_i)=cos(2ai*pi-a*pi)=(-1)^a, hence sum=d(-1)^a.',['A3.SS3.p3.2'])
edge('e-alias-multiple',['grid','standing'],'alias_multiple',['A3.SS3.p3.2'])
node('alias_all_int','source_result','For EVERY k in Z, sum_i cos(k theta_i)=d(-1)^a when k=2ad (a in Z), and 0 otherwise; includes k<0 and k=0.',['A3.SS3.p3.1','A3.Ex139'])
edge('e-alias-all-int',['alias_nonmultiple','alias_multiple'],'alias_all_int',['A3.Ex139'],case_split='k in 2d Z OR k outside 2d Z; these cases cover frequencies, not alternate complete proofs')

# Actual Gaussian substrate is reused as a proved internal producer, never a binder.
node('actual_gaussian_to_grid','existing_canonical_substrate_reuse','Actual Gaussian norm-square and cosine-quadratic integrability, E U_i^2=1/lambda_i, M=sum_i 1/lambda_i, mu_n=sum_i cos(n theta_i)/lambda_i.',['A3.SS3.p4.1','A3.Ex140'],reuse_from_seal='FixedSpectrumGaussianMoments.actual_diagonal_gaussian_quadratic_means; text-only reuse identification, implementation not read',source_implicit_steps=['finite second-moment integrability','Euclidean norm-square expansion','diagonal quadratic-form finite linearity','inverse diagonal covariance gives reciprocal eigenvalues'],not_new_target_input=True,not_required_as_separate_binder=True,does_not_require_selected_packet=['variance','fourth moments','offdiagonal fourth-product estimates','upper-spectrum theorem'])
edge('e-actual-gaussian-to-grid',['standing','grid','actual_objects'],'actual_gaussian_to_grid',['A3.SS3.p4.1','A3.Ex140'],justification='Reuse already canonical actual Gaussian-to-grid substrate. Source law covariance is Lambda^-1. All substrate guards are discharged inside reuse; none added to exact-means signature.')
node('gap_finite_series_exchange','SOURCE_GAP','Interchange the finite i-sum with each absolutely summable j-series; multiplication by cos(n theta_i) preserves absolute summability.',['A3.SS3.p4.2'],gap_type='source asserts exchange but omits detailed finite linearity/weighted domination',obligation_not_public_premise=True,discharge='For each of finitely many i, bound weighted summands by r^j since |cos|<=1, then finite sum linearity of convergent series.')
edge('e-finite-series-exchange',['c7_absolute','grid','standing'],'gap_finite_series_exchange',['A3.SS3.p4.2'],[guard('finite grid and absolute summability',['standing','c7_absolute'],'finite i; cos weight bounded by 1')])
node('expanded_grid_sums','source_step','Replace 1/lambda_i in BOTH actual grid sums using C7 and exchange finite grid and infinite cosine sums.',['A3.SS3.p4.2'])
edge('e-grid-series-absolute-route',['actual_gaussian_to_grid','c7_expansion','gap_finite_series_exchange'],'expanded_grid_sums',['A3.SS3.p4.2'],route='ABSOLUTE_FINITE_EXCHANGE',route_selected=True)

# M route: positive j, multiples of 2d, sign and geometric resummation.
node('m_positive_alias_support','source_step','For positive j, nonzero aliases are exactly j=2ad, a>=1. Constant mode j=0 is separate; (-r)^(2ad)=r^(2ad).',['A3.SS3.p5.1'])
edge('e-m-support',['alias_all_int','standing','scalar_guards'],'m_positive_alias_support',['A3.SS3.p5.1','A3.Ex141'],[guard('d>0 and j>=1',['scalar_guards'],'an integer a with j=2ad must have a>=1; 2ad even')])
node('gap_m_reindex','SOURCE_GAP','Reindex positive supported j by the bijection a>=1 -> j=2ad, preserving the absolutely convergent sum.',['A3.SS3.p5.1','A3.Ex141'],gap_type='source gives support but suppresses formal reindexing',obligation_not_public_premise=True,discharge='d>0 makes a->2ad injective; alias support gives surjectivity onto survivors; absolute summability permits restriction/reindexing.')
edge('e-m-reindex',['m_positive_alias_support','c7_absolute','scalar_guards'],'gap_m_reindex',['A3.Ex141'])
node('m_tail_series','source_step','M=d/sqrt(kappa)*(1+2 sum_{a>=1}(-1)^a r^(2ad)).',['A3.Ex141'])
edge('e-m-tail-series',['expanded_grid_sums','m_positive_alias_support','gap_m_reindex'],'m_tail_series',['A3.Ex141'])
node('tail_geometric_guards','internal_guard','q=r^(2d) satisfies 0<q<1, |(-q)|<1, 1+q>0 and 1-q>0.',['A3.Ex142','A3.Ex146','A3.SS3.p9.1'],derivation='0<r<1 and 2d>0; geometric ratio is -q.')
edge('e-tail-guards',['r_interval','scalar_guards'],'tail_geometric_guards',['A3.Ex142','A3.Ex146','A3.SS3.p8.2','A3.Ex150'])
node('m_tail_summed','source_step','M=d/sqrt(kappa)*(1-2r^(2d)/(1+r^(2d))).',['A3.Ex142'])
edge('e-m-tail-summed',['m_tail_series','tail_geometric_guards'],'m_tail_summed',['A3.Ex142'],[guard('|-r^(2d)|<1 and 1+r^(2d)!=0',['tail_geometric_guards'],'positive-j alternating geometric series sum -q/(1+q)')])
node('m_exact','source_result','M=d/sqrt(kappa)*(1-r^(2d))/(1+r^(2d)).',['A3.Ex143','A3.Ex138','S4.Ex16'])
edge('e-m-exact',['m_tail_summed','tail_geometric_guards'],'m_exact',['A3.Ex143'],[guard('1+r^(2d)!=0',['tail_geometric_guards'],'legitimate simplification')])

# Weighted route, preserving the three distinct classes and Nat/Int boundaries.
node('weighted_constant_zero','source_step','sum_i cos(n theta_i)=0, because 0<n<d excludes n in 2d Z.',['A3.SS3.p6.1'])
edge('e-weighted-constant-zero',['alias_all_int','standing','scalar_guards'],'weighted_constant_zero',['A3.SS3.p6.1','A3.Ex144'])
node('weighted_product_to_sum','source_step','2 cos(n theta_i)cos(j theta_i)=cos((j-n)theta_i)+cos((j+n)theta_i); j-n is an integer frequency.',['A3.SS3.p6.1','A3.Ex144'])
edge('e-product-to-sum',['grid'],'weighted_product_to_sum',['A3.SS3.p6.1','A3.Ex144'])
node('weighted_series','source_step','mu_n=1/sqrt(kappa) sum_{j>=1}(-r)^j [sum_i cos((j-n)theta_i)+sum_i cos((j+n)theta_i)].',['A3.Ex144'])
edge('e-weighted-series',['expanded_grid_sums','weighted_constant_zero','weighted_product_to_sum'],'weighted_series',['A3.Ex144'])
node('weighted_class_center','source_step','First inner sum: j=n gives k=j-n=0, value d; this is a singleton positive-j class.',['A3.SS3.p6.2'])
edge('e-weighted-center',['alias_all_int','standing'],'weighted_class_center',['A3.SS3.p6.2','A3.Ex145'])
node('weighted_class_plus','source_step','Other nonzero first-inner aliases: exactly j=2ad+n, a>=1, with value d(-1)^a. No negative-a aliases survive.',['A3.SS3.p6.2'])
edge('e-weighted-plus',['alias_all_int','standing','scalar_guards'],'weighted_class_plus',['A3.SS3.p6.2','A3.Ex145'],[guard('j>=1 and 0<n<d',['standing'],'j-n> -d, so multiple 2ad cannot have a<0; a=0 is j=n')])
node('weighted_class_minus','source_step','Nonzero second-inner aliases: exactly j=2ad-n, a>=1, with value d(-1)^a; 2ad-n>0.',['A3.SS3.p6.2'])
edge('e-weighted-minus',['alias_all_int','standing','scalar_guards'],'weighted_class_minus',['A3.SS3.p6.2','A3.Ex145'],[guard('a>=1 and 2ad>n',['standing','scalar_guards'],'j+n positive excludes a<=0; n<d<=ad, so difference positive')])
node('weighted_disjoint_parity','source_step','Three classes j=n, 2ad+n, 2ad-n (a>=1) are pairwise disjoint; (-r)^(2ad±n)=(-1)^n r^(2ad±n).',['A3.SS3.p6.2'])
edge('e-weighted-disjoint-parity',['weighted_class_center','weighted_class_plus','weighted_class_minus','standing','scalar_guards'],'weighted_disjoint_parity',['A3.SS3.p6.2','A3.Ex145'],[guard('0<n<d; 2ad-n nonnegative',['standing','scalar_guards'],'center/plus would force a=0; center/minus gives n=ad; plus/minus gives n=(b-a)d, impossible in (0,d). Even 2ad gives parity n for both differences.')])
node('gap_weighted_reindex','SOURCE_GAP','Restriction, disjoint union and bijective reindexing of the positive-j series into the singleton and the two shifted positive-a tails are justified by absolute summability.',['A3.SS3.p6.2','A3.Ex145'],gap_type='source asserts classification/consequence but suppresses formal infinite-sum reindexing',obligation_not_public_premise=True,discharge='The three support descriptions are exhaustive; each a-map is injective since d>0; disjointness prevents double counting; original weighted series is absolutely summable.')
edge('e-weighted-reindex',['weighted_series','weighted_disjoint_parity','c7_absolute','scalar_guards'],'gap_weighted_reindex',['A3.Ex145'])
node('weighted_three_class_series','source_step','(-1)^n mu_n=d/sqrt(kappa)*[r^n+sum_{a>=1}(-1)^a(r^(2ad+n)+r^(2ad-n))].',['A3.Ex145'])
edge('e-weighted-three-class-series',['weighted_series','weighted_class_center','weighted_class_plus','weighted_class_minus','weighted_disjoint_parity','gap_weighted_reindex'],'weighted_three_class_series',['A3.Ex145'])
node('gap_shifted_geometric_indices','SOURCE_GAP','For a>=1: 2ad+n=(2d+n)+2d(a-1); 2ad-n=(2d-n)+2d(a-1), with 2d-n>0. Both shifted tails have common ratio -r^(2d) and are absolutely summable.',['A3.Ex146'],gap_type='source suppresses shifted geometric-series/index arithmetic details',obligation_not_public_premise=True,discharge='a>=1 permits predecessor a-1; n<d ensures nontruncated natural differences. Factor fixed initial powers, then apply |ratio|<1.')
edge('e-shifted-geometric-indices',['scalar_guards','tail_geometric_guards'],'gap_shifted_geometric_indices',['A3.Ex146'],[guard('a>=1, n<d, |ratio|<1',['standing','scalar_guards','tail_geometric_guards'],'valid predecessor and difference arithmetic; summable geometric factors')])
node('weighted_tails_summed','source_step','(-1)^n mu_n=d/sqrt(kappa)*[r^n-(r^(2d+n)+r^(2d-n))/(1+r^(2d))].',['A3.Ex146'])
edge('e-weighted-tails-summed',['weighted_three_class_series','gap_shifted_geometric_indices','tail_geometric_guards'],'weighted_tails_summed',['A3.Ex146'],[guard('1+r^(2d)>0 and both shifted tails summable',['tail_geometric_guards','gap_shifted_geometric_indices'],'sum -r^(2d±n)/(1+r^(2d))')])
node('mu_exact','source_result','(-1)^n mu_n=d/sqrt(kappa)*(r^n-r^(2d-n))/(1+r^(2d)).',['A3.Ex147','A3.Ex138','S4.Ex16'])
edge('e-mu-exact',['weighted_tails_summed','tail_geometric_guards','scalar_guards'],'mu_exact',['A3.Ex147'],[guard('1+r^(2d)!=0',['tail_geometric_guards'],'common denominator and r^(2d+n)=r^n*r^(2d) cancellation')])
node('producer_root','sealed_root','Actual integrability of norm-square and Q, and BOTH closed exact Gaussian mean equalities, as sealed.',['A3.Ex138','A3.SS3.p7.1','S4.Ex16'],seal_component='producer',theorem_name=seal['producer']['name'])
edge('e-producer-root',['actual_gaussian_to_grid','m_exact','mu_exact'],'producer_root',['A3.Ex138','A3.SS3.p7.1','S4.Ex16'],justification='Conjoin the two derived equalities and inherited integrability. Their conclusions are not theorem binders.')

# Consumer subroots: variance does not feed the M bound.
node('m_positive_upper','source_consumer','0<M and M<=d/sqrt(kappa).',['A3.SS3.p8.2'],source_explicit='M upper bound explicit; strict M positivity implicit needed by Ex150 normalization')
edge('e-m-positive-upper',['m_exact','tail_geometric_guards','scalar_guards'],'m_positive_upper',['A3.SS3.p8.2','A3.Ex150'],[guard('d/sqrt(kappa)>0; 0<q<1',['scalar_guards','tail_geometric_guards'],'0<(1-q)/(1+q)<=1')],excluded_inputs=['A3.SS3.p8.1','A3.Ex148','A3.Ex149','coordinate independence','Gaussian fourth moment'])
node('mu_signed_positive','source_consumer','0<(-1)^n mu_n, since n<2d-n and 0<r<1 imply r^n>r^(2d-n).',['A3.SS3.p9.1'])
edge('e-mu-signed-positive',['mu_exact','r_interval','scalar_guards','tail_geometric_guards'],'mu_signed_positive',['A3.SS3.p9.1'],[guard('n<2d-n; r>0; r<1; scale/denominator positive',['scalar_guards','r_interval','tail_geometric_guards'],'strict antitonicity of positive powers in exponent')])
node('gap_absolute_sign','SOURCE_GAP','|mu_n|=(-1)^n mu_n, using positive signed mu and |(-1)^n|=1.',['A3.SS3.p9.1','A3.Ex150'],gap_type='source says dividing formulas but suppresses absolute-value sign elimination',obligation_not_public_premise=True,discharge='abs signed_mu=signed_mu by positivity; abs product=abs((-1)^n)*abs(mu_n)=abs(mu_n).')
edge('e-absolute-sign',['mu_signed_positive'],'gap_absolute_sign',['A3.Ex150'])
node('gap_ratio_normalization','SOURCE_GAP','All cancellation factors are nonzero: M>0, d/sqrt(kappa)>0, 1+r^(2d)>0, 1-r^(2d)>0. Also 2d-n=n+2(d-n).',['A3.SS3.p9.1','A3.Ex150'],gap_type='source omits denominator discharge and exponent factorization',obligation_not_public_premise=True,discharge='M positivity from exact M branch; q=r^(2d) in (0,1); n<d makes Nat subtraction exact; r^(2d-n)=r^n*r^(2(d-n)).')
edge('e-ratio-normalization',['m_positive_upper','scalar_guards','tail_geometric_guards'],'gap_ratio_normalization',['A3.Ex150'])
node('ratio_exact','source_consumer','|mu_n|/M=r^n*(1-r^(2(d-n)))/(1-r^(2d)), for the actual Gaussian means.',['A3.Ex150'])
edge('e-ratio-exact',['m_exact','mu_exact','gap_absolute_sign','gap_ratio_normalization'],'ratio_exact',['A3.SS3.p9.1','A3.Ex150'],[guard('M and both cancelled common factors nonzero',['gap_ratio_normalization'],'divide actual exact means and factor powers'),guard('|mu_n| equals signed mu',['gap_absolute_sign'],'uses signed positivity')])
node('consumer_root','sealed_root','0<m, m<=d/sqrt(kappa), 0<(-1)^n*b, and |b|/m=r^n*(1-r^(2(d-n)))/(1-r^(2d)), where m,b are the actual integrals.',['A3.SS3.p8.2','A3.SS3.p9.1','A3.Ex150'],seal_component='actual_private_consumer',theorem_name=seal['actual_private_consumer']['name'])
edge('e-consumer-root',['producer_root','m_positive_upper','mu_signed_positive','ratio_exact'],'consumer_root',['A3.SS3.p8.2','A3.SS3.p9.1','A3.Ex150'],justification='Intended real producer-consumer edge: specialize actual producer once; use BOTH equalities for ratio and inherited integrability. No free m,b callbacks or formula-valued definitions.')

alternatives=[dict(id='exchange-choice',target='expanded_grid_sums',logic='OR',selected='e-grid-series-absolute-route',routes=[dict(id='e-grid-series-absolute-route',status='selected source route',requires=['actual_gaussian_to_grid','c7_expansion','c7_absolute','gap_finite_series_exchange']),dict(id='uniform-exchange-unselected',status='possible mathematical route; not a separate author proof and not claimed discharged',requires=['actual_gaussian_to_grid','c7_expansion','c7_uniform','finite linearity plus convergence-to-limit exchange proof'])],prohibition='Do not flatten absolute and uniform into a mandatory AND. No alternate complete source proof of either mean appears in C.3.')]

graph=dict(schema_version=1,artifact_kind='independent source proof graph',state='FROZEN_FOR_DISTINCT_REVIEW_NOT_APPROVED',source_sha256='6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915',phase1_freeze_sha256=digest(OUT/'phase1-freeze-v1.json'),seal_id=seal['seal_id'],seal_sha256=inputs['statement-seal-v1.json'],root_nodes=['producer_root','consumer_root'],public_input_nodes=['standing'],semantics='AND hyperedges carry internal proof ingredients. SOURCE_GAP nodes retain omitted details with explicit mathematical discharge obligations; they are not external premises or proof credit. Source definitions fix actual objects. Existing canonical reuse is an internal theorem dependency, not a binder.',nodes=nodes,edges=edges,alternative_routes=alternatives,exclusions_never_required=['variance','Gaussian fourth moments','offdiagonal mixed fourth-product estimates','coordinate independence','upper-spectrum theorem as a new premise','d-n>=sqrt(kappa)','Ex151 factor bounds','logarithmic/exponential bias bounds','whole Lemma4.5 completion'],no_implementation_access=True,no_proof_or_verified_credit=True)
save('source-proof-graph-v1.json',graph)

# Exhaustive coverage: one disposition per raw inventory item, never silence.
mapping={
'S4.SS1.p1.1':['standing'],'S4.E11':['grid'],
'S4.Thmtheorem5.p1.1':['standing','grid','actual_objects','r_def'],
'S4.Ex16':['producer_root'],
'A3.SS3.p1.1':['grid'],
'A3.Thmtheorem7.p1.1':['c7_expansion'],'A3.Ex133':['c7_expansion'],
'A3.Thmtheorem7.p1.2':['c7_absolute','c7_uniform'],
'A3.SS3.p2.1':['r_interval','c7_complex_geometric'],
'A3.Ex134':['c7_complex_geometric','gap_complex_denominators'],
'A3.Ex135':['c7_rational','gap_complex_denominators'],
'A3.SS3.p2.2':['c7_normalization'],'A3.Ex136':['c7_normalization'],
'A3.SS3.p2.3':['c7_expansion','c7_majorant'],'A3.Ex137':['c7_majorant'],
'A3.SS3.p2.4':['c7_absolute','c7_uniform'],
'A3.Thmtheorem8.p1.1':['standing','producer_root'],'A3.Ex138':['producer_root','m_exact','mu_exact'],
'A3.SS3.p3.1':['alias_all_int'],'A3.Ex139':['alias_all_int'],
'A3.SS3.p3.2':['alias_nonmultiple','alias_multiple','gap_alias_sine_denominator'],
'A3.SS3.p4.1':['actual_gaussian_to_grid'],'A3.Ex140':['actual_gaussian_to_grid'],
'A3.SS3.p4.2':['expanded_grid_sums','gap_finite_series_exchange'],
'A3.SS3.p5.1':['m_positive_alias_support','gap_m_reindex'],
'A3.Ex141':['m_tail_series'],'A3.Ex142':['m_tail_summed','tail_geometric_guards'],'A3.Ex143':['m_exact'],
'A3.SS3.p6.1':['weighted_constant_zero','weighted_product_to_sum'],
'A3.Ex144':['weighted_series'],
'A3.SS3.p6.2':['weighted_class_center','weighted_class_plus','weighted_class_minus','weighted_disjoint_parity','gap_weighted_reindex'],
'A3.Ex145':['weighted_three_class_series'],
'A3.Ex146':['weighted_tails_summed','gap_shifted_geometric_indices'],
'A3.Ex147':['mu_exact'],
'A3.SS3.p7.1':['producer_root'],
'A3.SS3.p8.2':['m_positive_upper'],
'A3.SS3.p9.1':['mu_signed_positive','gap_absolute_sign','gap_ratio_normalization'],
'A3.Ex150':['ratio_exact']}
excluded={
'S4.SS1.p1.1.cite.L1086':'Historical construction provenance [22, §9.2], bibliographic bib.bib3 identifies OpenAI 2026 Subpolynomial query complexity. No external theorem or proof premise used in C.3 resummation.',
'S4.Thmtheorem5':'Bundled full-Lemma container: exact mean statement is covered at p1.1/Ex16; variance and conditional exponential bounds are outside selected sealed roots.',
'S4.EGx1':'Aligned equation-group structural container; its actual TBODY display S4.Ex16 is separately NODE-covered.',
'S4.Thmtheorem5.p1.2':'Variance assertions outside selected roots. The M upper bound is separately covered at p8.2 and must not inherit this variance branch.',
'S4.Thmtheorem5.p2.1':'Additional d-n>=sqrt(kappa) hypothesis belongs only to excluded exponential lower-bias branch.',
'S4.Ex17':'Exponential bias assertion outside selected exact-means/ratio roots.',
'A3.Thmtheorem7':'Named Fact C.7 container; complete statement and convergence claims are separately covered at p1.1/Ex133/p1.2.',
'A3.EGx14':'Aligned equation-group structural container; actual TBODY Ex134 and Ex135 separately covered.',
'A3.Thmtheorem8':'Named Fact C.8 container; complete condition/pair separately covered at p1.1 and Ex138.',
'A3.EGx15':'Aligned equation-group structural container; TBODY Ex141-143 separately covered.',
'A3.EGx16':'Aligned equation-group structural container; TBODY Ex145-147 separately covered.',
'A3.SS3.p6.3':'End-proof glyph only.',
'A3.SS3.p8.1':'Excluded variance branch: coordinate independence, Gaussian fourth moment, square-coordinate variance, and lambda lower bound used for variances. None needed as new ingredients for p8.2 M bound; Gaussian-to-grid reused internally.',
'A3.EGx17':'Excluded variance equation-group; individual Ex148/Ex149 also explicitly excluded.',
'A3.Ex148':'Variance of norm-square outside selected producer/consumer.',
'A3.Ex149':'Variance of cosine quadratic form outside selected producer/consumer.',
'A3.SS3.p9.2':'Downstream bounds on the exact ratio factor after Ex150; not needed for exact identity.',
'A3.Ex151':'Downstream ratio-factor inequalities outside selected exact ratio.',
'A3.SS3.p10.1':'Logarithmic power-bound route outside selected exact ratio.',
'A3.EGx18':'Excluded logarithmic equation-group; actual TBODY Ex152-154 also individually excluded.',
'A3.Ex152':'Log(1/r) algebra outside selected roots.',
'A3.Ex153':'Integral representation of log(1/r) outside selected roots.',
'A3.Ex154':'Integral split for log(1/r) outside selected roots.',
'A3.SS3.p10.2':'Logarithmic lower/upper estimates outside selected roots.',
'A3.EGx19':'Excluded logarithmic equation-group; TBODY Ex155/156 individually excluded.',
'A3.Ex155':'Integral upper estimate for log(1/r) outside selected roots.',
'A3.Ex156':'Constants in logarithmic upper estimate outside selected roots.',
'A3.SS3.p10.3':'Exponentiating logarithmic estimates outside selected roots.',
'A3.Ex157':'Exponential bounds on r^n outside selected roots.',
'A3.SS3.p11.1':'Conditional d-n>=sqrt(kappa) exponential correction estimate outside selected roots.',
'A3.Ex158':'Exponential correction estimate outside selected roots.',
'A3.SS3.p11.2':'Combine ratio-factor and exponential estimates for whole-Lemma bias result, outside selected roots.',
'A3.Ex159':'Full exponential normalized-bias bounds outside selected roots.',
'A3.SS3.p11.3':'End-proof glyph only.'}
assert set(mapping).isdisjoint(excluded)
assert set(mapping)|set(excluded)=={x['id'] for x in inv}, (set(mapping)|set(excluded))^{x['id'] for x in inv}
coverage=[]
for x in inv:
    y=dict(x)
    if x['id'] in mapping: y.update(disposition='NODE',graph_node_ids=mapping[x['id']])
    else: y.update(disposition='EXCLUDED',reason=excluded[x['id']])
    coverage.append(y)
definitions=[
dict(source='S4.E11',definition='theta_i',nodes=['grid']),
dict(source='S4.E11',definition='lambda_i',nodes=['grid']),
dict(source='S4.E11',definition='Lambda diagonal precision',nodes=['grid']),
dict(source='S4.Thmtheorem5.p1.1',definition='actual Gaussian U covariance Lambda^-1',nodes=['actual_objects']),
dict(source='S4.Thmtheorem5.p1.1',definition='D_n',nodes=['actual_objects']),
dict(source='S4.Thmtheorem5.p1.1',definition='M actual expectation',nodes=['actual_objects']),
dict(source='S4.Thmtheorem5.p1.1',definition='mu_n actual expectation',nodes=['actual_objects']),
dict(source='S4.Thmtheorem5.p1.1',definition='r',nodes=['r_def'])]
save('source-coverage-v1.json',dict(schema_version=1,state='PENDING_DISTINCT_RAW_SOURCE_REVIEW',inventory_sha256=digest(OUT/'phase1/raw-inventory.json'),items=coverage,definition_subitems=definitions,external_citations=[dict(source='S4.SS1.p1.1.cite.L1086',disposition='EXCLUDED',reason=excluded['S4.SS1.p1.1.cite.L1086'])],internal_citation_uses=[dict(source='A3.SS3.p4.2',cites='A3.Thmtheorem7',edge='e-grid-series-absolute-route'),dict(source='A3.SS3.p7.1',cites='A3.Thmtheorem8',edge='e-producer-root')],counts=dict(total=len(coverage),NODE=len(mapping),EXCLUDED=len(excluded)),reviewer_must_recheck='every raw paragraph/display/inline definition/citation; aligned TBODY IDs; false ANDs; all-Int aliases; sign, positivity and ratio normalization'))

# Exact seal projection: signatures only, no candidate proof/API interpretation.
projection=dict(schema_version=1,state='PROPOSED_FOR_DISTINCT_REVIEW_NO_SELF_APPROVAL',inputs_sha256=inputs,statement_seal_id=seal['seal_id'],signature_texts={f:(BASE/f).read_text() for f in ['producer-signature.txt','consumer-signature.txt']},standard_definition_text=(BASE/'multivariateGaussian-standard-definition.txt').read_text(),bindings=[
dict(source='d>=2, kappa>=2, integer 1<=n<d',sealed='hd,hκ,hn,hnd',classification='STANDING/SOURCE; Nat is positive-integer representation',nodes=['standing']),
dict(source='i=1,...,d; theta=(i-1/2)pi/d',sealed='Fin d; i.val+1/2',classification='literal reindex i_source=i.val+1',nodes=['grid']),
dict(source='Lambda precision; U~N(0,Lambda^-1)',sealed='multivariateGaussian 0 Λ⁻¹',classification='literal covariance argument; standard definition maps standard Gaussian by covariance square root',nodes=['actual_objects']),
dict(source='D_n quadratic form',sealed='Q x = sum_i cos(n theta_i)*(WithLp.ofLp x i)^2',classification='literal diagonal quadratic form',nodes=['actual_objects']),
dict(source='M,mu_n are actual expectations',sealed='actual Bochner integrals; integrability in producer conclusion',classification='no formula-defining M/mu; no free values or callbacks',nodes=['actual_gaussian_to_grid','producer_root']),
dict(source='r=(sqrt(kappa)-1)/(sqrt(kappa)+1)',sealed='literal let r',classification='literal; interval internal',nodes=['r_def','r_interval']),
dict(source='integer differences 2d-n and d-n',sealed='Nat exponents 2*d-n and d-n',classification='literal only after hn,hnd internally discharge truncation arithmetic',nodes=['scalar_guards','gap_shifted_geometric_indices','gap_ratio_normalization'])],producer_outputs=[dict(conjunct='norm-square integrability',source='implicit in actual moments p4.1/Ex140',node='actual_gaussian_to_grid',input_status='existing canonical reuse, internal edge'),dict(conjunct='Q integrability',source='implicit in actual moments p4.1/Ex140',node='actual_gaussian_to_grid',input_status='existing canonical reuse, internal edge'),dict(conjunct='M exact equality',source='Ex138/Ex141-143',node='m_exact'),dict(conjunct='signed mu exact equality',source='Ex138/Ex144-147',node='mu_exact')],consumer_outputs=[dict(conjunct='0<m',source='normalization guard implicit in p9.1/Ex150',node='m_positive_upper'),dict(conjunct='m<=d/sqrt(kappa)',source='p8.2',node='m_positive_upper'),dict(conjunct='0<(-1)^n*b',source='p9.1',node='mu_signed_positive'),dict(conjunct='exact |b|/m ratio',source='Ex150',node='ratio_exact')],minimal_packet_scope=dict(producer_pair_justified=True,reason='Exact ratio needs both means; consumer additionally demonstrates separate M upper-bound and signed-mu positivity branches.',m_bound_requires_only='m_exact plus r/d/kappa positivity guards',signed_mu_positivity_requires_only='mu_exact plus exponent and positivity guards',ratio_requires_both=True,full_Lemma4_5_required=False),excess_binders_observed=[],definition_caveats=['General standard multivariateGaussian constructor alone does not certify covariance without suitable PSD facts. Here its argument is literal Lambda^-1 and actual Gaussian-to-grid is an existing canonical substrate; no new law callback or PSD premise is added.','No new implementation or proof was read, so actual public dependency names/compiled guards remain unaudited.'],read_only_text_projection=True,no_proof_credit=True)
save('seal-projection-v1.json',projection)

# Separate backward root closures; alternate exchange route is not forced.
byid={n['id']:n for n in nodes}
assert len(byid)==len(nodes)
incoming={}
for e in edges:
    assert e['to_node'] in byid
    assert all(x in byid for x in e['from_nodes'])
    incoming.setdefault(e['to_node'],[]).append(e)
def closure(root):
    ns=set(); es=set(); active=set()
    def visit(x):
        assert x not in active, f'cycle {x}'
        if x in ns:return
        active.add(x)
        for e in incoming.get(x,[]):
            es.add(e['id'])
            for z in e['from_nodes']:visit(z)
        active.remove(x);ns.add(x)
    visit(root)
    return dict(root=root,node_ids=sorted(ns),edge_ids=sorted(es),leaf_nodes=sorted(n for n in ns if n not in incoming),source_gap_nodes=sorted(n for n in ns if byid[n]['kind']=='SOURCE_GAP'),existing_canonical_reuse_nodes=sorted(n for n in ns if byid[n]['kind']=='existing_canonical_substrate_reuse'),public_input_nodes=['standing'],source_refs=sorted({r for n in ns for r in byid[n]['source_refs']}),unselected_alternatives=['uniform-exchange-unselected'],excluded_branches=['C3 p8.1/Ex148-149 variances/fourth moments','C3 p9.2/Ex151 factor bounds','C3 p10-11/Ex152-159 log/exponential bounds'],boundary='Source topology closure only; SOURCE_GAP and internal guard records identify proof obligations. No formal closure or approval is asserted.')
closures={x:closure(x) for x in ['producer_root','consumer_root']}
closures['consumer_subroot_dependency_checks']={x:closure(x) for x in ['m_positive_upper','mu_signed_positive','ratio_exact']}
assert 'mu_exact' not in closures['consumer_subroot_dependency_checks']['m_positive_upper']['node_ids']
assert 'm_exact' not in closures['consumer_subroot_dependency_checks']['mu_signed_positive']['node_ids']
assert all(x in closures['consumer_subroot_dependency_checks']['ratio_exact']['node_ids'] for x in ['m_exact','mu_exact'])
save('two-root-closures-v1.json',dict(schema_version=1,state='PENDING_DISTINCT_ROOT_CLOSURE_REVIEW',**closures))
save('structural-validation-v1.json',dict(status='PASS_STRUCTURAL_ONLY_NOT_MATHEMATICAL_APPROVAL',checks=['all 72 captured source units have exactly one NODE/EXCLUDED disposition','all mapped graph node IDs exist','all edge endpoints exist','two selected backward root closures are acyclic','M bound subroot has no mu exact branch','signed mu positivity subroot has no M exact branch','ratio subroot contains both exact means','equation-group containers and aligned TBODY displays separately covered','all public theorem inputs restricted to standing/source conditions'],counts=dict(nodes=len(nodes),edges=len(edges),coverage=len(coverage),source_gaps=sum(n['kind']=='SOURCE_GAP' for n in nodes))))
assert all(i in byid for ids in mapping.values() for i in ids)
print(json.dumps(dict(nodes=len(nodes),edges=len(edges),coverage=len(coverage),source_gaps=sum(n['kind']=='SOURCE_GAP' for n in nodes))))
