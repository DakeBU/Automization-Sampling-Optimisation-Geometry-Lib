from pathlib import Path
import json,hashlib,shutil
r=Path(__file__).resolve().parent;repo=r.parents[2];old=repo/".astis/semantic-neutral-20261110/module_74e2d8"
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
freezeHash=sha(old/"freeze.json");assert freezeHash=="26a5b00f08bddbf3e13c62e495e0ab268eaad341ef6204a2fce1a291a278eb2f"
freeze=json.loads((old/"freeze.json").read_text());assets={x["path"]:x for x in freeze["artifacts"]}
def check(s):
 assert sha(old/s)==assets[s]["sha256"],s
 return assets[s]["sha256"]
check("exact-input-check.json");bindings={x["path"]:x for x in json.loads((old/"exact-input-check.json").read_text())}
for p in ["lean-toolchain","lake-manifest.json","lakefile.lean"]:assert sha(repo/p)==bindings[p]["sha256"],p
assert sha(old/"toolchain.stdout.log")==sha(r/"toolchain.stdout.log")
rows=[]
mods=[("AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumGaussianMoments.lean","isolated-final-1-FixedSpectrumGaussianMoments"),("AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumCosineExpansion.lean","isolated-final-2-FixedSpectrumCosineExpansion"),("AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumGridAlias.lean","isolated-final-3-FixedSpectrumGridAlias"),("AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumExactMeans.lean","isolated-final-4-FixedSpectrumExactMeans"),("AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumBias.lean","isolated-final-6-FixedSpectrumBias")]
(r/"reused-native-evidence").mkdir(exist_ok=True)
for src,label in mods:
 assert sha(repo/src)==bindings[src]["sha256"],src
 rel="oleans/"+str(Path(src).with_suffix(".olean"));objhash=check(rel)
 receiptHash=check(label+".receipt.json");receipt=json.loads((old/(label+".receipt.json")).read_text());assert receipt["exit_code"]==0
 for suffix in [".receipt.json",".stdout.log",".stderr.log"]:
  check(label+suffix);shutil.copyfile(old/(label+suffix),r/"reused-native-evidence"/(label+suffix))
 dest=r/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(old/rel,dest);assert sha(dest)==objhash
 rows.append({"source":src,"current_source_sha256":sha(repo/src),"reused_olean_sha256":objhash,"previous_exact_candidate":"300fb6f3e680f5a4585fee2bcf57d1005d57f1fa","evidence_freeze_sha256":freezeHash,"receipt_sha256":receiptHash,"stdout_sha256":receipt["stdout_sha256"],"stderr_sha256":receipt["stderr_sha256"],"historical_command":receipt["argv"],"historical_exit_code":0,"fresh_run_claim":False})
report={"method":"Reuse of five unchanged canonical objects from own earlier immutable native evidence, with current source/toolchain/manifest and object/receipt hashes checked","previous_evidence_freeze_sha256":freezeHash,"current_toolchain_sha256":sha(repo/"lean-toolchain"),"current_manifest_sha256":sha(repo/"lake-manifest.json"),"current_native_version_output_sha256":sha(r/"toolchain.stdout.log"),"objects":rows}
(r/"canonical-reuse.json").write_text(json.dumps(report,indent=2)+"\n");print(json.dumps(report,indent=2))
