"""Archive exact Git closure and independently verify read-only upstream input bytes."""
from concurrent.futures import ThreadPoolExecutor
import json
import re
from native_common import *

P = 'AutoSamplingTheory.TechnicalLemmas.Probability.MatrixLaplaceTail'
T = 'Tests.GaussianComplexityLaplaceTail'

def main():
    assert not (OWN / 'actual-import-closure.json').exists()
    assert git('candidate-rev', 'rev-parse', COMMIT).decode().strip() == COMMIT
    head = git('observed-head', 'rev-parse', 'HEAD').decode().strip()
    tree_sha = git('candidate-tree', 'rev-parse', COMMIT + '^{tree}').decode().strip()
    tree = {}
    for entry in git('candidate-ls-tree', 'ls-tree', '-r', '-z', COMMIT).split(b'\0'):
        if entry:
            meta, path = entry.split(b'\t', 1)
            mode, kind, oid = meta.decode().split()
            tree[path.decode()] = (mode, kind, oid)
    project = {p[:-5].replace('/', '.'): p for p in tree if p.endswith('.lean') and (p.startswith(('AutoSamplingTheory/', 'Tests/')) or p in ['AutoSamplingTheory.lean', 'Tests.lean'])}
    sources, imports, order, active = {}, {}, [], set()
    def visit(module):
        if module in order: return
        assert module not in active, 'project import cycle'
        active.add(module)
        path = project[module]
        data = git('source-' + str(len(sources)), 'cat-file', 'blob', tree[path][2])
        sources[module] = data
        declared = []
        for line in data.decode().splitlines():
            if match := re.match(r'^\s*(?:public\s+|private\s+|meta\s+)?import\s+([^\n]+)', line):
                declared.extend(match.group(1).split('--', 1)[0].split())
        imports[module] = declared
        for dep in declared:
            if dep in project: visit(dep)
            elif dep.startswith(('AutoSamplingTheory', 'Tests')): raise ValueError('Missing ASTIS source ' + dep)
        active.remove(module)
        order.append(module)
    visit(P); visit(T)
    CAND.mkdir(exist_ok=True)
    rows = []
    for module in order:
        path = project[module]
        dest = CAND / path
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(sources[module])
        rows.append({'module': module, 'path': path, 'git_oid': tree[path][2], 'sha256': sha(sources[module]), 'bytes': len(sources[module]), 'imports': imports[module], 'actual_ASTIS_imports': [d for d in imports[module] if d in project]})
    expected = {P:'4924fede99548f6aab4f63605d2beed9dc435d6338a61d89ee301d9e83733749', T:'9ecf723f0487ddf50cb1d7c3102ebc04b58c472e56d2b16b186d91bc91cc6aac'}
    assert all(sha(sources[m]) == h for m,h in expected.items())
    for path in ['lean-toolchain', 'lake-manifest.json', 'lakefile.lean', 'tools/astis.py', 'AGENTS.md', 'CONTRIBUTING.md', 'docs/contributor-codex-contract.md', 'docs/proof-digestion-protocol.md', 'docs/theorem-publication-protocol.md', 'docs/evidence-routed-memory-protocol.md']:
        if path in tree:
            dest = CAND / path
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(git('input-' + path.replace('/', '-').replace('.', '-'), 'cat-file', 'blob', tree[path][2]))
    assert (CAND / 'lean-toolchain').read_text().strip() == 'leanprover/lean4:v4.33.0'
    write_json(OWN / 'actual-import-closure.json', {'candidate_commit': COMMIT, 'candidate_tree': tree_sha, 'observed_HEAD_only': head, 'P':P, 'T':T, 'topological_order': order, 'modules':rows, 'ASTIS_olean_copied':False, 'actual_ASTIS_source_closure_count':len(order)})
    originals = OWN / 'immutable-inputs'
    originals.mkdir(exist_ok=True)
    seal_root = REPO / '.astis/huanjian-gc-matrix-laplace-20261114'
    for name in ['statement-seal.sealed.v1.json', 'P.proposition.sealed.v1.txt', 'T.proposition.sealed.v1.txt', 'binder-definition-audit.sealed.v1.json']:
        (originals / name).write_bytes((seal_root / name).read_bytes())
    seal = json.loads((originals / 'statement-seal.sealed.v1.json').read_text())
    for role in ['P','T']:
        assert file_sha(originals / seal[role]['proposition_file']) == seal[role]['sha256']
    assert file_sha(originals / seal['binder_definition_audit']['file']) == seal['binder_definition_audit']['sha256']
    package_seal = REPO / '.astis/semantic-neutral-20261114/bernstein_exp_native_72c4/package-artifact-digests.json'
    frozen = {p['package']:p for p in json.loads(package_seal.read_text())['packages']}
    manifest = json.loads((CAND / 'lake-manifest.json').read_text())
    package_results = []
    for package in manifest['packages']:
        name = package['name']
        src = REPO / '.lake/packages' / name
        revision = git('upstream-revision-' + name, '-C', str(src), 'rev-parse', 'HEAD').decode().strip()
        status = git('upstream-clean-' + name, '-C', str(src), '-c', 'core.fsmonitor=false', 'status', '--porcelain', '--untracked-files=no')
        assert revision == package['rev'] and not status
        root = package_seal.parent / 'clean-packages' / name / '.lake/build/lib/lean'
        files = frozen[name]['files']
        assert {str(p.relative_to(root)) for p in root.rglob('*') if p.is_file()} == {r['path'] for r in files}
        def check(row):
            p = root / row['path']
            before = p.stat()
            digest = file_sha(p)
            after = p.stat()
            assert before.st_size == after.st_size == row['bytes'] and before.st_mtime_ns == after.st_mtime_ns
            assert digest == row['sha256'], (name,row['path'])
            return row['bytes']
        with ThreadPoolExecutor(max_workers=8) as pool:
            byte_count = sum(pool.map(check, files))
        package_results.append({'name':name, 'revision':revision, 'tracked_source_clean':True, 'effective_lean_path':str(root), 'exact_membership_and_bytes_rehashed':True, 'files':len(files), 'bytes':byte_count, 'read_only_reuse':True})
        print(json.dumps({'upstream_rehashed':name, 'files':len(files), 'bytes':byte_count}), flush=True)
    write_json(OWN / 'verified-package-inputs.json', {'candidate_commit':COMMIT, 'packages':package_results, 'reference_artifact_seal':str(package_seal), 'reference_seal_sha256':file_sha(package_seal), 'ASTIS_output_reused':False, 'package_bytes_copied':0})
    print(json.dumps({'prepared_actual_ASTIS_closure':len(order), 'package_count':len(package_results)}), flush=True)

if __name__ == '__main__': main()
