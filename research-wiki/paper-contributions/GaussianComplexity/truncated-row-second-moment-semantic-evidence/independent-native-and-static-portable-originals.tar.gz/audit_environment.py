from pathlib import Path
import hashlib,json,subprocess,datetime,platform,os
R=Path.cwd(); O=R/'.astis/semantic-neutral-20261111/rc_native_68bc'; C='86c9bb627c61955f2a47f492c59a044230536739'
def run(args):
 p=subprocess.run(args,cwd=R,capture_output=True); return {'command':args,'exit_code':p.returncode,'stdout':p.stdout.decode(),'stderr':p.stderr.decode()}
def sha(b): return hashlib.sha256(b).hexdigest()
def exact(path): return subprocess.check_output(['git','show',C+':'+path],cwd=R)
binary=Path('/Users/zhouhuanjian/.elan/toolchains/leanprover--lean4---v4.33.0/bin/lean')
tool=exact('lean-toolchain'); mf=exact('lake-manifest.json'); manifest=json.loads(mf)
data={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'candidate':C,'head':run(['git','rev-parse','HEAD']),'platform':platform.platform(),'binary':str(binary),'binary_sha256':sha(binary.read_bytes()),'file':run(['file',str(binary)]),'lean_version':run([str(binary),'--version']),'toolchain_exact_git_sha256':sha(tool),'manifest_exact_git_sha256':sha(mf),'toolchain_worktree_equal':tool==(R/'lean-toolchain').read_bytes(),'manifest_worktree_equal':mf==(R/'lake-manifest.json').read_bytes(),'packages':[]}
(O/'inputs').mkdir(); (O/'native-src').mkdir(); (O/'native-lib').mkdir()
for name,b in [('lean-toolchain.exact',tool),('lake-manifest.exact.json',mf)]: (O/'inputs'/name).write_bytes(b)
for pkg in manifest['packages']:
 p=R/'.lake/packages'/pkg['name']; h=run(['git','-C',str(p),'rev-parse','HEAD']); status=run(['git','-C',str(p),'status','--porcelain=v1','--untracked-files=all','--ignore-submodules=none']); raw=json.dumps({'head':h,'status':status},indent=2)+'\n'; fn='package-'+pkg['name']+'.json'; (O/'inputs'/fn).write_text(raw)
 data['packages'].append({'name':pkg['name'],'expected_revision':pkg['rev'],'actual_revision':h['stdout'].strip(),'head_matches':h['exit_code']==0 and h['stdout'].strip()==pkg['rev'],'complete_porcelain_empty':status['exit_code']==0 and status['stdout']=='','raw_evidence':str((O/'inputs'/fn).relative_to(R)),'raw_sha256':sha(raw.encode()),'lib':str(p/'.lake/build/lib/lean')})
paths=['AutoSamplingTheory/TechnicalLemmas/Probability/StdGaussianMoment.lean','AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumTruncatedRowMoment.lean','Tests/GaussianComplexityFixedSpectrumTruncatedRowMoment.lean']
data['modules']=[]
for path in paths:
 b=exact(path); out=O/'native-src'/path;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(b); data['modules'].append({'path':path,'sha256':sha(b),'bytes':len(b),'LF_lines':len(b.splitlines()),'worktree_equal':b==(R/path).read_bytes()})
seal='research-wiki/paper-contributions/GaussianComplexity/truncated-row-second-moment-statement-seal-v2.json';b=exact(seal);(O/'inputs'/'statement-seal-v2.exact.json').write_bytes(b);data['seal_sha256']=sha(b)
raw=R/'.astis/huanjian-resume-20261103/2610.20492v1.html';data['source_html']={'path':str(raw.relative_to(R)),'sha256':sha(raw.read_bytes()),'bytes':raw.stat().st_size,'class':'private raw source snapshot; reference only; not copied'}
assert data['binary_sha256']=='1b370cfcbf44e80d1b004ab1b1ab9a4c73951f9f7c242140bcff9bc577576554'
assert data['manifest_exact_git_sha256']=='b83ca83b9cf7caa85fa8b023c2ff9a3fb7a7cce7e1c332e810c348535ec49c37'
assert all(p['head_matches'] and p['complete_porcelain_empty'] for p in data['packages'])
assert data['modules'][1]['sha256']=='1a97dd98ecc4e3965db20a91c1d22ca8520406ea22cbbfbd631579522d071310'
assert data['modules'][2]['sha256']=='0125f27884195dc6210ade46987373d0b4674ba067067a03d91dcd0d2828276e'
assert data['source_html']['sha256']=='6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
(O/'environment.json').write_text(json.dumps(data,indent=2)+'\n');print(json.dumps(data,indent=2))
