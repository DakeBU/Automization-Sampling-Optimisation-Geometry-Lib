"""Collect completed same-core evidence into a disabled browser context; no browser/API."""
from pathlib import Path
import hashlib
import json
import subprocess

P = Path('.astis/huanjian-gc-fixed-spectrum-cosine-expansion-integration-20261109')
S = P / 'independent-reader/browser-preparation-v2'
sha = lambda b: hashlib.sha256(b).hexdigest()
ref = lambda p: {'path': str(p), 'sha256': sha(Path(p).read_bytes())}
core = subprocess.check_output(['git', 'rev-parse', 'HEAD']).decode().strip()
assert core == '7ad39273de26a0ed0315db46be231b5585e26409'
assert not subprocess.check_output(['git', 'status', '--porcelain=v1', '--untracked-files=no']).strip()
freeze = (S / 'freeze-manifest.json').read_bytes()
assert sha(freeze) == 'f52f5cd6497ebff97fa6c46d4ee08eb607af8711eb02634e7c1f137fcb2ff08d'
for row in json.loads(freeze)['files']:
    p = Path(row['path'])
    if not p.is_absolute():
        p = S / p
    assert sha(p.read_bytes()) == row['sha256']
a = json.loads((S / 'root-browser-context.DISABLED.template.json').read_bytes())
assert a['authorized_by'] is None and a['execute_browser_authorized'] is False
a['accepted_immutable_core'] = core
base = Path('.astis/huanjian-resume-20261103')
checks = {}
for role, label in {
    'canonical_lean': 'canonical-lean', 'publication': 'publication',
    'contributor': 'contributor', 'semantic': 'semantic', 'frontier': 'frontier',
    'site_build': 'site-build', 'site_check': 'site-check', 'graph_check': 'graph-check'
}.items():
    paths = list(base.glob('*cosine-expansion-core2-' + label + '.receipt.json'))
    assert len(paths) == 1, (role, paths)
    p = paths[0]
    r = json.loads(p.read_bytes())
    assert r['exit_code'] == 0 and r['head_before'] == r['head_after'] == core
    assert sha(Path(r['log']).read_bytes()) == r['log_sha256']
    checks[role] = ref(p)
a['actual_checks_before_browser'] = checks
p = next(base.glob('*cosine-expansion-core2-merged-main-focused-tests.receipt.json'))
r = json.loads(p.read_bytes())
assert r['exit_code'] == 0 and r['head_before'] == r['head_after'] == core
a['actual_subject_reader_focused_tests'] = ref(p)
a['actual_gate'] = ref('.astis/site-lean-gate.json')
a['site_metadata'] = ref('_site/data/build-metadata.json')
gate = json.loads(Path(a['actual_gate']['path']).read_bytes())
meta = json.loads(Path(a['site_metadata']['path']).read_bytes())
assert gate['passed'] and meta['gate']['passed'] and meta['gate']['current']
assert gate['commit'] == meta['git']['commit'] == core
assert gate['source_digest'] == meta['source_digest']
a['source_digest'] = gate['source_digest']
pins = json.loads((S / 'expected-immutable-input-pins.json').read_bytes())['pins']
for name, expected in pins.items():
    raw = Path(name).read_bytes()
    assert sha(raw) == expected and subprocess.check_output(['git', 'show', core + ':' + name]) == raw
a['actual_immutable_input_pins'] = pins
name = 'AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumCosineExpansion.actual_inverse_spectrum_cosine_expansion'
item = 'huanjian-fixed-spectrum-cosine-expansion'
rows = {r['declaration']: r for r in json.loads(Path('_site/data/declaration-exposition.json').read_bytes())}
data = json.loads(Path('_site/data/site-data.json').read_bytes())
pages = [
    'lean-foundations.html', 'example-cases/samplewiki/companions/gaussian-sampling-complexity.html',
    'proofs/source-' + item + '.html', rows[name]['page'], 'sampling/index.html',
    'libraries/optimisation/index.html', 'lower-bounds/index.html', 'libraries/discrete-sampling/index.html',
    'example-cases/samplewiki/companions/slc-lsi-query-complexity.html'
]
modules = ['AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumCosineExpansion',
           'Tests.GaussianComplexityFixedSpectrumCosineExpansion']
pages += [r['page'] for r in data['modules'] if r['name'] in modules]
pages += [r['card'] for r in data['registry_declarations'] if r['local_decl'] == 'AutoSamplingTheory.TechnicalLemmas.InformationTheory.DensityAffinity.normalized_density_tv_affinity']
site = ['_site/' + p for p in pages] + [
    '_site/data/build-metadata.json', '_site/data/declaration-exposition.json', '_site/data/site-data.json',
    '_site/data/underlying-lean-graph.json', '_site/assets/information-architecture.css',
    '_site/assets/underlying-lean-graph.js', '_site/assets/subject-readers.css'
]
a['actual_site_input_pins'] = {p: sha(Path(p).read_bytes()) for p in sorted(set(site))}
public = Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-cosine-expansion-integration-20261109')
for key, value in list(a.items()):
    if isinstance(value, dict) and set(value) == {'path', 'sha256'}:
        path = Path(value['path'])
        if path.is_relative_to(P / 'independent-reader'):
            copy = public / path.relative_to(P)
            if copy.is_file():
                assert copy.read_bytes() == path.read_bytes()
                assert subprocess.check_output(['git', 'show', core + ':' + str(copy)]) == copy.read_bytes()
                a[key] = ref(copy)
for v in a.values():
    if isinstance(v, dict) and set(v) == {'path', 'sha256'}:
        assert sha(Path(v['path']).read_bytes()) == v['sha256']
a['no_future_facts_filled'] = False
a['review_state'] = 'ACTUAL_CORE_AND_COMPLETED_GATES_BOUND_STILL_DISABLED_PENDING_ROOT_REVIEW_AND_SCOPED_OS_APPROVAL'
out = P / 'actual-browser-context-v2.DISABLED.json'
with out.open('x') as f:
    f.write(json.dumps(a, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'context': str(out), 'sha256': sha(out.read_bytes()), 'actual_core': core,
                  'official_checks': len(checks), 'site_pins': len(a['actual_site_input_pins']),
                  'execute_browser_authorized': False, 'new_source_verdict': False}))
