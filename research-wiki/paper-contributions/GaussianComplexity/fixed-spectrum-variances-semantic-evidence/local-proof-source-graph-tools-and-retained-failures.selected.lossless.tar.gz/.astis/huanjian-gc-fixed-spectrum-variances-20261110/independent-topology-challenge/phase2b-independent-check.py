"""Bounded source/JSON identity and graph traversal; no Lean, API or proof search."""
from pathlib import Path
from collections import Counter, defaultdict
import hashlib
import json
import re
import runpy

BASE = Path('.astis/huanjian-gc-fixed-spectrum-variances-20261110')
OWN = BASE / 'independent-topology-challenge'
INPUT = BASE / 'independent-source-graph/v2-scope-correction'
PINS = {
    'source-proof-graph-v2.json': '924e4c7073589434c4463c1e1fd29884ec0318b9cb9c75dd932fd74cbba44bf3',
    'exact-target-coverage-v2.json': '93f4a7cc11863bfaccc6a43a1d3462f346c12ed8338adeb21de66eace5c0554f',
    'root-closures-v2.json': '4b1f0272827f9b61ae2b00078be328a9a888d9109522854c762ade62bc526a6e',
    'machine-inputs-v2.json': 'dbaf95e4a4c9424a1eeae6cc753bf63552e9ff6a7696e114679c08ebf65d78a7',
    'freeze-v2.json': '55e4e0f6c59f6c615efca5f911e278ecf6bc99342fb0c9b9b30d2ebdd9740bf2',
    'binding-lineage-v2.json': '7cfc0cde1ba40ba3bfefab764bfb6ced8b6b2f5ed398bb6cf09636f00c32b324',
}


def pin(p):
    data = p.read_bytes()
    return {'path': str(p), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


inputs = []
for name, expected in PINS.items():
    info = pin(INPUT / name)
    assert info['sha256'] == expected, name
    inputs.append(info)
graph = json.loads((INPUT / 'source-proof-graph-v2.json').read_bytes())
coverage = json.loads((INPUT / 'exact-target-coverage-v2.json').read_bytes())
recorded = json.loads((INPUT / 'root-closures-v2.json').read_bytes())
projection = pin(BASE / 'strict-preproof-seal-projection-v2.json')
assert projection['sha256'] == '76136b7367d19fd1b98583adc5f4fae17330a817ad2c1a330300e399b0925b85'
inputs.append(projection)
reader = runpy.run_path(str(OWN / 'source_only_reader.py'))
ids, walk, record = reader['READER'].ids, reader['walk'], reader['record']
source_lines = reader['TEXT'].splitlines(keepends=True)
inputs.append(pin(reader['SOURCE']))


def norm(s):
    return re.sub(r'\s+', ' ', s).strip()


def compact(s):
    return re.sub(r'\s+', '', s)


def unit_kind(n):
    classes = n.attrs.get('class', '').split()
    if n.tag == 'section':
        return 'section-context'
    if re.fullmatch('h[1-6]', n.tag):
        return 'heading'
    if n.tag == 'div':
        for c, kind in [('ltx_para', 'paragraph-container'), ('ltx_theorem', 'theorem-block'), ('ltx_proof', 'proof-block')]:
            if c in classes:
                return kind
    if n.tag == 'p' and 'ltx_p' in classes:
        return 'paragraph'
    if n.tag == 'table' and any(c in classes for c in ['ltx_equation', 'ltx_equationgroup']):
        return 'display'
    if n.tag == 'tbody':
        return 'tbody'
    if n.tag == 'cite':
        return 'external-citation'
    if n.tag == 'a' and n.attrs.get('href', '').startswith('#'):
        return 'internal-reference'
    if n.tag == 'li' and n.attrs.get('id', '').startswith('bib.'):
        return 'bibliography-entry'


def unit_id(n):
    if n.attrs.get('id'):
        return n.attrs['id']
    ancestor = n.parent
    while ancestor and not ancestor.attrs.get('id'):
        ancestor = ancestor.parent
    return ancestor.attrs['id'] + '::' + n.tag + '@' + str(record(n)['line_start'])


def actual_math(n):
    return [{'id': q.attrs.get('id'), 'line': record(q)['line_start'], 'tex': q.attrs.get('alttext', ''),
             'display': q.attrs.get('display', '')} for q in walk(n) if q.tag == 'math']


def actual_refs(n):
    return [{'line': record(q)['line_start'], 'href': q.attrs['href'], 'title': q.attrs.get('title', ''),
             'text': norm(reader['normalized'](q))} for q in walk(n)
            if q.tag == 'a' and q.attrs.get('href', '').startswith('#')]


expected = []
for key in ['S4', 'bib.bib3', 'A3.SS3']:
    for n in walk(ids[key]):
        kind = unit_kind(n)
        if not kind or (key == 'S4' and record(n)['line_start'] > 1500):
            continue
        expected.append((unit_id(n), kind, record(n)['line_start'], n))
rows = coverage['rows']
assert len(rows) == len(expected) == 294
assert [r['raw_unit_ordinal'] for r in rows] == list(range(len(rows)))
expected_keys = [e[:3] for e in expected]
actual_keys = [(r['raw_source_unit']['id'], r['raw_source_unit']['kind'], r['raw_source_unit']['original_lines'][0]) for r in rows]
assert expected_keys == actual_keys  # also protects order within same-line link collisions
render_spacing = []
all_math = set()
for row, (_, _, _, n) in zip(rows, expected):
    unit = row['raw_source_unit']
    a, z = unit['original_lines']
    assert record(n)['line_end'] == unit['container_original_end']
    assert hashlib.sha256(''.join(source_lines[a - 1:z]).encode()).hexdigest() == unit['raw_html_sha256']
    successor = row['exact_target_successor']
    assert successor['disposition'] in ['NODE', 'EXCLUDED']
    if successor['disposition'] == 'EXCLUDED':
        assert successor['reason'] and successor['graph_nodes'] == []
    else:
        assert successor['graph_nodes'] and successor['reason'] is None
    if unit['text_with_tex'].startswith('[Structural container'):
        assert unit['math'] == [] and unit['references'] == []
        continue
    assert actual_math(n) == unit['math'], unit['id']
    assert actual_refs(n) == unit['references'], unit['id']
    actual_text = norm(reader['normalized'](n))
    assert compact(actual_text) == compact(unit['text_with_tex']), unit['id']
    if actual_text != unit['text_with_tex']:
        render_spacing.append(row['raw_unit_ordinal'])
    all_math.update(m['id'] for m in unit['math'])
scoped_math = {n.attrs['id'] for key in ['S4', 'bib.bib3', 'A3.SS3'] for n in walk(ids[key])
               if n.tag == 'math' and (key != 'S4' or record(n)['line_start'] <= 1500)}
assert scoped_math == all_math
own_inventory = json.loads((OWN / 'raw-source-inventory.json').read_bytes())
own_math = {m['id'] for u in own_inventory['items'] for m in u.get('math', [])}
assert own_math <= all_math
collisions = {key: [r['raw_unit_ordinal'] for r in rows if r['raw_source_unit']['id'] == key]
              for key, count in Counter(r['raw_source_unit']['id'] for r in rows).items() if count > 1}
assert collisions == {e['id']: e['ordinals'] for e in coverage['raw_unit_identity']['synthetic_id_collisions']}

nodes = {n['id']: n for n in graph['nodes']}
routes = {r['id']: r for r in graph['routes']}
assert len(nodes) == len(graph['nodes']) == 38
assert len(routes) == len(graph['routes']) == 31
incoming = defaultdict(list)
anchors_checked = 0
for n in graph['nodes']:
    for a in n['source_anchors']:
        raw_node = ids[a['id']]
        assert a['original_lines'] == [record(raw_node)['line_start'], record(raw_node)['line_end']]
        start, end = a['original_lines']
        assert hashlib.sha256(''.join(source_lines[start - 1:end]).encode()).hexdigest() == a['raw_html_sha256']
        assert a['math'] == actual_math(raw_node)
        assert a['references'] == actual_refs(raw_node)
        anchors_checked += 1
for r in graph['routes']:
    assert r['consumer'] in nodes and all(p in nodes for p in r['inputs'])
    assert r['logic'] == 'AND' and r['inputs'] and r['discharge']
    incoming[r['consumer']].append(r)
    for a in r['consumer_use_sites']:
        raw_node = ids[a['id']]
        assert a['original_lines'] == [record(raw_node)['line_start'], record(raw_node)['line_end']]
assert graph['alternative_routes'] == []
assert all(len(incoming[n]) == 1 for n, v in nodes.items() if v['kind'] == 'SOURCE_GAP')
assert {p for r in rows for p in r['exact_target_successor']['graph_nodes']} == set(nodes)


def closure(root):
    seen, edges, active = set(), set(), set()

    def visit(n):
        assert n not in active, ('cycle', n)
        if n in seen:
            return
        active.add(n)
        for route in incoming[n]:
            edges.add(route['id'])
            for parent in route['inputs']:
                visit(parent)
        active.remove(n)
        seen.add(n)

    visit(root)
    return {'root': root, 'nodes': sorted(seen), 'routes': sorted(edges),
            'node_source_anchors': sorted({a['id'] for n in seen for a in nodes[n]['source_anchors']}),
            'route_use_site_anchors': sorted({a['id'] for r in edges for a in routes[r]['consumer_use_sites']}),
            'leaves': sorted(n for n in seen if not incoming[n]),
            'SOURCE_GAP_internal_obligations': sorted(n for n in seen if nodes[n]['kind'] == 'SOURCE_GAP'),
            'opaque_source_backed_prerequisites': sorted(n for n in seen if nodes[n]['kind'] == 'opaque-source-backed-prerequisite')}


closures = {}
for owner, existing in recorded['closures'].items():
    computed = closure(existing['root'])
    for key in ['nodes', 'routes', 'SOURCE_GAP_internal_obligations', 'opaque_source_backed_prerequisites']:
        assert computed[key] == existing[key], (owner, key)
    closures[owner] = computed
for node in nodes:
    closure(node)  # detects any cycle, including context-only component
assert closures['producer']['leaves'] == ['D_actual_law', 'D_domain', 'D_grid', 'D_quadratics']
assert closures['actual_private_consumer']['leaves'] == ['C_contrast_definition', 'C_numeric_domain', 'D_actual_law', 'D_domain', 'D_grid', 'D_quadratics']
assert set(recorded['consumer_projection_required']) == set(routes['r_projection']['inputs'])
assert set(recorded['consumer_not_required']).isdisjoint(closures['actual_private_consumer']['nodes'])
subroot_names = ['N_norm_L2', 'N_Q_L2', 'N_norm_exact_variance', 'N_Q_exact_variance',
                 'N_norm_variance_le_2M', 'N_Q_variance_le_2M', 'O_closed_mean_upper', 'N_Z_L2', 'C_root']
subroots = {n: closure(n) for n in subroot_names}
lineage_current_checks = []
for name, obj in [('source-proof-graph-v2.json', graph), ('exact-target-coverage-v2.json', coverage), ('root-closures-v2.json', recorded)]:
    for component in obj['binding_successor']['unchanged_semantic_components']:
        h = hashlib.sha256(json.dumps(obj[component['component']], ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
        assert h == component['current_canonical_sha256'] == component['old_canonical_sha256']
        lineage_current_checks.append({'artifact': name, 'component': component['component'], 'current_computed_and_old_bound_sha256': h})
# Do not read historical private cognition/scripts/audits. Old-component digests
# are lineage bindings; only current component canonical digests are recomputed.
old_checksums = []
for name in ['SHA256SUMS.raw', 'SHA256SUMS.phase2a-judgment-v1', 'SHA256SUMS.phase2a-process-v1', 'SHA256SUMS.phase2a-judgment-v2']:
    for line in (OWN / name).read_text().splitlines():
        h, filename = line.split('  ', 1)
        assert pin(OWN / filename)['sha256'] == h, filename
    old_checksums.append(pin(OWN / name))
assert pin(OWN / 'RAW-FREEZE.json')['sha256'] == '8f5124e94368f11b70118d21e2b4cb0924f709de4a81b790790be6db7aaaa4c4'
result = {'run': 'VARIANCES-INDEPENDENT-EXACT-GRAPH-V2-20261110',
          'check_kind': 'source_identity_and_structural_traversal_not_mathematical_proof',
          'all_executed_assertions': 'PASS', 'inputs': inputs,
          'source_scope': ['S4 original lines1054-1500 inclusive', 'bib.bib3 original lines1847-1864', 'complete A3.SS3 original lines3837-4134'],
          'coverage': {'units_independently_reenumerated_in_exact_order': len(expected),
                       'kinds': dict(Counter(e[1] for e in expected)),
                       'dispositions': dict(Counter(r['exact_target_successor']['disposition'] for r in rows)),
                       'all_294_line_hashes_match': True, 'all_math_and_reference_records_match': True,
                       'unique_scoped_math_ids': len(all_math), 'math_attachment_occurrences': sum(len(r['raw_source_unit']['math']) for r in rows),
                       'own_raw_math_ids_preserved': len(own_math), 'synthetic_link_collisions_preserved': collisions,
                       'render_only_whitespace_differences_ordinals': render_spacing,
                       'exhaustive_source_unit_keys_sha256': hashlib.sha256(json.dumps(expected_keys, ensure_ascii=False, separators=(',', ':')).encode()).hexdigest()},
          'graph': {'nodes': len(nodes), 'AND_routes': len(routes), 'alternatives': 0,
                    'source_anchor_snapshots_rebound_to_raw': anchors_checked,
                    'route_use_sites_rebound_to_raw': sum(len(r['consumer_use_sites']) for r in routes.values()),
                    'all_nodes_have_exact_target_coverage_mapping': True,
                    'all_SOURCE_GAPs_have_internal_incoming_routes': True, 'acyclic_all_components': True},
          'recomputed_root_closures': closures, 'recomputed_each_target_subroot': subroots,
          'current_component_canonical_lineage_checks': lineage_current_checks,
          'historical_component_content_not_opened': True,
          'preserved_own_previous_checksum_sets': old_checksums,
          'prohibited_inputs_not_read': ['extractor private cognition/generators/evidence prose/audit verdict', 'full seals/root plans/API inventory/implementation/lessons/ledgers'],
          'prohibited_actions_not_run': ['proof/API search', 'Lean/build', 'normal transition', 'network/browser', 'sourceV/Goal/shared mutation']}
target = OWN / 'phase2b-independent-checks-v2.json'
assert not target.exists()
target.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'output': pin(target), 'summary': result['coverage'],
                  'root_counts': {k: {'nodes': len(v['nodes']), 'routes': len(v['routes'])} for k, v in closures.items()}}, ensure_ascii=False, indent=2))
