from pathlib import Path
from html.parser import HTMLParser
import json, hashlib, datetime, sys
from bs4 import BeautifulSoup

BASE=Path(__file__).resolve().parent
P=BASE/'inputs'/'2610.20492v1.html'
b=P.read_bytes(); s=b.decode('utf-8')
line_starts=[0]
for i,c in enumerate(s):
    if c=='\n':line_starts.append(i+1)
class Parser(HTMLParser):
    def __init__(self):super().__init__(convert_charrefs=False);self.es=[];self.stack=[]
    def handle_starttag(self,tag,attrs):
        st=line_starts[self.getpos()[0]-1]+self.getpos()[1]
        e={'tag':tag,'attrs':dict(attrs),'start':st,'open_end':st+len(self.get_starttag_text()),'parent':self.stack[-1] if self.stack else None}
        ix=len(self.es);self.es.append(e)
        if tag in {'area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr'}:e['end']=e['open_end']
        else:self.stack.append(ix)
    def handle_startendtag(self,tag,attrs):
        self.handle_starttag(tag,attrs)
        if self.stack and self.stack[-1]==len(self.es)-1:self.es[self.stack.pop()]['end']=self.es[-1]['open_end']
    def handle_endtag(self,tag):
        st=line_starts[self.getpos()[0]-1]+self.getpos()[1];end=s.index('>',st)+1
        for j in range(len(self.stack)-1,-1,-1):
            if self.es[self.stack[j]]['tag']==tag:
                for ix in self.stack[j:]:self.es[ix]['end']=end
                del self.stack[j:];return
p=Parser();p.feed(s)
byid={e['attrs']['id']:e for e in p.es if 'id' in e['attrs']}
def anchor(e):
    st,en=e['start'],e['end']
    return {'char_start':st,'char_end':en,'raw_utf8_start':len(s[:st].encode()),'raw_utf8_end':len(s[:en].encode()),'lf_line_start':s.count('\n',0,st)+1,'lf_column0_start':st-(s.rfind('\n',0,st)+1),'lf_line_end':s.count('\n',0,en)+1,'span_sha256':hashlib.sha256(s[st:en].encode()).hexdigest()}
def textext(e):
    sp=BeautifulSoup(s[e['start']:e['end']],'html.parser')
    for m in sp.find_all('math'):m.replace_with(' $'+m.get('alttext',m.get_text(' ',strip=True))+'$ ')
    return sp.get_text(' ',strip=True)
roots=['S4.SS1','S4.SS2.SSS0.Px1','S4.SS2.SSS0.Px2','A3.SS2']
selected=[]
for e in p.es:
    if not any(byid[r]['start']<=e['start'] and e['end']<=byid[r]['end'] for r in roots):continue
    cl=e['attrs'].get('class','').split()
    if e['tag'] in ['p','math','h2','h3','h4','h5'] or any(c in cl for c in ['ltx_para','ltx_theorem','ltx_proof','ltx_equation','ltx_cite']) or (e['tag']=='a' and 'ltx_ref' in cl):
        ident=e['attrs'].get('id','anon:'+str(e['start']))
        selected.append({'source_id':ident,'tag':e['tag'],'classes':cl,'href':e['attrs'].get('href'),'anchor':anchor(e),'text':textext(e)})
out={'source_sha256':hashlib.sha256(b).hexdigest(),'source_bytes':len(b),'source_characters':len(s),'newline_counts':{'LF':s.count('\n'),'CRLF':s.count('\r\n'),'CR':s.count('\r')},'offset_conventions':'0-based Python Unicode codepoint and raw UTF-8 byte offsets, end-exclusive; LF lines 1-based, columns 0-based; source raw bytes are unchanged.','scope_roots':roots,'items':selected}
(BASE/'source-inventory-raw.json').write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n')
ids=roots+['S4.Thmtheorem3','S4.Thmtheorem4','A3.Thmtheorem5','A3.Thmtheorem6']+[f'A3.SS2.p{i}' for i in range(1,20)]
ex={i:{'anchor':anchor(byid[i]),'raw_html':s[byid[i]['start']:byid[i]['end']],'textext':textext(byid[i])} for i in ids if i in byid}
refids=set()
for x in selected:
    if x['href'] and x['href'].startswith('#bib'):refids.add(x['href'][1:])
for i in sorted(refids):
    if i in byid:ex[i]={'anchor':anchor(byid[i]),'raw_html':s[byid[i]['start']:byid[i]['end']],'textext':textext(byid[i])}
(BASE/'anchored-excerpts.json').write_text(json.dumps(ex,indent=2,ensure_ascii=False)+'\n')
receipt={'argv':sys.argv,'time_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':0,'input_read':{'path':'inputs/2610.20492v1.html','bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()},'stdout':'','stderr':'','scope_roots':roots,'output_files':['source-inventory-raw.json','anchored-excerpts.json'],'parser_unclosed_elements':len(p.stack)}
lines=['SOURCE TITLE '+BeautifulSoup(s,'html.parser').title.get_text(' ',strip=True),'SOURCE FORMAT '+json.dumps({k:out[k] for k in ['source_sha256','source_bytes','source_characters','newline_counts']}),'INVENTORY ITEMS '+str(len(selected)),'ROOT ANCHORS '+json.dumps({r:anchor(byid[r]) for r in roots},ensure_ascii=False)]
for ident in ['A3.SS2.p'+str(i) for i in range(1,20)]:
    if ident in ex:lines.append(ident+' | '+ex[ident]['textext'][:450])
for ident in sorted(refids):lines.append('CITATION '+ident+' | '+ex.get(ident,{}).get('textext','MISSING'))
receipt['stdout']='\n'.join(lines)+'\n'
(BASE/'execution'/'extract-execution.json').write_text(json.dumps(receipt,indent=2,ensure_ascii=False)+'\n')
print(receipt['stdout'],end='')
