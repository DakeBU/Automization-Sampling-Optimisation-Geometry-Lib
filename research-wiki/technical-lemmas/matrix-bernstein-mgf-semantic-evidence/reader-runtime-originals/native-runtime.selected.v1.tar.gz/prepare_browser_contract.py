#!/usr/bin/env python3
"""Prepare a new frozen browser checker; does not start Chrome or a server."""
import ast
import hashlib
import json
from pathlib import Path
import plistlib

OWN = Path(__file__).resolve().parent
REPO = OWN.parents[3]
R13 = REPO / '.astis/semantic-neutral-20261114/bernstein_exp_native_72c4'
PREVIEW = REPO / '.astis/huanjian-gc-weighted-mgf-20261114/reader-preview-v1'

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def main():
    verification = json.loads((OWN / 'reader-freeze-verification.v1.json').read_text())
    assert verification['all_inputs_and_exact_diffs_verified']
    old = (R13 / 'primary_browser_wrapper_v5.py').read_text()
    text = old.replace('''"""ROOT-primary only: one bounded original/candidate browser run.

This new wrapper is preparation, not permission. Only the root may execute it
after reviewing the frozen exact contract and obtaining its own narrow approval.
No previous browser approval or R12 script is used.
"""''', '"""Independent native reader execution explicitly assigned by ROOT; localhost only."""')
    text = text.replace('import traceback\n', 'import traceback\nimport tempfile\nfrom browser_extensions import step_actions, source_extra, graph_extra\n')
    text = text.replace("OWN = Path(__file__).resolve().parent\n", "OWN = Path(__file__).resolve().parent\nNATIVE = OWN.parent\nREPO = OWN.parents[3]\nPREVIEW = REPO / '.astis/huanjian-gc-weighted-mgf-20261114/reader-preview-v1'\n(OWN / 'chrome-tmp').mkdir(exist_ok=True)\nos.environ['TMPDIR'] = str(OWN / 'chrome-tmp')\ntempfile.tempdir = str(OWN / 'chrome-tmp')\n")
    text = text.replace('MatrixBernsteinExponential.lean', 'MatrixBernsteinMgf.lean')
    text = text.replace('Tests/GaussianComplexityBernsteinMgf.lean', 'Tests/GaussianComplexityBernsteinWeightedMgf.lean')
    text = text.replace('MatrixBernsteinExponential.bernstein_exponential_quadratic_bound', 'MatrixBernsteinMgf.centered_bounded_matrix_mgf')
    text = text.replace("TMOD = 'Tests.GaussianComplexityBernsteinMgf'", "TMOD = 'Tests.GaussianComplexityBernsteinWeightedMgf'")
    text = text.replace("choices=['candidate']", "choices=['original', 'candidate']")
    text = text.replace("in ['candidate']", "in ['original', 'candidate']")
    text = text.replace('root-primary-browser-contract.v5.json', 'independent-browser-contract.v1.json')
    text = text.replace('FROZEN_PREPARED_ROOT_PRIMARY_ONLY_NO_EXECUTION_BY_CHILD', 'FROZEN_INDEPENDENT_NATIVE_BROWSER_APPROVED_BY_ROOT')
    text = text.replace('ROOT-primary contract', 'independent native contract')
    text = text.replace("(OWN / 'reader-render-manifest.C2.json')", "(PREVIEW / 'preview-freeze-manifest.json')")
    text = text.replace("fixture = OWN / 'reader-fixtures-c2' / args.variant", "fixture = PREVIEW / 'fixtures' / args.variant")
    text = text.replace('root-primary-browser-output-v5', 'browser-output')
    text = text.replace('root-primary-browser-process-v5', 'browser-process')
    text = text.replace('root-primary-actual-process-receipt-v1', 'independent-native-actual-browser-process-receipt-v1')
    text = text.replace("cwd=OWN.parents[2]", "cwd=REPO")
    text = text.replace("context = browser.new_context(viewport={'width': width, 'height': height},", "context = browser.new_context(permissions=['clipboard-read', 'clipboard-write'], viewport={'width': width, 'height': height},")
    text = text.replace('steps.count() == 7', 'steps.count() == 6').replace('seven-proof-steps', 'six-proof-steps').replace('all-seven-steps', 'all-six-steps')
    begin = text.index("                    check(label + '-seven-code-folds'")
    end = text.index('                    table = page.locator', begin)
    replacement = '''                    check(label + '-six-code-folds', len(code) == 6)
                    check(label + '-exact-P121-first-three-folds', ''.join(code[:3]).encode() == (NATIVE / 'candidate-4869db55' / PFILE).read_bytes())
                    check(label + '-exact-T159-last-three-folds', ''.join(code[3:]).encode() == (NATIVE / 'candidate-4869db55' / TFILE).read_bytes())
                    check(label + '-all280-source-lines-exact-in-six-code-folds',
                          len(''.join(code[:3]).splitlines()) == 121 and len(''.join(code[3:]).splitlines()) == 159)
                    step_actions(page, context, steps, NATIVE / 'candidate-4869db55', output, label, check, screenshot, args.variant)
                    for i in range(6):
                        steps.nth(i).scroll_into_view_if_needed()
                        screenshot(page, label + '-step-' + str(i + 1))
'''
    text = text[:begin] + replacement + text[end:]
    text = text.replace("                for source_label, raw, anchor, line_count in [('P', PFILE, 116, 148), ('T', TFILE, 57, 240)]:", "                if args.variant == 'original':\n                    context.close()\n                    continue\n\n                for source_label, raw, anchor, line_count in [('P', PFILE, 46, 121), ('T', TFILE, 21, 159)]:")
    text = text.replace("(OWN / 'reader-9a8b163f' / raw)", "(NATIVE / 'candidate-4869db55' / raw)")
    text = text.replace("pre > span[id^=\"L\"]", "pre span[id^=\"L\"]")
    text = text.replace('theorem bernstein_exponential_quadratic_bound', 'theorem centered_bounded_matrix_mgf')
    text = text.replace('private theorem actual_source_normalized_single_summand_mgf', 'private theorem actual_source_weighted_normalized_single_summand_mgf')
    text = text.replace("                        layout('source-' + source_label)\n", "                        layout('source-' + source_label)\n                        source_extra(page, raw, exact, output, label, check)\n")
    text = text.replace("e[2] == 'source correspondence; not a Lean dependency'", "e[2] == 'source reference (scanner)'")
    text = text.replace("'actual_source_normalized_single_summand_mgf'", "'actual_source_weighted_normalized_single_summand_mgf'")
    text = text.replace("                    layout('graph')\n", "                    layout('graph')\n                    graph_extra(page, context, origin, selected, label, check, screenshot, P, PMOD, TMOD)\n")
    text = text.replace('ROOT execution', 'authorized independent native execution').replace('ROOT runs this process', 'this assigned actor runs this process')
    ast.parse(text)
    wrapper = OWN / 'browser_check.py'
    wrapper.write_text(text)
    chrome = Path('/Applications/Google Chrome.app/Contents/MacOS/Google Chrome')
    info = Path('/Applications/Google Chrome.app/Contents/Info.plist')
    meta = plistlib.loads(info.read_bytes())
    frozen = verification['snapshot_files'] + verification['fixture_files'] + verification['exact_diff_files']
    paths = [PREVIEW / name for name in ['preview-freeze-manifest.json', 'input-freeze-manifest.json', 'static-comparison-report.v1.json', 'render-process.v1.receipt.json', 'render-process.v1.stdout.raw', 'render-process.v1.stderr.raw', 'render_preview.py', 'reader_overlay.py']]
    paths += [OWN / 'browser_extensions.py', OWN / 'reader-freeze-verification.v1.json']
    owned_inputs = [{'path': str(path), 'sha256': sha(path)} for path in paths]
    owned_inputs += [{'path': row['path'], 'sha256': row['sha256']} for row in frozen]
    python = str(REPO / '.astis/huanjian-gc-integration-20261105/browser-venv/bin/python')
    contract = {'schema': 'independent-weighted-mgf-browser-contract-v1', 'status': 'FROZEN_INDEPENDENT_NATIVE_BROWSER_APPROVED_BY_ROOT', 'mathematical_candidate': '4869db55d340cee39f0ba4d49fb0a7a4309ba2d6', 'reader_freeze_sha256': verification['expected_author_artifact_hashes']['preview-freeze-manifest.json'], 'wrapper_sha256': sha(wrapper), 'owned_inputs': owned_inputs, 'cwd': str(REPO), 'exact_commands': {v: [python, str(wrapper), v] for v in ['original', 'candidate']}, 'installed_chrome': {'executable_path': str(chrome), 'binary_sha256': sha(chrome), 'Info_plist_path': str(info), 'Info_plist_sha256': sha(info), 'app_short_version': meta.get('CFBundleShortVersionString'), 'app_build_version': meta.get('CFBundleVersion')}, 'old_approved_script_executed': False, 'viewports': [{'name': 'desktop', 'width': 1440, 'height': 1000}, {'name': 'mobile', 'width': 390, 'height': 844}], 'original_scope': 'Bounded real proof baseline reproducing six absent adjacent actions; original failures preserved, no full source/graph baseline rerun', 'candidate_scope': 'Complete six exact P/P/P/T/T/T code/copy/source/download controls;280source lines;actual formulas/folds/source headers/anchors/longest glyph scrolling; full module download; source-index/reader/Lean/parent navigation; actual existing graph wheel/pointer UI and physical readability with default-fit limits retained', 'all_writes_beneath_owned_runtime': True, 'only_localhost_requests_permitted': True, 'no_other_user_tabs_opened': True, 'server_lifecycle': 'Same foreground process only; shutdown/server_close/worker.join in finally', 'normal_API_metadata_gates_production_writes': 0, 'GUI_execution_requires_tool_escalation': True, 'runtime_outputs_preexisting': (OWN / 'browser-output').exists() or (OWN / 'browser-process').exists()}
    assert not contract['runtime_outputs_preexisting']
    dest = OWN / 'independent-browser-contract.v1.json'
    dest.write_text(json.dumps(contract, indent=2) + '\n')
    print(json.dumps({'wrapper': str(wrapper), 'wrapper_sha256': sha(wrapper), 'contract': str(dest), 'contract_sha256': sha(dest), 'browser_started': False, 'exact_commands': contract['exact_commands']}))

if __name__ == '__main__':
    main()
