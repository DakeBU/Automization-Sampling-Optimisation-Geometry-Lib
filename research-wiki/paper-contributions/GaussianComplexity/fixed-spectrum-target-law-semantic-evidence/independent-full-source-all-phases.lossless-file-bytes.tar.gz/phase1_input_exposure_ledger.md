# Phase-1 input and exposure ledger

Run identity: `/root/targetlaw_fresh_source_9c7d21`.
Owned write directory only: `/Users/zhouhuanjian/ASTIS-GC/.astis/semantic-neutral-20261110/tl_src_e028af/`.

## Assigned information and role

The parent assigned an independent fresh anti-anchored original-source review, source-only before any candidate, concerning source Gaussian laws and target norm moments. The mathematical input was exactly pinned to `.astis/huanjian-resume-20261103/2610.20492v1.html`, 951991 bytes, SHA-256 `6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915`. The named reading regions were `S2`, `S4.SS1`, `S4.SS2.SSS0.Px3` (Lemma 4.5 and explanatory text), `A3.SS3`, and `A3.SS4`, with necessary raw context/citations. The parent instructed me not to read target Lean/type/seal/proof/exposition, registry, source graphs, repair proposals, prior verdict/status, or search target code/library APIs. It also forbade Lean, API/intake/V/STAB, staging/commit/push, browser, and background ASTIS. I was to freeze original-source cognition and then pause before receiving a selective anonymous reconstruction/type/definition packet.

No parent proof transcript, candidate packet, theorem type, proposed implementation definition, or previous semantic judgment was supplied to this run. The broad subject and source region identifiers themselves were supplied by the assignment. This is a source-reviewer role, not a source-blind decoder role.

## Procedural inputs actually read

The complete following prescribed files were read; exact byte copies are under `procedure/` and individually hashed by the manifest:

- `AGENTS.md`
- `docs/contributor-codex-contract.md`
- `docs/theorem-publication-protocol.md`
- `docs/proof-digestion-protocol.md`
- `docs/evidence-routed-memory-protocol.md`
- `docs/samplewiki-reader-navigation.md`
- `.agents/skills/astis-semantic-roundtrip/SKILL.md`

I did not follow procedural links into theorem implementations, semantic registries, publication bindings, source graphs, previous reviews, process-memory verdicts, or suggested source repair documents. The prescribed procedure files themselves contain generic mathematical examples and historical checkpoints (including unrelated project/Bench and StrongConvexFirstOrder information); this was unavoidable prescribed procedural exposure, and no target content was sought through those references. The procedure's generic reminder to distinguish normalization base measures from probability measures in Fisher integrals was visible; it supplies no Gaussian target-law candidate or target verdict.

The four ancestor locations `/AGENTS.md`, `/Users/AGENTS.md`, `/Users/zhouhuanjian/AGENTS.md`, and `/Users/zhouhuanjian/ASTIS-GC/AGENTS.md` were tested for file existence, and existing contents were printed. The repository guide was the returned guide.

## Mathematical source inputs actually inspected

1. The pinned raw source's byte count, SHA-256, title/preamble, and existence/tag attributes of the five assigned anchors were inspected.
2. Raw ID/tag outlines were inspected only for the immediate `S4.SS2`, `A3.SS2`, `A3.SS3`, `A3.SS4`, and `A3.SS5` prefixes to determine selection bounds. The outline included `A3.SS2` paragraph/proof ID names but not their mathematical contents at this step.
3. Complete math-alt/prose renderings of `S2`, `S4.SS1`, all `S4.SS2`, `A3.SS3`, and `A3.SS4` were read. The assigned `S4.SS2.SSS0.Px3` is included in its parent and also preserved separately.
4. The selected paper's bibliography entry `bib.bib3`, cited as [22] in the raw selected context, was read. No external linked text was opened.
5. Extraction validation inspected selected source bytes and math-alt attribute presence; no missing `alttext` was found in the selected math elements. Exact selected subtree bytes were compared again to the original raw byte offsets.

## Accidental/broader exposure, explicitly disclosed

**Directory-name exposure.** An initial `rg --files -g AGENTS.md` inventory of the repository and `/Users/zhouhuanjian/.agents` printed the ordinary repository guide and the following three path names:

```text
/Users/zhouhuanjian/ASTIS-GC/research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-first-order-semantic-evidence/fresh-source-reader-4e8f6a/phase1/inputs/AGENTS.md
/Users/zhouhuanjian/ASTIS-GC/research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-normalizer-semantic-evidence/fresh-source-reader-640251/phase1/instructions/AGENTS.md
/Users/zhouhuanjian/ASTIS-GC/research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-geometry-semantic-evidence/fresh-source-reader-9a6d2f/phase1/instructions/AGENTS.md
```

These names reveal that earlier source-reader directories and those thematic route labels exist. I did not open any of these three paths or their containing directories and saw no previous mathematical reconstruction, judgment, delta, repair, candidate statement, or status content through this inventory. This exposure prevents a claim that absolutely no prior-review metadata was visible.

**Additional raw-source formula exposure.** While checking whether the paper displayed a definition of `Z_A`, I searched the permitted raw HTML for **all** math `alttext` containing a capital `Z`, rather than the narrower string `Z_{A}`. This printed additional raw-paper formulas from `S4.SS3`, `A2.SS1`, `A3.SS1`, and `A3.SS2`, as well as already selected formulas. The exact output is preserved in `extra_raw_exposure_math_alt_with_capital_Z.txt`. It included standard-Gaussian/deferred-rotation and concentration-related formulas from other raw appendices. I did not pursue those sections, consult their candidate implementations, or use them to construct the target-moment account. This was broader **original-source-only** exposure, not candidate or prior-verdict exposure.

## Limits of an independence claim

Ordinary model pretraining familiarity, latent recognition of a theorem, or prior mathematical knowledge cannot be guaranteed absent. I make no claim of an erased history or a cognitively pristine model. The defensible claim is narrower: this run received no parent proof transcript and accessed no candidate theorem/type/definition/proof/exposition, registry, existing source graph, repair proposal, or prior verdict contents before freezing source cognition. The disclosed directory-name inventory and broader raw-source scan are retained rather than silently omitted.

I have not acted as the formalizer or decoder in this run. I cannot certify the identities or histories of other actors from materials not provided to me. I did not spawn another agent.

## Actions and non-actions

Commands used only filesystem read operations, Python standard-library HTML/text/hash extraction, and writes inside the assigned new directory. No Lean process, repository proof/API search, ASTIS control-plane command, gate/check invocation, build/test, browser, external-network retrieval, background job, git status/staging/commit/push, or production edit occurred. Current git-head identity was intentionally not read; the immutable mathematical input is the source byte hash.

The extraction script and procedural snapshots are included for exact reproducibility of the local preservation operation. The manifest and freeze receipt are set to mode `0444`. Source cognition and other phase-1 evidence files are also made read-only when frozen. No candidate/source verdict has been issued. Further packet review must be a subsequent phase with new artifacts rather than editing this freeze.
