import Tests.GaussianComplexityLaplaceTail
import NativeLiteralApplications
import Lean

open Lean Elab Command
set_option maxRecDepth 32768
set_option maxHeartbeats 0

namespace NativeTransitive61e4

def owner (env : Environment) (n : Name) : Json :=
  match env.getModuleIdxFor? n with
  | none => .null
  | some i => toJson env.header.modules[i.toNat]!.module.toString

def audit : CommandElabM Unit := do
  let env := (← getEnv).setExporting false
  let p := `AutoSamplingTheory.TechnicalLemmas.Probability.MatrixLaplaceTail.max_eigenvalue_tail_le_iInf_trace_exp
  let found := env.constants.toList.filter fun (n, _) =>
    n.toString.endsWith ".actual_source_four_sums_laplace_tail"
  unless found.length == 1 do throwError "Expected unique actual private T"
  let t := found.head!.1
  let mut todo := #[p, t]
  let mut seen : NameSet := {}
  let mut rows : Array Json := #[]
  while !todo.isEmpty do
    let n := todo.back!
    todo := todo.pop
    if seen.contains n then continue
    seen := seen.insert n
    let some c := env.find? n | throwError "Missing referenced declaration {n}"
    let td := c.type.getUsedConstants
    let vd := c.value? true |>.map Expr.getUsedConstants |>.getD #[]
    for dep in td ++ vd do
      unless seen.contains dep do todo := todo.push dep
    let isAxiom := match c with | .axiomInfo _ => true | _ => false
    if isAxiom then
      unless n == ``propext || n == ``Classical.choice || n == ``Quot.sound do
        throwError "Nonstandard axiom {n} in complete transitive target closure"
    rows := rows.push <| Json.mkObj [
      ("name", toJson n.toString), ("first_owner", owner env n),
      ("type_dependencies", toJson (td.map Name.toString)),
      ("value_dependencies", toJson (vd.map Name.toString)),
      ("has_value", toJson (c.value? true).isSome),
      ("is_axiom", toJson isAxiom), ("is_unsafe", toJson c.isUnsafe)]
  let data := Json.mkObj [
    ("candidate_commit", toJson "1d1103af694b9663a72b0d610004ed85c7c6b527"),
    ("roots", toJson #[p.toString,t.toString]),
    ("complete_recursive_type_and_value_constant_graph", toJson true),
    ("upstream_values_read_from_pinned_readonly_cache", toJson true),
    ("declarations", Json.arr rows)]
  liftIO <| IO.FS.writeFile
    "/Users/zhouhuanjian/ASTIS-GC/.astis/semantic-neutral-20261114/laplace_native_61e4/complete-transitive-type-value-graph.json"
    data.compress
  logInfo "Complete recursive type/value target graph: {rows.size} declarations"

run_cmd audit
end NativeTransitive61e4

def main : IO Unit := pure ()
