from pathlib import Path
from collections import Counter
import datetime
import hashlib
import json
import re
import runpy
import sys

ROOT = Path('/Users/zhouhuanjian/ASTIS-GC')
OWN = ROOT / '.astis/semantic-neutral-20261112/ri_tc_24a6'
SG = ROOT / '.astis/semantic-neutral-20261112/ri_sg_78c2'
INPUTS = {
    'type-phase-v1/source-graph-v1.json': 'ff660c676a6c5e2d15ca9fa60ff370dcd1383b0d03190a596d227c8c18db0786',
    'type-phase-v1/coverage-v1.json': '4ed21e306eec4017ef3a8488f1fef848165b5e9b599e870c34e8a2763014a9fd',
    'type-phase-v1/internal-bridge-and-applicability-ports.json': '81ce2bf272b44dd42e208cf842a10cf39dcb1229bd0c5ea2a5570c1057ceb61a',
    'raw-freeze-v1/inventory.json': 'b7d9ff0199e061fb925968afb10efea4ddd75fb533ebeb2a91bec3439694d43e',
    'raw-freeze-v1/locators.json': '5e08353ebcaf0997fb56fa0e5baa9c67208ac0b49d43dd376c9a05f8b44b1d22',
}

def sha(b):
    return hashlib.sha256(b).hexdigest()

def digest(p):
    b = p.read_bytes()
    return {'path': str(p.relative_to(ROOT)), 'bytes': len(b), 'sha256': sha(b)}

def write(name, value):
    (OWN / name).write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')

preserved = {
    'raw-freeze.json': 'dc5f3b9278a7fe8d3eac246c794f0832ca157f4d9cf3b9c52443c28444e70ee9',
    'raw-reading.md': 'da525cbeeb425a406679ba7a96ed05d6ebb3ed32c2350fcc67d301593243db84',
    'exposure.json': '7d56295228b82cd5bcd0ae8d706a51fd6a97a3fa2bec02f597f9a9a4c3e52be5',
    'type-freeze.json': '8d363393f9486f01bb526747d6142c8843823917f74b70a664a537988f69147a',
    'type-audit.md': '0709309c3e1965a202a600391ec27c6f353df9b8ca838318c1c1dd1815042b32',
}
for name, expected in preserved.items():
    assert digest(OWN / name)['sha256'] == expected

docs = {}
for name, expected in INPUTS.items():
    assert digest(SG / name)['sha256'] == expected
    docs[name] = json.loads((SG / name).read_text())
g = docs['type-phase-v1/source-graph-v1.json']
c = docs['type-phase-v1/coverage-v1.json']
p = docs['type-phase-v1/internal-bridge-and-applicability-ports.json']
i = docs['raw-freeze-v1/inventory.json']
l = docs['raw-freeze-v1/locators.json']
packet_path = ROOT / '.astis/huanjian-gc-source-row-independence-20261112/selective-type-definition-packet.json'
assert digest(packet_path)['sha256'] == 'c9f8312610515f2ebc067612c981889103e7d8a93a00aa5f75ec8c74feb1ab68'
packet = json.loads(packet_path.read_text())
expected_bindings = {
    'packet_sha256': digest(packet_path)['sha256'],
    'statement_seal_sha256': packet['statement_seal_sha256'],
    'producer_signature_sha256': packet['producer']['signature_sha256'],
    'consumer_signature_sha256': packet['actual_private_consumer']['signature_sha256'],
    'minimal_definition_context_sha256': packet['minimal_definition_context_sha256'],
    'mathlib_pin': packet['minimal_definition_context']['mathlib_pin'],
}
for doc in [g, c, p]:
    for key, val in expected_bindings.items():
        assert doc['bindings'][key] == val
assert g['bindings'] == c['bindings'] == p['bindings']

rawpath = ROOT / packet['source']['raw']
raw = rawpath.read_bytes()
text = raw.decode()
assert sha(raw) == packet['source']['raw_sha256'] == l['source_sha256']
occurrences = []

def visit(x, path):
    if isinstance(x, dict):
        if 'utf8_byte_start' in x:
            a, b = x['utf8_byte_start'], x['utf8_byte_end_exclusive']
            u, v = x['unicode_char_start'], x['unicode_char_end_exclusive']
            checks = {
                'raw_fragment_sha256': sha(raw[a:b]) == x['raw_fragment_sha256'],
                'unicode_and_utf8_spans_agree': text[u:v].encode() == raw[a:b],
                'inclusive_LF_start_line': raw[:a].count(b'\n') + 1 == x['lf_line_start_1based'],
                'inclusive_LF_end_line': raw[:max(a,b-1)].count(b'\n') + 1 == x['lf_line_end_1based'],
            }
            assert all(checks.values()), (path, checks)
            occurrences.append({'record_path':path, 'locator':x, 'checks':checks})
        for key, val in x.items():
            visit(val, path + '/' + key)
    elif isinstance(x, list):
        for n, val in enumerate(x):
            visit(val, path + '/' + str(n))

for name, doc in docs.items():
    visit(doc, name)
assert len(occurrences) == 472
assert len({(x['locator']['utf8_byte_start'], x['locator']['utf8_byte_end_exclusive']) for x in occurrences}) == 75

sys.argv = [str(OWN / 'read_raw.py'), 'silent']
reader = runpy.run_path(str(OWN / 'read_raw.py'))
by_id = reader['by_id']
actual_units = [n.attrs['id'] for n in reader['r'].nodes
                if 3318 <= n.line <= 3606 and n.tag in ['p', 'table'] and 'id' in n.attrs]
claimed_units = [u['element_id'] for u in c['continuous_appendix_window_coverage']]
assert len(actual_units) == len(claimed_units) == 47
assert actual_units == claimed_units
nonspace = lambda s: re.sub(r'\s+', '', s)
assert len(l['source_units']) == 65
assert all(nonspace(v['text']) == nonspace(by_id[k].clean()) for k,v in l['source_units'].items())
assert len(c['items']) == len(i['items']) == len(l['locators']) == 83
assert Counter(a['disposition'] for a in c['items']) == {'NODE':17, 'EXCLUDED':66}
assert len({a['id'] for a in c['items']}) == 83
for post, old in zip(c['items'], i['items']):
    assert all(post.get(k) == v for k,v in old.items())
    assert post['post_seal_disposition'] == post['disposition']
    assert post['raw_disposition_changed'] is False
    assert post['locator'] == l['locators'][post['id']]

source_reviews = {
    'theta.half-grid': 'The physical midpoint grid is literal, with source i=1 through d and typed i.val+1.',
    'experiment.carriers': 'Retain finite real column dimension only; Lambda is not an independence premise.',
    'experiment.natural-standing': 'Retain natural d,q and exact 2q+1<d, including q=0; no tau or kappa input.',
    'experiment.independent-columns': 'Retain full independent standard d-Gaussian column experiment; fixed canonical mu realizes the bounded statement.',
    'c2.r': 'Literal r=q+1 controls both row and feature cardinality.',
    'c2.row-range': 'Entire physical family i=1 through d is retained, not a selected subfamily.',
    'c2.literal-t': 'Deterministic features have constant slot 1 and remaining sqrt2 cosine slots.',
    'c2.physical-gamma': 'Actual coordinate rows of the same column sample, without resampling or orthonormal-basis coefficient substitution.',
    'c2.row-joint-independence': 'Explicit full-family source assertion; marginal laws or pairwise independence cannot discharge it.',
    'c2.row-marginal-context': 'Visible law context only; correctly has no edge into full row independence and is not proved by this producer.',
    'c2.B-definition-context': 'Visible B normalization/tensor context only; correctly not a theorem prerequisite for Yi independence.',
    'c5.theta-recall-context': 'Repeated grid definition, not an orthogonality estimate.',
    'c5.t-coordinate-context': 'Source features are indexed 0 through q, matching the constant coordinate and q=0 endpoint.',
    'cutoff.literal-L': 'Exact deterministic 2r+3log(1000d), with no tail certificate input.',
    'cutoff.literal-R': 'Squared Euclidean norm of actual row i only, with no joint truncation conditioning.',
    'Yi.joint-independence-source-claim': 'Explicit independent truncated-matrix family, without a generic iid strengthening.',
    'Yi.actual-literal-definition': 'Exact inverse-d, Gaussian-first tensor order and closed local cutoff; zero outside is literal source indicator semantics.',
}

def excluded_review(a):
    name = a['id']
    if name.startswith('s4.'):
        return 'The full cited spectral/Haar/algorithm context is outside the same canonical-column independence experiment; its exclusion supplies no hidden premise.'
    if name.startswith('lemma44.') or name == 'experiment.krylov-definition':
        return 'The uniform/Krylov/tau branch is outside both sealed independence outputs; no conditional bound premise is imported.'
    if name == 'c2.n':
        return 'The frequency n is absent from actual row/Y maps; excluding its equality loses no selected premise.'
    if name.startswith('c2.strategy'):
        return 'The complete strategy paragraph concerns range, matrix means and concentration, not the selected independence claims.'
    if name.startswith('c5.'):
        return 'The raw formula/proof step concerns deterministic cosine/range/Gram identities or Gaussian moments; none establishes or is needed as an input to full independence.'
    if name.startswith('c6.'):
        return 'The simultaneous concentration assertion/strategy is a later result and receives no coverage or prerequisite edge in this narrow packet.'
    if name.startswith('cutoff.'):
        return 'The probability/common-event argument is not needed to define the deterministic local Borel truncation; no conditioning or tail premise enters Yi.'
    if name.startswith('bias.'):
        return 'The raw radial/mean/tail-bias step is outside independence; neither shared marginal laws nor Fact C.5 mean identities are used to infer joint independence.'
    raise ValueError(name)

atom_reviews = []
for n, a in enumerate(c['items']):
    comment = source_reviews[a['id']] if a['disposition'] == 'NODE' else excluded_review(a)
    atom_reviews.append({
        'ordinal_1based':n+1, 'id':a['id'], 'source_element_id':a['source_element_id'],
        'semantic_slice':a.get('semantic_slice'), 'source_disposition':a['disposition'],
        'disposition_review':'ACCEPT_FOR_BOUNDED_SOURCE_COVERAGE',
        'independent_review':comment, 'locator':a['locator'],
        'locator_hash_char_span_line_checks_pass':True,
        'source_element_read_independently':True,
        'proof_or_compiled_credit':False,
    })
write('atomic-disposition-review-v1.json', {'version':1, 'items':atom_reviews})

ids = {n['id'] for n in g['nodes']}
assert len(g['nodes']) == 30 and len(g['edges']) == 33
assert {n['id'] for n in g['nodes'] if 'source_element_id' in n} == set(source_reviews)
assert all(e['from'] in ids and e['to'] in ids for e in g['edges'])
assert all(not e['formal_implementation_use_verified'] for e in g['edges'])
edge_reviews = []
for n, e in enumerate(g['edges']):
    kind = e['kind']
    if kind == 'direct source/definition use':
        comment = 'Direction and direct source use site match the literal consumer formula/definition. This is not compiler-backed dependency evidence.'
    elif 'source-to-sealed-target' in kind:
        comment = 'Accepted as narrow source/target correspondence only, with no inference that the source assertion proves the formal target.'
    elif 'required intended producer-consumer' in kind:
        comment = 'Correct intended full-row producer input to the actual separate measurable-image consumer; future material code use remains entirely unverified.'
    elif kind == 'source-implicit measurability output':
        comment = 'Measurability is a source-implicit output and not a public premise; current composition obligation remains unproved.'
    elif kind == 'literal internal adapter':
        comment = 'Actual-Y identity is an internal literal adapter obligation, preserving entries, cutoff and same experiment; no substitute or injectivity premise.'
    else:
        comment = 'Accepted as a source-supported omitted internal bridge with correct direction/use site; no applicability theorem or premise discharge has been verified.'
    edge_reviews.append({
        'ordinal_1based':n+1, 'from':e['from'], 'to':e['to'], 'kind':kind,
        'review':'ACCEPT_SOURCE_OR_UNPROVED_PORT_TOPOLOGY', 'independent_review':comment,
        'consumer_use_sites':e['consumer_use_sites'], 'all_use_site_locator_checks_pass':True,
        'conditional_premises':'Must be discharged internally; no new public certificate accepted.',
        'formal_implementation_use_verified':False,
    })
write('edge-review-v1.json', {'version':1, 'edges':edge_reviews, 'hyperedges':[
    {'id':h['id'], 'conclusion':h['conclusion'], 'required_ports':h['required_ports'],
     'review':'ACCEPT_CHOSEN_INTERNAL_AND_PIPELINE_NOT_FALSE_AND_OF_ALTERNATIVES',
     'proof_verified':False} for h in g['hyperedges']]})

assert len(p['ports']) == 10
assert {a['id'] for a in p['ports']} == {n['id'] for n in g['nodes'] if n['id'].startswith('PORT.')}
assert all(a['status'] == 'OPEN_UNPROVED_INTERNAL_PORT' and not a['compiled_parents'] for a in p['ports'])
write('open-port-review-v1.json', {'version':1, 'genuine_statement_or_source_coverage_blockers':[], 'ports':[
    {'id':a['id'], 'consumer':a['consumer'], 'meaning':a['meaning'],
     'review':'EXPECTED_INTERNAL_MATHEMATICAL_OR_MATHLIB_APPLICABILITY_OBLIGATION',
     'still_open':True, 'is_public_premise':False, 'is_missing_source_coverage_blocker':False,
     'compiled_or_applicability_proof_verified':False} for a in p['ports']]})
write('locator-checks-v1.json', {'version':1, 'raw_source':digest(rawpath),
                               'occurrences':472, 'unique_spans':75, 'checks':occurrences})

local_names = ['graph-assignment.txt', 'graph-exposure-v1.json', 'topology-challenge-v1.md',
               'review_graph_inputs.py', 'freeze_graph_v1.py',
               'atomic-disposition-review-v1.json', 'edge-review-v1.json',
               'open-port-review-v1.json', 'locator-checks-v1.json']
freeze = {
    'kind':'distinct-independent-source-coverage-and-topology-challenge', 'version':1,
    'actor':'/root/row_indep_topology_24a6',
    'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'finding':'ACCEPT_BOUNDED_SOURCE_COVERAGE_AND_UNPROVED_SOURCE_TOPOLOGY',
    'genuine_statement_or_source_coverage_blockers':[],
    'expected_unproved_internal_ports':10,
    'counts':{'atomic_dispositions':83,'NODE':17,'EXCLUDED':66,'nodes':30,'edges':33,
              'route_hyperedges':2,'continuous_window_units':47,'atom_source_elements':65,
              'locator_occurrences_checked':472,'unique_raw_spans_checked':75},
    'bindings':g['bindings'],
    'binding_note':'Exact type packet and all listed bindings verified. SG raw_freeze_manifest_sha256 is a shared input reference; the unspecified SG manifest itself was not opened or independently certified.',
    'source':digest(rawpath),
    'inputs':[digest(SG/name) for name in INPUTS] + [digest(packet_path)],
    'preserved_prior_evidence':[digest(OWN/name) for name in preserved],
    'local_records':[digest(OWN/name) for name in local_names],
    'chronology':'Independent raw freeze -> exact seal/binder/definition packet -> independent type freeze -> explicit SG public-record handoff -> distinct topology challenge.',
    'source_graph_private_rationale_seen':False,
    'implementation_or_target_proofs_seen':False,
    'normal_intake_or_proof_permission_grant':False,
    'actual_compiled_or_call_edges_certified':False,
    'VERIFIED_or_publication_grant':False,
    'remaining_truth_boundary':'All ten internal ports and actual producer/consumer proofs, compilation, material call edges and normal repository admission remain unverified; no source beyond declared bounded windows is accepted.'
}
write('graph-freeze-v1.json', freeze)
records = [digest(OWN/name) for name in local_names] + [digest(OWN/'graph-freeze-v1.json')]
(OWN/'GRAPH-SHA256SUMS-v1').write_text(''.join(f"{a['sha256']}  {Path(a['path']).name}\n" for a in records))
print(json.dumps({'freeze':digest(OWN/'graph-freeze-v1.json'),
                  'report':digest(OWN/'topology-challenge-v1.md'),
                  'finding':freeze['finding'], 'counts':freeze['counts'],
                  'genuine_blockers':[], 'open_internal_ports':10,
                  'prior_raw_and_type_freezes_preserved':True},indent=2))
