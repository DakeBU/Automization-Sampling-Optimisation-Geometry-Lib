from pathlib import Path
import hashlib
import json
import re
from bs4 import BeautifulSoup

ROOT = Path('/Users/zhouhuanjian/ASTIS-GC')
OUT = ROOT / '.astis/semantic-neutral-20261110/src_a83e10'
SOURCE = ROOT / '.astis/huanjian-resume-20261103/2610.20492v1.html'
EXPECTED = '6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
raw = SOURCE.read_bytes()
assert hashlib.sha256(raw).hexdigest() == EXPECTED
soup = BeautifulSoup(raw, 'html.parser')

def text(e):
    c = BeautifulSoup(str(e), 'html.parser')
    for m in c.find_all('math'):
        alt = m.get('alttext')
        if not alt:
            a = m.find('annotation', attrs={'encoding': 'application/x-tex'})
            alt = a.get_text() if a else m.get_text(' ', strip=True)
        m.replace_with(' $' + alt + '$ ')
    return re.sub(r'\s+', ' ', c.get_text(' ', strip=True)).strip()

records = []
for anchor in ('S2', 'S4', 'A3.SS3', 'bib.bib3'):
    section = soup.find(id=anchor)
    assert section is not None
    (OUT / (anchor + '.html')).write_text(str(section), encoding='utf-8')
    (OUT / (anchor + '.txt')).write_text(text(section) + '\n', encoding='utf-8')
    units = []
    for e in section.find_all(True):
        cls = e.get('class', [])
        if e.name in ('h2','h3','h4','h5','h6'):
            kind = 'heading'
        elif e.name == 'p' and 'ltx_p' in cls:
            kind = 'paragraph'
        elif e.name == 'table' and ('ltx_equation' in cls or 'ltx_equationgroup' in cls):
            kind = 'display'
        elif e.name == 'cite':
            kind = 'citation'
        else:
            continue
        units.append({'kind':kind, 'id':e.get('id'), 'text':text(e),
                      'math':[m.get('alttext') for m in e.find_all('math')],
                      'links':[{'href':a.get('href'), 'text':text(a)} for a in e.find_all('a')]})
    record = {'anchor':anchor, 'text_sha256':hashlib.sha256((text(section)+'\n').encode()).hexdigest(),
              'units':units, 'all_math':[{'id':m.get('id'),'tex':m.get('alttext'),'display':m.get('display')} for m in section.find_all('math')],
              'links':[{'href':a.get('href'),'text':text(a)} for a in section.find_all('a')]}
    records.append(record)
    (OUT / (anchor + '.units.txt')).write_text('\n\n'.join(f"{u['kind'].upper()} {u['id']}\n{u['text']}" for u in units)+'\n', encoding='utf-8')
    print(anchor, 'units',len(units),'math',len(record['all_math']),'bytes',len(str(section).encode()))
(OUT / 'raw_source_inventory.json').write_text(json.dumps({'source_path':str(SOURCE.relative_to(ROOT)), 'source_sha256':EXPECTED, 'sections':records}, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
