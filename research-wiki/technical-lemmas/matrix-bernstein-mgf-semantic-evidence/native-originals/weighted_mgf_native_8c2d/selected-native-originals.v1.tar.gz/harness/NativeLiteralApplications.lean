import Tests.GaussianComplexityBernsteinWeightedMgf
import Lean
open MeasureTheory ProbabilityTheory Lean Elab Term
open scoped BigOperators Matrix.Norms.L2Operator MatrixOrder
noncomputable section
universe u v
elab "native_actual_T" : term => do
  let env ← getEnv
  let found := env.constants.toList.filter fun (n, _) =>
    n.toString.endsWith ".actual_source_weighted_normalized_single_summand_mgf"
  unless found.length == 1 do throwError "Expected exactly one actual private weighted consumer, found {found.length}"
  return mkConst found.head!.1
namespace NativeLiteralApplications

theorem literal_P
    {Ω : Type v} [MeasurableSpace Ω] (μ : Measure Ω) [IsProbabilityMeasure μ]
    {ι : Type u} [Fintype ι] [DecidableEq ι] [Nonempty ι]
    (X : Ω → Matrix ι ι ℝ)
    (hX : AEStronglyMeasurable X μ)
    (hintX : Integrable X μ)
    (hintSq : Integrable (fun ω => X ω * X ω) μ)
    (hherm : ∀ᵐ ω ∂μ, (X ω).IsHermitian)
    (hcap : ∀ᵐ ω ∂μ, (1 - X ω).PosSemidef)
    (hzero : (∫ ω, X ω ∂μ) = 0)
    {s : ℝ} (hs : 0 < s) :
    (NormedSpace.exp ((Real.exp s - s - 1) • (∫ ω, X ω * X ω ∂μ)) -
      ∫ ω, NormedSpace.exp (s • X ω) ∂μ).PosSemidef
 := by
  exact AutoSamplingTheory.TechnicalLemmas.Probability.MatrixBernsteinMgf.centered_bounded_matrix_mgf μ X hX hintX hintSq hherm hcap hzero hs

theorem literal_T
        {d q : ℕ} (hq : 2 * q + 1 < d) :
  let D := EuclideanSpace ℝ (Fin d)
  let E := EuclideanSpace ℝ (Fin (q + 1))
  let Ω := Fin (q + 1) → D
  let μ : Measure Ω := Measure.pi (fun _ : Fin (q + 1) => stdGaussian D)
  let r : ℝ := ((q + 1 : ℕ) : ℝ)
  let L : ℝ := 2 * r + 3 * Real.log (1000 * (d : ℝ))
  let θ : Fin d → ℝ := fun i => ((i.val : ℝ) + 1 - 1 / 2) * Real.pi / (d : ℝ)
  let t : Fin d → Fin (q + 1) → ℝ := fun i k =>
    if k.val = 0 then 1 else Real.sqrt 2 * Real.cos ((k.val : ℝ) * θ i)
  let row : Fin d → Ω → E := fun i ω =>
    WithLp.toLp 2 (fun b : Fin (q + 1) => ω b i)
  let Y : Fin d → Ω →
      Matrix (Fin (q + 1) × Fin (q + 1)) (Fin (q + 1) × Fin (q + 1)) ℝ := fun i ω =>
    if ‖row i ω‖ ^ 2 ≤ L then
      (d : ℝ)⁻¹ • Matrix.kronecker
        (Matrix.vecMulVec (WithLp.ofLp (row i ω)) (WithLp.ofLp (row i ω)))
        (Matrix.vecMulVec (t i) (t i))
    else 0
  let mean : Fin d → Matrix (Fin (q + 1) × Fin (q + 1)) (Fin (q + 1) × Fin (q + 1)) ℝ :=
    fun i => ∫ ω, Y i ω ∂μ
  let Z : Fin d → Ω → Matrix (Fin (q + 1) × Fin (q + 1)) (Fin (q + 1) × Fin (q + 1)) ℝ :=
    fun i ω => Y i ω - mean i
  let ρ : ℝ := 2 * r * (L + 1) / (d : ℝ)
  let w : Fin d → ℝ := fun i => Real.cos (((2 * q + 1 : ℕ) : ℝ) * θ i)
  let X : Fin d → Ω →
      Matrix (Fin (q + 1) × Fin (q + 1)) (Fin (q + 1) × Fin (q + 1)) ℝ :=
    fun i ω => ρ⁻¹ • (w i • Z i ω)
  ∀ s : ℝ, 0 < s → ∀ i : Fin d,
    (NormedSpace.exp
        ((Real.exp s - s - 1) • (∫ ω, X i ω * X i ω ∂μ)) -
      ∫ ω, NormedSpace.exp (s • X i ω) ∂μ).PosSemidef
 := by
  exact native_actual_T hq

theorem literal_T_q0 {d : ℕ} (hd : 1 < d) :
  let D := EuclideanSpace ℝ (Fin d)
  let E := EuclideanSpace ℝ (Fin (0 + 1))
  let Ω := Fin (0 + 1) → D
  let μ : Measure Ω := Measure.pi (fun _ : Fin (0 + 1) => stdGaussian D)
  let r : ℝ := ((0 + 1 : ℕ) : ℝ)
  let L : ℝ := 2 * r + 3 * Real.log (1000 * (d : ℝ))
  let θ : Fin d → ℝ := fun i => ((i.val : ℝ) + 1 - 1 / 2) * Real.pi / (d : ℝ)
  let t : Fin d → Fin (0 + 1) → ℝ := fun i k =>
    if k.val = 0 then 1 else Real.sqrt 2 * Real.cos ((k.val : ℝ) * θ i)
  let row : Fin d → Ω → E := fun i ω =>
    WithLp.toLp 2 (fun b : Fin (0 + 1) => ω b i)
  let Y : Fin d → Ω →
      Matrix (Fin (0 + 1) × Fin (0 + 1)) (Fin (0 + 1) × Fin (0 + 1)) ℝ := fun i ω =>
    if ‖row i ω‖ ^ 2 ≤ L then
      (d : ℝ)⁻¹ • Matrix.kronecker
        (Matrix.vecMulVec (WithLp.ofLp (row i ω)) (WithLp.ofLp (row i ω)))
        (Matrix.vecMulVec (t i) (t i))
    else 0
  let mean : Fin d → Matrix (Fin (0 + 1) × Fin (0 + 1)) (Fin (0 + 1) × Fin (0 + 1)) ℝ :=
    fun i => ∫ ω, Y i ω ∂μ
  let Z : Fin d → Ω → Matrix (Fin (0 + 1) × Fin (0 + 1)) (Fin (0 + 1) × Fin (0 + 1)) ℝ :=
    fun i ω => Y i ω - mean i
  let ρ : ℝ := 2 * r * (L + 1) / (d : ℝ)
  let w : Fin d → ℝ := fun i => Real.cos (((2 * 0 + 1 : ℕ) : ℝ) * θ i)
  let X : Fin d → Ω →
      Matrix (Fin (0 + 1) × Fin (0 + 1)) (Fin (0 + 1) × Fin (0 + 1)) ℝ :=
    fun i ω => ρ⁻¹ • (w i • Z i ω)
  ∀ s : ℝ, 0 < s → ∀ i : Fin d,
    (NormedSpace.exp
        ((Real.exp s - s - 1) • (∫ ω, X i ω * X i ω ∂μ)) -
      ∫ ω, NormedSpace.exp (s • X i ω) ∂μ).PosSemidef
 := by
  exact native_actual_T (d := d) (q := 0) hd

theorem literal_T_q0_d2 :
  let D := EuclideanSpace ℝ (Fin 2)
  let E := EuclideanSpace ℝ (Fin (0 + 1))
  let Ω := Fin (0 + 1) → D
  let μ : Measure Ω := Measure.pi (fun _ : Fin (0 + 1) => stdGaussian D)
  let r : ℝ := ((0 + 1 : ℕ) : ℝ)
  let L : ℝ := 2 * r + 3 * Real.log (1000 * (2 : ℝ))
  let θ : Fin 2 → ℝ := fun i => ((i.val : ℝ) + 1 - 1 / 2) * Real.pi / (2 : ℝ)
  let t : Fin 2 → Fin (0 + 1) → ℝ := fun i k =>
    if k.val = 0 then 1 else Real.sqrt 2 * Real.cos ((k.val : ℝ) * θ i)
  let row : Fin 2 → Ω → E := fun i ω =>
    WithLp.toLp 2 (fun b : Fin (0 + 1) => ω b i)
  let Y : Fin 2 → Ω →
      Matrix (Fin (0 + 1) × Fin (0 + 1)) (Fin (0 + 1) × Fin (0 + 1)) ℝ := fun i ω =>
    if ‖row i ω‖ ^ 2 ≤ L then
      (2 : ℝ)⁻¹ • Matrix.kronecker
        (Matrix.vecMulVec (WithLp.ofLp (row i ω)) (WithLp.ofLp (row i ω)))
        (Matrix.vecMulVec (t i) (t i))
    else 0
  let mean : Fin 2 → Matrix (Fin (0 + 1) × Fin (0 + 1)) (Fin (0 + 1) × Fin (0 + 1)) ℝ :=
    fun i => ∫ ω, Y i ω ∂μ
  let Z : Fin 2 → Ω → Matrix (Fin (0 + 1) × Fin (0 + 1)) (Fin (0 + 1) × Fin (0 + 1)) ℝ :=
    fun i ω => Y i ω - mean i
  let ρ : ℝ := 2 * r * (L + 1) / (2 : ℝ)
  let w : Fin 2 → ℝ := fun i => Real.cos (((2 * 0 + 1 : ℕ) : ℝ) * θ i)
  let X : Fin 2 → Ω →
      Matrix (Fin (0 + 1) × Fin (0 + 1)) (Fin (0 + 1) × Fin (0 + 1)) ℝ :=
    fun i ω => ρ⁻¹ • (w i • Z i ω)
  ∀ s : ℝ, 0 < s → ∀ i : Fin 2,
    (NormedSpace.exp
        ((Real.exp s - s - 1) • (∫ ω, X i ω * X i ω ∂μ)) -
      ∫ ω, NormedSpace.exp (s • X i ω) ∂μ).PosSemidef
 := by
  exact native_actual_T (d := 2) (q := 0) (by norm_num)

end NativeLiteralApplications
#print axioms NativeLiteralApplications.literal_P
#print axioms NativeLiteralApplications.literal_T
#print axioms NativeLiteralApplications.literal_T_q0
#print axioms NativeLiteralApplications.literal_T_q0_d2

namespace NativeSemanticChecks
variable {ι : Type u} [Fintype ι] [DecidableEq ι]
theorem norm_is_actual_clm (A : Matrix ι ι ℝ) :
    ‖A‖ = ‖Matrix.toEuclideanCLM (𝕜 := ℝ) A‖ := rfl
theorem matrix_uniformity_is_product :
    (inferInstance : UniformSpace (Matrix ι ι ℝ)) = Matrix.instUniformSpace ι ι ℝ := rfl
theorem matrix_topology_is_product :
    (inferInstance : TopologicalSpace (Matrix ι ι ℝ)) =
      (inferInstanceAs (TopologicalSpace (ι → ι → ℝ))) := rfl
theorem matrix_is_standard_borel :
    let M := Matrix ι ι ℝ
    letI : MeasurableSpace M := borel M
    StandardBorelSpace M := by
  dsimp only
  letI : MeasurableSpace (Matrix ι ι ℝ) := borel (Matrix ι ι ℝ)
  letI : BorelSpace (Matrix ι ι ℝ) := ⟨rfl⟩
  infer_instance
def actual_rational_matrix_algebra : Algebra ℚ (Matrix ι ι ℝ) := inferInstance
theorem actual_matrix_exp_series (A : Matrix ι ι ℝ) :
    NormedSpace.exp A = (NormedSpace.expSeries ℚ (Matrix ι ι ℝ)).sum A :=
  congrFun (NormedSpace.exp_eq_expSeries_sum ℚ) A
theorem original_mu_probability (d q : ℕ) :
    IsProbabilityMeasure
      (Measure.pi (fun _ : Fin (q + 1) => stdGaussian (EuclideanSpace ℝ (Fin d)))) := by
  infer_instance
end NativeSemanticChecks
