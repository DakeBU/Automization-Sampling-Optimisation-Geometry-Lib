#!/opt/anaconda3/bin/python
import hashlib
import html.parser
import json
import pathlib
from bs4 import BeautifulSoup

BASE = pathlib.Path(__file__).resolve().parent
raw = (BASE/'inputs/2610.20492v1.html').read_bytes()
text = raw.decode()
soup = BeautifulSoup(raw, 'html.parser')
def readable(tag):
    other = BeautifulSoup(str(tag), 'html.parser')
    for math in other.find_all('math'):
        math.replace_with(' $' + math.get('alttext', math.get_text(' ', strip=True)) + '$ ')
    return other.get_text('\n', strip=True)

definition_ids = set()
for m in soup.find_all('math'):
    alt = m.get('alttext', '')
    if ('\\theta_{i}=' in alt or '\\lambda_{i}=' in alt) and m.find_parent('section', id='S4'):
        p = m.find_parent(class_='ltx_para')
        if p is not None:
            definition_ids.add(p.get('id'))
for anchor in sorted(definition_ids):
    p = soup.find(id=anchor)
    print('DEFINITION', anchor)
    print(readable(p))
    (BASE/(anchor+'.text')).write_text(readable(p))

# HTMLParser positions refer to the unmodified UTF-8-decoded input. Span files
# retain original byte slices rather than BeautifulSoup serializations.
line_starts = [0]
for pos, ch in enumerate(text):
    if ch == '\n': line_starts.append(pos+1)
class Spans(html.parser.HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=False)
        self.stack = []
        self.spans = {}
    def position(self):
        row, col = self.getpos()
        return line_starts[row-1]+col
    def handle_starttag(self, name, attrs):
        if name in {'area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr'}:
            return
        self.stack.append((name, dict(attrs).get('id'), self.position()))
    def handle_startendtag(self, name, attrs):
        pass
    def handle_endtag(self, name):
        for idx in range(len(self.stack)-1, -1, -1):
            if self.stack[idx][0] == name:
                matched = self.stack[idx]
                del self.stack[idx:]
                if matched[1]:
                    start = matched[2]
                    end = text.find('>', self.position())+1
                    self.spans[matched[1]]=(start,end)
                return
parser = Spans()
parser.feed(text)
selected = ['S4.Thmtheorem4', 'A3.SS2', 'A3.Thmtheorem5']
selected += sorted(definition_ids)
# The complete C.2 subtree gives an exhaustive inventory with exact math
# locators and all source proof paragraphs; no implementation topology read.
for tag in soup.find(id='A3.SS2').find_all(id=True):
    if tag.name != 'math' and not tag.get('id','').endswith('.mrow'):
        if ('ltx_para' in tag.get('class',[]) or 'ltx_equation' in tag.get('class',[])
            or 'ltx_proof' in tag.get('class',[]) or 'ltx_theorem' in tag.get('class',[])):
            selected.append(tag['id'])
selected += ['S4.SS2.SSS0.Px1.p2', 'S4.SS2.SSS0.Px2.p1']
records = []
for anchor in dict.fromkeys(selected):
    tag = soup.find(id=anchor)
    if tag is None:
        print('MISSING_REQUESTED_ANCHOR',anchor)
        continue
    start,end = parser.spans[anchor]
    byte_start = len(text[:start].encode())
    byte_end = len(text[:end].encode())
    snippet = raw[byte_start:byte_end]
    path = 'spans/'+anchor+'.html'
    (BASE/'spans').mkdir(exist_ok=True)
    (BASE/path).write_bytes(snippet)
    records.append({'anchor': anchor, 'tag': tag.name, 'class': tag.get('class',[]),
                    'utf8_byte_start_0': byte_start, 'utf8_byte_end_exclusive_0': byte_end,
                    'line_start_1': text.count('\n',0,start)+1,
                    'line_end_1': text.count('\n',0,end)+1,
                    'snippet': path, 'bytes': len(snippet),
                    'sha256': hashlib.sha256(snippet).hexdigest(),
                    'math': [{'id': m.get('id'),'alttext':m.get('alttext')} for m in tag.find_all('math')]})
(BASE/'source_spans.json').write_text(json.dumps(records, ensure_ascii=False, indent=2)+'\n')
for rec in records:
    print(rec['anchor'], rec['tag'], rec['utf8_byte_start_0'], rec['utf8_byte_end_exclusive_0'],
          rec['line_start_1'], rec['line_end_1'], 'MATH', len(rec['math']))
