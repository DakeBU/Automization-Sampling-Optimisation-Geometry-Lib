"""One real normal V call; no manual ledger append, rollback or automatic retry."""
from common import *

def main():
    marker=PRIVATE/'normal-V-attempted.once.json'
    assert not marker.exists() and not (OWN/'window1-success.json').exists()
    x=inputs()
    before=snapshot('window1-before')
    assert not git('window1-initial-worktree-diff','diff','--name-only','HEAD','-z')
    assert not git('window1-initial-index-diff','diff','--cached','--name-only','-z')
    target=before['advances'][ADV];rows=[r for r in before['records'] if r.get('advance_id')==ADV]
    assert target['state']=='PROVED_LOCAL' and target['owner_id']==PROVER and target['publication_declarations']==[P]
    assert sum(r.get('to_state')=='PROVED_LOCAL' for r in rows)==1 and not any(r.get('to_state')=='VERIFIED' for r in rows)
    assert next(r['evidence'] for r in rows if r.get('to_state')=='PROVED_LOCAL')==x['pl']
    assert VERIFIER!=PROVER and read(REPO/CELL)['status']=='proved_locally'
    payload=copy.deepcopy(x['pl'])
    payload.update({
      'verifier_id':VERIFIER,'verified_commit':CARRIER,
      'gate':{'actual_preV_carrier':CARRIER,'six_actual_exit0_gates':x['gates'],'normal_API_reviewed_publication_gate':'The real normal transition implementation calls check_advance(publication_declarations, reviewed=True) before appending; actual API return and the appended event witness this path.','new_Lean_build_at_carrier':False},
      'source_audit':{'public_audit':ident(x['publicpath']),'private_consumer_audit':ident(x['privatepath']),'public_and_private_source_review_state':'source-reviewed','publication_binding_sha256':x['reader']['publication_binding_sha256'],'original_source_blind_decoding':copy.deepcopy(x['pl']['source_blind_decoding']),'independent_wholemodule_seven_slot_review':copy.deepcopy(x['pl']['fresh_source_wholemodule_and_seven_slot']),'source_topology_and_coverage':copy.deepcopy(x['pl']['source_topology_and_coverage']),'new_source_audit_performed':False},
      'semantic_roundtrip_audit':{'public':ident(x['publicpath']),'private':ident(x['privatepath']),'binding':x['reader']['publication_binding_sha256'],'source_fidelity_review_is_distinct_from_native_or_browser_checks':True},
      'fake_closure_scan':{'actual_immutable_math_commit':MATH,'native_report':ident(x['nativepath']),'canonical_source_scan_member':'fake-closure-scan.v1.json in the original independent native public238 archive','native_archive':copy.deepcopy(x['pl']['native_type_value_kernel']['selected_public238_originals']),'P_T_source_bytes':copy.deepcopy(x['pl']['actual_source_bytes']),'standard_axioms_only':['Classical.choice','Quot.sound','propext'],'unauthorized_axioms_or_sorryAx':False,'actual_native_source_closure_rebuilt_at_math_identity':True,'new_build_or_scan_at_metadata_carrier_claimed':False},
      'current_reader_native_and_independent_visual_acceptance':{'exact_acceptance_record':ident(x['readerpath']),'full_current_reader_evidence':copy.deepcopy(x['reader']),'bounded_clip_finding_closed_independently':True,'actual_supplement_exit1_and_2false_retained':True,'wrong_crops_and_unexecuted_mobile_postcrop_steps_not_adopted':True,'optional_v3_not_executed':True},
      'original24_PL_retention':{'original_payload':ident(x['plpath']),'original_field_count':24,'all_original_fields_inline_and_equal':True,'historical_reader_pending_snapshot_preserved_as_historical':True},
      'actual_build_identity_qualification_for_V':'VERIFIED commit999b89925e95e463e0269148010f794dc27bb26a is the frozen metadata/source/reader evidence carrier checked by six actual gates. The actual independent Lean/source-closure build identity remains immutable1d1103af694b9663a72b0d610004ed85c7c6b527; no new Lean build is attributed to999b.',
      'normal_verification_scope':'One public shared P verified with its real private four-family T checked as material consumer; no separate public T theorem node. Full Bernstein/MGF/Lieb/master-tail/C6/main lower bounds, integration/main/site/global graph/purification/whole-Goal completion remain outside this transition.',
      'authorization':ident(x['authpath'])
    })
    assert all(payload[k]==v for k,v in x['pl'].items()) and set(x['pl'])<=set(payload)
    write(OWN/'normal-V-final-payload.full.json',payload)
    write(OWN/'input-identity-check.public.json',{'carrier':CARRIER,'all_six_gate_receipt_and_log_hashes_verified':True,'existing_evidence_identities_checked':len(x['checked_identities']),'original24_inline_equal':True,'reader_necessary_residual':0,'supplement_raw_FAIL_retained':True,'new_browser_Lean_or_source_audit':False,'original239_and356_manifests_unchanged':True})
    sys.path.insert(0,str(REPO))
    from tools import astis_advance as api
    assert api.DEFAULT_ADVANCE_LEDGER==REPO/ADVPATH
    assert not marker.exists()
    write(marker,{'local_private_do_not_publish':True,'advance_id':ADV,'carrier':CARRIER,'worker_id':VERIFIER,'about_to_invoke_normal_API_once':True,'payload_sha256':file_sha(OWN/'normal-V-final-payload.full.json'),'utc':dt.datetime.now(dt.timezone.utc).isoformat()})
    print(json.dumps({'event':'invoking_one_normal_transition','advance_id':ADV,'to_state':'VERIFIED','verifier_id':VERIFIER,'carrier':CARRIER}),flush=True)
    api.transition_advance(ADV,'VERIFIED',worker_id=VERIFIER,modes=['source-review'],evidence=payload)
    print(json.dumps({'event':'normal_transition_returned','normal_API_calls':1}),flush=True)
    after=snapshot('window1-after')
    guards=postguards(before,after,{ADVPATH})
    assert after['advraw'].startswith(before['advraw'])
    suffix=after['advraw'][len(before['advraw']):]
    assert suffix.endswith(b'\n') and len(suffix.splitlines())==1
    appended=json.loads(suffix)
    assert appended['event']=='transition' and appended['advance_id']==ADV and appended['from_state']=='PROVED_LOCAL' and appended['to_state']=='VERIFIED' and appended['worker_id']==VERIFIER
    assert appended['evidence']==payload and all(appended['evidence'][k]==v for k,v in x['pl'].items())
    target=after['advances'][ADV];assert target['state']=='VERIFIED' and target['owner_id']==PROVER and target['publication_declarations']==[P]
    assert sum(r.get('advance_id')==ADV and r.get('to_state')=='VERIFIED' for r in after['records'])==1
    assert git('window1-final-worktree-diff','diff','--name-only','HEAD','-z').split(b'\0')==[ADVPATH.encode(),b'']
    (OWN/'normal-V-exact-target-append.jsonl').write_bytes(suffix)
    write(OWN/'window1-success.json',{'advance_id':ADV,'verified_commit':CARRIER,'verifier_id':VERIFIER,'normal_API_calls':1,'actual_normal_API_returned':True,'original24_top_level_fields_unchanged':True,'exact_appended_record_sha256':sha(suffix),'exact_appended_record_bytes':len(suffix),'target_state':'VERIFIED','all_window1_postguards_passed':True,'all_frontiers_including_target_unchanged':True,'guards':guards,'math_identity':MATH,'new_build_at_verified_carrier':False})
    print(json.dumps({'event':'window1_all_postguards_passed','advance_id':ADV,'target_state':'VERIFIED','exact_appended_record_sha256':sha(suffix)}),flush=True)

if __name__=='__main__':main()
