import AutoSamplingTheory.ExampleCases.ProximalBPS.ActualHarmonicFlow
import AutoSamplingTheory.ExampleCases.ProximalBPS.ActualBounceRate
import Mathlib.MeasureTheory.Measure.Haar.InnerProductSpace
import Mathlib.MeasureTheory.Group.Prod
import Mathlib.MeasureTheory.Integral.Bochner.Basic
import Mathlib.Tactic.Module
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Ring

open MeasureTheory InnerProductSpace
noncomputable section
set_option autoImplicit false
variable {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℝ E]
  [FiniteDimensional ℝ E] [MeasurableSpace E] [BorelSpace E]

private theorem lower_shear (a : ℝ) :
    MeasurePreserving (fun z : E × E => (z.1, z.2 + a • z.1))
      ((volume : Measure E).prod volume) ((volume : Measure E).prod volume) := by
  exact (MeasurePreserving.id (volume : Measure E)).skew_product
    (measurable_snd.add (measurable_fst.const_smul a))
    (Filter.Eventually.of_forall fun x => (measurePreserving_add_right volume (a • x)).map_eq)

private theorem upper_shear (a : ℝ) :
    MeasurePreserving (fun z : E × E => (z.1 + a • z.2, z.2))
      ((volume : Measure E).prod volume) ((volume : Measure E).prod volume) := by
  simpa only [Function.comp_def, Prod.swap_prod_mk, Prod.fst_swap, Prod.snd_swap] using
    (Measure.measurePreserving_swap.comp (lower_shear (E := E) a)).comp Measure.measurePreserving_swap

private theorem negate_phase :
    MeasurePreserving (fun z : E × E => (-z.1, -z.2))
      ((volume : Measure E).prod volume) ((volume : Measure E).prod volume) := by
  exact (LinearIsometryEquiv.neg ℝ).measurePreserving.prod
    (LinearIsometryEquiv.neg ℝ).measurePreserving

private theorem reflect_fiber (n : E) :
    MeasurePreserving (fun p : E => p - (2 * inner ℝ p n / ‖n‖ ^ 2) • n)
      volume volume := by
  let : CompleteSpace E := FiniteDimensional.complete ℝ E
  have heq : (fun p : E => p - (2 * inner ℝ p n / ‖n‖ ^ 2) • n) =
      (fun p => (ℝ ∙ n)ᗮ.reflection p) := by
    funext p
    rw [Submodule.reflection_orthogonal_apply, Submodule.reflection_singleton_apply]
    simp only [two_smul, neg_sub, div_eq_mul_inv, mul_smul]
    rw [real_inner_comm n p]
    module
  rw [heq]
  exact ((ℝ ∙ n)ᗮ.reflection).measurePreserving

private theorem area_matrix (a b c : ℝ) (hd : a * a - b * c = 1)
    (ha : 1 + a ≠ 0) :
    MeasurePreserving (fun z : E × E => (a • z.1 + b • z.2, c • z.1 + a • z.2))
      ((volume : Measure E).prod volume) ((volume : Measure E).prod volume) := by
  let k : ℝ := b / (1 + a)
  have hk : c * k = a - 1 := by
    dsimp [k]
    rw [← mul_div_assoc]
    apply (div_eq_iff ha).2
    nlinarith [hd]
  have hb : k * (1 + a) = b := by dsimp [k]; exact div_mul_cancel₀ b ha
  have heq : (fun z : E × E => (a • z.1 + b • z.2, c • z.1 + a • z.2)) =
      (fun z : E × E => (z.1 + k • z.2, z.2)) ∘
      (fun z : E × E => (z.1, z.2 + c • z.1)) ∘
      (fun z : E × E => (z.1 + k • z.2, z.2)) := by
    funext z
    apply Prod.ext <;> dsimp only [Function.comp_def] <;> match_scalars <;>
      nlinarith [hk, hb, congrArg (fun x : ℝ => k * x) hk]
  rw [heq]
  exact (upper_shear k).comp ((lower_shear c).comp (upper_shear k))

private theorem harmonic_linear (η u : ℝ) (hη : 0 < η) :
    MeasurePreserving (fun z : E × E =>
      (Real.cos u • z.1 + (Real.sqrt η * Real.sin u) • z.2,
       (-Real.sin u / Real.sqrt η) • z.1 + Real.cos u • z.2))
      ((volume : Measure E).prod volume) ((volume : Measure E).prod volume) := by
  have hr : Real.sqrt η ≠ 0 := ne_of_gt (Real.sqrt_pos.mpr hη)
  by_cases ha : 1 + Real.cos u = 0
  · have hc : Real.cos u = -1 := by linarith
    have hs : Real.sin u = 0 := by nlinarith [Real.sin_sq_add_cos_sq u, sq_nonneg (Real.sin u)]
    simpa only [hc, hs, mul_zero, neg_zero, zero_div, zero_smul, add_zero, zero_add,
      neg_one_smul] using (negate_phase (E := E))
  · apply area_matrix _ _ _ _ ha
    field_simp [hr]
    nlinarith [Real.sin_sq_add_cos_sq u]

private theorem translate_position (d : E) :
    MeasurePreserving (fun z : E × E => (d + z.1, z.2))
      ((volume : Measure E).prod volume) ((volume : Measure E).prod volume) := by
  exact (measurePreserving_add_left volume d).prod (MeasurePreserving.id volume)

private theorem harmonic_affine (η u : ℝ) (hη : 0 < η) (d : E) :
    MeasurePreserving (fun z : E × E =>
      (d + Real.cos u • (z.1 - d) + (Real.sqrt η * Real.sin u) • z.2,
       (-Real.sin u / Real.sqrt η) • (z.1 - d) + Real.cos u • z.2))
      ((volume : Measure E).prod volume) ((volume : Measure E).prod volume) := by
  have heq : (fun z : E × E =>
      (d + Real.cos u • (z.1 - d) + (Real.sqrt η * Real.sin u) • z.2,
       (-Real.sin u / Real.sqrt η) • (z.1 - d) + Real.cos u • z.2)) =
      (fun z : E × E => (d + z.1, z.2)) ∘
      (fun z : E × E => (Real.cos u • z.1 + (Real.sqrt η * Real.sin u) • z.2,
        (-Real.sin u / Real.sqrt η) • z.1 + Real.cos u • z.2)) ∘
      (fun z : E × E => (-d + z.1, z.2)) := by
    funext z
    apply Prod.ext <;> dsimp only [Function.comp_def] <;> module
  rw [heq]
  exact (translate_position d).comp ((harmonic_linear η u hη).comp (translate_position (-d)))

#print axioms harmonic_affine

#print axioms lower_shear
#print axioms upper_shear
#print axioms reflect_fiber
end
