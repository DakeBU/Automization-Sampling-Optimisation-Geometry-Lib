from pathlib import Path
import re, html, hashlib, json, sys

ROOT = Path('/Users/zhouhuanjian/ASTIS-GC')
SOURCE = ROOT / '.astis/huanjian-resume-20261103/2610.20492v1.html'
B = SOURCE.read_bytes()
assert len(B) == 951991
assert hashlib.sha256(B).hexdigest() == '6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
S = B.decode('utf-8')

def element(ident):
    m = re.search(r'<([A-Za-z][\w:]*)\b[^>]*\bid="' + re.escape(ident) + r'"[^>]*>', S)
    assert m, ident
    tag = m.group(1)
    depth = 1
    for n in re.finditer(r'</?' + re.escape(tag) + r'\b[^>]*>', S[m.end():]):
        token = n.group()
        depth += -1 if token.startswith('</') else 1
        if depth == 0:
            return m.start(), m.end() + n.end()
    raise ValueError(ident)

def plain(a,z):
    t=S[a:z]
    formulas=[]
    def replace_math(m):
        formulas.append(html.unescape(m.group(1)))
        return ' MATHPLACEHOLDER'+str(len(formulas)-1)+'END '
    t=re.sub(r'<math\b[^>]*\balttext="([^"]*)"[^>]*>.*?</math>',replace_math,t,flags=re.S)
    t=re.sub(r'</(?:p|div|table|h[1-6]|tr|tbody)>','\n',t)
    t=html.unescape(re.sub(r'<[^>]+>','',t))
    t=re.sub(r'MATHPLACEHOLDER(\d+)END',lambda m:'$'+formulas[int(m.group(1))]+'$',t)
    return re.sub(r'\n\s*\n+','\n',t).strip()

def locator(a,z):
    by_a=len(S[:a].encode('utf-8'));by_z=len(S[:z].encode('utf-8'))
    return {'utf8_byte_start':by_a,'utf8_byte_end_exclusive':by_z,'unicode_char_start':a,'unicode_char_end_exclusive':z,'lf_line_start_1based':S.count('\n',0,a)+1,'lf_line_end_1based':S.count('\n',0,z-1)+1,'raw_fragment_sha256':hashlib.sha256(B[by_a:by_z]).hexdigest()}

if __name__ == '__main__':
    for ident in sys.argv[1:]:
        a,z=element(ident)
        print('\n===',ident,json.dumps(locator(a,z),sort_keys=True),'===\n'+plain(a,z))
