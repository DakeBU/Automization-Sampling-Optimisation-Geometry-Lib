from pathlib import Path
import hashlib
import json

base=Path(__file__).resolve().parent
author=Path('/Users/zhouhuanjian/ASTIS-GC/.astis/semantic-neutral-20261110/cg_sg_1d7a46')
checks=[]
out=['Exact author-root filename inventory: '+json.dumps(sorted(x.name for x in author.iterdir()))]
for name,digest in [('phase1_manifest.json','ededc4db5669a328807c9e0fbf9f719fdc92df4257c878bafd343965e25fb00b'),
                    ('phase2_manifest.json','d96ad3ac8e44b7f0621d62c620c1c9e4f8e38b626fa4aa2a5b94a0aa0eb02fc9')]:
    p=author/name;b=p.read_bytes();actual=hashlib.sha256(b).hexdigest()
    assert actual==digest,name
    (base/('author-'+name)).write_bytes(b)
    data=json.loads(b)
    summary={}
    for key,value in data.items():
        if isinstance(value,list):summary[key]={'length':len(value),'first_two':value[:2]}
        elif isinstance(value,dict):summary[key]={'keys':list(value)}
        else:summary[key]=value
    checks.append({'path':str(p),'bytes':len(b),'sha256':actual})
    out.append(name+'\n'+json.dumps(summary,indent=2))
(base/'author-manifest-input-checks.json').write_text(json.dumps(checks,indent=2)+'\n')
stdout='\n\n'.join(out)+'\n';(base/'read-author-manifests.stdout.txt').write_text(stdout);print(stdout,end='')
