"""Freeze two exact propositions and their meaning-carrying definitions."""
from datetime import datetime, timezone
from html.parser import HTMLParser
from pathlib import Path
import hashlib
import json
import subprocess

workspace = Path(__file__).resolve().parent.relative_to(Path.cwd())
paper = Path('research-wiki/paper-contributions/GaussianComplexity')
evidence = paper / 'truncated-row-second-moment-semantic-evidence'
source_path = Path('.astis/huanjian-resume-20261103/2610.20492v1.html')
runner = Path('.astis/huanjian-resume-20261103')


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def dump(obj):
    return (json.dumps(obj, ensure_ascii=False, indent=2) + '\n').encode()


def create(path, raw):
    with path.open('xb') as out:
        out.write(raw)


def receipt(stem):
    path = runner / (stem + '.receipt.json')
    raw = path.read_bytes()
    value = json.loads(raw)
    log = Path(value['log']).read_bytes()
    assert value['exit_code'] == 0 and sha(log) == value['log_sha256']
    return {'path': str(path), 'sha256': sha(raw), 'log_sha256': sha(log)}, log


raw_source = source_path.read_bytes()
text = raw_source.decode()
assert len(raw_source) == 951991 and sha(raw_source) == '6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
line_offsets = [0]
for i, c in enumerate(text):
    if c == '\n':
        line_offsets.append(i + 1)


class Locators(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=False)
        self.stack = []
        self.spans = {}

    def source_offset(self):
        line, col = self.getpos()
        return line_offsets[line - 1] + col

    def handle_starttag(self, tag, attrs):
        start = self.source_offset()
        identifier = dict(attrs).get('id')
        if tag in {'area', 'base', 'br', 'col', 'embed', 'hr', 'img', 'input', 'link', 'meta', 'param', 'source', 'track', 'wbr'}:
            return
        self.stack.append((tag, identifier, start))

    def handle_endtag(self, tag):
        for i in range(len(self.stack) - 1, -1, -1):
            if self.stack[i][0] == tag:
                _, identifier, start = self.stack[i]
                if identifier:
                    end = text.index('>', self.source_offset()) + 1
                    assert identifier not in self.spans
                    self.spans[identifier] = (start, end)
                del self.stack[i:]
                return


parser = Locators()
parser.feed(text)
ids = [
    'S4.Thmtheorem4.p1.m2', 'S4.Thmtheorem4.p1.m3',
    'A3.SS2.p1', 'A3.SS2.p10.m1', 'A3.SS2.p10.m2',
    'A3.Ex107.m1', 'A3.Ex108.m1', 'A3.SS2.p12.m5',
]
anchors = []
for key in ids:
    first, last = parser.spans[key]
    span = text[first:last].encode()
    a, b = len(text[:first].encode()), len(text[:last].encode())
    assert span == raw_source[a:b] and f'id="{key}"'.encode() in span
    anchors.append({
        'source_id': key, 'char_span': [first, last], 'UTF8_byte_span': [a, b],
        'LF_lines_1based': [text.count('\n', 0, first) + 1, text.count('\n', 0, last) + 1],
        'span_sha256': sha(span),
    })

formed, formation_log = receipt('20261111T024902794299Z-radial-covariance-literal-Prop-L2-operator-formation')
meaning, definition_log = receipt('20261111T025203905861Z-radial-covariance-complete-definition-meaning')
assert b'ProducerStatement : Prop' in formation_log and b'ConsumerStatement : Prop' in formation_log
names = [
    'ProbabilityTheory.stdGaussian', 'EuclideanSpace', 'WithLp.ofLp',
    'Matrix.vecMulVec', 'Matrix.kronecker', 'Set.indicator',
    'MeasureTheory.Integrable', 'MeasureTheory.integral',
    'Matrix.instL2OpNormedAddCommGroup', 'Matrix.l2OpNormedAddCommGroupAux',
    'Matrix.toEuclideanCLM', 'Matrix', 'Matrix.of', 'Matrix.one',
    'Matrix.diagonal', 'Matrix.instL2OpNormedSpace',
]
for name in names:
    assert name.encode() in definition_log, name
env = json.loads((workspace / 'actual-environment-before-seal.json').read_bytes())
assert env['manifest_sha256'] == sha(Path('lake-manifest.json').read_bytes())
assert env['source_sha256'] == sha(raw_source)
context = {
    'allowed_only': 'Canonical definitions, domain/measure/normalization and matrix norm conventions. No proof hypotheses or proposed new proof.',
    'mathlib_pin': 'db584cd6d46c92f209a44c0f1c829460d327499d',
    'imports_and_scope': ['import Mathlib', 'open MeasureTheory ProbabilityTheory', 'open scoped Matrix.Norms.L2Operator'],
    'literal_definitions_printed': names,
    'actual_print_receipt': meaning,
    'actual_print_log_sha256': sha(definition_log),
    'meaning': [
        'The carrier is real Euclidean space with q+1 coordinates, its Euclidean norm and Borel sigma-algebra. WithLp.ofLp exposes its coordinate function.',
        'The measure is the canonical centered variance-one standard Gaussian. Its implementation is a pushforward of independent gaussianReal 0 1 coordinates through an orthonormal basis. No law certificate is a supplied premise.',
        'A real Matrix m n is the finite array m → n → real. Matrix.of is the canonical identity equivalence. vecMulVec w v has entry w_i v_j, so G is the uncentered rank-one second-moment matrix.',
        'Matrix.one is diagonal with ones on the diagonal. Matrix.kronecker A B has paired indices with entry A_(i1,j1) B_(i2,j2), giving the ordered gamma-index first and deterministic feature-index second.',
        'The scoped matrix norm is the Euclidean L2 operator norm transported through matrices as continuous linear maps. Its topology agrees with the existing product topology. All matrix integrals use this declared scope.',
        'Set.indicator returns the indicated function on its set and zero elsewhere. The kept event includes equality R=L. The scalar a is the unnormalized retained radial moment divided by r, with no division by a retention probability.',
        'Integrable means a.e. strong measurability and finite norm integral. The real and matrix integrals are Bochner integrals. Their totalized nonintegrable branch returns zero. Both matrix integrabilities are target conclusions, and the finite-dimensional complete matrix codomain is canonical.',
        'All finite natural casts, positive row dimension q+1, source dimension/denominator facts, Gaussian invariance and integrability obligations must be established internally. The consumer fixes a literal deterministic midpoint cosine row, not an assumed bounded feature vector.',
    ],
    'integral_definition_source': {
        'path': '.lake/packages/mathlib/Mathlib/MeasureTheory/Integral/Bochner/Basic.lean',
        'lines': [156, 160],
        'text': ''.join(Path('.lake/packages/mathlib/Mathlib/MeasureTheory/Integral/Bochner/Basic.lean').read_text().splitlines(keepends=True)[155:160]),
    },
}
producer = (workspace / 'producer-signature.draft.txt').read_bytes()
consumer = (workspace / 'consumer-signature.draft.txt').read_bytes()
assert not any(token in producer + consumer for token in (b':= by', b'sorry', b'admit', b'axiom'))
exposure = json.loads((workspace / 'preseal-exposure.json').read_bytes())
seal = {
    'schema_version': 1,
    'seal_id': 'GAUSSIAN-COMPLEXITY-TRUNCATED-ROW-SECOND-MOMENT-20261111-v1',
    'created_utc': datetime.now(timezone.utc).isoformat(),
    'state': 'EXACT_LITERAL_PROPS_FORMED;UNPROVED;INDEPENDENT_TYPE_TOPOLOGY_PENDING',
    'source': {'version': 'arXiv2610.20492v1', 'raw': str(source_path),
               'raw_sha256': sha(raw_source), 'anchors': anchors,
               'scope': 'C.2 Ex108 truncated uncentered row second moment and immediate p12.m5 single-row expected Kronecker summand; source definitions in p1/p10.'},
    'producer': {
        'name': 'AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumTruncatedRowMoment.actual_truncated_row_second_moment',
        'planned_file': 'AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumTruncatedRowMoment.lean',
        'signature': producer.decode(), 'signature_sha256': sha(producer),
        'outcome': 'Matrix integrability and exact scalar-identity second-moment equality under the actual canonical Gaussian and source cutoff.',
    },
    'actual_private_consumer': {
        'name': 'AutoSamplingTheory.Tests.GaussianComplexityFixedSpectrumTruncatedRowMoment.actual_truncated_matrix_summand_mean',
        'planned_file': 'Tests/GaussianComplexityFixedSpectrumTruncatedRowMoment.lean',
        'signature': consumer.decode(), 'signature_sha256': sha(consumer),
        'outcome': 'The actual single-row Y_i is integrable and its expectation is (a/d) times the literal identity-Kronecker deterministic rank-one feature matrix.',
        'consumer_edge': 'Must materially use the producer equality and integrability. No caller-supplied covariance or expectation equation.',
    },
    'binder_audit': [
        {'binder': 'd q : Nat; hq : 2*q+1<d', 'class': 'SOURCE', 'source_ids': ['S4.Thmtheorem4.p1.m2', 'S4.Thmtheorem4.p1.m3'], 'meaning': 'Natural q includes zero, r=q+1; retain the standing source range.'},
        {'binder': 'private i : Fin d', 'class': 'SOURCE_INDEX', 'source_ids': ['A3.Ex107.m1', 'A3.SS2.p12.m5'], 'meaning': 'An arbitrary single summand row, using the common row marginal law and literal deterministic feature row.'},
        {'binder': 'Let-bound E,μ,r,R,L,a,G,kept,θ,t,Y', 'class': 'DEFINITION', 'meaning': 'All explicit canonical or source formulas. No mathematical premise, estimate or proof certificate is hidden in a let definition.'},
    ],
    'EXCESS_public_binders': [],
    'proof_components_forbidden_as_extra_binders': [
        'Gaussian law or radial/sign/permutation invariance certificate',
        'matrix/radius/entry integrability or measurability',
        'a covariance matrix equality, off-diagonal cancellation, equal diagonal moments or trace value',
        'a conditional or truncated probability normalization',
        'joint row-family independence, retained-probability tail bound, matrix concentration',
        'positive-dimension or distinct-coordinate assumption excluding q=0',
        'boundedness/norm estimate or orthogonality of t_i',
    ],
    'scope_boundary': 'Unnormalized truncated second moment and one deterministic-row mean. The prior scalar range/bias, full row-family probability transport, aggregate cosine-frame means, centered summand bounds, fourth moments, concentration, Lemma4.4, oracle/TV/cost adapters, both main bounds, integrated site and purification are separate.',
    'shared_floor_audit': 'Reuse the same canonical stdGaussian and squared-norm moment nodes. A new source-facing matrix second-moment candidate is proposed. Actual compiled parent edges are determined after the proof. No new public law alias or conditional-covariance bundle.',
    'actual_statement_formation': formed,
    'actual_definition_meaning': meaning,
    'actual_environment': env,
    'preseal_exposure': exposure,
    'minimal_definition_context_sha256': sha(dump(context)),
    'no_target_proof_or_proof_API_search_before_admission': True,
}
evidence.mkdir(exist_ok=False)
create(evidence / 'minimal-definition-context.json', dump(context))
create(evidence / 'actual-definition-meaning.log', definition_log)
create(evidence / 'StatementFormation.lean.raw.txt', (workspace / 'StatementFormation.lean').read_bytes())
create(evidence / 'DefinitionMeaning.lean.raw.txt', (workspace / 'DefinitionMeaning.lean').read_bytes())
seal_raw = dump(seal)
seal_path = paper / 'truncated-row-second-moment-statement-seal.json'
create(seal_path, seal_raw)
create(workspace / 'statement-seal-v1.json', seal_raw)
for path in (seal_path, workspace / 'statement-seal-v1.json'):
    path.chmod(0o444)
packet = {
    'roles': 'Selective exact type and canonical meaning packet, independent raw-source freezes precede this handoff.',
    'producer': seal['producer'], 'actual_private_consumer': seal['actual_private_consumer'],
    'source': {'raw': str(source_path), 'sha256': sha(raw_source)},
    'minimal_definition_context': context, 'statement_seal_sha256': sha(seal_raw),
    'minimal_definition_context_sha256': sha(dump(context)),
}
create(workspace / 'selective-type-definition-packet.json', dump(packet))
for name in ('StatementFormation.lean', 'DefinitionMeaning.lean'):
    path = workspace / name
    with path.with_suffix('.lean.raw.txt').open('xb') as out:
        out.write(path.read_bytes())
    path.unlink()
print(json.dumps({'seal': str(seal_path), 'sha256': sha(seal_raw),
                  'producer_signature_sha256': sha(producer), 'private_signature_sha256': sha(consumer),
                  'selective_packet_sha256': sha(dump(packet)), 'state': seal['state']}))
