# Bias typed successor v2: final independent preproof admission

**ACCEPT_PREPROOF_SOURCE_TOPOLOGY_COVERAGE_ROOT_CLOSURES** for this exact successor and the previously accepted unchanged strict statement. Both original typed HOLDs are resolved. **Prospective target proof/API work may proceed after this actual final admission**, with root remaining the sole mathematical worker. The earlier informal implementation-oriented planning deviation and original HOLD remain immutable history; this grants no retroactive pristine-order certificate or waiver and is not a proof/source-V/Goal claim.

## Exact admitted input binding

- Exact successor input-set freeze: `993a4c25db9741d996556731ae36b5f7deb293f2b4d1ab8a19189aea69258d61`.
- Author clarification freeze: `3ef69a26880f4ef33cd6bd93f71b7e27be905d2cf4f1fd1f7c7636cc1943651a`.
- Graph v2: `4608d12b9b1fedc48c4f71ff2cf5f81faa0a0c90ad14a48e0134c90e75b57f56`.
- Coverage binding v2: `f8f8f11b604d97cb79827da98d49e3563aeb2a142e2711b764d2540aa06a5a99`.
- Root-closure binding v2: `2beaf8f85a439ebd4398c4ec3296e6e1dd818db95eda5f0734e27e3887c89f51`.
- Typed-change record: `53e0018ba75673868348d6d6a0ed27c9cd451dbe7ae16b83a1d86d1442577121`.

Machine-input/lineage/original-HOLD-reference bindings were independently hash-checked from the exact master input set. Creator statement-audit and statement-binding artifacts were hash-bound only; their contents were not parsed or adopted as verdicts. The generator and private cognition were not read. The source pin remains `6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915`; strict projection remains `b245ddf40403f7aca7d2f0be6de9953cf1fb2bda57e840d9ee6bf6156aac8511`. No full seal was opened.

## Independently verified limited correction

Recursive comparison of the actual original and successor node/route records found exactly seven semantic field changes, equal to the declared old/new values. They are the two node statements and five conditional/description fields identified in the typed-change record. Every node ID, route ID, parent/consumer/AND field, source snapshot, numerical conclusion, literal object and other original semantic field is unchanged. Schema1→2 and explicit predecessor/current-hash bindings are additional format/provenance metadata changes, not unreported mathematical changes.

`H-POWER-ORDER-SIGN` is resolved: the node now correctly attributes reversal to multiplication by −k≤0, followed by increasing exp. It explicitly identifies the positive source exponents and leaves real casts/power identities as internal obligations. It no longer claims that multiplying by k≥0 itself reverses order.

`H-CHEBYSHEV-CONDITIONAL-SCOPE` is resolved by the generic-conditional option. `G_Chebyshev` and `r_cheb` now express a rule quantified over t with antecedent 0<t, without claiming actual mean positivity. The condition is machine-visible and explicitly unproved until its actual application. `r_zerocheb` instantiates t=m=E F and discharges positivity through **the existing actual incoming parent `N_signed_actual_mean`**. That parent itself depends on the new signed-positive output and actual integrability; it is not a free certificate. The generic subroot still need not contain actual mean positivity, while the actual application closure contains and must prove it. No public theorem binder, private assumed numerical premise or source-wide zero-threshold setting has been added.

## Required inherited checks remain valid

The successor coverage rows are exactly equal to the original rows, including every raw field, historical disposition, target inclusion/exclusion and fragment reason. Root-closure records are exactly equal except explicit current bindings and the new conditional audit. Their canonical hashes were independently checked. The prior source check therefore remains applicable: 366 machine units match the own 367-unit raw inventory after explicitly accounting for the one external bibliography download-link granularity difference; all 350 math elements and exact raw/source-parent/display bindings remain preserved. No source was silently dropped or newly claimed.

All 58 nodes, 50 AND routes, 20 SOURCE_GAP and four local internal obligations retain their original topology and open-proof status. No OR route was introduced. I independently retraversed both entire roots and every one of the thirteen previously checked output/guard subroots, recomputing node, route, source-anchor and use-site-anchor sets. All are unchanged: producer **38 nodes/33 routes**, private consumer **52/46**. No cycle or new free proof-obligation leaf appeared.

The inherited correct scope separations still hold: source gap only in the tail/lower-bias branch; actual Gaussian expectations distinct from deterministic sums; canonical prior means/variance author routes explicit without new credit; actual inverse-precision covariance and finite integral/variance guards internal; private closure materially requires new lower bias/positivity plus actual Q L2/variance≤2M and excludes unused upper bias/full original contrast. No actual rotated-Y, concrete nonzero τ, original .9 probability, query/TV or main lower-bound application is closed here.

This is source topology admission, not a Lean implication or a certificate that future code materially uses the new result. All internal obligations must be proved or supplied by the exact corresponding canonical actual-law facts at integration. The sourcegraph does not authorize substituting arbitrary laws, default-zero integrals, infinite-toReal variance/probability, callback estimates or theorem-shaped hypotheses.

## Process and preservation

Own raw phase1, statement ACCEPT, preseal/process readback, separate postseal process audit and original graph HOLD/checksum members were independently rehashed unchanged. Original author phase2 machine inputs were also rehashed unchanged. The author's new reference-binding points to the exact actual frozen original HOLD hashes; this was verified rather than accepted merely as parent report.

The earlier process HOLD was prospective pending actual independent topology admission. That gate is now satisfied **for forward work on this exact packet**. The disclosed earlier Lean-organization/API-memory planning remains an ordering deviation; no claim that planning never occurred is made. Negative target-file/authorship/retrieval assertions remain attributed to root's disclosures, not independently proved through forbidden implementation/log inspection. Prior source/reviewer roles and all cue exposure remain disclosed.

The limited rereview initially stopped on an overstrict assumption that schema metadata would be identical. Actual schema1→2 changes were then explicitly compared and recorded; this did not expose a source defect or produce an interim acceptance artifact. The final bounded check completed successfully and records its exact inputs/diff. No author graph was repaired by this reviewer.

No target implementation, API/Mathlib body, other-reviewer audit/lesson, private generator/cognition, full seal, normal ledger/frontier/global state, proof, build, browser/network operation or source V was accessed or executed. Only this private successor-review directory was written. Stop after this final immutable admission.
