# Preliminary raw reading: actual matrix second moments and variance

This is a fresh raw-source freeze for the prospective actual-matrix variance
packet. No new exact types, Statement Seal, binder/definition packet or source
graph have been received by this actor. The root's proposed endpoints guide
scope only. This record admits no signature, chosen formal endpoint, topology,
mathematical proof, applicability or permission. Its chronology is before this
actor's new type exposure, not a claim about global seal timing.

## Source and locator correction

The source is *On Complexity of Gaussian Sampling*, arXiv2610.20492v1,
`.astis/huanjian-resume-20261103/2610.20492v1.html`, 951991 bytes, SHA-256
`6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915`.
I freshly read original C.2 p1-p15 in full, including Fact C.5/C.6, and the
original grid/independent-column standing clause.

The initial task's reference to p15 for the variance comparison is retained in
assignment.txt as historical scope wording. Exact raw locations are: Z_i is
defined in p13; Ex113/114 and both centered/cos-squared comparisons occur in
p14; p15 applies matrix Bernstein. The root confirmed this correction before
the freeze. No source defect is inferred from this task-locator correction.

## Literal experiment and substantive source content

The actual physical row gamma_i collects coordinate i of each of r=q+1
independent standard d-Gaussian columns. Source p1 gives its N(0,I_r) marginal
law and also joint row independence. The actual deterministic source features
are t_i=(1,sqrt(2)cos(theta_i),...,sqrt(2)cos(q theta_i))^T with
theta_i=(i-1/2)pi/d, physical i=1,...,d and feature coordinates 0,...,q.
Set n=2q+1, R_i=||gamma_i||^2 and L=2r+3log(1000d). The original source matrix
is

    Y_i=(1/d)(gamma_i gamma_i^T tensor t_i t_i^T) 1_{R_i<=L}.

It is unconditioned on the event that all truncations succeed. Its cutoff
includes equality; the Gaussian factor precedes the deterministic feature
factor. All expectations below concern this actual same experiment, not an
independently resampled surrogate.

Source p13 defines Z_i=Y_i-E[Y_i], then derives operator-norm bounds and R-star.
The definition is relevant; the R-star/Bernstein bounded-summand results are
outside the proposed moment/variance delta.

In p14, Ex113 states

    E[R_i gamma_i gamma_i^T]=(r+2)I_r.

Its substantive explanation uses sign symmetry for off-diagonals and
3+(r-1)=r+2 for diagonals. The same paragraph gives the two rank-one square
identities and Ex114:

    Y_i^2 = (R_i ||t_i||^2 / d^2)
              (gamma_i gamma_i^T tensor t_i t_i^T) 1_{R_i<=L}.

These are ordinary matrix multiplication squares, not entrywise squares or a
scalar squared norm. Dropping the indicator is justified in the source by
positive semidefiniteness. The displayed chain then uses the fourth-moment
identity, ||t_i||^2<=2r and sum_i t_i t_i^T=d I_r to state

    sum_i E[Y_i^2] <=_PSD (2r(r+2)/d) I_(r^2).

Ex118 states the centered identity/comparison

    E[Z_i^2]=E[Y_i^2]-(E[Y_i])^2 <=_PSD E[Y_i^2].

Ex119 names v-star=2r(r+2)/d as an upper bound on the sequence variance
parameter. Ex120 gives, for deterministic c_i=cos(n theta_i),

    E[(c_i Z_i)^2]=c_i^2 E[Z_i^2] <=_PSD E[Z_i^2].

The prospective operator-norm consumer clarified by the root is compatible
with this source scope only after the internal PSD/integral/norm bridges. It
is still a proposed endpoint, not a frozen Lean type in this record.

## Exact principal locators

Complete raw element hashes, UTF-8/codepoint offsets and inclusive LF lines are
in locators.json. These locators are preliminary evidence, not admitted graph
nodes or edges.

| Source locator | Content |
| --- | --- |
| `S4.E11`, lines 1090-1097; `S4.Thmtheorem4.p1.1`, 1210-1214 | Exact midpoint grid and standing nonnegative q, 2q+1<d, independent standard d-Gaussian columns. Shared eigenvalue/C/Krylov clauses are context. |
| `A3.SS2.p1`, 3317-3329; `A3.Ex85` | r/n, actual row/features and source marginal law. |
| `A3.Ex87`, 3352-3358; `A3.SS2.p5`, 3397-3432; `A3.SS2.p8`, 3497-3507 | Source t-norm estimate and exact unweighted t Gram identity used explicitly in p14. |
| `A3.SS2.p10`, 3532-3556; `A3.Ex107`, 3572-3578 | Literal L/R and actual closed-cutoff Y. Tail/common-event probability is not a new premise. |
| `A3.SS2.p12.4`, 3596-3598 | Actual first-mean formula, source context for the actual integral used in centering; no supplied mean certificate. |
| `A3.SS2.p13.1`, line 3609 onward | Literal Z_i=Y_i-E[Y_i]. |
| `A3.Ex111`, 3612-3618; `A3.Ex112`, 3620-3626; `A3.SS2.p13.3`, 3627-3628 | Read in full, but R-star/operator bounded-summand result is outside this variance delta. The deterministic |cos|<=1 fact also appears here. |
| `A3.SS2.p14.1`, 3631; `A3.Ex113`, 3632-3638 | Gaussian fourth-moment invocation and exact R-weighted matrix moment. |
| `A3.SS2.p14.2`, 3639-3645; `A3.Ex114`, 3646-3652 | Sign/diagonal calculation, rank-one square identities, exact actual Y_i^2 formula. |
| `A3.SS2.p14.3`, 3653-3654; `A3.EGx11`, 3655-3672 | PSD indicator removal and complete uncentered second-moment sum bound. |
| `A3.SS2.p14.4`, 3673-3675 | Explicit source use of t norm and unweighted t Gram. |
| `A3.Ex118`, 3676-3682; `A3.SS2.p14.5`, 3683; `A3.Ex119`, 3684-3690 | Centered square identity/PSD comparison and exact variance coefficient. |
| `A3.SS2.p14.6`, 3691; `A3.Ex120`, 3692-3698 | Actual cosine-weighted centered-square comparison. |
| `A3.SS2.p15`, 3700-3714; `A3.Ex121` | Independent/centered/self-adjoint assertion followed by Bernstein probability bound; read but Bernstein is outside the proposed target. |

## Potential hidden premises, endpoints and dimensions

- d,q are natural and the sole prospective standing range is 2q+1<d. This
  includes q=0, r=1 and t_i=(1); the source coarse coefficient is then 6/d,
  still the literal 2r(r+2)/d. No positive-q or separate nonzero-d/r
  certificate should be added for implementation convenience.
- Physical i=1,...,d and Gaussian-column indices 1,...,r must remain distinct
  from feature indices 0,...,q. A future finite-index representation must keep
  the physical +1 offset in theta. Both matrix indices are pairs in Gaussian
  coordinate first, feature coordinate second order; size is r^2 by r^2.
- Actual Y_i^2 has inverse-d-squared normalization, while the summed bound
  has inverse d after the unweighted Gram identity. The indicator is squared
  only through its idempotence, so the literal closed cutoff remains once.
  Neither B's inverse-square-root-d nor a conditional truncation law is the
  same object.
- The source inequality is Loewner/PSD order, not entrywise order. Its later
  operator-norm variance interpretation needs positive semidefiniteness of
  the summed expected squares in addition to the upper Loewner bound. An
  upper Loewner bound on a generic matrix alone is not the norm conclusion.
  Self-adjointness/PSD and any required integral-order compatibility are
  internal obligations, not supplied matrix certificates.
- The centered variance parameter here is sum_i E[Z_i^2], and the weighted
  one is sum_i E[(cos(n theta_i)Z_i)^2]. They are not automatically
  E[(sum_i Z_i)^2] or the square of an expected sum. No cross-term cancellation
  or joint independence is a needed premise for the displayed comparisons.
- Centering uses the actual deterministic matrix E_mu[Y_i], not an arbitrary
  formal mean matrix. The identity in Ex118 needs actual first/square
  integrability, finite integral algebra and self-adjointness internally.
  It must not acquire a new mean certificate, commutativity assumption or
  positivity/bias bound on the coefficient a.
- For W_i=cos(n theta_i)Z_i, the scalar is deterministic and may be negative;
  its square lies in [0,1]. The source comparison is against the PSD expected
  centered square. It uses no weighted Gram cancellation or iid matrix claim.
- Full Gaussian fourth-moment integrability and the exact coefficient r+2
  must be justified for the actual row law. A truncated second-moment result
  or its historical metadata does not by itself supply the unbounded
  R-weighted moment. No moment bound may become a new public premise.
- Any later Bochner formulation must internally prove the required actual
  functions/integrands integrable and use the real finite matrix structure
  selected in the eventual exact packet. Totalized zero integrals must not
  stand in for moments, centering or variance identities. No new exact
  integrability-output list or formal norm choice is accepted here.
- Joint independence is source context for p15 Bernstein, not a premise of
  these single-row second moments or sums of expected PSD matrices. R-star,
  common-event/tail probabilities, a-bias/range, tau smallness, concentration,
  original-ambient transfer and main bounds are not needed certificates.

## Preliminary omitted bridges for the later sealed review

These are concerns from raw reading only; no graph topology or proof is
admitted:

1. Match each actual physical row under the same original column-product
   sample measure to the standard r-Gaussian marginal law. Measurability,
   exact coordinate/basis conventions and scalar/matrix integral transport
   must apply internally without arbitrary ambient-transfer generalization.
2. Expand the source Gaussian fourth-moment invocation and its sign/diagonal
   computation with the appropriate unbounded weighted-product integrability.
   The source's r+2 coefficient and any canonical reuse must match exactly.
3. Reconcile actual Y multiplication with Ex114 using rank-one/tensor square
   algebra and the closed indicator. Establish PSD of the retained and
   untruncated expressions before removing that indicator under expectation.
   Required integrability and order preservation cannot be assumed.
4. Use the exact unweighted source t norm/Gram facts at p14.4, preserve paired
   identity/tensor normalization and derive the exact uncentered PSD sum bound.
   The weighted cosine Gram-zero identity is not a substitute and is not
   needed for this upper bound.
5. Derive the actual centered-square expectation identity, PSD subtraction
   comparison and any requested mean-zero/integrability conclusions from the
   literal actual mean. No public centering/mean/variance certificate is allowed.
6. Handle deterministic cosine scalar squaring and the PSD comparison, then
   any norm interpretation of both summed variance parameters, including
   finite integral/order and Euclidean operator-norm bridges. The exact
   formal endpoint awaits the seal; no Bernstein bound is included.

## Exposure and stop boundary

This actor is not pristine to the paper: R7/R8 work previously exposed C.2
p1-p12 and their types/source topology. Bounded conceptual packets also
supplied historical Ex113/radial-fourth-moment mechanism metadata. The actual
raw p13-p15 text and detailed Ex113/114/118/120 argument are freshly read in
this phase. No old review verdict, new target type, SG note, API or proof
implementation was opened to conduct this reading. Prior exposure is recorded
without treating historical statements as current applicability evidence.

All R7/R8 original raw/type/topology/conceptual bytes remain unchanged. No new
target proof or normal intake was attempted. This phase stops after the raw
freeze, awaiting the separate exact new seal/binder/definition packet; a later
distinct topology challenge must follow the actor's own new type freeze.
