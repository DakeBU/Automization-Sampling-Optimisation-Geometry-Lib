from pathlib import Path
from hashlib import sha256
import json

R=Path('/Users/zhouhuanjian/ASTIS-GC')
O=R/'.astis/semantic-neutral-20261110/cg_sg_1d7a46'
P=O/'phase2'
p=R/'.astis/huanjian-gc-fixed-spectrum-cosine-gram-20261110/multivariateGaussian-literal-definition.txt'
b=p.read_bytes()
assert len(b)==566
assert sha256(b).hexdigest()=='0d32e6c37ec13dc0bdbce701ed77a7e2da591a748c8d8f92eb81a72cc2228171'
target=P/'inputs'/p.name
target.write_bytes(b)
target.chmod(0o444)
record={'path':str(p),'bytes':len(b),'sha256':sha256(b).hexdigest(),'snapshot':'inputs/'+p.name,
 'scope':'Third exact path explicitly authorized after the original two-input read; literal complete definition only, no implementation/proof/API.'}
(P/'supplement_input.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
stdout=json.dumps(record,ensure_ascii=False)+'\n'+b.decode('utf-8')+'\n'
(P/'logs/read_supplement.stdout').write_text(stdout)
(P/'logs/read_supplement.stderr').write_bytes(b'')
print(stdout,end='')
