from pathlib import Path
import json,hashlib,tarfile,io,gzip,datetime
root=Path('.astis/huanjian-gc-first-order-query-integration-20261107/browser');out=Path('research-wiki/paper-contributions/GaussianComplexity/first-order-query-integration-20261107')
def sha(b):return hashlib.sha256(b).hexdigest()
paths=sorted(p for p in root.rglob('*') if p.is_file());rows=[];runs=[];buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w') as tf:
 for p in paths:
  assert not p.is_symlink();raw=p.read_bytes();name=str(p.relative_to(root));info=tarfile.TarInfo(name);info.size=len(raw);info.mtime=0;info.mode=0o644;tf.addfile(info,io.BytesIO(raw));rows.append({'original_raw_path':str(p),'archive_member':name,'raw_sha256':sha(raw),'raw_bytes':len(raw)})
 for p in sorted(root.glob('live-*/report.json')):
  r=json.loads(p.read_text());runs.append({'original_report':str(p),'raw_sha256':sha(p.read_bytes()),'status':r.get('status'),'mode':r.get('mode'),'original_images':len(r.get('screenshots',[])),'semantic_scope':'Only actual passed22 current main acceptance plus passed4 focused supplement support final browser acceptance. Three failed runs and one diagnostic-only run are retained and never relabelled.'})
p=out/'all-browser-originals-and-reports.lossless.tar.gz';assert not p.exists();packed=gzip.compress(buf.getvalue(),mtime=0);p.write_bytes(packed)
with tarfile.open(fileobj=io.BytesIO(gzip.decompress(packed)),mode='r') as tf:
 assert len(tf.getmembers())==len(rows)
 for row in rows:assert sha(tf.extractfile(row['archive_member']).read())==row['raw_sha256']
assert sum(1 for r in rows if r['archive_member'].endswith('.png'))==48
x={'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Lossless raw image/report/diagnostic DOM archive, preserving all successes/failures/diagnostic-only runs. Original local files remain unchanged. Tar filesystem timestamps are normalized packaging metadata; only raw member bytes/relative names are asserted preserved.','archive':str(p),'archive_raw_sha256':sha(packed),'archive_bytes':len(packed),'members':rows,'runs':runs,'all_48_original_PNGs_preserved':True,'final_acceptance_images':26,'diagnostic_only_images':2,'failed_run_images':20,'every_member_roundtrip_verified':True,'new_source_or_Lean_or_UI_verdict_created':False}
(out/'all-browser-originals-and-reports.manifest.json').write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'raw_artifacts':len(rows),'originalPNGs':48,'current_final_acceptance_images':26,'lossless_archive_bytes':len(packed),'archive_raw_sha256':sha(packed)}))
