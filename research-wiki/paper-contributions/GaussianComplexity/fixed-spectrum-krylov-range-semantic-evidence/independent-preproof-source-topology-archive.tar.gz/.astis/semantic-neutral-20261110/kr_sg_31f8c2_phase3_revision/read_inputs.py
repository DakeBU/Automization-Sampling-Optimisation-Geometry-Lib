from pathlib import Path
import hashlib,json,stat
ROOT=Path(__file__).resolve().parent;REPO=ROOT.parents[2]
sha=lambda b:hashlib.sha256(b).hexdigest()
dump=lambda n,x:(ROOT/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
origins={'phase1':('kr_sg_31f8c2','973bcc204bdbad7ac177017fa859d81f03122e7fc583233857c9a31b32afa9b8'),'phase2':('kr_sg_31f8c2_phase2','cfd5668db1992ab74fc9ca63353f35669c76dd5f66df1c909c92777e96702b93')}
snap={}
for label,(name,mhash) in origins.items():
    root=ROOT.with_name(name);assert sha((root/'payload-manifest.json').read_bytes())==mhash
    for mf in ['payload-manifest.json','freeze-envelope-hashes.json']:
        for item in json.loads((root/mf).read_bytes())['files']:
            b=(root/item['path']).read_bytes();assert len(b)==item['bytes'] and sha(b)==item['sha256']
    items=[]
    for p in sorted([root]+list(root.rglob('*'))):
        assert not p.is_symlink();st=p.stat();x={'path':'.' if p==root else str(p.relative_to(root)),'type':'directory' if p.is_dir() else 'file','mode':format(stat.S_IMODE(st.st_mode),'04o'),'inode':st.st_ino,'mtime_ns':st.st_mtime_ns,'ctime_ns':st.st_ctime_ns}
        if p.is_file():
            b=p.read_bytes();x.update(bytes=len(b),sha256=sha(b));assert x['mode']=='0444'
        else:assert x['mode']=='0555'
        items.append(x)
    snap[label]={'root':str(root),'manifest_sha256':mhash,'items':items}
dump('original-phases-baseline.json',snap)
inputs=[('.astis/semantic-neutral-20261110/kr_tc_72a0bf/phase2b/repair-requests.json','c749e11d40049f5c39e00026854d91db889fa4a9d0884e89275a4224b87ab9e8'),('.astis/semantic-neutral-20261110/kr_tc_72a0bf/phase2b/phase2b_topology_judgment.md','190abf7ca84fe952d90aba017a01924a8851f4d8d5dd0fc2a7b8660fdecd0943')]
pins=[]
for file,expected in inputs:
    b=(REPO/file).read_bytes();assert sha(b)==expected;(ROOT/Path(file).name).write_bytes(b)
    pins.append({'path':str(REPO/file),'raw_sha256':sha(b),'bytes':len(b),'copied_as':Path(file).name})
    print('AUTHORIZED CRITIQUE:',file);print(b.decode())
dump('revision-input-pins.json',{'critique_inputs':pins,'original_phase_manifests':{k:v['manifest_sha256'] for k,v in snap.items()},'original_phase_counts':{k:{'files':sum(x['type']=='file' for x in v['items']),'directories':sum(x['type']=='directory' for x in v['items'])} for k,v in snap.items()},'blinding_limit':'Independent challenge is now authorized exposure. No root proof plan, other verdict or implementation is read. These requests are evaluated against raw source, not predetermined acceptance.'})
