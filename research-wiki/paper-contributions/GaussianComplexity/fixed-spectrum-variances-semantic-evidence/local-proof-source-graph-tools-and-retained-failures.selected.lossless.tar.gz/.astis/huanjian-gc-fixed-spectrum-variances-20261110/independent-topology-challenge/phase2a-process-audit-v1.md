# Separate variance preseal exposure audit v1

**Decision: disclosed preseal API-inventory exposure is a recorded process deviation; no zero-API/fully pristine ordering certificate is issued.** It does not refute either fixed source statement, and is not mathematical evidence. Statement judgment v1 remains frozen independently and its private-classification HOLD remains in force pending exact corrected-input review and the separate later topology gate.

This audit was performed only after freezing `phase2a-statement-judgment-v1.md` (SHA-256 `e78f9fa719f03ad2b1c57fe21f64ec042c355217f36d7af8d722dbc244396d54`) and `SHA256SUMS.phase2a-judgment-v1` (SHA-256 `bffae95b36d232cfb5f5a8f7c1fac6a20730ac459474b493e60a4617febe45b3`). The strict corrected v2 projection and new extractor graph have not been read for this audit.

## Exact observed disclosure and limits

Input `preseal-API-inventory-exposure-disclosure.json` is 850 bytes, SHA-256 `b5987904f1e180fedfddefe29486b16e9639ff28de46d408cc9cda11cda7e489`. It records output chunk `120e48` and the actual command:

```text
rg -n '^((noncomputable )?def|theorem|lemma).*variance|^def variance' .lake/packages/mathlib/Mathlib/Probability/Moments/Variance.lean
```

This pattern searches theorem/lemma/declaration names beyond the literal variance definition. The record reports visible variance declaration names and initial signature lines, including finite-variance, finite-sum, covariance and Chebyshev interfaces, and no proof bodies from that output. It reports that the literal definitions were subsequently read at lines 49–69 and that no target proof was authored. Those are the root's exact disclosed assertions; this reviewer did not inspect the referenced chunk, Mathlib file, actual API inventory or target implementation to independently verify the negative claims. No such input is needed for this bounded disclosure audit.

The first attempt to display the disclosure returned an output/context-truncation notice with no usable content visible to the reviewer. A subsequent bounded size/hash/key inspection and then the complete 850-byte JSON supplied the actual readable input. No additional API output or proof body was exposed to this actor by these reads.

## Constitutional assessment

AGENTS and the publication/proof-digestion protocols require the statement seal before proof search and an independently source-built graph. The disclosed broad target-related API query is not confined to semantic definition inspection. Its accidental origin and limited visible lines do not undo that earlier exposure, so the history must not be described as API-blind or an entirely clean preseal ordering. A process exception/deviation is retained, rather than silently certifying the query as definition-only.

The disclosure does not itself establish target proof construction or use of implementation Lean to infer author topology. On this bounded evidence I find no additional mathematical or source-statement defect, and do not invent a source-premise waiver or a new theorem hypothesis. The preseal ordering deviation remains explicit in any later admission. Continuation after exact statement correction and independent graph admission is compatible with preserving that disclosed limitation; it cannot create a retroactive pristine-process certificate.

The reviewer independently froze raw source cognition before seeing the strict statement, and independently froze the statement judgment before this detailed disclosure. Prior C7/grid/means roles and the root-relayed matching classification HOLD were already disclosed. No zero-cue, zero-verdict-exposure or root-never-saw-APIs claim is made. The disclosure's API categories must not be used here as a proof plan or availability certificate.

This audit authorizes no proof/API retrieval, build, normal transition, source V, Goal credit or shared mutation. Final topology admission remains unopened. The only substantive statement HOLD is still `H-PRIVATE-TAU-ANCHOR-CLASSIFICATION`, to be tested against the exact append-only v2 correction separately.
