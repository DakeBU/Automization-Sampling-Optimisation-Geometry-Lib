# Independent whole-module source judgment

Reviewer `/root/radial_exp_fresh_source_6c28`. This judgment is bound to the Phase 1 raw reconstruction freeze `c5337fc016d3c17c3d1966994e367451b39bb6d7044b68d9a8b7ffe129122d66`, Phase 2 type judgment freeze `74f143b55aa888ec4a75cd831a92f31b6d82b26f8c4b3a075298649a3a4b67e3`, and snapshot manifest `967d845b49fbd1574a8a12ef8143c63a342d7e30e479a6ee9a9c2c5a68d125e6` for commit `c0bb993e3674181e33813d4b25fe655865e5ad0b`. The three manifest-bound snapshots were read whole and line numbered. The two declaration literals match the Phase 2 types byte for byte. This judgment precedes the lesson, decoder reconstruction, source correspondence, publication metadata and native checks.

## Verdict

**The producer implements the exact finite moment used at `A3.SS2.p10.m3` on specialization to the unscaled Gaussian marginal in `A3.SS2.p1.2`.** The more general carrier and zero-dimensional case are mathematically valid. The proof adds no source assumption. Its Gaussian change of density fills in the calculation compressed in the source.

**The private consumer uses both conjuncts of that producer to obtain exactly the one-row strict truncation tail at the source cutoff.** This is `A3.Ex104.m1` at \(x=\log(1000d)\), with the upper bound \(1/(1000d)\). The proof's weak exponential Markov event is a temporary superset. The stated bad event stays strict.

No mathematical flaw or blocking semantic delta was found in the three exact snapshots. The source coverage remains the moment and the single-row cutoff specialization. The full variable-threshold estimate and simultaneous all-row event are outside the two interfaces.

## Reused isotropic density

`AutoSamplingTheory/TechnicalLemmas/Measure/IsotropicGaussianDensity.lean`, 4762 bytes, SHA-256 `08eaba5759c1f514e80c58123f6a7c4c9f1ffc18c4d20df3a93b6e718fae25d7`.

- Lines 24–36 quantify over the same finite-dimensional Borel real inner-product carrier and any positive real variance \(\eta\). The output law is the pushforward by \(z\mapsto\sqrt\eta\,z\), with density relative to the canonical volume
  \[
     p_\eta(z)=(\sqrt{2\pi\eta})^{-m}\exp(-\|z\|^2/(2\eta)),\qquad
     m=\operatorname{finrank}_{\mathbb R}E.
  \]
  This is an equality of measures, with the displayed nonnegative real density embedded into \(\mathbb R_{\ge0}^\infty\).
- Lines 38–78 construct an orthonormal coordinate synthesis measurable equivalence. Coordinate scaling commutes with synthesis, and \((\sqrt\eta)^2=\eta\) identifies the scaled scalar variance. The pushforward of the product of independent standard scalar coordinates becomes the product of centered scalar Gaussians of variance \(\eta\).
- Lines 79–103 convert that product to its density and push it across the same volume-preserving coordinate equivalence. The product gives the \(m\)-th power of the one-coordinate normalizer. The exponent uses the sum of squares and the coordinate map's isometry to give the squared Euclidean norm. The proof uses \(\eta>0\) for the positive scalar density representation and root identity. The later applications take \(\eta=1\) and \(\eta=3\).
- At \(m=0\), the empty coordinate product and the canonical volume are unit masses on the singleton, the constant normalizer has exponent zero, and the exponential density is \(1\). The proposition and proof require no positive-dimension premise.

This proposition provides the actual normalized Gaussian densities for the omitted source moment derivation. It is a proof dependency of that moment.

## Moment implementation

`AutoSamplingTheory/TechnicalLemmas/Probability/StdGaussianRadialExponential.lean`, 5096 bytes, SHA-256 `c44b2840eb91a3abf29434bdf2baa9859b503f7a30c24c10ed3296e7f41c88e4`.

| Exact lines | Mathematical check and source binding |
| --- | --- |
| 21–37 | The signature gives \(\operatorname{Integrable}\) and the finite real integral equality. The weight is \(w(z)=e^{\|z\|^2/3}\), the scalar `factor` is the positive-base real power \(F=3^{m/2}\), and the local density embeds the expression of the reused proposition. Continuity and nonnegativity are proved for the weight, and the densities are measurable. This keeps the \(1/3\), norm-square and real half-dimension of `A3.SS2.p10.m2–m3`. |
| 38–53 | The density at variance \(1\) is the original `stdGaussian E` because scaling by \(\sqrt1\) is identity. The variance-\(3\) density is the pushforward of `stdGaussian E` under a measurable scaling, so it has mass \(1\). The lower integral of \(p_3\) against the same volume is consequently \(1\). Both input variance premises are discharged numerically. |
| 54–69 | \(F\ge0\), \(F=(\sqrt3)^m\) via positive-base real powers, and \(F(\sqrt{2\pi\cdot3})^{-m}=(\sqrt{2\pi\cdot1})^{-m}\). The root factors are positive, which justifies their inverses and cancellation. The source's real exponent retains odd-dimension values and \(F=1\) at dimension zero. |
| 70–77 | The weighted density identity is \(p_1(z)w(z)=F p_3(z)\). The exponent calculation is \(-\|z\|^2/2+\|z\|^2/3=-\|z\|^2/6\). Multiplication under the nonnegative extended-real embedding is justified by nonnegativity. This agrees with the Phase 1 tilt derivation, expressed directly in \(m\) dimensions. |
| 78–94 | Integration against the variance-\(1\) law is first evaluated as a lower integral. The weighted identity, measurability and the normalized variance-\(3\) mass yield exactly \(\operatorname{ofReal}(F)\), which is finite. The code combines this with a.e. strong measurability of the continuous weight to prove \(\operatorname{Integrable}\). |
| 95–98 | The finite real Bochner equality follows from the lower integral via the explicit integrability and nonnegativity. The nonnegative real embedding is injective on both sides. The real integral is used only after establishing its integrability. |

The use of the arbitrary carrier is sound because the density is intrinsic to the real inner product. At \(E=\text{EuclideanSpace }\mathbb R\,(\text{Fin }(q+1))\), it is the same standard Gaussian law as the original \(\gamma_i\), and \(\|z\|^2\) has the original \(r=q+1\) independent squared coordinates. The cosine vector and \(d^{-1/2}\) in the row of \(B\) from `A3.Ex85` and `A3.SS2.p1.m6–m8` do not enter the radial law. The case \(q=0\) has \(m=1\) and \(F=\sqrt3\). The generalized zero-dimensional law has \(w\equiv1\) and \(F=1\).

## Single-row truncation implementation

`Tests/GaussianComplexityRadialExponential.lean`, 4161 bytes, SHA-256 `d80698f914312d2953bb1ac1a8f0a92d43a752389f0e14f6abcfa01563345443`.

| Exact lines | Mathematical check and source binding |
| --- | --- |
| 19–35 | From `S4.Thmtheorem4.p1.1` and `A3.SS2.p1.m1`, take natural \(d,q\) with \(2q+1<d\), the Euclidean carrier of dimension \(r=q+1\), and its actual standard Gaussian measure. The cutoff is \(L=2r+3\log(1000d)\) from `A3.SS2.p10.m1`. The condition supplies \(d>0\), so \(\mathrm{scale}=1000d>0\), with \(r\ge0\) from its natural dimension. In the source domain \(d\ge2\) and therefore \(\log(1000d)\ge0\). |
| 36–44 | The proof calls the public moment theorem directly and obtains its integrability and exact real expectation together. It rewrites the rank to \(q+1\). Later both conclusions are used to evaluate the actual lower integral in Markov's bound. The measurable weight is \(e^{R/3}\), with the unscaled squared norm. |
| 46–65 | The identity \((3/2)^2(4/3)=3\) gives \(\log3=2\log(3/2)+\log(4/3)\). The estimates \(\log(3/2)<1/2\) and \(\log(4/3)\le1/3\) give \(\log3<4/3\), exactly the inequality in `A3.SS2.p10.m5`. Multiplying by the nonnegative row dimension yields \((r/2)\log3\le2r/3\). The positive \(\mathrm{scale}\) supports the identity \(e^{\log(\mathrm{scale})}=\mathrm{scale}\); real-power and exponential algebra reduce the ratio to the required \(1/\mathrm{scale}\) bound. |
| 67–78 | The original bad event is \(L<\|z\|^2\). It lies in the weak threshold event used in exponential Markov by monotonicity under division by positive \(3\), real exponential and the nonnegative embedding. The threshold \(e^{L/3}\) is positive and its embedding finite, so extended-real division has the intended sense. This proves the `A3.Ex104.m1` inequality at the fixed cutoff without changing its strict event. |
| 79–82 | The lower integral is converted from the finite real integral using the producer's integrability and a.e. nonnegativity, and then the exact moment is substituted. Real division by the positive threshold commutes with the nonnegative embedding. The final comparison is \(\mu\{R>L\}\le\operatorname{ofReal}((1000d)^{-1})\). |

The ratio in lines 60–65 and 79–81 is

\[
 \frac{3^{r/2}}{e^{L/3}}
 =\exp\!\left(\tfrac r2\log3-\tfrac{2r}{3}-\log(1000d)\right)
 \le \frac1{1000d}.
\]

This realizes the specialized intermediate exponential in the proof. The declared conclusion is the specialized final inequality. In particular \(q=0,d=2\) uses \(r=1\) and \(L=2+3\log2000\), with bound \(1/2000\). At the exact cutoff a row lies in the retained event.

## Remaining source scope

- The source's \(\forall x\ge0\) chain `A3.Ex104`, including its \(x=0\) endpoint, is wider than the fixed-cutoff proposition. The joint \(\mathcal T\) of `A3.Ex105` with mass at least \(999/1000\) uses a finite union bound after the marginal estimate. Neither appears as a declaration in these snapshots.
- The joint construction of the \(d\) independent Gaussian rows from the starts is source setup. The private test directly constructs the correct marginal law and uses its tail. The tail does not require cross-row independence.
- The shifted-tail and first-moment bias argument in `A3.SS2.p11/Ex106`, the radial matrix expectation and bias in `A3.SS2.p12/Ex107–Ex110`, and the recombination with concentration in `A3.SS2.p17/Ex125–Ex126` are downstream. The three code snapshots do not supply their proofs.

## Execution record

All shell commands used `/Users/zhouhuanjian/ASTIS-GC` as explicit working directory. The Phase 2 `shasum -a 256 -c` and freeze digest check returned exit 0 and all three entries OK (chunk `5f9010`). The manifest digest check and read returned exit 0 (chunk `c973f6`). Each snapshot was checked with `wc -c` and `shasum -a 256` and read with `nl -ba`. The retained execution output is from the following independent replay (exit 0, chunk `6583b8`).

```sh
python3 .astis/semantic-neutral-20261110/re_src_6c28/phase3/verify_modules.py > .astis/semantic-neutral-20261110/re_src_6c28/phase3/module_execution.txt 2>&1 && cat .astis/semantic-neutral-20261110/re_src_6c28/phase3/module_execution.txt
```

It verifies the raw manifest, the three snapshots, their manifest commit fields, and the byte-for-byte correspondence of the target types with Phase 2. The lexical scan `rg -n '\b(sorry|admit|axiom|unsafe)\b'` on the three authorized snapshot paths returned no matches, exit 1 (chunk `2f4bca`). This phase's evidence is a mathematical and source comparison of the supplied snapshots.
