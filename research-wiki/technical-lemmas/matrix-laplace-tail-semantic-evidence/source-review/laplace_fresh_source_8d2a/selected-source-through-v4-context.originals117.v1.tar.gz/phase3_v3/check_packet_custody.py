from pathlib import Path
import json,hashlib
p=Path(__file__).parent;sha=lambda b:hashlib.sha256(b).hexdigest()
canonical=lambda j:sha(json.dumps({k:v for k,v in j.items() if k!='packet_sha256'},ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())
root=p/'inputs/anonymous_decoder_originals';rm=json.loads((root/'output/manifest.json').read_text());records=[]
for role,n in [('P','1'),('T','2')]:
 pktp=p/'inputs'/(role+'.reviewer-packet.v2.json');pkt=json.loads(pktp.read_text());dec=json.loads((root/'input'/(n+'.json')).read_text());out=root/'output'/n;manifest=json.loads((out/'manifest.json').read_text());run=json.loads((out/'run.json').read_text());res=json.loads((out/'result.json').read_text());reconstruction=(out/'reconstructed.md').read_text()
 assert canonical(pkt)==pkt['packet_sha256']
 assert canonical(dec)==dec['packet_sha256']==pkt['blind_reconstruction']['decoder_packet_sha256']
 assert sha((out/'run.json').read_bytes())==pkt['blind_reconstruction']['decoder_run_sha256']==manifest['decoder_run_sha256']
 assert reconstruction==pkt['blind_reconstruction']['text']
 assert sha(reconstruction.encode())==pkt['blind_reconstruction']['text_sha256']
 assert dec['lean']['statement']==pkt['lean']['statement']
 assert sha(pkt['lean']['statement'].encode())==pkt['lean']['statement_sha256']
 assert sha(pkt['source']['original_text'].encode())==pkt['source']['text_sha256']
 assert not pkt['blind_reconstruction']['source_text_visible'] and not run['source_text_visible'] and not manifest['source_text_visible']
 assert all(not x for x in pkt['anti_anchoring'].values())
 assert (root/'input'/(n+'.json')).read_bytes()==(out/'input-artifacts/packet.json').read_bytes()
 for a in manifest['input_artifacts']+manifest['output_artifacts']:
  original=Path(a['path']);parts=original.parts;oi=parts.index('output');local=root/Path(*parts[oi:]);assert sha(local.read_bytes())==a['sha256'];assert len(local.read_bytes())==a['bytes']
 rmrec=next(x for x in rm['runs'] if x['number']==int(n));assert sha((out/'manifest.json').read_bytes())==rmrec['manifest_sha256']
 assert dec['lean']['approved_definition_context']==json.loads((out/'input-artifacts/approved-definition-context.json').read_text())
 text=(root/'input'/(n+'.json')).read_text()
 forbidden=['Tropp','2610.20492','GaussianComplexity','MatrixLaplaceTail','ASTIS-RT-','huanjian_20261114']
 assert not any(x in text for x in forbidden)
 records.append({'role':role,'reviewer_packet_file_sha256':sha(pktp.read_bytes()),'reviewer_packet_canonical_sha256':pkt['packet_sha256'],'decoder_input_file_sha256':sha((root/'input'/(n+'.json')).read_bytes()),'decoder_packet_canonical_sha256':dec['packet_sha256'],'decoder_run_sha256':sha((out/'run.json').read_bytes()),'reconstructed_text_sha256':sha(reconstruction.encode()),'all_manifest_artifact_hashes_match':True,'anonymous_inputs_have_no_scanned_source_identity':True,'anti_anchoring_flags_all_false':True,'source_text_visible':False,'decoder_identity':pkt['blind_reconstruction']['decoder'],'formalizer_identity':pkt['roles']['formalizer'],'result_keys':list(res),'current_publication_binding_sha256':pkt['publication_binding_sha256']})
(p/'packet_custody_checks.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(records,indent=2))
