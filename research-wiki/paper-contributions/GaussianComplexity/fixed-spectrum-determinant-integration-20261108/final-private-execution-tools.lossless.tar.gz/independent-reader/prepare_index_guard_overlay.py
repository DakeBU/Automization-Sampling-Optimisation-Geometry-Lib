"""Freeze conditional helper overlays; no live helper/shared/source/API mutation."""
from pathlib import Path
import ast, copy, datetime, difflib, gzip, hashlib, io, json, tarfile
R=Path('/Users/zhouhuanjian/ASTIS-GC');S=R/'.astis/huanjian-gc-fixed-spectrum-determinant-integration-20261108/independent-reader'
P=R/'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-determinant-integration-20261108/independent-integration-reader-review/proposal'
INDEX=P/'canonical-dje-index-supplement';O=INDEX/'guard-overlay-preparation'
WR=P/'later-helper-preparation/official-wrapper-guard-repair'
sha=lambda b:hashlib.sha256(b).hexdigest()
indexpath=INDEX/'supplementary-index-proposal.json';assert sha(indexpath.read_bytes())=='f34ddae19da4c5b6980ce20bd08a99ee1c112b5e95bdc34c9e0e552af720f7ed'
index=json.loads(indexpath.read_bytes());assert not O.exists()
oldpath=P/'later-helper-preparation/preparation-manifest.json';assert sha(oldpath.read_bytes())=='070ba1d78548318993e873723dd8ded0c80f2e088b8a5ff0d8cda9848c250e29'
old=json.loads(oldpath.read_bytes());before={row['path']:(R/row['path']).read_bytes() for row in old['helpers']}
for row in old['helpers']:assert sha(before[row['path']])==row['raw_sha256']
repair=json.loads((WR/'conditional-repair-review.json').read_bytes());assert sha((WR/'conditional-repair-review.json').read_bytes())=='419e7c343659a8acd62a8c0f265f97396f4069ffe25e5062cd5c2ffa5e5b62cf'
current=copy.deepcopy(before)
for row in repair['proposed_changes']:
 data=(R/row['proposed_after_archive']['path']).read_bytes();assert sha(data)==row['proposed_after_archive']['gzip_sha256']
 raw=gzip.decompress(data);assert sha(raw)==row['proposed_after_sha256'];current[row['path']]=raw
commonpath=str((S/'det_acceptance_common.py').relative_to(R));parkpath=str((S/'park_existing_verified_once.py').relative_to(R));acceptpath=str((S/'record_local_acceptance.py').relative_to(R));schemapath=str((S/'future-authorization.schema.json').relative_to(R));docpath=str((S/'LATER_HELPERS.md').relative_to(R))
text=current[commonpath].decode()
def replace(a,b):
 global text
 assert text.count(a)==1,(a[:120],text.count(a));text=text.replace(a,b,1)
replace(" plan=json.loads(rp.read_bytes()); assert len(plan['shared_paths'])==6 and plan['formal_ASTIS_producer_parents']==[DJE]", """ plan=json.loads(rp.read_bytes()); assert len(plan['shared_paths'])==6 and plan['formal_ASTIS_producer_parents']==[DJE]
 supplement_ref=a['supplementary_index_proposal']
 assert supplement_ref['sha256']=='f34ddae19da4c5b6980ce20bd08a99ee1c112b5e95bdc34c9e0e552af720f7ed'
 supplement=read_json_ref(supplement_ref)
 assert resolve(supplement_ref['path'])==P/'canonical-dje-index-supplement/supplementary-index-proposal.json'
 assert supplement['original_six_path_proposal_report_sha256']==PROPOSAL_SHA
 assert supplement['new_mathematical_declarations']==0 and supplement['new_SAUs_or_source_verdicts']==0
 assert supplement['actual_formalizedLocal_records_before']==619 and supplement['proposed_administrative_count_after']==620
 overlay={row['path']:row for row in supplement['shared_paths']}
 assert len(supplement['shared_paths'])==2 and set(overlay)=={'AutoSamplingTheory/TechnicalLemmas/Registry.lean','Tests/Basic.lean'}
 for row in plan['shared_paths']:
  if row['path'] in overlay:
   extra=overlay[row['path']]
   assert extra['before_sha256']==row['planned_after_sha256'] and unpack(extra['before_archive'])==unpack(row['planned_after_archive'])
""")
replace("  assert sha(raw)==row['planned_after_sha256'] and raw==unpack(row['planned_after_archive'])==gitraw(core,path)", """  if path in overlay:
   extra=overlay[path]
   assert sha(raw)==extra['proposed_after_sha256'] and raw==unpack(extra['proposed_after_archive'])==gitraw(core,path)
  else: assert sha(raw)==row['planned_after_sha256'] and raw==unpack(row['planned_after_archive'])==gitraw(core,path)""")
replace("assert registry.count(b'status := LemmaMemoryStatus.formalizedLocal')==619", "assert registry.count(b'status := LemmaMemoryStatus.formalizedLocal')==620")
replace(" assert (R/'Tests/Basic.lean').read_bytes().count(b'formalizedTechnicalLemmaCount = 619')==1", " assert registry.count(b'key := \\\"measure.det-conj-star-alg-aut-existing-canonical\\\"'.replace(b'\\\\',b''))==1\n assert (R/'Tests/Basic.lean').read_bytes().count(b'formalizedTechnicalLemmaCount = 620')==1")
replace("'all_six_exact_after_payloads_and_old_Registry_preserved':True,'canonical_Registry_count':619", "'original_six_after_plus_exact_two_path_index_overlay_and_old_Registry_preserved':True,'supplementary_index_proposal':supplement_ref,'canonical_Registry_count':620")
graphraw=(R/'_site/data/underlying-lean-graph.json').read_bytes();graphsha=sha(graphraw)
scanner=json.loads(gzip.decompress((R/index['actual_readonly_scanner']['path']).read_bytes()))
assert graphsha==scanner['actual_old_generated_graph_raw_sha256']
graphguard="""def unchanged_foreign_graph_guard():
 # Preserve the held39798 graph as historical evidence. This supplementary
 # admission is exactly one canonical existing node and two labelled edges.
 archive=P/'canonical-dje-index-supplement/guard-overlay-preparation/held-original-39798-graph.json.raw.gz'
 oldraw=gzip.decompress(archive.read_bytes())
 assert sha(oldraw)=='GRAPH_SHA'
 old=json.loads(oldraw);new=json.loads((R/'_site/data/underlying-lean-graph.json').read_bytes())
 oldnodes={x['id']:x for x in old['nodes']};newnodes={x['id']:x for x in new['nodes']}
 parent='decl:'+DJE;child='decl:'+DECL;module='module:AutoSamplingTheory.TechnicalLemmas.Measure.DisplacementJacobianEntropy'
 assert parent not in oldnodes and set(newnodes)==set(oldnodes)|{parent}
 assert newnodes[parent]['kind']=='declaration' and newnodes[parent]['status']=='compiled'
 assert 'compilation-only-index' in newnodes[parent]['summary'] and 'legacy-source-audit-debt' in newnodes[parent]['summary']
 for ident,value in oldnodes.items():
  if ident!=child: assert newnodes[ident]==value,ident
 prior=oldnodes[child];now=newnodes[child]
 assert set(prior)==set(now) and all(prior[k]==now[k] for k in prior if k not in ['details','search'])
 details=json.loads(json.dumps(prior['details']))
 refs=[x for x in details if x['label']=='References (name scan; incomplete)']
 assert len(refs)==1 and refs[0]['value']=='';refs[0]['value']=DJE
 assert now['details']==details and now['search'].replace(DJE.lower(),'',1)==prior['search']
 triples=lambda graph:{(x['source'],x['target'],x['relation']) for x in graph['edges']}
 oldedges=triples(old);newedges=triples(new)
 assert oldedges<=newedges and newedges-oldedges=={(module,parent,'declares'),(parent,child,'source reference (scanner)')}
 assert all(old[k]==new[k] for k in old if k not in ['nodes','edges','counts','publication_inputs_sha256'])
 expected=dict(old['counts']);expected['registry_declarations']+=1;expected['nodes']+=1;expected['edges']+=2
 assert new['counts']==expected
 return {'held39798_graph_sha256':sha(oldraw),'one_existing_canonical_compilation_only_node_added':parent,'all_older_foreign_nodes_and_edges_exactly_preserved':True,'only_prior_node_change':child,'two_new_edges':'Owning-module declares plus true source-name scan only; no formal proof or conceptual edge.'}

""".replace('GRAPH_SHA',graphsha)
replace('def browser_evidence(a):',graphguard+'def browser_evidence(a):')
replace(" assert browser['status']=='passed' and not browser['errors']", " assert browser['status']=='passed' and not browser['errors']\n unchanged_foreign_graph_guard()")
current[commonpath]=text.encode()
text=current[parkpath].decode()
replace("expected=P/'later-helper-preparation/official-wrapper-guard-repair/updated-preparation-manifest.json'", "expected=P/'canonical-dje-index-supplement/guard-overlay-preparation/updated-preparation-manifest.json'")
replace('one new Registry producer, administrative619; both models unchanged. Canonical DJE/GPD legacy audit and graph statuses remain unchanged.', 'one actual new source producer plus one compilation-only index admission of existing canonicalDJE, administrative620; both models unchanged. CanonicalDJE source-audit debt remains visible; GPD legacy status/audit is unchanged.')
current[parkpath]=text.encode()
text=current[acceptpath].decode()
replace(" result.update({'origin_main_readback':report['origin_main_readback'],'origin_main_scope':report['origin_main_scope']})", """ result['parent_status_caveat']='Canonical DJE is newly admitted as an EXISTING compiled canonical Registry inventory node only, with visible legacy-source-audit-debt; this adds no theorem, SAU, sourceV or fresh parent-module publication audit. GPD retains its previous source-present/PARTIAL graph reputation. Actual canonical kernel reuse remains separate from the dashed incomplete source-name edge.'
 result['exact_graph_supplement']=unchanged_foreign_graph_guard()
 result.update({'origin_main_readback':report['origin_main_readback'],'origin_main_scope':report['origin_main_scope']})""")
current[acceptpath]=text.encode()
schema=json.loads(current[schemapath]);schema['required'].append('supplementary_index_proposal');schema['properties']['supplementary_index_proposal']={'$ref':'#/$defs/ref'}
current[schemapath]=(json.dumps(schema,ensure_ascii=False,indent=2)+'\n').encode()
text=current[docpath].decode()
replace('Parent DJE/GPD source-present/PARTIAL graph reputation and legacy audit are preserved.', 'Canonical DJE receives compilation-only normal Registry indexing of its already existing proof with visible legacy-source-audit-debt; no old parent sourceV or whole-module publication audit is created. GPD source-present/PARTIAL graph reputation and legacy audit are preserved.')
text+='\nThe separately reviewed canonical-DJE index supplement layers exactly two Registry/Tests after payloads on the frozen original six-path plan, raising only the administrative inventory to620. Every later context must pin its exact supplementary-index-proposal.json. Current helper guards retain original before/after history, verify the exact supplementary payloads and compare the regenerated graph against the held39798 original: all foreign nodes/edges remain identical, with exactly one existing canonical node, its module ownership and the true dashed source scan added. The official canonical lean_gate.py wrapper is accepted only with its immutable reviewed source SHA, actual gate.commands, original hash-checked success log and runtime-bound certificate timestamp; direct tools/astis.py check remains valid. The updated conditional preparation manifest and parking-script hashes require fresh root review and explicit authorization.\n'
current[docpath]=text.encode()
for path,raw in current.items():
 if path.endswith('.py'):ast.parse(raw,filename=path)
 if path.endswith('.json'):json.loads(raw)
O.mkdir(exist_ok=False)
def archive(name,raw):
 path=O/name;assert not path.exists();data=gzip.compress(raw,mtime=0);path.write_bytes(data);assert gzip.decompress(data)==raw
 return {'path':str(path.relative_to(R)),'raw_sha256':sha(raw),'gzip_sha256':sha(data),'raw_bytes':len(raw)}
held=archive('held-original-39798-graph.json.raw.gz',graphraw)
rows=[];diff=b''
changed={path:raw for path,raw in current.items() if raw!=before[path]}
for i,(path,raw) in enumerate(changed.items(),1):
 rows.append({'path':path,'before_sha256':sha(before[path]),'proposed_after_sha256':sha(raw),'before_archive':archive(f'helper-{i}.before.raw.gz',before[path]),'proposed_after_archive':archive(f'helper-{i}.proposed-after.raw.gz',raw)})
 diff+=b''.join(difflib.diff_bytes(difflib.unified_diff,before[path].splitlines(keepends=True),raw.splitlines(keepends=True),fromfile=('a/'+path).encode(),tofile=('b/'+path).encode()))
buf=io.BytesIO();helperrows=[]
with tarfile.open(fileobj=buf,mode='w') as tar:
 for path,raw in current.items():
  info=tarfile.TarInfo(Path(path).name);info.size=len(raw);info.mode=0o644;info.mtime=0;info.uid=info.gid=0;info.uname=info.gname='';tar.addfile(info,io.BytesIO(raw))
  helperrows.append({'path':path,'raw_sha256':sha(raw),'raw_bytes':len(raw),'syntax_check':'ast.parse only' if path.endswith('.py') else 'JSON syntax only' if path.endswith('.json') else 'Preparation documentation only'})
tarraw=gzip.compress(buf.getvalue(),mtime=0);tarpath=O/'updated-conditional-helpers.tar.gz';tarpath.write_bytes(tarraw)
with tarfile.open(fileobj=io.BytesIO(tarraw),mode='r:gz') as tar:
 for path,raw in current.items():assert tar.extractfile(Path(path).name).read()==raw
manifest={'state':'PREPARATION_ONLY_AST_PARSED_NOT_EXECUTED','role':'/root/det_integration_reader','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_verifier_to_preserve':'/root/reader_835194','proof_owner_to_preserve':'huanjian_gc_20261108_fixed_spectrum_determinant','helpers':helperrows,'conditional_application_only':True,'original_preparation_manifest_sha256':sha(oldpath.read_bytes()),'wrapper_repair_review_sha256':'419e7c343659a8acd62a8c0f265f97396f4069ffe25e5062cd5c2ffa5e5b62cf','supplementary_index_proposal_sha256':sha(indexpath.read_bytes()),'held_graph_archive':held,'lossless_preparation_archive':{'path':str(tarpath.relative_to(R)),'sha256':sha(tarraw),'members':len(current)},'actual_updated_helper_executions':0,'new_source_verdict_or_parking_authorization':False}
manifestpath=O/'updated-preparation-manifest.json';manifestpath.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
receiptpath=R/'.astis/huanjian-resume-20261103/20261108T033028602073Z-fixed-spectrum-determinant-canonicalDJE-index-readonly-scanner.receipt.json';receiptraw=receiptpath.read_bytes();receipt=json.loads(receiptraw);logpath=Path(receipt['log']);lograw=logpath.read_bytes()
assert receipt['exit_code']==0 and sha(lograw)==receipt['log_sha256']
report={'reviewer':'/root/det_integration_reader','phase':'Conditional supplementary protection/status/current-helper preparation only','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'verdict':'NO_BLOCKING_OBJECTION_TO_EXACT_CONDITIONAL_HELPER_OVERLAYS','shared_index_proposal':str(indexpath.relative_to(R)),'shared_index_proposal_sha256':sha(indexpath.read_bytes()),'composes_frozen_official_wrapper_repair':True,'proposed_helper_changes':rows,'changed_helper_paths':len(changed),'exact_diff':archive('exact-helper-overlays.diff.raw.gz',diff),'updated_conditional_manifest':str(manifestpath.relative_to(R)),'updated_conditional_manifest_sha256':sha(manifestpath.read_bytes()),'held_graph_archive':held,'unchanged_browser_checker_sha256':'d191bcb9ea513e71e0c2357315dee1821fdcccdab6dc6a2f473d5289589f0766','old_live_helpers_and_all_previous_frozen_proposals_preserved':True,'actual_readonly_scanner_execution':{'receipt':archive('actual-readonly-scanner.receipt.json.raw.gz',receiptraw),'stdout':archive('actual-readonly-scanner.stdout.raw.gz',lograw),'actual_exit_code':0,'actual_elapsed_seconds':receipt['elapsed_seconds']},'preparation_driver':archive('prepare-helper-overlays.py.raw.gz',Path(__file__).read_bytes()),'future_guard_scope':['Exact original6after history plus exact2path supplementary index payloads, currentcount620, oldRegistrybytes retained','Original sourceV/owner/binding/282foreignstates/441foreignfrontiers/7432protectedcontents/README/casevalues/models unchanged','Exact held39798 graph foreign nodes/edges/metadata preserved; only canonicalparent indexing and actual producer scanner reference may change','CanonicalDJE compilation-only inventory status with legacy source-audit debt; GPD oldstatus preserved; no fresh parent sourceV','Actual officialwrapper immutable source/commands/rawlog compatibility guards, root explicit current helperhash authorization and exactlyone mechanical parking API guard unchanged'],'actual_proposed_helper_imports_or_executions':0,'actual_shared_writes_build_site_browser_API_or_ledger_mutations':0,'actual_new_local_acceptance_or_parking_authorization':False,'next_root_action':'Review/apply exact2shared supplement and exact5private helper after payloads only when explicitly authorized. Freeze new immutable core and run real finalgates/site/graph; current parentnode remains required by unchanged Chrome checker. Later acceptance/parking need fresh root contexts and this updated manifest/script hashes.'}
reportpath=O/'conditional-helper-overlays-review.json';reportpath.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
for path,raw in before.items():assert (R/path).read_bytes()==raw
print(json.dumps({'review_sha256':sha(reportpath.read_bytes()),'updated_manifest_sha256':sha(manifestpath.read_bytes()),'common_proposed_after_sha256':sha(current[commonpath]),'park_proposed_after_sha256':sha(current[parkpath]),'updated_archive_sha256':sha(tarraw),'held_original_graph_sha256':graphsha,'changed_helper_paths':len(changed),'actual_updated_helper_executions':0,'all_live_original_helpers_unchanged':True},indent=2))
