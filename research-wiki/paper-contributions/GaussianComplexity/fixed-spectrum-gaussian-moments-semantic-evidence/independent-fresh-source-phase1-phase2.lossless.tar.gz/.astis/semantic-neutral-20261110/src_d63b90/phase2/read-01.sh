python3 - <<'PY'
from pathlib import Path
import hashlib
p=Path('.astis/semantic-neutral-20261110/src_d63b90/phase2-inputs/selective-input.json')
b=p.read_bytes();h=hashlib.sha256(b).hexdigest();assert h=='42970541548f93e09cb5f099017ef2015c75e3c7a80ce7aa9cedbdbc350b1ed6'
print('raw_sha256',h)
print(b.decode())
PY
