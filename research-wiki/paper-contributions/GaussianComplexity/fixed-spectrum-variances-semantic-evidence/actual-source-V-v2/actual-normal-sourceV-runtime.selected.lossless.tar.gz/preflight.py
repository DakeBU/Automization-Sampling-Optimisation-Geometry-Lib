from pathlib import Path
import os, sys, json, hashlib, subprocess, datetime, tarfile, traceback

os.environ['PYTHONDONTWRITEBYTECODE']='1'
sys.dont_write_bytecode=True
ROOT=Path('/Users/zhouhuanjian/ASTIS-GC')
OUT=Path(__file__).resolve().parent
BASE=OUT.parent
sys.path.insert(0,str(ROOT))
from tools import astis_advance as advance
from tools import astis_publication as publication

ACTOR='/root/source_reader_c24a61'
SAU='ASTIS-SA-20261110-GaussianComplexityFixedSpectrumVariances'
DECL='AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumVariances.actual_diagonal_gaussian_quadratic_variances'
HEAD='93d302689aaaebe28dcbe39b155d2168f269a7c8'
CELL='research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-variances.json'
LEDGER=ROOT/'runs/substantive_advances.jsonl'
sha=lambda b:hashlib.sha256(b).hexdigest()
canonical=lambda x:sha(json.dumps(x,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode())
def put(name,value):
    (OUT/name).write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n')

start=datetime.datetime.now(datetime.timezone.utc).isoformat()
result={'command':[sys.executable,str(Path(__file__).relative_to(ROOT))],
        'cwd':str(ROOT),'start_utc':start,'actor':ACTOR,'advance_id':SAU,
        'native_or_build_rerun':False,'normal_transition_call_made':False}
try:
    assert not (OUT/'preflight-result.json').exists()
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip()==HEAD
    assert sha((BASE/'phase3/FREEZE.json').read_bytes())=='ab4a3912822eee2d9c912b651644822b2e3bb15f18df8f544502bce66da270ea'
    assert sha((BASE/'execution-binding/FREEZE.json').read_bytes())=='9a992aa7bcde868dfc1947f62991ac80bd3e029391ef3d94376b01e479b38d04'
    raw=LEDGER.read_bytes()
    assert raw.endswith(b'\n'), 'Ledger tail not complete; no normal call permitted'
    records=[json.loads(line) for line in raw.splitlines() if line.strip()]
    states=advance._replay_advances(records)
    own=states[SAU]
    assert own['state']=='PROVED_LOCAL'
    assert own['owner_id']!=ACTOR
    assert own['publication_declarations']==[DECL]
    (OUT/'ledger-before.raw.jsonl').write_bytes(raw)
    put('all-SAU-states-before.json',states)
    put('own-SAU-before.json',own)
    frontier_paths=sorted((ROOT/'research-wiki/frontier-cells').rglob('*.json'))
    frontier_inventory=[]
    with tarfile.open(OUT/'all-frontiers-before.raw.tar.gz','w:gz') as tf:
        for path in frontier_paths:
            b=path.read_bytes()
            frontier_inventory.append({'path':path.relative_to(ROOT).as_posix(),'bytes':len(b),'sha256':sha(b)})
            tf.add(path,arcname=path.relative_to(ROOT).as_posix(),recursive=False)
    put('all-frontiers-before.inventory.json',frontier_inventory)
    own_frontier=(ROOT/CELL).read_bytes()
    assert json.loads(own_frontier)['status']=='proved_locally'
    (OUT/'own-frontier-before.raw.json').write_bytes(own_frontier)

    tracked=subprocess.check_output(['git','ls-files','-z'],cwd=ROOT).decode().split('\0')
    protected={name for name in tracked if name and
               (name.endswith('.lean') or
                (name.startswith('Libraries/') and name.endswith('.json')) or
                name in ['lean-toolchain','lake-manifest.json',
                         'research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-variances.json',
                         'website/content/declaration_lessons/huanjian-fixed-spectrum-variances.json',
                         'website/content/publications/huanjian-fixed-spectrum-variances.json'])}
    found=subprocess.check_output(['rg','--files','AutoSamplingTheory','Tests','-g','*.lean'],cwd=ROOT).decode().splitlines()
    protected.update(found)
    protected_inventory=[]
    for name in sorted(protected):
        b=(ROOT/name).read_bytes()
        protected_inventory.append({'path':name,'bytes':len(b),'sha256':sha(b)})
    put('protected-models-Registry-imports-before.json',protected_inventory)
    for name in ['runs/substantive_discoveries.jsonl']:
        b=(ROOT/name).read_bytes();(OUT/'discovery-ledger-before.raw.jsonl').write_bytes(b)

    # This is precisely the read-only reviewed publication/semantic gate the
    # normal transition itself will invoke, with the same exact target set.
    gate_start=datetime.datetime.now(datetime.timezone.utc).isoformat()
    returned=publication.check_advance([DECL],reviewed=True)
    gate_end=datetime.datetime.now(datetime.timezone.utc).isoformat()
    assert returned is None
    assert LEDGER.read_bytes()==raw
    for row in frontier_inventory:
        assert sha((ROOT/row['path']).read_bytes())==row['sha256']
    for row in protected_inventory:
        assert sha((ROOT/row['path']).read_bytes())==row['sha256']
    assert (ROOT/'runs/substantive_discoveries.jsonl').read_bytes()==(OUT/'discovery-ledger-before.raw.jsonl').read_bytes()
    result.update(status='PASS',exit_code=0,reviewed_publication_gate_return=None,
                  reviewed_publication_gate_start_utc=gate_start,
                  reviewed_publication_gate_end_utc=gate_end,
                  metadata_head=HEAD,ledger_before_sha256=sha(raw),
                  ledger_before_bytes=len(raw),ledger_record_count=len(records),
                  total_SAU_count=len(states),frontier_raw_file_count=len(frontier_inventory),
                  protected_model_Registry_import_file_count=len(protected_inventory),
                  independent_actor_differs_from_owner=True,
                  all_snapshot_bytes_preserved_by_preflight=True,
                  publication_binding_sha256='8bdbee09a451232660a793e46b50337c0e7941a8b069afe32839a23756a0a189',
                  existing_stabilizing_advances=[key for key,value in states.items() if value['state']=='STABILIZING'],
                  stabilization_prohibited=True)
except Exception as exc:
    result.update(status='FAIL',exit_code=1,exception_type=type(exc).__name__,exception=str(exc),traceback=traceback.format_exc())
result['end_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
put('preflight-result.json',result)
print(json.dumps(result,indent=2,ensure_ascii=False))
sys.exit(result['exit_code'])
