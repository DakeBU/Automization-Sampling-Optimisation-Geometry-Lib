"""Read-only independent receipt/hash/geometry checks. Does not invoke a browser."""
from pathlib import Path
import datetime as dt
import hashlib
import json
import struct

REPO = Path(__file__).resolve().parents[4]
OWN = Path(__file__).resolve().parent
RAW = REPO / '.astis/semantic-neutral-20261114/laplace_native_61e4/reader-parent-supplement-v2'
OLD = RAW.parent / 'reader-runtime-v3'

def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def load(p):
    return json.loads(Path(p).read_text())

def describe(p):
    return {'path': str(p.relative_to(REPO)), 'bytes': p.stat().st_size, 'sha256': sha(p)}

receipt = load(RAW / 'process/receipt.json')
contract = load(RAW / 'contract.v1.json')
result = load(RAW / 'actual-result.json')
assert receipt['exit_code'] == 1
assert sha(RAW / 'actual-result.json') == receipt['actual_result_sha256']
assert sha(RAW / 'contract.v1.json') == receipt['contract_sha256'] == result['contract_sha256']
assert sha(RAW / 'supplement.py') == receipt['runner_sha256'] == result['runner_sha256'] == contract['runner_sha256']
for stream in ['stdout', 'stderr']:
    p = RAW / receipt[stream]['path']
    assert p.stat().st_size == receipt[stream]['bytes']
    assert sha(p) == receipt[stream]['sha256']
stdout = load(RAW / 'process/stdout.raw')
checks = result['checks']
false = [x['name'] for x in checks if not x['pass']]
assert len(checks) == 167 and len({x['name'] for x in checks}) == 167
assert false == ['mobile-Radius-targeted-case-completed', 'mobile-Structure-targeted-case-completed']
assert stdout['checks'] == 167 and stdout['false_checks'] == false and stdout['status'] == 'FAIL'
assert stdout['actual_result_sha256'] == sha(RAW / 'actual-result.json')
assert len(result['screenshots']) == 24 == stdout['PNGs']
assert not result['page_errors'] and not result['blocked_external_requests']
assert not [x for x in result['responses'] if x['status'] >= 400]
for row in contract['inputs']:
    p = Path(row['path'])
    assert p.stat().st_size == row['bytes'] and sha(p) == row['sha256']
preview = REPO / '.astis/huanjian-gc-matrix-laplace-20261114/reader-preview-v3/preview-freeze-manifest.json'
assert sha(preview) == '9209609b560905e6cd11a69082ac4bdb89e752a66fe3e99ba38e17508d2103b7'
old_manifest = OLD / 'presentation-selected-originals.manifest.v1.json'
assert sha(old_manifest) == '3cea83cd0e61df11cba9ab36dca51f1f64c79b18df1238b836d8f9c05f301451'
old_leaves = load(old_manifest)['leaves']
assert len(old_leaves) == 356
for row in old_leaves:
    p = OLD / row['path']
    assert p.stat().st_size == row['bytes'] and sha(p) == row['sha256']

expected_sources = {
    'AutoSamplingTheory/TechnicalLemmas/Probability/MatrixLaplaceTail.lean': '4924fede99548f6aab4f63605d2beed9dc435d6338a61d89ee301d9e83733749',
    'Tests/GaussianComplexityLaplaceTail.lean': '9ecf723f0487ddf50cb1d7c3102ebc04b58c472e56d2b16b186d91bc91cc6aac',
    'AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumSourceMatrixRadius.lean': 'b81c079a78e08325cea951c38a62520e3c5dea19309673f02e050009d3483d31',
    'AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumSourceMatrixStructure.lean': 'b1d08b92b84b3d1b6d8fc53ebad7b991d9aa99ccfd955d51b96f3e2db52dfff6',
}
for name, digest in expected_sources.items():
    assert sha(REPO / name) == digest

start = dt.datetime.fromisoformat(receipt['started_utc']).timestamp()
end = dt.datetime.fromisoformat(receipt['ended_utc']).timestamp()
images = []
for row in result['screenshots']:
    p = RAW / row['path']
    assert sha(p) == row['sha256']
    data = p.read_bytes()
    assert data[:8] == b'\x89PNG\r\n\x1a\n'
    width, height = struct.unpack('>II', data[16:24])
    assert start <= p.stat().st_mtime <= end
    images.append({**describe(p), 'runtime_relative_path': row['path'], 'width': width, 'height': height, 'mtime_within_actual_process_window': True})
assert {x['path'] for x in result['screenshots']} == {str(p.relative_to(RAW)) for p in (RAW / 'output').glob('*.png')}
(OWN / 'all_actual_PNGs.manifest.json').write_text(json.dumps({'count': 24, 'unique_byte_hashes': len({x['sha256'] for x in images}), 'images': images}, indent=2) + '\n')

def rect_intersection(a, b):
    left, right = max(a['left'], b['left']), min(a['right'], b['right'])
    top, bottom = max(a['top'], b['top']), min(a['bottom'], b['bottom'])
    return max(0, right-left)*max(0, bottom-top)

case_rows = []
for c in result['cases']:
    g = c['final_node_geometry']
    s, v = g['svg'], g['viewport']
    clip = {'left': max(0, s['left']), 'right': min(v['width'], s['right']),
            'top': max(g['headerBottom']+8, s['top']), 'bottom': min(v['height']-8, s['bottom'])}
    # The recorded ancestors' client edges coincide with their inner box edges in
    # these four cases. The final SVG area is strictly inside the other ancestors.
    for a in g['clipAncestors']:
        if a['overflowX'] in ['hidden', 'clip', 'scroll', 'auto']:
            clip['left'] = max(clip['left'], a['rect']['left'])
            clip['right'] = min(clip['right'], a['rect']['right'])
        if a['overflowY'] in ['hidden', 'clip', 'scroll', 'auto']:
            clip['top'] = max(clip['top'], a['rect']['top'])
            clip['bottom'] = min(clip['bottom'], a['rect']['bottom'])
    assert all(abs(clip[k]-g['clip'][k]) < 0.01 for k in clip)
    n, t = g['node'], g['labelRect']
    node_ratio = rect_intersection(n, clip)/(n['width']*n['height'])
    label_ratio = rect_intersection(t, clip)/(t['width']*t['height'])
    assert abs(node_ratio-1) < 1e-9 and abs(label_ratio-1) < 1e-9
    assert g['effectiveFontPx'] >= 12
    assert any('native_pointer_pan' in x for x in c['interactions'])
    assert any('native_wheel' in x for x in c['interactions'])
    crop = {'x': clip['left']+g['scroll']['x'], 'y': clip['top']+g['scroll']['y'],
            'width': clip['right']-clip['left'], 'height': clip['bottom']-clip['top']}
    if c['label'].startswith('mobile'):
        assert c['status'] == 'RUNTIME_MEASUREMENT_FAILED' and 'outside the resulting image' in c['exception']
        assert 'detail_regions' not in c
        assert crop['y'] > v['height']
    else:
        assert c['status'] == 'PASS' and len(c['detail_regions']) == 5
    case_rows.append({'label': c['label'], 'recorded_case_status': c['status'], 'viewport': v,
                      'independently_recomputed_clip': clip, 'node_fraction': node_ratio,
                      'rendered_core_label_fraction': label_ratio, 'effective_font_px': g['effectiveFontPx'],
                      'rendered_core_label': g['label'], 'native_interactions': len(c['interactions']),
                      'completed_detail_regions': len(c.get('detail_regions', [])),
                      'buggy_clip_argument_from_runner_line133': crop,
                      'buggy_crop_begins_below_viewport': crop['y'] > v['height']})

old_checks = load(OLD / 'browser-output-v1/candidate/actual-checks.json')['checks']
reuse_names = [f'mobile-parent-{i}-{suffix}' for i in [1, 2] for suffix in ['actual-selected-node', 'exact-local-reader-or-source-link', 'actual-parent-navigation']]
reuse_names += [f'mobile-{parent}-{suffix}' for parent in ['Radius', 'Structure'] for suffix in ['complete-source-exact', 'complete-source-lines', 'anchor-below-mobile-header', 'actual-copy-complete-source-byte-exact', 'module-download-exact']]
reuse = [x for x in old_checks if x['name'] in reuse_names]
assert len(reuse) == len(reuse_names) and all(x['pass'] for x in reuse)
summary = {
    'reviewer': '/root/laplace_fresh_source_8d2a',
    'method': 'Read-only local hash/receipt/recorded-geometry recomputation; no browser/API/Git/source/fixture mutation.',
    'receipt': describe(RAW / 'process/receipt.json'), 'raw_result': describe(RAW / 'actual-result.json'),
    'actual_process_exit': receipt['exit_code'], 'actual_checks': len(checks), 'actual_false_checks': false,
    'PNG_count': len(images), 'PNG_unique_byte_hashes': len({x['sha256'] for x in images}),
    'PNG_all_mtimes_inside_actual_process': True, 'contract_input_hashes_rechecked': len(contract['inputs']),
    'old356_leaf_hashes_rechecked_unchanged': len(old_leaves), 'current_source_hashes': expected_sources,
    'preview_manifest': describe(preview), 'cases': case_rows,
    'v1_already_accepted_mobile_navigation_and_source_checks_rechecked': reuse,
    'no_claim_failed_run_passed': True,
    'native_verdict_inherited': False,
}
(OWN / 'independent_actual_chain_checks.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({'exit_preserved': receipt['exit_code'], 'checks': len(checks), 'false_checks': false,
                  'PNGs': len(images), 'old356_unchanged': True, 'contract_inputs_unchanged': len(contract['inputs']),
                  'all_four_independent_node_label_clip_ratios': [[x['label'], x['node_fraction'], x['rendered_core_label_fraction']] for x in case_rows]}, indent=2))
