from pathlib import Path
import re, html, hashlib, json, datetime, shutil

ROOT=Path('/Users/zhouhuanjian/ASTIS-GC')
BASE=ROOT/'.astis/semantic-neutral-20261112/mm_sg_61c4'
OUT=BASE/'raw-freeze-v1'
SOURCE=ROOT/'.astis/huanjian-resume-20261103/2610.20492v1.html'
B=SOURCE.read_bytes();S=B.decode('utf-8')
def sha(b):return hashlib.sha256(b).hexdigest()
assert len(B)==951991 and sha(B)=='6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
assert not OUT.exists(),'Never overwrite a frozen raw reading.'
def element(id):
    m=re.search(r'<([A-Za-z][\w:]*)\b[^>]*\bid="'+re.escape(id)+r'"[^>]*>',S);assert m,id
    depth=1
    for n in re.finditer(r'</?'+re.escape(m[1])+r'\b[^>]*>',S[m.end():]):
        depth+=-1 if n[0].startswith('</') else 1
        if depth==0:return m.start(),m.end()+n.end()
    raise ValueError(id)
def plain(a,z):
    fs=[]
    def replace(m):fs.append(html.unescape(m[1]));return ' MATH'+str(len(fs)-1)+'END '
    t=re.sub(r'<math\b[^>]*alttext="([^"]*)"[^>]*>.*?</math>',replace,S[a:z],flags=re.S)
    t=re.sub(r'</(?:p|div|table|tbody|h[1-6])>','\n',t)
    t=html.unescape(re.sub(r'<[^>]+>','',t))
    t=re.sub(r'MATH(\d+)END',lambda m:'$'+fs[int(m[1])]+'$',t)
    return re.sub(r'\n\s*\n+','\n',t).strip()
def locator(a,z):
    x=len(S[:a].encode());y=len(S[:z].encode())
    return {'utf8_byte_start':x,'utf8_byte_end_exclusive':y,
     'unicode_char_start':a,'unicode_char_end_exclusive':z,
     'lf_line_start_1based':S.count('\n',0,a)+1,'lf_line_end_1based':S.count('\n',0,z-1)+1,
     'raw_fragment_sha256':sha(B[x:y])}
OUT.mkdir();(OUT/'inputs').mkdir();(OUT/'source-fragments').mkdir()
def dump(name,v):(OUT/name).write_text(json.dumps(v,ensure_ascii=False,sort_keys=True,indent=2)+'\n',encoding='utf-8')
def write(name,t):(OUT/name).write_text(t,encoding='utf-8')
task='''Separate prospective next packet, RAW SOURCE READING ONLY now; R7 remains under independent normal verification. New directory .astis/semantic-neutral-20261112/mm_sg_61c4. Do not read new implementation/API/audits (none exist), old review verdicts or other graphs. Pinned raw .astis/huanjian-resume-20261103/2610.20492v1.html sha6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915. Read C.2 p1–p12 original region, focus on actual original-column experiment, Ex107 Yi, its mean a/d(I⊗ti tiᵀ), and two exact mean sums aI/0 using source Fact C.5. Proposed new packet is actual source-family first-moment transport, with a real private two-sum expectation consumer. Scope q0, only2q+1<d, sameΩμ, original closed cutoff and Gaussian-first tensor order; no ambient transfer/conditioning, no caller moment/integrability hypotheses. This is ONLY prose target selection, not a Statement Seal or admitted graph. Freeze raw exhaustive atoms/locators/coverage independently; preserve all oldR7 artifacts untouched. Before exact final seal and binder/definition packet arrives, do not accept or formalize any type/graph/topology. You may record clearly unaccepted raw notes/ports; no claimed closed proofs. Return exact raw freeze hashes. No tracked C/L/Git/shared changes.'''
write('inputs/task-envelope.txt',task+'\n')
protocols=['AGENTS.md','CONTRIBUTING.md','.agents/prompts/collaborator-contribution.md',
 'docs/contributor-codex-contract.md','docs/theorem-publication-protocol.md',
 'docs/proof-digestion-protocol.md','docs/evidence-routed-memory-protocol.md',
 '.agents/skills/astis-substantive-advance/SKILL.md',
 '.agents/skills/astis-semantic-roundtrip/SKILL.md','.agents/prompts/samplewiki-route.md']
inputs=[]
for name in protocols:
    b=(ROOT/name).read_bytes();dest='inputs/'+name.replace('/','__');(OUT/dest).write_bytes(b)
    inputs.append({'path':name,'snapshot':dest,'bytes':len(b),'sha256':sha(b),'role':'Current process protocol; already read in this actor run, rehashed/snapshotted for this raw phase. No theorem evidence.'})
(OUT/'inputs/2610.20492v1.html').write_bytes(B)
inputs.append({'path':str(SOURCE.relative_to(ROOT)),'snapshot':'inputs/2610.20492v1.html','bytes':len(B),'unicode_characters':len(S),'LF_count':S.count('\n'),'sha256':sha(B),'role':'Pinned original source; only bounded region and standing/grid context interpreted.'})
shutil.copyfile(BASE/'working/build_raw_freeze.py',OUT/'inputs/build_raw_freeze.py')

units={};items=[]
def unit(id):
    if id not in units:
        a,z=element(id);units[id]={'locator':locator(a,z),'text':plain(a,z),'atom_ids':[]}
        (OUT/'source-fragments'/f'{id}.raw.html').write_bytes(S[a:z].encode())
    return units[id]
def atom(id,anchor,disposition,kind,meaning,reason=None,slice=None):
    u=unit(anchor);obj={'id':id,'source_element_id':anchor,'locator':u['locator'],'disposition':disposition,
     'kind':kind,'meaning':meaning,'status':'RAW_SOURCE_READING_UNACCEPTED_NO_STATEMENT_SEAL'}
    if reason:obj['reason']=reason
    if slice:obj['semantic_slice']=slice
    items.append(obj);u['atom_ids'].append(id)
def n(id,a,k,m,slice=None):atom(id,a,'NODE',k,m,slice=slice)
def x(id,a,k,m,r,slice=None):atom(id,a,'EXCLUDED',k,m,r,slice)

# Minimal source-standing and literal-grid context, separate from the C.2 window.
x('standing.C','S4.Thmtheorem4.p1.1','theorem quantifier','There is an absolute C>0.','Concentration/uniform-bound constant is outside the selected first-moment packet.','First sentence')
n('standing.naturals-and-range','S4.Thmtheorem4.p1.1','standing source range','Natural dimension d and nonnegative integer query count q, with 2q+1<d; q=0 retained.','q and range clause; natural typing follows source dimension/query-count convention and assigned scope')
n('experiment.independent-standard-columns','S4.Thmtheorem4.p1.1','source experiment','g_1,...,g_(q+1) are independent N(0,I_d) vectors.','Column-experiment clause')
x('standing.K-alias','S4.Thmtheorem4.p1.1','source notation','K_q=K_q(g_1,...,g_(q+1)).','No Krylov result is selected.','Final alias clause')
n('grid.theta','S4.E11.m1','literal source definition','theta_i=(i-1/2)pi/d, i=1,...,d.','theta clause')
x('grid.lambda-and-Lambda','S4.E11.m1','source definitions','Affine eigenvalues lambda_i and diagonal Lambda.','No spectral, kappa or Krylov input is needed by the selected means.','lambda and Lambda clauses')

n('c2.r','A3.SS2.p1.1','source definition','r=q+1.','r clause')
n('c2.n','A3.SS2.p1.1','source definition','n=2q+1.','n clause')
n('c2.physical-index','A3.SS2.p1.1','typing context','1<=i<=d.','physical row index clause')
n('c2.literal-t','A3.Ex85','literal source definition','t_i=(1,sqrt(2)cos(theta_i),...,sqrt(2)cos(q theta_i))^T.','t clause')
n('c2.actual-gamma','A3.Ex85','literal source definition','gamma_i=((g_1)_i,...,(g_r)_i)^T, from the same original column sample.','gamma clause')
x('c2.joint-row-independence','A3.SS2.p1.2','unnamed source claim','The full row family gamma_1,...,gamma_d is independent.','First-moment transport and finite expectation linearity do not need joint independence. R7 is not re-audited or credited here.','First sentence independence clause')
n('c2.row-marginal-law','A3.SS2.p1.2','unnamed source law claim','Each gamma_i has law N(0,I_r).','First sentence Gaussian-law clause')
n('c2.B-normalization-context','A3.SS2.p1.2','source definition context','B in R^(d x r^2) has i-th row d^(-1/2)(gamma_i tensor t_i)^T.','Second sentence; tensor order and normalization context only')
x('strategy.norm','A3.SS2.p2.1','substantive proof strategy','Write u=Bc and control ||u||^2 through B^T B.','No Krylov/norm theorem is selected.')
x('strategy.weighted-form','A3.SS2.p2.1','substantive proof strategy','Control u^T D_n u through B^T D_n B.','No quadratic form/uniform lower-bound theorem is selected.')
x('strategy.concentration','A3.SS2.p2.1','substantive proof strategy','Use range, untruncated expectations and concentration to obtain a uniform bound.','Only actual truncated Y first moments and exact sums are prospective targets.')
for id,m in [('range','range(B)=K_q'),('B-mean','E[B^T B]=I_(r^2)'),('weighted-B-mean','E[B^T D_n B]=0')]:
 x('c5.'+id,'A3.Ex86','Fact C.5 conclusion',m,'These untruncated B claims are not the actual-Y first-moment target or required deterministic sum identity.',id+' clause')
x('c5.t-norm-bound','A3.Ex87','Fact C.5 estimate','||t_i||^2<=2r.','The norm estimate is not required to state the exact means; deterministic finite t suffices for the internal integrability port.','First clause')
n('c5.t-Gram','A3.Ex87','Fact C.5 exact identity','sum_i t_i t_i^T=d I_r.','Second clause')
n('c5.weighted-t-Gram','A3.Ex87','Fact C.5 exact identity','sum_i cos(n theta_i)t_i t_i^T=0.','Third clause')
x('c5.range-proof','A3.SS2.p3.1','substantive proof paragraph','Chebyshev polynomial change of basis, nonzero leading coefficient and invertible triangular basis map.','No range/Krylov or spectral theorem is selected.')
x('c5.B-mean-subgoal','A3.SS2.p4.1','proof subgoal','Boxed E[B^T B]=I_(r^2).','Only the deterministic cosine identities within this proof are needed for the prospective actual-Y consumer.','First boxed clause')
n('c5.theta-recall','A3.SS2.p4.m2','reused source definition','theta_i=(i-1/2)pi/d.')
n('c5.frequency-domain','A3.SS2.p4.1','proof-domain condition','Integer k with 0<|k|<2d.','Final clause')
n('c5.cosine-telescope','A3.Ex88','substantive display step','2sin(k pi/(2d)) sum_i cos(k theta_i) equals a telescoping sine difference sum.')
n('c5.cosine-endpoints','A3.Ex89','substantive display step','The sine difference sum is sin(k pi)-sin0=0.')
n('c5.cosine-zero','A3.SS2.p4.2','unnamed identity/proof step','The sine factor is nonzero, so sum_i cos(k theta_i)=0.')
n('c5.feature-index','A3.SS2.p5.1','typing context','t_i coordinates are indexed by 0,...,q.','First sentence')
n('c5.constant-coordinate-sum','A3.Ex90','reused exact identity','sum_i (t_i)_0^2=d.','First clause')
n('c5.mixed-coordinate-sum','A3.Ex90','reused exact identity','sum_i (t_i)_0(t_i)_j=sqrt(2)sum_i cos(j theta_i)=0 for 1<=j<=q.','Second clause')
n('c5.product-to-sum-invocation','A3.SS2.p5.2','substantive proof step','For 1<=j,k<=q apply the product-to-sum identity.')
n('c5.positive-feature-product','A3.Ex91','substantive display step','sum_i(t_i)_j(t_i)_k=2sum_i cos(j theta_i)cos(k theta_i).')
n('c5.frequency-split','A3.Ex92','substantive display step','The product sum is sum_i cos((j-k)theta_i)+sum_i cos((j+k)theta_i).')
n('c5.diagonal-offdiagonal','A3.Ex93','substantive display step','The result is d if j=k, otherwise 0.')
n('c5.frequency-check-and-Gram','A3.SS2.p5.3','substantive proof paragraph','Check 0<j+k<=2q<2d and j-k=0 exactly on the diagonal; symmetry covers all entries, hence sum_i t_i t_i^T=d I_r.')
x('c5.untruncated-Gaussian-second-moment','A3.SS2.p6.1','unnamed estimate/proof input','E[gamma_i gamma_i^T]=I_r, then use the B row definition.','The selected exact truncated moment is Ex108; no untruncated second-moment premise or new target is imported here.')
for id,m in [('A3.Ex94','Expected B Gram as a sum of expected Gaussian outer products tensor t Gram'),('A3.Ex95','Tensor factorization produces I_(r^2)')]:
 x('c5.'+id,id,'substantive display step',m,'Untruncated B means are outside the prospective actual-Y target.')
x('c5.weighted-B-subgoal','A3.SS2.p7.1','proof subgoal','Boxed E[B^T D_n B]=0.','The deterministic weighted t identity is selected separately; the B mean is not.','First boxed clause')
n('c5.n-domain-context','A3.SS2.p7.1','reused definition/proof premise','n=2q+1 and 0<=j,k<=q.','Following clause')
n('c5.weighted-frequency-range','A3.Ex96','substantive source estimate','1<=n-j-k<=n±j±k<=n+j+k<=4q+1<2d.')
n('c5.invoke-cosine-zero','A3.SS2.p7.2','substantive proof step','Apply the earlier cosine-sum identity.')
n('c5.triple-cosine-sum','A3.Ex97','reused display','sum_i cos(n theta_i)cos(j theta_i)cos(k theta_i).')
n('c5.four-frequencies','A3.Ex98','substantive display step','Product-to-sum gives one quarter of four cosine sums at n±j±k.')
n('c5.weighted-cosine-zero','A3.Ex99','substantive display step','The four-frequency sum is zero.')
n('c5.weighted-Gram-entry-conclusion','A3.SS2.p7.3','substantive proof paragraph','Each entry of the weighted t Gram is a constant multiple of such a sum, so sum_i cos(n theta_i)t_i t_i^T=0.','First sentence, before Consequently')
for id,m in [('A3.Ex100','Expected weighted B Gram expressed using Gaussian outer-product means'),('A3.Ex101','Tensor factorization yields zero')]:
 x('c5.'+id,id,'substantive display step',m,'Untruncated weighted B means are outside the selected actual-Y target.')
x('c5.t-norm-proof','A3.Ex102','unnamed estimate','||t_i||^2=1+2sum_(j=1)^q cos^2(j theta_i)<=1+2q<=2r.','A uniform deterministic t-norm bound is not a required new target/input for exact mean transport.')
x('c6.strategy','A3.SS2.p9.1','substantive proof strategy','Operator norm deviations control every coefficient vector.','No concentration claim is selected.')
x('c6.constant-and-probability','A3.Thmtheorem6.p1.1','Fact C.6 statement','For sufficiently large absolute C, probability at least 0.995.','No concentration probability or C is selected.')
x('c6.concentration','A3.Ex103','Fact C.6 conclusion','Two operator-norm deviations are <=tau_(d,q).','No concentration statement is selected.')
n('cutoff.L','A3.SS2.p10.m1','literal source definition','L=2r+3log(1000d).')
n('cutoff.R','A3.SS2.p10.m2','literal source definition','R_i=||gamma_i||^2.')
x('cutoff.exponential-moment','A3.SS2.p10.m3','unnamed estimate','E exp(R_i/3)=3^(r/2).','No exponential moment/tail probability is needed for the selected exact mean identities.')
x('cutoff.Markov','A3.SS2.p10.1','substantive proof invocation','Markov inequality for x>=0.','Tail proof is excluded.','Final clause')
x('cutoff.tail','A3.Ex104','unnamed estimate','P(R_i>2r+3x)<=exp((r/2)log3-2r/3-x)<=exp(-x).','No tail bound or event probability is selected.')
x('cutoff.log-bound','A3.SS2.p10.2','unnamed constant estimate','(log3)/2<2/3 and transition to a common event.','Tail constant proof is excluded.')
x('cutoff.common-event','A3.Ex105','source event definition','T={R_i<=L for every i}.','Actual Y uses only its own local closed cutoff. No conditioning on T or common-event replacement is allowed.')
x('cutoff.common-event-probability','A3.SS2.p10.3','unnamed probability estimate','P(T)>=0.999.','No truncation event probability is selected.')
x('bias.shifted-tail','A3.SS2.p11.1','unnamed estimate','P(R_i>L+s)<=exp(-s/3)/(1000d).','The discarded-tail bias bound is outside the exact-mean transport packet.')
x('bias.integrated-tail','A3.Ex106','unnamed estimate/display','E[R_i 1_(R_i>L)]<= (L+3)/(1000d), via layer cake.','No bias/error bound is selected.')
x('Yi.independence-claim','A3.SS2.p12.1','unnamed source independence claim','Define the independent truncated matrices.','This prospective packet selects first moments only; no new independence theorem, R7 status or independence premise is claimed.')
n('Yi.actual-definition','A3.Ex107','literal source definition','Y_i=(1/d)(gamma_i gamma_i^T tensor t_i t_i^T)1_(R_i<=L).')
n('mean.radial-symmetry-invocation','A3.SS2.p12.2','substantive proof invocation','By radial symmetry.')
n('mean.truncated-row-outer-product','A3.Ex108','unnamed exact source moment','E[gamma_i gamma_i^T 1_(R_i<=L)]=a I_r.','First clause')
n('mean.literal-a','A3.Ex108','source scalar definition','a=(1/r)E[R_i 1_(R_i<=L)].','Second clause')
n('mean.a-common','A3.SS2.p12.3','unnamed source law consequence','The scalar a is the same for every i.','First sentence')
x('bias.untruncated-radius-mean','A3.SS2.p12.3','unnamed moment','E R_i=r.','Only used in the following omitted bias comparison; no untruncated moment premise is imposed.','Second sentence first clause')
x('bias.a-range','A3.SS2.p12.3','unnamed estimate','0<=a<=1.','Scalar bias/range bound is outside the selected exact identity target.','Second sentence second clause')
x('bias.loss-bound','A3.Ex109','unnamed estimate','1-a=(1/r)E[R_i 1_(R_i>L)]<= (L+3)/(1000rd).','No loss/bias estimate is selected.')
n('mean.actual-Y','A3.SS2.p12.4','unnamed exact source mean','E Y_i=(a/d)(I_r tensor t_i t_i^T).','First sentence')
n('mean.FactC5-use','A3.SS2.p12.4','explicit source consumer use','Fact C.5 therefore gives the two following exact mean sums.','Second sentence')
n('consumer.sum-means','A3.Ex110','exact source display','sum_i E Y_i=a I_(r^2).','First clause')
n('consumer.weighted-sum-means','A3.Ex110','exact source display','sum_i cos(n theta_i)E Y_i=0.','Second clause')
n('consumer.weighted-expectation-conclusion','A3.SS2.p12.5','unnamed source conclusion','The truncated weighted sum has zero expectation.')

# Every p/display in the continuous original C.2 p1-through-p12 window has a disposition.
wa,_=element('A3.SS2');_,wz=element('A3.SS2.p12')
coverage=[]
for m in re.finditer(r'<(p|table)\b[^>]*\bid="([^"]+)"[^>]*>',S[wa:wz]):
    id=m[2];a,z=element(id);txt=plain(a,z)
    atoms=[v['id'] for v in items if v['source_element_id']==id]
    if id=='A3.SS2.p4.1':atoms.append('c5.theta-recall')
    if id=='A3.SS2.p10.1':atoms+=['cutoff.L','cutoff.R','cutoff.exponential-moment']
    if id=='A3.SS2.p8.1':atoms=['c5.t-norm-proof'];note='Pure connective Finally; estimate is adjacent Ex102.'
    elif txt=='∎':atoms=[];note='Proof-end punctuation only.'
    elif id=='A3.Thmtheorem5.p1.1':atoms=['c5.range','c5.B-mean','c5.weighted-B-mean'];note='Statement connective; all claims atomized in Ex86.'
    elif id=='A3.Thmtheorem5.p1.2':atoms=['c5.t-norm-bound','c5.t-Gram','c5.weighted-t-Gram'];note='Statement connective; all claims atomized in Ex87.'
    elif not atoms:
        for v in items:
            if v['source_element_id'].startswith('A3.Ex'):
                aa,zz=element(v['source_element_id'])
                if a<=aa and zz<=z:atoms.append(v['id'])
        note='Display container covered by the individual atomic display rows.'
    else:note='Every substantive clause covered; remaining text is connective prose.'
    assert atoms or txt=='∎',id
    coverage.append({'element_id':id,'locator':locator(a,z),'atom_ids':list(dict.fromkeys(atoms)),'note':note})

dump('atomic-inventory.json',{'phase':'RAW_PROSE_TARGET_SELECTION_ONLY','status':'UNACCEPTED_NO_STATEMENT_SEAL_NO_ADMITTED_GRAPH','scope':'Continuous original Appendix C.2 opening through p12 end, plus only S4.Thmtheorem4.p1.1 and S4.E11.m1 standing/experiment/grid context.','items':items,
 'counts':{'atoms':len(items),'NODE':sum(v['disposition']=='NODE' for v in items),'EXCLUDED':sum(v['disposition']=='EXCLUDED' for v in items)}})
dump('locators-and-source-units.json',{'source_sha256':sha(B),'convention':'Zero-based half-open UTF-8 byte/Unicode-codepoint intervals; LF lines one-based inclusive; hashes cover exact unnormalized raw fragments. Shared parent locators have explicit semantic_slice clauses.','source_units':units})
dump('coverage.json',{'phase':'RAW_ONLY_UNACCEPTED','continuous_window':{'char_start':wa,'char_end_exclusive':wz,'locator':locator(wa,wz)},'units':coverage,'unit_count':len(coverage),
 'all_substantive_units_disposed':True,'not_a_review_verdict':'Mechanical source-unit coverage shape only; independent mathematical topology/coverage acceptance is not claimed.',
 'whole_paper_or_whole_Lemma44_coverage':False,'outside_window_exclusions':[
 {'topic':'p13 onward PSD, centered variance, concentration and uniform/main lower bounds','reason':'Outside this bounded reading and first-moment packet; no proof or source coverage is claimed.'},
 {'topic':'Original arbitrary extended-ambient/algorithm-output transfer','reason':'The selected canonical original-column family is fixed; no coupling/ambient extension result is selected.'}]})

notes=[
 {'id':'RAW_PORT.physical-row-law','meaning':'Transport each actual original-column row gamma_i to the source N(0,I_r) marginal law, with actual row measurability, under the same canonical product experiment.','source_anchors':['A3.SS2.p1.2'],'not_required':'Full joint row independence is not needed for any first-moment identity.'},
 {'id':'RAW_PORT.truncated-moment-well-defined','meaning':'Establish measurability and integrability of the actual truncated row outer-product and scalar radius functions and of Y_i internally. No caller moment/integrability hypothesis is permitted.','source_anchors':['A3.Ex107','A3.Ex108'],'route_note':'Bounded local truncation is a possible source-supported inference; Gaussian finite moments are another possible integrability route. These are alternatives, not an AND requirement or closed proof.'},
 {'id':'RAW_PORT.radial-mean-and-common-a','meaning':'Justify the source radial-symmetry outer-product identity and common scalar a, then transport it from the standard r-Gaussian law to each physical row. If a canonical-law scalar is used later, identify it with the literal source (1/r)E[R_i 1_(R_i<=L)].','source_anchors':['A3.SS2.p12.2','A3.Ex108','A3.SS2.p12.3'],'boundary':'No caller-provided matrix-mean, a, or law certificate may substitute for the actual original-column mean.'},
 {'id':'RAW_PORT.tensor-mean-transport','meaning':'Pull deterministic t_i t_i^T and inverse d through the finite real-entry matrix expectation, preserving Gaussian-first paired indices and the exact closed local cutoff; obtain actual E Y_i=(a/d)(I_r tensor t_i t_i^T).','source_anchors':['A3.Ex107','A3.SS2.p12.4'],'boundary':'Do not replace Y_i by an independent surrogate, condition on T, or change the probability experiment.'},
 {'id':'RAW_PORT.literal-grid-C5','meaning':'Instantiate both exact deterministic Fact C.5 identities for the literal half-grid/features with r=q+1 and n=2q+1. All source frequency-range checks must apply, including q=0.','source_anchors':['A3.Ex87','A3.SS2.p4','A3.SS2.p5','A3.SS2.p7'],'boundary':'The B-moment and range claims of Fact C.5 are not required as parents.'},
 {'id':'RAW_PORT.two-sum-algebra','meaning':'Combine the actual per-row mean with sum_i t_i t_i^T=dI_r and sum_i cos(n theta_i)t_i t_i^T=0 to obtain exactly the two Ex110 sums of expectations.','source_anchors':['A3.SS2.p12.4','A3.Ex110'],'boundary':'The source Fact C.5 use is direct at this consumer site; it is not an inference of source topology from Lean.'},
 {'id':'RAW_PORT.expectation-of-actual-sums','meaning':'For a prospective private consumer phrased as expectations of the actual unweighted and weighted finite Y sums, derive required integrability and finite expectation linearity internally, including deterministic cosine weights. Distinguish E[sum_i Y_i] and E[sum_i cos(n theta_i)Y_i] from the displayed sum_i E Y_i and sum_i cos(n theta_i)E Y_i.','source_anchors':['A3.Ex110','A3.SS2.p12.5'],'boundary':'No independence assumption is required for finite expectation linearity.'}]
dump('unaccepted-raw-ports.json',{'status':'RAW_NOTES_ONLY_UNPROVED_NO_TYPES_NO_GRAPH','ports':[dict(v,status='UNPROVED_SOURCE_SUPPORTED_INFERENCE') for v in notes],
 'no_compiled_parents':True,'no_extra_source_hypotheses':True,'no_topology_acceptance':True})

dump('raw-consumer-use-observations.json',{'status':'UNACCEPTED_PROSE_OBSERVATIONS_ONLY_NOT_A_GRAPH',
 'observations':[
 {'source_use':'A3.SS2.p12.2 / A3.Ex108','reading':'The author invokes radial symmetry for the actual row truncated outer-product expectation and defines a from its radius.','source_items':['mean.radial-symmetry-invocation','mean.truncated-row-outer-product','mean.literal-a']},
 {'source_use':'A3.SS2.p12.3','reading':'The scalar a is common across i, consistent with the common standard r-Gaussian row marginal law; joint independence is not cited for this step.','source_items':['mean.a-common','c2.row-marginal-law']},
 {'source_use':'A3.SS2.p12.4','reading':'The actual Y_i definition consumes the row moment with deterministic t_i tensor factor and inverse d.','source_items':['Yi.actual-definition','mean.truncated-row-outer-product','mean.actual-Y']},
 {'source_use':'A3.SS2.p12.4 / A3.Ex110','reading':'The explicit Fact C.5 invocation directly precedes the two exact mean sums and uses its unweighted/weighted deterministic t Gram identities.','source_items':['mean.FactC5-use','c5.t-Gram','c5.weighted-t-Gram','consumer.sum-means','consumer.weighted-sum-means']},
 {'source_use':'A3.SS2.p12.5','reading':'The weighted-sum expectation conclusion is stated after the displayed weighted sum of expectations; finite-integral linearity is omitted bookkeeping.','source_items':['consumer.weighted-sum-means','consumer.weighted-expectation-conclusion']}],
 'not_observed':'No implementation call, formal type, compiled parent, exact typed consumer or admitted dependency graph has been inspected for this prospective packet.'})

write('raw-prose-target-selection.md',r'''# Actual source-family first-moment transport: raw reading only

This new packet is prose target selection, before any exact final Statement Seal or binder/definition packet. No new type is proposed, formed, audited or admitted, and no graph/topology is accepted. All source items and omitted bridges remain raw notes. R7 and all its artifacts remain untouched and under the parent's separately reported independent normal verification.

The original source experiment has natural d,q, 2q+1<d and r=q+1 independent standard d-Gaussian columns g_a. The selected canonical realization is the same single product-column experiment, with physical rows gamma_i=((g_a)_i)_a. Each row has the source N(0,I_r) marginal law. Joint row independence is an explicit source claim in C.2 p1, but it is not an input needed for this first-moment transport or for finite expectation linearity. No new independence result or R7 admission is claimed here.

Use the literal theta_i=(i-1/2)pi/d and t_i=(1,sqrt(2)cos(theta_i),...,sqrt(2)cos(q theta_i))^T. Set n=2q+1, R_i=||gamma_i||^2 and L=2r+3log(1000d). The actual source matrix is Y_i=(1/d)(gamma_i gamma_i^T tensor t_i t_i^T)1_{R_i<=L}, with Gaussian coordinate first in each tensor paired index. The threshold includes equality and is local to i. There is no conditioning on T, common-event multiplier, independent surrogate or changed ambient probability space.

The source invokes radial symmetry and states E[gamma_i gamma_i^T 1_{R_i<=L}]=a I_r, where a=(1/r)E[R_i 1_{R_i<=L}], common to all i. A future canonical standard-r-Gaussian-law definition of a must be identified with this literal source scalar using the actual physical row laws; it cannot be free supplied data or a supplied mean certificate. Its exact typed definition remains undecided until the later seal.

The prospective per-row result is the actual original-column mean E Y_i=(a/d)(I_r tensor t_i t_i^T). All needed measurability, integrability and law/expectation transport are internal outputs or bridges. No caller moment or integrability hypothesis belongs in the eventual target. The source does not supply the detailed measurable-map, tensor integral or integrability bookkeeping; the raw ports retain these omissions without claiming proofs.

Fact C.5 provides precisely sum_i t_i t_i^T=d I_r and sum_i cos(n theta_i)t_i t_i^T=0. It explicitly becomes a consumer input at p12.4, giving the two exact Ex110 identities: sum_i E Y_i=a I_(r^2) and sum_i cos(n theta_i)E Y_i=0. The untruncated B moment, Krylov range and t norm bound are not required parents of these two exact sums. The deterministic cosine proof in p4/p5/p7 is inventoried because it supports the literal identities, including its frequency checks.

For a real private consumer phrased as two expectations of the actual finite sums, the unweighted target E[sum_i Y_i]=a I_(r^2) and weighted target E[sum_i cos(n theta_i)Y_i]=0 require finite-integral linearity after internal integrability. The source displays sums of individual expectations and then states the weighted sum has zero expectation. These statements must not be silently identified before that bridge is discharged. Independence is unnecessary for this linearity step.

The q=0 case remains in scope: r=1, n=1, t_i=(1), d>=2. The source deterministic identities reduce to sum_i 1=d and sum_i cos(theta_i)=0. The prospective matrix mean is scalar a/d; the unweighted aggregate is a and weighted aggregate zero. These are raw interpretation specializations, not closed proofs. No tau, kappa, C, positive-q condition, discarded-tail estimate, bound on 1-a, PSD/centered-variance/concentration result or main lower bound is selected.

The continuous C.2 p1-through-p12 source window is exhaustively disposed into NODE or EXCLUDED atoms with exact UTF-8 byte, Unicode-character, LF-line and raw-fragment SHA-256 locators. Shared source-element locators specify distinct semantic clauses. Numbered statements, unnamed law/moment/mean assertions and the actual downstream mean-sum use all remain visible. Later source/proof regions are outside this bounded inventory. No exact new signature/API/implementation or old verdict/other graph was read for this new raw phase.
''')

dump('input-exposure-and-protocol-record.json',{'actor':'/root/row_indep_source_graph_78c2','new_packet_output_root':str(BASE.relative_to(ROOT)),
 'new_phase_reads':['Exact pinned original HTML, semantically C.2 p1 through p12 plus S4.Thmtheorem4.p1.1 and S4.E11.m1 only.','Exact current process protocol files snapshotted here.','This new task envelope and own new files only.'],
 'prior_actor_exposure':'This same actor previously read R7 raw source, its own R7 raw/type graph artifacts and the selective R7 sealed type/definition packet. Those earlier exposures cannot be erased. They were not reopened or used as source evidence in this new mean-packet phase. No API-pristine/source-blind-decoder claim is made.',
 'new_implementation_API_audit_seen':False,'old_review_verdicts_or_other_graphs_read_this_phase':False,
 'raw_source_sha256':sha(B),'inputs':inputs,
 'task_envelope_sha256':sha((OUT/'inputs/task-envelope.txt').read_bytes()),
 'protocol_application':'Existing substantive-advance and semantic-roundtrip protocols are applied only to source-first preservation and explicit boundaries here. Exact statement seal, formal topology and any proof work are deferred per the task.',
 'not_run':['No publication/ledger/capsule/global inventory read','No Lean/API search, type elaboration or proof','No old R7 artifact read/write','No Git mutation or tracked C/L/shared/registry/ledger/status write','No new Goal or background ASTIS'],
 'authorization':'No permission, proof, source-review acceptance, topology acceptance, theorem status or publication grant.'})
write('README.md','RAW SOURCE READING ONLY, before exact Statement Seal. Start with raw-prose-target-selection.md, atomic-inventory.json, coverage.json and unaccepted-raw-ports.json. raw-consumer-use-observations.json contains prose observations only; no graph/type/topology is admitted. Prior R7 artifacts were not reopened or changed. All source/inputs/artifacts are hashed by freeze-manifest.json.\n')

manifest={'format':'astis-mean-matrix-raw-source-freeze-v1','actor':'/root/row_indep_source_graph_78c2','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'phase':'RAW_PROSE_ONLY_BEFORE_STATEMENT_SEAL','source_sha256':sha(B),'statement_seal_seen':False,'new_types_seen':False,'graph_or_topology_admitted':False,'files':[]}
for f in sorted(OUT.rglob('*')):
    if f.is_file():
        b=f.read_bytes();manifest['files'].append({'path':str(f.relative_to(OUT)),'bytes':len(b),'sha256':sha(b)})
dump('freeze-manifest.json',manifest)
digest=sha((OUT/'freeze-manifest.json').read_bytes());write('freeze-manifest.sha256',digest+'  freeze-manifest.json\n')
for f in OUT.rglob('*'):
    if f.is_file():f.chmod(0o444)
for d in sorted([d for d in OUT.rglob('*') if d.is_dir()],key=lambda d:len(d.parts),reverse=True):d.chmod(0o555)
OUT.chmod(0o555)
print(json.dumps({'freeze_path':str(OUT),'freeze_manifest_sha256':digest,'raw_interpretation_sha256':sha((OUT/'raw-prose-target-selection.md').read_bytes()),'inventory_sha256':sha((OUT/'atomic-inventory.json').read_bytes()),'coverage_sha256':sha((OUT/'coverage.json').read_bytes()),'locators_sha256':sha((OUT/'locators-and-source-units.json').read_bytes()),'ports_sha256':sha((OUT/'unaccepted-raw-ports.json').read_bytes()),'atoms':len(items),'nodes':sum(i['disposition']=='NODE' for i in items),'excluded':sum(i['disposition']=='EXCLUDED' for i in items),'continuous_units':len(coverage),'open_raw_ports':len(notes)},indent=2))
