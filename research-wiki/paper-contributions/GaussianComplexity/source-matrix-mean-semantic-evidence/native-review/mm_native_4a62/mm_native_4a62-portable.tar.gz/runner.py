#!/usr/bin/env python3
"""Own isolated verifier. All subprocesses retain exact byte streams and receipts."""
import os, sys, re, json, hashlib, subprocess, time, datetime, shutil
from pathlib import Path

REPO = Path('/Users/zhouhuanjian/ASTIS-GC')
OWN = Path(__file__).resolve().parent
CANDIDATE = '5fb1440f771bdae77ad31f27b2275447fe3e89e5'
P = 'AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumSourceMatrixMean.lean'
T = 'Tests/GaussianComplexityFixedSpectrumSourceMatrixMean.lean'
E = 'research-wiki/paper-contributions/GaussianComplexity/source-matrix-mean-semantic-evidence'
sha = lambda b: hashlib.sha256(b).hexdigest()
def save(name, x):
    p=OWN/name; p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
    return x
def run(label, argv, cwd=REPO, env=None):
    dest=OWN/'receipts';dest.mkdir(exist_ok=True)
    assert not (dest/(label+'.receipt.json')).exists(), label
    start=datetime.datetime.now(datetime.timezone.utc).isoformat()
    head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO).decode().strip()
    tic=time.monotonic()
    proc=subprocess.run([str(x) for x in argv],cwd=cwd,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    elapsed=time.monotonic()-tic
    for ext,b in [('stdout',proc.stdout),('stderr',proc.stderr)]:
        (dest/(label+'.'+ext)).write_bytes(b)
    receipt={'label':label,'argv':[str(x) for x in argv],'cwd':str(cwd),'start_utc':start,
      'start_HEAD':head,'candidate':CANDIDATE,'elapsed_seconds':elapsed,'exit_code':proc.returncode,
      'stdout':{'path':f'receipts/{label}.stdout','bytes':len(proc.stdout),'sha256':sha(proc.stdout)},
      'stderr':{'path':f'receipts/{label}.stderr','bytes':len(proc.stderr),'sha256':sha(proc.stderr)},
      'script_sha256':sha(Path(__file__).read_bytes()),
      'environment_overrides':{k:env[k] for k in ['LEAN_PATH','LEAN_SRC_PATH','LEAN_SYSROOT','PYTHONDONTWRITEBYTECODE'] if env and k in env}}
    save('receipts/'+label+'.receipt.json',receipt)
    print(label,proc.returncode,round(elapsed,3),len(proc.stdout),len(proc.stderr),flush=True)
    return proc
def must(label,argv,cwd=REPO,env=None):
    p=run(label,argv,cwd,env)
    if p.returncode: raise RuntimeError(label+': '+p.stderr.decode(errors='replace')[-600:])
    return p.stdout
def native_env():
    env=os.environ.copy()
    env['LEAN_PATH']=':'.join([str(OWN/'fresh/olean')]+[str(p) for p in sorted((REPO/'.lake/packages').glob('*/.lake/build/lib/lean'))])
    env.pop('LEAN_SRC_PATH',None);env.pop('LEAN_SYSROOT',None)
    env['PYTHONDONTWRITEBYTECODE']='1'
    return env
def prepare():
    must('start-head',['git','rev-parse','HEAD'])
    must('start-status',['git','status','--porcelain=v1','--untracked-files=all'])
    tool=must('elan-which-lean',['elan','which','lean']).decode().strip()
    lean=Path(tool).resolve()
    version=must('native-version',[lean,'--version']).decode().strip()
    must('native-help',[lean,'--help'])
    manifest=(REPO/'lake-manifest.json').read_bytes()
    assert sha(manifest)=='b83ca83b9cf7caa85fa8b023c2ff9a3fb7a7cce7e1c332e810c348535ec49c37'
    package=[]
    for pkg in json.loads(manifest)['packages']:
        name=pkg['name'];root=REPO/'.lake/packages'/name
        head=must('package-'+name+'-head',['git','rev-parse','HEAD'],root).decode().strip()
        status=must('package-'+name+'-status',['git','status','--porcelain=v1','--untracked-files=all'],root)
        assert head==pkg['rev'] and status==b'',name
        package.append({'name':name,'expected':pkg['rev'],'actual':head,'clean_including_untracked':not status,'root':str(root)})
    save('environment.json',{'lean_path':str(lean),'lean_binary_sha256':sha(lean.read_bytes()),'lean_binary_bytes':lean.stat().st_size,
      'version':version,'lean_toolchain_sha256':sha((REPO/'lean-toolchain').read_bytes()),'manifest_sha256':sha(manifest),'packages':package,
      'LEAN_PATH':native_env()['LEAN_PATH'],'ASTIS_cached_oleans_in_LEAN_PATH':False})
    sources={};order=[]
    def visit(module):
        if module in sources:return
        path=module.replace('.','/')+'.lean'
        raw=must('candidate-'+module.replace('.','_'),['git','show',CANDIDATE+':'+path])
        sources[module]={'path':path,'bytes':len(raw),'sha256':sha(raw),'imports':[]}
        target=OWN/'fresh/src'/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
        assert (REPO/path).read_bytes()==raw, 'candidate/current code differs: '+path
        for m in re.findall(r'^import\s+([^\n]+)',raw.decode(),re.M):
            for dep in m.strip().split():
                if dep.startswith(('AutoSamplingTheory.','Tests.')):
                    sources[module]['imports'].append(dep);visit(dep)
        order.append(module)
    visit(T[:-5].replace('/','.'))
    assert len(sources)==7, list(sources)
    out=OWN/'fresh/olean';out.mkdir(parents=True,exist_ok=True)
    assert not list(out.rglob('*.olean')),'fresh output must be empty'
    save('closure.json',{'candidate':CANDIDATE,'modules':sources,'topological_order':order,'initial_olean_count':0})
    print('CLOSURE',order,flush=True)
def compile_all():
    env=native_env();lean=json.loads((OWN/'environment.json').read_text())['lean_path']
    closure=json.loads((OWN/'closure.json').read_text())
    for i,mod in enumerate(closure['topological_order']):
        path=closure['modules'][mod]['path'];out=OWN/'fresh/olean'/Path(path).with_suffix('.olean');out.parent.mkdir(parents=True,exist_ok=True)
        must('fresh-compile-'+str(i+1),[lean,'-o',out,path],OWN/'fresh/src',env)
    save('fresh-outputs.json',[{'path':str(p.relative_to(OWN)),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in sorted((OWN/'fresh/olean').rglob('*')) if p.is_file()])
if __name__=='__main__':
    {'prepare':prepare,'compile':compile_all}[sys.argv[1]]()
