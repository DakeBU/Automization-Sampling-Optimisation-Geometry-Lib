from pathlib import Path
from hashlib import sha256
import json,datetime,runpy
D=Path('.astis/huanjian-gc-fixed-spectrum-grid-alias-20261109/independent-source-graph')
inv=json.loads((D/'phase1/source-item-inventory.json').read_text())
nodes=[
('standing-grid','S4.SS1.p1.1;S4.E11','d>=2, kappa>=2, theta_i=(i-1/2)pi/d for i=1,...,d; lambda_i=(kappa+1)/2+(kappa-1)cos(theta_i)/2; Lambda=diag(lambda_i).','definition'),
('rho','S4.Thmtheorem5.p1.1','rho=(sqrt(kappa)-1)/(sqrt(kappa)+1), so the source later uses 0<rho<1.','definition'),
('moment-definitions','S4.Thmtheorem5.p1.1','U~N(0,Lambda^-1), D_n=diag(cos(n theta_i)), M=E||U||^2, mu_n=E[U^T D_n U], integer 1<=n<d. Only the deterministic grid side is targeted.','definition-context'),
('c7-expand','A3.Thmtheorem7;A3.Ex133','For every real theta: inverse spectrum=(1/sqrt(kappa))(1+2 sum_{j>=1}(-rho)^j cos(j theta)); absolute/uniform convergence.','upstream-source-result'),
('c7-geometric','A3.SS3.p2.1;A3.EGx14','0<rho<1 permits the geometric-series route through complex exponentials to the Poisson-type rational expression.','upstream-proof-step'),
('c7-normalization','A3.SS3.p2.2;A3.Ex136;A3.SS3.p2.3','rho-to-kappa normalization identities identify the inverse eigenvalue denominator.','upstream-proof-step'),
('c7-majorant','A3.Ex137;A3.SS3.p2.4','The theta-independent majorant sum rho^j=rho/(1-rho) supplies absolute and uniform convergence.','upstream-proof-step'),
('integer-alias','A3.SS3.p3.1;A3.Ex139','For ALL k in Z: sum_i cos(k theta_i)=d*(-1)^a when k=2ad, a in Z; zero if k notin 2dZ. This is the newly bounded source leaf.','bounded-target'),
('integer-alias-nonmultiple','A3.SS3.p3.2','Nonmultiple branch uses sin(k pi)/(2 sin(k pi/(2d)))=0; condition k notin 2dZ makes the denominator nonzero.','source-proof-step'),
('integer-alias-multiple','A3.SS3.p3.2','Multiple branch evaluates each cos(2ai pi-a pi)=(-1)^a, including a=0 and negative a.','source-proof-step'),
('expectation-to-grid','A3.SS3.p4.1;A3.Ex140','E U_i^2=1/lambda_i identifies M and mu_n with deterministic inverse-grid sums. Remains OPEN/excluded from this bounded target, not silently treated as definition.','SOURCE_GAP-outside-bound'),
('finite-series-exchange','A3.SS3.p4.2','C7 absolute convergence justifies interchanging its positive-frequency series with the finite grid sum, also after bounded cosine weighting.','consumer-prerequisite'),
('weighted-constant-zero','A3.SS3.p6.1','For 1<=n<d, sum_i cos(n theta_i)=0: integer-alias applies on the nonmultiple branch. The C7 constant term vanishes.','consumer-step'),
('weighted-product-sum','A3.SS3.p6.1;A3.Ex144','Use 2 cos(j theta_i) cos(n theta_i)=cos((j-n)theta_i)+cos((j+n)theta_i). C7 factor 2 cancels the product-to-sum half.','consumer-step'),
('weighted-prealias-series','A3.Ex144','Deterministic W_n=sum_i cos(n theta_i)/lambda_i=(1/sqrt(kappa))*sum_{j>=1}(-rho)^j*(sum_i cos((j-n)theta_i)+sum_i cos((j+n)theta_i)). The paper writes mu_n after the separate expectation bridge.','bounded-consumer'),
('weighted-alias-supported-series','A3.Ex139;A3.SS3.p6.1;A3.Ex144;A3.SS3.p6.2','Rewrite EACH inner sum using the all-integer alias identity: W_n=(d/sqrt(kappa))*sum_{j>=1}(-rho)^j*(a_d(j-n)+a_d(j+n)); a_d(k)=(-1)^a for k=2ad else 0. This is a source-derived deterministic compression of Ex144, not a separately numbered source theorem.','bounded-consumer-compression'),
('weighted-tail-classes','A3.SS3.p6.2','j=n and j=2ad+n (a>=1) for j-n; j=2ad-n (a>=1) for j+n. These classes are disjoint because 1<=n<d. Parity yields (-rho)^(2ad+-n)=(-1)^n rho^(2ad+-n). OPEN/excluded tail extraction.','SOURCE_GAP-outside-bound'),
('weighted-tail-resum','A3.EGx16','The source regroups the three classes and sums geometric tails to the signed closed weighted mean formula. OPEN/excluded from the bounded alias/series delta.','SOURCE_GAP-outside-bound'),
('unweighted-tail-resum','A3.SS3.p5.1;A3.EGx15','The source extracts j=2ad,a>=1, then geometrically resums M. OPEN/excluded from this bounded weighted consumer.','SOURCE_GAP-outside-bound'),
('c8-means','A3.Thmtheorem8;A3.Ex138','Both Gaussian mean closed forms remain the larger C8 result; this bounded extraction does not admit C8.','outside-target-context')]
N=[dict(id=i,source=s,meaning=m,kind=k) for i,s,m,k in nodes]
edges=[]
def edge(parents,child,use,discharge):edges.append(dict(parents=parents,consumer=child,use_site=use,conditional_discharge=discharge,semantics='AND-within-this-author-route'))
edge(['standing-grid'],'integer-alias','A3.SS3.p3','d>=2 source standing; arbitrary k in Z, not restricted to positive modes')
edge(['integer-alias-nonmultiple','integer-alias-multiple'],'integer-alias','A3.SS3.p3.2','Disjoint exhaustive split k in 2dZ or not; the branch equations are guarded')
edge(['rho'],'c7-geometric','A3.SS3.p2.1','0<rho<1 derives from kappa>=2, not an added public premise')
edge(['c7-geometric','c7-normalization','c7-majorant'],'c7-expand','A3.SS3.p2.3-p2.4','geometric convergence and denominators are source proof obligations; no witness premise')
edge(['c7-expand'],'finite-series-exchange','A3.SS3.p4.2','absolute convergence supplied by C7; finite grid and bounded cosine weight')
edge(['standing-grid','integer-alias'],'weighted-constant-zero','A3.SS3.p6.1','1<=n<d implies n notin 2dZ')
edge(['c7-expand','finite-series-exchange','weighted-constant-zero','weighted-product-sum'],'weighted-prealias-series','A3.SS3.p6.1/A3.Ex144','1<=n<d; no Gaussian bridge required for W_n')
edge(['weighted-prealias-series','integer-alias'],'weighted-alias-supported-series','A3.Ex144 inner sums / A3.SS3.p6.2','j>=1; j-n can be negative/zero, so all-integer alias coverage is essential')
edge(['moment-definitions','expectation-to-grid','weighted-prealias-series'],'c8-means','A3.SS3.p4 through p6','Incomplete: still needs unweighted and weighted tail regrouping/resummation')
edge(['weighted-alias-supported-series'],'weighted-tail-classes','A3.SS3.p6.2','OPEN future edge; 1<=n<d used for disjointness and positive 2ad-n')
edge(['weighted-tail-classes'],'weighted-tail-resum','A3.EGx16','OPEN future edge; absolute series regrouping and geometric resummation required')
# Exact one disposition for every source paragraph/display/theorem/reference in the bounded raw read.
M={}
def bind(ids,node):
 for x in ids.split(): M[x]=('NODE',node,None)
def excl(ids,reason):
 for x in ids.split(): M[x]=('EXCLUDED',None,reason)
bind('S4.SS1.p1.1 S4.E11','standing-grid')
excl('S4.SS1::ref-1','External [22] Section9.2 is construction provenance; the present alias and weighted series are explicitly proved locally in C.3. No imported theorem asserted.')
excl('S4.SS1.p1.2 S4.SS1.p2.1','Random rotation, algorithm knowledge, A and pi_A belong to the lower-bound experiment, outside this deterministic spectral-grid delta.')
excl('S4.Thmtheorem2 S4.Thmtheorem2.p1.1 S4.SS1::ref-7 S4.SS1::ref-8 S4.SS1::ref-9 S4.SS1::ref-10 S4.SS1::ref-11','Remark4.2 query lower-bound motivation and comparison are outside the bounded alias/series consumer; equation11 standing grid is independently retained.')
bind('S4.Thmtheorem5 S4.Thmtheorem5.p1.1','moment-definitions')
excl('S4.EGx1','Lemma4.5 closed Gaussian means are the enclosing result; expectation identification and closed resummation remain open/excluded.')
excl('S4.Thmtheorem5.p1.2','Gaussian variance statement outside the deterministic grid-series slice.')
excl('S4.Thmtheorem5.p2.1 S4.Ex17','Normalized-bias endpoint assumption d-n>=sqrt(kappa) and exponential bounds are not premises or outputs of this slice.')
bind('A3.SS3::ref-18 A3.SS3.p1.1','standing-grid')
bind('A3.Thmtheorem7 A3.Thmtheorem7.p1.1 A3.Ex133 A3.Thmtheorem7.p1.2','c7-expand')
bind('A3.SS3.p2.1 A3.EGx14','c7-geometric')
bind('A3.SS3.p2.2 A3.Ex136 A3.SS3.p2.3','c7-normalization')
bind('A3.Ex137 A3.SS3.p2.4','c7-majorant')
bind('A3.Thmtheorem8 A3.Thmtheorem8.p1.1 A3.Ex138','c8-means')
bind('A3.SS3.p3.1 A3.Ex139','integer-alias')
bind('A3.SS3.p3.2','integer-alias-nonmultiple')
excl('A3.SS3.p4.1 A3.Ex140','OPEN expectation-to-grid bridge retained as explicit source graph node expectation-to-grid; no Gaussian means credit.')
bind('A3.SS3.p4.2 A3.SS3::ref-40','finite-series-exchange')
excl('A3.SS3.p5.1 A3.EGx15','OPEN unweighted alias extraction and tail closed resummation retained as unweighted-tail-resum.')
bind('A3.SS3.p6.1','weighted-constant-zero')
bind('A3.Ex144','weighted-prealias-series')
excl('A3.SS3.p6.2 A3.EGx16','OPEN three-class tail extraction, disjointness/parity and closed resummation retained as weighted-tail-classes and weighted-tail-resum. Alias application before regrouping remains in scope.')
excl('A3.SS3.p6.3','Proof-end glyph only.')
excl('A3.SS3::ref-48 A3.SS3.p7.1 A3.SS3::ref-50','C8-to-Lemma4.5 whole means citation is outside bounded delta and cannot grant whole C8/Lemma4.5 credit.')
excl('A3.SS3.p8.1 A3.EGx17 A3.SS3.p8.2','Gaussian independence/fourth moments, variance sums and bound M<=d/sqrt(kappa) are outside deterministic alias/series scope.')
excl('A3.SS3.p9.1 A3.Ex150 A3.SS3.p9.2 A3.Ex151','Normalized signed bias and ratio estimates consume closed means, outside this delta.')
excl('A3.SS3.p10.1 A3.EGx18 A3.SS3.p10.2 A3.EGx19 A3.SS3.p10.3 A3.Ex157','Logarithm/integral and exponential bounds are outside this delta, including their kappa-dependent estimate.')
excl('A3.SS3.p11.1 A3.Ex158 A3.SS3.p11.2 A3.Ex159','Endpoint d-n>=sqrt(kappa) and final normalized-bias lower bound are outside this delta.')
excl('A3.SS3.p11.3','Proof-end glyph only.')
assert set(M)=={r['source_id'] for r in inv},set(r['source_id'] for r in inv)-set(M)
coverage=[]
for r in inv:
 d,node,reason=M[r['source_id']];coverage.append({**r,'disposition':d,'node':node,'exclusion_reason':reason})
# Display row aliases receive the same unique disposition as their parent displayed group.
row_map={'S4.Ex16':'S4.EGx1','A3.Ex134':'A3.EGx14','A3.Ex135':'A3.EGx14','A3.Ex141':'A3.EGx15','A3.Ex142':'A3.EGx15','A3.Ex143':'A3.EGx15','A3.Ex145':'A3.EGx16','A3.Ex146':'A3.EGx16','A3.Ex147':'A3.EGx16','A3.Ex148':'A3.EGx17','A3.Ex149':'A3.EGx17','A3.Ex152':'A3.EGx18','A3.Ex153':'A3.EGx18','A3.Ex154':'A3.EGx18','A3.Ex155':'A3.EGx19','A3.Ex156':'A3.EGx19'}
rows=[{'source_id':k,'parent_group':v,'disposition':M[v][0],'node':M[v][1],'exclusion_reason':M[v][2]} for k,v in row_map.items()]
# Further semantic subdivisions preserve paragraphs with more than one mathematical move.
substeps=[{'source_id':'A3.SS3.p3.2::multiple-branch','disposition':'NODE','node':'integer-alias-multiple'},{'source_id':'A3.SS3.p6.1::product-to-sum','disposition':'NODE','node':'weighted-product-sum'},{'source_id':'A3.SS3.p6.2::alias-evaluation-only','disposition':'NODE','node':'weighted-alias-supported-series','boundary':'Only substitutions of Ex139 into Ex144; excludes tail class partition/regrouping/resummation.'},{'source_id':'S4.Thmtheorem5.p1.1::rho-definition','disposition':'NODE','node':'rho'}]
graph={'phase':'raw-first-frozen','source_sha256':'6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915','scope':['S4.SS1','S4.Thmtheorem5','A3.SS3'],'not_whole_paper_coverage':True,'nodes':N,'edges':edges,'semantic_substeps':substeps,'alternative_routes':[],'truth_boundary':'Source extraction/topology only. No implementation, proof APIs, Registry, production lesson/audit, or prior graph verdict was read. No Lean/proof/C8 acceptance.'}
(D/'phase1/raw-first-author-graph.json').write_text(json.dumps(graph,indent=2)+'\n')
(D/'phase1/exhaustive-bounded-coverage.json').write_text(json.dumps({'items':coverage,'display_row_aliases':rows,'paragraph_substeps':substeps,'coverage_total':len(coverage),'silent_items':0,'scope_claim':'Only exact source roots listed; all paragraph/display/theorem/reference units inventoried. Inline source definitions are represented by semantic nodes and enclosing paragraph, not silently omitted.'},indent=2,ensure_ascii=False)+'\n')
(D/'phase1/raw-first-cognition.md').write_text('''# Raw-first source cognition (frozen before interface exposure)

Source: On Complexity of Gaussian Sampling, arXiv:2610.20492v1, pinned local HTML SHA256 6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915.

The author starts from the one-based midpoint grid and rho in Lemma4.5. C7 is an absolutely/uniformly convergent positive-frequency cosine expansion. The C8 proof then states an all-integer grid alias rule, proves its nonmultiple and multiple branches, identifies Gaussian expectations with inverse-grid sums, and consumes C7 in a finite/series exchange. For the weighted sum, the constant vanishes at 1<=n<d; product-to-sum creates the two frequencies j-n and j+n; the all-integer alias is then consumed in those inner sums. The sign/magnitude factor is d times the normalized alias value, so the weighted alias-supported series has d/sqrt(kappa), not 1/sqrt(kappa), outside it.

This bounded author graph is a deterministic pre-resummation slice. Let W_n=sum_i cos(n theta_i)/lambda_i. The genuine alias consumer is W_n=(d/sqrt(kappa))*sum_{j>=1}(-rho)^j*(a_d(j-n)+a_d(j+n)). This formula is the explicit substitution of the author's alias rule into the product-to-sum display. It is not a claim that the paper defines mu_n deterministically: mu_n is a Gaussian expectation and needs the separate expectation-to-grid bridge. The aliases at j-n include negative, zero and positive frequencies; j=n produces the zero-frequency value one. Integer powers of -1 must remain meaningful for negative alias quotients. All source integers k are required.

Raw source conditions: d>=2 and kappa>=2 are standing; k is any integer; 1<=n<d is needed for constant elimination and later tail disjointness. No d-n>=sqrt(kappa) belongs in this bounded alias/series statement. That endpoint is only for the later normalized-bias bound. The finite angle index is i=1,...,d; any zero-based formal carrier must explicitly shift i by one and retain the midpoint.

The graph retains the Gaussian expectation bridge and the unweighted and weighted tail extraction/geometric closed resummation as explicit OPEN source obligations outside this target. The variance and normalized-bias regions are explicitly excluded. [22] Section9.2 is construction provenance, not an unseen proof dependency for the locally proved alias. No source route is inferred from imports or formal implementation topology.

Coverage is exhaustive only for S4.SS1, S4.Thmtheorem5 and A3.SS3. It covers all paragraphs, display groups/rows, theorem containers, source definitions and citations by NODE or EXCLUDED with reason. This is not a whole-paper inventory and is not independently approved by its extractor.
''')
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
timeline={'ordering_basis':'Exact tool-call ordinal exposure sequence; wall-clock timestamps prior to this checkpoint were not instrumented and are not fabricated.','events':[
{'event':'E01','exposure':'Parent task and named seal path/hash only; no seal content.'},
{'event':'E02','exposure':'rg filename inventory for instructions. Prior evidence filenames appeared, no contents read.'},
{'event':'E03','exposure':'AGENTS.md and proof-digestion-protocol.md read (first output truncated; later instruction portions read to complete applicable rules).'},
{'event':'E04','exposure':'source-dependency-audit/SKILL.md and evidence-routed-memory-protocol.md read.'},
{'event':'E05','exposure':'Attempted raw-source extraction failed before read because bs4 missing; no candidate exposure.'},
{'event':'E06','exposure':'Raw HTML hash and full S4.SS1, S4.E11, S4.Thmtheorem5, A3.SS3 text read using stdlib parser.'},
{'event':'E07','exposure':'Raw HTML markup at A3.SS3 and S4.Thmtheorem5 inspected for exact source IDs.'},
{'event':'E08','exposure':'Saved source/instruction snapshots; independently reread exhaustive paragraph/display/citation inventory.'},
{'event':'E09','exposure':'Remaining applicable AGENTS text, raw bibliography bib.bib3 and display row IDs read.'},
{'event':'E10','utc':now,'exposure':'Raw-first cognition, author graph and bounded exhaustive coverage frozen. No candidate/interface, implementation Lean, proof API, Registry, production audit/lesson or prior graph verdict read.'}],
'forbidden_exposures_to_this_point':[]}
(D/'phase1/exposure-timeline-through-freeze.json').write_text(json.dumps(timeline,indent=2)+'\n')
files=[]
for p in sorted((D/'phase1').rglob('*')):
 if p.is_file():
  b=p.read_bytes();files.append({'path':str(p.relative_to(D)),'sha256':sha256(b).hexdigest(),'bytes':len(b)})
f={'frozen_utc':now,'immutable_by_protocol':True,'phase1_files':files,'phase2_may_not_mutate_phase1':True}
(D/'phase1-freeze-manifest.json').write_text(json.dumps(f,indent=2)+'\n')
for p in [D/'phase1/raw-first-author-graph.json',D/'phase1/exhaustive-bounded-coverage.json',D/'phase1/raw-first-cognition.md',D/'phase1-freeze-manifest.json']:print(p,sha256(p.read_bytes()).hexdigest())
