from pathlib import Path
import datetime, gzip, hashlib, json, shutil, subprocess, sys
sys.path.insert(0,'tools')
import astis_advance as adv
sha = lambda b: hashlib.sha256(b).hexdigest()
R = Path('.astis/huanjian-gc-fixed-spectrum-first-order-integration-20261108')
P = R/'graph-selection-repair-v3'
B = Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-first-order-integration-20261108/native-selection-repair-v3')
review = R/'independent-reader/UI-camera-repair-independent-review-v3/initial-exact-v3-review.json'
assert sha(review.read_bytes()) == '5b488c34d9eee3bb26215b61e106d2ab8a95b6f58b2fa6ce3d4b3adc4b658a97'
assert json.loads(review.read_bytes())['status'] == 'accepted-for-bounded-application-and-new-validation'
proposal = P/'proposal-report.json'
assert sha(proposal.read_bytes()) == 'e2c7fa2e3128d92e46cf789d370e89382a7160e01da90c3a0d227ad7b6a66f69'
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip() == '87ecd4d421de0146a062435f63e9dcb1f815c807'
assert not subprocess.check_output(['git','diff','HEAD','--name-only'],text=True).strip()
states = adv.current_advances(); aid = 'ASTIS-SA-20261108-GaussianComplexityFixedSpectrumFirstOrder'
assert [k for k,v in states.items() if v['state']=='STABILIZING'] == [aid]
ledger = Path('runs/substantive_advances.jsonl'); ledger_raw = ledger.read_bytes()
discovery = Path('runs/substantive_discoveries.jsonl'); discovery_raw = discovery.read_bytes()
frontiers = {str(p):p.read_bytes() for p in Path('research-wiki/frontier-cells').glob('*.json')}
pins = json.loads((R/'independent-reader/conditional-proposal-v1/proposal-report.json').read_bytes())
protected = {str(Path(row['path'])):Path(row['path']).read_bytes() for row in pins['shared_paths']}
for path in ['AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumFirstOrder.lean',
             'Tests/GaussianComplexityFixedSpectrumFirstOrder.lean',
             'website/content/declaration_lessons/huanjian-fixed-spectrum-first-order.json',
             'website/content/publications/huanjian-fixed-spectrum-first-order.json',
             'research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-first-order.json',
             'research-wiki/paper-contributions/GaussianComplexity/README.md','lake-manifest.json','lean-toolchain']:
    protected[path] = Path(path).read_bytes()
target = Path('website/static/underlying-lean-graph.js'); before = target.read_bytes()
after = gzip.decompress((P/'planned-after.raw.js.gz').read_bytes())
assert sha(before) == 'cb899b6cff1e241a47ee88bff0fb72d04a56af7e4134bfe30168d44a2f00c6e7'
assert sha(after) == '016c11a60392c449ebb28e8bedc7d3ab69134fff8dde4b438fd06c9f6c951a3a'
assert not B.exists(); B.mkdir(parents=True)
target.write_bytes(after)
assert subprocess.check_output(['git','diff','HEAD','--name-only'],text=True).splitlines() == [str(target)]
assert ledger.read_bytes() == ledger_raw and discovery.read_bytes() == discovery_raw
assert adv.current_advances() == states
assert all(Path(p).read_bytes() == raw for p,raw in frontiers.items())
assert all(Path(p).read_bytes() == raw for p,raw in protected.items())
for name in ['proposal-report.json','exact-UI-repair.diff','before.raw.js.gz','planned-after.raw.js.gz']:
    shutil.copy2(P/name,B/name)
shutil.copy2(review,B/'independent-initial-exact-v3-review.json')
shutil.copy2(R/'independent-reader/UI-camera-repair-independent-review-v3/initial-freeze.json',B/'independent-initial-freeze.json')
record = {'applied_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'authorized_by':'/root','operation':'Exactly one independently reviewed shared JS camera repair; no lifecycle API',
    'held_core':'87ecd4d421de0146a062435f63e9dcb1f815c807',
    'independent_review_sha256':sha(review.read_bytes()),'proposal_sha256':sha(proposal.read_bytes()),
    'only_changed_preexisting_tracked_path':str(target),'before_sha256':sha(before),'after_sha256':sha(after),
    'actual_gates_runtime_acceptance':'Pending new immutable core and all real gates/runtime/pixels.',
    'all285_SAU_states_both_ledgers_and444_frontiers_unchanged':True,
    'source_Test_lesson_publication_audit_models_manifest_README_unchanged':True,
    'old_v3_38_originals_script_PASS_and_independent_pixel_HOLD_preserved':True,
    'new_source_verdict_or_API':False}
(B/'exact-one-path-application.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'one_reviewed_JS_path_applied':True,'after_sha256':sha(after),
                  'all_math_and_lifecycle_state_unchanged':True,'next':'New immutable core, real gates and stronger v4 UI.'}))
