"""Private test-only cast fix plus negative-dominant mixed spectrum; no ASTIS rebuild."""
import json
from native_common import *

def main():
    for filename in ['native-assignment.json','native-successor-assignment.json']:
        for row in json.loads((OWN/filename).read_text())['inputs']:assert file_sha(OWN/row['path'])==row['sha256']
    harness=OWN/'harness-v3';harness.mkdir(exist_ok=False)
    source=(OWN/'harness-v2/NativeLiteralApplications.lean').read_text()
    assert source.count('[Matrix.cstar_norm_def, Fintype.card_fin]')==1
    source=source.replace('[Matrix.cstar_norm_def, Fintype.card_fin]','[Matrix.cstar_norm_def, Fintype.card_fin, Nat.cast_ofNat]')
    source=source.replace('if i = 0 then -2 else 3','if i = 0 then -3 else 2').replace('mixed 0 0 = -2 ∧ mixed 1 1 = 3','mixed 0 0 = -3 ∧ mixed 1 1 = 2')
    extra='''theorem mixed_operator_norm_three : ‖mixed‖ = 3 := by
  rw [mixed, Matrix.l2_opNorm_diagonal]
  apply le_antisymm
  · apply (pi_norm_le_iff_of_nonneg (by norm_num : (0 : ℝ) ≤ 3)).2
    intro i
    fin_cases i <;> norm_num
  · have h := norm_le_pi_norm (fun i : Fin 2 => if i = 0 then (-3 : ℝ) else 2) (0 : Fin 2)
    norm_num at h
    exact h

theorem mixed_negative_parameter_exact_norm_cap :
    0 < Matrix.trace (NormedSpace.exp ((-1 : ℝ) • mixed)) ∧
      Matrix.trace (NormedSpace.exp ((-1 : ℝ) • mixed)) ≤ 2 * Real.exp 3 := by
  simpa [← Matrix.cstar_norm_def, mixed_operator_norm_three] using mixed_allreal (-1)

'''
    source=source.replace('end NativeLiteralApplications\n',extra+'end NativeLiteralApplications\n')
    source+='\n#print axioms NativeLiteralApplications.mixed_operator_norm_three\n#print axioms NativeLiteralApplications.mixed_negative_parameter_exact_norm_cap\n'
    (harness/'NativeLiteralApplications.lean').write_text(source)
    for name in ['NativeAudit.lean','NativeTransitiveGraph.lean']:(harness/name).write_bytes((OWN/'harness-v2'/name).read_bytes())
    packages=json.loads((OWN/'verified-package-inputs.json').read_text());env=lean_env(packages['packages']);flags=[str(LEAN),'-DmaxRecDepth=32768','-DmaxHeartbeats=0','-Ddebug.skipKernelTC=false']
    commands=[{'id':'literal-types-and-boundaries-v3','argv':flags+['-o',str(OUT/'NativeLiteralApplications.olean'),str(harness/'NativeLiteralApplications.lean')]},{'id':'lossless-raw-type-value-kernel-v3','argv':flags+['--run',str(harness/'NativeAudit.lean')]},{'id':'complete-recursive-type-value-graph-v3','argv':flags+['--run',str(harness/'NativeTransitiveGraph.lean')]}]
    write_json(OWN/'native-v3-commands.json',commands)
    pinned=list(harness.iterdir())+[p for p in OUT.rglob('*') if p.is_file()]+[OWN/x for x in ['native-assignment.json','native-successor-assignment.json','native-v3-commands.json','run_successor_v3.py']]
    assignment={'candidate_commit':COMMIT,'reason':'Fix private mixed-test Nat.cast_ofNat simplification; use diag(-3,2), norm3 and s=-1 to separate operator norm from largest algebraic eigenvalue. No production or sealed type change.','inputs':[{'path':str(p.relative_to(OWN)),'sha256':file_sha(p)} for p in pinned]}
    write_json(OWN/'native-v3-assignment.json',assignment)
    for command in commands:
        for row in assignment['inputs']:assert file_sha(OWN/row['path'])==row['sha256']
        print(json.dumps({'actual_v3_started':command['id']}),flush=True)
        run(command['id'],command['argv'],cwd=harness,env=env)
    write_json(OWN/'native-sequence.completed.json',{'candidate_commit':COMMIT,'ASTIS_modules_freshly_recompiled':11,'both_private_harness_failures_retained':True,'all_v3_actual_commands_exit_zero':True,'negative_dominant_mixed_spectrum_checked':True})

if __name__=='__main__':main()
