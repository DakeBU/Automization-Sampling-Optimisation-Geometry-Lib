from pathlib import Path
import json,gzip,hashlib,subprocess,sys,datetime,os
sys.path.insert(0,'tools');import astis_advance as a;import astis_publication as pub
ADV='ASTIS-SA-20261108-GaussianComplexityFixedSpectrumDeterminant';OWNER='huanjian_gc_20261108_fixed_spectrum_determinant_integration';DECL='AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumDeterminant.actual_precision_det'
OUT=Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-determinant-integration-20261108');sha=lambda b:hashlib.sha256(b).hexdigest()
def unpack(row):
 raw=Path(row['path']).read_bytes();assert sha(raw)==row['gzip_sha256'];data=gzip.decompress(raw);assert sha(data)==row['raw_sha256'];return data
s=a.current_advances();assert s[ADV]['state']=='STABILIZING' and s[ADV]['latest_evidence']['integration_owner']==OWNER and [k for k,v in s.items() if v['state']=='STABILIZING']==[ADV];pub.check_advance([DECL],reviewed=True)
report=OUT/'independent-integration-reader-review/proposal/proposal-report.json';assert sha(report.read_bytes())=='ab826ff9e6fbbd2db0f0fa766ceadaccf470448152727e48b987bab0ae7161ac';x=json.loads(report.read_bytes());assert len(x['shared_paths'])==6 and not (OUT/'shared-integration-manifest.json').exists()
for p,h in x['source_Test_lesson_publication_pins'].items():assert sha(Path(p).read_bytes())==h
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();claim=json.loads((OUT/'normal-stab-claim.json').read_bytes());assert head==claim['accepted_metadata_first_carrying_commit'];subprocess.run(['git','merge-base','--is-ancestor','origin/main','HEAD'],check=True)
plans=[]
for row in x['shared_paths']:
 p=Path(row['path']);old=p.read_bytes() if p.exists() else None;assert (old is not None)==row['before_exists'] and (sha(old) if old is not None else None)==row['before_sha256'],str(p)
 if old is not None:assert subprocess.check_output(['git','show',head+':'+str(p)])==old
 new=unpack(row['planned_after_archive']);assert sha(new)==row['planned_after_sha256'];plans.append((row,old,new))
for path,r in x['ledger_protection'].items():
 assert Path(path).read_bytes().startswith(unpack(r['raw_prefix']));foreign=json.loads(unpack(r['foreign_projection']));now=a.current_advances() if 'advances' in path else a.current_discoveries();assert all(now[k]==v for k,v in foreign.items())
protected=json.loads(unpack(x['protected_foreign_content']))
for p,row in protected.items():
 q=Path(p);raw=os.fsencode(os.readlink(q)) if q.is_symlink() else q.read_bytes();assert sha(raw)==row['sha256'],p
old,new=map(json.loads,next((o,n) for row,o,n in plans if row['path']=='website/content/samplewiki_companion_frontiers.json'));assert old['execution']==new['execution'] and old['cases'][4]['theorems'][0]==new['cases'][4]['theorems'][0];assert new['cases'][4]['theorems'][1]['boundary'].endswith(x['protected_case_values']['Section4_4_limitation_suffix'])
for v in [old,new]:v['cases'][4]['reader_guide'][3]='<OWN>';v['cases'][4]['theorems'][1]['boundary']='<OWN>'
assert old==new
for p,h in x['unchanged_models'].items():assert sha(Path(p).read_bytes())==h
lb=Path('runs/substantive_advances.jsonl').read_bytes();db=Path('runs/substantive_discoveries.jsonl').read_bytes()
for row,old,new in plans:
 p=Path(row['path']);p.parent.mkdir(exist_ok=True,parents=True);p.write_bytes(new);assert sha(p.read_bytes())==row['planned_after_sha256']
assert Path('runs/substantive_advances.jsonl').read_bytes()==lb and Path('runs/substantive_discoveries.jsonl').read_bytes()==db and a.current_advances()==s
for p,h in x['unchanged_models'].items():assert sha(Path(p).read_bytes())==h
manifest={'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base_commit':head,'integration_owner':OWNER,'mathematical_candidate':'a0310046dc10c06ce9f61959094322fb9016be1e','accepted_source_V_first_carrying_commit':head,'source_verifier':'/root/reader_835194','reviewed_proposal_sha256':sha(report.read_bytes()),'paths':[{'path':r['path'],'before_sha256':sha(o) if o is not None else None,'after_sha256':sha(n)} for r,o,n in plans],'case_scalar_pointer_delta':x['frontier_scalar_pointer_delta'],'determinant_index0_all_other_case_values_and_execution_preserved':True,'Section4_4_limitation_suffix_preserved_verbatim':True,'all_old_Registry_bytes_preserved':True,'new_canonical_entries':1,'count_change':'618->619 administrative inventory only','new_conceptual_bridge_or_oracle_binding':False,'actual_ASTIS_producer_parents':x['formal_ASTIS_producer_parents'],'actual_ASTIS_consumer_parents':x['formal_ASTIS_consumer_parents'],'consumer_private_Test_only':True,'unchanged_models':x['unchanged_models'],'ledger_and_all_advance_states_unchanged_by_shared_write':True,'protected_foreign_content_checked':len(protected),'state':'Exact guarded six-path STAB shared write completed; actual canonical gates/reader acceptance pending'};(OUT/'shared-integration-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'shared_paths':len(plans),'canonical_nodes_added':1,'both_graph_models_unchanged':True,'protected_foreign_content':len(protected)}))
