from pathlib import Path
import json, hashlib, datetime
raw=Path(__file__).resolve().parent
own=raw.parent
items=json.loads((raw/'source-blocks.json').read_text())
coverage=[]
for x in items:
    if not (1083 <= x['line'] < 1241 or 3314 <= x['line'] < 3835):
        continue
    sid=x['id']; line=x['line']; layers=[]; disp='NODE'; reason=''
    if x['tag'].startswith('h'):
        disp='EXCLUDED'; reason='Navigation/theorem/proof heading only.'
    elif sid in ['S4.E11','S4.SS1.p1.1','S4.Ex12','S4.SS2.SSS0.Px2.p1.1','S4.Thmtheorem4.p1.1']:
        layers=['source-regime-and-literal-grid-frequency']; reason='Keep exact source regime, Gaussian experiment or deterministic phase/frequency.'
    elif sid in ['S4.Thmtheorem4.p1.2','S4.Ex14','S4.Ex13']:
        layers=['full-Lemma44-context']; reason='Conditional tau and probability/full final conclusion; not a premise of eventwise Gram reconciliation.'
    elif sid in ['S4.Ex10','S4.SS2.SSS0.Px2.p2.1']:
        layers=['optional-range-to-Krylov-transfer']; reason='Needed only if later scope transfers from every Bc to every Krylov vector.'
    elif line < 3314:
        disp='EXCLUDED'; reason='Surrounding algorithm/rotation/lower-bound/Krylov representation context; no input to eventwise actual Gram algebra or coefficient-vector consumer.'
    elif 3318 <= line <= 3358:
        layers=['literal-B-and-frame','optional-range-to-Krylov-transfer']; reason='Source definitions and FactC5 combined displays; exact relevant projections and range-only conditions distinguished in raw-source-expectations.'
    elif 3364 <= line < 3378:
        layers=['optional-range-to-Krylov-transfer']; reason='Source triangular/invertible basis change; separate from Gram reconciliation and norm conversion.'
    elif 3378 <= line < 3498:
        layers=['exact-frame-and-aggregate-means']; reason='Midpoint cosine sums, frame/weighted cancellation and original Gram expectation computations are internal proof ingredients.'
    elif 3498 <= line < 3510:
        disp='EXCLUDED'; reason='Frame norm bound can support separate summand estimates but exact frame identities suffice for the current aggregate/reconciliation path.'
    elif 3510 <= line < 3533:
        layers=['full-FactC6-context']; reason='Concentration target context only, not established by deterministic Ex125/126.'
    elif 3533 <= line < 3558:
        layers=['literal-cutoff-and-T','probability-boundary']; reason='Literal L,R,T retained; MGF/tail/event-probability subclaims remain separate full stochastic obligations, not caller certificates.'
    elif 3558 <= line < 3571:
        layers=['quantitative-bias-to-tau-boundary']; reason='Tail-bias numerical estimate is separate from Ex125/126 exact/eventwise content.'
    elif 3571 <= line < 3609:
        layers=['actual-individual-and-aggregate-means']; reason='Y definition, actual radial/individual mean, a-range and aggregate mean identities; quantitative bias subclaim is separately scoped in expectations.'
    elif 3609 <= line < 3631:
        layers=['literal-Z','Bernstein-input-boundary']; reason='Z definition and weighted sequence retained; summand norm bounds are separate Bernstein obligations.'
    elif 3631 <= line < 3701:
        disp='EXCLUDED'; reason='Fourth moments, PSD matrix-square/variance comparisons including Ex120 belong to separate Bernstein variance preparation, not exact Gram reconciliation.'
    elif 3701 <= line < 3735:
        layers=['Bernstein-and-threshold-boundary']; reason='Explicitly separate concentration proof/probability and source scalar Delta from eventwise use; none is a supplied stochastic caller premise.'
    elif 3735 <= line < 3744:
        layers=['source-deviation-antecedents']; reason='Exact simultaneous two centered-sum inequalities at a fixed outcome; their probability is separate.'
    elif 3744 <= line < 3753:
        layers=['Ex125-eventwise-reconciliation']; reason='Exact equality on literal T; actual aggregate means and pointwise Gram algebra required internally.'
    elif 3753 <= line < 3765:
        layers=['Ex126-eventwise-norms','probability-boundary']; reason='Norm implication from T and both deviations; probability arithmetic separately retained without claiming it proved.'
    elif 3765 <= line < 3792:
        layers=['quantitative-simplification-to-tau-boundary']; reason='Absolute constants/bias simplification belongs to full FactC6 scope, not exact eventwise reconciliation.'
    elif 3794 <= line < 3804:
        layers=['full-FactC6-to-Lemma44-boundary']; reason='Actual high-probability Gram input event to p19; probability must be proved internally if claimed.'
    elif 3804 <= line < 3820:
        layers=['all-c-deterministic-quadratic-consumer','optional-range-to-Krylov-transfer']; reason='Exact norm/quadratic conversion and simultaneous coefficient vectors; range bridge separately needed for arbitrary Krylov u.'
    else:
        layers=['optional-final-ratio-and-uniform-Krylov-transfer']; reason='Source tau<=1/2 only for inversion; all-c simultaneity retained; final probability/full lemma remains separate.'
    coverage.append({'source_id':sid,'line_start_1based':line,'tag':x['tag'],'disposition':disp,'layers':layers,'reason':reason,'readable_text_sha256':hashlib.sha256(x['text'].encode()).hexdigest()})
(raw/'coverage.raw-only.v1.json').write_text(json.dumps(coverage,ensure_ascii=False,indent=2)+'\n')
failure={'attempt':'First freeze construction in preceding tool invocation','exit_code':1,'stderr':'File "<stdin>", line 5: if not (1083<=x[\'line\']<1241 or3314<=x[\'line\']<3835):continue; SyntaxError: invalid syntax. Perhaps you forgot a comma?','cause':'Missing whitespace between Python keywords and numeric literals (or3314 and elif3318 etc).','scope':'Pure script formatting failure. Source expectations Markdown had been written; no freeze or coverage output existed from that failed Python command.','recovery':'Persisted corrected freeze_source.py with normal token spacing.','exact_command_body':'Preserved verbatim in original tool session.'}
(raw/'logs/failed-freeze-attempt.v1.json').write_text(json.dumps(failure,indent=2)+'\n')
freeze={'version':'next-gram-independent-raw-first-freeze-v1','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_sha256':'6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915','status':'RAW_SOURCE_EXPECTATIONS_FROZEN_BEFORE_NEW_SIGNATURE_GRAPH_API_PROOF','new_P_T_signatures_read':False,'new_SG_map_read':False,'implementation_or_API_search':False,'old_audit_native_verdicts_read':False,'no_previous_exposure_claim':'Earlier structure-packet source/signature work is disclosed; no new Gram interface or implementation was read.','scope':'Eventwise original B/Gram reconciliation on literal T; source deviation antecedents; deterministic norm/quadratic consumer; full probability/Bernstein/range/tau boundaries explicit.','coverage_blocks':len(coverage),'files':[]}
for p in sorted(raw.rglob('*')):
    if p.is_file() and p.name!='RAWFIRST-FREEZE.v1.json':
        freeze['files'].append({'path':str(p.relative_to(own)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(raw/'RAWFIRST-FREEZE.v1.json').write_text(json.dumps(freeze,indent=2)+'\n')
for p in [raw/'RAWFIRST-FREEZE.v1.json',raw/'raw-source-expectations.v1.md',raw/'coverage.raw-only.v1.json']:
    print(str(p),hashlib.sha256(p.read_bytes()).hexdigest())
