from hashlib import sha256
import json
from pathlib import Path

out = Path(__file__).resolve().parent
status = {
    'candidate': '49259190ed5aa40ac0696699eb2aaf9635a3697d',
    'base': '.astis/semantic-neutral-20261110/rm_native_941b',
    'self_hash': 'The manifest itself is excluded. Its detached digest is printed by the manifest generator.',
    'classification': {
        'portable_original': 'Bounded original evidence for internal byte-exact custody. Restore scripts under the given base for reproduction.',
        'private_host_specific_original': 'Original internal receipt with unredacted machine-local paths or host details. Keep private, and carry byte-exact only if approved.',
        'pinned_input_copy': 'Existing raw paper or immutable Git input. Recover by hash when possible. No need to duplicate in the original-output archive.',
    },
    'files': [],
    'omitted_cache_or_binaries': ['native-prefix/**', 'Kernel_*.olean', '**/__pycache__/**'],
}
private = {
    'native.log', 'native-manifest.json', 'kernel-a.log', 'kernel-a-raw.log', 'kernel-b.log',
    'static-a.log', 'static-b.log', 'static-c.log', 'static-d.log',
}
for file in sorted(out.rglob('*')):
    relative = file.relative_to(out)
    if not file.is_file() or relative.parts[0] == 'native-prefix' or '__pycache__' in relative.parts or file.suffix == '.olean' or relative.name == 'original-files.json':
        continue
    path = relative.as_posix()
    if path == '2610.20492v1.html' or path.startswith('blobs/'):
        group = 'pinned_input_copy'
    elif path in private:
        group = 'private_host_specific_original'
    else:
        group = 'portable_original'
    data = file.read_bytes()
    status['files'].append({'path': path, 'sha256': sha256(data).hexdigest(), 'bytes': len(data), 'custody': group})
manifest = out / 'original-files.json'
manifest.write_text(json.dumps(status, indent=2) + '\n')
print(len(status['files']), sha256(manifest.read_bytes()).hexdigest())
