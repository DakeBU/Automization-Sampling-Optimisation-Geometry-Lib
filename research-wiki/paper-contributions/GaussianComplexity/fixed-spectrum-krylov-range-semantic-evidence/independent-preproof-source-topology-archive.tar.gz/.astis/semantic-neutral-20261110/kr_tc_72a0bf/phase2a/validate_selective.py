from pathlib import Path
import hashlib,json,re,stat,datetime
OUT=Path(__file__).parent
sha=lambda b:hashlib.sha256(b).hexdigest()
sel=json.loads((OUT/'selective-input.raw.json').read_bytes())
receipts={'stage':'phase2a-selective-input-validation','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'no_SG_or_candidate_proof_read':True,'definitions':[],'signatures':[]}
for i,x in enumerate(sel['lean']):
 b=x['signature'].encode('utf8');assert sha(b)==x['signature_sha256']
 (OUT/('P' if i==0 else 'T')).with_suffix('.signature.txt').write_bytes(b)
 receipts['signatures'].append({'name':x['name'],'planned_file':x['planned_file'],'sha256':sha(b),'bytes':len(b),'literal_Prop_formation_only':x['literal_Prop_formation_only'],'target_theorem_compiled':x['target_theorem_compiled']})
sealpath=Path(sel['sealed_statement_file_for_hash_and_signature_fields_only'])
b=sealpath.read_bytes();assert sha(b)==sel['sealed_statement_raw_sha256']
receipts['full_seal_hash_only']={'file':str(sealpath),'bytes':len(b),'sha256':sha(b)}
seal=json.loads(b)
selected={}
def find_obj(v,allowed):
 if isinstance(v,dict):
  for k,z in v.items():
   if k in allowed:
    assert k not in selected
    selected[k]=z
   else:find_obj(z,allowed)
 elif isinstance(v,list):
  for z in v:find_obj(z,allowed)
find_obj(seal,{'producer','actual_private_consumer'})
assert set(selected)=={'producer','actual_private_consumer'}
def permitted(k):
 return any(t in k.lower() for t in ['signature','sha256','digest']) or k.lower() in {'name','file','planned_file','lean_name','declaration_name','declaration','lean_file'}
def extract_fields(v):
 if isinstance(v,dict):
  return {k:z for k,z in v.items() if permitted(k) and isinstance(z,(str,bool,int,type(None)))}
 raise TypeError('Expected designated seal object')
fields={k:extract_fields(v) for k,v in selected.items()}
(OUT/'seal-permitted-fields-only.json').write_text(json.dumps(fields,ensure_ascii=False,indent=2)+'\n')
# No root audit, planning, graph, or status narrative is output or retained.
receipts['full_seal_permitted_fields']=fields
for k,signature in zip(['producer','actual_private_consumer'],sel['lean']):
 vals=list(fields[k].values())
 assert signature['signature'] in vals,('signature not found in selected permitted fields',k)
 assert signature['signature_sha256'] in vals,('signature digest not found',k)
 assert signature['name'] in vals,('name not found',k)
 assert signature['planned_file'] in vals,('file not found',k)
receipts['full_seal_selective_equality_passed']=True
for i,d in enumerate(sel['minimal_definitions']):
 p=Path(d['file']);b=p.read_bytes();s=b.decode('utf8')
 assert sha(b)==d['wholefile_raw_sha256']
 a,z=d['start_character_inclusive'],d['end_character_exclusive']
 fragment=s[a:z];assert fragment==d['literal'];fb=fragment.encode('utf8')
 assert sha(fb)==d['literal_sha256']
 b0,b1=len(s[:a].encode('utf8')),len(s[:z].encode('utf8'))
 assert b0==d['byte_start_inclusive'] and b1==d['byte_end_exclusive']
 assert b[b0:b1]==fb
 l0=s.count('\n',0,a)+1;l1=s.count('\n',0,z-1)+1
 assert l0==d['start_line_1based'] and l1==d['end_line_1based_inclusive']
 assert fb.endswith(b'\n')==d['source_LF_included_exactly']
 contexts=[]
 if isinstance(d['context'],list):
  for c in d['context']:
   hits=[m.start() for m in re.finditer(re.escape(c),s)]
   contexts.append({'supplied_exact_context':c,'exact_occurrences':len(hits),'preceding_literal_occurrences':[{'char':x,'byte':len(s[:x].encode('utf8')),'line':s.count('\n',0,x)+1} for x in hits if x<a]})
   assert any(x<a for x in hits),('exact context not located before literal',i,c)
 (OUT/f'definition-{i+1:02d}.literal.txt').write_bytes(fb)
 receipts['definitions'].append({'index':i+1,'file':str(p),'wholefile_sha256':sha(b),'literal_sha256':sha(fb),'char_half_open':[a,z],'utf8_byte_half_open':[b0,b1],'LF_lines_1based_inclusive':[l0,l1],'terminal_LF_included':fb.endswith(b'\n'),'literal':fragment,'given_context':d['context'],'literal_exact_context_checks':contexts,'read_limit':'wholefile raw hash and locator arithmetic; only supplied literal/header/context displayed, no theorem proof body'})
root=OUT.parent
manifest=json.loads((root/'phase1.manifest.json').read_bytes())
assert sha((root/'phase1.manifest.json').read_bytes())=='05c869d5248141c2cab0604796c0b18f5695d11c9fd272265ec6b65cd1f9475a'
assert all(sha((root/'phase1'/x['path']).read_bytes())==x['sha256'] for x in manifest['files'])
assert all(stat.S_IMODE((root/'phase1'/x['path']).stat().st_mode)==0o444 for x in manifest['files'])
assert stat.S_IMODE((root/'phase1').stat().st_mode)==0o555
receipts['phase1_unchanged_hashes_and_modes']=True
(OUT/'selective-validation.receipts.json').write_text(json.dumps(receipts,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(receipts,ensure_ascii=False,indent=2))
