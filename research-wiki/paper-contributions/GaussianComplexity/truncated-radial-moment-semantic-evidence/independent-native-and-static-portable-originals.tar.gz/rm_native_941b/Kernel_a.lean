import Lean
import Tests.GaussianComplexityFixedSpectrumTruncatedRadialMoment

open MeasureTheory ProbabilityTheory

def sealedProducer : Prop :=
  ∀ {d q : ℕ} (hq : 2 * q + 1 < d),
  let E := EuclideanSpace ℝ (Fin (q + 1))
  let μ : Measure E := stdGaussian E
  let R : E → ℝ := fun x => ‖x‖ ^ 2
  let L : ℝ := 2 * ((q + 1 : ℕ) : ℝ) + 3 * Real.log (1000 * (d : ℝ))
  let badMoment : E → ℝ := Set.indicator {x : E | L < R x} R
  let tail : ℝ → ℝ := fun s => (μ {x : E | L + s < R x}).toReal
  Integrable badMoment μ ∧ IntegrableOn tail (Set.Ioi (0 : ℝ)) (volume : Measure ℝ) ∧
    (∫ x, badMoment x ∂μ) = L * tail 0 + (∫ s in Set.Ioi (0 : ℝ), tail s ∂volume) ∧
    (∫ x, badMoment x ∂μ) ≤ (L + 3) / (1000 * (d : ℝ))


def sealedConsumer : Prop :=
  ∀ {d q : ℕ} (hq : 2 * q + 1 < d),
  let E := EuclideanSpace ℝ (Fin (q + 1))
  let μ : Measure E := stdGaussian E
  let r : ℝ := ((q + 1 : ℕ) : ℝ)
  let R : E → ℝ := fun x => ‖x‖ ^ 2
  let L : ℝ := 2 * r + 3 * Real.log (1000 * (d : ℝ))
  let a : ℝ := (∫ x, Set.indicator {y : E | R y ≤ L} R x ∂μ) / r
  0 ≤ a ∧ a ≤ 1 ∧
    1 - a = (∫ x, Set.indicator {y : E | L < R y} R x ∂μ) / r ∧
    1 - a ≤ (L + 3) / (1000 * r * (d : ℝ))


open Lean Elab Command

set_option maxHeartbeats 0
set_option maxRecDepth 4096

def origin (env : Environment) (decl : Name) : Name :=
  ((env.getModuleIdxFor? decl).map fun i => env.header.moduleNames[i]!).getD Name.anonymous

def isOwned (env : Environment) (decl : Name) : Bool :=
  let modName := origin env decl
  `AutoSamplingTheory.isPrefixOf modName || `Tests.isPrefixOf modName

partial def reach (env : Environment) (pending : List Name) (seen : NameSet) : NameSet :=
  match pending with
  | [] => seen
  | name :: rest =>
    if seen.contains name then reach env rest seen
    else
      let more := ((env.find? name).map fun info => info.getUsedConstantsAsSet.toList).getD []
      reach env (more ++ rest) (seen.insert name)

def report (target expected literal theoremName : Name) : CommandElabM Unit := do
  let env ← getEnv
  unless origin env target == expected do
    throwError "unexpected target owner: {target} belongs to {origin env target}"
  let some (.thmInfo actual) := env.find? target
    | throwError "target is not a theorem: {target}"
  let some (.defnInfo sealed) := env.find? literal
    | throwError "missing independently elaborated proposition: {literal}"
  unless ← liftTermElabM <| Meta.withTransparency .all <| Meta.isDefEq actual.type sealed.value do
    throwError "sealed type mismatch: {target}"
  liftCoreM <| Lean.addDecl (.thmDecl {
    name := theoremName
    levelParams := []
    type := mkConst literal
    value := mkConst target
  })
  let axioms ← collectAxioms target
  let allowed := [``propext, ``Classical.choice, ``Quot.sound]
  unless axioms.size == allowed.length && axioms.all allowed.contains do
    throwError "unexpected axioms: {target}: {axioms}"
  logInfo m!"TARGET {target} ({origin env target})\nDEFEQ true / KERNEL certificate {theoremName}\nAXIOMS {axioms}"
  let proofRefs := actual.value.getUsedConstantsAsSet.toList
  let typeRefs := actual.type.getUsedConstantsAsSet.toList
  logInfo m!"FIRST PROOF PARENTS {proofRefs.filter (isOwned env)}\nFIRST TYPE PARENTS {typeRefs.filter (isOwned env)}"
  let all := reach env [target] {}
  let owned := (all.toList.filter (isOwned env))
  logInfo m!"TRANSITIVE CLOSURE total {all.toList.length}; owned {owned.length}"
  for name in owned do
    let some info := env.find? name | throwError "missing reachable declaration: {name}"
    let deps := info.getUsedConstantsAsSet.toList.filter (isOwned env)
    logInfo m!"OWNED {name} ({origin env name}) ← {deps}"

run_cmd do
  let env ← getEnv
  let producer := `AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumTruncatedRadialMoment.actual_standard_row_tail_first_moment
  let producerModule := `AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumTruncatedRadialMoment
  let privateUser := `AutoSamplingTheory.Tests.GaussianComplexityFixedSpectrumTruncatedRadialMoment.actual_truncated_radial_bias
  let consumerModule := `Tests.GaussianComplexityFixedSpectrumTruncatedRadialMoment
  let matches := env.constants.fold (init := []) fun found name _ =>
    if privateToUserName? name == some privateUser && origin env name == consumerModule then name :: found else found
  let [consumer] := matches | throwError "expected one exact private consumer: {matches}"
  report producer producerModule `sealedProducer `kernelProducer
  report consumer consumerModule `sealedConsumer `kernelConsumer
