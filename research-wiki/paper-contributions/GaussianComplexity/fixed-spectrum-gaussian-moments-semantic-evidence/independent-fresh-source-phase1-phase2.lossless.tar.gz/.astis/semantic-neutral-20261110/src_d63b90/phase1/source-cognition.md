# Frozen raw-source cognition, before candidate exposure

Reviewer task identity: `/root/source_reader_d63b90`. This is phase 1 only. It makes no fidelity or implementation verdict. No candidate statement, Lean module, reconstruction, prior semantic audit, graph, frontier verdict, repair proposal, Mathlib proof/API, or other reader's report was read.

The sole mathematical source was the pinned local HTML of *On Complexity of Gaussian Sampling*, arXiv:2610.20492v1, SHA-256 `6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915`. The exact raw fragments, source character/line ranges, and digests are in `raw-inputs-manifest.json`. The main cognition covers Section 4.1, Lemma 4.5, its immediate introductory/interpretive paragraphs, and Appendix C.3. The bibliography entry [22] was read only as construction provenance; its linked preprint was not opened. A context search accidentally matched the substring `notation` inside HTML `annotation`, exposing the abstract repeatedly. That incidental raw-source exposure is explicitly recorded and frozen; no candidate information was exposed.

## Source objects and domains

Section 4.1 introduces an integer dimension d >= 2 and real condition parameter kappa >= 2. The coordinate index is i = 1,...,d. It defines

    theta_i = (i - 1/2) pi / d,
    lambda_i = (kappa+1)/2 + ((kappa-1)/2) cos(theta_i),
    Lambda = diag(lambda_1,...,lambda_d).

These are the fixed cosine/Chebyshev grid and its deterministic precision spectrum, not freely chosen angles or positive entries. The family additionally draws O from Haar measure on O(d), independently of algorithm randomness, and puts A = O Lambda O^T, f_A(x) = x^T A x / 2, pi_A = N(0,A^{-1}). The spectrum may be known to the algorithm; the eigenbasis is hidden. Haar randomness is family context, not an input needed by Appendix C.3's diagonal target calculation.

Lemma 4.5 takes U distributed as the centered real d-dimensional Gaussian N(0,Lambda^{-1}). Its actual random quantities are the Euclidean norm squared and a diagonal quadratic form. For each integer 1 <= n < d,

    rho = rho_kappa = (sqrt(kappa)-1)/(sqrt(kappa)+1),
    D_n = diag(cos(n theta_i)),
    M = E ||U||^2,
    mu_n = E[U^T D_n U].

M and mu_n are defined expectations, rather than unconstrained real inputs. Lambda is positive definite: the source derives lambda_i >= 1. Consequently the source uses finite Gaussian moments; these are consequences to discharge, not separate public moment or integrability hypotheses. The proof also derives 0 < rho < 1, M > 0, and (-1)^n mu_n > 0.

The immediate post-lemma paragraph identifies the target-coordinate interpretation: for Y | O ~ pi_A, U = O^T Y has N(0,Lambda^{-1}) law and preserves both ||Y||^2 and Y^T O D_n O^T Y. This is an interpretation of the computed target statistics. It does not add an algorithm-output premise to Lemma 4.5.

## Exact conclusions and quantifier scope

For every d >= 2, kappa >= 2 and every integer n with 1 <= n < d, the lemma concludes both exact means:

    M = (d/sqrt(kappa)) (1-rho^(2d))/(1+rho^(2d)),
    (-1)^n mu_n = (d/sqrt(kappa))
                    (rho^n-rho^(2d-n))/(1+rho^(2d)).

It also concludes each of

    Var(||U||^2) <= 2M <= 2d/sqrt(kappa),
    Var(U^T D_n U) <= 2M <= 2d/sqrt(kappa).

Only the final normalized-bias estimate has the additional condition

    d - n >= sqrt(kappa).

Under that condition the exact statement is

    (1-exp(-4)) exp(-3n/sqrt(kappa))
        <= |mu_n|/M <= exp(-2n/sqrt(kappa)).

The upper bound is in fact established in the proof without the additional separation condition, but the displayed lemma places the two-sided estimate together under that condition. The means and variances carry no separation condition. No delta, epsilon, query count, asymptotic dimension condition, kappa <= d^(1-delta), bound on arbitrary coefficients, or algorithm-success hypothesis belongs to this lemma.

## Appendix C.3: independent source proof organization

The source has one forward route with two explicitly named facts followed by the variance and normalized-bias arguments. It does not present alternative OR-routes.

1. `A3.SS3.p1`: recalls the grid and spectrum and announces inverse-spectrum expansion, exact grid summation, variance control, normalized cosine bias.
2. Fact C.7, `A3.Thmtheorem7` / `A3.Ex133`: for every real theta,

       2/(kappa+1+(kappa-1) cos(theta))
          = (1/sqrt(kappa))
              (1 + 2 sum_{j>=1} (-rho)^j cos(j theta)),

   with absolute and uniform convergence in theta. This inherits kappa >= 2 and rho's definition from the surrounding lemma proof. It is not a bare theorem with free independent rho and kappa.
3. C.7 proof `A3.SS3.2` / paragraph p2 uses 0<rho<1 and the geometric series. Displays Ex134-135 turn the complex exponential sums into the Poisson-kernel expression `(1-rho^2)/(1+2 rho cos(theta)+rho^2)`. Ex136 supplies the two algebraic identities `(1-rho)/(1+rho)=1/sqrt(kappa)` and `(1+2 rho cos(theta)+rho^2)/(1-rho)^2=(kappa+1+(kappa-1)cos(theta))/2`. Ex137 bounds the absolute cosine series by `rho/(1-rho)`, uniformly in theta. The bound is for each fixed kappa; no uniformity as kappa approaches an endpoint is asserted.
4. Fact C.8, `A3.Thmtheorem8` / Ex138: exactly the two finite-grid mean formulas above, for 1<=n<d.
5. C.8 proof `A3.SS3.3`, paragraph p3 / Ex139: for every integer k,

       sum_{i=1}^d cos(k theta_i)
          = d (-1)^a, if k = 2ad for a in Z;
          = 0, otherwise.

   The source justifies the nonmultiple case using `sin(k pi)/(2 sin(k pi/(2d)))=0`, and the multiple case term by term. The nonmultiple condition is essential to the denominator being nonzero.
6. Paragraph p4 / Ex140 obtains `M=sum_i 1/lambda_i` and `mu_n=sum_i cos(n theta_i)/lambda_i` from E U_i^2=1/lambda_i. C.7's absolute convergence permits interchange with the finite grid sum.
7. Paragraph p5 / Ex141-143: only j=2ad, a>=1 survive for M. The resulting alternating geometric series gives the exact M formula.
8. Paragraph p6 / Ex144-147: the constant mode sums to zero since 1<=n<d. Product-to-sum reduces the cosine-weighted sum to frequencies j-n and j+n. The surviving positive j classes are j=n; j=2ad+n for a>=1; and j=2ad-n for a>=1. They are disjoint because 1<=n<d. Their signs combine using `(-rho)^(2ad +/- n)=(-1)^n rho^(2ad +/- n)`. Two geometric tails give the exact mu_n formula. The frequency indexing, signs, and subtraction of the reflected term rho^(2d-n) are substantive content.
9. Lemma proof `A3.SS3.4`, p7 cites C.8 for both means.
10. Paragraph p8 / Ex148-149: diagonal Gaussian covariance gives independent centered coordinates with variances 1/lambda_i, fourth moments 3/lambda_i^2, and squared-coordinate variance 2/lambda_i^2. Using lambda_i>=1 and cos^2<=1 gives the two variance bounds, followed by M<=d/sqrt(kappa) from the exact formula.
11. Paragraph p9 / Ex150-151: n<d and 0<rho<1 give `(-1)^n mu_n>0`. Dividing the means yields

        |mu_n|/M = rho^n
             (1-rho^(2(d-n)))/(1-rho^(2d)).

    The fraction lies between `1-rho^(2(d-n))` and 1, because `0<rho^(2d)<rho^(2(d-n))<1`. Positivity is discharged within the argument before division/absolute-value removal.
12. Paragraph p10 / Ex152-157: the logarithm is represented as

        log(1/rho) = 2 integral_0^(1/sqrt(kappa)) 1/(1-t^2) dt
                   = 2/sqrt(kappa)
                     + 2 integral_0^(1/sqrt(kappa)) t^2/(1-t^2) dt.

    Nonnegativity gives the lower bound 2/sqrt(kappa). Bounding `1-t^2 >= 1-1/kappa` and integrating t^2 gives the upper bound `2/sqrt(kappa) (1+1/(3(kappa-1))) <= 8/(3 sqrt(kappa)) < 3/sqrt(kappa)`, using kappa>=2. Exponentiation yields `exp(-3n/sqrt(kappa)) <= rho^n <= exp(-2n/sqrt(kappa))`.
13. Paragraph p11 / Ex158-159: the separation condition gives `rho^(2(d-n)) <= exp(-4(d-n)/sqrt(kappa)) <= exp(-4)`. This combines with steps 11 and 12 to finish the two-sided estimate.

Every substantive paragraph p1-p11 and every displayed equation/group in Appendix C.3 is accounted for above. Nested table/tbody wrappers and theorem/proof containers are structural grouping, not extra mathematical obligations; their exact inventory and line ranges are frozen in `source-unit-inventory.json`. Section 4.1 definition/Eq11 and the Gaussian coordinate interpretation are source context. Remark 4.2 is read context for the construction, but its downstream query-complexity comparison is excluded from the present mathematical proof slice. The abstract is incidental exposure and excluded. Citation [22], Section 9.2 supplies stated construction provenance; no external result from that preprint is invoked inside C.3's proof.

## Source omissions, ordinary implicit facts, and ambiguity boundary

The source does not reprove the complex geometric-series theorem, product-to-sum identity, finite cosine-sum formula, Gaussian covariance-to-independence fact, univariate Gaussian fourth moment, variance additivity for independent variables, Gaussian finite-moment facts, basic logarithm/exp identities, or the elementary integral antiderivative/FTC steps. These are identifiable standard mathematical dependencies used by the source; they are not additional assumptions on U, the grid, or the parameters. A formal treatment must discharge the applicable conditions rather than making the desired conclusions public premises.

The standalone wording of Fact C.7 does not repeat kappa>=2 or rho's definition, and Fact C.8 does not repeat the Gaussian/grid definitions; their inherited scope is supplied by the C.3 introduction and Lemma 4.5. The dimension convention is inherited from Section 4.1 rather than repeated in Lemma 4.5's first sentence. Integer positive mode indices and i=1,...,d are fixed by the source formulas. A formal adapter using zero-based coordinates must preserve `(i+1/2) pi/d`, not reuse the printed `(i-1/2)` on i=0,...,d-1.

No source-level algebraic contradiction was found in this bounded reading. This is a source cognition observation, not a candidate fidelity verdict, proof compilation claim, graph admission, or acceptance of any future repair. The exact-vs-subresult question must be assessed only once a later authorized anonymous reconstruction is supplied: C.7 alone, C.8 alone, the variance estimates alone, and the complete Lemma 4.5 are distinct source boundaries.
