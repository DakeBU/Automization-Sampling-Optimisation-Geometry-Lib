from pathlib import Path
import gzip, hashlib, json, subprocess, tarfile
P = Path('.astis/huanjian-gc-fixed-spectrum-geometry-20261109')
B = Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-geometry-semantic-evidence')
sha = lambda b: hashlib.sha256(b).hexdigest()
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == '54273a30ec293ce53f770905856c4322d291abb9'
assert not subprocess.check_output(['git', 'diff', '--cached', '--name-only']).strip()
checks = B/'admission-actual-checks'
checks.mkdir()
names = ['20261108T175152186804Z-fixed-spectrum-geometry-parent-source-packet',
         '20261108T180739881172Z-fixed-spectrum-preintegration-origin-main-network',
         '20261108T180953650566Z-fixed-spectrum-geometry-normal-admitted-intake',
         '20261108T181049818305Z-fixed-spectrum-geometry-admission-frontier',
         '20261108T181049818371Z-fixed-spectrum-geometry-admission-contributor',
         '20261108T181049818245Z-fixed-spectrum-geometry-bounded-publication-packet']
for name in names:
    p = Path('.astis/huanjian-resume-20261103')/(name+'.receipt.json')
    r = json.loads(p.read_bytes())
    raw = Path(r['log']).read_bytes()
    assert r['exit_code'] == 0 and sha(raw) == r['log_sha256']
    assert r['head_before'] == r['head_after'] == '54273a30ec293ce53f770905856c4322d291abb9'
    (checks/p.name).write_bytes(p.read_bytes())
    z = checks/(Path(r['log']).name+'.gz')
    z.write_bytes(gzip.compress(raw, mtime=0))
    assert gzip.decompress(z.read_bytes()) == raw
files = sorted(p for p in B.rglob('*') if p.is_file())
tracked = set(subprocess.check_output(['git', 'ls-files', '-z']).decode().split('\0'))
ignored_result = subprocess.run(['git', 'check-ignore', '-z', '--stdin'],
    input=b'\0'.join(str(p).encode() for p in files)+b'\0', capture_output=True)
assert ignored_result.returncode in (0, 1)
ignored = set(ignored_result.stdout.decode().split('\0'))
def unsafe(p):
    raw = p.read_bytes()
    if p.suffix in ['.gz', '.png', '.zip'] or b'\0' in raw: return False
    return b'\r\n' in raw or raw.endswith(b'\n\n') or any(line.endswith((b' ', b'\t')) for line in raw.splitlines())
excluded = [p for p in files if str(p) not in tracked and (str(p) in ignored or unsafe(p) or p.name.endswith('.raw.html'))]
originals = set(excluded+list(P.glob('*.py'))+[P/'normal-intake-started.json'])
for rel in ['source-only-review/phase1/phase1-freeze.json', 'source-only-review/phase2/phase2-freeze.json',
            'topology-challenge/phase1/manifest.json', 'topology-challenge/phase2/manifest.json']:
    manifest = json.loads((B/rel).read_bytes())
    for row in manifest['files']:
        p = Path(row['path'])
        assert sha(p.read_bytes()) == row['sha256']
        originals.add(p)
originals = sorted(originals)
archive, manifest = B/'independent-preproof-originals.lossless.tar.gz', B/'independent-preproof-originals.manifest.json'
assert not archive.exists() and not manifest.exists()
with tarfile.open(archive, 'w:gz') as t:
    for p in originals: t.add(p, arcname=str(p), recursive=False)
with tarfile.open(archive, 'r:gz') as t:
    assert len(t.getmembers()) == len(originals)
    for p in originals: assert t.extractfile(str(p)).read() == p.read_bytes()
manifest.write_text(json.dumps({'archive': str(archive), 'sha256': sha(archive.read_bytes()),
    'originals_retained_unchanged': True, 'source_and_interface_admission_only_not_mathematical_proof': True,
    'files': [{'original': str(p), 'member': str(p), 'raw_sha256': sha(p.read_bytes()), 'raw_bytes': p.stat().st_size} for p in originals]}, ensure_ascii=False, indent=2)+'\n')
mutable = [Path('runs/substantive_advances.jsonl'),
    Path('research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-geometry.json'),
    Path('research-wiki/paper-contributions/GaussianComplexity/README.md')]
paths = sorted(set([p for p in files if p not in excluded]+mutable+[archive, manifest]))
subprocess.run(['git', 'add', '--', *map(str, paths)], check=True)
staged = subprocess.check_output(['git', 'diff', '--cached', '--name-only', '-z']).decode().strip('\0').split('\0')
for name in staged:
    p = Path(name)
    assert p in mutable or p.is_relative_to(B), name
    assert subprocess.check_output(['git', 'show', ':'+name]) == p.read_bytes(), name
for p in mutable: assert subprocess.check_output(['git', 'show', ':'+str(p)]) == p.read_bytes()
subprocess.run(['git', 'diff', '--cached', '--check'], check=True)
out = B/'admission-staging-readback.json'
assert not out.exists()
out.write_text(json.dumps({'stage': 'EXACT_PREPROOF_ADMISSION_NO_NEW_LEAN_THEOREM',
    'staged_before_this_result': len(staged), 'all_staged_index_bytes_equal_live': True,
    'mutable_direct_index_bytes': {str(p): sha(p.read_bytes()) for p in mutable},
    'frozen_raw_originals_lossless': len(originals), 'archive_sha256': sha(archive.read_bytes()),
    'unsafe_or_ignored_raw_originals_not_staged_directly': [str(p) for p in excluded],
    'foreign_or_production_or_shared_path_staged': False, 'new_source_VERIFIED_or_Goal_complete': False}, ensure_ascii=False, indent=2)+'\n')
subprocess.run(['git', 'add', '--', str(out)], check=True)
assert subprocess.check_output(['git', 'show', ':'+str(out)]) == out.read_bytes()
subprocess.run(['git', 'diff', '--cached', '--check'], check=True)
print(json.dumps({'staged_paths': len(staged)+1, 'lossless_originals': len(originals),
    'all_mutable_and_staged_bytes_exact': True, 'target_proof_exists': False}))
