from pathlib import Path
from copy import deepcopy
import hashlib,json
root=Path('/Users/zhouhuanjian/ASTIS-GC')
base=root/'.astis/huanjian-gc-fixed-spectrum-bias-20261110/independent-source-graph'
p1=base/'phase1';prev=base/'phase2';out=prev/'clarification-v2'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
load=lambda p:json.loads(p.read_text())
enc=lambda x:(json.dumps(x,indent=2,ensure_ascii=False)+'\n').encode()
canonical=lambda x:hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()
assert sha(p1/'phase1-freeze.json')=='68309ef6d866f304eb8f1fcc333736033fac96da40aed870d9d1b09cc22d300b'
assert sha(prev/'phase2-freeze.json')=='7c4b146f87028cee63f355bc6cf7b846c9e272d16adca7ccbb82396337d66de0'
for f in [load(p1/'phase1-freeze.json'),load(prev/'phase2-freeze.json')]:
 for a in f['artifacts']:assert sha(root/a['path'])==a['sha256']
g0=load(prev/'source-proof-graph.json');c0=load(prev/'exact-target-coverage.json');r0=load(prev/'root-closures.json');a0=load(prev/'statement-projection-audit.json')
projection=root/'.astis/huanjian-gc-fixed-spectrum-bias-20261110/strict-preproof-seal-projection-v1.json'
assert sha(projection)=='b245ddf40403f7aca7d2f0be6de9953cf1fb2bda57e840d9ee6bf6156aac8511'
p=load(projection)
for role in ['producer','actual_private_consumer']:
 assert hashlib.sha256(p[role]['signature'].encode()).hexdigest()==p[role]['signature_sha256']
assert p['producer']['signature']==a0['producer']['exact_signature']
assert p['actual_private_consumer']['signature']==a0['private_consumer']['exact_signature']
g=deepcopy(g0);changes=[]
def change(obj,field,new,pointer,kind,reason):
 old=deepcopy(obj.get(field));existed=field in obj
 obj[field]=new
 changes.append({'json_pointer':pointer+'/'+field,'change_type':'replace' if existed else 'add','semantic_type':kind,'old_value':old,'new_value':deepcopy(new),'reason':reason})
ni={n['id']:i for i,n in enumerate(g['nodes'])};ei={e['id']:i for i,e in enumerate(g['routes'])}
k=ni['G_power_log_exp'];n=g['nodes'][k]
change(n,'statement','For each nonnegative exponent k, use ρ^k=exp(−k log(1/ρ)). Order reverses when a logarithmic inequality is multiplied by −k≤0, not when multiplied by k≥0; exp is increasing and preserves the resulting inequality. The source uses k=n>0 and k=2(d−n)>0, with real casts/power identities justified internally.','/nodes/'+str(k),'SIGN_AND_ORDER_CLARIFICATION','Original wording incorrectly attributed reversal to multiplying by a nonnegative mode. The source exponent contains the negative coefficient −k.')
k=ni['G_Chebyshev'];n=g['nodes'][k]
change(n,'statement','Generic conditional positive-threshold rule for the actual finite centered second moment: for any real t with 0<t, μ{|F−E F|≥t}.toReal≤Var(F)/t². This rule does not assert 0<t or E F>0. At the local zero-threshold application take t=m=E F; the separate parent N_signed_actual_mean supplies the actual m>0. The source names Chebyshev without expanding this rule.','/nodes/'+str(k),'CONDITIONAL_RULE_CLARIFICATION','Keep threshold positivity as a conditional proof-rule premise until actual application; no free background positivity or omitted parent.')
condition={'id':'chebyshev_threshold_positive','formula':'0 < t','kind':'conditional rule premise, not a proved fact','actual_application_route':'r_zerocheb','actual_instantiation':'t := m = ∫F dμ','actual_discharge_parent':'N_signed_actual_mean','discharge_status':'Explicit internal application obligation; N_signed_actual_mean must itself be proved. No mathematical completion is claimed.'}
change(n,'conditional_premises',[condition],'/nodes/'+str(k),'TYPED_CONDITIONAL_PREMISE','Expose the premise/instantiation/discharge at the actual consumer use site.')
k=ei['r_cheb'];e=g['routes'][k]
change(e,'description','Provide the conditional Chebyshev rule instantiated to actual F: ∀t:ℝ, 0<t → μ{|F−E F|≥t}.toReal≤Var(F)/t². G_sign_centered supplies actual finite centered second moment and G_event_probability supplies actual probability/event semantics. No actual mean-positivity conclusion is produced by this route.','/routes/'+str(k),'CONDITIONAL_EDGE_SEMANTICS','Its existing input set is sufficient for the conditional rule; actual positive mean is supplied only at r_zerocheb.')
change(e,'conclusion_kind','conditional rule; positive threshold not yet discharged','/routes/'+str(k),'TYPED_CONDITIONAL_EDGE','Distinguish a conditional general rule from an already applicable actual-mean inequality.')
k=ei['r_zerocheb'];e=g['routes'][k]
change(e,'description','Instantiate G_Chebyshev at t=m=E F. The existing incoming parent N_signed_actual_mean proves m=(−1)^n b=|b|>0 and discharges 0<t. Then {F≤0}⊆{|F−m|≥m}; G_sign_centered supplies actual Var(F)≤2M, and G_event_probability supplies actual measurable finite probability, yielding μ(E₀).toReal≤Var(F)/m²≤2M/m².','/routes/'+str(k),'ACTUAL_CONDITION_DISCHARGE','Actual positivity remains an incoming dependency, already present in r_zerocheb; no new public assumption or free threshold fact.')
change(e,'conditional_premise_discharges',[{'conditional_node':'G_Chebyshev','premise_id':'chebyshev_threshold_positive','instantiation':'t := m = ∫F dμ','required_formula':'0 < m','incoming_parent':'N_signed_actual_mean','parent_in_inputs':True,'status':'proof dependency, not a certified completed proof'}],'/routes/'+str(k),'TYPED_ACTUAL_DISCHARGE','Make the positivity discharge machine-visible at the exact actual event application.')
assert g['routes'][ei['r_cheb']]['inputs']==g0['routes'][ei['r_cheb']]['inputs']
assert g['routes'][ei['r_zerocheb']]['inputs']==g0['routes'][ei['r_zerocheb']]['inputs']
assert 'N_signed_actual_mean' in g['routes'][ei['r_zerocheb']]['inputs']
# Only the exact descriptive/conditional fields listed above may change in semantic arrays.
check=deepcopy(g)
for ch in reversed(changes):
 parts=ch['json_pointer'].strip('/').split('/');obj=check
 for q in parts[:-1]:obj=obj[int(q)] if isinstance(obj,list) else obj[q]
 field=parts[-1]
 if ch['change_type']=='replace':obj[field]=ch['old_value']
 else:del obj[field]
assert check==g0
lineage_base={'predecessor_freeze':{'path':str((prev/'phase2-freeze.json').relative_to(root)),'sha256':sha(prev/'phase2-freeze.json')},'unchanged_raw_freeze':{'path':str((p1/'phase1-freeze.json').relative_to(root)),'sha256':sha(p1/'phase1-freeze.json')},'unchanged_projection':{'path':str(projection.relative_to(root)),'sha256':sha(projection),'unread_full_seal_sha256':p['seal_sha256']},'feedback_authority':'Parent-delivered exact two-point preliminary typed clarification request from distinct challenger. No challenger artifact/final verdict or other actor mathematics was read.','intermediate_status':'Append-only original-author clarification; independent review/admission remains pending, and further challenger findings may require another successor.'}
outputs={}
typed={'schema':1,'status':'TYPED_PRECISION_SUCCESSOR_PENDING_DISTINCT_CHALLENGE','lineage':lineage_base,'changes':changes,'exact_allowed_semantic_field_change_count':len(changes),'unchanged':['All source anchor raw fields and source/Lean statement signatures','All graph node IDs and route IDs','Every route input/consumer/AND topology field','All366 raw source rows and earlier204/162 history','All exact-target successor NODE/EXCLUDED dispositions and fragment/exclusion reasons','All producer/consumer root node and route sets'],'classification':'Both changes clarify existing internal proof obligations. No source-paper statement, exact target signature, theorem premise, numerical constant or event definition is changed.','no_acceptance':'No mathematical proof, source coverage approval, challenger final verdict or VERIFIED transition.'}
outputs['typed-changes-v2.json']=enc(typed);typed_sha=hashlib.sha256(outputs['typed-changes-v2.json']).hexdigest()
g['schema']=2
g['binding_successor']={'artifact_predecessor':{'path':str((prev/'source-proof-graph.json').relative_to(root)),'sha256':sha(prev/'source-proof-graph.json')},'typed_change_record':{'path':str((out/'typed-changes-v2.json').relative_to(root)),'sha256':typed_sha},'projection_unchanged_sha256':sha(projection),'semantic_change_scope':'Only the two SOURCE_GAP descriptions and typed conditional/discharge edge semantics listed in the change record. Route parents and every source anchor unchanged.','route_parent_sets_canonical_sha256_unchanged':canonical([{'id':e['id'],'consumer':e['consumer'],'inputs':e['inputs'],'logic':e['logic']} for e in g['routes']]),'status':'INTERMEDIATE_ORIGINAL_AUTHOR_CLARIFICATION_NOT_SELF_ACCEPTED'}
outputs['source-proof-graph-v2.json']=enc(g);gsha=hashlib.sha256(outputs['source-proof-graph-v2.json']).hexdigest()
c=deepcopy(c0);c['schema']=2;c['graph_sha256']=gsha
c['binding_successor']={'artifact_predecessor':{'path':str((prev/'exact-target-coverage.json').relative_to(root)),'sha256':sha(prev/'exact-target-coverage.json')},'current_graph_sha256':gsha,'typed_change_sha256':typed_sha,'rows_unchanged':True,'predecessor_rows_canonical_sha256':canonical(c0['rows']),'current_rows_canonical_sha256':canonical(c['rows']),'interpretation':'No coverage disposition changed. Rebinding is explicit because the graph descriptions/typed conditional fields were clarified; all raw history remains unchanged.'}
outputs['exact-target-coverage-binding-v2.json']=enc(c);csha=hashlib.sha256(outputs['exact-target-coverage-binding-v2.json']).hexdigest()
r=deepcopy(r0);r['schema']=2;r['graph_sha256']=gsha;r['coverage_sha256']=csha
r['binding_successor']={'artifact_predecessor':{'path':str((prev/'root-closures.json').relative_to(root)),'sha256':sha(prev/'root-closures.json')},'current_graph_sha256':gsha,'current_coverage_sha256':csha,'typed_change_sha256':typed_sha,'closure_node_and_route_sets_unchanged':True,'predecessor_closures_canonical_sha256':canonical(r0['closures']),'current_closures_canonical_sha256':canonical(r['closures'])}
r['conditional_premise_audit']={'generic_rule_node':'G_Chebyshev','rule_route':'r_cheb','generic_conditional_premise':'0<t','actual_application_route':'r_zerocheb','actual_threshold':'m=E F','actual_positive_threshold_parent':'N_signed_actual_mean','application_parent_present':True,'parent_present_in_consumer_root':('N_signed_actual_mean' in r['closures']['private_actual_consumer']['nodes']),'premise_discharge':'Internal dependency only; positive actual signed mean must be proved, never assumed as an added public binder.','producer_root_affected':False,'consumer_topology_changed':False}
outputs['root-closures-binding-v2.json']=enc(r)
projection_binding={'schema':1,'status':'UNCHANGED_EXACT_STATEMENTS_BOUND_TO_TYPED_GRAPH_SUCCESSOR','projection':lineage_base['unchanged_projection'],'unchanged_statement_audit':{'path':str((prev/'statement-projection-audit.json').relative_to(root)),'sha256':sha(prev/'statement-projection-audit.json')},'producer_signature_sha256':p['producer']['signature_sha256'],'private_consumer_signature_sha256':p['actual_private_consumer']['signature_sha256'],'current_graph_sha256':gsha,'typed_change_sha256':typed_sha,'statement_change':False,'definition_change':False,'binder_change':False,'no_new_private_numeric_assumption':True,'no_new_proof_or_admission_claim':True}
outputs['statement-projection-binding-v2.json']=enc(projection_binding)
inputs={'schema':1,'phase':'BOUNDED_ORIGINAL_AUTHOR_TYPED_CLARIFICATION','lineage':lineage_base,'file_inputs':[{'path':str((q).relative_to(root)),'sha256':sha(q)} for q in [p1/'phase1-freeze.json',prev/'phase2-freeze.json',prev/'source-proof-graph.json',prev/'exact-target-coverage.json',prev/'root-closures.json',prev/'statement-projection-audit.json',projection]],'permitted_nonfile_input':'Parent exact two-point preliminary request: negative-exponent order sign and positive-threshold Chebyshev conditional/actual discharge distinction.','not_read':['Final challenger report or HOLD artifact','Implementation/API/Mathlib/proof/lesson/other-agent files','Full source seal or root private rationale'],'not_run':['Lean/proof search/build','API/harness/network/global mutation'],'script_sha256':sha(out/'freeze_clarification.py'),'phase1_and_v1_all_artifact_hashes_rechecked_unchanged':True,'append_only_output_directory':str(out.relative_to(root))}
outputs['machine-inputs-v2.json']=enc(inputs)
binding={'schema':1,'lineage':lineage_base,'typed_change_sha256':typed_sha,'successors':[{'path':str((out/n).relative_to(root)),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)} for n,b in outputs.items()],'invariance':{'graph_ids_and_route_parent_sets_unchanged':True,'raw_rows_and_history_unchanged':c['rows']==c0['rows'],'root_node_and_route_sets_unchanged':r['closures']==r0['closures'],'exact_source_and_statement_signature_hashes_unchanged':True},'correction_scope':'Two typed descriptive/conditional proof-obligation clarifications only; retain this record as intermediate history if later review raises further issues.'}
outputs['binding-lineage-v2.json']=enc(binding)
for f in [load(p1/'phase1-freeze.json'),load(prev/'phase2-freeze.json')]:
 for a in f['artifacts']:assert sha(root/a['path'])==a['sha256']
for n in list(outputs)+['clarification-freeze-v2.json']:assert not (out/n).exists(),n
for name,data in outputs.items():
 with (out/name).open('xb') as f:f.write(data)
freeze={'schema':1,'status':'APPEND_ONLY_TYPED_CLARIFICATION_FROZEN_PENDING_FINAL_CHALLENGE','lineage':lineage_base,'artifacts':[{'path':str((out/n).relative_to(root)),'sha256':sha(out/n),'bytes':(out/n).stat().st_size} for n in ['freeze_clarification.py']+list(outputs)],'source_statement_signatures_unchanged':True,'phase1_v1_bytes_unchanged':True,'topology_and_root_sets_unchanged':True,'new_source_coverage_self_acceptance':False,'intermediate_history':True}
with (out/'clarification-freeze-v2.json').open('xb') as f:f.write(enc(freeze))
print(json.dumps({'freeze_sha256':sha(out/'clarification-freeze-v2.json'),'corrected_fields':[ch['json_pointer'] for ch in changes],'artifacts':freeze['artifacts']},indent=2))
