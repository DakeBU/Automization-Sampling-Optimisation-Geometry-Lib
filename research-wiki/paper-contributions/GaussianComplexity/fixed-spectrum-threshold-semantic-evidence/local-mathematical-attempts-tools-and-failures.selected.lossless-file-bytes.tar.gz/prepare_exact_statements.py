from pathlib import Path
import json, hashlib, datetime, subprocess

W=Path(__file__).parent
def put(name, text):
    p=W/name
    assert not p.exists(), p
    p.write_text(text)

head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert head=='e8427141e6119012745a8913596c38c3b0600dbc'
base='''(C : ℝ) (hC : 0 < C) {δ : ℝ} (hδ0 : 0 < δ) (hδ1 : δ < 1) :
  ∃ d₀ : ℕ, ∀ (d : ℕ), d₀ ≤ d → ∀ (κ : ℝ), 2 ≤ κ →
    κ ≤ (d : ℝ) ^ (1 - δ) → ∀ (q : ℕ),
    (q : ℝ) ≤ (δ / 256) * Real.sqrt κ * Real.log (d : ℝ) →
    let n : ℕ := 2 * q + 1
    let θ : Fin d → ℝ := fun i => ((i.val : ℝ) + 1 / 2) * Real.pi / (d : ℝ)
    let eigenvalue : Fin d → ℝ := fun i => (κ + 1) / 2 + (κ - 1) / 2 * Real.cos (θ i)
    let Λ : Matrix (Fin d) (Fin d) ℝ := Matrix.diagonal eigenvalue
    let μ : Measure (EuclideanSpace ℝ (Fin d)) :=
      multivariateGaussian (0 : EuclideanSpace ℝ (Fin d)) Λ⁻¹
    let Q : EuclideanSpace ℝ (Fin d) → ℝ := fun x =>
      ∑ i : Fin d, Real.cos ((n : ℝ) * θ i) * (WithLp.ofLp x i) ^ 2
    let τ : ℝ := C * (((q : ℝ) + 1) * Real.sqrt (Real.log (d : ℝ) / (d : ℝ)) +
      (((q : ℝ) + 1) * ((q : ℝ) + 1 + Real.log (d : ℝ)) * Real.log (d : ℝ)) / (d : ℝ))
'''
prod='theorem eventual_actual_gaussian_threshold_small '+base+'''    let M : ℝ := ∫ x : EuclideanSpace ℝ (Fin d), ‖x‖ ^ 2 ∂μ
    let b : ℝ := ∫ x : EuclideanSpace ℝ (Fin d), Q x ∂μ
    let β : ℝ := |b| / M
    0 ≤ τ ∧ τ ≤ 1 / 2 ∧ τ ≤ β / 4
'''
cons='private theorem actual_gaussian_source_query_shifted_event_le_tenth '+base+'''    (μ {x | (-1 : ℝ) ^ n * Q x - 2 * τ * ‖x‖ ^ 2 ≤ 0}).toReal ≤ (1 : ℝ) / 10
'''
put('producer-signature.txt',prod)
put('consumer-signature.txt',cons)
formation='''import AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumSignalStrength
import AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumVariances
noncomputable section
open MeasureTheory ProbabilityTheory
open scoped BigOperators
namespace ThresholdStatementFormation
'''
for kind,sig in [('producer',prod),('consumer',cons)]:
    start=sig.index('(C : ℝ)')
    body=sig[start:].replace(' :\n  ∃ d₀', ' : Prop :=\n  ∃ d₀',1)
    formation+='\ndef '+kind+'_statement '+body
formation+='\nend ThresholdStatementFormation\n'
put('StatementFormation.lean',formation)
exposure={
 'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'working_HEAD':head,
 'root_prior_exposure':'Root authored prior Gaussian packets and knows original source, previous proofs, source/topology/whole-module review outcomes. No pristine ignorance claim.',
 'scope_selection_informal_mathematics':'Earlier context considered numeric C>0 concrete tau formula, its uniform power-log smallness against actual beta and a shifted Gaussian contrast; root has now read original Section4 text, the existing ModeGap producer and earlier actual zero-event Test, and searched existing filenames/target names and logarithmic asymptotic API names. It has informal expectations about bounding q+1, tau via powers/logs, beta via the earlier bias producer, then actual variance/Chebyshev. These are scope-selection/provisional plans, NOT independent source topology or a proved theorem.',
 'preseal_tools':'Existing theorem/consumer inspection and read-only reuse-name search, raw source extraction, protocol/process-memory reading and exact Prop signature formation. First raw source extraction with system python failed only because bs4 absent; installed /opt/anaconda3 Python succeeded. No new target proof body, proof experiment, normal API, new SAU, frontier, global site or STAB mutation.',
 'C_scope':'C is an arbitrary fixed positive numeric scale, before delta and cutoff. It does not assert an absolute concentration constant exists or works. After a future independent concentration theorem produces ONE absolute C, this family specializes without an additional assumption on the MAIN lower bound. Source theorem4.1 remains unchanged/unproved.',
 'roles':'Raw-first source extractor and distinct topology challenger are independently reading original source before this exact target. No implementation or root route plans supplied to them.'
}
put('preseal-exposure-disclosure.json',json.dumps(exposure,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'producer_signature_sha256':hashlib.sha256(prod.encode()).hexdigest(),'consumer_signature_sha256':hashlib.sha256(cons.encode()).hexdigest(),'formation_sha256':hashlib.sha256(formation.encode()).hexdigest(),'proof_started':False}))
