from pathlib import Path
import datetime, hashlib, json

OUT=Path(__file__).resolve().parent; ROOT=OUT.parents[2]
sealpath=ROOT/'.astis/huanjian-gc-source-matrix-structure-20261113/statement-seal-v2.json'
seal=json.loads(sealpath.read_text()); sealhash=hashlib.sha256(sealpath.read_bytes()).hexdigest()
assert sealhash=='0164b6bcb7f1362c27e459eccf6a68a72a7cea81272f15377e7c193af18e3c60'
ids=json.loads((OUT/'type-code-identities.stdout').read_text())
def api(path,a,z,meaning): return {'path':path,'lines_1based':[a,z],'file_sha256':ids[path],'meaning':meaning}
audit={
 'seal_id':seal['seal_id'],'seal_path':str(sealpath.relative_to(ROOT)),'seal_sha256':sealhash,
 'producer_signature_sha256':seal['producer']['signature_sha256'],
 'consumer_signature_sha256':seal['actual_private_consumer']['signature_sha256'],
 'status':'SOURCE-ONLY EXTRACTION AND BINDER/DEFINITION AUDIT; independent topology review and source/normalV acceptance remain pending',
 'raw_first_ordering':{'source_freeze':'RAWFREEZE.json','corrected_readable_derivative':'RAWFREEZE.v2.json',
    'topology_freeze':'TOPOLOGY-RAWFREEZE.json','first_signature_read_receipts':['v2-seal-read.receipt.json','v2-signatures-read.receipt.json'],
    'implementation_target_proof_read':False,'prior_source_graph_or_verdict_read':False},
 'binders':[
  {'name':'d q : ℕ','class':'TYPING','expansion':'Finite dimension and nonnegative integer degree/query budget. Source q>=0 is represented by q:Nat; no q>0 restriction.','source_ids':['S4.Thmtheorem4.p1.1']},
  {'name':'hq : 2*q+1<d','class':'SOURCE','expansion':'Exact source regime. Derive d>=2,d>0,r=q+1>0 and 2r<=d internally; do not add any positivity/cutoff/size caller certificate.','source_ids':['S4.Thmtheorem4.p1.1']},
  {'name':'letI MeasurableSpace Matrix := borel Matrix','class':'TYPING','expansion':'A fixed locally defined standard sigma algebra, not a quantified hypothesis or Prop alias. Coordinate equivalence audited below.'}
 ],
 'recursive_expansion':'No project-owned Prop alias/structure/typeclass is a public logical input. All remaining lets are explicit objects and definitions. The local measurable-space definition is fully expanded to borel of the selected finite matrix product topology.',
 'EXCESS':[],
 'source_assumptions_encoded_as_definitions':[
   'D=EuclideanSpace R (Fin d); Omega=Fin(q+1)->D; mu=Measure.pi (fun _ => stdGaussian D) is the canonical realization of the original independent standard Gaussian columns g_a.',
   'No independence, mean, moment, measurability, integrability, Hermitian, norm, variance or concentration certificate is supplied by the caller.'
 ],
 'definitions':[
  {'name':'D,E,Omega,mu','kind':'literal','meaning':'Original g_a are the coordinate projections omega a under finite product standard Gaussian columns. E is Euclidean r-space for actual physical rows. This fixes the same original unconditional mu for Y, mean, Z and X; no conditional or surrogate law.','source_ids':['S4.Thmtheorem4.p1.1','A3.SS2.p1.2'],'unproved_internal_requirements':['Probability mass mu(univ)=1','Row measurability/law and row independence from original column experiment']},
  {'name':'r,L','kind':'literal','meaning':'r=(q+1):R; L=2*r+3*log(1000*d), exactly source p10. No clamp/default or user-chosen cutoff.','source_ids':['A3.SS2.p1.1','A3.SS2.p10.1']},
  {'name':'theta,t','kind':'literal','meaning':'Fin d uses zero-based i.val, so (i.val+1-1/2)*pi/d is source theta_(i+1). t coordinate0=1, coordinate k>0=sqrt(2)*cos(k*theta); k runs0..q. All are deterministic.','source_ids':['S4.E11','A3.Ex85']},
  {'name':'row','kind':'literal','meaning':'row i omega=WithLp.toLp 2 (fun b=>omega b i), so its squared Euclidean norm is actual R_i=sum_b(omega b i)^2. WithLp conversion changes the normed representation, not entries or law.','source_ids':['A3.Ex85','A3.SS2.p10.1']},
  {'name':'Y','kind':'literal','meaning':'Closed condition norm(row)^2<=L is source inclusive indicator R_i<=L. Inside branch entries are d^(-1)*gamma_a gamma_b*t_j t_k indexed by pair(a,j),pair(b,k). Else0 is the literal truncation indicator, not invented off-source fallback. Product indexing is a canonical r^2-dimensional coordinate labeling.','source_ids':['A3.Ex107'],'unproved_internal_requirements':['Actual measurable matrix map for explicit Borel structure','Actual Bochner integrability','Pointwise Hermitian algebra']},
  {'name':'mean','kind':'literal','meaning':'mean i=Bochner integral_mu(Y i), not a supplied scalar/identity proxy. Mathlib integral is totalized to0 if nonintegrable (or incomplete), so actual Integrable(Y i) and complete finite matrix carrier must be established internally before calling it source expectation. The existing mean parent signature includes true Integrable(Y i).','source_ids':['A3.SS2.p12.4'],'unproved_internal_requirements':['True Y integrability','Coordinate-Bochner compatibility','Actual mean Hermitian by direct integral OR actual radial formula']},
  {'name':'Z','kind':'literal','meaning':'Y i omega minus its own actual same-mu unconditional mean; translate is deterministic in omega.','source_ids':['A3.SS2.p13.1'],'unproved_internal_requirements':['Measurable translate','Independence under per-index map','Integrable subtraction','Integral constant uses mu probability','Hermitian difference']},
  {'name':'w,X','kind':'literal','meaning':'w_i=cos(((2*q+1):Nat):R *theta_i), exactly frequency n=2q+1, and X_i=w_i smul Z_i. These are deterministic real scalars, possibly zero or negative. No nonzero/sign/lower-bound condition is justified or needed.','source_ids':['A3.SS2.p13.3','A3.SS2.p14.6','A3.SS2.p15.1']},
  {'name':'Measurable,iIndepFun,Integrable,integral=0,IsHermitian','kind':'literal','meaning':'Joint independence within each Fin d-indexed family separately under the original mu, not pairwise-only and not independence of the combined two families. Real IsHermitian is conjugate-transpose equality, equivalent here to transpose symmetry. Pointwise forall omega is justified by the literal formulas. Measurability and integrability expose source-implicit well-definedness conclusions, not extra premises.','source_ids':['A3.SS2.p15.1']}
 ],
 'borel_coordinate_audit':{
  'conclusion':'The explicit borel Matrix is the usual finite coordinate/product Borel sigma algebra. This is a typing/definition conclusion, not a proof of the new source target.',
  'steps':[
   'The selected TopologicalSpace printed by TypeInstanceAudit.v2 is instTopologicalSpaceMatrix, the nested function/product topology. Selected UniformSpace is Matrix.instUniformSpace.',
   'The selected Norm is Matrix.instL2OpNormedRing via NormedRing.toNorm; selected completeness is Matrix.instCompleteSpace and selected finite dimension is Matrix.finiteDimensional.',
   'Mathlib instL2OpMetricSpace constructs its metric with replaceTopology and replaceUniformity so that the existing product topology/uniformity is preserved. Thus L2Operator does not silently select another Borel sigma algebra.',
   'With finite J=Fin(q+1)xFin(q+1), all coordinate index types are countable and R is second countable/Borel. Apply Pi.borelSpace twice and BorelSpace.measurable_eq to identify the nested coordinate measurable product with borel(Matrix J J R).',
   'Hence a matrix-valued map is measurable for the explicit Borel structure iff each entry is measurable, by transport across that equality and measurable_pi_iff twice. Coordinate evaluations are continuous_matrix/Continuous.matrix_elem; their Bochner integration is by continuous linear coordinate maps after integrability.',
   'If proof automation needs a BorelSpace instance for the explicit local letI, it can construct the identity certificate locally (the measurable space is definitionally borel). Such an instance is discharged typing evidence, never a public assumption.'
  ],
  'evidence':[
   api('.lake/packages/mathlib/Mathlib/Topology/Instances/Matrix.lean',48,49,'Matrix topology is the nested function/product topology.'),
   api('.lake/packages/mathlib/Mathlib/Topology/Instances/Matrix.lean',95,104,'Continuity is coordinatewise and entry evaluation is continuous.'),
   api('.lake/packages/mathlib/Mathlib/Analysis/CStarAlgebra/Matrix.lean',153,183,'L2Operator metric/norm preserves original topology/uniformity.'),
   api('.lake/packages/mathlib/Mathlib/MeasureTheory/Constructions/BorelSpace/Basic.lean',631,654,'Pi Borel/product equality for countable coordinates and second countable factors.'),
   api('.lake/packages/mathlib/Mathlib/MeasureTheory/Integral/Bochner/Basic.lean',143,161,'Totalized Bochner integral requires real integrability to mean source expectation.'),
   api('.lake/packages/mathlib/Mathlib/Probability/Distributions/Gaussian/Multivariate.lean',56,73,'Standard finite Gaussian and its probability instance.'),
   api('.lake/packages/mathlib/Mathlib/Probability/Independence/Basic.lean',131,138,'iIndepFun is independence of generated measurable spaces, not merely pairwise.'),
   api('.lake/packages/mathlib/Mathlib/LinearAlgebra/Matrix/Hermitian.lean',42,44,'Real Hermitian is symmetric matrix condition.'),
   api('.lake/packages/mathlib/Mathlib/LinearAlgebra/Matrix/Kronecker.lean',54,56,'Kronecker coordinate ordering is pair-indexed outer-product factors.')
  ],
  'instance_probe':'type-instance-audit-v2.receipt.json (exit0, checks existing instances only; no source theorem inhabitant)',
 },
 'q0':{'allowed':True,'specialization':'r=1,n=1,d>=2,E=R^1,t_i=(1); offdiagonal radial/sign symmetry obligations are vacuous; actual Y_i=d^(-1)*gamma_i^2*1_(gamma_i^2<=L) is real 1x1. Deterministic cosine can vanish, causing no independence/centering/Hermitian obstruction.','no_added_assumptions':['q>0','nonzero weights','positive weights','extra moment assumption','generic carrier measurable-space certificate']},
 'source_vs_conclusion':'Producer and private consumer state the p15 structural assertion plus necessary source-implicit measurability/integrability. They stop before Bernstein tails, norm/variance parameters, high probability events, or final Lemma4.4.',
 'failure_history':{
  'v1':'Exact predecessor seal21e234c0... remains preserved at original path. Actual formation exit1 on missing Matrix MeasurableSpace for Measurable/iIndepFun; original log0b7bcab1626e49453331bcdd87767af3984bf56ff0cafc6759d8dc3dce62a0b0. This is type/API formation failure; no mathematical route refuted.',
  'v2':'Explicit fixed borel Matrix fixes that typing omission. Original actual Prop formation exit0 log0b5984d7611c9d40e6541286f734fde439ffa96d004e2aca84ef234df13b9e1a; this constructs Prop types, not proofs.',
  'own_renderer_v1':'Math alttext containing < was damaged in readable derivative by stripping tags after unescaping. Original/raw spans and v1 outputs preserved; v2 protects math before tag stripping. No raw-source bytes changed.',
  'bootstrap':'Initial broad filename rg exited2; no unrelated file contents read. Pre-receipt command/result chunks retained in tool transcript and bootstrap-history.json. Initial combined protocol output was tool-truncated and protocols were read separately afterwards.',
  'own_instance_v1':'Existing class-instance definitions generated reducibility/defProp warnings only, exit0. Preserved; v2 uses #synth/#check only and exits0. No source target proof attempted.'
 },
 'review_limit':'No self-approval of source topology. A distinct reviewer must reread raw original and graph/coverage; no source fidelity/normalV/PURIFIED claim follows from this audit.'
}
(OUT/'binder-definition-audit.v2.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n')

ports=[
 {'id':'P0-TYPING','source_graph_nodes':['dimensions','grid'],'statement':'Finite matrix standard Borel/product compatibility and norm topology compatibility; CompleteSpace M and FiniteDimensional R M; mu is a probability measure.','discharge':'Existing typing instances and coordinate Borel equivalence above. No new caller binder.','evidence':'type-instance-audit-v2.stdout'},
 {'id':'P1-ROWS','source_graph_nodes':['gap-column-to-row','row-law','gap-independence-transform'],'statement':'For the exact current local D,E,Omega,mu,row: iIndepFun row mu. Also prove each row is measurable.','existing_interface':'AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumSourceRowIndependence.actual_source_rows_independent hq','interface_match':'Exact same product standard column mu and WithLp.toLp2 physical row. Existing theorem supplies independence only; row measurability remains a separate transformation obligation.','evidence':'existing-parent-signatures.stdout','proof_read':False},
 {'id':'P2-YMAP','source_graph_nodes':['gap-measurable-Y'],'statement':'For each i, define Phi_i:E->M by the exact inclusive cutoff/tensor formula. Prove Measurable Phi_i and Y_i=Phi_i composed with row_i. Then Y is independent by per-index measurable maps.','discharge':'R(x)=norm(x)^2 is continuous; cutoff R<=L measurable; each retained matrix coordinate is a polynomial of x entries with deterministic coefficients. Transport coordinate measurability to explicit borel M.'},
 {'id':'P3-ACTUAL-MEAN','source_graph_nodes':['gap-integrable-Y','gap-actual-mean-transport','actual-mean'],'statement':'For exact Y_i under exact mu: Integrable (Y_i) mu; integral_mu Y_i=(a/d) smul (I tensor t_i t_i^T), a=(integral_(stdGaussian E) [norm(x)^2 1_(norm(x)^2<=L)])/r.','existing_interface':'AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumSourceMatrixMean.actual_source_truncated_matrix_means hq','interface_match':'Signature uses exactly same d,q,hq,D,E,Omega,mu,r,L,theta,t,row,Y; supplies true Integrable Y before actual matrix mean formula. No radial mean proxy binder.','evidence':'existing-parent-signatures.stdout','proof_read':False},
 {'id':'P4-MEAN-HERMITIAN','source_graph_nodes':['mean-Hermitian','gap-mean-Hermitian-integral','gap-mean-Hermitian-radial'],'statement':'For each i, (integral_mu Y_i).IsHermitian.','routes':[{'id':'A','needs':['P3 true Y integrability','pointwise Y Hermitian'],'discharge':'Apply continuous linear transpose/coordinate integration to equal symmetric entries.'},{'id':'B','needs':['P3 actual explicit mean formula'],'discharge':'Real scalar multiple of I tensor (t_i t_i^T) is Hermitian.'}],'logic':'A OR B. Do not require both or turn one into a public certificate.'},
 {'id':'P5-Z','source_graph_nodes':['Z','Z-structure','gap-centering','gap-independence-transform'],'statement':'For exact Z_i=Y_i-integral_mu Y_i: all five producer conjuncts.','discharge':['Measurable deterministic translations of per-row maps preserve iIndepFun under original mu.','Integrable Y and constant mean under probability mu give Integrable Z; integral_sub and integral_const give actual zero.','Y is pointwise Hermitian by real outer-product tensor algebra; P4 mean Hermitian gives Hermitian difference.'],'public_binder_policy':'Only exact original hq may remain; none of these statements may be added as premises.'},
 {'id':'P6-X','source_graph_nodes':['weighted-Z','gap-weighted-transfer','structure'],'statement':'For exact deterministic w_i=cos(((2*q+1):Nat):R*theta_i), X_i=w_i smul Z_i: all five private consumer conjuncts.','discharge':['Per-index constant scalar multiplication is measurable and preserves iIndepFun.','Integrability and integral_smul commute with fixed real scalar, giving mean0.','Real fixed scalar multiplication preserves Hermitian.'],'boundary':'Private actual weighted consumer; no separate public API or registry credit.'}
]
portdoc={'seal_sha256':sealhash,'ports':ports,'source_graph_sha256':hashlib.sha256((OUT/'source-graph.RAWFIRST.v1.json').read_bytes()).hexdigest(),
 'implementation_boundary':'These are obligation/interface ports after independent source topology freeze; they do not rewrite the source graph from import or implementation topology. Existing parent proof bodies and earlier audits were not read. No new source target proof exists here.'}
(OUT/'internal-obligation-ports.v2.json').write_text(json.dumps(portdoc,ensure_ascii=False,indent=2)+'\n')

bootstrap=[
 {'tool_chunk':'fe06b7','command':"pwd && rg --files -g 'AGENTS.md' -g '*proof-digestion*' -g '*theorem-publication*' -g '*evidence-routed-memory*' -g '*astis-source-dependency-audit*' /Users/zhouhuanjian/ASTIS-GC /Users/zhouhuanjian/.agents /Users/zhouhuanjian/.codex/skills 2>/dev/null",'exit_code':2,'raw_output_location':'Tool transcript chunk fe06b7; filename listing only. Not exported as forbidden foreign/control/index snapshot.','limitation':'This bootstrap call preceded own raw runner, so no on-disk exact stdout copy exists.'},
 {'tool_chunk':'bbb94b','command':'cat AGENTS.md docs/proof-digestion-protocol.md docs/theorem-publication-protocol.md docs/evidence-routed-memory-protocol.md .agents/skills/astis-source-dependency-audit/SKILL.md','exit_code':0,'raw_output_location':'Tool transcript; tool warned truncation. Controls not exported.'},
 {'tool_chunk':'72976c','command':'cat docs/proof-digestion-protocol.md','exit_code':0,'raw_output_location':'Tool transcript; controls not exported.'},
 {'tool_chunks':['8e36a5','a887e9'],'commands':['cat docs/theorem-publication-protocol.md','cat AGENTS.md'],'exit_codes':[0,0],'raw_output_location':'Tool transcript; controls not exported.'},
 {'tool_event':'c2-v2-read invocation aborted before dispatch','result':'No process executed. Later c2-v2-read succeeded; exact successful stdout is on disk.'}
]
(OUT/'bootstrap-history.json').write_text(json.dumps(bootstrap,indent=2)+'\n')

now=datetime.datetime.now(datetime.timezone.utc).isoformat()
manifest={'created_utc':now,'scope':'Preparation only; no SAU intake, ledger/canonical/global edits or new theorem proof.',
 'seal_sha256':sealhash,'raw_topology_review':'pending distinct reviewer',
 'files':{n:hashlib.sha256((OUT/n).read_bytes()).hexdigest() for n in ['binder-definition-audit.v2.json','internal-obligation-ports.v2.json','bootstrap-history.json','source-graph.RAWFIRST.v1.json','source-coverage.RAWFIRST.v1.json','TOPOLOGY-RAWFREEZE.json','RAWFREEZE.json','RAWFREEZE.v2.json']}}
(OUT/'AUDIT-FREEZE.v2.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps(manifest,indent=2))
