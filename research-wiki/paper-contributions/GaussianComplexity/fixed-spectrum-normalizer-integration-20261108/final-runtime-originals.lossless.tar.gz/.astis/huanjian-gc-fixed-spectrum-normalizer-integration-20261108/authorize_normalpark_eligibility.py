from pathlib import Path
import datetime, gzip, hashlib, json
B = Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-normalizer-integration-20261108')
sha = lambda raw: hashlib.sha256(raw).hexdigest()
def ref(p):
    p = Path(p)
    return {'path': str(p), 'sha256': sha(p.read_bytes())}
context = B / 'actual-successor-local-acceptance-authorization.json'
assert sha(context.read_bytes()) == 'fa7d9321be13bbc1f71a7794a4b1c9e45744ebc64b9167ddfc9b0d0f3092985c'
a = json.loads(context.read_bytes())
accepted = B / 'independent-reader/local-successor-v7-acceptance.json'
decision = json.loads(accepted.read_bytes())
assert decision['state'] == 'LOCAL_INTEGRATION_READER_ACCEPTED' and decision['reviewer'] == '/root/norm_integration_reader'
assert decision['accepted_immutable_core'] == a['accepted_immutable_core'] == 'a5ec44836422e56ca5cfab14f951ed84bbfc9324'
assert decision['new_source_verdict'] is False and decision['parking_authorized_or_executed'] is False
append_ref = a['source_lineage']['source_V_append']
raw = Path(append_ref['path']).read_bytes()
assert sha(raw) == append_ref['sha256']
if append_ref.get('encoding') == 'gzip': raw = gzip.decompress(raw)
assert sha(raw) == '630b6125401c93aec5588645373ab70a61ea2a098ca1f345a351b422d47c477c'
v = json.loads(raw)
out = B / 'normalpark-readonly-eligibility-authorization.json'
assert not out.exists()
out.write_text(json.dumps({'authorized_by': '/root', 'recorded_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'authorization_kind': 'normalizer-existingV-normalpark-readonly', 'advance_id': a['advance_id'], 'new_source_verdict': False, 'normal_API_transition': 'STABILIZING -> VERIFIED', 'normal_API_transition_actor': a['source_verifier_to_preserve'], 'preserved_original_verifier_fields': {k: v['evidence'][k] for k in ['verifier_id', 'verified_commit', 'gate', 'source_audit', 'fake_closure_scan']}, 'postcore_context': ref(context), 'local_reader_acceptance': ref(accepted), 'lifecycle_API_or_park_authorized': False, 'scope': 'Only the independent integration actor may run the frozen v6 normalpark eligibility helper through the reviewed v7 binding. This checks acceptance, exact original sourceV and unchanged current sole STAB/protections. It calls no lifecycle API. A later new separate root authorization is required for the original fresh source verifier itself to execute one mechanical normalpark.'}, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'path': str(out), 'sha256': sha(out.read_bytes()), 'accepted_reader': ref(accepted), 'eligibility_API_authorized': False}))
