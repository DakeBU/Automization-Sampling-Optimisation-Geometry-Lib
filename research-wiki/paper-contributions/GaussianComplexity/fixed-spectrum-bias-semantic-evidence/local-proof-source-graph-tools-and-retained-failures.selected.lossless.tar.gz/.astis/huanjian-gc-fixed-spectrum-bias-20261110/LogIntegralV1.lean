import Mathlib.Analysis.SpecialFunctions.Log.Deriv
import Mathlib.Analysis.SpecialFunctions.Integrals.Basic
import Mathlib.Tactic
noncomputable section
open MeasureTheory Set
open scoped Interval BigOperators

private theorem log_remainder_integral {a : ℝ} (ha0 : 0 ≤ a) (ha1 : a < 1) (n : ℕ) :
    (∫ t : ℝ in 0..a, (t ^ 2) ^ n / (1 - t ^ 2)) =
      1 / 2 * Real.log ((1 + a) / (1 - a)) -
        (∑ i ∈ Finset.range n, a ^ (2 * i + 1) / (2 * i + 1)) := by
  have hden (t : ℝ) (ht : t ∈ Set.uIcc 0 a) : 1 - t ^ 2 ≠ 0 := by
    rw [Set.uIcc_of_le ha0] at ht
    have ht0 : 0 ≤ t := ht.1
    have ht1 : t < 1 := ht.2.trans_lt ha1
    nlinarith
  have hi : IntervalIntegrable (fun t : ℝ => (t ^ 2) ^ n / (1 - t ^ 2)) volume 0 a := by
    apply ContinuousOn.intervalIntegrable
    exact ContinuousOn.div (by fun_prop) (by fun_prop) hden
  have hd (t : ℝ) (ht : t ∈ Set.uIcc 0 a) : HasDerivAt
      (fun x : ℝ => 1 / 2 * Real.log ((1 + x) / (1 - x)) -
        (∑ i ∈ Finset.range n, x ^ (2 * i + 1) / (2 * i + 1)))
      ((t ^ 2) ^ n / (1 - t ^ 2)) t := by
    rw [Set.uIcc_of_le ha0] at ht
    exact Real.hasDerivAt_half_log_one_add_div_one_sub_sub_sum_range n
      (by linarith [ht.1]) (ht.2.trans_lt ha1)
  have h := intervalIntegral.integral_eq_sub_of_hasDerivAt hd hi
  simpa using h

private theorem log_integral_identities {a : ℝ} (ha0 : 0 ≤ a) (ha1 : a < 1) :
    Real.log ((1 + a) / (1 - a)) = 2 * (∫ t : ℝ in 0..a, 1 / (1 - t ^ 2)) ∧
    Real.log ((1 + a) / (1 - a)) =
      2 * a + 2 * (∫ t : ℝ in 0..a, t ^ 2 / (1 - t ^ 2)) := by
  have h0 := log_remainder_integral ha0 ha1 0
  have h1 := log_remainder_integral ha0 ha1 1
  simp only [pow_zero, Finset.range_zero, Finset.sum_empty, sub_zero] at h0
  simp only [pow_one, Finset.range_one, Finset.sum_singleton, zero_mul, zero_add,
    pow_one, div_one] at h1
  constructor <;> linarith
