import AutoSamplingTheory.TechnicalLemmas.Measure.DisplacementJacobianEntropy
import Mathlib.LinearAlgebra.UnitaryGroup
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Basic
open Matrix
set_option autoImplicit false
#check AutoSamplingTheory.TechnicalLemmas.Measure.DisplacementJacobianEntropy.det_conjStarAlgAut_eq
#check Unitary.conjStarAlgAut_apply
#check Matrix.det_diagonal
#check fun {d : ℕ} (O : Matrix.orthogonalGroup (Fin d) ℝ) =>
  (show unitary (Matrix (Fin d) (Fin d) ℝ) from O)
