from pathlib import Path
import ast, json, gzip, hashlib, datetime, subprocess
R=Path('/Users/zhouhuanjian/ASTIS-GC')
P=R/'.astis/huanjian-gc-fixed-spectrum-admissibility-integration-20261107/check_final_reader.py'
O=R/'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-admissibility-integration-20261107/independent-integration-reader-review/proposal/browser-checker-preparation'
sha=lambda b:hashlib.sha256(b).hexdigest()
raw=P.read_bytes(); tree=ast.parse(raw,filename=str(P))
assert 'metadata-only HEAD' not in raw.decode()
assert "gate['commit'] == metadata['git']['commit'] == HEAD" in raw.decode()
assert "gate['source_digest'] == metadata['source_digest'] == astis_site.source_digest()" in raw.decode()
assert "for width in (1440, 390):" in raw.decode()
O.mkdir(parents=True,exist_ok=False)
q=O/'check_final_reader.py.raw.gz';q.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(q.read_bytes())==raw
report={'reviewer':'/root/admiss_integration_reader','prepared_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'state':'PREPARED_NOT_EXECUTED','script':str(P.relative_to(R)),'script_sha256':sha(raw),'archive':str(q.relative_to(R)),'archive_sha256':sha(q.read_bytes()),'static_syntax_check':'Python ast.parse only; checker module never imported or executed, no Chrome/server/site/build/API/ledger action.','actual_browser_runs':[],'exact_HEAD_precondition':'Actual gate.commit == site.git.commit == currentHEAD and actual source_digest == site.source_digest == current computed Lean source_digest; no metadata-only build exception.','future_coverage':['Exact corrected production/Test/lesson/publication pins, reviewed current publication binding, actual5steps and empty producer ASTIS parents.','1440/390 initially closed progressive main/assumptions/5proofsteps, rendered mathematics, exact adjacent statement/proof, local code hscroll and no fullpage overflow.','Real source-index link click, own full module/download bytes and immutable local Git source object; external GitHub link syntax only, not external/public HTML availability.','One canonical producer/module plus native neighbor module click; one pre-existing canonical GaussianPrecisionDensity node actually reused only by focused Test.','Both GraphMemory/Functor exact bytes preserved, no admissibility oracle-factorization candidate incidence or false formal parent/transport.','Actual screenshot/report files with raw hashes; original image human/model inspection is a later separate acceptance step.'],'future_authorization':'Root must obtain task-scoped browser execution permission and complete genuine exactHEAD official gate/sitebuild/sitecheck/cellgraph first. Do not execute now.','shared_or_source_audit_or_ledger_mutations':False}
(O/'preparation-manifest.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'state':report['state'],'script_sha256':sha(raw),'manifest_sha256':sha((O/'preparation-manifest.json').read_bytes()),'archive_sha256':sha(q.read_bytes())}))
