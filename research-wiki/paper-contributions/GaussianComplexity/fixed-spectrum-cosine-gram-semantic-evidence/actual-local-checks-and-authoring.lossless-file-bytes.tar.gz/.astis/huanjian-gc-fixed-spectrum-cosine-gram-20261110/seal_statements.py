from pathlib import Path
import subprocess,json,hashlib,datetime
W=Path(__file__).resolve().parent.relative_to(Path.cwd())
sha=lambda b:hashlib.sha256(b).hexdigest()
dump=lambda x:(json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode()
assert not (W/'statement-seal-v1.json').exists()
manifest=Path('lake-manifest.json').read_bytes()
assert sha(manifest)=='b83ca83b9cf7caa85fa8b023c2ff9a3fb7a7cce7e1c332e810c348535ec49c37'
version=subprocess.check_output(['lake','env','lean','--version'],text=True).strip()
assert 'version 4.33.0,' in version and 'd8b18978322de05a8f3dba51ef03cf5461676c17' in version
binary=Path(subprocess.check_output(['elan','which','lean'],text=True).strip())
assert sha(binary.read_bytes())=='1b370cfcbf44e80d1b004ab1b1ab9a4c73951f9f7c242140bcff9bc577576554'
deps=[]
for p in json.loads(manifest)['packages']:
    d=Path('.lake/packages')/p['name']
    head=subprocess.check_output(['git','-C',str(d),'rev-parse','HEAD'],text=True).strip()
    status=subprocess.check_output(['git','-C',str(d),'status','--porcelain'],text=True)
    assert head==p['rev'] and status=='',p['name']
    deps.append({'name':p['name'],'expected_rev':p['rev'],'actual_HEAD':head,'actual_full_porcelain':status})
assert len(deps)==9
env={'actual_HEAD':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'native_version':version,'native_binary':str(binary),'native_binary_sha256':sha(binary.read_bytes()),'manifest_sha256':sha(manifest),'toolchain_bytes':Path('lean-toolchain').read_text(),'actual_dependencies':deps,'scope':'Actual environment at exact statement seal; no target proof/build/normal SAU or global authority.'}
(W/'actual-environment-at-seal.json').write_bytes(dump(env))
p=(W/'producer-signature.draft.txt').read_bytes();t=(W/'consumer-signature.draft.txt').read_bytes()
formation=json.loads((W/'statement-formation.json').read_bytes())
assert not (W/'StatementFormation.lean').exists()
assert sha((W/'StatementFormation.raw.lean.txt').read_bytes())==formation['raw_probe_sha256']
f=Path('.lake/packages/mathlib/Mathlib/Probability/Distributions/Gaussian/Multivariate.lean')
b=f.read_bytes();lines=b.decode().splitlines(keepends=True)
excerpt=''.join(lines[162:170]).encode()
assert b'def multivariateGaussian' in excerpt
(W/'multivariateGaussian-literal-definition.txt').write_bytes(excerpt)
defs=[{'name':'ProbabilityTheory.multivariateGaussian','definition_kind':'literal','file':str(f),'first_line':163,'last_line_inclusive':170,'whole_file_sha256':sha(b),'excerpt':str(W/'multivariateGaussian-literal-definition.txt'),'excerpt_sha256':sha(excerpt),'meaning':'The actual canonical mean-plus-covariance-square-root pushforward of standardGaussian. The covariance in this consumer is literally I on Fin d x Fin(q+1); positivity/probability and actual coordinate-product moments must be derived internally, excluding any non-PSD fallback. This is not a symbolic independent-variable certificate.'},
{'name':'theta/t/D','definition_kind':'literal','meaning':'All are literal let bodies in both sealed types. Fin indices start at0. r=q+1, theta_i=(i+1/2)pi/d. t_i0=1 and t_ik=sqrt2*cos(k theta_i) for k>0; D=diag(cos((2q+1)theta_i)). hq implies d>=2 and excludes denominator0. Matrix transpose is real transpose; product and scalar multiplication are ordinary matrix operations, with1 the identity.'},
{'name':'B and mu','definition_kind':'literal','meaning':'mu is actual centered Gaussian of identity covariance on EuclideanSpace indexed Fin d x Fin(q+1). B(x)_{i,(a,b)}=(sqrt d)^(-1)*x_(i,a)*t_(i,b). Product indices explicitly realize r squared columns and d rows. No supplied independent-row law, covariance, expectation, integrability or moment is bundled.'},
{'name':'entrywise integrability and means','definition_kind':'literal','meaning':'For every a,b in Fin r x Fin r, both actual Gram entries are Bochner integrable over the actual mu; unweighted mean is Kronecker identity, weighted mean is0. Entrywise expectation is the literal finite-dimensional matrix-expectation meaning; no conditional or adaptive random law is asserted.'}]
binders=[]
for owner in ['producer','private_consumer']:
    binders.extend([{'owner':owner,'binder':'d:Nat','class':'TYPING','reason':'Finite ambient Euclidean dimension.'},{'owner':owner,'binder':'q:Nat','class':'SOURCE','reason':'Source nonnegative Krylov degree; Nat encodes q>=0 includingq0.'},{'owner':owner,'binder':'hq:2*q+1<d','class':'SOURCE','reason':'Exact Lemma4.4/FactC.5 standing range. No stronger4q+1<d premise is added.'}])
seal={'schema':1,'seal_id':'ASTIS-GC-COSINE-GRAM-v1','state':'EXACT_LITERAL_TYPES_SEALED_NO_PROOF_OR_NORMAL_INTAKE','created_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
'source':{'version':'arXiv:2610.20492v1','raw':{'path':'.astis/huanjian-resume-20261103/2610.20492v1.html','bytes':951991,'sha256':'6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'},'anchors':['S4.Thmtheorem4','A3.SS2','A3.Thmtheorem5'],'scope':'The deterministic cosine-frame Gram, weighted cancellation and row-norm component of FactC.5, with genuine private actual Gaussian Gram expectation consumer. Range(B)=Krylov and C.6 concentration/full Lemma4.4 remain separate.'},
'producer':{'name':'AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumCosineGram.actual_cosine_frame_gram','planned_file':'AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumCosineGram.lean','signature':p.decode(),'signature_sha256':sha(p),'definition_kind':'literal'},
'actual_private_consumer':{'name':'actual_gaussian_gram_means','planned_file':'Tests/GaussianComplexityFixedSpectrumCosineGram.lean','signature':t.decode(),'signature_sha256':sha(t),'definition_kind':'literal','is_source_anchor':False,'consumer_obligation':'Materially invoke new deterministic Gram/weighted identities in actual Gaussian entrywise Gram integrability and expectations. Derive actual second coordinate moments, sqrt-d normalization/nonzero and finite sum/integral interchange internally. No caller covariance/moment/integrability/Gram/range/concentration certificate.'},
'binder_audit':binders,'EXCESS_public_binders':[],'project_owned_Prop_aliases_or_hidden_bundles':[],'definition_semantics_audit':defs,
'literal_conventions':{'ranges':'All naturals q including0; exact source2q+1<d impliesd>=2 and2(q+1)<=d. There is no kappa parameter because the cosine-frame component does not depend on kappa. Full source q range is retained.','matrix_identities':'t^T t=d I_(q+1); t^T D_(2q+1)t=0; each row squared Euclidean norm=sum squares<=2(q+1). Real transpose not conjugate transpose; realscalar d only.','Gaussian_consumer':'True joint standardGaussian in d*(q+1) coordinates, not unspecified random variables plus assumed covariance. Equality to the source independent g_a/row-law interpretation must be justified from actual law internally if used; row independence is not silently inserted as a premise.','expectation':'Entrywise Bochner integrability AND actual integral values; a totalized integral equality without integrability is insufficient.','scope_boundary':'Deterministic frame and actual Gaussian second-moment centering do not supply range(B)=Krylov, nonasymptotic op-norm concentration/absoluteC, positivity of a random Gram matrix, a Haar/adaptive/oracle/precision/TV/cap/cost adapter, either main lower bound or website delivery.'},
'no_proof_ingredient_binder':['no finite cosine cancellation premise','no normalized Gram identity premise','no random covariance or expectation premise','no integrability/independence/moment witness','no Haar/Krylov/concentration/opnorm/query/cost certificate'],
'actual_statement_formation':formation,'actual_environment':env,'honest_preseal_exposure':{'record':str(W/'preseal-planning.json'),'sha256':sha((W/'preseal-planning.json').read_bytes()),'no_pristine_root_claim':True},
'reuse_search':{'known_existing_node':'Canonical FixedSpectrumGridAlias has already been proved/reviewed in earlier work; its known name/interface is a possible finite cosine cancellation floor, not an extra hypothesis. Its exact selected API and all other proof retrieval wait until this packet source/topology admission.','generic_target_proof_API_search':'NOT_STARTED'},
'process_memory':{'path':'research-wiki/process-memory.json','sha256':sha(Path('research-wiki/process-memory.json').read_bytes()),'process_memory_ids':[],'reason':'Known current Fisher/tilt/normalized-gradient process rules do not establish finite cosine or Gaussian Gram mathematics; no control memory supplies a proof.'},
'independent_source_graph_and_distinct_topology':'PENDING; source graph role currently raw-only before any sealed type exposure. No mathematical implementation or normal next-SAU intake yet.',
'owner_boundary':'Same overallGoal, original foreign global owner and every old queue/result preserved. This private seal does not transfer any lease or change the current ZeroQuery packet/sourceV process.'}
raw=dump(seal);(W/'statement-seal-v1.json').write_bytes(raw)
projection={'producer_signature':p.decode(),'consumer_signature':t.decode(),'binder_audit':binders,'definitions':defs,'literal_conventions':seal['literal_conventions'],'source_raw_sha256':seal['source']['raw']['sha256']}
(W/'strict-statement-projection.json').write_bytes(dump(projection))
print(json.dumps({'seal_sha256':sha(raw),'producer_signature_sha256':sha(p),'consumer_signature_sha256':sha(t),'source_binders':4,'typing_binders':2,'EXCESS':0,'actual_environment_9deps_clean':True,'actual_Prop_formation_only':True,'no_target_proof_or_intake':True}))
