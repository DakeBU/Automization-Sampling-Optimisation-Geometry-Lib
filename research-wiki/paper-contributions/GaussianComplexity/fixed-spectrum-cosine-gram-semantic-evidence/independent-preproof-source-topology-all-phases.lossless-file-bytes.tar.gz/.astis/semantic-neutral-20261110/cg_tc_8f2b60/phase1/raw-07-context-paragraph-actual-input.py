from pathlib import Path
from bs4 import BeautifulSoup
base=Path('.astis/semantic-neutral-20261110/cg_tc_8f2b60/phase1');out=[]
for key in ['S4.SS1','S4.SS2.SSS0.Px1','S4.SS2.SSS0.Px2']:
 s=BeautifulSoup((base/(key+'.html')).read_bytes(),'html.parser')
 for t in s.find_all(class_='ltx_para'):
  for m in t.find_all('math'):m.replace_with(' $'+m.get('alttext','')+'$ ')
  out.append(t.get('id')+'\n'+t.get_text(' ',strip=True))
x='\n\n'.join(out)+'\n';(base/'raw-07-context-paragraph-output.txt').write_text(x);print(x)
