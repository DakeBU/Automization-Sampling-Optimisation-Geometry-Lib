from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import sys

root = Path('/Users/zhouhuanjian/ASTIS-GC')
out = root / '.astis/semantic-neutral-20261109/src_82a91d/normal-sourceV-runtime'
assert not (out / 'execute.receipt.json').exists(), 'Execution already attempted; never retry'
command = ['python3', str((out / 'sourceV.py').relative_to(root)), 'execute']
head_before = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root).decode().strip()
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
result = subprocess.run(command, cwd=root, capture_output=True)
ended = datetime.datetime.now(datetime.timezone.utc).isoformat()
for name, data in [('execute.stdout.txt', result.stdout), ('execute.stderr.txt', result.stderr)]:
    (out / name).write_bytes(data)
receipt = {
    'command': command, 'cwd': str(root), 'started_utc': started, 'ended_utc': ended,
    'head_before': head_before,
    'head_after': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root).decode().strip(),
    'exit_code': result.returncode,
    'stdout': {'path': str(out / 'execute.stdout.txt'), 'bytes': len(result.stdout), 'sha256': hashlib.sha256(result.stdout).hexdigest()},
    'stderr': {'path': str(out / 'execute.stderr.txt'), 'bytes': len(result.stderr), 'sha256': hashlib.sha256(result.stderr).hexdigest()},
    'script_sha256': hashlib.sha256((out / 'sourceV.py').read_bytes()).hexdigest(),
    'retry_policy': 'Exactly one execution. Any guard/API failure stops with evidence; no forced transition or unchanged retry.',
}
(out / 'execute.receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt, indent=2))
print(result.stdout.decode(), end='')
print(result.stderr.decode(), end='', file=sys.stderr)
raise SystemExit(result.returncode)
