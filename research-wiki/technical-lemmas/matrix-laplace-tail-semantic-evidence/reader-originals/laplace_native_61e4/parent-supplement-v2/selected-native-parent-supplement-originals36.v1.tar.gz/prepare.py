"""Freeze a new narrow parent-node supplement; preserve all prior browser evidence."""
import hashlib
import json
from pathlib import Path
import plistlib

OWN=Path(__file__).resolve().parent
ROLE=OWN.parent
REPO=OWN.parents[3]
PREVIEW=REPO/'.astis/huanjian-gc-matrix-laplace-20261114/reader-preview-v3'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')

def main():
    assert not (OWN/'contract.v1.json').exists()
    old=ROLE/'reader-runtime-v3'
    assert sha(old/'presentation-selected-originals.manifest.v1.json')=='3cea83cd0e61df11cba9ab36dca51f1f64c79b18df1238b836d8f9c05f301451'
    assert sha(ROLE/'selected-originals.manifest.v1.json')=='dbd220b80c7c6a5db609c89eae3b0fbd3630fd652dc7de39074ad7f0e84186eb'
    prior=json.loads((old/'browser-output-v1/candidate/actual-checks.json').read_text())
    selected=[x for x in prior['checks'] if x['name'] in ['desktop-parent-1-readable-existing-graph-UI','desktop-parent-2-readable-existing-graph-UI']]
    assert len(selected)==2
    diagnosis={'schema':'independent-parent-clip-measurement-defect-v1','classification':'IMPLEMENTATION_FAILED_IN_PRIOR_BROWSER_HARNESS_MEASUREMENT','old_398_flags_and_356_original_manifest_preserved':True,'old_results_not_rewritten':True,'old_checks':selected,'actual_old_PNGs_inspected':[{'path':'reader-runtime-v3/browser-output-v1/candidate/'+n,'sha256':sha(old/'browser-output-v1/candidate'/n)} for n in ['desktop-parent-1-actual-UI-zoom-pan.png','desktop-parent-2-actual-UI-zoom-pan.png']], 'finding':'The old two desktop images have an empty graph canvas. Prior pan centers node on the global viewport at y~500, while the SVG visible clipped area starts near y698. Positive font size and a global node bounding box do not establish visibility inside SVG clipping.','old_measurement_gap':'No node/SVG-clipped-visible-region intersection assertion in parent readability check; desired_y used global viewport center, potentially outside SVG.','page_or_mathematics_defect_established':False,'repair_scope':'Only a new targeted browser harness; no fixture, production, old script or mathematics edit.','supplement_scope':'Radius and Structure declarations only, desktop1440x1000 and mobile390x844, actual scroll/wheel/pointer; inspect SVG ancestor clip and fixed-header intersection, real full detail/source navigation.','status':'SUPPLEMENT_PREPARED_NOT_YET_EXECUTED'}
    write(OWN/'prior-measurement-diagnosis.v1.json',diagnosis)
    assert sha(PREVIEW/'preview-freeze-manifest.json')=='9209609b560905e6cd11a69082ac4bdb89e752a66fe3e99ba38e17508d2103b7'
    m=json.loads((PREVIEW/'preview-freeze-manifest.json').read_text())
    fixture=PREVIEW/'fixtures/candidate'
    frozen=[]
    for row in m['variants']['candidate']['files']:
        p=fixture/row['path'];assert sha(p)==row['sha256'];frozen.append({'path':str(p),'sha256':row['sha256'],'bytes':p.stat().st_size})
    targets=[]
    for label,module,name,anchor,count in [
      ('Radius','AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumSourceMatrixRadius','actual_source_truncated_matrix_norm_bounds',101,226),
      ('Structure','AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumSourceMatrixStructure','actual_source_centered_matrix_structure',13,148)]:
        raw=module.replace('.','/')+'.lean';source=PREVIEW/'input-snapshot'/raw
        assert source.read_bytes()==(ROLE/'candidate-1d1103af6'/raw).read_bytes()
        targets.append({'label':label,'id':'decl:'+module+'.'+name,'full_name':module+'.'+name,'raw':raw,'source_path':'data/lesson-sources/'+raw+'.html#L'+str(anchor),'anchor':anchor,'lines':count,'source_sha256':sha(source)})
        frozen.append({'path':str(source),'sha256':sha(source),'bytes':source.stat().st_size})
    chrome=Path('/Applications/Google Chrome.app/Contents/MacOS/Google Chrome');info=Path('/Applications/Google Chrome.app/Contents/Info.plist');meta=plistlib.loads(info.read_bytes())
    contract={'schema':'independent-parent-SVG-clip-native-browser-supplement-v1','status':'FROZEN_ROOT_EXPLICITLY_AUTHORIZED_TARGETED_SUPPLEMENT','actual_browser_target':'reader-preview-v3 candidate only; v4 transfer remains byte-identity-only','preview_manifest_sha256':sha(PREVIEW/'preview-freeze-manifest.json'),'fixture':str(fixture),'targets':targets,'viewports':[{'label':'desktop','width':1440,'height':1000},{'label':'mobile','width':390,'height':844}],'runner_sha256':sha(OWN/'supplement.py'),'inputs':frozen,'chrome':{'path':str(chrome),'binary_sha256':sha(chrome),'Info_plist_path':str(info),'Info_plist_sha256':sha(info),'app_version':meta.get('CFBundleShortVersionString')},'measurement_contract':['scroll the actual SVG into viewport before measuring or panning','compute visible SVG rectangle intersecting viewport below fixed/sticky header and every overflow-clipping ancestor','assert node bbox has positive intersection inside that actual clipped region, not merely the global viewport','require selected node effective label font>=12px and >=98% bbox area inside clipped visible SVG area','use actual native wheel and pointer handlers only; never write SVG transforms/node styles','target desired node center is clipped SVG visible-area center, never unconditional viewport center','capture actual node viewport and actual visible-SVG crop after settled geometry','capture complete detail through actual scrolling and exact full declaration text, then actual primary source navigation and byte-exact whole source body','record requests/responses/console/errors and rehash all frozen candidate fixture bytes after run'],'prior_398_rerun':False,'native_Lean_rerun':False,'prior_acceptance_inherited':False,'old_manifests_unchanged':True,'new_script_requires_its_own_scoped_native_approval':True,'only_localhost_requests':True,'production_Git_ledger_API_writes':0,'local_server_lifecycle':'same foreground process; shutdown, server_close, thread.join in finally','outputs_preexisting':False}
    assert not (OWN/'output').exists() and not (OWN/'process').exists()
    write(OWN/'contract.v1.json',contract)
    plan=json.loads((ROLE/'verification-preparation/preparation-plan.v1.json').read_text())
    write(ROLE/'verification-preparation/stabilization-view-clarification.v1.json',{'original_preparation_plan_unchanged':True,'local_private_branch_preparation_HEAD':plan['preparation_HEAD'],'local_private_replay_STABILIZING_count':plan['foreign_STABILIZING_count'],'origin_main_observation_from_ROOT':{'commit':'9448a8b6692ec17408e99f5aadafcd321d0daedf','existing_STABILIZING_count':2,'basis':'ROOT bounded actual fetch/observation message; not claimed as local replay'},'correction':'Earlier commentary incorrectly mixed the origin/main two-stabilizer observation with local replay. Local preparation count is 0; this does not release or take over the two original origin/main stabilizers.','normal_V_authorization':False,'no_checkout_rebase_takeover':True})
    contract['measurement_contract'].append('Rendered core label text bbox must have >=95% visible area inside actual SVG clip, at least min(80px,full width) visible width and min(12px,full height) visible height, with effective font>=12px. Exact full ID remains a detail-panel check; no full-ID-fit claim.')
    contract['preexecution_successor']='Prepared v1 was not executed; v2 adds explicit clipped text-bbox readability before the first actual targeted run. Old398 scripts/evidence and prepared-v1 files remain unchanged.'
    write(OWN/'contract.v1.json',contract)
    print(json.dumps({'prepared':True,'contract_sha256':sha(OWN/'contract.v1.json'),'runner_sha256':sha(OWN/'supplement.py'),'old356_and239_unchanged':True}))

if __name__=='__main__':main()
