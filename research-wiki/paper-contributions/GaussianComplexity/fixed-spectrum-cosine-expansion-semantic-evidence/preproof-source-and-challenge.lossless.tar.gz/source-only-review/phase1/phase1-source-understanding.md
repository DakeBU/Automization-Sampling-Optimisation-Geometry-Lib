# Frozen source understanding: fixed-spectrum target moments

This is phase 1 raw-source cognition and topology, frozen before any implementation interface is chosen. It is not a Lean statement, proof design, API assessment, claim packet, mathematical verification, or theorem-completion certificate. A distinct reader still needs to challenge the topology and binders against the raw source. The source and implementation graphs remain separate; no implementation graph was read or created here.

The only mathematical input is the existing pinned HTML snapshot of Huanjian Zhou and Taiji Suzuki, *On Complexity of Gaussian Sampling*, arXiv:2610.20492v1: 951991 bytes, SHA-256 `6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915`. The main statement is the actual raw anchor `#S4.Thmtheorem5`, inside `#S4.SS2.SSS0.Px3`; its complete proof is `#A3.SS3`. No external source was fetched. The snapshot's license notice is “arXiv.org perpetual non-exclusive license”; this is not an assertion that the paper or its cited works have a Creative Commons license. Excerpts stay in this task-local review directory.

## Exact bounded coverage

`declared_regions.json` declares fourteen nonoverlapping raw regions: Section 2; Section 4's two short context paragraphs and Theorem 4.1; Section 4.1; the introductory role paragraph of Section 4.2; its four named paragraphs containing the statement-level inputs 4.3, 4.4, 4.5 and 4.6; all of Section 4.3; all of Appendix C.3; bibliography item [22]; and the snapshot license notice. The exact raw slices, source byte offsets, line ranges and raw hashes are preserved. Title/author metadata is separately pinned in the provenance record.

`paragraph_display_citation_coverage.json` inventories every paragraph, paragraph block, theorem/fact/remark, heading, citation, display table/group and equation row in those regions. Nested display rows are intentionally retained rather than counted as distinct mathematical results. `all_math_anchors.json` preserves all 308 exact decoded TeX alttexts, their hashes, the corresponding annotation and raw-element hashes. `all_source_anchors.json` preserves all 590 source ids. `all_source_links.json` preserves all 48 links and classifies bibliography backreferences separately. All 308 TeX alttexts match their source annotations; no local link is unresolved. These counts describe this declared slice only.

Appendices C.1, C.2 and C.4 are excluded proof expansions of the contracted neighboring statement inputs. Section 4.4 is excluded, despite incidental source heading/snippet exposure. Theorem 3.1, Sections 1 and 3 and other paper regions are not covered merely because a link points to them. The externally cited OpenAI preprint [22] was not opened. No whole-paper or formal-theorem coverage is claimed.

## Objects, laws, parameters and normalization

Section 2 uses real Euclidean vectors, the Euclidean norm, real symmetric precision matrices, and the Loewner order. For integer dimension `d>=1` and `kappa>=1`, the normalized class is

\[
\mathcal A_{d,\kappa}=\{A\in\mathbb R^{d\times d}:A=A^\top,\ I_d\preceq A\preceq\kappa I_d\},
\qquad f_A(x)=\tfrac12x^\top Ax,\qquad \pi_A=N(0,A^{-1}).
\]

Thus `A` is precision and `A^{-1}` is covariance. The endpoints `1,kappa` are the paper's rescaled normalization. Exact value-gradient, gradient-only and matrix-vector oracle accesses are equivalent on this class. A randomized algorithm is Borel in its independent seed and prior replies; its fixed budget is a deterministic cap for every input and seed. Its fixed-input output law `rho_A^Alg` already averages the seed. `Q_G` takes an infimum over nonnegative integer budgets admitting one algorithm with a uniform-in-input TV bound. TV is the supremum over measurable events and bounds differences of measurable `[0,1]` test expectations.

Section 4.1 strengthens the family parameters to integer `d>=2`, real `kappa>=2`. For `i=1,...,d`, its literal formulas are

\[
\theta_i=(i-\tfrac12)\pi/d,\quad
\lambda_i=(\kappa+1)/2+(\kappa-1)\cos\theta_i/2,\quad
\Lambda=\operatorname{diag}(\lambda_1,\ldots,\lambda_d).
\]

Draw `O` from Haar probability on the full real orthogonal group `O(d)`, independently of the algorithm seed, and set `A=O Lambda O^T`. The spectrum is deterministic, may be supplied to the algorithm, and determines the known Gaussian normalizing constant. The hidden information is the random eigenbasis. The source does not give an additional normalizer formula in this slice. The determinant-component and conditioned-Haar notation from Section 2 is present but unused here; it is explicitly excluded from the moments dependencies.

Lemma 4.5 first fixes this grid and `kappa>=2`, then a vector `U~N(0,Lambda^{-1})`, then takes any integer `1<=n<d` and defines

\[
 r=\varrho_\kappa=\frac{\sqrt\kappa-1}{\sqrt\kappa+1},\qquad
 D_n=\operatorname{diag}(\cos(n\theta_i)),\qquad
 M=\mathbb E\|U\|^2,\qquad
 \mu_n=\mathbb E[U^\top D_nU].
\]

This diagonal-law statement does not require a query count, algorithm, Haar-random input, `delta`, `epsilon`, `tau`, or the large-d range of Theorem 4.1. In particular, `n` is not restricted to odd integers in Lemma 4.5. In this report `r` is only an abbreviation for the source's `varrho_kappa`; it must not be confused with the algorithm output law `rho_A^Alg`.

The source standing inputs are the Euclidean/real finite-dimensional convention, integer dimension, literal hard grid, and the stated centered Gaussian law. `D_n`, `M` and `mu_n` are literal definitions. Positivity of eigenvalues, `0<r<1`, finite polynomial moments, coordinate independence, exact moment formulas, variance estimates, the sign of `mu_n`, and the bias bounds are produced ingredients or unnamed background consequences. They are not extra source hypotheses. The extra condition `d-n>=sqrt(kappa)` belongs only to the final normalized-bias conclusion; exact means and variances have no such condition.

## Every moment claim and its source proof

The exact means, displayed at `#S4.Ex16` and repeated in Fact C.8 `#A3.Ex138`, are

\[
 M=\frac d{\sqrt\kappa}\frac{1-r^{2d}}{1+r^{2d}},\qquad
 (-1)^n\mu_n=\frac d{\sqrt\kappa}\frac{r^n-r^{2d-n}}{1+r^{2d}}.
\]

The ratio of these means is the quantity later called normalized bias. It is not the mean of a normalized random ratio. Appendix C.3 obtains it by the following source steps, all of which are separate graph nodes:

1. Fact C.7 expands the inverse spectrum, for every real `theta`, as
   \[
   \frac2{\kappa+1+(\kappa-1)\cos\theta}
   =\frac1{\sqrt\kappa}\left(1+2\sum_{j\ge1}(-r)^j\cos(j\theta)\right).
   \]
   At `#A3.Ex134`–`#A3.Ex135`, complex geometric sums give the rational expression `(1-r^2)/(1+2r cos(theta)+r^2)`. At `#A3.Ex136`, the two algebraic identities in the literal `r` formula supply the normalization `1/sqrt(kappa)`. The geometric majorant `sum r^j=r/(1-r)` at `#A3.Ex137` supplies absolute and uniform convergence. No external result is cited in C.3.
2. At `#A3.Ex139`, for every integer `k`, the midpoint-grid sum is `d(-1)^a` when `k=2ad`, `a` integer, and zero otherwise. The proof paragraph explicitly covers both cases: the nonmultiple case has `sin(k pi)/(2 sin(k pi/(2d)))=0`; the multiple case evaluates each cosine as `(-1)^a`.
3. Since `E U_i^2=1/lambda_i`, `#A3.Ex140` identifies `M=sum_i lambda_i^{-1}` and `mu_n=sum_i cos(n theta_i)lambda_i^{-1}`. Fact C.7 permits interchanging the absolutely convergent series and finite grid sum.
4. For `M`, only `j=2ad`, `a>=1`, survive. `#A3.Ex141`–`#A3.Ex143` sum the geometric alias tail and yield the exact first formula.
5. For `mu_n`, `sum_i cos(n theta_i)=0`. Product-to-sum gives `#A3.Ex144`. The paragraph `#A3.SS3.p6.2` classifies three supported positive-j classes: `j=n`, `j=2ad+n`, and `j=2ad-n` with `a>=1`. Their values/signs and disjointness rely on `1<=n<d`. It also records `(-r)^{2ad+-n}=(-1)^n r^{2ad+-n}`. `#A3.Ex145`–`#A3.Ex147` reindex and resum these tails to yield the exact second formula. The proof of Lemma 4.5 then explicitly consumes Fact C.8 for both means.

The variance paragraph `#A3.SS3.p8.1` explicitly uses diagonal covariance to obtain independent centered Gaussian coordinates. It states every coordinate moment needed:

\[
 \operatorname{Var}(U_i)=1/\lambda_i,\quad
 \mathbb E U_i^2=1/\lambda_i,\quad
 \mathbb E U_i^4=3/\lambda_i^2,\quad
 \operatorname{Var}(U_i^2)=2/\lambda_i^2.
\]

It also produces `lambda_i>=1` from the hard-grid formula. The exact variance identities and bounds at `#A3.Ex148`–`#A3.Ex149` are

\[
 \operatorname{Var}(\|U\|^2)=2\sum_i\lambda_i^{-2}\le2\sum_i\lambda_i^{-1}=2M,
\]
\[
 \operatorname{Var}(U^\top D_nU)=2\sum_i\cos^2(n\theta_i)\lambda_i^{-2}\le2M.
\]

The exact formula for `M` supplies `M<=d/sqrt(kappa)`. Thus both source variance conclusions are bounded by `2M<=2d/sqrt(kappa)`. Gaussian finite moments, finite-sum expectation/variance identities and covariance cancellation for independent coordinates remain visible unnamed-background nodes. They are not newly assumed estimates.

The normalized-bias paragraphs `#A3.SS3.p9`–`#A3.SS3.p11` produce the sign `(-1)^n mu_n>0`, positivity of `M` and denominators, and the exact identity and correction bounds

\[
 \frac{|\mu_n|}{M}=r^n\frac{1-r^{2(d-n)}}{1-r^{2d}},\qquad
 1-r^{2(d-n)}\le\frac{1-r^{2(d-n)}}{1-r^{2d}}\le1.
\]

The proof does not assume an asymptotic infinite-grid moment. It retains the finite-grid correction. It obtains power bounds from the actual log-integral calculation:

\[
 \log(1/r)=2\int_0^{1/\sqrt\kappa}\frac{dt}{1-t^2}
 =\frac2{\sqrt\kappa}+2\int_0^{1/\sqrt\kappa}\frac{t^2}{1-t^2}\,dt,
\]
\[
 \frac2{\sqrt\kappa}\le\log(1/r)
 \le\frac2{\sqrt\kappa}\left(1+\frac1{3(\kappa-1)}\right)
 \le\frac8{3\sqrt\kappa}<\frac3{\sqrt\kappa},\qquad
 e^{-3n/\sqrt\kappa}\le r^n\le e^{-2n/\sqrt\kappa}.
\]

Here `kappa>=2` supplies the integration domain and numerical upper constant. Only when `d-n>=sqrt(kappa)` does `#A3.Ex158` give `r^{2(d-n)}<=e^{-4}`. Combining the three produced ingredients yields

\[
 (1-e^{-4})e^{-3n/\sqrt\kappa}\le|\mu_n|/M\le e^{-2n/\sqrt\kappa}.
\]

## Real target transport and consumer

The post-lemma paragraph `#S4.SS2.SSS0.Px3.p2.1` is substantive. For `Y|O~pi_A`, `U=O^T Y` has law `N(0,Lambda^{-1})` and exactly preserves the squared norm and rotated cosine form. Therefore the two means and variances transfer to the target at every fixed hard-family input. This needs the standard orthogonal Gaussian pushforward and quadratic-conjugation facts, recorded as an unnamed background bridge. It does not require or assert that `Y` and `O` are independent.

Theorem 4.1 has the ordered scope: for every fixed `delta in (0,1)`, there is a single `d0(delta)` such that for every integer `d>=d0(delta)`, every `2<=kappa<=d^{1-delta}` and every `0<epsilon<=1/10`, the displayed `delta/256 sqrt(kappa) log d` lower bound holds. Its proof fixes such parameters and supposes a successful algorithm with an integer fixed cap `q<=delta/256 sqrt(kappa) log d`. It uses admissibility 4.6 to apply the per-input TV promise to the hard family.

The proof sets `n=2q+1` and `tau=tau_{d,q}`, with absolute `C>0` from Lemma 4.4 and

\[
 \tau_{d,q}=C\left[(q+1)\sqrt{\log d/d}+\frac{(q+1)(q+1+\log d)\log d}{d}\right].
\]

It literally defines a polynomial statistic and measurable test event:

\[
 S_A(x)=(-1)^n x^\top T_n\!\left(\frac{2A-(\kappa+1)I}{\kappa-1}\right)x-2\tau\|x\|^2,
 \qquad E_A=\{x:S_A(x)>0\}.
\]

The source uses first-kind Chebyshev identity `T_n(cos theta_i)=cos(n theta_i)` and implicit polynomial conjugation to identify the first form with `x^T O D_n O^T x`. The energy-weight interpretation divides by `||x||^2` only for `x!=0`; the polynomial event itself covers zero and has `S_A(0)=0`.

There are two necessary branches, connected by AND:

* The algorithm branch uses contracted input Lemmas 4.3 and 4.4, not Lemma 4.5. The q/kappa range gives `n=o(d)` and `tau lesssim d^{-delta/2}(log d)^3 ->0`, uniformly, so `n<d` and `tau<=1/2` eventually. Lemma 4.3 supplies independent Gaussian starting vectors on an extension preserving `(O,X)` law; Lemma 4.4 gives a simultaneous quadratic bound for every vector in their Krylov space. Therefore `S_A(X)<=0` with joint probability at least `.99`, and `E_A[rho_A^Alg(E_A)]<=.01`. This is an input-averaged bound, not a `.01` statement for every fixed input.
* The target branch uses all the relevant outputs of Lemma 4.5 and their transport. It defines `beta=|mu_n|/M`. Uniform `n=o(d)` and `sqrt(kappa)=o(d)` discharge the local condition `d-n>=sqrt(kappa)`. The bias bound and q cap imply `beta>=b d^{-delta/4}`, `b=(1-e^{-4})e^{-3}`. The source uses the weaker consequence `r<=e^{-1/sqrt(kappa)}` of the proved log bound, together with `d>=sqrt(kappa)`, to get `r^{2d}<=e^{-2}<1/3`. The exact `M` formula then gives `M>=d/(2sqrt(kappa))>=d^{(1+delta)/2}/2`.

Those estimates imply `tau/beta <=(Cprime/b)d^{-delta/4}(log d)^3 ->0` and `M beta^2>=b^2 sqrt(d)/2 ->infinity`. The source chooses one `d0(delta)` for the earlier algorithm conditions and additionally `tau<=beta/4`, `M beta^2>=320`. The hidden constant `Cprime` is not numerically specified. These are produced uniform large-d ingredients, not added public moment premises.

For each fixed hard input, draw `Y~pi_A` and put `Z=S_A(Y)`. Lemma 4.5 gives signed mean `(-1)^n mu_n=beta M`, norm mean `M`, and both variances at most `2M`. The source explicitly uses centered-variable L2 triangle, not independence of the two quadratic forms:

\[
 \mathbb EZ=(\beta-2\tau)M\ge\beta M/2,\quad
 \operatorname{Var}(Z)\le(\sqrt{2M}+2\tau\sqrt{2M})^2\le8M.
\]

The first numerical bound uses `tau<=beta/4`; the variance constant uses the earlier `tau<=1/2`. Chebyshev with positive mean and finite variance then yields, for every hard input,

\[
 \pi_A(E_A)=P(Z>0)\ge1-\frac{\operatorname{Var}(Z)}{(\mathbb EZ)^2}
 \ge1-\frac{32}{M\beta^2}\ge.9.
\]

Finally the per-input TV bound applies to each `E_A`; averaging over the input and combining `.9` with the algorithm's average `.01` gives `.89<=epsilon<=.1`, a contradiction. Test measurability and joint-law/conditioning/averaging bookkeeping remain visible source-implicit background nodes. None is licensed as a convenience source hypothesis.

## Topology and open expansion boundary

`source_graph.json` has 77 source-only nodes, 43 AND hyperedges with exact consumer use sites and condition discharge records, and four separately typed citation/provenance edges. The conditional premise of the normalized-bias source result is kept distinct from its downstream large-d discharge, preventing a consumer estimate from appearing as a premise of the source proof. The theorem's statement range is context for the contradiction setup, not a cyclic proof dependency on the theorem conclusion.

No alternative sufficient OR route was found in the declared proof. Grid case splits and the two mean computations are not alternatives; they are parts of the one C.3 route. The means, variances and conditional bias are separate outputs. The two testing branches are both needed. Bibliographic provenance, explanatory comparison and deferred-proof navigation do not become implication edges.

The visible `SOURCE_GAP:unnamed-background` nodes preserve the omitted expansions of complex geometric series/Euler identity, uniform convergence from geometric domination, finite trigonometric sums/product-to-sum/reindexing, Gaussian coordinate laws and moments/integrability, log-integral calculus, orthogonal Gaussian pushforward, polynomial conjugation, uniform asymptotics, centered L2 triangle, Chebyshev, and Borel/joint-law averaging. “Gap” here means the source invoked or omitted the expansion; it does not mean the source is false or that any library lacks the fact. No availability guesses are made.

The source-facing binder and definition interface remains for the root to seal and independently challenge after this freeze. This report does not propose one. In particular, nothing here authorizes replacing a produced finite-moment, variance, concentration, sign, normalized-bias, trace, or threshold estimate with a new public hypothesis.
