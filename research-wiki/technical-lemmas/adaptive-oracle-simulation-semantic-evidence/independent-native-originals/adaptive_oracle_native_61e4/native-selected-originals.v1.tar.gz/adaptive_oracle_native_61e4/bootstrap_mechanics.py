"""New R18 namespace; reuse only R17 process/rebuild mechanics, not any result or ASTIS olean."""
import hashlib,json
from pathlib import Path
OWN=Path(__file__).resolve().parent;REPO=OWN.parents[2]
OLD=REPO/'.astis/semantic-neutral-20261115/matrix_domain_native_61e4'
copies=[]
for name in ['native_common.py','compile_closure.py']:
    raw=(OLD/name).read_text();new=raw.replace('a8bb8ea5b4474be5214bd83ae380a612e2cecb78','57016008083947405bc7d430838537014a40f987').replace('candidate-a8bb8ea5','candidate-57016008').replace('matrix-domain-native-real-command-v1','adaptive-oracle-native-real-command-v1').replace('exact a8bb ASTIS','exact570 ASTIS')
    with (OWN/name).open('x') as f:f.write(new)
    copies.append({'mechanism_file':name,'source_sha256':hashlib.sha256(raw.encode()).hexdigest(),'new_sha256':hashlib.sha256(new.encode()).hexdigest()})
with (OWN/'mechanism-provenance.json').open('x') as f:json.dump({'schema':'R18-native-mechanism-provenance-v1','prior_mechanics_only':copies,'old_checks_verdicts_OSreceipts_ASTIS_olean_not_inherited':True,'fresh_target_math_commit':'57016008083947405bc7d430838537014a40f987','only_explicit_ASTIS_source_closure_will_be_extracted':True,'normal_API_cell_ledger_Git_production_actions':0},f,ensure_ascii=False,indent=2);f.write('\n')
print('R18 process/rebuild mechanics prepared; no compiler/build/audit has run.')
