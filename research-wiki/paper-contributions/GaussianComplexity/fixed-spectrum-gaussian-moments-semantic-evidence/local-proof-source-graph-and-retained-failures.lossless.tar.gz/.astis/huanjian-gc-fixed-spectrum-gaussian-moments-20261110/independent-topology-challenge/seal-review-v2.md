# Actual Gaussian means v2 — exact seal review

**ACCEPT for the exact statement meaning, binder and literal-definition boundary. Source-topology admission is pending the NEW independently frozen extractor graph.** No target proof, actual compiled use, source V or VERIFIED is certified.

Raw cognition preceded all new candidate/graph exposure and is frozen under `SHA256SUMS.raw` SHA-256 `e17a2e6d7acf24865c277df2231e6d4588d461b0241c2f95031d6993aa27336a`. After that freeze, this reviewer read `statement-seal-v2.json`, SHA-256 `eed0782fa32075cdf6313e802293764bd6b07ca991974b9e56c8d520a8e13354`, and the exact standard-definition snippet. The root shorthand `standard-definition.txt` did not exist; the seal's precise reference identifies `multivariateGaussian-standard-definition.txt`, SHA-256 `512ddbd6cb835fbf4bd28967f04a22cb0c0afe42e57036932fbbe27f3a2cf2cd`. A bounded filename lookup resolved that name; this is not a semantic defect or admission HOLD.

The 223-byte standard snippet was compared directly with only the named three-line definition in the pinned Mathlib file. That file's whole-byte digest/size matches the seal (`1fec35cf781da1009c37db80a96b05d70f2296ca7768e19bfc0b6314c9b43d49`, 12755 bytes). No neighboring API, theorem or proof was displayed or interpreted. No candidate Lean/formation code, predecessor seal, old source graph or new extractor rationale was opened.

## Independent binder classification

| Inputs, in both signatures | Classification | Independent source justification |
|---|---|---|
| d:Nat | TYPING | Finite Euclidean dimension carrier. |
| hd:2≤d | STANDING | Literal hard-family range at S4.SS1.p1.1. |
| κ:Real | TYPING | Real spectrum condition parameter. |
| hκ:2≤κ | STANDING | Literal source hard-family range. |
| n:Nat | TYPING | Represents the positive integer source frequency together with its bounds. |
| hn:1≤n | SOURCE | Lemma 4.5/C8 positive mode range. |
| hnd:n<d | SOURCE | Same strict upper mode range needed by the later zero-constant step. |

There is no other public logical premise and no project-owned bundled Prop/typeclass/structure to expand. In particular there is no positivity/PSD witness, coordinate-moment certificate, measurability/integrability premise, independence premise, finite-integral exchange hypothesis or deterministic-series certificate. No EXCESS binder was found independently; the creator's empty EXCESS list was not used as evidence.

Although the norm mean does not mathematically need n, this joint source packet also contains μₙ, and the source 1≤n<d range is faithfully retained. There is no oddness, query relation, asymptotic κ bound or d−n≥√κ condition.

## Literal definitions and covariance convention

The source grid on Fin d has the correct `(i.val+1/2)π/d` shift. The eigenvalue formula retains both halves, and Λ is exactly its diagonal matrix. The law is fixed internally as `multivariateGaussian 0 Λ⁻¹` on actual real finite-dimensional Euclidean space.

The standard definition maps `stdGaussian` by `x ↦ mean + toEuclideanCLM(CFC.sqrt S) x`. Consequently the matrix argument is intended as covariance, not precision or a coordinate scaling matrix. Passing Λ⁻¹ here matches U∼N(0,Λ⁻¹). There is no mistaken use of Λ, Λ^(-1/2) as covariance, or Λ⁻¹ as a standard-normal scaling map. Its covariance interpretation requires the source-domain positive diagonal/inverse facts internally; they are not new input witnesses.

Matrix inversion and CFC.sqrt are standard totalized operations. The local let bodies introduce no project-defined fallback or conditional Gaussian constructor. All statements are restricted by d≥2 and κ≥2, where λᵢ≥1, invertibility and positive covariance must be proved. The theorem may not obtain a source conclusion by using singular/off-SPD defaults, and this ACCEPT supplies none of those facts as a proof certificate.

`‖x‖²` is the actual Euclidean norm square. Q is literally Σᵢcos(nθᵢ)(WithLp.ofLp x i)², the diagonal quadratic UᵀDₙU. Correct coordinate/norm/sum-square and diagonal-matrix identities remain internal correspondence obligations. Neither integrand has been redefined to equal a deterministic inverse-spectrum sum.

## Produced integrability and the Gaussian bridge

The public producer outputs both actual `Integrable` facts and both actual Bochner integral equalities. Thus default-zero integral semantics cannot serve as the intended proof of either expectation; this matters for the signed quadratic form even if an integral happens to vanish. The measure is a fixed actual Gaussian, not a free law callback with moment assumptions.

The first right side Σᵢλᵢ⁻¹ and the second Σᵢcos(nθᵢ)/λᵢ match Ex140 exactly. Coordinate variance/centering, correct diagonal inverse, finite second moments, norm/quadratic integrability and finite integral/sum linearity must be established from the actual law. Gaussian diagonal independence is not inserted as a gratuitous premise; fourth moments or variance estimates are not claimed.

## Real private consumer

The private output is actual Q-integrability and an actual Gaussian integral equal to the alias-supported series, together with Summable of that exact supported series. It retains literal r, integer-divisibility alias/zpow and the cast to Int before forming j+1−n. Its factor d/√κ and both shifted aliases match the already understood deterministic precursor.

This is mathematically more than the previous deterministic test: it must use the NEW Gaussian expectation/integrability bridge, then C7 and all-integer aliasing to evaluate the actual finite spectral sum. The finite Gaussian integral exchange occurs inside the new means producer; source p4.2's infinite-series exchange is over a finite grid, not a new Gaussian-integral/series Fubini premise. No theorem-shaped assumption or wrapper is present in the consumer signature.

Canonical C7/alias and any precision-admissibility/Gaussian substrates mentioned in metadata are proposed implementation dependencies only. No proof/API search was made here and no actual compiled use is certified. Calling an old private test through a mangled name would not satisfy a new public dependency claim; actual authored use remains a later independent check.

## Scope and pending graph review

Both exact signature strings were independently rehashed: producer `4adf051c6547ccf720a1c4a7d3dbb08c6158b934b61a5e5a5c277709d05c6e46`, consumer `a8874e18ef98bb7db14cff90b5199d3188d5e7c31fb03444e6d6f1b3df9516ff`. The metadata's formation/reuse/history claims are exposure, not new mathematical evidence. No Lean compilation was run.

The fresh graph must still expose the actual Gaussian covariance/second-moment/integration route, not import a full Lemma 4.5/C8 statement as an already-proved parent. Producer and consumer root closures must keep source hypotheses distinct from PSD, inverse/covariance, integrability, finite integral linearity and series-exchange proof obligations. Gaussian-law input is a real source premise; it must not be erased by a deterministic-sum definition. The consumer requires the Gaussian producer AND the C7/alias route, with conditional n-range discharge and no false OR or invisible proof-result premise.

Closed C8 means/tail resummations, variances/fourth moments, normalized bias, rotations to target Y, oracle/TV/cost/main bounds and all integration/site/Goal status remain outside this seal admission. The accepted earlier C7/grid source graphs are not reopened. The new extractor graph will be reviewed separately against the frozen raw baseline.
