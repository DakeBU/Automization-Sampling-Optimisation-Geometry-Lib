"""Prepare exact payload and candidate own cell; no tracked/control-plane mutation."""
import copy,json
from guard import *
from evidence_preflight import E,N,HELD,MATH,PL_SHA,PL_APPEND_SHA
import astis_frontier_cells as frontiers

assert git('rev-parse','HEAD').decode().strip()==HELD
original=read(E/'actual-PROVED_LOCAL-evidence.full.json')
assert len(original)==26 and sha((E/'actual-PROVED_LOCAL-evidence.full.json').read_bytes())==PL_SHA
pre=read(O/'evidence-preflight.bounded.json');expr=read(O/'expression-evidence-crosscheck.bounded.json')
final=read(O/'final-reader-and-package-check.bounded.json')
assert final['status']==expr['status']=='PASS'
peer=read(N/'final-native-reader-closure.json')
reader_update={
 'status':'ACCEPTED_EXACT_OWNED_BOUNDED_C3_V2_READER_FIXTURE',
 'reader_candidate':peer['reader_commit'],'actual_native_candidate':peer['math_commit'],
 'actual_report_sha256':final['actual_C3_v2_report_sha256'],'actual_checker_exit':0,
 'independent_native_visual_reviewer':'gram_native_6a27',
 'four_reader_contexts':4,'byte_exact_full_code_lines':[208,136],'source_download_checks':12,
 'bounded_production_graph_checks':2,'eight_P13_T14_anchors_clear_header':True,
 'mobile_table_scroll100_MAX':[100,324],
 'actual_source_pre_scroll_scope':final['actual_source_pre_scroll_scope'],
 'source_glyph_geometry_qualification':'Mobile longest-line right ends around y413 are below and clear of sticky header bottom60.42, within844px viewport.',
 'actual_candidate_and_C2_reference_manifests_unchanged_before_after':True,
 'candidate_site_manifest_sha256':'a12af8c19a0f1323343e9cbd578d28e68ab1c745386b20db44aaf7398fa35985',
 'original_FAIL_C1_untested_C2_bounded_residual_failed_C3_v1_preserved':True,
 'failed_C3_v1_diagnosis':'Checker relied on immediate geometry after smooth viewport scrolling; actual horizontal movement passed. V2 uses explicit instantaneous measured viewport positioning at the exact same frozen C3 site and retains strict right-glyph/header/viewport assertions.',
 'historical_original_PL_pending_strings':'All26 original fields remain inline unchanged; this separate current closure adds later evidence without rewriting those historical statements.',
 'candidate_CSS_globally_applied':False,'shared_production_CSS_unchanged':True,
 'global_production_delivery_integration_publication_purification_whole_Goal':'HOLD',
 'exact_native_reader_closure':{'path':str((N/'final-native-reader-closure.json').relative_to(ROOT)),
                              'sha256':'1459c72b4ab63e012ef06ebbfec773ed6e1301344dbb0b086838a1e31f60629e'},
 'exact_independent_reader_judgment':{'path':str((N/'reader/C3-bounded-acceptance.json').relative_to(ROOT)),
                                    'sha256':'4ace0a1bf4af5e0652aea3d1e325b7f14c29d190ef89dbbbbf7682f3b5812226'},
 'frozen_wording_qualification':{'path':str((O/'peer-wording-qualification.json').relative_to(ROOT)),
                                 'sha256':sha((O/'peer-wording-qualification.json').read_bytes())}}
payload=copy.deepcopy(original)
payload.update({
 'verifier_id':VERIFIER,'verified_commit':HELD,
 'gate':{
  'status':'PASS_LOCAL_MATHEMATICS_SOURCE_NATIVE_BOUNDED_READER_AND_FOUR_HELD_CLI_GATES',
  'native_mathematical_candidate':MATH,'actual_executed_ROOT_build_HEAD_qualification':original['executed_build_qualification'],
  'all_eight_live_Lean_module_bytes_identical_to_native_and_held_commits':pre['eight_module_exact_identity'],
  'held_commit_claimed_rebuilt':False,'complete_native_type_value_rechecks':41,'complete_ExprDAG_nodes':52106,
  'actual_four_held_CLI_gate_originals':pre['four_held_gate_originals'],
  'held_gate_summary':{'path':str((N/'final-metadata-result.json').relative_to(ROOT)),
                       'sha256':'b80430e119de180612b878b64881dab8ac8b103b124380ae5c546a3b8a2eca4d'},
  'verification_method':'Read unchanged original source/native/reader evidence and actual gate raw streams; no source review, Lean build, browser or four CLI gate replay. Normal API retains its mandatory real publication admission.',
  'scope':'Local acceptance only. Root build/shared graph/site/global integration and purification remain separate.'},
 'source_audit':{
  'status':'ACCEPTED_EXISTING_INDEPENDENT_SOURCE_REVIEW_REUSED',
  'reviewer':'gram_src_e182','public_audit_id':'ASTIS-RT-20261113-HuanjianGaussianSourceGramRealization',
  'public_binding_sha256':original['publication_binding_sha256'],
  'private_T_binding_sha256':'e8d5ad9ff1297f051c7449ffd71f7cf9131fbf4de7400e3ebf91e5d805d56b4f',
  'independent_exact_selected_original_archive_members_checked':41,
  'independent_current_P_T_inputs_seven_slots_blind_decoder_and_packet_run_provenance_checked':True,
  'source_conclusion':'Public exact eventwise Ex125 equivalent after elaboration; private T openly authored all-real-threshold deterministic Ex126 generalization only. No probability or public T API credit.',
  'a_bound_qualification':'Only needed a<=1 derived internally; no proof credit for lower half0<=a.'},
 'semantic_roundtrip_audit':'ASTIS-RT-20261113-HuanjianGaussianSourceGramRealization accepted/equivalent-after-elaboration; separate private T accepted with explicit threshold generalization. Seven slots and independent decoder/source-review provenance preserved.',
 'fake_closure_scan':{
  'status':'PASS_UNCHANGED_EIGHT_MODULE_NATIVE_AND_COMPLETE_EXPRESSION_EVIDENCE',
  'source_scan':{'path':str((N/'fake-closure-source-scan.json').relative_to(ROOT)),
                 'sha256':sha((N/'fake-closure-source-scan.json').read_bytes())},
  'complete_declaration_type_value_rows':41,'complete_ExprDAG_nodes':52106,
  'closed_and_kernel_checked':True,'standard_axioms':expr['standard_axioms'],'nonstandard_axioms':[],
  'actual_complete_owned_emissions':4,'two_handwritten_plus_two_generated':True,
  'all_owned_reachable_and_canonical_parent_P_to_T_constants_checked':True,
  'universal_literal_seals_genuine_q0_universal_and_q0d2_proof_checks':True,
  'real_Euclidean_L2_operator_norm_CLM_action_and_topology_checked':True,
  'independent_expression_crosscheck':{'path':str((O/'expression-evidence-crosscheck.bounded.json').relative_to(ROOT)),
                                       'sha256':sha((O/'expression-evidence-crosscheck.bounded.json').read_bytes())}},
 'final_current_reader_update':reader_update,
 'final_native_reader_package':{
  'path':str((N/'selected-native-reader-originals.lossless.tar.gz').relative_to(ROOT)),
  'sha256':'758996d2b885c394edc8acc6cb45300cfacc35deea362f784343fb6225bf02d0','bytes':12617237,
  'regular_members':365,'exact_nested_native_archive_occurrences':1,
  'all_selected_and_nested_original_payloads_byte_checked':True,
  'recursive_private_map_scan':'PASS','whole_neutral_directory_exported':False,
  'archive_manifest_sha256':'9e891739cbe2247b579225e6e4dbc8c7c5c70e05fdca8de5fc14dfc63038d0d4',
  'archive_closure_sha256':'404cb895810f0d94bfc250efc31ac3693b3525d2439518281633f13c0f1b3b7b'},
 'original_PL_carry':{'field_count':26,'all_original_fields_inline_unchanged':True,
                      'original_payload_sha256':PL_SHA,'original_exact_append_sha256':PL_APPEND_SHA,
                      'historical_pending_failure_boundary_strings_preserved':True},
 'verification_scope':{
  'local_mathematics_source_native_and_owned_bounded_reader':'VERIFIED',
  'retained_owner':OWNER,'stabilization_owner_transfer':False,
  'sole_hq_q0_original_product_mu_actual_mean_B_inclusive_G_preserved':True,
  'public_P_exact_centered_and_weighted_Gram_identities':True,
  'private_T_actual_same_outcome_eventwise_all_real_Delta_norm_implication':True,
  'probability_Bernstein_full_C6_Lemma4_4_Krylov_main_lower_bound_oracle_TV_caps_cost_claim':False,
  'shared_CSS_imports_Registry_global_indices_site_main_integration_changed':False,
  'integration_publication_purification_whole_Goal':'HOLD'},
 'preservation_verification_plan':{
  'historical':'All312 foreign advance full states/472 frontier files/43 discoveries and136171 tracked/116040 control fingerprints plus foreign index entries checked locally before and after.',
  'fresh':'Exact held whole index/current tracked/control/frontier files/full states and ledger prefix; only own C plus exactly one expected normal V append may change.',
  'full_private_maps_indexes_and_control_snapshots_exported':False}
})
assert all(payload[k]==v for k,v in original.items()),'original PL field changed'
cell=read(ROOT/C);before=copy.deepcopy(cell)
assert cell['status']=='proved_locally' and cell['owner_id']==OWNER
cell['status']='independently_verified'
cell['evidence']['independent_verification']=(
 'Independent verifier gram_final_verifier_91dc at held f7a38f36 accepted local exact P/private T mathematics, source/native evidence and all four actual held CLI gates. Independent C3-v2 bounded reader closure accepted; original FAIL/C2 residual/failed C3 and all26 historical PL fields remain inline unchanged. Candidate CSS globally UNAPPLIED, original owner retained; integration/publication/purification/whole Goal HOLD. Details separately under independent_verification_details.')
cell['evidence']['independent_verification_details']=copy.deepcopy(payload)
cell['evidence']['final_current_reader_update']=copy.deepcopy(reader_update)
assert all(cell[k]==v for k,v in before.items() if k not in ['status','evidence'])
assert all(cell['evidence'][k]==v for k,v in before['evidence'].items())
cells=frontiers.load_cells()
for ix,current in enumerate(cells):
    if current.get('cell_id')==cell['cell_id']:
        cells[ix]=dict(copy.deepcopy(cell),__path__=C)
errors=frontiers.validate_cells(cells);assert not errors,'prepared full frontier schema rejected'
create(O/'VERIFIED-evidence.full.json',dump(payload));create(O/'candidate-cell.exact.json',dump(cell))
create(O/'ROOT-READY.received.json',dump({'source':'Explicit ROOT FINAL READY message after exact native closure/archive hashes',
 'held_HEAD':HELD,'authorized_actor':VERIFIER,'at_most_one_normal_VERIFIED_API_call':True,
 'mutation_scope':[C,L],'original_PL_fields_inline_unchanged':26,'owner_retained':OWNER,
 'full_private_maps_local_only':True,'postwrite_full_frontier_schema_required':True,
 'ROOT_actual_V_calls':0,'native_final_closure_sha256':'1459c72b4ab63e012ef06ebbfec773ed6e1301344dbb0b086838a1e31f60629e'}))
print(json.dumps({'status':'PREPARED_NO_TRACKED_MUTATION','original_PL_fields_inline_unchanged':26,
 'payload_sha256':sha((O/'VERIFIED-evidence.full.json').read_bytes()),
 'candidate_C_sha256':sha((O/'candidate-cell.exact.json').read_bytes()),
 'independent_verification_type':type(cell['evidence']['independent_verification']).__name__,
 'candidate_full_frontier_schema':'PASS','normal_VERIFIED_calls':0},indent=2))
