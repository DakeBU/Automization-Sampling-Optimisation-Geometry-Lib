"""TL-COV-1: only two role-string replacements; no old artifact mutations."""
from pathlib import Path
from copy import deepcopy
import hashlib,json

REPO=Path('/Users/zhouhuanjian/ASTIS-GC')
OWN=Path(__file__).parent;P1=OWN.parent;P2=P1/'phase2'
FB=REPO/'.astis/semantic-neutral-20261110/tl_tc_7c319d/phase2b'
sha=lambda b:hashlib.sha256(b).hexdigest()
def dump(name,data):(OWN/name).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
feedback_expected={
 'manifest.json':'999c718895f98d8b49decf54aea3121a9093fb0c6479d7950180113cb141e301',
 'independent-topology-coverage-report.md':'d672251fcdbbf8251f5b7c92c83aaa738df3305db7b2d71b8ad3f691a6377910',
 'verdict.json':'d712da89f7f45c981fa87f8aedda16f4f3f09153adf3950aad63c62ee47ca497',
 'coverage-role-witness.json':'67cba4624ad6eadd9fc6ff2d35cc6f5f725b9c9d55118504ba3b5ea1fc1a68ed'}
feedback=[]
for name,h in feedback_expected.items():
 b=(FB/name).read_bytes();assert sha(b)==h
 feedback.append({'path':str((FB/name).relative_to(REPO)),'bytes':len(b),'sha256':h,
  'read_scope':'Authorized manifest metadata for locating the three whitelisted mathematical feedback files only' if name=='manifest.json' else 'Authorized mathematical feedback only'})

preserved=[]
for directory,name,h in [(P1,'phase1_manifest.json','d610a5424dcf5106393e735c793c7a8ae41a1844038e7506a1043addaaca58dd'),
 (P2,'manifest.json','0c52f44dfde7dcec01a10316e88a7643db1e136ba24598dd215fc62cdd3c1f8c')]:
 b=(directory/name).read_bytes();assert sha(b)==h;m=json.loads(b)
 for f in m['files']:assert sha((directory/f['file']).read_bytes())==f['sha256']
 preserved.append({'path':str((directory/name).relative_to(REPO)),'sha256':h,'all_recorded_file_bytes_unchanged':True})

basep=P2/'coverage_alignment.json';baseb=basep.read_bytes()
assert sha(baseb)=='755076e7d113736233ca0717dcd5365b510d06e47f45dbebf2eeef2333028495'
base=json.loads(baseb);successor=deepcopy(base)
changes=[
 (65,'A3.Ex160','Normalizer-only sibling/context: Gaussian partition-function determinant formula; outside the exact fixed-O law and norm-sum consumer outputs.'),
 (66,'A3.SS4.p3.2','Normalizer-only sibling/context: fixed Lambda makes Z_A independent of O and public with the spectrum; outside the exact fixed-O law and norm-sum consumer outputs.')]
operations=[];row_diffs=[]
for i,sid,role in changes:
 old=base['items'][i];assert old['source_id']==sid
 assert old['unchanged_disposition']=='NODE' and old['unchanged_node']=='bg:C4-normalizer'
 assert old['exact_type_scope_role']=='Mixed source region: selected mean/target-law statement only; other outputs preserved outside exact type'
 successor['items'][i]['exact_type_scope_role']=role
 operations.append({'op':'replace','path':f'/items/{i}/exact_type_scope_role','value':role})
 row_diffs.append({'source_id':sid,'json_pointer':f'/items/{i}/exact_type_scope_role',
  'original_role':old['exact_type_scope_role'],'successor_role':role,
  'raw_sha256_unchanged':old['raw_sha256'],'source_node_unchanged':old['unchanged_node'],
  'NODE_disposition_unchanged':True})
dump('coverage_alignment_v2.json',successor)
newsha=sha((OWN/'coverage_alignment_v2.json').read_bytes())

def differences(a,b,path=''):
 if type(a)!=type(b):return [path]
 if isinstance(a,dict):
  assert a.keys()==b.keys();out=[]
  for k in a:out.extend(differences(a[k],b[k],path+'/'+k))
  return out
 if isinstance(a,list):
  assert len(a)==len(b);out=[]
  for i,(av,bv) in enumerate(zip(a,b)):out.extend(differences(av,bv,path+'/'+str(i)))
  return out
 return [] if a==b else [path]
diff=differences(base,successor)
assert diff==['/items/65/exact_type_scope_role','/items/66/exact_type_scope_role']
replayed=deepcopy(base)
for op in operations:
 idx=int(op['path'].split('/')[2]);replayed['items'][idx]['exact_type_scope_role']=op['value']
assert replayed==successor

untouched_expected={
 '.astis/semantic-neutral-20261110/d_sg_48e2c0/source_graph.json':'2d47aa63ead6a81895dd7f81e0a3f854ec9c5041a42dc4d48faa66687ccfe2c1',
 '.astis/semantic-neutral-20261110/d_sg_48e2c0/phase2c_tc_b1_successor/source_graph_v2.json':'a3d876092b9854614c6d09bba8f1fa4add8d772ba030fa2358526b9c55ac6449',
 '.astis/semantic-neutral-20261110/d_sg_48e2c0/coverage_inventory.json':'63f9a219a6b0d20cbe40acfcdae91f4049c4666363fbfddc48e0f0f4285e377a',
 '.astis/semantic-neutral-20261110/tl_sg_b41a8e/coverage_checkpoint.json':'d473ec821c3c489d204e908400149b5472f729dd490ec951a90a051f3c9da667',
 '.astis/semantic-neutral-20261110/tl_sg_b41a8e/source_root_map.json':'5c433ebe49be188db05bad6c91dac3903a5767539ee18939e36860d1cabac1df',
 '.astis/semantic-neutral-20261110/tl_sg_b41a8e/phase2/source_root_map_v2.json':'3448a14a9634474f6e7855c7e899e5b0631c14cde0a1118158db2dedc3ab56bd',
 '.astis/semantic-neutral-20261110/tl_sg_b41a8e/phase2/exact_source_selector_delta.json':'660724759634bdc66d7082815ccaf0e6c139a173000cf64d67c0cd6f41387700',
 '.astis/semantic-neutral-20261110/tl_sg_b41a8e/phase2/target_binding.json':'b33d7bd876b4a4a7ca6114a521544b28110a5ee0bc64266b8950d6a2b1ddd1fa',
 '.astis/semantic-neutral-20261110/tl_sg_b41a8e/phase2/type_semantic_use_overlay.json':'991816a8f58b34509474606e48f7cd29751c1248717e51def9847ca47db0be47'}
untouched=[]
for rel,h in untouched_expected.items():
 assert sha((REPO/rel).read_bytes())==h
 untouched.append({'path':rel,'sha256':h,'unchanged':True,'read_scope':'Hash/integrity only for this repair; no source/proof verdict inherited.'})

delta={'finding':'TL-COV-1','kind':'TWO_ORIGINAL_ELEMENT_SCOPE_ROLE_STRING_SUCCESSOR',
 'base_path':str(basep.relative_to(REPO)),'base_sha256':sha(baseb),
 'successor':'coverage_alignment_v2.json','successor_sha256':newsha,
 'exact_json_patch_operations':operations,'original_and_revised_rows':row_diffs,
 'source_recheck':{'source_sha256':'6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915',
  'complete_raw_element_reread':'A3.SS4.p3',
  'reason':'A3.Ex160 is the Z_A partition/determinant formula and A3.SS4.p3.2 is public-normalizer independence of O. Only preceding p3.1 contains the actual target definition. The two later rows must not inherit that selected suboutput merely from sharing bg:C4-normalizer.'},
 'all_other_values_unchanged':True,'NODE_removal':False,'new_graph_or_type_change':False,
 'old_HOLD_and_all_originals_preserved':True,
 'classification':'Author alignment attribution mistake, not a mathematical source/type refutation.',
 'independent_rereview':'PENDING','proof_credit':False}
dump('exact_two_role_delta.json',delta)
dump('before_after_two_rows.json',[
 {'source_id':sid,'original_complete_row':base['items'][i],
  'successor_complete_row':successor['items'][i]}
 for i,sid,role in changes])
dump('preservation_checks.json',{'changed_JSON_pointers_only':diff,'exact_two_replace_replay_matched':True,
 'all_other_alignment_values_unchanged':True,'raw_NODE_EXCLUDED_hash_spans_node_ids_unchanged':True,
 'unchanged_frozen_manifests':preserved,'unchanged_base_graph_coverage_selector_type_files':untouched,
 'old_feedback_files_still_match_authorized_hashes':all(sha((REPO/f['path']).read_bytes())==f['sha256'] for f in feedback),
 'authority':'Mechanical integrity only, not a new source/type/proof or topology verdict.'})
dump('actual_input_whitelist_and_exposure.json',{'role':'Original author; not a new blind actor','authorized_feedback':feedback,
 'raw_reread':'Pinned original HTML A3.SS4.p3 complete paragraph/display group, via own frozen parser.',
 'existing_own_inputs':'Frozen alignment plus own manifests/files for integrity only; unchanged source selectors/types and all prior role history retained.',
 'not_read':['root full seal/process/normal-intake/history plans','foreign raw cognition or other foreign artifacts','new Mathlib/API/Lean/proof implementation'],
 'mutations':'This new phase2c_coverage_role_successor directory only. Old phase2/HOLD/source/coverage/selector/types unchanged.',
 'next_action':'Freeze and pause; original distinct TC actor independently rereviews the two role strings.'})
dump('successor_reviewer_packet.json',{'purpose':'Independent TL-COV-1 two-role-string successor rereview only',
 'candidate_successor':'coverage_alignment_v2.json','candidate_sha256':newsha,
 'read_whitelist':[
  {'path':str(basep.relative_to(REPO)),'sha256':sha(baseb)},
  {'path':str((OWN/'coverage_alignment_v2.json').relative_to(REPO)),'sha256':newsha},
  {'path':str((OWN/'exact_two_role_delta.json').relative_to(REPO))},
  {'path':str((OWN/'before_after_two_rows.json').relative_to(REPO))},
  {'path':str((OWN/'preservation_checks.json').relative_to(REPO))},
  {'path':'.astis/huanjian-resume-20261103/2610.20492v1.html','sha256':'6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915','scope':'A3.SS4.p3 original complete raw element'},
  *feedback],
 'challenge':['Exactly two role-string replacements and no other values changed?','Both rows describe only retained normalizer context outside exact law/norm-sum outputs?','Both original NODE/bg:C4-normalizer/raw spans/hashes remain intact?','All previous source graph/coverage/7-operation selector delta/type binding and HOLD remain immutable?'],
 'withhold':['Any author raw cognition/private process notes','root process/plans/normal intake','implementation/API/proof material'],
 'status':'PENDING_ORIGINAL_DISTINCT_ACTOR_REREVIEW','proof_credit':False})
print(json.dumps({'successor_sha256':newsha,'only_changed_pointers':diff,'old_freezes_preserved':True,'independent_rereview':'PENDING','proof_credit':False}))
