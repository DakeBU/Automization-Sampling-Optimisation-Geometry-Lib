# Phase 1: independent raw-source cognition freeze

Actor: `/root/signal_topology`, distinct from the source-topology extractor.
This is an immutable pre-statement/pre-extractor record. Later judgment must be
written separately, retaining this record and its digest unchanged.

## Evidence and exposure boundary

The only mathematical evidence opened for this phase was the specified raw
HTML `arXiv:2610.20492v1`,
`.astis/huanjian-resume-20261103/2610.20492v1.html`, SHA-256
`6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915`.
I read full Section 2 (`S2`), full Section 4 (`S4`, including 4.4), full Appendix
C.3 (`A3.SS3`), and bibliography entry [22] (`bib.bib3`). I inspected the raw
document's section heading/ID inventory only to identify these scopes; I did
not read mathematical text in other sections through that inventory.

I also read the complete `AGENTS.md`,
`docs/contributor-codex-contract.md`, `docs/proof-digestion-protocol.md`,
`docs/evidence-routed-memory-protocol.md`, and
`.agents/skills/astis-source-dependency-audit/SKILL.md`. These impose process
constraints, not mathematical evidence for a claim. The task packet exposed
the paper identity and requested reading scopes, but no proposed declaration,
statement seal, candidate implementation, extractor graph/coverage, private
rationale, prior verdict, lesson, frontier, or audit was opened. I did not
inspect sibling `.astis` directories or infer a selected target from names. I
did not run Lean, search Mathlib, devise an alternate proof, or mutate canonical
repository/ledger state. Writes are confined to this new task directory.

The supplied scope includes statements whose proofs are deferred outside the
scope. In particular C.1, C.2 and C.4 remain unopened; [22]'s actual preprint
remains unopened. Their content is not certified by reading a citation. No
claim here certifies the entire paper, source correctness, Lean correctness,
or mathematical novelty. A later graph can expose a boundary but cannot
silently count an unopened dependency as independently audited.

`phase1-full-scope.txt` is the full readable extraction of the four read
scopes, preserving formulas through the HTML's MathML `alttext`.
`phase1-raw-units.json` records raw source IDs, texts and outgoing crossrefs
for paragraphs, displays/display groups, statement/proof containers and [22].
Container and paragraph/display entries intentionally overlap: the inventory
is a retrieval aid, not an arithmetic coverage proof. The mathematical region
map below is my independently reasoned cognition.

## Section 2: standing semantics that must survive translation

`S2.p1` fixes Euclidean norm and identity matrices. `S2.p2` fixes Loewner order,
the real orthogonal group with Haar probability, determinant components of
mass one half, and the conditioned Haar laws. These definitions are not proof
conclusions.

`S2.SS0.SSS0.Px1.p1`, `S2.Ex1`, and `S2.E1` define the admissible precision
class for an integer dimension at least one and real condition parameter at
least one, the centered Gaussian target with covariance inverse to the
precision, and the exact value-and-gradient oracle. The unnamed equivalence
argument in `S2.SS0.SSS0.Px1.p2` is substantive: an FO response contains the
matrix-vector response, while a matrix-vector response reconstructs the value
and gradient. It supplies both simulation directions. It must not be replaced
by a unilateral implication or by a claim about approximate/noisy oracles.

`S2.SS0.SSS0.Px2.p1` allows adaptive Borel queries, Borel stopping and arbitrary
Borel outputs. Internal randomness is input-independent. A fixed budget is an
integer cap on every run for every input and every seed; it is not an expected
query bound. Output need not lie in the span of previous queries and replies.

`S2.SS0.SSS0.Px3.p1`/`S2.Ex2` use TV as a supremum over measurable events and
also its density formula; the expectation bound is for measurable functions
with range in [0,1]. `S2.E2` and its surrounding paragraph define the infimum
over deterministic caps for an existing randomized algorithm with uniformly
small per-input TV after averaging its seed. A random hard input may be used
inside a lower-bound argument, but it does not replace that public uniform
accuracy quantifier by average-case accuracy. Dimension, condition parameter,
and accuracy domains must not disappear in a future public interface.

## Section 4: source architecture and raw mathematical regions

The context paragraph `S4.p1` cites [22] for the earlier well-conditioned
constant-accuracy logarithmic lower bound; `S4.p2` compares the scope of the new
bound to Theorem 3.1. These are context, not extra parents in the proof of the
new bound. Theorem 3.1 was not read in this phase.

`S4.Thmtheorem1` asserts: for each fixed delta in (0,1), one dimension threshold
depending only on delta works for every integer dimension above it, every
condition parameter between 2 and d^(1-delta), and every positive accuracy at
most 1/10, giving delta/256 times sqrt(kappa) log d as a query lower bound.
The same spectrum may be supplied to the algorithm. The threshold is uniform
in kappa and epsilon; a threshold chosen after either parameter is not this
statement. Neither a source probability event nor a source-derived estimate
belongs as a new public premise.

`S4.SS1.p1` and `S4.E11` define midpoint angles and a cosine precision spectrum,
for dimension at least two and kappa at least two. The precision is a Haar
rotation of that diagonal spectrum, independent of the algorithm's seed.
`S4.SS1.p2` explains that the deterministic spectrum and normalization can be
known: uncertainty is in eigenvectors. The construction is attributed to
[22, Section 9.2]; the external citation must remain an explicit boundary.

`S4.Thmtheorem2` has two distinct substantive observations: affine oracle
equivalence to the kappa=2 construction using the same rotation, and the
algorithm/target contrast at frequency n=2q+1. The latter is an explanatory
forecast of Lemmas 4.4/4.5, not a third independent proof of them. It does not
permit reversing the edges from a desired lower bound to either lemma.

`S4.SS2.p1` is an architecture summary: all four lemmas have distinct jobs.
`S4.SS2.SSS0.Px1.p1` cites [22, Lemma 9.2] for deferred rotation.
`S4.Ex10` defines the block Krylov space with q+1 independent Gaussian starts
and powers from zero through q. `S4.Thmtheorem3` supplies the almost-sure output
representation when 2q+1<d. `S4.SS2.SSS0.Px1.p3` records why q+1, not q,
starting vectors are needed: the output may be outside the observed span.
Coefficients may depend on the full extended experiment. No independence of
those coefficients from the Gaussian starts is asserted. The extension must
preserve the joint law of rotation and output. C.1 is an explicit deferred
proof boundary, not an audited derivation here.

`S4.SS2.SSS0.Px2.p1`/`S4.Ex12` define n and the diagonal cosine statistic;
frequency n exceeds all frequencies from products of degree-q cosine
polynomials. `S4.Thmtheorem4`, `S4.Ex13`, and `S4.Ex14` assert an absolute
constant C, the displayed two-term tau(d,q), and a simultaneous bound for every
vector in the Krylov space, with probability at least .99, conditional on
tau<=1/2. This is uniform in the vector, so it handles random coefficients
depending on the entire experiment. It is not a pointwise fixed-vector bound.
`S4.SS2.SSS0.Px2.p2` supplies the nonconstant affine change from lambda powers
to cosine polynomials and explains independence of kappa. C.2 is deferred.
`S4.SS2.SSS0.Px2.p3`/`S4.Ex15` apply 4.3 and 4.4 conjunctively to the output.
The conditional tau premise still has to be discharged at the application.

`S4.Thmtheorem5`/`S4.EGx1`/`S4.Ex17` assert two exact target means, both variance
bounds, and a conditional lower/upper bound for normalized bias. The objects
are a diagonal-covariance Gaussian, the same cosine grid, kappa>=2, and an
integer frequency with 1<=n<d. The additional condition d-n>=sqrt(kappa) is
attached to the exponential two-sided bias estimate; it is not a premise for
the exact means or variances. `S4.SS2.SSS0.Px3.p2` supplies the orthogonal
transport back to an exact target sample given the rotation, retaining both
norm and quadratic statistic. C.3 proves 4.5 and is read below.

`S4.SS2.SSS0.Px4.p1`/`S4.Thmtheorem6` assert admissibility for every orthogonal
rotation, with proof deferred to C.4. This permits application of a per-input
accuracy promise on the hard family, not merely on typical rotations.

`S4.SS3.p2` fixes parameters and a hypothetical algorithm below the proposed
cap, then invokes admissibility. `S4.SS3.p3`/`S4.EGx2` define the signed
Chebyshev-matrix quadratic statistic minus 2tau times the squared norm, and
its strictly positive event. `S4.SS3.p4` supplies the spectral interpretation
using T_n(cos theta)=cos(n theta). Its normalized weights are only introduced
for nonzero x; the polynomial statistic/event itself is meaningful at zero.
Measurability of the event and its input dependence are needed for the later
TV comparison; the event need not be a common fixed set for every input.

`S4.SS3.SSS0.Px1.p1`, `S4.Ex20`, `S4.Ex21`, and `S4.Ex22` are a substantive
unnumbered algorithm-side chain. The cap on q and the kappa range imply
n=o(d), tau bounded by delta-dependent decaying powers times logarithms, and
eventually n<d and tau<=1/2. Only then may 4.3 and 4.4 be used; their extension
and uniform probability event yield expected algorithmic event mass at most
.01 over the random input. These asymptotic premise discharges cannot be
covered merely by listing the two numbered lemmas.

`S4.SS3.SSS0.Px2.p1` names M, mu and beta. The paragraph and displays
`S4.SS3.SSS0.Px2.p2`, `S4.Ex23`, `S4.Ex24` comprise separate bookkeeping:
eventually d-n>=sqrt(kappa); beta >= b*d^(-delta/4), with the absolute
b=(1-exp(-4))*exp(-3); rho^(2d)<=exp(-2)<1/3; M>=d/(2sqrt(kappa));
tau/beta tends to zero; and M*beta^2 grows at least as an absolute multiple of
sqrt(d). The source explicitly says these estimates are uniform over the
parameter range. Their conjunction allows a single d0(delta), with all earlier
conditions plus tau<=beta/4 and M*beta^2>=320. These are internal conclusions,
not allowable theorem binders. Source displays invoke a weakened estimate
rho<=exp(-1/sqrt(kappa)); the stronger estimate in C.3 can supply it.

`S4.SS3.SSS0.Px2.p3`, `S4.Ex25`, and `S4.Ex26` are another substantive chain:
4.5 gives the signed mean and both variance bounds; the L2 triangle inequality
for centered variables handles covariance between norm and statistic (they
are not independent); the chosen tau yields mean>=beta*M/2 and variance<=8M;
one-sided use of Chebyshev yields target event probability at least .9 for
each hard input. The .9 bound depends on the numerical 320 threshold.

`S4.SS3.SSS0.Px3.p1`/`S4.Ex27` use per-input TV on that input's measurable
event, average over the random precision, and combine .9 with .01 to obtain
.89<=epsilon<=.1, a contradiction. Section 2's deterministic budget semantics
and uniform seed-averaged TV matter here. The source uses one sufficient route
whose branches (algorithm failure event and target success event) are an AND
at this comparison; no alternate proof of 4.1 appears in the read scope.

## Section 4.4 is a scope boundary, not another theorem parent

`S4.SS4.p1` states what the earlier theorem does not achieve. The kappa
discussion (`S4.SS4.SSS0.Px1.p1`, `S4.Thmtheorem7`, `S4.Ex28`,
`S4.SS4.SSS0.Px1.p2`, `S4.Ex29`) asserts the almost-sure Krylov dimension
min(d,(q+1)^2), then explains saturation. The distinct spectrum matters. When
the space is all of R^d and 1<=n<d, the grid cosine-square sum yields a
coordinate whose absolute diagonal statistic is at least 1/sqrt(2), obstructing
a vanishing uniform bound. The dimension lemma has no proof in the read scope;
a graph must show the unsupported/deferred boundary rather than invent a
proof. The line calling a supremum bound of 1/2 a requirement of Lemma 4.4
deserves care: the lemma as stated has the conditional conclusion 2tau, with
tau<=1/2. Its exact numerical formulation is not literally the same statement.
The qualitative obstruction to a sufficiently small uniform bound is clear,
but I do not silently repair or certify this numerical phrasing.

The accuracy discussion (`S4.SS4.SSS0.Px2.p1`, `S4.Ex30`) needs a threshold
between the uniform bound and the target bias: algorithm uniform bound requires threshold>=a,
target Chebyshev needs threshold below absolute normalized bias. It invokes
the Bernstein calculation of Fact C.6 for a>=c/sqrt(d), a separate unopened
proof region in C.2. The upper bias estimate from 4.5 then caps q at order
sqrt(kappa) log d, regardless of epsilon. These observations constrain this
analysis; `S4.Thmtheorem8` explicitly leaves stronger lower bounds for the same
fixed-spectrum family open. They do not prove impossibility for all tests or
algorithms. The two limitations are separate conclusions, not an AND-premise
of the already proved lower bound and not OR-proofs of it.

## Appendix C.3: detailed source-only dependency cognition

`A3.SS3.p1` restates the same theta/lambda grid and announces three tasks.
Fact C.7 (`A3.Thmtheorem7`, `A3.Ex133`) expands the scalar inverse spectrum
as (1/sqrt(kappa)) times 1 plus twice the cosine series with coefficients
(-rho)^j. It asserts absolute and uniform convergence in theta. Its inherited
kappa>=2 guarantees 0<rho<1; positivity is not an extra standalone public
assumption if rho is defined by kappa. Uniform convergence here is in theta
for each fixed admissible kappa, not a claim of uniform convergence as kappa
ranges without bound.

The C.7 proof is all in `A3.SS3.p2`, `A3.EGx14`, `A3.Ex136`, `A3.Ex137`:
geometric series at complex conjugate points yields the Poisson-shaped
rational expression; two algebraic rho/kappa identities identify the inverse
spectrum; the geometric absolute majorant independent of theta gives absolute
and uniform convergence. Both the rational identity and convergence claim
require coverage. Convergence is used at the finite-grid interchange in C.8,
not an optional decorative sentence.

Fact C.8 (`A3.Thmtheorem8`, `A3.Ex138`) gives both exact finite-grid means.
Its proof begins with the grid aliasing identity for every integer k at
`A3.SS3.p3`/`A3.Ex139`: the cosine sum is zero except at multiples 2ad, when
it is d*(-1)^a. The exceptional case includes k=0 and negative multiples.
The finite-cosine-sum argument's denominator is used only off those multiples.
This identity is local source mathematics, not an imported citation.

`A3.SS3.p4`/`A3.Ex140` identify Gaussian coordinate second moments with inverse
eigenvalues, express M and mu as the corresponding finite sums, and explicitly
invoke C.7 for interchange. For M, `A3.SS3.p5`/`A3.EGx15` select only
j=2ad, a>=1, preserve the (-1)^a aliasing sign, and resum a geometric series.
For mu, `A3.SS3.p6`/`A3.Ex144`/`A3.EGx16` first remove the zero base sum,
use product-to-sum, and classify surviving j into j=n, j=2ad+n and j=2ad-n.
The three positive-index classes are disjoint specifically because 1<=n<d.
The parity identity for (-rho)^(2ad+-n) yields the sign (-1)^n; both tails
then resum to rho^n-rho^(2d-n). Losing either tail or identifying n=d would
change the result. M's derivation and mu's derivation are sibling branches
using the same grid/series parents, jointly supplying the two-mean fact.

`A3.SS3.p7` applies C.8 to give the two means of Lemma 4.5. The variance
paragraph `A3.SS3.p8`/`A3.EGx17` uses diagonal Gaussian independence, the fourth
moment 3/lambda_i^2, hence Var(U_i^2)=2/lambda_i^2, and lambda_i>=1. It
separately bounds the unweighted and cos-weighted variances by 2M and uses the
exact M formula to bound M<=d/sqrt(kappa). Those Gaussian moment identities,
independence, and variance additivity are mathematical bridges, even though
not separately numbered or externally cited here.

`A3.SS3.p9`, `A3.Ex150`, `A3.Ex151` obtain positive signed mu, positive M,
and the exact normalized bias rho^n*(1-rho^(2(d-n)))/(1-rho^(2d)). The sign
uses 0<rho<1 and n<d; it is required to replace signed mu by absolute mu.
The quotient factor lies between 1-rho^(2(d-n)) and one. This exact ratio
does not require d-n>=sqrt(kappa).

`A3.SS3.p10`, `A3.EGx18`, `A3.EGx19`, `A3.Ex157` derive log(1/rho) as an
integral, lower bound it by 2/sqrt(kappa), and upper bound it by
8/(3sqrt(kappa))<3/sqrt(kappa), using kappa>=2. Exponentiation yields
exp(-3n/sqrt(kappa))<=rho^n<=exp(-2n/sqrt(kappa)). The upper rho^n bound
holds before the extra d-n condition. `A3.SS3.p11`, `A3.Ex158`, `A3.Ex159`
use that condition to force rho^(2(d-n))<=exp(-4), then combine the quotient
and power estimates for the displayed two-sided bias result. The extra
condition's discharge belongs at the eventual lower-bound application.

C.3 contains a single route to Lemma 4.5: C.7 feeds C.8, C.8 supplies means,
the Gaussian fourth-moment calculation supplies variance bounds, and the
ratio plus logarithmic/integral estimates supplies the conditional bias
estimate. Their final conjunction is appropriate. No alternate proof, external
citation, or implementation-derived helper topology appears in this slice.

## Citation, source gaps, and future challenge criteria

[22] is the OpenAI (2026) preprint *Subpolynomial query complexity for
well-conditioned log-concave sampling*, release identifier
`OAI:Subpolynomial-query-complexity-for-well-conditioned-log-concave-sampling-September-26-2026`.
The raw bibliography URL is a GitHub `main` PDF URL; the citation alone does
not pin that external article's bytes. Its Section 9.2 and Lemma 9.2 are
explicit external inputs at their consumer paragraphs. Bibliography backlinks
are navigation, not implication edges. No upstream proof content was opened
or asserted as checked.

For later comparison I will challenge coverage by following source regions,
not unit totals: the full C.7 convergence proof; both C.8 aliasing tails and
their disjointness; Gaussian variance bookkeeping; sign/denominator positivity;
the log integral and its parameter restriction; conditional bias premise;
algorithm representation's output vector and joint-law preservation; the
uniform random-vector event; asymptotic uniform d0 selection and all numerical
thresholds; centered-variable covariance handling; measurable input-dependent
event/TV averaging; and the distinction between proof limitations and an
impossibility theorem. Unopened C.1/C.2/C.4 and the actual [22] text must remain
explicit. Source omissions or unverified bridges must be visible as gaps or
open boundaries, not theorem-shaped public hypotheses. The next permitted
phase is minimal sealed-signature/definition review in a new file; extractor
graph/coverage will be considered only after that judgment is separately
frozen.
