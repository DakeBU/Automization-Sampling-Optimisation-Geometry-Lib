"""Independent v6 repair replay and newline/raw-byte/presentation challenges."""
from review import *
import ast

old=(D/'proposal-v5.exact.py').read_bytes();new=(D/'proposal.py').read_bytes()
before=b'base.esc(line)}</span>'
after=b'base.esc(line.removesuffix(chr(13)))}</span>'
assert old.count(before)==1 and old.replace(before,after)==new
js('exact-delta-check.json',{'v5_sha256':sha(old),'v6_sha256':sha(new),
 'only_advertised_sourceHTML_line_text_expression_changed':True,
 'LF_anchor_partition_matching_downloads_candidates_copy_panel_path_URL_symlink_logic_byte_identical':True})

# Exact old renderer loaded only as a comparison input, never as a verdict.
spec=importlib.util.spec_from_file_location('exact_v5_comparison',D/'proposal-v5.exact.py')
v5=importlib.util.module_from_spec(spec);spec.loader.exec_module(v5)
v5.ROOT=fixture

def html_text(raw):
 # Explicit static HTML CR preprocessing fixture, not live browser evidence.
 return parse(raw.replace('\r\n','\n').replace('\r','\n'))
def normalized_source(text):
 return text.replace('\r\n','\n').replace('\r','\n')
def expected_pre(text):
 value=normalized_source(text)
 return value+('\n' if value and not value.endswith('\n') else '')
def export_read(renderer,u,out,name):
 renderer.ROOT=fixture;renderer.export_sources(out,[u]);p=out/'data/lesson-sources'/(name+'.html')
 rawhtml=p.read_bytes().decode('utf-8');tree=html_text(rawhtml);pre=tree.descendants('pre');assert len(pre)==1
 return rawhtml,tree,pre[0].text()

# Replay exact frozen original Unicode source and literal; no source approximation.
orig=json.loads((D/'frozen-originals/original-U2028-record.json').read_bytes())
raw=(D/'frozen-originals/UnicodeLineSeparator.lean').read_bytes()
literal='theorem sample : True := by\n  trivial\n'
assert sha(raw)==orig['source_sha256'] and sha(literal.encode())==orig['literal_sha256']
file('OriginalUnicodeCounterexample.lean',raw)
u=fixture_unit([],canonical='OriginalUnicodeCounterexample.lean',line=2)
actions=v6.exact_lean_step_actions(u,{'lean':literal},page);put('replay-original-Unicode/actions.html',actions)
out=D/'replay-original-Unicode/export';rawhtml,tree,pretext=export_read(v6,u,out,'OriginalUnicodeCounterexample.lean')
fragment=urlsplit(parse(actions).descendants('a')[0].attrs['href']).fragment
anchor=[n for n in tree.descendants('span') if n.attrs.get('id')==fragment];assert len(anchor)==1
assert fragment=='L2' and anchor[0].text()=='theorem sample : True := by'
assert pretext==expected_pre(raw.decode())
assert (out/'data/lesson-sources/OriginalUnicodeCounterexample.lean').read_bytes()==raw
js('replay-original-Unicode/result.json',{'source_sha256':sha(raw),'literal_sha256':sha(literal.encode()),
 'same_frozen_original_bytes':True,'returned_fragment':fragment,'anchor_text':anchor[0].text(),
 'raw_download_exact':True,'normalized_presentation_correct':True,'result':'PASS; original prior decision unchanged'})

# Replay exact frozen v5 CRLF and CR-only artifacts; compare the old/new pages.
original_crlf=json.loads((D/'frozen-originals/original-v5-CRLF-record.json').read_bytes())
replays=[]
for ident,path,expected_hash in [
 ('CRLF','CRLFPresentation.original.lean',original_crlf['source_sha256']),
 ('CR-only','cr-only.lean',sha('α\rβ\r'.encode()))]:
 b=(D/'frozen-originals'/path).read_bytes();assert sha(b)==expected_hash
 name='Frozen'+ident+'.lean';file(name,b);u=fixture_unit([name])
 comparisons={}
 for label,renderer in [('v5',v5),('v6',v6)]:
  out=D/'replay-v5-regressions'/ident/label;h,t,text=export_read(renderer,u,out,name)
  comparisons[label]={'sourceHTML_sha256':sha(h.encode()),'normalized_code_text':text,
    'raw_download_exact':(out/'data/lesson-sources'/name).read_bytes()==b}
 assert comparisons['v5']['normalized_code_text']!=expected_pre(b.decode())
 assert comparisons['v6']['normalized_code_text']==expected_pre(b.decode())
 replays.append({'case':ident,'same_frozen_source_sha256':sha(b),'comparisons':comparisons,
   'normalized_expected':expected_pre(b.decode()),'prior_v5_regression_fixed':True,
   'presentation_not_raw_byte_equality':'CR presentation is normalized; raw downloads retain original bytes.'})
js('replay-v5-regressions/results.json',replays)

# Reuse only fixture literals from the frozen earlier test script. Tests below
# assert the current contracts independently, not the old expected verdict.
tree=ast.parse((D/'original-v5-newline-review.py').read_text())
assignments=[n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='cases' for t in n.targets)]
assert len(assignments)==1
cases=ast.literal_eval(assignments[0].value)
assert len(cases)==20
cases.extend([
 {'id':'two-CR-before-every-LF','whole':'-- prefix\r\r\nα\r\r\nβ\r\r\n','literal':'α\r\r\nβ\r\r\n','line':2,'end_line':3,'spans':3},
 {'id':'three-CR-before-every-LF','whole':'-- prefix\r\r\r\nα\r\r\r\nβ\r\r\r\n','literal':'α\r\r\r\nβ\r\r\r\n','line':2,'end_line':3,'spans':3},
 {'id':'two-terminal-CR','whole':'α\nβ\r\r','literal':'α\nβ\r\r','line':1,'end_line':2,'spans':2},
 {'id':'three-terminal-CR','whole':'α\nβ\r\r\r','literal':'α\nβ\r\r\r','line':1,'end_line':2,'spans':2},
 {'id':'embedded-CR-words','whole':'-- prefix\rinside\nα\rmiddle\nβ\rend\n','literal':'α\rmiddle\nβ\rend\n','line':2,'end_line':3,'spans':3},
 {'id':'CRLF-and-final-CR','whole':'α\r\nβ\r','literal':'α\r\nβ\r','line':1,'end_line':2,'spans':2},
 {'id':'one-CR-only','whole':'\r','literal':'\r','line':None,'end_line':None,'spans':1},
 {'id':'two-CR-only','whole':'\r\r','literal':'\r\r','line':None,'end_line':None,'spans':1},
 {'id':'blank-CRLF','whole':'\r\n','literal':'\r\n','line':1,'end_line':1,'spans':1},
 {'id':'blank-CRCRLF','whole':'\r\r\n','literal':'\r\r\n','line':1,'end_line':1,'spans':1},
 {'id':'CR-after-LF','whole':'α\n\r','literal':'α\n\r','line':1,'end_line':2,'spans':2},
 {'id':'embedded-CR-before-Unicode-separator','whole':'-- prefix\r\u2028suffix\nα\nβ\n','literal':'α\nβ\n','line':2,'end_line':3,'spans':3},
 {'id':'CR-before-final-Unicode-separator','whole':'α\r\u2028','literal':'α\r\u2028','line':None,'end_line':None,'spans':1},
 {'id':'Unicode-separator-before-terminal-CR','whole':'α\u2028\r','literal':'α\u2028\r','line':None,'end_line':None,'spans':1},
])
matrix=[]
for case in cases:
 name='newline/'+case['id']+'.lean';b=case['whole'].encode();lit=case['literal'].encode();file(name,b);u=fixture_unit([name])
 out=D/'newline-matrix'/case['id'];h,t,text=export_read(v6,u,out,name)
 spans=[n for n in t.descendants('span') if re.fullmatch('L[0-9]+',n.attrs.get('id',''))]
 assert len(spans)==case['spans'] and [n.attrs['id'] for n in spans]==['L'+str(i) for i in range(1,len(spans)+1)]
 assert b.count(b'\n')+(1 if b and not b.endswith(b'\n') else 0)==case['spans']
 assert text==expected_pre(case['whole']),(case['id'],repr(text),repr(expected_pre(case['whole'])))
 assert (out/'data/lesson-sources'/name).read_bytes()==b
 actions=v6.exact_lean_step_actions(u,{'lean':case['literal']},page);put('newline-matrix/'+case['id']+'/actions.html',actions)
 links=parse(actions).descendants('a') if actions else []
 if case['line'] is None:assert not links
 else:
  assert len(links)==2 and urlsplit(links[0].attrs['href']).fragment=='L'+str(case['line'])
  offset=b.index(lit);end=offset+len(lit)
  assert b.count(b'\n',0,offset)+1==case['line'] and b.count(b'\n',0,end-1)+1==case['end_line']
  # Compare displayed first line plus its emitted break with the normalized
  # original first line including its actual source boundary. This handles
  # multiple CRs without claiming byte equality for normalized presentation.
  first_source=case['literal'].partition('\n')[0]
  assert spans[case['line']-1].text()+'\n'==normalized_source(first_source+'\n')
 old_out=D/'newline-matrix-v5'/case['id'];old_html,old_tree,old_text=export_read(v5,u,old_out,name)
 # Exact authorized presentation scope: only the redundant final CR before
 # each generated span end can differ; all other page bytes must match.
 assert h==old_html.replace('\r</span>\n','</span>\n')
 matrix.append({'case':case['id'],'source_sha256':sha(b),'literal_sha256':sha(lit),
  'LF_anchor_count':len(spans),'context_line':case['line'],'end_line_terminal_LF_preceding':case['end_line'],
  'normalized_presentation_correct':True,'raw_download_exact':True,
  'presentation_equals_raw_source_bytes':text.encode()==b,
  'v5_v6_page_difference_only_authorized_redundant_CR_removal':True,'result':'PASS'})
js('newline-matrix-results.json',matrix)

# Presentation-equivalent source text must never be confused with raw equality.
control('CRLF and LF display equivalence does not merge raw CRLF match',
 ['raw-crlf.lean','raw-lf.lean'],{'raw-crlf.lean':'é\r\nrest\r\n','raw-lf.lean':'é\nrest\n'},'é\r\nrest\r\n',1,wanted_path='raw-crlf.lean')
control('CRLF and LF display equivalence does not merge raw LF match',
 ['raw-crlf.lean','raw-lf.lean'],{},'é\nrest\n',1,wanted_path='raw-lf.lean')
control('Unicode NFC matching remains raw byte exact',
 ['raw-nfc.lean','raw-nfd.lean'],{'raw-nfc.lean':'é\nrest\n','raw-nfd.lean':'é\nrest\n'},'é\nrest\n',1,wanted_path='raw-nfc.lean')
control('Unicode NFD matching remains raw byte exact',
 ['raw-nfc.lean','raw-nfd.lean'],{},'é\nrest\n',1,wanted_path='raw-nfd.lean')

# Strict UTF8 invalid source must fail export before a completed target exists.
invalid=b'-- \xff\n'+literal.encode();file('InvalidUTF8.lean',invalid);u=fixture_unit(['InvalidUTF8.lean']);out=D/'invalid-UTF8-export'
try:v6.export_sources(out,[u])
except UnicodeDecodeError as exc:
 js('invalid-UTF8-control.json',{'source_sha256':sha(invalid),'expected_exception':type(exc).__name__,'message':str(exc),
   'complete_sourceHTML_absent':not (out/'data/lesson-sources/InvalidUTF8.lean.html').exists(),
   'complete_raw_download_absent':not (out/'data/lesson-sources/InvalidUTF8.lean').exists(),'result':'PASS; strict UTF8 fails closed'})
else:raise AssertionError('Invalid UTF8 exported without error')

# Real C5 has no CR; v5->v6 must leave every current lesson and sourceHTML byte
# unchanged under the identical bounded fixture, while keeping exact raw files.
base._SOURCE_BY_NAME=known;inline_lean.declarations.cache_clear();v5.ROOT=D/'inputs';v6.ROOT=D/'inputs'
assert v5.render_unit(unit,page)==v6.render_unit(unit,page)
out5=D/'real-C5-v5-export';out6=D/'real-C5-v6-export';v5.export_sources(out5,[unit]);v6.export_sources(out6,[unit])
real=[]
for rel in [P,T]:
 assert b'\r' not in (D/'inputs'/rel).read_bytes()
 a=out5/'data/lesson-sources'/rel;b=out6/'data/lesson-sources'/rel
 assert a.read_bytes()==b.read_bytes()==(D/'inputs'/rel).read_bytes()
 ah=a.with_suffix(a.suffix+'.html');bh=b.with_suffix(b.suffix+'.html');assert ah.read_bytes()==bh.read_bytes()
 real.append({'file':rel,'raw_bytes_identical':True,'sourceHTML_v5_v6_byte_identical':True,'sourceHTML_sha256':sha(bh.read_bytes())})
js('real-C5-v5-v6-no-hidden-change.json',{'lesson_render_byte_identical':True,'source_exports':real})
js('scope-and-progress.json',{'candidate':C,'exact_delta':'Only advertised trailing-CR sourceHTML presentation expression',
 'real_C5_six_routes_exact_folds_downloads_copy_structure':'PASS',
 'original_exact_Unicode_replay':'PASS','frozen_v5_CRLF_and_CR_only_replays':'PASS',
 'newline_cases_passed':len(matrix),'matching_controls_passed':len(controls),'path_URL_symlink_controls_passed':len(security),
 'canonical_export_controls_passed':len(compat),'strict_UTF8_invalid_source_control':'PASS',
 'no_hidden_C5_change':'Current lesson and P/T sourceHTML byte-identical to v5; raw files identical to candidate',
 'byte_equality_scope':'Raw UTF8 matching and downloads exact; sourceHTML presentation intentionally normalizes CR boundaries and adds a display LF for a nonempty unterminated final line. No raw-byte equality claimed for that presentation.',
 'decision':'PASS within the bounded prospective static review; no defect found in tested scope; all earlier HOLDs unchanged',
 'unavailable_acceptance':'No JS runtime/clipboard/live browser/MathJax/desktop/mobile/global delivery or sourceV/native build acceptance',
 'fixture_limits':'Exact functions; identity source_lineage global shell, unpublished Git, passed=false gate; HTML CR preprocessing simulated statically, not observed in a browser.',
 'preservation':'No prior freeze or tracked/shared file changed; no reviewer repair implementation.'})
print(json.dumps({'real_C5_routes':['P34','P54','P125','P156','T59','T13'],'full_T_bytes':7494,
 'frozen_Unicode_CRLF_CR_only_replays':'PASS','newline_cases_passed':len(matrix),'matching_controls_passed':len(controls),
 'path_URL_symlink_controls_passed':len(security),'canonical_export_controls_passed':len(compat),
 'strict_UTF8_negative_control':'PASS','no_hidden_current_C5_change':True,
 'decision':'PASS bounded prospective static scope; earlier HOLDs unchanged; no runtime/browser/global acceptance'},indent=2))
