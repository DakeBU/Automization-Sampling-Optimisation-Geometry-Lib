from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, stat

BASE=Path(__file__).resolve().parent
PHASE1=BASE.parent/'phase1'
REPO=Path('/Users/zhouhuanjian/ASTIS-GC')
src=REPO/'research-wiki/paper-contributions/GaussianComplexity/zero-query-separation-semantic-evidence/selective-fresh-source-phase2-input.json'
b=src.read_bytes()
assert len(b)==9649 and hashlib.sha256(b).hexdigest()=='2f2e5f127775bea0be16b4aad327c377b744d6410c5b36344aa7f50e5ee1511a'
(BASE/'input.raw.json').write_bytes(b)
data=json.loads(b)
for label,value,expected in [
 ('source_attribution_text',data['source']['original_text'],data['source']['text_sha256']),
 ('public_statement',data['lean']['statement'],data['lean']['statement_sha256']),
 ('blind_reconstruction',data['blind_reconstruction']['text'],data['blind_reconstruction']['text_sha256']),
 ('private_signature',data['private_consumer_literal_signature']['signature'],data['private_consumer_literal_signature']['signature_sha256'])
]:
    h=hashlib.sha256(value.encode()).hexdigest()
    assert h==expected,(label,h,expected)

# Phase1 validation reads only this reviewer's frozen own files; no external inventory.
assert hashlib.sha256((PHASE1/'receipt.json').read_bytes()).hexdigest()=='ef13349dd0f6b894a6ba171184c65f19edb89b1e42e394ef7d0bd6d550320653'
m1=json.loads((PHASE1/'manifest.json').read_text())
for row in m1['payload_files']:
    p=PHASE1/row['path'];assert hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256'];assert stat.S_IMODE(p.stat().st_mode)==0o444
assert hashlib.sha256((PHASE1/'manifest.json').read_bytes()).hexdigest()=='d8e1def94411192058922b64b4b7cb61e1c26ceb3ade1816b69fce2ecd9788ce'
payload=[]
for p in sorted(BASE.rglob('*')):
    if p.is_file() and p.name not in {'manifest.json','receipt.json'}:
        q=p.read_bytes();payload.append({'path':str(p.relative_to(BASE)),'bytes':len(q),'sha256':hashlib.sha256(q).hexdigest(),'frozen_mode':'0444'})
manifest={'schema_version':1,'phase':'PHASE2_SELECTIVE_COMPARISON','actor':'/root/zeroquery_fresh_source_2f8a71','phase1_receipt_sha256':'ef13349dd0f6b894a6ba171184c65f19edb89b1e42e394ef7d0bd6d550320653','input_raw_sha256':hashlib.sha256(b).hexdigest(),'payload_files':payload,'self_reference_policy':'Manifest excludes itself and receipt; receipt binds manifest; both freeze 0444'}
mp=BASE/'manifest.json';mp.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
receipt={'schema_version':1,'phase':'PHASE2_FROZEN_PAUSE','actor':'/root/zeroquery_fresh_source_2f8a71','frozen_at_utc':datetime.now(timezone.utc).isoformat(),'manifest_sha256':hashlib.sha256(mp.read_bytes()).hexdigest(),'comparison_sha256':hashlib.sha256((BASE/'comparison.md').read_bytes()).hexdigest(),'exposure_sha256':hashlib.sha256((BASE/'exposure.json').read_bytes()).hexdigest(),'input_raw_sha256':hashlib.sha256(b).hexdigest(),'embedded_text_hashes_verified':True,'phase1_receipt_and_manifest_and_all_payload_hashes_modes_verified_unchanged':True,'payload_files':len(payload),'files_mode':'0444','directory_mode':'0555','provisional_type_level_classification':'equivalent-after-elaboration for the signed-event auxiliary only; final code/exposition review pending','next':'Pause for separately authorized immutable full candidate/code/reader inputs','authority':'No sourceV/application/native/delivery/VERIFIED/STAB/global/Goal verdict'}
rp=BASE/'receipt.json';rp.write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
for p in BASE.rglob('*'):
    if p.is_file():p.chmod(0o444)
BASE.chmod(0o555)
for row in payload:
    p=BASE/row['path'];assert hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256'];assert stat.S_IMODE(p.stat().st_mode)==0o444
for p in (mp,rp):assert stat.S_IMODE(p.stat().st_mode)==0o444
print(json.dumps({'receipt':str(rp),'receipt_sha256':hashlib.sha256(rp.read_bytes()).hexdigest(),'manifest_sha256':receipt['manifest_sha256'],'comparison_sha256':receipt['comparison_sha256'],'payload_files':len(payload),'phase1_unchanged_and_phase2_hashes_modes_verified':True},indent=2))
