# Phase 1 frozen source cognition — independent topology/binder/definition reviewer

Actor: `/root/detector_topology` (directory identity `d_tc_91b6e4`). Role: source/topology/binder/definition reviewer, not prover. This record is written before seeing the sealed signature, another actor's graph, implementation Lean, or root proof plans/exposures. It conveys source-only mathematical expectations, not a statement verdict or any formal completion credit. Later corrections must be successor records, never edits to this freeze.

## Source and scope actually read

The only mathematical source is the pinned local HTML `2610.20492v1.html`, title *On Complexity of Gaussian Sampling*, 951991 bytes, SHA256 `6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915`.

I read the full extracted substantive paper text: abstract/introduction, §2, §3, §4, conclusion/disclosures/bibliography, Appendices A/B/C. Mathematical reconstruction is scoped to §4.1 Eq. (11) and the complete §4.3 proof of Theorem 4.1, with full §2 conventions, §4.2 and Appendix C as supporting context. §3 and Appendix B are context only, not author dependencies of this proof. The bibliography identifies [22], but its external content was not accessed. Reading its name here supplies citation provenance only.

The frozen snippets contain exact original HTML for §2, §4 and Appendix C, plus an ID-indexed text rendition that substitutes each MathML element's own `alttext`. The extraction checks all 45 / 221 / 528 math elements in these sections are present, in source order; `source-blocks.json` also preserves block IDs and math IDs. `text-full.txt` records the complete extracted paper text. These are renditions of the single allowed raw input, not independently sourced mathematical evidence.

## Objects, carriers and quantifier scope

1. §2 uses Euclidean `R^d`, the Euclidean norm and real symmetric precision matrices. `A_{d,κ}={A=A^T: I_d≼A≼κI_d}` for integer `d≥1`, real `κ≥1`. The target is exactly `π_A=N(0,A^{-1})` and `f_A(x)=x^T A x/2`. The exact first-order reply is `(x^T A x/2,Ax)`; its value component adds no information beyond `Ax`.
2. Algorithms may be randomized, adaptive and have arbitrary Borel outputs based on their seed and previous replies. Their private seed is independent of the input. A budget is a deterministic cap for every input and every seed, not an expected budget and not a restriction of the output to the query/reply span. These are source model assumptions, not conclusions of the Krylov argument.
3. `ρ_A^Alg` is the output law at a fixed input, averaging over the private seed. Accuracy is `sup_{A∈A_{d,κ}} TV(ρ_A^Alg,π_A)≤ε`, before the proof introduces its random hard input. `TV(P,Q)=sup_{B measurable}|P(B)-Q(B)|`; its convention has the `1/2` density factor.
4. Theorem 4.1 has order `∀δ∈(0,1), ∃d0(δ), ∀integer d≥d0(δ), ∀κ∈[2,d^(1-δ)], ∀ε∈(0,1/10], Q_G(d,κ,ε)≥(δ/256)√κ log d`. The dimension threshold depends only on δ, not separately on κ, q or ε. The bound does not improve as ε decreases. The source also says the spectrum can be public.
5. Eq. (11) is a literal definition for integer `d≥2`, real `κ≥2`, indices `i=1,…,d`: `θ_i=(i-1/2)π/d`, `λ_i=(κ+1)/2+((κ-1)/2)cos θ_i`, `Λ=diag(λ_i)`. The indices matter: a zero-based encoding needs `(i+1/2)π/d`. These are interior midpoint nodes, not endpoint Chebyshev nodes. `θ_i∈(0,π)` and `1<λ_i<κ`; the closed matrix bounds follow. Eigenvalues are distinct because cosine is strictly decreasing on `(0,π)` and the affine slope is positive.
6. Draw `O` from Haar probability on the full orthogonal group `O(d)`, independently of the seed, and set `A=OΛO^T`. The spectrum is deterministic and known. The hidden object is the eigenbasis; the Gaussian normalizing constant `Z_A=(2π)^(d/2)(detΛ)^(-1/2)` is deterministic. It is the density partition function, not an energy normalization, a probability of an event, or `M=trΛ^{-1}`.
7. In the contradiction proof, `q` is a nonnegative integer query budget satisfying `q≤(δ/256)√κ log d`. The source includes `q=0`. Define `n=2q+1` (positive odd integer), `r=q+1` and `D_n=diag(cos(nθ_i))`. The eventual `n<d` and `τ≤1/2` are proved by increasing `d0(δ)`, not new theorem hypotheses. Lemma 4.5 allows general integer `1≤n<d`; the final proof specializes to odd `n`.
8. Lemma 4.4 has an absolute `C>0` fixed sufficiently large once, and then the displayed `τ_{d,q}=C[(q+1)√(log d/d)+(q+1)(q+1+log d)log d/d]`. Its constant is independent of κ, d, q and δ. A parameterization by C must preserve this existence/choice scope; an arbitrary C>0 does not give the concentration theorem. In the valid regime d≥2, τ is positive. Its precise bound is a proved ingredient, not an input supplied by an algorithm.

## Literal statistic, event, and geometry

The complete source definition at `S4.EGx2` is

`S_A(x)=(-1)^n x^T T_n((2A-(κ+1)I_d)/(κ-1))x - 2τ ||x||²`,

`E_A={x : S_A(x)>0}`,

where `T_n` is the first-kind Chebyshev polynomial. This is a homogeneous quadratic polynomial in x and is defined on all `R^d`; κ−1 is nonzero in the source domain. For fixed A it is continuous, so E_A is Borel (indeed open). It is also an event depending only on A, not an arbitrary choice of its eigenbasis. Its joint dependence on A and x is polynomial/continuous for fixed d,κ,n,τ, which supports the later averaging.

The source then uses the spectral polynomial bridge

`(2A-(κ+1)I)/(κ-1)=O diag(cosθ_i) O^T`,

`T_n((2A-(κ+1)I)/(κ-1))=O D_n O^T`

from polynomial conjugation and `T_n(cosθ)=cos(nθ)`. This bridge is substantive: it identifies the event used by TV with the diagonal cosine statistic controlled by Lemmas 4.4/4.5. It must not disappear simply because a definition is made directly in eigenbasis coordinates.

For x≠0 only, the weights are `w_i(x)=|<x,Oe_i>|²/||x||²`. They are nonnegative and sum to one by orthonormality/Parseval. They represent fractions of the vector's squared norm in the eigendirections. Thus

`x∈E_A ↔ (-1)^n Σ_i w_i(x)cos(nθ_i)>2τ` for x≠0.

The test asks for magnitude above 2τ together with the sign of the target mean. The sign factor is essential: for the specialized odd n the target cosine mean is negative. Replacing the signed test by just its absolute value changes E_A. The normalized quantity is a random ratio of quadratic forms, while β below is a ratio of means; the source does not identify `E[Q/N]` with `E[Q]/E[N]`.

At x=0, `S_A(0)=0` and `0∉E_A` because the inequality is strict. The source gives no weights at zero. A public weight definition with an off-source fallback needs an explicit domain restriction or separately audited extension; the source's globally defined event itself needs no division by `||x||²`. Changing `>` to `≥` would include zero and breaks the immediate algorithm-bound argument for a possible atom at zero. No theorem about algorithms permits discarding such an atom. The target has no atom at zero, but that does not repair the algorithm side.

## The actual probability spaces and their transfers

There are three different experiments, and the proof transfers only the quantities it justifies.

* **Original algorithm experiment:** O Haar and private seed R independent, with adaptive Borel queries/replies and output `X=X(O,R)`, input `A(O)=OΛO^T`. At fixed A the conditional/output kernel is `ρ_A^Alg`. The unconditional test probability is `P(S_{A(O)}(X)>0)=E_A[ρ_A^Alg(E_A)]` for the pushforward hard-input law. E_A varies with A; the equivalent event on `(A,x)` is the correct object for averaging. This is not TV between unconditional x-mixtures against a single fixed x-event.
* **Extended algorithm experiment:** Appendix C.1 adds i.i.d. `Z_1,…,Z_{q+1}~N(0,I_d)` independent of `(R,O)` without changing their original joint law or the transcript/output. Derived vectors `g_i` are mutually independent standard Gaussians and yield `O^T X∈K_q(g_1,…,g_{q+1})` almost surely. They need not be independent of O or X. Source polynomial coefficients may depend on the full enlarged experiment. The uniform event from Lemma 4.4 applies to all vectors in K_q simultaneously, so no independence between that event and the selected output is needed. Law preservation transfers the final event probability back to the original `(O,X)` experiment.
* **Fixed-input target experiment:** for every fixed hard-family A, choose any associated O and draw `Y~π_A`. Then `U=O^T Y~N(0,Λ^{-1})`; orthogonality gives `||Y||²=||U||²` and the polynomial bridge gives `Y^T O D_n O^T Y=U^T D_n U`. Lemma 4.5 therefore yields the same means/variances for every fixed A. This is a per-input ≥0.9 result, unlike the algorithm's averaged ≤0.01 result. It may then be averaged over the hard-input law.

Haar here is the full orthogonal Haar law, not determinant-conditioned Haar from §3. The source's two-prior determinant indistinguishability and Hellinger amplification are not inputs to §4.3. No proof step says the algorithm's conditional output law at every A satisfies the ≤0.01 event bound.

## Source author's proof route, with consumer use sites

These are source-only expectations for later graph review, not approval of anyone else's graph.

1. **Construction/admissibility:** Eq. (11), O Haar, A=OΛO^T; Lemma 4.6/C.4 establish precision bounds. Consumer: first paragraph of §4.3, permitting use of the assumed uniform accuracy on the hard family. C.4 also establishes smooth quadratic/unique minimizer/known partition function, supporting source model and public-spectrum remarks; not all these facts are separate inputs to the numerical contradiction.
2. **Statistic and event:** §4.3 `S4.SS3.p3` / `S4.EGx2`; matrix-polynomial cosine identity and geometric explanation at `S4.SS3.p4.1`. These definitions/bridges are substantive proof regions, not just decorative exposition or a title for an unnamed final event.
3. **Parameter regime:** the q and κ bounds imply `q+1≤d^((1-δ)/2)log d` for sufficiently large d and `n=o(d)` uniformly in the stated range. Substitution gives `τ≲d^(-δ/2)(log d)^(3/2)+d^(-δ)(log d)^3≲d^(-δ/2)(log d)^3→0`. Consumer: obtain `n<d`, `τ≤1/2` needed for Lemmas 4.3/4.4. Constants here can be absolute; the sufficiently-large threshold depends only on δ.
4. **Algorithm event:** Lemma 4.3 law-preserving Krylov representation AND Lemma 4.4 simultaneous cosine bound, followed by orthogonal norm transport and polynomial identity, imply `|X^T O D_n O^T X|≤2τ||X||²` with probability ≥0.99. Hence signed statistic ≤0 and `E_A[ρ_A^Alg(E_A)]≤0.01`. The almost-sure representation failure and the uniform-event failure must be combined on the same extension. The auxiliary Gaussian construction itself is not a public hypothesis of the final theorem.
5. **Target means and bias:** Lemma 4.5 gives `M=trΛ^{-1}>0`, `μ_n=tr(D_nΛ^{-1})`, β=`|μ_n|/M>0` and signed mean `(-1)^n μ_n=βM`. Require `d−n≥√κ`, obtained from the same uniform regime (`n=o(d)`, `√κ≤d^((1-δ)/2)=o(d)`). Consumer: bias lower bound in `S4.Ex23`.
6. **Separation budgets:** `β≥(1−e^-4)e^(-3n/√κ)≥b d^(-δ/4)`, `b=(1−e^-4)e^-3>0`, using `3n/√κ≤3+(3δ/128)logd`. For large d, `d≥√κ` and `ρ_κ≤e^(-1/√κ)` imply `ρ_κ^(2d)≤e^-2<1/3`, hence exact M formula gives `M≥d/(2√κ)≥d^((1+δ)/2)/2`. Combine to get `τ/β≤(C'/b)d^(-δ/4)(logd)^3→0`, `Mβ²≥(b²/2)√d→∞`. Choose a single d0(δ) so all prior conditions plus `τ≤β/4`, `Mβ²≥320` hold simultaneously and uniformly. These estimates are author steps, not extra source premises.
7. **Target test probability:** for fixed A, `Z=S_A(Y)`, mean `(β−2τ)M≥βM/2`. Both component variances ≤2M; centered L² triangle inequality gives `VarZ≤(√(2M)+2τ√(2M))²≤8M` using `τ≤1/2`. Chebyshev for the complement `{Z≤0}` then yields `π_A(E_A)≥1−32/(Mβ²)≥0.9`. Covariance need not vanish; independence of the two quadratic forms is not asserted or needed. Finite fourth moments and integrability are supplied by Gaussian moments, not new public binders.
8. **TV contradiction and budget conclusion:** at each fixed A, the same Borel E_A obeys `π_A(E_A)−ρ_A^Alg(E_A)≤TV≤ε`. Average this inequality and combine steps 4/7: `0.89≤E_A[π_A(E_A)−ρ_A^Alg(E_A)]≤ε≤0.1`, contradiction. Thus no accurate algorithm with the supposed small integer q exists; the query-complexity infimum definition supplies the final lower bound. The proof uses one route with multiple necessary branches, not two alternative complete routes.

## Supporting source topology in Appendix C

* C.1: source motivates hidden coordinates, handles adaptivity by deferred Haar revelation. Fact C.1 gives conditional uniform direction and residual Haar law in complements. Definition C.2 packages a Haar state `(H,E)` with measurability of E and OP_E and conditional Haar complement. Fact C.3 has three updates (auxiliary randomness, image, preimage), explicitly treating zero residual components; Fact C.4 Gaussianizes a uniform complementary direction, requiring `dimE<d` and Gaussian norm positive a.s. Lemma 4.3 proof pads queries with zero, preserves original law on extension, maintains `dimE_i≤2i<d`, constructs g_i conditionally standard Gaussian, derives mutual independence from constant conditional laws, then inducts spans to include the final output. The extra output direction is essential; output is not assumed in the earlier query span.
* C.2: set r=q+1, cosine vectors `t_i=(1,√2cosθ_i,…,√2cos(qθ_i))`, independent Gaussian rows γ_i, and B with rows `d^-1/2(γ_i⊗t_i)^T`. Fact C.5 proves `rangeB=K_q` by invertible triangular polynomial change of basis, `Σt_it_i^T=dI_r`, weighted sum zero, and means `E B^TB=I_(r²)`, `E B^TD_nB=0`. The cosine sum telescoping and product-to-sum are real author steps: `n=2q+1` keeps every weighted product frequency between 1 and `4q+1<2d`; no zero or alias frequency survives.
* Fact C.6: truncation at `L=2r+3log(1000d)`; Gaussian exponential moment and Markov give truncation event ≥0.999 and tail bias `(L+3)/(1000rd)`. Radial symmetry gives common scalar expectation `aI_r`, so the weighted truncated expectation is exactly zero. Centered independent self-adjoint matrices have bounded norms `R_*=2r(L+1)/d` and variance parameter `v_*=2r(r+2)/d` from Gaussian fourth moments. Two-sided bounded matrix Bernstein is used as a standard theorem; the paper gives no external citation at this use. `z=log(1000r²)` and `Δ=√(2v_*z)+2R_*z/3` make each failure ≤0.002. Union bound with truncation gives ≥0.995. Absolute comparisons bound `Δ+(1−a)` by τ, fixing C. These are dependencies if the graph expands this lemma; they are not independent assumptions.
* Lemma 4.4 proof: same event controls unweighted and weighted Grams; for every c, norm ≥(1−τ)||c||² and numerator ≤τ||c||², so for every u in K_q the ratio-free bound is `|u^TD_nu|≤τ/(1−τ)||u||²≤2τ||u||²`. It applies also to u=0. The source deliberately weakens 0.995 to 0.99.
* C.3: Fact C.7 cosine expansion of inverse spectrum follows from geometric series, `0<ρ_κ<1`, algebra and absolute/uniform convergence. Fact C.8 finite-grid alias sums (`k=2ad` gives `d(-1)^a`, otherwise 0) plus product-to-sum evaluate M/μ exactly, including finite-d correction terms `ρ^(2d)` and `ρ^(2d−n)`. Lemma 4.5 variance uses coordinate independence and fourth moments `VarU_i²=2/λ_i²`, `λ_i≥1`. Sign of μ and positivity of M come from `n<d` and `0<ρ<1`. The ratio formula is `β=ρ^n(1−ρ^(2(d−n)))/(1−ρ^(2d))`. The integral identity for `log(1/ρ)` bounds it between `2/√κ` and `3/√κ`; `d−n≥√κ` supplies the `(1−e^-4)` factor. The exact finite-grid denominators cannot be silently replaced by an infinite-grid asymptotic identity.
* C.4: interior cosine nodes give strict scalar eigenvalue bounds; orthogonal conjugation gives admissibility. Quadratic Hessian A gives source regularity; determinant conjugation and Gaussian integration give the public partition function. The first-order/matrix-vector equivalence itself is stated in §2.

## Expected binder and definition audit before viewing any interface

SOURCE/STANDING/TYPING candidates are the dimension/carrier conventions, κ/δ/ε ranges, algorithm model and its query cap/accuracy assumption where the intended declaration is the contradiction lemma, and literal Eq. (11) parameters. Final Theorem 4.1 is a complexity lower bound and must not acquire as additional premises the truth of Lemmas 4.3–4.6, a favorable event, a constructed Gaussian coupling, moment identities/bounds, `τ≤β/4`, `Mβ²≥320`, concentration validity, or generic continuity/integrability/orthogonal transport theorems. Those are proof ingredients to establish internally or link by actual dependencies. Which assumptions belong to an intermediate source lemma versus the final anchor must be checked against its exact claimed source boundary.

Literal definitions to audit include midpoint angles/eigenvalues, hard input, Gaussian precision/covariance, D_n, τ with fixed sufficient constant, matrix Chebyshev polynomial statistic, strict positive event, M/μ/β, and optional nonzero-vector weights. They must retain normalization factors, matrix evaluation conventions, index shift, signs, full carriers and zero behavior. A characterized/coupling object must preserve the specified joint law and independence actually needed; merely choosing some witnesses without those semantics is insufficient. The Haar-state definitions involve conditional laws/representatives; existence of a representative is not a canonical everywhere equality. The source no-zero-residual branch is explicit, so a proof may not divide by the residual norm unconditionally.

Potential graph-review traps to test later: missing event/statistic/geometry nodes, using implementation-only providers as author edges, reversed lemma-use edges, false AND of complete alternative routes, conflating mutual g-independence with independence from O, per-input/averaged probability drift, omitted uniform d0 quantifiers, changed strict endpoint at zero, ratio-of-means drift, omitted finite-grid terms, and silently moving derived parameter bounds into public binders. These are audit questions, not a verdict on an unseen artifact.

## Phase boundary

Status: `PHASE1_FROZEN_WAITING_PHASE2`. The sealed statement hash was supplied only as metadata (`011376bdd5d1edb66cedb434f8cd7bec7a5f108cc7c653011a7f10cab89ac701`); its path/content has not been searched or opened. No other actor graph, root proofplan/exposure record, Lean proof/signature, tests, Mathlib source, old review/lesson/publication/audit, ledger/frontier/site state or other `.astis` record was opened. Filename-only incidental exposure is explicitly logged in `phase1-exposure-log.md`. No claim of zero exposure is made.

No sourceV/PROVED/Lean/native/global/wholeGoal credit is given. No normal API, ledger, frontier, shared, site or Git mutation or proof execution was performed. All outputs belong to the assigned neutral directory.
