import Tests.GaussianComplexityFixedSpectrumSourceRowIndependence
import Lean
open MeasureTheory ProbabilityTheory Lean Elab Command
set_option autoImplicit false
def IndependentLiteralProducer : Prop := ∀ {d q : ℕ} (hq : 2 * q + 1 < d),
  let D := EuclideanSpace ℝ (Fin d)
  let E := EuclideanSpace ℝ (Fin (q + 1))
  let Ω := Fin (q + 1) → D
  let μ : Measure Ω := Measure.pi (fun _ : Fin (q + 1) => stdGaussian D)
  let row : Fin d → Ω → E := fun i ω =>
    WithLp.toLp 2 (fun a : Fin (q + 1) => ω a i)
  iIndepFun row μ

def IndependentLiteralConsumer : Prop := ∀ {d q : ℕ} (hq : 2 * q + 1 < d),
  let D := EuclideanSpace ℝ (Fin d)
  let E := EuclideanSpace ℝ (Fin (q + 1))
  let Ω := Fin (q + 1) → D
  let μ : Measure Ω := Measure.pi (fun _ : Fin (q + 1) => stdGaussian D)
  let row : Fin d → Ω → E := fun i ω =>
    WithLp.toLp 2 (fun a : Fin (q + 1) => ω a i)
  let r : ℝ := ((q + 1 : ℕ) : ℝ)
  let L : ℝ := 2 * r + 3 * Real.log (1000 * (d : ℝ))
  let θ : Fin d → ℝ := fun i =>
    (((i.val : ℝ) + 1 - (1 / 2 : ℝ)) * Real.pi) / (d : ℝ)
  let t : Fin d → Fin (q + 1) → ℝ := fun i k =>
    if k.val = 0 then 1 else Real.sqrt 2 * Real.cos ((k.val : ℝ) * θ i)
  let Y : Fin d → Ω →
      ((Fin (q + 1) × Fin (q + 1)) → (Fin (q + 1) × Fin (q + 1)) → ℝ) := fun i ω =>
    if ‖row i ω‖ ^ 2 ≤ L then
      (d : ℝ)⁻¹ • Matrix.kronecker
        (Matrix.vecMulVec (fun a => row i ω a) (fun a => row i ω a))
        (Matrix.vecMulVec (t i) (t i))
    else 0
  (∀ i : Fin d, Measurable (Y i)) ∧ iIndepFun Y μ


run_cmd do
  let env := (← getEnv).setExporting false
  setEnv env
  let producer := `AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumSourceRowIndependence.actual_source_rows_independent
  let roots := env.constants.toList.filter fun (n,_) => n == producer ||
    n.toString.endsWith ".actual_truncated_matrices_measurable_and_independent"
  unless roots.length == 2 do throwError "Wrong actual roots {roots.map Prod.fst}"
  for (n,c) in roots do
    let key := if n == producer then "IndependentLiteralProducer" else "IndependentLiteralConsumer"
    let literal := Name.mkSimple key
    let some expected := env.find? literal | throwError "Missing independent literal"
    let some typ := expected.value? true | throwError "Missing independent literal body"
    unless c.levelParams == [] do throwError "Unexpected universes {n}"
    liftCoreM <| addDecl <| Declaration.thmDecl {
      name := Name.mkSimple (key ++ "AppliedActual")
      levelParams := []
      type := mkConst literal
      value := mkConst n
    }
    logInfo m!"INDEPENDENT_SEAL_KERNEL_APPLICATION_PASS {n}"
    logInfo m!"INDEPENDENT_RAW_EXPR_EQUAL {n}: {c.type == typ}"
#print axioms IndependentLiteralProducerAppliedActual
#print axioms IndependentLiteralConsumerAppliedActual
