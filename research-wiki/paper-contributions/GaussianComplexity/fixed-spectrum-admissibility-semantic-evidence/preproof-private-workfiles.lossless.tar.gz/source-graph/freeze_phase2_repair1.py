from pathlib import Path
from datetime import datetime,timezone
import copy,hashlib,json

ROOT=Path('/Users/zhouhuanjian/ASTIS-GC')
BASE=ROOT/'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-admissibility-semantic-evidence/source-only-review'
P2=BASE/'phase2';OUT=BASE/'phase2-repair1'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
def write(name,value):(OUT/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
assert not (OUT/'freeze.json').exists(),'Already frozen; do not mutate.'
before=read(P2/'source-graph.json');after=read(OUT/'source-graph.json')
assert before['nodes']==after['nodes']
assert before['selected_producer_source_slice']==after['selected_producer_source_slice']
assert before['explicit_pending_downstream_or_context']==after['explicit_pending_downstream_or_context']
assert before['route_semantics']==after['route_semantics']
assert len(before['edges'])==len(after['edges'])
changes=[]
for old,new in zip(before['edges'],after['edges']):
    if old!=new:
        assert old['id']==new['id']=='edge:fs-admiss:determinant'
        old_fields={k:v for k,v in old.items() if k!='parents'}
        new_fields={k:v for k,v in new.items() if k!='parents'}
        assert old_fields==new_fields
        assert new['parents']==old['parents']+['sg:fs-admiss:normalizer-integral']
        changes.append(new['id'])
assert len(changes)==1
assert (OUT/'coverage.json').read_bytes()==(P2/'coverage.json').read_bytes()
mb=read(P2/'matching.json');ma=read(OUT/'matching.json')
for key in ['exact_signature_utf8','exact_signature_sha256','candidate_seal_sha256','seven_slots',
 'definition_meaning_adapters','node_by_node_binding','selected_internal_source_bridge_ids',
 'pending_appended_C4_branches','actual_consumer_boundary']:
    assert mb[key]==ma[key],key
assert ma['source_graph_revision']['after_repair_source_graph_sha256']==sha(OUT/'source-graph.json')
assert hashlib.sha256(ma['exact_signature_utf8'].encode()).hexdigest()=='186231307d4c41acba15a1098c56518120394295cf048f504fed6f8ea50018d5'
pins=read(OUT/'raw-inputs.json')['frozen_predecessor_pins']
assert all(sha(BASE/n)==h for n,h in pins.items())
nodes={n['id'] for n in after['nodes']}
incoming={n:set() for n in nodes}
for e in after['edges']:
    assert all(p in nodes for p in e['parents']) and e['child'] in nodes
    incoming[e['child']].update(e['parents'])
remaining=set(nodes);order=[]
while remaining:
    ready=sorted(n for n in remaining if not incoming[n]&remaining)
    assert ready,'Cycle detected.'
    order.extend(ready);remaining.difference_update(ready)
write('structural-check.json',{
 'status':'structural-check-only-passed','changed_mathematical_edges':changes,
 'new_edge_parent':'sg:fs-admiss:normalizer-integral','acyclic':True,'topological_order':order,
 'node_claims_unchanged':True,'coverage_byte_identical':True,'producer_seal_and_signature_unchanged':True,
 'selected_producer_and_pending_bindings_unchanged':True,'frozen_predecessor_hashes_unchanged':True,
 'boundary':'This check confirms exact preservation and DAG structure, not mathematical proof or independent approval of the repair.'})
helpers={}
for n in ['build_phase2_repair1.py','freeze_phase2_repair1.py']:
    p=ROOT/'.astis/huanjian-fixed-spectrum-admissibility-20261107/source-graph'/n
    helpers[str(p.relative_to(ROOT))]=sha(p)
payload={str(p.relative_to(OUT)):sha(p) for p in sorted(OUT.rglob('*')) if p.is_file() and p.name not in ['rawhashes.json','freeze.json']}
write('rawhashes.json',{'algorithm':'SHA-256','revision_payload_files':payload,'private_helpers':helpers,
 'self_exclusion':'rawhashes.json and freeze.json are excluded; freeze binds rawhashes, and its own digest is sent to root.'})
write('freeze.json',{
 'revision':'phase2-repair1','frozen_at_utc':datetime.now(timezone.utc).isoformat(),
 'phase1_freeze_sha256':sha(BASE/'phase1/freeze.json'),'phase2_freeze_sha256':sha(P2/'freeze.json'),
 'before_graph_sha256':sha(P2/'source-graph.json'),'after_graph_sha256':sha(OUT/'source-graph.json'),
 'before_matching_sha256':sha(P2/'matching.json'),'after_matching_sha256':sha(OUT/'matching.json'),
 'coverage_sha256':sha(OUT/'coverage.json'),'exact_diff_sha256':sha(OUT/'exact-diff.json'),
 'rationale_sha256':sha(OUT/'repair-rationale.json'),'exposure_manifest_sha256':sha(OUT/'exposure-manifest.json'),
 'raw_inputs_sha256':sha(OUT/'raw-inputs.json'),'rawhashes_sha256':sha(OUT/'rawhashes.json'),
 'seal_sha256':ma['candidate_seal_sha256'],'signature_sha256':ma['exact_signature_sha256'],
 'payload_file_count':len(payload),
 'status':'proposed-internal-dependency-repair-pending-distinct-challenger-review; no-proof-or-source-verification',
 'stop_rule':'Send exact hashes to root, then stop for challenger review. No target proof/API work.'})
print(json.dumps({'freeze_sha256':sha(OUT/'freeze.json'),**read(OUT/'freeze.json')},ensure_ascii=False,indent=2))
