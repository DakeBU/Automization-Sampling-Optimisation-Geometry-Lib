import json,os,pathlib
from run import ROOT,run,sha
m=json.loads((ROOT/'input-manifest.json').read_text());env=dict(os.environ);env['LEAN_PATH']=os.pathsep.join(m['lean_path']);env.pop('LEAN_SRC_PATH',None)
out=[]
for i,p in enumerate(m['modules']):
    assert all(n.replace('.','/')+'.lean' in m['modules'][:i] for n in m['imports'][p] if n.startswith(('AutoSamplingTheory.','Tests.')))
    d=ROOT/'native-olean'/pathlib.Path(p).with_suffix('.olean');d.parent.mkdir(parents=True,exist_ok=True)
    r=run('compile-'+str(i),[m['lean_binary']['path'],'-R',str(ROOT/'scratch'),'-o',str(d),str(ROOT/'scratch'/p)],cwd=ROOT/'scratch',env=env)
    assert r.returncode==0,p
    out.append({'source':p,'olean':str(d.relative_to(ROOT)),'sha256':sha(d.read_bytes())})
r=run('exact-author-probe',[m['lean_binary']['path'],'-R',str(ROOT/'scratch'),str(ROOT/'scratch/SourceRowIndependenceKernelProbe.lean')],cwd=ROOT/'scratch',env=env)
assert r.returncode==0
(ROOT/'native-build.json').write_text(json.dumps({'candidate':m['candidate_commit'],'outputs':out,'author_probe_pass':True,'lean_path':m['lean_path']},indent=2)+'\n')
