from pathlib import Path
import os,sys,stat,json,hashlib,subprocess,datetime,traceback
ROOT=Path(__file__).resolve().parent;REPO=ROOT.parents[2]
utc=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
sha=lambda b:hashlib.sha256(b).hexdigest()
enc=lambda x:(json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode()
started=utc();envelope={'payload-manifest.json','freeze-execution.receipt.json','freeze-execution.stdout','freeze-execution.stderr','freeze-envelope-hashes.json'}
assert not any((ROOT/x).exists() for x in envelope)
argv=[sys.executable,str(ROOT/'verify_revision.py')];r=subprocess.run(argv,cwd=REPO,capture_output=True)
(ROOT/'freeze-verification.stdout').write_bytes(r.stdout);(ROOT/'freeze-verification.stderr').write_bytes(r.stderr)
assert r.returncode==0,r.stderr.decode(errors='replace')
pres=json.loads((ROOT/'original-phases-preservation-final.json').read_bytes());assert pres['status']=='unchanged'
payload=[]
for path in sorted(ROOT.rglob('*')):
    assert not path.is_symlink()
    if path.is_file() and path.name not in envelope:
        b=path.read_bytes();payload.append({'path':str(path.relative_to(ROOT)),'bytes':len(b),'sha256':sha(b),'frozen_mode':'0444'})
manifest={'schema':'phase3-source-representation-revision-static-manifest-v1','created_utc':utc(),'root':str(ROOT),'version':'31f8c2-source-representation-v2','parent_phase1_manifest_sha256':'973bcc204bdbad7ac177017fa859d81f03122e7fc583233857c9a31b32afa9b8','parent_phase2_manifest_sha256':'cfd5668db1992ab74fc9ca63353f35669c76dd5f66df1c909c92777e96702b93','files':payload,'envelope_files':sorted(envelope),'hash_contract':'This manifest covers every static revision input/output/script/command record. The five envelope files are excluded; freeze-envelope-hashes.json covers the other four and excludes itself. All new-root files0444 and directories0555; no other phase or challenger directory is written or chmodded.'}
(ROOT/'payload-manifest.json').write_bytes(enc(manifest));manifest_sha=sha((ROOT/'payload-manifest.json').read_bytes())
handles={name:(ROOT/name).open('w+b') for name in envelope if name!='payload-manifest.json'}
try:
    files=sorted(x for x in ROOT.rglob('*') if x.is_file());dirs=sorted([ROOT]+[x for x in ROOT.rglob('*') if x.is_dir()],key=lambda x:len(x.parts),reverse=True);actions=[]
    for path in files:
        os.chmod(path,0o444);actions.append({'path':str(path.relative_to(ROOT)),'operation':'chmod','requested_mode':'0444','actual_mode':format(stat.S_IMODE(path.stat().st_mode),'04o')})
    for path in dirs:
        os.chmod(path,0o555);actions.append({'path':'.' if path==ROOT else str(path.relative_to(ROOT)),'operation':'chmod','requested_mode':'0555','actual_mode':format(stat.S_IMODE(path.stat().st_mode),'04o')})
    assert all(x['requested_mode']==x['actual_mode'] for x in actions)
    for item in payload:
        b=(ROOT/item['path']).read_bytes();assert len(b)==item['bytes'] and sha(b)==item['sha256']
    receipt={'schema':'actual-phase3-revision-freeze-execution-v1','status':'FROZEN_SOURCE_REPRESENTATION_REVISION_V2','started_utc':started,'chmod_and_payload_recheck_completed_utc':utc(),'cwd':str(REPO),'invocation':['python3',str(Path(__file__).relative_to(REPO))],'actual_interpreter':sys.executable,'payload_manifest_sha256':manifest_sha,'static_payload_files':len(payload),'all_files_including_envelope':len(files),'directories_including_root':len(dirs),'verification_command':argv,'verification_returncode':r.returncode,'verification_stdout_sha256':sha(r.stdout),'verification_stderr_sha256':sha(r.stderr),'original_phase_preservation_record_sha256':sha((ROOT/'original-phases-preservation-final.json').read_bytes()),'original_phases_untouched':pres['phases'],'actions':actions,'envelope_finalization':'Only the four non-manifest envelope descriptors were preopened before chmod. Receipt/raw stdout/raw stderr/envelope hash index finalized after actual mode/content verification, then all handles closed. No permissions are relaxed. Every chmod path is within the new Phase3 root.','review_scope':'Author R1/R2 source/dependency representation revision; exact-overlay independent recheck pending. No statement/binder/coverage mutation, sourceV, topology approval, Lean/API proof search, implementation or compiled-edge assertion.'}
    rb=enc(receipt);handles['freeze-execution.receipt.json'].write(rb);handles['freeze-execution.receipt.json'].flush()
    log=enc({'status':'FROZEN_SOURCE_REPRESENTATION_REVISION_V2','root':str(ROOT),'payload_manifest_sha256':manifest_sha,'freeze_receipt_sha256':sha(rb),'source_graph_v2_sha256':sha((ROOT/'source-graph.v2.json').read_bytes()),'type_source_overlay_v2_sha256':sha((ROOT/'type-source-overlay.v2.json').read_bytes()),'structured_delta_sha256':sha((ROOT/'structured-delta-and-lineage.json').read_bytes()),'capsule_sha256':sha((ROOT/'capsule.md').read_bytes()),'preservation_sha256':sha((ROOT/'original-phases-preservation-final.json').read_bytes()),'phase1_original_files_unchanged':111,'phase2_original_files_unchanged':47,'files_0444':len(files),'directories_0555':len(dirs),'exact_signatures':'unchanged P4d5056/T082eda, seal f47e23','review_status':'await independent exact-overlay recheck; no sourceV/topology or compiled-edge claim'})
    handles['freeze-execution.stdout'].write(log);handles['freeze-execution.stdout'].flush();handles['freeze-execution.stderr'].write(b'');handles['freeze-execution.stderr'].flush()
    env={'schema':'nonrecursive-phase3-freeze-envelope-hashes-v1','self_excluded':'freeze-envelope-hashes.json','files':[]}
    for name in sorted(envelope-{'freeze-envelope-hashes.json'}):
        b=(ROOT/name).read_bytes();env['files'].append({'path':name,'bytes':len(b),'sha256':sha(b),'mode':format(stat.S_IMODE((ROOT/name).stat().st_mode),'04o')})
    handles['freeze-envelope-hashes.json'].write(enc(env));handles['freeze-envelope-hashes.json'].flush()
    for h in handles.values():h.close()
    assert all(stat.S_IMODE(x.stat().st_mode)==0o444 for x in files);assert all(stat.S_IMODE(x.stat().st_mode)==0o555 for x in dirs)
    sys.stdout.buffer.write(log)
except BaseException:
    tb=traceback.format_exc().encode();h=handles.get('freeze-execution.stderr')
    if h and not h.closed:h.write(tb);h.flush()
    for h in handles.values():
        if not h.closed:h.close()
    sys.stderr.buffer.write(tb);raise
