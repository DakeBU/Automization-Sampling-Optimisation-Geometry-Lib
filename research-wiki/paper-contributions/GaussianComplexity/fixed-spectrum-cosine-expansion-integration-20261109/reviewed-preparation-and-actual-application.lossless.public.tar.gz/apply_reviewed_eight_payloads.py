"""Apply reviewed exact bytes only inside the real main95322 merge and sole STAB."""
from pathlib import Path
import gzip
import hashlib
import json
import subprocess
import sys
sys.dont_write_bytecode = True

P = Path('.astis/huanjian-gc-fixed-spectrum-cosine-expansion-integration-20261109')
Q = P / 'independent-reader/conditional-proposal-main95322-v2'
B = Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-cosine-expansion-integration-20261109')
C = Path('research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-cosine-expansion.json')
LP = Path('runs/substantive_advances.jsonl')
DP = Path('runs/substantive_discoveries.jsonl')
ADV = 'ASTIS-SA-20261109-GaussianComplexityFixedSpectrumCosineExpansion'
ACTOR = 'huanjian_gc_20261109_fixed_spectrum_cosine_expansion_integration'
MAIN = '95322cd2c762e5969c560815a803c4e15a424007'
sha = lambda b: hashlib.sha256(b).hexdigest()
dump = lambda x: (json.dumps(x, ensure_ascii=False, indent=2) + '\n').encode()
git = lambda *args: subprocess.check_output(['git', *args])

assert git('rev-parse', 'MERGE_HEAD').decode().strip() == MAIN, 'A real merge of main is required'
assert not git('diff', '--name-only', '--diff-filter=U').strip()
stage_A_raw = (Q / 'stage-A/reconciliation-manifest.json').read_bytes()
stage_B_raw = (Q / 'stage-B/payload-manifest.json').read_bytes()
assert sha(stage_A_raw) == 'c343c294bac4f6735b625789858fd62fe1973a5453ddd2124b6692215a8cd051'
assert sha(stage_B_raw) == '6dc1f5f6ae23b60723cc4ca5f52c3152a2a7bb37f64759d29d01ad8594a8bf2d'
a, b = json.loads(stage_A_raw), json.loads(stage_B_raw)
assert a['main'] == b['main_required_ancestor'] == MAIN
assert len(a['rows']) == 34 and len(b['rows']) == 8
for row in a['rows']:
    assert sha(Path(row['path']).read_bytes()) == row['expected_merged_raw_sha256'], row['path']
payloads = []
for row in b['rows']:
    target = Path(row['path'])
    if row['before'] is None:
        assert not target.exists(), target
    else:
        assert sha(target.read_bytes()) == row['before']['raw_sha256'], target
    ref = row['after']
    z = (Q / ref['archive']).read_bytes()
    raw = gzip.decompress(z)
    assert sha(z) == ref['archive_sha256'] and sha(raw) == ref['raw_sha256'] and len(raw) == ref['raw_bytes']
    payloads.append((target, raw))
before = LP.read_bytes()
assert before.endswith(b'\n')
records = [json.loads(x) for x in before.splitlines()]
assert all(isinstance(x, dict) for x in records)
sys.path.insert(0, str(Path.cwd()))
from tools import astis_advance as adv
states = adv._replay_advances(records)
assert [k for k, v in states.items() if v['state'] == 'STABILIZING'] == [ADV]
assert states[ADV]['latest_evidence']['integration_owner'] == ACTOR
protection = json.loads(gzip.decompress((B / 'before-STAB-protection.json.gz').read_bytes()))
assert {k: v for k, v in states.items() if k != ADV} == protection['foreign_states']
frontiers = {str(p): sha(p.read_bytes()) for p in Path('research-wiki/frontier-cells').rglob('*.json')}
assert frontiers == protection['all_frontier_hashes']
discovery = DP.read_bytes()
assert sha(discovery) == protection['discovery_sha256']
prod = Path('AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumCosineExpansion.lean')
test = Path('Tests/GaussianComplexityFixedSpectrumCosineExpansion.lean')
assert sha(prod.read_bytes()) == '659d6baf40abad2c48e7fced98c6c46a07624817cf14ef2de5a8146e82522de7'
assert sha(test.read_bytes()) == '7deb7539b72061b79b82865a956ac6560f505884d4fcb3ebba92a3d5f58d4759'
cell_raw = C.read_bytes()
cell = json.loads(cell_raw)
assert cell['status'] == 'independently_verified' and 'canonical_integration' not in cell['evidence']
stub = json.loads((B / 'sole-STAB-actual-receipt.json').read_bytes())
(B / 'frontier-before-payload-projection.raw.json.gz').write_bytes(gzip.compress(cell_raw, mtime=0))
for target, raw in payloads:
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(raw)
cell['evidence']['canonical_integration'] = {
    'state': 'REVIEWED_EIGHT_PAYLOADS_APPLIED_IN_REAL_MAIN_MERGE_CORE_GATES_PENDING',
    'owner': ACTOR, 'required_main_ancestor': MAIN,
    'source_V_first_carrying_commit': stub['source_V_carrier'],
    'source_verifier_preserved': stub['source_verifier_preserved'],
    'actual_STAB_append_sha256': stub['actual_append_sha256'],
    'conditional_payload_manifest_sha256': sha(stage_B_raw),
    'conceptual_mirror': 'Independently conceptually validated Poisson bridge retained in models; no Lean transport certificate.',
    'actual_core_gate_or_runtime_acceptance': False
}
cell['graph_contribution']['functor_view'] = 'stabilized'
C.write_bytes(dump(cell))
assert LP.read_bytes() == before and DP.read_bytes() == discovery
assert {str(p): sha(p.read_bytes()) for p in C.parent.rglob('*.json') if p != C} == {k: v for k, v in frontiers.items() if k != str(C)}
for row in b['rows']:
    assert sha(Path(row['path']).read_bytes()) == row['after']['raw_sha256']
changed_shared = {row['path'] for row in b['rows']}
for row in a['rows']:
    if row['path'] not in changed_shared:
        assert sha(Path(row['path']).read_bytes()) == row['expected_merged_raw_sha256']
receipt = {'state': 'ACTUAL_REVIEWED_EIGHT_PAYLOADS_APPLIED', 'actual_normal_API_calls_in_this_script': 0,
           'real_merge_HEAD': MAIN, 'payloads': [{ 'path': str(p), 'sha256': sha(raw)} for p, raw in payloads],
           'source_V_and_STAB_prefix_unchanged': True, 'foreign_frontiers_preserved': 445,
           'frontier_before_sha256': sha(cell_raw), 'frontier_after_sha256': sha(C.read_bytes()),
           'actual_core_gates_runtime_remote_purification': 'pending'}
(B / 'eight-payload-application-receipt.json').write_bytes(dump(receipt))
print(json.dumps(receipt))
