import hashlib,json,pathlib,tarfile
from run import ROOT
sha=lambda b:hashlib.sha256(b).hexdigest()
r=json.loads((ROOT/'report.json').read_text());r['HOLD'].append('full source-index and graph delivery')
r['typed_historical_harness_failures'].append({'class':'IMPLEMENTATION_FAILED','driver':'finalize_v1.py','receipt':'receipts/finalize.json','reason':'A metadata-only root commit advanced during report freeze; updated expected later metadata HEAD and compared all20 relevant files to401a3e1 without recompilation.'})
(ROOT/'report.json').write_text(json.dumps(r,indent=2)+'\n')
md=(ROOT/'report.md').read_text().replace('graph interaction/layout, copy/download runtime','full source-index and graph delivery, graph interaction/layout, copy/download runtime');(ROOT/'report.md').write_text(md)
im=json.loads((ROOT/'input-manifest.json').read_text())
selected=set()
for name in ['report.json','report.md','input-manifest.json','native-build.json','native-inspection-summary.json','reader-static.json','locator-checks.json','source-snippets.json','metadata-head-byte-comparison.json','REPRODUCE.md']:
    selected.add(ROOT/name)
selected.update(ROOT.glob('*.py'));selected.update((ROOT/'scratch').glob('InspectNative*.lean'));selected.add(ROOT/'scratch/LiteralApplications.lean')
for p in im['files']:
    if p.endswith('.lean') or p.startswith('website/') or p.endswith('statement-seal.json') or p.endswith('source-lean-map.draft.json') or p in {'lean-toolchain','lake-manifest.json'}:selected.add(ROOT/'inputs'/p)
labels=['native-build','sealed-literal-applications','native-environment-inspection-v2','reader-static-v4','validate-locators','prepare','prepare-v2','native-environment-inspection','reader-static','reader-static-v2','reader-static-v3','finalize','finalize-v2','inspect-process-v2','summarize-native','pretty-completeness','theme-input','v2-lean-version','v2-lean-binary-file','v2-final-head']+['compile-'+str(i) for i in range(6)]
labels+=['v2-dependency-'+d['name']+'-'+kind for d in im['dependencies'] for kind in ['head','status']]
labels+=['v2-final-dependency-'+d['name']+'-'+kind for d in im['dependencies'] for kind in ['head','status']]
for label in labels:
    for suffix in ['json','stdout','stderr']:
        p=ROOT/'receipts'/(label+'.'+suffix)
        if p.exists():selected.add(p)
files=[{'path':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in sorted(selected)]
retained=[]
for name in ['native-environment.json','native-environment-v1.json.gz','native-environment-v2.json','native-environment-v2.json.gz','native-six-authored-types.txt']:
    p=ROOT/name;retained.append({'local_path':name,'bytes':p.stat().st_size,'sha256':sha(p.read_bytes()),'portable_copy':False,'scope':'Only exact six-module owned namespace export; no foreign/whole-repository dump.'})
manifest={'schema_version':1,'compiled_candidate':im['candidate_commit'],'later_metadata_head':r['later_metadata_head'],'publication_binding_sha256':r['publication_binding_sha256'],'lean_binary':im['lean_binary'],'dependency_manifest_sha256':im['files']['lake-manifest.json']['sha256'],'mathematical_scope':'exact six native modules and44 owned constants, literal producer+private consumer','reader_scope':'bounded current production renderer static only; no browser, graph/public or purification acceptance','files':files,'large_local_retained_exports':retained,'portable_member_count':len(files),'total_uncompressed_bytes':sum(f['bytes'] for f in files),'report_sha256':sha((ROOT/'report.json').read_bytes())}
(ROOT/'portable-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(ROOT/'portable-evidence.tar.gz','w:gz') as tar:
    for p in sorted(selected):tar.add(p,arcname=str(p.relative_to(ROOT)),recursive=False)
    tar.add(ROOT/'portable-manifest.json',arcname='portable-manifest.json',recursive=False)
print(json.dumps({'report_sha256':manifest['report_sha256'],'portable_manifest_sha256':sha((ROOT/'portable-manifest.json').read_bytes()),'archive_sha256':sha((ROOT/'portable-evidence.tar.gz').read_bytes()),'archive_bytes':(ROOT/'portable-evidence.tar.gz').stat().st_size,'members':len(files)+1,'uncompressed_bytes':manifest['total_uncompressed_bytes']},indent=2))
