from pathlib import Path
import datetime
import hashlib
import json
import runpy
import subprocess
import sys

ROOT = Path('/Users/zhouhuanjian/ASTIS-GC')
OWN = ROOT / '.astis/semantic-neutral-20261112/ri_tc_24a6'
EXPECTED_HEAD = '2c57883183937fdef1578a2b33e4ea892af2c694'
EXPECTED_SOURCE = '6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'

def digest(p):
    b = p.read_bytes()
    return {'path': str(p.relative_to(ROOT)), 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}

head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
assert head == EXPECTED_HEAD, (head, EXPECTED_HEAD)
source = ROOT / '.astis/huanjian-resume-20261103/2610.20492v1.html'
source_info = digest(source)
assert source_info['bytes'] == 951991 and source_info['sha256'] == EXPECTED_SOURCE

protocol_paths = [
    'AGENTS.md', 'CONTRIBUTING.md', '.agents/prompts/collaborator-contribution.md',
    'docs/contributor-codex-contract.md', 'docs/theorem-publication-protocol.md',
    'docs/proof-digestion-protocol.md', 'docs/evidence-routed-memory-protocol.md',
    '.agents/skills/astis-substantive-advance/SKILL.md', 'LICENSE_SCOPE.md',
]
protocols = [digest(ROOT / p) for p in protocol_paths]
sys.argv = [str(OWN / 'read_raw.py'), 'freeze']
reader = runpy.run_path(str(OWN / 'read_raw.py'))
by_id = reader['by_id']
selected = ['S4.Thmtheorem4', 'S4.E11', 'A3.SS2.p1', 'A3.SS2.p4.m2',
            'A3.SS2.p10.1', 'A3.SS2.p12.1', 'A3.Ex107']
locators = []
for ident in selected:
    node = by_id[ident]
    rendered = node.clean().encode()
    locators.append({'html_id': ident, 'start_line': node.line,
                     'projection': 'HTMLParser text with each math element replaced by its alttext; whitespace collapsed',
                     'rendered_text_bytes': len(rendered),
                     'rendered_text_sha256': hashlib.sha256(rendered).hexdigest()})

local_paths = ['assignment.txt', 'exposure.json', 'raw-reading.md', 'read_raw.py', 'freeze.py']
local_records = [digest(OWN / p) for p in local_paths]
protocol_bytes = json.dumps(protocols, sort_keys=True, separators=(',', ':')).encode()
packet = {
    'record_kind': 'preliminary-independent-raw-reading-freeze',
    'actor': '/root/row_indep_topology_24a6',
    'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'tracked_head_before_and_at_freeze': head,
    'owned_write_root': str(OWN.relative_to(ROOT)),
    'source': source_info,
    'input_record_note': 'assignment.txt is a whitespace-normalized transcription of the root assignment plus its subsequent amendment; the hash binds this transcript, not transport bytes unavailable to this actor.',
    'local_records': local_records,
    'protocols': protocols,
    'protocol_manifest_sha256': hashlib.sha256(protocol_bytes).hexdigest(),
    'source_locator_projection_hashes': locators,
    'chronology_gate': {
        'statement_seal_received': False,
        'binder_definition_audit_received': False,
        'source_graph_received': False,
        'new_typed_packet_received': False,
        'implementation_lean_seen': False,
        'raw_reading_frozen': True,
        'formal_topology_challenge_or_admission_started': False,
        'proof_or_signature_grant': False,
    },
    'truth_boundary': 'Raw reading/exposure/scope/locators and preliminary omitted-bridge concerns only; no mathematical proof, compiled/call/transformation edge, signature or topology admitted.',
    'next_required_input': 'Exact Statement Seal plus binder/definition audit, followed by root-authorized source graph/types handoff.',
}
out = OWN / 'raw-freeze.json'
out.write_text(json.dumps(packet, indent=2, ensure_ascii=False) + '\n')
records = [digest(OWN / p) for p in local_paths] + [digest(out)]
(OWN / 'SHA256SUMS').write_text(''.join(f"{x['sha256']}  {Path(x['path']).name}\n" for x in records))
print(json.dumps({'freeze': digest(out), 'exposure': digest(OWN / 'exposure.json'),
                  'reading': digest(OWN / 'raw-reading.md'),
                  'protocol_manifest_sha256': packet['protocol_manifest_sha256'],
                  'head': head}, indent=2))
