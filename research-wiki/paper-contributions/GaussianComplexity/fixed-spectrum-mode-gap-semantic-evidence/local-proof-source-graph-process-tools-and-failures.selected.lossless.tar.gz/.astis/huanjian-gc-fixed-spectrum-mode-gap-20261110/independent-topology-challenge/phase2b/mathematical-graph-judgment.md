# Mode-gap exact graph: independent mathematical/source admission

**ACCEPT_MATHEMATICAL_SOURCE_TOPOLOGY_COVERAGE_ROOT_SUBROOT_CLOSURES. No mathematical graph HOLD was found.** The exact statement ACCEPT is unchanged. This freezes the mathematical judgment **before** the separate chronology disclosure. It does not grant prospective proof/API permission or decide that process question, and does not certify compilation, actual implementation use, source V or Goal credit. Stop after this freeze.

## Exact inputs and independence

The source remains the pinned 951991-byte raw HTML SHA-256 `6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915`. Own raw freeze `e82bcd88ca0b31661e035c25164e51b356a48b87e6771ed77dcce458aa7015b2` preceded strict projection v2 `54b23ce1ccd86b780b8c2b38bb18ac3cf91b5102afefe15444b2231e1b65c0f9`. Own statement freeze `26cc9f367e9a9518d062d08570948921bb2789eb1d265c19d3c9e82b5279da86` preceded all new extractor inputs. The full parent seal and unissued projection were not opened.

This admission binds the exact author machine artifacts:

| File | SHA-256 |
| --- | --- |
| phase2-freeze.json | 38671a5bda14e7164d6b33c1ecbd2e892dcf3c2092d2d1c2cf557add94ea225e |
| source-proof-graph.json | a2376d7ecdd2c186fe59c4b55db300ea5695bf046fb81c2b2902e01d1eb52ed0 |
| exact-target-coverage.json | 4aa3b58447de06c53f3195d4f73e0f9509e093fe72aaae0c18a67d7e6bf1e0d9 |
| root-subroot-closures.json | 9905d6e4fd66b8b2e264cdfd207ae7143ad85acad9440fc37a0846602ade96a9 |
| statement-projection-audit.json | 6c9d9c7ab6de843708c09928cfd7baf799d046d544a34dee493cab35875a9be7 |
| machine-inputs.json | c1c26eab25d3bf36dc7a61acb92fff718fdff9e6edb58236a2cb30ebfbda21ed |
| binding-lineage.json | 6534fe7aac3e4d845b35f12d7093736a638cc14227fdd4cdd827d851d0b9a9d0 |

The creator's statement-audit artifact was hashed only, not parsed or adopted as a verdict. Freeze metadata necessarily exposed its filenames/status/assessment strings; these were not used as completeness evidence. Extractor private cognition, generators and old verdict artifacts were not read. The raw-source rows in the current coverage file suffice for direct independent source checking; no private phase1 rationale was needed.

## Exhaustive raw coverage, not count-only agreement

Every machine source key was rebound to actual tag/line/column in the pinned HTML and to an element in the independent own census. All 366 raw ordinals are unique and have exactly one successor: **49 NODE, 317 EXCLUDED**. All original HTML IDs, raw LF line-fragment hashes, mathematical text modulo renderer whitespace, math tuples, internal-reference tuples, nearest ID-bearing parents and true containing display IDs match the raw source.

The exact source census agrees with own 367 units after one explicit granularity difference: own census separately records the external download hyperlink `a@1853:0` in bib.bib3, while machine unit enumeration separately records internal-reference links only. The external local title/identifier/raw line is preserved in the excluded bibliography object. No linked external document was opened and no mathematical assertion/citation identity is missing. All **350 actual math elements** equal the own raw registry. The 53 machine internal links plus that external link equal the own 54 link occurrences.

Same-line anonymous link collisions remain distinct by source key and ordinal (66/68 at line1112; 181/182 at line1388). Named log TBODY rows Ex152–156 retain their correct actual parent groups and are selected as mathematical rows; aggregate groups are explicitly excluded as duplicate rendering containers. The selected lower clauses of Ex17/151/157/159 and the partial source-domain paragraphs have explicit included/excluded fragments. Proof-end markers, including p11.3, are not promoted to final formulas.

The scalar source use sites are p1.1/p1.2 of the algorithm-side subsection and p2.1 of the target-side subsection. Ex20 τ decay, the uniform algorithmic event, fourth moments/variance, upper bias, closed-M growth, Ex24, 320, shifted contrast, Chebyshev, rotated transport, TV/oracle/cost and limitations branches receive explicit scope exclusions. The four historical [22] citations and the genuinely referenced bibliography object remain preserved without being silently imported as missing mathematical premises. The source's complete sections are inventoried; this admission does not claim complete formalization of those sections.

## Public producer: source uniformity and conditional discharge

The scalar producer closure contains only scalar-role nodes. Its premise context consists of fixed δ and the original conditional scalar regime; its local n=2q+1 is a literal definition. `S_regime` records the guarded universal scope after the eventual witness, not an assumed successful cutoff or an already proved mode/gap fact. The cutoff itself and all range consequences remain outputs/internal obligations.

The α=(1−δ)/2 notation is defined internally from 0<δ<1, with no extra exponent hypothesis. The graph retains the positive-domain sqrt/rpow comparison, the uniform √κ envelope, the source q+1 envelope with explicit +1 absorption, the two natural-dimension growth facts, and separate uniform small-mode/small-spectrum statements. None is replaced by a limit for one fixed κ/q sequence.

Each intermediate tolerance permits a δ/η-dependent threshold. The eventual mode/gap and common-cutoff nodes must internally select fixed tolerances and intersect/enlarge natural cutoffs, leaving one witness depending only on δ before all d/κ/q universals. This quantifier-order obligation is explicit; no witness may be chosen after κ/q or sample selection. The source omits these details, so visible SOURCE_GAP nodes are appropriate and remain unproved, rather than becoming public caller certificates.

The gap route genuinely AND-combines both uniform small-o controls. It keeps the real rearrangement from n+√κ≤d to √κ≤d−n and does not substitute natural truncation. The positive mode comes from natural q, with q=0 retained; eventual d≥2 is internally supplied. The four-output producer root preserves all of these conclusions under exactly the admitted source regime. No Gaussian, mean, variance, τ, event, oracle or API dependency enters this scalar root.

## Private actual-law application and prior-source boundaries

The producer-output projection is the application interface providing d≥2, positive source mode, n<d and spacing. The private actual object is the same literal midpoint spectrum and Gaussian with covariance Λ⁻¹ (Λ is precision), with actual Q/M/b integrals. Domain, inverse/covariance, probability and finite-integrability bridges remain internal; no alternative law, callback or certificate is a binder.

The mean-source route separates actual finite expectation/sum identities from C7's absolute scalar-series/finite-grid exchange. All-integer alias cases, three positive disjoint coefficient classes, parity/resummation, actual exact means, signed/M positivity and ratio cancellation are visible. These are expanded **source prerequisite applications**, not new compiled/verified API claims or instructions to re-prove existing canonical results. Their closure here is instantiated in this source query regime; it is not a claim that the general C7/grid/mean facts intrinsically require δ, q or the new eventual threshold.

The lower-bias source ingredient retains the ratio of actual means, positive denominator, the nonsingular log-integral background, the exact log constants, correct negative-multiplier order reversal, lower power estimate and separated tail factor. The produced source gap is discharged at that application, not added to the public producer premises. Source/prerequisite labels do not certify the eventual Lean calls; matching canonical actual-law evidence is still required during proof integration.

The query-exponent branch separately preserves 3δ/128 from the exact budget and mode. Its comparison with δ/4 is a weakening under the established positive/log domain, not equality of coefficients. Real positive-base powers and factor 1−exp(−4)>0 are internal guards. The final private numerical component keeps exact constant `(1−exp(−4))*exp(−3)` and rate −δ/4, plus actual M/signed-b positivity, without confusing the actual mean b with the source scalar constant b.

The private uniform-application node retains a δ-only threshold across all actual parameterized Gaussian objects; no later κ/q-dependent witness or free random-law assumption appears. It is a substantive use of the public applicability result and source lower-bias ingredient, not a repeated range wrapper. It proves neither a shifted event nor a probability, rotation, TV, cost, algorithm or main lower-bound statement. The source graph does not certify actual future implementation use.

## Full roots and all output/guard subroots independently recomputed

Every listed route is AND, with no source-supported alternative proof being flattened into an unrelated conjunction; no OR route is asserted. All 23 SOURCE_GAP nodes have incoming internal routes and none is a free premise leaf. There is no directed cycle. I rebound **100 node source snapshots and 64 consumer use sites** directly to the checked raw rows.

Independent backward traversal exactly reproduces the five supplied node/route/gap sets and records their source-anchor/use-site-anchor sets:

| Root | Nodes | Routes |
| --- | ---: | ---: |
| producer all outputs | 18 | 15 |
| consumer all outputs | 52 | 48 |
| consumer scalar-domain subroot | 19 | 16 |
| consumer actual-bias subroot | 44 | 40 |
| consumer query-exponent subroot | 24 | 21 |

The individual output and uniformity subroots were additionally recomputed: large-d domain (2/1), literal positive mode (1/0), eventual mode upper bound (13/10), eventual gap (14/11), uniform mode-small (11/8), uniform sqrt-small (8/6), actual M positivity (32/28), signed-b positivity (32/28), exact source exponent (21/18), exponential-to-power bound (24/21), and actual polynomial bias (50/46). The source-mode and Gaussian dependencies are therefore checked beyond the bundled roots. Producer leaves are exactly S_delta/S_mode/S_regime; consumer adds only the literal actual-object node, not a theorem-shaped assumption.

Current raw/history canonical hashes match lineage bindings. Historical rows/dispositions remain preserved in the current machine file; no private old mathematical record was used to certify them. Structural PASS supports serialization and source identity only; the independent source reasoning above is the mathematical scope/topology assessment.

## Freeze and stop boundary

Own raw and statement checksum members were rechecked unchanged. Earlier paper/challenge/process exposure remains disclosed; no pristine ignorance or zero-cue claim is made. The current separate chronology note/root planning record remains unread, so this report draws no conclusion about current process ordering or prospective permission.

This is the mathematical source/topology ACCEPT only. **Prospective proof/API decision remains pending the separately authorized process-only chronology audit.** No target proof, implementation/API/Mathlib body, generator/private cognition, lesson, other reviewer verdict, full seal, frontier/ledger/global record, normal ASTIS, build, source V or Goal completion was accessed or executed. Only this new private phase2b directory was written. Stop now.
