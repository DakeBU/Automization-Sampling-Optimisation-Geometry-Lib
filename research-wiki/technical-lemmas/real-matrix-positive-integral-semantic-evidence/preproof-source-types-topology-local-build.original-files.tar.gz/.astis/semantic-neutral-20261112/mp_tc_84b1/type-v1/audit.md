# Independent type/source-meaning audit: shared real-matrix positive integral

**No type/binder/source-attribution issue was found relative to the explicitly
authored shared-background contract.** The producer is an ASTIS-authored
general background theorem. It is not a printed arbitrary-function theorem in
the Gaussian paper, a source repair, or a license to change the R9 source
target's hypotheses. No background source graph, new implementation, root old
proof, library proof/API search or other review was read.

## Exact input and source boundary

The exact packet is
`.astis/huanjian-real-matrix-positive-integral-20261112/selective-type-definition-packet.json`,
SHA-256 `d2d9493c6fd09222fbe183fcb296bd0c104328a462a03f28b7c9930caa9b9e95`.
It names shared seal
`a5179ed392ef8e55ab470a3a98ebd542e35301f51472e9cdd7bc168a88bafa26`
and context `f43d358af135d42c8585f927f7e20b2b3363af2bf28eed98298f2996a2f8e591`.
The exact producer signature independently hashes to
`283e07e3c85b9a5cce5c3c40f574f23f593dfcca5e35be4d3e2800f378208b19`.
The actual consumer string hashes to
`d5ac54443c79ea7b35b09ddcd6b5e3c40bef081bbe4f196cae5ab3ead35aa2ea`,
exactly the previously frozen R9 producer signature. Its named existing seal
remains `5f905cafe6035238cebdedd4f841e87b703e741b4c8aa204471d89e4c07e8a14`.
No research-wiki seal file was opened or changed. All eight embedded standard
excerpt hashes, the literal-print digest and all four pinned paper span hashes
were recomputed and matched. Separate unspecified seal/context serialization
was not independently reconstructed.

The actor's R9 raw source reading predates exposure to this new shared type.
It supplies an application-source baseline for p14, Ex115, Ex118 and Ex120,
where the paper integrates PSD residuals/squares. It does not supply evidence
of a printed generic theorem quantifying over arbitrary n, Omega, mu and f.
The packet correctly labels that quantification as an authored background
expansion. No new pre-type generic-source reading is fabricated here.

The future fixed external Mathlib Analysis/Convex/Integral.lean source was not
opened in this type-only phase. Its actual hypotheses and any proposed proof
route remain for the later independent background-graph challenge. No
closed-convex integral theorem is credited merely by a file or theorem name.

## Every logical input and its scope

The index n is an arbitrary finite type with DecidableEq, and Omega is an
arbitrary measurable type. These are carrier/finite-sum typing. The theorem
does not restrict n to Fin(q+1), require positive dimension, or include a
Nonempty n binder. The explicit function f is the actual matrix-valued map,
not a supplied matrix intended to be its expectation.

The arbitrary measure mu with IsProbabilityMeasure, Integrable f mu, and
AE PosSemidef(f omega) are the stated hypotheses of the authored theorem.
They are genuine analytic/mathematical contracts for arbitrary f. They are
not project-owned opaque bundles, and none assumes the desired positivity of
the integral itself. No excess input relative to this explicit authored
contract was found. The probability restriction is a deliberate bounded
authored scope, not a claim that it is mathematically minimal for every
possible positive-integral theorem.

AUTHORED_BACKGROUND_HYPOTHESIS in this binder table must not be read as a new
source-premise category for Gaussian Source Anchors. In the actual R9 theorem,
mu and Y are literal definitions, its only logical input remains 2q+1<d, and
integrability/positivity evidence needed by any shared-lemma application must
be produced inside its proof. In particular, hf and hpos must not be added to
that source theorem, wrapped in a certificate, or inferred from a producer
name. The current concrete signature is byte-identical to the old exact
signature, so no such premise transfer occurred in this packet.

## Definitions: AE, full PSD and genuine integral

Matrix is the finite real two-index function carrier. PosSemidef is full
Hermitian structure and nonnegative finite quadratic form, not entrywise
nonnegativity. Over real scalars the Hermitian condition is symmetry. The
generic result promises full PSD of the actual deterministic Bochner integral.
It does not merely promise individual entry inequalities or assume a
postulated PSD expected matrix.

hpos is almost-everywhere positivity of the full matrix predicate. It allows
arbitrary exceptional values on a mu-null set and does not assert all-outcome
positivity. It includes Hermitian and all quadratic-form conditions together
on its good set. A future argument may not silently strengthen this into
pointwise positivity or demand a separate pointwise symmetry certificate.
Null-set insensitivity and any representative/closed-cone argument are
internal proof obligations.

hf expands to an almost-everywhere strongly measurable representative and
finite extended-norm integral. It supplies the actual arbitrary f's analytic
contract, without adding a separate measurability witness. The Bochner
integral's nonintegrable zero default cannot be used as a fake proof because
hf is a real theorem assumption. Completeness comes from the actual finite
real matrix space, not an additional caller certificate.

The definition context identifies Matrix.Norms.L2Operator as the Euclidean
operator norm, with standard finite-matrix completeness. Its current concrete
instance print block comes from the R9 paired-index context; it is not a
separately run generic-n elaboration by this reviewer. The generic standard
norm definitions are supplied, and this audit interprets the authored
signature in its declared L2Operator scope. No new typeclass premise or
alternate norm is introduced. Exact generic elaboration/API application is
not certified by a source-meaning audit.

## Empty indices and internal cone facts

The statement permits n empty. In that case the finite matrix carrier has its
unique empty matrix, Hermitian equality and quadratic positivity have their
ordinary empty-index meanings, and the integral still has that matrix
carrier. There is no source or authored positive-dimension contract to add.
A later implementation whose chosen library theorem needs Nonempty n must
handle the empty case internally or choose a faithful API; it cannot weaken
the fixed signature by silently adding that binder.

Likewise, a proof based on the PSD cone must establish its membership semantics,
closedness, convexity, zero membership/nonemptiness and the required topology/
integral compatibility internally. Any ambient theorem's cone/set nonempty
condition concerns that constructed set, not a new positive matrix-dimension
or source hypothesis. No closed/convex cone assumption is present in the public
signature, and this audit supplies no proof of those facts.

## Actual R9 consumer and remaining boundary

The actual consumer is exactly the original-column R9 squared-moment producer:
same natural d,q and hq, same product standard-Gaussian law, actual coordinate
row, literal midpoint t, inclusive cutoff and Gaussian-first Kronecker order.
It concludes actual Y_i*Y_i integrability and the full PSD difference
C I - sum_i E_mu[Y_i*Y_i]. It has no generic f, hf or hpos input and no extra
mean/PSD/moment/variance certificate. Its q=0 endpoint and source normalization
are unchanged.

A concrete application of the shared result to a PSD residual or square needs
its exact matrix carrier/norm, actual probability measure, actual integrability
and AE full PSD proved internally. The reusable lemma by itself does not give
the Gaussian row law, fourth moment, cutoff order, finite tensor/frame algebra,
centering or source variance bound. The later centered and weighted-square
families are intended real reuse contexts, not observed current compiled
call edges in this audit.

No source theorem, R9 original seal, historical R4/R5 private proof or API
status has been revalidated. The packet discloses formalizer_API_pristine=false;
the floor-search report is supplied context only. The ordinary embedded
standard definition/identity fragments are the allowed type semantics, not
new-target proof work. This finding grants no source/theorem completion,
compiled dependency, source VERIFIED, normal V, integration or permission.

The next step for this actor is to wait for the separately authorized shared
background graph and then challenge its source/application/closed-cone
applicability coverage independently. No SG opinion has been read here.
