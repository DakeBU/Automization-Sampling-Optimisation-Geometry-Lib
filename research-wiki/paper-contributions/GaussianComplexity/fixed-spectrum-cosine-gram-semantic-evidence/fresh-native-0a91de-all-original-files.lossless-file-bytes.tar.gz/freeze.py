"""Seal every payload file and directory; the two envelope files are explicit."""
import datetime, hashlib, json, os, pathlib, stat

D=pathlib.Path(__file__).resolve().parent
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,obj): p.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
write(D/'freeze-invocation.json',{'command':['python3',str(D/'freeze.py')],
  'candidate':'72e5d1405284f729f4eb600c5ae5dd556365b7e2','started_at_utc':now,
  'scope':'All descendants without payload truncation; only freeze-manifest.json and freeze-outer-receipt.json are envelope files.',
  'target_file_mode':'0444','target_directory_mode':'0555'})
envelope={'freeze-manifest.json','freeze-outer-receipt.json'}
allpaths=sorted(D.rglob('*'))
assert not any(p.is_symlink() for p in allpaths)
files=[p for p in allpaths if p.is_file() and p.relative_to(D).as_posix() not in envelope]
directories=[D]+[p for p in allpaths if p.is_dir()]
manifest={'schema':'astis-lossless-full-payload-freeze/v1','candidate':'72e5d1405284f729f4eb600c5ae5dd556365b7e2',
  'payload_scope':'Every file and directory under this review root, including all failed attempts, raw outputs, input blobs, scripts, generated .olean/.ilean artifacts and Python caches. Exactly two envelope files excluded from this payload list to avoid recursive hash definitions.',
  'explicit_envelope_files':sorted(envelope),
  'files':[{'path':p.relative_to(D).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p),'frozen_mode':'0444'} for p in files],
  'directories':[{'path':'.' if p==D else p.relative_to(D).as_posix(),'frozen_mode':'0555'} for p in directories]}
mf=D/'freeze-manifest.json'; write(mf,manifest)
receipt={'schema':'astis-lossless-freeze-outer-receipt/v1','reviewer':'independent-native-reader-0a91de',
  'candidate':manifest['candidate'],'created_at_utc':now,'manifest_path':'freeze-manifest.json','manifest_sha256':sha(mf),
  'payload_file_count':len(files),'payload_bytes':sum(p.stat().st_size for p in files),'directory_count':len(directories),
  'findings_sha256':sha(D/'findings.json'),'native_result':'PASS','reader_delivery':'HOLD',
  'final_modes':{'all_files_including_both_envelopes':'0444','all_directories_including_root':'0555'},
  'boundary':'No source-fidelity verdict, VERIFIED/SourceV/STAB transition, global or Goal acceptance. Stop after this freeze.'}
outer=D/'freeze-outer-receipt.json'; write(outer,receipt)
for p in files+[mf,outer]: p.chmod(0o444)
for p in sorted(directories,key=lambda p:len(p.parts),reverse=True): p.chmod(0o555)
for record in manifest['files']:
    p=D/record['path']; assert sha(p)==record['sha256'] and stat.S_IMODE(p.stat().st_mode)==0o444
for p in directories: assert stat.S_IMODE(p.stat().st_mode)==0o555
assert stat.S_IMODE(mf.stat().st_mode)==0o444 and stat.S_IMODE(outer.stat().st_mode)==0o444
assert sha(mf)==receipt['manifest_sha256']
print(json.dumps({'frozen':True,'payload_files':len(files),'payload_bytes':receipt['payload_bytes'],
  'directories':len(directories),'all_files_mode':'0444','all_directories_mode':'0555',
  'findings_sha256':receipt['findings_sha256'],'manifest_sha256':receipt['manifest_sha256'],
  'outer_receipt_sha256':sha(outer)},indent=2))
