from pathlib import Path
import gzip,hashlib,json,subprocess,tarfile
P=Path('.astis/huanjian-gc-fixed-spectrum-moments-20261109/cosine-expansion')
E=Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-cosine-expansion-semantic-evidence')
sha=lambda b:hashlib.sha256(b).hexdigest()
dump=lambda x:(json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode()
git=lambda *a:subprocess.check_output(['git',*a])
assert git('rev-parse','HEAD').decode().strip()=='27ee4447905b5c43d7fa56546dd1a915b365094f'
assert not git('diff','--cached','--name-only').strip()
assert sha(Path('AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumCosineExpansion.lean').read_bytes())=='659d6baf40abad2c48e7fced98c6c46a07624817cf14ef2de5a8146e82522de7'
assert sha(Path('Tests/GaussianComplexityFixedSpectrumCosineExpansion.lean').read_bytes())=='7deb7539b72061b79b82865a956ac6560f505884d4fcb3ebba92a3d5f58d4759'
roots=[P,Path('.astis/semantic-neutral-20261109/src_cosine_27c4e1'),
       Path('.astis/semantic-neutral-20261109/src_cosine_5d8c2a/phase1'),
       Path('.astis/semantic-neutral-20261109/src_cosine_5d8c2a/phase2'),
       Path('.astis/semantic-neutral-20261109/src_cosine_5d8c2a/phase2-inputs'),
       Path('.astis/huanjian-gc-fixed-spectrum-moments-20261109/poisson-mirror-independent-review/v1')]
assert sha((roots[3]/'manifest.json').read_bytes())=='b5e8a7a77d0aedca153100bec3655755d4796ed805d2dfa3dcecf97fab7f7a04'
payload=[]
for base in roots:
    assert base.exists(),base
    for q in sorted(base.rglob('*')):
        if q.is_file() and '__pycache__' not in q.parts and q.suffix!='.pyc':payload.append(q)
archive=E/'local-proof-tools-reviews-and-retained-failures.lossless.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz') as t:
    for q in payload:t.add(q,arcname=str(q),recursive=False)
with tarfile.open(archive,'r:gz') as t:
    for q in payload:assert t.extractfile(str(q)).read()==q.read_bytes(),q
(E/'local-proof-archive-manifest.json').write_bytes(dump({'archive':str(archive),'sha256':sha(archive.read_bytes()),
    'files':[{'original':str(q),'member':str(q),'sha256':sha(q.read_bytes()),'bytes':q.stat().st_size} for q in payload],
    'scope':'Actual local proofs, fresh semantic phase1/2, independent conceptual review/validation and all failed/contaminated inputs. Not source V, aggregate integration or publication acceptance.'}))
checks=E/'actual-local-checks';checks.mkdir()
receipts=sorted(Path('.astis/huanjian-resume-20261103').glob('*-cosine-expansion-*.receipt.json'))
rows=[]
for q in receipts:
    r=json.loads(q.read_bytes());raw=Path(r['log']).read_bytes();assert sha(raw)==r['log_sha256']
    (checks/q.name).write_bytes(q.read_bytes());z=checks/(Path(r['log']).name+'.gz');z.write_bytes(gzip.compress(raw,mtime=0))
    rows.append({'receipt':str(checks/q.name),'exit_code_actual':r['exit_code'],'raw_log_sha256':sha(raw)})
(E/'actual-local-checks-manifest.json').write_bytes(dump({'checks':rows,'publication_and_contributor_full_checks':'Actual exit1 pending independent accepted whole-module review; no unchanged retry or false PASS.','proof_and_kernel_checks':'Actual successful separate builds and literal type/Std3 inspection; see individual actual receipts.'}))
tracked=set(git('ls-files','-z').decode().strip('\0').split('\0'))
pack=E/'local-candidate-raw-packaging';pack.mkdir();safe=[];wrapped=[]
for q in sorted(q for q in E.rglob('*') if q.is_file() and str(q) not in tracked):
    raw=q.read_bytes();binary=q.suffix in ['.gz','.zip','.png'] or b'\0' in raw
    ignored=subprocess.run(['git','check-ignore','-q','--',str(q)]).returncode==0
    bad=not binary and (b'\r\n' in raw or raw.endswith(b'\n\n') or any(l.endswith((b' ',b'\t')) for l in raw.splitlines()))
    if ignored or bad:
        z=pack/(str(len(wrapped)).zfill(3)+'-'+q.name+'.gz');z.write_bytes(gzip.compress(raw,mtime=0))
        assert gzip.decompress(z.read_bytes())==raw
        wrapped.append({'original':str(q),'raw_sha256':sha(raw),'gzip':str(z),'gzip_sha256':sha(z.read_bytes()),'original_retained':True});safe.append(z)
    else:safe.append(q)
mp=pack/'manifest.json';mp.write_bytes(dump({'files':wrapped,'lossless_only':True}));safe.append(mp)
mutable=list(map(Path,[
 'AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumCosineExpansion.lean',
 'Tests/GaussianComplexityFixedSpectrumCosineExpansion.lean',
 'website/content/declaration_lessons/huanjian-fixed-spectrum-cosine-expansion.json',
 'website/content/publications/huanjian-fixed-spectrum-cosine-expansion.json',
 'research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-cosine-expansion.json',
 'research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-cosine-expansion.json',
 'research-wiki/paper-contributions/GaussianComplexity/README.md',
 'runs/substantive_advances.jsonl','runs/substantive_discoveries.jsonl']))
safe=sorted(set(safe+mutable));subprocess.run(['git','add','--',*map(str,safe)],check=True)
staged=git('diff','--cached','--name-only','-z').decode().strip('\0').split('\0')
assert set(staged)==set(map(str,safe))
for q in staged:assert git('show',':'+q)==Path(q).read_bytes(),q
subprocess.run(['git','diff','--cached','--check'],check=True)
print(json.dumps({'staged_paths':len(staged),'retained_frozen_artifacts':len(payload),'all_index_bytes_equal_live':True,
    'source_VERIFIED_or_publication_acceptance_or_aggregate_build':False}))
