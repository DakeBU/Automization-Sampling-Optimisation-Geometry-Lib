from pathlib import Path
import json, hashlib, copy, datetime, re

P3 = Path(__file__).resolve().parent
B = P3.parent
P2 = B/'phase2'
expected_parent_freeze='10c8d1e3034f41e007f3898aaedc29d1de44e5ec869b4e118cc2eceb21267945'
expected_parent_graph='54afc6149bc90dce57e27306383f4d74e49f48347ea6a5b352eafd89b9dc88c1'
def sha(b):return hashlib.sha256(b).hexdigest()
def dump(name,x):
    path=P3/name
    assert not path.exists(), path
    path.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
assert sha((P2/'FREEZE.json').read_bytes())==expected_parent_freeze
assert sha((P2/'source-graph.json').read_bytes())==expected_parent_graph
for rec in json.loads((P2/'FREEZE.json').read_text())['files']:
    assert sha((B/rec['path']).read_bytes())==rec['sha256'],rec['path']
parent=json.loads((P2/'source-graph.json').read_text())
resolved=copy.deepcopy(parent)

def at(x,p):
    for k in p.split('/')[1:]:
        k=k.replace('~1','/').replace('~0','~')
        x=x[int(k)] if isinstance(x,list) else x[k]
    return x
def set_at(x,p,v):
    ks=p.split('/')[1:];last=ks.pop()
    for k in ks:x=x[int(k)] if isinstance(x,list) else x[k]
    x[int(last) if isinstance(x,list) else last]=v

# Explicit pointer/value replacements: no search-and-replace is used to mutate the graph.
inverse_old='Inverse covariance is diagonal with entries lambda_i^-1 and positive definite'
inverse_new='Covariance Lambda^-1 (inverse of precision Lambda) is diagonal with entries lambda_i^-1 and positive definite'
l2_old='Coordinate squares/products integrable and zero mean/inverse covariance exact'
l2_new='Coordinate squares/products integrable; mean zero and covariance Lambda^-1 (inverse of precision Lambda) exact'
changes=[]
for pointer in [
 '/conditional_requirements/C-inverse/required',
 '/edges/1/conditional_discharge/1/required',
 '/edges/2/conditional_discharge/0/required',
 '/edges/4/conditional_discharge/1/required']:
    changes.append(dict(pointer=pointer,before=inverse_old,after=inverse_new,
      reason='Correct the condition subject: covariance is Lambda^-1=diag(lambda_i^-1); inverse covariance is precision Lambda=diag(lambda_i). The reciprocal diagonal formula and SPD requirement are retained.'))
for pointer in [
 '/conditional_requirements/C-L2/required',
 '/edges/3/conditional_discharge/1/required',
 '/edges/4/conditional_discharge/0/required',
 '/edges/7/conditional_discharge/1/required']:
    changes.append(dict(pointer=pointer,before=l2_old,after=l2_new,
      reason='Replace the ambiguous inverse-covariance label by the exact intended covariance Lambda^-1; retain integrability and zero mean as internal obligations.'))
changes.append(dict(pointer='/edges/0/mechanism',
  before='Ensure the precision and inverse covariance are nondegenerate from literal source inputs.',
  after='Ensure precision Lambda and covariance Lambda^-1 (inverse of precision Lambda) are nondegenerate from literal source inputs.',
  reason='Name the two matrices explicitly; no bound, formula, premise, edge or target changes.'))
assert len(changes)==9
for c in changes:
    assert at(resolved,c['pointer'])==c['before'], c['pointer']
    set_at(resolved,c['pointer'],c['after'])

def differences(a,b,p=''):
    if type(a)!=type(b):return [(p,a,b)]
    if isinstance(a,dict):
        assert set(a)==set(b),(p,'keys changed')
        return [z for k in a for z in differences(a[k],b[k],p+'/'+str(k).replace('~','~0').replace('/','~1'))]
    if isinstance(a,list):
        assert len(a)==len(b),(p,'length changed')
        return [z for i,(x,y) in enumerate(zip(a,b)) for z in differences(x,y,p+'/'+str(i))]
    return [] if a==b else [(p,a,b)]
diff=differences(parent,resolved)
assert {d[0] for d in diff}=={c['pointer'] for c in changes}
assert len(diff)==9
assert parent['nodes']==resolved['nodes']
assert parent['root_ids']==resolved['root_ids']
assert parent['source_gaps']==resolved['source_gaps']
assert parent['alternative_routes']==resolved['alternative_routes']
for old,new in zip(parent['edges'],resolved['edges']):
    assert old['id']==new['id']
    assert old['prerequisites']==new['prerequisites']
    assert old['target']==new['target']
    assert old['edge_semantics']==new['edge_semantics']
    assert old['consumer_use_sites']==new['consumer_use_sites']
    assert [c['id'] for c in old['conditional_discharge']]==[c['id'] for c in new['conditional_discharge']]
    for oc,nc in zip(old['conditional_discharge'],new['conditional_discharge']):
        assert oc['source_mathematical_discharge']==nc['source_mathematical_discharge']
        assert oc['proposed_provider']==nc['proposed_provider']

dump('source-graph.resolved.json',resolved)
# Exact byte copies are used only for the small closures. Large coverage and sealed signatures
# remain inherited by immutable hash references, never reauthored or reinterpreted here.
root_bytes=(P2/'root-closures.json').read_bytes()
assert not (P3/'root-closures.unchanged.json').exists()
(P3/'root-closures.unchanged.json').write_bytes(root_bytes)
inherited={}
for name in ['coverage-inventory.json','root-closures.json','seal-projection.json','inputs/statement-seal-v2.json','inputs/multivariateGaussian-standard-definition.txt']:
    b=(P2/name).read_bytes()
    inherited[name]=dict(parent_path='phase2/'+name,sha256=sha(b),bytes=len(b),unchanged=True)

def string_leaves(x,p=''):
    if isinstance(x,dict):
        for k,v in x.items():yield from string_leaves(v,p+'/'+str(k).replace('~','~0').replace('/','~1'))
    elif isinstance(x,list):
        for i,v in enumerate(x):yield from string_leaves(v,p+'/'+str(i))
    elif isinstance(x,str):yield p,x

# Review each covariance-related field by mathematical role, including occurrences that are
# already correct. Formula-only moment statements are separately protected by node equality.
semantic=[]
changed={c['pointer']:c for c in changes}
for p,v in string_leaves(parent):
    if not any(s in v.lower() for s in ['covariance','inverse-precision','inverse precision']):continue
    after=at(resolved,p)
    if p in changed:
        assessment=changed[p]['reason']
        status='CORRECTED_ACTIVE_CONDITION_OR_MECHANISM'
    elif p=='/terminology':
        assessment='First two clauses state precision Lambda, covariance Lambda^-1, sqrt(Lambda^-1) correctly. The later phrase refers historically to frozen phase1 wording and is not an active covariance identity. Preserved verbatim.'
        status='CORRECT_EXPLICIT_IDENTITY_AND_HISTORICAL_NOTE'
    elif p.endswith('/id') or '/prerequisites/' in p:
        assessment='Stable source-node identifier, not a matrix equality or an extra premise.'
        status='IDENTIFIER_UNCHANGED'
    elif 'diagonal inverse entry is lambda_i^-1' in v:
        assessment='The inverse is of the source precision Lambda, as fixed by the claim and the corrected C-inverse condition; its diagonal inverse entry lambda_i^-1 is exactly covariance diagonal. Preserved.'
        status='CORRECT_PRECISION_INVERSE_ENTRY'
    elif 'inverse-precision law' in v:
        assessment='The law is centered with covariance equal to inverse precision Lambda^-1, matching the fixed constructor and source N(0,Lambda^-1). Preserved.'
        status='CORRECT_INVERSE_PRECISION_LAW'
    elif 'covariance' in v:
        assessment='Covariance refers to Lambda^-1 (or A^-1 in the standing precision convention), or to the generic zero-mean covariance/variance identity. No active statement identifies inverse covariance with diag(lambda_i^-1). Preserved.'
        status='CORRECT_COVARIANCE_STATEMENT'
    else:
        assessment='Inverse precision is the covariance; this is the correct standing target convention. Preserved.'
        status='CORRECT_INVERSE_PRECISION_CONVENTION'
    semantic.append(dict(pointer=p,before=v,after=after,assessment=status,mathematical_readback=assessment))

bad=[]
for p,v in string_leaves(resolved):
    if ('inverse covariance' in v.lower() or 'inverse-covariance' in v.lower()) and p!='/terminology':bad.append((p,v))
assert not bad,bad
assert all(at(resolved,p)==inverse_new for p in [c['pointer'] for c in changes if c['before']==inverse_old])
assert all(at(resolved,p)==l2_new for p in [c['pointer'] for c in changes if c['before']==l2_old])

overlay=dict(schema_version=1,kind='TYPED_CONDITION_TERMINOLOGY_CLARIFICATION_SUCCESSOR',
  state='PENDING_DISTINCT_REVIEW; no self-admission or source verification',
  scope='Nine exact JSON string replacements only. This corrects a false/ambiguous prose subject; it is not a proof, new mathematical target, new formula, or structural graph change.',
  parent_freeze=dict(path='phase2/FREEZE.json',sha256=expected_parent_freeze),
  parent_graph=dict(path='phase2/source-graph.json',sha256=expected_parent_graph),
  resolved_graph=dict(path='phase3/source-graph.resolved.json',sha256=sha((P3/'source-graph.resolved.json').read_bytes())),
  replacements=changes,inherited_unchanged=inherited,
  fixed_mathematical_identity='Precision Lambda=diag(lambda_i); covariance Lambda^-1=diag(lambda_i^-1); sqrt(Lambda^-1) is used in the sealed standard Gaussian realization.',
  implementation_lean_read=False,API_search=False,proof_or_build=False)
dump('condition-clarification-overlay.json',overlay)
dump('semantic-occurrence-readback.json',dict(schema_version=1,scope='Every parent graph string field containing covariance or inverse-precision terminology, not a blind replacement.',
  total=len(semantic),active_bad_inverse_covariance_occurrences_after_resolution=0,
  records=semantic,readback_status='EXTRACTOR_READBACK_ONLY; independent reviewer must accept or hold.'))
dump('unchanged-boundary-verification.json',dict(schema_version=1,status='PASS_EXACT_DIFF_AND_BOUNDARY_CHECKS_ONLY',
  parent_freeze_sha256=expected_parent_freeze,parent_graph_sha256=expected_parent_graph,
  exact_changed_JSON_pointers=[c['pointer'] for c in changes],exact_changed_field_count=len(diff),
  unchanged=dict(all_38_node_records=True,all_28_edge_IDs=True,prerequisites_targets_hyperedge_semantics=True,
    consumer_use_sites=True,guard_IDs_providers_and_mathematical_discharge=True,
    root_IDs_and_source_gap_IDs=True,all_original_formula_bearing_node_claims=True,
    source_raw_and_phase1_freeze=True,phase2_freeze_and_all_members=True,
    sealed_literal_signatures_and_meanings=True,coverage_and_dispositions=True,
    root_closure_bytes=sha(root_bytes)==sha((P3/'root-closures.unchanged.json').read_bytes())),
  inherited_hashes=inherited,
  proof_credit=False,independent_review_status='PENDING'))

print(json.dumps(dict(replacements=len(diff),semantic_readback_fields=len(semantic),
  parent_graph_sha256=expected_parent_graph,resolved_graph_sha256=sha((P3/'source-graph.resolved.json').read_bytes()),
  root_closure_sha256=sha(root_bytes),state='READY_FOR_DISTINCT_REVIEW_NOT_SELF_ACCEPTED'),indent=2))
