from pathlib import Path
from html.parser import HTMLParser
import hashlib
import json

ROOT = Path('.astis/semantic-neutral-20261111/r4_sg_55d8')
OUT = Path('.astis/semantic-neutral-20261111/r4_tc_d390')
SOURCE = Path('.astis/huanjian-resume-20261103/2610.20492v1.html')

def sha(b):
    return hashlib.sha256(b).hexdigest()

checks = {}
bound_inputs = []
for rel, expected in [
    ('evidence-manifest.json', '32fb1c7a85b209dab52ab69c8f73f009bf623a6b9af91c0a84418191d234d802'),
    ('typed-overlay-v1/typed-overlay-manifest.json', 'bc82c04245246b7101d494dd09cbbdd0170d69bccdd41420f82a23a7649468ff'),
    ('typed-overlay-v1/proof-component-graph.json', '565f6dfbe1eec3c4975a1e2dd9765b129abe282f1ea65ff28890afede92ba47f'),
]:
    b = (ROOT / rel).read_bytes()
    assert sha(b) == expected, rel
    bound_inputs.append({'path': str(ROOT / rel), 'bytes': len(b), 'sha256': sha(b)})

artifact_counts = {}
for rel in ['evidence-manifest.json', 'typed-overlay-v1/typed-overlay-manifest.json']:
    manifest_path = ROOT / rel
    manifest = json.loads(manifest_path.read_text())
    for row in manifest['content_artifacts']:
        b = (manifest_path.parent / row['path']).read_bytes()
        assert len(b) == row['bytes'] and sha(b) == row['sha256'], row['path']
    artifact_counts[rel] = len(manifest['content_artifacts'])
checks['manifest_artifact_hashes'] = artifact_counts

raw = SOURCE.read_bytes()
source = raw.decode()
assert len(raw) == 951991
assert sha(raw) == '6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
locators = json.loads((ROOT / 'locators.json').read_text())
locator_count = 0
for category in ['windows', 'atomic_items', 'structural_containers', 'all_math_locators']:
    for row in locators[category]:
        lo, hi = row['utf8_byte_range_zero_based_half_open']
        clo, chi = row['char_range_zero_based_half_open']
        b = raw[lo:hi]
        s = source[clo:chi]
        assert b == s.encode(), (category, row.get('id', row.get('item')))
        assert len(b) == row['utf8_bytes']
        assert len(s) == row['unicode_codepoints']
        assert s.count('\n') == row['lf_count']
        assert sha(b) == row['sha256_raw_utf8']
        assert [source.count('\n', 0, clo) + 1, source.count('\n', 0, chi) + 1] == row['lf_lines_one_based_inclusive']
        assert clo - (source.rfind('\n', 0, clo) + 1) == row['start_column_zero_based_char']
        assert chi - (source.rfind('\n', 0, chi) + 1) == row['end_column_zero_based_char_exclusive']
        locator_count += 1
checks['independently_rehashed_locator_records'] = locator_count

class Node:
    def __init__(self, tag, attrs, start):
        self.tag, self.attrs, self.start, self.end = tag, dict(attrs), start, None

class Parser(HTMLParser):
    def __init__(self, text):
        super().__init__()
        self.text = text
        self.line_offsets = [0]
        self.line_offsets.extend(i + 1 for i, c in enumerate(text) if c == '\n')
        self.stack, self.nodes, self.ids = [], [], {}
    def position(self):
        line, column = self.getpos()
        return self.line_offsets[line - 1] + column
    def handle_starttag(self, tag, attrs):
        n = Node(tag, attrs, self.position())
        self.nodes.append(n)
        if 'id' in n.attrs:
            assert n.attrs['id'] not in self.ids
            self.ids[n.attrs['id']] = n
        if tag in {'area', 'base', 'br', 'col', 'embed', 'hr', 'img', 'input', 'link', 'meta', 'param', 'source', 'track', 'wbr'}:
            n.end = n.start + len(self.get_starttag_text())
        else:
            self.stack.append(n)
    def handle_endtag(self, tag):
        for i in range(len(self.stack) - 1, -1, -1):
            if self.stack[i].tag == tag:
                self.stack[i].end = self.text.index('>', self.position()) + 1
                del self.stack[i:]
                return

parser = Parser(source)
parser.feed(source)
coverage = json.loads((ROOT / 'coverage.json').read_text())
membership = json.loads((ROOT / 'math-membership.json').read_text())
windows = [parser.ids[key] for key in coverage['bounded_windows']]
nodes = [n for n in parser.nodes if n.end is not None and any(w.start <= n.start and n.end <= w.end for w in windows)]
math_ids = {n.attrs['id'] for n in nodes if n.tag == 'math'}
dom_ids = {n.attrs['id'] for n in nodes if 'id' in n.attrs}
atoms = [n for n in nodes if n.tag in {'p', 'table', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6'}]
assert len(atoms) == coverage['atomic_count'] == len(coverage['items'])
assert len(math_ids) == coverage['math_count'] == membership['count']
assert len(dom_ids) == coverage['dom_id_count']
assert {m['id'] for m in membership['members']} == math_ids
assert len(membership['members']) == len(math_ids)
owners = {}
all_covered_dom = []
for item in coverage['items']:
    assert item['disposition'] in {'NODE', 'EXCLUDED'}
    all_covered_dom.extend(item['member_dom_ids'])
    for m in item['math_members']:
        assert m['id'] not in owners
        owners[m['id']] = item['item']
        assert parser.ids[m['id']].attrs['alttext'] == m['alttext']
for structural in locators['structural_containers']:
    all_covered_dom.append(structural['id'])
assert len(all_covered_dom) == len(set(all_covered_dom))
assert set(all_covered_dom) == dom_ids
assert set(owners) == math_ids
for m in membership['members']:
    assert m['owner'] == owners[m['id']]
    assert m['alttext'] == parser.ids[m['id']].attrs['alttext']
checks['independent_bounded_source_partition'] = {'atoms': len(atoms), 'math_ids': len(math_ids), 'dom_ids': len(dom_ids), 'unique_ownership': True}

closure_summary = {}
for rel in ['source-graph.json', 'typed-overlay-v1/proof-component-graph.json']:
    graph = json.loads((ROOT / rel).read_text())
    by_id = {n['id']: n for n in graph['nodes']}
    assert len(by_id) == len(graph['nodes'])
    expected_edges = {(p, n['id']) for n in graph['nodes'] for p in n['prerequisites']}
    actual_edges = {(e['from'], e['to']) for e in graph['edges']}
    assert expected_edges == actual_edges
    assert len(actual_edges) == len(graph['edges'])
    done, active = set(), set()
    def closure(root):
        found = set()
        def visit(n):
            assert n in by_id and n not in active
            if n in found:
                return
            active.add(n)
            for parent in by_id[n]['prerequisites']:
                visit(parent)
            active.remove(n)
            found.add(n)
        visit(root)
        return found
    rows = []
    if 'complete_expanded_root_closures' in graph:
        expanded = {row['root']: row for row in graph['complete_expanded_root_closures']}
        assert set(expanded) == set(graph['roots'])
        for root in graph['roots']:
            found = closure(root)
            row = expanded[root]
            assert set(row['node_ids']) == found
            assert len(row['node_ids']) == len(found)
            assert {n['id'] for n in row['complete_expanded_nodes']} == found
            assert len(row['complete_expanded_nodes']) == len(found)
            for n in row['complete_expanded_nodes']:
                assert n == by_id[n['id']]
            edges = {(e['from'], e['to']) for e in row['complete_edges']}
            assert edges == {(a, b) for a, b in actual_edges if a in found and b in found}
            assert set(row['terminal_leaves']) == {n for n in found if not by_id[n]['prerequisites']}
            rows.append({'root': root, 'nodes': len(found), 'edges': len(edges)})
    else:
        for root in graph['roots']:
            found = closure(root)
            assert set(graph['complete_backward_closures'][root]) == found
            rows.append({'root': root, 'nodes': len(found)})
    closure_summary[rel] = {'nodes': len(by_id), 'edges': len(actual_edges), 'acyclic': True, 'roots': rows}
checks['independently_recomputed_graph_closures'] = closure_summary

for manifest_name in ['RAW_FREEZE_HASHES.json']:
    for row in json.loads((OUT / manifest_name).read_text()):
        b = Path(row['path']).read_bytes()
        assert len(b) == row['bytes'] and sha(b) == row['sha256']
prior_type = json.loads((OUT / 'TYPE_ONLY_FREEZE_METADATA.json').read_text())
assert sha(Path(prior_type['report']).read_bytes()) == prior_type['report_sha256']
checks['prior_freezes_preserved'] = True

result = {'status': 'all-independent-structural-checks-pass', 'authority': 'Structural evidence only; mathematical source/topology judgment is in TOPOLOGY_CHALLENGE.md. No proof or process grant.', 'bound_inputs': bound_inputs, 'checks': checks}
(OUT / 'TOPOLOGY_STRUCTURAL_CHECK.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(result, ensure_ascii=False, indent=2))
