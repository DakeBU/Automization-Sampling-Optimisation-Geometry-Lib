# Independent source mathematics — Phase 1

This is an unformalized reconstruction from the pinned source only. No Lean, target signature, statement seal, previous verdict, ledger, API, Git state, or network source was used. It proves no source theorem and supplies no semantic-verifier transition. All mathematical explanations below remain subject to independent source/topology review and any later formalization.

Source: *On Complexity of Gaussian Sampling*, arXiv HTML 2610.20492v1, raw SHA256 `6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915`. The raw file has 951991 bytes, 942139 Unicode codepoints, and 4269 LF characters, with no CR. Exact source ranges, excerpt bytes and span hashes are in `anchored-excerpts.json` and the atomic inventory. Raw anchors are 0-based, end-exclusive Unicode codepoint/raw UTF-8 intervals; LF lines are 1-based.

## Declared slice and meaning

The closed coverage containers are Section 4.1 (`S4.SS1`), Section 4.2's Krylov and uniform-bound subsections (`S4.SS2.SSS0.Px1`, `S4.SS2.SSS0.Px2`), and the whole Appendix C.2 (`A3.SS2`). Every paragraph, mathematical formula, equation wrapper, theorem/proof wrapper, citation/reference, and heading in those containers is inventoried as NODE or EXCLUDED with a reason. Nested inventory rows are textual coverage, not extra proof dependencies. C.1/C.3/C.4, other Section 4 subsections and the rest of the paper are outside this slice. The only bibliography expansion is source entry `bib.bib3`, cited as [22] by the selected setup.

The selected scalar spine comprises the actual standard-Gaussian radial exponential moment, the literal truncation level, the one-row tail and truncated first-moment bias, and the way their failure budget is used. C.5, the full C.6 concentration theorem and full Lemma 4.4 are separately excluded conclusions. Their relevant source use sites are recorded as downstream context, without importing those theorems as parents of the scalar estimates.

## Objects, carriers, laws and constants

Section 4.1 uses integer dimension d≥2 and κ≥2, θ_i=(i−1/2)π/d, λ_i=(κ+1)/2+(κ−1)cos(θ_i)/2, Λ=diag(λ_i), 1≤i≤d. A Haar orthogonal O independent of algorithm randomness defines A=OΛOᵀ, potential xᵀAx/2 and target N(0,A⁻¹). These precision/target objects are context, not the Gaussian row law.

The standing query parameter is an integer q≥0 with 2q+1<d. There are q+1 independent starter vectors g_a∼N(0,I_d), indexed 1≤a≤q+1. Lemma 4.3's output representation is contextual; its proof is not part of the scalar moment argument. Lemma 4.4 restates the same starter law directly, so one need not derive it from the algorithm representation theorem.

Appendix C.2 sets r=q+1 and n=2q+1. Thus r≥1; because q,d are integers, 2q+1<d implies 2r≤d and d≥2. For each i=1,…,d,

  t_i=(1,√2 cosθ_i,…,√2 cos(qθ_i))ᵀ∈ℝ^r,
  γ_i=((g_1)_i,…,(g_r)_i)ᵀ∈ℝ^r.

The source states the γ_i are independent N(0,I_r). The selected moment needs only the single-row marginal law γ_i∼N(0,I_r); independence across i is required later for matrix concentration, not for the moment, single-row Markov bound, layer cake, or union bound. Within-vector independent standard coordinates are a characterization of N(0,I_r), used only in the optional product proof of the Gaussian integral.

B is d×r², with i-th row d^(−1/2)(γ_i⊗t_i)ᵀ. The selected random variable is R_i=‖γ_i‖²=Σ_{a=1}^r(g_a)_i², with no dimension normalization. The squared norm of the row of B would be d^(−1)R_i‖t_i‖² and is a different quantity. The moment has variance-one Gaussian coordinates, exponent coefficient exactly 1/3, and real exponent r/2 on the base 3. It is not an exponential linear moment, not a tail premise, and not a moment of the target N(0,A⁻¹).

The literal threshold is L=2r+3log(1000d), with natural logarithm. No replacement by 2r+3log d or an asymptotic threshold is permitted. Since d≥2 and r≥1, log(1000d)>0 and L>0. The endpoint q=0 is included: r=1, n=1, t_i=(1), B is d×1, and E exp(R_i/3)=√3. No division by q occurs. A zero-dimensional r=0 generalization is outside this source slice; in particular the later definition of a divides by r.

## The moment and its omitted background

At `A3.SS2.p10.m3` the source says exactly E exp(R_i/3)=3^(r/2), introduced by “Since”; it supplies no Gaussian-integral calculation or explicit integrability proof. This is a source assertion whose proof is background, not an allowed extra theorem hypothesis.

One explicit reconstructed background route uses the N(0,I_r) density (2π)^(−r/2)exp(−‖z‖²/2) on ℝ^r. Multiplying by exp(‖z‖²/3) leaves (2π)^(−r/2)exp(−‖z‖²/6). The substitution z=√3 y has Jacobian 3^(r/2) and leaves the normalized standard-Gaussian integral. This also establishes finite integrability, since the residual quadratic exponent is negative. Its prerequisites are the literal standard-Gaussian density/normalization, measurable squared Euclidean norm and exponential, and the Lebesgue scaling formula. None is assumed as the moment itself.

An alternative background route factors E exp((Σ_a Z_a²)/3) into the product of r one-dimensional Gaussian integrals. Each integral is √3, and their product is (√3)^r=3^(r/2). Nonnegative Tonelli/product integration can be used before finiteness is known; the computation then yields finiteness. This route uses coordinate independence, not independence across rows. The density/scaling route and the coordinate-product route are OR alternatives; they must not be flattened into a combined list of necessary parents. Neither detailed route is claimed to be literally written in the paper.

Other implicit regularity consists of Borel measurability of R_i and the exponential, nonnegativity, and a probability law under which the expectation is taken. The finite exponential expectation is derived by the Gaussian computation. A certificate of that expectation or a tail bound must not become a public premise merely because a provider lemma exists.

## Markov, numerical comparison, and literal probability use

For a fixed i and every real x≥0, exp(R_i/3)>0 is measurable and integrable, and exp((2r+3x)/3)>0. Strict monotonicity of exp identifies {R_i>2r+3x} with the corresponding strict exponential event. Markov therefore gives

  P(R_i>2r+3x) ≤ exp(−2r/3−x) E exp(R_i/3)
                    = exp((r/2)log3−2r/3−x) ≤ exp(−x).

The source explicitly uses (log3)/2<2/3. The last step also uses r≥0. A possible background justification is exp(4/3)>1+4/3+(4/3)²/2=29/9>3, followed by monotonicity/inversion of log and exp. This is not an additional source assumption. The source states the range x≥0 even though some analytical extensions are possible; this reconstruction preserves that range and the strict tail event.

Substitute x=log(1000d)≥0: P(R_i>L)≤1/(1000d). Define T={R_i≤L for every i=1,…,d}. Its complement is the union of the d strict-tail events. A finite union bound yields P(T)≥1−d/(1000d)=0.999. No row independence is needed. This is the source's untruncated/truncated-agreement event.

For every real s≥0, use x=log(1000d)+s/3≥0. Because 2r+3x=L+s,

  P(R_i>L+s) ≤ exp(−s/3)/(1000d).

The source then displays the tail integral identity

  E[R_i 1_{R_i>L}]
    = L P(R_i>L)+∫₀^∞P(R_i>L+s)ds
    ≤ (L+3)/(1000d).

The omitted bridge is layer cake/Tonelli: for R_i≥0 and L≥0, pointwise R_i1_{R_i>L}=L1_{R_i>L}+(R_i−L)_+, and (R_i−L)_+=∫₀^∞1_{R_i>L+s}ds. All terms are nonnegative, so this identity is valid in the extended sense before integrability is established. The exponential bound gives the finite right side, using ∫₀^∞exp(−s/3)ds=3. The strict/weak split at L is exactly retained; no assertion of a zero-probability boundary is needed.

At `A3.SS2.p12`, the source states E R_i=r. This uses standard-Gaussian second moments, a separate background fact. With a=(1/r)E[R_i1_{R_i≤L}], r>0 and the complementary-indicator split give 0≤a≤1 and

  1−a=(1/r)E[R_i1_{R_i>L}]≤(L+3)/(1000rd).

Equal single-row laws make a the same for each i; independence is unnecessary. Radial symmetry is a distinct downstream step identifying E[γ_iγ_iᵀ1_{R_i≤L}]=aI_r. It is not needed to compute the scalar exponential moment or tail expectation. Its integrability is supported by E‖γ_i‖²=r, and its scalar identification follows by taking the trace. Source use of this covariance identity and C.5 produces the expectations of the truncated matrix sums; that matrix branch is recorded separately.

## Consumer topology and excluded neighboring obligations

The one-row tail produces two distinct consumers: the event T with failure ≤0.001, and the scalar tail expectation producing bias 1−a. Neither consumer depends on C.5, Gaussian fourth moments, or matrix Bernstein.

Independently, C.6's excluded matrix branch constructs independent centered self-adjoint Z_i and cos(nθ_i)Z_i, with summand bound R_*=2r(L+1)/d and variance bound v_*=2r(r+2)/d. The variance calculation uses Gaussian fourth moments E[R_iγ_iγ_iᵀ]=(r+2)I_r; it is separate from the selected exponential moment. Two-sided bounded matrix Bernstein, followed by z=log(1000r²) and Δ=√(2v_*z)+2R_*z/3, gives failure ≤0.002 for each matrix bound and ≤0.004 jointly. The source does not attach a bibliography citation to this named Bernstein inequality. This reconstruction records its name/use, not its proof or formal validity.

At `A3.SS2.p17`, on T the original and truncated sums agree. Using the separate expectation identities, BᵀB−I=ΣZ_i−(1−a)I and BᵀD_nB=Σcos(nθ_i)Z_i. Intersect T with the two matrix-concentration events by a union bound: failure ≤0.001+0.004=0.005, success ≥0.995; no independence of these events is claimed. The scalar bias enters the unweighted norm as Δ+(1−a), while the weighted expectation is zero. This is the precise downstream probability/bias use, not an additional premise of the scalar moment.

The remaining constant absorption into τ_{d,q}, the full C.6 conclusion, and the full uniform Lemma 4.4 (including τ≤1/2 and 0.995≥0.99) are separately excluded source obligations. C.5's range(B)=K_q, cosine orthogonality and matrix expectation identities are separately inventoried/excluded. Their results, the Haar/deferred-rotation proof, O, κ, target moments, and output representation are never false AND parents of E exp(R_i/3), the one-row tail or its scalar bias.

## Limits and review status

The graph records source assertions, omitted background bridges, exact use sites, and explicit exclusions. It does not self-approve source coverage, certify a target type, prove C.5/C.6/Lemma 4.4, or assert any compiler result. No source invalidity/counterexample was established. The Gaussian integral, numerical comparison, measure-theoretic bridges, and marginal-law reconstruction are visible obligations/background expansions rather than hidden assumptions. Phase 2, if supplied later, may compare selected types with this already frozen source mathematics; it must not retroactively change these bytes.
