from __future__ import annotations

import copy
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

from bs4 import BeautifulSoup

ROOT = Path('/Users/zhouhuanjian/ASTIS-GC')
WORK = ROOT / '.astis/huanjian-gc-fixed-spectrum-geometry-20261109/topology-challenger'
OUT = ROOT / 'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-geometry-semantic-evidence/topology-challenge/phase1'
SOURCE = ROOT / '.astis/huanjian-resume-20261103/2610.20492v1.html'
EXPECTED = '6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'


def dump(path: Path, data: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')


def digest(path: Path) -> dict:
    raw = path.read_bytes()
    return {'path': str(path.relative_to(ROOT)), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


source_bytes = SOURCE.read_bytes()
assert len(source_bytes) == 951991
assert hashlib.sha256(source_bytes).hexdigest() == EXPECTED
OUT.mkdir(parents=True, exist_ok=True)
(OUT / 'raw-source').mkdir(exist_ok=True)
(OUT / 'raw-source/2610.20492v1.html').write_bytes(source_bytes)

instructions = [
    'AGENTS.md',
    'docs/contributor-codex-contract.md',
    'docs/theorem-publication-protocol.md',
    'docs/proof-digestion-protocol.md',
    'docs/evidence-routed-memory-protocol.md',
    '.agents/skills/astis-source-dependency-audit/SKILL.md',
    '.agents/skills/astis-substantive-advance/SKILL.md',
    '.agents/skills/astis-semantic-roundtrip/SKILL.md',
]
instruction_records = []
for index, name in enumerate(instructions, 1):
    src = ROOT / name
    target = OUT / 'instructions' / f'{index:02d}-{name.replace("/", "__")}.raw'
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(src.read_bytes())
    instruction_records.append({'original': digest(src), 'frozen': digest(target)})

anchors = [
    'S2', 'S4.p1', 'S4.Thmtheorem1', 'S4.SS1', 'S4.E11',
    'S4.SS2', 'S4.Thmtheorem6', 'A3.SS4', 'bib.bib3',
]
soup = BeautifulSoup(source_bytes, 'html.parser')
anchor_records = []
for ident in anchors:
    elem = soup.find(id=ident)
    assert elem is not None, ident
    clone = copy.deepcopy(elem)
    for math in clone.find_all('math'):
        math.replace_with(' $' + math.get('alttext', math.get_text(' ', strip=True)) + '$ ')
    text = clone.get_text(' ', strip=True) + '\n'
    path = OUT / 'source-text' / f'{ident}.txt'
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text)
    anchor_records.append({
        'anchor': ident,
        'source_path': str(SOURCE.relative_to(ROOT)),
        'source_sha256': EXPECTED,
        'derived_text': digest(path),
        'derivation': 'BeautifulSoup DOM text; MathML replaced by source math alttext. Exact authority is frozen full original HTML, not this derived text.',
    })

exposure = {
    'phase': 'phase1-source-only',
    'role': 'different-role mathematical source topology / binder / definition challenger',
    'direction_fingerprint': 'raw-source-first-geometry-domains-quantifiers-definition-and-consumer-challenge',
    'allowed_source': digest(SOURCE),
    'instruction_snapshots': instruction_records,
    'additional_process_document_access': [
        {
            **digest(ROOT / 'docs/companion-papers-handoff.md'),
            'exposure': 'AGENTS-required handoff command accessed the file; tool output was truncated. This is historical process handoff, not geometry-task seal, raw-interface packet, author rationale, extractor proposal, or geometry implementation.',
            'used_for_mathematical_cognition': False,
        }
    ],
    'other_accesses': [
        'Filename-only rg inventories were broader than needed; no listed paper-contribution proof capsule was opened.',
        'Checked ancestor AGENTS locations; no ancestor AGENTS file was returned.',
        'Checked task-owned and instruction paths for nested AGENTS; none returned.',
        'System python3 lacks bs4; used already installed /opt/anaconda3/bin/python for local source parsing. No package install or network action.',
        'Read raw source context S4.SS2 and main Theorem 4.1 solely to identify local-versus-global boundaries; their proof obligations are not claimed by this phase.',
        'Read bib.bib3 within pinned HTML solely as citation identity/provenance; no OpenAI source package or theorem was used.',
    ],
    'unseen_before_freeze': [
        'new statement-seal', 'raw-interface packet', 'root preseal rationale',
        'root exposure/reuse audit', 'source extractor proposal or private rationale',
        'Gaussian implementation Lean', 'geometry-task README/proof capsules',
    ],
    'forbidden_actions_performed': [],
    'source_topology_verdict': None,
    'verification_or_SAU_claim': None,
    'next_authorized_input': 'Only after this freeze: independently frozen extractor graph and exact raw interfaces/standard definitions, without author/extractor private rationale.',
}
dump(OUT / 'exposure.json', exposure)
dump(OUT / 'source-anchors.json', anchor_records)

inventory = [
    ('CTX-EUCLIDEAN-LOEWNER', 'S2.p1', 'NODE', 'Euclidean norm, identity and Loewner order on symmetric real matrices; semantic standing context.'),
    ('CTX-FULL-ORTHOGONAL', 'S2.p2', 'NODE', 'Full real O(d), O^T O=I; determinant signs +1 and -1 both retained. Haar/component laws are probabilistic context, not deterministic geometry premises.'),
    ('DEF-PRECISION-CLASS', 'S2.Ex1', 'NODE', 'Symmetric precision class with I <= A <= kappa I, d>=1, kappa>=1 in preliminaries.'),
    ('DEF-S2-POTENTIAL-TARGET', 'S2.SS0.SSS0.Px1.p1', 'NODE', 'Literal f_A(x)=x^T A x/2 and target N(0,A^-1), before the actual hard-family restriction.'),
    ('DEF-EXACT-FO', 'S2.E1', 'NODE', 'Exact ordered value/gradient response (x^T A x/2, A x), codomain R x R^d.'),
    ('CTX-ORACLE-EQUIVALENCE', 'S2.SS0.SSS0.Px1.p2', 'EXCLUDED', 'One-query value-gradient / gradient-only / matrix-vector conversion is separate query-accounting mathematics; retain exact formula as context but no complexity-equivalence credit here.'),
    ('CTX-BOREL-ALGORITHMS', 'S2.SS0.SSS0.Px2.p1', 'NODE', 'Borel query/stop/output rules, seed independent of input. Fixed-input actual oracle measurability is the bounded bridge relevant here.'),
    ('CTX-TV', 'S2.SS0.SSS0.Px3.p1;S2.Ex2', 'EXCLUDED', 'TV definition and [0,1] test inequality are downstream accuracy context, not geometry or oracle-measurability conclusions.'),
    ('CTX-QUERY-COMPLEXITY', 'S2.SS0.SSS0.Px4.p1;S2.E2', 'EXCLUDED', 'Uniform output-law accuracy and deterministic per-run query caps remain global algorithm obligations; no expected-query statement is inferred.'),
    ('CTX-HARD-FAMILY-PROVENANCE', 'S4.SS1.p1;bib.bib3', 'EXCLUDED', 'Citation [22, Section 9.2] describes construction provenance. C.4 local polynomial/spectral argument does not invoke an external theorem from that citation.'),
    ('DEF-COSINE-GRID', 'S4.E11', 'NODE', 'Exact one-based angles, affine cosine eigenvalues and diagonal Lambda, with d>=2 and kappa>=2 inherited from S4.SS1.p1.'),
    ('DEF-HARD-PRECISION', 'S4.SS1.p1', 'NODE', 'A=O Lambda O^T and actual potential f_A; every real orthogonal O is relevant to deterministic geometry.'),
    ('CTX-HARD-RANDOMNESS', 'S4.SS1.p1', 'NODE', 'Haar O independent of algorithm seed defines the hard input distribution; it must not weaken every-O deterministic conclusions to almost sure ones.'),
    ('CTX-PUBLIC-SPECTRUM', 'S4.SS1.p2', 'NODE', 'Spectrum deterministic/public and normalizer known; local geometry does not establish the normalizer calculation by itself.'),
    ('REMARK-AFFINE-KAPPA-COMPARISON', 'S4.Thmtheorem2.p1', 'EXCLUDED', 'A=(kappa-1) A_2-(kappa-2)I and reply conversion are separate comparison route, unnecessary for C.4 geometry.'),
    ('REMARK-COSINE-STATISTIC-HARDNESS', 'S4.Thmtheorem2.p1', 'EXCLUDED', 'Algorithm-versus-target cosine test, Krylov and target moments, and sqrt(kappa) lower-bound factor are independent main-theorem obligations.'),
    ('ANCHOR-ADMISSIBILITY', 'S4.Thmtheorem6', 'NODE', 'For every O in full O(d), the source A has I <= A <= kappa I.'),
    ('PROOF-STRICT-ANGLE-COSINE-SPECTRUM', 'A3.SS4.p1', 'NODE', '0<theta_i<pi -> -1<cos(theta_i)<1 -> 1<lambda_i<kappa; strict intermediate estimates use actual hard-family parameter range.'),
    ('PROOF-ORTHOGONAL-LOEWNER', 'A3.SS4.p1', 'NODE', 'Real diagonal bounds transported by orthogonal conjugation produce Loewner admissibility, with implicit symmetry/isometry algebra made visible.'),
    ('PROOF-CINFINITY-HESSIAN', 'A3.SS4.p2', 'NODE', 'Literal V_A is C-infinity on all R^d; Hessian at every x is A. V_A is the same literal potential as f_A.'),
    ('PROOF-STRONG-CONVEX-SMOOTH', 'A3.SS4.p2', 'NODE', 'From Hessian bounds derive global 1-strong convexity and kappa-smoothness with Euclidean conventions.'),
    ('PROOF-ORIGIN-GAP-UNIQUE', 'A3.SS4.p2', 'NODE', 'V_A(0)=0; V_A(x)>=||x||^2/2>0 for x!=0; hence origin is unique global minimizer.'),
    ('CTX-C4-TARGET-NORMALIZER', 'A3.SS4.p3;A3.Ex160', 'EXCLUDED', 'The associated Gaussian and exact Gaussian integration/determinant-invariance/public-normalizer conclusion are recorded source content but separate from this geometry/oracle-measurability target; no new normalizer proof credit.'),
    ('CTX-S4-OTHER-LEMMAS', 'S4.SS2', 'EXCLUDED', 'Read as consumer context only. Lemmas 4.3-4.5 and their Appendix C.1-C.3 proofs are not prerequisites of the C.4 deterministic geometry branch.'),
    ('CTX-MAIN-LOWER-BOUND', 'S4.Thmtheorem1;S4.p1', 'EXCLUDED', 'Main theorem dimension threshold, delta, upper kappa growth, epsilon range and query lower bound are outside this local slice and cannot become extra local binders.'),
]

expected = {
    'status': 'SOURCE_COGNITION_FROZEN_AWAITING_PHASE2',
    'source_identity': {'title': 'On Complexity of Gaussian Sampling', 'version': 'arXiv:2610.20492v1', 'sha256': EXPECTED, 'bytes': 951991},
    'inventory': [{'id': i, 'anchor': a, 'disposition': d, 'reason_or_content': r} for i,a,d,r in inventory],
    'objects_domains_quantifiers': [
        'd is an integer with d>=2 and kappa is a real scalar with kappa>=2 for the actual S4.SS1 family; do not import main-theorem delta/d0/kappa<=d^(1-delta)/epsilon assumptions.',
        'i ranges over source indices 1,...,d. For zero-based Fin d, theta_i must be ((i+1/2)*pi)/d, after real coercion; not ((i-1/2)*pi)/d.',
        'theta_i=((i-1/2)*pi)/d; lambda_i=(kappa+1)/2+(kappa-1)/2*cos(theta_i); Lambda=diag(lambda_1,...,lambda_d).',
        'O is any real square orthogonal matrix O^T O=I. Both determinant signs are included. No SO(d), det=+1, genericity, Haar-almost-sure or random-isotropy restriction is justified for the deterministic local results.',
        'A=O Lambda O^T; A is symmetric, positive definite, invertible, and I<=A<=kappa I as conclusions/dependency facts, never convenience public assumptions on the fixed hard family.',
        'The public potential is literally V_A=f_A:x in Euclidean R^d -> (1/2)*x^T A x on the whole space; x and y are arbitrary, not almost everywhere or in a bounded set.',
        'C-infinity means all finite Frechet derivative orders with continuity on the whole Euclidean space. Hessian is the Euclidean x-Hessian, not derivative in O or A.',
        'Hessian equality is pointwise for every x; as a bilinear form it sends (h,k) to <h,A k>, and as a Euclidean linear operator it is A. Representations need a reviewed adapter.',
        'Gradient equals A x for every x. The exact first-order oracle is a map x -> (V_A(x),A x) into R x R^d with standard product Borel structure, for each fixed admissible source input.',
        'Strong convexity constant is exactly the valid lower bound 1; smoothness constant exactly the valid upper bound kappa. They are uniform in O and x,y, with no unspecified d/O-dependent multiplier.',
        'The unique minimizer is exactly 0 over all R^d: V_A(0)=0, V_A(x)>=||x||^2/2, and x!=0 implies V_A(x)>0.',
        'Generalizations to d=1 or kappa>=1 may be true but must be identified as generalizations. In particular kappa=1 removes strict 1<lambda_i<kappa and cannot inherit that strict source proof.',
    ],
    'expected_source_bridges': [
        {'id': 'B01', 'at': 'A3.SS4.p1', 'class': 'internal-paper-step', 'obligation': 'Discharge index/denominator/coercion positivity to prove 0<theta_i<pi from the actual source grid.'},
        {'id': 'B02', 'at': 'A3.SS4.p1', 'class': 'internal-paper-step', 'obligation': 'Use cosine strict range on (0,pi) and kappa-1>0 to obtain strict eigenvalue bounds.'},
        {'id': 'B03', 'at': 'A3.SS4.p1', 'class': 'local-lemma', 'obligation': 'Real diagonal Lambda is symmetric; conjugation A=O Lambda O^T is symmetric. Orthogonality on square matrices gives both O^T O=I and O O^T=I and preserves Euclidean norm.'},
        {'id': 'B04', 'at': 'A3.SS4.p1', 'class': 'local-lemma', 'obligation': 'For all z, ||z||^2<=z^T A z<=kappa||z||^2; transport diagonal sums through O^T and interpret this as Loewner inequalities.'},
        {'id': 'B05', 'at': 'A3.SS4.p2', 'class': 'internal-paper-step', 'obligation': 'The literal finite-dimensional quadratic is C-infinity. This branch needs the formula, not a random-input event or full spectral admissibility.'},
        {'id': 'B06', 'at': 'S2.E1;A3.SS4.p2', 'class': 'internal-paper-step', 'obligation': 'Differentiate the literal symmetric quadratic to get DV_A(x)[h]=<A x,h>, gradient A x, and D2 V_A(x)[h,k]=<h,A k> independent of x. Symmetry is essential to identifying Hessian as A rather than its symmetric part.'},
        {'id': 'B07', 'at': 'A3.SS4.p2', 'class': 'local-lemma', 'obligation': 'Lower Hessian/quadratic bound implies V_A(y)>=V_A(x)+<A x,y-x>+(1/2)||y-x||^2. Verify convention/factor when using a convexity predicate.'},
        {'id': 'B08', 'at': 'A3.SS4.p2', 'class': 'local-lemma', 'obligation': 'Upper spectral bound implies ||A(x-y)||<=kappa||x-y|| in Euclidean induced operator norm; hence gradient is globally kappa-Lipschitz. Do not substitute function Lipschitzness or an entrywise/Frobenius matrix norm.'},
        {'id': 'B09', 'at': 'A3.SS4.p2', 'class': 'internal-paper-step', 'obligation': 'Evaluate V_A(0); use lower quadratic bound and positivity of Euclidean norm squared off zero to derive strict positivity and unique global minimizer, with no pre-given minimizer/existence/coercivity binder.'},
        {'id': 'B10', 'at': 'S2.E1;S2.SS0.SSS0.Px2.p1', 'class': 'local-lemma', 'obligation': 'For fixed source input, actual potential is continuous (polynomial), A x is continuous (linear), and their pair is continuous/Borel. Measurability belongs to the actual oracle, not a surrogate map or arbitrary supplied oracle.'},
        {'id': 'B11', 'at': 'S4.SS1.p1;A3.SS4.p2', 'class': 'internal-paper-step', 'obligation': 'Identify f_A and V_A by their identical literal formula and identify matrix-coordinate representations with the standard Euclidean vector/inner-product structure.'},
    ],
    'source_routes_and_consumer_edges': [
        {'consumer': 'A3.SS4.p1 angle inequalities', 'inputs': ['DEF-COSINE-GRID', 'd>=2', '1<=i<=d'], 'logic': 'AND'},
        {'consumer': 'A3.SS4.p1 strict eigenvalue bounds', 'inputs': ['angle inequalities', 'cosine strict bounds', 'kappa>=2'], 'logic': 'AND'},
        {'consumer': 'S4.Thmtheorem6 via A3.SS4.p1', 'inputs': ['diagonal eigenvalue bounds', 'DEF-HARD-PRECISION', 'orthogonal isometry/conjugation'], 'logic': 'AND'},
        {'consumer': 'A3.SS4.p2 C-infinity', 'inputs': ['literal finite-dimensional quadratic formula'], 'logic': 'single sufficient branch; no lower-bound or Haar theorem needed'},
        {'consumer': 'A3.SS4.p2 Hessian / S2.E1 gradient identity', 'inputs': ['literal quadratic differentiation', 'A symmetric'], 'logic': 'AND'},
        {'consumer': 'A3.SS4.p2 strong convexity', 'inputs': ['Hessian/gradient identification', 'lower Loewner bound', 'global Euclidean domain'], 'logic': 'source Hessian route'},
        {'consumer': 'A3.SS4.p2 smoothness', 'inputs': ['Hessian/gradient identification', 'upper Loewner bound', 'Euclidean norm conversion'], 'logic': 'source Hessian route'},
        {'consumer': 'A3.SS4.p2 unique minimizer', 'inputs': ['V_A(0)=0', 'lower quadratic bound', 'strict norm positivity off zero'], 'logic': 'AND; C-infinity/smoothness/upper bound are not needed by this source argument'},
        {'consumer': 'fixed-input actual FO Borel bridge for S2 algorithm context', 'inputs': ['actual literal V_A continuity', 'actual linear A x continuity', 'product Borel structure'], 'logic': 'AND; source-implicit bridge, not an explicit numbered theorem'},
        {'consumer': 'A3.SS4.p3 normalizer independence', 'inputs': ['Gaussian integration', 'positive definite A', 'det(O Lambda O^T)=det Lambda'], 'logic': 'separate out-of-target source branch; must not be silently conflated with geometry'},
    ],
    'binder_challenge': {
        'SOURCE_or_STANDING': ['actual hard family d>=2 and kappa>=2', 'full O(d) orthogonality', 'literal grid/precision/potential definitions', 'Euclidean and Borel conventions'],
        'TYPING': ['finite real Euclidean coordinate carrier and matrix dimensions', 'natural source indices with exact one-based translation', 'standard product codomain R x R^d for oracle'],
        'must_be_derived_not_public_premises': ['angle/cosine/eigenvalue estimates', 'A symmetry/positive definiteness/Loewner bounds', 'potential continuity/C-infinity/measurability', 'gradient/Hessian identities', 'Hessian/operator norm bounds', 'strong convexity and Lipschitz gradient', 'origin gap/minimizer existence or uniqueness', 'seed/oracle measurability gates supplied as assumptions on actual source family'],
        'unjustified_local_restrictions': ['det O=+1 or SO(d)', 'a.e. Haar O or generic eigenbasis', 'bounded spatial domain', 'only a.e. x derivatives or minimizer', 'kappa upper growth bound from main Theorem 4.1', 'delta/d0/epsilon/query-budget conditions', 'extra positive dimension assumption beyond source d>=2', 'arbitrary input A with supplied semantic facts replacing the actual O-Lambda formula'],
    },
    'definition_challenge': [
        'The hard grid, diagonal, conjugated precision, potential and exact oracle are literal definitions. Audit complete meaning-carrying bodies and all parameter/default branches on the public carrier.',
        'The source does not define an arbitrary admissible potential then choose one. Substituting a characterized potential, a cutoff, shifted potential, clipped spectrum, surrogate oracle, or fallback zero changes the object.',
        'V_A and f_A differ only in notation here. A formal additive shift could preserve derivative geometry but changes the exact source value oracle and V_A(0)=0.',
        'No chosen eigenbasis is canonical: different O can represent the same A. Every-O conclusions must not require injectivity or a unique representative.',
        'If a minimizer object is introduced by choice, actual existence/uniqueness must be proved before characterization; no if-exists/otherwise-default definition is justified.',
        'Hessian-as-matrix, Hessian-as-bilinear-form, and derivative-as-continuous-linear-map require explicit semantic equivalence, including Euclidean inner product and norm conventions.',
    ],
    'phase2_questions': [
        'Q01 Does every public theorem use the actual cosine-grid precision/potential rather than an arbitrary supplied Hessian or regularity bundle? Recursively expand every project-owned Prop/structure/class.',
        'Q02 Does every-O include determinant -1? Is any positivity of determinant, SO type, connected-component condition, or Haar-a.e. premise hidden in a type alias?',
        'Q03 Do zero-based indices reproduce the exact one-based midpoint grid, including the half shift and division after real coercion?',
        'Q04 Are all x/y conclusions global on R^d, and are derivative statements Frechet/Euclidean with the source quadratic normalization 1/2?',
        'Q05 Is the Hessian equal to A as an operator/bilinear form at every x, with symmetry derived from O Lambda O^T? Is gradient A x separately identified for actual FO?',
        'Q06 Which strong-convexity convention is encoded, and where is the factor 1/2 in the global inequality checked? Is smoothness Lipschitzness of the gradient with constant kappa?',
        'Q07 Which norm does any matrix/operator-norm assertion use? Could a Frobenius or coordinate norm silently introduce a dimension factor or make the kappa bound false?',
        'Q08 Does uniqueness identify the actual origin as global minimizer, including existence, V(0)=0, and strict off-origin gap, rather than only at-most-one or stationarity?',
        'Q09 Does the measurability conclusion concern x -> (actual V(x), actual A x) for each fixed source input with standard product Borel structures? Is it being overstated as a full adaptive algorithm/kernel theorem?',
        'Q10 Are polynomial smoothness, spectral admissibility, and the direct minimizer argument separate branches? Has the graph introduced false AND dependencies or reversed a consequence into a premise?',
        'Q11 Is every substantive region of C.4, including its final normalizer paragraph, represented or explicitly excluded from this bounded target? Are source-implicit derivative/norm/measurability bridges visible?',
        'Q12 Are actual proof ingredients absent from public binders even when an existing producer theorem is available? Does a broader generic library theorem have an explicit adapter restoring the actual source family?',
        'Q13 Are d>=2, kappa>=2 and universal O scope inherited correctly without importing main-theorem delta/epsilon/kappa-growth conditions? Are any generalizations labelled accurately?',
        'Q14 Does the graph distinguish local deterministic geometry from Haar input distribution, query equivalence, TV lower bounds, deterministic caps and expected costs?',
        'Q15 Does any theorem/definition body invent off-source defaults, require a canonical eigenbasis, silently shift the value oracle, or substitute a surrogate for the actual potential?',
    ],
    'truth_boundary': [
        'This freezes independent source cognition only. No sealed interface was inspected, no extractor graph was assessed, and no source-equivalence/coverage acceptance or VERIFIED/SAU claim is issued.',
        'No proof search, Lean compilation, proof implementation, browser/network/remote/ATLAS/model work, canonical metadata or shared ledger changes, or extra agents were performed.',
        'The local source statements do not prove main lower bound, Krylov/target moments, TV transfer, normalizer integration, a complete Borel adaptive algorithm, query-cap composition, or expected-query costs.',
    ],
}
dump(OUT / 'independent-expectations.json', expected)

capsule = r'''# Phase 1 source-only topology / binder / definition cognition

Status: `SOURCE_COGNITION_FROZEN_AWAITING_PHASE2`. This is a preparatory challenge record, not a source verdict, proof seal, SAU, or verification.

The independently read authority is **On Complexity of Gaussian Sampling**, arXiv:2610.20492v1, local HTML SHA-256 `6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915`, 951991 bytes. The complete original HTML and exact governing instruction bytes are frozen alongside this capsule. Derived DOM text is only a reading aid. Scope: S4.SS1 / Eq. (11), Lemma 4.6, Appendix C.4, and Section 2 for exact-oracle/Borel context. The main theorem and neighboring lemmas were read only to preserve boundaries.

The actual family uses integers d>=2, real kappa>=2, source indices i=1,...,d, midpoint angles theta_i=((i-1/2)pi)/d, lambda_i=(kappa+1)/2+(kappa-1)cos(theta_i)/2, Lambda=diag(lambda_i), and A=O Lambda O^T. Deterministic claims quantify over **every real O in the full O(d)**, including determinant -1. Haar randomness and seed independence describe the lower-bound input experiment; neither is a premise for local geometry. No delta, epsilon, query budget, dimension threshold or kappa growth ceiling belongs in the local geometry statement.

Appendix C.4 has three substantive paragraphs. The first derives strict angle/cosine/eigenvalue bounds and transports the diagonal bounds by orthogonality to I<=A<=kappa I. The second says the **literal actual potential** V_A(x)=x^T A x/2 (the same f_A as Sections 2/4.1) is C-infinity on all Euclidean R^d, has pointwise Hessian A, is 1-strongly convex and kappa-smooth, and has the unique global minimizer 0 because V_A(0)=0 and V_A(x)>=||x||^2/2>0 off zero. The third identifies the Gaussian target and computes the rotation-independent normalizer; that branch is recorded but excluded from this geometry target rather than silently dropped or newly credited.

Expected implicit bridges include one-based/zero-based index translation, symmetry of A, square-orthogonal inverse/isometry algebra, quadratic-form/Loewner equivalence, Frechet differentiation of the symmetric quadratic, Euclidean Hessian representation, the strong-convexity factor 1/2, the induced-operator-norm versus coordinate-matrix-norm distinction, and strict norm positivity for uniqueness. The gradient must be A x for the **actual** exact oracle. For each fixed source input, x -> (V_A(x),A x) is a continuous/Borel map into R x R^d; this source-implicit bridge supports the Section 2 Borel algorithm model without proving a whole adaptive algorithm or random-input kernel theorem.

Topology expectations: the polynomial C-infinity branch does not need a Haar theorem or full lower-bound proof; Hessian/gradient identification needs symmetry; strong convexity and smoothness use lower and upper spectral bounds respectively; the source's direct minimizer argument needs the lower quadratic bound and origin evaluation, not every regularity branch. Existing producer results remain dependency edges, never public convenience binders. Source topology must retain these separate branches and make omitted bridges visible.

The immediate phase-2 challenge will inspect exact literal definitions and recursively expanded binders; full O(d) scope; midpoint index shift; pointwise/global Euclidean derivative semantics; convexity/smoothness constants and operator norm; existence plus uniqueness of the origin minimizer; actual fixed-input oracle Borel semantics; complete C.4 coverage/exclusions; false AND edges; and local-versus-main/TV/cap/expected-cost boundaries. Fifteen precise questions and a source-anchored inventory are in `independent-expectations.json`.

No new statement-seal, raw-interface packet, author preseal/exposure/reuse rationale, extractor proposal/private rationale, Gaussian implementation Lean, or geometry-task README/proof capsule was opened. `exposure.json` records all instruction/source access and a truncated historical process-handoff exposure. No implementation work, proof search/build, browser/network/remote/ATLAS/model action, canonical/shared/ledger change, or sub-agent work was performed. Stop after freezing; the next input must be the extractor's independently frozen graph and raw exact interfaces/standard definitions without private rationale.
'''
(OUT / 'phase1-capsule.md').write_text(capsule)

dump(OUT / 'phase1-freeze.json', {
    'phase': 'phase1',
    'frozen_at_utc': datetime.now(timezone.utc).isoformat(),
    'status': 'SOURCE_COGNITION_FROZEN_AWAITING_PHASE2',
    'source': digest(SOURCE),
    'source_only': True,
    'implementation_read': False,
    'extractor_graph_read': False,
    'sealed_interfaces_read': False,
    'source_verdict': None,
    'SAU_or_VERIFIED_transition': None,
    'scope': ['S4.SS1', 'S4.E11', 'S4.Thmtheorem6', 'A3.SS4', 'S2 exact FO/Borel fixed-input context'],
    'next_step': 'STOP; await separately supplied frozen graph and raw interfaces/standard definitions for phase 2.',
})

records = [digest(path) for path in sorted(OUT.rglob('*')) if path.is_file() and path.name not in {'manifest.json', 'manifest.sha256'}]
records.append(digest(Path(__file__)))
dump(OUT / 'manifest.json', {
    'schema': 1,
    'phase': 'source-only-independent-cognition-phase1',
    'self_hash_policy': 'manifest excludes itself and detached manifest.sha256; detached digest authenticates manifest bytes',
    'files': records,
})
manifest_digest = hashlib.sha256((OUT / 'manifest.json').read_bytes()).hexdigest()
(OUT / 'manifest.sha256').write_text(manifest_digest + '  manifest.json\n')
dump(WORK / 'phase1-result.json', {
    'status': 'SOURCE_COGNITION_FROZEN_AWAITING_PHASE2',
    'capsule': digest(OUT / 'phase1-capsule.md'),
    'expectations': digest(OUT / 'independent-expectations.json'),
    'manifest': digest(OUT / 'manifest.json'),
    'stop': True,
})

for rec in [digest(OUT / 'phase1-capsule.md'), digest(OUT / 'independent-expectations.json'), digest(OUT / 'manifest.json'), digest(WORK / 'phase1-result.json')]:
    print(json.dumps(rec, ensure_ascii=False))
