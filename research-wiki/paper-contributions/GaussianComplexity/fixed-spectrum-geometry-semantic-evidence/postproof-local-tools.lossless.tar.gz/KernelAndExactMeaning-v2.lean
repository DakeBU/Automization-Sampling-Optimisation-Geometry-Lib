import Tests.GaussianComplexityFixedSpectrumGeometry
open Matrix InnerProductSpace
open scoped ContDiff
set_option autoImplicit false

example {d : ℕ} (hd : 2 ≤ d)
    {κ : ℝ} (hκ : 2 ≤ κ)
    (O : Matrix.orthogonalGroup (Fin d) ℝ) :
  let θ : Fin d → ℝ := fun i => ((i.val : ℝ) + 1 / 2) * Real.pi / (d : ℝ)
  let A : Matrix (Fin d) (Fin d) ℝ :=
    (O : Matrix (Fin d) (Fin d) ℝ) *
      Matrix.diagonal (fun i => (κ + 1) / 2 + (κ - 1) / 2 * Real.cos (θ i)) *
      (O : Matrix (Fin d) (Fin d) ℝ).transpose
  let f : EuclideanSpace ℝ (Fin d) → ℝ := fun x =>
    (WithLp.ofLp x) ⬝ᵥ (A *ᵥ WithLp.ofLp x) / 2
  ContDiff ℝ ∞ f ∧
    (∀ x : EuclideanSpace ℝ (Fin d),
      HasFDerivAt (gradient f) (Matrix.toEuclideanCLM (𝕜 := ℝ) (n := Fin d) A) x) ∧
    StrongConvexOn (Set.univ : Set (EuclideanSpace ℝ (Fin d))) 1 f ∧
    (∀ x y : EuclideanSpace ℝ (Fin d),
      ‖gradient f x - gradient f y‖ ≤ κ * ‖x - y‖) ∧
    f 0 = 0 ∧
    (∀ x : EuclideanSpace ℝ (Fin d), IsMinOn f Set.univ x ↔ x = 0) := by
  exact AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumGeometry.actual_potential_geometry hd hκ O

def anonymousConsumerExpected : Prop := ∀ {d : ℕ} (hd : 2 ≤ d)
    {κ : ℝ} (hκ : 2 ≤ κ)
    (O : Matrix.orthogonalGroup (Fin d) ℝ),
  let θ : Fin d → ℝ := fun i => ((i.val : ℝ) + 1 / 2) * Real.pi / (d : ℝ)
  let A : Matrix (Fin d) (Fin d) ℝ :=
    (O : Matrix (Fin d) (Fin d) ℝ) *
      Matrix.diagonal (fun i => (κ + 1) / 2 + (κ - 1) / 2 * Real.cos (θ i)) *
      (O : Matrix (Fin d) (Fin d) ℝ).transpose
  let f : EuclideanSpace ℝ (Fin d) → ℝ := fun x =>
    (WithLp.ofLp x) ⬝ᵥ (A *ᵥ WithLp.ofLp x) / 2
  let query : EuclideanSpace ℝ (Fin d) → EuclideanSpace ℝ (Fin d) :=
    fun x => WithLp.toLp 2 (A *ᵥ WithLp.ofLp x)
  @Measurable (EuclideanSpace ℝ (Fin d))
    (ℝ × EuclideanSpace ℝ (Fin d))
    (borel (EuclideanSpace ℝ (Fin d)))
    (borel (ℝ × EuclideanSpace ℝ (Fin d)))
    (fun x => (f x, query x))

open Lean in
run_cmd do
  let env ← getEnv
  let producer := `AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumGeometry.actual_potential_geometry
  let consumers := env.constants.toList.filter fun (name, _) =>
    name.toString.startsWith "_private.Tests.GaussianComplexityFixedSpectrumGeometry" &&
    name.toString.endsWith ".actual_first_order_oracle_measurable"
  unless consumers.length == 1 do throwError "Expected one compiled genuine Borel consumer"
  let consumer := consumers.head!.1
  let admiss := `AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumAdmissibility.actual_precision_admissible
  let first := `AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumFirstOrder.actual_first_order_query
  let converse := `AutoSamplingTheory.TechnicalLemmas.Analysis.StrongConvexGradientConverse.strongConvexOn_of_gradient_inner_lower_bound
  for (name, expected) in [(producer, [admiss, first, converse]), (consumer, [producer, first])] do
    let some info := env.find? name | throwError "Missing compiled target"
    let some proof := info.value? (allowOpaque := true) | throwError "Missing actual proof term"
    let used := proof.getUsedConstants.toList.filter fun n => n.toString.startsWith "AutoSamplingTheory."
    unless used.length == expected.length && expected.all used.contains do
      throwError m!"Actual direct ASTIS parents mismatch: {name}: {used}"
    logInfo m!"ACTUAL_TARGET {name}"
    for dep in used do logInfo m!"ACTUAL_ASTIS_PARENT {dep}"
    for dep in proof.getUsedConstants.toList do
      unless dep.toString.startsWith "AutoSamplingTheory." do
        logInfo m!"ACTUAL_OTHER_CONSTANT {name}: {dep}"
  let check ← `(command| example : anonymousConsumerExpected := $(mkIdent consumer))
  Lean.Elab.Command.elabCommand check
  logInfo "Exact sealed full-forall producer application and literal private-consumer type application checked."
  logInfo "Actual proof-term ASTIS parents producer3/consumer2; imports/name scans are not this evidence."
