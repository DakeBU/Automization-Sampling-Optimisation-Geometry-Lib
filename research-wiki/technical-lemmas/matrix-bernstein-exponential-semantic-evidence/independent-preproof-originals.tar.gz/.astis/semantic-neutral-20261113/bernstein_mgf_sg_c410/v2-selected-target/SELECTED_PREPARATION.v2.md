# Exact P/T selected-source preparation v2

This is a separate source-only refinement of the immutable v1 raw reading. It
does not approve its own graph, admit a target, or supply a theorem proof. The
recommendation is to send the exact frozen P/T graph to the distinct challenge,
with intake held for that challenge and the canonical reuse/visibility audit.

The exact seal and audit were read only after the raw-source freeze. Their
SHA-256 values match the supplied values, and the literal P and T signature
strings independently hash to the values recorded by the seal. The v1 originals
and all prior source artifacts are unchanged.

## Selected source scope

P is the real finite nonempty restriction of the deterministic inequality in
the last display of Tropp Lemma 6.7's proof on p. 25:

\[
\exp(sA)\preceq I+sA+(e^s-s-1)A^2,
\qquad A=A^*,\quad\lambda_{\max}(A)\le1,\quad s>0.
\]

The exact sealed `PosSemidef` difference has the correct direction. Its
`(1-A).PosSemidef` premise represents the one-sided upper spectral cap, through
an internal equivalence that still needs proof. It imposes no lower spectral
cap or operator-norm bound. `[Fintype ι] [DecidableEq ι] [Nonempty ι]` makes the
finite positive matrix dimension explicit; the source's complex domain is
restricted to real self-adjoint matrices. P is not the full stochastic mgf
lemma.

T is an authored actual Gaussian specialization of the full single-matrix
mgf lemma. It fixes the original product Gaussian experiment, the source's
literal cutoff and feature grid, the actual unconditional mean, and
\(Z_i=Y_i-\mathbb E Y_i\). It normalizes by the actual source radius
\(\rho=2r(L+1)/d\), with \(X_i=\rho^{-1}Z_i\), and asserts the mgf bound for
every \(s>0\) and every actual row i. It has only the original natural parameters
and \(2q+1<d\); the case \(q=0\) remains included. T stays private, with no
public API or Registry credit.

T is not a quotation of Gaussian `A3.Ex121`: that invocation is an uncited
two-sided sum-tail bound. Tropp remains independently selected matching external
background. The new target reaches only a normalized single-item ingredient.

## Concrete source use and open ports

| Use site | Required internal discharge |
|---|---|
| P scalar bound | Smooth removable remainder and monotonicity on every real eigenvalue \(x\le1\), including arbitrarily negative x and zero. |
| P spectral cap | Real self-adjoint \(\operatorname{PSD}(I-A)\) is equivalent to \(\lambda_{\max}(A)\le1\) in finite nonempty dimension. |
| P matrix transfer | Source scalar functional calculus, the quadratic factor identity, and congruence order. No operator monotonicity of f or exp is assumed. |
| P exact exponential | The actual rational-series `NormedSpace.exp` must equal the source spectral exponential. The supplied audit's successful instance/definition typing does not prove this equality. |
| T original experiment | Product standard Gaussian measure represents the original independent Gaussian columns; the row packing, zero-based grid, and features match the source. |
| T actual normalization | Derive \(d>0\), \(r>0\), \(\rho>0\), actual centered radius, self-adjointness, and \(\|X_i\|\le1\). No new radius or positivity binder. |
| T centering | Derive \(\int X_i\,d\mu=0\) from the actual unconditional mean, integrability, scalar linearity, and \(\mu(\Omega)=1\). |
| T analytic domain | Derive all Bochner measurability/integrability of X, its square, exp, and the relevant PSD differences from actual finite-dimensional boundedness and the probability measure. |
| T first comparison | Apply P at the actual X, then integrate PSD using the closed convex cone and the internally derived full-measure hypotheses. |
| T second comparison | Show the actual \(C_i=(e^s-s-1)\int X_i^2\,d\mu\) is self-adjoint and apply \(I+C_i\preceq\exp(C_i)\) internally. |
| T exact conclusion | Add the two PSD differences to obtain exactly the sealed exponential-minus-mgf difference. |

The generic source Section 2.2 regularity convention remains unquantified as a
source fact. It must not become an added T hypothesis. Unlike a generic
one-sided spectral cap, the actual Gaussian construction is bounded after its
literal truncation and normalization, so its concrete analytic requirements
belong to internal dependencies. Bochner matrix integrals must be matched with
the source's matrix expectations; no arbitrary covariance, free mean, or
expectation conditioned on the simultaneous truncation event is used.

P is deterministic. T needs the derived order/radius comparisons almost
everywhere for integration; a direct pointwise actual-object bound is also
sufficient. The graph introduces no extra everywhere-bound certificate.

No total-variance envelope, Gaussian fourth-moment estimate, sum-family
independence premise, tail threshold, or sum-tail optimizer is needed for these
P/T targets. In particular, zero covariance is allowed. T derives its actual
normalization radius positive; it does not import Theorem 6.1's unresolved
zero-R/zero-variance formula conventions.

## Remaining admission boundary

The source graph has 47 nodes, 53 consumer-use edges, 22 explicit internal ports,
and 30 selected coverage records. Mechanical checks confirm valid references,
explicit exclusions, acyclicity, and matching literal signature hashes. These
checks do not certify the mathematics.

The coordinator reports that R11 public actual structure is locally compiled
and R12 is independently closed at the supplied base HEAD. The exact R10
centered-radius public/private visibility and canonical-parent audit remains
pending. This pass retrieved no headers, proof bodies, or module/API bodies.
Do not duplicate a public canonical lemma or create a public wrapper solely to
expose a private radius fact. P's canonical ownership and accessible parent
reuse need that audit; T stays private.

Lieb, conditioned cgf, master-tail, and two-sided union adapters remain open for
future sum-tail work. They are outside this selected P/T closure and must not
become false AND dependencies of this mgf preparation.

`selected-source-graph.v2.json` is the complete selected graph;
`target-use-map.v2.json` maps exact binders/local definitions and consumer use
sites; `admission-recommendation.v2.json` records the bounded recommendation.
`selected-target-expectations.freeze.v2.json` retains the exact signature
strings, and the byte-identical input seal/audit copies are in `inputs/`.

No proof, build, intake, ledger/frontier/Registry/site state write, or public
wrapper node was made. The independent selected-source challenge and canonical
reuse audit are pending.
