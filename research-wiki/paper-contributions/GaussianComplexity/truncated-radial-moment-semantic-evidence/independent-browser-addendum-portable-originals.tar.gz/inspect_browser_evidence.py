from hashlib import sha256
import json
from pathlib import Path
import subprocess

out = Path(__file__).resolve().parent
repo = out.parents[2]
relative_root = Path('.astis/huanjian-gc-truncated-radial-moment-20261110')
run = relative_root / 'browser-exposition-v2-escalated/attempt-20261111T024012071766Z'
receipt_path = Path('.astis/huanjian-resume-20261103/20261111T024012019906Z-truncated-radial-moment-exposition-v2-bounded-browser-escalated.receipt.json')
revision = '1baba1dd32bb79b66a541251f5a16ae6fdc54076'
render = repo / '.astis/semantic-neutral-20261110/rm_native_941b_exposition_v2/static-site'


def digest(data):
    return sha256(data).hexdigest()


def blob(path):
    return subprocess.check_output(['git', 'cat-file', 'blob', f'{revision}:{path}'], cwd=repo)


receipt_bytes = (repo / receipt_path).read_bytes()
receipt = json.loads(receipt_bytes)
report_bytes = (repo / run / 'actual-browser-report.json').read_bytes()
report = json.loads(report_bytes)
log_path = Path(receipt['log'])
log_bytes = log_path.read_bytes()
script_path = relative_root / 'check_bounded_reader_browser.py'
script_bytes = (repo / script_path).read_bytes()
assert receipt['head_before'] == receipt['head_after'] == report['commit'] == revision
assert receipt['exit_code'] == 0 and report['bounded_browser'] == 'PASS' and report['errors'] == []
assert digest(log_bytes) == receipt['log_sha256'] == 'd2a69a30bd59df6816b438734604ddf9294cca74e756ae3db08061510ec10520'
assert receipt['command'] == [
    '.astis/huanjian-gc-integration-20261105/browser-venv/bin/python', '-B', str(script_path),
    '.astis/semantic-neutral-20261110/rm_native_941b_exposition_v2/static-site',
    str(relative_root / 'browser-exposition-v2-escalated'),
]
assert digest(script_bytes) == 'b178114aceb046ac5d6b68d4f5a853ab9ffc849cd48e1f7d065559172d02c3ac'
for path, expected in report['render_sha256'].items():
    data = (render / path.lstrip('/')).read_bytes()
    assert digest(data) == expected
    print('UNCHANGED_RENDER', path, expected)
for path, expected in report['assets'].items():
    relative = 'website/static/' + path.removeprefix('/assets/')
    assert digest(blob(relative)) == expected
    print('PINNED_ASSET', path, expected)
assert [(p['width'], p['height']) for p in report['pages']] == [(1440, 1000), (390, 844)]
for page in report['pages']:
    assert page['visible_main_math'] and page['complete_source_math'] and page['assumption_fold']
    assert page['exact_step_folds'] == 5 and page['step_controls'] == [{'copy': 0, 'download': 0}] * 5
    assert page['companion_link'] == '/proofs/source-huanjian-gaussian-truncated-radial-moment.html'
    assert page['private_context_link'] == '/data/lesson-sources/Tests/GaussianComplexityFixedSpectrumTruncatedRadialMoment.lean.html#L18'
    screenshot = page['screenshot']
    data = (repo / run / screenshot['file']).read_bytes()
    assert digest(data) == screenshot['sha256']
    assert data.startswith(b'\x89PNG\r\n\x1a\n')
    print('SCREENSHOT', page['width'], screenshot['sha256'])
assert report['public_integration'] == report['canonical_source_index_and_graph'] == 'HOLD'
originals = [script_path, receipt_path, log_path.relative_to(repo), run / 'actual-browser-report.json', run / 'main-1440.png', run / 'main-390.png']
manifest = {'revision': revision, 'runner': 'root agent; independently reviewed receipt, code, report, exact assets and screenshots', 'reviewer_reran_browser': False, 'inputs': []}
for path in originals:
    data = (repo / path).read_bytes()
    name = 'successful-browser-script.py' if path == script_path else path.name
    target = out / 'originals' / name
    target.parent.mkdir(exist_ok=True)
    target.write_bytes(data)
    manifest['inputs'].append({'path': str(path), 'copy': str(target.relative_to(out)), 'sha256': digest(data), 'bytes': len(data)})
(out / 'browser-input-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print('BROWSER_RECEIPT_REPORT_AND_RENDER_CUSTODY_PASS')
print('No browser launch was performed by this review script.')
