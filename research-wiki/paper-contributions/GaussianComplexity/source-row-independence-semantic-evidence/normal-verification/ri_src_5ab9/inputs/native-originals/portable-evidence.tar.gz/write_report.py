import json
from run import ROOT,sha
load=lambda p:json.loads((ROOT/p).read_text())
m=load('input-manifest.json');n=load('native-summary.json');l=load('locator-checks.json');r=load('reader-static.json');b=load('relevant-input-binding.json')
holds=['Independent source-fidelity verdict (fresh source reader owns it)','arbitrary extended-ambient transfer','matrix expectation/centered variance/concentration/full Lemma4.4/main lower bounds','oracle/TV/precision/query caps/expected costs','global graph/full site/source-index validation','browser desktop/mobile/MathJax/clipboard/interactive download runtime','root Tests/full repository gates','public publication/serialized integration/purification','ledger transitions, release permission or shared-owner grant']
report={'verifier_id':'ri_native_74b8','verdict':'ACCEPT_BOUNDED_NATIVE_WHOLE_MODULE_STATIC','compile_candidate_only':m['candidate_commit'],'source_fidelity_grant':False,'ledger_transition_or_permission_grant':False,'ownership':'Only .astis/semantic-neutral-20261112/ri_native_74b8; no candidate proof or shared edits','native':{'derived_ASTIS_modules':m['modules'],'fresh_module_builds':len(m['modules']),'all_owned_declarations':n['module_owned_total'],'new_handwritten':n['new_handwritten'],'new_generated':n['new_generated'],'new_public':1,'new_private':1,'all_owned_reachable':True,'native_type_body_closed':True,'standard_axioms_only':n['only_standard_axioms'],'parents':n['canonical_ASTIS_parents'],'exact_author_probe_pass':True,'separate_seal_literal_kernel_applications_pass':True,'both_raw_Expr_structural_equalities':False,'equality_meaning':'Raw Expr equality is false; actual kernel theorem application to each frozen literal Prop passes by definitional equality. No extra binder or type/output drift.','lean':m['lean_binary'],'version':m['lean_version'],'manifest_sha256':m['files']['lake-manifest.json']['sha256'],'all_9_packages_pinned_clean_including_untracked':True,'isolated_path':m['lean_path'],'no_ASTIS_cached_oleans_copied_or_reachable':True,'full_native_dump':n['large_full_dump']},'proof_reading':{'producer':'Internal full Gaussian scalar-coordinate product map via map_pi_eq_stdGaussian, column unwrap, finite specialization of infinitePi_eq_pi and curry_symm, swap Q×I, regroup I×Q, Euclidean row wrapping, genuine actual_joint product law, then joint-product characterization of full finite-family iIndepFun. Marginals supply measurable component laws and do not imply the joint law on their own.','consumer':'Literal same-Omega/mu Yi=Fi(rowi). Actual closed norm-squared cutoff, half-grid deterministic features and inverse-d Gaussian-first Kronecker entries are preserved. Coordinate entry polynomials plus Measurable.ite prove all Fi measurable; canonical row law supplies row measurability; separate measurable images preserve full independence, with no injectivity/common-Fi/iid conclusion.','applicability':'Actual native specialized checks synthesize probability/sigmafinite structures for scalar Gaussian, Euclidean Gaussian, column product, nested scalar product and flattened product. map_pi_eq_stdGaussian is specialized to the literal WithLp.toLp coordinate map, validating physical coordinate applicability. Kernel.iIndepSets explicitly quantifies every finite set of indices and every family of measurable preimage events.','canonicality':'The unchanged canonical row marginal theorem remains the one parent, not a duplicate marginal theorem. No new generated helper or unreachable new declaration.'},'static':{'production_calls':r['actual_production_calls'],'publication_binding_sha256':r['binding_sha256'],'six_exact_closed_steps':r['six_steps'],'full_public_statement_and_proof_folds_exact':True,'complete_private_export_lines':81,'private_link_line':11,'original_blank_separator_line':60,'all_formulas_adjacent':True,'source_download_targets_and_exact_file_bytes':True,'download_runtime_claimed':False,'dependency_distinctions':'Producer has exactly canonical row-law ASTIS parent; private consumer has new producer plus same row-law. Mathlib calls remain external.','source_map_sha256':l['source_map_sha256'],'coordinate_span_checks':l['all_source_Lean_background_and_seal_spans_checked'],'original_archive_members_all_reread':l['preproof_archive']['member_count']},'history':{'actual_first_build_and_strict_kernel_receipts_exit0_verified':True,'failed_API_lookup':'Exactly three unqualified infinitePi API names, API_BLOCKED; qualified production APIs pass.','preseal_formations':'Two preseal Matrix-alias/letI formation failures retained, followed by successful v3/v4 Prop formation; no theorem proof claimed.','own_rejected_attempts':load('verifier-failures.json'),'no_mathematical_refutation_from_verifier_or_API_failures':True},'final_binding':{'file':'relevant-input-binding.json','sha256':sha((ROOT/'relevant-input-binding.json').read_bytes()),'tracked_input_count':len(b['tracked_relevant_input_hashes']),'HEAD_at_final_comparison':b['HEAD_at_comparison'],'all_relevant_bytes_equal':True,'later_carrier_compile_credit':False},'HOLD':holds,'evidence':['native-build.json','native-summary.json','native-authored-types.txt','reader-static.json','static-extra.json','locator-checks.json','fake-closure-scan.json','historical-failure-detail.json','historical-original-checks.json','relevant-input-binding.json','receipts/','REPRODUCE.md']}
(ROOT/'report.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
md='''# Independent bounded acceptance — ri_native_74b8

**ACCEPT_BOUNDED_NATIVE_WHOLE_MODULE_STATIC**, exclusively for immutable math
candidate `66e0bb9b748d68816a8443d60696656c9340222f`.

The independently derived transitive ASTIS closure has three whole modules:
the unchanged canonical source row law, the new public row-independence producer,
and the actual private matrix consumer. All three freshly compile under the
actual pinned Lean 4.33.0 native binary, with a new empty ASTIS output directory
and only pinned Mathlib/package caches reachable. All nine package HEADs match
the frozen manifest and are clean including untracked files, before and after.

All three module-owned declarations have complete closed native types and
bodies, standard axiom closure only (`propext`, `Classical.choice`, `Quot.sound`),
and reachability from the new roots. The two new declarations are exactly one
public and one private handwritten theorem, with zero generated owned helpers.
The producer's ASTIS parent is exactly the same canonical marginal-law node;
the private consumer's parents are exactly the producer and that node. No
duplicate marginal law, extra premise certificate, hidden assumption,
unreachable new helper, fake closure, or output-measurability drift was found.

Both independently generated frozen literal Props and the exact author probe
pass actual kernel theorem application. Both raw Expr equalities are false;
the kernel applications establish the relevant definitional equalities.

The producer constructs the genuine joint product law: physical-coordinate
Gaussian product identification, column unwrapping, finite curry/flattening,
index swap and regrouping, row wrapping, then full-family independence from
the joint-product characterization. It does not infer independence from
marginals. Actual native probability/sigmafinite instances and the literal
physical-coordinate `WithLp.toLp` Gaussian map specialization pass. Kernel
independence definitions retain every finite-family measurable event.

The private consumer proves measurable closed-cutoff polynomial matrix images
and transports full independence through their separate measurable maps on
the identical measure. Its actual cutoff, cosine features, inverse-d factor,
Gaussian-first Kronecker entry order and measurable-output conclusion remain
literal; no injectivity or identical-distribution premise is added.

Actual production `render_unit`, `export_sources`, and `render_source_module`
pass bounded static checks. The six initially closed steps are exactly P21–57,
P59–77, P78–86, P88–96, T1–59 and T61–81. The original blank T60 separator is
restored when reconstructing the complete 81-line private export, linked at
line 11. Exact public folds, adjacent formulas, dependency distinctions,
local source/module anchors, download target names and locally materialized
download file bytes pass. The exact source map has 47 independently recomputed
byte/Unicode-character/LF spans; all 204 members of its bounded original
preproof archive are re-read and hash-checked.

Historical first actual implementation build and strict probe receipts are
exit 0. The failed exploratory API stream contains exactly three unqualified
Measure namespace lookups. Two preseal statement-formation failures are
preserved as formation/typing failures, followed by successful v3/v4 Props;
they confer no theorem proof. The sole rejected own attempt was missing an
isolated Python import dependency. Its version and exit-1 streams remain;
freezing the exact production Python import closure resolved it. No such
failure is mathematical negative evidence.

`relevant-input-binding.json` freezes all relevant candidate code, lesson,
publication, source map, pins, protocols and production renderer bytes for a
later held-carrier byte comparison. Native compile credit remains at 66e0.
The omitted local full-body dump is hashed in `native-summary.json`; generated
inspector and replay instructions reproduce it.

**Truth boundary:** this report grants no source-fidelity verdict, ledger
transition, ownership release or integration permission. It grants no global
graph/full-site/source-index, browser/mobile/MathJax/clipboard/interactive
download, root Tests/full-repository, public publication or purification
credit. Arbitrary ambient transfer, matrix expectation/variance/concentration,
full Lemma4.4, main lower bounds and oracle/TV/precision/cap/cost results remain
outside this acceptance. No candidate proof or shared repository file changed.
'''
(ROOT/'report.md').write_text(md)
print(json.dumps({'report_sha256':sha((ROOT/'report.json').read_bytes()),'markdown_sha256':sha((ROOT/'report.md').read_bytes()),'spans':47,'original_members':204,'tracked_inputs':len(b['tracked_relevant_input_hashes'])}))
