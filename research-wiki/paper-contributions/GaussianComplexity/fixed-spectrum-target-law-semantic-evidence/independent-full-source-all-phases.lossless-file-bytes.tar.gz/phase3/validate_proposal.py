"""Read-only canonical validator on this review's own singleton fixture.

Never loads the repository registry or applies an audit. No Lean is invoked.
"""
from pathlib import Path
from hashlib import sha256
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
validator = ROOT / 'substrate/tools/astis_semantic_roundtrip_core.py'
assert sha256(validator.read_bytes()).hexdigest() == '90049b13ea83ccc41876f9267fd2e1a8052acac42e89a1063f97ac5619d39058'
spec = importlib.util.spec_from_file_location('exact_canonical_semantic_core_for_own_fixture', validator)
core = importlib.util.module_from_spec(spec)
spec.loader.exec_module(core)

packet = json.loads((ROOT / 'fresh-source-reviewer-packet.json').read_bytes())
selective = json.loads((ROOT.parent / 'phase2/selective_packet.json').read_bytes())
proposal = json.loads((ROOT / 'canonical-five-field-audit-proposal.json').read_bytes())
lean = dict(packet['lean'])
lean['formalizer'] = packet['roles']['formalizer']
lean['decoder_context'] = selective['approved_definition_context']
reconstruction = dict(packet['blind_reconstruction'])
reconstruction['lean_statement_sha256'] = lean['statement_sha256']
audit = {
    'id': 'ASTIS-RT-20261110-HuanjianFixedSpectrumTargetLaw',
    'source': dict(packet['source']),
    'lean': lean,
    'reconstruction': reconstruction,
    'repairs': [],
    'publication_binding_sha256': packet['publication_binding_sha256'],
    'publication_context': packet['candidate_publication_context'],
    **proposal,
}
blind_packet = core.decoder_packet(audit)
assert blind_packet['packet_sha256'] == reconstruction['decoder_packet_sha256']
reconstruction['input_artifacts'] = blind_packet['input_artifacts']
recreated_packet = core.semantic_reviewer_packet(audit)
assert recreated_packet == packet
fixture = {
    'schema_version': 1,
    'protocol': {
        'decoder_blindness': 'required',
        'decoder_context_content_scan': 'required',
        'independent_source_review': 'required',
        'source_review_packet_binding': 'required',
        'independent_repair_review': 'required',
        'repair_review_packet_binding': 'required',
        'semantic_slots': list(core.SEMANTIC_SLOTS),
        'decoder_allowed_inputs': list(core.DECODER_INPUT_ARTIFACTS),
    },
    'audits': [audit],
}
errors = core.validate_registry(fixture)
(ROOT / 'canonical_validator_singleton_fixture.json').write_text(
    json.dumps(fixture, ensure_ascii=False, indent=2) + '\n')
report = {
    'validator_source_sha256': sha256(validator.read_bytes()).hexdigest(),
    'operation': 'validate_registry(own singleton fixture), never load_registry',
    'real_registry_read': False,
    'audit_applied': False,
    'lean_or_native_run': False,
    'compiled_field': 'Inherited from authorized packet, not independently reverified here',
    'canonical_decoder_packet_hash_recomputed': blind_packet['packet_sha256'],
    'full_canonical_reviewer_packet_recreated_identically': True,
    'canonical_reviewer_packet_sha256': recreated_packet['packet_sha256'],
    'proposal_exactly_five_fields': set(proposal) == {'state','verdict','semantic_slots','deltas','source_review'},
    'seven_slots': len(proposal['semantic_slots']),
    'schema_violations': errors,
}
(ROOT / 'schema_validation.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
if errors:
    raise SystemExit(1)
