from pathlib import Path
from hashlib import sha256
from datetime import datetime, timezone
import json
import shutil
import stat

O=Path('/Users/zhouhuanjian/ASTIS-GC/.astis/semantic-neutral-20261110/cg_sg_1d7a46')
P=O/'phase1'
assert not (O/'phase1_receipt.json').exists(), 'Already frozen; phase1 is never rewritten.'
G=P/'logs/generators'
G.mkdir()
for name in ['prepare_phase1.py','author_phase1.py','capture_reads.py','freeze_phase1.py']:
    shutil.copyfile(O/name,G/name)

def read(name):
    return json.loads((P/name).read_text())
def dump(path,obj):
    path.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
def digest(path):
    return sha256(path.read_bytes()).hexdigest()

source=read('source_index.json')
raw=(P/'inputs/2610.20492v1.html').read_bytes()
expected='6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
assert sha256(raw).hexdigest()==expected==source['raw_sha256']
ids={x['id']:x for x in source['items']}
assert len(ids)==463
assert sum(x['tag']=='math' for x in ids.values())==227
for item in ids.values():
    assert sha256(raw[item['byte_start']:item['byte_end_exclusive']]).hexdigest()==item['sha256']
graph=read('source_graph.json')
cov=read('coverage.json')
assert graph['raw_sha256']==cov['raw_sha256']==expected
covered={x['item_id']:x for x in cov['items']}
assert len(covered)==len(cov['items'])==473
assert set(ids)<=set(covered)
nodes={x['id']:x for x in graph['nodes']}
assert len(nodes)==33
assert len(graph['edges'])==19
assert all(x['formal_status']=='SOURCE_ONLY_UNCHECKED' for x in nodes.values())
for item in cov['items']:
    assert item['disposition'] in ['NODE','EXCLUDED']
    assert bool(item['node_ids'])==(item['disposition']=='NODE')
    assert all(x in nodes for x in item['node_ids'])
    assert item['reason']
    assert sha256(raw[item['byte_start']:item['byte_end_exclusive']]).hexdigest()==item['raw_span_sha256']
parents={n:set() for n in nodes}
for edge in graph['edges']:
    assert edge['consumer'] in nodes
    assert set(edge['parents'])<=set(nodes)
    assert edge['logic']=='AND'
    assert all(x in ids for x in edge['consumer_use_sites'])
    assert edge['discharge']
    parents[edge['consumer']].update(edge['parents'])
def acyclic(current,prior=()):
    assert current not in prior, (current,prior)
    for parent in parents[current]:
        acyclic(parent,prior+(current,))
for name in nodes:
    acyclic(name)
outside={x['id'] for x in graph['out_of_scope']}
all_context=set(nodes)|outside
context_parents={x:set(parents.get(x,set())) for x in all_context}
for edge in graph['context_only_downstream_topology']:
    assert edge['consumer'] in all_context
    assert set(edge['parents'])<=all_context
    assert all(x in ids for x in edge['use_sites'])
    context_parents[edge['consumer']].update(edge['parents'])
def context_acyclic(current,prior=()):
    assert current not in prior, (current,prior)
    for parent in context_parents[current]:
        context_acyclic(parent,prior+(current,))
for name in all_context:
    context_acyclic(name)

validation={'status':'STRUCTURAL_INTEGRITY_ONLY_PASS',
 'source_sha256':expected,'raw_span_checks':len(ids),'coverage_rows':len(covered),
 'raw_math_ids':227,'graph_nodes':len(nodes),'core_edges':len(graph['edges']),
 'core_and_context_dags_acyclic':True,'all_use_sites_exist':True,
 'independent_review':'PENDING; no self-certification of source coverage or mathematics',
 'typed_overlay':'not received or read',
 'checks_do_not_establish':['Lean truth','source fidelity verdict','source topology acceptance','C.5 range clause','C.6','full Lemma 4.4','either main result']}
dump(P/'logs/freeze_validation.json',validation)

files=sorted(x for x in P.rglob('*') if x.is_file())
assert all(not x.is_symlink() for x in files)
manifest={'schema':'astis-raw-phase1-file-manifest/v1',
 'root':str(P),'source_sha256':expected,
 'nonrecursive_contract':'This manifest lives outside phase1 and hashes phase1 files only. It does not hash itself or the receipt. The receipt hashes this manifest and does not hash itself.',
 'files':[{'path':str(x.relative_to(P)),'bytes':x.stat().st_size,'sha256':digest(x),'frozen_mode':'0444'} for x in files]}
manifest_path=O/'phase1_manifest.json'
dump(manifest_path,manifest)
for path in files:
    path.chmod(0o444)
directories=sorted([P,*[x for x in P.rglob('*') if x.is_dir()]],key=lambda x:len(x.parts),reverse=True)
for path in directories:
    path.chmod(0o555)
assert all(stat.S_IMODE(x.stat().st_mode)==0o444 for x in files)
assert all(stat.S_IMODE(x.stat().st_mode)==0o555 for x in directories)
for name in ['prepare_phase1.py','author_phase1.py','capture_reads.py','freeze_phase1.py']:
    (O/name).chmod(0o444)
manifest_path.chmod(0o444)

keynames=['source_graph.json','coverage.json','cognition.md','source_index.json','inputs.json','logs/execution_and_exposure.md']
receipt={'schema':'astis-raw-phase1-freeze-receipt/v1','status':'PHASE1_FROZEN_WAITING_FOR_EXACT_TYPES',
 'frozen_utc':datetime.now(timezone.utc).isoformat(),
 'phase1_path':str(P),'manifest_path':str(manifest_path),'manifest_sha256':digest(manifest_path),
 'source_sha256':expected,'file_count':len(files),'directory_count':len(directories),
 'all_phase1_file_modes':'0444','all_phase1_directory_modes':'0555',
 'key_artifacts':{name:digest(P/name) for name in keynames},
 'source_graph_math_status':'source-only, unchecked, independent review pending',
 'counts':{'raw_ids':463,'raw_math_ids':227,'coverage_rows':473,'source_graph_nodes':33,'core_edges':19},
 'typed_overlay':'not received or read; send exact sealed types and minimal meaning-carrying definitions in a new bounded input only after this receipt',
 'immutability':'No phase1 bytes may change. Typed alignment, independent reviews and any proposed correction must be separate artifacts.',
 'excluded_completion':['Range(B)=Krylov','C.6 concentration','full Lemma 4.4','either main theorem']}
receipt_path=O/'phase1_receipt.json'
dump(receipt_path,receipt)
receipt_path.chmod(0o444)
summary={'status':receipt['status'],'manifest_sha256':receipt['manifest_sha256'],
 'receipt_path':str(receipt_path),'receipt_sha256':digest(receipt_path),
 'key_artifacts':receipt['key_artifacts'],'counts':receipt['counts'],
 'modes_verified':True,'independent_review':'PENDING','typed_overlay':'NOT RECEIVED'}
summary_path=O/'phase1_freeze_stdout.json'
dump(summary_path,summary)
summary_path.chmod(0o444)
print(json.dumps(summary,ensure_ascii=False))
