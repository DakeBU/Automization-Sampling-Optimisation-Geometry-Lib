from pathlib import Path
from datetime import datetime, timezone
import copy
import gzip
import hashlib
import json
import os
import subprocess
import sys

ROOT = Path('/Users/zhouhuanjian/ASTIS-GC')
sys.path[:0] = [str(ROOT / 'tools'), str(ROOT / 'website/scripts')]
import astis_advance as advance
import astis_semantic_roundtrip as semantic
import astis_publication as publication

BASE = ROOT / 'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-admissibility-semantic-evidence'
OWN = BASE / 'fresh-source-reader-742806'
FROZEN = OWN / 'phase3'
OUT = OWN / 'phase3-verification-transition'
AUDIT = ROOT / 'research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-admissibility.json'
ADVANCE_ID = 'ASTIS-SA-20261107-GaussianComplexityFixedSpectrumAdmissibility'
REVIEWER = '/root/reader_742806'
HEAD = '83fec39dfa6202cdf9bc687affb10aafbc216ab8'
DECLARATION = 'AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumAdmissibility.actual_precision_admissible'
CANONICAL_PACKET = '50a751a10e22704a5002fe3ae515f3874533e0e077369f9a8ca935e11fe4d2ce'
RUN_SHA = 'abc8e8a02fc23935b421a0d3e2cc71fac3e03b383041428312956def9977ed9d'
BINDING = 'e4e245c817d124b16e93b4f999df81132f1e50a9e38535903cb5c036417c0e94'

def sha(b):
    return hashlib.sha256(b).hexdigest()

def put(name, obj):
    (OUT / name).write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n')

def canon_sha(obj):
    return sha(json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode())

def head():
    return subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()

def cells():
    return {str(p.relative_to(ROOT)): sha(p.read_bytes())
            for p in sorted((ROOT / 'research-wiki/frontier-cells').glob('*.json'))}

assert OUT.is_dir() and not (OUT / 'audit.before.raw.json').exists()
assert head() == HEAD
pins = json.loads((BASE / 'full-review-input-pins.json').read_text())
for path, digest in pins['exact_inputs'].items():
    assert sha((ROOT / path).read_bytes()) == digest, path
frozen_manifests = {}
for name in ['phase1', 'phase2', 'phase3']:
    directory = OWN / name
    m = json.loads((directory / 'manifest.json').read_text())
    digest = sha((directory / 'manifest.json').read_bytes())
    assert digest == (directory / 'manifest.sha256').read_text().split()[0]
    for f in m['files']:
        assert sha((directory / f['path']).read_bytes()) == f['sha256'], f['path']
    frozen_manifests[name] = digest
assert frozen_manifests['phase3'] == '514f6f00525752261b570858d549aa5d7e67f2cccee9f6dec00546e3dbfdb2b4'
projection_bytes = (FROZEN / 'proposed-canonical-audit-projection.json').read_bytes()
assert sha(projection_bytes) == '1921ddceb98c0d3e4429d605567b95f37f69a4e0fbdfaa017159d7322a1d116c'
projection = json.loads(projection_bytes)
assert projection['review_run_sha256'] == RUN_SHA
assert sha((FROZEN / 'independent-review-run.json').read_bytes()) == RUN_SHA
assert projection['reviewer_packet_sha256'] == CANONICAL_PACKET
assert projection['publication_binding_sha256'] == BINDING

ledger = ROOT / 'runs/substantive_advances.jsonl'
discovery = ROOT / 'runs/substantive_discoveries.jsonl'
before_ledger = ledger.read_bytes()
before_discovery = discovery.read_bytes()
before_states = advance.current_advances()
before_discoveries = advance.current_discoveries()
before_cells = cells()
before_audit = AUDIT.read_bytes()
old_audit = json.loads(before_audit)
target_before = before_states[ADVANCE_ID]
foreign_before = {k: v for k, v in before_states.items() if k != ADVANCE_ID}
assert target_before['state'] == 'PROVED_LOCAL'
assert target_before['owner_id'] == 'huanjian_gc_20261107_fixed_spectrum_admissibility'
assert target_before['owner_id'] != REVIEWER
assert target_before['publication_declarations'] == [DECLARATION]
assert len(foreign_before) == 281 and len(before_cells) == 441
assert not [k for k, v in before_states.items() if v['state'] == 'STABILIZING']
assert sha(before_audit) == '3275a552f1c2d21e96a93dc68f8ec19718cde33ef0f1c251812c57534608347f'
(OUT / 'audit.before.raw.json').write_bytes(before_audit)
(OUT / 'advance-ledger.before.raw.jsonl.gz').write_bytes(gzip.compress(before_ledger, mtime=0))
(OUT / 'discovery-ledger.before.raw.jsonl.gz').write_bytes(gzip.compress(before_discovery, mtime=0))
put('states.before.json', before_states)
put('discoveries.before.json', before_discoveries)
put('frontier-cell-hashes.before.json', before_cells)
protected_paths = ['AutoSamplingTheory.lean', 'Tests.lean',
                   'AutoSamplingTheory/TechnicalLemmas/Registry.lean', 'README.md',
                   'research-wiki/semantic-roundtrip/registry.json']
protected_before = {p: sha((ROOT / p).read_bytes()) for p in protected_paths}
foreign_audits_before = {str(p.relative_to(ROOT)): sha(p.read_bytes())
                         for p in sorted(AUDIT.parent.glob('*.json')) if p != AUDIT}
put('protection.before.json', {
    'HEAD': HEAD, 'advance_ledger_sha256': sha(before_ledger),
    'discovery_ledger_sha256': sha(before_discovery),
    'advance_ledger_bytes': len(before_ledger), 'discovery_ledger_bytes': len(before_discovery),
    'foreign_states_count': len(foreign_before), 'frontier_cells_count': len(before_cells),
    'STABILIZING': [], 'protected_file_hashes': protected_before,
    'foreign_audit_hashes': foreign_audits_before,
    'frozen_manifests': frozen_manifests
})

# Project only the independently frozen review fields, preserving all payloads.
new_audit = copy.deepcopy(old_audit)
for key in ['semantic_slots', 'deltas', 'verdict', 'repairs']:
    new_audit[key] = copy.deepcopy(projection[key])
new_audit['state'] = 'accepted'
new_audit['source_review'] = {
    'state': 'accepted',
    'reviewer': REVIEWER,
    'independent_from_formalizer': True,
    'independent_from_decoder': True,
    'evidence': projection['review_evidence'],
    'review_run_sha256': RUN_SHA,
    'reviewer_packet_sha256': CANONICAL_PACKET,
    'run_artifact': str((FROZEN / 'independent-review-run.json').relative_to(ROOT))
}
for key in ['id', 'source', 'lean', 'reconstruction',
            'publication_binding_sha256', 'publication_context']:
    assert new_audit[key] == old_audit[key], key
assert semantic.semantic_reviewer_packet(new_audit)['packet_sha256'] == CANONICAL_PACKET
registry = semantic.load_registry()
matches = [i for i, a in enumerate(registry['audits']) if a['id'] == old_audit['id']]
assert len(matches) == 1
registry['audits'][matches[0]] = new_audit
errors = semantic.validate_registry(registry)
put('in-memory-normal-semantic-preflight.json', {'errors': errors, 'audits': len(registry['audits'])})
assert not errors, errors
after_audit_bytes = (json.dumps(new_audit, ensure_ascii=False, indent=2) + '\n').encode()
temporary = AUDIT.with_name(AUDIT.name + '.reader-742806.tmp')
assert not temporary.exists()
with temporary.open('wb') as handle:
    handle.write(after_audit_bytes)
    handle.flush()
    os.fsync(handle.fileno())
os.replace(temporary, AUDIT)
(OUT / 'audit.accepted.raw.json').write_bytes(AUDIT.read_bytes())
assert AUDIT.read_bytes() == after_audit_bytes
print('CANONICAL_AUDIT_ACCEPTED', sha(before_audit), sha(after_audit_bytes), flush=True)

# Actual normal semantic/publication checks; these are read-only gates.
semantic_errors = semantic.validate_registry(semantic.load_registry())
put('normal-semantic-gate.json', {'errors': semantic_errors})
assert not semantic_errors, semantic_errors
publication.check_advance([DECLARATION], reviewed=True)
put('normal-publication-gate.json', {
    'official_API': 'astis_publication.check_advance',
    'declarations': [DECLARATION], 'reviewed': True, 'passed': True
})
print('NORMAL_SEMANTIC_AND_REVIEWED_PUBLICATION_GATES_PASSED', flush=True)

evidence = {
    'verifier_id': REVIEWER,
    'verified_commit': HEAD,
    'result_kind': 'theorem-edge',
    'lean_declarations': [DECLARATION],
    'publication_declarations': [DECLARATION],
    'publication_binding_sha256': BINDING,
    'gate': {
        'fresh_Lean_and_Test': str((FROZEN / 'receipts').relative_to(ROOT)),
        'source_review_run_sha256': RUN_SHA,
        'normal_semantic': str((OUT / 'normal-semantic-gate.json').relative_to(ROOT)),
        'normal_reviewed_publication': str((OUT / 'normal-publication-gate.json').relative_to(ROOT)),
        'passed': True
    },
    'source_audit': {
        'audit_id': old_audit['id'],
        'audit_file': str(AUDIT.relative_to(ROOT)),
        'audit_accepted_sha256': sha(after_audit_bytes),
        'state': 'accepted',
        'verdict': projection['verdict'],
        'reviewer_packet_sha256': CANONICAL_PACKET,
        'review_run_sha256': RUN_SHA,
        'seven_slots': str((FROZEN / 'seven-semantic-slots.final.json').relative_to(ROOT)),
        'OR_route_boundary': str((FROZEN / 'actual-proof-OR-route-and-source-gap-map.json').relative_to(ROOT))
    },
    'fake_closure_scan': {
        'artifact': str((FROZEN / 'whole-module-and-fake-closure.json').relative_to(ROOT)),
        'artifact_sha256': sha((FROZEN / 'whole-module-and-fake-closure.json').read_bytes()),
        'standard_axioms_only': True,
        'actual_axiom_parent_probe': str((FROZEN / 'receipts/ancestry-probe.stdout.raw').relative_to(ROOT))
    },
    'focused_checks': [
        str((FROZEN / 'receipts' / p).relative_to(ROOT))
        for p in ['focused-lake-build.receipt.json', 'producer-direct.receipt.json',
                  'canonical-density-direct.receipt.json', 'same-A-Test-direct.receipt.json',
                  'ancestry-probe.receipt.json']
    ],
    'reader_evidence': str((FROZEN / 'static-reader-check.json').relative_to(ROOT)),
    'truth_boundary': [
        'Bounded actual admissibility and genuine same-A Gaussian density consumer only.',
        'Historical strict angle/cosine/eigenvalue source nodes remain unproved; valid closed-envelope OR route used.',
        'Full C4 determinant/known-normalizer product/calculus/Hessian/minimizer, moments/Krylov, algorithm/TV/cost adapters and main bounds remain open.',
        'Root integration, Registry, site/browser/public delivery, purification/Exposition Seal, remote and whole-Goal completion are separate.'
    ]
}
put('normal-VERIFIED-request.json', {
    'API': 'astis_advance.transition_advance',
    'advance_id': ADVANCE_ID, 'to_state': 'VERIFIED',
    'worker_id': REVIEWER, 'evidence': evidence,
    'authorization': 'Explicit root authorization after independent phase3 hash verification; exactly one normal transition requested.'
})
assert head() == HEAD
assert ledger.read_bytes() == before_ledger
assert discovery.read_bytes() == before_discovery
print('INVOKING_EXACTLY_ONE_NORMAL_VERIFIED_API', ADVANCE_ID, REVIEWER, flush=True)
advance.transition_advance(
    ADVANCE_ID, 'VERIFIED', worker_id=REVIEWER,
    modes=['source', 'Lean', 'reader', 'independent-verification'],
    evidence=evidence
)
print('NORMAL_VERIFIED_API_RETURNED', flush=True)

after_ledger = ledger.read_bytes()
after_discovery = discovery.read_bytes()
after_states = advance.current_advances()
after_discoveries = advance.current_discoveries()
after_cells = cells()
assert after_ledger.startswith(before_ledger)
append = after_ledger[len(before_ledger):]
events = [json.loads(line) for line in append.splitlines() if line.strip()]
assert len(events) == 1
event = events[0]
assert event['event'] == 'transition'
assert event['advance_id'] == ADVANCE_ID
assert event['from_state'] == 'PROVED_LOCAL' and event['to_state'] == 'VERIFIED'
assert event['worker_id'] == REVIEWER
assert event['evidence']['publication_declarations'] == event['evidence']['lean_declarations'] == [DECLARATION]
assert after_states[ADVANCE_ID]['state'] == 'VERIFIED'
assert after_states[ADVANCE_ID]['owner_id'] == target_before['owner_id']
assert {k: v for k, v in after_states.items() if k != ADVANCE_ID} == foreign_before
assert after_discovery == before_discovery and after_discoveries == before_discoveries
assert after_cells == before_cells
assert not [k for k, v in after_states.items() if v['state'] == 'STABILIZING']
for key, value in target_before.items():
    if key not in {'state', 'last_actor', 'modes', 'latest_evidence', 'updated_at'}:
        assert after_states[ADVANCE_ID][key] == value, key
assert head() == HEAD
for p, digest in protected_before.items():
    assert sha((ROOT / p).read_bytes()) == digest, p
for p, digest in foreign_audits_before.items():
    assert sha((ROOT / p).read_bytes()) == digest, p
for path, digest in pins['exact_inputs'].items():
    if path not in {str(AUDIT.relative_to(ROOT)), str(ledger.relative_to(ROOT))}:
        assert sha((ROOT / path).read_bytes()) == digest, path
for name, digest in frozen_manifests.items():
    m = json.loads((OWN / name / 'manifest.json').read_text())
    assert sha((OWN / name / 'manifest.json').read_bytes()) == digest
    for f in m['files']:
        assert sha((OWN / name / f['path']).read_bytes()) == f['sha256']

(OUT / 'advance-ledger.append.raw.jsonl').write_bytes(append)
(OUT / 'advance-ledger.after.raw.jsonl.gz').write_bytes(gzip.compress(after_ledger, mtime=0))
(OUT / 'discovery-ledger.after.raw.jsonl.gz').write_bytes(gzip.compress(after_discovery, mtime=0))
put('states.after.json', after_states)
put('discoveries.after.json', after_discoveries)
put('frontier-cell-hashes.after.json', after_cells)
put('audit-field-preservation.json', {
    'before_sha256': sha(before_audit), 'accepted_sha256': sha(after_audit_bytes),
    'changed_top_level_fields': sorted(k for k in set(old_audit) | set(new_audit) if old_audit.get(k) != new_audit.get(k)),
    'preserved_exact_payloads': ['id', 'source', 'lean', 'reconstruction', 'publication_binding_sha256', 'publication_context'],
    'reviewer_packet_sha256': CANONICAL_PACKET, 'review_run_sha256': RUN_SHA,
    'accepted_state': new_audit['state'], 'accepted_source_review_state': new_audit['source_review']['state']
})
receipt = {
    'completed_at_utc': datetime.now(timezone.utc).isoformat(),
    'API_calls': 1,
    'actual_state': after_states[ADVANCE_ID]['state'],
    'actual_actor': REVIEWER,
    'proof_owner_before_after': target_before['owner_id'],
    'checked_immutable_commit': HEAD,
    'accepted_audit_sha256': sha(after_audit_bytes),
    'advance_ledger_before_sha256': sha(before_ledger),
    'advance_ledger_after_sha256': sha(after_ledger),
    'advance_ledger_before_bytes': len(before_ledger),
    'advance_ledger_after_bytes': len(after_ledger),
    'append_sha256': sha(append), 'append_bytes': len(append), 'append_events': 1,
    'exact_old_advance_prefix_preserved': True,
    'discovery_ledger_before_sha256': sha(before_discovery),
    'discovery_ledger_after_sha256': sha(after_discovery),
    'exact_old_discovery_prefix_preserved': True,
    'discovery_raw_and_replayed_states_unchanged': True,
    'all_foreign_advance_states_preserved': len(foreign_before),
    'foreign_advance_full_state_digest': canon_sha(foreign_before),
    'all_foreign_frontier_cells_preserved': 440,
    'all_frontier_cell_files_including_target_byte_unchanged': len(before_cells),
    'frontier_hash_map_digest': canon_sha(before_cells),
    'all_foreign_audit_fragments_preserved': len(foreign_audits_before),
    'protected_root_registry_readme_files_unchanged': True,
    'STABILIZING_before_after': [],
    'earlier_phase_manifests_and_payloads_unchanged': frozen_manifests,
    'semantic_gate_passed': True, 'reviewed_publication_gate_passed': True,
    'no_shared_cell_or_root_site_Registry_mutation': True,
    'no_integration_purification_remote_or_Goal_completion_claim': True
}
put('complete-preservation-receipt.json', receipt)
print(json.dumps(receipt, ensure_ascii=False, indent=2), flush=True)
