"""UI-only static comparison of the exact disabled v3 renderer and candidate."""
import dataclasses, hashlib, html, importlib.util, json, pathlib, re, sys, types
from html.parser import HTMLParser
from urllib.parse import urlsplit

D=pathlib.Path(__file__).resolve().parent
C='72e5d1405284f729f4eb600c5ae5dd556365b7e2'
P='AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumCosineGram.lean'
T='Tests/GaussianComplexityFixedSpectrumCosineGram.lean'
L='website/content/declaration_lessons/huanjian-fixed-spectrum-cosine-gram.json'
def sha(b): return hashlib.sha256(b).hexdigest()
def put(rel,b):
    p=D/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b if isinstance(b,bytes) else b.encode());return p
def js(rel,obj): return put(rel,json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
assert sha((D/'proposal.py').read_bytes())=='64b8768e27da03eebb93d0a5ef77a2b47481bb1f50d4a90fae32b92c94d2e05a'
assert sha((D/'production.py').read_bytes())=='b22394faeb8de07109826174d05856f4a561b20f9301e1f1d031b466fd6f2596'
sys.path[:0]=[str(D/'inputs/tools'),str(D/'inputs/website/scripts')]
shell=types.ModuleType('source_lineage')
shell.canonical_shell=lambda text,rel,output:text
sys.modules['source_lineage']=shell
import astis_site as base, inline_lean
base._ACTIVE_GIT=base.GitContext(commit=C,ref='isolated-ui-only-fixture',remote_url='',web_root='',commit_published=False,public_source_links=False,dirty_files=set())
base._ACTIVE_GATE=base.GateEvidence(passed=False,current=False,commit=C,source_digest='',generated_at='',commands=[],note='No native build credit from this UI-only fixture')
modules,decls=base.scan_project_sources(); base._SOURCE_BY_NAME={d.full_name:d for d in decls}
assert {m.source_file for m in modules}=={P,T,'AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumGridAlias.lean'}
unit=json.loads((D/'inputs'/L).read_bytes())['units'][0]
assert (D/'inputs'/L).read_bytes()==(pathlib.Path('/Users/zhouhuanjian/ASTIS-GC')/L).read_bytes()
renderers={}
for kind in ['production','proposal']:
    spec=importlib.util.spec_from_file_location('scope_'+kind,D/(kind+'.py'))
    mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
    mod.ROOT=D/'inputs'
    renderers[kind]=mod

class Node:
    def __init__(self,tag,attrs=None,parent=None):self.tag,self.attrs,self.parent,self.children=tag,dict(attrs or []),parent,[]
    def text(self):return ''.join(c if isinstance(c,str) else c.text() for c in self.children)
    def descendants(self,tag=None):
        found=[]
        for c in self.children:
            if isinstance(c,Node):
                if tag is None or c.tag==tag:found.append(c)
                found+=c.descendants(tag)
        return found
    def cls(self,c):return c in self.attrs.get('class','').split()
class DOM(HTMLParser):
    void={'area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr'}
    def __init__(self):super().__init__(convert_charrefs=True);self.root=Node('root');self.stack=[self.root]
    def handle_starttag(self,tag,attrs):
        n=Node(tag,attrs,self.stack[-1]);self.stack[-1].children.append(n)
        if tag not in self.void:self.stack.append(n)
    def handle_endtag(self,tag):
        assert self.stack[-1].tag==tag,(self.stack[-1].tag,tag)
        self.stack.pop()
    def handle_data(self,data):self.stack[-1].children.append(data)
def parse(s):
    d=DOM();d.feed(s);assert len(d.stack)==1;return d.root

records={};page=renderers['production'].lesson_path(unit['declaration'])
for kind,mod in renderers.items():
    text=mod.render_unit(unit,page);put('static/'+kind+'/'+page,text)
    root=parse(text)
    steps=[n for n in root.descendants('details') if n.cls('proof-reader-step')]
    assert len(steps)==6
    observed=[]
    for i,(node,s) in enumerate(zip(steps,unit['steps']),1):
        folds=[n for n in node.descendants('details') if n.children[0].tag=='summary' and n.children[0].text()=='Corresponding Lean step'];assert len(folds)==1
        fold=folds[0];codes=fold.descendants('code');assert len(codes)==1
        formula=[n for n in node.descendants('div') if n.cls('proof-reader-equation')];assert len(formula)==1
        literal=codes[0].text().encode();matches=[]
        for source in [P,T]:
            b=(D/'inputs'/source).read_bytes()
            count=b.count(literal)
            if count:
                a=b.index(literal);z=a+len(literal)
                matches.append({'file':source,'exact_byte_occurrences':count,'byte_start':a,'byte_end':z,
                    'start_line':b.count(b'\n',0,a)+1,'end_line_terminal_LF_preceding':b.count(b'\n',0,z-1)+1,
                    'whole_file_match':literal==b})
        observed.append({'step':i,'title':s['title'],'code_bytes':len(literal),'code_sha256':sha(literal),
          'code_exact':literal==s['lean'].encode(),'formula_exact':formula[0].text()=='\\['+s['formula']+'\\]',
          'outer_initially_closed':'open' not in node.attrs,'code_initially_closed':'open' not in fold.attrs,
          'fold_has_code_panel_attribute':'data-lean-code-panel' in fold.attrs,
          'copy_buttons':[n.text() for n in fold.descendants('button') if 'data-lean-copy' in n.attrs],
          'neighbor_anchors':[{'text':n.text(),'href':n.attrs.get('href'),'download':'download' in n.attrs} for n in fold.descendants('a')],
          'direct_inner_tags':[n.tag for n in fold.children if isinstance(n,Node)],'exact_known_file_matches':matches})
        assert all(observed[-1][k] for k in ['code_exact','formula_exact','outer_initially_closed','code_initially_closed'])
    records[kind]=observed
    # This executes the exact export_sources body and actual base.page function.
    # Only the unrelated global source_lineage canonical-shell overlay is identity.
    output=D/'static'/kind
    mod.export_sources(output,[unit])
    sourcehtml=output/'data/lesson-sources'/ (T+'.html')
    source_root=parse(sourcehtml.read_text())
    anchors=[n for n in source_root.descendants('span') if n.attrs.get('id')=='L13'];assert len(anchors)==1
    assert anchors[0].text().startswith('private theorem actual_gaussian_gram_means')
    precodes=[n for n in source_root.descendants('pre')];assert len(precodes)==1
    assert precodes[0].text().encode()==(D/'inputs'/T).read_bytes()
    download=output/'data/lesson-sources'/T
    record={'source_html_exists':True,'source_html_sha256':sha(sourcehtml.read_bytes()),
       'L13_actual_private_theorem':anchors[0].text(),'full_source_text_exact':True,
       'raw_source_download_exists':download.exists(),
       'raw_source_download_sha256':sha(download.read_bytes()) if download.exists() else None,
       'source_html_download_anchors':[n.attrs['href'] for n in source_root.descendants('a') if 'download' in n.attrs]}
    js('source-html-'+kind+'.json',record)

v3=renderers['proposal']; t=(D/'inputs'/T).read_bytes()
controls=[]
for label,step,custom_unit,wanted in [
    ('current full private Test',unit['steps'][5],unit,True),
    ('same complete file minus final LF',{**unit['steps'][5],'lean':unit['steps'][5]['lean'].rstrip('\n')},unit,False),
    ('one added LF',{**unit['steps'][5],'lean':unit['steps'][5]['lean']+'\n'},unit,False),
    ('current partial private Test moment snippet',unit['steps'][4],unit,False),
    ('current public production snippet',unit['steps'][0],unit,False),
    ('full Test absent local source citation',unit['steps'][5],{**unit,'sources':[s for s in unit['sources'] if not s.get('path')]},False)]:
    result=v3.complete_lean_step_actions(custom_unit,step,page)
    controls.append({'control':label,'actions_present':bool(result),'expected':wanted,'pass':bool(result)==wanted,'actions':result})
assert all(x['pass'] for x in controls)
assert all(not x['neighbor_anchors'] for x in records['proposal'][:5])
assert len(records['proposal'][5]['neighbor_anchors'])==2
assert not any(x['copy_buttons'] or x['fold_has_code_panel_attribute'] for x in records['proposal'])
assert sha(t)=='90b43f488d3fe9b6c95d4c039d0f771ee5bfecdd699b72dfa52465643f0b0dee'
for link in records['proposal'][5]['neighbor_anchors']:
    resolved=(D/'static/proposal'/pathlib.Path(page).parent/urlsplit(link['href']).path).resolve()
    assert resolved.is_file()
    if link['download']:assert resolved.read_bytes()==t
    else:assert urlsplit(link['href']).fragment=='L13'
js('static-fold-comparison.json',records)
js('exact-full-file-controls.json',controls)
js('fixture-scope.json',{'candidate':C,'proposal_sha256':sha((D/'proposal.py').read_bytes()),
  'production_sha256':sha((D/'production.py').read_bytes()),'lesson_sha256':sha((D/'inputs'/L).read_bytes()),
  'current_lesson_equals_candidate':True,'renderer_functions_unchanged':True,
  'fixtures':{'ROOT':'Only exact candidate input files under this follow-up directory',
    'GitContext':'unpublished isolated candidate, no public-source inference',
    'GateEvidence':'passed=false, no build credit',
    'source_lineage.canonical_shell':'identity overlay; sourceHTML content/export generated by exact export_sources plus actual base.page; no global shell, site or browser acceptance'},
  'original_frozen_review':'Untouched; original reader HOLD remains unchanged',
  'scope':'Prospective UI-only isolated static control. No mathematical verdict change, sourceV, shared adoption, native build, browser or global acceptance.'})
print(json.dumps({'proposal_scope':'Step6 exact full Test source context + raw download; sourceHTML gains exact raw download',
  'current_steps1_to5_neighbor_actions':False,'all_six_step_copy_buttons':False,'all_six_step_panel_attributes':False,
  'partial_private_step5_requires_T_context':True,'all_exactness_controls_pass':True,
  'reader_hold':'UNCHANGED; proposal is partial'},indent=2))
