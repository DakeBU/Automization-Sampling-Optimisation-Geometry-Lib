from pathlib import Path
from bs4 import BeautifulSoup
import hashlib,json
root=Path('.astis/semantic-neutral-20261110/cg_tc_8f2b60/phase1')
p=Path('.astis/huanjian-resume-20261103/2610.20492v1.html'); b=p.read_bytes(); s=BeautifulSoup(b,'html.parser')
lines=[]
for key in ['S4.Thmtheorem4','A3.SS2','A3.Thmtheorem5']:
 t=s.find(id=key)
 lines.append(f'ANCHOR {key} found={t is not None}')
 if t:
  lines.append('ANCESTORS '+str([(a.name,a.get('id'),a.get('class')) for a in [t,*list(t.parents)[:4]]]))
  for c in t.find_all(recursive=False):
   lines.append(str((c.name,c.get('id'),c.get('class'),c.get_text(' ',strip=True)[:250])))
out='\n'.join(lines)+'\n'; (root/'raw-00-dom-inventory.txt').write_text(out)
(root/'raw-00-dom-inventory-input.py').write_text('Exact script is preserved in command-transcript.jsonl; the raw source was parsed using bs4 html.parser.\n')
print(out)
