from pathlib import Path
import sys,subprocess,json,datetime,hashlib,time
root=Path('/Users/zhouhuanjian/ASTIS-GC/.astis/semantic-neutral-20261111/kr_src_c47e12')
label=sys.argv[1]
command=sys.argv[2:]
audit=root/'phase1'/'audit'
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
t0=time.monotonic()
result=subprocess.run(command,cwd='/Users/zhouhuanjian/ASTIS-GC',stdout=subprocess.PIPE,stderr=subprocess.PIPE)
ended=datetime.datetime.now(datetime.timezone.utc).isoformat()
(audit/(label+'.stdout')).write_bytes(result.stdout)
(audit/(label+'.stderr')).write_bytes(result.stderr)
receipt={'label':label,'argv':command,'cwd':'/Users/zhouhuanjian/ASTIS-GC','started_utc':started,'ended_utc':ended,'elapsed_seconds':time.monotonic()-t0,'exit_code':result.returncode,'stdout':{'path':label+'.stdout','bytes':len(result.stdout),'sha256':hashlib.sha256(result.stdout).hexdigest()},'stderr':{'path':label+'.stderr','bytes':len(result.stderr),'sha256':hashlib.sha256(result.stderr).hexdigest()}}
(audit/(label+'.receipt.json')).write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
sys.stdout.buffer.write(result.stdout); sys.stdout.buffer.flush()
sys.stderr.buffer.write(result.stderr); sys.stderr.buffer.flush()
raise SystemExit(result.returncode)
