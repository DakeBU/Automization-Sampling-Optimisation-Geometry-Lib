"""Freeze independent Phase 3 evidence and a five-field proposal; never apply it."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import runpy
import stat
import subprocess

ROOT = Path('/Users/zhouhuanjian/ASTIS-GC')
OUT = ROOT / '.astis/semantic-neutral-20261110/d_fresh_a6c943'
BASE = OUT / 'phase3-commit-inputs'
COMMIT = '65776f88e92b9680e6afe0d4c20b7390e4521241'
PARENT = '8c88749c51c87ce54c22e7910b366c0f9f3fba6d'
E = 'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-detector-semantic-evidence/'
P = 'AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumDetector.lean'
T = 'Tests/GaussianComplexityFixedSpectrumDetector.lean'
PACKET = E + 'fresh-source-reviewer-packet.json'
MAP = E + 'source-to-lean-map-v1.json'
LESSON = 'website/content/declaration_lessons/huanjian-fixed-spectrum-detector.json'
PUB = 'website/content/publications/huanjian-fixed-spectrum-detector.json'
SCHEMA = 'tools/astis_semantic_roundtrip_core.py'
CANONICAL_PACKET_SHA = '9525ebc96a14c49ea7694c6997103ac371ae5942b83356718ccaf05ce5aa751b'

def sha_bytes(data):
    return hashlib.sha256(data).hexdigest()

def sha_text(text):
    return sha_bytes(text.encode())

def canonical_sha(obj):
    return sha_text(json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(',', ':')))

def digest(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': sha_bytes(data)}

def rel(path):
    return str(path.relative_to(ROOT))

def write_json(path, obj):
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n')

assert subprocess.run(['git', 'rev-parse', COMMIT + '^'], cwd=ROOT, check=True,
                      stdout=subprocess.PIPE).stdout.decode().strip() == PARENT
expected = {
    P: '98d055da8ca5a10fe56874b19a58fb523511b9fc7c5ae13e20225e18340ed75a',
    T: 'f7732afeb3cac55734dc2b05fd68e72f353d9bae6f2be2bbfa0bc499788cbe3d',
    PACKET: '1d9d7688662ec3129522431a5f974a7c7b11408d3adc7eed9de953939e401555',
    MAP: 'c15236eee9c39cea7cbfb2b3e7bb03a780f51dae6d6cdbf49fa1d007858a5481',
    LESSON: '6a1af435bf8e3bb364fdcf0d491ff9d53b7e9570aa12c7a1ef7297dde25138ce',
    PUB: 'a24624478c7a54a71cb1aa11762f334bbd92c6dad5b28d05ab15a9fe318777b6',
    SCHEMA: '90049b13ea83ccc41876f9267fd2e1a8052acac42e89a1063f97ac5619d39058',
}
fixed_inputs = []
for filename, sha in expected.items():
    data = subprocess.run(['git', 'show', COMMIT + ':' + filename], cwd=ROOT,
                          check=True, stdout=subprocess.PIPE).stdout
    assert sha_bytes(data) == sha
    assert (BASE / filename).read_bytes() == data
    assert (ROOT / filename).read_bytes() == data
    fixed_inputs.append({
        'canonical_path': str(ROOT / filename),
        'commit_path': filename, 'commit': COMMIT,
        **digest(BASE / filename), 'working_tree_byte_equal': True,
    })

previous_freezes = []
for phase, receipt_sha in [
    ('phase1', 'f7a0179225df164d57079e25ec13057e31bbd3def0b22b6916ee73cc13d7abb8'),
    ('phase2', 'fd12155fe75bca7d2b867cd7228c18de9bf90600c5ea1445431b706da7698a80'),
]:
    receipt_path = OUT / (phase + '-freeze-receipt.json')
    assert digest(receipt_path)['sha256'] == receipt_sha
    receipt = json.loads(receipt_path.read_text())
    for artifact in receipt['artifacts']:
        path = Path(artifact['path'])
        assert path.is_relative_to(OUT)
        assert digest(path) == artifact
        assert stat.S_IMODE(path.stat().st_mode) == 0o444
    assert stat.S_IMODE(receipt_path.stat().st_mode) == 0o444
    previous_freezes.append({'receipt': digest(receipt_path),
                            'all_receipted_artifacts_unchanged': True})

packet = json.loads((BASE / PACKET).read_text())
packet_core = {key: value for key, value in packet.items() if key != 'packet_sha256'}
assert packet['packet_sha256'] == CANONICAL_PACKET_SHA == canonical_sha(packet_core)
selective = json.loads((OUT / 'phase2-selective-input.snapshot.json').read_text())
for key in ['source', 'lean', 'blind_reconstruction']:
    for field, value in selective[key].items():
        assert packet[key][field] == value

p_text = (BASE / P).read_text()
t_text = (BASE / T).read_text()
assert packet['candidate_publication_context']['current_lean_module'] == p_text
p_start = p_text.index('theorem actual_chebyshev_matrix_cosine ')
p_end = p_text.index(':= by', p_start)
p_header = p_text[p_start:p_end].rstrip()
header = re.fullmatch(r'theorem actual_chebyshev_matrix_cosine (.*?) :\n(.*)',
                      p_header, re.DOTALL)
assert header
public_type = '∀ ' + header.group(1) + ',\n' + header.group(2) + '\n'
assert public_type == packet['lean']['statement']
t_start = t_text.index('private theorem actual_rotated_gaussian_detector_event ')
t_end = t_text.index(':= by', t_start)
private_type = t_text[t_start:t_end].rstrip() + '\n'
assert private_type == selective['exact_private_consumer_statement']

lesson = json.loads((BASE / LESSON).read_text())['units'][0]
publication = json.loads((BASE / PUB).read_text())['items'][0]
context = packet['candidate_publication_context']
assert all(lesson[key] == value for key, value in context['lesson'].items())
for key in ['source', 'statement', 'formulae', 'assumptions', 'obligations']:
    assert publication[key] == context[key]
assert publication['bindings'][0]['boundary'] == lesson['boundary']
assert len(lesson['steps']) == 6
reader_steps = []
for number, step in enumerate(lesson['steps'], 1):
    module = p_text if number <= 3 else t_text
    start = module.find(step['lean'])
    assert start >= 0
    if number == 6:
        assert step['lean'] == t_text
    reader_steps.append({
        'step': number, 'module': P if number <= 3 else T,
        'literal_code_sha256': sha_text(step['lean']),
        'literal_code_bytes': len(step['lean'].encode()),
        'start_line': module[:start].count('\n') + 1,
        'end_line_inclusive': module[:start + len(step['lean'])].count('\n'),
        'literal_substring_match': True,
        'complete_Test_byte_equal': number == 6,
    })

source_map = json.loads((BASE / MAP).read_text())
assert len(source_map['rows']) == 27
locator_checks = []
for row in source_map['rows']:
    spec = row['lean']
    path = ROOT / spec['file'] if spec['file'].startswith('.lake/') else BASE / spec['file']
    data = path.read_bytes()
    assert sha_bytes(data) == spec['file_sha256']
    text = data.decode()
    lines = text.splitlines()
    assert lines[spec['line'] - 1].startswith(spec['exact_start_marker'])
    if row['id'] in {'P-type', 'C-type'}:
        start = text.index(spec['exact_start_marker'])
        stop = text.index(':= by', start)
        block = text[start:stop].rstrip()
        convention = 'literal declaration header before := by, right-trimmed'
    elif spec['file'].startswith('.lake/'):
        block = '\n'.join(lines[spec['line'] - 1:spec['end_line']])
        convention = 'inclusive line excerpt, LF-joined, no final LF'
    else:
        block = '\n'.join(lines[spec['line'] - 1:spec['end_line'] - 1]) + '\n'
        convention = 'literal proof substring to next block boundary, terminal LF retained; end_line exclusive'
    assert sha_text(block) == spec['exact_locator_block_sha256'], row['id']
    locator_checks.append({
        'id': row['id'], 'file': spec['file'], 'line': spec['line'], 'end_line': spec['end_line'],
        'file_sha256': spec['file_sha256'], 'block_sha256': sha_text(block),
        'hash_convention': convention, 'all_exact_checks_passed': True,
    })

source = ROOT / '.astis/huanjian-resume-20261103/2610.20492v1.html'
assert digest(source)['sha256'] == '6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
source_anchors = ['S4.E11', 'S4.EGx2', 'S4.SS3.p4.1',
                  'S4.Thmtheorem5', 'S4.SS2.SSS0.Px3.p2.1']
parsed = runpy.run_path(str(OUT / 'extract_source.py'))
source_parts = []
for anchor in source_anchors:
    node = next(n for n in parsed['p'].nodes if n.attrs.get('id') == anchor)
    source_parts.append(parsed['render'](node).strip())
source_excerpt = OUT / 'phase3-raw-source-checked.txt'
source_excerpt.write_text('\n\n'.join(source_parts) + '\n')

mathlib_manifests = [OUT / 'phase3-mathlib-excerpts' / name for name in
                     ['manifest-initial.json', 'manifest-additional.json', 'manifest-final.json']]
mathlib_inputs = []
for manifest in mathlib_manifests:
    for entry in json.loads(manifest.read_text()):
        assert digest(Path(entry['path']))['sha256'] == entry['sha256']
        assert digest(Path(entry['excerpt_path']))['sha256'] == entry['excerpt_sha256']
        mathlib_inputs.append(entry)

assert len(re.findall(r'^theorem ', p_text, re.MULTILINE)) == 1
assert len(re.findall(r'^private theorem ', t_text, re.MULTILINE)) == 1
assert not re.search(r'\b(sorry|admit|axiom)\b', p_text + '\n' + t_text)
call = 'AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumDetector.actual_chebyshev_matrix_cosine hd hκ O n'
assert call in t_text
assert 'rw [hT]' in t_text
checks = {
    'schema': 'independent-phase3-static-checks-v1',
    'commit': COMMIT, 'parent': PARENT,
    'packet_raw_sha256': expected[PACKET],
    'packet_canonical_sha256_independently_reproduced': CANONICAL_PACKET_SHA,
    'public_type_byte_equal_after_declaration_binder_rendering_to_phase2': True,
    'private_signature_byte_equal_to_phase2': True,
    'packet_full_P_byte_equal': True,
    'reader_and_publication_context_fields_match': True,
    'reader_step_code_checks': reader_steps,
    'source_map_rows_checked': locator_checks,
    'source_map_row_count': len(locator_checks),
    'source_code_direct_call_and_use': {'call': call, 'call_Test_lines': [63, 65],
                                        'rewrite_Test_line': 98, 'found': True},
    'public_declarations_in_P': 1, 'private_declarations_in_Test': 1,
    'placeholder_tokens_in_complete_P_Test': [],
    'Borel_branch_source_code_dependency_on_hT': False,
    'right_event_branch_source_code_dependency_on_hT': True,
    'native_compilation_or_kernel_extraction_run': False,
    'browser_or_renderer_check_run': False,
}
checks_path = OUT / 'phase3-static-checks.json'
write_json(checks_path, checks)

schema_content_ranges = [[25, 120], [548, 649]]
manifest = {
    'schema': 'fresh-source-review-phase3-input-exposure-v1',
    'reviewer': '/root/detector_fresh_source',
    'owned_directory': str(OUT),
    'candidate_commit': COMMIT, 'candidate_parent': PARENT,
    'git_operations': 'read-only git rev-parse COMMIT^ and git show COMMIT:path only; no status/history/log/commit message or mutation',
    'commit_fixed_inputs': fixed_inputs,
    'input_content_coverage': {
        P: 'complete module displayed/read', T: 'complete module displayed/read',
        PACKET: 'full JSON ingested; large initial display truncated, all mathematical fields subsequently covered by exact P/Test/lesson/publication content and specific metadata reads/comparisons',
        MAP: 'all 27 rows and header/boundary fields displayed/read',
        LESSON: 'all prose/formula/assumption/source/boundary fields displayed/read; all six lean code strings compared exactly to completely read modules',
        PUB: 'complete publication content displayed/read',
        SCHEMA: {'viewed_schema_ranges_inclusive': schema_content_ranges,
                 'additional_exposure': 'rg matches for semantic-slot/source-review/schema fields, including line numbers outside these ranges; full-file bytes copied/hashed only outside viewed ranges'},
    },
    'raw_paper': digest(source),
    'raw_paper_phase3_reread_anchors': source_anchors,
    'earlier_source_cognition_and_selective_review_unchanged': previous_freezes,
    'Mathlib_actual_content_inputs': mathlib_inputs,
    'Mathlib_targeted_name_searches': [
        {'file': 'Mathlib/LinearAlgebra/UnitaryGroup.lean', 'patterns': ['orthogonalGroup', 'mem_orthogonalGroup_iff'], 'output': 'matching lines only, then bounded relevant context'},
        {'file': 'Mathlib/Data/Matrix/Mul.lean', 'patterns': ['mulVec_mulVec', 'mulVec_diagonal', 'diagonal_mulVec'], 'output': 'matching lines only, then bounded relevant context'},
        {'file': 'Mathlib/RingTheory/Polynomial/Chebyshev.lean', 'patterns': ['def T', 'T_zero', 'T_one', 'T_add_two', 'T_natCast'], 'output': 'matching lines only, then bounded relevant context'},
    ],
    'raw_canonical_hash_diagnosis': {
        'initial_parent_label': '9525... supplied as raw SHA',
        'initial_packet_content_stopped_at_mismatch': True,
        'actual_raw_sha256': expected[PACKET],
        'parent_clarification_received': 'raw/canonical mislabeled, not a post-commit change; authorized raw1d9d...; do not regenerate packet',
        'canonical_hash_computation': 'remove packet_sha256; json.dumps ensure_ascii=False, sort_keys=True, separators=(comma,colon); UTF8 SHA256',
        'computed_canonical_sha256': CANONICAL_PACKET_SHA,
        'packet_changed': False,
    },
    'incidental_exposure_in_authorized_inputs': [
        'Lesson/publication boundary and source-map header contain historical topology v1 HOLD / minimal-v2 accepted assertions and graph/overlay hashes/node identifiers. These embedded strings were visible, but no old graph/topology verdict or underlying record was opened or relied upon.',
        'Candidate packet compiled:true and reader compiled-producer wording are visible unverified build assertions; this reviewer did not run or inspect native/kernel evidence.',
        'Publication assumption_deltas and packet candidate_assumptions were read as current candidate claims, independently checked, not as prior accepted verdicts.',
        'Initial whole-packet and nested-context prints were truncated; subsequent exact module/lesson/publication reads cover the mathematical content. No claim that each character of an omitted display was human-visible.',
        'The first snapshot script named declaration_publications as a prospective path, but stopped at the packet assertion before ever reaching/reading it; the actual authorized publications path was then used.',
    ],
    'prior_knowledge_and_independence': 'General mathematical knowledge disclosed in Phase1 remains applicable. Reviewer had no proof-construction role and is neither formalizer nor decoder. Phase1 raw-source reading and Phase2 selective comparison were frozen before implementation exposure. No claim of pretrained ignorance.',
    'not_opened': [
        'root native/kernel reports', 'prior graph/topology verdict files or graph/overlay contents',
        'process archives, Root plans/history or prior reviews/audits/deltas',
        'any other ASTIS implementation module beyond P/Test',
        'canonical semantic registry or state ledgers',
        'other chat/PBPS/SPHMC/Bench/ATLAS content',
        'frontend renderer or generated/public browser page',
    ],
    'not_executed': ['no Lean/native/kernel command', 'no V/API/STAB/registry transition',
                     'no Git mutation', 'no browser/network/API', 'no subagent',
                     'no canonical/ledger/frontier change'],
    'scope_of_final_proposal': 'narrow source/code/reader-content judgment only; no mathematical global/native/sourceV or rendered-delivery acceptance',
}
manifest_path = OUT / 'phase3-input-exposure-manifest.json'
write_json(manifest_path, manifest)

review_doc = OUT / 'phase3-full-module-reader-review.md'
run = {
    'schema': 'independent-source-code-reader-review-run-v1',
    'reviewer': '/root/detector_fresh_source',
    'formalizer': packet['roles']['formalizer'],
    'blind_decoder': packet['roles']['blind_decoder'],
    'independent_from_formalizer': True, 'independent_from_decoder': True,
    'candidate_commit': COMMIT, 'candidate_parent': PARENT,
    'reviewer_packet_raw_sha256': expected[PACKET],
    'reviewer_packet_canonical_sha256': CANONICAL_PACKET_SHA,
    'source': digest(source), 'inputs': fixed_inputs,
    'source_code_reader_review': digest(review_doc),
    'static_checks': digest(checks_path),
    'input_exposure_manifest': digest(manifest_path),
    'earlier_phase_freezes_preserved': previous_freezes,
    'judgment': {
        'source_semantics': 'accepted for declared source-extracted/generalized auxiliary',
        'complete_P_Test_source_code_argument': 'accepted by independent mathematical/code reading; native/kernel not checked',
        'actual_P_to_private_Test_call': 'present and materially consumed in right event branch',
        'Borel_branch': 'internally proved independently of hT',
        'right_event_branch': 'uses hT, orthogonality/norm transport and map_apply with derived measurability',
        'reader_content': 'six formula steps accurate; all literal code checked; step6 equals complete Test',
        'rendered_reader_delivery': 'not inspected/accepted',
        'Gaussian_pi_A_law_identification': 'explicit remaining boundary',
        'source_target_probability_and_main_lower_bounds': 'outside accepted scope',
        'source_repair': 'none proposed',
        'canonical_state_transition': 'none applied; five-field object is a proposal only',
    },
    'run_hash_convention': 'source_review.review_run_sha256 is SHA256 of this complete UTF8 JSON artifact bytes; receipt also gives its canonical JSON digest',
}
run_path = OUT / 'phase3-source-review-run.json'
write_json(run_path, run)
run_sha = digest(run_path)['sha256']

slot_data = {
    'objects': (
        'explicit-elaboration',
        'Eq11 and S4.EGx2 use the literal midpoint precision and first-kind matrix polynomial; S4.SS3.p4.1 uses the same-O cosine diagonal/geometry.',
        'Exact real Matrix/Fin grid, A=O Lambda O^T, B=(kappa-1)^(-1) scalar action, Polynomial.aeval in the real matrix algebra; Test uses actual multivariateGaussian 0 Lambda^(-1) and Rz=Oz.',
        'Blind text preserves the same objects and distinguishes matrix evaluation from entrywise evaluation and scalar reciprocal from matrix inverse.',
        'P26-39,42-60,80-92; Test21-37,44-65; raw S4.E11/S4.EGx2/S4.SS3.p4.1; inspected Mathlib diagonalAlgHom, conjStarAlgAut, T and multivariateGaussian definitions.'),
    'domains': (
        'explicit-elaboration',
        'Hard family d>=2,kappa>=2, full real O(d). Raw proof instance n=2q+1,tau=tau_dq; declared auxiliary explicitly includes all natural n and private all real tau.',
        'Public hd:2<=d,hkappa:2<=kappa,O:orthogonalGroup(Fin d) Real,n:Nat; private tau:Real and full Euclidean vector carrier, including zero.',
        'Blind text states d>=2,kappa>=2,both determinant signs and every natural n including zero, with no n upper bound.',
        'P26-39 and complete Test18-41; Mathlib UnitaryGroup280-325 distinguishes full from special group; Phase1/2 preserve the explicit generalization/source specialization.'),
    'quantifiers': (
        'explicit-elaboration',
        'Fixed-input algebraic bridge within the source hard family; all-natural-n quantification is the declared auxiliary generalization, not a claim that the raw paper prints an all-n theorem.',
        'Universal d,kappa,O,n with literal local definitions; private universal tau and pointwise hstat for every z. No random-O or algorithm/seed quantifier is required.',
        'Blind text has the same universal fixed-input quantifiers and deterministic definitions, with no existential diagonalization witness.',
        'P theorem and local lets; Test18-41,108-122; phase2 stronger-in-lean label concerned raw proof-use domain and remains preserved as an informational generalization delta.'),
    'assumptions': (
        'same',
        'For this declared hard-family algebraic auxiliary: d>=2,kappa>=2 and full orthogonality. Nonzero denominator, orthogonal identities, continuity and measurability are internal obligations, not source premise additions.',
        'Only hd,hkappa,O,n and private tau; no project Prop alias, moment/probability/concentration/query/cost or desired conclusion premise. hnz,hR,hSc,hEvent,hO,hnorm are derived internally.',
        'Blind reconstruction states precisely the public data and no extra condition on n or determinant.',
        'Complete P26-92; Test63-122, especially independent hSc/hEvent and hT-dependent hquad; no placeholder/axiom tokens in complete P/Test.'),
    'conclusion': (
        'explicit-elaboration',
        'Orthogonal polynomial transport expands the source T_n(cos theta)=cos(n theta) into the intrinsic matrix/cosine equality; source strict E_A={S_A>0} is preserved in the private component.',
        'Exact matrix equality; private MeasurableSet strict event and exact ENNReal mass equality under literal mu.map R. Sign,2*tau and zero boundary retained; no pi_A or probability lower bound.',
        'Blind reconstruction gives exactly the public real matrix equality with canonical first-kind polynomial evaluation.',
        'P hD/hB/hdiag/final rewrite; Test hT63-65,hquad94-107,hstat108-112,map113-122; raw S4.EGx2; Mathlib map_apply161-163 and actual norm/transpose/aeval contexts.'),
    'scopes': (
        'explicit-elaboration',
        'Declared source-extracted auxiliary plus private literal event-transport component; not Theorem4.1, Lemma4.5 moments, Ex26, normalized-weight theorem or full target-law identification.',
        'P only public matrix identity; Test private Borel/pushforward event equality. Complete code materially calls P. Reader scope explicitly leaves pi_A law, probability, concentration, algorithm/TV/query/cost and main lower bounds open.',
        'Blind text stops at the public matrix identity; private scope is supplied separately and reviewed as such.',
        'P docstring; Test docstring/signature/final proof; lesson assumptions/boundary and all six steps; publication source.scope and binding boundary; source-map27 rows. No rendered browser/native/global acceptance.'),
    'constant_dependencies': (
        'same',
        'Exact affine spectral constants 2,1/2,kappa+/-1,pi and frequency n; source specialization tau_dq and q-regime belong to later probability/lower-bound use.',
        'Same literal fractions/casts and correction 2*tau; no hidden C,delta,epsilon,d0,error or probability constant. hκ only supplies nonzero scalar reciprocal.',
        'Blind text retains literal real constants, scalar reciprocal, standard casts and no quantitative error.',
        'P26-39,61-79; Test21-41,108-122; lesson steps2,5,6; raw S4.E11/S4.EGx2.'),
}
slots = {}
for name, values in slot_data.items():
    relation, source_text, lean_text, reconstruction_text, evidence = values
    slots[name] = {
        'relation': relation, 'source': source_text, 'lean': lean_text,
        'reconstruction': reconstruction_text, 'evidence': evidence,
        'original': source_text, 'reconstructed': reconstruction_text,
    }
deltas = [
    {'slot': 'quantifiers', 'severity': 'informational',
     'description': 'All natural n, including zero, explicitly generalizes the raw proof frequency n=2q+1. This is valid for the algebraic auxiliary, retains the source instance by substitution, and gives no new query/probability regime. Phase2 raw-scope stronger-in-lean observation is preserved.',
     'evidence': 'Raw S4.SS3.p3.1; P26-39,80-92; packet source contract; lesson assumptions[2]; Mathlib T0/T1/recurrence and T_real_cos.'},
    {'slot': 'domains', 'severity': 'informational',
     'description': 'Private arbitrary real tau is an explicit event-transport generalization of source tau_dq; no tau-smallness or negative-threshold target-sign geometry is inferred.',
     'evidence': 'Test18-41,108-122; raw S4.EGx2 and S4.SS3.p4.1; lesson assumptions[3] and boundary.'},
    {'slot': 'scopes', 'severity': 'informational',
     'description': 'The source text field is a faithfully attributed auxiliary-contract paraphrase, not verbatim raw paper. The public result is an extracted algebraic bridge; private literal mu.map R is not yet pi_A and carries no target pass probability or full lower bound.',
     'evidence': 'Packet source and candidate source.wording_status; publication source.scope; complete Test docstring and type; raw S4.SS2.SSS0.Px3.p2.1 versus S4.SS3.Ex26; Phase1/2 frozen scope.'},
    {'slot': 'scopes', 'severity': 'informational',
     'description': 'Reader-content/code adjacency is verified, including full Test at step6. Rendered initial folding, generated public statement code fold and desktop/mobile/browser delivery were outside this phase and are not certified.',
     'evidence': 'Lesson progressive unit and six literal step lean fields; phase3-static-checks.json; lean_statement is prose; no renderer/browser opened.'},
]
proposal = {
    'state': 'source-reviewed', 'verdict': 'equivalent-after-elaboration',
    'semantic_slots': slots, 'deltas': deltas,
    'source_review': {
        'reviewer': '/root/detector_fresh_source',
        'independent_from_formalizer': True, 'independent_from_decoder': True,
        'reviewer_packet_sha256': CANONICAL_PACKET_SHA,
        'review_run_sha256': run_sha,
        'run_artifact': rel(run_path),
        'evidence': f'Independent Phase1 source-first and Phase2 selective freezes preserved. Complete P/Test at commit {COMMIT}, actual P-to-Test call, distinct Borel/right dependencies, real Mathlib contexts,27 exact locators and six reader-code steps reviewed. Detailed evidence: {rel(review_doc)}; {rel(checks_path)}; {rel(manifest_path)}. Accepted only declared auxiliary/source-code/reader-content semantics; not native/kernel, rendered delivery, canonical admission or sourceV/global completion. This is a proposal, no transition applied.',
        'state': 'accepted',
    },
}
proposal_path = OUT / 'phase3-proposal.json'
write_json(proposal_path, proposal)

# Standalone shape verification of this authored five-field proposal only.
# This is not the canonical registry validator, accepted-metadata gate or V/API.
assert set(proposal) == {'state', 'verdict', 'semantic_slots', 'deltas', 'source_review'}
assert set(slots) == set(slot_data) and len(slots) == 7
assert all(row['relation'] in {'same', 'equivalent', 'explicit-elaboration'} for row in slots.values())
assert all(all(isinstance(row[key], str) and row[key].strip() for key in
               ['source', 'lean', 'reconstruction', 'original', 'reconstructed', 'evidence'])
           for row in slots.values())
assert all(delta['slot'] in slots and delta['severity'] == 'informational'
           and delta['description'] and delta['evidence'] for delta in deltas)
assert proposal['source_review']['reviewer'] not in {
    packet['roles']['formalizer'], packet['roles']['blind_decoder']}
assert proposal['source_review']['review_run_sha256'] == digest(run_path)['sha256']
shape_path = OUT / 'phase3-proposal-shape-check.json'
write_json(shape_path, {
    'scope': 'own standalone five-field object shape only; not normal accepted metadata gate',
    'proposal': digest(proposal_path), 'top_five_fields_exact': True,
    'seven_slots_with_parent_fields_and_schema_aliases': True,
    'allowed_verdict_and_relations': True, 'blocking_deltas': 0,
    'source_review_required_fields_and_actual_run_hash': True,
    'reviewer_independence_identity_check': True,
    'canonical_state_or_registry_touched': False,
})

phase3_files = [OUT / 'freeze_phase3.py', OUT / 'phase3-initial-run.json',
                OUT / 'phase3-proposal.initial.json', review_doc, checks_path,
                source_excerpt, manifest_path, run_path, proposal_path, shape_path]
for directory in [BASE, OUT / 'phase3-mathlib-excerpts']:
    phase3_files.extend(sorted(path for path in directory.rglob('*') if path.is_file()))
assert len(phase3_files) == len(set(phase3_files))
receipt = {
    'schema': 'fresh-source-review-phase3-freeze-v1',
    'frozen_at_utc': datetime.now(timezone.utc).isoformat(),
    'candidate_commit': COMMIT, 'candidate_parent': PARENT,
    'reviewer_packet_raw_sha256': expected[PACKET],
    'reviewer_packet_canonical_sha256': CANONICAL_PACKET_SHA,
    'review_run_raw_sha256': run_sha,
    'review_run_canonical_json_sha256': canonical_sha(run),
    'earlier_phases_unchanged': previous_freezes,
    'proposal_only': True,
    'proposal_state': proposal['state'], 'proposal_verdict': proposal['verdict'],
    'source_review_state': proposal['source_review']['state'],
    'native_kernel_registry_API_STAB_browser_or_global_acceptance': False,
    'artifacts': [digest(path) for path in phase3_files],
    'freeze_policy': 'all listed new artifacts plus this receipt0444; nested phase3 snapshot/excerpt directories0555; earlier phases untouched; no canonical transition',
}
receipt_path = OUT / 'phase3-freeze-receipt.json'
write_json(receipt_path, receipt)
for path in phase3_files + [receipt_path]:
    path.chmod(0o444)
for directory in [BASE, OUT / 'phase3-mathlib-excerpts']:
    for path in sorted((p for p in directory.rglob('*') if p.is_dir()), reverse=True):
        path.chmod(0o555)
    directory.chmod(0o555)
assert all(stat.S_IMODE(path.stat().st_mode) == 0o444 for path in phase3_files + [receipt_path])
print(json.dumps({
    'proposal': digest(proposal_path), 'source_review_run': digest(run_path),
    'full_module_reader_review': digest(review_doc),
    'input_exposure_manifest': digest(manifest_path),
    'receipt': digest(receipt_path),
    'readonly_new_files_checked': len(phase3_files) + 1,
    'all_27_exact_locators_and_6_literal_reader_steps_checked': True,
    'previous_phases_unchanged': True,
}, ensure_ascii=False, indent=2))
