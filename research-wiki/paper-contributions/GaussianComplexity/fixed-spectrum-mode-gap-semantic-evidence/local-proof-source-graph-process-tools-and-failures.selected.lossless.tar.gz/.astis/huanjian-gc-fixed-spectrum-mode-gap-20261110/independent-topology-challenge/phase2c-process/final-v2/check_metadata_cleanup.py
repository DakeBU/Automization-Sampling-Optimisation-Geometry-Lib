"""Metadata/probe preservation/current-fact check only; no Lean or intake."""
from pathlib import Path
from collections import Counter
import datetime
import gzip
import hashlib
import json

B = Path('.astis/huanjian-gc-fixed-spectrum-mode-gap-20261110')
O = B / 'independent-topology-challenge/phase2c-process/final-v2'


def pin(p):
    data = p.read_bytes()
    return {'path': str(p), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def load(p):
    return json.loads(p.read_bytes())


expected = {
    'statement-seal-v2.json': '46b02334624aec52e560d50d895df0652f84c77eeecd97f4d15d72f2d9f7ee44',
    'metadata-successor-v2-diff.json': '0bbb4d0f3a259e5e0ea90fb216b09553848c34971fa45a70138c30bdce06d536',
    'owner-probe-cleanup-prepared.json': '6be017e2b6eed0891201a73955600da28a3538d87d733d0b00b707dc21f628dc',
    'owner-probe-cleanup-completed.json': '240297d72af5291d56b890026f62bd159cfd89ff1314cd8469965cb82b7b7959',
    'statement-seal-v1.json': '1f9228d5caa180bc26ae9e47dc86b2d4be074c499b670a9a9a639da67457fb0c',
    'strict-preproof-seal-projection-v2.json': '54b23ce1ccd86b780b8c2b38bb18ac3cf91b5102afefe15444b2231e1b65c0f9',
    'preseal-exposure-disclosure.json': '08207c77e45d95ba37a91ad3be958aaa4a8308dffb7b15174a007442d33f9b5e',
    'postseal-informal-planning-exposure.json': '67adfdd373c76b3b74fed6513305a192ae0de23e0ce86d741792e9df2f6813e0',
    'strict-projection-v2-minimization-lineage.json': '5b53fefc538d9fa2907cf3a102c9ca138453127fec538f6a2c6f9f25f709ae8f',
}
inputs = []
for name, h in expected.items():
    info = pin(B / name)
    assert info['sha256'] == h, name
    inputs.append(info)
old, new = load(B / 'statement-seal-v1.json'), load(B / 'statement-seal-v2.json')
declared = load(B / 'metadata-successor-v2-diff.json')
changed = sorted(k for k in old if old[k] != new.get(k))
added = sorted(set(new) - set(old))
assert changed == sorted(declared['changed_existing_top_level_fields']) == ['binder_audit', 'seal_id', 'state']
assert added == sorted(declared['new_top_level_fields']) == ['existential_output_audit', 'metadata_successor_lineage']
assert set(old) <= set(new)
unchanged = [k for k in old if k not in changed]
assert all(old[k] == new[k] for k in unchanged)
projection = load(B / 'strict-preproof-seal-projection-v2.json')
for owner in ['producer', 'actual_private_consumer']:
    assert new[owner] == old[owner]
    assert new[owner]['signature'] == projection[owner]['signature']
    assert hashlib.sha256(new[owner]['signature'].encode()).hexdigest() == projection[owner]['signature_sha256']
assert old['source'] == new['source'] == projection['source']
assert new['EXCESS_public_binders'] == []
expected_audit = []
for entry in old['binder_audit']:
    if entry['binder'] == 'EXISTS d0:Nat':
        continue
    if entry['binder'] == 'FORALL kappa:Real;2<=kappa':
        owner = entry['owner']
        expected_audit.extend([
            {'owner': owner, 'binder': 'FORALL kappa:Real', 'class': 'TYPING', 'reason': 'Pure real condition-parameter carrier.'},
            {'owner': owner, 'binder': '2<=kappa', 'class': 'SOURCE', 'reason': 'Exact original inclusive lower condition-parameter guard.'},
        ])
    else:
        expected_audit.append(entry)
assert new['binder_audit'] == expected_audit
assert len(new['binder_audit']) == 18
assert all(x['class'] in ['SOURCE', 'STANDING', 'TYPING', 'RULED', 'EXCESS'] for x in new['binder_audit'])
assert all('EXISTS' not in x['binder'] and x['class'] not in ['RULED', 'EXCESS'] for x in new['binder_audit'])
assert {x['owner'] for x in new['existential_output_audit']} == {'producer', 'private_consumer'}
for output in new['existential_output_audit']:
    assert output['class'] is None and output['is_input_hypothesis'] is False
    assert output['depends_only_on'] == ['δ']
    assert 'before universal d,κ,q' in output['scope_order']
    assert output['is_human_approved_correction_or_source_ruling'] is False
prepared, completed = load(B / 'owner-probe-cleanup-prepared.json'), load(B / 'owner-probe-cleanup-completed.json')
assert completed['prepared_record_sha256'] == expected['owner-probe-cleanup-prepared.json']
text_path, gzip_path = Path(prepared['exact_non_Lean_text_copy']['path']), Path(prepared['lossless_gzip']['path'])
text, compressed = text_path.read_bytes(), gzip_path.read_bytes()
decompressed = gzip.decompress(compressed)
assert len(text) == prepared['probe_bytes'] == 1650
assert text == decompressed
assert hashlib.sha256(text).hexdigest() == prepared['probe_raw_sha256'] == completed['raw_probe_sha256']
assert pin(text_path)['sha256'] == prepared['exact_non_Lean_text_copy']['sha256']
assert pin(gzip_path)['sha256'] == prepared['lossless_gzip']['sha256']
initial_facts = load(B / 'independent-topology-challenge/phase2c-process/current-path-and-receipt-facts.json')
initial_probe = initial_facts['current_observations']['formation_probe']['current_byte_pin_only_no_body_read']
assert initial_probe['sha256'] == hashlib.sha256(text).hexdigest() and initial_probe['bytes'] == len(text)
probe = Path(prepared['temporary_probe'])
targets = [Path(new['producer']['planned_file']), Path(new['actual_private_consumer']['planned_file'])]
observed_utc = datetime.datetime.now(datetime.timezone.utc).isoformat()
path_facts = [{'path': str(p), 'exists': p.exists(), 'is_file': p.is_file()} for p in [probe] + targets]
assert all(not p['exists'] and not p['is_file'] for p in path_facts)
receipt_pins = []
for evidence in initial_facts['exact_receipt_log_facts']:
    for name in ['receipt', 'log']:
        info = evidence[name]
        assert pin(Path(info['path'])) == info
        receipt_pins.append(info)
preserved = []
for sub, name in [('phase1', 'SHA256SUMS.phase1'), ('phase2a', 'SHA256SUMS.phase2a'),
                  ('phase2b', 'SHA256SUMS.phase2b-math'), ('phase2c-process', 'SHA256SUMS.initial-process-HOLD')]:
    base = B / 'independent-topology-challenge' / sub
    for line in (base / name).read_text().splitlines():
        h, filename = line.split('  ', 1)
        assert pin(base / filename)['sha256'] == h
    preserved.append(pin(base / name))
lineage = new['metadata_successor_lineage']
math_statement = B / 'independent-topology-challenge/phase2a/PHASE2A-STATEMENT-FREEZE.json'
math_graph = B / 'independent-topology-challenge/phase2b/PHASE2B-MATH-FREEZE.json'
initial_hold = B / 'independent-topology-challenge/phase2c-process/INITIAL-PROCESS-HOLD-FREEZE.json'
assert pin(math_statement)['sha256'] == lineage['mathematical_statement_freeze_sha256'] == '26cc9f367e9a9518d062d08570948921bb2789eb1d265c19d3c9e82b5279da86'
assert pin(math_graph)['sha256'] == lineage['mathematical_graph_freeze_sha256'] == '4f7af06cde92035f8419775027e3de5060600a1e6213309eb740d55014e2d2f2'
assert pin(initial_hold)['sha256'] == lineage['initial_process_HOLD_freeze_sha256'] == '3d649d03ea049442e6d14c6f3d7d3daf827dc117be9479dedf3f1466f6507f36'
graph_pins = []
for name, h in [('source-proof-graph.json', 'a2376d7ecdd2c186fe59c4b55db300ea5695bf046fb81c2b2902e01d1eb52ed0'),
                ('exact-target-coverage.json', '4aa3b58447de06c53f3195d4f73e0f9509e093fe72aaae0c18a67d7e6bf1e0d9'),
                ('root-subroot-closures.json', '9905d6e4fd66b8b2e264cdfd207ae7143ad85acad9440fc37a0846602ade96a9')]:
    info = pin(B / 'independent-source-graph/phase2' / name)
    assert info['sha256'] == h
    graph_pins.append(info)
result = {
    'run_id': 'MODE-GAP-FINAL-METADATA-CLEANUP-PROCESS-CHECK-V2-20261110',
    'check_result': 'PASS', 'input_pins': inputs,
    'independent_full_object_diff': {'changed_existing_top_level_fields': changed, 'added_top_level_fields': added,
                                     'all_other_original_fields_deep_equal': unchanged,
                                     'old_binder_audit': old['binder_audit'], 'new_binder_audit': new['binder_audit'],
                                     'new_output_audit': new['existential_output_audit']},
    'source_math_signatures_definitions_and_quantifier_payloads_unchanged': True,
    'input_output_classification_matches_frozen_independent_audit': True,
    'current_path_observation_utc': observed_utc, 'current_path_facts': path_facts,
    'archive_equality': {'raw_bytes': len(text), 'raw_sha256': hashlib.sha256(text).hexdigest(),
                         'non_Lean_text': pin(text_path), 'gzip': pin(gzip_path),
                         'decompression_equal_to_text_and_initial_HOLD_original_pin': True,
                         'formation_body_not_displayed_or_used_as_mathematical_evidence': True},
    'unchanged_real_receipts_and_logs': receipt_pins,
    'unchanged_prior_checksum_sets_and_all_members': preserved,
    'unchanged_mathematical_freezes': [pin(math_statement), pin(math_graph)],
    'unchanged_sourcegraph_coverage_closure_bindings': graph_pins,
    'initial_HOLD_preserved': pin(initial_hold),
    'historical_negative_claims_not_independently_certified': True,
    'informal_planning_and_late_probe_cleanup_chronology_retained': True,
    'no_target_proof_API_or_normal_intake_executed_by_reviewer': True,
}
O.mkdir(parents=True, exist_ok=True)
p = O / 'actual-repair-checks.json'
assert not p.exists()
p.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'result': pin(p), 'metadata_delta': changed, 'metadata_added': added,
                  'probe_and_target_paths_currently_absent': True}, indent=2))
