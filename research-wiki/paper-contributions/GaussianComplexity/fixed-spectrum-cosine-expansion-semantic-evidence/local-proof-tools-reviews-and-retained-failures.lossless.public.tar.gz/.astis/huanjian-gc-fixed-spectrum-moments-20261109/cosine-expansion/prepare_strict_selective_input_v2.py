"""Explicit whitelist projection. Full canonical publication context is PHASE3 only."""
from pathlib import Path
import hashlib,json
sha=lambda b:hashlib.sha256(b).hexdigest()
dump=lambda x:(json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode()
E=Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-cosine-expansion-semantic-evidence')
full=json.loads((E/'fresh-source-reviewer-packet.json').read_bytes())
assert full['packet_sha256']=='74a47b3eb5d33d778a273873f34382f926370894a577114833d7dfb97d8f8ead'
a=json.loads(Path('research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-cosine-expansion.json').read_bytes())
seal=json.loads(Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-cosine-expansion-statement-seal.json').read_bytes())
head,body=seal['actual_private_consumer']['signature'].split(' :\n',1)
consumer='∀'+head.removeprefix('private theorem actual_inverse_grid_cosine_series')+',\n'+body
white={
 'schema_version':1,'task':'selective-source-statement-reconstruction-comparison',
 'parent_canonical_packet_sha256':full['packet_sha256'],
 'source':{k:full['source'][k] for k in ['source_id','anchor','original_text','text_sha256']},
 'lean_statement':{k:full['lean'][k] for k in ['statement','statement_sha256']},
 'approved_definition_context':a['lean']['decoder_context'],
 'blind_reconstruction':{k:full['blind_reconstruction'][k] for k in ['text','text_sha256','decoder','decoder_packet_sha256','decoder_run_sha256','source_text_visible']},
 'private_consumer_statement':consumer}
assert set(white)=={'schema_version','task','parent_canonical_packet_sha256','source','lean_statement','approved_definition_context','blind_reconstruction','private_consumer_statement'}
assert set(white['lean_statement'])=={'statement','statement_sha256'}
assert sha(white['lean_statement']['statement'].encode())==white['lean_statement']['statement_sha256']
assert sha(white['blind_reconstruction']['text'].encode())==white['blind_reconstruction']['text_sha256']
for forbidden in ['candidate_publication_context','current_lean_module','lean_proof','lesson','publication_context','semantic_slots','deltas','verdict','repairs']:
    def keys(x):
        if isinstance(x,dict):
            for k,v in x.items():yield k;yield from keys(v)
        elif isinstance(x,list):
            for v in x:yield from keys(v)
    assert forbidden not in set(keys(white)),forbidden
raw=dump(white)
assert b' := by' not in raw and b'ACTUAL_TARGET' not in raw
base=Path('.astis/semantic-neutral-20261109/src_cosine_5d8c2a/phase2-inputs')
assert not base.exists();base.mkdir(parents=True)
(base/'selective-input.json').write_bytes(raw)
manifest={
 'scope':'Exactly one explicit-whitelist payload, no full canonical envelope is delivered at phase2. Parent canonical packet is a hash reference only until phase3.',
 'whitelisted_paths':['source.{source_id,anchor,original_text,text_sha256}','lean.{statement,statement_sha256}',
                      'blind_reconstruction.{text,text_sha256,decoder,decoder_packet_sha256,decoder_run_sha256,source_text_visible}',
                      'audit.lean.decoder_context','sealed private consumer anonymous literal statement'],
 'excluded':'All module/proof/lesson/publication context, declaration/file identifiers, prior source decisions/slots/deltas/repairs, proof graph and runtime evidence.',
 'files':[{'path':'selective-input.json','sha256':sha(raw),'bytes':len(raw)}],
 'phase1_must_be_frozen_before_delivery':True,'source_fidelity_or_independence_verdict':False}
(base/'manifest.json').write_bytes(dump(manifest))
(E/'strict-selective-phase2-input-v2.json').write_bytes(raw)
(E/'strict-selective-phase2-manifest-v2.json').write_bytes(dump(manifest))
(E/'phase2-input-exposure-failure-v1.json').write_bytes(dump({
 'classification':'IMPLEMENTATION_FAILED','subtype':'REVIEW_INPUT_EXPOSURE',
 'cause':'Root used the full canonical semantic-reviewer packet as if it were statement-only; its candidate_publication_context includes complete module and lesson.',
 'actual_HOLD':'.astis/semantic-neutral-20261109/src_cosine_27c4e1/phase2/hold-report.md',
 'actual_HOLD_sha256':'50d4e3dde2a142561959c71e7d80b57df2ff4746bbda9c16167301c95f8d3235',
 'old_phase2_freeze_sha256':'606d8809cee01c22a801eb75d0211fd9b85786254827e01b94af990c35c02258',
 'old_inputs_and_all_exposure_records_preserved':True,'old_reviewer_not_source_verifier_for_this_packet':True,
 'recovery':'A different fresh actor rereads raw source first; new explicit-whitelist phase2 projection is separately hash-bound. Full canonical packet is only phase3 after statement-only comparison freezes.',
 'mathematical_refutation_or_sourceV_credit':False}))
print(json.dumps({'strict_payload_sha256':sha(raw),'manifest_sha256':sha((base/'manifest.json').read_bytes()),
 'canonical_full_packet_unchanged':True,'new_source_review_or_proof_credit':False}))
