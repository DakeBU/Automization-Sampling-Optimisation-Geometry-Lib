"""Bounded, source-only locator. No project mathematical artifacts are read."""
from pathlib import Path
from html.parser import HTMLParser
import hashlib
import html
import json
import sys

BASE = Path(__file__).resolve().parent
SOURCE = Path('/Users/zhouhuanjian/ASTIS-GC/.astis/huanjian-resume-20261103/2610.20492v1.html')
PIN = '6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
RAW = SOURCE.read_bytes()
assert len(RAW) == 951991 and hashlib.sha256(RAW).hexdigest() == PIN
TEXT = RAW.decode('utf-8')
LINES = [0]
for index, character in enumerate(TEXT):
    if character == '\n':
        LINES.append(index + 1)
VOID = {'area', 'base', 'br', 'col', 'embed', 'hr', 'img', 'input', 'link', 'meta', 'param', 'source', 'track', 'wbr'}


class Node:
    def __init__(self, tag, attrs, parent=None, start=0):
        self.tag, self.attrs, self.parent = tag, dict(attrs), parent
        self.children, self.start, self.end = [], start, None


class Reader(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=False)
        self.root = Node('root', [])
        self.stack, self.ids = [self.root], {}

    def source_offset(self):
        line, column = self.getpos()
        return LINES[line - 1] + column

    def handle_starttag(self, tag, attrs):
        node = Node(tag, attrs, self.stack[-1], self.source_offset())
        self.stack[-1].children.append(node)
        if node.attrs.get('id'):
            self.ids[node.attrs['id']] = node
        if tag in VOID:
            node.end = self.source_offset() + len(self.get_starttag_text())
        else:
            self.stack.append(node)

    def handle_endtag(self, tag):
        for index in range(len(self.stack) - 1, 0, -1):
            if self.stack[index].tag == tag:
                self.stack[index].end = TEXT.index('>', self.source_offset()) + 1
                self.stack = self.stack[:index]
                return

    def handle_startendtag(self, tag, attrs):
        self.handle_starttag(tag, attrs)
        if tag not in VOID:
            self.stack[-1].end = self.source_offset() + len(self.get_starttag_text())
            self.stack.pop()

    def handle_data(self, data):
        self.stack[-1].children.append(data)

    def handle_entityref(self, name):
        self.handle_data(html.unescape('&' + name + ';'))

    def handle_charref(self, name):
        self.handle_data(html.unescape('&#' + name + ';'))


def normalized(node):
    if isinstance(node, str):
        return node
    if node.tag == 'math':
        return '$' + node.attrs.get('alttext', '') + '$'
    if node.tag in {'script', 'style'}:
        return ''
    text = ''.join(normalized(child) for child in node.children)
    return text + ('\n' if node.tag in {'p', 'div', 'section', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'tr', 'li'} else ' ' if node.tag in {'td', 'th'} else '')


READER = Reader()
READER.feed(TEXT)


def record(anchor):
    node = READER.ids[anchor]
    assert node.end is not None, anchor
    fragment = TEXT[node.start:node.end].encode('utf-8')
    byte_start = len(TEXT[:node.start].encode('utf-8'))
    return {
        'anchor': anchor, 'tag': node.tag,
        'byte_start_inclusive': byte_start,
        'byte_end_exclusive': byte_start + len(fragment),
        'raw_bytes': len(fragment),
        'raw_sha256': hashlib.sha256(fragment).hexdigest(),
        'line_start_1based': TEXT.count('\n', 0, node.start) + 1,
        'line_end_1based': TEXT.count('\n', 0, node.end) + 1,
        'boundary': 'Complete exact outer HTML element, original UTF-8 bytes, no newline normalization.',
    }


if __name__ == '__main__':
    if sys.argv[1:] and sys.argv[1] == '--manifest':
        anchors = sys.argv[2:]
        manifest = {
            'source_path': str(SOURCE), 'source_bytes': len(RAW), 'source_sha256': PIN,
            'fragment_hash_semantics': 'sha256(original UTF-8 byte slice [start,end)); offsets 0 based; full outer element.',
            'fragments': [record(anchor) for anchor in anchors],
        }
        (BASE / 'raw-source-manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
        print('raw-source-manifest.json written; fragments=' + str(len(anchors)))
    else:
        for anchor in sys.argv[1:]:
            node = READER.ids[anchor]
            print('\nANCHOR', anchor, '|', node.tag, node.attrs)
            print(normalized(node))
