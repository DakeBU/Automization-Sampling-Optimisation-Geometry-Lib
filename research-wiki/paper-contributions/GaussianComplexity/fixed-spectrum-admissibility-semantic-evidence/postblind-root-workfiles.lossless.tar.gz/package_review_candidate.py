from pathlib import Path
import hashlib,json,tarfile,gzip,subprocess,shutil
sha=lambda b:hashlib.sha256(b).hexdigest()
b=Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-admissibility-semantic-evidence')
out=b/'actual-checks/completed-executions'
for p in sorted(Path('.astis/huanjian-resume-20261103').glob('*-fixed-spectrum-admissibility-*.receipt.json')):
 r=json.loads(p.read_bytes());raw=Path(r['log']).read_bytes();assert sha(raw)==r['log_sha256']
 if (out/p.name).exists():continue
 shutil.copy2(p,out/p.name);z=out/(Path(r['log']).name+'.gz');z.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(z.read_bytes())==raw
private=Path('.astis/huanjian-fixed-spectrum-admissibility-20261107');files=sorted(p for p in private.iterdir() if p.is_file());archive=b/'postblind-root-workfiles.lossless.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz') as t:
 for p in files:t.add(p,arcname=p.name,recursive=False)
with tarfile.open(archive,'r:gz') as t:
 for p in files:assert t.extractfile(p.name).read()==p.read_bytes()
(b/'postblind-root-workfiles.manifest.json').write_text(json.dumps({'archive':str(archive),'sha256':sha(archive.read_bytes()),'files':[{'path':str(p),'member':p.name,'sha256':sha(p.read_bytes())} for p in files]},indent=2)+'\n')
roots=[b/'actual-checks',b/'blind-918537',b/'reader-boundary-correction',b/'fresh-source-reader-742806/phase1',Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-admissibility-integration-20261107/independent-integration-reader-review/proposal/reader-boundary-correction-review')]
paths=[p for root in roots for p in root.rglob('*') if p.is_file()]
paths += [b/x for x in ['phase2-selective-input.json','blind-adoption-receipt.json','postblind-root-workfiles.lossless.tar.gz','postblind-root-workfiles.manifest.json']]
paths += [Path(x) for x in ['website/content/declaration_lessons/huanjian-fixed-spectrum-admissibility.json','website/content/publications/huanjian-fixed-spectrum-admissibility.json','research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-admissibility.json']]
pack=b/'postblind-frozen-raw-packaging';pack.mkdir(exist_ok=False);rows=[];safe=[]
for p in paths:
 raw=p.read_bytes();ignored=subprocess.run(['git','check-ignore','-q','--',str(p)]).returncode==0
 binary=p.suffix in ['.gz','.zip','.png'] or b'\0' in raw
 bad=not binary and (any(line.endswith((b' ',b'\t',b'\r')) for line in raw.split(b'\n')) or raw.endswith(b'\n\n'))
 if ignored or bad:
  z=pack/(str(len(rows)).zfill(3)+'-'+p.name+'.gz');z.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(z.read_bytes())==raw
  rows.append({'original_path':str(p),'raw_sha256':sha(raw),'raw_bytes':len(raw),'gzip_path':str(z),'gzip_sha256':sha(z.read_bytes()),'reason':{'ignored':ignored,'frozen_whitespace_or_blank_EOF':bad},'original_retained_unmodified':True});safe.append(z)
 else:safe.append(p)
manifest=pack/'manifest.json';manifest.write_text(json.dumps({'rule':'Lossless packaging, no frozen original normalization/deletion. Restore exact input paths from gzip before replaying source manifests.','files':rows},indent=2)+'\n');safe.append(manifest)
subprocess.run(['git','add','--',*[str(p) for p in safe]],check=True)
r=subprocess.run(['git','diff','--cached','--check'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT);print(r.stdout.decode());assert r.returncode==0
print(json.dumps({'safe_paths':len(safe),'raw_packaged':len(rows),'phase2_in_progress_not_staged':True,'source_V':False}))
