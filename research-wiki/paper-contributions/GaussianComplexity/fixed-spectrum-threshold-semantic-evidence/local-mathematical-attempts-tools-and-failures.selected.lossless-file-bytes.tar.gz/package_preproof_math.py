from pathlib import Path
import json, hashlib, tarfile, io, gzip, re
W=Path(__file__).parent
B=Path('.astis/semantic-neutral-20261110')
sha=lambda b:hashlib.sha256(b).hexdigest()
freeze_specs=[
 ('tau_sg_74c208/phase1','freeze.json','0d2fc3bdf9119791f2ee7ecc46f9c07ce875e2d5db74697e2a244eec92e8c9dc'),
 ('tau_sg_74c208/phase2','freeze.json','b72f4a4a31abb9b1b5cc359993f5bef80133964b0629793ee63c5da3f78713a5'),
 ('tau_sg_74c208/phase2-v2','freeze.json','7f2c34bf9a1ada4cc1c166c7912d59e47ced84f9fd2cc7a1d22e8c2e8bfb8a5f'),
 ('tau_tc_19abf4/phase1','FROZEN-MANIFEST.json','f28aba1f8685285b11bda9c555af55f03e63b204938ab45125f8b637a3e5d47e'),
 ('tau_tc_19abf4/phase2a','FROZEN-MANIFEST.json','b6f0d91a727569d03b74b9163bff16d0312a5884637c09b2409ebfadb12a52a2'),
 ('tau_tc_19abf4/phase2b','FROZEN-MANIFEST.json','2567748417894c9d7981b01f4db95492fe265e5e4773d8fc73f29b5dc67cd429'),
 ('tau_tc_19abf4/phase2b-v2','FROZEN-MANIFEST.json','5a6867cc2ac91ddce51f007fd0a2d9fa45de4366f5486012371b34727b19bf0c')]
files={}
for folder,fn,want in freeze_specs:
 d=B/folder;f=d/fn;assert sha(f.read_bytes())==want;obj=json.loads(f.read_bytes())
 if 'files' in obj:
  assert isinstance(obj['files'],list)
  for row in obj['files']:
   p=d/row['path'];raw=p.read_bytes();assert len(raw)==row['bytes'] and sha(raw)==row['sha256']
 else:
  sums=(d/'SHA256SUMS').read_bytes();assert sha(sums)==obj['sha256sums_sha256']
  for line in sums.decode().splitlines():
   h,n=line.split('  ',1);assert sha((d/n).read_bytes())==h
 for p in d.rglob('*'):
  if p.is_file():files[str(p.relative_to(B))]=p.read_bytes()
 if 'script' in obj:
  row=obj['script'];p=(d/row['path']).resolve();assert sha(p.read_bytes())==row['sha256']
  files[str(p.relative_to(B.resolve()))]=p.read_bytes()
privacy=re.compile(rb'wxid_[a-z0-9]{8,}|/Library/Containers/com\.tencent',re.I)
assert all(not privacy.search(raw) for raw in files.values())
archive=W/'preproof-source-graph-and-independent-math.lossless-file-bytes.tar.gz'
assert not archive.exists()
buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w') as tar:
 for name,raw in sorted(files.items()):
  ti=tarfile.TarInfo(name);ti.size=len(raw);ti.mode=0o444;ti.mtime=0;tar.addfile(ti,io.BytesIO(raw))
archive.write_bytes(gzip.compress(buf.getvalue(),mtime=0))
with tarfile.open(archive,'r:gz') as tar:
 assert {m.name for m in tar.getmembers()}==set(files)
 for m in tar.getmembers():assert tar.extractfile(m).read()==files[m.name]
receipt={'kind':'Selected preproof source graph and distinct mathematical challenge frozen file-byte archive; no native/proof/process/global credit',
 'archive':{'path':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes())},
 'files':[{'path':n,'bytes':len(b),'sha256':sha(b)} for n,b in sorted(files.items())],
 'original_v1_HOLD_and_successor_v2_ACCEPT_both_retained':True,'source_graph_own_source_statuses_unchanged':True,
 'raw_foreign_states_or_preservation_snapshots_included':False,'known_private_locator_pattern_scan_passed':True,
 'lossless_claim':'All selected file bytes exact. Tar ownership/time/mode headers normalized; no filesystem-metadata preservation claim.',
 'prospective_process_permission_from_archive':False}
p=W/'preproof-source-graph-and-independent-math.archive-manifest.json';assert not p.exists();p.write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'archive_sha256':sha(archive.read_bytes()),'archive_bytes':archive.stat().st_size,'selected_exact_file_bytes_count':len(files),'raw_foreign_data':False,'proof_or_process_permission':False}))
