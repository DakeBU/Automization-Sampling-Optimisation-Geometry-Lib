from html.parser import HTMLParser
from pathlib import Path
import re, sys
SOURCE=Path('/Users/zhouhuanjian/ASTIS-GC/.astis/huanjian-resume-20261103/2610.20492v1.html')
class Node:
 def __init__(self,tag='',attrs=(),parent=None): self.tag,self.attrs,self.parent,self.children=tag,dict(attrs),parent,[]
class Parser(HTMLParser):
 def __init__(self): super().__init__(); self.root=Node(); self.cur=self.root; self.nodes=[]
 def handle_starttag(self,tag,attrs):
  n=Node(tag,attrs,self.cur);self.cur.children.append(n);self.nodes.append(n)
  if tag not in {'area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr'}: self.cur=n
 def handle_endtag(self,tag):
  n=self.cur
  while n.parent and n.tag!=tag:n=n.parent
  if n.parent:self.cur=n.parent
 def handle_data(self,data):self.cur.children.append(data)
def render(n):
 if isinstance(n,str):return n
 if n.tag=='math':
  if 'alttext' not in n.attrs:raise ValueError('Math without alttext')
  return ' $'+n.attrs['alttext']+'$ '
 if n.tag in {'script','style'}:return ''
 t=''.join(render(c) for c in n.children)
 if n.tag in {'p','div','section','h1','h2','h3','h4','li','tr','table','blockquote'}:
  return '\n'+('[ANCHOR '+n.attrs['id']+']\n' if 'id' in n.attrs else '')+t+'\n'
 return t
p=Parser();p.feed(SOURCE.read_text())
for ident in sys.argv[1:]:
 n=next(n for n in p.nodes if n.attrs.get('id')==ident)
 t=render(n)
 t=re.sub(r'[^\S\n]+',' ',t)
 t=re.sub(r'\n[ \t]+','\n',t)
 t=re.sub(r'\n{3,}','\n\n',t).strip()
 print(t+'\n')
