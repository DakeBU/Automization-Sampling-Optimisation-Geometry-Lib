import Tests.GaussianComplexityLaplaceTail
import Lean
open MeasureTheory ProbabilityTheory Lean Elab Term
open scoped BigOperators Matrix.Norms.L2Operator MatrixOrder ENNReal
noncomputable section
universe u v
elab "native_actual_T" : term => do
  let env ← getEnv
  let found := env.constants.toList.filter fun (n, _) =>
    n.toString.endsWith ".actual_source_four_sums_laplace_tail"
  unless found.length == 1 do throwError "Expected exactly one actual private T, found {found.length}"
  return mkConst found.head!.1
namespace NativeLiteralApplications

theorem literal_P :
∀ {Ω : Type v} [MeasurableSpace Ω] (μ : Measure Ω) [IsProbabilityMeasure μ]
    {ι : Type u} [Fintype ι] [DecidableEq ι] [Nonempty ι]
    (X : Ω → Matrix ι ι ℝ)
    (hX : AEStronglyMeasurable X μ)
    (hherm : ∀ᵐ ω ∂μ, (X ω).IsHermitian)
    (t : ℝ),
    μ {ω | t ≤ sSup (spectrum ℝ (X ω))} ≤
      ⨅ s : {s : ℝ // 0 < s},
        ENNReal.ofReal (Real.exp (-(s.val * t))) *
          ∫⁻ ω, ENNReal.ofReal (Matrix.trace (NormedSpace.exp (s.val • X ω))) ∂μ := by
  intro Ω inst μ instμ ι instι instDec instNon X hX hherm t
  exact AutoSamplingTheory.TechnicalLemmas.Probability.MatrixLaplaceTail.max_eigenvalue_tail_le_iInf_trace_exp μ X hX hherm t

theorem literal_T :
∀ {d q : ℕ} (hq : 2 * q + 1 < d),
  let D := EuclideanSpace ℝ (Fin d)
  let E := EuclideanSpace ℝ (Fin (q + 1))
  let Ω := Fin (q + 1) → D
  let μ : Measure Ω := Measure.pi (fun _ : Fin (q + 1) => stdGaussian D)
  let M := Matrix (Fin (q + 1) × Fin (q + 1)) (Fin (q + 1) × Fin (q + 1)) ℝ
  let r : ℝ := ((q + 1 : ℕ) : ℝ)
  let L : ℝ := 2 * r + 3 * Real.log (1000 * (d : ℝ))
  let α : Fin d → ℝ := fun i => ((i.val : ℝ) + 1 - 1 / 2) * Real.pi / (d : ℝ)
  let tvec : Fin d → Fin (q + 1) → ℝ := fun i k =>
    if k.val = 0 then 1 else Real.sqrt 2 * Real.cos ((k.val : ℝ) * α i)
  let row : Fin d → Ω → E := fun i ω =>
    WithLp.toLp 2 (fun b : Fin (q + 1) => ω b i)
  let Y : Fin d → Ω → M := fun i ω =>
    if ‖row i ω‖ ^ 2 ≤ L then
      (d : ℝ)⁻¹ • Matrix.kronecker
        (Matrix.vecMulVec (WithLp.ofLp (row i ω)) (WithLp.ofLp (row i ω)))
        (Matrix.vecMulVec (tvec i) (tvec i))
    else 0
  let mean : Fin d → M := fun i => ∫ ω, Y i ω ∂μ
  let Z : Fin d → Ω → M := fun i ω => Y i ω - mean i
  let w : Bool → Fin d → ℝ := fun useCos i =>
    if useCos = true then Real.cos (((2 * q + 1 : ℕ) : ℝ) * α i) else 1
  let sign : Bool → ℝ := fun minus => if minus = true then -1 else 1
  let S : Bool → Bool → Ω → M := fun useCos minus ω =>
    sign minus • ∑ i : Fin d, w useCos i • Z i ω
  ∀ s : ℝ, 0 < s → ∀ a : ℝ, ∀ useCos minus : Bool,
    μ {ω | a ≤ sSup (spectrum ℝ (S useCos minus ω))} ≤
      ENNReal.ofReal
        (Real.exp (-(s * a)) *
          ∫ ω, Matrix.trace (NormedSpace.exp (s • S useCos minus ω)) ∂μ) := by
  intro d q hq
  exact native_actual_T hq

theorem literal_T_q0 {d : ℕ} (hd : 1 < d) :
  let D := EuclideanSpace ℝ (Fin d)
  let E := EuclideanSpace ℝ (Fin (0 + 1))
  let Ω := Fin (0 + 1) → D
  let μ : Measure Ω := Measure.pi (fun _ : Fin (0 + 1) => stdGaussian D)
  let M := Matrix (Fin (0 + 1) × Fin (0 + 1)) (Fin (0 + 1) × Fin (0 + 1)) ℝ
  let r : ℝ := ((0 + 1 : ℕ) : ℝ)
  let L : ℝ := 2 * r + 3 * Real.log (1000 * (d : ℝ))
  let α : Fin d → ℝ := fun i => ((i.val : ℝ) + 1 - 1 / 2) * Real.pi / (d : ℝ)
  let tvec : Fin d → Fin (0 + 1) → ℝ := fun i k =>
    if k.val = 0 then 1 else Real.sqrt 2 * Real.cos ((k.val : ℝ) * α i)
  let row : Fin d → Ω → E := fun i ω =>
    WithLp.toLp 2 (fun b : Fin (0 + 1) => ω b i)
  let Y : Fin d → Ω → M := fun i ω =>
    if ‖row i ω‖ ^ 2 ≤ L then
      (d : ℝ)⁻¹ • Matrix.kronecker
        (Matrix.vecMulVec (WithLp.ofLp (row i ω)) (WithLp.ofLp (row i ω)))
        (Matrix.vecMulVec (tvec i) (tvec i))
    else 0
  let mean : Fin d → M := fun i => ∫ ω, Y i ω ∂μ
  let Z : Fin d → Ω → M := fun i ω => Y i ω - mean i
  let w : Bool → Fin d → ℝ := fun useCos i =>
    if useCos = true then Real.cos (((2 * 0 + 1 : ℕ) : ℝ) * α i) else 1
  let sign : Bool → ℝ := fun minus => if minus = true then -1 else 1
  let S : Bool → Bool → Ω → M := fun useCos minus ω =>
    sign minus • ∑ i : Fin d, w useCos i • Z i ω
  ∀ s : ℝ, 0 < s → ∀ a : ℝ, ∀ useCos minus : Bool,
    μ {ω | a ≤ sSup (spectrum ℝ (S useCos minus ω))} ≤
      ENNReal.ofReal
        (Real.exp (-(s * a)) *
          ∫ ω, Matrix.trace (NormedSpace.exp (s • S useCos minus ω)) ∂μ) := by
  exact native_actual_T (d := d) (q := 0) hd

theorem literal_T_q0_d2 :
  let D := EuclideanSpace ℝ (Fin 2)
  let E := EuclideanSpace ℝ (Fin (0 + 1))
  let Ω := Fin (0 + 1) → D
  let μ : Measure Ω := Measure.pi (fun _ : Fin (0 + 1) => stdGaussian D)
  let M := Matrix (Fin (0 + 1) × Fin (0 + 1)) (Fin (0 + 1) × Fin (0 + 1)) ℝ
  let r : ℝ := ((0 + 1 : ℕ) : ℝ)
  let L : ℝ := 2 * r + 3 * Real.log (1000 * (2 : ℝ))
  let α : Fin 2 → ℝ := fun i => ((i.val : ℝ) + 1 - 1 / 2) * Real.pi / (2 : ℝ)
  let tvec : Fin 2 → Fin (0 + 1) → ℝ := fun i k =>
    if k.val = 0 then 1 else Real.sqrt 2 * Real.cos ((k.val : ℝ) * α i)
  let row : Fin 2 → Ω → E := fun i ω =>
    WithLp.toLp 2 (fun b : Fin (0 + 1) => ω b i)
  let Y : Fin 2 → Ω → M := fun i ω =>
    if ‖row i ω‖ ^ 2 ≤ L then
      (2 : ℝ)⁻¹ • Matrix.kronecker
        (Matrix.vecMulVec (WithLp.ofLp (row i ω)) (WithLp.ofLp (row i ω)))
        (Matrix.vecMulVec (tvec i) (tvec i))
    else 0
  let mean : Fin 2 → M := fun i => ∫ ω, Y i ω ∂μ
  let Z : Fin 2 → Ω → M := fun i ω => Y i ω - mean i
  let w : Bool → Fin 2 → ℝ := fun useCos i =>
    if useCos = true then Real.cos (((2 * 0 + 1 : ℕ) : ℝ) * α i) else 1
  let sign : Bool → ℝ := fun minus => if minus = true then -1 else 1
  let S : Bool → Bool → Ω → M := fun useCos minus ω =>
    sign minus • ∑ i : Fin 2, w useCos i • Z i ω
  ∀ s : ℝ, 0 < s → ∀ a : ℝ, ∀ useCos minus : Bool,
    μ {ω | a ≤ sSup (spectrum ℝ (S useCos minus ω))} ≤
      ENNReal.ofReal
        (Real.exp (-(s * a)) *
          ∫ ω, Matrix.trace (NormedSpace.exp (s • S useCos minus ω)) ∂μ) := by
  exact native_actual_T (d := 2) (q := 0) (by norm_num)

theorem family_ordinary_positive :
  let D := EuclideanSpace ℝ (Fin 2)
  let E := EuclideanSpace ℝ (Fin (0 + 1))
  let Ω := Fin (0 + 1) → D
  let μ : Measure Ω := Measure.pi (fun _ : Fin (0 + 1) => stdGaussian D)
  let M := Matrix (Fin (0 + 1) × Fin (0 + 1)) (Fin (0 + 1) × Fin (0 + 1)) ℝ
  let r : ℝ := ((0 + 1 : ℕ) : ℝ)
  let L : ℝ := 2 * r + 3 * Real.log (1000 * (2 : ℝ))
  let α : Fin 2 → ℝ := fun i => ((i.val : ℝ) + 1 - 1 / 2) * Real.pi / (2 : ℝ)
  let tvec : Fin 2 → Fin (0 + 1) → ℝ := fun i k =>
    if k.val = 0 then 1 else Real.sqrt 2 * Real.cos ((k.val : ℝ) * α i)
  let row : Fin 2 → Ω → E := fun i ω =>
    WithLp.toLp 2 (fun b : Fin (0 + 1) => ω b i)
  let Y : Fin 2 → Ω → M := fun i ω =>
    if ‖row i ω‖ ^ 2 ≤ L then
      (2 : ℝ)⁻¹ • Matrix.kronecker
        (Matrix.vecMulVec (WithLp.ofLp (row i ω)) (WithLp.ofLp (row i ω)))
        (Matrix.vecMulVec (tvec i) (tvec i))
    else 0
  let mean : Fin 2 → M := fun i => ∫ ω, Y i ω ∂μ
  let Z : Fin 2 → Ω → M := fun i ω => Y i ω - mean i
  let w : Bool → Fin 2 → ℝ := fun useCos i =>
    if useCos = true then Real.cos (((2 * 0 + 1 : ℕ) : ℝ) * α i) else 1
  let sign : Bool → ℝ := fun minus => if minus = true then -1 else 1
  let S : Bool → Bool → Ω → M := fun useCos minus ω =>
    sign minus • ∑ i : Fin 2, w useCos i • Z i ω
  ∀ s : ℝ, 0 < s → ∀ a : ℝ, let useCos := false; let minus := false;
    μ {ω | a ≤ sSup (spectrum ℝ (S useCos minus ω))} ≤
      ENNReal.ofReal
        (Real.exp (-(s * a)) *
          ∫ ω, Matrix.trace (NormedSpace.exp (s • S useCos minus ω)) ∂μ) := by
  intro s hs a
  exact native_actual_T (d := 2) (q := 0) (by norm_num) s hs a false false

theorem family_ordinary_negative :
  let D := EuclideanSpace ℝ (Fin 2)
  let E := EuclideanSpace ℝ (Fin (0 + 1))
  let Ω := Fin (0 + 1) → D
  let μ : Measure Ω := Measure.pi (fun _ : Fin (0 + 1) => stdGaussian D)
  let M := Matrix (Fin (0 + 1) × Fin (0 + 1)) (Fin (0 + 1) × Fin (0 + 1)) ℝ
  let r : ℝ := ((0 + 1 : ℕ) : ℝ)
  let L : ℝ := 2 * r + 3 * Real.log (1000 * (2 : ℝ))
  let α : Fin 2 → ℝ := fun i => ((i.val : ℝ) + 1 - 1 / 2) * Real.pi / (2 : ℝ)
  let tvec : Fin 2 → Fin (0 + 1) → ℝ := fun i k =>
    if k.val = 0 then 1 else Real.sqrt 2 * Real.cos ((k.val : ℝ) * α i)
  let row : Fin 2 → Ω → E := fun i ω =>
    WithLp.toLp 2 (fun b : Fin (0 + 1) => ω b i)
  let Y : Fin 2 → Ω → M := fun i ω =>
    if ‖row i ω‖ ^ 2 ≤ L then
      (2 : ℝ)⁻¹ • Matrix.kronecker
        (Matrix.vecMulVec (WithLp.ofLp (row i ω)) (WithLp.ofLp (row i ω)))
        (Matrix.vecMulVec (tvec i) (tvec i))
    else 0
  let mean : Fin 2 → M := fun i => ∫ ω, Y i ω ∂μ
  let Z : Fin 2 → Ω → M := fun i ω => Y i ω - mean i
  let w : Bool → Fin 2 → ℝ := fun useCos i =>
    if useCos = true then Real.cos (((2 * 0 + 1 : ℕ) : ℝ) * α i) else 1
  let sign : Bool → ℝ := fun minus => if minus = true then -1 else 1
  let S : Bool → Bool → Ω → M := fun useCos minus ω =>
    sign minus • ∑ i : Fin 2, w useCos i • Z i ω
  ∀ s : ℝ, 0 < s → ∀ a : ℝ, let useCos := false; let minus := true;
    μ {ω | a ≤ sSup (spectrum ℝ (S useCos minus ω))} ≤
      ENNReal.ofReal
        (Real.exp (-(s * a)) *
          ∫ ω, Matrix.trace (NormedSpace.exp (s • S useCos minus ω)) ∂μ) := by
  intro s hs a
  exact native_actual_T (d := 2) (q := 0) (by norm_num) s hs a false true

theorem family_cos_positive :
  let D := EuclideanSpace ℝ (Fin 2)
  let E := EuclideanSpace ℝ (Fin (0 + 1))
  let Ω := Fin (0 + 1) → D
  let μ : Measure Ω := Measure.pi (fun _ : Fin (0 + 1) => stdGaussian D)
  let M := Matrix (Fin (0 + 1) × Fin (0 + 1)) (Fin (0 + 1) × Fin (0 + 1)) ℝ
  let r : ℝ := ((0 + 1 : ℕ) : ℝ)
  let L : ℝ := 2 * r + 3 * Real.log (1000 * (2 : ℝ))
  let α : Fin 2 → ℝ := fun i => ((i.val : ℝ) + 1 - 1 / 2) * Real.pi / (2 : ℝ)
  let tvec : Fin 2 → Fin (0 + 1) → ℝ := fun i k =>
    if k.val = 0 then 1 else Real.sqrt 2 * Real.cos ((k.val : ℝ) * α i)
  let row : Fin 2 → Ω → E := fun i ω =>
    WithLp.toLp 2 (fun b : Fin (0 + 1) => ω b i)
  let Y : Fin 2 → Ω → M := fun i ω =>
    if ‖row i ω‖ ^ 2 ≤ L then
      (2 : ℝ)⁻¹ • Matrix.kronecker
        (Matrix.vecMulVec (WithLp.ofLp (row i ω)) (WithLp.ofLp (row i ω)))
        (Matrix.vecMulVec (tvec i) (tvec i))
    else 0
  let mean : Fin 2 → M := fun i => ∫ ω, Y i ω ∂μ
  let Z : Fin 2 → Ω → M := fun i ω => Y i ω - mean i
  let w : Bool → Fin 2 → ℝ := fun useCos i =>
    if useCos = true then Real.cos (((2 * 0 + 1 : ℕ) : ℝ) * α i) else 1
  let sign : Bool → ℝ := fun minus => if minus = true then -1 else 1
  let S : Bool → Bool → Ω → M := fun useCos minus ω =>
    sign minus • ∑ i : Fin 2, w useCos i • Z i ω
  ∀ s : ℝ, 0 < s → ∀ a : ℝ, let useCos := true; let minus := false;
    μ {ω | a ≤ sSup (spectrum ℝ (S useCos minus ω))} ≤
      ENNReal.ofReal
        (Real.exp (-(s * a)) *
          ∫ ω, Matrix.trace (NormedSpace.exp (s • S useCos minus ω)) ∂μ) := by
  intro s hs a
  exact native_actual_T (d := 2) (q := 0) (by norm_num) s hs a true false

theorem family_cos_negative :
  let D := EuclideanSpace ℝ (Fin 2)
  let E := EuclideanSpace ℝ (Fin (0 + 1))
  let Ω := Fin (0 + 1) → D
  let μ : Measure Ω := Measure.pi (fun _ : Fin (0 + 1) => stdGaussian D)
  let M := Matrix (Fin (0 + 1) × Fin (0 + 1)) (Fin (0 + 1) × Fin (0 + 1)) ℝ
  let r : ℝ := ((0 + 1 : ℕ) : ℝ)
  let L : ℝ := 2 * r + 3 * Real.log (1000 * (2 : ℝ))
  let α : Fin 2 → ℝ := fun i => ((i.val : ℝ) + 1 - 1 / 2) * Real.pi / (2 : ℝ)
  let tvec : Fin 2 → Fin (0 + 1) → ℝ := fun i k =>
    if k.val = 0 then 1 else Real.sqrt 2 * Real.cos ((k.val : ℝ) * α i)
  let row : Fin 2 → Ω → E := fun i ω =>
    WithLp.toLp 2 (fun b : Fin (0 + 1) => ω b i)
  let Y : Fin 2 → Ω → M := fun i ω =>
    if ‖row i ω‖ ^ 2 ≤ L then
      (2 : ℝ)⁻¹ • Matrix.kronecker
        (Matrix.vecMulVec (WithLp.ofLp (row i ω)) (WithLp.ofLp (row i ω)))
        (Matrix.vecMulVec (tvec i) (tvec i))
    else 0
  let mean : Fin 2 → M := fun i => ∫ ω, Y i ω ∂μ
  let Z : Fin 2 → Ω → M := fun i ω => Y i ω - mean i
  let w : Bool → Fin 2 → ℝ := fun useCos i =>
    if useCos = true then Real.cos (((2 * 0 + 1 : ℕ) : ℝ) * α i) else 1
  let sign : Bool → ℝ := fun minus => if minus = true then -1 else 1
  let S : Bool → Bool → Ω → M := fun useCos minus ω =>
    sign minus • ∑ i : Fin 2, w useCos i • Z i ω
  ∀ s : ℝ, 0 < s → ∀ a : ℝ, let useCos := true; let minus := true;
    μ {ω | a ≤ sSup (spectrum ℝ (S useCos minus ω))} ≤
      ENNReal.ofReal
        (Real.exp (-(s * a)) *
          ∫ ω, Matrix.trace (NormedSpace.exp (s • S useCos minus ω)) ∂μ) := by
  intro s hs a
  exact native_actual_T (d := 2) (q := 0) (by norm_num) s hs a true true

end NativeLiteralApplications
#print axioms NativeLiteralApplications.literal_P
#print axioms NativeLiteralApplications.literal_T
#print axioms NativeLiteralApplications.literal_T_q0
#print axioms NativeLiteralApplications.literal_T_q0_d2
#print axioms NativeLiteralApplications.family_ordinary_positive
#print axioms NativeLiteralApplications.family_ordinary_negative
#print axioms NativeLiteralApplications.family_cos_positive
#print axioms NativeLiteralApplications.family_cos_negative
