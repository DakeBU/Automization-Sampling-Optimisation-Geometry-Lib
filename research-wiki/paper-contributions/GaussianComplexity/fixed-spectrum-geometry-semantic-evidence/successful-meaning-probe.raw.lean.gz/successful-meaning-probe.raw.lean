import AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumFirstOrder
import Mathlib.Analysis.Calculus.ContDiff.Defs
import Mathlib.Analysis.Convex.Strong
import Mathlib.MeasureTheory.Constructions.BorelSpace.Basic

open Matrix InnerProductSpace
open scoped ContDiff

set_option autoImplicit false

/- Type/meaning probe only: these definitions return propositions, not proofs.
No production declaration, proof search, source verdict or theorem credit. -/
namespace TemporaryGeometryStatementMeaning

def producerStatement {d : ℕ} (hd : 2 ≤ d)
    {κ : ℝ} (hκ : 2 ≤ κ)
    (O : Matrix.orthogonalGroup (Fin d) ℝ) : Prop :=
  let θ : Fin d → ℝ := fun i => ((i.val : ℝ) + 1 / 2) * Real.pi / (d : ℝ)
  let A : Matrix (Fin d) (Fin d) ℝ :=
    (O : Matrix (Fin d) (Fin d) ℝ) *
      Matrix.diagonal (fun i => (κ + 1) / 2 + (κ - 1) / 2 * Real.cos (θ i)) *
      (O : Matrix (Fin d) (Fin d) ℝ).transpose
  let f : EuclideanSpace ℝ (Fin d) → ℝ := fun x =>
    (WithLp.ofLp x) ⬝ᵥ (A *ᵥ WithLp.ofLp x) / 2
  ContDiff ℝ ∞ f ∧
    (∀ x : EuclideanSpace ℝ (Fin d),
      HasFDerivAt (gradient f) (Matrix.toEuclideanCLM (𝕜 := ℝ) (n := Fin d) A) x) ∧
    StrongConvexOn (Set.univ : Set (EuclideanSpace ℝ (Fin d))) 1 f ∧
    (∀ x y : EuclideanSpace ℝ (Fin d),
      ‖gradient f x - gradient f y‖ ≤ κ * ‖x - y‖) ∧
    f 0 = 0 ∧
    (∀ x : EuclideanSpace ℝ (Fin d), IsMinOn f Set.univ x ↔ x = 0)

def consumerStatement {d : ℕ} (hd : 2 ≤ d)
    {κ : ℝ} (hκ : 2 ≤ κ)
    (O : Matrix.orthogonalGroup (Fin d) ℝ) : Prop :=
  let θ : Fin d → ℝ := fun i => ((i.val : ℝ) + 1 / 2) * Real.pi / (d : ℝ)
  let A : Matrix (Fin d) (Fin d) ℝ :=
    (O : Matrix (Fin d) (Fin d) ℝ) *
      Matrix.diagonal (fun i => (κ + 1) / 2 + (κ - 1) / 2 * Real.cos (θ i)) *
      (O : Matrix (Fin d) (Fin d) ℝ).transpose
  let f : EuclideanSpace ℝ (Fin d) → ℝ := fun x =>
    (WithLp.ofLp x) ⬝ᵥ (A *ᵥ WithLp.ofLp x) / 2
  let query : EuclideanSpace ℝ (Fin d) → EuclideanSpace ℝ (Fin d) :=
    fun x => WithLp.toLp 2 (A *ᵥ WithLp.ofLp x)
  @Measurable (EuclideanSpace ℝ (Fin d))
    (ℝ × EuclideanSpace ℝ (Fin d))
    (borel (EuclideanSpace ℝ (Fin d)))
    (borel (ℝ × EuclideanSpace ℝ (Fin d)))
    (fun x => (f x, query x))

#check producerStatement
#check consumerStatement

end TemporaryGeometryStatementMeaning
