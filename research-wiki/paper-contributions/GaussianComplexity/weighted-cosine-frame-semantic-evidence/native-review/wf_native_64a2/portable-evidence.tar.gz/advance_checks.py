import gzip,hashlib,json,os,pathlib
from run import ROOT,run
m=json.loads((ROOT/'input-manifest.json').read_text());env=dict(os.environ);env['LEAN_PATH']=os.pathsep.join(m['lean_path'])
# Preserve failed API driver and its output without relabeling it successful.
old=ROOT/'native-environment.json'
with gzip.open(ROOT/'native-environment-v1.json.gz','wb') as f:f.write(old.read_bytes())
s=(ROOT/'scratch/InspectNative.lean').read_text().replace('set_option pp.maxDepth 100000\n','').replace('native-environment.json','native-environment-v2.json')
(ROOT/'scratch/InspectNativeV2.lean').write_text(s)
seal=json.loads((ROOT/'inputs/research-wiki/paper-contributions/GaussianComplexity/weighted-cosine-frame-statement-seal.json').read_text())
p=seal['producer'];c=seal['actual_private_consumer']
for obj in [p,c]: assert hashlib.sha256(obj['signature'].encode()).hexdigest()==obj['signature_sha256']
lit='''import Tests.GaussianComplexityFixedSpectrumWeightedFrameBound
import Lean
open MeasureTheory ProbabilityTheory
open scoped BigOperators Matrix.Norms.L2Operator
set_option autoImplicit false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
elab "verifiedActualPrivateConsumer" : term => do
  let env ← Lean.getEnv
  let some (n, _) := env.constants.toList.find? (fun (n, _) => n.toString.endsWith ".actual_uncentered_second_moment_sum_bound")
    | throwError "The actual private theorem is absent"
  return Lean.mkConst n
namespace IndependentFrozenStatement
'''
lit+='theorem producer '+p['signature']+' := by\n  exact '+p['name']+' hq\n\n'
lit+='theorem consumer '+c['signature']+' := by\n  exact verifiedActualPrivateConsumer hq\n\n'
lit+='example : (2 * (0 : ℕ) + 1 < 2) := by decide\nend IndependentFrozenStatement\n'
(ROOT/'scratch/LiteralApplications.lean').write_text(lit)
r=run('sealed-literal-applications',[m['lean_binary']['path'],'-R',str(ROOT/'scratch'),'-o',str(ROOT/'native-olean/LiteralApplications.olean'),str(ROOT/'scratch/LiteralApplications.lean')],cwd=ROOT/'scratch',env=env);assert r.returncode==0
r=run('native-environment-inspection-v2',[m['lean_binary']['path'],'-R',str(ROOT/'scratch'),str(ROOT/'scratch/InspectNativeV2.lean')],cwd=ROOT/'scratch',env=env);assert r.returncode==0
