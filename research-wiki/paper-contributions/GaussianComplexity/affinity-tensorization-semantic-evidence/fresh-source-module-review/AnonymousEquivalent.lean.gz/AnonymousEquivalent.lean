import AutoSamplingTheory.ExampleCases.GaussianComplexity.AffinityTensorization
import Lean.Util.FoldConsts
open Matrix MeasureTheory ProbabilityTheory
open scoped ENNReal BigOperators
set_option autoImplicit false
example : ∀ {d n : ℕ} (hn : 3 ≤ n) (hnd : n ≤ d)
    {κ : ℝ} (hκ : 4 ≤ κ),
    letI : MeasurableSpace (Matrix (Fin d) (Fin d) ℝ) := borel _
    let e : ((Fin n × Fin (d / n)) ⊕ Fin (d % n)) ≃ Fin d :=
      ((Equiv.sumCongr
        ((Equiv.prodComm (Fin n) (Fin (d / n))).trans finProdFinEquiv)
        (Equiv.refl (Fin (d % n)))).trans finSumFinEquiv).trans
        (finCongr (by simpa [Nat.mul_comm] using Nat.div_add_mod d n))
    let B : Matrix.orthogonalGroup (Fin n) ℝ → Matrix (Fin n) (Fin n) ℝ :=
      fun O => ((κ + 1) / 2) • (1 : Matrix (Fin n) (Fin n) ℝ) -
        ((κ - 1) / 4) • ((O : Matrix (Fin n) (Fin n) ℝ) +
          (O : Matrix (Fin n) (Fin n) ℝ).transpose)
    let μ := (Measure.haarMeasure (⊤ : TopologicalSpace.PositiveCompacts (Matrix.orthogonalGroup (Fin n) ℝ)))
    let νpos := (2 : ℝ≥0∞) • μ.restrict
      {O : Matrix.orthogonalGroup (Fin n) ℝ | (O : Matrix (Fin n) (Fin n) ℝ).det = 1}
    let νneg := (2 : ℝ≥0∞) • μ.restrict
      {O : Matrix.orthogonalGroup (Fin n) ℝ | (O : Matrix (Fin n) (Fin n) ℝ).det = -1}
    let Dpos := (Measure.pi (fun _ : Fin (d / n) => νpos)).map (fun Os : Fin (d / n) → Matrix.orthogonalGroup (Fin n) ℝ => Matrix.reindex e e
      (Matrix.fromBlocks (Matrix.blockDiagonal (fun j => B (Os j))) 0 0
        (1 : Matrix (Fin (d % n)) (Fin (d % n)) ℝ)))
    let Dneg := (Measure.pi (fun _ : Fin (d / n) => νneg)).map (fun Os : Fin (d / n) → Matrix.orthogonalGroup (Fin n) ℝ => Matrix.reindex e e
      (Matrix.fromBlocks (Matrix.blockDiagonal (fun j => B (Os j))) 0 0
        (1 : Matrix (Fin (d % n)) (Fin (d % n)) ℝ)))
    let γ : Matrix (Fin d) (Fin d) ℝ → Measure (EuclideanSpace ℝ (Fin d)) :=
      fun A => multivariateGaussian (0 : EuclideanSpace ℝ (Fin d)) A⁻¹
    let Mpos := Dpos.bind γ
    let Mneg := Dneg.bind γ
    let p : Matrix.orthogonalGroup (Fin n) ℝ → EuclideanSpace ℝ (Fin n) → ℝ :=
      fun O x => Real.sqrt (B O).det /
        (2 * Real.pi) ^ ((n : ℝ) / 2) *
        Real.exp (-((WithLp.ofLp x) ⬝ᵥ
          (B O *ᵥ WithLp.ofLp x)) / 2)
    let qpos : EuclideanSpace ℝ (Fin n) → ℝ := fun x => ∫ O, p O x ∂νpos
    let qneg : EuclideanSpace ℝ (Fin n) → ℝ := fun x => ∫ O, p O x ∂νneg
    let a : ℝ := ∫ x, Real.sqrt (qpos x * qneg x)
    let F : EuclideanSpace ℝ (Fin d) → ℝ := fun x =>
      Real.sqrt (((Mpos.rnDeriv volume) x).toReal * ((Mneg.rnDeriv volume) x).toReal)
    Mpos ≪ volume ∧ Mneg ≪ volume ∧ Integrable F volume ∧
      (∫ x, F x) = a ^ (d / n) := by
  exact @AutoSamplingTheory.ExampleCases.GaussianComplexity.AffinityTensorization.actual_affinity_tensorization

#print axioms AutoSamplingTheory.ExampleCases.GaussianComplexity.AffinityTensorization.actual_affinity_tensorization
#print axioms AutoSamplingTheory.ExampleCases.GaussianComplexity.ProductDensity.actual_product_density
#print axioms AutoSamplingTheory.ExampleCases.GaussianComplexity.MixtureDensities.actual_mixture_densities
#print axioms AutoSamplingTheory.TechnicalLemmas.InformationTheory.DensityAffinity.normalized_density_tv_affinity
