from pathlib import Path
import hashlib,json,datetime,shutil
ROOT=Path('/Users/zhouhuanjian/ASTIS-GC');BASE=ROOT/'.astis/semantic-neutral-20261112/mv_sg_42f6';RAW=BASE/'raw-freeze-v2';OUT=BASE/'type-freeze-v1'
PACKET=ROOT/'.astis/huanjian-gc-source-matrix-variance-20261112/selective-type-definition-packet.json'
def sha(b):return hashlib.sha256(b).hexdigest()
assert not OUT.exists()
pb=PACKET.read_bytes();assert sha(pb)=='b9b93126880486157e88e9a59abcd2b89d81b4cf34d46fa9dc51f88d2b6e0170';p=json.loads(pb)
rm=(RAW/'freeze-manifest.json').read_bytes();assert sha(rm)=='e7e6ca17db84515ecfc8af6ff48f019a297a057c3e185e5e0ccb1cab590aa05f'
for x in json.loads(rm)['files']:
 b=(RAW/x['path']).read_bytes();assert len(b)==x['bytes'] and sha(b)==x['sha256']
for k in ['producer','actual_private_consumer']:assert sha(p[k]['signature'].encode())==p[k]['signature_sha256']
ctx=p['minimal_definition_context'];assert sha(ctx['literal_current_prints_and_instances'].encode())==ctx['literal_current_prints_sha256']
for x in ctx['literal_definition_excerpts']:assert sha(x['literal_source'].encode())==x['literal_source_sha256']
assert p['statement_seal_sha256']=='5f905cafe6035238cebdedd4f841e87b703e741b4c8aa204471d89e4c07e8a14'
source=(RAW/'inputs/2610.20492v1.html').read_bytes();s=source.decode()
for x in p['source']['anchors']:
 frag=source[x['raw_utf8_start']:x['raw_utf8_end']];assert sha(frag)==x['span_sha256'];assert frag==s[x['char_start']:x['char_end']].encode()
OUT.mkdir();(OUT/'inputs').mkdir()
def dump(n,v):(OUT/n).write_text(json.dumps(v,ensure_ascii=False,sort_keys=True,indent=2)+'\n',encoding='utf-8')
def write(n,t):(OUT/n).write_text(t,encoding='utf-8')
(OUT/'inputs/selective-type-definition-packet.json').write_bytes(pb);(OUT/'inputs/raw-v2-manifest.json').write_bytes(rm)
shutil.copyfile(BASE/'working/build_type_freeze.py',OUT/'inputs/build_type_freeze.py')
for k,n in [('producer','producer.signature.txt'),('actual_private_consumer','consumer.signature.txt')]:write('inputs/'+n,p[k]['signature'])
bindings={'raw_v2_manifest_sha256':sha(rm),'packet_sha256':sha(pb),'statement_seal_sha256':p['statement_seal_sha256'],'producer_signature_sha256':p['producer']['signature_sha256'],'consumer_signature_sha256':p['actual_private_consumer']['signature_sha256'],'definition_context_sha256':p['minimal_definition_context_sha256'],'mathlib_pin':ctx['mathlib_pin']}
binders=[
 {'input':'d : Nat','class':'TYPING','audit':'Finite physical dimension, exact natural typing.'},
 {'input':'q : Nat','class':'TYPING','audit':'Nonnegative integer query count. q=0 is included.'},
 {'input':'hq : 2*q+1<d','class':'STANDING','audit':'Exact source range. Positive d,r, nonzero denominators and nonnegative explicit bound are internal consequences.'},
 {'input':'Every local let','class':'NOT_A_LOGICAL_PREMISE','audit':'Fixed literal experiment/data/map/mean/constant definitions, not caller witnesses or moment/variance/PSD/mean/Gram/independence certificates.'},
 {'input':'Canonical real, finite, Euclidean, matrix, probability/norm structures','class':'TYPING','audit':'Actual standard instances supplied by packet, not extra caller-controlled structure. Matrix completeness and probability instance are inferred; their use in proofs remains internal.'}]
defs=[
 ('D,E,Omega,mu','literal canonical realization','d-dimensional standard Gaussian columns on the finite product; row space dimension r=q+1. All actual expectations are under the same literal mu, with no ambient extension/conditioning.'),
 ('row','literal','WithLp.toLp 2 collects coordinate i.val+1 of every original column. WithLp.ofLp reads exactly the r source physical-row coordinates.'),
 ('r,L','literal','Real r=q+1 and exact L=2r+3log(1000d). No additional positivity or logarithm-domain binder.'),
 ('theta,t','literal','theta=(i.val+1-1/2)pi/d with real half; t0=1 and tk=sqrt2*cos(k theta) for k=1,...,q. q=0 retains t=(1).'),
 ('Y','literal','Closed row-local norm-squared cutoff. Inside: inverse d times actual-row outer product Kronecker feature outer product. Outside: zero, exactly the source indicator. Gaussian coordinate precedes feature coordinate in both paired indices.'),
 ('Matrix product','expanded actual instance','Ordinary matrix product (MN)ij=sum_k Mik Nkj, with finite paired middle index. Therefore Y*Y, Z*Z and (w Z)*(w Z) are source matrix squares, not Hadamard squares.'),
 ('Matrix identity/scalar action','standard literal semantics','1 is the typed identity matrix; C scalar-multiplies identity. This matches I_(r^2), not an all-ones matrix.'),
 ('L2Operator norm and completeness','actual supplied standard instances','The supplied NormedRing/NormedSpace and complete square-matrix structure use the norm induced by Euclidean continuous linear operators. Thus both consumer norms are the source Euclidean operator norm, not a default entrywise/sup norm.'),
 ('PosSemidef','fully expanded output predicate','Matrix.IsHermitian M means conjugate-transpose M=M, and every Finsupp quadratic form is nonnegative. With finite real paired indices, star is real conjugation and every finite vector is covered. PosSemidef(CI-sum E[Y*Y]) is precisely the Loewner upper bound; no Hermitian half is omitted.'),
 ('Integrable','expanded output predicate','AEStronglyMeasurable and finite integral of the extended norm. The almost-everywhere representative and norm-integrability obligations are conclusions for actual Y squares and both actual centered-square families.'),
 ('Bochner integral','literal standard definition','The supplied integral defaults to zero outside completeness/integrability. Complete matrix structure and explicit squared-variable integrability outputs prevent vacuous second-moment default-zero credit. Yi integrability for its actual mean, mixed terms and centering algebra must also be proved internally, though not a public output.'),
 ('mean,Z','literal actual mean/centering','mean_i=integral_mu Yi and Zi=Yi-mean_i. No supplied first-moment matrix or free mean variable appears. This is the exact p13 centering.'),
 ('w','literal deterministic weights','w_i=cos(((2q+1:Nat):Real)*theta_i), exact source n=2q+1.'),
 ('C','explicit bound definition','C=2r(r+2)/d equals source v*. This local defined C is not the unrelated existential absolute concentration C in Lemma4.4; no tau/kappa/absolute-constant premise.'),
 ('producer outputs','literal source conclusion plus well-definedness','Every actual Y_i*Y_i is integrable; C I minus sum_i integral_mu(Y_i*Y_i) is PSD. No caller PSD certificate.'),
 ('consumer outputs','literal variance-parameter conclusions','Both actual Zi square families are integrable, and the two sums of their actual squared means have Euclidean operator norm <=C. These are sums of individual square expectations, not the expected square of a random sum, so no cross-index independence input is needed.')]
audit={'version':1,'phase':'TYPE_VERDICT_FROZEN_BEFORE_SOURCE_GRAPH','bindings':bindings,'actor':'/root/row_indep_source_graph_78c2','source_root_full_path':str(BASE),
 'verdict':'NO_GENUINE_BINDER_DEFINITION_TYPE_OR_SOURCE_SCOPE_ISSUE_FOUND','genuine_target_issues':[],
 'role':'Independent of formalizer for source/type audit; not a source-blind decoder and not an independent reviewer of own raw coverage.',
 'binder_audit':binders,'EXCESS_public_binders':[],'definitions':[{'object':o,'kind':k,'audit':a,'meaning_match':True} for o,k,a in defs],
 'semantic_slots':{'objects':'Same original-column physical rows and literal actual Yi; actual Bochner means define Zi.',
 'domains':'Natural d,q with2q+1<d; real finite Euclidean vectors and r^2 square real matrices with Gaussian-first paired indices.',
 'quantifiers':'All admissible d,q; all physical i for integrability; complete finite sums of actual integrals for the bounds.',
 'assumptions':'Only typing plus hq. All moment, variance, matrix positivity, mean, Gram, independence, integrability and integral-algebra facts are internal, never new certificates.',
 'conclusion':'Actual uncentered squares integrable and source PSD sum bound; actual centered/weighted squares integrable and both true operator-norm variance bounds.',
 'scopes_and_senses':'One fixed mu. Ordinary matrix squares and full Hermitian/quadratic PSD. Actual mean, exact cosine weights, actual Euclidean operator norm. No independent surrogate, conditioning or expected-square-of-sum substitution.',
 'constants':'Exact inverse d, closed L, sqrt2 features, source n=2q+1 and explicit2r(r+2)/d. No R*,tau,kappa or existential absolute-C restriction.'},
 'q_zero_check':'r=1,n=1,t=(1),d>=2, C=6/d. Matrix carrier is1-by-1 and both source ordinary squares/PSD/operator norm meanings retain their scalar specialization without new q>0 hypothesis.',
 'source_locator_scope':'Z definition p13; Ex113/114 and all variance comparisons p14; all p15 Bernstein context EXCLUDED, matching raw-v2.',
 'remaining_internal_obligations':['Physical-row law and actual fourth-moment applicability/transport.','Ordinary matrix rank-one/tensor-square identity and complete integrability.','Hermitian/PSD algebra, indicator-dropping and integral Loewner order.','Literal t norm/Gram application and finite tensor sum algebra.','Actual Yi integrability and noncommutative centering integral algebra.','Weighted square positivity and |cos|<=1 comparison.','PSD upper/lower bounds to Euclidean operator-norm variance conclusions.'],
 'genuine_SOURCE_GAPs':[],'compiled_parents':[],'new_target_proof_seen':False,'API_search_performed':False,
 'topology':'No new source graph is included or accepted in this type freeze. Source graph follows only after this immutable type verdict.',
 'permission_status_or_proof_grant':False}
dump('type-audit.json',audit)
write('type-meaning-verdict.md','No genuine source/type/binder mismatch or EXCESS input was found. Ordinary matrix multiplication, actual L2Operator norm, complete Hermitian-plus-quadratic PosSemidef, one actual mu, actual Bochner centering and both true variance-sum norm conclusions match the source. q=0 remains included. All squared-variable integrability is output; Yi integrability and noncommutative centering algebra remain internal to justify the actual mean and avoid integral-default-zero artifacts. No moment/PSD/mean/Gram/independence certificate is supplied. p13/p14 locators are retained and all p15 Bernstein context remains excluded. This independent type verdict is frozen before source graph construction; no proof, compiled-parent or permission/status grant.\n')
dump('input-exposure-chronology.json',{'bindings':bindings,'raw_before_type':'Own raw-v2 was frozen and checked before this actor first opened the R9 selective exact type/definition packet. No claim about nonexistence of a global seal before raw is made.',
 'read_allowlist':'Only new selective packet and this actor own mv raw source/protocol/artifacts; no new implementation, TC opinion or prior verdict used to choose topology.',
 'new_target_implementation_or_API_search':False,'formalizer_API_pristine':False,
 'reported_attempts':'Parent reports root new-target proof/API attempts0 and P/T not existing. This actor saw no new target proof; no independent repository-wide attempt/history scan was performed.',
 'prior_context':'Prior R4/R5/R8 canonical results are reported context only. No compiled parent or public provider is inferred from name/import, and no private canonical-row test import is assumed to provide public mathematics. This actor earlier R7/R8 exposures remain disclosed, not labelled pristine.',
 'digest_verification':'Exact packet/signature/print/excerpt UTF8 hashes, own raw-v2 manifest contents and raw source anchors rechecked. Seal/context identifiers are supplied labels bound by exact verified packet bytes; no unavailable separate serialization checksum is fabricated.',
 'writes':'Only own mv_sg_42f6 new type-freeze directory and builder; raw v1/v2 unchanged; no ledger/registry/C/Git/shared mutation.',
 'no_grant':True})
write('README.md','R9 independent exact type/source audit frozen BEFORE source graph construction. Read type-audit.json. No graph is included, no proof body/API search performed, no mathematical/status/permission grant. Own raw-v1/v2 are unchanged.\n')
m={'format':'astis-matrix-variance-type-freeze-v1','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'phase':'TYPE_VERDICT_BEFORE_GRAPH','bindings':bindings,'files':[]}
for f in sorted(OUT.rglob('*')):
 if f.is_file():b=f.read_bytes();m['files'].append({'path':str(f.relative_to(OUT)),'bytes':len(b),'sha256':sha(b)})
dump('freeze-manifest.json',m);dig=sha((OUT/'freeze-manifest.json').read_bytes());write('freeze-manifest.sha256',dig+'  freeze-manifest.json\n')
for f in OUT.rglob('*'):
 if f.is_file():f.chmod(0o444)
for d in sorted([d for d in OUT.rglob('*') if d.is_dir()],key=lambda d:len(d.parts),reverse=True):d.chmod(0o555)
OUT.chmod(0o555)
print(json.dumps({'type_freeze_path':str(OUT),'type_audit_sha256':sha((OUT/'type-audit.json').read_bytes()),'type_manifest_sha256':dig,'raw_v2_manifest_sha256':sha(rm),'producer_signature_sha256':p['producer']['signature_sha256'],'consumer_signature_sha256':p['actual_private_consumer']['signature_sha256'],'genuine_target_issues':[]},indent=2))
