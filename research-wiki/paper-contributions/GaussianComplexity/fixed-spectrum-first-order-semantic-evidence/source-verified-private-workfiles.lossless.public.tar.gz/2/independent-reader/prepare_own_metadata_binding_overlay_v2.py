"""Freeze only an explicit legitimate-own-metadata successor binding; no execution."""
from pathlib import Path
import ast,difflib,gzip,hashlib,json
R=Path('/Users/zhouhuanjian/ASTIS-GC');S=R/'.astis/huanjian-gc-fixed-spectrum-first-order-integration-20261108/independent-reader';O=S/'conditional-helper-own-metadata-overlay-v2'
sha=lambda b:hashlib.sha256(b).hexdigest();dump=lambda x:(json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode()
assert not O.exists();O.mkdir()
oldcommon=(S/'first_order_browser_common_v1.py').read_bytes();oldbrowser=(S/'check_final_reader_v1.py').read_bytes()
assert sha(oldcommon)=='37a0fb9532f15981db880d61f7b4873765e7342d7bfc526c7d70e721b8dd4088' and sha(oldbrowser)=='a5b937fc56403a38ea30cbae576a87565a639ed41d5f6bcff88ca2a594c5cf8f'
common=oldcommon.decode().replace("S/'check_final_reader_v1.py'","S/'check_final_reader_v2.py'",1)
assert common.count("  if name==ledger:continue")==1
common=common.replace("  if name==ledger:continue","  if name in [ledger,'research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-first-order.json']:continue",1)
anchor=" assert subprocess.check_output(['git','show',a['accepted_immutable_core']+':'+a['accepted_source_audit']['path']],cwd=R)==readref(a['accepted_source_audit'])\n"
assert common.count(anchor)==1
extra=''' # The only successor frontier exception is the explicitly pinned OWN cell.
 # All443 foreign frontiers remain covered by the full raw baseline above.
 frontier_name='research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-first-order.json'
 assert a['own_frontier_current']['path']==frontier_name
 frontier_raw=readref(a['own_frontier_current']);frontier=json.loads(frontier_raw)
 before_raw=subprocess.check_output(['git','show',CANDIDATE+':'+frontier_name],cwd=R);before_frontier=json.loads(before_raw)
 assert sha(before_raw)==baseline['all_frontier_raw_hashes'][frontier_name]
 assert subprocess.check_output(['git','show',a['accepted_immutable_core']+':'+frontier_name],cwd=R)==frontier_raw
 assert frontier['cell_id']==before_frontier['cell_id']=='ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-first-order'
 assert frontier['advance_id']==before_frontier['advance_id']==ADV and frontier['owner_id']==before_frontier['owner_id']==OWNER
 assert frontier['status'] in ['proved_locally','independently_verified']
 def changed_paths(x,y,path=''):
  if isinstance(x,dict) and isinstance(y,dict):
   out=[]
   for k in sorted(x.keys()|y.keys()):
    key=path+'/'+k.replace('~','~0').replace('/','~1')
    out.extend(changed_paths(x[k],y[k],key) if k in x and k in y else [key])
   return out
  return [] if x==y else [path]
 delta=changed_paths(before_frontier,frontier)
 assert all(path=='/status' or path.startswith('/evidence/') for path in delta)
 projection=json.loads(readref(a['own_frontier_projection_review']))
 assert projection['authorized_by']=='/root' and projection['scope']=='mechanical-own-cell-sourceV-STAB-evidence-only'
 assert projection['candidate_commit']==CANDIDATE and projection['advance_id']==ADV
 assert projection['before_sha256']==sha(before_raw) and projection['after_sha256']==sha(frontier_raw)
 assert projection['source_V_append_sha256']==sha(append) and projection['STAB_append_sha256']==sha(tail[1]+b'\\n')
 assert projection['changed_json_paths']==delta and projection['new_mathematical_or_source_verdict'] is False
 # The exact future record pins actual events and status/evidence projection;
 # target_statement, binders/seals, parents, source coverage and all other fields
 # remain byte-content-equivalent JSON data from candidate9d, never broadly exempt.
'''
common=common.replace(anchor,anchor+extra,1)
common=common.replace("'all_discoveries_and_frontier_bytes_preserved':True", "'all_discoveries_and443_foreign_frontier_bytes_preserved':True,'own_frontier_successor':a['own_frontier_current'],'own_frontier_projection_review':a['own_frontier_projection_review'],'own_frontier_changed_paths':delta",1)
browser=oldbrowser.decode().replace('from first_order_browser_common_v1 import','from first_order_browser_common_v2 import',1)
for name,source in [('first_order_browser_common_v2.py',common),('check_final_reader_v2.py',browser)]:compile(source,name,'exec');ast.parse(source);(S/name).write_text(source)
for name,a,b in [('common',oldcommon.decode(),common),('browser',oldbrowser.decode(),browser)]:
 (O/(name+'.exact.diff')).write_text(''.join(difflib.unified_diff(a.splitlines(keepends=True),b.splitlines(keepends=True),fromfile=name+'-v1',tofile=name+'-v2')))
 for version,raw in [('before',a.encode()),('after',b.encode())]:(O/(name+'.'+version+'.raw.py.gz')).write_bytes(gzip.compress(raw,mtime=0))
template=json.loads((S/'UNAUTHORIZED-final-browser-context.template.json').read_bytes());template.update({'browser_checker_sha256':sha(browser.encode()),'browser_common_sha256':sha(common.encode()),'own_frontier_current':{'path':'research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-first-order.json','sha256':'<future exact sourceV/STAB-projected own frontier bytes>'},'own_frontier_projection_review':{'path':'<separately root-approved exact mechanical projection review>','sha256':'<rawSHA256>'}});(S/'UNAUTHORIZED-final-browser-context-v2.template.json').write_bytes(dump(template))
projection_template={'state':'UNAUTHORIZED_TEMPLATE_ONLY','authorized_by':'<root actual review required later>','scope':'mechanical-own-cell-sourceV-STAB-evidence-only','candidate_commit':'9d306d837fbddf1518b0035494baaf5c21c24488','advance_id':'ASTIS-SA-20261108-GaussianComplexityFixedSpectrumFirstOrder','before_sha256':'<candidate own frontier rawSHA256>','after_sha256':'<actual own projected frontier rawSHA256>','source_V_append_sha256':'<actual normal sourceV append rawSHA256>','STAB_append_sha256':'<actual soleSTAB append rawSHA256>','changed_json_paths':['<actual /status and/or /evidence/... paths only>'],'new_mathematical_or_source_verdict':False};(S/'UNAUTHORIZED-own-frontier-projection-v2.template.json').write_bytes(dump(projection_template))
report={'state':'CONDITIONAL_HELPER_OWN_METADATA_BINDING_OVERLAY_NOT_EXECUTED','parent_capsule':{'path':str((S/'conditional-preparation-capsule-v1.json').relative_to(R)),'sha256':sha((S/'conditional-preparation-capsule-v1.json').read_bytes())},'shared8payloads_and_all_report_archive_bytes_unchanged':True,'reason':'Root explicitly identified legitimate own frontier sourceV/soleSTAB mechanical projection as successor metadata. V1 incorrectly demanded candidate-byte equality for this own path. This overlay is exact and bounded, retaining v1 originals and all foreign protection.','browser_checker':{'path':str((S/'check_final_reader_v2.py').relative_to(R)),'sha256':sha(browser.encode())},'browser_common':{'path':str((S/'first_order_browser_common_v2.py').relative_to(R)),'sha256':sha(common.encode())},'allowed_successor_paths_only':['Own normal sourceV then soleSTAB ledger appends, with candidate raw prefix and foreign states exact','Own independently accepted current-binding source audit, explicit raw pin and original fresh actor','Own frontier status/evidence projection, explicit current raw pin plus separately root-reviewed exact delta record binding actual V/STAB append hashes'],'foreign_guard_unchanged':'All284 foreign SAU states, all443 foreign frontier raw bytes, all old Discovery data and every other baseline path remain exact. No broad metadata exception. All target_statement/seal/binders/parents/source coverage/non-evidence fields in own frontier stay equal to candidate.','future_projection_status_only':['proved_locally','independently_verified'],'requires_later_actual_events_and_root_bound_context':True,'sourceV_or_STAB_API_run':False,'actual_browser_run':False,'new_browser_flow_changes':'None: only import selects the new common guard; desktop/mobile38 originals/native folds/old DensityAffinity unique direct source selector and>=100line assertions unchanged.','root_build_or_site_acceptance_claimed':False,'unbound_templates':['UNAUTHORIZED-final-browser-context-v2.template.json','UNAUTHORIZED-own-frontier-projection-v2.template.json']}
(O/'overlay-report.json').write_bytes(dump(report));(O/'preparation-driver.raw.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
f={'report_sha256':sha((O/'overlay-report.json').read_bytes()),'files':[{'path':str(p.relative_to(R)),'sha256':sha(p.read_bytes())} for p in sorted(O.iterdir()) if p.is_file()],'executed':False};(O/'freeze.json').write_bytes(dump(f));print(json.dumps({'report':str((O/'overlay-report.json').relative_to(R)),'report_sha256':f['report_sha256'],'freeze_sha256':sha((O/'freeze.json').read_bytes()),'checker':report['browser_checker'],'common':report['browser_common'],'applied_or_run':False},indent=2))
