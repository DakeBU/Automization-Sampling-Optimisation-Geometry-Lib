"""Correct only library-name descriptions after the first reservation check."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys

sys.dont_write_bytecode = True
sys.path.insert(0, 'tools')
import astis_advance as advance
import astis_frontier_cells as frontiers

workspace = Path(__file__).resolve().parent
cell_path = Path('research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-weighted-cosine-frame.json')
sha = lambda raw: hashlib.sha256(raw).hexdigest()
dump = lambda obj: (json.dumps(obj, ensure_ascii=False, indent=2) + '\n').encode()
baseline = json.loads((workspace / 'preproof-baseline.private.json').read_bytes())
before = cell_path.read_bytes()
assert sha(before) == '0e1066f1c32259b4b86560755828eab21e0ece51e6c7fabe638d6d6d6a779599'
with (workspace / 'reserved-cell.description-attempt1.original.json').open('xb') as out:
    out.write(before)
script = workspace / 'reserve_sealed_packet.py'
with (workspace / 'reserve_sealed_packet.attempt1.original.py').open('xb') as out:
    out.write(script.read_bytes())
cell = json.loads(before)
searches = cell['shared_floor_audit']['searched']
assert searches == cell['reuse_plan']['searched_existing']
searches[0] = 'Samplinglib canonical reuse. ' + searches[0]
searches[2] = 'Mathlib definition audit. ' + searches[2]
cell['reuse_plan']['searched_existing'] = searches
cell_path.write_bytes(dump(cell))
errors = frontiers.validate_cells(frontiers.load_cells())
assert not errors, errors
ledger = Path('runs/substantive_advances.jsonl').read_bytes()
assert sha(ledger) == baseline['ledger_sha256'] and len(ledger) == baseline['ledger_bytes']
assert advance._replay_advances([json.loads(line) for line in ledger.splitlines()]) == baseline['all_foreign_states']
for name, digest in baseline['all_existing_frontier_hashes'].items():
    assert sha(Path(name).read_bytes()) == digest, name
assert subprocess.check_output(['git', 'rev-parse', 'HEAD']).decode().strip() == baseline['head']
assert not subprocess.check_output(['git', 'diff', 'HEAD', '--name-only'])
summary = {
    'baseline_commit': baseline['head'],
    'cell': str(cell_path), 'cell_sha256': sha(cell_path.read_bytes()),
    'exact_seal_sha256': 'fca4e21eaa1e3107b6cfcf99c2a08c6dc7884c5a62f1dd4f626fbf3042cc4998',
    'foreign_full_states_guarded': len(baseline['all_foreign_states']),
    'older_frontier_files_guarded': len(baseline['all_existing_frontier_hashes']),
    'normal_API_and_proof_calls': 0, 'independent_topology_acceptance': 'pending',
    'failure_class': 'IMPLEMENTATION_FAILED',
    'recovery': 'Only library-name descriptions changed. Failed check retained. No mathematical claim or statement changed.',
}
with (workspace / 'actual-seal-and-reservation-summary.json').open('xb') as out:
    out.write(dump(summary))
print(json.dumps(summary))
