from pathlib import Path
from html.parser import HTMLParser
import hashlib
import json
import re
import sys

ROOT = Path('/Users/zhouhuanjian/ASTIS-GC')
SOURCE = ROOT / '.astis/huanjian-resume-20261103/2610.20492v1.html'

class Node:
    def __init__(self, tag, attrs, parent=None, line=0):
        self.tag, self.attrs, self.parent, self.line = tag, dict(attrs), parent, line
        self.children = []

    def text(self):
        if self.tag == 'math':
            return '$' + self.attrs.get('alttext', '') + '$'
        if self.tag in ('annotation', 'annotation-xml'):
            return ''
        return ''.join(c.text() if isinstance(c, Node) else c for c in self.children)

    def clean(self):
        return re.sub(r'\s+', ' ', self.text()).strip()

class Reader(HTMLParser):
    void = {'area', 'base', 'br', 'col', 'embed', 'hr', 'img', 'input', 'link', 'meta', 'param', 'source', 'track', 'wbr'}

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.root = Node('root', [])
        self.stack = [self.root]
        self.nodes = []

    def handle_starttag(self, tag, attrs):
        n = Node(tag, attrs, self.stack[-1], self.getpos()[0])
        self.stack[-1].children.append(n)
        self.nodes.append(n)
        if tag not in self.void:
            self.stack.append(n)

    def handle_endtag(self, tag):
        for i in range(len(self.stack)-1, 0, -1):
            if self.stack[i].tag == tag:
                self.stack = self.stack[:i]
                break

    def handle_data(self, data):
        self.stack[-1].children.append(data)

raw = SOURCE.read_bytes()
r = Reader()
r.feed(raw.decode())
by_id = {n.attrs['id']: n for n in r.nodes if 'id' in n.attrs}

if sys.argv[1] == 'outline':
    for n in r.nodes:
        if re.fullmatch('h[1-6]', n.tag) and any(x in n.clean() for x in ('4.4', 'C.2', 'C.6')):
            print(json.dumps({'line':n.line, 'parent_id':n.parent.attrs.get('id'), 'text':n.clean()}))
elif sys.argv[1] == 'children':
    n = by_id[sys.argv[2]]
    for c in n.children:
        if isinstance(c, Node):
            print(json.dumps({'tag':c.tag, 'id':c.attrs.get('id'), 'line':c.line, 'class':c.attrs.get('class')}))
elif sys.argv[1] == 'read':
    for ident in sys.argv[2:]:
        n = by_id[ident]
        print(json.dumps({'id':ident, 'line':n.line, 'text':n.clean()}, ensure_ascii=False))
