# Phase1 source-only freeze

Start with `mathematics.md`, `source-graph.json`, `coverage.json`, and `exposure.json`.

- `inputs/` and `input-manifest.json` are the supplied original source/policy packet, preserved byte-for-byte.
- `source-inventory-raw.json` records the 446 paragraph/formula/wrapper/citation/heading items in four closed source containers. `coverage.json` adds the one expanded bibliography entry, giving447 explicit dispositions:128 NODE and319 EXCLUDED.
- `anchored-excerpts.json` retains28 exact original-HTML excerpts with Unicode-codepoint, raw UTF-8, LF-line and SHA256 anchors.
- `source-graph.json` has35 nodes and16 use-site edges. It marks omitted background, OR alternatives, and separate excluded neighboring obligations. The selected scalar ancestry has no C.5/row-independence/radial-symmetry/fourth-moment/Bernstein/full-uniform-bound false parent.
- `integrity-results.json` is a structural and raw-byte check only. It confers no independent coverage approval, mathematical acceptance, theorem proof or semantic-verifier status.
- `execution/` retains actual input/extraction/build/check stdout and exit statuses, tool receipt objects, all failures, output truncation limits and the exact wrong-path correction operation. `exposure.json` explicitly says write_scope_pristine=false.
- `phase1-manifest.json` hashes the complete frozen payload except itself. The external freeze execution receipt and index bind the manifest and its own immutable bytes without a self-hash cycle.

No target types were shown before this freeze. The parent gave only the source-reading assignment and later a digest of a still-withheld selective packet. Later selective-type comparisons must be new artifacts outside this frozen Phase1 directory. No source theorem is proved by this reconstruction, and its author does not independently approve their own coverage.
