import AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumSourceRowIndependence
import AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumSourceMatrixMean

noncomputable section
open MeasureTheory ProbabilityTheory
open scoped BigOperators Matrix Kronecker Matrix.Norms.L2Operator
set_option autoImplicit false

namespace StructureTypeInstanceAudit
variable {d q : ℕ}
abbrev J (q : ℕ) := Fin (q + 1) × Fin (q + 1)
abbrev M (q : ℕ) := Matrix (J q) (J q) ℝ

def SelectedMatrixTopology : TopologicalSpace (M q) := inferInstance
def SelectedMatrixUniformity : UniformSpace (M q) := inferInstance
def SelectedMatrixNorm : Norm (M q) := inferInstance
def SelectedMatrixCompleteness : CompleteSpace (M q) := inferInstance
def SelectedMatrixFiniteDimension : FiniteDimensional ℝ (M q) := inferInstance
def ExplicitMatrixBorel : MeasurableSpace (M q) := borel (M q)

#print SelectedMatrixTopology
#print SelectedMatrixUniformity
#print SelectedMatrixNorm
#print SelectedMatrixCompleteness
#print SelectedMatrixFiniteDimension
#print ExplicitMatrixBorel
#check Pi.borelSpace
#check BorelSpace.measurable_eq
#check measurable_pi_iff
#check continuous_matrix
#check Continuous.matrix_elem
#check ProbabilityTheory.stdGaussian
#check ProbabilityTheory.iIndepFun
#check Matrix.IsHermitian
#check MeasureTheory.integral

#synth IsProbabilityMeasure
  (Measure.pi (fun _ : Fin (q + 1) => stdGaussian (EuclideanSpace ℝ (Fin d))))

end StructureTypeInstanceAudit
