"""Locate source formulas and the exact compiled proof and statement spans."""
from html.parser import HTMLParser
from pathlib import Path
import hashlib
import json

evidence = Path('research-wiki/paper-contributions/GaussianComplexity/radial-fourth-matrix-semantic-evidence')
raw = Path('.astis/huanjian-resume-20261103/2610.20492v1.html').read_bytes()
text = raw.decode()
sha = lambda data: hashlib.sha256(data).hexdigest()
assert sha(raw) == '6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
offsets = [0] + [i + 1 for i, char in enumerate(text) if char == '\n']


class SourceElements(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=False)
        self.stack = []
        self.elements = {}

    def source_offset(self):
        line, col = self.getpos()
        return offsets[line - 1] + col

    def handle_starttag(self, tag, attrs):
        if tag not in {'area', 'base', 'br', 'col', 'embed', 'hr', 'img', 'input', 'link', 'meta', 'param', 'source', 'track', 'wbr'}:
            self.stack.append((tag, dict(attrs).get('id'), self.source_offset()))

    def handle_endtag(self, tag):
        for i in range(len(self.stack) - 1, -1, -1):
            if self.stack[i][0] == tag:
                _, identifier, start = self.stack[i]
                if identifier:
                    self.elements[identifier] = (start, text.index('>', self.source_offset()) + 1)
                del self.stack[i:]
                return


parser = SourceElements()
parser.feed(text)


def source_span(identifier):
    first, last = parser.elements[identifier]
    data = text[first:last].encode()
    a, b = len(text[:first].encode()), len(text[:last].encode())
    assert raw[a:b] == data and f'id="{identifier}"'.encode() in data
    return {
        'source_id': identifier, 'char_start': first, 'char_end': last,
        'raw_utf8_start': a, 'raw_utf8_end': b,
        'lf_line_start': text.count('\n', 0, first) + 1,
        'lf_column0_start': first - text.rfind('\n', 0, first) - 1,
        'lf_line_end': text.count('\n', 0, last) + 1, 'span_sha256': sha(data),
    }


P = Path('AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumRadialFourthMoment.lean')
T = Path('Tests/GaussianComplexityFixedSpectrumRadialFourthMoment.lean')


def code_span(path, first, last):
    raw_code = path.read_bytes()
    lines = raw_code.splitlines(keepends=True)
    assert 1 <= first <= last <= len(lines)
    prefix, body = b''.join(lines[:first - 1]), b''.join(lines[first - 1:last])
    return {'path': str(path), 'file_sha256': sha(raw_code),
            'LF_lines_1based': [first, last],
            'raw_UTF8_byte_span': [len(prefix), len(prefix) + len(body)],
            'decoded_char_span': [len(prefix.decode()), len(prefix.decode()) + len(body.decode())],
            'span_sha256': sha(body)}


def mapping(identifiers, ranges, meaning):
    return {'source': [source_span(x) for x in identifiers],
            'lean': [code_span(*entry) for entry in ranges], 'meaning': meaning}



mappings = [
    mapping(['S4.Thmtheorem4.p1.m2', 'S4.Thmtheorem4.p1.m3'],
            [(P, 24, 24), (T, 15, 15)], 'The standing query range, including q=0 and positive row dimension r=q+1.'),
    mapping(['A3.SS2.p1.m1', 'A3.SS2.p1.m5'],
            [(P, 25, 28), (P, 105, 121), (T, 16, 19)],
            'The canonical one-row Gaussian law and Euclidean radius. The actual product-coordinate pushforward is internal; original-family row transport remains outside this theorem.'),
    mapping(['A3.Ex113.m1'], [(P, 23, 34), (P, 35, 78)],
            'Complete exact producer statement and quartic/entry/matrix integrability, before use of its Bochner expectation.'),
    mapping(['A3.SS2.p14.2', 'A3.Ex113.m1'], [(P, 80, 103)],
            'Actual Gaussian reflection invariance cancels each distinct-coordinate weighted entry.'),
    mapping(['A3.SS2.p14.m1', 'A3.Ex113.m1'], [(P, 105, 188)],
            'Scalar fourth moment three, second moment one, independent mixed moment one and finite sums give r+2. All entries and scalar transport are integrable.'),
    mapping(['S4.E11.m1', 'A3.SS2.p5.m2', 'A3.Ex85.m1'], [(T, 21, 24)],
            'Exact midpoint row index and frequencies0..q. Source row j=i.val+1, constant coordinate one and higher sqrt(2) normalization.'),
    mapping(['A3.SS2.p10.m1', 'A3.SS2.p10.m2', 'A3.Ex107.m1'], [(T, 19, 29), (T, 50, 55)],
            'Literal closed cutoff and actual Gaussian-first Kronecker summand with inverse-d scaling.'),
    mapping(['A3.SS2.p14.m2', 'A3.SS2.p14.m3', 'A3.Ex114.m1'], [(T, 68, 101)],
            'Both rank-one square identities, ordinary Kronecker matrix multiplication and indicator idempotence give the exact actual squared summand and its integrability.'),
    mapping(['A3.SS2.p14.3', 'A3.Ex115.m2'], [(T, 14, 35), (T, 103, 141)],
            'The source-supported individual PSD consequence preceding the displayed sum. The aggregate display is provenance for the termwise step and is not a claimed aggregate theorem.'),
    mapping(['A3.Ex113.m1', 'A3.SS2.p14.3', 'A3.Ex115.m2'], [(T, 142, 158)],
            'The consumer materially uses producer integrability and exact mean through the same fixed continuous linear tensor map, then evaluates the integrated PSD residual.'),
]
draft = json.loads((evidence / 'publication-draft-record.json').read_bytes())
record = {
    'kind': 'Root-authored exact source/Lean map for independent review',
    'source_sha256': sha(raw), 'actual_ASTIS_proof_parents': draft['actual_public_ASTIS_parents'],
    'mappings': mappings,
    'proof_background': [
        {'declaration': 'ProbabilityTheory.stdGaussian_map',
         'source': code_span(Path('.lake/packages/mathlib/Mathlib/Probability/Distributions/Gaussian/Multivariate.lean'), 128, 135),
         'consumer': code_span(P, 80, 103), 'meaning': 'Canonical-law coordinate reflection invariance.'},
        {'declaration': 'ProbabilityTheory.map_pi_eq_stdGaussian',
         'source': code_span(Path('.lake/packages/mathlib/Mathlib/Probability/Distributions/Gaussian/Multivariate.lean'), 137, 143),
         'consumer': code_span(P, 105, 121), 'meaning': 'Actual canonical product-coordinate law bridge.'},
        {'declaration': 'ProbabilityTheory.IsGaussian.memLp_id',
         'source': code_span(Path('.lake/packages/mathlib/Mathlib/Probability/Distributions/Gaussian/Fernique.lean'), 186, 203),
         'consumer': code_span(P, 45, 61), 'meaning': 'Actual finite Gaussian fourth-norm moment supplies matrix-entry domination.'},
        {'declaration': 'AutoSamplingTheory.TechnicalLemmas.StochasticProcesses.GaussianFourthMoment.integral_pow_four_gaussianReal_zero',
         'source': code_span(Path('AutoSamplingTheory/TechnicalLemmas/StochasticProcesses/GaussianFourthMoment.lean'), 23, 89),
         'consumer': code_span(P, 132, 138), 'meaning': 'Reuse the identical compiled scalar fourth-moment node already used by Brownian quadratic variation.'},
        {'declaration': 'Convex.integral_mem',
         'source': code_span(Path('.lake/packages/mathlib/Mathlib/Analysis/Convex/Integral.lean'), 57, 65),
         'consumer': code_span(T, 123, 141), 'meaning': 'The internally proved closed convex PSD cone contains the Bochner residual integral.'},
    ],
    'mathlib_pin': 'db584cd6d46c92f209a44c0f1c829460d327499d',
    'scope': 'Canonical Ex113 and individual Ex114/p14 PSD consequence. Original-family transport, sums, centered variance, concentration and full-paper reader integration remain open.',
}
path = evidence / 'source-lean-map.draft.json'
with path.open('x') as out:
    json.dump(record, out, ensure_ascii=False, indent=2)
    out.write('
')
print(json.dumps({'path': str(path), 'sha256': sha(path.read_bytes()),
                  'source_locator_entries': sum(len(item['source']) for item in mappings),
                  'Lean_spans': sum(len(item['lean']) for item in mappings)}))
