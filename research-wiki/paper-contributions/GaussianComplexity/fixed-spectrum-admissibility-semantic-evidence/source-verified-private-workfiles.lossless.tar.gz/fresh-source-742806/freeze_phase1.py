from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
from bs4 import BeautifulSoup

ROOT = Path('/Users/zhouhuanjian/ASTIS-GC')
OUT = ROOT / 'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-admissibility-semantic-evidence/fresh-source-reader-742806/phase1'
PAPER = ROOT / '.astis/huanjian-resume-20261103/2610.20492v1.html'
EXPECTED = '6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'

def sha(b):
    return hashlib.sha256(b).hexdigest()

def write_json(p, data):
    p.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')

paper_bytes = PAPER.read_bytes()
assert sha(paper_bytes) == EXPECTED
OUT.mkdir(parents=True, exist_ok=False)
raw = OUT / 'raw-inputs'
raw.mkdir()
instruction_paths = [
    'AGENTS.md', 'CONTRIBUTING.md',
    'docs/contributor-codex-contract.md',
    'docs/theorem-publication-protocol.md',
    'docs/proof-digestion-protocol.md',
    'docs/evidence-routed-memory-protocol.md',
    '.agents/prompts/collaborator-contribution.md',
    '.agents/prompts/samplewiki-route.md',
    '.agents/skills/astis-substantive-advance/SKILL.md',
    '.agents/skills/astis-semantic-roundtrip/SKILL.md',
    'docs/formalization-protocol.md',
    '.agents/skills/astis-cross-library-coordination/SKILL.md',
]
inputs = []
for i, path in enumerate(instruction_paths):
    b = (ROOT / path).read_bytes()
    dest = raw / f'{i:02d}-instruction-{path.replace("/", "__")}.raw'
    dest.write_bytes(b)
    inputs.append({'role': 'instruction', 'original_path': path,
                   'snapshot': str(dest.relative_to(OUT)), 'sha256': sha(b),
                   'bytes': len(b)})
dest = raw / 'paper-2610.20492v1.raw.html'
dest.write_bytes(paper_bytes)
inputs.append({'role': 'sole mathematical source', 'original_path': str(PAPER.relative_to(ROOT)),
               'snapshot': str(dest.relative_to(OUT)), 'sha256': sha(paper_bytes),
               'bytes': len(paper_bytes)})

# Convenience rendering only; full exact source above is authoritative.
selected = [('S1', True), ('S1.SS1', False), ('S2', False), ('S4', True),
            ('S4.SS1', False), ('S4.SS2', False), ('A3.SS4', False)]
extracts = []
for id_, omit_subsections in selected:
    soup = BeautifulSoup(paper_bytes, 'html.parser')
    element = soup.find(id=id_)
    assert element is not None
    if omit_subsections:
        for section in element.find_all('section', recursive=False):
            section.decompose()
    for math in element.find_all('math'):
        math.replace_with(' $' + math.get('alttext', '') + '$ ')
    extracts.append(f'ANCHOR {id_}; omit direct child subsections={omit_subsections}\n'
                    + element.get_text(' ', strip=True))
(OUT / 'source-reading-extracts.txt').write_text(
    'DERIVED rendering; authority is raw-inputs/paper-2610.20492v1.raw.html.\n\n'
    + '\n\n'.join(extracts) + '\n')

slots = {
    'reviewer_id': 'fresh-source-reader-742806',
    'phase': '1-raw-source-first-only',
    'source_sha256': EXPECTED,
    'candidate_material_seen': False,
    'seven_semantic_slots': {
        'objects': {
            'anchors': ['S2', 'S4.E11', 'S4.SS1', 'S4.Thmtheorem6', 'A3.SS4'],
            'reconstruction': [
                'Dimension d; condition-number bound kappa; theta_i=((i-1/2) pi)/d; lambda_i=(kappa+1)/2+((kappa-1)/2) cos(theta_i); Lambda=diag(lambda_1,...,lambda_d).',
                'Real orthogonal O and rotated precision A=O Lambda O^T.',
                'Sections 2/4 call the quadratic f_A, while C.4 calls it V_A: both are x^T A x/2.',
                'Actual centered Gaussian target pi_A=N(0,A^{-1}), covariance A^{-1}, and unnormalized Gaussian integral Z_A.',
                'Euclidean norm, identity I_d, and Loewner order on real symmetric matrices.'
            ]
        },
        'domains': {
            'anchors': ['S2', 'S4.SS1', 'A3.SS4'],
            'reconstruction': [
                'The Eq. (11) fixed-spectrum family has integer d>=2 and real kappa>=2. The earlier ambient precision class has integer d>=1 and kappa>=1; these ranges must remain distinct.',
                'i ranges through {1,...,d}; x through R^d; matrices are real d-by-d.',
                'O ranges over full O(d)={O:O^T O=I_d}, including determinant +1 and -1. Section 2 gives each component Haar probability 1/2.',
                'A is precision, not covariance; the positive definite inverse A^{-1} is covariance.',
                'The Gaussian density is on all R^d relative to Euclidean Lebesgue volume dx. This is the standard semantic expansion of the stated Gaussian/integration, not an extra source premise.'
            ]
        },
        'quantifiers': {
            'anchors': ['S4.SS1', 'S4.Thmtheorem6', 'A3.SS4'],
            'reconstruction': [
                'Fix any source-allowed d,kappa, thereby fixing theta,lambda,Lambda; then for every O in O(d), set A=O Lambda O^T.',
                'Admissibility is pointwise for every O, not merely Haar-almost surely.',
                'The hard-family experiment separately draws O from Haar(O(d)), independently of algorithm private randomness; randomization is not needed as a premise for the universal admissibility fact.',
                'C.4 regularity and Hessian statements hold for every x; strict potential positivity for every x!=0 yields unique minimizer 0.',
                'Z_A is the same for every O at fixed Lambda. This does not assert independence from d,kappa.'
            ]
        },
        'assumptions': {
            'anchors': ['S2', 'S4.SS1', 'S4.Thmtheorem6', 'A3.SS4'],
            'reconstruction': [
                'Standing source inputs: integer d>=2, real kappa>=2, the exact Eq. (11) grid, and real O with O^T O=I_d.',
                'No det(O)=+1 premise and no kappa<=d^(1-delta) premise in admissibility.',
                'Angle/cosine/eigenvalue bounds, symmetry, positive definiteness, Loewner bounds, potential regularity, Gaussian integrability, determinant invariance and the normalizer are ingredients or consequences, not new public input hypotheses.',
                'No query budget, algorithm estimate, Krylov event, target-moment estimate or supplied admissibility witness is assumed.',
                'Theorem 4.1 has additional delta, dimension-threshold, kappa and epsilon ranges; those belong to that theorem.'
            ]
        },
        'conclusion': {
            'anchors': ['S4.Thmtheorem6', 'A3.SS4', 'A3.Ex160'],
            'reconstruction': [
                'The exact short Lemma 4.6 concludes I_d<=A<=kappa I_d in Loewner order for the actual A=O Lambda O^T.',
                'C.4 first obtains 0<theta_i<pi, -1<cos(theta_i)<1, and 1<lambda_i<kappa, then the matrix inequalities.',
                'C.4 additionally states V_A is C-infinity with Hessian A, hence 1-strongly convex and kappa-smooth.',
                'V_A(0)=0 and V_A(x)>=||x||^2/2>0 for x!=0, so 0 is the unique minimizer.',
                'The associated target is N(0,A^{-1}).',
                'Z_A=(2 pi)^(d/2)(det A)^(-1/2)=(2 pi)^(d/2)(det Lambda)^(-1/2); it is independent of O and known whenever the spectrum is public.',
                'Gaussian meaning: Z_A=integral over R^d of exp(-x^T A x/2) dx, and pi_A has Lebesgue density Z_A^{-1} exp(-x^T A x/2). The half in the exponent and inverse covariance are essential.'
            ]
        },
        'scopes_senses': {
            'anchors': ['S1.Thmtheorem3', 'S2', 'S4.SS1', 'S4.Thmtheorem6', 'A3.SS4'],
            'reconstruction': [
                'Loewner order means B-A positive semidefinite for symmetric A,B; the conclusion bounds x^T A x between ||x||^2 and kappa||x||^2 for every real x.',
                'The convention is exp(-V_A), V_A=x^T A x/2, not exp(-x^T A x). Z_A is the integral, not its reciprocal density prefactor.',
                'Lebesgue volume on R^d is the Gaussian normalization measure; Haar probability on O(d) is a separate eigenbasis law.',
                'The spectrum may be public while the eigenbasis is unknown. Admissibility is not a sampling/query lower bound.',
                'Section 2 exact first-order/matrix-vector equivalence is context, not the short Lemma 4.6 conclusion.',
                'Full C.4 is broader than a scalar-grid or matrix-bound producer. A narrow result must retain its narrow source boundary.',
                'This phase asserts no candidate fidelity, Lean closure, source-graph coverage approval, module acceptance or reader acceptance.'
            ]
        },
        'constant_dependencies': {
            'anchors': ['S4.E11', 'S4.Thmtheorem6', 'A3.SS4', 'S4'],
            'reconstruction': [
                'theta_i depends on d,i; lambda_i on d,kappa,i; Lambda on d,kappa; A also on O.',
                'Admissibility constants are exactly 1,kappa. No hidden large-d threshold, delta, epsilon or probability constant enters.',
                'Z_A depends on fixed d,kappa through Lambda, and not on O or its determinant sign. det(A)=det(Lambda)>0; orientation is not a normalizer factor.',
                'Context only: for each fixed delta in (0,1), Theorem 4.1 has d_0(delta), all integer d>=d_0(delta), 2<=kappa<=d^(1-delta), 0<epsilon<=1/10, and Q_G>=(delta/256)sqrt(kappa)log d. These dependencies do not belong to Lemma 4.6.'
            ]
        }
    }
}
write_json(OUT / 'seven-semantic-slots.source-only.json', slots)

(OUT / 'source-contract.source-only.md').write_text(r'''# Independent source-only contract

Authority: On Complexity of Gaussian Sampling, arXiv:2610.20492v1.
Exact raw HTML SHA-256: 6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915.
The raw paper is preserved under raw-inputs/. Derived excerpts are conveniences.

## Exact family and principal result

For integer d>=2, real kappa>=2, and 1<=i<=d, Eq. (11) defines

    theta_i = ((i - 1/2) pi)/d
    lambda_i = (kappa+1)/2 + ((kappa-1)/2) cos(theta_i)
    Lambda = diag(lambda_1,...,lambda_d).

For every real O satisfying O^T O=I_d, set A=O Lambda O^T.
The short Lemma 4.6 concludes I_d <= A <= kappa I_d in Loewner order.
This covers full O(d), determinant +1 and -1. The hard-family Haar draw and its
independence from algorithm randomness are separate from this universal fact.
Section 2's ambient class d>=1,kappa>=1 does not erase the family's d>=2,kappa>=2.

## Full C.4 content and exact target meaning

The source proof asserts these moves, with no external citation in C.4:

1. The grid has 0<theta_i<pi, hence -1<cos(theta_i)<1, hence 1<lambda_i<kappa.
2. Diagonalization and orthogonality give I_d<=A<=kappa I_d for the actual A.
3. V_A(x)=x^T A x/2 is C-infinity with Hessian A, hence 1-strongly convex and
   kappa-smooth.
4. V_A(0)=0 and V_A(x)>=||x||^2/2>0 for x!=0, so 0 is the unique minimizer.
5. The associated target is the actual Gaussian N(0,A^{-1}); A is precision and
   A^{-1} is covariance.
6. Gaussian integration gives

    Z_A = (2 pi)^(d/2) (det A)^(-1/2)
        = (2 pi)^(d/2) (det Lambda)^(-1/2).

Since Lambda is fixed, Z_A is independent of O and known when the spectrum is
public. In particular det(A)=det(Lambda)>0 for both determinant signs of O.
No orientation-preserving hypothesis is available.

The semantic expansion of the Gaussian law and normalizing integral is

    Z_A = integral_{R^d} exp(-x^T A x/2) dx
    density(pi_A)(x) = Z_A^{-1} exp(-x^T A x/2)
                    = sqrt(det A)/(2 pi)^(d/2) exp(-x^T A x/2).

Here dx is Euclidean Lebesgue volume on the entire space, distinct from Haar
probability on O(d). C.4 writes "Gaussian integration" and its result rather
than explicitly spelling out dx. The display records ordinary Gaussian meaning,
not an extra assumption. Remark 1.3 explicitly uses pi proportional to exp(-V).
The half in the exponent, inverse covariance, exponent d/2, and distinction
between integral Z_A and reciprocal density prefactor must be preserved.

## Source ingredients versus inputs

Inputs are the standing d,kappa ranges, exact grid, real carriers, orthogonality.
Angle, cosine, eigenvalue, quadratic-form, Hessian, unique-minimizer,
integrability and determinant facts are ingredients/consequences. They cannot
be extra public source-facing hypotheses merely because producer lemmas exist.

The source compresses "orthogonal conjugation preserves spectral bounds",
"the quadratic has Hessian A", and "Gaussian integration gives the formula".
This phase records those source moves; it does not certify formal implementation,
source-graph completeness, dependencies or Lean closure.

## Failure and source-scope boundaries

- Restricting to SO(d) loses the stated full-group domain.
- Replacing exact A=O Lambda O^T by an arbitrary already-admissible matrix loses
  the actual fixed-spectrum construction.
- Scalar-grid or diagonal-spectrum bounds are narrower than Lemma 4.6. Matrix
  admissibility alone is narrower than full C.4 regularity/target/normalization.
- Swapping precision and covariance, dropping the inverse, changing exp(-V_A),
  using a Gaussian base law for the integral, or confusing Z_A and Z_A^{-1}
  changes the object.
- Strict eigenvalue bounds use kappa>1 supplied by kappa>=2. At kappa=1 they
  become equalities; any extension requires explicit classification.
- Public spectrum means no dependence of Z_A on unknown O. It does not mean
  independence from d,kappa and does not specify computational cost.
- Lemmas 4.3--4.5 concern Krylov representation, uniform cosine estimates and
  target moments. They are nearby context, not Lemma 4.6 hypotheses/conclusions.
- Theorem 4.1 separately has fixed delta in (0,1), d>=d_0(delta),
  2<=kappa<=d^(1-delta), 0<epsilon<=1/10, and
  Q_G>=(delta/256)sqrt(kappa)log d. C.4 admissibility is not that main lower bound.
- Section 2 exact first-order/matrix-vector oracle equivalence is context.
  Query budgets in the paper are deterministic caps per run, not expected costs.

## Phase-one limit

This is a fresh source-text reconstruction. No candidate Lean statement, code,
tests, proof explanation, publication, exact seals, source graph/topology
outputs, old reviewer verdict contents, anonymous packet or blind reconstruction
has been opened. No candidate status, fidelity, mathematical closure, module or
reader acceptance is asserted. The filename-enumeration caveat is disclosed in
the exposure record. Later comparison must preserve the distinction between a
narrow producer, full C.4 content, and Theorem 4.1.
''')

exposure = {
    'reviewer_id': 'fresh-source-reader-742806', 'phase': '1',
    'source_text_visible': True,
    'candidate_statement_visible': False, 'candidate_code_visible': False,
    'candidate_tests_visible': False, 'candidate_prose_or_publication_visible': False,
    'exact_seals_visible': False, 'source_graph_or_topology_outputs_visible': False,
    'prior_reviewer_verdict_contents_visible': False, 'anonymous_packet_visible': False,
    'blind_reconstruction_visible': False, 'implementation_or_api_proof_visible': False,
    'raw_source_semantically_read': [
        'S1 introductory text excluding S1.SS1, then S1.SS1 in full',
        'S2 in full',
        'S4 introductory/theorem text excluding subsections',
        'S4.SS1 in full including Eq. (11)',
        'S4.SS2 in full including contextual Lemmas 4.3--4.6',
        'A3.SS4 in full including A3.Ex160',
        'Source section-id/title/length inventory used for locating sections',
        'Source-only math-alttext search for Z_A, exp and integration formulas returned isolated A2.Ex56, A2.Ex60, A2.SS2.SSS2.p4.4, A2.Ex68, A2.Ex71, A2.Ex72 formulas; no candidate material'
    ],
    'instruction_inputs': instruction_paths,
    'metadata_exposure_caveat': {
        'event': 'Initial instruction-location rg --files search was overly broad and returned a large truncated filename listing.',
        'command': "pwd && rg --files -g 'AGENTS.md' -g '*CONTRIBUT*' -g '*theorem*publication*' -g '*proof*digestion*' -g '*evidence*memory*' -g '*semantic*roundtrip*' -g '*source*review*' -g '!**/node_modules/**' -g '!**/.git/**' /Users/zhouhuanjian/ASTIS-GC",
        'extent': 'Path metadata only, including old review/evidence directories in this and other source families. No contents from those files were opened.',
        'interpretation': 'No candidate semantics, implementation, old verdict contents or approval status was read or inferred from filenames. Caveat retained explicitly.'
    },
    'ancestor_instructions': 'Only repository AGENTS.md was present on tested root-to-owned-output ancestor paths; no nested AGENTS.md.',
    'phase_specific_exclusions': 'Parent restricts this phase to raw source/instructions. No normal SAU, discovery, sourceV, ledger, Registry, root Test, site, browser or remote API invoked. Generic instruction steps requiring candidate/frontier exposure were deferred.',
    'mutations': ['Assigned fresh-source-reader-742806/phase1 outputs and private fresh-source-742806 helper only.'],
    'subagents_spawned': False, 'proof_construction_performed': False,
    'candidate_verdict': 'not assessed; candidate not exposed',
    'write_attempt_note': 'An initial apply_patch script-add failed validation because JS string escaping split a LaTeX backslash sequence. It created no file and performed no candidate read; a plain-text contract generator was then added.'
}
write_json(OUT / 'exposure.source-only.json', exposure)
(OUT / 'README.md').write_text('''# Fresh source reader 742806 — phase one freeze

This source-only freeze precedes selective candidate/reconstruction exposure.
The pinned raw arXiv HTML is the sole mathematical source. Read the seven slots,
source contract and exposure record together. raw-inputs/ preserves exact paper
and instruction bytes. The filename-enumeration caveat is explicit.

manifest.json binds all phase files except itself; manifest.sha256 seals it.
The helper hash records the generator. This evidence is source-text
reconstruction, not Lean truth or candidate approval. Later comparison belongs
in a separate phase directory; this phase is frozen.
''')

manifest = {
    'schema': 'fresh-source-reader-phase1-freeze-v1',
    'reviewer_id': 'fresh-source-reader-742806',
    'frozen_at_utc': datetime.now(timezone.utc).isoformat(),
    'phase': '1-source-only-before-selective-comparison',
    'source_sha256': EXPECTED, 'exact_raw_inputs': inputs,
    'generator': {'path': str(Path(__file__).relative_to(ROOT)),
                  'sha256': sha(Path(__file__).read_bytes())},
    'files': [{'path': str(p.relative_to(OUT)), 'sha256': sha(p.read_bytes()),
               'bytes': p.stat().st_size}
              for p in sorted(OUT.rglob('*')) if p.is_file()],
    'candidate_exposure': False, 'candidate_acceptance': 'not assessed',
    'scope': 'source text only; no Lean/proof closure',
    'next_phase': 'STOP; await root selective anonymous statement, approved contexts and independent blind reconstruction; freeze comparison before whole-module exposure'
}
write_json(OUT / 'manifest.json', manifest)
manifest_sha = sha((OUT / 'manifest.json').read_bytes())
(OUT / 'manifest.sha256').write_text(manifest_sha + '  manifest.json\n')
print(json.dumps({
    'phase1_path': str(OUT), 'manifest_sha256': manifest_sha,
    'source_sha256': EXPECTED,
    'seven_slots_sha256': sha((OUT / 'seven-semantic-slots.source-only.json').read_bytes()),
    'source_contract_sha256': sha((OUT / 'source-contract.source-only.md').read_bytes()),
    'exposure_sha256': sha((OUT / 'exposure.source-only.json').read_bytes()),
    'raw_input_count': len(inputs)
}, indent=2))
