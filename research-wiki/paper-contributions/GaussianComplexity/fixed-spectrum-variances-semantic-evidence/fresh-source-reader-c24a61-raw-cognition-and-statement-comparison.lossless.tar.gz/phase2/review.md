# Independent Phase 2 statement review

This judgment compares the exact supplied statement and embedded anonymous reconstruction with the raw-source cognition frozen in Phase 1. It is confined to the actual-Gaussian variance portion of Lemma 4.5 and Appendix C.3, together with the separately supplied private numerical consumer. It does not judge a Lean proof, compilation, declaration identity, actual dependency use, publication binding, or a complete source theorem.

The selective input hash is `8eb89d562697f2712b3e2c661766463a5103b9aaddf5663d8f07d52635728b93`. Its manifest hash is `29659f9b9040713bf70722b30ea36721dfa17426dcf36ddece36034cf388e8bb`. The prior Phase 1 freeze hash is `163bb0977e6e7ec36f895cdad15529e4f96ef4870b4f50a5fa3384a16f78f52e`. The main statement hash is `e72c27e801f97a76f681608b09c9c7cc069c29e55b6adf837d95b54d480e33b8`; the embedded reconstruction hash is `2762ba46ddfc0258fa0f7ca08ebabfba2dc404ece3477e23d0ae5f0e3543979a`. All of these digests were checked against the exact supplied bytes/text. The canonical parent packet remains unread and is only a hash reference.

## Judgment

The main statement and its reconstruction preserve the reviewed source variance claim on its actual standing domain. The two explicit square-integrability conclusions are justified source-implicit consequences of the actual finite-dimensional Gaussian law and the fourth-moment argument; they are additional conclusions, not added assumptions. No blocking semantic delta or source repair is required for this bounded variance result.

The private consumer is a compatible generalized numerical variance helper. Its scope is all admissible n and all tau in [0,1/2], with the same literal Gaussian law, and its conclusions are square integrability and `Var(Z)<=8M`. This accepts its mathematical statement as a sufficient variance ingredient for the displayed application. It does not accept all of Ex25, Lemma 4.5, Appendix C.3, Theorem 4.1, or any source-wide publication status.

## Seven semantic slots

1. **Objects — equivalent.** Source Eq. (11), `S4.E11` (raw lines 1090–1097), fixes the actual cosine-grid diagonal precision matrix. `S4.Thmtheorem5` (1261–1293) uses the actual Gaussian `U~N(0,Lambda^{-1})`. The supplied measure `multivariateGaussian 0 Lambda^{-1}` has the same law under the supplied covariance convention. Standard Euclidean norm and exposed coordinates give `||x||^2=sum_i x_i^2`. The diagonal quadratic form `U^T D_n U` is exactly the supplied coordinate sum Q. The definition of M as the integral of the squared norm is its actual target mean. No abstract law with assumed moments replaces the Gaussian.

2. **Domains — equivalent.** Source Section 4.1 assumes integer d>=2 and real kappa>=2; Lemma 4.5 assumes integer 1<=n<d. These are precisely hd, h-kappa, hn, and hnd. Source coordinates i=1,...,d become Lean i in Fin d through `i_source=i.val+1`, so `(i_source-1/2)pi/d=(i.val+1/2)pi/d`. The index set has exactly d elements, and no grid endpoint is added. There is no need for `d-n>=sqrt(kappa)` in a variance statement: that guard belongs to the later normalized-bias lower bound. There is likewise no delta-dependent upper condition on kappa for these moments.

3. **Quantifiers — equivalent within the declared slice.** The main statement and reconstruction both quantify universally over every admissible triple (d,kappa,n), then make local definitions of theta, eigenvalue, Lambda, the Gaussian measure, Q, and M. Every conclusion uses the same definitions and measure. There is no existential choice of a convenient law, spectrum, representative, or moment witness. The result is not restricted to odd n or to n=2q+1; the source moment lemma also treats every integer 1<=n<d.

4. **Assumptions — no excess mathematical premise.** The only explicit main-statement premises are d>=2, kappa>=2, and 1<=n<d. Coordinate independence, inverse identities, positivity, fourth moments, square integrability, and the upper bound on M are absent from its hypotheses. The source uses the first four as derived properties of its specified Gaussian and spectrum (`A3.SS3.p8.1`, raw 4013–4022), and derives the M bound from its finite-grid moment formula (`A3.SS3.p8.2`, 4036–4037). The input restatement's assertion that facts are "proved internally" is not proof evidence in this review; the signature alone establishes that these facts have not been moved into public binders.

5. **Conclusions — source variance formulas and bounds preserved, with explicit finiteness.** The raw identities are `A3.Ex148` and `A3.Ex149` inside `A3.EGx17` (4023–4035): `Var(||U||^2)=2 sum_i lambda_i^{-2}` and `Var(U^T D_n U)=2 sum_i cos^2(n theta_i)/lambda_i^2`. The raw inequalities bound both by 2M, followed by `M<=d/sqrt(kappa)` at 4036. The statement has these two exact formulas, both bounds by 2M, and the same final `2M<=2d/sqrt(kappa)`. Its `1/(eigenvalue i)^2` has the correct inverse-square meaning. Its two MemLp conclusions make square integrability explicit. The reconstruction enumerates exactly those seven conjuncts. Neither the exact means, the signed-bias identity, nor the guarded exponential bias estimate is a conclusion of this target, so this review grants them no coverage.

6. **Scopes and senses — equivalent on the supported domain.** The Gaussian matrix parameter is covariance, while Lambda is precision. This distinction is preserved. From kappa>=2, `lambda_i>=(kappa+1)/2-(kappa-1)/2=1`; hence Lambda is positive definite and invertible and Lambda^{-1} is positive definite. The supplied totalized inverses and square root therefore evaluate on their ordinary positive-definite branches. No off-domain fallback measure is being used. The source's ordinary finite variance agrees with the supplied extended centered second moment followed by ENNReal.toReal: MemLp for both observables, on a Gaussian probability measure, gives finite first and centered second moments and excludes the infinity-to-zero branch. All integrals refer to the same actual Gaussian probability law. The source restatement is treated as a restatement, with the previously frozen raw source as authority.

7. **Constants and dependencies — preserved.** Every main variance identity and upper bound has the exact numerical factor 2. No hidden parameter-dependent constant occurs. M depends on (d,kappa), Q's coefficients on (d,n), and the Gaussian covariance on (d,kappa). There is no auxiliary absolute C, error tolerance, query count, or sufficiently-large-d threshold in this result. The private consumer's factor 8 is uniform in d, kappa, n, and tau over its displayed guards, as checked below.

## Private consumer: exact scope and application boundary

The private consumer statement hash is `61c69b97aa87c435f9d33fdd8033fcd38752e125b01fafd0ccb24748288bcb1f`. It universally quantifies over d>=2, kappa>=2, natural n with 1<=n<d, and real tau with 0<=tau<=1/2. It defines the same Gaussian measure and functions, then

`Z(x)=(-1)^n Q(x)-2 tau ||x||^2`,

and concludes precisely `MemLp Z 2 mu` and `Var[Z;mu]<=8M`.

This statement is mathematically compatible with the source variance clause in `S4.Ex25` (raw 1464–1470). Square-integrability of the two constituent observables gives square-integrability of Z. Since `|(-1)^n|=1`, the source's L2 triangle inequality for centered variables gives

`sqrt(Var Z) <= sqrt(2M)+2 tau sqrt(2M)`.

The guards 0<=tau<=1/2 imply `(1+2tau)^2<=4`, so `Var Z<=2M(1+2tau)^2<=8M`. This uses no independence of Q and the squared norm, no oddness of n, and no mean-bias premise. It is an independent check of the statement's mathematical scope, not a claim about how any Lean proof is written.

The source application has additional context: n=2q+1, tau=tau_{d,q}, a sufficiently large d chosen uniformly for fixed delta, a fixed hard-family input A=O Lambda O^T, and an exact sample Y from pi_A. To match its literal statistic `S_A(Y)` to this coordinate-space Z requires the source's orthogonal transport U=O^T Y, norm invariance, and `T_n((2A-(kappa+1)I)/(kappa-1))=O D_n O^T`. The source states the transport at raw 1294–1300 and the Chebyshev identity in 1356–1370. The private helper alone does not establish that transport or an actual implementation call.

The guard `tau<=beta/4` is needed for the separate positive mean estimate `E Z>=(beta M)/2`. The condition `M beta^2>=320` is needed for the later probability .9, while `d-n>=sqrt(kappa)` is used to obtain the bias estimate feeding those guards. None is required for the numerical variance bound `Var Z<=8M` itself. Omitting them from this private variance helper is therefore an appropriate mathematical generalization; omitting them from a claim of the full source application would be unsound. This review does not certify their discharge, actual use of the helper, Ex26's probability estimate, or a sampling/query lower bound.

## Exact deltas and repair disposition

- Zero-based Fin indexing is a bijective coordinate reindexing of the source midpoint grid. It changes neither the spectrum nor the sums. No repair is needed.
- A Gaussian measure with identity random variable replaces random-variable notation. The law is equal under the specified covariance definition and the positive-definite domain. No repair is needed.
- Explicit MemLp conclusions strengthen the raw presentation by exposing finite fourth-moment consequences already used in its variance proof. They add no assumptions and ensure the totalized variance means ordinary finite variance. No repair is needed.
- Totalized square root, inverse, and ENNReal.toReal carry off-domain conventions. The source domain and the explicit L2 conclusions exclude those exceptional branches here. No repair is needed on the reviewed carrier.
- The private consumer extends the source's particular odd n and derived tau to arbitrary valid n and tau in [0,1/2]. This is a bounded helper generalization, not a change to the source theorem or evidence for all of Ex25. No source repair is proposed.
- The selected statement covers the variance subtree, not the whole moment lemma or lower-bound theorem. This is a coverage boundary and must remain explicit in any downstream publication decision.

No blocking delta was found in the seven reviewed semantic slots. The repair list is empty. Compilation, proof correctness, definition implementation, full-module context, actual consumers, build status, sourceV status, and canonical packet/publication acceptance remain unreviewed.
