# Frozen source-first Phase 1

The pinned raw HTML SHA256 is 6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915 (951991 bytes).

Selected regions are Section 2 definition context, Section 4 through Section 4.3, Appendix C.2, Appendix C.3, and bibliography item [22]. Surplus comparison, oracle, roadmap, TV contradiction, and other selected contextual material has an explicit EXCLUDED disposition. Appendix C.1/C.4 proofs and the external [22] document are not extracted.

The inventory has 71 paragraph blocks, plus nested exact statement/prose/display/citation records. Source locators are raw UTF-8 byte intervals, 0-based and half-open. source.raw.html and raw/*.raw.html preserve bytes without normalization. inventory-reader.md uses math alttext only as a reading aid.

The source fixes a sufficiently large absolute positive concentration constant C before the Section 4.3 choice of d0(delta). C is uniform in d, q, kappa, delta and the cutoff. The source does not assert the concentration lemma for every positive C. Both literal tau terms and the 2*tau shifted detector are preserved.

The shifted detector mean bound uses tau<=beta/4. Its final variance bound also consumes tau<=1/2 and uses the centered L2 triangle inequality; it does not assume the two quadratic forms independent. Chebyshev is for each fixed hard-family A, whereas the 0.01 algorithmic pass probability is averaged over the random input.

source-gaps.json preserves abbreviated eventual-cutoff bookkeeping, the spectral-polynomial detector bridge, and uncited matrix Bernstein provenance. These are visible source boundaries, not claims that an inconsistent theorem was found.

No sealed target was available. No proof graph edges, Lean implementation, proof, build, source-fidelity approval, or self-review is included. Phase 2 must preserve this freeze and begin only after the exact sealed target projection is supplied. A distinct reviewer must reread the raw source and challenge topology.

The exposure disclosure records the ambient parent steering, opening broad filename-list exposure, Section 4.4 source exposure, and irrelevant bibliography-ID probe. Read it before assessing independence.
