from pathlib import Path
import gzip
import hashlib
import html
from html.parser import HTMLParser
import json
import re
import sys

ROOT=Path('/Users/zhouhuanjian/ASTIS-GC')
BASE=ROOT/'.astis/huanjian-fixed-spectrum-determinant-20261108/fresh-source-835194/phase3'
EVIDENCE=ROOT/'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-determinant-semantic-evidence'
sys.path[:0]=[str(ROOT/'website/scripts'),str(ROOT/'tools')]
import astis_site as site
import declaration_lessons as lessons
import inline_lean
import publication_reader

def sha(data):return hashlib.sha256(data).hexdigest()
def save(name,value):
 p=BASE/name;p.parent.mkdir(parents=True,exist_ok=True)
 p.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')

producer=ROOT/'AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumDeterminant.lean'
parent=ROOT/'AutoSamplingTheory/TechnicalLemmas/Measure/DisplacementJacobianEntropy.lean'
test=ROOT/'Tests/GaussianComplexityFixedSpectrumDeterminant.lean'
# Execute the repository's exact scanner on only the two renderer-needed modules.
site.project_lean_paths=lambda: [producer,parent]
modules,decls=site.scan_project_sources()
site._SOURCE_BY_NAME={d.full_name:d for d in decls}
site._ACTIVE_GIT=site.GitContext('15fbef72d04a1e9d1e647289a099a6ff8f829125','immutable-source-review','','',False,False,set())
unit=json.loads((ROOT/'website/content/declaration_lessons/huanjian-fixed-spectrum-determinant.json').read_text())['units'][0]
item=json.loads((ROOT/'website/content/publications/huanjian-fixed-spectrum-determinant.json').read_text())['items'][0]
audit=json.loads((ROOT/'research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-determinant.json').read_text())
# The current fragment contains no earlier decision. Do not expose or borrow old reviews.
save('current-audit-shape.json',{'keys':list(audit),'kind':audit.get('kind'),'id':audit.get('id'),'state':audit.get('state'),'verdict':audit.get('verdict'),'source_review_state':audit.get('source_review',{}).get('state')})
local_data={'declarations':site._SOURCE_BY_NAME,'lessons':{unit['declaration']:unit},'audits':{audit['id']:audit},'cells':{}}
publication_reader.publication.inputs=lambda:local_data
page=item['chapter_path']
fragment=publication_reader.source_card(item,page)
(BASE/'reader').mkdir(exist_ok=True)
(BASE/'reader/current-publication-card.html').write_text(fragment)

class Inspect(HTMLParser):
 def __init__(self):
  super().__init__(convert_charrefs=True);self.details=[];self.pre=[];self.stack=[];self.active_pre=None;self.events=[]
 def handle_starttag(self,tag,attrs):
  attrs=dict(attrs)
  if tag=='details':self.details.append(attrs)
  if tag=='pre':self.active_pre=[]
  if tag in ['article','section','details','h2'] :self.events.append({'tag':tag,'attrs':attrs,'position':len(self.events)})
 def handle_data(self,data):
  if self.active_pre is not None:self.active_pre.append(data)
 def handle_endtag(self,tag):
  if tag=='pre' and self.active_pre is not None:self.pre.append(''.join(self.active_pre));self.active_pre=None

parser=Inspect();parser.feed(fragment)
target=site._SOURCE_BY_NAME[unit['declaration']]
exact=inline_lean.display_source(target.source_text)
statement,body=inline_lean.split_statement(exact)
checks={
 'main_formula_exact':r'\[\det A=\prod_{i=1}^{d}\lambda_i.\]' in fragment,
 'all_details_initially_closed':all('open' not in a for a in parser.details),
 'exact_statement_present':statement in parser.pre,
 'exact_proof_present':exact in parser.pre,
 'statement_fold_count':sum('inline-lean-statement' in a.get('class','') for a in parser.details)==1,
 'proof_fold_count':sum('inline-lean-proof' in a.get('class','') for a in parser.details)==1,
 'all_five_math_steps_present':sum('proof-reader-step' in a.get('class','') for a in parser.details)==5,
 'statement_fold_in_first_pass':fragment.index('inline-lean-statement')<fragment.index('Full assumptions and notation'),
 'proof_fold_after_formula_steps':fragment.index('inline-lean-proof')>fragment.index('Consume the determinant in the actual Gaussian density'),
 'source_comparison_adjacent':fragment.index('Source assumptions versus formal assumptions')>fragment.index('inline-lean-proof'),
 'all_assumption_delta_rows_rendered':all(html.escape(row['reason']) in fragment for row in item['bindings'][0]['assumption_deltas']),
 'consumer_formula_exact':html.escape(unit['steps'][4]['formula']) in fragment,
 'producer_parent_exact':unit['astis_dependencies']==['AutoSamplingTheory.TechnicalLemmas.Measure.DisplacementJacobianEntropy.det_conjStarAlgAut_eq'],
 'full_scope_boundary_present':lessons.inline_text(unit['boundary']) in fragment,
 'source_conditions_present':all(lessons.inline_text(a) in fragment for a in unit['assumptions']),
}
save('reader/static-reader-checks.json',{'renderer':'publication_reader.source_card -> declaration_lessons.render_unit -> inline_lean.disclosure','catalogue_scope':'Only the actual producer and its one declared ASTIS renderer parent; canonical repository scanner unchanged, input enumeration bounded.','publication_data_scope':'Exact current lesson/publication/audit only; cells omitted so status remains TODO/pending review, with no fabricated VERIFIED state.','checks':checks,'passed':all(checks.values()),'details_count':len(parser.details),'exact_statement_sha256':sha(statement.encode()),'exact_proof_sha256':sha(exact.encode()),'fragment_sha256':sha(fragment.encode()),'review_limit':'Static content, structure, formula and exact-code/fold adjacency inspection only. No browser pixels, desktop Chrome, deployment or remote reader acceptance claimed.'})
assert all(checks.values()),checks

success=gzip.decompress((EVIDENCE/'proof-attempts/successful-anonymous-consumer.raw.lean.txt.gz').read_bytes()).decode()
failed=gzip.decompress((EVIDENCE/'proof-attempts/first-consumer-broad-rewrite-showterm.raw.lean.txt.gz').read_bytes()).decode()
test_text=test.read_text()
current_prefix=test_text.split('\n#print axioms')[0]
success_prefix=success.split('\n#print axioms')[0]
erased=current_prefix.replace('private theorem actual_gaussian_density_consumer','example',1)
signature=erased[erased.index('example {d'):erased.index(' := by')]+ '\n'
sealed=(EVIDENCE/'actual-consumer-interface/candidate-exact-consumer-signature.txt').read_text()
lines=failed.splitlines(keepends=True);converted=[];under_showterm=False
for line in lines:
 if line=='  show_term\n':under_showterm=True;continue
 if under_showterm and not line.strip():under_showterm=False
 if under_showterm:
  assert line.startswith('  ')
  line=line[2:]
 converted.append(line)
diag={
 'private_name_erasure_equals_successful_anonymous_consumer_statement_and_body':erased==success_prefix,
 'current_consumer_signature_equals_exact_preproof_seal':signature==sealed,
 'failed_input_equals_successful_after_only_show_term_removal_and_indentation':''.join(converted)==success,
 'current_Test_contains_one_private_theorem':len(re.findall(r'^private theorem ',test_text,re.M))==1,
 'new_public_producer_declarations':len([d for d in decls if d.source_file==str(producer.relative_to(ROOT))]),
 'consumer_signature_sha256':sha(signature.encode()),
 'sealed_consumer_signature_sha256':sha(sealed.encode()),
 'failed_input_raw_sha256':sha(failed.encode()),
 'successful_anonymous_input_raw_sha256':sha(success.encode()),
 'classification':{'prior_show_term_timeout':'IMPLEMENTATION_FAILED: diagnostic pretty-print/re-elaboration overhead; exact proof succeeds at unchanged default heartbeat after show_term removal. No source correction, mathematical refutation, heartbeat increase or premise change.','private_name_projection':'Test-only observability change. Exact sealed proposition and proof preserved after erasing private name; later kernel-introspection commands add no theorem assumptions.'}
}
save('private-name-and-diagnostic-checks.json',diag)
assert diag['private_name_erasure_equals_successful_anonymous_consumer_statement_and_body']
assert diag['current_consumer_signature_equals_exact_preproof_seal']
assert diag['failed_input_equals_successful_after_only_show_term_removal_and_indentation']

sanitize=site.sanitize_lean
inventory={}
for p in [producer,test,parent,ROOT/'AutoSamplingTheory/TechnicalLemmas/Measure/GaussianPrecisionDensity.lean',ROOT/'AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumAdmissibility.lean']:
 clean=sanitize(p.read_text())
 inventory[str(p.relative_to(ROOT))]={'sha256':sha(p.read_bytes()),'forbidden_tokens':re.findall(r'\b(?:sorry|admit|axiom|postulate)\b|Prop\s*:=\s*True|:=\s*trivial',clean),'imports':re.findall(r'^import (.+)$',clean,re.M)}
save('static-module-inventory.json',inventory)
assert all(not x['forbidden_tokens'] for x in inventory.values())
print(json.dumps({'static_reader_passed':all(checks.values()),'all_private_projection_checks_passed':True,'no_fake_closure_tokens':True,'reader_fragment_sha256':sha(fragment.encode())},indent=2))
