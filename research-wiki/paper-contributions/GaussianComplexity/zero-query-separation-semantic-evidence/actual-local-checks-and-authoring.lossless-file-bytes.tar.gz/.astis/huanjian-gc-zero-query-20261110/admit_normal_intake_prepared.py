"""Prepared prospective control only; no execution before exact independent grant."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys

if sys.flags.optimize != 0 or os.environ.get('PYTHONOPTIMIZE') != '0':
    raise RuntimeError('Explicit PYTHONOPTIMIZE=0 and active assertions are required')
sys.dont_write_bytecode = True
sys.path.insert(0, 'tools')
import astis_advance as adv

W = Path(__file__).parent
E = Path('research-wiki/paper-contributions/GaussianComplexity/zero-query-separation-semantic-evidence')
C = Path('research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-zero-query-separation.json')
L = Path('runs/substantive_advances.jsonl')
ADV = 'ASTIS-SA-20261110-GaussianComplexityZeroQuerySeparation'
OWNER = 'huanjian_gc_20261110_zero_query_separation'
sha = lambda b: hashlib.sha256(b).hexdigest()
dump = lambda x: (json.dumps(x, ensure_ascii=False, indent=2) + '\n').encode()
def put(path, data):
    assert not path.exists(), path
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)
def ref(path):
    path = Path(path)
    data = path.read_bytes()
    return {'path':str(path),'bytes':len(data),'sha256':sha(data)}
def controls():
    names = {str(p) for p in Path('research-wiki/frontier-cells').rglob('*') if p.is_file()}
    names |= {str(p) for p in Path('runs').iterdir() if p.is_file()}
    names.add('website/content/samplewiki_companion_frontiers.json')
    for p in Path('.astis').iterdir():
        if p.is_file() and any(t in p.name.lower() for t in ['queue','control','global','goal','steer','execution']):
            names.add(str(p))
    for n in ['control','queues','runtime','harness','state','locks']:
        d = Path('.astis') / n
        if d.is_dir():
            names |= {str(p) for p in d.rglob('*') if p.is_file()}
    return sorted(names)

assert len(sys.argv) == 4, 'grant path, exact raw grant SHA256, exact private intake-baseline raw SHA256'
grantpath = Path(sys.argv[1])
assert sha(grantpath.read_bytes()) == sys.argv[2]
grant = json.loads(grantpath.read_bytes())
assert grant['prospective_target_Lean_proof_API_allowed_after_this_grant'] is True
assert grant['root_sole_mathematical_worker'] is True
assert grant['prepared_intake_script_sha256'] == sha(Path(__file__).read_bytes())
assert grant['private_baseline_sha256'] == sys.argv[3]
for row in grant['independent_inputs']:
    assert sha(Path(row['path']).read_bytes()) == row['sha256'], row['path']
baselinepath = W / 'intake-baseline.private.json'
assert sha(baselinepath.read_bytes()) == sys.argv[3]
b = json.loads(baselinepath.read_bytes())
prepath = Path(b['preproof_snapshot']['path'])
assert sha(prepath.read_bytes()) == b['preproof_snapshot']['sha256']
pre = json.loads(prepath.read_bytes())
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip() == pre['head']
sp = W / 'statement-seal-v1.json'
assert sha(sp.read_bytes()) == 'c4c83b1287b9b7ab5cabc8aa7e4f901e4702bd4c2aec99c63957b74db31d4195'
s = json.loads(sp.read_bytes())
prod = s['producer']['planned_file']
test = s['actual_private_consumer']['planned_file']
name = s['producer']['name']
assert not Path(prod).exists() and not Path(test).exists()
assert not (W/'DraftLiteralStatementFormation.lean').exists()
publicseal = Path('research-wiki/paper-contributions/GaussianComplexity/zero-query-separation-statement-seal.json')
assert publicseal.read_bytes() == sp.read_bytes()
assert sha(C.read_bytes()) == b['own_frontier']['sha256']
assert set(b['control_paths']) <= set(controls())
for path, h in b['foreign_control_hashes'].items():
    assert sha(Path(path).read_bytes()) == h, path
before = L.read_bytes()
assert sha(before) == pre['ledger_sha256'] and len(before) == pre['ledger_bytes']
states = adv._replay_advances([json.loads(z) for z in before.splitlines()])
assert states == pre['all_foreign_states'] and ADV not in states
assert states['ASTIS-SA-20261110-GaussianComplexityFixedSpectrumTargetLaw']['state'] == 'VERIFIED'
tracked = [p.decode() for p in subprocess.check_output(['git','ls-files','-z']).split(b'\0') if p]
assert set(tracked) == set(pre['all_tracked_regular_file_hashes'])
for path, h in pre['all_tracked_regular_file_hashes'].items():
    assert sha(Path(path).read_bytes()) == h, path
for path, h in pre['all_existing_frontier_hashes'].items():
    assert sha(Path(path).read_bytes()) == h, path
assert json.loads(C.read_bytes())['owner_id'] == OWNER
put(E/'preproof-source-admission.json', grantpath.read_bytes())
put(W/'intake-tracked-private-preservation.json', dump({
    'all_tracked_hashes_except_own_ledger_and_frontier':{
        p:h for p,h in pre['all_tracked_regular_file_hashes'].items() if p not in {str(L),str(C)}},
    'all_foreign_states':states, 'raw_private_not_for_public_copy':True}))
cell = json.loads(C.read_bytes())
boundary = ('Actual signed coordinate-event mass gap for precision I and diag(kappa,1,...,1), all d>=1,kappa>=4, '
    'and a genuine private arbitrary-common-probability-output event-sup TV obstruction at1/16. '
    'No actual Borel seed/stopping/output/deterministic query-cap adapter, source precision-class '
    'membership adapter, T>=1/Q_G/main bound, fixed-spectrum/disclosed-spectrum transfer, '
    'sourceV/STAB/global integration/site/browser/publication/purification or Goal completion. '
    'All prior states/frontiers/queues and10 source-verified packets retained.')
proposal = adv.AdvanceProposal(
    advance_id=ADV, task_id='ASTIS-SW-GAUSSIAN-COMPLEXITY-2026',
    goal='Prove the actual zero-query Gaussian coordinate-event gap, materially consumed by an actual common-probability-output TV obstruction at the exact source endpoint.',
    source_anchor=cell['source_anchor'], theorem_delta=s['producer']['signature'],
    truth_boundary=boundary, created_by=OWNER,
    dag_inputs=('source:arXiv2610.20492v1 S2; S3.SS3.SSS0.Px1.p1.1 zero-query argument',
        'Existing canonical actual Gaussian/TV background is reused after admission; source graph is not a compiled dependency certificate.'),
    proposed_files=(prod,test,str(C),str(publicseal),
        'website/content/declaration_lessons/huanjian-zero-query-separation.json',
        'website/content/publications/huanjian-zero-query-separation.json',
        'research-wiki/semantic-roundtrip/audits/huanjian-zero-query-separation.json'),
    focused_checks=('lake env lean '+prod,'lake build Tests.GaussianComplexityZeroQuerySeparation'),
    modes=('source-reading','proof-design','compiler-diagnosis'),priority=50,
    frontier_cell=C.stem,target_declarations=(name,))
proposal.validate()
fd = os.open(W/'normal-intake-attempted.once.json', os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
with os.fdopen(fd,'wb') as f:
    f.write(dump({'advance':ADV,'permanent_no_replay_marker':True,'proof_API_not_allowed_until_all3_events_and_postguards_pass':True}))
try:
    adv.propose_advance(proposal)
    adv.transition_advance(ADV,'CLAIMED',worker_id=OWNER,evidence={
        'exact_statement_seal':ref(sp),'preproof_admission':ref(E/'preproof-source-admission.json'),'truth_boundary':boundary})
    adv.transition_advance(ADV,'EXPLORING',worker_id=OWNER,evidence={
        'preproof_admission':ref(E/'preproof-source-admission.json'),
        'target_proof_API_search_starts_only_after_all_postguards':True,
        'preseal_planning_and_old_related_implementation_exposure_retained':True,
        'no_pristine_history_or_self_sourceV_claim':True,'no_own_STAB_authority':True,'truth_boundary':boundary})
except BaseException:
    observed = L.read_bytes()
    put(W/'normal-intake-failed-observed-ledger.PRIVATE.raw.jsonl', observed)
    put(W/'normal-intake-failed-no-replay.json',dump({'ledger_starts_with_original_prefix':observed.startswith(before),'normal_intake_attempted_once':True,'proof_API_authority':False,'next':'Readonly determine exact completed events and legal remaining recovery; never re-propose/reset/rewrite history.'}))
    raise
after = L.read_bytes()
assert after.startswith(before)
app = after[len(before):]
assert len(app.splitlines()) == 3
rows = [json.loads(z) for z in app.splitlines()]
assert all(z['advance_id']==ADV for z in rows)
new = adv._replay_advances([json.loads(z) for z in after.splitlines()])
assert new[ADV]['state']=='EXPLORING' and new[ADV]['owner_id']==OWNER
assert {k:v for k,v in new.items() if k!=ADV} == states
for path, h in pre['all_tracked_regular_file_hashes'].items():
    if path not in {str(L),str(C)}:
        assert sha(Path(path).read_bytes()) == h, path
for path, h in pre['all_existing_frontier_hashes'].items():
    assert sha(Path(path).read_bytes()) == h, path
assert set(b['control_paths']) <= set(controls())
for path, h in b['foreign_control_hashes'].items():
    assert sha(Path(path).read_bytes()) == h, path
assert sha(C.read_bytes())==b['own_frontier']['sha256']
cell['evidence']['preproof_source_admission'] = ref(E/'preproof-source-admission.json')
cell['evidence']['execution_boundary'] = 'EXPLORING only after exact qualified intake3events and preservation postguards. No proof or sourceV yet. '+boundary
C.write_bytes(dump(cell))
assert json.loads(C.read_bytes())['owner_id']==OWNER
put(E/'normal-EXPLORING-append.exact.jsonl',app)
put(E/'normal-intake-preservation.json',dump({'actual_normal_API_calls':3,'state':'EXPLORING',
    'advance_id':ADV,'owner':OWNER,'append_sha256':sha(app),'foreign_states_preserved':len(states),
    'foreign_frontiers_preserved':len(pre['all_existing_frontier_hashes']),
    'protected_tracked_files_preserved':len(pre['all_tracked_regular_file_hashes'])-1,
    'foreign_raw_private':True,'no_proof_or_sourceV_STAB_or_global_credit':True}))
print(json.dumps({'state':'EXPLORING','actual_normal_API_calls':3,'append_sha256':sha(app),
    'foreign_states_preserved':len(states),'foreign_frontiers_preserved':len(pre['all_existing_frontier_hashes']),
    'proof_or_sourceV_credit':False}))
