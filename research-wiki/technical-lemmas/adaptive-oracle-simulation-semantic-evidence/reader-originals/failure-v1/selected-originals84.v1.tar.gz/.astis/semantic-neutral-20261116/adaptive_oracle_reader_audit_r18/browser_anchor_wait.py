"""Observe natural source-anchor settling. Never changes scroll, transforms, styles, or animation."""
import time

OBSERVE_TEMPLATE=r'''el=>{
 const geometry=($VISIBLE$)(el),pre=el.closest('pre');
 return {geometry,performance_ms:performance.now(),window_scroll:{x:scrollX,y:scrollY},
 pre_scroll:pre?{left:pre.scrollLeft,top:pre.scrollTop}:null};
}'''

def signature(s):
    g=s['geometry'];p=s['pre_scroll'] or {'left':0,'top':0}
    return [s['window_scroll']['x'],s['window_scroll']['y'],p['left'],p['top'],
            *[g[k] for k in ['left','right','top','bottom']],g['header'],
            *[g['clip'][k] for k in ['left','right','top','bottom']]]

def wait_for_natural_anchor(page,anchor,visible_expression):
    expression=OBSERVE_TEMPLATE.replace('$VISIBLE$',visible_expression)
    start=time.monotonic();samples=[];stable=False
    def observe():
        s=anchor.evaluate(expression);s['elapsed_ms']=(time.monotonic()-start)*1000;samples.append(s)
    observe()
    while time.monotonic()-start<5:
        remaining=5-(time.monotonic()-start)
        if remaining<=0:break
        page.wait_for_timeout(min(100,remaining*1000));observe()
        tail=samples[-4:]
        if len(tail)==4 and samples[-1]['elapsed_ms']>=500 and all(max(z)-min(z)<=.25 for z in zip(*(signature(s) for s in tail))):
            stable=True;break
    return {'immediate_geometry':samples[0]['geometry'],'settled_geometry':samples[-1]['geometry'],
            'samples':samples,'stable':stable,'maximum_observation_seconds':5,
            'four_stable_samples_interval_ms':100,'stability_tolerance_css_px':.25,'minimum_elapsed_ms':500,
            'strict_visibility_header_predicate_applied_by_caller_unchanged':True,
            'no_programmatic_scroll_style_transform_or_animation_change':True}
