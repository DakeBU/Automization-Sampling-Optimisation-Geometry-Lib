"""Publish a typed source comparison with no compiled implication."""
from pathlib import Path
import hashlib
import json
import sys

sys.dont_write_bytecode = True
sys.path.insert(0, 'tools')
import astis_advance as advance

workspace = Path(__file__).resolve().parent.relative_to(Path.cwd())
evidence = Path('research-wiki/paper-contributions/GaussianComplexity/truncated-row-second-moment-semantic-evidence')
ledger = Path('runs/substantive_discoveries.jsonl')
advance_ledger = Path('runs/substantive_advances.jsonl')
advance_id = 'ASTIS-SA-20261111-GaussianComplexityTruncatedRowMoment'
discovery_id = 'ASTIS-DISC-20261111-GaussianRadialWeightedMatrixSymmetry'
owner = 'huanjian_gc_20261111_truncated_row_moment'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
dump = lambda obj: (json.dumps(obj, ensure_ascii=False, indent=2) + '\n').encode()


def create(path, raw):
    with path.open('xb') as out:
        out.write(raw)


P = Path('AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumTruncatedRowMoment.lean')
metadata = {
    'bridge_id': 'transport:gaussian-radial-weighted-matrix-symmetry',
    'family_id': 'family:orthogonal-invariance',
    'domains': ['concept:truncated-gaussian-row-second-moment', 'concept:gaussian-radial-fourth-moment-matrix'],
    'formula': 'For a radial weight w(R), the symmetry route yields E[w(R) Z Z^T] = E[w(R) R]/r times I_r, once the relevant weighted products are integrable. Ex108 uses w=indicator(R<=L). Ex113 uses w=R and obtains coefficient r+2 from Gaussian fourth moments.',
    'mechanism': 'Coordinate sign changes cancel off-diagonal entries. Coordinate permutations equalize diagonal entries. The trace identifies the common coefficient. The two weights require different moment bounds and coefficient evaluations.',
    'hypothesis_map': {
        'truncated': 'Actual standard Gaussian in r=q+1>=1, literal source L and standing 2q+1<d. The source proof must establish scalar and matrix integrability internally; the retained products are dominated by R indicator(R<=L).',
        'radial_fourth': 'Actual standard Gaussian in the same dimension. The source proof must establish fourth-moment integrability and the standard Gaussian coordinate fourth and mixed second moments internally. These are proof obligations under the fixed law.',
        'shared_symmetry': 'The law and radial weight are invariant under individual coordinate signs and permutations. These invariances follow internally for the canonical standard Gaussian and the two literal weights.',
    },
    'key_estimate': {
        'truncated': '|Z_k Z_l| indicator(R<=L) <= R indicator(R<=L), with finite retained first radial moment.',
        'radial_fourth': '|R Z_k Z_l| <= R^2, with a finite second radial moment. The diagonal coefficient uses E[Z_k^4]=3 and E[Z_k^2 Z_l^2]=1 for distinct coordinates, giving 3+(r-1)=r+2.',
    },
    'conclusion_map': {
        'truncated': 'The compiled local Ex108 identity uses a=E[R indicator(R<=L)]/r. Its actual private consumer derives E[Y_i]=(a/d)(I_r Kronecker t_i t_i^T).',
        'radial_fourth': 'The source Ex113 identity E[R Z Z^T]=(r+2)I_r supplies the later positive-semidefinite variance estimate. This identity and variance estimate have no compiled claim in this candidate.',
    },
    'failure_boundary': 'A nonradial weight or a law with unequal coordinate symmetries can destroy cancellation or equal diagonals. Finite E[R] does not supply the unbounded R-weighted integrability needed by Ex113. The dimension coefficient and radial fourth-moment coefficient have distinct evaluations. The current compiled truncated identity alone does not imply Ex113, matrix concentration or a lower bound.',
    'source_ids': ['arXiv:2610.20492v1#A3.Ex108.m1', 'arXiv:2610.20492v1#A3.Ex113.m1',
                   'arXiv:2610.20492v1#A3.SS2.p14.m1', 'ProbabilityTheory.stdGaussian_map'],
    'graph_views': ['functor', 'overview'],
    'exact_source_and_implementation_anchors': {
        'pinned_source': {'path': '.astis/huanjian-resume-20261103/2610.20492v1.html',
                          'sha256': '6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'},
        'compiled_truncated_source': {'path': str(P), 'sha256': sha(P.read_bytes())},
        'actual_build_receipt': {'path': '.astis/huanjian-resume-20261103/20261111T032852209851Z-radial-row-second-moment-actual-producer-and-consumer-build.receipt.json',
                                  'sha256': 'dfb4a1143aaa6e818df99c7b83b5f7cd81ccc9174d85a8d0282945dce5470a04'},
    },
    'compiled_edges': [],
    'canonical_API_rule': 'Reuse the same compiled ProbabilityTheory.stdGaussian_map declaration wherever invoked. The comparison between distinct radial weights is a conceptual mechanism. No generic weighted-matrix theorem or cross-weight Lean implication is asserted.',
}
proposal = {'discovery_id': discovery_id, 'advance_id': advance_id, 'kind': 'conceptual-mirror',
            'proposed_by': owner, 'metadata': metadata,
            'scope': 'Independent mathematical validation and serialized graph delivery remain separate.'}
proposal_path = evidence / 'conceptual-mirror-radial-matrix-symmetry.json'
create(proposal_path, dump(proposal))
before, adv_before = ledger.read_bytes(), advance_ledger.read_bytes()
states = advance._replay_discoveries([json.loads(x) for x in before.splitlines()])
assert discovery_id not in states
assert advance._replay_advances([json.loads(x) for x in adv_before.splitlines()])[advance_id]['state'] == 'EXPLORING'
discovery = advance.Discovery(
    discovery_id=discovery_id, advance_id=advance_id, kind='conceptual-mirror',
    statement='Radial truncation and the source radial fourth-moment matrix use the same sign/permutation/trace mechanism with different integrability and coefficient evaluations.',
    evidence=str(proposal_path), where_it_matters='Keep the C.2 truncation and variance routes source-connected while preserving their distinct mathematical obligations.',
    provenance='Pinned C.2 Ex108, Ex113 and the actual locally compiled truncated row proof.',
    created_by=owner, frontier_cell='ASTIS-SW-GAUSSIAN-COMPLEXITY-truncated-row-second-moment',
    metadata=metadata,
)
create(workspace / 'conceptual-mirror-publish-attempted.once.json', dump({'id': discovery_id, 'ledger_before_sha256': sha(before)}))
advance.publish_discovery(discovery)
after = ledger.read_bytes()
assert after.startswith(before) and advance_ledger.read_bytes() == adv_before
append = after[len(before):]
event = json.loads(append)
assert len(append.splitlines()) == 1 and event['discovery_id'] == discovery_id and event['status'] == 'raw'
assert event['metadata'] == metadata
now = advance._replay_discoveries([json.loads(x) for x in after.splitlines()])
assert now.pop(discovery_id)['status'] == 'raw' and now == states
create(evidence / 'conceptual-mirror-raw-discovery.exact.jsonl', append)
result = {'status': 'raw', 'proposal_sha256': sha(proposal_path.read_bytes()),
          'append_sha256': sha(append), 'foreign_discoveries_preserved': len(states)}
create(evidence / 'conceptual-mirror-raw-publication.json', dump(result))
print(json.dumps(result))
