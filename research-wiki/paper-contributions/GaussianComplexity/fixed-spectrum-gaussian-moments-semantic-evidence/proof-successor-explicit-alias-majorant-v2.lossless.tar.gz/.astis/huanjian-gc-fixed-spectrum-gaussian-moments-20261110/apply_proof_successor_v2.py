from pathlib import Path
import copy, gzip, hashlib, json, re, sys, tarfile
sys.dont_write_bytecode = True
sys.path.insert(0, 'tools')
import astis_publication as pub
import astis_semantic_roundtrip as rt
W = Path('.astis/huanjian-gc-fixed-spectrum-gaussian-moments-20261110')
E = Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-gaussian-moments-semantic-evidence')
R = Path('.astis/semantic-neutral-20261110/src_d63b90')
sha = lambda b: hashlib.sha256(b).hexdigest()
dump = lambda x: (json.dumps(x, ensure_ascii=False, indent=2) + '\n').encode()
def ref(p):
    return {'path': str(p), 'sha256': sha(p.read_bytes()), 'bytes': p.stat().st_size}
def put(p, b):
    assert not p.exists(), p
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(b)
seal = json.loads((W / 'statement-seal-v2.json').read_bytes())
prod = Path(seal['producer']['planned_file'])
test = Path(seal['actual_private_consumer']['planned_file'])
name = seal['producer']['name']
assert sha(prod.read_bytes()) == '6fb5f83f8c392814246dd39c1f95201215407fd8e14243f3b0e1e6e7895a847d'
for p, n, sig in [(prod, 'theorem actual_diagonal_gaussian_quadratic_means', seal['producer']['signature']),
                  (test, 'private theorem actual_gaussian_cosine_alias_series', seal['actual_private_consumer']['signature'])]:
    assert p.read_text().split(n, 1)[1].split(' := by', 1)[0] == sig.split(n, 1)[1].rstrip()
    assert not re.search(r'\b(sorry|admit|axiom)\b|Prop\s*:=\s*True|:=\s*trivial\b', p.read_text())
stems = ['20261109T161722581865Z-gaussian-moments-consumer-explicit-alias-norm-context-v3',
         '20261109T161938274545Z-gaussian-moments-final-kernel-and-diagonal-quadratic-meaning-v3']
checks = []
for stem in stems:
    p = Path('.astis/huanjian-resume-20261103') / (stem + '.receipt.json')
    d = json.loads(p.read_bytes())
    assert d['exit_code'] == 0 and sha(Path(d['log']).read_bytes()) == d['log_sha256']
    checks.append({'receipt': ref(p), 'raw_log_sha256': d['log_sha256'], 'exit_code': 0})
lessonpath = Path('website/content/declaration_lessons/huanjian-fixed-spectrum-gaussian-moments.json')
oldlesson = lessonpath.read_bytes()
lesson = json.loads(oldlesson)
step = lesson['units'][0]['steps'][4]
step['text'] = 'The range 1≤n<d makes the constant grid mode zero. Product-to-sum and the all-integer midpoint alias identity evaluate both inner sums, each contributing d times A_d. Every guarded alias has absolute value at most one, so the supported term is dominated by2r^j. C7 at angle zero supplies the geometric majorant summability. This estimate is actually used to produce supported-series summability. Nat j+1 is cast to Int before subtracting n.'
step['formula'] = r'\begin{gathered}|A_d(k)|\le1,\qquad|(-r)^j[A_d(j-n)+A_d(j+n)]|\le2r^j,\\\mathbb E Q(U)=\frac d{\sqrt\kappa}\sum_{j\ge1}(-r)^j[A_d(j-n)+A_d(j+n)],\qquad\sum_{j\ge1}|(-r)^j[A_d(j-n)+A_d(j+n)]|<\infty.\end{gathered}'
step['lean'] = 'hcos calls canonical actual_midpoint_grid_cosine_alias at n and both signed shifts. hnnon/hzero discharge the low-mode guard; hprod is product-to-sum and hterm proves2G_j=dF_j. ha_bound proves the normalized signed alias norm bound, hFmajor proves the explicit2r^(j+1) majorant, hbase uses C7 habs0, and hFnorm/hF actually derive supported summability from that bound. hseries/hexchange finish the actual Gaussian expectation. Public ASTIS consumer parents remain exactly new means, C7 and GridAlias.'
put(E / 'proof-successor-v2-history/lesson-before-explicit-alias-bound.raw.json', oldlesson)
lessonpath.write_bytes(dump(lesson))
ap = Path('research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-gaussian-moments.json')
oldaudit = ap.read_bytes()
a = json.loads(oldaudit)
assert a['state'] == 'blind-reconstructed' and a['source_review'] == {'state': 'pending'}
put(E / 'proof-successor-v2-history/audit-before-binding-successor.raw.json', oldaudit)
item = json.loads(Path('website/content/publications/huanjian-fixed-spectrum-gaussian-moments.json').read_bytes())['items'][0]
binding = item['bindings'][0]
pub.inputs.cache_clear()
pub.load.cache_clear()
a['publication_binding_sha256'] = pub.binding_digest(item, binding)
a['publication_context'] = pub.review_context(item, binding)
ap.write_bytes(dump(a))
full = rt.semantic_reviewer_packet(a)
put(E / 'fresh-source-reviewer-packet-v2.json', dump(full))
assert full['lean']['statement_sha256'] == json.loads((E / 'fresh-source-reviewer-packet.json').read_bytes())['lean']['statement_sha256']
initial = json.loads((E / 'local-proof-capsule.json').read_bytes())
capsule = copy.deepcopy(initial)
capsule['private_consumer'].update(ref(test))
capsule['actual_checks'] = checks
capsule['proof_successor_reason'] = 'Actual normalized alias bound and2r^j majorant are now produced and materially used, matching the explicitly named source-graph background estimate. Initial target proof remains preserved and true. No statement or source condition changed.'
capsule['source_statement_review'] = {'reviewer': '/root/source_reader_d63b90',
    'phase2_freeze_sha256': 'dec575f0e6af490e52fdd8fc691336d7df39ce25cf7999cf8cffd434a6222baa',
    'scope': 'Equivalent public Ex140 subresult and faithful private actual Gaussian series statement only; no implementation/runtime/sourceV credit. Original strict whitelist inputs remain byte-identical.'}
capsule['compile_scope'] = 'Final exact source files over ca3665, before immutable candidate commit. Public producer unchanged; private proof refined with explicit alias majorant.'
capsule['prior_local_proof_capsule'] = ref(E / 'local-proof-capsule.json')
capsule['publication_binding_sha256'] = a['publication_binding_sha256']
capsule['full_reviewer_packet_canonical_sha256'] = full['packet_sha256']
meaning = {'kind': 'compiled-meaning-audit-only-not-new-production-node',
    'probe': ref(W / 'KernelAndExactMeaningV3.lean'), 'actual_receipt': checks[-1]['receipt'],
    'claim': 'For every real Euclidean x and finite diagonal weights w, x dot(diag(w)*x)=sum_i w_i*x_i²; Matrix.mulVec_diagonal, dotProduct and ring discharge the coordinate meaning. Exact public/private sealed types and recursive actual parent/axiom checks run in the same successful command.'}
put(E / 'diagonal-quadratic-meaning-audit.json', dump(meaning))
mapping = json.loads((E / 'source-to-lean-map.json').read_bytes())
for row in mapping['obligations']:
    if row['source_node'] == 'gap:alias-series-summability':
        row['local_provider'] = 'have ha_bound'
        row['line'] = next(i + 1 for i, line in enumerate(test.read_text().splitlines()) if 'have ha_bound' in line)
        row['implementation_map'] = 'ha_bound produces |a(k)|<=1 at every signed k. hrnonneg/hpownorm and hFmajor prove the actual2r^(j+1) majorant; hbase is C7 absolute convergence at0, hFnorm/hF materially use the bound to produce Summable. No unused alias-bound wrapper.'
    if row['source_node'] == 'gap:norm-quadratic-coordinate-identities':
        row['compiled_diagonal_quadratic_meaning_audit'] = ref(E / 'diagonal-quadratic-meaning-audit.json')
        row['implementation_map'] += ' The generic diagonal quadratic coordinate identity is additionally compiled in the exact meaning-audit probe; it creates no production/Registry node.'
mapping['proof_successor_of'] = ref(E / 'source-to-lean-map.json')
put(E / 'source-to-lean-map-v2.json', dump(mapping))
capsule['source_to_lean_map'] = ref(E / 'source-to-lean-map-v2.json')
put(E / 'local-proof-capsule-v2.json', dump(capsule))
payload = [prod, test, W / 'KernelAndExactMeaningV2.lean', W / 'KernelAndExactMeaningV3.lean',
    W / 'retained-consumer-v1-before-explicit-alias-bound.lean.gz',
    W / 'retained-consumer-v2-alias-bound-elaboration-failure.lean.gz', W / 'apply_proof_successor_v2.py']
archive = E / 'proof-successor-explicit-alias-majorant-v2.lossless.tar.gz'
assert not archive.exists()
with tarfile.open(archive, 'w:gz') as t:
    for p in payload:
        t.add(p, arcname=str(p), recursive=False)
with tarfile.open(archive, 'r:gz') as t:
    for p in payload:
        assert t.extractfile(str(p)).read() == p.read_bytes()
put(E / 'proof-successor-v2-archive-manifest.json', dump({'archive': ref(archive), 'files': [ref(p) for p in payload]}))
actual = []
for p in sorted(Path('.astis/huanjian-resume-20261103').glob('*-gaussian-moments-*.receipt.json')):
    if not any(v in p.name for v in ['consumer-explicit-', 'final-kernel-']):
        continue
    d = json.loads(p.read_bytes())
    raw = Path(d['log']).read_bytes()
    assert sha(raw) == d['log_sha256']
    dest = E / 'actual-proof-successor-checks' / p.name
    put(dest, p.read_bytes())
    put(dest.with_name(Path(d['log']).name + '.gz'), gzip.compress(raw, mtime=0))
    actual.append({'receipt': ref(dest), 'actual_exit_code': d['exit_code'], 'raw_log_sha256': sha(raw)})
put(E / 'actual-proof-successor-checks-manifest.json', dump({'actual_checks': actual, 'includes_retained_implementation_and_harness_failures': True}))
payload = [p for folder in [R / 'phase1', R / 'phase2', R / 'phase2-inputs'] for p in sorted(folder.rglob('*')) if p.is_file()]
for phase, frozen, expected in [('phase1', 'phase1-freeze.json', '763446abce7e48ec32330ff4a7ee1538187a8fe9d9a80e6f29fa82b7276b054d'),
                               ('phase2', 'FREEZE.json', 'dec575f0e6af490e52fdd8fc691336d7df39ce25cf7999cf8cffd434a6222baa')]:
    f = R / phase / frozen
    assert sha(f.read_bytes()) == expected
    for row in json.loads(f.read_bytes())['files']:
        p = Path(row['path'])
        assert sha(p.read_bytes()) == row['sha256'] and p.stat().st_size == row['bytes']
archive = E / 'independent-fresh-source-phase1-phase2.lossless.tar.gz'
assert not archive.exists()
with tarfile.open(archive, 'w:gz') as t:
    for p in payload:
        t.add(p, arcname=str(p), recursive=False)
with tarfile.open(archive, 'r:gz') as t:
    for p in payload:
        assert t.extractfile(str(p)).read() == p.read_bytes()
put(E / 'independent-fresh-source-phase1-phase2-manifest.json', dump({'archive': ref(archive), 'files': [ref(p) for p in payload],
    'truth_boundary': 'Source-only cognition then exact strict statement/reconstruction comparison; original parent full-context hash is retained history, with no proof/module/sourceV credit. Final v2 full-context packet awaits separate phase3 review.'}))
C = Path('research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-gaussian-moments.json')
cell = json.loads(C.read_bytes())
assert cell['status'] == 'proved_locally'
cell['evidence'].update({'focused_checks': [x['receipt']['path'] for x in checks],
    'local_proof_capsule': str(E / 'local-proof-capsule-v2.json'), 'publication_binding_sha256': a['publication_binding_sha256']})
cell['source_proof_coverage']['source_to_lean_map'] = ref(E / 'source-to-lean-map-v2.json')
C.write_bytes(dump(cell))
pub.check_advance([name], reviewed=False)
print(json.dumps({'state': 'PROVED_LOCAL_PROOF_SUCCESSOR_NOT_SOURCE_VERIFIED', 'producer': ref(prod), 'consumer': ref(test),
    'publication_binding_sha256': a['publication_binding_sha256'], 'full_reviewer_packet_canonical_sha256': full['packet_sha256'],
    'source_review_or_V_or_integration_credit': False}))
