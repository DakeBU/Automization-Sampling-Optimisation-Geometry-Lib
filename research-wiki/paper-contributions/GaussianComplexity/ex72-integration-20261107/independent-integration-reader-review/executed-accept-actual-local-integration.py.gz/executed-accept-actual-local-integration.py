"""Bind local integration acceptance to actual receipts and 14 viewed originals.

All 14 originals were independently viewed through view_image(detail=original)
before this script. It performs no build/browser, source verdict, lifecycle,
ledger, source, audit, frontier or shared-integration write.
"""
from pathlib import Path
import datetime
import gzip
import hashlib
import json
import struct
import subprocess
import sys

sys.dont_write_bytecode = True
ROOT = Path('/Users/zhouhuanjian/ASTIS-GC')
DIR = ROOT / 'research-wiki/paper-contributions/GaussianComplexity/ex72-integration-20261107'
OUT = DIR / 'independent-integration-reader-review'
ORIGINAL = ROOT / '.astis/huanjian-gc-ex72-integration-20261107/browser/live-20261107T070517399362Z'
CORE = 'eff84aa2f702efc804f84066b73b75f47d3d1e56'
DIGEST = '07faa921512467cb741b614687f132b18f1d8d952acb9807a7a56f7549eda529'
MATH = 'ebf76119351b23ef0718fc69aa5081515bab0b52'
ADV = 'ASTIS-SA-20261107-GaussianComplexityTVAmplification'
DECL = 'AutoSamplingTheory.ExampleCases.GaussianComplexity.TVAmplification.actual_averaged_tv_lower_bound'
REPORT = OUT / 'actual-local-integration-reader-acceptance.json'
assert not REPORT.exists()


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def checked(path, expected=None):
    raw = path.read_bytes()
    if expected:
        assert sha(raw) == expected, str(path)
    return raw, json.loads(raw)


def descriptor(path):
    return {'path': str(path.relative_to(ROOT)), 'sha256': sha(path.read_bytes())}


def receipt(stem, expected_log):
    path = DIR / 'actual-checks' / (stem + '.receipt.json')
    raw, data = checked(path)
    assert data['exit_code'] == 0 and data['head_before'] == data['head_after'] == CORE
    original_receipt = ROOT / '.astis/huanjian-resume-20261103' / path.name
    assert original_receipt.read_bytes() == raw
    compressed_path = path.with_name(stem + '.log.gz')
    compressed = compressed_path.read_bytes()
    log = gzip.decompress(compressed)
    assert sha(log) == data['log_sha256'] == expected_log
    assert Path(data['log']).read_bytes() == log
    return {'receipt': descriptor(path), 'lossless_log': descriptor(compressed_path),
            'raw_log_sha256': sha(log), 'exit_code': 0, 'elapsed_seconds': data['elapsed_seconds'],
            'command': data['command'], 'head_before': data['head_before'], 'head_after': data['head_after']}, log


assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT).decode().strip() == CORE
receipts = {}
for name, stem, expected in [
    ('root_gate', '20261107T065154058557Z-ex72-canonical-site-lean-gate', '5023edd55b21cca1053d6c9c430303179cbc3f123473d249fee5b81a89d7cf9d'),
    ('frontier', '20261107T065210617817Z-ex72-integrated-frontier', 'ef8d24e07b36c107f7241dd2f2dd3644203e451b507865e55b879bd621e9d26d'),
    ('publication', '20261107T065210617900Z-ex72-integrated-publication', '0149c6d7d8ef7429ac713512d1c5bb1d0035e4db28b019fe7cef2040de65910e'),
    ('contributor', '20261107T065210618003Z-ex72-integrated-contributor', '1578398b4938eeea1a84eda107192b11989e88406a422a70e882a6e3e9d435ee'),
    ('site_build', '20261107T065357440083Z-ex72-final-site-build', 'b6fad393e6c55eaf730719fc297553b2f56ea0c6efe2373bfac36cbfe9927c48'),
    ('graph_check', '20261107T065619086135Z-ex72-final-graph-check', 'f566327ffce84e85f36235e6c5296d3c3654a64e93453fe5d8b3be65778a8550'),
    ('site_check', '20261107T065619086155Z-ex72-final-site-check', '8591c193f7397254320d0665357f8681b816d1212bfc4aa5db5c4868509c9493'),
    ('Chrome', '20261107T070517263086Z-ex72-final-browser', '1b22b4be1db0f7167bf03b076a6576f5af0eab526ec522ba3380f35d9a33f750'),
]:
    receipts[name], log = receipt(stem, expected)
    if name == 'root_gate':
        assert b'Build completed successfully (9646 jobs).' in log and b'ASTIS check passed' in log
        assert b'ACTUAL COMPILED SOURCE PARENTS' in log and DECL.encode() in log
    elif name == 'site_check':
        assert b'12 chapters, 1112 modules, 5266 declarations, 77 reviewed teaching declarations' in log
    elif name == 'graph_check':
        graph_receipt = json.loads(log)
        assert graph_receipt['status'] == 'graph coverage checked'
        assert len(graph_receipt['contributions']) == 1
        assert graph_receipt['contributions'][0]['node'] == 'decl:' + DECL
        assert graph_receipt['contributions'][0]['omitted_connections'] == 0

certificate_raw, certificate = checked(DIR / 'actual-root-gate-at-core-commit.json', '0979d128c26f9d65accccb16b371f3b6a5228da52ea5d820313e6feb77d201f3')
assert certificate['passed'] and certificate['commit'] == CORE and certificate['source_digest'] == DIGEST
assert (ROOT / '.astis/site-lean-gate.json').read_bytes() == certificate_raw
metadata_raw, metadata = checked(ROOT / '_site/data/build-metadata.json', '2705932d9caa6ad459511b5af5bb9e35e858e5208e024f4f93cefa0bf990aa60')
assert (DIR / 'actual-final-site-build-metadata.json').read_bytes() == metadata_raw
assert metadata['git']['commit'] == CORE and not metadata['git']['commit_published'] and not metadata['git']['public_source_links']
assert metadata['gate']['passed'] and metadata['gate']['current']
assert metadata['source_digest'] == metadata['gate']['source_digest'] == DIGEST
browser_raw, browser = checked(DIR / 'final-browser/report.json', '9e9e19823ed27685a04cfa63f06c4489457efbbb59b264afcd67307bfba6480b')
assert (ORIGINAL / 'report.json').read_bytes() == browser_raw
assert browser['status'] == 'passed' and not browser['errors'] and browser['head'] == CORE
assert browser['browser_version'] == '156.0.8078.80'
assert browser['site_metadata'] == metadata and browser['site_metadata_sha256'] == sha(metadata_raw)
assert browser['actual_compiled_gate_commit'] == CORE and browser['actual_compiled_source_digest'] == DIGEST
assert not browser['external_GitHub_HTML_checked']
assert [p['width'] for p in browser['pages']] == [1440, 390]
assert [p['width'] for p in browser['graphs']] == [1440, 390]
assert len(browser['visible_source_index_clicks']) == 2 and all(p['actual_click'] for p in browser['visible_source_index_clicks'])
for p in browser['pages']:
    assert p['target'] == DECL and p['closed_initially'] and p['adjacent_exact_statement_and_proof']
    assert p['full_module_and_download_verified'] and p['immutable_git_object_source_bytes_verified'] and not p['page_overflow']
    assert p['immutable_source_link_commit_and_path_verified'] is None
    assert p['immutable_source_link_check'] == 'not_executed_own_site_route' and not p['external_GitHub_HTML_checked']
checker_path = DIR / 'final-browser/executed-checker.py'
checker = checker_path.read_bytes()
assert sha(checker) == '787a53d3c8c7d3b0abdeaae552d2d6129b9568f58828af9fe085b1be1a488c97'
assert checker == (ROOT / '.astis/huanjian-gc-ex72-integration-20261107/check_final_reader.py').read_bytes()
for literal in (b'assert steps.count() == 5', b'Actual amplified TV Ex72', b'measurable-event', b'explicit exponential lower bound',
                b'downloaded.body() ==', b'git_source == actual_source', b'page.locator(\'#complete-module-source pre > code\')',
                b'not an expected-cost lower bound without a separate reduction'):
    assert literal in checker, literal
reused = [
    'AutoSamplingTheory.ExampleCases.GaussianComplexity.AveragedBlockLaw.actual_averaged_block_product',
    'AutoSamplingTheory.ExampleCases.GaussianComplexity.AffinityTensorization.actual_affinity_tensorization',
    'AutoSamplingTheory.ExampleCases.GaussianComplexity.SingleBlockAffinity.single_block_affinity_bound',
    'AutoSamplingTheory.TechnicalLemmas.InformationTheory.DensityAffinity.normalized_density_tv_affinity',
]
for g in browser['graphs']:
    assert g['one_canonical_node'] and g['reference_and_source_edges_not_formal']
    assert g['canonical_reused_nodes_present_once'] == reused
    assert not any(e['evidence'] == 'formal' and e['relation'] in ('source reference (scanner)', 'source correspondence; not a Lean dependency') for e in g['edges'])
graph_raw, graph = checked(ROOT / '_site/data/underlying-lean-graph.json')
for name in [DECL] + reused:
    nodes = [n for n in graph['nodes'] if n['id'] == 'decl:' + name]
    assert len(nodes) == 1 and nodes[0]['status'] == 'compiled'
formal_ownership = [e for e in graph['edges'] if e['target'] == 'decl:' + DECL and e['relation'] == 'declares']
assert len(formal_ownership) == 1 and formal_ownership[0]['source'] == 'module:AutoSamplingTheory.ExampleCases.GaussianComplexity.TVAmplification'
for name in reused:
    assert len([e for e in graph['edges'] if e['source'] == 'decl:' + name and e['target'] == 'decl:' + DECL and e['relation'] == 'source reference (scanner)']) == 1
exposition_raw, exposition = checked(ROOT / '_site/data/declaration-exposition.json')
assert len([r for r in exposition if r['declaration'] == DECL]) == 1

proposal_raw, proposal = checked(OUT / 'preparation-report-v3.json', 'b593861ac8a24728055a2626c11eea0c85fbc613f5f9530cac3459087fe17e9b')
manifest_raw, manifest = checked(DIR / 'shared-integration-manifest.json')
assert len(manifest['paths']) == len(proposal['shared_paths']) == 7
assert manifest['reviewed_proposal_raw_sha256'] == sha(proposal_raw)
for planned, actual in zip(proposal['shared_paths'], manifest['paths']):
    assert planned['path'] == actual['path'] and planned['before_sha256'] == actual['before_sha256']
    assert planned['planned_after_sha256'] == actual['after_sha256']
    path = ROOT / actual['path']
    raw = path.read_bytes()
    assert sha(raw) == actual['after_sha256']
    assert subprocess.check_output(['git', 'show', CORE + ':' + actual['path']], cwd=ROOT) == raw
    assert gzip.decompress((ROOT / planned['planned_after_archive']['path']).read_bytes()) == raw
    if planned['before_exists']:
        assert subprocess.check_output(['git', 'show', manifest['base_commit'] + ':' + actual['path']], cwd=ROOT) == gzip.decompress((ROOT / planned['before_archive']['path']).read_bytes())
for path, expected in proposal['source_test_publication_lesson_pins'].items():
    raw = (ROOT / path).read_bytes()
    assert sha(raw) == expected
    assert subprocess.check_output(['git', 'show', MATH + ':' + path], cwd=ROOT) == raw
audit_path = ROOT / 'research-wiki/semantic-roundtrip/audits/huanjian-tv-amplification.json'
audit_raw, audit = checked(audit_path, '67b1c0484faf78ca170cc65a407bac46d26b40a316daf3cb19edc1cefb6933ab')
assert audit['source_review']['reviewer'] == '/root/ex72_fresh_source_v2' and audit['source_review']['state'] == 'accepted'
sys.path.insert(0, str(ROOT / 'tools'))
import astis_site
import astis_advance as advance
import astis_publication as publication
assert astis_site.source_digest() == DIGEST
item = next(i for i in publication.load() if i['id'] == 'huanjian-tv-amplification')
assert publication.binding_digest(item, item['bindings'][0]) == proposal['publication_binding_sha256']
cell_path = ROOT / 'research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-tv-amplification.json'
assert sha(cell_path.read_bytes()) == '4f8ea3fda67573054297f3b66b41673768090ed3a0d7b76b677b59136cf4fc5a'
ledger_raw = (ROOT / 'runs/substantive_advances.jsonl').read_bytes()
claim_raw, claim = checked(DIR / 'normal-stab-claim.json')
assert sha(ledger_raw) == claim['after_sha256'] == 'a47b939e2ad017a9fc5b9ed102455bd996bb9096ec0c7d85bb55d5713cb2dfec'
claim_prefix = gzip.decompress((DIR / 'normal-stab-claim-ledger-prefix.jsonl.gz').read_bytes())
assert ledger_raw.startswith(claim_prefix) and sha(claim_prefix) == claim['before_sha256']
claim_append = ledger_raw[len(claim_prefix):]
assert sha(claim_append) == claim['append_sha256'] == '635a5c338cf6d162915fb1e29c70b442975e614c3df0b4c5ef5325a065d9dc85'
assert len(claim_append.splitlines()) == 1
states = advance._replay_advances(json.loads(r) for r in ledger_raw.splitlines())
assert [k for k, v in states.items() if v['state'] == 'STABILIZING'] == [ADV]
assert states[ADV]['owner_id'] == 'huanjian_gc_20261107_ex72'
assert states[ADV]['last_actor'] == 'huanjian_gc_20261107_ex72_integration'
protection_raw, protection = checked(OUT / 'final-local-reader-protection-readback.json', 'd96eb8ff327a057f6908b32e0c50c22a6c3734cdc9623b005e2a9a0f1505a824')
assert protection['status'] == 'passed' and protection['own_state'] == 'STABILIZING'
assert all(p['state'] == 'planned-after' for p in protection['checks']['shared_paths'])

# These observations are from the actual original-resolution tool views, not
# inferred from filenames, image sizes or the automated browser pass.
notes = {
    'actual-1440-first.png': 'The actual-TV exponential formula is fully rendered and legible; adjacent exact Lean statement, assumptions and mathematical proof steps start folded.',
    'actual-1440-proof.png': 'Five readable mathematical proof-step folds precede the open Lean-proof introduction. Complete code is below the viewport and is established by exact DOM/source checks, not claimed visible here.',
    'actual-1440-module.png': 'Complete-module view shows imports, scope, namespace, source header and theorem binders; copy and module-download controls are visible.',
    'case-boundary-1440.png': 'Theorem3.1 remains red/open with not-formalized Lean statement. Actual target, exact oracle and deterministic every-input/every-seed cap are visible.',
    'source-index-1440.png': 'New inline-LaTeX domain, TV lower bound, k=floor(d/n) and explicit log2 threshold render clearly. Oracle/cap/cost and main-bound caveats remain; reviewed items are building blocks, not completed paper results.',
    'actual-1440-source-index-open.png': 'One expanded Ex72 reviewed-work item exposes its readable full-statement/proof link; neighboring items remain folded.',
    'actual-1440-graph.png': 'The focused TV node and four canonical reused declarations are legible; solid owning-module structure and dashed source/reference/fidelity overlays remain distinct. Pan/Fit guidance is visible.',
    'actual-390-first.png': 'Statement and folded Lean label wrap in one column. The long formula uses its own horizontal viewport with an explicit scroll instruction; no whole-page overflow is observed.',
    'actual-390-proof.png': 'Mathematical-step and open Lean-proof labels wrap cleanly; the introduction stays within the column. This viewport does not claim to display the complete proof source.',
    'actual-390-module.png': 'The module label, copy and download are readable. Long source lines remain in the code container horizontal viewport, retaining exact source text.',
    'case-boundary-390.png': 'Main-source statement and actual target/oracle assumptions wrap clearly; deterministic every-input/every-seed query cap remains readable.',
    'source-index-390.png': 'Worst-case deterministic cap versus expected-cost caveat and building-blocks-not-completed-results boundary are readable; navigation folds stay in-column.',
    'actual-390-source-index-open.png': 'Expanded Ex72 title and full-statement/proof link are readable without overlapping text; neighboring index folds stay distinct.',
    'actual-390-graph.png': 'TV and all four reused declaration boxes fit their labels. The wider graph stays in the intended draggable canvas with visible drag/Fit guidance; surrounding nodes extend inside that canvas, not the page.',
}
assert set(notes) == {r['file'] for r in browser['screenshots']} and len(notes) == 14
images = []
for row in browser['screenshots']:
    original_path = ORIGINAL / row['file']
    archive_path = DIR / 'final-browser' / row['file']
    raw = original_path.read_bytes()
    assert raw == archive_path.read_bytes() and sha(raw) == row['sha256']
    assert raw[:8] == b'\x89PNG\r\n\x1a\n'
    width, height = struct.unpack('>II', raw[16:24])
    assert (width, height) in [(1440, 1000), (390, 844)]
    images.append({'original_path': str(original_path.relative_to(ROOT)), 'byte_identical_archive': str(archive_path.relative_to(ROOT)),
                   'sha256': sha(raw), 'width': width, 'height': height,
                   'independently_viewed': True, 'view_tool': 'view_image(detail=original)', 'observation': notes[row['file']]})
source_phase = ROOT / 'research-wiki/paper-contributions/GaussianComplexity/tv-amplification-semantic-evidence/fresh-source-v2/phase3'
source_manifest_raw, source_manifest = checked(source_phase / 'manifest.json', '29ac9b98a1736b6c2ba2d08becd30ab3048666a833b6e2d9ea24ca7d49a9a352')
for filename, desc in source_manifest['files'].items():
    assert sha((source_phase / filename).read_bytes()) == desc['sha256'], filename
foreign_frontiers = json.loads(gzip.decompress((source_phase / 'foreign-frontier-files.json.gz').read_bytes()))
assert len(foreign_frontiers) == 437
for path, expected in foreign_frontiers.items():
    assert sha((ROOT / path).read_bytes()) == expected, path

report = {
    'reviewer': '/root/ex72_integration_reader_review', 'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'decision': 'accepted for local integration and reader delivery at the exact named core',
    'core_commit': CORE, 'immutable_mathematical_candidate': MATH, 'actual_compiled_source_digest': DIGEST,
    'source_verdict_originated': False, 'source_V_is_separate_existing_fact': True,
    'actual_gate_certificate': descriptor(DIR / 'actual-root-gate-at-core-commit.json'),
    'actual_site_metadata': descriptor(DIR / 'actual-final-site-build-metadata.json'),
    'actual_core_bound_receipts': receipts,
    'reviewed_proposal': descriptor(OUT / 'preparation-report-v3.json'),
    'actual_seven_path_manifest': descriptor(DIR / 'shared-integration-manifest.json'),
    'all_seven_planned_after_bytes_match_current_and_immutable_core': True,
    'production_test_lesson_publication_match_immutable_math_candidate': True,
    'canonical_audit_unchanged': descriptor(audit_path),
    'browser_report': descriptor(DIR / 'final-browser/report.json'), 'executed_checker': descriptor(checker_path),
    'actual_viewports': [[1440, 1000], [390, 844]], 'all_14_originals_independently_viewed': images,
    'rendered_formula_and_new_reader_boundary': 'accepted; source/main-bound/cap/cost distinctions retained',
    'exact_lean_acceptance': 'Successful actual checker verifies adjacent initially folded statement/proof, five mathematical proof steps, complete module, own-site download and immutable local Git-object source bytes. PNGs are bounded viewports, not complete code dumps.',
    'source_index_navigation': 'Two real visible clicks, desktop and mobile, reach the focused exact reader.',
    'graph_acceptance': {'one_canonical_TV_node': True, 'four_canonical_reused_nodes': reused,
                         'formal_module_structure_and_dashed_reference_source_overlays_distinct': True,
                         'generated_graph_sha256': sha(graph_raw), 'declaration_exposition_sha256': sha(exposition_raw),
                         'graph_checks_are_not_mathematical_dependency_certificates': True},
    'protection': descriptor(OUT / 'final-local-reader-protection-readback.json'),
    'ledger_exactly_preserved_during_review_sha256': sha(ledger_raw),
    'all_278_foreign_projected_states_and_437_foreign_frontiers_preserved': True,
    'old_protected_source_content_tracked_objects_and_source_phase_manifest_preserved': True,
    'source_only_graph_statuses_and_external_Poisson_citation_boundary_preserved': True,
    'single_stabilization_lane_at_acceptance': [ADV], 'proof_owner_retained': states[ADV]['owner_id'],
    'normal_lifecycle_events_created_by_this_review': 0, 'parking_performed': False,
    'build_browser_or_source_review_reruns': [],
    'external_GitHub_HTML_checked': False,
    'external_source_link_check': 'null/not_executed_own_site_route; no external HTTP200 or public-source visibility inferred',
    'source_verifier_file_URL_block': 'Preserved separately. Its static content scope is not relabelled live acceptance. This review uses the separately authorized actual canonical-site HTTP Chrome receipt.',
    'remaining_boundary': 'Remote publication/current remote CI/merge/live-public delivery, postmerge purification/Exposition Seal, both main lower bounds and oracle/transcript/TV-precision/deterministic-cap/expected-cost/hidden-eigenbasis adapters, full Goal completion remain separate and open.',
    'writes_stop_after_acceptance_report': True,
}
assert (ROOT / 'runs/substantive_advances.jsonl').read_bytes() == ledger_raw
assert audit_path.read_bytes() == audit_raw and cell_path.read_bytes() == subprocess.check_output(['git', 'show', CORE + ':' + str(cell_path.relative_to(ROOT))], cwd=ROOT)
REPORT.write_bytes((json.dumps(report, ensure_ascii=False, indent=2) + '\n').encode())
script_archive = OUT / 'executed-accept-actual-local-integration.py.gz'
assert not script_archive.exists()
script_archive.write_bytes(gzip.compress(Path(__file__).read_bytes(), compresslevel=9, mtime=0))
assert gzip.decompress(script_archive.read_bytes()) == Path(__file__).read_bytes()
print(json.dumps({'decision': report['decision'], 'core': CORE, 'report_sha256': sha(REPORT.read_bytes()),
                  'original_images_viewed': len(images), 'new_source_verdicts': 0, 'new_normal_lifecycle_events': 0,
                  'parking_performed': False, 'writes_stopped': True}, indent=2))
