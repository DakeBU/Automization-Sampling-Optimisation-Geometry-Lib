import datetime, hashlib, json, pathlib, stat

D=pathlib.Path(__file__).resolve().parent
def sha(b):return hashlib.sha256(b).hexdigest()
def put(rel,b):
    p=D/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b if isinstance(b,bytes) else b.encode());return p
def js(rel,obj):return put(rel,json.dumps(obj,ensure_ascii=False,indent=2)+'\n')

failed='failed-attempts/js-path-discovery/'
put(failed+'command.txt',"sed -n '1010,1125p' inputs/tools/astis_site.py && rg -n 'data-lean-copy|data-lean-code-panel|lean-copy|closest|code-block' website/static/lean-source-actions.js website/static/inline-lean.js website/static/reader-code-tools.js\n")
put(failed+'stdout.raw.txt',b''.join((D/'inputs/tools/astis_site.py').read_bytes().splitlines(keepends=True)[1009:1125]))
put(failed+'stderr.raw.txt','rg: website/static/lean-source-actions.js: No such file or directory (os error 2)\nrg: website/static/inline-lean.js: No such file or directory (os error 2)\nrg: website/static/reader-code-tools.js: No such file or directory (os error 2)\n')
js(failed+'receipt.json',{'exit_code':2,'cause':'Guessed candidate JavaScript filenames did not exist; no JavaScript file body was read.',
 'repair':'No further filename guessing or browser claim. Static DOM directly establishes absence of all six copy buttons and code-panel attributes.',
 'scope':'No renderer implementation, no shared mutation; original frozen review untouched.'})
records=json.loads((D/'static-fold-comparison.json').read_bytes())
findings={
 'schema':'astis-disabled-renderer-prospective-ui-scope-review/v1',
 'candidate':'72e5d1405284f729f4eb600c5ae5dd556365b7e2',
 'reviewer':'disabled-v3-scope-review-0a91de',
 'proposal_sha256':'64b8768e27da03eebb93d0a5ef77a2b47481bb1f50d4a90fae32b92c94d2e05a',
 'production_renderer_sha256':'b22394faeb8de07109826174d05856f4a561b20f9301e1f1d031b466fd6f2596',
 'current_C5_lesson_sha256':sha((D/'inputs/website/content/declaration_lessons/huanjian-fixed-spectrum-cosine-gram.json').read_bytes()),
 'decision':'PARTIAL UI-ONLY PROPOSAL; original all-six-fold reader HOLD remains unchanged',
 'what_v3_addresses':[
   'Only current step6 is a byte-equal whole cited local Lean file. Its inner code fold gains Exact source context to the private Tests sourceHTML #L13 and Download exact Lean source to the byte-identical 7494B Tests file.',
   'export_sources now writes the exact cited .lean bytes and adds a sibling raw-file download link on the sourceHTML page. Static sourceHTML has the complete exact Tests text, and #L13 begins the actual private theorem.',
   'All six authored code blocks, formulas and initially closed disclosure states stay exact under the proposal.'
 ],
 'what_v3_leaves':[
   'Steps1-5 get no adjacent exact source-context or download links, because they are snippets rather than complete-file byte matches.',
   'All six step code folds still have no data-lean-copy button and no data-lean-code-panel binding attribute; no per-step copy control is supplied.',
   'Existing public standalone statement/proof controls are unchanged and do not supply controls inside the six distinct step folds.',
   'Private step5 is a Tests fragment (lines59-82), not public producer source. A blanket fallback to the unit public declaration would point this step at the wrong module.',
   'Global sourceHTML shell, whole-site links/assets, browser/clipboard/MathJax/desktop/mobile delivery, shared adoption and global acceptance remain untested/unreleased.'
 ],
 'exact_step_contexts':[
   {'step':row['step'],'exact_matches':row['exact_known_file_matches']} for row in records['proposal']
 ],
 'required_minimal_concrete_repair_boundary':[
   'Supply an adjacent copy control with the existing copy-panel binding on each of the six code folds, so it copies exactly that displayed step. Step6 should copy all7494B; step5 should copy only its displayed Tests fragment.',
   'Supply adjacent exact context and whole-module download controls for steps1-4 using known production P, and step5 using cited Tests T. Keep v3 step6 context/download tied to T. Reuse canonical owning-file/cited-source identities and exact byte locators; do not route every step to the public theorem or discover a new private mathematical node.',
   'Require the chosen context/download targets to exist in the generated output and preserve exact source bytes. For this lesson the required context routing is P lines34-53/54-124/125-155/156-166, then T lines59-82 and full T with private theorem atL13. Preserve the sourceHTML raw Tests download introduced by v3.',
   'After an owner-authorized repair, rerun the six-fold static exactness/routing/copy-panel and raw-download checks, then obtain actual browser clipboard/MathJax/desktop/mobile evidence separately. A partial static repair cannot release the original whole reader HOLD.'
 ],
 'controls':'Exact full file qualifies; missing/added LF, partial private/public snippets and absent local citation do not qualify. All controls passed.',
 'fixture_limit':'Exact production/proposal functions used with only bounded candidate inputs, unpublished Git fixture and false gate. For sourceHTML export only, source_lineage.canonical_shell was identity to avoid invoking unrelated global overlays; actual export_sources and base.page generated the page. No browser or global sourceHTML acceptance.',
 'preservation':'Original independent-native-reader-0a91de frozen directory was never imported or written; all follow-up writes are under this new sibling directory. Its mathematical/native/static findings and HOLD remain unchanged.',
 'no_adoption_or_credit':'No shared renderer or metadata changes, new renderer implementation, sourceV, mathematical verdict change, native build credit, browser acceptance or global acceptance.'
}
js('findings.json',findings)
put('findings.txt',
 'Disabled v3 is a partial UI-only proposal. Original all-six-fold reader HOLD stays unchanged.\n'
 'It adds context+exact download for step6 full7494B Tests, and exact raw download from its sourceHTML page.\n'
 'It leaves steps1-5 without context/download; all six still lack copy controls/code-panel bindings.\n'
 'Steps1-4 are public P snippets; step5 is private T lines59-82; step6 is full T with theorem atL13.\n'
 'Required repair: exact per-step copy binding for6/6 and correct P/P/P/P/T/T context-download routing, exact targets/bytes, then separate owner-authorized browser and global acceptance.\n'
 'No shared adoption, mathematics/sourceV/native build credit or browser/global acceptance.\n')
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
js('freeze-invocation.json',{'command':['python3',str(D/'finalize.py')],'started_at_utc':now,
  'scope':'All follow-up files without truncation, including exact inputs, comparison output, sourceHTML/raw download fixtures and failed path-discovery attempt. Two explicit envelope files excluded only to avoid recursive hashes.'})
envelope={'freeze-manifest.json','freeze-outer-receipt.json'}
allpaths=sorted(D.rglob('*'));assert not any(p.is_symlink() for p in allpaths)
files=[p for p in allpaths if p.is_file() and p.relative_to(D).as_posix() not in envelope]
dirs=[D]+[p for p in allpaths if p.is_dir()]
manifest={'schema':'astis-full-followup-payload-freeze/v1','scope':'Every follow-up descendant; only two explicit envelope files outside payload hash list.',
 'explicit_envelopes':sorted(envelope),
 'files':[{'path':p.relative_to(D).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes()),'mode':'0444'} for p in files],
 'directories':[{'path':'.' if p==D else p.relative_to(D).as_posix(),'mode':'0555'} for p in dirs]}
mf=js('freeze-manifest.json',manifest)
receipt={'schema':'astis-followup-freeze-outer-receipt/v1','created_at_utc':now,'manifest_sha256':sha(mf.read_bytes()),
 'findings_sha256':sha((D/'findings.json').read_bytes()),'payload_files':len(files),'payload_bytes':sum(p.stat().st_size for p in files),'directories':len(dirs),
 'file_mode':'0444','directory_mode':'0555','decision':'PARTIAL; original HOLD unchanged','original_freeze':'untouched'}
outer=js('freeze-outer-receipt.json',receipt)
for p in files+[mf,outer]:p.chmod(0o444)
for p in sorted(dirs,key=lambda p:len(p.parts),reverse=True):p.chmod(0o555)
for row in manifest['files']:
 p=D/row['path'];assert sha(p.read_bytes())==row['sha256'] and stat.S_IMODE(p.stat().st_mode)==0o444
for p in dirs:assert stat.S_IMODE(p.stat().st_mode)==0o555
assert sha(mf.read_bytes())==receipt['manifest_sha256']
print(json.dumps({**receipt,'outer_receipt_sha256':sha(outer.read_bytes()),'frozen':True},indent=2))
