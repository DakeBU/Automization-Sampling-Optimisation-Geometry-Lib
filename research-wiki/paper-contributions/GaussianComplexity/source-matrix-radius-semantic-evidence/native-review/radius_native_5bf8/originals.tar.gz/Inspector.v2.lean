import Tests.GaussianComplexityFixedSpectrumSourceMatrixRadius
import Lean
import Lean.Util.CollectAxioms
import Lean.Util.FoldConsts

open Lean Meta Elab Command
open MeasureTheory ProbabilityTheory
open scoped BigOperators Matrix Kronecker Matrix.Norms.L2Operator
set_option autoImplicit false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

namespace RadiusNative5bf8
def destination : System.FilePath := "/Users/zhouhuanjian/ASTIS-GC/.astis/semantic-neutral-20261113/radius_native_5bf8/inspection"
def jname (n : Name) : Json := Json.mkObj [("display", toJson n.toString), ("exact", toJson (reprStr n))]
def kind : ConstantInfo → String
  | .axiomInfo _ => "axiom" | .defnInfo _ => "definition" | .thmInfo _ => "theorem"
  | .opaqueInfo _ => "opaque" | .quotInfo _ => "quotient" | .inductInfo _ => "inductive"
  | .ctorInfo _ => "constructor" | .recInfo _ => "recursor"
def jhints : ReducibilityHints → Json
  | .opaque => toJson "opaque"
  | .abbrev => toJson "abbrev"
  | .regular h => Json.mkObj [("regular",toJson h)]
def owner (env : Environment) (n : Name) : Name :=
  match env.getModuleIdxFor? n with
  | some i => env.header.moduleNames[i.toNat]!
  | none => env.mainModule
def isProject (env : Environment) (n : Name) : Bool :=
  let m := (owner env n).toString
  m.startsWith "AutoSamplingTheory." || m.startsWith "Tests."

structure Dag where
  ids : Std.HashMap Expr Nat := {}
  stream : IO.FS.Handle

partial def encode (e : Expr) : StateT Dag IO Nat := do
  if let some id := (← get).ids[e]? then return id
  let payload ← match e with
    | .bvar i => pure <| Json.mkObj [("ctor",toJson "bvar"),("index",toJson i)]
    | .fvar i => pure <| Json.mkObj [("ctor",toJson "fvar"),("id",jname i.name)]
    | .mvar i => pure <| Json.mkObj [("ctor",toJson "mvar"),("id",jname i.name)]
    | .sort u => pure <| Json.mkObj [("ctor",toJson "sort"),("level",toJson (reprStr u))]
    | .const n us => pure <| Json.mkObj [("ctor",toJson "const"),("name",jname n),("levels",toJson (us.map reprStr))]
    | .app f a => do
      let fi ← encode f; let ai ← encode a
      pure <| Json.mkObj [("ctor",toJson "app"),("function",toJson fi),("argument",toJson ai)]
    | .lam n t b bi => do
      let ti ← encode t; let bi' ← encode b
      pure <| Json.mkObj [("ctor",toJson "lam"),("name",jname n),("domain",toJson ti),("body",toJson bi'),("binderInfo",toJson (reprStr bi))]
    | .forallE n t b bi => do
      let ti ← encode t; let bi' ← encode b
      pure <| Json.mkObj [("ctor",toJson "forall"),("name",jname n),("domain",toJson ti),("body",toJson bi'),("binderInfo",toJson (reprStr bi))]
    | .letE n t v b nondep => do
      let ti ← encode t; let vi ← encode v; let bi ← encode b
      pure <| Json.mkObj [("ctor",toJson "let"),("name",jname n),("type",toJson ti),("value",toJson vi),("body",toJson bi),("nondep",toJson nondep)]
    | .lit l => pure <| Json.mkObj [("ctor",toJson "literal"),("value",toJson (reprStr l))]
    | .mdata d b => do
      let bi ← encode b
      pure <| Json.mkObj [("ctor",toJson "metadata"),("metadata",toJson (reprStr d)),("body",toJson bi)]
    | .proj n i b => do
      let bi ← encode b
      pure <| Json.mkObj [("ctor",toJson "projection"),("name",jname n),("index",toJson i),("body",toJson bi)]
  let id := (← get).ids.size
  modify fun s => {s with ids := s.ids.insert e id}
  (← get).stream.putStrLn <| (Json.mkObj [("id",toJson id),("node",payload)]).compress
  return id

def checkValue (env : Environment) (ci : ConstantInfo) : MetaM String := do
  if let some v := ci.value? true then
    if ci.type.hasFVar || ci.type.hasMVar || ci.type.hasLooseBVars || v.hasFVar || v.hasMVar || v.hasLooseBVars then
      throwError "open expression in {ci.name}"
    let n := Name.str `RadiusNativeKernelClone ci.name.toString
    let d : Declaration := match ci with
      | .thmInfo x => .thmDecl {x with name := n}
      | .defnInfo x => .defnDecl {x with name := n}
      | .opaqueInfo x => .opaqueDecl {x with name := n}
      | _ => panic! "unexpected declaration with value"
    match env.addDeclCore 0 100000 d none true with
    | .ok _ => return "actual-type-and-value-kernel-addDeclCore-doCheck-true-PASS"
    | .error e => throwError "kernel rejection {ci.name}: {e.toMessageData (← getOptions)}"
  else
    throwError "project declaration without value: {ci.name}"

run_meta do
  let env ← getEnv
  IO.FS.createDirAll destination
  let owned := env.constants.toList.filter fun (n,_) => isProject env n
  let owned := owned.mergeSort (fun a b => Name.quickLt a.1 b.1)
  let dag ← IO.FS.Handle.mk (destination / "expressions.ndjson") .write
  let decls ← IO.FS.Handle.mk (destination / "declarations.ndjson") .write
  let mut state : Dag := {stream := dag}
  for (n,ci) in owned do
    let checked ← checkValue env ci
    let (ty,s) ← (encode ci.type).run state; state := s
    let (v,s) ← (encode (ci.value! true)).run state; state := s
    let axioms ← collectAxioms n
    for a in axioms do
      unless a == ``propext || a == ``Classical.choice || a == ``Quot.sound do
        throwError "nonstandard axiom {a} in {n}"
    let row := Json.mkObj [
      ("name",jname n),("owner",jname (owner env n)),("kind",toJson (kind ci)),
      ("levelParams",Json.arr (ci.levelParams.toArray.map jname)),
      ("typeRoot",toJson ty),("valueRoot",toJson v),
      ("typeConstants",Json.arr (ci.type.getUsedConstants.map jname)),
      ("valueConstants",Json.arr ((ci.value! true).getUsedConstants.map jname)),
      ("axioms",Json.arr (axioms.map jname)),("unsafe",toJson ci.isUnsafe),
      ("partial",toJson ci.isPartial),("reducibilityHints",jhints ci.hints),
      ("typeHasFVar",toJson ci.type.hasFVar),("typeHasMVar",toJson ci.type.hasMVar),
      ("typeHasLooseBVars",toJson ci.type.hasLooseBVars),
      ("valueHasFVar",toJson (ci.value! true).hasFVar),("valueHasMVar",toJson (ci.value! true).hasMVar),
      ("valueHasLooseBVars",toJson (ci.value! true).hasLooseBVars),("kernelCheck",toJson checked)]
    decls.putStrLn row.compress
    IO.println s!"checked {n} ({kind ci})"
  dag.flush; decls.flush
  IO.FS.writeFile (destination / "summary.json") <| (Json.mkObj [
    ("declarations",toJson owned.length),("uniqueExprNodes",toJson state.ids.size),
    ("importedModules",Json.arr (env.header.moduleNames.map jname))]).pretty
end RadiusNative5bf8
