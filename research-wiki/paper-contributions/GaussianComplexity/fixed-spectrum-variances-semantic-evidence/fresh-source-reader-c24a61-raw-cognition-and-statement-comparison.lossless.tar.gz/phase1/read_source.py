from pathlib import Path
import sys, hashlib, json, re, html
from html.parser import HTMLParser

HERE = Path(__file__).resolve().parent
SOURCE = HERE / 'pinned_source.html'
assert hashlib.sha256(SOURCE.read_bytes()).hexdigest() == '6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
start, end, label = int(sys.argv[1]), int(sys.argv[2]), sys.argv[3]
lines = SOURCE.read_text().splitlines(keepends=True)
raw = ''.join(lines[start-1:end])
class Reader(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.math_depth=0
        self.rows={}
    def add(self, line, text):
        self.rows.setdefault(line+start-1,[]).append(text)
    def handle_starttag(self, tag, attrs):
        if tag == 'math':
            if not self.math_depth:
                self.add(self.getpos()[0], ' $'+dict(attrs).get('alttext','[NO ALTTEXT]')+'$ ')
            self.math_depth+=1
    def handle_endtag(self, tag):
        if tag == 'math': self.math_depth-=1
    def handle_data(self, data):
        if self.math_depth: return
        line=self.getpos()[0]
        for offset,text in enumerate(data.split('\n')):
            self.add(line+offset,text)
r=Reader();r.feed(raw)
projection='\n'.join(f'{i}: {t}' for i in sorted(r.rows) if (t:=re.sub(r'\s+',' ',' '.join(r.rows[i])).strip()))+'\n'
raw_path = HERE / f'{label}.raw.html'
read_path = HERE / f'{label}.read.txt'
assert not raw_path.exists() and not read_path.exists(), 'Read artifact already exists'
raw_path.write_text(raw)
read_path.write_text(projection)
record = {'operation':'read-pinned-source-lines','argv':sys.argv,'reader_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'source':'pinned_source.html','line_start':start,'line_end':end,'raw_artifact':raw_path.name,'raw_sha256':hashlib.sha256(raw.encode()).hexdigest(),'projection_artifact':read_path.name,'projection_sha256':hashlib.sha256(projection.encode()).hexdigest(),'ids':re.findall(r'\bid="([^"]+)"',raw)}
with (HERE/'raw_read_log.jsonl').open('a') as f: f.write(json.dumps(record)+'\n')
print(projection)
