# Independent upstream raw reading before SG graph exposure

The fixed external source read in this phase is
`.lake/packages/mathlib/Mathlib/Analysis/Convex/Integral.lean`: 21375 bytes,
344 lines, SHA-256
`1b3115887fabf0dccc2fed689d1f1ddc7a114b5de4594e752c02908a445aafb4`.
Its header attributes the file to Yury Kudryashov under Apache-2.0. The Mathlib
pin db584cd6d46c92f209a44c0f1c829460d327499d is the fixed packet's dependency
context; this actor has not queried Git to establish a checkout state.
All 344 lines were read before any new SG directory inventory or graph was
opened. This is an authorized external primary-source/proof reading, not a
new ASTIS target implementation or a root old proof/API search.

The relevant printed theorem is Convex.integral_mem at lines 57-58, under the
ambient variables at 46-47. E is a complete real normed vector space, mu is a
probability measure, s is convex and closed, f is integrable, and f belongs to
s almost everywhere. The conclusion is actual integral membership in s.
There is no Matrix/PosSemidef-specialized theorem printed here, no positive
dimension premise, no separate Nonempty s assumption, and no separate public
SeparableSpace/BorelSpace E assumption in that signature.

The printed proof internally chooses the Borel structure and an a.e.-equal
strongly measurable representative g; obtains a separable range intersected
with s and a point in that intersection from the AE facts under the probability
law; transfers integral/integrability by AE equality; constructs SimpleFunc
approximants whose values lie in s; proves convergence of their integrals;
uses convex finite sums with nonnegative weights summing to one; and finally
uses closedness to retain membership in the limit. Probability normalization,
constant integrability, witness/representative selection and approximation
facts belong to that upstream proof, rather than additional assumptions on
the authored matrix theorem.

Specializing s to the full real PSD matrix predicate is an ASTIS-authored
background application. The exact predicate includes Hermitian equality and
all finite quadratic-form inequalities. Its semantics, closedness and
convexity in the actual L2Operator topology, finite matrix completeness, and
AE-membership/integrability matching are still internal obligations. The
paper p14 supplies application calculations, not this generic theorem or
proof. Its actual Gaussian residual/square functions must independently meet
the generic hf/hpos contracts without changing the R9 signature.

Empty finite matrix indices remain permitted. The upstream E assumptions do
not impose positive dimension or Nonempty matrix indices. Its internal
range-intersection witness comes from AE membership and the probability law,
not a dimension premise. Any concrete PSD-cone zero/nonempty fact and any
empty-case handling remain internal specialization work.

The rest of the file provides average/restricted-average, convex-function
Jensen, strict/interior and norm strictness variants. They were read to fix
the source boundary. Their nonzero-restriction, extra function-integrability,
continuity or strict-convexity assumptions are not new hypotheses of the
frozen matrix background theorem. No implementation or exact API application
to the matrix cone has been tested or proved in this reading.

This raw-source understanding is frozen before SG exposure. It is not a
source-graph extraction/admission, a mathematical proof, a compiled dependency
or a permission grant. Later graph review must distinguish the printed
upstream theorem/proof, the authored PSD specialization, and p14's actual
Gaussian application.
