"""Standalone offline validation of the selected normal-verifier package."""
from pathlib import Path
import hashlib, io, json, tarfile
ROOT = Path(__file__).resolve().parent
sha = lambda b:hashlib.sha256(b).hexdigest()
read = lambda p:json.loads(Path(p).read_bytes())
manifest_raw = (ROOT/'payload-manifest.json').read_bytes()
manifest = json.loads(manifest_raw); seal = read(ROOT/'manifest-seal.json')
assert sha(manifest_raw) == seal['payload_manifest_sha256']
assert len(manifest['files']) == seal['payload_file_count']
assert len({x['path'] for x in manifest['files']}) == len(manifest['files'])
forbidden_keys = {'all_foreign_states','all_existing_tracked_fingerprints','actual_control_fingerprints',
                  'tracked_git_index','advance_states','discovery_states','index_exact'}
def no_private_maps(obj):
    if isinstance(obj,dict):
        assert not (set(obj)&forbidden_keys), 'private preservation map in portable JSON'
        for value in obj.values(): no_private_maps(value)
    elif isinstance(obj,list):
        for value in obj: no_private_maps(value)
def safe_name(name):
    p = Path(name)
    assert not p.is_absolute() and '..' not in p.parts
    assert not any('.private.' in part or part.startswith('.PRIVATE') for part in p.parts)
def inspect(name,raw):
    safe_name(name)
    if name.endswith('.json'): no_private_maps(json.loads(raw))
    if name.endswith('.tar.gz'):
        with tarfile.open(fileobj=io.BytesIO(raw),mode='r:gz') as tf:
            members=tf.getmembers(); names=[m.name for m in members]
            assert len(names)==len(set(names)) and all(m.isfile() for m in members)
            for member in members: inspect(member.name,tf.extractfile(member).read())
for item in manifest['files']:
    safe_name(item['path']); raw=(ROOT/item['path']).read_bytes()
    assert len(raw)==item['bytes'] and sha(raw)==item['sha256']
    inspect(item['path'],raw)
v = ROOT/'verifier-originals'
original = read(ROOT/'historical-originals/PROVED_LOCAL-evidence.full.json')
payload = read(v/'VERIFIED-evidence.full.json')
cell = read(v/'candidate-cell.exact.json')
event = json.loads((v/'actual-VERIFIED-append.exact.jsonl').read_bytes())
outcome = read(v/'normal-VERIFIED-outcome.bounded.json')
assert len(original)==26 and all(payload[k]==value for k,value in original.items())
assert cell['evidence']['independent_verification_details']==payload and event['evidence']==payload
assert isinstance(cell['evidence']['independent_verification'],str) and cell['evidence']['independent_verification']
assert payload['verified_commit']==manifest['held_commit']
assert event['worker_id']==payload['verifier_id']=='gram_final_verifier_91dc'
assert cell['owner_id']=='huanjian_gc_20261113_source_gram_realization'
assert outcome['normal_API_calls']==1 and outcome['actual_VERIFIED_transitions']==1
assert outcome['integration_publication_purification_whole_Goal']=='HOLD'
assert sha((v/'actual-VERIFIED-append.exact.jsonl').read_bytes())==outcome['actual_VERIFIED_append_sha256']
print(json.dumps({'status':'PASS','payload_files':len(manifest['files']),
                  'original_PL_fields_inline_unchanged':26,'normal_VERIFIED_calls':1,
                  'owner_retained':True,'recursive_private_map_scan':'PASS',
                  'offline_check_only_no_Lean_browser_gate_or_transition_replay':True},indent=2))
