Exact script is preserved in command-transcript.jsonl; the raw source was parsed using bs4 html.parser.
