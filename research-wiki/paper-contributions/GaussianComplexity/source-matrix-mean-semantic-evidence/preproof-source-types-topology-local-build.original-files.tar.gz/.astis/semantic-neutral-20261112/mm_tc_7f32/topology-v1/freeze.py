from pathlib import Path
from collections import Counter
import datetime
import hashlib
import json
import re
import runpy
import sys

ROOT = Path('/Users/zhouhuanjian/ASTIS-GC')
OWN = ROOT/'.astis/semantic-neutral-20261112/mm_tc_7f32'
DEST = OWN/'topology-v1'
SG = ROOT/'.astis/semantic-neutral-20261112/mm_sg_61c4'
INPUTS = {
    'raw-freeze-v1/atomic-inventory.json':'6f58e1eae7a0c3adb6e1cb0422da3e8106baaabca2712d9cb9dc3b3f19a9f230',
    'raw-freeze-v1/locators-and-source-units.json':'a7eedcc25675956632cd861ac06c004e7762d6f2ec36e8a6bf3bbe8753245695',
    'raw-freeze-v1/coverage.json':'274007e988ff5c8fdaf2e5ff5128a4e6f0d46dd04985c46b292c4b4a7513a599',
    'raw-freeze-v1/unaccepted-raw-ports.json':'0b67e3e16773de628fbc86c5bdd76d959b1c5251583e5d4cb9a253a131dba96e',
    'source-graph-freeze-v1/source-proof-graph.json':'72cbce5939c8ac2b27ab9dc6d0b347e8b8f5311cc161d78727cc08e0ae9915b4',
    'source-graph-freeze-v1/post-seal-coverage.json':'508560a2f8c69f42e6482fab0c89f12b1f935700feb25e989a61e7f05667b8b8',
    'source-graph-freeze-v1/internal-ports-and-source-gaps.json':'70a8b803ed6d8b99cdd836dc57450075b0982e15e12326f31d6c276f13705d16',
    'source-graph-freeze-v1/chronology-qualification.json':'2c8964caeed7abd102fd068b2d95eda8bc69723014cded26de77aaa5d49630e3',
    'source-graph-freeze-v1/graph-exposure-record.json':'ec4a3e1ae1dd45a654480b60bafa81f8634083d1d8f73f02e8e775b0882de323',
    'source-graph-freeze-v1/source-reading-report.md':'ea7f5b7671dce5bab44b102bb21ea95f61b11f314512ef23d4c16e6131558974',
}

def sha(b):
    return hashlib.sha256(b).hexdigest()

def digest(path):
    b = path.read_bytes()
    return {'path':str(path.relative_to(ROOT)), 'bytes':len(b), 'sha256':sha(b)}

def write(name,obj):
    (DEST/name).write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n')

docs = {}
for name,val in INPUTS.items():
    assert digest(SG/name)['sha256'] == val
    if name.endswith('.json'):
        docs[name] = json.loads((SG/name).read_text())
g = docs['source-graph-freeze-v1/source-proof-graph.json']
c = docs['source-graph-freeze-v1/post-seal-coverage.json']
p = docs['source-graph-freeze-v1/internal-ports-and-source-gaps.json']
inv = docs['raw-freeze-v1/atomic-inventory.json']
loc = docs['raw-freeze-v1/locators-and-source-units.json']
rawcov = docs['raw-freeze-v1/coverage.json']
packetpath = ROOT/'.astis/huanjian-gc-source-matrix-mean-20261112/selective-type-definition-packet.json'
assert digest(packetpath)['sha256'] == 'efdba6eea9aa32da4cd9ea8d5022548ac128179f1ba73661fefa342f6ca4d95c'
packet = json.loads(packetpath.read_text())
expected = {
    'statement_seal_sha256':packet['statement_seal_sha256'],
    'producer_signature_sha256':packet['producer']['signature_sha256'],
    'consumer_signature_sha256':packet['actual_private_consumer']['signature_sha256'],
    'definition_context_sha256':packet['minimal_definition_context_sha256'],
    'selective_packet_sha256':digest(packetpath)['sha256'],
    'mathlib_pin':packet['minimal_definition_context']['mathlib_pin'],
}
for doc in [g,c,p,docs['source-graph-freeze-v1/graph-exposure-record.json']]:
    for key,val in expected.items():
        assert doc['bindings'][key] == val
    assert doc['bindings'] == g['bindings']
assert g['chronology_qualification_sha256'] == INPUTS['source-graph-freeze-v1/chronology-qualification.json']

preserved = []
for rel in ['SHA256SUMS','type-v1/SHA256SUMS']:
    sums = OWN/rel
    for line in sums.read_text().splitlines():
        val,name = line.split('  ',1)
        assert digest(sums.parent/name)['sha256'] == val
        preserved.append(digest(sums.parent/name))
    preserved.append(digest(sums))
assert digest(OWN/'raw-freeze.json')['sha256'] == '30a7d626b681fb59c522969a9be91797d1ca794f5e0433ea6941dfc7064c3fa8'
assert digest(OWN/'type-v1/freeze.json')['sha256'] == '4602bbe4a97d053a1e9cf788f0247fee5a6965d33e0cfdb40928767f995c43e7'
raw_input = json.loads((OWN/'input-manifest.json').read_text())
for a in raw_input['prior_R7_preserved_by_existing_checksum_manifests']:
    assert digest(ROOT/a['path'])['sha256'] == a['sha256']

sourcepath = ROOT/packet['source']['raw']
raw = sourcepath.read_bytes()
source = raw.decode()
assert sha(raw) == packet['source']['raw_sha256'] == loc['source_sha256']
occurrences = []

def walk(x,path):
    if isinstance(x,dict):
        if 'utf8_byte_start' in x:
            a,b = x['utf8_byte_start'],x['utf8_byte_end_exclusive']
            u,v = x['unicode_char_start'],x['unicode_char_end_exclusive']
            checks = {
                'raw_sha256':sha(raw[a:b]) == x['raw_fragment_sha256'],
                'unicode_utf8_map':source[u:v].encode() == raw[a:b],
                'LF_start_line':raw[:a].count(b'\n')+1 == x['lf_line_start_1based'],
                'LF_inclusive_end_line':raw[:b-1].count(b'\n')+1 == x['lf_line_end_1based'],
            }
            assert all(checks.values()),(path,checks)
            occurrences.append({'record_path':path,'locator':x,'checks':checks})
        for key,val in x.items():
            walk(val,path+'/'+key)
    elif isinstance(x,list):
        for n,val in enumerate(x):
            walk(val,path+'/'+str(n))

for name,doc in docs.items():
    walk(doc,name)
unique_spans = {(a['locator']['utf8_byte_start'],a['locator']['utf8_byte_end_exclusive']) for a in occurrences}
assert len(occurrences) == 463 and len(unique_spans) == 67
sys.argv = [str(OWN/'read_raw.py'),'silent']
reader = runpy.run_path(str(OWN/'read_raw.py'))
by_id = reader['by_id']
actual_units = [n.attrs['id'] for n in reader['r'].nodes if n.start>=731260 and n.end and n.end<=804228
                and n.tag in ['p','table'] and 'id' in n.attrs]
assert len(actual_units) == 47
assert actual_units == [a['element_id'] for a in c['units']] == [a['element_id'] for a in rawcov['units']]
nonspace = lambda s:re.sub(r'\s+','',s)
assert len(loc['source_units']) == 56
assert all(nonspace(v['text']) == nonspace(by_id[k].clean()) for k,v in loc['source_units'].items())
assert len(c['items']) == len(inv['items']) == 79
assert Counter(a['disposition'] for a in c['items']) == {'NODE':44,'EXCLUDED':35}
assert len({a['id'] for a in c['items']}) == 79
for a,b in zip(c['items'],inv['items']):
    assert all(a.get(k) == val for k,val in b.items())
    assert not a['disposition_change'] and a['post_seal_disposition'] == a['disposition']

specific = {
    'standing.naturals-and-range':'Exact natural source range retains q=0; denominator consequences remain internal.',
    'experiment.independent-standard-columns':'Source actual column experiment is retained; no ambient-transfer certificate or mean premise.',
    'grid.theta':'Exact source half-grid and physical one-based index; adjacent eigenvalue definitions excluded.',
    'c2.r':'Exact r=q+1 determines both row and feature dimensions.',
    'c2.n':'Exact n=2q+1 is needed for weighted frame/actual-sum weights.',
    'c2.physical-index':'All physical i=1,...,d retained as typing context.',
    'c2.literal-t':'Constant slot 1, other slots sqrt2 cos(k theta); exact deterministic finite feature vector.',
    'c2.actual-gamma':'Actual coordinate row of the same original sample, not resampled or replaced by basis coefficients.',
    'c2.row-marginal-law':'Marginal law is the relevant first-moment bridge; full joint row independence is not a needed premise.',
    'c2.B-normalization-context':'Context preserves gamma-first tensor order and distinguishes B inverse-sqrt-d from Yi inverse-d.',
    'cutoff.L':'Exact fixed source L, with no tail/success-event premise.',
    'cutoff.R':'Actual row squared Euclidean norm, with no common-event conditioning.',
    'Yi.actual-definition':'Exact actual inverse-d tensor and inclusive local cutoff; same mu and zero outside.',
    'mean.radial-symmetry-invocation':'Printed proof invocation retained; its internal moment/integrability derivation remains unproved.',
    'mean.truncated-row-outer-product':'Exact source retained matrix moment retained as target specification, never a new caller premise.',
    'mean.literal-a':'Source retained radial coefficient must match the canonical scalar through the internal law/integability ports.',
    'mean.a-common':'Common coefficient derives from common marginal law and fixed r,L, not an iid or mean certificate.',
    'mean.actual-Y':'Exact actual matrix mean is a/d times I tensor t outer product; Bochner transport remains open.',
    'mean.FactC5-use':'Explicit direct source consumer use at p12.4; no implementation topology inferred.',
    'consumer.sum-means':'Exact Ex110 unweighted sum of actual means equals a times paired identity.',
    'consumer.weighted-sum-means':'Exact Ex110 deterministic cosine-weighted sum of actual means is zero.',
    'consumer.weighted-expectation-conclusion':'Actual weighted sum expectation requires internal finite Bochner exchange; source explicitly states this endpoint.',
}

def atom_comment(a):
    name = a['id']
    if a['disposition'] == 'NODE':
        if name in specific:
            return specific[name]
        assert name.startswith('c5.')
        return 'Raw deterministic cosine/frame clause and its stated normalization, case/frequency conditions match; it belongs to the complete source chain for the two exact frame identities, with no formal proof credited.'
    if name in ['c2.joint-row-independence','Yi.independence-claim']:
        return 'Independence is outside this mean packet and is not needed for individual expectation transport or finite linearity.'
    if name.startswith('cutoff.') or name.startswith('bias.'):
        return 'Tail/common-event/bias or a-range content is outside exact means; no conditioning, positivity or probability certificate is imported.'
    if name in ['c5.t-norm-bound','c5.t-norm-proof']:
        return 'Uniform t norm estimate excluded without assuming integrability; the literal fixed finite factors and matrix integrability still require internal discharge.'
    return 'The complete raw clause is range/B/spectral/concentration context outside these actual truncated first-moment and mean-sum outputs; no required deterministic-frame identity is lost.'

atoms = [{
    'ordinal_1based':n+1,'id':a['id'],'source_element_id':a['source_element_id'],
    'semantic_slice':a.get('semantic_slice'),'disposition':a['disposition'],
    'review':'ACCEPT_BOUNDED_SOURCE_DISPOSITION','independent_comment':atom_comment(a),
    'locator':a['locator'],'source_text_independently_read':True,
    'locator_hash_spans_lines_match':True,'proof_credit':False,
} for n,a in enumerate(c['items'])]
write('atom-review.json',{'version':1,'items':atoms})

ids = {n['id'] for n in g['nodes']}
assert len(g['nodes']) == 62 and len(g['edges']) == 94
assert {n['id'] for n in g['nodes'] if 'source_element_id' in n} == {a['id'] for a in c['items'] if a['disposition']=='NODE'}
assert all(e['from'] in ids and e['to'] in ids and e['compiled_dependency'] is False for e in g['edges'])
assert len(g['hyperedges']) == 1
assert g['hyperedges'][0]['premise_formula'] == 'INTERNAL.mean-transport-CLM OR INTERNAL.mean-transport-entrywise'
or_links = [('INTERNAL.mean-transport-CLM','INTERNAL.mean-transport-result'),
            ('INTERNAL.mean-transport-entrywise','INTERNAL.mean-transport-result')]

def ancestors(root):
    result = {root}
    while True:
        old = set(result)
        for e in g['edges']:
            if e['to'] in result:
                result.add(e['from'])
        for start,end in or_links:
            if end in result:
                result.add(start)
        if old == result:
            return sorted(result)

roots = {name:ancestors(name) for name in g['roots']}
source_endpoints = ['mean.actual-Y','consumer.sum-means','consumer.weighted-sum-means',
                    'consumer.weighted-expectation-conclusion','mean.FactC5-use']
source_closures = {name:ancestors(name) for name in source_endpoints}
covered = set().union(*(set(v) for v in list(roots.values())+list(source_closures.values())))
context = {'c2.physical-index','c2.B-normalization-context','c5.feature-index'}
assert len(covered) == 59 and covered|context == ids
remaining = set(ids)
edge_pairs = [(e['from'],e['to']) for e in g['edges']]+or_links
while remaining:
    ready = {n for n in remaining if not any(t==n and f in remaining for f,t in edge_pairs)}
    assert ready,'Graph cycle'
    remaining -= ready
write('root-coverage.json',{
    'version':1,'formal_root_ancestors_with_explicit_OR':roots,
    'source_endpoint_ancestors':source_closures,
    'correspondence_links_not_proof_edges':[
        {'formal_root':'FORMAL.producer','source_endpoints':['mean.actual-Y'],
         'evidence':'INTERNAL.mean-transport-result source_context and p12.4 consumer-use sites; source assertion is a specification, not a caller premise.'},
        {'formal_root':'FORMAL.private-consumer','source_endpoints':source_endpoints[1:],
         'evidence':'INTERNAL.tensor-and-sum-algebra and INTERNAL.finite-Bochner-exchange source_context, plus p12.4/Ex110/p12.5 consumer-use sites.'}
    ],
    'explicit_nonproof_typing_normalization_context':sorted(context),
    'all_nodes_accounted':62,'source_and_formal_closure_union':59,
    'unexplained_nodes':[],'acyclic_with_OR':True,
    'OR_semantics':'Closure lists both alternatives for review coverage, not as simultaneous required hypotheses.',
    'actual_compiled_root_closure_certified':False,
})

def edge_comment(e):
    kind = e['kind']
    if kind == 'direct source consumer use':
        return 'Direction and exact raw consumer site match the author formula/invocation; not a compiled theorem edge.'
    if 'alternative route' in kind:
        return 'Inputs belong to one alternative mean-transport method; the explicit OR join never requires both alternatives as an AND.'
    if 'sealed-target correspondence' in kind:
        return 'Matches fixed target output only; no proof, totalization shortcut or caller premise is certified.'
    if 'intended consumer' in kind:
        return 'Planned actual producer/frame use is faithful to the source endpoint; actual proof call and applicability remain unseen.'
    if 'INTERNAL' in kind:
        return 'Correct internal applicability/integrability/transport/exchange obligation at this source use; all hypotheses remain to be discharged internally.'
    return 'Source-supported invocation or omitted inference is retained without promoting source wording to a proof premise or compiled parent.'

write('edge-review.json',{'version':1,'edges':[
    {'ordinal_1based':n+1,'from':e['from'],'to':e['to'],'kind':e['kind'],
     'review':'ACCEPT_SOURCE_OR_UNPROVED_APPLICABILITY_TOPOLOGY','independent_comment':edge_comment(e),
     'consumer_use_sites':e['consumer_use_sites'],'locator_checks_pass':True,
     'compiled_dependency_certified':False} for n,e in enumerate(g['edges'])],
    'OR_hyperedge_review':{'id':g['hyperedges'][0]['id'],'review':'ACCEPT_EXPLICIT_ALTERNATIVES',
                           'both_routes_proved_or_required_as_AND':False}})
assert len(p['ports']) == 13
assert {a['id'] for a in p['ports']} == {n['id'] for n in g['nodes'] if n['id'].startswith('INTERNAL.')}
assert not p['genuine_source_gaps'] and not g['genuine_source_gaps'] and not g['compiled_parents']
write('port-review.json',{'version':1,'genuine_blockers':[],'ports':[
    {'id':a['id'],'obligation':a['obligation'],'source_context':a['source_context'],
     'review':'EXPECTED_STILL_UNPROVED_INTERNAL_MATHEMATICAL_APPLICABILITY_PORT',
     'still_open':True,'missing_source_coverage_blocker':False,'public_hypothesis':False,
     'compiled_or_API_applicability_certified':False} for a in p['ports']],
    'alternative_port_note':'The CLM and entrywise ports are alternative sufficient routes; all port records are reviewed, without requiring both routes to be proved.'})
write('locator-checks.json',{'version':1,'source':digest(sourcepath),'occurrences':463,
                           'unique_spans':67,'checks':occurrences})
write('input-manifest.json',{
    'authorized_SG_inputs':[digest(SG/name) for name in INPUTS],
    'fixed_type_packet':digest(packetpath),'exact_type_bindings_checked':expected,
    'unopened_SG_manifest_type_audit_references_note':'Additional SG type/raw-freeze audit hashes are metadata references only; their separate files were not opened or certified.',
    'prior_own_MM_records_preserved':preserved,
    'prior_R7_records_preserved_count':len(raw_input['prior_R7_preserved_by_existing_checksum_manifests']),
    'source':digest(sourcepath),
})
local_names = ['assignment.txt','report.md','exposure.json','read_inputs.py','freeze.py',
               'atom-review.json','root-coverage.json','edge-review.json','port-review.json',
               'locator-checks.json','input-manifest.json']
freeze = {
    'version':1,'kind':'distinct-independent-source-coverage-topology-applicability-coverage-freeze',
    'actor':'/root/row_indep_topology_24a6','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'finding':'ACCEPT_BOUNDED_SOURCE_COVERAGE_AND_UNPROVED_TOPOLOGY_ONLY',
    'genuine_blockers':[],'still_unproved_INTERNAL_ports':13,
    'counts':{'atoms':79,'NODE':44,'EXCLUDED':35,'nodes':62,'edges':94,'OR_hyperedges':1,
              'continuous_source_units':47,'atom_source_elements':56,'locator_occurrences':463,'unique_raw_spans':67,
              'formal_producer_reverse_closure':24,'formal_consumer_reverse_closure':54,
              'source_formal_closure_union':59,'explicit_context_nodes':3,'all_nodes_accounted':62},
    'bindings':expected,'SG_source_graph':digest(SG/'source-graph-freeze-v1/source-proof-graph.json'),
    'local_records':[digest(DEST/name) for name in local_names],
    'prior_raw_freeze':digest(OWN/'raw-freeze.json'),'prior_type_freeze':digest(OWN/'type-v1/freeze.json'),
    'own_and_SG_input_artifacts_preserved':True,
    'implementation_or_target_proof_seen':False,'proof_or_API_search_attempts':0,
    'mathematical_or_API_applicability_proof_certified':False,
    'compiled_edge_source_VERIFIED_normal_intake_or_permission_grant':False,
    'truth_boundary':'Only bounded source coverage and obligation topology accepted. All thirteen ports, actual producer/consumer proofs, exact API applications, compiled calls, normal verification and repository admission remain open.',
}
write('freeze.json',freeze)
for name,val in INPUTS.items():
    assert digest(SG/name)['sha256'] == val
records = [digest(DEST/name) for name in local_names]+[digest(DEST/'freeze.json')]
(DEST/'SHA256SUMS').write_text(''.join(f"{a['sha256']}  {Path(a['path']).name}\n" for a in records))
print(json.dumps({'freeze':digest(DEST/'freeze.json'),'report':digest(DEST/'report.md'),
                  'input_manifest':digest(DEST/'input-manifest.json'),'finding':freeze['finding'],
                  'counts':freeze['counts'],'genuine_blockers':[],'open_internal_ports':13,
                  'own_and_SG_originals_preserved':True},indent=2))
