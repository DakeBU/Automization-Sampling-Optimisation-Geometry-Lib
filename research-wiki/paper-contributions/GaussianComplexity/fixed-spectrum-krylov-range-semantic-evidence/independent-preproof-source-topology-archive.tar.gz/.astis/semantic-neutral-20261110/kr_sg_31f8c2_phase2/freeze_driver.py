from pathlib import Path
import os,sys,stat,json,hashlib,subprocess,datetime,traceback
ROOT=Path(__file__).resolve().parent;REPO=ROOT.parents[2]
utc=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
sha=lambda b:hashlib.sha256(b).hexdigest()
enc=lambda x:(json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode()
started=utc();envelope={'payload-manifest.json','freeze-execution.receipt.json','freeze-execution.stdout','freeze-execution.stderr','freeze-envelope-hashes.json'}
assert not any((ROOT/x).exists() for x in envelope)
argv=[sys.executable,str(ROOT/'verify_overlay.py')]
r=subprocess.run(argv,cwd=REPO,capture_output=True)
(ROOT/'freeze-verification.stdout').write_bytes(r.stdout);(ROOT/'freeze-verification.stderr').write_bytes(r.stderr)
assert r.returncode==0,r.stderr.decode(errors='replace')
pres=json.loads((ROOT/'phase1-preservation-final.json').read_bytes());assert not pres['changed'] and pres['status']=='preserved exactly'
payload=[]
for path in sorted(ROOT.rglob('*')):
    assert not path.is_symlink()
    if path.is_file() and path.name not in envelope:
        b=path.read_bytes();payload.append({'path':str(path.relative_to(ROOT)),'bytes':len(b),'sha256':sha(b),'frozen_mode':'0444'})
manifest={'schema':'phase2-static-payload-manifest-v1','created_utc':utc(),'root':str(ROOT),'phase1_original_manifest_sha256':'973bcc204bdbad7ac177017fa859d81f03122e7fc583233857c9a31b32afa9b8','selective_packet_raw_sha256':'471d8f4351d80f33d478049a0a2d8716689b2140c043aa324d8132f9b3fb79cb','files':payload,'envelope_files':sorted(envelope),'nonrecursive_hash_contract':'This manifest covers all static overlay/audit/input/command/script files. The five freeze-envelope files are excluded; freeze-envelope-hashes.json covers the other four and explicitly excludes itself. All files including the envelope become0444, all directories0555. Phase1 is never chmodded or written.'}
(ROOT/'payload-manifest.json').write_bytes(enc(manifest));manifest_sha=sha((ROOT/'payload-manifest.json').read_bytes())
handles={n:(ROOT/n).open('w+b') for n in envelope if n!='payload-manifest.json'}
try:
    files=sorted(p for p in ROOT.rglob('*') if p.is_file())
    dirs=sorted([ROOT]+[p for p in ROOT.rglob('*') if p.is_dir()],key=lambda p:len(p.parts),reverse=True)
    actions=[]
    for path in files:
        os.chmod(path,0o444);actions.append({'path':str(path.relative_to(ROOT)),'operation':'chmod','requested_mode':'0444','actual_mode':format(stat.S_IMODE(path.stat().st_mode),'04o')})
    for path in dirs:
        os.chmod(path,0o555);actions.append({'path':'.' if path==ROOT else str(path.relative_to(ROOT)),'operation':'chmod','requested_mode':'0555','actual_mode':format(stat.S_IMODE(path.stat().st_mode),'04o')})
    assert all(x['requested_mode']==x['actual_mode'] for x in actions)
    for item in payload:
        b=(ROOT/item['path']).read_bytes();assert sha(b)==item['sha256'] and len(b)==item['bytes']
    receipt={'schema':'actual-phase2-freeze-execution-v1','status':'FROZEN_PHASE2_OVERLAY','started_utc':started,'chmod_and_static_hash_verification_completed_utc':utc(),'cwd':str(REPO),'invocation':['python3',str(Path(__file__).relative_to(REPO))],'actual_interpreter':sys.executable,'payload_manifest_sha256':manifest_sha,'payload_files':len(payload),'files_including_envelope':len(files),'directories_including_root':len(dirs),'verification_command':argv,'verification_returncode':r.returncode,'verification_stdout_sha256':sha(r.stdout),'verification_stderr_sha256':sha(r.stderr),'phase1_preservation_record_sha256':sha((ROOT/'phase1-preservation-final.json').read_bytes()),'phase1_files_untouched':111,'phase1_directories_untouched':6,'phase1_snapshot_hash_before':pres['baseline_snapshot_sha256'],'phase1_snapshot_hash_after':pres['final_snapshot_sha256'],'actions':actions,'envelope_finalization':'Four envelope descriptors opened before actual chmod; receipt and raw stdout/stderr and nonrecursive envelope hash index finalized through those descriptors after mode/hash verification, then all descriptors closed. No permissions relaxed. All chmod paths are within this new Phase2 root only.','semantic_limit':'Planned-type binder/definition/source-root overlay only; no implementation/proof closure/compiled parents/sourceV/topology approval.'}
    rb=enc(receipt);handles['freeze-execution.receipt.json'].write(rb);handles['freeze-execution.receipt.json'].flush()
    log=enc({'status':'FROZEN_PHASE2_OVERLAY','root':str(ROOT),'payload_manifest_sha256':manifest_sha,'freeze_receipt_sha256':sha(rb),'type_source_overlay_sha256':sha((ROOT/'type-source-overlay.json').read_bytes()),'planned_type_audit_sha256':sha((ROOT/'planned-type-audit.md').read_bytes()),'capsule_sha256':sha((ROOT/'capsule.md').read_bytes()),'phase1_preservation_sha256':sha((ROOT/'phase1-preservation-final.json').read_bytes()),'phase1_files_unchanged':111,'phase1_directories_unchanged':6,'files_0444':len(files),'directories_0555':len(dirs),'scope':'no sourceV or topology approval; no actual compiled parent claim'})
    handles['freeze-execution.stdout'].write(log);handles['freeze-execution.stdout'].flush()
    handles['freeze-execution.stderr'].write(b'');handles['freeze-execution.stderr'].flush()
    env={'schema':'nonrecursive-phase2-freeze-envelope-hashes-v1','self_excluded':'freeze-envelope-hashes.json','files':[]}
    for name in sorted(envelope-{'freeze-envelope-hashes.json'}):
        b=(ROOT/name).read_bytes();env['files'].append({'path':name,'bytes':len(b),'sha256':sha(b),'mode':format(stat.S_IMODE((ROOT/name).stat().st_mode),'04o')})
    handles['freeze-envelope-hashes.json'].write(enc(env));handles['freeze-envelope-hashes.json'].flush()
    for h in handles.values():h.close()
    assert all(stat.S_IMODE(p.stat().st_mode)==0o444 for p in files)
    assert all(stat.S_IMODE(p.stat().st_mode)==0o555 for p in dirs)
    sys.stdout.buffer.write(log)
except BaseException:
    tb=traceback.format_exc().encode();h=handles.get('freeze-execution.stderr')
    if h and not h.closed:h.write(tb);h.flush()
    for h in handles.values():
        if not h.closed:h.close()
    sys.stderr.buffer.write(tb)
    raise
