from pathlib import Path
from hashlib import sha256
from bs4 import BeautifulSoup
p=Path('.astis/huanjian-resume-20261103/2610.20492v1.html')
b=p.read_bytes()
s=BeautifulSoup(b,'html.parser')
print('raw',len(b),sha256(b).hexdigest())
for ident in ['S4.Thmtheorem4','A3.SS2','A3.Thmtheorem5']:
 e=s.find(id=ident)
 print('\nANCHOR',ident,'FOUND',e is not None)
 if e:
  print('TAG',e.name,'class',e.get('class'),'ancestors',[(a.name,a.get('id')) for a in list(e.parents)[:4]])
  print(e.get_text(' ',strip=True))
