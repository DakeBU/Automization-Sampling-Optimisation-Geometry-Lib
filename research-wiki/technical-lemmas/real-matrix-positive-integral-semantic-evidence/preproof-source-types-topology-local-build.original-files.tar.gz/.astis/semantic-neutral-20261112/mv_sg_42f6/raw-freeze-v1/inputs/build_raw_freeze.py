from pathlib import Path
import re,html,hashlib,json,datetime,shutil
ROOT=Path('/Users/zhouhuanjian/ASTIS-GC');BASE=ROOT/'.astis/semantic-neutral-20261112/mv_sg_42f6';OUT=BASE/'raw-freeze-v1'
SOURCE=ROOT/'.astis/huanjian-resume-20261103/2610.20492v1.html'
B=SOURCE.read_bytes();S=B.decode()
def sha(b):return hashlib.sha256(b).hexdigest()
assert len(B)==951991 and sha(B)=='6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
assert not OUT.exists(),'Never overwrite immutable raw interpretation.'
def element(id):
 m=re.search(r'<([A-Za-z][\w:]*)\b[^>]*\bid="'+re.escape(id)+r'"[^>]*>',S);assert m,id;dep=1
 for n in re.finditer(r'</?'+re.escape(m[1])+r'\b[^>]*>',S[m.end():]):
  dep+=-1 if n[0].startswith('</') else 1
  if not dep:return m.start(),m.end()+n.end()
 raise ValueError(id)
def plain(a,z):
 fs=[]
 def sub(m):fs.append(html.unescape(m[1]));return ' MATH'+str(len(fs)-1)+'END '
 t=re.sub(r'<math\b[^>]*alttext="([^"]*)"[^>]*>.*?</math>',sub,S[a:z],flags=re.S);t=re.sub(r'</(?:p|div|table|tbody|h[1-6])>','\n',t)
 t=html.unescape(re.sub(r'<[^>]+>','',t));t=re.sub(r'MATH(\d+)END',lambda m:'$'+fs[int(m[1])]+'$',t)
 return re.sub(r'\n\s*\n+','\n',t).strip()
def loc(a,z):
 x=len(S[:a].encode());y=len(S[:z].encode());return {'utf8_byte_start':x,'utf8_byte_end_exclusive':y,'unicode_char_start':a,'unicode_char_end_exclusive':z,'lf_line_start_1based':S.count('\n',0,a)+1,'lf_line_end_1based':S.count('\n',0,z-1)+1,'raw_fragment_sha256':sha(B[x:y])}
OUT.mkdir();(OUT/'inputs').mkdir();(OUT/'source-fragments').mkdir()
def dump(n,v):(OUT/n).write_text(json.dumps(v,ensure_ascii=False,sort_keys=True,indent=2)+'\n',encoding='utf-8')
def write(n,t):(OUT/n).write_text(t,encoding='utf-8')
task='''Prospective NEXT packet RAW source reading only while current R8 is under independent normal V (root remains sole mathematical prover). Own new dir .astis/semantic-neutral-20261112/mv_sg_42f6. Pinned .astis/huanjian-resume-20261103/2610.20492v1.html SHA6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915. Read complete C.2 p1–p15, focus Ex113/114 uncentered squared-matrix mean sum PSD bound 2r(r+2)/d I and source centered Zi=Yi−EYi + cosine-weighted variance assertions in p15. Proposed producer will handle actual ORIGINAL independent-column experiment Yi integrability of Yi² and actual uncentered second-moment sum bound; real private consumer to derive actual centered and cos(nθ)-weighted squared-mean bounds, with integrability/centering internal outputs as needed. Final exacttypes/seal not yetformed: no type/graph/topology admission, no implementation/API body search. Sameμ original physicalrows, q0,2q+1<d, literal closed cutoff/Gaussian-first pairs/inverse-d; no moment/variance/PSD/mean/Gram/independence certificate premise, no tau/kappa bound or R* norm/concentration/mainresult credit. Prior R4/R5/R8 canonical results are reported existing context only, no compiledparent guessed from imports/names, no private canonical-row test import assumed as public provider. Distinguish ordinary missing internal applicability/matrix positivity/integral algebra from genuineSOURCE_GAP. Freeze own exhaustive raw atom/locator/dispositions/source-use/notes/ports with explicit before-this-actor-newtype-exposure chronology, preserve allR7/R8 originals. Return raw manifestpaths/hashes; wait separate exactsealed packet before formalgraph. No trackedC/L/registry/Git/shared changes.'''
write('inputs/task-envelope.txt',task+'\n')
protocols=['AGENTS.md','CONTRIBUTING.md','.agents/prompts/collaborator-contribution.md','docs/contributor-codex-contract.md','docs/theorem-publication-protocol.md','docs/proof-digestion-protocol.md','docs/evidence-routed-memory-protocol.md','.agents/skills/astis-substantive-advance/SKILL.md','.agents/skills/astis-semantic-roundtrip/SKILL.md','.agents/prompts/samplewiki-route.md']
inputs=[]
for n in protocols:
 b=(ROOT/n).read_bytes();dest='inputs/'+n.replace('/','__');(OUT/dest).write_bytes(b);inputs.append({'path':n,'snapshot':dest,'bytes':len(b),'sha256':sha(b),'role':'Process protocol already read by this actor; current bytes snapshotted only, not source mathematics.'})
(OUT/'inputs/2610.20492v1.html').write_bytes(B);inputs.append({'path':str(SOURCE.relative_to(ROOT)),'snapshot':'inputs/2610.20492v1.html','bytes':len(B),'unicode_characters':len(S),'LF_count':S.count('\n'),'sha256':sha(B),'role':'Original pinned mathematical source; bounded reading only.'})
shutil.copyfile(BASE/'working/build_raw_freeze.py',OUT/'inputs/build_raw_freeze.py')
units={};items=[]
def unit(id):
 if id not in units:
  a,z=element(id);units[id]={'locator':loc(a,z),'text':plain(a,z),'atom_ids':[]};(OUT/'source-fragments'/f'{id}.raw.html').write_bytes(S[a:z].encode())
 return units[id]
def atom(id,a,disp,k,m,r=None,sl=None):
 u=unit(a);v={'id':id,'source_element_id':a,'locator':u['locator'],'disposition':disp,'kind':k,'meaning':m,'status':'RAW_UNACCEPTED_NO_NEW_TYPE_EXPOSURE'}
 if r:v['reason']=r
 if sl:v['semantic_slice']=sl
 items.append(v);u['atom_ids'].append(id)
def n(id,a,k,m,sl=None):atom(id,a,'NODE',k,m,sl=sl)
def x(id,a,k,m,r,sl=None):atom(id,a,'EXCLUDED',k,m,r,sl)
x('standing.C','S4.Thmtheorem4.p1.1','theorem quantifier','Absolute C>0.','No concentration/uniform-bound constant is selected.','First sentence')
n('standing.range','S4.Thmtheorem4.p1.1','standing source range','Natural d,q; q>=0,2q+1<d; q=0 retained.','Range clause; natural typing follows source dimension/query-count convention and assigned scope')
n('experiment.columns','S4.Thmtheorem4.p1.1','source experiment','r=q+1 independent standard d-Gaussian columns.','Column clause')
x('standing.K','S4.Thmtheorem4.p1.1','source notation','K_q alias.','No Krylov result is selected.','K clause')
n('grid.theta','S4.E11.m1','literal source definition','theta_i=(i-1/2)pi/d, source physical i=1,...,d.','theta clause')
x('grid.spectral','S4.E11.m1','source definitions','lambda_i and Lambda.','No kappa/eigenvalue input or spectral result is selected.','lambda/Lambda clauses')
n('c2.r','A3.SS2.p1.1','literal source definition','r=q+1.','r clause')
n('c2.n','A3.SS2.p1.1','literal source definition','n=2q+1.','n clause')
n('c2.indices','A3.SS2.p1.1','typing context','1<=i<=d.','Index clause')
n('c2.t','A3.Ex85','literal source definition','t_i=(1,sqrt2cos(theta_i),...,sqrt2cos(q theta_i))^T.','t clause')
n('c2.gamma','A3.Ex85','literal source definition','gamma_i=((g_1)_i,...,(g_r)_i)^T from the actual same original-column sample.','gamma clause')
x('c2.row-joint-independence','A3.SS2.p1.2','unnamed source claim','The physical rows are jointly independent.','Moment sum and per-row centering comparisons do not require independence; this packet gives no new independence/R7 credit.','Independence clause')
n('c2.row-law','A3.SS2.p1.2','unnamed source law claim','Each physical row has law N(0,I_r).','Gaussian marginal-law clause')
n('c2.B-context','A3.SS2.p1.2','literal definition context','B row is d^(-1/2)(gamma_i tensor t_i)^T in R^(d x r^2).','B clause; tensor order/normalization context only')
for id,m in [('norm','u=Bc and control ||u||^2 via B^T B'),('weighted','Control u^T D_nu via B^T D_nB'),('concentration','Span/mean/concentration strategy toward the uniform bound')]:
 x('strategy.'+id,'A3.SS2.p2.1','substantive source strategy',m,'No uniform/Krylov/concentration theorem is selected.')
for id,m in [('range','range(B)=K_q'),('Bmean','E[B^T B]=I_(r^2)'),('weightedBmean','E[B^T D_nB]=0')]:
 x('c5.'+id,'A3.Ex86','Fact C.5 conclusion',m,'Untruncated B result is not needed by the selected actual-Y square bounds.',id+' clause')
n('c5.t-norm','A3.Ex87','Fact C.5 estimate','||t_i||^2<=2r.','First clause')
n('c5.t-Gram','A3.Ex87','Fact C.5 exact identity','sum_i t_i t_i^T=d I_r.','Second clause')
x('c5.weighted-Gram','A3.Ex87','Fact C.5 exact identity','sum_i cos(n theta_i)t_i t_i^T=0.','Centered weighted-square domination uses cos^2<=1, not the weighted Gram identity.','Third clause')
x('c5.range-proof','A3.SS2.p3.1','substantive proof paragraph','Chebyshev/invertible-triangular change of basis for range(B).','No spectral/range theorem is selected.')
x('c5.Bmean-subgoal','A3.SS2.p4.1','proof subgoal','Boxed E[B^T B]=I_(r^2).','Only its deterministic cosine/Gram proof context is selected.','Boxed clause')
n('c5.theta-recall','A3.SS2.p4.m2','reused definition','theta_i=(i-1/2)pi/d.')
n('c5.frequency-domain','A3.SS2.p4.1','proof domain','Integer k with 0<|k|<2d.','Final clause')
for id,m in [('A3.Ex88','Cosine sum times 2sin(k pi/2d) telescopes as sine differences'),('A3.Ex89','Endpoint sine difference=0'),('A3.SS2.p4.2','Nonzero sine factor yields sum_i cos(k theta_i)=0')]:n('c5.'+id,id,'substantive exact identity/proof step',m)
n('c5.feature-indices','A3.SS2.p5.1','typing context','t coordinates are0,...,q.','First sentence')
n('c5.constant-sum','A3.Ex90','exact coordinate sum','sum_i(t_i)_0^2=d.','First clause')
n('c5.mixed-sum','A3.Ex90','exact coordinate sum','sum_i(t_i)_0(t_i)_j=sqrt2 sum_i cos(j theta_i)=0 for1<=j<=q.','Second clause')
for id,m in [('A3.SS2.p5.2','For1<=j,k<=q invoke product-to-sum'),('A3.Ex91','Positive-feature product sum=2sum cos(j theta_i)cos(k theta_i)'),('A3.Ex92','Split into cosine sums at j-k and j+k'),('A3.Ex93','Result is d on diagonal,0 otherwise'),('A3.SS2.p5.3','Frequency-range checks, symmetry and full unweighted t Gram identity')]:n('c5.'+id,id,'substantive deterministic proof step',m)
for id,m in [('A3.SS2.p6.1','E[gamma_i gamma_i^T]=I_r and B-row use'),('A3.Ex94','Expected B Gram sum'),('A3.Ex95','Tensor factorization to I_(r^2)'),('A3.SS2.p7.1','Weighted B mean subgoal and n=2q+1'),('A3.Ex96','1<=n-j-k<=n±j±k<=n+j+k<=4q+1<2d'),('A3.SS2.p7.2','Invoke cosine-sum identity'),('A3.Ex97','Triple cosine sum'),('A3.Ex98','Four-frequency product-to-sum'),('A3.Ex99','Weighted cosine sum=0'),('A3.SS2.p7.3','Weighted t Gram zero and consequent B-mean step'),('A3.Ex100','Weighted B mean sum'),('A3.Ex101','Weighted B mean tensor zero')]:
 x('c5.'+id,id,'unnamed estimate/reused display/proof step',m,'The weighted Gram/B-mean route is not needed for variance-square domination; no such premise is introduced.')
n('c5.t-norm-proof','A3.Ex102','substantive source estimate','||t_i||^2=1+2sum_(j=1)^q cos^2(j theta_i)<=1+2q<=2r.')
for id,m in [('A3.SS2.p9.1','Deviation strategy for both Gram matrices'),('A3.Thmtheorem6.p1.1','Sufficient absolute C gives probability0.995'),('A3.Ex103','Simultaneous operator-norm concentration bounds')]:
 x('c6.'+id,id,'source strategy/fact',m,'No concentration statement is selected.')
n('cutoff.L','A3.SS2.p10.m1','literal source definition','L=2r+3log(1000d).')
n('cutoff.R','A3.SS2.p10.m2','literal source definition','R_i=||gamma_i||^2.')
for id,m in [('A3.SS2.p10.m3','E exp(R_i/3)=3^(r/2)'),('A3.SS2.p10.1','Markov invocation for x>=0'),('A3.Ex104','Exponential tail estimate'),('A3.SS2.p10.2','log3/2<2/3 and transition to event'),('A3.Ex105','T={R_i<=L for every i}'),('A3.SS2.p10.3','P(T)>=0.999'),('A3.SS2.p11.1','Shifted discarded-radius tail'),('A3.Ex106','Discarded-radius mean/bias estimate')]:
 x('tail.'+id,id,'unnamed source moment/event/estimate',m,'No tail/common-event/bias result is selected; Y keeps its own local closed cutoff.', 'Only Markov clause; cutoff definitions inventoried separately' if id=='A3.SS2.p10.1' else None)
x('Yi.independence','A3.SS2.p12.1','unnamed source claim','Define independent truncated matrices.','This packet selects squares/centering bounds, not a new independence result.')
n('Yi.literal','A3.Ex107','literal source definition','Y_i=(1/d)(gamma_i gamma_i^T tensor t_i t_i^T)1_(R_i<=L).')
for id,m in [('A3.SS2.p12.2','Radial symmetry for first retained mean'),('A3.Ex108','Retained row outer-product mean=aI_r and scalar a definition'),('A3.SS2.p12.3','Common a; E R_i=r and0<=a<=1'),('A3.Ex109','1-a discarded-tail bound'),('A3.SS2.p12.4','E Yi=(a/d)(I_r tensor t_i t_i^T), then Fact C.5 use'),('A3.Ex110','Unweighted/weighted sums of first means aI/0'),('A3.SS2.p12.5','Truncated weighted sum has zero expectation')]:
 x('firstmean.'+id,id,'source first-moment/bias statement',m,'Centering is by the actual E Yi; the selected square comparison does not need a supplied exact-mean/a/Gram-weighted certificate. Prior R8 is reported context only and no public provider is inferred.')
n('center.Z','A3.SS2.p13.1','literal source definition','Z_i=Y_i-E Y_i.','Put Z clause')
x('center.norm-prelude','A3.SS2.p13.1','substantive proof invocation','Use ||t_i||^2<=2r for summand norm bounds.','R* norm route is excluded.','Using clause')
x('norm.Y','A3.Ex111','source operator-norm identity/estimate','||Yi||_op=R_i||ti||^2/d indicator<=2rL/d.','No almost-sure R* or norm-bound result is selected.','First clause')
x('norm.EY','A3.Ex111','source operator-norm identity/estimate','||EYi||_op=a||ti||^2/d<=2r/d.','No R* or a-range bound is selected.','Second clause')
x('norm.centered','A3.Ex112','source operator-norm estimate/definition','||Zi||_op<=2r(L+1)/d=:R*.','R* bound excluded.')
x('norm.weighted','A3.SS2.p13.3','source operator-norm assertion','The same R* bound holds for cos(n theta_i)Zi.','Weighted R* route excluded.','First clause')
n('weight.cos-bound','A3.SS2.p13.3','unnamed scalar source estimate','|cos(n theta_i)|<=1.','Since clause')
n('fourth.invocation','A3.SS2.p14.1','substantive source invocation','Gaussian fourth moments give the following retained-unrestricted row matrix mean.')
n('fourth.actual-row-moment','A3.Ex113','unnamed exact source moment','E[R_i gamma_i gamma_i^T]=(r+2)I_r.')
n('fourth.off-diagonal','A3.SS2.p14.2','substantive proof clause','Off-diagonal entries vanish by sign symmetry.','First clause')
n('fourth.diagonal','A3.SS2.p14.2','substantive proof clause','Each diagonal entry equals3+(r-1)=r+2.','Second clause')
n('square.gaussian-rank-one','A3.SS2.p14.2','reused exact matrix identity','(gamma_i gamma_i^T)^2=R_i gamma_i gamma_i^T.','First Since identity')
n('square.feature-rank-one','A3.SS2.p14.2','reused exact matrix identity','(t_i t_i^T)^2=||t_i||^2 t_i t_i^T.','Second Since identity')
n('square.actual-Y','A3.Ex114','unnamed exact source matrix identity','Yi^2=(R_i||ti||^2/d^2)(gamma_i gamma_i^T tensor ti ti^T)1_(R_i<=L).')
n('square.drop-indicator','A3.SS2.p14.3','substantive PSD-order proof step','Drop truncation indicator in this positive-semidefinite expression.')
n('square.sum-first-order-bound','A3.Ex115','source Loewner inequality','sum_i E Yi^2 <=PSD (r+2)/d^2 sum_i ||ti||^2(I_r tensor ti ti^T).')
n('square.sum-use-t-norm','A3.Ex116','source Loewner inequality','The preceding RHS <=PSD (2r(r+2)/d^2)(I_r tensor sum_i ti ti^T).')
n('square.sum-final','A3.Ex117','source exact simplification','The preceding RHS=(2r(r+2)/d)I_(r^2).')
n('square.explicit-C5-use','A3.SS2.p14.4','explicit source consumer use','Here used ||ti||^2<=2r and sum_i ti ti^T=d I_r.','First sentence')
n('center.square-mean-identity','A3.Ex118','unnamed exact source matrix moment','E Zi^2=E Yi^2-(E Yi)^2.','Equality clause')
n('center.square-PSD-comparison','A3.Ex118','source Loewner inequality','E Zi^2 <=PSD E Yi^2.','Final inequality clause')
n('center.variance-assertion','A3.SS2.p14.5','unnamed variance assertion','The Zi sequence has variance parameter at most the next v*.')
n('center.v','A3.Ex119','source scale definition','v*=2r(r+2)/d.')
n('weighted.variance-assertion','A3.SS2.p14.6','unnamed variance assertion','The same variance upper bound holds for cos(n theta_i)Zi.')
n('weighted.square-mean-identity','A3.Ex120','unnamed exact source moment','E[(cos(n theta_i)Zi)^2]=cos^2(n theta_i)E Zi^2.','Equality clause')
n('weighted.square-PSD-comparison','A3.Ex120','source Loewner inequality','cos^2(n theta_i)E Zi^2 <=PSD E Zi^2.','Final inequality clause')
x('bernstein.independence','A3.SS2.p15.1','unnamed source structural assertion','Both sequences are independent.','Independence is not a premise of the selected squared-mean algebra; no Bernstein or new independence credit.','Both sequences clause, independence')
n('bernstein.centered-context','A3.SS2.p15.1','unnamed source structural assertion','Both sequences are centered.','Both sequences clause, centered')
n('bernstein.self-adjoint-context','A3.SS2.p15.1','unnamed source structural assertion','Both sequences are self-adjoint.','Both sequences clause, self-adjoint')
x('bernstein.invocation','A3.SS2.p15.1','external/general inequality invocation','Two-sided bounded matrix Bernstein for t>0.','No concentration theorem is selected or claimed.','Final invocation clause')
x('bernstein.unweighted','A3.Ex121','source tail conclusion','P(||sum_i Zi||_op>t)<=2r^2 exp(-t^2/[2(v*+R*t/3)]).','Concentration/mainresult credit excluded.')
x('bernstein.weighted','A3.SS2.p15.2','source tail conclusion','Same tail bound for sum_i cos(n theta_i)Zi.','Concentration credit excluded.')

# Exhaustive source p/display coverage in the continuous original p1-through-p15 region.
wa,_=element('A3.SS2');_,wz=element('A3.SS2.p15');coverage=[]
for m in re.finditer(r'<(p|table)\b[^>]*\bid="([^"]+)"[^>]*>',S[wa:wz]):
 id=m[2];a,z=element(id);txt=plain(a,z);ats=[v['id'] for v in items if v['source_element_id']==id]
 if id=='A3.SS2.p4.1':ats.append('c5.theta-recall')
 if id=='A3.SS2.p10.1':ats+=['cutoff.L','cutoff.R','tail.A3.SS2.p10.m3']
 if id=='A3.SS2.p8.1':ats=['c5.t-norm-proof'];note='Pure Finally connective; estimate in Ex102.'
 elif txt=='∎':ats=[];note='Proof-end punctuation only.'
 elif id=='A3.Thmtheorem5.p1.1':ats=['c5.range','c5.Bmean','c5.weightedBmean'];note='Statement connective; Ex86 clauses separately disposed.'
 elif id=='A3.Thmtheorem5.p1.2':ats=['c5.t-norm','c5.t-Gram','c5.weighted-Gram'];note='Statement connective; Ex87 clauses separately disposed.'
 elif id=='A3.SS2.p13.2':ats=['norm.centered'];note='Hence connective; estimate is Ex112.'
 elif not ats:
  for v in items:
   if v['source_element_id'].startswith('A3.Ex'):
    x1,x2=element(v['source_element_id'])
    if a<=x1 and x2<=z:ats.append(v['id'])
  note='Display container covered by atomic display rows.'
 else:note='Every substantive clause disposed; remaining prose is connective.'
 assert ats or txt=='∎',id
 coverage.append({'element_id':id,'locator':loc(a,z),'atom_ids':list(dict.fromkeys(ats)),'note':note})
dump('atomic-inventory.json',{'phase':'RAW_ONLY_BEFORE_THIS_ACTOR_NEW_TYPE_EXPOSURE','scope':'Complete continuous original C.2 p1 through p15, plus S4.Thmtheorem4.p1.1 and S4.E11.m1 standing/experiment/grid context only.','items':items,'counts':{'atoms':len(items),'NODE':sum(v['disposition']=='NODE' for v in items),'EXCLUDED':sum(v['disposition']=='EXCLUDED' for v in items)},'admitted_graph':False})
dump('locators-and-source-units.json',{'source_sha256':sha(B),'convention':'Zero-based half-open UTF-8 byte and Unicode-codepoint ranges, one-based inclusive LF lines, raw unnormalized-fragment SHA256. Shared element locators have explicit semantic slices.','source_units':units})
dump('coverage.json',{'phase':'RAW_UNACCEPTED','window_locator':loc(wa,wz),'units':coverage,'unit_count':len(coverage),'whole_paper_coverage':False,'independent_mathematical_coverage_acceptance':False,
 'source_numbering_note':'Z is defined at p13. Ex113/Ex114, uncentered and centered/weighted variance assertions are p14. p15 applies Bernstein; only its centered/self-adjoint structural assertion is context here.','outside_window':'p16 onward and main lower bounds/uniform bounds remain outside the source window and target.'})

ports=[
 ('INTERNAL.actual-row-law','Apply the standard r-Gaussian marginal law and measurability to each actual original-column physical row under the same fixed canonical mu. No new sampling, ambient transfer or private canonical-row test imported as public provider.'),
 ('INTERNAL.actual-fourth-moment','Match/transport the source E[R_i gamma_i gamma_i^T]=(r+2)I_r, including its finite fourth-moment integrability, to the actual physical rows. Prior R4/R5 reports are context only; their exact applicability and public provider status remain unverified.'),
 ('INTERNAL.matrix-square-identity','Identify literal actual Yi matrix multiplication square with Ex114, using both rank-one square identities, Kronecker multiplication, indicator idempotence and exact inverse-d squared. No Hadamard square or wrong paired order.'),
 ('INTERNAL.square-integrability','Derive measurability/AEStrong measurability and integrability of actual Yi^2 and all needed untruncated fourth-moment/tensor majorants internally. The exact norm/integral carrier awaits the seal. No caller integrability/moment certificate.'),
 ('INTERNAL.PSD-drop-and-integral-order','Establish required self-adjointness/PSD of actual squares and the untruncated rank-one/tensor expression, then apply pointwise cutoff dropping, integral Loewner monotonicity and finite-sum order under discharged integrability. PSD is not entrywise nonnegativity.'),
 ('INTERNAL.fourth-moment-tensor-transport','Move deterministic feature tensors/scalars through the actual matrix expectation to use the actual Gaussian fourth moment, with exact r+2 and d^2.'),
 ('INTERNAL.literal-frame-and-bound','Apply source ||ti||^2<=2r and unweighted sum ti ti^T=dI_r to the literal half-grid, q=0 included. No supplied Gram/norm certificate or weighted-Gram premise.'),
 ('INTERNAL.aggregate-square-algebra','Combine exact Ex115–117 Loewner steps, nonnegative scalar factors, finite tensor sums and I_r tensor I_r=I_(r^2), deriving denominator positivity internally; obtain actual sum_i E Yi^2 <=PSD v*I.'),
 ('INTERNAL.actual-centering-and-integrability','Define Zi=Yi-E_mu Yi with the actual mean, derive needed Yi/Zi/Zi^2 integrability and centered expectation internally. Prior R8 is reported context only; do not supply means as caller data or assume private-test provider status.'),
 ('INTERNAL.noncommutative-centering-algebra','Expand (Y-M)^2 with both left and right cross terms, commute deterministic matrix multiplication through actual integrals under justified hypotheses, use M=E Y, and establish E Zi^2=E Yi^2-M^2. No commutativity certificate is a premise.'),
 ('INTERNAL.centered-PSD-order','Show the actual deterministic mean is self-adjoint and its square PSD, so E Zi^2<=PSD E Yi^2; aggregate and preserve source v*. PSD of expected centered squares is also internal.'),
 ('INTERNAL.weighted-square-and-order','For exact deterministic c_i=cos(n theta_i), derive weighted integrability/centering and E[(c_i Zi)^2]=c_i^2 E Zi^2<=PSD E Zi^2 using |c_i|<=1 and PSD of E Zi^2. Aggregate with the same v*, not a weighted-Gram cancellation.'),
 ('INTERNAL.variance-interpretation','If the future consumer expresses operator-norm variance, derive it from PSD/self-adjoint sum bounds under the exact matrix norm structure; source variance parameter is not a new premise. The exact sealed output form remains undecided.')]
dump('unaccepted-raw-ports.json',{'phase':'RAW_NOTES_ONLY_NO_TYPES_OR_GRAPH','ports':[{'id':id,'meaning':m,'status':'OPEN_INTERNAL_APPLICABILITY_OR_ALGEBRA','genuine_SOURCE_GAP':False,'compiled_parents':[]} for id,m in ports],
 'genuine_source_gaps_found':[],'definition':'Ordinary omitted source details, theorem applicability, integrability, matrix positivity and integral algebra are INTERNAL ports. No genuine source defect/missing source premise has been established by this raw reading.',
 'alternative_routes':'Bounded truncation or Gaussian fourth-moment domination may supply integrability; CLM or finite-entry matrix integral transport may supply bookkeeping. These unproved internal options are not an AND and are not source-authored alternative proofs.'})

dump('raw-source-use-observations.json',{'phase':'UNACCEPTED_PROSE_ONLY_NOT_A_GRAPH','observations':[
 {'use_site':'A3.SS2.p14.1 / Ex113','reading':'Gaussian fourth moments are invoked for the actual R_i gamma_i gamma_i^T mean; the following paragraph explains sign-symmetry/off-diagonal and3+(r-1) diagonal entries.'},
 {'use_site':'A3.SS2.p14.2 / Ex114','reading':'Both rank-one square identities feed the actual Yi^2 formula, preserving source cutoff and inverse-d squared.'},
 {'use_site':'A3.SS2.p14.3 / Ex115','reading':'Dropping the indicator is justified by a positive-semidefinite expression before applying the fourth-moment identity in the expectation sum.'},
 {'use_site':'A3.SS2.p14.4 / Ex116–117','reading':'The author explicitly uses ||ti||^2<=2r and the unweighted t Gram identity to obtain2r(r+2)/d times identity.'},
 {'use_site':'Ex118 / A3.SS2.p14.5 / Ex119','reading':'Actual mean centering subtracts (EYi)^2 from EYi^2, then uses the uncentered aggregate bound for v*.'},
 {'use_site':'A3.SS2.p14.6 / Ex120','reading':'The cosine factor squares deterministically and is bounded by1 in PSD order. Weighted Gram cancellation and independence are not invoked for this comparison.'},
 {'use_site':'A3.SS2.p15','reading':'The structural centered/self-adjoint assertion is source context; independence and the subsequent Bernstein tail theorem are excluded from the selected packet.'}],
 'implementation_use_not_observed':'No exact new formal type, implementation call, import graph or compiled parent was inspected.'})

write('raw-interpretation.md',r'''# Actual truncated-matrix second moments and centering: raw source reading

This is prospective prose selection only, frozen before this actor's first exposure to any new packet type/seal. It makes no statement about whether a global seal may exist elsewhere at freeze time. No new type, proof, graph or topology is formed, admitted or accepted here. Root remains the sole mathematical prover. All older R7/R8 artifacts remain untouched.

The source uses natural d,q with2q+1<d, r=q+1,n=2q+1 and the original independent standard d-Gaussian columns g_a. Each actual physical row gamma_i=((g_a)_i)_a has law N(0,I_r). The same canonical column-product experiment and its one fixed measure must be used throughout a future target. Row/column independence is not a premise needed for the per-row squared moments, finite mean sums or centering comparisons selected here.

The literal half-grid is theta_i=(i-1/2)pi/d, and t_i=(1,sqrt2cos(theta_i),...,sqrt2cos(q theta_i))^T. With L=2r+3log(1000d), R_i=||gamma_i||^2, the actual Yi is inverse-d times gamma_i gamma_i^T tensor t_i t_i^T times1_(R_i<=L). The cutoff includes equality and is local to the row; Gaussian coordinates precede feature coordinates in both paired matrix indices. No conditioning, common-event multiplier, surrogate rows or changed ambient model is allowed by the source formula.

Ex113 states the actual untruncated matrix fourth-moment identity E[R_i gamma_i gamma_i^T]=(r+2)I_r. Its source explanation uses sign symmetry for off-diagonal entries and diagonal3+(r-1). Ex114 is the literal matrix-product square of Yi, not an entrywise square: Yi^2=(R_i||ti||^2/d^2)(gamma_i gamma_i^T tensor ti ti^T)1_(R_i<=L). The author uses both rank-one square identities and the same indicator. Their formal applicability and integrability are not closed by this reading.

The uncentered prospective producer is actual Yi^2 integrability and the actual source Loewner sum bound sum_i E Yi^2 <=PSD [2r(r+2)/d]I_(r^2). Source Ex115 drops the cutoff from a PSD expression and uses Ex113. Ex116 uses ||ti||^2<=2r with nonnegative PSD factors. Ex117 uses sum_i ti ti^T=dI_r and tensor identity algebra. This is matrix PSD/Loewner order, not entrywise order. Source statements are not caller-supplied moment/PSD/Gram certificates.

The source defines Zi=Yi-EYi at p13, using the actual deterministic matrix mean. At Ex118, E Zi^2=E Yi^2-(EYi)^2<=PSD E Yi^2. The noncommutative expansion and integral algebra must be justified internally, including both cross terms; no commuting-matrix premise belongs in a future target. Self-adjointness/PSD and needed Yi,Zi,Zi^2 integrability and centering are likewise internal outputs/ports. An explicit formula for a or the first mean is not required to perform the centering algebra, and no prior private canonical-row test is assumed to be a public provider.

The same source v*=2r(r+2)/d bounds the centered variance. For c_i=cos(n theta_i), Ex120 states E[(c_i Zi)^2]=c_i^2 E Zi^2<=PSD E Zi^2. The cosine is deterministic and |c_i|<=1; positivity of E Zi^2 is part of the omitted internal order justification. Weighted Gram cancellation and independence are not needed for this inequality. A future private consumer can select exact centered/weighted sum-of-squared-mean PSD bounds and any required integrability/centering outputs. If it instead expresses an operator-norm variance bound, the PSD-to-norm equivalence requires its own internal applicability under the exact eventual norm instance. No final typed form is chosen here.

The raw source labels matter: p13 defines Z and gives R* norm estimates; p14 contains Ex113–120, the uncentered sum bound, centering comparison and weighted variance claim. p15 applies bounded matrix Bernstein. The complete p1–p15 window is inventoried, but R* estimates and the Bernstein tail conclusions are explicitly excluded. The p15 centered/self-adjoint structural assertion is retained only as source context for ordinary internal obligations. No concentration, tau/kappa restriction, main-result or independence credit is claimed.

q=0 remains in scope: r=1,n=1,t_i=(1),d>=2. The same scalar/1-by-1 specialization is intended, with source uncentered bound coefficient2*1*(1+2)/d=6/d; the loose source t-norm bound is retained without sharpening the constant. This is an interpretation check, not a proved estimate. Natural positivity and denominator facts must be internal, not additional binders.

Reported existing R4/R5/R8 canonical results are context only. No signature/body/import/lesson/audit was read here, no compiled parent is inferred from names, and no public-provider status is guessed. The notes distinguish internal law/fourth-moment applicability, matrix positivity, integral transport and algebra from genuine SOURCE_GAP. This bounded raw reading identifies no genuine source defect or missing source premise. All ports are unproved. A separate exact final seal and binder/definition packet is required before type audit and formal graph work.
''')

dump('input-exposure-protocol-chronology.json',{'actor':'/root/row_indep_source_graph_78c2','owned_output_root':str(BASE),'chronology':'This raw freeze occurs before this actor first reads any exact new variance-packet type/seal. It does not assert that the global seal has not been created elsewhere. No exact new types are present in this raw input.',
 'source_reads':'Fresh complete C.2 p1–p15 plus S4.Thmtheorem4.p1.1 and S4.E11.m1 from the exact original pinned HTML.',
 'protocol_inputs':inputs,'task_envelope_sha256':sha((OUT/'inputs/task-envelope.txt').read_bytes()),
 'actor_prior_exposure':'This actor previously saw R7/R8 source and selective types/own source graphs in earlier assignments. That history cannot be erased and no API-pristine/source-blind claim is made. Those prior artifacts were not reopened in this new raw variance phase.',
 'parent_reported_context':'R8 under independent normal verification; R4/R5/R8 canonical results reported existing. This is not a verifier verdict or compiled-parent grant and was not checked by reading old proofs/audits.',
 'no_new_target_implementation_API_or_type_exposure':True,'old_review_verdicts_or_other_graphs_read_this_phase':False,
 'changes':'Own new raw directory and builder only. No old R7/R8 writes, tracked C/L/registry/ledger/Git/shared mutation, new Goal, detached/background ASTIS, proof/status/permission grant.',
 'mathematical_role':'Source reader only; root is sole mathematical prover. All prospective ports are raw unproved notes.'})
write('README.md','RAW SOURCE READING ONLY before this actor new variance-type exposure. Start with raw-interpretation.md, atomic-inventory.json, locators-and-source-units.json, coverage.json and unaccepted-raw-ports.json. raw-source-use-observations.json is prose only, not an admitted graph. No type/graph/topology acceptance, proof or compiled-parent claim. Prior R7/R8 artifacts untouched.\n')
m={'format':'astis-matrix-variance-raw-source-freeze-v1','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'phase':'RAW_ONLY_BEFORE_THIS_ACTOR_NEW_TYPE_EXPOSURE','new_statement_seal_seen_by_this_actor':False,'global_seal_existence_not_asserted':True,'source_sha256':sha(B),'owned_source_root_full_path':str(BASE),'graph_or_topology_admitted':False,'files':[]}
for f in sorted(OUT.rglob('*')):
 if f.is_file():b=f.read_bytes();m['files'].append({'path':str(f.relative_to(OUT)),'bytes':len(b),'sha256':sha(b)})
dump('freeze-manifest.json',m);digest=sha((OUT/'freeze-manifest.json').read_bytes());write('freeze-manifest.sha256',digest+'  freeze-manifest.json\n')
for f in OUT.rglob('*'):
 if f.is_file():f.chmod(0o444)
for d in sorted([d for d in OUT.rglob('*') if d.is_dir()],key=lambda d:len(d.parts),reverse=True):d.chmod(0o555)
OUT.chmod(0o555)
print(json.dumps({'raw_freeze_path':str(OUT),'manifest_sha256':digest,'interpretation_sha256':sha((OUT/'raw-interpretation.md').read_bytes()),'inventory_sha256':sha((OUT/'atomic-inventory.json').read_bytes()),'locators_sha256':sha((OUT/'locators-and-source-units.json').read_bytes()),'coverage_sha256':sha((OUT/'coverage.json').read_bytes()),'ports_sha256':sha((OUT/'unaccepted-raw-ports.json').read_bytes()),'source_use_sha256':sha((OUT/'raw-source-use-observations.json').read_bytes()),'atoms':len(items),'NODE':sum(v['disposition']=='NODE' for v in items),'EXCLUDED':sum(v['disposition']=='EXCLUDED' for v in items),'continuous_units':len(coverage),'internal_ports':len(ports),'genuine_source_gaps':[]},indent=2))
