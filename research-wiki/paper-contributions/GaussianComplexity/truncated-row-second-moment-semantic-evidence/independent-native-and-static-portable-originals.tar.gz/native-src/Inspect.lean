import Tests.GaussianComplexityFixedSpectrumTruncatedRowMoment
import Lean.Util.CollectAxioms
import Lean.Util.FoldConsts
open Lean Elab Command
run_elab do
  let env ← getEnv
  for (n, c) in env.constants.toList do
    if n.toString.endsWith "actual_truncated_matrix_summand_mean" then
      logInfo m!"PRIVATE_NAME {n}"
      logInfo m!"PRIVATE_TYPE {c.type}"
