from pathlib import Path
import json,hashlib,gzip,subprocess,tarfile,shutil
sha=lambda raw:hashlib.sha256(raw).hexdigest()
b=Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-normalizer-semantic-evidence');private=Path('.astis/huanjian-fixed-spectrum-normalizer-20261108');checks=b/'actual-checks'
for p in sorted(Path('.astis/huanjian-resume-20261103').glob('*-fixed-spectrum-normalizer-*.receipt.json')):
 if (checks/p.name).exists():continue
 r=json.loads(p.read_bytes());raw=Path(r['log']).read_bytes();assert sha(raw)==r['log_sha256'];shutil.copy2(p,checks/p.name);z=checks/(Path(r['log']).name+'.gz');z.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(z.read_bytes())==raw
files=sorted(p for p in private.iterdir() if p.is_file());archive=b/'compiled-local-root-tools.lossless.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz') as t:
 for p in files:t.add(p,arcname=p.name,recursive=False)
with tarfile.open(archive,'r:gz') as t:
 for p in files:assert t.extractfile(p.name).read()==p.read_bytes()
manifest=b/'compiled-local-root-tools.manifest.json';manifest.write_text(json.dumps({'archive':str(archive),'sha256':sha(archive.read_bytes()),'all_members_roundtrip_verified':True,'files':[{'path':str(p),'member':p.name,'sha256':sha(p.read_bytes())} for p in files]},indent=2)+'\n')
paths=[p for root in [checks,b/'proof-attempts'] for p in root.rglob('*') if p.is_file()]
paths += [b/name for name in ['actual-consumer-interface/test-private-name-projection.json','anonymous-statement.txt','decoder-input.json','publication-draft-record.json','local-proof-capsule.json','normal-proved-local-preservation.json']]+[archive,manifest]
pack=b/'compiled-local-frozen-raw-packaging';pack.mkdir(exist_ok=False);safe=[];rows=[]
for p in paths:
 raw=p.read_bytes();tracked=subprocess.run(['git','ls-files','--error-unmatch','--',str(p)],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode==0;ignored=subprocess.run(['git','check-ignore','-q','--',str(p)]).returncode==0;binary=p.suffix in ['.gz','.zip','.png'] or b'\0' in raw;bad=not binary and (any(line.endswith((b' ',b'\t',b'\r')) for line in raw.split(b'\n')) or raw.endswith(b'\n\n'))
 if not tracked and (ignored or bad):
  z=pack/(str(len(rows)).zfill(3)+'-'+p.name+'.gz');z.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(z.read_bytes())==raw;rows.append({'original_path':str(p),'raw_sha256':sha(raw),'gzip_path':str(z),'gzip_sha256':sha(z.read_bytes()),'original_retained_unmodified':True});safe.append(z)
 else:safe.append(p)
manifest=pack/'manifest.json';manifest.write_text(json.dumps({'rule':'Lossless frozen-input packaging only; no originalnormalization/deletion. Mutablecanonicalpaths stageddirectly below.','files':rows},indent=2)+'\n');safe.append(manifest)
mutable=[Path(x) for x in ['AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumNormalizer.lean','Tests/GaussianComplexityFixedSpectrumNormalizer.lean','website/content/declaration_lessons/huanjian-fixed-spectrum-normalizer.json','website/content/publications/huanjian-fixed-spectrum-normalizer.json','research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-normalizer.json','research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-normalizer.json','runs/substantive_advances.jsonl','research-wiki/paper-contributions/GaussianComplexity/README.md']];safe += mutable;subprocess.run(['git','add','--',*[str(p) for p in safe]],check=True)
r=subprocess.run(['git','diff','--cached','--check'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT);print(r.stdout.decode());assert r.returncode==0
for p in mutable:assert subprocess.check_output(['git','show',':'+str(p)])==p.read_bytes()
print(json.dumps({'owned_paths_staged':len(safe),'frozen_raw_packaged':len(rows),'all8mutable_paths_exactly_staged':True,'sourceV':'pending','freshsource_phase1_and_otherrole_ongoing_files_not_staged':True}))
