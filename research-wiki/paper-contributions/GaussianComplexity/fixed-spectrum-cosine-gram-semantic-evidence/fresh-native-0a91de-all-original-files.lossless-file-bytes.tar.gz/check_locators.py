import json
from verify import *

m=json.loads((D/'inputs'/E/'source-to-lean-map-v1.json').read_text())
expected='1-based inclusive line numbers; a final LF belongs to the preceding line. Character offsets are 0-based Unicode code points of strict UTF-8 decode, before any newline normalization; end is exclusive. literalLF is exact and has no CR.'
assert m['locator_convention']==expected
loc=m['locator_slices']; assert len(loc)==57
data={}; inputs=[]; results=[]
for row in loc:
    path=row['file']
    if path not in data:
        if path.startswith('.lake/packages/mathlib/Mathlib/'):
            b=(R/path).read_bytes()
            put('inputs/'+path,b)
        else:
            assert path in [P,T,G]
            b=(D/'inputs'/path).read_bytes()
        data[path]=b
        inputs.append({'path':path,'bytes':len(b),'sha256':sha(b),'origin':'manifest-pinned clean mathlib' if path.startswith('.lake') else 'candidate Git blob'})
    b=data[path]; text=b.decode('utf-8',errors='strict')
    a,z=row['character_start_inclusive'],row['character_end_exclusive']
    ba,bz=row['byte_start_inclusive'],row['byte_end_exclusive']
    lit=row['literalLF']; actual=text[a:z]
    checks={
        'whole_file_sha256':sha(b)==row['raw_wholefile_sha256'],
        'strict_character_slice_literal':actual==lit,
        'character_length':len(lit)==row['character_length']==z-a,
        'byte_start':len(text[:a].encode('utf-8'))==ba,
        'byte_end':len(text[:z].encode('utf-8'))==bz,
        'byte_slice_literal':b[ba:bz]==lit.encode('utf-8'),
        'literal_sha256':sha(lit.encode())==row['exact_block_sha256'],
        'start_line':text.count('\n',0,a)+1==row['start_line_1based_inclusive'],
        'end_line_LF_preceding':text.count('\n',0,z-1)+1==row['end_line_1based_inclusive'],
        'no_CR_in_literal':'\r' not in lit,
        'line_convention':row['line_convention']==expected,
        'start_marker':text.startswith(row['start_marker'],a),
        'end_marker':text.startswith(row['end_marker'],z-len(row['end_marker']) if row['end_marker_included'] else z)
    }
    results.append({'slice_id':row['slice_id'],'file':path,'checks':checks,'pass':all(checks.values())})
js('locator-check-inputs.json',inputs)
js('locator-check-results.json',{'candidate':C,'convention':expected,'count':len(results),'passed':sum(x['pass'] for x in results),'results':results})
print(json.dumps({'count':len(results),'passed':sum(x['pass'] for x in results),'failed':[x for x in results if not x['pass']]},indent=2))
assert all(x['pass'] for x in results)
