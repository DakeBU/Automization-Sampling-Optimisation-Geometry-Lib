
def scroll_center(locator):
    locator.evaluate("""async el=>{
      el.scrollIntoView({behavior:'instant',block:'center',inline:'nearest'});
      await new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)));
    }""")

def core_label_readable(g):
    return (g['positiveSVGClippedIntersection'] and g['intersectionFraction']>=.98
            and g['labelVisibleFraction']>=.95 and g['effectiveFontPx']>=12
            and g['labelIntersection']['width']>=min(80,g['labelRect']['width'])
            and g['labelIntersection']['height']>=min(12,g['labelRect']['height']))

def zoom_pan_actual_ui(page,node):
    import math
    svg=page.locator('[data-graph-svg]')
    before=node.evaluate(GEOMETRY)
    scroll_center(svg);page.wait_for_timeout(120)
    interactions=[]
    def pan(force=False):
        g=node.evaluate(GEOMETRY);c=g['clip'];n=g['node']
        if c['width']<=40 or c['height']<=40:raise RuntimeError('No usable actual clipped SVG area')
        dx=(c['left']+c['right'])/2-(n['left']+n['right'])/2
        dy=(c['top']+c['bottom'])/2-(n['top']+n['bottom'])/2
        if abs(dx)<1 and abs(dy)<1:
            if not force:return False
            dx=8;dy=0
        point=svg.evaluate("""(el,c)=>{
          const xs=[c.left+12,c.right-12,(c.left+c.right)/2],ys=[c.top+12,c.bottom-12,(c.top+c.bottom)/2];
          for(const y of ys)for(const x of xs){const h=document.elementFromPoint(x,y);
            if(h&&h.closest('[data-graph-svg]')===el&&!h.closest('.ulg-node'))return{x,y};}
          return null;
        }""",c)
        if point is None:raise RuntimeError('No native SVG background pointer target')
        dx=max(c['left']+4-point['x'],min(c['right']-4-point['x'],dx))
        dy=max(c['top']+4-point['y'],min(c['bottom']-4-point['y'],dy))
        page.mouse.move(point['x'],point['y']);page.mouse.down()
        page.mouse.move(point['x']+dx,point['y']+dy,steps=10);page.mouse.up();page.wait_for_timeout(80)
        interactions.append({'native_pointer':{'start':point,'dx':dx,'dy':dy},'center_basis':'actual clipped SVG area'})
        return True
    for i in range(10):
        if not pan(force=i==0):break
    for i in range(12):
        g=node.evaluate(GEOMETRY);font=g['effectiveFontPx']
        if i and 12.5<=font<=14.5:break
        delta=-1000*math.log(13/max(font,.1))
        delta=max(-500,min(500,delta))
        if abs(delta)<25:delta=-25
        c=g['clip'];n=g['node']
        x=max(c['left']+8,min(c['right']-8,(n['left']+n['right'])/2))
        y=max(c['top']+8,min(c['bottom']-8,(n['top']+n['bottom'])/2))
        page.mouse.move(x,y);page.mouse.wheel(0,delta);page.wait_for_timeout(100)
        interactions.append({'native_wheel':{'x':x,'y':y,'deltaY':delta}})
    for _ in range(10):
        if not pan():break
    after=node.evaluate(GEOMETRY)
    return {'default_fit_before_scroll':before,'after_native_UI':after,'interactions':interactions,
            'native_pointer_and_wheel_exercised':any('native_pointer' in x for x in interactions) and any('native_wheel' in x for x in interactions),
            'core_label_readable_inside_actual_SVG_clip':core_label_readable(after),
            'direct_SVG_transform_or_node_style_writes':False,
            'long_SVG_label_may_remain_ellipsized_full_ID_uses_detail':True}

GLYPH=r'''async (el,mode)=>{
  const frames=()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)));
  const headerBottom=()=>{let bottom=0;const hs=[...document.querySelectorAll('header,.mobile-bar,.verification-strip')];
    for(let pass=0;pass<hs.length+1;pass++)for(const h of hs){const s=getComputedStyle(h),r=h.getBoundingClientRect();
      if(['fixed','sticky'].includes(s.position)&&s.display!=='none'&&s.visibility!=='hidden'&&r.width>0&&r.height>0&&r.right>0&&r.left<innerWidth&&r.bottom>0&&r.top<=bottom+1)bottom=Math.max(bottom,r.bottom);}
    return bottom;};
  el.scrollIntoView({behavior:'instant',block:'center',inline:'nearest'});await frames();
  let line=el.getBoundingClientRect(),header=headerBottom();
  if(line.top<header+8)window.scrollBy({top:line.top-header-12,left:0,behavior:'instant'});
  else if(line.bottom>innerHeight-8)window.scrollBy({top:line.bottom-innerHeight+12,left:0,behavior:'instant'});
  await frames();
  const p=el.closest('pre'),text=el.firstChild,raw=text.textContent,end=raw.trimEnd().length;
  let start=Math.max(0,end-1);
  if(start>0&&raw.charCodeAt(start)>=0xDC00&&raw.charCodeAt(start)<=0xDFFF&&raw.charCodeAt(start-1)>=0xD800&&raw.charCodeAt(start-1)<=0xDBFF)start--;
  const range=document.createRange();range.setStart(text,start);range.setEnd(text,end);
  if(mode==='rightmost')p.scrollLeft=p.scrollWidth-p.clientWidth;
  else{p.scrollLeft=0;let r=range.getBoundingClientRect(),b=p.getBoundingClientRect();if(r.right>b.right-4)p.scrollLeft+=r.right-b.right+8;}
  await frames();const r=range.getBoundingClientRect(),b=p.getBoundingClientRect();line=el.getBoundingClientRect();header=headerBottom();
  const clip={left:Math.max(0,b.left+p.clientLeft),right:Math.min(innerWidth,b.left+p.clientLeft+p.clientWidth),top:Math.max(header+4,b.top),bottom:Math.min(innerHeight-4,b.bottom)};
  for(let a=p.parentElement;a;a=a.parentElement){const s=getComputedStyle(a),q=a.getBoundingClientRect();
    if(['hidden','clip','scroll','auto'].includes(s.overflowX)){clip.left=Math.max(clip.left,q.left+a.clientLeft);clip.right=Math.min(clip.right,q.left+a.clientLeft+a.clientWidth);}
    if(['hidden','clip','scroll','auto'].includes(s.overflowY)){clip.top=Math.max(clip.top,q.top+a.clientTop);clip.bottom=Math.min(clip.bottom,q.top+a.clientTop+a.clientHeight);}}
  return {lineId:el.id,sourceTextLengthUTF16:raw.length,selectedGlyphStartUTF16:start,selectedGlyphEndUTF16:end,
    selectedGlyph:raw.slice(start,end),codePoints:Array.from(raw.slice(start,end),c=>c.codePointAt(0)),trailingWhitespaceCodeUnitsSkipped:raw.length-end,
    glyph:{left:r.left,right:r.right,top:r.top,bottom:r.bottom,width:r.width,height:r.height},
    container:{left:b.left,right:b.right,width:p.clientWidth,scroll:p.scrollLeft,max:p.scrollWidth-p.clientWidth,overflow:getComputedStyle(p).overflowX},
    headerBottom:header,viewportHeight:innerHeight,actualVisibleClip:clip,
    visible:r.width>0&&r.height>0&&r.left>=clip.left-1&&r.right<=clip.right+1&&r.top>=clip.top&&r.bottom<=clip.bottom,
    lineVisible:line.height>0&&line.top>=clip.top&&line.bottom<=clip.bottom};
}'''
