from pathlib import Path
import copy, datetime, gzip, hashlib, json, re, shutil, subprocess, sys
sys.path.insert(0, 'tools')
import astis_advance as advance
import astis_publication as pub
import astis_semantic_roundtrip as rt

P = Path('.astis/huanjian-gc-fixed-spectrum-geometry-20261109')
B = Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-geometry-semantic-evidence')
N = Path('.astis/semantic-neutral-20261109/91f0b8e4')
HEAD = '64497b461fb21c190f9c61bbd9a49db0894e1ad9'
ADV = 'ASTIS-SA-20261109-GaussianComplexityFixedSpectrumGeometry'
OWNER = 'huanjian_gc_20261109_fixed_spectrum_geometry'
DECL = 'AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumGeometry.actual_potential_geometry'
CELL = Path('research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-geometry.json')
PROD = Path('AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumGeometry.lean')
TEST = Path('Tests/GaussianComplexityFixedSpectrumGeometry.lean')
AP = Path('research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-geometry.json')
sha = lambda b: hashlib.sha256(b).hexdigest()
dump = lambda x: (json.dumps(x, ensure_ascii=False, indent=2)+'\n').encode()
canon = lambda x: json.dumps(x, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()
def put(p, x):
    assert not p.exists(), p
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(dump(x))
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == HEAD
assert sha(PROD.read_bytes()) == 'd7edd1684006382e7e51ff717b5a9b82308181538ae824598961604dacea08d6'
assert sha(TEST.read_bytes()) == 'c6f90cc8ad43182a81e8b4343b28fff34e4fc81bc2e181d91002f3005a463b88'
models = {x: sha(Path(x).read_bytes()) for x in [
    'website/content/graph_memory_index.json', 'website/content/functor_hypergraph.json',
    'runs/substantive_discoveries.jsonl']}
assert models['website/content/graph_memory_index.json'] == 'e72359bd0ecec17d101cb28c0a3162f8f9cda625b2bcf698f0e68b40a116d01b'
assert models['website/content/functor_hypergraph.json'] == 'c67be70d121fdfb29a15124e1fc964342902cabf25ac009c607cc5485fc2ed98'
packet = json.loads((N/'input.json').read_bytes())
assert sha((N/'input.json').read_bytes()) == '8d5272bf8887939c011f79a074ee153bc9df882ec4f8e107bfaa3cad4eccc5dd'
assert sha(canon({k:v for k,v in packet.items() if k != 'packet_sha256'})) == packet['packet_sha256'] == 'c196feaa2f8da545f1e8774785a51e6d59d26e4b43dc1229f7975516b4877e16'
mf = N/'hash-manifest.json'
assert sha(mf.read_bytes()) == '56d645690085ff8a5c9ec5819210832ca87fe5ec5247dd740ac941f2796b4354'
for row in json.loads(mf.read_bytes())['outputs']:
    raw = (N/row['relative_path']).read_bytes()
    assert len(raw) == row['bytes'] and sha(raw) == row['sha256']
recon = json.loads((N/'reconstruction.json').read_bytes())
run = json.loads((N/'decoder-run.json').read_bytes())
text = (N/'reconstructed-theorem.md').read_text()
assert recon['reconstructed_theorem_text'].encode() == text.encode()
assert sha(text.encode()) == recon['reconstructed_text_sha256']
assert recon['decoder_run_sha256'] == sha((N/'decoder-run.json').read_bytes())
assert not run['source_text_visible'] and not run['source_identity_visible'] and not run['prior_verdicts_visible']
assert all(isinstance(recon[k], str) and recon[k] for k in ['objects','domains','quantifiers','assumptions','conclusion','scopes','constant_dependencies'])
dest = B/'blind-80a1c2'
assert not dest.exists()
shutil.copytree(N, dest)
for q in N.rglob('*'):
    if q.is_file(): assert (dest/q.relative_to(N)).read_bytes() == q.read_bytes()
a = json.loads(AP.read_bytes())
assert a['state'] == 'draft' and rt.decoder_packet(a) == packet
put(B/'pre-blind-adoption-audit.json', a)
a['reconstruction'] = {
    'text': text, 'text_sha256': sha(text.encode()), 'decoder': recon['decoder'],
    'decoder_run_sha256': recon['decoder_run_sha256'], 'decoder_packet_sha256': packet['packet_sha256'],
    'source_text_visible': False, 'lean_statement_sha256': a['lean']['statement_sha256'],
    'input_artifacts': packet['input_artifacts'], 'run_artifact': str(dest/'decoder-run.json'),
    'ambient_exposure_record': str(dest/'decoder-run.json')+'#/ambient_cues_disclosed',
    'ambient_identity_cues_disclosed': True,
    'current_source_title_version_anchor_or_target_declaration_explicitly_supplied': False}
a['state'] = 'blind-reconstructed'
AP.write_bytes(dump(a))
assert rt.decoder_packet(a) == packet
assert a['publication_binding_sha256'] == '69c4f115a417c0aea6a8ebc9384cfc66ff07e6fae92de806831b79075a4760fa'
pub.check_advance([DECL], reviewed=False)

labels = [
    'fixed-spectrum-geometry-proof-v1', 'fixed-spectrum-geometry-proof-v2',
    'fixed-spectrum-geometry-proof-v3', 'fixed-spectrum-geometry-actual-production-and-Borel-consumer',
    'fixed-spectrum-geometry-actual-Borel-consumer-notation-scope',
    'fixed-spectrum-geometry-kernel-and-exact-meaning',
    'fixed-spectrum-geometry-kernel-and-exact-meaning-scaffold-v2']
checks = []
for label in labels:
    paths = list(Path('.astis/huanjian-resume-20261103').glob('*-'+label+'.receipt.json'))
    assert len(paths) == 1, label
    p = paths[0]; r = json.loads(p.read_bytes())
    assert r['head_before'] == r['head_after'] == HEAD
    assert sha(Path(r['log']).read_bytes()) == r['log_sha256']
    checks.append({'receipt': str(p), 'receipt_sha256': sha(p.read_bytes()), 'raw_log_sha256': r['log_sha256'],
                   'exit_code': r['exit_code'], 'actual_elapsed_seconds': r['elapsed_seconds']})
assert [r['exit_code'] for r in checks] == [1,1,0,1,0,1,0]
focus = Path(json.loads(Path(checks[4]['receipt']).read_bytes())['log']).read_text()
kernel = Path(json.loads(Path(checks[6]['receipt']).read_bytes())['log']).read_text()
assert focus.count('depends on axioms: [propext,') == 2 and 'sorryAx' not in focus
assert kernel.count('ACTUAL_ASTIS_PARENT ') == 5
assert 'Exact sealed full-forall producer application and literal private-consumer type application checked.' in kernel
for q in [PROD, TEST]:
    assert not re.search(r'\b(sorry|admit|sorryAx)\b|^\s*(axiom|unsafe)\b|Prop\s*:=\s*True|:=\s*trivial\b', q.read_text(), re.M)
parents = [
    'AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumAdmissibility.actual_precision_admissible',
    'AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumFirstOrder.actual_first_order_query',
    'AutoSamplingTheory.TechnicalLemmas.Analysis.StrongConvexGradientConverse.strongConvexOn_of_gradient_inner_lower_bound']
mirror = {
    'status': 'none-found', 'discovery_ids': [],
    'reason': 'Postproof audit of the actual compiled proof: this packet reuses the SAME existing Euclidean gradient-monotonicity converse, actual admissibility and actual first-order declarations. PSD/Rayleigh and continuous-to-Borel are ordinary canonical library applications in the same Euclidean carrier. No new change-of-space, metric, energy, oracle, discrepancy or hypothesis/conclusion transport was proved or proposed. Existing curvature-growth and Gaussian oracle-factorization mechanisms already retain their distinct hypotheses and failure boundaries. The fixed-input Borel consumer does not create an adaptive/target/TV/cost bridge. Do not duplicate these canonical nodes or invent a cross-domain transport edge for a specialization.',
    'examined': ['Libraries/conceptual-mirror-protocol.json', 'Libraries/frontloaded-shared-spine.json',
                 'website/content/graph_memory_index.json#/families/family:curvature-growth',
                 'website/content/functor_hypergraph.json#transport:curvature-growth',
                 'website/content/functor_hypergraph.json#transport:gaussian-quadratic-oracle-factorization',
                 'AutoSamplingTheory/TechnicalLemmas/Analysis/StrongConvexGradientConverse.lean',
                 str(PROD), str(TEST)],
    'shared_models_changed': False, 'formal_implication_from_conceptual_analogy': False}
put(B/'postproof-conceptual-mirror-audit.json', mirror)
mapping = {
    'G.angle': 'Author strict angle/cosine prefix remains an unproved alternate source route in this packet; no new credit. Canonical admissibility supplies the closed envelope actually used.',
    'G.symmetry': 'Canonical actual_precision_admissible.1.1; mapped to actual H.IsSymmetric.',
    'G.orthogonalnorm_and_G.conjugation_and_G.membership': 'The actual closed lower/upper matrix certificates are reused from canonical admissibility, not reproved or replaced by caller assumptions. Local hquad/hlower/hupper convert the produced certificates into the exact Euclidean quadratic inequalities.',
    'G.polynomial': 'hf identifies the same literal function; hcinfty constructs ContDiff infinity via canonical continuous-linear-map and inner-product calculus.',
    'G.derivatives_and_G.actualoracleidentification': 'Canonical actual_first_order_query produces genuine HasGradientAt. hg uses existence to recover the total gradient; hhessian proves actual gradient derivative H at every point.',
    'G.hessiancriteria': 'Author generic Hessian criterion remains distinct. Implementation sufficient alternative: SAME canonical strongConvexOn_of_gradient_inner_lower_bound plus produced hgrad and hlower. Norm estimate uses actual symmetric H and Rayleigh supremum with explicit zero case. No extra Hessian/regularity premise.',
    'origin_minimizer': 'hzero, hnonneg and hpositive from actual half-quadratic and lower bound, then global IsMinOn biconditional; existence and uniqueness are outputs.',
    'G.oraclecontinuous_and_G.oracleborel': 'Private Test genuinely consumes new scalar smoothness and gradient-derivative output, identifies the same query with actual gradient via canonical FirstOrder, and applies Continuous.borel_measurable to the ordered pair. Fixed O only; joint/adaptive model not closed.'}
capsule = {
    'recorded_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'state': 'ACTUAL_LOCAL_GEOMETRY_AND_BOREL_CONSUMER_COMPILED_INDEPENDENT_SOURCE_REVIEW_PENDING',
    'immutable_preproof_admission_commit': HEAD,
    'source_raw_sha256': '6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915',
    'producer': DECL, 'production_raw_sha256': sha(PROD.read_bytes()), 'Test_raw_sha256': sha(TEST.read_bytes()),
    'actual_direct_ASTIS_producer_parents': parents,
    'actual_direct_ASTIS_private_consumer_parents': [DECL, parents[1]],
    'source_gap_implementation_map': mapping, 'actual_checks_including_failed_predecessors': checks,
    'focused_success_receipt': checks[4], 'kernel_and_exact_statement_success_receipt': checks[6],
    'standard_axioms_only': ['propext', 'Classical.choice', 'Quot.sound'],
    'failure_class': 'IMPLEMENTATION_FAILED',
    'salvage': {'status': 'completed', 'reason': 'No failed mathematical target or extra assumption. V1/v2 proof API and namespace issues were repaired in v3; actual producer compiled while first Test annotation lacked ContDiff notation scope, then corrected without signature change. First meta inspector used a reserved identifier/quotation scaffold and was corrected. Raw candidates, error logs, exact compiler error-recovery output and successful Std3 logs are retained; failed recovery sorryAx is not an authored or accepted proof.', 'discarded_mathematics': [], 'promoted_fragments': ['Actual v3 proof materialized as canonical production module; actual private consumer corrected notation scope only.']},
    'exact_meaning_applications': 'Actual compiled full-forall public anonymous proposition and private literal sealed consumer type both applied successfully in kernel inspector v2.',
    'conceptual_mirror_audit': mirror, 'publication_binding_sha256': a['publication_binding_sha256'],
    'sourceV_or_wholeGoal': False,
    'truth_boundary': 'Selected literal actual C4 geometry and real fixed-input Borel reply consumer only. Independent source/whole-module/freshLean/static reader and later root/site/graph/desktop-mobile/immutable integration acceptance remain pending. Source strict-grid author prefix, joint hidden-input/adaptive/seed/history/output-law, Gaussian/TV/precision adapters, deterministic worst-query caps, explicit expected-cost comparison, both main lower bounds, remote owner release/delivery and postmerge purification/Exposition Seal remain separate.'}
put(B/'local-proof-capsule.json', capsule)
cell = json.loads(CELL.read_bytes())
cell['evidence']['preproof_phase_history'] = {'execution_boundary': cell['evidence']['execution_boundary'], 'source_detail_gap': cell['source_detail_audit']['gap'], 'old_statement_seal_status': cell['statement_seal']['status']}
cell['status'] = 'proved_locally'
cell['statement_seal']['status'] = 'EXACT_PRODUCER_AND_ACTUAL_CONSUMER_COMPILED_POSTPROOF_REVIEW_PENDING'
cell['evidence']['execution_boundary'] = capsule['truth_boundary']
cell['evidence']['local_proof_capsule'] = str(B/'local-proof-capsule.json')
cell['evidence']['actual_compiled_producer_parents'] = parents
cell['evidence']['actual_compiled_private_consumer_parents'] = capsule['actual_direct_ASTIS_private_consumer_parents']
cell['evidence']['publication_binding_sha256'] = a['publication_binding_sha256']
cell['evidence']['focused_checks'] = [checks[4]['receipt'], checks[6]['receipt']]
cell['source_detail_audit']['gap'] = 'Selected literal actual geometry and real fixed-input Borel consumer locally discharged; source author strict-grid/Hessian-criterion route remains distinct and unclaimed. Independent whole-module/source/freshLean/static reader review pending. Joint/adaptive/precision/TV/cap/cost/main lower bounds remain separate.'
cell['source_detail_audit']['fidelity_boundary'] = capsule['truth_boundary']
cell['source_proof_coverage']['current_implementation_mapping'] = str(B/'local-proof-capsule.json')+'#/source_gap_implementation_map'
cell['source_proof_coverage']['original_open_obligations_are_preproof_history'] = True
cell['reuse_plan']['reused_declarations'] = parents
cell['reuse_plan']['known_consumers'] = ['Actual compiled private same-A/f/query Borel consumer in '+str(TEST)+'; actual kernel parents are the new geometry producer and canonical FirstOrder.']
cell['shared_floor_audit']['postproof_actual_reuse'] = parents
cell['conceptual_mirror_audit'] = mirror
cell['learning_contract']['failure_class'] = 'IMPLEMENTATION_FAILED'
cell['learning_contract']['salvage'] = {'required': True, 'status': 'completed', 'reason': capsule['salvage']['reason'], 'promoted_fragments': capsule['salvage']['promoted_fragments'], 'discarded_fragments': []}
states = advance.current_advances()
assert states[ADV]['state'] == 'EXPLORING' and not any(v['state'] == 'STABILIZING' for v in states.values())
foreign = {str(q):sha(q.read_bytes()) for q in CELL.parent.glob('*.json') if q != CELL}
ledger = Path('runs/substantive_advances.jsonl'); before = ledger.read_bytes()
assert sha(before) == '232b5169052a286744cc2b252e36d73f943e69add8276a3fc85173ac6164aed5'
(B/'before-PLOC-ledger.raw.jsonl.gz').write_bytes(gzip.compress(before, mtime=0))
CELL.write_bytes(dump(cell))
advance.transition_advance(ADV, 'PROVED_LOCAL', worker_id=OWNER, evidence={
    'theorem_delta': 'Actual literal fixed-spectrum C-infinity, genuine gradient derivative,1-strong convexity,kappa-gradient bound,zero minimum uniquely at origin; genuine fixed-input actual Borel reply consumer.',
    'result_kind': 'theorem-edge', 'lean_files': [str(PROD),str(TEST)],
    'lean_declarations': [DECL], 'publication_declarations': [DECL],
    'focused_checks': [checks[4],checks[6]], 'truth_boundary': capsule['truth_boundary'],
    'conceptual_mirror_audit': mirror, 'local_proof_capsule': str(B/'local-proof-capsule.json'),
    'source_review': 'Pending independent anti-anchored review; root does not mark VERIFIED.'})
after = ledger.read_bytes(); now = advance.current_advances()
assert after.startswith(before) and len(after[len(before):].splitlines()) == 1
assert all(now[k] == v for k,v in states.items() if k != ADV)
assert foreign == {str(q):sha(q.read_bytes()) for q in CELL.parent.glob('*.json') if q != CELL}
assert models == {x:sha(Path(x).read_bytes()) for x in models}
put(B/'normal-PROVED_LOCAL-preservation.json', {
    'normal_state': now[ADV]['state'], 'before_ledger_sha256': sha(before), 'after_ledger_sha256': sha(after),
    'append_sha256': sha(after[len(before):]), 'old_prefix_preserved': True,
    'foreign_states_preserved': len(states)-1, 'foreign_raw_frontiers_preserved': len(foreign),
    'discovery_and_shared_models_unchanged': models, 'sourceV_or_integration_or_Goal_complete': False})
readme = B.parent/'README.md'; old = readme.read_bytes()
(B/'README-before-PLOC.raw.md.gz').write_bytes(gzip.compress(old, mtime=0))
readme.write_bytes(('## 2026-11-09: actual fixed-spectrum geometry and Borel consumer PROVED_LOCAL\n\nThe literal source quadratic is globally C-infinity with actual gradient derivative A,1-strong convexity,kappa-gradient Lipschitzness and zero value uniquely minimized at the origin. The real private fixed-input Borel reply consumer materially uses new scalar smoothness and gradient derivative, then canonical actual gradient identification. Exact original signatures, actual3 producer/2 Test kernel parents and only the standard three axioms are compiled. Canonical reuse replaces no source premise; the author strict-grid/Hessian-criterion route is separately retained. Independent anonymous decoding completed with ambient cues disclosed. Fresh anti-anchored source/whole-module/freshLean/static reader review remains pending.\n\nNormal API marked PROVED_LOCAL only; root issued no sourceV. Postproof conceptual audit found no new transport mechanism beyond canonical Euclidean parents and existing typed families; models/discoveries are unchanged. Same foreground Goal and every prior state/frontier/queue/result remain. Root/site/graph/desktop-mobile and immutable integration, joint/adaptive/oracle/precision/TV/deterministic cap/expected-cost adapters, both main lower bounds, remote owner release/delivery and postmerge purification/Exposition Seal remain separate.\n\n').encode()+old)
print(json.dumps({'state':now[ADV]['state'], 'actual_ASTIS_parents_producer':3, 'actual_ASTIS_parents_private_consumer':2, 'blind_reconstruction_verified':True, 'foreign_states_preserved':len(states)-1, 'foreign_raw_frontiers_preserved':len(foreign), 'ledger_sha256':sha(after), 'sourceV':False}))
