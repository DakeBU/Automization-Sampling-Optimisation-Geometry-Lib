"""Execute at most one normal V after final evidence judgment and explicit ROOT readiness."""
import copy, datetime, json, os, stat, subprocess, sys, traceback
from guard import *
from evidence_preflight import E,HELD,PL_SHA,PL_APPEND_SHA

def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def own_events():
    raw,records = clean_records(L)
    own = [r for r in records if r.get('advance_id') == ADV]
    return raw,[r for r in own if r.get('to_state') == 'PROVED_LOCAL'],[r for r in own if r.get('to_state') == 'VERIFIED']

def main():
    started = now()
    payload_raw = (O/'VERIFIED-evidence.full.json').read_bytes(); payload = json.loads(payload_raw)
    ready = read(O/'ROOT-READY.received.json')
    assert ready['held_HEAD'] == payload['verified_commit'] == HELD
    assert ready['authorized_actor'] == payload['verifier_id'] == VERIFIER
    assert ready['at_most_one_normal_VERIFIED_API_call'] is True
    assert read(O/'final-reader-and-package-check.bounded.json')['status'] == 'PASS'
    assert read(O/'expression-evidence-crosscheck.bounded.json')['status'] == 'PASS'
    original = read(E/'actual-PROVED_LOCAL-evidence.full.json')
    assert sha((E/'actual-PROVED_LOCAL-evidence.full.json').read_bytes()) == PL_SHA
    assert len(original) == 26 and all(payload[k] == v for k,v in original.items())
    raw,pls,vs = own_events()
    assert len(pls) == 1 and not vs and pls[0]['evidence'] == original, 'prior transition exists; inspect, never replay'
    marker = O/'normal-VERIFIED-call.once.json'
    assert not marker.exists(), 'once marker exists; inspect actual ledger rather than retry'
    held_guard = check_snapshot('held-preflight',after=False)
    old_guard = historical('PROVED_LOCAL')
    fresh = snapshot('before-normalV',HELD)
    create(O/'before-normalV-preservation.bounded.json',dump({
        'status':'PASS','held_guard':held_guard,'historical_guard':old_guard,'fresh_private_snapshot':fresh,
        'full_private_maps_exported':False}))
    raw2,pls2,vs2 = own_events()
    assert raw2 == raw and len(pls2) == 1 and not vs2
    current = read(ROOT/C); candidate = read(O/'candidate-cell.exact.json')
    assert current['status'] == 'proved_locally' and current['owner_id'] == candidate['owner_id'] == OWNER
    assert candidate['status'] == 'independently_verified'
    assert isinstance(candidate['evidence']['independent_verification'],str) and candidate['evidence']['independent_verification']
    assert candidate['evidence']['independent_verification_details'] == payload
    assert all(candidate['evidence'][k] == v for k,v in current['evidence'].items())
    assert all(candidate[k] == v for k,v in current.items() if k not in ['status','evidence'])
    create(O/'cell-before.exact.json',(ROOT/C).read_bytes())
    create(marker,dump({'created_at':now(),'verifier_id':VERIFIER,'advance_id':ADV,
        'held_HEAD':HELD,'from_state':'PROVED_LOCAL','to_state':'VERIFIED',
        'payload_sha256':sha(payload_raw),'before_ledger_sha256':sha(raw),'normal_API_calls_authorized':1,
        'rule':'Exclusive marker prevents replay. Inspect actual state and exact suffix even after an exception.'}),private=True)
    api_started = now(); error = None
    try:
        astis_advance.transition_advance(ADV,'VERIFIED',worker_id=VERIFIER,
            modes=['independent-verification'],evidence=payload,path=ROOT/L,discovery_path=ROOT/D)
    except BaseException as exc:
        error = {'type':type(exc).__name__,'message':str(exc),'traceback':traceback.format_exc()}
    afterraw,afterpls,aftervs = own_events()
    suffix = afterraw[len(raw):] if afterraw.startswith(raw) else b''
    create(O/'normal-API.receipt.json',dump({'started_at':api_started,'ended_at':now(),
        'api':'astis_advance.transition_advance','calls':1,'advance_id':ADV,'to_state':'VERIFIED',
        'worker_id':VERIFIER,'held_HEAD':HELD,'exception':error,'ledger_prefix_preserved':afterraw.startswith(raw),
        'PL_count_after':len(afterpls),'VERIFIED_count_after':len(aftervs),
        'suffix_lines':len(suffix.splitlines()),'suffix_sha256':sha(suffix),'never_retry':True}))
    assert afterraw.startswith(raw) and suffix.endswith(b'\n') and len(suffix.splitlines()) == 1, 'inspect actual outcome; no replay'
    event = json.loads(suffix)
    assert len(afterpls) == len(aftervs) == 1 and event in aftervs
    assert event['evidence'] == payload and event['worker_id'] == VERIFIER
    # The normal API does not write C. Complete exactly the reviewed own-cell bytes.
    mode = stat.S_IMODE((ROOT/C).lstat().st_mode)
    temporary = (ROOT/C).with_suffix('.verifier-91dc.tmp')
    create(temporary,(O/'candidate-cell.exact.json').read_bytes())
    temporary.chmod(mode); os.replace(temporary,ROOT/C)
    old_after = historical('VERIFIED'); exact_after = check_snapshot('before-normalV',payload,after=True)
    create(O/'after-normalV-preservation.bounded.json',dump({'status':'PASS',
        'historical_guard':old_after,'fresh_guard':exact_after,'owner_retained':read(ROOT/C)['owner_id'],
        'full_private_maps_exported':False}))
    command_dir = O/'commands/postwrite-frontier'; command_dir.mkdir(parents=True,exist_ok=False)
    argv = [sys.executable,'tools/astis_frontier_cells.py','check']; began = now()
    result = subprocess.run(argv,cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    create(command_dir/'stdout',result.stdout); create(command_dir/'stderr',result.stderr)
    create(command_dir/'receipt.json',dump({'argv':argv,'started_at':began,'ended_at':now(),
        'exit_code':result.returncode,'held_HEAD':git('rev-parse','HEAD').decode().strip(),
        'stdout_sha256':sha(result.stdout),'stderr_sha256':sha(result.stderr),
        'schema_script_sha256':sha((ROOT/'tools/astis_frontier_cells.py').read_bytes())}))
    assert result.returncode == 0, 'postwrite frontier schema failed; do not replay V'
    final = read(ROOT/C)
    assert all(final['evidence']['independent_verification_details'][k] == v for k,v in original.items())
    outcome = {'status':'VERIFIED_LOCAL_ONCE_OWNER_AND_GLOBAL_HOLD_RETAINED','started_at':started,'ended_at':now(),
        'verifier_id':VERIFIER,'verified_commit':HELD,'normal_API_calls':1,
        'actual_PROVED_LOCAL_transitions':1,'actual_VERIFIED_transitions':1,
        'original_PL_fields_inline_unchanged_in_V_and_Cdetails':26,'payload_sha256':sha(payload_raw),
        'actual_VERIFIED_append_sha256':sha(suffix),'cell_after_sha256':sha((ROOT/C).read_bytes()),
        'postwrite_full_frontier_schema_exit':result.returncode,'old_and_fresh_full_preservation_guards':'PASS',
        'own_C_independent_verification_type':'str','owner_retained':final['owner_id'],
        'only_own_C_and_one_exact_normal_ledger_append_changed':True,
        'source_review_Lean_browser_or_four_gates_replayed':False,
        'integration_publication_purification_whole_Goal':'HOLD','full_private_maps_exported':False}
    create(O/'normal-VERIFIED-outcome.bounded.json',dump(outcome))
    print(json.dumps(outcome,ensure_ascii=False,indent=2))
if __name__ == '__main__': main()
