from pathlib import Path
import hashlib,json,subprocess,sys
sys.dont_write_bytecode=True
ROOT=Path('/Users/zhouhuanjian/ASTIS-GC');BASE=ROOT/'.astis/semantic-neutral-20261110/src_a74f20';OUT=BASE/'normal-sourceV-runtime'
def sha(b):return hashlib.sha256(b).hexdigest()
def canon(o):return json.dumps(o,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
def put(name,o):
 p=OUT/name;p.write_text(json.dumps(o,indent=2,ensure_ascii=False)+'\n');return p
COMMIT='6eca29f8704a024f9bbf2de986d8aa9fbe8c6129'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==COMMIT
before=json.loads((OUT/'before-state.json').read_text());checks=json.loads((OUT/'after-preservation-checks.json').read_text());assert checks['passes']
raw=(OUT/'advance-ledger.before.raw.jsonl').read_bytes();append=(OUT/'ACTUAL-normal-V-append.raw.jsonl').read_bytes();current=(ROOT/'runs/substantive_advances.jsonl').read_bytes();assert current==raw+append
event=json.loads(append);evidence=event['evidence'];inventory=json.loads((OUT/'ACTUAL-V-evidence-key-inventory.json').read_text());assert len(evidence)==inventory['actual_key_count'] and list(evidence)==inventory['actual_keys']
assert json.loads((OUT/'ACTUAL-V-evidence.raw.json').read_text())==evidence
assert json.loads((OUT/'ACTUAL-V-evidence.pretty.json').read_text())==evidence
assert (OUT/'ACTUAL-V-evidence.canonical.json').read_bytes()==canon(evidence)
assert all(sha(canon(evidence[k]))==h for k,h in inventory['per_value_canonical_sha256'].items())
cell='research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-exact-means.json';assert (ROOT/cell).read_bytes()==(OUT/'own-frontier.after.raw.json').read_bytes()
for p,h in before['frontier_raw_hashes'].items():
 if p!=cell:assert sha((ROOT/p).read_bytes())==h
for p,h in before['protected_raw_hashes'].items():assert sha((ROOT/p).read_bytes())==h
assert (ROOT/'runs/substantive_discoveries.jsonl').read_bytes()==(OUT/'discovery-ledger.before.raw.jsonl').read_bytes()
assert sha((ROOT/'research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-exact-means.json').read_bytes())=='357e192b7a81486caba7e57d742e90c9380b365d3ea74197c3a3a50d4679e49e'
for phase in ['phase1','phase2','phase3','phase3-reader-v2']:
 m=json.loads((BASE/phase/'freeze-manifest.json').read_text())
 for v in m['files']:assert sha((ROOT/v['path']).read_bytes())==v['sha256']
release=put('original-V-evidence-preservation-contract.json',{'actual_original_key_count':len(evidence),'actual_original_keys':list(evidence),'actual_original_per_value_canonical_sha256':inventory['per_value_canonical_sha256'],'raw_evidence_sha256':sha((OUT/'ACTUAL-V-evidence.raw.json').read_bytes()),'pretty_evidence_sha256':sha((OUT/'ACTUAL-V-evidence.pretty.json').read_bytes()),'canonical_evidence_sha256':sha(canon(evidence)),'exact_append_sha256':sha(append),'future_release_rule':'Retain ALL actual original evidence keys with equal original values; the only permitted new top-level evidence key is post_integration. Do not assume12/13keys and do not rewrite verifier_id,verified_commit,gate,source_audit,fake_closure_scan or any other original field. No post_integration release performed in this run.'})
report=f'''# Actual independent normal source V

Verifier: `/root/source_reader_a74f20`. Advance: `ASTIS-SA-20261110-GaussianComplexityFixedSpectrumExactMeans`. Author owner remains `huanjian_gc_20261110_fixed_spectrum_exact_means`.

Exactly one normal `astis_advance.transition_advance(..., "VERIFIED", worker_id="/root/source_reader_a74f20", ...)` call completed. Its actual API return was `None`/JSON null; the enclosing execute process exited 0 (actual completion chunk `aecbd5`). Complete API stdout and stderr are preserved as empty files (0 bytes each). The actual event timestamp is `{event['created_at']}` and verified carrier is `{COMMIT}`. No other transition, stabilization claim or foreign-lane transfer was attempted.

The exact single appended JSONL record is `ACTUAL-normal-V-append.raw.jsonl`, SHA-256 `{sha(append)}`, {len(append)} bytes. The entire previous advance ledger is an exact raw prefix of the new ledger. Before/after full raw ledgers, actual event pretty/canonical forms and API invocation intent/return artifacts are retained. The persistent intent file prevents executing a second call through this runner.

The owned frontier is now `independently_verified`, with a nonempty **string** `evidence.independent_verification`, actual normal-V append evidence, and the selected source coverage flag set true. The exact changed-field list and before/after raw frontier bytes are preserved. Its new raw SHA-256 is `{sha((ROOT/cell).read_bytes())}`. Only the advance ledger and this own frontier appear in the current tracked diff; no source, Lean, Test, lesson, audit, shared model/graph, protected or foreign frontier file was edited.

Preflight independently matched the exact four-field v2 audit proposal, canonical audit SHA357e192..., source/reconstruction/repairs, current binding782a2b..., reviewer packeta5ad7c..., current carrier/code/Test/lesson bytes and every earlier frozen file. All46 current source-map locators resolve exactly. The SAU was genuinely PROVED_LOCAL under its author owner with exactly one publication declaration before the call. Existing three canonical ASTIS parents and generic reindex/geometric reuse in the own-cell reuse plan agree with prior independent kernel review; no new mathematical premise or result was introduced.

All four required metadata gates were independently rerun at the current carrier before V and exited0: publication, contributor, semantic-roundtrip and frontier. Their exact commands, receipts and complete stdout/stderr are retained. The API also performed its ordinary reviewed publication admission. After own-frontier projection, the frontier gate again exited0. Earlier root receipts, gzip logs and the initial actual contributor failure are preserved and their decompressed log hashes verified; history was not rewritten.

Preservation checks pass for289 foreign SAU states (full before/after replay equality),448 foreign frontier raw files,191 protected raw files (including the188 protected source/metadata/shared-root files and3 protected shared histories/models), the complete discovery ledger, and all196 files in the four earlier reviewer freezes. Preproof historical foreign states/frontiers were also checked. Current HEAD remains `{COMMIT}`. The before snapshots include full advance/discovery raw ledgers, all frontier raw files in a lossless ZIP, all protected raw files in a lossless ZIP, full replayed states and per-file hashes. Global foreign ownership remains occupied and no ownership or integration authority was transferred.

Native production/Test/kernel/cache evidence is explicitly reused from d823dddd; exact reader/static evidence is from64922804 and its independent successor run52c8c7.... No fresh native check at the carrier is claimed. This normal V certifies only the selected actual closed C8 means/integrability and actual-integral upper/sign/exact-ratio consumer. Variance/exponential bounds, full Lemma4.5/main lower bounds, latest-main shared integration, Registry/graph/site/browser/remote delivery and purification remain separate.

The actual original V evidence contains **{len(evidence)} keys**, discovered from the actual appended record, not an assumed schema count:

'''+'\n'.join('- `'+k+'`' for k in evidence)+f'''

Exact original evidence is retained as raw wire-object bytes, pretty JSON and canonical JSON. Per-value canonical hashes and the complete actual key list/count are recorded. Later release must retain **all** these original keys and values and may add only `post_integration`; this run performed no such release. Preservation contract SHA-256: `{sha(release.read_bytes())}`.

The runtime phase is now frozen for root to carry its exact independent bytes. No canonical source review edit, STAB/merge/shared/global/site/browser/OS/network/push/reset/background ASTIS or Goal completion occurred.
'''
(OUT/'NORMAL-SOURCE-V-REPORT.md').write_text(report)
files=sorted(p for p in OUT.rglob('*') if p.is_file() and p.name not in ['freeze-manifest.json','seal-receipt.json'])+[BASE/'normal_source_v.py',BASE/'freeze_normal_v.py']
manifest=put('freeze-manifest.json',{'status':'FROZEN_ACTUAL_NORMAL_SOURCE_VERIFIED_OWN_FRONTIER_PROJECTED','verifier':'/root/source_reader_a74f20','verified_commit':COMMIT,'api_calls':1,'actual_evidence_key_count':len(evidence),'files':[{'path':str(p.relative_to(ROOT)),'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size} for p in files],'terminal_command':'PYTHONDONTWRITEBYTECODE=1 python3 .astis/semantic-neutral-20261110/src_a74f20/freeze_normal_v.py','receipt_policy':'Separate actual post-seal tool receipt outside non-self-referential manifest. Root may carry exact original bytes; no later release value is synthesized here.'})
print(json.dumps({'status':'FROZEN_ACTUAL_NORMAL_SOURCE_VERIFIED_OWN_FRONTIER_PROJECTED','manifest_sha256':sha(manifest.read_bytes()),'report_sha256':sha((OUT/'NORMAL-SOURCE-V-REPORT.md').read_bytes()),'append_sha256':sha(append),'actual_evidence_key_count':len(evidence),'evidence_canonical_sha256':sha(canon(evidence)),'evidence_key_inventory_sha256':sha((OUT/'ACTUAL-V-evidence-key-inventory.json').read_bytes()),'preservation_contract_sha256':sha(release.read_bytes()),'after_preservation_sha256':sha((OUT/'after-preservation-checks.json').read_bytes()),'own_frontier_after_sha256':sha((ROOT/cell).read_bytes()),'file_count':len(files)},indent=2))
