from pathlib import Path
import json,hashlib,datetime,sys,stat
BASE=Path(__file__).resolve().parent
def sha(b):return hashlib.sha256(b).hexdigest()
inp=json.loads((BASE/'input-manifest.json').read_text())
for name,x in inp.items():
    b=(BASE/'inputs'/name).read_bytes()
    assert len(b)==x['bytes'] and sha(b)==x['sha256'],name
paths=sorted(BASE.rglob('*'))
assert all(not p.is_symlink() for p in paths),'No symlink is admitted into this source-only freeze.'
files=[p for p in paths if p.is_file() and p.name!='phase1-manifest.json']
dirs=[BASE]+[p for p in paths if p.is_dir()]
records=[{'path':str(p.relative_to(BASE)),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes()),'frozen_mode':'0444'} for p in files]
m={'schema':'source-only-phase1-content-manifest-v1','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_raw_sha256':'6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915','frozen_before_target_types':True,'mathematical_status':'unformalized source reconstruction; no independent coverage approval; no theorem proved','write_scope_pristine':False,'files':records,'directories':[{'path':'.' if p==BASE else str(p.relative_to(BASE)),'frozen_mode':'0555'} for p in dirs],'manifest_self_binding':'This manifest excludes its own recursive content hash. Its exact bytes/hash and actual freeze process result are bound by ../phase1-freeze-execution-receipt.json and ../phase1-freeze-index.json; that finite two-level closure covers every Phase1 file.'}
mp=BASE/'phase1-manifest.json';mp.write_text(json.dumps(m,indent=2,ensure_ascii=False)+'\n')
for p in files+[mp]:p.chmod(0o444)
for p in sorted(dirs,key=lambda x:len(x.parts),reverse=True):p.chmod(0o555)
for x in records:
    p=BASE/x['path'];assert sha(p.read_bytes())==x['sha256'] and p.stat().st_size==x['bytes'] and stat.S_IMODE(p.stat().st_mode)==0o444
for p in dirs:assert stat.S_IMODE(p.stat().st_mode)==0o555
key=['input-manifest.json','source-graph.json','mathematics.md','coverage.json','exposure.json','integrity-results.json','phase1-manifest.json']
out={'status':'FROZEN_SOURCE_ONLY_PHASE1','phase1_path':str(BASE),'payload_files_excluding_manifest':len(files),'total_phase1_files':len(files)+1,'directories':len(dirs),'file_modes':'0444','directory_modes':'0555','key_sha256':{n:sha((BASE/n).read_bytes()) for n in key},'source_raw_sha256':sha((BASE/'inputs'/'2610.20492v1.html').read_bytes()),'write_scope_pristine':False,'truth_boundary':'No target types read; no theorem proved; no independent source-coverage approval or semantic-verifier transition.'}
print(json.dumps(out,indent=2,ensure_ascii=False))
