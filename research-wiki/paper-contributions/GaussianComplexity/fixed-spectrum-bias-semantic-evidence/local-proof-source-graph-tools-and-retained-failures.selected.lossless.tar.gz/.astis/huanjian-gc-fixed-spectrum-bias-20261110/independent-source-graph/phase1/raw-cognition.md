# New Bias packet: phase-1 source cognition before new target exposure

## Exposure boundary

This is a fresh raw-source pass for the new Bias packet. No new Bias seal, signature, target coverage, API, implementation, lesson, audit, reviewer output or other-agent artifact was read. The extractor already knew the paper's Fact C.8 mean formulas and the full C.3 bias argument from its earlier raw pass, and previously saw the two Variances literal-statement projections and constructed the Variances source graph. That prior related exposure cannot be undone and is disclosed; this phase is raw-first relative to the **new Bias targets**, not a claim of complete historical source blindness. The prior Variances implementation, APIs and proof were never inspected. The new packet has no supplied mathematical target interface in this phase.

The authoritative original is `.astis/huanjian-resume-20261103/2610.20492v1.html`, SHA256 `6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915`. I reread complete §2 (original lines 635–753), complete §4 (1054–1600), complete Appendix C.3 (3837–4134), and their sole external bibliography entry, [22] (`bib.bib3`, 1847–1864). All these units are re-enumerated in the current raw inventory. No exact-target graph, Lean dependency projection or target-dependent exclusion is constructed here.

## Standing laws, oracle and error conventions from §2

`S2.p1.1` (639–642) fixes the Euclidean norm, identity matrix and positive-semidefinite matrix order. `S2.p2.1` (645–652) defines the real orthogonal group by OᵀO=I and Haar probability measure, including its two determinant components and conditioned Haar laws. This is matrix/probability convention, not an extra target assumption invented to support a proof.

`S2.SS0.SSS0.Px1.p1.1` / `S2.Ex1` (658–669) restrict to centered Gaussians, with d≥1, κ≥1 and precision class A=Aᵀ, I≼A≼κI. `p1.2` / `S2.E1` (670–681) sets f_A(x)=xᵀAx/2, π_A=N(0,A⁻¹), FO_A(x)=(xᵀAx/2,Ax). `p2.1` (684–690) explains exact first-order, gradient-only and matrix-vector equivalence. The input parameter is **precision** A, so the target covariance is A⁻¹, not A. No approximate oracle or expected-query budget is used.

`S2.SS0.SSS0.Px2.p1.1` (697–704) requires randomized queries/stopping/output to be Borel functions of internal randomness and previous replies, with the seed independent of input. A fixed query budget is a cap for every input and every seed realization. `S2.Ex2` and adjacent paragraphs (711–725) define TV by a supremum over measurable sets, equivalently half the L¹ density difference; [0,1]-valued measurable test expectations differ by at most TV. `S2.E2` / `S2.SS0.SSS0.Px4.p1.2` (732–750) define Q_G via uniform per-input TV after averaging the algorithm's seed. The budget is deterministic, not an expectation bound. These conventions matter when §4 first proves a fixed-input target test probability and later averages over random inputs.

## Hard-family and target-moment domain from §4

`S4.SS1.p1.1` / `S4.E11` (1086–1097) define, for d≥2 and κ≥2, θ_i=(i−1/2)π/d, λ_i=(κ+1)/2+(κ−1)cos θ_i/2, Λ=diag(λ_i), i=1,…,d. `p1.2` (1098–1101) draws O Haar independently of the algorithm seed, sets A=OΛOᵀ, f_A=xᵀAx/2 and π_A=N(0,A⁻¹). The spectrum and normalizer are known; the unknown eigenbasis carries the hardness (`p2.1`, 1104–1106).

`S4.Thmtheorem5.p1.1` (1264–1270) assumes κ≥2, U∼N(0,Λ⁻¹), ρ=(√κ−1)/(√κ+1), and integer 1≤n<d, then defines D_n=diag(cos(nθ_i)), M=E‖U‖² and μ_n=E[UᵀD_nU]. The source mode is not restricted to odd n in this lemma. Odd n=2q+1 is chosen in the lower-bound application, separately. M and μ_n are actual moments under the specified Gaussian; they are not arbitrary free scalars.

`S4.EGx1` (1271–1278) gives the two exact mean formulas. `S4.Thmtheorem5.p1.2` (1279–1281) adds the two variance bounds by 2M≤2d/√κ. `p2.1` / `S4.Ex17` (1284–1291) states the two-sided exponential normalized-bias bound **if d−n≥√κ**. This additional spacing condition belongs to that stated pair, not the exact means or variance statement.

`S4.SS2.SSS0.Px3.p2.1` (1295–1299) explicitly transfers the actual law: if Y|O∼π_A then U=OᵀY∼N(0,Λ⁻¹), ‖Y‖²=‖U‖² and YᵀOD_nOᵀY=UᵀD_nU. It does not assert ambient-coordinate independence of Y or replace the Gaussian law with an abstract callback. Fixed-O and fixed-A target calculations must retain the actual covariance conjugation and quadratic identities.

## Full C.3 derivation, independently reread

`A3.SS3.p1.1` (3841–3846) declares the route: inverse-spectrum cosine expansion, finite-grid summation, then variance and normalized bias.

Fact C.7 (`A3.Thmtheorem7`, `A3.Ex133`, 3848–3861) states the all-real-θ expansion

2/[κ+1+(κ−1)cosθ]=(1/√κ)(1+2Σ_{j≥1}(−ρ)^j cos(jθ)),

with absolute and uniform convergence. `A3.SS3.p2.1` / `A3.EGx14` (3865–3879) use 0<ρ<1 and two complex geometric series to get (1−ρ²)/(1+2ρcosθ+ρ²). `A3.Ex136` (3881–3887) matches this to the source denominator using the two algebraic identities for ρ. `A3.Ex137` / `p2.4` (3890–3898) bound the absolute series by ρ/(1−ρ). These are internal-paper arguments, with no external bibliography citation in C.3.

Fact C.8 (`A3.Thmtheorem8`, `A3.Ex138`, 3901–3912) records, for 1≤n<d,

M=(d/√κ)(1−ρ^{2d})/(1+ρ^{2d}),
(−1)^n μ_n=(d/√κ)(ρ^n−ρ^{2d−n})/(1+ρ^{2d}).

`A3.Ex139` (3918–3926) evaluates Σ_i cos(kθ_i) as d(−1)^a if k=2ad, a integer, and zero otherwise. `A3.SS3.p3.2` (3927–3930) supplies the finite-cosine-sum and direct-angle justifications. `p4.1` / `A3.Ex140` (3933–3940) use E U_i²=1/λ_i to express M and μ_n as the corresponding finite reciprocal-eigenvalue sums. `p4.2` (3941–3943) explicitly invokes absolute convergence for series/finite-grid interchange. `p5.1` / `A3.EGx15` (3946–3965) keep only j=2ad and sum M's geometric series. `p6.1` / `A3.Ex144` (3968–3976) apply product-to-sum to μ_n. `p6.2` (3977–3985) enumerates the disjoint surviving classes j=n, j=2ad+n and j=2ad−n, their grid signs and coefficient parity; 1≤n<d is used for disjointness. `A3.EGx16` (3986–4003) sums them into the stated formula. `p7.1` (4010–4011) applies Fact C.8 to the asserted means in Lemma 4.5.

The variance paragraph `A3.SS3.p8.1` (4014–4022) states diagonal-Gaussian coordinate independence, scalar second/fourth moments and Var(U_i²)=2/λ_i², then λ_i≥1. The named TBODY equations `A3.Ex148` and `A3.Ex149` (4025–4034, inside `A3.EGx17`) give the two exact variance sums and their bounds by 2M. `p8.2` (4036) uses exact M for M≤d/√κ. This variance branch is adjacent source context; it does not prove the bias's logarithm or tail estimate. Conversely, the fourth-moment/independence branch is unnecessary for the scalar algebra deriving the bias from its already-established actual means.

`A3.SS3.p9.1` (4039–4044) uses n<d and 0<ρ<1 to obtain ρ^n>ρ^{2d−n}, hence (−1)^n μ_n>0. Dividing the **two exact means** gives `A3.Ex150` (4045–4051):

β:=|μ_n|/M=ρ^n(1−ρ^{2(d−n)})/(1−ρ^{2d}).

This requires M>0 and the positive denominators supplied by the source domain; their verification is implicit. It is a **ratio of means**, not E[|UᵀD_nU|/‖U‖²] or E[UᵀD_nU/‖U‖²]. Pointwise eigenvector energy weights later in §4 are different objects.

`p9.2` / `A3.Ex151` (4052–4061) use 0<ρ^{2d}<ρ^{2(d−n)}<1 to show

1−ρ^{2(d−n)}≤(1−ρ^{2(d−n)})/(1−ρ^{2d})≤1.

The upper comparison follows throughout 1≤n<d. It does not need d−n≥√κ. In particular, β≤ρ^n is available before imposing the extra tail-spacing condition. The final lemma's displayed **paired** bound is nevertheless written with that extra condition, which is needed by its uniform lower factor.

`A3.SS3.p10.1` / `A3.EGx18` (4064–4082) write

log(1/ρ)=log((√κ+1)/(√κ−1))
=2∫₀^{1/√κ} 1/(1−t²) dt
=2/√κ+2∫₀^{1/√κ} t²/(1−t²) dt.

The last integral is nonnegative, giving log(1/ρ)≥2/√κ. `p10.2` / `A3.EGx19` (4083–4099) use 1−t²≥1−κ⁻¹ on the integration interval and compute ∫t² to get

log(1/ρ)≤(2/√κ)(1+1/[3(κ−1)])≤8/(3√κ)<3/√κ.

`p10.3` (4100–4101) explicitly identifies κ≥2 as the final constant hypothesis. `A3.Ex157` (4102–4108) exponentiates after multiplying by −n, reversing the bounds in the exponent:

e^{−3n/√κ}≤ρ^n≤e^{−2n/√κ}.

The log calculation is scalar and uses no Gaussian fourth moments, independence, q, δ, τ, TV or algorithm assumptions. The stated positive mode domain suffices; powers/logarithms and denominator identities need their domain guards discharged internally.

`A3.SS3.p11.1` / `A3.Ex158` (4111–4119) now impose d−n≥√κ, and use only the **lower** log estimate to obtain

ρ^{2(d−n)}=exp(−2(d−n)log(1/ρ))≤e^{−4(d−n)/√κ}≤e^{−4}.

`p11.2` / `A3.Ex159` (4120–4130) combine this tail estimate, the ratio correction-factor bounds and the power estimates into

(1−e^{−4})e^{−3n/√κ}≤β≤e^{−2n/√κ}.

The author presents one sufficient conjunction of these steps. No alternative proof route is asserted in this source slice, and no implementation-oriented alternative is inferred here.

## Probability application and its separate parameter obligations

Theorem 4.1 (`S4.Thmtheorem1`, 1062–1075) quantifies fixed δ∈(0,1), then an existence threshold d₀(δ), all sufficiently large integer d, 2≤κ≤d^{1−δ}, and 0<ε≤1/10. The proof supposes q≤(δ/256)√κ log d and a per-input TV guarantee (`S4.SS3.p2.1`, 1330–1337). Lemma 4.6 supplies admissibility.

`S4.SS3.p3.1` / `S4.EGx2` (1340–1355) fix n=2q+1 and τ=τ_{d,q}; S_A is the signed Chebyshev matrix quadratic minus 2τ‖x‖², and E_A={S_A>0}. `p3.2` identifies the first-kind Chebyshev polynomial. `p4.1` (1360–1370) evaluates T_n(cosθ_i)=cos(nθ_i) and interprets the statistic using pointwise energy weights when x≠0. The polynomial event itself is defined for all x; S_A(0)=0, so no arbitrary off-domain ratio convention at x=0 is needed.

The algorithm branch (`S4.SS3.SSS0.Px1`, 1373–1413) derives n=o(d) and τ→0 under the source q/κ/δ restrictions. `S4.Ex20` gives the explicit decay rates, and `p1.2` obtains n<d and τ≤1/2 for sufficiently large d depending only on δ. Lemmas 4.3/4.4 give the uniform cosine-statistic event with probability≥0.99, hence averaged algorithm test probability≤0.01 (`S4.Ex22`). The Gaussian vectors used for the Krylov extension are algorithm-side source objects, distinct from an exact target sample U. Their proof is deferred to C.1/C.2, not read or claimed covered by this C.3 pass.

The target branch defines M=trΛ⁻¹, μ_n=tr(D_nΛ⁻¹), β=|μ_n|/M (`S4.SS3.SSS0.Px2.p1.1`, 1418–1422). `p2.1` (1425–1428) uses n=o(d) and √κ=o(d) uniformly to establish d−n≥√κ eventually; the tail condition is actually discharged before applying the lower-bias estimate. `S4.Ex23` (1429–1435) gives β≥b d^{−δ/4}, b=(1−e^{−4})e^{−3}. `p2.2` (1436–1444) explains 3n/√κ≤3+(3δ/128)log d. The displayed d^{−δ/4} is a weaker convenient rate than the immediate exponent from 3δ/128; no equality of these constants is asserted.

The same paragraph separately uses ρ≤e^{−1/√κ} and d≥√κ to get ρ^{2d}≤e^{−2}<1/3, and the exact M formula then gives M≥d/(2√κ)≥d^{(1+δ)/2}/2. This is a lower bound on M, distinct from the earlier upper bound used in the variance lemma. The source chooses a weaker exponential bound for ρ here than the already available e^{−2/√κ}; this does not create an alternative proof premise.

`S4.Ex24` (1445–1451) combines the **upper** τ estimate, **lower** β estimate and **lower** M estimate: τ/β≤(C′/b)d^{−δ/4}(log d)³→0, and Mβ²≥(b²/2)√d→∞. `p2.3` (1452–1455) stresses uniformity over the parameter range and chooses a common d₀(δ) preserving the algorithmic conditions and adding τ≤β/4, Mβ²≥320. These are derived eventual conditions in the source application, not independent standing assumptions of Lemma 4.5. No explicit numeric formula for d₀ is supplied.

`p3.1` / `S4.Ex25` (1458–1470) fix A, draw Y∼π_A and Z=S_A(Y). The signed target quadratic has mean (−1)^nμ_n=βM; the squared norm has mean M; both variances≤2M. The mean formula and τ≤β/4 yield E Z=(β−2τ)M≥βM/2>0. The centered-L² triangle inequality and 0≤τ≤1/2 give Var Z≤(√(2M)+2τ√(2M))²≤8M. The whole quadratic forms are not declared independent; centered-L² is precisely the source's dependence-safe inequality. Finite moments/L² are internal ingredients, not new public hypotheses.

`p3.2` / `S4.Ex26` (1471–1478) use Chebyshev at the **positive mean**, for every A in the hard family:

π_A(E_A)=P(Z>0)≥1−Var Z/(E Z)²≥1−32/(Mβ²)≥0.9.

The number 320 is used for this probability conclusion, not for the scalar normalized-bias formula or log/power estimates. `S4.SS3.SSS0.Px3.p1.1` / `S4.Ex27` (1485–1495) combine the per-input target bound and per-input TV comparison with the **averaged** algorithm bound to get 0.89≤ε≤0.1. E_A can depend on A: the uniform per-input TV premise applies to the measurable test set for that fixed A before averaging. The source does not require the algorithm to know or evaluate the test.

## Full §4.4 context retained without inventing stronger paper claims

`S4.SS4.p1.1` (1505–1510) states that this proof is limited in κ and does not improve as ε decreases. The dimension limitation (`S4.SS4.SSS0.Px1`, 1512–1559) uses Lemma 4.7's dim K_q=min{d,(q+1)²} almost surely; once K_q fills R^d, a coordinate with |cos(nθ_i)|≥1/√2 prevents the requisite uniform bound. This is a limitation of the uniform-Krylov route, not a refutation of the fixed-spectrum family's possible stronger hardness.

The accuracy limitation (`S4.SS4.SSS0.Px2`, 1561–1588) compares a threshold t with an algorithmic uniform bound a and the target β: a≤t<β. It references a Bernstein requirement a≥c/√d in the proof of Fact C.6, and uses β≤e^{−2n/√κ}; with n=2q+1, `S4.Ex30` (1577–1583) yields c/√d≤a<β≤e^{−2(2q+1)/√κ}. Taking logs restricts this proof to q=O(√κ log d), independently of ε. The cited Fact C.6 proof is outside the reread C.3 scope; its exact reference is retained, with no claim to have audited that proof here. `S4.Thmtheorem8.p1.1` (1592–1595) explicitly leaves stronger lower bounds for the same family open.

## Omitted source ingredients and source-only inventory boundary

The source does not isolate separate proofs for positivity/invertibility of all displayed denominators; 0<ρ<1; M>0; log/power identities and their positivity domains; continuity/integrability and fundamental-theorem evaluation of the log integral on [0,1/√κ]⊂[0,1); order-preserving integration and the elementary t² integral; sign/absolute-value conversion of μ_n; legitimate division of actual mean formulas; actual Gaussian linear pushforward and matrix-polynomial evaluation; finite Gaussian moments and finite centered-L² for the probability step; the positive-mean event inclusion needed by Chebyshev; or the uniform eventual-threshold selection and error-budget arithmetic. These must remain visible source-derived internal obligations in a later exact graph. Their omission from exposition never makes them permissible new source hypotheses.

The raw inventory keeps all original math TeX, IDs, line spans, reference destinations and true containing-display IDs. Every unit has one target-independent NODE/EXCLUDED disposition. Named TBODY formula rows, including A3.Ex148/A3.Ex149 and the log-integral rows, are raw NODEs; anonymous TBODY rendering duplicates name their actual capturing display. Current raw ordinals and tag/line/column keys distinguish same-line links; matching prior Variances raw ordinals are attached without rewriting them. All full-source substantive §2/§4/C.3 regions are retained even if a later exact target excludes some. No target-dependent coverage or self-acceptance is asserted.

Phase 1 stops after its immutable artifact/hash freeze. Any later exact-target projection must be separately authorized and must preserve this historical record and exposure disclosure.
