from pathlib import Path
from html.parser import HTMLParser
import datetime, hashlib, html, json, re

ROOT=Path('/Users/zhouhuanjian/ASTIS-GC')
OUT=ROOT/'.astis/semantic-neutral-20261113/structure_sg_a94e'
SRC=ROOT/'.astis/huanjian-resume-20261103/2610.20492v1.html'
b=SRC.read_bytes(); s=b.decode('utf-8')
assert hashlib.sha256(b).hexdigest()=='6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
(OUT/'original.2610.20492v1.html.RAW').write_bytes(b)
starts=[0]+[m.end() for m in re.finditer('\n',s)]
def locator(a,z):
    import bisect
    return {'char_start':a,'char_end_exclusive':z,'byte_start':len(s[:a].encode()),
            'byte_end_exclusive':len(s[:z].encode()),'line_start_1based':bisect.bisect_right(starts,a),
            'line_end_1based':bisect.bisect_right(starts,max(a,z-1))}
class Parser(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=False); self.stack=[]; self.nodes=[]
    def at(self):
        line,col=self.getpos(); return starts[line-1]+col
    def handle_starttag(self,tag,attrs):
        d=dict(attrs); self.stack.append({'tag':tag,'attrs':d,'a':self.at()})
        if tag in {'meta','link','br','img','hr','input','wbr','source'}: self.stack.pop()
    def handle_endtag(self,tag):
        for i in range(len(self.stack)-1,-1,-1):
            if self.stack[i]['tag']==tag:
                n=self.stack[i]; n['z']=self.at()+len(tag)+3
                self.nodes.append(n); self.stack=self.stack[:i]; break
p=Parser();p.feed(s)
ss2=next(n for n in p.nodes if n['attrs'].get('id')=='A3.SS2')
def text(raw):
    raw=re.sub(r'<math\b[^>]*alttext="([^"]*)"[^>]*>.*?</math>',lambda m:' $'+html.unescape(m[1])+'$ ',raw,flags=re.S)
    raw=re.sub(r'<annotation\b.*?</annotation>','',raw,flags=re.S)
    raw=re.sub('<[^>]+>',' ',raw)
    return re.sub(r'\s+',' ',html.unescape(raw)).strip()
nodes=[]
for n in sorted(p.nodes,key=lambda n:n['a']):
    if ss2['a']<=n['a']<ss2['z'] and n['tag'] in {'p','table','h3','h6'}:
        if n['tag']=='table' and 'ltx_equation' not in n['attrs'].get('class',''): continue
        raw=s[n['a']:n['z']]
        node={'id':n['attrs'].get('id',f"heading-{n['a']}"),'tag':n['tag'],**locator(n['a'],n['z']),
              'raw_sha256':hashlib.sha256(raw.encode()).hexdigest(),'text':text(raw)}
        nodes.append(node)
(OUT/'c2-raw-blocks.json').write_text(json.dumps(nodes,ensure_ascii=False,indent=2)+'\n')
(OUT/'c2-readable.txt').write_text('\n\n'.join(f"{n['id']} | lines {n['line_start_1based']}-{n['line_end_1based']} | chars [{n['char_start']},{n['char_end_exclusive']}) | bytes [{n['byte_start']},{n['byte_end_exclusive']})\n{n['text']}" for n in nodes)+'\n')
raw=s[ss2['a']:ss2['z']].encode(); (OUT/'c2-exact-scope.RAW.html').write_bytes(raw)
manifest={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'original_path':str(SRC.relative_to(ROOT)),
          'original_sha256':hashlib.sha256(b).hexdigest(),'original_bytes':len(b),
          'scope':{'id':'A3.SS2',**locator(ss2['a'],ss2['z']),'sha256':hashlib.sha256(raw).hexdigest()},
          'ordering':'Pinned original read and own source-only extraction before any target signature or implementation/prior audit/topology contents.',
          'boundaries':'Preparation only; no source fidelity, normalV, theorem completeness, or Lean proof claim.',
          'outputs':{name:hashlib.sha256((OUT/name).read_bytes()).hexdigest() for name in ['original.2610.20492v1.html.RAW','c2-raw-blocks.json','c2-readable.txt','c2-exact-scope.RAW.html']}}
(OUT/'RAWFREEZE.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(manifest,indent=2))
