from pathlib import Path
import hashlib,json,sys
sys.dont_write_bytecode=True
sys.path.insert(0,'tools');import astis_advance as adv
P=Path('.astis/huanjian-gc-fixed-spectrum-moments-20261109/cosine-expansion')
E=Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-cosine-expansion-semantic-evidence')
sha=lambda b:hashlib.sha256(b).hexdigest()
dump=lambda x:(json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode()
path=Path('runs/substantive_discoveries.jsonl');before=path.read_bytes()
assert before.endswith(b'\n')
states=adv._replay_discoveries([json.loads(x) for x in before.splitlines()])
assert sha(before)=='65666d5e5fcd3648c0e068c5ed0f3b0006f6761276df07ef87bc05d45ee7aa3a'
metadata={
 'bridge_id':'transport:poisson-boundary-to-cosine-spectrum',
 'family_id':'family:poisson-representation',
 'domains':['concept:poisson-boundary-harmonics','concept:cosine-spectrum-resolvent'],
 'formula':r'K_q(\theta)=\frac{1-q^2}{1-2q\cos\theta+q^2},\quad q=-r_\kappa,\quad \lambda_\kappa(\theta)^{-1}=\kappa^{-1/2}K_{-r_\kappa}(\theta).',
 'mechanism':'The normalized Poisson kernel reproduces boundary harmonic modes. AppendixA1 uses spherical Poisson representation for constant/coordinate harmonic functions; C7 expresses the auxiliary circle kernel by absolutely and uniformly convergent cosine modes. The kernel interpretation of C7 is a proposed algebraic inference, not wording attributed to its author or a certified formal transport.',
 'hypothesis_map':'A1: normalized surface measure on S^(n-1), interior pole r e1,0<r<1, harmonic functions1 and x1. Raw statement has n>=2 and trailing n>=3 ambiguity; existing compiled n=2 is a disclosed extension, not upgraded source credit. C7: real kappa>=2, r=(sqrt(kappa)-1)/(sqrt(kappa)+1), every real theta, an AUXILIARY circle (dimension2), negative pole q=-r or equivalently an angle shift by pi. Gaussian ambient dimension d is not this auxiliary dimension. An angular-parametrization/surface-measure adapter and negative-pole rotation are not currently certified.',
 'key_estimate':'A1 normalized Poisson moments have mass1 and coordinate mean r after multiplying the two raw Eq12 integrals by1-r^2. C7 uses |(-r)^(j+1)cos((j+1)theta)|<=r^(j+1), a summable majorant for fixed kappa. The exact normalization is1-r^2=sqrt(kappa)(1-r)^2; the spectral reciprocal includes the factor1/sqrt(kappa).',
 'conclusion_map':'Retain one source-backed Poisson representation family connecting boundary-harmonic reproduction and Fourier-mode decomposition of a scalar inverse spectrum. Current compiled C7 supplies its pointwise/absolute/uniform assertions and a real private finite-grid interchange; existing A1 supplies its reviewed concrete spherical moments with its original domain/source-audit boundary. This is conceptual typed memory only. Neither result is listed as a compiled dependency of the other, no circle-surface transport certificate is supplied, and no new Gaussian expectation or lower-bound result is inferred.',
 'failure_boundary':'Continuous circle/sphere averaging is NOT the d-point midpoint cosine grid: alias modes survive and the finite corrections in C8 must be retained; in particular this bridge does not assert M=d/sqrt(kappa). Generic higher-dimensional kernels have denominator power n/2 and require the appropriate spherical harmonics, not the plain circle cosine formula. The positive-pole A1 expression has a minus sign, while C7 uses the negative pole plus sign; forgetting the phase/pole change is invalid. Uniform convergence is for fixed kappa, not uniform as kappa tends to infinity/r tends to1; r>=1 is outside the majorant regime. Preserve the raw A1 n>=2/n>=3 ambiguity and the author HFT-route debt. No Gaussian dimension reduction, closed C8 moments/variance/bias, oracle/TV/precision/cap/expected-cost comparison, main-bound implication or source-status upgrade follows.',
 'source_ids':['arXiv2610.20492v1:A1.SS1/Eq12','arXiv2610.20492v1:A3.Thmtheorem7/A3.Ex133-137','arXiv2610.20492v1:A3.SS3.p4.2'],
 'source_map':{'A1':'A1.SS1 full lemma/proof, normalized Poisson representation and two moments; original n>=2/n>=3 wording retained.',
               'C7':'A3.Ex133 rational expansion, Ex134-136 geometric/normalization algebra, Ex137 fixed-kappa majorant.',
               'finite_grid':'A3.SS3.p4.2 only finite-sum/series exchange. C8 grid cancellation/finite corrections and Gaussian identification remain outside current result.'},
 'graph_views':['overview','functor'],
 'compiled_candidate_substrates':[
  'AutoSamplingTheory.ExampleCases.GaussianComplexity.SphericalPoisson.spherical_poisson_moments',
  'AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumCosineExpansion.actual_inverse_spectrum_cosine_expansion'],
 'formal_transport_certificate':False,'independent_validation':'pending; creator cannot validate',
 'source_snapshot_sha256':'6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'}
did='ASTIS-DISC-20261109-GaussianComplexityPoissonCosineMirror'
proposal={'id':did,'state':'RAW_CONCEPTUAL_CANDIDATE_NOT_LEAN_IMPLICATION','metadata':metadata,
 'review_required':'Independent source/mathematical check of both source anchors and every adapter/failure boundary, then normal discovery validation. Shared model integration only during later stabilization.'}
q=E/'poisson-cosine-mirror-candidate-v1.json';assert not q.exists();q.write_bytes(dump(proposal))
adv.publish_discovery(adv.Discovery(discovery_id=did,
 advance_id='ASTIS-SA-20261109-GaussianComplexityFixedSpectrumCosineExpansion',kind='conceptual-mirror',
 statement='Normalized Poisson boundary reproduction and the C7 cosine inverse-spectrum expansion share an auxiliary circle-kernel representation, with explicit dimension, pole, measure and finite-grid failure boundaries.',
 evidence=str(q),where_it_matters='Preserve the mathematical relation between the two Gaussian-complexity source routes without creating a Lean dependency or discarding finite-grid corrections.',
 provenance='Pinned arXiv2610.20492v1 A1.SS1 and C7/C8p4.2, read directly; existing local concrete spherical-moment statement and current compiled C7. Candidate interpretation independently pending.',
 created_by='huanjian_gc_20261109_fixed_spectrum_cosine_expansion',
 frontier_cell='ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-cosine-expansion',metadata=metadata))
after=path.read_bytes();assert after.startswith(before);append=after[len(before):];assert len(append.splitlines())==1
new=adv._replay_discoveries([json.loads(x) for x in after.splitlines()])
assert {k:v for k,v in new.items() if k!=did}==states
(E/'actual-poisson-mirror-discovery-append.exact.jsonl').write_bytes(append)
(E/'postproof-conceptual-mirror-audit.json').write_bytes(dump({'status':'candidates-published','discovery_ids':[did],
 'candidate':str(q),'actual_normal_discovery_API_calls':1,'existing_discovery_states_preserved':len(states),
 'old_raw_prefix_preserved':True,'append_sha256':sha(append),'discovery_ledger_after_sha256':sha(after),
 'models_changed':False,'formal_proof_edge_or_transport_certificate':False,'independent_validation':'pending'}))
print(json.dumps({'status':'candidates-published','discovery_id':did,'candidate_sha256':sha(q.read_bytes()),'append_sha256':sha(append),'previous_states_preserved':len(states),'models_changed':False}))
