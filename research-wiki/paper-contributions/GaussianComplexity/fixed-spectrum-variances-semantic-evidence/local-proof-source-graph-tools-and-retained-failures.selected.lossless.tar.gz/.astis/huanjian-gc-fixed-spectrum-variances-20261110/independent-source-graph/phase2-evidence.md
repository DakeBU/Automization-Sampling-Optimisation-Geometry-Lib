# Phase 2 source-only extraction result

The exact whitelist projection was hash-checked after the phase-1 freeze. No full seal, API inventory, implementation or other actor mathematics was read. Every artifact named by the phase-1 freeze was rechecked unchanged.

The proposed graph has separate producer and private-consumer roots. All omitted Gaussian law/covariance, coordinate independence, fourth-moment, squared-variable independence, finite L², finite variance and centered-L² steps remain explicit internal SOURCE_GAP obligations. They are never new public assumptions. The source contains one centered-L² route for this variance clause, so no synthetic alternative OR-route was invented.

The producer needs both exact variance formulas, both L² outputs, both bounds by 2M, and the additional 2M≤2d/√κ output. The minimal private consumer subroot needs both actual L² outputs and both 2M variance bounds; it does not mathematically need the closed-M upper output. Opaque source mean prerequisites carry no new proof credit.

The proposed private scalar guards are **not accepted as source-wide STANDING assumptions**. The source fixes n=2q+1 and τ=τ_dq, and obtains τ≤1/2 by its original large-d choice. The variance algebra itself is valid for all source positive modes and arbitrary 0≤τ≤1/2, so the exact private signature is coherent as an explicitly identified local numerical generalization. Its proposed STANDING classification is HOLD pending independent admission/scope correction. This does not legalize extra source-Anchor hypotheses or rotated-law callbacks. It does not prove the Ex25 mean clause or Ex26 probability claim.

Every one of the 294 phase-1 raw units has an auditable exact-target successor. Broader phase-1 NODEs become EXCLUDED with reasons where outside these precise targets. A3.Ex148 and A3.Ex149 are named TBODY formula rows; phase 2 promotes them to semantic nodes and explicitly corrects the generic phase-1 capturing-parent rationale without altering historical bytes.

No mathematical obligation is marked proved, no implementation-use claim is made, and no coverage/root closure is self-approved. Distinct raw-source coverage and root-closure challenges remain required.
