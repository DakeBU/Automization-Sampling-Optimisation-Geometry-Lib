"""Create a disabled, exact-snippet successor proposal; never edit production."""
from pathlib import Path
import difflib, hashlib, json
W = Path(__file__).parent
D = W/'reader-step-neighbor-proposal-v4'
assert not D.exists()
q = Path('.astis/huanjian-gc-zero-query-20261110/reader-neighbor-proposal-v3/proposed/website/scripts/declaration_lessons.py')
sha = lambda b: hashlib.sha256(b).hexdigest()
assert sha(q.read_bytes()) == '64b8768e27da03eebb93d0a5ef77a2b47481bb1f50d4a90fae32b92c94d2e05a'
production = Path('website/scripts/declaration_lessons.py')
assert sha(production.read_bytes()) == 'b22394faeb8de07109826174d05856f4a561b20f9301e1f1d031b466fd6f2596'
text = q.read_text()
assert text.count("for source in unit.get('sources', []):") == 2
text = text.replace("for source in unit.get('sources', []):", "for source in unit_source_candidates(unit):", 1)
start = text.index('def complete_lean_step_actions(')
end = text.index('\ndef render_unit(', start)
helper = '''def unit_source_candidates(unit: dict) -> list[dict]:
    """Existing explicit citations plus this unit's actual canonical module."""
    sources = list(unit.get('sources', []))
    declaration = inline_lean.declarations().get(unit.get('declaration', ''))
    if declaration and not any(s.get('path') == declaration.source_file for s in sources):
        sources.insert(0, {'path': declaration.source_file, 'line': declaration.source_line})
    return sources


def exact_lean_step_actions(unit: dict, step: dict, page: str) -> str:
    """Copy literal code and link only one unambiguous exact source occurrence.

    This matches bytes, never theorem names or approximate snippets. Ambiguous or
    absent matches receive copy controls only, with no invented source routing.
    """
    literal = str(step.get('lean', '')).encode('utf-8')
    if b'\\n' not in literal:
        return ''
    copy = ('<button type="button" data-lean-copy>Copy Lean step</button>'
            '<span role="status" aria-live="polite" data-lean-copy-status></span>')
    matches = []
    seen = set()
    for source in unit_source_candidates(unit):
        raw = source.get('path', '')
        if source.get('url') or not raw or raw.startswith('.lake/packages/') or Path(raw).suffix != '.lean':
            continue
        source_link(source, page)  # validate the existing repository path first
        if raw in seen:
            continue
        seen.add(raw)
        path = ROOT / raw
        if not path.resolve().is_relative_to(ROOT.resolve()):
            raise ValueError(f'Exposition source leaves the repository: {raw}')
        if not path.is_file():
            continue
        whole = path.read_bytes()
        offset = whole.find(literal)
        if offset < 0:
            continue
        if whole.find(literal, offset + 1) >= 0:
            matches.extend([None, None])  # repeated source occurrences are ambiguous
            continue
        line = (source.get('line', 1) if whole == literal
                else whole[:offset].count(b'\\n') + 1)
        matches.append((raw, line))
    links = ''
    if len(matches) == 1 and matches[0] is not None:
        raw, line = matches[0]
        context = source_link({'path': raw, 'line': line}, page)
        download = base.relative_prefix(page) + 'data/lesson-sources/' + Path(raw).as_posix()
        links = (f'<a href="{base.esc(context)}">Exact source context</a>'
                 f'<a href="{base.esc(download)}" download>Download exact Lean source</a>')
    return '<div class="lean-source-actions">' + copy + links + '</div>'

'''
text = text[:start] + helper + text[end:]
old = "        '<details><summary>Corresponding Lean step</summary>'\n        + complete_lean_step_actions(unit, s, page)"
new = "        + ('<details data-lean-code-panel>' if '\\n' in s['lean'] else '<details>')\n        + '<summary>Corresponding Lean step</summary>'\n        + exact_lean_step_actions(unit, s, page)"
assert old in text
text = text.replace(old, new)
compile(text, '<disabled-reader-v4>', 'exec')
dest = D/'proposed/website/scripts/declaration_lessons.py'
dest.parent.mkdir(parents=True)
dest.write_text(text)
patch = ''.join(difflib.unified_diff(production.read_text().splitlines(keepends=True), text.splitlines(keepends=True), fromfile='a/website/scripts/declaration_lessons.py', tofile='b/website/scripts/declaration_lessons.py'))
(D/'reader-step-neighbor.patch').write_text(patch)
record = {'production_file': str(production), 'production_sha256': sha(production.read_bytes()),
          'base_disabled_v3_sha256': sha(q.read_bytes()), 'proposed_file': str(dest),
          'proposed_sha256': sha(dest.read_bytes()), 'patch_sha256': sha(patch.encode()),
          'scope': 'DISABLED prospective renderer-only proposal. Same canonical math/lesson/audit/publication bytes. All six corresponding code folds gain existing copy-panel hooks; source/download association requires a unique exact byte occurrence among the existing canonical module and explicit local citations. Actual public/private routing must be independently checked. No fuzzy matching, new theorem node, production adoption, browser/site/global/HOLD release or sourceV.',
          'prior_original_HOLDs_preserved': True}
(D/'proposal.json').write_text(json.dumps(record, indent=2)+'\n')
for p in [dest, D/'reader-step-neighbor.patch', D/'proposal.json']:
    p.chmod(0o444)
print(json.dumps(record))
