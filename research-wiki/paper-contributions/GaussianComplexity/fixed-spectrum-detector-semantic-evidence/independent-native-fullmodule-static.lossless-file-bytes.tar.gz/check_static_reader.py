from pathlib import Path
from html.parser import HTMLParser
import sys, json, hashlib, re, html, shutil

sys.dont_write_bytecode = True
ROOT = Path.cwd()
W = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'website/scripts'))
sys.path.insert(0, str(ROOT / 'tools'))
import declaration_lessons as dl
import inline_lean

sha = lambda b: hashlib.sha256(b).hexdigest()

class Node:
    def __init__(self, tag='', attrs=(), parent=None):
        self.tag, self.attrs, self.parent = tag, dict(attrs), parent
        self.children = []
    def text(self):
        return ''.join(x.text() if isinstance(x, Node) else x for x in self.children)
    def find(self, tag, cls=None):
        found = []
        for x in self.children:
            if isinstance(x, Node):
                if x.tag == tag and (cls is None or cls in x.attrs.get('class','').split()):
                    found.append(x)
                found.extend(x.find(tag, cls))
        return found

class Tree(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.root = self.at = Node()
    def handle_starttag(self, tag, attrs):
        n = Node(tag, attrs, self.at)
        self.at.children.append(n)
        if tag not in {'br','hr','img','meta','link','input','source','area','base','embed','wbr'}:
            self.at = n
    def handle_endtag(self, tag):
        p = self.at
        while p.parent is not None:
            if p.tag == tag:
                self.at = p.parent
                return
            p = p.parent
    def handle_data(self, data):
        self.at.children.append(data)

lesson = Path('website/content/declaration_lessons/huanjian-fixed-spectrum-detector.json')
publication = Path('website/content/publications/huanjian-fixed-spectrum-detector.json')
u = json.loads(lesson.read_bytes())['units'][0]
item = json.loads(publication.read_bytes())['items'][0]
P = Path('AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumDetector.lean')
C = Path('Tests/GaussianComplexityFixedSpectrumDetector.lean')
ptext, ctext = P.read_text(), C.read_text()
page = dl.lesson_path(u['declaration'])
rendered = dl.render_unit(u, page)
tree = Tree(); tree.feed(rendered)
details = tree.root.find('details')
assert details and all('open' not in n.attrs for n in details)
steps = tree.root.find('details', 'proof-reader-step')
assert len(steps) == len(u['steps']) == 6
snippet_results = []
for i, (step, node) in enumerate(zip(u['steps'], steps), 1):
    code = step['lean']
    assert '\n' in code
    locs = [str(p) for p,t in [(P,ptext),(C,ctext)] if code in t]
    assert locs, ('not a literal whole-source substring', i)
    panels = [x for x in node.find('details') if x.find('summary') and x.find('summary')[0].text() == 'Corresponding Lean step']
    assert len(panels) == 1, ('one adjacent Lean panel', i)
    assert [x.text() for x in panels[0].find('pre')] == [code], ('literal step code', i)
    assert step['formula'] in node.text(), ('formula present in its own step', i)
    snippet_results.append({'step':i,'title':step['title'],'literal_source_paths':locs,
                            'snippet_bytes':len(code.encode()),'snippet_sha256':sha(code.encode()),
                            'formula':step['formula'],'adjacent_initially_closed_lean_panel':True})
assert u['steps'][5]['lean'].encode() == C.read_bytes(), 'full raw Test bytes in adjacent step 6'
source = inline_lean.display_source(inline_lean.declarations()[u['declaration']].source_text)
statement, body = inline_lean.split_statement(source)
assert source in ptext and body.startswith(':= by')
stmt_nodes = tree.root.find('details', 'inline-lean-statement')
proof_nodes = tree.root.find('details', 'inline-lean-proof')
assert len(stmt_nodes) == len(proof_nodes) == 1
assert [x.text() for x in stmt_nodes[0].find('pre')] == [statement]
assert [x.text() for x in proof_nodes[0].find('pre')] == [source]
assert item['assumptions'] == u['assumptions']
assert item['bindings'][0]['declaration'] == u['declaration']
assert item['bindings'][0]['boundary'] == u['boundary']
for a in u['assumptions']:
    assert dl._canonical_prose(a) in dl._authored_prose_text(rendered)
assert dl._canonical_prose(u['boundary']) in dl._authored_prose_text(rendered)
for token in ['Both determinant signs', 'every natural', 'including zero', 'every real',
              'Scalar', 'identifying that law', 'strict']:
    assert token in json.dumps(u,ensure_ascii=False), token
assert 'not yet identified with pi_A' in u['boundary']
assert 'role' in item['bindings'][0] and item['bindings'][0]['role'] == 'prerequisite'

out = W / 'isolated-static-reader'
out.mkdir(exist_ok=False)
(out / 'exact-lesson-fragment.html').write_text(rendered)
fixture = Path('_site/textbook/index.html')
(out / 'textbook').mkdir()
(out / 'textbook/index.html').write_bytes(fixture.read_bytes())
dl.export_sources(out, [u])
export = out / 'data/lesson-sources/Tests/GaussianComplexityFixedSpectrumDetector.lean.html'
etree = Tree(); etree.feed(export.read_text())
pre = etree.root.find('pre')
assert len(pre) == 1 and pre[0].text().encode() == C.read_bytes(), 'full exported raw Test code'
link = dl.source_link(next(s for s in u['sources'] if s.get('path') == str(C)), page)
assert link in html.unescape(rendered)
assert 'id="L18"' in export.read_text()

result = {'scope':'Actual isolated static renderer and exact local Test source export only. No browser, desktop/mobile, pixels, server, canonical build, sourceV or global acceptance.',
          'candidate':'65776f88e92b9680e6afe0d4c20b7390e4521241',
          'lesson_sha256':sha(lesson.read_bytes()),'publication_sha256':sha(publication.read_bytes()),
          'all_details_initially_closed':True,'details_count':len(details),'steps':snippet_results,
          'full_raw_Test_bytes_step6':True,'full_raw_Test_bytes_export':True,'source_link':link,
          'public_exact_statement_bytes':len(statement.encode()),'public_exact_statement_sha256':sha(statement.encode()),
          'public_exact_declaration_bytes':len(source.encode()),'public_exact_declaration_sha256':sha(source.encode()),
          'literal_fragment_sha256':sha(rendered.encode()),
          'source_export_sha256':sha(export.read_bytes()),
          'reused_theme_fixture':{'path':str(fixture),'size':fixture.stat().st_size,'sha256':sha(fixture.read_bytes()),
                                  'scope':'Reused old shell fixture only; no theorem/page/canonical credit.'}}
(W / 'static-reader-results.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
print(json.dumps(result,indent=2,ensure_ascii=False))
