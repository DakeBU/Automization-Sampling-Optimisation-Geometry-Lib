from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import urlparse,unquote
import json,hashlib,re
ROOT=Path('/Users/zhouhuanjian/ASTIS-GC')
OWN=Path(__file__).parent
PRE=ROOT/'.astis/huanjian-gc-matrix-laplace-20261114/reader-preview-v2'
P='AutoSamplingTheory/TechnicalLemmas/Probability/MatrixLaplaceTail.lean'
T='Tests/GaussianComplexityLaplaceTail.lean'
sha=lambda b:hashlib.sha256(b).hexdigest()
class Page(HTMLParser):
 def __init__(self):
  super().__init__(convert_charrefs=True);self.pre=0;self.parts=[];self.blocks=[];self.details=[];self.stack=[];self.links=[];self.ids=set();self.panel=None
 def handle_starttag(self,t,attrs):
  a=dict(attrs)
  if a.get('id'):self.ids.add(a['id'])
  if t=='details':
   d={'attrs':a,'links':[],'blocks':[]};self.details.append(d);self.stack.append(d)
  if t=='a' and a.get('href'):
   r={'attrs':a};self.links.append(r)
   if self.stack:self.stack[-1]['links'].append(r)
  if t=='pre':
   self.pre+=1
   if self.pre==1:self.parts=[]
 def handle_endtag(self,t):
  if t=='pre':
   self.pre-=1
   if not self.pre:
    b=''.join(self.parts);self.blocks.append(b)
    if self.stack:self.stack[-1]['blocks'].append(b)
  if t=='details':self.stack.pop()
 def handle_data(self,d):
  if self.pre:self.parts.append(d)
def parse(p):
 x=Page();x.feed(p.read_text());return x
im=json.loads((PRE/'input-freeze-manifest.json').read_text())
pm=json.loads((PRE/'preview-freeze-manifest.json').read_text())
input_bad=[]
for r in im['files']:
 if sha((PRE/'input-snapshot'/r['path']).read_bytes())!=r['sha256']:input_bad.append(r['path'])
fixture_bad=[]
for variant,rec in pm['variants'].items():
 for r in rec['files']:
  if sha((PRE/'fixtures'/variant/r['path']).read_bytes())!=r['sha256']:fixture_bad.append(variant+'/'+r['path'])
assert not input_bad and not fixture_bad
assert sha((PRE/'input-freeze-manifest.json').read_bytes())==pm['input_freeze_manifest_sha256']
assert sha((PRE/'render_preview.py').read_bytes())==pm['generator_sha256']
assert sha((PRE/'reader_overlay.py').read_bytes())==pm['overlay_sha256']
u=json.loads((ROOT/'website/content/declaration_lessons/huanjian-matrix-laplace-tail.json').read_text())['units'][0]
step_rows=[]
for no,s in enumerate(u['steps'],1):
 f=ROOT/s['lean_source_path'];b=f.read_bytes();txt=b.decode();loc=s['lean_source'];lo,hi=loc['LF_lines_1based'];clo,chi=loc['decoded_char_span'];blo,bhi=loc['raw_UTF8_byte_span'];span=s['lean'].encode()
 assert sha(b)==loc['file_sha256']
 assert ''.join(txt.splitlines(keepends=True)[lo-1:hi])==s['lean']
 assert txt[clo:chi]==s['lean'] and b[blo:bhi]==span
 assert sha(span)==loc['span_sha256']
 step_rows.append({'step':no,'path':s['lean_source_path'],'lines':[lo,hi],'all_offsets_and_span_hash_match':True})
assert [s['lean_source_path'] for s in u['steps']]==[P]*3+[T]*3
assert ''.join(s['lean'] for s in u['steps'] if s['lean_source_path']==P).encode()==(ROOT/P).read_bytes()
assert ''.join(s['lean'] for s in u['steps'] if s['lean_source_path']==T).encode()==(ROOT/T).read_bytes()
source_rows=[];page_rows=[]
for variant in ['original','candidate']:
 froot=PRE/'fixtures'/variant
 for path in [P,T,'AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumSourceMatrixRadius.lean','AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumSourceMatrixStructure.lean']:
  expected=(PRE/'input-snapshot'/path).read_bytes();pg=froot/'data/lesson-sources'/(path+'.html');a=parse(pg)
  assert a.blocks==[expected.decode()]
  assert (froot/'downloads/lean'/path).read_bytes()==expected
  assert (ROOT/path).read_bytes()==expected
  assert {f'L{i}' for i in range(1,len(expected.decode().splitlines())+1)}<=a.ids
  source_rows.append({'variant':variant,'path':path,'exact_source_text_download_and_current_source_match':True,'line_anchors_complete':True})
 for rel in [pm['variants'][variant]['proof_path'],pm['variants'][variant]['lesson_path']]:
  pg=froot/rel;a=parse(pg)
  for s in u['steps']:assert s['lean'] in a.blocks
  step_panels=[d for d in a.details if 'data-mgf-step' in d['attrs']]
  if variant=='candidate':
   assert len(step_panels)==6
   for no,(s,d) in enumerate(zip(u['steps'],step_panels),1):
    assert 'open' not in d['attrs']
    assert d['attrs']['data-mgf-step']==str(no)
    assert d['attrs']['data-step-source-path']==s['lean_source_path']
    assert d['blocks']==[s['lean']]
    dl=[x['attrs'] for x in d['links'] if 'download' in x['attrs']];sl=[x['attrs'] for x in d['links'] if 'data-step-source' in x['attrs']]
    assert len(dl)==len(sl)==1
    for x in [dl[0],sl[0]]:
     z=urlparse(x['href']);target=(pg.parent/unquote(z.path)).resolve();assert target.is_file()
     if z.fragment:assert z.fragment in parse(target).ids
    assert (pg.parent/unquote(urlparse(dl[0]['href']).path)).resolve().read_bytes()==(ROOT/s['lean_source_path']).read_bytes()
  page_rows.append({'variant':variant,'page':rel,'all_six_exact_code_blocks':True,'candidate_closed_step_panels':len(step_panels),'candidate_adjacent_source_download_exact':variant=='candidate'})
# Every formula/equation anchor named by authored attribution exists in the pinned original HTML.
raw=(ROOT/'.astis/semantic-neutral-20261114/laplace_fresh_source_8d2a/phase1/inputs/.astis__huanjian-handoff-20261019__2610.20492v1.html').read_text()
source_anchors=sorted({r['anchor'] for s in u['steps'] for r in s['source_attribution'] if 'anchor' in r}|{urlparse(r['url']).fragment for r in u['sources'] if r.get('url','').startswith('https://arxiv.org/html/')})
assert all('id="'+a+'"' in raw for a in source_anchors)
# Compare text payloads and graphs; local layout wrappers do not alter proof code.
for rel in [pm['variants']['candidate']['proof_path'],pm['variants']['candidate']['lesson_path']]:
 assert parse(PRE/'fixtures/original'/rel).blocks==parse(PRE/'fixtures/candidate'/rel).blocks
assert (PRE/'fixtures/original/data/underlying-lean-graph.json').read_bytes()==(PRE/'fixtures/candidate/data/underlying-lean-graph.json').read_bytes()
g=json.loads((PRE/'fixtures/candidate/data/underlying-lean-graph.json').read_text())
assert not any('actual_source_four_sums_laplace_tail' in n['id'] for n in g['nodes'])
assert all(n['status']=='partial' for n in g['nodes'])
css0=(PRE/'fixtures/original/assets/site-base.css').read_bytes();css1=(PRE/'fixtures/candidate/assets/site-base.css').read_bytes()
assert css0.partition(b'\n')[2]==css1
ctx=json.loads((ROOT/'.astis/huanjian-gc-matrix-laplace-20261114/publication-context.authored-v2.original.json').read_text())
assert ctx['publication_binding_sha256']=='d38d9501aa243dd110c5bb7958f2a86869fa6ec54b5a373b7d2928df84f3afe8'
assert ctx['publication_context']['current_lean_module'].encode()==(ROOT/P).read_bytes()
context_lesson=ctx['publication_context']['lesson']
assert context_lesson=={k:v for k,v in u.items() if k!='boundary'}
context_lesson_omitted_keys=sorted(set(u)-set(context_lesson))
result={'status':'STATIC_REVIEW_CHECKS_COMPLETED_NO_BROWSER','reviewer':'/root/laplace_fresh_source_8d2a','input_hashes_verified':len(im['files']),'fixture_hashes_verified':sum(len(v['files']) for v in pm['variants'].values()),'proof_commit_manifest':im['proof_commit'],'binding_stored_value_matches_expected':ctx['publication_binding_sha256'],'binding_digest_recomputed':False,'context_full_module_and_shared_lesson_fields_match_literal_current_inputs':True,'context_lesson_omitted_current_keys':context_lesson_omitted_keys,'step_spans':step_rows,'sources':source_rows,'reader_pages':page_rows,'raw_source_anchors_exist':source_anchors,'graphs_identical_and_all_partial':True,'private_T_not_a_declaration_node':True,'candidate_font_change_exactly_first_import_line_removed':True,'runtime_not_checked':['pixels','glyph rendering','layout sizes','horizontal scroll usability','clipboard','anchor landing','downloads via browser','graph interaction'],'note':'Checks are independent static parsing/hash/locator checks only. No renderer, Lean, API, Git, browser or production mutation was executed.'}
(OWN/'static_checks.json').write_text(json.dumps(result,indent=2)+'\n')
# Snapshot every mathematical/prose/source page read; assets remain hash-bound by copied manifests.
selected=[ROOT/P,ROOT/T,ROOT/'website/content/declaration_lessons/huanjian-matrix-laplace-tail.json',ROOT/'website/content/publications/huanjian-matrix-laplace-tail.json',ROOT/'.astis/huanjian-gc-matrix-laplace-20261114/publication-context.authored-v2.original.json',PRE/'input-freeze-manifest.json',PRE/'preview-freeze-manifest.json',PRE/'reader_overlay.py',PRE/'reader_overlay.py.exact.diff',PRE/'render_preview.py']
selected += [ROOT/'AutoSamplingTheory/ExampleCases/GaussianComplexity'/x for x in ['FixedSpectrumSourceMatrixRadius.lean','FixedSpectrumSourceMatrixStructure.lean','FixedSpectrumSourceMatrixMean.lean']]
for variant in ['original','candidate']:
 selected += [PRE/'fixtures'/variant/r['path'] for r in pm['variants'][variant]['files'] if r['path'].endswith('.html') or r['path'].endswith('underlying-lean-graph.json') or r['path'].endswith('mgf-reader-overlay.css')]
manifest=[]
for f in dict.fromkeys(selected):
 data=f.read_bytes();rel=str(f.relative_to(ROOT));dst=OWN/'inputs'/rel.replace('/','__');dst.write_bytes(data);manifest.append({'source':str(f),'snapshot':str(dst),'sha256':sha(data),'bytes':len(data)})
(OWN/'input_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'static_result':str(OWN/'static_checks.json'),'inputs_snapshotted':len(manifest),'input_hashes_verified':len(im['files']),'fixture_hashes_verified':result['fixture_hashes_verified'],'six_spans_exact':True,'source_anchors_exist':source_anchors},indent=2))
