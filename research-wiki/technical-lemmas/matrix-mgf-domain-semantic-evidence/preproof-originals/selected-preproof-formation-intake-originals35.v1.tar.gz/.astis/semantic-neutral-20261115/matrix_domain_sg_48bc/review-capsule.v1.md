# Matrix MGF domain source-only capsule

Exact seal: `1b52776e9793f302109cb649dd0c82c666193086aa7546006e36651ee389e638`. Binder audit was independently rehashed only: `ab17ddb4d2b402194af7b4668054d580956a80a103da938a25978d94e03e7744`. Both raw source hashes match the seal.

`source-graph.v1.json` contains printed source claims, consumer-site edges, explicit SOURCE_GAP nodes and an exhaustive bounded inventory: all 93 C.2 paragraph/display/title records, plus enumerated Tropp §§2.1–2.7 and3.1 items. Total dispositions: 55 NODE and 63 EXCLUDED. Source graph extraction is unreviewed.

`author-derived-bridges.v1.json` is separate. It contains the exact sealed P/T statements and nonformal mathematical obligations for measurability/Bochner integration, strict PD of a true matrix mean, trace commutation, and the deterministic full-law envelope for all real s and both signs of both families. P is Level B author-derived infrastructure; T is a private concrete consumer. These are not printed source theorems. The two sufficient mean-PD routes are OR alternatives.

Source boundaries: Ex107–112 are read literally; Ex121/p15.2 records the consumer only. Variance/fourth-moment, Bernstein, concentration optimization, FactC.6/Lemma4.4, matrix-log theorems, lower-bound completion, and oracle/cost adapters are explicitly outside this task.

Source gaps: GAP-FINITE-MATRIX-INTEGRATION, GAP-STRICT-MEAN-PD, GAP-FOUR-MGF-ENVELOPE, GAP-TRACE-COMMUTE. A gap means the bridge is not printed in the bounded source; no Lean discharge is asserted.

Independence: only the exact seal, hash-only binder file, current instructions and the two pinned raw sources were read for mathematical extraction. No implementation Lean, previous source graph/review, or proposal script was read. Raw Tropp pp.7–9 were text-extracted and visually inspected. Gaussian C.2 was reconstructed from raw HTML math alttext with source ids. No shared source, ledger, frontier, Registry, site or API was modified.

The topology reviewer receives this capsule, the two JSON records, the exact seal and the two raw sources. There are no earlier verdicts or extractor private rationale in this packet. This capsule supplies no self-approval or independent-admission verdict.
