import AutoSamplingTheory.ExampleCases.ProximalBPS.ActualFiniteCountPath
open scoped NNReal ENNReal
namespace PBPSDensityAlgebra94

theorem product_survival (n : ℕ) (r : Fin n → ℝ) (h : Fin (n+1) → ℝ) :
    (∏ i : Fin n, r i * Real.exp (-h i.castSucc)) * Real.exp (-h (Fin.last n)) =
      Real.exp (-(∑ j : Fin (n+1), h j)) * ∏ i : Fin n, r i := by
  rw [Finset.prod_mul_distrib, ← Real.exp_sum, ← mul_assoc, mul_assoc,
    ← Real.exp_add, Fin.sum_univ_castSucc, neg_add, Finset.sum_neg_distrib]
  ring

#print axioms product_survival
end PBPSDensityAlgebra94
