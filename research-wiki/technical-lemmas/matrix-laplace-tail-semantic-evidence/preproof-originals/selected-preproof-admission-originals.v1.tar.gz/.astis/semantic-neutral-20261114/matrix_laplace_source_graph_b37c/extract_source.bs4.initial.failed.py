import json, pathlib
from bs4 import BeautifulSoup
BASE = pathlib.Path(__file__).resolve().parent
path = pathlib.Path('/Users/zhouhuanjian/ASTIS-GC/.astis/huanjian-handoff-20261019/2610.20492v1.html')
soup = BeautifulSoup(path.read_bytes(), 'html.parser')
requested = ['S2.Ex85','S2.Ex107','S2.p10','S2.p13','S2.Ex112','S2.Ex121','S2.p15','S2.p15.2']
found = []
for short in requested:
    elems = soup.find_all(id=lambda v: bool(v) and (v == short or v.endswith('.'+short) or v.endswith(short.split('.')[-1])))
    for e in elems:
        if e.get('id') not in [v['id'] for v in found]:
            found.append({'id': e['id'], 'tag': e.name, 'text': e.get_text(' ',strip=True), 'html':str(e)})
context=[]
for e in soup.find_all(['p','div']):
    if e.name=='div' and ('ltx_para' not in e.get('class',[])):
        continue
    text=e.get_text(' ',strip=True)
    if len(text)<6000 and ('g_{q+1}' in str(e) or ('angle' in text.lower() and ('C2' in str(e.get('id')) or 'Gaussian' in text))):
        context.append({'id':e.get('id'), 'tag':e.name,'text':text,'html':str(e)})
data={'requested':requested,'anchors':found,'nearby_g_angles_search_matches':context}
(BASE/'gaussian-selected.raw.json').write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n')
for a in found:
    print(a['id'], a['tag'], '\n'+a['text']+'\n')
print('CONTEXT MATCHES',len(context))
for a in context:
    print(a['id'], '\n'+a['text']+'\n')
