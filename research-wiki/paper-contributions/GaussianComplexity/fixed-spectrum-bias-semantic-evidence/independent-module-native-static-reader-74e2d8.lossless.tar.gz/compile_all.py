from pathlib import Path
import subprocess,sys,json
r=Path(__file__).resolve().parent;repo=r.parents[2]
parents=["AutoSamplingTheory/TechnicalLemmas/StochasticProcesses/GaussianFourthMoment.lean","AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumGaussianMoments.lean","AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumCosineExpansion.lean","AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumGridAlias.lean","AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumExactMeans.lean"]
for i,s in enumerate(parents+["AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumVariances.lean","AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumBias.lean","Tests/GaussianComplexityFixedSpectrumBias.lean"]):
 out=r/"oleans"/Path(s).with_suffix(".olean")
 out.parent.mkdir(parents=True,exist_ok=True)
 if out.is_symlink():out.unlink()
 label="isolated-final-"+str(i)+"-"+Path(s).stem
 result=subprocess.run([sys.executable,str(r/"run_recorded.py"),label,"lean","-o",str(out),s],cwd=repo)
 if result.returncode:sys.exit(result.returncode)

sys.exit(0)
