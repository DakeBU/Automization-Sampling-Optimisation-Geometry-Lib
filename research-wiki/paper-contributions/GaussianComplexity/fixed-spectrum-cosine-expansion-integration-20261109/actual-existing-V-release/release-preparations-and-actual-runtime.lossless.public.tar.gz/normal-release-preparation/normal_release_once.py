"""Dedicated existing-C7-V release preparation. Future acceptance refs are NULL: disabled."""
from pathlib import Path
import argparse, copy, gzip, hashlib, json, subprocess, sys
from datetime import datetime, timezone

sys.dont_write_bytecode = True
ROOT = Path('/Users/zhouhuanjian/ASTIS-GC')
PREP = Path(__file__).resolve().parent
ADV = 'ASTIS-SA-20261109-GaussianComplexityFixedSpectrumCosineExpansion'
VERIFIER = '/root/cosine_fresh_source_5d8c2a'
sha = lambda b: hashlib.sha256(b).hexdigest()
def load(p): return json.loads(Path(p).read_bytes())
def put(p, x):
    with Path(p).open('xb') as f:
        f.write((json.dumps(x, ensure_ascii=False, indent=2)+'\n').encode())

def complete_records(raw):
    # Pure: never call current_advances/load_jsonl/recover_jsonl before this check.
    if raw and not raw.endswith(b'\n'):
        raise RuntimeError('HOLD: incomplete ledger tail; no recovery or API permitted')
    records = [json.loads(line) for line in raw.splitlines() if line.strip()]
    if not all(isinstance(record, dict) for record in records):
        raise RuntimeError('HOLD: non-object JSONL record')
    return records


def replay(records):
    # Exact pure replay semantics inspected in astis_advance.py:344-389.
    state = {}
    for record in records:
        event, advance_id = record.get('event'), record.get('advance_id')
        if not isinstance(advance_id, str) or not advance_id:
            continue
        if event == 'proposal':
            item = dict(record)
            item.setdefault('frontier_cell', 'global')
            item.setdefault('target_declarations', [])
            item.setdefault('checkpoint_count', 0)
            item.setdefault('no_progress_streak', 0)
            item.setdefault('needs_diagnosis', False)
            state[advance_id] = item
            continue
        if advance_id not in state:
            continue
        current = state[advance_id]
        if event == 'transition':
            to_state = record.get('to_state', current.get('state'))
            current['state'] = to_state
            current['last_actor'] = record.get('worker_id', current.get('last_actor', ''))
            if to_state == 'CLAIMED':
                current['owner_id'] = record.get('worker_id', '')
                current['no_progress_streak'], current['needs_diagnosis'] = 0, False
            current['modes'] = list(record.get('modes') or current.get('modes') or [])
            if record.get('evidence'):
                current['latest_evidence'] = record['evidence']
                if to_state == 'PROVED_LOCAL' and record['evidence'].get('publication_declarations'):
                    current['publication_declarations'] = record['evidence']['publication_declarations']
            current['updated_at'] = record.get('created_at', current.get('updated_at'))
        elif event == 'checkpoint':
            previous = current.get('latest_checkpoint') or {}
            same = (previous.get('route_fingerprint') == record.get('route_fingerprint') and
                    previous.get('progress_signature') == record.get('progress_signature'))
            streak = int(current.get('no_progress_streak', 0)) + 1 if same else 1
            current['checkpoint_count'] = int(current.get('checkpoint_count', 0)) + 1
            current['no_progress_streak'] = streak
            current['needs_diagnosis'] = streak >= 3
            current['latest_checkpoint'] = dict(record)
            current['updated_at'] = record.get('created_at', current.get('updated_at'))
    return state


def authorize(path, phase):
    if path is None:
        raise RuntimeError('DISABLED: no separate root authorization')
    path = Path(path).resolve()
    assert not path.is_relative_to(PREP)
    auth = load(path)
    mraw = (PREP/'manifest.json').read_bytes()
    assert auth['actor'] == '/root' and auth['original_source_verifier'] == VERIFIER
    assert auth['prepared_manifest_sha256'] == sha(mraw)
    for f in json.loads(mraw)['files']:
        b = (PREP/f['path']).read_bytes()
        assert sha(b) == f['sha256'] and len(b) == f['bytes']
    if phase == 'preflight':
        assert auth['action'] == 'authorize-existing-V-release-readonly-preflight'
        assert auth['preflight_enabled'] is True and auth['execution_enabled'] is False
    else:
        assert auth['action'] == 'authorize-one-existing-V-release'
        assert auth['execution_enabled'] is True and auth['max_normal_API_calls'] == 1
        assert auth['exclusive_serialized_window_confirmed'] is True
    return auth, {'path': str(path), 'sha256': sha(path.read_bytes())}


def require_actual_future_bindings(c):
    # No invented future report schema or authorization-provided PASS wrapper.
    # A future immutable successor must bind the actual reports after original-verifier review.
    refs = c['future_acceptance_refs']
    if any(value is None for value in refs.values()):
        raise RuntimeError('HOLD: actual browser48/pixels48/local acceptance/eligibility unbound; no release')
    for ref in refs.values():
        assert set(ref) == {'path', 'sha256'}
        assert sha((ROOT/ref['path']).read_bytes()) == ref['sha256']
    return refs


def fixed_checks(c):
    head = subprocess.run(['git','rev-parse','HEAD'],cwd=ROOT,capture_output=True,check=True).stdout.decode().strip()
    assert head == c['integration_core']
    for f in c['fixed_files']:
        b = (ROOT/f['path']).read_bytes()
        assert sha(b) == f['sha256'] and len(b) == f['bytes']
    actual = load(PREP/c['core_artifact_bindings'])
    for r in actual['actual_records']:
        b = (ROOT/r['receipt']).read_bytes(); receipt = json.loads(b)
        assert sha(b) == r['receipt_sha256']
        assert receipt['head_before'] == receipt['head_after'] == c['integration_core']
        assert receipt['exit_code'] == 0
        compressed = (ROOT/r['compressed_log']).read_bytes()
        assert sha(compressed) == r['compressed_log_sha256']
        assert sha(gzip.decompress(compressed)) == r['uncompressed_log_sha256']
    original = load(PREP/'original-source-V.exact.jsonl')
    assert sha((PREP/'original-source-V.exact.jsonl').read_bytes()) == c['original_V_append_sha256']
    assert original['worker_id'] == original['evidence']['verifier_id'] == VERIFIER
    assert original['evidence']['verified_commit'] == c['checked_source_commit']
    assert original['evidence'] == load(PREP/'original-source-V-evidence.json')
    assert len(original['evidence']) == 13 and 'post_integration' not in original['evidence']
    return original['evidence']


def snapshot(c):
    raw = (ROOT/c['advance_ledger']).read_bytes()
    records = complete_records(raw)  # pure full JSONL validation before any recovering API
    states = replay(records)
    foreign = {k:v for k,v in states.items() if k != ADV}
    assert len(foreign) == 286 and states[ADV]['owner_id'] == c['source_owner']
    frontier = {p.relative_to(ROOT).as_posix():sha(p.read_bytes())
                for p in sorted((ROOT/'research-wiki/frontier-cells').rglob('*.json'))}
    assert c['own_frontier'] in frontier and len(frontier)-1 == 445
    protected = {name:sha((ROOT/name).read_bytes()) for name in c['protected_models_and_discovery']}
    complete_records((ROOT/c['discovery_ledger']).read_bytes())
    return raw, {'all_states':states, 'foreign_states':foreign, 'frontier':frontier,
                 'protected_models_and_discovery':protected,
                 'audit_sha256':sha((ROOT/c['audit_path']).read_bytes()),
                 'ledger_sha256':sha(raw), 'ledger_bytes':len(raw)}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('phase',choices=['preflight','execute'])
    p.add_argument('--authorization',type=Path)
    p.add_argument('--out',type=Path,required=True)
    a = p.parse_args()
    auth, authref = authorize(a.authorization,a.phase)
    c = load(PREP/'release-contract.json')
    refs = require_actual_future_bindings(c)  # NULL now; this preparation cannot release
    original = fixed_checks(c)
    out = a.out.resolve(); allowed = (ROOT/c['allowed_runtime_root']).resolve()
    assert out.is_relative_to(allowed) and out != allowed
    before, snap = snapshot(c)
    assert sha(before) == c['prepared_live_ledger_sha256']
    current = snap['all_states'][ADV]
    assert current['state'] == 'STABILIZING'
    assert current['latest_evidence']['integration_owner'] == c['integration_owner']
    assert [k for k,v in snap['all_states'].items() if v['state']=='STABILIZING'] == [ADV]
    lines = before.splitlines(keepends=True)
    assert (PREP/'original-source-V.exact.jsonl').read_bytes() in lines
    assert (PREP/'sole-STAB.exact.jsonl').read_bytes() in lines
    if a.phase == 'preflight':
        out.mkdir(parents=True,exist_ok=False)
        with (out/'before-ledger.exact.jsonl').open('xb') as f: f.write(before)
        put(out/'before-snapshot.json',snap)
        put(out/'preflight-receipt.json',{'status':'READONLY_RELEASE_PREFLIGHT_NOT_RELEASED',
            'normal_API_calls':0,'authorization':authref,
            'prepared_manifest_sha256':sha((PREP/'manifest.json').read_bytes()),
            'snapshot_sha256':sha((out/'before-snapshot.json').read_bytes()),
            'source_checked_commit':c['checked_source_commit'],'integration_core':c['integration_core']})
        return
    pre = (out/'preflight-receipt.json').read_bytes()
    assert sha(pre) == auth['preflight_receipt_sha256']
    assert load(out/'preflight-receipt.json')['normal_API_calls'] == 0
    assert load(out/'preflight-receipt.json')['prepared_manifest_sha256'] == sha((PREP/'manifest.json').read_bytes())
    assert snap == load(out/'before-snapshot.json')
    assert before == (out/'before-ledger.exact.jsonl').read_bytes()
    evidence = copy.deepcopy(original)
    layer = load(PREP/'post-integration-layer.template.json')
    for key,ref in refs.items():
        assert layer[key] is None
        layer[key] = copy.deepcopy(ref)
    evidence['post_integration'] = layer
    assert {k:v for k,v in evidence.items() if k!='post_integration'} == original
    assert set(evidence)-set(original) == {'post_integration'}
    put(out/'one-normal-release-attempt.once.json',{'authorization':authref,
        'source_verifier':VERIFIER,'prepared_manifest_sha256':sha((PREP/'manifest.json').read_bytes())})
    put(out/'actual-call-evidence.json',evidence)
    sys.path.insert(0,str(ROOT))
    from tools import astis_advance as advance
    assert advance._replay_advances(complete_records(before)) == snap['all_states']
    error = None
    try:
        advance.transition_advance(ADV,'VERIFIED',worker_id=VERIFIER,evidence=evidence,
            path=ROOT/c['advance_ledger'],discovery_path=ROOT/c['discovery_ledger'])
    except BaseException as exc:
        error = repr(exc)
    after = (ROOT/c['advance_ledger']).read_bytes()
    with (out/'after-observed-ledger.exact.jsonl').open('xb') as f: f.write(after)
    observation = {'API_call_attempts':1,'API_exception':error,'old_prefix_preserved':after.startswith(before),
                   'before_ledger_sha256':sha(before),'after_ledger_sha256':sha(after)}
    if after.startswith(before):
        added = after[len(before):]
        with (out/'actual-release-append.exact.jsonl').open('xb') as f: f.write(added)
        observation['actual_observed_append_sha256'] = sha(added)
    put(out/'API-observation.json',observation)
    assert error is None and after.startswith(before), 'HOLD: no retry/repair/manual append'
    rows = complete_records(after[len(before):]); assert len(rows) == 1
    event = rows[0]
    assert (event['advance_id'],event['from_state'],event['to_state']) == (ADV,'STABILIZING','VERIFIED')
    assert event['worker_id'] == VERIFIER and event['evidence'] == evidence
    assert {k:v for k,v in event['evidence'].items() if k!='post_integration'} == original
    _, post = snapshot(c)
    for key in ['foreign_states','frontier','protected_models_and_discovery','audit_sha256']:
        assert post[key] == snap[key]
    assert post['all_states'][ADV]['state'] == 'VERIFIED'
    assert post['all_states'][ADV]['owner_id'] == c['source_owner']
    fixed_checks(c)
    put(out/'after-snapshot.json',post)
    put(out/'actual-release-receipt.json',{'status':'OBSERVED_ONE_EXISTING_V_RELEASE',
        'normal_API_calls':1,'source_verifier':VERIFIER,'source_checked_commit':c['checked_source_commit'],
        'integration_core':c['integration_core'],'all_original13_evidence_fields_unchanged':True,
        'only_evidence_addition':'post_integration','actual_event_created_at_observed':event['created_at'],
        'actual_append_sha256':sha(after[len(before):]),'foreign_states_preserved':286,
        'foreign_raw_frontiers_preserved':445,'owncell_models_discovery_audit_unchanged':True,
        'source_owner_unchanged':c['source_owner'],'no_new_source_or_remote_or_purification_credit':True})


if __name__ == '__main__':
    main()
