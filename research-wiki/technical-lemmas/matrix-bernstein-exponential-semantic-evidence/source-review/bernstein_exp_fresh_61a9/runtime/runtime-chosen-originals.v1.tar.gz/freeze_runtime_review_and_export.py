#!/usr/bin/env python3
"""Freeze this reviewer's bounded presentation judgment; no browser or math execution."""
from pathlib import Path
import collections
import datetime as dt
import hashlib
import json
import tarfile

OWN = Path(__file__).resolve().parent
ROOT = OWN.parents[2]
NATIVE = ROOT / '.astis/semantic-neutral-20261114/bernstein_exp_native_72c4'
FINAL = OWN / 'presentation-runtime-review-final'
FINAL.mkdir(exist_ok=False)


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def ref(path):
    path = Path(path)
    return {'path': str(path.relative_to(ROOT)), 'sha256': digest(path), 'bytes': path.stat().st_size}


def load(path):
    return json.loads(Path(path).read_text())


def write(name, obj):
    path = FINAL / name
    with path.open('x') as stream:
        stream.write(json.dumps(obj, indent=2, ensure_ascii=False) + '\n')
    return path


now = dt.datetime.now(dt.timezone.utc).isoformat()
source_archive = OWN / 'chosen-originals.v1.tar.gz'
assert digest(source_archive) == 'b7f92c0f50512871f5be13ead69565c7b19806dbeb8e47944172f1ecb29ab093'
prior_v3_path = OWN / 'presentation-runtime-review-v3/independent-runtime-review.v3.json'
prior_v5_path = OWN / 'presentation-runtime-review-C2-v5/independent-runtime-review.C2-v5.observed.json'
prior_v3, prior_v5 = load(prior_v3_path), load(prior_v5_path)
assert digest(prior_v3_path) == '91613c54fbec3d56591a07214008e9a4ff737e3dbaf5f779ce341783e96873e7'
assert digest(prior_v5_path) == '766e719b5a17eca94bf0da1a68f1fdc4ec4c007aa7208449a2a36b9aec291aef'
assert prior_v3['accepted_isolated_candidate'] is False
assert prior_v5['accepted_isolated_candidate'] is False

report_paths = {
    'original': NATIVE / 'root-primary-browser-output-v3/original/actual-checks.json',
    'candidate_v3': NATIVE / 'root-primary-browser-output-v3/candidate/actual-checks.json',
    'isolated_candidate': NATIVE / 'root-primary-browser-output-v5/candidate/actual-checks.json',
    'graph_zoom': NATIVE / 'root-primary-graph-zoom-output/candidate/actual-checks.json',
}
expected_reports = {
    'original': '2c59e330141418ae36b6377b6e7aa21fc431b1e4cd8af7cea8793188656f4ee5',
    'candidate_v3': 'f36c3d9a4917682160d70c7c6e70fb980f98454c52dc664349a7bdd3fcedb3db',
    'isolated_candidate': '22c4b9b5435891139431095aa1b3e997b44954f7fa3bccb6fb22de6f01b786b7',
    'graph_zoom': 'c313cbb71ead4e2486deb54957797e5c348170c061fc01c685375124dfb6e89c',
}
for key, path in report_paths.items():
    assert digest(path) == expected_reports[key]
reports = {key: load(path) for key, path in report_paths.items()}
assert reports['original']['status'] == reports['candidate_v3']['status'] == 'FAIL'
assert reports['isolated_candidate']['status'] == reports['graph_zoom']['status'] == 'PASS'
assert all(c['pass'] for k in ['isolated_candidate', 'graph_zoom'] for c in reports[k]['checks'])

process_dirs = {
    'original': 'root-primary-browser-process-v3/original',
    'candidate_v3': 'root-primary-browser-process-v3/candidate',
    'isolated_candidate': 'root-primary-browser-process-v5/candidate',
    'graph_zoom': 'root-primary-graph-zoom-process/candidate',
}
processes = {}
for key, directory in process_dirs.items():
    receipt_path = NATIVE / directory / 'process-receipt.json'
    receipt = load(receipt_path)
    assert receipt['actual_checks']['sha256'] == digest(report_paths[key])
    assert receipt['exit_code'] == (1 if key in ['original', 'candidate_v3'] else 0)
    streams = {}
    for stream in ['stdout', 'stderr']:
        stream_path = NATIVE / directory / (stream + '.raw')
        assert digest(stream_path) == receipt[stream]['sha256']
        assert stream_path.stat().st_size == receipt[stream]['bytes']
        streams[stream] = ref(stream_path)
    processes[key] = {'process_receipt': ref(receipt_path), 'exit_code': receipt['exit_code'],
                      **streams, 'actual_report_binding_matches': True}

graph = reports['graph_zoom']
assert len(graph['screenshots']) == 12 and len(graph['real_UI_actions']) == 19
assert digest(NATIVE / 'primary_graph_zoom_supplement.py') == '5fc8895cdae381ee61e8db16ca7a58580ca2481cc925c27bd4043fdbbd1859e2'
assert digest(NATIVE / 'root-primary-graph-zoom-contract.json') == 'e2397ec7db5845440235d20120fe978319a9222aedd70aea9b7b6338c4042f26'
for key, report in reports.items():
    for png in report['screenshots']:
        assert digest(NATIVE / png['path']) == png['sha256']

# Independently rehash the actual fixture trees and the one-line C2 delta.
original = NATIVE / 'reader-fixtures/original'
candidate = NATIVE / 'reader-fixtures/candidate'
c2 = NATIVE / 'reader-fixtures-c2/candidate'
tree_files = lambda p: {str(x.relative_to(p)): x for x in p.rglob('*') if x.is_file()}
candidate_files, c2_files = tree_files(candidate), tree_files(c2)
assert len(tree_files(original)) == 94 and len(candidate_files) == len(c2_files) == 95
assert candidate_files.keys() == c2_files.keys()
changed = [key for key in candidate_files if digest(candidate_files[key]) != digest(c2_files[key])]
assert changed == ['assets/site-base.css']
old_css = candidate_files[changed[0]].read_bytes()
new_css = c2_files[changed[0]].read_bytes()
removed_line = old_css.splitlines(keepends=True)[0]
assert removed_line.startswith(b'@import url("https://fonts.googleapis.com/')
assert old_css[len(removed_line):] == new_css
manifest = load(NATIVE / 'reader-render-manifest.C2.json')
for entry in manifest['variants']['candidate']['files']:
    assert digest(c2 / entry['path']) == entry['sha256']

graph_pngs = []
for png in graph['screenshots']:
    graph_pngs.append({**ref(NATIVE / png['path']),
                      'inspection': 'Actual PNG opened directly with view_image by independent reviewer; no crop, editing or synthetic image.'})

# A lossless path/hash/size index of selected native originals replaces duplicate payloads.
# Only these explicitly bounded reader directories and files are traversed.
external_files = set()
for directory in [original, candidate, c2,
                  *(NATIVE / p for p in process_dirs.values()),
                  *(p.parent for p in report_paths.values())]:
    for path in directory.rglob('*'):
        if path.is_file():
            external_files.add(path)
native_small_files = [
    'reader_overlay.py', 'render_bounded_reader.py', 'reader-render-manifest.json',
    'root-primary-browser-contract.v2.json', 'primary_browser_wrapper_v2.py',
    'root-primary-browser-contract.v3.json', 'primary_browser_wrapper_v3.py',
    'reader-render-manifest.C2.json', 'reader-C2-render-delta.json',
    'root-primary-browser-contract.v5.json', 'primary_browser_wrapper_v5.py',
    'root-primary-graph-zoom-contract.json', 'primary_graph_zoom_supplement.py',
]
external_files.update(NATIVE / name for name in native_small_files)
external_entries = [ref(path) for path in sorted(external_files)]
external = write('runtime-native-originals.external-refs.v1.json', {
    'artifact_kind': 'lossless-external-reference-manifest-not-duplicate-native-payload-archive',
    'reviewer': '/root/bernstein_exp_fresh_61a9', 'created_utc': now,
    'scope': 'Exact bounded reader original/candidate/C2 fixtures, actual v3/v5/graph PNGs, reports, downloads, genuine process receipts/streams, and their reader-only scripts/contracts/manifests.',
    'custody': 'Native reviewer final chosen-original archive is the carrier of these exact original bytes. This review archive carries path/SHA256/byte counts; local earlier input copies remain untouched and are excluded to avoid duplicate payloads.',
    'excluded': ['native mathematics or metadata gate reports', 'private state/index/maps/guards',
                 'package caches/venvs/builds', 'v2 launch failure output not read', 'unexecuted v4 preparations'],
    'actual_original_bytes_rehashed': True, 'file_count': len(external_entries),
    'total_bytes': sum(e['bytes'] for e in external_entries), 'files': external_entries,
})

history = write('runtime-history-and-scope.v1.json', {
    'reviewer': '/root/bernstein_exp_fresh_61a9', 'created_utc': now,
    'v2': {'disposition': 'ENV_BLOCKED', 'evidence_basis': 'ROOT message only; bundled Playwright executable absent before browser open, zero screenshots and candidate unrun. No v2 page verdict or result tree was consumed.'},
    'v3_original': {'disposition': 'REJECTED', 'actual_report': ref(report_paths['original']),
                    'genuine_exit_code': 1, 'failures': 'Missing T-step5 adjacent source/download, source filename/header, mobile table reach, document overflow, T mobile anchor obscured, external font requests; original graph screenshot coverage gap.'},
    'v3_candidate': {'disposition': 'HOLD', 'actual_report': ref(report_paths['candidate_v3']),
                    'genuine_exit_code': 1, 'program_failure': '12 attempted/blocked external Google Fonts requests.',
                    'independent_missing_evidence': 'Actual mobile graph canvas absent from PNG and formula right-end reach not captured.'},
    'v4': {'disposition': 'UNEXECUTED', 'evidence_basis': 'ROOT stated preserved preparation only; no runtime outcome inferred.'},
    'C2_v5_before_zoom': {'disposition': 'HOLD', 'actual_report': ref(report_paths['isolated_candidate']),
                          'genuine_exit_code': 0, 'program_status': 'PASS',
                          'independent_missing_evidence': 'Graph fit-scale labels tiny; selected/adjacent label legibility needed existing-UI zoom evidence.'},
    'graph_zoom': {'disposition': 'BOUNDED_GRAPH_CRITERION_SATISFIED', 'actual_report': ref(report_paths['graph_zoom']),
                   'genuine_exit_code': 0, 'program_status': 'PASS', 'no_full_reader_rerun': True},
    'history_preserved': [ref(prior_v3_path), ref(prior_v5_path)],
    'new_review_operational_failures': ['One long JSON print was truncated; report structure and bounded relevant fields were subsequently read directly. No browser, math or API was executed by this reviewer.'],
    'source_math_archive_unchanged': ref(source_archive),
})

report = write('independent-runtime-review.final.json', {
    'schema_version': 1, 'artifact_kind': 'independent-final-bounded-reader-runtime-and-actual-PNG-review',
    'created_utc': now, 'reviewer': '/root/bernstein_exp_fresh_61a9',
    'reviewer_identity': '/root/bernstein_exp_fresh_61a9',
    'reviewer_role': 'Independent raw-source, pre-outcome whole-code, source-fidelity and reader reviewer; distinct from formalizer, decoder, native preparer and ROOT browser runner.',
    'role_independence': {**prior_v5['role_independence'],
                          'no_normal_API_or_compiler_or_native_math_gate_verdict_consumed': True,
                          'preoutcome_criteria_frozen_before_actual_outcome_exposure': True},
    'immutable_reader_commit': '9a8b163f4753a1329dbc0435c1e7f810f729c349',
    'mathematical_candidate': '0ff1e2227b8e5a45a6a73906582ef042bd0d73ff',
    'immutable_math_commit': '0ff1e2227b8e5a45a6a73906582ef042bd0d73ff',
    'candidate_variant': 'isolated C2 offline font-import removal on the separately labelled presentation overlay; graph uses existing wheel/pan UI',
    'production_changes_applied': False,
    'accepted_isolated_candidate': True,
    'original_disposition': 'REJECTED_FOR_BOUNDED_READER_PRESENTATION',
    'verdict_scope': 'Accept the isolated C2 bounded desktop1440x1000/mobile390x844 presentation, using actual v5 reader/source/formula evidence plus the same-fixture graph-only real UI zoom/pan supplement. This does not apply production changes or certify main/site/purification, native touch gestures, compiler results, or full Bernstein/C6.',
    'actual_report_refs': {key: ref(report_paths[key]) for key in ['original', 'isolated_candidate']},
    'preoutcome_criteria': ref(OWN / 'presentation-runtime-review-v1/runtime-PNG-criteria.preoutcome.v1.json'),
    'static_presentation_review': ref(OWN / 'presentation-runtime-review-v1/presentation-overlay-static-review.v1.json'),
    'actual_wrapper': ref(NATIVE / 'primary_browser_wrapper_v5.py'),
    'actual_contract': ref(NATIVE / 'root-primary-browser-contract.v5.json'),
    'actual_process_evidence': processes,
    'graph_zoom_supplement': {
        'actual_checks': ref(report_paths['graph_zoom']),
        'process_receipt': processes['graph_zoom']['process_receipt'],
        'contract': ref(NATIVE / 'root-primary-graph-zoom-contract.json'),
        'wrapper': ref(NATIVE / 'primary_graph_zoom_supplement.py'),
        'actual_program_status': graph['status'], 'exit_code': processes['graph_zoom']['exit_code'],
        'checks': len(graph['checks']), 'failed_assertions': [], 'actual_PNG_count': 12,
        'all12_actual_PNGs_opened_directly': True,
        'real_UI_actions': {'total': len(graph['real_UI_actions']),
                            'by_viewport_and_action': dict(collections.Counter(a['viewport'] + ':' + a['action'] for a in graph['real_UI_actions'])),
                            'actual_action_records': graph['real_UI_actions']},
        'wrapper_review': 'Read complete exact source. SVG geometry/effective-font/style evaluation is observational. Document scrollIntoView positions the existing page; real mouse wheel changes widget zoom and real blank-SVG pointer drag pans. No direct SVG transform, graph state, node layout, CSS or data replacement is used. Exact P focus remains selected.',
        'same_C2_fixture': {'all95_actual_files_rehashed': True, 'no_fixture_bytes_changed': True,
                            'manifest': ref(NATIVE / 'reader-render-manifest.C2.json')},
        'v5_full_reader_PASS_report_unchanged': ref(report_paths['isolated_candidate']),
        'actual_PNGs': graph_pngs,
        'visual_judgment': 'Desktop/mobile selected and both adjacent node label strings are readable in dedicated fully visible-node captures at effective13.5px. Identifier abbreviation is intentional and the full P identity is readable in the detail panel. Solid curved structural edge and dashed curated source edge are visibly distinct in dedicated panned captures, with source/formal legend retained. Detail reader link and immediate prerequisites/consumer entries are readable. On mobile edges and complete endpoint labels are covered by separate panned images, not claimed simultaneously fitted into390px.',
        'limitations': ['Initial fit-scale label text remains tiny; acceptance requires the demonstrated existing wheel zoom/pan interaction.',
                        'Mobile means390x844 Chrome viewport with real wheel/pointer events; native touch/pinch accessibility was not exercised.',
                        'The faint nonselected T module is not promoted to a canonical private theorem node or formal completion claim.'],
    },
    'C2_exact_delta': prior_v5['C2_delta'],
    'all_preoutcome_areas': [
        {'area': 'initial proof and all7 expanded steps', 'judgment': 'ACCEPT_BOUNDED', 'basis': 'All seven exact148+240 source-line folds and readable desktop/mobile prose/formulas inspected; v5 byte-identical PNG reuse is disclosed in prior observed report.'},
        {'area': 'T step5 adjacency and full-module actions', 'judgment': 'ACCEPT_BOUNDED', 'basis': 'Actual T57 source destination and complete T download/hash; readable scoped action labels. Copy-module-opening label reviewed; clipboard behavior itself unexercised.'},
        {'area': 'source-assumption table right reach', 'judgment': 'ACCEPT_BOUNDED', 'basis': 'Actual right-scrolled mobile table visible, no document-wide overflow.'},
        {'area': 'P/T filename/header/anchors and complete source', 'judgment': 'ACCEPT_BOUNDED', 'basis': 'Actual P116/T57 below measured headers, complete P148/T240 files and downloads match frozen code hashes.'},
        {'area': 'longest source lines and final glyphs', 'judgment': 'ACCEPT_BOUNDED', 'basis': 'Every required actual segment reaches final positive-size glyph, vertically visible below actual headers.'},
        {'area': 'formula right endpoints', 'judgment': 'ACCEPT_BOUNDED', 'basis': 'Eight actual mobile right-end captures resolve v3 missing reach; actual maximum horizontal scroll and visible mathematical endings inspected.'},
        {'area': 'graph selected/adjacent labels, formal/overlay edges, detail/reader', 'judgment': 'ACCEPT_BOUNDED_WITH_EXISTING_UI_ZOOM', 'basis': 'All12 actual supplementary PNGs directly opened; geometry and real wheel/pan action records agree with readable images; unchanged C2 graph data/CSS/layout.'},
        {'area': 'runtime and fixture integrity', 'judgment': 'ACCEPT_BOUNDED', 'basis': 'v5 PASS202checks/50PNGs and graph PASS119checks/12PNGs, genuine exit0/raw fd streams and report/contract/wrapper hashes; no JS/external requests;95C2bytes unchanged.'},
    ],
    'selected_actual_PNGs': prior_v5['PNG_inspection']['images'] + graph_pngs,
    'PNG_custody': {'v3_total_referents': 76, 'v5_total_referents': 50,
                    'v5_new_or_changed_opened_directly': 19, 'v5_prior_byte_identical_reuse': 31,
                    'graph12_opened_directly': 12, 'all_referent_bytes_rehashed': True,
                    'native_payloads_carried_once_externally': ref(external)},
    'historical_reports_unchanged': [ref(prior_v3_path), ref(prior_v5_path)],
    'history': ref(history),
    'source_math_phase_preserved': {'archive': ref(source_archive),
                                    'P_overlay_v2': ref(OWN / 'P.audit-overlay.v2.json'),
                                    'T_overlay_v2': ref(OWN / 'T.audit-overlay.v2.json'),
                                    'source_run_v2': ref(OWN / 'source-reader-review.run.v2.json'),
                                    'whole_PT_code_freeze': ref(OWN / 'PT-whole-module-code-judgment.v1.json'),
                                    'no_source_math_acceptance_inferred_from_browser': True},
    'remaining_blocking_reader_deltas_for_this_scope': [],
    'unclaimed': ['production/main/site publication or purification', 'full matrix Bernstein/C6',
                  'native mathematics/compiler/gate outcomes', 'clipboard execution', 'native mobile touch/pinch',
                  'unexercised routes or full accessibility audit'],
})
receipt = write('independent-runtime-review.final.receipt.json', {
    'reviewer': '/root/bernstein_exp_fresh_61a9', 'frozen_utc': now,
    'final_judgment': ref(report), 'accepted_isolated_candidate': True,
    'production_changes_applied': False, 'preoutcome_criteria': ref(OWN / 'presentation-runtime-review-v1/runtime-PNG-criteria.preoutcome.v1.json'),
    'prior_hold_reports_preserved_unchanged': [ref(prior_v3_path), ref(prior_v5_path)],
    'external_native_originals': ref(external), 'source_archive_unchanged': ref(source_archive),
})

# Explicitly chosen OWN review products only. Native payloads are external refs.
chosen = [
    Path(__file__).resolve(),
    *sorted((OWN / 'presentation-runtime-review-v1').glob('*.json')),
    *sorted((OWN / 'presentation-runtime-review-v3').glob('*.json')),
    *sorted((OWN / 'presentation-runtime-review-C2-v5').glob('*.json')),
    external, history, report, receipt,
]
assert len(chosen) == len(set(chosen))
allowlist = write('runtime-export-allowlist.v1.json', {
    'artifact_kind': 'explicit-runtime-own-review-originals-allowlist', 'created_utc': now,
    'chosen_files': [ref(p) for p in chosen], 'file_count': len(chosen),
    'excludes': ['all native PNG/stream/fixture/download payloads and local input copies of them',
                 'static source archive payload already carried separately', 'all private state/index/maps/guards',
                 'package caches/venvs/build outputs', 'unrelated units', 'unfinished or self-referential archive/manifest'],
    'external_exact_originals_manifest': ref(external),
    'preserve_failure_history': [ref(prior_v3_path), ref(prior_v5_path), ref(history)],
})
members = chosen + [allowlist]
archive = FINAL / 'runtime-chosen-originals.v1.tar.gz'
with tarfile.open(archive, 'x:gz') as tf:
    for path in members:
        tf.add(path, arcname=str(path.relative_to(OWN)), recursive=False)
expected_members = {str(p.relative_to(OWN)): (p.stat().st_size, digest(p)) for p in members}
with tarfile.open(archive, 'r:gz') as tf:
    actual_members = tf.getmembers()
    assert len(actual_members) == len(expected_members)
    assert all(m.isfile() for m in actual_members)
    for member in actual_members:
        content = tf.extractfile(member).read()
        assert (len(content), hashlib.sha256(content).hexdigest()) == expected_members.pop(member.name)
assert not expected_members
archive_manifest = write('runtime-chosen-originals.manifest.v1.json', {
    'artifact_kind': 'completed-runtime-own-originals-archive-manifest', 'created_utc': now,
    'archive': ref(archive), 'explicit_allowlist': ref(allowlist),
    'regular_member_count': len(members), 'total_original_member_bytes': sum(p.stat().st_size for p in members),
    'archive_reopened_and_every_original_byte_hash_and_count_checked': True,
    'members': [dict(ref(p), archive_member=str(p.relative_to(OWN))) for p in members],
    'external_native_originals': ref(external), 'source_archive_unchanged': ref(source_archive),
    'no_self_reference': 'Completed archive and this post-archive manifest are not archive members.',
})
carrier = write('ROOT-runtime-carrier-allowlist.v1.json', {
    'reviewer': '/root/bernstein_exp_fresh_61a9', 'created_utc': now,
    'accepted_isolated_candidate': True, 'production_changes_applied': False,
    'carrier_files': [ref(p) for p in [archive, archive_manifest, report, receipt, external, allowlist]],
    'source_phase_carrier_unchanged': ref(OWN / 'ROOT-carrier-allowlist.v1.json'),
})
print(json.dumps({'final_report': ref(report), 'final_receipt': ref(receipt),
                  'runtime_archive': ref(archive), 'runtime_manifest': ref(archive_manifest),
                  'external_refs': ref(external), 'ROOT_carrier': ref(carrier),
                  'archive_member_count': len(members), 'external_original_count': len(external_entries),
                  'accepted_isolated_candidate': True}, indent=2))
