"""Freeze helper preparation only: AST/JSON syntax and own raw archive roundtrip."""
from pathlib import Path
import ast, datetime, gzip, hashlib, io, json, tarfile
R=Path('/Users/zhouhuanjian/ASTIS-GC')
S=R/'.astis/huanjian-gc-fixed-spectrum-determinant-integration-20261108/independent-reader'
P=R/'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-determinant-integration-20261108/independent-integration-reader-review/proposal'
O=P/'later-helper-preparation'
assert not O.exists(),'Preparation freeze already exists; preserve it.'
names=['det_acceptance_common.py','check_postcore.py','prepare_original38_review.py','verify_retained_browser_archive.py','record_local_acceptance.py','park_existing_verified_once.py','future-authorization.schema.json','original38-completed-review.schema.json','LATER_HELPERS.md','freeze_later_helpers.py']
sha=lambda b:hashlib.sha256(b).hexdigest()
raws={name:(S/name).read_bytes() for name in names}
for name,raw in raws.items():
 if name.endswith('.py'):ast.parse(raw,filename=str(S/name))
 if name.endswith('.json'):json.loads(raw)
assert sha((P/'proposal-report.json').read_bytes())=='ab826ff9e6fbbd2db0f0fa766ceadaccf470448152727e48b987bab0ae7161ac'
assert sha((P/'freeze.json').read_bytes())=='bd6fa76e2469cc23222ed70d4a8443e82adb39df3735cacdfcb9d595be071723'
assert sha((R/'.astis/huanjian-gc-fixed-spectrum-determinant-integration-20261108/check_final_reader.py').read_bytes())=='d191bcb9ea513e71e0c2357315dee1821fdcccdab6dc6a2f473d5289589f0766'
O.mkdir(exist_ok=False)
rows=[]
for name,raw in raws.items():
 archive=gzip.compress(raw,mtime=0);path=O/(name+'.raw.gz');path.write_bytes(archive)
 assert gzip.decompress(path.read_bytes())==raw
 rows.append({'path':str((S/name).relative_to(R)),'raw_sha256':sha(raw),'raw_bytes':len(raw),'raw_archive':str(path.relative_to(R)),'archive_sha256':sha(archive),'syntax_check':'ast.parse only; not imported/executed' if name.endswith('.py') else 'json.loads syntax only' if name.endswith('.json') else 'Read as preparation instructions'})
buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w') as tar:
 for name,raw in raws.items():
  info=tarfile.TarInfo(name);info.size=len(raw);info.mtime=0;info.uid=info.gid=0;info.uname=info.gname='';info.mode=0o644
  tar.addfile(info,io.BytesIO(raw))
archive=gzip.compress(buf.getvalue(),mtime=0);path=O/'prepared-helpers.tar.gz';path.write_bytes(archive)
with tarfile.open(fileobj=io.BytesIO(archive),mode='r:gz') as tar:
 assert tar.getnames()==names
 for name,raw in raws.items():assert tar.extractfile(name).read()==raw
manifest={'state':'PREPARATION_ONLY_AST_PARSED_NOT_EXECUTED','role':'/root/det_integration_reader','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_verifier_to_preserve':'/root/reader_835194','proof_owner_to_preserve':'huanjian_gc_20261108_fixed_spectrum_determinant','expected_integration_owner':'huanjian_gc_20261108_fixed_spectrum_determinant_integration','actual_postcore_protection_runs':0,'actual_original_image_views':0,'actual_acceptance_records':0,'actual_archive_evidence_verification_runs':0,'actual_normal_API_calls':0,'actual_build_site_browser_or_remote_actions':0,'authorization_or_placeholder_acceptance_file_created':False,'previous_conditional_proposal_report_sha256':'ab826ff9e6fbbd2db0f0fa766ceadaccf470448152727e48b987bab0ae7161ac','previous_checker_sha256':'d191bcb9ea513e71e0c2357315dee1821fdcccdab6dc6a2f473d5289589f0766','helpers':rows,'lossless_preparation_archive':{'path':str(path.relative_to(R)),'sha256':sha(archive),'members':len(names),'raw_members_individually_roundtrip_compared':True},'future_evidence_requirements':['Protection-only mode is resumable read only after real immutable core/sourceV/soleSTAB/shared integration; no placeholder site/browser required.','Final acceptance requires actual exactHEAD canonical Lean gate/site/graph/Chrome38, all38realoriginals independently viewed, actual lossless39member archive, and fresh full protection readback.','Normal existing-V parking requires distinct exact root authorization raw hash, exact prepared-script/manifest pins and actual core/gate/site/browser/independentacceptance/archive/sourceV/ledger pins. Persisted one-attempt guard, exactlyone normal API call, no automatic retry or rollback.','Unique genuine original sourceV by /root/reader_835194 and proving owner preserved;282foreignstates/441foreignfrontiers/alloldprotectedbytes/models unchanged. No new source verdict or parent legacy audit promotion.'],'truth_boundary':'Code/schema/documentation preparation only; no actual protection/visual/retention/acceptance/lifecycle/publication verdict. Previous admissibility helpers supplied implementation scaffolding only; none of their successful verdicts, commits or receipts is credited to this packet.'}
m=O/'preparation-manifest.json';m.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'state':manifest['state'],'manifest':str(m.relative_to(R)),'manifest_sha256':sha(m.read_bytes()),'archive_sha256':sha(archive),'helper_count':len(names),'python_files_ast_parsed':sum(name.endswith('.py') for name in names),'park_helper_sha256':sha(raws['park_existing_verified_once.py']),'common_helper_sha256':sha(raws['det_acceptance_common.py']),'executed_later_helpers':0},indent=2))
