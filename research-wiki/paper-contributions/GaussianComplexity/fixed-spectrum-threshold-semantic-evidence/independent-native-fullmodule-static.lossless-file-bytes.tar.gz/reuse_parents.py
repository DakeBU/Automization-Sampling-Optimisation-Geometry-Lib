from pathlib import Path
import json,hashlib,shutil
r=Path(__file__).resolve().parent;repo=r.parents[2];sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
configs={"module_74e2d8":("26a5b00f08bddbf3e13c62e495e0ab268eaad341ef6204a2fce1a291a278eb2f",{}),"module_8d91a6":("3e50cf4ff370eb3a43bb42557c6f8f3dc612f3db11bde66c5700e268dc354a42",{}),"module_6bc291":("b03582c72b2c874bbbe2a2896a2dc9d70dbd60f920e435f74d171df277b52904",{})}
for key,(expected,unused) in list(configs.items()):
 old=repo/".astis/semantic-neutral-20261110"/key;assert sha(old/"freeze.json")==expected
 assets={x["path"]:x for x in json.loads((old/"freeze.json").read_text())["artifacts"]}
 bindingFile="exact-input-check.json" if (old/"exact-input-check.json").exists() else "read-log.json"
 assert sha(old/bindingFile)==assets[bindingFile]["sha256"]
 bindings={x["path"]:x["sha256"] for x in json.loads((old/bindingFile).read_text())}
 for p in ["lean-toolchain","lake-manifest.json","lakefile.lean"]:assert sha(repo/p)==bindings[p],p
 assert sha(old/"toolchain.stdout.log")==sha(r/"toolchain.stdout.log")
 configs[key]=(old,assets,bindings,expected)
mods=[("module_6bc291","AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumSignalStrength.lean","isolated-producer"),("module_8d91a6","AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumModeGap.lean","isolated-producer"),("module_74e2d8","AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumBias.lean","isolated-final-6-FixedSpectrumBias"),("module_74e2d8","AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumExactMeans.lean","isolated-final-4-FixedSpectrumExactMeans"),("module_74e2d8","AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumGaussianMoments.lean","isolated-final-1-FixedSpectrumGaussianMoments"),("module_74e2d8","AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumCosineExpansion.lean","isolated-final-2-FixedSpectrumCosineExpansion"),("module_74e2d8","AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumGridAlias.lean","isolated-final-3-FixedSpectrumGridAlias"),("module_74e2d8","AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumVariances.lean","isolated-final-5-FixedSpectrumVariances"),("module_74e2d8","AutoSamplingTheory/TechnicalLemmas/StochasticProcesses/GaussianFourthMoment.lean","isolated-final-0-GaussianFourthMoment")]
rows=[];(r/"reused-native-evidence").mkdir(exist_ok=True)
for key,p,label in mods:
 old,assets,bindings,freezeHash=configs[key];assert sha(repo/p)==bindings[p],p
 obj="oleans/"+str(Path(p).with_suffix(".olean"));assert sha(old/obj)==assets[obj]["sha256"]
 rec=json.loads((old/(label+".receipt.json")).read_text());assert rec["exit_code"]==0
 for suffix in [".receipt.json",".stdout.log",".stderr.log"]:
  assert sha(old/(label+suffix))==assets[label+suffix]["sha256"]
  shutil.copyfile(old/(label+suffix),r/"reused-native-evidence"/(key+"--"+label+suffix))
 dest=r/obj;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(old/obj,dest)
 assert sha(dest)==assets[obj]["sha256"]
 rows.append({"source":p,"source_sha256":bindings[p],"object_sha256":sha(dest),"own_prior_freeze":key,"freeze_sha256":freezeHash,"receipt_sha256":sha(old/(label+".receipt.json")),"native_argv":rec["argv"],"stdout_sha256":rec["stdout_sha256"],"stderr_sha256":rec["stderr_sha256"],"exit_code":0,"fresh_parent_compilation_claim":False})
report={"method":"Nine unchanged canonical objects reused from own immutable native bindings, all current source/object/toolchain/manifest/evidence hashes verified","toolchain_sha256":sha(repo/"lean-toolchain"),"manifest_sha256":sha(repo/"lake-manifest.json"),"native_version_stdout_sha256":sha(r/"toolchain.stdout.log"),"objects":rows}
(r/"canonical-reuse.json").write_text(json.dumps(report,indent=2)+"\n");print(json.dumps({"objects":len(rows),"all_reuse_bindings_match":True,"fresh_parent_runs":0},indent=2))
