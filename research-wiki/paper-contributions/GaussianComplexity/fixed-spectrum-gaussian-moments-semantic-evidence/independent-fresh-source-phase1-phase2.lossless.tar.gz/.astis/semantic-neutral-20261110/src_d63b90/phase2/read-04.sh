python3 - <<'PY'
from pathlib import Path
from html.parser import HTMLParser
import hashlib,json,re
root=Path('/Users/zhouhuanjian/ASTIS-GC');p=root/'.astis/semantic-neutral-20261110/src_d63b90/phase1/phase1-freeze.json';b=p.read_bytes();assert hashlib.sha256(b).hexdigest()=='763446abce7e48ec32330ff4a7ee1538187a8fe9d9a80e6f29fa82b7276b054d';j=json.loads(b)
for x in j['files']:
    q=root/x['path'];assert hashlib.sha256(q.read_bytes()).hexdigest()==x['sha256']
src=root/'.astis/huanjian-resume-20261103/2610.20492v1.html';b=src.read_bytes();assert hashlib.sha256(b).hexdigest()=='6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915';s=b.decode()
class Text(HTMLParser):
    def __init__(self): super().__init__();self.parts=[];self.depth=0
    def handle_starttag(self,tag,attrs):
        if tag=='math':self.parts.append('$'+dict(attrs)['alttext']+'$');self.depth+=1
    def handle_endtag(self,tag):
        if tag=='math':self.depth-=1
    def handle_data(self,text):
        if not self.depth:self.parts.append(text)
print('Phase1 freeze verified:',len(j['files']),'files')
for ident in ['A3.SS3.p4.1','A3.SS3.p4.2','A3.SS3.p6.1']:
    m=re.search(r'<p id="'+re.escape(ident)+r'"[^>]*>',s);assert m;end=s.index('</p>',m.start())+4;t=Text();t.feed(s[m.start():end]);print(ident, ''.join(t.parts))
start=s.index('<table id="A3.Ex140"');end=s.index('</table>',start)+8;t=Text();t.feed(s[start:end]);print('A3.Ex140',''.join(t.parts))
start=s.index('<table id="A3.Ex144"');end=s.index('</table>',start)+8;t=Text();t.feed(s[start:end]);print('A3.Ex144',''.join(t.parts))
PY
