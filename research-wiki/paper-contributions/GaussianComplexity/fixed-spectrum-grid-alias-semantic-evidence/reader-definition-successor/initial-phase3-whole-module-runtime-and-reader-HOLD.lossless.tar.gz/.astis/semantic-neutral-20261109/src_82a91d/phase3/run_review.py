from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess
import sys

ROOT = Path('/Users/zhouhuanjian/ASTIS-GC')
OWN = ROOT / '.astis/semantic-neutral-20261109/src_82a91d/phase3'
CANDIDATE = 'cbf3c22b901a484c463f417a3e206bb200622294'
LOGS = OWN / 'runtime'
LOGS.mkdir(exist_ok=True)

def sha(data):
    return hashlib.sha256(data).hexdigest()

def run(label, argv, extra_env=None):
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT).decode().strip()
    assert head == CANDIDATE, head
    env = os.environ.copy()
    if extra_env:
        env.update(extra_env)
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    p = subprocess.run(argv, cwd=ROOT, env=env, capture_output=True)
    ended = datetime.datetime.now(datetime.timezone.utc).isoformat()
    for suffix, data in [('stdout', p.stdout), ('stderr', p.stderr)]:
        (LOGS / f'{label}.{suffix}.txt').write_bytes(data)
    receipt = {
        'label': label, 'argv': argv, 'cwd': str(ROOT), 'head': head,
        'started_utc': started, 'ended_utc': ended, 'exit_code': p.returncode,
        'extra_environment': extra_env or {},
        'stdout': {'path': str(LOGS / f'{label}.stdout.txt'), 'bytes': len(p.stdout), 'sha256': sha(p.stdout)},
        'stderr': {'path': str(LOGS / f'{label}.stderr.txt'), 'bytes': len(p.stderr), 'sha256': sha(p.stderr)},
        'head_after': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT).decode().strip(),
    }
    (LOGS / f'{label}.receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt, indent=2), flush=True)
    print(p.stdout.decode(errors='replace'), end='', flush=True)
    print(p.stderr.decode(errors='replace'), end='', file=sys.stderr, flush=True)
    if p.returncode:
        raise SystemExit(p.returncode)
    assert receipt['head_after'] == CANDIDATE
    return p.stdout.decode()

def environment():
    run('01-git-status', ['git', 'status', '--short', '--untracked-files=no'])
    run('02-lean-version', ['lake', 'env', 'lean', '--version'])
    lean = run('03-lean-executable', ['lake', 'env', 'which', 'lean']).strip()
    leanpath = run('04-lean-path', ['lake', 'env', 'printenv', 'LEAN_PATH']).strip()
    run('05-mathlib-head', ['git', '-C', '.lake/packages/mathlib', 'rev-parse', 'HEAD'])
    (LOGS / 'environment.json').write_text(json.dumps({'lean': lean, 'leanpath': leanpath}, indent=2) + '\n')

def compile_targets():
    e = json.loads((LOGS / 'environment.json').read_text())
    overlay = LOGS / 'overlay'
    relative = Path('AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumGridAlias')
    target = overlay / relative.with_suffix('.olean')
    target.parent.mkdir(parents=True, exist_ok=True)
    extra = {'LEAN_PATH': str(overlay) + ':' + e['leanpath']}
    run('06-fresh-producer', [e['lean'], '-o', str(target), str(ROOT / relative.with_suffix('.lean'))], extra)
    test = Path('Tests/GaussianComplexityFixedSpectrumGridAlias')
    test_target = overlay / test.with_suffix('.olean')
    test_target.parent.mkdir(parents=True, exist_ok=True)
    run('07-fresh-private-consumer', [e['lean'], '-o', str(test_target), str(ROOT / test.with_suffix('.lean'))], extra)
    run('08-kernel-dependency-literal-audit', [e['lean'], str(OWN / 'KernelAudit.lean')], extra)

def consumer_only():
    e = json.loads((LOGS / 'environment.json').read_text())
    overlay = LOGS / 'overlay'
    extra = {'LEAN_PATH': str(overlay) + ':' + e['leanpath']}
    test = ROOT / 'Tests/GaussianComplexityFixedSpectrumGridAlias.lean'
    target = overlay / 'Tests/GaussianComplexityFixedSpectrumGridAlias.olean'
    target.parent.mkdir(parents=True, exist_ok=True)
    run('07c-fresh-private-consumer', [e['lean'], '-o', str(target), str(test)], extra)
    run('08-kernel-dependency-literal-audit', [e['lean'], str(OWN / 'KernelAudit.lean')], extra)

if __name__ == '__main__':
    if sys.argv[1] == 'environment':
        environment()
    elif sys.argv[1] == 'compile':
        compile_targets()
    elif sys.argv[1] == 'consumer':
        consumer_only()
    elif sys.argv[1] == 'probe':
        e = json.loads((LOGS / 'environment.json').read_text())
        extra = {'LEAN_PATH': str(LOGS / 'overlay') + ':' + e['leanpath']}
        run(sys.argv[2], [e['lean'], str(OWN / sys.argv[3])], extra)
    else:
        raise SystemExit('unknown stage')
