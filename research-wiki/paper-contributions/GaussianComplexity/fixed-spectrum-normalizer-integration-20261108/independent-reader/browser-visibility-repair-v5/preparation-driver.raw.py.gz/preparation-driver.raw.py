"""Freeze native reading-mode/summary visibility repair; no Chrome execution."""
from pathlib import Path
from html.parser import HTMLParser
import ast,datetime,difflib,gzip,hashlib,json,subprocess
R=Path('/Users/zhouhuanjian/ASTIS-GC')
S=R/'.astis/huanjian-gc-fixed-spectrum-normalizer-integration-20261108/independent-reader'
PUBLIC=R/'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-normalizer-integration-20261108/independent-reader'
O=PUBLIC/'browser-visibility-repair-v5'
CORE='c8c157a69aaad4007cb801a781e980a27005bb02';DIGEST='92a908be0defdf1b5994f5ff4fe8a0e545cdca0f6c229cd1141c36338129bd21'
GPD='AutoSamplingTheory.TechnicalLemmas.Measure.GaussianPrecisionDensity.multivariateGaussian_eq_withDensity_of_posDef'
sha=lambda b:hashlib.sha256(b).hexdigest();dump=lambda x:(json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode()
def cmd(*a):return subprocess.check_output(a,cwd=R)
def desc(p):return {'path':str(p.relative_to(R)),'sha256':sha(p.read_bytes()),'bytes':len(p.read_bytes())}
def archive(name,b):
 p=O/name;assert not p.exists();p.write_bytes(gzip.compress(b,mtime=0));assert gzip.decompress(p.read_bytes())==b
 return {'path':str(p.relative_to(R)),'raw_sha256':sha(b),'gzip_sha256':sha(p.read_bytes()),'raw_bytes':len(b)}
def diff(a,b,pa,pb):return b''.join(difflib.diff_bytes(difflib.unified_diff,a.splitlines(keepends=True),b.splitlines(keepends=True),fromfile=pa.encode(),tofile=pb.encode()))
assert cmd('git','rev-parse','HEAD').decode().strip()==CORE and not O.exists()
site=R/'_site';meta=json.loads((site/'data/build-metadata.json').read_bytes());gate=json.loads((R/'.astis/site-lean-gate.json').read_bytes())
assert meta['git']['commit']==gate['commit']==CORE and meta['source_digest']==gate['source_digest']==DIGEST and gate['passed'] and meta['gate']['current']
sd=json.loads((site/'data/site-data.json').read_bytes());row=next(x for x in sd['registry_declarations'] if x['local_decl']==GPD);card=site/row['card'];rawcard=card.read_bytes()
assert sha(rawcard)=='bd4de0099d6e40a1412ce29c4ff1127cb6bcb127864003099fbb2530a1077a51'
sitejs=site/'assets/site.js';tutorjs=site/'assets/lean-tutor.js';tutorcss=site/'assets/lean-tutor.css';renderer=R/'tools/astis_site.py'
for generated,authored in [(sitejs,R/'website/static/site.js'),(tutorjs,R/'website/static/lean-tutor.js'),(tutorcss,R/'website/static/lean-tutor.css')]:assert generated.read_bytes()==authored.read_bytes()
class Probe(HTMLParser):
 def __init__(self):super().__init__();self.stack=[];self.article_depth=None;self.current=None;self.headers=[];self.paragraphs=[];self.buttons=[];self.detail_nodes=[]
 def handle_starttag(self,t,a):
  d=dict(a)
  if t in ('area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr'):return
  self.stack.append((t,d))
  if t=='details':self.detail_nodes.append({'attributes':d,'ancestors':list(self.stack)})
  if t in ('h2','p','button'):self.current={'tag':t,'attributes':d,'ancestors':list(self.stack),'text':''}
 def handle_data(self,s):
  if self.current is not None:self.current['text']+=s
 def handle_endtag(self,t):
  if self.current is not None and self.current['tag']==t:
   {'h2':self.headers,'p':self.paragraphs,'button':self.buttons}[t].append(self.current);self.current=None
  for i in range(len(self.stack)-1,-1,-1):
   if self.stack[i][0]==t:self.stack=self.stack[:i];break
p=Probe();p.feed(rawcard.decode());headings=[x for x in p.headers if x['text']=='Proof architecture'];paras=[x for x in p.paragraphs if x['text'].startswith('Compilation-only admission of the existing canonical density')];buttons=[x for x in p.buttons if x['attributes'].get('data-reading-mode')=='lean']
assert len(headings)==len(paras)==len(buttons)==1
assert not [x for x in headings[0]['ancestors'] if x[0]=='details']
assert not [x for x in paras[0]['ancestors'] if x[0]=='details']
html=rawcard.decode();assert html.index('<h2>Lean statement</h2>')<html.index('<h2>Proof architecture</h2>')<html.index(paras[0]['text'])
js=sitejs.read_text();fold=js[js.index('  function foldLeanFormalizationLens() {'):js.index('\n  function globalSearch() {')]
assert 'details.className = "formalization-lens"' in fold and 'details.appendChild(cursor)' in fold
tjs=tutorjs.read_text();modes=tjs[tjs.index('  function setReadingMode(mode) {'):tjs.index('\n  async function bootStudio(studio) {')]
assert 'details.open = true' in modes and 'details.open = false' in modes
css=tutorcss.read_text();cssblock=css[css.index('body[data-reading-mode="beginner"] .rigorous-lesson-panel,'):css.index('\n@media (max-width: 900px)')]
assert 'display: none !important' in cssblock and 'display: block' in cssblock
oldbrowser=S/'check_final_reader_v4.py';oldb=oldbrowser.read_bytes();assert sha(oldb)=='884d13001c6ff811ea3632a5b600e1cb34f881e91dfdce1ad8559506a18cbfc0'
oldblock='''            warning = page.locator('h2').filter(has_text='Proof architecture')
            warning.scroll_into_view_if_needed()
'''
newblock='''            warning = page.locator('h2').filter(has_text='Proof architecture')
            assert warning.count() == 1
            # The real reading-mode control exposes the CSS-hidden formalization
            # lens. Its handler opens the lens; reopen it through the real summary.
            lean_mode = page.locator('.lean-learning-studio button[data-reading-mode="lean"]')
            assert lean_mode.count() == 1 and lean_mode.is_visible()
            lean_mode.click()
            assert lean_mode.get_attribute('aria-pressed') == 'true'
            ancestors = warning.locator('xpath=ancestor::details')
            assert ancestors.count() == 1
            lens = ancestors.first
            assert 'formalization-lens' in lens.get_attribute('class').split()
            summary = lens.locator(':scope > summary')
            assert summary.count() == 1 and summary.is_visible()
            if lens.get_attribute('open') is not None:
                summary.click()
                assert lens.get_attribute('open') is None
            summary.click()
            assert lens.get_attribute('open') is not None and warning.is_visible()
            debt_paragraph = warning.locator('xpath=following-sibling::p[1]')
            assert debt_paragraph.count() == 1 and debt_paragraph.is_visible()
            for phrase in ('Compilation-only admission of the existing canonical density', 'historical source/publication audit debt', 'proved_locally without independent verification', 'no old sourceV or completed audit is claimed'):
                assert phrase in debt_paragraph.text_content(), phrase
            warning.scroll_into_view_if_needed()
'''
assert oldb.count(oldblock.encode())==1;newb=oldb.replace(oldblock.encode(),newblock.encode(),1);assert newb.replace(newblock.encode(),oldblock.encode(),1)==oldb
ast.parse(newb);newbrowser=S/'check_final_reader_v5.py';assert not newbrowser.exists()
oldwrapper=S/'proposal_binding_and_navigation_overlay_v4.py';oldw=oldwrapper.read_bytes();assert sha(oldw)=='28048881e1ec97d09434b139fca3d97902161b25a333549a4dcfd2b3f2ea36c1'
neww=oldw.decode()
def replace(a,b):
 global neww
 assert neww.count(a)==1,(a,neww.count(a));neww=neww.replace(a,b,1)
replace('Apply v3 proposal binding plus the exact frozen v4 browser navigation repair.','Apply v3 proposal binding plus the exact frozen v5 native visibility repair.')
replace('Only the catalog navigation block changes; all46image, source-lineage, exact-byte and acceptance gates remain unchanged.','Preserve v4 catalog navigation and expose the actual debt section by native mode/summary clicks; all46image, source-lineage, exact-byte and acceptance gates remain unchanged.')
oldpath=str(oldbrowser.relative_to(R));newpath=str(newbrowser.relative_to(R))
replace("'"+oldpath+"': '884d13001c6ff811ea3632a5b600e1cb34f881e91dfdce1ad8559506a18cbfc0'", "'"+oldpath+"': '884d13001c6ff811ea3632a5b600e1cb34f881e91dfdce1ad8559506a18cbfc0', '"+newpath+"': '"+sha(newb)+"'")
replace("'"+oldpath+"']","'"+newpath+"']")
replace("common.CHECKER=S/'check_final_reader_v4.py'","common.CHECKER=S/'check_final_reader_v5.py'")
neww=neww.encode();ast.parse(neww);newwrapper=S/'proposal_binding_and_visibility_overlay_v5.py';assert not newwrapper.exists()
failed=S/'browser/live-20261108T075309287225Z/report.json';fr=failed.read_bytes();f=json.loads(fr);assert sha(fr)=='39120b5f9ba14408d870b8e462dd78b5b8fd9b47da47af5e6bb3b96d1e1a6047'
assert f['status']=='failed' and len(f['screenshots'])==21 and len(f['pages'])==1 and len(f['graphs'])==0
log=R/'.astis/huanjian-resume-20261103/20261108T075258816464Z-fixed-spectrum-normalizer-final-browser-navigation-v4.log';fl=log.read_bytes();assert sha(fl)=='6c8947c77a0ae7da03ff0b0fa6cb2443af25371d33cae9290592ca18c3b57caa'
images=[]
for r in f['screenshots']:
 q=failed.parent/r['file'];assert sha(q.read_bytes())==r['sha256'];images.append(desc(q))
oldcontext=PUBLIC.parent/'actual-gates-browser-navigation-v4-context.json';context=json.loads(oldcontext.read_bytes());assert context['browser_checker_sha256']==sha(oldb)
oldowned={str(q.relative_to(R)):sha(q.read_bytes()) for base in [S,PUBLIC] for q in base.rglob('*') if q.is_file()}
protectedpaths=['AutoSamplingTheory.lean','Tests.lean','Tests/Basic.lean','AutoSamplingTheory/TechnicalLemmas/Registry.lean','website/content/samplewiki_companion_frontiers.json','research-wiki/sampling-sde-library/cards/AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumNormalizer.md','AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumNormalizer.lean','Tests/GaussianComplexityFixedSpectrumNormalizer.lean','website/content/declaration_lessons/huanjian-fixed-spectrum-normalizer.json','website/content/publications/huanjian-fixed-spectrum-normalizer.json','research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-normalizer.json','research-wiki/frontier-cells/ASTIS-SHARED-gaussian-precision-density.json','website/content/publications/gaussian-complexity-law-density.json','website/content/declaration_lessons/gaussian-complexity-law-density.json','website/content/graph_memory_index.json','website/content/functor_hypergraph.json','runs/substantive_advances.jsonl','runs/substantive_discoveries.jsonl']
protected={q:sha((R/q).read_bytes()) for q in protectedpaths}
O.mkdir();newbrowser.write_bytes(newb);newwrapper.write_bytes(neww)
bd=diff(oldb,newb,oldpath,newpath);wd=diff(oldw,neww,str(oldwrapper.relative_to(R)),str(newwrapper.relative_to(R)))
(O/'exact-visibility-repair.diff').write_bytes(bd);(O/'exact-wrapper-binding.diff').write_bytes(wd)
evidence={'reviewer':'/root/norm_integration_reader','method':'Read actual generated card HTML, deployed JS/CSS and authored renderer; no browser execution or runtime DOM mutation.','card':desc(card),'static_target_h2':headings[0],'static_actual_debt_paragraph':paras[0],'actual_native_lean_mode_button':buttons[0],'static_details_ancestors':0,'runtime_fold_source':{'file':desc(sitejs),'exact_function':archive('foldLeanFormalizationLens.function.raw.gz',fold.encode())},'runtime_reading_mode_source':{'file':desc(tutorjs),'exact_function':archive('setReadingMode.function.raw.gz',modes.encode())},'mode_CSS_source':{'file':desc(tutorcss),'exact_rules':archive('reading-mode-CSS.rules.raw.gz',cssblock.encode())},'generic_renderer':desc(renderer),'complete_terminal_flow':['The unchanged native canonical old-reader click succeeds, then unchanged v4 catalog/search/native GPD card navigation reaches this card.','The generated source places h2 Proof architecture and its immediately following saldUse debt paragraph after direct-child Lean statement heading in theorem-layout article.','site.js synchronously moves Lean statement and every later sibling into ONE newly created, initially closed details.formalization-lens; no static nested details wrap these targets.','lean-tutor boot defaults to beginner; beginner and rigorous CSS hide the entire lens. Actual visible Lean learner mode button sets lean mode, exposes the lens and opens it through the existing site handler.','Native summary click closes the already-open lens; a second native summary click opens it. If it is initially closed, one native summary click opens it. The target has exactly one ancestor details, so outer-to-inner ordering is vacuous and explicit.','Only after verifying open state plus actual h2 and immediately following debt paragraph visibility are the same four debt assertions rechecked against the visible paragraph and the existing screenshot taken.'],'repair_does_not':['Add timeout','Force-scroll or force-click','Set open attributes or styles via evaluate/JavaScript','Change generated site, renderer, CSS, source, old publication, math or sourceV','Remove any existing body-text/debt/Compiled/native-navigation/46image/lineage/exact-byte check']}
(O/'full-terminal-flow-DOM-source-evidence.json').write_bytes(dump(evidence))
contextupdate={'old_root_context':desc(oldcontext),'root_action_required':'After reviewing this exact repair, create a fresh root context that preserves every existing field/core/sourceV/gate receipt pin and updates only browser_checker_sha256. This proposal does not authorize execution.','exact_update':{'/browser_checker_sha256':{'before':sha(oldb),'after':sha(newb)}}}
(O/'required-root-context-update.json').write_bytes(dump(contextupdate))
report={'reviewer':'/root/norm_integration_reader','state':'MINIMAL_V5_NATIVE_VISIBILITY_REPAIR_FROZEN_NOT_RUN','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'immutable_core':CORE,'source_digest':DIGEST,'failure_class':'IMPLEMENTATION_FAILED','diagnosis':'The generated HTML target is moved at runtime into formalization-lens; beginner/rigorous modes hide that entire container. Presence/body-text checks do not establish visibility. Native reading-mode and real summary clicks are required before scrolling the actual h2/debt paragraph.','DOM_source_evidence':desc(O/'full-terminal-flow-DOM-source-evidence.json'),'exact_browser_repair':{'before':desc(oldbrowser),'after':desc(newbrowser),'before_archive':archive('check_final_reader_v4.before.raw.gz',oldb),'after_archive':archive('check_final_reader_v5.after.raw.gz',newb),'diff':archive('exact-visibility-repair.diff.raw.gz',bd),'all_other_checker_bytes_identical':True,'only_before_block':archive('only-visibility-block.before.raw.gz',oldblock.encode()),'only_after_block':archive('only-visibility-block.after.raw.gz',newblock.encode())},'exact_helper_binding_overlay':{'before':desc(oldwrapper),'after':desc(newwrapper),'before_archive':archive('overlay_v4.before.raw.gz',oldw),'after_archive':archive('overlay_v5.after.raw.gz',neww),'diff':archive('exact-wrapper-binding.diff.raw.gz',wd),'only_effective_binding_change':'common.CHECKER points to frozen v5 browser; original v3 proposal/report/freeze constants and all other common helper bytes/acceptance gates unchanged.'},'original46image_names_and_all_other_navigation_lineage_exact_byte_debt_gates_preserved':True,'failed_v4_preservation':{'report':desc(failed),'report_archive':archive('failed-v4-21-report.original.raw.gz',fr),'log':desc(log),'log_archive':archive('failed-v4-log.original.raw.gz',fl),'original_images':images,'images_visually_reviewed_or_accepted_by_this_preparation':False},'all_old_owned_private_public_artifacts':archive('all-preexisting-owned-artifact-hashes.json.gz',dump(oldowned)),'old_root_context':desc(oldcontext),'required_context_update':desc(O/'required-root-context-update.json'),'protected_shared_source_ledger_models':protected,'generated_site_unchanged':{str(q.relative_to(R)):sha(q.read_bytes()) for q in [card,sitejs,tutorjs,tutorcss,site/'data/build-metadata.json',site/'data/site-data.json',site/'data/underlying-lean-graph.json',R/'.astis/site-lean-gate.json']},'AST_parse':'PASS for new checker and wrapper; neither executed/imported','root_invocation':['/opt/anaconda3/bin/python','.astis/huanjian-resume-20261103/run_check.py','fixed-spectrum-normalizer-final-browser-visibility-v5','.astis/huanjian-gc-integration-20261105/browser-venv/bin/python',str(newwrapper.relative_to(R)),'--entry',str(newbrowser.relative_to(R)),'--authorization-json','NEW_ROOT_REVIEWED_V5_CONTEXT','--authorization-sha256','NEW_CONTEXT_SHA256'],'new_OS_authorization_needed':'New wrapper path uses its own normal OS approval; no v3/v4 prefix workaround or execution attempted.','no_source_site_generator_build_Chrome_sourceV_STAB_acceptance_parking_network_mutation':True}
(O/'proposal-report.json').write_bytes(dump(report));freeze={'reviewer':report['reviewer'],'state':report['state'],'report_sha256':sha((O/'proposal-report.json').read_bytes()),'checker_sha256':sha(newb),'wrapper_sha256':sha(neww),'browser_diff_raw_sha256':sha(bd),'wrapper_diff_raw_sha256':sha(wd),'expected_original_PNGs':46,'actual_execution':'NOT_RUN','core':CORE,'source_digest':DIGEST}
(O/'freeze.json').write_bytes(dump(freeze));archive('preparation-driver.raw.py.gz',Path(__file__).read_bytes())
for q,h in oldowned.items():assert sha((R/q).read_bytes())==h,q
for q,h in protected.items():assert sha((R/q).read_bytes())==h,q
assert cmd('git','rev-parse','HEAD').decode().strip()==CORE
print(json.dumps({'proposal_report':str((O/'proposal-report.json').relative_to(R)),'report_sha256':freeze['report_sha256'],'freeze_sha256':sha((O/'freeze.json').read_bytes()),'new_checker':str(newbrowser.relative_to(R)),'new_checker_sha256':sha(newb),'new_wrapper':str(newwrapper.relative_to(R)),'new_wrapper_sha256':sha(neww),'browser_diff_sha256':sha(bd),'wrapper_diff_sha256':sha(wd),'DOM_evidence_sha256':sha((O/'full-terminal-flow-DOM-source-evidence.json').read_bytes()),'state':report['state']},ensure_ascii=False,indent=2))
