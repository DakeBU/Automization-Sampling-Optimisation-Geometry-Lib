from pathlib import Path
import json
P = Path('.astis/huanjian-gc-fixed-spectrum-geometry-20261109')
seal = json.loads(Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-geometry-statement-seal.json').read_bytes())
raw = seal['private_actual_consumer']['signature']
head, body = raw.split(' :\n', 1)
params = head.removeprefix('private theorem actual_first_order_oracle_measurable')
consumer_expected = 'def anonymousConsumerExpected : Prop := ∀'+params+',\n'+body
header = '''import Tests.GaussianComplexityFixedSpectrumGeometry
open Matrix InnerProductSpace
open scoped ContDiff
set_option autoImplicit false

'''
example = seal['producer']['signature'].replace('theorem actual_potential_geometry', 'example', 1).rstrip()+''' := by
  exact AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumGeometry.actual_potential_geometry hd hκ O

'''
inspection = '''open Lean in
run_cmd do
  let env ← getEnv
  let producer := `AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumGeometry.actual_potential_geometry
  let matches := env.constants.toList.filter fun (name, _) =>
    name.toString.startsWith "_private.Tests.GaussianComplexityFixedSpectrumGeometry" &&
    name.toString.endsWith ".actual_first_order_oracle_measurable"
  unless matches.length == 1 do throwError "Expected one compiled genuine Borel consumer"
  let consumer := matches.head!.1
  let admiss := `AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumAdmissibility.actual_precision_admissible
  let first := `AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumFirstOrder.actual_first_order_query
  let converse := `AutoSamplingTheory.TechnicalLemmas.Analysis.StrongConvexGradientConverse.strongConvexOn_of_gradient_inner_lower_bound
  for (name, expected) in [(producer, [admiss, first, converse]), (consumer, [producer, first])] do
    let some info := env.find? name | throwError "Missing compiled target"
    let some proof := info.value? (allowOpaque := true) | throwError "Missing actual proof term"
    let used := proof.getUsedConstants.toList.filter fun n => n.toString.startsWith "AutoSamplingTheory."
    unless used.length == expected.length && expected.all used.contains do
      throwError m!"Actual direct ASTIS parents mismatch: {name}: {used}"
    logInfo m!"ACTUAL_TARGET {name}"
    for dep in used do logInfo m!"ACTUAL_ASTIS_PARENT {dep}"
    for dep in proof.getUsedConstants.toList do
      unless dep.toString.startsWith "AutoSamplingTheory." do
        logInfo m!"ACTUAL_OTHER_CONSTANT {name}: {dep}"
  let check ← `(example : anonymousConsumerExpected := $(mkIdent consumer))
  Lean.Elab.Command.elabCommand check
  logInfo "Exact sealed full-forall producer application and literal private-consumer type application checked."
  logInfo "Actual proof-term ASTIS parents producer3/consumer2; imports/name scans are not this evidence."
'''
out = P/'KernelAndExactMeaning.lean'
assert not out.exists()
out.write_text(header+example+consumer_expected+'\n'+inspection)
print(str(out))
