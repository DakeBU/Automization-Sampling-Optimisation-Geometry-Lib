from pathlib import Path
import json, hashlib
W = Path(__file__).parent
p = W/'check_disabled_v3_static_cg.py'
old = p.read_bytes()
with (W/'check_disabled_v3_static_cg.attempt1.executed.py').open('xb') as f:
    f.write(old)
text = old.decode().replace("D = W/'disabled-v3-cosine-gram-static'", "D = W/'disabled-v3-cosine-gram-static-v2'")
text = text.replace("out.mkdir()\ndl.export_sources", "out.mkdir()\n# Old canonical theme is an explicitly reused static fixture, not a new site build.\nfixture = Path('_site/textbook/index.html').read_bytes()\n(out/'textbook').mkdir()\n(out/'textbook/index.html').write_bytes(fixture)\ndl.export_sources")
text = text.replace("'production_sha256': sha(production_before)", "'reused_theme_fixture_sha256': sha(fixture), 'production_sha256': sha(production_before)")
with (W/'check_disabled_v3_static_cg_v2.py').open('xb') as f:
    f.write(text.encode())
(W/'disabled-v3-static-missing-theme-diagnostic.json').write_text(json.dumps({
    'failure': 'The first isolated prospective export lacked its mandatory canonical textbook theme fixture; actual source/download fold assertions had run, but export completion did not pass.',
    'repair': 'A separate v2 output copies the already existing canonical theme as an explicitly old static fixture. Original script, partial output and real failed receipt remain unchanged. Production renderer, mathematical candidate and current reader HOLD remain unchanged.',
    'original_script_sha256': hashlib.sha256(old).hexdigest(),
    'normal_API_or_mathematical_change': False,
}, indent=2)+'\n')
print('Prepared distinct v2 static fixture check; original failed attempt retained')
