# Phase 2: selective type/definition/decoder comparison — initial notes

This is a new exposure phase after the immutable phase1 source-only cognition freeze. It is a provisional type-semantics comparison, not a proof/native/compilation review. The full implementation, reader lesson, full reviewer packet, other actors' verdicts, sourceV/intake/API/global artifacts remain unread.

## Provenance and independent comparison basis

The sole newly authorized file is the 9323-byte selective-fresh-source-phase2-input.json, SHA256 92a4b1401ec63ee22409929bd3c6528b1b25bbc822066a3944a8c9f0bbfca173. It was hashed before JSON interpretation. Source-contract, public-statement, blind-text and all supplied per-definition text hashes match their exact UTF-8 strings with no whitespace/TeX normalization. The blind reconstruction text here is 1220 bytes; the parent describes its original anonymous input packet as 2668 bytes. These are different objects, not inconsistent lengths.

The original paper remains the phase1 pinned raw, with source-only cognition SHA256 e05b005990169d78fa7a42517a8910ecd57f28cfad0425a13f67b645f4c3b993. All phase1 payload bytes and read-only modes were rechecked unchanged. The selective source.original_text is a supplied paraphrase/contract and was compared against that raw-first cognition; it was not promoted to raw-paper authority.

The public Lean field compiled=true is supplied metadata. It is not an independent compile/native certificate, and no private-theorem compilation evidence is included. The supplied publication binding and full reviewer-packet hashes are references only; their unseen contents were not inspected or independently hashed. Likewise the decoder actor/packet/run provenance and source_text_visible=false are supplied provenance. The supplied original reconstruction string itself is hashed and compared, without rewriting its mathematics.

## Seven comparison slots

Slot 1 — Objects and carriers.
Raw source: d rows, r=q+1 cosine coordinates, real Euclidean vectors t_i; B has d rows and r^2 columns. The public type uses Matrix (Fin d) (Fin(q+1)) R with a real d-by-d diagonal D. Decoder reconstructs precisely those carriers. The private type uses EuclideanSpace R (Fin d x Fin(q+1)) as its Gaussian sample carrier and paired columns Fin(q+1) x Fin(q+1). Pair order in B is Gaussian index first, cosine index second. Its dimensions match the source after zero-based reindexing. Literal semantic confirmation of WithLp.ofLp and the covariance-map wrapper was requested separately.

Slot 2 — Quantifiers and dependency order.
Raw source fixes permitted d,q, then r,n,grid/frame; Gaussian vectors are sampled afterward for B. Public type universally quantifies natural d,q and the strict hq, then defines theta,t,D by local lets shared across the three conjuncts. Decoder accurately says all d,q, no existential constants, fixed coefficient2, all rows. Private type fixes the same d,q, then literal theta,t,D, then fixed mu and B, then universally quantifies paired column entries alpha,beta. There is no arbitrary-measure, arbitrary-Gaussian, covariance-witness or desired-mean premise.

Slot 3 — Hypotheses and endpoints.
The sole non-typing premise in either supplied signature is 2q+1<d with d,q natural. It implies d>=2, q+1>=1 and includes q=0. This agrees with the source subclaims' standing range. At q=0 the only frame coordinate is1 and all sums over nonconstant coordinates disappear. The public claim does not add tau<=1/2, positivity of q, a concentration event, row bounds, orthogonality, covariance, integrability or moment hypotheses. Source kappa>=2 is relevant to the separate affine-eigenvalue/Krylov range branch, while the stated cosine-frame auxiliary has no kappa-valued object and does not claim that branch. Decoder's “only hypothesis” statement is accurate for the public type. Source proof ingredients have not been moved into extra binders.

Slot 4 — Literal definitions, constants and normalization.
All three views use theta_i=(i+1/2)pi/d in zero-based indexing, constant coordinate1, and sqrt2*cos(k theta_i) on nonzero k. Fin(q+1) guarantees 1<=k<=q when k!=0. D's diagonal entries use the exact natural frequency2q+1 and off-diagonal entries are0. The public Gram is unnormalized dI, not I; the private B has (sqrt d)^(-1), agreeing with d^(-1/2) for the admitted positive d. The row expression is an explicit finite sum of real squares, avoiding any raw-function supremum-norm interpretation. The decoder states these details, including the nonnegative real square root.

Gaussian literal chain supplied: multivariateGaussian is the affine pushforward of stdGaussian by CFC.sqrt S; stdGaussian is the orthonormal-coordinate image of a finite product of gaussianReal0 1; gaussianReal at positive variance is Lebesgue measure with gaussianPDF; gaussianPDF is ENNReal.ofReal of the classical real density (sqrt(2*pi*v))^(-1)*exp(-(x-mu)^2/(2*v)). Thus the scalar variance1 density is explicitly present, rather than a covariance label alone. gaussianReal's zero-variance Dirac branch is inapplicable at1. For multivariateGaussian, the supplied comment documents a non-PSD zero-square-root/Dirac fallback. Its actual identity covariance is mathematically PSD, but the exact CFC.sqrt identity-input and coordinate-map meanings were requested as minimal additional context. No fallback is assumed benign solely from names or comments.

Slot 5 — Conclusions and meaning.
Public signature is one theorem with three conjunctive outputs:
P1 t^T t = d I_(q+1).
P2 t^T D t = 0_(q+1)x(q+1).
P3 for every row i, sum_k t_ik^2 <= 2(q+1).
These are exactly the three deterministic C.5 subclaims, with the source row-vector sums expressed as matrix products. Decoder reconstructs all three without weakening or strengthening them; it explicitly identifies the row sum as squared Euclidean norm.

The private signature is one private theorem with four outputs for every pair of paired indices alpha,beta:
Q1 the actual scalar Gram entry x -> ((B x)^T B x)_(alpha,beta) is Integrable under the fixed mu;
Q2 the actual weighted scalar Gram entry x -> ((B x)^T D B x)_(alpha,beta) is Integrable under that same mu;
Q3 its unweighted entry integral is delta_(alpha,beta);
Q4 its weighted entry integral is0.
The two Integrable propositions are conclusions, not hypotheses. The finite-dimensional entrywise means match the mathematical entries of the two source matrix means. Recovering a formal matrix-valued expectation identity needs the finite-dimensional compatibility bridge, which is not itself a public output in the supplied signature. The anonymous decoder was given the public deterministic type only and makes no private-mean reconstruction; that is an explicit coverage limit, not evidence of a private mismatch.

Slot 6 — Ingredients and totalization.
The source deterministic route uses finite trigonometric sums/product-to-sum and exact frequencies; the actual Gaussian mean route needs genuine second moments, measurable polynomial entries, finite-product L1 and finite-sum linearity. Nothing in the supplied signatures assumes these desired conclusions. They remain implementation/proof obligations to be inspected later.

The admitted d>=2 excludes the totalized d=0 division/square-root-inverse case. The real sqrt2 and positive variance1 PDF use their nonnegative/positive branches; ENNReal.ofReal does not change a positive classical Gaussian density. For the exact matrix square-root and coordinate wrappers, a bounded definition/characterization request remains open at these initial notes.

Lean scalar integrals have totalized behavior away from integrability; Q1 and Q2 explicitly prevent the zero-valued mean assertions from standing alone without L1 control. This is particularly relevant to the weighted mean0 and off-diagonal mean0. Type-level co-occurrence of Integrable and mean conclusions is appropriate, but proves neither conclusion without checking the eventual implementation. Across-row independence and fourth/exponential moments are not extra premises of these C.5 means; they are source obligations used in C.6, beyond this review.

Slot 7 — Source scope and completion boundary.
Public P1–P3 are the deterministic frame component of Fact C.5. Private Q1–Q4 are entrywise analytic/mean statements for its actual Gaussian application, subject to confirming literal measure/coordinate semantics and later code review. Neither signature contains range(B)=K_q, a Krylov representation, a concentration event/operator-norm deviation bound, the uniform all-u probability assertion of Lemma4.4, or a main sampling lower bound. Decoder's reconstruction also claims none of those. Publicdeterministic roots plus private means cannot confer full C.5, C.6 or Lemma4.4 completion.

The source's probability statement has one event that works for every u in the random Krylov space. The current deterministic public type does not approximate or replace it with pointwise-in-u probability; it simply makes a different, properly bounded auxiliary statement. No coefficient c or adaptive random output occurs in these supplied signatures.

## Initial classification

P1–P3: provisional exact semantic agreement among pinned raw subclaims, supplied literal public type, source paraphrase contract, and actual supplied decoder reconstruction. The agreement is for the bounded deterministic auxiliary, with no proof/native assurance.

Q1–Q4: literal signature puts the appropriate entrywise L1 and mean assertions over a fixed intended standard Gaussian law in the conclusions, without a theorem-shaped extra assumption. Exact canonical wrappers/identity matrix-square-root semantics remain pending the specifically requested minimal context. No acceptance of actual proof realization or of full C.5 is made.

No mathematical mismatch in the deterministic type/decoder comparison was found. This is this reviewer's independent classification from the observed content; compiled/provenance fields and supplied role names are not semantic verdicts. No pretrained zero-knowledge or pristine guarantee is made. All further conclusions belong to a new version of these notes with any new exposure separately recorded; these initial bytes will be retained.
