"""Freeze an exact six-path proposal, without applying it or issuing source V."""
from pathlib import Path
import json, hashlib, gzip, datetime, subprocess, difflib, os, sys
sys.dont_write_bytecode=True
R=Path('/Users/zhouhuanjian/ASTIS-GC')
O=R/'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-admissibility-integration-20261107/independent-integration-reader-review/proposal'
S=R/'.astis/huanjian-gc-fixed-spectrum-admissibility-integration-20261107/independent-reader'
ADV='ASTIS-SA-20261107-GaussianComplexityFixedSpectrumAdmissibility'
AUDIT='ASTIS-RT-20261107-HuanjianFixedSpectrumAdmissibility'
CANDIDATE='2df0cd116cd21a71113ae67997b7482878633460'
DECL='AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumAdmissibility.actual_precision_admissible'
BINDING='e4e245c817d124b16e93b4f999df81132f1e50a9e38535903cb5c036417c0e94'
PATHS=['AutoSamplingTheory.lean','Tests.lean','Tests/Basic.lean','AutoSamplingTheory/TechnicalLemmas/Registry.lean','website/content/samplewiki_companion_frontiers.json','research-wiki/sampling-sde-library/cards/AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumAdmissibility.md']
PINS={'AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumAdmissibility.lean':'0e3fea5e779787d9a5365b639fdb5bff8e4a76d9e53a6dba811531db321f2241','Tests/GaussianComplexityFixedSpectrumAdmissibility.lean':'59a064649635a38002d752d4e42ae0051700c415e5ab9f323fb007576b2226d1','website/content/declaration_lessons/huanjian-fixed-spectrum-admissibility.json':'6669ef095eb7a8b0926d446d52438477dc25be00d58970f1d81f82b2b32eadd1','website/content/publications/huanjian-fixed-spectrum-admissibility.json':'787c0f0b14ef1bb6dbfa81b4b42745c9ec3c69af0f5b819aca7a6938b9863ec6'}
sha=lambda b:hashlib.sha256(b).hexdigest()
canon=lambda x:json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
def dump(x):return (json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode()
def cmd(*args):return subprocess.check_output(args,cwd=R)
def put(p,x):assert not p.exists(),str(p);p.write_bytes(dump(x))
def archive(name,raw):
 p=O/name;assert not p.exists(),str(p);p.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(p.read_bytes())==raw
 return {'path':str(p.relative_to(R)),'raw_sha256':sha(raw),'gzip_sha256':sha(p.read_bytes()),'raw_bytes':len(raw)}
def replace_once(raw,old,new):
 a=old.encode();assert raw.count(a)==1,old
 return raw.replace(a,new.encode(),1)
def differences(a,b,p=''):
 assert type(a) is type(b)
 if isinstance(a,dict):assert a.keys()==b.keys();return sum((differences(a[k],b[k],p+'/'+str(k)) for k in a),[])
 if isinstance(a,list):assert len(a)==len(b);return sum((differences(x,y,p+'/'+str(i)) for i,(x,y) in enumerate(zip(a,b))),[])
 return [] if a==b else [p]
head=cmd('git','rev-parse','HEAD').decode().strip();cmd('git','merge-base','--is-ancestor',CANDIDATE,head)
for p,h in PINS.items():assert sha((R/p).read_bytes())==h,p
for p in list(PINS)[:2]:assert cmd('git','show',CANDIDATE+':'+p)==(R/p).read_bytes()
sys.path.insert(0,str(R/'tools'));import astis_advance as adv;import astis_publication as pub
item=next(x for x in pub.load() if x['id']=='huanjian-fixed-spectrum-admissibility');assert pub.binding_digest(item,item['bindings'][0])==BINDING
lesson=json.loads((R/'website/content/declaration_lessons/huanjian-fixed-spectrum-admissibility.json').read_bytes())['units'][0]
assert lesson['astis_dependencies']==[] and lesson['reading_layout']=='progressive' and len(lesson['steps'])==5
before={p:(R/p).read_bytes() if (R/p).exists() else None for p in PATHS};assert before[PATHS[-1]] is None
for p in PATHS[:-1]:assert before[p]==cmd('git','show',head+':'+p),p
models={p:(R/p).read_bytes() for p in ['website/content/graph_memory_index.json','website/content/functor_hypergraph.json']}
plans={}
plans[PATHS[0]]=replace_once(before[PATHS[0]],'import AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumAffine\n','import AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumAffine\nimport AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumAdmissibility\n')
plans[PATHS[1]]=replace_once(before[PATHS[1]],'import Tests.GaussianComplexityFixedSpectrumAffine\n','import Tests.GaussianComplexityFixedSpectrumAffine\nimport Tests.GaussianComplexityFixedSpectrumAdmissibility\n')
plans[PATHS[2]]=replace_once(before[PATHS[2]],'formalizedTechnicalLemmaCount = 617','formalizedTechnicalLemmaCount = 618')
reg=replace_once(before[PATHS[3]],'import AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumAffine\n','import AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumAffine\nimport AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumAdmissibility\n')
assert before[PATHS[3]].count(b'status := LemmaMemoryStatus.formalizedLocal')==617
entry='''  {
    key := "gaussian-complexity.fixed-spectrum-admissibility",
    localDecl := "AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumAdmissibility.actual_precision_admissible",
    upstreamDecl := "arXiv2610.20492v1 Eq11 and Lemma4.6 actual cosine-grid precision admissibility",
    upstreamFile := "S4.E11 literal precision; S4.Thmtheorem6 Lemma4.6; selected AppendixC.4 A3.SS4",
    status := LemmaMemoryStatus.formalizedLocal,
    tags := ["GaussianComplexity", "fixed-spectrum", "actual-precision", "Loewner-bounds", "positive-definite"],
    saldUse := "Actual same-precision inverse-covariance Gaussian law-density Test consumes produced PosDef through the existing canonical GaussianPrecisionDensity declaration",
    note := "Mathematical candidate2df0cd116cd21a71113ae67997b7482878633460 carried a draft audit; later corrected publication binding and genuine independent source/whole-module review and normal source V are separately pinned. Exactlyd>=2,kappa>=2 and every actual full real orthogonal O, including either determinant sign. The literal cosine-grid O diagonal Otranspose precision satisfies both quadratic-form bounds I<=A<=kappaI and internally produced PosDef. Real cosine bounds, diagonal positivity, actual orthogonal conjugation and strict positivity from the identity are internal proof components, not public assumptions. Source dimension hd is deliberately retained though the cosine envelope needs no angle restriction. Producer ASTIS proof parents are empty; FixedSpectrumAffine and FirstOrderQuery are not formal parents. The real Test reuses the identical canonical GaussianPrecisionDensity.multivariateGaussian_eq_withDensity_of_posDef for actual N(0,Ainv) and its Euclidean-Lebesgue quadratic density with real d/2. This is a consumer dependency, not a new duplicate node or producer parent. Basis-independent determinant/known-normalizer product, C4 calculus/minimizer, moments/Krylov, target-law/TV parameter transport, adaptive/seed/transcript/output simulation, finite precision, deterministic/expected costs, both main lower bounds, remote publication and purification remain separate."
  },
'''
assert entry.splitlines()[1].encode() not in reg
reg=replace_once(reg,'  {\n    key := "gaussian-complexity.single-block-separation",',entry+'  {\n    key := "gaussian-complexity.single-block-separation",')
assert reg.replace(entry.encode(),b'',1).replace(b'import AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumAdmissibility\n',b'',1)==before[PATHS[3]]
plans[PATHS[3]]=reg
f=json.loads(before[PATHS[4]]);guide=f['cases'][4]['reader_guide'][3];boundary=f['cases'][4]['theorems'][1]['boundary']
suffix=boundary[boundary.index(' Section 4.4 limits'):];old_pending='Spectral/positive-definite/normalizer background, Gaussian covariance/target-law/TV transport, operational adaptive/seed/transcript/output simulation, deterministic/expected costs, finite-precision adapters and Krylov/moment/main-bound composition remain separate.'
assert boundary.count(old_pending)==1
newguide=guide+' Lemma4.6 now also has a compiled and independently source-reviewed pointwise precision precursor: the actual cosine-grid matrix satisfies both quadratic-form bounds and has internally produced positive definiteness. Its actual inverse-precision Gaussian law-density Test consumes that positivity through the existing canonical density node. Basis-independent known-normalizer products, C4 calculus/minimizer, moments/Krylov and all full lower-bound transports remain separate.'
new_pending=r'An additional compiled and independently source-reviewed Lemma4.6 precursor proves \(I_d\preceq A\preceq\kappa I_d\) and \(A\succ0\) for this same literal precision, with exactly \(d\ge2,\ \kappa\ge2\) and every full real \(O\). Its actual \(N(0,A^{-1})\) Test consumes the produced positivity in the existing canonical GaussianPrecisionDensity theorem to establish the quadratic density relative to Euclidean Lebesgue volume, with real exponent \(d/2\). This is actual shared-declaration reuse, not another producer proof parent or an algorithmic transport. Basis-independent determinant/known-normalizer products, C4 calculus/minimizer, Gaussian target-law/TV parameter transport, operational adaptive/seed/transcript/output simulation, deterministic/expected costs, finite-precision adapters and Krylov/moment/main-bound composition remain separate.'
newboundary=boundary.replace(old_pending,new_pending,1);assert newboundary.endswith(suffix)
changed=before[PATHS[4]]
for old,new in [(guide,newguide),(boundary,newboundary)]:
 a=json.dumps(old,ensure_ascii=False).encode();b=json.dumps(new,ensure_ascii=False).encode();assert changed.count(a)==1;changed=changed.replace(a,b,1)
after=json.loads(changed);delta=differences(f,after);assert set(delta)=={'/cases/4/reader_guide/3','/cases/4/theorems/1/boundary'}
assert f['execution']==after['execution'] and f['cases'][4]['theorems'][0]==after['cases'][4]['theorems'][0]
undo=changed
for old,new in [(guide,newguide),(boundary,newboundary)]:undo=undo.replace(json.dumps(new,ensure_ascii=False).encode(),json.dumps(old,ensure_ascii=False).encode(),1)
assert undo==before[PATHS[4]];plans[PATHS[4]]=changed
plans[PATHS[5]]='''# AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumAdmissibility

- File: `AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumAdmissibility.lean`.
- Sole declaration: `actual_precision_admissible`; one canonical compiled node.
- Mathematical candidate: `2df0cd116cd21a71113ae67997b7482878633460` carried a draft semantic audit. Corrected publication binding and later genuine independent source/whole-module review and normal source V must be pinned separately; no audit-byte equality across phases is inferred.
- Domain: exactly `d >= 2`, `kappa >= 2` and every actual `O in O(d)`, including either determinant sign. No Haar-law premise is required for this pointwise assertion.
- Actual object: `A = O diagonal(lambda_i) O^T`, `lambda_i=(kappa+1)/2+(kappa-1)cos(theta_i)/2`, `theta_i=(i-1/2)pi/d`. Lean zero-based `i.val+1/2` equals source one-based `i-1/2`; the focused Test compiles the index adapter.
- Result: `I <= A <= kappa I` in quadratic-form order, together with internally produced `A.PosDef`. The two PSD differences include symmetry and cover every real coordinate vector via the finite-support definition. Entrywise nonnegativity is not claimed.
- Internal proof spine: scalar cosine envelope -> actual positive diagonal differences -> actual full-O conjugation -> both Loewner differences -> strict positive identity contribution. No spectral window, symmetry, PSD, PosDef or Gaussian-correctness input is added. The source dimension binder is intentionally retained even though the cosine envelope needs no angle restriction.
- Real consumer: `Tests.GaussianComplexityFixedSpectrumAdmissibility` obtains `hA` from this producer and reuses the identical existing `GaussianPrecisionDensity.multivariateGaussian_eq_withDensity_of_posDef A hA`. It establishes actual `N(0,A^{-1})` as its quadratic density relative to Euclidean Lebesgue volume with real `d/2`, including odd dimensions. No duplicate generic density theorem is introduced.
- Formal reuse: Mathlib real cosine/order, diagonal/PSD/PD and orthogonal matrix facts only in the producer. Producer ASTIS proof parents are empty. GaussianPrecisionDensity is an actual consumer dependency, not a producer parent. FixedSpectrumAffine and FirstOrderQuery are distinct statements, not producer parents.
- Conceptual graph: no new weaker mechanism or oracle-factorization substrate link is proposed. The current Graph Memory and Functor Hypergraph remain byte-identical; a shared compiled GaussianPrecisionDensity declaration stays one canonical formal node.
- Source: Zhou--Suzuki arXiv2610.20492v1 Eq11, Lemma4.6 and selected AppendixC.4 matrix/Gaussian context.
- Authored mathematics: `website/content/declaration_lessons/huanjian-fixed-spectrum-admissibility.json`, bound by `website/content/publications/huanjian-fixed-spectrum-admissibility.json`.
- Remaining: basis-independent determinant/known-normalizer product, C4 calculus/Hessian/minimizer, moments/Krylov, true adaptive/seed/transcript/output laws, Gaussian target/TV parameter adapters, finite precision, deterministic worst-case cap and explicit expected-cost comparison, and both complete main lower bounds. The fixed-spectrum theorem retains fixed delta in(0,1), large d,2<=kappa<=d^(1-delta),0<epsilon<=1/10; determinant-sign source ranges remain distinct. Local canonical root/site/Chrome acceptance, remote publication, postmerge purification/Exposition Seal and whole Goal remain separate.
'''.encode()
assert set(plans)==set(PATHS)
rows=[];diff=b''
for i,p in enumerate(PATHS):
 old=before[p];new=plans[p];assert old!=new
 row={'path':p,'before_exists':old is not None,'before_sha256':sha(old) if old is not None else None,'planned_after_sha256':sha(new)}
 if old is not None:row['before_archive']=archive(f'path-{i+1}.before.raw.gz',old)
 row['planned_after_archive']=archive(f'path-{i+1}.planned-after.raw.gz',new);rows.append(row)
 diff+=b''.join(difflib.diff_bytes(difflib.unified_diff,(old or b'').splitlines(keepends=True),new.splitlines(keepends=True),fromfile=('a/'+p).encode() if old is not None else b'/dev/null',tofile=('b/'+p).encode()))
(S/'exact-proposed-shared.diff').write_bytes(diff);diffrow=archive('exact-proposed-shared.diff.gz',diff)
ledger={};foreign={}
for p,replay in [('runs/substantive_advances.jsonl',adv._replay_advances),('runs/substantive_discoveries.jsonl',adv._replay_discoveries)]:
 raw=(R/p).read_bytes();assert raw.endswith(b'\n');ss=replay([json.loads(line) for line in raw.splitlines() if line.strip()])
 if 'advances' in p:own=ss.pop(ADV)
 else:ss={k:v for k,v in ss.items() if v.get('advance_id')!=ADV}
 foreign[p]=ss;ledger[p]={'raw_prefix':archive(Path(p).name+'.prefix.raw.gz',raw),'foreign_projection':archive(Path(p).name+'.foreign-projection.json.gz',canon(ss)),'foreign_projected_records':len(ss)}
assert own['state'] in ['PROVED_LOCAL','VERIFIED'] and len(foreign['runs/substantive_advances.jsonl'])==281
assert not [k for k,v in foreign['runs/substantive_advances.jsonl'].items() if v['state']=='STABILIZING']
markers=('FixedSpectrumAdmissibility','fixed-spectrum-admissibility','huanjian-fixed-spectrum-admissibility','ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-admissibility')
gitmap={};inputs={}
for line in cmd('git','ls-files','--stage','-z').split(b'\0'):
 if not line:continue
 md,p=line.split(b'\t',1);p=os.fsdecode(p);mode,blob,stage=md.decode().split();assert stage=='0'
 if p in PATHS or p in ledger or any(m in p for m in markers):continue
 gitmap[p]=[mode,blob]
 if not p.startswith('runs/'):
  q=R/p;raw=os.fsencode(os.readlink(q)) if q.is_symlink() else q.read_bytes();inputs[p]={'sha256':sha(raw),'bytes':len(raw)}
tracked=archive('protected-tracked-git-objects.json.gz',canon(gitmap));protected=archive('protected-foreign-content-sha256.json.gz',canon(inputs))
frontiers={str(p.relative_to(R)):sha(p.read_bytes()) for p in (R/'research-wiki/frontier-cells').glob('*.json') if p.name!='ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-admissibility.json'}
assert len(frontiers)==440
fp=archive('all-440-foreign-frontier-hashes.json.gz',canon(frontiers))
gc={str(p.relative_to(R)):sha(p.read_bytes()) for p in (R/'research-wiki/paper-contributions/GaussianComplexity').rglob('*') if p.is_file() and not any(m in str(p.relative_to(R)) for m in markers)}
gcp=archive('all-older-GaussianComplexity-evidence-hashes.json.gz',canon(gc))
masked=json.loads(before[PATHS[4]]);masked['cases'][4]['reader_guide'][3]='<OWN_ADMISSIBILITY_SCALAR>';masked['cases'][4]['theorems'][1]['boundary']='<OWN_ADMISSIBILITY_SCALAR>'
atlas=(R/'.atlas-upstream').stat()
for p in PATHS:assert ((R/p).read_bytes() if (R/p).exists() else None)==before[p]
for p,raw in models.items():assert (R/p).read_bytes()==raw
for p,h in PINS.items():assert sha((R/p).read_bytes())==h
(O/'initial-worktree-status.txt').write_bytes(cmd('git','status','--short','--untracked-files=normal'))
report={'reviewer':'/root/admiss_integration_reader','phase':'Exact six-path integration and readability proposal only','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head_at_start':head,'head_at_end':cmd('git','rev-parse','HEAD').decode().strip(),'mathematical_candidate':CANDIDATE,'verdict':'NO_BLOCKING_OBJECTION_TO_EXACT_CONDITIONAL_PROPOSAL','sourceV':'Not issued; genuine current-binding independent source/whole-module review still required before application.','shared_source_audit_ledger_API_or_lifecycle_mutations':False,'build_site_browser_runs':[],'source_Test_lesson_publication_pins':PINS,'publication_binding_sha256':BINDING,'shared_paths':rows,'shared_path_count':6,'canonical_Registry_nodes_added':1,'administrative_count_only':'617->618; actual existing formalizedLocal records counted617','all_old_Registry_bytes_retained':True,'formal_ASTIS_producer_parents':[],'actual_consumer_canonical_reuse':'GaussianPrecisionDensity.multivariateGaussian_eq_withDensity_of_posDef, identical existing compiled declaration; no duplicate node and not producer proof parent','frontier_scalar_pointer_delta':delta,'protected_case_values':{'execution_sha256':sha(canon(f['execution'])),'determinant_theorem_index0_sha256':sha(canon(f['cases'][4]['theorems'][0])),'all_other_case_values_sha256':sha(canon(masked)),'Section4_4_limitation_suffix':suffix,'Section4_4_suffix_sha256':sha(suffix.encode())},'unchanged_models':{p:sha(raw) for p,raw in models.items()},'new_conceptual_bridge_or_oracle_substrate_binding':False,'raw_diff':diffrow,'ledger_protection':ledger,'foreign_frontiers':{'count':len(frontiers),**fp},'older_GaussianComplexity_evidence':{'count':len(gc),**gcp},'protected_git_objects':{'count':len(gitmap),**tracked},'protected_foreign_content':{'count':len(inputs),**protected},'own_state_at_snapshot':own['state'],'untracked_Atlas':{'path':'.atlas-upstream','scope':'Directory stat only; no content opened or traversed.','device':atlas.st_dev,'inode':atlas.st_ino,'mtime_ns':atlas.st_mtime_ns},'reader_preflight':{'main_conclusion':'Concise I<=A<=kappaI and A>0 first, progressive source assumptions/literal grid/finite-support quadratic-form meaning, five mathematical steps and adjacent exact Lean; real Gaussian consumer distinguished from source producer.','stale_prose_correction':'Separately reviewed exact two-scalar planned->compiled correction accepted before this final proposal; corrected lesson/publication/binding pinned above.','actual_render':'Pending final exactHEAD desktop/mobile original images; no visual acceptance claimed.'},'application_preconditions':['Genuine independent current-binding sourceV with accepted whole-module/reader review; root does not selfV.','Sole normal root STAB lease, preserving all other owners/queues.','All exact current before hashes match and newcard absent; apply only the six archived after payloads.','Both GraphMemory and Functor model exact bytes remain unchanged.','Freeze immutable core; real exactHEAD official Lean/rootTests gate, site build/check and cell graph check; actual original desktop1440/mobile390/source-index/module/download/localGit and canonical graph inspection.'],'later_actual_acceptance':['Inspect compact rendered formulas, assumptions, all five proof steps, exact statement/proof Lean folds and its horizontal scroll region at1440/390; no false fullpage overflow or clipping claim.','Actually click source-index into full focused reader, source link, exact Lean/module/download and local immutable Git bytes; external public availability remains separate.','One canonical producer declaration; producer ASTIS parents empty. Canonical GaussianPrecisionDensity is actual Test reuse; no new duplicate density or oracle transport.','Native graph focused node plus neighbor clicks show correct formal imports/declares and typed dashed source/planned links; import topology is not theorem implication. Both model JSON files unchanged.','View every final actual originalPNG independently and record filenames/raw hashes, viewport limits and local hscroll.','Fresh protection readback and actual gate/site/graph/browser receipts before local acceptance; normal lease parking is separately authorized.'],'remaining_open':['Actual sourceV and canonical local acceptance at proposal time','C4 basis-independent determinant/known-normalizer product, calculus/Hessian/minimizer and moment/Krylov background','Both main lower bounds; actual adaptive/seed/transcript/output, finiteprecision, TV and deterministic/expected costs','Remote original-owner hold/publication, postmerge purification/Exposition Seal and wholeGoal']}
assert report['head_at_start']==report['head_at_end']
put(O/'proposal-report.json',report)
put(O/'freeze.json',{'reviewer':report['reviewer'],'phase':report['phase'],'report_sha256':sha((O/'proposal-report.json').read_bytes()),'diff_raw_sha256':sha(diff),'all_shared_paths_frozen':rows,'models_unchanged':report['unchanged_models']})
print(json.dumps({'report':str((O/'proposal-report.json').relative_to(R)),'report_sha256':sha((O/'proposal-report.json').read_bytes()),'freeze_sha256':sha((O/'freeze.json').read_bytes()),'diff_raw_sha256':sha(diff),'shared_paths':6,'foreign_SAUs':len(foreign['runs/substantive_advances.jsonl']),'foreign_frontiers':len(frontiers),'protected_foreign_content':len(inputs),'older_GC_evidence':len(gc)},indent=2))
