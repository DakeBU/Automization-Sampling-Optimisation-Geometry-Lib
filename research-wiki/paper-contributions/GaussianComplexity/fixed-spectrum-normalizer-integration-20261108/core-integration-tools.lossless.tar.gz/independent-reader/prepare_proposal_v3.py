"""Two exact prose corrections only; preserve v1/v2 and all shared working bytes."""
from pathlib import Path
import ast,copy,datetime,difflib,gzip,hashlib,json,subprocess
R=Path('/Users/zhouhuanjian/ASTIS-GC')
S=R/'.astis/huanjian-gc-fixed-spectrum-normalizer-integration-20261108/independent-reader'
O=R/'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-normalizer-integration-20261108/independent-reader'
OLD=O/'proposal-v2';NEW=O/'proposal-v3';HELP=O/'helper-binding-overlay-v3'
sha=lambda b:hashlib.sha256(b).hexdigest()
dump=lambda x:(json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode()
def cmd(*args):return subprocess.check_output(args,cwd=R)
def unpack(row):
 raw=(R/row['path']).read_bytes();assert sha(raw)==row['gzip_sha256'];b=gzip.decompress(raw)
 assert sha(b)==row['raw_sha256'] and len(b)==row['raw_bytes'];return b
def archive(directory,name,raw):
 q=directory/name;assert not q.exists();q.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(q.read_bytes())==raw
 return {'path':str(q.relative_to(R)),'raw_sha256':sha(raw),'gzip_sha256':sha(q.read_bytes()),'raw_bytes':len(raw)}
head=cmd('git','rev-parse','HEAD').decode().strip();assert head=='813268bc2683a82269364caffbc0c7490a884204'
oldraw=(OLD/'proposal-report.json').read_bytes();oldfreeze=(OLD/'freeze.json').read_bytes()
assert sha(oldraw)=='64b266f7c9f9bbd3cfe6421346022c78f2f841ab5122d8b1e6dee64288cc3920'
assert sha(oldfreeze)=='cb1f1630c6877efb3c48cccd5bb0f2e8c1439ef4e7db8dc30c9abab745738927'
old=json.loads(oldraw);oldrows={x['path']:x for x in old['shared_paths']};before={};after={};previous={}
replacement='The current normalizer review inspects critical ancestors for this new proof; it does not confer a standalone historical sourceV or completed publication audit on this GPD parent, and does not alter its old frontier/audit.'
changes={
 'AutoSamplingTheory/TechnicalLemmas/Registry.lean':'Its new source review does not review this historical parent module.',
 'research-wiki/sampling-sde-library/cards/AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumNormalizer.md':'New normalizer source V does not review that old module.',
}
for p,row in oldrows.items():
 before[p]=unpack(row['before_archive']) if row['before_exists'] else None
 q=R/p;assert q.exists()==row['before_exists']
 assert (q.read_bytes() if q.exists() else None)==before[p],p
 previous[p]=unpack(row['planned_after_archive']);after[p]=previous[p]
 if p in changes:
  a=changes[p].encode();assert after[p].count(a)==1 and replacement.encode() not in after[p]
  after[p]=after[p].replace(a,replacement.encode(),1)
  assert after[p].replace(replacement.encode(),a,1)==previous[p]
assert {p for p in after if after[p]!=previous[p]}==set(changes)
for p,h in {**old['source_Test_lesson_publication_pins'],**old['unchanged_models']}.items():assert sha((R/p).read_bytes())==h,p
assert not NEW.exists() and not HELP.exists();NEW.mkdir();HELP.mkdir()
rows=[];diff=b'';delta=b''
for i,(p,row) in enumerate(oldrows.items(),1):
 a,b=before[p],after[p];nr={'path':p,'before_exists':a is not None,'before_sha256':sha(a) if a is not None else None,'planned_after_sha256':sha(b),'planned_after_archive':archive(NEW,f'path-{i}.planned-after.raw.gz',b)}
 if a is not None:nr['before_archive']=archive(NEW,f'path-{i}.before.raw.gz',a)
 rows.append(nr)
 diff+=b''.join(difflib.diff_bytes(difflib.unified_diff,(a or b'').splitlines(keepends=True),b.splitlines(keepends=True),fromfile=('a/'+p).encode() if a is not None else b'/dev/null',tofile=('b/'+p).encode()))
 if b!=previous[p]:delta+=b''.join(difflib.diff_bytes(difflib.unified_diff,previous[p].splitlines(keepends=True),b.splitlines(keepends=True),fromfile=('v2/'+p).encode(),tofile=('v3/'+p).encode()))
(S/'exact-proposed-shared-v3.diff').write_bytes(diff)
(S/'exact-v2-to-v3-prose-only.diff').write_bytes(delta)
report=copy.deepcopy(old)
report['created_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
report['phase']='Exact conditional six-path proposal v3; two critical-ancestor review/debt prose corrections only'
report['shared_paths']=rows;report['raw_diff']=archive(NEW,'exact-proposed-shared.diff.gz',diff)
entry=unpack(old['Registry_exact_insertions']['GPD_compilation_only'])
assert entry.count(changes['AutoSamplingTheory/TechnicalLemmas/Registry.lean'].encode())==1
entry=entry.replace(changes['AutoSamplingTheory/TechnicalLemmas/Registry.lean'].encode(),replacement.encode(),1)
report['Registry_exact_insertions']['GPD_compilation_only']=archive(NEW,'GPD-entry.raw.gz',entry)
report['Registry_exact_insertions']['normalizer']=archive(NEW,'normalizer-entry.raw.gz',unpack(old['Registry_exact_insertions']['normalizer']))
report['supersedes']={'report':str((OLD/'proposal-report.json').relative_to(R)),'sha256':sha(oldraw),'freeze_sha256':sha(oldfreeze),'reason':'Fresh review inspects critical ancestor modules for the current new proof. Such inspection does not confer a standalone historical GPD sourceV or completed old publication audit. Preserve v1/v2 exact bytes; change only the two requested sentences.'}
report['v3_delta_scope']={'changed_shared_paths':list(changes),'old_sentences':changes,'replacement_sentence':replacement,'all_other_planned_after_payloads_byte_identical_to_v2':True,'before_payloads_byte_identical_to_v2':True,'production_Test_lesson_publication_and_binding_unchanged':True,'actual_scanner_evidence':'Reuse unchanged v2 virtual scanner raw evidence; no fresh scanner/build/graph/Chrome run needed for these two prose sentences.','source_review_scope':'Critical-ancestor inspection for the current new proof is distinct from standalone historical GPD sourceV/publication admission.','two_sentence_delta':archive(NEW,'exact-v2-to-v3-prose-only.diff.gz',delta)}
(NEW/'proposal-report.json').write_bytes(dump(report));rsha=sha((NEW/'proposal-report.json').read_bytes())
freeze={'reviewer':report['reviewer'],'phase':report['phase'],'report_sha256':rsha,'diff_raw_sha256':sha(diff),'shared_paths':rows,'models':report['unchanged_models'],'application_authorized':False,'acceptance':'NOT_RUN','supersedes_report_sha256':sha(oldraw),'two_sentence_delta_raw_sha256':sha(delta)}
(NEW/'freeze.json').write_bytes(dump(freeze));fsha=sha((NEW/'freeze.json').read_bytes())
archive(NEW,'proposal-v3-preparation-driver.py.raw.gz',Path(__file__).read_bytes())
# Runtime constant overlay leaves all five frozen v2 helper files untouched.
# The old entry point remains the actual checker, with its existing frozen SHA.
helperfreeze=O/'helper-preparation-v2/helpers-freeze.json'
assert sha(helperfreeze.read_bytes())=='bdea9a5b53144400db0ffc1c7a77888654a1eda8e9dd68ddca63571532920fdd'
h=json.loads(helperfreeze.read_bytes());helperpins={x['path']:x['sha256'] for x in h['helpers']}
for p,digest in helperpins.items():assert sha((R/p).read_bytes())==digest,p
common=S/'normalizer_acceptance_common_v2.py';commonraw=common.read_bytes()
assert sha(commonraw)=='7fa8348491edf4e3ecb745ba2111a9ed44e74ac4b0709619af330a05ac4fcfa6'
entrypoints=[str((S/n).relative_to(R)) for n in ['check_postcore_v2.py','record_local_acceptance_v2.py','check_normalpark_eligibility_v2.py','check_final_reader_v2.py']]
overlay='''"""Apply only v3 proposal binding constants, then run an unchanged frozen v2 helper.
Preparation artifact: execution still requires the helper's existing root-bound context.
Use --entry with the full repository-relative frozen entrypoint path so actual receipts
retain the checker identity. No browser flow, acceptance gate or lifecycle API changes.
"""
from pathlib import Path
import hashlib,runpy,sys
sys.dont_write_bytecode=True
R=Path('/Users/zhouhuanjian/ASTIS-GC')
S=R/'.astis/huanjian-gc-fixed-spectrum-normalizer-integration-20261108/independent-reader'
PINS=__PINS__
ENTRIES=__ENTRIES__
sha=lambda b:hashlib.sha256(b).hexdigest()
assert len(sys.argv)>2 and sys.argv[1]=='--entry'
entry=sys.argv[2];assert entry in ENTRIES
for p,h in PINS.items():assert sha((R/p).read_bytes())==h,p
import normalizer_acceptance_common_v2 as common
assert str(common.P.relative_to(common.O))=='proposal-v2'
assert common.REPORT_SHA=='64b266f7c9f9bbd3cfe6421346022c78f2f841ab5122d8b1e6dee64288cc3920'
assert common.FREEZE_SHA=='cb1f1630c6877efb3c48cccd5bb0f2e8c1439ef4e7db8dc30c9abab745738927'
common.P=common.O/'proposal-v3'
common.REPORT_SHA='__REPORT_SHA__'
common.FREEZE_SHA='__FREEZE_SHA__'
sys.argv=[str(R/entry),*sys.argv[3:]]
runpy.run_path(str(R/entry),run_name='__main__')
'''.replace('__PINS__',repr(helperpins)).replace('__ENTRIES__',repr(entrypoints)).replace('__REPORT_SHA__',rsha).replace('__FREEZE_SHA__',fsha)
ast.parse(overlay);op=S/'proposal_binding_overlay_v3.py';assert not op.exists();op.write_text(overlay)
schema=json.loads((O/'future-context.schema.json').read_bytes());assert schema['properties']['proposal_report_sha256']['const']==sha(oldraw)
schema['title']='Future root-bound normalizer v3 read-only context; this schema is not authorization'
schema['properties']['proposal_report_sha256']['const']=rsha
schemafile=HELP/'future-context-v3.schema.json';schemafile.write_bytes(dump(schema))
manifest={'reviewer':report['reviewer'],'state':'MINIMAL_V3_PROPOSAL_BINDING_OVERLAY_PREPARED_NOT_EXECUTED','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'HEAD':head,'v2_helpers_freeze':{'path':str(helperfreeze.relative_to(R)),'sha256':sha(helperfreeze.read_bytes())},'unchanged_v2_helper_pins':helperpins,'unchanged_browser_checker_sha256':'acd0b2be49b2c3059f9ae4659058a18c157f3dda673f4ebfb6e0d7a51e7a408f','runtime_changes_only':{'P':{'before':'proposal-v2','after':'proposal-v3'},'REPORT_SHA':{'before':sha(oldraw),'after':rsha},'FREEZE_SHA':{'before':sha(oldfreeze),'after':fsha}},'two_changed_after_hashes':{p:{'v2':oldrows[p]['planned_after_sha256'],'v3':sha(after[p])} for p in changes},'other_four_after_payloads_unchanged':True,'overlay':{'path':str(op.relative_to(R)),'sha256':sha(op.read_bytes()),'archive':archive(HELP,'proposal_binding_overlay_v3.py.raw.gz',op.read_bytes())},'schema':{'path':str(schemafile.relative_to(R)),'sha256':sha(schemafile.read_bytes())},'execution_pattern':'python proposal_binding_overlay_v3.py --entry FULL_REPOSITORY_RELATIVE_V2_ENTRYPOINT --authorization-json NEW_V3_CONTEXT --authorization-sha256 CONTEXT_SHA [--output NEW_OWN_RESULT]','browser_flow_acceptance_gates_and_sourceV_lineage_logic':'Exact existing v2 helper bytes and logic unchanged; only proposal path/report/freeze constants are rebound in memory.','execution_status':'NOT_RUN','sourceV_STAB_application_build_site_Chrome_acceptance_or_parking_performed':False}
(HELP/'overlay-freeze.json').write_bytes(dump(manifest));hsha=sha((HELP/'overlay-freeze.json').read_bytes())
for p,row in oldrows.items():assert unpack(row['planned_after_archive'])==previous[p]
assert (OLD/'proposal-report.json').read_bytes()==oldraw and (OLD/'freeze.json').read_bytes()==oldfreeze
for p,digest in helperpins.items():assert sha((R/p).read_bytes())==digest,p
for p,b in before.items():assert ((R/p).read_bytes() if (R/p).exists() else None)==b,p
assert cmd('git','rev-parse','HEAD').decode().strip()==head
result={'reviewer':report['reviewer'],'state':'V3_TWO_SENTENCE_PREPARATION_COMPLETE_NO_SHARED_APPLICATION','HEAD':head,'proposal_report_sha256':rsha,'proposal_freeze_sha256':fsha,'six_path_diff_raw_sha256':sha(diff),'v2_to_v3_prose_only_diff_sha256':sha(delta),'helper_overlay_freeze_sha256':hsha,'helper_overlay_script_sha256':sha(op.read_bytes()),'unchanged_browser_checker_sha256':manifest['unchanged_browser_checker_sha256'],'two_changed_after_hashes':manifest['two_changed_after_hashes'],'production_Test_lesson_publication_binding_unchanged':True,'old_v1_v2_and_helpers_retained':True,'execution_status':'NOT_RUN'}
(NEW/'preparation-complete.json').write_bytes(dump(result))
print(json.dumps(result,ensure_ascii=False,indent=2))
