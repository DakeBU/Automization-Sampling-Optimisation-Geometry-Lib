from pathlib import Path
from hashlib import sha256
from bs4 import BeautifulSoup
p=Path('.astis/huanjian-resume-20261103/2610.20492v1.html')
b=p.read_bytes()
s=BeautifulSoup(b,'html.parser')
for anchor in ['S4','S4.SS2','S4.SS2.SSS0.Px2','A3.SS2']:
 e=s.find(id=anchor)
 print('\nSTRUCTURE',anchor)
 for c in e.children:
  if getattr(c,'name',None):
   print(c.name,c.get('id'),','.join(c.get('class',[])),len(str(c)),c.get_text(' ',strip=True)[:200])
print('\nC2 IDS')
e=s.find(id='A3.SS2')
for c in e.find_all(id=True):
 print(c.name,c['id'],','.join(c.get('class',[])),len(str(c)), c.get('alttext','') or c.get_text(' ',strip=True)[:110])
