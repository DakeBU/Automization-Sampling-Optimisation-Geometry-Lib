"""Read-only exact evidence checks. Bounded reports contain no foreign/private maps."""
from pathlib import Path
import json, tarfile
from guard import *
from astis_semantic_roundtrip_core import sha256_json

HELD = 'f7a38f36c080883d6c936ae90157a40548797e1b'
MATH = '60ec0e083261dfa71f009bdd5d8c9e63b1425bb7'
E = ROOT/'research-wiki/paper-contributions/GaussianComplexity/source-gram-realization-semantic-evidence'
N = ROOT/'.astis/semantic-neutral-20261113/gram_native_6a27'
S = E/'source-review/gram_src_e182'
PL_SHA = '5fba206470cdcaefe0ea8533b735d3754088cfe9e81694516feef801f5806a14'
PL_APPEND_SHA = 'f5fe8f25b024b1ea558edb2ab5161866a267eb3a5cc2e39417a8c9d6e0db5d98'

def verify_archive(path, manifest, extra=None):
    extra = extra or {}
    with tarfile.open(path,'r:gz') as tf:
        members = tf.getmembers(); names = [m.name for m in members]
        assert len(names) == len(set(names))
        assert set(names) == set(manifest)|set(extra), 'archive manifest membership mismatch'
        assert all(m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts for m in members)
        for name,info in manifest.items():
            raw = tf.extractfile(name).read()
            assert len(raw) == info['bytes'] and sha(raw) == info['sha256'], 'archive payload bytes mismatch'
        for name,raw in extra.items(): assert tf.extractfile(name).read() == raw
    return len(members)

def run():
    assert git('rev-parse','HEAD').decode().strip() == HELD
    original_raw = (E/'actual-PROVED_LOCAL-evidence.full.json').read_bytes()
    append = (E/'actual-PROVED_LOCAL-append.exact.jsonl').read_bytes()
    assert sha(original_raw) == PL_SHA and sha(append) == PL_APPEND_SHA
    original = json.loads(original_raw); assert len(original) == 26
    raw,records = clean_records(L)
    own = [r for r in records if r.get('advance_id') == ADV]
    pls = [r for r in own if r.get('to_state') == 'PROVED_LOCAL']
    vs = [r for r in own if r.get('to_state') == 'VERIFIED']
    assert len(pls) == 1 and not vs and json.loads(append) == pls[0] and pls[0]['evidence'] == original
    assert append in raw and read(ROOT/C)['owner_id'] == OWNER and read(ROOT/C)['status'] == 'proved_locally'
    # Check every directly recorded path/hash pointer in the original payload.
    pointer_count = 0
    def pointers(obj):
        nonlocal pointer_count
        if isinstance(obj,dict):
            path = obj.get('path') or obj.get('file')
            if path and obj.get('sha256'):
                p = Path(path); p = p if p.is_absolute() else ROOT/p
                assert p.is_file() and sha(p.read_bytes()) == obj['sha256'], 'original evidence pointer differs'
                pointer_count += 1
            for value in obj.values(): pointers(value)
        elif isinstance(obj,list):
            for value in obj: pointers(value)
    pointers(original)
    # Scientific native evidence is inherited only over identical module bytes.
    native = read(N/'native-math-verdict.json')
    assert native['status'] == 'PASS' and native['checked_commit'] == MATH
    assert native['closure_modules'] == 8 and native['complete_module_emission_count'] == 41
    assert native['task_module_emission_count'] == 4 and native['unique_expr_nodes'] == 52106
    assert all(native[k] for k in ['Expr_DAG_all_roots_and_backward_links_validated',
                                  'all_complete_types_and_values_kernel_checked',
                                  'all_complete_types_and_values_closed','standard_axioms_only'])
    assert native['source_scan'] == []
    native_m = read(N/'selected-native-originals.manifest.json')
    assert len(native_m) == 231
    for name,info in native_m.items():
        b = (N/name).read_bytes(); assert len(b) == info['bytes'] and sha(b) == info['sha256']
    native_count = verify_archive(N/'selected-native-originals.lossless.tar.gz',native_m,
                                 {'selected-native-originals.manifest.json':(N/'selected-native-originals.manifest.json').read_bytes()})
    scan = read(N/'fake-closure-source-scan.json'); modules = []
    assert scan['violations'] == [] and len(scan['modules']) == 8
    for item in scan['modules']:
        path = item['module'].replace('.','/')+'.lean'
        b = (ROOT/path).read_bytes(); assert sha(b) == item['sha256'] and not item['hits']
        assert git('show',f'{MATH}:{path}') == b and git('show',f'{HELD}:{path}') == b
        assert (N/'snapshot'/path).read_bytes() == b
        modules.append({'path':path,'sha256':sha(b),'identical_to_native_and_held_commits':True})
    for path in ['lean-toolchain','lake-manifest.json','lakefile.lean']:
        assert (ROOT/path).read_bytes() == (N/'snapshot'/path).read_bytes()
    for result in read(N/'seal-result.json'):
        assert result['fullUniversalTypeKernelDefEq'] and result['actualProofAtSealedTypeKernelChecked']
        assert result['genuineQ0UniversalApplicationKernelChecked'] and result['genuineQ0ApplicationKernelChecked']
        assert result['genuineQ0ApplicationD'] == 2
    # Exact selected independent source originals and current bindings.
    sm = read(S/'complete-source-originals.manifest.json')
    assert sha((S/'complete-source-originals.tar.gz').read_bytes()) == sm['archive_sha256']
    source_count = verify_archive(S/'complete-source-originals.tar.gz',sm['files'])
    assert source_count == 41
    prefix = '.astis/semantic-neutral-20261113/gram_src_e182/source_review_v1/'
    with tarfile.open(S/'complete-source-originals.tar.gz','r:gz') as tf:
        get = lambda name: tf.extractfile(prefix+name).read()
        for name,path in [('P-immutable-current.lean',original['lean_files'][0]),
                          ('T-immutable-current.lean',original['lean_files'][1]),
                          ('current-lesson.json','website/content/declaration_lessons/huanjian-gaussian-source-gram-realization.json'),
                          ('current-publication.json','website/content/publications/huanjian-gaussian-source-gram-realization.json'),
                          ('source-lean-map.authored-v1.json',str((E/'source-lean-map.authored-v1.json').relative_to(ROOT))),
                          ('conceptual-mirror-audit.authored-v1.json',str((E/'conceptual-mirror-audit.authored-v1.json').relative_to(ROOT)))]:
            assert get(name) == (ROOT/path).read_bytes(), 'source-reviewed current input changed'
        run = json.loads(get('review-run.json'))
        assert sha(get('review-run.json')) == original['independent_source_review']['review_run_sha256']
        assert run['reviewer'] == 'gram_src_e182'
        assert all(run['independence_and_limits'][k] for k in ['independent_from_formalizer','independent_from_P_decoder','independent_from_T_decoder'])
        for letter,decoder in [('P','4e62'),('T','b83d')]:
            overlay = json.loads(get(letter+'.audit-overlay.json'))
            assert overlay['state'] == 'accepted' and len(overlay['semantic_slots']) == 7
            assert overlay['source_review']['state'] == 'accepted'
            assert overlay['source_review']['independent_from_formalizer'] and overlay['source_review']['independent_from_decoder']
            assert overlay['source_review']['review_run_sha256'] == sha(get('review-run.json'))
            packet = json.loads(get('fresh-'+letter+'-review.v1.json'))
            packet_hash = packet.pop('packet_sha256')
            assert packet_hash == sha256_json(packet)
            assert overlay['source_review']['reviewer_packet_sha256'] == packet_hash
            result = json.loads(get('anon_'+decoder+'-result.json'))
            assert result['source_text_visible'] is False
            assert sha(result['reconstructed_theorem_text'].encode()) == result['reconstructed_text_sha256']
            assert result['decoder'] != OWNER and result['decoder'] != run['reviewer']
            if letter == 'P':
                current = read(ROOT/'research-wiki/semantic-roundtrip/audits/huanjian-gaussian-source-gram-realization.json')
                for key,value in overlay.items():
                    if key != 'source': assert current[key] == value, 'canonical accepted overlay field changed'
                # The source carrier omits only the overlay URL; exact text and all meaning-bearing fields remain.
                assert {k:v for k,v in overlay['source'].items() if k != 'url'} == current['source']
                assert overlay['publication_binding_sha256'] == original['publication_binding_sha256']
    # Inspect all four original actual held gate receipts and their raw streams.
    gates_raw = (N/'final-metadata-result.json').read_bytes()
    assert sha(gates_raw) == 'b80430e119de180612b878b64881dab8ac8b103b124380ae5c546a3b8a2eca4d'
    gates = json.loads(gates_raw)
    assert gates['held_HEAD'] == HELD and gates['base'] == BASE and gates['gate_count'] == 4 and gates['all_passed']
    expected = {('python3','tools/astis_publication.py','check','--base',BASE),
                ('python3','tools/astis_contributor_contract.py','check','--base',BASE),
                ('python3','tools/astis_semantic_roundtrip.py','check'),
                ('python3','tools/astis_frontier_cells.py','check')}
    assert {tuple(x['command']) for x in gates['commands']} == expected
    gate_rows = []
    for item in gates['commands']:
        rp = Path(item['receipt']); r = read(rp)
        assert r['argv'] == item['command'] and r['exit'] == item['exit'] == 0 and r['HEAD'] == HELD
        out = rp.with_suffix('.stdout').read_bytes(); err = rp.with_suffix('.stderr').read_bytes()
        assert sha(out) == r['stdout_sha256'] and sha(err) == r['stderr_sha256'] and not err
        assert b'PASS' in out or b'valid' in out or b'passed' in out
        gate_rows.append({'command':item['command'],'exit':0,'receipt':str(rp.relative_to(ROOT)),
                          'receipt_sha256':sha(rp.read_bytes()),'stdout_sha256':sha(out),'stderr_empty':True,
                          'actual_held_HEAD':r['HEAD']})
    out = {'status':'PASS_SCIENTIFIC_AND_FOUR_HELD_GATES_WAITING_FINAL_READER_CLOSURE',
           'verifier_id':VERIFIER,'held_HEAD':HELD,'original_PL_fields':26,
           'original_PL_payload_sha256':PL_SHA,'original_PL_append_sha256':PL_APPEND_SHA,
           'original_path_hash_pointers_checked':pointer_count,'PL_count':1,'VERIFIED_count':0,
           'eight_module_exact_identity':modules,'native_selected_payload_files':231,
           'native_archive_members':native_count,'source_archive_members':source_count,
           'independent_source_and_decoder_provenance_checked':True,
           'four_held_gate_originals':gate_rows,'normal_VERIFIED_calls':0,'tracked_edits':False,
           'Lean_browser_source_review_or_gates_replayed':False,'full_private_maps_exported':False,
           'scientific_boundary':'Exact eventwise actual centered/weighted Gram identities and private all-real-threshold norm implication only. No probability, full C6/Lemma4.4/main lower bound or integration/purification credit.'}
    create(O/'evidence-preflight.bounded.json',dump(out))
    print(json.dumps(out,ensure_ascii=False,indent=2))
if __name__ == '__main__': run()
