# Minimal C7 browser v3: rendered fixed parameter

The real v2 run on unchanged core7ad stopped at `AssertionError('fixed kappa')` after12 desktop originals. Its source/Lean/product inputs are unchanged. The own-site HTML actually contains `for each fixed \(\kappa\)`; MathJax renders the mathematical parameter, so the browser text is not the English spelling `kappa`.

This successor preserves every48-original/20-native check. Its only view criterion change is `fixed kappa` → `are outputs for each fixed`, plus an actual own-site HTTP response status200 and exact HTML substring check for `for each fixed \(\kappa\)`. This retains the fixed-parameter requirement. No lesson, publication, source, UI or core change is proposed. The remaining code delta is only the new v3 common import/path/hash and authorization kind.

The disabled actual-records context copies the existing real7ad core, eight official gates,122tests, source digest and site/core pins from the original actual v2 authorization. It resets `authorized_by=null`, `execute_browser_authorized=false`, `actual_facts_reviewed_by_root=false`, and explicitly inherits no execution authority. There are no compatibility wrappers or new mathematical/source verdicts.

The v2 code/freeze, original authorization, failed report/receipt and all12 actual original PNGs remain unchanged. Their hashes and real PNG dimensions were checked; none was viewed or accepted as pixels in this preparation. The partial run is not a full runtime or pixel acceptance. The future v3 run must independently produce all48 originals; the old12 are not substituted.

Only AST syntax parsing and source/file inspection were performed. Neither v3 checker nor common was imported/executed. No server, HTTP request, browser, OS approval request, build, API, shared edit, stage or commit occurred. Root can review the exact diff/actual disabled context and then obtain the requested new scoped approval for:

```text
/opt/anaconda3/bin/python .astis/huanjian-resume-20261103/run_check.py cosine-expansion-final-browser-v3 .astis/huanjian-gc-integration-20261105/browser-venv/bin/python .astis/huanjian-gc-fixed-spectrum-cosine-expansion-integration-20261109/independent-reader/browser-preparation-v3/check_final_reader_v3.py --authorization-json <ACTUAL_NEW_ROOT_AUTHORIZATION_PATH> --authorization-sha256 <ACTUAL_NEW_ROOT_AUTHORIZATION_SHA256>
```

The placeholders remain documentation. Old v2 OS approval/authorization does not authorize v3. Actual same-core original-image review, own-site/external-GitHub limits, both open main bounds, remote release, park and purification remain separate.
