# Phase 2a: standalone statement, binder and literal-definition judgment

Actor: `/root/signal_topology`. This judgment is frozen before exposure to any
extractor graph, coverage records, extractor rationale, implementation, or
prior/root mathematical verdict. The independent raw-source cognition remains
the unchanged Phase 1 record and manifest SHA-256
`a647b8bbcf6ecb63780c0e71a2acd11a6db5be9d08703e4ac0d902fe72e69a42`.

The only newly opened input was
`.astis/huanjian-gc-fixed-spectrum-signal-strength-20261110/strict-preproof-seal-projection-v1.json`,
5842 bytes, independently verified SHA-256
`e8322849cd533289522de2de96ae5913364b1446dee114d4224956c1ced02fca`.
The signature text and literal let bodies were read as the objects to audit;
the projection's explanations are not independent mathematical evidence. No
proof body, API search, graph record, candidate-history artifact or process
chronology record was opened. Writes remain append-only new files in this
reviewer's own directory.

## Standalone decision

**ACCEPT, with the exact bounded scopes below, at the mathematical statement,
binder and literal-definition level. No HOLD is identified in that level.**

The public producer expresses a source-faithful selected numerical slice of
the target-side bookkeeping in Section 4.3: positivity and actual Gaussian
moment/signal lower bounds, uniform in the original scalar parameter regime.
It does not express the full detector, the .9 target-event bound, an
algorithm-side comparison, a sampling query lower bound, or all of Lemma 4.5.
The additional output positivity claims follow the meaning of the same source
quantities and do not add assumptions. This decision does not assert a proof
exists in the repository or that any implementation discharges its obligations.

The private consumer is mathematically aligned with a narrower target-side
zero-threshold event under the actual diagonal Gaussian. It is not a literal
restatement of the paper's shifted detector. Its explicit private non-Anchor
status is therefore essential: it receives no separate credit for proving the
original detector or the full display `S4.Ex26`. If that scope were expanded,
this judgment would not transfer to the expanded claim.

## Exact reviewed interfaces

Public name:
`AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumSignalStrength.eventual_actual_gaussian_signal_strength`.
The projection records signature digest
`4ba04efc22eb664771b1b2f471dc62cd50694a12f70712010287908788362d91`.
The interface is evaluated as its exact supplied text, not by the theorem name.

Private name: `actual_gaussian_source_query_zero_event_le_tenth`.
The projection records signature digest
`e24c33732826ea528bfd2d9f959b8963a022b35989f6e5740e3f7445a23de7d5`.
It is explicitly `private`, in a proposed Tests file, is not a Source Anchor,
and is not a Registry node. The reviewed claim is only the specified actual-law
event inequality.

No signature is conditional on a producer theorem being installed, on any
previous result's conclusion, or on a moment/probability certificate. No
unfolded project-owned `Prop` alias, structure or typeclass hides a logical
premise in these texts. All meaning-carrying project-local objects are literal
lets displayed within the signature. Native mathematical types and operations
do not conceal a new project-owned assumption interface here.

## Exhaustive logical-binder audit

The two signatures have the same scalar binder prefix. The following audit
applies independently to both occurrences; the private conclusion then differs.

| Exact item | Class | Source meaning and scope |
| --- | --- | --- |
| `{δ : ℝ}` | TYPING | Real carrier for the fixed source parameter. Its universally quantified status is outside the existential threshold. |
| `(hδ0 : 0 < δ)` | SOURCE | The original fixed-delta regime, first strict endpoint. |
| `(hδ1 : δ < 1)` | SOURCE | The other strict endpoint of the same original regime. |
| `∃ d₀ : ℕ` | OUTPUT; no input-assumption class | One witness threshold, chosen after delta and before all varying parameters. It is neither an assumed certificate nor a RULED correction. |
| `∀ (d : ℕ)` | TYPING | Integer dimension. Eventual source-domain positivity is supplied by choosing the output threshold internally. |
| `d₀ ≤ d →` | SOURCE | The original sufficiently-large-dimension restriction relative to that one witness. It is a premise of each eventual instance, not a free threshold input. |
| `∀ (κ : ℝ)` | TYPING | Real condition parameter, quantified after the threshold. |
| `2 ≤ κ →` | SOURCE | Original lower endpoint of the fixed-spectrum regime. |
| `κ ≤ (d : ℝ) ^ (1 - δ) →` | SOURCE | Original upper condition-number restriction, including its dependence on the same delta. |
| `∀ (q : ℕ)` | TYPING | Nonnegative integer query index/cap used in the numerical source slice. |
| `(q : ℝ) ≤ (δ / 256) * Real.sqrt κ * Real.log (d : ℝ) →` | SOURCE | Original cap from the Section 4.3 hypothetical algorithm's regime. The numerical moment statement needs this scalar restriction, not an algorithm witness. |
| each subsequent `let` | DEFINITION, not a logical input | Bodies are literal objects audited below. |

There are no STANDING logical-premise bundles needing recursive expansion in
the provided signatures; source definitions supply the meaning of their
literal objects. There is no RULED premise: no human correction is asserted.
There is no EXCESS logical input. In particular, neither signature assumes
`n<d`, `d-n>=sqrt(kappa)`, positivity of a moment, a target-bias bound,
integrability, positive definiteness, spectral admissibility, a favorable event,
or the selected signal lower bound. Any such needed fact must be derived
internally from the declared scalar regime and the selected threshold.

The existential conclusion does not return a threshold varying with kappa,
q, a random draw, a Gaussian law, or epsilon. The same d0 works for all kappa
and q allowed at every d beyond it. Both statements are independent of epsilon;
that omission is appropriate for this source numerical slice, whose actual
moments do not depend on the accuracy parameter. Neither claims to be the
full theorem about sampling algorithms.

## Literal definition and domain audit

`n := 2*q+1` is the source positive odd frequency. It is natural-valued, with
the real cast made explicit in the cosine. Positivity and eventual `n<d`
must be consequences, not user-supplied frequency hypotheses. The cap includes
q=0 and its resulting n=1; the signature does not silently exclude that case.

`θ i := ((i.val : ℝ)+1/2)*pi/(d:ℝ)` is exactly the source midpoint grid after
the zero-based reindexing `source i = i.val+1`. In particular, the plus one
half is correct under `Fin d`. The finite carrier supplies precisely d
coordinates. Selecting d0 large enough ensures the denominator d is positive
on the asserted source range; totalized real division at d=0 is not being
used to claim a new source formula at dimension zero.

`eigenvalue i := (κ+1)/2 + (κ-1)/2*cos(θ i)` agrees with source Eq. (11).
`Λ := Matrix.diagonal eigenvalue` is the diagonal precision, with no random
rotation in this interface. All off-diagonal entries are literally zero.
On the asserted source range, the source cosine bound gives positive
eigenvalues at least one; positive definiteness/invertibility belongs to the
internal obligations. No indefinite matrix branch is intended as an
additional off-source definition.

`μ := multivariateGaussian 0 Λ⁻¹` uses zero mean and the **inverse precision
as covariance**. It does not interchange precision and covariance. The
specified Euclidean-space carrier matches the d real coordinates. A source
faithfulness proof must identify this standard multivariate-Gaussian measure
with the actual probability law `N(0,Λ⁻¹)` on this positive spectral domain.
The assertion is not a theorem about a free measure that merely happens to
satisfy some supplied moment inequalities. The totalized standard inverse and
Gaussian constructors do not introduce a project-owned choose-or-zero
fallback here. I did not inspect their implementation/API and do not certify
library proof obligations by this statement review.

`Q x := ∑ i, cos((n:ℝ)*θ i)*(WithLp.ofLp x i)^2` is the literal diagonal
quadratic form `xᵀD_n x`. The coordinate conversion exposes the ordinary real
coordinates of the Euclidean vector; there is no norm normalization or hidden
factor d in Q. Cosine weights can have either sign, as they should.

`M := ∫ x, ‖x‖^2 ∂μ` is the actual-law expected squared Euclidean norm, with
no division by d and no replacement by an assumed trace formula. `b := ∫ x,
Q x ∂μ` is the signed target mean called `μ_n` in the source. It is not the
source's positive numerical constant b. These real Bochner integrals are
totalized operations in Lean, so finite integrability must be established
internally for the intended expectation meaning. The asserted Gaussian
spectral domain supplies the mathematical setting for that obligation; it is
not an extra source-facing premise.

`β := |b| / M` is exactly the source dimensionless normalized target bias.
Its denominator is the same actual M. Positive M and positive beta are
outputs. They are not implicit preconditions in the literal division body,
nor substitutes for proving the relation to the source exact moments.

`B := (1-exp(-4))*exp(-3)` is the positive source scalar named b in the
target-side bookkeeping. Its constants and signs agree with the original.
The renaming of the source μ_n to Lean b, and source b to Lean B, causes no
mathematical change provided that distinction remains visible in exposition.

Real powers in the parameter restriction and lower-bound conclusions have
positive base d after the internally chosen threshold. Square roots have
positive arguments d and kappa in the asserted regime; the log is of positive
d. These are necessary internal domain facts, not sources of implicit public
assumptions. In particular, the statement does not request an extra rpow or
log identity as an input certificate.

All displayed local objects are literal; none is characterized by an existence
predicate, selected by a choice branch, or defined only as a quotient or a
representative. No characterization/uniqueness theorem is needed to define
these particular lets. The mathematical identification of a Gaussian law and
its moments still needs a proof in a later phase.

## Public conclusion versus the source selected slice

The five conjuncts are:

1. `0<M`;
2. `0<β`;
3. `(d:ℝ)/(2*sqrt κ) ≤ M`;
4. `(d:ℝ)^((1+δ)/2)/2 ≤ M`;
5. `(B^2/2)*sqrt(d:ℝ) ≤ M*β^2`.

The two M inequalities are the successive source bounds in
`S4.SS3.SSS0.Px2.p2`. The last is the source signal estimate in `S4.Ex24`
with its literal moment product and the correct absolute constant, not an
estimate of a differently normalized proxy. M positivity and beta positivity
agree with the finite-grid target means and signed-bias reasoning in C.3.
There is no strengthened constant, omitted parameter dependence, or threshold
quantifier change. All five conjuncts concern the same actual μ, M and beta.

The selected slice omits the source's tau/beta convergence bound, the explicit
beta lower bound, the final 320 selection and the event/Chebyshev comparison.
Those omissions are legitimate at this bounded source interface. They mean
the producer cannot by itself be credited with discharging those other source
regions, and a later graph must preserve any such unproved boundary. This
is a partial source result, not coverage of the entire paragraph or theorem.

## Private actual-law zero-event scope

The private conclusion is exactly
`(μ {x | (-1:ℝ)^n * Q x ≤ 0}).toReal ≤ 1/10`.
The event uses the same frequency and the same actual diagonal Gaussian as
the public numerical slice. It concerns the signed quadratic statistic at
threshold zero. There is no norm subtraction and no random O in this event.
The finite-valued quadratic is Borel measurable; the standard probability law
must be recognized internally, so `.toReal` is a genuine probability and not
the totalization of an infinite ENNReal value. No event-probability premise is
being smuggled through the interface.

The source event `S_A(Y)>0` instead uses the signed, **rotated** quadratic
minus `2*tau*‖Y‖²`. Its bad event is that shifted statistic at most zero.
Orthogonal diagonalization relates the raw quadratic and norm, but merely
putting the raw signed statistic above zero does not put it above the
positive norm-dependent shift. The private event is a narrower bad event;
the private inequality is consequently a weaker target-side guarantee than
the original shifted detector guarantee. Its truth or verification cannot
be presented as proof of `S4.Ex26`. This is a scope comparison, not an
alternate proof construction.

The private claim preserves the same uniform output-threshold order and the
original scalar regime. As a private non-Anchor application of source-backed
quantities, it has no statement-fidelity obstruction at this stage. Its
actual-law identity, integrability, finite-probability interpretation, and
numeric inequality remain proof obligations to verify independently later.

## Frozen limits and next phase

No standalone mathematical statement/binder/definition HOLD is recorded for
these exact two signatures. ACCEPT here is expressly not a dependency-graph
verdict, proof-success verdict, source-coverage certification, publication
status, or chronology audit. It does not validate any candidate, graph edge,
unopened appendix proof or extractor interpretation. Phase 1 and this phase
must remain unchanged after graph exposure. The next mathematical phase may
open only the extractor's proposed source graph/coverage, without its private
rationale or verdict, and challenge that topology against the two independent
frozen records.
