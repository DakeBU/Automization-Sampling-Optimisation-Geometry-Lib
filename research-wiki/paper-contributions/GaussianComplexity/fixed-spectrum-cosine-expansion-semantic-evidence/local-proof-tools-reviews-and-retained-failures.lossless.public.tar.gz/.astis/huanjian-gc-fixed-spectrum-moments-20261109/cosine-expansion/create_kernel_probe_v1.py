from pathlib import Path
import json
P=Path('.astis/huanjian-gc-fixed-spectrum-moments-20261109/cosine-expansion')
s=json.loads(Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-cosine-expansion-statement-seal.json').read_bytes())
head,body=s['actual_private_consumer']['signature'].split(' :\n',1)
params=head.removeprefix('private theorem actual_inverse_grid_cosine_series')
expected='def ExpectedPrivate : Prop := ∀'+params+',\n'+body+'\n'
example=s['producer']['signature'].replace('theorem actual_inverse_spectrum_cosine_expansion','example',1).rstrip()+''' := by
  exact AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumCosineExpansion.actual_inverse_spectrum_cosine_expansion hκ

'''
probe='''import Tests.GaussianComplexityFixedSpectrumCosineExpansion
open scoped BigOperators
open Filter Lean
set_option autoImplicit false

'''+example+expected+'''
run_cmd do
  let env := (← getEnv).setExporting false
  setEnv env
  let target := `AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumCosineExpansion.actual_inverse_spectrum_cosine_expansion
  let matches := env.constants.toList.filter fun (n, _) =>
    n == target || n.toString.endsWith ".actual_inverse_grid_cosine_series"
  unless matches.length == 2 do throwError "Expected exactly two actual packet constants"
  let allowed := [`propext, `Classical.choice, `Quot.sound]
  for (n, ci) in matches do
    let some proof := ci.value? true | throwError "Missing actual kernel proof term"
    let used := proof.getUsedConstants.toList
    let astis := used.filter fun k => k.toString.startsWith "AutoSamplingTheory."
    if n == target then
      unless astis.isEmpty do throwError "Unexpected public ASTIS producer parent: {astis}"
    else
      unless astis == [target] do throwError "Actual consumer must use exactly the new canonical producer: {astis}"
    let axs ← Lean.collectAxioms n
    unless axs.all (fun a => allowed.contains a) do throwError "Unexpected axiom: {axs}"
    logInfo m!"ACTUAL_TARGET {n}"
    logInfo m!"ACTUAL_TYPE {n}: {ci.type}"
    logInfo m!"DIRECT_ASTIS {n}: {astis}"
    logInfo m!"DIRECT_ALL {n}: {used}"
    logInfo m!"KERNEL_AXIOMS {n}: {axs}"
    if n != target then
      Lean.Elab.Command.liftCoreM <| addDecl <| Declaration.thmDecl {
        name := Name.mkSimple "ActualPrivateSealedTypeCheck"
        levelParams := []
        type := mkConst (Name.mkSimple "ExpectedPrivate")
        value := mkConst n
      }
      logInfo "ACTUAL_PRIVATE_SEALED_LITERAL_KERNEL_TYPE_APPLICATION_PASS"

#print axioms ActualPrivateSealedTypeCheck
#print axioms AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumCosineExpansion.actual_inverse_spectrum_cosine_expansion
'''
q=P/'KernelAndExactMeaning.lean';assert not q.exists();q.write_text(probe)
print(str(q))
