#!/opt/anaconda3/bin/python
import hashlib,json,pathlib
BASE=pathlib.Path(__file__).resolve().parent
ROOT=pathlib.Path('/Users/zhouhuanjian/ASTIS-GC')
def sha(data):return hashlib.sha256(data).hexdigest()
inv=json.loads((BASE/'input_inventory.json').read_text())
blobs={r['source']:(BASE/r['snapshot']).read_bytes() for r in inv}
p='AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumCosineGram.lean'
t='Tests/GaussianComplexityFixedSpectrumCosineGram.lean'
l='website/content/declaration_lessons/huanjian-fixed-spectrum-cosine-gram.json'
pub='website/content/publications/huanjian-fixed-spectrum-cosine-gram.json'
packet=json.loads((BASE/'inputs/fresh-source-reviewer-packet.json').read_text())
context=packet['candidate_publication_context']
lesson=json.loads(blobs[l])['units'][0]
publication=json.loads(blobs[pub])['items'][0]
assert context['current_lean_module'].encode()==blobs[p]
assert context['file']==sha(blobs[p])
steps=[]
for index,step in enumerate(lesson['steps'],1):
    code=step['lean'].encode();target=blobs[t] if index>=5 else blobs[p]
    pos=target.find(code)
    assert pos>=0,(index,'not literal target substring')
    assert target.find(code,pos+1)<0,(index,'ambiguous duplicate')
    start=target[:pos].count(b'\n')+1
    end=start+code.count(b'\n')-(1 if code.endswith(b'\n') else 0)
    steps.append({'step':index,'title':step['title'],'target':t if index>=5 else p,
                  'byte_start':pos,'byte_end_exclusive':pos+len(code),'line_start':start,
                  'line_end':end,'bytes':len(code),'sha256':sha(code),
                  'complete_test_module':index==6 and code==blobs[t]})
assert len(steps)==6
projection_mismatches=[key for key,value in context['lesson'].items() if lesson.get(key)!=value]
assert not projection_mismatches,projection_mismatches
for key in ['source','statement','formulae','assumptions','obligations']:
    assert context[key]==publication[key],key
assert packet['publication_binding_sha256']=='2c69e97d04c07f82e06cc79d73e7b0a1708dcae4dad8b4ae6c644e5173d27c10'
hash_matches=[]
for object_name,obj,expected in [('packet-without-self',{k:v for k,v in packet.items() if k!='packet_sha256'},packet['packet_sha256']),
                                 ('context',context,packet['publication_binding_sha256'])]:
  for ascii_flag in [False,True]:
    for indent in [None,2,4]:
      for compact in [False,True]:
        for trailing in ['', '\n']:
          kwargs={'sort_keys':True,'ensure_ascii':ascii_flag,'indent':indent}
          if compact:kwargs['separators']=(',',':')
          digest=sha((json.dumps(obj,**kwargs)+trailing).encode())
          if digest==expected:
            hash_matches.append({'object':object_name,'ensure_ascii':ascii_flag,'indent':indent,
                                 'compact':compact,'trailing_LF':bool(trailing),'sha256':digest})
mapping=json.loads(blobs['research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-cosine-gram-semantic-evidence/source-to-lean-map-v1.json'])
deps=[]
(BASE/'dependencies').mkdir(exist_ok=True)
for row in mapping['locator_slices']:
    name=row['file']
    if name not in blobs:
        assert name.startswith('.lake/packages/mathlib/Mathlib/'),name
        data=(ROOT/name).read_bytes();blobs[name]=data
        snapshot='dependencies/'+name.replace('/','__')
        (BASE/snapshot).write_bytes(data)
        deps.append({'source':name,'bytes':len(data),'sha256':sha(data),'snapshot':snapshot})
    data=blobs[name]
    assert sha(data)==row['raw_wholefile_sha256'],(row['slice_id'],'wholefile')
    fragment=data[row['byte_start_inclusive']:row['byte_end_exclusive']]
    assert fragment.decode()==row['literalLF'],(row['slice_id'],'literal')
    assert sha(fragment)==row['exact_block_sha256'],(row['slice_id'],'blockhash')
    chars=data.decode()[row['character_start_inclusive']:row['character_end_exclusive']]
    assert chars==row['literalLF'],(row['slice_id'],'char locator')
    assert data[:row['byte_start_inclusive']].count(b'\n')+1==row['start_line_1based_inclusive']
raw=(BASE.parent/'phase1/inputs/2610.20492v1.html').read_bytes()
for anchor,row in mapping['raw_source_anchor_locators'].items():
    fragment=raw[row['byte_start']:row['byte_end_exclusive']]
    assert sha(fragment)==row['sha256'],anchor
result={'candidate_commit':'72e5d1405284f729f4eb600c5ae5dd556365b7e2',
        'packet_current_module_matches_candidate_blob':True,
        'packet_lesson_projection_matches_candidate_lesson':True,
        'packet_publication_projection_matches_candidate_publication':True,
        'packet_and_binding_canonical_hash_scheme_matches':hash_matches,
        'literal_folded_blocks':steps,'source_to_lean_locator_slices_verified':len(mapping['locator_slices']),
        'raw_source_anchor_locators_verified':len(mapping['raw_source_anchor_locators']),
        'independent_dependency_raw_snapshots':deps,
        'limitations':'Literal/content/source-locator integrity; source map remains a proposed correspondence. No build or native constant-traversal evidence was read or created.'}
(BASE/'bindings_locators_blocks_verification.json').write_text(json.dumps(result,indent=2)+'\n')
(BASE/'dependency_inventory.json').write_text(json.dumps(deps,indent=2)+'\n')
print(json.dumps(result,indent=2))
print('COMPACT_MAP_ROWS')
for row in mapping['canonical_rows']:
    print(row['canonical_id'],row['definition_or_lemma_locator_slice'],row['role'])
print('COMPACT_CORRESPONDENCES')
for row in mapping['correspondence_slices']:
    print(row['slice_id'],','.join(row['source_anchors']),row['mathematical_role'])
