#!/opt/anaconda3/bin/python
import datetime
import hashlib
import json
import os
import pathlib
import shutil
import stat

BASE = pathlib.Path(__file__).resolve().parent
PHASE = BASE/'phase1'
EXPECTED = '6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
assert not PHASE.exists(), 'Refuse to overwrite a prior phase.'
raw = (BASE/'inputs/2610.20492v1.html').read_bytes()
assert len(raw)==951991 and hashlib.sha256(raw).hexdigest()==EXPECTED
locators = json.loads((BASE/'source_spans.json').read_text())
for row in locators:
    data = (BASE/row['snippet']).read_bytes()
    assert data == raw[row['utf8_byte_start_0']:row['utf8_byte_end_exclusive_0']]
    assert hashlib.sha256(data).hexdigest()==row['sha256']
math = json.loads((BASE/'all_C2_math.json').read_text())
assert len(math)==167
assert len({m['id'] for m in math})==167
assert sum(m['display']=='block' for m in math)==28
commands = [json.loads(line) for line in (BASE/'actual_commands.jsonl').read_text().splitlines()]
for row in commands:
    for stream in ['stdout','stderr']:
        data = (BASE/row[stream+'_file']).read_bytes()
        assert len(data)==row[stream+'_bytes']
        assert hashlib.sha256(data).hexdigest()==row[stream+'_sha256']
assert all(row['returncode']==0 for row in commands)
# Preserve the exact earlier script input, explicitly marked as reconstructed.
v2 = (BASE/'pin_spans.py').read_text()
v1 = v2.replace("            or 'ltx_equationgroup' in tag.get('class',[])\n", '')
v1 = v1[:v1.index('math_records = []')]
(BASE/'pin_spans.initial.py').write_text(v1)
PHASE.mkdir()
excluded = {'phase1','freeze_execution.stdout','freeze_execution.stderr','freeze_execution.json'}
for path in sorted(BASE.iterdir()):
    if path.name in excluded:
        continue
    target = PHASE/path.name
    if path.is_dir():
        shutil.copytree(path,target)
    elif path.is_file():
        shutil.copy2(path,target)
entries=[]
for path in sorted(PHASE.rglob('*')):
    if path.is_file():
        data=path.read_bytes()
        path.chmod(0o444)
        entries.append({'path':str(path.relative_to(PHASE)), 'bytes':len(data),
                        'sha256':hashlib.sha256(data).hexdigest(),'mode':'0444'})
manifest={'phase':'raw-first-before-candidate-or-decoder','raw_sha256':EXPECTED,
          'excluded_self_and_receipt':['manifest.json','freeze_receipt.json'],
          'payloads':entries}
manifest_path=PHASE/'manifest.json'
manifest_path.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
manifest_path.chmod(0o444)
manifest_hash=hashlib.sha256(manifest_path.read_bytes()).hexdigest()
cognition_hash=hashlib.sha256((PHASE/'raw_first_cognition.md').read_bytes()).hexdigest()
for path in sorted(PHASE.rglob('*'),reverse=True):
    if path.is_dir(): path.chmod(0o555)
receipt={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
         'phase':'phase1','claim':'raw-first cognition frozen; no candidate verdict',
         'raw_input_bytes':len(raw),'raw_input_sha256':EXPECTED,
         'manifest_sha256':manifest_hash,'cognition_sha256':cognition_hash,
         'payload_count':len(entries),'verified_raw_span_count':len(locators),
         'verified_math_count':len(math),'observed_captured_command_count':len(commands),
         'observed_captured_returncodes':[row['returncode'] for row in commands],
         'payload_modes_verified_before_receipt':all(stat.S_IMODE((PHASE/e['path']).stat().st_mode)==0o444 for e in entries),
         'manifest_mode_observed':format(stat.S_IMODE(manifest_path.stat().st_mode),'04o'),
         'planned_phase_directory_mode':'0555',
         'receipt_is_excluded_from_manifest':True,
         'actual_finalizer_stdout_stderr_and_exit_record':'../freeze_execution.json'}
receipt_path=PHASE/'freeze_receipt.json'
receipt_path.write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
receipt_path.chmod(0o444)
PHASE.chmod(0o555)
assert stat.S_IMODE(PHASE.stat().st_mode)==0o555
assert all(stat.S_IMODE(p.stat().st_mode)==0o444 for p in PHASE.rglob('*') if p.is_file())
assert all(stat.S_IMODE(p.stat().st_mode)==0o555 for p in PHASE.rglob('*') if p.is_dir())
# The phase cannot append a record about its own final stdout without a cycle.
# Print actual observed post-freeze state for the outer executor to preserve.
observed={'phase_directory_mode_observed':format(stat.S_IMODE(PHASE.stat().st_mode),'04o'),
          'all_phase_file_modes_observed_0444':True,
          'all_phase_subdirectory_modes_observed_0555':True,
          'manifest_sha256':manifest_hash,'cognition_sha256':cognition_hash,
          'receipt_sha256':hashlib.sha256(receipt_path.read_bytes()).hexdigest(),
          'phase_directory':str(PHASE),'payload_count':len(entries),
          'verified_source_spans':len(locators),'verified_math_elements':len(math)}
for path in BASE.rglob('*'):
    if path.is_file() and PHASE not in path.parents:
        path.chmod(0o444)
print(json.dumps(observed,ensure_ascii=False,indent=2))
