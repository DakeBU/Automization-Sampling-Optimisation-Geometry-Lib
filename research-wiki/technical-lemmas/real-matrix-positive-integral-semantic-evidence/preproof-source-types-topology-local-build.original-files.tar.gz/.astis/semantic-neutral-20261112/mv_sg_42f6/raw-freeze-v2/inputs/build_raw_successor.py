from pathlib import Path
import json,hashlib,shutil,datetime
BASE=Path('/Users/zhouhuanjian/ASTIS-GC/.astis/semantic-neutral-20261112/mv_sg_42f6');OLD=BASE/'raw-freeze-v1';OUT=BASE/'raw-freeze-v2'
def sha(b):return hashlib.sha256(b).hexdigest()
assert not OUT.exists()
oldm=(OLD/'freeze-manifest.json').read_bytes();assert sha(oldm)=='fc43d029ffd38278845eefd77f397929647ee9c3594b693f8540433675a9516d'
for x in json.loads(oldm)['files']:
 b=(OLD/x['path']).read_bytes();assert len(b)==x['bytes'] and sha(b)==x['sha256']
OUT.mkdir()
for x in json.loads(oldm)['files']:
 p=OUT/x['path'];p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(OLD/x['path'],p)
def j(n):return json.loads((OUT/n).read_text())
def dump(n,v):(OUT/n).write_text(json.dumps(v,ensure_ascii=False,sort_keys=True,indent=2)+'\n',encoding='utf-8')
steering='''确认locator更正：Z定义p13；Ex113/114及centered/cos²比较在p14；p15 Bernstein只作EXCLUDED context。保留初始任务请求的p15措辞并明确更正，不称source defect。Root最终形成中的private consumer预计给两种实际centered-square的Integrable输出和它们variance-sum Euclidean operator norm≤2r(r+2)/d（variance parameter原意）；所需PSD→operator-norm与完整Bochner/integrability为internal ports，绝不新hyp。类型未最终seal前仍只raw理解/notes，不按此提前接受signature或graph。No target API search/implementation。'''
(OUT/'inputs/steering-envelope.txt').write_text(steering+'\n',encoding='utf-8');(OUT/'inputs/predecessor-manifest.json').write_bytes(oldm)
shutil.copyfile(BASE/'working/build_raw_successor.py',OUT/'inputs/build_raw_successor.py')
inv=j('atomic-inventory.json');changes=[]
for x in inv['items']:
 if x['id'] in ['bernstein.centered-context','bernstein.self-adjoint-context']:
  x['disposition']='EXCLUDED';x['reason']='Latest source-scope steering excludes all p15 Bernstein context. Centering/self-adjointness needed for selected square bounds remain internal obligations from actual definitions, not this Bernstein application premise.'
  changes.append({'id':x['id'],'old_disposition':'NODE','new_disposition':'EXCLUDED','reason':x['reason']})
inv['counts']={'atoms':len(inv['items']),'NODE':sum(x['disposition']=='NODE' for x in inv['items']),'EXCLUDED':sum(x['disposition']=='EXCLUDED' for x in inv['items'])}
inv['successor_note']='Raw successor after parent scope steering, before this actor new exact types; original v1 preserved. No source wording or locator changed.';dump('atomic-inventory.json',inv)
coverage=j('coverage.json');coverage['source_numbering_note']='Z is defined p13. Ex113/114 and uncentered/centered/cos² variance comparisons are p14. All p15 Bernstein application context, including its structural assertions, is EXCLUDED by the latest prospective packet scope.';dump('coverage.json',coverage)
obs=j('raw-source-use-observations.json')
for x in obs['observations']:
 if x['use_site']=='A3.SS2.p15':x['reading']='All p15 Bernstein context is excluded by latest scope steering. Centering/self-adjointness for selected actual square bounds are internal obligations from literal definitions; no p15 concentration or independence credit.'
dump('raw-source-use-observations.json',obs)
text=(OUT/'raw-interpretation.md').read_text()
text=text.replace('The p15 centered/self-adjoint structural assertion is retained only as source context for ordinary internal obligations.','All p15 Bernstein context, including its centered/self-adjoint structural assertion, is EXCLUDED in this successor by the latest scope steering. Centering/self-adjointness remain internal obligations from literal actual definitions.')
text+='\nThe latest prospective consumer refinement is integrability of both actual centered-square families and Euclidean-operator-norm bounds for their variance sums by2r(r+2)/d. This is recorded only as prose direction before this actor sees any exact new type/seal. The conversion from PSD/self-adjoint matrix-sum bounds to those norm bounds and complete Bochner/integrability justifications remains internal; no signature, graph, theorem interface or applicability is accepted here.\n'
(OUT/'raw-interpretation.md').write_text(text,encoding='utf-8')
dump('successor-qualification.json',{'predecessor_path':str(OLD),'predecessor_manifest_sha256':sha(oldm),'original_bytes_preserved':True,'reason':'Parent source-numbering/scope refinement arrived after initial raw freeze. Preserve chronology and qualify in a raw successor rather than rewriting v1.','source_numbering_correction':'Initial task wording about p15 is retained verbatim in inputs/task-envelope.txt; exact source shows variance comparisons at p14 and Bernstein at p15. This is locator/scope clarification, not a source defect.','disposition_changes':changes,'prospective_consumer':'Both actual centered-square integrability outputs and variance-sum Euclidean-operator-norm <=2r(r+2)/d; raw prose only.','no_exact_new_type_exposure':True,'no_type_graph_topology_acceptance':True,'no_permission_proof_or_status_grant':True})
record=j('input-exposure-protocol-chronology.json');record['successor_steering_envelope_sha256']=sha((OUT/'inputs/steering-envelope.txt').read_bytes());record['successor_note']='Only own raw predecessor and this new parent prose steering read. No exact target API/type/implementation exposure.';dump('input-exposure-protocol-chronology.json',record)
m={'format':'astis-matrix-variance-raw-source-freeze-v2','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'phase':'RAW_ONLY_BEFORE_THIS_ACTOR_NEW_TYPE_EXPOSURE','predecessor_manifest_sha256':sha(oldm),'new_statement_seal_seen_by_this_actor':False,'global_seal_existence_not_asserted':True,'source_sha256':'6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915','owned_source_root_full_path':str(BASE),'graph_or_topology_admitted':False,'files':[]}
for p in sorted(OUT.rglob('*')):
 if p.is_file():b=p.read_bytes();m['files'].append({'path':str(p.relative_to(OUT)),'bytes':len(b),'sha256':sha(b)})
dump('freeze-manifest.json',m);digest=sha((OUT/'freeze-manifest.json').read_bytes());(OUT/'freeze-manifest.sha256').write_text(digest+'  freeze-manifest.json\n')
for p in OUT.rglob('*'):
 if p.is_file():p.chmod(0o444)
for p in sorted([p for p in OUT.rglob('*') if p.is_dir()],key=lambda p:len(p.parts),reverse=True):p.chmod(0o555)
OUT.chmod(0o555)
print(json.dumps({'raw_freeze_path':str(OUT),'manifest_sha256':digest,'interpretation_sha256':sha((OUT/'raw-interpretation.md').read_bytes()),'inventory_sha256':sha((OUT/'atomic-inventory.json').read_bytes()),'locators_sha256':sha((OUT/'locators-and-source-units.json').read_bytes()),'coverage_sha256':sha((OUT/'coverage.json').read_bytes()),'ports_sha256':sha((OUT/'unaccepted-raw-ports.json').read_bytes()),'source_use_sha256':sha((OUT/'raw-source-use-observations.json').read_bytes()),'qualification_sha256':sha((OUT/'successor-qualification.json').read_bytes()),'counts':inv['counts'],'predecessor_unchanged':sha((OLD/'freeze-manifest.json').read_bytes())},indent=2))
