from pathlib import Path
import json,hashlib,datetime,gzip,subprocess,tarfile,shutil,sys
sys.path.insert(0,'tools')
import astis_advance as a
sha=lambda raw:hashlib.sha256(raw).hexdigest()
def put(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
b=Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-normalizer-semantic-evidence')
out=b/'actual-consumer-interface'
review=b/'topology-challenge/phase1/actual-consumer-admission-checkpoint-v1'
mf=review/'manifest.json'
assert sha(mf.read_bytes())=='ab3c0b6a5ff988a8925511bbb464adc207bf788f3ec122d26cb2725f6db02c83'
m=json.loads(mf.read_bytes())
for row in m['actual_raw_inputs']+m['necessary_standard_meaning_windows']+m['frozen_outputs']:
 p=Path(row.get('archive_file',row.get('file')))
 assert sha(p.read_bytes())==row['sha256'] and len(p.read_bytes())==row['bytes']
for p,h in m['prior_freezes_verified_unchanged'].items():assert sha((review.parent/p).read_bytes())==h
vp=review/'consumer-admission-verdict.json'
assert sha(vp.read_bytes())=='f87ad1e5d253b041bc1ce6bc6c8440f76d9ecb60bce3a13be8d9ab388bfd838b'
v=json.loads(vp.read_bytes())
assert v['status']=='PREPROOF_EXACT_ACTUAL_CONSUMER_INTERFACE_ADMITTED' and not v['blocking_findings'] and not v['EXCESS']
assert v['proof_target_API_admission']['may_proceed_after_this_checkpoint']
sp=out/'statement-seal.json';s=json.loads(sp.read_bytes())
assert sha(sp.read_bytes())==v['consumer_seal_sha256']=='4d036cbb704d1090d059274771f76b1ebc15d60d3ceb18c9e33dd4437b072cc8'
assert s['consumer_signature_sha256']==v['consumer_signature_sha256']=='f23354ebeb976688e4d724ca9a3b30a219599bb8b456cafae728a846c17242a6'
assert not Path('AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumNormalizer.lean').exists() and not Path('Tests/GaussianComplexityFixedSpectrumNormalizer.lean').exists()
states=a.current_advances();lp=Path('runs/substantive_advances.jsonl');ledger=lp.read_bytes();discovery=Path('runs/substantive_discoveries.jsonl').read_bytes()
cp=Path('research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-normalizer.json')
foreign={str(p):p.read_bytes() for p in cp.parent.glob('*.json') if p!=cp}
record={'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'state':'EXACT_PRODUCER_AND_ACTUAL_CONSUMER_IMPLEMENTATION_ADMITTED_ONLY_NOT_PROVED',
 'producer_source_commit':'da5360ef615a04397fb53bf5c53194cf3ec13b9f',
 'producer_signature_sha256':'3e2c0dd72fce0a272a73b4ee7d8447cde4e6ce313f7a5ccda80744f8dc8fa7f0',
 'consumer_seal_raw_sha256':sha(sp.read_bytes()),'consumer_signature_sha256':s['consumer_signature_sha256'],
 'distinct_reviewer':'/root/norm_topology_570830','distinct_verdict':str(vp),'distinct_verdict_raw_sha256':sha(vp.read_bytes()),
 'consumer_review_directory':str(review),'actual_use_contract':v['actual_use_admission'],
 'critical_definition_audit':v['critical_definition_audit'],'EXCESS':[],
 'target_implementation_and_API_search_started':False,
 'next':'After immutable admission commit, root may retrieve exact existing canonical APIs and prove exact actual integral producer plus genuinely dependent same-A normalized-law consumer. No new public assumptions or duplicate generic/canonical lemma.',
 'truth_boundary':'Actual proof/real Test dependency, independent blind/freshsource/wholemodule/reader/sourceV, root/site/graph/Chrome/integration remain pending. Full C4 calculus/minimizer/moments/Krylov, both main bounds, real adaptive/oracle/precision/TV/deterministic/expected-cost adapters and remote/purification/Seal/Goal remain open.'}
assert not (b/'implementation-admission.json').exists();put(b/'implementation-admission.json',record)
x=json.loads(cp.read_bytes());x['evidence']['before_consumer_implementation_admission']={'execution_boundary':x['evidence']['execution_boundary'],'source_detail_gap':x['source_detail_audit']['gap']}
x['statement_seal']['status']='EXACT_PRODUCER_AND_ACTUAL_CONSUMER_SOURCE_TYPE_ADMITTED_UNPROVED'
x['evidence']['actual_consumer_interface']={'seal':str(sp),'seal_raw_sha256':sha(sp.read_bytes()),'signature_sha256':s['consumer_signature_sha256'],'independent_verdict':str(vp),'independent_verdict_raw_sha256':sha(vp.read_bytes()),'status':'SOURCE_COMPATIBLE_IMPLEMENTATION_ADMITTED_UNPROVED','actual_new_producer_use_required':True}
x['evidence']['implementation_admission']=str(b/'implementation-admission.json')
x['evidence']['execution_boundary']='Exact producer and genuine actual-integral normalized same-A Gaussian consumer have independent statement/binder/criticaldefinition/sourcecoverage/topology and consumer-interface admission only. Current mathematical proofs and actual Test use remain unimplemented. Target API/proof begins only after immutable admission commit. No proof/sourceV/integration/wholeGoal claim.'
put(cp,x)
rp=b.parent/'README.md';old=rp.read_bytes();lead=('\n# Current continuation: actual normalizer and Gaussian consumer admitted; proof next\n\nRead `fixed-spectrum-normalizer-semantic-evidence/implementation-admission.json`. Exact producer signature3e2c0dd7 and consumerf23354eb/seal4d036cbb have independent source/binder/criticaldefinition/coverage/topology and consumer-interface admission. Type-only checks passed; target producer/Test remain unimplemented, normal state EXPLORING. The actual same-A Gaussian consumer must substantively use the new actual-integral result and identical canonical GPD, deriving validity/positive finite mass internally from source inputs.\n\nAfter this immutable commit, retrieve exact canonical APIs and prove the one bounded mathematical packet. All283 foreign states/442 old frontiers and other queues/results remain intact. Full C4 calculus/minimizer, moments/Krylov, both main bounds and actual oracle/precision/TV/deterministic/expected-cost adapters, remote original-owner release, purification/Seal and wholeGoal remain open. Older checkpoints below retain phase history.\n\n').lstrip().encode();rp.write_bytes(lead+old);assert rp.read_bytes()[len(lead):]==old
assert a.current_advances()==states and lp.read_bytes()==ledger and Path('runs/substantive_discoveries.jsonl').read_bytes()==discovery and all(Path(p).read_bytes()==raw for p,raw in foreign.items())
checks=b/'actual-checks'
for p in sorted(Path('.astis/huanjian-resume-20261103').glob('*-fixed-spectrum-normalizer-*.receipt.json')):
 if (checks/p.name).exists():continue
 r=json.loads(p.read_bytes());raw=Path(r['log']).read_bytes();assert sha(raw)==r['log_sha256'];shutil.copy2(p,checks/p.name);z=checks/(Path(r['log']).name+'.gz');z.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(z.read_bytes())==raw
private=Path('.astis/huanjian-fixed-spectrum-normalizer-20261108');files=sorted(p for p in private.rglob('*') if p.is_file());archive=b/'preproof-consumer-admission-tools.lossless.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz') as t:
 for p in files:t.add(p,arcname=str(p.relative_to(private)),recursive=False)
with tarfile.open(archive,'r:gz') as t:
 for p in files:assert t.extractfile(str(p.relative_to(private))).read()==p.read_bytes()
manifest=b/'preproof-consumer-admission-tools.manifest.json';put(manifest,{'archive':str(archive),'sha256':sha(archive.read_bytes()),'all_members_roundtrip_verified':True,'target_proof_or_targetAPI':False,'files':[{'path':str(p),'member':str(p.relative_to(private)),'sha256':sha(p.read_bytes())} for p in files]})
paths=[*[p for root in [out,review,checks] for p in root.rglob('*') if p.is_file()],b/'implementation-admission.json',archive,manifest];pack=b/'consumer-frozen-raw-packaging';pack.mkdir(exist_ok=False);safe=[];rows=[]
for p in paths:
 raw=p.read_bytes();tracked=subprocess.run(['git','ls-files','--error-unmatch','--',str(p)],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode==0;ignored=subprocess.run(['git','check-ignore','-q','--',str(p)]).returncode==0;binary=p.suffix in ['.gz','.zip','.png'] or b'\0' in raw;bad=not binary and (any(line.endswith((b' ',b'\t',b'\r')) for line in raw.split(b'\n')) or raw.endswith(b'\n\n'))
 if not tracked and (ignored or bad):
  z=pack/(str(len(rows)).zfill(3)+'-'+p.name+'.gz');z.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(z.read_bytes())==raw;rows.append({'original_path':str(p),'raw_sha256':sha(raw),'gzip_path':str(z),'gzip_sha256':sha(z.read_bytes()),'original_retained_unmodified':True});safe.append(z)
 else:safe.append(p)
manifest=pack/'manifest.json';put(manifest,{'rule':'Lossless frozen evidence packaging; originalbytes retained and restorepaths preserved. Mutablecell/README staged directly.','files':rows});safe.extend([manifest,cp,rp]);subprocess.run(['git','add','--',*[str(p) for p in safe]],check=True);r=subprocess.run(['git','diff','--cached','--check'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT);print(r.stdout.decode());assert r.returncode==0
for p in [cp,rp]:assert subprocess.check_output(['git','show',':'+str(p)])==p.read_bytes()
print(json.dumps({'implementation_admission_only':True,'targetproof_API_started':False,'consumer_raw_packaged':len(rows),'private_archive_sha256':sha(archive.read_bytes()),'next':'Immutable commit before first normalizer API/proof.'}))
