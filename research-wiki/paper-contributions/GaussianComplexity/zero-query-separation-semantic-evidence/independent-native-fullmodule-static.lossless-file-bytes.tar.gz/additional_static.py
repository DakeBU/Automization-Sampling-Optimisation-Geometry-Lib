from verify import *
import re,html
record=json.loads((D/'static-reader.json').read_text()); source=D/'static-output'
lesson=next((source/'lessons').glob('*.html')).read_text()
unit=json.loads((D/'candidate/website/content/declaration_lessons/huanjian-zero-query-separation.json').read_text())['units'][0]
blocks=[html.unescape(t) for t in re.findall(r'<pre class="code-block"><code class="language-lean">([\s\S]*?)</code></pre>',lesson)]
for step in unit['steps']: assert step['lean'] in blocks
export=(source/'data/lesson-sources'/(T+'.html')).read_text()
spans=re.findall(r'<span id="L(\d+)">([\s\S]*?)</span>\n',export)
assert [int(n) for n,s in spans]==list(range(1,len(spans)+1))
reconstructed=''.join(html.unescape(s)+'\n' for n,s in spans).encode()
assert reconstructed==gitbytes(T)
download_links=re.findall(r'<a\b[^>]*\bdownload(?:=|\s|>)',export)
record.update({'six_steps_exact_after_HTML_decoding':True,'T_export_full_source_reconstructed_sha256':sha(reconstructed),'T_export_full_source_bytes':len(reconstructed),'T_export_line_anchors':len(spans),'T_export_download_action_present':bool(download_links),'static_judgment':'QUALIFIED: exact statements/proofs/formulas/closed disclosures/source exports pass; HOLD full reader-neighbor source/download acceptance for private T.'})
js('static-reader-final.json',record)
print('HTML_DECODED_SIX_STEPS_AND_FULL_T_EXPORT_PASS; T_EXPORT_HAS_DOWNLOAD_ACTION='+str(bool(download_links)))
