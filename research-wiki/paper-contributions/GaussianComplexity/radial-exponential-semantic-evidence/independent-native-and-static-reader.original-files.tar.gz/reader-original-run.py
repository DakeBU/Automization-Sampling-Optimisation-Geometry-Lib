import ast
from copy import deepcopy
import json
from pathlib import Path
import sys
import traceback
from urllib.parse import urljoin, urlsplit

from bs4 import BeautifulSoup

from native import COMMIT, HERE, IG, LESSON, MAP, P, RN, SOURCE, T, digest, git, snapshot, write_json


def install_bounded_renderer():
    directories = ['website/scripts', 'tools']
    candidates = git('ls-tree', '-r', '--name-only', COMMIT, '--', *directories).decode().splitlines()
    modules = {Path(path).stem: path for path in candidates
               if str(Path(path).parent) in directories and path.endswith('.py')}
    pending = ['declaration_lessons']
    installed = {}
    while pending:
        module = pending.pop()
        if module in installed:
            continue
        relative = modules[module]
        installed[module] = snapshot(relative)
        parsed = ast.parse((SOURCE / relative).read_bytes())
        nodes = list(parsed.body)
        while nodes:
            node = nodes.pop()
            if isinstance(node, ast.Import):
                names = [alias.name for alias in node.names]
            elif isinstance(node, ast.ImportFrom):
                names = [node.module] if node.module else [alias.name for alias in node.names]
            else:
                if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                    nodes.extend(ast.iter_child_nodes(node))
                continue
            pending.extend(name for name in names if name in modules and name not in installed)
    write_json(HERE / 'renderer-inputs.json', sorted(installed.values(), key=lambda file: file['path']))
    sys.dont_write_bytecode = True
    sys.path[:0] = [str(SOURCE / path) for path in directories]


def byte_and_line_checks(unit):
    inputs = {path: (SOURCE / path).read_bytes() for path in (P, T)}
    report = []
    for i, step in enumerate(unit['steps'], start=1):
        path = P if i <= 3 else T
        file = inputs[path]
        code = step['lean'].encode()
        lo = file.index(code)
        hi = lo + len(code)
        assert file.count(code) == 1 and file[lo:hi] == code
        report.append({'step': i, 'path': path, 'start_byte': lo, 'end_byte_exclusive': hi,
                       'start_line': file[:lo].count(b'\n') + 1,
                       'end_line': file[:hi].count(b'\n'), 'sha256': digest(code)})
    assert len(report) == 4 and report[0]['end_byte_exclusive'] == report[1]['start_byte']
    assert report[1]['end_byte_exclusive'] == report[2]['start_byte']
    assert report[3]['start_byte'] == 0 and report[3]['end_byte_exclusive'] == len(inputs[T])
    verified_spans = []
    for mapping in json.loads((SOURCE / MAP).read_bytes())['mappings']:
        for span in mapping['lean']:
            file = inputs[span['path']]
            lo, hi = span['raw_UTF8_byte_span']
            line_lo, line_hi = span['LF_lines_1based']
            char_lo, char_hi = span['decoded_char_span']
            assert digest(file) == span['file_sha256']
            assert digest(file[lo:hi]) == span['span_sha256']
            assert file[lo:hi] == b''.join(file.splitlines(keepends=True)[line_lo - 1:line_hi])
            assert file[lo:hi] == file.decode()[char_lo:char_hi].encode()
            verified_spans.append(span)
    return {'exact_step_blocks': report, 'validated_Lean_map_spans': verified_spans}


def check_rendered_unit(body, unit, base, declaration_lessons, page):
    soup = BeautifulSoup(body, 'html.parser')
    article = soup.select_one('article.proof-reader.reader-progressive')
    assert article is not None
    details = article.select('details')
    assert details and all(not item.has_attr('open') for item in details)
    equations = article.select('.proof-reader-equation')
    assert [item.get_text() for item in equations] == [
        '\\[' + item['formula'] + '\\]' for item in [unit, *unit['steps']]
    ]
    steps = article.select('details.proof-reader-step')
    assert len(steps) == 4
    for item, authored in zip(steps, unit['steps'], strict=True):
        code_fold = item.select_one('.reader-step-body > details')
        assert code_fold is not None
        assert code_fold.find_previous_sibling().get('class') == ['proof-reader-equation']
        assert code_fold.select_one('summary').get_text() == 'Corresponding Lean step'
        assert code_fold.select_one('pre > code').get_text() == authored['lean']
    assert steps[-1].select_one('pre > code').get_text().encode() == (SOURCE / T).read_bytes()
    first = article.select_one('.reader-first-pass .inline-lean-statement')
    assert first.find_previous_sibling().get('class') == ['proof-reader-equation', 'reader-main-equation']
    proof = article.select_one('.lean-verification .inline-lean-proof')
    controls = []
    for panel, label in [(first, 'Copy statement'), (proof, 'Copy declaration')]:
        copy = panel.select_one('button[data-lean-copy]')
        status = panel.select_one('[data-lean-copy-status][aria-live=polite]')
        download = panel.select_one('a[download]')
        context = panel.find('a', string='Exact module and namespace context')
        assert copy.get_text() == label and status is not None
        assert download['href'] == '../downloads/lean/' + P
        assert context['href'] == '../modules/' + base.slugify(P.removesuffix('.lean').replace('/', '.')) + '.html#complete-module-source'
        controls.append({'copy': label, 'download': download['href'], 'context': context['href']})
    provenance = article.select_one('details.proof-reader-provenance')
    assert provenance is not None
    citations = []
    for source in unit['sources']:
        link = provenance.find('a', string=source['label'])
        assert link['href'] == declaration_lessons.source_link(source, page)
        assert source['scope'] in link.parent.get_text()
        citations.append(link['href'])
    assert citations[-1] == '../data/lesson-sources/' + T + '.html#L19'
    return {'closed_details': len(details), 'exact_tex_formulas': len(equations),
            'rendered_exact_adjacent_step_folds': len(steps),
            'step_4_has_its_own_copy_or_download': bool(steps[-1].select('[data-lean-copy],a[download]')),
            'producer_controls': controls, 'source_citations': citations}


def check_targets(root, page, report):
    def local_target(url):
        parts = urlsplit(urljoin('/' + page, url))
        return root / parts.path.lstrip('/'), parts.fragment

    for controls in report['producer_controls']:
        download, _ = local_target(controls['download'])
        assert download.read_bytes() == (SOURCE / P).read_bytes()
        context, fragment = local_target(controls['context'])
        context_dom = BeautifulSoup(context.read_text(), 'html.parser')
        assert context_dom.select_one(f'#{fragment} pre > code').get_text().encode() == (SOURCE / P).read_bytes()
    citation, fragment = local_target(report['source_citations'][-1])
    citation_dom = BeautifulSoup(citation.read_text(), 'html.parser')
    assert citation_dom.select_one(f'#{fragment}').get_text() == 'private theorem actual_source_row_truncation_tail'
    assert ''.join(line.get_text() + '\n' for line in citation_dom.select('pre > span[id]')).encode() == (SOURCE / T).read_bytes()
    report['local_provenance_targets'] = 'Exact producer download, complete producer context, and private consumer line 19'


def main():
    install_bounded_renderer()
    import astis_site as base
    import declaration_lessons
    import source_lineage

    base._ACTIVE_GIT = base.GitContext(COMMIT, COMMIT[:12], '', '', False, False, set())
    base._ACTIVE_GATE = base.GateEvidence(False, False, COMMIT, '', '', [], 'Bounded local reader review')
    modules, declarations = base.scan_project_sources()
    assert {module.source_file for module in modules} == {P, T, IG, RN}
    base._SOURCE_BY_NAME = {decl.full_name: decl for decl in declarations}
    base._ALL_MODULES = modules
    [original] = declaration_lessons.load_units()
    raw = (SOURCE / LESSON).read_bytes()
    data = {'source_commit': COMMIT, 'lesson_sha256': digest(raw), 'bounded_module_count': len(modules)}
    if len(sys.argv) > 1:
        corrected_commit = sys.argv[1]
        corrected_raw = git('show', f'{corrected_commit}:{LESSON}')
        assert digest(corrected_raw) == '20629617e4dfecf97d42247e95d7c3adc967191b7ecba798bc4c15a055de68cb'
        expected = deepcopy(original)
        expected['sources'][1]['scope'] = 'Complete private Lean application of the exact moment to the single-row tail at the source threshold.'
        [unit] = json.loads(corrected_raw)['units']
        assert unit == expected
        (HERE / 'corrected-lesson.exact.json').write_bytes(corrected_raw)
        data.update(corrected_commit=corrected_commit, corrected_lesson_sha256=digest(corrected_raw))
        output = HERE / 'reader-corrected'
    else:
        corrected_commit = None
        unit = original
        output = HERE / 'reader-original'
    data.update(byte_and_line_checks(unit))
    page = declaration_lessons.lesson_path(unit['declaration'])
    data['page'] = page
    try:
        body = declaration_lessons.render_unit(unit, page)
    except KeyError as error:
        assert corrected_commit is None and error.args == ('scope',)
        (HERE / 'reader-original.traceback.txt').write_text(traceback.format_exc())
        data.update(rendered=False, error='KeyError: scope',
                    source_index_with_missing_scope=1,
                    affected_source=unit['sources'][1], browser_acceptance='skipped: exact lesson renderer did not return HTML')
        write_json(HERE / 'reader-original.json', data)
        print(traceback.format_exc(), end='')
        return
    assert corrected_commit is not None, 'The original lesson unexpectedly rendered'
    data.update(check_rendered_unit(body, unit, base, declaration_lessons, page), rendered=True)
    theme = output / 'textbook/index.html'
    theme.parent.mkdir(parents=True, exist_ok=True)
    theme.write_text('<link rel="stylesheet" href="../assets/site.css">\n'
                     '<link rel="stylesheet" href="../assets/information-architecture.css">\n')
    rendered = base.page(unit['title'], page, body, extra_head='<link rel="stylesheet" href="../assets/proof-readers.css">')
    base.write_page(output, page, source_lineage.canonical_shell(rendered, page, output))
    declaration_lessons.export_sources(output, [unit])
    for module in modules:
        source_download = output / 'downloads/lean' / module.source_file
        source_download.parent.mkdir(parents=True, exist_ok=True)
        source_download.write_bytes((SOURCE / module.source_file).read_bytes())
        module_path = f'modules/{base.slugify(module.name)}.html'
        base.write_page(output, module_path, base.render_source_module(module, []))
    check_targets(output, page, data)
    data['browser_acceptance'] = 'not performed; bounded static HTML and local targets inspected'
    write_json(HERE / 'reader-corrected.json', data)
    print(f'Rendered {output / page}')


if __name__ == '__main__':
    main()
