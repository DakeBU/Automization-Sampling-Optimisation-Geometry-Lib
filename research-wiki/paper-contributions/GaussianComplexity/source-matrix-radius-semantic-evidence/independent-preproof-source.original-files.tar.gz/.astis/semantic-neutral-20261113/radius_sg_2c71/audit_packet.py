"""Finalize the independent source/binder/definition audit; never prove targets."""
from pathlib import Path
import json, hashlib, datetime, subprocess
R=Path(__file__).parent
def sha(b): return hashlib.sha256(b).hexdigest()
def dump(p,j):
    with (R/p).open('x') as f: json.dump(j,f,ensure_ascii=False,indent=2); f.write('\n')
W=Path('/Users/zhouhuanjian/ASTIS-GC')

# Exact post-freeze originals. Imported ASTIS implementation bodies are neither opened nor copied.
inputs=[
('.astis/huanjian-gc-source-matrix-radius-20261113/statement-seal-v1.json','statement-seal-v1.json'),
('.astis/huanjian-gc-source-matrix-radius-20261113/StatementFormation.lean','StatementFormation.lean'),
('lean-toolchain','lean-toolchain'),('lake-manifest.json','lake-manifest.json')]
post=[]
for p,name in inputs:
    b=(W/p).read_bytes();dest=R/'originals/post-freeze'/name;dest.parent.mkdir(parents=True,exist_ok=True)
    with dest.open('xb') as f:f.write(b)
    post.append(dict(source_path=p,portable_path=str(dest.relative_to(R)),sha256=sha(b),bytes=len(b)))
seal=json.loads((R/'originals/post-freeze/statement-seal-v1.json').read_text())
assert sha((R/'originals/post-freeze/statement-seal-v1.json').read_bytes())=='49d5fa00c9ae90d65878d955fab59d6a4bc03e942501677719881f3d26bf1a72'
for k in ['producer','actual_private_consumer']:
    assert sha(seal[k]['signature'].encode())==seal[k]['signature_sha256']

# Small, byte-original standard meaning windows. The full input-file digest remains pinned.
meaning=[
('Mathlib/Analysis/CStarAlgebra/Matrix.lean',[(98,108),(137,150),(155,186),(253,260),(263,272)]),
('Mathlib/Analysis/InnerProductSpace/PiL2.lean',[(107,114)]),
('Mathlib/Analysis/Normed/Lp/WithLp.lean',[(46,55)]),
('Mathlib/Probability/Distributions/Gaussian/Multivariate.lean',[(55,69)]),
('Mathlib/MeasureTheory/Constructions/Pi.lean',[(207,211)]),
('Mathlib/MeasureTheory/Integral/Bochner/Basic.lean',[(144,160)]),
('Mathlib/MeasureTheory/Function/L1Space/Integrable.lean',[(55,62)]),
('Mathlib/LinearAlgebra/Matrix/Kronecker.lean',[(54,56),(270,275)]),
('Mathlib/Data/Matrix/Mul.lean',[(613,617)])]
ml=[]
for p,ranges in meaning:
    src=W/'.lake/packages/mathlib'/p;b=src.read_bytes();s=b.decode();lines=s.splitlines(keepends=True)
    for a,z in ranges:
        ca=sum(map(len,lines[:a-1]));cb=sum(map(len,lines[:z]));raw=''.join(lines[a-1:z]).encode()
        name=p.replace('/','__')+f'.L{a}-{z}.raw';dest=R/'originals/standard-meaning'/name;dest.parent.mkdir(parents=True,exist_ok=True)
        with dest.open('xb') as f:f.write(raw)
        ml.append(dict(source_path='.lake/packages/mathlib/'+p,source_file_sha256=sha(b),portable_path=str(dest.relative_to(R)),
                       LF_line=[a,z],char=[ca,cb],raw_utf8_byte=[len(s[:ca].encode()),len(s[:cb].encode())],sha256=sha(raw),bytes=len(raw)))
dump('post-freeze-meaning-originals-v1.json',dict(exact_post_freeze_inputs=post,meaning_windows=ml,
    coordinate_convention='0-based half-open Unicode-code-point chars/raw UTF8 bytes; 1-based LF lines inclusive',
    authorization='ROOT post-rawfreeze message authorized proof-free StatementFormation and concrete-instance print probes using same imports, plus exact standard meanings and aliases. No imported ASTIS bodies or prior audits read.'))

ports=[
dict(id='port.parameters',type='OPEN_INTERNAL_PROOF_OBLIGATION',statement='Derive d>=2, d>0, r=q+1>=1, nonempty r^2 carrier, finite/nonnegative L from hq and literal definitions; no new public binder.',source=['S4.Thmtheorem4.p1.m2','S4.Thmtheorem4.p1.m3','A3.SS2.p10.1'],availability='not searched or claimed'),
dict(id='port.original.row.law',type='OPEN_INTERNAL_LIBRARY_APPLICABILITY',statement='Under the exact product mu of q+1 standard d-dimensional Gaussians, the selected row has the standard r-dimensional Gaussian law and required second moments.',source=['A3.SS2.p1.2','A3.SS2.p12.m3'],availability='No public provider/implementation theorem was inspected; source assertion only.'),
dict(id='port.feature.bound',type='OPEN_INTERNAL_PROOF_OBLIGATION',statement='For the literal t, establish its Euclidean squared norm <=2r, including q=0.',source=['A3.Ex102','A3.SS2.p13.m2'],availability='not searched'),
dict(id='port.rankone.tensor.norm',type='OPEN_INTERNAL_LIBRARY_APPLICABILITY',statement='Apply rank-one and tensor norm identities to the exact real L2Operator carrier and literal vecMulVec/kronecker formulas.',source=['A3.Ex111'],availability='Concrete norm meaning resolved by print probe; target norm-identity API/proof not searched or constructed.'),
dict(id='port.Y.pointwise',type='OPEN_INTERNAL_PROOF_OBLIGATION',statement='Obtain <=2rL/d for literal Y on all outcomes by the closed-cutoff cases; no high-probability event premise.',source=['A3.Ex107','A3.Ex111'],availability='unproved here'),
dict(id='port.Y.regularity',type='OPEN_INTERNAL_LIBRARY_APPLICABILITY',statement='Discharge actual Bochner integrability for literal Y under original mu, with source-domain measurability/strong measurability and finite-moment/dominating facts supplied internally.',source=['A3.Ex107','A3.Ex108','A3.SS2.p12.m5'],availability='unproved here; completeness of concrete matrix carrier type-resolves. Codomain MeasurableSpace/BorelSpace is not an integral-type requirement.',
     sufficient_routes_OR=[['finite product probability','literal row/cutoff/outer-product strong measurability','uniform truncated bound'],['literal strong measurability','Gaussian second-moment domination by fixed deterministic feature tensor']],routes_status='Candidate internal alternatives, not asserted source routes or proven applicability; do not require both routes.'),
dict(id='port.actual.mean',type='OPEN_INTERNAL_LIBRARY_APPLICABILITY',statement='Obtain <=2r/d for the actual Bochner integral, without replacing it by an arbitrary population matrix and without using the nonintegrable default branch.',source=['A3.Ex108','A3.SS2.p12.m4','A3.SS2.p12.m5','A3.Ex111'],availability='unproved here',
     sufficient_routes_OR=[dict(route='source-author-radial',needs=['row law','actual regularity','radial mean aI','0<=a<=1','fixed-tensor integral transport','real operator norm identity']),dict(route='possible-internal-PSD-alternative',needs=['actual regularity','pointwise PSD cutoff order','expectation order','untruncated covariance','PSD norm/order applicability'])],
     routes_status='Only the first route is in the source proof. Second is an unverified alternative applicability port, not an added source prerequisite. Never flatten both to AND.'),
dict(id='port.centered.radius',type='OPEN_INTERNAL_PROOF_OBLIGATION',statement='Actually consume both producer outputs at literal Z=Y-integralY and obtain exactly2r(L+1)/d; no public mean/norm/triangle certificate.',source=['A3.SS2.p13.m1','A3.Ex112'],availability='unproved; private consumer signature only'),
dict(id='port.cosine.radius',type='OPEN_INTERNAL_PROOF_OBLIGATION',statement='Use literal w=cos((2q+1)theta_i), |w|<=1 and scalar norm homogeneity to consume unweighted radius.',source=['A3.SS2.p13.3'],availability='unproved here')]
dump('internal-port-obligations-v1.json',dict(ports=ports,
    source_gaps_meaning='SOURCE_GAP nodes record author-omitted derivations at exact source use sites. These are distinct from unknown Lean/library applicability. No false/ill-posed source or missing source hypothesis was established.',
    failure_class='NONE for the mathematical route; no proof attempt was made. Extra type diagnostic failure is recorded separately, not API_BLOCKED proof evidence.',
    forbidden_premise_promotion=['norm bound','mean identity/bound','row law certificate','PSD certificate','integrability certificate','concentration theorem/event'],
    target_proof_or_API_search_attempts=0))

audit=dict(
actor='radius_sg_2c71',role='independent source-first binder/definition audit and source topology extraction; cannot approve own topology',
source_sha256='6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915',
seal_sha256='49d5fa00c9ae90d65878d955fab59d6a4bc03e942501677719881f3d26bf1a72',
signature_hashes={k:seal[k]['signature_sha256'] for k in ['producer','actual_private_consumer']},
binder_audit=[dict(binder='d q : Nat',classification='TYPING',expanded='Finite dimension and nonnegative integer degree; no bundled proposition or project-owned Prop alias.'),
              dict(binder='hq :2*q+1<d',classification='SOURCE',expanded='Exact Lemma4.4 admissible dimension-frequency condition. q=0 is explicit in source and retained.')],
public_excess=[],standing_premise_encoded_in_literal_experiment='The independent standard Gaussian g columns are instantiated by the fixed product mu, not taken as a free certificate binder.',
definition_kind='literal',
definition_audit=[
dict(definition='D,E,Omega',finding='Finite real Euclidean carriers D=R^d,E=R^(q+1); Omega is q+1 d-dimensional g vectors. EuclideanSpace abbreviates PiLp2; no quotient or representative choice.'),
dict(definition='mu',finding='Measure.pi of stdGaussian D is the original independent-column Gaussian experiment. stdGaussian is the standard finite-dimensional real Gaussian construction, not an arbitrary law. No row-law theorem assumed in public signature.'),
dict(definition='r,L,theta,t',finding='r=q+1; L=2r+3log(1000d); Fin zero-based theta=(i.val+1-1/2)pi/d matches source one-based half grid; t_0=1 and t_k=sqrt2 cos(k theta) for k=1..q. No changed grid, phase, normalization or spectrum.'),
dict(definition='row,Y',finding='WithLp packaging preserves the original coordinates; outer product entries are coordinate products, kronecker has paired row/column indices in the source order gamma tensor t. Y is d^-1 times the tensor on the literal closed cutoff norm(row)^2<=L and zero otherwise. This zero is the source indicator, not invented fallback semantics.'),
dict(definition='matrix norm',finding='Actual same imports/scopes selected NormedRing.toNorm(Matrix.instL2OpNormedRing) on Matrix (Fin(q+1)xFin(q+1)) ... Real, and instL2OpNormedAddCommGroup/NormedSpace. Standard construction induces the norm through continuous linear maps on finite Euclidean space. Thus the printed concrete norm is the source real Euclidean operator norm, rather than an inferred choice from a preceding audit.',evidence=['ConcreteMeaningProbeV2.lean','ConcreteMeaningProbeV2.log','originals/standard-meaning/Mathlib__Analysis__CStarAlgebra__Matrix.lean.L137-150.raw','originals/standard-meaning/Mathlib__Analysis__CStarAlgebra__Matrix.lean.L155-186.raw']),
dict(definition='mean',finding='The expression is the actual integral of literal Y under the same mu. Mathlib integral is totalized: complete-and-integrable branch uses L1 integral, otherwise zero. Concrete completeness resolves; actual Y integrability must still be discharged internally to justify the source expectation meaning. The source does not license an Integrable public binder.'),
dict(definition='Z,w,Rstar',finding='Z=Y-actual mean, w=cos((2q+1)theta_i), and Rstar=2r(L+1)/d exactly match p13. All-outcome quantification is source-faithful; no truncation-event condition is needed for these bounded summands.')],
q0=dict(retained=True,source_anchor='S4.Thmtheorem4.p1.m2',interpretation='q=0 gives r=1,n=1,only t_0=1, and hq is1<d; no public q>0 or q>=1 premise. The Fin1xFin1 matrix norm instance also resolves in the print probe.'),
dimension=dict(condition='2q+1<d',finding='Source-compatible. d>=2,d>0,r>=1 and nonempty matrix index are internal consequences, not extra binders. hq can be stronger than a particular pointwise proof needs without being an excess source hypothesis.'),
scope=dict(included='p13 four norm/radius claims with actual Y and actual mean, plus necessary literal/source prerequisites.',excluded=['p14 variance/fourth moments/PSD second moment sum (separate packet)','p15 matrix Bernstein/tail inequality','p16-p18 budgets, truncation recovery and tau simplification','p19/full Lemma4.4 and downstream oracle/lower-bound conclusions'],
           no_tau_binder='tau<=1/2 is for final Lemma4.4 conversion, not the radius packet.',exhaustive_coverage='raw-source-coverage-freeze-v1.json',consumer_use_edges='source-proof-graph-freeze-v1.json'),
verdict=dict(binders='NO_EXCESS_DETECTED',definitions='LITERAL_FORMULA_AND_CONCRETE_NORM_MEANING_ALIGNED; actual expectation integrability remains internal proof obligation',source_scope='BOUNDED_SOURCE_SCOPE_SUPPORTED; proposed topology awaits distinct challenge',source_contract_gap='NONE_ESTABLISHED',source_omitted_derivations='Five explicitly typed SOURCE_GAP nodes, not proof failures or added hypotheses.'),
authority_limits=['No target theorem is proved or source/Lean equivalence certified.','No imported ASTIS implementation bodies, previous source graphs/audits, target API/proof search or compiled theorem results used.','Print probe compiles type/definition queries only; type success does not discharge norm estimates or integrability.','The extractor does not accept its own source topology.'],
probe_failures=dict(v1_exit_code=1,reason='Unnecessary explicit Matrix MeasurableSpace and BorelSpace requests failed; other concrete norm/completion and meaning queries returned. Integral codomain requires normed additive group and normed real space, not a measurable-space instance.',v1_files=['ConcreteMeaningProbe.lean','ConcreteMeaningProbe.log'],classification='diagnostic IMPLEMENTATION_FAILED, not a failure of the sealed source statement or a target proof',repair='V2 omits only these two irrelevant requests, retains all intended norm/completeness/definition queries; exit0.'),
proof_search_exposure='Not API-pristine after authorized standard-meaning reads: bounded regex/line windows incidentally exposed neighboring standard theorem names/proof lines. These were not used to infer the frozen topology, select a target proof route or claim target API availability. Source graph froze first.',
environment=dict(head='339d6176f61fce828f4766a8951857cfef746a62',lean='Lean4.33.0 arm64-apple-darwin24.6.0 commit d8b18978322de05a8f3dba51ef03cf5461676c17',
                 lean_toolchain_sha256=sha((W/'lean-toolchain').read_bytes()),lake_manifest_sha256=sha((W/'lake-manifest.json').read_bytes())),
mutations=dict(owned_root_only=str(R.relative_to(W)),target_Lean_implementation=0,website_frontier_ledger_Git_index=0,ASTIS_loops=0,spawns=0,new_Goals=0))
dump('binder-definition-audit-v1.json',audit)

dump('probe-v1-receipt.json',dict(argv=['lake','env','lean',str(R.relative_to(W)/'ConcreteMeaningProbe.lean')],exit_code=1,
    file_sha256=sha((R/'ConcreteMeaningProbe.lean').read_bytes()),log_sha256=sha((R/'ConcreteMeaningProbe.log').read_bytes()),
    output_complete=True,scope='Print/type/definition commands only, no target proof. Missing matrix measurable-space diagnostics not required by integral.'))

print(json.dumps(dict(binder_audit='NO_EXCESS_DETECTED',definition_audit='literal formulas and concrete operator-norm meaning aligned; actual integrability internal/open',
    topology='proposed, distinct review pending',post_freeze_originals=len(post),meaning_windows=len(ml),ports=len(ports),audit_sha256=sha((R/'binder-definition-audit-v1.json').read_bytes())),indent=2))
