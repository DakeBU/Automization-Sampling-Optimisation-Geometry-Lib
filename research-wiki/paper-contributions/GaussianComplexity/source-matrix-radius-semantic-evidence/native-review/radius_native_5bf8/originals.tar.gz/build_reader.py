from runner import *
import shutil
COMMIT=sys.argv[1]
C=OUT/('reader/candidate-'+COMMIT[:7]);SITE=OUT/('reader-site-'+COMMIT[:7])
sys.path[:0]=[str(C/'tools'),str(C/'website/scripts')]
import astis_site as base,declaration_lessons as lessons,publication_reader,astis_publication as pub,source_lineage
base._ACTIVE_GATE=base.GateEvidence(False,False,COMMIT,'','',[],'Bounded fixture; aggregate gate intentionally unverified')
base._ACTIVE_GIT=base.GitContext(COMMIT,'fixed-4b585-native-reader','','',False,False,set())
modules,decls=base.scan_project_sources();base._SOURCE_BY_NAME={d.full_name:d for d in decls};base._ALL_MODULES=modules
unit=json.loads((C/'website/content/declaration_lessons/huanjian-gaussian-source-matrix-radius.json').read_text())['units'][0]
item=json.loads((C/'website/content/publications/huanjian-gaussian-source-matrix-radius.json').read_text())['items'][0]
pub.inputs=lambda:{'declarations':base._SOURCE_BY_NAME,'lessons':{unit['declaration']:unit},'audits':{},'cells':{}}
SITE.mkdir(exist_ok=False);(SITE/'textbook').mkdir()
theme='<html><head>'+''.join(f'<link rel="stylesheet" href="../assets/{x}">' for x in ['site.css','information-architecture.css','proof-readers.css'])+'</head><body>Bounded canonical theme seed; unverified.</body></html>'
(SITE/'textbook/index.html').write_text(theme)
for p in (C/'website/static').rglob('*'):
    if p.is_file():
        q=SITE/'assets'/p.relative_to(C/'website/static');q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q)
pages=[]
lesson=lessons.lesson_path(unit['declaration']);proof=publication_reader.source_proof_path(item)
for rel,body in [(lesson,lessons.render_unit(unit,lesson)),(proof,publication_reader.source_card(item,proof))]:
    h=base.page(unit['title'],rel,body,extra_head='<link rel="stylesheet" href="../assets/proof-readers.css">')
    h=source_lineage.canonical_shell(h,rel,SITE);base.write_page(SITE,rel,h);pages.append(rel)
lessons.export_sources(SITE,[unit])
for m in modules:
    rel=f'modules/{base.slugify(m.name)}.html';h=base.render_source_module(m,[x.name for x in modules if m.name in x.imports])
    base.write_page(SITE,rel,source_lineage.canonical_shell(h,rel,SITE))
    q=SITE/'downloads/lean'/m.source_file;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes((C/m.source_file).read_bytes())
checks=[]
for rel in pages:
    h=(SITE/rel).read_text();assert h.count('class="proof-reader-step reader-proof-disclosure"')==6
    assert 'unverified' in h
    for lo,hi,key in [(0,4,'AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumSourceMatrixRadius.lean'),(4,6,'Tests/GaussianComplexityFixedSpectrumSourceMatrixRadius.lean')]:
        assert ''.join(x['lean'] for x in unit['steps'][lo:hi]).encode()==(C/key).read_bytes()
    checks.append({'path':rel,'sha256':sha(SITE/rel),'steps':6,'exact_P_folds_lines':226,'exact_T_folds_lines':95})
result={'candidate':COMMIT,'site':str(SITE),'source_snapshot':str(C),'page_contexts':pages,'checks':checks,'production_css_sha256':sha(SITE/'assets/proof-readers.css'),'global_navigation_and_late_overlays':'outside bounded fixture','empty_audits_cells':True,'source_export':'declaration_lessons.export_sources','module_renderer':'astis_site.render_source_module','download_export':'verbatim production per-module write_bytes','remote_citations':'not fetched'}
(OUT/'reader/build-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
