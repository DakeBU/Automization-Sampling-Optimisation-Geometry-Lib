from pathlib import Path
import datetime, gzip, hashlib, json

R = Path('.astis/huanjian-gc-fixed-spectrum-first-order-integration-20261108')
I = R/'independent-reader'
sha = lambda b: hashlib.sha256(b).hexdigest()
ref = lambda p: {'path': str(p), 'sha256': sha(p.read_bytes())}
freeze_path = I/'original38-independent-review-v4/freeze.json'
assert sha(freeze_path.read_bytes()) == '1c074fd5dc701233edc6200c0c14f655dc8485ec17e28d0315ea6fd5049915c4'
freeze = json.loads(freeze_path.read_bytes())
for key in ['review', 'journal', 'input_provenance']:
    r = freeze[key]
    assert sha(Path(r['path']).read_bytes()) == r['sha256']
for row in freeze['raw_archives']:
    raw = Path(row['original']['path']).read_bytes()
    archive = Path(row['archive']['path']).read_bytes()
    assert sha(raw) == row['original']['sha256'] and len(raw) == row['raw_bytes']
    assert sha(archive) == row['archive']['sha256'] and gzip.decompress(archive) == raw
pixel = json.loads(Path(freeze['review']['path']).read_bytes())
assert pixel['status'] == 'accepted' and pixel['blocking_objections'] == []
rp = I/'browser/live-20261108T160740169669Z/report.json'
report = json.loads(rp.read_bytes())
assert pixel['browser_report_sha256'] == sha(rp.read_bytes())
assert len(pixel['reviewed_images']) == len(report['screenshots']) == 38
actual = {r['file']: r['sha256'] for r in report['screenshots']}
reviewed = {r['file']: r['sha256'] for r in pixel['reviewed_images']}
assert actual == reviewed and len(reviewed) == 38
assert all(r['viewed_original'] is True and r['status'] == 'accepted' for r in pixel['reviewed_images'])
out = R/'root-local-acceptance-v4-authorization.json'
assert not out.exists()
d = {
    'recorded_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'authorized_by': '/root', 'reviewer': '/root/norm_integration_reader',
    'authorization': 'SEPARATE_INDEPENDENT_LOCAL_ACCEPTANCE_AND_NORMALPARK_ELIGIBILITY_REVIEW_ONLY',
    'accepted_immutable_core': '9b1e90d25711668203c6e252cfe5a748f95c8ad4',
    'candidate_source_checked_commit': '9d306d837fbddf1518b0035494baaf5c21c24488',
    'context': ref(R/'root-final-browser-context-v4.json'),
    'bound_context_review': ref(I/'late-context-independent-review-v4/late-context-decision.json'),
    'actual_browser_report': ref(rp),
    'actual_browser_receipt': ref(Path('.astis/huanjian-resume-20261103/20261108T160725345032Z-fixed-spectrum-first-order-final-browser-v4.receipt.json')),
    'pixel_review': ref(Path(freeze['review']['path'])), 'pixel_freeze': ref(freeze_path),
    'root_actual8_review': ref(R/'root-actual-v4-original8-review.json'),
    'root_guarded_park_preparation_review': ref(R/'root-normalpark-v2-preparation-review.json'),
    'required_decisions': ['Independent local integration acceptance, only if the actual current evidence supports it',
                           'Separate mechanical existing-V parking eligibility, preserving all sourceV306 fields and original actor; execution still requires later exact root authorization'],
    'required_limits': ['Exactly one reviewed JS camera exception; all other protected bytes preserved',
                        'Actual38 pixels distinct from extra4 native DOM-only routes and2 old DensityAffinity DOM-only regressions',
                        'Source-checked9d versus sourceV first-carryingf45 versus actual accepted integration/UIcore9b remain distinct',
                        'No remote publication, postmerge purification, Exposition Seal, parent historical-audit upgrade, main-bound or wholeGoal completion'],
    'normalpark_execution_authorized': False, 'lifecycle_API_authorized': False,
    'new_source_verdict_authorized': False, 'browser_rerun_authorized': False,
    'canonical_or_shared_edits_authorized': False,
}
out.write_text(json.dumps(d, ensure_ascii=False, indent=2)+'\n')
print(json.dumps(ref(out)))
