from pathlib import Path
import hashlib,json,shutil,subprocess
B=Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-geometry-semantic-evidence')
N=Path('.astis/semantic-neutral-20261109/91f0b8e4')
F=Path('.astis/semantic-neutral-20261109/src_9a6d2f/phase1')
sha=lambda b:hashlib.sha256(b).hexdigest()
dump=lambda x:(json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode()
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()=='ab8b47caed9f781191f8408154cd355c7e7c104c'
assert not subprocess.check_output(['git','diff','HEAD','--name-only']).strip()
mf=F/'phase1_manifest.json'
assert sha(mf.read_bytes())=='aa9b3ffb40981e0d6d80d9c1ac8458a610c41bb7137e185a89baf6d9c25f81f1'
m=json.loads(mf.read_bytes()); assert not m['candidate_inputs_seen']
for row in m['files']:
    raw=(F/row['path']).read_bytes()
    assert len(raw)==row['bytes'] and sha(raw)==row['sha256']
dest=B/'fresh-source-reader-9a6d2f/phase1'
assert not dest.exists(); shutil.copytree(F,dest)
for q in F.rglob('*'):
    if q.is_file():assert (dest/q.relative_to(F)).read_bytes()==q.read_bytes()
packet=json.loads((N/'input.json').read_bytes())
recon=json.loads((N/'reconstruction.json').read_bytes())
run=json.loads((N/'decoder-run.json').read_bytes())
assert sha((N/'reconstruction.json').read_bytes())=='43f3896385037870a5a6d3acfde94bef5c658280b53b40d3949ab8581f6ba47f'
assert sha((N/'decoder-run.json').read_bytes())=='9a6c09e4716538d7c907e3721d0e654cf40c2e9a8ad4c8c926d783cbe6843c7d'
selective={'schema_version':1,'stage':'SELECTIVE_ANONYMOUS_SOURCE_COMPARISON_BEFORE_FULL_MODULE_CONTEXT',
    'input_scope':'Anonymous public proposition and minimal approved standard definitions; actual independent blind reconstruction and its honest exposure/run provenance. No target declaration/module/proof/lesson/publication metadata or earlier semantic verdict/repair. Private consumer whole-module review is later, not blind-decoded here.',
    'anonymous_decoder_packet':packet,'blind_reconstruction':recon,'blind_decoder_run':run,
    'provenance':{'anonymous_input_raw_sha256':sha((N/'input.json').read_bytes()),
        'anonymous_packet_canonical_sha256':packet['packet_sha256'],
        'reconstruction_raw_sha256':sha((N/'reconstruction.json').read_bytes()),
        'decoder_run_raw_sha256':sha((N/'decoder-run.json').read_bytes()),
        'own_source_phase1_manifest_raw_sha256':sha(mf.read_bytes()),
        'actual_source_phase1_payloads_verified':len(m['files'])}}
out=F.parent/'phase2-selective-input.json'
assert not out.exists(); out.write_bytes(dump(selective))
(B/'phase2-selective-input.json').write_bytes(out.read_bytes())
record={'source_reviewer':'/root/source_reader_9a6d2f','source_phase1_manifest_sha256':sha(mf.read_bytes()),
    'actual_source_phase1_payloads_verified':len(m['files']),'all_public_copy_bytes_equal':True,
    'source_blind_decoder':'/root/decode_80a1c2','selective_input':str(out),'selective_input_raw_sha256':sha(out.read_bytes()),
    'no_root_source_verdict':True,'sourceV':False}
(B/'selective-review-input-adoption.json').write_bytes(dump(record))
print(json.dumps(record))
