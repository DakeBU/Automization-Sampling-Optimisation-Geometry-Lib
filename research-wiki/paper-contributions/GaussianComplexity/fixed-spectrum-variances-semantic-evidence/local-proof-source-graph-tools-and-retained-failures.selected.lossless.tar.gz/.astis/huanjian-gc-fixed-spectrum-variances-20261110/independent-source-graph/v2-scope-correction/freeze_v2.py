from pathlib import Path
from copy import deepcopy
import hashlib,json
root=Path('/Users/zhouhuanjian/ASTIS-GC')
base=root/'.astis/huanjian-gc-fixed-spectrum-variances-20261110/independent-source-graph'
out=base/'v2-scope-correction'
sha_bytes=lambda b:hashlib.sha256(b).hexdigest()
sha=lambda p:sha_bytes(p.read_bytes())
load=lambda p:json.loads(p.read_text())
blob=lambda o:(json.dumps(o,indent=2,ensure_ascii=False)+'\n').encode()
semantic_sha=lambda o:sha_bytes(json.dumps(o,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode())
v1_projection=root/'.astis/huanjian-gc-fixed-spectrum-variances-20261110/strict-preproof-seal-projection-v1.json'
v2_projection=root/'.astis/huanjian-gc-fixed-spectrum-variances-20261110/strict-preproof-seal-projection-v2.json'
assert sha(v1_projection)=='f1a37d117d750748d0d0ff6b229778d4b9c0e34a556f875679d8f05e0f387509'
assert sha(v2_projection)=='76136b7367d19fd1b98583adc5f4fae17330a817ad2c1a330300e399b0925b85'
v1=load(v1_projection);v2=load(v2_projection)
assert v2['original_seal_sha256']=='77e6ee5f01804f871bcd798cb7a1e87093d08be3193ea280dc9b0783e5fddec9'
assert v2['predecessor_projection']['sha256']==sha(v1_projection)
assert v1['source']==v2['source'] and v1['producer']==v2['producer']
assert v1['definition_audit']==v2['definition_audit']
assert v1['standard_actual_gaussian_definition']==v2['standard_actual_gaussian_definition']
assert v1['standard_real_variance_definition']==v2['standard_real_variance_definition']
for role in ['producer','actual_private_consumer']:
 assert v1[role]['signature']==v2[role]['signature']
 assert v1[role]['signature_sha256']==v2[role]['signature_sha256']==sha_bytes(v2[role]['signature'].encode())
for k,val in v1['actual_private_consumer'].items():assert v2['actual_private_consumer'][k]==val
assert v2['binder_audit']==[r for r in v1['binder_audit'] if r['owner']=='producer']
assert len(v2['binder_audit'])==7 and all(r['owner']=='producer' for r in v2['binder_audit'])
a=v2['private_internal_provider_audit']
assert v2['actual_private_consumer']['is_source_anchor'] is False
assert a['exact_signature_unchanged'] is True
assert a['tau_carrier']['source_anchor_classification'] is None
assert len(a['private_assumed_domain_hypotheses'])==2
for h in a['private_assumed_domain_hypotheses']:
 assert h['source_anchor_classification'] is None
 assert h['assumed_in_private'] is True
 assert h['proved_fact'] is False
 assert h['inherited_by_public_anchor'] is False
f1=load(base/'phase1-freeze.json'); f_old=load(base/'phase2-freeze.json')
assert sha(base/'phase1-freeze.json')=='0c7f3a128170bd0565ee4797c330aa11280e6c7af739922e7e2bc6d54cb0853f'
assert sha(base/'phase2-freeze.json')=='03029329f52c78d8b42a5a8480384c405013c1cef8be2c0b99b5fb39784f23a6'
for freeze in [f1,f_old]:
 for entry in freeze['artifacts']:assert sha(root/entry['path'])==entry['sha256'],entry['path']
old_graph=load(base/'phase2-source-proof-graph.json')
old_coverage=load(base/'phase2-exact-target-coverage.json')
old_closure=load(base/'phase2-root-closures.json')
old_audit=load(base/'phase2-statement-projection-audit.json')
raw=load(base/'raw-unit-inventory.json'); raw_by_id={r['id']:r for r in raw['units']}
anchors=['S4.Thmtheorem4.p1.2','S4.SS3.p3.1','S4.SS3.SSS0.Px1.p1.2','S4.SS3.SSS0.Px2.p2.3','S4.SS3.SSS0.Px2.p3.1','S4.Ex25','A3.SS3.p8.1','A3.Ex148','A3.Ex149']
source_recheck=[{'id':i,'original_lines':raw_by_id[i]['original_lines'],'text_with_tex':raw_by_id[i]['text_with_tex'],'raw_html_sha256':raw_by_id[i]['raw_html_sha256']} for i in anchors]
projection_lineage={'predecessor_projection':{'path':str(v1_projection.relative_to(root)),'sha256':sha(v1_projection),'bound_full_seal_sha256_unread':v1['original_seal_sha256']},'current_projection':{'path':str(v2_projection.relative_to(root)),'sha256':sha(v2_projection),'bound_full_seal_sha256_unread':v2['original_seal_sha256']},'exact_signatures_unchanged':True,'literal_definitions_unchanged':True,'source_scope_unchanged':True,'permitted_delta':'Only scope/taxonomy metadata is corrected: remove private consumer from the source-Anchor binder audit, mark it non-Anchor Internal Provider, and expose its scalar guards as private assumed domain hypotheses. No source math or theorem string changes.'}
classification={
 'finding_id':'private-tau-scope-v2',
 'current_result':'RESOLVED_CLASSIFICATION_HOLD_ONLY',
 'prior_hold_retained':{'artifact_path':str((base/'phase2-statement-projection-audit.json').relative_to(root)),'sha256':sha(base/'phase2-statement-projection-audit.json'),'verbatim_verdict':old_audit['actual_private_consumer']['proposed_STANDING_label_verdict'],'verbatim_status':old_audit['actual_private_consumer']['status'],'historical_artifact_unchanged':True},
 'independent_assessment':'The precise v2 correction satisfies the earlier classification objection. The paper source fixes n=2q+1 and concrete τ_dq, with the τ≤1/2 bound established for sufficiently large d. The private numerical variance algebra can instead quantify over arbitrary 0≤τ≤1/2 and every source mode because the signed coefficient has absolute value 1. Those scalar guards are explicit assumptions of that private local theorem, not source-wide standing premises or derived facts. No new source Anchor is thereby admitted.',
 'source_grounding':source_recheck,
 'private_tau_audit':deepcopy(a),
 'public_binder_boundary':{'number_of_binders':7,'audit':deepcopy(v2['binder_audit']),'private_scalar_guards_present':False,'hypothetical_public_insertion':'EXCESS: the arbitrary scalar guard hypotheses are not SOURCE/STANDING/TYPING/RULED premises of the public paper Anchor. They must never be inherited by it.'},
 'no_sixth_anchor_bin':True,
 'still_open':['All actual-law validity, independence, fourth moments, L², finite evariance and centered-L² obligations remain internal unproved SOURCE_GAP nodes.','Actual use of both new quadratic L² outputs and both actual 2M variance outputs has not been inspected or certified.','Distinct source-coverage, root-closure, statement and eventual proof reviews remain required.','Concrete original source application still must derive n=2q+1, τ=τ_dq, original parameter/large-d conditions and rotated-target transport internally.','Full Ex25 mean separation, Ex26 probability and full query lower bound remain outside these exact targets.'],
 'not_resolved':'No theorem proof, API readiness, independent coverage acceptance, sourceV, VERIFIED or publication completion is claimed.'}
audit={'schema':2,'status':'CLASSIFICATION_CORRECTION_ACCEPTED_SOURCE_GRAPH_REVIEW_STILL_PENDING','projection_lineage':projection_lineage,'classification_resolution':classification,'producer':deepcopy(old_audit['producer']),'actual_private_consumer':{'name':v2['actual_private_consumer']['name'],'exact_signature':v2['actual_private_consumer']['signature'],'signature_sha256':v2['actual_private_consumer']['signature_sha256'],'role':v2['actual_private_consumer']['role'],'is_source_anchor':False,'private_guard_assumptions':deepcopy(a['private_assumed_domain_hypotheses']),'mathematical_scope_assessment':old_audit['actual_private_consumer']['mathematical_scope_assessment'],'implementation_use_status':'Not inspected and not certified. The exact material-use requirement remains unchanged.','status':'NON_ANCHOR_PRIVATE_LOCAL_GENERALIZATION_SCOPE_CORRECTION_ACCEPTED_PENDING_DISTINCT_REVIEW_AND_PROOF'},'definition_audit':deepcopy(old_audit['definition_audit']),'full_seal_files_read':False,'admission_boundary':'Resolve only the classification HOLD against the exact corrected whitelist. No signature or semantic proof-graph revision and no theorem/proof acceptance.'}
artifacts={}
audit_name='statement-projection-audit-v2.json';artifacts[audit_name]=blob(audit)
audit_sha=sha_bytes(artifacts[audit_name])
def binding(oldname,semantic):
 return {'artifact_predecessor':{'path':str((base/oldname).relative_to(root)),'sha256':sha(base/oldname)},'projection_lineage':deepcopy(projection_lineage),'current_projection_audit':{'path':str((out/audit_name).relative_to(root)),'sha256':audit_sha},'unchanged_semantic_components':semantic,'classification_only_overlay':{'node_id':'C_numeric_domain','result':'Private scalar hypotheses explicitly ASSUMED in a non-Anchor Internal Provider; source_anchor_classification=null, proved_fact=false, inherited_by_public_anchor=false. The v1 proposed-STANDING HOLD is resolved only on this corrected scope.','semantic_node_and_routes_unchanged':True},'historical_corrections_retained':['Named TBODY A3.Ex148/A3.Ex149 successor NODE corrections and original frozen phase1 exclusions.','Raw ordinal identity for two same-line synthetic link-ID collisions; no unit dropped.','Both actual quadratic L² and both 2M bounds are needed by consumer; closed-M upper output is not in its minimal source closure.']}
graph=deepcopy(old_graph)
graph['schema']=2
graph['exact_projection_sha256']=sha(v2_projection)
graph['original_seal_sha256']=v2['original_seal_sha256']
graph['binding_successor']=binding('phase2-source-proof-graph.json',[{'component':k,'old_canonical_sha256':semantic_sha(old_graph[k]),'current_canonical_sha256':semantic_sha(graph[k]),'identical':graph[k]==old_graph[k]} for k in ['nodes','routes','alternative_routes']])
graph_name='source-proof-graph-v2.json';artifacts[graph_name]=blob(graph);graph_sha=sha_bytes(artifacts[graph_name])
coverage=deepcopy(old_coverage)
coverage['schema']=2
coverage['current_projection_sha256']=sha(v2_projection)
coverage['current_graph_sha256']=graph_sha
coverage['binding_successor']=binding('phase2-exact-target-coverage.json',[{'component':k,'old_canonical_sha256':semantic_sha(old_coverage[k]),'current_canonical_sha256':semantic_sha(coverage[k]),'identical':coverage[k]==old_coverage[k]} for k in ['rows','raw_unit_identity','historical_NODE_to_exact_EXCLUDED']])
coverage_name='exact-target-coverage-v2.json';artifacts[coverage_name]=blob(coverage);coverage_sha=sha_bytes(artifacts[coverage_name])
closures=deepcopy(old_closure)
closures['schema']=2
closures['current_projection_sha256']=sha(v2_projection)
closures['current_graph_sha256']=graph_sha
closures['current_coverage_sha256']=coverage_sha
closures['binding_successor']=binding('phase2-root-closures.json',[{'component':k,'old_canonical_sha256':semantic_sha(old_closure[k]),'current_canonical_sha256':semantic_sha(closures[k]),'identical':closures[k]==old_closure[k]} for k in ['closures','consumer_projection_required','consumer_not_required','concrete_source_application_obligations_not_closed_here']])
closure_name='root-closures-v2.json';artifacts[closure_name]=blob(closures)
# Verify every reused component is unchanged and source-graph semantics remain the previous raw-first graph.
assert graph['nodes']==old_graph['nodes'] and graph['routes']==old_graph['routes']
assert coverage['rows']==old_coverage['rows'] and len(coverage['rows'])==294
assert closures['closures']==old_closure['closures']
assert 'O_closed_mean_upper' not in closures['closures']['actual_private_consumer']['nodes']
assert all(i in closures['closures']['actual_private_consumer']['nodes'] for i in ['N_norm_L2','N_Q_L2','N_norm_variance_le_2M','N_Q_variance_le_2M'])
for r in coverage['rows']:
 j=r['raw_unit_ordinal'];assert r['raw_source_unit']==raw['units'][j]
inputs={'schema':2,'status':'EXACT_CORRECTED_PROJECTION_ONLY','current_projection':projection_lineage['current_projection'],'predecessor_projection':projection_lineage['predecessor_projection'],'prior_frozen_artifacts':[{'path':str((base/f).relative_to(root)),'sha256':sha(base/f)} for f in ['phase1-freeze.json','phase2-freeze.json','phase1-raw-cognition.md','raw-unit-inventory.json','phase2-source-proof-graph.json','phase2-exact-target-coverage.json','phase2-root-closures.json','phase2-statement-projection-audit.json']],'source_units_rechecked':[x['id'] for x in source_recheck],'input_identity_checks':['Exact producer and consumer signature strings/hashes match v1.','Source scope and all supplied literal definition fields match v1.','Public Anchor audit has exactly the previous seven producer entries.','Private scalar guards separately assumed, not proved, null Anchor classification and not inherited.','All phase1 and v1 frozen artifact hashes rechecked unchanged.'],'additional_authorized_input':'Parent v2 assignment and exact hash/scope restrictions only.','not_read':['Full seal v1 or v2','Root rationale/private scripts/API inventory','Other actor mathematics or judgments','Implementation, Lean, lessons, sourceV or normal ledgers'],'not_run':['Proof search, Lean or builds','ASTIS API/harness','Network','Shared/global mutation'],'write_boundary':str(out.relative_to(root)),'script_sha256':sha(out/'freeze_v2.py')}
artifacts['machine-inputs-v2.json']=blob(inputs)
lineage={'schema':2,'result':'RESOLVED_CLASSIFICATION_HOLD_ONLY','projection_lineage':projection_lineage,'predecessor_freeze':{'path':str((base/'phase2-freeze.json').relative_to(root)),'sha256':sha(base/'phase2-freeze.json')},'current_successors':[{'path':str((out/f).relative_to(root)),'sha256':sha_bytes(b),'bytes':len(b)} for f,b in artifacts.items()],'semantic_invariance':{'graph_nodes':graph['nodes']==old_graph['nodes'],'graph_routes':graph['routes']==old_graph['routes'],'coverage_rows':coverage['rows']==old_coverage['rows'],'root_closures':closures['closures']==old_closure['closures']},'retained_history':'Prior v1 HOLD, all phase1 bytes, named TBODY corrections and ordinal-disambiguated raw link collisions remain unchanged and linked.','no_new_proof_credit':True}
artifacts['binding-lineage-v2.json']=blob(lineage)
# Append-only output rule. Refuse to overwrite any successor artifact.
for name in artifacts:assert not (out/name).exists(),name
assert not (out/'freeze-v2.json').exists()
for freeze in [f1,f_old]:
 for entry in freeze['artifacts']:assert sha(root/entry['path'])==entry['sha256']
for name,data in artifacts.items():
 with (out/name).open('xb') as f:f.write(data)
freeze={'schema':2,'status':'V2_CLASSIFICATION_ONLY_SUCCESSOR_FROZEN_PENDING_DISTINCT_CHALLENGE','predecessor_freeze_sha256':sha(base/'phase2-freeze.json'),'phase1_freeze_sha256':sha(base/'phase1-freeze.json'),'current_projection_sha256':sha(v2_projection),'full_seal_v2_sha256_unread':v2['original_seal_sha256'],'result':'Prior classification HOLD is resolved for the precise private non-Anchor assumed-domain correction only. All proof/coverage/source-completion questions remain open.','artifacts':[{'path':str((out/f).relative_to(root)),'sha256':sha(out/f),'bytes':(out/f).stat().st_size} for f in ['freeze_v2.py']+list(artifacts)],'semantic_content_counts':{'nodes':len(graph['nodes']),'AND_routes':len(graph['routes']),'raw_units':len(coverage['rows']),'coverage_counts':coverage['successor_counts'],'producer_closure_nodes':len(closures['closures']['producer']['nodes']),'consumer_closure_nodes':len(closures['closures']['actual_private_consumer']['nodes'])},'no_semantic_change':True,'no_proof_or_self_review_credit':True}
with (out/'freeze-v2.json').open('xb') as f:f.write(blob(freeze))
print(json.dumps({'freeze_sha256':sha(out/'freeze-v2.json'),'result':freeze['result'],'artifacts':freeze['artifacts']},indent=2))
