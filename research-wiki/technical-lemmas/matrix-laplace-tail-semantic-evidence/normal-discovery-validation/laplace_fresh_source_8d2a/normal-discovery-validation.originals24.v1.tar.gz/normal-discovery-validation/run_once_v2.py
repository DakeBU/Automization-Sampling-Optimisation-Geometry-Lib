from pathlib import Path
from datetime import datetime,timezone
import contextlib,hashlib,json,os,stat,subprocess,sys,traceback
sys.dont_write_bytecode=True
ROOT=Path('/Users/zhouhuanjian/ASTIS-GC');OWN=Path(__file__).parent;PRIVATE=OWN/'local-private-guards';PRIVATE.mkdir(exist_ok=True);PRIVATE.chmod(0o700)
sys.path.insert(0,str(ROOT))
from tools import astis_advance as api
ACTOR='/root/laplace_fresh_source_8d2a';D='ASTIS-DISC-20261114-ScalarSelfadjointLaplaceTailMechanism';CREATOR='huanjian_20261114_matrix_laplace_tail';MARKER=OWN/'normal-discovery-validation.once.marker.json'
sha=lambda d:hashlib.sha256(d).hexdigest()
def emit(path,obj):path.write_text(json.dumps(obj,indent=2,ensure_ascii=True)+'\n')
def raw_valid(path):
 data=path.read_bytes() if path.exists() else b''
 if data and not data.endswith(b'\n'):raise RuntimeError('Incomplete ledger tail: no API recovery is authorized')
 for line in data.splitlines():
  if line.strip() and not isinstance(json.loads(line),dict):raise RuntimeError('Non-object ledger row')
 return data
GIT_ENV=dict(os.environ,GIT_OPTIONAL_LOCKS='0')
def git(*args):
 r=subprocess.run(['git',*args],cwd=ROOT,env=GIT_ENV,capture_output=True,check=False)
 if r.returncode not in [0,1]:raise RuntimeError('Read-only Git guard failed')
 return {'returncode':r.returncode,'stdout_hex':r.stdout.hex(),'stderr_hex':r.stderr.hex()}
def git_bytes(*args):
 r=subprocess.run(['git',*args],cwd=ROOT,env=GIT_ENV,capture_output=True,check=True);return r.stdout

def file_entry(path):
 try:s=path.lstat()
 except FileNotFoundError:return {'kind':'absent'}
 if stat.S_ISLNK(s.st_mode):data=os.fsencode(os.readlink(path));kind='symlink-target-bytes'
 elif stat.S_ISREG(s.st_mode):data=path.read_bytes();kind='regular-file'
 elif stat.S_ISDIR(s.st_mode):return {'kind':'directory-gitlink-or-submodule','mode':stat.S_IMODE(s.st_mode)}
 else:return {'kind':'other','mode':stat.S_IMODE(s.st_mode)}
 return {'kind':kind,'bytes':len(data),'sha256':sha(data),'mode':stat.S_IMODE(s.st_mode)}

def capture(label):
 print('guard_'+label+'_started',flush=True)
 disc=raw_valid(api.DEFAULT_DISCOVERY_LEDGER);adv=raw_valid(api.DEFAULT_ADVANCE_LEDGER)
 ds=api.current_discoveries();as_=api.current_advances();assert raw_valid(api.DEFAULT_DISCOVERY_LEDGER)==disc and raw_valid(api.DEFAULT_ADVANCE_LEDGER)==adv
 listed=git_bytes('ls-files','-z');paths=[os.fsdecode(x) for x in listed.split(b'\0') if x]
 tracked={x:file_entry(ROOT/x) for x in paths}
 ip=Path(os.fsdecode(git_bytes('rev-parse','--git-path','index')).strip());ip=ip if ip.is_absolute() else ROOT/ip;index=ip.read_bytes() if ip.exists() else b''
 frontier_paths=set((ROOT/'research-wiki/frontier-cells').rglob('*'))
 frontier_paths|={f for f in (ROOT/'website/content').rglob('*') if 'frontier' in f.name.lower()}
 frontiers={str(f.relative_to(ROOT)):file_entry(f) for f in sorted(frontier_paths) if f.is_file() or f.is_symlink()}
 ledger_files={str(f.relative_to(ROOT)):file_entry(f) for f in sorted((ROOT/'runs').glob('*.jsonl'))}
 full={'captured_at_utc':datetime.now(timezone.utc).isoformat(),'label':label,'git_head':git('rev-parse','--verify','HEAD'),'git_branch':git('symbolic-ref','-q','HEAD'),'git_ls_files_bytes_sha256':sha(listed),'tracked':tracked,'index_path':str(ip),'index_bytes':len(index),'index_sha256':sha(index),'discovery_ledger_bytes':len(disc),'discovery_ledger_sha256':sha(disc),'advance_ledger_bytes':len(adv),'advance_ledger_sha256':sha(adv),'discovery_states':ds,'advance_states':as_,'frontier_files':frontiers,'all_direct_runs_jsonl_files':ledger_files}
 with contextlib.ExitStack() as stack:
  for name,data in [('discovery-ledger.raw',disc),('advance-ledger.raw',adv),('git-index.raw',index),('git-ls-files.raw',listed)]:
   path=PRIVATE/(label+'.'+name);fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
   with os.fdopen(fd,'wb') as f:f.write(data)
 path=PRIVATE/(label+'.full-guard.json');fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
 with os.fdopen(fd,'w') as f:json.dump(full,f,indent=2,ensure_ascii=True);f.write('\n')
 print('guard_'+label+'_completed',flush=True)
 return full,disc,adv,sha(path.read_bytes())

if MARKER.exists():raise SystemExit('STOP: one-time marker already exists; inspect actual ledger suffix and status, never replay this script')
review=OWN.parent/'conceptual_mirror_v1/conceptual-mirror.review-run.json';assert sha(review.read_bytes())=='84db3352383b1a3bafbb9f402c6a6e4722d71d31e9ea778efb189b930c93551b'
proposal=json.loads((OWN.parent/'conceptual_mirror_v1/inputs/conceptual-mirror-proposal.authored-v1.json').read_text())
before,disc_before,adv_before,before_sha=capture('before-v2')
target=before['discovery_states'][D];assert target['status']=='raw' and target['created_by']==CREATOR and target['kind']=='conceptual-mirror';assert ACTOR!=CREATOR;assert target['metadata']==proposal['metadata'] and target['statement']==proposal['statement']
note=('Independent source/math conceptual-mirror validation by '+ACTOR+'. Evidence: '+str(review.relative_to(ROOT))+' SHA256 84db3352383b1a3bafbb9f402c6a6e4722d71d31e9ea778efb189b930c93551b; exact proposal SHA256 3c34f9b57ed166b125bee215174175eaf4cfb9bf64ab111cf016f037a536e051. Accepted typed mechanism: positive-observable scalar Markov with same-operator spectral-to-trace adapter; hypothesis/conclusion/key-estimate/failure-boundary source mapping checked. This does not validate the creator\'s process/global-retrieval survey, a Lean implication/formal transport, full matrix MGF/Lieb/master-tail/Bernstein/C6/main lower bound, production/global graph or whole-Goal completion. No proof advance transition or graph mutation is performed.')
(OWN/'validation-note.txt').write_text(note+'\n')
marker={'target_discovery_id':D,'from_status':'raw','to_status':'validated','actor':ACTOR,'creator':CREATOR,'api':'tools.astis_advance.transition_discovery','validation_calls_authorized':1,'review_run_sha256':'84db3352383b1a3bafbb9f402c6a6e4722d71d31e9ea778efb189b930c93551b','note_sha256':sha(note.encode()),'before_guard_sha256':before_sha,'created_at_utc':datetime.now(timezone.utc).isoformat(),'failure_policy':'If any error occurs, inspect actual ledger suffix and this marker; never automatically replay.'}
fd=os.open(MARKER,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
with os.fdopen(fd,'w') as f:json.dump(marker,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
api_status=0;api_error=None
print('normal_validation_call_started_once',flush=True)
with (OWN/'normal-api.stdout.txt').open('x') as sout,(OWN/'normal-api.stderr.txt').open('x') as serr:
 with contextlib.redirect_stdout(sout),contextlib.redirect_stderr(serr):
  try:api.transition_discovery(D,'validated',actor=ACTOR,note=note)
  except BaseException as exc:
   api_status=1;api_error=type(exc).__name__;traceback.print_exc()
emit(OWN/'normal-api.status.json',{'exit_status':api_status,'api_calls_attempted':1,'api_exception_type':api_error,'stdout_bytes':(OWN/'normal-api.stdout.txt').stat().st_size,'stderr_bytes':(OWN/'normal-api.stderr.txt').stat().st_size})
print('normal_validation_call_returned_status_'+str(api_status),flush=True)
after,disc_after,adv_after,after_sha=capture('after-v2')
append_prefix_preserved=disc_after.startswith(disc_before);suffix=disc_after[len(disc_before):] if append_prefix_preserved else b'';(OWN/'exact-target-append.jsonl').write_bytes(suffix)
appended=[json.loads(x) for x in suffix.splitlines() if x.strip()] if append_prefix_preserved else []
one_target_append=(len(appended)==1 and appended[0].get('event')=='discovery_transition' and appended[0].get('discovery_id')==D and appended[0].get('from_status')=='raw' and appended[0].get('to_status')=='validated' and appended[0].get('actor')==ACTOR and appended[0].get('note')==note)
old_discoveries_preserved=all(after['discovery_states'].get(k)==v for k,v in before['discovery_states'].items() if k!=D)
expected_target=dict(target);expected_target.update(status='validated',updated_at=appended[0].get('created_at') if appended else None,latest_note=note,latest_actor=ACTOR)
target_exact=(after['discovery_states'].get(D)==expected_target)
all_runs_other_same=all(after['all_direct_runs_jsonl_files'].get(k)==v for k,v in before['all_direct_runs_jsonl_files'].items() if k!=str(api.DEFAULT_DISCOVERY_LEDGER.relative_to(ROOT))) and set(after['all_direct_runs_jsonl_files'])==set(before['all_direct_runs_jsonl_files'])
checks={'normal_api_exit_status_zero':api_status==0,'exactly_one_target_discovery_append':one_target_append,'raw_discovery_ledger_prefix_preserved':append_prefix_preserved,'all_other_discovery_states_preserved':old_discoveries_preserved,'discovery_identity_set_preserved':set(before['discovery_states'])==set(after['discovery_states']),'target_only_expected_replay_fields_changed':target_exact,'advance_ledger_exact_bytes_preserved':adv_before==adv_after,'all_advance_states_preserved':before['advance_states']==after['advance_states'],'all_other_direct_runs_jsonl_files_preserved':all_runs_other_same,'old_frontier_file_map_preserved':before['frontier_files']==after['frontier_files'],'git_HEAD_preserved':before['git_head']==after['git_head'],'git_branch_preserved':before['git_branch']==after['git_branch'],'git_index_bytes_preserved':before['index_sha256']==after['index_sha256'] and before['index_bytes']==after['index_bytes'],'git_all_other_tracked_content_bytes_modes_preserved':{k:v for k,v in before['tracked'].items() if k!=str(api.DEFAULT_DISCOVERY_LEDGER.relative_to(ROOT))}=={k:v for k,v in after['tracked'].items() if k!=str(api.DEFAULT_DISCOVERY_LEDGER.relative_to(ROOT))},'git_tracked_path_set_preserved':before['git_ls_files_bytes_sha256']==after['git_ls_files_bytes_sha256'],'tracked_target_ledger_mode_preserved':before['tracked'][str(api.DEFAULT_DISCOVERY_LEDGER.relative_to(ROOT))]['mode']==after['tracked'][str(api.DEFAULT_DISCOVERY_LEDGER.relative_to(ROOT))]['mode'],'tracked_target_ledger_has_only_exact_authorized_append':append_prefix_preserved and one_target_append}
summary={'status':'VALIDATED_ONCE_ALL_PRESERVATION_CHECKS_PASS' if all(checks.values()) else 'STOP_INSPECT_ACTUAL_SUFFIX_NO_REPLAY','discovery_id':D,'creator':CREATOR,'independent_actor':ACTOR,'actual_before_status':target['status'],'actual_after_status':after['discovery_states'][D]['status'],'normal_api':'tools.astis_advance.transition_discovery','normal_api_calls_attempted':1,'review_evidence_run_sha256':'84db3352383b1a3bafbb9f402c6a6e4722d71d31e9ea778efb189b930c93551b','checks':checks,'counts':{'discovery_states_before':len(before['discovery_states']),'discovery_states_after':len(after['discovery_states']),'advance_states_before':len(before['advance_states']),'advance_states_after':len(after['advance_states']),'frontier_files':len(before['frontier_files']),'tracked_paths':len(before['tracked'])},'before_discovery_ledger_bytes':len(disc_before),'after_discovery_ledger_bytes':len(disc_after),'append_bytes':len(suffix),'exact_append_sha256':sha(suffix),'private_before_guard_sha256':before_sha,'private_after_guard_sha256':after_sha,'private_guard_policy':'Full foreign states, tracked/index/frontier maps and raw ledgers remain local-only in local-private-guards; never copy to public custody. Only this bounded summary and exact target suffix are public-safe.','tracked_file_exception':'Only runs/substantive_discoveries.jsonl may change, solely by complete prefix preservation plus the one exact authorized target event; all other tracked bytes/modes and the index remain unchanged.','scope':'Independent typed conceptual/source/math validation only. No creator process/global-retrieval certification; no formal transport/full MGF/Lieb/Bernstein; no proof PL/VERIFIED/stabilization/graph/production mutation.'}
emit(OWN/'preservation.bounded-summary.json',summary);emit(OWN/'normal-validation.receipt.json',{'discovery_id':D,'actor':ACTOR,'to_status':after['discovery_states'][D]['status'],'api_exit_status':api_status,'api_calls_attempted':1,'exact_target_append_sha256':sha(suffix),'bounded_summary_sha256':sha((OWN/'preservation.bounded-summary.json').read_bytes()),'one_time_marker_sha256':sha(MARKER.read_bytes()),'all_preservation_checks_pass':all(checks.values()),'safe_evidence_scope':summary['scope']})
print(json.dumps({'status':summary['status'],'target':D,'calls':1,'all_preservation_checks_pass':all(checks.values()),'append_bytes':len(suffix)},indent=2),flush=True)
if not all(checks.values()):raise SystemExit(2)
