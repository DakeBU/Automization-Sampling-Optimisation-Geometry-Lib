from pathlib import Path
import sys, subprocess, hashlib, json, datetime, os
ROOT=Path(__file__).resolve().parents[3]
OUT=Path(__file__).resolve().parent
label=sys.argv[1]; argv=sys.argv[2:]
assert label.replace('-', '').replace('_', '').isalnum()
log=OUT/(label+'.log'); receipt=OUT/(label+'.receipt.json')
assert not log.exists() and not receipt.exists(), label
head=lambda: subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
before=head(); start=datetime.datetime.now(datetime.timezone.utc).isoformat()
env=dict(os.environ); env['PYTHONDONTWRITEBYTECODE']='1'
p=subprocess.run(argv,cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,env=env)
log.write_bytes(p.stdout)
r={'label':label,'argv':argv,'cwd':str(ROOT),'head_before':before,'head_after':head(),'started_utc':start,'ended_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':p.returncode,'log':str(log.relative_to(ROOT)),'log_sha256':hashlib.sha256(p.stdout).hexdigest(),'log_size':len(p.stdout)}
receipt.write_text(json.dumps(r,indent=2,ensure_ascii=False)+'\n')
print(json.dumps(r,ensure_ascii=False)); print(p.stdout.decode(errors='replace'))
sys.exit(p.returncode)
