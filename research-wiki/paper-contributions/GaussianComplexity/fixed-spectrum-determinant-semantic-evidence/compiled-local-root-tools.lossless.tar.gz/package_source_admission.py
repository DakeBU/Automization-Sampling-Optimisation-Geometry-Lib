from pathlib import Path
import json,hashlib,gzip,subprocess,tarfile,shutil
sha=lambda raw:hashlib.sha256(raw).hexdigest()
b=Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-determinant-semantic-evidence');private=Path('.astis/huanjian-fixed-spectrum-determinant-20261108');seal=json.loads((b.parent/'fixed-spectrum-determinant-statement-seal.json').read_bytes());assert not Path(seal['production_file']).exists() and not Path(seal['real_consumer']['file']).exists()
src=private/'source-graph-486201/phase1-freeze-manifest.json';dst=b/'source-only-review/source-phase1-freeze-manifest.copy.json';assert not dst.exists();shutil.copy2(src,dst);assert src.read_bytes()==dst.read_bytes()
checks=b/'actual-checks'
for p in sorted(Path('.astis/huanjian-resume-20261103').glob('*-fixed-spectrum-determinant-*.receipt.json')):
 r=json.loads(p.read_bytes());raw=Path(r['log']).read_bytes();assert sha(raw)==r['log_sha256']
 if (checks/p.name).exists():continue
 shutil.copy2(p,checks/p.name);z=checks/(Path(r['log']).name+'.gz');z.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(z.read_bytes())==raw
files=sorted(p for p in private.rglob('*') if p.is_file());archive=b/'preproof-source-admission-tools.lossless.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz') as t:
 for p in files:t.add(p,arcname=str(p.relative_to(private)),recursive=False)
with tarfile.open(archive,'r:gz') as t:
 for p in files:assert t.extractfile(str(p.relative_to(private))).read()==p.read_bytes()
manifest=b/'preproof-source-admission-tools.manifest.json';manifest.write_text(json.dumps({'archive':str(archive),'sha256':sha(archive.read_bytes()),'all_members_roundtrip_verified':True,'target_Lean_implementation_exists':False,'files':[{'path':str(p),'member':str(p.relative_to(private)),'sha256':sha(p.read_bytes())} for p in files]},indent=2)+'\n')
paths=sorted(p for p in b.rglob('*') if p.is_file());pack=b/'preproof-frozen-raw-packaging';pack.mkdir(exist_ok=False);safe=[];rows=[]
for p in paths:
 raw=p.read_bytes();ignored=subprocess.run(['git','check-ignore','-q','--',str(p)]).returncode==0;binary=p.suffix in ['.gz','.zip','.png'] or b'\0' in raw;bad=not binary and (any(line.endswith((b' ',b'\t',b'\r')) for line in raw.split(b'\n')) or raw.endswith(b'\n\n'))
 if ignored or bad:
  z=pack/(str(len(rows)).zfill(3)+'-'+p.name+'.gz');z.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(z.read_bytes())==raw;rows.append({'original_path':str(p),'raw_sha256':sha(raw),'raw_bytes':len(raw),'gzip_path':str(z),'gzip_sha256':sha(z.read_bytes()),'reason':{'ignored':ignored,'frozen_whitespace_or_blank_EOF':bad},'original_retained_unmodified':True});safe.append(z)
 else:safe.append(p)
manifest=pack/'manifest.json';manifest.write_text(json.dumps({'rule':'Only frozen evidence under owned newpacket folder is packaged losslessly; originals never normalized/deleted. Restore exactoriginalpaths before replaying sourcefreezes. Mutable ledger/frontier/README staged directly below.','files':rows},indent=2)+'\n');safe.append(manifest)
mutable=[Path(x) for x in ['runs/substantive_advances.jsonl','research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-determinant.json','research-wiki/paper-contributions/GaussianComplexity/README.md']];safe += mutable+[b.parent/'fixed-spectrum-determinant-statement-seal.json'];subprocess.run(['git','add','--',*[str(p) for p in safe]],check=True)
r=subprocess.run(['git','diff','--cached','--check'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT);print(r.stdout.decode());assert r.returncode==0
for p in mutable:assert subprocess.check_output(['git','show',':'+str(p)])==p.read_bytes()
print(json.dumps({'owned_paths_staged':len(safe),'frozen_raw_losslessly_packaged':len(rows),'all3mutable_paths_exactly_staged':True,'preproof_archive_sha256':sha(archive.read_bytes()),'producer_Test_implementation_exists':False,'overall_implementation_admission':False}))
