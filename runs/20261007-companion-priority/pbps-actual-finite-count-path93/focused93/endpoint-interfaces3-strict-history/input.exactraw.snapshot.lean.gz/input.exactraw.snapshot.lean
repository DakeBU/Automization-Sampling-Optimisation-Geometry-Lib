import AutoSamplingTheory.ExampleCases.ProximalBPS.ActualOrderedPrefix
import AutoSamplingTheory.ExampleCases.ProximalBPS.ActualPhysicalTimeMeasurability
import Mathlib.MeasureTheory.Constructions.Pi

open InnerProductSpace MeasureTheory ProbabilityTheory Filter
open scoped NNReal ENNReal

namespace EndpointInterfaces93

private theorem subtype_coordinate_null (n : ℕ) (D : Set (Fin n → ℝ))
    (i : Fin n) (t : ℝ) :
    (Measure.comap (fun x : D => x.val) (volume : Measure (Fin n → ℝ)))
      {x | x.val i = t} = 0 := by
  have hm : MeasurableSet {x : D | x.val i = t} :=
    measurableSet_eq_fun ((measurable_pi_apply i).comp measurable_subtype_coe) measurable_const
  apply le_antisymm _ zero_le
  calc
    _ ≤ (volume : Measure (Fin n → ℝ))
        ((fun x : D => x.val) '' {x | x.val i = t}) :=
      Measure.comap_apply_le _ _ hm.nullMeasurableSet
    _ ≤ (volume : Measure (Fin n → ℝ)) {x | x i = t} := by
      apply measure_mono
      rintro x ⟨y, hy, rfl⟩
      exact hy
    _ = 0 := Measure.pi_hyperplane (fun _ : Fin n => (volume : Measure ℝ)) i t

private theorem weighted_map_coordinate_null
    {Ω X : Type*} [MeasurableSpace Ω] [MeasurableSpace X]
    (P : Measure Ω) (B : Set Ω) (H : Ω → X)
    (n : ℕ) (D : Set (Fin n → ℝ)) (K : D → X) (q : D → ℝ≥0∞)
    (obs : X → ℝ) (i : Fin n) (t : ℝ)
    (hH : Measurable H) (hK : Measurable K) (hobs : Measurable obs)
    (hcoord : ∀ x, obs (K x) = x.val i)
    (hlaw : Measure.map H (P.restrict B) =
      Measure.map K ((Measure.comap (fun x : D => x.val) volume).withDensity q)) :
    P ({w | obs (H w) = t} ∩ B) = 0 := by
  have hs : MeasurableSet {x | obs x = t} := measurableSet_eq_fun hobs measurable_const
  have hnull := withDensity_absolutelyContinuous
    (Measure.comap (fun x : D => x.val) volume) q (subtype_coordinate_null n D i t)
  have heval := congrArg (fun μ : Measure X => μ {x | obs x = t}) hlaw
  rw [Measure.map_apply hH hs, Measure.map_apply hK hs,
    Measure.restrict_apply (hs.preimage hH)] at heval
  have heq : K ⁻¹' {x | obs x = t} = {x : D | x.val i = t} := by
    ext x
    simp only [Set.mem_preimage, Set.mem_ofPred_eq, hcoord]
  rw [heq, hnull] at heval
  exact heval

#print axioms weighted_map_coordinate_null

private theorem live_prefix_strict_guard {X : Type*}
    (r : ℕ → (ℝ≥0 × X) ⊕ Unit)
    (hmono : Monotone (fun k => (r k).elim
      (fun a => (a.1 : WithTop ℝ≥0)) (fun _ => ⊤)))
    (hstrict : ∀ k a b, r k = Sum.inl a → r (k+1) = Sum.inl b → a.1 < b.1)
    (n : ℕ) (T : ℝ≥0)
    (hend : (r n).elim (fun a => (a.1 : WithTop ℝ≥0)) (fun _ => ⊤) < T) :
    (∀ j : Fin (n+1), ∃ a, r j.val = Sum.inl a) ∧
      StrictMono (fun j : Fin (n+1) => (r j.val).elim (fun a => (a.1 : ℝ)) (fun _ => 0)) ∧
      (∀ j : Fin n, (r j.succ.val).elim (fun a => (a.1 : ℝ)) (fun _ => 0) < T) := by
  have hfinite (k : ℕ) (hk : k ≤ n) :
      (r k).elim (fun a => (a.1 : WithTop ℝ≥0)) (fun _ => ⊤) < T :=
    lt_of_le_of_lt (hmono hk) hend
  have hlive (j : Fin (n+1)) : ∃ a, r j.val = Sum.inl a := by
    have hh := hfinite j.val (Nat.le_of_lt_succ j.isLt)
    cases hr : r j.val with
    | inl a => exact ⟨a, hr⟩
    | inr u => simp only [hr, Sum.elim_inr, not_top_lt] at hh
  refine ⟨hlive, ?_, ?_⟩
  · apply Fin.strictMono_iff_lt_succ.mpr
    intro j
    obtain ⟨a, ha⟩ := hlive j.castSucc
    obtain ⟨b, hb⟩ := hlive j.succ
    simp only [ha, hb, Sum.elim_inl]
    exact NNReal.coe_lt_coe.mpr (hstrict j.val a b ha hb)
  · intro j
    obtain ⟨a, ha⟩ := hlive j.succ
    have hh := hfinite j.succ.val (Nat.le_of_lt_succ j.succ.isLt)
    rw [ha] at hh ⊢
    exact NNReal.coe_lt_coe.mpr (WithTop.coe_lt_coe.mp hh)

#print axioms live_prefix_strict_guard
end EndpointInterfaces93
