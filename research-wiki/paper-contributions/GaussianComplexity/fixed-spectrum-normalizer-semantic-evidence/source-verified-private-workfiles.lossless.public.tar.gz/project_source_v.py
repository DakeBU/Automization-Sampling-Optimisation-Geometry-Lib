from pathlib import Path
import json,hashlib,datetime,sys,copy,subprocess,gzip
sys.path.insert(0,'tools')
import astis_advance as a
sha=lambda raw:hashlib.sha256(raw).hexdigest()
b=Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-normalizer-semantic-evidence')
v=b/'fresh-source-reader-640251/verification-transition'
rp=v/'transition-receipt.json';assert sha(rp.read_bytes())=='507ea27bbf1c3e5b838511065b3ca21afc667d1853a66aea9f57676fee35356e'
r=json.loads(rp.read_bytes());assert r['normal_API_calls']==1 and r['normal_API_exit_code']==0 and r['actor']=='/root/norm_fresh_source_640251'
mf=v/'preservation-manifest.json';assert sha(mf.read_bytes())=='5a1b5ae3e5932897c9429c0a30daaa1fd1f82319f80e3044ecedcc9a10b86f90'
private=Path('.astis/huanjian-fixed-spectrum-normalizer-20261108/fresh-source-640251/verification-transition')
assert mf.read_bytes()==(private/'preservation-manifest.json').read_bytes()
for row in json.loads(mf.read_bytes())['files']:
 for base in [v,private]:
  raw=(base/row['path']).read_bytes();assert len(raw)==row['bytes'] and sha(raw)==row['sha256']
before=gzip.decompress(Path(r['before_ledger_lossless_gzip']).read_bytes())
after=gzip.decompress(Path(r['after_ledger_lossless_gzip']).read_bytes())
append=Path(r['normal_append']).read_bytes()
assert after==before+append and len(append.splitlines())==1
assert sha(before)==r['ledger_before_raw_sha256']=='5c9e1a59a36580f09859d7ca7790196adb72f5be10282695381be8cfc1f333da'
assert sha(after)==r['actual_current_ledger_raw_sha256']=='2f891b0bdeb1d03432adbc327733c3f78b7bded735a0ed19bc396885f6623f08'
assert sha(append)==r['normal_append_raw_sha256']=='630b6125401c93aec5588645373ab70a61ea2a098ca1f345a351b422d47c477c'
event=json.loads(append);e=event['evidence']
assert event['from_state']=='PROVED_LOCAL' and event['to_state']=='VERIFIED' and event['worker_id']==r['actor']
assert e['verifier_id']==r['actor'] and e['verified_commit']==r['verified_commit']=='813268bc2683a82269364caffbc0c7490a884204'
assert all(e[k] for k in ['gate','source_audit','fake_closure_scan'])
ap=Path(r['accepted_canonical_audit']);ab=ap.read_bytes();assert sha(ab)=='8fa833c84e0a39e2afef0a7c4236e8d624a1cab94ecfbaa6b47a820f4f2ca7d1'
audit=json.loads(ab);assert audit['state']=='accepted' and audit['source_review']['reviewer']==r['actor']
assert json.loads(subprocess.check_output(['git','show',r['verified_commit']+':'+str(ap)]))['state']=='blind-reconstructed'
lp=Path('runs/substantive_advances.jsonl');dp=Path('runs/substantive_discoveries.jsonl');db=dp.read_bytes();assert lp.read_bytes()==after
aid=r['advance_id'];states=a.current_advances();assert states[aid]['state']=='VERIFIED' and states[aid]['owner_id']==r['original_proof_owner']
assert not [x for x in states.values() if x['state']=='STABILIZING']
cp=Path('research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-normalizer.json');old=cp.read_bytes();cell=json.loads(old)
foreign={str(p):p.read_bytes() for p in cp.parent.glob('*.json') if p!=cp}
readme=Path('research-wiki/paper-contributions/GaussianComplexity/README.md');readme_raw=readme.read_bytes()
assert 'existing_source_V' not in cell['evidence']
cell['evidence'].setdefault('source_phase_history',[]).append({k:copy.deepcopy(cell[k]) for k in ['status','source_detail_audit','source_proof_coverage','graph_contribution']})
cell['status']='independently_verified'
cell['statement_seal']['status']='EXACT_PROOF_COMPILED_AND_INDEPENDENT_SOURCE_ACCEPTED_CANONICAL_ROOT_GATE_PENDING'
cell['evidence']['independent_verification']='Existing independent normal V by '+r['actor']+' at813268bc; root mechanically projects only this event, no source verdict or lifecycle API.'
cell['evidence']['existing_source_V']={
 'verifier':r['actor'],'checked_commit':r['verified_commit'],'mathematical_candidate':'8d33e06485edc17320cc01308af40da44945659d',
 'canonical_packet_sha256':audit['source_review']['reviewer_packet_sha256'],'accepted_audit_raw_sha256':sha(ab),
 'normal_append_sha256':sha(append),'transition_and_preservation_receipt':str(rp),'transition_receipt_raw_sha256':sha(rp.read_bytes()),
 'review_run':str(b/'fresh-source-reader-640251/phase3/review-run.json'),
 'review_run_raw_sha256':'af777f590408d2c97ea4aa0172e416bb01b4dbcce815f9e2b1efe0f9a01a63f2',
 'accepted_audit_bytes_in_checked_commit':False,'root_source_verdict_created':False}
cell['evidence']['publication_binding_sha256']=audit['publication_binding_sha256']
boundary='Exact actual weight is Integrable against unweighted Euclidean Lebesgue volume AND its actual integral has the fixed spectral product value; genuine same-A actual-integral-normalized Gaussian Test uses the new producer. Independent source/whole-module/fresh-Lean/static-reader normal V accepted equivalent-after-elaboration. Checked813268bc contains blind audit; accepted8fa833 bytes and Vappend are successor metadata, not retroactive checked-tree bytes. Canonical root/site/graph/desktop-mobile acceptance pending. Full C4 calculus/minimizer, strict historical angle/cosine route, moments/Krylov, actual adaptive/oracle/precision/TV/deterministic/expected-cost adapters, both main bounds, remote/purification/Seal/wholeGoal remain separate.'
cell['evidence']['execution_boundary']=boundary;cell['source_detail_audit']['fidelity_boundary']=boundary
cell['source_proof_coverage']['independent_implementation_review']={
 'review':str(b/'fresh-source-reader-640251/phase3/review-result.json'),
 'sha256':sha((b/'fresh-source-reader-640251/phase3/review-result.json').read_bytes()),
 'scope':'Exact actual finite integral and genuine private normalized-law consumer, disclosed source-implicit convention and actual density/unit-mass implementation OR-route.',
 'historical_ancestor_sourceV_upgraded':False,'strict_source_angle_cosine_new_Lean_credit':False}
cell['proof_digestion']={
 'existing_substrate':cell['evidence']['actual_compiled_producer_parents'],
 'bookkeeping':['Literal source reindexing/coordinate quadratic and actual unnormalized Euclidean integration base',
 'Finite nonnegative Gaussian probability-density mass plus measurability proves integrability; positive coefficient removal and actual real integral conversion',
 'Actual determinant product and positive square-root/real-power normalization adapters'],
 'new_reusable':[],'new_topology':['Explicit implementation OR-route: canonical actual Gaussian density/unit probability mass to actual unweighted integrability/value; this is not a new source author route or novelty score.'],
 'independent_review':str(b/'fresh-source-reader-640251/phase3/review-result.json')}
cell['graph_contribution']['visual_review']='Pending exactHEAD root/site/graph/actual desktop-mobile Chrome acceptance. Source V covers static reader only; reuse canonical parent IDs and retain historical GPD audit debt.'
cell['learning_contract']['reader_backpressure']['assumptions_preserved']=True
cell['learning_contract']['reader_backpressure']['boundary_preserved']=True
cp.write_text(json.dumps(cell,ensure_ascii=False,indent=2)+'\n')
assert lp.read_bytes()==after and dp.read_bytes()==db and a.current_advances()==states and ap.read_bytes()==ab
assert all(Path(p).read_bytes()==raw for p,raw in foreign.items()) and readme.read_bytes()==readme_raw
record={'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'operation':'Mechanical own-cell projection of existing independent V only; no root source verdict/API.',
 'cell_before_sha256':sha(old),'cell_after_sha256':sha(cp.read_bytes()),'source_verifier':r['actor'],
 'source_V_append_sha256':sha(append),'audit_unchanged_raw_sha256':sha(ab),
 'foreign_frontier_files_preserved':len(foreign),'all_advance_states_and_ledgers_unchanged':True,'README_unchanged':True,
 'checked_tree_audit':'blind-reconstructed at813268bc','accepted_bytes_first_carrying_commit':'Next metadata commit; no retroactive checked-tree byte equality.',
 'canonical_integration_remote_purification':False}
p=b/'mechanical-existing-source-V-projection.json';assert not p.exists();p.write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'projected_existing_sourceV':True,'foreign_frontiers_preserved':len(foreign),'normal_append_sha256':sha(append),'source_verdict_created':False,'README_unchanged':True}))
