#!/opt/anaconda3/bin/python
import hashlib,json,pathlib,re,stat,subprocess
BASE=pathlib.Path(__file__).resolve().parent
def sha(b):return hashlib.sha256(b).hexdigest()
commit='72e5d1405284f729f4eb600c5ae5dd556365b7e2'
proc=subprocess.run(['git','rev-parse',commit+'^'],cwd='/Users/zhouhuanjian/ASTIS-GC',capture_output=True)
(BASE/'candidate-parent.stdout').write_bytes(proc.stdout);(BASE/'candidate-parent.stderr').write_bytes(proc.stderr)
assert proc.returncode==0 and proc.stdout.decode().strip()=='75dcc0c9c7d9591384c6e0705e118b1ab440cd6c'
parents={'argv':['git','rev-parse',commit+'^'],'returncode':proc.returncode,
         'stdout':proc.stdout.decode(),'stderr':proc.stderr.decode()}
inventory=json.loads((BASE/'input_inventory.json').read_text())
mapping=json.loads((BASE/'inputs/research-wiki__paper-contributions__GaussianComplexity__fixed-spectrum-cosine-gram-semantic-evidence__source-to-lean-map-v1.json').read_text())
all_inventory=inventory+json.loads((BASE/'dependency_inventory.json').read_text())+json.loads((BASE/'deeper_dependency_inventory.json').read_text())
paths={r['source']:BASE/r['snapshot'] for r in all_inventory}
for row in mapping['locator_slices']:
    data=paths[row['file']].read_bytes();end=row['byte_end_exclusive']
    observed=data[:end].count(b'\n')+(0 if data[:end].endswith(b'\n') else 1)
    assert observed==row['end_line_1based_inclusive'],(row['slice_id'],observed)
    assert len(row['literalLF'])==row['character_length']
raw=(BASE.parent/'phase1/inputs/2610.20492v1.html').read_bytes()
for anchor,row in mapping['raw_source_anchor_locators'].items():
    fragment=raw[row['byte_start']:row['byte_end_exclusive']]
    assert ('id="'+anchor+'"').encode() in fragment,anchor
root_files=['AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumCosineGram.lean',
            'Tests/GaussianComplexityFixedSpectrumCosineGram.lean',
            'AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumGridAlias.lean']
scans=[]
for name in root_files:
    text=paths[name].read_text()
    found=re.findall(r'(?m)^\s*(?:(?:private|protected|noncomputable)\s+)*(?:theorem|lemma|def|axiom|instance|abbrev)\s+([^\s:({]+)',text)
    prohibited=re.findall(r'\b(?:sorry|admit|axiom)\b|Prop\s*:=\s*True|:=\s*trivial',text)
    scans.append({'source':name,'handwritten_declarations':found,'prohibited_token_matches':prohibited,
                  'ambient_variable_commands':bool(re.search(r'(?m)^\s*(?:variable|variables|include|omit)\b',text))})
    assert not prohibited
for name in root_files[:2]:assert 'set_option autoImplicit false' in paths[name].read_text()
phase2=json.loads((BASE.parent/'phase2/inputs/selective-fresh-source-phase2-input.json').read_text())
T=paths[root_files[1]].read_text()
assert phase2['actual_private_consumer_literal_signature'] in T
unchanged=[]
expected={'phase1':'80d4eefdb9d3d733e60d4ea52d00207c5ca62e03c1964b94e404525c2e472079',
          'phase2':'8a5ff1011acb383f99d2411649240d48023186cac33c24323d9e95402361625e'}
for name,digest in expected.items():
    directory=BASE.parent/name
    assert sha((directory/'manifest.json').read_bytes())==digest
    manifest=json.loads((directory/'manifest.json').read_text())
    for row in manifest['payloads']:
        path=directory/row['path'];data=path.read_bytes()
        assert sha(data)==row['sha256'] and len(data)==row['bytes']
        assert stat.S_IMODE(path.stat().st_mode)==0o444
    assert stat.S_IMODE(directory.stat().st_mode)==0o555
    unchanged.append({'phase':name,'manifest_sha256':digest,'verified_payload_count':len(manifest['payloads']),
                      'file_mode_observed':'0444','directory_mode_observed':'0555'})
result={'candidate_parent_observation':parents,'source_map_all_line_end_and_character_counts_match':True,
        'raw_source_locator_IDs_match':True,'root_source_scans':scans,
        'phase2_private_literal_signature_is_exact_candidate_substring':True,
        'prior_phases_verified_unchanged':unchanged,'compiler_run':False,
        'canonical_row_identity_count':len({r['canonical_id'] for r in mapping['canonical_rows']})}
(BASE/'final_structural_verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
