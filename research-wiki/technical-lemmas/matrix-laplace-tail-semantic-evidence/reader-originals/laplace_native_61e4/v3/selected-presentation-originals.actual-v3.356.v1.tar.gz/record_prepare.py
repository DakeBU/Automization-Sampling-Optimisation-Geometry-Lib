"""Capture a real preparation subprocess in the independent presentation directory."""
import datetime as dt
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time
OWN=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
out=OWN/'prepare-attempt2.stdout.raw';err=OWN/'prepare-attempt2.stderr.raw'
started=dt.datetime.now(dt.timezone.utc).isoformat();start=time.monotonic()
argv=[sys.executable,str(OWN/'prepare_browser.py')]
with out.open('xb') as o,err.open('xb') as e:r=subprocess.run(argv,cwd=OWN,stdout=o,stderr=e,stdin=subprocess.DEVNULL)
receipt={'argv':argv,'cwd':str(OWN),'started_utc':started,'ended_utc':dt.datetime.now(dt.timezone.utc).isoformat(),'elapsed_seconds':time.monotonic()-start,'exit_code':r.returncode,'stdout':{'path':out.name,'sha256':sha(out)},'stderr':{'path':err.name,'sha256':sha(err)}}
(OWN/'prepare-attempt2.receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt));sys.exit(r.returncode)
