# Phase 2 — selective source/type/reconstruction comparison

Actor: `/root/zeroquery_fresh_source_2f8a71`. This phase follows the immutable phase1 cognition and precedes implementation, proof, exposition and native-check exposure. The only newly read external artifact is `selective-fresh-source-phase2-input.json`, exactly 9649 bytes, raw SHA-256 `2f2e5f127775bea0be16b4aad327c377b744d6410c5b36344aa7f50e5ee1511a`. Its source paraphrase is a candidate attribution, not the original source authority. The source basis remains the original HTML and my frozen phase1 reconstruction.

## Result of this limited comparison

The displayed public proposition and independent reconstruction agree with the **signed coordinate-event separation auxiliary** that I derived in phase1 from the original source event calculation. My provisional type-level classification for that bounded auxiliary is `equivalent-after-elaboration`. This is not a final source-review verdict or an implementation/native/publication verdict. Full code and authored-content review remain pending.

The candidate is only the event-gap auxiliary. The larger selected source paragraph additionally relates actual zero-query algorithms to one common output law, applies uniform-in-input accuracy, and concludes T≥1. Neither the public type nor the supplied private signature states that entire algorithm claim. The candidate attribution explicitly says auxiliary, which is the appropriate narrower boundary. It would be a scope error to treat these signatures alone as formalizing the actual algorithm model, the cap conclusion, the complete integral chain, all of Theorem 3.1, or the disclosed-spectrum model.

## Seven slots

| Slot | Original-source auxiliary meaning, independently reconstructed | Candidate/reconstruction meaning | Relation and evidence |
|---|---|---|---|
| Objects | Precisions A₀=I and A₁=diag(κ,1,…,1); targets N(0,A_j⁻¹); first-coordinate closed slab | Actual inverse covariance parameters supplied to multivariateGaussian; real Euclidean finite coordinate space and event masses | `explicit-elaboration`. Matrix diagonal, actual inverse, Gaussian covariance, and coordinate meanings agree with phase1's source-derived objects. Decoder identifies probability measures and precision/covariance distinction correctly. |
| Domains | d an integer ≥1 and real κ≥4; x∈R^d with Borel events; no block dimension condition | d:Nat, hd:1≤d, κ:Real, hκ:4≤κ, EuclideanSpace Real(Fin d) | `equivalent`. Nat with hd represents positive integer dimension; all κ≥4 including 4 remain; no κ upper bound. d=1 remains with only first entry. |
| Quantifiers | Every d≥1, every κ≥4; targets/event fixed from them | Universal implicit d, explicit hd, implicit κ, explicit hκ, followed by local lets | `same`. Implicit binder syntax does not restrict universal scope; no existential target, event or regularity witness is assumed. |
| Assumptions | Dimension and κ bounds suffice for the auxiliary; admissibility/inverse/normal-coordinate/event facts are derived | Only hd and hκ are mathematical proof binders; no separation, inverse, density, covariance positivity or probability witness is public input | `same` at the displayed interface. Basic carrier/type structure is ordinary typing. Supplied definition meanings imply all parameter branches are valid; implementation discharge remains unobserved. |
| Conclusion | At E, π_A1(E)−π_A0(E)>1/8, by smaller first-coordinate variance, symmetry and source integral estimate | (1:Real)/8 < ν₁.real B−ν₀.real B; decoder gives ν₁(B)−ν₀(B)>1/8 | `explicit-elaboration`. Signed direction is correct and stronger than a generic unsigned event gap, but it is exactly the signed event calculation recovered independently in phase1. It is not the entire raw displayed TV/integral chain or the algorithm conclusion. |
| Scopes | Auxiliary step inside an undisclosed-input exact-oracle zero-query proof; source TV is sup event difference | Public theorem concerns two target event masses only; private signature separately excludes a common probability law at two fixed errors | `explicit-elaboration` for the bounded auxiliary, with informational scope limits below. It does not encode algorithms/caps and cannot import the separate disclosed-spectrum guarantee. |
| Constant dependencies | Literal event radius 1/2, strict gap >1/8, all d≥1 and κ≥4; dimension/κ-independent constants | Same fractions, closed ≤ endpoint, strict conclusion, first Fin coordinate using hd | `same`. Private signature's 1/16 is the source threshold for common-law contradiction. ε is appropriately absent from the gap auxiliary. |

The blind reconstruction does not mention Lean `.real` totalization, inverse totalization or square-root fallback. That omission is harmless **on this displayed domain** because the inverse covariances are positive definite and the resulting measures are probabilities, so their event masses are finite. It would cease to be harmless if those guards were changed. The current comparison is based on the supplied minimal meanings; actual implementations of those meanings are still withheld.

## Every binder and local definition

- `{d : Nat}` is carrier information; `hd : 1≤d` is the source dimension restriction. The Fin element ⟨0,hd⟩ is the same first coordinate as paper x₁. No d=0 case is claimed. It is not an added dimension assumption.
- `{κ : Real}` is carrier information; `hκ : 4≤κ` is the source parameter restriction. It implies κ>0 internally, rather than requesting a separate positivity/invertibility premise.
- The local A₁ is a definition, not an assumption. At i.val=0 its diagonal entry is κ; otherwise it is 1. Both reachable conditional branches have the intended source diagonal meaning. At d=1 there is no distinct nonfirst coordinate. No behavior of the empty matrix matters because hd excludes it.
- The local ν₀ has zero mean and covariance (I_d)⁻¹=I_d. The local ν₁ has zero mean and covariance A₁⁻¹=diag(1/κ,1,…,1). All precision and inverse diagonal entries are positive for κ≥4. Matrix nonsingular-inverse semantics apply; the off-domain singular-inverse totalization branch cannot be reached.
- By the supplied minimal canonical meaning, multivariateGaussian uses the square-root pushforward and is a probability measure. Its non-PSD square-root/Dirac fallback cannot be reached for these inverse covariances. A Gaussian construction's arbitrary fallback elsewhere is not in itself a defect of this guarded auxiliary; actual body/dependency inspection is deferred.
- The canonical coordinate Gaussian has variance v, not standard deviation v. Reachable variances are 1 and 1/κ>0, so the positive-density branch applies, with standard deviation 1/√κ. The zero-variance Dirac branch is unreachable here.
- The local B uses ordinary closed `≤1/2` and the absolute value of the first coordinate. Continuity gives Borel measurability internally. Neither an event-mass equality nor a Borel witness is assumed in the public statement.
- `Measure.real B` is toReal of the extended event mass. These measures are probabilities, so all event masses are finite and conversion preserves the intended real probabilities. Thus the signed real subtraction is the source probability difference, not a difference of truncated/infinite values.
- Implicit standard measurable/Euclidean structures are typing conventions of the source carrier, not extra mathematical assumptions. There is no project-owned Prop alias or record argument in the displayed public type to expand further.

## Real TV normalization and the private common-law signature

The private signature is additional selective exposure and was not available during phase1. It takes the same hd,hκ and an arbitrary `ρ : ProbabilityMeasure(EuclideanSpace Real(Fin d))`. This supplies exactly a common Borel probability law, not Gaussianity, a density, a target match, a separation witness, or an algorithm. That subtype's IsProbabilityMeasure field is source-appropriate standing structure for the common-law bridge.

Its local Δ is

\[
\sup\{ |\mu(B)-\nu(B)| : B\text{ Borel}\}.
\]

Here μ(B),ν(B) are expressed with `.real`. On all actual pairs in the private conclusion, both arguments are probability measures. Each event value is between 0 and 1, so the set of absolute differences is bounded above by 1. It contains 0 by the empty event. Therefore real `sSup` is a legitimate finite supremum and equals the source probability-TV convention, with **no factor of two**. This is the same normalized TV as one-half the L¹ density difference; it is not the full total-variation norm of μ−ν.

Although the local Δ lambda syntactically accepts arbitrary measures, the private theorem does not assert good TV semantics for arbitrary infinite measures. Its only evaluated arguments are the fixed Gaussian probabilities and ρ's probability coercion; off-domain real-supremum/toReal behavior does not enter. A change that evaluated Δ on uncontrolled measures would require renewed audit.

The private conclusion forbids Δ(ρ,ν₀)≤1/16 and Δ(ρ,ν₁)≤1/16 simultaneously. The public signed gap >1/8 suffices: on the Borel slab, ν₁(B)−ν₀(B)≤|ν₁(B)−ρ(B)|+|ρ(B)−ν₀(B)|≤1/8. This uses the displayed literal Δ meaning and no Gaussian assumption on ρ. The signature does not expose a theorem-shaped premise or hide a bound inside ρ.

This is a faithful **law-level consequence**, subject to later proof review. It is not an implementation of a full oracle algorithm. To obtain the source's T≥1 statement, a formal consumer must still derive that a zero-cap source algorithm produces a single law independent of A and instantiate uniform accuracy at two admissible matrices. Those links are not supplied by a signature alone. The private threshold 1/16 entails the corresponding contradiction for every source ε≤1/16 by monotonicity; no ε binder is necessary for this fixed-threshold helper.

## Signed event direction and source attribution

The source's raw display states TV≥2∫_{1/2}^1φ≥φ(1)>1/8≥2ε. The text identifies E={|x₁|≤1/2}. From the actual source target definitions, π_A1(E)=P(|Z|≤√κ/2) and π_A0(E)=P(|Z|≤1/2), so the nonnegative difference is specifically π_A1−π_A0. That direction was already frozen in phase1. Thus the candidate's signed gap is a justified elaboration of the source event calculation, independently of its attributed paraphrase and decoder.

The candidate source paraphrase should stay visibly labeled as an attributed auxiliary restatement. Calling it the verbatim source or treating its source identifier as proof of fidelity would be incorrect. No blanket acceptance of that paraphrase is given here.

## Phase2 scope observations, not repairs

1. Public event-gap auxiliary omits the explicit integral expression and TV conclusion. This is a bounded proof component, not the whole displayed chain or selected source paragraph. The supplied attribution marks auxiliary; no source repair is warranted.
2. Private common-law impossibility covers arbitrary Borel output probabilities, but contains no seed, Borel algorithm transcript, stopping rule or T binder. Algorithm-cap closure remains a separate source obligation.
3. Since A₀ and A₁ have different spectra, their outputs need not agree if input-dependent spectrum information is free. No strengthened disclosed-spectrum conclusion follows from these signatures. At d=1 a known spectrum fixes the precision and permits exact zero-oracle Gaussian output. This boundary was established before the candidate was read.
4. `compiled:true` is supplied metadata. No actual compiler invocation, dependency implementation, native execution, fake-closure cleanliness, publication binding freshness, authored proof, correspondence or delivery has been observed. This phase cannot certify those facts.

No minimum additional canonical context is required for this limited type-level comparison. The supplied meanings are sufficient to identify and bound every reachable branch above. The next phase still requires immutable full candidate/code/reader inputs to validate implementation and exposition before any final five-field source-review proposal.
