from pathlib import Path
import collections
import json
import runpy
import sys

ROOT = Path('/Users/zhouhuanjian/ASTIS-GC')
OWN = ROOT / '.astis/semantic-neutral-20261112/ri_tc_24a6'
SG = ROOT / '.astis/semantic-neutral-20261112/ri_sg_78c2'
mode = sys.argv[1]
lo, hi = (int(v) for v in sys.argv[2:4]) if len(sys.argv) > 2 else (0, 1000)
sys.argv = [str(OWN / 'read_raw.py'), 'silent']
r = runpy.run_path(str(OWN / 'read_raw.py'))
by_id = r['by_id']
c = json.loads((SG / 'type-phase-v1/coverage-v1.json').read_text())
groups = collections.OrderedDict()
for n, a in enumerate(c['items']):
    groups.setdefault(a['source_element_id'], []).append((n, a))
if mode == 'counts':
    print(json.dumps({'atomic_count':len(c['items']), 'unique_source_elements':len(groups), 'groups':list(groups)}))
elif mode == 'read':
    for n, (ident, atoms) in enumerate(groups.items()):
        if not lo <= n < hi:
            continue
        print(json.dumps({'group':n, 'source_id':ident, 'line':by_id[ident].line,
                          'actual_raw_projection':by_id[ident].clean(),
                          'atoms':[{'ordinal0':k, **{a:b for a,b in item.items() if a in
                              ['id','disposition','meaning','reason','semantic_slice','source_kind','evidence_class']}}
                              for k,item in atoms]},
                         ensure_ascii=False))
