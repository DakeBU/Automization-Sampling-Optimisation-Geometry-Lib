"""Independently recompute all source-map coordinate systems and span hashes."""
import json,pathlib
from run import ROOT,REPO,sha
I=ROOT/'inputs';E='research-wiki/paper-contributions/GaussianComplexity/source-row-law-semantic-evidence'
m=json.loads((I/E/'source-lean-map.draft.json').read_text())
s=json.loads((I/'research-wiki/paper-contributions/GaussianComplexity/source-row-law-statement-seal.json').read_text())
raw=(REPO/s['source']['raw']).read_bytes();assert sha(raw)==s['source']['raw_sha256']==m['source_sha256']
(I/'paper-source.html').write_bytes(raw)
checks=[];extra={}
def load(path):
    p=I/path
    if not p.exists():
        b=(REPO/path).read_bytes();p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
        extra[path]={'sha256':sha(b),'bytes':len(b)}
    return p.read_bytes()
def check(v,source=False):
    b=raw if source else load(v['path']);t=b.decode();assert '\r' not in t
    if not source:assert sha(b)==v['file_sha256']
    bs,be=(v['raw_utf8_start'],v['raw_utf8_end']) if source else v['raw_UTF8_byte_span']
    cs,ce=(v['char_start'],v['char_end']) if source else v['decoded_char_span']
    part=b[bs:be];assert part.decode()==t[cs:ce]
    assert len(t[:cs].encode())==bs and len(t[:ce].encode())==be
    assert sha(part)==v['span_sha256']
    start=t[:cs].count('\n')+1;end=t[:ce].count('\n')+(0 if t[:ce].endswith('\n') else 1)
    if source:
        assert start==v['lf_line_start'] and end==v['lf_line_end']
        assert cs-(t.rfind('\n',0,cs)+1)==v['lf_column0_start']
        assert 'id="'+v['source_id']+'"' in part.decode()
    else:assert [start,end]==v['LF_lines_1based'],(v['path'],[start,end],v['LF_lines_1based'])
    checks.append({'path':'paper-source.html' if source else v['path'],'source_id':v.get('source_id'),'bytes':[bs,be],'chars':[cs,ce],'LF_lines':[start,end],'span_sha256':sha(part)})
for x in m['mappings']:
    for v in x['source']:check(v,True)
    for v in x['lean']:check(v)
for x in m['proof_background']:
    check(x['source']);check(x['consumer'])
assert m['actual_ASTIS_proof_parents']=={
    'AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumSourceRowLaw.actual_source_row_marginal_law':[],
    '_private.Tests.GaussianComplexityFixedSpectrumSourceRowLaw.0.AutoSamplingTheory.Tests.GaussianComplexityFixedSpectrumSourceRowLaw.actual_original_all_good_cutoff_probability':[
      'AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumSourceRowLaw.actual_source_row_marginal_law',
      'AutoSamplingTheory.TechnicalLemmas.Probability.StdGaussianRadialExponential.integrable_exp_norm_sq_div_three_and_integral_stdGaussian']}
result={'all_coordinates_recomputed':True,'checks':checks,'source_full_sha256':sha(raw),'additional_inputs':extra,'source_map_sha256':sha((I/E/'source-lean-map.draft.json').read_bytes())}
(ROOT/'locator-checks.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'all_spans_checked':len(checks),'source_sha256':sha(raw),'additional_inputs':extra},indent=2))
