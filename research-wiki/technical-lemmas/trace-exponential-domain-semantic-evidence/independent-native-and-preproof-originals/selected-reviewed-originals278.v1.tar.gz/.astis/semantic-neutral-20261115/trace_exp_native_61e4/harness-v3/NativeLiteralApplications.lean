import Tests.GaussianComplexityTraceMgfDomain
import Lean
open MeasureTheory ProbabilityTheory Lean Elab Term
open scoped BigOperators Matrix.Norms.L2Operator MatrixOrder ENNReal
noncomputable section
universe u
elab "native_actual_T" : term => do
  let env ← getEnv
  let found := env.constants.toList.filter fun (n, _) =>
    n.toString.endsWith ".actual_source_four_trace_mgfs_integrable_positive_and_bounded"
  unless found.length == 1 do throwError "Expected unique actual private R16 T, found {found.length}"
  return mkConst found.head!.1
namespace NativeLiteralApplications

theorem literal_P :
∀ {ι : Type u} [Fintype ι] [DecidableEq ι] [Nonempty ι],
  ∀ (A : Matrix ι ι ℝ), A.IsHermitian → ∀ s : ℝ,
    0 < Matrix.trace (NormedSpace.exp (s • A)) ∧
      Matrix.trace (NormedSpace.exp (s • A)) ≤
        (Fintype.card ι : ℝ) * Real.exp (|s| * ‖A‖) := by
  intro ι instF instD instN A hA s
  exact AutoSamplingTheory.TechnicalLemmas.Analysis.MatrixTraceExponentialBounds.trace_exp_pos_and_le_card_mul_exp_abs_mul_norm A hA s

theorem literal_P_explicit_L2_operator :
∀ {ι : Type u} [Fintype ι] [DecidableEq ι] [Nonempty ι],
  ∀ (A : Matrix ι ι ℝ), A.IsHermitian → ∀ s : ℝ,
    0 < Matrix.trace (NormedSpace.exp (s • A)) ∧
      Matrix.trace (NormedSpace.exp (s • A)) ≤
        (Fintype.card ι : ℝ) * Real.exp (|s| * ‖(Matrix.toEuclideanCLM (𝕜 := ℝ) (n := ι)) A‖) := by
  intro ι instF instD instN A hA s
  simpa only [Matrix.cstar_norm_def] using
    AutoSamplingTheory.TechnicalLemmas.Analysis.MatrixTraceExponentialBounds.trace_exp_pos_and_le_card_mul_exp_abs_mul_norm A hA s

theorem literal_T :
∀ {d q : ℕ} (hq : 2 * q + 1 < d),
  let D := EuclideanSpace ℝ (Fin d)
  let E := EuclideanSpace ℝ (Fin (q + 1))
  let Ω := Fin (q + 1) → D
  let μ : Measure Ω := Measure.pi (fun _ : Fin (q + 1) => stdGaussian D)
  let M := Matrix (Fin (q + 1) × Fin (q + 1)) (Fin (q + 1) × Fin (q + 1)) ℝ
  let r : ℝ := ((q + 1 : ℕ) : ℝ)
  let L : ℝ := 2 * r + 3 * Real.log (1000 * (d : ℝ))
  let α : Fin d → ℝ := fun i => ((i.val : ℝ) + 1 - 1 / 2) * Real.pi / (d : ℝ)
  let tvec : Fin d → Fin (q + 1) → ℝ := fun i k =>
    if k.val = 0 then 1 else Real.sqrt 2 * Real.cos ((k.val : ℝ) * α i)
  let row : Fin d → Ω → E := fun i ω =>
    WithLp.toLp 2 (fun b : Fin (q + 1) => ω b i)
  let Y : Fin d → Ω → M := fun i ω =>
    if ‖row i ω‖ ^ 2 ≤ L then
      (d : ℝ)⁻¹ • Matrix.kronecker
        (Matrix.vecMulVec (WithLp.ofLp (row i ω)) (WithLp.ofLp (row i ω)))
        (Matrix.vecMulVec (tvec i) (tvec i))
    else 0
  let mean : Fin d → M := fun i => ∫ ω, Y i ω ∂μ
  let Z : Fin d → Ω → M := fun i ω => Y i ω - mean i
  let w : Bool → Fin d → ℝ := fun useCos i =>
    if useCos = true then Real.cos (((2 * q + 1 : ℕ) : ℝ) * α i) else 1
  let sign : Bool → ℝ := fun minus => if minus = true then -1 else 1
  let S : Bool → Bool → Ω → M := fun useCos minus ω =>
    sign minus • ∑ i : Fin d, w useCos i • Z i ω
  let Rstar : ℝ := 2 * r * (L + 1) / (d : ℝ)
  ∀ s : ℝ, ∀ useCos minus : Bool,
    let f : Ω → ℝ := fun ω => Matrix.trace (NormedSpace.exp (s • S useCos minus ω))
    let B : ℝ := r ^ 2 * Real.exp (|s| * ((d : ℝ) * Rstar))
    Integrable f μ ∧ (∀ ω, 0 < f ω ∧ f ω ≤ B) ∧
      0 < ∫ ω, f ω ∂μ ∧ (∫ ω, f ω ∂μ) ≤ B := by
  intro d q hq
  exact native_actual_T hq

theorem literal_T_q0 {d : ℕ} (hd : 1 < d) :
  let D := EuclideanSpace ℝ (Fin d)
  let E := EuclideanSpace ℝ (Fin (0 + 1))
  let Ω := Fin (0 + 1) → D
  let μ : Measure Ω := Measure.pi (fun _ : Fin (0 + 1) => stdGaussian D)
  let M := Matrix (Fin (0 + 1) × Fin (0 + 1)) (Fin (0 + 1) × Fin (0 + 1)) ℝ
  let r : ℝ := ((0 + 1 : ℕ) : ℝ)
  let L : ℝ := 2 * r + 3 * Real.log (1000 * (d : ℝ))
  let α : Fin d → ℝ := fun i => ((i.val : ℝ) + 1 - 1 / 2) * Real.pi / (d : ℝ)
  let tvec : Fin d → Fin (0 + 1) → ℝ := fun i k =>
    if k.val = 0 then 1 else Real.sqrt 2 * Real.cos ((k.val : ℝ) * α i)
  let row : Fin d → Ω → E := fun i ω =>
    WithLp.toLp 2 (fun b : Fin (0 + 1) => ω b i)
  let Y : Fin d → Ω → M := fun i ω =>
    if ‖row i ω‖ ^ 2 ≤ L then
      (d : ℝ)⁻¹ • Matrix.kronecker
        (Matrix.vecMulVec (WithLp.ofLp (row i ω)) (WithLp.ofLp (row i ω)))
        (Matrix.vecMulVec (tvec i) (tvec i))
    else 0
  let mean : Fin d → M := fun i => ∫ ω, Y i ω ∂μ
  let Z : Fin d → Ω → M := fun i ω => Y i ω - mean i
  let w : Bool → Fin d → ℝ := fun useCos i =>
    if useCos = true then Real.cos (((2 * 0 + 1 : ℕ) : ℝ) * α i) else 1
  let sign : Bool → ℝ := fun minus => if minus = true then -1 else 1
  let S : Bool → Bool → Ω → M := fun useCos minus ω =>
    sign minus • ∑ i : Fin d, w useCos i • Z i ω
  let Rstar : ℝ := 2 * r * (L + 1) / (d : ℝ)
  ∀ s : ℝ, ∀ useCos minus : Bool,
    let f : Ω → ℝ := fun ω => Matrix.trace (NormedSpace.exp (s • S useCos minus ω))
    let B : ℝ := r ^ 2 * Real.exp (|s| * ((d : ℝ) * Rstar))
    Integrable f μ ∧ (∀ ω, 0 < f ω ∧ f ω ≤ B) ∧
      0 < ∫ ω, f ω ∂μ ∧ (∫ ω, f ω ∂μ) ≤ B := by
  exact native_actual_T (d := d) (q := 0) hd

theorem literal_T_q0_d2 :
  let D := EuclideanSpace ℝ (Fin 2)
  let E := EuclideanSpace ℝ (Fin (0 + 1))
  let Ω := Fin (0 + 1) → D
  let μ : Measure Ω := Measure.pi (fun _ : Fin (0 + 1) => stdGaussian D)
  let M := Matrix (Fin (0 + 1) × Fin (0 + 1)) (Fin (0 + 1) × Fin (0 + 1)) ℝ
  let r : ℝ := ((0 + 1 : ℕ) : ℝ)
  let L : ℝ := 2 * r + 3 * Real.log (1000 * (2 : ℝ))
  let α : Fin 2 → ℝ := fun i => ((i.val : ℝ) + 1 - 1 / 2) * Real.pi / (2 : ℝ)
  let tvec : Fin 2 → Fin (0 + 1) → ℝ := fun i k =>
    if k.val = 0 then 1 else Real.sqrt 2 * Real.cos ((k.val : ℝ) * α i)
  let row : Fin 2 → Ω → E := fun i ω =>
    WithLp.toLp 2 (fun b : Fin (0 + 1) => ω b i)
  let Y : Fin 2 → Ω → M := fun i ω =>
    if ‖row i ω‖ ^ 2 ≤ L then
      (2 : ℝ)⁻¹ • Matrix.kronecker
        (Matrix.vecMulVec (WithLp.ofLp (row i ω)) (WithLp.ofLp (row i ω)))
        (Matrix.vecMulVec (tvec i) (tvec i))
    else 0
  let mean : Fin 2 → M := fun i => ∫ ω, Y i ω ∂μ
  let Z : Fin 2 → Ω → M := fun i ω => Y i ω - mean i
  let w : Bool → Fin 2 → ℝ := fun useCos i =>
    if useCos = true then Real.cos (((2 * 0 + 1 : ℕ) : ℝ) * α i) else 1
  let sign : Bool → ℝ := fun minus => if minus = true then -1 else 1
  let S : Bool → Bool → Ω → M := fun useCos minus ω =>
    sign minus • ∑ i : Fin 2, w useCos i • Z i ω
  let Rstar : ℝ := 2 * r * (L + 1) / (2 : ℝ)
  ∀ s : ℝ, ∀ useCos minus : Bool,
    let f : Ω → ℝ := fun ω => Matrix.trace (NormedSpace.exp (s • S useCos minus ω))
    let B : ℝ := r ^ 2 * Real.exp (|s| * ((2 : ℝ) * Rstar))
    Integrable f μ ∧ (∀ ω, 0 < f ω ∧ f ω ≤ B) ∧
      0 < ∫ ω, f ω ∂μ ∧ (∫ ω, f ω ∂μ) ≤ B := by
  exact native_actual_T (d := 2) (q := 0) (by norm_num)

theorem allreal_ordinary_positive :
∀ {d q : ℕ} (hq : 2 * q + 1 < d),
  let D := EuclideanSpace ℝ (Fin d)
  let E := EuclideanSpace ℝ (Fin (q + 1))
  let Ω := Fin (q + 1) → D
  let μ : Measure Ω := Measure.pi (fun _ : Fin (q + 1) => stdGaussian D)
  let M := Matrix (Fin (q + 1) × Fin (q + 1)) (Fin (q + 1) × Fin (q + 1)) ℝ
  let r : ℝ := ((q + 1 : ℕ) : ℝ)
  let L : ℝ := 2 * r + 3 * Real.log (1000 * (d : ℝ))
  let α : Fin d → ℝ := fun i => ((i.val : ℝ) + 1 - 1 / 2) * Real.pi / (d : ℝ)
  let tvec : Fin d → Fin (q + 1) → ℝ := fun i k =>
    if k.val = 0 then 1 else Real.sqrt 2 * Real.cos ((k.val : ℝ) * α i)
  let row : Fin d → Ω → E := fun i ω =>
    WithLp.toLp 2 (fun b : Fin (q + 1) => ω b i)
  let Y : Fin d → Ω → M := fun i ω =>
    if ‖row i ω‖ ^ 2 ≤ L then
      (d : ℝ)⁻¹ • Matrix.kronecker
        (Matrix.vecMulVec (WithLp.ofLp (row i ω)) (WithLp.ofLp (row i ω)))
        (Matrix.vecMulVec (tvec i) (tvec i))
    else 0
  let mean : Fin d → M := fun i => ∫ ω, Y i ω ∂μ
  let Z : Fin d → Ω → M := fun i ω => Y i ω - mean i
  let w : Bool → Fin d → ℝ := fun useCos i =>
    if useCos = true then Real.cos (((2 * q + 1 : ℕ) : ℝ) * α i) else 1
  let sign : Bool → ℝ := fun minus => if minus = true then -1 else 1
  let S : Bool → Bool → Ω → M := fun useCos minus ω =>
    sign minus • ∑ i : Fin d, w useCos i • Z i ω
  let Rstar : ℝ := 2 * r * (L + 1) / (d : ℝ)
  ∀ s : ℝ, let useCos := false; let minus := false;
    let f : Ω → ℝ := fun ω => Matrix.trace (NormedSpace.exp (s • S useCos minus ω))
    let B : ℝ := r ^ 2 * Real.exp (|s| * ((d : ℝ) * Rstar))
    Integrable f μ ∧ (∀ ω, 0 < f ω ∧ f ω ≤ B) ∧
      0 < ∫ ω, f ω ∂μ ∧ (∫ ω, f ω ∂μ) ≤ B := by
  intro d q hq
  dsimp only
  intro s
  exact native_actual_T hq s false false

theorem q0_d2_ordinary_positive_s_zero :
  let D := EuclideanSpace ℝ (Fin 2)
  let E := EuclideanSpace ℝ (Fin (0 + 1))
  let Ω := Fin (0 + 1) → D
  let μ : Measure Ω := Measure.pi (fun _ : Fin (0 + 1) => stdGaussian D)
  let M := Matrix (Fin (0 + 1) × Fin (0 + 1)) (Fin (0 + 1) × Fin (0 + 1)) ℝ
  let r : ℝ := ((0 + 1 : ℕ) : ℝ)
  let L : ℝ := 2 * r + 3 * Real.log (1000 * (2 : ℝ))
  let α : Fin 2 → ℝ := fun i => ((i.val : ℝ) + 1 - 1 / 2) * Real.pi / (2 : ℝ)
  let tvec : Fin 2 → Fin (0 + 1) → ℝ := fun i k =>
    if k.val = 0 then 1 else Real.sqrt 2 * Real.cos ((k.val : ℝ) * α i)
  let row : Fin 2 → Ω → E := fun i ω =>
    WithLp.toLp 2 (fun b : Fin (0 + 1) => ω b i)
  let Y : Fin 2 → Ω → M := fun i ω =>
    if ‖row i ω‖ ^ 2 ≤ L then
      (2 : ℝ)⁻¹ • Matrix.kronecker
        (Matrix.vecMulVec (WithLp.ofLp (row i ω)) (WithLp.ofLp (row i ω)))
        (Matrix.vecMulVec (tvec i) (tvec i))
    else 0
  let mean : Fin 2 → M := fun i => ∫ ω, Y i ω ∂μ
  let Z : Fin 2 → Ω → M := fun i ω => Y i ω - mean i
  let w : Bool → Fin 2 → ℝ := fun useCos i =>
    if useCos = true then Real.cos (((2 * 0 + 1 : ℕ) : ℝ) * α i) else 1
  let sign : Bool → ℝ := fun minus => if minus = true then -1 else 1
  let S : Bool → Bool → Ω → M := fun useCos minus ω =>
    sign minus • ∑ i : Fin 2, w useCos i • Z i ω
  let Rstar : ℝ := 2 * r * (L + 1) / (2 : ℝ)
  let s : ℝ := 0; let useCos := false; let minus := false;
    let f : Ω → ℝ := fun ω => Matrix.trace (NormedSpace.exp (s • S useCos minus ω))
    let B : ℝ := r ^ 2 * Real.exp (|s| * ((2 : ℝ) * Rstar))
    Integrable f μ ∧ (∀ ω, 0 < f ω ∧ f ω ≤ B) ∧
      0 < ∫ ω, f ω ∂μ ∧ (∫ ω, f ω ∂μ) ≤ B := by
  exact native_actual_T (d := 2) (q := 0) (by norm_num) 0 false false

theorem q0_d2_ordinary_positive_s_negative :
  let D := EuclideanSpace ℝ (Fin 2)
  let E := EuclideanSpace ℝ (Fin (0 + 1))
  let Ω := Fin (0 + 1) → D
  let μ : Measure Ω := Measure.pi (fun _ : Fin (0 + 1) => stdGaussian D)
  let M := Matrix (Fin (0 + 1) × Fin (0 + 1)) (Fin (0 + 1) × Fin (0 + 1)) ℝ
  let r : ℝ := ((0 + 1 : ℕ) : ℝ)
  let L : ℝ := 2 * r + 3 * Real.log (1000 * (2 : ℝ))
  let α : Fin 2 → ℝ := fun i => ((i.val : ℝ) + 1 - 1 / 2) * Real.pi / (2 : ℝ)
  let tvec : Fin 2 → Fin (0 + 1) → ℝ := fun i k =>
    if k.val = 0 then 1 else Real.sqrt 2 * Real.cos ((k.val : ℝ) * α i)
  let row : Fin 2 → Ω → E := fun i ω =>
    WithLp.toLp 2 (fun b : Fin (0 + 1) => ω b i)
  let Y : Fin 2 → Ω → M := fun i ω =>
    if ‖row i ω‖ ^ 2 ≤ L then
      (2 : ℝ)⁻¹ • Matrix.kronecker
        (Matrix.vecMulVec (WithLp.ofLp (row i ω)) (WithLp.ofLp (row i ω)))
        (Matrix.vecMulVec (tvec i) (tvec i))
    else 0
  let mean : Fin 2 → M := fun i => ∫ ω, Y i ω ∂μ
  let Z : Fin 2 → Ω → M := fun i ω => Y i ω - mean i
  let w : Bool → Fin 2 → ℝ := fun useCos i =>
    if useCos = true then Real.cos (((2 * 0 + 1 : ℕ) : ℝ) * α i) else 1
  let sign : Bool → ℝ := fun minus => if minus = true then -1 else 1
  let S : Bool → Bool → Ω → M := fun useCos minus ω =>
    sign minus • ∑ i : Fin 2, w useCos i • Z i ω
  let Rstar : ℝ := 2 * r * (L + 1) / (2 : ℝ)
  let s : ℝ := (-1); let useCos := false; let minus := false;
    let f : Ω → ℝ := fun ω => Matrix.trace (NormedSpace.exp (s • S useCos minus ω))
    let B : ℝ := r ^ 2 * Real.exp (|s| * ((2 : ℝ) * Rstar))
    Integrable f μ ∧ (∀ ω, 0 < f ω ∧ f ω ≤ B) ∧
      0 < ∫ ω, f ω ∂μ ∧ (∫ ω, f ω ∂μ) ≤ B := by
  exact native_actual_T (d := 2) (q := 0) (by norm_num) (-1) false false

theorem q0_d2_ordinary_positive_s_positive :
  let D := EuclideanSpace ℝ (Fin 2)
  let E := EuclideanSpace ℝ (Fin (0 + 1))
  let Ω := Fin (0 + 1) → D
  let μ : Measure Ω := Measure.pi (fun _ : Fin (0 + 1) => stdGaussian D)
  let M := Matrix (Fin (0 + 1) × Fin (0 + 1)) (Fin (0 + 1) × Fin (0 + 1)) ℝ
  let r : ℝ := ((0 + 1 : ℕ) : ℝ)
  let L : ℝ := 2 * r + 3 * Real.log (1000 * (2 : ℝ))
  let α : Fin 2 → ℝ := fun i => ((i.val : ℝ) + 1 - 1 / 2) * Real.pi / (2 : ℝ)
  let tvec : Fin 2 → Fin (0 + 1) → ℝ := fun i k =>
    if k.val = 0 then 1 else Real.sqrt 2 * Real.cos ((k.val : ℝ) * α i)
  let row : Fin 2 → Ω → E := fun i ω =>
    WithLp.toLp 2 (fun b : Fin (0 + 1) => ω b i)
  let Y : Fin 2 → Ω → M := fun i ω =>
    if ‖row i ω‖ ^ 2 ≤ L then
      (2 : ℝ)⁻¹ • Matrix.kronecker
        (Matrix.vecMulVec (WithLp.ofLp (row i ω)) (WithLp.ofLp (row i ω)))
        (Matrix.vecMulVec (tvec i) (tvec i))
    else 0
  let mean : Fin 2 → M := fun i => ∫ ω, Y i ω ∂μ
  let Z : Fin 2 → Ω → M := fun i ω => Y i ω - mean i
  let w : Bool → Fin 2 → ℝ := fun useCos i =>
    if useCos = true then Real.cos (((2 * 0 + 1 : ℕ) : ℝ) * α i) else 1
  let sign : Bool → ℝ := fun minus => if minus = true then -1 else 1
  let S : Bool → Bool → Ω → M := fun useCos minus ω =>
    sign minus • ∑ i : Fin 2, w useCos i • Z i ω
  let Rstar : ℝ := 2 * r * (L + 1) / (2 : ℝ)
  let s : ℝ := 1; let useCos := false; let minus := false;
    let f : Ω → ℝ := fun ω => Matrix.trace (NormedSpace.exp (s • S useCos minus ω))
    let B : ℝ := r ^ 2 * Real.exp (|s| * ((2 : ℝ) * Rstar))
    Integrable f μ ∧ (∀ ω, 0 < f ω ∧ f ω ≤ B) ∧
      0 < ∫ ω, f ω ∂μ ∧ (∫ ω, f ω ∂μ) ≤ B := by
  exact native_actual_T (d := 2) (q := 0) (by norm_num) 1 false false

theorem allreal_ordinary_negative :
∀ {d q : ℕ} (hq : 2 * q + 1 < d),
  let D := EuclideanSpace ℝ (Fin d)
  let E := EuclideanSpace ℝ (Fin (q + 1))
  let Ω := Fin (q + 1) → D
  let μ : Measure Ω := Measure.pi (fun _ : Fin (q + 1) => stdGaussian D)
  let M := Matrix (Fin (q + 1) × Fin (q + 1)) (Fin (q + 1) × Fin (q + 1)) ℝ
  let r : ℝ := ((q + 1 : ℕ) : ℝ)
  let L : ℝ := 2 * r + 3 * Real.log (1000 * (d : ℝ))
  let α : Fin d → ℝ := fun i => ((i.val : ℝ) + 1 - 1 / 2) * Real.pi / (d : ℝ)
  let tvec : Fin d → Fin (q + 1) → ℝ := fun i k =>
    if k.val = 0 then 1 else Real.sqrt 2 * Real.cos ((k.val : ℝ) * α i)
  let row : Fin d → Ω → E := fun i ω =>
    WithLp.toLp 2 (fun b : Fin (q + 1) => ω b i)
  let Y : Fin d → Ω → M := fun i ω =>
    if ‖row i ω‖ ^ 2 ≤ L then
      (d : ℝ)⁻¹ • Matrix.kronecker
        (Matrix.vecMulVec (WithLp.ofLp (row i ω)) (WithLp.ofLp (row i ω)))
        (Matrix.vecMulVec (tvec i) (tvec i))
    else 0
  let mean : Fin d → M := fun i => ∫ ω, Y i ω ∂μ
  let Z : Fin d → Ω → M := fun i ω => Y i ω - mean i
  let w : Bool → Fin d → ℝ := fun useCos i =>
    if useCos = true then Real.cos (((2 * q + 1 : ℕ) : ℝ) * α i) else 1
  let sign : Bool → ℝ := fun minus => if minus = true then -1 else 1
  let S : Bool → Bool → Ω → M := fun useCos minus ω =>
    sign minus • ∑ i : Fin d, w useCos i • Z i ω
  let Rstar : ℝ := 2 * r * (L + 1) / (d : ℝ)
  ∀ s : ℝ, let useCos := false; let minus := true;
    let f : Ω → ℝ := fun ω => Matrix.trace (NormedSpace.exp (s • S useCos minus ω))
    let B : ℝ := r ^ 2 * Real.exp (|s| * ((d : ℝ) * Rstar))
    Integrable f μ ∧ (∀ ω, 0 < f ω ∧ f ω ≤ B) ∧
      0 < ∫ ω, f ω ∂μ ∧ (∫ ω, f ω ∂μ) ≤ B := by
  intro d q hq
  dsimp only
  intro s
  exact native_actual_T hq s false true

theorem q0_d2_ordinary_negative_s_zero :
  let D := EuclideanSpace ℝ (Fin 2)
  let E := EuclideanSpace ℝ (Fin (0 + 1))
  let Ω := Fin (0 + 1) → D
  let μ : Measure Ω := Measure.pi (fun _ : Fin (0 + 1) => stdGaussian D)
  let M := Matrix (Fin (0 + 1) × Fin (0 + 1)) (Fin (0 + 1) × Fin (0 + 1)) ℝ
  let r : ℝ := ((0 + 1 : ℕ) : ℝ)
  let L : ℝ := 2 * r + 3 * Real.log (1000 * (2 : ℝ))
  let α : Fin 2 → ℝ := fun i => ((i.val : ℝ) + 1 - 1 / 2) * Real.pi / (2 : ℝ)
  let tvec : Fin 2 → Fin (0 + 1) → ℝ := fun i k =>
    if k.val = 0 then 1 else Real.sqrt 2 * Real.cos ((k.val : ℝ) * α i)
  let row : Fin 2 → Ω → E := fun i ω =>
    WithLp.toLp 2 (fun b : Fin (0 + 1) => ω b i)
  let Y : Fin 2 → Ω → M := fun i ω =>
    if ‖row i ω‖ ^ 2 ≤ L then
      (2 : ℝ)⁻¹ • Matrix.kronecker
        (Matrix.vecMulVec (WithLp.ofLp (row i ω)) (WithLp.ofLp (row i ω)))
        (Matrix.vecMulVec (tvec i) (tvec i))
    else 0
  let mean : Fin 2 → M := fun i => ∫ ω, Y i ω ∂μ
  let Z : Fin 2 → Ω → M := fun i ω => Y i ω - mean i
  let w : Bool → Fin 2 → ℝ := fun useCos i =>
    if useCos = true then Real.cos (((2 * 0 + 1 : ℕ) : ℝ) * α i) else 1
  let sign : Bool → ℝ := fun minus => if minus = true then -1 else 1
  let S : Bool → Bool → Ω → M := fun useCos minus ω =>
    sign minus • ∑ i : Fin 2, w useCos i • Z i ω
  let Rstar : ℝ := 2 * r * (L + 1) / (2 : ℝ)
  let s : ℝ := 0; let useCos := false; let minus := true;
    let f : Ω → ℝ := fun ω => Matrix.trace (NormedSpace.exp (s • S useCos minus ω))
    let B : ℝ := r ^ 2 * Real.exp (|s| * ((2 : ℝ) * Rstar))
    Integrable f μ ∧ (∀ ω, 0 < f ω ∧ f ω ≤ B) ∧
      0 < ∫ ω, f ω ∂μ ∧ (∫ ω, f ω ∂μ) ≤ B := by
  exact native_actual_T (d := 2) (q := 0) (by norm_num) 0 false true

theorem q0_d2_ordinary_negative_s_negative :
  let D := EuclideanSpace ℝ (Fin 2)
  let E := EuclideanSpace ℝ (Fin (0 + 1))
  let Ω := Fin (0 + 1) → D
  let μ : Measure Ω := Measure.pi (fun _ : Fin (0 + 1) => stdGaussian D)
  let M := Matrix (Fin (0 + 1) × Fin (0 + 1)) (Fin (0 + 1) × Fin (0 + 1)) ℝ
  let r : ℝ := ((0 + 1 : ℕ) : ℝ)
  let L : ℝ := 2 * r + 3 * Real.log (1000 * (2 : ℝ))
  let α : Fin 2 → ℝ := fun i => ((i.val : ℝ) + 1 - 1 / 2) * Real.pi / (2 : ℝ)
  let tvec : Fin 2 → Fin (0 + 1) → ℝ := fun i k =>
    if k.val = 0 then 1 else Real.sqrt 2 * Real.cos ((k.val : ℝ) * α i)
  let row : Fin 2 → Ω → E := fun i ω =>
    WithLp.toLp 2 (fun b : Fin (0 + 1) => ω b i)
  let Y : Fin 2 → Ω → M := fun i ω =>
    if ‖row i ω‖ ^ 2 ≤ L then
      (2 : ℝ)⁻¹ • Matrix.kronecker
        (Matrix.vecMulVec (WithLp.ofLp (row i ω)) (WithLp.ofLp (row i ω)))
        (Matrix.vecMulVec (tvec i) (tvec i))
    else 0
  let mean : Fin 2 → M := fun i => ∫ ω, Y i ω ∂μ
  let Z : Fin 2 → Ω → M := fun i ω => Y i ω - mean i
  let w : Bool → Fin 2 → ℝ := fun useCos i =>
    if useCos = true then Real.cos (((2 * 0 + 1 : ℕ) : ℝ) * α i) else 1
  let sign : Bool → ℝ := fun minus => if minus = true then -1 else 1
  let S : Bool → Bool → Ω → M := fun useCos minus ω =>
    sign minus • ∑ i : Fin 2, w useCos i • Z i ω
  let Rstar : ℝ := 2 * r * (L + 1) / (2 : ℝ)
  let s : ℝ := (-1); let useCos := false; let minus := true;
    let f : Ω → ℝ := fun ω => Matrix.trace (NormedSpace.exp (s • S useCos minus ω))
    let B : ℝ := r ^ 2 * Real.exp (|s| * ((2 : ℝ) * Rstar))
    Integrable f μ ∧ (∀ ω, 0 < f ω ∧ f ω ≤ B) ∧
      0 < ∫ ω, f ω ∂μ ∧ (∫ ω, f ω ∂μ) ≤ B := by
  exact native_actual_T (d := 2) (q := 0) (by norm_num) (-1) false true

theorem q0_d2_ordinary_negative_s_positive :
  let D := EuclideanSpace ℝ (Fin 2)
  let E := EuclideanSpace ℝ (Fin (0 + 1))
  let Ω := Fin (0 + 1) → D
  let μ : Measure Ω := Measure.pi (fun _ : Fin (0 + 1) => stdGaussian D)
  let M := Matrix (Fin (0 + 1) × Fin (0 + 1)) (Fin (0 + 1) × Fin (0 + 1)) ℝ
  let r : ℝ := ((0 + 1 : ℕ) : ℝ)
  let L : ℝ := 2 * r + 3 * Real.log (1000 * (2 : ℝ))
  let α : Fin 2 → ℝ := fun i => ((i.val : ℝ) + 1 - 1 / 2) * Real.pi / (2 : ℝ)
  let tvec : Fin 2 → Fin (0 + 1) → ℝ := fun i k =>
    if k.val = 0 then 1 else Real.sqrt 2 * Real.cos ((k.val : ℝ) * α i)
  let row : Fin 2 → Ω → E := fun i ω =>
    WithLp.toLp 2 (fun b : Fin (0 + 1) => ω b i)
  let Y : Fin 2 → Ω → M := fun i ω =>
    if ‖row i ω‖ ^ 2 ≤ L then
      (2 : ℝ)⁻¹ • Matrix.kronecker
        (Matrix.vecMulVec (WithLp.ofLp (row i ω)) (WithLp.ofLp (row i ω)))
        (Matrix.vecMulVec (tvec i) (tvec i))
    else 0
  let mean : Fin 2 → M := fun i => ∫ ω, Y i ω ∂μ
  let Z : Fin 2 → Ω → M := fun i ω => Y i ω - mean i
  let w : Bool → Fin 2 → ℝ := fun useCos i =>
    if useCos = true then Real.cos (((2 * 0 + 1 : ℕ) : ℝ) * α i) else 1
  let sign : Bool → ℝ := fun minus => if minus = true then -1 else 1
  let S : Bool → Bool → Ω → M := fun useCos minus ω =>
    sign minus • ∑ i : Fin 2, w useCos i • Z i ω
  let Rstar : ℝ := 2 * r * (L + 1) / (2 : ℝ)
  let s : ℝ := 1; let useCos := false; let minus := true;
    let f : Ω → ℝ := fun ω => Matrix.trace (NormedSpace.exp (s • S useCos minus ω))
    let B : ℝ := r ^ 2 * Real.exp (|s| * ((2 : ℝ) * Rstar))
    Integrable f μ ∧ (∀ ω, 0 < f ω ∧ f ω ≤ B) ∧
      0 < ∫ ω, f ω ∂μ ∧ (∫ ω, f ω ∂μ) ≤ B := by
  exact native_actual_T (d := 2) (q := 0) (by norm_num) 1 false true

theorem allreal_cos_positive :
∀ {d q : ℕ} (hq : 2 * q + 1 < d),
  let D := EuclideanSpace ℝ (Fin d)
  let E := EuclideanSpace ℝ (Fin (q + 1))
  let Ω := Fin (q + 1) → D
  let μ : Measure Ω := Measure.pi (fun _ : Fin (q + 1) => stdGaussian D)
  let M := Matrix (Fin (q + 1) × Fin (q + 1)) (Fin (q + 1) × Fin (q + 1)) ℝ
  let r : ℝ := ((q + 1 : ℕ) : ℝ)
  let L : ℝ := 2 * r + 3 * Real.log (1000 * (d : ℝ))
  let α : Fin d → ℝ := fun i => ((i.val : ℝ) + 1 - 1 / 2) * Real.pi / (d : ℝ)
  let tvec : Fin d → Fin (q + 1) → ℝ := fun i k =>
    if k.val = 0 then 1 else Real.sqrt 2 * Real.cos ((k.val : ℝ) * α i)
  let row : Fin d → Ω → E := fun i ω =>
    WithLp.toLp 2 (fun b : Fin (q + 1) => ω b i)
  let Y : Fin d → Ω → M := fun i ω =>
    if ‖row i ω‖ ^ 2 ≤ L then
      (d : ℝ)⁻¹ • Matrix.kronecker
        (Matrix.vecMulVec (WithLp.ofLp (row i ω)) (WithLp.ofLp (row i ω)))
        (Matrix.vecMulVec (tvec i) (tvec i))
    else 0
  let mean : Fin d → M := fun i => ∫ ω, Y i ω ∂μ
  let Z : Fin d → Ω → M := fun i ω => Y i ω - mean i
  let w : Bool → Fin d → ℝ := fun useCos i =>
    if useCos = true then Real.cos (((2 * q + 1 : ℕ) : ℝ) * α i) else 1
  let sign : Bool → ℝ := fun minus => if minus = true then -1 else 1
  let S : Bool → Bool → Ω → M := fun useCos minus ω =>
    sign minus • ∑ i : Fin d, w useCos i • Z i ω
  let Rstar : ℝ := 2 * r * (L + 1) / (d : ℝ)
  ∀ s : ℝ, let useCos := true; let minus := false;
    let f : Ω → ℝ := fun ω => Matrix.trace (NormedSpace.exp (s • S useCos minus ω))
    let B : ℝ := r ^ 2 * Real.exp (|s| * ((d : ℝ) * Rstar))
    Integrable f μ ∧ (∀ ω, 0 < f ω ∧ f ω ≤ B) ∧
      0 < ∫ ω, f ω ∂μ ∧ (∫ ω, f ω ∂μ) ≤ B := by
  intro d q hq
  dsimp only
  intro s
  exact native_actual_T hq s true false

theorem q0_d2_cos_positive_s_zero :
  let D := EuclideanSpace ℝ (Fin 2)
  let E := EuclideanSpace ℝ (Fin (0 + 1))
  let Ω := Fin (0 + 1) → D
  let μ : Measure Ω := Measure.pi (fun _ : Fin (0 + 1) => stdGaussian D)
  let M := Matrix (Fin (0 + 1) × Fin (0 + 1)) (Fin (0 + 1) × Fin (0 + 1)) ℝ
  let r : ℝ := ((0 + 1 : ℕ) : ℝ)
  let L : ℝ := 2 * r + 3 * Real.log (1000 * (2 : ℝ))
  let α : Fin 2 → ℝ := fun i => ((i.val : ℝ) + 1 - 1 / 2) * Real.pi / (2 : ℝ)
  let tvec : Fin 2 → Fin (0 + 1) → ℝ := fun i k =>
    if k.val = 0 then 1 else Real.sqrt 2 * Real.cos ((k.val : ℝ) * α i)
  let row : Fin 2 → Ω → E := fun i ω =>
    WithLp.toLp 2 (fun b : Fin (0 + 1) => ω b i)
  let Y : Fin 2 → Ω → M := fun i ω =>
    if ‖row i ω‖ ^ 2 ≤ L then
      (2 : ℝ)⁻¹ • Matrix.kronecker
        (Matrix.vecMulVec (WithLp.ofLp (row i ω)) (WithLp.ofLp (row i ω)))
        (Matrix.vecMulVec (tvec i) (tvec i))
    else 0
  let mean : Fin 2 → M := fun i => ∫ ω, Y i ω ∂μ
  let Z : Fin 2 → Ω → M := fun i ω => Y i ω - mean i
  let w : Bool → Fin 2 → ℝ := fun useCos i =>
    if useCos = true then Real.cos (((2 * 0 + 1 : ℕ) : ℝ) * α i) else 1
  let sign : Bool → ℝ := fun minus => if minus = true then -1 else 1
  let S : Bool → Bool → Ω → M := fun useCos minus ω =>
    sign minus • ∑ i : Fin 2, w useCos i • Z i ω
  let Rstar : ℝ := 2 * r * (L + 1) / (2 : ℝ)
  let s : ℝ := 0; let useCos := true; let minus := false;
    let f : Ω → ℝ := fun ω => Matrix.trace (NormedSpace.exp (s • S useCos minus ω))
    let B : ℝ := r ^ 2 * Real.exp (|s| * ((2 : ℝ) * Rstar))
    Integrable f μ ∧ (∀ ω, 0 < f ω ∧ f ω ≤ B) ∧
      0 < ∫ ω, f ω ∂μ ∧ (∫ ω, f ω ∂μ) ≤ B := by
  exact native_actual_T (d := 2) (q := 0) (by norm_num) 0 true false

theorem q0_d2_cos_positive_s_negative :
  let D := EuclideanSpace ℝ (Fin 2)
  let E := EuclideanSpace ℝ (Fin (0 + 1))
  let Ω := Fin (0 + 1) → D
  let μ : Measure Ω := Measure.pi (fun _ : Fin (0 + 1) => stdGaussian D)
  let M := Matrix (Fin (0 + 1) × Fin (0 + 1)) (Fin (0 + 1) × Fin (0 + 1)) ℝ
  let r : ℝ := ((0 + 1 : ℕ) : ℝ)
  let L : ℝ := 2 * r + 3 * Real.log (1000 * (2 : ℝ))
  let α : Fin 2 → ℝ := fun i => ((i.val : ℝ) + 1 - 1 / 2) * Real.pi / (2 : ℝ)
  let tvec : Fin 2 → Fin (0 + 1) → ℝ := fun i k =>
    if k.val = 0 then 1 else Real.sqrt 2 * Real.cos ((k.val : ℝ) * α i)
  let row : Fin 2 → Ω → E := fun i ω =>
    WithLp.toLp 2 (fun b : Fin (0 + 1) => ω b i)
  let Y : Fin 2 → Ω → M := fun i ω =>
    if ‖row i ω‖ ^ 2 ≤ L then
      (2 : ℝ)⁻¹ • Matrix.kronecker
        (Matrix.vecMulVec (WithLp.ofLp (row i ω)) (WithLp.ofLp (row i ω)))
        (Matrix.vecMulVec (tvec i) (tvec i))
    else 0
  let mean : Fin 2 → M := fun i => ∫ ω, Y i ω ∂μ
  let Z : Fin 2 → Ω → M := fun i ω => Y i ω - mean i
  let w : Bool → Fin 2 → ℝ := fun useCos i =>
    if useCos = true then Real.cos (((2 * 0 + 1 : ℕ) : ℝ) * α i) else 1
  let sign : Bool → ℝ := fun minus => if minus = true then -1 else 1
  let S : Bool → Bool → Ω → M := fun useCos minus ω =>
    sign minus • ∑ i : Fin 2, w useCos i • Z i ω
  let Rstar : ℝ := 2 * r * (L + 1) / (2 : ℝ)
  let s : ℝ := (-1); let useCos := true; let minus := false;
    let f : Ω → ℝ := fun ω => Matrix.trace (NormedSpace.exp (s • S useCos minus ω))
    let B : ℝ := r ^ 2 * Real.exp (|s| * ((2 : ℝ) * Rstar))
    Integrable f μ ∧ (∀ ω, 0 < f ω ∧ f ω ≤ B) ∧
      0 < ∫ ω, f ω ∂μ ∧ (∫ ω, f ω ∂μ) ≤ B := by
  exact native_actual_T (d := 2) (q := 0) (by norm_num) (-1) true false

theorem q0_d2_cos_positive_s_positive :
  let D := EuclideanSpace ℝ (Fin 2)
  let E := EuclideanSpace ℝ (Fin (0 + 1))
  let Ω := Fin (0 + 1) → D
  let μ : Measure Ω := Measure.pi (fun _ : Fin (0 + 1) => stdGaussian D)
  let M := Matrix (Fin (0 + 1) × Fin (0 + 1)) (Fin (0 + 1) × Fin (0 + 1)) ℝ
  let r : ℝ := ((0 + 1 : ℕ) : ℝ)
  let L : ℝ := 2 * r + 3 * Real.log (1000 * (2 : ℝ))
  let α : Fin 2 → ℝ := fun i => ((i.val : ℝ) + 1 - 1 / 2) * Real.pi / (2 : ℝ)
  let tvec : Fin 2 → Fin (0 + 1) → ℝ := fun i k =>
    if k.val = 0 then 1 else Real.sqrt 2 * Real.cos ((k.val : ℝ) * α i)
  let row : Fin 2 → Ω → E := fun i ω =>
    WithLp.toLp 2 (fun b : Fin (0 + 1) => ω b i)
  let Y : Fin 2 → Ω → M := fun i ω =>
    if ‖row i ω‖ ^ 2 ≤ L then
      (2 : ℝ)⁻¹ • Matrix.kronecker
        (Matrix.vecMulVec (WithLp.ofLp (row i ω)) (WithLp.ofLp (row i ω)))
        (Matrix.vecMulVec (tvec i) (tvec i))
    else 0
  let mean : Fin 2 → M := fun i => ∫ ω, Y i ω ∂μ
  let Z : Fin 2 → Ω → M := fun i ω => Y i ω - mean i
  let w : Bool → Fin 2 → ℝ := fun useCos i =>
    if useCos = true then Real.cos (((2 * 0 + 1 : ℕ) : ℝ) * α i) else 1
  let sign : Bool → ℝ := fun minus => if minus = true then -1 else 1
  let S : Bool → Bool → Ω → M := fun useCos minus ω =>
    sign minus • ∑ i : Fin 2, w useCos i • Z i ω
  let Rstar : ℝ := 2 * r * (L + 1) / (2 : ℝ)
  let s : ℝ := 1; let useCos := true; let minus := false;
    let f : Ω → ℝ := fun ω => Matrix.trace (NormedSpace.exp (s • S useCos minus ω))
    let B : ℝ := r ^ 2 * Real.exp (|s| * ((2 : ℝ) * Rstar))
    Integrable f μ ∧ (∀ ω, 0 < f ω ∧ f ω ≤ B) ∧
      0 < ∫ ω, f ω ∂μ ∧ (∫ ω, f ω ∂μ) ≤ B := by
  exact native_actual_T (d := 2) (q := 0) (by norm_num) 1 true false

theorem allreal_cos_negative :
∀ {d q : ℕ} (hq : 2 * q + 1 < d),
  let D := EuclideanSpace ℝ (Fin d)
  let E := EuclideanSpace ℝ (Fin (q + 1))
  let Ω := Fin (q + 1) → D
  let μ : Measure Ω := Measure.pi (fun _ : Fin (q + 1) => stdGaussian D)
  let M := Matrix (Fin (q + 1) × Fin (q + 1)) (Fin (q + 1) × Fin (q + 1)) ℝ
  let r : ℝ := ((q + 1 : ℕ) : ℝ)
  let L : ℝ := 2 * r + 3 * Real.log (1000 * (d : ℝ))
  let α : Fin d → ℝ := fun i => ((i.val : ℝ) + 1 - 1 / 2) * Real.pi / (d : ℝ)
  let tvec : Fin d → Fin (q + 1) → ℝ := fun i k =>
    if k.val = 0 then 1 else Real.sqrt 2 * Real.cos ((k.val : ℝ) * α i)
  let row : Fin d → Ω → E := fun i ω =>
    WithLp.toLp 2 (fun b : Fin (q + 1) => ω b i)
  let Y : Fin d → Ω → M := fun i ω =>
    if ‖row i ω‖ ^ 2 ≤ L then
      (d : ℝ)⁻¹ • Matrix.kronecker
        (Matrix.vecMulVec (WithLp.ofLp (row i ω)) (WithLp.ofLp (row i ω)))
        (Matrix.vecMulVec (tvec i) (tvec i))
    else 0
  let mean : Fin d → M := fun i => ∫ ω, Y i ω ∂μ
  let Z : Fin d → Ω → M := fun i ω => Y i ω - mean i
  let w : Bool → Fin d → ℝ := fun useCos i =>
    if useCos = true then Real.cos (((2 * q + 1 : ℕ) : ℝ) * α i) else 1
  let sign : Bool → ℝ := fun minus => if minus = true then -1 else 1
  let S : Bool → Bool → Ω → M := fun useCos minus ω =>
    sign minus • ∑ i : Fin d, w useCos i • Z i ω
  let Rstar : ℝ := 2 * r * (L + 1) / (d : ℝ)
  ∀ s : ℝ, let useCos := true; let minus := true;
    let f : Ω → ℝ := fun ω => Matrix.trace (NormedSpace.exp (s • S useCos minus ω))
    let B : ℝ := r ^ 2 * Real.exp (|s| * ((d : ℝ) * Rstar))
    Integrable f μ ∧ (∀ ω, 0 < f ω ∧ f ω ≤ B) ∧
      0 < ∫ ω, f ω ∂μ ∧ (∫ ω, f ω ∂μ) ≤ B := by
  intro d q hq
  dsimp only
  intro s
  exact native_actual_T hq s true true

theorem q0_d2_cos_negative_s_zero :
  let D := EuclideanSpace ℝ (Fin 2)
  let E := EuclideanSpace ℝ (Fin (0 + 1))
  let Ω := Fin (0 + 1) → D
  let μ : Measure Ω := Measure.pi (fun _ : Fin (0 + 1) => stdGaussian D)
  let M := Matrix (Fin (0 + 1) × Fin (0 + 1)) (Fin (0 + 1) × Fin (0 + 1)) ℝ
  let r : ℝ := ((0 + 1 : ℕ) : ℝ)
  let L : ℝ := 2 * r + 3 * Real.log (1000 * (2 : ℝ))
  let α : Fin 2 → ℝ := fun i => ((i.val : ℝ) + 1 - 1 / 2) * Real.pi / (2 : ℝ)
  let tvec : Fin 2 → Fin (0 + 1) → ℝ := fun i k =>
    if k.val = 0 then 1 else Real.sqrt 2 * Real.cos ((k.val : ℝ) * α i)
  let row : Fin 2 → Ω → E := fun i ω =>
    WithLp.toLp 2 (fun b : Fin (0 + 1) => ω b i)
  let Y : Fin 2 → Ω → M := fun i ω =>
    if ‖row i ω‖ ^ 2 ≤ L then
      (2 : ℝ)⁻¹ • Matrix.kronecker
        (Matrix.vecMulVec (WithLp.ofLp (row i ω)) (WithLp.ofLp (row i ω)))
        (Matrix.vecMulVec (tvec i) (tvec i))
    else 0
  let mean : Fin 2 → M := fun i => ∫ ω, Y i ω ∂μ
  let Z : Fin 2 → Ω → M := fun i ω => Y i ω - mean i
  let w : Bool → Fin 2 → ℝ := fun useCos i =>
    if useCos = true then Real.cos (((2 * 0 + 1 : ℕ) : ℝ) * α i) else 1
  let sign : Bool → ℝ := fun minus => if minus = true then -1 else 1
  let S : Bool → Bool → Ω → M := fun useCos minus ω =>
    sign minus • ∑ i : Fin 2, w useCos i • Z i ω
  let Rstar : ℝ := 2 * r * (L + 1) / (2 : ℝ)
  let s : ℝ := 0; let useCos := true; let minus := true;
    let f : Ω → ℝ := fun ω => Matrix.trace (NormedSpace.exp (s • S useCos minus ω))
    let B : ℝ := r ^ 2 * Real.exp (|s| * ((2 : ℝ) * Rstar))
    Integrable f μ ∧ (∀ ω, 0 < f ω ∧ f ω ≤ B) ∧
      0 < ∫ ω, f ω ∂μ ∧ (∫ ω, f ω ∂μ) ≤ B := by
  exact native_actual_T (d := 2) (q := 0) (by norm_num) 0 true true

theorem q0_d2_cos_negative_s_negative :
  let D := EuclideanSpace ℝ (Fin 2)
  let E := EuclideanSpace ℝ (Fin (0 + 1))
  let Ω := Fin (0 + 1) → D
  let μ : Measure Ω := Measure.pi (fun _ : Fin (0 + 1) => stdGaussian D)
  let M := Matrix (Fin (0 + 1) × Fin (0 + 1)) (Fin (0 + 1) × Fin (0 + 1)) ℝ
  let r : ℝ := ((0 + 1 : ℕ) : ℝ)
  let L : ℝ := 2 * r + 3 * Real.log (1000 * (2 : ℝ))
  let α : Fin 2 → ℝ := fun i => ((i.val : ℝ) + 1 - 1 / 2) * Real.pi / (2 : ℝ)
  let tvec : Fin 2 → Fin (0 + 1) → ℝ := fun i k =>
    if k.val = 0 then 1 else Real.sqrt 2 * Real.cos ((k.val : ℝ) * α i)
  let row : Fin 2 → Ω → E := fun i ω =>
    WithLp.toLp 2 (fun b : Fin (0 + 1) => ω b i)
  let Y : Fin 2 → Ω → M := fun i ω =>
    if ‖row i ω‖ ^ 2 ≤ L then
      (2 : ℝ)⁻¹ • Matrix.kronecker
        (Matrix.vecMulVec (WithLp.ofLp (row i ω)) (WithLp.ofLp (row i ω)))
        (Matrix.vecMulVec (tvec i) (tvec i))
    else 0
  let mean : Fin 2 → M := fun i => ∫ ω, Y i ω ∂μ
  let Z : Fin 2 → Ω → M := fun i ω => Y i ω - mean i
  let w : Bool → Fin 2 → ℝ := fun useCos i =>
    if useCos = true then Real.cos (((2 * 0 + 1 : ℕ) : ℝ) * α i) else 1
  let sign : Bool → ℝ := fun minus => if minus = true then -1 else 1
  let S : Bool → Bool → Ω → M := fun useCos minus ω =>
    sign minus • ∑ i : Fin 2, w useCos i • Z i ω
  let Rstar : ℝ := 2 * r * (L + 1) / (2 : ℝ)
  let s : ℝ := (-1); let useCos := true; let minus := true;
    let f : Ω → ℝ := fun ω => Matrix.trace (NormedSpace.exp (s • S useCos minus ω))
    let B : ℝ := r ^ 2 * Real.exp (|s| * ((2 : ℝ) * Rstar))
    Integrable f μ ∧ (∀ ω, 0 < f ω ∧ f ω ≤ B) ∧
      0 < ∫ ω, f ω ∂μ ∧ (∫ ω, f ω ∂μ) ≤ B := by
  exact native_actual_T (d := 2) (q := 0) (by norm_num) (-1) true true

theorem q0_d2_cos_negative_s_positive :
  let D := EuclideanSpace ℝ (Fin 2)
  let E := EuclideanSpace ℝ (Fin (0 + 1))
  let Ω := Fin (0 + 1) → D
  let μ : Measure Ω := Measure.pi (fun _ : Fin (0 + 1) => stdGaussian D)
  let M := Matrix (Fin (0 + 1) × Fin (0 + 1)) (Fin (0 + 1) × Fin (0 + 1)) ℝ
  let r : ℝ := ((0 + 1 : ℕ) : ℝ)
  let L : ℝ := 2 * r + 3 * Real.log (1000 * (2 : ℝ))
  let α : Fin 2 → ℝ := fun i => ((i.val : ℝ) + 1 - 1 / 2) * Real.pi / (2 : ℝ)
  let tvec : Fin 2 → Fin (0 + 1) → ℝ := fun i k =>
    if k.val = 0 then 1 else Real.sqrt 2 * Real.cos ((k.val : ℝ) * α i)
  let row : Fin 2 → Ω → E := fun i ω =>
    WithLp.toLp 2 (fun b : Fin (0 + 1) => ω b i)
  let Y : Fin 2 → Ω → M := fun i ω =>
    if ‖row i ω‖ ^ 2 ≤ L then
      (2 : ℝ)⁻¹ • Matrix.kronecker
        (Matrix.vecMulVec (WithLp.ofLp (row i ω)) (WithLp.ofLp (row i ω)))
        (Matrix.vecMulVec (tvec i) (tvec i))
    else 0
  let mean : Fin 2 → M := fun i => ∫ ω, Y i ω ∂μ
  let Z : Fin 2 → Ω → M := fun i ω => Y i ω - mean i
  let w : Bool → Fin 2 → ℝ := fun useCos i =>
    if useCos = true then Real.cos (((2 * 0 + 1 : ℕ) : ℝ) * α i) else 1
  let sign : Bool → ℝ := fun minus => if minus = true then -1 else 1
  let S : Bool → Bool → Ω → M := fun useCos minus ω =>
    sign minus • ∑ i : Fin 2, w useCos i • Z i ω
  let Rstar : ℝ := 2 * r * (L + 1) / (2 : ℝ)
  let s : ℝ := 1; let useCos := true; let minus := true;
    let f : Ω → ℝ := fun ω => Matrix.trace (NormedSpace.exp (s • S useCos minus ω))
    let B : ℝ := r ^ 2 * Real.exp (|s| * ((2 : ℝ) * Rstar))
    Integrable f μ ∧ (∀ ω, 0 < f ω ∧ f ω ≤ B) ∧
      0 < ∫ ω, f ω ∂μ ∧ (∫ ω, f ω ∂μ) ≤ B := by
  exact native_actual_T (d := 2) (q := 0) (by norm_num) 1 true true

def mixed : Matrix (Fin 2) (Fin 2) ℝ :=
  Matrix.diagonal (fun i => if i = 0 then -3 else 2)

theorem mixed_diagonal_entries : mixed 0 0 = -3 ∧ mixed 1 1 = 2 := by
  norm_num [mixed, Matrix.diagonal_apply]

theorem mixed_allreal (s : ℝ) :
    0 < Matrix.trace (NormedSpace.exp (s • mixed)) ∧
      Matrix.trace (NormedSpace.exp (s • mixed)) ≤
        2 * Real.exp (|s| * ‖(Matrix.toEuclideanCLM (𝕜 := ℝ) (n := Fin 2)) mixed‖) := by
  simpa only [Matrix.cstar_norm_def, Fintype.card_fin, Nat.cast_ofNat] using
    AutoSamplingTheory.TechnicalLemmas.Analysis.MatrixTraceExponentialBounds.trace_exp_pos_and_le_card_mul_exp_abs_mul_norm mixed
      (Matrix.isHermitian_diagonal _) s

theorem mixed_s_zero :
    0 < Matrix.trace (NormedSpace.exp ((0 : ℝ) • mixed)) ∧
      Matrix.trace (NormedSpace.exp ((0 : ℝ) • mixed)) ≤
        2 * Real.exp (|(0 : ℝ)| * ‖(Matrix.toEuclideanCLM (𝕜 := ℝ) (n := Fin 2)) mixed‖) :=
  mixed_allreal 0

theorem mixed_s_negative :
    0 < Matrix.trace (NormedSpace.exp (((-1) : ℝ) • mixed)) ∧
      Matrix.trace (NormedSpace.exp (((-1) : ℝ) • mixed)) ≤
        2 * Real.exp (|((-1) : ℝ)| * ‖(Matrix.toEuclideanCLM (𝕜 := ℝ) (n := Fin 2)) mixed‖) :=
  mixed_allreal (-1)

theorem mixed_s_positive :
    0 < Matrix.trace (NormedSpace.exp ((1 : ℝ) • mixed)) ∧
      Matrix.trace (NormedSpace.exp ((1 : ℝ) • mixed)) ≤
        2 * Real.exp (|(1 : ℝ)| * ‖(Matrix.toEuclideanCLM (𝕜 := ℝ) (n := Fin 2)) mixed‖) :=
  mixed_allreal 1

theorem mixed_operator_norm_three : ‖mixed‖ = 3 := by
  rw [mixed, Matrix.l2_opNorm_diagonal]
  apply le_antisymm
  · apply (pi_norm_le_iff_of_nonneg (by norm_num : (0 : ℝ) ≤ 3)).2
    intro i
    fin_cases i <;> norm_num
  · have h := norm_le_pi_norm (fun i : Fin 2 => if i = 0 then (-3 : ℝ) else 2) (0 : Fin 2)
    norm_num at h
    exact h

theorem mixed_negative_parameter_exact_norm_cap :
    0 < Matrix.trace (NormedSpace.exp ((-1 : ℝ) • mixed)) ∧
      Matrix.trace (NormedSpace.exp ((-1 : ℝ) • mixed)) ≤ 2 * Real.exp 3 := by
  simpa [← Matrix.cstar_norm_def, mixed_operator_norm_three] using mixed_allreal (-1)

end NativeLiteralApplications
#print axioms NativeLiteralApplications.literal_P
#print axioms NativeLiteralApplications.literal_P_explicit_L2_operator
#print axioms NativeLiteralApplications.literal_T
#print axioms NativeLiteralApplications.literal_T_q0
#print axioms NativeLiteralApplications.literal_T_q0_d2
#print axioms NativeLiteralApplications.allreal_ordinary_positive
#print axioms NativeLiteralApplications.q0_d2_ordinary_positive_s_zero
#print axioms NativeLiteralApplications.q0_d2_ordinary_positive_s_negative
#print axioms NativeLiteralApplications.q0_d2_ordinary_positive_s_positive
#print axioms NativeLiteralApplications.allreal_ordinary_negative
#print axioms NativeLiteralApplications.q0_d2_ordinary_negative_s_zero
#print axioms NativeLiteralApplications.q0_d2_ordinary_negative_s_negative
#print axioms NativeLiteralApplications.q0_d2_ordinary_negative_s_positive
#print axioms NativeLiteralApplications.allreal_cos_positive
#print axioms NativeLiteralApplications.q0_d2_cos_positive_s_zero
#print axioms NativeLiteralApplications.q0_d2_cos_positive_s_negative
#print axioms NativeLiteralApplications.q0_d2_cos_positive_s_positive
#print axioms NativeLiteralApplications.allreal_cos_negative
#print axioms NativeLiteralApplications.q0_d2_cos_negative_s_zero
#print axioms NativeLiteralApplications.q0_d2_cos_negative_s_negative
#print axioms NativeLiteralApplications.q0_d2_cos_negative_s_positive
#print axioms NativeLiteralApplications.mixed_allreal
#print axioms NativeLiteralApplications.mixed_s_zero
#print axioms NativeLiteralApplications.mixed_s_negative
#print axioms NativeLiteralApplications.mixed_s_positive

set_option pp.all true in
#check @AutoSamplingTheory.TechnicalLemmas.Analysis.MatrixTraceExponentialBounds.trace_exp_pos_and_le_card_mul_exp_abs_mul_norm
set_option pp.all true in
#check native_actual_T

#print axioms NativeLiteralApplications.mixed_operator_norm_three
#print axioms NativeLiteralApplications.mixed_negative_parameter_exact_norm_cap
