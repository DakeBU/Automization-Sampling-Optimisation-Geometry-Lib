theorem eval_X : X.eval x = x :=
  eval₂_X _ _
