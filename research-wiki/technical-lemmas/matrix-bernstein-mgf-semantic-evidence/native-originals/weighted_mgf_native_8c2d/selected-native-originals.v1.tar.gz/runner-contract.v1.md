# Native runner preparation contract

`native_runner.py COMMAND_ID` refuses until an actual
`native-command-assignment.json` supplies status
`ROOT_ADMITTED_AND_ASSIGNED_IMMUTABLE_COMPLETE_P_AND_T`, a pinned source-topology
admission receipt, exact immutable candidate commit, archived complete P/T,
all immutable source inputs, this runner/expectation hashes, a frozen native
command manifest and independent exact nine-package byte-verification receipt.
This preparation creates no assignment, fake admission, command plan for a
target build, or output-initialization marker.

Before the first command, `native-output/` must contain zero entries. Later
commands require the identical assignment hash. Commands have exact argv,
owned cwd and a fully explicit environment; no shell or inherited environment
is used. LEAN_PATH is only the fresh owned ASTIS output plus precisely nine
frozen, independently verified upstream package roots. Read-only R13 clean
upstream artifact reuse can avoid a second six-GB cache copy, but old R13 ASTIS
output and root ASTIS caches are never accepted.

Raw stdout/stderr are separate exclusive timestamped files, with argv, cwd,
environment, exit status, time and hashes in exclusive receipts. Actual
candidate commit is separate from before/after observed live repository HEAD.
An observation never fabricates a successful build at a different HEAD.

Root supplies admission and immutable code; native-owned archival, actual import
closure, command contract, universal literal applications and generic kernel
audit adaptation are prepared only after that assignment. The existing R13
NativeAudit/actual-parent/reader scripts are external hash references, not new
acceptance or proof evidence. Current preparation does not run Lean on a target.

Metadata gates, browser work and every normal API are outside this runner's
native phase. A later separately frozen reader wrapper may inspect only owned
isolated fixtures at desktop1440x1000 and mobile390x844. Full P/T code, source,
copy/download/index/graph and formula/fold behavior require new actual evidence.
Global renderer/CSS/Registry/root imports and old R13 source bytes remain held.
