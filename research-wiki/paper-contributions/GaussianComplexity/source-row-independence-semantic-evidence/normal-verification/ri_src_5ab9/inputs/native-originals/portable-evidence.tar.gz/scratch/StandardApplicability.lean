import Tests.GaussianComplexityFixedSpectrumSourceRowIndependence
open MeasureTheory ProbabilityTheory
set_option autoImplicit false
set_option pp.universes true
set_option pp.explicit true
set_option pp.proofs true
#check @ProbabilityTheory.map_pi_eq_stdGaussian
#print ProbabilityTheory.map_pi_eq_stdGaussian
#check @MeasureTheory.measurePreserving_pi
#check @MeasureTheory.measurePreserving_piCongrLeft
#check @MeasureTheory.Measure.infinitePi_eq_pi
#check @MeasureTheory.Measure.infinitePi_map_curry_symm
#check @MeasureTheory.Measure.infinitePi_map_curry
#check @ProbabilityTheory.iIndepFun_iff_map_fun_eq_pi_map
#check @ProbabilityTheory.iIndepFun.comp
#print ProbabilityTheory.iIndepFun
#print ProbabilityTheory.iIndep
#print ProbabilityTheory.iIndepSets
example (d : ℕ) : IsProbabilityMeasure (stdGaussian (EuclideanSpace ℝ (Fin d))) := inferInstance
example : IsProbabilityMeasure (gaussianReal 0 1) := inferInstance
example (q : ℕ) : IsProbabilityMeasure (Measure.pi (fun _ : Fin (q+1) => gaussianReal 0 1)) := inferInstance
example (d q : ℕ) : IsProbabilityMeasure (Measure.pi (fun _ : Fin (q+1) => stdGaussian (EuclideanSpace ℝ (Fin d)))) := inferInstance
example (d q : ℕ) : IsProbabilityMeasure (Measure.pi (fun _ : Fin (q+1) × Fin d => gaussianReal 0 1)) := inferInstance
example (q : ℕ) : SigmaFinite (Measure.pi (fun _ : Fin (q+1) => gaussianReal 0 1)) := inferInstance
example (d : ℕ) : SigmaFinite (stdGaussian (EuclideanSpace ℝ (Fin d))) := inferInstance
example (d : ℕ) : Measure.map (WithLp.toLp 2 : (Fin d → ℝ) → EuclideanSpace ℝ (Fin d))
    (Measure.pi (fun _ : Fin d => gaussianReal 0 1)) = stdGaussian (EuclideanSpace ℝ (Fin d)) := map_pi_eq_stdGaussian
