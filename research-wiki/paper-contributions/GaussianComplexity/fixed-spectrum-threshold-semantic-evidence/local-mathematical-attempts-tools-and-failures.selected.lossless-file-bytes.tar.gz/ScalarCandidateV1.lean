import Mathlib.Analysis.SpecialFunctions.Pow.Asymptotics
import Mathlib.Tactic
open Filter Asymptotics
noncomputable section

private theorem threshold_envelope {C δ κ : ℝ} (hC : 0 ≤ C)
    (hδ0 : 0 ≤ δ) (hδ1 : δ ≤ 1) (d q : ℕ)
    (hd : 1 ≤ (d : ℝ)) (hlog : 1 ≤ Real.log (d : ℝ))
    (hκ : 0 ≤ κ) (hκcap : κ ≤ (d : ℝ) ^ (1 - δ))
    (hq : (q : ℝ) ≤ (δ / 256) * Real.sqrt κ * Real.log (d : ℝ)) :
    C * (((q : ℝ) + 1) * Real.sqrt (Real.log (d : ℝ) / (d : ℝ)) +
      (((q : ℝ) + 1) * ((q : ℝ) + 1 + Real.log (d : ℝ)) * Real.log (d : ℝ)) / (d : ℝ))
      ≤ 8 * C * (d : ℝ) ^ (-δ / 2) * (Real.log (d : ℝ)) ^ 3 := by
  let x : ℝ := d
  let L : ℝ := Real.log x
  let R : ℝ := x ^ ((1 - δ) / 2)
  let A : ℝ := (q : ℝ) + 1
  change C * (A * Real.sqrt (L / x) + A * (A + L) * L / x) ≤
    8 * C * x ^ (-δ / 2) * L ^ 3
  have hx1 : 1 ≤ x := hd
  have hx : 0 < x := by linarith
  have hL1 : 1 ≤ L := hlog
  have hL0 : 0 ≤ L := by linarith
  have hR0 : 0 ≤ R := Real.rpow_nonneg hx.le _
  have hR1 : 1 ≤ R := by
    dsimp [R]
    exact Real.one_le_rpow hx1 (by linarith)
  have hs : Real.sqrt κ ≤ R := by
    calc
      _ ≤ Real.sqrt (x ^ (1 - δ)) := Real.sqrt_le_sqrt hκcap
      _ = R := by
        rw [Real.sqrt_eq_rpow, ← Real.rpow_mul hx.le]
        congr 1
        ring
  have hqR : (q : ℝ) ≤ R * L := by
    calc
      _ ≤ (δ / 256) * Real.sqrt κ * L := hq
      _ ≤ 1 * R * L := by gcongr; linarith
      _ = R * L := by ring
  have hRL : 1 ≤ R * L := one_le_mul hR1 hL1
  have hA : A ≤ 2 * R * L := by dsimp [A]; linarith
  have hsum : A + L ≤ 3 * R * L := by
    have hLR : L ≤ R * L := by nlinarith
    linarith
  have hsL : Real.sqrt L ≤ L := (Real.sqrt_le_iff).2 ⟨hL0, by nlinarith⟩
  have hsdiv : Real.sqrt (L / x) ≤ L / Real.sqrt x := by
    rw [Real.sqrt_div hL0]
    exact div_le_div_of_nonneg_right hsL (Real.sqrt_nonneg _)
  have hRdiv : R / Real.sqrt x = x ^ (-δ / 2) := by
    rw [Real.sqrt_eq_rpow, ← Real.rpow_sub hx]
    congr 1
    ring
  have hR2div : R ^ 2 / x = x ^ (-δ) := by
    have he : R ^ 2 = x ^ (((1 - δ) / 2) * 2) := by
      dsimp [R]
      rw [Real.rpow_mul hx.le]
      norm_num
    rw [he, ← Real.rpow_sub_one (ne_of_gt hx)]
    congr 1
    ring
  have hLpow : L ^ 2 ≤ L ^ 3 := by
    calc
      _ ≤ L ^ 2 * L := le_mul_of_one_le_right (sq_nonneg L) hL1
      _ = L ^ 3 := by ring
  have hfirst : A * Real.sqrt (L / x) ≤ 2 * x ^ (-δ / 2) * L ^ 3 := by
    calc
      _ ≤ (2 * R * L) * (L / Real.sqrt x) := by gcongr
      _ = 2 * (R / Real.sqrt x) * L ^ 2 := by ring
      _ = 2 * x ^ (-δ / 2) * L ^ 2 := by rw [hRdiv]
      _ ≤ _ := mul_le_mul_of_nonneg_left hLpow (by positivity)
  have hsecond : A * (A + L) * L / x ≤ 6 * x ^ (-δ / 2) * L ^ 3 := by
    calc
      _ ≤ (2 * R * L) * (3 * R * L) * L / x := by gcongr
      _ = 6 * (R ^ 2 / x) * L ^ 3 := by ring
      _ = 6 * x ^ (-δ) * L ^ 3 := by rw [hR2div]
      _ ≤ _ := by
        gcongr
        exact Real.rpow_le_rpow_of_exponent_le hx1 (by linarith)
  calc
    _ ≤ C * (2 * x ^ (-δ / 2) * L ^ 3 + 6 * x ^ (-δ / 2) * L ^ 3) :=
      mul_le_mul_of_nonneg_left (add_le_add hfirst hsecond) hC
    _ = _ := by ring
