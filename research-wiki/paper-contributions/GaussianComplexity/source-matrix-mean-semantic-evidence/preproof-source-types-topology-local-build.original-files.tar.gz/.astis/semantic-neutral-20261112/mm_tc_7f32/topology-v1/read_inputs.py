from pathlib import Path
from collections import OrderedDict
import json
import runpy
import sys

ROOT = Path('/Users/zhouhuanjian/ASTIS-GC')
OWN = ROOT/'.astis/semantic-neutral-20261112/mm_tc_7f32'
SG = ROOT/'.astis/semantic-neutral-20261112/mm_sg_61c4'
mode = sys.argv[1]
lo, hi = (int(v) for v in sys.argv[2:4]) if len(sys.argv)>2 else (0,1000)
sys.argv = [str(OWN/'read_raw.py'),'silent']
reader = runpy.run_path(str(OWN/'read_raw.py'))
by_id = reader['by_id']
coverage = json.loads((SG/'source-graph-freeze-v1/post-seal-coverage.json').read_text())
groups = OrderedDict()
for n,a in enumerate(coverage['items']):
    groups.setdefault(a['source_element_id'],[]).append((n,a))
if mode == 'read':
    for n,(ident,atoms) in enumerate(groups.items()):
        if lo<=n<hi:
            print(json.dumps({'group':n,'source_id':ident,'actual_raw_text':by_id[ident].clean(),
                              'atoms':[{'ordinal':k+1,**{key:val for key,val in item.items() if key in
                                   ['id','kind','meaning','semantic_slice','disposition','reason']}}
                                   for k,item in atoms]},ensure_ascii=False))
elif mode == 'counts':
    print(json.dumps({'groups':len(groups),'atoms':len(coverage['items'])}))
