from pathlib import Path
import datetime
import gzip
import hashlib
import json
import subprocess
import sys
sys.dont_write_bytecode = True
sys.path.insert(0, 'tools')
import astis_advance as adv

W = Path(__file__).parent
E = Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-target-law-semantic-evidence')
sha = lambda b: hashlib.sha256(b).hexdigest()
dump = lambda x: (json.dumps(x, ensure_ascii=False, indent=2) + '\n').encode()
git = lambda *a: subprocess.check_output(['git', *a])
def put(p, b):
    assert not p.exists(), p
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(b)

head = git('rev-parse', 'HEAD').decode().strip()
assert head == 'ca084cc4375fe1cd21e65da8746358ae5ac109d7'
assert not git('diff', '--name-only', 'HEAD')
receiptpath = Path('.astis/huanjian-resume-20261103/20261110T094501243412Z-target-law-literal-Prop-only-statement-formation.receipt.json')
receipt = json.loads(receiptpath.read_bytes())
assert receipt['exit_code'] == 0
log = Path(receipt['log']).read_bytes()
assert sha(log) == receipt['log_sha256'] == '6dd6b4382dcd92c88b9d08404e59e834bafccf1a92b87d7d4fde525a223b2792'
assert receipt['head_before'] == receipt['head_after'] == '904d6d68b5d403a387ff4e6984b1f0310ff63374'
assert git('diff', '--name-only', receipt['head_after'], head).decode().splitlines() == ['research-wiki/paper-contributions/GaussianComplexity/README.md']

manifest = Path('lake-manifest.json').read_bytes()
assert sha(manifest) == 'b83ca83b9cf7caa85fa8b023c2ff9a3fb7a7cce7e1c332e810c348535ec49c37'
packages = json.loads(manifest)['packages']
deps = []
for p in packages:
    location = Path('.lake/packages') / p['name']
    actual = subprocess.check_output(['git', '-C', str(location), 'rev-parse', 'HEAD'], text=True).strip()
    dirty = subprocess.check_output(['git', '-C', str(location), 'status', '--porcelain', '--untracked-files=no'])
    assert actual == p['rev'] and not dirty, p['name']
    deps.append({'name':p['name'], 'actual_head':actual, 'manifest_rev':p['rev'], 'tracked_clean':True})
assert len(deps) == 9
lean = Path(subprocess.check_output(['lake', 'env', 'which', 'lean'], text=True).strip()).resolve()
version = subprocess.check_output(['lake', 'env', 'lean', '--version'], text=True).strip()
assert '4.33.0' in version
assert sha(lean.read_bytes()) == '1b370cfcbf44e80d1b004ab1b1ab9a4c73951f9f7c242140bcff9bc577576554'
environment = {'observed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'HEAD':head, 'lean_path':str(lean), 'actual_lean_version':version,
    'lean_binary_sha256':sha(lean.read_bytes()), 'manifest_sha256':sha(manifest),
    'lean_toolchain_raw_sha256':sha(Path('lean-toolchain').read_bytes()), 'nine_actual_dependency_heads':deps,
    'no_lake_update_or_dependency_source_write':True, 'ATLAS_read_or_training':False}
put(W/'actual-env-at-seal.json', dump(environment))
put(E/'actual-env-at-seal.json', dump(environment))

probe = W/'LiteralStatementFormation.lean'
rawprobe = probe.read_bytes()
assert sha(rawprobe) == 'e2da27acd7acb2a122008cdffd147b3db3599ff2d57bb31b38e0bec8a10027f4'
assert rawprobe.count(b': Prop :=') == 2 and b' := by' not in rawprobe
put(E/'Prop-only-literal-statement-formation.raw.lean.txt', rawprobe)
put(E/'Prop-only-literal-statement-formation.raw.lean.txt.gz', gzip.compress(rawprobe,mtime=0))
put(E/'actual-statement-formation.receipt.json', receiptpath.read_bytes())
put(E/'actual-statement-formation.log.gz', gzip.compress(log,mtime=0))
probe.unlink()
assert not probe.exists()

definitions = [
    {'name':'multivariateGaussian', 'file':'.lake/packages/mathlib/Mathlib/Probability/Distributions/Gaussian/Multivariate.lean', 'first':163, 'last':170,
     'meaning':'Actual measure stdGaussian mapped by mean plus toEuclideanCLM(CFC.sqrt covariance). Non-PSD fallback is a real convention, not the source family. Proper positive covariance must be justified from literal hard-family bounds/canonical admissibility, never a caller certificate; the genuine norm-mean consumer is nonvacuous.'},
    {'name':'Matrix.orthogonalGroup', 'file':'.lake/packages/mathlib/Mathlib/LinearAlgebra/UnitaryGroup.lean', 'first':291, 'last':295,
     'meaning':'Full real orthogonal group abbreviation; no det=1 restriction.'},
]
for i,d in enumerate(definitions):
    path = Path(d['file'])
    lines = path.read_text().splitlines()
    block = '\n'.join(lines[d['first']-1:d['last']]) + '\n'
    out = E/'necessary-definition-context'/f'{i:02d}-{d["name"].replace(".","_")}.txt'
    put(out,block.encode())
    d.update({'whole_file_sha256':sha(path.read_bytes()), 'excerpt_path':str(out), 'excerpt_sha256':sha(block.encode())})

p = (W/'producer-signature.txt').read_text()
c = (W/'consumer-signature.txt').read_text()
assert sha(p.encode()) == '531a3651e3640057ea29a0ccce6b7fd2cf7689ecb126be71d7460af125d2b9fb'
assert sha(c.encode()) == 'a54682278c1ba728a1ea4ad03f735f997787a733b8dd9c02856280de749e6b3a'
binders = []
for owner in ['producer','private_consumer']:
    for name,kind,why in [
        ('d:Nat','TYPING','Finite natural dimension.'),
        ('2<=d','SOURCE','Literal hard-family source domain; not an extra premise on either final main theorem.'),
        ('kappa:Real','TYPING','Real source construction/condition-number parameter.'),
        ('2<=kappa','SOURCE','Hard-family range; all invertibility/positive-covariance facts are derived/reused internally.'),
        ('O:Matrix.orthogonalGroup(Fin d) Real','SOURCE','Every fixed full real orthogonal hidden eigenbasis, including both determinant signs. No random/Haar/conditional joint-law binder.')]:
        binders.append({'owner':owner,'binder':name,'class':kind,'reason':why})
paper = Path('.astis/huanjian-resume-20261103/2610.20492v1.html').read_bytes()
assert len(paper)==951991 and sha(paper)=='6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
body = {
    'schema':1, 'status':'STATEMENT_SEALED_ONLY_NO_PROOF',
    'source':{'revision':'arXiv:2610.20492v1', 'anchors':['S4.E11','S4.SS2.SSS0.Px3.p2.1','A3.SS3','A3.SS4.p3.1'],
      'scope':'Actual fixed-O Gaussian law recognition and a genuine target norm-square L1/finite inverse-spectrum mean component. Extracted source components, not all Lemma4.5, target pass probability, conditioning/Haar/adaptive algorithm or main lower bound.',
      'raw':{'path':'.astis/huanjian-resume-20261103/2610.20492v1.html','bytes':len(paper),'sha256':sha(paper)}},
    'producer':{'name':'AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumTargetLaw.actual_rotated_gaussian_target',
      'planned_file':'AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumTargetLaw.lean',
      'signature':p, 'signature_sha256':sha(p.encode()), 'definition_kind':'literal'},
    'actual_private_consumer':{'name':'actual_target_gaussian_norm_mean',
      'planned_file':'Tests/GaussianComplexityFixedSpectrumTargetLaw.lean',
      'signature':c, 'signature_sha256':sha(c.encode()), 'definition_kind':'literal','is_source_anchor':False,
      'consumer_obligation':'Actually consume new law together with canonical existing diagonal Gaussian moment mathematics, producing target L1 and actual target integral. No wrapper assuming the desired law/mean, no unexported-private name hack or repeated proof copy.'},
    'binder_audit':binders, 'definition_semantics_audit':definitions,
    'literal_conventions':{'precision_vs_covariance':'A=O Lambda O transpose is precision; Lambda inverse and A inverse are covariance matrices. The real inverse eigenvalues in the norm mean are scalars.',
      'Euclidean_model':'EuclideanSpace R(Fin d), ordinary Euclidean norm and WithLp coordinate conversion; R uses exact matvec by O.',
      'matrix_inverse':'Actual Matrix inverse notation, never scalar reciprocal. Nonsingular/PSD source domain must be justified, not assumed as a goal certificate.',
      'measure':'Actual Mathlib Gaussian measures and Measure.map, not a placeholder law; R measurability and norm transport are proof ingredients.',
      'pointwise_vs_joint':'Every fixed O only; no Haar law, measurable parameter kernel, conditional representative, algorithmic output law or query-cost conclusion.'},
    'no_proof_ingredient_binder':['no PosDef/invertibility certificate','no Gaussian map/covariance recognition input','no law or moment oracle','no hR/hEvent/Integrable certificate','no q/delta/C/TV/precision/cost assumption'],
    'source_generalization_boundary':'Hard-family d>=2,kappa>=2 auxiliary; no new hardness range. Private norm mean is the n-independent norm component, not a full moment/variance lemma.',
    'reuse_search_before_seal':{'region':'Existing GaussianComplexity/TechnicalLemmas declaration inventory and active owned cells; no active duplicate new target ID/file. Exact generic Mathlib/local theorem API retrieval is postponed until source/topology admission.',
      'known_existing_candidate':'FixedSpectrumGaussianMoments.actual_diagonal_gaussian_quadratic_means is a real compiled canonical diagonal-moment producer, not assumed target law. Exact actual dependency set is only credited after compilation.'},
    'preseal_exposure':'preseal-exposure-disclosure.json and inherited-preseal-planning.raw.json retained; informal related-proof planning/prior implementation and minimal adjacent definition header exposure are explicit. No pristine history is claimed.',
    'Prop_only_formation':{'receipt':str(E/'actual-statement-formation.receipt.json'),'log_raw_sha256':sha(log),'probe_raw_sha256':sha(rawprobe),'probe_actually_deleted':True,
      'scope':'Only two Prop-valued type definitions, no proof bodies, no axiom/sorry. Source hd/hkappa linter warnings retained. Actual formation at904d; interveningca084 README-only correction is not a new build.'},
    'actual_environment':environment, 'independent_source_topology_and_normal_intake':'PENDING; no advance proposed/claimed, no target proof/API work admitted',
    'control_plane_math_authority':False, 'global_owner_release':'HOLD original owner; all existing queues/foreign states/frontiers retained'}
sealed = dump(body)
put(W/'statement-seal-v1.json',sealed)
put(Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-target-law-statement-seal.json'),sealed)
projection = {k:body[k] for k in ['source','producer','actual_private_consumer','binder_audit','definition_semantics_audit','literal_conventions','no_proof_ingredient_binder','source_generalization_boundary']}
put(W/'strict-statement-projection.json',dump(projection))

rawledger = Path('runs/substantive_advances.jsonl').read_bytes()
states = adv._replay_advances([json.loads(z) for z in rawledger.splitlines()])
assert len(states)==296 and 'ASTIS-SA-20261110-GaussianComplexityFixedSpectrumTargetLaw' not in states
frontiers = {str(f):sha(f.read_bytes()) for f in Path('research-wiki/frontier-cells').glob('*.json')}
tracked = {p.decode():sha(Path(p.decode()).read_bytes()) for p in git('ls-files','-z').split(b'\0') if p and not Path(p.decode()).is_symlink()}
put(W/'preproof-baseline.private.json',dump({'state':'PRIVATE_RAW_FOREIGN_NEVER_ARCHIVE','head':head,
    'ledger_bytes':len(rawledger),'ledger_sha256':sha(rawledger),'all296_foreign_states':states,
    'all_existing_frontier_hashes':frontiers,'all_tracked_regular_file_hashes':tracked}))
print(json.dumps({'state':'STATEMENT_SEALED_ONLY','seal_sha256':sha(sealed),
    'strict_projection_sha256':sha(dump(projection)),'all296_prior_states_preserved':True,
    'existing_frontier_JSON_count':len(frontiers),'tracked_regular_files_protected':len(tracked),
    'no_new_advance_API_or_proof':True,'Prop_probe_deleted':True}))
