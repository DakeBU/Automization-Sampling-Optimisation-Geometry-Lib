"""Correct three stale current-phase prose scalars from the existing source V.

Retain the exact v1 cell and reports; do not originate a verdict, change source
graph statuses, write a ledger/audit/code file, or claim live-reader acceptance.
"""
from pathlib import Path
import copy
import datetime
import difflib
import gzip
import hashlib
import json
import subprocess
import sys
import time

sys.dont_write_bytecode = True
ROOT = Path('/Users/zhouhuanjian/ASTIS-GC')
OUT = ROOT / 'research-wiki/paper-contributions/GaussianComplexity/ex72-integration-20261107/independent-integration-reader-review'
STAGE = ROOT / '.astis/huanjian-gc-ex72-integration-20261107/independent-reader-preparation'
SOURCE = ROOT / 'research-wiki/paper-contributions/GaussianComplexity/tv-amplification-semantic-evidence/fresh-source-v2/phase3'
CELL = ROOT / 'research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-tv-amplification.json'
AUDIT = ROOT / 'research-wiki/semantic-roundtrip/audits/huanjian-tv-amplification.json'
REPORT = OUT / 'existing-source-v-frontier-current-prose-v2.json'
assert not REPORT.exists()


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def canonical(obj):
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()


def archive(path, raw):
    assert not path.exists()
    packed = gzip.compress(raw, compresslevel=9, mtime=0)
    path.write_bytes(packed)
    assert gzip.decompress(path.read_bytes()) == raw
    return {'path': str(path.relative_to(ROOT)), 'sha256': sha(packed), 'raw_sha256': sha(raw), 'raw_bytes': len(raw)}


v1_report_raw = (OUT / 'existing-source-v-frontier-projection.json').read_bytes()
assert sha(v1_report_raw) == 'f6d6712272f3cf162a2ac8b4ef5499402fd6d061b405a59d2a1add2fbe193aa1'
v1_report = json.loads(v1_report_raw)
before = CELL.read_bytes()
assert sha(before) == 'c891474a92d1ad137e58611efc4166198034b3bc278612f6d685c666b815d72a'
assert gzip.decompress((ROOT / v1_report['after']['path']).read_bytes()) == before
source_receipt_raw = (SOURCE / 'actual-source-V-and-preservation-receipt.json').read_bytes()
assert sha(source_receipt_raw) == '61548d073a14e5d420640d6b97b5f5225ae602995093b5d60592180685459571'
run_raw = (SOURCE / 'independent-review-run.json').read_bytes()
assert sha(run_raw) == '32277ca886cc0ea865d92e68e95c64976b859a015f1af77fd677e70089355939'
run = json.loads(run_raw)
assert run['fidelity_judgment'] == 'equivalent-after-elaboration'
assert run['reviewer'] == '/root/ex72_fresh_source_v2'
audit_raw = AUDIT.read_bytes()
assert sha(audit_raw) == '67b1c0484faf78ca170cc65a407bac46d26b40a316daf3cb19edc1cefb6933ab'
audit = json.loads(audit_raw)
assert audit['state'] == 'source-reviewed' and audit['source_review']['state'] == 'accepted'
ledger_path, discoveries_path = (ROOT / p for p in ('runs/substantive_advances.jsonl', 'runs/substantive_discoveries.jsonl'))
ledger_raw, discoveries_raw = ledger_path.read_bytes(), discoveries_path.read_bytes()
assert sha(ledger_raw) == '7dc1c9f7e12c582121afe9741f00e21863a24cf929d2ddb3c289ab35eb11dd29'
sys.path.insert(0, str(ROOT / 'tools'))
import astis_advance as advance
states = advance._replay_advances(json.loads(row) for row in ledger_raw.splitlines())
assert states['ASTIS-SA-20261107-GaussianComplexityTVAmplification']['state'] == 'VERIFIED'
assert not any(s['state'] == 'STABILIZING' for s in states.values())
manifest_raw = (SOURCE / 'manifest.json').read_bytes()
assert sha(manifest_raw) == '29ac9b98a1736b6c2ba2d08becd30ab3048666a833b6e2d9ea24ca7d49a9a352'
manifest = json.loads(manifest_raw)
frontier_map = json.loads(gzip.decompress((SOURCE / 'foreign-frontier-files.json.gz').read_bytes()))
assert len(frontier_map) == 437
for path, expected in frontier_map.items():
    assert sha((ROOT / path).read_bytes()) == expected, path
graph_path = ROOT / run['source_graph_mapping']['path']
graph_raw = graph_path.read_bytes()
assert sha(graph_raw) == run['source_graph_mapping']['sha256']
original = json.loads(before)
after_object = copy.deepcopy(original)
assert original['status'] == 'independently_verified'
old_adapter = original['source_detail_audit']['consulted'][0]['hypothesis_adapter']
assert old_adapter.endswith('Independent source fidelity pending.')
run_path = str((SOURCE / 'independent-review-run.json').relative_to(ROOT))
receipt_path = str((SOURCE / 'actual-source-V-and-preservation-receipt.json').relative_to(ROOT))
after_object['source_detail_audit']['consulted'][0]['hypothesis_adapter'] = (
    old_adapter.removesuffix('Independent source fidelity pending.') +
    'Existing fresh source review accepted the selected final Ex72 inequality as equivalent-after-elaboration; actual internal producer use is recorded in ' +
    run_path + ' at /seven_phase2_obligations and /source_graph_mapping. No extra public source-domain hypothesis is introduced.')
after_object['source_detail_audit']['fidelity_boundary'] = (
    'The selected final actual Ex72 inequality has existing fresh independent source-reviewed/accepted fidelity, equivalent-after-elaboration, '
    'through the normal source V recorded in ' + receipt_path + ' and ' + run_path +
    '. This is a mechanical projection of that existing fact. Mathematical code/Test candidate ebf76119351b23ef0718fc69aa5081515bab0b52 '
    'remains distinct from verified metadata commit e4a1b8d60822706df62a7d4bab23814d7187c622; the candidate audit was draft then. '
    'Static candidate content/disclosures are the reader scope of source V; the browser file-URL security rejection is preserved and supplies no live acceptance. '
    'Root/Registry/aggregate Tests/canonical gate/site/graph/actual Chrome, remote publication, merge, purification/Exposition Seal and Goal completion remain pending. '
    'Both main lower bounds and oracle/transcript/TV-precision/deterministic worst-case cap/expected-cost/hidden-eigenbasis adapters remain open.')
after_object['source_proof_coverage']['source_gaps'] = (
    'Historical source-only provenance retains 20 visible standard/source-implied bridge nodes and the external general Poisson citation. '
    'For the selected final Ex72 inequality, the existing fresh accepted source V in ' + receipt_path +
    ' has later actual-producer/source mapping evidence in ' + run_path + ' at /source_graph_mapping. '
    'This is not a bulk verification/status upgrade of those 20 source-only nodes, separately exported min-overlap/min-sqrt theorems, '
    'or a claim of the full general external Poisson representation. Raw source-only graph/artifact statuses, citation boundary and alternate-route qualifications remain unchanged.')
restored = copy.deepcopy(after_object)
restored['source_detail_audit']['consulted'][0]['hypothesis_adapter'] = old_adapter
restored['source_detail_audit']['fidelity_boundary'] = original['source_detail_audit']['fidelity_boundary']
restored['source_proof_coverage']['source_gaps'] = original['source_proof_coverage']['source_gaps']
assert restored == original
assert after_object['source_detail_audit']['detail_status'] == original['source_detail_audit']['detail_status']
assert after_object['evidence'] == original['evidence']
after = (json.dumps(after_object, ensure_ascii=False, indent=2) + '\n').encode()
before_archive = archive(OUT / 'source-v-frontier.v1-before-current-prose-v2.raw.json.gz', before)
after_archive = archive(OUT / 'source-v-frontier.current-prose-v2.after.raw.json.gz', after)
phase_history = archive(OUT / 'source-v-frontier.v1-source-only-phase-history.json.gz', canonical({
    'scope': 'Exact v1 semantic fields; exact full v1 byte archive is separately retained.',
    'source_detail_audit': original['source_detail_audit'], 'source_proof_coverage': original['source_proof_coverage']}))
raw_diff = b''.join(difflib.diff_bytes(difflib.unified_diff, before.splitlines(True), after.splitlines(True),
    fromfile=('v1/' + str(CELL.relative_to(ROOT))).encode(), tofile=('current-prose-v2/' + str(CELL.relative_to(ROOT))).encode()))
diff_archive = archive(OUT / 'source-v-frontier.current-prose-v2.diff.gz', raw_diff)
assert CELL.read_bytes() == before
CELL.write_bytes(after)
isolated = STAGE / 'exact-current-source-prose-v2-frontier-check'
isolated.mkdir(exist_ok=False)
copy_path = isolated / CELL.name
copy_path.write_bytes(CELL.read_bytes())
assert copy_path.read_bytes() == after == CELL.read_bytes()
command = ['/opt/anaconda3/bin/python', '-B', 'tools/astis_frontier_cells.py', 'check', '--root', str(isolated.relative_to(ROOT))]
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
tick = time.monotonic()
result = subprocess.run(command, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
elapsed = time.monotonic() - tick
log = archive(OUT / 'targeted-current-source-prose-v2-frontier-check.log.gz', result.stdout)
check_receipt = {'command': command, 'started_utc': started, 'exit_code': result.returncode, 'elapsed_seconds': elapsed,
    'live_cell': str(CELL.relative_to(ROOT)), 'isolated_exact_copy': str(copy_path.relative_to(ROOT)),
    'live_and_copy_sha256': sha(after), 'byte_equality_checked_before_and_after': True,
    'scope': 'One justified recheck after three real metadata prose scalars changed; normal Frontier Cell validator on exact isolated live-cell copy only.', 'log': log}
check_path = OUT / 'targeted-current-source-prose-v2-frontier-check.receipt.json'
assert not check_path.exists()
check_path.write_bytes((json.dumps(check_receipt, ensure_ascii=False, indent=2) + '\n').encode())
assert result.returncode == 0 and b'ASTIS Frontier Cell protocol check passed: 1 registered cells' in result.stdout
assert CELL.read_bytes() == copy_path.read_bytes() == after
assert AUDIT.read_bytes() == audit_raw and graph_path.read_bytes() == graph_raw
assert ledger_path.read_bytes() == ledger_raw and discoveries_path.read_bytes() == discoveries_raw
assert advance._replay_advances(json.loads(row) for row in ledger_raw.splitlines()) == states
assert (OUT / 'existing-source-v-frontier-projection.json').read_bytes() == v1_report_raw
for path, expected in frontier_map.items():
    assert sha((ROOT / path).read_bytes()) == expected, path
for filename, item in manifest['files'].items():
    assert sha((SOURCE / filename).read_bytes()) == item['sha256'], filename
assert (SOURCE / 'manifest.json').read_bytes() == manifest_raw
report = {'actor': '/root/ex72_integration_reader_review', 'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'operation': 'v2 mechanical current-phase prose projection of existing source V; no new mathematical/source verdict',
    'reason': 'Remove stale pending fidelity/mapping language from current metadata while preserving source-only provenance as historical evidence.',
    'exact_json_pointer_delta': ['/source_detail_audit/consulted/0/hypothesis_adapter', '/source_detail_audit/fidelity_boundary', '/source_proof_coverage/source_gaps'],
    'v1_projection_report_preserved_sha256': sha(v1_report_raw), 'v1_cell_before_sha256': sha(before), 'current_cell_after_sha256': sha(after),
    'exact_v1_cell_archive': before_archive, 'exact_current_cell_archive': after_archive, 'v1_source_only_phase_history': phase_history,
    'lossless_raw_diff': diff_archive, 'all_other_fields_and_v1_evidence_preserved': restored == original,
    'no_source_only_graph_or_artifact_status_or_citation_change': True, 'no_mass_20_gap_upgrade': True,
    'existing_actual_source_V_receipt_sha256': sha(source_receipt_raw), 'existing_accepted_review_run_sha256': sha(run_raw),
    'canonical_audit_unchanged_sha256': sha(audit_raw), 'source_graph_unchanged_sha256': sha(graph_raw),
    'ledger_exactly_unchanged_sha256': sha(ledger_raw), 'discovery_ledger_exactly_unchanged_sha256': sha(discoveries_raw),
    'all_279_projected_states_unchanged': True, 'all_278_foreign_states_unchanged': True, 'all_437_foreign_frontiers_unchanged': True,
    'frozen_source_phase3_manifest_files_unchanged': True, 'new_source_verdicts': 0, 'new_ledger_events': 0,
    'actual_targeted_check': {'path': str(check_path.relative_to(ROOT)), 'sha256': sha(check_path.read_bytes()), 'exit_code': result.returncode},
    'single_stabilization_lane': [], 'no_shared_integration_or_build_browser_or_parking': True, 'writes_stopped_after_report': True}
REPORT.write_bytes((json.dumps(report, ensure_ascii=False, indent=2) + '\n').encode())
archive(OUT / 'executed-project-current-source-prose-v2.py.gz', Path(__file__).read_bytes())
print(json.dumps({'status': 'passed', 'cell_after_sha256': sha(after), 'report_sha256': sha(REPORT.read_bytes()),
                  'targeted_receipt_sha256': sha(check_path.read_bytes()), 'only_three_prose_scalars': True,
                  'ledger_audit_source_and_other_frontiers_unchanged': True, 'writes_stopped': True}, indent=2))
