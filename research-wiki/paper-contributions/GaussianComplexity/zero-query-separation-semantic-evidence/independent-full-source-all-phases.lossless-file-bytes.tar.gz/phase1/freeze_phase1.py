from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, stat

BASE=Path(__file__).resolve().parent
REPO=Path('/Users/zhouhuanjian/ASTIS-GC')
docs=[
 'AGENTS.md', 'CONTRIBUTING.md',
 '.agents/prompts/collaborator-contribution.md',
 'docs/contributor-codex-contract.md',
 'docs/theorem-publication-protocol.md',
 'docs/proof-digestion-protocol.md',
 'docs/evidence-routed-memory-protocol.md',
 'docs/samplewiki-reader-navigation.md',
 'docs/formalization-protocol.md',
 '.agents/skills/astis-semantic-roundtrip/SKILL.md',
 '.agents/skills/astis-substantive-advance/SKILL.md',
 '.agents/prompts/samplewiki-route.md', 'LICENSE_SCOPE.md'
]
procedural=BASE/'procedural_inputs'
procedural.mkdir(exist_ok=False)
records=[]
for i,rel in enumerate(docs,1):
    data=(REPO/rel).read_bytes()
    dst=procedural/(str(i).zfill(2)+'_'+rel.replace('/','__'))
    dst.write_bytes(data)
    records.append({'original_path':str(REPO/rel),'snapshot':str(dst.relative_to(BASE)),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'use':'Procedural only; no candidate theorem content'})
(BASE/'procedural_inputs.json').write_text(json.dumps({'note':'Snapshots at phase1 freeze of the explicit procedural paths previously read; no broader inventory','files':records},ensure_ascii=False,indent=2)+'\n')

# Inventory only this newly owned phase1 directory; never enumerate repository evidence.
payload=[]
for p in sorted(BASE.rglob('*')):
    if p.is_file() and p.name not in {'manifest.json','receipt.json'}:
        b=p.read_bytes();payload.append({'path':str(p.relative_to(BASE)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'frozen_mode':'0444'})
manifest={'schema_version':1,'phase':'PHASE1_SOURCE_COGNITION','reviewer':'/root/zeroquery_fresh_source_2f8a71','candidate_exposure':False,'source_sha256':'6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915','payload_files':payload,'self_reference_policy':'manifest does not list manifest or receipt; receipt binds manifest; all files including both are frozen 0444'}
mp=BASE/'manifest.json';mp.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
receipt={'schema_version':1,'phase':'PHASE1_FROZEN_PAUSE','reviewer':'/root/zeroquery_fresh_source_2f8a71','frozen_at_utc':datetime.now(timezone.utc).isoformat(),'manifest_sha256':hashlib.sha256(mp.read_bytes()).hexdigest(),'cognition_sha256':hashlib.sha256((BASE/'cognition.md').read_bytes()).hexdigest(),'exposure_sha256':hashlib.sha256((BASE/'exposure.md').read_bytes()).hexdigest(),'source_inventory_sha256':hashlib.sha256((BASE/'source_inventory.json').read_bytes()).hexdigest(),'proof_inventory_sha256':hashlib.sha256((BASE/'source_proof_inventory.json').read_bytes()).hexdigest(),'payload_files':len(payload),'files_mode':'0444','directories_mode':'0555','allowed_next_phase':'Pause. No candidate exposure until root separately supplies selective type and anonymous reconstruction. Later work must use a new sibling phase directory.','authority':'Source-only cognition receipt; no sourceV/VERIFIED/STAB/native/site/browser/global or Goal claim','qualification':'Filename-only old evidence exposure and truncation disclosed; no pristine/pretraining-zero-knowledge guarantee'}
rp=BASE/'receipt.json';rp.write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
for p in BASE.rglob('*'):
    if p.is_file(): p.chmod(0o444)
for p in sorted([p for p in BASE.rglob('*') if p.is_dir()], key=lambda p:len(p.parts),reverse=True):p.chmod(0o555)
BASE.chmod(0o555)
for row in payload:
    p=BASE/row['path']; assert hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256'];assert stat.S_IMODE(p.stat().st_mode)==0o444
for p in (mp,rp):assert stat.S_IMODE(p.stat().st_mode)==0o444
print(json.dumps({'receipt':str(rp),'receipt_sha256':hashlib.sha256(rp.read_bytes()).hexdigest(),'manifest_sha256':receipt['manifest_sha256'],'cognition_sha256':receipt['cognition_sha256'],'exposure_sha256':receipt['exposure_sha256'],'payload_files':len(payload),'all_payload_hashes_and_modes_verified':True},indent=2))
