from pathlib import Path
import hashlib
import json

base=Path(__file__).resolve().parent
repo=Path('/Users/zhouhuanjian/ASTIS-GC')
E=repo/'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-cosine-gram-semantic-evidence'
seal=E.parent/'fixed-spectrum-cosine-gram-statement-seal.json'
sb=seal.read_bytes()
assert hashlib.sha256(sb).hexdigest()=='a5e464a34ee276e62267d21f0965c1a0b1ef905bed27e679a85ecee3cd7fd45c'
assert sb==(base/'W/statement-seal-v1.json').read_bytes()
(base/'public-statement-seal.json').write_bytes(sb)
records=[]
for p in sorted(E.rglob('*')):
    if not p.is_file():continue
    rel=p.relative_to(E)
    assert 'private' not in p.name.lower() or p.name=='private-origin-portable-definition-and-input-index.json',str(rel)
    b=p.read_bytes()
    records.append({'path':str(p),'relative_E_path':str(rel),'bytes':len(b),'raw_sha256':hashlib.sha256(b).hexdigest()})
(base/'public-E-inventory.json').write_text(json.dumps(records,indent=2)+'\n')
out=json.dumps({'public_seal_path':str(seal),'public_seal_matches_private_W_exactly':True,'public_seal_sha256':hashlib.sha256(sb).hexdigest(),'E_files':records},indent=2)+'\n'
(base/'read-public-evidence-inventory.stdout.txt').write_text(out);print(out,end='')
