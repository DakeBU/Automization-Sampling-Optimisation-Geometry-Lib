# Independent statement-only audit, projection v1

This phase follows the immutable raw-source preread whose manifest SHA256 is `f28aba1f8685285b11bda9c555af55f03e63b204938ab45125f8b637a3e5d47e`. The only newly received mathematical artifact is `strict-preproof-seal-projection-v1.json`, SHA256 `3b067b8fe683ec9654fe9b38b7ce72259a40ddd7efa3204283a75bb12f07cb53`. No proof body, Lean build result, extractor graph, root route rationale, full seal, or prior verdict was read.

## Verdict and exact scope

**ACCEPT the projected signatures as a numerical auxiliary family and a private actual diagonal-Gaussian bad-event statement.** This is statement/definition acceptance only, not proof acceptance. The producer is not the concentration assertion of Lemma 4.4, and the private consumer is not the full rotated detector, Eq. 26, or Theorem 4.1.

The producer's conclusion is precisely nonnegativity of literal tau, tau<=1/2, and tau<=beta/4 for the literal Gaussian beta, eventually uniformly in d,kappa,q after fixing C and delta. The private consumer bounds the actual bad event of the shifted signed cosine form by 1/10 under that literal Gaussian. The scope projection is mathematically consistent with those signatures. No source correction, human waiver, or RULED binder is asserted.

The projected signatures cannot be relabeled as literal statements of Lemma 4.4 or Theorem 4.1. In such a relabeling, universal positive C would not replace the source's existential sufficiently large concentration constant, and C/hC would not become new main-theorem premises. This limitation is part of acceptance, not a deferred proof decision.

## Quantifier and binder audit

Both signatures have the order

`forall C>0, forall delta in (0,1), exists d0, forall d>=d0, forall kappa in [2,d^(1-delta)], forall natural q under the stated cap, ...`.

Thus d0 may depend on C and delta, but not on later d, kappa or q. The source proof's eventual numerical estimates remain valid for each fixed positive numeric scale; their hidden comparison constants may absorb that scale. There is no assertion of one cutoff uniform over all unbounded C. At later application to the source lower bound, the actual sufficiently large absolute concentration C must already have been fixed from its separate source argument. Specializing this numerical family to that fixed C does not establish the separate concentration property. Conversely, proving the numerical family needs no concentration property.

For the requested auxiliary-family interfaces the full binder inventory is:

| Binder | Classification for this family and correspondence |
| --- | --- |
| C : real | Explicit numerical-family scale parameter; domain extension of the literal tau expression, not a concentration witness. |
| hC : 0<C | Explicit positive-scale domain of that numerical family. No bound, event or producer conclusion is assumed. |
| delta : real; 0<delta; delta<1 | SOURCE range of the Section 4.3 eventual step. |
| d0 : natural, existential conclusion | The cutoff to be proved, not an input hypothesis. It follows C and delta. |
| d : natural | TYPING integer dimension. The eventual cutoff must internally ensure d>=2; no source standing dimension is lost by allowing the conclusion to choose a larger cutoff. |
| d0<=d | SOURCE eventual range, relative to the existentially produced cutoff. |
| kappa : real; 2<=kappa; kappa<=d^(1-delta) | SOURCE parameter range. |
| q : natural; real(q)<=delta*sqrt(kappa)*log(d)/256 | SOURCE query-index range and cap; natural typing retains q>=0, including q=0. No algorithm is quantified by these numerical helpers. |
| n,theta,eigenvalue,Lambda,mu,Q,tau,M,b,beta | Let-bound literal objects, not independent inputs or hidden proof hypotheses. The private consumer omits M,b,beta because its event conclusion uses none of them. |

The strict five-bin SOURCE/STANDING/TYPING/RULED/EXCESS source-anchor audit applies when an interface is claimed to be a source anchor. Here C/hC are a declared generalization parameter/domain of an auxiliary numerical family. They must not be recorded as human RULED or as source premises of the main lower bound. If these exact signatures were instead registered as Lemma 4.4 or Theorem 4.1, that anchor interpretation would fail the binder audit. No extra integrability, covariance, moment, concentration, sign, event-success, or eventual-smallness premise appears in either projected signature. There are no project-owned Prop aliases to expand in the supplied signatures.

## Definition audit

1. `n : natural := 2*q+1` is literal. It is always >=1; n<d is an eventual internal obligation, not an existing binder.
2. `theta i := (real(i.val)+1/2)*pi/real(d)` is exactly source theta_j=(j-1/2)pi/d under j=i.val+1. The zero-based finite-index shift is correct.
3. The eigenvalue affine cosine expression and `Matrix.diagonal eigenvalue` agree with the source precision Lambda. With kappa>=2 and |cos|<=1, every eigenvalue is >=1. That proof is internal. Matrix inverse is the standard total inverse operation; positivity must establish that it is the intended inverse covariance here.
4. `multivariateGaussian 0 Lambda^-1` is the actual centered diagonal Gaussian with the intended inverse precision covariance once the internal spectral/inverse semantics are established. It is not a variable law constrained by a new certificate. This statement audit accepts the standard mathematical meaning of the named imported Gaussian construction; it does not audit its library implementation, elaborate its type, or infer a Lean success.
5. `Q x := sum_i cos(real(n)*theta i)*(WithLp.ofLp x i)^2` is the source quadratic form x^T D_n x in Euclidean coordinates. There is no absolute value, sign or shift inside Q itself; those are applied exactly where specified later.
6. Tau has all source factors exactly: real(q)+1; sqrt(log(real(d))/real(d)); then ((real(q)+1)*(real(q)+1+log(real(d)))*log(real(d)))/real(d). It is C times the sum. The second term's extra log factor is present. The real casts occur before +1. Tau is not replaced by its asymptotic upper bound.
7. The producer defines M by the actual norm-square integral and local `b` by the actual Q integral; beta=abs(b)/M. Its local `b` is source mu_n, not the distinct fixed positive source constant `(1-exp(-4))*exp(-3)` also named b in Section 4.3. This naming difference is harmless in the signature but must not confuse graph nodes or displayed formulas. Integrability and M>0 are internal mathematical obligations; Lean's total integral/real division do not, by themselves, establish those meanings.
8. Standard total operations give formula values outside the eventual source region (for example d=0), but no explicit existence-test/default/fallback branch has been introduced. The theorem may choose d0>=2. Literal agreement is asserted on the full source carrier; no off-source default is used to prove a source assertion.
9. The private event is exactly `{x | (-1)^n*Q(x)-2*tau*norm(x)^2 <= 0}`. It includes x=0, as does the source detector's bad event. It is the complement of the source strict good event Z>0, before orthogonal transport. No x!=0 premise or ratio event changes the endpoint.
10. Taking `.toReal` of the event mass is faithful only after establishing finiteness of the literal Gaussian measure (indeed probability mass one). This is an internal obligation of the proof, not a statement premise. No arbitrary extended mass or potentially infinite input measure appears in the signature.

## Obligations retained for later topology/proof checks

These are not added binders and are not proved by this audit:

- An eventual uniform choice must establish all positive-dimension, n<d and d-n>=sqrt(kappa) conditions used by target moment estimates, and absorb the +1 terms for q=0 as well as other q.
- Literal Gaussian law semantics, inverse identities, coordinate moments, integrability, and positivity of M/beta must be supplied internally.
- The producer's output does not include M*beta^2>=320. The private consumer still needs that source signal-mass growth or another sufficient internal estimate; it cannot assume it as an extra public premise.
- The private shifted-variance estimate must use both actual target variance bounds and centered L2 triangle (or another correctly labeled proof route). The two forms share x; independence/variance additivity is not licensed.
- A producer theorem for scalar smallness is not evidence for the concentration C of Lemma 4.4. Later graph records must distinguish the fixed numeric family parameter from the source concentration witness and keep the latter outside this claimed delta.
- The source statement's full rotated event needs additional transport and matrix-polynomial identities. They are expressly outside these exact projected signatures.

No proof search permission or theorem-completion status follows from this acceptance. Freeze this phase before receiving any graph; the next permitted artifact is the separately prepared source node/edge/coverage graph for topology challenge, without Lean implementation or private rationale.
