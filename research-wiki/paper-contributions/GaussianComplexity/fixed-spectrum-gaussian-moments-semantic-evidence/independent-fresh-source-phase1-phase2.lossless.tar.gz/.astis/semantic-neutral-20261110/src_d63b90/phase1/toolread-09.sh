mkdir -p .astis/semantic-neutral-20261110/src_d63b90/phase1 && cat > .astis/semantic-neutral-20261110/src_d63b90/extract_source.py <<'PY'
from html.parser import HTMLParser
from pathlib import Path
from dataclasses import dataclass, field
import json, hashlib, sys
ROOT=Path('/Users/zhouhuanjian/ASTIS-GC')
SOURCE=ROOT/'.astis/huanjian-resume-20261103/2610.20492v1.html'
OUT=ROOT/'.astis/semantic-neutral-20261110/src_d63b90/phase1'
raw=SOURCE.read_bytes(); html=raw.decode('utf-8')
EXPECTED='6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
assert hashlib.sha256(raw).hexdigest()==EXPECTED
lines=[0]
for i,c in enumerate(html):
    if c=='\n': lines.append(i+1)
@dataclass
class Node:
    tag:str
    attrs:dict
    start:int
    end:int=0
    parent:object=None
    parts:list=field(default_factory=list)
    children:list=field(default_factory=list)
class Parser(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True); self.root=Node('root',{},0,len(html)); self.stack=[self.root]; self.ids={}
    def pos(self):
        l,c=self.getpos(); return lines[l-1]+c
    def handle_starttag(self,tag,attrs):
        n=Node(tag,dict(attrs),self.pos(),parent=self.stack[-1]); self.stack[-1].parts.append(n); self.stack[-1].children.append(n)
        if n.attrs.get('id'): self.ids[n.attrs['id']]=n
        if tag not in {'area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr'}: self.stack.append(n)
        else: n.end=self.pos()+len(self.get_starttag_text())
    def handle_startendtag(self,tag,attrs):
        self.handle_starttag(tag,attrs)
        if self.stack[-1].tag==tag: self.stack.pop().end=self.pos()+len(self.get_starttag_text())
    def handle_endtag(self,tag):
        for j in range(len(self.stack)-1,0,-1):
            if self.stack[j].tag==tag:
                end=html.find('>',self.pos())+1
                for n in self.stack[j:]: n.end=end
                del self.stack[j:]
                return
    def handle_data(self,data): self.stack[-1].parts.append(data)
p=Parser(); p.feed(html)
def textnode(n):
    if n.tag=='math': return '$'+n.attrs.get('alttext','[MISSING ALTTEXT]')+'$'
    if n.tag in {'script','style','svg','annotation'}: return ''
    val=''.join(t if isinstance(t,str) else textnode(t) for t in n.parts)
    return ('\n'+val+'\n') if n.tag in {'div','section','p','table','tr','h1','h2','h3','h4','h5','h6','li'} else val

def extract(ident):
    n=p.ids[ident]; assert n.end>n.start
    fragment=html[n.start:n.end].encode('utf-8')
    f=OUT/(ident+'.html'); f.write_bytes(fragment)
    t=OUT/(ident+'.txt'); t.write_text(textnode(n))
    return {'id':ident,'source_char_range':[n.start,n.end], 'source_line_range':[html.count('\n',0,n.start)+1,html.count('\n',0,n.end)+1], 'raw_path':str(f.relative_to(ROOT)), 'raw_sha256':hashlib.sha256(fragment).hexdigest(), 'text_path':str(t.relative_to(ROOT)), 'text_sha256':hashlib.sha256(t.read_bytes()).hexdigest()}
if sys.argv[1]=='inspect':
    for ident in ['S4.SS1','S4.Thmtheorem5','A3.SS3']:
        n=p.ids[ident]
        print(json.dumps({'id':ident,'parent':n.parent.attrs.get('id'), 'sibling_structures':[{'tag':s.tag,'id':s.attrs.get('id'),'class':s.attrs.get('class')} for s in n.parent.children if s.tag in {'section','div'}]}))
elif sys.argv[1]=='extract':
    ids=sys.argv[2:]
    result={'source':str(SOURCE.relative_to(ROOT)),'source_sha256':EXPECTED, 'extractor_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'extracts':[extract(i) for i in ids]}
    mf=OUT/'raw-inputs-manifest.json'
    if mf.exists():
        old=json.loads(mf.read_text()); result['extracts']=old['extracts']+[r for r in result['extracts'] if r['id'] not in {x['id'] for x in old['extracts']}]
    mf.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
PY
python3 .astis/semantic-neutral-20261110/src_d63b90/extract_source.py inspect
