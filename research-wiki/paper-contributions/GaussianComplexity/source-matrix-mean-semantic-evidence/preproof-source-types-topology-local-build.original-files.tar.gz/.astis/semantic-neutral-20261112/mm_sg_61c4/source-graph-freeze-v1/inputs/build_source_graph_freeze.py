from pathlib import Path
import json,hashlib,datetime,shutil
ROOT=Path('/Users/zhouhuanjian/ASTIS-GC');BASE=ROOT/'.astis/semantic-neutral-20261112/mm_sg_61c4'
RAW=BASE/'raw-freeze-v1';TYPE=BASE/'type-freeze-v1';OUT=BASE/'source-graph-freeze-v1'
def sha(b):return hashlib.sha256(b).hexdigest()
def j(p):return json.loads(p.read_text())
assert not OUT.exists()
rm=(RAW/'freeze-manifest.json').read_bytes();tm=(TYPE/'freeze-manifest.json').read_bytes()
assert sha(rm)=='4daf44e6a41b758d624abc58eaa9ac78101c7d43e309fe5554fcac3dd40d2ac7'
assert sha(tm)=='fb51437ebd9e6d36241e4c84637a2d1e168f11c75818edef785c7b4a9a2c474c'
for f in [RAW,TYPE]:
 for x in j(f/'freeze-manifest.json')['files']:
  b=(f/x['path']).read_bytes();assert len(b)==x['bytes'] and sha(b)==x['sha256']
ta=j(TYPE/'type-audit.json');assert sha((TYPE/'type-audit.json').read_bytes())=='57478b54ec7f5bd2ecc7b5ef0fa4761d271eda6cbfde1c6f2075b54002f1ae90'
inv=j(RAW/'atomic-inventory.json');src=j(RAW/'locators-and-source-units.json');units=src['source_units']
packet=j(TYPE/'inputs/selective-type-definition-packet.json')
OUT.mkdir();(OUT/'inputs').mkdir()
def dump(n,v):(OUT/n).write_text(json.dumps(v,ensure_ascii=False,sort_keys=True,indent=2)+'\n',encoding='utf-8')
def write(n,t):(OUT/n).write_text(t,encoding='utf-8')
bind=dict(ta['bindings'],type_audit_sha256=sha((TYPE/'type-audit.json').read_bytes()),type_freeze_manifest_sha256=sha(tm))
(OUT/'inputs/raw-freeze-v1.manifest.json').write_bytes(rm);(OUT/'inputs/type-freeze-v1.manifest.json').write_bytes(tm)
shutil.copyfile(TYPE/'type-audit.json',OUT/'inputs/type-audit.json')
shutil.copyfile(BASE/'working/build_source_graph_freeze.py',OUT/'inputs/build_source_graph_freeze.py')
qual={'version':1,'raw_created_utc':json.loads(rm)['created_utc'],'type_created_utc':json.loads(tm)['created_utc'],
 'global_exact_seal_creation':'Parent reports 2026-11-12 12:25:43 UTC; this actor did not open the separate seal artifact or independently verify its timestamp.',
 'correct_order':'Global exact seal existed; this actor independently completed its raw source freeze before first opening the selective typed packet; the type verdict froze next; this source graph was constructed only afterwards.',
 'raw_phase_label_qualification':'RAW_PROSE_ONLY_BEFORE_STATEMENT_SEAL and statement_seal_seen=false in the original raw manifest mean before THIS ACTOR exposure to the new seal/types. They must not be read as asserting that no global exact seal yet existed.',
 'preservation':'Original raw and type freeze bytes are not changed or re-sealed. This explicit qualification preserves chronology instead of rewriting history.',
 'acceptance':'No graph/type/topology acceptance or permission is inferred from creation times or hashes.'}
dump('chronology-qualification.json',qual)

# Internal proof applicability is distinguished from a genuine source defect/gap.
spec=[
 ('INTERNAL.row-law-applicability','Source-to-canonical experiment applicability','Apply/derive the physical-row marginal N(0,I_r) law and row measurability for the exact sealed Omega,mu,row. The parent reports a canonical row-law node exists, but its signature/proof is not exposed here and no compiled parent is certified.',['c2.row-marginal-law','c2.actual-gamma']),
 ('INTERNAL.scalar-a-integrability','Source-implicit well-definedness','Establish integrability of the canonical retained-radius scalar integrand under stdGaussian E. The Bochner definition of a must not silently depend on the default-zero branch. No public hypothesis is added.',['mean.literal-a','cutoff.L']),
 ('INTERNAL.a-row-identification','Measure/integral transport applicability','Use the exact row law to identify the canonical-law a with (1/r)E_mu[R_i1_(R_i<=L)] for every physical i. Verify measurability/integrability and exact cutoff conventions.',['mean.literal-a','mean.a-common']),
 ('INTERNAL.radial-moment-applicability','Canonical radial-moment applicability','Apply/derive the retained standard-r-Gaussian outer-product mean aI_r and its integrability, matching exact L,r,a. The reported canonical truncated radial-moment node is a potential reuse, not a newly inspected proof.',['mean.radial-symmetry-invocation','mean.truncated-row-outer-product']),
 ('INTERNAL.actual-row-moment-transport','Measure/integral transport applicability','Transport the canonical truncated outer-product moment and integrability to the same actual original-column row, preserving WithLp.ofLp coordinates and the same mu.',['mean.truncated-row-outer-product','c2.actual-gamma']),
 ('INTERNAL.actual-Y-integrability','Finite matrix/norm applicability','Prove actual Y_i AEStronglyMeasurable and with finite norm integral in the synthesized complete Matrix L2 operator-norm space. Fixed tensor factors, cutoff, scalar action and probability/moment bounds must apply internally.',['Yi.actual-definition']),
 ('INTERNAL.mean-transport-CLM','Alternative internal transport option','Construct/apply the continuous linear map M -> d^-1*(M tensor t_i t_i^T), verify domain/codomain norms and integrability, commute it with the Bochner integral, and identify its action on aI.',['Yi.actual-definition','mean.actual-Y']),
 ('INTERNAL.mean-transport-entrywise','Alternative internal transport option','Use continuous entry evaluations and finite real-coordinate integral equalities to identify the same matrix expectation; verify equivalence with the actual finite-dimensional Bochner integral and all integrability requirements.',['Yi.actual-definition','mean.actual-Y']),
 ('INTERNAL.mean-transport-result','OR route join, not a new source hypothesis','Obtain the actual mean by either verified CLM transport or verified finite-entry transport; do not require both routes as an AND. The source does not choose either implementation bookkeeping route.',['mean.actual-Y']),
 ('INTERNAL.literal-frame-applicability','Deterministic source identity applicability','Match exact literal theta,t,n,r to both source Fact C.5 Gram identities, including constant coordinate, q=0 and frequency range. Reported canonical cosine-frame nodes remain potential unverified reuse until exact applications are checked.',['c5.t-Gram','c5.weighted-t-Gram']),
 ('INTERNAL.tensor-and-sum-algebra','Finite tensor/frame algebra applicability','Use exact actual means and the two deterministic frame identities to obtain the two Ex110 sums of means, with I_r tensor I_r identified with I_(r^2) in Gaussian-first paired order and d nonzero internally.',['consumer.sum-means','consumer.weighted-sum-means']),
 ('INTERNAL.actual-sums-integrability','Finite integral applicability','Derive integrability of both actual finite sums from all actual Y integrability and deterministic scalar weights. No independence is needed.',['A3.Ex110','consumer.weighted-expectation-conclusion']),
 ('INTERNAL.finite-Bochner-exchange','Finite integral/constant-scalar exchange applicability','Commute both actual finite sums and each deterministic cosine scalar with the Bochner integral only after discharging actual integrability; use exact Ex110 mean sums to get the expected actual sums.',['consumer.sum-means','consumer.weighted-sum-means','consumer.weighted-expectation-conclusion'])]
ports=[{'id':id,'kind':k,'obligation':m,'source_context':a,'status':'OPEN_INTERNAL_PROOF_APPLICABILITY','SOURCE_GAP':False,'actual_compiled_parents':[]} for id,k,m,a in spec]
dump('internal-ports-and-source-gaps.json',{'bindings':bind,'ports':ports,
 'genuine_source_gaps':[],'source_gap_definition':'A genuine source defect, ill-posedness, missing mathematical source premise or source claim not supported by the bounded source. Ordinary omitted proofs, existing theorem applicability and Lean/Bochner bookkeeping remain INTERNAL ports here.',
 'no_new_source_hypotheses':True,'no_new_target_proof_or_compiled_parent_claims':True,
 'integrability_routes_note':'Raw notes permit bounded truncation or a justified Gaussian-moment domination route. These are possible internal alternatives and not extra source premises. The graph does not join them into a false AND.'})

nodes=[{'id':v['id'],'kind':v['kind'],'meaning':v['meaning'],'source_element_id':v['source_element_id'],'locator':v['locator'],'status':'SOURCE_NODE_UNPROVED_IN_THIS_AUDIT'} for v in inv['items'] if v['disposition']=='NODE']
nodes += [{'id':v['id'],'kind':v['kind'],'meaning':v['obligation'],'status':v['status']} for v in ports]
nodes += [
 {'id':'OUTPUT.all-Y-integrable','kind':'Source-implicit target output','meaning':'All actual Y_i are Bochner integrable under exact mu.','status':'UNPROVED_TARGET_OUTPUT'},
 {'id':'FORMAL.producer','kind':'Exact sealed target conjunction','name':packet['producer']['name'],'signature_sha256':packet['producer']['signature_sha256'],'status':'SEALED_UNPROVED_TARGET'},
 {'id':'OUTPUT.both-sums-integrable','kind':'Source-implicit target output','meaning':'Both actual finite sums under exact mu are integrable.','status':'UNPROVED_TARGET_OUTPUT'},
 {'id':'OUTPUT.expected-actual-sums','kind':'Source-supported finite-exchange target output','meaning':'E_mu[sum_i Y_i]=a I_(r^2) and E_mu[sum_i cos((2q+1)theta_i)Y_i]=0.','status':'UNPROVED_TARGET_OUTPUT'},
 {'id':'FORMAL.private-consumer','kind':'Exact sealed target conjunction','name':packet['actual_private_consumer']['name'],'signature_sha256':packet['actual_private_consumer']['signature_sha256'],'status':'SEALED_UNPROVED_TARGET'}]
edges=[]
def e(a,b,anchor,meaning,kind='direct source consumer use'):
 if isinstance(anchor,str):anchor=[anchor]
 ls=[]
 for id in anchor:
  if id in units:ll=units[id]['locator']
  else:
   # Parent containers are present in own frozen source; derive exact locators here without opening original again.
   text=(RAW/'inputs/2610.20492v1.html').read_bytes();ss=text.decode();import re
   m=re.search(r'<([A-Za-z][\w:]*)\b[^>]*\bid="'+re.escape(id)+r'"[^>]*>',ss);assert m,id
   dep=1
   for z in re.finditer(r'</?'+m[1]+r'\b[^>]*>',ss[m.end():]):
    dep+=-1 if z[0].startswith('</') else 1
    if not dep:end=m.end()+z.end();break
   start=m.start();bs=len(ss[:start].encode());be=len(ss[:end].encode())
   ll={'utf8_byte_start':bs,'utf8_byte_end_exclusive':be,'unicode_char_start':start,'unicode_char_end_exclusive':end,'lf_line_start_1based':ss.count('\n',0,start)+1,'lf_line_end_1based':ss.count('\n',0,end-1)+1,'raw_fragment_sha256':sha(text[bs:be])}
  ls.append({'element_id':id,'locator':ll})
 edges.append({'from':a,'to':b,'kind':kind,'consumer_use_sites':ls,'meaning':meaning,'compiled_dependency':False})

# Literal source definitions and explicit deterministic C.5 proof uses.
e('grid.theta','c2.literal-t','A3.Ex85','Literal midpoint grid in the feature formula.')
e('c2.r','c2.actual-gamma','A3.Ex85','The physical row has the r original Gaussian-column entries.')
e('experiment.independent-standard-columns','c2.row-marginal-law','A3.SS2.p1.2','Source asserts the standard r-Gaussian row law in the same experiment; omitted proof remains an internal applicability port.','source-supported omitted inference, not a compiled edge')
e('c2.actual-gamma','c2.row-marginal-law','A3.SS2.p1.2','The law is about these physical rows.')
e('c2.actual-gamma','c2.B-normalization-context','A3.SS2.p1.2','B row fixes Gaussian-first tensor convention.')
e('c2.literal-t','c2.B-normalization-context','A3.SS2.p1.2','B row has deterministic t second.')
e('c5.theta-recall','c5.cosine-telescope','A3.Ex88','The half-grid supplies the adjacent sine difference.')
e('c5.frequency-domain','c5.cosine-telescope','A3.Ex88','Integer nonzero frequency domain.')
e('c5.cosine-telescope','c5.cosine-endpoints','A3.Ex89','Telescoping leaves the sine endpoints.')
e('c5.cosine-endpoints','c5.cosine-zero','A3.SS2.p4.2','Endpoint zero plus the nonzero sine factor yields cosine zero.')
e('c5.frequency-domain','c5.cosine-zero','A3.SS2.p4.2','The sine-factor nonzero check uses 0<|k|<2d.')
e('c2.literal-t','c5.constant-coordinate-sum','A3.Ex90','Constant coordinate contributes d.')
e('c2.literal-t','c5.mixed-coordinate-sum','A3.Ex90','Mixed coordinate normalization is sqrt2.')
e('c5.cosine-zero','c5.mixed-coordinate-sum','A3.Ex90','Positive feature frequency sum vanishes.')
e('c2.literal-t','c5.positive-feature-product','A3.Ex91','Two sqrt2 feature factors produce 2cos cos.')
e('c5.product-to-sum-invocation','c5.frequency-split','A3.Ex92','Product-to-sum creates j-k and j+k.')
e('c5.positive-feature-product','c5.frequency-split','A3.Ex92','Rewrite the actual feature-coordinate sum.')
e('c5.frequency-split','c5.diagonal-offdiagonal','A3.Ex93','The diagonal has zero frequency; off-diagonal terms vanish.')
e('c5.cosine-zero','c5.diagonal-offdiagonal','A3.Ex93','Apply the earlier cosine identity at nonzero admissible frequencies.')
for a in ['c5.constant-coordinate-sum','c5.mixed-coordinate-sum','c5.diagonal-offdiagonal']:
 e(a,'c5.frequency-check-and-Gram','A3.SS2.p5.3','These entry cases, with stated frequency checks and symmetry, cover the full Gram matrix.')
e('standing.naturals-and-range','c5.frequency-check-and-Gram','A3.SS2.p5.3','The standing q,d range supplies the frequency inequalities.')
e('c5.frequency-check-and-Gram','c5.t-Gram','A3.SS2.p5.3','Author proves the exact unweighted t Gram identity.')
e('c2.n','c5.n-domain-context','A3.SS2.p7.1','n=2q+1 at the weighted identity use.')
e('c5.n-domain-context','c5.weighted-frequency-range','A3.Ex96','0<=j,k<=q and n=2q+1.')
e('standing.naturals-and-range','c5.weighted-frequency-range','A3.Ex96','The strict source range implies all n±j±k are below 2d.')
e('c5.cosine-zero','c5.invoke-cosine-zero','A3.SS2.p7.2','Explicit reuse of the earlier cosine-sum identity.')
e('c5.triple-cosine-sum','c5.four-frequencies','A3.Ex98','Expand the triple cosine product.')
e('c5.four-frequencies','c5.weighted-cosine-zero','A3.Ex99','Each of four cosine sums vanishes.')
e('c5.weighted-frequency-range','c5.weighted-cosine-zero','A3.Ex99','All four frequencies lie in the proven nonzero admissible range.')
e('c5.invoke-cosine-zero','c5.weighted-cosine-zero','A3.Ex99','Apply the earlier exact cosine identity.')
e('c5.weighted-cosine-zero','c5.weighted-Gram-entry-conclusion','A3.SS2.p7.3','Each entry is a constant multiple of a vanishing sum.')
e('c2.literal-t','c5.weighted-Gram-entry-conclusion','A3.SS2.p7.3','Literal feature entries identify the weighted t Gram matrix.')
e('c5.weighted-Gram-entry-conclusion','c5.weighted-t-Gram','A3.SS2.p7.3','Author proves the exact weighted t Gram identity.')
e('c2.actual-gamma','cutoff.R','A3.SS2.p10.m2','Actual row radius.')
e('c2.r','cutoff.L','A3.SS2.p10.m1','Exact r in the source cutoff.')
for a in ['c2.actual-gamma','c2.literal-t','cutoff.R','cutoff.L']:
 e(a,'Yi.actual-definition','A3.Ex107','Literal actual-Y factor/cutoff at its definition.')
e('mean.radial-symmetry-invocation','mean.truncated-row-outer-product','A3.Ex108','Author invokes radial symmetry for the retained outer-product mean.','explicit source proof invocation; derivation not closed here')
e('cutoff.R','mean.literal-a','A3.Ex108','Source defines a by the retained radius.')
e('cutoff.L','mean.literal-a','A3.Ex108','Same closed truncation threshold.')
e('mean.literal-a','mean.a-common','A3.SS2.p12.3','Same scalar definition for all i.')
e('c2.row-marginal-law','mean.a-common','A3.SS2.p12.3','Common standard row laws support the unnamed common-a assertion.','source-supported omitted inference')
for a in ['Yi.actual-definition','mean.truncated-row-outer-product','mean.a-common']:
 e(a,'mean.actual-Y','A3.SS2.p12.4','Actual per-row matrix mean follows from this literal factor/retained moment/common scalar.','source-supported omitted expectation transport')
for a in ['mean.actual-Y','c5.t-Gram']:
 e(a,'consumer.sum-means',['A3.SS2.p12.4','A3.Ex110'],'Direct actual-mean and Fact C.5 use for the unweighted sum.')
for a in ['mean.actual-Y','c5.weighted-t-Gram']:
 e(a,'consumer.weighted-sum-means',['A3.SS2.p12.4','A3.Ex110'],'Direct actual-mean and Fact C.5 use for the weighted sum.')
e('mean.FactC5-use','consumer.sum-means','A3.Ex110','Explicit source citation use at the consumer.')
e('mean.FactC5-use','consumer.weighted-sum-means','A3.Ex110','Explicit source citation use at the consumer.')
e('consumer.weighted-sum-means','consumer.weighted-expectation-conclusion','A3.SS2.p12.5','Source concludes zero expectation of the actual weighted sum; exchange remains internal.','source-supported omitted finite-integral exchange')

# Post-seal internal applicability and target correspondence; no actual proof call is claimed.
for a in ['c2.row-marginal-law','c2.actual-gamma']:
 e(a,'INTERNAL.row-law-applicability','A3.SS2.p12.4','Match the source physical-row law to exact sealed Omega,mu,row.','INTERNAL applicability')
e('mean.literal-a','INTERNAL.scalar-a-integrability','A3.Ex108','Source coefficient integral must be genuinely integrable.','INTERNAL well-definedness')
for a in ['INTERNAL.row-law-applicability','INTERNAL.scalar-a-integrability','mean.literal-a','mean.a-common']:
 e(a,'INTERNAL.a-row-identification','A3.Ex108','Identify exact canonical scalar a with each physical retained-radius mean.','INTERNAL integral transport')
for a in ['mean.truncated-row-outer-product','INTERNAL.scalar-a-integrability']:
 e(a,'INTERNAL.radial-moment-applicability','A3.Ex108','Match/apply the canonical retained standard-Gaussian moment.','INTERNAL applicability')
for a in ['INTERNAL.row-law-applicability','INTERNAL.a-row-identification','INTERNAL.radial-moment-applicability']:
 e(a,'INTERNAL.actual-row-moment-transport','A3.SS2.p12.4','Derive the actual physical-row retained moment with exact source scalar.','INTERNAL integral transport')
for a in ['Yi.actual-definition','INTERNAL.actual-row-moment-transport']:
 e(a,'INTERNAL.actual-Y-integrability','A3.SS2.p12.4','Discharge actual matrix integrability under the selected norm internally.','INTERNAL integrability')
for route in ['INTERNAL.mean-transport-CLM','INTERNAL.mean-transport-entrywise']:
 for a in ['INTERNAL.actual-row-moment-transport','INTERNAL.actual-Y-integrability','Yi.actual-definition']:
  e(a,route,'A3.SS2.p12.4','Inputs for this alternative internal expectation-transport method.','INTERNAL alternative route')
# OR route choice is represented only by a hyperedge below, not false AND direct prerequisites.
e('INTERNAL.mean-transport-result','FORMAL.producer','A3.SS2.p12.4','Exact all-i mean output of the producer.','sealed-target correspondence, not a compiled edge')
e('INTERNAL.actual-Y-integrability','OUTPUT.all-Y-integrable','A3.Ex107','Source-implicit random-matrix integrability output.','sealed-target correspondence')
e('OUTPUT.all-Y-integrable','FORMAL.producer','A3.Ex107','Exact producer integrability conjunct.','sealed-target correspondence')
for a in ['c5.t-Gram','c5.weighted-t-Gram','c2.literal-t','grid.theta','c2.n']:
 e(a,'INTERNAL.literal-frame-applicability',['A3.SS2.p12.4','A3.Ex110'],'Match literal sealed definitions to exact source frame identities.','INTERNAL applicability')
for a in ['FORMAL.producer','INTERNAL.literal-frame-applicability']:
 e(a,'INTERNAL.tensor-and-sum-algebra','A3.Ex110','Required intended material producer/frame use; implementation has not been seen.','INTERNAL intended consumer use')
e('FORMAL.producer','INTERNAL.actual-sums-integrability','A3.Ex110','All actual Y integrable gives both finite deterministic-weighted sums integrable.','INTERNAL intended consumer use')
e('INTERNAL.actual-sums-integrability','OUTPUT.both-sums-integrable','A3.Ex110','Private consumer integrability outputs.','sealed-target correspondence')
for a in ['FORMAL.producer','INTERNAL.tensor-and-sum-algebra','INTERNAL.actual-sums-integrability']:
 e(a,'INTERNAL.finite-Bochner-exchange',['A3.Ex110','A3.SS2.p12.5'],'Exchange actual finite sums and deterministic weights with the integral.','INTERNAL integral exchange')
e('INTERNAL.finite-Bochner-exchange','OUTPUT.expected-actual-sums',['A3.Ex110','A3.SS2.p12.5'],'Exact actual-integral aI/0 conclusions.','sealed-target correspondence')
for a in ['OUTPUT.both-sums-integrable','OUTPUT.expected-actual-sums']:
 e(a,'FORMAL.private-consumer',['A3.Ex110','A3.SS2.p12.5'],'Private consumer exact output conjunction.','sealed-target correspondence')

graph={'version':1,'bindings':bind,'source_root_full_path':str(BASE),'state':'POST_TYPE_FREEZE_SOURCE_GRAPH_EXTRACTED_UNPROVED',
 'chronology_qualification_sha256':sha((OUT/'chronology-qualification.json').read_bytes()),'roots':['FORMAL.producer','FORMAL.private-consumer'],
 'nodes':nodes,'edges':edges,'hyperedges':[{'id':'OR.mean-transport','kind':'INTERNAL alternative sufficient routes','premise_formula':'INTERNAL.mean-transport-CLM OR INTERNAL.mean-transport-entrywise','conclusion':'INTERNAL.mean-transport-result','status':'OPEN_NOT_A_CLOSED_PROOF','origin':'Inferred formal bookkeeping options, not two routes attributed to the source author.'}],
 'genuine_source_gaps':[],
 'forbidden_edges':['No joint-row-independence or iid claim is a mean/finite-linearity prerequisite.','No caller integrability, actual-row moment, formal mean matrix or scalar-a certificate.','No imported/named canonical node becomes a compiled proof parent without exact checked applicability.','No tail/common-event/bias/PSD/variance/concentration node is a parent of these exact means.','No Bochner default-zero branch substitutes for target integrability.'],
 'independent_topology_coverage_acceptance':'PENDING_DISTINCT_CHALLENGER. This actor cannot accept own extracted coverage.',
 'implementation_seen':False,'new_target_compiled':False,'compiled_parents':[],'permission_or_status_grant':False}
dump('source-proof-graph.json',graph)

coverage=j(RAW/'coverage.json');post=[]
for a in inv['items']:
 v=dict(a);v['post_seal_disposition']=a['disposition'];v['disposition_change']=False;v['post_seal_status']='SOURCE_REPRESENTED_NOT_PROVED' if a['disposition']=='NODE' else 'OUTSIDE_SELECTED_TARGET'
 post.append(v)
dump('post-seal-coverage.json',{'version':1,'bindings':bind,'source_root_full_path':str(BASE),'bounded_scope':inv['scope'],'items':post,'continuous_window':coverage['continuous_window'],'units':coverage['units'],'outside_window_exclusions':coverage['outside_window_exclusions'],'counts':inv['counts'],
 'type_induced_disposition_changes':[],'independent_coverage_approval':'PENDING_DISTINCT_CHALLENGER','raw_bytes_unchanged':True,'whole_paper_coverage':False})

write('source-reading-report.md','The post-seal graph represents the exact actual-Y producer and real two-sum Bochner consumer after the independent type verdict froze. All 79 raw atom dispositions remain unchanged. The source directly invokes radial symmetry at Ex108 and Fact C.5 at p12.4/Ex110. Internal ports retain exact row-law applicability, scalar-a integrability/identification, radial moment application, actual-row integral transport, matrix integrability, tensor/CLM or entrywise expectation transport, literal frame applicability and finite Bochner exchange. None is labelled a genuine SOURCE_GAP. No genuine source defect was found. The OR transport routes are inferred implementation options, never falsely conjoined or attributed as two source-authored proofs. No implementation or compiled new target was read. Independent topology/coverage acceptance remains with a distinct challenger. Read chronology-qualification.json: the global seal already existed before this actor raw freeze; raw precedes this actor first type exposure only.\n')
dump('graph-exposure-record.json',{'bindings':bind,'read_allowlist':'Own new mean raw/type frozen artifacts and their pinned source/protocol snapshots only. No original source was reopened in this graph stage; exact source locators come from own pinned snapshot.','other_graph_or_old_verdict_read':False,'implementation_or_API_search':False,'formalizer_API_pristine':False,'chronology':qual,'type_verdict_before_graph':True,'no_compiled_parent_claims':True,'no_admission_or_permission_grant':True})
write('README.md','Post-seal source graph, created AFTER independent type verdict freeze. Read source-proof-graph.json, post-seal-coverage.json, internal-ports-and-source-gaps.json and chronology-qualification.json. Ordinary internal applicability ports are not genuine source gaps. Independent topology challenger acceptance is pending. Original raw/type freezes remain byte-identical.\n')
m={'format':'astis-mean-source-graph-freeze-v1','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'bindings':bind,'source_root_full_path':str(BASE),'phase':'GRAPH_AFTER_TYPE_VERDICT','files':[]}
for f in sorted(OUT.rglob('*')):
 if f.is_file():b=f.read_bytes();m['files'].append({'path':str(f.relative_to(OUT)),'bytes':len(b),'sha256':sha(b)})
dump('freeze-manifest.json',m);dig=sha((OUT/'freeze-manifest.json').read_bytes());write('freeze-manifest.sha256',dig+'  freeze-manifest.json\n')
for f in OUT.rglob('*'):
 if f.is_file():f.chmod(0o444)
for d in sorted([d for d in OUT.rglob('*') if d.is_dir()],key=lambda d:len(d.parts),reverse=True):d.chmod(0o555)
OUT.chmod(0o555)
print(json.dumps({'source_root_full_path':str(BASE),'graph_freeze_path':str(OUT),'graph_sha256':sha((OUT/'source-proof-graph.json').read_bytes()),'coverage_sha256':sha((OUT/'post-seal-coverage.json').read_bytes()),'ports_sha256':sha((OUT/'internal-ports-and-source-gaps.json').read_bytes()),'chronology_qualification_sha256':sha((OUT/'chronology-qualification.json').read_bytes()),'graph_freeze_manifest_sha256':dig,'source_nodes':44,'all_nodes':len(nodes),'edges':len(edges),'internal_ports':len(ports),'genuine_source_gaps':[]},indent=2))
