#!/usr/bin/env python3
"""Verify every supplied immutable reader input, fixture and exact diff."""
import datetime as dt
import difflib
import hashlib
import json
from pathlib import Path
import subprocess

OWN = Path(__file__).resolve().parent
REPO = OWN.parents[3]
PREVIEW = REPO / '.astis/huanjian-gc-weighted-mgf-20261114/reader-preview-v1'

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def main():
    expected = {'preview-freeze-manifest.json': 'f2cbc9d412344fe2ec1d97a5c8bab21f83ffdc4d8e34d58d6f17e63d0d4e99c4', 'static-comparison-report.v1.json': '8ebcd212c996d711659c5c84929b8832594a0b39bcd856c25e371828480a2e72', 'render-process.v1.receipt.json': '2f6eb51a8d65ec1b09cfcd0a59c67d183c0cb85a6ec7d03178361712741873dc'}
    for name, digest in expected.items():
        assert sha(PREVIEW / name) == digest, name
    freeze = json.loads((PREVIEW / 'preview-freeze-manifest.json').read_text())
    inputs = json.loads((PREVIEW / 'input-freeze-manifest.json').read_text())
    assert sha(PREVIEW / 'input-freeze-manifest.json') == freeze['input_freeze_manifest_sha256']
    assert sha(PREVIEW / 'render_preview.py') == freeze['generator_sha256']
    assert sha(PREVIEW / 'reader_overlay.py') == freeze['overlay_sha256']
    snapshots = []
    for row in inputs['files']:
        path = PREVIEW / 'input-snapshot' / row['path']
        assert sha(path) == row['sha256'] and path.stat().st_size == row['bytes']
        snapshots.append({'path': str(path), 'sha256': row['sha256'], 'bytes': row['bytes']})
    assert {str(path.relative_to(PREVIEW / 'input-snapshot')) for path in (PREVIEW / 'input-snapshot').rglob('*') if path.is_file()} == {row['path'] for row in inputs['files']}
    for key, digest_key in [('lesson_input', 'lesson_sha256'), ('publication_input', 'publication_sha256')]:
        assert sha(inputs[key]) == inputs[digest_key] == freeze[digest_key]
    fixture_rows = []
    variants = {}
    for name, variant in freeze['variants'].items():
        root = PREVIEW / 'fixtures' / name
        assert {str(path.relative_to(root)) for path in root.rglob('*') if path.is_file()} == {row['path'] for row in variant['files']}
        variants[name] = {row['path']: row for row in variant['files']}
        for row in variant['files']:
            path = root / row['path']
            assert sha(path) == row['sha256'] and path.stat().st_size == row['bytes']
            fixture_rows.append({'path': str(path), 'sha256': row['sha256'], 'bytes': row['bytes']})
    changes = []
    for path in sorted(set(variants['original']) | set(variants['candidate'])):
        a = variants['original'].get(path, {})
        b = variants['candidate'].get(path, {})
        if a.get('sha256') != b.get('sha256'):
            changes.append(path)
    assert changes == [row['path'] for row in freeze['changed_files']]
    diff_rows = []
    for row in freeze['changed_files']:
        path = row['path']
        before = (PREVIEW / 'fixtures/original' / path).read_bytes() if row['original_sha256'] else b''
        after = (PREVIEW / 'fixtures/candidate' / path).read_bytes() if row['candidate_sha256'] else b''
        actual = ''.join(difflib.unified_diff(before.decode().splitlines(keepends=True), after.decode().splitlines(keepends=True), fromfile='original/' + path, tofile='candidate/' + path))
        diff = PREVIEW / row['diff']
        assert diff.read_text() == actual
        diff_rows.append({'path': str(diff), 'sha256': sha(diff), 'bytes': diff.stat().st_size})
    render = json.loads((PREVIEW / 'render-process.v1.receipt.json').read_text())
    assert render['exit_code'] == 0
    for stream in ['stdout', 'stderr']:
        assert sha(render[stream]) == render[stream + '_sha256']
    for path, expected_sha in [('AutoSamplingTheory/TechnicalLemmas/Probability/MatrixBernsteinMgf.lean', 'b46bb5a3eabbcadf31fee93d48c1fbabf9b5b42cf717a8a17c8c8cfdd210a3f3'), ('Tests/GaussianComplexityBernsteinWeightedMgf.lean', '42f372143ffe52e4372271d09fbc6b67391739f2fe2a5fbfffe6cd9fa586936e')]:
        raw = subprocess.check_output(['git', '--no-optional-locks', 'show', freeze['proof_commit'] + ':' + path], cwd=REPO)
        assert hashlib.sha256(raw).hexdigest() == expected_sha
        assert (PREVIEW / 'input-snapshot' / path).read_bytes() == raw
    report = {'schema': 'independent-reader-freeze-input-diff-verification-v1', 'status': 'ALL_FROZEN_INPUTS_FIXTURES_AND_DIFFS_MATCH', 'utc': dt.datetime.now(dt.timezone.utc).isoformat(), 'proof_commit': freeze['proof_commit'], 'expected_author_artifact_hashes': expected, 'input_snapshot_count': len(snapshots), 'fixture_file_counts': {name: len(rows) for name, rows in variants.items()}, 'changed_file_and_exact_diff_count': len(diff_rows), 'all_inputs_and_exact_diffs_verified': True, 'snapshot_files': snapshots, 'fixture_files': fixture_rows, 'exact_diff_files': diff_rows, 'author_metadata_payloads_modified': False, 'render_stdout_stderr_exact': True, 'new_browser_or_server_started': False}
    dest = OWN / 'reader-freeze-verification.v1.json'
    dest.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({'status': report['status'], 'snapshots': len(snapshots), 'fixtures': report['fixture_file_counts'], 'exact_diffs': len(diff_rows), 'report': str(dest), 'sha256': sha(dest)}))

if __name__ == '__main__':
    main()
