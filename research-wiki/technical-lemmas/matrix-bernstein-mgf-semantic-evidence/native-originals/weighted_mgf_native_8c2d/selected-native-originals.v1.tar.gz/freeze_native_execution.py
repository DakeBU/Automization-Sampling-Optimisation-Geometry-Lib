#!/usr/bin/env python3
"""Freeze this actor's exact harness/commands against admitted Git candidate."""
import hashlib
import json
import pathlib
import re

OWN = pathlib.Path(__file__).resolve().parent
R13 = OWN.parent / 'bernstein_exp_native_72c4'
CANDIDATE = '4869db55d340cee39f0ba4d49fb0a7a4309ba2d6'
LEAN = '/Users/zhouhuanjian/.elan/toolchains/leanprover--lean4---v4.33.0/bin/lean'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def item(path):
    return {'path': str(path.relative_to(OWN)), 'sha256': sha(path)}

def write_json(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')

def main():
    assert not (OWN / 'native-command-assignment.json').exists()
    assert not any((OWN / 'native-output').iterdir())
    closure = json.loads((OWN / 'actual-import-closure.json').read_text())
    packages = json.loads((OWN / 'verified-package-inputs.json').read_text())
    assert closure['candidate_commit'] == packages['candidate_commit'] == CANDIDATE
    seal = json.loads((OWN / 'immutable-inputs/statement-seal.sealed.v1.json').read_text())
    candidate = OWN / 'candidate-4869db55'
    signature_checks = []
    for role, key in [('P', 'public'), ('T', 'private_consumer')]:
        source = (candidate / seal[key]['file']).read_text()
        name = seal[key]['name'].split('.')[-1]
        matched = re.search(r'\btheorem\s+' + re.escape(name) + r'\b(.*?)\s*:=\s*by', source, re.S)
        assert matched and matched.group(1).strip() == seal[key]['signature'].strip()
        assert not re.search(r'\b(sorry|admit|axiom)\b', source)
        signature_checks.append({'role': role, 'source_sha256': sha(candidate / seal[key]['file']), 'literal_seal_signature_sha256': seal[key]['signature_sha256'], 'whitespace_outer_trim_only_match': True, 'fake_closure_keyword_hits': []})
    harness = OWN / 'harness'
    harness.mkdir(exist_ok=True)
    signature_p = seal['public']['signature']
    signature_t = seal['private_consumer']['signature']
    body_t = signature_t.split(':\n', 1)[1]
    body_q0 = re.sub(r'\bq\b', '0', body_t)
    body_q0_d2 = re.sub(r'\bd\b', '2', body_q0)
    text = '''import Tests.GaussianComplexityBernsteinWeightedMgf
import Lean
open MeasureTheory ProbabilityTheory Lean Elab Term
open scoped BigOperators Matrix.Norms.L2Operator MatrixOrder
noncomputable section
universe u v
elab "native_actual_T" : term => do
  let env ← getEnv
  let found := env.constants.toList.filter fun (n, _) =>
    n.toString.endsWith ".actual_source_weighted_normalized_single_summand_mgf"
  unless found.length == 1 do throwError "Expected exactly one actual private weighted consumer, found {found.length}"
  return mkConst found.head!.1
namespace NativeLiteralApplications

'''
    text += 'theorem literal_P\n' + signature_p + ' := by\n  exact ' + seal['public']['name'] + ' μ X hX hintX hintSq hherm hcap hzero hs\n\n'
    text += 'theorem literal_T\n' + signature_t + ' := by\n  exact native_actual_T hq\n\n'
    text += 'theorem literal_T_q0 {d : ℕ} (hd : 1 < d) :\n' + body_q0 + ' := by\n  exact native_actual_T (d := d) (q := 0) hd\n\n'
    text += 'theorem literal_T_q0_d2 :\n' + body_q0_d2 + ' := by\n  exact native_actual_T (d := 2) (q := 0) (by norm_num)\n\n'
    text += '''end NativeLiteralApplications
#print axioms NativeLiteralApplications.literal_P
#print axioms NativeLiteralApplications.literal_T
#print axioms NativeLiteralApplications.literal_T_q0
#print axioms NativeLiteralApplications.literal_T_q0_d2

'''
    old_literals = (R13 / 'harness/NativeLiteralApplications.lean').read_text()
    text += 'namespace NativeSemanticChecks' + old_literals.split('namespace NativeSemanticChecks', 1)[1]
    literal_file = harness / 'NativeLiteralApplications.lean'
    literal_file.write_text(text)
    old_kernel = (R13 / 'harness/NativeAudit.lean').read_text()
    kernel = old_kernel.replace('Tests.GaussianComplexityBernsteinMgf', 'Tests.GaussianComplexityBernsteinWeightedMgf')
    kernel = kernel.replace('NativeAudit72c4', 'NativeAudit8c2d').replace(str(R13), str(OWN))
    kernel = kernel.replace('AutoSamplingTheory.TechnicalLemmas.Probability.MatrixBernsteinExponential.bernstein_exponential_quadratic_bound', seal['public']['name'])
    kernel = kernel.replace('.actual_source_normalized_single_summand_mgf', '.actual_source_weighted_normalized_single_summand_mgf')
    kernel = kernel.replace('0ff1e2227b8e5a45a6a73906582ef042bd0d73ff', CANDIDATE)
    modules = closure['topological_order'] + ['NativeLiteralApplications']
    module_text = 'def modules : Array String := #[\n  ' + ',\n  '.join(json.dumps(module) for module in modules) + ']\n\n'
    kernel, count = re.subn(r'def modules : Array String := #\[.*?\]\s*\n(?=def atJ)', module_text, kernel, count=1, flags=re.S)
    assert count == 1
    kernel_file = harness / 'NativeAudit.lean'
    kernel_file.write_text(kernel)
    env = {'HOME': '/Users/zhouhuanjian', 'PATH': str(pathlib.Path(LEAN).parent) + ':/usr/bin:/bin', 'LEAN_PATH': ':'.join([str(OWN / 'native-output')] + [row['effective_lean_path'] for row in packages['packages']]), 'LC_ALL': 'C', 'LEAN_ABORT_ON_PANIC': '1'}
    commands = {'lean-version': {'phase': 'native', 'argv': [LEAN, '--version'], 'cwd': 'candidate-4869db55', 'environment': env}}
    for number, module in enumerate(closure['topological_order']):
        relative = module.replace('.', '/')
        output = OWN / 'native-output' / (relative + '.olean')
        # Do not create output subdirectories until the runner records empty initialization.
        commands[f'build-{number:02d}'] = {'phase': 'native', 'argv': [LEAN, '-DmaxRecDepth=16384', '-DmaxHeartbeats=0', '-Ddebug.skipKernelTC=false', '-o', str(output), relative + '.lean'], 'cwd': 'candidate-4869db55', 'environment': env}
    commands['literal-applications'] = {'phase': 'native', 'argv': [LEAN, '-DmaxRecDepth=16384', '-DmaxHeartbeats=0', '-Ddebug.skipKernelTC=false', '-o', str(OWN / 'native-output/NativeLiteralApplications.olean'), str(literal_file)], 'cwd': 'harness', 'environment': env}
    commands['raw-kernel-audit'] = {'phase': 'native', 'argv': [LEAN, '-DmaxRecDepth=32768', '-DmaxHeartbeats=0', '-Ddebug.skipKernelTC=false', '--run', str(kernel_file)], 'cwd': 'harness', 'environment': env}
    command_file = OWN / 'native-commands.v1.json'
    write_json(command_file, commands)
    write_json(OWN / 'literal-signature-source-match.json', {'candidate_commit': CANDIDATE, 'targets': signature_checks, 'harness_sha256': sha(literal_file), 'complete_harness_types_generated_from_frozen_literal_seal': True})
    immutable_paths = [OWN / 'actual-import-closure.json', OWN / 'literal-signature-source-match.json', literal_file, kernel_file]
    immutable_paths += [candidate / row['path'] for row in closure['modules']]
    immutable_paths += [candidate / name for name in ['lean-toolchain', 'lake-manifest.json', 'lakefile.lean', 'lakefile.toml'] if (candidate / name).is_file()]
    assignment = {
        'schema': 'weighted-mgf-native-assignment-v1', 'status': 'ROOT_ADMITTED_AND_ASSIGNED_IMMUTABLE_COMPLETE_P_AND_T',
        'candidate_commit': CANDIDATE, 'root_assignment_basis': 'ROOT explicit collaboration message authorizing admitted immutable4869 native execution',
        'runner_sha256': sha(OWN / 'native_runner.py'), 'expectations_sha256': sha(OWN / 'native-expectations.v1.md'),
        'admission_receipt': item(OWN / 'immutable-inputs/preproof-admission.v2.json'),
        'candidate_sources': {role: item(candidate / seal[key]['file']) for role, key in [('P', 'public'), ('T', 'private_consumer')]},
        'immutable_inputs': [item(path) for path in immutable_paths] + [item(OWN / 'immutable-inputs/statement-seal.sealed.v1.json')],
        'verified_package_inputs': item(OWN / 'verified-package-inputs.json'), 'commands': item(command_file),
    }
    write_json(OWN / 'native-command-assignment.json', assignment)
    print(json.dumps({'assignment_frozen': True, 'candidate': CANDIDATE, 'ASTIS_modules': len(closure['topological_order']), 'commands': len(commands), 'literal_harness_sha256': sha(literal_file), 'kernel_harness_sha256': sha(kernel_file)}))

if __name__ == '__main__':
    main()
