-- prefix still-comment
theorem sample : True := by
  trivial
