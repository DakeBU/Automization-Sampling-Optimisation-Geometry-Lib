def col (A : Matrix m n α) : n → m → α := Aᵀ
