"""Copy exact whole modules for the independent reviewer's code-only phase."""
from pathlib import Path
import hashlib
import json

root = Path('.astis/semantic-neutral-20261111/r4_src_6aef/code-only-inputs')
root.mkdir(exist_ok=False)
paths = [
    'AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumRadialFourthMoment.lean',
    'Tests/GaussianComplexityFixedSpectrumRadialFourthMoment.lean',
    'AutoSamplingTheory/TechnicalLemmas/StochasticProcesses/GaussianFourthMoment.lean',
    '.lake/packages/mathlib/Mathlib/Probability/Distributions/Gaussian/Multivariate.lean',
    '.lake/packages/mathlib/Mathlib/Probability/Distributions/Gaussian/Fernique.lean',
]
records = []
for index, name in enumerate(paths):
    path = Path(name)
    raw = path.read_bytes()
    destination = root / f'{index:02d}-{path.name}.raw.txt'
    with destination.open('xb') as out:
        out.write(raw)
    records.append({'original': name, 'input_copy': str(destination),
                    'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()})
manifest = {
    'phase': 'Whole-module code-only source review after separately frozen raw and type phases',
    'mathlib_pin': 'db584cd6d46c92f209a44c0f1c829460d327499d',
    'inputs': records,
    'scope': 'Exact new producer and private consumer, canonical ASTIS scalar fourth-moment provider, and directly used pinned Gaussian law/integrability modules.',
    'excluded': ['compiler receipts', 'proof history', 'decoder reconstruction', 'exposition', 'source map', 'other reviewer verdicts', 'source graph', 'earlier packet reports'],
}
raw = (json.dumps(manifest, ensure_ascii=False, indent=2) + '\n').encode()
path = root / 'input-manifest.json'
with path.open('xb') as out:
    out.write(raw)
print(json.dumps({'manifest': str(path), 'sha256': hashlib.sha256(raw).hexdigest(), 'files': records}))
