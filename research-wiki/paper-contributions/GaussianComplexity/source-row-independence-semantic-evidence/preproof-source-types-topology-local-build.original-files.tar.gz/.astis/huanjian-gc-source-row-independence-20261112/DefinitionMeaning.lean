import Mathlib

noncomputable section
open MeasureTheory ProbabilityTheory
set_option pp.universes true

-- Definition semantics only, before target proof search.
#print ProbabilityTheory.iIndepFun
#print ProbabilityTheory.iIndep
#print ProbabilityTheory.iIndepSets
#print ProbabilityTheory.Kernel.iIndepFun
#print ProbabilityTheory.Kernel.iIndep
#print ProbabilityTheory.Kernel.iIndepSets
#print ProbabilityTheory.Kernel.const
#print MeasureTheory.Measure.dirac
#print MeasurableSpace.comap
#print MeasurableSpace.pi
#print Matrix
#print Matrix.vecMulVec
#print Matrix.kronecker
#print EuclideanSpace
#print WithLp.toLp
#print ProbabilityTheory.stdGaussian
#print MeasureTheory.Measure.pi

section
variable {d q : ℕ}
#synth MeasurableSpace (EuclideanSpace ℝ (Fin d))
#synth MeasurableSpace ((Fin (q + 1) × Fin (q + 1)) → (Fin (q + 1) × Fin (q + 1)) → ℝ)
#synth IsProbabilityMeasure
  (Measure.pi (fun _ : Fin (q + 1) => stdGaussian (EuclideanSpace ℝ (Fin d))))
#synth SigmaFinite (stdGaussian (EuclideanSpace ℝ (Fin d)))
end
