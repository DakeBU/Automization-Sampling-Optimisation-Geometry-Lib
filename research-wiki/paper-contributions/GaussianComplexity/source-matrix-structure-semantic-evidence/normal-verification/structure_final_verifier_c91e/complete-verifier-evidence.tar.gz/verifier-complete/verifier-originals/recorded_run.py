"""Capture exact stdout/stderr and receipt for one owned verifier command."""
from pathlib import Path
import datetime, hashlib, json, subprocess, sys
O = Path(__file__).resolve().parent
label,script = sys.argv[1:3]
assert label in ['prepare-normal','normal-once']
assert script in ['prepare_normal_verification.py','execute_normal_once.py']
D = O/'commands'/label; D.mkdir(parents=True,exist_ok=False)
argv = [sys.executable,str(O/script)]
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
start = now()
with (D/'stdout').open('wb') as out,(D/'stderr').open('wb') as err:
    result = subprocess.run(argv,stdout=out,stderr=err)
receipt = {'argv':argv,'started_at':start,'ended_at':now(),'exit_code':result.returncode,
    'script_sha256':hashlib.sha256((O/script).read_bytes()).hexdigest(),
    'stdout_sha256':hashlib.sha256((D/'stdout').read_bytes()).hexdigest(),
    'stderr_sha256':hashlib.sha256((D/'stderr').read_bytes()).hexdigest()}
(D/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
print((D/('stderr' if result.returncode else 'stdout')).read_text())
sys.exit(result.returncode)
