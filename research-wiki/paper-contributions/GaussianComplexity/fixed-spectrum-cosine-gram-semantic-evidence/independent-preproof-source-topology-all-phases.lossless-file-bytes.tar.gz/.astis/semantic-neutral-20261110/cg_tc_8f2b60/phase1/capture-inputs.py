from pathlib import Path
import json

base = Path(__file__).resolve().parent
scripts = {}
scripts['bootstrap'] = r'''import pathlib, json, hashlib, datetime
r=pathlib.Path('/Users/zhouhuanjian/ASTIS-GC')
p=r/'.astis/semantic-neutral-20261110/cg_tc_8f2b60/phase1'
inputs=['AGENTS.md','docs/proof-digestion-protocol.md','docs/theorem-publication-protocol.md','docs/evidence-routed-memory-protocol.md','.agents/skills/astis-source-dependency-audit/SKILL.md']
records=[]
for i,f in enumerate(inputs):
 b=(r/f).read_bytes(); dst=p/f'procedure-{i}.txt'; dst.write_bytes(b)
 records.append({'path':f,'snapshot':dst.name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
(p/'procedural-inputs.json').write_text(json.dumps(records,ensure_ascii=False,indent=2)+'\n')
(p/'initial-exposure.json').write_text(json.dumps({'phase':'raw-only','before_snapshot':{'commands':['cat AGENTS.md','cat docs/proof-digestion-protocol.md docs/theorem-publication-protocol.md docs/evidence-routed-memory-protocol.md .agents/skills/astis-source-dependency-audit/SKILL.md','/opt/anaconda3/bin/python -c [fixed raw SHA/size verification]'],'tool_output':{'outer_warning':'truncated output (original token count: 17682)','displayed_total_output_lines':3,'call0_exit':0,'call0_original_token_count':6942,'call1':'output partly lost to outer tool truncation; re-read from full byte snapshots before any raw cognition','call2_exit':0,'call2_output':'.astis/huanjian-resume-20261103/2610.20492v1.html\n951991\n6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915\n'}},'exposure_exclusions':['No draft/seal/type/author SG/root implementation/current or old verdict/semantic registry/controlled graph/index/ledger/ATLAS read.','Only parent assignment, allowed procedures, and fixed raw SHA metadata seen.'],'remediation':'Full procedural files snapshotted separately; read them in bounded calls. No missing output represented as read.'},ensure_ascii=False,indent=2)+'\n')
print(json.dumps(records,ensure_ascii=False,indent=2))
'''
scripts['raw-00-dom-inventory'] = r'''from pathlib import Path
from bs4 import BeautifulSoup
import hashlib,json
root=Path('.astis/semantic-neutral-20261110/cg_tc_8f2b60/phase1')
p=Path('.astis/huanjian-resume-20261103/2610.20492v1.html'); b=p.read_bytes(); s=BeautifulSoup(b,'html.parser')
lines=[]
for key in ['S4.Thmtheorem4','A3.SS2','A3.Thmtheorem5']:
 t=s.find(id=key)
 lines.append(f'ANCHOR {key} found={t is not None}')
 if t:
  lines.append('ANCESTORS '+str([(a.name,a.get('id'),a.get('class')) for a in [t,*list(t.parents)[:4]]]))
  for c in t.find_all(recursive=False):
   lines.append(str((c.name,c.get('id'),c.get('class'),c.get_text(' ',strip=True)[:250])))
out='\n'.join(lines)+'\n'; (root/'raw-00-dom-inventory.txt').write_text(out)
(root/'raw-00-dom-inventory-input.py').write_text('Exact script is preserved in command-transcript.jsonl; the raw source was parsed using bs4 html.parser.\n')
print(out)
'''
scripts['raw-01-reading'] = r'''from pathlib import Path
from bs4 import BeautifulSoup
from html.parser import HTMLParser
import hashlib,json
base=Path('.astis/semantic-neutral-20261110/cg_tc_8f2b60/phase1')
raw=Path('.astis/huanjian-resume-20261103/2610.20492v1.html').read_text()
soup=BeautifulSoup(raw,'html.parser')
class Spans(HTMLParser):
 def __init__(self):
  super().__init__(convert_charrefs=False); self.stack=[]; self.spans={}; self.starts=[0]
  self.starts.extend(i+1 for i,c in enumerate(raw) if c=='\n')
 def pos(self):
  l,c=self.getpos(); return self.starts[l-1]+c
 def handle_starttag(self,tag,attrs):
  ident=dict(attrs).get('id'); start=self.pos(); end=start+len(self.get_starttag_text())
  if tag in {'area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr'}:
   if ident:self.spans[ident]=(start,end)
  else:self.stack.append((tag,ident,start))
 def handle_startendtag(self,tag,attrs):
  ident=dict(attrs).get('id'); start=self.pos()
  if ident:self.spans[ident]=(start,start+len(self.get_starttag_text()))
 def handle_endtag(self,tag):
  for i in range(len(self.stack)-1,-1,-1):
   if self.stack[i][0]==tag:
    matches=self.stack[i:]; self.stack=self.stack[:i]
    end=raw.index('>',self.pos())+1
    for _,ident,start in matches:
     if ident:self.spans[ident]=(start,end)
    break
p=Spans();p.feed(raw)
keys=['S4.Thmtheorem4','A3.SS2.p1','A3.SS2.p2','A3.Thmtheorem5','A3.SS2.2']
meta=[]; output=[]
for key in keys:
 a,z=p.spans[key]; fragment=raw[a:z]; b=fragment.encode(); tag=BeautifulSoup(fragment,'html.parser')
 for math in tag.find_all('math'):
  math.replace_with(' $'+math.get('alttext',math.get_text(' ',strip=True))+'$ ')
 txt=tag.get_text(' ',strip=True)
 (base/(key+'.html')).write_bytes(b);(base/(key+'.txt')).write_text(txt+'\n')
 item={'id':key,'byte_start':len(raw[:a].encode()),'byte_end_exclusive':len(raw[:z].encode()),'line_start':raw.count('\n',0,a)+1,'line_end':raw.count('\n',0,z)+1,'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
 meta.append(item);output.append(json.dumps(item)+'\n'+txt)
(base/'source-spans-01.json').write_text(json.dumps(meta,indent=2)+'\n')
ctx=soup.find(id='S4.SS2'); inv=[]
for c in ctx.find_all(recursive=False):
 x=BeautifulSoup(str(c),'html.parser')
 for math in x.find_all('math'):math.replace_with(' $'+math.get('alttext','')+'$ ')
 inv.append((c.name,c.get('id'),x.get_text(' ',strip=True)[:700]))
output.append('S4.SS2 DIRECT CHILD INVENTORY\n'+json.dumps(inv,ensure_ascii=False,indent=2))
out='\n\n'.join(output)+'\n';(base/'raw-01-reading-output.txt').write_text(out);print(out)
'''
scripts['raw-02-definitions'] = r'''from pathlib import Path
from bs4 import BeautifulSoup
import json
base=Path('.astis/semantic-neutral-20261110/cg_tc_8f2b60/phase1')
s=BeautifulSoup(Path('.astis/huanjian-resume-20261103/2610.20492v1.html').read_bytes(),'html.parser')
outs=[]
for key in ['S4','S4.SS1','S4.SS2.SSS0.Px1','S4.SS2.SSS0.Px2']:
 t=s.find(id=key)
 outs.append('ANCHOR '+key)
 if key=='S4':
  use=[c for c in t.find_all(recursive=False) if c.name!='section']
 elif key=='S4.SS2.SSS0.Px2':
  use=[c for c in t.find_all(recursive=False) if c.get('id')!='S4.Thmtheorem4']
 else:use=[t]
 for tag in use:
  c=BeautifulSoup(str(tag),'html.parser')
  for m in c.find_all('math'):m.replace_with(' $'+m.get('alttext','')+'$ ')
  outs.append(c.get_text(' ',strip=True))
outs.append('C.2 full proof structure inventory')
for c in s.find(id='A3.SS2').find_all(recursive=False):
 if c.name=='h3':continue
 outs.append(json.dumps({'id':c.get('id'),'class':c.get('class'),'children':[(a.name,a.get('id'),a.get('class')) for a in c.find_all(recursive=False)]},ensure_ascii=False))
out='\n\n'.join(outs)+'\n';(base/'raw-02-definitions-output.txt').write_text(out);print(out)
'''
scripts['raw-04-coverage-anchor'] = r'''from pathlib import Path
from bs4 import BeautifulSoup
import json
base=Path('.astis/semantic-neutral-20261110/cg_tc_8f2b60/phase1')
spans={x['id']:x for x in json.loads((base/'source-spans-complete.json').read_text())}
s=BeautifulSoup((base/'A3.SS2.html').read_bytes(),'html.parser')
lines=[]
for tag in s.find_all(id=True):
 if 'ltx_para' in tag.get('class',[]) or 'ltx_theorem' in tag.get('class',[]):
  key=tag['id']; item=spans[key]
  lines.append(json.dumps({'id':key,'source_lines':[item['line_start'],item['line_end']],'byte_span':[item['byte_start'],item['byte_end_exclusive']],'sha256':item['sha256'],'display_ids':[x.get('id') for x in tag.find_all(class_='ltx_equation') if x.get('id')]},ensure_ascii=False))
for key in ['S4.SS1','S4.SS2.SSS0.Px1','S4.SS2.SSS0.Px2']:
 tag=BeautifulSoup((base/(key+'.html')).read_bytes(),'html.parser')
 lines.append('SOURCE CONTEXT ANCHORS '+key+' '+json.dumps([(x.name,x.get('id')) for x in tag.find_all(id=True) if 'ltx_para' in x.get('class',[]) or 'ltx_equation' in x.get('class',[])],ensure_ascii=False))
out='\n'.join(lines)+'\n';(base/'raw-04-coverage-anchor-output.txt').write_text(out);print(out)
'''
scripts['raw-05-display-inventory'] = r'''from pathlib import Path
from bs4 import BeautifulSoup
import json
base=Path('.astis/semantic-neutral-20261110/cg_tc_8f2b60/phase1')
s=BeautifulSoup((base/'A3.SS2.html').read_bytes(),'html.parser')
items=[]
for t in s.find_all(id=True):
 if '.Ex' in t['id']:
  p=t.find_parent(class_='ltx_para')
  text=t.get_text(' ',strip=True)
  alt=[m.get('alttext') for m in t.find_all('math')]
  items.append({'id':t['id'],'tag':t.name,'class':t.get('class'),'paragraph':p.get('id') if p else None,'math_alt':alt})
out=json.dumps(items,ensure_ascii=False,indent=2)+'\n';(base/'raw-05-display-inventory-output.json').write_text(out);print(out)
'''
scripts['raw-06-complete-subspans'] = r'''from pathlib import Path
from contextlib import redirect_stdout
import io,runpy,json,re,hashlib
base=Path('.astis/semantic-neutral-20261110/cg_tc_8f2b60/phase1')
buf=io.StringIO()
with redirect_stdout(buf): env=runpy.run_path(str(base/'audit_reader.py'))
(base/'raw-06-reader-replay-output.txt').write_text(buf.getvalue())
raw=env['raw']; soup=env['soup']; parser=env['p']
keys=[]
for parent_id in ['S4.SS1','S4.SS2.SSS0.Px1','S4.SS2.SSS0.Px2','A3.SS2']:
 t=soup.find(id=parent_id);keys.append(parent_id)
 for child in t.find_all(id=True):
  key=child['id'];cls=child.get('class',[])
  if any(c in cls for c in ['ltx_para','ltx_theorem','ltx_proof']) or re.fullmatch(r'(?:A3|S4)\.(?:Ex|E)\d+',key):keys.append(key)
meta=[]
for key in dict.fromkeys(keys):
 a,z=parser.spans[key];fragment=raw[a:z].encode()
 meta.append({'id':key,'byte_start':len(raw[:a].encode()),'byte_end_exclusive':len(raw[:z].encode()),'line_start':raw.count('\n',0,a)+1,'line_end':raw.count('\n',0,z)+1,'sha256':hashlib.sha256(fragment).hexdigest(),'bytes':len(fragment)})
(base/'source-spans-complete.json').write_text(json.dumps(meta,indent=2)+'\n')
out=json.dumps({'source_anchor_count':len(meta),'replayed_reader_stdout_bytes':len(buf.getvalue().encode()),'new_source_text_displayed':False},indent=2)+'\n';(base/'raw-06-span-completion-output.txt').write_text(out);print(out)
'''
scripts['raw-07-context-paragraph'] = r'''from pathlib import Path
from bs4 import BeautifulSoup
base=Path('.astis/semantic-neutral-20261110/cg_tc_8f2b60/phase1');out=[]
for key in ['S4.SS1','S4.SS2.SSS0.Px1','S4.SS2.SSS0.Px2']:
 s=BeautifulSoup((base/(key+'.html')).read_bytes(),'html.parser')
 for t in s.find_all(class_='ltx_para'):
  for m in t.find_all('math'):m.replace_with(' $'+m.get('alttext','')+'$ ')
  out.append(t.get('id')+'\n'+t.get_text(' ',strip=True))
x='\n\n'.join(out)+'\n';(base/'raw-07-context-paragraph-output.txt').write_text(x);print(x)
'''
for name, source in scripts.items():
    (base / (name + '-actual-input.py')).write_text(source)

prefix = '.astis/semantic-neutral-20261110/cg_tc_8f2b60/phase1/'
cwd = '/Users/zhouhuanjian/ASTIS-GC'
records = []


def event(command, stdout_artifact=None, chunk=None, tokens=None, note=None):
    records.append({'cwd': cwd, 'command': command, 'stdout_artifact': stdout_artifact,
                    'tool_chunk_id': chunk, 'original_token_count': tokens,
                    'exit_code_observed': 0 if chunk else None, 'stderr': '', 'note': note})


event('cat AGENTS.md', 'procedure-0.txt', '024da6', 6942, 'First outer output was truncated despite this nested output being complete in its own envelope.')
event('cat docs/proof-digestion-protocol.md docs/theorem-publication-protocol.md docs/evidence-routed-memory-protocol.md .agents/skills/astis-source-dependency-audit/SKILL.md', None, note='Original combined output transport truncated; original per-call envelope not fully observed. Later full bounded reads are recorded below, and byte snapshots preserve the inputs. No invented original exit status/output.')
event('/opt/anaconda3/bin/python -c \'import hashlib,pathlib; p=pathlib.Path(".astis/huanjian-resume-20261103/2610.20492v1.html"); b=p.read_bytes(); print(str(p)); print(len(b)); print(hashlib.sha256(b).hexdigest())\'', None, 'c469b2', 31, 'stdout exactly recorded in initial-exposure.json.')
event('mkdir -p .astis/semantic-neutral-20261110/cg_tc_8f2b60/phase1', None, 'a7d046', 0)
event("/opt/anaconda3/bin/python - <<'PY'\n" + scripts['bootstrap'] + 'PY', 'procedural-inputs.json', '49af6b', 244)
event('cat ' + prefix + 'procedure-0.txt', 'procedure-0.txt', '020639', 6942)
event('cat ' + prefix + 'procedure-1.txt', 'procedure-1.txt', '028596', 4035)
event('cat ' + prefix + 'procedure-2.txt', 'procedure-2.txt', '89620b', 3547)
event('cat ' + prefix + 'procedure-3.txt ' + prefix + 'procedure-4.txt', None, '8fa784', 2548, 'stdout is exact concatenation of procedure-3.txt and procedure-4.txt.')
raw_envelopes = [
 ('raw-00-dom-inventory', 'raw-00-dom-inventory.txt', 'f94b1e', 1134),
 ('raw-01-reading', 'raw-01-reading-output.txt', '464d2d', 2242),
 ('raw-02-definitions', 'raw-02-definitions-output.txt', 'b0e8e9', 1708),
 ('raw-04-coverage-anchor', 'raw-04-coverage-anchor-output.txt', 'b7dfed', 1262),
 ('raw-05-display-inventory', 'raw-05-display-inventory-output.json', '71a3e5', 5338),
 ('raw-06-complete-subspans', 'raw-06-span-completion-output.txt', '3d513c', 28),
 ('raw-07-context-paragraph', 'raw-07-context-paragraph-output.txt', '2f58fb', 1120),
]
for name, out, chunk, tokens in raw_envelopes:
    event("/opt/anaconda3/bin/python - <<'PY'\n" + scripts[name] + 'PY', out, chunk, tokens,
          'Script print adds one further newline to the retained stdout artifact. raw-06 also preserves internally redirected replay stdout in raw-06-reader-replay-output.txt.')
event('/opt/anaconda3/bin/python ' + prefix + 'audit_reader.py', 'raw-03-excluded-tail-output.txt', '1e76c3', 1619, 'This occurred after raw-02 and before raw-04; file-creation apply_patch input is the initial audit_reader.py add-file patch. Script print adds one further newline.')
for chunk in ['86ea63', 'd3b96c', 'a960cf']:
    event('/opt/anaconda3/bin/python ' + prefix + 'build-coverage.py', None, chunk, 24,
          'stdout has C2_para_count 21, C2_display_anchor_count 48, missing [], then Coverage rows: ' + ('103' if chunk == 'a960cf' else '98') + '. Order: 86ea63 before raw-06; d3b96c immediately after raw-06; a960cf after raw-07 and the context-label repair patch.')
report = {'kind': 'literal shell input retention plus observed output envelope ledger',
          'order_note': 'Exact tool chronology is determined by tool_chunk_id notes and the chronological session tool record; raw-* numbers describe read stages. No commands were executed by this capture script.',
          'initial_transport_truncation': {'outer_original_token_count': 17682, 'recovery': 'Five full procedure snapshots and bounded rereads'},
          'failures': [], 'unobserved_detail': 'Initial combined procedure per-call envelope was lost to outer truncation; it is explicitly unknown, not reconstructed as success.',
          'all_subsequent_commands_exit_zero': True, 'events': records,
          'patch_inputs': 'Add-file apply_patch inputs consist of the exact named initial file body with + prefixes. audit_reader.py and raw-cognition.md are unchanged. build-coverage.py had one explicit correction patch retained separately; its initial body is retained as build-coverage-v1.py. capture-inputs.py itself is preserved verbatim. Later package/freeze scripts are retained verbatim and their outputs are in their receipts.'}
(base / 'command-transcript.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print('Retained exact Python heredoc inputs:', len(scripts))
print('Observed shell-command ledger entries:', len(records))
