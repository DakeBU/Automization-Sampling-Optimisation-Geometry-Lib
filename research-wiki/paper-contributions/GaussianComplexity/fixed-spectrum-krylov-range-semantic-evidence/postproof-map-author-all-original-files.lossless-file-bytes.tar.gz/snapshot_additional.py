from pathlib import Path
import json,hashlib,stat
ROOT=Path(__file__).resolve().parent;REPO=ROOT.parents[2]
sha=lambda b:hashlib.sha256(b).hexdigest()
records=[]
for label,rel in [
('candidate-lessons','website/content/declaration_lessons/huanjian-fixed-spectrum-krylov-range.json'),
('candidate-publication','website/content/publications/huanjian-fixed-spectrum-krylov-range.json'),
('actual-owned-inventory','research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-krylov-range-semantic-evidence/actual-kernel-owned-inventory.json'),
('publication-draft-record','research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-krylov-range-semantic-evidence/publication-draft-record.json')]:
    path=REPO/rel;b=path.read_bytes();dest=ROOT/'input-originals'/(label+'.json');dest.write_bytes(b)
    records.append({'label':label,'original_path':str(path),'snapshot_path':str(dest.relative_to(ROOT)),'bytes':len(b),'raw_sha256':sha(b),'lf_count':b.count(b'\n'),'original_mode':format(stat.S_IMODE(path.stat().st_mode),'04o')})
(ROOT/'additional-input-manifest.json').write_text(json.dumps({'inputs':records,'authorized_binding_hash':'7b97440eda9692f238e20ad1f0e985b5c38b4fc4f358ccffb02535b92df14ea7','scope':'Newly authorized authored candidate exposition/publication/actual-owned inventory snapshots. No browser or source acceptance implied.'},ensure_ascii=False,indent=2)+'\n')
print(json.dumps(records,ensure_ascii=False,indent=2))
