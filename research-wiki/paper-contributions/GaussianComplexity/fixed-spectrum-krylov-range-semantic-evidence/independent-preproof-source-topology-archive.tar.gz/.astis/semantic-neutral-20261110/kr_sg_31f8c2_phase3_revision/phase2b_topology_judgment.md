# Phase 2b independent source-topology challenge

Decision: **two bounded representation/necessity repairs are required before accepting this proposal as an exhaustive, use-site-precise dependency account**. The source mathematical conclusions, exact P/T signatures, metric, normalization and main route are not refuted. Most of the proposal agrees with the two independently frozen baselines. The defects below concern a surplus immediate parent and an insufficiently explicit matrix-power representation obligation; neither authorizes a new public hypothesis or an implementation change.

This judgment was formed after freezing Phase 1 raw-source mathematics and Phase 2a exact-type/binder/definition semantics. The graph and type overlay are proposals, not evidence of proof existence or global sourceV. No target Lean, API, implementation, root binder/planning narrative, frontier or process-authority packet was read. The three new inputs were read only after both freezes:

* source graph SHA256 `b8d2503c8cf64491e5099e3ae6b5b1745d1d18f5bf2e7650046f95f0c23fc2ba`;
* coverage SHA256 `1105056c5d9a1a2210846ea9958ef3c6df99034ffdbd280f068361b9f333a833`;
* typed overlay SHA256 `0fe674ba24615b9030e30ef4ea09ed332acec04c2f12ba0d16293b6531661787`.

## R1 — separate existential image semantics from the earlier column-span theorem

Exact affected record: source graph `e-witness`, whose consumer is `C2.witness` and current AND parents are `C5.range` and `E.range-columns`.

The source use site A3.SS2.p19.2 says that for u in K_q, Fact C.5 lets us write u=Bc. Its raw pin is characters [848617,849605), UTF8 bytes [857429,858431), LF lines 3804--3806, SHA256 `88c2408fcc6109c1d89566ee9a192425acd47e771f9410f7e270bd46fbd3f044`. The needed mathematical direction is K_q subset range(B), followed by the definition of matrix image. In exact P, `Set.range` is already the existential image `{v | exists c, B.mulVec c=v}`.

`E.range-columns` currently bundles the nontrivial theorem “matrix image equals span of columns” with preservation under nonzero individual column scalings. Those facts genuinely belong to the proof of `C5.range` via `e-range`; once that equality is available, they are not a second immediate mathematical ingredient at the witness use site. The typed overlay already recognizes this correctly in its `P.reverse -> T.witness` edge. The unqualified source-graph `e-witness` therefore overstates the immediate AND dependency and obscures the difference between a definition unfolding and a new result.

Required minimal repair: in a versioned author overlay, replace the immediate witness edge by the reverse inclusion supplied by `C5.range`, with an explicit existential-image definition conversion. This can be `parents=[C5.range]` plus a consumed-direction/definition field, or a separate *definition-only* image-membership node. Do not reintroduce the whole `E.range-columns` theorem/scaling package as a necessary direct parent. Keep `E.range-columns -> C5.range` untouched. The complete backward closure can remain unchanged because the range proof itself still uses column spans; this is a correction of mathematical use sites, not an excuse to claim progress from node counts.

This does not allege the old AND is an invalid sufficient conjunction. It is a rejection of its presentation as the source's necessary use-site ingredient list. If the graph were explicitly only a permissive, nonminimal sufficient route, the extra premise could be harmless; the requested ASTIS source-ingredient/necessary-parent contract is stricter.

## R2 — expose the diagonal-power coordinate identification inside the span conversion

Exact affected records: source nodes `C5.polynomials`, `E.triangular`, `C5.span-conversion`; edge `e-span`; typed obligations `P.objects`, `P.polynomial` and `P.triangular`.

A3.SS2.p3 converts the coordinate vectors `((g_a)_i cos(j theta_i))_i` to `Lambda^j g_a` for 0<=j<=q. Its raw pin is characters [743701,748451), UTF8 bytes [751263,756054), LF lines 3363--3376, SHA256 `70a50b8444b84fbd1c589f08cfc7406de60df80ef880fbbaf0be8043a31b0d77`. The polynomial identity in `C5.polynomials` is pointwise at the scalar eigenvalues. The evaluated-family triangular lemma in `E.triangular` preserves spans. The bridge identifying the monomial-evaluated, g-weighted vector with the actual matrix-power generator is

    ((Lambda^j).mulVec(g_a))_i = lambda_i^j (g_a)_i,

including j=0, because Lambda is the source diagonal matrix. For a polynomial P_j, this also identifies its coordinate evaluation with the corresponding real linear combination of the actual Lambda^m g_a generators.

That representation fact is implicit in the current prose but has no explicit content/discharge record in `e-span` or the typed obligations. `P.objects` says to identify source family and columns, while `P.polynomial` only states scalar cosine/eigenvalue evaluation. Merely saying “ordinary matrix powers, not entrywise powers” in the local definition audit gives the right semantics but does not discharge their coordinate action. The independently frozen Phase 2a baseline explicitly retained this as internal proof content.

Required minimal repair: add an explicit diagonal-power/weighted-polynomial-evaluation subobligation, with its source use site and binding into `e-span`/`P.polynomial` or `P.objects`. A new graph node is not mandatory: an expanded existing elementary representation leaf and an explicit consumed subobligation are sufficient. It must be clear that the formula is to be proved from the diagonal definition for arbitrary g, not assumed as a public binder, inferred from vector independence, or declared compiled. Preserve q=0 and zero g. No change to P/T signatures is required.

R2 is a missing explicit proof-ingredient account, not a claim that the elementary representation fact is false. A broad unresolved phrase “finite-dimensional algebra” in `source_gaps` exposes uncertainty but does not identify this exact consumer bridge sufficiently for the exhaustive ingredient contract.

## Independent coverage and mathematical checks that passed

The author's coverage contains exactly the same 520 ID elements as the independent raw inventory. All raw Unicode character intervals, UTF8 byte intervals, LF line intervals, raw fragment hashes, tags and math alttexts agree. All 252 math elements and 67 table/body elements have explicit dispositions; the three anonymous citations are separately pinned and were independently rehashed. These are mechanical comparisons, not a mathematical acceptance argument.

I separately inspected the paragraph and table assignments against the frozen source understanding. In particular, A3.Ex130.m1/m2 map to `C2.energy-equality` and `C2.energy-bound`; A3.Ex131.m1/m2 map to `C2.form-equality` and `C2.form-bound`. They remain `display=inline` inside A3.EGx13, and their exact equalities are not lost behind their inequalities. The target-moment split table S4.EGx1/S4.Ex16 is explicitly excluded for the proper peer-result reason. The C.2 paragraph groups p1 through p19, including p2/p9 strategy bridges and p18 constant simplification, all have mathematically appropriate coverage. No silent substantive source region was found in these three sections.

The following distinctions are correctly present and should be preserved in a repair overlay:

* `C5.range`, `C5.gram-expectation`, `C5.weighted-expectation`, `C5.feature-norm`, `C5.feature-gram` and `C5.feature-weighted` are separate nodes; `e-C5-aggregate` joins their conclusions rather than using the aggregate as a cyclic parent of every conjunct.
* The deterministic range route uses Chebyshev degree/nonzero leading coefficients, a triangular coefficient transform, actual column normalizations, K's generators and image/column-span algebra. It does not use the Gaussian row law, full rank, a matrix event, tau or the output theorem. Invertibility is at polynomial coefficient level, not linear independence of evaluated vectors.
* B's source scaling is exact: common 1/sqrt(d), zero mode 1, positive modes sqrt(2), tensor order start then mode; g itself is unscaled source data. No normalized-start substitution appears. Formal Fin indices match source spatial/start indices by adding one and mode index directly.
* `C2.witness` is existential and common to both exact forms. `E.coefficient-algebra` correctly needs no rank, distribution, D symmetry or event. Source signed weighted equality is identified as the exact algebra underneath the displayed absolute-value equality.
* The two norm estimates are AND components on the same event and same coefficient. There is no false OR between span inclusions or between the energy and weighted branches. The source gives one route; `or_routes=[]` and `alternative_OR_routes=[]` are appropriate.
* `C6.event` correctly depends on Gaussian rows, deterministic feature moments, truncation/bias/norm/variance estimates, Bernstein and event/constant bookkeeping. It does not consume `C5.range`. The matrix-Bernstein theorem remains an external, unproved-in-slice leaf without an invented numbered citation. No external leaf is certified by a compiler import.
* The unweighted t identity retains the zero-frequency diagonal contribution; the weighted triple products use positive frequencies 1 through 4q+1<2d. Truncation has a common scalar a and exactly zero weighted mean; no unnecessary weighted bias is invented. The probability accounting .999/.996/.995 and .995>=.99 is consistent with the source.
* K.output-context, Haar/target experiment, target moments and admissibility are contextual/peer or later output-use nodes, not parents of the focal deterministic identities. A prospective output use of Lemma 4.4 is not a proof of that lemma.

The edge parents `G.rows-law` in `e-gram-mean`/`e-weighted-mean` may be read through their marginal-law/covariance content: inter-row independence is not necessary for those two expectations. Their discharge prose already points to the standard Gaussian second moment; I do not demand new Gaussian-law nodes merely to duplicate that projection. Any public rendering must not label row independence itself as necessary for the expectation identities. Similarly, HF.grid and C2.features are definition bundles, whose unused fields are not new logical hypotheses at each consumer.

The generic discharge wording “unconditional pointwise algebra” on `e-C5-aggregate` and `e-L44` is imprecise for probabilistic conclusions. Read as logical assembly *after the listed conditional source results*, it does not eliminate their law/event hypotheses; it is not itself a new mathematical defect. A wording cleanup to “conjunction/implication under the previously stated source experiment and conditions” is advisable in the same versioned overlay, especially if a renderer might otherwise flatten context.

## Exact typed overlay comparison

The overlay's P/T exact signatures are byte-identical to the challenger's frozen Phase 2a signatures. The semantic conclusions, intended source roots, deterministic-pointwise strengthening, signed algebraic elaboration, real Euclidean norm and inner orientation, zero cases and same existential witness all agree with the independent judgment. Its excluded parents correctly reject G.rows-law, target moments, concentration, Haar experiment, full rank and unique coefficients for the two exact roots.

The labels SOURCE/TYPING on data κ, x and v, and SOURCE/STANDING on inherited hq, differ from this challenger's classification vocabulary. The overlay explicitly distinguishes data, conclusion witnesses and actual logical premises; it makes no additional assumption from these labels. I find no mathematical discrepancy or EXCESS premise on that account. The source-supported hypotheses remain hκ, hq and the consumer's v∈K restriction, with c concluded.

The selected T mathematically consumes only P's reverse inclusion for existence, followed by ordinary Euclidean matrix identities. This is a meaningful prospective consumer, not a new compiled edge. The overlay correctly states targets not compiled, no observed compiled parents, no sourceV or topology approval, no target files read and no generic API search. Those are scope statements, not proof evidence. The present review likewise makes no claim about actual Lean use or source-wide completion.

## Disposition and required next version

Required repair set is exactly R1 and R2. No source statement repair, binder change, normalization change, extra hypothesis, new OR-route, implementation search or theorem proof is requested. Produce a **new frozen author overlay/version** identifying how it supersedes the exact old `e-witness` use-site record and where the diagonal-power representation obligation is discharged/accounted for. Do not overwrite either frozen graph or either of this challenger's frozen mathematical baselines. Recheck only those changes against this frozen judgment before calling the dependency account necessity-complete. The current packet is not global sourceV, actual compiled proof credit, or authority to alter any owner/Goal/ledger/frontier.
