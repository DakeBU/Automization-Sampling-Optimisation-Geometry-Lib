from pathlib import Path
from hashlib import sha256
import json
from bs4 import BeautifulSoup
from copy import deepcopy

ROOT=Path('/Users/zhouhuanjian/ASTIS-GC')
BASE=ROOT/'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-determinant-semantic-evidence'
P1=BASE/'source-only-review/phase1'
OUT=BASE/'source-only-review/phase2'
PRIVATE=ROOT/'.astis/huanjian-fixed-spectrum-determinant-20261108/source-graph-486201'
def digest(p):return sha256(p.read_bytes()).hexdigest()
def rel(p):return str(p.relative_to(ROOT))
def dump(name,body):
    p=OUT/('source_graph_486201.'+name+'.json')
    p.write_text(json.dumps(body,ensure_ascii=False,indent=2)+'\n')
    return p
prefix='src:arxiv:2610.20492v1:'
def sid(x):return prefix+x

manifest1=PRIVATE/'phase1-freeze-manifest.json'
assert digest(manifest1)=='56a8ad22412ec59b837b45921da72255783bba51cb492b62d5c4d2ea46d53477'
p1=json.loads(manifest1.read_text())
for entry in p1['artifacts']+p1['raw_inputs']+[p1['private_generator']]:
    assert digest(ROOT/entry['path'])==entry['sha256'],entry['path']
seal_path=ROOT/'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-determinant-statement-seal.json'
context_path=BASE/'necessary-meaning-context.json'
disclosure_path=BASE/'postseal-necessary-meaning-exposure.json'
assert digest(seal_path)=='15d7e92a84617b97ee7e9b105da967e1c6598a9ca2d6a06596c8974e25b05354'
assert digest(context_path)=='1b2d1b1bc748ad0d6c7620297bc34dfdd884eb7f8e34d246183185d12deb6de4'
assert digest(disclosure_path)=='eeebdf201a058d922b25efa4d827c66d653ef2b72e41191fe22747fb4b19b8ec'
seal=json.loads(seal_path.read_text())
context=json.loads(context_path.read_text())
signature=seal['exact_signature_utf8']
signature_hash=sha256(signature.encode()).hexdigest()
assert signature_hash=='1c55aaf1c9c11d4e1cdb1b565d3327fa8274e9a78f6440ca577b6c49b880f2dd'
for e in context['files']:
    assert sha256(e['exact_text'].encode()).hexdigest()==e['sha256']
    assert digest(ROOT/e['path'])==e['sha256']
graph_path=P1/'source_graph_486201.proof_graph.json'
coverage_path=P1/'source_graph_486201.coverage.json'
slots_path=P1/'source_graph_486201.seven_slots.json'
contract_path=P1/'source_graph_486201.source_contract.json'
oldgraph=json.loads(graph_path.read_text())
oldcoverage=json.loads(coverage_path.read_text())
oldslots=json.loads(slots_path.read_text())
assert len(oldgraph['nodes'])==36 and len(oldgraph['edges'])==27
raw_path=ROOT/'.astis/huanjian-resume-20261103/2610.20492v1.html'
assert digest(raw_path)=='6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
raw_bytes=raw_path.read_bytes()
raw_soup=BeautifulSoup(raw_bytes,'html.parser')
def normalized(e):
    e=deepcopy(e)
    for m in e.find_all('math'):m.replace_with(' $'+m.get('alttext','')+'$ ')
    return ' '.join(e.get_text(' ',strip=True).split())
auxiliary_regions=[]
for anchor in ['S2.p2','S1.p1.1']:
    e=raw_soup.find(id=anchor)
    text=normalized(e)
    auxiliary_regions.append({'anchor':anchor,'normalized_text':text,
       'normalized_text_sha256':sha256(text.encode()).hexdigest(),
       'raw_source_sha256':digest(raw_path),
       'math':[{'anchor':m.get('id'),'formula_latex':m.get('alttext','')} for m in e.find_all('math')],
       'citations':[c.get_text(' ',strip=True) for c in e.find_all('cite')]})
coverage_corrections=[
 {'id':'phase2-coverage-correction:conditioned-Haar-definition',
  'raw_anchor':'S2.p2.1','subclause':'For b∈{−1,+1}, μ_{n,b} is Haar probability conditioned on det O=b.',
  'math_anchors':['S2.p2.m5','S2.p2.m6','S2.p2.m7'],
  'previous_disposition':'Phase1 parent region and all its mathematics inherited NODE references to S2:orthogonal and S2:haar, whose node statements omitted the μ definition.',
  'effective_disposition':'EXCLUDED',
  'reason':'The determinant-component statement is pointwise on full O(d). Conditioned Haar measures μ_{n,b} are unused distributional context; they are not a determinant prerequisite.',
  'scope_rule':'This explicit subclause exclusion overrides inherited Phase1 NODE coverage for these three math expressions and their associated clause only. The full-group definition, both components and their Haar masses remain covered by the original nodes.',
  'new_determinant_parent':False,'source_rechecked_independently':True},
 {'id':'phase2-coverage-correction:unnormalized-density-introduction',
  'raw_anchor':'S1.p1.1','effective_disposition':'EXCLUDED',
  'previous_issue':'Phase1 Z-meaning cited this anchor although it was outside the eight coverage/extraction roots. Its text is introductory query-access/application context.',
  'reason':'The paragraph says query access to an unnormalized density and cites applications. It does not define Z, specify an integration base measure or prove Gaussian integration. It is nonessential to the selected determinant/normalizer graph.',
  'auxiliary_citation_dispositions':[
    {'citation':'[7]','disposition':'EXCLUDED','reason':'Bayesian-inference application provenance; not invoked in this proof.'},
    {'citation':'[11]','disposition':'EXCLUDED','reason':'Numerical-simulation application provenance; not invoked in this proof.'},
    {'citation':'[16]','disposition':'EXCLUDED','reason':'Randomized-approximation application provenance; not invoked in this proof.'}],
  'source_rechecked_independently':True}]
anchor_corrections=[
 {'node':sid('A3.SS4:Z-meaning'),
  'phase1_source_anchors':['S1.p1.1','S4.SS1.p2.1','A3.SS4.p3.1','A3.Ex160'],
  'effective_phase2_source_anchors':['S4.SS1.p2.1','A3.SS4.p3.1','A3.Ex160'],
  'removed_anchor':'S1.p1.1','reason':'Introductory unnormalized-density query access does not establish an integral/base-measure definition. The conventional Z interpretation remains explicitly SOURCE_IMPLICIT, not source-defined by this introduction.',
  'phase1_rewritten':False,'new_integral_definition_inferred':False}]

candidate_id='sealed-statement:sha256:'+signature_hash
gap_id=sid('S4.E11:det-diagonal-product')
index_id='semantic-adapter:arxiv2610.20492v1:source-i-to-Fin-d'
new_nodes=[
 {'id':gap_id,'kind':'omitted-standard-bridge','source_status':'SOURCE_GAP',
  'source_anchors':['S4.E11','A3.Ex160'],
  'statement':'For Λ=diag(λ₁,…,λ_d), det Λ=∏_{i=1}^{d}λ_i.',
  'reason_for_phase2_addition':'The source uses det Λ; the sealed type makes its diagonal product explicit. Phase 1 had not split out this identity. It is a genuine required proof/representation bridge, not an additional theorem premise.',
  'source_proof_detail':'Standard finite-dimensional determinant identity, implicit in the source diagonal-matrix definition; not separately stated or proved in C.4.',
  'proof_status':'UNPROVED_IN_THIS_REVIEW','compiled_dependency':None},
 {'id':index_id,'kind':'source-to-type-index-adapter','source_status':'SEMANTIC_EXPANSION',
  'source_anchors':['S4.E11'],'statement':'For j:Fin d, source index i=j.val+1 runs exactly through 1,…,d. Then i−1/2=j.val+1/2, and the two θ, λ formulae agree after this reindexing.',
  'proof_status':'SEMANTIC_COMPARISON_ONLY_NOT_A_LEAN_PROOF',
  'division_sense':'The sealed θ has type Fin d→ℝ. Its half, the dimension cast, multiplication by π and division by d are real operations; d≥2 ensures a positive nonzero denominator.'},
 {'id':candidate_id,'kind':'sealed-type-endpoint','source_status':'MATCHES_SELECTED_COMPONENT_SUBJECT_TO_DISTINCT_TOPOLOGY_CHALLENGE',
  'seal_file':rel(seal_path),'seal_sha256':digest(seal_path),
  'signature_sha256':signature_hash,'exact_signature_utf8':signature,
  'claim_boundary':'Actual precision determinant equals the explicit product of the literal grid values, pointwise for every full real orthogonal O. No integral, density, Z, probability or lower-bound claim.',
  'proof_status':'NOT_INSPECTED_NOT_PROVED_BY_THIS_REVIEW'}]
new_edges=[
 {'id':'phase2-edge:diagonal-determinant-product','semantics':'AND',
  'prerequisites':[sid('S4.E11:diagonal')],'consumer':gap_id,
  'consumer_use_site':'A3.Ex160 det Λ; sealed statement conclusion ∏ i:Fin d, diagonalValue i',
  'actual_use':'The source diagonal determinant must be identified with the product to match the explicitly expanded sealed RHS.',
  'edge_kind':'source-omission/semantic-expansion','discharged':False},
 {'id':'phase2-edge:index-convention','semantics':'AND',
  'prerequisites':[sid('S4:domain'),sid('S4.E11:theta'),sid('S4.E11:lambda'),sid('S4.E11:diagonal')],
  'consumer':index_id,'consumer_use_site':'Sealed θ/diagonalValue lets and product index Fin d',
  'actual_use':'Reindex the source 1,…,d coordinates by j.val+1, preserving the midpoint grid and every factor once.',
  'edge_kind':'semantic-index-adapter','discharged':'semantic comparison only; no compiler proof checked'},
 {'id':'phase2-edge:sealed-determinant-component','semantics':'AND',
  'prerequisites':[sid('A3.SS4:det-conjugation'),gap_id,index_id],
  'consumer':candidate_id,'consumer_use_site':'Sealed conclusion A.det = ∏ i:Fin d, diagonalValue i',
  'actual_use':'Compose the source orthogonal-conjugation determinant identity with the diagonal-product identity, using the exact source/type indexing correspondence.',
  'edge_kind':'statement-match-overlay','discharged':False}]
graph_match={'schema_version':1,'actor':'source-graph-486201','phase':2,
 'artifact_kind':'source-graph-to-sealed-type-matching-overlay',
 'phase1_graph':{'path':rel(graph_path),'sha256':digest(graph_path),'nodes':36,'edges':27,'rewritten':False},
 'phase1_manifest_sha256':digest(manifest1),
 'new_nodes':new_nodes,'new_edges':new_edges,
 'source_anchor_corrections':anchor_corrections,
 'alternatives':'No source OR-route is introduced. Determinant conjugation and diagonal-product expansion are AND ingredients for this explicit-product statement.',
 'selected_source_root':sid('A3.SS4:det-conjugation'),
 'candidate_endpoint':candidate_id,
 'downstream_preservation':{
  'combined_normalizer':sid('A3.Ex160:normalizer-fixed-spectrum'),
  'required_gaussian_integral':sid('A3.SS4:gaussian-integral'),
  'unchanged_AND_edge':'edge:combined-normalizer',
  'status':'All phase-1 source obligations and edges remain unchanged and unproved by this review. Selecting the determinant component does not certify or erase Gaussian integration, integrability, target density or known-Z claims.'},
 'proof_credit':False,'independent_topology_approval':False,
 'next_required_review':'Distinct actor challenges the full raw-source coverage and graph, including this diagonal-product refinement, before implementation admission.'}
dump('phase2_graph',graph_match)

slot_match={
 'objects':{
  'source':'Literal θ_i,λ_i,Λ; real O∈O(d); A=OΛOᵀ; actual determinant.',
  'sealed_type':'θ:Fin d→ℝ; diagonalValue:Fin d→ℝ; A=(O:Matrix)*Matrix.diagonal diagonalValue*(O:Matrix).transpose; A.det; finite product.',
  'finding':'MATCH: exact matrix and diagonal values occur in the proposition itself, with no free Λ or supplied determinant value.',
  'definition_evidence':'Supplied determinant definition is detRowAlternating M via alternatization, documented as Leibniz determinant. It is not a substitute trace/absolute determinant/provider predicate.'},
 'domains':{
  'source':'d integer≥2, κ real≥2; source i=1,…,d; real d×d matrices; every O in full O(d).',
  'sealed_type':'{d:ℕ} (hd:2≤d) {κ:ℝ} (hκ:2≤κ) (O:Matrix.orthogonalGroup (Fin d) ℝ).',
  'finding':'MATCH: natural d≥2 agrees with the positive integer source domain; κ has the exact lower endpoint; Fin d gives exactly d real coordinates. Full orthogonal carrier, no SO(d) restriction.',
  'definition_evidence':'orthogonalGroup abbreviates unitaryGroup with local starRingOfComm and is documented as transpose-inverse matrices. unitaryGroup abbreviates unitary(Matrix ...); unitary carrier requires star U*U=1 and U*star U=1. This imposes orthogonality rather than a determinant-sign condition.'},
 'quantifiers':{
  'source':'For fixed admissible d,κ and their literal Λ, for every O∈O(d).',
  'sealed_type':'Universal source parameters followed by arbitrary O. θ, diagonalValue and A are literal lets, not existentially supplied witnesses or hypotheses.',
  'finding':'MATCH: pointwise in every O, including both determinant signs. O Haar/seed independence are experiment context rather than premises required by this pointwise algebraic identity.'},
 'assumptions':{
  'source':'d≥2; κ≥2; actual full orthogonal O; fixed definitions.',
  'sealed_type':'Only hd,hκ and O’s genuine orthogonal subtype carrier. No positivity, determinant equality, normalizer, spectral certificate, density certificate, provider or Haar hypothesis.',
  'finding':'MATCH: no excess mathematical premise in the sealed interface. The algebraic determinant identity can be more general, but retaining source endpoints is source faithful.',
  'binder_audit':[{'item':'d:ℕ and real κ','class':'TYPING'},
                  {'item':'hd:2≤d, hκ:2≤κ','class':'STANDING','source':'S4.SS1.p1.1'},
                  {'item':'O:full real orthogonal group','class':'SOURCE','source':'S2.p2; S4.Thmtheorem6'},
                  {'item':'θ, diagonalValue,A lets','class':'LITERAL_DEFINITION_NOT_NEW_PREMISE'}],
  'excess_binders_found':[]},
 'conclusion':{
  'source':'The determinant equality det A=det Λ used in the second equality of Ex160.',
  'sealed_type':'A.det=∏ i:Fin d, diagonalValue i.',
  'finding':'SEMANTIC MATCH WITH EXPLICIT STANDARD BRIDGE: det(diagonal λ)=∏λ plus exact source/Fin indexing. Neither bridge is smuggled in as a binder.',
  'graph_refinement':gap_id,'proof_obligation_status':'Unproved in this review; theorem implementation not inspected.',
  'excluded_claims':['Gaussian integral formula','Normalizer/known-Z equality','Density identification','C.4 calculus/minimizer','Main lower bound']},
 'scopes_senses':{
  'source':'Literal midpoint grid and full orthogonal precision conjugation. The selected determinant component is distinct from the combined Gaussian-normalizer claim.',
  'sealed_type':'For j:Fin d, θ_j=((j.val:ℝ)+1/2)*π/(d:ℝ), diagonalValue_j=(κ+1)/2+(κ−1)/2*cos θ_j. Product over all Fin d.',
  'finding':'MATCH: source i=j.val+1 gives i−1/2=j.val+1/2. Positive d makes the denominator well-defined in the source sense. Product enumerates each source eigenvalue exactly once. Transpose is ordinary matrix transpose; the source object is a precision matrix.',
  'definition_scope_limit':'Only supplied definition snapshots were inspected. No determinant proof, group API, local implementation or target code was used. Matrix star/coe machinery was not searched; the supplied orthogonal alias documentation and carrier definitions state transpose-inverse semantics.',
  'no_normalizer_definition_needed':'The candidate has no Z/integral/density symbol, so no such definition is exposed in this phase. Its downstream source prerequisites remain on the frozen graph.'},
 'constant_dependencies':{
  'source':'Midpoint shift 1/2, angle scale π/d, eigenvalue center (κ+1)/2, amplitude (κ−1)/2; determinant value depends on d,κ via this grid and not O.',
  'sealed_type':'All four literal constants/operations match. No hidden coefficient, δ,ε,q,n or asymptotic C occurs.',
  'finding':'MATCH: RHS explicitly depends only on d,κ. The normalizer factor (2π)^{d/2} and exponent −1/2 are absent because this is only the selected determinant component.'}}
assert len(slot_match)==7
dump('phase2_slot_matching',{
 'schema_version':1,'phase':2,'actor':'source-graph-486201',
 'phase1_seven_slots':{'path':rel(slots_path),'sha256':digest(slots_path)},
 'seal_sha256':digest(seal_path),'signature_sha256':signature_hash,
 'canonical_slot_comparison':slot_match,
 'statement_matching_verdict':'The exact sealed type matches the selected source determinant component with an explicit diagonal-product expansion. No blocking source/type delta found in the allowed inputs.',
 'claim_limits':'This is sourcegraph↔type matching, not source-blind semantic decoding, accepted topology review, proof verification, source-V, normalization proof or source completion.',
 'blocking_deltas':[],
 'required_unproved_bridges':[sid('A3.SS4:det-conjugation'),gap_id],
 'independent_topology_challenge_required':True})

dispositions=[]
for n in oldgraph['nodes']:
    key=n['id']
    if key in [sid('S4:domain'),sid('S4.E11:theta'),sid('S4.E11:lambda'),sid('S4.E11:diagonal'),sid('S4:rotation'),sid('S2:orthogonal')]:
        use='Definition/domain input represented literally or by the supplied full orthogonal carrier in the sealed type.'
        state='MATCHED_TYPE_INPUT_NOT_PROOF_COMPLETE'
    elif key==sid('A3.SS4:det-conjugation'):
        use='Selected determinant source component; sealed explicit product adds the phase2 diagonal-product bridge.'
        state='MATCHED_SELECTED_COMPONENT_NOT_PROOF_COMPLETE'
    else:
        use='Retained phase1 source context/obligation; not claimed by this sealed determinant statement.'
        state='RETAINED_OUTSIDE_SELECTED_CONCLUSION_NO_PROOF_CREDIT'
    dispositions.append({'source_node':key,'source_anchors':n['source_anchors'],'phase2_disposition':state,'reason':use,'proved_by_phase2':False})
dump('phase2_coverage_matching',{
 'phase':2,'actor':'source-graph-486201',
 'phase1_coverage':{'path':rel(coverage_path),'sha256':digest(coverage_path),'modified':False,
                    'region_math_text_records':len(oldcoverage['regions_and_math_and_text_nodes']),
                    'DOM_elements':len(oldcoverage['full_selected_element_inventory'])},
 'existing_node_dispositions':dispositions,
 'additional_required_source_expansion':gap_id,
 'explicit_phase2_coverage_corrections':coverage_corrections,
 'effective_source_anchor_corrections':anchor_corrections,
 'raw_reinspection_regions':auxiliary_regions,
 'raw_source_exhaustiveness_claim':'Phase1 exhaustive inventory is preserved; its mathematical approval is still pending a distinct reviewer.',
 'do_not_erase':['A3.SS4.p1.1 unnamed spectral estimates','A3.SS4.p2.1 calculus/convexity/minimizer statements',
                 'A3.SS4.p3.1 Gaussian integration','A3.Ex160 full equality chain','A3.SS4.p3.2 conditional known-Z conclusion'],
 'all_proof_node_completion_flags':False})

inputs=[{'path':rel(manifest1),'sha256':digest(manifest1),'role':'frozen-pre-candidate-phase1-manifest'}]
inputs += [{'path':e['path'],'sha256':e['sha256'],'role':'frozen-phase1-artifact'} for e in p1['artifacts']]
inputs += [{'path':rel(p),'sha256':digest(p),'role':role} for p,role in [
    (seal_path,'sealed-type-and-disclosed-packet-metadata'),
    (context_path,'necessary-definition-only-packet'),
    (disclosure_path,'root-incidental-definition-lookup-exposure-disclosure')]]
inputs += [{'path':e['path'],'sha256':e['sha256'],'role':'necessary-definition-only-snapshot'} for e in context['files']]
inputs += [{'path':rel(raw_path),'sha256':digest(raw_path),'role':'independent-reinspection-of-S2.p2-and-S1.p1.1-to-resolve-distinct-coverage-challenge'}]
dump('phase2_inputs_provenance',{
 'phase':2,'actor':'source-graph-486201','inputs':inputs,
 'signature_utf8_sha256':signature_hash,
 'underlying_raw_source':{'path':'.astis/huanjian-resume-20261103/2610.20492v1.html','sha256':'6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'},
 'provenance_chain':'Pinned raw source → independently frozen phase1 contract/graph/coverage/seven slots → exact sealed type + minimal definition snapshots → this separate phase2 matching overlay.',
 'not_replayed':'No earlier source approval, implementation graph, API inventory or prior candidate review was used as matching evidence.'})
dump('phase2_exposure',{
 'phase':2,'actor':'source-graph-486201','source_first_phase1_manifest_sha256':digest(manifest1),
 'new_content_read':[rel(seal_path),rel(context_path),rel(disclosure_path)],
 'definition_snapshots':[{'path':e['path'],'sha256':e['sha256'],'read_scope':'exact definition text only, supplied in necessary-meaning-context; file bytes verified'} for e in context['files']],
 'seal_metadata_exposure':'The authorized seal also contains root source/binder interpretation, planned consumer and type-only receipt metadata. These were seen after phase1 froze; none was treated as an independent verdict or proof. Linked preseal audit, receipt/log and implementation/consumer files were not opened.',
 'root_incidental_exposure_disclosure':'Disclosure reports root saw adjacent generic one_mem simp proof and mul_mem header at Unitary.lean34–38. Reviewer did not inspect that original lookup window or those proofs/API contents.',
 'names_only_discovery':'Only the two exact context/disclosure filenames were discovered under this packet directory.',
 'distinct_challenge_exposure':'Parent forwarded three provisional raw-source followups after the Phase2 draft but before any Phase2 freeze: explicit diagonal determinant product, omitted conditional-Haar definition coverage, and introductory S1 Z-meaning anchor. These were independently checked against the pinned raw source; no prior verdict or implementation evidence was received.',
 'new_raw_source_reinspection':['S2.p2 (full orthogonal/Haar/μ_{n,b} paragraph)','S1.p1.1 (unnormalized-density introduction with application citations [7],[11],[16])'],
 'challenge_resolutions':coverage_corrections,
 'candidate_implementation_proof_exposed':False,'candidate_API_search':False,
 'root_oldgraph_review_frontier_or_floor_API_contents_exposed':False,
 'Tests_or_consumer_implementation_exposed':False,
 'phase1_bytes_modified':False,
 'consumer_status':'Same-A spectrum-only density consumer remains a plan in seal metadata. Its exact interface/carriers require a separate seal before implementation; no consumer has been validated here.',
 'review_scope':'Source graph and seven-slot match to exact sealed type only; stop for distinct topology challenge.'})

report=r'''# Phase-2 matching — source-graph-486201

The exact sealed determinant statement matches the selected source component. No blocking source/type delta was found in the supplied statement and definition context. This is a statement-matching result; no implementation proof was inspected, and independent topology challenge remains required.

The signature SHA-256 is `1c55aaf1c9c11d4e1cdb1b565d3327fa8274e9a78f6440ca577b6c49b880f2dd`. Its source boundary is the second equality used in Appendix C.4 Ex160, with the literal Eq. (11) grid. The frozen Phase-1 manifest remains `56a8ad22412ec59b837b45921da72255783bba51cb492b62d5c4d2ea46d53477`; no Phase-1 bytes were changed.

The type retains d≥2, κ≥2 and arbitrary O in full real O(d), including both determinant signs. It forms the actual precision matrix OΛOᵀ in a let and concludes its actual determinant equals the explicit product of its displayed diagonal values. There is no determinant-sign, PosDef, spectral-certificate, normalizer, density or provider premise. The supplied ordinary determinant and orthogonal-carrier definitions support these meanings; no target proof or API was searched.

The literal source index is i=1,…,d; the type uses j:Fin d. Under i=j.val+1, the source numerator i−1/2 is j.val+1/2. Thus the midpoint angles and affine cosine eigenvalues agree, and the product ranges over each source coordinate once. Real casts and divisions preserve the source constants.

The sealed product makes one implicit bridge explicit:

\[
\det\!\bigl(\operatorname{diag}(\lambda_1,\ldots,\lambda_d)\bigr)
=\prod_{i=1}^{d}\lambda_i.
\]

This standard diagonal-determinant identity was not a separate Phase-1 node. It is appended here as `SOURCE_GAP`, with no proof-completion credit. It and determinant invariance are AND ingredients for the explicit-product endpoint. The graph refinement records the mathematical work still needed rather than treating either identity as a theorem binder.

A distinct provisional source challenge identified two coverage details, and I independently re-read both raw paragraphs before this freeze. In S2.p2, the conditional-Haar definition μ_{n,b} had inherited broad coverage from nodes whose statements did not include it. Phase 2 explicitly excludes that unused subclause and its three expressions; it creates no determinant parent. S1.p1.1 is now inventoried as auxiliary excluded introduction/application context, including its three citations, and removed from the effective Z-meaning source anchors. Its unnormalized-density query-access wording supplies no Gaussian-integral or base-measure definition. These corrections are separate overlays; Phase-1 bytes remain unchanged, and the normalizer meaning remains explicitly source implicit.

The selected determinant statement does not claim Gaussian integration, integrability, a normalizer value or density identification. The entire Phase-1 graph remains intact: a combined determinant-plus-Z claim still needs Gaussian integration as an actual prerequisite. The C.4 calculus/minimizer statements, main bounds and other paper obligations remain outside this statement and unproved by this review. The same-A spectrum-only density consumer mentioned in the seal remains planned; its exact interface and carriers need separate sealing before implementation.

All seven semantic slots are compared in the JSON record. Existing source coverage receives only input/component/context matching dispositions; no source proof node becomes complete. The next step is a distinct raw-source topology challenge, including this diagonal-product expansion. No source-V, accepted semantic round trip or source-completion claim is made.
'''
(OUT/'source_graph_486201.phase2_report.md').write_text(report)

# Structural-only validation of matching metadata and the unchanged source graph.
all_nodes={n['id'] for n in oldgraph['nodes']}|{n['id'] for n in new_nodes}
all_edges=oldgraph['edges']+new_edges
parents={n:set() for n in all_nodes}
for e in all_edges:
    assert e['consumer'] in all_nodes
    assert set(e['prerequisites'])<=all_nodes
    parents[e['consumer']].update(e['prerequisites'])
def ancestors(n,active=frozenset()):
    assert n not in active,'cycle'
    out=set(parents[n])
    for p in parents[n]:out.update(ancestors(p,active|{n}))
    return out
for n in all_nodes:ancestors(n)
integ=sid('A3.SS4:gaussian-integral')
assert integ not in ancestors(candidate_id)
assert gap_id in ancestors(candidate_id)
assert integ in ancestors(sid('A3.Ex160:normalizer-fixed-spectrum'))
assert sid('A3.SS4:det-conjugation') in ancestors(sid('A3.Ex160:normalizer-fixed-spectrum'))
for e in p1['artifacts']+[p1['private_generator']]:assert digest(ROOT/e['path'])==e['sha256']
assert digest(manifest1)=='56a8ad22412ec59b837b45921da72255783bba51cb492b62d5c4d2ea46d53477'
dump('phase2_structural_validation',{
 'result':'PASS','kind':'structural-only','all_input_hashes_verified':True,
 'signature_hash_verified':True,'all_four_definition_snapshot_hashes_verified':True,
 'phase1_unchanged':True,'seven_slots_present':True,'graph_acyclic':True,
 'candidate_requires_diagonal_product_bridge':True,
 'candidate_determinant_component_does_not_claim_integral':True,
 'combined_normalizer_still_requires_gaussian_integral':True,
 'proof_nodes_marked_complete':False,'independent_topology_approval':False})

paths=sorted(OUT.glob('source_graph_486201.*'))
paths=[p for p in paths if 'freeze_manifest' not in p.name]
freeze={'schema_version':1,'phase':2,'actor':'source-graph-486201',
 'freeze_status':'FROZEN_FOR_DISTINCT_TOPOLOGY_CHALLENGE',
 'phase1_manifest_sha256':digest(manifest1),
 'signature_sha256':signature_hash,'inputs':inputs,
 'artifacts':[{'path':rel(p),'sha256':digest(p),'bytes':p.stat().st_size} for p in paths],
 'private_generator':{'path':rel(PRIVATE/'build_phase2.py'),'sha256':digest(PRIVATE/'build_phase2.py')},
 'stop_condition':'Stop here. No implementation/proof/API work or topology self-approval authorized by this phase.',
 'limits':'Statement-match overlay only; all proof/source-completion credit remains absent.'}
mp=OUT/'source_graph_486201.phase2_freeze_manifest.json'
mp.write_text(json.dumps(freeze,ensure_ascii=False,indent=2)+'\n')
(OUT/'source_graph_486201.phase2_freeze_manifest.sha256').write_text(digest(mp)+'  '+mp.name+'\n')
print(json.dumps({'phase2_manifest':rel(mp),'sha256':digest(mp),
                  'artifacts':freeze['artifacts'],'inputs':inputs,
                  'phase1_unchanged':True,'status':'STOP_FOR_DISTINCT_TOPOLOGY_CHALLENGE'},ensure_ascii=False,indent=2))
