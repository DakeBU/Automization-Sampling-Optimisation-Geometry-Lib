from pathlib import Path
import json, hashlib, datetime, shutil

ROOT=Path('/Users/zhouhuanjian/ASTIS-GC')
BASE=ROOT/'.astis/semantic-neutral-20261112/ri_sg_78c2'
RAW=BASE/'raw-freeze-v1'
PACKET=ROOT/'.astis/huanjian-gc-source-row-independence-20261112/selective-type-definition-packet.json'
OUT=BASE/'type-phase-v1'
assert not OUT.exists(), 'Versioned phase freezes are never overwritten.'
def sha(b):return hashlib.sha256(b).hexdigest()
def readj(p):return json.loads(p.read_text(encoding='utf-8'))
pb=PACKET.read_bytes();assert sha(pb)=='c9f8312610515f2ebc067612c981889103e7d8a93a00aa5f75ec8c74feb1ab68'
p=json.loads(pb)
rawmb=(RAW/'frozen-manifest.json').read_bytes()
assert sha(rawmb)=='2bdc92ca14e919b33ec81f8480e8782bf0fe16e94fca4442e2f1e15ad040b351'
rm=json.loads(rawmb)
for f in rm['files']:
    b=(RAW/f['path']).read_bytes();assert len(b)==f['bytes'] and sha(b)==f['sha256'],f['path']
assert p['statement_seal_sha256']=='88a55849ce9e13a9a04edff6aac13ce32d4370712b1b7a422fba0d570ff0b25e'
assert p['minimal_definition_context_sha256']=='bb8e77b15c4905a3b5d4aa37e482314e44a5d97886088c72b91f36050bcf9860'
for k in ['producer','actual_private_consumer']:
    assert sha(p[k]['signature'].encode())==p[k]['signature_sha256']
ctx=p['minimal_definition_context']
assert sha(ctx['literal_current_prints_and_instances'].encode())==ctx['literal_current_prints_sha256']
for excerpt in ctx['literal_definition_excerpts']:
    assert sha(excerpt['literal_source'].encode())==excerpt['literal_source_sha256']
source=(RAW/'inputs/2610.20492v1.html').read_bytes();s=source.decode()
assert sha(source)==p['source']['raw_sha256']
for a in p['source']['anchors']:
    raw=source[a['raw_utf8_start']:a['raw_utf8_end']]
    assert sha(raw)==a['span_sha256']
    assert raw==s[a['char_start']:a['char_end']].encode()

OUT.mkdir();(OUT/'inputs').mkdir()
def dump(name,v):(OUT/name).write_text(json.dumps(v,ensure_ascii=False,sort_keys=True,indent=2)+'\n',encoding='utf-8')
def write(name,t):(OUT/name).write_text(t,encoding='utf-8')
(OUT/'inputs/selective-type-definition-packet.json').write_bytes(pb)
(OUT/'inputs/raw-freeze-v1.manifest.json').write_bytes(rawmb)
shutil.copyfile(BASE/'working/build_type_phase_v1.py',OUT/'inputs/build_type_phase_v1.py')
for k,n in [('producer','producer.signature.txt'),('actual_private_consumer','consumer.signature.txt')]:
    write('inputs/'+n,p[k]['signature'])

bindings={'packet_sha256':sha(pb),'raw_freeze_manifest_sha256':sha(rawmb),
 'statement_seal_sha256':p['statement_seal_sha256'],
 'producer_signature_sha256':p['producer']['signature_sha256'],
 'consumer_signature_sha256':p['actual_private_consumer']['signature_sha256'],
 'minimal_definition_context_sha256':p['minimal_definition_context_sha256'],
 'mathlib_pin':ctx['mathlib_pin']}

binder=[
 {'logical_input':'d : Nat','classification':'TYPING','source':'Physical finite dimension d.','audit':'Exact. Natural dimension is supplied, not a real-valued parameter.','source_atoms':['experiment.natural-standing']},
 {'logical_input':'q : Nat','classification':'TYPING','source':'Nonnegative integer query count, including zero.','audit':'Exact. There is no positivity requirement on q.','source_atoms':['experiment.natural-standing','c2.r']},
 {'logical_input':'hq : 2*q+1 < d','classification':'STANDING','source':'Lemma 4.4 standing range.','audit':'Exact. Any d positivity/cardinality/log-domain facts are internal consequences. The independence fact is not weakened by retaining the source standing range.','source_atoms':['experiment.natural-standing']},
 {'logical_input':'Local let definitions in both targets','classification':'NOT_A_LOGICAL_INPUT','source':'Literal named objects on a fixed experiment.','audit':'No existential witness, regularity/independence/measure certificate or bundled theorem is supplied by these lets.'},
 {'logical_input':'Inferred real, finite, Euclidean and canonical measurable-space structure','classification':'TYPING','source':'Usual finite real vector and matrix carriers.','audit':'Canonical inferred structures; no caller-chosen measurable-space or measure argument. Applicability/compatibility are internal verification ports.'}]

defs=[
 {'object':'D','kind':'literal','formal':'EuclideanSpace R (Fin d)','source':'R^d','audit':'The canonical l2 real vector space with coordinates i.val+1. EuclideanSpace expands to PiLp 2; no Gaussian law on the norm of Omega is asserted.','status':'MATCH'},
 {'object':'E','kind':'literal','formal':'EuclideanSpace R (Fin(q+1))','source':'R^r, r=q+1','audit':'The row vector has exactly r actual Gaussian-column coordinates.','status':'MATCH'},
 {'object':'Omega and mu','kind':'literal canonical experiment','formal':'Omega=Fin(q+1)->D; mu=Measure.pi(fun _=>stdGaussian D)','source':'r independent standard d-Gaussian columns','audit':'A fixed canonical realization of the source independent-column experiment. The supplied finite-product definition is consistent with that meaning. Product probability/coordinate-factorization applications remain internal ports. No arbitrary extended-ambient realization is covered.','status':'MATCH_CANONICAL_SPECIALIZATION'},
 {'object':'row','kind':'literal','formal':'row i omega=WithLp.toLp 2(fun a=>omega a i)','source':'gamma_i=((g_1)_i,...,(g_r)_i)^T','audit':'a.val+1 is source column a and i.val+1 is source physical row i; WithLp wrapping retains the coordinates. This is the same physical column sample, not independently resampled rows.','status':'MATCH'},
 {'object':'iIndepFun row mu','kind':'expanded standard predicate','formal':'Kernel.iIndepFun -> iIndep of comap row sigma-fields -> finite-intersection factorization, constant kernel on Unit under dirac()','source':'gamma_1,...,gamma_d are independent','audit':'Full family independence for all finite subsets and Borel row events. It is neither pairwise independence nor an iid predicate. It does not itself state that arbitrary row functions are measurable; actual row measurability is a separate internal obligation.','status':'MATCH'},
 {'object':'r and L','kind':'literal','formal':'r=((q+1:Nat):R); L=2*r+3*Real.log(1000*(d:R))','source':'r=q+1; L=2r+3log(1000d)','audit':'Exact real cast, factor 3 and factor 1000. Natural logarithm; d>0 follows internally from hq.','status':'MATCH'},
 {'object':'theta','kind':'literal','formal':'theta i=(((i.val:R)+1-(1/2:R))*Real.pi)/(d:R)','source':'theta_i=(i-1/2)pi/d, i=1,...,d','audit':'The +1 converts Fin d index to the literal source half-grid. The term 1/2 is real division, not Nat division.','status':'MATCH'},
 {'object':'t','kind':'literal','formal':'if k.val=0 then 1 else sqrt(2)*cos((k.val:R)*theta i)','source':'(1,sqrt(2)cos(theta_i),...,sqrt(2)cos(q theta_i))^T','audit':'Constant coordinate is exactly 1; positive feature k is the literal k-th cosine, k=1,...,q. q=0 yields the single constant coordinate. No norm/Gram bound is an input.','status':'MATCH'},
 {'object':'matrix carrier and measurable structure','kind':'literal finite entry array','formal':'(Fin(q+1) x Fin(q+1))->(Fin(q+1) x Fin(q+1))->R','source':'r^2 by r^2 real matrices','audit':'Definitionally Matrix; function measurable spaces are canonical finite product structures over ordinary measurable reals. Gaussian coordinate comes first in both paired indices. No topology or operator-norm conclusion is being claimed.','status':'MATCH'},
 {'object':'Y inside cutoff','kind':'literal','formal':'(d:R)^-1 scalar-multiplied kronecker(vecMulVec(row,row),vecMulVec(t,t))','source':'(1/d)(gamma_i gamma_i^T tensor t_i t_i^T)','audit':'At indices ((a,j),(b,k)), the entry is d^-1 * row_i[a]*row_i[b]*t_i[j]*t_i[k], with Gaussian-first order. Inverse d is the source 1/d. No transpose/conjugation or feature scaling is lost.','status':'MATCH'},
 {'object':'Y cutoff and zero branch','kind':'literal','formal':'if norm(row i omega)^2 <= L then matrix else 0','source':'matrix times 1_{R_i<=L}, R_i=||gamma_i||^2','audit':'Equality at L is included and the condition is local to i. Zero outside the source cutoff is the exact indicator semantics, not a fallback for unproved existence. No conditioning on the common event T is introduced.','status':'MATCH'},
 {'object':'consumer conjunction','kind':'two target conclusions','formal':'(forall i,Measurable(Y i)) AND iIndepFun Y mu','source':'Define the independent truncated matrices (actual Ex107)','audit':'All-Y measurability makes the implicit random-matrix meaning explicit and is an output, not a premise certificate. Independence refers to the entire actual family under the identical fixed mu. t_i varies, so no identical-distribution assertion occurs.','status':'MATCH_WITH_SOURCE_IMPLICIT_MEASURABILITY_OUTPUT'}]

audit={'version':1,'phase':'POST_STATEMENT_SEAL_PRE_PROOF','bindings':bindings,
 'actor':'/root/row_indep_source_graph_78c2','independence':'Source/type auditor is distinct from the formalizer; this actor is not a source-blind decoder and does not supply semantic-roundtrip acceptance.',
 'verdict':'NO_GENUINE_TARGET_MEANING_OR_BINDER_ISSUE_FOUND',
 'scope':'Meaning/binder/definition correspondence only. Neither mathematical target has been proved or checked against implementation.',
 'producer':p['producer']['name'],'consumer':p['actual_private_consumer']['name'],
 'binder_audit':binder,'EXCESS':[],'public_proof_certificates':[],
 'definition_audit':defs,
 'semantic_slots':{
  'objects':'Same physical row maps from one r-column Gaussian sample; actual Ex107 matrices.',
  'domains':'d,q natural, 2q+1<d; Fin d physical rows, Fin(q+1) Gaussian/feature coordinates; finite real entry matrices.',
  'quantifiers':'For every permitted d,q. The experiment, rows and Y are local fixed lets; full finite family event factorization, with all Y maps measurable in consumer.',
  'assumptions':'Only natural typing and source standing hq. Canonical probability space is a literal choice of realization, not a new source event or theorem premise.',
  'conclusion':'Producer full row independence; consumer all Y measurable and full actual Y independence.',
  'scopes_and_senses':'One mu in producer and consumer; no arbitrary ambient transfer, pairwise-only interpretation, iid-Y assertion, conditioning or operator norm claim.',
  'constant_dependencies':'Exact r=q+1, closed threshold 2r+3log(1000d), literal half-grid and inverse d. No tau,kappa,C or event probability parameter.'},
 'q_zero_check':{'status':'MEANING_MATCH','reading':'r=1, d>=2, t_i=(1); Y_i is the scalar d^-1*(g_1)_i^2 times 1_{(g_1)_i^2<=2+3log(1000d)}. No extra q>0 condition.'},
 'important_boundaries':['iIndepFun by itself does not assert map measurability.','No row marginal-law result is used as a premise or evidence of joint independence.','The producer has no Gaussian-law output; row marginal laws remain source context.','The extra measurable-Y conclusion is source-implicit well-definedness, and its proof remains internal.','The packet names an existing canonical row-law node as a possible reuse, but supplies no node signature/proof; no actual compiled parent or call is inferred.','The literal stdGaussian print uses stdOrthonormalBasis. Its equality to coordinate product Gaussian in D is an unproved applicability port, not presumed by reading the name.'],
 'authorization_or_status_grant':False}
dump('type-audit.json',audit)

port_specs=[
 ('PORT.stdGaussian-coordinate-factorization','Gaussian-law applicability','Establish the joint coordinate product law of stdGaussian(EuclideanSpace R (Fin d)) for the physical evaluation coordinates. The supplied definition maps scalar Gaussian coefficients through stdOrthonormalBasis; the required physical-coordinate conclusion needs an applicable basis-coordinate result or invariant-standard-Gaussian argument.','c2.row-joint-independence',['SOURCE_GAP.gaussian-coordinate-product']),
 ('PORT.column-product-applicability','Finite product applicability','Use the fixed Measure.pi of standard d-Gaussian columns as an actual probability product. Discharge required measurability, finiteness/sigma-finiteness and rectangle/product hypotheses internally. The supplied context includes the product probability-instance expression but no new target proof.','c2.row-joint-independence',['SOURCE_GAP.product-regrouping']),
 ('PORT.finite-coordinate-regrouping','Omitted source bridge','Regroup the joint scalar array indexed by (a,i) into physical rows indexed by i without resampling or changing mu. Verify finite reindexing/evaluation/WithLp coordinate maps and the exact joint measure/sigma-field statement.','c2.row-joint-independence',['SOURCE_GAP.product-regrouping']),
 ('PORT.full-row-iIndepFun','Independence-predicate applicability','Derive full finite family independence of the row comap sigma-fields from the joint product/regrouping conclusion; identify the target iIndepFun, including the constant-kernel/Unit-dirac expansion. Scalar marginal laws or pairwise independence are insufficient.','c2.row-joint-independence',['SOURCE_GAP.row-sigma-fields']),
 ('PORT.row-measurability','Internal measurability bridge','For each physical i, show omega -> WithLp.toLp 2(fun a=>omega a i) is measurable for the actual canonical domain/codomain structures. Coordinate evaluation, finite vector assembly and WithLp measurable/Borel compatibility must apply. This can be proved directly; no hypothetical row-measurable input certificate.','Yi.all-measurable-output',['SOURCE_GAP.Yi-measurable-row-map']),
 ('PORT.local-cutoff-measurable','Internal measurability bridge','Prove x -> ||x||^2 measurable and {x:||x||^2<=L} measurable in E with its actual structure; the threshold is closed at equality and fixed by d,q.','Yi.all-measurable-output',['SOURCE_GAP.Yi-measurable-row-map']),
 ('PORT.matrix-row-map-measurable','Finite-entry matrix applicability','For each fixed i, prove F_i(x)=d^-1*(xx^T tensor t_i t_i^T)1_{||x||^2<=L} measurable into the explicit finite product real-entry array. Check finite entry evaluation, products/scalar action, piecewise map and canonical matrix/function measurable structures.','Yi.all-measurable-output',['SOURCE_GAP.Yi-measurable-row-map']),
 ('PORT.actual-Y-image-identity','Literal internal adapter','Identify the signature Y_i pointwise with F_i o row_i, including Euclidean-coordinate coercions, Gaussian-first paired indices, inverse d, <= branch and zero matrix. No abstract surrogate matrix may replace actual Ex107 Y.','Yi.joint-independence-source-claim',['SOURCE_GAP.independent-measurable-images']),
 ('PORT.Y-measurable-composition','Internal composition applicability','Compose row measurability and measurable F_i, then transfer along the actual-Y identity to all i. The forall-i field remains a target output.','Yi.all-measurable-output',['SOURCE_GAP.Yi-measurable-row-map']),
 ('PORT.independent-measurable-images','Independence-preservation applicability','Apply full-family independence preservation under separate i-dependent measurable F_i to the new producer row result, under that exact same mu; transfer using actual-Y identity. Verify the chosen library rule has discharged hypotheses. No theorem name or compiled producer call is asserted by this audit.','Yi.joint-independence-source-claim',['SOURCE_GAP.independent-measurable-images'])]
ports=[]
for id,kind,meaning,consumer,raw_ports in port_specs:
    ports.append({'id':id,'kind':kind,'meaning':meaning,'consumer':consumer,'raw_ports_refined':raw_ports,
      'status':'OPEN_UNPROVED_INTERNAL_PORT','source_status':'Source-supported inference expanding omitted bookkeeping; not an additional source hypothesis.','mathlib_applicability':'NOT_VERIFIED_BY_THIS_SOURCE_ONLY_TYPE_AUDIT','compiled_parents':[]})
dump('internal-bridge-and-applicability-ports.json',{'version':1,'bindings':bindings,'ports':ports,
 'no_public_premise_certificates':True,'no_compiled_parent_claims':True,
 'route_freedom':'Ports identify mathematical obligations. A future exact library theorem may discharge several at once; this does not require a separate helper declaration per port.'})

rawinv=readj(RAW/'inventory.json')
rawloc=readj(RAW/'locators.json')
items=[]
roles={
 'theta.half-grid':'Literal consumer-definition ancestor',
 'experiment.carriers':'Experiment notation context only; no Lambda/Krylov dependency',
 'experiment.natural-standing':'Source standing/type context for both targets',
 'experiment.independent-columns':'Source experiment supplied by fixed canonical mu, not a caller premise',
 'c2.r':'Literal finite row/feature cardinality',
 'c2.row-range':'Physical finite-family index set',
 'c2.literal-t':'Literal actual Yi deterministic factor',
 'c2.physical-gamma':'Literal physical row target map',
 'c2.row-joint-independence':'Producer source anchor',
 'c2.row-marginal-context':'Context only; no edge into row independence',
 'c2.B-definition-context':'Definition/normalization context only; not a theorem dependency of Yi',
 'c5.theta-recall-context':'Repeated definition context only',
 'c5.t-coordinate-context':'Feature coordinate convention context',
 'cutoff.literal-L':'Actual closed-cutoff threshold',
 'cutoff.literal-R':'Actual row-local squared radius',
 'Yi.joint-independence-source-claim':'Actual private-consumer source anchor',
 'Yi.actual-literal-definition':'Actual source matrix map, not a surrogate'}
for atom in rawinv['items']:
    new=dict(atom)
    new['post_seal_disposition']=atom['disposition']
    new['post_seal_role']=roles.get(atom['id'],'Explicitly excluded for the raw stated reason; exact sealed types introduce no need for this claim.')
    new['post_seal_proof_status']='NOT_PROVED_BY_THIS_AUDIT' if atom['disposition']=='NODE' else 'OUTSIDE_TARGET'
    new['raw_disposition_changed']=False
    items.append(new)
dump('coverage-v1.json',{'version':1,'phase':'POST_SEAL_SOURCE_GRAPH_EXTRACTION','bindings':bindings,
 'bounded_scope':rawinv['scope'],'items':items,
 'continuous_appendix_window_coverage':rawinv['continuous_appendix_window_coverage'],
 'excluded_outside_window_topics':rawinv['excluded_outside_window_topics'],
 'counts':{'atomic_items':len(items),'NODE':sum(i['disposition']=='NODE' for i in items),'EXCLUDED':sum(i['disposition']=='EXCLUDED' for i in items),'continuous_appendix_units':len(rawinv['continuous_appendix_window_coverage'])},
 'coverage_changes_after_types':[],
 'independent_topology_coverage_review':'NOT_SELF_APPROVED. This actor originally extracted the raw topology; a distinct topology coverage reviewer remains required by the protocol. This type audit is independent of the formalizer, not independent of this actor own raw extraction.',
 'whole_source_coverage_claim':False})

nodes=[{'id':a['id'],'kind':a['source_kind'],'source_element_id':a['source_element_id'],'locator':a['locator'],'meaning':a['meaning'],'status':'SOURCE_CONTEXT_OR_ASSERTION_UNPROVED'} for a in items if a['disposition']=='NODE']
nodes += [{'id':v['id'],'kind':v['kind'],'meaning':v['meaning'],'status':v['status']} for v in ports]
nodes += [
 {'id':'FORMAL.producer','kind':'exact sealed target','name':p['producer']['name'],'signature_sha256':p['producer']['signature_sha256'],'status':'SEALED_TARGET_UNPROVED'},
 {'id':'Yi.all-measurable-output','kind':'source-implicit well-definedness conclusion','meaning':'forall i,Measurable(actual Y_i) on the canonical product experiment','status':'TARGET_OUTPUT_UNPROVED'},
 {'id':'FORMAL.consumer','kind':'exact sealed target conjunction','name':p['actual_private_consumer']['name'],'signature_sha256':p['actual_private_consumer']['signature_sha256'],'status':'SEALED_TARGET_UNPROVED'}]
edges=[]
def edge(a,b,anchor,meaning,kind='direct source/definition use'):
    if isinstance(anchor,str):anchor=[anchor]
    loc=[]
    for ident in anchor:
        if ident in rawloc['source_units']:ll=rawloc['source_units'][ident]['locator']
        else:
            matches=[v for v in p['source']['anchors'] if v['source_id']==ident]
            assert matches,ident
            ll=matches[0]
        loc.append({'element_id':ident,'locator':ll})
    edges.append({'from':a,'to':b,'kind':kind,'consumer_use_sites':loc,'meaning':meaning,'formal_implementation_use_verified':False})
edge('theta.half-grid','c2.literal-t','A3.Ex85','Substitute the actual half-grid into t_i.')
edge('c2.r','c2.physical-gamma','A3.Ex85','The physical row contains r columns.')
edge('experiment.independent-columns','PORT.stdGaussian-coordinate-factorization','A3.SS2.p1.2','Unproved standard-Gaussian physical-coordinate law applicability.','inferred omitted source bridge')
edge('experiment.independent-columns','PORT.column-product-applicability','A3.SS2.p1.2','Fixed independent-column product experiment.','inferred omitted source bridge')
edge('PORT.stdGaussian-coordinate-factorization','PORT.finite-coordinate-regrouping','A3.SS2.p1.2','Within-column full coordinate product input.','inferred omitted source bridge')
edge('PORT.column-product-applicability','PORT.finite-coordinate-regrouping','A3.SS2.p1.2','Across-column product input.','inferred omitted source bridge')
edge('c2.physical-gamma','PORT.finite-coordinate-regrouping','A3.SS2.p1.2','Regroup these actual rows, with no new sampling.','inferred omitted source bridge')
edge('PORT.finite-coordinate-regrouping','PORT.full-row-iIndepFun','A3.SS2.p1.2','Convert joint row-product law to full independent row sigma-fields.','inferred omitted source bridge')
edge('PORT.full-row-iIndepFun','c2.row-joint-independence','A3.SS2.p1.2','Discharge the unnamed full-family claim.','inferred omitted source bridge')
edge('c2.row-joint-independence','FORMAL.producer','A3.SS2.p1.2','The exact producer represents this source assertion on the fixed canonical experiment.','source-to-sealed-target correspondence, not a proof edge')
edge('c2.physical-gamma','c2.B-definition-context','A3.SS2.p1.2','B uses the actual physical rows.')
edge('c2.literal-t','c2.B-definition-context','A3.SS2.p1.2','B has gamma-first, t-second tensor order.')
edge('c2.physical-gamma','cutoff.literal-R','A3.SS2.p10.m2','R_i is this row squared Euclidean norm.')
edge('c2.r','cutoff.literal-L','A3.SS2.p10.m1','L uses r=q+1.')
for atom,meaning in [('c2.physical-gamma','Physical row outer product.'),('c2.literal-t','Literal deterministic feature outer product.'),('cutoff.literal-R','Row-local squared radius.'),('cutoff.literal-L','Fixed closed threshold.')]:
    edge(atom,'Yi.actual-literal-definition','A3.Ex107',meaning)
edge('c2.physical-gamma','PORT.row-measurability',['A3.SS2.p12.1','A3.Ex107'],'Actual row maps must be measurable; this is not supplied as a public hypothesis.','inferred omitted source bridge')
edge('cutoff.literal-R','PORT.local-cutoff-measurable',['A3.SS2.p12.1','A3.Ex107'],'Measurability of the actual closed squared-norm event.','inferred omitted source bridge')
edge('Yi.actual-literal-definition','PORT.actual-Y-image-identity','A3.Ex107','Entrywise equality to the separate row map F_i.','literal internal adapter')
edge('Yi.actual-literal-definition','PORT.matrix-row-map-measurable',['A3.SS2.p12.1','A3.Ex107'],'F_i must be measurable into the actual finite real-entry matrix carrier.','inferred omitted source bridge')
edge('PORT.local-cutoff-measurable','PORT.matrix-row-map-measurable',['A3.SS2.p12.1','A3.Ex107'],'Piecewise cutoff component of F_i.','inferred omitted source bridge')
for a in ['PORT.row-measurability','PORT.matrix-row-map-measurable','PORT.actual-Y-image-identity']:
    edge(a,'PORT.Y-measurable-composition',['A3.SS2.p12.1','A3.Ex107'],'Discharge all actual Y map measurability internally.','inferred omitted source bridge')
edge('PORT.Y-measurable-composition','Yi.all-measurable-output',['A3.SS2.p12.1','A3.Ex107'],'Source-implicit random-matrix well-definedness as target output.','source-implicit measurability output')
edge('FORMAL.producer','PORT.independent-measurable-images',['A3.SS2.p12.1','A3.Ex107'],'The new full row independence result is the intended material input to actual Yi independence under identical mu; its future code call is not yet observed.','required intended producer-consumer use, unproved')
for a in ['PORT.matrix-row-map-measurable','PORT.actual-Y-image-identity']:
    edge(a,'PORT.independent-measurable-images',['A3.SS2.p12.1','A3.Ex107'],'Separate i-dependent measurable row maps, identified with actual Yi.','inferred omitted source bridge')
edge('PORT.independent-measurable-images','Yi.joint-independence-source-claim',['A3.SS2.p12.1','A3.Ex107'],'Full independence of actual Ex107 matrices; no identical-distribution claim.','inferred omitted source bridge')
for a in ['Yi.all-measurable-output','Yi.joint-independence-source-claim']:
    edge(a,'FORMAL.consumer',['A3.SS2.p12.1','A3.Ex107'],'One of the two explicit target conclusions.','source-to-sealed-target correspondence, not a proof edge')
graph={'version':1,'state':'POST_SEAL_VERSIONED_SOURCE_GRAPH_EXTRACTED_UNPROVED','bindings':bindings,
 'chronology':'New artifact created after receipt of the fixed new seal. Raw-freeze-v1 and its unaccepted preliminary graph remain byte-identical and immutable.',
 'nodes':nodes,'edges':edges,
 'hyperedges':[{'id':'ROUTE.canonical-row-regrouping','semantics':'AND: separate within-column coordinate joint product and across-column product, then finite regrouping and full sigma-field interpretation.','required_ports':['PORT.stdGaussian-coordinate-factorization','PORT.column-product-applicability','PORT.finite-coordinate-regrouping','PORT.full-row-iIndepFun'],'conclusion':'FORMAL.producer','status':'UNPROVED_SOURCE_SUPPORTED_ROUTE'},
  {'id':'ROUTE.actual-Yi','semantics':'AND: literal actual-Y identity, measurable row maps and full producer row independence; measurability and independence are outputs under the same mu.','required_ports':['PORT.row-measurability','PORT.local-cutoff-measurable','PORT.matrix-row-map-measurable','PORT.actual-Y-image-identity','PORT.Y-measurable-composition','PORT.independent-measurable-images'],'conclusion':'FORMAL.consumer','status':'UNPROVED_SOURCE_SUPPORTED_ROUTE'}],
 'no_false_edges':['No row marginal-law -> full row independence edge.','No B definition, cosine orthogonality, moment, tail probability, bias or common truncation event -> Yi independence edge.','No row-iid -> Yi-iid claim.','No old node name -> compiled parent edge.'],
 'graph_semantics':'Source obligations, literal definition uses and explicitly inferred omitted bridges only. Never compiler-backed implication or proof acceptance.',
 'source_topology_independent_coverage_acceptance':'PENDING_DISTINCT_REVIEWER; no self-approval',
 'implementation_dependencies_verified':False,'compiled_parents':[],'permission_grant':False}
dump('source-graph-v1.json',graph)

write('meaning-comparison.md',r'''# Post-seal source/type audit, version 1

No genuine mismatch was found between the two supplied sealed target meanings and the frozen source reading. This is a source/type audit independent of the formalizer. It is not a proof, decoder verdict, topology self-approval, publication status, or permission grant.

The producer asks for full `iIndepFun` of the actual physical rows under one fixed product of r standard d-Gaussian column laws. Expanding the supplied predicate passes through each row's inverse-image sigma-field and factors every finite intersection under a constant kernel on Unit. Thus the target has the strength of the unnamed C.2 p1 joint-independence claim. It has no pairwise-only or marginal-only shortcut, and no public row-law/independence certificate.

The consumer defines exactly the source Ex107 matrices and asks for two outputs: every actual Y map is measurable and the whole Y family is independent under that same fixed product measure. Measurability is source-implicit well-definedness made explicit as a conclusion. `iIndepFun` alone does not assert map measurability; the conjunction makes the relevant random-matrix meaning auditable. Neither field is a hypothesis.

Natural d,q and `2*q+1<d` are the only logical inputs. All other objects are literal lets. The Fin indices shift the source physical row index by +1 in theta; the feature index already runs 0,...,q. The leading feature is exactly 1, positive features have sqrt(2), the tensor indices are Gaussian-first, the scalar is exactly inverse d, and the radius cutoff includes equality. The zero branch is the source indicator. For q=0, t has one constant coordinate and the matrix is scalar; no new positivity condition appears. No tau,kappa,C, common event, moments or variance assumptions enter.

The actual `stdGaussian` print uses an orthonormal-basis map from scalar Gaussians. This supports the intended standard Gaussian law, but it does not by itself discharge the physical evaluation-coordinate factorization needed in the row argument. The versioned ports therefore retain that basis/coordinate applicability question, the fixed finite-column product argument, regrouping, the full independence-predicate bridge, and all map-measurability/image bridges as open internal obligations. No compiled parent has been invented. A possible existing canonical row-law node is mentioned by the supplied packet, but no signature or proof for it was exposed, so it is only a possible future reuse.

The versioned source graph preserves direct use at C.2 p1 and at p12/Ex107. Its formal producer-to-consumer link is a required intended use, because no new proof implementation was exposed. The graph does not pretend to have observed a compiler-backed call. All 83 raw source atom dispositions remain unchanged, with exact byte/character/LF-line/hash locators. The later PSD, centered variance, concentration proof, original ambient transfer and lower-bound routes remain excluded.

Raw-freeze-v1 remains immutable preparation. This new graph was authored after the new Statement Seal was supplied. Because this actor extracted the raw source inventory, independent topology coverage acceptance remains for a distinct reviewer. No source-blind decoder claim is made. The formalizer is explicitly recorded as API-nonpristine, and no old API/lesson/audit or implementation file was read by this actor.
''')

dump('input-exposure-record.json',{'version':1,'bindings':bindings,
 'new_inputs':[{'path':str(PACKET.relative_to(ROOT)),'bytes':len(pb),'sha256':sha(pb),'role':'Exact sealed statements plus standard definition semantics only; no new implementation.'}],
 'reused_own_inputs':{'raw_manifest':str((RAW/'frozen-manifest.json').relative_to(ROOT)),'sha256':sha(rawmb),'scope':'Own immutable raw source/protocol/exposure artifacts and pinned source snapshot only.'},
 'new_implementation_seen':False,'old_audit_lesson_verdict_or_ledger_read':False,
 'formalizer_API_pristine':False,'why':'Explicit from first seal, supplied packet and parent instruction. This audit does not fabricate API blindness.',
 'preseal_failures':'Parent states initial alias/letI formation failures are preserved. No failure artifact was opened and no new conclusion is drawn from them.',
 'digest_verification':{'packet':'RECOMPUTED_EXACT_BYTES','producer_signature':'RECOMPUTED_EXACT_UTF8','consumer_signature':'RECOMPUTED_EXACT_UTF8','literal_prints':'RECOMPUTED_EXACT_UTF8','literal_excerpts':'RECOMPUTED_EXACT_UTF8','source_anchors':'RECOMPUTED_AGAINST_OWN_FROZEN_SOURCE','raw_freeze':'ALL_MANIFEST_FILE_HASHES_RECHECKED','statement_seal_and_definition_context_identifiers':'Supplied identifiers are bound by the exact verified packet bytes. Underlying separate seal/context serialization not supplied; no independent recomputation of those opaque identifiers is claimed.'},
 'chronology':'Raw interpretation and preliminary source graph froze before this new type exposure. New exact seal was supplied before creation of this post-seal source/type audit and versioned graph.',
 'prior_filename_exposure':'The honest raw-phase filename-only exposure and truncation disclosure remain in raw-freeze-v1/exposure-record.json, unchanged.',
 'writes':'Exclusively new type-phase-v1 and its builder under the assigned own root; no tracked/C/ledger/registry/status write.',
 'no_grant':'No mathematical proof, theorem admission, status transition, publication acceptance or permission is granted.'})
write('README.md','Post-seal independent source/type audit. Read meaning-comparison.md and type-audit.json, then source-graph-v1.json and coverage-v1.json. Open internal/library applicability ports are in internal-bridge-and-applicability-ports.json. No proof or compiled dependency was inspected. A distinct topology coverage reviewer remains required; the raw extractor has not approved its own coverage. Raw-freeze-v1 remains unchanged.\n')

manifest={'format':'astis-post-seal-source-type-freeze-v1','actor':'/root/row_indep_source_graph_78c2','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'bindings':bindings,'status':'SOURCE_TYPE_MATCH_NO_PROOF_OR_PERMISSION_GRANT','independent_topology_coverage_review':'PENDING_DISTINCT_REVIEWER','files':[]}
for f in sorted(OUT.rglob('*')):
    if f.is_file():
        b=f.read_bytes();manifest['files'].append({'path':str(f.relative_to(OUT)),'bytes':len(b),'sha256':sha(b)})
dump('freeze-manifest.json',manifest)
digest=sha((OUT/'freeze-manifest.json').read_bytes())
write('freeze-manifest.sha256',digest+'  freeze-manifest.json\n')
for f in OUT.rglob('*'):
    if f.is_file():f.chmod(0o444)
for d in sorted([d for d in OUT.rglob('*') if d.is_dir()],key=lambda d:len(d.parts),reverse=True):d.chmod(0o555)
OUT.chmod(0o555)
print(json.dumps({'path':str(OUT),'type_audit_sha256':sha((OUT/'type-audit.json').read_bytes()),'source_graph_sha256':sha((OUT/'source-graph-v1.json').read_bytes()),'coverage_sha256':sha((OUT/'coverage-v1.json').read_bytes()),'freeze_manifest_sha256':digest,'source_atoms':len(items),'open_internal_ports':len(ports),'graph_nodes':len(nodes),'graph_edges':len(edges),'genuine_target_issue':None,'raw_manifest_unchanged':sha((RAW/'frozen-manifest.json').read_bytes())},indent=2))
