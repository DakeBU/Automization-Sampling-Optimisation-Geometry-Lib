"""Carry only this compiled delta and bounded originals, preserving all foreign state."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys
import tarfile

sys.dont_write_bytecode = True
sys.path.insert(0, 'tools')
import astis_advance as advance
import astis_frontier_cells as frontiers

workspace = Path(__file__).resolve().parent.relative_to(Path.cwd())
paper = Path('research-wiki/paper-contributions/GaussianComplexity')
evidence = paper / 'weighted-cosine-frame-semantic-evidence'
cell_path = Path('research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-weighted-cosine-frame.json')
ledger = Path('runs/substantive_advances.jsonl')
sha = lambda raw: hashlib.sha256(raw).hexdigest()
dump = lambda obj: (json.dumps(obj, ensure_ascii=False, indent=2) + '\n').encode()
git = lambda *args: subprocess.check_output(['git', *args])


def create(path, raw):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as out:
        out.write(raw)


baseline = json.loads((workspace / 'preproof-baseline.private.json').read_bytes())
head = git('rev-parse', 'HEAD').decode().strip()
assert head == baseline['head'] == 'f2a603b9112e0472ab3220e3310021cf51ce4218'
assert not git('diff', '--cached', '--name-only')
assert git('diff', 'HEAD', '--name-only').decode().splitlines() == [str(ledger)]
assert ledger.read_bytes() == git('show', f'{head}:{ledger}') + (evidence / 'normal-EXPLORING-append.exact.jsonl').read_bytes()
states = advance._replay_advances([json.loads(x) for x in ledger.read_bytes().splitlines()])
assert states.pop('ASTIS-SA-20261112-GaussianComplexityWeightedCosineFrame')['state'] == 'EXPLORING'
assert states == baseline['all_foreign_states']
discoveries = Path('runs/substantive_discoveries.jsonl').read_bytes()
discovery_guard = json.loads((workspace / 'preproof-discoveries.private.json').read_bytes())
assert sha(discoveries) == discovery_guard['ledger_sha256']
assert advance._replay_discoveries([json.loads(x) for x in discoveries.splitlines()]) == discovery_guard['full_states']
for path, digest in baseline['all_existing_frontier_hashes'].items():
    assert sha(Path(path).read_bytes()) == digest, path
controls = json.loads((workspace / 'intake-controls.private.json').read_bytes())
for path, digest in controls.items():
    assert sha(Path(path).read_bytes()) == digest, path

concept_root = Path('.astis/semantic-neutral-20261111/wf_tc_8ea0/conceptual-mirror')
concept_manifest = concept_root / 'MANIFEST.json'
assert sha(concept_manifest.read_bytes()) == '11dbc30d974ec99c5835ca1fbf87e834f31eb563a36f0ac9dbcb21b902bf5e18'
concept_files = [concept_manifest]
for item in json.loads(concept_manifest.read_bytes())['files']:
    path = concept_root / item['path']
    raw = path.read_bytes()
    assert sha(raw) == item['sha256'] and len(raw) == item['bytes']
    concept_files.append(path)
judgment = json.loads((concept_root / 'audit.json').read_bytes())
assert judgment['conceptual_mirror_audit'] == {'status': 'none-found', 'discovery_ids': []}
assert judgment['new_candidates'] == [] and judgment['no_discovery_state_changes']
for path in concept_files:
    create(evidence / 'conceptual-mirror-originals' / path.name, path.read_bytes())
cell = json.loads(cell_path.read_bytes())
cell['conceptual_mirror_audit'] = {
    **judgment['conceptual_mirror_audit'],
    'scope': judgment['scope'],
    'evidence': str(evidence / 'conceptual-mirror-originals/audit.json'),
    'independent_reviewer': '/root/weighted_frame_topology_8ea0',
    'existing_validated_mirrors': [
        {**item, 'identity_unchanged': True} for item in judgment['existing_records_considered']
    ],
}
cell['graph_contribution']['functor_view'] = 'none-found'
cell['graph_contribution']['visual_review'] = 'Compiled canonical parent extraction and exact source map are available. Shared graph integration and actual graph visual acceptance remain pending original owner release.'
cell['evidence']['independent_verification'] = ''
cell_path.write_bytes(dump(cell))
assert not frontiers.validate_cells(frontiers.load_cells())

seal_path = paper / 'weighted-cosine-frame-statement-seal.json'
assert sha(seal_path.read_bytes()) == 'fca4e21eaa1e3107b6cfcf99c2a08c6dc7884c5a62f1dd4f626fbf3042cc4998'
seal = json.loads(seal_path.read_bytes())
P, T = [Path(seal[k]['planned_file']) for k in ('producer', 'actual_private_consumer')]
draft = json.loads((evidence / 'publication-draft-record.json').read_bytes())
assert sha(P.read_bytes()) == draft['producer_sha256'] == 'fbdd52b69919b02d1009b642fbf4975618689b10f417d1311fb766d23e87f5ce'
assert sha(T.read_bytes()) == draft['private_consumer_sha256'] == '50283ee15678aa6f3ebadd89ce10b69a5bf2404e0e2ad8fb9d242181e74739a4'
create(evidence / 'actual-local-mathematical-result.json', dump({
    'actual_compilation': draft['build'], 'actual_kernel': draft['kernel'],
    'literal_types_kernel_applied': True, 'raw_Expr_structural_equality': False,
    'owned_theorems': 5, 'handwritten_roots': 2, 'generated_reachable_internal': 3,
    'allowed_axioms_only': ['propext', 'Classical.choice', 'Quot.sound'],
    'canonical_actual_parent_edges': draft['actual_public_ASTIS_parents'],
    'formalizer_API_pristine': False, 'new_target_preseal_proof_attempts': 0,
    'normal_intake_receipt': '.astis/huanjian-resume-20261103/20261112T041441660117Z-weighted-cosine-frame-normal-intake.receipt.json',
    'actual_intake_readback_tool_chunk': 'ebf07c',
    'status': 'Compiled bounded mathematics. Independent final source/native acceptance and normal PROVED_LOCAL submission pending.',
}))
create(evidence / 'local-attempt-diagnoses.json', dump({
    'sealed_statements_changed': False,
    'failure_class': 'IMPLEMENTATION_FAILED',
    'reservation': 'Library-name descriptions did not contain the required literal Samplinglib/Mathlib names. Original rejected cell/script and receipt retained. Recovery changes descriptions only; no ledger call.',
    'preproof_readback': 'The first manifest reader duplicated the type-only directory prefix. Corrected its manifest base; all77 exact originals rehashed before intake.',
    'producer_attempts': 'Attempt1 exposed let-hidden Gram evaluation and opaque Kronecker rewriting. Attempt2 fixed explicit Gram type and Kronecker unfolding. Attempts2/3 repeated the same sum-evaluation simplification failure. Route frozen and a successful separate generic Matrix.sum_apply diagnostic isolated the API. Explicit theorem application then compiled the unchanged producer.',
    'consumer_attempts': 'The first build exposed implicit arguments of Finset.smul_sum. Exact inferred theorem application fixed the aggregate mean without changing the source statement. Both declarations then built.',
    'cleanup': 'Removed an unreachable ring and unnecessary tactic-sequence focus before final build and exact code review copies.',
    'salvage': 'All mathematical fragments retained inside the compiled producer or aggregate consumer. No route refuted, no discarded source theorem, no additional premise.',
}))

review = json.loads((workspace / 'reviewed-preproof-inputs.json').read_bytes())
originals = [Path(item['path']) for item in review['independent_originals']] + concept_files
originals += [p for p in workspace.iterdir()
              if p.is_file() and not p.is_symlink() and '.private.' not in p.name]
for receipt_path in sorted(Path('.astis/huanjian-resume-20261103').glob('*-weighted-cosine-frame-*.receipt.json')):
    obj = json.loads(receipt_path.read_bytes())
    log = Path(obj['log']).resolve().relative_to(Path.cwd().resolve())
    assert sha(log.read_bytes()) == obj['log_sha256']
    originals += [receipt_path, log]
originals = sorted(set(originals))
for p in originals:
    assert p.is_file() and not p.is_symlink() and p.stat().st_size < 5_000_000
    assert '.private.' not in p.name
archive_path = evidence / 'preproof-source-types-topology-local-build.original-files.tar.gz'
with tarfile.open(archive_path, 'x:gz') as archive:
    for path in originals:
        archive.add(path, arcname=str(path), recursive=False)
with tarfile.open(archive_path, 'r:gz') as archive:
    for path in originals:
        assert archive.extractfile(str(path)).read() == path.read_bytes()
create(evidence / 'preproof-source-types-topology-local-build.original-manifest.json', dump({
    'files': {str(path): {'bytes': path.stat().st_size, 'sha256': sha(path.read_bytes())} for path in originals},
    'scope': 'Bounded own source/type/topology/conceptual and actual build originals. Complete foreign preservation/control replays remain private and local.',
}))
slug = 'huanjian-gaussian-weighted-cosine-frame.json'
files = [P, T, cell_path, seal_path, ledger,
         Path('website/content/declaration_lessons') / slug,
         Path('website/content/publications') / slug,
         Path('research-wiki/semantic-roundtrip/audits') / slug,
         *sorted(p for p in evidence.rglob('*') if p.is_file())]
assert len(files) == len(set(files))
subprocess.run(['git', 'add', '-f', '--', *map(str, files)], check=True)
assert set(git('diff', '--cached', '--name-only').decode().splitlines()) == set(map(str, files))
# The independent raw originals retain exact bytes. Check only authored text formatting.
authored = [P, T, cell_path, seal_path, *files[5:8]]
subprocess.run(['git', 'diff', '--cached', '--check', '--', *map(str, authored)], check=True)
subprocess.run(['git', 'commit', '-m', 'Prove the weighted cosine coefficient and Gaussian marginal second-moment sum'], check=True)
commit = git('rev-parse', 'HEAD').decode().strip()
for path in files:
    assert git('show', f'{commit}:{path}') == path.read_bytes()
assert not git('diff', 'HEAD', '--name-only')
record = {
    'mathematical_candidate': commit, 'parent': head,
    'producer_sha256': draft['producer_sha256'], 'private_consumer_sha256': draft['private_consumer_sha256'],
    'publication_binding_sha256': draft['publication_binding_sha256'],
    'source_lean_map_sha256': sha((evidence / 'source-lean-map.draft.json').read_bytes()),
    'archive_sha256': sha(archive_path.read_bytes()), 'original_archive_files': len(originals),
    'exact_carried_files': len(files), 'foreign_full_advance_states_preserved': len(states),
    'all_discovery_states_preserved': len(discovery_guard['full_states']),
    'older_frontier_regular_files_preserved': len(baseline['all_existing_frontier_hashes']),
    'foreign_controls_preserved': len(controls), 'formalizer_API_pristine': False,
    'state': 'EXPLORING. Exact bounded mathematics compiled, independent final source/native review pending.',
}
create(workspace / 'actual-immutable-math-candidate.json', dump(record))
print(json.dumps(record))
