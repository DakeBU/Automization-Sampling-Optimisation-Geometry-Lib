"""Apply only v3 proposal binding constants, then run an unchanged frozen v2 helper.
Preparation artifact: execution still requires the helper's existing root-bound context.
Use --entry with the full repository-relative frozen entrypoint path so actual receipts
retain the checker identity. No browser flow, acceptance gate or lifecycle API changes.
"""
from pathlib import Path
import hashlib,runpy,sys
sys.dont_write_bytecode=True
R=Path('/Users/zhouhuanjian/ASTIS-GC')
S=R/'.astis/huanjian-gc-fixed-spectrum-normalizer-integration-20261108/independent-reader'
PINS={'.astis/huanjian-gc-fixed-spectrum-normalizer-integration-20261108/independent-reader/normalizer_acceptance_common_v2.py': '7fa8348491edf4e3ecb745ba2111a9ed44e74ac4b0709619af330a05ac4fcfa6', '.astis/huanjian-gc-fixed-spectrum-normalizer-integration-20261108/independent-reader/check_postcore_v2.py': '2108ab76a5b2b8609430f7b0c51146a82cba76ff438f4077e1d9cce78af37047', '.astis/huanjian-gc-fixed-spectrum-normalizer-integration-20261108/independent-reader/record_local_acceptance_v2.py': '8206dbe0ddadb7104430222f5907b7d43bf81cd9d785aa0aa45e80fabfe08eb7', '.astis/huanjian-gc-fixed-spectrum-normalizer-integration-20261108/independent-reader/check_normalpark_eligibility_v2.py': 'f36c26e985fd48d4130d4fa66211ff9eef0b2d9eb9b5e7ed82ee3bf340340b96', '.astis/huanjian-gc-fixed-spectrum-normalizer-integration-20261108/independent-reader/check_final_reader_v2.py': 'acd0b2be49b2c3059f9ae4659058a18c157f3dda673f4ebfb6e0d7a51e7a408f'}
ENTRIES=['.astis/huanjian-gc-fixed-spectrum-normalizer-integration-20261108/independent-reader/check_postcore_v2.py', '.astis/huanjian-gc-fixed-spectrum-normalizer-integration-20261108/independent-reader/record_local_acceptance_v2.py', '.astis/huanjian-gc-fixed-spectrum-normalizer-integration-20261108/independent-reader/check_normalpark_eligibility_v2.py', '.astis/huanjian-gc-fixed-spectrum-normalizer-integration-20261108/independent-reader/check_final_reader_v2.py']
sha=lambda b:hashlib.sha256(b).hexdigest()
assert len(sys.argv)>2 and sys.argv[1]=='--entry'
entry=sys.argv[2];assert entry in ENTRIES
for p,h in PINS.items():assert sha((R/p).read_bytes())==h,p
import normalizer_acceptance_common_v2 as common
assert str(common.P.relative_to(common.O))=='proposal-v2'
assert common.REPORT_SHA=='64b266f7c9f9bbd3cfe6421346022c78f2f841ab5122d8b1e6dee64288cc3920'
assert common.FREEZE_SHA=='cb1f1630c6877efb3c48cccd5bb0f2e8c1439ef4e7db8dc30c9abab745738927'
common.P=common.O/'proposal-v3'
common.REPORT_SHA='6b86afe6caeaf8e1cc83fc782b1221c7b316edfa20f2439cd204d840da4bc87a'
common.FREEZE_SHA='3b31e3d6e2dc762d0f8628766f1485e4d15bc7f87f5db73922e30a28a75960a8'
sys.argv=[str(R/entry),*sys.argv[3:]]
runpy.run_path(str(R/entry),run_name='__main__')
