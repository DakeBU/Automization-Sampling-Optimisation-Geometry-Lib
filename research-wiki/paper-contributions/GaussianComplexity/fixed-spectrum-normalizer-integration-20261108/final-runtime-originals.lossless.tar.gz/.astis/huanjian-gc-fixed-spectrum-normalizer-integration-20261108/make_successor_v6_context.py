from pathlib import Path
import datetime, hashlib, json, subprocess, sys
sys.path.insert(0, 'tools')
import astis_site
sha = lambda raw: hashlib.sha256(raw).hexdigest()
B = Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-normalizer-integration-20261108')
base = B / 'postcore-protection-context.json'
assert sha(base.read_bytes()) == 'e465a1dfbb81380c9481bfb1b88b5f8d45d0e91e9b3446be4a1aea526f844316'
a = json.loads(base.read_bytes())
head = subprocess.check_output(['git', 'rev-parse', 'HEAD']).decode().strip()
assert head == 'a5ec44836422e56ca5cfab14f951ed84bbfc9324'
def ref(path):
    p = Path(path)
    return {'path': str(p), 'sha256': sha(p.read_bytes())}
gate, meta = Path('.astis/site-lean-gate.json'), Path('_site/data/build-metadata.json')
g, m = json.loads(gate.read_bytes()), json.loads(meta.read_bytes())
assert g['passed'] and m['gate']['passed'] and m['gate']['current']
assert g['commit'] == m['git']['commit'] == head
assert g['source_digest'] == m['source_digest'] == astis_site.source_digest() == '92a908be0defdf1b5994f5ff4fe8a0e545cdca0f6c229cd1141c36338129bd21'
css = Path('website/static/information-architecture.css').read_bytes()
assert sha(css) == 'a41ffd9d41e8c281aa716fcff25e42e5cb8d14208badff456a0dff7dfbb1b766'
assert Path('_site/assets/information-architecture.css').read_bytes() == css
checks = {}
for role, label in {'canonical_lean': 'canonical-lean', 'publication': 'publication', 'contributor': 'contributor', 'semantic': 'semantic', 'frontier': 'frontier', 'site_build': 'site-build', 'site_check': 'site-check', 'graph_check': 'graph-check'}.items():
    rows = list(Path('.astis/huanjian-resume-20261103').glob('*-fixed-spectrum-normalizer-layout-v6-' + label + '.receipt.json'))
    assert len(rows) == 1, (role, len(rows))
    raw = rows[0].read_bytes()
    r = json.loads(raw)
    assert r['exit_code'] == 0 and r['head_before'] == r['head_after'] == head
    assert sha(Path(r['log']).read_bytes()) == r['log_sha256']
    checks[role] = ref(rows[0])
checker = Path('.astis/huanjian-gc-fixed-spectrum-normalizer-integration-20261108/independent-reader/check_final_reader_v6.py')
assert sha(checker.read_bytes()) == '760458d8b3aacc48706a2ff496cf629dada37399c7de895263a9d3ab68ded6b5'
a.update({'recorded_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'accepted_immutable_core': head, 'source_digest': astis_site.source_digest(), 'browser_checker_sha256': sha(checker.read_bytes()), 'actual_gate': ref(gate), 'site_metadata': ref(meta), 'actual_checks_before_browser': checks, 'layout_exception_proposal': {'path': str(B / 'independent-reader/mobile-debt-layout-proposal-v6/proposal-report.json'), 'sha256': '9e5ace010535e879abafb81ac71e0281c756d84311845d0ad15d2bd0a318eeec'}, 'successor_helper_freeze': {'path': str(B / 'independent-reader/successor-helper-preparation-v6/helpers-freeze.json'), 'sha256': '15a4bc5797a3f5203fa960b90e79a6376fb58ebacbca8e77d380f79cbd7223a7'}, 'site_layout_css_sha256': sha(css), 'scope': 'Root has reviewed the exact v6 helper diffs and verified six original helper archives/old helper hashes. All eight actual gates on this immutable successor have completed. This authorizes the frozen actual v6 local Chrome check, not image acceptance, lifecycle parking or new source verdict. Ordinary prose and text-range clipping checks supplement preserved old assertions. Exactly one old long-Lean card has two-width DOM/native-UI geometry regression only, with no separate regression screenshots; the earlier checkpoint expectation of two additional originals is superseded and no such originals are claimed. All main46 fresh originals still require independent actual image review. c8 evidence/HOLD remain unchanged and do not transfer success.'})
p = B / 'actual-gates-successor-layout-v6-context.json'
assert not p.exists()
p.write_text(json.dumps(a, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'path': str(p), 'sha256': sha(p.read_bytes()), 'core': head, 'actual_checks': len(checks), 'CSS_sha256': sha(css), 'source_digest': a['source_digest']}))
