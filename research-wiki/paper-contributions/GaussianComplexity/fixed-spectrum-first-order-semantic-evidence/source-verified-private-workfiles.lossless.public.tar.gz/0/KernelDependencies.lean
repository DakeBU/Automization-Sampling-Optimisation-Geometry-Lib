import Tests.GaussianComplexityFixedSpectrumFirstOrder
open Lean in
run_cmd do
  let env ← getEnv
  let producer := `AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumFirstOrder.actual_first_order_query
  let consumers := env.constants.toList.filter fun (name, _) =>
    name.toString.startsWith "_private.Tests.GaussianComplexityFixedSpectrumFirstOrder" &&
    name.toString.endsWith ".actual_reference_precision_first_order_consumer"
  unless consumers.length == 1 do throwError "Expected one named actual private consumer"
  let consumer := consumers.head!.1
  let admiss := `AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumAdmissibility.actual_precision_admissible
  let affine := `AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumAffine.actual_affine_precision_query
  for (name, expected) in [(producer, [admiss]), (consumer, [producer, affine])] do
    let some info := env.find? name | throwError "Missing compiled target"
    let some proof := info.value? (allowOpaque := true) | throwError "Missing actual proof term"
    let used := proof.getUsedConstants.toList.filter fun n => n.toString.startsWith "AutoSamplingTheory."
    unless used.length == expected.length && expected.all used.contains do
      throwError m!"Actual direct ASTIS proof parents mismatch: {name}: {used}"
    logInfo m!"ACTUAL_TARGET {name}"
    for dep in used do logInfo m!"ACTUAL_ASTIS_PARENT {dep}"
  logInfo "Exact actual ASTIS producer1/private-consumer2 parents checked from proof terms; no import/count credit."
