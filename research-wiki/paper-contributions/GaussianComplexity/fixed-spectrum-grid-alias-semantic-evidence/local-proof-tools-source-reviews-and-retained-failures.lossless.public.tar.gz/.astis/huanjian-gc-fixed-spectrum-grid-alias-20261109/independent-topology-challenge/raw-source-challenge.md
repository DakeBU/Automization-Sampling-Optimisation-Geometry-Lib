# Independent raw-source challenge: midpoint-grid alias and weighted spectrum

This record is frozen before opening either candidate seal/formation evidence or the sibling extractor's graph. It is source cognition and a challenge baseline, not a target proof, source V, final admission, or Lean dependency graph.

Only the pinned 951991-byte `2610.20492v1.html`, SHA-256 `6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915`, was read for this new task. The fresh read covered `S4.SS1.p1.1`, `S4.E11`, `S4.Thmtheorem5`, C7's full statement/proof, C8's statement and full proof paragraphs p3–p6. The five governing repository protocols were already read in the preceding authorized role. No new implementation, API, seal, graph, ledger or external source was opened.

This is not zero-cue: the assignment names the all-Int/negative-quotient/zpow/Fin-shift issues and private consumer name; earlier authorized C7/C8 and Poisson conceptual reviews are present in this actor's context. The original-source locator from the earlier role was reused solely to read this pinned HTML. No earlier candidate for this new alias target has been seen.

## Source meaning and domains

The hard family has integer d≥2, real κ≥2, source i=1,…,d, θᵢ=(i−1/2)π/d and λᵢ=(κ+1)/2+((κ−1)/2)cosθᵢ. A Fin d carrier must use θ(i)=(i.val+1/2)π/d. The random eigenbasis and Gaussian law are not premises of the deterministic grid identity.

`A3.SS3.p3`/`A3.Ex139` asserts the finite cosine identity for **every integer k**, including k=0 and negative k. The sum is d(−1)^a when k=2ad with a∈ℤ, and 0 otherwise. This pure grid fact uses d and the literal θ grid, but not κ, ρ, n, Gaussian law, integrability or C7.

For an alias coefficient written by an exact quotient, the multiple-case exponent is the integer k/(2d), guarded by integer divisibility (2d)|k. d≥2 makes the divisor nonzero. Negative quotients must remain integer exponents. A real-base integer power of −1 has values ±1; replacing a negative quotient by a natural number through truncation loses source meaning. Quotient rounding off the divisible branch is irrelevant only if that branch is truly guarded.

Stress instances: k=0 gives d; k=2d and k=−2d give −d; k=4d gives d. It is false that all nonzero frequencies vanish. The full result is even in k, consistent with cosine and the parity of an exact negative quotient.

## Source route, background and AND/OR

The source gives one proof by a partition into two integer-frequency cases. In the nonmultiple case the finite cosine sum is sin(kπ)/(2sin(kπ/(2d)))=0. The omitted bridges are the midpoint finite-sum identity, integer sine zero, and the equivalence between the denominator's zero set and integer divisibility. The formula cannot simply be used with a zero denominator. In the multiple case every term is cos(2aiπ−aπ)=(−1)^a, requiring the literal grid, casts, periodicity/parity and d finite summands. Both cases are needed for the all-k result. They are not two alternative sufficient proofs of the complete theorem.

Source hypotheses: d≥2 and k∈ℤ, with θ defined literally. Derived facts: d>0, valid denominator/nondivisibility facts, finite-sum evaluation, parity and any bounds on alias coefficients. None may be smuggled into a public alias theorem as a convenient assumption. No κ or Gaussian premise should enter through a bundled standing/context node.

## Actual weighted-consumer baseline

`A3.Ex140` separately identifies the Gaussian means with actual reciprocal-eigenvalue finite sums. The present deterministic consumer should work directly with Σᵢcos(nθᵢ)/λᵢ; it must not claim that this alone proves the Gaussian expectation identification.

For source integer 1≤n<d, `A3.SS3.p6.1` uses Σᵢcos(nθᵢ)=0, product-to-sum and the C7 inverse-spectrum series. The zero constant term is a produced use of the new grid alias fact: n is positive and strictly below d, so it is not a multiple of 2d. It is not a new binder. There is no odd-n restriction. An all-natural-n generalization of the simplified formula would require retaining its constant alias term; dropping it at n=0 is wrong.

C7 supplies ρ=(√κ−1)/(√κ+1), 0<ρ<1, the all-real-angle reciprocal formula and absolute summability. Its finite-grid specialization and finite weighted-series interchange remain internal ingredients. The full C7 uniform-convergence output is not an additional necessary mathematical premise of finite linear-combination exchange.

After product-to-sum, the source has 1/√κ times the positive-j series with grid sums at **integer frequencies j−n and j+n**. Applying the new alias identity replaces each grid sum by d times its alias coefficient. Thus an alias-coefficient-series intermediate has the external factor d/√κ, with no residual factor 2: the 2 in C7 cancels the product-to-sum half. The d factor must not be silently built into an alias definition and then counted twice.

In an ℕ-indexed series the source j is j+1. Cast that positive mode to ℤ **before subtracting n**. For example d=3, n=2, j+1=1 is permitted and has frequency −1, whose alias is 0. Natural subtraction would yield 0, whose alias is 1, creating a spurious term. Both signs and both shifted modes must be preserved.

The series summability is a produced conclusion/ingredient. With normalized alias values bounded by 1, the combined pair is bounded in magnitude by 2 and geometric decay is available from C7's literal ρ. Neither this bound, absolute summability nor a finite-sum/tsum exchange certificate is an extra source input. A consumer that assumes the new alias identity or its weighted equality is a wrapper; a substantive consumer must use the new all-k producer to evaluate the two shifted grid sums and the low-frequency constant, and materially use canonical C7's reciprocal expansion/convergence.

## Coverage and boundary for the future graph

- NODE: literal standing/grid `S4.SS1.p1.1`/`S4.E11`, with d-only projection for the pure alias producer and κ/ρ context only where spectral inversion needs it.
- NODE: full p3/Ex139, including the all-integer quantifier, both cases and the final every-grid-term computation. Omitted trig/denominator/cast/parity bridges remain visible background obligations.
- NODE: C7 statement/proof as an existing source-backed producer boundary, not a newly completed alias declaration or automatically inferred Lean edge.
- NODE: p4.2 finite weighted series exchange and p6.1/Ex144 product-to-sum/zero-mode step. The alias-series consumer requires these AND the new alias producer; neither alone is an OR route to it.
- BOUNDARY: p4.1/Ex140 Gaussian expectation identification. It is separate from the deterministic spectral series.
- EXCLUDED from an unevaluated alias-series delta: p5 closed M resummation; p6.2's three-class partition/disjointness/parity resummation and Ex145–147 closed μ formula. They were read to identify the boundary, not claimed complete. Their source range 1≤n<d must not be forgotten by later work.
- EXCLUDED: Lemma 4.5 variance, normalized bias and the extra condition d−n≥√κ; all Gaussian/TV/oracle/cost/main-bound implications.

The forthcoming source graph must preserve use sites and source-only topology. Compiler-backed actual calls must be assessed separately after a proof exists. This phase does not construct that proof, run APIs, or alter existing C7/Discovery state.
