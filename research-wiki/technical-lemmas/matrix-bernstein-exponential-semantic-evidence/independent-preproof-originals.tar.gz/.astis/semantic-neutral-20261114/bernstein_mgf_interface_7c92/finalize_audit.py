"""Package body-free interface findings; no production or shared-state writes."""
import hashlib
import json
import re
import subprocess
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
read_json = lambda p: json.loads((ROOT / p).read_text())
headers = json.loads((OUT / "canonical-headers.json").read_text())
by_path = {r["path"]: r for r in headers}
base = "research-wiki/paper-contributions/GaussianComplexity/"
seal_paths = {
    "W": ".astis/huanjian-gc-bernstein-mgf-preparation-20261114/statement-seal.unclaimed.v1.json",
    "mean": base + "source-matrix-mean-statement-seal.json",
    "R10": base + "source-matrix-radius-statement-seal.json",
    "R11": base + "source-matrix-structure-statement-seal.json",
}
seals = {k: read_json(v) for k, v in seal_paths.items()}
norm = lambda s: re.sub(r"\s+", " ", s).strip()
comparisons = []
for key in ("mean", "R10", "R11"):
    for role in ("producer", "actual_private_consumer"):
        item = seals[key][role]
        name = item["name"].rsplit(".", 1)[1]
        header = next(d for d in by_path[item["planned_file"]]["declarations"] if d["name"] == name)
        actual_sig = header["signature"].split("\n", 1)[1] + "\n"
        comparisons.append({
            "packet": key, "role": role, "name": item["name"],
            "path": item["planned_file"], "line": header["line"],
            "sealed_signature_sha256": item["signature_sha256"],
            "projected_signature_sha256": hashlib.sha256(actual_sig.encode()).hexdigest(),
            "exact_signature_byte_equal": actual_sig == item["signature"],
            "signature_equal_modulo_whitespace": norm(actual_sig) == norm(item["signature"]),
            "private": header["private"],
        })
instructions = [
    "AGENTS.md", "CONTRIBUTING.md", ".agents/prompts/collaborator-contribution.md",
    "docs/contributor-codex-contract.md", "docs/theorem-publication-protocol.md",
    "docs/proof-digestion-protocol.md", "docs/evidence-routed-memory-protocol.md",
    ".agents/skills/astis-substantive-advance/SKILL.md",
    ".agents/skills/astis-semantic-roundtrip/SKILL.md",
    ".agents/skills/astis-source-dependency-audit/SKILL.md",
]
maps = [base + "source-matrix-radius-semantic-evidence/source-lean-map.authored-v1.json",
        base + "source-matrix-structure-semantic-evidence/source-lean-map.authored-v1.json"]
report = {
    "kind": "BOUNDED_READ_ONLY_CANONICAL_INTERFACE_AND_PRIVATE_VISIBILITY_AUDIT",
    "status": "INTERFACE_FINDINGS_ONLY;NO_NEW_PROOF;NO_INTAKE;NO_ACCEPTANCE_OR_VERIFIED_CLAIM",
    "HEAD": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip(),
    "W_statement_seal": {"path": seal_paths["W"], "sha256": sha(ROOT / seal_paths["W"]),
                          "matches_parent_expected_sha256": sha(ROOT / seal_paths["W"]) == "c3103a9e8d08fea6c83f35201fce953af4dd93e88a1a3d7d647fc4deaaddeb7a"},
    "canonical_public_parents": [
        {"name": seals[k]["producer"]["name"], "module": seals[k]["producer"]["planned_file"].removesuffix(".lean").replace("/", "."),
         "exact_signature": seals[k]["producer"]["signature"],
         "interface_result": description}
        for k, description in [
            ("mean", "Actual Yi integrability and exact unconditional means; same original Gaussian product experiment."),
            ("R10", "Pointwise ||Yi|| <= 2rL/d and actual integral mean norm <= 2r/d; no public centered-radius output."),
            ("R11", "Actual Zi measurability, joint independence, integrability, true zero mean and pointwise real Hermitian under explicit standard Matrix Borel letI."),
        ]
    ] + [{"name": "AutoSamplingTheory.TechnicalLemmas.Probability.RealMatrixPositiveIntegral.integral_posSemidef",
          "module": "AutoSamplingTheory.TechnicalLemmas.Probability.RealMatrixPositiveIntegral",
          "exact_declaration_header": by_path["AutoSamplingTheory/TechnicalLemmas/Probability/RealMatrixPositiveIntegral.lean"]["declarations"][0]["signature"],
          "interface_result": "Integrable real finite matrix family under a probability measure, a.e. PSD => integral PSD; no Nonempty matrix-index premise."}],
    "signature_seal_comparisons": comparisons,
    "private_visibility": {
        "ordinary_source_name_check": "R10-T and R11-T source-qualified names are unknown identifiers after ordinary imports of their Tests modules.",
        "compiled_type_metadata": "Both exact private kernel names exist in the ordinary-import environment; names and constant TYPES were read, never proof values or dependencies.",
        "R10_exact_kernel_name": "_private.Tests.GaussianComplexityFixedSpectrumSourceMatrixRadius.0.AutoSamplingTheory.Tests.GaussianComplexityFixedSpectrumSourceMatrixRadius.actual_source_centered_summand_radius",
        "R11_exact_kernel_name": "_private.Tests.GaussianComplexityFixedSpectrumSourceMatrixStructure.0.AutoSamplingTheory.Tests.GaussianComplexityFixedSpectrumSourceMatrixStructure.actual_source_weighted_centered_matrix_structure",
        "private_semantics": "R10-T already has centered and cosine-weighted radius with Rstar=2r(L+1)/d. R11-T already has the five cosine-weighted structural properties. Public header absence is not unproved mathematics.",
        "preserved_failed_branch": "The initial unescaped numeric private kernel names produced parser errors, not evidence of kernel-name lookup failure. The original probe/comment and stdout are retained unchanged; the successful type-only lookup corrected that diagnostic.",
        "no_access_hack_or_wrapper": True,
        "no_private_formal_parent_claim": True,
    },
    "instance_and_source_context_differences": [
        "All canonical original-experiment interfaces and W-T retain d,q:Nat; hq:2*q+1<d; q=0; r=q+1; the same independent standard-Gaussian columns, physical rows, inclusive cutoff, cosine features, d^-1 Kronecker outer products and actual unconditional Bochner mean.",
        "All numeric matrix interfaces use open scoped Matrix.Norms.L2Operator (real Euclidean induced operator norm). Successful generic #synth returns Matrix.instAlgebra (Algebra Q), Matrix.instL2OpNormedRing, Matrix.instCompleteSpace.",
        "R11 P/T explicitly bind the standard Matrix Borel measurable space. W-T has no Matrix MeasurableSpace binder because its numerical matrix integrals do not themselves ask a matrix-valued Measurable/iIndepFun proposition. This is a typing context difference, not a changed Gaussian source law.",
        "W-T uses X_i = rho^-1 smul Zi, rho=2*r*(L+1)/d. R10-T's Rstar is this exact rho. R11-T's local X instead denotes cos((2q+1)*theta_i) smul Zi; the identical local letter does not make these families identical.",
        "W-P is a generic real finite Hermitian matrix inequality requiring (1-A).PosSemidef and s>0; it has no source probability-law binder. The public existing declarations are candidate reusable parent interfaces for W-T, not a compiled implication to W-P or W-T.",
    ],
    "bounded_reuse_search": {
        "artifact": "reuse-search.json",
        "name_search_scope": "Declaration starts matching the recorded regex in AutoSamplingTheory/**/*.lean and pinned Mathlib/**/*.lean (8977 files; 134 names). No proof-body search.",
        "signature_search_scope": "Four selected modules plus theorem headers in 175 files under Mathlib Analysis/CStarAlgebra, Analysis/Normed/Algebra, LinearAlgebra/Matrix and local TechnicalLemmas/Probability. Regex-based declaration projection is bounded, not a complete semantic inventory.",
        "outcome": "No exact existing deterministic matrix exponential-quadratic Bernstein bound or single-matrix normalized MGF interface was identified in this scope. No global absence claim.",
        "nearby_interfaces": [
            "Mathlib Analysis/Normed/Algebra/MatrixExponential: Matrix.exp_diagonal, Matrix.exp_blockDiagonal, Matrix.exp_conjTranspose, Matrix.IsHermitian.exp, Matrix.exp_transpose, Matrix.exp_neg, Matrix.exp_zsmul and conjugation identities; these are exponential identities/structure preservation, not the sealed bound.",
            "ProbabilityTheory.mgf_le_of_mem_Icc_of_integral_eq_zero and Probability/Moments/{Basic,SubGaussian,MGFAnalytic,ComplexMGF}: scalar real or complex MGF interfaces; not a matrix PSD-order MGF conclusion.",
            "Local EmpiricalCovariance.empiricalSecondMoment_preconcentration and unitRankOneCovariance_momentPackage: bounded rank-one operator symmetry/radius/moment packages, with population/unit-vector hypotheses; not W's literal Gaussian matrix MGF or deterministic Bernstein exponential bound.",
            "Local GaussianLipschitzExponential and StdGaussianRadialExponential: scalar Gaussian Laplace/radial exponential interfaces; not the sealed matrix statement. Local Probability.dvFiniteLogMgfOfLeAlpha and SALD MGF contracts likewise do not provide the sealed matrix conclusion.",
        ],
    },
    "probe_receipts": [json.loads((OUT / n).read_text()) | {"receipt_file": n, "receipt_sha256": sha(OUT / n)}
                       for n in ("interface-probe.receipt.json", "private-type-lookup.receipt.json")],
    "input_hashes": {p: sha(ROOT / p) for p in instructions + list(seal_paths.values()) + maps},
    "source_file_hashes": {r["path"]: r["file_sha256"] for r in headers},
    "writes": "Only this isolated .astis audit directory. No production Lean, ledger, frontier, Registry, graph or publication edit.",
    "truth_boundary": "Already compiled interfaces/type metadata only; no proof-body inspection, theorem proof, source-fidelity verdict, acceptance, new dependency edge or VERIFIED claim.",
}
(OUT / "audit-report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
manifest = {str(p.relative_to(OUT)): {"sha256": sha(p), "bytes": p.stat().st_size} for p in sorted(OUT.iterdir()) if p.is_file() and p.name != "safe-bounded-manifest.json"}
(OUT / "safe-bounded-manifest.json").write_text(json.dumps({"scope": str(OUT.relative_to(ROOT)), "artifacts": manifest,
    "no_production_or_shared_state_writes": True, "no_target_proofs": True,
    "no_proof_values_or_DAG_queries": True, "no_import_all": True,
    "no_private_whole_control_or_index_map_access": True}, indent=2) + "\n")
print(json.dumps({"report_sha256": sha(OUT / "audit-report.json"), "manifest_sha256": sha(OUT / "safe-bounded-manifest.json"),
                  "W_seal_matches": report["W_statement_seal"]["matches_parent_expected_sha256"],
                  "signature_comparisons": comparisons}, ensure_ascii=False, indent=2))
