lemma degree_eq (i : ℕ) : (S i).degree = i := S.degree_eq' i
