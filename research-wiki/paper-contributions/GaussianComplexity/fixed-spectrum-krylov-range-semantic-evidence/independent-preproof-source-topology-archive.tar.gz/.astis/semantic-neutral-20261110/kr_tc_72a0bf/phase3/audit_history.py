from pathlib import Path
import hashlib,json,ast,subprocess,datetime
OUT=Path(__file__).parent;ROOT=OUT.parent;W=Path('.astis/huanjian-gc-fixed-spectrum-krylov-range-20261110');sha=lambda b:hashlib.sha256(b).hexdigest()
a=(OUT/'StatementFormation.lean.attempt1.raw.txt').read_text();b=(OUT/'StatementFormation.lean.coordinate-energy-v2.raw.txt').read_text();c=(OUT/'StatementFormation.raw.lean.txt').read_text()
assert a.replace('λ','eigenvalue')==b
P=(ROOT/'phase2a/P.signature.txt').read_text();T=(ROOT/'phase2a/T.signature.txt').read_text()
assert (OUT/'producer-signature.draft.txt.attempt1.raw.txt').read_text().replace('λ','eigenvalue')==P
assert (OUT/'consumer-signature.draft.txt.attempt1.raw.txt').read_text().replace('λ','eigenvalue')==(OUT/'consumer-signature.draft.txt.coordinate-energy-v2.raw.txt').read_text()
for name,sig in [('PlannedProducer',P),('PlannedConsumer',T)]:
 marker=f'def {name} : Prop := ∀ ';start=c.index(marker)+len(marker);end=c.find('\ndef PlannedConsumer',start) if name=='PlannedProducer' else c.find('\n#check',start)
 assert c[start:end].strip()==sig.replace(' :\n', ',\n',1).strip()
assert b[:b.index('def PlannedConsumer')]==c[:c.index('def PlannedConsumer')]
assert all(t not in c for t in [':= by','sorry','axiom','theorem '])
ctx0=json.loads((OUT/'minimal-definition-context.json').read_bytes());ctx1=json.loads((OUT/'minimal-definition-context-exact-LF.json').read_bytes())
assert [x['literal'].rstrip('\n') for x in ctx0['definitions']]==[x['literal'].rstrip('\n') for x in ctx1['definitions']]
rs=json.loads((OUT/'R-receipts.index.json').read_bytes());ds={x['path'].split('/')[-1]:x['data'] for x in rs}
assert len(rs)==12 and sum(x['data']['exit_code']!=0 for x in rs)==2
formation=[x['data'] for x in rs if x['data']['command'][:3]==['lake','env','lean']]
assert [x['exit_code'] for x in formation]==[1,0,0]
seal=[x['data'] for x in rs if x['data']['command'][-1].endswith('/seal_exact_statements.py')][0]
assert formation[-1]['started_utc']<seal['started_utc']
assert all(x['data']['head_before']==x['data']['head_after']=='6a7a3a454b3ded093e335f57032227d3de02663f' for x in rs)
script=(OUT/'admit_normal_intake_prepared.py').read_text();assert sha(script.encode())=='593d25fd5c50a683e7f56937f28e7dc8c65fe05aa8414c47b69ab491a3a84cc7'
tree=ast.parse(script);calls=[]
for node in ast.walk(tree):
 if isinstance(node,ast.Call) and isinstance(node.func,ast.Attribute) and isinstance(node.func.value,ast.Name) and node.func.value.id=='adv' and node.func.attr in ['propose_advance','transition_advance']:
  calls.append({'line':node.lineno,'function':node.func.attr,'state':node.args[1].value if node.func.attr=='transition_advance' else 'PROPOSAL'})
assert sorted(x['function'] for x in calls)==['propose_advance','transition_advance','transition_advance']
assert {x['state'] for x in calls}=={'PROPOSAL','CLAIMED','EXPLORING'}
assert 'os.O_EXCL' in script and "os.environ.get('PYTHONOPTIMIZE') != '0'" in script
captures=[]
paths=[str(W/'prospective-admission-request.json')]+[x['path'] for x in json.loads((OUT/'W-inputs.metadata.json').read_bytes())]+[x['path'] for x in rs]+[x['path'] for x in json.loads((OUT/'R-logs.metadata.json').read_bytes())]
cap=OUT/'actual-read-captures';cap.mkdir()
for i,p in enumerate(paths):
 z=subprocess.run(['cat',p],capture_output=True);assert z.returncode==0
 (cap/f'{i:02d}.stdout').write_bytes(z.stdout);(cap/f'{i:02d}.stderr').write_bytes(z.stderr)
 captures.append({'argv':['cat',p],'returncode':z.returncode,'stdout_bytes':len(z.stdout),'stdout_sha256':sha(z.stdout),'stderr_bytes':len(z.stderr),'stderr_sha256':sha(z.stderr),'provenance':'actual rerun capture of already read authorized process input; no private baseline content captured'})
result={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reserved_lambda_to_eigenvalue_was_exact_alpha_rename':True,'final_two_closed_Props_exactly_encode_frozen_P_T':True,'coordinate_variant_to_actual_metric_was_before_seal':True,'no_target_proof_term_in_formation_source':True,'initial_context_vs_exact_LF_overlay_same_definition_semantics':True,'actual_R_receipts':12,'actual_R_failures':2,'failure_classes':['reserved-lambda-parser','disabled-v13-MD-vs-JSON-readback-identity'],'all_R_logs_rehashed':True,'all_R_heads_unchanged':True,'prepared_AST_normal_API_calls':sorted(calls,key=lambda x:x['line']),'intake_script_not_executed':True,'actual_read_captures':captures}
(OUT/'history-audit.receipts.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='actual_read_captures'},indent=2));print('actual read captures',len(captures),'all exit0, empty stderr')
