from pathlib import Path
import datetime
import hashlib
import json

ROOT = Path('/Users/zhouhuanjian/ASTIS-GC')
OWN = ROOT / '.astis/semantic-neutral-20261112/ri_tc_24a6'
PACKET = ROOT / '.astis/huanjian-gc-source-row-independence-20261112/selective-type-definition-packet.json'

def sha(b):
    return hashlib.sha256(b).hexdigest()

def digest(p):
    b = p.read_bytes()
    return {'path': str(p.relative_to(ROOT)), 'bytes': len(b), 'sha256': sha(b)}

assert digest(OWN / 'raw-freeze.json')['sha256'] == 'dc5f3b9278a7fe8d3eac246c794f0832ca157f4d9cf3b9c52443c28444e70ee9'
assert digest(OWN / 'raw-reading.md')['sha256'] == 'da525cbeeb425a406679ba7a96ed05d6ebb3ed32c2350fcc67d301593243db84'
assert digest(OWN / 'exposure.json')['sha256'] == '7d56295228b82cd5bcd0ae8d706a51fd6a97a3fa2bec02f597f9a9a4c3e52be5'
assert digest(PACKET)['sha256'] == 'c9f8312610515f2ebc067612c981889103e7d8a93a00aa5f75ec8c74feb1ab68'
p = json.loads(PACKET.read_text())
for key in ['producer', 'actual_private_consumer']:
    assert sha(p[key]['signature'].encode()) == p[key]['signature_sha256']
c = p['minimal_definition_context']
assert sha(c['literal_current_prints_and_instances'].encode()) == c['literal_current_prints_sha256']
assert all(sha(a['literal_source'].encode()) == a['literal_source_sha256'] for a in c['literal_definition_excerpts'])
raw = (ROOT / p['source']['raw']).read_bytes()
assert sha(raw) == p['source']['raw_sha256']
assert all(sha(raw[a['raw_utf8_start']:a['raw_utf8_end']]) == a['span_sha256'] for a in p['source']['anchors'])
local_paths = ['type-assignment.txt', 'type-exposure.json', 'type-audit.md', 'freeze_type.py']
record = {
    'kind': 'independent-type-only-meaning-audit-freeze',
    'actor': '/root/row_indep_topology_24a6',
    'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'packet': digest(PACKET),
    'prior_raw_freeze': digest(OWN / 'raw-freeze.json'),
    'prior_raw_reading': digest(OWN / 'raw-reading.md'),
    'prior_exposure': digest(OWN / 'exposure.json'),
    'local_records': [digest(OWN / name) for name in local_paths],
    'statement_seal_sha256_as_named_in_exact_packet': p['statement_seal_sha256'],
    'producer_signature_sha256_recomputed': p['producer']['signature_sha256'],
    'consumer_signature_sha256_recomputed': p['actual_private_consumer']['signature_sha256'],
    'definition_context_sha256_as_named_in_exact_packet': p['minimal_definition_context_sha256'],
    'literal_prints_sha256_recomputed': c['literal_current_prints_sha256'],
    'all_five_embedded_excerpt_hashes_match': True,
    'all_six_source_span_hashes_match': True,
    'type_source_meaning_finding': 'No type/source meaning issue found within narrow row-independence and literal truncated-matrix consumer scope.',
    'source_graph_seen': False,
    'formal_topology_challenge_or_admission_started': False,
    'implementation_lean_seen': False,
    'target_proofs_seen_or_attempted': False,
    'elaboration_compilation_or_actual_call_edges_certified': False,
    'proof_status_or_permission_grant': False,
    'remaining': [
        'Raw p1 marginal Gaussian-law content is outside this producer conclusion.',
        'Source-coverage/topology challenge awaits root-supplied graph.',
        'Actual internal measurability, scalar-array regrouping, source-consumer construction and producer call edges await proof and independent checks.'
    ]
}
out = OWN / 'type-freeze.json'
out.write_text(json.dumps(record, indent=2, ensure_ascii=False) + '\n')
records = [digest(OWN / n) for n in local_paths] + [digest(out)]
(OWN / 'TYPE-SHA256SUMS').write_text(''.join(f"{a['sha256']}  {Path(a['path']).name}\n" for a in records))
print(json.dumps({'type_freeze': digest(out), 'audit': digest(OWN / 'type-audit.md'),
                  'raw_freeze_preserved': digest(OWN / 'raw-freeze.json')}, indent=2))
