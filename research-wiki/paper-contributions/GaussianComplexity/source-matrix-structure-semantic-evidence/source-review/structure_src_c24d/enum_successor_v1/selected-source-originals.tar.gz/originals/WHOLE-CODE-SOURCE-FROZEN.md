# Whole-code/source judgment frozen

Commit: `9ed997b7fda8631deb5bc1397d021495d53c4d41`. Both whole-module hashes and line counts match the supplied immutable identities.

**Accepted mathematically for the bounded claims; no blocking finding.** This judgment was frozen after reading the full 148-line production module, the full 108-line private weighted consumer, necessary actual-law/mean/moment parent modules and pinned Mathlib meanings, before reading any ROOT compiler/kernel result or canonical reviewer packet.

All five conjuncts hold for each family: measurability, finite-family independence, Bochner integrability, actual zero expectation under the same product Gaussian measure, and pointwise self-adjointness. The actual Gaussian mean is subtracted directly; parent integrability prevents a totalized-zero artifact. Row independence comes from the actual joint product law, not scalar marginals. Weighted independence uses separate deterministic measurable scalar maps; zero and negative weights are allowed. No combined-family independence or iid assertion occurs. `q=0`, the exact `2q+1<d` regime, source indexing and the closed retained cutoff are preserved.

The statement-level `letI ... := borel Matrix` fixes standard Borel typing and is not a caller premise. Mathlib's scoped L2 operator norm retains the ordinary finite-product matrix topology/uniformity. These give the genuine finite-dimensional matrix integral and ordinary real symmetric/self-adjoint meaning.

The weighted theorem is private Tests consumption and receives no public API credit. Compiler/kernel status, final canonical seven-slot fidelity, current authored-publication review and normal verification remain pending or not requested. Detailed conjunct proofs, type meanings and source boundaries are in the JSON companion. No concentration or final Krylov claim is certified here.
