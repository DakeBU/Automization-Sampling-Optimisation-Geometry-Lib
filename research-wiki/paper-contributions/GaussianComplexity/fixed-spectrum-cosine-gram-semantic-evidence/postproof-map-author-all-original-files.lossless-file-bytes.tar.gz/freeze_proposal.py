from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,stat

R=Path('/Users/zhouhuanjian/ASTIS-GC')
O=R/'.astis/huanjian-gc-fixed-spectrum-cosine-gram-20261110/source-map-author-1d7a46'
S=R/'.astis/semantic-neutral-20261110/cg_sg_1d7a46'
assert not (O/'receipt.json').exists(), 'Already frozen; no rewrite.'
def digest(p): return sha256(p.read_bytes()).hexdigest()
def load(p): return json.loads(p.read_text())
def dump(p,obj): p.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')

original=[]
for phase,manifest_hash,receipt_hash in [
 ('phase1','ededc4db5669a328807c9e0fbf9f719fdc92df4257c878bafd343965e25fb00b','86869756bdcdb1dfe0a33cba6d572705ebee9c6784ecee5660db72c3c00bfd91'),
 ('phase2','d96ad3ac8e44b7f0621d62c620c1c9e4f8e38b626fa4aa2a5b94a0aa0eb02fc9','7b0e78a7cca3ba7ce39fe90f479cb0d264405e6e964b5714cdb0b2b29c6ff801')]:
 mp=S/(phase+'_manifest.json'); rp=S/(phase+'_receipt.json')
 assert digest(mp)==manifest_hash
 assert digest(rp)==receipt_hash
 m=load(mp)
 for item in m['files']:
  f=S/phase/item['path']
  assert f.stat().st_size==item['bytes'] and digest(f)==item['sha256']
  assert stat.S_IMODE(f.stat().st_mode)==0o444
 for d in [S/phase,*[p for p in (S/phase).rglob('*') if p.is_dir()]]:
  assert stat.S_IMODE(d.stat().st_mode)==0o555
 original.append({'phase':phase,'manifest_sha256':manifest_hash,'receipt_sha256':receipt_hash,'files_rechecked':len(m['files']),'all_original_hashes_and_modes_unchanged':True})

inputs=load(O/'inputs.json');meta={x['path']:x for x in inputs}
for item in inputs:
 snapshot=O/item['snapshot']
 assert snapshot.stat().st_size==item['bytes']
 assert digest(snapshot)==item['raw_wholefile_sha256']
 assert digest(R/item['path'])==item['raw_wholefile_sha256'], ('current input drift',item['path'])
p=load(O/'source-to-lean-map.PROPOSAL.json')
locs={x['slice_id']:x for x in p['locator_slices']}
assert len(locs)==57
assert len(p['canonical_rows'])==24==len({x['canonical_id'] for x in p['canonical_rows']})
assert len(p['correspondence_slices'])==29
for loc in locs.values():
 f=meta[loc['file']]
 b=(O/f['snapshot']).read_bytes();text=b.decode('utf-8')
 a,e=loc['character_start_inclusive'],loc['character_end_exclusive']
 block=text[a:e]
 assert block==loc['literalLF']
 assert '\r' not in block
 assert digest(O/'slices'/(loc['slice_id']+'.lean.txt'))==loc['exact_block_sha256']
 assert sha256(block.encode('utf-8')).hexdigest()==loc['exact_block_sha256']
 assert b[loc['byte_start_inclusive']:loc['byte_end_exclusive']]==block.encode('utf-8')
 assert text.startswith(loc['start_marker'],a)
 assert loc['end_marker']=='<EOF>' or text.startswith(loc['end_marker'],e)
 assert text.count('\n',0,a)+1==loc['start_line_1based_inclusive']
 assert text.count('\n',0,e-1)+1==loc['end_line_1based_inclusive']
 assert sha256(b).hexdigest()==loc['raw_wholefile_sha256']
for row in p['canonical_rows']:
 assert row['definition_or_lemma_locator_slice'] in locs
for row in p['correspondence_slices']:
 assert row['slice_id'] in locs
 assert set(row['canonical_references'])<=set(x['canonical_id'] for x in p['canonical_rows'])
raw=(O/meta['.astis/semantic-neutral-20261110/cg_sg_1d7a46/phase1/inputs/2610.20492v1.html']['snapshot']).read_bytes()
assert sha256(raw).hexdigest()==p['raw_source_sha256']=='6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
for ref in p['raw_source_anchor_locators'].values():
 assert sha256(raw[ref['byte_start']:ref['byte_end_exclusive']]).hexdigest()==ref['sha256']
assert all(x['formal_dependency'] is False for x in p['context_only_links'])
assert p['source_lineage']['raw_graph_sha256']=='c4b19d5410db563d3211b148277a34d2181cbf1133bef0b9932f0eb117ab5d4c'
assert p['source_lineage']['typed_overlay_sha256']=='e91185a610e691520fa0ca329d329e42ec2a825a36a3a19167c802a9257fc6cd'
validation={'kind':'mechanical locator/hash check','exact_code_slices_checked':57,'canonical_ids_unique':24,'correspondence_slices':29,
 'all_current_inputs_match_preserved_snapshots':True,'original_phase_immutability':original,
 'scope':'Only correspondence proposal integrity; no new mathematical/source/native acceptance, no Lean rerun.'}
dump(O/'logs/freeze-validation.json',validation)
excluded=['manifest.json','receipt.json','freeze.stdout.json']
files=sorted(x for x in O.rglob('*') if x.is_file() and x.relative_to(O).as_posix() not in excluded)
assert all(not x.is_symlink() for x in files)
manifest={'kind':'nonrecursive locator-proposal manifest','root':str(O),'excluded_metadata':excluded,
 'contract':'Hashes all payload files; excludes itself/receipt/stdout. Receipt hashes this manifest and not itself. Freeze stdout contains resulting receipt digest and is not included in a cyclic manifest.',
 'files':[{'path':str(f.relative_to(O)),'bytes':f.stat().st_size,'sha256':digest(f),'mode':'0444'} for f in files]}
dump(O/'manifest.json',manifest)
receipt={'kind':'mechanical locator proposal freeze receipt','frozen_utc':datetime.now(timezone.utc).isoformat(),
 'proposal_path':str(O/'source-to-lean-map.PROPOSAL.json'),'proposal_sha256':digest(O/'source-to-lean-map.PROPOSAL.json'),
 'manifest_sha256':digest(O/'manifest.json'),'original_phase_immutability':original,
 'counts':{'root_declarations':2,'correspondence_slices':29,'locator_slices':57,'canonical_rows':24,'generated_provider_math_nodes':0},
 'payload_files':len(files),'file_mode':'0444','directory_mode':'0555',
 'mathematical_scope':'Mechanical post-proof locator correspondence proposal only; implementation seen after both source freezes. Source/native independent acceptance belongs to other reviewers.',
 'remaining_source_boundary':['Range(B)=Krylov','C.6 concentration','full Lemma4.4','either main result'],
 'actions_not_performed':['Lean rerun','Lean edits','source/native verdict','normal API','intake','publication','global graph/site']}
dump(O/'receipt.json',receipt)
summary={'kind':'locator proposal frozen and paused','proposal_path':str(O/'source-to-lean-map.PROPOSAL.json'),'proposal_sha256':receipt['proposal_sha256'],
 'manifest_sha256':receipt['manifest_sha256'],'receipt_sha256':digest(O/'receipt.json'),'original_phase1_phase2_unchanged':True,'counts':receipt['counts']}
(O/'freeze.stdout.json').write_text(json.dumps(summary,ensure_ascii=False)+'\n')
allfiles=[x for x in O.rglob('*') if x.is_file()]
for f in allfiles: f.chmod(0o444)
dirs=sorted([O,*[x for x in O.rglob('*') if x.is_dir()]],key=lambda x:len(x.parts),reverse=True)
for d in dirs: d.chmod(0o555)
assert all(stat.S_IMODE(f.stat().st_mode)==0o444 for f in allfiles)
assert all(stat.S_IMODE(d.stat().st_mode)==0o555 for d in dirs)
print(json.dumps(summary,ensure_ascii=False))
