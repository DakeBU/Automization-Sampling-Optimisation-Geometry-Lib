"""R18 inline-math regression checks only. No source-anchor repair or acceptance prepopulation."""
from browser_geometry import VISIBLE, scroll_center

# Read-only geometry/semantic snapshot. CSS glyph boxes refer only to direct visible
# CHTML, excluding every assistive subtree; native MathML is audited separately.
MEASURE_TEMPLATE=r'''el=>{
 const rect=r=>({left:r.left,right:r.right,top:r.top,bottom:r.bottom,width:r.width,height:r.height});
 const style=getComputedStyle(el),parent=el.parentElement,ps=getComputedStyle(parent),pr=parent.getBoundingClientRect();
 const visibleMath=el.querySelector(':scope > mjx-math');
 const assistive=el.querySelector(':scope > mjx-assistive-mml');
 const native=[...(assistive?assistive.querySelectorAll('math'):[])];
 const nativeAudit=native.map(m=>{const ancestry=[];for(let p=m;p;p=p.parentElement){
   const s=getComputedStyle(p);ancestry.push({tag:p.tagName,display:s.display,visibility:s.visibility,ariaHidden:p.getAttribute('aria-hidden')});
   if(p===el)break;}
   return{text:m.textContent,namespace:m.namespaceURI,ancestry,
    semanticSubtreeAvailable:!!m.textContent.trim()&&m.namespaceURI==='http://www.w3.org/1998/Math/MathML'&&
     ancestry.every(x=>x.display!=='none'&&x.visibility!=='hidden'&&x.ariaHidden!=='true')};});
 const glyphs=visibleMath?[...visibleMath.querySelectorAll('mjx-c')].filter(e=>!e.closest('mjx-assistive-mml')):[];
 const glyphBoxes=glyphs.map(g=>({className:g.className,rect:rect(g.getBoundingClientRect()),geometry:($VISIBLE$)(g)}))
   .filter(g=>g.rect.width>0&&g.rect.height>0);
 const last=glyphBoxes.length?glyphBoxes[glyphBoxes.length-1]:null;
 const allGlyphsVerticallyInsideActualClip=glyphBoxes.length>0&&glyphBoxes.every(g=>
   g.rect.top>=g.geometry.clip.top&&g.rect.bottom<=g.geometry.clip.bottom);
 const r=el.getBoundingClientRect();
 return{rect:rect(r),geometry:($VISIBLE$)(el),clientWidth:el.clientWidth,scrollWidth:el.scrollWidth,
   scrollLeft:el.scrollLeft,maxScrollLeft:el.scrollWidth-el.clientWidth,
   computed:{display:style.display,maxWidth:style.maxWidth,overflowX:style.overflowX,overflowY:style.overflowY,
    fontSize:style.fontSize,fontSizePx:parseFloat(style.fontSize),lineHeight:style.lineHeight,
    paddingTop:style.paddingTop,paddingBottom:style.paddingBottom},
   parent:{rect:rect(pr),contentLeft:pr.left+parent.clientLeft+parseFloat(ps.paddingLeft),
    contentRight:pr.left+parent.clientLeft+parent.clientWidth-parseFloat(ps.paddingRight),
    contentWidth:parent.clientWidth-parseFloat(ps.paddingLeft)-parseFloat(ps.paddingRight),fontSize:ps.fontSize},
   directVisibleMathPresent:!!visibleMath,directAssistivePresent:!!assistive,nativeMathMLCount:native.length,
   nativeMathML:nativeAudit,normalizedFormula:native.length?native[0].textContent.replace(/\s+/g,''):'',
   glyphCount:glyphBoxes.length,visibleGlyphBoxes:glyphBoxes,lastVisibleGlyph:last,
   allVisibleGlyphsVerticallyInsideActualClip:allGlyphsVerticallyInsideActualClip,
   assistiveSubtreeTouched:false,sourceAnchorScrollModified:false};
}'''
MEASURE=MEASURE_TEMPLATE.replace('$VISIBLE$',VISIBLE)

def run_inline_regression(page,label,check,shot):
    selector='article.proof-reader .assumption-ledger li > mjx-container[jax="CHTML"]:not([display="true"])'
    roots=page.locator(selector)
    initial=roots.evaluate_all('xs=>xs.map('+MEASURE+')')
    check(label+'-inline-regression-top-level-assumption-math-present',len(initial)>0,{'count':len(initial)})
    candidates=[i for i,row in enumerate(initial) if any(m['text'].replace(' ','').startswith('A=Odiag(') and m['text'].strip().endswith('O⊤') for m in row['nativeMathML'])]
    check(label+'-inline-regression-exact-matrix-formula-unique',len(candidates)==1,{'candidate_indices':candidates,'native_formulas':[row['nativeMathML'] for row in initial]})
    if len(candidates)!=1:
        return
    target=roots.nth(candidates[0])
    # The original GLYPH mechanics also center the independently tested content.
    # This is a separate formula-reachability action, never a source-anchor fix.
    scroll_center(target)
    before=target.evaluate(MEASURE)
    check(label+'-inline-regression-parent-content-bound',
          before['rect']['left']>=before['parent']['contentLeft']-1 and
          before['rect']['right']<=before['parent']['contentRight']+1 and
          before['rect']['width']<=before['parent']['contentWidth']+1,before)
    check(label+'-inline-regression-actual-local-scroll-container',
          before['computed']['display']=='inline-block' and before['computed']['overflowX'] in ['auto','scroll'],before)
    # 17.424 px is the owning visible formula's independently measured original
    # font in first-expansion-opened-1.geometry.json (SHA feb48b1bc1b4d40f7983840016eb092f44c169736e584bc84df88f77a3a9bbbe).
    original_font_expected=max(17.424,float(before['parent']['fontSize'].removesuffix('px'))*1.089)
    check(label+'-inline-regression-original-font-not-shrunk',
          before['computed']['fontSizePx']>=original_font_expected-.001,
          {'original_mobile_font_px':17.424,'original_ratio_to_parent':1.089,'expected_minimum_current_font_px':original_font_expected,'actual':before['computed'],'parent':before['parent']})
    if label=='mobile':
        check(label+'-inline-regression-real-horizontal-overflow',before['maxScrollLeft']>1,before)
    check(label+'-inline-regression-assistive-native-MathML-preserved-before-scroll',
          before['directAssistivePresent'] and before['nativeMathMLCount']>0 and
          all(m['semanticSubtreeAvailable'] for m in before['nativeMathML']),before['nativeMathML'])
    check(label+'-inline-regression-visible-glyphs-vertical-containment-before-scroll',
          before['directVisibleMathPresent'] and before['allVisibleGlyphsVerticallyInsideActualClip'],before)
    shot(page,label+'-inline-regression-local-formula-before-scroll')
    # Intentional local-container exercise, same kind as the retained source GLYPH
    # rightmost test. No viewport/style/font/animation mutation occurs here.
    action=target.evaluate('el=>{const before=el.scrollLeft;el.scrollLeft=el.scrollWidth-el.clientWidth;return{before,after:el.scrollLeft,max:el.scrollWidth-el.clientWidth};}')
    after=target.evaluate(MEASURE)
    check(label+'-inline-regression-actual-right-edge-reached',
          after['maxScrollLeft']<=1 or (after['scrollLeft']>0 and after['scrollLeft']>=after['maxScrollLeft']-1),
          {'action':action,'measurement':after})
    tail=after['lastVisibleGlyph']
    check(label+'-inline-regression-final-visible-transpose-glyph-identified',
          tail is not None and 'mjx-c22A4' in tail['className'] and after['normalizedFormula'].startswith('A=Odiag(') and
          after['normalizedFormula'].endswith('O⊤'),{'tail':tail,'native_formula':after['normalizedFormula']})
    check(label+'-inline-regression-final-visible-glyph-inside-real-clip',
          tail is not None and tail['geometry']['positive'] and
          tail['rect']['left']>=tail['geometry']['clip']['left']-1 and
          tail['rect']['right']<=tail['geometry']['clip']['right']+1 and
          tail['rect']['top']>=tail['geometry']['clip']['top'] and
          tail['rect']['bottom']<=tail['geometry']['clip']['bottom'],tail)
    check(label+'-inline-regression-all-visible-glyphs-vertical-containment-after-scroll',
          after['allVisibleGlyphsVerticallyInsideActualClip'],after)
    check(label+'-inline-regression-assistive-native-MathML-preserved-after-scroll',
          after['nativeMathMLCount']==before['nativeMathMLCount'] and
          [m['text'] for m in after['nativeMathML']]==[m['text'] for m in before['nativeMathML']] and
          all(m['semanticSubtreeAvailable'] for m in after['nativeMathML']),after['nativeMathML'])
    final=roots.evaluate_all('xs=>xs.map('+MEASURE+')')
    check(label+'-inline-regression-all-assumption-native-MathML-retained-and-available',
          len(final)==len(initial) and
          [[m['text'] for m in row['nativeMathML']] for row in final]==[[m['text'] for m in row['nativeMathML']] for row in initial] and
          all(row['directAssistivePresent'] and row['nativeMathMLCount']>0 and all(m['semanticSubtreeAvailable'] for m in row['nativeMathML']) for row in final),
          {'root_count':len(final),'initial_root_count':len(initial),'all_root_native_math_audits':[row['nativeMathML'] for row in final]})
    shot(page,label+'-inline-regression-local-formula-right-end')
