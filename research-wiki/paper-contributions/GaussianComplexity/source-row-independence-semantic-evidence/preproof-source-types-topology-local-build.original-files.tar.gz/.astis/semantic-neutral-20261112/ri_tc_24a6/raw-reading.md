# Preliminary independent raw reading: row independence

This freezes a raw-source reading before any prospective Statement Seal,
binder/definition audit, source graph, or new typed packet was received. It is
not admitted source topology, a theorem signature, a proof, a mathematical
completion claim, or permission to proceed. The later formal topology challenge
must start from the exact approved seal and its binder/definition audit. No
compiled/call/transformation edge has been checked or proved here.

## Raw source identity and locations

The pinned local source is `On Complexity of Gaussian Sampling`, arXiv
2610.20492v1, `.astis/huanjian-resume-20261103/2610.20492v1.html`, 951991 bytes,
SHA-256 `6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915`.
HTML IDs are authoritative locators; line numbers refer to those exact bytes.

| Locator | Raw role in this bounded reading |
| --- | --- |
| `S4.Thmtheorem4`, line 1207; independence clause in Lemma 4.4 | Standing source columns g_1,...,g_(q+1) independent N(0,I_d), q>=0 and 2q+1<d. Only these clauses concern this prospective target. |
| `S4.E11`, line 1090; math `S4.E11.m1`, line 1094 | Exact physical grid theta_i=(i-1/2)pi/d. The other expressions in that display do not enter this target. |
| `A3.SS2.p1`, line 3317 | Sets r=q+1, n=2q+1; defines t_i and gamma_i for 1<=i<=d, explicitly asserts gamma_1,...,gamma_d independent N(0,I_r), then defines B. |
| `A3.SS2.p4.m2`, line 3379 | Repeats the exact grid, without needing that paragraph's orthogonality proof. |
| `A3.SS2.p10.1`, line 3533, first definition sentence | L=2r+3log(1000d), R_i=||gamma_i||^2. The following moment/Markov clause is excluded. |
| `A3.SS2.p12.1`, line 3571 | Explicitly calls the subsequently defined matrices independent. |
| `A3.Ex107`, line 3572 | Literal Y_i=(1/d)(gamma_i gamma_i^T tensor t_i t_i^T) 1_{R_i<=L}. |

## Prospective scope, frozen without types

The random experiment is the same concrete canonical product experiment of
r=q+1 independent real standard d-Gaussian columns. The actual row gamma_i is
the tuple of their i-th scalar coordinates. The desired reading is joint
independence of the entire family of d actual row vectors, with the explicit
real consumer being joint independence of the literal d truncated matrices on
that very experiment. A collection of independently constructed substitutes
with matching row marginals would not be that consumer. No arbitrary extended
ambient probability-space transfer has been requested.

The deterministic source data are theta_i=(i-1/2)pi/d and
t_i=(1,sqrt(2)cos(theta_i),...,sqrt(2)cos(q theta_i))^T. The threshold is precisely
L=2r+3log(1000d), with R_i<=L inclusive. A zero value outside this indicator is
the source's literal truncation, rather than a source-repair fallback. There is
no conditioning on all truncations succeeding, and no shared random threshold.

## Potential hidden premises and dimension checks for later review

- d and q are natural, q=0 is included, r=q+1, and 2q+1<d. Thus the physical
  row family is nonempty, d is nonzero, and no positivity premise for division
  or logarithms should be added publicly just to satisfy an API. A later
  signature must not silently impose q>0 or r>=2.
- Source indices are i=1,...,d and column indices 1,...,r. If types use zero
  based finite indices, the i+1 offset in theta and the actual column-coordinate
  projection must be visible; swapping physical and column indices changes the
  experiment. Every actual physical row must be included.
- gamma_i and t_i each have real dimension r. Both outer products are r by r;
  their Kronecker product is r^2 by r^2, naturally indexed by ordered pairs of
  r-indices. Flattening is only a deterministic indexing adapter and must not
  silently reverse the gamma/t factor order. No B, Krylov, eigenvalue or D_n
  hypotheses are needed merely because they occur nearby.
- At q=0, r=1, t_i=(1), with the same physical theta formula and the same L.
  The consumer is still the literal truncation for every physical row; it does
  not disappear with an empty range of nonconstant cosine coordinates.
- Joint independence of standard d-Gaussian columns and their full standard
  d-dimensional law are the standing inputs. Individual gamma_i marginals,
  pairwise row independence, or covariance cancellation alone would not express
  the source's joint independence assertion.
- The row-specific deterministic maps differ through t_i. The source calls
  Y_i independent; it does not make a generic identically-distributed matrix
  claim. No iid strengthening is justified for this family by equal Gaussian
  row marginals.
- Measurability of coordinate regrouping and each literal norm-threshold,
  outer-product/Kronecker map must be discharged internally. New public
  measurability, law-equality, row-independence or truncated-matrix-independence
  certificate inputs would require separate source justification and cannot be
  smuggled in as convenience premises.
- The tau<=1/2 condition and probability bound in Lemma 4.4 belong to its later
  conclusion, not to the row-independence/truncation-independence claim. No norm
  bound, successful-truncation event, moment estimate, bias/mean/PSD fact,
  centered variance estimate or concentration conclusion is an input here.

## Source bridges omitted from the printed local argument

These are preliminary source-reading obligations for a later sealed review,
not newly admitted graph nodes or proved mathematical claims:

1. `A3.SS2.p1` gives no local derivation from independent standard d-Gaussian
   columns to joint independence of all actual r-dimensional rows. A faithful
   internal bridge must account for the full scalar array and its regrouping
   into disjoint physical rows. Proving only each row's N(0,I_r) law misses the
   joint conclusion.
2. `A3.SS2.p12.1` labels the matrices independent without a local discharge of
   independence under the differing deterministic measurable maps whose bodies
   are displayed in `A3.Ex107`. The input must be the actual row family on the
   same experiment and the output must retain the literal inclusive truncation.
3. Any canonical finite-product coordinate order or matrix flattening used by
   types must be reconciled internally with the source tuple and tensor order.
   This is a source-to-representation obligation, not an external law-transfer
   theorem requested by this task.

## Explicit exclusions and next-phase boundary

Excluded are the B/Krylov construction after its incidental appearance in p1,
the n/frequency orthogonality proof, all moment/Markov and truncation-success
probability arguments, bias/expectation/PSD identities, Fact C.6's statement and
conclusions, centered variance, concentration, and the Lemma 4.4 main bound.
The source overreads are disclosed in `exposure.json`; none was used to prove
or admit an excluded claim.

No GaussianComplexity Lean file, new typed interface, previous audit, source
graph, verdict, lesson, ledger or global inventory content was read. A generic
filename search did expose the name of an old verifier-feedback file, and a
source outline exposed headings/IDs; these are recorded honestly. No parser or
process blocker was encountered or invented.

I now await the exact Statement Seal and binder/definition audit, then root's
specific source graph/type handoff. This preliminary freeze does not approve
coverage, topology, a signature, implementation, proof, or publication.
