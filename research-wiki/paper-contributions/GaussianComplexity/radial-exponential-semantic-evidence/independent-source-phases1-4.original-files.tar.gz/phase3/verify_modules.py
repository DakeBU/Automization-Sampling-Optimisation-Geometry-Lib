"""Bind the reviewed snapshot bytes and compare both target signature literals."""

import hashlib
import json
from pathlib import Path


SNAPSHOTS = Path(".astis/huanjian-gc-radial-exponential-20261110/fresh-source-immutable-modules")
MANIFEST_SHA256 = "967d845b49fbd1574a8a12ef8143c63a342d7e30e479a6ee9a9c2c5a68d125e6"
COMMIT = "c0bb993e3674181e33813d4b25fe655865e5ad0b"
SIGNATURES = {
    "StdGaussianRadialExponential.lean.txt": (
        "theorem integrable_exp_norm_sq_div_three_and_integral_stdGaussian\n    ",
        "7b27efe79e0ebbc31760b1e4bb17e8591bbca4335e35fd3fdbe4c642ee50c6b3",
    ),
    "GaussianComplexityRadialExponential.lean.txt": (
        "private theorem actual_source_row_truncation_tail\n    ",
        "3dc0457798c1b594a16ad8f7ab8e863d8cd469c9fe0b940550e05a23cdd2d94a",
    ),
}
EXPECTED_MODULES = {*SIGNATURES, "IsotropicGaussianDensity.lean.txt"}


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def main() -> None:
    manifest_raw = (SNAPSHOTS / "manifest.json").read_bytes()
    if sha256(manifest_raw) != MANIFEST_SHA256:
        raise ValueError("Snapshot manifest digest mismatch")
    manifest = json.loads(manifest_raw)
    if set(manifest) != EXPECTED_MODULES:
        raise ValueError("Unexpected module set")
    print(f"manifest_sha256={MANIFEST_SHA256}")
    for name, entry in manifest.items():
        raw = (SNAPSHOTS / name).read_bytes()
        digest = sha256(raw)
        if digest != entry["sha256"] or len(raw) != entry["bytes"] or entry["commit"] != COMMIT:
            raise ValueError(f"Snapshot manifest mismatch for {name}")
        print(f"{entry['repository_path']} sha256={digest} bytes={len(raw)} lines={len(raw.splitlines())}")
        if name in SIGNATURES:
            heading, expected = SIGNATURES[name]
            code = raw.decode("utf-8")
            literal = code.split(heading, 1)[1].split(" := by\n", 1)[0] + "\n"
            if sha256(literal.encode("utf-8")) != expected:
                raise ValueError(f"Signature does not match Phase 2 for {name}")
            print(f"  phase2_signature_sha256={expected}")
    print(f"All supplied snapshots matched the pinned manifest for {COMMIT}.")


if __name__ == "__main__":
    main()
