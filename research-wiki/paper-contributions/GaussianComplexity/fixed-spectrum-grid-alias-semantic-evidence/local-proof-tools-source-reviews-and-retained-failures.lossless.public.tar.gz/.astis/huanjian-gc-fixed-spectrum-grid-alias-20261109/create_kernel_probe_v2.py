from pathlib import Path
W=Path('.astis/huanjian-gc-fixed-spectrum-grid-alias-20261109')
s=(W/'KernelAndExactMeaning.lean').read_text()
old='''    if n == target then
      unless astis.isEmpty do throwError "Unexpected public ASTIS producer parent: {astis}"
    else
      unless astis.length == 2 && astis.contains target && astis.contains c7 do
        throwError "Actual consumer must use exactly new canonical alias and C7: {astis}"
'''
new='''    -- Raw compiler auxiliaries are printed and recursively inspected, never
    -- counted as additional public canonical producer declarations.
    let mut pending := used
    let mut seen : NameSet := {}
    let mut parents : NameSet := {}
    let mut auxiliaries : Array Name := #[]
    while !pending.isEmpty do
      let u := pending.head!
      pending := pending.tail!
      unless seen.contains u do
        seen := seen.insert u
        let localAux := u.toString.startsWith (target.toString ++ "._proof_") ||
          u.toString.startsWith (n.toString ++ "._proof_")
        if localAux then
          let some aci := env.find? u | throwError "Missing compiled auxiliary {u}"
          match aci with
          | .thmInfo _ => pure ()
          | _ => throwError "Expected theorem auxiliary, got {u}"
          let some ap := aci.value? true | throwError "Missing auxiliary proof {u}"
          let ax ← Lean.collectAxioms u
          unless ax.all (fun a => allowed.contains a) do throwError "Bad auxiliary axioms {u}: {ax}"
          auxiliaries := auxiliaries.push u
          pending := ap.getUsedConstants.toList ++ pending
          logInfo m!"ACTUAL_GENERATED_AUXILIARY {u}: {aci.type}"
          logInfo m!"ACTUAL_GENERATED_AUXILIARY_USES {u}: {ap.getUsedConstants.toList}"
          logInfo m!"ACTUAL_GENERATED_AUXILIARY_AXIOMS {u}: {ax}"
        else if u.toString.startsWith "AutoSamplingTheory." then
          parents := parents.insert u
    let publicParents := parents.toList
    if n == target then
      unless publicParents.isEmpty do throwError "Unexpected public ASTIS producer parent: {publicParents}"
    else
      unless publicParents.length == 2 && publicParents.contains target && publicParents.contains c7 do
        throwError "Actual consumer must use exactly new canonical alias and C7: {publicParents}"
    logInfo m!"GENERATED_AUXILIARIES_EXPANDED {n}: {auxiliaries}"
    logInfo m!"ACTUAL_PUBLIC_ASTIS_PARENTS {n}: {publicParents}"
'''
assert old in s;s=s.replace(old,new)
p=W/'KernelAndExactMeaningV2.lean';assert not p.exists();p.write_text(s);print(p)
