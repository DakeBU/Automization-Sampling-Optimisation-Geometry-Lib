import AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumGaussianMoments

open scoped BigOperators
open MeasureTheory ProbabilityTheory

/-- Independent check of the source diagonal-quadratic-form notation. -/
theorem independent_diagonal_quadratic_coordinates {d : ℕ}
    (w : Fin d → ℝ) (x : EuclideanSpace ℝ (Fin d)) :
    dotProduct (WithLp.ofLp x) (Matrix.mulVec (Matrix.diagonal w) (WithLp.ofLp x)) =
      ∑ i : Fin d, w i * (WithLp.ofLp x i) ^ 2 := by
  classical
  simp only [dotProduct, Matrix.mulVec_diagonal]
  apply Finset.sum_congr rfl
  intro i _
  ring

#check @ProbabilityTheory.multivariateGaussian
#check @ProbabilityTheory.IsGaussian.memLp_dual
#check @ProbabilityTheory.IsGaussian.integrable_fun_id
#check @ProbabilityTheory.integral_id_multivariateGaussian
#check @ProbabilityTheory.variance_eval_multivariateGaussian
#check @ProbabilityTheory.variance_eq_integral
#check @MeasureTheory.MemLp.integrable_sq
#check @ContinuousLinearMap.integral_comp_comm
#check @MeasureTheory.integrable_finsetSum
#check @MeasureTheory.integral_finsetSum
#check @MeasureTheory.integral_const_mul
#check @EuclideanSpace.real_norm_sq_eq
#check @Matrix.PosDef.diagonal
#check @Matrix.PosDef.inv
#check @Matrix.inv_eq_left_inv
#print axioms independent_diagonal_quadratic_coordinates
