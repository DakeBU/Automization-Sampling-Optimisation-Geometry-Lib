"""Bounded reuse search: declaration names and theorem signatures only."""
import hashlib
import json
import re
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
roots = [ROOT / "AutoSamplingTheory", ROOT / ".lake/packages/mathlib/Mathlib"]
decl = re.compile(r"^(?:(?:private|public|protected|noncomputable)\s+)*(theorem|lemma|def|abbrev|structure|class)\s+([^\s:(]+)")
needle = re.compile(r"bernstein|mgf|exponential_quadratic|quadratic_exponential|matrix_exp|exp_matrix", re.I)
hits, count = [], 0
for root in roots:
    for path in sorted(root.rglob("*.lean")):
        count += 1
        with path.open() as stream:
            for lineno, line in enumerate(stream, 1):
                m = decl.match(line)
                if m and needle.search(m.group(2)):
                    hits.append({"path": str(path.relative_to(ROOT)), "line": lineno,
                                 "kind": m.group(1), "name": m.group(2)})

# Modules selected from names/file inventory, bounded to existing matrix-exp,
# scalar MGF, concentration, PSD, and local covariance interfaces.
selected = [
    "AutoSamplingTheory/TechnicalLemmas/Probability/EmpiricalCovariance.lean",
    ".lake/packages/mathlib/Mathlib/Analysis/Normed/Algebra/MatrixExponential.lean",
    ".lake/packages/mathlib/Mathlib/Probability/Moments/Basic.lean",
    ".lake/packages/mathlib/Mathlib/Probability/Moments/SubGaussian.lean",
]
signatures = []
proof_stop = re.compile(r":=\s*by\b|:=\s*rfl\b|:=\s*fun\b")
for rel in selected:
    pending, start, name = [], 0, ""
    with (ROOT / rel).open() as stream:
        for lineno, line in enumerate(stream, 1):
            m = decl.match(line)
            if m:
                if m.group(1) in {"theorem", "lemma"}:
                    pending, start, name = [line], lineno, m.group(2)
                else:
                    pending = []
            elif pending:
                pending.append(line)
            if pending and proof_stop.search(line):
                header = proof_stop.split("".join(pending), maxsplit=1)[0].rstrip()
                signatures.append({"path": rel, "line": start, "name": name, "signature": header})
                pending = []
matrix_exp_regions = [
    ".lake/packages/mathlib/Mathlib/Analysis/CStarAlgebra",
    ".lake/packages/mathlib/Mathlib/Analysis/Normed/Algebra",
    ".lake/packages/mathlib/Mathlib/LinearAlgebra/Matrix",
    "AutoSamplingTheory/TechnicalLemmas/Probability",
]
region_names, region_signature_hits, region_count = [], [], 0
for region in matrix_exp_regions:
    for path in sorted((ROOT / region).rglob("*.lean")):
        region_count += 1
        pending, start, name = [], 0, ""
        with path.open() as stream:
            for lineno, line in enumerate(stream, 1):
                m = decl.match(line)
                if m:
                    if re.search(r"exp|bernstein|mgf", m.group(2), re.I):
                        region_names.append({"path": str(path.relative_to(ROOT)), "line": lineno, "name": m.group(2)})
                    pending, start, name = ([line], lineno, m.group(2)) if m.group(1) in {"theorem", "lemma"} else ([], 0, "")
                elif pending:
                    pending.append(line)
                if pending and proof_stop.search(line):
                    header = proof_stop.split("".join(pending), maxsplit=1)[0].rstrip()
                    if re.search(r"\bexp\b", header) and re.search(r"PosSemidef|IsHermitian|IsSelfAdjoint|Matrix|integral|∫", header):
                        region_signature_hits.append({"path": str(path.relative_to(ROOT)), "line": start, "name": name, "signature": header})
                    pending = []
result = {
    "scope": "declaration names in local AutoSamplingTheory and pinned Mathlib; theorem signatures in four selected modules",
    "files_name_scanned": count,
    "name_pattern": needle.pattern,
    "name_hits": hits,
    "signature_modules": selected,
    "signatures": signatures,
    "matrix_exp_signature_regions": matrix_exp_regions,
    "matrix_exp_region_file_count": region_count,
    "matrix_exp_region_name_hits": region_names,
    "matrix_exp_region_signature_hits": region_signature_hits,
    "no_proof_bodies_emitted": True,
    "no_theorem_proof_attempted": True,
}
(OUT / "reuse-search.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({"files_name_scanned": count, "name_hit_count": len(hits),
                  "local_name_hits": [x for x in hits if x["path"].startswith("AutoSamplingTheory/")],
                  "hit_modules": sorted({x["path"] for x in hits}),
                  "matrix_exp_region_file_count": region_count,
                  "matrix_exp_region_signature_hit_names": [x["name"] for x in region_signature_hits],
                  "selected_signature_counts": {p: sum(s["path"] == p for s in signatures) for p in selected}},
                 ensure_ascii=False, indent=2))
