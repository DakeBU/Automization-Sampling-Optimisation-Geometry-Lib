"""Freeze proof-free mathematical statements, binders, definitions and baseline."""
from pathlib import Path
import subprocess
import hashlib
import json
import datetime

R = Path('/Users/zhouhuanjian/ASTIS-GC')
W = Path(__file__).resolve().parent
sha = lambda b: hashlib.sha256(b).hexdigest()
def emit(path, value):
    assert not path.exists(), path
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
run_dir = W / 'baseline-actual'
run_dir.mkdir()
commands = []
def run(argv):
    proc = subprocess.run(argv, cwd=R, capture_output=True, check=False)
    n = len(commands)
    out, err = run_dir / f'{n:02d}.stdout.raw', run_dir / f'{n:02d}.stderr.raw'
    out.write_bytes(proc.stdout); err.write_bytes(proc.stderr)
    commands.append({'argv': argv, 'exit_code': proc.returncode,
        'stdout': str(out.relative_to(W)), 'stdout_sha256': sha(proc.stdout),
        'stderr': str(err.relative_to(W)), 'stderr_sha256': sha(proc.stderr)})
    assert proc.returncode == 0, argv
    return proc.stdout.decode().strip()
head = run(['git', 'rev-parse', 'HEAD'])
assert head == '2da2ccccfd1429aab18007e06895a1eb7cc58066'
assert run(['git', 'status', '--porcelain', '--untracked-files=no']) == ''
version = run(['lake', 'env', 'lean', '--version'])
assert 'version 4.33.0' in version and 'd8b18978322de05a8f3dba51ef03cf5461676c17' in version
binary = R / '.elan/toolchains/leanprover--lean4---v4.33.0/bin/lean'
# The installed elan root is beside this repository, not a repository subfolder.
binary = Path('/Users/zhouhuanjian/.elan/toolchains/leanprover--lean4---v4.33.0/bin/lean')
assert sha(binary.read_bytes()) == '1b370cfcbf44e80d1b004ab1b1ab9a4c73951f9f7c242140bcff9bc577576554'
manifest = json.loads((R / 'lake-manifest.json').read_text())
assert sha((R / 'lake-manifest.json').read_bytes()) == 'b83ca83b9cf7caa85fa8b023c2ff9a3fb7a7cce7e1c332e810c348535ec49c37'
packages = []
for p in manifest['packages']:
    path = '.lake/packages/' + p['name']
    actual = run(['git', '-C', path, 'rev-parse', 'HEAD'])
    status = run(['git', '-C', path, 'status', '--porcelain', '--untracked-files=no'])
    assert p['type'] == 'git' and actual == p['rev'] and status == ''
    packages.append({'name': p['name'], 'manifest_rev': p['rev'], 'actual_HEAD': actual, 'tracked_clean': True})
formation = W / 'StatementFormation.lean'
text = formation.read_text()
p_statement = text.split('def ProposedPublicStatement : Prop :=\n', 1)[1].split('\ndef ProposedPrivateConsumerStatement', 1)[0].strip() + '\n'
t_statement = text.split('def ProposedPrivateConsumerStatement : Prop :=\n', 1)[1].split('\n#check', 1)[0].strip() + '\n'
for name, data in [('P.proposition.sealed.v1.txt', p_statement), ('T.proposition.sealed.v1.txt', t_statement)]:
    path = W / name
    assert not path.exists()
    path.write_text(data)
receipt_path = R / '.astis/huanjian-resume-20261103/20261114T102435618401Z-matrix-laplace-proof-free-P-and-actual-four-sums-namespace-corrected-formation.receipt.json'
receipt = json.loads(receipt_path.read_text())
assert receipt['exit_code'] == 0 and receipt['head_before'] == head
source_pins = {
    '.astis/semantic-neutral-20261113/bernstein_raw_intake_74ab/Tro11-User-Friendly-preprint.pdf': 'f4c3cff8661011395e793972a1f8d9a199fae4ca0fd098535d7a42166cf8fc86',
    '.astis/huanjian-handoff-20261019/2610.20492v1.html': '6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'}
for path, digest in source_pins.items():
    assert sha((R / path).read_bytes()) == digest
emit(W / 'environment-baseline.v1.json', {'observed_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'local_source_HEAD': head, 'public_progress_commit': '4a746323019221910dd91b3e0039fe3345ae8d2b',
    'last_observed_main': '4db0f863340a1710446c86a6e9db1994cd8bceb3',
    'main_observation_record': 'research-wiki/technical-lemmas/matrix-bernstein-mgf-semantic-evidence/latest-owner-at-independent-V-closeout.json',
    'lean_actual_version': version, 'lean_binary': str(binary), 'lean_binary_sha256': sha(binary.read_bytes()),
    'toolchain_sha256': sha((R / 'lean-toolchain').read_bytes()), 'manifest_sha256': sha((R / 'lake-manifest.json').read_bytes()),
    'all9_exact_package_revisions_tracked_clean': packages, 'actual_commands': commands,
    'no_lake_update_or_new_target_proof': True})
audit = {
    'status': 'SEALED_ROOT_BINDER_AND_DEFINITION_AUDIT; INDEPENDENT_SOURCE_AND_TC_ADMISSION_PENDING',
    'P_binders': [
        {'binder': 'Ω : Type v; MeasurableSpace Ω', 'class': 'TYPING', 'meaning': 'General source random-matrix sample space.'},
        {'binder': 'μ : Measure Ω; IsProbabilityMeasure μ', 'class': 'SOURCE/STANDING', 'meaning': 'Probability law for source probability and expectation.'},
        {'binder': 'ι : Type u; Fintype; DecidableEq; Nonempty', 'class': 'TYPING', 'meaning': 'Finite nonempty real square matrix; excludes empty-spectrum fallback as a source maximum.'},
        {'binder': 'X : Ω → Matrix ι ι ℝ', 'class': 'SOURCE', 'meaning': 'Real self-adjoint special case of Tropp complex finite matrices; no complex theorem claimed.'},
        {'binder': 'hX : AEStronglyMeasurable X μ', 'class': 'STANDING', 'meaning': 'Expanded §2.2 regularity for matrix random variable and continuous scalar trace-exponential; no supplied tail or mgf certificate.'},
        {'binder': 'hherm : ∀ᵐ ω, (X ω).IsHermitian', 'class': 'SOURCE', 'meaning': 'Source self-adjointness with §2.2 almost-sure convention.'},
        {'binder': 't : ℝ', 'class': 'SOURCE', 'meaning': 'Every real threshold, including zero/negative; not t>0.'},
        {'binder': 'infimum over s : {s : ℝ // 0<s}', 'class': 'SOURCE', 'meaning': 'Exactly positive Laplace parameters; no nonpositive parameters or hidden restriction to finite Bochner mgfs.'}],
    'T_binders': [
        {'binder': 'd q : ℕ', 'class': 'TYPING/SOURCE', 'meaning': 'Original dimension/query parameters; r=q+1.'},
        {'binder': 'hq : 2*q+1<d', 'class': 'SOURCE', 'meaning': 'Original experiment range; q=0 retained. r≥1,d≥2 follow internally.'},
        {'binder': 's : ℝ; 0<s; a : ℝ', 'class': 'SOURCE', 'meaning': 'Every fixed positive Laplace parameter and real threshold.'},
        {'binder': 'useCos minus : Bool', 'class': 'TYPING/SOURCE-CASE-ELABORATION', 'meaning': 'Ordinary/cosine centered sum and each of their two global signs; no symmetry-in-law assumption.'}],
    'EXCESS': [],
    'definitions': [
        {'expression': 'sSup (spectrum ℝ A)', 'meaning': 'Algebraic largest eigenvalue on the ae self-adjoint finite nonempty source domain. Not operator norm or largest absolute eigenvalue. Nonempty/compact real spectrum and maximum semantics are proof obligations; behavior off the ae source domain supplies no conclusion.'},
        {'expression': 'NormedSpace.exp', 'meaning': 'Matrix-algebra series exponential with real/rational matrix algebra, not entrywise exponential; actual formation uses the same pinned L2 operator-norm scope as the audited existing floor.'},
        {'expression': 'Matrix.trace', 'meaning': 'Ordinary unnormalized real trace; trace I=card ι. The Gaussian matrix index is Fin(r)×Fin(r), hence size r², not d or r.'},
        {'expression': 'P lintegral of ENNReal.ofReal(trace exp)', 'meaning': 'Candidate uses nonnegative extended scalar expectation, allowing infinity. Ae positivity must be proved from self-adjointness; no Bochner nonintegrability-default-zero substitution. Tropp p9 notes mgfs may fail to exist for some parameters; this interpretation requires independent source/TC admission, not a claim that the source explicitly specifies ENNReal.'},
        {'expression': 'T Bochner integral of trace exp', 'meaning': 'Actual bounded cutoff sums must internally prove trace-exponential integrability and nonnegativity and its agreement with the extended expectation. No such fact is a T premise.'},
        {'expression': 'μ product(q+1 stdGaussian R^d)', 'meaning': 'Literal original unconditional experiment; row i reorders coordinates of the q+1 original vectors. No conditioned law.'},
        {'expression': 'Y, mean, Z', 'meaning': 'Own-row inclusive ||row_i||²≤L cutoff, d^-1(rowouter⊗featureouter), actual unconditional mean integral, centered difference. Paired index is Gaussian coordinate first, feature coordinate second.'},
        {'expression': 'four S useCos minus', 'meaning': 'Actual ±ΣZi and ±Σcos((2q+1)αi)Zi; signs do not assert equal mgfs or equal distributions. All regularity/centering/norm bounds remain internal proof obligations.'},
        {'expression': 'tail ≥ vs AppendixC2 norm tail >', 'meaning': 'Generic spectral event is the source Prop3.1 ≥ event. Later strict operator-norm tail transfer needs explicit event inclusion and both signs; no Eq121 closure now.'}],
    'not_new_binders': ['spectral maximum and trace domination', 'scalar Markov inequality', 'positivity and measurability of trace exponential',
        'event/ae measure adapters', 'actual Gaussian sum measurability/self-adjointness', 'actual exponential integrability',
        'Lieb/independent-sum/master-tail/Bernstein conclusions'],
    'formation_qualification': 'The hX/hherm/hq unused warnings are only in a Prop-valued type definition; no theorem proof has been supplied. First failed namespace-only stdGaussian formation is preserved, and ProbabilityTheory namespace correction changes no intended formula.',
    'formation_import_boundary': 'Broad existing modules are imported only for proof-free type formation; imports are not declared mathematical parents of the proposed public Laplace theorem.',
}
emit(W / 'binder-definition-audit.sealed.v1.json', audit)
seal = {'schema': 'exact-source-facing-matrix-laplace-statement-seal-v1',
    'status': 'SEALED_PROOF_FREE;SOURCE_GRAPH_AND_DISTINCT_TC_PENDING', 'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'local_base_commit': head, 'same_unfinished_goal': True, 'target_proof_calls': 0, 'normal_API_calls': 0,
    'P': {'proposed_file': 'AutoSamplingTheory/TechnicalLemmas/Probability/MatrixLaplaceTail.lean',
        'proposed_declaration': 'AutoSamplingTheory.TechnicalLemmas.Probability.MatrixLaplaceTail.max_eigenvalue_tail_le_iInf_trace_exp',
        'proposition_file': 'P.proposition.sealed.v1.txt', 'sha256': sha(p_statement.encode()), 'public': True},
    'T': {'proposed_file': 'Tests/GaussianComplexityLaplaceTail.lean',
        'proposed_declaration': 'AutoSamplingTheory.Tests.GaussianComplexityLaplaceTail.actual_source_four_sums_laplace_tail',
        'proposition_file': 'T.proposition.sealed.v1.txt', 'sha256': sha(t_statement.encode()), 'public': False,
        'actual_source_model': 'Only hq supplied; original cutoff centered ordinary/cosine sums and their two global signs, with finite actual Bochner trace expectation internally proved.'},
    'binder_definition_audit': {'file': 'binder-definition-audit.sealed.v1.json', 'sha256': sha((W / 'binder-definition-audit.sealed.v1.json').read_bytes())},
    'actual_type_formation': {'source_file': str(formation.relative_to(R)), 'source_sha256': sha(formation.read_bytes()),
        'receipt': str(receipt_path.relative_to(R)), 'receipt_sha256': sha(receipt_path.read_bytes()), 'exit_code': 0,
        'only_type_formation_not_target_proofs': True},
    'source_pins': source_pins,
    'source_anchors': {'P': 'Tropp2011 revised15June author preprint Prop3.1 statement p9, proof p9-10; §2.1-2.4 pp7-8 and §3.1 p9 expectation-domain caveat.',
        'T': 'Gaussian2610.20492v1 AppendixC2 Ex85, Ex107, p10,p13,Ex112,Ex121,p15/p15.2; original experiment angles p4.1 and g1..g(q+1) law p1.2. Norm > vs spectral≥ and source use of both signs remain explicit.'},
    'source_attribution': 'Independently matched external background; Gaussian does not explicitly cite Tropp at its C2 Bernstein call. Generic P real-case extended-expectation interpretation is a candidate for independent source review, not silently claimed to be the paper wording.',
    'bounded_reuse_inventory': {'receipt': '.astis/huanjian-resume-20261103/20261114T102932351760Z-matrix-laplace-bounded-existing-declaration-head-reuse-intake.receipt.json',
        'scope': 'Existing AutoSamplingTheory and pinned Mathlib declaration-head names matching laplace/chernoff/trace_exp/exp_trace/norm_le_trace/eigenvalue-exp/spectrum-trace. No exact matrix tail counterpart among inspected matches; not an exhaustive absence claim. Further API-level reuse search remains required before implementation.'},
    'truth_boundary': 'No new target proof or SAU admission yet. Intended bounded real matrix Laplace tail and exact four actual Gaussian sum cases only. No Lieb/independent-sum/master-tail/full Bernstein/C6/Lemma4.4/main lower bounds, oracle/TV/precision/query-cap/expected-cost adapter, main/production website/global graph, purification or whole-Goal completion.',
    'preservation_policy': 'Do not alter old packets, ledgers/frontiers/results/queues, original stabilization owner or root imports/Registry/global graph/site. New candidate preparation stays in its own ignored directory until independent admission.'}
emit(W / 'statement-seal.sealed.v1.json', seal)
emit(W / 'seal-output-index.v1.json', {'seal_sha256': sha((W / 'statement-seal.sealed.v1.json').read_bytes()),
    'binder_definition_sha256': sha((W / 'binder-definition-audit.sealed.v1.json').read_bytes()),
    'P_sha256': sha(p_statement.encode()), 'T_sha256': sha(t_statement.encode()), 'formation_exit_code': 0,
    'target_proofs_or_normal_API_calls': 0})
print((W / 'seal-output-index.v1.json').read_text())
