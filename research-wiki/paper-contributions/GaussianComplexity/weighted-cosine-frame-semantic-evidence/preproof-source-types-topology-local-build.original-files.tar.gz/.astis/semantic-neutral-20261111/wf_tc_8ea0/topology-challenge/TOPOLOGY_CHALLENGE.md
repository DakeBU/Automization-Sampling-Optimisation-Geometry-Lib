# Distinct topology challenge — wf_tc_8ea0

Verdict: **ACCEPTED_BOUNDED_SOURCE_TOPOLOGY_WITH_OPEN_PROOF_OBLIGATIONS**. No required mathematical repair, blocking source mismatch, missing substantive in-scope component, wrong mathematical edge direction, false AND-route, or hidden extra source hypothesis was found in the frozen raw graph plus typed overlay. This accepts the stated source/type topology for the two bounded targets. It certifies neither a proof nor actual compiled producer use; root remains the mathematical prover.

The exact raw/type predecessors and supplied graph artifacts are bound in `checked-inputs-manifest.json`. The independent raw reading preceded the type packet, my own type-only freeze preceded both supplied graphs, and the final challenge includes the separately frozen typed overlay. The earlier disclosed adjacent centered-source exposure remains outside credited mathematics. Original raw and type-only files, including both manifests, were preserved byte-for-byte. The extractor's mixed q classification is also preserved in its immutable history; my independent single-bin clarification is below.

## Independent target traces

The producer's expanded backward closure has 16 nodes and 12 edges. Its raw floor is dimensions and Euclidean/PSD conventions, half-grid and exact features, cosine cancellation, all Gram-entry cases, feature squared-length bound, and rank-one/tensor PSD algebra. These reach the raw r-by-r coefficient inequality Ct=sum_i ||t_i||^2 t_i t_i^T <= 2rd I_r. This is the deterministic content implicit in the Ex116 comparison, rather than a separately numbered source theorem.

The typed path is explicitly `raw:coefficient-comparison + typed-index-feature-port -> identity-tensor-port` (tp01), together with nonnegative alpha=(r+2)/d^2 (tp02), paired-coordinate identity (tp03), and d-nonzero scalar normalization (tp04), then the exact sealed producer (tp05). This supplies the required Ct -> I_r tensor Ct -> nonnegative scaling -> exact C I_N minus B path. The producer's complete backward closure contains no Gaussian law, Ex113, Ex114, Ex115, row experiment or integrability input. The literal factor r+2 is a deterministic coefficient here.

This was a substantive challenge point: raw edge e16 is a step in the entire expectation chain and consumes Ex115. Binding the sealed deterministic producer directly to that chain node would falsely inherit Gaussian inputs. The typed overlay avoids this: its producer takes the raw coefficient comparison through tp01–tp05 and never routes through raw Ex115/Ex116. The raw history remains intact.

The consumer's expanded backward closure has 27 nodes and 22 edges. It contains the full deterministic producer closure and the following additional canonical ports: single-row Gaussian law, literal canonical row template, canonical radial fourth matrix moment with its actual integrability, rank-one square, tensor/scalar/indicator square, individual squared-summand Bochner integrability, PSD indicator deletion, integration order and deterministic-factor transport, and the finite-sum Ex115 counterpart. Edge tc06 requires `typed-producer`, `typed-Ex115-integral-sum-port` and `typed-square-integrability` to reach the exact sealed consumer. Thus the proposed consumer dependency is materially represented; actual proof use remains to be inspected once an implementation exists.

The canonical integration-port inputs explicitly require actual integrability of both compared sides. The matrix square and its untruncated domination use only degree-four Gaussian content after deterministic tensoring. Measurability, finite-dimensional Bochner interpretation, scalar/tensor transport and finite-sum linearity are internal ports. The totalized integral's zero default cannot count as discharge because every actual square integrand's integrability is a conclusion. No infinite-series or limit bridge is silently introduced.

## Source provenance and exhaustive bounded coverage

All 60 source locator byte/character spans, line intervals and raw hashes were independently checked against the pinned 951,991-byte HTML. Every raw and typed source anchor and consumer use site resolves. All 18 raw-freeze originals and 9 typed-freeze originals hash correctly. Graph references are valid and acyclic; the recorded full, marginal-cut and expanded typed closures reproduce independently. These mechanical checks are supporting provenance evidence, not mathematical proof validation.

The 34 primary source inventory components were individually challenged in `independent-component-challenge.json`; each is mapped or explicitly excluded with a mathematical reason. The typed inventory preserves every original component and all support/downstream exclusions. The exact producer and consumer statement strings equal my frozen type-packet strings and reproduce their signature digests.

The retained source chain covers Ex113's sign-symmetry/diagonal-fourth-moment explanation; both rank-one square identities; the implicit tensor/indicator algebra for Ex114; PSD deletion; expectation/integrability/finite-sum transport for Ex115; feature squared-length comparison for Ex116; and the Gram, tensor identity and exact scalar normalization for Ex117. Backward support includes the half-grid cosine telescope, nonzero sine, all constant/nonconstant and diagonal/off-diagonal Gram cases, and the norm calculation. There is no missing external citation in this closure.

The range/Krylov change of basis, signed n-frequency Gram cancellation, first moments, cutoff-tail event/bias, centered norm paragraph and concentration motivation are explicitly excluded where unused. Centered Ex118, variance/operator-norm Ex119, high-frequency centered-square Ex120, Bernstein, Fact C.6 and the complete Lemma 4.4 proof remain downstream. The comparison's weights are ||t_i||^2, not cos(n theta_i). No scoped completion claim crosses this boundary.

## Marginal and original-family boundary

The raw graph retains the original source experiment and its unexpanded adapter from independent d-dimensional Gaussian columns to each r-dimensional row law. Its separate marginal-sufficient closure cuts at the individual row law. The typed consumer instead begins from canonical `stdGaussian E` and literal row templates; it does not inherit the raw original-family row-map, original column law, or row-law adapter as an already discharged theorem.

This is appropriate for the exact sealed finite sum of canonical marginal second moments. The same dummy integration variable in every indexed term does not construct or identify the original family. Original-family measurability, each row marginal-law identification, expectation transport for the relevant integrands, agreement of the source Y_i with the template, and any later full joint-law/independence transport remain explicitly open. Cross-row independence is unnecessary for the current sum of individual expectations and is neither assumed nor concluded by the canonical target.

## Binder clarification and q=0

My primary classification for `{q : Nat}` is **TYPING**. It specifies the nonnegative integer degree carrier used by the source; the source's integer q>=0 wording is the rationale for this carrier choice. It does not introduce an additional logical premise. `{d : Nat}` is also TYPING, and `hq : 2*q+1<d` is STANDING. The extractor's literal `TYPING + SOURCE` label for q can therefore be read through this independent single-primary-bin clarification without altering its frozen artifact. No mathematical repair or statement change is required.

The exact formulas include q=0: r=1, t_i=(1), hq implies d>=2, the positive-frequency block is empty, and all product matrices are 1-by-1. Ex113 becomes the ordinary Gaussian fourth moment 3. The deterministic coefficient is 3/d and the source's valid loose final bound is 6/d. No q>0, r>=2 or nonempty-frequency condition is hidden in any accepted path.

## Remaining obligations and acceptance limits

The six raw SOURCE_GAP nodes remain visible as omitted exposition/internal proof bridges: rank-one/tensor PSD order; original-family-to-row marginal adapter; Gaussian polynomial integrability; tensor/indicator square algebra; expectation and finite-sum order; tensor/scalar identity normalization. The label does not mean the source is false and licenses no extra public assumptions. Their source topology is accepted, not their formal discharge.

The deterministic cosine/Gram/PSD/tensor/scalar mathematics still needs actual proof. The canonical radial fourth-moment/integrability dependency's exact theorem interface and material reuse have not been inspected. Square, measurability, integrability, PSD deletion, Bochner order, deterministic tensor/scalar transport and finite sums remain proof obligations. The actual consumer must demonstrably use the deterministic producer when implemented. No implementation, API, proof, compiler history, decoder, old verdict or ATLAS material was opened for this challenge.

There are **no required mathematical repairs** to either exact signature or this bounded source topology. Original-family transport and all centered/concentration conclusions are outside the accepted target scope. This verdict is not a proof grant, process grant, source-completion certificate or permission to claim the larger paper result.
