"""Independent bounded raw/source-JSON/closure checks, not target proof."""
from pathlib import Path
from collections import Counter, defaultdict
from bisect import bisect_right
import hashlib
import json
import re
import runpy

B = Path('.astis/huanjian-gc-fixed-spectrum-mode-gap-20261110')
I = B / 'independent-source-graph/phase2'
O = B / 'independent-topology-challenge/phase2b'
PINS = {
    'phase2-freeze.json': '38671a5bda14e7164d6b33c1ecbd2e892dcf3c2092d2d1c2cf557add94ea225e',
    'source-proof-graph.json': 'a2376d7ecdd2c186fe59c4b55db300ea5695bf046fb81c2b2902e01d1eb52ed0',
    'exact-target-coverage.json': '4aa3b58447de06c53f3195d4f73e0f9509e093fe72aaae0c18a67d7e6bf1e0d9',
    'root-subroot-closures.json': '9905d6e4fd66b8b2e264cdfd207ae7143ad85acad9440fc37a0846602ade96a9',
    'statement-projection-audit.json': '6c9d9c7ab6de843708c09928cfd7baf799d046d544a34dee493cab35875a9be7',
    'machine-inputs.json': 'c1c26eab25d3bf36dc7a61acb92fff718fdff9e6edb58236a2cb30ebfbda21ed',
    'binding-lineage.json': '6534fe7aac3e4d845b35f12d7093736a638cc14227fdd4cdd827d851d0b9a9d0',
}


def pin(p):
    data = p.read_bytes()
    return {'path': str(p), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


inputs = []
for name, expected in PINS.items():
    info = pin(I / name)
    assert info['sha256'] == expected, name
    inputs.append(info)
g = json.loads((I / 'source-proof-graph.json').read_bytes())
c = json.loads((I / 'exact-target-coverage.json').read_bytes())
rc = json.loads((I / 'root-subroot-closures.json').read_bytes())
lineage = json.loads((I / 'binding-lineage.json').read_bytes())
own = json.loads((B / 'independent-topology-challenge/phase1/raw-source-inventory.json').read_bytes())
m = runpy.run_path('.astis/huanjian-gc-fixed-spectrum-variances-20261110/independent-topology-challenge/source_only_reader.py')
walk, record, ids = m['walk'], m['record'], m['READER'].ids
source_lines = m['TEXT'].splitlines(keepends=True)


def key(n):
    line = bisect_right(m['LINES'], n.start)
    return f'{n.tag}@{line}:{n.start - m["LINES"][line - 1]}'


def compact(s):
    return re.sub(r'\s+', '', s)


def actual_math(n):
    return [{'id': q.attrs.get('id'), 'line': record(q)['line_start'], 'tex': q.attrs.get('alttext', ''),
             'display': q.attrs.get('display', '')} for q in walk(n) if q.tag == 'math']


def actual_refs(n):
    return [{'line': record(q)['line_start'], 'href': q.attrs['href'], 'title': q.attrs.get('title', ''),
             'text': re.sub(r'\s+', ' ', m['normalized'](q)).strip()} for q in walk(n)
            if q.tag == 'a' and q.attrs.get('href', '').startswith('#')]


source_nodes = {key(n): n for root in ['S2', 'S4', 'A3.SS3', 'bib.bib3'] for n in walk(ids[root])}
own_by_key = {u['source_unit_key']: u for u in own['units']}
assert len(own_by_key) == 367
rows = c['rows']
assert [r['raw_unit_ordinal'] for r in rows] == list(range(366))
keys = [r['raw_source_unit']['source_unit_key'] for r in rows]
assert len(set(keys)) == 366 and set(keys) <= set(own_by_key)
assert set(own_by_key) - set(keys) == {'a@1853:0'}
extra_link = source_nodes['a@1853:0']
assert extra_link.attrs['href'].startswith('https://github.com/openai/math/blob/main/preprints/')
whitespace_only = []
for row in rows:
    u = row['raw_source_unit']
    n = source_nodes[u['source_unit_key']]
    actual = record(n)
    assert u['original_html_id'] == n.attrs.get('id')
    assert n.tag == own_by_key[u['source_unit_key']]['tag']
    assert u['original_lines'] == [actual['line_start'], actual['line_end']]
    a, z = u['original_lines']
    assert hashlib.sha256(''.join(source_lines[a - 1:z]).encode()).hexdigest() == u['raw_html_LF_fragment_sha256']
    assert u['math'] == actual_math(n), u['id']
    assert u['references'] == actual_refs(n), u['id']
    assert compact(u['text_with_tex']) == compact(m['normalized'](n)), u['id']
    if u['text_with_tex'] != re.sub(r'\s+', ' ', m['normalized'](n)).strip():
        whitespace_only.append(row['raw_unit_ordinal'])
    parent = n.parent
    while parent and not parent.attrs.get('id'):
        parent = parent.parent
    assert u['parent_original_html_id'] == (parent.attrs.get('id') if parent else None), u['id']
    parent = n.parent
    while parent and parent.tag != 'table':
        parent = parent.parent
    assert u['containing_display_id'] == (parent.attrs.get('id') if parent else None), u['id']
    successor = row['exact_target_successor']
    assert successor['disposition'] in ['NODE', 'EXCLUDED']
    if successor['disposition'] == 'NODE':
        assert successor['graph_nodes'] and successor['reason'] is None
    else:
        assert successor['reason'] and not successor['graph_nodes']
math_ids = {v['id'] for row in rows for v in row['raw_source_unit']['math']}
assert math_ids == {v['id'] for v in own['math_registry']} and len(math_ids) == 350
collisions = {name: [r['raw_unit_ordinal'] for r in rows if r['raw_source_unit']['id'] == name]
              for name, count in Counter(r['raw_source_unit']['id'] for r in rows).items() if count > 1}
assert sorted(map(len, collisions.values())) == [2, 2]
nodes, edges = {n['id']: n for n in g['nodes']}, {e['id']: e for e in g['routes']}
assert len(nodes) == len(g['nodes']) == 52
assert len(edges) == len(g['routes']) == 48 and g['OR_routes'] == []
incoming = defaultdict(list)
snapshots = 0
for n in g['nodes']:
    for a in n['source_anchors']:
        u = rows[a['raw_unit_ordinal']]['raw_source_unit']
        for field in ['id', 'source_unit_key', 'original_lines', 'math', 'references']:
            assert a[field] == u[field], (n['id'], field)
        assert a['raw_fragment_sha256'] == u['raw_html_LF_fragment_sha256']
        snapshots += 1
for e in g['routes']:
    assert e['consumer'] in nodes and e['logic'] == 'AND' and e['inputs'] and e['discharge']
    assert all(n in nodes for n in e['inputs'])
    incoming[e['consumer']].append(e)
    for a in e['consumer_use_sites']:
        u = rows[a['raw_unit_ordinal']]['raw_source_unit']
        assert a['id'] == u['id'] and a['original_lines'] == u['original_lines']
assert {n for row in rows for n in row['exact_target_successor']['graph_nodes']} == set(nodes)
assert all(incoming[n['id']] for n in g['nodes'] if n['kind'] == 'SOURCE_GAP')


def closure(root):
    seen, routes, active = set(), set(), set()

    def visit(n):
        assert n not in active, ('cycle', n)
        if n in seen:
            return
        active.add(n)
        for e in incoming[n]:
            routes.add(e['id'])
            for p in e['inputs']:
                visit(p)
        active.remove(n)
        seen.add(n)

    visit(root)
    return {'root': root, 'nodes': sorted(seen), 'routes': sorted(routes),
            'node_source_anchors': sorted({a['id'] for n in seen for a in nodes[n]['source_anchors']}),
            'route_use_site_anchors': sorted({a['id'] for e in routes for a in edges[e]['consumer_use_sites']}),
            'leaves': sorted(n for n in seen if not incoming[n]),
            'internal_SOURCE_GAP_nodes': sorted(n for n in seen if nodes[n]['kind'] == 'SOURCE_GAP')}


closures = {}
for owner, provided in rc['closures'].items():
    d = closure(provided['root'])
    for field in ['nodes', 'routes', 'internal_SOURCE_GAP_nodes']:
        assert d[field] == provided[field], (owner, field)
    closures[owner] = d
for n in nodes:
    closure(n)
assert closures['producer_all_outputs']['leaves'] == ['S_delta', 'S_mode', 'S_regime']
assert closures['consumer_all_outputs']['leaves'] == ['A_objects', 'S_delta', 'S_mode', 'S_regime']
assert all(nodes[n]['role'] == 'scalar-producer' for n in closures['producer_all_outputs']['nodes'])
extra_roots = ['G_large_dimension_domain', 'S_mode', 'N_mode_lt', 'N_uniform_gap',
               'N_M_positive', 'N_signed_b_positive', 'N_actual_polynomial_bias',
               'N_uniform_mode_small', 'N_uniform_sqrt_small', 'N_source_exponent', 'N_exponential_to_power']
subroots = {n: closure(n) for n in extra_roots}
canonical = lambda x: hashlib.sha256(json.dumps(x, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
raw_sha = canonical([row['raw_source_unit'] for row in rows])
history_sha = canonical([row['phase1_disposition'] for row in rows])
assert raw_sha == lineage['raw_rows_canonical_sha256'] == lineage['successor_raw_rows_canonical_sha256']
assert history_sha == lineage['history_rows_canonical_sha256'] == lineage['successor_history_rows_canonical_sha256']
preserved = []
for sub, name in [('phase1', 'SHA256SUMS.phase1'), ('phase2a', 'SHA256SUMS.phase2a')]:
    base = B / 'independent-topology-challenge' / sub
    for line in (base / name).read_text().splitlines():
        expected, filename = line.split('  ', 1)
        assert pin(base / filename)['sha256'] == expected
    preserved.append(pin(base / name))
projection = pin(B / 'strict-preproof-seal-projection-v2.json')
assert projection['sha256'] == '54b23ce1ccd86b780b8c2b38bb18ac3cf91b5102afefe15444b2231e1b65c0f9'
raw_pin = pin(m['SOURCE'])
assert raw_pin['sha256'] == '6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
result = {'run': 'MODE-GAP-INDEPENDENT-PHASE2B-MATHEMATICAL-GRAPH-CHECK-20261110',
          'check_kind': 'raw_source_binding_and_graph_traversal_not_a_target_proof',
          'structural_check_result': 'PASS', 'exact_machine_inputs': inputs,
          'source_and_projection': [raw_pin, projection],
          'creator_statement_audit_content': 'HASH_ONLY_NOT_PARSED',
          'granularity': {'own_units': 367, 'machine_units': 366,
                          'own_only_source_key': 'a@1853:0', 'external_bibliography_url': extra_link.attrs['href'],
                          'resolution': 'External navigation hyperlink separately inventoried by own census; machine single-row units enumerate internal references only. Complete bib identity/original raw row remains EXCLUDED, no missing mathematical assertion.'},
          'coverage': {'all_source_keys_unique_and_raw_bound': True,
                       'all_line_hashes_IDs_text_math_references_true_parents_and_displays_checked': True,
                       'unique_math_ids': len(math_ids),
                       'target_dispositions': dict(Counter(r['exact_target_successor']['disposition'] for r in rows)),
                       'source_kind_counts': dict(Counter(r['raw_source_unit']['kind'] for r in rows)),
                       'anonymous_collisions_preserved': collisions,
                       'text_renderer_whitespace_only_difference_ordinals': whitespace_only},
          'graph': {'nodes': len(nodes), 'AND_routes': len(edges), 'OR_routes': 0,
                    'node_raw_snapshots_rebound': snapshots,
                    'route_raw_use_sites_rebound': sum(len(e['consumer_use_sites']) for e in edges.values()),
                    'no_free_SOURCE_GAP_leaf': True, 'acyclic_all_components': True},
          'all_five_provided_root_subroot_sets_recomputed_exact': closures,
          'additional_each_output_and_uniformity_subroots': subroots,
          'current_raw_history_canonical_hashes_match_lineage': [raw_sha, history_sha],
          'own_prior_checksum_members_rechecked_unchanged': preserved,
          'chronology_or_root_planning_note_read': False,
          'new_target_proof_API_Mathlib_implementation_old_verdict_or_normal_ASTIS': False}
O.mkdir(parents=True, exist_ok=True)
p = O / 'source-coverage-closure-checks.json'
assert not p.exists()
p.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'output': pin(p), 'coverage': result['coverage']['target_dispositions'],
                  'root_counts': {k: [len(d['nodes']), len(d['routes'])] for k, d in closures.items()},
                  'graph': result['graph']}, ensure_ascii=False, indent=2))
