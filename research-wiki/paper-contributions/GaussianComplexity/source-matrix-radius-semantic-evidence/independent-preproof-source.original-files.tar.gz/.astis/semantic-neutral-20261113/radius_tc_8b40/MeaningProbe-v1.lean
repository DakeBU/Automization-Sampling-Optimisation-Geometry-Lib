import AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumSourceMatrixVariance
import AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumSourceMatrixMean
noncomputable section
open MeasureTheory ProbabilityTheory
open scoped BigOperators Matrix Kronecker Matrix.Norms.L2Operator
variable (q d : ℕ)
set_option pp.all true in
#synth Norm (Matrix (Fin (q + 1) × Fin (q + 1)) (Fin (q + 1) × Fin (q + 1)) ℝ)
set_option pp.all true in
#synth Norm (EuclideanSpace ℝ (Fin (q + 1)))
#synth NormedSpace ℝ (Matrix (Fin (q + 1) × Fin (q + 1)) (Fin (q + 1) × Fin (q + 1)) ℝ)
#print WithLp.toLp
#print WithLp.ofLp
#print Matrix.vecMulVec
#print Matrix.kronecker
#print Matrix.kroneckerMap
#print MeasureTheory.integral
#check Measure.pi
#check stdGaussian
