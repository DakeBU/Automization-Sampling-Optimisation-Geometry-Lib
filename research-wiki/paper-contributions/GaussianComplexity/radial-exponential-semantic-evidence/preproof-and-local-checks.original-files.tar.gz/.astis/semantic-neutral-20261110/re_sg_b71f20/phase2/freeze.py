from pathlib import Path
import json,hashlib,datetime,stat
BASE=Path(__file__).resolve().parent
def sha(b):return hashlib.sha256(b).hexdigest()
packet=BASE/'inputs'/'selective-type-definition-packet.json'
assert sha(packet.read_bytes())=='44cecb47245a0d1ab06d634f8b1dcd408c8368437e37cea1f0bde46fc2669ae3'
paths=sorted(BASE.rglob('*'));assert all(not p.is_symlink() for p in paths)
files=[p for p in paths if p.is_file() and p.name!='phase2-manifest.json']
dirs=[BASE]+[p for p in paths if p.is_dir()]
rows=[{'path':str(p.relative_to(BASE)),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes()),'frozen_mode':'0444'} for p in files]
g=json.loads((BASE/'typed-source-overlay.json').read_text());c=json.loads((BASE/'typed-coverage.json').read_text())
assert len(g['literal_targets'])==2 and len(g['literal_definitions'])==11
assert g['phase1_binding']['source_graph_bytes_modified'] is False
assert g['selective_packet_sha256']==sha(packet.read_bytes())
manifest={'schema':'typed-source-phase2-content-manifest-v1','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'phase1_binding':g['phase1_binding'],'selective_packet_sha256':sha(packet.read_bytes()),'file_records':rows,'directory_records':[{'path':'.' if p==BASE else str(p.relative_to(BASE)),'frozen_mode':'0555'} for p in dirs],'whole_run_write_scope_pristine':False,'self_binding':'The index and actual freeze process receipt bind this manifest itself; payload records include every other Phase2 file.'}
mp=BASE/'phase2-manifest.json';mp.write_text(json.dumps(manifest,indent=2,ensure_ascii=False)+'\n')
for p in files+[mp]:p.chmod(0o444)
for p in sorted(dirs,key=lambda x:len(x.parts),reverse=True):p.chmod(0o555)
for row in rows:
    p=BASE/row['path'];assert sha(p.read_bytes())==row['sha256'] and p.stat().st_size==row['bytes'] and stat.S_IMODE(p.stat().st_mode)==0o444
assert stat.S_IMODE(mp.stat().st_mode)==0o444
for p in dirs:assert stat.S_IMODE(p.stat().st_mode)==0o555
key=['typed-source-overlay.json','typed-coverage.json','typed-mathematics.md','exposure.json','phase2-manifest.json']
out={'status':'FROZEN_LITERAL_TYPE_OVERLAY_ONLY','phase2_path':str(BASE),'total_phase2_files':len(files)+1,'file_modes':'0444','directory_modes':'0555','key_sha256':{n:sha((BASE/n).read_bytes()) for n in key},'selective_packet_sha256':sha(packet.read_bytes()),'phase1_graph_binding':g['phase1_binding']['graph_sha256'],'coverage_counts':c['counts'],'whole_run_write_scope_pristine':False,'truth_boundary':'Typed source comparison, no proof/API/compile/independent acceptance/semantic verifier transition.'}
print(json.dumps(out,indent=2,ensure_ascii=False))
