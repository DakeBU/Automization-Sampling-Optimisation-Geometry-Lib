# Independent raw-source mathematical freeze

Role: distinct SOURCE-ONLY topology challenger. This is my independent reconstruction and coverage inventory, not the other author's Source Proof Graph, a Lean proof, verifier certification, or a statement-seal judgment. No target type or definition context has yet been shown.

## Frozen source and exposure

The supplied raw HTML is *On Complexity of Gaussian Sampling*, arXiv 2610.20492v1, SHA256 6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915 (951991 bytes; 942139 Unicode code points; 4269 LF; no CR). Its original bytes and the original supplied protocol files remain in inputs. I read the supplied AGENTS/proof-digestion/evidence-routed-memory/theorem-publication files and the supplied sibling input-manifest. I have not read implementation Lean, API inventories, a statement seal, another author's graph, old verdicts, ledger, Git, network, site, or Goal state. The initial task names the scalar radial exponential moment, row-tail, literal L and intended later phases; this is disclosed exposure, not a claim of a wholly unprompted topic selection. No guarantee of pristine pretraining is made.

I first attempted inputs/input-manifest.json; that path did not exist. The command returned exit 1 after printing cwd and listing the five supplied input files. I then read phase1/input-manifest.json successfully. All actual original shell commands and returned output/status are retained in the execution receipt, including this failure. The first combined protocol output was display-truncated; I subsequently reread all four supplied files in bounded separate batches. The title/heading scan incidentally exposed headings and theorem labels elsewhere in the same raw HTML, not their mathematical body. Section 4 and all Appendix C.2 bodies were rendered with TeX alttext and read. The exact C.2 p10–p11 raw HTML was also read.

## Source setup independently reconstructed

Section 4.1 defines d>=2, kappa>=2, cosine nodes theta_i=(i-1/2)pi/d, an affine cosine spectrum Lambda and an independent Haar eigenbasis O. Those spectral/rotation choices do not change the standard Gaussian normalization used below.

Section 4.2, Lemma 4.3: integer q>=0 with 2q+1<d; there exist q+1 mutually independent g_a~N(0,I_d) giving the almost-sure Krylov output representation. The extra starting vector accounts for the output. This is a contextual source for the starters, not an analytic prerequisite to the radial identity for a vector whose standard Gaussian law is already fixed.

Appendix C.2 p1 sets r=q+1 and n=2q+1 and defines
 t_i=(1,sqrt(2)cos theta_i,...,sqrt(2)cos(q theta_i))^T,
 gamma_i=((g_1)_i,...,(g_r)_i)^T.
It explicitly says gamma_1,...,gamma_d are independent N(0,I_r). This follows from the independent Gaussian starter vectors and the independent coordinates of N(0,I_d). In particular R_i=||gamma_i||^2 is a sum of r squares of independent N(0,1) variables. The dimension is r=q+1, not q, d or r^2. Independence across rows is true in this setup but a single-row exponential moment needs only the marginal law. The later union bound needs no independence across rows.

The row definition of B is d^(-1/2)(gamma_i tensor t_i)^T, in R^(d x r^2). This d^(-1/2) belongs to B, not gamma_i or R_i. Replacing R_i by a B-row squared norm would introduce the factor ||t_i||^2/d and would change the asserted moment.

## Selected scalar source assertion and omitted background bridge

The actual assertion in A3.SS2.p10.m3 is
 E exp(R_i/3) = 3^(r/2).
Here r/2 is real division and 3^(r/2)=exp((real r/2)log 3). For odd r it is not an integer power produced by natural-number division. In the source endpoint q=0, r=1, it equals sqrt(3). At q=1, r=2, it equals 3. The source r is always at least 1; extending the identity to dimension 0 would also be true but would be a generalization, not a new source premise. The assumption 2q+1<d ensures d>=2 and 2r<=d in this source context, but neither inequality is mathematically necessary for this single-row identity.

The source states the moment without a derivation or external citation at that use site. The omitted background calculation is:
 E exp(||Z||^2/3)
 = (2pi)^(-r/2) integral_R^r exp(-||z||^2/6) dz
 = (sqrt(3))^r = 3^(r/2), Z~N(0,I_r).
Equivalently, use the product of one-dimensional normalized Gaussian integrals. This is an omitted/background bridge, not evidence that the source assertion is false. The density is normalized relative to Lebesgue measure. Using an unnormalized Gaussian weight, variance other than 1, a Gaussian with a nonzero mean, exp(||Z||/3), or exp(3||Z||^2) would change or destroy the assertion.

The same computation establishes finiteness/integrability of the exponential: the combined exponent is -||z||^2/6, with positive Gaussian precision 1/3. Squared norm and exponential are measurable. Nonnegativity permits Tonelli/product integration before finiteness is concluded; the resulting finite value supplies ordinary integrability. Integrability of exp(R_i/3) is a proof ingredient to discharge internally, not an extra source hypothesis. A finite expectation as a real-valued integral by itself must not silently rely on a convention returning zero for nonintegrable functions. The normalized probability law and the actual integrability conclusion must both remain visible.

## Scalar consumer chain with use sites and conditional discharge

At A3.SS2.p10 / Ex104, for every real x>=0, exponential monotonicity and Markov yield
 P(R_i>2r+3x)
 <= E exp(R_i/3) / exp((2r+3x)/3)
 = exp((r/2)log3 - 2r/3 - x)
 <= exp(-x).
The denominator is strictly positive. The strict event > is bounded by the usual >= Markov event, so the endpoint convention is sound. The last inequality uses r>=0 and (log3)/2<2/3. The source's source-level x>=0 binder belongs to this tail estimate, not to the preceding moment identity.

The literal threshold at A3.SS2.p10.m1 is L=2r+3log(1000d), with natural logarithm and d regarded as a positive real inside log. For the displayed source range d>=2, x=log(1000d)>=0. Substitute it into Ex104 to obtain P(R_i>L)<=1/(1000d). With exactly d row indices, the union bound on the complement of T={for every i, R_i<=L} gives P(T)>=1-d/(1000d)=0.999 (A3.Ex105 and p10.3). Equality at the threshold is retained in the good event; the bad event uses >. No product formula or row independence is required for this union step.

At A3.SS2.p11, substitute x=log(1000d)+s/3, for real s>=0, obtaining
 P(R_i>L+s)<=exp(-s/3)/(1000d).
The nonnegative tail-integral identity for R_i, with L>=0, gives
 E[R_i 1_{R_i>L}]
 = L P(R_i>L)+integral_0^infinity P(R_i>L+s) ds
 <= (L+3)/(1000d).
The factor 3 is the integral of exp(-s/3), not exp(-s). This omitted layer-cake/Tonelli justification is another background bridge; finiteness follows from the bound. These are downstream scalar consumers of the moment, not incoming parents of it.

At p12 the tail moment controls 1-a, using the separate standard fact E R_i=r and radial symmetry:
 E[gamma_i gamma_i^T 1_{R_i<=L}]=a I_r,
 1-a=E[R_i 1_{R_i>L}]/r <= (L+3)/(1000rd).
Here r>0 is discharged by r=q+1. The division by r should not be copied to a hypothetical zero-dimensional generalization without a separate argument.

At p17 the event T is used to identify the original matrix sums with truncated sums; intersecting T with two matrix concentration events yields failure budget 0.001+0.004 and success 0.995. This is a genuine downstream use of the scalar row-tail event. It is not itself the proof of the row-tail or moment.

## Boundaries and spurious-edge challenges frozen before targets

The selected scalar source ingredient is not Fact C.6 in full and is not Lemma 4.4. Full C.6 additionally requires cosine moment identities, radial truncation symmetry, Gaussian second/fourth moments, operator-norm and variance bounds, two matrix Bernstein estimates, their union bound, bias subtraction, and absolute-constant simplification. Lemma 4.4 then additionally uses range(B)=K_q, matrix quadratic-form comparison, the condition tau<=1/2, and a simultaneous-for-all-u conclusion. Those remain outside any claim that the scalar moment alone has been formalized.

There is no source justification for an incoming edge to the radial identity from Fact C.5, cosine orthogonality, the high-frequency choice n=2q+1, the matrix B norm estimates, matrix Bernstein, full C.6, Lemma 4.4, target N(0,Lambda^-1) moments, or the Section 4.3 TV contradiction. Those items are unrelated context or downstream users. The correct normalization/law, r-dimensional squared norm, and Gaussian integration bridge are indispensable. A general conditional exponential Markov theorem may be a useful library ingredient, but it cannot turn the actual Gaussian exponential moment, integrability, normalization, or T probability into extra public source premises.

The proof uses one sufficient scalar route (Gaussian exponential moment, then Markov, then union bound). Treating a chi-square MGF formula and direct product Gaussian integration as simultaneous required AND parents would invent a false conjunction; they are alternative realizations of the same omitted background identity. No second source-authored proof route is claimed.

## Deferred judgment

The source scalar assertions above are coherent under the actual standard Gaussian row law. I find no SOURCE_INVALID defect in this bounded source chain. Omitted derivations remain explicit background/SOURCE_GAP nodes in this independent coverage inventory; this is not a statement that the mathematical identity is untrue. I have not judged any sealed generic or source-facing target, because none has been shown. Phase 2 must expand the actual meaning-carrying definitions, classify every actual binder, and check whether the exact proposed interface discharges these ingredients or smuggles them into assumptions. Only after that typed judgment is frozen should the other author's graph be exposed.

