"""Merge only explicit previously frozen allowlists; never discover export files by rglob."""
from hashlib import sha256
import json
from pathlib import Path

BASE = Path('/Users/zhouhuanjian/ASTIS-GC/.astis/semantic-neutral-20261114/mgf_fresh_source_5b7e')
SOURCES = [
    'phase5_static/public-chosen-originals.phase5-static.json',
    'phase6_reporter_preflight/public-chosen-originals.preflight.json',
    'phase7_native_visual/public-chosen-originals.failed-runtime.json',
    'phase8_anchor_repair_static/public-chosen-originals.anchor-repair.json',
    'phase9_v3_contract_preflight/public-chosen-originals.v3-preflight.json',
    'phase10_native_glyph_failure/public-chosen-originals.v3-failure.json',
    'phase11_v4_measurement_preflight/public-chosen-originals.v4-static.json',
    'phase12_final_native_visual/public-chosen-originals.final-runtime.json',
]
TARGET = BASE / 'public-chosen-originals.manifest.phase5-through-final.json'
if TARGET.exists():
    raise RuntimeError('Frozen final public manifest already exists; do not overwrite.')


def sha(data):
    return sha256(data).hexdigest()


ROOT_EXPLICIT_PUBLIC_STREAMS = {'phase6-preflight.actual.stdout.txt', 'phase9-preflight.actual.stdout.txt', 'phase5-static-checks.actual.stdout.txt', 'phase9-preflight.actual.stderr.txt', 'phase7-original-archive.actual.stdout.txt', 'phase5-static-checks.actual.stderr.txt', 'phase6-preflight.actual.stderr.txt', 'phase8-static.actual.stderr.txt', 'phase7-candidate-archive.actual.stderr.txt', 'phase7-original-archive.actual.stderr.txt', 'phase8-static.actual.stdout.txt', 'phase7-candidate-archive.actual.stdout.txt'}
rows = {}
manifest_sources = []
def include(path, expected_sha=None, expected_bytes=None, chosen_by=None):
    p = Path(path)
    if p.is_absolute() or '..' in p.parts or not p.parts or (p.as_posix() not in ROOT_EXPLICIT_PUBLIC_STREAMS and p.parts[0] not in {
        'phase5_static', 'phase6_reporter_preflight', 'phase7_native_visual',
        'phase8_anchor_repair_static', 'phase9_v3_contract_preflight',
        'phase10_native_glyph_failure', 'phase11_v4_measurement_preflight',
        'phase12_final_native_visual', 'phase13_public_selection'}):
        raise ValueError('Selection escapes the explicit phase5-final owned artifacts: ' + path)
    forbidden = ['mirror-normal-api', 'ledger', 'foreign', 'workspace', 'chrome-cache', 'chromium-cache']
    if any(part.lower() in forbidden for part in p.parts):
        raise ValueError('Private guard/cache component in export path: ' + path)
    data = (BASE / p).read_bytes()
    actual = {'source_relative_path':p.as_posix(),'bytes':len(data),'sha256':sha(data)}
    if expected_sha is not None and actual['sha256'] != expected_sha:
        raise ValueError('Previously frozen bytes changed: ' + path)
    if expected_bytes is not None and actual['bytes'] != expected_bytes:
        raise ValueError('Previously frozen byte count changed: ' + path)
    if path in rows and any(rows[path][key] != actual[key] for key in actual):
        raise ValueError('Conflicting source bindings: ' + path)
    if path not in rows:
        actual['chosen_by'] = []
        rows[path] = actual
    if chosen_by and chosen_by not in rows[path]['chosen_by']:
        rows[path]['chosen_by'].append(chosen_by)


for relative in SOURCES:
    data = (BASE / relative).read_bytes()
    manifest = json.loads(data)
    manifest_sources.append({'source_relative_path':relative,'bytes':len(data),'sha256':sha(data)})
    include(relative, chosen_by='exact additive allowlist itself')
    for item in manifest['files']:
        path = item.get('source_relative_path', item.get('path'))
        include(path, item['sha256'], item['bytes'], chosen_by=relative)

for extra in ['merger-attempt1.original.py', 'merger-attempt1.actual-failure.md', 'merger-attempt2.original.py', 'selection-boundary-note.md']:
    include('phase13_public_selection/' + extra, chosen_by='explicit bounded export-merger history')

prior = BASE / 'public-chosen-originals.manifest.through-phase4.json'
assert sha(prior.read_bytes()) == '2549201d96092036c9dc4ca0ca399a4a96317185656d751d436348300c7ebcbc'
assert any('checker-attempt1.actual-failure.md' in p for p in rows)
assert any('checker-attempt1.original.py' in p for p in rows)
result = {
    'schema':'bounded-explicit-chosen-originals-phase5-through-final-v1',
    'source_base':str(BASE),
    'copy_only_explicit_files':True,
    'never_rglob_source_base_or_phase4':True,
    'scope':'Independent static/actual reader reviews, exact input/diff contracts, previous failures and final real native screenshots/receipts; additive to immutable through-phase4 list.',
    'prior_through_phase4_manifest':{'source_relative_path':prior.name,'sha256':sha(prior.read_bytes()),'rewritten':False},
    'excluded':['Complete discovery/advance ledgers and copies','All foreign state/digest maps','Workspace/index full protection snapshots','Guard implementation/raw guard payload','Chrome profiles/cache/global machine state'],
    'all_original_failure_and_schema_attempt_artifacts_retained':True,
    'source_allowlists':manifest_sources,
    'file_count':len(rows),
    'total_bytes':sum(item['bytes'] for item in rows.values()),
    'files':[rows[p] for p in sorted(rows)],
}
TARGET.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'path':str(TARGET),'sha256':sha(TARGET.read_bytes()),'files':result['file_count'],'bytes':result['total_bytes']},indent=2))
