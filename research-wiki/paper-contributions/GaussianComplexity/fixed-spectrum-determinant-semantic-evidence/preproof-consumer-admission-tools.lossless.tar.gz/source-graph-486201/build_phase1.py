from pathlib import Path
from hashlib import sha256
from copy import deepcopy
from bs4 import BeautifulSoup, NavigableString
import json

ROOT = Path('/Users/zhouhuanjian/ASTIS-GC')
PRIVATE = ROOT / '.astis/huanjian-fixed-spectrum-determinant-20261108/source-graph-486201'
OUT = ROOT / 'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-determinant-semantic-evidence/source-only-review/phase1'
RAW = ROOT / '.astis/huanjian-resume-20261103/2610.20492v1.html'
EXPECTED = '6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
data = RAW.read_bytes()
assert sha256(data).hexdigest() == EXPECTED
raw_text = data.decode('utf-8')
soup = BeautifulSoup(data, 'html.parser')
PREFIX = 'src:arxiv:2610.20492v1:'
def sid(x): return PREFIX + x
def dump(name, value):
    p = OUT / ('source_graph_486201.' + name + '.json')
    p.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
    return p
def normalized(e):
    e = deepcopy(e)
    for m in e.find_all('math'):
        m.replace_with(' $' + m.get('alttext', '') + '$ ')
    return ' '.join(e.get_text(' ', strip=True).split())
def line_of(anchor):
    token = 'id="' + anchor + '"'
    pos = raw_text.index(token)
    return raw_text.count('\n', 0, pos) + 1

nodes = []
def node(key, kind, anchors, statement, status='SOURCE_EXPLICIT', **extra):
    nodes.append(dict(id=sid(key), kind=kind, source_anchors=anchors,
                      statement=statement, source_status=status, **extra))
node('S2:euclidean', 'standing-definition', ['S2.p1'],
     'The ambient space is real Euclidean space; ||·|| is its Euclidean norm, I_d the identity, and A≼B means B−A is positive semidefinite for symmetric matrices.')
node('S2:orthogonal', 'standing-definition', ['S2.p2'],
     'O(d)={O∈R^{d×d}:OᵀO=I_d} is the full real orthogonal group. It has determinant +1 and −1 components; neither is excluded.')
node('S2:haar', 'standing-definition', ['S2.p2'],
     'Haar probability measure is on the full O(d); the two determinant components each have Haar probability 1/2.')
node('S2:precision-class', 'standing-definition', ['S2.Ex1'],
     '𝒜_{d,κ} consists of real symmetric d×d A with I_d≼A≼κI_d.')
node('S4:domain', 'source-standing-assumption', ['S4.SS1.p1.1'],
     'In the hard-family construction d is an integer with d≥2 and κ is a real parameter with κ≥2. Grid indices are i=1,…,d, as in diag(λ₁,…,λ_d).')
node('S4.E11:theta', 'literal-definition', ['S4.E11'],
     'θ_i=((i−1/2)π)/d for i=1,…,d.', latex=r'\theta_i=\frac{(i-\tfrac12)\pi}{d}')
node('S4.E11:lambda', 'literal-definition', ['S4.E11'],
     'λ_i=(κ+1)/2+((κ−1)/2)cos θ_i.', latex=r'\lambda_i=\frac{\kappa+1}{2}+\frac{\kappa-1}{2}\cos\theta_i')
node('S4.E11:diagonal', 'literal-definition', ['S4.E11'],
     'Λ=diag(λ₁,…,λ_d). This is the particular deterministic cosine grid in the paper.', latex=r'\Lambda=\operatorname{diag}(\lambda_1,\ldots,\lambda_d)')
node('S4:draw', 'source-experiment-definition', ['S4.SS1.p1.2'],
     'Draw O∼Haar(O(d)), independently of the algorithm’s private randomness.')
node('S4:rotation', 'literal-definition', ['S4.SS1.p1.2'],
     'A=OΛOᵀ.', latex=r'A=O\Lambda O^{\top}')
node('S4:potential', 'literal-definition', ['S4.SS1.p1.2','A3.SS4.p2.1'],
     'f_A(x)=xᵀAx/2; C.4 writes the same literal quadratic formula as V_A(x)=½xᵀAx on all x∈R^d.')
node('S4:target', 'source-definition', ['S4.SS1.p1.2','A3.SS4.p3.1'],
     'The associated target is π_A=N(0,A^{-1}), with precision A and covariance A^{-1}.')
node('S4:fixed-spectrum', 'substantive-unnumbered-statement', ['S4.SS1.p2.1','A3.SS4.p3.2'],
     'For fixed d,κ, Λ and the spectrum are deterministic and do not vary with O.')
node('S4:public-spectrum', 'conditional-informational-premise', ['S4.SS1.p2.1','A3.SS4.p3.2'],
     'The spectrum may be supplied to the algorithm; the final known-Z claim is conditional on the spectrum being public. No public eigenbasis is assumed.')
node('S4:hidden-eigenbasis', 'substantive-context-statement', ['S4.SS1.p2.1'],
     'The unknown component is the random eigenbasis represented by O.')
node('S4:known-Z-assertion', 'substantive-unnumbered-claim', ['S4.SS1.p2.1'],
     'In the public-spectrum experiment the Gaussian normalizing constant is known. C.4 supplies the displayed reason.')
node('S4.Thmtheorem6:admissibility', 'numbered-source-lemma', ['S4.Thmtheorem6'],
     'For every O∈O(d), A=OΛOᵀ satisfies I_d≼A≼κI_d, under the hard-family setup d≥2, κ≥2.')
node('A3.SS4:angle', 'substantive-unnamed-estimate', ['A3.SS4.p1.1'],
     'For every grid index i, 0<θ_i<π.')
node('A3.SS4:cosine', 'substantive-unnamed-estimate', ['A3.SS4.p1.1'],
     'For every grid index i, −1<cos θ_i<1.')
node('A3.SS4:eigenvalue', 'substantive-unnamed-estimate', ['A3.SS4.p1.1'],
     'For every grid index i, 1<λ_i<κ.')
node('A3.SS4:spectral-order', 'substantive-proof-step', ['A3.SS4.p1.1'],
     'Orthogonal conjugation of the diagonal grid gives I_d≼A≼κI_d.')
node('A3.SS4:symmetry', 'omitted-bridge', ['S4.E11','S4.SS1.p1.2','A3.SS4.p2.1'],
     'Λ is real diagonal and A=OΛOᵀ is symmetric. This supplies the symmetry used by the Hessian identity without importing positivity into that derivative step.',
     status='SOURCE_GAP', classification='internal-paper-step',
     gap='The source leaves the elementary transpose calculation implicit. It follows from the literal matrix definitions, not an additional source hypothesis.')
node('A3.SS4:symmetric-positive', 'omitted-bridge', ['S4.SS1.p1.2','A3.SS4.p1.1','A3.Ex160'],
     'A and Λ are real symmetric positive definite; their determinants are positive. This is a prerequisite of the Gaussian integral and inverse/real-power meanings.',
     status='SOURCE_GAP', classification='internal-paper-step',
     gap='The source supplies the diagonal eigenvalue bounds and spectral order, but does not separately spell out symmetry, positive definiteness, determinant positivity, or inverse existence. These are standard finite-dimensional consequences, not new source binders.')
node('A3.SS4:smooth', 'substantive-unnamed-statement', ['A3.SS4.p2.1'],
     'V_A is C∞ on R^d.')
node('A3.SS4:hessian', 'substantive-unnamed-identity', ['A3.SS4.p2.1'],
     'For all x∈R^d, ∇²V_A(x)=A.')
node('A3.SS4:strong-convexity', 'substantive-unnamed-statement', ['A3.SS4.p2.1'],
     'V_A is 1-strongly convex.')
node('A3.SS4:smoothness-bound', 'substantive-unnamed-statement', ['A3.SS4.p2.1'],
     'V_A is κ-smooth.')
node('A3.SS4:zero-value', 'substantive-unnamed-identity', ['A3.SS4.p2.1'],
     'V_A(0)=0.')
node('A3.SS4:quadratic-lower', 'substantive-unnamed-estimate', ['A3.SS4.p2.1'],
     'For x≠0, V_A(x)≥½||x||²>0.')
node('A3.SS4:unique-minimizer', 'substantive-unnamed-statement', ['A3.SS4.p2.1'],
     'The unique minimizer of V_A is 0.')
node('A3.SS4:Z-meaning', 'implicit-definition-convention', ['S1.p1.1','S4.SS1.p2.1','A3.SS4.p3.1','A3.Ex160'],
     'Z_A is the Gaussian normalizing constant for exp(−V_A). The conventional integral interpretation is ∫_{R^d}exp(−½xᵀAx) dx with respect to Euclidean Lebesgue measure.',
     status='SOURCE_IMPLICIT',
     audit_boundary='The selected raw source does not separately define the base measure or this integral. The displayed formula fixes the intended Lebesgue normalization; candidate phase must expose its actual Z definition and measure. Do not treat this interpretation as an additional explicit source premise.')
node('A3.SS4:gaussian-integral', 'unnamed-invoked-result', ['A3.SS4.p3.1','A3.Ex160'],
     'Gaussian integration for positive-definite real symmetric A gives Z_A=(2π)^{d/2}(det A)^{-1/2}.',
     classification='internal-paper-step', citation=None,
     detail='Explicitly invoked as Gaussian integration; no citation or proof is given here. It includes the analytic integrability/normalization prerequisite. It must remain an actual dependency of a combined normalizer claim.')
node('A3.SS4:det-conjugation', 'omitted-bridge', ['A3.Ex160'],
     'For every O in the full O(d), det(OΛOᵀ)=det Λ.', status='SOURCE_GAP',
     classification='internal-paper-step',
     gap='The equality is used in the second equality of Ex160 but not displayed separately or proved. Standard algebra: determinant multiplicativity, transpose invariance, and det(OᵀO)=1 give (det O)^2=1. Both det O=+1 and det O=−1 are allowed. No Gaussian integration is needed for this component by itself.')
node('A3.Ex160:normalizer-fixed-spectrum', 'reused-display-combined-claim', ['A3.Ex160'],
     'Z_A=(2π)^{d/2}(det A)^{-1/2}=(2π)^{d/2}(det Λ)^{-1/2}.',
     latex=r'Z_A=(2\pi)^{d/2}(\det A)^{-1/2}=(2\pi)^{d/2}(\det\Lambda)^{-1/2}')
node('A3.SS4:Z-independent-of-O', 'substantive-unnamed-conclusion', ['A3.SS4.p3.2'],
     'For fixed d,κ, Z_{OΛOᵀ} has the same value for every O∈O(d). This is pointwise invariance/constancy with respect to the eigenbasis; under the Haar experiment it is consequently a deterministic quantity.')
node('A3.SS4:Z-known-if-public', 'conditional-substantive-unnamed-conclusion', ['A3.SS4.p3.2'],
     'Whenever the fixed spectrum is public, Z_A is known from (2π)^{d/2}(det Λ)^{-1/2}. This is an informational conditional, not a statistical independence assumption or an extra source binder.')

edges = []
def use(key, parents, consumer, site, reason, condition=None, discharge=None):
    e=dict(id='edge:'+key, semantics='AND', prerequisites=[sid(x) for x in parents],
           consumer=sid(consumer), consumer_use_site=site, actual_use=reason)
    if condition:
        e.update(conditional_premise=condition, discharge=discharge)
    edges.append(e)
use('define-theta', ['S4:domain'], 'S4.E11:theta','S4.E11, angle definition',
    'The midpoint grid uses the fixed dimension and its 1,…,d index carrier.')
use('define-lambda', ['S4:domain','S4.E11:theta'], 'S4.E11:lambda','S4.E11, eigenvalue definition',
    'The literal affine cosine formula uses κ and the source midpoint angles.')
use('define-diagonal', ['S4.E11:lambda'], 'S4.E11:diagonal','S4.E11, diagonal-matrix definition',
    'Λ is formed from exactly the source list λ₁,…,λ_d.')
use('define-rotation', ['S4.E11:diagonal'], 'S4:rotation','S4.SS1.p1.2, set A clause',
    'A is the orthogonal conjugate of this fixed diagonal matrix, rather than an unrelated freely chosen spectrum.')
use('define-potential', ['S4:rotation'], 'S4:potential','S4.SS1.p1.2 and A3.SS4.p2.1, quadratic-potential definition',
    'The quadratic uses the source-defined precision A with coefficient 1/2.')
use('theta-grid', ['S4:domain','S4.E11:theta'], 'A3.SS4:angle','A3.SS4.p1.1, opening Since clause',
    'The literal i=1,…,d midpoint grid supplies strict interior angles.')
use('cos-interior', ['A3.SS4:angle'], 'A3.SS4:cosine','A3.SS4.p1.1, we have clause',
    'Strict cosine bounds on (0,π).')
use('affine-grid-bounds', ['S4:domain','S4.E11:lambda','A3.SS4:cosine'], 'A3.SS4:eigenvalue','A3.SS4.p1.1, and hence clause',
    'κ≥2 gives positive affine coefficient (κ−1)/2, preserving the strict inequalities.')
use('spectral-conjugation', ['S4.E11:diagonal','S4:rotation','S2:orthogonal','A3.SS4:eigenvalue'], 'A3.SS4:spectral-order','A3.SS4.p1.1, As A=OΛOᵀ clause',
    'Orthogonal conjugation preserves the quadratic-form spectral bounds.')
use('close-lemma46', ['A3.SS4:spectral-order'], 'S4.Thmtheorem6:admissibility','A3.SS4.p1.1 to S4.Thmtheorem6.p1.1',
    'The first proof paragraph supplies precisely the numbered lemma conclusion.')
use('symmetry-bridge', ['S4.E11:diagonal','S4:rotation'], 'A3.SS4:symmetry','A3.SS4.p2.1, Hessian A clause',
    'The transpose calculation gives Aᵀ=A because Λ is diagonal.')
use('positivity-bridge', ['A3.SS4:symmetry','S4.E11:diagonal','S4:rotation','S2:orthogonal','A3.SS4:eigenvalue'], 'A3.SS4:symmetric-positive','A3.SS4.p3.1 and Ex160, positive Gaussian precision prerequisites',
    'Derive the analytic/algebraic well-posedness facts internally; do not assume them publicly.',
    'Gaussian integral requires symmetric positive-definite precision.',
    {'status':'source-derived-but-detail-omitted','producer_nodes':[sid('A3.SS4:eigenvalue'),sid('S4:rotation')],'not_a_public_binder':True})
use('smooth-quadratic', ['S4:potential'], 'A3.SS4:smooth','A3.SS4.p2.1, is C∞ clause','A finite-dimensional quadratic polynomial is smooth.')
use('hessian-quadratic', ['S4:potential','A3.SS4:symmetry'], 'A3.SS4:hessian','A3.SS4.p2.1, with Hessian clause','Symmetry makes the Hessian of ½xᵀAx equal to A; positive definiteness is not needed for this derivative identity.')
use('strong-convexity-hessian', ['A3.SS4:hessian','A3.SS4:spectral-order'], 'A3.SS4:strong-convexity','A3.SS4.p2.1, Thus clause','The lower Hessian bound is I_d.')
use('smoothness-hessian', ['A3.SS4:hessian','A3.SS4:spectral-order'], 'A3.SS4:smoothness-bound','A3.SS4.p2.1, Thus clause','The upper Hessian bound is κI_d.')
use('value-at-zero', ['S4:potential'], 'A3.SS4:zero-value','A3.SS4.p2.1, Moreover clause','Evaluate the literal quadratic at 0.')
use('positive-away-zero', ['S4:potential','A3.SS4:spectral-order','S2:euclidean'], 'A3.SS4:quadratic-lower','A3.SS4.p2.1, V_A(x)≥½||x||²>0 clause','The lower matrix bound and x≠0 supply the two inequalities.')
use('minimizer', ['A3.SS4:zero-value','A3.SS4:quadratic-lower'], 'A3.SS4:unique-minimizer','A3.SS4.p2.1, so clause','0 has value 0, while every nonzero point has strictly positive value.')
use('gaussian-target-identification', ['S4:potential','A3.SS4:symmetric-positive'], 'S4:target','A3.SS4.p3.1, associated target clause','The quadratic precision A specifies the centered covariance A^{-1}.')
use('gaussian-normalization', ['A3.SS4:Z-meaning','S4:potential','A3.SS4:symmetric-positive'], 'A3.SS4:gaussian-integral','A3.SS4.p3.1 Gaussian integration gives; first equality in Ex160',
    'The unnamed standard Gaussian integral produces the value and establishes the required integrability.',
    'A must be real symmetric positive definite; Z must mean the unnormalized Lebesgue integral.',
    {'status':'source-derived/implicit-convention','producer_nodes':[sid('A3.SS4:symmetric-positive'),sid('A3.SS4:Z-meaning')],'not_a_public_binder':True})
use('det-invariance', ['S4:rotation','S2:orthogonal'], 'A3.SS4:det-conjugation','A3.Ex160, equality replacing det A by det Λ',
    'Orthogonal conjugation leaves the determinant unchanged; orthogonality supplies squared determinant 1, not determinant +1.')
use('combined-normalizer', ['A3.SS4:gaussian-integral','A3.SS4:det-conjugation'], 'A3.Ex160:normalizer-fixed-spectrum','A3.Ex160, entire equality chain',
    'Gaussian integration supplies the first equality, determinant invariance the second. These form an AND; determinant invariance alone does not establish the combined claim.')
use('fixed-spectrum', ['S4:domain','S4.E11:theta','S4.E11:lambda','S4.E11:diagonal'], 'S4:fixed-spectrum','S4.SS1.p2.1 first sentence; A3.SS4.p3.2 Since Λ is fixed',
    'The eigenvalues are fixed functions of d,κ rather than functions of O.')
use('normalizer-constancy', ['A3.Ex160:normalizer-fixed-spectrum','S4:fixed-spectrum'], 'A3.SS4:Z-independent-of-O','A3.SS4.p3.2, Z_A is independent of O clause',
    'The expression depends on fixed d,Λ only; it holds pointwise on full O(d).')
use('known-if-public', ['A3.Ex160:normalizer-fixed-spectrum','S4:fixed-spectrum','S4:public-spectrum'], 'A3.SS4:Z-known-if-public','A3.SS4.p3.2, known whenever the spectrum is public clause',
    'Public d and spectrum determine the displayed normalizing constant.',
    'The spectrum is supplied/public.',
    {'status':'conditional-retained','source_condition':sid('S4:public-spectrum'),'case_when_public':'condition supplied by experiment definition; not inferred from determinant equality','not_a_public_binder':False})
use('explain-early-assertion', ['A3.SS4:Z-known-if-public'], 'S4:known-Z-assertion','S4.SS1.p2.1, In particular sentence',
    'C.4 provides the mathematical reason for the earlier informal normalizer claim in the public-spectrum experiment.')

graph = dict(schema_version=1, artifact_kind='source-only-proof-graph', phase=1,
             actor='source-graph-486201', raw_source_sha256=EXPECTED,
             claim_status='extractor-proposed; independent raw-source coverage review pending; no Lean/source-completion credit',
             roots={'determinant_component':sid('A3.SS4:det-conjugation'),
                    'combined_normalizer':sid('A3.Ex160:normalizer-fixed-spectrum'),
                    'pointwise_normalizer_invariance':sid('A3.SS4:Z-independent-of-O'),
                    'conditional_known_normalizer':sid('A3.SS4:Z-known-if-public'),
                    'numbered_lemma_only':sid('S4.Thmtheorem6:admissibility')},
             nodes=nodes, edges=edges,
             alternative_routes={'semantics':'OR between sufficient routes only','source_routes_found':1,'or_hyperedges':[],
                                 'reason':'No alternative proof of this selected claim is stated in the raw source. The determinant algebra expansion and Gaussian integration are not alternative routes to a combined Z claim.'},
             graph_view='source/semantic overlay only; no compiler-backed Lean dependency claims',
             forbidden_inferences=['Haar independence from the algorithm is not a needed binder for pointwise determinant or Z invariance.',
                                   'Neither determinant sign is restricted to +1.',
                                   'The determinant component does not by itself establish Gaussian integration or integrability.',
                                   'The numbered Lemma 4.6 only states spectral admissibility; the additional C.4 claims remain unnamed source statements.',
                                   'No proof of Theorem 4.1, Krylov representation, target moments, oracle lower bound, source-V, or whole-paper completion is asserted.'])
dump('proof_graph', graph)

slots = {
    'objects':{
        'source':['d-dimensional real matrices O, Λ, A; midpoint angles θ_i and eigenvalues λ_i; quadratic potential f_A (V_A in C.4); target π_A=N(0,A^{-1}); Gaussian normalizer Z_A.'],
        'determinant_component':'det A and det Λ for A=OΛOᵀ.',
        'combined_normalizer':'Z_A of exp(−½xᵀAx), with conventional Euclidean Lebesgue normalization, and the displayed determinant expressions.',
        'anchors':['S4.E11','S4.SS1.p1.2','A3.SS4.p2.1','A3.Ex160']},
    'domains':{
        'source':['d∈Z, d≥2; κ∈R, κ≥2; i=1,…,d; x∈R^d; O∈full real O(d).'],
        'sign_scope':'Both det O=+1 and det O=−1. Source O(d) is not SO(d).',
        'bounds_scope':'Do not import κ≤d^{1−δ}, a sufficiently-large-d condition, query budget q, n<d, or ε from Theorem 4.1 or the neighboring moment/Krylov lemmas.',
        'anchors':['S2.p2','S4.SS1.p1.1','S4.Thmtheorem6']},
    'quantifiers':{
        'source':['Fix any admissible d,κ and hence the literal θ_i,λ_i,Λ. For every O∈O(d), form A=OΛOᵀ. The determinant equality, spectral bounds and displayed Z equality are pointwise in O.',
                   'The construction also draws O Haar independently of the algorithm seed. The universal algebraic/normalizer statements imply constancy in that experiment; they are stronger than an almost-sure-only formulation.',
                   'The word known is conditional: whenever the spectrum is public.'],
        'anchors':['S4.SS1.p1.2','S4.Thmtheorem6','A3.SS4.p3.2']},
    'assumptions':{
        'source':['Hard-family d≥2,κ≥2; literal Eq11 grid; A=OΛOᵀ; O orthogonal.'],
        'conditional':['Public spectrum for the informational known-normalizer claim.'],
        'derived_not_new_binders':['Interior angles and cosines; 1<λ_i<κ; positive definiteness/invertibility; determinant positivity; Gaussian integrability; determinant invariance.'],
        'experiment_only':['O Haar on full O(d), independent of algorithm private randomness. These describe the hard-family experiment and do not become necessary premises of a pointwise determinant invariant.'],
        'anchors':['S4.E11','S4.SS1.p1.1','S4.SS1.p1.2','A3.SS4']},
    'conclusion':{
        'determinant_component':'det(OΛOᵀ)=det Λ; no integration assertion follows from this component alone.',
        'combined_normalizer':'Z_A=(2π)^{d/2}(det A)^{−1/2}=(2π)^{d/2}(det Λ)^{−1/2}. Thus it is invariant under O for fixed d,κ and known if the spectrum is public.',
        'other_C4_conclusions':['I_d≼A≼κI_d; V_A∈C∞; ∇²V_A=A; V_A is 1-strongly convex and κ-smooth; 0 is its unique minimizer; target N(0,A^{-1}).'],
        'anchors':['S4.Thmtheorem6','A3.SS4.p1.1','A3.SS4.p2.1','A3.Ex160','A3.SS4.p3.2']},
    'scopes_senses':{
        'source':['The fixed-spectrum construction differs from the hidden-determinant-sign construction in Section 3 and Appendix B.',
                   'Normalizer independence of O means pointwise lack of eigenbasis dependence; it does not refer to the independence of O and the algorithm seed.',
                   'A is a precision matrix; A^{-1} is the Gaussian covariance. V_A and f_A use the same 1/2 quadratic convention.',
                   'Eq11 is a literal definition on its full index carrier, with θ at half-grid points. A zero-based formal index requires an explicit i↔i+1 translation.',
                   'Gaussian normalizer means the mass of the unnormalized Lebesgue density, not an integral with respect to the already normalized Gaussian law.',
                   'Known given public spectrum is informational, not a new numerical-approximation or query-complexity theorem.'],
        'definition_audit':{'theta_lambda_diagonal_A_potential':'literal','Gaussian_target':'source-defined Gaussian with precision A','Z':'implicit integral convention; actual candidate definition must be exposed in phase 2'},
        'anchors':['S2.SS0.SSS0.Px1','S4.E11','S4.SS1.p1.2','S4.SS1.p2.1','A3.SS4.p3.2']},
    'constant_dependencies':{
        'source':['The normalizer depends on fixed dimension d and the fixed eigenvalues λ₁,…,λ_d (and therefore κ via Eq11). It has no O dependence.',
                   'The exact prefactor is (2π)^{d/2}; the determinant exponent is −1/2. The quadratic potential has coefficient 1/2.',
                   'The admissibility/convexity constants are lower 1 and upper κ; angle grid spacing is π/d with midpoint shift 1/2.',
                   'There is no δ, ε, q, n, hidden universal C, or asymptotic constant in the determinant/normalizer identity.'],
        'anchors':['S4.E11','A3.SS4.p2.1','A3.Ex160']}}
assert len(slots)==7
dump('seven_slots',dict(phase=1,comparand='raw-source contract only; no candidate comparison yet',canonical_slots=slots))

contract = dict(schema_version=1,actor='source-graph-486201',phase=1,
 source={'title':'On Complexity of Gaussian Sampling','version':'arXiv:2610.20492v1','local_path':str(RAW.relative_to(ROOT)),
         'url':'https://arxiv.org/html/2610.20492v1','sha256':EXPECTED,'primary_anchors':['S4.E11','A3.SS4'],
         'numbered_statement_context':'S4.Thmtheorem6 (Lemma 4.6)',
         'raw_source_is_authoritative':True},
 status='PHASE1_FROZEN_SOURCE_ONLY; not candidate approval, not topology-reviewed, not source-complete',
 scope={'complete_selected_roots':['S4.SS1','S4.SS2.SSS0.Px4','A3.SS4'],
        'supporting_context_roots':['S2.p1','S2.p2','S2.SS0.SSS0.Px1','S4.p2','bib.bib3'],
        'main_claim_boundary':'The determinant invariance component used in Ex160 and the combined Gaussian integral/fixed-known-normalizer context; all of C.4 is inventoried.'},
 source_faithful_contract={
  'setup':'Let d≥2 be an integer and κ≥2 real. For i=1,…,d set θ_i=((i−1/2)π)/d, λ_i=(κ+1)/2+((κ−1)/2)cos θ_i, and Λ=diag(λ₁,…,λ_d). For every O∈O(d) set A=OΛOᵀ.',
  'determinant_component':'det A=det Λ for every O in full O(d), without restricting its determinant sign.',
  'normalizer_component':'For the quadratic V_A(x)=½xᵀAx and target N(0,A^{-1}), Gaussian integration gives Z_A=(2π)^{d/2}(det A)^{-1/2}=(2π)^{d/2}(det Λ)^{-1/2}.',
  'independence_and_known_spectrum':'For fixed d,κ, Λ is fixed. Hence Z_A is independent of O; if the spectrum is public it is known.',
  'pointwise_versus_randomized':'The hard-family experiment samples O from Haar(O(d)), independently of algorithm randomness. The relevant deterministic identities hold for every O, including both Haar components.',
  'Z_convention_limit':'The raw source names Gaussian normalization and states the standard formula but does not separately display the Lebesgue-integral definition. That meaning is source-implicit, and candidate phase must expose its exact definition.'},
 binder_classification=[
  {'item':'d integer, d≥2; κ real, κ≥2','class':'STANDING','source':'S4.SS1.p1.1'},
  {'item':'Literal θ, λ, Λ grid and A definition','class':'SOURCE','source':'S4.E11; S4.SS1.p1.2','note':'Definitions, not free producer witnesses.'},
  {'item':'O∈O(d), full group','class':'SOURCE','source':'S4.Thmtheorem6; S2.p2'},
  {'item':'Real Euclidean finite-dimensional carrier','class':'TYPING','source':'S2.p1; S2.p2'},
  {'item':'Spectrum public','class':'SOURCE','source':'A3.SS4.p3.2','note':'Only for conditional known-Z conclusion.'},
  {'item':'A positive definite; det equality; integrability; normalization formula','class':'DERIVED_DEPENDENCY_NOT_BINDER','source':'A3.SS4; A3.Ex160'},
  {'item':'Additional proof-ready determinant/normalizer certificates, det O=+1, external regularity assumptions','class':'EXCESS_IF_CANDIDATE_ADDS','source':'Not source premises; no candidate inspected.'}],
 definition_contract={'literal':['θ_i','λ_i','Λ','A','f_A/V_A'],
                      'whole_carrier':'i=1,…,d and x∈R^d; no fallback/default/conditional semantics are source-given.',
                      'not_characterized_choice':'The source does not introduce these matrices or grid values through a choose-if-exists fallback.'},
 source_omissions=[{'node':sid('A3.SS4:symmetry'),'kind':'omitted-elementary-transpose-bridge','new_assumption_allowed':False},
                   {'node':sid('A3.SS4:symmetric-positive'),'kind':'omitted-standard-bridge','new_assumption_allowed':False},
                   {'node':sid('A3.SS4:det-conjugation'),'kind':'omitted-standard-determinant-bridge','new_assumption_allowed':False},
                   {'node':sid('A3.SS4:gaussian-integral'),'kind':'explicitly-invoked-unnamed-standard-result-without-proof-or-citation','new_assumption_allowed':False},
                   {'node':sid('A3.SS4:Z-meaning'),'kind':'implicit-base-measure/normalizer-convention','new_assumption_allowed':False}],
 phase2_required_exposure=['Exact sealed statement text and its digest.','Only the recursively necessary meaning-carrying definitions, including actual grid indexing, matrix carrier, orthogonality predicate and any Z definition/base measure.','No implementation proof topology or prior verdicts are needed to compare these seven slots.'],
 exclusions=['No Gaussian integral theorem is certified or formalized by this extraction.',
             'No proof-worker/source-reviewer self-approval; independent topology/coverage review remains pending.',
             'No source-V, formal source completion, admissible query lower bound, or whole-paper credit.',
             'No candidate seal, Lean implementation, Tests, registries, frontier, source-prepared packet, old graph, previous review, or old prose was inspected.'])
dump('source_contract',contract)

roots=['S2.p1','S2.p2','S2.SS0.SSS0.Px1','S4.p2','S4.SS1','S4.SS2.SSS0.Px4','A3.SS4','bib.bib3']
unit_map={
 'S2.p1.1':['S2:euclidean'],'S2.p2.1':['S2:orthogonal','S2:haar'],
 'S2.SS0.SSS0.Px1.p1.1':['S2:precision-class'],'S2.Ex1':['S2:precision-class'],
 'S2.SS0.SSS0.Px1.p1.2':['S4:potential','S4:target'],
 'S4.p2.1':[],
 'S4.SS1.p1.1':['S4:domain','S4.E11:theta','S4.E11:lambda'],
 'S4.E11':['S4.E11:theta','S4.E11:lambda','S4.E11:diagonal'],
 'S4.SS1.p1.2':['S4:draw','S4:rotation','S4:potential','S4:target'],
 'S4.SS1.p2.1':['S4:fixed-spectrum','S4:public-spectrum','S4:known-Z-assertion','S4:hidden-eigenbasis'],
 'S4.Thmtheorem2.p1.1':[],
 'S4.SS2.SSS0.Px4.p1.1':['S4.Thmtheorem6:admissibility'],
 'S4.Thmtheorem6.p1.1':['S4.Thmtheorem6:admissibility'],
 'A3.SS4.p1.1':['A3.SS4:angle','A3.SS4:cosine','A3.SS4:eigenvalue','A3.SS4:spectral-order'],
 'A3.SS4.p2.1':['S4:potential','A3.SS4:smooth','A3.SS4:hessian','A3.SS4:strong-convexity','A3.SS4:smoothness-bound','A3.SS4:zero-value','A3.SS4:quadratic-lower','A3.SS4:unique-minimizer'],
 'A3.SS4.p3.1':['S4:target','A3.SS4:gaussian-integral'],
 'A3.Ex160':['A3.SS4:gaussian-integral','A3.SS4:det-conjugation','A3.Ex160:normalizer-fixed-spectrum'],
 'A3.SS4.p3.2':['S4:fixed-spectrum','A3.SS4:Z-independent-of-O','A3.SS4:Z-known-if-public']}
exclude_reason={
 'S4.p2.1':'Theorem 4.1 comparison/context: public-spectrum hardness is relevant context, but the theorem lower bound, ε,δ and κ≤d^{1−δ} restrictions are not premises or conclusions of this determinant/normalizer component.',
 'S4.Thmtheorem2.p1.1':'Remark 4.2 is neighboring prior-construction/oracle/ratio/lower-bound explanation. Its affine A₂ adapter, moment/Krylov statements and √κ log d conclusion are not used by C.4 or Ex160.',
 'S2.E1':'Exact first-order oracle equation is not used by the selected determinant/normalizer proof.',
 'S2.SS0.SSS0.Px1.p2.1':'Oracle equivalence and query complexities are outside this selected component.',
 'bib.bib3':'Bibliographic provenance for the similar construction, not a mathematical prerequisite invoked in C.4. No external preprint result is imported into the selected proof.'}
coverage=[]
fragments=[]
for rootid in roots:
    root=soup.find(id=rootid)
    fragments.append({'source_root':rootid,'start_line':line_of(rootid),'normalized_text':normalized(root),
                      'normalized_text_sha256':sha256(normalized(root).encode()).hexdigest(),
                      'parser_serialized_html_sha256':sha256(str(root).encode()).hexdigest(),
                      'serialization_note':'DOM serialization is a convenience extraction; authoritative bytes are the pinned whole raw source.'})
    selected=root.find_all(['p','table','h3','h5','h6','cite'])
    if root.name in ['p','table']: selected=[root]+selected
    if rootid=='bib.bib3': selected=[root]
    # Tables and paragraphs are nonoverlapping mathematical/text regions in these roots.
    for k,e in enumerate(selected):
        anchor=e.get('id') or rootid+':'+e.name+':'+str(k)
        keys=unit_map.get(anchor,[])
        is_cite=e.name=='cite'
        if is_cite:
            keys=[]
            reason='Citation [22, Section 9.2] is construction provenance. This source does not delegate the C.4 determinant/normalizer calculation to it.'
        elif e.name.startswith('h'):
            reason='Section/proof/lemma heading and cross-reference only; no separate mathematical assertion beyond the inventoried body.'
        elif keys:
            reason=None
        else:
            reason=exclude_reason.get(anchor,'Structural bibliography or neighboring statement outside this selected proof component.')
        entry={'source_root':rootid,'locator':anchor,'tag':e.name,'disposition':'NODE' if keys else 'EXCLUDED',
               'node_ids':[sid(x) for x in keys], 'normalized_text':normalized(e),
               'text_sha256':sha256(normalized(e).encode()).hexdigest()}
        if reason:entry['reason']=reason
        coverage.append(entry)
        # Every MathML source expression is inventoried, even in excluded regions.
        for m in e.find_all('math'):
            ma=m.get('id')
            if not ma: raise AssertionError('math without id')
            coverage.append({'source_root':rootid,'locator':ma,'tag':'math','parent_region':anchor,
                             'disposition':entry['disposition'],'node_ids':entry['node_ids'],
                             'formula_latex':m.get('alttext',''),'reason':reason,
                             'coverage_semantics':'Expression belongs to the fully covered parent region; multiple node ids preserve the distinct clause-level statements.'})
    # A lossless text-node inventory catches prose not inside numbered equations, p regions, or headings.
    for j,t in enumerate(root.descendants):
        if not isinstance(t,NavigableString) or not str(t).strip():continue
        if any(getattr(a,'name',None) in ['math','annotation'] for a in t.parents):continue
        owner=next((a for a in t.parents if a.name in ['p','table','h3','h5','h6','cite']),None)
        locator=(owner.get('id') if owner else None)
        if owner and not locator:
            # Heading and citation ids are resolved through their deterministic root-local selector order.
            for k,e in enumerate(selected):
                if e is owner: locator=rootid+':'+e.name+':'+str(k);break
        if rootid=='bib.bib3':locator=rootid
        if not locator:locator=rootid+':structural-text'
        keys=unit_map.get(locator,[])
        coverage.append({'source_root':rootid,'locator':rootid+':text-node:'+str(j),'tag':'text',
                         'parent_region':locator,'text':str(t),'text_sha256':sha256(str(t).encode()).hexdigest(),
                         'disposition':'NODE' if keys else 'EXCLUDED','node_ids':[sid(x) for x in keys],
                         'reason':None if keys else exclude_reason.get(locator,'Heading/citation/QED/structural wrapper or explicitly excluded neighboring region; no uncovered mathematical assertion.')})

# Full source-element inventory is deliberately separate from the clause graph:
# every C.4 DOM element belongs either to a substantive region or a structural exclusion.
elements=[]
for rootid in ['S4.SS1','S4.SS2.SSS0.Px4','A3.SS4']:
    root=soup.find(id=rootid)
    for j,e in enumerate([root]+list(root.find_all(True))):
        anchor=e.get('id') or rootid+':dom:'+str(j)+':'+e.name
        p=e if e.name in ['p','table'] else e.find_parent(['p','table'])
        region=p.get('id') if p else None
        keys=unit_map.get(region,[])
        elements.append({'source_root':rootid,'locator':anchor,'tag':e.name,'parent_region':region,
                         'disposition':'NODE' if keys else 'EXCLUDED','node_ids':[sid(x) for x in keys],
                         'reason':None if keys else exclude_reason.get(region,'Structural container/header/markup, or inherited excluded Remark 4.2 region; its substantive descendants are inventoried separately.')})
dump('raw_source_regions',{'raw_source_sha256':EXPECTED,'regions':fragments})
dump('coverage',{'raw_source_sha256':EXPECTED,'coverage_status':'extractor-proposed; no independent coverage approval',
                'scope_roots':roots,'regions_and_math_and_text_nodes':coverage,'full_selected_element_inventory':elements,
                'outside_slice_exclusions':[
                  {'anchors':['S4.Thmtheorem1','S4.SS3','S4.SS4'],'reason':'Theorem 4.1 lower bound, its testing proof and limitations are not proved by this determinant/normalizer component.'},
                  {'anchors':['S4.Thmtheorem3','S4.Thmtheorem4','S4.Thmtheorem5','A3.SS1','A3.SS2','A3.SS3'],'reason':'Krylov/Gram/moment leaves and proofs are distinct neighboring source obligations, not used at C.4.'},
                  {'anchors':['S3','A2'],'reason':'The hidden determinant-sign hard family and Appendix B Gaussian normalization cancellation concern a different construction; they are not prerequisites here.'}],
                'counts':{'nodes':len(nodes),'AND_use_edges':len(edges),'OR_route_edges':0,
                          'region_math_text_records':len(coverage),'selected_DOM_elements':len(elements)},
                'exhaustiveness_method':'Enumerate every p/table/heading/citation, every contained math alttext, every nonempty non-MathML text node in the selected roots; additionally enumerate every DOM element in all three complete selected roots. Each entry is NODE or EXCLUDED with reason. Unnamed C.4 statements are split into stable graph nodes.'})

instructions=[
 'AGENTS.md','CONTRIBUTING.md','.agents/prompts/collaborator-contribution.md',
 'docs/contributor-codex-contract.md','docs/theorem-publication-protocol.md',
 'docs/proof-digestion-protocol.md','docs/evidence-routed-memory-protocol.md',
 '.agents/skills/astis-substantive-advance/SKILL.md',
 '.agents/skills/astis-source-dependency-audit/SKILL.md',
 '.agents/skills/astis-semantic-roundtrip/SKILL.md',
 '.agents/skills/astis-proof-dag/SKILL.md','.agents/prompts/samplewiki-route.md',
 'docs/formalization-protocol.md','.agents/skills/astis-cross-library-coordination/SKILL.md',
 'LICENSE_SCOPE.md']
input_hashes=[{'path':str(RAW.relative_to(ROOT)),'sha256':EXPECTED,'kind':'pinned-primary-raw-source'}]
input_hashes.extend({'path':p,'sha256':sha256((ROOT/p).read_bytes()).hexdigest(),'kind':'repository-instruction'} for p in instructions)
exposure=dict(actor='source-graph-486201',phase=1,method='RAW_SOURCE_FIRST',
             exact_input_artifacts=input_hashes,
             source_exposure=['Raw HTML title and source search hits for determinant/normalization strings.',
                              'Normalized complete S2, S4 introductory direct children, S4.SS1, S4.SS2 and A3.SS4.',
                              'Raw lines 1068–1150, 1350–1385 and 4125–4225 (the latter includes nonmathematical arXiv footer).',
                              'Normalized S2.p1, S2.p2, S2.SS0.SSS0.Px1, S4.SS2.SSS0.Px4, S4.Thmtheorem6, bib.bib3 and A3.SS4.',
                              'Raw-source paragraph-only normalization/Z search printed S1.p1.1, S4.SS3.SSS0.Px2.p1.1, A1.SS1.p2.1, A2.SS2.p2.1, A2.SS2.SSS1.p1.1 and p2.2, A3.SS2.p3.1, A3.SS3.p1.1 and p9.1. These are source-only incidental context, not candidate exposure or imported dependencies.',
                              'Final artifact generation parses the exact raw-source roots recorded in coverage.'],
             instruction_discovery='Bounded filename-only discovery under .agents and selected ancestor AGENTS paths. No review/frontier/registry/proof history search.',
             forbidden_exposure={k:False for k in ['candidate_seal','candidate_Lean','implementation_proofs','Tests','root_prepared_source_packet','old_source_graphs','previous_reviews','candidate_prose','current_frontier','registry_implementations','prior_verdicts']},
             process_limits=['No target proof or API changes.','No ledger, shared aggregation, registry, publication, frontier or site changes.','No compiler/source-completion/source-V claim.','No sub-agent spawned; independent topology approval must be by another actor.'],
             tool_note='System python3 lacked bs4; used existing /opt/anaconda3/bin/python with bs4. No dependency installation or network retrieval.',
             output_paths=[str(OUT.relative_to(ROOT)),str(PRIVATE.relative_to(ROOT))])
dump('exposure',exposure)

report=r'''# Frozen phase-1 source extraction — source-graph-486201

This is a raw-source-first extraction of the determinant/known-normalizer context in *On Complexity of Gaussian Sampling*, arXiv:2610.20492v1, Eq. (11) and Appendix C.4. It is a proposed source proof graph, awaiting independent coverage review. No candidate statement, implementation, old graph or prior review was inspected. It confers no Lean, source-V or source-completion credit.

The raw input SHA-256 is `6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915`. The JSON artifacts bind the instructions, raw source, seven slots, complete selected source coverage and graph with hashes.

The source fixes an integer d≥2 and real κ≥2. For the literal indices i=1,…,d it defines

\[
\theta_i=\frac{(i-\tfrac12)\pi}{d},\qquad
\lambda_i=\frac{\kappa+1}{2}+\frac{\kappa-1}{2}\cos\theta_i,\qquad
\Lambda=\operatorname{diag}(\lambda_1,\ldots,\lambda_d).
\]

It draws O from Haar probability on the full real orthogonal group, independently of algorithm randomness, and sets A=OΛOᵀ. Both determinant components are included. For the pointwise statements, O is arbitrary in O(d). The Haar law and seed independence describe the experiment; they are not necessary public premises for determinant invariance.

The determinant component used in the second equality of Ex160 is det(OΛOᵀ)=det Λ. Its standard omitted algebra uses determinant multiplicativity, invariance under transpose and (det O)²=1. Replacing full O(d) by determinant +1 would narrow the source. The source does not state this determinant component as a separately numbered lemma.

The combined claim has two actual prerequisites. Gaussian integration supplies

\[
Z_A=(2\pi)^{d/2}(\det A)^{-1/2},
\]

and determinant invariance supplies its substitution by det Λ. Their use is an AND. A theorem proving only determinant invariance does not itself prove Gaussian integrability or the normalizer formula. Positive definiteness comes from the source grid and orthogonal conjugation; it belongs inside the proof as a dependency, rather than as a convenience public hypothesis.

Since Λ is fixed at fixed d,κ, the resulting Z_A is constant as O varies. When the spectrum is public it is known from the displayed expression. The first is pointwise eigenbasis invariance; the second retains the source's informational condition. Neither is the separate independence between O and algorithm randomness. Z_A conventionally means the Lebesgue mass of exp(−V_A), not an integral against the normalized Gaussian. The selected source does not separately define this base measure, so phase 2 must expose the candidate's actual normalizer definition before comparing meanings.

All of C.4 is covered, including its unnamed material. The first paragraph derives 0<θ_i<π, −1<cos θ_i<1, 1<λ_i<κ and I_d≼A≼κI_d. Only the last spectral bound is the numbered Lemma 4.6 conclusion. The second paragraph states smoothness, Hessian A, 1-strong convexity, κ-smoothness, V_A(0)=0, strict positivity away from 0, and the unique minimizer. The third identifies the target, invokes Gaussian integration, states the determinant equality chain and concludes fixed/public-spectrum normalization. Those statements have separate nodes and consumer-use edges.

The graph has no source-stated alternative sufficient proof route. In particular determinant algebra and Gaussian integration are not OR alternatives for the combined Z result. Omitted standard symmetry/positivity and determinant bridges remain marked SOURCE_GAP; Gaussian integration is an explicitly invoked unnamed result without a proof or citation here. These markers describe omitted source detail, not a claim that the source is false.

The coverage inventory includes every paragraph, display, heading, citation, MathML expression and nonempty text node in the selected source roots, with NODE or EXCLUDED disposition, plus a complete DOM-element inventory for S4.SS1, its admissibility subsection and C.4. Remark 4.2, the Krylov/moment lemmas, Theorem 4.1, oracle complexity, and the distinct hidden determinant-sign construction are explicitly excluded from this bounded component. The [22, §9.2] citation is provenance for a similar construction; C.4 does not invoke that external preprint for this calculation. Its content was not fetched.

Phase 1 stops here. Phase 2 may expose the exact sealed statement and only the definitions necessary to interpret it, then compare all seven frozen slots. This phase has not accepted a candidate, reviewed its proof, updated shared truth, or approved its own source coverage.
'''
(OUT/'source_graph_486201.phase1_report.md').write_text(report)

# Structural validation cannot replace the independent mathematical review.
ids={n['id'] for n in nodes}
assert len(ids)==len(nodes)
for e in edges:
    assert e['consumer'] in ids
    assert set(e['prerequisites'])<=ids
    assert e['semantics']=='AND' and e['consumer_use_site'] and e['actual_use']
for e in coverage+elements:
    assert e['disposition'] in ['NODE','EXCLUDED']
    assert set(e['node_ids'])<=ids
    if e['disposition']=='EXCLUDED':assert e.get('reason')
c4_math={m['id'] for m in soup.find(id='A3.SS4').find_all('math')}
assert c4_math<={r['locator'] for r in coverage if r['tag']=='math'}
assert all(r['disposition']=='NODE' for r in coverage if r['tag']=='math' and r['source_root']=='A3.SS4')
assert {r['locator'] for r in coverage if r['source_root']=='A3.SS4' and r['tag'] in ['p','table']}=={'A3.SS4.p1.1','A3.SS4.p2.1','A3.SS4.p3.1','A3.Ex160','A3.SS4.p3.2'}
validation={'kind':'structural-only','result':'PASS','raw_sha256_matches':True,'seven_slots_present':len(slots)==7,
            'all_graph_edge_endpoints_present':True,'all_coverage_entries_disposed':True,
            'C4_math_count':len(c4_math),'C4_all_math_covered_as_nodes':True,
            'C4_all_paragraphs_and_display_covered':True,
            'independent_mathematical_coverage_approval':False,
            'candidate_exposed':False,'source_completion_claim':False}
dump('structural_validation',validation)
artifact_paths=sorted(OUT.glob('source_graph_486201.*'))
manifest={'schema_version':1,'actor':'source-graph-486201','phase':1,
          'freeze_status':'FROZEN_BEFORE_CANDIDATE_EXPOSURE',
          'raw_inputs':input_hashes,
          'artifacts':[{'path':str(p.relative_to(ROOT)),'sha256':sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in artifact_paths],
          'private_generator':{'path':str((PRIVATE/'build_phase1.py').relative_to(ROOT)),'sha256':sha256((PRIVATE/'build_phase1.py').read_bytes()).hexdigest()},
          'stop_condition':'Do not expose candidate until this freeze is reported; phase 2 is separately authorized and appended without rewriting this phase-1 contract.',
          'limits':'Proposed raw-source graph only; not independently approved topology; no source-V or proof/source-completion claim.'}
mp=PRIVATE/'phase1-freeze-manifest.json'
mp.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
(PRIVATE/'phase1-freeze-manifest.sha256').write_text(sha256(mp.read_bytes()).hexdigest()+'  phase1-freeze-manifest.json\n')
print(json.dumps({'manifest':str(mp.relative_to(ROOT)),'manifest_sha256':sha256(mp.read_bytes()).hexdigest(),
                  'artifacts':len(artifact_paths),'nodes':len(nodes),'edges':len(edges),
                  'coverage_records':len(coverage),'DOM_elements':len(elements),'C4_math':len(c4_math),'validation':'PASS'},indent=2))
