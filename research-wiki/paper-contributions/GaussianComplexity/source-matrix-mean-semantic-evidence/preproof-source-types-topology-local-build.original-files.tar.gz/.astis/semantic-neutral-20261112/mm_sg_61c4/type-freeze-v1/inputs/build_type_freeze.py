from pathlib import Path
import hashlib,json,datetime,shutil
ROOT=Path('/Users/zhouhuanjian/ASTIS-GC');BASE=ROOT/'.astis/semantic-neutral-20261112/mm_sg_61c4'
RAW=BASE/'raw-freeze-v1';OUT=BASE/'type-freeze-v1'
PACKET=ROOT/'.astis/huanjian-gc-source-matrix-mean-20261112/selective-type-definition-packet.json'
def sha(b):return hashlib.sha256(b).hexdigest()
assert not OUT.exists()
pb=PACKET.read_bytes();assert sha(pb)=='efdba6eea9aa32da4cd9ea8d5022548ac128179f1ba73661fefa342f6ca4d95c'
p=json.loads(pb);rm=(RAW/'freeze-manifest.json').read_bytes();assert sha(rm)=='4daf44e6a41b758d624abc58eaa9ac78101c7d43e309fe5554fcac3dd40d2ac7'
for f in json.loads(rm)['files']:
 b=(RAW/f['path']).read_bytes();assert len(b)==f['bytes'] and sha(b)==f['sha256']
for k in ['producer','actual_private_consumer']:assert sha(p[k]['signature'].encode())==p[k]['signature_sha256']
c=p['minimal_definition_context'];assert sha(c['literal_current_prints_and_instances'].encode())==c['literal_current_prints_sha256']
for x in c['literal_definition_excerpts']:assert sha(x['literal_source'].encode())==x['literal_source_sha256']
assert p['statement_seal_sha256']=='b55a1acb837288d580a667903987e5f809610626eb4848c750ff8d3a6c01149b'
assert p['minimal_definition_context_sha256']=='92117d5029065dcbd8e1a218bb175a7c32d37e9dd34ac2f5255125e2f9c48cfa'
source=(RAW/'inputs/2610.20492v1.html').read_bytes();s=source.decode()
for x in p['source']['anchors']:
 b=source[x['raw_utf8_start']:x['raw_utf8_end']];assert sha(b)==x['span_sha256'];assert b==s[x['char_start']:x['char_end']].encode()
OUT.mkdir();(OUT/'inputs').mkdir()
def dump(n,v):(OUT/n).write_text(json.dumps(v,ensure_ascii=False,sort_keys=True,indent=2)+'\n',encoding='utf-8')
def write(n,t):(OUT/n).write_text(t,encoding='utf-8')
(OUT/'inputs/selective-type-definition-packet.json').write_bytes(pb);(OUT/'inputs/raw-freeze-v1.manifest.json').write_bytes(rm)
shutil.copyfile(BASE/'working/build_type_freeze.py',OUT/'inputs/build_type_freeze.py')
for k,n in [('producer','producer.signature.txt'),('actual_private_consumer','consumer.signature.txt')]:write('inputs/'+n,p[k]['signature'])
bind={'raw_freeze_manifest_sha256':sha(rm),'selective_packet_sha256':sha(pb),'statement_seal_sha256':p['statement_seal_sha256'],'producer_signature_sha256':p['producer']['signature_sha256'],'consumer_signature_sha256':p['actual_private_consumer']['signature_sha256'],'definition_context_sha256':p['minimal_definition_context_sha256'],'mathlib_pin':c['mathlib_pin']}
ba=[
 {'input':'d : Nat','class':'TYPING','audit':'Exact natural physical dimension.'},
 {'input':'q : Nat','class':'TYPING','audit':'Exact nonnegative query count, including q=0.'},
 {'input':'hq : 2*q+1<d','class':'STANDING','audit':'Exact Lemma4.4 standing source range. Positive d and r, nonzero denominators and admissible literal cosine frequencies are internal consequences.'},
 {'input':'All local lets','class':'NOT_A_LOGICAL_PREMISE','audit':'Literal fixed data definitions, not source input assumptions or theorem certificates.'},
 {'input':'Canonical real/Euclidean/finite matrix/probability and norm structures','class':'TYPING','audit':'Actual inferred standard structures supplied in the selective packet. No caller-chosen measure/norm/measurable-space or integrability/moment certificate.'}]
defs=[
 ('D,E','literal','Standard real Euclidean d- and r-spaces, r=q+1; no norm on the function-valued Omega is treated as Gaussian.'),
 ('Omega,mu','literal canonical experiment','r standard d-Gaussian column projections on their fixed finite product measure, matching the original-column experiment. No ambient extension or conditioning.'),
 ('row','literal','WithLp.toLp 2 assembles physical coordinate i.val+1 from all original columns b.val+1. WithLp.ofLp in Y reads those same coordinates.'),
 ('r,L','literal','Real r=q+1 and L=2r+3log(1000d), with exact constants and source natural-log meaning.'),
 ('a','literal canonical-law scalar','Integral of ||x||^2 on the closed ball ||x||^2<=L under stdGaussian E, divided by r. This is the canonical-law realization of the source (1/r)E[R_i1_(R_i<=L)]. Its equality to every physical-row retained-radius mean must be derived internally from the marginal law; a is not free data.'),
 ('theta','literal','((i.val+1)-1/2)pi/d. The half is real because the expression is in R. This is the source one-based half-grid.'),
 ('t','literal','Feature index0 is exactly1. For k=1,...,q, feature k is sqrt2*cos(k theta_i). q=0 gives a single constant feature.'),
 ('Y','literal','Closed actual-row cutoff; inside, inverse d times actual Gaussian outer product Kronecker literal deterministic t outer product; outside, zero. Source indicator semantics on the entire carrier, not an existence fallback.'),
 ('Matrix indices and identity','literal','r^2-by-r^2 real matrices, paired indices (Gaussian,feature) in both positions. Matrix identity is I_r or I_(r^2) as typed, not an all-ones matrix.'),
 ('Matrix norm/topology/completeness','standard actual instances','Supplied current prints identify the L2 operator norm from Euclidean-space operators and internally synthesized complete normed real matrix space. This agrees with a finite-dimensional real matrix expectation; proof transport through entries or CLMs remains an internal applicability obligation.'),
 ('Integrable','expanded standard target predicate','AEStronglyMeasurable plus finite integral of extended norm, with the almost-everywhere strongly measurable representative meaning supplied. Every actual-Y and both actual-sum integrability claims are outputs.'),
 ('Bochner integral','standard definition','Defaults to zero outside complete/integrable cases in the supplied literal definition. Matrix completeness is supplied and Y/sum integrability are explicit target conclusions, so their mean identities cannot earn credit from the default-zero branch. The scalar-a integrand integrability must also be discharged internally, even though it is not an additional public conclusion.'),
 ('Producer mean matrix','literal conclusion','E_mu[Y_i]=(a/d)(I_r tensor t_i t_i^T). Correct scalar action and Gaussian-first paired order.'),
 ('Private consumer sums','literal conclusions','The same actual Y_i on the same Omega,mu are summed with weights1 and exactly cos((2q+1)theta_i). The four outputs are integrability of both sums, integral of unweighted sum=a I_(r^2), integral of weighted sum=0.')]
audit={'version':1,'phase':'EXACT_TYPE_AUDIT_FROZEN_BEFORE_POST_SEAL_GRAPH','bindings':bind,'source_root_full_path':str(BASE),
 'verdict':'NO_GENUINE_TYPE_BINDER_DEFINITION_OR_SOURCE_SCOPE_ISSUE_FOUND','genuine_target_issues':[],
 'actor':'/root/row_indep_source_graph_78c2','role':'Independent of formalizer for this type/source audit; not a source-blind decoder and not an independent checker of own raw coverage.',
 'binder_audit':ba,'EXCESS_public_binders':[],'definitions':[{'object':o,'kind':k,'audit':a,'meaning_match':True} for o,k,a in defs],
 'source_match':{'producer':'Actual Ex107 integrability (source-implicit well-definedness) and per-row mean at p12.4 from Ex108.',
 'consumer':'Exact actual integrals of the two finite sums, a source-supported linearity expansion of Ex110 sums of individual expectations and the p12.5 weighted-sum expectation conclusion.',
 'extra_public_inputs':'None','extra_source_result_claims':'No a-range/bias estimate, joint/iid independence, PSD, centered variance, concentration or main lower bound.'},
 'q_zero':'Retained. r=1,n=1,t_i=(1),d>=2; producer mean is scalar a/d; expected aggregate is a and expected cosine-weighted aggregate zero.',
 'semantic_slots':{'objects':'Same actual physical rows and literal truncated Y matrices from one original-column product sample.',
 'domains':'Natural d,q; 2q+1<d; finite real Euclidean vectors and r^2 square matrices.',
 'quantifiers':'All admissible d,q; all physical i in producer; actual full finite sums in consumer. All experiment objects are fixed lets.',
 'assumptions':'Only natural typing and source standing range. All law, moment, integrability, CLM and sum-exchange obligations remain internal.',
 'conclusion':'All Y integrable with exact means; both actual sums integrable and their actual Bochner expectations aI/0.',
 'scopes_and_senses':'One fixed canonical mu throughout; no merely formal sum of supplied means, surrogate/conditioned model or ambient transfer.',
 'constants':'Literal r,L,a definition, one-based midpoint theta, sqrt2 features, inverse d, n=2q+1. No tau,kappa,C.'},
 'internal_obligations_not_source_gaps':['Actual physical-row marginal-law applicability and measurable map transport.','Canonical retained-radius integrability and radial outer-product mean applicability.','Actual matrix integrability in the synthesized L2 operator norm.','Continuous-linear-map/tensor expectation transport and source-scalar identification.','Literal cosine-frame identities and finite Bochner exchange with deterministic weights.'],
 'genuine_SOURCE_GAPs':[],
 'compiled_parent_claims':[],'new_target_proof_seen':False,'new_API_search_performed':False,
 'topology_state':'Not yet constructed in this type freeze. A later versioned source graph must bind this immutable type verdict.',
 'permission_or_status_grant':False}
dump('type-audit.json',audit)
write('type-meaning-verdict.md','No genuine mismatch or EXCESS public premise was found. The producer returns actual Y integrability and per-row means; the private consumer returns integrability and Bochner expectations of the two actual finite sums. The literal coefficient a is a canonical-law retained-radius integral and must be identified with the source actual-row coefficient internally. The matrix L2 operator norm and completeness are explicit standard context. Bochner default-zero cannot supply credit in place of the stated integrability outputs; scalar-a integrability also remains internal. All row-law, radial-moment, integral/CLM/tensor transport and finite-exchange applicability work is unproved. This source/type verdict is frozen before any post-seal graph construction. No proof, theorem status or permission is granted.\n')
dump('input-exposure-record.json',{'bindings':bind,'raw_before_type':'raw-freeze-v1 was fully written, made read-only and integrity-checked before opening this selective packet.',
 'new_input':str(PACKET.relative_to(ROOT)),'formalizer_API_pristine':False,
 'formalizer_exposure_disclosure':'Parent explicitly discloses known canonical row-law/radial-moment/cosine-frame nodes and exact preseal standard-definition lookup incidental API/header/proof-fragment exposure. This is not hidden or labelled pristine. This actor did not open those API/proof files.',
 'actor_prior_exposure':'Earlier R7 source/type context is disclosed in raw-freeze-v1 input-exposure record. No old graph/audit/verdict was reopened in this mean-packet phase.',
 'new_target_implementation_or_API_search':False,'read_allowlist':'New selective packet, own frozen mean raw source/protocols/artifacts, own new output only.',
 'digest_checks':'Packet, exact signature UTF-8 strings, supplied literal print/excerpt strings, source anchors and every raw manifest file independently rehashed. Seal/context identifiers are supplied labels bound by verified packet bytes; their separate underlying serializations were not supplied and are not independently rehashed here.',
 'no_grants':'No permission, proof, graph/topology acceptance, ledger status or publication acceptance.'})
write('README.md','Independent post-seal type/source verdict frozen BEFORE graph construction. Read type-audit.json. No graph artifact is included here. Raw mean reading remains immutable, and old R7 files were not reopened or changed.\n')
m={'format':'astis-mean-type-freeze-v1','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'bindings':bind,'phase':'TYPE_VERDICT_BEFORE_GRAPH','files':[]}
for f in sorted(OUT.rglob('*')):
 if f.is_file():b=f.read_bytes();m['files'].append({'path':str(f.relative_to(OUT)),'bytes':len(b),'sha256':sha(b)})
dump('freeze-manifest.json',m);digest=sha((OUT/'freeze-manifest.json').read_bytes());write('freeze-manifest.sha256',digest+'  freeze-manifest.json\n')
for f in OUT.rglob('*'):
 if f.is_file():f.chmod(0o444)
for d in sorted([d for d in OUT.rglob('*') if d.is_dir()],key=lambda d:len(d.parts),reverse=True):d.chmod(0o555)
OUT.chmod(0o555)
print(json.dumps({'type_freeze_path':str(OUT),'type_audit_sha256':sha((OUT/'type-audit.json').read_bytes()),'type_manifest_sha256':digest,'raw_manifest_sha256':sha(rm),'target_issues':[]},indent=2))
