from pathlib import Path
import subprocess,sys,json,datetime,hashlib
ROOT=Path(__file__).resolve().parent;REPO=ROOT.parents[2]
label=sys.argv[1];argv=sys.argv[2:];started=datetime.datetime.now(datetime.timezone.utc).isoformat()
r=subprocess.run(argv,cwd=REPO,capture_output=True);out=ROOT/'commands';out.mkdir(exist_ok=True)
for ext,raw in [('stdout',r.stdout),('stderr',r.stderr)]:(out/(label+'.'+ext)).write_bytes(raw)
rec={'label':label,'argv':argv,'cwd':str(REPO),'started_utc':started,'ended_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'returncode':r.returncode,'stdout_bytes':len(r.stdout),'stderr_bytes':len(r.stderr),'stdout_sha256':hashlib.sha256(r.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(r.stderr).hexdigest(),'script_inputs':[{'path':x,'sha256':hashlib.sha256((REPO/x).read_bytes()).hexdigest()} for x in argv if x.endswith('.py') and (REPO/x).is_file()]}
(out/(label+'.receipt.json')).write_text(json.dumps(rec,indent=2)+'\n')
sys.stdout.buffer.write(r.stdout);sys.stderr.buffer.write(r.stderr);print(json.dumps(rec),file=sys.stderr);sys.exit(r.returncode)
