from pathlib import Path
from contextlib import redirect_stdout
import io,runpy,json,re,hashlib
base=Path('.astis/semantic-neutral-20261110/cg_tc_8f2b60/phase1')
buf=io.StringIO()
with redirect_stdout(buf): env=runpy.run_path(str(base/'audit_reader.py'))
(base/'raw-06-reader-replay-output.txt').write_text(buf.getvalue())
raw=env['raw']; soup=env['soup']; parser=env['p']
keys=[]
for parent_id in ['S4.SS1','S4.SS2.SSS0.Px1','S4.SS2.SSS0.Px2','A3.SS2']:
 t=soup.find(id=parent_id);keys.append(parent_id)
 for child in t.find_all(id=True):
  key=child['id'];cls=child.get('class',[])
  if any(c in cls for c in ['ltx_para','ltx_theorem','ltx_proof']) or re.fullmatch(r'(?:A3|S4)\.(?:Ex|E)\d+',key):keys.append(key)
meta=[]
for key in dict.fromkeys(keys):
 a,z=parser.spans[key];fragment=raw[a:z].encode()
 meta.append({'id':key,'byte_start':len(raw[:a].encode()),'byte_end_exclusive':len(raw[:z].encode()),'line_start':raw.count('\n',0,a)+1,'line_end':raw.count('\n',0,z)+1,'sha256':hashlib.sha256(fragment).hexdigest(),'bytes':len(fragment)})
(base/'source-spans-complete.json').write_text(json.dumps(meta,indent=2)+'\n')
out=json.dumps({'source_anchor_count':len(meta),'replayed_reader_stdout_bytes':len(buf.getvalue().encode()),'new_source_text_displayed':False},indent=2)+'\n';(base/'raw-06-span-completion-output.txt').write_text(out);print(out)
