from pathlib import Path
import json,hashlib,sys,datetime,subprocess
sys.dont_write_bytecode=True
sys.path.insert(0,'tools')
import astis_advance as adv
W=Path('.astis/huanjian-gc-fixed-spectrum-signal-strength-20261110')
E=Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-signal-strength-semantic-evidence')
C=Path('research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-signal-strength.json')
L=Path('runs/substantive_advances.jsonl')
ADV='ASTIS-SA-20261110-GaussianComplexityFixedSpectrumSignalStrength'
OWNER='huanjian_gc_20261110_fixed_spectrum_signal_strength'
sha=lambda b:hashlib.sha256(b).hexdigest()
dump=lambda x:(json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode()
def ref(p):
    p=Path(p);return {'path':str(p),'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size}
def put(p,b):
    assert not p.exists(),p
    p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
f=Path(sys.argv[1]);expected=sys.argv[2]
assert sha(f.read_bytes())==expected
j=json.loads(f.read_bytes())
assert j['outstanding_HOLDs']==[]
assert j['permission_for_future_target_proof_and_mathematical_API_retrieval'] is True
assert datetime.datetime.now(datetime.timezone.utc)>=datetime.datetime.fromisoformat(j['effective_from_utc'])
sp=W/'statement-seal-v1.json'
assert sha(sp.read_bytes())=='8a560b9d9ec883324957551dc1eee9aae106736c9c545d919830844e43016c04'
s=json.loads(sp.read_bytes())
prod=s['producer']['planned_file'];test=s['actual_private_consumer']['planned_file'];name=s['producer']['name']
assert not Path(prod).exists() and not Path(test).exists() and not C.exists() and not E.exists()
assert not (W/'StatementFormation.lean').exists()
b=json.loads((W/'intake-baseline-after-prior-packet-carry.json').read_bytes())
before=L.read_bytes();assert sha(before)==b['ledger_sha256']
states=adv._replay_advances([json.loads(x) for x in before.splitlines()])
assert states==b['all_SAU_states'] and ADV not in states
assert states['ASTIS-SA-20261110-GaussianComplexityFixedSpectrumModeGap']['state']=='VERIFIED'
assert not [k for k,v in states.items() if v['state']=='STABILIZING']
for p,h in b['all_frontier_hashes'].items():assert sha(Path(p).read_bytes())==h,p
for p,h in b['protected_shared_hashes'].items():assert sha(Path(p).read_bytes())==h,p
inputs=[]
for directory,freeze,fs in [
  (Path('.astis/semantic-neutral-20261110/sg_41e7c9'),'phase1_freeze.json','69372fb70615bbc7cc6ddc0fe9a6baa96177126d2eb67647882d19626ca67509'),
  (Path('.astis/semantic-neutral-20261110/sg_41e7c9/phase2_c34b8a'),'phase2_freeze.json','956452028bad9e1892f1af17bd20f68b59adea53302f8c4f56cd19e527f6deeb'),
  (Path('.astis/semantic-neutral-20261110/sg_41e7c9/phase2_v2_a91d3f'),'phase2_v2_freeze.json','6b7301e30d01ec763c3b53468ba9cf3a930014d45f49512090fe63cdf223a261')]:
    fp=directory/freeze;assert sha(fp.read_bytes())==fs;inputs.append(ref(fp))
    for row in json.loads(fp.read_bytes())['files']:
        p=directory/row['path'];raw=p.read_bytes();assert len(raw)==row['bytes'] and sha(raw)==row['sha256'];inputs.append(ref(p))
T=Path('.astis/semantic-neutral-20261110/tc_b903a7')
for filename,fs in [
  ('phase1-freeze-manifest.json','a647b8bbcf6ecb63780c0e71a2acd11a6db5be9d08703e4ac0d902fe72e69a42'),
  ('phase2a-statement-freeze-manifest.json','833febd839fcd2da0bf7aa283e170b6ab75ef8702ba5a196c0b2b93637843a9e'),
  ('phase2b-graph-freeze-manifest.json','304a90c3bba0ac5e8892b1cc62b84834e980e784c62589af76d51e17d2c0b8de'),
  ('phase2b-v2-graph-freeze-manifest.json','a7b81b833216d8ff0c3cb7ea0ae70cbddd1701cca863e55eea996d84426f91b8')]:
    p=T/filename;assert sha(p.read_bytes())==fs;inputs.append(ref(p))
inputs.append(ref(f));inputs=list({r['path']:r for r in inputs}.values())
boundary='; '.join(s['scope_boundary'])
grant={'scope':'Prospective new exact target proof/API admission ONLY after distinct mathematical source graph v2 and separate process admission. No pristine informal-planning chronology, no proof success/sourceV/global authority.','observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exact_seal':ref(sp),'independent_process_admission':ref(f),'independent_math_inputs':inputs,'prospective_target_Lean_proof_API_allowed_after_this_grant':True,'root_sole_mathematical_worker':True,'target_Lean_proof_or_new_API_retrieval_before_this_grant':False,'preseal_and_postseal_informal_planning_retained':True,'source_graph_predecessor_H1_H2_preserved_and_resolved_only_in_v2':True,'no_own_STAB_global_or_new_Goal_authority':True}
put(W/'root-preproof-admission-grant.json',dump(grant))
put(E/'preproof-source-admission.json',dump(grant))
sealpublic=Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-signal-strength-statement-seal.json')
put(sealpublic,sp.read_bytes())
for src,dst in [('producer-signature.txt','producer.signature.lean.txt'),('consumer-signature.txt','consumer.signature.lean.txt'),('preseal-exposure-disclosure.json','preseal-exposure-disclosure.json'),('postseal-informal-planning-exposure.json','postseal-informal-planning-exposure.json')]:
    put(E/dst,(W/src).read_bytes())
old=json.loads(Path('research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-mode-gap.json').read_bytes())
searched=['Samplinglib/ASTIS exact proposed declaration and filename inventory in AutoSamplingTheory,Tests and frontier cells: no exact target name/module match before seal. This is not a semantic/generic API absence claim.','Mathlib/generic Samplinglib proof/API retrieval deferred until this admitted EXPLORING event. Known canonical Gaussian/ModeGap spine is prior verified context, not a new proof or a premise certificate.']
cell={'schema_version':3,'cell_id':C.stem,'route':'samplewiki-route','mode':'faithfulPaper','title':'Actual Gaussian norm and normalized-bias signal strength in the uniform source query regime','source_anchor':'arXiv2610.20492v1 S4.SS3.SSS0.Px2.p1-.2; S4.Ex24 signal branch; C3; private zero-threshold actual-law application only','target_statement':s['producer']['signature'],'status':'claimed','owner_id':OWNER,'advance_id':ADV,'parents':[],'consumers':['Sealed PRIVATE actual diagonal Gaussian signed-zero-event probability at most1/10 in the original fixed-delta/condition/query regime; not yet proved.','Concrete-tau shifted detector and both main lower bounds remain open.'],'shared_floor_audit':{'searched':searched,'classification':'adapt','decision':'adapt_existing','canonical_declaration':name,'canonical_shared_cell':'','notes':'Reuse actual canonical Gaussian source nodes when genuinely called; planned source topology is not emitted compiled dependency. Search exact generic APIs after admission.'},'reuse_plan':{'searched_existing':searched,'reused_declarations':[],'new_shared_declarations':[],'known_consumers':[],'planned_consumers':['actual_gaussian_source_query_zero_event_le_tenth: genuine actual-law finite probability via internally proved uniform strength, not a numerical wrapper.'],'no_duplicate_wrapper':True,'decision_reason':'New actual M lower and M beta squared bound, with an actual finite-event probability consumer. No assumed moment, signal, gap, growth or law certificate.'},'reader_contract':old['reader_contract'],'graph_contribution':{'lean_view':'new-node','overview_view':'no-change-with-reason','functor_view':'none-found','edge_semantics':'formal-solid; overlays-dashed','color_semantics':'evidence-status; library-scope','focus_targets':[name],'visual_review':'Preproof statement/source topology only; no compiled or UI/source-index/graph acceptance.'},'source_detail_audit':{'primary_edition':'arXiv2610.20492v1','primary_anchor':'S4.SS3.SSS0.Px2.p1-.2; S4.Ex24 signal branch; A3.SS3','detail_status':'omitted','gap':'Actual M positivity/lower estimates, beta positivity, power product and real probability consumer remain internal proof obligations; no extra public binder may replace them.','consulted':[{'source':'Pinned S2/S4/C3 plus independently frozen generic-source graph v2 and different-role topology challenge','anchor':'Unnamed M lower bounds and signal branch of Ex24; private zero-event is non-Anchor adaptation','hypothesis_adapter':'Exact0<delta<1,2<=kappa<=d^(1-delta),Natq and q<=(delta/256)sqrt(kappa)logd; one existential natural threshold before all varying scalars. Actual inverse-precision Gaussian, actual Bochner means and beta=abs(b)/M; no tau,algorithm,TV,cost or moment/gap certificates.'}],'fidelity_boundary':boundary},'learning_contract':{'control_plane_math_authority':False,'process_memory_checked':True,'process_memory_ids':old['learning_contract']['process_memory_ids'],'failure_class':'NONE','salvage':{'required':True,'status':'completed','reason':'No mathematical proof attempt yet. Original source-graph H1/H2 and raw0043 refinement retained, resolved only in v2 and independently re-reviewed. Informal planning exposure retained; process admission is prospective only.','promoted_fragments':[],'discarded_fragments':[]},'parallelism':{'decision':'serial','direction_fingerprints':[],'expected_information_gain':'Root is sole mathematical proof worker; independent source/topology/decoder/native roles resolve distinct uncertainties. Foreign original-owner STAB remains occupied.','shared_verified_context_digest':s['producer']['signature_sha256']},'cross_route_blind_spot_audit':{'required':False,'status':'not-applicable','evidence':'','canonical_route':'','selection_reason':'No parallel proof routes.'},'reader_backpressure':{'purification_status':'pending','exposition_seal_status':'pending','exposition_evidence':'','source_expansion_nodes':[],'lean_expansion_nodes':[],'assumptions_preserved':True,'boundary_preserved':True}},'statement_seal':{'path':str(sealpublic),'sha256':sha(sp.read_bytes()),'signature_sha256':s['producer']['signature_sha256'],'status':'EXACT_STATEMENTS_AND_SOURCE_GRAPH_V2_INDEPENDENTLY_ADMITTED_PROSPECTIVELY_NO_TARGET_PROOF_YET'},'source_proof_coverage':{'preproof_admission':ref(E/'preproof-source-admission.json'),'internal_obligations_still_unproved':s['internal_dependencies_not_extra_binders'],'source_gaps_are_not_public_assumptions':True,'private_consumer_non_Anchor':True},'evidence':{'execution_boundary':boundary,'focused_checks':[],'preproof_source_admission':str(E/'preproof-source-admission.json'),'actual_consumer_seal':s['actual_private_consumer'],'independent_verification':'','root_build':'','graph_regeneration':'','pr':'','process_order_exposure':str(E/'postseal-informal-planning-exposure.json')},'blocked':{'reason':'','children':[]}}
p=adv.AdvanceProposal(advance_id=ADV,task_id='ASTIS-SW-GAUSSIAN-COMPLEXITY-2026',goal='Prove actual Gaussian uniform source norm/signal-strength lower bounds, consumed by a genuine private zero-threshold probability estimate.',source_anchor=cell['source_anchor'],theorem_delta=s['producer']['signature'],truth_boundary=boundary,created_by=OWNER,dag_inputs=('source:arXiv2610.20492v1:S4.3 unnamed M bounds/Ex24 signal branch','canonical:actual Gaussian moments/means/bias and uniform mode-gap spine; no assumed result certificates'),proposed_files=(prod,test,str(C),'website/content/declaration_lessons/huanjian-fixed-spectrum-signal-strength.json','website/content/publications/huanjian-fixed-spectrum-signal-strength.json'),focused_checks=('lake env lean '+prod,'lake build Tests.GaussianComplexityFixedSpectrumSignalStrength'),modes=('source-reading','proof-design','compiler-diagnosis'),priority=50,frontier_cell=C.stem,target_declarations=(name,))
p.validate();adv.propose_advance(p)
adv.transition_advance(ADV,'CLAIMED',worker_id=OWNER,evidence={'exact_statement_seal':ref(sp),'preproof_admission':ref(E/'preproof-source-admission.json'),'truth_boundary':boundary})
adv.transition_advance(ADV,'EXPLORING',worker_id=OWNER,evidence={'preproof_admission':ref(E/'preproof-source-admission.json'),'target_Lean_proof_API_starts_after_this_event':True,'preseal_and_postseal_informal_planning_retained':True,'no_pristine_zero_planning_claim':True,'no_own_STAB_authority':True,'truth_boundary':boundary})
C.write_bytes(dump(cell))
after=L.read_bytes();assert after.startswith(before);app=after[len(before):];assert len(app.splitlines())==3
new=adv._replay_advances([json.loads(x) for x in after.splitlines()])
assert new[ADV]['state']=='EXPLORING' and {k:v for k,v in new.items() if k!=ADV}==states
for p,h in b['all_frontier_hashes'].items():assert sha(Path(p).read_bytes())==h,p
for p,h in b['protected_shared_hashes'].items():assert sha(Path(p).read_bytes())==h,p
put(E/'normal-EXPLORING-append.exact.jsonl',app)
put(E/'normal-intake-preservation.json',dump({'normal_API_calls':3,'state':'EXPLORING','advance_id':ADV,'owner':OWNER,'append_sha256':sha(app),'foreign_SAU_states_preserved':len(states),'foreign_frontiers_preserved':len(b['all_frontier_hashes']),'no_own_STAB':'Actual main/live original-owner lane remains occupied; local empty is not authority.','no_target_proof_sourceV_or_Goal_credit':True}))
print(json.dumps({'state':'EXPLORING','append_sha256':sha(app),'foreign_states_preserved':len(states),'foreign_frontiers_preserved':len(b['all_frontier_hashes']),'sourceV_or_proof_credit':False}))
