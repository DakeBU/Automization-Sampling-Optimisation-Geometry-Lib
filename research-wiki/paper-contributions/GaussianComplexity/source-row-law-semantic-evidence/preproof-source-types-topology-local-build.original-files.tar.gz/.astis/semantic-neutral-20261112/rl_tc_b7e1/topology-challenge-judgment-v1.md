# Independent bounded topology challenge v1

Verdict: ACCEPTED BOUNDED TOPOLOGY, WITH EXPLICIT UNPROVED PORTS.
No blocking source-topology gap was found in the exact raw/typed SG artifacts.
This is a distinct mathematical source-coverage/topology judgment. It grants no
proof, compiled-dependency status, source-VERIFIED status, publication acceptance,
process permission, or authorization to change a statement.

My raw-source freeze and type-only freeze both preceded SG exposure and remain
byte-for-byte unchanged. The exact SG input hashes are recorded in
`topology-challenge-exposure-v1.json`; all match the assigned identities.

## Coverage challenge

I independently re-enumerated the contiguous raw Appendix C.2 heading-through-p11
interval and found all 145 atoms: 23 paragraphs, 94 math elements, and 28 display
containers (15 tables and 13 id-bearing tbody components). The inventory gives
19 NODE and 126 EXCLUDED dispositions with explicit scope reasons. The typed
coverage retains every original atom and disposition. I independently checked
all 196 supplied locators against pinned raw UTF-8 bytes, fragment hashes,
Unicode character intervals, and source start/end lines; no mismatch occurred.

The first, nonfrozen integrity diagnostic used a narrower table-only matcher
and reported 13 valid tbody displays as extras. Direct raw-tag inspection
resolved that local matcher issue; the preserved v2 integrity result accounts
for all 145 atoms. This was not a source-coverage defect.

P1 is split correctly: the actual row construction and fixed-row marginal
component are in scope; deterministic cosine/tensor material and the stronger
printed joint-row independence claim remain excluded. P2-p9 and Facts C.5/C.6
have explicit exclusions. P11's shifted tail and integrated bias are preserved
with exact locators and excluded as separate obligations. Markov's named,
unlinked external input is represented. The single bounded linked reference is
the heading's pointer to Lemma4.4. Source-wide norm/dimension/range context is
recorded without importing the final tau<=1/2 hypothesis.

## Source topology and exact consumer

The raw source route has the right direction: original independent Gaussian
columns plus actual row coordinates -> omitted coordinate/product-law bridge ->
actual fixed-row standard Gaussian marginal -> omitted canonical Gaussian
exponential integral and actual-row expectation -> source Markov tail -> unnamed
cutoff substitution -> unnamed finite bad-row union -> exact good-event
complement -> printed p10 probability. Both SOURCE_GAP labels identify omitted
standard derivations, not a false source or a proposed repair.

The source use sites are precise: row law at p1.2; moment/Markov at p10.1 and
p10.m3; strict tail at Ex104; good event at Ex105; printed probability at p10.3
and p10.m6. I additionally checked the raw p17 text for the graph's context edge:
on T the original and truncated sums agree, followed by the separate
0.001+0.004 error combination. That edge records a later consumer of T while
preserving all matrix/concentration obligations as excluded. It gives this
packet no concentration credit.

There is no false AND combining alternative proof routes, reversed source
consumer edge, or dependence of the finite union on full joint row independence.
The exact source all-good event is the preferred consumer anchor; the equivalent
strict any-bad upper bound is openly labeled a source-supported unnamed bridge.

## Typed ports and semantic safeguards

The typed graph's 12 dependency/meaning edges are reviewed individually in
`topology-challenge-judgment-v1.json`. Both MeasurePreserving fields are output
obligations. Product-column realization, coordinate-law transport, canonical
exponential integrability and moment, actual-row integral transport, strict tail,
cutoff, union and complement remain unproved ports. The graph does not pretend
that definition prints or inferred probability instances certify any target.
No exact compiled exponential-moment dependency statement was supplied, so no
applicability verdict or proof edge is being certified.

The literal tuple space, product probability measure, and row map are shared by
producer and consumer. All rows in the global event use the same omega. Norm
square is the source sum of q+1 actual coordinate squares. q=0 is retained,
giving r=1 and d>=2. The source cutoff is exactly
L=2r+3log(1000d). The good event is <=L; its exact complement is some row >L.
The source constant is exactly999/1000, embedded as a positive finite ENNReal.
No atom-free-boundary hypothesis or row-independence premise is needed for this
consumer.

Some typed context nodes bundle more definitions than a minimal mathematical
prerequisite would need (for example the cutoff/event node also carries row
Euclidean/dimension meaning). Their edges are explicitly dependency/meaning
ports, not assertions of mathematical necessity. In particular, stochastic
independence is not being asserted necessary for measurability, and L is not
being asserted necessary for canonical exponential integrability. This bundling
creates no false alternative-route conjunction or extra theorem binder.

## Retained boundary

The exact target is the canonical iid-column realization. Application in an
arbitrary alternate or extended source probability space needs its own joint
column-law and event transport. The current graph states that scope correctly.
Full joint-row independence is a separate stronger source claim and cannot be
recovered merely from the producer's family of marginal laws. p11 bias,
truncated matrices, concentration, full Lemma4.4, main theorem, oracle and cost
remain separate. Acceptance here is of the bounded source topology and open-port
placement only.
