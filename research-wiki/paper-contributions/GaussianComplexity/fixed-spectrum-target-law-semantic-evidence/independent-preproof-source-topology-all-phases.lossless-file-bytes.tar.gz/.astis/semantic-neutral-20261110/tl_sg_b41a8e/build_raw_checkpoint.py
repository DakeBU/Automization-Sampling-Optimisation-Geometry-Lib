"""Re-pin raw source and reuse immutable own source graph; no type/API reads."""
from pathlib import Path
from datetime import datetime,timezone
import sys,importlib.util,json,hashlib
sys.dont_write_bytecode=True
REPO=Path('/Users/zhouhuanjian/ASTIS-GC')
OWN=Path(__file__).parent
OLD=REPO/'.astis/semantic-neutral-20261110/d_sg_48e2c0'
spec=importlib.util.spec_from_file_location('raw_html_extractor',OLD/'extract_source.py')
x=importlib.util.module_from_spec(spec);spec.loader.exec_module(x)
sha=lambda b:hashlib.sha256(b).hexdigest()
def dump(name,data):(OWN/name).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
basep=OLD/'phase2c_tc_b1_successor/source_graph_v2.json'
baseb=basep.read_bytes();assert sha(baseb)=='a3d876092b9854614c6d09bba8f1fa4add8d772ba030fa2358526b9c55ac6449'
base=json.loads(baseb)
prior_inventory=json.loads((OLD/'coverage_inventory.json').read_text())
oldrows={(r['byte_start_inclusive'],r['byte_end_exclusive']):r for r in prior_inventory['items']}
scopes=['S4.SS1.p1','S4.SS2.SSS0.Px3','A3.SS3','A3.SS4.p1','A3.SS4.p3']
snips=[];rows=[];readable=[]
local_outside={'sg:target-bias','bg:C3-mu-sum','bg:C3-variance','bg:C3-bias-ratio','bg:C3-logrho','bg:C3-bias-bound'}
for sid in scopes:
 n=x.PARSER.ids[sid];b=x.raw_slice(n);a=len(x.TEXT[:n.start].encode());z=a+len(b)
 assert b==x.RAW[a:z]
 fn='selected_snippets/'+sid+'.html';(OWN/fn).write_bytes(b)
 snips.append({'source_id':sid,'file':fn,'byte_start_inclusive':a,'byte_end_exclusive':z,'bytes':len(b),'sha256':sha(b),'selection':'Complete original DOM element.'})
 readable.append('SOURCE_ID '+sid)
 for e in [n,*x.descendants(n)]:
  if e.tag not in {'p','table','h2','h3','h4','h5','h6'}:continue
  eb=x.raw_slice(e);ea=len(x.TEXT[:e.start].encode());ez=ea+len(eb)
  prior=oldrows[(ea,ez)];assert sha(eb)==prior['raw_sha256']
  r=dict(prior)
  r['selected_root_role']=('outside norm-mean root; preserved substantive sibling output' if r.get('node') in local_outside
   else 'source statement packages multiple outputs; norm-mean selector explicit in source_root_map.json' if r.get('node') in {'sg:target-moments','bg:C3-C8','bg:C3-assemble','bg:C3-means'}
   else 'normalizer context, not sufficient Gaussian-law proof' if r.get('node')=='bg:C4-normalizer'
   else 'source/context for fixed-O law and norm mean' if r['disposition']=='NODE' else 'explicit inherited exclusion')
  rows.append(r);readable.append((e.attrs.get('id') or e.tag)+'\n'+x.normalized(e)+'\n')
dump('selected_snippets/index.json',{'raw_source_sha256':sha(x.RAW),'snippets':snips})
(OWN/'selected_source_readable.txt').write_text('\n'.join(readable))
dump('coverage_checkpoint.json',{'status':'RAW_SOURCE_CHECKPOINT_UNREVIEWED','scope':scopes,
 'base_inventory':str((OLD/'coverage_inventory.json').relative_to(REPO)),
 'base_inventory_sha256':sha((OLD/'coverage_inventory.json').read_bytes()),
 'policy':'Every selected paragraph/display/heading retains exact original NODE/EXCLUDED disposition and byte hash. Source sibling coverage does not make it a necessary parent of the selected root.',
 'items':rows,'counts_are_not_mathematics':True})

bridges=[
 {'id':'tl:bg-Gaussian-linear-law','classification':'AUTHOR_INVOKED_STANDARD_BACKGROUND; SOURCE_GAP_GENERAL_PROOF',
  'use_site':'S4.SS2.SSS0.Px3.p2.1','inputs':['fixed full orthogonal O','actual Y~N(0,A^-1)','Gaussian linear transformation rule','covariance inverse/conjugation algebra'],
  'output':'O^T Y~N(0,Lambda^-1); forward inverse-map formulation gives (O)_#N(0,Lambda^-1)=N(0,A^-1)',
  'source_boundary':'Author explicitly asserts the specialized law, but does not prove or attach an exact external citation for the general Gaussian transformation rule here. No library proof credit.'},
 {'id':'tl:bg-inverse-conjugation','classification':'IMPLICIT_STANDARD_MATRIX_ALGEBRA',
  'use_site':'S4.SS2.SSS0.Px3.p2.1','inputs':['A=O Lambda O^T','O^T O=O O^T=I','positive/invertible Lambda,A'],
  'output':'O^T A^-1 O=Lambda^-1 and A^-1=O Lambda^-1 O^T','source_boundary':'Required covariance adapter, not a scalar reciprocal substitution and not a new supplied theorem premise.'},
 {'id':'tl:bg-norm-isometry','classification':'SOURCE_ASSERTED_SPECIALIZATION; GENERAL_ALGEBRA_UNEXPANDED',
  'use_site':'S4.SS2.SSS0.Px3.p2.1','inputs':['same orthogonal O','U=O^T Y'],
  'output':'||Y||^2=||U||^2, or ||O z||^2=||z||^2 for all z','source_boundary':'No nonzero restriction or normalized weights. No Gaussian law needed for the pointwise identity.'},
 {'id':'tl:bg-Gaussian-second-moment','classification':'AUTHOR_USED_STANDARD_BACKGROUND; GENERAL_PROOF_OMITTED',
  'use_site':'A3.SS3.p4.1 / A3.Ex140','inputs':['actual U~N(0,Lambda^-1)','positive lambda_i','finite Gaussian second moments'],
  'output':'E U_i^2=1/lambda_i and E||U||^2=sum_i 1/lambda_i','source_boundary':'The source uses this Gaussian fact; does not prove its general law/coordinate-moment theorem. Fourth moments are not a needed input to this norm-mean selector.'},
 {'id':'tl:bg-expectation-transport','classification':'IMPLICIT_STANDARD_MEASURE_BACKGROUND',
  'use_site':'S4.SS2.SSS0.Px3.p2.1 last sentence','inputs':['actual law identity','measurable orthogonal map','norm-square integrability/finite second moment','pointwise norm identity'],
  'output':'Actual target norm mean equals latent Gaussian norm mean M','source_boundary':'Expectation under a law/pushforward and finite real integral are mathematical bridges, not old constructor/API evidence.'},
 {'id':'tl:bg-Gaussian-integration','classification':'NAMED_STANDARD_BACKGROUND',
  'use_site':'A3.SS4.p3.1 / A3.Ex160','inputs':['positive definite A','Gaussian normalization integral','orthogonal determinant invariance'],
  'output':'Z_A=(2pi)^(d/2)det(A)^(-1/2)=(2pi)^(d/2)det(Lambda)^(-1/2)',
  'source_boundary':'Normalizer context alone does not establish Gaussian linear-image law or norm mean.'}
]
dump('standard_background_and_gaps.json',bridges)

rootmap={
 'status':'RAW_SOURCE_ONLY_BEFORE_NEW_EXACT_TYPES','base_graph':str(basep.relative_to(REPO)),
 'base_graph_sha256':sha(baseb),'old_graph_mutations':False,
 'source_selector_policy':'Reuse existing source nodes; add precise sub-output selections/background granularity without rewriting full author graph.',
 'selected_source_roots':[
  {'id':'tl:fixed-O-law','source_node':'sg:target-coordinate-transfer','anchor':'S4.SS2.SSS0.Px3.p2.1',
   'output':'Actual target/latent Gaussian law relationship at the same fixed full O; forward and backward coordinate descriptions.'},
  {'id':'tl:latent-norm-sum','source_node':'bg:C3-means','anchor':'A3.SS3.p4 / Ex140 first equality',
   'output':'M=E||U||^2=sum_i 1/lambda_i',
   'selector':'Norm sum only; separate from series interchange and cosine sibling.'},
  {'id':'tl:latent-norm-mean','source_node':'bg:C3-M-sum','anchor':'A3.SS3.p5 / EGx15',
   'output':'M=(d/sqrt(kappa))(1-varrho^(2d))/(1+varrho^(2d))',
   'selector':'Refines the norm sum to its exact value; no sibling mu_n, variance or normalized-bias output is required.'},
  {'id':'tl:target-norm-mean','source_node':'sg:target-coordinate-transfer','anchor':'S4.SS2.SSS0.Px3.p2.1 last sentence',
   'output':'Under actual pi_A, E||Y||^2=M by law recognition, orthogonal norm identity and expectation transport.'}
 ],
 'source_use_hyperedges':[
  {'id':'tl:e-law','logic':'AND','premises':['sg:grid11','sg:hard-rotation','bg:C4-spectrum','tl:bg-inverse-conjugation','tl:bg-Gaussian-linear-law'],
   'consumer':'tl:fixed-O-law','consumer_use_site':'S4.SS2.SSS0.Px3.p2.1',
   'consumed_outputs':'Same literal A/Lambda and fixed orthogonal O; actual centered target covariance; inverse/covariance transport and general Gaussian image rule.',
   'premise_selection':'From sg:hard-rotation consume fixed A and target only, not Haar/algorithm experiment.'},
  {'id':'tl:e-norm-sum','logic':'AND','premises':['sg:grid11','tl:bg-Gaussian-second-moment'],
   'consumer':'tl:latent-norm-sum','consumer_use_site':'A3.SS3.p4.1 / Ex140 first M equality',
   'consumed_outputs':'Positive diagonal covariance and finite coordinate second moments; finite sum norm identity. No variance/fourth-moment sibling needed.'},
  {'id':'tl:e-exact-M','logic':'AND','premises':['tl:latent-norm-sum','bg:C3-C7','bg:C3-grid-alias'],
   'consumer':'tl:latent-norm-mean','consumer_use_site':'A3.SS3.p5 / EGx15',
   'consumed_outputs':'Inverse-spectrum absolutely convergent expansion; constant-mode grid aliases; geometric sum yielding finite-grid M formula.',
   'semantics':'Sequential source evaluation of the norm sum using the displayed geometric summation at p5; not an alternative OR proof and not a claim that bg:C3-M-sum is proved in Lean.'},
  {'id':'tl:e-target-mean','logic':'AND','premises':['tl:fixed-O-law','tl:bg-norm-isometry','tl:latent-norm-mean','tl:bg-expectation-transport'],
   'consumer':'tl:target-norm-mean','consumer_use_site':'S4.SS2.SSS0.Px3.p2.1 last sentence',
   'consumed_outputs':'Actual law identity, all-vector norm equality and latent M; real expectation transport with integrability.'}
 ],
 'consumer_use_backlinks':[
  {'producer':'tl:latent-norm-sum','consumer':'tl:latent-norm-mean','edge':'tl:e-exact-M','consumed_output':'Norm mean as finite inverse-eigenvalue sum, whose value is evaluated by the cosine-grid calculation.'},
  {'producer':'tl:fixed-O-law','consumer':'tl:target-norm-mean','edge':'tl:e-target-mean','consumed_output':'Actual target/latent Gaussian law, not arbitrary named measure.'},
  {'producer':'tl:latent-norm-mean','consumer':'tl:target-norm-mean','edge':'tl:e-target-mean','consumed_output':'Finite latent norm mean, and exact M value when selected.'}],
 'parameter_and_zero_boundary':{
  'd':'integer >=2','kappa':'real >=2','O':'same fixed member of full real O(d), including determinant -1',
  'n':'1<=n<d belongs to joint Lemma4.5 cosine statement; M-only C.3.p4–p5 derivation has no n dependence.',
  'bias_gap':'d-n>=sqrt(kappa) is a sibling bias condition, not a norm-law premise.',
  'zero':'All vectors allowed; no division by vector norm or strict-event boundary in this selected law/norm root.',
  'measure':'Actual mathematical N(0,Lambda^-1) and N(0,A^-1); no new library constructor/type is exposed in this phase.'},
 'sibling_region_policy':'All read cosine/variance/bias/normalizer regions retain source NODE or explicit roadmap/heading EXCLUDED dispositions in coverage_checkpoint.json; outside a selected root does not mean absent from source.',
 'no_OR_routes':'One author coordinate/moment route. Forward/backward law reexpressions are not alternative proofs.',
 'separation':{'source_math':'Recorded source claims/uses and unexpanded necessary background',
  'compiler_library_implementation':'Not inspected for this packet; no such edges claimed',
  'old_type_exposure':'Recorded as prior exposure only, not source authority'},
 'independent_review':'PENDING','proof_status':'NO_PROOF_CREDIT'}
dump('source_root_map.json',rootmap)

exposure={
 'phase':'NEW_PACKET_PHASE1_RAW_SOURCE_ONLY','actor_reused':True,'fresh_blindness_claim':False,
 'current_actual_inputs':[
  {'path':str(x.SOURCE.relative_to(REPO)),'bytes':len(x.RAW),'sha256':sha(x.RAW),'semantic_scopes':scopes},
  {'path':str(basep.relative_to(REPO)),'bytes':len(baseb),'sha256':sha(baseb),'scope':'Own source graph only, relevant selected mathematical nodes/edges.'},
  {'path':str((OLD/'coverage_inventory.json').relative_to(REPO)),'sha256':sha((OLD/'coverage_inventory.json').read_bytes()),'scope':'Own raw-byte NODE/EXCLUDED records for exact new selected spans.'},
  {'path':str((OLD/'extract_source.py').relative_to(REPO)),'sha256':sha((OLD/'extract_source.py').read_bytes()),'scope':'Own frozen pure HTML parser utility; bytecode writing disabled.'}],
 'prior_cognition':[
  'Repository AGENTS/proof-digestion/evidence-routed instructions and full selected old source §4.1–4.3/C.1–C.4.',
  'Own source raw cognition and graphs v1/v2; prior TC-B1 mathematical feedback read in its authorized earlier phase; not reread now.',
  'Old Detector exact matrix-Chebyshev producer/private pushforward-event consumer signatures and projection audit metadata.',
  'Old Mathlib literal definitions for multivariateGaussian, Chebyshev.T, aeval, matrix inverse, full orthogonalGroup/unitaryGroup and Measure.map.',
  'Previously disclosed accidental adjacent Mathlib proof/API text exposure, including wide Measure.map locator results. Not forgotten, not new source evidence.',
  'Current task reports an unseen new Prop-only seal/probe lifecycle and old postproof-window closure; not inspected and not mathematical evidence.'],
 'history_refs_not_reread':[
  {'path':str((OLD/'phase1_manifest.json').relative_to(REPO)),'sha256':'71d3bf703026ca41943bf19af1212a1eabfd72c02a6d1fe2fe72b8d7c11521cc'},
  {'path':str((OLD/'phase2/phase2_manifest.json').relative_to(REPO)),'sha256':'030c8a767d484f3058e241df7819ab11100a6527c87585dfbf9055333852a8e1'},
  {'path':str((OLD/'phase2c_tc_b1_successor/manifest.json').relative_to(REPO)),'sha256':'e8ffaddc00efd34595467c75cb9880bb805d3c5168c14c767f705b785ed3f9c6'}],
 'not_read_now':['New seal/exact types','New or old verdict files','Mathlib/API/library proof search','target Lean/Tests/implementation','root plans/process/exposure','foreign raw cognition or work'],
 'mutations':'Only new owned tl_sg_b41a8e directory; no old artifacts, tracked/global/frontier/API state touched.',
 'authority':'Raw source scope/coverage/consumer-relation checkpoint only; pause before exact types.'}
dump('actual_inputs_and_prior_exposure.json',exposure)
dump('raw_source_review_packet.json',{
 'phase':'RAW_SOURCE_CHECKPOINT_ONLY','source_scopes':scopes,'source_sha256':sha(x.RAW),
 'read_whitelist':['selected_snippets/index.json','selected_snippets/*.html','coverage_checkpoint.json','source_root_map.json','standard_background_and_gaps.json',str(basep.relative_to(REPO))],
 'base_graph_sha256':sha(baseb),
 'withhold':['raw_source_cognition.md','actual_inputs_and_prior_exposure.json','old/new verdicts','old/new exact types','all implementation/API/proof material'],
 'next_step':'Pause for parent-authorized exact types; independent topology/statement review remains pending.',
 'authority':'No counts-based mathematical claim; general Gaussian transformation rule is explicit unproved background/source gap.'})
dump('artifact_integrity_checks.json',{'raw_source_pin_matched':True,
 'complete_selected_snippets_match_original_bytes':True,
 'every_selected_region_matches_old_raw_span_hash_and_disposition':True,
 'all_NODE_targets_exist_in_unchanged_base_graph':all(r.get('node') in {n['id'] for n in base['nodes']} for r in rows if r['disposition']=='NODE'),
 'old_source_graph_sha256_rechecked':sha(basep.read_bytes()),
 'counts_do_not_establish_mathematics':True,'independent_source_review':'PENDING','proof_credit':False})
print(json.dumps({'source_pin':sha(x.RAW),'scopes':scopes,'old_graph_unchanged':sha(basep.read_bytes())==sha(baseb),'new_types_read':False,'proof_credit':False}))
