from hashlib import sha256
from pathlib import Path
import json
import os
import shlex
import subprocess
import sys

out = Path(__file__).resolve().parent
repo = out.parents[2]
candidate = '1baba1dd32bb79b66a541251f5a16ae6fdc54076'
blobs = out / 'blobs'
proof = 'AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumTruncatedRadialMoment.lean'
consumer = 'Tests/GaussianComplexityFixedSpectrumTruncatedRadialMoment.lean'
modules = [
    'AutoSamplingTheory/TechnicalLemmas/Measure/RadonNikodym.lean',
    'AutoSamplingTheory/TechnicalLemmas/Measure/IsotropicGaussianDensity.lean',
    'AutoSamplingTheory/TechnicalLemmas/Probability/StdGaussianRadialExponential.lean',
    'AutoSamplingTheory/TechnicalLemmas/Probability/StdGaussianMoment.lean',
    proof,
    consumer,
]
base = 'research-wiki/paper-contributions/GaussianComplexity/'
seal_path = base + 'truncated-radial-moment-statement-seal.json'
map_path = base + 'truncated-radial-moment-semantic-evidence/source-lean-map.exposition-v2.json'
slug = 'huanjian-gaussian-truncated-radial-moment'
inputs = modules + [
    'lean-toolchain', 'lake-manifest.json', seal_path, map_path,
    'website/content/declaration_lessons/' + slug + '.json',
    'website/content/publications/' + slug + '.json',
]
expected = {
    map_path: '1ed9bc2099bbfef9e2d46ee8bf1b20c701514a8e3ab1c30c310423e87c0a7e8a',
    proof: 'f0f1a83f03793d1c3619a91980f3969d8fa09f579d617a3bb8ec295320fabffd',
    consumer: 'd9820c4438e058c12e7bd1a08dc32704bd6bbd192c0522f8c9edbca7e62ae944',
    'lake-manifest.json': 'b83ca83b9cf7caa85fa8b023c2ff9a3fb7a7cce7e1c332e810c348535ec49c37',
}


def run(args, cwd=repo, env=None):
    print(shlex.join(map(str, args)), f'[cwd={cwd}]', flush=True)
    proc = subprocess.run(args, cwd=cwd, env=env, capture_output=True)
    if proc.stderr:
        sys.stderr.buffer.write(proc.stderr)
        sys.stderr.flush()
    print(f'exit={proc.returncode}', flush=True)
    proc.check_returncode()
    return proc.stdout


def write_blob(path):
    content = run(['git', 'cat-file', 'blob', f'{candidate}:{path}'])
    target = blobs / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(content)
    digest = sha256(content).hexdigest()
    assert path not in expected or digest == expected[path], (path, digest)
    return digest


def audit_source():
    return {path: write_blob(path) for path in inputs}

