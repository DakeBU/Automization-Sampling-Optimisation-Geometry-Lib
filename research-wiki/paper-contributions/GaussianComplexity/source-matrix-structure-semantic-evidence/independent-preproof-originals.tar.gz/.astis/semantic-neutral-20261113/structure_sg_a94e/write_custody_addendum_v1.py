from pathlib import Path
import datetime, hashlib, json
OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[2]
refs={
 '.astis/semantic-neutral-20261113/structure_tc_b7c6/MANIFEST.v1.json':'4e62f4a27e831b3ecbfbf5ae047b015301aca6ab875cb85f8924a14bc22ce2f4',
 '.astis/semantic-neutral-20261113/structure_tc_b7c6/custody/path-clarification.v1.json':'8fcbc30042ce616abacfcdbefdecf244bfa88d7db7e54966c83b1907992e28b6',
 '.astis/semantic-neutral-20261113/structure_tc_b7c6/phase2/FINAL-MANIFEST.json':'bbf3bd3d69be736c26867484ee4bc055ac54ac865303e5d1e55a97cfaac52dd3'}
for p,h in refs.items():assert hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==h
preserve={
 'SUCCESSOR-MANIFEST.v3.json':'240cc65c718dbbb5ed5d1863a6c740ed2f99e74b89835730326ed431be4c54a6',
 'tc-response.v3.json':'38c968b231b8c4d1055212ef02497507e36e037cd89b2397bac12906dc81ec80',
 'source-graph.source-only.v3.json':'9242c7792704cb38a213905baee8cd074b286d5ead153b27defa3d65676cf182',
 'source-coverage.source-only.v3.json':'91ebd82a04303bbdc0551bf646accb6d92cd1d986d841741fc1a7d364fa07eb7',
 'internal-obligation-ports.v3.json':'e006fead44edfb7cccaebd0870789d2eb0a2252b0c25508609378db909b33618'}
for p,h in preserve.items():assert hashlib.sha256((OUT/p).read_bytes()).hexdigest()==h
d={'version':'custody-addendum-v1','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'scope':'Provenance-only role/path clarification; no graph, coverage, port, statement, mathematical, or review-decision change.',
 'clarifies':'tc-response.v3.json / manifest_path_discrepancy',
 'correct_TC_output_manifest':{'path':next(iter(refs)),'sha256':refs[next(iter(refs))],'role':'TC output manifest at TC task root; this is the manifest the parent intended to cite.'},
 'TC_own_custody_clarification':{'path':list(refs)[1],'sha256':refs[list(refs)[1]]},
 'copied_SG_input_manifest':{'path':list(refs)[2],'sha256':refs[list(refs)[2]],'role':'Copy of the SG input FINAL-MANIFEST.json in the TC phase2 input area; it is not the TC output manifest.'},
 'history':'The parent previously grouped MANIFEST.v1.json under phase2. That exact path was absent; the failed read was preserved. This addendum corrects the path and file role. The original parent-provided digest4e62 matches the actual task-root TC manifest. No original recorded file or review decision is rewritten.',
 'preserved_byte_exact_v3_files':preserve,
 'review_boundary':'Distinct TC may bind this addendum to its exact v3 re-review. The extractor makes no topology/source/normalV approval claim.'}
p=OUT/'custody-addendum.v1.json'
assert not p.exists()
p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'path':str(p.relative_to(ROOT)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'preserved_v3_files_verified':preserve},indent=2))
