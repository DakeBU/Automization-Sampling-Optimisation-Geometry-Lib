import AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumSourceMatrixVariance
import AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumSourceMatrixMean
noncomputable section
open MeasureTheory ProbabilityTheory
open scoped BigOperators Matrix Kronecker Matrix.Norms.L2Operator
variable (q d : ℕ)
#synth Norm (Matrix (Fin (q + 1) × Fin (q + 1)) (Fin (q + 1) × Fin (q + 1)) ℝ)
#synth Norm (EuclideanSpace ℝ (Fin (q + 1)))
#synth Norm (Matrix (Fin (0 + 1) × Fin (0 + 1)) (Fin (0 + 1) × Fin (0 + 1)) ℝ)
#synth NormedSpace ℝ (Matrix (Fin (q + 1) × Fin (q + 1)) (Fin (q + 1) × Fin (q + 1)) ℝ)
#print WithLp.toLp
#print WithLp.ofLp
#print Matrix.vecMulVec
#print Matrix.kroneckerMap
#check Measure.pi
#check stdGaussian
