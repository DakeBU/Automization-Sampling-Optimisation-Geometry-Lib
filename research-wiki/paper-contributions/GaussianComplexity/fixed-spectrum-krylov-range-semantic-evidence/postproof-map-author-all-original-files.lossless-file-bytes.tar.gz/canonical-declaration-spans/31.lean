lemma inner_toLp_toLp (x y : ι → 𝕜) :
    ⟪toLp 2 x, toLp 2 y⟫ = dotProduct y (star x) := rfl
