from pathlib import Path
import hashlib,json,sys
sys.dont_write_bytecode=True
sys.path.insert(0,'tools')
import astis_publication as pub
import astis_semantic_roundtrip as rt
P=Path('.astis/huanjian-gc-fixed-spectrum-moments-20261109/cosine-expansion')
E=Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-cosine-expansion-semantic-evidence')
S=json.loads(Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-cosine-expansion-statement-seal.json').read_bytes())
sha=lambda x:hashlib.sha256(x.encode() if isinstance(x,str) else x).hexdigest()
def put(p,x):
    p=Path(p);assert not p.exists(),p
    p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
name=S['producer']['name'];file=Path(S['producer']['planned_file']);test=Path(S['actual_private_consumer']['planned_file'])
sig=S['producer']['signature'];csig=S['actual_private_consumer']['signature']
assert file.read_text().split('theorem actual_inverse_spectrum_cosine_expansion',1)[1].split(' := by',1)[0] == sig.split('theorem actual_inverse_spectrum_cosine_expansion',1)[1].rstrip()
assert test.read_text().split('private theorem actual_inverse_grid_cosine_series',1)[1].split(' := by',1)[0] == csig.split('private theorem actual_inverse_grid_cosine_series',1)[1].rstrip()
focus=Path('.astis/huanjian-resume-20261103/20261109T055101900464Z-cosine-expansion-actual-private-grid-with-pi-import-v2.receipt.json')
kernel=Path('.astis/huanjian-resume-20261103/20261109T055316561702Z-cosine-expansion-actual-kernel-and-sealed-types-v2.receipt.json')
for q in [focus,kernel]:
    r=json.loads(q.read_bytes());assert r['exit_code']==0 and sha(Path(r['log']).read_bytes())==r['log_sha256']
klog=Path(json.loads(kernel.read_bytes())['log']).read_text()
assert 'ACTUAL_PRIVATE_SEALED_LITERAL_KERNEL_TYPE_APPLICATION_PASS' in klog and 'sorryAx' not in klog
short='The reciprocal cosine spectrum has an absolutely and uniformly convergent cosine expansion.'
formula=r'\lambda(\theta)^{-1}=\frac1{\sqrt\kappa}\left(1+2\sum_{j\ge1}(-r)^j\cos(j\theta)\right).'
assumptions=[
 r'Fix \(\kappa\in\mathbb R\) with \(\kappa\ge2\), and set \(r=(\sqrt\kappa-1)/(\sqrt\kappa+1)\). The square root is the nonnegative real square root.',
 r'For every real angle \(\theta\), define \(\lambda(\theta)=(\kappa+1)/2+(\kappa-1)\cos\theta/2\). The displayed equality is therefore exactly the source left side \(2/(\kappa+1+(\kappa-1)\cos\theta)\).',
 r'The source series starts at \(j=1\). Lean uses \(j\in\mathbb N\) and mode \(j+1\) in both the power and cosine. Its partial sum indexed by \(N\) has exactly the first \(N\) positive modes.',
 r'Absolute convergence is pointwise for each real angle. Uniform convergence is on all \(\mathbb R\) in the angle for this fixed \(\kappa\): one threshold works for every angle. No uniformity over unbounded \(\kappa\) is asserted.',
 r'The bounds \(0<r<1\), nonzero denominators, summability and uniform convergence are proved internally. No dimension, Gaussian law, matrix input, radius certificate or convergence premise is supplied by the caller.'
]
steps=[
 {'title':'Produce the geometric radius',
  'text':'The source condition gives a square root strictly greater than one. Its literal fractional transform lies strictly between zero and one, so the complex geometric ratios have norm below one.',
  'formula':r's=\sqrt\kappa>1,\qquad r=\frac{s-1}{s+1}\in(0,1).',
  'lean':'The private radius_bounds proof uses Real.sq_sqrt and Real.sqrt_nonneg, then positive-denominator division. These are internal outputs, not public hypotheses.'},
 {'title':'Take the real part of a convergent geometric series',
  'text':'Set z=−r exp(iθ). The complex phase has modulus one. Sum the geometric series and take its real part; De Moivre identifies each real term with the cosine mode. This packages the source pair of conjugate geometric sums by real-part linearity.',
  'formula':r'z=-re^{i\theta},\quad |z|=r<1,\qquad\sum_{j\ge0}(-r)^j\cos(j\theta)=\operatorname{Re}(1-z)^{-1}.',
  'lean':'cosine_series_value invokes hasSum_geometric_of_norm_lt_one and Complex.hasSum_re. hterm checks the casts and exp_nat_mul identity explicitly; hreal carries an actual HasSum certificate.'},
 {'title':'Compute the real rational expression',
  'text':'The squared norm of 1−z is the positive denominator D. The real part of its inverse is (1+r cosθ)/D. Separate the zero mode, then double the positive modes and subtract the zero term.',
  'formula':r'D=1+2r\cos\theta+r^2>0,\qquad1+2\sum_{j\ge1}(-r)^j\cos(j\theta)=\frac{1-r^2}{D}.',
  'lean':'hre, him and hnorm use the trigonometric unit-circle identity; hD is produced from r<1 and cosθ≥−1. Complex.inv_re and hreal.summable.tsum_eq_zero_add give hsplit; the final calculation proves the displayed rational identity.'},
 {'title':'Restore the exact source normalization',
  'text':'Substitute the literal radius and s²=κ. Two algebraic identities cancel the positive factors and yield the reciprocal source eigenvalue, with the exact factor two and square-root scale.',
  'formula':r'1-r^2=s(1-r)^2,\quad D=\frac{(1-r)^2}{2}\bigl(\kappa+1+(\kappa-1)\cos\theta\bigr).',
  'lean':'hparam and hnorm in the public producer prove these identities by field algebra; hspec and h1r supply nonzero denominators internally. The sealed pointwise conclusion follows from cosine_series_value.'},
 {'title':'Prove absolute and uniform convergence',
  'text':'Every absolute mode is bounded by the same positive geometric mode. The geometric majorant is summable. It proves absolute summability at each angle and, through the uniform majorant test, convergence of the partial sums uniformly over every real angle.',
  'formula':r'\left|(-r)^{j+1}\cos((j+1)\theta)\right|\le r^{j+1},\qquad\sum_{j\ge0}r^{j+1}<\infty.',
  'lean':'hgeom proves the shifted geometric sum is summable. hmajor uses the real cosine bound. Summable.of_norm_bounded yields the absolute output, and tendstoUniformly_tsum_nat yields exactly the sealed all-real-angle uniform output.'},
 {'title':'Consume the expansion on the actual finite grid',
  'text':'For d≥2 and the literal hard grid, the private Test takes cosine weights at any natural frequency n. It consumes the new pointwise expansion and absolute summability, proves weighted summability, normalizes each reciprocal eigenvalue and genuinely exchanges the finite grid sum with the infinite series. This is a private generalized intermediate, before Gaussian expectation identification or alias cancellation.',
  'formula':r'\sum_i\frac{\cos(n\theta_i)}{\lambda_i}=\frac1{\sqrt\kappa}\left[\sum_i\cos(n\theta_i)+2\sum_{j\ge1}(-r)^j\sum_i\cos(n\theta_i)\cos(j\theta_i)\right].',
  'lean':'actual_inverse_grid_cosine_series obtains heq and habs from the new canonical producer. hs, hsg and hlin use absolute summability; heigen proves literal reciprocal normalization; Summable.tsum_finsetSum is the actual exchange. The compiled private proof has exactly one public ASTIS parent, this producer; it is not a Registry node or a C8 Gaussian moment theorem.'}
]
boundary=('Selected FactC7 identity, pointwise absolute convergence and fixed-kappa all-real-angle uniform convergence, plus an actual private finite-grid series-interchange consumer, are compiled locally. '
 'The consumer is an all-natural-n intermediate; source1<=n<d remains required later for C8 alias classification and closed moments. Gaussian second-moment/expectation and orthogonal target-law bridges, C8 closed formulas, variance/bias/Krylov, both full main bounds and adaptive/oracle/precision/TV/deterministic-cap/expected-cost adapters, local integration/remote delivery and postmerge purification/Exposition Seal remain separate.')
source={'url':'https://arxiv.org/html/2610.20492v1#A3.Thmtheorem7',
 'edition':'arXiv2610.20492v1; raw HTML SHA2566bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915',
 'anchor':'Fact C.7/A3.Ex133-137, full proof A3.SS3.2; standing kappa S4.SS1.p1.m4 and literal rho S4.Thmtheorem5; private C8 finite-grid use A3.SS3.p4.2.',
 'wording_status':'faithful paraphrase','attribution':'Huanjian Zhou and Taiji Suzuki, On Complexity of Gaussian Sampling.',
 'scope':'Full scalar FactC7. Private deterministic grid exchange is a separately checked source-proof intermediate, not the Gaussian expectation or full C8 statement.'}
unit={'kind':'theorem','reading_layout':'progressive','declaration':name,'title':'Cosine expansion of the inverse spectrum',
 'reader_note':'The expansion is shown first; the exact parameter, convergence scope, formula proof and Lean are folded below.',
 'statement':short,'formula':formula,'assumptions':assumptions,
 'notation':[{'symbol':r'\(S_N(\theta)\)','text':'The first N positive cosine modes; kappa stays fixed.','formula':r'S_N(\theta)=\sum_{j=1}^{N}(-r)^j\cos(j\theta).'}],
 'steps':steps,'astis_dependencies':[],
 'mathlib_dependencies':['hasSum_geometric_of_norm_lt_one','Complex.hasSum_re','Complex.exp_nat_mul','Complex.inv_re','Complex.normSq_apply','Real.sin_sq_add_cos_sq','Summable.tsum_eq_zero_add','summable_geometric_of_lt_one','Summable.of_norm_bounded','tendstoUniformly_tsum_nat'],
 'lean_statement':'Exactly real kappa>=2 and literal r; the identity for every real angle, absolute summability and all-real-angle uniform convergence are all conclusions.',
 'lean_proof':'Complex geometric summation and real-part algebra produce the exact normalized identity. A common geometric majorant proves both convergence conclusions. The private actual finite-grid consumer separately uses the new producer and its absolute summability.',
 'boundary':boundary,'sources':[{**source,'label':'Zhou–Suzuki Fact C.7 and C.8 finite-grid use'}],
 'tests':['lake build Tests.GaussianComplexityFixedSpectrumCosineExpansion']}
def strings(x):
    if isinstance(x,str):yield x
    elif isinstance(x,dict):
        for v in x.values():yield from strings(v)
    elif isinstance(x,list):
        for v in x:yield from strings(v)
assert not any('\\\\' in x for x in strings(unit))
put('website/content/declaration_lessons/huanjian-fixed-spectrum-cosine-expansion.json',{'schema_version':1,'units':[unit]})
aid='ASTIS-RT-20261109-HuanjianFixedSpectrumCosineExpansion'
binding={'declaration':name,'cell':'ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-cosine-expansion','role':'proof-edge',
 'supports':['pointwise-inverse-expansion','absolute-convergence','uniform-convergence'],'boundary':boundary,'audit_id':aid,
 'assumption_deltas':[
  {'source':'Standing real kappa>=2 and literal rho; every real theta.','lean':'Exactly real kappa>=2; literal r in the statement; all-real-angle equality and convergence outputs. No dimension or matrix binder.','classification':'same','reason':'C7 is scalar and dimension-free. Radius bounds and denominators are internally proved, not additional source hypotheses.'},
  {'source':'Positive-index series converges absolutely and uniformly in theta.','lean':'Nat index j+1, Summable of the real term norm for every theta, and TendstoUniformly of the first N positive modes on all real theta, for each fixed kappa.','classification':'source-implicit','reason':'Explicitly exposes the positive-mode index and the standard absolute/uniform senses; the uniform threshold does not depend on theta and is allowed to depend on kappa.'},
  {'source':'C8 p4.2 consumes C7 for the finite grid exchange; later closed moments require1<=n<d.','lean':'A private actual cosine-weighted finite-grid interchange is proved for all natural n. Gaussian expectation identification and later alias-class cancellation remain separate.','classification':'generalization','reason':'Only the private deterministic intermediate is generalized. The source-facing C7 statement and future source C8 moment range are unchanged; no frequency cancellation, integrability or probabilistic conclusion is assumed.'}]}
text=' '.join([short,formula,*assumptions])
item={'id':'huanjian-fixed-spectrum-cosine-expansion','library':'samplewiki','chapter':'gaussian-sampling-complexity',
 'chapter_path':'example-cases/samplewiki/companions/gaussian-sampling-complexity.html','title':unit['title'],'source':source,'statement':text,
 'formulae':[{'label':'Inverse-spectrum cosine expansion','tex':formula}],'assumptions':assumptions,
 'obligations':[{'id':'pointwise-inverse-expansion','label':'Exact normalized expansion for every real angle.'},
                {'id':'absolute-convergence','label':'Absolute convergence at every real angle.'},
                {'id':'uniform-convergence','label':'Uniform positive-mode partial sums on the full real angle domain at fixed kappa.'}],
 'bindings':[binding]}
put('website/content/publications/huanjian-fixed-spectrum-cosine-expansion.json',{'schema_version':1,'items':[item]})
head,body=sig.split(' :\n',1)
statement='∀'+head.removeprefix('theorem actual_inverse_spectrum_cosine_expansion')+',\n'+body
context=[
 'Real.sqrt is the nonnegative real square root. All real divisions, norms, powers and cosines have their standard meanings.',
 'The infinite sum over natural j uses exactly the displayed j+1 mode. Finset.range N consists of zero through N minus one, so its partial sum contains the first N positive modes.',
 'Summable of the real norm means absolute convergence of the scalar series. The infinite sum is totalized by convention outside summability, but summability is a conclusion of this proposition, not a caller premise.',
 'TendstoUniformly F f atTop over the real angle means: for every real epsilon>0 there exists a natural N0 such that every N>=N0 and every real angle have absolute F(N,angle)-f(angle)<epsilon. The real parameter is outside this uniformity statement.'
]
audit={'id':aid,'state':'draft','source':{'source_id':'arxiv2610.20492v1-FactC7','url':source['url'],'anchor':source['anchor'],
 'original_text':text,'text_sha256':sha(text),'source_snapshot_sha256':S['source']['raw_sha256']},
 'lean':{'declaration':name,'file':str(file),'statement':statement,'statement_sha256':sha(statement),
         'formalizer':'huanjian_gc_20261109_fixed_spectrum_cosine_expansion','compiled':True,'decoder_context':context},
 'reconstruction':{},'semantic_slots':{},'deltas':[],'verdict':'pending','source_review':{'state':'pending'},'repairs':[]}
ap=Path('research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-cosine-expansion.json')
pub.inputs.cache_clear();pub.load.cache_clear()
audit['publication_binding_sha256']=pub.binding_digest(item,binding)
audit['publication_context']=pub.review_context(item,binding)
put(ap,audit)
pub.check_advance([name],reviewed=False)
packet=rt.decoder_packet(audit)
neutral=Path('.astis/semantic-neutral-20261109/b4e6a1')
assert not neutral.exists();neutral.mkdir(parents=True)
put(neutral/'input.json',packet);put(E/'decoder-input.json',packet)
(E/'anonymous-statement.txt').write_text(statement)
record={'producer_raw_sha256':sha(file.read_bytes()),'Test_raw_sha256':sha(test.read_bytes()),
 'producer_signature_sha256':S['producer']['signature_sha256'],'private_consumer_signature_sha256':S['actual_private_consumer']['signature_sha256'],
 'actual_direct_public_ASTIS_producer_parents':[],'actual_direct_public_ASTIS_private_consumer_parents':[name],
 'publication_binding_sha256':audit['publication_binding_sha256'],'anonymous_statement_sha256':sha(statement),
 'anonymous_packet_canonical_sha256':packet['packet_sha256'],'neutral_input':str(neutral/'input.json'),
 'neutral_input_raw_sha256':sha((neutral/'input.json').read_bytes()),'actual_focus_receipt':str(focus),'actual_kernel_receipt':str(kernel),
 'source_review':'pending','decoder':'pending','sourceV_or_integration_or_Goal_complete':False}
put(E/'publication-draft-record.json',record)
print(json.dumps(record))
