import AutoSamplingTheory.ExampleCases.ProximalBPS.ActualOrderedPrefix
open MeasureTheory
open scoped NNReal ENNReal
noncomputable section
private theorem terminal_elim_identity {X : Type*} (T : ℝ≥0)
    (g : X → ℝ≥0 → ℝ≥0∞) (r : (ℝ≥0 × X) ⊕ Unit) :
    r.elim (fun a => g a.2 (T - r.elim Prod.fst (fun _ => 0))) (fun _ => 0) =
      r.elim (fun a => g a.2 (T - a.1)) (fun _ => 0) := by
  cases r <;> rfl
private theorem terminal_measurable_transport {X Y : Type*} [MeasurableSpace Y]
    (T : ℝ≥0) (g : Y → X → ℝ≥0 → ℝ≥0∞)
    (r : Y → (ℝ≥0 × X) ⊕ Unit)
    (hg : Measurable (fun y => (r y).elim (fun a => g y a.2 (T-a.1)) (fun _ => 0))) :
    Measurable (fun y => (r y).elim
      (fun a => g y a.2 (T - (r y).elim Prod.fst (fun _ => 0))) (fun _ => 0)) := by
  have he : (fun y => (r y).elim
      (fun a => g y a.2 (T - (r y).elim Prod.fst (fun _ => 0))) (fun _ => 0)) =
      (fun y => (r y).elim (fun a => g y a.2 (T-a.1)) (fun _ => 0)) :=
    funext (fun y => terminal_elim_identity T (g y) (r y))
  rw [he]
  exact hg
#print axioms terminal_elim_identity
#print axioms terminal_measurable_transport
end