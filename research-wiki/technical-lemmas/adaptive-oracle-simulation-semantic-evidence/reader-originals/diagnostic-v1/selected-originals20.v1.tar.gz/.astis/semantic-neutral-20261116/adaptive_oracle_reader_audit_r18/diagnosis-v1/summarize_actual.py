"""Summarize the already completed R18 run; launches no browser or server."""
from pathlib import Path
import hashlib
import json
import struct

OWN=Path(__file__).resolve().parents[1]
OUT=Path(__file__).resolve().parent
raw=OWN/'actual-result.json'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
r=json.loads(raw.read_text())
assert sha(raw)=='f7e3488bdca1e854664f1eb2e91f48169e554293964ed5019915a792ceb01578'
screens=[]
for row in r['screenshots']:
    p=OWN/row['path']; b=p.read_bytes()
    assert sha(p)==row['sha256'] and b[:8]==b'\x89PNG\r\n\x1a\n'
    w,h=struct.unpack('>II',b[16:24])
    name=p.stem
    if 'initial-folded' in name:
        note='Actually viewed: main formula rendered; clear hierarchy; assumptions/proof/Lean initially folded; mobile formula has an explicit horizontal-scroll cue.'
    elif 'representative-step' in name:
        note='Actually viewed: expanded step prose/formula and its adjacent Lean disclosure remain identifiable; code stays in a bounded source container. Screenshot captures the stated viewport segment.'
    elif 'assumption-comparison' in name:
        note='Actually viewed: table content is readable. Mobile shot intentionally shows the right side of the table after its own internal scroll; it does not identify the separate body-width offender.'
    elif 'module-full-source-context' in name:
        note='Actually viewed: source module is shown in a bounded code panel with complete-module controls; the viewport shows its initial portion, with whole-source exactness separately checked by bytes.'
    elif 'widest-right-glyph' in name:
        note='Actually viewed: horizontally scrolled source exposes the widest line ending; large blank regions belong to shorter source lines at the same internal scroll position. Range geometry is independently rechecked below.'
    elif 'source-T-bottom' in name:
        note='Actually viewed: final namespace line and its ending are visible above the footer, at the retained internal horizontal scroll position.'
    elif '-source-' in name and '-anchor' in name:
        note='Actually viewed: exact declaration starts below the header at the natural source anchor. Mobile long source lines remain inside the source horizontal scroll container.'
    elif 'source-index' in name:
        note='Actually viewed: four long exact declaration identities wrap legibly; private T explicitly carries no public-node credit.'
    elif 'parent-context' in name:
        note='Actually viewed: public run-parent and private two-direction application links are distinct; private T no-public-node boundary is legible.'
    elif 'graph-' in name and 'actual-node-viewport' in name:
        note='Actually viewed: selected node core label is readable inside actual SVG clip; solid structure and dashed references have directed arrowheads. Long labels remain ellipsized as disclosed.'
    elif 'graph-' in name and 'full-ID-detail' in name:
        note='Actually viewed: full exact selected identity wraps legibly in detail with source/context entrance; related-neighbor cards retain their direction labels.'
    else:
        raise RuntimeError(name)
    screens.append({**row,'width':w,'height':h,'independently_viewed':True,'observation':note})

anchors=[]
for trace in r['natural_source_anchor_stability_traces']:
    samples=trace['samples']; tail=samples[-4:]
    def signature(s):
        g=s['geometry']; p=s['pre_scroll'] or {'left':0,'top':0}
        return [s['window_scroll']['x'],s['window_scroll']['y'],p['left'],p['top'],
                *[g[k] for k in ['left','right','top','bottom']],g['header'],
                *[g['clip'][k] for k in ['left','right','top','bottom']]]
    maximum_delta=max(max(z)-min(z) for z in zip(*(signature(s) for s in tail)))
    last=samples[-1]; g=last['geometry']; first=samples[0]['geometry']
    recomputed_stable=len(tail)==4 and last['elapsed_ms']>=500 and maximum_delta<=.25
    strict=g['positive'] and g['top']>=g['header']-1
    anchors.append({'case':trace['case'],'sample_count':len(samples),'elapsed_ms':last['elapsed_ms'],
                    'immediate_top_header':[first['top'],first['header']],
                    'settled_top_header':[g['top'],g['header']],
                    'tail_maximum_delta_css_px':maximum_delta,'recomputed_stable':recomputed_stable,
                    'recomputed_original_strict_predicate':strict,'target':trace['target']})

glyphs=[];graphs=[]
for c in r['checks']:
    g=c['detail']
    if c['name'].endswith(('widest-line-final-full-codepoint-visible','bottom-full-codepoint-visible')):
        box=g['glyph']; clip=g['actualVisibleClip']
        visible=box['width']>0 and box['height']>0 and box['left']>=clip['left']-1 and box['right']<=clip['right']+1 and box['top']>=clip['top'] and box['bottom']<=clip['bottom']
        glyphs.append({'check':c['name'],'line_id':g['lineId'],'selected_glyph':g['selectedGlyph'],'code_points':g['codePoints'],'glyph':box,'clip':clip,'recomputed_full_glyph_visible':visible,'reported_line_visible':g['lineVisible']})
    if c['name'].endswith('readable-node-core-label-inside-real-SVG-clip'):
        a=g['after_native_UI']
        readable=a['positiveSVGClippedIntersection'] and a['intersectionFraction']>=.98 and a['labelVisibleFraction']>=.95 and a['effectiveFontPx']>=12 and a['labelIntersection']['width']>=min(80,a['labelRect']['width']) and a['labelIntersection']['height']>=min(12,a['labelRect']['height'])
        graphs.append({'check':c['name'],'node_fraction':a['intersectionFraction'],'label_fraction':a['labelVisibleFraction'],'effective_font_px':a['effectiveFontPx'],'recomputed_core_readable':readable,'actual_native_interactions':g['interactions']})
layouts=[c for c in r['checks'] if c['name'].endswith('document-horizontal-containment')]
responses=r['responses']; requests=r['requests']
origin=requests[0]['url'].split('/')[2]
network={'requests':len(requests),'responses':len(responses),'origins':sorted(set(x['url'].split('/')[2] for x in requests if x['url'].startswith('http'))),'HTTP_errors':[x for x in responses if x['status']>=400],'console_errors':[x for x in r['console'] if x['type']=='error'],'page_errors':r['page_errors'],'blocked_external_requests':r['blocked_external_requests']}
out={'schema':'r18-failed-reader-independent-inspection-v1','actual_result_sha256':sha(raw),'process_receipt_sha256':sha(OWN/'runtime-process/receipt.json'),'runtime_status_retained':'FAIL','false_checks':[c for c in r['checks'] if not c['pass']],'screenshots':screens,'all46_screenshots_independently_viewed':len(screens)==46,'anchor_traces':anchors,'all18_anchor_traces_recomputed_strictly_pass':len(anchors)==18 and all(a['recomputed_stable'] and a['recomputed_original_strict_predicate'] for a in anchors),'glyph_measurements':glyphs,'all16_glyph_measurements_recomputed_pass':len(glyphs)==16 and all(g['recomputed_full_glyph_visible'] and g['reported_line_visible'] for g in glyphs),'graph_measurements':graphs,'all8_graph_measurements_recomputed_pass':len(graphs)==8 and all(g['recomputed_core_readable'] for g in graphs),'layout_measurements':layouts,'network':network,'independent_acceptance':'WITHHELD: body width 404 at mobile expanded proof violates unchanged390+1 strict limit. Exact offending element and causal repair are not established by this run because all-element/ancestor geometry was not captured.','new_browser_or_server_execution':False,'original_preview_checker_results_modified':False}
p=OUT/'actual-inspection.v1.json';p.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'path':str(p),'sha256':sha(p),'screenshots_viewed':len(screens),'anchor_traces':len(anchors),'anchors_pass':out['all18_anchor_traces_recomputed_strictly_pass'],'glyphs':len(glyphs),'glyphs_pass':out['all16_glyph_measurements_recomputed_pass'],'graphs':len(graphs),'graphs_pass':out['all8_graph_measurements_recomputed_pass'],'network':network,'false_checks':out['false_checks']},ensure_ascii=False,indent=2))
