from driver import *
import ast, sys, types, html, re
from html.parser import HTMLParser

SNAP=PHASE/'candidate'; OUT=PHASE/'static-render'; OUT.mkdir(exist_ok=True)
sys.path[:0]=[str(SNAP/'tools'),str(SNAP/'website/scripts')]
import astis_site as base
import astis_site_source_index as source_index_adapter
import inline_lean
source_index_adapter.install(base)
base._ACTIVE_GIT=base.GitContext(CAND,'independent-local-static972d','','',False,False,set())
base._ACTIVE_GATE=base.GateEvidence(False,False,CAND,'','',[],'Bounded independent static fixture; no global gate or publication acceptance claimed.')
# Execute the byte-exact candidate renderer definitions without importing its
# unused global source-lineage integration (which imports global control APIs).
path=SNAP/'website/scripts/declaration_lessons.py'
tree=ast.parse(path.read_text(),str(path)); tree.body=[n for n in tree.body if not (isinstance(n,ast.Import) and any(a.name=='source_lineage' for a in n.names))]
dl=types.ModuleType('bounded_declaration_lessons');dl.__file__=str(path)
exec(compile(tree,str(path),'exec'),dl.__dict__)
modules,decs=base.scan_project_sources(); base._SOURCE_BY_NAME={d.full_name:d for d in decs}; base._ALL_MODULES=modules
units=dl.load_units(); assert len(units)==1
unit=units[0]; item=json.loads((SNAP/'website/content/publications/huanjian-fixed-spectrum-krylov-range.json').read_text())['items'][0]
fixture={'lessons':{unit['declaration']:unit},'audits':{}}
# A pure rendering input supplies no audit and certifies no binding. This does
# not call/import ASTIS publication APIs or consume semantic verdicts.
pr=types.ModuleType('bounded_publication_reader')
pr.__dict__.update({'publication':types.SimpleNamespace(inputs=lambda:fixture,verified_binding=lambda b,d:False),'declaration_lessons':dl,'astis_site':base,'escape':html.escape})
prpath=SNAP/'website/scripts/publication_reader.py'; prtree=ast.parse(prpath.read_text(),str(prpath)); prtree.body=[n for n in prtree.body if isinstance(n,ast.FunctionDef) and n.name in ['semantic_details','source_card','source_proof_path']]
exec(compile(prtree,str(prpath),'exec'),pr.__dict__)
lesson_rel=dl.lesson_path(unit['declaration']); publication_rel=pr.source_proof_path(item)
base.write_page(OUT,lesson_rel,base.page(unit['title'],lesson_rel,dl.render_unit(unit,lesson_rel)))
base.write_page(OUT,publication_rel,base.page(item['title'],publication_rel,pr.source_card(item,publication_rel)))
for module in modules:
    rel='modules/'+base.slugify(module.name)+'.html'
    consumers=[m.name for m in modules if module.name in m.imports]
    base.write_page(OUT,rel,base.render_source_module(module,consumers))
    dest=OUT/'downloads/lean'/module.source_file; dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes((SNAP/module.source_file).read_bytes())
for source in unit['sources']:
    if 'path' not in source:continue
    raw=source['path']; lines=(SNAP/raw).read_text().splitlines();rel='data/lesson-sources/'+raw+'.html'
    numbered=''.join(f'<span id="L{i}">{base.esc(line)}</span>\n' for i,line in enumerate(lines,1))
    base.write_page(OUT,rel,base.page(raw,rel,'<h1>Exact source context</h1><pre>'+numbered+'</pre>'))
idx,module_files=base.source_index()
(OUT/'bounded-source-index.json').write_text(json.dumps({'index':idx,'module_files':module_files},ensure_ascii=False,indent=2)+'\n')
class Node:
    def __init__(self,tag='',attrs=(),parent=None):self.tag=tag;self.attrs=dict(attrs);self.parent=parent;self.children=[]
    def text(self):return ''.join(c if isinstance(c,str) else c.text() for c in self.children)
    def find(self,p):return ([self] if p(self) else [])+[v for c in self.children if isinstance(c,Node) for v in c.find(p)]
class Parse(HTMLParser):
    def __init__(self,s):super().__init__(convert_charrefs=True);self.root=Node();self.stack=[self.root];self.feed(s)
    def handle_starttag(self,t,a):
        n=Node(t,a,self.stack[-1]);self.stack[-1].children.append(n)
        if t not in {'meta','link','input','br','hr','img'}:self.stack.append(n)
    def handle_endtag(self,t):
        for i in range(len(self.stack)-1,0,-1):
            if self.stack[i].tag==t:self.stack=self.stack[:i];break
    def handle_data(self,d):self.stack[-1].children.append(d)
def hascls(n,c):return c in n.attrs.get('class','').split()
tree=Parse((OUT/lesson_rel).read_text()).root
steps=tree.find(lambda n:n.tag=='details' and hascls(n,'proof-reader-step'))
checks=[]
for i,(s,auth) in enumerate(zip(steps,unit['steps']),1):
    folds=s.find(lambda n:n.tag=='details' and any(isinstance(c,Node) and c.tag=='summary' and c.text()=='Corresponding Lean step' for c in n.children))
    f=folds[0]; codes=f.find(lambda n:n.tag=='code' and hascls(n,'language-lean'))
    controls=f.find(lambda n:'data-lean-copy' in n.attrs or ('download' in n.attrs and n.tag=='a'))
    checks.append({'step':i,'outer_closed':'open' not in s.attrs,'code_fold_closed':'open' not in f.attrs,'exact_code':len(codes)==1 and codes[0].text()==auth['lean'],'formula_present':auth['formula'] in s.text(),'adjacent_copy_or_download_controls':len(controls)>0,'context_link_in_fold':any('context' in a.text().lower() for a in f.find(lambda n:n.tag=='a'))})
panels=tree.find(lambda n:n.tag=='details' and 'data-inline-lean' in n.attrs)
panelresults=[]
for p in panels:
    actions=p.find(lambda n:hascls(n,'lean-source-actions'))
    dls=p.find(lambda n:n.tag=='a' and 'download' in n.attrs)
    ctx=p.find(lambda n:n.tag=='a' and 'Exact module and namespace context' in n.text())
    panelresults.append({'kind':p.attrs['class'],'closed':'open' not in p.attrs,'has_adjacent_actions':bool(actions),'has_copy_button':bool(p.find(lambda n:'data-lean-copy' in n.attrs)),'download_targets_exact':all((OUT/lesson_rel).parent.joinpath(a.attrs['href']).resolve().read_bytes()==(SNAP/'AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumKrylovRange.lean').read_bytes() for a in dls),'context_target_exists':all((OUT/lesson_rel).parent.joinpath(a.attrs['href'].split('#')[0]).resolve().is_file() for a in ctx)})
private=(SNAP/'Tests/GaussianComplexityFixedSpectrumKrylovRange.lean').read_text(); private_decl=private[private.index('private theorem '):private.rindex('\nend ')].rstrip()+'\n'
pub=(OUT/publication_rel).read_text();ptree=Parse(pub).root
source_folds=ptree.find(lambda n:n.tag=='details' and any(isinstance(c,Node) and c.tag=='summary' and c.text()=='Complete source statement and conditions' for c in n.children))
assert len(source_folds)==1
source_context=OUT/'data/lesson-sources/Tests/GaussianComplexityFixedSpectrumKrylovRange.lean.html'
report={'candidate':CAND,'render_scope':'Byte-exact candidate render_unit/source_card/base.page/render_source_module and source-index adapter, only P/T and own contribution. Global final-shell overlays, site build, browser/JS/MathJax/mobile/clipboard/deployment were not executed. Source-lineage canonical_shell omitted, not simulated. Publication pure fixture supplies no audits and verified_binding=False; status remains TODO.','lesson':lesson_rel,'publication':publication_rel,'source_index_exact_names':sorted(idx),'source_index_expected_P_only':sorted(idx)==[unit['declaration']],'scanner_handwritten_declarations':[d.full_name for d in decs],'step_count':len(steps),'steps':checks,'main_P_panels':panelresults,'private_T_full_text_exact_in_step6':unit['steps'][5]['lean']==private_decl,'private_T_has_own_generated_module_context':(OUT/('modules/'+base.slugify('Tests.GaussianComplexityFixedSpectrumKrylovRange')+'.html')).is_file(),'private_T_download_exact':(OUT/'downloads/lean/Tests/GaussianComplexityFixedSpectrumKrylovRange.lean').read_bytes()==(SNAP/'Tests/GaussianComplexityFixedSpectrumKrylovRange.lean').read_bytes(),'private_T_provenance_context_L12_exists':'id="L12"' in source_context.read_text(),'private_T_provenance_context_has_copy_or_download':'data-lean-copy' in source_context.read_text() or 'download=' in source_context.read_text(),'source_statement_fold_closed':'open' not in source_folds[0].attrs,'source_statement_and_assumptions_preserved':item['statement'] in source_folds[0].text() and all(a in source_folds[0].text() for a in item['assumptions']),'publication_statement_before_Learn_proof':pub.index('Complete source statement and conditions')<pub.index('Read the formalized proofs'),'P_own_public_ASTIS_parents_authored':unit['astis_dependencies'],'code_actions_limit':'The six corresponding-step folds contain exact closed code but do not carry individual copy/download/context controls. Main P statement/proof panels have the controls. The full private T text is in step6; its provenance source context is numbered, with no copy/download controls there.'}
(PHASE/'static-render-report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(report,ensure_ascii=False,indent=2))
