"""Read-only declaration/signature projection; never emit proof bodies."""
import hashlib
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
FILES = [
    "AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumSourceMatrixMean.lean",
    "Tests/GaussianComplexityFixedSpectrumSourceMatrixMean.lean",
    "AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumSourceMatrixRadius.lean",
    "Tests/GaussianComplexityFixedSpectrumSourceMatrixRadius.lean",
    "AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumSourceMatrixStructure.lean",
    "Tests/GaussianComplexityFixedSpectrumSourceMatrixStructure.lean",
    "AutoSamplingTheory/TechnicalLemmas/Probability/RealMatrixPositiveIntegral.lean",
]
DECL = re.compile(r"^(?:(?:private|protected|noncomputable)\s+)*(?:theorem|lemma)\s+(\S+)")
records = []
for rel in FILES:
    path = ROOT / rel
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    context, decls, pending, start, name = [], [], [], None, None
    with path.open() as stream:
        for lineno, line in enumerate(stream, 1):
            if re.match(r"^(?:public )?import |^namespace |^open |^open scoped |^variable |^universe |^noncomputable section", line):
                context.append({"line": lineno, "text": line.rstrip()})
            match = DECL.match(line)
            if match:
                pending, start, name = [line], lineno, match.group(1)
            elif pending:
                pending.append(line)
            if pending and re.search(r":=\s*by\b", line):
                text = "".join(pending)
                text = re.split(r":=\s*by\b", text, maxsplit=1)[0].rstrip()
                decls.append({"line": start, "name": name, "private": pending[0].startswith("private "), "signature": text})
                pending = []
    records.append({"path": rel, "file_sha256": digest, "context": context, "declarations": decls})
(OUT / "canonical-headers.json").write_text(json.dumps(records, ensure_ascii=False, indent=2) + "\n")
for item in records:
    print(item["path"], item["file_sha256"])
    for ctx in item["context"]:
        print(f"  L{ctx['line']}: {ctx['text']}")
    for decl in item["declarations"]:
        print(f"  L{decl['line']}: {'private ' if decl['private'] else ''}{decl['name']}")
