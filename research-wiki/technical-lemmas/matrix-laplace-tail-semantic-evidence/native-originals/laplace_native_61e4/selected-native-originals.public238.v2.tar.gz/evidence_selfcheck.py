"""Check every explicit evidence leaf and exclusion in the completed native manifest."""
import json
from native_common import *

manifest = json.loads((OWN/'selected-originals.manifest.v1.json').read_text())
assert manifest['candidate_commit'] == COMMIT
assert manifest['private_workspace_guards_excluded']
for leaf in manifest['leaves']:
    path=(OWN/leaf['path']).resolve()
    assert path.is_relative_to(OWN) and path.is_file()
    assert path.name!='private-workspace-guards.json'
    assert path.stat().st_size==leaf['bytes'] and file_sha(path)==leaf['sha256']
report=json.loads((OWN/'native-mathematics-report.v1.json').read_text())
assert report['raw_type_value_DAG']['ASTIS_checked_values']==56
assert report['complete_recursive_constant_dependency_graph']['declarations']==58103
assert not report['sorryAx_or_unauthorized_axiom']
assert report['T']['private']
print(json.dumps({'candidate_commit':COMMIT,'all_explicit_evidence_leaves_rehashed':len(manifest['leaves']),'private_workspace_guards_excluded':True,'native_report_consistency':True}))
