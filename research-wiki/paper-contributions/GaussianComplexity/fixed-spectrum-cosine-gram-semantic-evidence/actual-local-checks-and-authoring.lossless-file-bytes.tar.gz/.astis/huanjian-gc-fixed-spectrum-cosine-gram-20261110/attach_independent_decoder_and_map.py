from pathlib import Path
import sys,json,copy
sys.dont_write_bytecode=True;sys.path.insert(0,'.astis/huanjian-gc-fixed-spectrum-detector-20261110')
from lossless_frozen_bundle import archive_exact,put_new,sha
W=Path(__file__).resolve().parent.relative_to(Path.cwd())
E=Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-cosine-gram-semantic-evidence')
dump=lambda x:(json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode()
D=W/'source-map-author-1d7a46'
mp=D/'manifest.json';rp=D/'receipt.json';prop=D/'source-to-lean-map.PROPOSAL.json'
assert sha(mp.read_bytes())=='06cfa60c1ffa374cc50a5082e95931383ca34dff7b2c7a55c8bfc851070e030e'
assert sha(rp.read_bytes())=='fb9fed4eaaf32e91955948f1e75727deddaaeaca19454a0607443abed8cbf214'
assert sha(prop.read_bytes())=='120618372658e6dcb9799c4d43ddeb6b08ebbc8b83514483a58e75247b2258d0'
m=json.loads(mp.read_bytes())
for row in m['files']:
    p=D/row['path'];b=p.read_bytes();assert sha(b)==row['sha256'] and len(b)==row['bytes'],p
files={str(p.relative_to(D)):p.read_bytes() for p in D.rglob('*') if p.is_file() and not p.is_symlink()}
for p in D.rglob('*'):
    if p.is_file() and not p.is_symlink():assert p.stat().st_mode&0o777==0o444,p
assert len(files)==161
x=json.loads(prop.read_bytes());assert len(x['locator_slices'])==57
for row in x['locator_slices']:
    p=Path(row['file']);b=p.read_bytes();text=b.decode('utf-8')
    assert sha(b)==row['raw_wholefile_sha256']
    a=row['character_start_inclusive'];z=row['character_end_exclusive']
    literal=text[a:z];assert literal==row['literalLF'] and '\r' not in literal,row['slice_id']
    assert b[row['byte_start_inclusive']:row['byte_end_exclusive']]==literal.encode(),row['slice_id']
    assert text[:a].count('\n')+1==row['start_line_1based_inclusive']
    assert text[:z-1].count('\n')+1==row['end_line_1based_inclusive']
    # The original literal plus its raw-byte offsets are checked independently;
    # any original optional hash is retained unchanged in the exact proposal.
canonical=[r['canonical_id'] for r in x['canonical_rows']];assert len(canonical)==len(set(canonical))==24
map_record=archive_exact(files,E/'postproof-map-author-all-original-files.lossless-file-bytes.tar.gz')
put_new(E/'postproof-map-author-all-original-files.archive-manifest.json',dump(map_record))
put_new(E/'source-to-lean-map-v1.json',prop.read_bytes())
put_new(E/'source-to-lean-map-mechanical-byte-attachment.json',dump({'original_actor':'/root/cosine_gram_source_graph_1d7a46','original_proposal_sha256':sha(prop.read_bytes()),'all161_original_regular_files_byte_exact':True,'all57_decoded_character_and_raw_byte_slices_independently_checked':True,'inclusive_line_convention_verified':True,'canonical_ids_unique24':True,'no_new_source_or_native_verdict':True,'original_implementation_exposure_and_open_scope_retained':True}))
N=Path('/private/tmp/rt-pkt-5b83e1');packet=(N/'input.json').read_bytes()
assert sha(packet)=='3f9dc55241440d2b84ef26c6555204c1427036f79b3c35ecbc1a2709ed2fe71d'
runraw=(N/'decoder_run.json').read_bytes();run=json.loads(runraw)
rec=json.loads((N/'reconstruction.json').read_bytes());md=(N/'reconstructed_theorem.md').read_bytes()
assert run['actor']=='/root/neutral_decoder_5b83e1' and rec['decoder']==run['actor']
assert sha(runraw)==rec['decoder_run_sha256']=='098a042ca87745af5b3db824ee31a7ff6772bb498556d590571b6e7ccfaac802'
assert sha((N/'neutral_decoder_5b83e1_execution.rawreceipt.json').read_bytes())==run['run_hash']=='76a64ef87e1d226a8764f52e6130bbe27f4dc3eaed420ffde15d4bd2c9374f77'
assert sha((N/'neutral_decoder_5b83e1_freeze_receipt.json').read_bytes())=='76a63914450d38ed71b014d745976681593a4729c3347f058828942085ebca03'
assert sha(md)==rec['reconstructed_text_sha256']=='0f9ec8dc1f37357cd6db21b52058246a414844ac4aaf3efc993eaeffc38bbe1b'
assert md.decode()==rec['reconstructed_theorem_text']
assert not run['source_recognition']['particular_source_identified'] and not run['source_text_visible']
assert run['canonical_packet_sha256_computed']=='d37700e0ffc0ef8d9dbc3f2b800490f212a559f624792d2e7ef81c9e856074cd'
dest=E/'independent-decoder-5b83e1';assert not dest.exists();dest.mkdir()
decoderfiles=[]
for p in sorted(N.iterdir()):
    assert p.is_file() and not p.is_symlink(),p
    if p.name!='input.json':assert p.stat().st_mode&0o777==0o444,p
    q=dest/p.name;q.write_bytes(p.read_bytes());q.chmod(0o444)
    decoderfiles.append({'path':str(q),'sha256':sha(q.read_bytes()),'bytes':q.stat().st_size,'source_mode':oct(p.stat().st_mode&0o777)})
assert len(decoderfiles)==16
ap=Path('research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-cosine-gram.json')
oldraw=ap.read_bytes();a=json.loads(oldraw);assert a['state']=='draft' and a['reconstruction']=={}
assert a['publication_binding_sha256']=='2c69e97d04c07f82e06cc79d73e7b0a1708dcae4dad8b4ae6c644e5173d27c10'
assert a['lean']['statement_sha256']==run['lean_statement_sha256']=='6b88608363dcefc548788aaed850e51d25a4e73aa703f8a5b4347db7fbd03a2e'
put_new(E/'audit-before-independent-decoder.raw.json',oldraw)
a['reconstruction']={'text':md.decode(),'text_sha256':sha(md),'decoder':run['actor'],'decoder_run_sha256':sha(runraw),'decoder_packet_sha256':run['packet_sha256'],'source_text_visible':False,'lean_statement_sha256':run['lean_statement_sha256'],'input_artifacts':['lean-statement','approved-definition-context'],'run_artifact':str(dest/'reconstruction.json')}
a['state']='blind-reconstructed';ap.write_bytes(dump(a))
put_new(E/'independent-decoder-exact-attachment.json',dump({'source_actor':run['actor'],'all16_existing_original_regular_files_copied_byte_exact':decoderfiles,'input_original_mode':'0644, owned pre-existing input; its original bytes remain exact. Portable copy is0444, not a claim about original filesystem metadata.','actual_execution_raw_receipt_hash_used_as_run_hash':run['run_hash'],'original_first_TextEncoder_failure_and_unmirrored_wrapper_limit':run['receipt_limit'],'no_raw_reconstruction_or_TeX_bytes_normalized_by_root':True,'root_semantic_verdict_invented':False,'source_review':'pending','sourceV_global_Goal_credit':False}))
print(json.dumps({'source_map57_slices_exact':True,'map_author_original_files':161,'decoder_original_files':16,'reconstruction_text_sha256':sha(md),'audit_state':'blind-reconstructed','source_review':'pending','sourceV':False}))
