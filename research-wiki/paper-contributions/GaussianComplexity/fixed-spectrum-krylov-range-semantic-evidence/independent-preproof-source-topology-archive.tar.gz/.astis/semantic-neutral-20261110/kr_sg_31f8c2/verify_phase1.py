from pathlib import Path
import re,json,hashlib
ROOT=Path(__file__).resolve().parent;REPO=ROOT.parents[2]
src=REPO/'.astis/huanjian-resume-20261103/2610.20492v1.html'
b=src.read_bytes();s=b.decode();sha=lambda x:hashlib.sha256(x).hexdigest()
assert len(b)==951991 and sha(b)=='6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
pins=json.loads((ROOT/'source-pins.json').read_text());cov=json.loads((ROOT/'coverage.json').read_text());graph=json.loads((ROOT/'source-graph.json').read_text())
regexids=[];check=[]
for sec in pins['sections']:
    ca,cb=sec['char_span_0based_halfopen'];ba,bb=sec['utf8_span_0based_halfopen'];raw=b[ba:bb]
    assert s[ca:cb].encode()==raw and sha(raw)==sec['sha256_raw_utf8']
    assert raw==(ROOT/'raw'/(sec['id']+'.html')).read_bytes()
    ids=re.findall(rb'\bid="([^"]+)"',raw);regexids.extend(x.decode() for x in ids)
    math_tags=re.findall(rb'<math\b[^>]*>',raw)
    p_tags=re.findall(rb'<p\b[^>]*>',raw)
    table_tags=re.findall(rb'<table\b[^>]*>',raw)
    assert all(re.search(rb'\bid="[^"]+"',x) for x in math_tags+p_tags+table_tags)
    check.append({'section':sec['id'],'raw_sha256':sha(raw),'ids_by_independent_regex':len(ids),'math_tags':len(math_tags),'p_tags':len(p_tags),'table_tags':len(table_tags)})
assert len(regexids)==len(set(regexids))==520
assert set(regexids)=={x['id'] for x in pins['elements']}=={x['id'] for x in cov['records']}
cp={x['id']:x for x in cov['records']}
for pin in pins['elements']:
    ca,cb=pin['char_span_0based_halfopen'];ba,bb=pin['utf8_span_0based_halfopen'];raw=b[ba:bb]
    assert raw==s[ca:cb].encode() and sha(raw)==pin['sha256_raw_utf8']
    assert re.search(rb'\bid="'+re.escape(pin['id'].encode())+rb'"',raw.split(b'>',1)[0])
    assert pin['lf_lines_1based_inclusive']==[s.count('\n',0,ca)+1,s.count('\n',0,cb-1)+1]
    for k,v in pin.items():assert cp[pin['id']][k]==v
    assert cp[pin['id']]['disposition'] in ['NODE','EXCLUDED']
    if cp[pin['id']]['disposition']=='EXCLUDED':assert cp[pin['id']]['reason']
nodeids={n['id'] for n in graph['nodes']}
assert len(nodeids)==len(graph['nodes'])
for r in cov['records']:
    if r['disposition']=='NODE':assert set(r['node_ids'])<=nodeids
for x in ['A3.EGx13','A3.Ex130','A3.Ex131','A3.Ex130.m1','A3.Ex130.m2','A3.Ex131.m1','A3.Ex131.m2','A3.SS2.p19']:
    assert cp[x]['disposition']=='NODE'
for cmd in (ROOT/'commands').glob('*.receipt.json'):
    rec=json.loads(cmd.read_text());pre=cmd.name[:-len('.receipt.json')]
    for stream in ['stdout','stderr']:
        raw=(cmd.parent/(pre+'.'+stream)).read_bytes()
        assert rec[stream+'_bytes']==len(raw) and rec[stream+'_sha256']==sha(raw),(cmd,stream)
out={'input_rechecked':True,'raw_section_slices_rechecked':True,'every_pin_offset_hash_and_lf_line_rechecked':True,'coverage_matches_independent_raw_regex':True,'all_math_p_table_tags_have_ids':True,'complete_C2_and_final_table_groups_included':True,'command_receipt_stream_hashes_rechecked':True,'scope':check,'coverage_id_count':len(regexids),'status':'structural source-pin/coverage validation passed; not independent mathematical topology approval'}
print(json.dumps(out,indent=2))
