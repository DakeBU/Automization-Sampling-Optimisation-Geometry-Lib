from pathlib import Path
from hashlib import sha256
import json

O=Path('/Users/zhouhuanjian/ASTIS-GC/.astis/semantic-neutral-20261110/cg_sg_1d7a46')
P=O/'phase2'
raw_graph=json.loads((O/'phase1/source_graph.json').read_text())
projection=json.loads((P/'inputs/strict-statement-projection.json').read_text())
supplement=json.loads((P/'inputs/additional-canonical-Gaussian-definitions.json').read_text())
assert projection['source_raw_sha256']==raw_graph['raw_sha256']=='6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
for item in supplement['definitions']:
    assert sha256(item['literal_definition'].encode()).hexdigest()==item['literal_sha256'], item['name']
parents={x['id']:set() for x in raw_graph['nodes']}
for e in raw_graph['edges']:
    parents[e['consumer']].update(e['parents'])
def ancestors(n):
    ans=set()
    for p in parents[n]:
        ans.add(p); ans.update(ancestors(p))
    return sorted(ans)
def dump(name,obj):
    (P/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')

roots=[]
def root(ident,owner,meaning,source_nodes,anchors,conditions,notes):
    roots.append({'typed_root':ident,'owner':owner,'typed_meaning':meaning,
       'raw_source_nodes':source_nodes,'true_raw_ancestors':sorted(set().union(*[set(ancestors(x)) for x in source_nodes])),
       'raw_source_anchors':anchors,'internal_obligations':conditions,'mapping_notes':notes,
       'observation':'Literal source structure aligned at the supplied signature; not a Lean proof or source-review verdict.'})
root('P.unweighted','public actual_cosine_frame_gram','t.transpose * t = (d:Real) scalar I_(q+1)',
     ['det.unweighted'],['A3.Ex87.m1','A3.SS2.p5.3','A3.SS2.p5.m8'],
     ['O.index-translation','O.matrix-sum-entries','O.det-unweighted-source-steps'],
     'Typed t has frame vectors as rows; multiplying its transpose by itself is exactly sum_i t_i t_i^T. No Gaussian input is a parent.')
root('P.weighted','public actual_cosine_frame_gram','t.transpose * D * t = 0',
     ['det.weighted'],['S4.Ex12.m1','A3.Ex87.m1','A3.Ex96.m1','A3.SS2.p7.3'],
     ['O.index-translation','O.matrix-sum-entries','O.det-weighted-source-steps'],
     'D is the actual diagonal cos((2q+1)theta_i). The four signed frequencies must be proved locally to lie in 1,...,2d-1, including both zero-coordinate cases.')
root('P.row-norm','public actual_cosine_frame_gram','For every i, sum_k(t i k)^2 <= 2*((q:Real)+1)',
     ['det.row-norm'],['A3.Ex87.m1','A3.Ex102.m1'],
     ['O.index-translation','O.det-row-norm-source-steps'],
     'Finite sum of coordinate squares is the squared Euclidean row norm. r=q+1; q=0 remains covered. No Gram or concentration input is required.')
root('Q.integrable-unweighted','private actual_gaussian_gram_means','Every actual entry of (B x)^T(B x) is Integrable under the literal canonical mu',
     ['B','gaussian.second-moment','matrix.expectation-algebra'],['A3.SS2.p1.m8','A3.SS2.p6.m1','A3.Ex94.m2'],
     ['O.identity-covariance','O.actual-Gaussian-coordinate-moments','O.entry-integrability','O.matrix-sum-entries'],
     'Source expectation computation implicitly needs finite second products. Explicit integrability is an added conclusion, not an added source assumption or a symbolic covariance certificate.')
root('Q.integrable-weighted','private actual_gaussian_gram_means','Every actual entry of (B x)^T D(B x) is Integrable under the literal canonical mu',
     ['B','D','gaussian.second-moment','matrix.expectation-algebra'],['S4.Ex12.m1','A3.SS2.p1.m8','A3.SS2.p6.m1','A3.Ex100.m2'],
     ['O.identity-covariance','O.actual-Gaussian-coordinate-moments','O.entry-integrability','O.matrix-sum-entries'],
     'D and t are deterministic finite real coefficients; the weighted entry is a finite sum of integrable Gaussian coordinate products. No supplied integrability premise.')
root('Q.mean-unweighted','private actual_gaussian_gram_means','The actual integral of each unweighted Gram entry equals if a=b then 1 else 0',
     ['consumer.expected-unweighted'],['A3.Ex86.m1','A3.Ex94.m2','A3.Ex95.m1'],
     ['O.identity-covariance','O.actual-Gaussian-coordinate-moments','O.entry-integrability','O.B-normalization','O.matrix-sum-entries','O.det-unweighted-source-steps'],
     'The ordered pair column index is (Gaussian-column,cosine-coordinate). Its identity delta is the product of the two coordinate deltas. Row independence is unnecessary for this second-moment expectation.')
root('Q.mean-weighted','private actual_gaussian_gram_means','The actual integral of each D-weighted Gram entry equals 0',
     ['consumer.expected-weighted'],['A3.Ex86.m1','A3.Ex100.m2','A3.Ex101.m1'],
     ['O.identity-covariance','O.actual-Gaussian-coordinate-moments','O.entry-integrability','O.B-normalization','O.matrix-sum-entries','O.det-weighted-source-steps'],
     'The literal D weight is the same one in the public weighted root. The expectation reduces to the deterministic weighted Gram, not an assumed mean-zero random matrix.')

binders=[]
for owner in ['public actual_cosine_frame_gram','private actual_gaussian_gram_means']:
    binders.extend([
      {'owner':owner,'binder':'{d : Nat}','independent_classification':'TYPING','source':'S4.SS1.p1.1 and Eq.(11)','reason':'Finite integer ambient dimension. Its source restriction d>=2 is discharged from hq, not lost or newly requested.'},
      {'owner':owner,'binder':'{q : Nat}','independent_classification':'SOURCE','source':'S4.Thmtheorem3.p1.1; S4.Thmtheorem4.p1.m2','reason':'Nonnegative integer query/degree budget, including q=0. Nat also supplies the finite-index carrier.'},
      {'owner':owner,'binder':'(hq : 2*q+1<d)','independent_classification':'SOURCE','source':'S4.Thmtheorem4.p1.m3','reason':'Exact inherited strict source endpoint. It internally supplies d>=2 and 2(q+1)<=d; neither 4q+1<d nor tau<=1/2 is imposed.'}])
binders.extend([
 {'owner':'both','binder':'theta, t, D let bindings','independent_classification':'DEFINITION_NOT_CALLER_BINDER','reason':'Literal closed local bodies from d,q; no assumptions are hidden in these function-valued matrix definitions.'},
 {'owner':'private','binder':'mu, B let bindings','independent_classification':'DEFINITION_NOT_CALLER_BINDER','reason':'The measure is explicitly multivariateGaussian 0 I and B is explicitly coordinatewise; neither is caller-supplied or Prop-valued.'},
 {'owner':'private','binder':'forall a b : Fin(q+1) x Fin(q+1)','independent_classification':'TYPING_IN_CONCLUSION','reason':'Universal matrix-entry conclusion, not extra hypothesis.'}])

definitions=[
 {'name':'theta','kind':'literal','audit':'SOURCE_ALIGNED','body':'((i.val:Real)+1/2)*pi/(d:Real)',
  'source':'S4.E11.m1; A3.SS2.p4.m2','interpretation':'Source i=1,...,d corresponds to typed i.val+1. Thus i-1/2 becomes i.val+1/2.',
  'fallback_audit':'Real division is total at d=0, but no admissible typed theorem case has d=0: hq gives d>=2. No active fallback on the source domain.'},
 {'name':'t','kind':'literal','audit':'SOURCE_ALIGNED','body':'if k.val=0 then 1 else sqrt(2)*cos(k.val*theta i)',
  'source':'A3.Ex85.m1; A3.SS2.p5.m1,m2','interpretation':'Columns k.val=0,...,q; the zero coordinate has scale 1 and every positive coordinate sqrt(2).',
  'fallback_audit':'The if is the actual source coordinate split on the complete finite carrier, not existence/default/failure semantics. q=0 gives a single constant column.'},
 {'name':'D','kind':'literal','audit':'SOURCE_ALIGNED','body':'Matrix.diagonal (fun i => cos((2*q+1)*theta i))',
  'source':'S4.Ex12.m1','interpretation':'Real diagonal with n=2q+1, same row grid as t.', 'fallback_audit':'No branch or chosen witness.'},
 {'name':'mu','kind':'literal','audit':'ACTUAL_GAUSSIAN_DEFINITION_WITH_INTERNAL_SIDE_CONDITIONS',
  'body':'multivariateGaussian (0 : EuclideanSpace Real (Fin d x Fin(q+1))) (1 : Matrix ... Real)',
  'source':'S4.Thmtheorem4.p1.m4,m5; A3.SS2.p1.2',
  'interpretation':'A single fixed canonical joint Gaussian measure on all d*r coordinates. Rearranging x_(i,a) as r columns gives the source g_a family after a law/moment justification internal to the proof.',
  'fallback_audit':'Not a symbolic mu with an assumed covariance certificate. The non-PSD degeneracy of CFC.sqrt is irrelevant only after proving the literal identity covariance PSD and its square root/normalization properties internally.'},
 {'name':'B','kind':'literal','audit':'SOURCE_ALIGNED','body':'(sqrt(d:Real))^-1 * ofLp(x)(i,a.1) * t(i,a.2)',
  'source':'A3.SS2.p1.m6,m7,m8','interpretation':'d rows and r*r columns indexed (Gaussian-column,cosine-coordinate). gamma_i is the coordinate vector x_(i,.) and its tensor factor occurs first.',
  'fallback_audit':'Inverse sqrt is mathematically nonzero because hq implies d>=2; the d=0 totalized branch is outside the admitted source domain, not a public normalization assumption.'},
 {'name':'ProbabilityTheory.multivariateGaussian','kind':'literal','audit':'TOP_LEVEL_BODY_INSPECTED',
  'literal_input':'inputs/multivariateGaussian-literal-definition.txt','literal_input_sha256':'0d32e6c37ec13dc0bdbce701ed77a7e2da591a748c8d8f92eb81a72cc2228171',
  'interpretation':'(stdGaussian EuclideanSpace).map (fun x => mean + toEuclideanCLM (CFC.sqrt covariance) x). It has no caller proof argument and is not selected from a theorem-shaped witness.',
  'fallback_audit':'The literal documentation states that non-PSD covariance has CFC.sqrt S=0 and degenerates to dirac mean. This is a genuine ambient convention, not silently denied. Here S is exactly I; PSD(I) and CFC.sqrt I=I are internal obligations. No false fallback exclusion is accepted from the projection annotations alone.'},
 {'name':'stdGaussian','kind':'literal','audit':'LITERAL_DEFINITION_INSPECTED',
  'literal_input':'inputs/additional-canonical-Gaussian-definitions.json',
  'interpretation':'Product of gaussianReal 0 1 over Fin(finrank Real E), pushed through the standard orthonormal-basis coordinate sum.',
  'fallback_audit':'No explicit if/default branch in the supplied body. To identify its law on WithLp Euclidean coordinates, the basis/coordinate relationship or basis-invariant Gaussian moment property must be proved internally. Finrank, standard basis, Measure.pi and map remain canonical mathematical operations, not assumed moments.'},
 {'name':'gaussianReal','kind':'literal','audit':'LITERAL_DEFINITION_INSPECTED',
  'literal_input':'inputs/additional-canonical-Gaussian-definitions.json',
  'interpretation':'if v=0 then dirac mean else volume.withDensity(gaussianPDF mean v).',
  'fallback_audit':'The zero-variance dirac branch is explicit. stdGaussian calls it at v=1, so the nonzero density branch applies. The canonical Gaussian density/moments are proof obligations, not caller binders.'},
 {'name':'Integrable / entrywise integral','kind':'literal-canonical-operations','audit':'CONCLUSION_STRENGTHENING_EXPLICIT',
  'interpretation':'Both Gram entries are explicitly Bochner integrable and their actual mu integrals are specified. This supplies the well-defined expectation semantics implicit in the source.',
  'fallback_audit':'Totalized integral equality alone would not certify expectation. The given type separately demands integrability in its conclusion, so no zero-valued undefined-integral fallback can discharge the intended consumer without that additional proof.'}
]

obligations=[
 {'id':'O.index-translation','kind':'typing-and-literal-adapter','statement':'Translate source i in 1..d to Fin d by i_source=i.val+1, source cosine index 0..q to Fin(q+1), and r=q+1. Check d casts/positive denominator and all q=0 cases internally.', 'source_nodes':['domain','theta','rn','frame','D']},
 {'id':'O.matrix-sum-entries','kind':'finite-algebra','statement':'Expand t^Tt, t^TDt and both actual B-Gram entries as finite row sums. Collapse the literal diagonal D. Use pair-index equality for the r^2 identity and scalar square normalization, with no arbitrary Gram-identity premise.', 'source_nodes':['linear.entry-algebra','matrix.expectation-algebra']},
 {'id':'O.det-unweighted-source-steps','kind':'source-proof-obligations','statement':'Discharge the raw ancestors of det.unweighted internally: sine telescoping/nonzero cancellation; constant-coordinate cases; j+k/j-k windows with the zero-frequency diagonal case; sqrt(2) scaling and matrix entry extensionality. Weighted Gram and row norm are not additional parents. No ingredient becomes a caller hypothesis.', 'source_nodes':['det.unweighted']},
 {'id':'O.det-weighted-source-steps','kind':'source-proof-obligations','statement':'Discharge the raw ancestors of det.weighted internally: cosine cancellation; all four n+/-j+/-k integer frequencies in [1,2d); triple-product expansion; zero/positive-coordinate scalings and matrix entry extensionality. Unweighted Gram and row norm are not additional parents. No ingredient becomes a caller hypothesis.', 'source_nodes':['det.weighted']},
 {'id':'O.det-row-norm-source-steps','kind':'source-proof-obligations','statement':'Discharge the raw ancestors of det.row-norm internally: finite Euclidean sum of coordinate squares, sqrt(2)^2=2, cos^2<=1 and 1+2q<=2(q+1). Neither Gram orthogonality branch is a parent. No ingredient becomes a caller hypothesis.', 'source_nodes':['det.row-norm']},
 {'id':'O.identity-covariance','kind':'canonical-definition-side-condition','statement':'For the actual finite product index, identity is PSD, the canonical square root of identity is identity, zero mean translates by zero, and the induced Euclidean matrix map has the expected action. This excludes the documented non-PSD dirac convention internally; do not add PSD/covariance-square-root certificates as source binders.', 'source_nodes':['gaussian.input','gaussian.second-moment']},
 {'id':'O.actual-Gaussian-coordinate-moments','kind':'canonical-Gaussian-moment-obligation','statement':'Under the literal mu=multivariateGaussian 0 I, prove finite coordinate second moments and E[x_(i,a)x_(i,b)]=delta_ab. Derive any needed correspondence to independent g_a or gamma_i from the actual canonical law. Row independence is unnecessary for the two means and must not be supplied as an extra premise.', 'source_nodes':['gaussian.input','gaussian.second-moment']},
 {'id':'O.entry-integrability','kind':'source-implicit-well-definedness','statement':'Prove each coordinate product integrable using actual Gaussian finite second moments, then each Gram entry as a finite deterministic linear combination integrable. Weighted/unweighted entries, diagonal/off-diagonal entries and q=0 all remain included.', 'source_nodes':['gaussian.second-moment','matrix.expectation-algebra']},
 {'id':'O.B-normalization','kind':'literal-normalization','statement':'From hq obtain d>0, sqrt(d)>0, and ((sqrt d)^-1)^2=1/d; pull this deterministic coefficient and t/D factors through finite integrals. No caller-supplied normalization witness.', 'source_nodes':['domain','B','matrix.expectation-algebra']}
]

overlay={'schema':'astis-post-freeze-typed-overlay/v1','raw_source_sha256':raw_graph['raw_sha256'],
 'phase1_source_graph_sha256':sha256((O/'phase1/source_graph.json').read_bytes()).hexdigest(),
 'phase1_mutation':False,
 'input_projection_sha256':sha256((P/'inputs/strict-statement-projection.json').read_bytes()).hexdigest(),
 'exact_signatures':{k:projection[k] for k in ['producer_signature','consumer_signature']},
 'exact_signature_sha256':{k:sha256(projection[k].encode()).hexdigest() for k in ['producer_signature','consumer_signature']},
 'independent_observation':{'public':'All three supplied public deterministic conclusions match the literal source slice on its full source q,d range.',
 'private':'The supplied private type targets actual canonical Gaussian entrywise integrability and means. Its structure matches the two source expectation clauses, with explicit well-definedness conclusions. Actual-law/normalization/second-moment obligations remain internal and unproved.',
 'excess_caller_binders_found':[],'hidden_project_Prop_bundles_found':[],
 'annotation_handling':'The projection binder_audit, meaning and literal_conventions fields were read as untrusted producer annotations; independent classifications are in binder_definition_audit.json. No prior verdict was supplied or assumed.',
 'not_a_verdict':'This source-graph author observation does not replace distinct source verification, type elaboration, proof checks or publication acceptance.'},
 'typed_roots':roots,'overlay_edges':[{'parents':x['raw_source_nodes'],'consumer':x['typed_root'],'kind':'source-to-type-correspondence','not_Lean_dependency':True} for x in roots],
 'definition_audit':'binder_definition_audit.json','proof_obligations':'proof_obligations.json',
 'remaining_boundary':['all mathematical obligations unproved in this author task','independent topology/source review pending','Range(B)=Krylov','C.6 concentration','full Lemma 4.4','either main result'],
 'additional_minimal_definitions_required_now':[],
 'definition_audit_boundary':'The supplied complete multivariateGaussian top-level definition and stdGaussian/gaussianReal literals suffice to distinguish an actual fixed law from symbolic assumed moments and identify its branch conventions. Canonical CFC/Measure/Euclidean operations and Gaussian density/moment identities remain explicit mathematical proof obligations; no implementation/API claims are inferred from their names or comments.'}
dump('typed_overlay.json',overlay)
dump('binder_definition_audit.json',{'source_raw_sha256':raw_graph['raw_sha256'],'independent_binder_audit':binders,
 'source_bindings_not_promoted':['deterministic Gram identities','Gaussian covariance/moments','integrability','independence of rows','PSD identity certificate','CFC sqrt identity certificate','rank/range','concentration event','tau threshold'],
 'definitions':definitions,'fallback_summary':'t zero-index branch is literal source semantics. d=0 normalization branches are ruled out by the existing source hq. gaussianReal variance-zero and multivariate non-PSD conventions are real ambient branches; their inactivity at literal v=1 and S=I must be justified inside the proof. Explicit integrability prevents a totalized-integral-only closure.'})
dump('proof_obligations.json',{'status':'OPEN_SOURCE_AND_DEFINITION_OBLIGATIONS_NOT_PROOFS','obligations':obligations,
 'rule':'No listed proof ingredient may be moved into a source theorem caller binder merely because an internal producer exists.'})
report={'status':'TYPED_OVERLAY_SHAPE_CHECK_ONLY_PASS','typed_roots':len(roots),'public_roots':3,'private_roots':4,
 'caller_binders':'d,q,hq only; a,b are conclusion indices; all theta,t,D,mu,B are literal lets',
 'extra_caller_Prop_binders':0,'open_internal_obligations':len(obligations),
 'literal_definition_hashes_checked':[x['name'] for x in supplement['definitions']],
 'phase1_source_graph_unchanged':True,'independent_source_review':'PENDING'}
dump('logs/author_overlay_output.json',report)
stdout=json.dumps(report,ensure_ascii=False)+'\n'
(P/'logs/author_overlay.stdout').write_text(stdout)
(P/'logs/author_overlay.stderr').write_bytes(b'')
print(stdout,end='')
