# Exact sealed-interface source judgment

This judgment was made after the immutable phase-1 source cognition freeze, using only the exact 5842-byte sealed projection (SHA-256 `e8322849cd533289522de2de96ae5913364b1446dee114d4224956c1ced02fca`) and my own raw-source inventory. It is not an implementation review or approval of my own source coverage.

The public signature hash is `4ba04efc22eb664771b1b2f471dc62cd50694a12f70712010287908788362d91`. My source judgment is **SOURCE_STATEMENT_PASS, with independent topology/coverage review and implementation proof obligations still open**. I find no source-statement HOLD in this exact bounded public numeric slice. The private signature hash is `e24c33732826ea528bfd2d9f959b8963a022b35989f6e5740e3f7445a23de7d5`; my judgment is **MATHEMATICALLY_VALID_PRIVATE_ADAPTATION**, with the stated non-Anchor scope essential.

The public conclusions are the actual-law meanings of the source's unnamed lower bounds in `S4.SS3.SSS0.Px2.p2.2` and the right-hand signal inequality in `S4.Ex24`. Root selection, the requested source anchors, or the projection's own definition-audit labels are not evidence of correctness. The independent evidence is the raw Appendix C.3 moment formulas, the normalized-bias proof, and the scalar estimates spelled out below and in the conditional-discharge audit.

## Quantifiers, scalar domains, and casts

The only public logical inputs are real `δ` with `0<δ<1`, eventual natural dimension `d`, real `κ` with `2≤κ≤(d:ℝ)^(1-δ)`, and natural `q` with its original source cap. The existential natural `d₀` is before both varying `κ` and `q`; it must depend on `δ` alone. It is an output, not an assumed eventual-domain certificate. A single scalar majorant depending on `δ,d` proves the required uniformity; see `CD02` in the separate audit.

No `ε`, oracle algorithm, successful-sampler assumption, `τ`, spectral event, moment certificate, or probability certificate is a public input. The source proof introduced these numeric estimates inside a larger algorithmic contradiction, but the estimate derivations use only the scalar parameter range. Extracting them without those unused assumptions preserves the mathematical content and strengthens neither their numeric conclusion nor their domain.

`n=2*q+1` is a natural index. Its real cast is exactly `2*(q:ℝ)+1`, so `n≥1`, including the `q=0` case. No rounding of the query cap is performed. For sufficiently large `d` selected before `κ,q`, `d≥2`, `1≤n<d`, and `(n:ℝ)+sqrt κ≤(d:ℝ)`. Therefore all real powers have positive dimension base, the logarithm is on `d>1`, and square roots are taken at `κ≥2`. These domains are internally derived; they are not hidden binder additions. Dimension/query natural casts and `κ,δ` real powers agree with the paper's integer dimension and query count and real scalar parameter regimes.

The grid `θ i=((i.val:ℝ)+1/2)*π/(d:ℝ)` is the source grid under `i_source=i.val+1`. The source coefficient `(κ-1)/2*cos θ` is algebraically identical to the projected eigenvalue formula. No endpoint-grid or indexing change occurs. The dimension threshold excludes `d=0` and `d=1` internally; the public theorem makes no claim for every dimension independently of its existential threshold.

## Actual law and literal moment meanings

`Λ` is the diagonal **precision** matrix. The projected law is centered Gaussian with covariance `Λ⁻¹`, matching raw `S4.Thmtheorem5` and `A3.SS3.p4`; it is not Gaussian with covariance `Λ`. For each grid coordinate, `λ_i≥(κ+1)/2-(κ-1)/2=1` and `λ_i≤κ`, by the cosine range and `κ≥2`. Consequently the precision is positive definite and invertible, and its inverse is the positive diagonal covariance with entries `1/λ_i`. The actual law is a probability measure and its coordinate second/fourth moments and every polynomial integral used here are finite. These standard Gaussian facts are explicitly exposed as `gap:gaussian-semantics` because the consulted source states/uses them without foundational proofs. A later proof must establish them internally for the actual measure; they may not become free hypotheses.

`Q x=Σ_i cos((n:ℝ)θ_i)*x_i²` is exactly `UᵀD_nU` in diagonal coordinates. `M=∫||x||² dμ`, and the projected lower-case `b=∫Q dμ` denotes the source `μ_n`. The projected upper-case `B=(1-exp(-4))*exp(-3)` denotes the source's lower-case scalar `b` in `S4.Ex23`. `β=abs(b)/M` has no dimension factor. The source exact means identify these actual integrals with its trace formulas; this is an actual-law statement, not a theorem conditional on a supplied moment package.

The integrals are Bochner integrals with real integrands. Their formal totalized behavior outside integrability does not alter the intended theorem because all relevant integrability is mathematically true and must be proved on the selected domain. Similarly, standard totalized inverse/log/power conventions outside the selected domain add no new project-owned fallback definition. This source-only audit accepts the literal mathematical interpretation supplied by the projection; it has not inspected or certified the concrete library API or declaration bodies.

From the exact mean formula, `M>0`. From `0<ρ<1` and `1≤n<d`, `ρ^n>ρ^(2d-n)`, so `(-1)^n b>0` and `β>0`. All denominator positivity and normalization are proved consequences, not premises. The five public conjunctions are exact literal numeric claims; no `True` predicate, arbitrary law, or supplied estimate substitutes for them.

## Independent derivation of the numeric boundary

The source's conditional bias estimate applies because the uniform domain majorant gives `d-n≥sqrt κ`. It yields

`β ≥ (1-exp(-4))*exp(-3n/sqrt κ)`.

The source query cap gives `3n/sqrt κ ≤3+(3δ/128)log d ≤3+(δ/4)log d`, using `sqrt κ≥1`, `δ>0`, and `log d≥0`. Thus `β≥B*d^(-δ/4)` with `B>0`. This is an internal proof ingredient, not an extra exported premise.

The source exact norm mean and `d≥sqrt κ` give `ρ^(2d)≤exp(-2)<1/3`, so

`M = (d/sqrt κ)*(1-ρ^(2d))/(1+ρ^(2d)) ≥d/(2sqrt κ)`.

Since `sqrt κ≤d^((1-δ)/2)`, positive-base real-power algebra gives `M≥d^((1+δ)/2)/2`. Combining this with the nonnegative bias lower bound yields

`Mβ² ≥ [d^((1+δ)/2)/2]*[B² d^(-δ/2)] = (B²/2)sqrt d`.

This uses the right-hand component of `S4.Ex24`. Its neighboring `τ/β→0` estimate is a different source component and is not a dependency of the signal product. The public producer does not prove `Mβ²≥320` at every dimension, the shifted test, an algorithmic probability bound, the Gaussian lower bound theorem, or its accuracy dependence.

## The private event application

The private event is literally `{x | (-1:ℝ)^n*Q x≤0}` under the same diagonal inverse-precision Gaussian. It is measurable because `Q` is a finite polynomial in coordinates. Its probability is finite because the law has total mass one, so `.toReal` agrees with ordinary real probability. The event is not parameterized by a free law or a moment/probability certificate.

Let `Z=(-1)^n Q`. The source exact signed mean gives `EZ=abs(b)=βM>0`, and Appendix C.3 gives `Var Z=Var Q≤2M`. Chebyshev directly yields `P[Z≤0]≤2/(Mβ²)`. The public numeric lower bound and `B>0` allow a further threshold enlargement, still before `κ,q`, so `Mβ²≥20`; hence the private event probability is at most `1/10`. This is a valid derived application of the paper's moments and probability method.

The source detector instead uses a rotated law and subtracts `2τ||x||²` from the signed cosine quadratic. Its event is `S_A>0`, and its target-probability conclusion is full `S4.Ex26`. The zero-threshold private event does not establish that shifted-event statement. It cannot be advertised as a Registry node or additional source Anchor. The separate graph marks the application edges as private adaptations and leaves all shifted-detector and `τ` obligations outside both selected root closures.

## Remaining limits

There is no identified mathematical source contradiction or binder/definition mismatch in the sealed numeric statement. The source graph still names omitted standard inputs: Gaussian semantics/moments/integrability, geometric series and uniform convergence, trigonometric grid identities, log/integral calculus, real-power asymptotics, and, for the private application, Chebyshev. These are source-proof obligations, not proofs I have checked in Lean and not allegations that the paper is false.

No implementation, Lean API, proof term, lesson, audit, frontier, other reviewer, or prior verdict was consulted. The extractor cannot approve its own coverage. Source-topology/root-closure review by a distinct reviewer remains required, followed separately by actual proof construction, compilation, and semantic review at the exact sealed signatures.
