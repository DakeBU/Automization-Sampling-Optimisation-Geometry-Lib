import AutoSamplingTheory.ExampleCases.ProximalBPS.ActualPrescribedStateReversal
import AutoSamplingTheory.ExampleCases.ProximalBPS.ActualPrescribedPathDensity

namespace PBPSArcReversal100
open MeasureTheory Set
open scoped Classical
noncomputable section
set_option autoImplicit false

theorem active_arc (n : ℕ) (a : Fin (n+1) → ℝ) (ha : a 0 = 0)
    (s : ℝ) (hs : 0 ≤ s) :
    ∃ j, a j ≤ s ∧ ∀ k, j < k → s < a k := by
  let q : Finset (Fin (n+1)) := Finset.univ.filter (fun j => a j ≤ s)
  have hq : q.Nonempty := ⟨0, by simp [q, ha, hs]⟩
  refine ⟨q.max' hq, (Finset.mem_filter.mp (Finset.max'_mem q hq)).2, ?_⟩
  intro k hk
  by_contra h
  have hm : k ∈ q := by simp [q, le_of_not_gt h]
  exact (not_le_of_gt hk) (Finset.le_max' q k hm)

theorem path_reversal {X : Type*} (n : ℕ) (T : ℝ)
    (a b : Fin (n+2) → ℝ) (ha : Monotone a)
    (hb0 : b 0 = 0) (hbT : b (Fin.last (n+1)) = T)
    (hbl : ∀ j : Fin (n+1), b j.castSucc = T - a j.rev.succ)
    (hbr : ∀ j : Fin (n+1), b j.succ = T - a j.rev.castSucc)
    (Φ : ℝ → X → X) (R : X → X) (hR : Function.Involutive R)
    (hgroup : ∀ u v x, Φ (u+v) x = Φ u (Φ v x))
    (hrev : ∀ u x, R (Φ u (R x)) = Φ (-u) x)
    (post barPost : Fin (n+1) → X) (f g : ℝ → X)
    (hstate : ∀ j, barPost j =
      R (Φ (a j.rev.succ - a j.rev.castSucc) (post j.rev)))
    (hf : ∀ s, 0 ≤ s → s ≤ T → ∀ j : Fin (n+1),
      a j.castSucc ≤ s → (∀ k, j < k → s < a k.castSucc) →
      f s = Φ (s-a j.castSucc) (post j))
    (hg : ∀ s, 0 ≤ s → s ≤ T → ∀ j : Fin (n+1),
      b j.castSucc ≤ s → (∀ k, j < k → s < b k.castSucc) →
      g s = Φ (s-b j.castSucc) (barPost j)) :
    ∀ s, 0 ≤ s → s ≤ T → (∀ i : Fin n, s ≠ b i.succ.castSucc) →
      g s = R (f (T-s)) := by
  intro s hs0 hsT hne
  obtain ⟨j, hj, hjafter⟩ := active_arc n (fun j => b j.castSucc) (by simpa using hb0) s hs0
  have hnext : s ≤ b j.succ := by
    induction j using Fin.lastCases with
    | last => simpa only [Fin.succ_last, hbT] using hsT
    | cast i =>
      simpa only [Fin.succ_castSucc] using (hjafter i.succ (Fin.castSucc_lt_succ i)).le
  have hstart : a j.rev.castSucc ≤ T-s := by
    rw [hbr] at hnext
    linarith
  have hafter : ∀ k : Fin (n+1), j.rev < k → T-s < a k.castSucc := by
    intro k hk
    have hstrict : b j.castSucc < s := by
      induction j using Fin.cases with
      | zero => simpa only [Fin.rev_zero, not_lt_of_ge (Fin.le_last k)] using hk
      | succ i => exact lt_of_le_of_ne hj (hne i).symm
    have hidx : j.rev.succ ≤ k.castSucc := by
      exact_mod_cast hk
    have ham := ha hidx
    rw [hbl] at hstrict
    linarith
  have hc (u : ℝ) (x : X) : Φ u (R x) = R (Φ (-u) x) := by
    simpa only [hR] using congrArg R (hrev u x)
  rw [hg s hs0 hsT j hj hjafter,
    hf (T-s) (sub_nonneg.mpr hsT) (by linarith) j.rev hstart hafter,
    hstate, hc, ← hgroup]
  congr 2
  rw [hbl]
  ring

#print axioms path_reversal
end
end PBPSArcReversal100
