"""Freeze requested inline-LaTeX reader revision; preserve frozen v1/v2 bytes."""
from pathlib import Path
import difflib
import gzip
import hashlib
import json

ROOT = Path('/Users/zhouhuanjian/ASTIS-GC')
STAGE = ROOT / '.astis/huanjian-gc-ex72-integration-20261107/independent-reader-preparation'
OUT = ROOT / 'research-wiki/paper-contributions/GaussianComplexity/ex72-integration-20261107/independent-integration-reader-review'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def archive(path, raw):
    assert not path.exists()
    packed = gzip.compress(raw, compresslevel=9, mtime=0)
    path.write_bytes(packed)
    assert gzip.decompress(path.read_bytes()) == raw
    return {'path': str(path.relative_to(ROOT)), 'raw_sha256': sha(raw),
            'gzip_sha256': sha(packed), 'raw_bytes': len(raw), 'gzip_bytes': len(packed)}


raw_v2 = (OUT / 'preparation-report-v2.json').read_bytes()
assert sha(raw_v2) == '55078c1c664c8c283c9ea234943680a42983ad2e2d1cb25fd94078951a220639'
report = json.loads(raw_v2)
rows = report['shared_paths']
row = rows[4]
old = gzip.decompress((ROOT / row['planned_after_archive']['path']).read_bytes())
old_frontier = json.loads(old)
old_boundary = old_frontier['cases'][4]['theorems'][0]['boundary']
start = 'Actual amplified TV Ex72 is now also compiled and independently source-reviewed:'
end = ' The source-specific oracle/transcript/TV-precision/deterministic-query-cap composition and expected-cost reduction still require explicit proofs.'
assert old_boundary.count(start) == old_boundary.count(end) == 1
prefix, added = old_boundary.split(start, 1)
_, suffix = added.split(end, 1)
new_part = r'Actual amplified TV Ex72 is now also compiled and independently source-reviewed: for \(3\le n\le d,\ \kappa\ge4\), the measurable-event TV of the actual two common-sign matrix-prior Gaussian binds has the explicit exponential lower bound \(\operatorname{TV}(\bar\pi_+,\bar\pi_-)\ge1-\exp\!\left[-\frac{k}{8}e^{-10n/\sqrt\kappa}\right]\), where \(k=\lfloor d/n\rfloor\). Actual probability and analytic adapters are proved internally, including both residual cases. The focused actual-TV consumer gives \(\operatorname{TV}(\bar\pi_+,\bar\pi_-)\ge\frac12\) under the explicit threshold \(\frac{k}{8}e^{-10n/\sqrt\kappa}\ge\log 2\).'
new_boundary = prefix + new_part + end + suffix
old_scalar = json.dumps(old_boundary, ensure_ascii=False).encode()
new_scalar = json.dumps(new_boundary, ensure_ascii=False).encode()
assert old.count(old_scalar) == 1
new = old.replace(old_scalar, new_scalar, 1)
new_frontier = json.loads(new)
expected_frontier = json.loads(old)
expected_frontier['cases'][4]['theorems'][0]['boundary'] = new_boundary
assert new_frontier == expected_frontier
assert new_boundary.startswith(prefix) and new_boundary.endswith(end + suffix)
assert 'Eq25 scalar power estimate now has a true ambient-law affinity-integral consumer.' in prefix
for guard in ('Actual amplified TV Ex72', 'measurable-event', 'explicit exponential lower bound',
              'worst-case deterministic query cap', 'not an expected-cost lower bound without a separate reduction'):
    assert guard in new_boundary
assert 'floor(d/n)/8*exp' not in new_part and 'scale' not in new_part
row['planned_after_archive'] = archive(STAGE / 'shared-path-5.planned-after.v3.raw.gz', new)
row['planned_after_sha256'] = sha(new)
row['planned_after_bytes'] = len(new)
raw_diff = b''
for item in rows:
    before = gzip.decompress((ROOT / item['before_archive']['path']).read_bytes()) if item['before_exists'] else b''
    after = gzip.decompress((ROOT / item['planned_after_archive']['path']).read_bytes())
    assert sha(after) == item['planned_after_sha256']
    raw_diff += b''.join(difflib.diff_bytes(difflib.unified_diff,
        before.splitlines(keepends=True), after.splitlines(keepends=True),
        fromfile=(('a/' + item['path']).encode() if item['before_exists'] else b'/dev/null'),
        tofile=('b/' + item['path']).encode()))
original = STAGE / 'reviewed-planned-shared.v3.original.diff'
assert not original.exists()
original.write_bytes(raw_diff)
diff_archive = archive(OUT / 'reviewed-planned-shared.v3.diff.gz', raw_diff)
report['raw_diff'] = diff_archive
report['proposal_version'] = 3
report['preserved_predecessor'] = {'path': str((OUT / 'preparation-report-v2.json').relative_to(ROOT)),
                                   'sha256': sha(raw_v2),
                                   'change': 'Root-requested inline LaTeX domain/bound/threshold and shorter analytic-adapter sentence in the new Ex72 boundary prose only. Every preexisting prefix/suffix and all six other planned files are unchanged. Frozen v1/v2 raw artifacts are retained without normalization.'}
report['raw_diff_original_path'] = str(original.relative_to(ROOT))
for filename, obj in [('preparation-report-v3.json', report),
                      ('raw-artifact-manifest-v3.json', {'rule': 'Use exact bytes; do not normalize frozen v1/v2/v3 raw diff context whitespace.',
                        'preserved_predecessor': report['preserved_predecessor'],
                        'diff': {'original_path': str(original.relative_to(ROOT)), **diff_archive}, 'shared_paths': rows})]:
    path = OUT / filename
    assert not path.exists()
    path.write_bytes((json.dumps(obj, ensure_ascii=False, indent=2) + '\n').encode())
archive(OUT / 'executed-refine-reader-math-v3.py.gz', Path(__file__).read_bytes())
print(json.dumps({'report': 'preparation-report-v3.json',
                  'report_sha256': sha((OUT / 'preparation-report-v3.json').read_bytes()),
                  'raw_diff_sha256': sha(raw_diff),
                  'frontier_planned_after_sha256': sha(new),
                  'new_ex72_reader_prose': new_part,
                  'changed_since_v2': 'New Ex72 reader prose only; all preexisting boundary context and all six other planned files are byte-identical.'}, ensure_ascii=False, indent=2))
