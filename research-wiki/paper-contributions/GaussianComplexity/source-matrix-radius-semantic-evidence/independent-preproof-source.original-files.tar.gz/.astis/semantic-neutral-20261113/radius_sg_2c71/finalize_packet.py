"""Validate owned packet byte locators, then seal its portable inventory."""
from pathlib import Path
import json,hashlib,datetime
R=Path(__file__).parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(n,j):
 with (R/n).open('x') as f:json.dump(j,f,ensure_ascii=False,indent=2);f.write('\n')
S=(R/'originals/2610.20492v1.html').read_bytes();T=S.decode()
checks=[]
for n in ['source-unit-locators-v2.json','raw-source-locators.json']:
 j=json.loads((R/n).read_text());units=j.get('units',j.get('selected',[]))
 for u in units:
  a,b=u['char'];x,y=u['raw_utf8_byte'];raw=(R/u['original_path']).read_bytes()
  assert T[a:b].encode()==S[x:y]==raw
  assert hashlib.sha256(raw).hexdigest()==u['sha256']
 checks.append(dict(check=n,result='pass',units=len(units)))
for n in ['raw-source-coverage-freeze-v1.json','source-proof-graph-freeze-v1.json','source-unit-locators-v2.json']:
 r=json.loads((R/'raw-freeze-receipt-v1.json').read_text());expected=next(x['sha256'] for x in r['files'] if x['path']==n)
 assert sha(R/n)==expected
 checks.append(dict(check='unchanged raw freeze '+n,result='pass'))
coverage=json.loads((R/'raw-source-coverage-freeze-v1.json').read_text())['coverage']
assert len({x['source_unit'] for x in coverage})==len(coverage)==87
assert all(x['disposition'] in ['NODE','EXCLUDED'] and x['reason'] for x in coverage)
graph=json.loads((R/'source-proof-graph-freeze-v1.json').read_text());ids={n['id'] for n in graph['nodes']}
assert all(e['prerequisite'] in ids and e['consumer'] in ids and e['consumer_use_site'] for e in graph['edges'])
assert all(set(x['nodes'])<=ids for x in coverage)
checks.append(dict(check='coverage/edge structural consistency',result='pass',coverage_units=87,nodes=len(ids),edges=len(graph['edges']),downstream_edges=len(graph['downstream_consumer_edges']),limit='Structural consistency only, not independent mathematical topology approval.'))
for p in R.rglob('*.json'):json.loads(p.read_text())
checks.append(dict(check='all existing JSON parses',result='pass'))
assert json.loads((R/'ConcreteMeaningProbeV2.receipt.json').read_text())['exit_code']==0
checks.append(dict(check='proof-free concrete norm/meaning print probe',result='exit0',evidence='ConcreteMeaningProbeV2.receipt.json',limit='No target theorem or proof success asserted.'))
dump('local-validation-v1.json',dict(checks=checks,no_Lean_target_proof_or_source_equivalence=True,independent_topology_review='pending distinct role; extractor cannot approve'))

key=['raw-freeze-receipt-v1.json','raw-source-coverage-freeze-v1.json','source-proof-graph-freeze-v1.json','source-unit-locators-v2.json','binder-definition-audit-v1.json','internal-port-obligations-v1.json','command-trace-v1.json','post-freeze-meaning-originals-v1.json','local-validation-v1.json','ConcreteMeaningProbeV2.receipt.json']
dump('packet-summary-v1.json',dict(actor='radius_sg_2c71',scope='GaussianComplexity p13 radius preparation, actual original Y/mean/centered/cosine experiment',
 result='No excess binder detected; literal formulas and concrete real L2Operator norm meaning aligned. Actual integrability and norm/mean/radius proofs remain internal/open.',
 source_original_sha256=hashlib.sha256(S).hexdigest(),statement_seal_sha256='49d5fa00c9ae90d65878d955fab59d6a4bc03e942501677719881f3d26bf1a72',
 source_graph='PROPOSED:87 exhaustive paragraph/display dispositions,21 nodes,33 source edges,5 downstream consumer-use edges; distinct topology challenge pending.',
 retained='q=0; exact closed cutoff; actual Bochner mean; sole2q+1<d source premise; exact2r(L+1)/d radius.',
 source_gap='Five omitted-derivation SOURCE_GAP nodes; no source-invalid or extra-hypothesis defect established.',
 remaining='Nine internal proof/library applicability ports. No target API/proof search, target implementation, source/Lean equivalence or proof success claim.',
 scope_exclusions='p14 variance separate; p15 matrix Bernstein/tail application downstream; p16-p19 concentration budgets/fullLemma4.4 outside this packet.',
 evidence=[dict(path=n,sha256=sha(R/n)) for n in key],
 limits=['Extractor cannot approve own topology.','Initial inline extraction commands are recorded by argv/input/output/role rather than verbatim original heredoc text; exact raw inputs and reproducible later source builder are portable.','All predecessors retained, including V1 derived text and unnecessary-measurable-instance probe failures.'],
 canonical_mutations=0,new_goal_or_detached_work=0))
originals=[]
for p in sorted(R.rglob('*')):
 if p.is_file() and ('originals' in p.relative_to(R).parts or p.parent.name=='raw-units' and p.suffix=='.html'):
  originals.append(dict(path=str(p.relative_to(R)),bytes=p.stat().st_size,sha256=sha(p),kind='byte-original'))
dump('portable-byte-original-manifest-v1.json',dict(root='.',source='originals/2610.20492v1.html',source_sha256=hashlib.sha256(S).hexdigest(),
 originals=originals,scope='Raw paper/protocol/formation/seal/environment originals and exact raw source/standard-meaning slices. Derived text is never a byte-original.',
 no_imported_ASTIS_implementation_body=True))
files=[]
for p in sorted(R.rglob('*')):
 if p.is_file():files.append(dict(path=str(p.relative_to(R)),bytes=p.stat().st_size,sha256=sha(p)))
dump('output-manifest-v1.json',dict(root='.',files=files,excludes=['output-manifest-v1.json','packet-seal-v1.json'],
    independent_mathematical_status='No topology self-approval, no target proof/Lean-source equivalence claim'))
dump('packet-seal-v1.json',dict(actor='radius_sg_2c71',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    output_manifest=dict(path='output-manifest-v1.json',sha256=sha(R/'output-manifest-v1.json')),
    byte_original_manifest=dict(path='portable-byte-original-manifest-v1.json',sha256=sha(R/'portable-byte-original-manifest-v1.json')),
    summary=dict(path='packet-summary-v1.json',sha256=sha(R/'packet-summary-v1.json')),
    immutable_from_here=True,independent_topology='pending distinct role',source_and_Lean_proof_status='No proof or source/Lean equivalence assertion'))
print(json.dumps(dict(root=str(R),files=len(files),byte_originals=len(originals),seal_sha256=sha(R/'packet-seal-v1.json'),
    output_manifest_sha256=sha(R/'output-manifest-v1.json'),byte_original_manifest_sha256=sha(R/'portable-byte-original-manifest-v1.json'),
    binder_definition_sha256=sha(R/'binder-definition-audit-v1.json')),indent=2))
