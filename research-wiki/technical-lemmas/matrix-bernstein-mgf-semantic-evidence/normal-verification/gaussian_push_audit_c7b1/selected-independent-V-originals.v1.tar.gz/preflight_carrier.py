#!/usr/bin/env python3
"""Independent immutable-carrier checks; this file performs no normal API call."""
from pathlib import Path
import copy
import gzip
import hashlib
import json
import os
import re
import subprocess

ROOT = Path('/Users/zhouhuanjian/ASTIS-GC')
OWN = Path(__file__).resolve().parent
COMMIT = '6abc79ed4c012c1d506c17b9824257769c18c635'
TARGET = 'ASTIS-SA-20261114-MatrixBernsteinMgf'
ACTOR = '/root/gaussian_push_audit_c7b1'
E = 'research-wiki/technical-lemmas/matrix-bernstein-mgf-semantic-evidence/'
B = E + 'reader-runtime-originals/'
ENV = dict(os.environ, GIT_OPTIONAL_LOCKS='0', PYTHONDONTWRITEBYTECODE='1')

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, env=ENV)

def sha(data):
    return hashlib.sha256(data).hexdigest()

def blob(path):
    return git('show', COMMIT + ':' + path)

def obj(path):
    return json.loads(blob(path))

def rec(path):
    data = blob(path)
    return {'file': path, 'sha256': sha(data), 'bytes': len(data)}

def dump(name, value):
    p = OWN / name
    assert not p.exists(), p
    p.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

assert git('rev-parse', 'HEAD').decode().strip() == COMMIT
assert subprocess.run(['git', 'diff', '--quiet', 'HEAD', '--'], cwd=ROOT, env=ENV).returncode == 0
assert not git('diff', '--cached', '--name-only')
four = {
    'AutoSamplingTheory/TechnicalLemmas/Probability/MatrixBernsteinMgf.lean': 'b46bb5a3eabbcadf31fee93d48c1fbabf9b5b42cf717a8a17c8c8cfdd210a3f3',
    'Tests/GaussianComplexityBernsteinWeightedMgf.lean': '42f372143ffe52e4372271d09fbc6b67391739f2fe2a5fbfffe6cd9fa586936e',
    'website/content/declaration_lessons/huanjian-matrix-bernstein-mgf.json': 'd88b96ad5397be27a9f234a6b3ac993a236267591dd4c922c7ba7aa1915f28c0',
    'website/content/publications/huanjian-matrix-bernstein-mgf.json': '51580fc5033dcfb049ab5e1bc8754f42666f27bdedd65eda60029f40b2d96e1c',
}
for path, expected in four.items():
    assert sha(blob(path)) == expected == sha((ROOT / path).read_bytes())

ledger = (ROOT / 'runs/substantive_advances.jsonl').read_bytes()
assert ledger == blob('runs/substantive_advances.jsonl') and ledger.endswith(b'\n')
events = [json.loads(line) for line in ledger.splitlines()]
target_events = [x for x in events if x.get('advance_id') == TARGET]
pls = [x for x in target_events if x.get('to_state') == 'PROVED_LOCAL']
assert len(pls) == 1 and target_events[-1]['to_state'] == 'PROVED_LOCAL'
assert not any(x.get('to_state') == 'VERIFIED' for x in target_events)
pl = pls[0]['evidence']
assert len(pl) == 24 and pl == obj(E + 'PROVED_LOCAL-evidence.full.json')
assert pl == json.loads((OWN.parent / 'runtime/normalV-plan.draft.v2.json').read_text())['original_PL_evidence_inline']
owner = pls[0]['worker_id']
assert owner == 'huanjian_20261114_matrix_bernstein_mgf' and ACTOR != owner

# Check every explicit original PL file+SHA reference against immutable blobs.
references = {}
def walk(value):
    if isinstance(value, dict):
        if isinstance(value.get('file'), str) and re.fullmatch('[0-9a-f]{64}', str(value.get('sha256', ''))):
            p = value['file']
            assert sha(blob(p)) == value['sha256'], p
            references[p] = rec(p)
        for v in value.values(): walk(v)
    elif isinstance(value, list):
        for v in value: walk(v)
walk(pl)

cell = obj('research-wiki/frontier-cells/ASTIS-SHARED-MATRIX-BERNSTEIN-MGF.json')
assert cell['status'] == 'proved_locally' and cell['owner_id'] == owner and cell['advance_id'] == TARGET
assert cell['evidence']['focused_checks_bundle'] == pl['focused_checks']
assert len(cell['evidence']['focused_checks']) == 2
for old, row in zip(pl['focused_checks']['ROOT_actual'], cell['evidence']['focused_checks']):
    receipt = obj(old['file'])
    assert row == {**old, 'command': receipt['command']} and receipt['exit_code'] == 0
    assert old['executed_HEAD'] == '107eb7d0b519bc77c96e0a9d5ff7df24854bb80b'

summary = obj(B + 'preV-metadata-checks-summary.v1.json')
gate_runs = []
for row in summary['actual_runs']:
    r = obj(row['receipt'])
    assert sha(blob(row['receipt'])) == row['sha256'] and r['exit_code'] == row['exit_code']
    log_path = row['receipt'].replace('.receipt.json', '.log.gz')
    log = gzip.decompress(blob(log_path))
    assert sha(log) == row['decoded_log_sha256']
    gate_runs.append({'receipt': rec(row['receipt']), 'raw_log_gzip': rec(log_path),
                      'decoded_log_sha256': sha(log), 'exit_code': r['exit_code'],
                      'actual_command': r['command'], 'actual_observed_head_before': r.get('head_before'),
                      'actual_observed_head_after': r.get('head_after')})
failure = [x for x in gate_runs if x['exit_code'] == 1]
assert len(failure) == 1 and 'frontier-gate' in failure[0]['receipt']['file']
failed_text = gzip.decompress(blob(failure[0]['raw_log_gzip']['file'])).decode()
assert 'requires focused_checks evidence' in failed_text
assert [x['exit_code'] for x in gate_runs[-2:]] == [0, 0]
repair_text = blob(B + 'assembly-tools/repair_frontier_focused_checks_shape_v2.py').decode()
assert "cell['evidence']['focused_checks_bundle'] = copy.deepcopy(pl['focused_checks'])" in repair_text
assert "cell['evidence']['focused_checks'] = checks" in repair_text
assert "assert pl_path.read_bytes() == pl_bytes" in repair_text

# Exact current source scan supplements the already independent kernel and source audits.
source_findings = []
for path in list(four)[:2]:
    for n, line in enumerate(blob(path).decode().splitlines(), 1):
        if re.search(r'\b(sorry|admit|axiom|unsafe|implemented_by|run_tac|sorryAx)\b', line):
            source_findings.append({'file': path, 'line': n, 'text': line})
assert not source_findings
native = obj(E + 'native-originals/weighted_mgf_native_8c2d/native-mathematics-report.v1.json')
assert native['immutable_candidate_compiled'] == '4869db55d340cee39f0ba4d49fb0a7a4309ba2d6'
assert native['all_native_command_exit_codes_zero'] and not native['nonstandard_axioms']
assert not native['unsafe_production_or_harness_logical_declarations']

report = {
    'schema': 'weighted-MGF-independent-pre-V-carrier-review-v1', 'verified_commit_candidate': COMMIT,
    'reviewer_actual_actor': ACTOR, 'proving_owner': owner, 'independent_actor_is_distinct': True,
    'status': 'CORE_IMMUTABLE_IDENTITY_SOURCE_PL_AND_ENVELOPE_ACCEPTED;AWAITING_INDEPENDENT_CONTAINER_STREAM_REVIEW_BEFORE_API',
    'four_exact_source_metadata_hashes': four,
    'original_PL_fields': 24, 'original_PL_evidence_recursive_equality': True,
    'original_PL_evidence_canonical_sha256': sha(json.dumps(pl, sort_keys=True, ensure_ascii=False, separators=(',', ':')).encode()),
    'original_PL_historical_runtime_pending_snapshot_retained': True,
    'original_PL_explicit_blob_references_rechecked': list(references.values()),
    'envelope_repair_review': {'accepted': True, 'original_rich_bundle_preserved': True,
        'list_contains_only_two_real_compile_receipts': True, 'PL_file_unchanged': True,
        'actual_failure_retained': failure, 'actual_runs': gate_runs,
        'scope': 'Only frontier metadata envelope; original compiler identities107 worktree/4869 native and older4CLI2cc unchanged. Refreshed frontier/contributor ran at56f8 working-tree state before6abc commit.'},
    'fake_closure_scan': {'exact_P_T_source_forbidden_token_findings': source_findings,
        'kernel_type_and_value_DAGs_and_standard_axioms': pl['native_type_value_kernel'],
        'literal_seal_and_original_law_binders': pl['binder_definition_audit'],
        'truth': 'Exact closed type/value kernel and q0 checks already actual at4869; source-first actor separately accepted full-module/seven-slot and source mapping. No claim of new mathematical execution at6abc.'},
    'runtime_bounded_acceptance': rec(B + 'native-runtime-bounded-acceptance-report.v1.json'),
    'fresh_current_reader_verdict': rec(B + 'fresh-current-reader-independent-verdict.json'),
    'V_calls_in_preflight': 0, 'new_Chrome_Lean_or_four_CLI_runs': 0,
    'truth_boundary': 'No STABILIZING, integration, main merge, whole-site deployment, purification or whole Goal completion.'
}
dump('pre-V-carrier-core-review.v1.json', report)
payload = copy.deepcopy(pl)
payload.update({
    'verifier_id': ACTOR, 'verified_commit': COMMIT,
    'gate': {'original_independent_native_and_actual_root_checks': copy.deepcopy(pl['focused_checks']),
        'post_PL_current_runtime': rec(B + 'native-runtime-bounded-acceptance-report.v1.json'),
        'post_PL_metadata_envelope_checks': gate_runs,
        'identity_qualification': 'Native compiled4869 archived bytes; ROOT original checks107 worktree exactbytes; original4CLI2cc; refreshed2metadata gates56f8 worktree.6abc binds exact bytes and custody, not a newly executed build.'},
    'source_audit': {'original_preproof_topology': copy.deepcopy(pl['source_topology_and_coverage']),
        'original_blind_decoding': copy.deepcopy(pl['source_blind_decoding']),
        'distinct_source_first_full_module_and_seven_slot_actor': copy.deepcopy(pl['fresh_source_wholemodule_and_seven_slot']),
        'current_source_correspondence': copy.deepcopy(pl['source_lean_correspondence']),
        'current_reader_fresh_verdict': rec(B + 'fresh-current-reader-independent-verdict.json'),
        'source_boundary': 'Tropp independent matching background; literal Gaussian original law and signed cosine weights retained. Generic reader consumes rendered unit source links, not authored per-step source_attribution metadata.'},
    'fake_closure_scan': copy.deepcopy(report['fake_closure_scan']),
    'post_PL_current_evidence': {'math_candidate': pl['actual_math_commit'], 'carrier_commit': COMMIT,
        'four_exact_source_metadata_hashes': four, 'runtime_report': rec(B + 'native-runtime-bounded-acceptance-report.v1.json'),
        'portable_custody': rec(B + 'portable-originals-custody.v1.json'),
        'metadata_repair_receipts': rec(B + 'preV-metadata-checks-summary.v1.json'),
        'original24_PL_values_preserved_inline': True,
        'current_runtime_result': {'checks': 343, 'false': 0, 'PNG': 86, 'exit_code': 0,
            'checks_sha256': 'dd84dcee1105f455b1dd273f21187e8fe5c2539b515f8a1580b8888c614dd492',
            'process_receipt_sha256': '2cbc3228118bc7aabbd3c9e86c0ed87284171dfd490327b0b7198fed15df184b',
            'actual_invoker': 'ROOT', 'independent_runtime_interpreter': ACTOR,
            'fresh_source_PNG_reviewer': 'mgf_fresh_source_5b7e'},
        'runtime_boundaries': ['Exact isolated reader-preview-v2 at desktop1440x1000/mobile390x844, not a production/postV render.',
            'Default-fit graph labels too small; actual zoom/pan retains SVG ellipses/mobile clipping. Exact IDs read in actual detail inspector.',
            'v1 serializer, v2 baseline/anchor and v3 LF-probe real failures preserved; v4 measurement-input repair preserves geometry/assertions.',
            'No physical touch, remote source website browsing, whole-site acceptance, stabilization, main integration, purification or Goal completion.']},
    'post_PL_preservation_requirement': {'only_authorized_canonical_mutation': 'Exactly one target PROVED_LOCAL-to-VERIFIED normal API append.',
        'private_checks': 'Full tracked byte/mode map, foreign advance/discovery states, frontier bytes, branch/HEAD/index and both ledger prefixes compared locally; full guards stay private.',
        'public_result': 'A bounded preservation summary and the exact one-event append are separately carried; no full maps or guard fingerprint exported.'}
})
assert all(payload[k] == v for k, v in pl.items()) and len(pl) == 24
dump('VERIFIED-evidence.full.v1.json', payload)
print(json.dumps({'status': report['status'], 'original_PL_fields': 24,
    'payload_fields': len(payload), 'PL_file_references': len(references), 'source_forbidden_hits': 0,
    'normal_API_calls': 0, 'payload_sha256': sha((OWN / 'VERIFIED-evidence.full.v1.json').read_bytes())}))
