"""Freeze actual corrected-core protection-only evidence; preserve held39798 report."""
from pathlib import Path
import datetime, gzip, hashlib, json
R=Path('/Users/zhouhuanjian/ASTIS-GC')
O=R/'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-determinant-integration-20261108/independent-integration-reader-review/corrected-postcore-protection-readback'
report=O/'postcore-readback.json'
receipt=R/'.astis/huanjian-resume-20261103/20261108T033658524957Z-fixed-spectrum-determinant-corrected-independent-protection-only.receipt.json'
authorization=R/'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-determinant-integration-20261108/corrected-postcore-protection-context.json'
common=R/'.astis/huanjian-gc-fixed-spectrum-determinant-integration-20261108/independent-reader/det_acceptance_common.py'
entry=common.parent/'check_postcore.py'
sha=lambda b:hashlib.sha256(b).hexdigest()
assert sha(report.read_bytes())=='a4f8ced04ee69b7379096e94a8c05c2c6540b681c4c5739a92622b40d8e96341'
assert sha(authorization.read_bytes())=='12901bc25f26397786db39c0dd7dd335d5ca8d445000542cfe5d601f6bb40e8f'
assert sha(common.read_bytes())=='cb8a5e4306356d4bcf2ae3505836d13e3f3e62176eacb839f62d95565b2461fd'
value=json.loads(report.read_bytes());actual=json.loads(receipt.read_bytes());log=Path(actual['log'])
core='55b7b53921b430056db42ef04186d92074f0c49b'
assert value['state']=='POSTCORE_READBACK_PASS_NOT_LOCAL_SITE_ACCEPTANCE' and value['readback_phase']=='protection-only'
assert value['actual_Lean_site_browser_checks_claimed'] is False and value['actual_original_images_viewed_by_this_helper']==0
assert value['new_source_verdict'] is False and value['parking_authorized_or_executed'] is False
assert actual['exit_code']==0 and actual['head_before']==actual['head_after']==core
assert sha(log.read_bytes())==actual['log_sha256']=='defdcc9f026c8351d08e09f484ea63b8aad75bf19480004837e6addcecb5dee0'
assert value['sourceV_lineage']['actual_original_source_verifier']=='/root/reader_835194'
assert value['sourceV_lineage']['proof_owner']=='huanjian_gc_20261108_fixed_spectrum_determinant'
protection=value['protection'];assert protection['canonical_Registry_count']==620 and protection['original_six_after_plus_exact_two_path_index_overlay_and_old_Registry_preserved'] is True
assert protection['foreign_advances']==282 and protection['foreign_frontiers']==441 and protection['protected_foreign_content']==7432
assert protection['supplementary_index_proposal']['sha256']=='f34ddae19da4c5b6980ce20bd08a99ee1c112b5e95bdc34c9e0e552af720f7ed'
rows=[]
for name,path in [('postcore-readback.json.raw.gz',report),('actual-command.receipt.json.raw.gz',receipt),('actual-command.stdout.raw.gz',log),('authorization.json.raw.gz',authorization),('executed-common-helper.py.raw.gz',common),('executed-postcore-entry.py.raw.gz',entry),('freeze-driver.py.raw.gz',Path(__file__))]:
 raw=path.read_bytes();data=gzip.compress(raw,mtime=0);dest=O/name
 assert not dest.exists();dest.write_bytes(data);assert gzip.decompress(dest.read_bytes())==raw
 rows.append({'original':str(path.relative_to(R)),'raw_sha256':sha(raw),'raw_bytes':len(raw),'archive':str(dest.relative_to(R)),'archive_sha256':sha(data)})
old=R/'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-determinant-integration-20261108/independent-integration-reader-review/postcore-protection-readback/postcore-readback.json'
assert sha(old.read_bytes())=='2ecf798b66693f848d3e6020a4eb3b42f7d9e66698ed94132ea06af588dc730c'
freeze={'reviewer':'/root/det_integration_reader','recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'phase':'Actual explicitly authorized corrected protection-only execution; no local acceptance','immutable_core':core,'authorization_raw_sha256':sha(authorization.read_bytes()),'report_raw_sha256':sha(report.read_bytes()),'actual_receipt_raw_sha256':sha(receipt.read_bytes()),'actual_command':actual['command'],'actual_started_utc':actual['started_utc'],'actual_exit_code':actual['exit_code'],'actual_elapsed_seconds':actual['elapsed_seconds'],'raw_log_sha256':sha(log.read_bytes()),'executed_common_sha256':sha(common.read_bytes()),'lossless_archives':rows,'original_held39798_report_sha256_preserved':sha(old.read_bytes()),'actual_new_source_verdicts':0,'actual_lifecycle_API_calls':0,'actual_build_site_graph_browser_actions':0,'actual_original_image_views':0,'local_acceptance_or_parking':False,'scope':'Original six after payloads plus exact2path compilation-only existing-canonical index supplement/current620, original independent sourceV/owner/soleSTAB and all282foreignstates/441frontiers/7432protectedforeigncontents/olderGC/README/casevalues/models preserved. No actual graph/site/browser/gate acceptance is performed in protection-only mode.','stopped_after_freeze':True}
dest=O/'freeze.json';assert not dest.exists();dest.write_text(json.dumps(freeze,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'state':value['state'],'phase':value['readback_phase'],'report_sha256':sha(report.read_bytes()),'actual_receipt_sha256':sha(receipt.read_bytes()),'freeze_sha256':sha(dest.read_bytes()),'exit_code':actual['exit_code'],'elapsed_seconds':actual['elapsed_seconds'],'raw_log_sha256':sha(log.read_bytes()),'new_source_verdicts_or_API_build_site_graph_browser_actions':0},indent=2))
