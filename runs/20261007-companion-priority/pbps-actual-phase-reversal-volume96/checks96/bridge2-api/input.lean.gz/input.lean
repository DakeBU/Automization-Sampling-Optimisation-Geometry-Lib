import AutoSamplingTheory.ExampleCases.ProximalBPS.ActualHarmonicFlow
import AutoSamplingTheory.ExampleCases.ProximalBPS.ActualBounceRate
import Mathlib.MeasureTheory.Measure.Haar.InnerProductSpace
import Mathlib.MeasureTheory.Group.Prod
import Mathlib.MeasureTheory.Integral.Bochner.Basic
import Mathlib.Tactic.Module
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Ring

open MeasureTheory InnerProductSpace
noncomputable section
set_option autoImplicit false
variable {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℝ E]
  [FiniteDimensional ℝ E] [MeasurableSpace E] [BorelSpace E]

private theorem lower_shear (a : ℝ) :
    MeasurePreserving (fun z : E × E => (z.1, z.2 + a • z.1))
      ((volume : Measure E).prod volume) ((volume : Measure E).prod volume) := by
  exact (MeasurePreserving.id (volume : Measure E)).skew_product
    (measurable_snd.add (measurable_fst.const_smul a))
    (Filter.Eventually.of_forall fun x => (measurePreserving_add_right volume (a • x)).map_eq)

private theorem upper_shear (a : ℝ) :
    MeasurePreserving (fun z : E × E => (z.1 + a • z.2, z.2))
      ((volume : Measure E).prod volume) ((volume : Measure E).prod volume) := by
  simpa only [Function.comp_def, Prod.swap_prod_mk] using
    (Measure.measurePreserving_swap.comp (lower_shear (E := E) a)).comp Measure.measurePreserving_swap

private theorem negate_phase :
    MeasurePreserving (fun z : E × E => (-z.1, -z.2))
      ((volume : Measure E).prod volume) ((volume : Measure E).prod volume) := by
  exact (LinearIsometryEquiv.neg ℝ).measurePreserving.prod
    (LinearIsometryEquiv.neg ℝ).measurePreserving

private theorem reflect_fiber (n : E) :
    MeasurePreserving (fun p : E => p - (2 * inner ℝ p n / ‖n‖ ^ 2) • n)
      volume volume := by
  letI : CompleteSpace E := FiniteDimensional.complete ℝ E
  have heq : (fun p : E => p - (2 * inner ℝ p n / ‖n‖ ^ 2) • n) =
      (fun p => (ℝ ∙ n)ᗮ.reflection p) := by
    funext p
    rw [Submodule.reflection_orthogonal_apply, Submodule.reflection_singleton_apply]
    simp only [two_smul, neg_sub, div_eq_mul_inv, mul_smul]
    rw [real_inner_comm n p]
    module
  rw [heq]
  exact ((ℝ ∙ n)ᗮ.reflection).measurePreserving

#print axioms lower_shear
#print axioms upper_shear
#print axioms reflect_fiber
end
