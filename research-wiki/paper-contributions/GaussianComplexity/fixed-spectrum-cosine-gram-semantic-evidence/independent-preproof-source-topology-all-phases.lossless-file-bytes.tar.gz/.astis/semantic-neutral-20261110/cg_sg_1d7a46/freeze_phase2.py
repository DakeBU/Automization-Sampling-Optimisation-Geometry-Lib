from pathlib import Path
from hashlib import sha256
from datetime import datetime, timezone
import json
import stat
import shutil

O=Path('/Users/zhouhuanjian/ASTIS-GC/.astis/semantic-neutral-20261110/cg_sg_1d7a46')
P=O/'phase2'
assert not (O/'phase2_receipt.json').exists(), 'Already frozen; never rewrite.'
def digest(p): return sha256(p.read_bytes()).hexdigest()
def load(p): return json.loads(p.read_text())
def dump(p,obj): p.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
manifest1=O/'phase1_manifest.json'
receipt1=O/'phase1_receipt.json'
assert digest(manifest1)=='ededc4db5669a328807c9e0fbf9f719fdc92df4257c878bafd343965e25fb00b'
assert digest(receipt1)=='86869756bdcdb1dfe0a33cba6d572705ebee9c6784ecee5660db72c3c00bfd91'
m1=load(manifest1)
for item in m1['files']:
    f=O/'phase1'/item['path']
    assert f.stat().st_size==item['bytes']
    assert digest(f)==item['sha256']
    assert stat.S_IMODE(f.stat().st_mode)==0o444
for d in [O/'phase1',*[x for x in (O/'phase1').rglob('*') if x.is_dir()]]:
    assert stat.S_IMODE(d.stat().st_mode)==0o555
assert digest(O/'phase1/inputs/2610.20492v1.html')=='6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
assert digest(O/'phase1/source_graph.json')=='c4b19d5410db563d3211b148277a34d2181cbf1133bef0b9932f0eb117ab5d4c'
assert digest(O/'phase1/coverage.json')=='da152a145bb41d16bd224196e12a6feaad160afb3b7ee86d68ee6c8765532e05'
assert digest(O/'phase1/cognition.md')=='f967549630ba8fb17d3df22904ad0f30aa47aa91c211c64a2857dcd2a9ab4b00'

for name,size,expected in [
 ('strict-statement-projection.json',6296,'8c881cf422b5c637472f868839a93849468c203a8e0f8cedabcf40139136c549'),
 ('additional-canonical-Gaussian-definitions.json',1299,'70d5c296f08f41d214fa9baae07f5601787e0d4ffcb087756e0d22743ef0ca51'),
 ('multivariateGaussian-literal-definition.txt',566,'0d32e6c37ec13dc0bdbce701ed77a7e2da591a748c8d8f92eb81a72cc2228171')]:
    f=P/'inputs'/name
    assert f.stat().st_size==size
    assert digest(f)==expected
graph=load(O/'phase1/source_graph.json')
ids=set(x['id'] for x in load(O/'phase1/source_index.json')['items'])
parents={x['id']:set() for x in graph['nodes']}
for edge in graph['edges']: parents[edge['consumer']].update(edge['parents'])
def ancestors(n):
    result=set()
    for p in parents[n]: result.add(p); result.update(ancestors(p))
    return result
overlay=load(P/'typed_overlay.json')
obligations=load(P/'proof_obligations.json')
projection=load(P/'inputs/strict-statement-projection.json')
assert len(overlay['typed_roots'])==7
assert len(obligations['obligations'])==9
assert overlay['phase1_mutation'] is False
for name in ['producer_signature','consumer_signature']:
    assert overlay['exact_signatures'][name]==projection[name]
    assert sha256(projection[name].encode()).hexdigest()==overlay['exact_signature_sha256'][name]
for root in overlay['typed_roots']:
    assert set(root['raw_source_nodes'])<=set(parents)
    assert set(root['raw_source_anchors'])<=ids
    actual=set().union(*[ancestors(n) for n in root['raw_source_nodes']])
    assert set(root['true_raw_ancestors'])==actual
    assert set(root['internal_obligations'])<=set(x['id'] for x in obligations['obligations'])

G=P/'logs/generators'
G.mkdir()
for name in ['read_phase2.py','read_phase2_supplement.py','author_phase2.py','freeze_phase2.py']:
    shutil.copyfile(O/name,G/name)
validation={'status':'STRUCTURAL_AND_HASH_INTEGRITY_ONLY_PASS',
 'phase1_files_rechecked':len(m1['files']),'phase1_all_hashes_and_modes_unchanged':True,
 'phase1_manifest_sha256':digest(manifest1),'phase1_receipt_sha256':digest(receipt1),
 'typed_roots':7,'internal_open_obligations':9,'genuine_source_ancestor_closures_checked':True,
 'signature_strings_exact':True,'input_sizes_and_hashes_exact':True,
 'proof_or_verdict':'NONE; independent source review and all mathematical obligations remain pending.'}
dump(P/'logs/freeze_validation.json',validation)
files=sorted(x for x in P.rglob('*') if x.is_file())
assert all(not x.is_symlink() for x in files)
manifest={'schema':'astis-post-freeze-typed-overlay-manifest/v1','phase2_root':str(P),
 'phase1_manifest_sha256':digest(manifest1),'phase1_all_hashes_unchanged':True,
 'nonrecursive_contract':'Manifest outside phase2 hashes phase2 files only. Receipt outside phase2 hashes this manifest; neither object hashes itself.',
 'files':[{'path':str(f.relative_to(P)),'bytes':f.stat().st_size,'sha256':digest(f),'frozen_mode':'0444'} for f in files]}
manifest_path=O/'phase2_manifest.json'
dump(manifest_path,manifest)
for f in files: f.chmod(0o444)
dirs=sorted([P,*[x for x in P.rglob('*') if x.is_dir()]],key=lambda x:len(x.parts),reverse=True)
for d in dirs: d.chmod(0o555)
assert all(stat.S_IMODE(f.stat().st_mode)==0o444 for f in files)
assert all(stat.S_IMODE(d.stat().st_mode)==0o555 for d in dirs)
for name in ['read_phase2.py','read_phase2_supplement.py','author_phase2.py','freeze_phase2.py']:
    (O/name).chmod(0o444)
manifest_path.chmod(0o444)
receipt={'schema':'astis-post-freeze-typed-overlay-receipt/v1','status':'PHASE2_FROZEN_PAUSED',
 'frozen_utc':datetime.now(timezone.utc).isoformat(),'phase2_path':str(P),
 'phase2_manifest_path':str(manifest_path),'phase2_manifest_sha256':digest(manifest_path),
 'phase1_files_rechecked':len(m1['files']),'phase1_all_hashes_and_modes_unchanged':True,
 'phase1_manifest_sha256':digest(manifest1),'phase1_receipt_sha256':digest(receipt1),
 'phase1_key_hashes':{n:digest(O/'phase1'/n) for n in ['source_graph.json','coverage.json','cognition.md','source_index.json','inputs.json','logs/execution_and_exposure.md']},
 'phase2_key_hashes':{n:digest(P/n) for n in ['typed_overlay.json','binder_definition_audit.json','proof_obligations.json','cognition.md','task_and_exposure.md']},
 'files_frozen':len(files),'directories_frozen':len(dirs),'file_mode':'0444','directory_mode':'0555',
 'counts':{'public_typed_roots':3,'private_typed_roots':4,'open_internal_obligations':9},
 'observation':'Supplied public formulas source-aligned; private actual-law integrability/means structurally source-aligned with internal obligations. No excess caller premise found. This is not independent source verification or proof completion.',
 'no_further_minimal_definition_request_now':True,
 'remaining_boundary':['all target proofs/definition properties open','independent source topology/source review pending','Range(B)=Krylov','C.6 concentration','full Lemma4.4','both main results'],
 'actions_performed':'Only exact input reads, owned artifact authoring and hash/shape checks. No target proof/API/V/native/TC/intake/global action.'}
receipt_path=O/'phase2_receipt.json'
dump(receipt_path,receipt)
receipt_path.chmod(0o444)
summary={'status':receipt['status'],'receipt_path':str(receipt_path),'receipt_sha256':digest(receipt_path),
 'manifest_sha256':digest(manifest_path),'phase1_all_67_file_hashes_and_modes_unchanged':True,
 'phase2_key_hashes':receipt['phase2_key_hashes'],'counts':receipt['counts'],
 'modes_verified':True,'independent_review':'PENDING','target_proof_API_V_global':'NOT PERFORMED'}
stdout=json.dumps(summary,ensure_ascii=False)+'\n'
out=O/'phase2_freeze_stdout.json'
out.write_text(stdout)
out.chmod(0o444)
print(stdout,end='')
