import Tests.GaussianComplexityAdaptiveFirstOrderSimulation
import Lean
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring
open MeasureTheory ProbabilityTheory Matrix Lean Elab Term Meta
open AutoSamplingTheory.TechnicalLemmas.Analysis.QuadraticRegularizationOracle
open AutoSamplingTheory.TechnicalLemmas.Probability.AdaptiveOracleSimulation
set_option autoImplicit false
set_option backward.isDefEq.respectTransparency false
noncomputable section
universe uS uQ uA uB uX uΩ
elab "native_actual_T" : term => do
  let env ← getEnv
  let found := env.constants.toList.filter fun (n, _) =>
    n.toString.endsWith ".actual_fixed_spectrum_first_order_matvec_joint_laws_and_costs"
  unless found.length == 1 do throwError "Expected unique actual private R18 T, found {found.length}"
  mkConstWithFreshMVarLevels found.head!.1
namespace NativeLiteralApplications

theorem literal_P :
∀ {S : Type uS} {Q : Type uQ} {A : Type uA} {B : Type uB}
    {X : Type uX} {Ω : Type uΩ}
    [MeasurableSpace S] [MeasurableSpace Q] [MeasurableSpace A]
    [MeasurableSpace B] [MeasurableSpace X] [MeasurableSpace Ω],
    letI : MeasurableSpace (Option X) := MeasurableSpace.comap
      (fun x : Option X => x.elim (Sum.inl () : Unit ⊕ X) Sum.inr) inferInstance
    ∀ (μ : Measure Ω) [IsProbabilityMeasure μ]
    (next : S → Sum X Q) (update : S → Q → B → S)
    (oracle : Q → A) (target : Q → B) (decode : Q → A → B)
    (initial : Ω → S),
    Measurable next →
    Measurable (fun p : S × Q × B => update p.1 p.2.1 p.2.2) →
    Measurable oracle →
    Measurable (fun p : Q × A => decode p.1 p.2) →
    Measurable initial →
    (∀ q, decode q (oracle q) = target q) →
    ∀ fuel : ℕ,
      let baseRun : Ω → (S × Option X) × ℕ := fun ω =>
        run next (fun s q a => update s q (decode q a)) oracle fuel (initial ω)
      let targetRun : Ω → (S × Option X) × ℕ := fun ω =>
        run next update target fuel (initial ω)
      Measurable baseRun ∧ Measurable targetRun ∧
      (∀ ω, baseRun ω = targetRun ω ∧ (baseRun ω).2 ≤ fuel) ∧
      μ.map baseRun = μ.map targetRun ∧
      IsProbabilityMeasure (μ.map baseRun) ∧
      Integrable (fun ω => ((baseRun ω).2 : ℝ)) μ ∧
      (∫ ω, ((baseRun ω).2 : ℝ) ∂μ) = (∫ ω, ((targetRun ω).2 : ℝ) ∂μ) ∧
      (∫ ω, ((baseRun ω).2 : ℝ) ∂μ) ≤ (fuel : ℝ) := by
  exact @AutoSamplingTheory.TechnicalLemmas.Probability.AdaptiveOracleSimulation.measurable_simulation_joint_law_and_cost

theorem literal_T :
∀ {d : ℕ}, 2 ≤ d →
    ∀ {κ : ℝ}, 2 ≤ κ →
    letI : MeasurableSpace (EuclideanSpace ℝ (Fin d)) := borel _
    letI : MeasurableSpace (Option (EuclideanSpace ℝ (Fin d))) := MeasurableSpace.comap
      (fun x : Option (EuclideanSpace ℝ (Fin d)) =>
        x.elim (Sum.inl () : Unit ⊕ EuclideanSpace ℝ (Fin d)) Sum.inr) inferInstance
    ∀ {S : Type uS} {Ω : Type uΩ} [MeasurableSpace S] [MeasurableSpace Ω]
      (μ : Measure Ω) [IsProbabilityMeasure μ]
      (next : S → Sum (EuclideanSpace ℝ (Fin d)) (EuclideanSpace ℝ (Fin d)))
      (updateFO : S → EuclideanSpace ℝ (Fin d) →
        (ℝ × EuclideanSpace ℝ (Fin d)) → S)
      (updateMV : S → EuclideanSpace ℝ (Fin d) → EuclideanSpace ℝ (Fin d) → S)
      (initial : Ω → S),
      Measurable next →
      Measurable (fun p : S × EuclideanSpace ℝ (Fin d) ×
        (ℝ × EuclideanSpace ℝ (Fin d)) => updateFO p.1 p.2.1 p.2.2) →
      Measurable (fun p : S × EuclideanSpace ℝ (Fin d) ×
        EuclideanSpace ℝ (Fin d) => updateMV p.1 p.2.1 p.2.2) →
      Measurable initial →
      ∀ (fuel : ℕ) (O : Matrix.orthogonalGroup (Fin d) ℝ),
        let θ : Fin d → ℝ := fun i => ((i.val : ℝ) + 1 / 2) * Real.pi / (d : ℝ)
        let A : Matrix (Fin d) (Fin d) ℝ :=
          (O : Matrix (Fin d) (Fin d) ℝ) *
          Matrix.diagonal (fun i => (κ + 1) / 2 + (κ - 1) / 2 * Real.cos (θ i)) *
          (O : Matrix (Fin d) (Fin d) ℝ).transpose
        let f : EuclideanSpace ℝ (Fin d) → ℝ := fun x =>
          (WithLp.ofLp x) ⬝ᵥ (A *ᵥ WithLp.ofLp x) / 2
        let mv : EuclideanSpace ℝ (Fin d) → EuclideanSpace ℝ (Fin d) := fun x =>
          WithLp.toLp 2 (A *ᵥ WithLp.ofLp x)
        let fo := fun x => (f x, gradient f x)
        let foRun := fun ω => run next updateFO fo fuel (initial ω)
        let foViaMV := fun ω => run next
          (fun s x y => updateFO s x (inner ℝ x y / 2, y)) mv fuel (initial ω)
        let mvRun := fun ω => run next updateMV mv fuel (initial ω)
        let mvViaFO := fun ω => run next
          (fun s x (y : ℝ × EuclideanSpace ℝ (Fin d)) => updateMV s x y.2)
          fo fuel (initial ω)
        Measurable foViaMV ∧ Measurable foRun ∧
        (∀ ω, foViaMV ω = foRun ω ∧ (foViaMV ω).2 ≤ fuel) ∧
        μ.map foViaMV = μ.map foRun ∧ IsProbabilityMeasure (μ.map foViaMV) ∧
        Integrable (fun ω => ((foViaMV ω).2 : ℝ)) μ ∧
        (∫ ω, ((foViaMV ω).2 : ℝ) ∂μ) = (∫ ω, ((foRun ω).2 : ℝ) ∂μ) ∧
        (∫ ω, ((foViaMV ω).2 : ℝ) ∂μ) ≤ (fuel : ℝ) ∧
        Measurable mvViaFO ∧ Measurable mvRun ∧
        (∀ ω, mvViaFO ω = mvRun ω ∧ (mvViaFO ω).2 ≤ fuel) ∧
        μ.map mvViaFO = μ.map mvRun ∧ IsProbabilityMeasure (μ.map mvViaFO) ∧
        Integrable (fun ω => ((mvViaFO ω).2 : ℝ)) μ ∧
        (∫ ω, ((mvViaFO ω).2 : ℝ) ∂μ) = (∫ ω, ((mvRun ω).2 : ℝ) ∂μ) ∧
        (∫ ω, ((mvViaFO ω).2 : ℝ) ∂μ) ≤ (fuel : ℝ) := by
  exact native_actual_T

local instance : MeasurableSpace (Option ℝ) := MeasurableSpace.comap
  (fun x : Option ℝ => x.elim (Sum.inl () : Unit ⊕ ℝ) Sum.inr) inferInstance

def rNext (s : ℝ) : ℝ ⊕ ℝ := if s ≤ 0 then .inr (-s) else .inl s
def rUpdate (_ _ a : ℝ) : ℝ := a
def rOracle (q : ℝ) : ℝ := 2*q
def rTarget (q : ℝ) : ℝ := 3*q
def rDecode (q a : ℝ) : ℝ := a+q

theorem actual_reply_sensitive_joint_law :
    let b := fun ω : ℝ => run rNext (fun s q a => rUpdate s q (rDecode q a)) rOracle 7 (-ω)
    let t := fun ω : ℝ => run rNext rUpdate rTarget 7 (-ω)
    (Measure.dirac (2 : ℝ)).map b = (Measure.dirac (2 : ℝ)).map t := by
  have hn : Measurable rNext := by
    exact Measurable.ite (measurableSet_le measurable_id measurable_const)
      (measurable_inr.comp measurable_neg) measurable_inl
  have hu : Measurable (fun p : ℝ × ℝ × ℝ => rUpdate p.1 p.2.1 p.2.2) := measurable_snd.snd
  have ho : Measurable rOracle := by unfold rOracle; fun_prop
  have hd : Measurable (fun p : ℝ × ℝ => rDecode p.1 p.2) := by unfold rDecode; fun_prop
  have hi : Measurable (fun ω : ℝ => -ω) := measurable_neg
  have he (q : ℝ) : rDecode q (rOracle q) = rTarget q := by dsimp [rDecode,rOracle,rTarget]; ring
  have full := AutoSamplingTheory.TechnicalLemmas.Probability.AdaptiveOracleSimulation.measurable_simulation_joint_law_and_cost (Measure.dirac (2 : ℝ))
    rNext rUpdate rOracle rTarget rDecode (fun ω => -ω) hn hu ho hd hi he 7
  exact full.2.2.2.1

theorem zero_fuel_pending_is_none :
    run rNext (fun s q a => rUpdate s q (rDecode q a)) rOracle 0 (-2) =
      (((-2 : ℝ), none), 0) := by norm_num [run,rNext]

theorem initial_halt_even_at_zero_fuel :
    run rNext (fun s q a => rUpdate s q (rDecode q a)) rOracle 0 2 =
      (((2 : ℝ), some 2), 0) := by norm_num [run,rNext]

theorem initial_halt_positive_fuel_no_query :
    run rNext (fun s q a => rUpdate s q (rDecode q a)) rOracle 7 2 =
      (((2 : ℝ), some 2), 0) := by norm_num [run,rNext]

theorem fuel7_real_output6_cost1 :
    run rNext (fun s q a => rUpdate s q (rDecode q a)) rOracle 7 (-2) =
      (((6 : ℝ), some 6), 1) := by norm_num [run,rNext,rUpdate,rOracle,rDecode]

theorem changed_oracle_reply_changes_output :
    run rNext (fun s q a => rUpdate s q (rDecode q a)) (fun q => 3*q) 7 (-2) =
      (((8 : ℝ), some 8), 1) := by norm_num [run,rNext,rUpdate,rDecode]

theorem expected_cost_is_one :
    (∫ ω : ℝ, ((run rNext (fun s q a => rUpdate s q (rDecode q a)) rOracle 7 (-ω)).2 : ℝ)
      ∂Measure.dirac (2 : ℝ)) = 1 := by
  rw [integral_dirac]
  norm_num [run,rNext,rUpdate,rOracle,rDecode]

theorem expected_cost_is_not_fuel7 :
    (∫ ω : ℝ, ((run rNext (fun s q a => rUpdate s q (rDecode q a)) rOracle 7 (-ω)).2 : ℝ)
      ∂Measure.dirac (2 : ℝ)) ≠ 7 := by rw [expected_cost_is_one]; norm_num

abbrev E2 := EuclideanSpace ℝ (Fin 2)
local instance : MeasurableSpace E2 := borel E2
local instance : BorelSpace E2 := ⟨rfl⟩
local instance : MeasurableSpace (Option E2) := MeasurableSpace.comap
  (fun x : Option E2 => x.elim (Sum.inl () : Unit ⊕ E2) Sum.inr) inferInstance

def eNext (s : E2 × Bool) : E2 ⊕ E2 := if s.2 = true then .inl s.1 else .inr s.1
def eUpdateFO (_ : E2 × Bool) (_ : E2) (a : ℝ × E2) : E2 × Bool := (a.2, true)
def eUpdateMV (_ : E2 × Bool) (_ : E2) (a : E2) : E2 × Bool := (a, true)
def eInitial (_ : Unit) : E2 × Bool := (WithLp.toLp 2 (fun _ : Fin 2 => (1 : ℝ)), false)

theorem eNext_measurable : Measurable eNext := by
  exact Measurable.ite ((measurableSet_singleton true).preimage measurable_snd)
    (measurable_inl.comp measurable_fst) (measurable_inr.comp measurable_fst)
theorem eUpdateFO_measurable :
    Measurable (fun p : (E2 × Bool) × E2 × (ℝ × E2) => eUpdateFO p.1 p.2.1 p.2.2) :=
  (measurable_snd.snd.snd).prodMk measurable_const
theorem eUpdateMV_measurable :
    Measurable (fun p : (E2 × Bool) × E2 × E2 => eUpdateMV p.1 p.2.1 p.2.2) :=
  (measurable_snd.snd).prodMk measurable_const
theorem eInitial_measurable : Measurable eInitial := measurable_const

theorem T_concrete_full :
  let μ : Measure Unit := Measure.dirac ();
  let next := eNext; let updateFO := eUpdateFO; let updateMV := eUpdateMV; let initial := eInitial;
  ∀ (fuel : ℕ) (O : Matrix.orthogonalGroup (Fin 2) ℝ),
        let θ : Fin 2 → ℝ := fun i => ((i.val : ℝ) + 1 / 2) * Real.pi / (2 : ℝ)
        let A : Matrix (Fin 2) (Fin 2) ℝ :=
          (O : Matrix (Fin 2) (Fin 2) ℝ) *
          Matrix.diagonal (fun i => (2 + 1) / 2 + (2 - 1) / 2 * Real.cos (θ i)) *
          (O : Matrix (Fin 2) (Fin 2) ℝ).transpose
        let f : EuclideanSpace ℝ (Fin 2) → ℝ := fun x =>
          (WithLp.ofLp x) ⬝ᵥ (A *ᵥ WithLp.ofLp x) / 2
        let mv : EuclideanSpace ℝ (Fin 2) → EuclideanSpace ℝ (Fin 2) := fun x =>
          WithLp.toLp 2 (A *ᵥ WithLp.ofLp x)
        let fo := fun x => (f x, gradient f x)
        let foRun := fun ω => run next updateFO fo fuel (initial ω)
        let foViaMV := fun ω => run next
          (fun s x y => updateFO s x (inner ℝ x y / 2, y)) mv fuel (initial ω)
        let mvRun := fun ω => run next updateMV mv fuel (initial ω)
        let mvViaFO := fun ω => run next
          (fun s x (y : ℝ × EuclideanSpace ℝ (Fin 2)) => updateMV s x y.2)
          fo fuel (initial ω)
        Measurable foViaMV ∧ Measurable foRun ∧
        (∀ ω, foViaMV ω = foRun ω ∧ (foViaMV ω).2 ≤ fuel) ∧
        μ.map foViaMV = μ.map foRun ∧ IsProbabilityMeasure (μ.map foViaMV) ∧
        Integrable (fun ω => ((foViaMV ω).2 : ℝ)) μ ∧
        (∫ ω, ((foViaMV ω).2 : ℝ) ∂μ) = (∫ ω, ((foRun ω).2 : ℝ) ∂μ) ∧
        (∫ ω, ((foViaMV ω).2 : ℝ) ∂μ) ≤ (fuel : ℝ) ∧
        Measurable mvViaFO ∧ Measurable mvRun ∧
        (∀ ω, mvViaFO ω = mvRun ω ∧ (mvViaFO ω).2 ≤ fuel) ∧
        μ.map mvViaFO = μ.map mvRun ∧ IsProbabilityMeasure (μ.map mvViaFO) ∧
        Integrable (fun ω => ((mvViaFO ω).2 : ℝ)) μ ∧
        (∫ ω, ((mvViaFO ω).2 : ℝ) ∂μ) = (∫ ω, ((mvRun ω).2 : ℝ) ∂μ) ∧
        (∫ ω, ((mvViaFO ω).2 : ℝ) ∂μ) ≤ (fuel : ℝ) := by
  dsimp only
  intro fuel O
  exact native_actual_T (d := 2) (by norm_num) (κ := 2) (by norm_num)
    (S := E2 × Bool) (Ω := Unit) (Measure.dirac ()) eNext eUpdateFO eUpdateMV eInitial
    eNext_measurable eUpdateFO_measurable eUpdateMV_measurable eInitial_measurable fuel O

theorem T_concrete_fuel0 :
  let μ : Measure Unit := Measure.dirac ();
  let next := eNext; let updateFO := eUpdateFO; let updateMV := eUpdateMV; let initial := eInitial;
  let fuel : ℕ := 0; ∀ (O : Matrix.orthogonalGroup (Fin 2) ℝ),
        let θ : Fin 2 → ℝ := fun i => ((i.val : ℝ) + 1 / 2) * Real.pi / (2 : ℝ)
        let A : Matrix (Fin 2) (Fin 2) ℝ :=
          (O : Matrix (Fin 2) (Fin 2) ℝ) *
          Matrix.diagonal (fun i => (2 + 1) / 2 + (2 - 1) / 2 * Real.cos (θ i)) *
          (O : Matrix (Fin 2) (Fin 2) ℝ).transpose
        let f : EuclideanSpace ℝ (Fin 2) → ℝ := fun x =>
          (WithLp.ofLp x) ⬝ᵥ (A *ᵥ WithLp.ofLp x) / 2
        let mv : EuclideanSpace ℝ (Fin 2) → EuclideanSpace ℝ (Fin 2) := fun x =>
          WithLp.toLp 2 (A *ᵥ WithLp.ofLp x)
        let fo := fun x => (f x, gradient f x)
        let foRun := fun ω => run next updateFO fo fuel (initial ω)
        let foViaMV := fun ω => run next
          (fun s x y => updateFO s x (inner ℝ x y / 2, y)) mv fuel (initial ω)
        let mvRun := fun ω => run next updateMV mv fuel (initial ω)
        let mvViaFO := fun ω => run next
          (fun s x (y : ℝ × EuclideanSpace ℝ (Fin 2)) => updateMV s x y.2)
          fo fuel (initial ω)
        Measurable foViaMV ∧ Measurable foRun ∧
        (∀ ω, foViaMV ω = foRun ω ∧ (foViaMV ω).2 ≤ fuel) ∧
        μ.map foViaMV = μ.map foRun ∧ IsProbabilityMeasure (μ.map foViaMV) ∧
        Integrable (fun ω => ((foViaMV ω).2 : ℝ)) μ ∧
        (∫ ω, ((foViaMV ω).2 : ℝ) ∂μ) = (∫ ω, ((foRun ω).2 : ℝ) ∂μ) ∧
        (∫ ω, ((foViaMV ω).2 : ℝ) ∂μ) ≤ (fuel : ℝ) ∧
        Measurable mvViaFO ∧ Measurable mvRun ∧
        (∀ ω, mvViaFO ω = mvRun ω ∧ (mvViaFO ω).2 ≤ fuel) ∧
        μ.map mvViaFO = μ.map mvRun ∧ IsProbabilityMeasure (μ.map mvViaFO) ∧
        Integrable (fun ω => ((mvViaFO ω).2 : ℝ)) μ ∧
        (∫ ω, ((mvViaFO ω).2 : ℝ) ∂μ) = (∫ ω, ((mvRun ω).2 : ℝ) ∂μ) ∧
        (∫ ω, ((mvViaFO ω).2 : ℝ) ∂μ) ≤ (fuel : ℝ) := by
  dsimp only
  intro O
  exact T_concrete_full 0 O

theorem T_concrete_fuel1 :
  let μ : Measure Unit := Measure.dirac ();
  let next := eNext; let updateFO := eUpdateFO; let updateMV := eUpdateMV; let initial := eInitial;
  let fuel : ℕ := 1; ∀ (O : Matrix.orthogonalGroup (Fin 2) ℝ),
        let θ : Fin 2 → ℝ := fun i => ((i.val : ℝ) + 1 / 2) * Real.pi / (2 : ℝ)
        let A : Matrix (Fin 2) (Fin 2) ℝ :=
          (O : Matrix (Fin 2) (Fin 2) ℝ) *
          Matrix.diagonal (fun i => (2 + 1) / 2 + (2 - 1) / 2 * Real.cos (θ i)) *
          (O : Matrix (Fin 2) (Fin 2) ℝ).transpose
        let f : EuclideanSpace ℝ (Fin 2) → ℝ := fun x =>
          (WithLp.ofLp x) ⬝ᵥ (A *ᵥ WithLp.ofLp x) / 2
        let mv : EuclideanSpace ℝ (Fin 2) → EuclideanSpace ℝ (Fin 2) := fun x =>
          WithLp.toLp 2 (A *ᵥ WithLp.ofLp x)
        let fo := fun x => (f x, gradient f x)
        let foRun := fun ω => run next updateFO fo fuel (initial ω)
        let foViaMV := fun ω => run next
          (fun s x y => updateFO s x (inner ℝ x y / 2, y)) mv fuel (initial ω)
        let mvRun := fun ω => run next updateMV mv fuel (initial ω)
        let mvViaFO := fun ω => run next
          (fun s x (y : ℝ × EuclideanSpace ℝ (Fin 2)) => updateMV s x y.2)
          fo fuel (initial ω)
        Measurable foViaMV ∧ Measurable foRun ∧
        (∀ ω, foViaMV ω = foRun ω ∧ (foViaMV ω).2 ≤ fuel) ∧
        μ.map foViaMV = μ.map foRun ∧ IsProbabilityMeasure (μ.map foViaMV) ∧
        Integrable (fun ω => ((foViaMV ω).2 : ℝ)) μ ∧
        (∫ ω, ((foViaMV ω).2 : ℝ) ∂μ) = (∫ ω, ((foRun ω).2 : ℝ) ∂μ) ∧
        (∫ ω, ((foViaMV ω).2 : ℝ) ∂μ) ≤ (fuel : ℝ) ∧
        Measurable mvViaFO ∧ Measurable mvRun ∧
        (∀ ω, mvViaFO ω = mvRun ω ∧ (mvViaFO ω).2 ≤ fuel) ∧
        μ.map mvViaFO = μ.map mvRun ∧ IsProbabilityMeasure (μ.map mvViaFO) ∧
        Integrable (fun ω => ((mvViaFO ω).2 : ℝ)) μ ∧
        (∫ ω, ((mvViaFO ω).2 : ℝ) ∂μ) = (∫ ω, ((mvRun ω).2 : ℝ) ∂μ) ∧
        (∫ ω, ((mvViaFO ω).2 : ℝ) ∂μ) ≤ (fuel : ℝ) := by
  dsimp only
  intro O
  exact T_concrete_full 1 O

theorem T_concrete_fuel7 :
  let μ : Measure Unit := Measure.dirac ();
  let next := eNext; let updateFO := eUpdateFO; let updateMV := eUpdateMV; let initial := eInitial;
  let fuel : ℕ := 7; ∀ (O : Matrix.orthogonalGroup (Fin 2) ℝ),
        let θ : Fin 2 → ℝ := fun i => ((i.val : ℝ) + 1 / 2) * Real.pi / (2 : ℝ)
        let A : Matrix (Fin 2) (Fin 2) ℝ :=
          (O : Matrix (Fin 2) (Fin 2) ℝ) *
          Matrix.diagonal (fun i => (2 + 1) / 2 + (2 - 1) / 2 * Real.cos (θ i)) *
          (O : Matrix (Fin 2) (Fin 2) ℝ).transpose
        let f : EuclideanSpace ℝ (Fin 2) → ℝ := fun x =>
          (WithLp.ofLp x) ⬝ᵥ (A *ᵥ WithLp.ofLp x) / 2
        let mv : EuclideanSpace ℝ (Fin 2) → EuclideanSpace ℝ (Fin 2) := fun x =>
          WithLp.toLp 2 (A *ᵥ WithLp.ofLp x)
        let fo := fun x => (f x, gradient f x)
        let foRun := fun ω => run next updateFO fo fuel (initial ω)
        let foViaMV := fun ω => run next
          (fun s x y => updateFO s x (inner ℝ x y / 2, y)) mv fuel (initial ω)
        let mvRun := fun ω => run next updateMV mv fuel (initial ω)
        let mvViaFO := fun ω => run next
          (fun s x (y : ℝ × EuclideanSpace ℝ (Fin 2)) => updateMV s x y.2)
          fo fuel (initial ω)
        Measurable foViaMV ∧ Measurable foRun ∧
        (∀ ω, foViaMV ω = foRun ω ∧ (foViaMV ω).2 ≤ fuel) ∧
        μ.map foViaMV = μ.map foRun ∧ IsProbabilityMeasure (μ.map foViaMV) ∧
        Integrable (fun ω => ((foViaMV ω).2 : ℝ)) μ ∧
        (∫ ω, ((foViaMV ω).2 : ℝ) ∂μ) = (∫ ω, ((foRun ω).2 : ℝ) ∂μ) ∧
        (∫ ω, ((foViaMV ω).2 : ℝ) ∂μ) ≤ (fuel : ℝ) ∧
        Measurable mvViaFO ∧ Measurable mvRun ∧
        (∀ ω, mvViaFO ω = mvRun ω ∧ (mvViaFO ω).2 ≤ fuel) ∧
        μ.map mvViaFO = μ.map mvRun ∧ IsProbabilityMeasure (μ.map mvViaFO) ∧
        Integrable (fun ω => ((mvViaFO ω).2 : ℝ)) μ ∧
        (∫ ω, ((mvViaFO ω).2 : ℝ) ∂μ) = (∫ ω, ((mvRun ω).2 : ℝ) ∂μ) ∧
        (∫ ω, ((mvViaFO ω).2 : ℝ) ∂μ) ≤ (fuel : ℝ) := by
  dsimp only
  intro O
  exact T_concrete_full 7 O

end NativeLiteralApplications
#print axioms NativeLiteralApplications.literal_P
#print axioms NativeLiteralApplications.literal_T
#print axioms NativeLiteralApplications.actual_reply_sensitive_joint_law
#print axioms NativeLiteralApplications.zero_fuel_pending_is_none
#print axioms NativeLiteralApplications.initial_halt_even_at_zero_fuel
#print axioms NativeLiteralApplications.initial_halt_positive_fuel_no_query
#print axioms NativeLiteralApplications.fuel7_real_output6_cost1
#print axioms NativeLiteralApplications.changed_oracle_reply_changes_output
#print axioms NativeLiteralApplications.expected_cost_is_one
#print axioms NativeLiteralApplications.expected_cost_is_not_fuel7
#print axioms NativeLiteralApplications.T_concrete_full
#print axioms NativeLiteralApplications.T_concrete_fuel0
#print axioms NativeLiteralApplications.T_concrete_fuel1
#print axioms NativeLiteralApplications.T_concrete_fuel7

set_option pp.all true in
#check @AutoSamplingTheory.TechnicalLemmas.Probability.AdaptiveOracleSimulation.measurable_simulation_joint_law_and_cost
set_option pp.all true in
#check native_actual_T
