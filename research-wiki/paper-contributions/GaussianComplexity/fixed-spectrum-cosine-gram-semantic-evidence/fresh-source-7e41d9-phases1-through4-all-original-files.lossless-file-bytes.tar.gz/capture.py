#!/opt/anaconda3/bin/python
"""Bounded source-review capture runner; no implementation or inventory access."""
import datetime
import hashlib
import json
import pathlib
import subprocess
import sys

BASE = pathlib.Path(__file__).resolve().parent
REPO = pathlib.Path('/Users/zhouhuanjian/ASTIS-GC')
LOG = BASE / 'actual_commands.jsonl'

def run(label, argv):
    stamp = datetime.datetime.now(datetime.timezone.utc).isoformat()
    proc = subprocess.run(argv, cwd=REPO, capture_output=True)
    out = BASE / (label + '.stdout')
    err = BASE / (label + '.stderr')
    out.write_bytes(proc.stdout)
    err.write_bytes(proc.stderr)
    row = {'label': label, 'started_utc': stamp, 'cwd': str(REPO),
           'argv': argv, 'returncode': proc.returncode,
           'stdout_file': out.name, 'stdout_bytes': len(proc.stdout),
           'stdout_sha256': hashlib.sha256(proc.stdout).hexdigest(),
           'stderr_file': err.name, 'stderr_bytes': len(proc.stderr),
           'stderr_sha256': hashlib.sha256(proc.stderr).hexdigest()}
    with LOG.open('a') as f:
        f.write(json.dumps(row, ensure_ascii=False) + '\n')
    print(json.dumps(row, ensure_ascii=False))
    sys.stdout.write(proc.stdout.decode(errors='replace'))
    sys.stderr.write(proc.stderr.decode(errors='replace'))
    return proc.returncode

if __name__ == '__main__':
    raise SystemExit(run(sys.argv[1], sys.argv[2:]))
