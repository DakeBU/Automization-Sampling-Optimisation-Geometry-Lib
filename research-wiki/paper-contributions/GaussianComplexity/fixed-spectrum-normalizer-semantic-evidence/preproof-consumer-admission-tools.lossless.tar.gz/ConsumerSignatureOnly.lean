import AutoSamplingTheory.TechnicalLemmas.Measure.GaussianPrecisionDensity
import Mathlib.LinearAlgebra.UnitaryGroup
open Matrix MeasureTheory
open scoped BigOperators

#check (∀ {d : ℕ} (hd : 2 ≤ d) {κ : ℝ} (hκ : 2 ≤ κ)
    (O : Matrix.orthogonalGroup (Fin d) ℝ),
  let θ : Fin d → ℝ := fun i => ((i.val : ℝ) + 1 / 2) * Real.pi / (d : ℝ)
  let diagonalValue : Fin d → ℝ := fun i =>
    (κ + 1) / 2 + (κ - 1) / 2 * Real.cos (θ i)
  let A : Matrix (Fin d) (Fin d) ℝ :=
    (O : Matrix (Fin d) (Fin d) ℝ) * Matrix.diagonal diagonalValue *
      (O : Matrix (Fin d) (Fin d) ℝ).transpose
  let weight : EuclideanSpace ℝ (Fin d) → ℝ := fun x =>
    Real.exp (- (∑ i : Fin d, x.ofLp i * (A.mulVec x.ofLp) i) / 2)
  ProbabilityTheory.multivariateGaussian (0 : EuclideanSpace ℝ (Fin d)) A⁻¹ =
    (volume : Measure (EuclideanSpace ℝ (Fin d))).withDensity (fun x =>
      ENNReal.ofReal (weight x /
        (∫ y : EuclideanSpace ℝ (Fin d), weight y ∂volume))))
