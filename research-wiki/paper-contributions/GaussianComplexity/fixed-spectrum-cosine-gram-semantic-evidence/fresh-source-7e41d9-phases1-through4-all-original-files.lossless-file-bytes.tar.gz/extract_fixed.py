#!/opt/anaconda3/bin/python
import hashlib
import json
import pathlib
import re
from bs4 import BeautifulSoup

ROOT = pathlib.Path('/Users/zhouhuanjian/ASTIS-GC')
BASE = pathlib.Path(__file__).resolve().parent
RAW_PATH = ROOT / '.astis/huanjian-resume-20261103/2610.20492v1.html'
EXPECTED = '6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
raw = RAW_PATH.read_bytes()
digest = hashlib.sha256(raw).hexdigest()
assert len(raw) == 951991 and digest == EXPECTED, (len(raw), digest)
inputs = BASE / 'inputs'
inputs.mkdir(exist_ok=True)
(inputs / RAW_PATH.name).write_bytes(raw)
paths = ['AGENTS.md', 'docs/proof-digestion-protocol.md',
         'docs/theorem-publication-protocol.md',
         'docs/evidence-routed-memory-protocol.md',
         '.agents/skills/astis-source-dependency-audit/SKILL.md']
snapshots = []
for index, relative in enumerate(paths):
    data = (ROOT / relative).read_bytes()
    name = str(index) + '-' + pathlib.Path(relative).name
    (inputs / name).write_bytes(data)
    snapshots.append({'source': relative, 'snapshot': 'inputs/' + name,
                      'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
soup = BeautifulSoup(raw, 'html.parser')
def readable(tag):
    other = BeautifulSoup(str(tag), 'html.parser')
    for math in other.find_all('math'):
        math.replace_with(' $' + math.get('alttext', math.get_text(' ', strip=True)) + '$ ')
    return other.get_text('\n', strip=True)
summary = {'input': str(RAW_PATH.relative_to(ROOT)), 'bytes': len(raw), 'sha256': digest,
           'protocol_snapshots': snapshots, 'anchors': []}
for anchor in ['S4.Thmtheorem4', 'A3.SS2', 'A3.Thmtheorem5']:
    tag = soup.find(id=anchor)
    assert tag is not None, anchor
    raw_text = str(tag)
    (BASE / (anchor + '.parsed.html')).write_text(raw_text)
    (BASE / (anchor + '.text')).write_text(readable(tag))
    record = {'id': anchor, 'tag': tag.name, 'classes': tag.get('class'),
              'parsed_html_bytes': len(raw_text.encode()),
              'text_bytes': len(readable(tag).encode()),
              'parent_id': tag.parent.get('id')}
    summary['anchors'].append(record)
    print(json.dumps(record))
    print(readable(tag)[:1400])
(BASE / 'input_inventory.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'raw_bytes': len(raw), 'sha256': digest}))
