"""Unapplied successor. --preflight validates actual evidence without any mutation."""
from pathlib import Path
import datetime,gzip,hashlib,json,os,subprocess,sys
P=Path('.astis/huanjian-gc-fixed-spectrum-geometry-integration-20261109')
B=Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-geometry-integration-20261109')
E=Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-geometry-semantic-evidence')
Q=P/'independent-reader/conditional-proposal-v1'
CANDIDATE='ab8b47caed9f781191f8408154cd355c7e7c104c'
ADV='ASTIS-SA-20261109-GaussianComplexityFixedSpectrumGeometry'
OWNER='huanjian_gc_20261109_fixed_spectrum_geometry'
INTEGRATOR=OWNER+'_integration'
READER='/root/geometry_integration_reader'
VERIFIER='/root/source_reader_9a6d2f'
DECODER='/root/decode_80a1c2'
AP=Path('research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-geometry.json')
CP=Path('research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-geometry.json')
LP=Path('runs/substantive_advances.jsonl')
DP=Path('runs/substantive_discoveries.jsonl')
sha=lambda b:hashlib.sha256(b).hexdigest()
dump=lambda x:(json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode()
git=lambda *a:subprocess.check_output(['git',*a])
def readref(ref):
    p=Path(ref['path']); assert p.resolve().is_relative_to(Path.cwd())
    raw=p.read_bytes(); assert sha(raw)==ref['sha256'],p
    return raw
def rawfile(p):
    return os.fsencode(os.readlink(p)) if p.is_symlink() else p.read_bytes()
def rows(raw):
    assert raw and raw.endswith(b'\n')
    parsed=[json.loads(x) for x in raw.splitlines()]
    assert all(isinstance(x,dict) for x in parsed)
    return parsed
def differences(x,y,path=''):
    if isinstance(x,dict) and isinstance(y,dict):
        out=[]
        for k in sorted(x.keys()|y.keys()):
            q=path+'/'+k.replace('~','~0').replace('/','~1')
            out+=differences(x[k],y[k],q) if k in x and k in y else [q]
        return out
    return [] if x==y else [path]
def spans(text):
    dec=json.JSONDecoder(); out={}
    def ws(i):
        while i<len(text) and text[i].isspace():i+=1
        return i
    def value(i,path):
        i=ws(i); start=i
        if text[i]=='{':
            i=ws(i+1)
            while text[i]!='}':
                key,j=dec.raw_decode(text,i); i=ws(j); assert text[i]==':'
                i=ws(value(i+1,path+(key,)))
                if text[i]==',':i=ws(i+1)
                else:assert text[i]=='}'
            i+=1
        elif text[i]=='[':
            i=ws(i+1); n=0
            while text[i]!=']':
                i=ws(value(i,path+(n,))); n+=1
                if text[i]==',':i=ws(i+1)
                else:assert text[i]==']'
            i+=1
        else:_,i=dec.raw_decode(text,i)
        out[path]=(start,i); return i
    end=value(0,()); assert not text[end:].strip(); return out
def append_integration(raw,metadata):
    text=raw.decode(); cell=json.loads(text)
    assert cell['evidence'] and 'canonical_integration' not in cell['evidence']
    ss=spans(text); last=list(cell['evidence'])[-1]
    a,i=ss[('evidence',last)]
    line=text[text.rfind('\n',0,a)+1:a]
    indent=line[:len(line)-len(line.lstrip(' \t'))]
    eol='\r\n' if '\r\n' in text[max(0,a-300):a] else '\n'
    addition=','+eol+eol.join(indent+x for x in ('"canonical_integration": '+json.dumps(metadata,ensure_ascii=False,indent=2)).splitlines())
    after=(text[:i]+addition+text[i:]).encode()
    assert (after.decode()[:i]+after.decode()[i+len(addition):]).encode()==raw
    parsed=json.loads(after); assert parsed['evidence'].pop('canonical_integration')==metadata and parsed==cell
    assert differences(cell,json.loads(after))==['/evidence/canonical_integration']
    return after,{'character_insertion_offset':i,'inserted_text':addition,'inverse_restores_exact_before':True}

authpath=P/'root-sole-STAB-application-authorization-v2.json'
auth_raw=authpath.read_bytes(); auth=json.loads(auth_raw)
assert auth['authorized_by']=='/root' and auth['exact_six_path_application_authorized'] is True
assert auth['own_frontier_single_object_projection_authorized'] is True and auth['new_source_verdict'] is False
assert auth['application_helper_sha256']==sha(Path(__file__).read_bytes())
accepted_review=json.loads(readref(auth['independent_successor_review']))
assert accepted_review['reviewer']==READER and accepted_review['verdict']=='ACCEPT_EXACT_UNAPPLIED_SUCCESSOR'
assert accepted_review['helper_sha256']==sha(Path(__file__).read_bytes())
head=git('rev-parse','HEAD').decode().strip(); assert head==auth['source_V_first_carrying_commit'] and head!=CANDIDATE
assert not git('diff','HEAD','--name-only').strip()
assert git('rev-parse','origin/main').decode().strip()==auth['fresh_origin_main']
for ancestor in [CANDIDATE,auth['fresh_origin_main']]:subprocess.run(['git','merge-base','--is-ancestor',ancestor,head],check=True)
report=Q/'proposal-report.json'; freeze=Q/'freeze.json'
assert sha(report.read_bytes())==auth['proposal_report_sha256']=='6f9045472dc9f11da494942d065b093efab12c2cf385f6d83a379ad771a5e904'
assert sha(freeze.read_bytes())=='3bebcf376f16376e2225accf6db7fb679034923a7e7a9b8a526dccf5334e3bda'
for row in json.loads(freeze.read_bytes())['files']:assert sha(Path(row['path']).read_bytes())==row['sha256']
review=P/'root-conditional-six-path-review.json'
assert sha(review.read_bytes())==auth['root_conditional_review_sha256']=='d0976e1b5f621fc0ecd157ea466ab02e135f71ef74bd2d3f7a002c5ee409832d'
r=json.loads(report.read_bytes()); assert len(r['shared_paths'])==6
br=r['protected_baseline']; z=Path(br['path']).read_bytes(); assert sha(z)==br['gzip_sha256']
baseline_raw=gzip.decompress(z); assert sha(baseline_raw)==br['raw_sha256']
baseline=json.loads(baseline_raw); assert baseline['candidate']==CANDIDATE

# Read and validate raw complete event history BEFORE importing/calling loaders
# which may recover an interrupted tail. Pure replay below has no recovery I/O.
before=LP.read_bytes(); candidate_ledger=git('show',CANDIDATE+':'+str(LP))
vraw=readref(auth['actual_source_V_append']); assert vraw.endswith(b'\n') and len(vraw.splitlines())==1
assert before==candidate_ledger+vraw and sha(before)==auth['ledger_before_STAB_sha256']
records=rows(before); rows(candidate_ledger); v=json.loads(vraw)
assert v['event']=='transition' and v['advance_id']==ADV
assert (v['from_state'],v['to_state'])==('PROVED_LOCAL','VERIFIED')
audit_raw=readref(auth['accepted_source_audit']); assert auth['accepted_source_audit']['path']==str(AP)
audit=json.loads(audit_raw); verifier=audit['source_review']['reviewer']
assert verifier==auth['source_verifier']==VERIFIER==v['worker_id']==v['evidence']['verifier_id']
assert audit['lean']['formalizer']==OWNER and audit['reconstruction']['decoder']==DECODER
assert len({verifier,OWNER,DECODER,INTEGRATOR,'/root',READER})==6
assert audit['state']=='accepted' and audit['publication_binding_sha256']==r['publication_binding_sha256']
assert v['evidence']['verified_commit']==CANDIDATE
assert all(v['evidence'][k] for k in ['gate','source_audit','fake_closure_scan'])
source_run=readref(auth['source_review_run'])
assert sha(source_run)==audit['source_review']['review_run_sha256']
execution=json.loads(readref(auth['source_V_actual_execution_manifest']))
assert execution['actor']==verifier and execution['normal_API_calls']==1 and execution['exact_append_sha256']==sha(vraw)
assert execution['verified_commit']==CANDIDATE and execution['publication_binding_sha256']==audit['publication_binding_sha256']
assert execution['accepted_audit_sha256']==sha(audit_raw) and execution['source_review_run_sha256']==sha(source_run)
assert git('show',head+':'+str(AP))==audit_raw and git('show',head+':'+str(LP))==before
assert sha(git('show',CANDIDATE+':'+str(AP)))==baseline['all_tracked'][str(AP)]['sha256']
assert sha(candidate_ledger)==baseline['all_tracked'][str(LP)]['sha256']
cell_raw=CP.read_bytes(); old_cell_raw=git('show',CANDIDATE+':'+str(CP))
assert sha(old_cell_raw)==baseline['all_frontier_raw_hashes'][str(CP)]
assert sha(cell_raw)==auth['source_V_own_frontier_sha256'] and git('show',head+':'+str(CP))==cell_raw
if cell_raw!=old_cell_raw:
    projection=json.loads(readref(auth['source_V_own_frontier_projection_review']))
    assert projection['reviewer']==READER and projection['verdict']=='ACCEPT_EXACT_MECHANICAL_SOURCE_V_PROJECTION'
    assert projection['before_sha256']==sha(old_cell_raw) and projection['after_sha256']==sha(cell_raw)
    assert projection['candidate_commit']==CANDIDATE and projection['source_V_append_sha256']==sha(vraw)
    changed=differences(json.loads(old_cell_raw),json.loads(cell_raw)); assert changed==projection['changed_json_paths']
    allowed={'/status','/evidence/independent_verification','/evidence/existing_source_V','/evidence/source_phase_history',
        '/evidence/execution_boundary','/statement_seal/status','/source_detail_audit/gap',
        '/source_detail_audit/fidelity_boundary','/source_proof_coverage/independent_implementation_review'}
    assert set(changed)<=allowed and projection['new_mathematical_or_source_verdict'] is False
else:assert auth['source_V_own_frontier_projection_review'] is None
cell=json.loads(cell_raw); assert 'canonical_integration' not in cell['evidence']
assert cell['owner_id']==OWNER and cell['advance_id']==ADV

payloads=[]; shared={row['path'] for row in r['shared_paths']}
for row in r['shared_paths']:
    q=Path(row['path']); assert q.exists()==row['before_exists']
    assert not q.exists() or sha(rawfile(q))==row['before_sha256']
    ref=row['planned_after_archive']; z=Path(ref['path']).read_bytes(); raw=gzip.decompress(z)
    assert sha(z)==ref['gzip_sha256'] and sha(raw)==row['planned_after_sha256'] and len(raw)==ref['raw_bytes']
    payloads.append((q,raw))
exceptions={str(AP),str(LP),str(CP)}
def baseline_check(applied):
    for name,row in baseline['all_tracked'].items():
        if name in exceptions or (applied and name in shared):continue
        q=Path(name); assert q.is_symlink()==row['symlink'] and sha(rawfile(q))==row['sha256'],name
    for name,digest in baseline['all_frontier_raw_hashes'].items():
        if name!=str(CP):assert sha(Path(name).read_bytes())==digest,name
    assert {str(q) for q in CP.parent.glob('*.json')}==set(baseline['all_frontier_raw_hashes'])
    allowed_new_prefixes=(str(E)+'/',str(B)+'/') if applied else (str(E)+'/',)
    now_tracked=set(git('ls-files','-z').decode().strip('\0').split('\0'))
    added=now_tracked-set(baseline['all_tracked'])
    assert all(name.startswith(allowed_new_prefixes) or (applied and name in shared) for name in added),added
baseline_check(False)
sys.path[:0]=['tools','website/scripts']
import astis_advance as adv
import astis_publication as pub
import astis_site as site
discovery_raw=DP.read_bytes(); discovery_records=rows(discovery_raw)
states=adv._replay_advances(records); discoveries=adv._replay_discoveries(discovery_records)
assert {k:v for k,v in states.items() if k!=ADV}==baseline['foreign_SAU_states']
assert discoveries==baseline['all_discovery_states']
assert states[ADV]['state']=='VERIFIED' and states[ADV]['owner_id']==OWNER
assert not [k for k,v in states.items() if v['state']=='STABILIZING']
pub.check_advance([audit['lean']['declaration']],reviewed=True)
assert LP.read_bytes()==before and AP.read_bytes()==audit_raw and CP.read_bytes()==cell_raw
assert not B.exists()
if '--preflight' in sys.argv:
    print(json.dumps({'state':'ACTUAL_EVIDENCE_PREFLIGHT_PASS_NO_MUTATION','head':head,'baseline_files':len(baseline['all_tracked']),
        'normal_API_calls':0,'sourceV_reissued':False,'six_payloads':6,'own_frontier_projection':'one new object only, actual STAB hash determined at normal transition'}));sys.exit(0)
B.mkdir()
(B/authpath.name).write_bytes(auth_raw)
for name,raw in [('before-STAB-ledger.raw.jsonl.gz',before),('sourceV-own-frontier.before.raw.json.gz',cell_raw)]:
    (B/name).write_bytes(gzip.compress(raw,mtime=0))
adv.transition_advance(ADV,'STABILIZING',worker_id=INTEGRATOR,evidence={
    'integration_owner':INTEGRATOR,'canonical_branch':git('branch','--show-current').decode().strip(),
    'verifier_id':verifier,'verified_commit':CANDIDATE,'source_V_first_carrying_commit':head,
    'publication_declarations':[audit['lean']['declaration']],'lean_declarations':[audit['lean']['declaration']],
    'independent_proposal':str(report),'proposal_sha256':sha(report.read_bytes()),'root_exact_diff_review':str(review),
    'scope':'Exactly six reviewed shared payloads plus explicitly authorized one-object lossless own frontier metadata projection; original sourceV preserved.',
    'truth_boundary':'Selected local source/whole-module/freshLean/STATIC reader only. Actual immutable core/root/site/graph/desktop-mobile, remote, purification/Seal and both main lower bounds remain open.'})
after=LP.read_bytes(); assert after.startswith(before); append=after[len(before):]
assert append.endswith(b'\n') and len(append.splitlines())==1
event=json.loads(append)
assert event['event']=='transition' and event['advance_id']==ADV
assert (event['from_state'],event['to_state'])==('VERIFIED','STABILIZING')
assert event['worker_id']==event['evidence']['integration_owner']==INTEGRATOR
assert event['evidence']['verifier_id']==verifier and event['evidence']['verified_commit']==CANDIDATE
assert event['evidence']['publication_declarations']==event['evidence']['lean_declarations']==[audit['lean']['declaration']]
now=adv._replay_advances(rows(after)); assert [k for k,v in now.items() if v['state']=='STABILIZING']==[ADV]
assert now[ADV]['owner_id']==OWNER and {k:v for k,v in now.items() if k!=ADV}==baseline['foreign_SAU_states']
metadata={'state':'SOLE_STAB_EXACT_SIX_PATHS_APPLIED_ACTUAL_CORE_GATES_PENDING','owner':INTEGRATOR,
    'source_V_first_carrying_commit':head,'source_verifier_preserved':verifier,'proposal_report_sha256':sha(report.read_bytes()),
    'new_public_producer':audit['lean']['declaration'],'private_Test_Registry_node':False,'new_conceptual_transport':False,
    'actual_STAB_append_sha256':sha(append)}
cell_after,insertion=append_integration(cell_raw,metadata)
for q,raw in payloads:q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(raw)
CP.write_bytes(cell_after)
assert LP.read_bytes()==before+append and AP.read_bytes()==audit_raw and DP.read_bytes()==discovery_raw
for row in r['shared_paths']:assert sha(Path(row['path']).read_bytes())==row['planned_after_sha256']
baseline_check(True)
assert site.source_digest()==r['predicted_source_digest_after_exact_proposed_Lean_payloads']
(B/'sole-STAB-append.exact.jsonl').write_bytes(append)
for name,raw in [('after-STAB-ledger.raw.jsonl.gz',after),('own-frontier.after.raw.json.gz',cell_after)]:
    (B/name).write_bytes(gzip.compress(raw,mtime=0))
projection={'authorized_by':'/root','scope':'mechanical-own-cell-sourceV-STAB-evidence-only',
    'candidate_commit':CANDIDATE,'advance_id':ADV,'sourceV_before_sha256':sha(cell_raw),'before_sha256':sha(old_cell_raw),
    'after_sha256':sha(cell_after),'source_V_append_sha256':sha(vraw),'STAB_append_sha256':sha(append),
    'application_changed_json_paths':['/evidence/canonical_integration'],
    'changed_json_paths':differences(json.loads(old_cell_raw),json.loads(cell_after)),
    'insertion_inverse':insertion,'new_mathematical_or_source_verdict':False}
(B/'actual-own-frontier-projection.json').write_bytes(dump(projection))
record={'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'normal_state':'STABILIZING',
    'normal_API_calls':1,'actor':INTEGRATOR,'append_sha256':sha(append),'ledger_before_sha256':sha(before),'ledger_after_sha256':sha(after),
    'candidate_baseline_files_checked_before_and_after':len(baseline['all_tracked']),
    'foreign_states_preserved':len(baseline['foreign_SAU_states']),'foreign_raw_frontiers_preserved':len(baseline['all_frontier_raw_hashes'])-1,
    'exact_shared_payloads':r['shared_paths'],'additional_own_frontier_metadata':projection,
    'README_discovery_models_source_audit_preserved':True,'source_digest':site.source_digest(),
    'new_source_verdict_or_actual_core_gates_or_runtime_or_Goal_complete':False}
(B/'exact-shared-application-receipt.json').write_bytes(dump(record))
print(json.dumps({'state':'STABILIZING','normal_API_calls':1,'exact_shared_payloads':6,'additional_lossless_own_metadata_object':1,
    'baseline_files_checked':len(baseline['all_tracked']),'actual_source_digest':site.source_digest(),'sourceV_reissued':False}))
