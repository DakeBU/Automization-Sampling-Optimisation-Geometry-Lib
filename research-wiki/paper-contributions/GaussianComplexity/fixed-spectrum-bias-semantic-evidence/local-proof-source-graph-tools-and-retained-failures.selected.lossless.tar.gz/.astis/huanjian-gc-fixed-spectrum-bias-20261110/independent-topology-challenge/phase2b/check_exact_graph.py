"""Bounded independent source identity and graph traversal, not target proof."""
from pathlib import Path
from collections import Counter, defaultdict
import hashlib
import json
import re
import runpy

B = Path('.astis/huanjian-gc-fixed-spectrum-bias-20261110')
O = B / 'independent-topology-challenge/phase2b'
I = B / 'independent-source-graph/phase2'
PINS = {
    'phase2-freeze.json': '7c4b146f87028cee63f355bc6cf7b846c9e272d16adca7ccbb82396337d66de0',
    'source-proof-graph.json': 'cbb09cb05dd683f3ad535f42c7d016ecf5c4c781fdf1b1cba3161e8dd57d8dea',
    'exact-target-coverage.json': '3f28aff047704222ed4ec2414e67a48c84d602862e198b2f3226704e96ea372d',
    'root-closures.json': '491e6bd2a4732cc5eb0f3fc4f4fce2188ee4f4ee3c3d0649902e89da385af551',
    'statement-projection-audit.json': '41e76c8a289aed69d99df9f8645bf16391010821b93707c7f7eb2f5c6513a11f',
    'machine-inputs.json': '554788377593b8c7c6a02c7da8d6d091c15f4016e4b9b40828b6c02106961967',
    'binding-lineage.json': '9c406ca47929060caed76b8a25783404baa4a585cf48871a7ed7de3ec5d8ff27',
}


def pin(p):
    b = p.read_bytes()
    return {'path': str(p), 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}


input_pins = []
for name, sha in PINS.items():
    info = pin(I / name)
    assert info['sha256'] == sha, name
    input_pins.append(info)
g = json.loads((I / 'source-proof-graph.json').read_bytes())
c = json.loads((I / 'exact-target-coverage.json').read_bytes())
rc = json.loads((I / 'root-closures.json').read_bytes())
lineage = json.loads((I / 'binding-lineage.json').read_bytes())
own = json.loads((B / 'independent-topology-challenge/phase1/raw-inventory.json').read_bytes())
m = runpy.run_path('.astis/huanjian-gc-fixed-spectrum-variances-20261110/independent-topology-challenge/source_only_reader.py')
walk, record, ids = m['walk'], m['record'], m['READER'].ids
source_lines = m['TEXT'].splitlines(keepends=True)


def key(n):
    line = record(n)['line_start']
    col = n.start - (m['TEXT'].rfind('\n', 0, n.start) + 1)
    return f'{n.tag}@{line}:{col}'


def compact(s):
    return re.sub(r'\s+', '', s)


def actual_math(n):
    return [{'id': q.attrs.get('id'), 'line': record(q)['line_start'], 'tex': q.attrs.get('alttext', ''),
             'display': q.attrs.get('display', '')} for q in walk(n) if q.tag == 'math']


def actual_refs(n):
    return [{'line': record(q)['line_start'], 'href': q.attrs['href'], 'title': q.attrs.get('title', ''),
             'text': re.sub(r'\s+', ' ', m['normalized'](q)).strip()} for q in walk(n)
            if q.tag == 'a' and q.attrs.get('href', '').startswith('#')]


source_nodes = {key(n): n for root in ['S2', 'S4', 'A3.SS3', 'bib.bib3'] for n in walk(ids[root])}
own_keys = {}
for unit in own['items']:
    prefix = m['RAW'][:unit['byte_start_inclusive']].decode()
    unit_key = f"{unit['tag']}@{unit['line_start']}:{len(prefix.rsplit(chr(10), 1)[-1])}"
    assert unit_key not in own_keys
    own_keys[unit_key] = unit
rows = c['rows']
assert [r['raw_unit_ordinal'] for r in rows] == list(range(366))
machine_keys = [r['raw_source_unit']['source_unit_key'] for r in rows]
assert len(set(machine_keys)) == 366
assert set(machine_keys) <= set(own_keys)
own_extra = set(own_keys) - set(machine_keys)
assert own_extra == {'a@1853:0'}
external = source_nodes['a@1853:0']
assert external.attrs['href'].startswith('https://github.com/openai/math/blob/main/preprints/')
granularity = {'own_units': len(own_keys), 'machine_units': len(machine_keys),
              'own_only_unit': {**own_keys['a@1853:0'], 'href': external.attrs['href']},
              'resolution': 'One external bibliography download hyperlink is a separate own unit; machine enumerates internal references only. Its local bibliographic identity/text and original line remain under EXCLUDED bib.bib3, not an omitted theorem/claim.'}
whitespace_only = []
for row in rows:
    u = row['raw_source_unit']
    n = source_nodes[u['source_unit_key']]
    assert n.tag == own_keys[u['source_unit_key']]['tag']
    assert u['original_html_id'] == n.attrs.get('id')
    rr = record(n)
    assert u['original_lines'] == [rr['line_start'], rr['line_end']]
    a, z = u['original_lines']
    assert hashlib.sha256(''.join(source_lines[a - 1:z]).encode()).hexdigest() == u['raw_html_sha256']
    assert u['math'] == actual_math(n), u['id']
    assert u['references'] == actual_refs(n), u['id']
    assert compact(u['text_with_tex']) == compact(m['normalized'](n)), u['id']
    if u['text_with_tex'] != re.sub(r'\s+', ' ', m['normalized'](n)).strip():
        whitespace_only.append(row['raw_unit_ordinal'])
    parent = n.parent
    while parent and not parent.attrs.get('id'):
        parent = parent.parent
    assert u['parent_original_html_id'] == (parent.attrs.get('id') if parent else None), u['id']
    parent = n.parent
    while parent and parent.tag != 'table':
        parent = parent.parent
    assert u['containing_display_id'] == (parent.attrs.get('id') if parent else None), u['id']
    successor = row['exact_target_successor']
    assert successor['disposition'] in ['NODE', 'EXCLUDED']
    if successor['disposition'] == 'NODE':
        assert successor['graph_nodes'] and successor['reason'] is None
    else:
        assert successor['reason'] and not successor['graph_nodes']
raw_math = {v['id'] for row in rows for v in row['raw_source_unit']['math']}
assert raw_math == {v['id'] for v in own['math_registry']} and len(raw_math) == 350
collisions = {name: [r['raw_unit_ordinal'] for r in rows if r['raw_source_unit']['id'] == name]
              for name, count in Counter(r['raw_source_unit']['id'] for r in rows).items() if count > 1}
assert sorted(map(len, collisions.values())) == [2, 2]

nodes = {n['id']: n for n in g['nodes']}
routes = {r['id']: r for r in g['routes']}
assert len(nodes) == len(g['nodes']) == 58
assert len(routes) == len(g['routes']) == 50
assert g['OR_routes'] == []
incoming = defaultdict(list)
anchor_count = 0
for n in g['nodes']:
    for a in n['source_anchors']:
        u = rows[a['raw_unit_ordinal']]['raw_source_unit']
        for field in ['id', 'source_unit_key', 'original_lines', 'math', 'references', 'raw_html_sha256']:
            assert a[field] == u[field], (n['id'], field)
        anchor_count += 1
for route in g['routes']:
    assert route['logic'] == 'AND' and route['discharge'] and route['inputs']
    assert route['consumer'] in nodes and all(p in nodes for p in route['inputs'])
    incoming[route['consumer']].append(route)
    for a in route['consumer_use_sites']:
        u = rows[a['raw_unit_ordinal']]['raw_source_unit']
        for field in ['id', 'source_unit_key', 'original_lines']:
            assert a[field] == u[field], (route['id'], field)
assert {n for row in rows for n in row['exact_target_successor']['graph_nodes']} == set(nodes)
assert all(incoming[n['id']] for n in g['nodes'] if n['status'] == 'OPEN_INTERNAL_OBLIGATION')


def closure(root):
    seen, edge_set, active = set(), set(), set()

    def visit(n):
        assert n not in active, ('cycle', n)
        if n in seen:
            return
        active.add(n)
        for edge in incoming[n]:
            edge_set.add(edge['id'])
            for p in edge['inputs']:
                visit(p)
        active.remove(n)
        seen.add(n)

    visit(root)
    return {'root': root, 'nodes': sorted(seen), 'routes': sorted(edge_set),
            'node_source_anchor_ids': sorted({a['id'] for n in seen for a in nodes[n]['source_anchors']}),
            'route_use_site_anchor_ids': sorted({a['id'] for e in edge_set for a in routes[e]['consumer_use_sites']}),
            'leaves': sorted(n for n in seen if not incoming[n]),
            'internal_source_gap_obligations': sorted(n for n in seen if nodes[n]['kind'] == 'SOURCE_GAP'),
            'local_internal_obligations': sorted(n for n in seen if nodes[n]['kind'] == 'LOCAL_INTERNAL_OBLIGATION')}


closures = {}
for owner, provided in rc['closures'].items():
    computed = closure(provided['root'])
    for field in ['nodes', 'routes', 'internal_source_gap_obligations', 'local_internal_obligations']:
        assert computed[field] == provided[field], (owner, field)
    closures[owner] = computed
for n in nodes:
    closure(n)
subroots = {n: closure(n) for n in ['N_positive_M', 'N_signed_positive', 'N_bias_lower', 'N_bias_upper',
                                  'N_log_lower', 'N_log_upper', 'N_power_lower', 'N_power_upper',
                                  'N_tail_factor', 'N_Q_L2', 'N_Q_variance_2M', 'G_Chebyshev', 'C_root']}
assert 'D_gap' not in subroots['N_bias_upper']['nodes']
assert set(rc['consumer_required_producer_projection']) <= set(closures['private_actual_consumer']['nodes'])
assert set(rc['consumer_prior_actual_projection']) <= set(closures['private_actual_consumer']['nodes'])
assert set(rc['consumer_not_required']).isdisjoint(closures['private_actual_consumer']['nodes'])
canonical = lambda obj: hashlib.sha256(json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
raw_canonical = canonical([r['raw_source_unit'] for r in rows])
history_canonical = canonical([r['phase1_disposition'] for r in rows])
assert raw_canonical == lineage['successor_raw_rows_canonical_sha256'] == lineage['unchanged_raw_rows_canonical_sha256']
assert history_canonical == lineage['successor_history_rows_canonical_sha256'] == lineage['unchanged_history_rows_canonical_sha256']
old_sets = []
for subdir, name in [('phase1', 'SHA256SUMS.phase1'), ('phase2a', 'SHA256SUMS.phase2a'), ('phase2a', 'SHA256SUMS.postseal-process-v1')]:
    d = B / 'independent-topology-challenge' / subdir
    for line in (d / name).read_text().splitlines():
        h, n = line.split('  ', 1)
        assert pin(d / n)['sha256'] == h
    old_sets.append(pin(d / name))
result = {'run': 'BIAS-INDEPENDENT-PHASE2B-ORIGINAL-EXACT-GRAPH-20261110',
          'check_kind': 'source_identity_structural_assertions_not_semantic_admission',
          'structural_checks': 'PASS', 'inputs': input_pins,
          'creator_statement_audit_content': 'HASH_ONLY_NOT_PARSED',
          'inventory_granularity_resolution': granularity,
          'coverage': {'machine_rows': len(rows), 'own_units': len(own_keys),
                       'successor_counts_recomputed': dict(Counter(r['exact_target_successor']['disposition'] for r in rows)),
                       'kinds': dict(Counter(r['raw_source_unit']['kind'] for r in rows)),
                       'source_unit_keys_unique': True, 'every_raw_line_hash_text_math_reference_parent_and_TBODY_context_rebound': True,
                       'unique_math_ids': len(raw_math), 'synthetic_ID_collisions_disambiguated_by_source_key_and_ordinal': collisions,
                       'render_whitespace_only_difference_ordinals': whitespace_only},
          'graph': {'nodes': len(nodes), 'AND_routes': len(routes), 'OR_routes': 0,
                    'node_source_snapshots_checked': anchor_count,
                    'route_use_sites_checked': sum(len(r['consumer_use_sites']) for r in routes.values()),
                    'no_free_open_obligation_leaf': True, 'acyclic_all_components': True},
          'root_closures_recomputed': closures, 'every_target_and_selected_guard_subroot': subroots,
          'raw_and_history_current_canonical_hashes_match_lineage_bindings': [raw_canonical, history_canonical],
          'old_own_checksum_sets_and_members_rechecked': old_sets,
          'semantic_HOLDs_separately_recorded': ['H-POWER-ORDER-SIGN', 'H-CHEBYSHEV-CONDITIONAL-SCOPE'],
          'no_implementation_API_Mathlib_or_target_proof': True}
O.mkdir(parents=True, exist_ok=True)
p = O / 'original-graph-checks.json'
assert not p.exists()
p.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'output': pin(p), 'coverage_counts': result['coverage']['successor_counts_recomputed'],
                  'closure_counts': {k: [len(v['nodes']), len(v['routes'])] for k, v in closures.items()}}, ensure_ascii=False, indent=2))
