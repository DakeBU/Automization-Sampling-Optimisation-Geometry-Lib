# Bias original exact graph: independent admission HOLD

**HOLD for two typed semantic/conditional clarifications only.** The independently frozen statement/binder/definition ACCEPT is unchanged. No source mathematical refutation, new theorem input, signature change or new implementation requirement is requested. Prospective proof/API and implementation-oriented planning remain closed until an exact successor is independently reviewed. Preserve this initial HOLD and every original input byte.

The admitted statement input remains strict projection `b245ddf40403f7aca7d2f0be6de9953cf1fb2bda57e840d9ee6bf6156aac8511`. This challenge binds original graph `cbb09cb05dd683f3ad535f42c7d016ecf5c4c781fdf1b1cba3161e8dd57d8dea`, coverage `3f28aff047704222ed4ec2414e67a48c84d602862e198b2f3226704e96ea372d`, closure record `491e6bd2a4732cc5eb0f3fc4f4fce2188ee4f4ee3c3d0649902e89da385af551`, and the other exact parent-authorized machine hashes listed in the check receipt. The extractor statement-audit artifact was hashed only; its contents were deliberately not parsed or used as a verdict.

## H-POWER-ORDER-SIGN

Exact pointer `/nodes/31/statement`, node `G_power_log_exp`, currently says:

```text
Relate ρ^k to exp(−k log(1/ρ)); positivity and order reversal on multiplying by nonnegative source modes; real casts of natural powers/differences.
```

Multiplication by a nonnegative mode k preserves weak order. The reversal needed by these exponent estimates comes from the **nonpositive multiplier −k**, or equivalently the order-reversing function t↦exp(−kt) for k≥0. The adjacent formula displays are correct; this literal mechanism description is inaccurate unless its negative multiplier is made explicit.

Minimal repair: replace that statement with exact negative-multiplier/sign semantics and retain the existing natural-power/cast/domain obligations. No public hypothesis, formula, source anchor, route input or signature need change. Do not turn the needed sign arithmetic into an extra binder. This is a semantic-text correction to an internal source bridge, not advice about Lean APIs or a new proof route.

## H-CHEBYSHEV-CONDITIONAL-SCOPE

Exact pointer `/nodes/52/statement`, node `G_Chebyshev`, currently describes an actual Chebyshev inequality **at a positive mean**. Its only incoming route is `/routes/46` (`r_cheb`), whose inputs are `G_sign_centered` and `G_event_probability`. That subroot does not contain `N_signed_actual_mean` or `N_signed_positive`. Positive actual mean appears later in `/routes/47` (`r_zerocheb`) through `N_signed_actual_mean`.

There is a valid intended composition here, but the current text does not distinguish a generic conditional Chebyshev rule from an already instantiated positive-mean assertion. Interpreting `G_Chebyshev` as an unconditional instance silently treats an undisclosed positive-mean fact as available at its own subroot. The complete consumer happens to contain positivity through the later application; that does not type the earlier node's conditional scope.

Minimal acceptable repair, either choice:

1. Explicitly type `G_Chebyshev` as a **conditional/generic** finite-centered-moment inequality with its positive threshold/mean guard retained as an antecedent. Identify `r_zerocheb` as the actual application site where `N_signed_actual_mean` discharges that guard. Do not claim it was already discharged at `r_cheb`.
2. If the node is intended as the actual positive-mean instance, add the actual signed-mean/positivity dependency to `r_cheb` and recompute the affected subroot records.

No new public premise or callback certificate is acceptable. This request does not dispute Chebyshev or the private numerical statement; it requires the graph to say where its condition is supplied. A typed clarification can preserve all final formulas and full-root node sets.

## Source identity and exhaustive coverage checks passed

The independent raw phase1 inventory had 367 units: complete S2, complete S4, complete C.3, and the locally cited bibliography entry. The extractor has **366**, with exactly the same mathematical/structural units. The sole difference is granularity: own inventory separately counts the external bibliography download hyperlink `a@1853:0`; the extractor counts internal-reference hyperlinks only. Its 53 internal-reference units plus this one external navigation link equal the own 54 link occurrences. The external work's local identity/text and original raw line remain in the EXCLUDED `bib.bib3` row. The linked external document was not opened. This is not a missing theorem, premise or citation identity.

All 366 machine source keys uniquely match actual tag/line/column positions and distinct own raw elements. Every raw line-slice hash, original HTML ID, text modulo renderer whitespace, math tuple, internal-reference tuple, nearest ID-bearing parent and true containing display was independently checked against pinned HTML. All **350 unique math elements** equal the own raw registry. There is exactly one reasoned successor per ordinal: **55 NODE, 311 EXCLUDED**. All 58 graph nodes have coverage mappings. No coverage claim rests solely on matching counts.

Same-line anonymous link collisions are preserved by actual source key and ordinal: 66/68 at line1112 and 181/182 at line1388. Both href/text occurrences were checked independently. Selected log rows Ex152–156 are actual named TBODY NODEs with correct parent groups; aggregate log tables are reasoned duplicate exclusions. Ex149 is the selected actual Q-variance row. Ex148/norm variance and the closed-M upper are unnecessary here. The projection-listed `A3.SS3.p11.3` is only ∎ and is correctly excluded; the final paired bias formula is Ex159.

Historical family/Krylov references [22], S2 oracle/TV definitions, full algorithm/rotation/query/limitations branches and original probability context have explicit scope exclusions or context-only nodes. In particular Ex25/26 do not become quoted zero-threshold results. Relevant actual-moment prerequisites remain expanded with precise mathematical meanings, not hidden behind claims of prior compiler verification.

## Graph traversal and other semantic checks passed

The graph has **58 nodes, 50 AND routes, no OR routes** and no directed cycle. All 20 SOURCE_GAP and four local-internal-obligation nodes have incoming internal routes; no such proof obligation is a free premise leaf. I rebound 121 node source snapshots and 72 route use sites to raw inventory positions. Current raw/history canonical hashes match their immutable lineage bindings; historical private cognition/scripts were not opened to manufacture an independent old-content claim.

Independent backward traversal exactly reproduces the provided full node/edge/gap sets and separately records source-anchor/use-site sets:

| Root/subroot | Nodes | Routes |
| --- | ---: | ---: |
| M positivity | 17 | 14 |
| signed b positivity | 19 | 15 |
| lower bias | 34 | 29 |
| upper bias | 31 | 27 |
| whole producer | 38 | 33 |
| log lower / log upper, each | 6 | 4 |
| power lower / power upper, each | 9 | 6 |
| separated tail factor | 10 | 6 |
| prior actual Q L2 | 8 | 5 |
| prior actual Q variance≤2M | 16 | 13 |
| present G_Chebyshev subroot | 20 | 16 |
| whole private consumer | 52 | 46 |

D_gap is needed only for the separated tail/lower-bias branch, not M positivity, signed positivity, scalar log/power bounds or upper bias. The common public conjunction retains the source gap for the combined conclusion. Background object/family bundles are not standalone claims of a minimal κ-only reusable log API. Source graph expansion of prior C7/means/variance routes is provenance, not a demand for new proof credit or an instruction to reimplement canonical prerequisites.

The actual-law chain retains positive precision/inverse covariance, probability semantics, finite Gaussian coordinate moments and integrability. Actual finite expectation/sum exchange is separate from the absolute scalar-series/finite-grid interchange. C8's all-integer alias classes and source mode/parity/disjointness are explicit internal prerequisites, not binders. M and b remain actual expectations; positivity and ratio cancellation do not rely on default-zero integrals/division.

The source log-integral route preserves κ≥2, a nonsingular compact interval, denominator/integrability background, the exact 8/3<3 estimate and constants 1−exp(−4),3,2. The parent-requested two clarifications above are confined to typing/sign semantics; no alternative source proof or false OR route is proposed.

The private closure materially contains new lower bias, positive actual M and signed actual mean, plus actual Q L2/variance≤2M. It excludes the producer's unused upper bias, the bundled producer root and the original nonzero-τ contrast/probability context. Actual event measurability, finite measure before `.toReal`, finite centered variance, unit sign magnitude and positive numerical factors are internally present. Independence is only for the diagonal coordinate-square variance prerequisite; no Q/norm-square independence is claimed.

The event is genuinely `{(−1)^n Q≤0}` under the actual diagonal Gaussian. No τ=0 source binder, rotated-Y callback, .9 probability, 320/large-d/query/TV assumption or main-bound credit enters either root. Actual future material use still requires a later proof review; this is a source graph, not a Lean implication certificate.

## Preserved process boundary

Own raw, statement ACCEPT and both separate process freezes were rehashed unchanged. The preseal parent/source exposure and postseal informal Lean/API-memory planning deviation remain explicit. No pristine-order or zero-cue certificate is issued. The pending process gate is not cleared by these structural PASS results while the two typed graph HOLDs remain.

Only the exact allowed machine artifacts, pinned raw source, unchanged own raw parser and own frozen records were used. Freeze metadata unavoidably exposed creator filenames/status strings; they were not adopted as judgments. The creator statement-audit file was hash-bound only. No extractor private cognition/generator, target implementation, Mathlib/API, lesson, other-reviewer audit, full seal, normal ledger/frontier or source V was read or run.

The bounded check had two local schema-adaptation attempts retained as separate scripts: the original run did not produce a receipt; a captured second run exposed that route use sites omit `source_unit_key`; the third run uses the actual ordinal/ID/line schema and passed. This was a checker schema assumption, not a source/graph failure. The original inputs and initial scripts are retained; no producer graph was repaired by this reviewer.

Stop after this immutable HOLD. Submit only the two precise issues to the original extractor for an append-only successor, then re-review the exact changed semantics and required inherited references. No proof/API work or retroactive waiver is authorized by this report.
