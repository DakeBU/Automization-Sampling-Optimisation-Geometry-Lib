from pathlib import Path
import copy,json,hashlib,stat,datetime
ROOT=Path(__file__).resolve().parent;REPO=ROOT.parents[2];P1=ROOT.with_name('kr_sg_31f8c2');P2=ROOT.with_name('kr_sg_31f8c2_phase2')
sha=lambda b:hashlib.sha256(b).hexdigest()
dump=lambda n,x:(ROOT/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
oldg=json.loads((P1/'source-graph.json').read_bytes());oldt=json.loads((P2/'type-source-overlay.json').read_bytes());g=json.loads((ROOT/'source-graph.v2.json').read_bytes());t=json.loads((ROOT/'type-source-overlay.v2.json').read_bytes());delta=json.loads((ROOT/'structured-delta-and-lineage.json').read_bytes())
assert sha((P1/'source-graph.json').read_bytes())==delta['lineage']['source_graph_parent']['sha256']
assert sha((P2/'type-source-overlay.json').read_bytes())==delta['lineage']['typed_overlay_parent']['sha256']
for path,h in delta['outputs'].items():assert sha((ROOT/path).read_bytes())==h
def apply(original,ops):
    out=copy.deepcopy(original)
    for op in ops:
        tokens=[x.replace('~1','/').replace('~0','~') for x in op['path'].split('/')[1:]];parent=out
        for token in tokens[:-1]:parent=parent[int(token)] if isinstance(parent,list) else parent[token]
        key=int(tokens[-1]) if isinstance(parent,list) else tokens[-1]
        if op['operation']=='add':
            assert isinstance(parent,dict) and key not in parent;parent[key]=copy.deepcopy(op['after'])
        else:
            assert parent[key]==op['before']
            if op['operation']=='remove':del parent[key]
            else:assert op['operation'] in ['replace','replace-list'];parent[key]=copy.deepcopy(op['after'])
    return out
assert apply(oldg,delta['source_graph_exact_changes'])==g
assert apply(oldt,delta['typed_overlay_exact_changes'])==t
on={x['id']:x for x in oldg['nodes']};nn={x['id']:x for x in g['nodes']};oe={x['id']:x for x in oldg['and_hyperedges']};ne={x['id']:x for x in g['and_hyperedges']}
assert {key for key in on if on[key]!=nn[key]}=={'C5.polynomials','C5.span-conversion','C2.witness'}
assert set(nn)-set(on)=={'E.range-existential','C5.range-reverse','E.diagonal-power-action'}
assert {key for key in oe if oe[key]!=ne[key]}=={'e-witness','e-span'}
assert set(ne)-set(oe)=={'e-range-reverse'}
assert oe['e-range']==ne['e-range'] and on['E.range-columns']==nn['E.range-columns']
assert ne['e-witness']['parents']==['C5.range-reverse','E.range-existential']
assert 'E.range-columns' not in ne['e-witness']['parents']
assert ne['e-span']['parents']==['C5.polynomials','E.diagonal-power-action','E.triangular']
pins=json.loads((P1/'source-pins.json').read_bytes());sourceids={x['id'] for x in pins['elements']}
for node in g['nodes']:assert set(node['source_ids'])<=sourceids
for edge in g['and_hyperedges']:
    assert edge['consumer'] in nn and set(edge['parents'])<=set(nn)
    assert set(edge['consumer_use_source_ids'])<=sourceids
todo={x:set() for x in nn}
for edge in g['and_hyperedges']:todo[edge['consumer']].update(edge['parents'])
seen=set()
while True:
    new={key for key,parents in todo.items() if parents<=seen}-seen
    if not new:break
    seen|=new
assert seen==set(nn)
for old,new in zip(oldt['roots'],t['roots']):
    for field in ['name','planned_file','exact_signature','exact_signature_sha256','binders','literal_local_definitions','local_index_binders','source_root_nodes','public_hypothesis_audit','implementation_boundary']:assert old[field]==new[field]
    assert sha(new['exact_signature'].encode())==new['exact_signature_sha256']
    assert set(new['source_root_nodes'])<=set(nn)
assert oldt['local_definition_audit']==t['local_definition_audit']
for ob in t['mathematical_obligations']:assert set(ob['source_nodes'])<=set(nn)
for r in ['P.objects','P.polynomial','P.triangular']:
    assert next(x for x in t['mathematical_obligations'] if x['id']==r)['requires_internal_subobligations']==['P.diagonal-action']
assert not t['compile_and_review_status']['target_theorem_compiled'] and not t['compile_and_review_status']['sourceV_issued'] and not t['compile_and_review_status']['independent_topology_approval_issued']

source=REPO/'.astis/huanjian-resume-20261103/2610.20492v1.html';raw=source.read_bytes();s=raw.decode();assert len(raw)==951991 and sha(raw)==delta['lineage']['raw_source_sha256']
for pin in json.loads((ROOT/'source-use-pins.json').read_bytes())['records']:
    a,z=pin['utf8_span_0based_halfopen'];ca,cz=pin['char_span_0based_halfopen'];span=raw[a:z]
    assert span==s[ca:cz].encode()==(ROOT/'source-spans'/(pin['id']+'.html')).read_bytes() and sha(span)==pin['sha256_raw_utf8']
packet=(ROOT/'exact-selective-packet.json').read_bytes();assert sha(packet)=='471d8f4351d80f33d478049a0a2d8716689b2140c043aa324d8132f9b3fb79cb';packet=json.loads(packet)
seal=(REPO/packet['sealed_statement_file_for_hash_and_signature_fields_only']).read_bytes();assert sha(seal)==delta['lineage']['statement_seal_sha256'];seal=json.loads(seal)
for key,item in zip(['producer','actual_private_consumer'],packet['lean']):
    for field in ['name','planned_file','signature','signature_sha256']:assert seal[key][field]==item[field]
for inp in json.loads((ROOT/'revision-input-pins.json').read_bytes())['critique_inputs']:
    assert sha(Path(inp['path']).read_bytes())==sha((ROOT/inp['copied_as']).read_bytes())==inp['raw_sha256']

baseline=json.loads((ROOT/'original-phases-baseline.json').read_bytes());preservation={}
for label,entry in baseline.items():
    base=Path(entry['root']);items=[]
    for path in sorted([base]+list(base.rglob('*'))):
        assert not path.is_symlink();st=path.stat();rec={'path':'.' if path==base else str(path.relative_to(base)),'type':'directory' if path.is_dir() else 'file','mode':format(stat.S_IMODE(st.st_mode),'04o'),'inode':st.st_ino,'mtime_ns':st.st_mtime_ns,'ctime_ns':st.st_ctime_ns}
        if path.is_file():
            b=path.read_bytes();rec.update(bytes=len(b),sha256=sha(b))
        items.append(rec)
    old={x['path']:x for x in entry['items']};new={x['path']:x for x in items};changed=[x for x in sorted(set(old)|set(new)) if old.get(x)!=new.get(x)]
    preservation[label]={'root':str(base),'changed_paths':changed,'file_count':sum(x['type']=='file' for x in items),'directory_count':sum(x['type']=='directory' for x in items),'before_snapshot_sha256':sha(json.dumps(entry['items'],sort_keys=True).encode()),'after_snapshot_sha256':sha(json.dumps(items,sort_keys=True).encode())}
dump('original-phases-preservation-final.json',{'checked_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'phases':preservation,'compared_fields':'all paths, type, file content size/hash, mode, inode, mtime_ns, ctime_ns; read access atime intentionally excluded','status':'unchanged' if all(not x['changed_paths'] for x in preservation.values()) else 'ACTUAL PRESERVATION FAILURE'})
assert all(not x['changed_paths'] for x in preservation.values())
assert preservation['phase1']['file_count']==111 and preservation['phase1']['directory_count']==6
assert preservation['phase2']['file_count']==47 and preservation['phase2']['directory_count']==3
for path in (ROOT/'commands').glob('*.receipt.json'):
    rec=json.loads(path.read_bytes());prefix=path.name[:-len('.receipt.json')]
    for stream in ['stdout','stderr']:
        b=(path.parent/(prefix+'.'+stream)).read_bytes();assert len(b)==rec[stream+'_bytes'] and sha(b)==rec[stream+'_sha256']
    for script in rec['script_inputs']:assert sha((REPO/script['path']).read_bytes())==script['sha256']
dump('exposure-and-scope-record.json',{'phase3_authorized_challenge_exposure':['repair-requests.json','phase2b_topology_judgment.md'],'additional_challenger_artifacts_read':[],'own_prior_frozen_phases_read':True,'source_spans_independently_reread':['S4.E11','S4.Ex10','A3.SS2.p1','A3.SS2.p3','A3.SS2.p19.2','A3.EGx13'],'selective_types_and_definitions_rechecked':True,'full_seal_handling':'Raw hash and authorized producer/private consumer name,file,signature,hash fields only; no other content displayed.','new_generic_API_or_proof_body_search':False,'target_implementation_read_or_changed':False,'root_planning_or_binder_audit_read':False,'restricted_ATLAS_read':False,'new_agents_or_background_ASTIS':False,'actual_phase3_failures':[],'actual_phase3_truncations':[],'prior_limits':'Phase1/Phase2 exposure/capture limitations remain preserved in their immutable roots. Ordinary pretrained mathematical knowledge remains available; no absolute-pristine or zero-pretraining claim.','review_boundary':'Author source-supported revision after challenge. Independent exact-overlay recheck pending; no sourceV, topology approval, compiled proof or compiled-edge assertion.'})
print(json.dumps({'exact_delta_reapplies_to_both_original_objects':True,'changed_old_source_nodes':['C5.polynomials','C5.span-conversion','C2.witness'],'changed_old_edges':['e-span','e-witness'],'new_source_nodes':3,'new_source_edges':1,'graph_acyclic':True,'source_use_pins_rechecked':True,'exact_signatures_binders_and_literal_definitions_unchanged':True,'original_phases_preserved':{k:{'files':v['file_count'],'directories':v['directory_count']} for k,v in preservation.items()},'commands_and_actual_script_hashes_checked':True,'sourceV_or_topology_approval':False},ensure_ascii=False,indent=2))
