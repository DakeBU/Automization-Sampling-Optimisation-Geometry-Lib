from pathlib import Path
import json,hashlib,subprocess,re,sys
sys.dont_write_bytecode=True
sys.path.insert(0,'tools')
import astis_advance as adv
W=Path('.astis/huanjian-gc-fixed-spectrum-mode-gap-20261110')
E=Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-mode-gap-semantic-evidence')
R=Path('.astis/semantic-neutral-20261110/src_62f8c4/sourcev_execution_20261110/public')
D=E/'actual-source-V'
sha=lambda b:hashlib.sha256(b).hexdigest()
dump=lambda x:(json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode()
def put(p,b):
    assert not p.exists(),p
    p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
mf=R/'output-file-manifest.json';fr=R/'execution-freeze.json'
assert sha(mf.read_bytes())=='182c2457baf71403f3c1d01eb20003511142d630aee4e1ab4c181223302574ed'
assert sha(fr.read_bytes())=='d92ee6952cf3ae3e40aacb720275df6bbcecf35c42eac59027e220ed3fef9059'
m=json.loads(mf.read_bytes());f=json.loads(fr.read_bytes())
assert m['public_safe'] and m['private_raw_snapshots_excluded']
assert f['actual_normal_transition_API_calls']==1 and f['foreign_and_frontier_and_PBPS_SPHMC_preservation_pass']
listed={r['file']:r for r in m['files']}
actual={str(p.relative_to(R)) for p in R.rglob('*') if p.is_file()}
assert actual==set(listed)|{'output-file-manifest.json','execution-freeze.json','SHA256SUMS'},actual-set(listed)
checksums=(R/'SHA256SUMS').read_bytes()
assert sha(checksums)=='c5a63c1e73c856170057637c80057bc3a8ee48c7ad248e5b22893c4feaec0e00'
checksum_names=set()
for line in checksums.decode().splitlines():
    h,rel=line.split('  ',1);assert sha((R/rel).read_bytes())==h,rel;checksum_names.add(rel)
assert checksum_names==actual-{'SHA256SUMS'}
for rel in sorted(actual):
    p=R/rel;b=p.read_bytes()
    assert not p.is_symlink()
    if rel in listed:assert len(b)==listed[rel]['bytes'] and sha(b)==listed[rel]['sha256'],rel
    assert not re.search(rb'wxid_[a-z0-9]{8,}|/Library/Containers/com\.tencent',b),rel
    put(D/rel,b)
    assert (D/rel).read_bytes()==b
raw=(D/'original-evidence.raw.json').read_bytes()
canonical=(D/'original-evidence.canonical.json').read_bytes()
orig=json.loads(raw)
assert sha(raw)=='ef774a20ac6b3ee13ce872b99cca80a7731058f2fd8bd4d2b3168486f859eaa7'
assert sha(canonical)=='9b6b102bd38e87dbd3864dafa89c57d9026c22d40e5cc60df4cc834cc455275b'
assert json.loads(canonical)==orig
assert json.dumps(orig,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()==canonical
append=(D/'actual-own-ledger-append.raw.jsonl').read_bytes()
assert sha(append)=='a3d92da48b9edcde420449357f1fdca68793e7a94e1a68a366952794c033e8a3'
record=json.loads(append)
assert record['evidence']==orig and len(orig)==13 and record['to_state']=='VERIFIED'
assert record['worker_id']=='/root/source_reader_62f8c4'
ledger=Path('runs/substantive_advances.jsonl').read_bytes()
base=subprocess.check_output(['git','show','HEAD:runs/substantive_advances.jsonl'])
assert ledger==base+append
st=adv._replay_advances([json.loads(x) for x in ledger.splitlines()])
own=st['ASTIS-SA-20261110-GaussianComplexityFixedSpectrumModeGap']
assert own['state']=='VERIFIED' and own['owner_id']=='huanjian_gc_20261110_fixed_spectrum_mode_gap'
keys=json.loads((D/'original-evidence-contract-binding.json').read_bytes())['original_top_level_keys']
assert set(keys)==set(orig)
rec={'scope':'Exact lossless carry of ONLY original verifier-selected public-safe outputs. All original13 evidence keys/values/raw/canonical/append retained. No new sourceV call or original evidence rewrite.','original_verifier':'/root/source_reader_62f8c4','original_evidence_keys':keys,'original_raw_sha256':sha(raw),'original_canonical_sha256':sha(canonical),'actual_append_sha256':sha(append),'original_execution_freeze_sha256':sha(fr.read_bytes()),'public_file_manifest_sha256':sha(mf.read_bytes()),'copied_files':len(actual),'foreign_private_snapshots_copied':False,'normal_API_calls_by_root':0,'own_state':'VERIFIED','frontier_closeout':'Separate original-verifier closeout requested; not implied by this carry.','future_release':'Original source62 actor ONLY; preserve every original value and add only post_integration.','native_scope':'Actual fresh native producer/Test/kernel and source check at a289; source code equals886/348. No fresh native348 or first-carry commit run.','global_site_public_purification_whole_Goal_acceptance':False}
put(E/'actual-original-sourceV-byte-carry.json',dump(rec))
print(json.dumps({'own_state':own['state'],'original_key_count':len(orig),'public_files_copied':len(actual),'append_sha256':sha(append),'global_integration':False}))
