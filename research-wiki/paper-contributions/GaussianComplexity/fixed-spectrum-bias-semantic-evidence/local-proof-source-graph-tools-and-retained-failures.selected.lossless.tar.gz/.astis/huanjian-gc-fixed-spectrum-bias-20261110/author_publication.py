from pathlib import Path
import hashlib, json, sys
sys.dont_write_bytecode = True
sys.path.insert(0, 'tools')
import astis_publication as pub
import astis_semantic_roundtrip as rt

W = Path('.astis/huanjian-gc-fixed-spectrum-bias-20261110')
E = Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-bias-semantic-evidence')
S = json.loads((W/'statement-seal-v1.json').read_text())
sha = lambda x: hashlib.sha256(x.encode() if isinstance(x, str) else x).hexdigest()
def put(p, value):
    p = Path(p)
    assert not p.exists(), p
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n')

name = S['producer']['name']
prod = Path(S['producer']['planned_file'])
test = Path(S['actual_private_consumer']['planned_file'])
sig = S['producer']['signature']
csig = S['actual_private_consumer']['signature']
for f, st, start in [(prod, sig, 'theorem actual_diagonal_gaussian_exponential_bias'),
                     (test, csig, 'private theorem actual_gaussian_zero_threshold_probability_le')]:
    assert f.read_text().split(start, 1)[1].split(' := by', 1)[0] == st.split(start, 1)[1].rstrip()

short = 'For the actual inverse-precision Gaussian, the absolute cosine-quadratic mean divided by the squared-norm mean has the following exponential bounds.'
formula = r'(1-e^{-4})e^{-3n/\sqrt\kappa}\le\frac{|b|}{M}\le e^{-2n/\sqrt\kappa},\qquad M>0,\quad(-1)^n b>0.'
assumptions = [
    r'Fix \(d\in\mathbb N\), \(d\ge2\), \(\kappa\in\mathbb R\), \(\kappa\ge2\), and \(n\in\mathbb N\) with \(1\le n<d\). Assume the source gap \(d-n\ge\sqrt\kappa\). This subtraction is in the reals after casting the natural indices.',
    r'Set \(\theta_i=(i-\tfrac12)\pi/d\), \(\lambda_i=(\kappa+1)/2+((\kappa-1)/2)\cos\theta_i\), and \(\Lambda=\operatorname{diag}(\lambda_i)\). Lean uses \(i\in\mathrm{Fin}\,d\) and \((i.\mathrm{val}+1/2)\pi/d\).',
    r'Let \(U\sim N(0,\Lambda^{-1})\) in standard real Euclidean space, \(Q(x)=\sum_i\cos(n\theta_i)x_i^2\), \(M=\mathbb E\|U\|^2\), and \(b=\mathbb E Q(U)\). The Gaussian matrix argument is covariance; \(\Lambda\) is precision.',
    r'The source gap is an explicit hypothesis. The exact means, positivity, logarithmic integral estimates, denominator guards and exponential comparisons are internal proof dependencies, with no extra moment, logarithm, variance or law certificate hypothesis.'
]
steps = [
    {'title':'Normalize the actual Gaussian means',
     'text':'Use the existing exact-mean theorem for the same literal Gaussian. The positive ratio r is less than one. Factoring the signed cosine mean gives its positivity and the normalized formula; all denominator and scale factors are positive on the stated domain.',
     'formula':r'\begin{gathered}r=\frac{\sqrt\kappa-1}{\sqrt\kappa+1}\in(0,1),\quad M=\frac d{\sqrt\kappa}\frac{1-r^{2d}}{1+r^{2d}},\\(-1)^n b=\frac d{\sqrt\kappa}\frac{r^n-r^{2d-n}}{1+r^{2d}},\qquad\frac{|b|}{M}=r^n\frac{1-r^{2(d-n)}}{1-r^{2d}}.\end{gathered}',
     'detail':'hclosed materially calls the canonical ExactMeans declaration. hm/hb/hfactor/hMpos/hbpos/habs/hratio establish actual normalization, rather than assuming an abstract mean or a ratio formula.'},
    {'title':'Establish the two logarithmic integral identities',
     'text':'For 0≤a<1, the denominator stays positive throughout the integration interval. Apply the fundamental theorem of calculus to the canonical Mathlib logarithmic remainder derivative, first with zero terms and then with one term. These two instances give exactly the source integral and its quadratic remainder.',
     'formula':r'\log\frac{1+a}{1-a}=2\int_0^a\frac{dt}{1-t^2}=2a+2\int_0^a\frac{t^2}{1-t^2}\,dt.',
     'detail':'log_remainder_integral uses Real.hasDerivAt_half_log_one_add_div_one_sub_sub_sum_range and intervalIntegral.integral_eq_sub_of_hasDerivAt. log_integral_identities uses its n=0 and n=1 cases. Continuity and nonzero denominators are proved on the actual interval.'},
    {'title':'Bound the logarithm using the source remainder estimate',
     'text':'Compare the first integrand with one. For the remainder, use 1/(1−t²)≤1/(1−a²), and integrate t² exactly. With a=1/√κ, the condition κ≥2 gives a²≤1/2, so a³/[3(1−a²)]≤a/3. Substitute the exact reciprocal-ratio identity.',
     'formula':r'\begin{gathered}2a\le\log\frac{1+a}{1-a}\le2a+\frac{2a^3}{3(1-a^2)},\\a=\kappa^{-1/2},\qquad\frac2{\sqrt\kappa}\le\log(1/r)\le\frac8{3\sqrt\kappa}\le\frac3{\sqrt\kappa}.\end{gathered}',
     'detail':'log_integral_bounds proves the interval comparisons and integral of t². spectral_ratio_log_bounds proves square-root positivity, a<1, a²≤1/2, the remainder bound and 1/r=(1+a)/(1−a). The later power provider makes the final 8/3≤3 relaxation.'},
    {'title':'Convert the logarithmic bounds into power bounds',
     'text':'For every natural k, write r^k as exp(−k log(1/r)). Multiplication by k preserves the logarithmic inequalities; negation then reverses them. Apply the increasing exponential function. The case k=0 is included.',
     'formula':r'e^{-3k/\sqrt\kappa}\le r^k=\exp\!\bigl(-k\log(1/r)\bigr)\le e^{-2k/\sqrt\kappa}\qquad(k\in\mathbb N).',
     'detail':'spectral_ratio_power_bounds uses the exact positive-r logarithm identity and Real.exp_nat_mul. The sign reversal is explicit through neg_le_neg after multiplying by the nonnegative natural cast.'},
    {'title':'Control the finite-grid normalization factor',
     'text':'Because 0<r<1 and 2(d−n)≤2d, the normalization factor is at most one and at least 1−r^(2(d−n)). Apply the power bound to 2(d−n), then the explicit source gap, to bound this tail by e^(−4). Multiply by the n-th power bounds to obtain both conclusions.',
     'formula':r'\begin{gathered}1-r^{2(d-n)}\le\frac{1-r^{2(d-n)}}{1-r^{2d}}\le1,\\r^{2(d-n)}\le e^{-4(d-n)/\sqrt\kappa}\le e^{-4},\\(1-e^{-4})e^{-3n/\sqrt\kappa}\le\frac{|b|}{M}\le e^{-2n/\sqrt\kappa}.\end{gathered}',
     'detail':'hpoworder/hfraclower/hfracupper provide the finite-factor bounds. htail uses Nat.cast_sub under n<d and the explicit real hgap, so no truncated-subtraction assumption or hidden gap premise is introduced.'},
    {'title':'Use the lower bias in an actual zero-threshold probability bound',
     'text':'For the private numerical application put X=(−1)^nQ(U), B=EX>0 and C=1−e^(−4)>0. The new lower bias gives B≥C e^(−3n/√κ)M. Existing square integrability and Var(Q)≤2M give Var(X)≤2M. The event X≤0 lies inside |X−EX|≥B, so Chebyshev and the positive lower bound on B give the displayed actual-law probability estimate.',
     'formula':r'\Pr\{(-1)^nQ(U)\le0\}\le\frac{\operatorname{Var}(X)}{B^2}\le\frac{2M}{C^2e^{-6n/\sqrt\kappa}M^2}=\frac{2e^{6n/\sqrt\kappa}}{(1-e^{-4})^2M}.',
     'detail':'The complete exact private Test is folded here. hQ/hV supply actual L2 and variance; hmean/hsub/hm/hprob perform centered-event inclusion and finite ENNReal-to-real conversion. hLB/hbsq/hExpSq perform the genuine new-bias use. This PRIVATE NON-ANCHOR zero-threshold event does not identify the source nonzero concrete τ, rotated detector, query mode, source .9 event or full Ex26. The factor2 and exponent6 are local Chebyshev algebra, not quoted source constants.'}
]
ranges = [(prod,'  classical\n  let θ','  have hpoworder'),
          (prod,'private theorem log_remainder_integral','private theorem log_integral_bounds'),
          (prod,'private theorem log_integral_bounds','private theorem spectral_ratio_power_bounds'),
          (prod,'private theorem spectral_ratio_power_bounds','theorem actual_diagonal_gaussian_exponential_bias'),
          (prod,'  have hpoworder','\nend AutoSamplingTheory'),
          (test,None,None)]
code_records = []
for step,(f,a,b) in zip(steps,ranges):
    raw=f.read_text(); start=raw.index(a) if a else 0; end=raw.index(b,start) if b else len(raw)
    code=raw[start:end].rstrip()+'\n'; assert code in raw
    step['lean']=code
    code_records.append({'file':str(f),'line':raw[:start].count('\n')+1,'code_sha256':sha(code),'exact_contiguous_source':True})
parents = ['AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumExactMeans.actual_diagonal_gaussian_exact_means']
varname = 'AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumVariances.actual_diagonal_gaussian_quadratic_variances'
boundary = 'Only the actual diagonal-Gaussian exponential normalized-bias source subtree with its explicit source gap, actual M/signed-mean positivity, and a private NON-ANCHOR zero-threshold numerical probability application are claimed. The private event is not the source concrete nonzero threshold or rotated algorithmic event. Full Lemma4.5 assembly, concrete threshold/mode/query/large-d guards, orthogonal target-law transport, Krylov/concentration/adaptive seed/history/output laws, exact matvec/TV precision/deterministic worst-case query caps/explicit expected-cost adapters and both main lower bounds remain open. Independent sourceV, serialized latest-main integration, immutable public evidence/source links, actual desktop/mobile/source-index/graph acceptance, publication, purification and Exposition Seal are separate.'
source = {'url':'https://arxiv.org/html/2610.20492v1#S4.Ex17','edition':'arXiv2610.20492v1; raw HTML SHA2566bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915','anchor':'S4.Thmtheorem5.p2.1/Ex17; A3.SS3.p9-p11/Ex150-159; standing S4 fixed-spectrum family. The private numerical zero-threshold application has no source Anchor.','wording_status':'faithful paraphrase','attribution':'Huanjian Zhou and Taiji Suzuki, On Complexity of Gaussian Sampling.','scope':'Actual normalized cosine-quadratic mean under the diagonal inverse-precision Gaussian, with the explicit source gap.'}
unit = {'kind':'theorem','reading_layout':'progressive','declaration':name,'title':'Actual Gaussian exponential normalized bias','reader_note':'The two exponential bounds come first. The full domain, formula proof and exact Lean are folded beside the statement.','statement':short,'formula':formula,'assumptions':assumptions,'notation':[{'symbol':r'\(U,Q,M,b,r\)','text':'The actual Gaussian, cosine quadratic, two actual integral means and the positive spectral ratio.','formula':r'U\sim N(0,\Lambda^{-1}),\quad Q(x)=\sum_i\cos(n\theta_i)x_i^2,\quad M=\mathbb E\|U\|^2,\quad b=\mathbb E Q(U),\quad r=\frac{\sqrt\kappa-1}{\sqrt\kappa+1}.'}],'steps':steps,'astis_dependencies':parents,'mathlib_dependencies':['Real.hasDerivAt_half_log_one_add_div_one_sub_sub_sum_range','intervalIntegral.integral_eq_sub_of_hasDerivAt','ContinuousOn.intervalIntegrable','intervalIntegral.integral_mono_on','integral_pow','Real.exp_nat_mul','Real.exp_log','Real.log_inv','Real.exp_le_exp','pow_le_pow_of_le_one'],'lean_statement':'Exactly the sealed d≥2,κ≥2,Nat1≤n<d and real gap sqrtκ≤d−n; literal Gaussian covariance Λ inverse and literal integrals M,b. Positivity and both exponential estimates are conclusions.','lean_proof':'Five private scalar integral/logarithm/power providers; actual canonical closed means and normalization; finite-grid tail using the explicit source gap. The private probability consumer additionally calls the canonical actual variance theorem and Mathlib meas_ge_le_variance_div_sq.','boundary':boundary,'sources':[{**source,'label':'Zhou–Suzuki Lemma4.5 normalized-bias estimate and Appendix C.3 proof'},{'path':str(test),'line':test.read_text().split('private theorem')[0].count('\n')+1,'label':'Complete private actual-law zero-threshold probability application','scope':'Implementation context only; no additional public source Anchor or Registry node.'}],'tests':['lake build Tests.GaussianComplexityFixedSpectrumBias']}
put('website/content/declaration_lessons/huanjian-fixed-spectrum-bias.json',{'schema_version':1,'units':[unit]})
aid='ASTIS-RT-20261110-HuanjianFixedSpectrumBias'
binding={'declaration':name,'cell':'ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-bias','role':'proof-edge','supports':['actual-mean-positivity','exponential-normalized-bias'],'boundary':boundary,'audit_id':aid,'assumption_deltas':[
    {'source':'d≥2,κ≥2 and integer1≤n<d in the fixed cosine family; the estimate assumes d−n≥sqrtκ.','lean':'Exactly d:Nat,hd:2≤d,κ:Real,hκ:2≤κ,n:Nat,hn:1≤n,hnd:n<d and hgap:sqrtκ≤(d:Real)−(n:Real).','classification':'same','reason':'The gap remains explicit; no moment, logarithm, variance, oracle or law premise is added.'},
    {'source':'The means are those of the actual centered Gaussian with covariance Λ inverse.','lean':'Literal multivariateGaussian0 Λ inverse, the standard Euclidean squared norm and actual cosine-coordinate quadratic, with real Bochner integrals.','classification':'same','reason':'Canonical exact means establish the finite actual integrals; positive scale and denominators are proved internally.'},
    {'source':'The logarithmic identity, integral remainder, power bounds and finite-factor bounds are steps in Appendix C.3.','lean':'Five private scalar providers prove the actual interval integrals, source8/(3sqrtκ) estimate and exponential conversion before the source-gap tail estimate.','classification':'source-implicit','reason':'Proof ingredients are internal edges, with canonical Mathlib derivative/FTC reuse; they are not public binders.'},
    {'source':'The displayed source estimate bounds the absolute mean divided by M.','lean':'The same constants1−exp(−4),3,2 and additionally actual M>0 and signed mean>0.','classification':'same','reason':'The positivity conclusions are established from the same closed means and justify the exact normalized expression; they add no assumptions.'},
    {'source':'Ex26 uses Chebyshev for a concrete nonzero-threshold detector after further source-specific estimates.','lean':'A separate PRIVATE NON-ANCHOR local numerical application bounds the actual zero-threshold signed-Q event by2exp(6n/sqrtκ)/((1−exp(−4))²M).','classification':'generalization','reason':'This is a local specialization of the probability mechanism, not source Ex26 or a claim that concrete τ=0. It materially uses the new lower bias and existing Q L2/VarQ≤2M. Original τ/query/mode/large-d, rotation, .9 and oracle/TV/cost conclusions remain outside the result.'}
]}
text=' '.join([short,formula,*assumptions])
item={'id':'huanjian-fixed-spectrum-bias','library':'samplewiki','chapter':'gaussian-sampling-complexity','chapter_path':'example-cases/samplewiki/companions/gaussian-sampling-complexity.html','title':unit['title'],'source':source,'statement':text,'formulae':[{'label':'Actual Gaussian exponential normalized bias','tex':formula}],'assumptions':assumptions,'obligations':[{'id':'actual-mean-positivity','label':'Actual norm mean and signed cosine-quadratic mean are strictly positive.'},{'id':'exponential-normalized-bias','label':'Both exact exponential normalized-bias bounds under the source gap.'}],'bindings':[binding]}
put('website/content/publications/huanjian-fixed-spectrum-bias.json',{'schema_version':1,'items':[item]})
head,body=sig.split(' :\n',1)
statement='∀'+head.removeprefix('theorem actual_diagonal_gaussian_exponential_bias')+',\n'+body
context=[
    'Fin d is the usual finite type with values zero through d minus one; sums run over these coordinates. EuclideanSpace Real (Fin d) has the standard Euclidean norm, and WithLp.ofLp exposes coordinates. Matrix.diagonal is the usual diagonal matrix.',
    'ProbabilityTheory.multivariateGaussian m S is the image of the standard Gaussian by x↦m+toEuclideanCLM(CFC.sqrt S)x. The matrix S is covariance on the positive semidefinite domain; the standard totalized square root is zero outside that domain.',
    'Real and matrix inverses are standard totalized inverses. The displayed integrals are real Bochner integrals with the standard default value zero outside integrability. All finite sums, natural powers, real casts, square root, cosine, exponential, pi and absolute value have their standard meanings.',
    'Subtraction between explicitly real-cast natural numbers is subtraction in the real numbers. Natural subtraction in powers, when present, is truncated natural subtraction.'
]
audit={'id':aid,'state':'draft','source':{'source_id':'arxiv2610.20492v1-actual-gaussian-exponential-bias','url':source['url'],'anchor':source['anchor'],'original_text':text,'text_sha256':sha(text),'source_snapshot_sha256':S['source']['raw']['sha256']},'lean':{'declaration':name,'file':str(prod),'statement':statement,'statement_sha256':sha(statement),'formalizer':'huanjian_gc_20261110_fixed_spectrum_bias','compiled':True,'decoder_context':context},'reconstruction':{},'semantic_slots':{},'deltas':[],'verdict':'pending','source_review':{'state':'pending'},'repairs':[]}
pub.inputs.cache_clear();pub.load.cache_clear()
audit['publication_binding_sha256']=pub.binding_digest(item,binding)
audit['publication_context']=pub.review_context(item,binding)
put('research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-bias.json',audit)
pub.check_advance([name],reviewed=False)
packet=rt.decoder_packet(audit)
D=Path('.astis/semantic-neutral-20261110/b7e604')
put(D/'input.json',packet);put(E/'decoder-input.json',packet)
record={'producer_raw_sha256':sha(prod.read_bytes()),'Test_raw_sha256':sha(test.read_bytes()),'producer_signature_sha256':S['producer']['signature_sha256'],'private_consumer_signature_sha256':S['actual_private_consumer']['signature_sha256'],'actual_public_ASTIS_producer_parents':parents,'actual_public_ASTIS_private_consumer_parents':[name,varname],'publication_binding_sha256':audit['publication_binding_sha256'],'anonymous_statement_sha256':sha(statement),'anonymous_packet_canonical_sha256':packet['packet_sha256'],'neutral_input':str(D/'input.json'),'neutral_input_raw_sha256':sha((D/'input.json').read_bytes()),'exact_step_code_records':code_records,'source_review':'pending','decoder':'pending','sourceV_or_integration_or_Goal_complete':False}
put(E/'publication-draft-record.json',record)
print(json.dumps(record))
