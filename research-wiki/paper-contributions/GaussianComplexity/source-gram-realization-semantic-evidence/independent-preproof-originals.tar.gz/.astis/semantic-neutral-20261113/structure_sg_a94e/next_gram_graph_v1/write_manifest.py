from pathlib import Path
import datetime,hashlib,json
OUT=Path(__file__).resolve().parent
def H(p):return hashlib.sha256(p.read_bytes()).hexdigest()
g=OUT/'SOURCE-GRAPH.v3.json';c=OUT/'SOURCE-COVERAGE.v3.json';p=json.loads((OUT/'INTERNAL-PORTS.v2.json').read_text())
assert p['source_graph_sha256']==H(g) and p['source_coverage_sha256']==H(c)
files={f.name:H(f) for f in OUT.iterdir() if f.is_file() and f.name not in ['FINAL-MANIFEST.v1.json','final-manifest.stdout','final-manifest.stderr','final-manifest.receipt.json']}
d={'version':'unclaimed-Gram-source-extraction-v1','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'seal_sha256':'7b2f71cf9e89a41da4f66b2b3908222c875cd2fec2f8b2ca6533fe61b3bb3ce9',
 'producer_signature_sha256':'0c2de4cd20931d19055e83abbde9acb2b93d65c4cd252df0148377254982a580',
 'consumer_signature_sha256':'5fd6eb29c42885dff8e5341b01cfbcd7d755cb2a5bd02d20c02bc383ec03b662',
 'current_packet':['SOURCE-GRAPH.v3.json','SOURCE-COVERAGE.v3.json','BINDER-DEFINITION-AUDIT.v1.json','INTERNAL-PORTS.v2.json','REPORT.md'],
 'files':files,'closure':'Every regular file present in this new subdirectory before this final command output/receipt; this manifest and its own runner outputs are excluded to avoid self-reference. Exact original source and all commands/failures/body-free exposures are included.',
 'status':'PROPOSED INDEPENDENT SOURCE GRAPH; distinct TC raw-source challenge pending. No proof, source/normalV verdict, SAU/frontier/ledger or theorem-completeness claim.',
 'preservation':'All writes confined to next_gram_graph_v1; prior R11 and next-source-boundary closed artifacts remain untouched.'}
(OUT/'FINAL-MANIFEST.v1.json').write_text(json.dumps(d,indent=2)+'\n')
print(json.dumps({'manifest_sha256':H(OUT/'FINAL-MANIFEST.v1.json'),'current_files':{n:files[n] for n in d['current_packet']},'closed_files':len(files),'review_status':d['status']},indent=2))
