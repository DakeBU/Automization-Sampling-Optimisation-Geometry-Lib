# Bias exact statement/binder/definition judgment v1

**ACCEPT_STATEMENT_BINDER_DEFINITION_SCOPE_ONLY** for strict projection SHA-256 `b245ddf40403f7aca7d2f0be6de9953cf1fb2bda57e840d9ee6bf6156aac8511`. No statement-level HOLD was found. This is not source-graph admission, proof/API authorization, compilation, material-use verification, source V or Goal credit. Stop before extractor inputs.

This independent judgment is frozen before opening the optional new `preseal-exposure-disclosure.json`. Its sole new statement input is the exact 9437-byte strict projection, binding parent seal SHA-256 `45e323a4f42c0061a6de06c791041cd5b9907e662e7b17753062745e43128760`; the parent seal itself was not opened. Own raw phase1 freeze `d22141491691edbf8eb31dc8ebad3a463cc72b4a2772bb225dd13deb61e68f66` and all seven phase1 checksum members were rechecked unchanged.

## Public source statement and each input

The public theorem has eight inputs, with the paired mode inequalities counted separately rather than trusting the projection's grouped rows:

| Input | Independent classification | Source meaning |
| --- | --- | --- |
| d:Nat | TYPING | Finite dimension carrier. |
| hd:2≤d | STANDING | Audited fixed-family dimension range at §4.1. |
| κ:Real | TYPING | Real condition parameter. |
| hκ:2≤κ | SOURCE | Explicit Lemma4.5 regime, also compatible with the hard-family standing range. |
| n:Nat | TYPING | Representation of the source's positive integer mode. |
| hn:1≤n | SOURCE | Original lower mode range. |
| hnd:n<d | SOURCE | Original upper mode range. |
| hgap:√κ≤(d:Real)−(n:Real) | SOURCE | Exact conditional normalized-bias separation guard. |

No proof estimate, scalar-log theorem, integrability, covariance/inverse/PSD, exact mean, sign, denominator positivity, variance or probability certificate is an input. No EXCESS public binder was independently found. The producer's positivity conclusions need no extra source assumption. Although those consequences and the exponential upper bound hold on a broader intermediate range, restricting the combined conclusion by the source's explicit two-sided guard is faithful to the displayed conditional statement.

The source integer 1≤n<d is completely represented by the retained natural modes; no odd/query-mode assumption is silently added. hgap uses subtraction of real casts, hence has no natural-subtraction truncation. Its equality boundary is included, exactly as in the source. No δ, q, ε, sufficiently-large-d or κ≤d^(1−δ) premise has been imported into this general source bias statement.

The conclusions match C.3 p9–p11 and Lemma4.5: positive actual M, strictly positive signed actual mean, and the two bounds on |b|/M with **exact** factor 1−exp(−4) and exponents −3n/√κ and −2n/√κ. The lower-bias remainder bound is where hgap is needed. The predicate is a ratio of actual expectations, not an expectation of a samplewise ratio. Parity is retained in (−1)^n*b; b itself is not assumed positive for odd n.

## Literal definitions and totalized branches

All meaning-carrying project-owned bodies in the signature are literal lets. The zero-based Fin d midpoint `(i.val+1/2)*π/d` agrees with source index i_source=i.val+1. The eigenvalue and diagonal Λ formulas have the right coefficients and precision interpretation. μ is the actual centered Gaussian with covariance Λ⁻¹, not Λ. Q is the real coordinate-square cosine quadratic. M and b are actual real Bochner integrals under the same μ; neither is assigned its desired closed formula, bound or sign by definition.

The projection supplies no new project-owned characterized/default definition. Standard Gaussian/Euclidean-space semantics were encountered in earlier authorized roles and are disclosed as prior knowledge; no current Mathlib body or API was reopened and no claim of a fresh standard-library byte audit is made. The present audit compares the literal signature to the source's mathematical objects, not to an unseen future implementation.

Source κ≥2/d≥2 and internally derived positive eigenvalues must establish correct inverse/square-root/covariance semantics. The actual existing mean/integrability facts must be supplied internally on this same law. Positivity outputs prevent a proof from satisfying the stated ratio/sign conclusion merely through nonintegrable-integral or zero-denominator defaults; they do not replace the actual-law/integrability obligations. Likewise 1−exp(−4)>0 is an internal fact, not a supplied numerical hypothesis.

The private event is the actual signed-Q sublevel set `{x:(−1)^n Q(x)≤0}`. It is not an arbitrary event variable or callback. Gaussian probability/finiteness, event measurability, actual Q L2 and finite centered variance must justify the real-probability reading of `.toReal`; `toReal(∞)=0` supplies no permitted shortcut. No pointwise ratio by ||x||² is used, and no x≠0 premise is required.

## Private non-Anchor numerical consumer

The private theorem has exactly the same eight domain inputs and no additional assumed numeric premise. Its public-source class labels record inherited domain correspondence only; explicit `is_source_anchor:false`, `Registry_node:false` and the separate non-Anchor audit prevent independent source credit. The zero threshold is a literal choice in a new private numerical event, not a logical binder claiming concrete τ_dq=0 and not a source-wide assumption or a sixth Source Anchor bin.

Its mathematical conclusion is correct as a local actual-law application of the source Chebyshev mechanism. The tail factor 2 and exponent 6 are consistent with actual VarQ≤2M and squaring the new lower exponential bias. They are local numerical constants, not a quotation of the source's nonzero-τ factor 32. No Mβ² threshold is needed to state this upper bound; it is allowed to be larger than one.

This is a substantive consumer relation: an actual probability of a defined measurable event is bounded by explicit d/κ/n/M data, and the promised route materially needs the new lower bias plus the existing actual Q L2/variance bound and signed-mean/M positivity. It is not the producer's formula copied into a wrapper and it has no free law, moment, independence or certificate input. Actual use in the future proof remains to be inspected after a proof exists; this statement judgment does not certify that use.

The upper-bias output and the norm-square variance bound are not necessary outputs for this particular private numerical application. That fact should remain distinct from any eventual Lean dependency on a bundled producer. This consumer does not require or assert independence of Q and norm-square, nor a nonzero-τ contrast estimate.

The raw source fixes n=2q+1 and τ=τ_dq when applying its full test. The current private event under diagonal U is explicitly different from S_A(Y)'s shifted/rotated test. It does not assert actual Y-to-U transport, concrete query/large-d guards, positive nonzero-τ contrast mean, original .9 target probability, algorithmic .99 event, TV separation, oracle equivalence, cost or main lower bound. Those boundaries are explicit and mathematically necessary. No public premise or source-wide zero-threshold promotion has occurred.

## Identity, exposure and pending work

Both supplied signature digests were independently rehashed:

- Producer: 992 bytes, SHA-256 `dee7b4c788460d866735409b620e4050544735dec2a20181b5fd4adaaec53dc4`.
- Private consumer: 926 bytes, SHA-256 `1e4264e970a6405c42a8ea4bd7cf26580b00adc2b7306166179bc8fed4531a78`.

Prior C7/grid/C8/means/Variances roles, earlier strict definitions/signatures/source graphs and process-disclosure roles remain disclosed in raw phase1. The parent announced a new process disclosure about its prior-source/parent/informal-statement-design exposure; it has not been opened for this mathematical judgment. No pristine-order or unfamiliarity claim is made, and no other actor's judgment was read for this decision.

The exact extractor graph, exhaustive target dispositions, scope/conditional selectors, opaque canonical-substrate boundaries, and complete producer/private root closures have **not** been seen. They require the separately authorized later phase2b challenge. No Lean proof, API retrieval, implementation, Mathlib, lesson, audit, normal transition, build, source V, shared/site/ledger mutation or Goal completion was performed. This freezes the exact statement judgment only and stops before graph inputs.
