# Independent raw cognition: actual diagonal Gaussian means

Frozen before opening the new Gaussian-moments seal, standard-definition file or new extractor graph. This is source understanding and challenge criteria, not a proof or admission verdict.

The fixed 951991-byte `2610.20492v1.html` has SHA-256 `6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915`. Fresh raw reading covered `S4.SS1.p1.1`, `S4.E11`, all of `S4.Thmtheorem5`, `A3.SS3.p4.1`, `A3.Ex140`, `A3.SS3.p4.2`, `A3.SS3.p6.1` and `A3.Ex144`. An earlier source-only locator was reused to display these exact raw regions.

Exposure is disclosed: this actor previously reviewed C7, grid alias source topology and conceptual mirrors. The assignment itself names covariance/precision and integration/default-value risks. No fresh-zero-exposure claim is made. No new Gaussian-moments candidate, implementation/API, extractor graph/private rationale, source V, ledger, build or browser has been opened for this packet.

## Source objects and mathematical content

For integer d≥2 and real κ≥2, source indices i=1,…,d have θᵢ=(i−1/2)π/d and λᵢ=(κ+1)/2+((κ−1)/2)cosθᵢ, with Λ=diag(λᵢ). Fin d must shift source i to i.val+1, hence angle (i.val+1/2)π/d. The λᵢ satisfy positivity (indeed λᵢ≥1) as a derived scalar consequence; this is not an extra source premise.

The law is **centered U∼N(0,Λ⁻¹)**. Λ is precision, so the covariance is its inverse. Since Λ is diagonal and invertible, coordinate covariance is δᵢⱼ/λᵢ, and the coordinate variance/second moment is 1/λᵢ. A standard-normal diagonal scaling would need 1/√λᵢ, not 1/λᵢ; the latter gives variance 1/λᵢ² and is a different law. A standard multivariate-Gaussian definition taking covariance must receive Λ⁻¹, not Λ or Λ^(-1/2).

The source defines M=E‖U‖² and μₙ=E[UᵀDₙU], with Dₙ=diag(cos(nθᵢ)) and integer 1≤n<d. These are actual Gaussian expectations, not definitions of deterministic inverse-spectrum sums. Their concrete Euclidean formulas are ‖u‖²=Σᵢuᵢ² and uᵀDₙu=Σᵢcos(nθᵢ)uᵢ². A representation using the Euclidean inner product with the diagonal action is faithful only with that exact carrier/coordinate meaning.

`A3.SS3.p4.1` invokes E[Uᵢ²]=1/λᵢ, and `A3.Ex140` concludes M=Σᵢ1/λᵢ and μₙ=Σᵢcos(nθᵢ)/λᵢ. This short sentence suppresses substantive Gaussian-law, second-moment and integration facts. It is the current new bridge, not already discharged by deterministic C7/grid results.

## Source inputs versus produced ingredients

Source/standing inputs are d≥2, κ≥2, the literal grid/precision matrix, the actual centered Gaussian law, and 1≤n<d where the source's μₙ calculation is used. A faithful formal law representation may use an actual measure or an exact distributional-law hypothesis. Carrier, coordinates, finite dimensionality and standard Borel/Euclidean conventions are typing information. The explicit law itself must not be replaced by a second-moment certificate merely sufficient for this proof.

All of the following must be derived internally: positivity/nonzero eigenvalues; diagonal inverse/covariance identification; Gaussian centered-coordinate second moments; square integrability/integrability; measurability; norm/diagonal-quadratic coordinate identities; finite integral/sum and scalar-multiplication exchange; any bound on the quadratic form; and, in the private consumer, convergence and the weighted alias expansion. A theorem-shaped structure or Prop alias bundling those conclusions is an EXCESS premise, even if another theorem can later produce it.

Gaussian independence follows from a diagonal centered Gaussian law but is not needed as an extra premise for linearity of these finite expected sums. No fourth moment, variance calculation or independent-coordinate-square covariance estimate is necessary for this means-only delta.

## Meaning-carrying definition and default-value challenges

The forthcoming standard definition must identify the actual covariance convention, ambient Euclidean carrier, chosen zero vector and literal diagonal inverse. A library formula that accepts degenerate/nonnegative covariances or totalizes other parameter values must still agree with the source law throughout the admitted κ/d domain. Any project-owned off-source fallback/conditional choice must be audited rather than silently called a Gaussian definition.

The exact squared norm and diagonal quadratic function must be displayed by their actual bodies. Calling a deterministic spectral sum “the Gaussian mean” by definition is not the bridge claimed by the source.

Real Bochner integrals are totalized: without integrability they can return zero. Therefore the actual integrability of both functions must be a produced fact, whether an explicit joint output or a proved dependency visibly used. An infinite-sum or integral equality alone must not exploit a default-zero semantics, especially when signed μₙ can vanish. Measurability and integrability may not become unexplained public assumptions.

## Producer/consumer source topology

The means route has conjunctive ingredients: standing literal spectrum/law → correct positive diagonal covariance and coordinate second moments; norm/quadratic coordinate identities plus integrability → finite integral/sum exchange; these together → both actual Gaussian-to-spectral-sum equalities. The p4.1 scalar variance fact is a source-suppressed mathematical dependency, not a hypothesis of the result. No alternate sufficient source OR proof is given.

The actual Gaussian cosine-series precursor must then materially combine this new expectation bridge with the existing deterministic C7/grid-alias series (or an explicitly equivalent source route). It must not leave the Gaussian expectation as a cosmetic unused definition while proving only the deterministic finite sum. Its n range stays 1≤n<d; the coefficient/exponent and Int frequencies must retain the established j+1, (j+1)−n and (j+1)+n meanings and the d/√κ normalization.

The author first takes actual Gaussian expectations to finite inverse-eigenvalue sums in Ex140, then interchanges finite grid and series sums in p4.2 and uses zero low-frequency/product-to-sum in p6.1/Ex144. This is not an infinite-series/Gaussian-integral interchange. A new Tonelli/Fubini/domination assumption would distort that source route unless explicitly justified as internal background. C7 uniform convergence is not an extra premise required for finite grid exchange.

The actual U law is already specified in diagonal coordinates; no Haar basis, random O, algorithm seed or transport from a rotated sample Y is a current producer premise. Such a rotated-Gaussian adapter remains separate source work.

## Coverage and remaining boundary

NODE: standing d/κ and literal θ/λ/Λ; the U law and norm/diagonal-quadratic meanings in Lemma 4.5; p4.1's coordinate moment; Ex140's two actual Gaussian means; p4.2 finite series exchange; p6.1 zero mode/product-to-sum and Ex144 as the Gaussian consumer's source use.

SOURCE_GAP/background obligations must expose the Gaussian covariance/coordinate variance convention, diagonal inverse, integrability, Euclidean coordinate identities and finite integration linearity, with use sites and actual conditional discharge. Existing deterministic C7/alias results are separate producer boundaries; source edges are not automatically compiler-backed calls.

EXCLUDED from the current delta: the closed C8 formulas, tail class partition/regrouping and geometric resummation; both variances/fourth moments; normalized bias and d−n≥√κ; Gaussian rotation to Y; every TV/oracle/precision/cap/expected-cost/main-bound claim. The full Lemma 4.5 statement was read for definitions/range only and may not enter the admitted means closure as an already-proved parent.
