"""One authorized normal R10 verification transition. Never retry this script/API."""
from pathlib import Path
import contextlib,datetime,hashlib,io,json,os,stat,subprocess,sys,traceback
sys.dont_write_bytecode=True
sys.path.insert(0,"tools")
import astis_advance as advance
ROOT=Path.cwd()
OUT=Path(__file__).resolve().parent
ADV="ASTIS-SA-20261113-GaussianComplexitySourceMatrixRadius"
VERIFIER="radius_src_73c1_independent_resumed_verifier"
HELD="9e5ee5685d4f05fcfba9bcf700af25b8ec61386b"
CELL=ROOT/"research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-source-matrix-radius.json"
LEDGER=ROOT/"runs/substantive_advances.jsonl"
sha=lambda b:hashlib.sha256(b).hexdigest()
receipt_dir=OUT/"receipts";receipt_dir.mkdir(exist_ok=True)
guard_cmd=[sys.executable,str(OUT/"independent_preservation_guard.py"),"precall"]
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
guard=subprocess.run(guard_cmd,cwd=ROOT,text=True,capture_output=True)
(receipt_dir/"precall-full-guard.stdout").write_text(guard.stdout)
(receipt_dir/"precall-full-guard.stderr").write_text(guard.stderr)
guard_receipt={"argv":guard_cmd,"cwd":str(ROOT),"started":started,"ended":datetime.datetime.now(datetime.timezone.utc).isoformat(),"exit":guard.returncode,"stdout_sha256":sha(guard.stdout.encode()),"stderr_sha256":sha(guard.stderr.encode())}
(receipt_dir/"precall-full-guard.json").write_text(json.dumps(guard_receipt,indent=2)+"\n")
assert guard.returncode==0,"Final precall guard execution failed; no API called"
g=json.loads((OUT/"private_guard.precall.json").read_bytes())
assert g["result"]=="PASS","Final precall private guard failed; no API called"
audit=json.loads((OUT/"final-before-API-audit.json").read_bytes())
assert subprocess.check_output(["git","rev-parse","HEAD"],text=True).strip()==HELD
assert sha(CELL.read_bytes())==audit["ownC_before_sha256"]
ledger_before=LEDGER.read_bytes()
assert sha(ledger_before)==g["bounded_hashes"]["current_ledger_sha256"]
index_bytes=subprocess.check_output(["git","ls-files","--stage","-z"])
assert sha(index_bytes)==g["bounded_hashes"]["current_full_index_sha256"]=="489731b57b16e2f4961df393f8c833e54b58994f76229596b85a5db986917465"
index_path=Path(subprocess.check_output(["git","rev-parse","--git-path","index"],text=True).strip())
assert sha(index_path.read_bytes())==audit["raw_index_sha256"]
evidence_bytes=(OUT/"VERIFIED-evidence.full.json").read_bytes()
assert sha(evidence_bytes)==audit["VERIFIED_full_evidence_sha256"]
evidence=json.loads(evidence_bytes)
assert evidence["verifier_id"]==VERIFIER and evidence["verified_commit"]==HELD
original_path=ROOT/"research-wiki/paper-contributions/GaussianComplexity/source-matrix-radius-semantic-evidence/actual-PROVED_LOCAL-evidence.full.json"
original_bytes=original_path.read_bytes()
assert sha(original_bytes)=="e2ca572ea630b2a9df348206e21fb92f36c43954cbb6c83a02e8e8144bdd34c7"
original=json.loads(original_bytes)
assert len(original)==25 and all(evidence[k]==v for k,v in original.items())
assert isinstance(evidence["independent_verification"],str) and evidence["independent_verification"].strip()
prospective_bytes=(OUT/"ownC.prospective.json").read_bytes()
assert sha(prospective_bytes)==audit["ownC_prospective_sha256"]
records=[json.loads(x) for x in ledger_before.splitlines()]
own=[r for r in records if r.get("advance_id")==ADV]
assert sum(r.get("to_state")=="VERIFIED" for r in own)==0
states=advance._replay_advances(records)
assert states[ADV]["state"]=="PROVED_LOCAL" and states[ADV].get("owner_id")!=VERIFIER
sentinel=OUT/"normal-V-once.sentinel.json"
fd=os.open(sentinel,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
with os.fdopen(fd,"w") as f:
 json.dump({"advance_id":ADV,"verifier_id":VERIFIER,"held_commit":HELD,"created":datetime.datetime.now(datetime.timezone.utc).isoformat(),"maximum_normal_API_attempts":1,"ledger_before_sha256":sha(ledger_before),"ledger_before_bytes":len(ledger_before),"full_private_guard_exported":False},f,indent=2);f.write("\n");f.flush();os.fsync(f.fileno())
api_stdout=io.StringIO()
api_stderr=io.StringIO()
api_start=datetime.datetime.now(datetime.timezone.utc).isoformat()
api_error=None
try:
 with contextlib.redirect_stdout(api_stdout),contextlib.redirect_stderr(api_stderr):
  advance.transition_advance(ADV,"VERIFIED",worker_id=VERIFIER,modes=["independent-verification","source-review","native-proof-reuse"],evidence=evidence)
except BaseException:
 api_error=traceback.format_exc()
(receipt_dir/"normal-API.stdout").write_text(api_stdout.getvalue())
(receipt_dir/"normal-API.stderr").write_text(api_stderr.getvalue()+(api_error or ""))
api_receipt={"API":"tools.astis_advance.transition_advance","normal_API_attempts":1,"advance_id":ADV,"to_state":"VERIFIED","worker_id":VERIFIER,"started":api_start,"ended":datetime.datetime.now(datetime.timezone.utc).isoformat(),"held_HEAD":HELD,"evidence_file":"VERIFIED-evidence.full.json","evidence_sha256":sha(evidence_bytes),"returned_successfully":api_error is None,"stdout_sha256":sha(api_stdout.getvalue().encode()),"stderr_sha256":sha((api_stderr.getvalue()+(api_error or "")).encode()),"retry_forbidden":True}
(receipt_dir/"normal-API.json").write_text(json.dumps(api_receipt,indent=2)+"\n")
if api_error:
 print(json.dumps({"result":"NORMAL_API_FAILED_NO_RETRY","receipt":str(receipt_dir/"normal-API.json")}))
 raise SystemExit(1)
ledger_after=LEDGER.read_bytes()
assert ledger_after[:len(ledger_before)]==ledger_before,"Unexpected ledger prefix change after API; do not replay"
appended=ledger_after[len(ledger_before):]
assert len(appended.splitlines())==1 and appended.endswith(b"\n")
actual=json.loads(appended)
assert actual["advance_id"]==ADV and actual["event"]=="transition" and actual["from_state"]=="PROVED_LOCAL" and actual["to_state"]=="VERIFIED" and actual["worker_id"]==VERIFIER
assert actual["evidence"]==evidence and all(actual["evidence"][k]==v for k,v in original.items())
(OUT/"actual-normal-V-append.jsonl").write_bytes(appended)
assert sha(CELL.read_bytes())==audit["ownC_before_sha256"]
mode=stat.S_IMODE(CELL.stat().st_mode)
tmp=CELL.with_name(CELL.name+".radius-src-73c1-tmp")
with tmp.open("xb") as f:f.write(prospective_bytes);f.flush();os.fsync(f.fileno())
os.chmod(tmp,mode)
os.replace(tmp,CELL)
(OUT/"ownC.after.json").write_bytes(CELL.read_bytes())
assert CELL.read_bytes()==prospective_bytes
result={"result":"ONE_NORMAL_API_RETURNED_AND_OWN_C_UPDATED; POSTCHECKS_REQUIRED","advance_id":ADV,"verifier_id":VERIFIER,"checked_held_commit":HELD,"normal_API_attempts":1,"own_PL_count":1,"own_V_count":1,"actual_append_sha256":sha(appended),"actual_append_bytes":len(appended),"ledger_before_sha256":sha(ledger_before),"ledger_after_sha256":sha(ledger_after),"all25_original_PL_values_inline_unchanged":True,"ownC_before_sha256":audit["ownC_before_sha256"],"ownC_after_sha256":sha(CELL.read_bytes()),"ownC_independent_verification_is_nonempty_STRING":True,"full_structured_evidence_separate":True,"HEAD_unchanged":subprocess.check_output(["git","rev-parse","HEAD"],text=True).strip()==HELD,"index_stage_sha256":sha(subprocess.check_output(["git","ls-files","--stage","-z"])),"raw_index_sha256":sha(index_path.read_bytes()),"postwrite_full_schema":"REQUIRED_NOT_YET_RUN","postwrite_full_preservation":"REQUIRED_NOT_YET_RUN","staged_or_committed":False,"private_full_guards_exported":False,"stage_boundary":"Local mathematical verification only; original readerFAIL preserved, conditionalPASS UNAPPLIED, original global stabilization owner unchanged; integration/publication/purification/Goal HOLD."}
(OUT/"actual-API-returned.receipt.json").write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps(result,indent=2))
