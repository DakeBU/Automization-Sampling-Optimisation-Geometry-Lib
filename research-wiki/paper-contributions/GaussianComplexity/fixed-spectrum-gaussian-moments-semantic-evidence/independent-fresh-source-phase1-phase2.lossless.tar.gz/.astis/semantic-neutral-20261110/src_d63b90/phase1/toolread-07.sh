cat docs/theorem-publication-protocol.md
