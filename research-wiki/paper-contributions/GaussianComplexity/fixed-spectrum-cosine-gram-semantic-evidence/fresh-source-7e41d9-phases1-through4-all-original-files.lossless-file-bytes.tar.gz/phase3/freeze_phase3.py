#!/opt/anaconda3/bin/python
import datetime,hashlib,json,pathlib,stat
BASE=pathlib.Path(__file__).resolve().parent
assert not (BASE/'manifest.json').exists(),'Refuse to refreeze phase3.'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
judgment=json.loads((BASE/'mathematical_judgment.json').read_text())
assert judgment['candidate_commit']=='72e5d1405284f729f4eb600c5ae5dd556365b7e2'
assert judgment['verdict']=='equivalent-after-elaboration' and judgment['repairs']==[]
commands=[json.loads(x) for x in (BASE/'actual_commands.jsonl').read_text().splitlines()]
for row in commands:
    assert row['returncode']==0
    for stream in ['stdout','stderr']:
        path=BASE/row[stream+'_file']
        assert len(path.read_bytes())==row[stream+'_bytes'] and sha(path)==row[stream+'_sha256']
inventories=[]
for name in ['input_inventory.json','dependency_inventory.json','deeper_dependency_inventory.json']:
    inventories+=json.loads((BASE/name).read_text())
for row in inventories:
    path=BASE/row['snapshot']
    assert len(path.read_bytes())==row['bytes'] and sha(path)==row['sha256']
phase_manifests={'phase1':'80d4eefdb9d3d733e60d4ea52d00207c5ca62e03c1964b94e404525c2e472079',
                 'phase2':'8a5ff1011acb383f99d2411649240d48023186cac33c24323d9e95402361625e'}
for name,digest in phase_manifests.items():
    phase=BASE.parent/name
    assert sha(phase/'manifest.json')==digest
    for row in json.loads((phase/'manifest.json').read_text())['payloads']:
        path=phase/row['path']
        assert sha(path)==row['sha256'] and stat.S_IMODE(path.stat().st_mode)==0o444
    assert stat.S_IMODE(phase.stat().st_mode)==0o555
entries=[]
for path in sorted(BASE.rglob('*')):
    if path.is_file():
        path.chmod(0o444)
        entries.append({'path':str(path.relative_to(BASE)),'bytes':len(path.read_bytes()),
                        'sha256':sha(path),'mode':'0444'})
manifest={'phase':'phase3-independent-mathematical-code-source-module-exposition-before-SourceV',
          'candidate_commit':judgment['candidate_commit'],'payloads':entries,
          'excluded_self_and_receipt':['manifest.json','freeze_receipt.json'],
          'unchanged_prior_manifest_hashes':phase_manifests}
mp=BASE/'manifest.json';mp.write_text(json.dumps(manifest,indent=2)+'\n');mp.chmod(0o444)
receipt={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
         'phase':manifest['phase'],'candidate_commit':judgment['candidate_commit'],
         'manifest_sha256':sha(mp),
         'mathematical_judgment_sha256':sha(BASE/'mathematical_judgment.json'),
         'narrative_judgment_sha256':sha(BASE/'mathematical_source_module_exposition_judgment.md'),
         'payload_count':len(entries),'captured_child_command_count':len(commands),
         'captured_child_returncodes':[r['returncode'] for r in commands],
         'separately_recorded_wrapper_launch_failure_count':1,
         'source_map_locator_slices_verified':57,'raw_source_anchor_locators_verified':26,
         'exact_folded_code_strings_verified':6,'prior_phases_verified_unchanged':True,
         'verdict':judgment['verdict'],'repairs':[],'compiler_run_by_this_role':False,
         'SourceV_or_ledger_accessed':False,
         'freeze_execution_record_outside_phase':'../phase3_freeze_execution.json',
         'manifest_excludes_itself_and_receipt':True}
rp=BASE/'freeze_receipt.json';rp.write_text(json.dumps(receipt,indent=2)+'\n');rp.chmod(0o444)
for path in sorted(BASE.rglob('*'),reverse=True):
    if path.is_dir():path.chmod(0o555)
BASE.chmod(0o555)
assert all(stat.S_IMODE(p.stat().st_mode)==0o444 for p in BASE.rglob('*') if p.is_file())
assert all(stat.S_IMODE(p.stat().st_mode)==0o555 for p in BASE.rglob('*') if p.is_dir())
assert stat.S_IMODE(BASE.stat().st_mode)==0o555
print(json.dumps({'manifest_sha256':sha(mp),'mathematical_judgment_sha256':sha(BASE/'mathematical_judgment.json'),
                  'narrative_judgment_sha256':sha(BASE/'mathematical_source_module_exposition_judgment.md'),
                  'receipt_sha256':sha(rp),'phase_directory':str(BASE),'phase_directory_mode_observed':'0555',
                  'all_phase_file_modes_observed':'0444','all_phase_subdirectory_modes_observed':'0555',
                  'payload_count':len(entries),'captured_child_command_count':len(commands),
                  'prior_phases_verified_unchanged':True,'verdict':judgment['verdict']},indent=2))
