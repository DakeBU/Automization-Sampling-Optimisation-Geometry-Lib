import json, re
from verify import *

raw=(D/'raw/independent_kernel.stdout').read_text()
exact=(D/'raw/all_owned_exact_closed_prop_types.stdout').read_text()
owned=re.findall(r'OWNED_RECURSIVE_AXIOMS_REACHABLE_CLOSED ([^:\n]+): \[([^\]]*)\]',raw)
assert len(owned)==26 and 'OWNED_MODULE_PROVENANCE_INVENTORY_COUNT 26' in raw
assert len(re.findall(r'OWNED_EXACT_CLOSED_PROP_TYPE ',exact))==26
assert 'ALL_OWNED_EXACT_CLOSED_PROP_TYPES 26' in exact
inventory=[{'name':n,'recursive_axioms':[s.strip() for s in a.split(',') if s.strip()],
   'closed_prop':True,'reachable_from_actual_roots':True,
   'role':'source-authored public producer' if n.endswith('.actual_cosine_frame_gram') else 'source-authored private actual consumer' if n.endswith('.actual_gaussian_gram_means') else 'compiler-generated certificate; no mathematical node credit'} for n,a in owned]
assert all(set(x['recursive_axioms'])<={'propext','Classical.choice','Quot.sound'} for x in inventory)
js('independent-owned-kernel-summary.json',{'candidate':C,'owned_count':26,'authored_roots':2,'generated_certificates':24,
   'ownership':'Lean environment module provenance, not a namespace-only heuristic',
   'all_types':'All 26 are kernel-checked theorems with closed Prop types; exact pretty-printed actual types are preserved in raw/all_owned_exact_closed_prop_types.stdout',
   'exact_root_type_check':'IndependentExpectedProducer/Consumer made from sealed literal signatures, then kernel addDecl checks actual root constants at these closed Prop types',
   'inventory':inventory,'native_pass':True,'kernel_stdout_sha256':sha(raw.encode()),'owned_exact_types_stdout_sha256':sha(exact.encode())})
m=json.loads((D/'inputs'/E/'source-to-lean-map-v1.json').read_text())
roots={}
for n in [x['name'] for x in inventory if 'source-authored' in x['role']]:
    match=re.search(r'ROOT_DIRECT_USED_CONSTANTS '+re.escape(n)+r': \[([^\]]*)\]',raw)
    assert match
    roots[n]={x.strip() for x in match[1].split(',')}
observations=[]
for row in m['canonical_rows']:
    claims=row.get('observed_directly_in_owned_root_body',[])
    for n in claims:
        observations.append({'constant':row['compiled_constant'],'root':n,
           'actual_direct_constant_present':row['compiled_constant'] in roots[n]})
assert all(x['actual_direct_constant_present'] for x in observations)
js('canonical-row-direct-observations.json',{'canonical_rows':len(m['canonical_rows']),'claimed_direct_observations':len(observations),
   'all_claimed_direct_observations_confirmed':True,'observations':observations,
   'boundary':'This verifies compiler constant observations and locators. Source-fidelity judgments remain the separate reviewer’s responsibility.'})
same=run('canonical_parent_unchanged_from_candidate_parent',['git','diff','--exit-code',PARENT,C,'--',G])
tree=run('parent_exact_bounded_paths',['git','ls-tree',PARENT,'--',P,T,G])
audit=json.loads((D/'inputs/research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-cosine-gram.json').read_text())
print(json.dumps({'native_pass':True,'owned_count':26,'generated_certificates':24,'locator_pass_count':57,
    'canonical_direct_observations_confirmed':len(observations),'audit_state':audit.get('state'),
    'audit_source_review_state':audit.get('source_review',{}).get('state'),
    'reader_delivery':'HOLD'},indent=2))
js('bounded-audit-state.json',{'candidate':C,'state':audit.get('state'),'source_review_state':audit.get('source_review',{}).get('state'),
    'scope':'Read-only draft-state observation; no source slots modified and no source fidelity verdict issued.'})
