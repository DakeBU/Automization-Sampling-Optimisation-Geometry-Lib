# Typed overlay on the frozen raw source graph

This is a phase-2 interpretation of the exact selective type/definition packet,
not a target implementation, API proposal, source-review verdict, or proof
certificate. The raw-source artifacts remain unchanged. The input packet has
9976 bytes and SHA-256
`71806be7febb91c6ea9a847ce022065cec7eebf6b224503663fcbb7921bc5353`.
Its Statement Seal reference is
`f9476ec7454a0927d3a1068226ad635b464d9b5d631f4992421d4b3b39b70ec3`.
Only that packet and this role's own frozen raw artifacts were read in phase 2.
The root's `formalizer_API_pristine=false` is retained. No blanket pristine
claim is made.

## Exact probability experiment and row meaning

Both signatures use the same literal let-bindings. For natural `d,q` satisfying
`2*q+1<d`, the column space `D` is the real Euclidean space with `d` coordinates,
the row space `E` is the real Euclidean space with `q+1` coordinates, and an
outcome `omega` in `Omega` is a tuple of `q+1` columns in `D`. The measure `mu`
is the finite product of the standard Gaussian measures on these column
spaces. The packet's product-measure definition excerpts and probability
instance prints explain the intended canonical probability realization; they
are meaning context, not certificates for the new row-law theorem.

The source states its result for independent standard columns without naming
an underlying probability space. The exact signatures select the canonical
product realization of that same column experiment. They do not state a
theorem quantified over every possible ambient probability space or over a
coupling with an algorithm output. This canonical realization carries the
source column law. A later application to another realization must use its
actual column-law identification; an unrelated ambient probability must not
be silently substituted.

For a fixed `i : Fin d`, `row i omega` has coordinate `a` equal to `omega a i`.
`WithLp.toLp 2` wraps this coordinate function in the Euclidean row carrier; it
does not change any coordinate or rescale the row. The source indices are
`i.val+1` and `a.val+1`. The canonical row target is `stdGaussian E`, not a
Gaussian measure on the function carrier `Omega`. The Euclidean squared norm
is the sum of the `q+1` squared row coordinates, exactly as in source `R_i`.

The producer concludes `MeasurePreserving (row i) mu (stdGaussian E)` for every
`i`. Its expanded meaning has **two outputs**:

1. `row i` is measurable;
2. pushing the original product measure `mu` through `row i` gives precisely
   `stdGaussian E`.

Neither field is an assumption or an obligation delegated to the consumer.
The exact signature does not assert joint independence of different rows.
The stronger printed source assertion remains recorded as excluded source
context. A family of these marginal-law outputs cannot itself certify a
joint-row product law.

The packet expands `stdGaussian` as a finite product of scalar standard
Gaussians mapped through an orthonormal-basis expansion. The source law
`N(0,I)` is its standard Euclidean meaning. The fixed physical-coordinate
marginal law must still be established; it is not obtained merely by calling
the basis-expansion definition a coordinate projection. No new local default,
fallback, quotient, representative, or chosen witness is introduced by the
sealed signatures.

## Consumer and source coverage

The private consumer uses the very same `D,E,Omega,mu,row`. It casts `q+1` to
the real number `r`, sets `L=2*r+3*Real.log(1000*d)`, and takes the set of
outcomes for which every original row has squared norm at most `L`.
All row tests use the **same outcome**. Its conclusion
`ENNReal.ofReal (999/1000 : Real) <= mu good` is precisely the source p10
printed probability lower bound `0.999` for `T`. The positive rational is
embedded in extended nonnegative reals; the positive-part behavior of
`ofReal` does not change this threshold.

Only `d,q` and the source range condition are inputs to each signature. The
measure, canonical row law, cutoff and event are literal definitions. The
producer theorem, row measurability, marginal distribution, integrability,
exponential moment, strict tails and union estimate are not added as public
premises. They belong to dependency edges discharged internally.

The typed coverage file preserves every disposition of the raw bounded
inventory, including all 145 paragraph/formula/display atoms. C.2 p1 provides
the row construction and the marginal component of its stronger printed law.
P10 provides the radius, cutoff, moment identity, Markov tail, numerical
inequality, event and printed good probability. The complementary any-bad
estimate and finite-union derivation remain explicitly labeled source-supported
inference. P11's shifted-tail and bias estimates remain excluded neighboring
obligations. C.5/C.6 and all centered/matrix/concentration/main/oracle/cost
claims remain outside this target.

## Actual remaining mathematical edges

The sealed statements and definition prints alone discharge none of these new
mathematical edges:

1. Establish the canonical column-product realization properties relevant to
   each fixed row, then prove both the row's measurability and its exact
   standard-Gaussian pushforward. This is the raw coordinate/law bridge.
2. Obtain the canonical row exponential integrability and exact moment
   `integral exp(norm(z)^2/3) = 3^(r/2)` at row dimension `q+1`. The selective
   packet mentions an existing canonical result but supplies no exact theorem
   statement for it. Its precise domain, coefficient and integrability
   applicability therefore remain dependency obligations in this overlay.
3. Use the producer's measure-preserving output to transport the relevant
   integrability and moment to each row of the original product experiment.
4. Obtain the source strict tail
   `mu {norm(row i omega)^2 > 2*r+3*x} <= exp(-x)` for `x>=0`, using the
   nonnegative exponential, the exact moment and the source numerical
   inequality `(log 3)/2<2/3`. No equality of a strict and non-strict tail is
   needed.
5. Substitute `x=log(1000*d)`, justified by `d>=2` from the source range, to
   bound each original bad event by `1/(1000*d)`. Apply the finite union bound
   over exactly `d` rows. Joint-row independence is not required.
6. Identify `good` with the complement of the strict any-bad event, use the
   product probability normalization, and express the resulting lower bound
   as `ENNReal.ofReal (999/1000)`. Each event measurability condition must be
   supplied; the producer's measurability output is relevant here.

These are mathematical dependency obligations, not proposed formal APIs or a
proof-search route selected for the root. The printed Gaussian integral remains
an unexpanded source ingredient. The other bookkeeping expands the printed
p10 consequence rather than changing it.

For `q=0`, `E` has one coordinate, `Omega` has one standard `d`-Gaussian
column, `r=1`, and the source range forces `d>=2`. The cutoff is
`2+3*log(1000*d)`. The sealed signatures retain this endpoint. There is no
extra requirement `q>0`, `r>=2`, or `tau_(d,q)<=1/2`, and no row-independence
premise. Natural-number carriers and the range condition prevent an off-source
zero-dimensional column experiment here.

The accompanying typed graph, atom coverage and binder/definition audit are
frozen with their exact input hashes. They provide reviewable interpretation
and explicit residual gaps, without granting implementation, process, source
acceptance or proof-completion status.
