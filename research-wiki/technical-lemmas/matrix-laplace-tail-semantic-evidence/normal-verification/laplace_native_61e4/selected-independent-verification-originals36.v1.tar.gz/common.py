"""Exact two-window guards. Full maps, Git output and ledger snapshots are private only."""
import ast
from concurrent.futures import ThreadPoolExecutor
import copy
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

sys.dont_write_bytecode=True
OWN=Path(__file__).resolve().parent
ROLE=OWN.parent
REPO=OWN.parents[3]
PRIVATE=OWN/'local-private'
E=REPO/'research-wiki/technical-lemmas/matrix-laplace-tail-semantic-evidence'
W=REPO/'.astis/huanjian-gc-matrix-laplace-20261114'
CARRIER='999b89925e95e463e0269148010f794dc27bb26a'
MATH='1d1103af694b9663a72b0d610004ed85c7c6b527'
ADV='ASTIS-SA-20261114-MatrixLaplaceTail'
VERIFIER='laplace_native_61e4_independent_verifier'
PROVER='huanjian_20261114_matrix_laplace_tail'
P='AutoSamplingTheory.TechnicalLemmas.Probability.MatrixLaplaceTail.max_eigenvalue_tail_le_iInf_trace_exp'
ADVPATH='runs/substantive_advances.jsonl'
DISCPATH='runs/substantive_discoveries.jsonl'
CELL='research-wiki/frontier-cells/ASTIS-SHARED-REAL-MATRIX-LAPLACE-TAIL.json'
AUTH_SHA='1e6ce55cd7750320a9e114459a9eb9a55ddcfa7ac75833e0fcdbb79679ceb390'
PL_SHA='da479ae33a80a68835bbb517390a8532760df06054872873c767a5cb65cb198a'
READER_SHA='f9587b8bb5d30642913ed8a072d366d10deb1f65325f5192d2974a99425063d5'

def sha(b):return hashlib.sha256(b).hexdigest()
def file_sha(p):
    p=Path(p);h=hashlib.sha256()
    with p.open('rb') as f:
        while block:=f.read(1024*1024):h.update(block)
    return h.hexdigest()
def read(p):return json.loads(Path(p).read_text())
def write(p,d):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
def canonical_sha(v):return sha(json.dumps(v,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode())
def ident(p):
    p=Path(p);return {'file':str(p.relative_to(REPO)),'bytes':p.stat().st_size,'sha256':file_sha(p)}

def git(label,*args):
    directory=PRIVATE/'git-readonly';directory.mkdir(parents=True,exist_ok=True)
    out=directory/(label+'.stdout.raw');err=directory/(label+'.stderr.raw')
    argv=['/usr/bin/git','--no-optional-locks',*args];env={'PATH':'/usr/bin:/bin','LC_ALL':'C','GIT_OPTIONAL_LOCKS':'0'}
    start=time.monotonic()
    with out.open('xb') as o,err.open('xb') as e:r=subprocess.run(argv,cwd=REPO,env=env,stdout=o,stderr=e,stdin=subprocess.DEVNULL)
    write(directory/(label+'.receipt.json'),{'local_private_do_not_publish':True,'argv':argv,'cwd':str(REPO),'exit_code':r.returncode,'elapsed_seconds':time.monotonic()-start,'stdout_sha256':file_sha(out),'stderr_sha256':file_sha(err)})
    assert r.returncode==0,(label,r.returncode)
    return out.read_bytes()

def replay(advraw,discraw):
    assert advraw.endswith(b'\n') and discraw.endswith(b'\n'),'No recovery/truncation is permitted'
    ar=[json.loads(x) for x in advraw.splitlines() if x.strip()];dr=[json.loads(x) for x in discraw.splitlines() if x.strip()]
    assert all(isinstance(x,dict) for x in ar+dr)
    tree=ast.parse((REPO/'tools/astis_advance.py').read_text())
    nodes=[x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name in ['_replay_advances','_replay_discoveries']]
    ns={'Any':object,'Iterable':list,'NO_PROGRESS_FREEZE_AT':3}
    exec(compile(ast.Module(body=nodes,type_ignores=[]),'<pure read-only replay>','exec'),ns)
    return ar,dr,ns['_replay_advances'](copy.deepcopy(ar)),ns['_replay_discoveries'](copy.deepcopy(dr))

def snapshot(label):
    directory=PRIVATE/label;directory.mkdir(parents=True,exist_ok=False)
    head=git(label+'-HEAD','rev-parse','HEAD').decode().strip();assert head==CARRIER
    indexpath=Path(git(label+'-index-path','rev-parse','--git-path','index').decode().strip())
    if not indexpath.is_absolute():indexpath=REPO/indexpath
    index=indexpath.read_bytes();(directory/'index.exact').write_bytes(index)
    tracked=[x.decode() for x in git(label+'-tracked','ls-files','-z').split(b'\0') if x]
    def digest(relative):
        path=REPO/relative
        if path.is_symlink():return relative,{'kind':'symlink','sha256':sha(os.readlink(path).encode())}
        if not path.exists():return relative,{'kind':'missing'}
        before=path.stat();digest=file_sha(path);after=path.stat()
        assert before.st_size==after.st_size and before.st_mtime_ns==after.st_mtime_ns,relative
        return relative,{'kind':'file','bytes':after.st_size,'sha256':digest}
    with ThreadPoolExecutor(max_workers=8) as pool:trackedmap=dict(pool.map(digest,tracked))
    advraw=(REPO/ADVPATH).read_bytes();discraw=(REPO/DISCPATH).read_bytes()
    ar,dr,advances,discoveries=replay(advraw,discraw)
    frontiers={str(p.relative_to(REPO)):file_sha(p) for p in (REPO/'research-wiki/frontier-cells').rglob('*.json')}
    (directory/'advance-ledger.exact.jsonl').write_bytes(advraw);(directory/'discovery-ledger.exact.jsonl').write_bytes(discraw)
    state={'local_private_do_not_publish':True,'HEAD':head,'index_path':str(indexpath),'index_sha256':sha(index),'tracked':trackedmap,'frontiers':frontiers,'foreign_advances':{k:canonical_sha(v) for k,v in advances.items() if k!=ADV},'all_discoveries':{k:canonical_sha(v) for k,v in discoveries.items()},'advance_ledger_sha256':sha(advraw),'discovery_ledger_sha256':sha(discraw)}
    write(directory/'full-guards.private.json',state)
    return {'state':state,'advraw':advraw,'discraw':discraw,'records':ar,'advances':advances,'discoveries':discoveries,'indexbytes':index}

def postguards(before,after,allowed_files,frontier_exception=None):
    a=before['state'];b=after['state']
    assert a['HEAD']==b['HEAD']==CARRIER and before['indexbytes']==after['indexbytes']
    assert set(a['tracked'])==set(b['tracked'])
    changed={name for name in a['tracked'] if a['tracked'][name]!=b['tracked'][name]}
    assert changed==set(allowed_files),('Unexpected tracked byte changes',sorted(changed))
    assert a['foreign_advances']==b['foreign_advances'] and a['all_discoveries']==b['all_discoveries']
    assert before['discraw']==after['discraw']
    fa={k:v for k,v in a['frontiers'].items() if k!=frontier_exception};fb={k:v for k,v in b['frontiers'].items() if k!=frontier_exception}
    assert fa==fb
    return {'HEAD_unchanged':True,'index_exact_bytes_unchanged':True,'all_other_tracked_bytes_unchanged':True,'all_foreign_advance_and_discovery_states_unchanged':True,'whole_discovery_ledger_unchanged':True,'all_frontiers_unchanged':frontier_exception is None,'all_non_target_frontiers_unchanged':True,'tracked_files_checked':len(a['tracked']),'frontier_files_checked':len(a['frontiers']),'actual_changed_tracked_files':sorted(changed),'full_maps_private_only':True}

def check_refs(value,checked):
    if isinstance(value,dict):
        if isinstance(value.get('file'),str) and isinstance(value.get('sha256'),str):
            path=REPO/value['file'];assert path.is_file() and file_sha(path)==value['sha256'],value['file']
            if 'bytes' in value:assert path.stat().st_size==value['bytes'],value['file']
            checked.append(ident(path))
        for v in value.values():check_refs(v,checked)
    elif isinstance(value,list):
        for v in value:check_refs(v,checked)

def inputs():
    authpath=W/'ROOT-one-independent-V-authorization.v1.json';assert file_sha(authpath)==AUTH_SHA
    auth=read(authpath);assert auth['advance_id']==ADV and auth['verified_carrier']==CARRIER and auth['verifier_id']==VERIFIER and auth['prover_owner']==PROVER and auth['normal_API_calls_authorized']==1
    gatespath=REPO/auth['gate_summary'];assert file_sha(gatespath)==auth['gate_summary_sha256']=='19e02d046c69f8f64e4eb9c2489144d3f299df177cc2c40e029833f02754add4'
    gates=read(gatespath);assert gates['carrier']==CARRIER and gates['original_math_identity']==MATH
    assert {x['gate'] for x in gates['records']}=={'publication','contributor','semantic','private-semantic','frontier','whitespace'}
    verified_gates=[]
    originals=OWN/'input-originals';originals.mkdir(exist_ok=True)
    for row in gates['records']:
        rp=REPO/row['receipt'];assert file_sha(rp)==row['receipt_sha256']
        record=read(rp);assert row['actual_exit_code']==record['exit_code']==0 and row['checked_metadata_commit']==record['head_before']==record['head_after']==CARRIER
        log=Path(record['log']);assert file_sha(log)==record['log_sha256']
        for source in [rp,log]:
            dest=originals/source.name
            if dest.exists():assert dest.read_bytes()==source.read_bytes()
            else:dest.write_bytes(source.read_bytes())
        verified_gates.append({'gate':row['gate'],'checked_commit':CARRIER,'actual_exit_code':0,'actual_receipt':ident(rp),'actual_combined_log':ident(log),'command':record['command'],'own_exact_receipt_copy':ident(originals/rp.name),'own_exact_log_copy':ident(originals/log.name)})
    plpath=E/'PROVED_LOCAL-evidence.full.json';assert file_sha(plpath)==PL_SHA;pl=read(plpath);assert len(pl)==24
    assert pl['lean_declarations']==pl['publication_declarations']==[P] and pl['actual_math_commit']==MATH
    readerpath=E/'post-PL-current-reader-acceptance.v1.json';assert file_sha(readerpath)==READER_SHA==auth['current_reader_sha256']
    reader=read(readerpath);assert reader['status']=='ACCEPTED_BOUNDED_ISOLATED_READER_WITH_PRESERVED_PARENT_CLIP_CORRECTION' and reader['publication_binding_sha256']=='159708e68a0601d85a6081464aa654ea80b7b58cbf0fa41ac697a03fcd8e4346'
    assert reader['independent_corrective_review']['necessary_reader_residual']==0
    assert reader['actual_targeted_supplement']['actual_exit_code']==1 and reader['actual_targeted_supplement']['raw_false_checks']==2 and reader['optional_v3']['execution'] is False and reader['new_v4_browser_run'] is False
    checked=[];check_refs(pl,checked);check_refs(reader,checked)
    for row in pl['actual_source_bytes']:assert file_sha(REPO/row['path'])==row['sha256'] and (REPO/row['path']).stat().st_size==row['bytes']
    assert file_sha(REPO/'lean-toolchain')=='302cd63c54178885b89e669f33b38f12f4dd7ae7e5cac537b3203e3768d8fb2b'
    assert file_sha(REPO/'lake-manifest.json')=='b83ca83b9cf7caa85fa8b023c2ff9a3fb7a7cce7e1c332e810c348535ec49c37'
    nativepath=E/'native-originals/laplace_native_61e4/native-mathematics-report.v1.json';native=read(nativepath)
    assert nativepath.read_bytes()==(ROLE/'native-mathematics-report.v1.json').read_bytes()
    assert native['candidate_commit']==MATH and not native['sorryAx_or_unauthorized_axiom']
    publicpath=REPO/'research-wiki/semantic-roundtrip/audits/huanjian-matrix-laplace-tail.json';privatepath=E/'private-consumer-audit.source-reviewed.v4.json'
    public=read(publicpath);private=read(privatepath)
    assert public['state']==private['state']=='source-reviewed' and public['publication_binding_sha256']==private['publication_binding_sha256']==reader['publication_binding_sha256']
    assert file_sha(ROLE/'selected-originals.manifest.v1.json')=='dbd220b80c7c6a5db609c89eae3b0fbd3630fd652dc7de39074ad7f0e84186eb'
    assert file_sha(ROLE/'reader-runtime-v3/presentation-selected-originals.manifest.v1.json')=='3cea83cd0e61df11cba9ab36dca51f1f64c79b18df1238b836d8f9c05f301451'
    assert not (ROLE/'reader-parent-supplement-v3/process').exists() and not (ROLE/'reader-parent-supplement-v3/output').exists()
    for source,name in [(authpath,'ROOT-authorization.exact.json'),(gatespath,'preV-gates.exact.json'),(plpath,'PROVED_LOCAL-original24.exact.json'),(readerpath,'current-reader-acceptance.exact.json')]:
        dest=originals/name
        if dest.exists():assert dest.read_bytes()==source.read_bytes()
        else:dest.write_bytes(source.read_bytes())
    return {'auth':auth,'authpath':authpath,'gates':verified_gates,'pl':pl,'plpath':plpath,'reader':reader,'readerpath':readerpath,'checked_identities':checked,'nativepath':nativepath,'publicpath':publicpath,'privatepath':privatepath}
