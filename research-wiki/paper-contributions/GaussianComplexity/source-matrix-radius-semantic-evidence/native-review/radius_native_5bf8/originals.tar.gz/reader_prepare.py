from runner import *
import ast,re
COMMIT=sys.argv[1]
C=OUT/('reader/candidate-'+COMMIT[:7])
p,_=run('reader-tree',['git','ls-tree','-r','--name-only',COMMIT]);names=set(p.with_suffix('.stdout').read_text().splitlines())
def take(path):
    p,_=run('reader-exact-'+path.replace('/','__'),['git','show',COMMIT+':'+path])
    b=p.with_suffix('.stdout').read_bytes();dest=C/path;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b);return b
seen=set()
def pythonfile(path):
    if path in seen:return
    seen.add(path);b=take(path)
    for n in ast.walk(ast.parse(b.decode())):
        mods=[]
        if isinstance(n,ast.Import):mods=[x.name.split('.')[0] for x in n.names]
        elif isinstance(n,ast.ImportFrom) and n.module:mods=[n.module.split('.')[0]]
        for m in mods:
            for folder in ['website/scripts/','tools/']:
                p=folder+m+'.py'
                if p in names:pythonfile(p);break
for p in ['website/scripts/declaration_lessons.py','website/scripts/publication_reader.py','website/scripts/source_lineage.py']:pythonfile(p)
for kind in ['declaration_lessons','publications']:take(f'website/content/{kind}/huanjian-gaussian-source-matrix-radius.json')
settings=json.loads((OUT/'settings.json').read_text())
for m in settings['order']:take(m.replace('.','/')+'.lean')
assets=set()
def asset(path):
    if path in assets:return
    assets.add(path);b=take(path)
    if path.endswith('.css'):
        for url in re.findall(r'(?:@import\s+(?:url\()?|url\()\s*[\'\"]?([^\'\"\s);]+)',b.decode()):
            if url.startswith(('data:','http:','https:')):continue
            target=str(Path(path).parent/url.split('?')[0])
            if target in names:asset(target)
for n in ['site.css','information-architecture.css','proof-readers.css','source-lineage.css','site.js','math-reader.js']:asset('website/static/'+n)
for p in sorted(names):
    if p.startswith('website/static/vendor/mathjax@3.2.2/'):asset(p)
(OUT/('reader/input-inventory-'+COMMIT[:7]+'.json')).write_text(json.dumps({'commit':COMMIT,'python_modules':sorted(seen),'assets':sorted(assets),'audit_and_cell_maps':'empty and visibly unverified; bounded fixture'},indent=2)+'\n')
print(json.dumps({'python_modules':len(seen),'assets':len(assets),'candidate':COMMIT}))
