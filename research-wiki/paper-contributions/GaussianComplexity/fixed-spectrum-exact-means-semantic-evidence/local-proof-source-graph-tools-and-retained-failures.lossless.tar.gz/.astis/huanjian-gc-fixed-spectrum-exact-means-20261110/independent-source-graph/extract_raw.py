"""Bounded raw-source capture. Uses only stdlib HTMLParser; no proof files."""
from html.parser import HTMLParser
from pathlib import Path
import hashlib, json, re

ROOT = Path('/Users/zhouhuanjian/ASTIS-GC')
OUT = ROOT / '.astis/huanjian-gc-fixed-spectrum-exact-means-20261110/independent-source-graph'
SOURCE = ROOT / '.astis/huanjian-resume-20261103/2610.20492v1.html'
raw = SOURCE.read_text()
assert hashlib.sha256(SOURCE.read_bytes()).hexdigest() == '6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'

class N:
    def __init__(self, tag, attrs, parent, line):
        self.tag, self.attrs, self.parent, self.line = tag, dict(attrs), parent, line
        self.parts, self.children = [], []
    @property
    def id(self): return self.attrs.get('id')
    def text(self):
        if self.tag == 'math': return '$' + self.attrs.get('alttext', '') + '$'
        return re.sub(r'\s+', ' ', ''.join(x.text() if isinstance(x, N) else x for x in self.parts)).strip()
    def walk(self):
        yield self
        for x in self.children: yield from x.walk()

class P(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.root = N('root', [], None, 0)
        self.stack, self.ids = [self.root], {}
    def handle_starttag(self, tag, attrs):
        n = N(tag, attrs, self.stack[-1], self.getpos()[0])
        self.stack[-1].children.append(n); self.stack[-1].parts.append(n)
        if n.id: self.ids[n.id] = n
        if tag not in ('meta','link','img','br','hr','input','source','wbr','area','base','embed','param','col'): self.stack.append(n)
    def handle_endtag(self, tag):
        for i in range(len(self.stack)-1, 0, -1):
            if self.stack[i].tag == tag:
                self.stack[i].endline = self.getpos()[0]
                del self.stack[i:]
                return
    def handle_data(self, data): self.stack[-1].parts.append(data)

p=P(); p.feed(raw)
scopes=['S4.SS1.p1.1','S4.E11','S4.Thmtheorem5','A3.SS3']
lines=raw.splitlines(keepends=True)
inventory=[]
for scope in scopes:
    n=p.ids[scope]
    (OUT/'phase1'/f'{scope}.raw.html').write_text(''.join(lines[n.line-1:n.endline]))
    items=[]
    for q in n.walk():
        cls=q.attrs.get('class','')
        is_eq=q.tag in ('table','tbody') and q.id and ('ltx_equation' in cls or re.match(r'(S\d+\.E|A\d+\.Ex?)',q.id))
        is_theorem='ltx_theorem' in cls and q.tag=='div'
        is_para=q.tag=='p' and q.id
        is_cite=q.tag=='cite'
        if is_eq or is_theorem or is_para or is_cite:
            item={'source_scope':scope,'id':q.id or f'{scope}.cite.L{q.line}', 'tag':q.tag,'class':cls,'line_start':q.line,'line_end':getattr(q,'endline',q.line),'kind':'display' if is_eq else 'theorem' if is_theorem else 'paragraph' if is_para else 'citation','text':q.text(),'links':[a.attrs.get('href') for a in q.walk() if a.tag=='a']}
            inventory.append(item); items.append(item)
    (OUT/'phase1'/f'{scope}.readable.txt').write_text('\n\n'.join(f"[{x['id']}] ({x['tag']}, L{x['line_start']}-{x['line_end']})\n{x['text']}" for x in items)+'\n')
(OUT/'phase1'/'raw-inventory.json').write_text(json.dumps(inventory,indent=2,ensure_ascii=False)+'\n')
(OUT/'phase1'/'raw-source-manifest.json').write_text(json.dumps({'source':str(SOURCE.relative_to(ROOT)),'sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),'scopes':scopes,'inventory_count':len(inventory),'extractor':'stdlib HTMLParser; all paragraph and theorem/display/citation nodes including tbody IDs; nested theorem records retained as statement containers; paragraphs/displays are atomic coverage units','instructions':{f:hashlib.sha256((ROOT/f).read_bytes()).hexdigest() for f in ['AGENTS.md','docs/proof-digestion-protocol.md','docs/evidence-routed-memory-protocol.md']}},indent=2)+'\n')
print(json.dumps({'inventory_count':len(inventory),'scopes':scopes}))
