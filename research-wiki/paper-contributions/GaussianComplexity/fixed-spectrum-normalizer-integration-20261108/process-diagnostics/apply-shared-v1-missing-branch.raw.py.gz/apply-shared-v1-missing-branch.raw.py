from pathlib import Path
import json,hashlib,gzip,sys,datetime,subprocess
sys.path.insert(0,'tools')
import astis_advance as adv
import astis_publication as pub
sha=lambda raw:hashlib.sha256(raw).hexdigest()
def put(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
b=Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-normalizer-integration-20261108')
b.mkdir(exist_ok=True)
report=b/'independent-reader/proposal-v3/proposal-report.json'
freeze=b/'independent-reader/proposal-v3/freeze.json'
assert sha(report.read_bytes())=='6b86afe6caeaf8e1cc83fc782b1221c7b316edfa20f2439cd204d840da4bc87a'
assert sha(freeze.read_bytes())=='3b31e3d6e2dc762d0f8628766f1485e4d15bc7f87f5db73922e30a28a75960a8'
p=json.loads(report.read_bytes());assert p['shared_path_count']==6
assert subprocess.check_output(['git','rev-parse','HEAD']).decode().strip()=='cc9e72d2a140a577258ed3a9c2c782cb561f3709'
assert subprocess.check_output(['git','rev-parse','origin/main']).decode().strip()=='d9bcd4231df69061c5221f8d557ee179a945c1eb'
subprocess.run(['git','merge-base','--is-ancestor','origin/main','HEAD'],check=True)
ap=Path('research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-normalizer.json');audit_raw=ap.read_bytes()
assert sha(audit_raw)=='8fa833c84e0a39e2afef0a7c4236e8d624a1cab94ecfbaa6b47a820f4f2ca7d1'
assert subprocess.check_output(['git','show','HEAD:'+str(ap)])==audit_raw
audit=json.loads(audit_raw);assert audit['source_review']['reviewer']=='/root/norm_fresh_source_640251'
aid='ASTIS-SA-20261108-GaussianComplexityFixedSpectrumNormalizer'
owner='huanjian_gc_20261108_fixed_spectrum_normalizer_integration'
states=adv.current_advances();assert states[aid]['state']=='VERIFIED'
assert states[aid]['owner_id']=='huanjian_gc_20261108_fixed_spectrum_normalizer'
assert not [s for s in states.values() if s['state']=='STABILIZING']
decl=audit['lean']['declaration'];pub.check_advance([decl],reviewed=True)
lp=Path('runs/substantive_advances.jsonl');before=lp.read_bytes()
assert sha(before)=='2f891b0bdeb1d03432adbc327733c3f78b7bded735a0ed19bc396885f6623f08'
dp=Path('runs/substantive_discoveries.jsonl');discovery=dp.read_bytes()
cp=Path('research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-normalizer.json')
foreign={str(q):q.read_bytes() for q in cp.parent.glob('*.json') if q!=cp}
readme=Path('research-wiki/paper-contributions/GaussianComplexity/README.md');readme_raw=readme.read_bytes()
payloads=[]
for row in p['shared_paths']:
 q=Path(row['path']);assert q.exists()==row['before_exists'];assert not q.exists() or sha(q.read_bytes())==row['before_sha256']
 archive=Path(row['planned_after_archive']['path']).read_bytes();assert sha(archive)==row['planned_after_archive']['gzip_sha256']
 raw=gzip.decompress(archive);assert sha(raw)==row['planned_after_sha256'] and len(raw)==row['planned_after_archive']['raw_bytes']
 payloads.append((q,raw))
for path,digest in {**p['source_Test_lesson_publication_pins'],**p['unchanged_models']}.items():assert sha(Path(path).read_bytes())==digest
authorization={'authorized_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'authorized_by':'/root',
 'operation':'Sole normal STAB and exact independently reviewed six-path v3 application only',
 'integration_owner':owner,'proof_owner_to_preserve':states[aid]['owner_id'],
 'source_verifier_to_preserve':audit['source_review']['reviewer'],
 'source_V_first_carrying_commit':'cc9e72d2a140a577258ed3a9c2c782cb561f3709',
 'accepted_audit_sha256':sha(audit_raw),'proposal_report_sha256':sha(report.read_bytes()),
 'proposal_freeze_sha256':sha(freeze.read_bytes()),'actual_remote_main':'d9bcd4231df69061c5221f8d557ee179a945c1eb',
 'old_STAB':[],'no_new_source_verdict':True,'root_site_graph_browser_remote_purification_pending':True}
assert not (b/'root-sole-STAB-application-authorization.json').exists()
put(b/'root-sole-STAB-application-authorization.json',authorization)
adv.transition_advance(aid,to_state='STABILIZING',worker_id=owner,evidence={
 'integration_owner':owner,'source_V_first_commit':'cc9e72d2a140a577258ed3a9c2c782cb561f3709',
 'verifier_id':audit['source_review']['reviewer'],'verified_commit':'813268bc2683a82269364caffbc0c7490a884204',
 'lean_declarations':[decl],'publication_declarations':[decl],
 'independent_reviewed_proposal':str(report),'proposal_sha256':sha(report.read_bytes()),
 'scope':'Exact six shared paths, one new mathematical result plus existing canonical GPD compilation inventory; preserve historical source audit debt.',
 'authorization':str(b/'root-sole-STAB-application-authorization.json'),
 'truth_boundary':'Existing source V preserved. Actual final immutable root/site/graph/desktop-mobile/reader acceptance, remote/purification and both main bounds/wholeGoal remain pending.'})
after=lp.read_bytes();assert after.startswith(before) and len(after[len(before):].splitlines())==1
for q,raw in payloads:q.write_bytes(raw)
now=adv.current_advances();assert now[aid]['state']=='STABILIZING' and now[aid]['owner_id']==states[aid]['owner_id']
assert [k for k,s in now.items() if s['state']=='STABILIZING']==[aid]
assert all(now[k]==s for k,s in states.items() if k!=aid)
assert dp.read_bytes()==discovery and ap.read_bytes()==audit_raw and readme.read_bytes()==readme_raw
assert all(Path(q).read_bytes()==raw for q,raw in foreign.items())
for row in p['shared_paths']:assert sha(Path(row['path']).read_bytes())==row['planned_after_sha256']
for path,digest in {**p['source_Test_lesson_publication_pins'],**p['unchanged_models']}.items():assert sha(Path(path).read_bytes())==digest
for name,raw in [('before-STAB-ledger.lossless.jsonl.gz',before),('after-STAB-ledger.lossless.jsonl.gz',after),('sole-STAB-append.exact.jsonl.gz',after[len(before):])]:
 z=b/name;assert not z.exists();z.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(z.read_bytes())==raw
cell=json.loads(cp.read_bytes());cell['evidence']['canonical_integration']={
 'state':'SOLE_STAB_EXACT_SIX_PATHS_APPLIED_ACTUAL_GATES_PENDING','owner':owner,
 'source_V_first_carrying_commit':'cc9e72d2a140a577258ed3a9c2c782cb561f3709',
 'proposal':str(report),'proposal_report_sha256':sha(report.read_bytes()),
 'source_proof_unchanged':True,'historical_GPD_sourceV_upgraded':False}
put(cp,cell)
record={'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'normal_state':now[aid]['state'],'integration_owner':owner,'normal_STAB_append_events':1,
 'ledger_before_sha256':sha(before),'ledger_after_sha256':sha(after),
 'append_sha256':sha(after[len(before):]),'exact_old_prefix_preserved':True,
 'foreign_states_preserved':len(states)-1,'foreign_frontier_files_preserved':len(foreign),
 'discovery_audit_README_source_lesson_models_unchanged':True,
 'applied_exact_shared_paths':[{'path':row['path'],'sha256':row['planned_after_sha256']} for row in p['shared_paths']],
 'source_V_preserved_not_reissued':True,'new_theorems':1,'existing_compiled_GPD_inventory_only':1,
 'canonical_build_site_graph_actual_browser_acceptance':'Pending final immutable core.'}
put(b/'exact-shared-application-receipt.json',record)
print(json.dumps({'state':now[aid]['state'],'exact_shared_paths_applied':6,
 'foreign_states_preserved':len(states)-1,'foreign_frontiers_preserved':len(foreign),
 'old_source_V_and_README_unchanged':True,'next':'Freeze immutable core, then actual canonical gates and browser.'}))
