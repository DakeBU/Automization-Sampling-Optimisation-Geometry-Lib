from pathlib import Path
W = Path(__file__).parent
text = (W/'check_disabled_v4_static_cg.py').read_text()
text = text.replace("D = W/'disabled-v4-cosine-gram-static'", "D = W/'disabled-v5-cosine-gram-static'")
text = text.replace('reader-step-neighbor-proposal-v4/', 'reader-step-neighbor-proposal-v5/')
text = text.replace('01e205b8e16fe54ed32be93ac57b0ef42e3fcdccee84e3f878a8e34d6a03e93b', '64f7c70a7501b7143d16ef2317d8a0685c6ad37be6bd1f8cea2a021c7a6672e4')
needle = 'assert production.read_bytes() == before and lesson.read_bytes() == lesson_raw'
assert text.count(needle) == 1
extra = '''# Replay the original independent frozen U+2028 counterexample, exact bytes.
finding_path = W/'reader-step-neighbor-v4-independent-0a91de/findings.json'
assert sha(finding_path.read_bytes()) == 'e1cd945656648863a028686541b375f4c7a9a824518fbcc45ebc5215e81ed057'
counter = json.loads(finding_path.read_bytes())['independent_counterexample']
raw_counter = bytes.fromhex(counter['source_bytes_hex'])
assert sha(raw_counter) == counter['source_sha256']
literal = raw_counter.partition(b'\\n')[2]
assert sha(literal) == counter['literal_sha256']
fixture_root = D/'unicode-fixture'
fixture_root.mkdir()
(fixture_root/'UnicodeLineSeparator.lean').write_bytes(raw_counter)
dl.ROOT = fixture_root.resolve()
fixture_unit = {'sources': [{'path': 'UnicodeLineSeparator.lean'}]}
actions = BeautifulSoup(dl.exact_lean_step_actions(fixture_unit, {'lean': literal.decode()}, 'lessons/test.html'), 'html.parser')
context_link = next(a['href'] for a in actions.find_all('a') if a.get_text() == 'Exact source context')
assert context_link.endswith('#L2')
fixture_out = D/'unicode-output'
(fixture_out/'textbook').mkdir(parents=True)
(fixture_out/'textbook/index.html').write_bytes(fixture)
dl.export_sources(fixture_out, [fixture_unit])
context_path = fixture_out/'data/lesson-sources/UnicodeLineSeparator.lean.html'
context_soup = BeautifulSoup(context_path.read_text(), 'html.parser')
assert context_soup.find(id='L2').get_text() == literal.decode().split('\\n')[0]
assert (fixture_out/'data/lesson-sources/UnicodeLineSeparator.lean').read_bytes() == raw_counter
dl.ROOT = R
'''
text = text.replace(needle, extra+'\n'+needle)
text = text.replace("'reader_HOLD_still_pending': True", "'original_frozen_Unicode_counterexample_replayed_and_correctly_routed': True, 'reader_HOLD_still_pending': True")
with (W/'check_disabled_v5_static_cg.py').open('x') as f:
    f.write(text)
print('Prepared v5 six-route and exact original Unicode-counterexample regression')
