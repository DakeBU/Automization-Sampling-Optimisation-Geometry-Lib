from pathlib import Path
import subprocess,sys
r=Path(__file__).resolve().parent;repo=r.parents[2]
for label,p in [("isolated-producer","AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumThreshold.lean"),("isolated-Test","Tests/GaussianComplexityFixedSpectrumThreshold.lean")]:
 out=r/"oleans"/Path(p).with_suffix(".olean");out.parent.mkdir(parents=True,exist_ok=True)
 code=subprocess.run([sys.executable,str(r/"run_recorded.py"),label,"lean","-o",str(out),p],cwd=repo).returncode
 if code:sys.exit(code)
sys.exit(0)
