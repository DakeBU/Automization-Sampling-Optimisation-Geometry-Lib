from pathlib import Path
import hashlib,json,re,html
OUT=Path(__file__).parent;BASE=OUT.parent
sha=lambda b:hashlib.sha256(b).hexdigest()
ps=json.loads((BASE/'phase1/source_pins.json').read_bytes());by={p['id']:p for p in ps['pins']}
source=Path(ps['source']);b=source.read_bytes();assert sha(b)==ps['source_sha256'];s=b.decode('utf8')
ids=['S4.E11.m1','S4.Ex10.m1','S4.SS2.SSS0.Px1.p3.m1','S4.SS2.SSS0.Px2.p2','A3.SS2.p1','A3.Ex85.m1','A3.Ex86.m1','A3.SS2.p3','A3.SS2.p19.2','A3.Ex130.m1','A3.Ex130.m2','A3.Ex131.m1','A3.Ex131.m2']
records=[]
for ident in ids:
 p=by[ident];a,z=p['char_start'],p['char_end_exclusive'];b0,b1=p['utf8_byte_start'],p['utf8_byte_end_exclusive']
 assert s[a:z].encode('utf8')==b[b0:b1]
 assert sha(b[b0:b1])==p['raw_utf8_sha256']
 assert s.count('\n',0,a)+1==p['line_start_1based']
 assert s.count('\n',0,z-1)+1==p['line_end_inclusive_1based']
 raw=s[a:z];alts=[html.unescape(v) for v in re.findall(r'\balttext="([^"]*)"',raw)]
 records.append({'source_id':ident,'raw_pin':p,'all_math_alttexts_in_raw_span':alts,'raw_byte_char_hash_and_LF_recheck':True})
 (OUT/(ident+'.source-raw.html')).write_bytes(b[b0:b1])
result={'source':str(source),'source_sha256':sha(b),'phase1_locator_reused_without_change':True,'records':records,'meaning_check':'Statements are compared by independent mathematical index/normalization analysis in phase2a_binder_definition_audit.md; coordinates alone are not a semantic verdict.'}
(OUT/'source-locator-recheck.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False,indent=2))
