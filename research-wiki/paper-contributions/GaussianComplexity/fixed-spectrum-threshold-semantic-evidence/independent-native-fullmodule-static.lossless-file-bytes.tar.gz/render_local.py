from pathlib import Path
import sys,json,hashlib,html,re,shutil
from html.parser import HTMLParser
sys.dont_write_bytecode=True
root=Path(__file__).resolve().parent; repo=root.parents[2]
sys.path[:0]=[str(repo/"tools"),str(repo/"website/scripts")]
import astis_site as base,inline_lean,declaration_lessons
paths=["AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumThreshold.lean","AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumModeGap.lean","AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumBias.lean"]
base.project_lean_paths=lambda:[repo/p for p in paths]
_,decls=base.scan_project_sources();base._SOURCE_BY_NAME={d.full_name:d for d in decls}
base._ACTIVE_GIT=base.GitContext("521b422bad98d4297e86058b4a31e1f15aa4b064","isolated-static-review","","",False,False,set())
unit=json.loads((repo/"website/content/declaration_lessons/huanjian-fixed-spectrum-threshold.json").read_text())["units"][0]
page="lessons/current-threshold.html";out=root/"static";(out/"lessons").mkdir(parents=True,exist_ok=True)
body=declaration_lessons.render_unit(unit,page)
def shell(title,body,rel):
 p=base.relative_prefix(rel)
 return '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'+html.escape(title)+'</title><link rel="stylesheet" href="'+p+'assets/site.css"><link rel="stylesheet" href="'+p+'assets/proof-readers.css"></head><body><main id="content">'+body+'</main></body></html>'
(out/page).write_text(shell(unit["title"],body,page))
for name in ["site.css","proof-readers.css"]:
 (out/"assets").mkdir(exist_ok=True);shutil.copyfile(repo/"website/static"/name,out/"assets"/name)
for source in unit["sources"]:
 if not source.get("path"):continue
 p=source["path"];rel="data/lesson-sources/"+p+".html";dest=out/rel;dest.parent.mkdir(parents=True,exist_ok=True)
 text=(repo/p).read_text();numbered=''.join(f'<span id="L{i}">{html.escape(line)}</span>\n' for i,line in enumerate(text.splitlines(),1))
 dest.write_text(shell("Exact source context",'<h1>Exact source context</h1><pre>'+numbered+'</pre>',rel))
# Exact module context and download links emitted by the renderer.
for p in paths:
 text=(repo/p).read_text();module=p.removesuffix(".lean").replace("/",".");rel="modules/"+base.slugify(module)+".html";dest=out/rel;dest.parent.mkdir(parents=True,exist_ok=True)
 dest.write_text(shell(module,'<h1>Exact module context</h1><div id="complete-module-source">'+base.code_html(text)+'</div>',rel))
 dest=out/"downloads/lean"/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(text)
class Inspect(HTMLParser):
 def __init__(self):super().__init__();self.stack=[];self.details=[];self.pre_depth=0;self.code_depth=0;self.pre_context=[];self.hrefs=[]
 def handle_starttag(self,tag,attrs):
  a=dict(attrs)
  if tag=="details":self.stack.append(a);self.details.append(a)
  if tag=="pre":self.pre_context.append(list(self.stack))
  if tag=="a":self.hrefs.append(a.get("href",""))
 def handle_endtag(self,tag):
  if tag=="details":self.stack.pop()
ins=Inspect();ins.feed(body)
prod=(repo/paths[0]).read_text();test=(repo/"Tests/GaussianComplexityFixedSpectrumThreshold.lean").read_text()
snippets=[]
for i,step in enumerate(unit["steps"],1):
 text=step["lean"];where="production" if text in prod else "complete-private-Test" if text==test else "Test-excerpt" if text in test else None
 assert where,(i,"not contiguous exact source")
 snippets.append({"step":i,"exact_contiguous":True,"source":where,"sha256":hashlib.sha256(text.encode()).hexdigest()})
assert len(snippets)==6
assert all("open" not in a for a in ins.details)
assert all(context for context in ins.pre_context)
assert test==unit["steps"][5]["lean"]
shared=[h for h in ins.hrefs if "data/lesson-sources/Tests/GaussianComplexityFixedSpectrumThreshold.lean.html#L25" in h]
assert shared
assert (out/"data/lesson-sources/Tests/GaussianComplexityFixedSpectrumThreshold.lean.html").is_file()
report={"method":"existing declaration_lessons.render_unit; source scanner restricted to current Threshold and current canonical parent context files; isolated static shell only","lesson_path":str(out/page),"details_total":len(ins.details),"all_initially_folded":True,"all_exact_code_folded":True,"proof_steps":6,"snippets":snippets,"complete_private_test_exact":True,"adjacent_exported_complete_private_Test_link":shared,"limitations":["Static HTML structure/content inspection only. No browser, desktop/mobile, shared site build, source index, graph, Registry or remote acceptance."]}
(root/"local-reader-report.json").write_text(json.dumps(report,indent=2)+"\n");print(json.dumps(report,indent=2))
