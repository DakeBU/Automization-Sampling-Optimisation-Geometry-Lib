import hashlib,json,pathlib,re,sys
from run import ROOT,REPO
sys.path[:0]=[str(REPO/'tools')]
import astis_site
sha=lambda b:hashlib.sha256(b).hexdigest()
im=json.loads((ROOT/'input-manifest.json').read_text())
seal=json.loads((ROOT/'inputs/research-wiki/paper-contributions/GaussianComplexity/weighted-cosine-frame-statement-seal.json').read_text())
mapping=json.loads((ROOT/'inputs/research-wiki/paper-contributions/GaussianComplexity/weighted-cosine-frame-semantic-evidence/source-lean-map.draft.json').read_text())
raw=(REPO/seal['source']['raw']).read_bytes();text=raw.decode();assert sha(raw)==seal['source']['raw_sha256']==mapping['source_sha256']
checked=[];snippets={}
def source_span(obj):
    if 'source_id' not in obj:return
    if 'char_span' in obj:
        a,b=obj['char_span'];ba,bb=obj['UTF8_byte_span'];line=obj['LF_lines_1based'][0]
    else:
        a,b=obj['char_start'],obj['char_end'];ba,bb=obj['raw_utf8_start'],obj['raw_utf8_end'];line=obj['lf_line_start']
    s=text[a:b];assert s.encode()==raw[ba:bb]
    assert sha(s.encode())==obj['span_sha256'],obj['source_id']
    assert text[:a].count('\n')+1==line,obj['source_id']
    assert 'id="'+obj['source_id']+'"' in s,obj['source_id']
    snippets[obj['source_id']]=s
    checked.append({'kind':'source','id':obj['source_id'],'sha256':obj['span_sha256'],'raw_bytes':[ba,bb],'char_span':[a,b],'line':line})
def lean_span(obj):
    p=obj['path'];b=(ROOT/'inputs'/p).read_bytes() if not p.startswith('.lake/') else (REPO/p).read_bytes()
    t=b.decode();assert sha(b)==obj['file_sha256'],p
    a,z=obj['raw_UTF8_byte_span'];ca,cz=obj['decoded_char_span'];s=t[ca:cz]
    assert b[a:z]==s.encode() and sha(b[a:z])==obj['span_sha256'],p
    assert t[:ca].count('\n')+1==obj['LF_lines_1based'][0],p
    assert t[:cz].count('\n')==obj['LF_lines_1based'][1],(p,obj['LF_lines_1based'])
    checked.append({'kind':'lean','path':p,'sha256':obj['span_sha256'],'lines':obj['LF_lines_1based']})
for obj in seal['source']['anchors']:source_span(obj)
for m in mapping['mappings']:
    for x in m['source']:source_span(x)
    for x in m['lean']:lean_span(x)
for m in mapping['proof_background']:
    lean_span(m['source']);lean_span(m['consumer'])
scans=[]
for p in im['modules']:
    t=(ROOT/'inputs'/p).read_text();clean=astis_site.sanitize_lean(t)
    found=re.findall(r'\b(?:sorry|admit|axiom|constant|postulate|opaque)\b|Prop\s*:=\s*True|:=\s*trivial',clean)
    assert not found,(p,found)
    scans.append({'path':p,'fake_closure_tokens':found,'whole_module_sha256':sha((ROOT/'inputs'/p).read_bytes())})
(ROOT/'source-snippets.json').write_text(json.dumps(snippets,ensure_ascii=False,indent=2)+'\n')
(ROOT/'locator-checks.json').write_text(json.dumps({'source_raw_sha256':sha(raw),'source_raw_path':seal['source']['raw'],'unique_source_spans':len(snippets),'checked_locators':checked,'whole_module_fake_closure_scan':scans,'semantic_scope':'Exact span/line/hash integrity only; source-equivalence/topology verdicts are separate.'},indent=2)+'\n')
print(json.dumps({'verified_locators':len(checked),'unique_source_snippets':len(snippets),'six_module_fake_closure_scan':'clean'}))
