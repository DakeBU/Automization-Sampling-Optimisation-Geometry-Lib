"""No retry: only compare stopped window2 before guards with current bytes and preserve failure evidence."""
from verification_common import *
import traceback
def main():
    a=read(OWN/'window2.ROOT-authorization.v1.json');directory=PRIVATE/'window2-before'
    before={'state':read(directory/'full-guard-map.private.json'),'araw':(directory/'advance-ledger.exact.jsonl').read_bytes(),'draw':(directory/'discovery-ledger.exact.jsonl').read_bytes(),'index':(directory/'index.exact').read_bytes()}
    after=snapshot('window2-failed-no-write-after',a);g=postguards(before,after,a,set())
    assert before['araw']==after['araw'] and before['draw']==after['draw']
    assert file_sha(REPO/CELL)==a['expected_target_cell_sha256'] and not (PRIVATE/'target-cell-attempted.once.json').exists()
    original=read(OWN/'window2-OS-receipt.public.json');assert original['actual_exit_code']==1
    write(OWN/'window2-failure-preservation.public.json',{'status':'ACTUAL_WINDOW2_EXIT1_BEFORE_MARKER_OR_CELL_WRITE;PRESERVATION_CONFIRMED_NO_RETRY','classification':'IMPLEMENTATION_FAILED_IN_LOCAL_CELL_PROJECTION_VALIDATION','advance_id':ADV,'actual_window2_exit_code':1,'failure_location':'verification_driver.py line102 assert not cells.validate_cells([probe])','validator_error_list_not_printed_by_original_driver':True,'window2_marker_present':False,'window1_marker_present':'Existing sole successful normal-V marker; stopped summary API_attempt_marker_present=true refers to that preexisting marker only.','normal_API_calls_in_window2':0,'additional_V_or_cell_replay_or_rollback':False,'target_cell_status':read(REPO/CELL)['status'],'target_cell_sha256_unchanged':file_sha(REPO/CELL),'window1_V_outcome_unchanged':ident(OWN/'normal-V-outcome.public.json'),'window1_exact_V_append_unchanged':ident(OWN/'normal-V-exact-append.jsonl'),'all_window2_failure_preservation_guards_passed':True,'both_ledgers_exact_before_after':True,'guards':g,'actual_failed_OS_receipt':ident(OWN/'window2-OS-receipt.public.json'),'actual_failed_stdout_sha256':original['raw_stdout']['sha256'],'actual_failed_stderr_sha256':original['raw_stderr']['sha256'],'raw_failure_streams_and_full_guard_maps_stay_private':True,'this_followup_is_readonly_guard_comparison_not_a_second_action':True,'normal_V_success_not_refuted_by_local_projection_failure':True})
    print(json.dumps({'actual_window2_exit_code':1,'read_only_failure_preservation':'ALL_GUARDS_PASSED_NO_WRITE','target_cell_sha256':file_sha(REPO/CELL),'failure_report_sha256':file_sha(OWN/'window2-failure-preservation.public.json'),'no_API_action_replay':True}))
if __name__=='__main__':
    os.umask(0o077);directory=PRIVATE/'window2-failure-preservation-OS';assert not directory.exists();private_dir(directory);out=directory/'stdout.raw';err=directory/'stderr.raw';started=dt.datetime.now(dt.timezone.utc).isoformat();start=time.monotonic();code=0
    for fd,p in [(1,out),(2,err)]:
        f=p.open('xb',buffering=0);os.fchmod(f.fileno(),0o600);os.dup2(f.fileno(),fd);f.close()
    try:main()
    except BaseException:traceback.print_exc();code=1
    sys.stdout.flush();sys.stderr.flush();receipt={'schema':'r16-window2-failure-readonly-preservation-actual-OS-receipt-v1','argv':[sys.executable,*sys.argv],'cwd':str(REPO),'pid':os.getpid(),'started_utc':started,'ended_utc':dt.datetime.now(dt.timezone.utc).isoformat(),'elapsed_seconds':time.monotonic()-start,'actual_exit_code':code,'stdout_sha256':file_sha(out),'stderr_sha256':file_sha(err),'raw_streams_private':True,'script_sha256':file_sha(__file__),'normal_API_or_target_cell_actions':0}
    write(directory/'receipt.private.json',receipt);exact(OWN/'window2-failure-preservation-OS.public.json',(directory/'receipt.private.json').read_bytes());sys.exit(code)
