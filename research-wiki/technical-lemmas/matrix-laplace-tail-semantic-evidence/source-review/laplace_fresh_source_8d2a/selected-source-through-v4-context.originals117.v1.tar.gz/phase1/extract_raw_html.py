from pathlib import Path
from html.parser import HTMLParser
import json
ROOT=Path(__file__).parent
class Raw(HTMLParser):
 def __init__(self,target):
  super().__init__(); self.target=target; self.active=False; self.depth=0; self.skip=0; self.bits=[]; self.math=[]
 def handle_starttag(self,tag,attrs):
  a=dict(attrs)
  if not self.active:
   if a.get('id')!=self.target:return
   self.active=True; self.depth=1; self.bits.append(f'[{tag} id={self.target}]\n'); return
  if self.skip:
   if tag not in ['br','hr','img','meta','link','input','wbr']: self.skip+=1
   return
  if tag=='math':
   self.bits.append('$'+a.get('alttext','[no alttext]')+'$');self.math.append(a);self.skip=1;return
  if tag not in ['br','hr','img','meta','link','input','wbr']:self.depth+=1
  if tag in ['p','h1','h2','h3','h4','h5','h6','table','tr','section','div']:self.bits.append('\n')
  if tag=='a' and a.get('href'):self.bits.append('[href='+a['href']+']')
 def handle_endtag(self,tag):
  if not self.active:return
  if self.skip:self.skip-=1;return
  self.depth-=1
  if tag in ['p','h1','h2','h3','h4','h5','h6','table','tr','section','div']:self.bits.append('\n')
  if self.depth==0:self.active=False
 def handle_data(self,data):
  if self.active and not self.skip:self.bits.append(data)
source=(ROOT/'inputs/.astis__huanjian-handoff-20261019__2610.20492v1.html').read_text()
for target in ['A3.SS2','S4.SS1','S4.Thmtheorem4','bib.bib33']:
 x=Raw(target);x.feed(source)
 (ROOT/(target.replace('.','_')+'_extracted.txt')).write_text(''.join(x.bits))
 (ROOT/(target.replace('.','_')+'_math.json')).write_text(json.dumps(x.math,indent=2,ensure_ascii=False)+'\n')
 print(target,len(''.join(x.bits)),len(x.math))
