from pathlib import Path
import contextlib
import copy
import datetime
import gzip
import hashlib
import io
import json
import subprocess
import sys
import traceback

ROOT = Path('/Users/zhouhuanjian/ASTIS-GC')
OWN = ROOT / '.astis/semantic-neutral-20261109/src_82a91d'
OUT = OWN / 'normal-sourceV-runtime'
HEAD = '3cb4f0b7f5f4f8bf9fc6644d13e9581bccad3508'
ADVANCE = 'ASTIS-SA-20261109-GaussianComplexityFixedSpectrumGridAlias'
OWNER = 'huanjian_gc_20261109_fixed_spectrum_grid_alias'
ACTOR = '/root/source_reader_82a91d'
DECL = 'AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumGridAlias.actual_midpoint_grid_cosine_alias'
AUDIT = ROOT / 'research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-grid-alias.json'
ADV = ROOT / 'runs/substantive_advances.jsonl'
DISC = ROOT / 'runs/substantive_discoveries.jsonl'
sys.path.insert(0, str(ROOT))
from tools import astis_advance as api
from tools import astis_publication as publication
from tools import astis_semantic_roundtrip as roundtrip

def sha(data):
    return hashlib.sha256(data).hexdigest()

def dump(name, value):
    path = OUT / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
    return path

def ref(path):
    path = Path(path)
    b = path.read_bytes()
    return {'path': str(path.relative_to(ROOT)), 'bytes': len(b), 'sha256': sha(b)}

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT).decode()

def pure_parse(path):
    raw = path.read_bytes()
    assert not raw or raw.endswith(b'\n'), f'unterminated ledger tail: {path}'
    records = []
    for number, line in enumerate(raw.splitlines(keepends=True), start=1):
        assert line.endswith(b'\n') and line.strip(), f'invalid blank/tail row {path}:{number}'
        value = json.loads(line)
        assert isinstance(value, dict), f'nonobject ledger row {path}:{number}'
        records.append(value)
    return raw, records

def verify_inputs():
    assert git('rev-parse', 'HEAD').strip() == HEAD
    for phase in ['phase1', 'phase2', 'phase3', 'phase3-successor']:
        freeze = json.loads((OWN / phase / 'FREEZE.json').read_text())
        for row in freeze['files']:
            assert sha((OWN / phase / row['path']).read_bytes()) == row['sha256'], (phase, row['path'])
    expected = {
        'AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumGridAlias.lean': 'c98c899bd8b596388ae433e9241a7827e01d29c3ffcc945719238fa2e96f7d60',
        'Tests/GaussianComplexityFixedSpectrumGridAlias.lean': '9f3b9e64dced3467dbd163fde7918c376571d766bcebf7f7e25717b87de5d128',
        'website/content/declaration_lessons/huanjian-fixed-spectrum-grid-alias.json': '31af5a717308bb4bddaf919af481092de90c8fab7dad38de8e1263d57239cfb3',
        'website/content/publications/huanjian-fixed-spectrum-grid-alias.json': '596bfcc1eef259d609c58a8a4bfa86439e19bd4a76465898dbbe54e612db20d6',
        'lean-toolchain': '302cd63c54178885b89e669f33b38f12f4dd7ae7e5cac537b3203e3768d8fb2b',
        'lake-manifest.json': 'b83ca83b9cf7caa85fa8b023c2ff9a3fb7a7cce7e1c332e810c348535ec49c37',
        '.astis/huanjian-resume-20261103/2610.20492v1.html': '6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915',
        str(AUDIT.relative_to(ROOT)): '14433bd943b29a66aa4bdcbb6fb1894f682b75bff13a92b08cef312da3f478dd',
    }
    for name, h in expected.items():
        assert sha((ROOT / name).read_bytes()) == h, name
    proposal_path = OWN / 'phase3-successor/canonical-audit-update-proposal.json'
    assert sha(proposal_path.read_bytes()) == '9928c983a96785c105fff93a6311b05fc0a79d35aa877a39ca6b6e61445d2eb5'
    proposal = json.loads(proposal_path.read_text())
    audit = json.loads(AUDIT.read_text())
    for key, value in proposal.items():
        assert audit[key] == value, ('applied proposal mismatch', key)
    assert audit['state'] == 'source-reviewed' and audit['source_review']['state'] == 'accepted'
    assert audit['source_review']['reviewer'] == ACTOR
    assert audit['source_review']['independent_from_formalizer'] is True
    assert audit['source_review']['independent_from_decoder'] is True
    assert len({ACTOR, OWNER, audit['reconstruction']['decoder']}) == 3
    packet = roundtrip.semantic_reviewer_packet(audit)
    assert packet['packet_sha256'] == 'f381a1ca1e1aa488cc8cc259e0bae1f9d00a2b391e9ff4966cc64e0ae57875bb'
    assert packet == json.loads((OWN / 'phase3-successor/inputs/canonical-reviewer-packet-reader-v2.json').read_text())
    assert audit['publication_binding_sha256'] == 'c7b557be6ccb8b31fb252c496a4f5535d950fddd8ff3d06a6029527cbdee3f5d'
    assert audit['source_review']['review_run_sha256'] == '2f6adfb5ca211aa4d480b28750734f84e917d6ff16358e60ca53f5516f4aef62'
    return expected, audit, packet

def state_guards(records, discoveries):
    states = api._replay_advances(copy.deepcopy(records))
    dstate = api._replay_discoveries(copy.deepcopy(discoveries))
    item = states[ADVANCE]
    assert item['state'] == 'PROVED_LOCAL'
    assert item['owner_id'] == OWNER and ACTOR != OWNER
    assert int(item.get('schema_version', 1)) >= 4
    assert set(item['publication_declarations']) == {DECL}
    assert not [key for key, value in states.items() if value.get('state') == 'STABILIZING']
    return states, dstate

def preflight():
    assert not (OUT / 'preflight-success.json').exists(), 'preflight already completed; no unchanged replay'
    assert git('status', '--short', '--untracked-files=no') == ''
    expected, audit, packet = verify_inputs()
    adv_raw, records = pure_parse(ADV)
    disc_raw, discoveries = pure_parse(DISC)
    states, dstate = state_guards(records, discoveries)
    (OUT / 'advance-ledger.before.raw').write_bytes(adv_raw)
    (OUT / 'discovery-ledger.before.raw').write_bytes(disc_raw)
    dump('advance-states.before.json', states)
    dump('discovery-states.before.json', dstate)
    (OUT / 'accepted-audit.before.json').write_bytes(AUDIT.read_bytes())
    dump('exact-current-inputs.json', expected)
    roots = ROOT / 'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-grid-alias-semantic-evidence/fresh-source-reader-82a91d/actual-root-application-checks'
    root_refs = []
    for path in sorted(roots.glob('*source-reviewed-*.receipt.json')):
        value = json.loads(path.read_text())
        assert value['exit_code'] == 0
        assert value['head_before'] == value['head_after'] == '93a7005b3e861ddc58484fb3a21abd83ad44722b'
        log_path = path.with_name(path.name.replace('.receipt.json', '.log.gz'))
        log = gzip.decompress(log_path.read_bytes())
        assert sha(log) == value['log_sha256']
        (OUT / 'root-application-gates').mkdir(exist_ok=True)
        (OUT / 'root-application-gates' / path.name).write_bytes(path.read_bytes())
        (OUT / 'root-application-gates' / log_path.name).write_bytes(log_path.read_bytes())
        root_refs.append({'receipt': ref(path), 'compressed_log': ref(log_path),
                          'uncompressed_log_sha256': sha(log), 'command': value['command'],
                          'exit_code': value['exit_code'], 'head': value['head_before']})
    assert len(root_refs) == 4
    commands = [x['command'] for x in root_refs]
    assert any('tools/astis_contributor_contract.py' in c and '--base' in c and '71375dfbf73e209f49ae637317626de2e934ef2b' in c for c in commands)
    dump('root-gate-provenance.json', root_refs)
    # This is the real normal reviewed admission function, not a receipt assertion.
    stdout, stderr = io.StringIO(), io.StringIO()
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
        result = publication.check_advance([DECL], reviewed=True)
    ended = datetime.datetime.now(datetime.timezone.utc).isoformat()
    (OUT / 'normal-reviewed-admission.stdout.txt').write_text(stdout.getvalue())
    (OUT / 'normal-reviewed-admission.stderr.txt').write_text(stderr.getvalue())
    assert result is None
    data = publication.inputs()
    matched = [(item, binding) for item in publication.load() for binding in item['bindings']
               if binding['declaration'] == DECL]
    assert len(matched) == 1
    item, binding = matched[0]
    actual_binding = publication.binding_digest(item, binding, data)
    assert actual_binding == audit['publication_binding_sha256']
    assert publication.review_context(item, binding, data) == audit['publication_context']
    admission = {
        'function': 'tools.astis_publication.check_advance', 'arguments': {'declarations': [DECL], 'reviewed': True},
        'return_value': result, 'exit_code': 0, 'started_utc': started, 'ended_utc': ended,
        'head_before': HEAD, 'head_after': git('rev-parse', 'HEAD').strip(),
        'stdout': ref(OUT / 'normal-reviewed-admission.stdout.txt'),
        'stderr': ref(OUT / 'normal-reviewed-admission.stderr.txt'),
        'actual_binding_digest_recomputed': actual_binding,
        'actual_current_review_context_matches_accepted_audit': True,
    }
    assert admission['head_after'] == HEAD
    dump('normal-reviewed-admission.receipt.json', admission)
    assert ADV.read_bytes() == adv_raw and DISC.read_bytes() == disc_raw
    assert not git('status', '--short', '--untracked-files=no')
    dump('preflight-success.json', {
        'head': HEAD, 'verified_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'advance_state': states[ADVANCE]['state'], 'owner_id': states[ADVANCE]['owner_id'],
        'actor': ACTOR, 'creator_decoder_verifier_distinct': True, 'other_STABILIZING': [],
        'advance_rows': len(records), 'discovery_rows': len(discoveries),
        'all_advance_states_count': len(states), 'all_discovery_states_count': len(dstate),
        'advance_raw_prefix': ref(OUT / 'advance-ledger.before.raw'),
        'discovery_raw': ref(OUT / 'discovery-ledger.before.raw'),
        'pure_full_newline_valid_ledger_parse_and_replay': True,
        'no_recovery_or_tail_repair_called': True, 'current_normal_reviewed_admission': admission,
    })
    print('PREFLIGHT_PASS current normal reviewed admission, exact inputs, pure full ledgers, independent actor, no STABILIZING')

def execute():
    assert (OUT / 'preflight-success.json').is_file()
    assert not (OUT / 'API-CALLED.marker').exists(), 'sourceV API already attempted; no retry'
    expected, audit, packet = verify_inputs()
    assert not git('status', '--short', '--untracked-files=no')
    before = (OUT / 'advance-ledger.before.raw').read_bytes()
    dbefore = (OUT / 'discovery-ledger.before.raw').read_bytes()
    assert ADV.read_bytes() == before and DISC.read_bytes() == dbefore
    _, records = pure_parse(ADV)
    _, discoveries = pure_parse(DISC)
    states, dstate = state_guards(records, discoveries)
    admission_ref = ref(OUT / 'normal-reviewed-admission.receipt.json')
    prior = OWN / 'phase3'
    evidence = {
        'verifier_id': ACTOR,
        'verified_commit': HEAD,
        'checked_commit_layers': {
            'real_fresh_native_producer_Test_kernel': 'cbf3c22b901a484c463f417a3e206bb200622294',
            'accepted_full_source_whole_module_static_reader': '93a7005b3e861ddc58484fb3a21abd83ad44722b',
            'current_metadata_carrier_and_normal_reviewed_admission': HEAD,
            'no_fresh_native_build_claim_at_metadata_heads': True,
            'all_current_mathematical_reader_toolchain_manifest_bytes_content_equivalent': True,
        },
        'publication_declarations': [DECL],
        'gate': {
            'actual_fresh_producer': ref(prior / 'runtime/06-fresh-producer.receipt.json'),
            'actual_fresh_current_private_Test': ref(prior / 'runtime/07c-fresh-private-consumer.receipt.json'),
            'actual_kernel_literal_recursive_audit': ref(prior / 'runtime/08-kernel-dependency-literal-audit.receipt.json'),
            'current_normal_reviewed_admission': admission_ref,
            'actual_root_source_reviewed_four_gate_receipts': ref(OUT / 'root-gate-provenance.json'),
            'scope': 'Focused real native proof/kernel checks at cbf3; source/static reader at93a; current reviewed metadata admission at3cb4. No new native build or aggregate/site/UI/remote/Goal acceptance.',
        },
        'source_audit': {
            'raw_source_sha256': expected['.astis/huanjian-resume-20261103/2610.20492v1.html'],
            'phase1_source_only_freeze': ref(OWN / 'phase1/FREEZE.json'),
            'phase2_statement_only_freeze': ref(OWN / 'phase2/FREEZE.json'),
            'initial_whole_module_runtime_freeze': ref(OWN / 'phase3/FREEZE.json'),
            'accepted_successor_freeze': ref(OWN / 'phase3-successor/FREEZE.json'),
            'accepted_current_source_review_run': ref(OWN / 'phase3-successor/review-report.md'),
            'current_accepted_canonical_audit': ref(AUDIT),
            'source_review_state': audit['source_review']['state'],
            'verdict': audit['verdict'], 'blocking_semantic_deltas': [], 'source_repairs': [],
        },
        'fake_closure_scan': {
            'complete_current_source_hashes': expected,
            'source_lexical_and_context_scan': ref(prior / 'runtime/10-static-hash-context-scan.json'),
            'actual_recursive_kernel_log': ref(prior / 'runtime/08-kernel-dependency-literal-audit.stdout.txt'),
            'actual_recursive_axioms': ['propext', 'Classical.choice', 'Quot.sound'],
            'sorryAx_or_unauthorized_axiom': False,
            'generated_auxiliaries_inspected': 'One producer and three private Test Omega proof constants; full actual types/bodies/direct dependencies inspected, no public lemma credit.',
        },
        'actual_consumer': {
            'private_declaration': '_private.Tests.GaussianComplexityFixedSpectrumGridAlias.0.actual_weighted_inverse_grid_alias_series',
            'current_Test_sha256': expected['Tests/GaussianComplexityFixedSpectrumGridAlias.lean'],
            'sealed_literal_types_match_actual_kernel_types': True,
            'actual_public_ASTIS_parents_after_generated_aux_expansion': [
                DECL,
                'AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumCosineExpansion.actual_inverse_spectrum_cosine_expansion',
            ],
            'actual_import_resolution': ref(prior / 'runtime/11-actual-Test-import-resolution.stdout.txt'),
            'source_scope': 'Private deterministic summable weighted reciprocal-grid alias series; no Gaussian expectation identification or closed FactC8/Lemma4.5.',
        },
        'semantic_publication_review': {
            'reviewer_packet_sha256': packet['packet_sha256'],
            'publication_binding_sha256': audit['publication_binding_sha256'],
            'review_run_sha256': audit['source_review']['review_run_sha256'],
            'accepted_audit_sha256': sha(AUDIT.read_bytes()),
            'actual_current_binding_and_complete_context_recomputed_via_normal_publication_API': True,
            'formalizer': OWNER, 'decoder': audit['reconstruction']['decoder'], 'reviewer': ACTOR,
            'all_distinct': True, 'P3_R1_exposition_successor': 'resolved and exact successor independently accepted',
        },
        'preflight': ref(OUT / 'preflight-success.json'),
        'truth_boundary': 'Verified only exact all-integer midpoint-grid aliases and actual private summable weighted reciprocal-grid alias-series use. Gaussian expectation bridges, alias partitions/closed C8 means, Lemma4.5 variance/bias, main lower bounds, STAB/integration/site/browser/remote/purification and whole-Goal completion remain outside this sourceV.',
        'later_existing_V_release_policy': 'Preserve EVERY original evidence field/value; only add post_integration. Original evidence object and exact append bytes are archived by this independent verifier.',
    }
    dump('original-evidence.json', evidence)
    dump('original-evidence-digest.json', {'raw': ref(OUT / 'original-evidence.json'),
         'canonical_object_sha256': sha(json.dumps(evidence, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode())})
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    # Exactly one normal API attempt. Marker is durable before the call.
    (OUT / 'API-CALLED.marker').write_text(started + '\n')
    result = api.transition_advance(
        ADVANCE, 'VERIFIED', worker_id=ACTOR,
        modes=('source-review', 'independent-verification'), evidence=evidence,
        path=ADV, discovery_path=DISC,
    )
    ended = datetime.datetime.now(datetime.timezone.utc).isoformat()
    after, after_records = pure_parse(ADV)
    dafter, after_discoveries = pure_parse(DISC)
    assert after.startswith(before), 'raw original advance prefix changed'
    appended = after[len(before):]
    assert appended.endswith(b'\n') and appended.count(b'\n') == 1
    event = json.loads(appended)
    assert event['advance_id'] == ADVANCE and event['from_state'] == 'PROVED_LOCAL' and event['to_state'] == 'VERIFIED'
    assert event['worker_id'] == ACTOR and event['evidence'] == evidence
    assert event['evidence'] == json.loads((OUT / 'original-evidence.json').read_text())
    assert result is None and len(after_records) == len(records) + 1
    assert dafter == dbefore and after_discoveries == discoveries
    new_states = api._replay_advances(copy.deepcopy(after_records))
    new_dstate = api._replay_discoveries(copy.deepcopy(after_discoveries))
    assert {k: v for k, v in states.items() if k != ADVANCE} == {k: v for k, v in new_states.items() if k != ADVANCE}
    assert dstate == new_dstate
    assert new_states[ADVANCE]['state'] == 'VERIFIED'
    assert new_states[ADVANCE]['latest_evidence'] == evidence
    assert new_states[ADVANCE]['owner_id'] == OWNER
    verify_inputs()
    changed = git('diff', '--name-only').splitlines()
    assert changed == ['runs/substantive_advances.jsonl'], changed
    (OUT / 'exact-appended-event.raw.jsonl').write_bytes(appended)
    dump('exact-appended-event.json', event)
    dump('API-result.json', {
        'function': 'tools.astis_advance.transition_advance',
        'advance_id': ADVANCE, 'to_state': 'VERIFIED', 'worker_id': ACTOR,
        'normal_API_attempt_count': 1, 'return_value': result, 'exit_code': 0,
        'started_utc': started, 'ended_utc': ended, 'head_before': HEAD, 'head_after': git('rev-parse', 'HEAD').strip(),
        'resulting_target_state': new_states[ADVANCE]['state'],
        'ledger_event_created_at': event['created_at'],
        'original_evidence': ref(OUT / 'original-evidence.json'),
        'exact_append': ref(OUT / 'exact-appended-event.raw.jsonl'),
        'advance_ledger_before_sha256': sha(before), 'advance_ledger_after_sha256': sha(after),
        'raw_prefix_preserved': True, 'exactly_one_new_row': True,
        'all_other_advance_states_preserved': True, 'all_discovery_bytes_and_states_preserved': True,
        'only_tracked_changed_path': changed,
        'all_current_source_audit_reader_toolchain_manifest_bytes_preserved': True,
        'all_other_tracked_frontier_model_README_source_audit_bytes_preserved_by_clean_baseline_and_exact_git_diff': True,
        'tail_repair_hand_append_other_status_API': False,
    })
    print('NORMAL_SOURCE_V_RESULT VERIFIED; normal API returned None; exactly one appended event; all other states/bytes preserved')

if __name__ == '__main__':
    OUT.mkdir(parents=True, exist_ok=True)
    try:
        if sys.argv[1] == 'preflight':
            preflight()
        elif sys.argv[1] == 'execute':
            execute()
        else:
            raise ValueError('unknown stage')
    except Exception:
        dump('GUARD-OR-API-FAILURE.json', {'stage': sys.argv[1], 'head': git('rev-parse', 'HEAD').strip(),
             'time_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
             'traceback': traceback.format_exc(), 'policy': 'STOP; no unchanged retry or forced transition'})
        raise
