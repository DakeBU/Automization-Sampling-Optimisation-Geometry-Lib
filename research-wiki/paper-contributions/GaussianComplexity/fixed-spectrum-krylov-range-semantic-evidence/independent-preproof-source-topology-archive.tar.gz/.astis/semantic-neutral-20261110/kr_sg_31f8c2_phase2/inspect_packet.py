from pathlib import Path
import hashlib,json,stat
ROOT=Path(__file__).resolve().parent;REPO=ROOT.parents[2];P1=ROOT.with_name('kr_sg_31f8c2')
sha=lambda b:hashlib.sha256(b).hexdigest()
dump=lambda n,x:(ROOT/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
assert sha((P1/'payload-manifest.json').read_bytes())=='973bcc204bdbad7ac177017fa859d81f03122e7fc583233857c9a31b32afa9b8'
assert sha((P1/'freeze-execution.receipt.json').read_bytes())=='904b257909aa4220c8a99a023b7c9f67e8ef0ed7d032a85b50a96bdb1af7ae91'
assert sha((P1/'freeze-envelope-hashes.json').read_bytes())=='86d6f23f4df295cdeacfd360057ceb770d3a82f62f7ca879e12666918cd3f43b'
for m in ['payload-manifest.json','freeze-envelope-hashes.json']:
    for r in json.loads((P1/m).read_bytes())['files']:
        b=(P1/r['path']).read_bytes();assert sha(b)==r['sha256'] and len(b)==r['bytes']
snapshot=[]
for p in sorted([P1]+list(P1.rglob('*'))):
    assert not p.is_symlink();st=p.stat();r={'path':'.' if p==P1 else str(p.relative_to(P1)),'type':'directory' if p.is_dir() else 'file','mode':format(stat.S_IMODE(st.st_mode),'04o'),'mtime_ns':st.st_mtime_ns,'ctime_ns':st.st_ctime_ns,'inode':st.st_ino}
    if p.is_file():
        b=p.read_bytes();r.update(bytes=len(b),sha256=sha(b));assert r['mode']=='0444'
    else:assert r['mode']=='0555'
    snapshot.append(r)
assert sum(r['type']=='file' for r in snapshot)==111
assert sum(r['type']=='directory' for r in snapshot)==6
dump('phase1-baseline.json',{'phase1_root':str(P1),'items':snapshot,'known_manifest_sha256':'973bcc204bdbad7ac177017fa859d81f03122e7fc583233857c9a31b32afa9b8','status':'preserved at Phase2 entry'})
path=REPO/'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-krylov-range-semantic-evidence/selective-preproof-types-and-definitions.json'
b=path.read_bytes();assert sha(b)=='471d8f4351d80f33d478049a0a2d8716689b2140c043aa324d8132f9b3fb79cb'
(ROOT/'exact-selective-packet.json').write_bytes(b)
dump('input-pins.json',{'selective_packet':{'path':str(path),'bytes':len(b),'sha256':sha(b)},'phase1_manifest_sha256':'973bcc204bdbad7ac177017fa859d81f03122e7fc583233857c9a31b32afa9b8','prior_phase1_status':'all111 files and6 directories modes/hashes verified; no mutation','expected_signature_sha256':{'public_P':'4d5056d57aa0536b95af7aa9f7c3b6860ab7c9652b0bb306b6bad42434235ab6','private_T':'082eda7b36ecff3e87a62358e4f234b6d6c129b491405de3761fa83f79412969'},'expected_core_seal_sha256':'f47e23a601d1a8e0ff4760224676313e0f1999877a97156841a65c01847e5d82'})
print(b.decode())
