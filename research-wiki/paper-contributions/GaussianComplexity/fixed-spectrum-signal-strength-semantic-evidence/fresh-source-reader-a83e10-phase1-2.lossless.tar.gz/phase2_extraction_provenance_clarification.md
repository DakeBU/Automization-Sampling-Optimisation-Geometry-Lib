# Additive extraction provenance clarification

This is a new phase 2 clarification. It does not modify or supersede any bytes of the phase 1 cognition, payloads, or freeze `f4b7e781a584005ade0a21cb0d1df46b1d154b9b94df33d2f83bced7ffe9f822`.

The phase 1 files `S2.html`, `S4.html`, `A3.SS3.html`, and `bib.bib3.html` were produced by parsing the source with BeautifulSoup and serializing the selected DOM elements with `str(section)`. They are **DERIVED extractions**, not established byte-identical raw substrings of the original HTML. Parsing and serialization can normalize quotation, whitespace, attribute representation and other markup. Their byte lengths differ from the corresponding original raw substrings. Their per-file hashes bind these derived files only.

The `.txt`, `.units.txt`, and JSON inventory/coverage files are also derived reading aids: math is taken from original MathML alttext, and whitespace/text presentation is normalized. Calling the inventory “raw source inventory” describes its source-only origin; it does not make it a byte-preserving primary document.

The exact primary authority is the complete original file `.astis/huanjian-resume-20261103/2610.20492v1.html` with SHA-256 `6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915`. Original DOM anchors identify the bounded reading regions within that primary authority. This phase does not claim separate raw-substring hashes, byte-identical scope slices, or a new source revision.
