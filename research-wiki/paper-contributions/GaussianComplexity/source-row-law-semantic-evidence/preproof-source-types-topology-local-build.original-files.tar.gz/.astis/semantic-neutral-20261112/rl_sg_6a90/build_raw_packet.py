"""Freeze only raw-source interpretation, coverage, and topology artifacts."""
from pathlib import Path
import hashlib
import json
from source_reader import SOURCE, read

OUT = Path('.astis/semantic-neutral-20261112/rl_sg_6a90')
raw, p = read()
EXPECTED = '6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
assert len(raw) == 951991 and hashlib.sha256(raw).hexdigest() == EXPECTED

def write_json(name, value):
    (OUT/name).write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n')

start = p.ids['A3.SS2'].start
end = p.ids['A3.SS2.p11'].end
fragment = p.source[start:end].encode('utf-8')
(OUT/'bounded_source_fragment.html').write_bytes(fragment)

context_ids = [
    'S2.p1', 'S2.SS0.SSS0.Px1.p1', 'S2.SS0.SSS0.Px2.p1',
    'S2.SS0.SSS0.Px4.p1', 'S4.p1', 'S4.p2', 'S4.Thmtheorem1',
    'S4.SS1.p1', 'S4.SS1.p2', 'S4.SS2.SSS0.Px1.p2',
    'S4.Thmtheorem3', 'S4.SS2.SSS0.Px2.p1', 'S4.Thmtheorem4',
    'A3.SS2.p12', 'A3.SS2.p17'
]
scope_ids = [ident for ident,e in p.ids.items() if start <= e.start and e.end <= end]
locator_ids = list(dict.fromkeys(scope_ids+context_ids))
locators = {ident:p.locator(p.ids[ident]) for ident in locator_ids}
write_json('locators.json', {
    'source':str(SOURCE), 'source_sha256':EXPECTED,
    'offset_convention':'UTF-8 byte and Unicode-codepoint character intervals are zero-based, half-open. Lines are 1-based inclusive. Original bytes are not newline-normalized.',
    'bounded_scope':{
        'start_char':start, 'end_char_exclusive':end,
        'start_byte':len(p.source[:start].encode()),
        'end_byte_exclusive':len(p.source[:end].encode()),
        'line_range_inclusive_1based':[3314,3569],
        'fragment_sha256':hashlib.sha256(fragment).hexdigest()
    },
    'items':locators
})

regions = {
    'A3.SS2.p1':('NODE','Construction and source law context. Only the fixed-row marginal component is the proposed narrow producer. The cosine vector, tensor matrix, and full joint-row independence are explicitly separate boundaries.'),
    'A3.SS2.p2':('EXCLUDED','Gram-matrix strategy and intended uniform Krylov-space consumer are context; no matrix claim belongs to this narrow row-law/union-estimate boundary.'),
    'A3.Thmtheorem5':('EXCLUDED','Fact C.5 comprises range(B), Gram expectations, cosine-vector bounds and deterministic moment identities. Preserved as source context; none is a premise of the scalar bad-row estimate.'),
    'A3.SS2.p3':('EXCLUDED','Polynomial/Chebyshev triangular change of basis and range(B)=K_q are outside the marginal-row/union boundary.'),
    'A3.SS2.p4':('EXCLUDED','Finite cosine sum cancellation and nonvanishing sine denominator are outside this scalar Gaussian-law boundary.'),
    'A3.SS2.p5':('EXCLUDED','Constant coordinate, product-to-sum, frequency cases, and sum_i t_i t_i^T=d I_r are outside this boundary, including q=0 empty cosine-index ranges.'),
    'A3.SS2.p6':('EXCLUDED','The source uses the row second moment in the tensor expectation. This is a distinct consumer, not the active probability-of-any-bad-row consumer.'),
    'A3.SS2.p7':('EXCLUDED','High-frequency cancellation and weighted Gram expectation are outside this boundary.'),
    'A3.SS2.p8':('EXCLUDED','Deterministic norm bound for the cosine vector is irrelevant to the bad-row union estimate.'),
    'A3.SS2.p9':('EXCLUDED','Concentration strategy is preserved as context; it is not a conclusion of the proposed narrow producer.'),
    'A3.Thmtheorem6':('EXCLUDED','The simultaneous matrix concentration statement at probability 0.995 is a later result. No concentration, variance, centering, or operator norm conclusion is credited here.'),
    'A3.SS2.p10':('NODE','Radius/cutoff definitions, exponential moment, Markov tail, and printed all-rows-good event probability supply the actual scalar consumer.'),
    'A3.SS2.p11':('EXCLUDED','Shifted tail and integrated truncation-bias estimate are recorded and located as the adjacent continuation. They require the same marginal law but are not claimed by this narrow packet.')
}

semantic_units = [
    {'id':'units.parameters', 'anchors':['A3.SS2.p1.m1','A3.SS2.p1.m3'], 'disposition':'NODE', 'meaning':'r=q+1, original row indices 1 through d.'},
    {'id':'units.frequency', 'anchors':['A3.SS2.p1.m2'], 'disposition':'EXCLUDED', 'reason':'n=2q+1 belongs to later cosine cancellation, not the row probability law.'},
    {'id':'units.row-definition', 'anchors':['A3.Ex85.m1'], 'component':'second formula, gamma_i=((g_1)_i,...,(g_r)_i)^T', 'disposition':'NODE', 'meaning':'Original row is a coordinate projection/rearrangement of the same random columns, with no resampling.'},
    {'id':'units.cosine-definition', 'anchors':['A3.Ex85.m1'], 'component':'first formula, t_i', 'disposition':'EXCLUDED', 'reason':'Companion deterministic vector retained in the same display; unused in the scalar marginal law and union bound.'},
    {'id':'units.printed-joint-row-assertion', 'anchors':['A3.SS2.p1.2','A3.SS2.p1.m4','A3.SS2.p1.m5'], 'component':'first sentence only', 'disposition':'EXCLUDED', 'reason':'The printed claim is that all gamma_i are independent N(0,I_r). Its fixed-row marginal component motivates this packet. Full joint independence remains a separate open proof boundary here; a family of marginal-law statements alone does not supply it.'},
    {'id':'units.tensor-matrix', 'anchors':['A3.SS2.p1.m6','A3.SS2.p1.m7','A3.SS2.p1.m8'], 'disposition':'EXCLUDED', 'reason':'B has d rows and r^2 columns with tensor row normalization d^(-1/2); no B law or matrix conclusion is required by the chosen scalar consumer.'},
    {'id':'units.radius-cutoff', 'anchors':['A3.SS2.p10.m1','A3.SS2.p10.m2'], 'disposition':'NODE', 'meaning':'L=2r+3 log(1000d); R_i=||gamma_i||^2 is the squared Euclidean norm.'},
    {'id':'units.exponential-moment', 'anchors':['A3.SS2.p10.m3'], 'disposition':'NODE', 'meaning':'E exp(R_i/3)=3^(r/2), printed without an integral calculation.'},
    {'id':'units.markov-and-range', 'anchors':['A3.SS2.p10.1','A3.SS2.p10.m4'], 'component':'Markov citation and x>=0', 'disposition':'NODE', 'meaning':'Apply Markov to the nonnegative exponential at a positive threshold.'},
    {'id':'units.tail', 'anchors':['A3.Ex104.m1'], 'disposition':'NODE', 'meaning':'For x>=0: P(R_i>2r+3x)<=exp((r/2) log 3-2r/3-x)<=exp(-x).'},
    {'id':'units.log-constant', 'anchors':['A3.SS2.p10.m5'], 'disposition':'NODE', 'meaning':'(log 3)/2<2/3 controls the factor depending on r.'},
    {'id':'units.good-event', 'anchors':['A3.Ex105.m1'], 'disposition':'NODE', 'meaning':'T={R_i<=L for every original row i}.'},
    {'id':'units.printed-good-probability', 'anchors':['A3.SS2.p10.3','A3.SS2.p10.m6'], 'disposition':'NODE', 'meaning':'Printed lower bound P(T)>=1-d/(1000d)=0.999.'},
    {'id':'units.shifted-tail', 'anchors':['A3.SS2.p11.m1','A3.SS2.p11.m2'], 'disposition':'EXCLUDED', 'reason':'Adjacent continuation: s>=0 and P(R_i>L+s)<=exp(-s/3)/(1000d); no shifted-tail theorem is claimed here.'},
    {'id':'units.tail-integral', 'anchors':['A3.Ex106.m1','A3.Ex106.m2'], 'disposition':'EXCLUDED', 'reason':'Adjacent continuation: E[R_i 1_{R_i>L}]=L P(R_i>L)+integral_0^infty P(R_i>L+s) ds <=(L+3)/(1000d). This is a distinct bias obligation.'}
]

def owner_for(e):
    candidates=[(p.ids[k].end-p.ids[k].start,k) for k in regions if p.ids[k].start <= e.start and e.end <= p.ids[k].end]
    return min(candidates)[1] if candidates else None

atoms=[]
for ident in scope_ids:
    e=p.ids[ident]
    if e.tag=='math' or e.tag=='p' or (e.tag in {'table','tbody'} and ('ltx_equation' in e.attrs.get('class','') or ident.startswith('A3.Ex'))):
        owner=owner_for(e)
        assert owner, ident
        disposition,reason=regions[owner]
        if ident.startswith('A3.SS2.p1.m'):
            if ident in ['A3.SS2.p1.m2','A3.SS2.p1.m4','A3.SS2.p1.m5','A3.SS2.p1.m6','A3.SS2.p1.m7','A3.SS2.p1.m8']:
                disposition='EXCLUDED'
                reason='See explicit p1 semantic component inventory; stronger joint-row claim, frequency, or tensor construction is outside the narrow producer.'
        atoms.append({'source_id':ident,'kind':('formula' if e.tag=='math' else 'display' if e.tag in {'table','tbody'} else 'proof-paragraph'), 'disposition':disposition,'region':owner,'reason_or_scope':reason,'locator_id':ident})

references=[]
for e in p.descendants(p.ids['A3.SS2']):
    if e.start>=end: continue
    if e.tag=='a':
        references.append({'href':e.attrs.get('href'), 'text':p.normalized_text(e), 'disposition':'NODE','reason':'Source section heading points to Lemma4.4, establishing the standing source context. There are no other linked citations inside the bounded interval.'})

coverage = {
    'scope':'Contiguous Appendix C.2 section heading through end of p11 (source lines3314-3569). Auxiliary standing anchors and later actual use-site p17 are separate context reads, not expanded proof coverage.',
    'claim_boundary':'Raw source coverage only; no mathematical implementation, independent coverage approval, proof completion, publication status, or full-lemma coverage is asserted.',
    'regions':[{'source_id':k,'disposition':v[0],'reason_or_scope':v[1],'locator_id':k} for k,v in regions.items()],
    'semantic_component_inventory':semantic_units,
    'source_atoms':atoms,
    'linked_references':references,
    'named_unlinked_external_input':[{'name':'Markov inequality','use_site':'A3.SS2.p10.1','disposition':'NODE','provenance':'Explicit source prose, no bibliography reference at this site.'}],
    'exhaustiveness_check':{
        'all_id_bearing_paragraphs_math_and_equation_containers_in_interval_accounted':True,
        'math_count':sum(x['kind']=='formula' for x in atoms),
        'paragraph_count':sum(x['kind']=='proof-paragraph' for x in atoms),
        'display_container_count':sum(x['kind']=='display' for x in atoms),
        'all_major_prose_regions_accounted':True,
        'section_and_proof_headings':'Section C.2 heading, Fact C.5 heading, its Proof heading, Fact C.6 heading and its Proof heading are structural wrappers. Titles identify the preserved regions and add no unlisted mathematical premise.'
    },
    'unread_or_unexpanded_regions':[
        {'region':'C.2 p12-p19, except exact context reads p12 and p17','disposition':'EXCLUDED','reason':'Centering, matrix norm/variance, Bernstein, concentration probability, simplification and completion of Lemma4.4 remain separate.'},
        {'region':'Appendix C.1 and other paper sections outside explicitly listed context reads','disposition':'EXCLUDED','reason':'No need to reconstruct Krylov representation, algorithm coupling, main theorem, oracle equivalence or cost accounting to interpret this bounded row-law consumer.'},
        {'region':'C.2 p12 context read','disposition':'EXCLUDED','reason':'Independent truncated matrices, radial symmetry, same scalar a, and expectation/bias identities are later obligations; shared row marginals alone do not establish independent matrices.'},
        {'region':'C.2 p17 context read','disposition':'EXCLUDED','reason':'Retained solely as a later use site of T; the matrix identities and probability0.995 are not proved or credited here.'}
    ]
}
write_json('bounded_inventory.json',coverage)

nodes=[
    {'id':'source.notation','status':'PRINTED','anchors':['S2.p1'],'meaning':'Norm is Euclidean; I_d denotes the identity matrix.'},
    {'id':'source.dimension','status':'PRINTED','anchors':['S2.SS0.SSS0.Px1.p1','S4.SS1.p1'],'meaning':'Dimension d is an integer; the Section4 construction uses d>=2.'},
    {'id':'source.columns','status':'PRINTED','anchors':['S4.Thmtheorem4'],'meaning':'q>=0, 2q+1<d; g_1,...,g_(q+1) are independent N(0,I_d) vectors. Integer query indexing is explicit in Lemma4.3 and the Section2 integer query-budget definition.'},
    {'id':'source.row','status':'PRINTED','anchors':['A3.SS2.p1.m1','A3.SS2.p1.m3','A3.Ex85.m1'],'meaning':'r=q+1; original gamma_i is ((g_1)_i,...,(g_r)_i)^T for each 1<=i<=d.'},
    {'id':'gap.fixed-row-coordinate-law','status':'SOURCE_GAP','gap_kind':'omitted standard-law bridge','anchors':['S4.Thmtheorem4','A3.SS2.p1.2'],'meaning':'The source does not expand why a coordinate of N(0,I_d) is N(0,1), why independent column projections remain independent, or why their r-tuple is N(0,I_r). These are the law-meaning details needed to realize the printed row marginal on the original experiment; no false-source claim is asserted.'},
    {'id':'inference.row-marginal','status':'SOURCE_SUPPORTED_INFERENCE','anchors':['A3.SS2.p1.2'],'meaning':'For every fixed original row i, the pushforward of the original column-experiment probability by gamma_i is the canonical standard r-dimensional Gaussian law. This is the marginal component of the stronger printed source assertion; it does not assert joint independence of rows.'},
    {'id':'source.radius-cutoff','status':'PRINTED','anchors':['A3.SS2.p10.m1','A3.SS2.p10.m2'],'meaning':'R_i=||gamma_i||^2 and L=2r+3 log(1000d).'},
    {'id':'source.exp-moment','status':'PRINTED','anchors':['A3.SS2.p10.m3'],'meaning':'E_original exp(R_i/3)=3^(r/2).'},
    {'id':'gap.exp-moment-calculation','status':'SOURCE_GAP','gap_kind':'omitted standard Gaussian integral','anchors':['A3.SS2.p10.m3'],'meaning':'The exact Gaussian squared-norm exponential integral is asserted without derivation. One canonical-row integral plus equality of marginal laws supplies the original-experiment expectation; no joint-row law is needed.'},
    {'id':'source.markov','status':'PRINTED_EXTERNAL_INPUT','anchors':['A3.SS2.p10.1'],'meaning':'Markov inequality used on exp(R_i/3); the source names it but supplies no bibliographic citation.'},
    {'id':'source.log-constant','status':'PRINTED','anchors':['A3.SS2.p10.m5'],'meaning':'(log 3)/2<2/3.'},
    {'id':'source.single-row-tail','status':'PRINTED','anchors':['A3.SS2.p10.m4','A3.Ex104.m1'],'meaning':'For every x>=0, P_original(R_i>2r+3x)<=exp((r/2)log3-2r/3-x)<=exp(-x).'},
    {'id':'inference.original-cutoff-tail','status':'SOURCE_SUPPORTED_INFERENCE','anchors':['A3.Ex104.m1','A3.SS2.p10.m1'],'meaning':'Substituting x=log(1000d)>=0 yields, for every original row i, P_original(R_i>L)<=1/(1000d). Not separately displayed.'},
    {'id':'inference.any-bad-row','status':'SOURCE_SUPPORTED_INFERENCE','anchors':['A3.SS2.p10.2','A3.Ex105.m1','A3.SS2.p10.3'],'meaning':'P_original(exists i in1..d: R_i>L)<=sum_i P_original(R_i>L)<=d/(1000d)=0.001. This explicit complement/union calculation is not separately printed. It needs each row marginal, not joint-row independence.'},
    {'id':'source.good-event','status':'PRINTED','anchors':['A3.Ex105.m1','A3.SS2.p10.3'],'meaning':'T={R_i<=L for every i}; P_original(T)>=1-d/(1000d)=0.999. This printed consequence is the preferred actual consumer anchor.'},
    {'id':'context.joint-row-law','status':'PRINTED_CONTEXT_EXCLUDED_PROOF_BOUNDARY','anchors':['A3.SS2.p1.2'],'meaning':'The source additionally asserts gamma_1,...,gamma_d are independent N(0,I_r). The full joint assertion is stronger than the narrow producer and is not inferred from a family of marginal statements or claimed as proved here.'},
    {'id':'context.shifted-tail-bias','status':'PRINTED_CONTEXT_EXCLUDED_PROOF_BOUNDARY','anchors':['A3.SS2.p11'],'meaning':'Source continuation gives the shifted tail and integrated bias bound; no such theorem is credited in this packet.'},
    {'id':'context.actual-later-use','status':'PRINTED_CONTEXT_EXCLUDED_PROOF_BOUNDARY','anchors':['A3.SS2.p17'],'meaning':'The source uses T to identify original and truncated sums, then combines its0.001 error with concentration error0.004. Only the T use-site is retained; all matrix/concentration conclusions remain separate.'}
]

edges=[
    {'from':['source.columns','source.row'],'to':'gap.fixed-row-coordinate-law','route':'original fixed-row marginal','consumer_use_site':'A3.SS2.p1.2','condition_discharge':'Fixed i lies in1..d, r=q+1; original independent Gaussian columns, no new distributional hypothesis.'},
    {'from':['gap.fixed-row-coordinate-law'],'to':'inference.row-marginal','route':'original fixed-row marginal','consumer_use_site':'A3.SS2.p1.2','condition_discharge':'Coordinate-law/product-tuple expansion is an omitted standard-law bridge, openly retained.'},
    {'from':['inference.row-marginal','source.radius-cutoff'],'to':'gap.exp-moment-calculation','route':'single-row exponential moment','consumer_use_site':'A3.SS2.p10.m3','condition_discharge':'Squared Euclidean norm and finite Gaussian exponential moment at1/3; integral calculation is omitted in source.'},
    {'from':['gap.exp-moment-calculation'],'to':'source.exp-moment','route':'single-row exponential moment','consumer_use_site':'A3.SS2.p10.m3','condition_discharge':'Canonical marginal integral is transported to the original row law; no joint-row condition.'},
    {'from':['source.exp-moment','source.markov','source.log-constant'],'to':'source.single-row-tail','route':'Markov exponential tail','consumer_use_site':'A3.Ex104.m1','condition_discharge':'x>=0; r=q+1>=1; exp threshold positive and row exponential nonnegative.'},
    {'from':['source.single-row-tail','source.radius-cutoff','source.dimension'],'to':'inference.original-cutoff-tail','route':'source cutoff substitution','consumer_use_site':'A3.SS2.p10.2 through A3.SS2.p10.3','condition_discharge':'x=log(1000d)>=0 because integer d>=2; exp(-log(1000d))=1/(1000d).'},
    {'from':['inference.original-cutoff-tail','source.row'],'to':'inference.any-bad-row','route':'finite union bound','consumer_use_site':'A3.SS2.p10.3','condition_discharge':'There are exactly d rows, each bad event is measurable in the original experiment. No row-independence premise.'},
    {'from':['inference.any-bad-row'],'to':'source.good-event','route':'event complement','consumer_use_site':'A3.Ex105.m1 and A3.SS2.p10.3','condition_discharge':'Complement of all R_i<=L is some R_i>L; strict/non-strict endpoints match exactly, so no atom-free assumption is needed.'},
    {'from':['source.good-event'],'to':'context.actual-later-use','route':'downstream event consumer context only','consumer_use_site':'A3.SS2.p17.1 and A3.SS2.p17.2','condition_discharge':'Source conditions on T for equality of original and truncated sums. No matrix proof or concentration result is claimed.'}
]
write_json('raw_source_graph.json',{
    'phase':'RAW_SOURCE_FROZEN_BEFORE_TYPES',
    'source_path':str(SOURCE),'source_sha256':EXPECTED,
    'intended_boundary':'Original-row marginal laws sufficient for original-experiment probability of any row exceeding L; preferred printed consumer is P(T)>=0.999.',
    'nodes':nodes,'edges':edges,
    'alternative_routes':[],
    'excluded_false_dependency':'No edge from context.joint-row-law to the finite-union estimate; it is not required. No edge from matrix/centered/concentration/main/oracle/cost claims to this marginal-law producer.',
    'review_boundary':'Raw extraction, not self-approval of source topology, independent review, a sealed interface, or proof credit.'
})

instructions=[
    'AGENTS.md','docs/proof-digestion-protocol.md',
    'docs/theorem-publication-protocol.md','docs/evidence-routed-memory-protocol.md',
    '.agents/skills/astis-source-dependency-audit/SKILL.md',
    '.agents/skills/astis-semantic-roundtrip/SKILL.md'
]
write_json('access_manifest.json',{
    'role':'Independent raw-source graph reader rl_sg_6a90; root is sole mathematical prover.',
    'owned_directory':str(OUT),
    'source':{'path':str(SOURCE),'bytes':len(raw),'chars':len(p.source),'sha256':EXPECTED},
    'instruction_reads':[{'path':x,'sha256':hashlib.sha256(Path(x).read_bytes()).hexdigest()} for x in instructions],
    'source_content_reads':{
        'primary':'C.2 heading through p11, all prose/formulas/fact statements in that interval.',
        'standing_context':context_ids,
        'additional_read':'Section2 notation and conventions paragraphs were read to locate d integer and query-budget conventions; S2.p2 and TV paragraph are unused excluded background. A source-ID/line listing within Section4 and C.2 was used only to select bounded anchors.',
        'raw_exact_line_reads':[[3314,3363],[3515,3570]],
        'text_only_search':'A broad rg text search against the single pinned HTML for C.2/1000/gamma/standard Gaussian/standard normal/SS2 produced truncated source lines; these are source text only. Subsequent extraction used bounded anchors.'
    },
    'filename_only_exposure_disclosure':'Initial rg --files for AGENTS/SKILL unintentionally listed prior audit filenames (names only, no contents opened); all subsequent reads are exact mandatory instructions and pinned source only.',
    'filename_only_exposure_scope':'The initial listing searched .agents, ASTIS-GC/.agents and ASTIS-GC for AGENTS.md and *SKILL.md. Its output included repository skill filenames and prior semantic-evidence instruction-copy filenames. None of those prior audit files was opened or used as source evidence.',
    'prohibited_content_not_read':['previous SAU implementation code','Lean lessons','previous audits/verdicts/decoder packets','current source-V reports','ledger','ATLAS'],
    'no_actions':['no subagents','no canonical or global writes','no commits','no permission grants','no Lean/API searches or types','no mathematical implementation or completion claims'],
    'tool_note':'bs4 was unavailable. A local stdlib HTMLParser extraction utility was written only in the owned directory; no package installation or network access occurred.',
    'freeze_order':'Interpretation, graph, coverage and manifest are frozen in this raw source phase before any type/interface proposal. All future changes must be successor artifacts and must not silently overwrite this raw interpretation.'
})

print(json.dumps({
    'source_bytes':len(raw),'source_sha256':EXPECTED,
    'scope_bytes':len(fragment),'scope_sha256':hashlib.sha256(fragment).hexdigest(),
    'scope_chars':[start,end],'scope_lines':[3314,3569],
    'locator_count':len(locators),'atoms':len(atoms),
    'math_count':coverage['exhaustiveness_check']['math_count'],
    'paragraph_count':coverage['exhaustiveness_check']['paragraph_count'],
    'display_container_count':coverage['exhaustiveness_check']['display_container_count']
},indent=2))
