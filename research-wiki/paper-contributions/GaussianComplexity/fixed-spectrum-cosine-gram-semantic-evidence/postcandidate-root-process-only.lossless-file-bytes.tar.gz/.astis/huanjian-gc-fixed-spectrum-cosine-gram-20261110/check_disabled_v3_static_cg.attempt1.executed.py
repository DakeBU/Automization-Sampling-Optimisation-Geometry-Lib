"""Prospective isolated use of unchanged disabled renderer proposal; no adoption."""
from pathlib import Path
import hashlib, html, importlib.util, json, sys
from bs4 import BeautifulSoup
sys.dont_write_bytecode = True
sys.path[:0] = ['website/scripts', 'tools']
sha = lambda b: hashlib.sha256(b).hexdigest()
R = Path.cwd()
W = Path(__file__).parent
D = W/'disabled-v3-cosine-gram-static'
assert not D.exists()
D.mkdir()
production = Path('website/scripts/declaration_lessons.py')
production_before = production.read_bytes()
assert sha(production_before) == 'b22394faeb8de07109826174d05856f4a561b20f9301e1f1d031b466fd6f2596'
q = Path('.astis/huanjian-gc-zero-query-20261110/reader-neighbor-proposal-v3/proposed/website/scripts/declaration_lessons.py')
assert sha(q.read_bytes()) == '64b8768e27da03eebb93d0a5ef77a2b47481bb1f50d4a90fae32b92c94d2e05a'
spec = importlib.util.spec_from_file_location('isolated_disabled_v3_cg', q)
dl = importlib.util.module_from_spec(spec)
spec.loader.exec_module(dl)
dl.ROOT = R
dl.CONTENT = R/'website/content/declaration_lessons'
lesson = Path('website/content/declaration_lessons/huanjian-fixed-spectrum-cosine-gram.json')
lesson_before = lesson.read_bytes()
u = json.loads(lesson_before)['units'][0]
T = Path('Tests/GaussianComplexityFixedSpectrumCosineGram.lean')
tb = T.read_bytes()
assert len(tb) == 7494 and u['steps'][-1]['lean'].encode() == tb
page = dl.lesson_path(u['declaration'])
fragment = dl.render_unit(u, page)
(D/'prospective-lesson-fragment.html').write_text(fragment)
soup = BeautifulSoup(fragment, 'html.parser')
assert not soup.select('details[open]')
folds = [s.parent for s in soup.find_all('summary') if s.get_text(strip=True) == 'Corresponding Lean step']
assert len(folds) == 6
for fold, step in zip(folds, u['steps']):
    assert step['lean'] in fold.get_text()
own = folds[-1]
assert tb.decode() in own.get_text()
actions = own.find('p', class_='lean-source-actions')
assert actions is not None
links = {a.get_text(strip=True): a for a in actions.find_all('a')}
assert set(links) == {'Exact source context', 'Download exact Lean source'}
assert links['Exact source context']['href'].endswith('Tests/GaussianComplexityFixedSpectrumCosineGram.lean.html#L13')
assert links['Download exact Lean source'].has_attr('download')
out = D/'export'
out.mkdir()
dl.export_sources(out, [u])
raw = out/'data/lesson-sources'/T
source = raw.with_suffix('.lean.html')
assert raw.read_bytes() == tb
context = BeautifulSoup(source.read_text(), 'html.parser')
assert context.find(id='L13') is not None
download = context.find('a', attrs={'download': True})
assert download and download['href'] == T.name
assert (source.parent/download['href']).read_bytes() == tb
assert production.read_bytes() == production_before
assert lesson.read_bytes() == lesson_before and T.read_bytes() == tb
record = {
    'scope': 'DISABLED prospective static test on the actual cosine-gram lesson. No production adoption, independent acceptance, browser/pixel/MathJax/desktop/mobile/site/source-index/graph or existing reader-HOLD release.',
    'production_sha256': sha(production_before), 'proposed_renderer_sha256': sha(q.read_bytes()),
    'lesson_sha256': sha(lesson_before), 'Test_sha256': sha(tb),
    'six_literal_initially_closed_Lean_folds': True,
    'full_Test_step6_bytes': len(tb), 'Test_statement_line': 13,
    'prospective_private_Test_adjacent_actions': {k: v['href'] for k, v in links.items()},
    'prospective_exported_Test_HTML_download_exact': True,
    'global_reader_HOLD_still_pending_owner_and_real_acceptance': True,
}
(D/'actual-prospective-static-check.json').write_text(json.dumps(record, ensure_ascii=False, indent=2)+'\n')
print(json.dumps(record))
