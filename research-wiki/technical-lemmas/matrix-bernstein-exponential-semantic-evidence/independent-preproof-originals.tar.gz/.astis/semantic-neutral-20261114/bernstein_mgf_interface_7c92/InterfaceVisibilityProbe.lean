import Tests.GaussianComplexityFixedSpectrumSourceMatrixRadius
import Tests.GaussianComplexityFixedSpectrumSourceMatrixStructure
import AutoSamplingTheory.TechnicalLemmas.Probability.RealMatrixPositiveIntegral

open scoped Matrix.Norms.L2Operator

-- Types only. No theorem, proof term, proof-value query, or proof-DAG query.
#check AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumSourceMatrixMean.actual_source_truncated_matrix_means
#check AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumSourceMatrixRadius.actual_source_truncated_matrix_norm_bounds
#check AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumSourceMatrixStructure.actual_source_centered_matrix_structure
#check AutoSamplingTheory.TechnicalLemmas.Probability.RealMatrixPositiveIntegral.integral_posSemidef

-- Ordinary-import access by source name and by the first private declaration's
-- exact module-mangled name. Both failures are retained in the receipt.
#check AutoSamplingTheory.Tests.GaussianComplexityFixedSpectrumSourceMatrixRadius.actual_source_centered_summand_radius
#check _private.Tests.GaussianComplexityFixedSpectrumSourceMatrixRadius.0.AutoSamplingTheory.Tests.GaussianComplexityFixedSpectrumSourceMatrixRadius.actual_source_centered_summand_radius
#check AutoSamplingTheory.Tests.GaussianComplexityFixedSpectrumSourceMatrixStructure.actual_source_weighted_centered_matrix_structure
#check _private.Tests.GaussianComplexityFixedSpectrumSourceMatrixStructure.0.AutoSamplingTheory.Tests.GaussianComplexityFixedSpectrumSourceMatrixStructure.actual_source_weighted_centered_matrix_structure

section
variable {ι : Type} [Fintype ι] [DecidableEq ι] [Nonempty ι]
#synth Algebra ℚ (Matrix ι ι ℝ)
#synth NormedRing (Matrix ι ι ℝ)
#synth CompleteSpace (Matrix ι ι ℝ)
end
