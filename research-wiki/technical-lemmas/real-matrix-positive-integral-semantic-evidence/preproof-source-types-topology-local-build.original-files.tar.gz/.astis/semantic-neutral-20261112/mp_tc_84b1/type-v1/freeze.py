from pathlib import Path
import datetime
import hashlib
import json

ROOT = Path('/Users/zhouhuanjian/ASTIS-GC')
OWN = ROOT/'.astis/semantic-neutral-20261112/mp_tc_84b1'
DEST = OWN/'type-v1'
PACKET = ROOT/'.astis/huanjian-real-matrix-positive-integral-20261112/selective-type-definition-packet.json'

def sha(b):
    return hashlib.sha256(b).hexdigest()

def digest(path):
    b = path.read_bytes()
    return {'path':str(path.relative_to(ROOT)), 'bytes':len(b), 'sha256':sha(b)}

def write(name,obj):
    (DEST/name).write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n')

assert digest(PACKET)['sha256'] == 'd2d9493c6fd09222fbe183fcb296bd0c104328a462a03f28b7c9930caa9b9e95'
p = json.loads(PACKET.read_text())
assert p['statement_seal_sha256'] == 'a5179ed392ef8e55ab470a3a98ebd542e35301f51472e9cdd7bc168a88bafa26'
assert p['minimal_definition_context_sha256'] == 'f43d358af135d42c8585f927f7e20b2b3363af2bf28eed98298f2996a2f8e591'
assert sha(p['producer']['signature'].encode()) == p['producer']['signature_sha256'] == '283e07e3c85b9a5cce5c3c40f574f23f593dfcca5e35be4d3e2800f378208b19'
assert sha(p['actual_consumer']['signature'].encode()) == p['actual_consumer']['signature_sha256'] == 'd5ac54443c79ea7b35b09ddcd6b5e3c40bef081bbe4f196cae5ab3ead35aa2ea'
assert p['consumer_existing_exact_seal']['sha256'] == '5f905cafe6035238cebdedd4f841e87b703e741b4c8aa204471d89e4c07e8a14'
c = p['minimal_definition_context']
assert sha(c['literal_current_prints_and_instances'].encode()) == c['literal_current_prints_sha256']
assert len(c['literal_definition_excerpts']) == 8
assert all(sha(a['literal_source'].encode()) == a['literal_source_sha256'] for a in c['literal_definition_excerpts'])
raw = (ROOT/p['source']['raw']).read_bytes()
assert sha(raw) == p['source']['raw_sha256'] == '6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
assert len(p['source']['anchors']) == 4
for a in p['source']['anchors']:
    assert sha(raw[a['raw_utf8_start']:a['raw_utf8_end']]) == a['span_sha256']
    assert raw.decode()[a['char_start']:a['char_end']].encode() == raw[a['raw_utf8_start']:a['raw_utf8_end']]

old_roots = {
    '.astis/semantic-neutral-20261112/ri_tc_24a6':[
        'SHA256SUMS','TYPE-SHA256SUMS','GRAPH-SHA256SUMS-v1','conceptual-v1/SHA256SUMS'],
    '.astis/semantic-neutral-20261112/mm_tc_7f32':[
        'SHA256SUMS','type-v1/SHA256SUMS','topology-v1/SHA256SUMS','conceptual-v1/SHA256SUMS'],
    '.astis/semantic-neutral-20261112/mv_tc_93d1':[
        'SHA256SUMS','type-v1/SHA256SUMS','topology-v1/SHA256SUMS'],
}
preserved = {}
for label,sums in old_roots.items():
    records = []
    for rel in sums:
        manifest = ROOT/label/rel
        for line in manifest.read_text().splitlines():
            expected,name = line.split('  ',1)
            assert digest(manifest.parent/name)['sha256'] == expected
            records.append(digest(manifest.parent/name))
        records.append(digest(manifest))
    preserved[label] = list({a['path']:a for a in records}.values())
baseline = ROOT/'.astis/semantic-neutral-20261112/mv_tc_93d1/raw-freeze.json'
assert digest(baseline)['sha256'] == 'c0bf670eba58674aac8b29d8fd313428955e76f13c20680ae47c84f1f4b536db'
write('input-manifest.json',{
    'packet':digest(PACKET),'assignment':digest(DEST/'assignment.txt'),
    'authored_classification':p['classification'],
    'new_shared_seal_sha256_as_named':p['statement_seal_sha256'],
    'new_context_sha256_as_named':p['minimal_definition_context_sha256'],
    'producer_signature_sha256_recomputed':p['producer']['signature_sha256'],
    'unchanged_R9_consumer_signature_sha256_recomputed':p['actual_consumer']['signature_sha256'],
    'consumer_existing_source_seal_reference_not_opened':p['consumer_existing_exact_seal'],
    'literal_print_sha256_recomputed':c['literal_current_prints_sha256'],
    'all_eight_embedded_excerpt_hashes_match':True,'all_four_raw_source_span_hashes_and_char_byte_maps_match':True,
    'prior_application_source_baseline':digest(baseline),
    'baseline_limit':'Prior independent raw reading of the concrete p14 application, not a printed arbitrary-f background theorem.',
    'fixed_external_Analysis_Convex_Integral_source_read':False,
    'old_records_preserved_by_checksum_metadata_and_byte_hash_only':preserved,
    'SG_new_target_old_root_proof_API_or_other_review_inputs':[],
})
names = ['assignment.txt','audit.md','exposure.json','freeze.py','input-manifest.json']
freeze = {
    'version':1,'kind':'independent-authored-shared-background-type-source-meaning-audit',
    'actor':'/root/row_indep_topology_24a6','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'finding':'NO_TYPE_BINDER_OR_SOURCE_ATTRIBUTION_ISSUE_FOUND_RELATIVE_TO_AUTHORED_BACKGROUND_CONTRACT',
    'genuine_type_or_source_blockers':[],
    'classification':'ASTIS_AUTHORED_SHARED_BACKGROUND_NOT_PRINTED_GENERAL_PAPER_THEOREM',
    'packet':digest(PACKET),'shared_seal_sha256':p['statement_seal_sha256'],
    'context_sha256':p['minimal_definition_context_sha256'],
    'producer_signature_sha256':p['producer']['signature_sha256'],
    'actual_unchanged_R9_consumer_signature_sha256':p['actual_consumer']['signature_sha256'],
    'actual_R9_consumer_seal_sha256':p['consumer_existing_exact_seal']['sha256'],
    'semantic_checks':{
        'generic_hf_hpos_are_explicit_authored_background_hypotheses':True,
        'generic_inputs_not_added_to_concrete_Gaussian_binders':True,
        'AE_full_Hermitian_quadratic_PSD_not_pointwise_or_entrywise':True,
        'empty_finite_index_not_excluded':True,
        'L2Operator_meaning_declared_with_standard_norm_definitions':True,
        'generic_n_elaboration_or_empty_case_proof_independently_run':False,
        'closed_convex_cone_facts_are_internal_not_public_assumptions':True,
    },
    'local_records':[digest(DEST/name) for name in names],
    'prior_R9_raw_application_baseline':digest(baseline),
    'old_R7_R8_R9_originals_preserved':True,
    'preservation_counts':{label:len(records) for label,records in preserved.items()},
    'remaining_internal_boundaries':[
        'AE/representative and full Hermitian/quadratic positivity under actual Bochner integral.',
        'PSD-cone semantics, closedness, convexity, zero membership/nonemptiness and norm/topology compatibility if that proof route is chosen.',
        'Empty matrix-index handling without adding Nonempty n if a chosen API needs it.',
        'Exact generic norm/completeness/elaboration and any external integral theorem applicability after its fixed source is actually read.',
        'Each concrete Gaussian residual/square integrability and AE PSD obligation supplied internally; all original Gaussian moment/frame/variance work remains open.',
    ],
    'new_SG_background_graph_seen':False,'new_or_old_root_proof_implementation_API_seen':False,
    'proof_API_search_or_Lean_attempts':0,
    'topology_API_application_compiled_edge_source_VERIFIED_normal_V_or_permission_grant':False,
    'next_boundary':'Wait for separately authorized shared-background source graph and challenge attribution, coverage and internal applicability; no graph selection or proof has begun.',
}
write('freeze.json',freeze)
records = [digest(DEST/name) for name in names]+[digest(DEST/'freeze.json')]
(DEST/'SHA256SUMS').write_text(''.join(f"{a['sha256']}  {Path(a['path']).name}\n" for a in records))
print(json.dumps({'freeze':digest(DEST/'freeze.json'),'audit':digest(DEST/'audit.md'),
                  'exposure':digest(DEST/'exposure.json'),'input_manifest':digest(DEST/'input-manifest.json'),
                  'finding':freeze['finding'],'old_artifact_preservation_counts':freeze['preservation_counts']},indent=2))
