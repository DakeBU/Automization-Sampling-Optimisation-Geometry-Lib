# Weighted matrix MGF independent native expectation freeze

Preparation only. Actor `/root/gaussian_push_audit_c7b1` is assigned the
`weighted_mgf_native_8c2d` independent native/reader role. ROOT remains the sole
proof worker; a different fresh actor owns source review. This actor is neither
the blind decoder nor the source reviewer and cannot issue independent VERIFIED.

Base is `107eb7d0b519bc77c96e0a9d5ff7df24854bb80b`. Only the sealed signatures,
protocols, environment metadata and existing R13 checking infrastructure have
been read. New P/T proof bodies, ROOT proof logs, authored lessons, decoder output,
source-fidelity verdicts and peer target build outcomes have not been consumed.

The exact seal is `.astis/huanjian-gc-weighted-mgf-20261114/statement-seal.sealed.v1.json`.
Public P signature digest is
`be468f1df7abfd7159c2188857dc22ea3bbcdc3d40bcf8932d8826e425cd94de`.
Private T signature digest is
`dbdb0f08d11e6ad281af71d13b1abb1953013bd422867306e8e44e3bc1ea7c9e`.
An exact owned seal copy and its whole-file digest are recorded by preparation.

## Fixed mathematical checks after admission

P is the finite nonempty real matrix, probability-measure expectation MGF step
`MatrixBernsteinMgf.centered_bounded_matrix_mgf`, with exactly its explicit
AEStronglyMeasurable/integrable-X/integrable-X-squared standing inputs,
almost-sure Hermitian and one-sided `I-X` PSD cap, true mean zero, and every
positive real s. No lower spectral bound, two-sided norm cap, supplied MGF,
extra covariance certificate, fixed matrix size or bound on s may be added.
The integral and exponential use the actual matrix algebra and L2 operator
norm topology. Integrability of exp(sX) and any PSD expectation/exponential
adapter must be proved internally, without nonintegrable-integral default-zero
reasoning or entrywise-exponential substitution.

T is the actual cosine-weighted original Gaussian specialization in
`Tests/GaussianComplexityBernsteinWeightedMgf.lean`, with sole source condition
`2*q+1<d`, including q=0. Its original product Gaussian measure, inclusive
own-row cutoff, Kronecker Y, unconditional actual mean, centered Z, exact rho,
and signed weight `cos((2*q+1)*theta_i)` remain literally those sealed.
`X_i=rho^-1*(w_i*Z_i)` must not be replaced by the old unweighted normalized
summand, a conditional good-event law, absolute weights, or replacement means.
All actual centering, measurability/integrability, rho positivity, weighted
cap, PSD and exponential adapters are internal. Each positive s and each row
remain universal. Check the full literal P/T proof applications and q=0
universally in valid d, plus d=2,q=0 with arbitrary positive s and actual row.

## Fresh native evidence

Do not execute before explicit source-topology admission plus ROOT's complete
immutable candidate commit and P/T hashes. Freeze candidate commit separately
from contemporaneous observed repository HEAD; never label the latter a build
HEAD if it was not what the command compiled.

Archive the exact candidate ASTIS import closure after deriving it from imports.
Do not assume an earlier module count. Start fresh owned ASTIS output empty and
exclude root ASTIS caches and all old R13 ASTIS outputs from LEAN_PATH. Use Lean
4.33.0 and exactly the nine pinned manifest package revisions. Read-only reuse
of R13's clean upstream-package artifacts is only an optional later efficiency
choice after independent full byte revalidation and explicit frozen roots;
this preparation does not accept reuse, copy caches, or compile packages.

Rebuild P, T and every actual project import parent in dependency order. Capture
unmodified separate stdout/stderr, argv, cwd, full explicit environment, times,
exit codes and hashes. Kernel checks run with skipKernelTC=false. Preserve
complete per-module emissions, first-owner and emitter identities, all private,
generated, auxiliary and out-of-namespace declarations. Export lossless complete
closed type/value expression DAGs, structurally roundtrip them, kernel-check
all applicable emitted declarations and literal P/T application values, and
inventory transitive axioms allowing only propext/Classical.choice/Quot.sound.

Derive real ASTIS parents from actual constant-node paths in type/value DAGs,
following owned private supports and stopping at public canonical parents.
Imports alone, module counts, a dependency title, or intended reuse are not
evidence of an actual theorem call. Check material use of P by weighted T and
of the unchanged canonical deterministic bound by P if present in actual proof.

## Later reader and export boundary

Only after a separate exact reader assignment, use an isolated owned overlay
and actual desktop1440x1000/mobile390x844 inspection. Check default closed
disclosures, formulas, corresponding exact full P/T code, Unicode source,
copy/download bytes, source index and correct graph direction/status. Complete
private T belongs beside its own explanation. Preserve original failures and
successor evidence separately. Do not edit global CSS, renderer, Registry,
root imports or shared site; do not reinterpret old R13 observations as new ones.

Portable selection includes only exact necessary source/scripts/raw native
outputs/reader artifacts, once. Full index/foreign states/whole guards and
package caches stay local; old R13 P/T bytes remain unchanged. No normal API,
ledger/frontier writes, main integration, new public push, source VERIFIED,
purification, full C6/Lemma4.4/main bounds or whole-Goal completion is authorized.

Stop after this preparation. Admission, immutable code, execution and browser
evidence remain pending.
