from pathlib import Path
import json,hashlib,re
W=Path('.astis/huanjian-gc-fixed-spectrum-signal-strength-20261110')
E=Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-signal-strength-semantic-evidence')
P=Path('AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumSignalStrength.lean')
T=Path('Tests/GaussianComplexityFixedSpectrumSignalStrength.lean')
B=Path('AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumBias.lean')
X=Path('AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumExactMeans.lean')
V=Path('AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumVariances.lean')
G=Path('AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumModeGap.lean')
C7=Path('AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumCosineExpansion.lean')
AL=Path('AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumGridAlias.lean')
GM=Path('AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumGaussianMoments.lean')
sha=lambda b:hashlib.sha256(b).hexdigest()
dump=lambda x:(json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode()
def put(p,x):
    assert not p.exists(),p
    p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(dump(x))
def loc(p,marker):
    raw=p.read_text();idx=raw.index(marker)
    return {'file':str(p),'line':raw[:idx].count('\n')+1,'marker':marker,'full_file_sha256':sha(p.read_bytes())}
receipt=Path('.astis/huanjian-resume-20261103/20261110T021436245999Z-signal-strength-kernel-exact-sealed-types-all-owned-canonical-parents.receipt.json')
r=json.loads(receipt.read_bytes());log=Path(r['log']);raw=log.read_bytes()
assert r['exit_code']==0 and sha(raw)==r['log_sha256']
s=raw.decode();names=re.findall(r'^OWNED_DECL_TYPE ([^:]+):',s,re.M)
reachable=dict(re.findall(r'^OWNED_DECL_REACHABLE_FROM_ACTUAL_ROOT ([^:]+): (true|false)$',s,re.M))
ax={n:[x.strip() for x in text.split(',')] for n,text in re.findall(r'^OWNED_DECL_AXIOMS ([^:]+): \[([^\]]*)\]',s,re.M)}
hand=[n for n in names if '._proof_' not in n and '._simp_' not in n]
proof=[n for n in names if '._proof_' in n];simp=[n for n in names if '._simp_' in n]
assert (len(names),len(hand),len(proof),len(simp))==(13,4,2,7)
assert all(reachable[n]=='true' for n in hand+proof)
assert all(reachable[n]=='false' for n in simp)
assert set(ax)==set(names) and all(set(a)<={'propext','Classical.choice','Quot.sound'} for a in ax.values())
parents={n:[x.strip() for x in text.split(',')] for n,text in re.findall(r'^ACTUAL_PUBLIC_ASTIS_PARENTS ([^:]+): \[([^\]]*)\]',s,re.M)}
assert sorted(map(len,parents.values()))==[3,4]
put(E/'actual-kernel-owned-inventory.json',{'receipt':str(receipt),'receipt_sha256':sha(receipt.read_bytes()),'log_sha256':sha(raw),'log_bytes':len(raw),'working_HEAD_actual_execution':'beae330f07fd91f40d8402084f14630962fcf3a5','exact_sealed_kernel_types_applied':2,'owned_names':names,'handwritten':hand,'reachable_generated_proof_auxiliaries':proof,'unreachable_compiler_generated_simp_declarations':simp,'root_reachability':reachable,'axioms':ax,'actual_first_public_ASTIS_parents':parents,'producer_source_sha256':sha(P.read_bytes()),'Test_source_sha256':sha(T.read_bytes()),'no_independent_sourceV_or_global_credit':True})
graph=json.loads((E/'source-graph-v2.json').read_bytes())
closures=json.loads((E/'root-closures-v2.json').read_bytes())['roots']
membership={n['id']:[c['root'] for c in closures if n['id'] in c['node_ids']] for n in graph['nodes']}
rows=[]
for n in graph['nodes']:
    nid=n['id'];roots=membership[nid]
    state='outside-selected-roots-no-new-Lean-credit';providers=[]
    boundary='Source context remains represented; this packet emits no new implementation of this off-root statement.'
    if roots:
        if nid=='root:public-signal':
            state='new-exact-sealed-public-numerical-result';providers=[loc(P,'theorem eventual_actual_gaussian_signal_strength')]
            boundary='Exactly both actual norm lower bounds, positivity and finite signal lower inequality. No standalone Tendsto infinity or tau branch.'
        elif nid=='root:private-zero-event':
            state='new-private-NON-Anchor-actual-law-application';providers=[loc(T,'private theorem actual_gaussian_source_query_zero_event_le_tenth')]
            boundary='Zero-threshold same diagonal law only; no shifted rotated detector, Ex26, algorithmic or public Registry node.'
        elif nid=='s:M-lower':
            state='new-actual-M-endpoints-sufficient-source-route';providers=[loc(P,'private theorem spectral_tail_le_third'),loc(P,'private theorem source_norm_scale_lower'),loc(P,'  have hMformula')]
            boundary='Actual tail<=exp(-2)<=1/3 suffices for both exact selected M endpoints. Strict exp(-2)<1/3 and the full C3 log derivation are not emitted as new declarations.'
        elif nid=='s:beta-lower':
            state='actual-local-source-polynomial-bias-component';providers=[loc(P,'  have hqr'),loc(P,'  have hpoly')]
            boundary='Actual beta lower uses canonical Bias and exact3delta/128 before relaxation. Local proof fact, not an additional public canonical beta lemma.'
        elif nid=='s:signal-product':
            state='new-exact-finite-signal-inequality-component';providers=[loc(P,'  have hsquare'),loc(P,'  have hpowerproduct'),loc(P,'  have hsignalidentity')]
            boundary='Finite M beta squared lower is emitted. The source divergence wording is not separately compiled as a Tendsto theorem.'
        elif nid=='a:positive-M-beta':
            state='new-actual-positivity-outputs-with-canonical-sign-input';providers=[loc(P,'  rcases actual_diagonal_gaussian_exponential_bias'),loc(P,'  have hbne'),loc(P,'  have hβpos')]
            boundary='M and beta positivity are proved outputs; sign, integrability and actual moment semantics come from genuine canonical Gaussian results.'
        elif nid=='a:private-threshold':
            state='new-uniform-finite-zero-event-threshold';providers=[loc(T,'  obtain ⟨N, hN⟩'),loc(T,'  have hthreshold'),loc(T,'  have hsignal')]
            boundary='N>=40/B squared is chosen before varying parameters and yields20, not original tau/320 source detector assembly.'
        elif nid=='a:private-chebyshev':
            state='new-actual-signed-variable-probability-application';providers=[loc(T,'  have hX'),loc(T,'  have hmeanRatio'),loc(T,'  have hV'),loc(T,'  have hc'),loc(T,'  have hprob')]
            boundary='Actual MemLp, positive signed mean, variance and finite-ofReal handling. No independence of Q and norm or shifted-event claim.'
        elif nid in ['s:uniform-n','s:distance-domain']:
            state='source-asymptotic-intermediates-not-exact-new-emitted-outputs';providers=[loc(G,'theorem eventual_source_query_mode_gap'),loc(P,'  have hadm')]
            boundary='Reuse exact finite domain/gap endpoints through a sufficient common-envelope route. No separate exact author n=o(d), sqrt kappa=o(d) family or alpha/coarse-query declarations emitted.'
        elif nid=='a:domain':
            state='reused-exact-canonical-finite-domain-gap';providers=[loc(G,'theorem eventual_source_query_mode_gap'),loc(P,'  have hadm')]
            boundary='Every dimension/mode/gap condition is internally supplied; no free witness or certificate.'
        elif nid in ['s:scalar-regime','s:grid','s:cosine-statistic','s:generic-cosine-statistic','s:generic-moment-law','s:moment-normalization','a:literal-law']:
            state='literal-definitions-and-generic-source-to-selected-instance';providers=[loc(P,'theorem eventual_actual_gaussian_signal_strength'),loc(X,'theorem actual_diagonal_gaussian_exact_means')]
            boundary='The selected Fin/Bochner odd-frequency instance is downstream of generic source Gaussian/mean semantics. No new proof of all generic source statements or extra public premises.'
        elif nid in ['c:c7','c:geometric','c:rho-algebra','c:majorant','gap:geometric-series']:
            state='existing-canonical-series-provider-closure-not-new-credit';providers=[loc(C7,'theorem '),loc(X,'theorem actual_diagonal_gaussian_exact_means')]
            boundary='Canonical actual inverse-spectrum series and its convergence are reused through C8. Source gap labels remain source-provenance gaps, not new assumptions.'
        elif nid in ['c:grid-sum','gap:trigonometry']:
            state='existing-canonical-all-integer-grid-provider-not-new-credit';providers=[loc(AL,'theorem '),loc(X,'theorem actual_diagonal_gaussian_exact_means')]
            boundary='Same canonical all-integer alias node, not a duplicated cosine-sum lemma or a conceptual transport.'
        elif nid in ['c:trace-means','c:mean-M','c:mean-b','c:c8']:
            state='existing-actual-Gaussian-means-provider-closure-not-new-credit';providers=[loc(GM,'theorem actual_diagonal_gaussian_quadratic_means'),loc(X,'theorem actual_diagonal_gaussian_exact_means'),loc(P,'  have hclosed')]
            boundary='Actual integrability and both closed means in canonical modules on generic1<=n<d. No odd-frequency premise is imported into generic source facts.'
        elif nid in ['c:ratio','c:log-powers','c:bias']:
            state='existing-canonical-final-bias-estimates-with-intermediate-boundary';providers=[loc(B,'private theorem spectral_ratio_log_bounds'),loc(B,'private theorem spectral_ratio_power_bounds'),loc(B,'theorem actual_diagonal_gaussian_exponential_bias')]
            boundary='Actual canonical final exponential bias/sign/ratio reused. Exact source kappa-minus-one rational log upper expression and strict8/3<3 are not separately emitted new results; inherited sufficient nonstrict route remains explicit.'
        elif nid=='c:variance':
            state='existing-canonical-actual-variance-used-only-in-private-application';providers=[loc(V,'theorem actual_diagonal_gaussian_quadratic_variances'),loc(T,'  rcases actual_diagonal_gaussian_quadratic_variances')]
            boundary='Same actual covariance/finite moments/fourth-moment/independence provider, no new variance Anchor or source full Lemma4.5 assembly.'
        elif nid=='gap:gaussian-semantics':
            state='actual-canonical-Gaussian-foundation-for-selected-uses';providers=[loc(GM,'theorem actual_diagonal_gaussian_quadratic_means'),loc(X,'theorem actual_diagonal_gaussian_exact_means'),loc(V,'theorem actual_diagonal_gaussian_quadratic_variances')]
            boundary='Canonical actual covariance positivity/PSD/inverse/moments and genuine integrability support the selected uses. No free law or default zero-integral substitute; source graph gap record itself remains unchanged.'
        elif nid=='gap:log-calculus':
            state='pinned-canonical-Mathlib-log-provider-closure';providers=[loc(B,'private theorem log_remainder_integral'),loc(B,'private theorem log_integral_identities'),loc(B,'private theorem log_integral_bounds')]
            boundary='Actual already compiled FTC/log/integral providers behind Bias, not a new proof credit for the full author interpolation.'
        elif nid=='gap:power-asymptotics':
            state='actual-positive-base-identities-and-canonical-finite-cutoff-uses';providers=[loc(G,'theorem eventual_source_query_mode_gap'),loc(P,'private theorem source_norm_scale_lower'),loc(P,'  have hpowerproduct')]
            boundary='Selected guarded power algebra and finite uniform domain uses only. No blanket exact emission of every author asymptotic family.'
        elif nid=='gap:chebyshev':
            state='actual-Mathlib-Chebyshev-component-only';providers=[loc(T,'  have hc'),loc(T,'  have hprob')]
            boundary='This zero-event consumer uses variance Chebyshev only. Source shifted-variable L2 triangle/Minkowski and full Ex25/26 are not newly discharged.'
        else:
            raise AssertionError(('Unmapped selected node',nid))
    rows.append({'source_node':nid,'source_kind':n['kind'],'source_statement':n['statement'],'source_anchors':n.get('source_anchors',[]),'selected_roots':roots,'implementation_status':state,'providers':providers,'boundary':boundary})
put(E/'source-to-lean-map-v1.json',{'source_graph_sha256':sha((E/'source-graph-v2.json').read_bytes()),'rows':rows,'truth_boundary':'Source topology and compiler dependency are different. All rows are explicit scoped correspondences, not89 newly compiled statements or a formal implication hypergraph. Independent postproof correspondence review remains pending.','source_review':'pending','actual_public_parents':parents,'exact_new_public_declarations':[S['producer']['name']] if (S:=json.loads((W/'statement-seal-v1.json').read_bytes())) else []})
search={'actual_started_after_admission':'2026-11-10T02:02:32 normal EXPLORING receipt, then actual searches/proofs','Samplinglib_ASTIS_searches':[{'command':'rg exact declarations/imports in canonical ExactMeans,Bias and actual Tests','chunks':['eb8f2f','020437','c91041','e7c1d9','f9c28c','e8e53e'],'finding':'Canonical actual moments/exponential bias/mode-gap/variances reused; no new duplicate public source node.'},{'command':'rg M.*beta etc over broad technical subtree','chunk':'7d3090','finding':'Noisy generic type-variable matches; NOT evidence of semantic absence. Refined GaussianComplexity search used instead.'}],'Mathlib_searches':[{'command':'rg selected rpow/sqrt/exp APIs in pinned checkout','chunks':['3b90df','bc51d9','2f147d','9194ce','33dea1'],'finding':'Canonical Real.rpow_mul/add/mul_natCast/sqrt_eq_rpow,Real.add_one_le_exp/exp_nat_mul and exists_nat_ge reused. Initial guessed Exp directory absent; corrected exact provider is Analysis/Complex/Exponential.lean. Path mismatch is not a missing-API or mathematical obstruction.'}],'manifest_sha256':'b83ca83b9cf7caa85fa8b023c2ff9a3fb7a7cce7e1c332e810c348535ec49c37','mathlib_commit':'db584cd6d46c92f209a44c0f1c829460d327499d','classification':'adapt_existing','semantic_absence_claim':False,'formal_transport_or_new_conceptual_bridge_claim':False}
put(E/'actual-shared-floor-reuse-search-audit.json',search)
print(json.dumps({'owned':len(names),'handwritten':len(hand),'reachable_generated_proof':len(proof),'unreachable_compiler_simp':len(simp),'mapped_source_nodes':len(rows),'selected_nodes':sum(bool(r['selected_roots']) for r in rows),'sourceV':False}))
