from pathlib import Path
import datetime
import hashlib
import json
import runpy
import sys

ROOT = Path('/Users/zhouhuanjian/ASTIS-GC')
OWN = ROOT/'.astis/semantic-neutral-20261112/mv_tc_93d1'
SOURCE = ROOT/'.astis/huanjian-resume-20261103/2610.20492v1.html'

def sha(b):
    return hashlib.sha256(b).hexdigest()

def digest(path):
    b = path.read_bytes()
    return {'path':str(path.relative_to(ROOT)), 'bytes':len(b), 'sha256':sha(b)}

def write(name,obj):
    (OWN/name).write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n')

assert digest(SOURCE)['sha256'] == '6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
assert digest(SOURCE)['bytes'] == 951991
prior_roots = {
    '.astis/semantic-neutral-20261112/ri_tc_24a6':[
        'SHA256SUMS','TYPE-SHA256SUMS','GRAPH-SHA256SUMS-v1','conceptual-v1/SHA256SUMS'],
    '.astis/semantic-neutral-20261112/mm_tc_7f32':[
        'SHA256SUMS','type-v1/SHA256SUMS','topology-v1/SHA256SUMS','conceptual-v1/SHA256SUMS'],
}
preserved = {}
for rootrel,manifests in prior_roots.items():
    records = []
    for rel in manifests:
        manifest = ROOT/rootrel/rel
        for line in manifest.read_text().splitlines():
            expected,name = line.split('  ',1)
            target = manifest.parent/name
            assert digest(target)['sha256'] == expected,str(target)
            records.append(digest(target))
        records.append(digest(manifest))
    preserved[rootrel] = list({a['path']:a for a in records}.values())
assert len(preserved['.astis/semantic-neutral-20261112/ri_tc_24a6']) == 32
assert len(preserved['.astis/semantic-neutral-20261112/mm_tc_7f32']) == 38

sys.argv = [str(OWN/'read_raw.py'),'silent']
reader = runpy.run_path(str(OWN/'read_raw.py'))
by_id = reader['by_id']
read_ids = ['S4.E11','S4.Thmtheorem4.p1.1'] + [f'A3.SS2.p{n}' for n in range(1,16)] + ['A3.Thmtheorem5','A3.Thmtheorem6']
keys = [
    'S4.E11.m1','A3.SS2.p1.1','A3.Ex85','A3.SS2.p1.2','A3.Ex87',
    'A3.SS2.p5','A3.SS2.p8','A3.SS2.p10.m1','A3.SS2.p10.m2','A3.Ex107',
    'A3.SS2.p12.4','A3.SS2.p13.1','A3.Ex111','A3.Ex112','A3.SS2.p13.3',
    'A3.SS2.p14.1','A3.Ex113','A3.SS2.p14.2','A3.Ex114','A3.SS2.p14.3',
    'A3.EGx11','A3.Ex115','A3.Ex116','A3.Ex117','A3.SS2.p14.4',
    'A3.Ex118','A3.SS2.p14.5','A3.Ex119','A3.SS2.p14.6','A3.Ex120',
    'A3.SS2.p15.1','A3.Ex121','A3.SS2.p15.2',
]
locators = {ident:by_id[ident].locator() for ident in dict.fromkeys(read_ids+keys)}
raw = SOURCE.read_bytes()
for ident,loc in locators.items():
    assert sha(raw[loc['utf8_byte_start']:loc['utf8_byte_end_exclusive']]) == loc['raw_fragment_sha256']
write('locators.json',{
    'kind':'preliminary-raw-evidence-locators-not-accepted-types-or-topology',
    'source':digest(SOURCE),
    'convention':'Half-open zero-based UTF-8 byte and Unicode-codepoint spans; inclusive one-based LF lines; raw hashes cover unnormalized source.',
    'full_elements_freshly_read':read_ids,'principal_elements':keys,'locators':locators,
    'locator_correction':{'Z_definition':'A3.SS2.p13.1','fourth_and_square_and_variance_comparisons':'A3.SS2.p14',
                          'Bernstein_context_only':'A3.SS2.p15'},
})
protocol_paths = [
    'AGENTS.md','CONTRIBUTING.md','.agents/prompts/collaborator-contribution.md',
    'docs/contributor-codex-contract.md','docs/theorem-publication-protocol.md',
    'docs/proof-digestion-protocol.md','docs/evidence-routed-memory-protocol.md',
    '.agents/skills/astis-substantive-advance/SKILL.md','LICENSE_SCOPE.md',
]
protocols = [digest(ROOT/name) for name in protocol_paths]
write('input-manifest.json',{
    'source':digest(SOURCE),'assignment':digest(OWN/'assignment.txt'),
    'assignment_note':'Normalized task transcript and English rendering of the root clarification, including original p15 scope wording; not transport-byte hashes.',
    'protocols_previously_read_in_same_session_current_hash_snapshot':protocols,
    'protocol_manifest_sha256':sha(json.dumps(protocols,sort_keys=True,separators=(',',':')).encode()),
    'prior_R7_R8_preserved_by_checksum_manifests':preserved,
    'prior_record_access_note':'Manifest filenames/checksums and byte hashes only; no prior substantive review/proof/graph text reopened.',
    'new_target_type_seal_graph_API_implementation_inputs':[],
})
names = ['assignment.txt','read_raw.py','raw-reading.md','exposure.json','freeze.py','locators.json','input-manifest.json']
freeze = {
    'version':1,'kind':'prospective-actual-matrix-variance-independent-RAW-source-freeze',
    'actor':'/root/row_indep_topology_24a6','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'source':digest(SOURCE),'owned_root':str(OWN.relative_to(ROOT)),
    'proposed_scope':'Actual original-column Y_i^2 integrability and uncentered PSD second-moment sum bound; actual centered/cosine-weighted variance bounds with internal integrability/centering/PSD/operator-norm bridges.',
    'no_chosen_exact_type_or_endpoint_admitted':True,
    'new_exact_seal_types_binder_definition_packet_seen':False,
    'new_source_graph_or_SG_notes_seen':False,
    'new_target_API_implementation_other_review_seen':False,
    'source_pristine_claim':False,'claim_about_global_seal_creation_timing':False,
    'source_locator_correction':'Z is defined at p13; Ex113/114 and centered/cos-squared variance comparisons are p14; p15 is Bernstein and outside the proposed variance target.',
    'local_records':[digest(OWN/name) for name in names],
    'prior_R7_R8_originals_preserved':True,
    'preservation_counts':{name:len(records) for name,records in preserved.items()},
    'mathematical_proof_API_search_or_Lean_attempts':0,
    'type_topology_applicability_status_or_permission_grant':False,
    'tracked_C_L_registry_source_Git_or_shared_mutation':False,
    'stop_boundary':'Await a separate exact new seal and binder/definition packet. Later distinct source-topology challenge must follow this actor independent new type freeze; no second formal graph extraction or proof work is begun.',
}
write('raw-freeze.json',freeze)
records = [digest(OWN/name) for name in names]+[digest(OWN/'raw-freeze.json')]
(OWN/'SHA256SUMS').write_text(''.join(f"{a['sha256']}  {Path(a['path']).name}\n" for a in records))
print(json.dumps({'raw_freeze':digest(OWN/'raw-freeze.json'),'raw_reading':digest(OWN/'raw-reading.md'),
                  'exposure':digest(OWN/'exposure.json'),'locators':digest(OWN/'locators.json'),
                  'input_manifest':digest(OWN/'input-manifest.json'),
                  'R7_R8_artifacts_preserved':freeze['preservation_counts']},indent=2))
