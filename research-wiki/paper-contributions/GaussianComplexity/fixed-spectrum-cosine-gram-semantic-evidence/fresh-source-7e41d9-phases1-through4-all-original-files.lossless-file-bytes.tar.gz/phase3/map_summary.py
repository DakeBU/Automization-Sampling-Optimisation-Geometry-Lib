#!/opt/anaconda3/bin/python
import json,pathlib,sys
BASE=pathlib.Path(__file__).resolve().parent
obj=json.loads((BASE/'inputs/research-wiki__paper-contributions__GaussianComplexity__fixed-spectrum-cosine-gram-semantic-evidence__source-to-lean-map-v1.json').read_text())
if sys.argv[1]=='nodes':
  for key in ['boundary','source_lineage','whole_file_inputs','root_declarations','canonical_rows','correspondence_slices','source_route_differences','context_only_links','unclosed_source_boundary']:
    print(key,json.dumps(obj[key],ensure_ascii=False,indent=2))
elif sys.argv[1]=='locators':
  for row in obj['locator_slices']:
    print(json.dumps({k:v for k,v in row.items() if k!='literalLF'},ensure_ascii=False))
