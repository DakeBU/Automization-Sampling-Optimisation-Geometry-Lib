from pathlib import Path
import datetime, hashlib, json, subprocess, sys

ROOT = Path('/Users/zhouhuanjian/ASTIS-GC')
OUT = ROOT / '.astis/semantic-neutral-20261113/structure_sg_a94e'
OUT.mkdir(parents=True, exist_ok=True)

def capture(label, argv):
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    p = subprocess.run(argv, cwd=ROOT, capture_output=True)
    (OUT / f'{label}.stdout').write_bytes(p.stdout)
    (OUT / f'{label}.stderr').write_bytes(p.stderr)
    receipt = {'label': label, 'argv': argv, 'cwd': str(ROOT), 'started_utc': started,
               'returncode': p.returncode, 'stdout_sha256': hashlib.sha256(p.stdout).hexdigest(),
               'stderr_sha256': hashlib.sha256(p.stderr).hexdigest()}
    (OUT / f'{label}.receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    return p

if __name__ == '__main__':
    p = capture(sys.argv[1], sys.argv[2:])
    sys.stdout.buffer.write(p.stdout)
    sys.stderr.buffer.write(p.stderr)
    raise SystemExit(p.returncode)
