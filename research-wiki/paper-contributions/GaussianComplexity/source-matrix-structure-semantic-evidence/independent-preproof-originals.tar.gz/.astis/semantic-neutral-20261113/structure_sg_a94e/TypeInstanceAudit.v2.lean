import AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumSourceRowIndependence
import AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumSourceMatrixMean

noncomputable section
open MeasureTheory ProbabilityTheory
open scoped BigOperators Matrix Kronecker Matrix.Norms.L2Operator
set_option autoImplicit false
namespace StructureTypeInstanceAuditV2
variable {d q : ℕ}
abbrev J (q : ℕ) := Fin (q + 1) × Fin (q + 1)
abbrev M (q : ℕ) := Matrix (J q) (J q) ℝ

-- Existing-instance selection only; no declaration for the source target.
set_option pp.all true in
#synth TopologicalSpace (M q)
set_option pp.all true in
#synth UniformSpace (M q)
set_option pp.all true in
#synth Norm (M q)
#synth CompleteSpace (M q)
#synth FiniteDimensional ℝ (M q)
#synth IsProbabilityMeasure
  (Measure.pi (fun _ : Fin (q + 1) => stdGaussian (EuclideanSpace ℝ (Fin d))))
#check Pi.borelSpace
#check Matrix.instL2OpMetricSpace
#check Matrix.instL2OpNormedAddCommGroup

end StructureTypeInstanceAuditV2
