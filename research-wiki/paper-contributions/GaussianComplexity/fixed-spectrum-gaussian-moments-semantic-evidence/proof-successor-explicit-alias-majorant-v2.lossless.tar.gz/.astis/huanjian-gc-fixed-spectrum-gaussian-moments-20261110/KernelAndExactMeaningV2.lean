import Tests.GaussianComplexityFixedSpectrumGaussianMoments
open MeasureTheory ProbabilityTheory
open scoped BigOperators
open Lean
set_option autoImplicit false

example {d : ℕ} (hd : 2 ≤ d) {κ : ℝ} (hκ : 2 ≤ κ)
    (n : ℕ) (hn : 1 ≤ n) (hnd : n < d) :
  let θ : Fin d → ℝ := fun i => ((i.val : ℝ) + 1 / 2) * Real.pi / (d : ℝ)
  let eigenvalue : Fin d → ℝ := fun i => (κ + 1) / 2 + (κ - 1) / 2 * Real.cos (θ i)
  let Λ : Matrix (Fin d) (Fin d) ℝ := Matrix.diagonal eigenvalue
  let μ : Measure (EuclideanSpace ℝ (Fin d)) :=
    multivariateGaussian (0 : EuclideanSpace ℝ (Fin d)) Λ⁻¹
  let Q : EuclideanSpace ℝ (Fin d) → ℝ := fun x =>
    ∑ i : Fin d, Real.cos ((n : ℝ) * θ i) * (WithLp.ofLp x i) ^ 2
  Integrable (fun x : EuclideanSpace ℝ (Fin d) => ‖x‖ ^ 2) μ ∧
  Integrable Q μ ∧
  (∫ x : EuclideanSpace ℝ (Fin d), ‖x‖ ^ 2 ∂μ) = (∑ i : Fin d, (eigenvalue i)⁻¹) ∧
  (∫ x : EuclideanSpace ℝ (Fin d), Q x ∂μ) =
    ∑ i : Fin d, Real.cos ((n : ℝ) * θ i) / eigenvalue i := by
  exact AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumGaussianMoments.actual_diagonal_gaussian_quadratic_means hd hκ n hn hnd

def ExpectedPrivate : Prop := ∀ {d : ℕ} (hd : 2 ≤ d) {κ : ℝ} (hκ : 2 ≤ κ)
    (n : ℕ) (hn : 1 ≤ n) (hnd : n < d),
  let θ : Fin d → ℝ := fun i => ((i.val : ℝ) + 1 / 2) * Real.pi / (d : ℝ)
  let eigenvalue : Fin d → ℝ := fun i => (κ + 1) / 2 + (κ - 1) / 2 * Real.cos (θ i)
  let Λ : Matrix (Fin d) (Fin d) ℝ := Matrix.diagonal eigenvalue
  let μ : Measure (EuclideanSpace ℝ (Fin d)) :=
    multivariateGaussian (0 : EuclideanSpace ℝ (Fin d)) Λ⁻¹
  let Q : EuclideanSpace ℝ (Fin d) → ℝ := fun x =>
    ∑ i : Fin d, Real.cos ((n : ℝ) * θ i) * (WithLp.ofLp x i) ^ 2
  let r : ℝ := (Real.sqrt κ - 1) / (Real.sqrt κ + 1)
  let a : ℤ → ℝ := fun k =>
    if (2 * (d : ℤ)) ∣ k then (-1 : ℝ) ^ (k / (2 * (d : ℤ))) else 0
  Summable (fun j : ℕ => (-r) ^ (j + 1) *
    (a (((j + 1 : ℕ) : ℤ) - (n : ℤ)) + a (((j + 1 : ℕ) : ℤ) + (n : ℤ)))) ∧
  Integrable Q μ ∧
  (∫ x : EuclideanSpace ℝ (Fin d), Q x ∂μ) =
    ((d : ℝ) / Real.sqrt κ) * ∑' j : ℕ, (-r) ^ (j + 1) *
      (a (((j + 1 : ℕ) : ℤ) - (n : ℤ)) + a (((j + 1 : ℕ) : ℤ) + (n : ℤ)))

-- Meaning audit only: the source diagonal quadratic is the sealed coordinate Q.
-- This is not another production/Registry node or a substitute for the actual means.
example {d : ℕ} (w : Fin d → ℝ) (x : EuclideanSpace ℝ (Fin d)) :
    (WithLp.ofLp x) ⬝ᵥ (Matrix.diagonal w) *ᵥ (WithLp.ofLp x) =
      ∑ i : Fin d, w i * (WithLp.ofLp x i) ^ 2 := by
  classical
  simp only [Matrix.diagonal_mulVec, dotProduct, Pi.mul_apply]
  apply Finset.sum_congr rfl
  intro i _
  ring

run_cmd do
  let env := (← getEnv).setExporting false
  setEnv env
  let target := `AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumGaussianMoments.actual_diagonal_gaussian_quadratic_means
  let c7 := `AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumCosineExpansion.actual_inverse_spectrum_cosine_expansion
  let grid := `AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumGridAlias.actual_midpoint_grid_cosine_alias
  let wanted := env.constants.toList.filter fun (n, _) =>
    n == target || n.toString.endsWith ".actual_gaussian_cosine_alias_series"
  unless wanted.length == 2 do throwError "Expected exactly two actual packet theorem constants"
  let allowed := [`propext, `Classical.choice, `Quot.sound]
  for (n, ci) in wanted do
    match ci with
    | .thmInfo _ => pure ()
    | _ => throwError "Actual packet constant must be a theorem: {n}"
    let some proof := ci.value? true | throwError "Missing actual kernel proof term"
    let used := proof.getUsedConstants.toList
    let astis := used.filter fun k => k.toString.startsWith "AutoSamplingTheory."
    -- Raw compiler auxiliaries are printed and recursively inspected, never
    -- counted as additional public canonical producer declarations.
    let mut pending := used
    let mut seen : NameSet := {}
    let mut parents : NameSet := {}
    let mut auxiliaries : Array Name := #[]
    while !pending.isEmpty do
      let u := pending.head!
      pending := pending.tail!
      unless seen.contains u do
        seen := seen.insert u
        let localAux := u.toString.startsWith (target.toString ++ "._proof_") ||
          u.toString.startsWith (n.toString ++ "._proof_")
        if localAux then
          let some aci := env.find? u | throwError "Missing compiled auxiliary {u}"
          match aci with
          | .thmInfo _ => pure ()
          | _ => throwError "Expected theorem auxiliary, got {u}"
          let some ap := aci.value? true | throwError "Missing auxiliary proof {u}"
          let ax ← Lean.collectAxioms u
          unless ax.all (fun a => allowed.contains a) do throwError "Bad auxiliary axioms {u}: {ax}"
          auxiliaries := auxiliaries.push u
          pending := ap.getUsedConstants.toList ++ pending
          logInfo m!"ACTUAL_GENERATED_AUXILIARY {u}: {aci.type}"
          logInfo m!"ACTUAL_GENERATED_AUXILIARY_USES {u}: {ap.getUsedConstants.toList}"
          logInfo m!"ACTUAL_GENERATED_AUXILIARY_COMPLETE_PROOF_REPR {u}: {repr ap}"
          logInfo m!"ACTUAL_GENERATED_AUXILIARY_AXIOMS {u}: {ax}"
        else if u.toString.startsWith "AutoSamplingTheory." then
          parents := parents.insert u
    let publicParents := parents.toList
    if n == target then
      unless publicParents.isEmpty do throwError "Unexpected public ASTIS producer parent: {publicParents}"
    else
      unless publicParents.length == 3 && publicParents.contains target && publicParents.contains c7 && publicParents.contains grid do
        throwError "Actual Gaussian consumer must use exactly means producer, canonical C7 and GridAlias: {publicParents}"
    logInfo m!"GENERATED_AUXILIARIES_EXPANDED {n}: {auxiliaries}"
    logInfo m!"ACTUAL_PUBLIC_ASTIS_PARENTS {n}: {publicParents}"
    let axs ← Lean.collectAxioms n
    unless axs.all (fun a => allowed.contains a) do throwError "Unexpected axiom: {axs}"
    logInfo m!"ACTUAL_THEOREM_CONSTANT {n}"
    logInfo m!"ACTUAL_TYPE {n}: {ci.type}"
    logInfo m!"DIRECT_ASTIS {n}: {astis}"
    logInfo m!"DIRECT_ALL {n}: {used}"
    logInfo m!"KERNEL_AXIOMS {n}: {axs}"
    if n != target then
      Lean.Elab.Command.liftCoreM <| addDecl <| Declaration.thmDecl {
        name := Name.mkSimple "ActualPrivateSealedTypeCheck"
        levelParams := []
        type := mkConst (Name.mkSimple "ExpectedPrivate")
        value := mkConst n
      }
      logInfo "ACTUAL_PRIVATE_SEALED_LITERAL_KERNEL_TYPE_APPLICATION_PASS"

#print axioms ActualPrivateSealedTypeCheck
#print axioms AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumGaussianMoments.actual_diagonal_gaussian_quadratic_means
