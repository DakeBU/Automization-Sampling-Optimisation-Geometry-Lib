import Tests.GaussianComplexityFixedSpectrumSourceMatrixMean
open Lean MeasureTheory ProbabilityTheory
open scoped BigOperators Matrix.Norms.L2Operator
set_option autoImplicit false
noncomputable section
set_option maxRecDepth 10000
set_option maxHeartbeats 0
def IndependentLiteralP : Prop := ∀ {d q : ℕ} (hq : 2 * q + 1 < d),
  let D := EuclideanSpace ℝ (Fin d)
  let E := EuclideanSpace ℝ (Fin (q + 1))
  let Ω := Fin (q + 1) → D
  let μ : Measure Ω := Measure.pi (fun _ : Fin (q + 1) => stdGaussian D)
  let r : ℝ := ((q + 1 : ℕ) : ℝ)
  let L : ℝ := 2 * r + 3 * Real.log (1000 * (d : ℝ))
  let a : ℝ :=
    (∫ x : E, Set.indicator {y : E | ‖y‖ ^ 2 ≤ L} (fun y : E => ‖y‖ ^ 2) x
      ∂stdGaussian E) / r
  let θ : Fin d → ℝ := fun i => ((i.val : ℝ) + 1 - 1 / 2) * Real.pi / (d : ℝ)
  let t : Fin d → Fin (q + 1) → ℝ := fun i k =>
    if k.val = 0 then 1 else Real.sqrt 2 * Real.cos ((k.val : ℝ) * θ i)
  let row : Fin d → Ω → E := fun i ω =>
    WithLp.toLp 2 (fun b : Fin (q + 1) => ω b i)
  let Y : Fin d → Ω →
      Matrix (Fin (q + 1) × Fin (q + 1)) (Fin (q + 1) × Fin (q + 1)) ℝ := fun i ω =>
    if ‖row i ω‖ ^ 2 ≤ L then
      (d : ℝ)⁻¹ • Matrix.kronecker
        (Matrix.vecMulVec (WithLp.ofLp (row i ω)) (WithLp.ofLp (row i ω)))
        (Matrix.vecMulVec (t i) (t i))
    else 0
  (∀ i : Fin d, Integrable (Y i) μ) ∧
    ∀ i : Fin d, (∫ ω, Y i ω ∂μ) =
      (a / (d : ℝ)) • Matrix.kronecker
        (1 : Matrix (Fin (q + 1)) (Fin (q + 1)) ℝ) (Matrix.vecMulVec (t i) (t i))

def IndependentLiteralT : Prop := ∀ {d q : ℕ} (hq : 2 * q + 1 < d),
  let D := EuclideanSpace ℝ (Fin d)
  let E := EuclideanSpace ℝ (Fin (q + 1))
  let Ω := Fin (q + 1) → D
  let μ : Measure Ω := Measure.pi (fun _ : Fin (q + 1) => stdGaussian D)
  let r : ℝ := ((q + 1 : ℕ) : ℝ)
  let L : ℝ := 2 * r + 3 * Real.log (1000 * (d : ℝ))
  let a : ℝ :=
    (∫ x : E, Set.indicator {y : E | ‖y‖ ^ 2 ≤ L} (fun y : E => ‖y‖ ^ 2) x
      ∂stdGaussian E) / r
  let θ : Fin d → ℝ := fun i => ((i.val : ℝ) + 1 - 1 / 2) * Real.pi / (d : ℝ)
  let t : Fin d → Fin (q + 1) → ℝ := fun i k =>
    if k.val = 0 then 1 else Real.sqrt 2 * Real.cos ((k.val : ℝ) * θ i)
  let row : Fin d → Ω → E := fun i ω =>
    WithLp.toLp 2 (fun b : Fin (q + 1) => ω b i)
  let Y : Fin d → Ω →
      Matrix (Fin (q + 1) × Fin (q + 1)) (Fin (q + 1) × Fin (q + 1)) ℝ := fun i ω =>
    if ‖row i ω‖ ^ 2 ≤ L then
      (d : ℝ)⁻¹ • Matrix.kronecker
        (Matrix.vecMulVec (WithLp.ofLp (row i ω)) (WithLp.ofLp (row i ω)))
        (Matrix.vecMulVec (t i) (t i))
    else 0
  Integrable (fun ω => ∑ i : Fin d, Y i ω) μ ∧
    Integrable (fun ω => ∑ i : Fin d,
      Real.cos (((2 * q + 1 : ℕ) : ℝ) * θ i) • Y i ω) μ ∧
    (∫ ω, ∑ i : Fin d, Y i ω ∂μ) =
      a • (1 : Matrix (Fin (q + 1) × Fin (q + 1)) (Fin (q + 1) × Fin (q + 1)) ℝ) ∧
    (∫ ω, ∑ i : Fin d, Real.cos (((2 * q + 1 : ℕ) : ℝ) * θ i) • Y i ω ∂μ) = 0


run_cmd do
  setEnv ((← getEnv).setExporting false)
  let env ← getEnv
  let modules : List String := ["AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumSourceRowLaw", "AutoSamplingTheory.TechnicalLemmas.Probability.StdGaussianMoment", "AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumTruncatedRowMoment", "AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumSourceMatrixMean", "AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumGridAlias", "AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumCosineGram", "Tests.GaussianComplexityFixedSpectrumSourceMatrixMean"]
  let mut roots : List Name := []
  for expected in (["AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumSourceMatrixMean.actual_source_truncated_matrix_means", "_private.Tests.GaussianComplexityFixedSpectrumSourceMatrixMean.0.AutoSamplingTheory.Tests.GaussianComplexityFixedSpectrumSourceMatrixMean.actual_source_truncated_sum_means"] : List String) do
    let some (n, _) := env.constants.toList.find? (fun (n, _) => n.toString == expected) | throwError "Missing root {expected}"
    roots := roots ++ [n]
  let allowed := [`propext, `Classical.choice, `Quot.sound]
  let mut data : Array Json := #[]
  for (n, ci) in env.constants.toList do
    if let some idx := env.getModuleIdxFor? n then
      let mod := env.header.moduleNames[idx.toNat]!
      if modules.contains mod.toString then
        let some body := ci.value? true | throwError "Whole-module body absent {n}"
        let closed := !ci.type.hasLooseBVars && !ci.type.hasFVar && !ci.type.hasMVar &&
          !body.hasLooseBVars && !body.hasFVar && !body.hasMVar
        unless closed do throwError "Unclosed owned declaration {n}"
        let axioms ← Lean.collectAxioms n
        unless axioms.all (fun a => allowed.contains a) do throwError "Disallowed axioms {n}: {axioms}"
        let kind := match ci with
          | .thmInfo _ => "theorem"
          | .defnInfo _ => "definition"
          | .opaqueInfo _ => "opaque"
          | _ => "other"
        let ppType ← Lean.Elab.Command.liftTermElabM <| return (← Lean.Meta.ppExpr ci.type).pretty
        data := data.push <| Json.mkObj [
          ("name", toJson n.toString), ("module", toJson mod.toString),
          ("kind", toJson kind), ("closed", toJson closed),
          ("level_params", toJson (ci.levelParams.map Name.toString)),
          ("axioms", toJson (axioms.toList.map Name.toString)),
          ("type_used", toJson (ci.type.getUsedConstants.toList.map Name.toString)),
          ("body_used", toJson (body.getUsedConstants.toList.map Name.toString)),
          ("type_pretty", toJson ppType), ("type_raw", toJson (reprStr ci.type)),
          ("body_raw", toJson (reprStr body))]
  let mut checks : Array Json := #[]
  for n in roots do
    let ci := env.find! n
    let lit := if n == roots.head! then `IndependentLiteralP else `IndependentLiteralT
    let literal := (env.find! lit).value! true
    Lean.Elab.Command.liftCoreM <| addDecl <| Declaration.thmDecl {
      name := Name.mkSimple (if n == roots.head! then "IndependentKernelApplicationP" else "IndependentKernelApplicationT")
      levelParams := ci.levelParams
      type := mkConst lit
      value := mkConst n (ci.levelParams.map Level.param)
    }
    checks := checks.push <| Json.mkObj [("root",toJson n.toString),
      ("raw_expr_structurally_equal",toJson (ci.type == literal)),
      ("sealed_literal_kernel_application",toJson true)]
  liftIO <| IO.FS.writeFile "/Users/zhouhuanjian/ASTIS-GC/.astis/semantic-neutral-20261112/mm_native_4a62/local/native-wholemodule.json" ((Json.mkObj [("constants",Json.arr data),("literal_checks",Json.arr checks)]).compress)
  logInfo m!"Fresh whole-module constants inspected: {data.size}; sealed literal applications: {checks.size}"

-- Concrete analytical typeclass checks use the same L2 operator norm scope.
example (d q : ℕ) : IsProbabilityMeasure
    (Measure.pi (fun _ : Fin (q+1) => stdGaussian (EuclideanSpace ℝ (Fin d)))) := inferInstance
example (d q : ℕ) : SigmaFinite
    (Measure.pi (fun _ : Fin (q+1) => stdGaussian (EuclideanSpace ℝ (Fin d)))) := inferInstance
example (q : ℕ) : CompleteSpace (Matrix (Fin (q+1)) (Fin (q+1)) ℝ) := inferInstance
example (q : ℕ) : CompleteSpace
    (Matrix (Fin (q+1) × Fin (q+1)) (Fin (q+1) × Fin (q+1)) ℝ) := inferInstance
example (q : ℕ) : FiniteDimensional ℝ (Matrix (Fin (q+1)) (Fin (q+1)) ℝ) := inferInstance
example (q : ℕ) : NormedSpace ℝ
    (Matrix (Fin (q+1) × Fin (q+1)) (Fin (q+1) × Fin (q+1)) ℝ) := inferInstance
example (q : ℕ) (L : ℝ) :
    Integrable (Set.indicator {x : EuclideanSpace ℝ (Fin (q+1)) | ‖x‖ ^ 2 ≤ L}
      (fun x => ‖x‖ ^ 2)) (stdGaussian (EuclideanSpace ℝ (Fin (q+1)))) := by
  exact (AutoSamplingTheory.TechnicalLemmas.Probability.StdGaussianMoment.integrable_norm_sq_and_integral_stdGaussian
    (E := EuclideanSpace ℝ (Fin (q+1)))).1.indicator (measurableSet_le (by fun_prop) measurable_const)
#synth NormedAddCommGroup (Matrix (Fin 2) (Fin 2) ℝ)
#check @MeasureTheory.integral_map
#check @MeasureTheory.MeasurePreserving.integrable_comp_of_integrable
#check @ContinuousLinearMap.integrable_comp
#check @ContinuousLinearMap.integral_comp_comm
#check @LinearMap.toContinuousLinearMap
#check @MeasureTheory.integral_finsetSum
#check @MeasureTheory.integrable_finsetSum
#print axioms IndependentKernelApplicationP
#print axioms IndependentKernelApplicationT
