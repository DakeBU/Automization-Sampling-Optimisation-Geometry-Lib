"""Read-only R16 fixture inspection; never imports/executes the browser checker or renderer."""
import ast
import datetime as dt
import hashlib
from html.parser import HTMLParser
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
import traceback

OWN=Path(__file__).resolve().parent
REPO=OWN.parents[2]
PREVIEW=REPO/'.astis/huanjian-gc-trace-mgf-domain-20261115/reader-preview-v2'
OLD=PREVIEW.parent/'reader-preview-v1'
ITEM='huanjian-trace-exponential-domain'
PFILE='AutoSamplingTheory/TechnicalLemmas/Analysis/MatrixTraceExponentialBounds.lean'
TFILE='Tests/GaussianComplexityTraceMgfDomain.lean'
BINDING='e44190bca918ce5a1e8f4ff5fc942c56ea400deb7a10af9929a698ef22a9d45c'
SOURCES=[(PFILE,18,60),(TFILE,21,183),('AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumSourceMatrixRadius.lean',101,226),('AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumSourceMatrixStructure.lean',13,148)]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,v):Path(p).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')

class Node:
    def __init__(self,tag='',attrs=()):self.tag=tag;self.attrs=dict(attrs);self.children=[]
    def text(self):return ''.join(c if isinstance(c,str) else c.text() for c in self.children)
    def has(self,cls):return cls in self.attrs.get('class','').split()
    def find(self,p):
        out=[]
        for c in self.children:
            if isinstance(c,Node):
                if p(c):out.append(c)
                out.extend(c.find(p))
        return out
class Parse(HTMLParser):
    def __init__(self,data):
        super().__init__(convert_charrefs=True);self.root=Node();self.stack=[self.root];self.feed(data)
    def handle_starttag(self,tag,attrs):
        n=Node(tag,attrs);self.stack[-1].children.append(n)
        if tag not in {'area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr'}:self.stack.append(n)
    def handle_endtag(self,tag):
        for i in range(len(self.stack)-1,0,-1):
            if self.stack[i].tag==tag:self.stack=self.stack[:i];break
    def handle_data(self,data):self.stack[-1].children.append(data)

def delta(a,b,path=''):
    if type(a)!=type(b):return [{'path':path,'before':a,'after':b}]
    if isinstance(a,dict):
        return sum((delta(a[k],b[k],path+'/'+str(k)) if k in a and k in b else [{'path':path+'/'+str(k),'before':a.get(k),'after':b.get(k)}] for k in sorted(set(a)|set(b))),[])
    if isinstance(a,list):
        if len(a)!=len(b):return [{'path':path,'before':a,'after':b}]
        return sum((delta(x,y,path+'/'+str(i)) for i,(x,y) in enumerate(zip(a,b))),[])
    return [] if a==b else [{'path':path,'before':a,'after':b}]

def main():
    checks=[]
    def check(n,v,d=None):
        checks.append({'name':n,'pass':bool(v),'detail':d})
        if not v:raise AssertionError(n)
    manifest_path=PREVIEW/'preview-freeze-manifest.json';m=json.loads(manifest_path.read_text())
    check('exact-v2-preview-manifest',sha(manifest_path)=='d4a81e04b876d2366b884e729581c07efb03ada299c9c58bd83b12866a15b524')
    check('exact-immutable-mathematical-commit',m['proof_commit']=='30172847ec40c24426f0b39afc4887719810eca0')
    snapshot=PREVIEW/'input-snapshot';im=PREVIEW/'input-freeze-manifest.json';inputs=json.loads(im.read_text())
    check('input-manifest-bound',sha(im)==m['input_freeze_manifest_sha256'])
    check('all-selected-input-files-byte-exact',all(sha(snapshot/r['path'])==r['sha256'] and (snapshot/r['path']).stat().st_size==r['bytes'] for r in inputs['files']),{'selected_files':len(inputs['files'])})
    for variant,data in m['variants'].items():
        fixture=PREVIEW/'fixtures'/variant
        check(variant+'-exact-served-file-set',{str(p.relative_to(fixture)) for p in fixture.rglob('*') if p.is_file()}=={r['path'] for r in data['files']})
        check(variant+'-all-served-file-bytes',all(sha(fixture/r['path'])==r['sha256'] and (fixture/r['path']).stat().st_size==r['bytes'] for r in data['files']),len(data['files']))
    lp=Path('website/content/declaration_lessons')/(ITEM+'.json');pp=Path('website/content/publications')/(ITEM+'.json')
    check('exact-reviewed-v2-lesson',sha(snapshot/lp)==m['lesson_sha256']=='5e8fd90f74182fecc92563a6bb522c762189e46f40e5507af96e721103e65291')
    check('exact-publication-unchanged',sha(snapshot/pp)==sha(OLD/'input-snapshot'/pp)==m['publication_sha256']=='bf7f4960b97f9883b6b5cd81931ef138f87dcbbeafdffb20174612ff8c437f10')
    oldlesson=json.loads((OLD/'input-snapshot'/lp).read_text());lesson=json.loads((snapshot/lp).read_text());unit=lesson['units'][0]
    changes=delta(oldlesson,lesson)
    check('exactly-six-added-source-scopes',len(changes)==6 and {c['path'] for c in changes}=={'/units/0/sources/'+str(i)+'/scope' for i in range(1,7)} and all(c['before'] is None and isinstance(c['after'],str) and c['after'] for c in changes),changes)
    check('renderer-actually-requires-scope','source["scope"]' in (snapshot/'website/scripts/declaration_lessons.py').read_text())
    check('helpers-v1-v2-bytes-unchanged',all(sha(PREVIEW/n)==sha(OLD/n) for n in ['render_preview.py','reader_overlay.py']))
    check('exact-five-source-ranges',[(s['lean_source_path'],s['lean_source']['LF_lines_1based']) for s in unit['steps']]==[(PFILE,[1,37]),(PFILE,[38,51]),(PFILE,[52,60]),(TFILE,[1,136]),(TFILE,[137,183])])
    for raw in [PFILE,TFILE]:check('whole-module-five-span-'+raw,''.join(s['lean'] for s in unit['steps'] if s['lean_source_path']==raw).encode()==(snapshot/raw).read_bytes())
    check('five-spans-total243-lines',sum(len(s['lean'].splitlines()) for s in unit['steps'])==243)
    for variant,v in m['variants'].items():
        fixture=PREVIEW/'fixtures'/variant
        for page in [v['proof_path'],v['lesson_path']]:
            dom=Parse((fixture/page).read_text()).root;steps=dom.find(lambda n:n.tag=='details' and n.has('proof-reader-step'))
            check(variant+'-'+page+'-five-exact-steps',len(steps)==5 and [n.find(lambda n:n.tag=='pre' and n.has('code-block'))[0].text() for n in steps]==[s['lean'] for s in unit['steps']])
            check(variant+'-'+page+'-steps-initially-closed',all('open' not in s.attrs for s in steps))
        if variant=='candidate':
            for i,(n,s) in enumerate(zip(steps,unit['steps'])):
                source=n.find(lambda n:n.tag=='a' and 'data-step-source' in n.attrs);download=n.find(lambda n:n.tag=='a' and 'download' in n.attrs);copy=n.find(lambda n:n.tag=='button' and 'data-lean-copy' in n.attrs)
                check('step'+str(i+1)+'-exact-adjacent-action-targets',len(source)==len(download)==len(copy)==1 and source[0].attrs['href'].endswith(s['lean_source_path']+'.html#L'+str(s['lean_source']['LF_lines_1based'][0])) and download[0].attrs['href'].endswith('downloads/lean/'+s['lean_source_path']))
            for raw,anchor,count in SOURCES:
                dom=Parse((fixture/('data/lesson-sources/'+raw+'.html')).read_text()).root;pre=dom.find(lambda n:n.tag=='pre')
                check(raw+'-whole-source-page-body-byte-exact',len(pre)==1 and pre[0].text().encode()==(snapshot/raw).read_bytes())
                spans=pre[0].find(lambda n:n.tag=='span' and n.attrs.get('id','').startswith('L'))
                check(raw+'-all-lines-and-exact-anchor',len(spans)==count and any(n.attrs['id']=='L'+str(anchor) for n in spans))
                check(raw+'-download-byte-exact',(fixture/('downloads/lean/'+raw)).read_bytes()==(snapshot/raw).read_bytes())
    graph=json.loads((PREVIEW/'fixtures/candidate/data/underlying-lean-graph.json').read_text())
    check('graph-bounded-7nodes-9edges',len(graph['nodes'])==7 and len(graph['edges'])==9 and sum(e['relation']=='source reference (scanner)' for e in graph['edges'])==3)
    check('private-T-never-public-declaration-node',not any(n['id'].startswith('decl:') and 'actual_source_four_trace_mgfs' in n['id'] for n in graph['nodes']))
    index=(PREVIEW/'fixtures/candidate/source-index.html').read_text()
    check('private-source-index-label-explicitly-not-public','associated private application; no public node' in index)
    for name in ['browser_check.py','browser_geometry.py','geometry_helpers.fragment.py']:
        tree=ast.parse((OWN/name).read_text(),filename=name);check(name+'-Python-AST-valid',isinstance(tree,ast.Module))
    tree=ast.parse((OWN/'browser_geometry.py').read_text());js={n.targets[0].id:ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id in {'GEOMETRY','VISIBLE','GLYPH'}}
    node=shutil.which('node');check('node-present-for-JS-syntax-check',node is not None)
    for name,value in js.items():
        r=subprocess.run([node,'--check'],input='('+value+');',text=True,capture_output=True)
        check(name+'-JavaScript-syntax-valid',r.returncode==0,{'stdout':r.stdout,'stderr':r.stderr,'actual_exit_code':r.returncode})
    runner=(OWN/'browser_check.py').read_text()
    check('no-optional-screenshot-crop-code','clip=' not in runner and '.screenshot(' in runner)
    check('execution-assignment-does-not-exist',not (OWN/'execution-assignment.json').exists())
    check('no-browser-runtime-output-created',not any((OWN/p).exists() for p in ['runtime-process','runtime-output','actual-result.json','chrome-tmp']))
    frozen=[manifest_path,im,PREVIEW/'render_preview.py',PREVIEW/'reader_overlay.py',snapshot/lp,snapshot/pp,*[snapshot/r for r,_,_ in SOURCES]]
    draft={'authorization':'PREPARED_AWAIT_ROOT_POST_SOURCE_REVIEW_EXECUTION_AUTHORIZATION','preview_root':str(PREVIEW),'runner_sha256':sha(OWN/'browser_check.py'),'geometry_sha256':sha(OWN/'browser_geometry.py'),'preview_manifest_sha256':sha(manifest_path),'source_reviewed_publication_binding_sha256':BINDING,'frozen_inputs':[{'path':str(p),'sha256':sha(p)} for p in frozen],'lesson_sha256':m['lesson_sha256'],'publication_sha256':m['publication_sha256'],'chrome':{'path':'ROOT_TO_PIN_ACTUAL_CHROME_EXECUTABLE','binary_sha256':'ROOT_TO_PIN_ACTUAL_BINARY_SHA256'},'execution_custody':'ROOT_TO_RECORD_FRESH_SCOPED_APPROVAL_AND_ACTUAL_COMMAND'}
    dump(OWN/'execution-assignment.draft.json',draft)
    result={'schema':'r16-independent-reader-static-preparation-v1','status':'PREPARED_NO_BROWSER_RENDER_SERVER_OR_RUNTIME_EXECUTED','preview_root':str(PREVIEW),'preview_manifest_sha256':sha(manifest_path),'source_binding':BINDING,'independent_source_review':'ROOT reports accepted exact six-scope successor; not a reader acceptance inherited by this preparation','root_reported_review_run_sha256':'8543d7d7365431d074a20c5491750620d242a1b3125379fd8221d9e5270bf64c','checks':checks,'runner_sha256':sha(OWN/'browser_check.py'),'geometry_sha256':sha(OWN/'browser_geometry.py'),'source_review_not_reperformed':True,'old_acceptance_inherited':False,'initial_v1_render_failure':'ROOT actual exit1 KeyError scope; six fields absent. v1 and actual failed receipt retained by ROOT; this inspection did not execute that render.','future_screenshots':'approximately36-38 full viewport/full-page PNGs covering distinct meaningful states; no optional crop','future_browser_scope':'candidate isolated fixture only; not production/full-site acceptance','runtime_authorization_required':'Separate execution-assignment.json authorization ROOT_AUTHORIZED_AFTER_SOURCE_REVIEW plus fresh scoped sandbox approval; draft is deliberately rejected by browser checker','planned_command':[str(REPO/'.astis/huanjian-gc-integration-20261105/browser-venv/bin/python'),str(OWN/'browser_check.py'),'--preview-root',str(PREVIEW),'--assignment',str(OWN/'execution-assignment.json')],'side_effects':'Own preparation files only; no renderer, browser, localhost server, Lean, Git/API/ledger or production changes'}
    dump(OWN/'preparation-result.json',result)
    print(json.dumps({'status':result['status'],'checks':len(checks),'runner_sha256':result['runner_sha256'],'geometry_sha256':result['geometry_sha256'],'preparation_result_sha256':sha(OWN/'preparation-result.json')}))

if __name__=='__main__':
    process=OWN/'static-process';process.mkdir(exist_ok=False);start=time.monotonic();started=dt.datetime.now(dt.timezone.utc).isoformat();code=0
    out=process/'stdout.raw';err=process/'stderr.raw'
    for fd,p in [(1,out),(2,err)]:
        f=p.open('xb',buffering=0);os.dup2(f.fileno(),fd);f.close()
    try:main()
    except BaseException:traceback.print_exc();code=1
    sys.stdout.flush();sys.stderr.flush()
    dump(process/'receipt.json',{'argv':[sys.executable,*sys.argv],'cwd':str(Path.cwd()),'pid':os.getpid(),'started_utc':started,'ended_utc':dt.datetime.now(dt.timezone.utc).isoformat(),'elapsed_seconds':time.monotonic()-start,'actual_exit_code':code,'stdout':{'path':'static-process/stdout.raw','bytes':out.stat().st_size,'sha256':sha(out)},'stderr':{'path':'static-process/stderr.raw','bytes':err.stat().st_size,'sha256':sha(err)},'preparation_script_sha256':sha(__file__),'scope':'actual non-browser CLI/parse inspection only'})
    sys.exit(code)
