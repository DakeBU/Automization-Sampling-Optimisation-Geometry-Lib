"""Author the exact source-facing lesson and an anonymous decoder packet."""
from pathlib import Path
import hashlib
import json
import sys

sys.dont_write_bytecode = True
sys.path.insert(0, 'tools')
import astis_publication as publication
import astis_semantic_roundtrip as semantic

workspace = Path(__file__).resolve().parent.relative_to(Path.cwd())
evidence = Path('research-wiki/paper-contributions/GaussianComplexity/truncated-row-second-moment-semantic-evidence')
cell_path = Path('research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-truncated-row-second-moment.json')
runner = Path('.astis/huanjian-resume-20261103')


def sha(value):
    return hashlib.sha256(value.encode() if isinstance(value, str) else value).hexdigest()


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x') as out:
        json.dump(value, out, ensure_ascii=False, indent=2)
        out.write('\n')


def checked_receipt(stem):
    path = runner / (stem + '.receipt.json')
    receipt = json.loads(path.read_bytes())
    log = Path(receipt['log']).read_bytes()
    assert receipt['exit_code'] == 0 and sha(log) == receipt['log_sha256']
    return {'path': str(path), 'sha256': sha(path.read_bytes()), 'log_sha256': sha(log)}, log.decode()


seal = json.loads((workspace / 'statement-seal-v2.json').read_bytes())
P, T = [Path(seal[k]['planned_file']) for k in ('producer', 'actual_private_consumer')]
p_text, t_text = P.read_text(), T.read_text()
name = seal['producer']['name']
private_name = '_private.Tests.GaussianComplexityFixedSpectrumTruncatedRowMoment.0.' + seal['actual_private_consumer']['name']
for key, text in [('producer', p_text), ('actual_private_consumer', t_text)]:
    short = seal[key]['name'].split('.')[-1]
    literal = text.split('theorem ' + short, 1)[1].split(' := by', 1)[0].lstrip() + '\n'
    assert literal == seal[key]['signature']
build, _ = checked_receipt('20261111T032852209851Z-radial-row-second-moment-actual-producer-and-consumer-build')
kernel, log = checked_receipt('20261111T033046618660Z-radial-row-second-moment-actual-kernel-types-axioms-and-parents')
radius_parent = 'AutoSamplingTheory.TechnicalLemmas.Probability.StdGaussianMoment.integrable_norm_sq_and_integral_stdGaussian'
parents = {name: [radius_parent], private_name: [name]}
for target, required in parents.items():
    assert 'ACTUAL_SEALED_LITERAL_KERNEL_TYPE_APPLICATION_PASS ' + target in log
    start = log.index('ACTUAL_PUBLIC_ASTIS_PARENTS ' + target + ': [')
    end = log.index(']', start)
    assert all(item in log[start:end] for item in required)
assert 'ALL_OWNED_DECLARATIONS_KERNEL_INSPECTED 2' in log

title = 'The truncated second moment of a Gaussian row'
statement = r'At the cutoff \(L=2r+3\log(1000d)\), the retained standard-Gaussian second moment is \(aI_r\).'
formula = (
    r'\begin{aligned}\mathbb E[ZZ^\top\mathbf1_{\{R\le L\}}]&=aI_r,\\'
    r'a&=\frac{\mathbb E[R\mathbf1_{\{R\le L\}}]}r.\end{aligned}'
)
mean_formula = (
    r'\begin{aligned}Y_i&=\frac1d(ZZ^\top\otimes t_it_i^\top)\mathbf1_{\{R\le L\}},\\'
    r'\mathbb E Y_i&=\frac ad(I_r\otimes t_it_i^\top).\end{aligned}'
)
assumptions = [
    r'Let \(d,q\in\mathbb N\) satisfy \(2q+1<d\), and set \(r=q+1\). The case \(q=0\) has \(r=1\).',
    r'The row has the canonical law \(Z\sim N(0,I_r)\), with \(R=\|Z\|^2\). Retain the closed event \(R\le L\).',
    r'The expectation uses the original Gaussian measure. The coefficient \(a\) is the retained radial moment divided by \(r\). Both matrix integrability conclusions are proved using the Euclidean operator norm.',
    r'For the private application use \(\theta_j=(j-\tfrac12)\pi/d\), \(j=1,\ldots,d\), and \(t_j=(1,\sqrt2\cos\theta_j,\ldots,\sqrt2\cos(q\theta_j))\). Lean uses \(j=i.val+1\) for \(i\in\mathrm{Fin}(d)\) and zero-based feature frequencies.',
]
boundary = (
    'The exact canonical single-row truncated second moment and the actual deterministic-row Y mean are compiled. '
    'The original joint row-family pushforward and integral transport, aggregate cosine-frame means, '
    'centered bounds, fourth moments, matrix concentration, full Lemma 4.4, both main lower bounds and '
    'oracle/precision/cost adapters are separate. Independent source/native review, public integration, '
    'complete desktop/mobile reader acceptance and purification are pending.'
)
source = {
    'url': 'https://arxiv.org/html/2610.20492v1#A3.Ex108',
    'edition': 'arXiv:2610.20492v1; pinned HTML SHA256 ' + seal['source']['raw_sha256'],
    'anchor': 'Appendix C.2 Ex108 and p12.m5; Ex107 definition; p1/p10, S4.E11 and C.2p5 index conventions',
    'wording_status': 'faithful paraphrase',
    'attribution': 'On Complexity of Gaussian Sampling, arXiv:2610.20492v1.',
    'scope': 'Unnormalized retained row second moment and the immediate single-row matrix expectation.',
}
mathlib = [
    'ProbabilityTheory.stdGaussian_map', 'LinearIsometryEquiv.piLpCongrRight',
    'LinearIsometryEquiv.piLpCongrLeft', 'LinearIsometryEquiv.neg', 'MeasureTheory.integral_map',
    'MeasureTheory.Integrable.mono\x27', 'MeasureTheory.Integrable.indicator',
    'MeasureTheory.Integrable.of_eval', 'MeasureTheory.eval_integral',
    'Matrix.ofLinearEquiv', 'LinearEquiv.toContinuousLinearEquiv',
    'ContinuousLinearMap.integrable_comp', 'ContinuousLinearMap.integral_comp_comm',
    'ContinuousLinearEquiv.integral_comp_comm', 'EuclideanSpace.real_norm_sq_eq',
    'MeasureTheory.integral_finsetSum', 'Matrix.kroneckerBilinear',
]


def code(first, last):
    return ''.join(p_text.splitlines(keepends=True)[first - 1:last])


steps = [
    {'title': 'Establish the scalar and matrix integrals',
     'text': ('The canonical Gaussian squared-norm moment is integrable. Restrict it to the retained ball. '
              'Every retained coordinate product is dominated by that retained squared radius. '
              'Finite coordinate integrability and the continuous linear equivalence from arrays to matrices '
              'give the matrix integral and its entrywise evaluation.'),
     'formula': r'|Z_kZ_\ell|\mathbf1_{\{R\le L\}}\le R\mathbf1_{\{R\le L\}},\qquad R\mathbf1_{\{R\le L\}}\in L^1.',
     'lean': code(34, 92)},
    {'title': 'Cancel the off-diagonal entries',
     'text': ('A linear isometry preserves the standard Gaussian law and the radial cutoff. '
              'Flip the sign of coordinate k while keeping a distinct coordinate fixed. '
              'The corresponding retained product changes sign, so its expectation is zero.'),
     'formula': r'\mathbb E[Z_kZ_\ell\mathbf1_{\{R\le L\}}]=0\qquad(k\ne\ell).',
     'lean': code(93, 125)},
    {'title': 'Identify a common diagonal expectation',
     'text': ('The coordinate-swap isometry preserves the law and retained event. '
              'It interchanges the squared coordinates in the integral. The equality holds for every pair '
              'of indices and includes the single-coordinate case.'),
     'formula': r'\mathbb E[Z_k^2\mathbf1_{\{R\le L\}}]=\mathbb E[Z_\ell^2\mathbf1_{\{R\le L\}}].',
     'lean': code(127, 145)},
    {'title': 'Use the trace to determine the coefficient',
     'text': ('Write c for the common diagonal expectation. The sum of squared coordinates is R. '
              'Integrating this finite sum gives r c equal to the retained radial expectation. '
              'Divide by the positive dimension and combine the diagonal and off-diagonal entries.'),
     'formula': r'r c=\mathbb E[R\mathbf1_{\{R\le L\}}],\qquad c=a,\qquad \mathbb E[ZZ^\top\mathbf1_{\{R\le L\}}]=aI_r.',
     'lean': code(147, 180)},
    {'title': 'Compute the actual matrix summand mean',
     'text': ('For a fixed source row, tensoring with its deterministic rank-one feature matrix and '
              'scaling by 1/d form a continuous linear map. The map commutes with the retained indicator '
              'and Bochner integral. Apply both components of the producer to obtain integrability and '
              'the exact mean. This fold contains the complete private application.'),
     'formula': mean_formula,
     'lean': t_text},
]
unit = {
    'kind': 'theorem', 'reading_layout': 'progressive', 'declaration': name, 'title': title,
    'reader_note': 'Open the assumptions and source steps for the exact objects and Lean.',
    'statement': statement, 'formula': formula, 'assumptions': assumptions, 'steps': steps,
    'astis_dependencies': [radius_parent], 'mathlib_dependencies': mathlib,
    'dependency_notes': ('The producer consumes integrability from the canonical Gaussian norm moment. '
                         'Gaussian isometry invariance, finite-dimensional matrix integration and the trace '
                         'identify the matrix. The private application consumes the producer through a '
                         'continuous linear Kronecker map.'),
    'lean_statement': 'Integrability and the exact retained second moment under the actual standard row law.',
    'lean_proof': 'Prove entry integrability, use sign and coordinate symmetries, determine the trace coefficient, and transport through the deterministic tensor map.',
    'boundary': boundary,
    'sources': [{**source, 'label': 'Appendix C.2 truncated second moment and single-row matrix mean'},
                {'path': str(T), 'line': 19, 'label': 'Complete private matrix-mean proof',
                 'scope': 'Exact one-row application with the source cosine feature and normalization.'}],
    'tests': ['lake build Tests.GaussianComplexityFixedSpectrumTruncatedRowMoment'],
}
slug = 'huanjian-gaussian-truncated-row-second-moment'
audit_id = 'ASTIS-RT-20261111-HuanjianGaussianTruncatedRowMoment'
lesson_path = Path('website/content/declaration_lessons') / (slug + '.json')
pub_path = Path('website/content/publications') / (slug + '.json')
audit_path = Path('research-wiki/semantic-roundtrip/audits') / (slug + '.json')
write(lesson_path, {'schema_version': 1, 'units': [unit]})
binding = {
    'declaration': name, 'cell': cell_path.stem, 'role': 'proof-edge',
    'supports': ['c2-truncated-row-second-moment'], 'boundary': boundary, 'audit_id': audit_id,
    'assumption_deltas': [
        {'source': 'A standard r-dimensional Gaussian row, with r=q+1 and the standing source range.',
         'lean': 'The canonical standard Gaussian on EuclideanSpace real Fin(q+1), including q=0 and 2q+1<d.',
         'classification': 'same', 'reason': 'The local theorem realizes the canonical single-row marginal. Original row-family law transport is separate.'},
        {'source': 'The retained unnormalized matrix expectation equals a I_r.',
         'lean': 'The matrix integrability is also a proved conclusion, using the Euclidean operator norm.',
         'classification': 'source-implicit', 'reason': 'The source expectation presupposes finite entries. Scalar and matrix integrability are internal proof components.'},
        {'source': 'The immediate Y_i mean tensors with the deterministic cosine row and scales by 1/d.',
         'lean': 'The private application uses the literal midpoint cosine feature and derives the expected tensor matrix.',
         'classification': 'same', 'reason': 'The zero-based Fin row maps to the source one-based index by successor. Feature frequencies stay zero-based.'},
    ],
}
item = {
    'id': slug, 'library': 'samplewiki', 'chapter': 'gaussian-sampling-complexity',
    'chapter_path': 'example-cases/samplewiki/companions/gaussian-sampling-complexity.html',
    'title': title, 'source': source, 'statement': statement,
    'formulae': [{'label': 'Retained second moment and coefficient', 'tex': formula},
                 {'label': 'Actual single-row matrix mean', 'tex': mean_formula}],
    'assumptions': assumptions,
    'obligations': [{'id': 'c2-truncated-row-second-moment', 'label': 'The Ex108 matrix second moment with the actual p12.m5 consumer.'}],
    'bindings': [binding],
}
write(pub_path, {'schema_version': 1, 'items': [item]})
head, conclusion = seal['producer']['signature'].split(' :\n', 1)
literal = '∀ ' + head + ',\n' + conclusion
source_text = (
    r'For a standard Gaussian row in dimension \(r=q+1\), put \(R=\|Z\|^2\) and '
    r'\(L=2r+3\log(1000d)\). Its unnormalized retained second moment is '
    r'\(\mathbb E[ZZ^\top\mathbf1_{\{R\le L\}}]=aI_r\), where '
    r'\(a=\mathbb E[R\mathbf1_{\{R\le L\}}]/r\), in the standing range \(2q+1<d\).'
)
audit = {
    'id': audit_id, 'state': 'draft',
    'source': {'source_id': 'arxiv2610.20492v1-c2-truncated-row-second-moment',
               'url': source['url'], 'anchor': source['anchor'], 'original_text': source_text,
               'text_sha256': sha(source_text), 'source_snapshot_sha256': seal['source']['raw_sha256']},
    'lean': {'declaration': name, 'file': str(P), 'statement': literal,
             'statement_sha256': sha(literal), 'formalizer': 'huanjian_gc_20261111_truncated_row_moment',
             'compiled': True,
             'decoder_context': [
                 'EuclideanSpace real Fin n is ordinary real Euclidean n-space with its Euclidean norm and Borel measurable structure. stdGaussian is the canonical centered law with variance-one independent orthonormal coordinates.',
                 'WithLp.ofLp exposes the coordinate vector. Matrix m n real is a finite real array. Matrix.vecMulVec w v has entry w_i v_j, so its repeated-vector case is the rank-one matrix of coordinate products.',
                 'Matrix.one is the identity matrix. Scalar multiplication multiplies every matrix entry. The chosen norm is the Euclidean L2 operator norm on finite matrices, with the usual finite-dimensional topology.',
                 'Set.indicator retains the indicated function on its set and is zero elsewhere. Integrable means a.e. strong measurability and finite norm integral in the indicated measure. All integrals are real or matrix Bochner integrals.',
                 'The real dimension r is the cast of the positive natural dimension q+1. Real.log is the natural logarithm on positive arguments. The displayed integral defining the real scalar uses the original Gaussian measure.',
             ]},
    'reconstruction': {}, 'semantic_slots': {}, 'deltas': [], 'verdict': 'pending',
    'source_review': {'state': 'pending'}, 'repairs': [],
}
publication.inputs.cache_clear()
publication.load.cache_clear()
audit['publication_binding_sha256'] = publication.binding_digest(item, binding)
audit['publication_context'] = publication.review_context(item, binding)
write(audit_path, audit)
cell = json.loads(cell_path.read_bytes())
cell['parents'] = ['ASTIS-SHARED-std-gaussian-second-moment']
cell['evidence']['actual_compilation'] = build
cell['evidence']['actual_kernel'] = kernel
cell['evidence']['actual_public_ASTIS_parents'] = parents
cell['evidence'].pop('target_proof_calls', None)
cell['reuse_plan']['reused_declarations'] = [radius_parent, *mathlib]
cell['reuse_plan']['known_consumers'] = [private_name]
cell['source_detail_audit']['consulted'].append({
    'source': 'Pinned Mathlib Multivariate Gaussian, PiLp isometries, finite-dimensional modules and Bochner continuous-linear-map integration',
    'anchor': 'stdGaussian_map; piLpCongrRight/Left; Matrix.ofLinearEquiv; toContinuousLinearEquiv; integral_comp_comm; kroneckerBilinear',
    'hypothesis_adapter': 'Canonical standard-law invariance and retained norm integrability justify the entrywise symmetry proof. Finite-dimensional linear maps transport the matrix and deterministic Kronecker integrals.',
})
for key in ['source_ordered', 'source_statement_adjacent', 'natural_language_formula_proof',
            'hidden_assumptions_visible', 'lean_collapsed', 'external_dependencies_visible']:
    cell['reader_contract'][key] = True
cell['reader_contract']['status'] = 'Five authored adjacent Lean folds, including the full private module. Independent source/native/static/public reader acceptance pending.'
cell_path.write_text(json.dumps(cell, ensure_ascii=False, indent=2) + '\n')
publication.check_advance([name], reviewed=False)
packet = semantic.decoder_packet(audit)
neutral = Path('.astis/semantic-neutral-20261111/rc_decode_9d31/input.json')
write(neutral, packet)
write(evidence / 'decoder-input.json', packet)
record = {
    'producer_sha256': sha(P.read_bytes()), 'private_consumer_sha256': sha(T.read_bytes()),
    'build': build, 'kernel': kernel, 'actual_public_ASTIS_parents': parents,
    'both_exact_literal_types_kernel_applied': True, 'raw_Expr_structural_equality': False,
    'owned_theorems': 2, 'handwritten': 2, 'generated_internal': 0,
    'publication_binding_sha256': audit['publication_binding_sha256'],
    'neutral_input': str(neutral), 'neutral_input_raw_sha256': sha(neutral.read_bytes()),
    'neutral_canonical_packet_sha256': packet['packet_sha256'], 'anonymous_statement_sha256': sha(literal),
    'step_code_sha256': [sha(step['lean']) for step in steps], 'source_review': 'pending',
}
write(evidence / 'publication-draft-record.json', record)
print(json.dumps(record))
