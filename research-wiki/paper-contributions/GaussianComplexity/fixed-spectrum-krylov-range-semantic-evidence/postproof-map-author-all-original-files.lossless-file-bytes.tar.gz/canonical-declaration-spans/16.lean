theorem eval_mul : (p * q).eval x = p.eval x * q.eval x :=
  eval₂_mul _ _
