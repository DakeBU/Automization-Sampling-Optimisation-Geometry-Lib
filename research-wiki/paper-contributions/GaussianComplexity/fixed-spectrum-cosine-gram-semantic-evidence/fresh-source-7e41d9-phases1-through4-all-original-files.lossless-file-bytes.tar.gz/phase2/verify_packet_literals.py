#!/opt/anaconda3/bin/python
import hashlib
import json
import pathlib
import stat
BASE=pathlib.Path(__file__).resolve().parent
def digest(data):return hashlib.sha256(data).hexdigest()
results=[]
main=json.loads((BASE/'inputs/selective-fresh-source-phase2-input.json').read_text())
for block,key in [('source','original_text'),('lean','statement'),('blind_reconstruction','text')]:
    expected=main[block]['statement_sha256' if block=='lean' else 'text_sha256']
    observed=digest(main[block][key].encode())
    results.append({'field':block+'.'+key,'sha256':observed,'supplied_expected':expected,'matches':observed==expected})
for index,entry in enumerate(main['minimal_meaning_carrying_definitions']):
    if 'literal_sha256' not in entry:continue
    observed=digest(entry['literal_definition'].encode())
    results.append({'field':'main.definition.'+entry['name'],'sha256':observed,
                    'supplied_expected':entry['literal_sha256'],'matches':observed==entry['literal_sha256']})
for name,key in [('minimal-extra-law-definitions.pure-v2.json','literal_definition_or_context'),
                 ('minimal-requested-orthonormal-normalization-context.json','literal')]:
    packet=json.loads((BASE/'inputs'/name).read_text())
    for index,entry in enumerate(packet['definitions']):
        observed=digest(entry[key].encode())
        results.append({'field':name+':'+str(index),'sha256':observed,
                        'supplied_expected':entry['literal_sha256'],
                        'matches':observed==entry['literal_sha256']})
private_hash=digest(main['actual_private_consumer_literal_signature'].encode())
first=BASE.parent/'phase1'
known={'manifest.json':'80d4eefdb9d3d733e60d4ea52d00207c5ca62e03c1964b94e404525c2e472079',
       'raw_first_cognition.md':'3b4d1066754e4798eca86acbab56e5d16779d5ea8f2e7936a1af88f3de30f75b',
       'freeze_receipt.json':'8834e685793c01200a664e1bb1f439b6e77e132a16134241a23ea92e780f2452'}
first_records=[]
for name,expected in known.items():
    path=first/name;observed=digest(path.read_bytes())
    assert observed==expected,(name,observed)
    first_records.append({'path':name,'sha256':observed,'mode':format(stat.S_IMODE(path.stat().st_mode),'04o')})
manifest=json.loads((first/'manifest.json').read_text())
for entry in manifest['payloads']:
    path=first/entry['path'];data=path.read_bytes()
    assert digest(data)==entry['sha256'] and len(data)==entry['bytes'],entry['path']
    assert stat.S_IMODE(path.stat().st_mode)==0o444
assert stat.S_IMODE(first.stat().st_mode)==0o555
record={'literal_checks':results,'all_supplied_literal_hashes_match':all(r['matches'] for r in results),
        'private_signature_sha256_computed_here':private_hash,
        'phase1_hashes_unchanged':first_records,'phase1_payloads_verified_unchanged':len(manifest['payloads']),
        'phase1_directory_mode_observed':'0555','phase1_payload_file_modes_observed':'0444',
        'scope':'Hash and literal-byte integrity only; no compiler run or independent validation of claimed upstream whole-file hashes.'}
(BASE/'literal_and_phase1_verification.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
assert record['all_supplied_literal_hashes_match']
