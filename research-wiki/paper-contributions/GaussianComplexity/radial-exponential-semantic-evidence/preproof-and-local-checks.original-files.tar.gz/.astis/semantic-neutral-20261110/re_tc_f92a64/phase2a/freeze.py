from pathlib import Path
import hashlib,json,stat
base=Path(__file__).resolve().parent
packet=(base/'selective-type-definition-packet.original.json').read_bytes()
assert hashlib.sha256(packet).hexdigest()=='44cecb47245a0d1ab06d634f8b1dcd408c8368437e37cea1f0bde46fc2669ae3'
p=json.loads(packet)
for name in ('producer','private_consumer'):
    assert hashlib.sha256(p[name]['signature'].encode()).hexdigest()==p[name]['signature_sha256']
for d in p['minimal_definition_context']['definitions']:
    assert hashlib.sha256(d['literalLF'].encode()).hexdigest()==d['literal_sha256']
j=json.loads((base/'typed-judgment.json').read_bytes())
assert not j['exposure']['other_graph_exposed']
assert not j['exposure']['target_proof_exposed']
assert j['verdict']=='MATHEMATICALLY_SOURCE_CONSISTENT_INTERFACES'
entries=[]
for f in sorted(base.rglob('*')):
    if f.is_file():
        assert f.name!='frozen-manifest.json','Refuse to overwrite existing freeze'
        b=f.read_bytes();entries.append({'path':str(f.relative_to(base)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'frozen_mode':'0444'})
manifest={'kind':'Independent Phase2a exact-type mathematical judgment frozen before graph exposure','source_math_freeze_sha256':'50208c71a2b13245e70ea68b5fdb2a65a73b039eef4b034caa14438460a48d83','packet_sha256':hashlib.sha256(packet).hexdigest(),'other_graph_exposed':False,'target_proof_exposed':False,'files':entries,'directory_mode':'0555','self_hash':'Omitted to avoid self-reference; actual final command result and sibling receipt bind this manifest.','phase1_preservation':'No phase1 file opened for write or chmod during phase2a.'}
(base/'frozen-manifest.json').write_bytes((json.dumps(manifest,indent=2)+'\n').encode())
for f in base.rglob('*'):
    if f.is_file():f.chmod(0o444)
for d in sorted([d for d in base.rglob('*') if d.is_dir()],key=lambda d:len(d.parts),reverse=True):d.chmod(0o555)
base.chmod(0o555)
files=[f for f in base.rglob('*') if f.is_file()]
dirs=[base]+[d for d in base.rglob('*') if d.is_dir()]
assert all(stat.S_IMODE(f.stat().st_mode)==0o444 for f in files)
assert all(stat.S_IMODE(d.stat().st_mode)==0o555 for d in dirs)
print('PHASE2A_FROZEN_FILES',len(files),'DIRS',len(dirs),'FILE_MODE_0444',len(files),'DIR_MODE_0555',len(dirs))
for n in ('selective-type-definition-packet.original.json','independent-typed-judgment.md','typed-judgment.json','execution-receipt-pre-freeze.json','frozen-manifest.json'):
    b=(base/n).read_bytes();print('FROZEN_SHA256',n,hashlib.sha256(b).hexdigest(),'BYTES',len(b))
print('GRAPH_EXPOSURE_BEFORE_FREEZE',False,'TARGET_PROOF_EXPOSURE',False,'PHASE1_WRITES',0,'SIGNATURES_HASHED',2,'DEFINITION_LITERALS_HASHED',11)

