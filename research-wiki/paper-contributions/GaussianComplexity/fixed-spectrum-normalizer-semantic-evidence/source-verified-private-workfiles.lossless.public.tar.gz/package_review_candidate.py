from pathlib import Path
import hashlib,json,tarfile,gzip,subprocess,shutil,sys
sys.path.insert(0,'tools');import astis_publication as pub
sha=lambda raw:hashlib.sha256(raw).hexdigest()
b=Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-normalizer-semantic-evidence');private=Path('.astis/huanjian-fixed-spectrum-normalizer-20261108')
ap=Path('research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-normalizer.json');a=json.loads(ap.read_bytes());assert a['state']=='blind-reconstructed'
pub.check_advance([a['lean']['declaration']],reviewed=False)
checks=b/'actual-checks'
for p in sorted(Path('.astis/huanjian-resume-20261103').glob('*-fixed-spectrum-normalizer-*.receipt.json')):
 if (checks/p.name).exists():continue
 r=json.loads(p.read_bytes());raw=Path(r['log']).read_bytes();assert sha(raw)==r['log_sha256'];shutil.copy2(p,checks/p.name);z=checks/(Path(r['log']).name+'.gz');z.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(z.read_bytes())==raw
files=sorted(p for p in private.iterdir() if p.is_file());archive=b/'postblind-root-workfiles.lossless.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz') as t:
 for p in files:t.add(p,arcname=p.name,recursive=False)
with tarfile.open(archive,'r:gz') as t:
 for p in files:assert t.extractfile(p.name).read()==p.read_bytes()
manifest=b/'postblind-root-workfiles.manifest.json';manifest.write_text(json.dumps({'archive':str(archive),'sha256':sha(archive.read_bytes()),'all_members_roundtrip_verified':True,'files':[{'path':str(p),'member':p.name,'sha256':sha(p.read_bytes())} for p in files]},indent=2)+'\n')
roots=[checks,b/'blind-691853',b/'fresh-source-reader-640251/phase1'];paths=[p for root in roots for p in root.rglob('*') if p.is_file()]+[b/'phase2-selective-input.json',b/'blind-adoption-receipt.json',b/'integration-preflight-canonical-parent-visibility.json',b/'integration-preflight-canonical-parent-visibility-corrected.json',archive,manifest]
pack=b/'postblind-frozen-raw-packaging';pack.mkdir(exist_ok=False);rows=[];safe=[]
for p in paths:
 raw=p.read_bytes();tracked=subprocess.run(['git','ls-files','--error-unmatch','--',str(p)],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode==0;ignored=subprocess.run(['git','check-ignore','-q','--',str(p)]).returncode==0;binary=p.suffix in ['.gz','.zip','.png'] or b'\0' in raw;bad=not binary and (any(line.endswith((b' ',b'\t',b'\r')) for line in raw.split(b'\n')) or raw.endswith(b'\n\n'))
 if not tracked and (ignored or bad):
  z=pack/(str(len(rows)).zfill(3)+'-'+p.name+'.gz');z.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(z.read_bytes())==raw;rows.append({'original_path':str(p),'raw_sha256':sha(raw),'raw_bytes':len(raw),'gzip_path':str(z),'gzip_sha256':sha(z.read_bytes()),'original_retained_unmodified':True});safe.append(z)
 else:safe.append(p)
manifest=pack/'manifest.json';manifest.write_text(json.dumps({'rule':'Lossless frozen-input packaging only; originals retained. Canonical mutable audit staged directly. Phase2 in progress not staged.','files':rows},indent=2)+'\n');safe += [manifest,ap]
subprocess.run(['git','add','--',*[str(p) for p in safe]],check=True)
r=subprocess.run(['git','diff','--cached','--check'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT);print(r.stdout.decode());assert r.returncode==0;assert subprocess.check_output(['git','show',':'+str(ap)])==ap.read_bytes()
print(json.dumps({'owned_paths_staged':len(safe),'frozen_raw_packaged':len(rows),'canonical_audit_exactly_staged':True,'sourceV':False,'phase2_and_otherrole_ongoing_files_not_staged':True}))
