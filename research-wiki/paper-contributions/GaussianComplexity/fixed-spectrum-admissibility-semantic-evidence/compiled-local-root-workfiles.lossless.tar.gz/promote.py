from pathlib import Path
import json,hashlib
b=Path('.astis/huanjian-fixed-spectrum-admissibility-20261107');ev=Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-admissibility-semantic-evidence');sha=lambda v:hashlib.sha256(v).hexdigest();raw=(b/'Proof.lean').read_bytes();assert sha(raw)=='d9ebc6908ca5e3a3775f02ea6e67adc07feb7d4ca9fdf0996ecb399815755b64';r=json.loads(Path('.astis/huanjian-resume-20261103/20261107T144816332991Z-fixed-spectrum-admissibility-canonical-real-star-instance.receipt.json').read_bytes());assert r['exit_code']==0;sig=(ev/'candidate-exact-signature.txt').read_text();assert sha(sig.encode())=='186231307d4c41acba15a1098c56518120394295cf048f504fed6f8ea50018d5';s=raw.decode();assert sig.rstrip() in s
namespace='namespace AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumAdmissibility';doc='''/-!
# Actual cosine-grid precision admissibility

Zhou--Suzuki, arXiv:2610.20492v1, Eq11 and Lemma4.6. The literal
cosine-grid precision is used for every full real orthogonal O, with exactly
source d>=2 and kappa>=2. The two matrix differences are positive semidefinite
in quadratic-form order, and positive definiteness is produced internally.
The source dimension binder is deliberately retained even though the scalar
cosine envelope and matrix bound proof work for every choice of angles.

The actual inverse-precision Gaussian law-density consumer is in the focused
Test and reuses the existing canonical GaussianPrecisionDensity leaf. No
calculus, known-normalizer product, moment/Krylov, algorithm/TV/cost transport
or main-lower-bound completion is asserted by this pointwise matrix result.
-/

''';s=s.replace(namespace,doc+namespace,1);prod=Path('AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumAdmissibility.lean');assert not prod.exists();prod.write_text(s)
cs=(ev/'actual-consumer-interface/exact-consumer-signature.txt').read_text();assert sha(cs.encode())=='ef756379bce4efb8c2b4a323b2bb5aaa626bb2a4195ee5da09321f20f6c0c870';test=Path('Tests/GaussianComplexityFixedSpectrumAdmissibility.lean');assert not test.exists();head='''import AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumAdmissibility
import AutoSamplingTheory.TechnicalLemmas.Measure.GaussianPrecisionDensity
import Mathlib.Tactic.Ring

open Matrix MeasureTheory ProbabilityTheory
open AutoSamplingTheory.ExampleCases.GaussianComplexity
open AutoSamplingTheory.TechnicalLemmas.Measure.GaussianPrecisionDensity
set_option autoImplicit false

/-- Source one-based i-1/2 equals the actual Fin d half-grid. This is a
meaning adapter, not an extra public premise or a new Registry lemma. -/
example {d : ℕ} (i : Fin d) :
    ((i.val : ℝ) + 1 / 2) * Real.pi / (d : ℝ) =
      (((i.val : ℝ) + 1) - 1 / 2) * Real.pi / (d : ℝ) := by
  ring

/-- A genuine actual Gaussian consumer. Its only mathematical inputs are the
source d/kappa/full-O; positivity is obtained from the new producer, never
supplied as an hPD or correct-density premise. -/
''';body=''' := by
  show_term exact multivariateGaussian_eq_withDensity_of_posDef _
    ((FixedSpectrumAdmissibility.actual_precision_admissible hd hκ O).1)

#print axioms FixedSpectrumAdmissibility.actual_precision_admissible
#print axioms multivariateGaussian_eq_withDensity_of_posDef
open Lean in
run_cmd do
  let env ← getEnv
  let some info := env.find? `AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumAdmissibility.actual_precision_admissible | throwError "Missing actual cosine precision admissibility theorem"
  let some proof := info.value? (allowOpaque := true) | throwError "Missing actual admissibility proof"
  let parents := proof.getUsedConstants.filter fun n => n.toString.startsWith "AutoSamplingTheory"
  logInfo m!"ACTUAL COMPILED ASTIS PARENTS {parents}"
''';test.write_text(head+cs.rstrip()+body);print(json.dumps({'production':str(prod),'production_raw_sha256':sha(prod.read_bytes()),'Test':str(test),'Test_raw_sha256':sha(test.read_bytes()),'source_signature_unchanged':True,'actual_consumer_uses_new_produced_PosDef':True,'shared_root_Registry_or_site_edited':False}))
