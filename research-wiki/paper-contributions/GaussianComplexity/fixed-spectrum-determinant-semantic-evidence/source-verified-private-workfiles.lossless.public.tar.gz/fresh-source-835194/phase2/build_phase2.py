from pathlib import Path
import hashlib
import json
from datetime import datetime, timezone

ROOT = Path('/Users/zhouhuanjian/ASTIS-GC')
BASE = ROOT / '.astis/huanjian-fixed-spectrum-determinant-20261108/fresh-source-835194/phase2'
INPUT_REL = 'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-determinant-semantic-evidence/phase2-selective-input.json'
EXPECTED_RAW = '524c23dd2fdd5e98c2e11c37de7f3aae4a3d7eb06e577700696e157ed103f38e'
PHASE1_MANIFEST = '8ad4cf3e03e191f570b02867ea8422b4b29282c46bb718ade51825de2366a3cc'
SOURCE_SHA = '6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()

def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

raw = (ROOT / INPUT_REL).read_bytes()
assert sha(raw) == EXPECTED_RAW
packet = json.loads(raw)
anon = packet['anonymous_decoder_packet']
blind = packet['blind_reconstruction']
packet_sha = sha(canonical({k:v for k,v in anon.items() if k != 'packet_sha256'}))
statement_sha = sha(anon['lean']['statement'].encode())
reconstruction_sha = sha(blind['reconstructed_theorem_text'].encode())
assert packet_sha == anon['packet_sha256'] == blind['packet_sha256']
assert statement_sha == anon['lean']['statement_sha256']
assert reconstruction_sha == blind['reconstructed_text_sha256']
assert packet['provenance']['source_fresh_phase1_manifest_raw_sha256'] == PHASE1_MANIFEST

BASE.mkdir(parents=True, exist_ok=True)
inputs = BASE / 'inputs'
inputs.mkdir(exist_ok=True)
(inputs / 'phase2-selective-input.json').write_bytes(raw)
(inputs / 'anonymous-statement.txt').write_text(anon['lean']['statement'])
write_json(inputs / 'approved-definition-context.json', anon['lean']['approved_definition_context'])
(inputs / 'reconstructed-theorem.txt').write_text(blind['reconstructed_theorem_text'])
write_json(inputs / 'blind-reconstruction.json', blind)

slot_results = {
 'objects': {
  'classification': 'equivalent-for-bounded-determinant-component',
  'source_contract': 'Actual source precision A=O Lambda O^T, with actual cosine-grid diagonal Lambda, and genuine determinant/product of its entries.',
  'candidate_and_reconstruction': 'The anonymous lets construct the actual matrix A from the same O and actual Matrix.diagonal diagonalValue; the conclusion is the genuine real Matrix.det of that A, not an assumed spectrum/determinant certificate. The blind reconstruction identifies D only as explanatory notation for that actual diagonal matrix.',
  'evidence': 'The anonymous statement and approved definition contexts 3 and 4; blind objects/conclusion/reconstructed_theorem_text; frozen source slots objects and conclusion.',
  'blocking_delta': False
 },
 'domains': {
  'classification': 'equivalent-by-explicit-coordinate-reindexing',
  'source_contract': 'Integer d>=2, real kappa>=2, real d-by-d O in the full orthogonal group; source indices j=1,...,d.',
  'candidate_and_reconstruction': 'Natural d with 2<=d, real kappa with 2<=kappa, full real orthogonalGroup on Fin d. Fin d covers zero-based i=0,...,d-1 exactly once.',
  'translation': 'Set j=i.val+1. Then (j-1/2)*pi/d=(i.val+1/2)*pi/d, and j=1,...,d corresponds bijectively to Fin d. All real matrix and scalar domains agree.',
  'endpoints': 'Both d=2 and kappa=2 remain included. No parity restriction or complex-unitary domain appears.',
  'blocking_delta': False
 },
 'quantifiers': {
  'classification': 'equivalent-for-pointwise-component',
  'source_contract': 'For each allowed d,kappa, for every O in full real O(d), form the actual precision and take its determinant.',
  'candidate_and_reconstruction': 'Universal d with its bound, universal real kappa with its bound, universal full orthogonal O; all lets and conclusion share those inputs. The finite product binds every coordinate.',
  'probability_scope': 'Haar randomness belongs to the source hard-input construction. A deterministic universal determinant identity needs no random draw, almost-sure qualifier, or independence assumption. The reconstruction correctly adds none.',
  'blocking_delta': False
 },
 'assumptions': {
  'classification': 'source-assumptions-preserved-no-selective-excess-found',
  'source_contract': 'd>=2, kappa>=2, literal grid and actual orthogonal conjugation. Determinant invariance/product identities are proof dependencies, not public premises.',
  'candidate_and_reconstruction': 'The only numerical assumptions are the displayed source bounds. Orthogonal membership supplies matrix typing and orthogonality. No eigenvalue, determinant, integrability, positivity, public-spectrum, or normalizer certificate is supplied.',
  'orthogonality_adapter': 'The source defines square O(d) by O^T O=I. The approved carrier context gives both O^T O=I and O O^T=I. For finite real square matrices the second identity follows from the first, so this is equivalent orthogonal typing rather than an extra mathematical restriction.',
  'binder_classification': {'d_natural': 'TYPING', 'hd_2_le_d': 'SOURCE', 'kappa_real': 'TYPING', 'hkappa_2_le_kappa': 'SOURCE', 'O_full_real_orthogonal': 'SOURCE/TYPING', 'local_lets': 'literal defined source objects, not assumptions'},
  'blocking_delta': False
 },
 'conclusion': {
  'classification': 'faithful-scoped-component-not-full-normalizer-statement',
  'source_contract': 'The bounded direct algebraic consequence is det(actual A)=det(Lambda)=product lambda_i>0. C.4 separately displays the Gaussian normalizer and states its independence of O and conditional knowledge.',
  'candidate_and_reconstruction': 'The theorem asserts det(actual A)=product diagonalValue_i. Via the exact index translation this is precisely the source determinant/product equality component.',
  'omissions_and_scope': [
   'No explicit positivity conclusion is asserted. Positivity is a source consequence, but omitting it does not change the asserted determinant equality. This statement alone is not publication coverage of the strict-eigenvalue or positive-definiteness obligations.',
   'The intermediate equality det(Lambda)=product lambda_i is not a second theorem clause; the literal diagonal construction and approved genuine determinant semantics make the product the intended diagonal determinant. Full implementation consistency remains deferred.',
   'There is no Z, integral, density, optimization, sampling, probability, or query lower-bound conclusion. None may be credited from this selective statement alone.'
  ],
  'blocking_delta_for_bounded_component': False,
  'blocking_if_mislabeled_as': ['actual Gaussian integral evaluation', 'known Gaussian normalizer theorem', 'full C.4', 'Theorem 4.1 lower bound']
 },
 'scopes_senses': {
  'classification': 'equivalent-for-determinant-sense-with-explicit-coverage-boundary',
  'source_contract': 'Actual precision; full real O(d), both determinant signs; pointwise identity; no change of reference measure.',
  'candidate_and_reconstruction': 'Approved definitions explicitly give the full real orthogonal group and genuine determinant. The reconstructed equality covers either sign and uses the actual conjugated matrix. No measure or probability law occurs.',
  'normalization_boundary': 'The frozen source contract labels the Euclidean Lebesgue integral interpretation as inference from the original Gaussian context. This determinant-only statement neither needs nor certifies that measure interpretation. It cannot be silently promoted to an integral under Lebesgue, Gaussian probability, or Haar measure.',
  'blocking_delta': False
 },
 'constant_dependencies': {
  'classification': 'exact-after-reindexing-no-new-constant',
  'source_contract': 'Exact half-step grid; coefficients (kappa+1)/2 and (kappa-1)/2; determinant/product depends on d,kappa and is invariant in O.',
  'candidate_and_reconstruction': 'Real casts and real one-half/division give the exact half-step grid under j=i+1. Usual Real.pi and Real.cos are used. Lambda and the right-hand product depend only on d,kappa; no unspecified constant, algorithmic parameter, delta or epsilon occurs.',
  'real_power_scope': 'The statement contains no fractional-power normalizer. The source exponents d/2 and -1/2 therefore are outside this theorem rather than misformalized in it.',
  'blocking_delta': False
 }
}

comparison = {
 'schema_version': 1,
 'phase': 'PHASE2_SELECTIVE_COMPARISON_SECOND_FREEZE',
 'reviewer': '/root/reader_835194',
 'formalizer': '/root',
 'decoder': blind['decoder'],
 'phase1_manifest_sha256': PHASE1_MANIFEST,
 'phase1_source_sha256': SOURCE_SHA,
 'phase2_raw_input_sha256': EXPECTED_RAW,
 'anonymous_packet_sha256': packet_sha,
 'anonymous_statement_sha256': statement_sha,
 'blind_reconstructed_text_sha256': reconstruction_sha,
 'blind_decoder_run_sha256_as_supplied': blind['decoder_run_sha256'],
 'selective_result': 'No blocking semantic delta found for the bounded actual-precision determinant/eigenvalue-product component under the approved definition contexts. This is a selective statement-level comparison, not a full-module source review or canonical audit decision.',
 'seven_slots': slot_results,
 'classifications': [
  {'id': 'index-origin', 'type': 'representation-equivalence', 'blocking': False, 'detail': 'Source j=1,...,d versus Fin d i=0,...,d-1; exact j=i+1 bijection preserves every angle and product factor.'},
  {'id': 'orthogonal-carrier', 'type': 'typing-equivalence', 'blocking': False, 'detail': 'Both square inverse equations in the approved orthogonal group carrier are equivalent to the source one-equation orthogonal definition.'},
  {'id': 'actual-matrix-semantics', 'type': 'source-object-preserved', 'blocking': False, 'detail': 'The theorem constructs actual O diag(lambda) O^T and applies genuine determinant to it; no determinant/eigenvalue result is supplied as a premise.'},
  {'id': 'pointwise-versus-Haar', 'type': 'source-pointwise-component', 'blocking': False, 'detail': 'The determinant identity is universal on full O(d); omitting the random hard-input draw is appropriate for this pointwise component.'},
  {'id': 'positivity-coverage', 'type': 'narrower-conclusion-coverage', 'blocking': False, 'detail': 'No separate positivity/eigenvalue-bounds conclusion appears; those source obligations remain outside statement coverage.'},
  {'id': 'normalizer-and-integral-coverage', 'type': 'outside-selected-component', 'blocking': False, 'detail': 'The anonymous statement makes no Z, Gaussian integral, reference-measure or density assertion. A publication that attributes those results to this statement alone would exceed its conclusion.'},
  {'id': 'whole-proof-boundary', 'type': 'outside-selected-component', 'blocking': False, 'detail': 'Full C.4 and the main lower bound remain separate source obligations.'},
  {'id': 'full-module-consistency', 'type': 'deferred-to-phase3', 'blocking': None, 'detail': 'Actual production definitions, full theorem context, proof, module scope and authored source claims have not been exposed. Approved contexts are the only definition semantics checked at this stage.'}
 ],
 'blind_reconstruction_assessment': {
  'semantic_accuracy': 'The genuine supplied blind reconstruction accurately expands the anonymous statement into the actual finite-dimensional determinant theorem, with exact index origin, bounds, full orthogonal group and no additional source claims.',
  'independence_evidence': 'The supplied exposure manifest reports that the distinct decoder used only its neutral input and saw no source. This reviewer observed only that manifest inside the approved selective file; no external decoder artifact or path was opened.',
  'hash_checks_performed_here': ['raw selective input', 'canonical anonymous packet', 'statement string', 'reconstructed theorem string'],
  'hashes_not_independently_verified_here': ['decoder run file', 'external neutral input file', 'external canonical reconstruction file'],
  'compile_metadata_boundary': 'The input says compiled=true. This reviewer did not run Lean or inspect production code; the flag is not used as evidence of source fidelity.'
 },
 'remaining_before_any_full_review': ['Phase3 authorization', 'full production module and theorem-scope consistency', 'proof/publication context if explicitly supplied', 'comparison of actual authored coverage claims against this determinant-only boundary'],
 'no_canonical_mutation': True,
 'no_final_fidelity_verdict': True
}
write_json(BASE / 'selective-comparison.json', comparison)

report = r'''# Phase 2 selective source comparison

Reviewer `/root/reader_835194`; decoder `/root/decode_627304`; proving actor
`/root`. This is the second freeze before full-module exposure.

The frozen raw-source contract remains the independent baseline. The only new
input opened is the authorized `phase2-selective-input.json`, raw SHA-256
`524c23dd2fdd5e98c2e11c37de7f3aae4a3d7eb06e577700696e157ed103f38e`.

The anonymous statement and genuine independent reconstruction preserve the
bounded **actual-precision determinant/eigenvalue-product component**. No
blocking semantic delta is found for that component under the supplied
approved definition contexts. This does not issue a full-module fidelity
verdict or certify any normalizer/integral claim.

| Slot | Selective comparison |
|---|---|
| Objects | The actual (A=Ooperatorname{diag}(lambda)O^	op) is built locally and its genuine determinant is used. No conclusion-shaped determinant/eigenvalue premise is supplied. |
| Domains | (dinmathbb N, dge2), real (kappage2), and the full real orthogonal group match the source, including both determinant signs and both endpoints. |
| Quantifiers | Every allowed (d,kappa,O); every coordinate appears exactly once. The source random input draw is unnecessary to this pointwise identity. |
| Assumptions | The source numerical bounds are preserved. The square orthogonal carrier's two inverse identities are equivalent to the source one-equation definition. No integrability, spectrum-public or normalizer assumption appears. |
| Conclusion | Exactly the equality between the actual precision determinant and the full grid product. Separate positivity and normalization conclusions are outside its coverage. |
| Scopes/senses | Genuine determinant, full real (O(d)), no orientation filter, no absolute determinant, no probability/measure assertion. |
| Constants | Exact half-step grid, real fractions/casts, usual real (pi) and cosine. No additional constants or statistical parameters. |

The one-based source index (j=1,ldots,d) and anonymous zero-based index
(i=0,ldots,d-1) match by (j=i+1):

[
rac{(j-	frac12)pi}{d}
=rac{(i+	frac12)pi}{d}.
]

This bijection also preserves every factor in the finite product. All local
definitions use the same dimension, parameter and orthogonal element.

The source C.4 Gaussian normalizer, its unweighted integral interpretation,
conditional knowledge from a public spectrum, and actual density are absent
from the anonymous conclusion. This absence is appropriate to a bounded
determinant component; attributing those further results to this theorem alone
would exceed its content. The source real powers (d/2) and (-1/2) do not
occur in this determinant-only statement and receive no implementation
certification here. Full C.4 and the main query lower bound remain separate.

The blind reconstruction accurately states the anonymous theorem. Its
source-blind exposure is reported in the authorized file by the distinct
decoder; this reviewer has not opened the external neutral input or decoder
run. The raw approved-input, canonical packet, statement-string and
reconstruction-string hashes were recomputed and match. The supplied
`compiled=true` metadata has not been independently rechecked and is not
source-fidelity evidence.

Full production definitions, proof, module scope, canonical audit, authored
prose and publication coverage remain unexposed. Their consistency with this
selective statement and its approved contexts is deferred until explicit
Phase 3 authorization. No ledger, registry or shared file was changed. All
Phase 2 outputs are confined to the reviewer's previously authorized private
directory; the Phase 1 freeze is untouched.
'''
(BASE / 'selective-comparison.md').write_text(report)

exposure = {
 'schema_version': 1,
 'reviewer': '/root/reader_835194',
 'phase': 'PHASE2_SELECTIVE_ONLY',
 'phase1_prior_frozen_context': {'manifest_sha256': PHASE1_MANIFEST, 'source_sha256': SOURCE_SHA, 'material': 'Own already frozen source contract and seven slots retained in conversation context; no phase1 artifact or raw source was reopened in phase2.'},
 'new_external_content_paths_read': [INPUT_REL],
 'new_external_raw_input_sha256': EXPECTED_RAW,
 'read_operations': [
  'One tool invocation ran shasum -a 256 and cat on the single authorized selective input: hash read and full content read.',
  'The phase2 builder read the same authorized input once as bytes to verify, snapshot, parse and recompute its embedded hashes.',
  'Subsequent integrity verification, if performed, is restricted to newly created own phase2 outputs and snapshots.'
 ],
 'exposed_fields': ['anonymous Lean statement', 'five plain approved definition contexts', 'anonymous packet metadata/output contract', 'genuine supplied blind reconstruction and its exposure/hash metadata', 'supplied provenance including external path strings and prior phase1 hash'],
 'embedded_path_strings_are_not_file_reads': True,
 'full_new_input_copied_losslessly_to': str((inputs / 'phase2-selective-input.json').relative_to(ROOT)),
 'no_material_inspected': ['production module','Tests','proof','canonical semantic audit','authored prose/lessons','publication metadata','old verdicts','full reviewer packet','source graphs','other reviewer outputs','critical ancestry','git status/diff/log','external decoder run/input paths','Mathlib or local APIs'],
 'no_tools_run': ['Lean compiler','publication/audit tools','web','git','repository search'],
 'write_scope': str(BASE.relative_to(ROOT)),
 'phase1_modified': False,
 'shared_state_modified': False,
 'stop_boundary': 'Stop after this second freeze; wait for explicit phase3 followup before any full-code/prose/critical-ancestry exposure.'
}
write_json(BASE / 'exposure-log.json', exposure)

input_manifest = {
 'original_path': INPUT_REL,
 'raw_input_sha256': EXPECTED_RAW,
 'raw_snapshot': str((inputs / 'phase2-selective-input.json').relative_to(ROOT)),
 'raw_snapshot_lossless': True,
 'derived_snapshots': [
  {'path': str((inputs / 'anonymous-statement.txt').relative_to(ROOT)), 'transformation': 'Exact decoded JSON string bytes in UTF-8, no added newline.', 'sha256': statement_sha},
  {'path': str((inputs / 'reconstructed-theorem.txt').relative_to(ROOT)), 'transformation': 'Exact decoded JSON string bytes in UTF-8, no added newline.', 'sha256': reconstruction_sha},
  {'path': str((inputs / 'approved-definition-context.json').relative_to(ROOT)), 'transformation': 'Parsed JSON value, ensure_ascii=False, indent=2 plus final newline; full original bytes preserved by raw snapshot.'},
  {'path': str((inputs / 'blind-reconstruction.json').relative_to(ROOT)), 'transformation': 'Parsed JSON value, ensure_ascii=False, indent=2 plus final newline; full original bytes preserved by raw snapshot.'}
 ],
 'recomputed_hashes': {'canonical_anonymous_packet_sha256': packet_sha, 'statement_sha256': statement_sha, 'reconstructed_theorem_sha256': reconstruction_sha},
 'earlier_freeze_reference': {'phase1_manifest_sha256': PHASE1_MANIFEST, 'source_sha256': SOURCE_SHA, 'no_reread_in_phase2': True}
}
write_json(BASE / 'input-manifest.json', input_manifest)

artifacts=[]
for path in sorted(BASE.rglob('*')):
    if path.is_file() and path.name not in {'phase2-manifest.json','freeze-receipt.json'}:
        data=path.read_bytes()
        artifacts.append({'path':str(path.relative_to(ROOT)), 'sha256':sha(data), 'bytes':len(data)})
manifest={
 'schema_version':1,
 'freeze_id':'fresh-source-reader-835194-PHASE2-v1',
 'frozen_at_utc':datetime.now(timezone.utc).isoformat(),
 'phase1_manifest_sha256':PHASE1_MANIFEST,
 'phase2_raw_input_sha256':EXPECTED_RAW,
 'source_sha256':SOURCE_SHA,
 'scope':'Selective anonymous statement/approved definitions/genuine independent reconstruction comparison only, before full module/prose/critical ancestry.',
 'artifacts':artifacts,
 'manifest_hash_rule':'Manifest excludes itself and the receipt; receipt binds its exact bytes.'
}
write_json(BASE / 'phase2-manifest.json',manifest)
receipt={'freeze_id':manifest['freeze_id'], 'phase1_manifest_sha256':PHASE1_MANIFEST,'phase2_raw_input_sha256':EXPECTED_RAW}
for key,path in [
 ('manifest_sha256',BASE/'phase2-manifest.json'),
 ('comparison_sha256',BASE/'selective-comparison.json'),
 ('comparison_prose_sha256',BASE/'selective-comparison.md'),
 ('exposure_log_sha256',BASE/'exposure-log.json'),
 ('input_manifest_sha256',BASE/'input-manifest.json')]:
    receipt[key]=sha(path.read_bytes())
write_json(BASE/'freeze-receipt.json',receipt)
print(json.dumps(receipt,indent=2))
