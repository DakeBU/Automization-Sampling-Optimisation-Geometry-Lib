"""Source-only UTF-8 HTML locator/extractor; no repository mathematics imported."""
from html.parser import HTMLParser
from html import unescape
from pathlib import Path
import bisect
import hashlib
import json
import sys

SOURCE = Path('.astis/huanjian-resume-20261103/2610.20492v1.html')
VOID = {'area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr'}

class Element:
    def __init__(self, tag, attrs, start):
        self.tag, self.attrs, self.start = tag, dict(attrs), start
        self.end = None
        self.children = []

class SourceParser(HTMLParser):
    def __init__(self, source):
        super().__init__(convert_charrefs=True)
        self.source = source
        self.lines = [0] + [i+1 for i,c in enumerate(source) if c == '\n']
        self.root = Element('root', [], 0)
        self.stack = [self.root]
        self.ids = {}
        self.feed(source)
        self.root.end = len(source)
    def source_offset(self):
        line, col = self.getpos()
        return self.lines[line-1] + col
    def handle_starttag(self, tag, attrs):
        e = Element(tag, attrs, self.source_offset())
        self.stack[-1].children.append(e)
        if e.attrs.get('id'): self.ids[e.attrs['id']] = e
        if tag in VOID:
            e.end = e.start + len(self.get_starttag_text())
        else:
            self.stack.append(e)
    def handle_startendtag(self, tag, attrs):
        self.handle_starttag(tag,attrs)
        if tag not in VOID:
            e = self.stack.pop()
            e.end = e.start + len(self.get_starttag_text())
    def handle_endtag(self, tag):
        idx = next((i for i in range(len(self.stack)-1, 0, -1) if self.stack[i].tag == tag), None)
        if idx is None: return
        end = self.source.index('>', self.source_offset())+1
        for e in self.stack[idx:]: e.end = end
        self.stack = self.stack[:idx]
    def handle_data(self,data): self.stack[-1].children.append(data)
    def text(self,e):
        if isinstance(e,str): return e
        if e.tag == 'math': return ' $'+e.attrs.get('alttext','MISSING_ALTTEXT')+'$ '
        if e.tag in {'script','style'}: return ''
        return ' '.join(self.text(c) for c in e.children)
    def normalized_text(self,e): return ' '.join(self.text(e).split())
    def descendants(self,e):
        for c in e.children:
            if not isinstance(c,str):
                yield c
                yield from self.descendants(c)
    def locator(self,e):
        assert e.end is not None
        raw = self.source[e.start:e.end]
        raw_bytes = raw.encode('utf-8')
        firstline = bisect.bisect_right(self.lines,e.start)
        lastline = bisect.bisect_right(self.lines,e.end-1)
        return {
            'id':e.attrs.get('id'), 'tag':e.tag,
            'char_range_half_open':[e.start,e.end],
            'byte_range_half_open':[len(self.source[:e.start].encode('utf-8')),len(self.source[:e.end].encode('utf-8'))],
            'line_range_inclusive_1based':[firstline,lastline],
            'start_column_0based':e.start-self.lines[firstline-1],
            'raw_utf8_bytes':len(raw_bytes),
            'raw_sha256':hashlib.sha256(raw_bytes).hexdigest(),
            'normalized_text':self.normalized_text(e)
        }

def read():
    raw = SOURCE.read_bytes()
    return raw, SourceParser(raw.decode('utf-8'))

if __name__ == '__main__':
    raw,p = read()
    for ident in sys.argv[1:]:
        e=p.ids.get(ident)
        print('\n### '+ident)
        print(p.normalized_text(e) if e else 'MISSING')
