import contextlib
import hashlib
import io
import json
import subprocess
import sys
import time
import traceback
from pathlib import Path

ROOT=Path('/Users/zhouhuanjian/ASTIS-GC')
sys.path.insert(0,str(ROOT))
BASE=ROOT/'research-wiki/paper-contributions/GaussianComplexity/affinity-tensorization-semantic-evidence/fresh-source-module-review'
DECL='AutoSamplingTheory.ExampleCases.GaussianComplexity.AffinityTensorization.actual_affinity_tensorization'
sha=lambda b:hashlib.sha256(b).hexdigest()

def put(name,v):(BASE/name).write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')

def main():
    started=time.time()
    audit_path=ROOT/'research-wiki/semantic-roundtrip/audits/huanjian-affinity-tensorization.json'
    audit_before=audit_path.read_bytes()
    assert sha(audit_before)=='54d514e0ef022d17201311a28f1eb59366ee9ac0a217b215ef33c05b4224cd87'
    for name in ['review-run-v1.json','review-run-v2.json']:
        run=json.loads((BASE/name).read_text())
        for item in run['artifacts']:
            assert sha((ROOT/item['path']).read_bytes())==item['sha256'],item['path']
    for label in ['candidate-source','test-source','product-parent-source','mixture-parent-source']:
        r=json.loads((BASE/(label+'.receipt.json')).read_text())
        assert r['exit_code']==0
        assert sha((ROOT/r['log_path']).read_bytes())==r['log_sha256']
        source=ROOT/r['command'][-1]
        assert sha(source.read_bytes())==r['source_sha256_before']==r['source_sha256_after']
        assert 'head_before' not in r and 'head_after' not in r
    probe=json.loads((BASE/'anonymous-equivalence-and-axioms.receipt.json').read_text())
    assert probe['exit_code']==0
    assert sha((BASE/'anonymous-equivalence-and-axioms.log').read_bytes())==probe['log_sha256']
    probe_log=(BASE/'anonymous-equivalence-and-axioms.log').read_text()
    assert probe_log.count('depends on axioms: [propext,')==4
    assert 'sorryAx' not in probe_log
    assert 'Classical.choice' in probe_log and 'Quot.sound' in probe_log
    scan=json.loads((BASE/'fake-closure-scan-v1.json').read_text())
    assert scan['blocking_matches']==0
    for item in scan['files']:assert sha((ROOT/item['path']).read_bytes())==item['sha256']
    put('frozen-evidence-revalidation-v2.json',{
        'status':'passed','frozen_v1_and_v2_run_artifact_hashes_all_match':True,
        'four_direct_source_receipts_exit_zero_and_exact_input_log_hashes_match':True,
        'anonymous_equivalence_and_recursive_axiom_log_hash_matches':True,
        'axioms_exact':['propext','Classical.choice','Quot.sound'],
        'fake_closure_scan_blocking_matches':0,'actual_current_module_bytes_match_reviewed_source':True,
        'no_compilation_head_inferred_from_receipts':True,'no_repeated_Lean_compilation':True,
        'scope':'Revalidation of actual prior compiler evidence and exact hashes, not an additional compiler run or root gate.'})

    cmd=[sys.executable,'tools/astis_semantic_roundtrip.py','check']
    t=time.time();p=subprocess.run(cmd,cwd=ROOT,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    b=p.stdout.encode();(BASE/'postprojection-semantic-v2.log').write_bytes(b)
    put('postprojection-semantic-v2.receipt.json',{'command':cmd,'exit_code':p.returncode,'elapsed_seconds':time.time()-t,
        'log_sha256':sha(b),'canonical_audit_sha256':sha(audit_before),'actual_current_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
        'scope':'Real complete merged semantic registry validation; no compilation-HEAD claim.'})
    print('SEMANTIC',p.returncode,p.stdout.strip(),flush=True)
    if p.returncode:return p.returncode

    from tools import astis_publication as publication
    output=io.StringIO();t=time.time();code=0
    with contextlib.redirect_stdout(output),contextlib.redirect_stderr(output):
        try:
            publication.check_advance([DECL],reviewed=True)
            print('PASS tools.astis_publication.check_advance([actual_affinity_tensorization], reviewed=True)')
        except Exception:
            traceback.print_exc();code=1
    b=output.getvalue().encode();(BASE/'postprojection-reviewed-publication-v2.log').write_bytes(b)
    put('postprojection-reviewed-publication-v2.receipt.json',{
        'command':'tools.astis_publication.check_advance','declarations':[DECL],'reviewed':True,'exit_code':code,
        'elapsed_seconds':time.time()-t,'log_sha256':sha(b),'canonical_audit_sha256':sha(audit_before),
        'publication_binding_sha256':'9104d934f897b788965a51b8681eb96cf568a43d3a7b7dc5ed743ffe0469533d',
        'scope':'Actual target-only reviewed publication admission; not final root/site/remote publication.'})
    print('REVIEWED_PUBLICATION',code,output.getvalue().strip(),flush=True)
    assert audit_path.read_bytes()==audit_before
    put('postprojection-validation-v2.json',{'semantic_exit_code':p.returncode,'reviewed_publication_exit_code':code,
        'frozen_actual_compiler_and_fake_closure_evidence_revalidated':True,'canonical_audit_sha256':sha(audit_before),
        'canonical_audit_unchanged_during_checks':True,'elapsed_seconds':time.time()-started,'normal_advance_api_called':False})
    return code

if __name__=='__main__':raise SystemExit(main())
