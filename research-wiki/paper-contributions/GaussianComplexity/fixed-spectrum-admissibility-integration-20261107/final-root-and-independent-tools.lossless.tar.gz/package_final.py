from pathlib import Path
import json,hashlib,gzip,subprocess,tarfile,shutil
sha=lambda b:hashlib.sha256(b).hexdigest()
b=Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-admissibility-integration-20261107');checks=b/'actual-gate-and-site-records'
for p in sorted(Path('.astis/huanjian-resume-20261103').glob('*-fixed-spectrum-admissibility-*.receipt.json')):
 if p.name < '20261107T160001':continue
 r=json.loads(p.read_bytes());raw=Path(r['log']).read_bytes();assert sha(raw)==r['log_sha256']
 if (checks/p.name).exists():continue
 shutil.copy2(p,checks/p.name);z=checks/(Path(r['log']).name+'.gz');z.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(z.read_bytes())==raw
private=Path('.astis/huanjian-gc-fixed-spectrum-admissibility-integration-20261107');files=sorted(p for p in private.rglob('*') if p.is_file() and 'browser' not in p.relative_to(private).parts)
archive=b/'final-root-and-independent-tools.lossless.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz') as t:
 for p in files:t.add(p,arcname=str(p.relative_to(private)),recursive=False)
with tarfile.open(archive,'r:gz') as t:
 for p in files:assert t.extractfile(str(p.relative_to(private))).read()==p.read_bytes()
manifest=b/'final-root-and-independent-tools.manifest.json';manifest.write_text(json.dumps({'archive':str(archive),'sha256':sha(archive.read_bytes()),'files':[{'path':str(p),'member':str(p.relative_to(private)),'sha256':sha(p.read_bytes())} for p in files],'all_members_roundtrip_verified':True,'browser_originals':'Separate37memberarchive d9991e7e'},indent=2)+'\n')
paths=sorted(p for p in b.rglob('*') if p.is_file());safe=[];pack=b/'final-frozen-raw-packaging';pack.mkdir(exist_ok=False);rows=[]
for p in paths:
 raw=p.read_bytes();tracked=subprocess.run(['git','ls-files','--error-unmatch','--',str(p)],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode==0
 ignored=subprocess.run(['git','check-ignore','-q','--',str(p)]).returncode==0;binary=p.suffix in ['.gz','.zip','.png'] or b'\0' in raw
 bad=not binary and (any(line.endswith((b' ',b'\t',b'\r')) for line in raw.split(b'\n')) or raw.endswith(b'\n\n'))
 if not tracked and (ignored or bad):
  z=pack/(str(len(rows)).zfill(3)+'-'+p.name+'.gz');z.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(z.read_bytes())==raw;rows.append({'original_path':str(p),'raw_sha256':sha(raw),'raw_bytes':len(raw),'gzip_path':str(z),'gzip_sha256':sha(z.read_bytes()),'original_retained_unmodified':True,'reason':{'ignored':ignored,'frozen_whitespace_or_blank_EOF':bad}});safe.append(z)
 else:safe.append(p)
manifest=pack/'manifest.json';manifest.write_text(json.dumps({'rule':'Only new frozen evidence inside owned integration folder is losslessly packaged. Tracked mutable canonical ledger/frontier/README are staged directly outside this filter, never archived instead of staging their exact changes.','files':rows},indent=2)+'\n');safe.append(manifest)
safe += [Path(x) for x in ['runs/substantive_advances.jsonl','research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-admissibility.json','research-wiki/paper-contributions/GaussianComplexity/README.md']]
subprocess.run(['git','add','--',*[str(p) for p in safe]],check=True)
r=subprocess.run(['git','diff','--cached','--check'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT);print(r.stdout.decode());assert r.returncode==0
for p in safe[-3:]:assert subprocess.check_output(['git','show',':'+str(p)])==p.read_bytes()
print(json.dumps({'owned_paths_staged':len(safe),'new_frozen_raw_losslessly_packaged':len(rows),'all3mutable_canonical_paths_exactly_staged':True,'private_roundtrip_members':len(files),'no_new_build_or_API':True}))
