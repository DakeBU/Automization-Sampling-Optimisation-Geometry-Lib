from pathlib import Path
import sys,json,hashlib,re,html
from html.parser import HTMLParser
sys.dont_write_bytecode=True
ROOT=Path('/Users/zhouhuanjian/ASTIS-GC')
BASE=ROOT/'.astis/semantic-neutral-20261110/src_a74f20/phase3'
SRC=BASE/'native-src'
sys.path[:0]=[str(ROOT/'tools'),str(ROOT/'website/scripts')]
import astis_site as base
import inline_lean,declaration_lessons
base.ROOT=SRC
paths=[SRC/'AutoSamplingTheory/ExampleCases/GaussianComplexity'/x for x in ['FixedSpectrumExactMeans.lean','FixedSpectrumGaussianMoments.lean','FixedSpectrumCosineExpansion.lean','FixedSpectrumGridAlias.lean']]
base.project_lean_paths=lambda:paths
base._ACTIVE_GIT=base.GitContext('d823dddd8b7f203af3191b94ba2eb763fc0edc9b','d823dddd8b7f203af3191b94ba2eb763fc0edc9b','','',False,False,set())
modules,declarations=base.scan_project_sources()
base._SOURCE_BY_NAME={d.full_name:d for d in declarations}
unit=json.loads((SRC/'website/content/declaration_lessons/huanjian-fixed-spectrum-exact-means.json').read_text())['units'][0]
packet=json.loads((BASE/'canonical-reviewer-packet.json').read_text())
article=declaration_lessons.render_unit(unit,'lessons/exact-means-independent-static.html')
target=BASE/'static-reader.html'
target.write_text('<!doctype html><html><head><meta charset="utf-8"><title>Independent static reader check</title></head><body>'+article+'</body></html>')
class Parse(HTMLParser):
 def __init__(self):super().__init__();self.details=[];self.code=[];self.stack=[];self.current=None
 def handle_starttag(self,tag,attrs):
  a=dict(attrs);self.stack.append((tag,a))
  if tag=='details':self.details.append(a)
  if tag=='code':self.current=[]
 def handle_data(self,d):
  if self.current is not None:self.current.append(d)
 def handle_endtag(self,tag):
  if tag=='code' and self.current is not None:self.code.append(''.join(self.current));self.current=None
p=Parse();p.feed(article)
name=unit['declaration'];decl=base._SOURCE_BY_NAME[name]
signature,body=inline_lean.split_statement(inline_lean.display_source(decl.source_text))
formulas=[unit['formula']]+[s['formula'] for s in unit['steps']]+[n['formula'] for n in unit.get('notation',[])]
def brace_balance(t):
 depth=0
 for i,c in enumerate(t):
  if i and t[i-1]=='\\':continue
  if c=='{':depth+=1
  elif c=='}':depth-=1
  if depth<0:return False
 return depth==0
checks={
 'renderer_used_without_aggregate_site_build':True,
 'exact_owned_sources_only_scanned':len(paths)==4,
 'six_authored_formula_steps':len(unit['steps'])==6,
 'all_formulas_present_verbatim_after_HTML_unescape':all(t in html.unescape(article) for t in formulas),
 'all_formula_braces_balanced':all(brace_balance(t) for t in formulas),
 'all_assumptions_present':all(declaration_lessons.inline_text(a) in article for a in unit['assumptions']),
 'all_details_initially_closed':all('open' not in a for a in p.details),
 'exact_full_public_statement_code_present':signature in p.code,
 'exact_full_public_declaration_code_present':inline_lean.display_source(decl.source_text) in p.code,
 'main_formula_before_statement_Lean_fold':article.index('reader-main-equation')<article.index('inline-lean-statement'),
 'proof_fold_after_all_math_steps':article.rindex('inline-lean-proof')>article.index(unit['steps'][-1]['title']),
 'copy_and_download_hooks_present':('data-lean-copy' in article and 'data-lean-copy-status' in article and 'downloads/lean/'+decl.source_file in article),
 'source_links_present':'https://arxiv.org/html/2610.20492v1#A3.Ex138' in article,
 'exact_module_matches_packet':(SRC/decl.source_file).read_text()==packet['candidate_publication_context']['current_lean_module'],
 'main_formula_matches_packet':unit['formula']==packet['candidate_publication_context']['lesson']['formula'],
 'private_consumer_exact_code_present':any('private theorem actual_gaussian_closed_means_bias_ratio' in c for c in p.code),
 'private_consumer_Test_download_hook_present':'downloads/lean/Tests/GaussianComplexityFixedSpectrumExactMeans.lean' in article,
}
tool_paths=['tools/astis_site.py','website/scripts/declaration_lessons.py','website/scripts/inline_lean.py','website/scripts/source_lineage.py']
output={'checks':checks,'detail_count':len(p.details),'exact_code_block_count':len(p.code),'formula_count':len(formulas),'html_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'tool_hashes':{x:hashlib.sha256((ROOT/x).read_bytes()).hexdigest() for x in tool_paths},'formula_verification_boundary':'Static exact TeX preservation and brace balance only. No installed local KaTeX package was present at checked conventional paths, and no browser/network/typesetter was used; actual typesetting and desktop/mobile acceptance deferred.','reader_finding':'The six Corresponding Lean step folds contain authored explanatory prose. Exact producer statement and declaration are present in separate initially closed adjacent folds. The sixth step discusses the private Test consumer but the actual Test consumer code and Test module download are absent. Hold consumer-specific exact adjacent Lean acceptance pending a reader decision/fix; source/native theorem acceptance is independent.','bounded_static_result':'PRODUCER_STRUCTURE_PASS_CONSUMER_ADJACENT_LEAN_HOLD'}
(BASE/'static-reader-checks.json').write_text(json.dumps(output,indent=2,ensure_ascii=False)+'\n')
print(json.dumps(output,indent=2,ensure_ascii=False))
