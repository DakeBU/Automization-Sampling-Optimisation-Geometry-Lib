import Tests.GaussianComplexityMatrixMgfDomain
import Lean
open MeasureTheory ProbabilityTheory Lean Elab Term
open scoped BigOperators Matrix.Norms.L2Operator MatrixOrder ENNReal
noncomputable section
universe u v
elab "native_actual_T" : term => do
  let env ← getEnv
  let found := env.constants.toList.filter fun (n, _) =>
    n.toString.endsWith ".actual_source_four_matrix_mgfs_integrable_posDef_and_trace_bounded"
  unless found.length == 1 do throwError "Expected unique actual private R17 T, found {found.length}"
  return mkConst found.head!.1
namespace NativeLiteralApplications

theorem literal_P :
∀ {ι : Type u} {Ω : Type v} [Fintype ι] [DecidableEq ι] [MeasurableSpace Ω]
  {μ : Measure Ω} [IsProbabilityMeasure μ],
  ∀ (f : Ω → Matrix ι ι ℝ), Integrable f μ →
    (∀ᵐ ω ∂μ, (f ω).PosDef) → (∫ ω, f ω ∂μ).PosDef := by
  intro ι Ω instF instD instM μ instPr f hf hPD
  exact AutoSamplingTheory.TechnicalLemmas.Probability.RealMatrixPositiveDefIntegral.integral_posDef f hf hPD

theorem P_empty_indices {Ω : Type v} [MeasurableSpace Ω]
    {μ : Measure Ω} [IsProbabilityMeasure μ] :
    (∫ _ω : Ω, (0 : Matrix (Fin 0) (Fin 0) ℝ) ∂μ).PosDef := by
  have hp : (0 : Matrix (Fin 0) (Fin 0) ℝ).PosDef := by
    apply Matrix.PosDef.of_dotProduct_mulVec_pos Matrix.isHermitian_zero
    intro x hx
    have hz : x = 0 := by ext i; exact Fin.elim0 i
    exact False.elim (hx hz)
  exact AutoSamplingTheory.TechnicalLemmas.Probability.RealMatrixPositiveDefIntegral.integral_posDef (fun _ : Ω => 0) (integrable_const 0)
    (ae_of_all μ fun _ => hp)

theorem P_singleton_identity {Ω : Type v} [MeasurableSpace Ω]
    {μ : Measure Ω} [IsProbabilityMeasure μ] :
    (∫ _ω : Ω, (1 : Matrix (Fin 1) (Fin 1) ℝ) ∂μ).PosDef := by
  exact AutoSamplingTheory.TechnicalLemmas.Probability.RealMatrixPositiveDefIntegral.integral_posDef (fun _ : Ω => 1) (integrable_const 1)
    (ae_of_all μ fun _ => Matrix.PosDef.one)

def nullBad (x : ℝ) : Matrix (Fin 1) (Fin 1) ℝ := if x = 0 then 1 else 0

theorem P_ae_PD_dirac_null_bad :
    (∫ x : ℝ, nullBad x ∂Measure.dirac (0 : ℝ)).PosDef := by
  apply AutoSamplingTheory.TechnicalLemmas.Probability.RealMatrixPositiveDefIntegral.integral_posDef nullBad (integrable_dirac (by simp))
  simpa only [ae_dirac_eq, Filter.eventually_pure] using
    (show (nullBad 0).PosDef by simpa [nullBad] using
      (Matrix.PosDef.one : (1 : Matrix (Fin 1) (Fin 1) ℝ).PosDef))

theorem null_bad_is_not_pointwise_PD : ¬ ∀ x : ℝ, (nullBad x).PosDef := by
  intro h
  have hp := (h 1).diag_pos (i := (0 : Fin 1))
  norm_num [nullBad] at hp

theorem literal_T :
∀ {d q : ℕ} (hq : 2 * q + 1 < d),
  let D := EuclideanSpace ℝ (Fin d)
  let E := EuclideanSpace ℝ (Fin (q + 1))
  let Ω := Fin (q + 1) → D
  let μ : Measure Ω := Measure.pi (fun _ : Fin (q + 1) => stdGaussian D)
  let M := Matrix (Fin (q + 1) × Fin (q + 1)) (Fin (q + 1) × Fin (q + 1)) ℝ
  let r : ℝ := ((q + 1 : ℕ) : ℝ)
  let L : ℝ := 2 * r + 3 * Real.log (1000 * (d : ℝ))
  let α : Fin d → ℝ := fun i => ((i.val : ℝ) + 1 - 1 / 2) * Real.pi / (d : ℝ)
  let tvec : Fin d → Fin (q + 1) → ℝ := fun i k =>
    if k.val = 0 then 1 else Real.sqrt 2 * Real.cos ((k.val : ℝ) * α i)
  let row : Fin d → Ω → E := fun i ω =>
    WithLp.toLp 2 (fun b : Fin (q + 1) => ω b i)
  let Y : Fin d → Ω → M := fun i ω =>
    if ‖row i ω‖ ^ 2 ≤ L then
      (d : ℝ)⁻¹ • Matrix.kronecker
        (Matrix.vecMulVec (WithLp.ofLp (row i ω)) (WithLp.ofLp (row i ω)))
        (Matrix.vecMulVec (tvec i) (tvec i))
    else 0
  let mean : Fin d → M := fun i => ∫ ω, Y i ω ∂μ
  let Z : Fin d → Ω → M := fun i ω => Y i ω - mean i
  let w : Bool → Fin d → ℝ := fun useCos i =>
    if useCos = true then Real.cos (((2 * q + 1 : ℕ) : ℝ) * α i) else 1
  let sign : Bool → ℝ := fun minus => if minus = true then -1 else 1
  let S : Bool → Bool → Ω → M := fun useCos minus ω =>
    sign minus • ∑ i : Fin d, w useCos i • Z i ω
  let Rstar : ℝ := 2 * r * (L + 1) / (d : ℝ)
  ∀ s : ℝ, ∀ useCos minus : Bool,
    let G : Ω → M := fun ω => NormedSpace.exp (s • S useCos minus ω)
    let MX : M := ∫ ω, G ω ∂μ
    let B : ℝ := r ^ 2 * Real.exp (|s| * ((d : ℝ) * Rstar))
    Integrable G μ ∧ MX.PosDef ∧
      Matrix.trace MX = (∫ ω, Matrix.trace (G ω) ∂μ) ∧
      0 < Matrix.trace MX ∧ Matrix.trace MX ≤ B := by
  intro d q hq
  exact native_actual_T hq

theorem literal_T_q0 {d : ℕ} (hd : 1 < d) :
  let D := EuclideanSpace ℝ (Fin d)
  let E := EuclideanSpace ℝ (Fin (0 + 1))
  let Ω := Fin (0 + 1) → D
  let μ : Measure Ω := Measure.pi (fun _ : Fin (0 + 1) => stdGaussian D)
  let M := Matrix (Fin (0 + 1) × Fin (0 + 1)) (Fin (0 + 1) × Fin (0 + 1)) ℝ
  let r : ℝ := ((0 + 1 : ℕ) : ℝ)
  let L : ℝ := 2 * r + 3 * Real.log (1000 * (d : ℝ))
  let α : Fin d → ℝ := fun i => ((i.val : ℝ) + 1 - 1 / 2) * Real.pi / (d : ℝ)
  let tvec : Fin d → Fin (0 + 1) → ℝ := fun i k =>
    if k.val = 0 then 1 else Real.sqrt 2 * Real.cos ((k.val : ℝ) * α i)
  let row : Fin d → Ω → E := fun i ω =>
    WithLp.toLp 2 (fun b : Fin (0 + 1) => ω b i)
  let Y : Fin d → Ω → M := fun i ω =>
    if ‖row i ω‖ ^ 2 ≤ L then
      (d : ℝ)⁻¹ • Matrix.kronecker
        (Matrix.vecMulVec (WithLp.ofLp (row i ω)) (WithLp.ofLp (row i ω)))
        (Matrix.vecMulVec (tvec i) (tvec i))
    else 0
  let mean : Fin d → M := fun i => ∫ ω, Y i ω ∂μ
  let Z : Fin d → Ω → M := fun i ω => Y i ω - mean i
  let w : Bool → Fin d → ℝ := fun useCos i =>
    if useCos = true then Real.cos (((2 * 0 + 1 : ℕ) : ℝ) * α i) else 1
  let sign : Bool → ℝ := fun minus => if minus = true then -1 else 1
  let S : Bool → Bool → Ω → M := fun useCos minus ω =>
    sign minus • ∑ i : Fin d, w useCos i • Z i ω
  let Rstar : ℝ := 2 * r * (L + 1) / (d : ℝ)
  ∀ s : ℝ, ∀ useCos minus : Bool,
    let G : Ω → M := fun ω => NormedSpace.exp (s • S useCos minus ω)
    let MX : M := ∫ ω, G ω ∂μ
    let B : ℝ := r ^ 2 * Real.exp (|s| * ((d : ℝ) * Rstar))
    Integrable G μ ∧ MX.PosDef ∧
      Matrix.trace MX = (∫ ω, Matrix.trace (G ω) ∂μ) ∧
      0 < Matrix.trace MX ∧ Matrix.trace MX ≤ B := by
  exact native_actual_T (d := d) (q := 0) hd

theorem literal_T_q0_d2 :
  let D := EuclideanSpace ℝ (Fin 2)
  let E := EuclideanSpace ℝ (Fin (0 + 1))
  let Ω := Fin (0 + 1) → D
  let μ : Measure Ω := Measure.pi (fun _ : Fin (0 + 1) => stdGaussian D)
  let M := Matrix (Fin (0 + 1) × Fin (0 + 1)) (Fin (0 + 1) × Fin (0 + 1)) ℝ
  let r : ℝ := ((0 + 1 : ℕ) : ℝ)
  let L : ℝ := 2 * r + 3 * Real.log (1000 * (2 : ℝ))
  let α : Fin 2 → ℝ := fun i => ((i.val : ℝ) + 1 - 1 / 2) * Real.pi / (2 : ℝ)
  let tvec : Fin 2 → Fin (0 + 1) → ℝ := fun i k =>
    if k.val = 0 then 1 else Real.sqrt 2 * Real.cos ((k.val : ℝ) * α i)
  let row : Fin 2 → Ω → E := fun i ω =>
    WithLp.toLp 2 (fun b : Fin (0 + 1) => ω b i)
  let Y : Fin 2 → Ω → M := fun i ω =>
    if ‖row i ω‖ ^ 2 ≤ L then
      (2 : ℝ)⁻¹ • Matrix.kronecker
        (Matrix.vecMulVec (WithLp.ofLp (row i ω)) (WithLp.ofLp (row i ω)))
        (Matrix.vecMulVec (tvec i) (tvec i))
    else 0
  let mean : Fin 2 → M := fun i => ∫ ω, Y i ω ∂μ
  let Z : Fin 2 → Ω → M := fun i ω => Y i ω - mean i
  let w : Bool → Fin 2 → ℝ := fun useCos i =>
    if useCos = true then Real.cos (((2 * 0 + 1 : ℕ) : ℝ) * α i) else 1
  let sign : Bool → ℝ := fun minus => if minus = true then -1 else 1
  let S : Bool → Bool → Ω → M := fun useCos minus ω =>
    sign minus • ∑ i : Fin 2, w useCos i • Z i ω
  let Rstar : ℝ := 2 * r * (L + 1) / (2 : ℝ)
  ∀ s : ℝ, ∀ useCos minus : Bool,
    let G : Ω → M := fun ω => NormedSpace.exp (s • S useCos minus ω)
    let MX : M := ∫ ω, G ω ∂μ
    let B : ℝ := r ^ 2 * Real.exp (|s| * ((2 : ℝ) * Rstar))
    Integrable G μ ∧ MX.PosDef ∧
      Matrix.trace MX = (∫ ω, Matrix.trace (G ω) ∂μ) ∧
      0 < Matrix.trace MX ∧ Matrix.trace MX ≤ B := by
  exact native_actual_T (d := 2) (q := 0) (by norm_num)

theorem allreal_ordinary_positive :
∀ {d q : ℕ} (hq : 2 * q + 1 < d),
  let D := EuclideanSpace ℝ (Fin d)
  let E := EuclideanSpace ℝ (Fin (q + 1))
  let Ω := Fin (q + 1) → D
  let μ : Measure Ω := Measure.pi (fun _ : Fin (q + 1) => stdGaussian D)
  let M := Matrix (Fin (q + 1) × Fin (q + 1)) (Fin (q + 1) × Fin (q + 1)) ℝ
  let r : ℝ := ((q + 1 : ℕ) : ℝ)
  let L : ℝ := 2 * r + 3 * Real.log (1000 * (d : ℝ))
  let α : Fin d → ℝ := fun i => ((i.val : ℝ) + 1 - 1 / 2) * Real.pi / (d : ℝ)
  let tvec : Fin d → Fin (q + 1) → ℝ := fun i k =>
    if k.val = 0 then 1 else Real.sqrt 2 * Real.cos ((k.val : ℝ) * α i)
  let row : Fin d → Ω → E := fun i ω =>
    WithLp.toLp 2 (fun b : Fin (q + 1) => ω b i)
  let Y : Fin d → Ω → M := fun i ω =>
    if ‖row i ω‖ ^ 2 ≤ L then
      (d : ℝ)⁻¹ • Matrix.kronecker
        (Matrix.vecMulVec (WithLp.ofLp (row i ω)) (WithLp.ofLp (row i ω)))
        (Matrix.vecMulVec (tvec i) (tvec i))
    else 0
  let mean : Fin d → M := fun i => ∫ ω, Y i ω ∂μ
  let Z : Fin d → Ω → M := fun i ω => Y i ω - mean i
  let w : Bool → Fin d → ℝ := fun useCos i =>
    if useCos = true then Real.cos (((2 * q + 1 : ℕ) : ℝ) * α i) else 1
  let sign : Bool → ℝ := fun minus => if minus = true then -1 else 1
  let S : Bool → Bool → Ω → M := fun useCos minus ω =>
    sign minus • ∑ i : Fin d, w useCos i • Z i ω
  let Rstar : ℝ := 2 * r * (L + 1) / (d : ℝ)
  ∀ s : ℝ, let useCos := false; let minus := false;
    let G : Ω → M := fun ω => NormedSpace.exp (s • S useCos minus ω)
    let MX : M := ∫ ω, G ω ∂μ
    let B : ℝ := r ^ 2 * Real.exp (|s| * ((d : ℝ) * Rstar))
    Integrable G μ ∧ MX.PosDef ∧
      Matrix.trace MX = (∫ ω, Matrix.trace (G ω) ∂μ) ∧
      0 < Matrix.trace MX ∧ Matrix.trace MX ≤ B := by
  intro d q hq
  dsimp only
  intro s
  exact native_actual_T hq s false false

theorem q0_d2_ordinary_positive_s_zero :
  let D := EuclideanSpace ℝ (Fin 2)
  let E := EuclideanSpace ℝ (Fin (0 + 1))
  let Ω := Fin (0 + 1) → D
  let μ : Measure Ω := Measure.pi (fun _ : Fin (0 + 1) => stdGaussian D)
  let M := Matrix (Fin (0 + 1) × Fin (0 + 1)) (Fin (0 + 1) × Fin (0 + 1)) ℝ
  let r : ℝ := ((0 + 1 : ℕ) : ℝ)
  let L : ℝ := 2 * r + 3 * Real.log (1000 * (2 : ℝ))
  let α : Fin 2 → ℝ := fun i => ((i.val : ℝ) + 1 - 1 / 2) * Real.pi / (2 : ℝ)
  let tvec : Fin 2 → Fin (0 + 1) → ℝ := fun i k =>
    if k.val = 0 then 1 else Real.sqrt 2 * Real.cos ((k.val : ℝ) * α i)
  let row : Fin 2 → Ω → E := fun i ω =>
    WithLp.toLp 2 (fun b : Fin (0 + 1) => ω b i)
  let Y : Fin 2 → Ω → M := fun i ω =>
    if ‖row i ω‖ ^ 2 ≤ L then
      (2 : ℝ)⁻¹ • Matrix.kronecker
        (Matrix.vecMulVec (WithLp.ofLp (row i ω)) (WithLp.ofLp (row i ω)))
        (Matrix.vecMulVec (tvec i) (tvec i))
    else 0
  let mean : Fin 2 → M := fun i => ∫ ω, Y i ω ∂μ
  let Z : Fin 2 → Ω → M := fun i ω => Y i ω - mean i
  let w : Bool → Fin 2 → ℝ := fun useCos i =>
    if useCos = true then Real.cos (((2 * 0 + 1 : ℕ) : ℝ) * α i) else 1
  let sign : Bool → ℝ := fun minus => if minus = true then -1 else 1
  let S : Bool → Bool → Ω → M := fun useCos minus ω =>
    sign minus • ∑ i : Fin 2, w useCos i • Z i ω
  let Rstar : ℝ := 2 * r * (L + 1) / (2 : ℝ)
  let s : ℝ := 0; let useCos := false; let minus := false;
    let G : Ω → M := fun ω => NormedSpace.exp (s • S useCos minus ω)
    let MX : M := ∫ ω, G ω ∂μ
    let B : ℝ := r ^ 2 * Real.exp (|s| * ((2 : ℝ) * Rstar))
    Integrable G μ ∧ MX.PosDef ∧
      Matrix.trace MX = (∫ ω, Matrix.trace (G ω) ∂μ) ∧
      0 < Matrix.trace MX ∧ Matrix.trace MX ≤ B := by
  exact native_actual_T (d := 2) (q := 0) (by norm_num) 0 false false

theorem q0_d2_ordinary_positive_s_negative :
  let D := EuclideanSpace ℝ (Fin 2)
  let E := EuclideanSpace ℝ (Fin (0 + 1))
  let Ω := Fin (0 + 1) → D
  let μ : Measure Ω := Measure.pi (fun _ : Fin (0 + 1) => stdGaussian D)
  let M := Matrix (Fin (0 + 1) × Fin (0 + 1)) (Fin (0 + 1) × Fin (0 + 1)) ℝ
  let r : ℝ := ((0 + 1 : ℕ) : ℝ)
  let L : ℝ := 2 * r + 3 * Real.log (1000 * (2 : ℝ))
  let α : Fin 2 → ℝ := fun i => ((i.val : ℝ) + 1 - 1 / 2) * Real.pi / (2 : ℝ)
  let tvec : Fin 2 → Fin (0 + 1) → ℝ := fun i k =>
    if k.val = 0 then 1 else Real.sqrt 2 * Real.cos ((k.val : ℝ) * α i)
  let row : Fin 2 → Ω → E := fun i ω =>
    WithLp.toLp 2 (fun b : Fin (0 + 1) => ω b i)
  let Y : Fin 2 → Ω → M := fun i ω =>
    if ‖row i ω‖ ^ 2 ≤ L then
      (2 : ℝ)⁻¹ • Matrix.kronecker
        (Matrix.vecMulVec (WithLp.ofLp (row i ω)) (WithLp.ofLp (row i ω)))
        (Matrix.vecMulVec (tvec i) (tvec i))
    else 0
  let mean : Fin 2 → M := fun i => ∫ ω, Y i ω ∂μ
  let Z : Fin 2 → Ω → M := fun i ω => Y i ω - mean i
  let w : Bool → Fin 2 → ℝ := fun useCos i =>
    if useCos = true then Real.cos (((2 * 0 + 1 : ℕ) : ℝ) * α i) else 1
  let sign : Bool → ℝ := fun minus => if minus = true then -1 else 1
  let S : Bool → Bool → Ω → M := fun useCos minus ω =>
    sign minus • ∑ i : Fin 2, w useCos i • Z i ω
  let Rstar : ℝ := 2 * r * (L + 1) / (2 : ℝ)
  let s : ℝ := (-1); let useCos := false; let minus := false;
    let G : Ω → M := fun ω => NormedSpace.exp (s • S useCos minus ω)
    let MX : M := ∫ ω, G ω ∂μ
    let B : ℝ := r ^ 2 * Real.exp (|s| * ((2 : ℝ) * Rstar))
    Integrable G μ ∧ MX.PosDef ∧
      Matrix.trace MX = (∫ ω, Matrix.trace (G ω) ∂μ) ∧
      0 < Matrix.trace MX ∧ Matrix.trace MX ≤ B := by
  exact native_actual_T (d := 2) (q := 0) (by norm_num) (-1) false false

theorem q0_d2_ordinary_positive_s_positive :
  let D := EuclideanSpace ℝ (Fin 2)
  let E := EuclideanSpace ℝ (Fin (0 + 1))
  let Ω := Fin (0 + 1) → D
  let μ : Measure Ω := Measure.pi (fun _ : Fin (0 + 1) => stdGaussian D)
  let M := Matrix (Fin (0 + 1) × Fin (0 + 1)) (Fin (0 + 1) × Fin (0 + 1)) ℝ
  let r : ℝ := ((0 + 1 : ℕ) : ℝ)
  let L : ℝ := 2 * r + 3 * Real.log (1000 * (2 : ℝ))
  let α : Fin 2 → ℝ := fun i => ((i.val : ℝ) + 1 - 1 / 2) * Real.pi / (2 : ℝ)
  let tvec : Fin 2 → Fin (0 + 1) → ℝ := fun i k =>
    if k.val = 0 then 1 else Real.sqrt 2 * Real.cos ((k.val : ℝ) * α i)
  let row : Fin 2 → Ω → E := fun i ω =>
    WithLp.toLp 2 (fun b : Fin (0 + 1) => ω b i)
  let Y : Fin 2 → Ω → M := fun i ω =>
    if ‖row i ω‖ ^ 2 ≤ L then
      (2 : ℝ)⁻¹ • Matrix.kronecker
        (Matrix.vecMulVec (WithLp.ofLp (row i ω)) (WithLp.ofLp (row i ω)))
        (Matrix.vecMulVec (tvec i) (tvec i))
    else 0
  let mean : Fin 2 → M := fun i => ∫ ω, Y i ω ∂μ
  let Z : Fin 2 → Ω → M := fun i ω => Y i ω - mean i
  let w : Bool → Fin 2 → ℝ := fun useCos i =>
    if useCos = true then Real.cos (((2 * 0 + 1 : ℕ) : ℝ) * α i) else 1
  let sign : Bool → ℝ := fun minus => if minus = true then -1 else 1
  let S : Bool → Bool → Ω → M := fun useCos minus ω =>
    sign minus • ∑ i : Fin 2, w useCos i • Z i ω
  let Rstar : ℝ := 2 * r * (L + 1) / (2 : ℝ)
  let s : ℝ := 1; let useCos := false; let minus := false;
    let G : Ω → M := fun ω => NormedSpace.exp (s • S useCos minus ω)
    let MX : M := ∫ ω, G ω ∂μ
    let B : ℝ := r ^ 2 * Real.exp (|s| * ((2 : ℝ) * Rstar))
    Integrable G μ ∧ MX.PosDef ∧
      Matrix.trace MX = (∫ ω, Matrix.trace (G ω) ∂μ) ∧
      0 < Matrix.trace MX ∧ Matrix.trace MX ≤ B := by
  exact native_actual_T (d := 2) (q := 0) (by norm_num) 1 false false

theorem allreal_ordinary_negative :
∀ {d q : ℕ} (hq : 2 * q + 1 < d),
  let D := EuclideanSpace ℝ (Fin d)
  let E := EuclideanSpace ℝ (Fin (q + 1))
  let Ω := Fin (q + 1) → D
  let μ : Measure Ω := Measure.pi (fun _ : Fin (q + 1) => stdGaussian D)
  let M := Matrix (Fin (q + 1) × Fin (q + 1)) (Fin (q + 1) × Fin (q + 1)) ℝ
  let r : ℝ := ((q + 1 : ℕ) : ℝ)
  let L : ℝ := 2 * r + 3 * Real.log (1000 * (d : ℝ))
  let α : Fin d → ℝ := fun i => ((i.val : ℝ) + 1 - 1 / 2) * Real.pi / (d : ℝ)
  let tvec : Fin d → Fin (q + 1) → ℝ := fun i k =>
    if k.val = 0 then 1 else Real.sqrt 2 * Real.cos ((k.val : ℝ) * α i)
  let row : Fin d → Ω → E := fun i ω =>
    WithLp.toLp 2 (fun b : Fin (q + 1) => ω b i)
  let Y : Fin d → Ω → M := fun i ω =>
    if ‖row i ω‖ ^ 2 ≤ L then
      (d : ℝ)⁻¹ • Matrix.kronecker
        (Matrix.vecMulVec (WithLp.ofLp (row i ω)) (WithLp.ofLp (row i ω)))
        (Matrix.vecMulVec (tvec i) (tvec i))
    else 0
  let mean : Fin d → M := fun i => ∫ ω, Y i ω ∂μ
  let Z : Fin d → Ω → M := fun i ω => Y i ω - mean i
  let w : Bool → Fin d → ℝ := fun useCos i =>
    if useCos = true then Real.cos (((2 * q + 1 : ℕ) : ℝ) * α i) else 1
  let sign : Bool → ℝ := fun minus => if minus = true then -1 else 1
  let S : Bool → Bool → Ω → M := fun useCos minus ω =>
    sign minus • ∑ i : Fin d, w useCos i • Z i ω
  let Rstar : ℝ := 2 * r * (L + 1) / (d : ℝ)
  ∀ s : ℝ, let useCos := false; let minus := true;
    let G : Ω → M := fun ω => NormedSpace.exp (s • S useCos minus ω)
    let MX : M := ∫ ω, G ω ∂μ
    let B : ℝ := r ^ 2 * Real.exp (|s| * ((d : ℝ) * Rstar))
    Integrable G μ ∧ MX.PosDef ∧
      Matrix.trace MX = (∫ ω, Matrix.trace (G ω) ∂μ) ∧
      0 < Matrix.trace MX ∧ Matrix.trace MX ≤ B := by
  intro d q hq
  dsimp only
  intro s
  exact native_actual_T hq s false true

theorem q0_d2_ordinary_negative_s_zero :
  let D := EuclideanSpace ℝ (Fin 2)
  let E := EuclideanSpace ℝ (Fin (0 + 1))
  let Ω := Fin (0 + 1) → D
  let μ : Measure Ω := Measure.pi (fun _ : Fin (0 + 1) => stdGaussian D)
  let M := Matrix (Fin (0 + 1) × Fin (0 + 1)) (Fin (0 + 1) × Fin (0 + 1)) ℝ
  let r : ℝ := ((0 + 1 : ℕ) : ℝ)
  let L : ℝ := 2 * r + 3 * Real.log (1000 * (2 : ℝ))
  let α : Fin 2 → ℝ := fun i => ((i.val : ℝ) + 1 - 1 / 2) * Real.pi / (2 : ℝ)
  let tvec : Fin 2 → Fin (0 + 1) → ℝ := fun i k =>
    if k.val = 0 then 1 else Real.sqrt 2 * Real.cos ((k.val : ℝ) * α i)
  let row : Fin 2 → Ω → E := fun i ω =>
    WithLp.toLp 2 (fun b : Fin (0 + 1) => ω b i)
  let Y : Fin 2 → Ω → M := fun i ω =>
    if ‖row i ω‖ ^ 2 ≤ L then
      (2 : ℝ)⁻¹ • Matrix.kronecker
        (Matrix.vecMulVec (WithLp.ofLp (row i ω)) (WithLp.ofLp (row i ω)))
        (Matrix.vecMulVec (tvec i) (tvec i))
    else 0
  let mean : Fin 2 → M := fun i => ∫ ω, Y i ω ∂μ
  let Z : Fin 2 → Ω → M := fun i ω => Y i ω - mean i
  let w : Bool → Fin 2 → ℝ := fun useCos i =>
    if useCos = true then Real.cos (((2 * 0 + 1 : ℕ) : ℝ) * α i) else 1
  let sign : Bool → ℝ := fun minus => if minus = true then -1 else 1
  let S : Bool → Bool → Ω → M := fun useCos minus ω =>
    sign minus • ∑ i : Fin 2, w useCos i • Z i ω
  let Rstar : ℝ := 2 * r * (L + 1) / (2 : ℝ)
  let s : ℝ := 0; let useCos := false; let minus := true;
    let G : Ω → M := fun ω => NormedSpace.exp (s • S useCos minus ω)
    let MX : M := ∫ ω, G ω ∂μ
    let B : ℝ := r ^ 2 * Real.exp (|s| * ((2 : ℝ) * Rstar))
    Integrable G μ ∧ MX.PosDef ∧
      Matrix.trace MX = (∫ ω, Matrix.trace (G ω) ∂μ) ∧
      0 < Matrix.trace MX ∧ Matrix.trace MX ≤ B := by
  exact native_actual_T (d := 2) (q := 0) (by norm_num) 0 false true

theorem q0_d2_ordinary_negative_s_negative :
  let D := EuclideanSpace ℝ (Fin 2)
  let E := EuclideanSpace ℝ (Fin (0 + 1))
  let Ω := Fin (0 + 1) → D
  let μ : Measure Ω := Measure.pi (fun _ : Fin (0 + 1) => stdGaussian D)
  let M := Matrix (Fin (0 + 1) × Fin (0 + 1)) (Fin (0 + 1) × Fin (0 + 1)) ℝ
  let r : ℝ := ((0 + 1 : ℕ) : ℝ)
  let L : ℝ := 2 * r + 3 * Real.log (1000 * (2 : ℝ))
  let α : Fin 2 → ℝ := fun i => ((i.val : ℝ) + 1 - 1 / 2) * Real.pi / (2 : ℝ)
  let tvec : Fin 2 → Fin (0 + 1) → ℝ := fun i k =>
    if k.val = 0 then 1 else Real.sqrt 2 * Real.cos ((k.val : ℝ) * α i)
  let row : Fin 2 → Ω → E := fun i ω =>
    WithLp.toLp 2 (fun b : Fin (0 + 1) => ω b i)
  let Y : Fin 2 → Ω → M := fun i ω =>
    if ‖row i ω‖ ^ 2 ≤ L then
      (2 : ℝ)⁻¹ • Matrix.kronecker
        (Matrix.vecMulVec (WithLp.ofLp (row i ω)) (WithLp.ofLp (row i ω)))
        (Matrix.vecMulVec (tvec i) (tvec i))
    else 0
  let mean : Fin 2 → M := fun i => ∫ ω, Y i ω ∂μ
  let Z : Fin 2 → Ω → M := fun i ω => Y i ω - mean i
  let w : Bool → Fin 2 → ℝ := fun useCos i =>
    if useCos = true then Real.cos (((2 * 0 + 1 : ℕ) : ℝ) * α i) else 1
  let sign : Bool → ℝ := fun minus => if minus = true then -1 else 1
  let S : Bool → Bool → Ω → M := fun useCos minus ω =>
    sign minus • ∑ i : Fin 2, w useCos i • Z i ω
  let Rstar : ℝ := 2 * r * (L + 1) / (2 : ℝ)
  let s : ℝ := (-1); let useCos := false; let minus := true;
    let G : Ω → M := fun ω => NormedSpace.exp (s • S useCos minus ω)
    let MX : M := ∫ ω, G ω ∂μ
    let B : ℝ := r ^ 2 * Real.exp (|s| * ((2 : ℝ) * Rstar))
    Integrable G μ ∧ MX.PosDef ∧
      Matrix.trace MX = (∫ ω, Matrix.trace (G ω) ∂μ) ∧
      0 < Matrix.trace MX ∧ Matrix.trace MX ≤ B := by
  exact native_actual_T (d := 2) (q := 0) (by norm_num) (-1) false true

theorem q0_d2_ordinary_negative_s_positive :
  let D := EuclideanSpace ℝ (Fin 2)
  let E := EuclideanSpace ℝ (Fin (0 + 1))
  let Ω := Fin (0 + 1) → D
  let μ : Measure Ω := Measure.pi (fun _ : Fin (0 + 1) => stdGaussian D)
  let M := Matrix (Fin (0 + 1) × Fin (0 + 1)) (Fin (0 + 1) × Fin (0 + 1)) ℝ
  let r : ℝ := ((0 + 1 : ℕ) : ℝ)
  let L : ℝ := 2 * r + 3 * Real.log (1000 * (2 : ℝ))
  let α : Fin 2 → ℝ := fun i => ((i.val : ℝ) + 1 - 1 / 2) * Real.pi / (2 : ℝ)
  let tvec : Fin 2 → Fin (0 + 1) → ℝ := fun i k =>
    if k.val = 0 then 1 else Real.sqrt 2 * Real.cos ((k.val : ℝ) * α i)
  let row : Fin 2 → Ω → E := fun i ω =>
    WithLp.toLp 2 (fun b : Fin (0 + 1) => ω b i)
  let Y : Fin 2 → Ω → M := fun i ω =>
    if ‖row i ω‖ ^ 2 ≤ L then
      (2 : ℝ)⁻¹ • Matrix.kronecker
        (Matrix.vecMulVec (WithLp.ofLp (row i ω)) (WithLp.ofLp (row i ω)))
        (Matrix.vecMulVec (tvec i) (tvec i))
    else 0
  let mean : Fin 2 → M := fun i => ∫ ω, Y i ω ∂μ
  let Z : Fin 2 → Ω → M := fun i ω => Y i ω - mean i
  let w : Bool → Fin 2 → ℝ := fun useCos i =>
    if useCos = true then Real.cos (((2 * 0 + 1 : ℕ) : ℝ) * α i) else 1
  let sign : Bool → ℝ := fun minus => if minus = true then -1 else 1
  let S : Bool → Bool → Ω → M := fun useCos minus ω =>
    sign minus • ∑ i : Fin 2, w useCos i • Z i ω
  let Rstar : ℝ := 2 * r * (L + 1) / (2 : ℝ)
  let s : ℝ := 1; let useCos := false; let minus := true;
    let G : Ω → M := fun ω => NormedSpace.exp (s • S useCos minus ω)
    let MX : M := ∫ ω, G ω ∂μ
    let B : ℝ := r ^ 2 * Real.exp (|s| * ((2 : ℝ) * Rstar))
    Integrable G μ ∧ MX.PosDef ∧
      Matrix.trace MX = (∫ ω, Matrix.trace (G ω) ∂μ) ∧
      0 < Matrix.trace MX ∧ Matrix.trace MX ≤ B := by
  exact native_actual_T (d := 2) (q := 0) (by norm_num) 1 false true

theorem allreal_cos_positive :
∀ {d q : ℕ} (hq : 2 * q + 1 < d),
  let D := EuclideanSpace ℝ (Fin d)
  let E := EuclideanSpace ℝ (Fin (q + 1))
  let Ω := Fin (q + 1) → D
  let μ : Measure Ω := Measure.pi (fun _ : Fin (q + 1) => stdGaussian D)
  let M := Matrix (Fin (q + 1) × Fin (q + 1)) (Fin (q + 1) × Fin (q + 1)) ℝ
  let r : ℝ := ((q + 1 : ℕ) : ℝ)
  let L : ℝ := 2 * r + 3 * Real.log (1000 * (d : ℝ))
  let α : Fin d → ℝ := fun i => ((i.val : ℝ) + 1 - 1 / 2) * Real.pi / (d : ℝ)
  let tvec : Fin d → Fin (q + 1) → ℝ := fun i k =>
    if k.val = 0 then 1 else Real.sqrt 2 * Real.cos ((k.val : ℝ) * α i)
  let row : Fin d → Ω → E := fun i ω =>
    WithLp.toLp 2 (fun b : Fin (q + 1) => ω b i)
  let Y : Fin d → Ω → M := fun i ω =>
    if ‖row i ω‖ ^ 2 ≤ L then
      (d : ℝ)⁻¹ • Matrix.kronecker
        (Matrix.vecMulVec (WithLp.ofLp (row i ω)) (WithLp.ofLp (row i ω)))
        (Matrix.vecMulVec (tvec i) (tvec i))
    else 0
  let mean : Fin d → M := fun i => ∫ ω, Y i ω ∂μ
  let Z : Fin d → Ω → M := fun i ω => Y i ω - mean i
  let w : Bool → Fin d → ℝ := fun useCos i =>
    if useCos = true then Real.cos (((2 * q + 1 : ℕ) : ℝ) * α i) else 1
  let sign : Bool → ℝ := fun minus => if minus = true then -1 else 1
  let S : Bool → Bool → Ω → M := fun useCos minus ω =>
    sign minus • ∑ i : Fin d, w useCos i • Z i ω
  let Rstar : ℝ := 2 * r * (L + 1) / (d : ℝ)
  ∀ s : ℝ, let useCos := true; let minus := false;
    let G : Ω → M := fun ω => NormedSpace.exp (s • S useCos minus ω)
    let MX : M := ∫ ω, G ω ∂μ
    let B : ℝ := r ^ 2 * Real.exp (|s| * ((d : ℝ) * Rstar))
    Integrable G μ ∧ MX.PosDef ∧
      Matrix.trace MX = (∫ ω, Matrix.trace (G ω) ∂μ) ∧
      0 < Matrix.trace MX ∧ Matrix.trace MX ≤ B := by
  intro d q hq
  dsimp only
  intro s
  exact native_actual_T hq s true false

theorem q0_d2_cos_positive_s_zero :
  let D := EuclideanSpace ℝ (Fin 2)
  let E := EuclideanSpace ℝ (Fin (0 + 1))
  let Ω := Fin (0 + 1) → D
  let μ : Measure Ω := Measure.pi (fun _ : Fin (0 + 1) => stdGaussian D)
  let M := Matrix (Fin (0 + 1) × Fin (0 + 1)) (Fin (0 + 1) × Fin (0 + 1)) ℝ
  let r : ℝ := ((0 + 1 : ℕ) : ℝ)
  let L : ℝ := 2 * r + 3 * Real.log (1000 * (2 : ℝ))
  let α : Fin 2 → ℝ := fun i => ((i.val : ℝ) + 1 - 1 / 2) * Real.pi / (2 : ℝ)
  let tvec : Fin 2 → Fin (0 + 1) → ℝ := fun i k =>
    if k.val = 0 then 1 else Real.sqrt 2 * Real.cos ((k.val : ℝ) * α i)
  let row : Fin 2 → Ω → E := fun i ω =>
    WithLp.toLp 2 (fun b : Fin (0 + 1) => ω b i)
  let Y : Fin 2 → Ω → M := fun i ω =>
    if ‖row i ω‖ ^ 2 ≤ L then
      (2 : ℝ)⁻¹ • Matrix.kronecker
        (Matrix.vecMulVec (WithLp.ofLp (row i ω)) (WithLp.ofLp (row i ω)))
        (Matrix.vecMulVec (tvec i) (tvec i))
    else 0
  let mean : Fin 2 → M := fun i => ∫ ω, Y i ω ∂μ
  let Z : Fin 2 → Ω → M := fun i ω => Y i ω - mean i
  let w : Bool → Fin 2 → ℝ := fun useCos i =>
    if useCos = true then Real.cos (((2 * 0 + 1 : ℕ) : ℝ) * α i) else 1
  let sign : Bool → ℝ := fun minus => if minus = true then -1 else 1
  let S : Bool → Bool → Ω → M := fun useCos minus ω =>
    sign minus • ∑ i : Fin 2, w useCos i • Z i ω
  let Rstar : ℝ := 2 * r * (L + 1) / (2 : ℝ)
  let s : ℝ := 0; let useCos := true; let minus := false;
    let G : Ω → M := fun ω => NormedSpace.exp (s • S useCos minus ω)
    let MX : M := ∫ ω, G ω ∂μ
    let B : ℝ := r ^ 2 * Real.exp (|s| * ((2 : ℝ) * Rstar))
    Integrable G μ ∧ MX.PosDef ∧
      Matrix.trace MX = (∫ ω, Matrix.trace (G ω) ∂μ) ∧
      0 < Matrix.trace MX ∧ Matrix.trace MX ≤ B := by
  exact native_actual_T (d := 2) (q := 0) (by norm_num) 0 true false

theorem q0_d2_cos_positive_s_negative :
  let D := EuclideanSpace ℝ (Fin 2)
  let E := EuclideanSpace ℝ (Fin (0 + 1))
  let Ω := Fin (0 + 1) → D
  let μ : Measure Ω := Measure.pi (fun _ : Fin (0 + 1) => stdGaussian D)
  let M := Matrix (Fin (0 + 1) × Fin (0 + 1)) (Fin (0 + 1) × Fin (0 + 1)) ℝ
  let r : ℝ := ((0 + 1 : ℕ) : ℝ)
  let L : ℝ := 2 * r + 3 * Real.log (1000 * (2 : ℝ))
  let α : Fin 2 → ℝ := fun i => ((i.val : ℝ) + 1 - 1 / 2) * Real.pi / (2 : ℝ)
  let tvec : Fin 2 → Fin (0 + 1) → ℝ := fun i k =>
    if k.val = 0 then 1 else Real.sqrt 2 * Real.cos ((k.val : ℝ) * α i)
  let row : Fin 2 → Ω → E := fun i ω =>
    WithLp.toLp 2 (fun b : Fin (0 + 1) => ω b i)
  let Y : Fin 2 → Ω → M := fun i ω =>
    if ‖row i ω‖ ^ 2 ≤ L then
      (2 : ℝ)⁻¹ • Matrix.kronecker
        (Matrix.vecMulVec (WithLp.ofLp (row i ω)) (WithLp.ofLp (row i ω)))
        (Matrix.vecMulVec (tvec i) (tvec i))
    else 0
  let mean : Fin 2 → M := fun i => ∫ ω, Y i ω ∂μ
  let Z : Fin 2 → Ω → M := fun i ω => Y i ω - mean i
  let w : Bool → Fin 2 → ℝ := fun useCos i =>
    if useCos = true then Real.cos (((2 * 0 + 1 : ℕ) : ℝ) * α i) else 1
  let sign : Bool → ℝ := fun minus => if minus = true then -1 else 1
  let S : Bool → Bool → Ω → M := fun useCos minus ω =>
    sign minus • ∑ i : Fin 2, w useCos i • Z i ω
  let Rstar : ℝ := 2 * r * (L + 1) / (2 : ℝ)
  let s : ℝ := (-1); let useCos := true; let minus := false;
    let G : Ω → M := fun ω => NormedSpace.exp (s • S useCos minus ω)
    let MX : M := ∫ ω, G ω ∂μ
    let B : ℝ := r ^ 2 * Real.exp (|s| * ((2 : ℝ) * Rstar))
    Integrable G μ ∧ MX.PosDef ∧
      Matrix.trace MX = (∫ ω, Matrix.trace (G ω) ∂μ) ∧
      0 < Matrix.trace MX ∧ Matrix.trace MX ≤ B := by
  exact native_actual_T (d := 2) (q := 0) (by norm_num) (-1) true false

theorem q0_d2_cos_positive_s_positive :
  let D := EuclideanSpace ℝ (Fin 2)
  let E := EuclideanSpace ℝ (Fin (0 + 1))
  let Ω := Fin (0 + 1) → D
  let μ : Measure Ω := Measure.pi (fun _ : Fin (0 + 1) => stdGaussian D)
  let M := Matrix (Fin (0 + 1) × Fin (0 + 1)) (Fin (0 + 1) × Fin (0 + 1)) ℝ
  let r : ℝ := ((0 + 1 : ℕ) : ℝ)
  let L : ℝ := 2 * r + 3 * Real.log (1000 * (2 : ℝ))
  let α : Fin 2 → ℝ := fun i => ((i.val : ℝ) + 1 - 1 / 2) * Real.pi / (2 : ℝ)
  let tvec : Fin 2 → Fin (0 + 1) → ℝ := fun i k =>
    if k.val = 0 then 1 else Real.sqrt 2 * Real.cos ((k.val : ℝ) * α i)
  let row : Fin 2 → Ω → E := fun i ω =>
    WithLp.toLp 2 (fun b : Fin (0 + 1) => ω b i)
  let Y : Fin 2 → Ω → M := fun i ω =>
    if ‖row i ω‖ ^ 2 ≤ L then
      (2 : ℝ)⁻¹ • Matrix.kronecker
        (Matrix.vecMulVec (WithLp.ofLp (row i ω)) (WithLp.ofLp (row i ω)))
        (Matrix.vecMulVec (tvec i) (tvec i))
    else 0
  let mean : Fin 2 → M := fun i => ∫ ω, Y i ω ∂μ
  let Z : Fin 2 → Ω → M := fun i ω => Y i ω - mean i
  let w : Bool → Fin 2 → ℝ := fun useCos i =>
    if useCos = true then Real.cos (((2 * 0 + 1 : ℕ) : ℝ) * α i) else 1
  let sign : Bool → ℝ := fun minus => if minus = true then -1 else 1
  let S : Bool → Bool → Ω → M := fun useCos minus ω =>
    sign minus • ∑ i : Fin 2, w useCos i • Z i ω
  let Rstar : ℝ := 2 * r * (L + 1) / (2 : ℝ)
  let s : ℝ := 1; let useCos := true; let minus := false;
    let G : Ω → M := fun ω => NormedSpace.exp (s • S useCos minus ω)
    let MX : M := ∫ ω, G ω ∂μ
    let B : ℝ := r ^ 2 * Real.exp (|s| * ((2 : ℝ) * Rstar))
    Integrable G μ ∧ MX.PosDef ∧
      Matrix.trace MX = (∫ ω, Matrix.trace (G ω) ∂μ) ∧
      0 < Matrix.trace MX ∧ Matrix.trace MX ≤ B := by
  exact native_actual_T (d := 2) (q := 0) (by norm_num) 1 true false

theorem allreal_cos_negative :
∀ {d q : ℕ} (hq : 2 * q + 1 < d),
  let D := EuclideanSpace ℝ (Fin d)
  let E := EuclideanSpace ℝ (Fin (q + 1))
  let Ω := Fin (q + 1) → D
  let μ : Measure Ω := Measure.pi (fun _ : Fin (q + 1) => stdGaussian D)
  let M := Matrix (Fin (q + 1) × Fin (q + 1)) (Fin (q + 1) × Fin (q + 1)) ℝ
  let r : ℝ := ((q + 1 : ℕ) : ℝ)
  let L : ℝ := 2 * r + 3 * Real.log (1000 * (d : ℝ))
  let α : Fin d → ℝ := fun i => ((i.val : ℝ) + 1 - 1 / 2) * Real.pi / (d : ℝ)
  let tvec : Fin d → Fin (q + 1) → ℝ := fun i k =>
    if k.val = 0 then 1 else Real.sqrt 2 * Real.cos ((k.val : ℝ) * α i)
  let row : Fin d → Ω → E := fun i ω =>
    WithLp.toLp 2 (fun b : Fin (q + 1) => ω b i)
  let Y : Fin d → Ω → M := fun i ω =>
    if ‖row i ω‖ ^ 2 ≤ L then
      (d : ℝ)⁻¹ • Matrix.kronecker
        (Matrix.vecMulVec (WithLp.ofLp (row i ω)) (WithLp.ofLp (row i ω)))
        (Matrix.vecMulVec (tvec i) (tvec i))
    else 0
  let mean : Fin d → M := fun i => ∫ ω, Y i ω ∂μ
  let Z : Fin d → Ω → M := fun i ω => Y i ω - mean i
  let w : Bool → Fin d → ℝ := fun useCos i =>
    if useCos = true then Real.cos (((2 * q + 1 : ℕ) : ℝ) * α i) else 1
  let sign : Bool → ℝ := fun minus => if minus = true then -1 else 1
  let S : Bool → Bool → Ω → M := fun useCos minus ω =>
    sign minus • ∑ i : Fin d, w useCos i • Z i ω
  let Rstar : ℝ := 2 * r * (L + 1) / (d : ℝ)
  ∀ s : ℝ, let useCos := true; let minus := true;
    let G : Ω → M := fun ω => NormedSpace.exp (s • S useCos minus ω)
    let MX : M := ∫ ω, G ω ∂μ
    let B : ℝ := r ^ 2 * Real.exp (|s| * ((d : ℝ) * Rstar))
    Integrable G μ ∧ MX.PosDef ∧
      Matrix.trace MX = (∫ ω, Matrix.trace (G ω) ∂μ) ∧
      0 < Matrix.trace MX ∧ Matrix.trace MX ≤ B := by
  intro d q hq
  dsimp only
  intro s
  exact native_actual_T hq s true true

theorem q0_d2_cos_negative_s_zero :
  let D := EuclideanSpace ℝ (Fin 2)
  let E := EuclideanSpace ℝ (Fin (0 + 1))
  let Ω := Fin (0 + 1) → D
  let μ : Measure Ω := Measure.pi (fun _ : Fin (0 + 1) => stdGaussian D)
  let M := Matrix (Fin (0 + 1) × Fin (0 + 1)) (Fin (0 + 1) × Fin (0 + 1)) ℝ
  let r : ℝ := ((0 + 1 : ℕ) : ℝ)
  let L : ℝ := 2 * r + 3 * Real.log (1000 * (2 : ℝ))
  let α : Fin 2 → ℝ := fun i => ((i.val : ℝ) + 1 - 1 / 2) * Real.pi / (2 : ℝ)
  let tvec : Fin 2 → Fin (0 + 1) → ℝ := fun i k =>
    if k.val = 0 then 1 else Real.sqrt 2 * Real.cos ((k.val : ℝ) * α i)
  let row : Fin 2 → Ω → E := fun i ω =>
    WithLp.toLp 2 (fun b : Fin (0 + 1) => ω b i)
  let Y : Fin 2 → Ω → M := fun i ω =>
    if ‖row i ω‖ ^ 2 ≤ L then
      (2 : ℝ)⁻¹ • Matrix.kronecker
        (Matrix.vecMulVec (WithLp.ofLp (row i ω)) (WithLp.ofLp (row i ω)))
        (Matrix.vecMulVec (tvec i) (tvec i))
    else 0
  let mean : Fin 2 → M := fun i => ∫ ω, Y i ω ∂μ
  let Z : Fin 2 → Ω → M := fun i ω => Y i ω - mean i
  let w : Bool → Fin 2 → ℝ := fun useCos i =>
    if useCos = true then Real.cos (((2 * 0 + 1 : ℕ) : ℝ) * α i) else 1
  let sign : Bool → ℝ := fun minus => if minus = true then -1 else 1
  let S : Bool → Bool → Ω → M := fun useCos minus ω =>
    sign minus • ∑ i : Fin 2, w useCos i • Z i ω
  let Rstar : ℝ := 2 * r * (L + 1) / (2 : ℝ)
  let s : ℝ := 0; let useCos := true; let minus := true;
    let G : Ω → M := fun ω => NormedSpace.exp (s • S useCos minus ω)
    let MX : M := ∫ ω, G ω ∂μ
    let B : ℝ := r ^ 2 * Real.exp (|s| * ((2 : ℝ) * Rstar))
    Integrable G μ ∧ MX.PosDef ∧
      Matrix.trace MX = (∫ ω, Matrix.trace (G ω) ∂μ) ∧
      0 < Matrix.trace MX ∧ Matrix.trace MX ≤ B := by
  exact native_actual_T (d := 2) (q := 0) (by norm_num) 0 true true

theorem q0_d2_cos_negative_s_negative :
  let D := EuclideanSpace ℝ (Fin 2)
  let E := EuclideanSpace ℝ (Fin (0 + 1))
  let Ω := Fin (0 + 1) → D
  let μ : Measure Ω := Measure.pi (fun _ : Fin (0 + 1) => stdGaussian D)
  let M := Matrix (Fin (0 + 1) × Fin (0 + 1)) (Fin (0 + 1) × Fin (0 + 1)) ℝ
  let r : ℝ := ((0 + 1 : ℕ) : ℝ)
  let L : ℝ := 2 * r + 3 * Real.log (1000 * (2 : ℝ))
  let α : Fin 2 → ℝ := fun i => ((i.val : ℝ) + 1 - 1 / 2) * Real.pi / (2 : ℝ)
  let tvec : Fin 2 → Fin (0 + 1) → ℝ := fun i k =>
    if k.val = 0 then 1 else Real.sqrt 2 * Real.cos ((k.val : ℝ) * α i)
  let row : Fin 2 → Ω → E := fun i ω =>
    WithLp.toLp 2 (fun b : Fin (0 + 1) => ω b i)
  let Y : Fin 2 → Ω → M := fun i ω =>
    if ‖row i ω‖ ^ 2 ≤ L then
      (2 : ℝ)⁻¹ • Matrix.kronecker
        (Matrix.vecMulVec (WithLp.ofLp (row i ω)) (WithLp.ofLp (row i ω)))
        (Matrix.vecMulVec (tvec i) (tvec i))
    else 0
  let mean : Fin 2 → M := fun i => ∫ ω, Y i ω ∂μ
  let Z : Fin 2 → Ω → M := fun i ω => Y i ω - mean i
  let w : Bool → Fin 2 → ℝ := fun useCos i =>
    if useCos = true then Real.cos (((2 * 0 + 1 : ℕ) : ℝ) * α i) else 1
  let sign : Bool → ℝ := fun minus => if minus = true then -1 else 1
  let S : Bool → Bool → Ω → M := fun useCos minus ω =>
    sign minus • ∑ i : Fin 2, w useCos i • Z i ω
  let Rstar : ℝ := 2 * r * (L + 1) / (2 : ℝ)
  let s : ℝ := (-1); let useCos := true; let minus := true;
    let G : Ω → M := fun ω => NormedSpace.exp (s • S useCos minus ω)
    let MX : M := ∫ ω, G ω ∂μ
    let B : ℝ := r ^ 2 * Real.exp (|s| * ((2 : ℝ) * Rstar))
    Integrable G μ ∧ MX.PosDef ∧
      Matrix.trace MX = (∫ ω, Matrix.trace (G ω) ∂μ) ∧
      0 < Matrix.trace MX ∧ Matrix.trace MX ≤ B := by
  exact native_actual_T (d := 2) (q := 0) (by norm_num) (-1) true true

theorem q0_d2_cos_negative_s_positive :
  let D := EuclideanSpace ℝ (Fin 2)
  let E := EuclideanSpace ℝ (Fin (0 + 1))
  let Ω := Fin (0 + 1) → D
  let μ : Measure Ω := Measure.pi (fun _ : Fin (0 + 1) => stdGaussian D)
  let M := Matrix (Fin (0 + 1) × Fin (0 + 1)) (Fin (0 + 1) × Fin (0 + 1)) ℝ
  let r : ℝ := ((0 + 1 : ℕ) : ℝ)
  let L : ℝ := 2 * r + 3 * Real.log (1000 * (2 : ℝ))
  let α : Fin 2 → ℝ := fun i => ((i.val : ℝ) + 1 - 1 / 2) * Real.pi / (2 : ℝ)
  let tvec : Fin 2 → Fin (0 + 1) → ℝ := fun i k =>
    if k.val = 0 then 1 else Real.sqrt 2 * Real.cos ((k.val : ℝ) * α i)
  let row : Fin 2 → Ω → E := fun i ω =>
    WithLp.toLp 2 (fun b : Fin (0 + 1) => ω b i)
  let Y : Fin 2 → Ω → M := fun i ω =>
    if ‖row i ω‖ ^ 2 ≤ L then
      (2 : ℝ)⁻¹ • Matrix.kronecker
        (Matrix.vecMulVec (WithLp.ofLp (row i ω)) (WithLp.ofLp (row i ω)))
        (Matrix.vecMulVec (tvec i) (tvec i))
    else 0
  let mean : Fin 2 → M := fun i => ∫ ω, Y i ω ∂μ
  let Z : Fin 2 → Ω → M := fun i ω => Y i ω - mean i
  let w : Bool → Fin 2 → ℝ := fun useCos i =>
    if useCos = true then Real.cos (((2 * 0 + 1 : ℕ) : ℝ) * α i) else 1
  let sign : Bool → ℝ := fun minus => if minus = true then -1 else 1
  let S : Bool → Bool → Ω → M := fun useCos minus ω =>
    sign minus • ∑ i : Fin 2, w useCos i • Z i ω
  let Rstar : ℝ := 2 * r * (L + 1) / (2 : ℝ)
  let s : ℝ := 1; let useCos := true; let minus := true;
    let G : Ω → M := fun ω => NormedSpace.exp (s • S useCos minus ω)
    let MX : M := ∫ ω, G ω ∂μ
    let B : ℝ := r ^ 2 * Real.exp (|s| * ((2 : ℝ) * Rstar))
    Integrable G μ ∧ MX.PosDef ∧
      Matrix.trace MX = (∫ ω, Matrix.trace (G ω) ∂μ) ∧
      0 < Matrix.trace MX ∧ Matrix.trace MX ≤ B := by
  exact native_actual_T (d := 2) (q := 0) (by norm_num) 1 true true

end NativeLiteralApplications
#print axioms NativeLiteralApplications.literal_P
#print axioms NativeLiteralApplications.P_empty_indices
#print axioms NativeLiteralApplications.P_singleton_identity
#print axioms NativeLiteralApplications.P_ae_PD_dirac_null_bad
#print axioms NativeLiteralApplications.null_bad_is_not_pointwise_PD
#print axioms NativeLiteralApplications.literal_T
#print axioms NativeLiteralApplications.literal_T_q0
#print axioms NativeLiteralApplications.literal_T_q0_d2
#print axioms NativeLiteralApplications.allreal_ordinary_positive
#print axioms NativeLiteralApplications.q0_d2_ordinary_positive_s_zero
#print axioms NativeLiteralApplications.q0_d2_ordinary_positive_s_negative
#print axioms NativeLiteralApplications.q0_d2_ordinary_positive_s_positive
#print axioms NativeLiteralApplications.allreal_ordinary_negative
#print axioms NativeLiteralApplications.q0_d2_ordinary_negative_s_zero
#print axioms NativeLiteralApplications.q0_d2_ordinary_negative_s_negative
#print axioms NativeLiteralApplications.q0_d2_ordinary_negative_s_positive
#print axioms NativeLiteralApplications.allreal_cos_positive
#print axioms NativeLiteralApplications.q0_d2_cos_positive_s_zero
#print axioms NativeLiteralApplications.q0_d2_cos_positive_s_negative
#print axioms NativeLiteralApplications.q0_d2_cos_positive_s_positive
#print axioms NativeLiteralApplications.allreal_cos_negative
#print axioms NativeLiteralApplications.q0_d2_cos_negative_s_zero
#print axioms NativeLiteralApplications.q0_d2_cos_negative_s_negative
#print axioms NativeLiteralApplications.q0_d2_cos_negative_s_positive

set_option pp.all true in
#check @AutoSamplingTheory.TechnicalLemmas.Probability.RealMatrixPositiveDefIntegral.integral_posDef
set_option pp.all true in
#check native_actual_T
