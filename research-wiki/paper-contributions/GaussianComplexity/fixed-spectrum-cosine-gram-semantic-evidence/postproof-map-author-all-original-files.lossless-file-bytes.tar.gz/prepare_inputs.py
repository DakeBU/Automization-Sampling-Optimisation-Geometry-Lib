from pathlib import Path
from hashlib import sha256
import json, subprocess

R=Path('/Users/zhouhuanjian/ASTIS-GC')
O=R/'.astis/huanjian-gc-fixed-spectrum-cosine-gram-20261110/source-map-author-1d7a46'
for d in ['inputs','logs','slices']: (O/d).mkdir(exist_ok=True)
paths=[
'AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumCosineGram.lean',
'Tests/GaussianComplexityFixedSpectrumCosineGram.lean',
'.astis/huanjian-gc-fixed-spectrum-cosine-gram-20261110/statement-seal-v1.json',
'.astis/huanjian-gc-fixed-spectrum-cosine-gram-20261110/producer-signature.draft.txt',
'.astis/huanjian-gc-fixed-spectrum-cosine-gram-20261110/consumer-signature.draft.txt',
'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-cosine-gram-semantic-evidence/KernelExactTypesAndAllOwnedBounded.lean',
'.astis/huanjian-resume-20261103/20261110T155942501800Z-cosine-gram-actual-kernel-exact-types-all-owned.log',
'AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumGridAlias.lean',
'.astis/semantic-neutral-20261110/cg_sg_1d7a46/phase1/source_graph.json',
'.astis/semantic-neutral-20261110/cg_sg_1d7a46/phase1/source_index.json',
'.astis/semantic-neutral-20261110/cg_sg_1d7a46/phase1/inputs/2610.20492v1.html',
'.astis/semantic-neutral-20261110/cg_sg_1d7a46/phase2/typed_overlay.json',
'.lake/packages/mathlib/Mathlib/Analysis/Complex/Trigonometric.lean',
'.lake/packages/mathlib/Mathlib/Analysis/Real/Sqrt.lean',
'.lake/packages/mathlib/Mathlib/Probability/Distributions/Gaussian/Basic.lean',
'.lake/packages/mathlib/Mathlib/Probability/Distributions/Gaussian/Fernique.lean',
'.lake/packages/mathlib/Mathlib/Probability/Distributions/Gaussian/Multivariate.lean',
'.lake/packages/mathlib/Mathlib/Probability/Distributions/Gaussian/Real.lean',
'.lake/packages/mathlib/Mathlib/MeasureTheory/Function/L1Space/Integrable.lean',
'.lake/packages/mathlib/Mathlib/MeasureTheory/Integral/Bochner/Basic.lean',
'.lake/packages/mathlib/Mathlib/MeasureTheory/Integral/Bochner/ContinuousLinearMap.lean',
'.lake/packages/mathlib/Mathlib/Probability/Moments/Covariance.lean',
'.lake/packages/mathlib/Mathlib/LinearAlgebra/Matrix/PosDef.lean',
'.lake/packages/mathlib/Mathlib/Analysis/InnerProductSpace/PiL2.lean',
'.lake/packages/mathlib/Mathlib/Analysis/Normed/Lp/PiLp.lean']
records=[]
for rel in paths:
 b=(R/rel).read_bytes()
 target=O/'inputs'/rel
 target.parent.mkdir(parents=True,exist_ok=True)
 target.write_bytes(b)
 records.append({'path':rel,'bytes':len(b),'raw_wholefile_sha256':sha256(b).hexdigest(),'snapshot':str(target.relative_to(O))})
(O/'inputs.json').write_text(json.dumps(records,ensure_ascii=False,indent=2)+'\n')
# Actual read-only query replay. Full stdout/stderr is preserved, including exit1
# no-match searches; query output is not a mathematical result.
queries=[
 ('gla-name',['rg','-n','actual_midpoint_grid_cosine_alias',paths[7]],['fbfdb3']),
 ('gaussian-names',['rg','-n','theorem memLp_dual|lemma memLp_dual|theorem integrable_fun_id|lemma integrable_fun_id|theorem integral_id_multivariateGaussian|lemma integral_id_multivariateGaussian|theorem covariance_eval_multivariateGaussian|lemma covariance_eval_multivariateGaussian|def stdGaussian|def multivariateGaussian','.lake/packages/mathlib/Mathlib/Probability/Distributions/Gaussian'],['2eb3d6']),
 ('initial-trig-no-match',['rg','-n','theorem two_mul_cos_mul_cos|lemma two_mul_cos_mul_cos|theorem cos_sq_le_one|lemma cos_sq_le_one|theorem sq_sqrt|lemma sq_sqrt','.lake/packages/mathlib/Mathlib/Analysis/SpecialFunctions/Trigonometric','.lake/packages/mathlib/Mathlib/Analysis/SpecialFunctions/Sqrt.lean','.lake/packages/mathlib/Mathlib/Data/Real/Sqrt.lean'],['aae791']),
 ('actual-trig-Gaussian-names',['rg','-n','two_mul_cos_mul_cos|cos_sq_le_one|alias.*sq_sqrt|memLp_dual|integrable_fun_id','.lake/packages/mathlib/Mathlib'],['12b9f4']),
 ('integrability-no-match',['rg','-n','integrable_mul','.lake/packages/mathlib/Mathlib/MeasureTheory/Function/LpSeminorm','.lake/packages/mathlib/Mathlib/MeasureTheory/Function/LpSpace'],['d7d72f']),
 ('actual-product-name',['rg','-n','MemLp.integrable_mul|lemma integrable_mul|theorem integrable_mul|def proj ','.lake/packages/mathlib/Mathlib/MeasureTheory/Function','.lake/packages/mathlib/Mathlib/Analysis/InnerProductSpace/PiL2.lean'],['89a4d3']),
 ('projection-name',['rg','-n','EuclideanSpace.proj|abbrev proj|def proj|alias.*proj','.lake/packages/mathlib/Mathlib/Analysis/InnerProductSpace/PiL2.lean','.lake/packages/mathlib/Mathlib/Analysis/Normed/Lp/PiLp.lean'],['d3c3fd'])]
logs=[]
for label,argv,chunks in queries:
 r=subprocess.run(argv,cwd=R,capture_output=True)
 (O/'logs'/(label+'.stdout')).write_bytes(r.stdout)
 (O/'logs'/(label+'.stderr')).write_bytes(r.stderr)
 logs.append({'label':label,'argv':argv,'cwd':str(R),'exit_code':r.returncode,'original_chunks':chunks,
 'stdout':label+'.stdout','stderr':label+'.stderr','stdout_sha256':sha256(r.stdout).hexdigest(),'stderr_sha256':sha256(r.stderr).hexdigest(),
 'classification':'successful text locator query' if r.returncode==0 else 'no-match locator query; no mathematical failure'})
(O/'logs/query_commands.json').write_text(json.dumps(logs,ensure_ascii=False,indent=2)+'\n')
# Full stdout of the original combined read, replayed to disk; model-visible
# first call clipped part of seal/kernel, so no claim that it was read intact.
parts=[]
for rel in [paths[0],paths[1],paths[2],paths[6]]:
 b=(R/rel).read_bytes()
 parts.extend(['INPUT '+rel+' BYTES '+str(len(b))+' SHA256 '+sha256(b).hexdigest(), b.decode('utf-8')])
(O/'logs/initial-combined-read-replay.stdout').write_text('\n'.join(parts)+'\n')
(O/'logs/initial-combined-read-replay.stderr').write_bytes(b'')
report={'kind':'read-only input capture','input_files':len(records),'query_replays':len(logs),
 'no_match_queries':sum(x['exit_code']==1 for x in logs),'disk_output_truncation':False,
 'P_sha256':records[0]['raw_wholefile_sha256'],'T_sha256':records[1]['raw_wholefile_sha256'],
 'kernel_log_sha256':records[6]['raw_wholefile_sha256']}
(O/'logs/prepare.stdout').write_text(json.dumps(report,ensure_ascii=False)+'\n')
(O/'logs/prepare.stderr').write_bytes(b'')
print(json.dumps(report,ensure_ascii=False))
