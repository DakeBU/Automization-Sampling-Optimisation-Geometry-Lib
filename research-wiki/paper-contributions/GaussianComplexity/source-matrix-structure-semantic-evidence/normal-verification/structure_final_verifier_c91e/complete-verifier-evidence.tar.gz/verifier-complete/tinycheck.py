"""Selected-verifier package integrity only; no control-plane actions."""
from pathlib import Path
import hashlib, json
ROOT = Path(__file__).resolve().parent
sha = lambda b: hashlib.sha256(b).hexdigest()
manifest_bytes = (ROOT/'payload-manifest.json').read_bytes()
manifest = json.loads(manifest_bytes)
seal = json.loads((ROOT/'manifest-seal.json').read_bytes())
assert sha(manifest_bytes) == seal['payload_manifest_sha256']
paths = []
for item in manifest['files']:
    path = item['path']; assert not Path(path).is_absolute() and '..' not in Path(path).parts
    paths.append(path)
    b = (ROOT/path).read_bytes()
    assert len(b) == item['bytes'] and sha(b) == item['sha256']
assert len(paths) == len(set(paths)) == manifest['payload_file_count']
original = json.loads((ROOT/'historical-originals/PROVED_LOCAL-evidence.full.json').read_bytes())
pl = json.loads((ROOT/'historical-originals/PROVED_LOCAL-append.exact.jsonl').read_bytes())
payload = json.loads((ROOT/'verifier-originals/VERIFIED-evidence.full.json').read_bytes())
vbytes = (ROOT/'verifier-originals/actual-VERIFIED-append.exact.jsonl').read_bytes()
v = json.loads(vbytes)
cell = json.loads((ROOT/'verifier-originals/candidate-cell.exact.json').read_bytes())
assert len(original) == 26 and pl['evidence'] == original
assert all(payload[k] == x for k,x in original.items())
assert v['from_state'] == 'PROVED_LOCAL' and v['to_state'] == 'VERIFIED'
assert v['worker_id'] == 'structure_final_verifier_c91e' and v['evidence'] == payload
assert sha(vbytes) == '9469feb2ad5a0593b061859a64920419ad53ddd21d8a40061ed0cc4e53261580'
assert cell['status'] == 'independently_verified'
assert cell['owner_id'] == 'huanjian_gc_20261113_source_matrix_structure'
assert isinstance(cell['evidence']['independent_verification'],str)
assert cell['evidence']['independent_verification_details'] == payload
assert all(cell['evidence']['independent_verification_details'][k] == x for k,x in original.items())
assert payload['final_current_reader_update']['candidate_CSS_globally_applied'] is False
assert payload['verification_scope']['integration_publication_purification_whole_Goal'] == 'HOLD'
assert sha((ROOT/'native-reader-selected-evidence.tar.gz').read_bytes()) == 'b37c5a0a7d0ddb64332709849743762e5cb48e9adbb01a6fdde61a97c9fdb8ad'
assert sha((ROOT/'source-review-selected-originals.tar.gz').read_bytes()) == 'ce677c3d2a90d22905030fa5944c19baf8fc0f91577b682371fed812b0e90df9'
print(json.dumps({'status':'PASS','payload_files':len(paths),'original_PL_fields_unchanged':26,
    'exact_PL_and_V_appends_retained':True,'normal_API_calls_performed_by_tinycheck':0,
    'owner_and_global_HOLD_retained':True}))
