from pathlib import Path
import hashlib,json
from datetime import datetime,timezone

ROOT=Path('/Users/zhouhuanjian/ASTIS-GC')
BASE=ROOT/'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-admissibility-semantic-evidence/source-only-review'
P1=BASE/'phase1'
P2=BASE/'phase2'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p): return json.loads(p.read_text())
def write(name,value): (P2/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
assert not (P2/'freeze.json').exists(),'Already frozen; do not mutate phase2.'
g1=read(P1/'source-graph.json');g2=read(P2/'source-graph.json')
c1=read(P1/'coverage.json');c2=read(P2/'coverage.json')
m=read(P2/'matching.json')
assert g1['nodes']==g2['nodes'] and g1['edges']==g2['edges']
assert c1['coverage_counts']==c2['coverage_counts']
assert c1['units']==[{k:v for k,v in x.items() if k!='phase2_binding'} for x in c2['units']]
ids={n['id'] for n in g1['nodes']}
assert set(g2['selected_producer_source_slice']).isdisjoint(g2['explicit_pending_downstream_or_context'])
assert set(g2['selected_producer_source_slice'])|set(g2['explicit_pending_downstream_or_context'])==ids
assert {x['source_node'] for x in m['node_by_node_binding']}==ids
assert len(m['seven_slots'])==7
assert len(m['selected_internal_source_bridge_ids'])==4
assert all(x['source_gap_status']=='unproved' for x in m['node_by_node_binding'] if 'gap-' in x['source_node'])
for name,h in g2['frozen_phase1']['hashes'].items(): assert sha(P1/name)==h
for x in read(P2/'raw-inputs.json')['authorized_inputs']:
    assert sha(P2/x['snapshot'])==x['sha256']
write('structural-check.json',{
 'status':'deterministic-structure-only-passed',
 'checks':['Frozen phase1 hashes remain exact','Source nodes and edges are byte-content-equivalent to phase1 JSON values','Coverage dispositions/text/reasons remain exactly preserved','Every source node has exactly one selected/pending binding','Seven semantic slots present','All eight source-gap nodes remain unproved','All authorized input snapshots match exact raw hashes'],
 'node_count':len(ids),'edge_count':len(g1['edges']),'coverage_counts':c1['coverage_counts'],
 'selected_source_gap_count':4,'pending_source_gap_count':4,
 'boundary':'No mathematical coverage/topology self-approval, proof compilation, or source verification is implied.'})
helpers={}
for name in ['build_phase2.py','freeze_phase2.py']:
    p=ROOT/'.astis/huanjian-fixed-spectrum-admissibility-20261107/source-graph'/name
    helpers[str(p.relative_to(ROOT))]=sha(p)
payload={str(p.relative_to(P2)):sha(p) for p in sorted(P2.rglob('*')) if p.is_file() and p.name not in ['rawhashes.json','freeze.json']}
write('rawhashes.json',{'algorithm':'SHA-256','phase2_payload_files':payload,'private_helper_inputs':helpers,
 'self_exclusion':'rawhashes.json and freeze.json are excluded; freeze.json binds rawhashes.json, and the freeze digest is sent to root.'})
write('freeze.json',{
 'phase':'phase2','frozen_at_utc':datetime.now(timezone.utc).isoformat(),
 'phase1_freeze_sha256':sha(P1/'freeze.json'),
 'seal_sha256':'ab68d72daa52e4607be3acf310b93cb0ad20c3638cd8062078805e3a33eccab0',
 'signature_sha256':'186231307d4c41acba15a1098c56518120394295cf048f504fed6f8ea50018d5',
 'definition_context_sha256':'e41f07383b3aa3c57bbf686642e0dc14bf58555fd5451a8bf5c5f55bc325ff6a',
 'rawhashes_sha256':sha(P2/'rawhashes.json'),
 'source_graph_sha256':sha(P2/'source-graph.json'),
 'coverage_sha256':sha(P2/'coverage.json'),
 'matching_sha256':sha(P2/'matching.json'),
 'exposure_manifest_sha256':sha(P2/'exposure-manifest.json'),
 'raw_inputs_sha256':sha(P2/'raw-inputs.json'),
 'payload_file_count':len(payload),
 'status':'immutable-proposed-match-pending-distinct-topology-challenge; not-proved-not-source-accepted',
 'stop_rule':'Send exact hashes to root and stop. No further target proof/API work before full preproof admission.'})
print(json.dumps({'freeze_sha256':sha(P2/'freeze.json'),**read(P2/'freeze.json')},ensure_ascii=False,indent=2))
