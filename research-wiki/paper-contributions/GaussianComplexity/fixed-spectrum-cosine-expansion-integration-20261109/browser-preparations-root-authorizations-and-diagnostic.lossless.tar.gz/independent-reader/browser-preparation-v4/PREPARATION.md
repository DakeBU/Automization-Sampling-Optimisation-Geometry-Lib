# Minimal C7 browser v4 — disabled and unexecuted

The independent diagnostic review actually opened both original1440/390 PNGs and inspected all six original geometry records. The selected Lower Bounds text/domain tag is complete, legible and unobscured. Every check except `readable_label` is true; the label is about79.53125px wide,12px font and15px high. This is a false negative of the80px short-label proxy for this exact label.

The review's scope is selected label/readable native entry. Adjacent global cards overlap the selected card's lower blank region and neighbouring global nodes are cropped at the viewport edge. It does not accept all190 nodes, all card borders as unoccluded, or the full C7 reader/runtime. See the separately frozen two-original/six-geometry review, SHA256 `3aac3b4af92b15b30602e4233be566a6b5833aae097581690893770aff1ce7f3`.

The only acceptance-predicate change is inside the existing native geometry JS: for `args.id==='concept:lower'`, require `args.label==='Lower Bounds'`, exact rendered text equality and positive measured width. Font≥10px, height≥10px and all existing card/label/SVG/canvas/viewport/kind/view/query checks remain. Every other route retains width≥80px. No camera/UI/source/core change is proposed.

Any native wait/layout assertion failure now saves the actual `g0` and a separate original viewport PNG before rethrowing the original exception. Capture errors are retained. Failure-only PNGs are separate from the48 main originals and confer no acceptance. Successful completion still requires all48 main originals,20 native rows and all existing assertions; failure collections must be empty.

All other changes are v4 import/path/hash/authorization identity and diagnostic provenance. The disabled actual-records context reuses unchanged real7ad core/gate/site/sourceV/STAB facts, but resets root/execution flags and inherits no execution authority. v2/v3/diagnostic freezes, failed reports and originals remain intact. Neither checker/common was imported or run; only source/AST inspection was performed.

Root can review the exact diff/context and obtain the requested new scoped approval for the existing flow:

```text
/opt/anaconda3/bin/python .astis/huanjian-resume-20261103/run_check.py cosine-expansion-final-browser-v4 .astis/huanjian-gc-integration-20261105/browser-venv/bin/python .astis/huanjian-gc-fixed-spectrum-cosine-expansion-integration-20261109/independent-reader/browser-preparation-v4/check_final_reader_v4.py --authorization-json <ACTUAL_NEW_ROOT_AUTHORIZATION_PATH> --authorization-sha256 <ACTUAL_NEW_ROOT_AUTHORIZATION_SHA256>
```

These placeholders remain documentation. No browser/server/OS approval/build/API/shared edit/stage/commit occurs here. The prospective predicate agrees with the six recorded diagnostic measurements, but that is not a real v4 run or full48-image acceptance. Source/math verdicts, park, remote release, purification and both full main bounds remain separate.
