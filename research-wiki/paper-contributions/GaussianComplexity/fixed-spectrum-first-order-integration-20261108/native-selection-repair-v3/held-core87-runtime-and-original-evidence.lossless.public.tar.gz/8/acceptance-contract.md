# Future acceptance inputs — strict, fail closed

This is an input contract, not an acceptance record. No screenshots were opened,
created, altered or accepted for this preparation. The template state is MISSING.
A future independently reviewed schema adapter is required if actual outputs do
not supply these exact fields; do not silently manufacture accepted projections.

The acceptance bundle must have state READY_FOR_SEPARATE_ROOT_PARK_AUTHORIZATION,
accepted_immutable_core 87ecd4d421de0146a062435f63e9dcb1f815c807, and exactly six
artifact refs: bound_context_review, browser_report, browser_command_receipt,
pixel_review, local_acceptance, parking_eligibility. Each ref contains a real
repository-relative path and actual raw SHA256. All files must exist and match.

1. bound_context_review: status=accepted, accepted_immutable_core, context_raw_sha256
   bce331025023068c3d5e7e94c1706b26a349dec226d1b0d27253be71a6ef0698,
   exact browser_checker_sha256 and browser_common_sha256 from that context,
   reviewer distinct from proofowner/integrator/root, new_source_verdict=false.
2. browser_report: actual unchanged v3 checker report, status=passed/errors=[],
   HEAD/site/gate CORE87, original candidate9d and binding51d, matching source
   digests/actual gate/site metadata/context and actual sourceV readback. Exactly
   38 unique original PNG refs, two1440/390 page records, four graphs and two
   long-code regressions. external_GitHub_HTML_checked remains false.
3. browser_command_receipt: actual foreground exit_code0 at same CORE before/
   after, command naming check_final_reader_v3.py, actual log and its raw hash.
   Its logged summary must point to that actual report and assert passed/38
   screenshots/two pages/four graphs. No scripted fixture is sufficient.
4. pixel_review: status=accepted, CORE87, browser_report_sha256, independent
   reviewer distinct from proofowner/integrator/root/original source verifier,
   independent_from_browser_executor=true, new_source_verdict=false. Exactly38
   reviewed_images each gives file, sha256, viewed_original=true, status=accepted.
   Their set/hashes must equal the browser report's38 original files. The helper
   checks original PNG hashes and viewport dimensions1440x1000 or390x844; these
   checks do not substitute for that separate actual pixel review.
5. local_acceptance: status=accepted, authorized_by=/root, CORE87, exact raw
   browser_report_sha256, pixel_review_sha256, bound_context_review_sha256,
   all38_original_pixels_reviewed=true, remote_acceptance=false,
   wholeGoal_or_full_mains_claim=false. It may be issued only after those actual
   accepted artifacts exist.
6. parking_eligibility: eligible_for_normal_park=true, CORE87, from_state
   STABILIZING/to_state VERIFIED, original_source_verifier exact original actor,
   original source_V_append_sha256306b3e..., STAB_append_sha256621a44...,
   accepted_source_audit_sha256a14867..., local_acceptance_sha256 and
   pixel_review_sha256 matching the refs, no_new_source_verdict=true,
   remote_acceptance=false. This is a separate post-acceptance eligibility record.

The original browser context says parking_authorized=false. It is never park
authorization. A separate exact root park authorization must bind this frozen
helper/common/baseline/original events plus the final populated acceptance-bundle
raw hash. Every original V306 evidence key/value remains exact, including verifier,
verified_commit9d, source audit148, STATIC gate and all earlier boundaries. The
helper adds only post_integration_normalpark after validating real future inputs.
