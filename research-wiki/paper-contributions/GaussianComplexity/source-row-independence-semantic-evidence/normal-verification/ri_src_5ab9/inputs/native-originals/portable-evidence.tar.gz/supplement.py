import json,sys,tarfile
from run import ROOT,REPO,run,sha
I=ROOT/'inputs';m=json.loads((ROOT/'input-manifest.json').read_text());sys.path[:0]=[str(I/'tools'),str(I/'website/scripts')]
import astis
scan=[]
for p in m['modules']:
    clean=astis.strip_lean_comments_and_strings((I/p).read_text())
    hits=[{'line':i,'text':s.strip()} for i,s in enumerate(clean.splitlines(),1) if astis.FORBIDDEN_REGEX.search(s)]
    assert not hits,(p,hits)
    scan.append({'path':p,'sha256':sha((I/p).read_bytes()),'hits':hits})
(ROOT/'fake-closure-scan.json').write_text(json.dumps({'production_comment_string_stripper_and_FORBIDDEN_REGEX':True,'all_3_frozen_modules_scanned':True,'files':scan,'zero_hits':True,'kernel_closed_body_axiom_checks':'native-summary.json'},indent=2)+'\n')
old=(ROOT/'scratch/StandardApplicability.lean').read_text()
(ROOT/'scratch/KernelMeaning.lean').write_text('import Tests.GaussianComplexityFixedSpectrumSourceRowIndependence\nopen MeasureTheory ProbabilityTheory\n#print ProbabilityTheory.Kernel.iIndepFun\n#print ProbabilityTheory.Kernel.iIndep\n#print ProbabilityTheory.Kernel.iIndepSets\n')
import os
env=dict(os.environ);env['LEAN_PATH']=os.pathsep.join(m['lean_path']);env.pop('LEAN_SRC_PATH',None)
r=run('kernel-independence-meaning',[m['lean_binary']['path'],'-R',str(ROOT/'scratch'),str(ROOT/'scratch/KernelMeaning.lean')],cwd=ROOT/'scratch',env=env);assert r.returncode==0
e=m['E'];archive=I/e/'preproof-source-types-topology-local-build.original-files.tar.gz'
items={}
with tarfile.open(archive,'r:gz') as tar:
    for x in tar.getmembers():
        if x.isfile():items[x.name]=tar.extractfile(x).read()
record=json.loads((I/e/'publication-draft-record.json').read_text())
originals=[]
for key in ['build','kernel']:
    v=record[key];b=items[v['path']];assert sha(b)==v['sha256']
    z=json.loads(b);assert z.get('exit_code')==0,(key,z)
    originals.append({'kind':key,'path':v['path'],'sha256':sha(b),'exit_code':0,'provenance_only':True})
attempts=json.loads((I/e/'local-attempt-diagnoses.json').read_text())
assert attempts['producer_implementation_failures']==attempts['consumer_implementation_failures']==attempts['actual_strict_kernel_probe_failures']==0
api=[]
for path,b in items.items():
    if path.endswith('.receipt.json') and ('proof-api' in path.lower() or 'proofapi' in path.lower()):
        v=json.loads(b);api.append({'path':path,'sha256':sha(b),'exit_code':v.get('exit_code')})
result={'historical_original_actual_first_build_and_kernel':originals,'historical_implementation_failure_counts':{'producer':0,'consumer':0,'strict_kernel':0},'failed_exploratory_API_receipts':api,'classification':'API_BLOCKED lookup namespaces only; preseal formation IMPLEMENTATION_FAILED before any proof; no mathematical refutation','proof_api_diagnosis':attempts['proof_API_probe'],'preseal_formation_diagnosis':attempts['preseal_formation_failures'],'own_native_credit':'Only own fresh 66e0 build/probes; no archived verifier verdict reused.'}
(ROOT/'historical-original-checks.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'fake_closure_hits':0,'historical_receipts_checked':len(originals),'exploratory_api_receipts':api}))
