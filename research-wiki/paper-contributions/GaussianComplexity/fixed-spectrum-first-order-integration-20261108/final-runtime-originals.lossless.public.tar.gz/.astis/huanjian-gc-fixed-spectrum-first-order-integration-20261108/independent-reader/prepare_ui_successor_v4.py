"""Owned static preparation only. Does not import/execute the browser helpers."""
from pathlib import Path
from datetime import datetime, timezone
import ast, difflib, gzip, hashlib, json

R = Path('/Users/zhouhuanjian/ASTIS-GC')
S = R / '.astis/huanjian-gc-fixed-spectrum-first-order-integration-20261108/independent-reader'
D = S / 'conditional-ui-browser-v4'
D.mkdir(exist_ok=False)
sha = lambda b: hashlib.sha256(b).hexdigest()

def ref(p):
    return {'path': str(p.relative_to(R)), 'sha256': sha(p.read_bytes())}

def put(p, raw):
    assert not p.exists(), p
    p.write_bytes(raw)
    return ref(p)

def obj(p, value):
    return put(p, (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode())

def replace_once(text, before, after):
    assert text.count(before) == 1, before[:160]
    return text.replace(before, after)

before_common = (S / 'first_order_browser_common_v3.py').read_bytes()
before_checker = (S / 'check_final_reader_v3.py').read_bytes()
assert sha(before_common) == '6c9f3deab51d2f8d0f115c0c390799baa7ed222adeaaaee845ecc6c7d9a24445'
assert sha(before_checker) == '27823045ffb88354ebad05e63a19ebb94a735596866d119c4309baad2ea47700'
repair = {
    'held_core': '87ecd4d421de0146a062435f63e9dcb1f815c807',
    'source_path': 'website/static/underlying-lean-graph.js',
    'generated_asset_path': '_site/assets/underlying-lean-graph.js',
    'before_sha256': 'cb899b6cff1e241a47ee88bff0fb72d04a56af7e4134bfe30168d44a2f00c6e7',
    'after_sha256': '016c11a60392c449ebb28e8bedc7d3ab69134fff8dde4b438fd06c9f6c951a3a',
    'proposal': {
        'path': '.astis/huanjian-gc-fixed-spectrum-first-order-integration-20261108/graph-selection-repair-v3/proposal-report.json',
        'sha256': 'e2c7fa2e3128d92e46cf789d370e89382a7160e01da90c3a0d227ad7b6a66f69',
    },
    'independent_static_review': {
        'path': '.astis/huanjian-gc-fixed-spectrum-first-order-integration-20261108/independent-reader/UI-camera-repair-independent-review-v3/initial-exact-v3-review.json',
        'sha256': '5b488c34d9eee3bb26215b61e106d2ab8a95b6f58b2fa6ce3d4b3adc4b658a97',
    },
    'preservation_qualification': 'One reviewed exact graph-camera JavaScript layout exception; every other protected tracked raw file, foreign state/frontier and original sourceV/STAB binding is preserved.',
}
for name in ('proposal', 'independent_static_review'):
    assert sha((R / repair[name]['path']).read_bytes()) == repair[name]['sha256']

common = before_common.decode()
common = replace_once(common, '"""CONDITIONAL browser guards. No execution, source verdict or lifecycle API here."""', '"""CONDITIONAL v4 UI successor guards. Exactly one reviewed JS exception; no execution/source verdict/API here."""')
common = replace_once(common, "BINDING='51d5a5e9390a0d66c2d5b72d042a042eec8d3d60433043ea3909bf9320ccb31e'\n", "BINDING='51d5a5e9390a0d66c2d5b72d042a042eec8d3d60433043ea3909bf9320ccb31e'\nUI_REPAIR=" + repr(repair) + '\n')
common = replace_once(common, "a['authorization_kind']=='fixed-spectrum-first-order-final-browser'", "a['authorization_kind']=='fixed-spectrum-first-order-final-browser-v4-ui-repair'")
common = replace_once(common, " assert a['browser_checker_sha256']==sha((S/'check_final_reader_v3.py').read_bytes())", " assert a['reviewed_UI_repair']==UI_REPAIR and a['accepted_immutable_core']!=UI_REPAIR['held_core']\n subprocess.check_call(['git','merge-base','--is-ancestor',UI_REPAIR['held_core'],a['accepted_immutable_core']],cwd=R)\n assert a['browser_checker_sha256']==sha((S/'check_final_reader_v4.py').read_bytes())")
repair_guard = '''def reviewed_ui_exception(a,baseline):
 assert a['reviewed_UI_repair']==UI_REPAIR
 proposal=json.loads(readref(UI_REPAIR['proposal']));review=json.loads(readref(UI_REPAIR['independent_static_review']))
 assert proposal['path']==UI_REPAIR['source_path'] and proposal['held_core']==UI_REPAIR['held_core']
 assert proposal['before_sha256']==UI_REPAIR['before_sha256'] and proposal['planned_after_sha256']==UI_REPAIR['after_sha256']
 assert review['status']=='accepted-for-bounded-application-and-new-validation' and review['blocking_objections_to_exact_source_patch']==[]
 assert review['proposal']==UI_REPAIR['proposal'] and review['planned_after_sha256']==UI_REPAIR['after_sha256']
 row=baseline['protected_tracked'][UI_REPAIR['source_path']]
 assert row['sha256']==UI_REPAIR['before_sha256'] and row['symlink'] is False
 before=gzip.decompress(readref(proposal['before_archive']));after=gzip.decompress(readref(proposal['after_archive']))
 assert sha(before)==UI_REPAIR['before_sha256'] and sha(after)==UI_REPAIR['after_sha256']
 source=R/UI_REPAIR['source_path'];asset=R/UI_REPAIR['generated_asset_path']
 assert source.is_file() and not source.is_symlink() and source.read_bytes()==after==asset.read_bytes()
 assert subprocess.check_output(['git','show',UI_REPAIR['held_core']+':'+UI_REPAIR['source_path']],cwd=R)==before
 assert subprocess.check_output(['git','show',a['accepted_immutable_core']+':'+UI_REPAIR['source_path']],cwd=R)==after
 return {**UI_REPAIR,'source_generated_and_immutable_core_bytes_exact':True,'scope':'UI camera layout only; no source/math/lifecycle verdict'}
'''
common = replace_once(common, 'def authorized_context(a):\n', repair_guard + 'def authorized_context(a):\n')
old_loop = """ ledger='runs/substantive_advances.jsonl'
 for name,row in baseline['protected_tracked'].items():
  if name in [ledger,'research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-first-order.json']:continue
  q=R/name;raw=os.fsencode(os.readlink(q)) if q.is_symlink() else q.read_bytes();assert sha(raw)==row['sha256'],name
"""
new_loop = """ ledger='runs/substantive_advances.jsonl'
 ui_exception=reviewed_ui_exception(a,baseline);protected_other_count=0
 for name,row in baseline['protected_tracked'].items():
  if name in [ledger,'research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-first-order.json',UI_REPAIR['source_path']]:continue
  q=R/name;raw=os.fsencode(os.readlink(q)) if q.is_symlink() else q.read_bytes();assert sha(raw)==row['sha256'],name
  protected_other_count+=1
 assert protected_other_count==len(baseline['protected_tracked'])-3==125206
 assert len(baseline['foreign_SAU_states'])==284 and len(baseline['all_frontier_raw_hashes'])-1==443
"""
common = replace_once(common, old_loop, new_loop)
common = replace_once(common, "'foreign_tracked_raw_bytes_preserved':True,", "'foreign_tracked_raw_bytes_preserved':False,'all_other_foreign_tracked_raw_bytes_preserved':True,'protected_other_raw_files_checked':protected_other_count,'reviewed_one_path_UI_exception':ui_exception,'preservation_qualification':UI_REPAIR['preservation_qualification'],")

checker = before_checker.decode()
checker = replace_once(checker, 'from first_order_browser_common_v3 import', 'from first_order_browser_common_v4 import')
checker = replace_once(checker, "PINS={'AutoSamplingTheory", "PINS={'website/static/underlying-lean-graph.js':'016c11a60392c449ebb28e8bedc7d3ab69134fff8dde4b438fd06c9f6c951a3a','AutoSamplingTheory")
checker = replace_once(checker, "assert (SITE/'assets/information-architecture.css').read_bytes()==(ROOT/'website/static/information-architecture.css').read_bytes()", "assert (SITE/'assets/information-architecture.css').read_bytes()==(ROOT/'website/static/information-architecture.css').read_bytes()\nassert (SITE/'assets/underlying-lean-graph.js').read_bytes()==(ROOT/'website/static/underlying-lean-graph.js').read_bytes()")
checker = replace_once(checker, "'old_long_Lean_layout_regressions':[],", "'old_long_Lean_layout_regressions':[],'native_selection_geometry':[],'UI_repair':authorization['reviewed_UI_repair'],")
geometry = '''# Read-only native post-navigation geometry. No Fit/pan/transform mutation.
NATIVE_GEOMETRY_JS = r"""args => {
  const rect = r => ({left:r.left,right:r.right,top:r.top,bottom:r.bottom,width:r.width,height:r.height});
  const selected = [...document.querySelectorAll('.ulg-node.selected')];
  const node = selected.find(n => n.dataset.id === args.id);
  const svg = document.querySelector('[data-graph-svg]');
  const canvas = document.querySelector('[data-graph-canvas]');
  const detail = document.querySelector('[data-graph-detail]');
  const box = node?.querySelector(':scope > rect');
  const label = node?.querySelector(':scope > text.label');
  if (!node || !svg || !canvas || !detail || !box || !label) return null;
  const mobile = document.querySelector('.mobile-bar');
  const top = mobile && getComputedStyle(mobile).display !== 'none' ? Math.max(0,mobile.getBoundingClientRect().bottom) : 0;
  const labelMatrix = label.getScreenCTM();
  if (!labelMatrix) return null;
  const font = parseFloat(getComputedStyle(label).fontSize) * Math.hypot(labelMatrix.a,labelMatrix.b);
  const viewport = {left:0,right:innerWidth,top,bottom:innerHeight};
  const s = rect(svg.getBoundingClientRect()), c = rect(canvas.getBoundingClientRect());
  const r = rect(box.getBoundingClientRect()), l = rect(label.getBoundingClientRect());
  const inside = (a,b) => a.left >= b.left-1 && a.right <= b.right+1 && a.top >= b.top-1 && a.bottom <= b.bottom+1;
  const actualKind = detail.dataset.kind;
  const actualLabel = detail.querySelector(':scope > header > h2')?.textContent;
  const query = document.querySelector('[data-graph-search]')?.value.trim();
  const checks = {
    unique_selected:selected.length===1,
    source_kind:actualKind===args.kind,
    source_full_name:actualLabel===args.label,
    expected_view:canvas.dataset.view===args.view,
    nonempty_query:Boolean(query),
    readable_card:r.width>=160 && r.height>=40,
    readable_label:font>=10 && l.width>=80 && l.height>=10 && Boolean(label.textContent.trim()),
    full_card_inside_svg:inside(r,s),full_card_inside_canvas:inside(r,c),full_card_inside_viewport:inside(r,viewport),
    full_label_inside_svg:inside(l,s),full_label_inside_canvas:inside(l,c),full_label_inside_viewport:inside(l,viewport),
    full_label_inside_card:inside(l,r)
  };
  return {id:args.id,expected_kind:args.kind,expected_label:args.label,actual_kind:actualKind,actual_label:actualLabel,
    actual_view:canvas.dataset.view,query,viewport,svg:s,canvas:c,selected_main_rect:r,rendered_label:l,
    rendered_label_font_px:font,rendered_label_text:label.textContent,checks,ok:Object.values(checks).every(Boolean)};
}"""


def native_selection_geometry(page, ident, view):
    args = {'id': ident, 'kind': nodes[ident]['kind'], 'label': nodes[ident]['label'], 'view': view}
    # Keep the normal Playwright timeout. Wait real layout, then allow all queued
    # fit callbacks to finish before a second read; scheduling is not a camera action.
    page.wait_for_function('args => (' + NATIVE_GEOMETRY_JS + ')(args)?.ok === true', arg=args)
    page.evaluate('() => new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(() => resolve(true))))')
    geometry = page.evaluate(NATIVE_GEOMETRY_JS, args)
    assert geometry and geometry['ok'], geometry
    assert all(geometry['checks'].values()), geometry
    geometry['camera_actions_by_harness'] = []
    geometry['scope'] = 'Actual native selection geometry after queued callbacks; read-only DOM/UI, not an additional image review.'
    return geometry


'''
checker = replace_once(checker, 'def focused_entry(page, ident, query, view=\'lean\'):\n', geometry + "def focused_entry(page, ident, query, view='lean'):\n")
checker = replace_once(checker, "    selected.click()\n    no_page_overflow(page)\n    return {'route': route", "    selected.click()\n    no_page_overflow(page)\n    native_geometry = native_selection_geometry(page, ident, view)\n    return {'native_post_click_geometry':native_geometry,'route': route")
parent_before = """                no_page_overflow(page)
                screenshot(page, f'canonical-parent{i}-{width}-graph-native-parent-click')
"""
parent_after = """                no_page_overflow(page)
                parent_geometry = native_selection_geometry(page, parent_id, 'lean')
                report['native_selection_geometry'].append({'width':width,'route':'native-Lean-parent','geometry':parent_geometry,'main_original':f'canonical-parent{i}-{width}-graph-native-parent-click.png','extra_screenshot':False})
                screenshot(page, f'canonical-parent{i}-{width}-graph-native-parent-click')
"""
checker = replace_once(checker, parent_before, parent_after)
module_before = """            no_page_overflow(page)
            screenshot(page, f'actual-{width}-graph-module-native-click')
"""
module_after = """            no_page_overflow(page)
            module_geometry = native_selection_geometry(page, module_id, 'lean')
            report['native_selection_geometry'].append({'width':width,'route':'native-Lean-module','geometry':module_geometry,'main_original':f'actual-{width}-graph-module-native-click.png','extra_screenshot':False})
            screenshot(page, f'actual-{width}-graph-module-native-click')
"""
checker = replace_once(checker, module_before, module_after)
extras = '''            # Exercise the actual emitted preset caller with the existing query.
            # These additional native routes are DOM/UI-only; no extra PNG claim.
            preset = page.locator('#functor-contract nav[aria-label="Conceptual bridge inspector"] button[data-functor-jump="' + bridge + '"]')
            assert preset.count() == 1
            preset_ancestors = preset.locator('xpath=ancestor::details')
            for ancestor_index in reversed(range(preset_ancestors.count())):
                ancestor = preset_ancestors.nth(ancestor_index)
                if ancestor.get_attribute('open') is None:
                    ancestor.locator(':scope > summary').click()
                    assert ancestor.get_attribute('open') is not None
            assert preset.is_visible()
            preset_query = page.locator('[data-graph-search]').input_value().strip()
            assert preset_query == 'Quadratic observations factor'
            preset.click()
            assert page.locator('[data-graph-search]').input_value().strip() == preset_query
            page.locator('[data-graph-canvas]').scroll_into_view_if_needed()
            preset_geometry = native_selection_geometry(page, bridge, 'functor')
            no_page_overflow(page)
            report['native_selection_geometry'].append({'width':width,'route':'emitted-Functor-preset-with-query','native_preset_click':True,'native_details_ancestors_checked':preset_ancestors.count(),'geometry':preset_geometry,'pixel_review_claim':False,'extra_screenshot':False})
            cross_view_neighbor = page.locator('[data-graph-detail] button[data-jump="' + module_id + '"]')
            assert cross_view_neighbor.count() == 1
            cross_view_neighbor.click()
            page.wait_for_selector('.ulg-canvas[data-view="lean"][data-local="true"]')
            assert page.locator('[data-graph-search]').input_value().strip() == preset_query
            page.locator('[data-graph-canvas]').scroll_into_view_if_needed()
            cross_view_geometry = native_selection_geometry(page, module_id, 'lean')
            no_page_overflow(page)
            report['native_selection_geometry'].append({'width':width,'route':'native-Functor-to-Lean-module','native_neighbor_click':True,'geometry':cross_view_geometry,'pixel_review_claim':False,'extra_screenshot':False})
'''
checker = replace_once(checker, '            context.close()\n', extras + '            context.close()\n')
checker = replace_once(checker, "        assert len(report['screenshots']) == 38\n", "        assert len(report['screenshots']) == 38\n        assert len(report['native_selection_geometry']) == 8\n        assert {(row['width'],row['route']) for row in report['native_selection_geometry']} == {(w,r) for w in (1440,390) for r in ('native-Lean-parent','native-Lean-module','emitted-Functor-preset-with-query','native-Functor-to-Lean-module')}\n")

# Parse Python only. Never import/run either helper during preparation.
ast.parse(common); ast.parse(checker)
common_ref = put(S / 'first_order_browser_common_v4.py', common.encode())
checker_ref = put(S / 'check_final_reader_v4.py', checker.encode())
common_diff = put(D / 'common-v3-to-v4.exact.diff', ''.join(difflib.unified_diff(before_common.decode().splitlines(True), common.splitlines(True), fromfile='first_order_browser_common_v3.py', tofile='first_order_browser_common_v4.py')).encode())
checker_diff = put(D / 'checker-v3-to-v4.exact.diff', ''.join(difflib.unified_diff(before_checker.decode().splitlines(True), checker.splitlines(True), fromfile='check_final_reader_v3.py', tofile='check_final_reader_v4.py')).encode())
archive_refs = []
for name, raw in [('common-v3.before', before_common), ('common-v4.after', common.encode()), ('checker-v3.before', before_checker), ('checker-v4.after', checker.encode())]:
    archive_refs.append(put(D / (name + '.raw.gz'), gzip.compress(raw, mtime=0)))

template = json.loads((R / '.astis/huanjian-gc-fixed-spectrum-first-order-integration-20261108/root-final-browser-context-v3.json').read_bytes())
template.update({'state':'UNAUTHORIZED_CONDITIONAL_V4_TEMPLATE_NOT_A_RECEIPT','authorized_by':None,'authorization_kind':'fixed-spectrum-first-order-final-browser-v4-ui-repair','execute_browser_authorized':False,'browser_checker_sha256':checker_ref['sha256'],'browser_common_sha256':common_ref['sha256'],'accepted_immutable_core':None,'actual_gate':{'path':'.astis/site-lean-gate.json','sha256':None},'site_metadata':{'path':'_site/data/build-metadata.json','sha256':None},'actual_checks_before_browser':{k:{'path':None,'sha256':None} for k in template['actual_checks_before_browser']},'reviewed_UI_repair':repair,'authorized_utc':None,'instruction':'UNAUTHORIZED. Root must bind the actual new immutable descendant core, actual8 same-core gates and current gate/site metadata; independently review the concrete context, then request a NEW v4-path scoped OS permission. Never reuse v3 OS prefix, old CORE87 gates/context adapter or a file URL/source-preview refusal workaround. No source verdict/API/local acceptance/park/remote or wholeGoal authority.'})
template.pop('additional_actual_standalone_root_check',None)
template_ref = obj(S / 'UNAUTHORIZED-final-browser-context-v4.template.json', template)
late_template = obj(D / 'UNAUTHORIZED-late-context-review-v4.template.json', {'schema':'independent-current-context-consistency-review-v4','status':'PENDING_GENUINE_CONTEXT_REVIEW','scope':'CONTEXT_CONSISTENCY_ONLY; no pixels/current UI success, no math/sourceV/acceptance/park','reviewer':'/root/norm_integration_reader','accepted_immutable_core':None,'actual_context':{'path':None,'sha256':None},'source_gate':{'path':'.astis/site-lean-gate.json','sha256':None},'site_metadata':{'path':'_site/data/build-metadata.json','sha256':None},'browser_checker':checker_ref,'browser_common':common_ref,'reviewed_UI_repair':repair,'actual8_receipts_and_rawlogs_read':False,'blocking_objections':None,'new_source_verdict':False,'independent_from_proof_owner_integrator_and_source_actor':True,'old_context_adapter_preserved_pending':{'path':str((S/'late-context-independent-review-v3/context-consistency-status-adapter-v1.json').relative_to(R)),'sha256':'fc9b89b6add4ab21f46d2a03a21703196cee131bbf8f1d7bfa910dd3d8f85505'},'instructions':'Only after genuine new concrete-context review may the reviewer replace PENDING with native status accepted or HOLD in a new actual report. Do not manufacture an accepted adapter from old CORE87 evidence.'})

assert (S/'first_order_browser_common_v3.py').read_bytes()==before_common
assert (S/'check_final_reader_v3.py').read_bytes()==before_checker
assert checker.count('screenshot(page,') == before_checker.decode().count('screenshot(page,')
assert "old_code = old_lens.locator(':scope > pre.code-block')" in checker
assert 'assert old_lines >= 100' in checker
assert "'foreign_tracked_raw_bytes_preserved':True" not in common
assert 'state.' not in geometry and 'fit(' not in geometry
now = datetime.now(timezone.utc).isoformat()
manifest = obj(D / 'conditional-preparation-report.json', {
    'state':'CONDITIONAL_V4_PREPARATION_ONLY_NOT_EXECUTED_OR_ACCEPTED',
    'created_utc':now,'reviewer':'/root/norm_integration_reader',
    'review_before_helper_generation':repair['independent_static_review'],
    'reviewed_UI_repair':repair,'future_core':None,
    'helpers':[checker_ref,common_ref],'exact_diffs':[checker_diff,common_diff],
    'raw_archives':archive_refs,'authorization_template':template_ref,'late_context_template':late_template,
    'original_helpers_unchanged':[ref(S/'check_final_reader_v3.py'),ref(S/'first_order_browser_common_v3.py')],
    'static_checks':['Both Python files ast.parse only; no import/execution','Exact v3 helper raw pins preserved','All screenshot call sites and final38 count retained','All old assertions retained; direct :scope > pre.code-block count1 and>=100 lines retained','New geometry measurements are read-only; no Fit/pan/state/SVG mutation','One exact JS exception validated before baseline skip;125206 other raw files,284 foreign states,443 foreign frontiers and all original V/STAB/audit/frontier guards retained','Source digest still actual original definition18bcb; exact new core required by all8 actual receipts'],
    'geometry_policy':{'card_min_rendered_width':160,'card_min_rendered_height':40,'label_min_rendered_width':80,'label_min_rendered_font_px':10,'all_card_and_label_XY_bounds_inside':['actual SVG','actual canvas','current unobscured viewport'],'detail_kind_and_full_source_name_exact':True,'normal_timeout_unchanged':True,'two_animation_frames_wait_only_no_camera_action':True,'main_originals':38,'native_coverage_rows':8,'extra_preset_and_cross_view_rows':'DOM/UI-only at2widths; zero extra original-image claims'},
    'no_runtime_actions':['No shared application','No helper/browser/OS run','No gate/site generation','No new source verdict/API/local acceptance/park'],
    'execution_delegation':'Root only after actual new immutable core, actual8 gates, separately reviewed concrete v4 context and NEW v4 scoped OS approval. Old v3 prefix is not applicable.',
    'prospective_command':['/opt/anaconda3/bin/python','.astis/huanjian-resume-20261103/run_check.py','fixed-spectrum-first-order-final-browser-v4','.astis/huanjian-gc-integration-20261105/browser-venv/bin/python',str((S/'check_final_reader_v4.py').relative_to(R)),'--authorization-json','<future concrete root v4 context>','--authorization-sha256','<actual context rawSHA>'],
    'old_original38_HOLD_and_context_adapter_preserved':True,'uncertainties':['Future core/context/8receipt pins unknown and not preapproved','No new actual Chrome geometry or pixels exist from this preparation','Actual new38 originals require a separate independent per-original pixel review even if helper PASS'],
})
payloads = [common_ref,checker_ref,common_diff,checker_diff,*archive_refs,template_ref,late_template,manifest,ref(Path(__file__))]
freeze = obj(D / 'freeze.json', {'schema':'immutable-conditional-successor-helper-freeze-v4','created_utc':now,'payloads':payloads,'shared_paths_written':0,'lifecycle_API_calls':0,'browser_runs':0})
print(json.dumps({'report':manifest,'freeze':freeze,'checker':checker_ref,'common':common_ref,'authorization_template':template_ref},indent=2))
