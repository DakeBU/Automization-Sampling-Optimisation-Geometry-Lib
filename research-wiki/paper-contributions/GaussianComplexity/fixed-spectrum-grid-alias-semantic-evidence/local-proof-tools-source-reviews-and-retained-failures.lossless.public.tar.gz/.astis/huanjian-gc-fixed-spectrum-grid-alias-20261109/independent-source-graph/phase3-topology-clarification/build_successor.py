from pathlib import Path
from hashlib import sha256
import json,datetime
D=Path(__file__).resolve().parents[1]; O=D/'phase3-topology-clarification'
raw=json.loads((D/'phase1/raw-first-author-graph.json').read_text());prev=json.loads((D/'phase2/exact-interface-projection.json').read_text())
raw_hash=sha256((D/'phase1/raw-first-author-graph.json').read_bytes()).hexdigest()
prev_hash=sha256((D/'phase2/exact-interface-projection.json').read_bytes()).hexdigest()
N=[]; E=[]
def rawref(pointer):return {'path':'phase1/raw-first-author-graph.json','sha256':raw_hash,'json_pointer':pointer}
def node(i,statement,kind,refs=(),source=(),status='REQUIRED_SOURCE_OBLIGATION_NOT_PROVED_HERE'):
 N.append({'id':i,'statement':statement,'kind':kind,'raw_graph_refs':[rawref(x) for x in refs],'source_anchors':list(source),'status':status,'public_binder':False})
def edge(i,parents,consumer,kind,refs=(),use='',guard=None):
 E.append({'id':i,'parents':parents,'consumer':consumer,'edge_kind':kind,'raw_graph_refs':[rawref(x) for x in refs],'consumer_use_site':use,'guard':guard,'proof_status':'SOURCE_TOPOLOGY_OBLIGATION_ONLY_NOT_IMPLEMENTED_OR_PROVED','no_new_public_binder':True})
# Semantic selector: a projection of one source definition is not a proof of the alias.
node('ctx-d-theta','d:Nat, hd:2<=d, theta_i=(i-1/2)pi/d for i=1,...,d; equivalently Fin d angle=(i.val+1/2)pi/d. Contains no kappa, eigenvalue, rho or Gaussian object.','SELECTED_SOURCE_CONTEXT',('/nodes/0',),('S4.SS1.p1.m3','S4.E11.m1'),'SOURCE_CONTEXT_SELECTOR')
node('ctx-kappa-spectrum','kappa:Real>=2 and eigenvalue_i=(kappa+1)/2+(kappa-1)cos(theta_i)/2; rho=(sqrt(kappa)-1)/(sqrt(kappa)+1). This context is used only by C7/consumer, never by the alias branch proof.','SELECTED_SOURCE_CONTEXT',('/nodes/0','/nodes/1'),('S4.E11','S4.Thmtheorem5.p1.1'),'SOURCE_CONTEXT_SELECTOR')
node('ctx-positive-n','n is an integer with 1<=n<d, represented by n:Nat with hn/hnd.','SOURCE_RANGE_CONTEXT',('/nodes/2',),('S4.Thmtheorem5.p1.1','A3.Thmtheorem8.p1.1'),'SOURCE_RANGE_CONTEXT')
node('positive-series-index','j:Nat corresponds exactly to m=j+1>=1; m-n is formed in Int.','LITERAL_INDEX_ADAPTER',('/nodes/14','/nodes/15'),('A3.Ex144',),'LITERAL_ADAPTER')
node('gap-d-nonzero','From hd derive d>0, (d:Real)!=0 and 2*(d:Int)>0.','INTERNAL_SOURCE_GAP',('/nodes/0','/nodes/8'),('S4.SS1.p1.1','A3.SS3.p3.2'))
node('gap-grid-index-transport','Finite one-based source indices i=1,...,d and Fin d are bijective via i_source=i.val+1, preserving midpoint theta and the sum.','INTERNAL_SOURCE_GAP',('/nodes/0','/nodes/7'),('S4.E11','A3.Ex139'))
node('gap-nonmultiple-sine-denominator','For arbitrary integer k with NOT (2*d divides k), sin(k*pi/(2*d))!=0. This guarded denominator fact must be derived from the integer sine zero set and d>0; it is not assumed.','INTERNAL_SOURCE_GAP',('/nodes/8',),('A3.SS3.p3.2',))
node('gap-finite-cosine-ratio','For the literal midpoint grid and integer k with NOT (2*d divides k), the finite cosine sum equals sin(k*pi)/(2*sin(k*pi/(2*d))). The source quotes this finite-trigonometric identity without deriving it.','INTERNAL_SOURCE_GAP',('/nodes/8',),('A3.SS3.p3.2',))
node('gap-integer-sine-zero','For every integer k, sin(k*pi)=0, including zero and negative integers.','INTERNAL_SOURCE_GAP',('/nodes/8',),('A3.SS3.p3.2',))
node('guarded-nonmultiple-result','For every integer k, NOT (2*d divides k) IMPLIES sum_i cos(k*theta_i)=0.','GUARDED_BRANCH_PROVIDER',('/nodes/8',),('A3.SS3.p3.2',))
node('gap-exact-int-quotient','Under 2*d divides k, a=k/(2*d):Int satisfies k=2*a*d. This uses positive/nonzero divisor; negative a and a=0 are retained.','INTERNAL_SOURCE_GAP',('/nodes/9',),('A3.SS3.p3.2',))
node('gap-integer-cosine-parity','For every integer a and source index i, cos(2*a*i*pi-a*pi)=(-1)^a; the exponent is integer zpow, including negative a, and -1 is nonzero.','INTERNAL_SOURCE_GAP',('/nodes/9',),('A3.SS3.p3.2',))
node('guarded-multiple-result','For every integer k, (2*d divides k) IMPLIES sum_i cos(k*theta_i)=d*(-1)^(k/(2*d)).','GUARDED_BRANCH_PROVIDER',('/nodes/9',),('A3.SS3.p3.2',))
node('integer-alias','For every k:Int, sum_i cos(k*theta_i)=d*(if 2*d divides k then (-1)^(k/(2*d)) else 0).','BOUNDED_SOURCE_ANCHOR',('/nodes/7',),('A3.Ex139',))
node('c7-expand','C7 supplies the pointwise inverse-spectrum cosine expansion and absolute/uniform convergence for all real theta. It is an upstream source result, not a free public consumer premise.','UPSTREAM_SOURCE_RESULT',('/nodes/3',),('A3.Thmtheorem7','A3.Ex133'),'UPSTREAM_SOURCE_PREREQUISITE_NO_REVERIFICATION')
node('c7-internal-source-route','Frozen raw C7 route: rho -> geometric step; geometric+normalization+majorant -> C7. Required radius, rational denominator and convergence facts remain part of that upstream route.','UPSTREAM_EXPANSION_REFERENCE',('/nodes/1','/nodes/4','/nodes/5','/nodes/6'),('A3.SS3.p2','A3.Ex136','A3.Ex137'),'UPSTREAM_SOURCE_PREREQUISITE_NO_REVERIFICATION')
node('gap-consumer-denominators','From kappa>=2 and |cos|<=1, sqrt(kappa)>0 and each literal eigenvalue>=1; pointwise C7 inverse formula is therefore interpreted on its intended nonzero denominators. No such fact is needed as an alias binder.','INTERNAL_SOURCE_GAP',('/nodes/0','/nodes/5'),('S4.E11','A3.Ex136'))
node('gap-cosine-weight-bounded','At every grid point, |cos(n*theta_i)|<=1; multiplying the C7 absolute series by this fixed real weight preserves absolute convergence.','INTERNAL_SOURCE_GAP',('/nodes/11',),('A3.SS3.p4.2','A3.SS3.p6.1'))
node('gap-finite-tsum-interchange','A finite sum of the C7-derived absolutely summable weighted series can be interchanged with the positive-frequency infinite series. Standard finite/series linearity must be supplied internally.','INTERNAL_SOURCE_GAP',('/nodes/11',),('A3.SS3.p4.2',))
node('finite-series-exchange','Actual finite-grid weighted series is absolutely summable and its finite sum interchanges with the C7 positive-frequency series.','DERIVED_CONSUMER_PROVIDER',('/nodes/11',),('A3.SS3.p4.2',))
node('gap-n-nonmultiple','From d>=2 and 1<=n<d derive NOT (2*d divides n:Int).','INTERNAL_SOURCE_GAP',('/nodes/12',),('A3.SS3.p6.1',))
node('weighted-constant-zero','sum_i cos(n*theta_i)=0, derived by applying integer-alias at n and the low-frequency nonmultiple fact.','DERIVED_CONSUMER_PROVIDER',('/nodes/12',),('A3.SS3.p6.1',))
node('gap-product-to-sum-background','For real x,y, 2*cos(x)*cos(y)=cos(x-y)+cos(x+y). This unproved standard trigonometric background is internal, not a source binder.','INTERNAL_SOURCE_GAP',('/nodes/13',),('A3.SS3.p6.1',))
node('weighted-product-sum','At m=j+1>=1, product-to-sum creates the two Int frequencies m-n and m+n and cancels C7 factor2.','DERIVED_CONSUMER_PROVIDER',('/nodes/13',),('A3.SS3.p6.1','A3.Ex144'))
node('weighted-prealias-series','W_n=sum_i cos(n*theta_i)/lambda_i=(1/sqrt(kappa))*sum_{m>=1}(-rho)^m*(S(m-n)+S(m+n)), with the actual transformed series summable; S(k)=sum_i cos(k*theta_i).','DERIVED_CONSUMER_PROVIDER',('/nodes/14',),('A3.Ex144',))
node('alias-termwise-rewrite','For every m=j+1>=1, S(m-n)+S(m+n)=d*(a(m-n)+a(m+n)); both Int frequencies use the same all-integer alias.','DERIVED_CONSUMER_PROVIDER',('/nodes/15',),('A3.Ex139','A3.Ex144','A3.SS3.p6.2'))
node('gap-summability-transport','Transport summability and tsum under pointwise equality and multiplication/division by nonzero d. This derives Summable of the actual supported coefficient series from the transformed finite-grid series; it is not a hypothesis.','INTERNAL_SOURCE_GAP',('/nodes/11','/nodes/15'),('A3.SS3.p4.2','A3.Ex144'))
node('supported-series-summable','Summable_{j:Nat} (-rho)^(j+1)*(a((j+1)-n)+a((j+1)+n)), with Int subtraction.','CONSUMER_OUTPUT_COMPONENT',('/nodes/15',),('A3.Ex144',))
node('weighted-alias-supported-series','The exact private consumer output is supported-series-summable AND W_n=(d/sqrt(kappa))*tsum_j (-rho)^(j+1)*(a((j+1)-n)+a((j+1)+n)).','BOUNDED_PRIVATE_CONSUMER',('/nodes/15',),('A3.Ex139','A3.Ex144'))
# Context projections are nonimplicational selections, explicitly no definition->theorem edge.
edge('select-d-theta',['raw:standing-grid'],'ctx-d-theta','NONIMPLICATION_CONTEXT_SELECTION',('/edges/0',), 'S4.E11 -> producer context; select only d/hd/theta')
edge('select-kappa-spectrum',['raw:standing-grid','raw:rho'],'ctx-kappa-spectrum','NONIMPLICATION_CONTEXT_SELECTION',(), 'S4.E11/Lemma4.5 -> consumer context only')
edge('dimension-nonzero',['ctx-d-theta'],'gap-d-nonzero','INTERNAL_DERIVATION_OBLIGATION',(), 'p3.2 denominators and quotient')
edge('grid-index',['ctx-d-theta'],'gap-grid-index-transport','INTERNAL_DERIVATION_OBLIGATION',(), 'p3 and exact sealed Fin d interface')
edge('nonmultiple-denominator',['ctx-d-theta','gap-d-nonzero'],'gap-nonmultiple-sine-denominator','GUARDED_INTERNAL_DERIVATION_OBLIGATION',(), 'p3.2 nonmultiple branch', 'NOT (2*d divides k)')
edge('finite-trig-background',['ctx-d-theta','gap-d-nonzero','gap-grid-index-transport','gap-nonmultiple-sine-denominator'],'gap-finite-cosine-ratio','GUARDED_INTERNAL_DERIVATION_OBLIGATION',(), 'p3.2 quoted finite cosine sum', 'NOT (2*d divides k)')
edge('integer-sine-background',[],'gap-integer-sine-zero','STANDARD_BACKGROUND_SOURCE_GAP',(), 'p3.2 sin(k*pi)=0')
edge('nonmultiple-branch',['ctx-d-theta','gap-grid-index-transport','gap-nonmultiple-sine-denominator','gap-finite-cosine-ratio','gap-integer-sine-zero'],'guarded-nonmultiple-result','GUARDED_PROOF_BRANCH',('/edges/1',), 'A3.SS3.p3.2 nonmultiple branch','Conclusion is universally guarded: for all k, NOT div(k) -> S(k)=0')
edge('quotient-background',['ctx-d-theta','gap-d-nonzero'],'gap-exact-int-quotient','GUARDED_INTERNAL_DERIVATION_OBLIGATION',(), 'p3.2 multiple branch', '2*d divides k')
edge('cosine-parity-background',[],'gap-integer-cosine-parity','STANDARD_BACKGROUND_SOURCE_GAP',(), 'p3.2 cos(2ai*pi-a*pi)=(-1)^a')
edge('multiple-branch',['ctx-d-theta','gap-grid-index-transport','gap-exact-int-quotient','gap-integer-cosine-parity'],'guarded-multiple-result','GUARDED_PROOF_BRANCH',('/edges/1',), 'A3.SS3.p3.2 multiple branch','Conclusion is universally guarded: for all k, div(k) -> S(k)=d*(-1)^(k/(2*d))')
edge('all-integer-case-assembly',['guarded-nonmultiple-result','guarded-multiple-result'],'integer-alias','EXHAUSTIVE_GUARDED_CASE_ASSEMBLY',('/edges/1',), 'A3.SS3.p3.1-p3.2;A3.Ex139','For each arbitrary k exactly one guard holds; k=0 and negative k included')
edge('c7-route-reference',['c7-internal-source-route'],'c7-expand','UPSTREAM_SOURCE_ROUTE_REFERENCE_NOT_REPROVED',('/edges/2','/edges/3'), 'A3.SS3.p2')
edge('consumer-denominators',['ctx-kappa-spectrum','ctx-d-theta'],'gap-consumer-denominators','INTERNAL_DERIVATION_OBLIGATION',(), 'C7 pointwise identification at literal eigenvalue')
edge('weight-background',['ctx-d-theta','ctx-positive-n'],'gap-cosine-weight-bounded','STANDARD_BACKGROUND_SOURCE_GAP',(), 'p4.2 and p6.1 weighted C7 use')
edge('finite-interchange-background',['c7-expand','ctx-d-theta','gap-cosine-weight-bounded'],'gap-finite-tsum-interchange','INTERNAL_DERIVATION_OBLIGATION',('/edges/4',), 'A3.SS3.p4.2')
edge('derive-exchange',['c7-expand','ctx-d-theta','ctx-kappa-spectrum','gap-consumer-denominators','gap-cosine-weight-bounded','gap-finite-tsum-interchange'],'finite-series-exchange','DERIVED_PROVIDER_OBLIGATION',('/edges/4',), 'A3.SS3.p4.2; actual weighted finite grid')
edge('n-not-multiple',['ctx-d-theta','ctx-positive-n'],'gap-n-nonmultiple','INTERNAL_DERIVATION_OBLIGATION',(), 'A3.SS3.p6.1 constant elimination')
edge('derive-constant-zero',['ctx-d-theta','ctx-positive-n','integer-alias','gap-n-nonmultiple'],'weighted-constant-zero','DERIVED_PROVIDER_OBLIGATION',('/edges/5',), 'A3.SS3.p6.1; apply all-integer alias at n')
edge('productsum-background',[],'gap-product-to-sum-background','STANDARD_BACKGROUND_SOURCE_GAP',(), 'A3.SS3.p6.1 product-to-sum')
edge('derive-productsum',['ctx-d-theta','positive-series-index','gap-product-to-sum-background'],'weighted-product-sum','DERIVED_PROVIDER_OBLIGATION',(), 'A3.SS3.p6.1/A3.Ex144')
edge('derive-prealias',['c7-expand','finite-series-exchange','weighted-constant-zero','weighted-product-sum','ctx-d-theta','ctx-kappa-spectrum','ctx-positive-n','positive-series-index'],'weighted-prealias-series','AND_WITHIN_SINGLE_AUTHOR_ROUTE',('/edges/6',), 'A3.SS3.p6.1/A3.Ex144; W_n deterministic precursor')
edge('derive-termwise-alias',['weighted-prealias-series','integer-alias','positive-series-index'],'alias-termwise-rewrite','AND_WITHIN_SINGLE_AUTHOR_ROUTE',('/edges/7',), 'A3.Ex144 inner sums; apply alias at m-n and m+n')
edge('summability-transport-background',['gap-d-nonzero'],'gap-summability-transport','INTERNAL_DERIVATION_OBLIGATION',(), 'A3.SS3.p4.2/A3.Ex144; supported series conclusion')
edge('derive-supported-summability',['weighted-prealias-series','alias-termwise-rewrite','gap-d-nonzero','gap-summability-transport'],'supported-series-summable','AND_WITHIN_SINGLE_AUTHOR_ROUTE',('/edges/7',), 'Private consumer actual Summable conclusion')
edge('derive-supported-identity',['weighted-prealias-series','alias-termwise-rewrite','supported-series-summable','gap-summability-transport'],'weighted-alias-supported-series','AND_WITHIN_SINGLE_AUTHOR_ROUTE',('/edges/7',), 'A3.Ex144 plus inner alias substitution; factor d/sqrt(kappa)')
summary=[
 {'previous_pointer':'/projected_edges/0','edge_kind':'COARSENED_SUMMARY_NOT_SUFFICIENT_HYPEREDGE','formal_implication':False,'expansion_node_ids':['ctx-d-theta','gap-d-nonzero','gap-grid-index-transport','gap-nonmultiple-sine-denominator','gap-finite-cosine-ratio','gap-integer-sine-zero','guarded-nonmultiple-result','gap-exact-int-quotient','gap-integer-cosine-parity','guarded-multiple-result','integer-alias'],'expansion_edge_ids':['select-d-theta','dimension-nonzero','grid-index','nonmultiple-denominator','finite-trig-background','integer-sine-background','nonmultiple-branch','quotient-background','cosine-parity-background','multiple-branch','all-integer-case-assembly'],'correction':'standing-grid contains additional spectral data. It is projected to d/theta-only context; context alone does NOT imply alias. Two guarded branches and background obligations derive the alias.'},
 {'previous_pointer':'/projected_edges/1','edge_kind':'COARSENED_SUMMARY_NOT_SUFFICIENT_HYPEREDGE','formal_implication':False,'expansion_node_ids':['ctx-d-theta','ctx-kappa-spectrum','ctx-positive-n','positive-series-index','c7-internal-source-route','c7-expand','gap-consumer-denominators','gap-cosine-weight-bounded','gap-finite-tsum-interchange','finite-series-exchange','gap-n-nonmultiple','weighted-constant-zero','gap-product-to-sum-background','weighted-product-sum','weighted-prealias-series'],'expansion_edge_ids':['select-kappa-spectrum','c7-route-reference','consumer-denominators','weight-background','finite-interchange-background','derive-exchange','n-not-multiple','derive-constant-zero','productsum-background','derive-productsum','derive-prealias'],'requires_transitive_expansion_of_summary0':True,'correction':'exchange, constant-zero and product-to-sum are DERIVED source providers, never supplied as free hypotheses. Explicit incoming obligations and raw-edge refs preserve every ingredient.'},
 {'previous_pointer':'/projected_edges/2','edge_kind':'COARSENED_SUMMARY_NOT_SUFFICIENT_HYPEREDGE','formal_implication':False,'expansion_node_ids':['weighted-prealias-series','integer-alias','positive-series-index','alias-termwise-rewrite','gap-summability-transport','supported-series-summable','weighted-alias-supported-series'],'expansion_edge_ids':['derive-termwise-alias','summability-transport-background','derive-supported-summability','derive-supported-identity'],'requires_transitive_expansion_of_summary0_and_summary1':True,'correction':'Termwise all-integer alias use and supported-series summability transport are exposed; the conjunction conclusion is not obtained from unproved/free summability.'}]
obj={
'schema_version':1,'artifact_kind':'APPEND_ONLY_TOPOLOGY_CLARIFICATION_SUCCESSOR','seal_id':prev['seal_id'],'seal_sha256':prev['seal_sha256'],'previous_projection_sha256':prev_hash,'raw_first_graph_sha256':raw_hash,
'supersedes_only':'Interpretation of phase2 projected_edges as sufficient hyperedges and coarse standing-grid dependency. All exact v2 signatures, binder/definition conclusions, raw cognition and source dispositions remain unchanged. The predecessor artifacts/manifests are not rewritten.',
'node_reference_rules':'raw_graph_refs are content-hash-bound RFC6901 JSON pointers into the immutable phase1 author graph. New INTERNAL_SOURCE_GAP nodes expand source-quoted or omitted background; these are source obligations, never new public theorem binders and never asserted proved.',
'context_selector':{'raw_atom':'standing-grid','raw_ref':rawref('/nodes/0'),'producer_selector':'ctx-d-theta','consumer_spectral_selector':'ctx-kappa-spectrum','producer_selected_fields':['d:Nat','hd:2<=d','theta literal grid'],'producer_excluded_fields':['kappa','hκ','eigenvalue','rho','Lambda','Gaussian expectations'],'independence':'No producer node/edge path contains ctx-kappa-spectrum or c7-expand. The source-context selection is nonimplicational, so no definition-to-alias sufficient edge exists.'},
'predecessor_edges_retyped_as_summaries':summary,'expanded_nodes':N,'expanded_edges':E,
'raw_graph_edge_interpretation_overlay':[
 {'raw_pointer':'/edges/0','type':'CONTEXT_ATTACHMENT_SUMMARY_NOT_PROOF','expansion':['select-d-theta','all-integer-case-assembly'],'not_sufficient':True},
 {'raw_pointer':'/edges/1','type':'EXHAUSTIVE_GUARDED_CASE_ASSEMBLY','expansion':['nonmultiple-branch','multiple-branch','all-integer-case-assembly']},
 {'raw_pointer':'/edges/4','type':'DERIVED_EXCHANGE_SUMMARY','expansion':['finite-interchange-background','derive-exchange']},
 {'raw_pointer':'/edges/5','type':'DERIVED_ZERO_CONSTANT_SUMMARY','expansion':['n-not-multiple','derive-constant-zero']},
 {'raw_pointer':'/edges/6','type':'COMPOSED_AUTHOR_ROUTE_SUMMARY','expansion':['derive-prealias'],'requires_producer_closure':True},
 {'raw_pointer':'/edges/7','type':'TERMWISE_ALIAS_AND_SUMMABILITY_SUMMARY','expansion':['derive-termwise-alias','derive-supported-summability','derive-supported-identity']},
 {'raw_pointer':'/edges/8','type':'INCOMPLETE_OUTSIDE_SCOPE_CONTEXT_ONLY','excluded_from_bounded_closure':True},
 {'raw_pointer':'/edges/9','type':'OPEN_EXCLUDED_TAIL_EXTRACTION','excluded_from_bounded_closure':True},
 {'raw_pointer':'/edges/10','type':'OPEN_EXCLUDED_CLOSED_RESUMMATION','excluded_from_bounded_closure':True}],
'false_AND_OR_audit':{
 'status':'PASS_SOURCE_TOPOLOGY_ONLY_NOT_PROOF',
 'frequency_branches':'Both branch providers are universally quantified guarded implications. For a fixed k, div(k) and NOT div(k) are exhaustive/disjoint. Assembly uses proof by cases, never simultaneously assumes both guards. Both guarded providers are needed for the universal identity; they are not two independently sufficient alternative routes.',
 'consumer_AND':'The C7+exchange+constant-zero+product-to-sum combination is the single author route and really needs these ingredients. Each derived provider has incoming source/background obligations; none becomes a public premise.',
 'summary_edges':'All three predecessor projected_edges are now explicitly COARSENED_SUMMARY_NOT_SUFFICIENT_HYPEREDGE and refer losslessly to expanded node/edge IDs and hash-bound raw refs.',
 'no_false_closure':'Every INTERNAL_SOURCE_GAP is REQUIRED/UNPROVED_HERE. The expanded graph is a specification of proof obligations, not a theorem-implication certificate.'},
'excluded_open_bridges':prev['explicit_open_exclusions'],'EXCESS':[],
'no_upgrade':['Gaussian p4 expectation-to-grid','unweighted/weighted tail extraction or closed resummation','C8 or Lemma4.5 completion','Lean or compiled consumer proof','Registry/frontier/ledger/Goal state'],
'no_implementation_or_proof_API_exposure':True,
'bounded_verdict':'SOURCE/BINDER semantics unchanged ACCEPT; revised lossless topology is proposed for distinct challenge; no proof/VERIFIED credit.'}
# The two context selector arrows are provenance links, not logical premises.
for e in E:
 if e['edge_kind']=='NONIMPLICATION_CONTEXT_SELECTION':
  e['provenance_inputs_only']=e['parents']; e['parents']=[]
  e['interpretation']='Select only the stated source fields. The original combined context is provenance, not an AND-premise or sufficient theorem route.'
N[0]['source_field_selector']={
 'dimension':{'anchor':'S4.SS1.p1.m3','literal_alttext':r'd\geq 2'},
 'theta':{'anchor':'S4.E11.m1','selected_subexpression':r'\theta_{i}=\frac{(i-\tfrac{1}{2})\pi}{d}',
          'other_subexpressions_excluded':['lambda_i formula','Lambda diagonal formula']},
 'index_adapter':'source i=i.val+1; selected theta formula only',
 'provenance_is_not_logical_AND_parent':True}
# Structural integrity checks are shape/provenance checks only, not mathematical certification.
ids={x['id'] for x in N};eids={x['id'] for x in E};assert len(ids)==len(N);assert len(eids)==len(E)
for e in E:
 assert e['consumer'] in ids
 assert all(p in ids or p.startswith('raw:') for p in e['parents'])
for s in summary:assert set(s['expansion_node_ids'])<=ids and set(s['expansion_edge_ids'])<=eids
for x in N+E:
 for r in x['raw_graph_refs']:
  cur=raw
  for a in r['json_pointer'].split('/')[1:]:cur=cur[int(a)] if isinstance(cur,list) else cur[a]
# Verify no spectral context reaches the alias target in the expanded dependency graph.
anc=set();todo=['integer-alias'];byconsumer={}
for e in E:byconsumer.setdefault(e['consumer'],[]).extend(e['parents'])
while todo:
 n=todo.pop()
 if n in anc:continue
 anc.add(n);todo.extend(byconsumer.get(n,[]))
assert 'ctx-kappa-spectrum' not in anc and 'c7-expand' not in anc
assert all(s['formal_implication'] is False for s in summary)
(O/'lossless-topology-successor.json').write_text(json.dumps(obj,indent=2)+'\n')
(O/'clarification-report.md').write_text('''# Append-only bounded topology clarification

This successor keeps seal GC-FIXED-SPECTRUM-GRID-ALIAS-20261109-v2 and every prior frozen file unchanged. It supersedes only the interpretation of the three phase2 projected edges as sufficient hyperedges and the overly broad standing-grid attachment.

The producer now selects exactly d>=2 and the literal midpoint theta grid from the combined raw source atom. Kappa/eigenvalue/rho data are a separate consumer-only context; the expanded alias ancestor graph contains none of them. The context attachment is explicitly nonimplicational: a definition does not prove the alias.

The all-integer alias route explicitly retains universally guarded nonmultiple and multiple branches, the exhaustive case assembly, exact integer quotient, zero/negative parity, grid-index transport and nonzero dimension. The quoted finite cosine ratio, nonmultiple sine-denominator nonzero fact, integer sine zero and integer cosine parity appear as REQUIRED internal SOURCE_GAP background obligations. They are not theorem binders or proved results.

All three predecessor projected edges are explicitly typed COARSENED_SUMMARY_NOT_SUFFICIENT_HYPEREDGE. Their lossless expansions carry exact content-hash-bound raw graph node/edge pointers. C7 derives weighted finite-series exchange; the grid context, positive n range and actual alias derive constant elimination; standard product-to-sum derives the two-frequency transform. C7+exchange+zero+product-to-sum then gives the deterministic prealias series. All-integer alias substitution and internally derived summability transport yield the supported-series consumer specification. Exchange, zero and summability are never free premises.

The frequency guards are disjoint/exhaustive cases, not simultaneous AND hypotheses and not alternative complete OR proof routes. The consumer ingredients belong to one author route with explicit incoming obligations. Every new background gap is unproved here; this is lossless source topology and no formal proof certificate.

Gaussian expectation identification, tail extraction/regrouping/closed resummation, p7-p11, C8 and Lemma4.5 remain outside this bounded result. No Lean implementation, target proof or proof API was read or produced. Exact seal/binder semantics are unchanged; the successor awaits distinct topology challenge.
''')
(O/'structural-check.json').write_text(json.dumps({'checked_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'node_ids_unique':True,'edge_ids_unique':True,'all_refs_resolve':True,'all_summary_expansions_resolve':True,'alias_ancestor_nodes':sorted(anc),'alias_has_no_kappa_c7_ancestor':True,'all3_predecessor_edges_explicitly_nonsufficient_summaries':True,'warning':'Structural/provenance lint is not mathematical source review or proof.'},indent=2)+'\n')
print('successor',sha256((O/'lossless-topology-successor.json').read_bytes()).hexdigest(),'nodes',len(N),'edges',len(E))
