from pathlib import Path
from datetime import datetime, timezone
import copy,difflib,hashlib,json
from bs4 import BeautifulSoup

ROOT=Path('/Users/zhouhuanjian/ASTIS-GC')
BASE=ROOT/'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-admissibility-semantic-evidence/source-only-review'
P1=BASE/'phase1';P2=BASE/'phase2';OUT=BASE/'phase2-repair1'
SEAL=ROOT/'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-admissibility-statement-seal.json'
PINS={
 'phase1/freeze.json':'5363e9c98e484dc4439d700cdbe7ece589ec4cb5fafdcd832a0bf2a65d6e4327',
 'phase1/source-graph.json':'0159b1fdc8698702683dbe7fb872ec1e60e0be7ab0d8140f6b70b1bf85c6e0e7',
 'phase1/coverage.json':'bec73318e0437f4dc2bc70ae79286f27218ef4a884aa33523ca9fa5ecea1623b',
 'phase2/freeze.json':'b3b9107bc1d68aff6cfd596134f00a5e6256f455bdca3bbb95498ac19ef545de',
 'phase2/source-graph.json':'087371c7140770ca54fa99783977c47f5649627ebdd5811c3d129fed3f2e1055',
 'phase2/coverage.json':'35b6f8ef7bc110216db59e3503c3c5f0264c580ff4be088929eb3da0076e80a1',
 'phase2/matching.json':'7f9a94c01c06fc1b11fd60e622837f78032d40201ae86f032b98796856475b98',
 'phase2/exposure-manifest.json':'5e88d3874ed6233d00353b724fdb64ab82de8fc65264ba4f2cc0ac1e8fa54322',
 'phase2/rawhashes.json':'28df3ec734809446c1bce9d54d33efa4c8dc23148b3fb0c7e8580f0d8b765264',
}
def sha_bytes(b):return hashlib.sha256(b).hexdigest()
def sha(p):return sha_bytes(p.read_bytes())
def read(p):return json.loads(p.read_text())
def write(name,value):
    p=OUT/name;p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
def copy_input(p,name):
    dst=OUT/'inputs'/name;dst.parent.mkdir(parents=True,exist_ok=True)
    dst.write_bytes(p.read_bytes())
    return {'path':str(p.relative_to(ROOT)),'sha256':sha(p),'snapshot':str(dst.relative_to(OUT))}

assert not (OUT/'freeze.json').exists(),'Repair revision already frozen.'
assert all(sha(BASE/n)==h for n,h in PINS.items())
assert sha(SEAL)=='ab68d72daa52e4607be3acf310b93cb0ad20c3638cd8062078805e3a33eccab0'
seal=read(SEAL)
assert sha_bytes(seal['exact_signature_utf8'].encode())=='186231307d4c41acba15a1098c56518120394295cf048f504fed6f8ea50018d5'
OUT.mkdir(parents=True,exist_ok=True)
inputs=[copy_input(P2/'source-graph.json','before-source-graph.json'),
        copy_input(P2/'matching.json','before-matching.json'),
        copy_input(SEAL,'unchanged-statement-seal.json')]

source=P1/'source-original.html'
assert sha(source)=='6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
soup=BeautifulSoup(source.read_bytes(),'html.parser')
raw=str(soup.find(id='A3.SS4.p3')).encode()
(OUT/'inputs/raw-A3.SS4.p3.html').write_bytes(raw)
inputs.append({'path':str(source.relative_to(ROOT)),'full_source_sha256':sha(source),
 'selected_anchor':'A3.SS4.p3','selected_source_sha256':sha_bytes(raw),'snapshot':'inputs/raw-A3.SS4.p3.html',
 'serialization_note':'BeautifulSoup serialization of the pinned raw source DOM; full original hash is authoritative.'})

before=read(P2/'source-graph.json');after=copy.deepcopy(before)
edge_id='edge:fs-admiss:determinant'
edge_index=next(i for i,e in enumerate(before['edges']) if e['id']==edge_id)
parent='sg:fs-admiss:normalizer-integral'
assert parent not in after['edges'][edge_index]['parents']
after['edges'][edge_index]['parents'].append(parent)
after['phase']='phase2-repair1-source-derived-dependency-correction'
after['source_topology_unchanged']=False
after['source_topology_delta']={
 'base_phase2_source_graph_sha256':sha(P2/'source-graph.json'),
 'mathematical_change':'Add one existing prerequisite to the determinant edge because its unchanged full node claim also includes the normalizer equality.',
 'changed_edge':edge_id,'added_parent':parent,
 'unchanged':'All source nodes/claims, every other edge field, coverage, selected-producer scope, pending source branches and the exact producer seal.'}
after['boundary']='All frozen source nodes/claims and coverage are retained. A separate source-derived repair adds the existing normalizer-integral prerequisite to the full determinant-plus-Z claim. No source assertion is deleted, no producer premise is added, and all pending C4 branches remain unproved.'
after['status']='proposed-dependency-repair-pending-distinct-challenger-review'
write('source-graph.json',after)

# Exact source coverage file is carried forward byte for byte.
(OUT/'coverage.json').write_bytes((P2/'coverage.json').read_bytes())

matching=read(P2/'matching.json')
matching['phase']='phase2-repair1'
matching['source_graph_revision']={
 'base_phase1_source_graph_sha256':PINS['phase1/source-graph.json'],
 'before_phase2_source_graph_sha256':sha(P2/'source-graph.json'),
 'after_repair_source_graph_sha256':sha(OUT/'source-graph.json'),
 'changed_edge':edge_id,'added_parent':parent,
 'scope':'A dependency correction solely in the pending appended C4 normalization branch. The selected producer and exact signature are unchanged.'}
matching['proof_route_independence']='Frozen source topology remains the base. This separate revision corrects one full-claim dependency after independent raw-source rereading of A3.SS4.p3.1/A3.Ex160. No implementation/API route was opened or used. All source claims and producer meaning adapters remain unchanged.'
matching['remaining_gate']='Distinct challenger review of this exact repaired revision; no proof/source verification or completion claim.'
write('matching.json',matching)

write('repair-rationale.json',{
 'challenge_input':'Root relayed the distinct challenger concern that determinant-invariance claims both det(OΛOᵀ)=detΛ and hence the Z_A formula, but its producing edge omitted normalizer-integral.',
 'independent_source_observation':{
   'anchors':['A3.SS4.p3.1','A3.Ex160','A3.SS4.p3.2'],
   'formula':r'Z_A=(2π)^(d/2)(det A)^(−1/2)=(2π)^(d/2)(det Λ)^(−1/2)',
   'finding':'The determinant identity alone cannot identify Z_A. The first Gaussian-integral equality is consumed to derive the second displayed equality. The next sentence then uses fixed Λ to remove dependence on O.'},
 'decision':'Add the existing normalizer-integral parent to edge:fs-admiss:determinant; retain the full node claim unchanged.',
 'minimality':'Exactly one mathematical edge-parent addition. The determinant node, full Z_A claim, downstream known-normalizer combination, source coverage and producer signature are preserved. Other changes are revision provenance and exposure bookkeeping.',
 'why_acyclic':'normalizer-integral depends on Gaussian-target/conjugated-bounds/normalization-gap and has no dependency on determinant-invariance; adding its outgoing dependency to determinant-invariance introduces no reverse path.',
 'obligation_boundary':'Gaussian normalization remains an unproved internal source gap. The repaired edge only records its use; it does not prove it or make it a public hypothesis.',
 'producer_boundary':'The repair is entirely in the pending appended C4 branch. It does not alter d≥2, κ≥2, actual orthogonal O, literal grid/A, produced PosDef or the two PSD conclusions.',
 'classification':'internal-source-graph-dependency-correction; neither mathematical counterexample nor theorem-binder repair nor proof closure',
 'status':'proposed-repair-awaiting-distinct-review'})

write('exact-diff.json',{
 'format':'RFC6902 mathematical-edge patch plus explicit revision metadata',
 'graph_edge_patch':[{'op':'add','path':f'/edges/{edge_index}/parents/-','value':parent}],
 'before_edge':before['edges'][edge_index], 'after_edge':after['edges'][edge_index],
 'unchanged_node_claim':next(n for n in after['nodes'] if n['id']=='sg:fs-admiss:determinant-invariance'),
 'graph_before_sha256':sha(P2/'source-graph.json'),'graph_after_sha256':sha(OUT/'source-graph.json'),
 'matching_before_sha256':sha(P2/'matching.json'),'matching_after_sha256':sha(OUT/'matching.json'),
 'coverage_before_sha256':sha(P2/'coverage.json'),'coverage_after_sha256':sha(OUT/'coverage.json'),
 'seal_sha256':sha(SEAL),'signature_sha256':sha_bytes(seal['exact_signature_utf8'].encode()),
 'frozen_predecessor_pins':PINS})

for name in ['source-graph.json','matching.json']:
    diff=''.join(difflib.unified_diff((P2/name).read_text().splitlines(keepends=True),(OUT/name).read_text().splitlines(keepends=True),fromfile='frozen-phase2/'+name,tofile='phase2-repair1/'+name))
    (OUT/(name+'.diff')).write_text(diff)

write('exposure-manifest.json',{
 'role':'independent source-graph extractor/matcher performing a bounded repair; not a proof worker',
 'revision':'phase2-repair1','previous_exposure_manifest_sha256':PINS['phase2/exposure-manifest.json'],
 'new_authorized_challenge_exposure':'Root relayed one distinct challenger concern and two permissible repair options. No independent reviewer artifact or unrelated previous result was opened.',
 'new_source_reading':'Reread full raw C4 and the exact A3.Ex160 display from the pinned full original. Only the p3 normalizer branch determines this correction.',
 'inputs':inputs,
 'new_implementation_or_API_exposure':'None. No production/Test/target API, Std API or proof, root preseal audit, authored publication or old reviewer file was opened in this repair.',
 'mutations':'Only this new phase2-repair1 subtree and private helper build_phase2_repair1.py were written. Frozen phase1 and phase2 were not modified.',
 'preserved_truth_boundary':'All source gaps remain unproved. The selected producer seal, source assumptions, scope and pending downstream branches are unchanged. No source verification or completion claim.',
 'stop_rule':'Freeze exact revision and send hashes to root, then stop for distinct challenger review.'})

write('raw-inputs.json',{
 'revision':'phase2-repair1','frozen_predecessor_pins':PINS,
 'source_original_sha256':sha(source),'selected_source_inputs':inputs,
 'seal_sha256':sha(SEAL),'signature_sha256':sha_bytes(seal['exact_signature_utf8'].encode()),
 'no_target_proof_or_API_input':True})

