from pathlib import Path
import hashlib,json
root=Path('/Users/zhouhuanjian/ASTIS-GC')
out=root/'.astis/semantic-neutral-20261110/src_d63b90/phase1'
commands=[]
def add(chunk,cmd,code,exposure,limit):
    ident=f'{len(commands)+1:02d}'
    p=out/f'toolread-{ident}.sh';p.write_text(cmd+'\n')
    commands.append({'sequence':len(commands)+1,'tool':'functions.exec -> tools.exec_command','cwd':str(root),'exact_command_file':str(p.relative_to(root)),'command_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'observed_result_chunk_id':chunk,'observed_exit_code':code,'requested_max_output_tokens':limit,'visible_exposure':exposure})
add(None, 'pwd && cat AGENTS.md',0,'Repository instructions; exact chunk id was not returned in the visible first result and is corrected below.',18000)
commands[-1]['observed_result_chunk_id']=None
commands[-1]['visible_exposure']='Repository AGENTS.md instruction text, including generic protocol and scheduling guidance. No scheduled state or proof artifact opened.'
add('6c119c','cat docs/proof-digestion-protocol.md',0,'Generic source/seal/binder/topology/publication workflow instructions.',25000)
add('be95a3',"rg --files docs -g '*semantic*'",1,'No matching paths returned; no proof artifacts exposed.',2000)
add('bd9b6c','shasum -a 256 .astis/huanjian-resume-20261103/2610.20492v1.html',0,'Pinned HTML digest only, matching authorized digest.',1000)
add(None,"rg -n 'semantic|round.trip|denois|decoder' docs/theorem-publication-protocol.md docs/formalization-protocol.md",0,'Generic instruction lines and path of semantic-roundtrip skill. Exact chunk id corrected below.',7000)
commands[-1]['observed_result_chunk_id']=None
commands[-1]['visible_exposure']='Generic instruction lines and exact path .agents/skills/astis-semantic-roundtrip/SKILL.md.'
add(None,'cat .agents/skills/astis-semantic-roundtrip/SKILL.md',0,'Generic anti-anchoring, independent-review and seven-slot instructions. Exact chunk id not present in visible result.',25000)
commands[-1]['observed_result_chunk_id']=None
add(None,'cat docs/theorem-publication-protocol.md',0,'Generic publication instructions. Exact chunk id not present in visible result.',18000)
commands[-1]['observed_result_chunk_id']=None
add('853fb7',"""python3 - <<'PY'
from pathlib import Path
import re
p=Path('.astis/huanjian-resume-20261103/2610.20492v1.html')
s=p.read_text()
for ident in ['S4.SS1','S4.Thmtheorem5','A3.SS3']:
    m=re.search(r'<[^>]+\\bid="'+re.escape(ident)+r'"[^>]*>',s)
    print(ident, 'offset',m.start() if m else None)
    if m: print(s[m.start():m.start()+7000])
PY""",0,'First 7000 source characters at each authorized source anchor. Snippets include Eq11, lemma opening and C.3 opening.',9000)
script=(root/'.astis/semantic-neutral-20261110/src_d63b90/extract_source.py').read_text()
add('ea52e5',"mkdir -p .astis/semantic-neutral-20261110/src_d63b90/phase1 && cat > .astis/semantic-neutral-20261110/src_d63b90/extract_source.py <<'PY'\n"+script+"PY\npython3 .astis/semantic-neutral-20261110/src_d63b90/extract_source.py inspect",0,'Own stdlib HTMLParser tool creation; only parents/sibling structure IDs/classes of three authorized anchors printed.',5000)
add('1f545c','python3 .astis/semantic-neutral-20261110/src_d63b90/extract_source.py extract S4.SS1 S4.Thmtheorem5 S4.SS2.SSS0.Px3.p1 S4.SS2.SSS0.Px3.p2 A3.SS3',0,'Exact raw fragments written and hash/range manifest printed.',5000)
add('e3de64','cat .astis/semantic-neutral-20261110/src_d63b90/phase1/S4.SS1.txt .astis/semantic-neutral-20261110/src_d63b90/phase1/S4.Thmtheorem5.txt .astis/semantic-neutral-20261110/src_d63b90/phase1/S4.SS2.SSS0.Px3.p1.txt .astis/semantic-neutral-20261110/src_d63b90/phase1/S4.SS2.SSS0.Px3.p2.txt',0,'Entire Section4.1, lemma, immediate context. Math rendered once using original MathML alttext.',6500)
add('b2cb05','cat .astis/semantic-neutral-20261110/src_d63b90/phase1/A3.SS3.txt',0,'Entire Appendix C.3, including both named facts and all subsequent lemma proof.',13000)
add('498921',"""python3 - <<'PY'
import sys,runpy,json
sys.argv=['extract_source.py','context']
g=runpy.run_path('.astis/semantic-neutral-20261110/src_d63b90/extract_source.py')
p=g['p']; render=g['textnode']
print('Document title:',g['html'][g['html'].find('<title>'):g['html'].find('</title>')+8])
for ident,n in p.ids.items():
    if n.tag in {'h2','h3','h4'} and ('notation' in render(n).lower() or 'preliminar' in render(n).lower()): print(ident,render(n))
for ident in ['bib.bib3']:
    n=p.ids.get(ident)
    if n: print('Citation:',ident,render(n))
PY""",0,'Paper title and bibliography item [22] only. No notation headings emitted. Linked preprint not opened.',4000)
add('eaa3ff',"""python3 - <<'PY'
import sys,runpy,re
sys.argv=['extract_source.py','context']
g=runpy.run_path('.astis/semantic-neutral-20261110/src_d63b90/extract_source.py')
html=g['html'];p=g['p'];render=g['textnode']
for m in list(re.finditer(r'notation|Throughout|throughout|conventions',html))[:12]:
    containers=[(n.end-n.start,ident,n) for ident,n in p.ids.items() if n.start<=m.start()<n.end and n.tag in {'div','section','p'}]
    if containers:
        _,ident,n=min(containers,key=lambda x:x[0]); print(ident, render(n))
PY""",0,'Incidental abstract1.1 exposure repeated because regex notation matched annotation. Only raw-source abstract, no candidate material. Frozen separately.',4000)
add('d066a9','python3 .astis/semantic-neutral-20261110/src_d63b90/extract_source.py extract bib.bib3 abstract1.1',0,'Raw fragment hashes/ranges for already-exposed citation and incidental abstract.',4000)
add('c632d8',"""python3 - <<'PY'
import sys,runpy,json
from pathlib import Path
sys.argv=['extract_source.py','inventory']
g=runpy.run_path('.astis/semantic-neutral-20261110/src_d63b90/extract_source.py')
p=g['p']; s=g['html']; scope=p.ids['A3.SS3']; out=[]
for ident,n in p.ids.items():
    if scope.start<=n.start and n.end<=scope.end and n.tag in {'div','table','tbody'}:
        out.append({'id':ident,'tag':n.tag,'class':n.attrs.get('class',''),'lines':[s.count('\\n',0,n.start)+1,s.count('\\n',0,n.end)+1]})
f=Path('.astis/semantic-neutral-20261110/src_d63b90/phase1/source-unit-inventory.json')
f.write_text(json.dumps(out,indent=2)+'\\n')
print(json.dumps(out,indent=2))
PY""",0,'Only structural IDs/classes/line ranges within already-read C.3.',6000)
# All unknown chunk IDs remain null; none are invented identifiers.
for x in commands:
    if x['observed_result_chunk_id'] is None:
        x['chunk_note']='The first plain-text-only exec renderer did not expose a chunk identifier to this reviewer; command, exit status and output were visible.'
inputs=[]
for name in ['AGENTS.md','docs/proof-digestion-protocol.md','docs/theorem-publication-protocol.md','docs/formalization-protocol.md','.agents/skills/astis-semantic-roundtrip/SKILL.md','.astis/huanjian-resume-20261103/2610.20492v1.html']:
    p=root/name; inputs.append({'path':name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'read_scope':'whole file' if name not in ['docs/formalization-protocol.md','.astis/huanjian-resume-20261103/2610.20492v1.html'] else ('matching instruction lines only' if name.startswith('docs/') else 'parsed entirely locally; visible mathematical exposure bounded to raw-input manifest plus structural siblings and source title')})
ledger={'phase':1,'reviewer_task':'/root/source_reader_d63b90','source_sha256':'6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915','authorization':'Parent first-phase task only; source identity, exact source anchors and scope were provided. No target design or candidate supplied.','candidate_exposure':False,'reconstruction_exposure':False,'prior_audit_review_repair_graph_exposure':False,'mathlib_or_lean_source_exposure':False,'network_browser_build_or_production_mutation':False,'instructions_and_source_inputs':inputs,'toolreads':commands,'artifact_only_writes':['extract_source.py creation embedded in toolread-09.sh','source-cognition.md via shell heredoc, observed chunk 5c09aa, exit0','build_ledger.py creation/execution and later freeze validation; no new external semantic inputs'],'independence_note':'Protocol text is generic. AGENTS scheduling filenames were seen but not opened, because the explicit reviewer role forbids frontier/ledger/graph exposure. Structural source sibling identifiers are raw-source metadata rather than candidate design.','scope_caveat':'One accidental raw-source abstract exposure is retained explicitly. There is no claim that the only HTML read from disk was the rendered slice: the private parser necessarily read the pinned file, while only authorized slices and declared incidental source context were emitted.'}
(out/'exposure-toolread-ledger.json').write_text(json.dumps(ledger,indent=2)+'\n')
print(json.dumps({'toolreads':len(commands),'inputs':len(inputs),'ledger_sha256':hashlib.sha256((out/'exposure-toolread-ledger.json').read_bytes()).hexdigest()},indent=2))
