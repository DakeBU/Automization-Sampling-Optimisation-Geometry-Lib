cat docs/proof-digestion-protocol.md
