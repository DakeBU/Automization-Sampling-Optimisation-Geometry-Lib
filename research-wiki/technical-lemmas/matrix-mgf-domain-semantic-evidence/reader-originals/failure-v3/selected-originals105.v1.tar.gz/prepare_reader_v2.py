"""Independent R17 reader syntax/static-input preparation only; no server, render, or Chrome invocation."""
import argparse,ast,datetime as dt,hashlib,json,os,subprocess,sys,time,traceback
from pathlib import Path
from html.parser import HTMLParser
OWN=Path(__file__).resolve().parent;REPO=OWN.parents[2]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
class Node:
    def __init__(self,tag='',attrs=()):self.tag=tag;self.attrs=dict(attrs);self.children=[]
    def text(self):return ''.join(x if isinstance(x,str) else x.text() for x in self.children)
    def has(self,c):return c in self.attrs.get('class','').split()
    def find(self,p):
        out=[]
        for x in self.children:
            if isinstance(x,Node):
                if p(x):out.append(x)
                out+=x.find(p)
        return out
class Parse(HTMLParser):
    def __init__(self,s):super().__init__(convert_charrefs=True);self.root=Node();self.stack=[self.root];self.feed(s)
    def handle_starttag(self,t,a):
        n=Node(t,a);self.stack[-1].children.append(n)
        if t not in {'area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr'}:self.stack.append(n)
    def handle_endtag(self,t):
        for i in range(len(self.stack)-1,0,-1):
            if self.stack[i].tag==t:self.stack=self.stack[:i];break
    def handle_data(self,s):self.stack[-1].children.append(s)
def main():
    p=argparse.ArgumentParser();p.add_argument('--preview-root',type=Path,required=True);p.add_argument('--delivery',type=Path,required=True);p.add_argument('--delivery-sha256',required=True);p.add_argument('--selection',type=Path,required=True);p.add_argument('--selection-sha256',required=True);args=p.parse_args()
    checks=[]
    def check(name,ok,detail=None):
        checks.append({'name':name,'pass':bool(ok),'detail':detail})
        if not ok:raise AssertionError(name)
    preview=args.preview_root.resolve();fixture=preview/'fixtures/candidate';snapshot=preview/'input-snapshot';mp=preview/'preview-freeze-manifest.json'
    check('exact-delivery-sha',sha(args.delivery)==args.delivery_sha256=='ed0f31c2598a91e6ea708350a8a08a23627898d0c41b0c96ba2ed23f3fcdbccf')
    delivery=json.loads(args.delivery.read_text());selection=json.loads(args.selection.read_text());m=json.loads(mp.read_text())
    check('exact-v3-manifest',sha(mp)=='cb35d92094afe575fc6dfa96e2960508bd5c4e699f3c46e5d19c521afc697965')
    check('exact110-selection-sha',sha(args.selection)==args.selection_sha256=='a0114d46eacf0832240bf757bc473778510e7475ac9c936ea028c2fea77fe2ed')
    check('delivery-target-exact',fixture==(REPO/delivery['fixture_candidate']).resolve() and fixture==(REPO/selection['source_base']).resolve())
    check('delivery-all-explicit-files-byte-exact',all(sha(REPO/x['path'])==x['sha256'] for x in delivery['files']))
    rows=m['variants']['candidate']['files'];check('manifest-selection110-rows-identical',len(rows)==110 and rows==selection['files'])
    check('candidate-file-set110-exact',{str(x.relative_to(fixture)) for x in fixture.rglob('*') if x.is_file()}=={x['path'] for x in rows})
    check('all110-served-file-bytes-exact',all((fixture/x['path']).is_file() and not (fixture/x['path']).is_symlink() and sha(fixture/x['path'])==x['sha256'] and (fixture/x['path']).stat().st_size==x['bytes'] for x in rows))
    freeze=json.loads((preview/'input-freeze-manifest.json').read_text());check('all-explicit-input-snapshot-bytes-exact',all(sha(snapshot/x['path'])==x['sha256'] and (snapshot/x['path']).stat().st_size==x['bytes'] for x in freeze['files']))
    prior=preview.parent/'static-closure-v2';old=json.loads((prior/'preview-freeze-manifest.json').read_text());identical=0
    for variant,v in m['variants'].items():
        check(variant+'-v2-v3-served-row-identities',v['files']==old['variants'][variant]['files'])
        for x in v['files']:
            check(variant+'-actual-v2-v3-byte-identity:'+x['path'],(preview/'fixtures'/variant/x['path']).read_bytes()==(prior/'fixtures'/variant/x['path']).read_bytes());identical+=1
    check('actual219-served-byte-identities',identical==219)
    tree=ast.parse((OWN/'browser_check.py').read_text());names={}
    for n in tree.body:
        if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id in ['ITEM','PFILE','TFILE','P','T','PSD','TRACE','SOURCES']:
            names[n.targets[0].id]=eval(compile(ast.Expression(n.value),'<pure own literal targets>','eval'),{'__builtins__':{}},names)
    sources=names['SOURCES'];PF=names['PFILE'];TF=names['TFILE'];unit=json.loads((snapshot/'website/content/declaration_lessons/huanjian-matrix-mgf-domain.json').read_text())['units'][0]
    check('immutable-a8bb-source-identity',m['proof_commit']=='a8bb8ea5b4474be5214bd83ae380a612e2cecb78' and sha(snapshot/PF)=='d3c6e5a194fecf1ae1abe45c70310f4f47d66e903b098019c326ee0d3018b024' and sha(snapshot/TF)=='60e9f7b928ebc1b8a0d9efad93f39f1b172fe0a871893d67eb1015582c5d5c61')
    check('five-exact-P-P-T-T-T-ranges',[s['lean_source_path'] for s in unit['steps']]==[PF]*2+[TF]*3 and [s['lean_source']['LF_lines_1based'] for s in unit['steps']]==[[1,28],[29,50],[1,137],[138,186],[187,212]])
    check('P50-T212-all262-lines-exact',''.join(s['lean'] for s in unit['steps'][:2]).encode()==(snapshot/PF).read_bytes() and ''.join(s['lean'] for s in unit['steps'][2:]).encode()==(snapshot/TF).read_bytes())
    dom=Parse((fixture/m['variants']['candidate']['proof_path']).read_text()).root;article=dom.find(lambda n:n.tag=='article' and n.has('proof-reader'))[0];steps=article.find(lambda n:n.tag=='details' and n.has('proof-reader-step'))
    check('actual-five-adjacent-step-code-spans',len(steps)==5 and [n.find(lambda x:x.tag=='pre' and x.has('code-block'))[0].text() for n in steps]==[s['lean'] for s in unit['steps']])
    check('all-main-disclosures-initially-closed',all('open' not in n.attrs for n in dom.find(lambda n:n.tag=='main')[0].find(lambda n:n.tag=='details')))
    check('inline-whole-module-links-present',len(article.find(lambda n:n.tag=='details' and n.has('inline-lean')))==2 and len(article.find(lambda n:n.tag=='a' and 'modules/' in n.attrs.get('href','')))>=2)
    for i,(step,s) in enumerate(zip(steps,unit['steps']),1):
        copy=step.find(lambda n:n.tag=='button' and 'data-lean-copy' in n.attrs);source=step.find(lambda n:n.tag=='a' and 'data-step-source' in n.attrs);download=step.find(lambda n:n.tag=='a' and 'download' in n.attrs)
        check('step'+str(i)+'-adjacent-action-selectors-and-paths',len(copy)==len(source)==len(download)==1 and source[0].attrs['href'].endswith(s['lean_source_path']+'.html#L'+str(s['lean_source']['LF_lines_1based'][0])) and download[0].attrs['href'].endswith('downloads/lean/'+s['lean_source_path']))
    for label,raw,decl,anchor,count in sources:
        expected=(snapshot/raw).read_bytes();source=Parse((fixture/('data/lesson-sources/'+raw+'.html')).read_text()).root;pre=source.find(lambda n:n.tag=='pre')
        check(label+'-full-source-body-and-lines-exact',len(pre)==1 and pre[0].text().encode()==expected and len(expected.decode().splitlines())==count)
        check(label+'-anchor-and-exact-full-source-actions',len(source.find(lambda n:n.attrs.get('id')=='L'+str(anchor)))==1 and len(source.find(lambda n:n.tag=='button' and 'data-lean-copy' in n.attrs))==1 and len(source.find(lambda n:n.tag=='a' and 'download' in n.attrs))==1)
        check(label+'-whole-download-byte-exact',(fixture/('downloads/lean/'+raw)).read_bytes()==expected)
    index=Parse((fixture/'source-index.html').read_text()).root.find(lambda n:n.tag=='main')[0]
    check('source-index-six-exact-labels',[x.text() for li in index.find(lambda n:n.tag=='li') for x in li.find(lambda n:n.tag=='a')]==[s[2] for s in sources])
    parent=Parse((fixture/'parent-context.html').read_text()).root.find(lambda n:n.tag=='main')[0]
    check('parent-context-correct-five-parent-links',[x.text() for li in parent.find(lambda n:n.tag=='li') for x in li.find(lambda n:n.tag=='a')]==[names['PSD'],names['P'],names['TRACE'],sources[4][2],sources[5][2]])
    for raw in [PF,TF]:
        module=raw[:-5].replace('/','.');path=next(n['url'] for n in json.loads((fixture/'data/underlying-lean-graph.json').read_text())['nodes'] if n['id']=='module:'+module);page=Parse((fixture/path).read_text()).root
        check(raw+'-module-context-full-last-pre-exact',page.find(lambda n:n.tag=='pre')[-1].text().encode()==(snapshot/raw).read_bytes())
    graph=json.loads((fixture/'data/underlying-lean-graph.json').read_text());modules=[x[1][:-5].replace('/','.') for x in sources]
    expected_nodes={'module:'+v for v in modules}|{'decl:'+sources[i][2] for i in [0,2,3,4,5]}
    expected_edges={('module:'+modules[2],'module:'+modules[0],'imports')}|{('module:'+modules[i],'module:'+modules[1],'imports') for i in [0,3,4,5]}|{('module:'+modules[i],'decl:'+sources[i][2],'declares') for i in [0,2,3,4,5]}|{('decl:'+names['PSD'],'decl:'+names['P'],'source reference (scanner)')}|{('decl:'+sources[i][2],'module:'+modules[1],'source reference (scanner)') for i in [0,3,4,5]}
    check('exact11node15edge-graph-source-reference-directions',len(graph['nodes'])==11 and {x['id'] for x in graph['nodes']}==expected_nodes and len(graph['edges'])==15 and {(x['source'],x['target'],x['relation']) for x in graph['edges']}==expected_edges)
    check('private-T-module-not-public-declaration','decl:'+names['T'] not in expected_nodes and list(expected_nodes).count('module:'+modules[1])==1)
    node=REPO/'.astis/huanjian-gc-integration-20261105/browser-venv/lib/python3.12/site-packages/playwright/driver/node';js_checks=0
    for filename in ['browser_check.py','browser_geometry.py']:
        parsed=ast.parse((OWN/filename).read_text(),filename=filename);expressions=[]
        if filename=='browser_geometry.py':expressions=[ast.literal_eval(n.value) for n in parsed.body if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id in ['GEOMETRY','VISIBLE','GLYPH']]
        else:
            for n in ast.walk(parsed):
                if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr in ['evaluate','evaluate_all','wait_for_function'] and n.args and isinstance(n.args[0],ast.Constant) and isinstance(n.args[0].value,str):expressions.append(n.args[0].value)
        for i,s in enumerate(expressions):
            r=subprocess.run([str(node),'--check'],input='('+s+');',text=True,capture_output=True);check(filename+'-JS-syntax'+str(i),r.returncode==0,{'actual_exit_code':r.returncode,'stdout':r.stdout,'stderr':r.stderr});js_checks+=1
    check('no-crop-screenshot-code','clip=' not in (OWN/'browser_check.py').read_text())
    check('no-browser-server-render-execution',not any((OWN/n).exists() for n in ['runtime-process','runtime-output','chrome-tmp','actual-result.json','execution-assignment.json']))
    chrome=Path('/Applications/Google Chrome.app/Contents/MacOS/Google Chrome');frozen=[args.delivery,args.selection,mp,preview/'input-freeze-manifest.json',preview/'render_preview.py',preview/'reader_overlay.py',snapshot/'website/content/declaration_lessons/huanjian-matrix-mgf-domain.json',snapshot/'website/content/publications/huanjian-matrix-mgf-domain.json',fixture/'data/underlying-lean-graph.json',*[snapshot/s[1] for s in sources]]
    draft={'authorization':'PREPARED_ONLY_AWAIT_ROOT_FRESH_SCOPED_APPROVAL','preview_root':str(preview),'runner_sha256':sha(OWN/'browser_check.py'),'geometry_sha256':sha(OWN/'browser_geometry.py'),'preview_manifest_sha256':sha(mp),'source_reviewed_publication_binding_sha256':'5e79fa3d4390c4d1e689174b0c014d67fb8dbfb550f986b4af7d8474ef644691','actual_source_review_run_sha256':'1b2e4964109b4ca0c495f9ad2ecf50ed7f1508adfe38370487a182ad5fc9466a','frozen_inputs':[{'path':str(p.resolve()),'sha256':sha(p)} for p in frozen],'lesson_sha256':m['lesson_sha256'],'publication_sha256':m['publication_sha256'],'chrome':{'path':str(chrome),'binary_sha256':sha(chrome)},'execution_custody':'ROOT must create a separate actual assignment after reviewing exact new scripts and request fresh scoped Chrome/localhost approval.'}
    dump(OWN/'execution-assignment.draft.json',draft)
    report={'schema':'R17-independent-reader-preparation-v1','status':'PREPARED_ONLY_NO_CHROME_BROWSER_SERVER_RENDER_OR_API','preview_root':str(preview),'delivery_sha256':sha(args.delivery),'selection_sha256':sha(args.selection),'preview_manifest_sha256':sha(mp),'checks':checks,'JavaScript_expressions_syntax_checked':js_checks,'runner_sha256':draft['runner_sha256'],'geometry_sha256':draft['geometry_sha256'],'actual_v2_v3_served_direct_byte_identities':219,'visible_caption_changed_claim':False,'metadata_carrier_affe4e_is_not_a_new_math_build':True,'actual_math_build_identity':'a8bb8ea5b4474be5214bd83ae380a612e2cecb78','reading_scope':'desktop1440x1000/mobile390x844 headless Chrome CSS viewports; 5P/P/T/T/T adjacent code actions,6source pages and downloads/sourceindex, canonicalP/PSD/privateTmodule graph focuses with exact11nodes/15 directed edges; no publicT declaration. Local MathJax3.2.2 retained, no KaTeX.','planned_PNGs':'About45-55 meaningful full viewport/fullpage states depending on actual source overflow; no optional crops. Actual count/false flags will be reported and every actual PNG independently inspected after the one authorized run.','geometry_scope':'Native wheel/pointer; selected node>=98% and core label>=95% inside actual SVG∩viewport∩overflow clipping; font>=12px; full identifier in detail; explicit1CSSpx horizontal Range-bbox glyph tolerance, not a pixel-zero clipping claim.','unmeasured':'All browser/render/layout/glyph/copy/download/network/console/navigation/geometry/visual outcomes remain pending. This syntax/static check gives no reader acceptance. Physical touch/full-site/production/normalV are outside scope.','old_R16_results_images_or_verdicts_inherited':False,'current_normal_API_V_or_cell_work_by_this_role':0,'concrete_planned_invocation':[str(REPO/'.astis/huanjian-gc-integration-20261105/browser-venv/bin/python'),str(OWN/'browser_check.py'),'--preview-root',str(preview),'--assignment',str(OWN/'execution-assignment.json')]}
    dump(OWN/'preparation-result.json',report);print(json.dumps({'status':report['status'],'checks':len(checks),'JS_syntax_checks':js_checks,'runner_sha256':draft['runner_sha256'],'geometry_sha256':draft['geometry_sha256'],'draft_assignment_sha256':sha(OWN/'execution-assignment.draft.json'),'report_sha256':sha(OWN/'preparation-result.json')}))
if __name__=='__main__':
    d=OWN/'static-process-v2';d.mkdir(exist_ok=False);out=d/'stdout.raw';err=d/'stderr.raw';utc=dt.datetime.now(dt.timezone.utc).isoformat();start=time.monotonic();code=0
    for fd,p in [(1,out),(2,err)]:
        f=p.open('xb',buffering=0);os.dup2(f.fileno(),fd);f.close()
    try:main()
    except BaseException:traceback.print_exc();code=1
    sys.stdout.flush();sys.stderr.flush();dump(d/'receipt.json',{'schema':'actual-R17-reader-preparation-syntax-static-OS-receipt-v1','argv':[sys.executable,*sys.argv],'cwd':str(REPO),'pid':os.getpid(),'started_utc':utc,'ended_utc':dt.datetime.now(dt.timezone.utc).isoformat(),'elapsed_seconds':time.monotonic()-start,'actual_exit_code':code,'stdout_sha256':sha(out),'stderr_sha256':sha(err),'script_sha256':sha(__file__),'scope':'Read/parse/hash and node --check only. No browser, render, localhost, Lean, normalAPI/cell/ledger/Git or source write.'});sys.exit(code)
