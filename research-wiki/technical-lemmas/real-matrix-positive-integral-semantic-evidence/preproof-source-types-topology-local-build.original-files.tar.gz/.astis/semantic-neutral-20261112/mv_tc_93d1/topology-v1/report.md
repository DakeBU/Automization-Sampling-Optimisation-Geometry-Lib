# Independent R9 source coverage and applicability-topology challenge

**Accept the bounded source coverage and unproved obligation topology. No
genuine source-statement, coverage or root-path blocker was found. All 23
internal mathematical/applicability ports remain open.** This is not a proof,
API-application check, compiled dependency, normal verification, integration
or permission grant.

## Independent evidence and exact binding

The actor completed its own raw freeze before new type exposure and its own
type audit before SG graph exposure. Those unchanged freezes are respectively
`c0bf670eba58674aac8b29d8fd313428955e76f13c20680ae47c84f1f4b536db`
and `0ea162c064a81d8403a1b5152c2b863790d161eebeea10ade73e3f2d5b7c9cab`.
The fixed seal is
`5f905cafe6035238cebdedd4f841e87b703e741b4c8aa204471d89e4c07e8a14`,
type packet `b9b93126880486157e88e9a59abcd2b89d81b4cf34d46fa9dc51f88d2b6e0170`,
producer `d5ac54443c79ea7b35b09ddcd6b5e3c40bef081bbe4f196cae5ab3ead35aa2ea`,
consumer `95e81a02e5302de9a42e3b60038ffad6195315ac2eca99a4e6abb39978609f7e`
and context `c8f86ad1db7cf3798073ff5bde1d859cd2f95dcd54dbe7f759fa4b2022c5383a`.
The public graph, coverage, ports, manifest and exposure record bind these
same fixed types.

Eight public top-level SG artifacts were read and byte-hash checked, including
the graph/coverage/ports, freeze manifest, manifest checksum and source reports.
Scoped filename inventory also exposed four inputs/ snapshots. Their builder,
type-audit, type-manifest and raw-v2-manifest contents remain unopened. Their
hashes were seen only as manifest metadata and are not independently certified
here. No SG type verdict/private rationale, new implementation, library proof,
API search or other review was used to select this challenge.

The extractor's report is public input, not the verdict adopted here. Its
chronology qualification preserves raw-before-own-type-exposure without
denying an already created global seal. Neither timestamps nor hashes confer
mathematical acceptance. The original pinned source, rather than an unopened
SG raw snapshot, is the source used for independent checks.

## Exhaustive bounded raw coverage

Every one of the 105 atomic dispositions was compared with an independent
projection of the pinned raw HTML: 50 NODE and 55 EXCLUDED, with 77 distinct
atom-source elements. The continuous source window contains exactly 67
independently identified substantive paragraph/display units, matching the
coverage list in source order. The window is C.2 through p15, plus the named
discontiguous S4 standing/grid elements; no whole-paper coverage is claimed.

All 374 locator occurrences in the public JSON records were checked for raw
SHA-256, UTF-8 span, Unicode-codepoint span and inclusive LF lines. The 90
distinct raw spans all match. Semantic slices were checked against the actual
shared element text, including mixed NODE/EXCLUDED paragraphs. Detailed
per-atom and per-locator records accompany this finding.

The representation correctly retains the actual row marginal law; literal
grid, feature indices and tensor convention; unweighted t Gram and t-norm
proofs; actual Y/Z; the untruncated Gaussian fourth moment and its sign/diagonal
argument; both rank-one square identities; exact Y^2; PSD cutoff removal;
Ex115-117's aggregate with explicit C.5 use; Ex118's centered identity/order;
and Ex120's deterministic weighted identity/order. The scalar |cos|<=1 clause
is retained separately from the excluded R-star bound in the same paragraph.

All six p15 atoms are EXCLUDED: independence, centered/self-adjoint Bernstein
context, Bernstein invocation and the two tails. No required PSD or centering
fact is supplied by an excluded p15 assertion. Those facts instead remain
internal obligations from the actual definitions. Joint independence, weighted
Gram cancellation, exact a/first-mean formulas, R-star, tail/common-event/bias,
concentration and main results are correctly outside this variance delta.
Excluding their formulas does not omit actual Y integrability: it is explicitly
an internal obligation with direct and public-provider alternatives.

The raw phrase "retained-unrestricted" in the fourth-moment invocation is
imprecise editorial wording. The graph and coverage explicitly clarify that
Ex113 is untruncated, and its exact raw formula has no indicator. This is not
a hidden truncation premise or a reason to rewrite frozen raw history.

## All roots, nodes and consumer-use edges

All 80 nodes, 129 directed edges and two OR records were inspected. There are
no dangling endpoints or cycles after accounting for the explicit alternative
links. Each consumer-use locator points to the actual source use, including
frequency discharge in p5.3, actual moment use at Ex115, C.5 use in p14.4 and
the two variance conclusions in p14.

Reverse closure of the formal producer covers 48 nodes, and the private
consumer covers 66, with both OR branches listed for review coverage only.
Source conclusion correspondences are also traced explicitly, rather than
turned into formal premises: square.sum-final has a 37-node source ancestry,
center.variance-assertion 42 and weighted.variance-assertion 47. The union of
formal and source-endpoint traces accounts for 77 nodes. The remaining three
are physical-index, feature-index and B-normalization context. All 80 nodes
are therefore accounted for, with no omitted mathematical region or
unexplained root branch. The source-correspondence links in root-coverage.json
are not invented theorem-dependency edges.

The tensor integral route is CLM OR finite-entry transport. Actual first-mean
integrability is direct derivation OR an exactly checked public provider. The
graph never requires both members of either pair as an AND, and neither
alternative is attributed as a second source-author proof. An unselected reuse
branch is not a guessed compiled parent. Reports about R4/R5/R8 or private
canonical-row tests supply no current public-provider application or proof.
Every such application remains an open port.

## Actual moment, matrix order and Bochner premises

The actual row-law port must match the physical evaluation coordinates under
the exact standard-Gaussian column product, including measurability and the
standard-Gaussian basis semantics. The fourth-moment port must establish the
actual untruncated R gamma gamma^T expectation, its integrability and exact
r+2 coefficient. A Gaussian name, old record or totalized integral identity
alone is insufficient. No arbitrary ambient law or caller certificate appears.

The matrix-square port must use ordinary matrix multiplication, both
rank-one identities, Kronecker multiplication, indicator idempotence and
inverse-d-squared scaling. PSD cutoff removal uses full Hermitian/quadratic
positivity and nonnegative scalar factors. The integral-order port must carry
that order through genuinely integrable actual matrices/majorants and finite
sums. No entrywise-order comparison substitutes for Loewner order. Source
frame applicability retains the constant slot, sqrt(2), actual midpoint grid,
q=0 and exact unweighted identity, giving inverse d and I_(r^2) at Ex117.
Weighted frame cancellation is not a prerequisite.

The current producer supplies squared-Y integrability and an upper PSD
difference. It does not supply actual first-mean integrability, mean-Hermitian
facts, positivity of every centered expected square or a norm bound merely by
its type. The graph explicitly keeps these missing proof ingredients internal.
The two possible Y-integrability routes must justify the actual mean, not a
formal matrix or a zero-default integral.

For Ex118, the noncommutative centering port must expand Y^2-YM-MY+M^2 with
M=the actual integral of Y. Both fixed-right and fixed-left matrix maps must
commute with the Bochner integral under the required integrability. The
constant M^2 term also requires justified integrability and mu(total)=1 from
the actual canonical probability product. These are mandatory discharges
inside the existing centering/integrability obligations, not new binders or
an assumption that Y commutes with M. The fixed type context supplies the
canonical probability-instance meaning; this review does not prove its
application. Mean Hermitian and mean-square PSD must be derived internally.

Actual Z Hermitian implies the relevant square PSD only after its literal
definition/mean facts are justified. The graph separately retains pointwise,
integrated and finite-sum PSD, with full finite-vector/Finsupp compatibility.
The weighted step requires both 0<=w_i^2 and w_i^2<=1, with exact deterministic
w_i=cos((2q+1)theta_i), and the actual expected centered-square PSD. The lower
scalar bound and the lower PSD of the weighted sum remain part of the internal
weighted-order/norm obligations; the upper cosine bound alone is not credited
as a complete norm proof.

The two PSD-to-norm ports require actual variance sums to satisfy
0<=PSD A<=PSD C I, with C=2r(r+2)/d nonnegative internally, in the real complete
Matrix L2Operator structure. They conclude the genuine Euclidean operator
norm bounds, not a relabelled upper Loewner inequality. The variance parameter
is the sum of expected per-row squares, not expectation of a squared row sum;
there is no independence/cross-term premise. At q=0, all constant-feature and
n=1 weighted endpoints remain; no positive-q or extra denominator condition
has entered the graph.

## Verdict boundary

Genuine source/coverage/root-path blockers: **none found**. All 23 INTERNAL
ports remain unproved, including both members of the two alternative route
records; reviewing both alternatives does not require proving both. The graph
accounts for first/square integrability, actual row/fourth-moment/frame
applicability, positivity/order/integral compatibility, actual noncommutative
centering, weighted order and both norm bridges without adding public premises.

No source assertion or proof ingredient is legalized as a caller hypothesis.
No actual provider signature/application, theorem proof, compiled parent or
material producer call has been checked. Own raw/type/R7/R8 originals and the
public SG inputs remain unchanged; unopened SG snapshots were not written.
No source VERIFIED, normal verification, proof, ledger/C/registry/Git mutation,
integration or permission is granted.
