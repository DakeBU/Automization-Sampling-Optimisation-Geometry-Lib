from pathlib import Path
import hashlib
import json
import subprocess

ROOT = Path.cwd()
WORK = ROOT / '.astis/huanjian-gc-fixed-spectrum-grid-alias-20261109'
def digest(data):
    return hashlib.sha256(data).hexdigest()
def ref(path):
    p = ROOT / path
    b = p.read_bytes()
    return {'path': str(path), 'sha256': digest(b), 'bytes': len(b)}

producer = '''theorem actual_midpoint_grid_cosine_alias {d : ℕ} (hd : 2 ≤ d) (k : ℤ) :
  let θ : Fin d → ℝ := fun i => ((i.val : ℝ) + 1 / 2) * Real.pi / (d : ℝ)
  (∑ i : Fin d, Real.cos ((k : ℝ) * θ i)) =
    (d : ℝ) * (if (2 * (d : ℤ)) ∣ k then
      (-1 : ℝ) ^ (k / (2 * (d : ℤ))) else 0)
'''
consumer = '''private theorem actual_weighted_inverse_grid_alias_series {d : ℕ} (hd : 2 ≤ d)
    {κ : ℝ} (hκ : 2 ≤ κ) (n : ℕ) (hn : 1 ≤ n) (hnd : n < d) :
  let θ : Fin d → ℝ := fun i => ((i.val : ℝ) + 1 / 2) * Real.pi / (d : ℝ)
  let eigenvalue : Fin d → ℝ := fun i => (κ + 1) / 2 + (κ - 1) / 2 * Real.cos (θ i)
  let r : ℝ := (Real.sqrt κ - 1) / (Real.sqrt κ + 1)
  let alias : ℤ → ℝ := fun k =>
    if (2 * (d : ℤ)) ∣ k then (-1 : ℝ) ^ (k / (2 * (d : ℤ))) else 0
  Summable (fun j : ℕ => (-r) ^ (j + 1) *
    (alias (((j + 1 : ℕ) : ℤ) - (n : ℤ)) +
      alias (((j + 1 : ℕ) : ℤ) + (n : ℤ)))) ∧
  (∑ i : Fin d, Real.cos ((n : ℝ) * θ i) / eigenvalue i) =
    ((d : ℝ) / Real.sqrt κ) * ∑' j : ℕ, (-r) ^ (j + 1) *
      (alias (((j + 1 : ℕ) : ℤ) - (n : ℤ)) +
        alias (((j + 1 : ℕ) : ℤ) + (n : ℤ)))
'''
WORK.joinpath('producer-signature.txt').write_text(producer)
WORK.joinpath('consumer-signature.txt').write_text(consumer)
def prop_definition(s, old, new):
    s = s.replace('private theorem ', 'def ', 1).replace('theorem ', 'def ', 1)
    s = s.replace(old, new, 1)
    return s.replace(' :\n', ' : Prop :=\n', 1)
formation = '''import AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumCosineExpansion
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Basic
open scoped BigOperators
-- Exact proposed signatures as Prop definitions only. No theorem proof or axiom.
''' + prop_definition(producer, 'actual_midpoint_grid_cosine_alias', 'SealedProducerType') + '\n' + prop_definition(consumer, 'actual_weighted_inverse_grid_alias_series', 'SealedConsumerType') + '\n#check SealedProducerType\n#check SealedConsumerType\n'
WORK.joinpath('ExactStatementFormation.lean').write_text(formation)
seal = {
 'schema_version': 1,
 'seal_id': 'GC-FIXED-SPECTRUM-GRID-ALIAS-20261109-v1',
 'state': 'EXACT_SIGNATURES_FIXED_TYPE_FORMATION_AND_INDEPENDENT_ADMISSION_PENDING_NO_TARGET_PROOF',
 'source': {
  'title':'On Complexity of Gaussian Sampling', 'version':'arXiv:2610.20492v1',
  'raw': ref('.astis/huanjian-resume-20261103/2610.20492v1.html'),
  'producer_anchors':['A3.SS3.p3','A3.Ex139'],
  'consumer_anchors':['A3.SS3.p4','A3.SS3.p6','A3.Ex144'],
  'standing_anchors':['S4.SS1.p1.1','S4.E11','S4.Thmtheorem5.p1.1'],
  'existing_raw_first_source_graph_manifest':ref('.astis/huanjian-gc-fixed-spectrum-moments-20261109/source-only-review/phase1/manifest.json'),
  'consumer_scope':'Only the deterministic weighted reciprocal-grid identity after product-to-sum and alias evaluation. The Gaussian expectation identification in p4 and closed tail resummation in p6 remain separate open dependencies.'
 },
 'producer': {
  'name':'AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumGridAlias.actual_midpoint_grid_cosine_alias',
  'planned_file':'AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumGridAlias.lean',
  'signature':producer, 'signature_sha256':digest(producer.encode()),
  'definition_kind':'literal',
  'outputs':['Exact midpoint cosine sum for every integer frequency, including zero and negative frequencies.'],
  'planned_public_ASTIS_parents':[]
 },
 'actual_private_consumer': {
  'name':'actual_weighted_inverse_grid_alias_series',
  'planned_file':'Tests/GaussianComplexityFixedSpectrumGridAlias.lean',
  'signature':consumer,'signature_sha256':digest(consumer.encode()),
  'definition_kind':'literal',
  'actual_use_required':'Apply C7 pointwise and absolute convergence at the literal grid, produce weighted summability and interchange the actual finite sum with the infinite series. Use product-to-sum and the NEW alias theorem at n, j+1-n and j+1+n. Prove the constant sum vanishes from 1<=n<d. Produce supported-series Summable as a conclusion. A wrapper, unused call or #check is not a consumer.',
  'expected_public_ASTIS_parents':[
   'AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumCosineExpansion.actual_inverse_spectrum_cosine_expansion',
   'AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumGridAlias.actual_midpoint_grid_cosine_alias'],
  'parent_status':'Expected design only; exact recursive compiled parent sets must be inspected after proof.'
 },
 'binder_audit':[
  {'binder':'producer d:Nat','class':'TYPING','reason':'Finite source dimension.'},
  {'binder':'producer hd:2<=d','class':'STANDING','reason':'Literal Section4.1 hard-family domain. No denominator-nonzero premise.'},
  {'binder':'producer k:Int','class':'SOURCE','reason':'A3.SS3.p3 explicitly states every integer k. No positivity/parity/divisibility input.'},
  {'binder':'consumer d:Nat,hd:2<=d','class':'STANDING','reason':'Same hard-family grid.'},
  {'binder':'consumer kappa:Real,hkappa:2<=kappa','class':'STANDING','reason':'Literal hard-family domain, not a radius/convergence premise.'},
  {'binder':'consumer n:Nat,hn:1<=n,hnd:n<d','class':'SOURCE','reason':'Positive integer frequency below d in Lemma4.5 and C8 weighted moment calculation. The source integer n is represented by Nat together with the exact positive range.'}
 ],
 'definition_audit':[
  {'object':'theta','kind':'literal','meaning':'Fin d index i corresponds to source index i+1; (i.val+1/2)*pi/d equals (source_i-1/2)*pi/d. Finite sum is over all d points.'},
  {'object':'alias coefficient','kind':'literal','meaning':'Real-valued piecewise coefficient. The true branch uses integer exponent (zpow) of -1 with integer quotient k/(2*d). With d>=2 the divisor is positive, and in the divisible branch this quotient is exactly the source integer a in k=2*a*d. Outside divisibility the coefficient is literally zero; quotient fallback has no mathematical effect.'},
  {'object':'negative/zero frequencies','kind':'literal','meaning':'All k:Int retained. k=0 has quotient0 and sum d. Negative aliases use negative integer powers of nonzero -1; no natural truncation or lost parity. Nonaliases remain zero.'},
  {'object':'eigenvalue,r','kind':'literal','meaning':'Exactly the source half-shifted cosine eigenvalue grid and principal-real-square-root radius. Positivity of denominators and 0<r<1 are produced internally, not binders.'},
  {'object':'positive-index series','kind':'literal','meaning':'j:Nat means source positive frequency j+1; j+1-n is formed in Int and may be negative. No Nat subtraction/truncation is permitted.'},
  {'object':'tsum and Summable','kind':'literal','meaning':'Standard real infinite sum. Actual supported series summability is produced in the conclusion, so the identity cannot gain meaning solely from a nonsummable default value.'},
  {'object':'weighted reciprocal-grid sum','kind':'literal','meaning':'Unnormalized sum of cos(n theta_i)/lambda_i. Gaussian expectation identification is not defined into the theorem, assumed as a binder or claimed proved.'}
 ],
 'EXCESS_binders':[],
 'internal_dependencies_not_premises':[
  'Nonzero dimension/divisor and integer quotient correctness in divisible branch',
  'Finite trigonometric sum and zero-denominator case split',
  'Cosine at integer multiples of pi, including negative integers',
  'C7 pointwise identity and absolute convergence',
  'Weighted series summability and actual finite-sum/tsum interchange',
  'Product-to-sum and zero low-frequency constant grid sum'],
 'shared_floor_audit':{
  'searched_before_seal':['ASTIS GaussianComplexity and TechnicalLemmas declaration-name inventory for cosine/alias/midpoint/Chebyshev/grid','Existing GC frontier/canonical source graph records','Mathlib filename inventory: Trigonometric, Fourier, RootsOfUnity, Chebyshev'],
  'result':'No identical ASTIS alias declaration found in the bounded name inventory. ChebyshevLobatto and Mathlib finite-trigonometric/orthogonality candidates remain to inspect after admission.',
  'classification':'provisional missing route-local interface, not yet an API-availability or uniqueness certificate',
  'decision':'Use an existing exact canonical theorem if post-admission search finds it. Never create a duplicate wrapper for Registry credit.',
  'meaningful_known_consumer':'The sealed actual private weighted alias series above; exact finite-grid trace and weighted closed moments are planned consumers, not existing Lean edges.'},
 'process_memory':{
  'registry':ref('research-wiki/process-memory.json'),
  'consulted_ids':['ASTIS-PM-QUADRATIC-TILT-MEASURE-ROLES','ASTIS-NK-GRADIENT-FLOW-ZERO-TIME','ASTIS-NK-GD-INVERSE-DOMAIN'],
  'applicability':'No exact negative/proof memory for midpoint alias. Keep deterministic sums distinct from Gaussian expectation laws; unrelated gradient-flow failures do not retire this route.'},
 'baseline':json.loads(WORK.joinpath('source-intake-baseline.json').read_text()),
 'roles':'Root sole mathematical worker. Independent source-only graph projection and a distinct topology/binder challenger must admit this exact seal before proof/API search.',
 'truth_boundary':'Statement seal only: no target theorem or consumer proved, no SAU/claim/ledger/frontier admission yet. Full C8 Gaussian means, closed alias resummations, variances and bias, Krylov, both main lower bounds, oracle/precision/TV/deterministic-cap/expected-cost adapters, local integration/remote delivery/purification and whole Goal remain open.'
}
WORK.joinpath('statement-seal-v1.json').write_text(json.dumps(seal,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'seal':ref(str(WORK.relative_to(ROOT)/'statement-seal-v1.json')),'formation':ref(str(WORK.relative_to(ROOT)/'ExactStatementFormation.lean'))},ensure_ascii=False))
