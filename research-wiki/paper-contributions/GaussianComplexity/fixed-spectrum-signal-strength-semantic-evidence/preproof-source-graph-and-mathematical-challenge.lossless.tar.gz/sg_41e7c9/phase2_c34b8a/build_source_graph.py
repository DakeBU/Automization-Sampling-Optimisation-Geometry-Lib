from pathlib import Path
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json

BASE=Path(__file__).resolve().parent
P1=BASE.parent
ROOT=P1.parents[2]
PROJECTION=ROOT/'.astis/huanjian-gc-fixed-spectrum-signal-strength-20261110/strict-preproof-seal-projection-v1.json'
sha=lambda b:hashlib.sha256(b).hexdigest()
def write(name,x):
    (BASE/name).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
pb=PROJECTION.read_bytes()
assert len(pb)==5842 and sha(pb)=='e8322849cd533289522de2de96ae5913364b1446dee114d4224956c1ced02fca'
assert sha((P1/'phase1_freeze.json').read_bytes())=='69372fb70615bbc7cc6ddc0fe9a6baa96177126d2eb67647882d19626ca67509'
projection=json.loads(pb)
(BASE/'sealed_projection.exact.json').write_bytes(pb)
for k in ['producer','actual_private_consumer']:
    assert sha(projection[k]['signature'].encode())==projection[k]['signature_sha256']
units=json.loads((P1/'raw_unit_inventory.json').read_text())
byid={x['id']:x for x in units if x['id']}
nodes=[]
edges=[]
def node(name,kind,anchors,statement,**extra):
    assert name not in {n['id'] for n in nodes}
    n=dict(id=name,kind=kind,source_anchors=anchors,statement=statement,
           evidence='raw-pinned-source-only',**extra)
    nodes.append(n)
    return name
def edge(name,parents,child,uses,reason,*,dependency=True,kind='AND-proof-input',conditions=None):
    edges.append(dict(id=name,parents=parents,child=child,logic='AND' if dependency else 'non-implicational',
        kind=kind,dependency=dependency,consumer_use_sites=uses,use=reason,
        conditional_discharge=conditions or []))

# Every mathematical part of the complete supplied source slice is retained,
# including context that does not belong to either selected root closure.
node('s:notation','definition',['S2.p1'],'Euclidean norm, identity, and symmetric Loewner order.')
node('s:haar','definition',['S2.p2'],'O(n), Haar probability, determinant components and conditional sign laws.')
node('s:target-oracle','definition',['S2.SS0.SSS0.Px1.p1'],'Centered target N(0,A inverse), spectral precision class, quadratic potential, exact first-order oracle.')
node('s:oracle-equivalence','unnamed-proof-step',['S2.SS0.SSS0.Px1.p2'],'Exact FO, gradient and matrix-vector reply simulation.')
node('s:algorithm-model','definition',['S2.SS0.SSS0.Px2.p1'],'Borel adaptive randomized algorithm, input-independent seed, arbitrary Borel output, deterministic per-run query cap.')
node('s:tv','definition-and-bound',['S2.SS0.SSS0.Px3.p1'],'TV definition and bounded measurable test inequality.')
node('s:qg','definition',['S2.SS0.SSS0.Px4.p1'],'Uniform-in-input seed-averaged output-law TV query complexity with deterministic cap.')
node('s:history','attribution',['S4.p1'],'[22] constant-accuracy kappa=2 lower bound and announced limitations.')
node('s:theorem41','source-theorem',['S4.Thmtheorem1'],'Fixed delta in (0,1), eventual d, 2<=kappa<=d^(1-delta), epsilon<=1/10: Q_G >=delta sqrt(kappa) log(d)/256.')
node('s:comparison31','comparison',['S4.p2'],'Parameter-range and known-spectrum comparison to Theorem3.1; no epsilon-dependent growth.')
node('s:grid','definition',['S4.E11','S4.SS1.p1.1'],'d>=2,kappa>=2; midpoint angles and affine cosine eigenvalues; Lambda=diagonal precision.')
node('s:random-family','definition',['S4.SS1.p1.2'],'Independent Haar O, A=O Lambda O transpose, quadratic potential and target.')
node('s:known-spectrum','scope-claim',['S4.SS1.p2'],'Spectrum and Gaussian normalizer may be known; eigenbasis is hidden.')
node('s:kappa2-comparison','source-remark',['S4.Thmtheorem2'],'Affine reply equivalence with kappa=2 and preview of the separating cosine signal.')
node('s:four-lemma-plan','proof-plan',['S4.SS2.p1'],'Krylov representation, uniform bound, target moments, admissibility; appendix deferrals.')
node('s:krylov-definition','definition',['S4.SS2.SSS0.Px1.p2'],'K_q=span{Lambda^j g_a : a<=q+1,0<=j<=q}.')
node('s:deferred-rotation-use','external-citation-use',['S4.SS2.SSS0.Px1.p1'],'[22,Lemma9.2] deferred rotation used for adaptive-output Krylov representation.')
node('s:krylov','source-lemma',['S4.Thmtheorem3'],'For q>=0 and 2q+1<d, independent Gaussian starts represent O transpose X in K_q almost surely.')
node('s:krylov-output-explanation','unnamed-proof-step',['S4.SS2.SSS0.Px1.p3'],'Extra starting vector for arbitrary output; coefficients can depend on full experiment; uniform control is needed.')
node('s:cosine-statistic','definition',['S4.SS2.SSS0.Px2.p1'],'n=2q+1 and D_n=diag(cos(n theta_i)); frequency above degree-q products.')
node('s:uniform-krylov','source-lemma',['S4.Thmtheorem4'],'Absolute C defines tau; if tau<=1/2, simultaneous |u transpose D_n u|<=2tau||u||² with probability .99.')
node('s:kappa-free-span','unnamed-proof-step',['S4.SS2.SSS0.Px2.p2'],'Nonconstant affine eigenvalue change identifies polynomial and cosine Krylov spans; bound independent of kappa.')
node('s:output-cosine-bound','unnamed-proof-step',['S4.SS2.SSS0.Px2.p3'],'Krylov membership and simultaneous event imply output quadratic bound.')
node('s:target-moment-introduction','scope-description',['S4.SS2.SSS0.Px3.p1'],'Same cosine statistic is evaluated under the target law.')
node('s:lemma45-means-variance','source-lemma-component',['S4.Thmtheorem5.p1'],'For actual U~N(0,Lambda inverse), exact M and signed mu_n formulas; both variances<=2M<=2d/sqrt(kappa).')
node('s:lemma45-bias','source-lemma-component',['S4.Thmtheorem5.p2'],'If d-n>=sqrt(kappa), (1-exp(-4))exp(-3n/sqrt(kappa))<=abs(mu_n)/M<=exp(-2n/sqrt(kappa)).')
node('s:target-rotation','unnamed-proof-step',['S4.SS2.SSS0.Px3.p2'],'O transpose transports Y|O~pi_A to diagonal U while preserving norm and cosine quadratic.')
node('s:admissibility-plan','proof-deferral',['S4.SS2.SSS0.Px4.p1'],'Hard-family admissibility proof deferred to C.4.')
node('s:admissibility','source-lemma',['S4.Thmtheorem6'],'I<=O Lambda O transpose<=kappa I for every orthogonal O.')
node('s:single-test-plan','proof-plan',['S4.SS3.p1'],'Compare one test event under outputs and target samples.')
node('s:source-proof-regime','proof-assumptions',['S4.SS3.p2'],'delta,kappa,epsilon regimes; assume uniformly successful q-query algorithm with q<=delta sqrt(kappa)log(d)/256.')
node('s:scalar-regime','literal-extracted-scalar-regime',['S4.SS3.p2'],'delta in (0,1); d natural eventually; 2<=kappa<=d^(1-delta); q natural with q<=delta sqrt(kappa)log(d)/256. These scalar bounds do not use epsilon or successful-algorithm existence.')
node('s:shifted-detector','definition',['S4.SS3.p3'],'S_A=(-1)^n Chebyshev cosine quadratic minus 2tau||x||²; E_A={S_A>0}.')
node('s:energy-weights','unnamed-proof-step',['S4.SS3.p4'],'For nonzero x, normalized eigenvector energies and Chebyshev identity interpret the detector.')
node('s:uniform-n','unnamed-uniform-estimate',['S4.SS3.SSS0.Px1.p1.1'],'Uniform scalar query bound implies n=o(d) (fixed delta only threshold).')
node('s:tau-asymptotic','unnamed-uniform-estimate',['S4.Ex20'],'tau<=constant[d^(-delta/2)(log d)^(3/2)+d^(-delta)(log d)^3] ->0.')
node('s:algorithm-test','unnamed-proof-step',['S4.SS3.SSS0.Px1.p1.2','S4.Ex21','S4.SS3.SSS0.Px1.p1.3','S4.Ex22'],'For sufficiently large d, n<d,tau<=1/2; law-preserving extension and uniform Krylov bound yield average algorithm event probability<=.01.')
node('s:moment-normalization','definition',['S4.SS3.SSS0.Px2.p1'],'M=tr(Lambda inverse), mu_n=tr(D_n Lambda inverse), beta=abs(mu_n)/M; no dimension divisor.')
node('s:distance-domain','unnamed-uniform-estimate',['S4.SS3.SSS0.Px2.p2.1'],'n=o(d), sqrt(kappa)<=d^((1-delta)/2)=o(d), hence d-n>=sqrt(kappa) uniformly eventually.')
node('s:beta-lower','unnamed-uniform-estimate',['S4.Ex23','S4.SS3.SSS0.Px2.p2.2'],'beta>=B d^(-delta/4), B=(1-exp(-4))exp(-3), using 3n/sqrt(kappa)<=3+(3delta/128)log d.')
node('s:M-lower','unnamed-uniform-estimate',['S4.SS3.SSS0.Px2.p2.2'],'rho^(2d)<=exp(-2)<1/3, so M>=d/(2sqrt(kappa))>=d^((1+delta)/2)/2.')
node('s:tau-beta','unnamed-uniform-estimate',['S4.Ex24'],'Left component: tau/beta <=Cprime/B*d^(-delta/4)(log d)^3 ->0.',source_component='left-hand estimate only')
node('s:signal-product','unnamed-uniform-estimate',['S4.Ex24'],'Right component: M beta² >= (B²/2)sqrt(d) ->infinity, uniformly.',source_component='right-hand estimate only')
node('s:common-source-threshold','unnamed-uniform-estimate',['S4.SS3.SSS0.Px2.p2.3'],'All estimates uniform; choose d0(delta) for previous domains,tau<=beta/4,M beta²>=320.')
node('s:shifted-target-test','unnamed-proof-step',['S4.SS3.SSS0.Px2.p3'],'For actual rotated target and shifted S_A: EZ>0, VarZ<=8M, Chebyshev yields pi_A(E_A)>=.9 (full Ex26).')
node('s:tv-contradiction','unnamed-proof-step',['S4.SS3.SSS0.Px3.p1'],'Uniform per-input TV and the two probability bounds yield .89<=epsilon<=.1.')
node('s:limitations-intro','scope-boundary',['S4.SS4.p1'],'Present theorem restricts kappa and has no increasing accuracy dependence.')
node('s:dimension-limitation-plan','unnamed-proof-step',['S4.SS4.SSS0.Px1.p1'],'Krylov enlargement has (q+1)² generators and distinct eigenvalues.')
node('s:dimension','source-lemma',['S4.Thmtheorem7'],'dim K_q=min(d,(q+1)²) almost surely.')
node('s:dimension-obstruction','unnamed-proof-step',['S4.SS4.SSS0.Px1.p2'],'Once K_q=R^d and n<d, sum cos²=d/2 gives a coordinate ratio>=1/sqrt(2), obstructing the stated <=1/2 uniform test.')
node('s:accuracy-obstruction','unnamed-proof-step',['S4.SS4.SSS0.Px2.p1'],'Threshold requires c/sqrt(d)<=a<abs(mu_n)/M<=exp(-2(2q+1)/sqrt(kappa)), hence q=O(sqrt(kappa)log d) independently of epsilon.')
node('s:limitation-scope','source-remark',['S4.Thmtheorem8'],'These are proof limitations; stronger fixed-spectrum lower bounds remain open.')

node('c:intro','proof-plan',['A3.SS3.p1'],'Inverse-spectrum cosine expansion, finite-grid sums, variance and normalized-bias bounds.')
node('c:c7','source-fact',['A3.Thmtheorem7'],'Inverse precision cosine expansion, absolute and uniform convergence for every real theta; standing kappa>=2.')
node('c:geometric','unnamed-proof-step',['A3.SS3.p2.1','A3.EGx14'],'Complex geometric-series calculation gives (1-rho²)/(1+2rho cos(theta)+rho²).')
node('c:rho-algebra','unnamed-proof-step',['A3.SS3.p2.2','A3.Ex136'],'Two algebraic rho/kappa identities identify the inverse spectrum.')
node('c:majorant','unnamed-proof-step',['A3.SS3.p2.3','A3.Ex137','A3.SS3.p2.4'],'Geometric absolute majorant rho/(1-rho) uniform in theta proves convergence.')
node('c:c8','source-fact',['A3.Thmtheorem8'],'Exact finite-grid M and signed mu_n formulas for 1<=n<d.')
node('c:grid-sum','unnamed-proof-step',['A3.SS3.p3'],'All integer cosine grid sums: d(-1)^a at k=2ad, zero otherwise; finite sine identity or direct evaluation.')
node('c:trace-means','unnamed-proof-step',['A3.SS3.p4'],'Gaussian second moments identify M and mu_n finite sums; absolute convergence allows finite-grid/series interchange.')
node('c:mean-M','unnamed-proof-step',['A3.SS3.p5'],'Only j=2ad survive for M; sum alternating geometric series to exact rational expression.')
node('c:mean-b','unnamed-proof-step',['A3.SS3.p6'],'Product-to-sum; three disjoint surviving frequency classes j=n,2ad+n,2ad-n; sign and geometric summation give exact mu_n.')
node('c:means-invoke','unnamed-proof-step',['A3.SS3.p7'],'Fact C.8 supplies both means in Lemma4.5.')
node('c:variance','unnamed-proof-step',['A3.SS3.p8'],'Independent diagonal Gaussian coordinates, fourth moments and lambda>=1 give both variances<=2M and exact M<=d/sqrt(kappa).')
node('c:ratio','unnamed-proof-step',['A3.SS3.p9'],'n<d and 0<rho<1 imply positive signed mu_n and ratio rho^n(1-rho^(2(d-n)))/(1-rho^(2d)); fraction bounds.')
node('c:log-powers','unnamed-proof-step',['A3.SS3.p10'],'Logarithm integral identity and kappa>=2 give 2/sqrt(kappa)<=log(1/rho)<3/sqrt(kappa); exponential bounds on rho^n.')
node('c:bias-upper','source-derived-component',['A3.Ex150','A3.Ex151','A3.Ex157'],'The upper normalized bias <=exp(-2n/sqrt(kappa)) already follows for 1<=n<d without the extra d-n>=sqrt(kappa) condition needed by the lower bias.')
node('c:bias','unnamed-proof-step',['A3.SS3.p11'],'If d-n>=sqrt(kappa), rho^(2(d-n))<=exp(-4); combine ratio and rho^n bounds for normalized bias.')
node('ext:22','external-citation',['bib.bib3'],'OpenAI2026, Subpolynomial query complexity for well-conditioned log-concave sampling; bibliographic entry only, original work not consulted.',consultation='NOT_CONSULTED')

# Honest named gaps in a source proof graph are not assertions that the paper is
# invalid. They identify omitted standard ingredients or consultation boundaries.
gaps=[
 ('gap:gaussian-semantics',['S4.Thmtheorem5.p1','A3.SS3.p4','A3.SS3.p8'],'Actual inverse-positive-diagonal-precision Gaussian is a probability law; coordinates independent; covariance/second/fourth moments and polynomial integrability. Standard input stated/used without a proof in the consulted slice.'),
 ('gap:geometric-series',['A3.SS3.p2.1','A3.SS3.p5','A3.SS3.p6'],'Complex geometric-series convergence and sum, Euler/cosine identities, geometric majorant criterion. Standard inputs used without local foundational proofs.'),
 ('gap:trigonometry',['A3.SS3.p3','A3.SS3.p6'],'Finite cosine summation, cosine product-to-sum and integer sine/cosine identities used in grid proof.'),
 ('gap:log-calculus',['A3.SS3.p10'],'Integral/log identity, integral evaluation and monotonicity, logarithm/exponential algebra. Used without foundational proofs in source.'),
 ('gap:power-asymptotics',['S4.SS3.SSS0.Px1.p1.1','S4.SS3.SSS0.Px2.p2'],'Positive-base real power identities and log/power domination yielding fixed-delta uniform eventual thresholds.'),
 ('gap:chebyshev',['S4.SS3.SSS0.Px2.p3'],'Variance-to-probability Chebyshev inequality and L2 triangle inequality used without local proofs.'),
 ('gap:chebyshev-polynomial',['S4.SS3.p4'],'Chebyshev polynomial identity T_n(cos(theta))=cos(n theta) and diagonal orthogonal matrix polynomial functional calculus, used without foundational proof in the consulted slice.'),
 ('gap:C1',['S4.Thmtheorem3','S4.SS2.SSS0.Px1.p3'],'C.1 proof and exact cited [22,Lemma9.2] not consulted; do not fabricate internal premises.'),
 ('gap:C2',['S4.Thmtheorem4','S4.SS2.SSS0.Px2.p2'],'C.2 uniform concentration proof not consulted.'),
 ('gap:C4',['S4.Thmtheorem6','S4.SS2.SSS0.Px4.p1'],'C.4 admissibility proof not consulted; elementary spectral premise is separately visible in C.3.'),
 ('gap:dimension-proof',['S4.Thmtheorem7'],'Dimension lemma proof not in consulted C.3 slice and not independently reconstructed here.'),
 ('gap:C6',['S4.SS4.SSS0.Px2.p1'],'Fact C.6 Bernstein threshold-floor calculation is referenced but not consulted.'),
 ('gap:theorem31',['S4.p2'],'Comparison theorem statement body not consulted; no proof dependency inferred.')]
for name,anchors,statement in gaps:
    node(name,'SOURCE_GAP',anchors,statement,gap_class='omitted-standard-input' if name in {'gap:gaussian-semantics','gap:geometric-series','gap:trigonometry','gap:log-calculus','gap:power-asymptotics','gap:chebyshev','gap:chebyshev-polynomial'} else 'consultation-limit',
         formal_discharge='NOT_AUDITED_NO_IMPLEMENTATION_EXPOSURE',source_invalidity_claim=False)

node('a:literal-law','literal-definition-adapter',['S4.E11','S4.Thmtheorem5.p1','A3.SS3.p4'],'Fin d grid reindexes i_source=i.val+1; covariance is Lambda inverse; Q is diagonal cosine quadratic; actual Bochner means equal source M,mu_n on internally proved positive spectral domain.')
node('a:domain','source-estimate-domain-discharge',['S4.SS3.SSS0.Px2.p2.1'],'Fixed-delta-only threshold ensures d>=2, log d>=0, n=2q+1>=1 and n+sqrt(kappa)<=d uniformly in kappa,q.')
node('a:positive-M-beta','source-algebraic-discharge',['A3.SS3.p9','S4.SS3.SSS0.Px2.p2.2'],'M>0 and beta>0 from d>=2,kappa>=2,0<rho<1,n<d and exact means; beta=abs(actual b)/M.')
node('root:public-signal','bounded-source-anchor',['S4.SS3.SSS0.Px2.p2.2','S4.Ex24'],'Exact sealed public actual-law numeric conclusion: positive M,beta; M>=d/(2sqrt(kappa)); M>=d^((1+delta)/2)/2; M beta² >=(B²/2)sqrt(d).',
     exact_signature_sha256=projection['producer']['signature_sha256'],exact_name=projection['producer']['name'],scope='Source unnamed M lower and signal estimates only; no event or detector conclusion.')
node('a:private-threshold','private-derived-domain-discharge',['S4.Ex24'],'B>0 and signal lower bound allow a delta-only enlargement with M beta²>=20 for all permitted kappa,q.')
node('a:private-chebyshev','private-derived-application',['A3.SS3.p8','A3.SS3.p9','S4.SS3.SSS0.Px2.p3'],'For Z=(-1)^n Q under the actual diagonal Gaussian, EZ=abs(b)=beta M>0 and VarZ<=2M, so P[Z<=0]<=2/(M beta²).',is_source_theorem=False)
node('root:private-zero-event','private-non-Anchor-adaptation',['A3.SS3.p8','A3.SS3.p9','S4.Ex24'],'Exact sealed private actual-law zero-threshold event has probability<=1/10; not the shifted detector, rotated-law theorem, or Ex26.',
     exact_signature_sha256=projection['actual_private_consumer']['signature_sha256'],exact_name=projection['actual_private_consumer']['name'],is_source_anchor=False,registry_node=False)

edge('e:oracle',['s:target-oracle'],'s:oracle-equivalence',['S2.SS0.SSS0.Px1.p2'],'Extract gradient or compute value from matrix-vector reply.')
edge('e:qg',['s:target-oracle','s:algorithm-model','s:tv'],'s:qg',['S2.SS0.SSS0.Px4.p1'],'Interpret admissible class, output law, caps and uniform accuracy.')
edge('e:grid-attribution',['ext:22'],'s:grid',['S4.SS1.p1.1'],'Similar construction credited to [22,9.2], not a necessary unproved definition theorem.',dependency=False,kind='attribution')
edge('e:history',['ext:22'],'s:history',['S4.p1'],'Historical constant-accuracy lower bound attribution.',dependency=False,kind='attribution')
edge('e:random-family',['s:grid','s:haar','s:target-oracle'],'s:random-family',['S4.SS1.p1.2'],'Build source random rotated target.')
edge('e:comparison31',['gap:theorem31'],'s:comparison31',['S4.p2'],'Source comparison only.',dependency=False,kind='comparison')
edge('e:kappa2',['s:grid','s:random-family'],'s:kappa2-comparison',['S4.Thmtheorem2.p1'],'Affine reply relation and signal preview; lemmas4.4/4.5 previews are not a new proof route.')
edge('e:kappa2-preview',['s:uniform-krylov','s:lemma45-bias'],'s:kappa2-comparison',['S4.Thmtheorem2.p1'],'Remark explicitly uses lemmas4.4 and4.5 for its output/target signal comparison; this is exposition of their consequences, not a separate proof of them.')
edge('e:deferred',['ext:22','gap:C1'],'s:deferred-rotation-use',['S4.SS2.SSS0.Px1.p1'],'Exact external input not checked.')
edge('e:krylov',['s:algorithm-model','s:random-family','s:krylov-definition','s:deferred-rotation-use'],'s:krylov',['S4.Thmtheorem3','S4.SS2.SSS0.Px1.p3'],'Source Krylov representation, conditioned on q natural and 2q+1<d.',conditions=['2q+1<d: source lemma premise; discharged in theorem41 by s:uniform-n and s:algorithm-test.'])
edge('e:krylov-explanation',['s:krylov','s:krylov-definition'],'s:krylov-output-explanation',['S4.SS2.SSS0.Px1.p3'],'Equivalent polynomial-output description and need for simultaneous control.')
edge('e:cosine-definition',['s:grid'],'s:cosine-statistic',['S4.SS2.SSS0.Px2.p1'],'Use midpoint angles in the high-frequency diagonal statistic.')
edge('e:uniform-krylov',['s:krylov-definition','s:cosine-statistic','gap:C2'],'s:uniform-krylov',['S4.Thmtheorem4'],'Uniform concentration statement; proof not consulted.',conditions=['2q+1<d and tau<=1/2: source premises; discharged for theorem41 by s:uniform-n/s:tau-asymptotic.'])
edge('e:span',['s:grid','s:krylov-definition'],'s:kappa-free-span',['S4.SS2.SSS0.Px2.p2'],'Nonconstant affine eigenvalue relation changes polynomial basis.')
edge('e:output',['s:krylov','s:uniform-krylov'],'s:output-cosine-bound',['S4.SS2.SSS0.Px2.p3'],'Simultaneous estimate applies to random adaptive output without conditioning on coefficients.')

edge('e:rho-algebra',['s:grid'],'c:rho-algebra',['A3.SS3.p2.2','A3.Ex136'],'rho=(sqrt(kappa)-1)/(sqrt(kappa)+1); kappa>=2 implies all denominators positive.')
edge('e:geometric',['c:rho-algebra','gap:geometric-series'],'c:geometric',['A3.SS3.p2.1','A3.EGx14'],'0<rho<1 permits both complex geometric series.')
edge('e:majorant',['c:rho-algebra','gap:geometric-series'],'c:majorant',['A3.Ex137','A3.SS3.p2.4'],'Uniform geometric majorant for every real theta.')
edge('e:c7',['c:geometric','c:rho-algebra','c:majorant'],'c:c7',['A3.SS3.p2.3','A3.SS3.p2.4'],'Combine rational identities and convergence.')
edge('e:grid-sum',['s:grid','gap:trigonometry'],'c:grid-sum',['A3.SS3.p3'],'Separate k in 2dZ from nonmultiples; denominator nonzero in latter case.')
edge('e:literal-law',['s:grid','s:target-oracle','s:cosine-statistic','s:moment-normalization','gap:gaussian-semantics'],'a:literal-law',['S4.Thmtheorem5.p1','A3.SS3.p4','S4.SS3.SSS0.Px2.p1'],'Positive eigenvalues give actual inverse-precision covariance and Gaussian moment meaning; literal cosine/normalization definitions; integral finiteness is an internal obligation, not a binder.')
edge('e:trace',['a:literal-law','c:c7'],'c:trace-means',['A3.SS3.p4'],'Actual second moments identify finite sums; absolute convergence permits interchange.')
edge('e:mean-M',['c:trace-means','c:grid-sum','gap:geometric-series'],'c:mean-M',['A3.SS3.p5','A3.EGx15'],'Filter j=2ad then sum alternating geometric series.')
edge('e:mean-b',['c:trace-means','c:grid-sum','gap:geometric-series','gap:trigonometry'],'c:mean-b',['A3.SS3.p6','A3.Ex144','A3.EGx16'],'Product-to-sum and three disjoint frequency classes; n integer with 1<=n<d.',conditions=['1<=n<d: discharged for selected roots by a:domain; source FactC.8 retains it explicitly.'])
edge('e:c8',['c:mean-M','c:mean-b'],'c:c8',['A3.Thmtheorem8','A3.SS3.p6'],'Both exact means are required; this is AND, not an OR proof.')
edge('e:means',['c:c8'],'c:means-invoke',['A3.SS3.p7'],'FactC.8 supplies both Lemma4.5 means.')
edge('e:variance',['a:literal-law','c:mean-M','s:grid','gap:gaussian-semantics'],'c:variance',['A3.SS3.p8','A3.EGx17'],'Independence and fourth moments; lambda>=1 and cos²<=1; M formula bounds M.')
edge('e:lemma45-mv',['c:means-invoke','c:variance'],'s:lemma45-means-variance',['A3.SS3.p7','A3.SS3.p8'],'Source Lemma4.5 unconditional means/variance component.')
edge('e:ratio',['c:c8','c:rho-algebra'],'c:ratio',['A3.SS3.p9','A3.Ex150','A3.Ex151'],'n<d gives rho^n>rho^(2d-n); positive denominator permits division.',conditions=['M>0,0<rho<1,n<d: proved from exact formulas and regime; no free positivity premise.'])
edge('e:log-powers',['c:rho-algebra','gap:log-calculus'],'c:log-powers',['A3.SS3.p10','A3.EGx18','A3.EGx19','A3.Ex157'],'kappa>=2 and positive integration denominator; exponentiate logarithmic bounds.')
edge('e:bias-upper',['c:ratio','c:log-powers'],'c:bias-upper',['A3.Ex150','A3.Ex151','A3.Ex157'],'Ratio correction<=1 and rho^n<=exp(-2n/sqrt(kappa)); no distance-to-edge premise is used for this component.',conditions=['1<=n<d and kappa>=2 retained; selected roots discharge them through a:domain/source regime.'])
edge('e:bias',['c:ratio','c:log-powers'],'c:bias',['A3.SS3.p11','A3.Ex158','A3.Ex159'],'Distance-to-grid-edge controls correction factor by 1-exp(-4).',conditions=['d-n>=sqrt(kappa): source conditional premise; discharged for selected roots by s:distance-domain/a:domain.'])
edge('e:lemma45-bias',['c:bias'],'s:lemma45-bias',['A3.SS3.p11','S4.Thmtheorem5.p2'],'Source conditional bias conclusion.')
edge('e:rotation',['s:random-family','a:literal-law'],'s:target-rotation',['S4.SS2.SSS0.Px3.p2'],'Orthogonal change of variables; same diagonal law and quadratic/norm values.')
edge('e:admissible',['s:random-family','gap:C4'],'s:admissibility',['S4.Thmtheorem6','S4.SS2.SSS0.Px4.p1'],'C.4 is the stated deferred proof, not consulted.')

edge('e:n',['s:scalar-regime','gap:power-asymptotics'],'s:uniform-n',['S4.SS3.SSS0.Px1.p1.1'],'q cap and sqrt(kappa)<=d^((1-delta)/2) bound n uniformly.')
edge('e:distance',['s:uniform-n','s:scalar-regime','gap:power-asymptotics'],'s:distance-domain',['S4.SS3.SSS0.Px2.p2.1'],'Both n and sqrt(kappa) are uniformly o(d).')
edge('e:domain',['s:distance-domain','s:scalar-regime','gap:power-asymptotics'],'a:domain',['S4.SS3.SSS0.Px2.p2.1'],'Enlarge one delta-only threshold for d>=2 and positive-domain/log/integer requirements.')
edge('e:tau',['s:scalar-regime','s:uniform-n','s:uniform-krylov','gap:power-asymptotics'],'s:tau-asymptotic',['S4.Ex20'],'Substitute q bound into tau definition; only absolute constants.')
edge('e:energy-identity',['s:random-family','s:cosine-statistic','s:shifted-detector','gap:chebyshev-polynomial'],'s:energy-weights',['S4.SS3.p4'],'Identify the detector matrix with O D_n O transpose and interpret the normalized energy weights for x!=0.')
edge('e:algorithm-test',['s:uniform-n','s:tau-asymptotic','s:krylov','s:uniform-krylov','s:shifted-detector','s:energy-weights'],'s:algorithm-test',['S4.SS3.SSS0.Px1.p1.2','S4.Ex21','S4.Ex22'],'Discharge n<d,tau<=1/2; preserve joint law, apply simultaneous bound and average probability.')
edge('e:beta-lower',['a:domain','s:lemma45-bias','s:scalar-regime'],'s:beta-lower',['S4.Ex23','S4.SS3.SSS0.Px2.p2.2'],'3n/sqrt(kappa)<=3+(3delta/128)log d<=3+(delta/4)log d; B d^(-delta/4).',conditions=['kappa>=2,d-n>=sqrt(kappa),d>=2,delta>0: source regime and a:domain.'])
edge('e:M-lower',['a:domain','c:mean-M','c:log-powers','s:scalar-regime'],'s:M-lower',['S4.SS3.SSS0.Px2.p2.2'],'rho^(2d)<=exp(-2)<1/3, so (1-r)/(1+r)>=1/2; kappa bound yields dimension-power lower.',conditions=['d>=sqrt(kappa): follows from n+sqrt(kappa)<=d; sqrt(kappa)>0; real-power identities valid at d>0.'])
edge('e:positive',['a:domain','a:literal-law','c:c8','c:ratio'],'a:positive-M-beta',['A3.SS3.p9','S4.SS3.SSS0.Px2.p2.2'],'Exact M positive and signed b positive; literal beta=abs(b)/M positive.')
edge('e:signal',['s:M-lower','s:beta-lower','a:positive-M-beta','gap:power-asymptotics'],'s:signal-product',['S4.Ex24'],'Square nonnegative beta lower and multiply positive M lower; exponents cancel to d^(1/2).')
edge('e:tau-beta',['s:tau-asymptotic','s:beta-lower','a:positive-M-beta','gap:power-asymptotics'],'s:tau-beta',['S4.Ex24'],'Left-hand tau/beta component uses tau; it is not required by right-hand signal component.')
edge('e:common-threshold',['s:tau-beta','s:signal-product','a:domain','gap:power-asymptotics'],'s:common-source-threshold',['S4.SS3.SSS0.Px2.p2.3'],'Uniform estimates give one delta-only threshold for tau<=beta/4 and signal>=320.')
edge('e:shifted-target',['s:target-rotation','s:lemma45-means-variance','c:ratio','s:common-source-threshold','s:shifted-detector','s:energy-weights','gap:chebyshev'],'s:shifted-target-test',['S4.SS3.SSS0.Px2.p3','S4.Ex25','S4.Ex26'],'Signed cosine mean and L2 variance triangle, then Chebyshev: original rotated shifted detector.')
edge('e:contradiction',['s:algorithm-test','s:shifted-target-test','s:tv','s:admissibility','s:source-proof-regime'],'s:tv-contradiction',['S4.SS3.SSS0.Px3.p1','S4.Ex27'],'Both probability branches and per-input TV; average only after fixed-input bound.')
edge('e:theorem41',['s:tv-contradiction','s:qg'],'s:theorem41',['S4.SS3.SSS0.Px3.p1'],'Contradiction forbids the assumed low-query successful algorithm.')
edge('e:dimension',['s:krylov-definition','s:grid','gap:dimension-proof'],'s:dimension',['S4.Thmtheorem7'],'Distinct eigenvalues and Gaussian starts; detailed proof not in consulted slice.')
edge('e:dimension-obstruction',['s:dimension','s:cosine-statistic','gap:trigonometry'],'s:dimension-obstruction',['S4.SS4.SSS0.Px1.p2'],'Condition (q+1)²>=d and n<d makes a coordinate witness obstruct uniform smallness.')
edge('e:accuracy-obstruction',['s:uniform-krylov','c:bias-upper','gap:C6','gap:log-calculus'],'s:accuracy-obstruction',['S4.SS4.SSS0.Px2.p1'],'Threshold constraints plus certified concentration floor and target bias upper bound; exact conditions of FactC.6 remain consultation gap. The unshifted upper-bias proof only needs 1<=n<d, a retained domain of this proof method.')

edge('e:public-root',['a:literal-law','a:domain','a:positive-M-beta','s:M-lower','s:signal-product'],'root:public-signal',['S4.SS3.SSS0.Px2.p2.2','S4.Ex24'],'Conjoin exactly the sealed five actual-law numeric conclusions; definitions are literal; d0 chosen before kappa/q.')
edge('e:private-threshold',['root:public-signal','gap:power-asymptotics'],'a:private-threshold',['S4.Ex24'],'B>0 and sqrt(d) growth give delta-only enlarged threshold with signal>=20.')
edge('e:private-chebyshev',['a:literal-law','a:positive-M-beta','c:ratio','c:variance','gap:chebyshev'],'a:private-chebyshev',['A3.SS3.p8','A3.SS3.p9','S4.SS3.SSS0.Px2.p3'],'Use signed Q itself, with EZ=beta M and Var<=2M; source probability method adapted, not full Ex26.',kind='AND-private-adaptation')
edge('e:private-root',['a:private-threshold','a:private-chebyshev'],'root:private-zero-event',['S4.Ex24','A3.SS3.p8','A3.SS3.p9'],'2/(M beta²)<=1/10; continuous signed Q gives measurable event, Gaussian total mass one makes toReal ordinary probability.',kind='AND-private-adaptation')

# Raw-unit dispositions are source-derived and independent of target closure.
# A parent container may duplicate multiple mathematical nodes; it is excluded
# only as a duplicate wrapper, never as missing mathematical coverage.
region_map={
 'S2.p1':['s:notation'],'S2.p2':['s:haar'],
 'S2.SS0.SSS0.Px1.p1':['s:target-oracle'],'S2.SS0.SSS0.Px1.p2':['s:oracle-equivalence'],
 'S2.SS0.SSS0.Px2.p1':['s:algorithm-model'],'S2.SS0.SSS0.Px3.p1':['s:tv'],'S2.SS0.SSS0.Px4.p1':['s:qg'],
 'S4.p1':['s:history'],'S4.Thmtheorem1':['s:theorem41'],'S4.p2':['s:comparison31'],
 'S4.E11':['s:grid'],'S4.SS1.p1.1':['s:grid'],'S4.SS1.p1.2':['s:random-family'],'S4.SS1.p2':['s:known-spectrum'],
 'S4.Thmtheorem2':['s:kappa2-comparison'],'S4.SS2.p1':['s:four-lemma-plan'],
 'S4.SS2.SSS0.Px1.p1':['s:deferred-rotation-use'],'S4.SS2.SSS0.Px1.p2':['s:krylov-definition'],
 'S4.Thmtheorem3':['s:krylov'],'S4.SS2.SSS0.Px1.p3':['s:krylov-output-explanation'],
 'S4.SS2.SSS0.Px2.p1':['s:cosine-statistic'],'S4.Thmtheorem4':['s:uniform-krylov'],
 'S4.SS2.SSS0.Px2.p2':['s:kappa-free-span'],'S4.SS2.SSS0.Px2.p3':['s:output-cosine-bound'],
 'S4.SS2.SSS0.Px3.p1':['s:target-moment-introduction'],
 'S4.Thmtheorem5':['s:lemma45-means-variance','s:lemma45-bias'],'S4.Thmtheorem5.p1':['s:lemma45-means-variance'],
 'S4.Thmtheorem5.p2':['s:lemma45-bias'],'S4.SS2.SSS0.Px3.p2':['s:target-rotation'],
 'S4.SS2.SSS0.Px4.p1':['s:admissibility-plan'],'S4.Thmtheorem6':['s:admissibility'],
 'S4.SS3.p1':['s:single-test-plan'],'S4.SS3.p2':['s:source-proof-regime','s:scalar-regime'],
 'S4.SS3.p3':['s:shifted-detector'],'S4.SS3.p4':['s:energy-weights'],
 'S4.SS3.SSS0.Px1.p1.1':['s:uniform-n'],'S4.Ex20':['s:tau-asymptotic'],
 'S4.SS3.SSS0.Px1.p1.2':['s:algorithm-test'],'S4.Ex21':['s:algorithm-test'],
 'S4.SS3.SSS0.Px1.p1.3':['s:algorithm-test'],'S4.Ex22':['s:algorithm-test'],
 'S4.SS3.SSS0.Px2.p1':['s:moment-normalization'],
 'S4.SS3.SSS0.Px2.p2.1':['s:distance-domain'],'S4.Ex23':['s:beta-lower'],
 'S4.SS3.SSS0.Px2.p2.2':['s:beta-lower','s:M-lower'],
 'S4.Ex24':['s:tau-beta','s:signal-product'],
 'S4.SS3.SSS0.Px2.p2.3':['s:common-source-threshold'],
 'S4.SS3.SSS0.Px2.p3':['s:shifted-target-test'],'S4.SS3.SSS0.Px3.p1':['s:tv-contradiction'],
 'S4.SS4.p1':['s:limitations-intro'],'S4.SS4.SSS0.Px1.p1':['s:dimension-limitation-plan'],
 'S4.Thmtheorem7':['s:dimension'],'S4.SS4.SSS0.Px1.p2':['s:dimension-obstruction'],
 'S4.SS4.SSS0.Px2.p1':['s:accuracy-obstruction'],'S4.Thmtheorem8':['s:limitation-scope'],
 'A3.SS3.p1':['c:intro'],'A3.Thmtheorem7':['c:c7'],
 'A3.SS3.p2.1':['c:geometric'],'A3.EGx14':['c:geometric'],
 'A3.SS3.p2.2':['c:rho-algebra'],'A3.Ex136':['c:rho-algebra'],
 'A3.SS3.p2.3':['c:majorant'],'A3.Ex137':['c:majorant'],'A3.SS3.p2.4':['c:majorant'],
 'A3.Thmtheorem8':['c:c8'],'A3.SS3.p3':['c:grid-sum'],'A3.SS3.p4':['c:trace-means'],
 'A3.SS3.p5':['c:mean-M'],'A3.SS3.p6':['c:mean-b'],'A3.SS3.p7':['c:means-invoke'],
 'A3.SS3.p8':['c:variance'],'A3.SS3.p9':['c:ratio'],'A3.SS3.p10':['c:log-powers'],
 'A3.SS3.p11':['c:bias'],'bib.bib3':['ext:22']}
regions=[]
for k,v in region_map.items():
    x=byid[k]
    regions.append((x['start_byte'],x['end_byte'],v,k))
dispositions=[]
for x in units:
    contained=[r for r in regions if r[0]<=x['start_byte'] and x['end_byte']<=r[1]]
    if contained:
        chosen=min(contained,key=lambda r:r[1]-r[0])
        ds=dict(unit=x['unit'],source_id=x['id'],raw_sha256=x['raw_sha256'],disposition='NODE',
            node_ids=chosen[2],mapping_region=chosen[3],
            reason='Exact raw unit lies in the identified substantive source statement/proof/definition/citation region; nested labels/math are preserved.',
            root_membership=[])
    else:
        subregions=[r for r in regions if x['start_byte']<=r[0] and r[1]<=x['end_byte']]
        in_heading=any('heading' in h['kinds'] and h['start_byte']<=x['start_byte'] and x['end_byte']<=h['end_byte'] for h in units)
        if in_heading or 'heading' in x['kinds'] or x['id']=='S4.Thmtheorem5.2' or ('ltx_tag' in x['classes'] and not any(k in x['kinds'] for k in ['math','paragraph','equation'])):
            reason='Structural section/paragraph/theorem heading only; exact title/label retained in raw inventory and source node metadata; no mathematical claim deleted.'
        elif subregions:
            reason='Duplicate enclosing source/proof/paragraph container; substantive contained regions are individually NODE-mapped. Its exact raw bytes remain preserved.'
        elif x['text'].strip() in {'','∎','Proof.','Proof of Lemma 4.5 .'}:
            reason='Proof delimiter only; mathematical proof regions are separately NODE-mapped.'
        elif 'cross-reference-or-link' in x['kinds']:
            reason='Cross-reference in a structural proof-title heading; destination theorem/fact is represented by its source node. This reference alone does not add a proof premise.'
        else:
            raise AssertionError(('Unclassified substantive raw unit',x['unit'],x['id'],x['text']))
        ds=dict(unit=x['unit'],source_id=x['id'],raw_sha256=x['raw_sha256'],disposition='EXCLUDED',reason=reason,
            contained_node_ids=sorted({n for r in subregions for n in r[2]}))
    dispositions.append(ds)

nodeids={n['id'] for n in nodes}
assert all(set(e['parents']+[e['child']])<=nodeids for e in edges)
assert len({e['id'] for e in edges})==len(edges)
def closure(root):
    seen=set()
    selected=set()
    todo=[root]
    while todo:
        n=todo.pop()
        if n in seen: continue
        seen.add(n)
        for e in edges:
            if e['dependency'] and e['child']==n:
                selected.add(e['id'])
                todo.extend(e['parents'])
    leafs=sorted(n for n in seen if not any(e['dependency'] and e['child']==n for e in edges))
    gaps=sorted(n for n in seen if n.startswith('gap:'))
    return dict(root=root,node_ids=sorted(seen),edge_ids=sorted(selected),leaf_ids=leafs,source_gap_ids=gaps,
       outside_closure=[dict(node_id=n['id'],reason='Source context or a different downstream branch; no dependency path into this exact root. Its raw units remain covered.') for n in nodes if n['id'] not in seen],
       closure_semantics='Backward closure follows only dependency=true AND proof/definition/adaptation hyperedges. Attribution/comparison and shared source-position alone do not create dependencies.',
       formal_closure_status='NOT_CLAIMED; implementation/API not inspected',independent_coverage_approval='REQUIRED_DISTINCT_REVIEWER')
closures=[closure('root:public-signal'),closure('root:private-zero-event')]
for ds in dispositions:
    if ds['disposition']=='NODE':
        ds['root_membership']=[c['root'] for c in closures if set(ds['node_ids'])&set(c['node_ids'])]

graph=dict(schema='independent-source-proof-graph-v1',original_source_sha256='6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915',
    phase1_freeze_sha256='69372fb70615bbc7cc6ddc0fe9a6baa96177126d2eb67647882d19626ca67509',sealed_projection_sha256=sha(pb),
    exact_roots=['root:public-signal','root:private-zero-event'],nodes=nodes,hyperedges=edges,
    alternative_routes=[],alternative_route_judgment='The supplied source slice develops one cosine-expansion route. Separate M and mu_n branches are AND prerequisites, and algorithm/target branches are AND prerequisites of theorem41. No false AND across implementation alternatives is introduced.',
    important_separation='Source topology is not Lean dependency. Private zero-event adaptation is explicitly not source Ex26 or the shifted detector. Full source contexts are retained without promoting them into selected-root premises.')
coverage=dict(schema='exhaustive-source-unit-dispositions-v1',inventory_path='../raw_unit_inventory.json',inventory_sha256=sha((P1/'raw_unit_inventory.json').read_bytes()),
    total_units=len(units),disposition_counts=dict(Counter(x['disposition'] for x in dispositions)),units=dispositions,
    exhaustive_raw_disposition_check='Every one of 809 immutable raw units has exactly one NODE or reasoned EXCLUDED disposition; all raw source bytes, labels and formulas remain in phase1 inventory/slices.',
    mathematical_coverage_judgment='EXTRACTOR_PROPOSAL_ONLY; not independently approved',root_scope_is_not_evidence=True,
    root_membership_semantics='For a raw unit with several mapped components, root_membership means at least one component is in the closure; it does not promote the other components into dependencies.',
    independent_review_required='A distinct reviewer must re-read raw source plus node/edge records without implementation Lean or this extractor private rationale, and audit all root closures.')
write('source_graph.json',graph)
write('source_unit_dispositions.json',coverage)
write('root_closures.json',dict(roots=closures))
print(json.dumps(dict(nodes=len(nodes),hyperedges=len(edges),raw_units=len(units),dispositions=coverage['disposition_counts'],closures=[dict(root=c['root'],nodes=len(c['node_ids']),edges=len(c['edge_ids']),gaps=c['source_gap_ids']) for c in closures]),indent=2))
