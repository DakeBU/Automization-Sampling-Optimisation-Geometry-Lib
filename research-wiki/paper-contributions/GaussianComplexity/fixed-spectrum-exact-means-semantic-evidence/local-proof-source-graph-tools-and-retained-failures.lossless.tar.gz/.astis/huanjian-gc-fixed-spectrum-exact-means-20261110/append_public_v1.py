from pathlib import Path
import gzip
w=Path('.astis/huanjian-gc-fixed-spectrum-exact-means-20261110')
p=Path('AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumExactMeans.lean')
gzip.open(w/'retained-complete-tail-providers-v3.lean.gz','wb').write(p.read_bytes())
s=p.read_text(); end='end AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumExactMeans'
s=s.removesuffix('\n').removesuffix(end)
s+= '\n'+(w/'producer-signature.txt').read_text().rstrip()+' := by\n'+r'''  classical
  let θ : Fin d → ℝ := fun i => ((i.val : ℝ) + 1 / 2) * Real.pi / (d : ℝ)
  let eigenvalue : Fin d → ℝ := fun i => (κ + 1) / 2 + (κ - 1) / 2 * Real.cos (θ i)
  let Λ : Matrix (Fin d) (Fin d) ℝ := Matrix.diagonal eigenvalue
  let μ : Measure (EuclideanSpace ℝ (Fin d)) := multivariateGaussian 0 Λ⁻¹
  let Q : EuclideanSpace ℝ (Fin d) → ℝ := fun x =>
    ∑ i : Fin d, Real.cos ((n : ℝ) * θ i) * (WithLp.ofLp x i) ^ 2
  let r : ℝ := (Real.sqrt κ - 1) / (Real.sqrt κ + 1)
  let a : ℤ → ℝ := signedAlias (2 * d)
  change Integrable (fun x : EuclideanSpace ℝ (Fin d) => ‖x‖ ^ 2) μ ∧
    Integrable Q μ ∧
    (∫ x : EuclideanSpace ℝ (Fin d), ‖x‖ ^ 2 ∂μ) =
      ((d : ℝ) / Real.sqrt κ) * ((1 - r ^ (2 * d)) / (1 + r ^ (2 * d))) ∧
    (-1 : ℝ) ^ n * (∫ x : EuclideanSpace ℝ (Fin d), Q x ∂μ) =
      ((d : ℝ) / Real.sqrt κ) * ((r ^ n - r ^ (2 * d - n)) / (1 + r ^ (2 * d)))
  have hactual := actual_diagonal_gaussian_quadratic_means hd hκ n hn hnd
  change Integrable (fun x : EuclideanSpace ℝ (Fin d) => ‖x‖ ^ 2) μ ∧
    Integrable Q μ ∧
    (∫ x : EuclideanSpace ℝ (Fin d), ‖x‖ ^ 2 ∂μ) = (∑ i : Fin d, (eigenvalue i)⁻¹) ∧
    (∫ x : EuclideanSpace ℝ (Fin d), Q x ∂μ) =
      ∑ i : Fin d, Real.cos ((n : ℝ) * θ i) / eigenvalue i at hactual
  have hsqrt : 1 < Real.sqrt κ := by
    nlinarith [Real.sqrt_nonneg κ, Real.sq_sqrt (by linarith : 0 ≤ κ)]
  have hr0 : 0 < r := div_pos (by dsimp [r]; linarith) (by linarith)
  have hr1 : r < 1 := by
    dsimp [r]
    apply (div_lt_one (by linarith : 0 < Real.sqrt κ + 1)).2
    linarith
  have hq : ‖-r‖ < 1 := by simpa [Real.norm_eq_abs, abs_of_pos hr0] using hr1
  have hD : 0 < 2 * d := by omega
  have hnD : n < 2 * d := by omega
  have hqD : (-r) ^ (2 * d) = r ^ (2 * d) := by simp only [pow_mul, neg_sq]
  have hden : 1 + r ^ (2 * d) ≠ 0 := ne_of_gt (by positivity)
  have ha0 : a 0 = 1 := by simp [a, signedAlias]
  have han : a (n : ℤ) = 0 := by
    have hnot : ¬ (2 * d : ℤ) ∣ (n : ℤ) := by
      intro h
      have hle := Int.le_of_dvd (by omega : (0 : ℤ) < n) h
      have hlt : (n : ℤ) < (2 * d : ℤ) := by exact_mod_cast hnD
      omega
    simpa only [a, signedAlias, Nat.cast_mul, Nat.cast_ofNat, if_neg hnot]
  have hsA : Summable (fun j : ℕ => (-r) ^ (j + 1) * a ((j + 1 : ℕ) : ℤ)) := by
    simpa only [sub_zero] using summable_signedAlias (2 * d) hq 0
  have hs0 : Summable (fun j : ℕ => (-r) ^ (j + 1) *
      (a (((j + 1 : ℕ) : ℤ) - 0) + a (((j + 1 : ℕ) : ℤ) + 0))) := by
    simpa only [sub_zero, add_zero, mul_add] using hsA.add hsA
  have ht0 : (∑' j : ℕ, (-r) ^ (j + 1) *
      (a (((j + 1 : ℕ) : ℤ) - 0) + a (((j + 1 : ℕ) : ℤ) + 0))) =
      2 * (-r ^ (2 * d) / (1 + r ^ (2 * d))) := by
    calc
      _ = ∑' j : ℕ, 2 * ((-r) ^ (j + 1) * a ((j + 1 : ℕ) : ℤ)) :=
        tsum_congr (fun j => by simp only [sub_zero, add_zero]; ring)
      _ = 2 * (∑' j : ℕ, (-r) ^ (j + 1) * a ((j + 1 : ℕ) : ℤ)) := hsA.tsum_mul_left 2
      _ = _ := by rw [unweighted_alias_tsum hD hq, hqD]
  have hgrid0 := inverse_grid_alias_series hd hκ 0 hs0
  change (∑ i : Fin d, Real.cos ((0 : ℤ) * θ i) / eigenvalue i) =
    ((d : ℝ) / Real.sqrt κ) * (a 0 + ∑' j : ℕ, (-r) ^ (j + 1) *
      (a (((j + 1 : ℕ) : ℤ) - 0) + a (((j + 1 : ℕ) : ℤ) + 0))) at hgrid0
  simp only [Int.cast_zero, zero_mul, Real.cos_zero, one_div, ha0, ht0] at hgrid0
  have hsN := weighted_alias_summable hn (by omega : 2 * n < 2 * d) hq
  have htN := weighted_alias_tsum hD hn hnD hq
  have hgridN := inverse_grid_alias_series hd hκ (n : ℤ) hsN
  change (∑ i : Fin d, Real.cos ((n : ℝ) * θ i) / eigenvalue i) =
    ((d : ℝ) / Real.sqrt κ) * (a (n : ℤ) + ∑' j : ℕ, (-r) ^ (j + 1) *
      (a (((j + 1 : ℕ) : ℤ) - (n : ℤ)) + a (((j + 1 : ℕ) : ℤ) + (n : ℤ)))) at hgridN
  rw [han, zero_add, htN, hqD] at hgridN
  have hsignsq : (-1 : ℝ) ^ n * (-1 : ℝ) ^ n = 1 := by
    rw [← mul_pow]
    norm_num
  have hparity : (-1 : ℝ) ^ (2 * d - n) = (-1 : ℝ) ^ n := by
    apply mul_left_cancel₀ (pow_ne_zero n (by norm_num : (-1 : ℝ) ≠ 0))
    rw [← pow_add, Nat.add_sub_of_le hnD.le, hsignsq]
    simp [pow_mul]
  refine ⟨hactual.1, hactual.2.1, ?_, ?_⟩
  · rw [hactual.2.2.1, hgrid0]
    field_simp [hden]
    <;> ring
  · rw [hactual.2.2.2, hgridN, neg_pow r n, neg_pow r (2 * d - n), hparity]
    have hcancel (u : ℝ) : (-1 : ℝ) ^ n * ((-1 : ℝ) ^ n * u) = u := by
      rw [← mul_assoc, hsignsq, one_mul]
    calc
      _ = ((d : ℝ) / Real.sqrt κ) *
          (((-1 : ℝ) ^ n * ((-1 : ℝ) ^ n * (r ^ n - r ^ (2 * d - n)))) /
            (1 + r ^ (2 * d))) := by ring
      _ = _ := by rw [hcancel]

'''+end+'\n'
p.write_text(s)
