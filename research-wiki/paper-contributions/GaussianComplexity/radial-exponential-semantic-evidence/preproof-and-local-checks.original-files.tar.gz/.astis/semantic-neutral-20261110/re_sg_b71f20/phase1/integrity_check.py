from pathlib import Path
import json,hashlib,datetime,sys
BASE=Path(__file__).resolve().parent
raw=(BASE/'inputs'/'2610.20492v1.html').read_bytes();s=raw.decode('utf-8')
manifest=json.loads((BASE/'input-manifest.json').read_text())
for name,e in manifest.items():
    bb=(BASE/'inputs'/name).read_bytes()
    assert len(bb)==e['bytes'] and hashlib.sha256(bb).hexdigest()==e['sha256'],name
g=json.loads((BASE/'source-graph.json').read_text());c=json.loads((BASE/'coverage.json').read_text());ex=json.loads((BASE/'anchored-excerpts.json').read_text())
assert hashlib.sha256(raw).hexdigest()=='6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
assert len({x['source_id'] for x in c['items']})==len(c['items'])
for x in c['items']:
    assert x['disposition'] in ['NODE','EXCLUDED'] and x['reason']
    a=x['anchor'];ss=s[a['char_start']:a['char_end']]
    assert hashlib.sha256(ss.encode()).hexdigest()==a['span_sha256'],x['source_id']
    assert raw[a['raw_utf8_start']:a['raw_utf8_end']]==ss.encode(),x['source_id']
    assert len(s[:a['char_start']].encode())==a['raw_utf8_start']
    assert s.count('\n',0,a['char_start'])+1==a['lf_line_start']
    assert not (x['tag']=='math' and x['reason'].startswith('Non-substantive wrapper')),x['source_id']
for ident,x in ex.items():
    a=x['anchor'];assert x['raw_html'].encode()==raw[a['raw_utf8_start']:a['raw_utf8_end']],ident
ids={x['id'] for x in g['nodes']};assert len(ids)==len(g['nodes'])
for e in g['edges']:assert e['conclusion'] in ids and set(e['premises'])<=ids
ancestors={}
for target in g['selected_scalar_nodes']:
    seen=set();todo=[target]
    while todo:
        child=todo.pop()
        for e in g['edges']:
            if e['conclusion']==child:
                for pp in e['premises']:
                    if pp not in seen:seen.add(pp);todo.append(pp)
    assert not (seen & set(g['prohibited_scalar_parents'])),(target,seen & set(g['prohibited_scalar_parents']))
    ancestors[target]=sorted(seen)
for i in range(1,20):assert any(x['source_id']==f'A3.SS2.p{i}' for x in c['items'])
result={'status':'passed structural/source-byte integrity only; not mathematical/source-topology approval','input_manifest_entries_verified':len(manifest),'coverage_entries':len(c['items']),'exact_span_checks':len(c['items']),'raw_excerpt_checks':len(ex),'nodes':len(g['nodes']),'edges':len(g['edges']),'scalar_forbidden_ancestor_intersections':0,'selected_scalar_ancestors':ancestors}
receipt={'argv':sys.argv,'time_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':0,'stdout':json.dumps(result,indent=2)+'\n','stderr':'','read_scope':'provided Phase1 inputs/manifest and self-derived Phase1 artifacts only'}
(BASE/'integrity-results.json').write_text(json.dumps(result,indent=2)+'\n')
(BASE/'execution'/'integrity-execution.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='selected_scalar_ancestors'},indent=2))
