import Tests.GaussianComplexityFixedSpectrumWeightedFrameBound
import Lean
open Lean Elab Command Meta
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option pp.universes true
set_option pp.explicit true
set_option pp.proofs true
set_option pp.deepTerms true
set_option pp.maxSteps 100000000

private def owned (n : Name) : Bool :=
  (n.toString.splitOn "AutoSamplingTheory.TechnicalLemmas.StochasticProcesses.GaussianFourthMoment").length > 1 ||
  (n.toString.splitOn "AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrum").length > 1 ||
  (n.toString.splitOn "AutoSamplingTheory.Tests.GaussianComplexityFixedSpectrumWeightedFrameBound").length > 1

private partial def reach (env : Environment) (todo : List Name) (seen : NameSet := {}) : NameSet :=
  match todo with
  | [] => seen
  | n :: rest =>
    if seen.contains n then reach env rest seen else
    let seen := seen.insert n
    match env.find? n with
    | none => reach env rest seen
    | some c => reach env (c.getUsedConstantsAsSet.toList ++ rest) seen

run_cmd do
  let env ← getEnv
  let mut rows : Array Json := #[]
  for (n,c) in env.constants.toList do
    if owned n then
      let axioms ← collectAxioms n
      let direct := c.getUsedConstantsAsSet.toList.filter owned
      let closure := (reach env [n]).toList
      let typeText ← liftTermElabM <| return (← ppExpr c.type).pretty
      let valueText ← liftTermElabM <| match c.value? true with
        | none => pure "NO_BODY"
        | some v => return (← ppExpr v).pretty
      let moduleText := match env.getModuleIdxFor? n with
        | none => "NO_MODULE"
        | some idx => env.header.moduleNames[idx.toNat]!.toString
      rows := rows.push <| Json.mkObj [
        ("name",toJson n.toString), ("module",toJson moduleText),
        ("type",toJson typeText), ("body",toJson valueText),
        ("type_expr_hash",toJson (toString (hash c.type))),
        ("body_expr_hash",toJson (toString (hash (c.value? true)))),
        ("direct_owned",toJson (direct.map Name.toString)),
        ("transitive_owned",toJson ((closure.filter owned).map Name.toString)),
        ("closure_constant_count",toJson closure.length),
        ("closure_axioms",toJson (axioms.toList.map Name.toString))]
  liftIO <| IO.FS.writeFile "/Users/zhouhuanjian/ASTIS-GC/.astis/semantic-neutral-20261112/wf_native_64a2/native-environment-v2.json" (Json.pretty (toJson rows))
  logInfo m!"Exported full types, full proof bodies, direct and transitive owned dependencies, and axiom closures for {rows.size} owned constants."
