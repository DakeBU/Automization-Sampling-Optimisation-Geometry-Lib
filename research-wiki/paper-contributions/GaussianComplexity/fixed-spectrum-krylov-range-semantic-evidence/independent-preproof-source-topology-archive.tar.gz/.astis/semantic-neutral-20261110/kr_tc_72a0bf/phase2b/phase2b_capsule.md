# Phase 2b bounded independent challenger capsule

Disposition: **two bounded use-site/representation repairs required before necessity-complete topology acceptance**. No target signature, metric, normalization or source theorem is refuted; no proof or global sourceV is approved.

R1: source `e-witness` currently ANDs `C5.range` with the broad theorem/scaling leaf `E.range-columns`. At A3.SS2.p19.2, only K subset image(B) plus existential image semantics is immediately used. The typed overlay already has the correct `P.reverse -> T.witness` direction. Require a versioned replacement edge/definition conversion, keeping the column-span/scaling theorem inside the range proof.

R2: `e-span`/`C5.span-conversion` and typed `P.objects`/`P.polynomial`/`P.triangular` need an explicit internal obligation identifying actual diagonal matrix powers with weighted monomials: `((Lambda^j).mulVec g_a)_i=lambda_i^j(g_a)_i`, including j=0. Scalar cosine polynomial evaluation plus a triangular coefficient transform does not itself state that representation bridge. An expanded existing leaf/subobligation suffices; do not add a public binder or claim compilation.

Required changes are recorded in `repair-requests.json` and explained with raw source pins in `phase2b_topology_judgment.md`. Require a **new frozen author overlay/version and bounded recheck**; never overwrite frozen proposals or independent baselines.

Checks that passed: same 520 source IDs with exact raw character/UTF8/LF/hash agreement, all252 math and67 table/body elements, three anonymous citations; Ex130/131 table-inline equalities and inequalities separately mapped; C.5 conjuncts split; same coefficient witness; unscaled starts and B normalizations exact; q=0/zero/dependent cases preserved; pointwise strengthening and signed elaboration explicit; no Gaussian/rank/full-rank/concentration/independence hypotheses added to P/T; source route separated from hypothetical compiler topology. Counts are inventory checks only.

The C.6 source route and its open external Bernstein/moment leaves remain probabilistic context, not parents of the focal exact identities. No false OR-route was found. Parent projection notes for Gaussian marginal laws and definition bundles are nonblocking; probabilistic aggregate wording can be clarified in the same overlay.

Inputs: SG `b8d2503c8cf64491e5099e3ae6b5b1745d1d18f5bf2e7650046f95f0c23fc2ba`; coverage `1105056c5d9a1a2210846ea9958ef3c6df99034ffdbd280f068361b9f333a833`; typed overlay `0fe674ba24615b9030e30ef4ea09ed332acec04c2f12ba0d16293b6531661787`. Earlier Phase1/Phase2a hashes and modes remain unchanged. No target/API/proof/root narrative/frontier/process-authority/ledger/Goal/STAB/publication/ATLAS access, no subagent/background work; no read/assertion failure or truncation in this phase. Freeze then pause.
