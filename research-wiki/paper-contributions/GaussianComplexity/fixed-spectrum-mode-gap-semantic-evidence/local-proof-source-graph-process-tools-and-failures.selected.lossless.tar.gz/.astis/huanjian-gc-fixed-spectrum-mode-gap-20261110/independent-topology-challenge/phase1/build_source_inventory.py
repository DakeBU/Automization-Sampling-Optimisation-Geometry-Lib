"""Mode-gap packet raw source census only; no statement/graph/Lean input."""
from pathlib import Path
from collections import Counter
from bisect import bisect_right
import hashlib
import json
import re
import runpy

ROOT = Path('/Users/zhouhuanjian/ASTIS-GC')
OUT = ROOT / '.astis/huanjian-gc-fixed-spectrum-mode-gap-20261110/independent-topology-challenge/phase1'
PARSER = ROOT / '.astis/huanjian-gc-fixed-spectrum-variances-20261110/independent-topology-challenge/source_only_reader.py'
assert hashlib.sha256(PARSER.read_bytes()).hexdigest() == '9b937b08225abd768e25328e213ad758de84fd455b8acf255353710271fd99c5'
r = runpy.run_path(str(PARSER))
walk, record = r['walk'], r['record']
lines = r['TEXT'].splitlines(keepends=True)


def normalized(n):
    return re.sub(r'\s+', ' ', r['normalized'](n)).strip()


def source_key(n):
    line = bisect_right(r['LINES'], n.start)
    return f'{n.tag}@{line}:{n.start - r["LINES"][line - 1]}'


def unit_kind(n):
    classes = n.attrs.get('class', '').split()
    if n.tag == 'section':
        return 'section-container'
    if re.fullmatch('h[1-6]', n.tag):
        return 'heading'
    if n.tag == 'div':
        for c, kind in [('ltx_para', 'paragraph-container'), ('ltx_theorem', 'source-statement-container'), ('ltx_proof', 'source-proof-container')]:
            if c in classes:
                return kind
    if n.tag == 'p' and 'ltx_p' in classes:
        return 'substantive-paragraph'
    if n.tag == 'table' and any(c in classes for c in ['ltx_equation', 'ltx_equationgroup']):
        return 'display'
    if n.tag == 'tbody':
        return 'aligned-TBODY'
    if n.tag == 'cite':
        return 'citation-occurrence'
    if n.tag == 'a' and n.attrs.get('href'):
        return 'link-occurrence'
    if n.tag == 'li' and n.attrs.get('id', '').startswith('bib.'):
        return 'bibliography-entry'


def display_locator(n):
    if n.attrs.get('id'):
        return n.attrs['id']
    parent = n.parent
    while parent and not parent.attrs.get('id'):
        parent = parent.parent
    return parent.attrs['id'] + '::' + n.tag + '@' + str(record(n)['line_start'])


units, math, links, scopes, readback = [], {}, [], [], []
for scope in ['S2', 'S4', 'A3.SS3', 'bib.bib3']:
    root = r['READER'].ids[scope]
    scopes.append({'scope': scope, **record(root)})
    readback.append('RAW ROOT ' + scope + '\n' + r['normalized'](root))
    for n in walk(root):
        if n.tag == 'math':
            ident = n.attrs['id']
            assert ident not in math
            math[ident] = {'id': ident, 'source_unit_key': source_key(n),
                           'tex': n.attrs.get('alttext', ''), 'display': n.attrs.get('display', ''), **record(n)}
        if n.tag == 'a' and n.attrs.get('href'):
            links.append({'link_ordinal': len(links), 'scope': scope, 'source_unit_key': source_key(n),
                          'href': n.attrs['href'], 'title': n.attrs.get('title', ''), 'text': normalized(n), **record(n)})
        kind = unit_kind(n)
        if not kind:
            continue
        raw = record(n)
        text = normalized(n) if kind in ['substantive-paragraph', 'display', 'aligned-TBODY', 'citation-occurrence', 'link-occurrence', 'heading', 'bibliography-entry'] else None
        if kind == 'source-statement-container':
            text = next((normalized(q) for q in walk(n) if re.fullmatch('h[1-6]', q.tag)), '')
        units.append({'raw_ordinal': len(units), 'source_unit_key': source_key(n),
                      'display_locator': display_locator(n), 'scope': scope, 'kind': kind, **raw,
                      'line_slice_sha256': hashlib.sha256(''.join(lines[raw['line_start'] - 1:raw['line_end']]).encode()).hexdigest(),
                      'text': text, 'math_ids': [q.attrs['id'] for q in walk(n) if q.tag == 'math'],
                      'link_byte_starts': [record(q)['byte_start_inclusive'] for q in walk(n) if q.tag == 'a' and q.attrs.get('href')],
                      'status': 'RAW_OBSERVATION_ONLY_NO_NEW_TARGET_DISPOSITION'})
assert len({u['source_unit_key'] for u in units}) == len(units)
collisions = {name: [u['raw_ordinal'] for u in units if u['display_locator'] == name]
              for name, count in Counter(u['display_locator'] for u in units).items() if count > 1}
counts = {'raw_units': len(units), 'unit_kinds': dict(Counter(u['kind'] for u in units)),
          'scope_units': dict(Counter(u['scope'] for u in units)), 'unique_math_elements': len(math),
          'link_occurrences': len(links), 'internal_links': sum(x['href'].startswith('#') for x in links),
          'external_links': sum(not x['href'].startswith('#') for x in links)}
inventory = {'phase': 'MODE_GAP_INDEPENDENT_RAW_ONLY_PHASE1', 'source_sha256': hashlib.sha256(r['RAW']).hexdigest(),
             'unit_rule': 'Complete S2/S4/C3 roots plus genuinely cited local bibliography object; every paragraph/statement/display/TBODY/citation/link indexed. Math registry de-duplicates actual raw elements; containers are structural, not additional theorem claims.',
             'identity': 'Unique source_unit_key and raw_ordinal; preserve actual HTML IDs, while anonymous display_locator can collide and is not a unique key.',
             'roots': scopes, 'counts': counts, 'anonymous_display_locator_collisions': collisions,
             'units': units, 'math_registry': list(math.values()), 'link_registry': links,
             'NODE_EXCLUDED_target_dispositions': None, 'statement_or_graph_verdict': None}
OUT.mkdir(parents=True, exist_ok=True)
for name, content in [('raw-source-inventory.json', json.dumps(inventory, ensure_ascii=False, indent=2) + '\n'),
                      ('raw-source-readback.txt', '\n\n'.join(readback) + '\n')]:
    path = OUT / name
    assert not path.exists()
    path.write_text(content)
for obj in units + list(math.values()) + links:
    raw_slice = r['RAW'][obj['byte_start_inclusive']:obj['byte_end_exclusive']]
    assert hashlib.sha256(raw_slice).hexdigest() == obj['raw_sha256']
print(json.dumps({'counts': counts, 'collisions': collisions,
                  'outputs': {name: {'bytes': (OUT / name).stat().st_size,
                                     'sha256': hashlib.sha256((OUT / name).read_bytes()).hexdigest()}
                              for name in ['raw-source-inventory.json', 'raw-source-readback.txt']}}, ensure_ascii=False, indent=2))
