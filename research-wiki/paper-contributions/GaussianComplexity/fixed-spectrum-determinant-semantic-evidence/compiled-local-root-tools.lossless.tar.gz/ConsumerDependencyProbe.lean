import Tests.GaussianComplexityFixedSpectrumDeterminant
open Lean in
run_cmd do
  let env ← getEnv
  let mut count : Nat := 0
  for (name, _) in env.constants.toList do
    if name.toString.startsWith "_private.Tests.GaussianComplexityFixedSpectrumDeterminant" then
      count := count + 1
      logInfo m!"ACTUAL TEST DECLARATION {name}"
  logInfo m!"ACTUAL TEST PRIVATE DECLARATION COUNT {count}"
  let some info := env.find? `AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumDeterminant.actual_precision_det | throwError "Missing producer"
  let some proof := info.value? (allowOpaque := true) | throwError "Missing producer proof"
  for name in proof.getUsedConstants do
    if name.toString.startsWith "Matrix." || name.toString.startsWith "Unitary." then
      logInfo m!"ACTUAL CANONICAL STANDARD PROOF CONSTANT {name}"
