from pathlib import Path
import json,hashlib,sys
sys.path.insert(0,'tools')
import astis_publication as pub
import astis_semantic_roundtrip as rt
sha=lambda x:hashlib.sha256(x.encode() if isinstance(x,str) else x).hexdigest()
def put(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
b=Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-normalizer-semantic-evidence')
s=json.loads((b.parent/'fixed-spectrum-normalizer-statement-seal.json').read_bytes())
sig=s['exact_signature_utf8'];name=s['declaration'];file=s['production_file'];code=Path(file).read_text()
start=code.index('theorem actual_normalizing_integral');end=code.index(' := by',start)
assert code[start:end]+'\n'==sig
test=Path('Tests/GaussianComplexityFixedSpectrumNormalizer.lean')
cs=json.loads((b/'actual-consumer-interface/statement-seal.json').read_bytes())
tc=test.read_text();start=tc.index('private theorem actual_gaussian_density_consumer');end=tc.index(' := by',start)
assert tc[start:end].replace('private theorem actual_gaussian_density_consumer','example',1)+'\n'==cs['exact_consumer_signature_utf8']
put(b/'actual-consumer-interface/test-private-name-projection.json',{
 'original_sealed_signature_sha256':cs['consumer_signature_sha256'],
 'actual_Test_raw_sha256':sha(test.read_bytes()),
 'projection':'Erase only private theorem name by replacing it with example; exact sealed interface bytes match.',
 'statement_and_binders_byte_exact':True,'new_theorem_credit':False})
statement='∀ '+sig[len('theorem actual_normalizing_integral '):].replace('(O : Matrix.orthogonalGroup (Fin d) ℝ) :','(O : Matrix.orthogonalGroup (Fin d) ℝ),',1)
context=[
 'Fin d is the finite coordinate set with natural values zero through d-1. The finite sum and product each include every coordinate once. Index and dimension casts, one half, divisions and exponents here are real operations.',
 'Matrix.orthogonalGroup (Fin d) real is the full real orthogonal group, requiring both products with the transpose to equal identity. It permits either determinant sign and supplies no probability law or determinant-one condition. Diagonal, multiplication, transpose and mulVec are the ordinary finite matrix operations.',
 'EuclideanSpace real (Fin d) is the real coordinate space with its Euclidean inner product and norm. WithLp.ofLp gives the same vector coordinates. The explicit volume is its unnormalized Euclidean Lebesgue measure: the standard orthonormal-basis parallelepiped has measure one. It is not Gaussian probability or normalized surface measure.',
 'Integrable f volume means almost-everywhere strong measurability together with finite integral of the norm. It occurs in the conclusion. The displayed real Bochner integral is the actual integral of the same function against the same volume. Its conventional zero value outside integrability does not supply the separately asserted integrability conclusion.',
 'Real.exp, Real.cos and Real.pi have their usual real meanings. Real.sqrt is the nonnegative square root, totalized as zero on nonpositive arguments. Real.rpow uses a real exponent, including odd dimensions. Division is totalized at zero; all nonzero and positivity conditions needed for the asserted value must be derived from the displayed inputs rather than supplied as further assumptions.'
]
parents=[
 'AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumAdmissibility.actual_precision_admissible',
 'AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumDeterminant.actual_precision_det',
 'AutoSamplingTheory.TechnicalLemmas.Measure.GaussianPrecisionDensity.multivariateGaussian_eq_withDensity_of_posDef']
short='The actual quadratic Gaussian weight is Lebesgue integrable, with a normalizing integral determined by the displayed spectrum.'
formula=r'w_A\in L^1(dx),\qquad Z_A:=\int_{\mathbb R^d}e^{-x^\top A x/2}\,dx=\frac{(2\pi)^{d/2}}{\sqrt{\prod_{i=1}^d\lambda_i}}.'
assumptions=[
 r'\(d\in\mathbb N,\ d\ge2,\ \kappa\in\mathbb R,\ \kappa\ge2\). Fix every \(O\in O(d)\), with either determinant sign. This is a pointwise assertion.',
 r'For \(i=1,\ldots,d\), let \(\theta_i=(i-\tfrac12)\pi/d\), \(\lambda_i=(\kappa+1)/2+(\kappa-1)\cos\theta_i/2\), and \(A=O\operatorname{diag}(\lambda_i)O^\top\). Set \(w_A(x)=e^{-x^\top A x/2}\). The zero-based Lean index \(j.\mathrm{val}\) corresponds to \(i=j.\mathrm{val}+1\).',
 r'The integration base \(dx\) is ordinary unnormalized Euclidean Lebesgue volume. The exponent \(d/2\) is real, including odd dimensions. Integrability, positive definiteness, determinant/product identity and positive mass are proved internally; none is a supplied premise.',
 r'The paper displays the Gaussian normalizer value. Interpreting \(Z_A\) as this unweighted Lebesgue integral, and exposing finite integrability explicitly, is a disclosed standard source-implicit elaboration.',
 r'The actual consumer expresses the same \(N(0,A^{-1})\) as \(w_A(x)/Z_A\,dx\), using this actual integral. Only the normalizing scalar is independent of \(O\); the covariance and quadratic exponent retain the actual \(A\).']
steps=[
 {'title':'Obtain valid precision and its determinant','text':'Apply the existing actual admissibility and determinant results to the literal source matrix. Positive definiteness also gives a positive determinant and a valid inverse covariance.','formula':r'A\succ0,\qquad \det A=\prod_i\lambda_i>0.', 'lean':'hA and hdet use the identical canonical actual_precision_admissible and actual_precision_det nodes; hsqrt uses hA.det_pos. The strict historical angle/cosine route is not newly proved here.'},
 {'title':'Reuse the actual Gaussian density','text':'Put B=(2π)^(d/2) and c=√det(A)/B. Both are positive. The existing canonical Gaussian density identifies the actual centered inverse-precision Gaussian with the Lebesgue density c times this very weight.','formula':r'B=(2\pi)^{d/2}>0,\quad c=\frac{\sqrt{\det A}}B>0,\quad N(0,A^{-1})(dx)=c\,w_A(x)\,dx.', 'lean':'hdensity applies the unchanged GaussianPrecisionDensity.multivariateGaussian_eq_withDensity_of_posDef to actual A and internally produced hA. The coordinate dot product and explicit finite sum are definitionally the same quadratic form.'},
 {'title':'Use unit probability mass to prove finite integrability','text':'The actual Gaussian has mass one. Evaluating the density identity on the whole space gives a finite nonnegative integral. Continuity supplies measurability, so this finite integral proves integrability of c times the weight. Since c is nonzero, the weight itself is integrable.','formula':r'\int^{\! -}\operatorname{ofReal}(c\,w_A)\,dx=1<\infty\quad\Longrightarrow\quad c\,w_A\in L^1(dx)\quad\Longrightarrow\quad w_A\in L^1(dx).', 'lean':'hmass uses the whole-space measure identity. hmeas and hnonneg supply the hypotheses of lintegral_ofReal_ne_top_iff_integrable; integrable_const_mul_iff yields hw. This proves finite norm-integral independently of the totalized Bochner integral value.'},
 {'title':'Recover the actual unweighted integral','text':'For a nonnegative measurable function, the real integral agrees with the real value of its nonnegative integral. Pull out the constant and use the unit-mass identity, then divide by the positive coefficient.','formula':r'c\int w_A\,dx=\int c\,w_A\,dx=1,\qquad \int w_A\,dx=\frac{B}{\sqrt{\det A}}.', 'lean':'hscaled uses integral_const_mul and integral_eq_lintegral_of_nonneg_ae. The nonzero square root and B justify the final real division; no integrability or normalization certificate is assumed.'},
 {'title':'Substitute the fixed spectral product','text':'Replace the actual determinant by its proved finite diagonal product. This gives the displayed value, independent of the orientation. Gaussian integration is implemented through the already proved density and its probability mass, an explicit implementation route for the source’s compressed Gaussian-integration step.','formula':r'Z_A=\frac{(2\pi)^{d/2}}{\sqrt{\prod_i\lambda_i}}.', 'lean':'The exact sealed conclusion follows by hdet and positive-denominator algebra. The existing density proof does not depend on this new theorem, so this route has no circular normalization assumption.'},
 {'title':'Use the new integral in the actual normalized law','text':'The focused Test substitutes this actual integral into the density of the same Gaussian. It derives strictly positive actual mass internally and uses the new producer consequentially in the denominator calculation.','formula':r'N(0,A^{-1})(dx)=\frac{w_A(x)}{\int w_A\,dx}\,dx.', 'lean':'The compiled private Test proof contains actual_normalizing_integral, the existing actual admissibility and determinant nodes, and the same canonical Gaussian density node. Its signature matches the independently admitted consumer after erasing only the private name.'}
]
source={'url':'https://arxiv.org/html/2610.20492v1#A3.SS4',
 'edition':'arXiv2610.20492v1; raw HTML SHA2566bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915',
 'anchor':'S4.SS1 Eq11/public-normalizer; S2 actual potential/target; complete AppendixC.4 Gaussian-integration component A3.Ex160.',
 'wording_status':'faithful paraphrase',
 'attribution':'Huanjian Zhou and Taiji Suzuki, On Complexity of Gaussian Sampling. The actual integral/base measure is explicitly labeled a standard source-implicit elaboration.',
 'scope':'Actual finite unweighted Gaussian integral and same-A normalized-law consumer. Full C4 calculus/minimizer and main lower-bound/operational adapters remain separate.'}
boundary='This proves the actual fixed-spectrum unweighted Euclidean Gaussian integral, its finite integrability and a genuine same-A integral-normalized density consumer. It does not prove the remaining C.4 calculus/strong-convexity/smoothness/unique-minimizer claims or the strict historical angle/cosine route. Moments/Krylov, adaptive/private-seed/transcript/output laws, actual oracle/finite-precision/TV and deterministic/expected-cost adapters, both complete main lower bounds and whole-paper completion remain separate. Source review, canonical integration, remote delivery and postmerge purification/Exposition Seal have their own evidence gates.'
unit={'kind':'theorem','reading_layout':'progressive','declaration':name,'title':'Actual fixed-spectrum Gaussian normalizing integral',
 'reader_note':'The integral value is shown first; exact family, all assumptions, formula proof and precise Lean are folded below.',
 'statement':short,'formula':formula,'assumptions':assumptions,
 'notation':[{'symbol':r'\(w_A,Z_A,dx\)','text':'Actual unnormalized quadratic weight, its actual integral, and unnormalized Euclidean Lebesgue volume.','formula':r'w_A(x)=e^{-x^\top A x/2},\qquad Z_A=\int w_A(x)\,dx.'}],
 'steps':steps,'astis_dependencies':parents,
 'mathlib_dependencies':['withDensity_apply','measure_univ','lintegral_ofReal_ne_top_iff_integrable','integrable_const_mul_iff','integral_const_mul','integral_eq_lintegral_of_nonneg_ae','Real.sqrt_pos','Real.rpow_pos_of_pos'],
 'lean_statement':'Exactly the sealed literal source weight is Integrable and its actual volume integral equals the displayed product/sqrt expression; real d/2, source d>=2,kappa>=2 and full O.',
 'lean_proof':'Exact production statement and proof are extracted adjacent to these steps. Existing canonical precision/determinant/density declarations are actual formal parents; finite-mass/integrability and real-normalization adapters are proved internally.',
 'boundary':boundary,'sources':[{**source,'label':'Zhou–Suzuki Eq11 and Gaussian integration in AppendixC.4'}],
 'tests':['lake build Tests.GaussianComplexityFixedSpectrumNormalizer']}
put('website/content/declaration_lessons/huanjian-fixed-spectrum-normalizer.json',{'schema_version':1,'units':[unit]})
text=' '.join([short,formula,*assumptions])
binding={'declaration':name,'cell':'ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-normalizer','role':'proof-edge',
 'supports':['actual-fixed-spectrum-normalizing-integral'],'boundary':boundary,
 'assumption_deltas':[
 {'source':'Local hard family d>=2,kappa>=2 and arbitrary full real O; actual grid/precision/potential.',
  'lean':'Exactly the same inputs and literal theta/diagonalValue/A/weight. No PosDef, determinant, measurability, integrability, positive mass or normalization premise.',
  'classification':'same','reason':'All such facts are outputs or actual internal dependencies; the same canonical parents are reused once.'},
 {'source':'Appendix C.4 states Gaussian integration gives determinant-form Z_A and fixed-spectrum independence.',
  'lean':'Actual unweighted Euclidean Lebesgue integral with Integrable output equals (2pi)^(real d/2)/sqrt(full diagonal product).',
  'classification':'source-implicit','reason':'The base integral convention and explicit finite integrability elaborate standard normalizer meaning. Diagonal determinant/product and real square-root/half-power presentations are internal bridges. No source passage is falsely quoted as an explicit integral definition.'},
 {'source':'Actual target is N(0,Ainv) for quadratic potential.',
  'lean':'The same actual inverse-precision Gaussian equals volume.withDensity ofReal(weight/(actual integral)).',
  'classification':'source-implicit','reason':'This is a genuine actual-law normalization consumer, using the new integral result. Positive actual mass and valid covariance are produced internally; only the normalization scalar is independent of O. No algorithmic or TV/cost claim follows.'}],
 'audit_id':'ASTIS-RT-20261108-HuanjianFixedSpectrumNormalizer'}
item={'id':'huanjian-fixed-spectrum-normalizer','library':'samplewiki','chapter':'gaussian-sampling-complexity',
 'chapter_path':'example-cases/samplewiki/companions/gaussian-sampling-complexity.html','title':unit['title'],
 'source':source,'statement':text,'formulae':[{'label':'Actual Gaussian integral','tex':formula}],
 'assumptions':assumptions,'obligations':[{'id':'actual-fixed-spectrum-normalizing-integral','label':'The actual literal source Gaussian weight is Euclidean-Lebesgue integrable and has the displayed fixed-spectrum integral.'}],
 'bindings':[binding]}
put('website/content/publications/huanjian-fixed-spectrum-normalizer.json',{'schema_version':1,'items':[item]})
audit={'id':binding['audit_id'],'state':'draft',
 'source':{'source_id':'arxiv2610.20492v1-ActualFixedSpectrumNormalizer','url':source['url'],'anchor':source['anchor'],
           'original_text':text,'text_sha256':sha(text),'source_snapshot_sha256':s['source']['raw_sha256']},
 'lean':{'declaration':name,'file':file,'statement':statement,'statement_sha256':sha(statement),
         'formalizer':'huanjian_gc_20261108_fixed_spectrum_normalizer','compiled':True,'decoder_context':context},
 'reconstruction':{},'semantic_slots':{},'deltas':[],'verdict':'pending','source_review':{'state':'pending'},'repairs':[]}
ap=Path('research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-normalizer.json');assert not ap.exists();put(ap,audit)
pub.inputs.cache_clear();pub.load.cache_clear()
audit['publication_binding_sha256']=pub.binding_digest(item,binding);audit['publication_context']=pub.review_context(item,binding);put(ap,audit)
pub.check_advance([name],reviewed=False)
packet=rt.decoder_packet(audit)
neutral=Path('.astis/semantic-neutral-20261108/a7f6d291');neutral.mkdir(parents=True,exist_ok=False)
put(neutral/'input.json',packet);put(b/'decoder-input.json',packet);(b/'anonymous-statement.txt').write_text(statement)
probe='import AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumNormalizer\nopen Matrix MeasureTheory\nopen scoped BigOperators\nexample : (\n'+statement+') := by\n  intro d hd κ hκ O\n  exact '+name+' hd hκ O\n'
Path('.astis/huanjian-fixed-spectrum-normalizer-20261108/AnonymousProbe.lean').write_text(probe)
record={'production_raw_sha256':sha(Path(file).read_bytes()),'Test_raw_sha256':sha(test.read_bytes()),
 'actual_ASTIS_producer_parents':parents,'actual_ASTIS_consumer_parents':parents+[name],
 'publication_binding_sha256':audit['publication_binding_sha256'],'anonymous_statement_sha256':sha(statement),
 'anonymous_packet_canonical_sha256':packet['packet_sha256'],'actual_neutral_input':str(neutral/'input.json'),
 'actual_neutral_input_raw_sha256':sha((neutral/'input.json').read_bytes()),
 'actual_focused_build_receipt':'20261108T063101675961Z-fixed-spectrum-normalizer-focused-consumer-corrected.receipt.json',
 'actual_kernel_parent_receipt':'20261108T063237852392Z-fixed-spectrum-normalizer-kernel-dependencies-corrected.receipt.json',
 'source_review':'pending','anonymous_literal_application_probe':'pending'}
put(b/'publication-draft-record.json',record)
print(json.dumps({'draft_publication_valid':True,**record}))
