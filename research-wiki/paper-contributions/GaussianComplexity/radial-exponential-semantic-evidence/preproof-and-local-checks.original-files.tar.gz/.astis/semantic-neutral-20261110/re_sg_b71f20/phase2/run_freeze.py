from pathlib import Path
import subprocess,json,hashlib,datetime,sys
BASE=Path(__file__).resolve().parent;ROOT=BASE.parent
def sha(b):return hashlib.sha256(b).hexdigest()
cmd=['/opt/anaconda3/bin/python','-B',str(BASE/'freeze.py')];cwd='/Users/zhouhuanjian/ASTIS-GC'
start=datetime.datetime.now(datetime.timezone.utc).isoformat()
r=subprocess.run(cmd,cwd=cwd,capture_output=True)
receipt={'schema':'original-actual-execution-receipt-v1','command':cmd,'cwd':cwd,'start_utc':start,'end_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'actual_returncode':r.returncode,'actual_stdout_utf8':r.stdout.decode('utf-8'),'actual_stderr_utf8':r.stderr.decode('utf-8'),'stdout_bytes':len(r.stdout),'stdout_sha256':sha(r.stdout),'stderr_bytes':len(r.stderr),'stderr_sha256':sha(r.stderr),'status_authority':'Actual captured freeze subprocess; no mathematical verification authority.'}
rp=ROOT/'phase2-freeze-execution-receipt.json';rp.write_text(json.dumps(receipt,indent=2,ensure_ascii=False)+'\n');rp.chmod(0o444)
if r.returncode!=0:
    print(json.dumps(receipt,indent=2,ensure_ascii=False));sys.exit(r.returncode)
out=json.loads(r.stdout);mp=BASE/'phase2-manifest.json'
index={'schema':'typed-source-phase2-freeze-index-v1','manifest':{'path':'phase2/phase2-manifest.json','bytes':mp.stat().st_size,'sha256':sha(mp.read_bytes()),'mode':'0444'},'original_actual_execution_receipt':{'path':rp.name,'bytes':rp.stat().st_size,'sha256':sha(rp.read_bytes()),'mode':'0444'},'result':out,'self_binding':'Exact index hash reported to parent; manifest plus external manifest/receipt bindings cover all frozen Phase2 bytes.'}
ip=ROOT/'phase2-freeze-index.json';ip.write_text(json.dumps(index,indent=2,ensure_ascii=False)+'\n');ip.chmod(0o444)
print(json.dumps({'index_path':str(ip),'index_sha256':sha(ip.read_bytes()),'manifest_sha256':index['manifest']['sha256'],'original_actual_receipt_sha256':index['original_actual_execution_receipt']['sha256'],'key_sha256':out['key_sha256'],'total_phase2_files':out['total_phase2_files'],'actual_freeze_exit':r.returncode},indent=2))
