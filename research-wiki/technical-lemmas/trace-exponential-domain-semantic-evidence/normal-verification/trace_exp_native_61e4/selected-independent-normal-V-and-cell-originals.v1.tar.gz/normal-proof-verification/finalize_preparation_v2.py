"""Local permission fix + read-only pin/AST checks for PREPARED v2. Never invokes either action."""
from verification_common import *
import difflib,traceback

def main(before_files,before_dirs):
    for directory in [PRIVATE,*[p for p in PRIVATE.rglob('*') if p.is_dir()]]:os.chmod(directory,0o700)
    for p in PRIVATE.rglob('*'):
        if p.is_file():os.chmod(p,0o600)
    assert all(file_sha(Path(p))==x['sha256'] for p,x in before_files.items())
    write(PRIVATE/'permission-v2-before-map.private.json',{'files':before_files,'directories':before_dirs,'only_permissions_changed_in_preexisting_private_tree':True})
    saved=OWN/'preparation-source-before-permission-v2';diffs=[]
    for name in ['verification_common.py','verification_driver.py','prepare_readonly.py']:
        old=(saved/name).read_text();new=(OWN/name).read_text();diffs.extend(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='before-permission-v2/'+name,tofile='explicit-permission-v2/'+name));ast.parse(new,filename=name)
    exact(OWN/'permission-process-only.v2.diff',''.join(diffs).encode())
    a=read(OWN/'window1.authorization.draft.json');a['scripts']={n:file_sha(OWN/n) for n in ['verification_common.py','verification_driver.py']}
    a['carrier_commit']='45564beb6e0dd5e4357718ea04347a50613ad502';a['expected_branch']='refs/heads/huanjian/gaussian-fixed-spectrum-moments-20261109';a['expected_target_cell_sha256']='8f6a5225aefe5679c0606991c89c595c7c6aec67a66a70c07b847bf09e30bcd2'
    gate=REPO/'.astis/huanjian-gc-trace-mgf-domain-20261115/preV-actual-gates.v1.json';assert file_sha(gate)=='b7f3dd46c65c1ecdd1914da800b7135f6eacd4ed224e619a1255b1226f6ca54a';a['gate_summary']=ident(gate)
    E=REPO/'research-wiki/technical-lemmas/trace-exponential-domain-semantic-evidence';archive=E/'reader-originals/trace_exp_reader_61e4/selected-actual-reader-originals77.v1.tar.gz'
    with tarfile.open(archive,'r:*') as tar:
        members=[x for x in tar.getmembers() if x.name.endswith('reader-acceptance-v1/reader-acceptance-report.json')];assert len(members)==1 and members[0].isfile();b=tar.extractfile(members[0]).read();assert sha(b)==READERSHA
    a['evidence_pins']['reader_carried']={**ident(archive),'member':members[0].name,'member_sha256':READERSHA,'member_bytes':len(b)}
    served=E/'reader-served-byte-closure/new-exact-reader-served-and-freeze-originals40.v1.tar.gz';a['evidence_pins']['reader_served40_archive']=ident(served)
    assert a['authorization']=='PREPARED_ONLY_NOT_AUTHORIZED'
    # Reuse only the existing data validator. It hashes/reads existing evidence and gate receipts; no action, API, guard snapshot, Lean or browser.
    x=evidence_inputs(a)
    assert git('prepared-v2-HEAD','rev-parse','HEAD').decode().strip()==a['carrier_commit'] and git('prepared-v2-branch','symbolic-ref','HEAD').decode().strip()==a['expected_branch']
    assert file_sha(REPO/CELL)==a['expected_target_cell_sha256']
    araw=(REPO/ADVPATH).read_bytes();draw=(REPO/DISCPATH).read_bytes();records,_,adv,_=replay(araw,draw);rows=[r for r in records if r.get('advance_id')==ADV]
    assert adv[ADV]['state']=='PROVED_LOCAL' and adv[ADV]['owner_id']==OWNER and adv[ADV]['publication_declarations']==[P]
    assert sum(r.get('to_state')=='PROVED_LOCAL' for r in rows)==1 and not any(r.get('to_state')=='VERIFIED' for r in rows)
    assert next(r['evidence'] for r in rows if r.get('to_state')=='PROVED_LOCAL')==x['pl'] and sha((OWN/'PROVED_LOCAL-original24.exact.json').read_bytes())==PLSHA
    write(OWN/'window1.authorization.draft.v2.json',a)
    second=copy.deepcopy(a);second.update({'authorized_action':'TARGET_CELL_PROJECTION_ONCE','normal_API_calls_authorized':0,'window1_outcome':{'file':'ROOT_PENDING_REAL_WINDOW1_OUTCOME','sha256':'ROOT_PENDING_REAL_WINDOW1_OUTCOME_SHA256'},'expected_advance_ledger_sha256':'ROOT_PENDING_REAL_WINDOW1_AFTER_LEDGER_SHA256','expected_discovery_ledger_sha256':'ROOT_PENDING_FRESH_DISCOVERY_LEDGER_SHA256'})
    write(OWN/'window2.authorization.draft.v2.json',second)
    for n in ['authorization.schema.json','gate-summary.schema.json']:read(OWN/n)
    tree=ast.parse((OWN/'verification_driver.py').read_text());assert len([n for n in ast.walk(tree) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='transition_advance'])==1
    assert not (PRIVATE/'normal-V-attempted.once.json').exists() and not (PRIVATE/'target-cell-attempted.once.json').exists()
    assert not any((PRIVATE/n).exists() for n in ['window1-before','window1-after','window2-before','window2-after','window1-OS-process','window2-OS-process'])
    assert all(stat.S_IMODE(p.stat().st_mode)==0o700 for p in [PRIVATE,*[p for p in PRIVATE.rglob('*') if p.is_dir()]])
    assert all(stat.S_IMODE(p.stat().st_mode)==0o600 for p in PRIVATE.rglob('*') if p.is_file())
    write(OWN/'preparation-final.contract.v2.json',{'status':'PREPARED_ONLY_NO_ACTION_AUTHORIZED_OR_EXECUTED','advance_id':ADV,'verifier_id':VERIFIER,'PL':1,'V':0,'original24_inline_retention_contract_unchanged':True,'original_PL_SHA256':PLSHA,'original_exact_PL_append_SHA256':PLAPPENDSHA,'source_carrier':a['carrier_commit'],'exact_target_cell_sha256':a['expected_target_cell_sha256'],'new_actual_six_gate_summary':a['gate_summary'],'new_six_gates_verified_receipt_and_log_exit0_at_exact_carrier':True,'source_binding':BINDING,'actual_native_build_identity':MATH,'no_new_build_source_audit_reader_run_or_proofV_claim':True,'scripts':a['scripts'],'private_permissions':{'root_and_all_subdirs_octal':'0700','all_private_files_octal':'0600','driver_parent_and_child_umask':'077','preexisting_private_file_bytes_unchanged':True,'preexisting_private_files_checked':len(before_files),'raw_private_maps_not_public':True},'permission_only_change_diff':ident(OWN/'permission-process-only.v2.diff'),'pre_permission_sources_byte_exact_directory':'preparation-source-before-permission-v2','HOME':'Child whitelist retains original user HOME /Users/zhouhuanjian; never uses task directory.','ATLAS_boundary':'ASTIS_ATLAS_ROOT is only a known literal path reference. This role never reads/copies ATLAS contents or index.','normal_action_contract':'Distinct ROOT authorization file+SHA required for each action. Normal V has durable once-marker, sole real transition, actual suffix inspection on exception, strict postguards, no retry/rollback/window2 auto-launch. Window2 needs actual successful window1 outcome and a separate authorization plus fresh full guards.','public_evidence_policy':'After an actual action, explicit public manifest includes only bounded summary/postguard reports, exact target append and inline payload, safe exact OS receipt copy and own scripts/original24; all raw API streams, complete ledgers/index/full guard/foreign maps remain local-private. Exact receipt includes only explicit whitelist HOME/PATH/locale/Python/Git/ASTIS path; no inherited environment secrets.','window1_draft':ident(OWN/'window1.authorization.draft.v2.json'),'window2_draft':ident(OWN/'window2.authorization.draft.v2.json'),'normal_API_calls':0,'target_cell_writes':0})
    print(json.dumps({'status':'PREPARED_ONLY_PRIVATE_PERMISSIONS_FIXED','normal_API_calls':0,'target_cell_writes':0,'driver_sha256':file_sha(OWN/'verification_driver.py'),'common_sha256':file_sha(OWN/'verification_common.py'),'contract_sha256':file_sha(OWN/'preparation-final.contract.v2.json'),'window1_draft_sha256':file_sha(OWN/'window1.authorization.draft.v2.json'),'window2_draft_sha256':file_sha(OWN/'window2.authorization.draft.v2.json')}))

if __name__=='__main__':
    os.umask(0o077)
    before_files={str(p):{'sha256':file_sha(p),'mode':oct(stat.S_IMODE(p.stat().st_mode))} for p in PRIVATE.rglob('*') if p.is_file()}
    before_dirs={str(p):oct(stat.S_IMODE(p.stat().st_mode)) for p in [PRIVATE,*[p for p in PRIVATE.rglob('*') if p.is_dir()]]}
    private_dir(PRIVATE/'preparation-v2-permission-process');directory=PRIVATE/'preparation-v2-permission-process';out=directory/'stdout.raw';err=directory/'stderr.raw';start=time.monotonic();started=dt.datetime.now(dt.timezone.utc).isoformat();code=0
    for fd,p in [(1,out),(2,err)]:
        f=p.open('xb',buffering=0);os.fchmod(f.fileno(),0o600);os.dup2(f.fileno(),fd);f.close()
    try:main(before_files,before_dirs)
    except BaseException:traceback.print_exc();code=1
    sys.stdout.flush();sys.stderr.flush()
    receipt={'schema':'r16-local-permission-and-readonly-prepare-v2-actual-OS-receipt-v1','argv':[sys.executable,*sys.argv],'cwd':str(REPO),'pid':os.getpid(),'started_utc':started,'ended_utc':dt.datetime.now(dt.timezone.utc).isoformat(),'elapsed_seconds':time.monotonic()-start,'actual_exit_code':code,'stdout_sha256':file_sha(out),'stderr_sha256':file_sha(err),'raw_streams_private':True,'script_sha256':file_sha(__file__),'driver_or_action_executed':False,'normal_API_calls':0,'target_cell_writes':0}
    write(directory/'receipt.private.json',receipt);write(OWN/'preparation-v2-OS-receipt.public.json',receipt);sys.exit(code)
