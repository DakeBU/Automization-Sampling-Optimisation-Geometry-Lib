"""Deep exact-byte archive and final reader evidence inspection; no experiment replay."""
import io,json,tarfile
from guard import *
from evidence_preflight import N,HELD,verify_archive

expected={
 'final-native-reader-closure.json':'1459c72b4ab63e012ef06ebbfec773ed6e1301344dbb0b086838a1e31f60629e',
 'reader/C3-bounded-acceptance.json':'4ace0a1bf4af5e0652aea3d1e325b7f14c29d190ef89dbbbbf7682f3b5812226',
 'selected-native-reader-originals.lossless.tar.gz':'758996d2b885c394edc8acc6cb45300cfacc35deea362f784343fb6225bf02d0',
 'selected-native-reader-originals.manifest.json':'9e891739cbe2247b579225e6e4dbc8c7c5c70e05fdca8de5fc14dfc63038d0d4',
 'selected-native-reader-archive-closed.json':'404cb895810f0d94bfc250efc31ac3693b3525d2439518281633f13c0f1b3b7b',
 'reader/wording-qualification.json':'7cc7d62dea834aac4b231dbaa9f20b53df7f7a32f23bb55b1422782e27d24c31'}
for path,digest in expected.items(): assert sha((N/path).read_bytes())==digest
assert git('rev-parse','HEAD').decode().strip()==HELD
closure=read(N/'final-native-reader-closure.json');judgment=read(N/'reader/C3-bounded-acceptance.json')
assert closure['metadata_held_HEAD']==HELD and closure['metadata_base']==BASE
assert closure['reader']['independent_actual_C3_v2_accepted'] and judgment['visual_review']['accepted']
assert closure['reader']['candidate_CSS_globally_applied'] is False and closure['reader']['shared_production_CSS_untouched']
assert closure['four_final_metadata_gates']['all_passed'] and closure['four_final_metadata_gates']['actual_runs']==4
for info in closure['artifacts'].values():
    p=ROOT/info['path'];assert p.stat().st_size==info['bytes'] and sha(p.read_bytes())==info['sha256']
manifest=read(N/'selected-native-reader-originals.manifest.json');assert len(manifest['files'])==364
for path,info in manifest['files'].items():
    p=N/path;assert p.stat().st_size==info['bytes'] and sha(p.read_bytes())==info['sha256']
archive=N/'selected-native-reader-originals.lossless.tar.gz'
assert archive.stat().st_size==12617237
count=verify_archive(archive,manifest['files'],{
 'selected-native-reader-originals.manifest.json':(N/'selected-native-reader-originals.manifest.json').read_bytes()})
assert count==365
forbidden={'all_foreign_states','all_existing_tracked_fingerprints','actual_control_fingerprints',
           'tracked_git_index','advance_states','discovery_states','index_exact'}
def no_maps(obj):
    if isinstance(obj,dict):
        assert not set(obj)&forbidden,'private map in selected portable JSON'
        for x in obj.values():no_maps(x)
    elif isinstance(obj,list):
        for x in obj:no_maps(x)
archives=[];regular_count=0
def inspect(name,raw):
    global regular_count
    assert not Path(name).is_absolute() and '..' not in Path(name).parts
    assert not any('.private.' in p or p.startswith('.PRIVATE') for p in Path(name).parts)
    if name.endswith('.json'):no_maps(json.loads(raw))
    if name.endswith('.tar.gz'):
        archives.append({'name':name,'sha256':sha(raw)})
        with tarfile.open(fileobj=io.BytesIO(raw),mode='r:gz') as tf:
            ms=tf.getmembers();ns=[m.name for m in ms]
            assert len(ns)==len(set(ns)) and all(m.isfile() for m in ms)
            for m in ms:regular_count+=1;inspect(m.name,tf.extractfile(m).read())
inspect(archive.name,archive.read_bytes())
native_archives=[a for a in archives if a['sha256']=='53c96b82231e9576995755cc7cae794ae7b3ccbbb08193df78f470ae1fc2c8ea']
assert len(native_archives)==1 and len(archives)==2
report_path=N/'reader/browser-source-scroll-v2/report.json';report_raw=report_path.read_bytes();r=json.loads(report_raw)
assert sha(report_raw)==judgment['actual_ROOT_execution']['report_sha256']==closure['reader']['actual_ROOT_v2_report_sha256']
receipt_path=Path(judgment['actual_ROOT_execution']['receipt']);receipt=read(receipt_path)
assert sha(receipt_path.read_bytes())==judgment['actual_ROOT_execution']['receipt_sha256']
assert receipt['exit']==0 and receipt['HEAD']==HELD
assert not receipt_path.with_suffix('.stderr').read_bytes()
assert sha(receipt_path.with_suffix('.stdout').read_bytes())==receipt['stdout_sha256']
assert r['site_manifest_sha256']==r['site_manifest_sha256_after']=='a12af8c19a0f1323343e9cbd578d28e68ab1c745386b20db44aaf7398fa35985'
assert r['C2_reference_manifest_sha256']==r['C2_reference_manifest_sha256_after']=='95caac242f6d7f6884337815623ab203fabe117cd4f007116084b5743016cbf0'
for field,count_expected in [('contexts',4),('source_checks',12),('graph_checks',2),('source_anchor_placement',8),('formula_scroll_checks',2),('C2_source_reference',4),('source_pre_scroll_checks',4)]:
    assert len(r[field])==count_expected
for field in ['page_errors','failed_requests','http_errors','layout_failures']:assert not r[field]
assert r['server_thread_joined'] and r['reference_server_thread_joined'] and not r['CSS_globally_applied']
for anchor in r['source_anchor_placement']:
    assert anchor['unobscured_certification'] and not anchor['overlap'] and anchor['lineTop']>=anchor['headerBottom']
scroll=[]
for m in r['source_pre_scroll_checks']:
    assert m['overflowX']=='auto' and m['rightmost_long_line_glyph_visible_at_max']
    assert m['left']>=-1 and m['right']<=m['viewport']+1
    if m['possibleMax']>1:assert m['scrollLeftAfter100']==100 and abs(m['scrollLeftAtMax']-m['possibleMax'])<=1
    g=m['long_line_visible_geometry'];a=m['explicit_window_alignment']
    assert g['right']<=m['right']+2 and g['right']>=m['left']-2
    assert g['top']>=a['headerBottom'] and g['bottom']<=a['actualViewportHeight']
    scroll.append({'source':m['source'],'viewport':m['viewport'],'scroll100':m['scrollLeftAfter100'],
                   'scrollMAX':m['scrollLeftAtMax'],'right_glyph':g['right'],'glyph_top':g['top'],
                   'header_bottom':a['headerBottom'],'visible_below_header_and_within_viewport':True})
for p in judgment['visual_review']['actual_saved_PNGs_independently_viewed']:
    assert sha((N/p['path']).read_bytes())==p['sha256']
assert sha((ROOT/'website/static/proof-readers.css').read_bytes())==judgment['shared_production_CSS_sha256']['proof-readers.css']
assert sha((ROOT/'website/static/source-lineage.css').read_bytes())==judgment['shared_production_CSS_sha256']['source-lineage.css']
create(O/'peer-wording-qualification.json',(N/'reader/wording-qualification.json').read_bytes())
selected=[]
for name in closure['proposed_small_carrier_allowlist']:
    p=N/name
    selected.append({'path':str(p.relative_to(ROOT)),'portable_name':name,'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())})
assert len(selected)==7
create(O/'packaging-inputs.json',dump({'native_reader_selected_inputs':selected,
 'native_seven_path_carrier_exact':True,'separate_wording_qualification':'peer-wording-qualification.json',
 'exact_native_reader_archive_occurrences':1,'full_private_maps_exported':False}))
out={'status':'PASS','held_HEAD':HELD,'native_reader_archive_sha256':sha(archive.read_bytes()),
 'native_reader_archive_bytes':archive.stat().st_size,'native_reader_archive_members':count,
 'recursive_regular_members_checked':regular_count,'exact_native_archive_occurrences':1,
 'all_top_and_nested_archive_paths_and_payload_bytes_checked':True,'recursive_private_map_scan':'PASS',
 'actual_C3_v2_report_sha256':sha(report_raw),'actual_checker_exit':0,'original_C2_failed_C3_preserved':True,
 'four_actual_gates_reused_without_replay':True,'actual_source_pre_scroll_scope':scroll,
 'normal_verifier_saved_PNG_review':['390-context0-P-long-line-right.png','390-context0-T-long-line-right.png'],
 'frozen_wording_qualification':'y413 is below and clear of header bottom60.42; frozen artifacts unchanged',
 'candidate_CSS_globally_applied':False,'shared_CSS_unchanged':True,
 'remaining_scope':'Bounded owned reader/native/source local verification only; global production delivery/integration/purification/probabilities/full C6/whole Goal remain HOLD.',
 'normal_VERIFIED_calls':0,'tracked_edits':False,'full_private_maps_exported':False}
create(O/'final-reader-and-package-check.bounded.json',dump(out))
print(json.dumps(out,indent=2))
