import pathlib,json,hashlib,os,datetime,stat,sys
D=pathlib.Path(__file__).resolve().parent
start=datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(b): return hashlib.sha256(b).hexdigest()
def dump(path,value): path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
assert not (D/'manifest.json').exists() and not (D/'freeze.receipt.json').exists()
symlinks=[{'path':str(p.relative_to(D)),'target':os.readlink(p)} for p in D.rglob('*') if p.is_symlink()]
assert not symlinks
assert json.loads((D/'judgment.json').read_text())['native_judgment']=='PASS within exact candidate scope'
(D/'freeze.log').write_text('Freeze preflight: assigned directory only. No symlinks. Bounded judgment present. Raw file hashes follow in manifest.json.\n')
raw=[p for p in sorted(D.rglob('*')) if p.is_file() and p.name not in {'manifest.json','freeze.receipt.json'}]
rows=[{'path':str(p.relative_to(D)),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes()),'frozen_mode':'0444'} for p in raw]
manifest={'schema':1,'candidate':'eed870294de059136900110ade59b4a292a126ad','raw_file_count':len(rows),'raw_files':rows,'symlinks':symlinks,'hash_cycle_avoidance':'manifest.json and freeze.receipt.json are not raw hash entries. Receipt hashes manifest; neither document hashes itself.','complete_file_listing':sorted([r['path'] for r in rows]+['manifest.json','freeze.receipt.json'])}
dump(D/'manifest.json',manifest)
for p in raw+[D/'manifest.json']: p.chmod(0o444)
for row in rows:
 p=D/row['path']; assert stat.S_IMODE(p.stat().st_mode)==0o444 and sha(p.read_bytes())==row['sha256']
receipt={'schema':1,'argv':sys.argv,'cwd':os.getcwd(),'start':start,'end':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':0,'raw_files_frozen_and_rehashed':len(rows),'all_raw_modes_checked':'0444','manifest_mode_checked':oct(stat.S_IMODE((D/'manifest.json').stat().st_mode)),'manifest_bytes':(D/'manifest.json').stat().st_size,'manifest_sha256':sha((D/'manifest.json').read_bytes()),'receipt_self_mode_target':'0444','scope':'Final local evidence freeze only; no sourceV/VERIFIED/global/public/PURIFIED/Goal transition.'}
dump(D/'freeze.receipt.json',receipt); (D/'freeze.receipt.json').chmod(0o444)
assert stat.S_IMODE((D/'freeze.receipt.json').stat().st_mode)==0o444
print(json.dumps({'raw_files':len(rows),'complete_files':len(manifest['complete_file_listing']),'manifest_sha256':receipt['manifest_sha256'],'receipt_sha256':sha((D/'freeze.receipt.json').read_bytes()),'all_modes':'0444'}))
