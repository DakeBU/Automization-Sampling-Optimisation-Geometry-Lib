"""Independent raw-source authoring only. Reads only this agent's raw extraction."""
from pathlib import Path
from hashlib import sha256
import json

OWN = Path('/Users/zhouhuanjian/ASTIS-GC/.astis/semantic-neutral-20261110/cg_sg_1d7a46')
P = OWN / 'phase1'
idx = json.loads((P / 'source_index.json').read_text())
byid = {x['id']: x for x in idx['items']}

def dump(name, value):
    (P / name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')

nodes = []
def node(ident, kind, statement, anchors, scope='deterministic-core', **kw):
    for a in anchors:
        assert a in byid, a
    nodes.append(dict(id=ident, kind=kind, scope=scope, statement=statement,
                      anchors=anchors, formal_status='SOURCE_ONLY_UNCHECKED', **kw))

node('domain','standing-domain','d is an integer dimension, q is a nonnegative integer query budget, and 2q+1<d. Thus d>=2, r=q+1>=1, 2r<=d; q=0 is allowed.',
     ['S4.SS1.p1.m3','S4.Thmtheorem3.p1.1','S4.Thmtheorem4.p1.m2','S4.Thmtheorem4.p1.m3','A3.SS2.p1.m1'])
node('theta','literal-definition','For 1<=i<=d, theta_i=(i-1/2)pi/d. Only the theta clause of Eq. (11) is an active ancestor of the deterministic roots.',
     ['S4.E11.m1','A3.SS2.p4.m2'])
node('rn','literal-definition','r=q+1; n=2q+1.', ['A3.SS2.p1.m1','A3.SS2.p1.m2','S4.Ex12.m1'])
node('frame','literal-definition','t_i has coordinates indexed j=0,...,q: (t_i)_0=1 and (t_i)_j=sqrt(2) cos(j theta_i) for 1<=j<=q.',
     ['A3.Ex85.m1','A3.SS2.p5.m1','A3.SS2.p5.m2'])
node('D','literal-definition','D_n=diag(cos(n theta_1),...,cos(n theta_d)).', ['S4.Ex12.m1'])
node('trig.sine-difference','implicit-uncited-primitive','2 sin(h/2) cos(x-h/2)=sin(x)-sin(x-h); used at h=k pi/d, x=k i pi/d.',
     ['A3.Ex88.m1','A3.Ex88.m2'], external_classification='local-lemma', source_proves_primitive=False)
node('finite.telescope','implicit-uncited-primitive','A finite sum of consecutive differences telescopes; finite real sums distribute over scalar multiplication.',
     ['A3.Ex88.m2','A3.Ex89.m1'], external_classification='local-lemma', source_proves_primitive=False)
node('trig.integer-endpoints','implicit-uncited-primitive','For integer k, sin(k pi)=sin(0)=0.',
     ['A3.Ex89.m1'], external_classification='local-lemma', source_proves_primitive=False)
node('trig.nonzero','implicit-uncited-primitive','If k is integer and 0<|k|<2d, sin(k pi/(2d)) is nonzero: its argument lies strictly between -pi and pi and is not zero.',
     ['A3.SS2.p4.m3','A3.SS2.p4.m4','A3.SS2.p4.m5'], external_classification='local-lemma', source_proves_primitive=False)
node('cosine.telescope','author-proof-step','For integer k with 0<|k|<2d, 2 sin(k pi/(2d)) sum_i cos(k theta_i)=sum_i[sin(k i pi/d)-sin(k(i-1)pi/d)]=sin(k pi)-sin(0)=0.',
     ['A3.EGx5','A3.Ex88','A3.Ex89'])
node('cosine.zero','author-proof-step','For every integer k with 0<|k|<2d, sum_{i=1}^d cos(k theta_i)=0, by cancelling the nonzero sine factor.',
     ['A3.SS2.p4.2','A3.SS2.p4.m6'])
node('trig.product-to-sum','implicit-uncited-primitive','2 cos(x)cos(y)=cos(x-y)+cos(x+y). The four-term triple-product expansion follows by two applications.',
     ['A3.SS2.p5.2','A3.Ex92.m1','A3.Ex98.m2'], external_classification='local-lemma', source_proves_primitive=False)
node('trig.zero-angle','implicit-uncited-primitive','cos(0)=1. Consequently a zero-frequency finite cosine sum is d, and zero-coordinate triple products fit the same formula.',
     ['A3.Ex93.m1','A3.SS2.p7.3'], external_classification='local-lemma', source_proves_primitive=False)
node('linear.entry-algebra','implicit-uncited-primitive','An outer product has (j,k) entry t_j t_k; finite matrix sums act entrywise; multiplication of reals is symmetric; equality of all entries proves matrix equality.',
     ['A3.Ex90.m1','A3.SS2.p5.3','A3.SS2.p7.3'], external_classification='local-lemma', source_proves_primitive=False)
node('algebra.scalar-cancel','implicit-uncited-primitive','Over the reals, a nonzero scalar times a quantity equals zero only if that quantity equals zero.',
     ['A3.SS2.p4.2'], external_classification='local-lemma', source_proves_primitive=False)
node('algebra.sqrt-two','implicit-uncited-primitive','The real normalization satisfies (sqrt(2))^2=2; this converts the product/square of two positive-coordinate scalings into the exact factor 2.',
     ['A3.Ex85.m1','A3.Ex91.m2','A3.Ex102.m1'], external_classification='local-lemma', source_proves_primitive=False)
node('gram.constant-entries','author-proof-step','sum_i (t_i)_0^2=d; for 1<=j<=q, sum_i(t_i)_0(t_i)_j=sqrt(2)sum_i cos(j theta_i)=0. Symmetry gives the transposed entries.',
     ['A3.Ex90','A3.Ex90.m1'])
node('gram.frequency-window','author-proof-step','For 1<=j,k<=q, 0<j+k<=2q<2d; j-k=0 iff j=k, and otherwise 0<|j-k|<2d.',
     ['A3.SS2.p5.3','A3.SS2.p5.m4','A3.SS2.p5.m5','A3.SS2.p5.m6','A3.SS2.p5.m7'])
node('gram.nonconstant-entries','author-proof-step','For 1<=j,k<=q, sum_i(t_i)_j(t_i)_k=sum_i cos((j-k)theta_i)+sum_i cos((j+k)theta_i), equal to d when j=k and zero otherwise.',
     ['A3.EGx6','A3.Ex91','A3.Ex92','A3.Ex93'])
node('det.unweighted','bounded-root','sum_{i=1}^d t_i t_i^T=d I_r; all entries are covered by the constant-coordinate cases, positive-coordinate cases and symmetry.',
     ['A3.Ex87.m1','A3.SS2.p5.m8','A3.SS2.p5.3'])
node('weighted.frequency-window','author-proof-step','For 0<=j,k<=q, each integer n+j+k,n+j-k,n-j+k,n-j-k lies in [1,4q+1] and 4q+1<2d.',
     ['A3.SS2.p7.m2','A3.SS2.p7.m3','A3.Ex96','A3.Ex96.m1'])
node('weighted.triple-expansion','author-proof-step','sum_i cos(n theta_i)cos(j theta_i)cos(k theta_i) is one quarter of the sum of the four cosine sums with frequencies n+j+k,n+j-k,n-j+k,n-j-k.',
     ['A3.EGx8','A3.Ex97','A3.Ex98'])
node('weighted.triple-zero','author-proof-step','For 0<=j,k<=q, every one of those four cosine sums vanishes, so the triple-product sum is zero.',
     ['A3.Ex99','A3.SS2.p7.2'])
node('det.weighted','bounded-root','sum_i cos(n theta_i)t_i t_i^T=0. An entry is s_j s_k times the triple-product sum, with s_0=1 and s_j=sqrt(2) for j>=1; cos(0 theta_i)=1 covers all zero-coordinate cases.',
     ['A3.Ex87.m1','A3.SS2.p7.3','A3.SS2.p7.m4','A3.SS2.p7.m5'])
node('trig.cosine-square-bound','implicit-uncited-primitive','For real x, cos(x)^2<=1. The Euclidean squared norm is the sum of squared coordinates.',
     ['A3.Ex102.m1'], external_classification='local-lemma', source_proves_primitive=False)
node('det.row-norm','bounded-root','For every row i, ||t_i||^2=1+2 sum_{j=1}^q cos^2(j theta_i)<=1+2q<=2r.',
     ['A3.Ex87.m1','A3.Ex102','A3.Ex102.m1'])
node('gaussian.input','standing-consumer-input','g_1,...,g_r are independent N(0,I_d) vectors. gamma_i=((g_1)_i,...,(g_r)_i)^T; the raw source states that gamma_1,...,gamma_d are independent N(0,I_r).',
     ['S4.Thmtheorem4.p1.m4','S4.Thmtheorem4.p1.m5','A3.Ex85.m1','A3.SS2.p1.2'], scope='private-gaussian-consumer')
node('B','literal-consumer-definition','B is d by r^2 with row i equal to d^{-1/2}(gamma_i tensor t_i)^T. The Gaussian index is the first Kronecker factor and the cosine coordinate is the second.',
     ['A3.SS2.p1.m6','A3.SS2.p1.m7','A3.SS2.p1.m8'], scope='private-gaussian-consumer')
node('gaussian.second-moment','implicit-uncited-consumer-primitive','E[gamma_i gamma_i^T]=I_r. These entries are integrable from finite Gaussian second moments. Row independence is not used in either expectation identity.',
     ['A3.SS2.p6.m1'], scope='private-gaussian-consumer', external_classification='local-lemma', source_proves_primitive=False)
node('matrix.expectation-algebra','implicit-uncited-consumer-primitive','B^TWB is the finite sum of weighted row outer products; (gamma tensor t)(gamma tensor t)^T=(gamma gamma^T) tensor (t t^T). Entrywise expectation is linear over integrable finite sums, deterministic factors pull out, and I_r tensor I_r=I_{r^2}.',
     ['A3.Ex94.m2','A3.Ex95.m1','A3.Ex100.m2','A3.Ex101.m1'], scope='private-gaussian-consumer', external_classification='local-lemma', source_proves_primitive=False)
node('consumer.expected-unweighted','source-private-consumer','E[B^TB]=(1/d)sum_i(E[gamma_i gamma_i^T] tensor t_i t_i^T)=(1/d)(I_r tensor sum_i t_i t_i^T)=I_{r^2}.',
     ['A3.Ex86.m1','A3.SS2.p4.m1','A3.EGx7','A3.Ex94','A3.Ex95'], scope='private-gaussian-consumer')
node('consumer.expected-weighted','source-private-consumer','E[B^TD_n B]=(1/d)sum_i cos(n theta_i)(E[gamma_i gamma_i^T] tensor t_i t_i^T)=(1/d)(I_r tensor sum_i cos(n theta_i)t_i t_i^T)=0.',
     ['A3.Ex86.m1','A3.SS2.p7.m1','A3.EGx9','A3.Ex100','A3.Ex101'], scope='private-gaussian-consumer')
node('statement.C5.partition','coverage-partition','Fact C.5 contains six conclusion clauses: three deterministic roots, two Gaussian second-moment consumers, and a range(B)=K_q clause that is explicitly outside this packet. This partition node does not assert proof completion of Fact C.5.',
     ['A3.Thmtheorem5','A3.Thmtheorem5.p1','A3.Ex86','A3.Ex87'], scope='coverage-only')

edges = []
def edge(parents, child, use, detail):
    for a in use:
        assert a in byid, a
    edges.append({'parents':parents,'consumer':child,'logic':'AND','consumer_use_sites':use,'discharge':detail})

edge(['domain'],'theta',['S4.E11.m1'],'Positive nonzero integer dimension makes the midpoint grid defined; no kappa value enters theta.')
edge(['domain'],'rn',['A3.SS2.p1.m1','A3.SS2.p1.m2'],'Defines positive r and odd positive n from the inherited integer query budget.')
edge(['rn','theta'],'frame',['A3.Ex85.m1'],'The displayed vector has exactly q+1 real coordinates.')
edge(['rn','theta'],'D',['S4.Ex12.m1'],'Each diagonal entry uses the same grid and n.')
edge(['domain','theta','trig.sine-difference','finite.telescope','trig.integer-endpoints'],'cosine.telescope',['A3.Ex88.m1','A3.Ex88.m2','A3.Ex89.m1'],'The restricted integer k is not an extra premise of a root; it is locally quantified here and instantiated downstream.')
edge(['cosine.telescope','trig.nonzero','algebra.scalar-cancel'],'cosine.zero',['A3.SS2.p4.2'],'The local 0<|k|<2d premise is discharged at every downstream frequency. Cancel a proved nonzero real sine factor.')
edge(['domain','rn','frame','cosine.zero'],'gram.constant-entries',['A3.Ex90.m1'],'For 1<=j<=q, 0<j<2d; for the (0,0) entry sum of d ones is d.')
edge(['domain'],'gram.frequency-window',['A3.SS2.p5.3'],'Uses 1<=j,k<=q and 2q+1<d; equality case j=k is separated rather than fed to nonzero-frequency cancellation.')
edge(['frame','algebra.sqrt-two','trig.product-to-sum','trig.zero-angle','gram.frequency-window','cosine.zero'],'gram.nonconstant-entries',['A3.Ex91.m2','A3.Ex92.m1','A3.Ex93.m1'],'j+k is always positive; j-k is either zero with cosine sum d or a nonzero frequency in the allowed window.')
edge(['gram.constant-entries','gram.nonconstant-entries','linear.entry-algebra'],'det.unweighted',['A3.SS2.p5.3','A3.SS2.p5.m8'],'All entries, including transposes of constant-coordinate entries, are covered; ordinary entrywise matrix extensionality is implicit.')
edge(['domain','rn'],'weighted.frequency-window',['A3.Ex96.m1'],'n-j-k>=2q+1-2q=1. n+j+k<=4q+1<2d follows from 2q+1<d. The bounds also cover j=0 and/or k=0.')
edge(['theta','trig.product-to-sum'],'weighted.triple-expansion',['A3.Ex97.m1','A3.Ex98.m2'],'Apply the two-cosine identity twice; the coefficient is exactly 1/4, with all four sign combinations as displayed.')
edge(['weighted.triple-expansion','weighted.frequency-window','cosine.zero'],'weighted.triple-zero',['A3.Ex99.m2'],'Each of the four frequencies is a positive integer strictly below 2d, so no constant term survives.')
edge(['frame','weighted.triple-zero','trig.zero-angle','linear.entry-algebra'],'det.weighted',['A3.SS2.p7.3'],'The entrywise scaling is 1, sqrt(2), or 2 according to whether zero, one, or both coordinates are positive. All are constant multiples of zero; no additional stochastic input.')
edge(['rn','frame','algebra.sqrt-two','trig.cosine-square-bound'],'det.row-norm',['A3.Ex102.m1'],'The q positive-frequency terms each contribute at most 2, and 1+2q<=2(q+1). Empty sum q=0 is valid.')
edge(['gaussian.input'],'gaussian.second-moment',['A3.SS2.p6.m1'],'The standard Gaussian covariance and zero mean give the entrywise identity and finite second moments; no concentration event or rowwise independence is a premise.')
edge(['domain','frame','gaussian.input'],'B',['A3.SS2.p1.2'],'The d^{-1/2} factor is nonzero and well-defined because d>=2. The product index has r^2 entries.')
edge(['B','gaussian.second-moment','matrix.expectation-algebra','det.unweighted'],'consumer.expected-unweighted',['A3.Ex94.m2','A3.Ex95.m1'],'Gaussian second moments supply all integrability. Substitute dI_r for the deterministic sum and cancel d.')
edge(['B','D','gaussian.second-moment','matrix.expectation-algebra','det.weighted'],'consumer.expected-weighted',['A3.Ex100.m2','A3.Ex101.m1'],'Replace the deterministic weighted Gram by zero. The weight is precisely the diagonal of D_n.')

outs = [
 {'id':'outside.range','anchors':['A3.SS2.p3','A3.SS2.p3.m1','A3.SS2.p3.m3','S4.Ex10.m1','S4.SS2.SSS0.Px2.p2'],
  'reason':'Range(B)=K_q is a separate Chebyshev triangular change-of-basis branch. It uses the nonconstant affine lambda(cos theta), kappa>=2, degree/nonzero-leading-coefficient facts and invariance of column span under nonzero normalizations. None is established by the three deterministic Gram roots.'},
 {'id':'outside.C6','anchors':['A3.Thmtheorem6','A3.SS2.3'],
  'reason':'Simultaneous matrix concentration is downstream and excluded, including truncation, bias, Gaussian fourth moments, PSD estimates, Bernstein, union bounds and constant simplification. It is not certified by this packet.'},
 {'id':'outside.lemma4.4','anchors':['S4.Thmtheorem4','A3.SS2.4'],
  'reason':'The full probabilistic uniform Krylov bound requires both the range branch and C.6; tau<=1/2 is only a premise for this later conversion, not for deterministic C.5 or Gaussian second moments.'},
 {'id':'outside.output-representation','anchors':['S4.Thmtheorem3','S4.Ex11'],
  'reason':'Adaptive output representation and its rotation/test-statistic consequence depend on Lemma 4.3 and the full Lemma 4.4; not a deterministic Gram identity.'},
 {'id':'outside.main-results','anchors':['S4.SS1','S4.SS2.SSS0.Px2'],
  'reason':'Neither main theorem, nor full Lemma 4.4, nor C.6, nor Range(B)=K_q receives completion or formalization credit from this source-only artifact.'},
 {'id':'outside.rotated-statistic','anchors':['S4.SS2.SSS0.Px2.p3','S4.Ex15'],
  'reason':'The rotated output statistic follows from both the excluded algorithm-output representation and the full excluded Lemma 4.4, using orthogonality of O. It is a distinct downstream consequence, not an ancestor of any deterministic Gram root.'}
]
downstream = [
 {'parents':['det.unweighted','det.weighted'],'consumer':'outside.C6','use_sites':['A3.SS2.p12.4','A3.Ex110.m1'],'meaning':'For the radially truncated second moment aI_r, the two deterministic identities give sum E Y_i=aI and sum cos(n theta_i) E Y_i=0.'},
 {'parents':['det.row-norm'],'consumer':'outside.C6','use_sites':['A3.SS2.p13.1','A3.Ex111.m1'],'meaning':'Bounds on truncated/expected summand operator norm use ||t_i||^2<=2r.'},
 {'parents':['det.row-norm','det.unweighted'],'consumer':'outside.C6','use_sites':['A3.Ex115.m2','A3.Ex116.m1','A3.Ex117.m1','A3.SS2.p14.4'],'meaning':'Variance estimate combines Gaussian fourth moment r+2 with the norm bound and deterministic unweighted Gram.'},
 {'parents':['consumer.expected-unweighted','consumer.expected-weighted'],'consumer':'outside.C6','use_sites':['A3.SS2.p17.1','A3.Ex125.m1'],'meaning':'Original-vs-truncated sum identities use their expected centers; the C.6 proof also explicitly recomputes truncated expectations.'},
 {'parents':['outside.range','outside.C6'],'consumer':'outside.lemma4.4','use_sites':['A3.SS2.p19.2','A3.Ex130.m2','A3.Ex131.m2','A3.Ex132.m1'],'meaning':'On the shared concentration event choose u=Bc, control denominator by 1-tau, use tau<=1/2. This remains outside the bounded roots.'},
 {'parents':['outside.lemma4.4','outside.output-representation'],'consumer':'outside.rotated-statistic','use_sites':['S4.Ex15.m1'],'meaning':'Use O^T X in K_q and norm preservation under O to obtain the displayed output statistic. This contextual edge is not a completion claim.'}
]

# Exact one-disposition inventory over every ID in all bounded raw windows.
# Composite raw equations are partitioned explicitly rather than granting the
# excluded range clause credit through a mixed display.
coverage = []
def disposition(item):
    ident = item['id']
    tag = item['tag']
    # Formatting spans and titles never acquire independent mathematical credit.
    if tag in ['span','em']:
        return ('EXCLUDED', [], 'Formatting/typography wrapper; its enclosing paragraph/display and every descendant math ID are separately inventoried.')
    if ident in ['A3.SS2','A3.SS2.2']:
        return ('EXCLUDED', [], 'Structural source container only. All descendant mathematical items are separately inventoried; no whole-section or whole-proof completion claim.')
    if ident.startswith('A3.SS2.p3'):
        return ('EXCLUDED', [], outs[0]['reason'])
    if ident.startswith('A3.SS2.p2'):
        return ('EXCLUDED', [], 'Full Lemma 4.4 proof strategy and range/concentration announcement; contextual prose, not a proof of the bounded deterministic roots.')
    if ident.startswith('A3.SS2.p9') or ident in ['A3.Thmtheorem6','A3.SS2.3'] or any(ident.startswith('A3.SS2.p'+str(i)) for i in range(10,19)) or ident.startswith('A3.Thmtheorem6.'):
        return ('EXCLUDED', [], outs[1]['reason'])
    if ident=='A3.SS2.4' or ident.startswith('A3.SS2.p19'):
        return ('EXCLUDED', [], outs[2]['reason'])
    if ident.startswith('A3.Ex'):
        # Display IDs beyond Ex102 belong to C.6 or the final lemma proof.
        import re
        match = re.match(r'A3\.Ex(\d+)',ident)
        if match and int(match[1])>=103:
            return ('EXCLUDED', [], outs[2]['reason'] if int(match[1])>=129 else outs[1]['reason'])
    if ident.startswith('A3.EGx') and ident not in ['A3.EGx5','A3.EGx6','A3.EGx7','A3.EGx8','A3.EGx9']:
        return ('EXCLUDED', [], outs[2]['reason'] if ident=='A3.EGx13' else outs[1]['reason'])
    if ident.startswith('S4.SS1'):
        if ident in ['S4.SS1.p1','S4.SS1.p1.1','S4.SS1.p1.m3']:
            return ('NODE',['domain','theta'],'Standing d>=2 and the midpoint-grid definition are retained. The historical construction citation and kappa/spectrum/rotation clauses do not become active Gram-root dependencies.')
        return ('EXCLUDED', [], 'Hard-family spectral interval, random eigenbasis, potential, target or comparison narrative is outside the cosine Gram packet; Eq. (11) theta and d>=2 are separately retained.')
    if ident in ['S4.E11','S4.E11.m1']:
        return ('NODE',['theta'],'Only the theta_i=(i-1/2)pi/d clause is active. The same raw math ID also defines lambda_i and Lambda for the explicitly excluded range/hard-family branches.')
    if ident.startswith('S4.Thmtheorem2'):
        return ('EXCLUDED', [], 'Remark 4.2 and its asymptotic comparison/affine oracle equivalence concern the full hard-family lower bound, not the three deterministic identities.')
    if ident.startswith('S4.Thmtheorem3'):
        if ident in ['S4.Thmtheorem3.p1.1','S4.Thmtheorem3.p1.m1','S4.Thmtheorem3.p1.m2']:
            return ('NODE',['domain'],'Only the source wording integer q>=0 and 2q+1<d supplies domain context. The output-representation conclusion is excluded separately.')
        return ('EXCLUDED', [], outs[3]['reason'])
    if ident.startswith('S4.SS2.SSS0.Px1') or ident.startswith('S4.Ex10') or ident.startswith('S4.Ex11'):
        return ('EXCLUDED', [], 'Block-Krylov definition, external deferred-rotation motivation and algorithm-output representation are contextual to the excluded range/algorithm branch; no active ancestor of the deterministic roots.')
    if ident=='S4.SS2.SSS0.Px2':
        return ('EXCLUDED', [], 'Structural paragraph-section container; its D_n definition, domain binders and all out-of-scope conclusions are inventoried separately.')
    if ident.startswith('S4.Ex12') or ident.startswith('S4.SS2.SSS0.Px2.p1'):
        return ('NODE',['rn','D'],'Defines n and D_n and explains the frequency choice. The frequency-window proof is separately represented at A3.Ex96.')
    if ident.startswith('S4.Thmtheorem4'):
        if ident in ['S4.Thmtheorem4.p1.m2','S4.Thmtheorem4.p1.m3']:
            return ('NODE',['domain'],'Inherited query-budget domain only, not the full uniform-bound conclusion.')
        if ident in ['S4.Thmtheorem4.p1.m4','S4.Thmtheorem4.p1.m5']:
            return ('NODE',['gaussian.input'],'Independent standard Gaussian input for the private expectation consumers only.')
        return ('EXCLUDED', [], outs[2]['reason'])
    if ident.startswith('S4.Ex13') or ident.startswith('S4.Ex14'):
        return ('EXCLUDED', [], outs[2]['reason'])
    if ident.startswith('S4.SS2.SSS0.Px2.p2'):
        return ('EXCLUDED', [], outs[0]['reason'])
    if ident.startswith('S4.SS2.SSS0.Px2.p3') or ident.startswith('S4.Ex15'):
        return ('EXCLUDED', [], outs[3]['reason'])
    if ident=='bib.bib3':
        return ('EXCLUDED', [], 'Bibliography [22] identifies the historical hard-family/deferred-rotation source. It is not cited by the C.5 deterministic or second-moment proof and supplies no active proof dependency here.')
    if ident.startswith('A3.Thmtheorem5') or ident.startswith('A3.Ex86') or ident.startswith('A3.Ex87'):
        return ('NODE',['statement.C5.partition'],'Mixed six-clause statement partition only. Three deterministic roots and two expectation consumers are tracked; Range(B)=K_q is an explicit excluded clause. No whole-Fact-C.5 completion credit.')
    if ident.startswith('A3.SS2.p1') or ident.startswith('A3.Ex85'):
        # The common display holds both frame and gamma definitions.
        if ident=='A3.SS2.p1.m1': ns=['rn']
        elif ident=='A3.SS2.p1.m2': ns=['rn']
        elif ident=='A3.SS2.p1.m3': ns=['domain']
        elif ident in ['A3.SS2.p1.m4','A3.SS2.p1.m5']: ns=['gaussian.input']
        elif ident in ['A3.SS2.p1.m6','A3.SS2.p1.m7','A3.SS2.p1.m8']: ns=['B']
        elif ident.startswith('A3.Ex85'): ns=['frame','gaussian.input']
        else: ns=['rn','frame','gaussian.input','B']
        return ('NODE',ns,'Literal definitions and Gaussian consumer setup, with deterministic and consumer scopes recorded in the graph.')
    if ident.startswith('A3.SS2.p4') or ident.startswith('A3.Ex88') or ident.startswith('A3.Ex89') or ident=='A3.EGx5':
        if ident=='A3.SS2.p4.m1': ns=['consumer.expected-unweighted']
        elif ident=='A3.SS2.p4.m2': ns=['theta']
        elif ident in ['A3.SS2.p4.m3','A3.SS2.p4.m4','A3.SS2.p4.m5']: ns=['trig.nonzero']
        elif ident in ['A3.SS2.p4.2','A3.SS2.p4.m6']: ns=['cosine.zero']
        else: ns=['cosine.telescope']
        return ('NODE',ns,'The source telescopes midpoint cosines for integer nonzero frequencies and cancels a nonzero sine factor; the boxed expectation heading is only a consumer announcement.')
    if ident.startswith('A3.SS2.p5') or any(ident.startswith('A3.Ex'+str(i)) for i in range(90,94)) or ident=='A3.EGx6':
        if ident.startswith('A3.Ex90'): ns=['gram.constant-entries']
        elif ident in ['A3.SS2.p5.m1','A3.SS2.p5.m2','A3.SS2.p5.1']: ns=['frame']
        elif ident in ['A3.SS2.p5.m4','A3.SS2.p5.m5','A3.SS2.p5.m6','A3.SS2.p5.m7']: ns=['gram.frequency-window']
        elif ident in ['A3.SS2.p5.m8','A3.SS2.p5.3']: ns=['gram.frequency-window','det.unweighted']
        elif ident=='A3.SS2.p5': ns=['gram.constant-entries','gram.frequency-window','gram.nonconstant-entries','det.unweighted']
        else: ns=['gram.nonconstant-entries']
        return ('NODE',ns,'Unweighted entry cases, product-to-sum, frequency discharge and final matrix extensionality.')
    if ident.startswith('A3.SS2.p6') or ident.startswith('A3.Ex94') or ident.startswith('A3.Ex95') or ident=='A3.EGx7':
        return ('NODE',['gaussian.second-moment'] if ident=='A3.SS2.p6.m1' else ['consumer.expected-unweighted'],'Second-moment consumer of deterministic unweighted Gram; finite Gaussian second moments and expectation/Kronecker algebra are explicit dependency leaves.')
    if ident.startswith('A3.SS2.p7') or any(ident.startswith('A3.Ex'+str(i)) for i in range(96,102)) or ident in ['A3.EGx8','A3.EGx9']:
        if ident=='A3.SS2.p7.m1': ns=['consumer.expected-weighted']
        elif ident in ['A3.SS2.p7.1','A3.SS2.p7.m2','A3.SS2.p7.m3'] or ident.startswith('A3.Ex96'): ns=['weighted.frequency-window']
        elif ident.startswith('A3.Ex97') or ident.startswith('A3.Ex98') or ident=='A3.EGx8': ns=['weighted.triple-expansion']
        elif ident.startswith('A3.Ex99') or ident=='A3.SS2.p7.2': ns=['weighted.triple-zero']
        elif ident in ['A3.SS2.p7.3','A3.SS2.p7.m4','A3.SS2.p7.m5']: ns=['det.weighted']
        elif ident.startswith('A3.Ex100') or ident.startswith('A3.Ex101') or ident=='A3.EGx9': ns=['consumer.expected-weighted']
        else: ns=['weighted.frequency-window','weighted.triple-expansion','weighted.triple-zero','det.weighted','consumer.expected-weighted']
        return ('NODE',ns,'All four positive integer frequencies lie below 2d; the deterministic weighted Gram is obtained entrywise before its Gaussian expectation consumer.')
    if ident.startswith('A3.SS2.p8') or ident.startswith('A3.Ex102'):
        if ident.endswith('.p8.1') or ident.endswith('.p8.2'):
            return ('EXCLUDED', [], 'Transition word Finally or QED marker only; the full substantive norm display is separately a node.')
        return ('NODE',['det.row-norm'],'The source proves the row norm bound last, after both expectation branches; no concentration input is involved.')
    raise AssertionError(('unclassified raw item',ident,tag))

for item in idx['items']:
    disp, ns, reason = disposition(item)
    coverage.append({'item_id':item['id'],'item_kind':'mathID' if item['tag']=='math' else item['tag'],
        'source_locator':item['locator'],'byte_start':item['byte_start'],
        'byte_end_exclusive':item['byte_end_exclusive'],'raw_span_sha256':item['sha256'],
        'disposition':disp,'node_ids':ns,'reason':reason})

clauses = [
 ('A3.Ex86.m1::range','EXCLUDED',[],outs[0]['reason']),
 ('A3.Ex86.m1::expected-unweighted','NODE',['consumer.expected-unweighted'],'Expected unweighted Gram clause only.'),
 ('A3.Ex86.m1::expected-weighted','NODE',['consumer.expected-weighted'],'Expected D_n-weighted Gram clause only.'),
 ('A3.Ex87.m1::row-norm','NODE',['det.row-norm'],'First deterministic clause only.'),
 ('A3.Ex87.m1::unweighted','NODE',['det.unweighted'],'Second deterministic clause only.'),
 ('A3.Ex87.m1::weighted','NODE',['det.weighted'],'Third deterministic clause only.'),
 ('S4.E11.m1::spectrum','EXCLUDED',[],'lambda_i and Lambda define the hard family and excluded Chebyshev range branch, not an ancestor of the deterministic Gram roots.'),
]
for ident,disp,ns,reason in clauses:
    parent=ident.split('::')[0]
    source=byid[parent]
    coverage.append({'item_id':ident,'item_kind':'semantic-clause','source_locator':'#'+parent,
        'byte_start':source['byte_start'],'byte_end_exclusive':source['byte_end_exclusive'],
        'raw_span_sha256':source['sha256'],'disposition':disp,'node_ids':ns,'reason':reason})

# External citations in the expanded standing-context read windows; no external
# citation appears in the actual C.5 proof. Ordinal is relative to each raw root.
for root,ordinal,container in [('S4.SS1',1,'S4.SS1.p1.1'),('S4.SS1',2,'S4.Thmtheorem2.p1.1'),('S4.SS2.SSS0.Px1',1,'S4.SS2.SSS0.Px1.p1.1')]:
    source=byid[container]
    coverage.append({'item_id':root+'::external-citation-'+str(ordinal), 'item_kind':'external-citation',
        'source_locator':'#'+container+' a[href="#bib.bib3"]','byte_start':source['byte_start'],
        'byte_end_exclusive':source['byte_end_exclusive'],'raw_span_sha256':source['sha256'],
        'disposition':'EXCLUDED','node_ids':[],
        'reason':'Citation [22] OpenAI (2026), Subpolynomial query complexity for well-conditioned log-concave sampling, is historical/deferred-rotation background for excluded branches. It is not a C.5 deterministic or Gaussian expectation proof input. Bibliography locator #bib.bib3.'})

graph = {'schema':'astis-independent-raw-source-proof-graph/v1','raw_sha256':idx['raw_sha256'],
 'author_role':'raw-source-only Source Proof Graph author; not prover, verifier or integration owner',
 'stage':'PHASE1_RAW_GRAPH_FROZEN_BEFORE_TYPED_OVERLAY',
 'bounded_roots':['det.unweighted','det.weighted','det.row-norm'],
 'private_consumer_nodes':['consumer.expected-unweighted','consumer.expected-weighted'],
 'status_contract':'Every mathematical node is source-only unchecked. This graph records the author proof topology and implicit leaves, not any Lean result, semantic verdict or completion seal.',
 'nodes':nodes,'edges':edges,'alternative_routes':[],
 'route_semantics':'One author route per bounded root, with locally required inputs as AND edges. Separate range/Krylov branch is excluded; it is not an additional AND premise of any Gram identity.',
 'out_of_scope':outs,'context_only_downstream_topology':downstream,
 'source_contract_gaps_detected':[],
 'unproved_background_leaves':[x['id'] for x in nodes if 'primitive' in x['kind']],
 'typed_overlay':'Not received, not read, not inferred. Future exact sealed types/minimal definitions must be a separate artifact; phase1 graph bytes must not change.'}
dump('source_graph.json',graph)
dump('coverage.json',{'schema':'astis-source-coverage/v1','raw_sha256':idx['raw_sha256'],
 'scope_roots':idx['roots'],'policy':'Every raw ID in all expanded read windows has exactly one NODE or EXCLUDED disposition. All source math IDs, equation displays, theorem/definition clauses, substantive proof paragraphs and external citations are covered. Semantic clauses make mixed displays explicit. Formatting wrappers are not mathematical progress.',
 'items':coverage,'summary':{'raw_ids':len(idx['items']),'raw_math_ids':sum(x['tag']=='math' for x in idx['items']),
    'coverage_rows':len(coverage),'node_rows':sum(x['disposition']=='NODE' for x in coverage),
    'excluded_rows':sum(x['disposition']=='EXCLUDED' for x in coverage),
    'unclassified':0,'independent_review_status':'PENDING; author cannot accept its own source topology'}})

allnodes={x['id'] for x in nodes}
assert len(allnodes)==len(nodes)
for e in edges:
    assert e['consumer'] in allnodes
    assert all(x in allnodes for x in e['parents'])
for row in coverage:
    assert row['disposition'] in ['NODE','EXCLUDED']
    assert (len(row['node_ids'])>0)==(row['disposition']=='NODE')
    assert all(x in allnodes for x in row['node_ids'])
assert len({x['item_id'] for x in coverage})==len(coverage)
assert {x['id'] for x in idx['items']}<= {x['item_id'] for x in coverage}

# Acyclicity and root ancestor closure are shape checks, not mathematical review.
parents={x:set() for x in allnodes}
for e in edges:
    parents[e['consumer']].update(e['parents'])
def ancestors(x, path=()):
    assert x not in path, ('cycle',path,x)
    ans=set()
    for y in parents[x]:
        ans.add(y); ans.update(ancestors(y,path+(x,)))
    return ans
closures={r:sorted(ancestors(r)) for r in graph['bounded_roots']+graph['private_consumer_nodes']}
report={'status':'STRUCTURAL_CHECK_ONLY_PASS','raw_ids':len(idx['items']),
 'raw_math_ids':sum(x['tag']=='math' for x in idx['items']), 'coverage_rows':len(coverage),
 'graph_nodes':len(nodes),'core_edges':len(edges),'root_ancestor_closures':closures,
 'source_topology_review':'PENDING independent raw-source reviewer; shape checking is not review.',
 'file_permissions':'Freeze will set phase1 files 0444 and all phase1 directories 0555.'}
dump('logs/author_output.json',report)
print(json.dumps({k:v for k,v in report.items() if k!='root_ancestor_closures'},ensure_ascii=False))
