#!/opt/anaconda3/bin/python
import json,pathlib
BASE=pathlib.Path(__file__).resolve().parent
audit=json.loads((BASE/'inputs/huanjian-fixed-spectrum-cosine-gram.json').read_text())
print('AUDIT_KEYS',[(k,type(v).__name__,len(v) if hasattr(v,'__len__') else None) for k,v in audit.items()])
for key,value in audit.items():
    if key not in ['source','lean','blind_reconstruction','publication_context']:
        print('AUDIT',key,json.dumps(value,ensure_ascii=False,indent=2))
for key in ['source','lean','blind_reconstruction','publication_context']:
    print('AUDIT_FIELD_KEYS',key,list(audit.get(key,{})))
outer=json.loads((BASE/'inputs/fresh-native-0a91de-original-outer-receipt.json').read_text())
print('NATIVE_OUTER',json.dumps(outer,ensure_ascii=False,indent=2))
manifest=json.loads((BASE/'inputs/fresh-native-0a91de-original-freeze-manifest.json').read_text())
print('NATIVE_MANIFEST_SUMMARY',json.dumps({k:v for k,v in manifest.items() if k not in ['files','directories']},ensure_ascii=False,indent=2))
print('NATIVE_MANIFEST_COUNTS',len(manifest['files']),len(manifest.get('directories',[])))
for r in manifest['files']:
    if any(s in r['path'] for s in ['kernel','owned','fresh-build-results','fresh-build-plan','static-reader','input-hashes','build_fresh','make_probe','raw/fresh_','raw/owned_']):
        print('NATIVE_RELEVANT_PATH',json.dumps(r))
