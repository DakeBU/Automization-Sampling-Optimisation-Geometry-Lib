from pathlib import Path
import copy
import gzip
import json
import subprocess
import sys
sys.dont_write_bytecode = True
from lossless_frozen_bundle import archive_exact, put_new, sha

W = Path(__file__).parent
E = Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-detector-semantic-evidence')
S = Path('.astis/semantic-neutral-20261110/d_fresh_a6c943').resolve()
candidate = '65776f88e92b9680e6afe0d4c20b7390e4521241'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == candidate
dump = lambda x: (json.dumps(x, ensure_ascii=False, indent=2) + '\n').encode()

files = {}
for name, expected in [
    ('phase1-freeze-receipt.json', 'f7a0179225df164d57079e25ec13057e31bbd3def0b22b6916ee73cc13d7abb8'),
    ('phase2-freeze-receipt.json', 'fd12155fe75bca7d2b867cd7228c18de9bf90600c5ea1445431b706da7698a80'),
    ('phase3-freeze-receipt.json', 'ffe73f1521ee61983d5be75235bf92a9c2c5a1f40ad8acccdcc9422aae0dc595'),
]:
    raw = (S / name).read_bytes()
    assert sha(raw) == expected
    files[name] = raw
    for row in json.loads(raw)['artifacts']:
        path = Path(row['path'])
        rel = str(path.relative_to(S))
        data = path.read_bytes()
        assert len(data) == row['bytes'] and sha(data) == row['sha256'], rel
        assert path.stat().st_mode & 0o777 == 0o444, rel
        if rel in files:
            assert files[rel] == data
        files[rel] = data
assert set(files) == {str(p.relative_to(S)) for p in S.rglob('*') if p.is_file()}

proposalraw = files['phase3-proposal.json']
assert sha(proposalraw) == '70f7df056b459247ef476858a6b7ae0e20cefad4b9a06c5a9cba647c4c6edc86'
proposal = json.loads(proposalraw)
fields = {'state', 'verdict', 'semantic_slots', 'deltas', 'source_review'}
assert set(proposal) == fields
assert proposal['state'] == 'source-reviewed'
assert proposal['source_review']['reviewer'] == '/root/detector_fresh_source'
assert proposal['source_review']['state'] == 'accepted'
assert proposal['source_review']['review_run_sha256'] == '77a6f70eb925cb6b62ea47b0dea6eb99fe0896de7aa6f867ec76449d356628b9'
assert all(d['severity'] != 'blocking' for d in proposal['deltas'])
assert proposal['source_review']['reviewer_packet_sha256'] == '9525ebc96a14c49ea7694c6997103ac371ae5942b83356718ccaf05ce5aa751b'

native = json.loads((E / 'independent-native-fullmodule-static.archive-manifest.json').read_bytes())
assert native['sha256'] == 'eaf9bb161fb1a1fed28746e349b0ea2c3024dd9f3b8487c489590d416e75ab42'
assert sha(Path(native['archive']).read_bytes()) == native['sha256']
source = archive_exact(files, E / 'independent-full-source-all-phases.lossless-file-bytes.tar.gz')
source['original_verifier_actor'] = '/root/detector_fresh_source'
source['actual_checked_mathematical_commit'] = candidate
put_new(E / 'independent-full-source-all-phases.archive-manifest.json', dump(source))
put_new(E / 'independent-source-five-field-proposal.raw.json', proposalraw)

auditpath = Path('research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-detector.json')
oldraw = auditpath.read_bytes()
old = json.loads(oldraw)
assert old['state'] == 'blind-reconstructed' and old['source_review'] == {'state': 'pending'}
assert old['publication_binding_sha256'] == '5a5e5931f81293f2b4d191170a878aec1eb681cacd34554ab074bb430e6548da'
put_new(E / 'audit-before-independent-full-source-application.raw.json', oldraw)
updated = copy.deepcopy(old)
for k in fields:
    updated[k] = proposal[k]
assert {k:v for k,v in old.items() if k not in fields} == {k:v for k,v in updated.items() if k not in fields}
assert all(updated[k] == proposal[k] for k in fields)
auditpath.write_bytes(dump(updated))
put_new(E / 'independent-source-proposal-exact-application.json', dump({
    'source_proposal_sha256': sha(proposalraw),
    'source_phase3_freeze_sha256': 'ffe73f1521ee61983d5be75235bf92a9c2c5a1f40ad8acccdcc9422aae0dc595',
    'native_freeze_sha256': 'c9fcba354e8a55a20111e8ccc461da6d74afac96d85f3ab5f374db6f64cbdcc3',
    'mathematical_checked_commit': candidate,
    'changed_audit_top_level_fields': sorted(fields),
    'all_other_audit_values_exact': True, 'five_original_proposal_values_exact': True,
    'original_proposal_and_independent_boundaries_preserved': True,
    'root_source_verdict_invented': False, 'normal_sourceV_API_calls': 0,
    'new_native_at_metadata_carrier_or_global_or_Goal_credit': False,
}))
cellpath = Path('research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-detector.json')
cellraw = cellpath.read_bytes()
cell = json.loads(cellraw)
assert cell['status'] == 'proved_locally'
put_new(E / 'frontier-before-accepted-independent-reviews.raw.json.gz', gzip.compress(cellraw, mtime=0))
cell['evidence']['independent_verification'] = 'Original fresh source reviewer accepted exact auxiliary/code/reader-content scope at65776f88; independent72c9e4 fresh P/Test/kernel and actual Lake context,27 exact locators and isolated static17 closed folds accepted the same exact bytes. Native cache reused/fresh boundaries and all failures retained. Normal sourceV pending; no global/site/browser/purification or whole-Goal credit.'
cell['evidence']['independent_source_archive'] = source
cell['evidence']['independent_native_static_archive'] = native
cell['source_detail_audit']['gap'] = 'Matrix detector algebra and private actual rotated-pushforward strict-event/Borel component independently source/code/native/static reviewed. Normal sourceV pending. Actual pushforward-target covariance law, rotated pass probability, source concentration C, Krylov/Haar/adaptive algorithm/TV/query/cost and complete main bounds, global/browser/publication/purification remain separate.'
cellpath.write_bytes(dump(cell))
for name in ['reviewer-packet-raw-versus-canonical-diagnostic.json', 'latest-main-live-owner-after-detector-candidate.json']:
    put_new(E / name, (W / name).read_bytes())
print(json.dumps({'source_files_byte_exact':len(files), 'source_archive_sha256':source['sha256'], 'native_files_byte_exact':native['file_count'], 'audit_state':updated['state'], 'root_sourceV_API_calls':0}))
