from pathlib import Path
import json, hashlib, re
from html.parser import HTMLParser
from bs4 import BeautifulSoup
phase=Path("/Users/zhouhuanjian/ASTIS-GC/.astis/semantic-neutral-20261110/cg_src_c63b08/phase1-source-only")
source=(phase/"inputs/2610.20492v1.html").read_bytes()
text=source.decode("utf-8")
soup=BeautifulSoup(text,"html.parser")
class Spans(HTMLParser):
    def __init__(self,data):
        super().__init__(convert_charrefs=False)
        self.data=data
        self.lines=[0]
        for m in re.finditer("\n",data): self.lines.append(m.end())
        self.stack=[]
        self.spans={}
    def pos(self): return self.lines[self.getpos()[0]-1]+self.getpos()[1]
    def handle_starttag(self,tag,attrs):
        start=self.pos()
        ident=dict(attrs).get("id")
        if tag in {"area","base","br","col","embed","hr","img","input","link","meta","param","source","track","wbr"}:
            if ident: self.spans[ident]=(start,start+len(self.get_starttag_text()))
        else: self.stack.append((tag,ident,start))
    def handle_startendtag(self,tag,attrs):
        start=self.pos()
        ident=dict(attrs).get("id")
        if ident:self.spans[ident]=(start,start+len(self.get_starttag_text()))
    def handle_endtag(self,tag):
        end=self.data.find(">",self.pos())+1
        for j in range(len(self.stack)-1,-1,-1):
            if self.stack[j][0]==tag:
                for _,ident,start in self.stack[j:]:
                    if ident:self.spans[ident]=(start,end)
                self.stack=self.stack[:j]
                break
sp=Spans(text)
sp.feed(text)
def loc(ident):
    start,end=sp.spans[ident]
    bs=len(text[:start].encode("utf-8"));be=len(text[:end].encode("utf-8"))
    return {"source_id":ident,"byte_start":bs,"byte_end_exclusive":be,"bytes":be-bs,"sha256":hashlib.sha256(source[bs:be]).hexdigest(),"source_url":"https://arxiv.org/html/2610.20492v1#"+ident}
def latextext(el):
    cp=BeautifulSoup(str(el),"html.parser")
    for m in cp.find_all("math"):m.replace_with(" $"+str(m.get("alttext","MISSING_ALTTEXT"))+"$ ")
    return cp.get_text(" ",strip=True)
ids=["A3.SS2.2","A3.SS2.3","A3.SS2.4","A3.Thmtheorem6"]+["A3.SS2.p"+str(i) for i in range(1,20)]
index=[]
for ident in ids:
    row=loc(ident)
    start,end=row["byte_start"],row["byte_end_exclusive"]
    name=ident.replace(".","_")
    (phase/"raw"/(name+".exact.html")).write_bytes(source[start:end])
    row["snapshot"]="raw/"+name+".exact.html"
    el=soup.find(id=ident)
    math=[]
    for m in el.find_all("math"):
        rec={"id":m.get("id"),"alttext":m.get("alttext")}
        if m.get("id") in sp.spans:rec["locator"]=loc(m.get("id"))
        math.append(rec)
    (phase/"raw"/(name+".math-alttext.json")).write_text(json.dumps(math,ensure_ascii=False,indent=2)+"\n")
    (phase/"raw"/(name+".latex-text.txt")).write_text(latextext(el)+"\n")
    index.append(row)
(phase/"raw/proof-detail-locators.json").write_text(json.dumps(index,ensure_ascii=False,indent=2)+"\n")
sec=soup.find(id="A3.SS2")
blocks=[]
for el in sec.find_all(recursive=False):
    if el.name not in {"h3","h4","h5","p","div","section"}:continue
    ident=el.get("id")
    row={"id":ident,"tag":el.name,"class":el.get("class"),"text":latextext(el)}
    if ident in sp.spans:row["locator"]=loc(ident)
    row["math"]=[{"id":m.get("id"),"alttext":m.get("alttext")} for m in el.find_all("math")]
    blocks.append(row)
(phase/"raw/c2-blocks-v2.json").write_text(json.dumps(blocks,ensure_ascii=False,indent=2)+"\n")
meta={"title":soup.title.get_text(" ",strip=True) if soup.title else None,"source_sha256":hashlib.sha256(source).hexdigest(),"source_bytes":len(source),"decode":"UTF-8","parser":"bs4 html.parser and custom HTMLParser offset spans; exact HTML slices from original UTF-8 bytes","math_alttext_total_in_C2":len(sec.find_all("math")),"missing_alttext_ids":[m.get("id") for m in sec.find_all("math") if m.get("alttext") is None],"fragments":len(index),"C2_blocks":len(blocks)}
(phase/"raw/source-metadata-v2.json").write_text(json.dumps(meta,ensure_ascii=False,indent=2)+"\n")
print(json.dumps(meta,ensure_ascii=False,indent=2))
print(json.dumps([{"id":x["source_id"],"bytes":x["bytes"],"sha256":x["sha256"]} for x in index],ensure_ascii=False,indent=2))
