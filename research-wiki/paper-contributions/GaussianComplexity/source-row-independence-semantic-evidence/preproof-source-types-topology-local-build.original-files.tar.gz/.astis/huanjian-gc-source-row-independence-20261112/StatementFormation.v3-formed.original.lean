import Mathlib

noncomputable section
open MeasureTheory ProbabilityTheory
set_option autoImplicit false

-- Preliminary literal Prop formation only. No proof and no admission.
def proposedIndependentRows : Prop :=
  ∀ {d q : ℕ} (hq : 2 * q + 1 < d),
  let D := EuclideanSpace ℝ (Fin d)
  let E := EuclideanSpace ℝ (Fin (q + 1))
  let Ω := Fin (q + 1) → D
  let μ : Measure Ω := Measure.pi (fun _ : Fin (q + 1) => stdGaussian D)
  let row : Fin d → Ω → E := fun i ω =>
    WithLp.toLp 2 (fun a : Fin (q + 1) => ω a i)
  iIndepFun row μ

def proposedIndependentTruncatedMatrices : Prop :=
  ∀ {d q : ℕ} (hq : 2 * q + 1 < d),
  let D := EuclideanSpace ℝ (Fin d)
  let E := EuclideanSpace ℝ (Fin (q + 1))
  let Ω := Fin (q + 1) → D
  let μ : Measure Ω := Measure.pi (fun _ : Fin (q + 1) => stdGaussian D)
  let row : Fin d → Ω → E := fun i ω =>
    WithLp.toLp 2 (fun a : Fin (q + 1) => ω a i)
  let r : ℝ := ((q + 1 : ℕ) : ℝ)
  let L : ℝ := 2 * r + 3 * Real.log (1000 * (d : ℝ))
  let θ : Fin d → ℝ := fun i =>
    (((i.val : ℝ) + 1 - (1 / 2 : ℝ)) * Real.pi) / (d : ℝ)
  let t : Fin d → Fin (q + 1) → ℝ := fun i k =>
    if k.val = 0 then 1 else Real.sqrt 2 * Real.cos ((k.val : ℝ) * θ i)
  let Y : Fin d → Ω →
      ((Fin (q + 1) × Fin (q + 1)) → (Fin (q + 1) × Fin (q + 1)) → ℝ) := fun i ω =>
    if ‖row i ω‖ ^ 2 ≤ L then
      (d : ℝ)⁻¹ • Matrix.kronecker
        (Matrix.vecMulVec (fun a => row i ω a) (fun a => row i ω a))
        (Matrix.vecMulVec (t i) (t i))
    else 0
  iIndepFun Y μ

#check proposedIndependentRows
#check proposedIndependentTruncatedMatrices
