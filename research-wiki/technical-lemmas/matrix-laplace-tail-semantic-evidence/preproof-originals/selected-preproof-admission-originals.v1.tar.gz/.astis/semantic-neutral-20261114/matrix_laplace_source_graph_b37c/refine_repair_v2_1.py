import copy, hashlib, json, pathlib
B=pathlib.Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(n):return json.loads((B/n).read_text())
def put(n,obj):
    p=B/n;assert not p.exists();p.write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n');return sha(p)
g=read('source-graph.repaired.v2.json')
g['version']='v2.1'
g['preserved_first_v2_proposal']={'file':'source-graph.repaired.v2.json','sha256':sha(B/'source-graph.repaired.v2.json'),'reason':'Final self-check adds the already-mentioned truncated-domain predecessor to Gaussian radial-mean background explicitly and distinguishes phase1 independence snapshot from current post-seal read state. No target formula change.'}
g['independence_at_phase1_freeze']=copy.deepcopy(g['independence'])
g['independence'].update({'sealed_P_T_read':True,'seal_audit_read':True,'distinct_TC_findings_read':True,'root_singleton_supplement_read':True})
g['edges'].append({'producer':'GC.Y.REGULARITY','consumer':'BG.GAUSSIAN.ROW.MEAN','consumer_use_site':'Radial truncated-expectation form mentioned in background requires the actual truncated expectation domain before GC.MEAN use; second moments/radial law also come from GC.MODEL.','status':'SOURCE_TOPOLOGY_ONLY_NOT_COMPILED'})
g['coverage_inventory']='coverage.exact.v2.1.json'
ids={n['id'] for n in g['nodes']};pending=set(ids);done=set();order=[]
while pending:
    ready={x for x in pending if all(e['producer'] in done for e in g['edges'] if e['consumer']==x)}
    assert ready,'cycle';order+=sorted(ready);pending-=ready;done|=ready
assert order.index('GC.Y.REGULARITY')<order.index('BG.GAUSSIAN.ROW.MEAN')<order.index('GC.MEAN')<order.index('GC.RADIUS')<order.index('GC.SUM.BOUND')
gh=put('source-graph.repaired.v2.1.json',g)
c=read('coverage.exact.v2.json');c['version']='v2.1';c['graph_sha256']=gh
ch=put('coverage.exact.v2.1.json',c)
x=read('source-vs-seal.repaired.v2.json');x['version']='v2.1';x['repaired_graph_sha256']=gh;x['coverage_sha256']=ch
x['graph_repair']['TC15-F1']+=' The Gaussian radial truncated-expectation background also explicitly depends on GC.Y.REGULARITY, so every occurrence of an actual truncated expectation has its domain predecessor.'
xh=put('source-vs-seal.repaired.v2.1.json',x)
o=read('graph-repair.overlay.v2.json');o['version']='v2.1';o['repaired_graph_sha256']=gh;o['coverage_sha256']=ch;o['source_vs_seal_sha256']=xh
o['added_edges'].append(g['edges'][-1]);o['mechanical_checks']['edges']=len(g['edges']);o['mechanical_checks']['Y_REGULARITY_before_RADIAL_BACKGROUND_before_MEAN']=True
o['preserved_initial_v2_files']={n:sha(B/n) for n in ['source-graph.repaired.v2.json','coverage.exact.v2.json','source-vs-seal.repaired.v2.json','graph-repair.overlay.v2.json']}
oh=put('graph-repair.overlay.v2.1.json',o)
print(json.dumps({'graph':gh,'coverage':ch,'crosswalk':xh,'overlay':oh,'mechanical_checks':o['mechanical_checks']},indent=2))
