"""Independent R18 static reader preflight; never imports/executes the browser checker."""
from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import urlparse, unquote, urljoin
import ast
import hashlib
import json
import plistlib
import re
import sys

REPO = Path('/Users/zhouhuanjian/ASTIS-GC')
OWN = Path(__file__).resolve().parent
PREP = REPO / '.astis/huanjian-gc-adaptive-oracle-simulation-20261116/metadata-drafts/reader-preparation-v1'
PREVIEW = PREP / 'isolated-preview-v1'
FIXTURE = PREVIEW / 'fixtures/candidate'
SNAPSHOT = PREVIEW / 'input-snapshot'
ITEM = 'huanjian-adaptive-oracle-simulation'
PFILE = 'AutoSamplingTheory/TechnicalLemmas/Probability/AdaptiveOracleSimulation.lean'
TFILE = 'Tests/GaussianComplexityAdaptiveFirstOrderSimulation.lean'
P = 'AutoSamplingTheory.TechnicalLemmas.Probability.AdaptiveOracleSimulation.measurable_simulation_joint_law_and_cost'
T = 'AutoSamplingTheory.Tests.GaussianComplexityAdaptiveFirstOrderSimulation.actual_fixed_spectrum_first_order_matvec_joint_laws_and_costs'
RUN = 'AutoSamplingTheory.TechnicalLemmas.Analysis.QuadraticRegularizationOracle.run'
FO = 'AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumFirstOrder.actual_first_order_query'
SOURCES = [('P', PFILE, P, 93, 170), ('T', TFILE, T, 21, 118),
           ('RUN', 'AutoSamplingTheory/TechnicalLemmas/Analysis/QuadraticRegularizationOracle.lean', RUN, 18, 62),
           ('FO', 'AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumFirstOrder.lean', FO, 30, 92)]

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def digest(value):
    return hashlib.sha256(value).hexdigest()

def load(path):
    return json.loads(Path(path).read_text())

checks = []
def check(name, passed, detail=None):
    checks.append({'name': name, 'pass': bool(passed), 'detail': detail})

class Node:
    def __init__(self, tag='', attrs=(), parent=None):
        self.tag, self.attrs, self.parent, self.parts = tag, dict(attrs), parent, []
    @property
    def text(self):
        return ''.join(p.text if isinstance(p, Node) else p for p in self.parts)
    def descendants(self, tag=None, cls=None, attr=None):
        out = []
        for child in self.parts:
            if not isinstance(child, Node):
                continue
            if ((tag is None or child.tag == tag) and
                    (cls is None or cls in child.attrs.get('class', '').split()) and
                    (attr is None or attr in child.attrs)):
                out.append(child)
            out.extend(child.descendants(tag, cls, attr))
        return out

class Document(HTMLParser):
    VOID = {'area', 'base', 'br', 'col', 'embed', 'hr', 'img', 'input', 'link', 'meta', 'param', 'source', 'track', 'wbr'}
    def __init__(self, path):
        super().__init__(convert_charrefs=True)
        self.root = Node()
        self.stack = [self.root]
        self.feed(Path(path).read_text())
        self.nodes = self.root.descendants()
        self.ids = {n.attrs['id']: n for n in self.nodes if 'id' in n.attrs}
    def handle_starttag(self, tag, attrs):
        n = Node(tag, attrs, self.stack[-1])
        self.stack[-1].parts.append(n)
        if tag not in self.VOID:
            self.stack.append(n)
    def handle_endtag(self, tag):
        for i in range(len(self.stack)-1, 0, -1):
            if self.stack[i].tag == tag:
                self.stack = self.stack[:i]
                break
    def handle_data(self, data):
        self.stack[-1].parts.append(data)

delivery = load(PREP / 'DELIVERY.DRAFT.v1.json')
check('exact-delivery-sha', sha(PREP / 'DELIVERY.DRAFT.v1.json') == '90033d20a107b1006a0a592fd96278231d178a2fd396404bba5e21bcede28f55')
for path, row in delivery['files'].items():
    check('delivery-file:' + path, sha(PREP/path) == row['sha256'] and (PREP/path).stat().st_size == row['bytes'])
manifest = load(PREVIEW / 'preview-freeze-manifest.json')
check('exact-preview-manifest-sha', sha(PREVIEW / 'preview-freeze-manifest.json') == '221dd9b5ae7af9dc6fa0a1e5ab35241c7ca858357b7d69e94ec1d475c9294cd3')
check('proof-freeze', manifest['proof_commit'] == '57016008083947405bc7d430838537014a40f987')
frozen = load(PREVIEW / 'input-freeze-manifest.json')
check('input-manifest-link-sha', sha(PREVIEW/'input-freeze-manifest.json') == manifest['input_freeze_manifest_sha256'])
input_mismatches = []
for row in frozen['files']:
    path = SNAPSHOT / row['path']
    if not path.is_file() or sha(path) != row['sha256']:
        input_mismatches.append(row['path'])
check('all118-input-snapshot-file-hashes', len(frozen['files']) == 118 and not input_mismatches, input_mismatches)
variant_mismatches = {}
for variant, selected in manifest['variants'].items():
    root = PREVIEW / 'fixtures' / variant
    actual = {str(x.relative_to(root)) for x in root.rglob('*') if x.is_file()}
    expected = {r['path'] for r in selected['files']}
    mismatch = [r['path'] for r in selected['files'] if not (root/r['path']).is_file() or sha(root/r['path']) != r['sha256'] or (root/r['path']).stat().st_size != r['bytes']]
    variant_mismatches[variant] = {'missing': sorted(expected-actual), 'extra': sorted(actual-expected), 'byte_mismatches': mismatch}
    check('exact-file-set-and-byte-hashes:' + variant, actual == expected and not mismatch, {'count': len(actual), **variant_mismatches[variant]})
selection = load(PREP / 'candidate-served.selection.v1.json')
candidate = manifest['variants']['candidate']
check('candidate104-served-selection-exact', len(candidate['files']) == 104 and selection['files'] == candidate['files'])

lesson_path = 'website/content/declaration_lessons/' + ITEM + '.json'
publication_path = 'website/content/publications/' + ITEM + '.json'
for raw, key in [(lesson_path, 'lesson_sha256'), (publication_path, 'publication_sha256')]:
    check('snapshot-and-live-metadata:' + raw, sha(SNAPSHOT/raw) == manifest[key] == sha(REPO/raw), {'sha256': manifest[key]})
unit = load(SNAPSHOT / lesson_path)['units'][0]
spans = [[1,52], [53,134], [135,152], [153,170], [1,118]]
check('five-step-paths-and-spans', [s['lean_source_path'] for s in unit['steps']] == [PFILE]*4+[TFILE] and [s['lean_source']['LF_lines_1based'] for s in unit['steps']] == spans)
for i, step in enumerate(unit['steps']):
    exact = (SNAPSHOT/step['lean_source_path']).read_bytes()
    first, last = spans[i]
    expected = b''.join(exact.splitlines(keepends=True)[first-1:last])
    source = step['lean_source']
    a,b = source['raw_UTF8_byte_span']
    c,d = source['decoded_char_span']
    check('step-span-exact:' + str(i+1), step['lean'].encode() == expected == exact[a:b] == exact.decode()[c:d].encode() and source['span_sha256'] == digest(expected) and source['file_sha256'] == digest(exact), {'lines': spans[i], 'bytes': len(expected), 'sha256': digest(expected)})
check('all-P170-T118-partitioned-with-context', ''.join(s['lean'] for s in unit['steps'][:4]).encode() == (SNAPSHOT/PFILE).read_bytes() and unit['steps'][4]['lean'].encode() == (SNAPSHOT/TFILE).read_bytes())

docs = {str(p.relative_to(FIXTURE)): Document(p) for p in FIXTURE.rglob('*.html')}
for raw in [candidate['proof_path'], candidate['lesson_path']]:
    doc = docs[raw]
    articles = doc.root.descendants('article', 'proof-reader')
    check('one-proof-article:' + raw, len(articles) == 1)
    article = articles[0]
    steps = article.descendants('details', 'proof-reader-step')
    details = [n for n in doc.root.descendants('main')[0].descendants('details')]
    check('initially-closed-reading-disclosures:' + raw, len(details)>0 and all('open' not in d.attrs for d in details), {'details':len(details), 'proof_steps':len(steps)})
    check('five-exact-adjacent-Lean-spans:' + raw, len(steps)==5 and [s.descendants('pre', 'code-block')[0].descendants('code')[0].text for s in steps] == [s['lean'] for s in unit['steps']])
    main = article.descendants(cls='reader-main-equation')
    check('default-main-formula-and-six-folded-assumptions:' + raw, len(main)==1 and unit['formula'] in main[0].text and len(article.descendants('details','assumption-ledger')) == 1 and len(unit['assumptions']) == 6)
    for i, step in enumerate(steps):
        check('adjacent-copy-source-download:' + raw + ':' + str(i+1), len(step.descendants('button', attr='data-lean-copy')) == 1 and len(step.descendants('a',attr='data-step-source')) == 1 and len(step.descendants('a',attr='download')) == 1 and len(step.descendants('details',attr='data-step-source-path')) == 1)
        source = step.descendants('a',attr='data-step-source')[0].attrs['href']
        check('correct-step-source-anchor:' + raw + ':' + str(i+1), source.endswith(unit['steps'][i]['lean_source_path']+'.html#L'+str(spans[i][0])))

source_rows = []
for label, raw, name, anchor, line_count in SOURCES:
    exact=(SNAPSHOT/raw).read_bytes()
    doc = docs['data/lesson-sources/'+raw+'.html']
    pre = doc.root.descendants('pre')[0]
    source_lines = [n for n in pre.descendants('span') if re.fullmatch('L[0-9]+', n.attrs.get('id',''))]
    check('whole-source-line-context-and-download:' + label, pre.text.encode() == exact and [n.attrs['id'] for n in source_lines] == ['L'+str(i) for i in range(1,line_count+1)] and (FIXTURE/'downloads/lean'/raw).read_bytes()==exact and (REPO/raw).read_bytes()==exact)
    expected_prefix = ('private theorem ' if label=='T' else 'def ' if label=='RUN' else 'theorem ') + name.split('.')[-1]
    check('exact-declaration-anchor:' + label, doc.ids['L'+str(anchor)].text.strip().startswith(expected_prefix))
    source_rows.append({'label':label,'path':raw,'lines':line_count,'declaration_line':anchor,'sha256':digest(exact)})

graph=load(FIXTURE/'data/underlying-lean-graph.json')
modules=[x[1][:-5].replace('/','.') for x in SOURCES]
expected_nodes={'module:'+m for m in modules}|{'decl:'+SOURCES[i][2] for i in [0,2,3]}
expected_edges={('module:'+modules[2],'module:'+modules[0],'imports')}|{('module:'+modules[i],'module:'+modules[1],'imports') for i in [0,3]}|{('module:'+modules[i],'decl:'+SOURCES[i][2],'declares') for i in [0,2,3]}|{('decl:'+RUN,'decl:'+P,'source reference (scanner)')}|{('decl:'+SOURCES[i][2],'module:'+modules[1],'source reference (scanner)') for i in [0,3]}
check('graph-seven-unique-identities-no-private-T-node', len(graph['nodes']) == 7 and {n['id'] for n in graph['nodes']}==expected_nodes and not any(T in n['id'] for n in graph['nodes']))
check('graph-nine-directed-import-declare-reference-edges', len(graph['edges'])==9 and {(e['source'],e['target'],e['relation']) for e in graph['edges']}==expected_edges and 'do not assert theorem implication' in graph['reference_contract'])
index = docs['source-index.html'].root.descendants('main')[0]
index_links = [a for li in index.descendants('li') for a in li.descendants('a')]
check('source-index-four-exact-labels-and-anchors', [n.text for n in index_links] == [r[2] for r in SOURCES] and all(a.attrs['href'].endswith(raw+'.html#L'+str(anchor)) for a,(_,raw,_,anchor,_) in zip(index_links,SOURCES)))
check('source-index-private-T-qualifier', 'associated private application; no public node' in index.text)
parent = docs['parent-context.html'].root.descendants('main')[0]
parent_links = [a for li in parent.descendants('li') for a in li.descendants('a')]
check('parent-run-P-FO-navigation-and-private-T-boundary', [n.text for n in parent_links] == [RUN,P,FO] and 'It has no separate public theorem node' in parent.text and 'reuses the existing canonical finite-fuel run definition' in parent.text)

broken=[];external=[];disabled=0;link_count=0
for raw, doc in docs.items():
    for n in doc.nodes:
        if 'data-preview-unserved-href' in n.attrs:
            disabled+=1
            if 'href' in n.attrs or n.attrs.get('aria-disabled') != 'true':
                broken.append([raw,'disabled-link-still-active',n.attrs])
        for attr in ['href','src']:
            if attr not in n.attrs:
                continue
            target=n.attrs[attr]
            if target.startswith(('data:', 'blob:')):
                continue
            parsed=urlparse(target)
            if parsed.scheme or parsed.netloc:
                external.append({'from':raw,'tag':n.tag,'url':target})
                continue
            if not target or target.startswith(('data:','blob:','mailto:','javascript:')):
                continue
            resolved=urlparse(urljoin('https://fixture.invalid/'+raw,target))
            relative=unquote(resolved.path.lstrip('/')) or 'index.html'
            dest=FIXTURE/relative
            if dest.is_dir():
                dest=dest/'index.html'; relative=relative.rstrip('/')+'/index.html'
            link_count+=1
            if not dest.is_file():
                broken.append([raw,target,'missing-file'])
            elif resolved.fragment and relative in docs and unquote(resolved.fragment) not in docs[relative].ids:
                broken.append([raw,target,'missing-anchor'])
for p in (FIXTURE/'assets').rglob('*.css'):
    for ref in re.findall(r'url\(\s*[\'\"]?([^\)\'\"]+)',p.read_text()):
        if ref.startswith(('data:','http:','https:','#')):
            continue
        target=(p.parent/unquote(ref.split('#')[0])).resolve()
        if not target.is_file():
            broken.append([str(p.relative_to(FIXTURE)),ref,'CSS-url-missing'])
check('independent-all-HTML-and-CSS-local-link-closure', not broken, {'active_local_refs':link_count,'disabled_global_links':disabled,'broken':broken})
check('external-refs-are-citations-not-load-resources', all(n['tag']=='a' for n in external), {'external_citation_count':len(external)})
for label, raw, name, anchor, line_count in SOURCES:
    module_path = 'modules/' + raw[:-5].replace('/', '-').lower() + '.html'
    module = docs[module_path]
    check('module-context-source-exact:' + label, module.root.descendants('pre')[-1].text.encode() == (SNAPSHOT/raw).read_bytes())
for n in graph['nodes']:
    target = urlparse(n['url'])
    check('graph-node-URL-local-target:' + n['id'], target.path in docs and (not target.fragment or unquote(target.fragment) in docs[target.path].ids))

custody = load(PREP/'adaptation-custody.DRAFT.v1.json')
for row in custody['files']:
    if Path(row['draft']).name not in ['browser_check.py', 'browser_geometry.py', 'browser_anchor_wait.py']:
        continue
    check('actual-mechanism-base-and-current-hashes:' + Path(row['draft']).name, sha(REPO/row['original']) == row['original_sha256'] and sha(REPO/row['draft']) == row['draft_sha256'])
    if row.get('byte_identical_mechanism_reuse'):
        check('byte-identical-mechanism-reuse:' + Path(row['draft']).name, (REPO/row['original']).read_bytes() == (REPO/row['draft']).read_bytes())

for name in ['browser_check.py','browser_geometry.py','browser_anchor_wait.py']:
    source=(PREP/'runtime-draft'/name).read_text()
    ast.parse(source)
    check('unexecuted-checker-syntax:' + name, True, {'sha256':sha(PREP/'runtime-draft'/name)})
anchor_source=(PREP/'runtime-draft/browser_anchor_wait.py').read_text()
check('passive-anchor-observer-no-scroll-style-animation-mutation', not any(x in anchor_source for x in ['scrollIntoView','scrollBy(','scrollTo(','scrollLeft=','scrollTop=','.style.','animation=']))
geometry=(PREP/'runtime-draft/browser_geometry.py').read_text()
check('original-geometry-strict-thresholds-present', all(x in geometry for x in ["g['intersectionFraction']>=.98", "g['labelVisibleFraction']>=.95", "g['effectiveFontPx']>=12", "r.left>=clip.left-1", "r.right<=clip.right+1", "r.top>=clip.top", "r.bottom<=clip.bottom"]))

chrome=Path('/Applications/Google Chrome.app/Contents/MacOS/Google Chrome')
info=plistlib.loads((chrome.parents[1]/'Info.plist').read_bytes())
framework=chrome.parents[1]/'Frameworks/Google Chrome Framework.framework/Versions'/info['CFBundleShortVersionString']/'Google Chrome Framework'
chrome_info={'path':str(chrome),'binary_sha256':sha(chrome),'bytes':chrome.stat().st_size,'bundle_version_static':info['CFBundleShortVersionString'],'framework_path':str(framework),'framework_sha256':sha(framework) if framework.is_file() else None,'not_executed':True}
frozen_paths=[PREVIEW/'input-freeze-manifest.json', PREVIEW/'preview-freeze-manifest.json', PREP/'candidate-served.selection.v1.json', PREP/'DELIVERY.DRAFT.v1.json']+[SNAPSHOT/x for x in [lesson_path,publication_path]+[r[1] for r in SOURCES]+['lean-toolchain','lake-manifest.json']]
assignment=load(PREP/'runtime-draft/execution-assignment.TEMPLATE.json')
assignment.update({'preview_manifest_sha256':sha(PREVIEW/'preview-freeze-manifest.json'),'frozen_inputs':[{'path':str(p),'sha256':sha(p)} for p in frozen_paths],'selected_served_leaf_count':104,'lesson_sha256':manifest['lesson_sha256'],'publication_sha256':manifest['publication_sha256'],'chrome':{'path':str(chrome),'binary_sha256':sha(chrome)},'execution_custody':'DRAFT ONLY. Independently preflighted current fixture/checker. Actual source review evidence and binding stay null pending ROOT; only a later explicit ROOT assignment and scoped launch approval may authorize actual browser/server execution. All output must be placed in this reader-owned directory; checker should be copied byte-for-byte here at that stage. No source/native/old reader acceptance inherited.'})
(OWN/'execution-assignment.DRAFT.v1.json').write_text(json.dumps(assignment,ensure_ascii=False,indent=2)+'\n')
result={'schema':'r18-independent-reader-static-preflight-v1','status':'STATIC_PREFLIGHT_PASS' if all(c['pass'] for c in checks) else 'STATIC_PREFLIGHT_FAIL','checks':checks,'source_files':source_rows,'chrome':chrome_info,'fixture_html_files':len(docs),'candidate_served_leaves':len(candidate['files']),'source_reviewed_binding':None,'actual_source_review_artifact':None,'actual_browser_executed':False,'server_started':False,'normal_API_Lean_Git_or_canonical_writes':False,'prior_native_source_reader_verdict_inherited':False,'source_fidelity_verdict':'NOT IN ROLE; NOT PRODUCED','visual_acceptance':'PENDING authorized actual browser run and independent PNG/trace review','checker_runtime_findings':['The checker copies must be placed byte-for-byte into this own directory before execution because OWN controls runtime writes.','Checker asserts the source evidence artifact hash and a 64-hex binding but does not semantically validate their relationship; ROOT must supply and bind actual source reviewed evidence before assignment.','Source-anchor checks apply original positive-intersection and top >= header - 1 after passive natural settling. Graph and final-codepoint reachability intentionally use actual UI scrolling separately.','Headless 1440x1000 and 390x844 are CSS viewport checks; they do not simulate physical touch.'],'assignment_draft':{'path':str(OWN/'execution-assignment.DRAFT.v1.json'),'sha256':sha(OWN/'execution-assignment.DRAFT.v1.json')}}
(OWN/'preflight-result.v2.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'status':result['status'],'checks':len(checks),'false':[c for c in checks if not c['pass']],'chrome':chrome_info,'result_sha256':sha(OWN/'preflight-result.v2.json'),'draft_sha256':sha(OWN/'execution-assignment.DRAFT.v1.json')},ensure_ascii=False,indent=2))
