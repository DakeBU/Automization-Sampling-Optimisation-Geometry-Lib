from pathlib import Path
import subprocess,os,json,hashlib,time,datetime,sys
ROOT=Path('/Users/zhouhuanjian/ASTIS-GC');BASE=ROOT/'.astis/semantic-neutral-20261110/src_d63b90/phase3';RUN=BASE/'runtime';RUN.mkdir(exist_ok=True);OVERLAY=RUN/'overlay';OVERLAY.mkdir(exist_ok=True)
LEAN='/Users/zhouhuanjian/.elan/toolchains/leanprover--lean4---v4.33.0/bin/lean'
def command(label,args,cwd,env=None):
    p=RUN/(label+'.log');t=time.monotonic();start=datetime.datetime.now(datetime.timezone.utc).isoformat();print('START',label,flush=True)
    r=subprocess.run(args,cwd=cwd,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);p.write_bytes(r.stdout)
    rec={'label':label,'args':args,'cwd':str(cwd),'started_at_utc':start,'finished_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'elapsed_seconds':time.monotonic()-t,'exit_code':r.returncode,'log_path':str(p.relative_to(ROOT)),'log_sha256':hashlib.sha256(r.stdout).hexdigest(),'log_bytes':len(r.stdout),'lean_path':env.get('LEAN_PATH') if env else None}
    (RUN/(label+'.json')).write_text(json.dumps(rec,indent=2)+'\n');print(json.dumps(rec),flush=True)
    if r.stdout: print(r.stdout.decode(errors='replace'),flush=True)
    if r.returncode:sys.exit(r.returncode)
    return r.stdout.decode().strip()
mode=sys.argv[1]
if mode=='setup':
    lp=command('lake-env-lean-path',['lake','env','printenv','LEAN_PATH'],ROOT)
    (RUN/'base-lean-path.txt').write_text(lp+'\n')
    command('pinned-lean-version',[LEAN,'--version'],ROOT)
    head=command('checked-head',['git','rev-parse','HEAD'],ROOT);assert head=='25922bb4c3b5a14ec882ebd4d876ed4a309b8843'
    paths=lp.split(':');resolved=[]
    for mod in ['AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumGridAlias','AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumCosineExpansion','Mathlib.Probability.Distributions.Gaussian.Multivariate']:
        found=next((Path(x)/(mod.replace('.','/')+'.olean') for x in paths if (Path(x)/(mod.replace('.','/')+'.olean')).exists()),None);assert found
        resolved.append({'module':mod,'cache_path':str(found),'cache_sha256':hashlib.sha256(found.read_bytes()).hexdigest(),'bytes':found.stat().st_size,'freshly_compiled_here':False})
    (RUN/'reused-cache-manifest.json').write_text(json.dumps(resolved,indent=2)+'\n');print(json.dumps(resolved,indent=2),flush=True)
else:
    lp=(RUN/'base-lean-path.txt').read_text().strip();env=os.environ.copy();env['LEAN_PATH']=str(OVERLAY)+':'+lp
    rel={'producer':'AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumGaussianMoments.lean','focused-test':'Tests/GaussianComplexityFixedSpectrumGaussianMoments.lean'}.get(mode,mode)
    source=BASE/'candidate'/rel;assert source.exists();dest=OVERLAY/Path(rel).with_suffix('.olean');dest.parent.mkdir(parents=True,exist_ok=True)
    command((sys.argv[2] if len(sys.argv)>2 else mode.replace('/','_').replace('.','_')),[LEAN,'-o',str(dest),'-i',str(dest.with_suffix('.ilean')),rel],BASE/'candidate',env)
    artifacts=[]
    for p in sorted(dest.parent.glob(dest.stem+'.*')):
        artifacts.append({'path':str(p.relative_to(ROOT)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size})
    (RUN/((sys.argv[2] if len(sys.argv)>2 else mode.replace('/','_').replace('.','_'))+'-artifacts.json')).write_text(json.dumps(artifacts,indent=2)+'\n');print(json.dumps(artifacts,indent=2),flush=True)
