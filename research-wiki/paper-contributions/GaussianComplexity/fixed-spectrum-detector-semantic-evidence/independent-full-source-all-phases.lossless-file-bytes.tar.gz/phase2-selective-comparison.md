# Phase 2: selective type, definitions and source-scope comparison

Status: **SELECTIVE SEMANTIC COMPARISON ONLY; FROZEN PENDING PHASE 3.**

This continues, and does not revise, the frozen Phase 1 source cognition (SHA256 `c5f8bca886476e04c99ff7a9bcc9423ed43e4a3575f7d5616a866ed43abff66a`; Phase 1 receipt SHA256 `f7a0179225df164d57079e25ec13057e31bbd3def0b22b6916ee73cc13d7abb8`). The new candidate input was only `selective-fresh-source-phase2-input.json`, 9370 bytes, SHA256 `7ea3428cd87be556bd4c4133f6eed4dc0bfabf7e2f4940e22bc3f1732b74ed54`.

## Result and its authority

The supplied public exact type and supplied blind reconstruction are **equivalent after the approved notation/type elaboration**. Against the raw paper, that type is a source-extracted **algebraic auxiliary**, with a mathematically valid explicit generalization from the proof's `n=2q+1` to every natural n, including zero. The displayed d and κ conditions agree with the hard-family source range, and no algorithm, Gaussian-moment estimate, probability estimate or query certificate has been introduced as a public hypothesis.

The exact private signature is a direct semantic consumer of this matrix identity: the source intrinsic polynomial occurs in its statistic, and the corresponding cosine diagonal occurs in its latent-coordinate event. Its statement is narrowly an event-measurability and **literal pushforward event-mass identity**. It does not identify that pushforward law with `π_A` and does not prove the target passing probability, moments, normalized-energy geometry, or Theorem 4.1. These boundaries are explicitly stated in the supplied contract and are consistent with an auxiliary, rather than a claim to have completed the whole source paragraph/theorem.

This is not a check of an implementation, actual calls, compilation, axioms, native/kernel results, complete module, source graph, correspondence, reader exposition, Registry state, or any prior review. The input's `compiled: true`, decoder process metadata, and `private_consumer_is_source_Anchor_or_Registry_node: false` were visible supplied assertions, not independently inspected evidence. No final source-V or mathematical acceptance is issued.

## Provenance: raw paper versus the authored source contract

The JSON field called `source.original_text` is **not a verbatim excerpt** of the pinned paper. It is an authored source contract: it includes Lean indexing/evaluation conventions, all-natural-n and all-real-τ auxiliary generalizations, a pushforward-measure scope boundary, and statements about internally produced ingredients. Its declared content SHA is correct, but that hash alone does not make the text an original quotation.

The raw paper itself supplies Eq. 11; defines `S_A` and strict `E_A` using the intrinsic first-kind Chebyshev matrix polynomial in §4.3; invokes `T_n(cos θ_i)=cos(n θ_i)` in the eigenvector-energy interpretation; and gives the target coordinate law in §4.2. Orthogonal conjugation of polynomial evaluation expands the implicit matrix identity. The auxiliary extraction and generalizations must retain those labels in any later attribution. There is no need to repair the paper's mathematical statement for this auxiliary identity; source provenance must not be overstated.

## The seven requested semantic slots

The Phase 1 record used a detailed seven-part source checklist. The following uses the exact seven names now requested: objects, domains, quantifiers, assumptions, conclusion, scopes, and constant_dependencies. Each entry distinguishes comparison with the blind text from comparison with the raw source.

### 1. objects

**Public type ↔ blind text: equivalent after elaboration.** Both contain real d×d matrices, a full real orthogonal matrix O, the midpoint cosine grid, the hard-family precision A, the normalized real matrix B, and the first-kind real Chebyshev polynomial evaluated in the matrix algebra. In `Polynomial.aeval B p`, coefficients become scalar identity matrices; this is not entrywise polynomial evaluation. The public type's integer-index polynomial receives the integer cast of the natural n; no negative indices are quantified.

**Public type ↔ raw source: explicit elaboration of the source's polynomial/cosine bridge.** With source index `j=i.val+1`, the formal `θ_i=((i.val:ℝ)+1/2)π/d` is exactly `θ_j=(j−1/2)π/d`. The local A is precisely Eq. 11's `OΛOᵀ`. The formal real scalar inverse `(κ−1)⁻¹ • ...` is the source division by κ−1, not matrix inversion. The conclusion has the same O on both sides of the cosine diagonal.

**Private context:** its Λ, θ, A and B repeat those same literal formulas. `EuclideanSpace ℝ (Fin d)` is the real Euclidean carrier; `WithLp.ofLp`/`toLp 2` expose/repackage its standard coordinates. `R z` is the linear rotation `Oz`. Its `Λ⁻¹` in `multivariateGaussian 0 Λ⁻¹` is a **matrix** inverse, distinct from the scalar `(κ−1)⁻¹`. Its S contains the literal public polynomial evaluation, the sign `(−1)^n`, and the correction `−2τ‖x‖²`.

### 2. domains

**Public type ↔ blind text: same.** d is a natural with `2≤d`, κ is real with `2≤κ`, O belongs to `Matrix.orthogonalGroup (Fin d) ℝ`, and n is any natural including zero. Both determinant signs are allowed; no special-orthogonal restriction occurs. Fin d is `0,…,d−1`, with ordinary real casts.

**Public type ↔ raw source:** d≥2 and κ≥2 match §4.1. The raw proof uses positive odd `n=2q+1`, and elsewhere imposes `n<d` for moment/Krylov estimates. The auxiliary domain is explicitly broader in n. The matrix polynomial identity itself needs neither oddness nor the upper bound n<d; these belong to other source estimates. Removing them from this auxiliary is not loss of a source condition needed for the identity. Its d and κ conditions are stronger than the mathematically minimal possible algebraic domain but are not extra restrictions relative to the chosen hard-family source domain.

**Private context:** τ ranges over all reals, while the source instance is the nonnegative `τ_{d,q}`. This is an explicit helper generalization: the pointwise event transport and Borelness hold for all τ. The source's geometric wording about exceeding an absolute threshold with the target sign must not automatically be exported to negative τ; the private signature does not make that claim.

### 3. quantifiers

**Public type ↔ blind text: same.** Universals are d/hd, κ/hκ, O, and n. θ, A and B are local deterministic definitions, not existential witnesses or additional hypotheses. No choice of another basis, diagonal matrix, polynomial, event, or output is being assumed. θ depends only on d; A and B depend on d, κ and O; n is the polynomial frequency.

**Public type ↔ raw source: explicit generalization.** The proof's frequency is `n=2q+1`; the public type asserts the identity for every natural n. It also turns a fixed-input step used during a random-input argument into its natural universal-in-O algebraic statement. This does not require Haar randomness or independence, and it remains valid for determinant −1 rotations. The source itself later fixes each A for the target argument, so fixed-input use is consistent with the source.

**Private context:** the signature is universal in d, κ, O, n and τ. Its event-mass equality is for each such fixed O and τ, not an expectation over O, not almost every O, and not an algorithm-output claim. There is no order change involving the algorithm or its seed because neither is in this helper.

### 4. assumptions

**Public type ↔ blind text: same.** Public premises are exactly the natural d bound, real κ bound, and membership in the full orthogonal group; n is typing data. There is no user-supplied diagonalization equality, normalized-matrix equality, scalar nonzeroness certificate, polynomial identity, moment bound, concentration event, probability/cost estimate, query model, rotation-law property, or private output fact. Local formulas expose their content instead of hiding new premises in a project-owned proposition.

**Public type ↔ raw source: no excess premise found in the shown signature.** The source hard-family assumptions give d≠0, κ−1≠0 and the orthogonal identities. These are internal algebraic consequences. The source's Haar law and independence are relevant to the lower-bound experiment, not needed for this fixed-input identity. Requiring them here would be unnecessary, and their absence is not a source omission for this selected scope.

**Private context:** it has only the same hard-family data plus arbitrary real τ, with all Gaussian/rotation/statistic objects locally defined. Its visible statement does not ask callers for continuity, measurability, positivity, Gaussian moments or event-mass equality. Continuity and measurability are obligations of an implementation of this statement, not newly exposed source assumptions. No project-owned Prop aliases occur in either supplied signature.

### 5. conclusion

**Public type ↔ blind text: equivalent after elaboration.** It is equality of real matrices

`T_n((2A−(κ+1)I)/(κ−1)) = O diag(cos(nθ_i)) Oᵀ`.

The equality is neither an approximate identity nor only a trace, expected-value, quadratic-form, event-mass or entrywise assertion. It says more than the particular scalar equality needed by one vector, as appropriate for a reusable algebraic helper. At n=0 both sides are I: the polynomial is 1, all cosine diagonal entries are 1, and `OOᵀ=I`. No exceptional/fallback semantics is needed at this newly included frequency.

**Public type ↔ raw source: explicit standard expansion.** The paper does not print this as a separately numbered all-n theorem. It uses the matrix polynomial in S_A and the scalar Chebyshev identity in its geometry. Orthogonal polynomial transport yields exactly this auxiliary conclusion, which at the source frequency gives its cosine-coordinate bridge. The source's full detector definition or probability estimate must not be treated as conclusions of this public type.

**Private conclusion:** Borelness of `{x:0<S x}` and

`(μ.map R) {x:0<S x} = μ {z:0 < (−1)^n Σ_i cos(nθ_i) z_i² − 2τ‖z‖²}`.

`0<S` is exactly the source's strict `S>0`. The statement neither replaces it by ≥ nor drops the target sign. At x=0, S=0 and the event excludes zero. It contains no division by ‖x‖² and therefore needs no x≠0 premise. It correctly uses squared latent coordinates z_i; it does not confuse them with original coordinates x_i or rows of O.

### 6. scopes

**Public type ↔ blind text: same selected scope.** Both stop at the algebraic identity. The supplied blind reconstruction preserves the reciprocal, first-kind matrix evaluation, arbitrary n, both orthogonal components, and no probabilistic hypothesis.

**Against the raw source:** this is a **narrow source-extracted auxiliary**, not Theorem 4.1, Lemma 4.5, the complete §4.3 detector argument, or a complete statement of normalized eigenvector-energy geometry. The narrow scope is declared. Within it no omitted source claim is being silently treated as proved. If it were advertised as the full §4.3 result, the missing law/moment/probability/query steps would be genuine omissions; that claim is not in the selective input.

**Private scope:** an exact event transport under a literal pushforward of a specified measure. It does not contain the target-law identification

`μ.map R = multivariateGaussian 0 A⁻¹`, or an identification with the source `π_A`.

It also does not state the moments from Lemma 4.5, their variance bounds, the conditions `τ≤β/4` and `Mβ²≥320`, the strict-event probability ≥0.9, the Krylov output argument, the averaged algorithm event bound, or the TV contradiction. The Gaussian covariance/law identification remains a separate source-alignment bridge before its LHS can be called `π_A(E_A)`. Weighted-energy fractions and their sum-to-one/nonzero-vector characterization remain distinct from the latent-coordinate equality here.

### 7. constant_dependencies

**Public type ↔ blind text: same.** The constants 2, 1/2, π, κ±1 and n are literal; every real/natural/integer cast has the ordinary meaning from the approved context. There is no unspecified approximation constant, hidden threshold, ε, δ, q, C, d₀, or asymptotic dependency. κ is not silently fixed at 2.

**Against the raw source:** the exact affine spectral normalization matches Eq. 11; the all-n identity has no frequency-dependent error term. Constants governing τ, the n=2q+1 substitution, and the lower-bound regime are outside this helper, rather than erased from a claimed full lower bound. The private statement has arbitrary explicit τ and retains exactly the multiplier 2τ; it introduces no event-probability constant such as 0.9, 0.99 or 320.

## What the two permitted Mathlib definition excerpts establish

Only the following whitelisted content ranges were viewed. Full-file bytes were read solely for hashing; no other file lines or proof API were displayed/searched.

1. `Mathlib/Probability/Distributions/Gaussian/Multivariate.lean:168–172`, full-file SHA256 `1fec35cf781da1009c37db80a96b05d70f2296ca7768e19bfc0b6314c9b43d49` (12755 bytes). The definition body is the pushforward of `stdGaussian` by `x ↦ μ + toEuclideanCLM (CFC.sqrt S) x`. Line 172 includes only the start/name of the next lemma `multivariateGaussian_of_not_posSemidef`; its body and proof were not read. The definition is a real measure construction, not a proposition certifying any desired moments. Calling it the covariance-S normal law is naturally justified on a positive-semidefinite S; the displayed body alone is not an independently checked covariance theorem. In the source hard family, Λ has λ_i>1, so its inverse is positive definite by standard diagonal linear algebra. This makes the intended covariance legitimate, but an implementation/source-law correspondence still belongs to later review.

2. `Mathlib/MeasureTheory/Measure/Map.lean:91–93`, full-file SHA256 `e9c245b054b5a897dba730cdefd02e89f94e9d7c54835bf149b6c952ad589a08` (13962 bytes). `Measure.map f μ` chooses `mapₗ (hf.mk f) μ` when f is AEMeasurable and returns zero otherwise. Thus the pushforward interpretation must discharge measurability, rather than assume arbitrary maps always preserve the intended probability semantics. Here R is an explicitly given finite-dimensional linear rotation and is continuous/measurable by ordinary mathematics. The private conclusion itself exposes event Borelness, and its implementation must produce the needed map measurability internally. No such code proof has yet been viewed.

The literal event equality is in fact measure-independent once the pointwise statistic identity and measurable R are established; its algebra does not require Gaussian moments or a covariance identification. The choice of μ specializes this auxiliary to the source coordinate setting without making it the full target-probability step.

## Private consumer relevance: precise finding

The public output is genuinely relevant to the exact private signature, rather than merely cited by surrounding prose:

- Its public LHS occurs literally inside the private S; the θ/A/B definitions match.
- Substituting the public RHS and evaluating at `Rz=Oz` gives

  `(Oz)ᵀ [O diag(cos(nθ_i)) Oᵀ] (Oz) = Σ_i cos(nθ_i) z_i²`.

- Orthogonality also gives `‖Rz‖²=‖z‖²`, so this identifies the exact strict event preimage, including the correction `−2τ‖z‖²`.
- With measurable R, pushforward event mass then gives exactly the private equality. Borelness of S's event is an additional elementary continuity obligation; it is not furnished merely by the public matrix equality.

Therefore: **the shown signature contains the public LHS and directly uses its output's mathematical content as the intrinsic-to-cosine bridge.** It is a concrete plausible semantic consumer. A signature alone cannot prove an actual implementation invokes this declaration, and it cannot establish that this particular declaration is the uniquely necessary proof route. The same matrix identity could be reproved inline, or a weaker pointwise/event identity could be supplied. Actual theorem-call dependence, reachable use, provider purity and full-module correctness remain unaudited for Phase 3.

## Typed scope classifications and residual review

- `PUBLIC_AUXILIARY`: source-extracted fixed-input matrix-polynomial/cosine equality; legitimate declared narrow scope.
- `PUBLIC_GENERALIZATION`: all natural n, including zero, beyond the raw proof's n=2q+1; valid algebraic extension, not a verbatim source theorem.
- `PRIVATE_GENERALIZATION`: all real τ; exact event/measure transport remains valid, but does not export the source's positive-threshold sign geometry to arbitrary negative τ.
- `PRIVATE_EVENT_TRANSPORT`: Borel strict event and literal μ.map R event equality; directly consumes the public identity semantically.
- `RESIDUAL_GAUSSIAN_LAW`: identification of μ.map R with π_A or the Gaussian with precision A; separate and unproved by the displayed signatures.
- `RESIDUAL_SOURCE_GEOMETRY`: normalized weights along Oe_i, nonzero-vector condition and fractions summing to one; supplied conceptually by Phase 1 but not asserted as a conclusion here.
- `RESIDUAL_SOURCE_ESTIMATES`: target moments/variances, uniform asymptotic conditions, probability ≥0.9, algorithm average bound and TV/query lower bound; outside these helper scopes.
- `IMPLEMENTATION_NOT_AUDITED`: no exact declaration body/call/provider/module/consumer proof inspected.
- `EXPOSITION_NOT_AUDITED`: no candidate authored exposition or full correspondence inspected.

No mathematical source repair, new assumption, or changed source theorem is proposed at this stage. The source-contract paraphrase and helper generalizations should remain visibly labeled in later attribution. This phase issues no final five-field source audit proposal and performs no V/API transition.

## Pause

Phase 2 freezes this independent comparison and actual-input/exposure manifest, then pauses. Phase 3 requires the specifically supplied fullmodule/provider/private-consumer/correspondence/exposition whitelist. The full canonical reviewer packet and all prior native/source/topology verdicts remain unopened.
