from pathlib import Path
import copy, datetime, gzip, hashlib, json, subprocess, sys, tarfile
sys.path.insert(0, 'tools')
import astis_advance, astis_site
sha = lambda raw: hashlib.sha256(raw).hexdigest()
dump = lambda value: (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode()
B = Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-normalizer-integration-20261108')
S = Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-normalizer-semantic-evidence/fresh-source-reader-640251')
X = S / 'post-integration-normalpark-execution/464d24039f39aaf9'
CORE = 'a5ec44836422e56ca5cfab14f951ed84bbfc9324'
ADV = 'ASTIS-SA-20261108-GaussianComplexityFixedSpectrumNormalizer'
CELL = Path('research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-normalizer.json')
README = Path('research-wiki/paper-contributions/GaussianComplexity/README.md')
def ref(p):
    p = Path(p)
    return {'path': str(p), 'sha256': sha(p.read_bytes())}
assert subprocess.check_output(['git', 'rev-parse', 'HEAD']).decode().strip() == CORE
assert not subprocess.check_output(['git', 'diff', '--cached', '--name-only']).strip()
assert subprocess.check_output(['git', 'diff', '--name-only']).decode().splitlines() == ['runs/substantive_advances.jsonl']
manifest = X / 'execution-closeout-manifest.json'
assert sha(manifest.read_bytes()) == '06e7de2ff44cff6087f03c425b2aee016eaaca0a2669a3bc8a0aa87911030a1f'
closeout = json.loads(manifest.read_bytes())
for row in closeout['files']:
    raw = (X / row['path']).read_bytes()
    assert sha(raw) == row['sha256'] and len(raw) == row['bytes']
assert closeout['normalpark_API_calls'] == 1 and closeout['normal_API_exit_code'] == 0 and closeout['STAB'] == []
states = astis_advance.current_advances()
assert states[ADV]['state'] == 'VERIFIED' and not any(v['state'] == 'STABILIZING' for v in states.values())
assert states[ADV]['owner_id'] == 'huanjian_gc_20261108_fixed_spectrum_normalizer'
ledger = Path('runs/substantive_advances.jsonl').read_bytes()
assert sha(ledger) == '94cd42c3b1cbed224d6fb9df5722ab369a2ec1e04f6110a3a61bd190984d68f1'
before = gzip.decompress((X / 'before-ledger.lossless.jsonl.gz').read_bytes())
append = (X / 'normalpark-append.exact.jsonl').read_bytes()
assert ledger == before + append and sha(append) == 'ede4848d3accb0f9a1d940b710456ef702a41a917c6f05f4cf465a68d3c130f2'
old_event = next(json.loads(row) for row in before.splitlines() if json.loads(row).get('advance_id') == ADV and json.loads(row).get('from_state') == 'PROVED_LOCAL' and json.loads(row).get('to_state') == 'VERIFIED')
park_event = json.loads(append)
assert park_event['worker_id'] == old_event['worker_id'] == '/root/norm_fresh_source_640251'
assert {k: v for k, v in park_event['evidence'].items() if k != 'post_integration_normalpark'} == old_event['evidence']
accepted = B / 'independent-reader/local-successor-v7-acceptance.json'
eligibility = B / 'independent-reader/normalpark-successor-v7-eligibility.json'
assert sha(accepted.read_bytes()) == '041f32035dfb56d550235ab53709b7d3399ddb365336f608baeef251e8ff6a23'
assert sha(eligibility.read_bytes()) == 'c8b0f09fc790b784bea56b36ea4d67ff8ca423f9b4900841c2452c5c2fe3ca2c'
assert astis_site.source_digest() == '92a908be0defdf1b5994f5ff4fe8a0e545cdca0f6c229cd1141c36338129bd21'
models = {p: sha(Path(p).read_bytes()) for p in ['website/content/graph_memory_index.json', 'website/content/functor_hypergraph.json']}
foreign = {str(p): sha(p.read_bytes()) for p in Path('research-wiki/frontier-cells').glob('*.json') if p != CELL}
assert len(foreign) == 442
old_cell, old_readme = CELL.read_bytes(), README.read_bytes()
assert sha(old_cell) == '6fead305d38586bdbd5d32c2541416509008e7803465a1929bfb7bb3326b479c'
assert sha(old_readme) == '7833c17d75451ace5ddab23594dbe0a8b2d158c097aef620e33cf594401b3cd8'
for name, raw in [('frontier-before-local-acceptance-projection.json.gz', old_cell), ('README-before-local-acceptance-projection.md.gz', old_readme)]:
    p = B / 'process-diagnostics' / name
    assert not p.exists()
    p.write_bytes(gzip.compress(raw, mtime=0))
    assert gzip.decompress(p.read_bytes()) == raw
boundary = ('The exact actual quadratic Gaussian weight is Lebesgue Integrable and its actual integral equals the full displayed spectrum-only product value at source d>=2,kappa>=2 and every full real O. The genuine same-A private Gaussian density consumer uses that actual integral. Independent sourceV at813268bc and accepted-audit successorcc9 remain distinct. Actual immutable integration corea5ec44836422e56ca5cfab14f951ed84bbfc9324 passed official root Lean/Tests/fakeclosure, site build/check, graph, all other gates, real Chrome1440/390 and independent actual46original review. Root actually viewed8 current originals. One precisely reviewed min-width CSS correction repairs mobile historical-GPD debt prose; all other protected foreign bytes/states/frontiers/models remain unchanged. Normal independent existing-V parking by the ORIGINAL fresh source verifier released soleSTAB, preserving every original V evidence field and proof owner. Only the normalizing scalar is independent of O; exponent/covariance retain O. Existing GPD compilation inventory adds no historical sourceV or completed standalone publication audit. Remaining C4 calculus/minimizer, strict historical angle/cosine route, moments/Krylov, actual adaptive/private-seed/transcript/output, oracle/finiteprecision/TV, deterministic worstcap and explicit expected-cost adapters, both full main bounds, remote publication, postmerge purification/ExpositionSeal and wholeGoal remain incomplete.')
c = json.loads(old_cell)
assert c['status'] == 'independently_verified'
c['evidence'].setdefault('integration_phase_history', []).append(copy.deepcopy(c['evidence']['canonical_integration']))
c['evidence']['canonical_integration'] = {'state': 'LOCAL_ACCEPTED_NORMAL_EXISTING_V_PARKED_REMOTE_AND_PURIFICATION_OPEN', 'accepted_immutable_core': CORE, 'source_digest': astis_site.source_digest(), 'owner': 'huanjian_gc_20261108_fixed_spectrum_normalizer_integration', 'independent_reader_acceptance': ref(accepted), 'independent_normalpark_eligibility': ref(eligibility), 'original_verifier_normalpark_closeout': ref(X / 'normalpark-closeout.json'), 'unique_park_append_sha256': sha(append), 'original_source_V_append_sha256': closeout['original_source_V_sha256'], 'source_and_Test_lesson_publication_unchanged': True, 'new_source_verdict': False, 'historical_GPD_sourceV_upgraded': False, 'qualified_site_CSS_exception': {'path': 'website/static/information-architecture.css', 'after_sha256': 'a41ffd9d41e8c281aa716fcff25e42e5cb8d14208badff456a0dff7dfbb1b766'}, 'remote_merge_publication_purification_or_wholeGoal_credit': False}
c['evidence']['execution_boundary'] = boundary
c['source_detail_audit']['fidelity_boundary'] = boundary
c['source_detail_audit']['gap'] = 'Selected finite Lebesgue-integrability/integral-value and genuine normalized-law consumer obligations are internally proved and independently reviewed. The source-implicit Lebesgue convention is disclosed. The canonical density/unit-probability-mass proof is a reviewed implementation OR-route. This does not claim new strict source angle/cosine proofs or the remaining C4/algorithm/main-bound/remote/purification obligations.'
c['statement_seal']['status'] = 'EXACT_STATEMENT_COMPILED_INDEPENDENT_SOURCE_VERIFIED_AND_LOCAL_INTEGRATION_ACCEPTED'
c['graph_contribution']['visual_review'] = 'Actual a5ec core graph/native navigation, desktop/mobile and independent all46 original review accepted; root viewed8 originals. Same3canonical producer/4private-consumer kernel parents. Existing GPD inventory retains explicit old audit debt. Source-name scans remain dashed/incomplete, separate from kernel evidence.'
c['graph_contribution']['edge_semantics'] = 'Canonical compiled declaration reuse; displayed name references are dashed and incomplete, not a kernel dependency export.'
c['source_proof_coverage']['selected_unproved_math_is_preimplementation_history'] = True
c['source_proof_coverage']['current_implementation_and_integration'] = c['evidence']['canonical_integration']
CELL.write_bytes(dump(c))
prefix = (f'## 2026-11-08: fixed-spectrum actual Gaussian mass locally accepted\n\n'
          f'The actual Lebesgue integral and its finite integrability at source d>=2,kappa>=2/full O, together with the genuine same-A actual-integral-normalized Gaussian density consumer, are independently source-VERIFIED and locally accepted at immutable core `{CORE}`. Exact real root Lean/Tests, site/graph and all nine checks passed; independent reader actually opened all46 current desktop/mobile originals, root8. A single reviewed CSS grid-item width correction repaired mobile GPD historical-debt prose. It changes no mathematics or sourceDigest; the one CSS exception is explicit, every other protected foreign byte/state/frontier/model remains intact.\n\n'
          'The ORIGINAL independent source verifier performed one normal existing-V STAB release with every original source-V evidence field preserved. STAB is empty. The accepted source audit remains successor metadata after checked813268bc; no retroactive checked-tree bytes, new V verdict, parent historical-audit upgrade or fresh build at the later metadata-only commit is claimed. Only Z is independent of O; the exponent/covariance are not.\n\n'
          'Remote original-owner PR385 remains OPEN/UNSTABLE at5a257960 with the unchanged native-runtime failure; owner release is still UNCONFIRMED. Fresh real origin fetch leaves main d9bcd423, an ancestor of the accepted core. No Bench retry, cap widening, pushtrigger, merge or other-owner edit occurred. Necessary-background historical standalone-audit debt, remaining C4 calculus/minimizer, moments/Krylov, both full main lower bounds, true adaptive/oracle/precision/TV/deterministic/expected-cost adapters, remote delivery and postmerge purification/ExpositionSeal remain open.\n\n'
          'Continue the SAME foreground Goal. Next exact pointwise fixed-spectrum gradient/value and same-O affine-response consumer are meaning-only elaborated and sealed; their independent raw source graph and distinct topology challenge are in progress. No next-target proof/API search or new SAU claim has occurred. All earlier checkpoints below remain phase history.\n\n')
README.write_bytes(prefix.encode() + old_readme)
old_checkpoint = (B / 'resume-checkpoint.json').read_bytes()
checkpoint_archive = B / 'process-diagnostics/resume-checkpoint-before-final-local-metadata.raw.json.gz'
assert not checkpoint_archive.exists()
checkpoint_archive.write_bytes(gzip.compress(old_checkpoint, mtime=0))
a = json.loads(old_checkpoint)
a.update({'recorded_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'state': 'LOCAL_INTEGRATION_ACCEPTED_EXISTING_V_NORMALLY_PARKED_FINAL_METADATA_ONLY', 'active_core': CORE, 'accepted_immutable_core': CORE, 'source_digest': astis_site.source_digest(), 'local_reader_acceptance': ref(accepted), 'normalpark_eligibility': ref(eligibility), 'normalpark_closeout': ref(X / 'normalpark-closeout.json'), 'normalpark_append_sha256': sha(append), 'current_ledger_sha256': sha(ledger), 'STAB': [], 'latest_browser_attempt': {'version': 'v7 exact full-code selector after reviewed one-line CSS successor', 'core': CORE, 'receipt': '20261108T111522609766Z-fixed-spectrum-normalizer-final-browser-selector-v7.receipt.json', 'raw_log_sha256': '8a622ea4d6583a8a9c7f75615643985517a714935b416fe90c75d17a3eab362d', 'elapsed_seconds': 57.43040883296635, 'status': 'PASS_AND_INDEPENDENT_ALL46_ORIGINAL_REVIEW_ACCEPTED', 'report_sha256': '30aff4ed1812e0998661f9c9a40501c6d96af615a9692e221213d258ac31874a', 'actual_original_PNGs': 46, 'root_actually_viewed_current_originals': 8, 'old_DensityAffinity_regression': 'Two widths native UI/DOM geometry only, no separate pixel-review claim'}, 'actual_nine_current_core_checks': ref(B / 'successor-actual-checks/all-nine-manifest.json'), 'qualified_site_layout_exception': {'path': 'website/static/information-architecture.css', 'before_sha256': 'fff8768ceacf00e973d4170751b75a0bc1e6cd9c16b2765a24e45b22f1aabd3e', 'after_sha256': 'a41ffd9d41e8c281aa716fcff25e42e5cb8d14208badff456a0dff7dfbb1b766'}, 'Goal_complete': False, 'next': 'Commit only final accepted evidence/metadata and actual normalpark append with exact mutable-index readback. No fresh-build credit at that metadata successor. Continue new exact FixedSpectrumFirstOrder source admission/critical definitions and distinct topology challenge before new SAU claim/proof/API. Current source Eq1 literal gradient/pair must be distinguished from C4 formal derivative-existence elaboration; forward affine consumer needs no inverse/nonzero assumption. Both full main bounds/actual adapters/remote/purification/wholeGoal remain open.'})
(B / 'resume-checkpoint.json').write_bytes(dump(a))
assert Path('runs/substantive_advances.jsonl').read_bytes() == ledger
assert foreign == {str(p): sha(p.read_bytes()) for p in Path('research-wiki/frontier-cells').glob('*.json') if p != CELL}
assert all(sha(Path(p).read_bytes()) == h for p, h in models.items())
assert README.read_bytes().endswith(old_readme)
result = {'state': 'ROOT_METADATA_PROJECTION_OF_EXISTING_ACCEPTANCE_AND_ORIGINAL_VERIFIER_NORMALPARK', 'accepted_immutable_core': CORE, 'new_source_verdict': False, 'lifecycle_API_called_by_root': False, 'old_README_bytes_preserved_as_exact_suffix': True, 'old_frontier_lossless_archive': ref(B / 'process-diagnostics/frontier-before-local-acceptance-projection.json.gz'), 'foreign442frontiers_and_models_unchanged': True, 'source_digest_unchanged': astis_site.source_digest(), 'ledger_after_original_verifier_API_unchanged_by_root': sha(ledger), 'frontier_after': ref(CELL), 'README_after': ref(README), 'Goal_complete': False}
(B / 'final-local-metadata-projection.json').write_bytes(dump(result))
print(json.dumps(result, ensure_ascii=False))
