#!/usr/bin/env python3
"""One explicitly authorized normal API transition, with private local preservation."""
from pathlib import Path
import copy
import datetime as dt
import hashlib
import json
import os
import stat
import subprocess
import sys
import time
import traceback

ROOT = Path('/Users/zhouhuanjian/ASTIS-GC')
OWN = Path(__file__).resolve().parent
COMMIT = '6abc79ed4c012c1d506c17b9824257769c18c635'
TARGET = 'ASTIS-SA-20261114-MatrixBernsteinMgf'
ACTOR = '/root/gaussian_push_audit_c7b1'
ENV = dict(os.environ, GIT_OPTIONAL_LOCKS='0', PYTHONDONTWRITEBYTECODE='1')
os.environ.update(GIT_OPTIONAL_LOCKS='0', PYTHONDONTWRITEBYTECODE='1')
sys.dont_write_bytecode = True
sys.path.insert(0, str(ROOT))
from tools import astis_advance as advance

def sha(data):
    return hashlib.sha256(data).hexdigest()

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, env=ENV)

def load(p):
    return json.loads(p.read_text())

def dump(name, value):
    p = OWN / name
    with p.open('x') as f:
        json.dump(value, f, ensure_ascii=False, indent=2)
        f.write('\n')

def file_sha(p):
    h = hashlib.sha256()
    with p.open('rb') as f:
        for data in iter(lambda: f.read(1024 * 1024), b''): h.update(data)
    return h.hexdigest()

def tracked_map():
    result = {}
    for entry in git('ls-files', '--stage', '-z').split(b'\0'):
        if not entry: continue
        meta, rawpath = entry.split(b'\t', 1)
        mode, oid, stage = meta.decode().split()
        assert stage == '0'
        path = os.fsdecode(rawpath)
        p = ROOT / path
        st = p.lstat()
        if stat.S_ISLNK(st.st_mode):
            data = os.fsencode(os.readlink(p))
            row = {'kind': 'symlink', 'sha256': sha(data), 'bytes': len(data)}
        elif stat.S_ISREG(st.st_mode):
            row = {'kind': 'file', 'sha256': file_sha(p), 'bytes': st.st_size}
        elif mode == '160000':
            row = {'kind': 'gitlink', 'oid': oid}
        else:
            raise AssertionError('Unexpected tracked leaf kind')
        result[path] = {**row, 'mode': stat.S_IMODE(st.st_mode), 'index_mode': mode, 'index_oid': oid}
    return result

def snapshot():
    a = (ROOT / 'runs/substantive_advances.jsonl').read_bytes()
    d = (ROOT / 'runs/substantive_discoveries.jsonl').read_bytes()
    ar = [json.loads(x) for x in a.splitlines()]
    dr = [json.loads(x) for x in d.splitlines()]
    states = advance._replay_advances(ar)
    index = Path(os.fsdecode(git('rev-parse', '--git-path', 'index')).strip())
    if not index.is_absolute(): index = ROOT / index
    return {'HEAD': git('rev-parse', 'HEAD').decode().strip(),
        'branch': git('symbolic-ref', '--quiet', 'HEAD').decode().strip(),
        'index_sha256': file_sha(index), 'all_tracked_worktree_bytes_and_modes': tracked_map(),
        'advance_prefix_bytes': len(a), 'advance_prefix_sha256': sha(a),
        'discovery_bytes': len(d), 'discovery_sha256': sha(d),
        'foreign_SAU_states': {k: v for k, v in states.items() if k != TARGET},
        'target_state': states[TARGET], 'all_discovery_states': advance._replay_discoveries(dr),
        'advance_record_count': len(ar), 'discovery_record_count': len(dr)}

def reconcile(before, after, payload):
    assert after['HEAD'] == before['HEAD'] == COMMIT and after['branch'] == before['branch']
    assert after['index_sha256'] == before['index_sha256']
    assert after['foreign_SAU_states'] == before['foreign_SAU_states']
    assert after['all_discovery_states'] == before['all_discovery_states']
    assert after['discovery_sha256'] == before['discovery_sha256'] and after['discovery_bytes'] == before['discovery_bytes']
    old = before['all_tracked_worktree_bytes_and_modes']
    new = after['all_tracked_worktree_bytes_and_modes']
    assert set(old) == set(new)
    changed = [p for p in old if old[p] != new[p]]
    assert changed == ['runs/substantive_advances.jsonl'], changed
    raw = (ROOT / 'runs/substantive_advances.jsonl').read_bytes()
    assert sha(raw[:before['advance_prefix_bytes']]) == before['advance_prefix_sha256']
    tail = raw[before['advance_prefix_bytes']:]
    assert tail.endswith(b'\n') and len(tail.splitlines()) == 1
    event = json.loads(tail)
    assert event['event'] == 'transition' and event['advance_id'] == TARGET
    assert event['from_state'] == 'PROVED_LOCAL' and event['to_state'] == 'VERIFIED'
    assert event['worker_id'] == ACTOR and event['evidence'] == payload
    assert after['advance_record_count'] == before['advance_record_count'] + 1
    assert after['target_state']['owner_id'] == before['target_state']['owner_id']
    assert after['target_state']['state'] == 'VERIFIED'
    with (OWN / 'VERIFIED-exact-canonical-append.jsonl').open('xb') as f: f.write(tail)
    return {'status': 'EXACT_ONE_TARGET_NORMAL_V_APPEND_AND_ALL_PROTECTED_IDENTITIES_PRESERVED',
        'verified_commit': COMMIT, 'actual_verifier_actor': ACTOR,
        'original24_PL_fields_inline_unchanged': True,
        'canonical_advance_ledger_prefix_byte_exact': True, 'canonical_append_events': 1,
        'canonical_append_sha256': sha(tail), 'canonical_append_bytes': len(tail),
        'all_foreign_advance_states_unchanged': True, 'all_discovery_states_and_ledger_unchanged': True,
        'all_prior_frontier_bytes_and_modes_unchanged': True,
        'all_tracked_worktree_bytes_modes_except_exact_ledger_append_unchanged': True,
        'owner_branch_HEAD_and_index_unchanged': True,
        'full_guard_snapshot_published': False, 'new_global_private_fingerprint_published': False,
        'tracked_changed_paths': changed,
        'build_identity': 'Actual independent native source4869; ROOT original compile107 worktree; original4CLI2cc; refreshed metadata gates56f8 worktree. No new6abc/export build claim.',
        'no_STABILIZING_site_merge_purification_or_Goal_completion': True}

def main():
    assert len(sys.argv) == 1
    assert not (OWN / 'normal-V-api-attempt-begun.json').exists(), 'Attempt exists; never retry blindly'
    acceptance = load(OWN / 'pre-V-independent-acceptance.v1.json')
    assert acceptance['status'] == 'ACCEPTED_EXACT_CARRIER_FOR_ONE_INDEPENDENT_NORMAL_V'
    assert acceptance['verified_commit'] == COMMIT and acceptance['verifier_id'] == ACTOR
    payload_path = OWN / 'VERIFIED-evidence.full.v2.json'
    payload = load(payload_path)
    assert file_sha(payload_path) == acceptance['payload_sha256']
    assert payload['verifier_id'] == ACTOR and payload['verified_commit'] == COMMIT
    before = snapshot()
    assert before['HEAD'] == COMMIT and before['target_state']['state'] == 'PROVED_LOCAL'
    assert before['target_state']['owner_id'] != ACTOR
    assert not git('diff', '--name-only', 'HEAD', '--')
    original_events = [json.loads(x) for x in (ROOT / 'runs/substantive_advances.jsonl').read_bytes().splitlines()]
    pls = [x['evidence'] for x in original_events if x.get('advance_id') == TARGET and x.get('to_state') == 'PROVED_LOCAL']
    assert len(pls) == 1 and len(pls[0]) == 24
    assert all(payload[k] == v for k, v in pls[0].items())
    dump('before.private.guard.json', before)
    dump('normal-V-api-attempt-begun.json', {'advance_id': TARGET, 'verified_commit': COMMIT,
        'verifier_id': ACTOR, 'normal_API_invocation_number': 1,
        'started_utc': dt.datetime.now(dt.timezone.utc).isoformat(), 'payload_sha256': file_sha(payload_path)})
    # This is the sole mutating normal API invocation in the verifier harness.
    advance.transition_advance(TARGET, 'VERIFIED', worker_id=ACTOR,
        modes=('verification',), evidence=copy.deepcopy(payload))
    print(json.dumps({'normal_API_returned': True, 'advance_id': TARGET, 'to_state': 'VERIFIED',
                      'verifier_id': ACTOR, 'verified_commit': COMMIT}))
    after = snapshot()
    dump('after.private.guard.json', after)
    summary = reconcile(before, after, payload)
    dump('normal-V-preservation-summary.v1.json', summary)
    print(json.dumps({'preservation': summary['status'], 'canonical_append_events': 1}))

if __name__ == '__main__':
    raise SystemExit(main())
