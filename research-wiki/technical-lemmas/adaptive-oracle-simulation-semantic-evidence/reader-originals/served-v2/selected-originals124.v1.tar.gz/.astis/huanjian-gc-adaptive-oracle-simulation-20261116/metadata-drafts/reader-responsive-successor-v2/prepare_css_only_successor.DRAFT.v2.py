"""UNEXECUTED CSS-only selected-copy helper. No renderer, browser, API or Git.
Default is a plan only; ROOT must review and explicitly use --execute.
Preserves the prior candidate as the new original and changes one candidate CSS leaf.
"""
from pathlib import Path,PurePosixPath
import argparse,copy,hashlib,json,os,stat
ROOT=Path(__file__).resolve().parents[4]
OWN=Path(__file__).resolve().parent
OLD=ROOT/'.astis/huanjian-gc-adaptive-oracle-simulation-20261116/metadata-drafts/reader-preparation-v1/isolated-preview-v1'
NEW=OWN/'isolated-preview-v2'
CSS='assets/mgf-reader-overlay.css'
OLD_MANIFEST_SHA='221dd9b5ae7af9dc6fa0a1e5ab35241c7ca858357b7d69e94ec1d475c9294cd3'
INPUT_MANIFEST_SHA='a62c0621d77ac967a67192a33e3eac0eea2c2e55bbd45cb3eb9908eccd976f27'
BINDING='38ae6f3bf655bb00e7b6054b55d2936fc06d254393ff607d4336cdbfb85201f6'
MAX_LEAF=32*1024*1024
MAX_TOTAL=64*1024*1024
sha=lambda b:hashlib.sha256(b).hexdigest()
def require(ok,msg):
    if not ok:raise RuntimeError(msg)
def regular(base,name):
    require(isinstance(name,str) and name and '\\' not in name and not name.startswith('/') and '\x00' not in name,'Noncanonical selected path')
    require(all(x not in ('','.','..') for x in name.split('/')),'Unsafe selected path')
    name=str(PurePosixPath(name));p=base/name
    require(base.is_dir() and not base.is_symlink(),'Source base is not a regular directory')
    cursor=base
    for part in PurePosixPath(name).parts:
        cursor=cursor/part;require(not cursor.is_symlink(),'Selected path has a symlink component')
    fd=os.open(p,os.O_RDONLY|getattr(os,'O_NOFOLLOW',0))
    try:
        info=os.fstat(fd);require(stat.S_ISREG(info.st_mode) and info.st_size<=MAX_LEAF,'Selected leaf is not a bounded regular file')
        with os.fdopen(fd,'rb',closefd=False) as stream:data=stream.read(MAX_LEAF+1)
        after=os.fstat(fd);require(len(data)==info.st_size and after.st_size==info.st_size and after.st_mtime_ns==info.st_mtime_ns,'Selected leaf changed while read')
    finally:os.close(fd)
    return data,stat.S_IMODE(info.st_mode)
def encoded(value):return (json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode()
def write(path,data,mode=0o644):
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('xb') as f:f.write(data)
    os.chmod(path,mode)
    require(path.read_bytes()==data and stat.S_IMODE(path.stat().st_mode)==mode,'Written leaf differs')
def rows(base,selected,expected_count):
    require(isinstance(selected,list) and len(selected)==expected_count,'Explicit selection count differs')
    result={};total=0
    for row in selected:
        name=row['path'];require(name not in result,'Duplicate selected leaf')
        data,mode=regular(base,name)
        require(len(data)==row['bytes'] and sha(data)==row['sha256'],'Selected leaf hash/size mismatch: '+name)
        total+=len(data);require(total<=MAX_TOTAL,'Selected collection exceeds total-byte bound')
        result[name]=(data,mode)
    return result
def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--execute',action='store_true');args=ap.parse_args()
    if not args.execute:
        print('DRAFT ONLY; no copy/render/browser/Git/API operation. ROOT must review inputs and explicitly execute once.');return
    control_raw,unused=regular(OWN,'inputs.DRAFT.v2.json');k=json.loads(control_raw)
    mraw,unused=regular(OLD,'preview-freeze-manifest.json');fraw,unused=regular(OLD,'input-freeze-manifest.json')
    require(sha(mraw)==OLD_MANIFEST_SHA==k['old_preview_manifest']['sha256'],'Prior preview manifest differs')
    require(sha(fraw)==INPUT_MANIFEST_SHA==k['old_input_freeze_manifest']['sha256'],'Prior input freeze differs')
    m=json.loads(mraw);freeze=json.loads(fraw);prior=m['variants']['candidate']
    require(m['proof_commit']=='57016008083947405bc7d430838537014a40f987','Wrong mathematical snapshot')
    require(k['source_reviewed_binding_reference']==BINDING,'Binding reference changed')
    assignment_raw,unused=regular(ROOT,k['prior_actual_assignment']['file'])
    require(sha(assignment_raw)==k['prior_actual_assignment']['sha256'] and json.loads(assignment_raw)['source_reviewed_publication_binding_sha256']==BINDING,'Prior actual assignment binding reference differs')
    suffix,unused=regular(OWN,'inline-math-local-scroll.APPEND.DRAFT.css')
    expected_diff,unused=regular(OWN,'expected-single-CSS.v1-to-v2.exact.diff')
    require(sha(suffix)==k['CSS_append']['sha256'] and sha(expected_diff)==k['expected_CSS_exact_diff']['sha256'],'Reviewed CSS draft changed')
    inputs=rows(OLD/'input-snapshot',freeze['files'],118)
    served=rows(OLD/'fixtures/candidate',prior['files'],104)
    before,cssmode=served[CSS];after=before+suffix
    require(sha(before)==k['CSS_before']['sha256'] and len(before)==k['CSS_before']['bytes'],'Old CSS differs')
    require(sha(after)==k['expected_CSS_after']['sha256'] and len(after)==k['expected_CSS_after']['bytes'],'Expected CSS append differs')
    require(not NEW.exists(),'Preserve an existing/partial successor; never overwrite or retry blindly')
    NEW.mkdir()
    copy_records=[]
    for path,(data,mode) in inputs.items():
        write(NEW/'input-snapshot'/path,data,mode)
        copy_records.append({'collection':'input','path':path,'bytes':len(data),'sha256':sha(data),'mode':oct(mode)})
    write(NEW/'input-freeze-manifest.json',fraw)
    write(NEW/'prior-preview-freeze-manifest.original.json',mraw)
    write(NEW/'successor-inputs.original.json',control_raw)
    write(NEW/'css-only.exact.diff',expected_diff)
    write(NEW/'inline-math-local-scroll.append.css',suffix)
    newrows=[];delta=[]
    for row in prior['files']:
        path=row['path'];data,mode=served[path]
        write(NEW/'fixtures/original'/path,data,mode)
        changed=after if path==CSS else data
        write(NEW/'fixtures/candidate'/path,changed,mode)
        updated=copy.deepcopy(row);updated.update(bytes=len(changed),sha256=sha(changed));newrows.append(updated)
        if changed!=data:delta.append({'path':path,'old_bytes':len(data),'old_sha256':sha(data),'new_bytes':len(changed),'new_sha256':sha(changed)})
        copy_records.append({'collection':'served-original','path':path,'bytes':len(data),'sha256':sha(data),'mode':oct(mode)})
    require([x['path'] for x in delta]==[CSS],'Successor must change exactly one served CSS leaf')
    # Reopen every selected member and verify original sources remain byte-exact.
    for path,(data,mode) in inputs.items():
        require(regular(NEW/'input-snapshot',path)==(data,mode) and regular(OLD/'input-snapshot',path)==(data,mode),'Input copy/source identity changed')
    for path,(data,mode) in served.items():
        require(regular(OLD/'fixtures/candidate',path)==(data,mode) and regular(NEW/'fixtures/original',path)==(data,mode),'Original served baseline changed')
        require(regular(NEW/'fixtures/candidate',path)==(after if path==CSS else data,mode),'Candidate member identity changed')
    require(regular(OLD,'preview-freeze-manifest.json')[0]==mraw and regular(OLD,'input-freeze-manifest.json')[0]==fraw,'Prior control manifest changed')
    variants={'original':copy.deepcopy(prior),'candidate':copy.deepcopy(prior)}
    variants['candidate']['files']=newrows
    result={'schema':'bounded-reader-css-only-selected-copy-successor.v2','status':'CSS_ONLY_COPY_AND_BYTE_CLOSURE_COMPLETE; ACTUAL_BROWSER_PENDING',
      'proof_commit':m['proof_commit'],'metadata_version':m['metadata_version'],'lesson_sha256':m['lesson_sha256'],'publication_sha256':m['publication_sha256'],
      'input_freeze_manifest_sha256':sha(fraw),'source_reviewed_binding_reference':BINDING,'progress_caption':freeze['progress_caption'],
      'generator_kind':'ROOT-later execution of selected-copy plus one CSS append; original renderer NOT rerun',
      'generator_sha256':sha(Path(__file__).read_bytes()),'builder_file':str(Path(__file__).relative_to(ROOT)),
      'prior_renderer_provenance':{'prior_preview_manifest_sha256':sha(mraw),'original_renderer_sha256':m['generator_sha256'],'original_overlay_python_sha256':m['overlay_sha256'],'renderer_or_old_overlay_reexecuted':False},
      'css_overlay_sha256':sha(after),'variants':variants,'changed_files':delta,
      'baseline_contract':'Both new variants start from the prior candidate104 leaves. New original retains every baseline byte; only candidate/'+CSS+' has the exact appended rule.',
      'diagnostic_reference':k['diagnostic_reference'],'original_FAILED_reader_status_unchanged':True,
      'input118_and_served104_selected_only':True,'all_input_HTML_source_code_MathJax_lesson_publication_caption_and_binding_bytes_preserved':True,
      'render_or_Lean_build_executed':False,'browser_server_API_Git_or_canonical_writes':False,
      'reader_acceptance':'PENDING distinct actual successor run, glyph/MathML/local-scroll regression checks and independent image inspection; copy/static checks confer no acceptance.'}
    custody={'kind':'ROOT-later selected-copy byte custody, not original actor rendering','builder_sha256':sha(Path(__file__).read_bytes()),'inputs_DRAFT_sha256':sha(control_raw),
      'selected_input_count':len(inputs),'selected_served_count':len(served),'copy_records':copy_records,'strict_served_delta':delta,'all_selected_copies_reopened':True,
      'source_manifests_and_members_rechecked_unchanged':True,'no_recursive_directory_copy':True,'actual_renderer_or_browser_executed':False}
    write(NEW/'selected-copy-custody.actual.v2.json',encoded(custody))
    write(NEW/'preview-freeze-manifest.json',encoded(result))
    print(json.dumps({'status':result['status'],'preview_root':str(NEW.relative_to(ROOT)),'preview_manifest_sha256':sha(encoded(result)),
      'strict_served_delta':delta,'copied_inputs':len(inputs),'original_served':len(served),'candidate_served':len(newrows),'renderer_rerun':False,'browser_opened':False},ensure_ascii=False,indent=2))
if __name__=='__main__':main()
