from pathlib import Path
import sys,subprocess,json,datetime,time,hashlib,base64,os,stat
P=Path("/Users/zhouhuanjian/ASTIS-GC/.astis/semantic-neutral-20261111/kr_src_c47e12/phase6-metadata-link-only");ROOT=Path('/Users/zhouhuanjian/ASTIS-GC');S=P.parent;h=lambda b:hashlib.sha256(b).hexdigest()
child=r"""from pathlib import Path
import json,hashlib,stat,copy,subprocess,datetime
ROOT=Path('/Users/zhouhuanjian/ASTIS-GC');S=ROOT/'.astis/semantic-neutral-20261111/kr_src_c47e12';P=S/'phase6-metadata-link-only';h=lambda b:hashlib.sha256(b).hexdigest()
baseline=json.loads((P/'original-phases1-5-preservation-before.json').read_text());total=0
for r in baseline['checks']:
 base=S/r['phase'];mp=base/'hash-manifest.json';assert h(mp.read_bytes())==r['manifest_sha256'];m=json.loads(mp.read_text())
 dirs={base}
 for item in m['files']:
  path=base/item['path'];data=path.read_bytes()
  assert len(data)==item['bytes']and h(data)==item['sha256']and stat.S_IMODE(path.stat().st_mode)==0o444
  d=path.parent
  while d!=base:dirs.add(d);d=d.parent
 assert all(stat.S_IMODE(d.stat().st_mode)==0o555 for d in dirs)
 assert stat.S_IMODE(mp.stat().st_mode)==0o444
 total+=len(m['files'])+1
for name,sha in [('freeze_phase1.py','72567829f89d7cbf65e7125f40b484e61d05c72f6f1381fe00947382bc42d5b4'),('phase1-freeze-original-execution-receipt.json','89306f6c051f98d654ce62c198b9e7bdcae9918db781ddb46e13bc8033eaa3cb')]:
 path=S/name;assert h(path.read_bytes())==sha and stat.S_IMODE(path.stat().st_mode)==0o444;total+=1
assert total==403
guard=json.loads((P/'application-guard-and-provenance.json').read_text());C=ROOT/guard['target_path'];b=C.read_bytes()
assert h(b)==guard['expected_current_cell_sha256']and b==(P/'cell-before.exact.json').read_bytes()
c=json.loads(b);v=json.loads((P/'additive-evidence-proposal.json').read_text())['evidence']['independent_verification']
assert c['evidence']['independent_verification']==''and isinstance(v,str)and v.strip()
assert h((P/'additive-evidence-proposal.json').read_bytes())==guard['minimal_proposal_sha256']
assert h((ROOT/guard['report_original_path']).read_bytes())==guard['report_expected_raw_sha256']
out=copy.deepcopy(c);out['evidence']['independent_verification']=v;out['evidence']['independent_verification']='';assert out==c
argv=['git','rev-parse','HEAD'];r=subprocess.run(argv,cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
(P/'final-readonly-head.stdout').write_bytes(r.stdout);(P/'final-readonly-head.stderr').write_bytes(r.stderr)
(P/'final-readonly-head.receipt.json').write_text(json.dumps({'argv':argv,'exit_code':r.returncode,'stdout_sha256':h(r.stdout),'stderr_sha256':h(r.stderr)},indent=2)+'\n')
assert r.returncode==0 and r.stdout.decode().strip()==guard['target_HEAD']
failed=0;receipts=0
for rp in (P/'audit').glob('*.receipt.json'):
 rec=json.loads(rp.read_text());failed+=int(rec['exit_code']!=0);receipts+=1
 for k in ['stdout','stderr']:
  data=(rp.parent/rec[k]['path']).read_bytes();assert h(data)==rec[k]['sha256']and len(data)==rec[k]['bytes']
assert failed==1
out={'closure_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'original_phase1_5_files_checked':total,'all_original_bytes_and_modes_preserved':True,'target_cell_raw_sha256':h(b),'target_cell_untouched':True,'target_HEAD':guard['target_HEAD'],'old_field_value':'','only_proposed_field':'evidence.independent_verification','proposal_sha256':guard['minimal_proposal_sha256'],'evidence_report_sha256':guard['report_expected_raw_sha256'],'normal_API_calls_this_phase':0,'actual_recorded_failed_local_draft_executions':failed,'original_command_receipts_valid':receipts,'proposal_unapplied':True,'no_parent_or_private_glob':True}
(P/'final-originals-and-proposal-readback.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
"""
start=datetime.datetime.now(datetime.timezone.utc).isoformat();t0=time.monotonic();argv=['/opt/anaconda3/bin/python','-c',child]
r=subprocess.run(argv,cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
receipt={'schema':'original-phase6-final-execution-receipt-v1','actual_actor':'/root/krylov_fresh_source_c47e12','wrapper_argv':sys.argv,'wrapper_file_sha256':h(Path(__file__).read_bytes()),'child_argv':argv,'started_utc':start,'ended_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'elapsed_seconds':time.monotonic()-t0,'exit_code':r.returncode,'stdout_raw_base64':base64.b64encode(r.stdout).decode('ascii'),'stderr_raw_base64':base64.b64encode(r.stderr).decode('ascii'),'stdout_sha256':h(r.stdout),'stderr_sha256':h(r.stderr),'note':'Exact original stream bytes in base64; no normalization. Included in detached phase6 manifest. No cell write or normal API call.'}
rp=P/'original-execution-receipt.json';rp.write_text(json.dumps(receipt,indent=2)+'\n')
sys.stdout.buffer.write(r.stdout);sys.stdout.buffer.flush();sys.stderr.buffer.write(r.stderr);sys.stderr.buffer.flush()
if r.returncode:raise SystemExit(r.returncode)
rows=[]
for path in sorted(P.rglob('*')):
 if path.is_file()and path.name!='hash-manifest.json':
  assert not path.is_symlink();os.chmod(path,0o444);data=path.read_bytes();rows.append({'path':str(path.relative_to(P)),'bytes':len(data),'sha256':h(data),'mode':'0444'})
m={'schema':'immutable-phase6-metadata-link-only-manifest-v1','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'actual_author':'/root/krylov_fresh_source_c47e12','scope':'All own phase6 files except this detached manifest, including original failed frontier check/log, failed local draft, exact report and minimal string-link proposal. No prior phase/target/private content changed.','files':rows,'file_mode':'0444','directory_mode':'0555','normal_API_calls_this_phase':0,'proposal_unapplied':True}
mp=P/'hash-manifest.json';mp.write_text(json.dumps(m,indent=2)+'\n');os.chmod(mp,0o444)
for d in sorted([x for x in P.rglob('*')if x.is_dir()],key=lambda x:len(x.parts),reverse=True):os.chmod(d,0o555)
os.chmod(P,0o555)
print(json.dumps({'phase6_manifest_sha256':h(mp.read_bytes()),'phase6_original_execution_receipt_sha256':h(rp.read_bytes()),'proposal_sha256':h((P/'additive-evidence-proposal.json').read_bytes()),'evidence_report_sha256':h((P/'independent-verification-original-evidence-report.json').read_bytes()),'frozen_files':len(rows)+1,'target_cell_written':False,'normal_API_calls_this_phase':0,'exit_code':0},indent=2))

