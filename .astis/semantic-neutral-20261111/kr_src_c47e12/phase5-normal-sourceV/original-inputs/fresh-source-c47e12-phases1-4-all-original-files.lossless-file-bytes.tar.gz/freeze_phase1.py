from pathlib import Path
import sys,subprocess,json,datetime,time,hashlib,base64,os
root=Path("/Users/zhouhuanjian/ASTIS-GC/.astis/semantic-neutral-20261111/kr_src_c47e12")
phase=root/'phase1'
child_code=r"""from pathlib import Path
import json,hashlib,datetime,os,stat
root=Path("/Users/zhouhuanjian/ASTIS-GC/.astis/semantic-neutral-20261111/kr_src_c47e12")
p=root/'phase1'
mf=p/'mathematical-freeze.json'
expected='e16737181cd0139bb4afe3e1cfc54d26e9224181f559fcb49efa25f67cf8a3b0'
assert hashlib.sha256(mf.read_bytes()).hexdigest()==expected
freeze=json.loads(mf.read_text())
for row in freeze['core_artifacts']:
 b=(p/row['path']).read_bytes()
 assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256'],row['path']
manifest=json.loads((p/'input-manifest.json').read_text())
for name,row in manifest.items():
 b=(p/'inputs'/name).read_bytes()
 assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256'],name
rows=[]
for path in sorted(p.rglob('*')):
 if path.is_file() and path.name!='hash-manifest.json':
  assert not path.is_symlink(),str(path)
  os.chmod(path,0o444)
  b=path.read_bytes()
  rows.append({'path':str(path.relative_to(p)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'mode':'0444'})
out={'schema':'immutable-phase1-hash-manifest-v1','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reviewer':'/root/krylov_fresh_source_c47e12','source_id':'arXiv:2610.20492v1','source_sha256':'6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915','mathematical_freeze_sha256':expected,'scope':'All phase1 files except this detached hash manifest itself. Mathematical artifacts were frozen first. Original raw command outputs and failure streams were retained. No phase2 information was read.','files':rows,'directory_mode':'0555','file_mode':'0444'}
hm=p/'hash-manifest.json'
hm.write_text(json.dumps(out,indent=2)+'\n')
os.chmod(hm,0o444)
dirs=sorted([x for x in p.rglob('*')if x.is_dir()],key=lambda x:len(x.parts),reverse=True)
for d in dirs:os.chmod(d,0o555)
os.chmod(p,0o555)
bad=[]
for x in [p]+list(p.rglob('*')):
 wanted=0o555 if x.is_dir() else 0o444
 if stat.S_IMODE(x.stat().st_mode)!=wanted:bad.append(str(x))
assert not bad,bad
print(json.dumps({'phase1_manifest_sha256':hashlib.sha256(hm.read_bytes()).hexdigest(),'mathematical_freeze_sha256':expected,'files_in_manifest':len(rows),'total_frozen_files':len(rows)+1,'all_files_0444_and_dirs_0555':True,'phase2_seen':False},indent=2))
"""
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
t0=time.monotonic()
argv=['/opt/anaconda3/bin/python','-c',child_code]
result=subprocess.run(argv,cwd='/Users/zhouhuanjian/ASTIS-GC',stdout=subprocess.PIPE,stderr=subprocess.PIPE)
receipt={'schema':'original-phase1-freeze-execution-receipt-v1','wrapper_argv':sys.argv,'wrapper_file_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'child_argv':argv,'cwd':'/Users/zhouhuanjian/ASTIS-GC','started_utc':started,'ended_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'elapsed_seconds':time.monotonic()-t0,'exit_code':result.returncode,'stdout_raw_base64':base64.b64encode(result.stdout).decode('ascii'),'stderr_raw_base64':base64.b64encode(result.stderr).decode('ascii'),'stdout_sha256':hashlib.sha256(result.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(result.stderr).hexdigest(),'stream_encoding_note':'Base64 retains exact subprocess bytes; it is not a normalized or rewritten log.','boundary':'No verifier state transition. No target signature or phase2 packet received.'}
rp=root/'phase1-freeze-original-execution-receipt.json'
rp.write_text(json.dumps(receipt,indent=2)+'\n')
os.chmod(rp,0o444)
os.chmod(Path(__file__),0o444)
sys.stdout.buffer.write(result.stdout)
sys.stdout.buffer.flush()
sys.stderr.buffer.write(result.stderr)
sys.stderr.buffer.flush()
print(json.dumps({'original_execution_receipt_sha256':hashlib.sha256(rp.read_bytes()).hexdigest(),'receipt_path':str(rp),'freeze_script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'exit_code':result.returncode},indent=2))
raise SystemExit(result.returncode)

