"""Preserve actual v2 FAIL evidence and publish only explicit safe supplemental leaves."""
import datetime as dt
import hashlib
import json
from pathlib import Path

OWN=Path(__file__).resolve().parent
ROLE=OWN.parent
REPO=OWN.parents[3]
FRESH=REPO/'.astis/semantic-neutral-20261114/laplace_fresh_source_8d2a/reader_visual_supplement_v2'

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
def identity(p):return {'path':str(p.relative_to(REPO)),'bytes':p.stat().st_size,'sha256':sha(p)}

def main():
    result_path=OWN/'actual-result.json';receipt_path=OWN/'process/receipt.json'
    r=json.loads(result_path.read_text());p=json.loads(receipt_path.read_text());c=json.loads((OWN/'contract.v1.json').read_text())
    assert r['status']=='FAIL' and p['exit_code']==1 and p['exception'] is None
    assert len(r['checks'])==167 and len([x for x in r['checks'] if not x['pass']])==2
    assert len(r['screenshots'])==24
    assert p['actual_result_sha256']==sha(result_path)
    assert r['runner_sha256']==p['runner_sha256']==sha(OWN/'supplement.py')
    assert r['contract_sha256']==p['contract_sha256']==sha(OWN/'contract.v1.json')
    for stream in ['stdout','stderr']:assert sha(OWN/p[stream]['path'])==p[stream]['sha256']
    for row in r['screenshots']:assert sha(OWN/row['path'])==row['sha256']
    assert sha(ROLE/'selected-originals.manifest.v1.json')=='dbd220b80c7c6a5db609c89eae3b0fbd3630fd652dc7de39074ad7f0e84186eb'
    assert sha(ROLE/'reader-runtime-v3/presentation-selected-originals.manifest.v1.json')=='3cea83cd0e61df11cba9ab36dca51f1f64c79b18df1238b836d8f9c05f301451'
    old_result=ROLE/'reader-runtime-v3/browser-output-v1/candidate/actual-checks.json'
    assert sha(old_result)=='591b27fa052af6bfcfd65f1de388a3b866b1442ec129120c9f08ea86c3b051be'
    v3=ROLE/'reader-parent-supplement-v3'
    assert not (v3/'process').exists() and not (v3/'output').exists() and not (v3/'actual-result.json').exists()
    write(OWN/'unexecuted-v3-cancellation.reference-only.json',{'status':'CANCELLED_OPTIONAL_DUPLICATE_BEFORE_EXECUTION','ROOT_instruction':'Stop v3 execution; no fourth run. Fresh independent review closes necessary isolated-reader remainder using prior actual v1 evidence plus v2 full viewport evidence.','actual_tool_request_observation':'The v3 scoped execution tool request returned: aborted by user after 1171.0s','process_directory_exists':False,'output_directory_exists':False,'actual_result_exists':False,'checked_utc':dt.datetime.now(dt.timezone.utc).isoformat(),'unexecuted_contract_reference':identity(v3/'contract.v1.json'),'unexecuted_runner_reference':identity(v3/'supplement.py'),'these_prepared_files_are_not_execution_evidence':True,'new_browser_process_or_receipt_invented':False})
    primary=REPO/'.astis/huanjian-gc-integration-20261105/browser-venv/lib/python3.12/site-packages/playwright/driver/package/lib/server/screenshotter.js'
    bad_crops=['output/desktop-Radius-actual-visible-SVG.png','output/desktop-Structure-actual-visible-SVG.png']
    usable=['output/'+v+'-'+t+'-node-after-real-wheel-pointer.png' for v in ['desktop','mobile'] for t in ['Radius','Structure']]
    measurements=[]
    for case in r['cases']:
        g=case['final_node_geometry'];assert g['intersectionFraction']==g['labelVisibleFraction']==1 and g['effectiveFontPx']>=12
        measurements.append({'case':case['label'],'node_SVG_clipped_visible_fraction':g['intersectionFraction'],'rendered_core_label_clipped_visible_fraction':g['labelVisibleFraction'],'effective_font_px':g['effectiveFontPx'],'actual_native_wheel_and_pointer_exercised':True,'raw_case_status':case['status']})
    write(OWN/'screenshot-coordinate-diagnosis.v1.json',{'classification':'IMPLEMENTATION_FAILED_IN_OPTIONAL_CROP_CAPTURE','actual_process_exit_code':1,'actual_checks':167,'actual_false_checks':2,'actual_PNGs':24,'cause':'The optional page.screenshot(full_page=false) crop used document scroll offsets although Playwright clips to viewport coordinates. Both desktop crops capture lower detail instead of SVG; both mobile crop attempts throw before mobile post-crop checks.','primary_implementation':{'path':str(primary),'sha256':sha(primary),'lines172_179':primary.read_text().splitlines()[171:179]},'desktop_misnamed_crops_excluded_from_SVG_evidence':bad_crops,'mobile_not_executed_in_this_run':['detail region checks and screenshots','primary source link navigation','source body byte equality and header checks','source anchor and line-count checks'],'valid_actual_evidence_not_erased_by_overall_FAIL':'Four complete viewport PNGs and their node/core-label SVG clip measurements remain real observations. Desktop post-crop detail/source navigation completed. The process remains FAIL; no all-PASS assertion is made.','optional_v3_repeat':'Cancelled before execution after independent fresh review composed already accepted same-fixture v1 mobile detail/source/navigation with the new v2 node/label viewport evidence.','production_fixture_or_mathematics_change':False})
    freeze=FRESH/'READER_VISUAL_SUPPLEMENT_V2_FROZEN.json';review=FRESH/'reader-visual-supplement.review.json';review_run=FRESH/'reader-visual-supplement.review-run.json'
    f=json.loads(freeze.read_text());fr=json.loads(review.read_text());rr=json.loads(review_run.read_text())
    assert sha(review)=='ab8bcaf035826329ebcc3cf92cf11e301f95f0a18bdbb72e5f90fa0a0b356e9f'
    assert sha(review_run)=='4a5f9009b482188e81639395d870e5d3b5a944aad26eef6d25af249fd08c6713'
    assert f['review_result_sha256']==sha(review) and f['review_run_sha256']==sha(review_run)
    assert fr['finding_disposition']=='CLOSED_BY_ACTUAL_VIEWPORT_EVIDENCE_BOUNDED'
    assert rr['actual_v2_result']['sha256']==sha(result_path) and rr['actual_v2_receipt']['sha256']==sha(receipt_path)
    outcome={
      'schema':'raw-native-parent-supplement-outcome-v1',
      'status':'ACTUAL_V2_NATIVE_PROCESS_FAIL_RETAINED;BOUNDED_VIEWPORT_EVIDENCE_SUPPORTED',
      'actual_browser_target':r['actual_browser_target'],'actual_chrome_version':r['actual_chrome_version'],
      'actual_exit_code':1,'actual_process_status':'FAIL','actual_check_count':167,'actual_false_check_count':2,'actual_PNG_count':24,
      'actual_result':identity(result_path),'actual_OS_process_receipt':identity(receipt_path),'contract':identity(OWN/'contract.v1.json'),'executed_script':identity(OWN/'supplement.py'),
      'actual_process_started_utc':p['started_utc'],'actual_process_ended_utc':p['ended_utc'],
      'false_checks':[x['name'] for x in r['checks'] if not x['pass']],
      'usable_complete_viewport_PNGs':[identity(OWN/path) for path in usable],
      'four_node_and_core_label_measurements':measurements,
      'wrong_desktop_crops_retained_but_excluded_as_SVG_evidence':[identity(OWN/path) for path in bad_crops],
      'mobile_post_crop_detail_source_navigation_executed_in_this_run':False,
      'desktop_post_crop_detail_source_navigation_executed':True,
      'all_v2_contract_checks_passed':False,
      'request_console_fixture_observation':{'requests':len(r['requests']),'responses':len(r['responses']),'console_errors':len([x for x in r['console'] if x['type']=='error']),'page_errors':len(r['page_errors']),'external_requests':len(r['blocked_external_requests']),'all_frozen_inputs_unchanged_checks_passed':all(x['pass'] for x in r['checks'] if x['name'].startswith('unchanged-input:'))},
      'independent_fresh_visual_review_reference_only':{'reviewer':fr['reviewer'],'freeze':identity(freeze),'review_run':identity(review_run),'review_result':identity(review),'finding':fr['finding_id'],'disposition':fr['finding_disposition'],'composed_scope':fr['combined_scope'],'not_self_certified_by_native_actor':True},
      'composed_necessary_reader_scope':'Independent fresh review combines its previously accepted same-fixture v1 source/detail/navigation observations with the four new v2 complete viewport/node/core-label clip observations. This does not convert v2 FAIL to PASS and does not claim that unexecuted v2 mobile actions occurred.',
      'optional_v3':'Cancelled before execution; process/output/actual-result absent. Prepared contract/script are reference-only, not runtime evidence.',
      'original_evidence_preserved':{'original239_math_manifest_unchanged':True,'original356_presentation_manifest_unchanged':True,'original398_actual_flags_and_PNGs_unchanged':True,'actual_v2_result_receipt_streams_scripts_24PNGs_unchanged':True},
      'limitations':['No full SVG ID/default-fit/full-graph-fit assertion; exact full ID remains a detail-panel observation.','No physical-touch or production/deployed-site/post-status-pixel acceptance.','No new v4 browser run; v4 served-byte identity remains separately recorded.','No new mathematics, source audit, proof VERIFIED, normal V call or global closure.'],
      'normal_proof_V_calls':0,'proof_V_authorized':False,'production_Git_ledger_API_writes':0,
      'public_safe_selection':'Explicit whole leaves only; all24 original PNGs preserved with evidence-role labels. No chrome-tmp, browser profile/cache, private workspace guard, foreign state map or whole-ledger snapshot is selected. Raw stdout/stderr are unchanged.'
    }
    write(OWN/'native-supplemental-outcome.v1.json',outcome)
    chosen=[OWN/n for n in ['contract.v1.json','prepare.py','supplement.py','prior-measurement-diagnosis.v1.json','screenshot-coordinate-diagnosis.v1.json','unexecuted-v3-cancellation.reference-only.json','native-supplemental-outcome.v1.json','finalize_public_evidence.py','actual-result.json','process/receipt.json','process/stdout.raw','process/stderr.raw']]
    chosen += [OWN/x['path'] for x in r['screenshots']]
    assert len(chosen)==36 and len({str(x) for x in chosen})==36
    leaves=[]
    for path in chosen:
        assert path.resolve().is_relative_to(OWN) and path.is_file()
        relative=str(path.relative_to(OWN));assert not any(x in relative for x in ['chrome-tmp','cache','local-private','guard'])
        role='raw_process_or_supporting_evidence'
        if relative in usable:role='usable_actual_node_and_core_label_complete_viewport'
        elif relative in bad_crops:role='retained_diagnostic_wrong_crop_excluded_from_SVG_visibility_evidence'
        elif relative.endswith('-actual-case-failure.png'):role='retained_actual_failure_viewport'
        elif relative.endswith('.png'):role='actual_desktop_detail_or_source_observation'
        leaves.append({'path':relative,'bytes':path.stat().st_size,'sha256':sha(path),'evidence_role':role})
    write(OWN/'public-safe-selected-originals.manifest.v1.json',{'schema':'explicit-public-safe-raw-supplement-evidence-v1','source_root':str(OWN),'actual_run':'targeted v2 with exit1 retained','actual_contract_all_PASS':False,'original_PNGs_selected':24,'old239_and356_manifests_untouched':True,'new_v3_execution_evidence_included':False,'v3_files_reference_only':True,'chrome_tmp_cache_profiles_private_guards_foreign_maps_excluded':True,'raw_stdout_stderr_never_trimmed_or_rewritten':True,'leaves':leaves})
    print(json.dumps({'v3_process_absent_confirmed':True,'v2_actual_exit_code':1,'actual_false_checks':2,'actual_PNGs':24,'public_safe_leaf_count':len(leaves),'outcome_sha256':sha(OWN/'native-supplemental-outcome.v1.json'),'manifest_sha256':sha(OWN/'public-safe-selected-originals.manifest.v1.json'),'independent_fresh_freeze_sha256':sha(freeze)}))

if __name__=='__main__':main()
