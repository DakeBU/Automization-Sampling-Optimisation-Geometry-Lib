# Exact grid-alias v2 interface review

**Seal meaning / binder decision: ACCEPT. Source-graph admission remains pending the distinct extractor's exact frozen graph.** No target proof or VERIFIED decision is made.

The independent raw challenge was frozen first under `SHA256SUMS.raw` SHA-256 `88fafa8c4d8344c42e7310974d1bf770670a115d41a4e14307a5ecf5836176f8`. Only afterward were the exact `statement-seal-v2.json` (SHA-256 `5abb51d681187baa67985c54f942a670cdc79e65a5ef12393dcaf8c94a376285`) and `type-formation-and-seal-confirmation-v2.json` opened. Their predecessor/receipt/status/path descriptions are exposure, not independent proof or API evidence. Neither predecessor seal nor formation code/log was opened. No sibling graph has yet been read.

## Producer

The literal Fin d grid uses `(i.val+1/2)π/d`, the correct shift of paper indices 1,…,d. The only public mathematical range is source standing d≥2, with arbitrary k:ℤ. There is no κ, n, Gaussian, radius, trigonometric estimate or integrability premise. The source quantifier explicitly includes zero and negative integers.

The alias coefficient has no d factor inside it; that factor occurs once outside. Its guard is integer divisibility by 2d. The real base −1 has an integer exponent because the quotient has type ℤ; this retains negative aliases and parity. Since d≥2, the divisor is positive, and the quotient on the divisible branch is exactly the paper's a. The unused quotient off that branch has no new fallback semantics: the paper coefficient is exactly zero there. Zero frequency evaluates with quotient 0. This matches the independent raw stress instances and avoids a hidden natural-power restriction.

No EXCESS producer binder was found independently. The seal's own empty EXCESS list is not relied on.

## Private actual consumer

The consumer uses the actual finite sum of `cos(n θᵢ)/eigenvalueᵢ`; it does not assume a spectral-series identity or wrap an input certificate. Its radius/eigenvalue/grid are literal definitions. Its d≥2, κ≥2 and natural n with 1≤n<d match the source calculation; the positive integer n representation is faithful. It does not assert the low-mode formula for n=0 or for n≥d, and imposes no odd-n condition.

The positive mode j+1 is first cast to ℤ and then n is subtracted/added. Therefore negative j+1−n remains a valid negative frequency. The formula keeps both aliases. The d/√κ factor is correct: C7 supplies 1/√κ and a factor 2, product-to-sum supplies a half, and the alias theorem supplies d.

`Summable` is a conclusion about the actual real supported series, not a public binder or merely a totalized infinite-sum expression. It asserts signed-series summability; this interface does not separately advertise a new absolute-convergence output. Absolute convergence of C7, weighted summability, finite-sum exchange and bounded alias estimates remain internal proof ingredients. This is a legitimate deterministic intermediate without a new convergence hypothesis.

The candidate has substantive content that materially combines two results: canonical C7 expands each actual inverse eigenvalue and supplies convergence; the new alias theorem evaluates grid sums at n (to remove the constant) and at j+1−n/j+1+n after product-to-sum. Neither statement alone is this private conclusion. Actual authored use of both, rather than an unused call or wrapper, must still be checked after proof. The listed ASTIS parents are expected design, not compiled dependency evidence.

No EXCESS consumer binder or project-owned bundled Prop assumption was found. In particular, denominator safety, alias bounds, low-frequency vanishing and summability are not public premises.

## Limits and pending graph check

The formation confirmation binds the same two signature digests, and both were independently rehashed. It provides type-formation evidence only; this reviewer did not run Lean, inspect implementation or perform Mathlib/API retrieval. The alpha-renaming of the local alias coefficient to `a` is reported as a parser correction and has no apparent semantic role in the exact v2 statements; the old failed attempt was not reviewed or promoted.

The private consumer is not an identity of Gaussian expectations, the closed C8 means or tail resummations, variance/bias, TV, oracle or cost. The n<d source range remains important for removing the constant mode. No new source/Lean dependency graph is inferred from the proposed public-parent list.

The remaining preproof check is the independent extractor's exact source graph: full p3 coverage, nonmultiple denominator bridge, all-integer/parity handling, source d-only producer inputs, C7 and alias AND-use at the private consumer, finite weighted-series/product-to-sum/zero-mode discharge, and explicit exclusions of Gaussian and closed-tail work. This report will remain unchanged when that comparison is recorded separately.
