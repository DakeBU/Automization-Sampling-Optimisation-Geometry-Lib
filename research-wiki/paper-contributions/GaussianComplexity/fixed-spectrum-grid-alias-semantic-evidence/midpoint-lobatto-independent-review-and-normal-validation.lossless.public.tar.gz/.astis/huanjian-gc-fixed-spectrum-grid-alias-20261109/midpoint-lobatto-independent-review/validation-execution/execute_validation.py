"""One explicitly authorized conceptual Discovery transition with fresh guards."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import sys

ROOT = Path('/Users/zhouhuanjian/ASTIS-GC')
OUT = Path(__file__).resolve().parent
REVIEW = OUT.parent
ID = 'ASTIS-DISC-20261109-MidpointLobattoCosineCancellation'
ACTOR = '/root/cosine_topology_challenge'
CAND = ROOT / 'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-grid-alias-semantic-evidence/midpoint-lobatto-conceptual-candidate.json'
SOURCE = ROOT / '.astis/huanjian-resume-20261103/2610.20492v1.html'
DISC = ROOT / 'runs/substantive_discoveries.jsonl'
ADV = ROOT / 'runs/substantive_advances.jsonl'
CAND_SHA = 'b928bd44a996aa9086d214aff8e1746bef3149f7e62f104e7a16092be61a03e7'
REVIEW_SHA = 'ee31e3219d9f5f6518a6ff4bffba04fd71d0d88f674718b67c22374a8fe19573'
FREEZE_SHA = '4a2bfc58d7677b33fdb6009c2e275a79cdd53fa8895420639b33dcc41b1f357e'
SOURCE_SHA = '6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
API_ATTEMPTED = False


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def save(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2) + '\n')


def records(raw, label):
    assert raw and raw.endswith(b'\n'), label + ': incomplete tail; STOP, never repair'
    result = [json.loads(line) for line in raw.splitlines() if line.strip()]
    assert all(isinstance(r, dict) for r in result), label
    return result


def pins():
    assert digest(CAND.read_bytes()) == CAND_SHA, 'candidate pin'
    assert digest((REVIEW / 'review.md').read_bytes()) == REVIEW_SHA, 'review pin'
    assert digest((REVIEW / 'SHA256SUMS').read_bytes()) == FREEZE_SHA, 'review freeze'
    for line in (REVIEW / 'SHA256SUMS').read_text().splitlines():
        expected, name = line.split('  ', 1)
        assert digest((REVIEW / name).read_bytes()) == expected, name
    raw = SOURCE.read_bytes()
    assert len(raw) == 951991 and digest(raw) == SOURCE_SHA, 'raw source pin'
    candidate = json.loads(CAND.read_text())
    assert candidate['id'] == ID and candidate['metadata']['formal_refs'] == []
    assert candidate['metadata']['formal_transport_certificate'] is False
    for item in candidate['metadata']['exact_local_inputs']:
        p = ROOT / item['path']
        assert p.stat().st_size == item['bytes'] and digest(p.read_bytes()) == item['sha256'], str(p)
    manifest = json.loads((REVIEW / 'input-manifest.json').read_text())
    for item in manifest['prior_freezes_preserved']:
        p = ROOT / item['path']
        assert digest(p.read_bytes()) == item['sha256'], str(p)
        for line in p.read_text().splitlines():
            expected, name = line.split('  ', 1)
            assert digest((p.parent / name).read_bytes()) == expected, str(p.parent / name)
    return candidate


def protected():
    # Fresh current bytes; no stale pre-PROVED_LOCAL frontier/README baseline.
    paths = {ROOT / 'README.md', ADV, SOURCE, CAND,
             ROOT / 'website/content/graph_memory_index.json',
             ROOT / 'website/content/functor_hypergraph.json',
             ROOT / 'Libraries/frontloaded-shared-spine.json',
             ROOT / 'Libraries/conceptual-mirror-protocol.json',
             ROOT / 'tools/astis_advance.py', ROOT / 'tools/astis_harness.py'}
    # Only the expressly protected categories; no repository-wide semantic scan.
    for directory, pattern in [('AutoSamplingTheory', '*.lean'), ('Tests', '*.lean'),
                               ('research-wiki/frontier-cells', '*'),
                               ('website/content/publications', '*')]:
        paths.update(p for p in (ROOT / directory).rglob(pattern) if p.is_file())
    paths.update(REVIEW / name for name in ['review.md', 'input-manifest.json',
                 'selected-local-formulas.txt', 'validation-plan.json', 'SHA256SUMS'])
    for item in json.loads(CAND.read_text())['metadata']['exact_local_inputs']:
        paths.add(ROOT / item['path'])
    for item in json.loads((REVIEW / 'input-manifest.json').read_text())['prior_freezes_preserved']:
        p = ROOT / item['path']
        paths.add(p)
        for line in p.read_text().splitlines():
            paths.add(p.parent / line.split('  ', 1)[1])
    return {str(p.relative_to(ROOT)): {'bytes': p.stat().st_size, 'sha256': digest(p.read_bytes())}
            for p in sorted(paths)}


def replay():
    from tools import astis_advance
    dr, ar = DISC.read_bytes(), ADV.read_bytes()
    ds = astis_advance._replay_discoveries(records(dr, 'discovery ledger'))
    advances = astis_advance._replay_advances(records(ar, 'advance ledger'))
    return dr, ar, ds, advances


def target(states, candidate, status):
    own = states[ID]
    assert own['status'] == status and own['kind'] == 'conceptual-mirror', 'target state/kind'
    assert own['metadata'] == candidate['metadata'], 'target metadata drift'
    assert own['created_by'] != ACTOR, 'creator cannot self-validate'
    return own, {k: v for k, v in states.items() if k != ID}


def main(mode):
    global API_ATTEMPTED
    candidate = pins()
    dr, ar, ds, advances = replay()
    own, foreign = target(ds, candidate, 'raw')
    if mode == 'prepare':
        assert not (OUT / 'preflight-receipt.json').exists(), 'existing preflight; STOP'
        (OUT / 'discovery-ledger.before.jsonl').write_bytes(dr)
        (OUT / 'advance-ledger.before.jsonl').write_bytes(ar)
        save('own-state.before.json', own)
        save('all-foreign-discoveries.before.json', foreign)
        save('all-advance-states.before.json', advances)
        guard = protected()
        save('protected-files.before.json', guard)
        receipt = {'time_utc': datetime.now(timezone.utc).isoformat(), 'status': 'PREFLIGHT_PASS',
            'discovery_id': ID, 'actor': ACTOR, 'created_by': own['created_by'],
            'discovery_bytes': len(dr), 'discovery_sha256': digest(dr),
            'advance_bytes': len(ar), 'advance_sha256': digest(ar),
            'foreign_discovery_states': len(foreign), 'all_advance_states': len(advances),
            'protected_file_count': len(guard), 'metadata_exact': True,
            'pure_replay_only_no_recovery': True, 'fresh_current_frontier_README_baseline': True,
            'candidate_sha256': CAND_SHA, 'review_sha256': REVIEW_SHA,
            'review_freeze_sha256': FREEZE_SHA, 'raw_source_sha256': SOURCE_SHA}
        save('preflight-receipt.json', receipt)
        print(json.dumps(receipt))
        return
    assert mode == 'apply'
    assert not (OUT / 'api-invocation-intent.json').exists(), 'prior API attempt; STOP, no retry'
    assert dr == (OUT / 'discovery-ledger.before.jsonl').read_bytes(), 'discovery changed after preflight'
    assert ar == (OUT / 'advance-ledger.before.jsonl').read_bytes(), 'advance changed after preflight'
    assert foreign == json.loads((OUT / 'all-foreign-discoveries.before.json').read_text())
    assert advances == json.loads((OUT / 'all-advance-states.before.json').read_text())
    assert protected() == json.loads((OUT / 'protected-files.before.json').read_text()), 'protected drift'
    note = ('Independent ACCEPT_CONCEPTUAL_ONLY by ' + ACTOR + '; candidate sha256=' + CAND_SHA
        + '; review sha256=' + REVIEW_SHA + '; review freeze sha256=' + FREEZE_SHA
        + '; raw source sha256=' + SOURCE_SHA + '. Source/implementation conceptual relation only. '
        'formal_refs=[]; no Lean implication or formal transport certificate. No fresh original-SPHMC '
        'source review/status/completion, source V, whole-paper or Goal credit. Preserve all failure boundaries: '
        + candidate['metadata']['failure_boundary'] + ' Review and input evidence: '
        '.astis/huanjian-gc-fixed-spectrum-grid-alias-20261109/midpoint-lobatto-independent-review/.')
    save('api-invocation-intent.json', {'api': 'tools.astis_advance.transition_discovery',
        'discovery_id': ID, 'to_status': 'validated', 'actor': ACTOR, 'note': note,
        'authorized_calls': 1, 'manual_ledger_append': False})
    from tools import astis_advance
    API_ATTEMPTED = True
    astis_advance.transition_discovery(ID, 'validated', actor=ACTOR, note=note)
    after, ar_after, states_after, advances_after = replay()
    assert after.startswith(dr), 'original discovery byte prefix changed'
    appended = after[len(dr):]
    assert appended.endswith(b'\n') and len(appended.splitlines()) == 1, 'not exactly one append'
    event = json.loads(appended)
    assert event['event'] == 'discovery_transition' and event['discovery_id'] == ID
    assert event['from_status'] == 'raw' and event['to_status'] == 'validated'
    assert event['actor'] == ACTOR and event['note'] == note
    own_after, foreign_after = target(states_after, candidate, 'validated')
    assert foreign_after == foreign and ar_after == ar and advances_after == advances
    allowed = {'status', 'updated_at', 'latest_note', 'latest_actor'}
    assert {k: v for k, v in own.items() if k not in allowed} == {
        k: v for k, v in own_after.items() if k not in allowed}
    guard_after = protected()
    assert guard_after == json.loads((OUT / 'protected-files.before.json').read_text())
    (OUT / 'append.jsonl').write_bytes(appended)
    save('own-state.after.json', own_after)
    save('all-foreign-discoveries.after.json', foreign_after)
    save('all-advance-states.after.json', advances_after)
    save('protected-files.after.json', guard_after)
    receipt = {'time_utc': datetime.now(timezone.utc).isoformat(), 'result': 'VALIDATED_CONCEPTUAL_ONLY',
        'discovery_id': ID, 'actor': ACTOR, 'api_calls': 1, 'api_returned_normally': True,
        'manual_ledger_append': False, 'appended_records': 1,
        'before_bytes': len(dr), 'before_sha256': digest(dr),
        'after_bytes': len(after), 'after_sha256': digest(after),
        'append_bytes': len(appended), 'append_sha256': digest(appended),
        'old_raw_prefix_unchanged': True, 'no_tail_repair': True,
        'all_foreign_discoveries_unchanged': len(foreign), 'all_advance_states_unchanged': len(advances),
        'advance_ledger_bytes_unchanged': True, 'protected_files_unchanged': len(guard_after),
        'target_metadata_unchanged': True, 'formal_refs': [], 'formal_transport_certificate': False,
        'no_fresh_original_SPHMC_source_or_source_V_wholepaper_Goal_credit': True}
    save('execution-receipt.json', receipt)
    save('readback.json', {'discovery_id': ID, 'status': own_after['status'],
         'latest_actor': own_after['latest_actor'], 'created_by': own_after['created_by'],
         'all_foreign_discovery_states_equal': True, 'all_advance_states_equal': True,
         'protected_byte_manifest_equal': True, 'ledger_sha256': digest(after)})
    print(json.dumps(receipt))


if __name__ == '__main__':
    sys.path.insert(0, str(ROOT))
    try:
        main(sys.argv[1])
    except Exception as exc:
        save('STOP-receipt.json', {'mode': sys.argv[1], 'api_attempted': API_ATTEMPTED,
             'error_type': type(exc).__name__, 'error': str(exc), 'retry_permitted': False})
        raise
