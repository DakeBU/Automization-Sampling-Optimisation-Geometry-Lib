from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,stat

BASE=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
prior={
 'phase1':{'receipt':'ef13349dd0f6b894a6ba171184c65f19edb89b1e42e394ef7d0bd6d550320653','manifest':'d8e1def94411192058922b64b4b7cb61e1c26ceb3ade1816b69fce2ecd9788ce'},
 'phase2':{'receipt':'fe71e48e45deac24afca70fdc1050e65ab80639093d26e547bac7cd17dd61ceb','manifest':'0ca53710dee6acfe75295f075b7465fc5483b2fa57e6968ed0f59657458ab6a6'}
}
for name,expected in prior.items():
    d=BASE.parent/name
    for part in ['receipt','manifest']:
        assert sha(d/(part+'.json'))==expected[part]
        assert stat.S_IMODE((d/(part+'.json')).stat().st_mode)==0o444
    m=json.loads((d/'manifest.json').read_text())
    for row in m['payload_files']:
        p=d/row['path'];assert sha(p)==row['sha256'];assert stat.S_IMODE(p.stat().st_mode)==0o444
    assert stat.S_IMODE(d.stat().st_mode)==0o555
proposal=json.loads((BASE/'source_review_proposal.json').read_text())
assert set(proposal)=={'state','verdict','semantic_slots','deltas','source_review'}
assert proposal['source_review']['reviewer']=='/root/zeroquery_fresh_source_2f8a71'
assert proposal['source_review']['review_run_sha256']==sha(BASE/'independent_review.md')
assert Path(proposal['source_review']['run_artifact'])==BASE/'independent_review.md'
assert json.loads((BASE/'locator_audit.json').read_text())['all_38_pass']
assert json.loads((BASE/'fold_audit.json').read_text())['all_six_literal']
assert json.loads((BASE/'fold_audit.json').read_text())['step6_full_T']
assert json.loads((BASE/'exact_input_audit.json').read_text())['all_checks_pass']
payload=[]
# Complete inventory of this newly owned directory only; no filtering by purpose,
# success, extension, zero size, source identity, or command status.
for p in sorted(BASE.rglob('*')):
    if p.is_file() and p.name not in {'manifest.json','receipt.json'}:
        payload.append({'path':str(p.relative_to(BASE)),'bytes':p.stat().st_size,'sha256':sha(p),'frozen_mode':'0444'})
manifest={'schema_version':1,'phase':'PHASE3_SOURCE_CODE_READER_TEXT','actor':'/root/zeroquery_fresh_source_2f8a71','candidate_commit':'eed870294de059136900110ade59b4a292a126ad','prior_receipts':prior,'all_payload_files_without_filtering':True,'payload_files':payload,'self_reference_policy':'Only manifest.json and receipt.json excluded to avoid self-reference. Receipt binds manifest. Every file including both freezes0444.'}
mp=BASE/'manifest.json';mp.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
receipt={'schema_version':1,'phase':'PHASE3_FROZEN_PAUSE','actor':'/root/zeroquery_fresh_source_2f8a71','frozen_at_utc':datetime.now(timezone.utc).isoformat(),'candidate_commit':'eed870294de059136900110ade59b4a292a126ad','manifest_sha256':sha(mp),'proposal_sha256':sha(BASE/'source_review_proposal.json'),'review_run_sha256':sha(BASE/'independent_review.md'),'mathematical_judgment_sha256':sha(BASE/'mathematical_judgment.md'),'exposure_sha256':sha(BASE/'exposure.json'),'raw_reviewer_packet_sha256':sha(BASE/'inputs/reviewer_packet.json'),'canonical_reviewer_packet_sha256':'698e80cd3f8ff7485ee94c15987e8c2c7b72f6bf49da88f792c3cafb81f0e6a6','source_review_proposal_state':proposal['source_review']['state'],'verdict':proposal['verdict'],'blocking_deltas':sum(x['severity']=='blocking' for x in proposal['deltas']),'locator_rows_verified':38,'literal_lean_folds_verified':6,'step6_exact_full_T':True,'payload_file_count':len(payload),'prior_phase1_phase2_payloads_receipts_manifests_and_modes_verified_unchanged':True,'files_mode':'0444','directories_mode':'0555','exposure_qualification':'Earlier filename-only exposure and late root-relayed other-role reader finding preserved. No complete phase3 reader-blindness or pristine zero-knowledge claim.','authority':'Independent bounded semantic proposal only; no applied sourceV/normalV/native/kernel/site/browser/delivery/STAB/global/Goal verdict','next':'Pause; normal/native API remains separately unauthorized.'}
rp=BASE/'receipt.json';rp.write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
for p in BASE.rglob('*'):
    if p.is_file():p.chmod(0o444)
for p in sorted([p for p in BASE.rglob('*') if p.is_dir()],key=lambda p:len(p.parts),reverse=True):p.chmod(0o555)
BASE.chmod(0o555)
for row in payload:
    p=BASE/row['path'];assert sha(p)==row['sha256'];assert stat.S_IMODE(p.stat().st_mode)==0o444
for p in [mp,rp]:assert stat.S_IMODE(p.stat().st_mode)==0o444
print(json.dumps({'receipt':str(rp),'receipt_sha256':sha(rp),'manifest_sha256':sha(mp),'proposal_sha256':receipt['proposal_sha256'],'review_run_sha256':receipt['review_run_sha256'],'mathematical_judgment_sha256':receipt['mathematical_judgment_sha256'],'payload_files':len(payload),'all_hashes_modes_and_prior_phases_verified':True},indent=2))
