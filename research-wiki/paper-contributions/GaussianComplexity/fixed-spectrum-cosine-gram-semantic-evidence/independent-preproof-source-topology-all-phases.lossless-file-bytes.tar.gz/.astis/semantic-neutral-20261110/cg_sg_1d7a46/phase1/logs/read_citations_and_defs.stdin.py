from pathlib import Path
from hashlib import sha256
from bs4 import BeautifulSoup
p=Path('.astis/huanjian-resume-20261103/2610.20492v1.html')
b=p.read_bytes()
s=BeautifulSoup(b,'html.parser')
print('TITLE',s.title.get_text(' ',strip=True))
for m in s.find_all('meta'):
 if m.get('name','') in ['citation_title','citation_author','citation_date','citation_arxiv_id']:
  print(m)
for ident in ['A3.SS2.p8','A3.SS2.p9','S4.SS1.p1','S4.E11','S4.SS2.SSS0.Px1.p2','S4.Ex10','S4.Ex12']:
 e=s.find(id=ident)
 print('\nANCHOR',ident, 'FOUND',e is not None)
 if e:
  print(e.get_text(' ',strip=True))
  print('MATH',[(m.get('id'),m.get('alttext')) for m in e.find_all('math')])
print('\nCITATIONS')
for ident in ['S4.SS1','S4.SS2.SSS0.Px1','S4.SS2.SSS0.Px2','A3.SS2']:
 e=s.find(id=ident)
 print(ident,[(a.get('href'),a.get_text(' ',strip=True)) for a in e.find_all('a')])
