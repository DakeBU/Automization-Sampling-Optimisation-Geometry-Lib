# Independent type-only audit: actual matrix means

**No binder, definition or source-scope issue was found in the exact fixed
types.** This finding concerns type/source meaning only. No source graph,
implementation or target proof has been inspected; no topology, applicability,
compiled edge, normal intake or proof permission is admitted.

The actor's own raw freeze was completed before receiving/reading this type
packet and remains unchanged at
`30a7d626b681fb59c522969a9be91797d1ca794f5e0433ea6941dfc7064c3fa8`.
The formalizer's seal was formed separately; the chronology claimed here is
this actor's raw freeze before type exposure,
not a claim that the formalizer created its seal later.

## Exact binding

The reviewed packet is
`.astis/huanjian-gc-source-matrix-mean-20261112/selective-type-definition-packet.json`,
SHA-256 `efdba6eea9aa32da4cd9ea8d5022548ac128179f1ba73661fefa342f6ca4d95c`.
It names seal `b55a1acb837288d580a667903987e5f809610626eb4848c750ff8d3a6c01149b`
and definition context
`92117d5029065dcbd8e1a218bb175a7c32d37e9dd34ac2f5255125e2f9c48cfa`.
The exact signature strings independently hash to producer
`099bcbe9d6cc440754282873a7f1e1001584c3566fc771a70bf9f1a3846b85fe`
and consumer `00c0b050a632e03d9b169acdb6632ae85a9ec43cc2b5e8aa26b7b6152a711b7e`.
The literal-print hash, all six embedded excerpt hashes and all seven raw-source
span hashes were recomputed and matched. The seal/context digests match the
handoff; their separate unspecified serialization was not independently
reconstructed.

## Reconstructed statement and binder boundary

Natural d,q and the single standing logical input 2q+1<d determine the whole
experiment. The sample space is q+1 actual d-dimensional real Euclidean columns
with the explicitly written product of standard Gaussian measures. Actual row
i collects the physical i-th coordinate of each of those columns. There is no
arbitrary ambient measure, substituted row law, expected-matrix certificate,
conditioning event or free matrix family.

All remaining lets define literal objects. The binder table's DEFINITION label
is a separate definition audit, not another class of logical hypothesis. There
are no integrability, row-law, radial moment, per-matrix mean or deterministic
Gram-sum assumptions. The producer concludes both every actual Y_i being
integrable and every exact actual matrix mean. The consumer concludes both
actual finite sums being integrable and both exact Bochner integral
equalities. These conjunctions package outputs, not hidden input bundles.

The common scalar a is the canonical retained squared Euclidean radius under
stdGaussian E, divided by r=q+1. This is precisely the source coefficient once
the actual row law is identified internally with that canonical law. It is not
a separate per-row a_i or a caller-supplied actual-row moment value. No scalar
bias, positivity or range estimate on a is a new premise or conclusion here.

## Literal source objects, dimensions and endpoints

The source physical index is i.val+1, so the angle is exactly
((i.val+1-1/2)pi)/d. Feature indices are 0,...,q: the constant slot is 1 and
other slots are sqrt(2)cos(k theta_i). WithLp.toLp packages the actual scalar
coordinates as the Euclidean row, and WithLp.ofLp recovers that same row's
coordinates in its outer product; it does not replace the physical row by
orthonormal-basis coefficients.

The matrix paired indices put the Gaussian coordinate first and the feature
coordinate second. KroneckerMap's literal body confirms the entry order. Inside
the closed condition ||row_i||^2<=L, the scale is inverse d and the two outer
products are the actual row and deterministic t_i. Outside that condition the
actual matrix is zero. This is the source indicator, with no common-event
conditioning or division by event probability.

The producer's mean has exact factor a/d and I_r tensor t_i t_i^T. The private
consumer's first right-hand side is a times the identity on paired indices,
of dimension r^2. Its second right-hand side is the zero matrix. The weighted
sum uses precisely cos((2q+1)theta_i) and the same actual Y_i on the same
measure. The statements are integrals of the actual sums, matching the
displayed sums of expectations through an internal finite-linearity bridge
and the source's final zero-expectation sentence. The type does not silently
replace those actual sums by sums of supplied formal mean matrices.

The standing range includes q=0, r=1 and the single constant feature. Both
actual sums and n=1 weights remain. Nonzero d and r derive internally; there
is no q>0, separate denominator certificate, kappa, tau, norm/Gram bound,
tail probability or moment estimate as an added public input.

## Norm, completeness and totalized integration

The supplied instance prints identify the actual Matrix.Norms.L2Operator norm
and real normed-space instance, and a complete finite matrix space. The
embedded definitions identify this with the operator norm on finite Euclidean
spaces. This is an ordinary finite matrix expectation carrier; no operator-norm
estimate is asserted by selecting that norm. The norm construction's standard
linear-identification injectivity is not a new stochastic map or source
injectivity hypothesis.

Integrable expands to almost-everywhere strong measurability and finite
extended-norm integral. Its representative-existence clause is a standard
target predicate, not a replacement of the literal source Y definition or an
additional witness supplied by the caller. The Bochner integral definition
returns zero in noncomplete or nonintegrable cases. Here completeness is an
actual synthesized instance and the producer/consumer explicitly require
integrability as outputs, so the mean identities cannot be accepted merely by
invoking a nonintegrable zero default.

The scalar a is also defined by a totalized real Bochner integral. Its
retained-radius integrability is not a separate public output in these types;
it remains an internal source-faithfulness/applicability obligation. This is
not an excess binder or a statement blocker. A later proof/audit must account
for it, along with any canonical moment result's hypotheses and the actual
row-law transport. No type-only reasoning here discharges it.

## Remaining proof and source-coverage obligations

Actual physical-row law applicability under the standard-Gaussian column
product, cutoff scalar/matrix integrability, canonical-to-actual expectation
transport and literal matrix tensor/scalar algebra are unproved here. The
two Fact C.5 deterministic feature-sum identities must apply with the exact
grid, indices and n=2q+1. Their use with integrable actual Y maps must justify
the finite Bochner integral exchanges internally. Joint row independence is
not a new needed premise for those mean calculations.

The packet's consumer_edge is intended material use, not evidence of an actual
producer call. No existing theorem's name or prior compiled context has been
accepted as a current applicability proof. No new source radial moment
theorem, B-range/B-moment theorem, independence/iid claim, centered variance,
concentration, tail/bias bound or main result is admitted.

The packet declares formalizer_API_pristine=false. The root's disclosure of
prior known proof/API context and incidental standard-definition lookup
fragments is retained; no pristine-formalizer claim or prior-review replay is
made. The ordinary cstar norm identity/header and standard norm-construction
body appear only as the explicitly allowed definition context. This reviewer
has attempted no new target proof or API search.

Await the root-supplied source graph for a separate distinct
coverage/topology/applicability challenge. No graph has been read for this new
packet.
