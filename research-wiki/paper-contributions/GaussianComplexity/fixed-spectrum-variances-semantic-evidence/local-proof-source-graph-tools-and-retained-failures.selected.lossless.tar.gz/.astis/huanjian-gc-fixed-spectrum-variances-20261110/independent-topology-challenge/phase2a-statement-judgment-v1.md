# Variance strict projection: independent statement judgment v1

**Public Anchor mathematics/binders/definitions: ACCEPT. Private numerical statement/definitions: ACCEPT in its explicit local scope. Overall exact v1 binder-classification admission: HOLD for one metadata/scope repair.** No statement formula or semantic signature change is requested.

This judgment is frozen **before reading** `preseal-API-inventory-exposure-disclosure.json`. Exact input: `strict-preproof-seal-projection-v1.json`, SHA-256 `f1a37d117d750748d0d0ff6b229778d4b9c0e34a556f875679d8f05e0f387509`, binding full-seal SHA-256 `88802d72f44960bfd5be0c45b50a6e81f044dfd20b42d4b2109c821f43b8a0e5`. The full seal itself was not opened. Prior own RAW-FREEZE `8f5124e94368f11b70118d21e2b4cb0924f709de4a81b790790be6db7aaaa4c4` and raw checksum freeze `288e437e436ef169cc1e0716574996f3765e2361c8d2a725c427e2e41ae9d492` remain unchanged.

## Independent mathematical/definition decision

The public producer has exactly the original seven d/κ/n inputs. d:Nat, κ:Real and n:Nat are TYPING; hd:2≤d and hκ:2≤κ are STANDING hard-family inputs; hn:1≤n and hnd:n<d are SOURCE frequency conditions. There is no coordinate moment, independence, PSD, covariance, L2, integrability, variance or M-upper certificate as a public premise. No EXCESS public Anchor binder was found independently.

Its literal Fin d midpoint grid, eigenvalue/precision Λ, actual `multivariateGaussian 0 Λ⁻¹`, actual Q and actual norm-square mean M agree with the pinned raw source. Covariance is Λ⁻¹, not Λ; the displayed standard definition maps stdGaussian by its covariance square root. Source-domain positivity/invertibility and correct covariance interpretation still require internal proof.

The two MemLp2 outputs concern actual norm-square and Q, not their deterministic bounds. The two exact variance sums have the correct factor 2, denominator λᵢ² and cosine square. Both ≤2M outputs and 2M≤2d/√κ agree with Ex148–149/p8.2. M remains an actual Gaussian integral; its upper bound is not defined into M and is not a variance/fourth-moment premise.

The supplied standard definition makes evariance an actual lintegral of the squared centered norm and real variance its `ENNReal.toReal`. Infinity-to-zero and a totalized mean are real hazards. Under the actual probability law, produced MemLp2 supplies the required measurability/L1/finite-centered-L2 facts internally; it is not assumed to make the variance formula convenient. These facts must be proved, so this admission is not a variance API or constructor certificate.

The private Z is exactly `(−1)^n Q − 2τ‖x‖²` under the **same fixed diagonal Gaussian**. Its MemLp2 output and Var(Z)≤8M have substantive content that materially uses both new variance/L2 outputs. No independence between Q and norm-square is supplied or validly inferred. Actual material use and centering/variance identities remain postproof checks.

Its arbitrary 0≤τ≤1/2 domain is mathematically appropriate for this local numerical contrast bound. The lower bound permits |2τ|=2τ; the upper bound gives the constant 8M. The mode extension is only to all retained source modes 1≤n<d, not to n outside that range. This is broader than the concrete algorithm test's n=2q+1/τ=τ_dq assignment and is correctly disclosed as a private generalization.

No β, τ≤β/4, Mβ²≥320 or positive-mean hypothesis is needed for this variance-only private output. Their absence is not a missing assumption: mean separation, Chebyshev probability, actual rotated Y, algorithmic conditions and the full Ex25/26 application are explicitly **not claimed**. Any later such application must prove its concrete parameter/transport conditions internally.

## H-PRIVATE-TAU-ANCHOR-CLASSIFICATION

At `/binder_audit/15/class`, the grouped private hτ0/hτ1 inputs are tagged `STANDING`. That class means a field of an audited **source-wide** standing assumption in the Source Anchor taxonomy. Arbitrary τ and its two inequalities are not such fields: the paper defines a particular τ_dq and separately activates an algorithmic half-threshold. The proposed helper deliberately quantifies a new arbitrary local real parameter. Its correct scope disclosure does not make the STANDING tag correct.

The inequalities are mathematical logical inputs, so TYPING would be false. The arbitrary-τ statement is not the paper's literal SOURCE premise. Current authorization permits a private numerical generalization, not an unrequested RULED repair/ruling to the public source theorem. If these guards were promoted into the original public variance Anchor, they would be EXCESS; they are **not** defects of a properly separated private non-Anchor helper.

### Precise acceptable v2 repair

Keep every exact signature, formula, Gaussian/variance definition and public range unchanged. Preserve v1 and append a corrected immutable projection/seal-metadata successor:

1. Keep a public Source Anchor binder audit for the producer, using exactly the seven classifications above. It has no τ or τ-guard entry and no EXCESS.
2. Explicitly identify `actual_gaussian_contrast_variance_le` as a **private Internal Provider / local numerical generalization**, with no independent paper-Anchor assertion. Keep its original d/κ/n source-domain correspondence and τ:Real carrier information.
3. In a separately scoped private-hypothesis audit, record hτ0 and hτ1 as **assumed local numerical domain hypotheses**, separately or as an explicit pair. Record `source_anchor_classification: null` (or an equally explicit not-applicable field), `assumed_in_private_lemma: true`, `proved_fact: false`, `inherited_by_public_anchor: false`, and the exact inequalities. A descriptive logical-role field may say `private numerical-generalization domain`; this is not a sixth Source-Anchor taxonomy bin.
4. State that no SOURCE/STANDING/TYPING/RULED label is being invented for these logical private hypotheses. Preserve the concrete τ_dq/nonnegative/half-threshold source use as application context only. Later application to S_A(Y), n=2q+1, mean separation or concentration must supply its actual parameter and rotated-law adapters, not cite this generalization as source-wide authorization.

If the schema cannot represent that separation, exclude the private guards from the public Anchor's five-bin ledger and attach the explicit private domain ledger. Do not force them into STANDING/TYPING or pretend they are proved. No human source correction or public assumption addition is needed.

This is the only current admission HOLD. It is a classification/provenance repair, not a mathematical refutation or request to weaken/change either theorem.

## Exposure and pending stages

This actor's raw source cognition was frozen before the strict projection. During drafting, root relayed that the separate extractor had a matching private-STANDING HOLD, without supplying its graph or rationale. That is disclosed verdict exposure; no zero-verdict/anti-anchoring claim is made. The reasoning above is based on the already frozen raw τ definition and the private-versus-Anchor scope, not adoption of an unread graph verdict.

Root also reported accidental preseal API-name/signature-line exposure during definition auditing. Its detailed process disclosure has **not yet been read** for this judgment; no claim is made that root never saw APIs. This reviewer has seen only the authorized standard definitions and exact strict signatures, not a target proof plan/API inventory or implementation. The process record will be assessed separately after this freeze and cannot retrospectively change this source/statement reasoning without a versioned record.

No extractor graph, actual target proof, build, normal transition API, shared/site/ledger/Goal mutation or source V was performed. Final topology admission remains a separate stage after exact frozen machine graph input. This stage stops before that graph.
