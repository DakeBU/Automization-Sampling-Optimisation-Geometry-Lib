"""Inspect complete native expression evidence without rerunning Lean."""
import json
from evidence_preflight import N
from guard import O,create,dump,sha

directory = N/'inspection-v2-complete-emissions'
rows = [json.loads(line) for line in (directory/'declarations.ndjson').read_text().splitlines()]
nodes = [json.loads(line) for line in (directory/'expressions.ndjson').read_text().splitlines()]
assert len(rows) == 41 and len(nodes) == 52106
child_fields = {'app':['function','argument'],'lam':['domain','body'],
                'forall':['domain','body'],'let':['type','value','body'],
                'metadata':['body'],'projection':['expression']}
for ix,item in enumerate(nodes):
    assert item['id'] == ix
    node = item['node']; ctor = node['ctor']
    assert ctor in {'sort','const','bvar','literal',*child_fields}
    for key in child_fields.get(ctor,[]): assert 0 <= node[key] < ix
standard = {'propext','Classical.choice','Quot.sound'}
names = {r['name']['display']:r for r in rows}
assert len(names) == 41
for row in rows:
    assert row['kernelCheck'] == 'actual-type-and-value-kernel-addDeclCore-doCheck-true-PASS'
    assert not row['unsafe'] and not row['partial']
    for key in ['typeHasFVar','typeHasLooseBVars','typeHasMVar','valueHasFVar','valueHasLooseBVars','valueHasMVar']:
        assert row[key] is False
    assert {x['display'] for x in row['axioms']} <= standard
    assert 0 <= row['typeRoot'] < len(nodes) and 0 <= row['valueRoot'] < len(nodes)
P = 'AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumSourceGramRealization.actual_source_centered_gram_realizations'
T = '_private.Tests.GaussianComplexityFixedSpectrumSourceGramRealization.0.AutoSamplingTheory.Tests.GaussianComplexityFixedSpectrumSourceGramRealization.actual_source_gram_deviation_bounds'
own = {name for name in names if name.startswith(P) or name.startswith(T)}
assert len(own) == 4 and P in own and T in own
def constants(row): return {x['display'] for x in row['valueConstants']}
reachable = {P,T}; todo = [P,T]
while todo:
    name = todo.pop()
    for nxt in constants(names[name]) & own:
        if nxt not in reachable: reachable.add(nxt);todo.append(nxt)
assert reachable == own
assert P in constants(names[T])
assert 'AutoSamplingTheory.TechnicalLemmas.Probability.StdGaussianMoment.integrable_norm_sq_and_integral_stdGaussian' in constants(names[T])
assert {'AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumSourceMatrixMean.actual_source_truncated_matrix_means',
        'AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumCosineGram.actual_cosine_frame_gram'} <= constants(names[P])
result = {'status':'PASS','complete_declaration_rows':41,'complete_ExprDAG_nodes':52106,
          'unique_consecutive_nodes_backward_links_and_all_roots_checked':True,
          'all_type_value_closure_and_actual_kernel_check_markers_checked':True,
          'nonstandard_axioms':[],'standard_axioms':sorted(standard),
          'own_emissions':4,'handwritten_roots':2,'generated_private_helpers':2,
          'all_own_emissions_reachable_from_actual_P_T_values':True,
          'actual_canonical_parent_and_consumer_value_constants_checked':True,
          'Lean_rerun':False,'full_private_preservation_maps_exported':False,
          'declarations_sha256':sha((directory/'declarations.ndjson').read_bytes()),
          'expressions_sha256':sha((directory/'expressions.ndjson').read_bytes())}
create(O/'expression-evidence-crosscheck.bounded.json',dump(result))
print(json.dumps(result,indent=2))
