"""Carry selected, independently frozen file bytes; never author a verdict."""
from pathlib import Path
import gzip
import hashlib
import io
import re
import tarfile


def sha(data):
    return hashlib.sha256(data).hexdigest()


def put_new(path, data):
    path = Path(path)
    assert not path.exists(), path
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)


def archive_exact(files, target):
    assert files
    for name, data in files.items():
        p = Path(name)
        assert not p.is_absolute() and '..' not in p.parts
        assert isinstance(data, bytes)
        assert not re.search(rb'wxid_[a-z0-9]{8,}|/Library/Containers/com\.tencent', data, re.I)
    buf = io.BytesIO()
    with tarfile.open(fileobj=buf, mode='w') as tar:
        for name, data in sorted(files.items()):
            item = tarfile.TarInfo(name)
            item.size = len(data)
            item.mode = 0o444
            item.mtime = 0
            tar.addfile(item, io.BytesIO(data))
    put_new(target, gzip.compress(buf.getvalue(), mtime=0))
    with tarfile.open(target, mode='r:gz') as tar:
        assert {m.name for m in tar.getmembers()} == set(files)
        for name, data in files.items():
            assert tar.extractfile(name).read() == data
    target = Path(target)
    return {
        'archive': str(target), 'sha256': sha(target.read_bytes()),
        'bytes': target.stat().st_size, 'file_count': len(files),
        'files': [{'path': n, 'bytes': len(b), 'sha256': sha(b)}
                  for n, b in sorted(files.items())],
        'file_bytes_exact_not_filesystem_metadata': True,
        'raw_foreign_snapshots_included': False,
        'does_not_author_or_upgrade_any_independent_verdict': True,
    }
