"""Bounded archive closure and receipt checks, no mathematical/runtime replay."""
from pathlib import Path
import hashlib, json, tarfile
O = Path('.astis/semantic-neutral-20261113/structure_final_verifier_c91e')
F = Path('.astis/semantic-neutral-20261113/structure_final_native_f30b')
sha = lambda b: hashlib.sha256(b).hexdigest()
expected = {
    'JUDGMENT.md':'c473a52d60cf688447bd297c202f847d442396dbe57247c63689c9ef02e85082',
    'reader-assessment.json':'6e116efc9f407c4ddb2239c968672c3319ffc4c18f978c92ca784aa546d8da74',
    'gate-summary.json':'eb631585985bb8e72c4737cd4df8d4da6c31d5003920f57da048910fe902356e',
    'native-inheritance-check.json':'3cd37d07d15115aa2dc1747bf8b8b4a44f303a05f2cd02f8ae5edc7f16f1a8f9',
    'archive-closure.json':'ba168ab2de1ae28ea3e4fd1104313ea1e34663d5a619d0a0d4159ad1d43ef0dc',
    'selected-evidence.tar.gz':'b37c5a0a7d0ddb64332709849743762e5cb48e9adbb01a6fdde61a97c9fdb8ad'}
for f,h in expected.items():
    assert sha((F/f).read_bytes()) == h, 'final artifact hash mismatch'
assert (F/'selected-evidence.tar.gz').stat().st_size == 26849221
forbidden_keys = {'all_foreign_states','all_existing_frontier_hashes',
    'all_existing_tracked_fingerprints','actual_control_fingerprints',
    'tracked_git_index','advance_states','index_exact'}
def badkeys(x):
    if isinstance(x,dict):
        return any(k in forbidden_keys for k in x) or any(badkeys(v) for v in x.values())
    return isinstance(x,list) and any(badkeys(v) for v in x)
with tarfile.open(F/'selected-evidence.tar.gz','r:gz') as tf:
    members = tf.getmembers(); names = [x.name for x in members]
    assert len(names) == len(set(names)) == 1174, 'membership count'
    root = 'selected-evidence/'
    assert all(m.isfile() and m.name.startswith(root) and '..' not in Path(m.name).parts and not Path(m.name).is_absolute() for m in members), 'member kind or path'
    # These two files are the explicitly authorized task mathematical DAG and
    # declaration inventory, not repository preservation/control-plane data.
    math_private = {root+'native-original/local-only/expression-dag.json',
                    root+'native-original/local-only/full-declaration-inventory.json'}
    assert not any(n.endswith(('.gz','.zip','.tar','.private.json','.private.jsonl','.z')) or
                   'preservation_guard' in n or 'tracked-index' in n or
                   ('/local-only/' in n and n not in math_private) for n in names), 'private map or nested archive member'
    mb = tf.extractfile(root+'payload-manifest.json').read(); m = json.loads(mb)
    sealb = tf.extractfile(root+'manifest-seal.json').read(); seal = json.loads(sealb)
    assert sha(mb) == seal['payload_manifest_sha256'] == '94d0d37cde6df8ff32c3205b4cfe2f3667525497b81c19ad768ae798e47f7c5b'
    assert sha(sealb) == '0800989d2863cf1753de1e689730cd6e420d140847f08763961d30cf575d221e'
    paths = set()
    for s in m['files']:
        path = s['path']; assert path not in paths; paths.add(path)
        b = tf.extractfile(root+path).read()
        assert len(b) == s['bytes'] and sha(b) == s['sha256'], 'payload bytes'
        if path.endswith('.json'):
            try: j = json.loads(b)
            except (json.JSONDecodeError,UnicodeDecodeError): continue
            assert not badkeys(j), 'private preservation map key present'
    assert len(paths) == 1172 and set(names) == {root+x for x in paths} | {root+'payload-manifest.json',root+'manifest-seal.json'}
    native = json.loads(tf.extractfile(root+'native-original/selected-native-manifest.json').read())
    for s in native['selected']:
        assert root+'native-original/'+s['path'] in names
    assert len(native['selected']) == 231
gates = json.loads((F/'gate-summary.json').read_bytes())
assert gates['status'] == 'PASS' and gates['held_head'] == 'cf75c5f89a8f93b79c255fb43a942f6d1b7d49e4' and len(gates['commands']) == 4
for x in gates['commands']:
    rb = (F/x['receipt']).read_bytes(); assert sha(rb) == x['receipt_sha256']
    r = json.loads(rb); assert r['exit'] == 0 and r['observed_head_after'] == gates['held_head']
    for stream in ['stdout','stderr']:
        sb = (F/r[stream]['path']).read_bytes()
        assert len(sb) == r[stream]['bytes'] and sha(sb) == r[stream]['sha256']
result = {'status':'PASS_FINAL_PACKAGE_CLOSURE_AND_FOUR_REAL_CLI_RECEIPTS',
    'verifier_id':'structure_final_verifier_c91e','held_head':gates['held_head'],
    'final_reviewer_artifact_hashes':expected,'archive_regular_members':1174,
    'payload_files':1172,'exact_manifest_membership_and_all_payload_hashes_checked':True,
    'native_selected_originals_in_archive':231,'full_private_maps_or_indexes_exported':False,
    'authorized_task_mathematical_DAG_and_declaration_inventory_retained':True,
    'nested_archives':0,'all_four_actual_CLI_receipt_stdout_stderr_hashes_checked':True,
    'CLI_exit_codes':[x['exit'] for x in gates['commands']],
    'normal_VERIFIED_calls':0,'waiting_ROOT_READY':False,
    'historical_check_diagnosis':'An initial overbroad local-only path exclusion rejected the explicitly authorized mathematical ExprDAG and declaration inventory. The corrected exclusion permits exactly those two mathematical artifacts; private preservation maps remain forbidden. No mathematical/runtime/source check was replayed.'}
(O/'final-package-review.bounded.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
