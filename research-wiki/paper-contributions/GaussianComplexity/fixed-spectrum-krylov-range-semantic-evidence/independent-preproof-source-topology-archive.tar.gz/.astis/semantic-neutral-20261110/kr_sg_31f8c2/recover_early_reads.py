from pathlib import Path
import subprocess,json,hashlib,datetime
ROOT=Path(__file__).resolve().parent; REPO=ROOT.parents[2]
allowed=['AGENTS.md','docs/proof-digestion-protocol.md','docs/theorem-publication-protocol.md','docs/evidence-routed-memory-protocol.md','.agents/skills/astis-source-dependency-audit/SKILL.md']
commands=[
 ('pwd','4bf3c3',['pwd']),
 ('wc-protocols','b4db43',['wc','-l',*allowed]),
 ('proof-digestion-1-240','86dc28',['sed','-n','1,240p',allowed[1]]),
 ('proof-digestion-241-480','af443d',['sed','-n','241,480p',allowed[1]]),
 ('AGENTS-300-520','5a1bef',['sed','-n','300,520p',allowed[0]]),
 ('publication-1-160','9e01a9',['sed','-n','1,160p',allowed[2]]),
 ('own-inventory-C2-1-110','5319f6',['sed','-n','1,110p',str(ROOT.relative_to(REPO)/'commands/inventory-C2.stdout')]),
 ('own-pins-summary','434064',['python3','-c','import json,collections; p=json.load(open(".astis/semantic-neutral-20261110/kr_sg_31f8c2/source-pins.json")); print(collections.Counter((x["tag"],x["class"]) for x in p["elements"])); print("DISPLAY TABLES:"); print("\\n".join(str((x["id"],x["tag"],x["class"],x["lf_lines_1based_inclusive"])) for x in p["elements"] if x["tag"] in ["table","tr"]))']),
]
history=[]
for name,chunk,argv in commands:
    r=subprocess.run(argv,cwd=REPO,capture_output=True)
    pre=ROOT/'commands'/('replay-'+name)
    pre.with_suffix('.stdout').write_bytes(r.stdout);pre.with_suffix('.stderr').write_bytes(r.stderr)
    rec={'label':name,'original_host_tool_chunk_id':chunk,'argv':argv,'cwd':str(REPO),'this_reexecution_time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'returncode':r.returncode,'stdout_bytes':len(r.stdout),'stderr_bytes':len(r.stderr),'stdout_sha256':hashlib.sha256(r.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(r.stderr).hexdigest(),'historical_capture_limit':'These files are raw outputs of this explicitly labelled later replay. Historical outputs remain in the host tool transcript; they were not separately persisted contemporaneously. They are not silently relabelled as original historical receipts.'}
    pre.with_suffix('.receipt.json').write_text(json.dumps(rec,ensure_ascii=False,indent=2)+'\n');history.append(rec)

# Preserve the script revisions actually used, reconstructing the earlier exact
# bytes from the observed applied patches. They were not hashed at run time.
dest=ROOT/'script-versions';dest.mkdir(exist_ok=True)
a=(ROOT/'audit_raw.py').read_text()
old=a[:a.index("    elif mode=='inventory':")]+a[a.index('    else:raise ValueError(mode)'):]
(dest/'audit_raw.before-inventory.py').write_text(old)
r=(ROOT/'record_run.py').read_text().replace("label=sys.argv[1];cmd=sys.argv[2:];quiet=False\nif cmd and cmd[0]=='--quiet':quiet=True;cmd=cmd[1:]","label=sys.argv[1];cmd=sys.argv[2:]").replace('if not quiet:sys.stdout.buffer.write(r.stdout);sys.stderr.buffer.write(r.stderr)','sys.stdout.buffer.write(r.stdout);sys.stderr.buffer.write(r.stderr)')
(dest/'record_run.before-quiet.py').write_text(r)
g=(ROOT/'build_graph.py').read_text()
g=g.replace("E('e-gram-mean','C5.gram-expectation',['G.rows-law','E.gaussian-second','E.gram-expectation','C5.feature-gram'],['A3.SS2.p6'],'Standard Gaussian second moments are finite; finite matrix expectations and sums require no limiting argument. The row law discharges the Gaussian moment leaf.')","E('e-gram-mean','C5.gram-expectation',['E.gaussian-second','E.gram-expectation','C5.feature-gram'],['A3.SS2.p6'],'Standard Gaussian second moments are finite; finite matrix expectations and sums require no limiting argument.')")
g=g.replace("E('e-weighted-mean','C5.weighted-expectation',['G.rows-law','E.gaussian-second','E.gram-expectation','C5.feature-weighted'],['A3.SS2.p7'],'The standard Gaussian row law supplies the second moment; weighted deterministic feature cancellation supplies the zero.')","E('e-weighted-mean','C5.weighted-expectation',['E.gaussian-second','E.gram-expectation','C5.feature-weighted'],['A3.SS2.p7'])")
g=g[:g.index("tables=[n for n in ns")]+g[g.index("dump('coverage-summary.json',summary)"):]
(dest/'build_graph.v1.py').write_text(g)
out={'replayed_unpersisted_early_reads':history,'script_version_note':'Earlier script revisions are reconstructed from the actual applied patches, not contemporaneous hash receipts. Final scripts and all reconstructed versions enter the frozen payload manifest. No mathematical failure was suppressed; all command executions returned exit0.','initial_aggregate_protocol_read':{'original_chunk_id':'d52739','command':['cat',*allowed],'observed_truncation':True,'reported_nested_original_tokens':17071,'reported_outer_original_tokens':17568,'replay_raw_stdout':'commands/replay-initial-protocol-cat.stdout'},'initial_source_location_search':{'original_chunk_id':'1431b1','argv':['rg','-n','id="(S4|S4.SS1|S4.SS2|A3|A3.SS2)|Lemma 4.4|Krylov','.astis/huanjian-resume-20261103/2610.20492v1.html'],'observed_truncation':True,'reported_original_tokens':106223,'reported_lines':937,'exposure':'Visible matches included introduction/Krylov context, S4 outside selected subsections, and A3.SS3/A3.SS4 source lines. The full replay raw match output is retained without semantic reliance on those unselected regions.','replay_raw_stdout':'commands/replay-initial-rg.stdout'},'aggregate_inventory_tool_call':{'original_chunks':['a0c600','02241a','inventory-C2 stdout retained by capture runner'],'observed_outer_truncation':True,'reported_outer_original_tokens':13686,'persistence':'All three command stdout/stderr files were contemporaneously captured in commands/. The complete readable C2 source had already been read without truncation in read-C2.stdout. The beginning of the id inventory was additionally read by sed and is preserved by its labelled replay.'},'source_blinding':{'target_signatures_read':False,'target_definition_bodies_read':False,'implementation_Lean_read':False,'Mathlib_API_read_or_searched':False,'old_SG_TC_audit_verdict_read':False,'restricted_ATLAS_read':False,'list_agents_called':False,'subagents_spawned':False,'other_roles_workdirs_read':False,'initial_task_priming':'The assignment named the desired source range component and same-vector algebra before raw reading; it supplied no exact target signature or proof implementation.'},'pretraining_limit':'Ordinary pretrained mathematical knowledge was available. This run cannot attest zero-pretraining or absolute pristine reasoning. External mathematical leaves are identified as standard/invoked rather than falsely claimed to have been derived solely from the source.','scope_rule':'Only fixed original HTML and five explicitly allowed procedural documents were used as task input. No additional procedural document was requested or read. Writes stayed under this assigned root.','substantive_failure_status':'No Lean/API attempt or target proof search occurred; no mathematical route failure is being classified. Truncations and incidental original-source exposures are retained as observation/provenance limits, not mathematical refutations.'}
(ROOT/'exposure-and-command-history.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'replays':len(history),'history_written':'exposure-and-command-history.json','historical_capture_limits_exposed':True},indent=2))
