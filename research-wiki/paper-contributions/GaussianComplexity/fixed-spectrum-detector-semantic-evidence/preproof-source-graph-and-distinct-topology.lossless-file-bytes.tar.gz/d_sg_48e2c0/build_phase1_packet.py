"""Source-only artifact construction; no repository control-plane calls."""
from pathlib import Path
import hashlib
import importlib.util
import json
import re

OWN=Path(__file__).parent
spec=importlib.util.spec_from_file_location('source_extract',OWN/'extract_source.py')
x=importlib.util.module_from_spec(spec);spec.loader.exec_module(x)
SCOPES=['S4.p1','S4.Thmtheorem1','S4.p2','S4.SS1','S4.SS2','S4.SS3','A3.SS1','A3.SS2','A3.SS3','A3.SS4']

def dump(name,data):
    (OWN/name).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')

snippets=[]
selected=[]
for sid in SCOPES:
    n=x.PARSER.ids[sid]
    b=x.raw_slice(n)
    start=len(x.TEXT[:n.start].encode('utf-8'))
    end=start+len(b)
    assert x.RAW[start:end]==b
    name='selected_snippets/'+sid+'.html'
    (OWN/name).write_bytes(b)
    snippets.append({'source_id':sid,'file':name,'byte_start_inclusive':start,
                     'byte_end_exclusive':end,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),
                     'selection':'Complete original DOM element; no paragraph/formula truncation.'})
    selected += [z for z in [n,*x.descendants(n)] if z.tag in {'p','table','h2','h3','h4','h5','h6'}]
dump('selected_snippets/index.json',{'source_sha256':hashlib.sha256(x.RAW).hexdigest(),'snippets':snippets})

nodes={}
assignment={}
excluded={}

def node(nid,label,anchors,inputs,outputs,role='source-step',notes=''):
    assert nid not in nodes
    nodes[nid]={'id':nid,'label':label,'role':role,'source_anchors':anchors,
                'mathematical_inputs':inputs,'mathematical_outputs':outputs,
                'status':'SOURCE_ONLY_UNREVIEWED','notes':notes,'consumer_uses':[]}
    for a in anchors:
        n=x.PARSER.ids[a]
        for z in [n,*x.descendants(n)]:
            if z.tag in {'p','table'}:
                key=(z.start,z.end)
                assert key not in excluded
                assert key not in assignment or assignment[key]==nid,(a,nid,assignment.get(key))
                assignment[key]=nid

def exclude(anchors,reason):
    for a in anchors:
        n=x.PARSER.ids[a]
        for z in [n,*x.descendants(n)]:
            if z.tag in {'p','table'}:
                key=(z.start,z.end)
                assert key not in assignment
                excluded[key]=reason

node('sg:anchor','Raw Theorem 4.1 interface',['S4.Thmtheorem1'],
     ['delta fixed in (0,1); eventual integer d','2<=kappa<=d^(1-delta); 0<epsilon<=1/10'],
     ['Q_G(d,kappa,epsilon)>=(delta/256)sqrt(kappa)log d'],role='raw-source-anchor',
     notes='Exact sealed statement/Lean interface not read. Q_G definition remains unexpanded upstream scope.')
exclude(['S4.p1'],'Prior [22] result and §4.4 roadmap; not a mathematical premise of this proof slice.')
exclude(['S4.p2'],'Comparison with Theorem 3.1 and statement-scope discussion; not a dependency of the §4.3 route.')
node('sg:grid11','Eq.(11) deterministic cosine grid',['S4.SS1.p1.1','S4.E11'],
     ['integer d>=2; kappa>=2; i=1,...,d'],
     ['theta_i=(i-1/2)pi/d; lambda_i=(kappa+1)/2+(kappa-1)cos(theta_i)/2; Lambda=diag(lambda_i)'])
node('sg:hard-rotation','Hidden Haar eigenbasis and Gaussian target',['S4.SS1.p1.2'],
     ['Eq.(11); O~Haar(O(d)) independent of private randomness'],
     ['A=O Lambda O^T; f_A(x)=x^T A x/2; pi_A=N(0,A^-1)'])
node('sg:public-spectrum','Public spectral information',['S4.SS1.p2'],
     ['deterministic Lambda'],['Spectrum and normalizer may be public; only eigenbasis is hidden'],role='context')
node('sg:remark42','Remark 4.2 affine comparison and mechanism',['S4.Thmtheorem2'],
     ['same O for kappa=2 and general kappa; Eq.(11)'],
     ['A=(kappa-1)A_2-(kappa-2)I; one matrix reply converts either way',
      'Krylov statistic ratio small while target mean ratio is exp(-Theta(n/sqrt(kappa))); motivation for sqrt(kappa)log d'],role='context',
     notes='Not an alternative proof or an extra AND premise of §4.3.')
exclude(['S4.SS2.p1'],'Four-lemma roadmap, with each mathematical lemma inventoried separately.')
node('sg:deferred-rotation-citation','Deferred rotation source provenance',['S4.SS2.SSS0.Px1.p1'],
     ['adaptive queries; undisclosed rotational symmetry'],['Prior [22,Lemma 9.2] is cited; C.1 provides the selected source proof'],role='context')
node('sg:Kq-definition','Block Krylov space definition',['S4.SS2.SSS0.Px1.p2'],
     ['g_1,...,g_(q+1) in R^d; diagonal Lambda'],
     ['K_q=span{Lambda^j g_a:1<=a<=q+1,0<=j<=q}'],role='source-definition')
node('sg:krylov','Lemma 4.3 Krylov representation',['S4.Thmtheorem3'],
     ['adaptive q-query output X on hard family; q integer>=0; 2q+1<d'],
     ['On law-preserving extension, jointly iid g_a~N(0,I_d) with O^T X in K_q a.s.'])
node('sg:adaptive-coefficients','Output extra start and adaptive polynomial coefficients',['S4.SS2.SSS0.Px1.p3'],
     ['Lemma 4.3'],['q+1-th start accounts for output outside query/reply span',
      'degree<=q coefficients may depend on entire extended experiment; bound must be simultaneous in K_q'],role='context')
node('sg:Dn','High-frequency diagonal statistic',['S4.SS2.SSS0.Px2.p1'],
     ['q>=0; Eq.(11)'],['n=2q+1; D_n=diag(cos(n theta_i)); frequency above degree-q product modes'],role='source-definition')
node('sg:tau','Absolute concentration scale',['S4.Thmtheorem4.p1.1','S4.Ex13'],
     ['absolute C>0; q>=0; 2q+1<d; iid standard Gaussian starts'],
     ['tau=C[(q+1)sqrt(log d/d)+(q+1)(q+1+log d)log d/d]'],role='source-definition')
node('sg:uniform-krylov','Lemma 4.4 simultaneous Krylov bound',['S4.Thmtheorem4.p1.2','S4.Ex14'],
     ['Lemma 4.4 setup; tau<=1/2'],
     ['With probability>=.99: for EVERY u in K_q, |u^T D_n u|<=2tau||u||^2'],
     notes='Event is simultaneous, so no independence between a selected u and Gaussian starts is needed.')
node('sg:cosine-span-adapter','Affine spectrum and cosine basis',['S4.SS2.SSS0.Px2.p2'],
     ['lambda_i nonconstant affine in cos theta_i; kappa>=2'],
     ['K_q spanned by g_a coordinatewise cos(j theta_i), j<=q; uniform estimate independent of kappa'])
node('sg:algorithm-transfer-preview','§4.2 preview of output bound',['S4.SS2.SSS0.Px2.p3'],
     ['Lemmas 4.3 and 4.4; same extended experiment; orthogonality'],
     ['|X^T O D_n O^T X|<=2tau||X||^2 on the uniform event'],role='source-composition-preview',
     notes='The same composition is repeated at §4.3; it is not an extra independent premise.')
exclude(['S4.SS2.SSS0.Px3.p1'],'Target-moment roadmap without additional mathematical input.')
node('sg:target-moments','Lemma 4.5 exact means and variance bounds',['S4.Thmtheorem5.p1'],
     ['kappa>=2; U~N(0,Lambda^-1); 1<=n<d; varrho=(sqrt(kappa)-1)/(sqrt(kappa)+1)'],
     ['M=(d/sqrt(kappa))(1-varrho^(2d))/(1+varrho^(2d))',
      '(-1)^n mu_n=(d/sqrt(kappa))(varrho^n-varrho^(2d-n))/(1+varrho^(2d))',
      'Var(||U||^2),Var(U^T D_n U)<=2M<=2d/sqrt(kappa)'])
node('sg:target-bias','Lemma 4.5 normalized bias range',['S4.Thmtheorem5.p2'],
     ['Lemma 4.5 setup; d-n>=sqrt(kappa)'],
     ['(1-e^-4)e^(-3n/sqrt(kappa))<=|mu_n|/M<=e^(-2n/sqrt(kappa))'])
node('sg:target-coordinate-transfer','Target rotation to eigenbasis',['S4.SS2.SSS0.Px3.p2'],
     ['Y|O~pi_A; O orthogonal'],
     ['U=O^T Y~N(0,Lambda^-1); ||Y||^2=||U||^2; Y^T O D_n O^T Y=U^T D_n U'])
exclude(['S4.SS2.SSS0.Px4.p1'],'Admissibility roadmap and proof locator; Lemma 4.6 body is covered.')
node('sg:admissible','Lemma 4.6 admissible spectral class',['S4.Thmtheorem6'],
     ['every O in O(d); Eq.(11)'],['I_d <= A <= kappa I_d'])
exclude(['S4.SS3.p1'],'Proof roadmap: compare one test event; subsequent definition/estimates are covered.')
node('sg:contradiction-setup','Uniformly accurate bounded-query algorithm assumption',['S4.SS3.p2'],
     ['delta in (0,1); 2<=kappa<=d^(1-delta); 0<epsilon<=.1',
      'supposed algorithm uses at most q<=(delta/256)sqrt(kappa)log d queries'],
     ['Per-input TV(rho_A^Alg,pi_A)<=epsilon for every admissible A; hard family admissible'])
node('sg:test','Intrinsic signed statistic and strict event',['S4.SS3.p3'],
     ['n=2q+1; tau=tau_(d,q); kappa-1>0; first-kind degree-n T_n'],
     ['S_A(x)=(-1)^n x^T T_n((2A-(kappa+1)I)/(kappa-1))x-2tau||x||^2',
      'E_A={x:S_A(x)>0}'],role='source-definition')
node('sg:energy-geometry','Eigenvector energy weights and signed threshold',['S4.SS3.p4'],
     ['x!=0; orthogonal O; T_n(cos theta_i)=cos(n theta_i)'],
     ['w_i=|<x,Oe_i>|^2/||x||^2; normalized energy weights',
      'x in E_A iff (-1)^n sum_i w_i cos(n theta_i)>2tau; absolute size AND target sign'],
     notes='At x=0 the ratio is undefined; S_A(0)=0 excludes zero without a fallback.')
node('sg:algorithm-rates','Uniform eventual smallness of n/d and tau',['S4.SS3.SSS0.Px1.p1.1','S4.Ex20'],
     ['parameter range and q bound; fixed delta'],
     ['q+1<=d^((1-delta)/2)log d eventually; n=o(d)',
      'tau <= Cprime d^(-delta/2)(log d)^3 ->0 uniformly in allowed q,kappa'])
node('sg:algorithm-apply','Apply the two Krylov lemmas on a preserving extension',['S4.SS3.SSS0.Px1.p1.2','S4.Ex21'],
     ['large d depending only on delta; n<d; tau<=1/2; Lemmas 4.3 and 4.4'],
     ['Law of (O,X) preserved; |X^T O D_n O^T X|<=2tau||X||^2 with probability>=.99'])
node('sg:algorithm-probability','Algorithm event probability bound',['S4.SS3.SSS0.Px1.p1.3','S4.Ex22'],
     ['uniform output bound; S_A coordinate identity; preserving law'],
     ['On good event S_A(X)<=0; E_A[rho_A^Alg(E_A)]<=.01'])
node('sg:target-statistics','Target M,mu,beta definitions',['S4.SS3.SSS0.Px2.p1'],
     ['Lambda^-1 and D_n; M>0 required for beta'],
     ['M=tr(Lambda^-1); mu_n=tr(D_n Lambda^-1); beta=|mu_n|/M'],role='source-definition')
node('sg:bias-scale','Bias lower bound in the theorem range',['S4.SS3.SSS0.Px2.p2.1','S4.Ex23'],
     ['n=o(d); sqrt(kappa)<=d^((1-delta)/2)=o(d); q bound; Lemma 4.5 bias'],
     ['d-n>=sqrt(kappa) eventually; beta>=b d^(-delta/4), b=(1-e^-4)e^-3>0'])
node('sg:target-scale','Mean scale and signal to error/variance ratios',['S4.SS3.SSS0.Px2.p2.2','S4.Ex24'],
     ['exact M formula; varrho bound; d>=sqrt(kappa); bias and tau estimates'],
     ['varrho^(2d)<=e^-2<1/3; M>=d/(2sqrt(kappa))>=d^((1+delta)/2)/2',
      'tau/beta <= (Cprime/b)d^(-delta/4)(log d)^3 ->0; M beta^2 >= b^2 sqrt(d)/2 ->infinity'])
node('sg:choose-d0','One uniform eventual dimension threshold',['S4.SS3.SSS0.Px2.p2.3'],
     ['all preceding estimates uniform over kappa,q in theorem range; fixed delta'],
     ['d0(delta) ensures algorithm lemma side conditions; tau<=beta/4; M beta^2>=320'])
node('sg:target-L2','Target statistic mean and centered L2 variance bound',['S4.SS3.SSS0.Px2.p3.1','S4.Ex25'],
     ['fixed hard A; Y~pi_A; Z=S_A(Y); target moments; tau<=beta/4; tau<=1/2'],
     ['E Z=(beta-2tau)M>=beta M/2>0; Var(Z)<=(sqrt(2M)+2tau sqrt(2M))^2<=8M'],
     notes='Uses centered L2 triangle inequality, not independence of the two quadratic forms.')
node('sg:target-probability','Chebyshev yields .9 acceptance for each hard input',['S4.SS3.SSS0.Px2.p3.2','S4.Ex26'],
     ['positive E Z; finite variance; M beta^2>=320; E_A strict event'],
     ['For EVERY hard A: pi_A(E_A)=P(Z>0)>=1-Var(Z)/(E Z)^2>=1-32/(M beta^2)>=.9'])
node('sg:TV-average','Per-input TV and Haar-average contradiction gap',['S4.SS3.SSS0.Px3.p1.1','S4.Ex27'],
     ['hard inputs admissible; per-input TV bound; .9 target and .01 averaged algorithm acceptance'],
     ['.89<=E_A[pi_A(E_A)-rho_A^Alg(E_A)]<=epsilon<=.1'],
     notes='Event may depend on A; apply per-input TV first, average second.')
node('sg:contradiction','Contradiction and theorem conclusion',['S4.SS3.SSS0.Px3.p1.2'],
     ['inconsistent probability-gap chain; source query complexity interface'],
     ['No uniformly accurate algorithm at the supposed budget; claimed Theorem 4.1 bound'],
     notes='Exact final Q_G conversion is an unexpanded upstream source-definition boundary in phase 1.')

# Appendix C: supporting source calculations, not implementation dependencies.
node('bg:C1-oracle','Latent coordinates and redundant value oracle',['A3.SS1.p1'],
     ['u=O^T x; A=O Lambda O^T'],['reply Ax=O Lambda u; value=<x,Ax>/2 is redundant'])
node('bg:C1-plan','Deferred-revelation strategy and output start',['A3.SS1.p2'],
     ['adaptive query dependence on O'],['Reveal latent subspaces; Gaussianize new directions; final output preimage'],role='context')
node('bg:C1-notation','Conditional Haar-isometry notation',['A3.SS1.p3'],
     ['equal-dimensional subspaces F,G'],['P_F; unit spheres; Iso(F,G); invariant Haar law; conditional law notation'],role='source-definition')
node('bg:C1-haar-reveal','Fact C.1 conditional one-pair revelation',['A3.SS1.p4','A3.Thmtheorem1'],
     ['H-measurable F,G; conditional Haar J; H-measurable unit query'],
     ['uniform preimage/image direction; conditional residual restriction Haar on orthogonal complements'])
node('bg:C1-haar-proof','Fact C.1 rotational-invariance proof',['A3.SS1.p5','A3.SS1.p6','A3.SS1.p7'],
     ['Haar invariance; independent stabilizer rotation; inversion symmetry'],
     ['Fact C.1 laws from rotational and stabilizer invariance'])
node('bg:C1-state','Definition C.2 Haar state',['A3.SS1.SSS0.Px1.p1','A3.Thmtheorem2'],
     ['sigma algebra H; random subspace E'],
     ['E and OP_E H-measurable; O restricted to Eperp conditional Haar into (OE)perp'],role='source-definition')
node('bg:C1-updates','Fact C.3 auxiliary/image/preimage updates',['A3.SS1.SSS0.Px1.p2','A3.Thmtheorem3'],
     ['Haar state; independent auxiliary Z or H-measurable b/x'],
     ['Updated histories and spans remain Haar states; Eq.(27) includes explicit zero/nonzero preimage branches'])
node('bg:C1-update-proof','Proof of Fact C.3 including zero cases',['A3.SS1.SSS0.Px1.p3','A3.SS1.SSS0.Px1.p4','A3.SS1.SSS0.Px1.p5'],
     ['Fact C.1; projection relations; measurable zero/nonzero branch'],
     ['Conditional law unchanged by auxiliary randomness; residual isometry and OP_E updates'])
node('bg:C1-gaussianize','Fact C.4 Gaussianization',['A3.Thmtheorem4','A3.SS1.SSS0.Px1.p6'],
     ['fixed E with dim E<d; independent Z~N(0,I), v uniform on sphere(Eperp)'],
     ['g=P_E Z+||P_Eperp Z||v is standard Gaussian; v in E+span{g} a.s.'],
     notes='Uses independent Gaussian projection norm/direction and positive projected radius a.s.')
node('bg:C1-extension','Query padding and independent probability extension',['A3.SS1.SSS0.Px1.p7'],
     ['seed R independent of O; at most q measurable adaptive queries'],
     ['pad exactly q zero queries; x_(q+1)=X; adjoin iid Z_i independent of (R,O); original joint law unchanged'])
node('bg:C1-history','Haar-state induction along transcript',['A3.SS1.SSS0.Px1.p8'],
     ['H_0=sigma(R), E_0=0; Fact C.3'],
     ['H_i=H_(i-1) join sigma(Z_i,u_i,O Lambda u_i); E_i=span(E_(i-1),u_i,Lambda u_i); dim E_i<=2i<d'])
node('bg:C1-g','Adaptive Gaussian starts with conditional standard law',['A3.SS1.SSS0.Px1.p9'],
     ['Haar state; independent Z_i; Fact C.4; explicit x_i-perp zero/nonzero cases'],
     ['Eq.(28): law(g_i|H_(i-1))=N(0,I); u_i in E_(i-1)+span{g_i} a.s.'])
node('bg:C1-independent','Conditional constant law gives mutually independent starts',['A3.SS1.SSS0.Px1.p10'],
     ['Eq.(28); earlier g measurable in preceding history'],['g_1,...,g_(q+1) mutually independent standard Gaussians'])
node('bg:C1-span','Krylov span induction including final output',['A3.SS1.SSS0.Px1.p11'],
     ['Eq.(28); E_i update; S_i span of Lambda powers up to i'],
     ['E_q subset S_q; O^T X in E_q+span{g_(q+1)} subset K_q'])

node('bg:C2-B','Random design matrix B',['A3.SS2.p1'],
     ['r=q+1; iid starts; n=2q+1; cosine grid'],
     ['t_i=(1,sqrt(2)cos theta_i,...); iid gamma_i~N(0,I_r); row_i(B)=d^-1/2(gamma_i tensor t_i)^T'],role='source-definition')
node('bg:C2-plan','Uniformity via two Gram matrices',['A3.SS2.p2','A3.SS2.p9'],
     ['u=Bc'],['Control norm with B^T B and statistic with B^T D_n B simultaneously'],role='context')
node('bg:C2-C5','Fact C.5 range, expectations and row identities',['A3.Thmtheorem5'],
     ['B; 2q+1<d; Eq.(11)'],
     ['range B=K_q; E B^T B=I; E B^T D_n B=0; ||t_i||^2<=2r; unweighted/weighted cosine Gram identities'])
node('bg:C2-span','Invertible polynomial/cosine basis change',['A3.SS2.p3'],
     ['nonzero affine eigenvalue slope; Chebyshev leading coefficient'],['range B=K_q via triangular invertible degree<=q basis change'])
node('bg:C2-grid-gram','Discrete cosine orthogonality and Gram expectation',['A3.SS2.p4','A3.SS2.p5','A3.SS2.p6'],
     ['0<|k|<2d; sine telescoping; product-to-sum; E gamma gamma^T=I'],
     ['sum cos(k theta_i)=0; sum t_i t_i^T=dI; E B^T B=I'])
node('bg:C2-highfreq','High-frequency cancellation and weighted expectation',['A3.SS2.p7'],
     ['n=2q+1; 0<=j,k<=q; 1<=n±j±k<=4q+1<2d'],
     ['sum cos(n theta_i)t_i t_i^T=0; E B^T D_n B=0'])
node('bg:C2-row-norm','Cosine row norm bound',['A3.SS2.p8'],['|cos|<=1; r=q+1'],['||t_i||^2<=1+2q<=2r'])
node('bg:C2-C6','Fact C.6 simultaneous Gram concentration',['A3.Thmtheorem6'],
     ['absolute C sufficiently large; B; 2q+1<d'],
     ['With probability>=.995: ||B^T B-I||op<=tau and ||B^T D_n B||op<=tau'])
node('bg:C2-tail','Gaussian truncation event and probability',['A3.SS2.p10'],
     ['R_i=||gamma_i||^2; L=2r+3log(1000d); exponential moment and Markov'],
     ['P(R_i>2r+3x)<=e^-x; all R_i<=L event has probability>=.999'])
node('bg:C2-tail-bias','Truncation first-moment bias',['A3.SS2.p11'],
     ['Gaussian tail bound; tail-integral expectation identity'],['E[R_i 1_(R_i>L)]<=(L+3)/(1000d)'])
node('bg:C2-truncated-mean','Truncated matrices and radial scalar expectation',['A3.SS2.p12'],
     ['independent gamma_i; radial symmetry; Fact C.5; tail bias'],
     ['independent PSD Y_i; E Y_i=(a/d)(I tensor t_i t_i^T); 0<=a<=1; 1-a bound; sums aI and weighted zero'])
node('bg:C2-summand-norm','Centered summand bounds',['A3.SS2.p13'],
     ['Z_i=Y_i-E Y_i; row norm; truncation L'],
     ['||Z_i||op<=R_*=2r(L+1)/d; same weighted bound'])
node('bg:C2-variance','Matrix variance parameters',['A3.SS2.p14'],
     ['Gaussian fourth moments; Fact C.5; PSD truncation; |cos|<=1'],
     ['E[R_i gamma_i gamma_i^T]=(r+2)I; both centered sums have variance parameter<=v_*=2r(r+2)/d'])
node('bg:C2-Bernstein','Named bounded two-sided matrix Bernstein application',['A3.SS2.p15'],
     ['independent centered self-adjoint r^2-dimensional matrices; norm R_*; variance v_*'],
     ['P(||sum Z_i||op>t)<=2r^2 exp(-t^2/[2(v_*+R_*t/3)]); same cosine-weighted'],
     notes='General external standard theorem displayed but not proved or precisely cited at this site.')
node('bg:C2-two-events','Bernstein threshold and union bound',['A3.SS2.p16'],
     ['z=log(1000r^2); Delta=sqrt(2v_*z)+2R_*z/3'],
     ['each failure<=.002; simultaneous centered norm bounds with probability>=.996'])
node('bg:C2-intersection','Intersect concentration with truncation',['A3.SS2.p17'],
     ['truncation event; two norm events; truncated expectations'],
     ['Original Gram deviations<=Delta+(1-a),Delta with probability>=.995'])
node('bg:C2-constants','Absolute constant absorption into tau',['A3.SS2.p18'],
     ['2q+1<d implies d>=2,2r<=d; z=O(log d); L+3=O(r+log d)'],
     ['Delta+(1-a)<=c[r sqrt(log d/d)+r(r+log d)log d/d]; choose fixed C>=c'])
node('bg:C2-uniform-ratio','Uniform quadratic form comparison',['A3.SS2.p19'],
     ['Fact C.5 range; Fact C.6 simultaneous matrices; tau<=1/2'],
     ['For all u=Bc: norm^2>=(1-tau)||c||^2 and |form|<=tau||c||^2; ratio<=2tau; .995 weakened to .99'])

exclude(['A3.SS3.p1'],'C.3 roadmap; its recalled grid is already explicitly covered by Eq.(11).')
node('bg:C3-C7','Fact C.7 inverse spectrum cosine expansion',['A3.Thmtheorem7'],
     ['kappa>=2; 0<varrho<1'],
     ['2/[kappa+1+(kappa-1)cos theta]=(1/sqrt(kappa))(1+2 sum_(j>=1)(-varrho)^j cos(j theta)); absolute/uniform convergence'])
node('bg:C3-geometric','Geometric-series expansion and uniform majorant',['A3.SS3.p2'],
     ['0<varrho<1; geometric series; algebraic identities in sqrt(kappa)'],
     ['Fact C.7 rational identity; majorant sum varrho^j=varrho/(1-varrho)'])
node('bg:C3-C8','Fact C.8 exact finite-grid moments',['A3.Thmtheorem8'],
     ['1<=n<d; grid; inverse expansion'],['Exact M and signed mu_n formulas reused in Lemma 4.5'])
node('bg:C3-grid-alias','Full cosine-grid alias identity',['A3.SS3.p3'],
     ['integer k; split k in 2d Z versus complement'],
     ['sum cos(k theta_i)=d(-1)^a for k=2ad, zero otherwise; nonzero sine denominator only in complement'])
node('bg:C3-means','Gaussian means and series interchange',['A3.SS3.p4'],
     ['E U_i^2=1/lambda_i; Fact C.7 absolute convergence; finite grid'],
     ['M=sum 1/lambda_i; mu_n=sum cos(n theta_i)/lambda_i; interchange legitimate'])
node('bg:C3-M-sum','Sum inverse-spectrum constant mode',['A3.SS3.p5'],
     ['grid alias identity; inverse expansion; geometric sum'],['Exact M formula'])
node('bg:C3-mu-sum','Sum inverse-spectrum nth cosine mode',['A3.SS3.p6'],
     ['product-to-sum; disjoint j=n,2ad+n,2ad-n for 1<=n<d; geometric sums'],['Exact signed mu_n formula'])
node('bg:C3-assemble','Reuse of Fact C.8 for asserted means',['A3.SS3.p7'],['Fact C.8'],['Lemma 4.5 mean formulas'])
node('bg:C3-variance','Target diagonal Gaussian variances',['A3.SS3.p8'],
     ['independent target coordinates; Gaussian fourth moment; lambda_i>=1; |cos|<=1'],
     ['Both variances<=2M; M<=d/sqrt(kappa)'])
node('bg:C3-bias-ratio','Signed mean positivity and bias ratio',['A3.SS3.p9'],
     ['n<d; 0<varrho<1; exact moment formulas; M>0'],
     ['(-1)^n mu_n>0; beta=varrho^n(1-varrho^(2(d-n)))/(1-varrho^(2d)); fraction between 1-varrho^(2(d-n)) and 1'])
node('bg:C3-logrho','Integral bounds on log inverse varrho',['A3.SS3.p10'],
     ['kappa>=2; positive denominators throughout integration interval'],
     ['2/sqrt(kappa)<=log(1/varrho)<3/sqrt(kappa); e^(-3n/sqrt(kappa))<=varrho^n<=e^(-2n/sqrt(kappa))'])
node('bg:C3-bias-bound','Finite-grid tail and normalized bias estimate',['A3.SS3.p11'],
     ['d-n>=sqrt(kappa); log inverse varrho bounds; bias-ratio formula'],
     ['varrho^(2(d-n))<=e^-4; Lemma 4.5 bias lower/upper bounds'])
node('bg:C4-spectrum','Interior grid eigenvalues and conjugation bounds',['A3.SS4.p1'],
     ['Eq.(11); 0<theta_i<pi; O orthogonal'],['1<lambda_i<kappa; I<=A<=kappa I'])
node('bg:C4-regularity','Quadratic regularity and unique minimizer',['A3.SS4.p2'],
     ['spectral bounds; V_A(x)=x^T A x/2'],
     ['C-infinity; Hessian A; 1-strong convexity; kappa smoothness; unique zero minimizer'],role='context')
node('bg:C4-normalizer','Gaussian normalizer is public',['A3.SS4.p3'],
     ['positive definite A; Gaussian integration; orthogonal determinant invariance'],
     ['pi_A=N(0,A^-1); Z_A=(2pi)^(d/2)det(A)^(-1/2)=(2pi)^(d/2)det(Lambda)^(-1/2)'],role='context')

BRIDGES=[
 ('br:polynomial-conjugation','IMPLICIT_STANDARD_BRIDGE','§4.3 statistic/geometry and algorithm bound',
  ['kappa-1>0; Eq.(11); A=O Lambda O^T; polynomial T_n; scalar T_n(cos theta_i)=cos(n theta_i)'],
  ['T_n((2A-(kappa+1)I)/(kappa-1))=O D_n O^T'],
  'General polynomial/conjugation algebra is not printed as a separate proof.'),
 ('br:orthogonal-energy','IMPLICIT_STANDARD_BRIDGE','§4.3 energy paragraph; §4.2 target/algorithm coordinate transfers',
  ['O orthogonal; x!=0 for weights'],
  ['norm preserved; quadratic coordinate identity; weights>=0 and sum=1; at zero S_A=0'],
  'Parseval and matrix quadratic-form adapters are implicit; normalized geometry is restricted to nonzero x.'),
 ('br:event-measurability','IMPLICIT_STANDARD_BRIDGE','§4.3 E_A definition and final averages',
  ['fixed finite-dimensional parameters; kappa-1>0; polynomial/continuous S_A'],
  ['E_A Borel for each A; jointly measurable indicator in (A,x) required for kernel integration'],
  'The source uses event probabilities without a standalone measurability lemma.'),
 ('br:uniform-asymptotics','IMPLICIT_STANDARD_BRIDGE','§4.3 Ex20,Ex23,Ex24 and threshold paragraph',
  ['fixed delta in (0,1); allowed q,kappa range; fixed absolute C; positive b'],
  ['uniform eventual bounds, logarithmic-power limits, positive denominators and a single d0(delta)'],
  'Source states limits and uniformity; finite absorptions and explicit eventual quantifiers are compressed.'),
 ('br:law-extension','IMPLICIT_STANDARD_BRIDGE','C.1 setup; §4.3 algorithm acceptance probability',
  ['extension preserves original joint law; conditional iid Gaussian construction; simultaneous good event'],
  ['Output-event probability survives pushforward; P(X in E_A)=E_A rho_A^Alg(E_A)'],
  'Conditional probability integration and measurable-kernel representation are unexpanded general machinery.'),
 ('br:Gaussian-laws','AUTHOR_USED_STANDARD_INPUT','§4.2 target coordinate transfer; C.1,C.2,C.3,C.4',
  ['positive covariance; linear orthogonal transformations; independent Gaussian coordinates/projections'],
  ['Gaussian covariance transport; 2nd/4th moments; radial norm/direction; finite L2; Gaussian integral'],
  'General Gaussian facts are invoked but not all proved in this source slice.'),
 ('br:centered-L2','NAMED_STANDARD_INPUT','§4.3 Ex25',
  ['two centered square-integrable variables; deterministic 2tau>=0'],
  ['sd(Q-2tau N)<=sd(Q)+2tau sd(N)'],
  'No independence of the two quadratic forms is required; general L2 triangle theorem not proved here.'),
 ('br:Chebyshev','NAMED_STANDARD_INPUT','§4.3 Ex26',
  ['Z square integrable; E Z>0; denominator (E Z)^2>0'],
  ['P(Z>0)>=1-Var(Z)/(E Z)^2'],
  'Strict acceptance uses complement Z<=0; Chebyshev is named, not proved in this slice.'),
 ('br:TV-and-average','AUTHOR_USED_STANDARD_INPUT','§4.3 final paragraph/Ex27',
  ['event measurable for each A; pointwise per-input TV<=epsilon; hard family admissible; integrable probabilities'],
  ['pi_A(E_A)-rho_A^Alg(E_A)<=epsilon; averaging preserves upper/lower bounds'],
  'Per-input event may depend on A; this is not a TV-of-marginal-mixtures assertion.'),
 ('br:matrix-Bernstein','NAMED_EXTERNAL_STANDARD_INPUT','C.2 p15/Ex121',
  ['independent centered self-adjoint r^2-by-r^2 matrices; uniform norm R_* and variance bound v_*'],
  ['P(||sum Z_i||op>t)<=2r^2 exp(-t^2/(2(v_*+R_*t/3))) and weighted analogue'],
  'General theorem is stated at use, not proved; no precise numbered external citation at this use site.'),
 ('br:conditional-Haar-machinery','IMPLICIT_STANDARD_BRIDGE','C.1 conditional revelation/Gaussian independence',
  ['measurable subspaces/isometries; conditional laws; Haar invariance; independent auxiliary randomness'],
  ['conditional restriction/disintegration operations and constant-conditional-law independence'],
  'The source gives its geometric proof; general varying-subspace measure machinery is unexpanded.'),
 ('scope:QG-definition','SOURCE_SCOPE_GAP','Raw Theorem 4.1 and final query-bound conclusion',
  ['upstream definition of Q_G and algorithm/query-budget convention'],
  ['exact minimax lower-bound interface'],
  'Section 2 body not inspected under this phase. This is not a claim of an omission in the paper; no Lean definition substituted.')
]
bridges=[]
for bid,kind,use,inputs,outputs,note in BRIDGES:
    bridges.append({'id':bid,'classification':kind,'consumer_use_site':use,'required_inputs':inputs,
                    'output':outputs,'source_boundary':note,'status':'UNEXPANDED_SOURCE_ONLY'})
    nodes[bid]={'id':bid,'label':kind,'role':'standard-bridge' if bid.startswith('br:') else 'scope-gap',
                'source_anchors':[],'mathematical_inputs':inputs,'mathematical_outputs':outputs,
                'status':'UNEXPANDED_SOURCE_ONLY','notes':note,'consumer_uses':[]}
dump('standard_bridges.json',bridges)

edges=[]
def edge(eid,premises,consumer,use,discharge,logic='AND'):
    assert all(p in nodes for p in premises) and consumer in nodes
    record={'id':eid,'logic':logic,'premises':premises,'consumer':consumer,
            'consumer_use_site':use,'conditional_premise_discharge':discharge}
    edges.append(record)
    for p in premises:nodes[p]['consumer_uses'].append({'edge':eid,'consumer':consumer,'use_site':use,'logic':logic})

edge('e:grid-rotation',['sg:grid11'],'sg:hard-rotation','§4.1 after Eq.(11)','O Haar independent seed is part of family construction, not a result assumed from algorithm.')
edge('e:grid-Dn',['sg:grid11'],'sg:Dn','§4.2 D_n display','q>=0 defines integer n=2q+1.')
edge('e:K-definition',['sg:grid11'],'sg:Kq-definition','§4.2 K_q display','Diagonal Lambda and vector carriers supplied.')
edge('e:C1-Haar-fact',['bg:C1-notation','bg:C1-haar-proof','br:conditional-Haar-machinery'],'bg:C1-haar-reveal','C.1 Fact C.1','Condition on H; unit direction and equal-dimensional complementary carriers retained.')
edge('e:C1-update',['bg:C1-state','bg:C1-haar-reveal','bg:C1-update-proof'],'bg:C1-updates','C.1 Fact C.3','Auxiliary independence or history-measurability checked per update; zero/nonzero cases explicit.',logic='AND_WITH_EXHAUSTIVE_ZERO_NONZERO_CASES')
edge('e:C1-gaussianize',['br:Gaussian-laws'],'bg:C1-gaussianize','C.1 Fact C.4 proof','Orthogonal Gaussian projections independent; complementary Gaussian norm/direction independent; projected radius positive a.s. when dim E<d.')
edge('e:C1-histories',['bg:C1-extension','bg:C1-updates','bg:C1-oracle'],'bg:C1-history','C.1 Histories','Seed independent Haar initializes state; dim E_i<=2i<=2q<d.')
edge('e:C1-g',['bg:C1-history','bg:C1-gaussianize','br:Gaussian-laws','br:conditional-Haar-machinery'],'bg:C1-g','C.1 Gaussian vectors / Eq.(28)','dim E<d; zero branch g_i=Z_i and nonzero Gaussianized branch both included.',logic='AND_WITH_EXHAUSTIVE_ZERO_NONZERO_CASES')
edge('e:C1-independent',['bg:C1-g'],'bg:C1-independent','C.1 Independence','Earlier starts are measurable in H_(i-1); conditional law constant.')
edge('e:C1-span',['bg:C1-g','bg:C1-history','sg:Kq-definition'],'bg:C1-span','C.1 Krylov span / Ex83–84','Final output revealed as x_(q+1), not assumed in transcript span.')
edge('e:C1-lemma',['bg:C1-independent','bg:C1-span','bg:C1-extension'],'sg:krylov','Lemma 4.3 proved at C.1 end','2q+1<d is imported lemma side condition; extension preserves original law.')
edge('e:C2-C5',['bg:C2-B','bg:C2-span','bg:C2-grid-gram','bg:C2-highfreq','bg:C2-row-norm'],'bg:C2-C5','C.2 Fact C.5 proof','Nonzero affine slope from kappa>=2; cancellation frequencies strictly between 0 and 2d.')
edge('e:C2-tail-bias',['bg:C2-tail'],'bg:C2-tail-bias','C.2 truncation bias','Tail integral finite by exponential bound.')
edge('e:C2-truncmean',['bg:C2-C5','bg:C2-tail-bias','br:Gaussian-laws'],'bg:C2-truncated-mean','C.2 Ex107–110','Radial symmetry makes same scalar a across all rows.')
edge('e:C2-norm',['bg:C2-truncated-mean','bg:C2-row-norm'],'bg:C2-summand-norm','C.2 Ex111–112','Truncation makes deterministic bound R_*.')
edge('e:C2-var',['bg:C2-truncated-mean','bg:C2-C5','br:Gaussian-laws'],'bg:C2-variance','C.2 Ex113–120','PSD order handles truncation; cosine weights have absolute value<=1.')
edge('e:C2-Bernstein',['bg:C2-summand-norm','bg:C2-variance','br:matrix-Bernstein'],'bg:C2-Bernstein','C.2 Ex121','Rows independent, summands centered/self-adjoint, dimension r^2.')
edge('e:C2-events',['bg:C2-Bernstein'],'bg:C2-two-events','C.2 Ex122–124','z>0 and expansion of Delta; union bound for two events, no independence of them assumed.')
edge('e:C2-intersect',['bg:C2-two-events','bg:C2-tail','bg:C2-truncated-mean'],'bg:C2-intersection','C.2 Ex125–126','Original/truncated matrices equal on T; failure budget .004+.001.')
edge('e:C2-C6',['bg:C2-intersection','bg:C2-constants'],'bg:C2-C6','C.2 Fact C.6 end','One absolute C chosen sufficiently large; 2r<=d follows integer 2q+1<d.')
edge('e:C2-uniform',['bg:C2-C5','bg:C2-C6'],'bg:C2-uniform-ratio','C.2 Ex129–132','tau<=1/2 gives positive 1-tau and ratio<=2tau; same event for every c.')
edge('e:C2-lemma',['bg:C2-uniform-ratio','sg:tau'],'sg:uniform-krylov','Lemma 4.4 / C.2 end','Probability .995 weakened to .99; tau smallness remains conditional until §4.3.')
edge('e:C2-adapter',['bg:C2-span'],'sg:cosine-span-adapter','§4.2 affine-cosine paragraph','Nonzero kappa-1 prevents singular degree basis change.')
edge('e:preview',['sg:krylov','sg:uniform-krylov','br:orthogonal-energy'],'sg:algorithm-transfer-preview','§4.2 Ex15','Same iid starts; output inclusion a.s.; all-u event permits adaptive selection.')
edge('e:C3-expansion',['bg:C3-geometric'],'bg:C3-C7','C.3 Fact C.7','0<varrho<1 and denominator positivity; geometric majorant uniform in theta.')
edge('e:C3-means',['br:Gaussian-laws','bg:C3-C7'],'bg:C3-means','C.3 Ex140','Diagonal target variance 1/lambda_i; finite grid and absolute series.')
edge('e:C3-M',['bg:C3-grid-alias','bg:C3-C7','bg:C3-means'],'bg:C3-M-sum','C.3 EGx15','Only nonzero 2d aliases survive; geometric denominator positive.')
edge('e:C3-mu',['bg:C3-grid-alias','bg:C3-C7','bg:C3-means'],'bg:C3-mu-sum','C.3 EGx16','1<=n<d makes the three alias classes disjoint.')
edge('e:C3-C8',['bg:C3-M-sum','bg:C3-mu-sum'],'bg:C3-C8','C.3 Fact C.8 proof','Exact finite-grid formulas, not continuum approximations.')
edge('e:C3-assemble',['bg:C3-C8'],'bg:C3-assemble','C.3 proof of Lemma 4.5 opening','Reuses means without new assumptions.')
edge('e:C3-var',['sg:grid11','br:Gaussian-laws'],'bg:C3-variance','C.3 variance paragraph / EGx17','Independent coordinates, lambda_i>=1, cos^2<=1; fourth moments finite.')
edge('e:lemma45-moments',['bg:C3-assemble','bg:C3-variance'],'sg:target-moments','Lemma 4.5 means/variances','kappa>=2 and 1<=n<d retained.')
edge('e:C3-ratio',['bg:C3-C8'],'bg:C3-bias-ratio','C.3 Ex150–151','M>0, 0<varrho<1, n<d yield signed positivity and positive 1-varrho^(2d).')
edge('e:C3-bias',['bg:C3-bias-ratio','bg:C3-logrho'],'bg:C3-bias-bound','C.3 Ex158–159','Additional d-n>=sqrt(kappa) supplies finite-grid tail factor.')
edge('e:lemma45-bias',['bg:C3-bias-bound'],'sg:target-bias','Lemma 4.5 final display','Conditional separation from n<d retained.')
edge('e:target-coords',['sg:hard-rotation','br:Gaussian-laws','br:orthogonal-energy'],'sg:target-coordinate-transfer','§4.2 target transfer paragraph','Y conditional on O has covariance A^-1; constants do not depend on O.')
edge('e:C4-spectrum',['sg:grid11','sg:hard-rotation'],'bg:C4-spectrum','C.4 first paragraph','Interior angles and orthogonal conjugation.')
edge('e:admissible',['bg:C4-spectrum'],'sg:admissible','Lemma 4.6 / C.4 first paragraph','Holds for every O, enabling per-input guarantee.')
edge('e:C4-regular',['bg:C4-spectrum'],'bg:C4-regularity','C.4 second paragraph','Quadratic Hessian A; context only, not extra premise of Lemma 4.6.')
edge('e:C4-normal',['sg:hard-rotation','br:Gaussian-laws'],'bg:C4-normalizer','C.4 Ex160','Positive definite A; determinant fixed under orthogonal rotation.')
edge('e:public-spectrum',['bg:C4-normalizer'],'sg:public-spectrum','§4.1 public spectrum paragraph','Supports public-normalizer discussion; no unknown normalization oracle.')
edge('e:setup',['sg:admissible'],'sg:contradiction-setup','§4.3 first setup paragraph','Hard family admitted into every-admissible-A TV guarantee.')
edge('e:test',['sg:tau','sg:Dn'],'sg:test','§4.3 statistic/event definition','kappa>=2 ensures nonzero affine denominator; n integer.')
edge('e:geometry',['sg:test','sg:grid11','br:polynomial-conjugation','br:orthogonal-energy'],'sg:energy-geometry','§4.3 full energy paragraph','Normalized weights only for x!=0; zero excluded directly by raw statistic.')
edge('e:alg-rates',['sg:contradiction-setup','sg:tau','br:uniform-asymptotics'],'sg:algorithm-rates','§4.3 Ex20','q+1 absorption and uniform n=o(d),tau->0 for fixed delta; no added assumption.')
edge('e:alg-apply',['sg:algorithm-rates','sg:krylov','sg:uniform-krylov','br:orthogonal-energy','br:law-extension'],'sg:algorithm-apply','§4.3 law-preserving extension paragraph / Ex21','n<d and tau<=1/2 discharged by sufficiently large d(delta).')
edge('e:alg-prob',['sg:algorithm-apply','sg:test','br:polynomial-conjugation','br:event-measurability','br:law-extension'],'sg:algorithm-probability','§4.3 S_A(X)<=0 and Ex22','Signed form<=absolute form; strict event contained in bad event; no conditional independence assumed.')
edge('e:target-stats',['sg:target-moments'],'sg:target-statistics','§4.3 target definitions','M>0 from positive spectrum/exact formula makes beta valid.')
edge('e:bias-scale',['sg:algorithm-rates','sg:target-bias','sg:contradiction-setup','br:uniform-asymptotics'],'sg:bias-scale','§4.3 Ex23','n+sqrt(kappa)<=d eventually; q bound supplies exponential-to-power comparison.')
edge('e:target-scale',['sg:target-moments','sg:bias-scale','sg:algorithm-rates','bg:C3-logrho','br:uniform-asymptotics'],'sg:target-scale','§4.3 M lower bound and Ex24','d>=sqrt(kappa); positive beta,b,M; fixed absolute constants.')
edge('e:d0',['sg:algorithm-rates','sg:bias-scale','sg:target-scale','br:uniform-asymptotics'],'sg:choose-d0','§4.3 uniformity/choose-d0 paragraph','Single maximum of finitely many uniform eventual thresholds; only delta dependence.')
edge('e:target-L2',['sg:test','sg:target-statistics','sg:target-moments','sg:target-coordinate-transfer','bg:C3-bias-ratio','sg:choose-d0','br:centered-L2'],'sg:target-L2','§4.3 Ex25','Signed mean=beta M; tau<=beta/4 for mean and tau<=1/2 for variance; finite Gaussian L2.')
edge('e:target-prob',['sg:target-L2','sg:choose-d0','br:Chebyshev','br:event-measurability'],'sg:target-probability','§4.3 Ex26','E Z>=beta M/2>0; M beta^2>=320; strict positive event for every hard A.')
edge('e:TV-average',['sg:contradiction-setup','sg:admissible','sg:algorithm-probability','sg:target-probability','br:TV-and-average','br:event-measurability'],'sg:TV-average','§4.3 final paragraph / Ex27','Apply per-input event inequality before averaging Haar-induced A; .9-.01=.89.')
edge('e:contradiction',['sg:TV-average'],'sg:contradiction','§4.3 final a contradiction','Probability-chain inconsistency excludes the supposed algorithm; no query-complexity definition is needed just for this contradiction.')
edge('e:anchor',['sg:contradiction','scope:QG-definition'],'sg:anchor','End of proof of Theorem 4.1','Raw source conclusion; exact Q_G conversion needs its upstream definition, which remains uninspected in phase 1. This scope marker is not an extra public theorem premise.',logic='AND_WITH_UNEXPANDED_UPSTREAM_DEFINITION')

# Output selection is recorded separately from producer identity, so a bundled
# background fact is not read as a claim that all of its outputs are consumed.
OUTPUT_USES={
 'e:grid-rotation':{'sg:grid11':'deterministic diagonal Lambda'},
 'e:grid-Dn':{'sg:grid11':'theta_i coordinate grid'},
 'e:K-definition':{'sg:grid11':'diagonal Lambda'},
 'e:C1-gaussianize':{'br:Gaussian-laws':'independent orthogonal projections; complementary radius/direction; nonzero radius a.s.'},
 'e:target-coords':{'sg:hard-rotation':'A and target covariance A^-1', 'br:Gaussian-laws':'linear Gaussian covariance transport only','br:orthogonal-energy':'norm and quadratic-form coordinate identities only'},
 'e:C3-means':{'br:Gaussian-laws':'coordinate second moment E U_i^2=1/lambda_i only','bg:C3-C7':'inverse-spectrum series and absolute convergence'},
 'e:C3-var':{'sg:grid11':'lambda_i>=1 from affine cosine expression','br:Gaussian-laws':'independent coordinates and fourth moments only'},
 'e:C4-normal':{'sg:hard-rotation':'positive-definite rotated matrix and target','br:Gaussian-laws':'Gaussian normalization integral only'},
 'e:C2-truncmean':{'br:Gaussian-laws':'radial symmetry of standard Gaussian only','bg:C2-C5':'unweighted/weighted t_i Gram sums only','bg:C2-tail-bias':'truncation first-moment bound'},
 'e:C2-var':{'br:Gaussian-laws':'Gaussian fourth moments only','bg:C2-C5':'row norm and unweighted t_i Gram sum only','bg:C2-truncated-mean':'truncated matrices and their centering'},
 'e:target-stats':{'sg:target-moments':'the means M and mu_n and positive M; variance output not needed to define beta'},
 'e:bias-scale':{'sg:algorithm-rates':'n=o(d) only for gap condition','sg:target-bias':'lower bound on beta only','sg:contradiction-setup':'q,kappa theorem range only','br:uniform-asymptotics':'uniform eventual d-n condition and exponential-to-power absorption'},
 'e:target-scale':{'sg:target-moments':'exact M formula only','sg:bias-scale':'beta lower bound','sg:algorithm-rates':'tau rate only','bg:C3-logrho':'varrho<=exp(-1/sqrt(kappa)), weakened from displayed stronger bound','br:uniform-asymptotics':'uniform signal ratios and denominator positivity'},
 'e:target-L2':{'sg:target-moments':'both means and both variance bounds','sg:target-coordinate-transfer':'fixed-A target law/norm/form transport','bg:C3-bias-ratio':'signed target mean positive, so (-1)^n mu_n=beta M','sg:choose-d0':'tau<=beta/4 and tau<=1/2 only; 320 is consumed later','br:centered-L2':'variance triangle for the two correlated quadratic forms','sg:test':'definition Z=S_A(Y)','sg:target-statistics':'definitions beta,M,mu_n'},
 'e:target-prob':{'sg:target-L2':'positive mean lower bound and variance upper bound','sg:choose-d0':'M beta^2>=320 only','br:Chebyshev':'P(Z>0)>=1-Var/(E Z)^2','br:event-measurability':'fixed-A event is measurable'},
 'e:TV-average':{'sg:contradiction-setup':'per-input TV<=epsilon and epsilon<=.1','sg:admissible':'every hard A belongs to admissible spectral class','sg:algorithm-probability':'averaged acceptance<=.01','sg:target-probability':'pointwise target acceptance>=.9','br:TV-and-average':'per-input event TV bound then expectation monotonicity','br:event-measurability':'jointly measurable input-dependent event probabilities'},
 'e:anchor':{'sg:contradiction':'exclusion of supposed uniformly accurate bounded-query algorithm','scope:QG-definition':'upstream source definition required only to translate to exact Q_G conclusion'}
}
for e in edges:
    uses=OUTPUT_USES.get(e['id'],{})
    e['output_consumption']=[{'producer':p,'consumed_output':uses.get(p,
      'Outputs used at this source site as specified by producer mathematical_outputs together with conditional_premise_discharge; not a claim about implementation necessity.')} for p in e['premises']]

for nid,n in nodes.items():
    if not n['consumer_uses']:
        n['output_consumption_boundary']=('terminal raw source anchor; no implementation mapping' if nid=='sg:anchor'
          else 'context/provenance/preview node; not a necessary separate input of the §4.3 route')

inventory=[]
for n in selected:
    key=(n.start,n.end)
    sid=n.attrs.get('id') or ('offset:'+str(len(x.TEXT[:n.start].encode())))
    start=len(x.TEXT[:n.start].encode())
    raw=x.raw_slice(n)
    row={'source_id':sid,'tag':n.tag,'byte_start_inclusive':start,'byte_end_exclusive':start+len(raw),
         'raw_sha256':hashlib.sha256(raw).hexdigest(),'readable_text':x.normalized(n)}
    if n.tag.startswith('h'):
        row.update(disposition='EXCLUDED',reason='Navigation/statement-kind heading; full mathematical body separately inventoried.')
    elif key in assignment:
        row.update(disposition='NODE',node=assignment[key])
    elif key in excluded:
        row.update(disposition='EXCLUDED',reason=excluded[key])
    else:
        raise AssertionError(('UNASSIGNED SUBSTANTIVE REGION',sid,x.normalized(n)))
    inventory.append(row)

citations=[]
for scope in SCOPES:
    for n in x.descendants(x.PARSER.ids[scope]):
        if n.tag=='cite':
            links=[z.attrs.get('href') for z in x.descendants(n) if z.tag=='a']
            citations.append({'scope':scope,'text':x.normalized(n),'source_byte_start':len(x.TEXT[:n.start].encode()),
                              'links':links,'disposition':'EXCLUDED',
                              'reason':'Prior-work comparison/construction inspiration/deferred-rotation provenance; selected source supplies its own statements and C.1 proof. Not a separate extra AND premise; external cited paper not read.'})

dump('coverage_inventory.json',{'status':'EXTRACTOR_DRAFT_NOT_INDEPENDENTLY_REVIEWED','scope':SCOPES,
     'coverage_contract':'Every selected paragraph/display receives exactly one NODE or EXCLUDED(reason); headings excluded as navigation. Counts are not proof.',
     'items':inventory,'external_citation_occurrences':citations})
dump('source_graph.json',{'schema':'source-only-raw-first-v1','status':'EXTRACTED_UNREVIEWED',
     'source_sha256':hashlib.sha256(x.RAW).hexdigest(),
     'anchor_interface':'raw source only; sealed signature not exposed in phase 1',
     'implementation_dependencies':None,
     'route_logic':'One source route; algorithm rejection AND target acceptance AND per-input TV. No author alternative OR route in selected slice.',
     'case_logic':'C.1 zero/nonzero branches are exhaustive cases joined for a single theorem, not alternative whole-proof routes.',
     'nodes':list(nodes.values()),'hyperedges':edges,'alternative_OR_routes':[],
     'independent_review':{'status':'PENDING','extractor_may_approve_own_coverage':False}})

readable=[]
for sid in SCOPES:
    readable.append('SOURCE_ID '+sid)
    for n in [x.PARSER.ids[sid],*x.descendants(x.PARSER.ids[sid])]:
        if n.tag in {'p','table','h2','h3','h4','h5','h6'}:
            readable.append((n.attrs.get('id') or n.tag)+'\n'+x.normalized(n)+'\n')
(OWN/'selected_source_readable.txt').write_text('\n'.join(readable))
dump('reviewer_packet.json',{'purpose':'Independent source topology review, not proof verification',
    'read':['selected_snippets/index.json','selected_snippets/*.html','source_graph.json','coverage_inventory.json','standard_bridges.json'],
    'withhold_extractor_private_cognition':'phase1_raw_cognition.md',
    'implementation_Lean_allowed':False,'independent_review_status':'PENDING'})
print(json.dumps({'snippets':len(snippets),'coverage_regions':len(inventory),'source_nodes':len(nodes),'hyperedges':len(edges),
                  'notice':'Artifact-shape counts only; not mathematical proof or independent coverage approval.'}))
