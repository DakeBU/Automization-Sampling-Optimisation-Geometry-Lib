import Mathlib

open scoped BigOperators
open Filter

-- Type formation only. These Prop-valued definitions prove no assertion.
def producerStatement {κ : ℝ} (hκ : 2 ≤ κ) : Prop :=
  let r : ℝ := (Real.sqrt κ - 1) / (Real.sqrt κ + 1)
  (∀ θ : ℝ,
    2 / (κ + 1 + (κ - 1) * Real.cos θ) =
      (1 / Real.sqrt κ) *
        (1 + 2 * ∑' j : ℕ, (-r) ^ (j + 1) * Real.cos (((j + 1 : ℕ) : ℝ) * θ))) ∧
  (∀ θ : ℝ,
    Summable (fun j : ℕ => ‖(-r) ^ (j + 1) * Real.cos (((j + 1 : ℕ) : ℝ) * θ)‖)) ∧
  TendstoUniformly
    (fun N : ℕ => fun θ : ℝ =>
      ∑ j ∈ Finset.range N, (-r) ^ (j + 1) * Real.cos (((j + 1 : ℕ) : ℝ) * θ))
    (fun θ : ℝ => ∑' j : ℕ, (-r) ^ (j + 1) * Real.cos (((j + 1 : ℕ) : ℝ) * θ))
    atTop

def consumerStatement {d : ℕ} (hd : 2 ≤ d) {κ : ℝ} (hκ : 2 ≤ κ) (n : ℕ) : Prop :=
  let θ : Fin d → ℝ := fun i => ((i.val : ℝ) + 1 / 2) * Real.pi / (d : ℝ)
  let eigenvalue : Fin d → ℝ := fun i => (κ + 1) / 2 + (κ - 1) / 2 * Real.cos (θ i)
  let r : ℝ := (Real.sqrt κ - 1) / (Real.sqrt κ + 1)
  (∑ i : Fin d, Real.cos ((n : ℝ) * θ i) / eigenvalue i) =
    (1 / Real.sqrt κ) *
      ((∑ i : Fin d, Real.cos ((n : ℝ) * θ i)) +
        2 * ∑' j : ℕ, (-r) ^ (j + 1) *
          (∑ i : Fin d, Real.cos ((n : ℝ) * θ i) *
            Real.cos (((j + 1 : ℕ) : ℝ) * θ i)))

#check producerStatement
#check consumerStatement
#print producerStatement
#print consumerStatement
