"""Read back frozen conditional payloads/protections and AST-only checker; no acceptance."""
from pathlib import Path
import ast, datetime, gzip, hashlib, json, os, subprocess, sys
sys.dont_write_bytecode = True
R = Path('/Users/zhouhuanjian/ASTIS-GC')
O = R/'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-determinant-integration-20261108/independent-integration-reader-review/proposal'
S = R/'.astis/huanjian-gc-fixed-spectrum-determinant-integration-20261108/independent-reader'
sha = lambda b: hashlib.sha256(b).hexdigest()
canon = lambda x: json.dumps(x, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()
report = json.loads((O/'proposal-report.json').read_bytes())
freeze = json.loads((O/'freeze.json').read_bytes())
assert sha((O/'proposal-report.json').read_bytes()) == freeze['report_sha256']
def raw_archive(row):
 data = (R/row['path']).read_bytes(); assert sha(data) == row['gzip_sha256']
 raw = gzip.decompress(data); assert sha(raw) == row['raw_sha256'] and len(raw) == row['raw_bytes']
 return raw
for row in report['shared_paths']:
 path = R/row['path']
 if row['before_exists']:
  assert path.read_bytes() == raw_archive(row['before_archive'])
  assert sha(path.read_bytes()) == row['before_sha256']
 else: assert not path.exists()
 assert sha(raw_archive(row['planned_after_archive'])) == row['planned_after_sha256']
assert raw_archive(report['raw_diff']) == (S/'exact-proposed-shared.diff').read_bytes()
for path,digest in {**report['source_Test_lesson_publication_pins'], **report['unchanged_models']}.items(): assert sha((R/path).read_bytes()) == digest, path
for path,row in report['input_archives'].items(): assert raw_archive(row) == (R/path).read_bytes()
frontiers = json.loads(raw_archive(report['foreign_frontiers']))
current_frontiers = {str(p.relative_to(R)): sha(p.read_bytes()) for p in (R/'research-wiki/frontier-cells').glob('*.json') if p.name != 'ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-determinant.json'}
assert current_frontiers == frontiers
old_gc = json.loads(raw_archive(report['older_GaussianComplexity_evidence']))
for path,digest in old_gc.items(): assert sha((R/path).read_bytes()) == digest, path
foreign = json.loads(raw_archive(report['protected_foreign_content']))
for path,row in foreign.items():
 q = R/path; raw = os.fsencode(os.readlink(q)) if q.is_symlink() else q.read_bytes()
 assert sha(raw) == row['sha256'] and len(raw) == row['bytes'], path
gitmap = json.loads(raw_archive(report['protected_git_objects'])); current_index = {}
for line in subprocess.check_output(['git','ls-files','--stage','-z'], cwd=R).split(b'\0'):
 if not line: continue
 md,path=line.split(b'\t',1); mode,blob,stage=md.decode().split()
 if stage == '0': current_index[os.fsdecode(path)] = [mode,blob]
for path,row in gitmap.items(): assert current_index[path] == row, path
sys.path.insert(0,str(R/'tools'))
import astis_advance as adv
for path, replay in [('runs/substantive_advances.jsonl',adv._replay_advances),('runs/substantive_discoveries.jsonl',adv._replay_discoveries)]:
 row=report['ledger_protection'][path]; raw=(R/path).read_bytes()
 assert raw.startswith(raw_archive(row['raw_prefix'])) and raw.endswith(b'\n')
 states=replay([json.loads(x) for x in raw.splitlines() if x.strip()])
 if 'advances' in path: states.pop('ASTIS-SA-20261108-GaussianComplexityFixedSpectrumDeterminant')
 else: states={k:v for k,v in states.items() if v.get('advance_id')!='ASTIS-SA-20261108-GaussianComplexityFixedSpectrumDeterminant'}
 assert canon(states) == raw_archive(row['foreign_projection']), path
readme=report['README_preservation']; assert sha((R/readme['path']).read_bytes())==readme['sha256']
M=O/'browser-checker-preparation/preparation-manifest.json'; manifest=json.loads(M.read_bytes())
script=(R/manifest['script']).read_bytes()
assert sha(script)==manifest['script_sha256']
assert sha((R/manifest['raw_archive']).read_bytes())==manifest['archive_sha256']
assert gzip.decompress((R/manifest['raw_archive']).read_bytes())==script
ast.parse(script,filename=manifest['script'])
assert manifest['execution_status']=='NOT_RUN'
helper_rows={}
for name in ['prepare_proposal.py','prepare_browser.py','finalize_preparation.py']:
 raw=(S/name).read_bytes(); archived=gzip.compress(raw,mtime=0)
 dest=O/('helper-'+name+'.raw.gz'); assert not dest.exists(); dest.write_bytes(archived)
 assert gzip.decompress(dest.read_bytes())==raw
 helper_rows[name]={'path':str((S/name).relative_to(R)),'raw_sha256':sha(raw),'archive':str(dest.relative_to(R)),'archive_sha256':sha(archived)}
receipt={'role':'/root/det_integration_reader','phase':'Conditional proposal and checker preparation complete; not local acceptance','recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head_now':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'proposal_report_sha256':sha((O/'proposal-report.json').read_bytes()),'proposal_freeze_sha256':sha((O/'freeze.json').read_bytes()),'raw_diff_sha256':freeze['diff_raw_sha256'],'six_before_payloads_current':True,'six_after_archives_hash_and_gzip_roundtrip':True,'current_unchanged_models':report['unchanged_models'],'protected_readback':{'foreign_SAUs':282,'foreign_frontiers':len(frontiers),'foreign_content':len(foreign),'old_GC_evidence':len(old_gc),'old_tracked_git_objects':len(gitmap),'ledger_raw_prefixes_and_foreign_projection':True,'README_unchanged':True},'checker_sha256':sha(script),'checker_manifest_sha256':sha(M.read_bytes()),'checker_syntax':'ast.parse only passed; no import or execution','checker_execution_status':'NOT_RUN','expected_later_original_images':38,'helper_archives':helper_rows,'no_sourceV_STAB_shared_file_ledger_API_build_site_browser_parking_or_publication_actions':True,'next_owner_action':'After accepted independent sourceV and sole normal STAB, root may apply exact6archivedpayloads; pin immutable core and run actual final gates then explicitly invoke checker. Later independent original-image/protection acceptance is separate.'}
dest=O/'preparation-completion-receipt.json'; assert not dest.exists();dest.write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'receipt':str(dest.relative_to(R)),'receipt_sha256':sha(dest.read_bytes()),'proposal_report_sha256':receipt['proposal_report_sha256'],'checker_manifest_sha256':receipt['checker_manifest_sha256'],'checker_sha256':receipt['checker_sha256'],'shared_planned_after':{row['path']:row['planned_after_sha256'] for row in report['shared_paths']},'status':'CONDITIONAL_PREPARATION_COMPLETE_NO_EXECUTION'},indent=2))
