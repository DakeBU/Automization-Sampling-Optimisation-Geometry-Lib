from pathlib import Path
sig=Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-query-semantic-evidence/candidate-exact-signature.txt').read_text().rstrip('\n')
head='''import Mathlib.LinearAlgebra.UnitaryGroup
import Mathlib.Data.Matrix.Diagonal
import Mathlib.Analysis.InnerProductSpace.PiL2
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Basic
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Ring
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
open Matrix
namespace AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumAffine
set_option autoImplicit false
'''
lets=sig[sig.index('    let θ :'):sig.index('    ∀ x :')]
lets='\n'.join(line[2:] if line.startswith('  ') else line for line in lets.splitlines())+'\n'
proof=''' := by
  classical
  dsimp only
'''+lets+'''  have hdpos : (0 : ℝ) < (d : ℝ) := by
    exact_mod_cast (lt_of_lt_of_le (by decide : (0 : ℕ) < 2) hd)
  have hd0 : (d : ℝ) ≠ 0 := ne_of_gt hdpos
  have hindex (i : Fin d) : θ i =
      (((i.val : ℝ) + 1 - 1 / 2) * Real.pi) / (d : ℝ) := by
    dsimp only [θ]
    field_simp [hd0] <;> ring
  have hscalar (i : Fin d) :
      (κ + 1) / 2 + (κ - 1) / 2 * Real.cos (θ i) =
      (κ - 1) * ((2 + 1) / 2 + (2 - 1) / 2 * Real.cos (θ i)) - (κ - 2) := by
    simp only [hindex i]
    ring
  have hdiag :
      Matrix.diagonal (fun i => (κ + 1) / 2 + (κ - 1) / 2 * Real.cos (θ i)) =
      (κ - 1) • Matrix.diagonal (fun i => (2 + 1) / 2 + (2 - 1) / 2 * Real.cos (θ i)) -
        (κ - 2) • (1 : Matrix (Fin d) (Fin d) ℝ) := by
    ext i j
    by_cases hij : i = j
    · subst j
      simpa [Matrix.diagonal_apply, Matrix.one_apply] using hscalar i
    · simp [Matrix.diagonal_apply, Matrix.one_apply, hij]
  have hO : (O : Matrix (Fin d) (Fin d) ℝ) *
      (O : Matrix (Fin d) (Fin d) ℝ).transpose = 1 :=
    Matrix.mem_orthogonalGroup_iff.mp O.property
  have hmatrix : A κ = (κ - 1) • A 2 - (κ - 2) • 1 := by
    dsimp only [A]
    rw [hdiag, Matrix.mul_sub, Matrix.sub_mul]
    simp only [Matrix.mul_smul, Matrix.smul_mul, Matrix.mul_one, hO]
  have hnz : κ - 1 ≠ 0 := by linarith
  intro x
  have hforward : query κ x = (κ - 1) • query 2 x - (κ - 2) • x := by
    apply WithLp.ofLp_injective 2
    change A κ *ᵥ WithLp.ofLp x =
      (κ - 1) • (A 2 *ᵥ WithLp.ofLp x) - (κ - 2) • WithLp.ofLp x
    rw [hmatrix]
    simp only [Matrix.sub_mulVec, Matrix.smul_mulVec, Matrix.one_mulVec]
  refine ⟨hforward, ?_⟩
  rw [hforward, sub_add_cancel, smul_smul, inv_mul_cancel₀ hnz, one_smul]
end AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumAffine
'''
p=Path('.astis/huanjian-fixed-spectrum-query-20261107/Proof.lean');assert not p.exists();p.write_text(head+sig+proof);print('First actual complete proof candidate written AFTER immutable preproof admission321b2aad. No public target statement changed.')
