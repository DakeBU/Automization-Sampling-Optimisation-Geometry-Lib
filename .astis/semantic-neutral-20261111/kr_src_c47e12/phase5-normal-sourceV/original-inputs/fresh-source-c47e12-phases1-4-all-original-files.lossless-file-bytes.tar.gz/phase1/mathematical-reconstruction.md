# Independent raw-source reconstruction — phase 1

Source: **On Complexity of Gaussian Sampling**, arXiv:2610.20492v1. Pinned HTML SHA-256: `6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915`.

This reconstruction was written before receiving any target signature, Lean implementation, decoder reconstruction, prior review, statement seal, source graph, or verifier output. Its full structured mathematical content is in `mathematical-reconstruction.json`; exact raw Unicode-character, UTF-8-byte and LF endpoint anchors are in `source-anchors.json`.

## Source interface

The Section 4 hard family has integer d≥2 and κ≥2, θᵢ=(i−1/2)π/d, λᵢ=(κ+1)/2+(κ−1)cos(θᵢ)/2, Λ=diag(λᵢ). The rotation O is Haar on O(d), independent of the algorithm's private seed, and A=OΛOᵀ. The spectrum is fixed and can be known.

For a nonnegative integer q with 2q+1<d, put r=q+1, n=2q+1 and Dₙ=diag(cos(nθᵢ)). The starters g₁,…,gᵣ are mutually independent N(0,I_d), without scaling. The exact block Krylov space is

K_q = span{Λʲgₐ : 1≤a≤r, 0≤j≤q}.

The extra starter is for the output. Lemma4.3 supplies an extended experiment preserving (O,X), with OᵀX∈K_q almost surely. Its polynomial coefficients may depend on the whole experiment. Their independence from the starters is neither stated nor needed.

Appendix C.2 defines γᵢ=((g₁)ᵢ,…,(gᵣ)ᵢ)ᵀ, tᵢ=(1,√2 cos θᵢ,…,√2 cos(qθᵢ))ᵀ, and B∈R^{d×r²} with i-th row d^{-1/2}(γᵢ⊗tᵢ)ᵀ. Thus only B is divided by √d; only nonconstant cosine features are multiplied by √2. Coordinates of c∈R^{r²} can be indexed by (a,j).

## Both range implications

Write α=(κ+1)/2, b=(κ−1)/2>0 and Pⱼ(z)=Tⱼ((z−α)/b). Then Pⱼ(λᵢ)=cos(jθᵢ). P₀=1; for j≥1, Pⱼ has degree j and leading coefficient 2^{j−1}b^{−j}, which is nonzero. The transformation between monomials and P₀,…,P_q is triangular and invertible. This is a transformation of indexed polynomial generator lists; evaluated Krylov generators need not be independent.

Let s₀=1 and sⱼ=√2 for j≥1. A column of B is d^{-1/2}sⱼ((gₐ)ᵢcos(jθᵢ))ᵢ. Every Bc therefore equals Σₐpₐ(Λ)gₐ with pₐ=d^{-1/2}ΣⱼsⱼcₐⱼPⱼ, so range(B)⊆K_q. Conversely, expand any degree-at-most-q pₐ as ΣⱼhₐⱼPⱼ and choose cₐⱼ=√d hₐⱼ/sⱼ. This gives u=Bc and K_q⊆range(B).

This is the source's triangular invertible argument expanded in both directions. Range equality is deterministic for arbitrary realized starters; randomness, concentration, full rank, and an independently chosen coefficient vector are not premises.

## One coefficient witness for both identities

For every u∈K_q choose **one** c with u=Bc. Using this same c throughout,

uᵢ = d^{-1/2} ΣₐΣⱼ cₐⱼ(gₐ)ᵢtᵢⱼ,

‖u‖² = (1/d)Σᵢ(Σₐⱼcₐⱼ(gₐ)ᵢtᵢⱼ)² = cᵀBᵀBc,

uᵀDₙu = (1/d)Σᵢcos(nθᵢ)(Σₐⱼcₐⱼ(gₐ)ᵢtᵢⱼ)² = cᵀBᵀDₙBc.

Both identities hold for every coefficient vector if u=Bc. Norms are the ordinary Euclidean norms; ‖c‖²=Σₐⱼcₐⱼ². Inner products are ordinary real coordinate sums. They are not normalized sums or function-space norms.

The source places the two final displays in **tbody A3.Ex130 and A3.Ex131**, with math display attributes set to **inline**. They are in one equation group following the single representation u=Bc. An extractor restricted to block math would miss them.

On the same event, the two operator norm bounds imply

‖u‖² ≥ (1−τ)‖c‖²,  |uᵀDₙu| ≤ τ‖c‖².

The condition τ≤1/2 gives |uᵀDₙu|≤τ/(1−τ)‖u‖²≤2τ‖u‖². The event holds for every c simultaneously, hence for every u in K_q, including adaptive or experiment-dependent choices. Uniqueness or a measurable canonical selection of c is not required.

## Other ingredients and conditional boundary

FactC.5 also states E[BᵀB]=I_{r²}, E[BᵀDₙB]=0, ‖tᵢ‖²≤2r, Σᵢtᵢtᵢᵀ=dI_r and Σᵢcos(nθᵢ)tᵢtᵢᵀ=0. Its proof uses the telescoping sine identity Σᵢcos(kθᵢ)=0 for 0<|k|<2d, product-to-sum, E[γᵢγᵢᵀ]=I_r, and 1≤n±j±k≤4q+1<2d. The constant feature is treated separately in the unweighted Gram proof. The source's feature norm estimate is 1+2Σ_{j=1}^q cos²(jθᵢ)≤1+2q≤2r.

FactC.6 supplies both Gram bounds with probability at least 0.995. Its proof includes Gaussian radial truncation and bias, centered summand and fourth-moment variance estimates, two matrix Bernstein bounds, their union bound, the truncation intersection, and absorption into an absolute C. These ingredients are proved dependencies, not additional source theorem hypotheses.

τ = C[(q+1)√(log d/d)+(q+1)(q+1+log d)log d/d].

C is sufficiently large and absolute. FactC.6 does not require τ≤1/2; that condition enters the final coefficient elimination. Lemma4.4 states probability at least 0.99 and a bound simultaneous over all u∈K_q. The estimate is independent of κ through the polynomial span conversion.

q=0 is included: r=1, n=1, d≥2, tᵢ=(1), B=d^{-1/2}g₁ and K₀=span{g₁}. Positive-frequency feature sums are empty. The same nonzero constant change and both quadratic identities apply, including zero vectors. d=1 and 2q+1≥d are outside the lemma's boundary; κ=1 is outside the hard-family setup.

## Main lower-bound boundary

Theorem4.1 states: for every fixed δ∈(0,1), there is d₀(δ) such that, for every integer d≥d₀(δ), 2≤κ≤d^{1−δ}, and 0<ε≤1/10,

Q_G(d,κ,ε) ≥ (δ/256)√κ log d.

The precision class is symmetric I_d≼A≼κI_d; the target is N(0,A^{-1}), and the oracle is exact first order, equivalently matrix-vector. The algorithm's budget is an every-run deterministic cap. The TV guarantee is uniform in fixed inputs and averages over the algorithm's private randomness.

Section4.3 discharges n<d, τ≤1/2 and the target-moment condition d−n≥√κ using the restricted κ range and sufficiently large d depending only on δ. It then derives τ≤β/4 and Mβ²≥320. The signed cosine test is passed by algorithmic outputs with averaged probability at most 0.01 and by targets with probability at least 0.9, contradicting ε≤0.1. This bounded reconstruction does not certify the full proof or its deferred C.1/C.3/C.4 proofs. Section4.4 identifies proof-technique limits for larger κ and improving ε; it does not claim those stronger lower bounds are false.

## Coverage and exposure boundary

All 149 paragraphs, theorem/proof containers, tables and tbody rows carrying IDs in §4.1, §4.2 and C.2 are inventoried: 148 NODE entries and one explicitly excluded proof-end symbol. Overlapping equation containers and their rows are retained deliberately. Section2, Theorem4.1, §4.3 and §4.4 were read for conventions and boundary. No target signature or implementation was available.

A parser naming collision and one process argument-length failure are separately retained as process failures. No numerical/Lean theorem test, source-target comparison, repair verdict, or verifier state transition occurred. The honest exposure record is `exposure-log.json`; no unrestricted clean-slate or pristine-isolation claim is made.

