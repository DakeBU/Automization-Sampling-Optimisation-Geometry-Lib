from pathlib import Path
import gzip, hashlib, io, json, re, subprocess, tarfile

W = Path(__file__).resolve().parent.relative_to(Path.cwd())
E = Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-krylov-range-semantic-evidence')
R = Path('.astis/huanjian-resume-20261103')
base = '050d6c51e4edd6583da404153a050b62beb8ad13'
sha = lambda b: hashlib.sha256(b).hexdigest()
dump = lambda x: (json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode()
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip() == base
assert not subprocess.check_output(['git','diff','--cached','--name-only']).strip()
record = json.loads((W/'actual-complete-original-V-carrier.json').read_bytes())
assert record['complete_original_V_carrier_commit'] == base and record['all_selected_original_bytes_exact_in_Git']
assert record['complete_original_V_recursive_JSON_nodes'] == 1407
(E/'last-formal-main-original-owner-observation.json').write_bytes((W/'latest-owner-after-complete-original-V-carrier.json').read_bytes())
planning = {'scope':'Source-only planning for the next bounded mathematical packet, not a new sealed target, normal claim, proof search, API retrieval or proof result.','actual_source_read':'Turn tool output63d211 read pinned raw arXiv HTML FactC.6/A3.SS2.3 and final A3.SS2.4 only. No local raw execution receipt was produced for that direct tool invocation; none is invented.','raw_source_sha256':'6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915','observed_source_ingredients':['For r=q+1, actual standard Gaussian row has E exp(||gamma||^2/3)=3^(real r/2); tail at2r+3x is at most exp(-x).','Literal truncation L=2r+3log(1000d), simultaneous truncation event>=0.999, tail/bias integrals and radial truncated covariance aI with0<=a<=1.','Actual Gaussian fourth radial covariance E[||gamma||^2 gamma gamma^T]=(r+2)I, followed by centered/truncated matrix bounds and matrix Bernstein.','FactC.6 simultaneous Gram failure budget0.005; source tau uses r*sqrt(log(d)/d)+r*(r+log(d))*log(d)/d with absolute constant, not a supplied event estimate.'],'candidate_scope':'Next inspect existing canonical targets/owners and exact source interfaces before choosing and sealing one minimal leaf with a real consumer. No generic covariance/MGF/concentration/rank/independence/integrability certificate may be inserted as an extra source premise. No candidate Lean statement or topology approval exists yet.','same_goal_all_original_frontiers_and_queues_preserved':True}
(E/'next-C6-source-only-planning-exposure.json').write_bytes(dump(planning))
memory = {**record,'local_cycle':'Exact source statement seal, qualified preproof source/topology admission, real proof, blind decoding, fresh raw-first/types-first/full-module source review, independent fresh native/static review, normal original-actor V and complete immutable original evidence carry done.','queued_source_V_packets':13,'public_integration':'HOLD: original foreign global STABILIZING owner remains. No takeover, shared imports/root Tests/Registry/global graph/source-index/site/clean-port/push. Disabled UI6 remains disabled.','reader_HOLD':'Exact six folded code blocks/full private Test and main theorem adjacency pass bounded static review. Individual step/private provenance-page controls and all browser/MathJax/clipboard/mobile/final-shell/whole-site acceptance remain separate.','purification_and_ExpositionSeal':'pending after actual integration/publication; no PURIFIED badge','whole_Goal':'unfinished: both main lower bounds, necessary background/debts, actual Haar/joint/adaptive/oracle/precision/TV/dimension-condition-number/deterministic cap/explicit expected-cost adapters and final public acceptance remain open.','next_math':'C6 source-only candidate planning, no new packet yet.'}
(E/'local-cycle-memory-and-next-boundary.json').write_bytes(dump(memory))
readme = E/'README.md';old=readme.read_bytes()
prefix = '''# Local source VERIFIED carried completely; integration/publication remain HOLD

Mathematical commit972d8994, independently reviewed metadatad4ff03bf and complete
original V carrier050d6c51 are distinct immutable stages. The original independent
actor /root/krylov_fresh_source_c47e12 executed one normal VERIFIED; root executed
zero. The exact133088-byte append SHA959a610c, all29 top-level evidence fields and
1407 recursive JSON nodes, full original PLOCAL event/evidence/capsule, current
latest_evidence and all98 portable source-V originals are byte-exact in Git050d.
Every old316 VERIFIED object and299 foreign advance states remain unchanged.

The13th local source-verified packet proves actual range(B)=K_q and its genuine
same-witness Euclidean quadratic application. It does not finish either main
lower bound. The latest formal-main/original-owner readback still holds global
integration. Website controls/runtime delivery, publication, purification and
whole-Goal completion remain separate. Conditional integrationv14 is being
prepared from fixed050d/mainEB/live83b inputs only; it grants no port authority.

C6 source-only reading identifies actual Gaussian exponential/truncated/fourth
moment and matrix-concentration ingredients for a next sealed packet. No next
Lean target, proof/API search or new advance has started. Previous README bytes
follow exactly as historical context.

'''.encode()
readme.write_bytes(prefix+old)
previous = set(json.loads((E/'actual-local-checks-lossless-archive.json').read_bytes())['files'])
files = []
for p in sorted(R.glob('*krylov-range*.receipt.json')):
    if str(p) in previous:
        continue
    x=json.loads(p.read_bytes());lp=Path(x['log']);assert sha(lp.read_bytes())==x['log_sha256'];files += [p,lp]
files += [W/n for n in ['close_local_cycle_memory.py','exact-normal-sourceV-request.json','actual-complete-original-V-carrier.json','actual-reviewed-metadata-commit.json','actual-immutable-mathematical-candidate.json','latest-owner-after-complete-original-V-carrier.json']]
target=E/'postcandidate-root-process-originals.lossless-file-bytes.tar.gz'
assert not target.exists()
entries={}
with target.open('xb') as out:
    with gzip.GzipFile(filename='',fileobj=out,mode='wb',mtime=0) as gz:
        with tarfile.open(fileobj=gz,mode='w') as tf:
            for p in sorted(set(files)):
                data=p.read_bytes();assert (b'/xwechat'+b'_files/') not in data and not re.search(rb'wx'+rb'id_[a-z0-9]{5,}',data),p
                name=str(p.relative_to(Path.cwd())) if p.is_absolute() else str(p)
                info=tarfile.TarInfo(name);info.size=len(data);info.mode=p.stat().st_mode&0o777
                tf.addfile(info,io.BytesIO(data));entries[name]={'sha256':sha(data),'bytes':len(data)}
with tarfile.open(target,'r:gz') as tf:
    for member in tf:assert sha(tf.extractfile(member).read())==entries[member.name]['sha256']
(E/'postcandidate-root-process-originals.archive-manifest.json').write_bytes(dump({'archive':str(target),'sha256':sha(target.read_bytes()),'files':entries,'scope':'Exact completed late root checks/failures/receipts and process scripts at this archive point. In-flight close-memory wrapper excluded. No private foreign baselines or source private sibling included.'}))
changed=subprocess.check_output(['git','diff','--name-only','-z']).decode().rstrip('\0').split('\0')
assert changed==[str(readme)],changed
paths=[readme,E/'last-formal-main-original-owner-observation.json',E/'next-C6-source-only-planning-exposure.json',E/'local-cycle-memory-and-next-boundary.json',target,E/'postcandidate-root-process-originals.archive-manifest.json']
hashes={str(p):sha(p.read_bytes()) for p in paths}
subprocess.run(['git','add','--',*hashes],check=True)
subprocess.run(['git','diff','--cached','--check'],check=True)
subprocess.run(['git','commit','-m','docs(gaussian): record completed local Krylov verification and remaining boundary'],check=True)
commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
for n,h in hashes.items():assert sha(subprocess.check_output(['git','show',commit+':'+n]))==h
print(json.dumps({'local_cycle_memory_commit':commit,'complete_original_V_carrier':base,'queued_local_source_V':13,'next_packet_started':False,'global_Goal_complete':False}))
