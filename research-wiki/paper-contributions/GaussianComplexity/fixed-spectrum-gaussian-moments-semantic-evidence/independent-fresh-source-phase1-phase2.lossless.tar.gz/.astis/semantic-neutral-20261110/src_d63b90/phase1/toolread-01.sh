pwd && cat AGENTS.md
