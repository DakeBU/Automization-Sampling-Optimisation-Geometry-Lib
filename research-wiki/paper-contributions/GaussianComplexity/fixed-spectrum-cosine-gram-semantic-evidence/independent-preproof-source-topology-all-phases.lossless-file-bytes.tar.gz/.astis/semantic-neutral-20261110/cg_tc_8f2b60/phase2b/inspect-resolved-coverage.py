from pathlib import Path
import json
import sys

base=Path(__file__).resolve().parent
mode=sys.argv[1]
if mode=='semantic':
    records=json.loads((base/'coverage-semantic-clauses.json').read_bytes())
    out=json.dumps(records,ensure_ascii=False,indent=2)+'\n'
elif mode=='tail':
    records=json.loads((base/'coverage-tail-resolved.json').read_bytes())
    out='\n'.join(r['id']+' | '+r['tag']+' | '+r['disposition']+' | '+','.join(r['node_ids'])+' | '+r['reason'] for r in records)+'\n'
else:
    records=json.loads((base/'coverage-core-resolved.json').read_bytes())
    wanted={'core1':{'A3.SS2.p1','A3.SS2.p2','A3.Thmtheorem5.p1','A3.SS2.p3','A3.SS2.p4'},
            'core2':{'A3.SS2.p5','A3.SS2.p6'},'core3':{'A3.SS2.p7','A3.SS2.p8'}}[mode]
    lines=[]
    for r in records:
        if r['paragraph'] not in wanted:continue
        line=r['id']+' | '+r['tag']+' | '+r['disposition']+' | '+','.join(r['node_ids'])
        if r['raw_alttext']:line+=' | '+r['raw_alttext']
        elif r['tag'] in {'div','p'}:line+=' | '+r['reason']
        lines.append(line)
    out='\n'.join(lines)+'\n'
(base/('inspect-coverage-'+mode+'.stdout.txt')).write_text(out)
print(out,end='')
