# Phase 2 initial challenge: exact seal and original source graph

This immutable initial review precedes reading the source author's phase 2 projection. It is based on the challenger's frozen raw-source phase 1, the exact seal, and a bounded C.7 → C.8 p4.2 slice of the original phase 1 graph. It does not approve proof implementation or award formalization credit.

## Exact inputs and exposure

- Seal: `research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-cosine-expansion-statement-seal.json`, SHA-256 `748538057656b235eed54272a87e66f4bf87bdbeb79a9831795b53e72ae74a36`. Root reports commit `62eb50764`; this review binds the independently hashed current file, not an independently checked Git commit.
- Original graph: `source-only-review/phase1/source_graph.json`, SHA-256 `25203b92a6b6dd63bd14ffb967a7a4072d7d750c9357ddb7c29cbe286b8e13d0`.
- Original manifest: `source-only-review/phase1/manifest.json`, SHA-256 `215fe8eba52b906f54c08471d9d0e896b956cb6726af15a335f4815bac60c6d3`.
- Original coverage inputs read: `paragraph_display_citation_coverage.json`, `all_source_anchors.json`, and summary keys of `coverage_summary.json`. The source-only phase 1 directory filenames were inventoried. Scripts, prior source understanding, exposure logs, implementation/Lean/API and prior verdicts were not opened.
- The first graph filter was wider than intended and displayed some neighboring algorithm/query/asymptotic labels and outgoing edges. They are source graph records, not proof implementation evidence; no review of those unrelated claims is made here.
- Root's assertion that its audit has no EXCESS binders is not relied on. The actual signature strings and definitions were examined independently. The root-reported type-formation receipt was not opened or used as proof evidence.
- Challengerial phase 1 remains frozen. No mathematical target proof, API search, background worker, ledger action or shared source mutation occurred.

## Independent seal determination

The producer matches the raw C.7 assertion under its source range: κ is real and κ≥2; θ ranges over all real numbers inside the conclusion; ρ is the literal principal-square-root quotient. There is no d, U, n, grid-angle, integrability, geometric-expansion, nonvanishing or convergence premise. No project-owned Prop aliases or bundled structures occur in the signature. No EXCESS binder was found independently.

The equality is real valued. `j : ℕ` maps to source frequency j+1 in both the power and cosine; `Finset.range N` gives exactly modes 1,…,N, with an empty partial sum at N=0. The separate constant 1 and factor 2 match the source. `Summable` of the real norm expresses absolute convergence. Uniform convergence is over every real θ for each fixed κ, not merely over the grid and not uniformly in unbounded κ. It has the explicit real partial sums and the same infinite-sum limit. Summability is a produced conjunct, so totalization of an infinite sum does not alone carry the claim.

The private consumer's grid `((i.val : ℝ)+1/2)π/d` corresponds to the paper's i+1 index, and its eigenvalues preserve both factors of 1/2. κ≥2 and d≥2 remain source standing inputs. Its n is any natural number: this is a legitimate private generalization of the pre-aliasing intermediate, not a claim of the later exact C.8 formula for all n. In particular n=0 is the unweighted inverse trace; no assertion about n≥d alias formulas is made.

The consumer proposition is mathematically substantive: the left side is the actual weighted reciprocal-eigenvalue finite sum, and the right side moves the finite weighted grid sum inside the positive-mode infinite series. It is not a restatement of the producer and does not assume the desired equality, summability or exchange law. Gaussian expectation identification is deliberately absent, so this consumer is a pure spectral intermediate. This is **pre-proof eligibility**, not evidence that an actual authored body calls the producer. After proof, the use of producer equality and absolute summability, reciprocal normalization, weighted-series summability, finite summation and the exchange itself still require actual-body verification.

## Original graph challenge

The core raw C.7 paragraphs/displays and C.8 Ex140/p4.2 are present with correct source hashes. The complex geometric step, two ρ identities, separate domination/convergence step, and conjunction at `e05` match the source route. There is no discovered alternative OR-route; the positive/negative complex phases are both ingredients. `background.geometric_complex` and `background.uniform_convergence` correctly expose unnamed background rather than claiming local Lean availability. `e05` records `A3.SS3.p2.3` as the equality-combination use site even though the coverage row assigns the composite paragraph to the domination node; that is a granularity note, not an omitted-source finding.

The original graph is a broader context graph and requires explicit bounded projections before admission of the exact κ-only producer and pure spectral consumer. The following are HOLD items for that projection, not claims that the raw mathematics or sealed signatures are false:

1. **H-PROJECT-RHO.** `e01` and `e03` have AND parents `hard.grid` and `moment.definitions`. Those nodes simultaneously carry d≥2/grid, Gaussian law and 1≤n<d, although the C.7 ρ range and algebra use only κ≥2 and the literal ρ definition. A projection must expose κ/ρ-only input ports and retain the larger nodes as source provenance/context, without turning U, d or n into mathematical premises of C.7. Proof ingredients and source context must not be conflated.
2. **H-SPECTRAL-TRANSFER.** `e08` links `C7.expansion` and `C8.trace_moments` to `C8.interchange`. That matches the source paragraph's use after expectation identification, but its root closure includes `background.gaussian`. For the sealed private consumer, distinguish a pure spectral finite weighted sum transfer from the separate Gaussian Ex140 identification. The private intermediate cannot acquire a Gaussian law merely because its eventual consumer is a mean.
3. **H-BRIDGE-EXCHANGE.** The projected transfer must actually represent bounded multiplication of each absolutely summable positive-mode series, summability of their finite sum, finite-sum/infinite-series linearity, and the literal identity between reciprocal eigenvalues and the C.7 left side. They may be explicit unnamed-background nodes or equivalently explicit mathematical discharge records, but cannot be input certificates/public binders. C.7 uniform convergence need not become an extra prerequisite of this finite linear-combination exchange; the source credits absolute convergence.

The complete C.8 exact means, Gaussian moment proof, alias partition, variances, bias and downstream lower bounds remain outside the exact mathematical delta. Projecting those out must be explicit exclusion, not a claim they have been proved. This source graph is source-derived topology only; it cannot certify actual future Lean dependency edges.

## Initial verdict

**SEAL-SEMANTICS-PASS; ORIGINAL-GRAPH-PROJECTION-HOLD.** No binder repair or signature change is requested. The three HOLD items above must be checked against the separately frozen source author's phase 2 projection. Final preproof admission remains pending that exact input. Subsequent projection review will be written separately; this initial record will not be replaced or silently repaired.
