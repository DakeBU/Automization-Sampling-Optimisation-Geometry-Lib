cat .astis/semantic-neutral-20261110/src_d63b90/phase1/source-cognition.md .astis/semantic-neutral-20261110/src_d63b90/phase1/source-seven-slots.json
