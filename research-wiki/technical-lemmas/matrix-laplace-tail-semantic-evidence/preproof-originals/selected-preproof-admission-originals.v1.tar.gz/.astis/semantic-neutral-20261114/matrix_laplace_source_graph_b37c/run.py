#!/usr/bin/env python3
"""Task-local command recorder; never invokes Lean, browser, API, or git."""
import datetime, hashlib, json, pathlib, subprocess, sys
BASE = pathlib.Path(__file__).resolve().parent
name, *cmd = sys.argv[1:]
if not name or not cmd:
    raise SystemExit('usage: run.py NAME CMD ...')
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
proc = subprocess.run(cmd, cwd='/Users/zhouhuanjian/ASTIS-GC', capture_output=True)
(BASE / f'{name}.stdout').write_bytes(proc.stdout)
(BASE / f'{name}.stderr').write_bytes(proc.stderr)
record = {'name': name, 'argv': cmd, 'cwd': '/Users/zhouhuanjian/ASTIS-GC',
          'started_utc': started, 'finished_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'exit_code': proc.returncode,
          'stdout_sha256': hashlib.sha256(proc.stdout).hexdigest(),
          'stderr_sha256': hashlib.sha256(proc.stderr).hexdigest()}
(BASE / f'{name}.receipt.json').write_text(json.dumps(record, indent=2) + '\n')
sys.stdout.buffer.write(proc.stdout)
sys.stderr.buffer.write(proc.stderr)
raise SystemExit(proc.returncode)
