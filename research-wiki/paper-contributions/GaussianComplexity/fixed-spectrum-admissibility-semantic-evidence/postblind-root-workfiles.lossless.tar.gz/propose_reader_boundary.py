from pathlib import Path
import hashlib,json,gzip
sha=lambda b:hashlib.sha256(b).hexdigest()
b=Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-admissibility-semantic-evidence/reader-boundary-correction')
b.mkdir(exist_ok=False)
rows=[]
for name in ['declaration_lessons','publications']:
 p=Path('website/content')/name/'huanjian-fixed-spectrum-admissibility.json'; raw=p.read_bytes()
 old=b'with real Gaussian consumer planned.'; new=b'with its actual same-precision Gaussian law-density consumer compiled.'
 assert raw.count(old)==1
 after=raw.replace(old,new)
 z=b/(name+'.planned-after.json.gz'); z.write_bytes(gzip.compress(after,mtime=0)); assert gzip.decompress(z.read_bytes())==after
 rows.append({'path':str(p),'before_sha256':sha(raw),'planned_after_sha256':sha(after),'planned_after_archive':str(z),'gzip_sha256':sha(z.read_bytes()),'single_exact_replacement':{'old':old.decode(),'new':new.decode()}})
x={'scope':'Two exact authored boundary scalars only; historical preproof statement seal remains unchanged. Correct stale planned status to genuine compiled actual Test; no mathematical statement/hypothesis/proof/producer/Test/anonymous packet change. Current independent source review is pending. Refresh canonical draft publication binding before full source review, never replay older binding.','paths':rows,'sourceV':False}
(b/'proposal.json').write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'proposal':str(b/'proposal.json'),'raw_sha256':sha((b/'proposal.json').read_bytes())}))
