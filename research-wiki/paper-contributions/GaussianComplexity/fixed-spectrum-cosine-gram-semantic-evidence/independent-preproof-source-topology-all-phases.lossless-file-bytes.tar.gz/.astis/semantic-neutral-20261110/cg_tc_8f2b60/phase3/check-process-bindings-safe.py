from pathlib import Path
import hashlib
import json
import gzip

base=Path(__file__).resolve().parent
repo=Path('/Users/zhouhuanjian/ASTIS-GC')
W=repo/'.astis/huanjian-gc-fixed-spectrum-cosine-gram-20261110'
sha=lambda b:hashlib.sha256(b).hexdigest()
pre_b=(W/'preproof-baseline.private.json').read_bytes()
intake_b=(W/'intake-baseline.private.json').read_bytes()
assert sha(pre_b)=='b66cbc1bc55833a725ac230cdea12fee3529b3ccdd484fcaacf9b18f7fde3d72'
assert sha(intake_b)=='c282409e8408237f99431e815cf19a71abac8b5dc3420412adecae4200d81981'
pre=json.loads(pre_b);intake=json.loads(intake_b)
cell=json.loads((base/'C.json').read_bytes())
seal=json.loads((base/'W/statement-seal-v1.json').read_bytes())
projection=json.loads((base.parent/'phase2a/strict-statement-projection.json').read_bytes())
assert seal['producer']['signature']==projection['producer_signature']==cell['target_statement']
assert seal['actual_private_consumer']['signature']==projection['consumer_signature']
assert intake['preproof_snapshot']['sha256']==sha(pre_b)
assert Path(intake['preproof_snapshot']['path'])==W/'preproof-baseline.private.json' or (repo/Path(intake['preproof_snapshot']['path'])).resolve()==W/'preproof-baseline.private.json'
assert intake['own_frontier']['sha256']==sha((base/'C.json').read_bytes())
assert len(intake['control_paths'])==834 and len(intake['foreign_control_hashes'])==832
assert intake['normal_API_calls_so_far']==0
assert set(intake['foreign_control_hashes'])<=set(intake['control_paths'])
assert set(intake['control_paths'])-set(intake['foreign_control_hashes'])=={
 'runs/substantive_advances.jsonl',
 'research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-cosine-gram.json'}
all_paths=list(intake['control_paths'])+list(pre['all_tracked_regular_file_hashes'])+list(pre['all_existing_frontier_hashes'])
restricted=lambda n: n.startswith('.atlas-upstream/') or 'atlas' in [p.lower() for p in Path(n).parts[:-1]]
restricted_count=sum(restricted(n) for n in all_paths)
assert restricted_count==0
assert all(not Path(n).is_absolute() and '..' not in Path(n).parts for n in all_paths)
assert pre['head']=='75dcc0c9c7d9591384c6e0705e118b1ab440cd6c'
assert 'ASTIS-SA-20261110-GaussianComplexityFixedSpectrumCosineGram' not in pre['all_foreign_states']
required_predecessors=['ASTIS-SA-20261110-GaussianComplexityFixedSpectrumTargetLaw','ASTIS-SA-20261110-GaussianComplexityZeroQuerySeparation']
verified_count=sum(pre['all_foreign_states'][n]['state']=='VERIFIED' for n in required_predecessors)
assert verified_count==2

def diff(a,b,prefix=''):
    result=[]
    if isinstance(a,dict) and isinstance(b,dict):
        for k in sorted(set(a)|set(b)):
            p=prefix+'.'+k if prefix else k
            if k not in a or k not in b:result.append({'path':p,'before':a.get(k),'after':b.get(k)})
            else:result.extend(diff(a[k],b[k],p))
    elif a!=b:result.append({'path':prefix,'before':a,'after':b})
    return result

initial=json.loads(gzip.decompress((base/'E/frontier-initial-prospective-reader-flag-normalization.raw.json.gz').read_bytes()))
before_labels=json.loads(gzip.decompress((base/'E/frontier-before-explicit-library-search-labels.raw.json.gz').read_bytes()))
reader_diff=diff(initial,before_labels)
label_diff=diff(before_labels,cell)
assert {r['path'] for r in reader_diff}=={
 'learning_contract.reader_backpressure.assumptions_preserved','learning_contract.reader_backpressure.boundary_preserved'}
assert all(r['before'] is True and r['after'] is False for r in reader_diff)
assert {r['path'] for r in label_diff}=={'shared_floor_audit.searched','reuse_plan.searched_existing'}
checks=[]
for receipt_name,log_name in [
 ('20261110T141130894994Z-cosine-gram-draft-two-literal-Prop-only-formation.receipt.json','20261110T141130894994Z-cosine-gram-draft-two-literal-Prop-only-formation.log.gz'),
 ('20261110T141739878001Z-cosine-gram-exact-statement-binder-definition-seal-no-proof.receipt.json','20261110T141739878001Z-cosine-gram-exact-statement-binder-definition-seal-no-proof.log.gz'),
 ('20261110T143917881647Z-cosine-gram-preproof-frontier-format-no-math-acceptance.receipt.json','20261110T143917881647Z-cosine-gram-preproof-frontier-format-no-math-acceptance.receipt.log.gz'),
 ('20261110T143958682117Z-cosine-gram-preproof-frontier-explicit-prior-libraries.receipt.json','20261110T143958682117Z-cosine-gram-preproof-frontier-explicit-prior-libraries.log.gz'),
 ('20261110T144250664877Z-cosine-gram-prepare-exact-control-baseline-no-API.receipt.json','20261110T144250664877Z-cosine-gram-prepare-exact-control-baseline-no-API.log.gz')]:
    r=json.loads((base/'E'/receipt_name).read_bytes());log=gzip.decompress((base/'E'/log_name).read_bytes())
    assert sha(log)==r['log_sha256'],receipt_name
    checks.append({'receipt':receipt_name,'exit_code':r['exit_code'],'decoded_log_sha256':sha(log),'matches_receipt':True})
result={
 'sealed_signatures_match_immutable_independent_phase2a':True,'current_C_same_source_type':True,
 'private_only_hash_schema_binding_count_checks':True,
 'private_preproof_snapshot_link_exact':True,'private_own_frontier_hash_matches_C':True,
 'control_path_count':834,'foreign_control_hash_count':832,'normal_API_calls_so_far':0,
 'foreign_state_count':len(pre['all_foreign_states']),'existing_frontier_count':len(pre['all_existing_frontier_hashes']),
 'tracked_regular_file_count':len(pre['all_tracked_regular_file_hashes']),
 'required_predecessors_verified_count':verified_count,'new_advance_present_count':0,
 'all_guard_paths_relative_no_parent_escape':True,'restricted_nested_ATLAS_key_count':restricted_count,
 'restricted_nested_directories_traversed_or_contents_read':False,
 'normal_intake_once_marker_exists':(W/'normal-intake-attempted.once.json').exists(),
 'target_production_file_exists':(repo/seal['producer']['planned_file']).exists(),
 'target_private_test_file_exists':(repo/seal['actual_private_consumer']['planned_file']).exists(),
 'temporary_formation_probe_exists':(W/'StatementFormation.lean').exists(),
 'own_C_reader_pending_correction_diff':reader_diff,'own_C_library_label_correction_diff':label_diff,
 'receipt_raw_log_hash_checks':checks,
 'privacy_boundary':'No full private foreign state, tracked hash map, frontier map or control path list copied/exported. Only aggregate counts, booleans and already-public own-C diffs are retained.',
 'scope':'Read-only process input binding checks; no prepared script, normal API, gate, Lean proof or sourceV executed.'
}
assert not result['normal_intake_once_marker_exists']
assert not result['target_production_file_exists'] and not result['target_private_test_file_exists'] and not result['temporary_formation_probe_exists']
(base/'safe-process-binding-checks.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
stdout=json.dumps(result,ensure_ascii=False,indent=2)+'\n';(base/'check-process-bindings-safe.stdout.txt').write_text(stdout);print(stdout,end='')
