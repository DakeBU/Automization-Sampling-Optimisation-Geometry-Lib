# Independent matrix-mean source coverage/topology challenge, version 1

**Accept the bounded source coverage and unproved source/applicability
topology. No genuine statement or source-coverage blocker was found. All 13
internal mathematical/applicability ports remain open.** This accepts the
representation of the obligations, not their mathematical discharge, library
applicability, implementation, proof, normal intake or status/permission.

## Binding, independence and chronology

This actor completed its own raw freeze, then its independent exact type audit,
before opening the extractor's source graph. The preserved raw freeze is
`30a7d626b681fb59c522969a9be91797d1ca794f5e0433ea6941dfc7064c3fa8`;
the preserved type freeze is
`4602bbe4a97d053a1e9cf788f0247fee5a6965d33e0cfdb40928767f995c43e7`.
Only the ten specifically authorized public SG source artifacts were opened.
No SG type-audit/private rationale, old verdict, target implementation or proof
was inspected. The graph's references to SG type-audit/freeze hashes are
metadata references only; those separate artifacts were not opened or
certified. No source extractor is approving its own graph through this review.

The exact graph binds seal
`b55a1acb837288d580a667903987e5f809610626eb4848c750ff8d3a6c01149b`,
type packet `efdba6eea9aa32da4cd9ea8d5022548ac128179f1ba73661fefa342f6ca4d95c`,
producer `099bcbe9d6cc440754282873a7f1e1001584c3566fc771a70bf9f1a3846b85fe`,
consumer `00c0b050a632e03d9b169acdb6632ae85a9ec43cc2b5e8aa26b7b6152a711b7e`
and definition context
`92117d5029065dcbd8e1a218bb175a7c32d37e9dd34ac2f5255125e2f9c48cfa`.
The graph, coverage, ports and exposure record have consistent bindings to
these fixed types. All authorized SG input hashes are preserved.

The extractor's chronology qualification correctly distinguishes global seal
creation from that actor's later first exposure to the seal/types. Its raw
label does not claim that no global seal existed. This actor likewise claims
raw-before-own-type-exposure. No acceptance is inferred from creation times or
hashes, and no original record has been rewritten to repair chronology.

## Every atom and source region

All 79 atomic dispositions were inspected against this actor's own parser of
the exact raw HTML: 44 NODE and 35 EXCLUDED, unchanged from the extractor's raw
inventory. All 56 atom-source elements agree in their non-whitespace text.
The independently identified 47 substantive paragraph/display units from
Appendix C.2's opening through p12 end exactly match both coverage records.
The remaining standing/grid regions are explicitly discontiguous. No claim of
whole-paper, whole-Lemma-4.4 or p13-onward coverage is accepted.

All 463 locator occurrences across the authorized JSON records were checked
for raw SHA-256, UTF-8 span, Unicode-codepoint span and inclusive LF lines.
They cover 67 distinct raw spans, with no mismatch. Per-atom and per-locator
review records retain these exact checks.

The selected source content includes the actual independent-column experiment,
physical row marginal law, exact midpoint/features, both deterministic Fact C.5
identities and their substantive cosine proof regions, literal R/L and Ex107
Y_i, radial moment/common-a assertions, actual E[Y_i], direct Fact C.5 use and
both Ex110 sums. In particular n=2q+1, the constant feature, sine nonzero
condition and weighted-frequency range have not been lost.

The exclusions are faithful to this first-moment scope. Joint row/matrix
independence is not needed as a premise for individual means or finite
expectation linearity. B's range and untruncated means, spectral/kappa/C
context, deterministic uniform t-norm estimate, tail/common-event probability,
discarded bias and a-range estimates, concentration and later results are not
selected. Excluding a uniform t-norm bound does not assume integrability: each
literal fixed finite t still requires the internal matrix-integrability proof.

## Full root coverage and edge directions

All 62 nodes and 94 directed edges were inspected. Every consumer-use locator
matches the actual raw use site. The explicit OR join adds the two alternative
route links only as alternatives, and the resulting structure is acyclic.

Ordinary reverse edge closure, interpreting the explicit OR record, covers 24
nodes at FORMAL.producer and 54 at FORMAL.private-consumer. The graph also keeps
source assertions and formal applicability obligations as separate layers:
five source mean/sum endpoints are mapped by the ports' source_context and
consumer-use metadata rather than made theorem hypotheses. This review traces
them explicitly: mean.actual-Y has a 14-node source ancestry; the unweighted
and weighted sum-of-means endpoints have 30 and 31 nodes; the weighted actual
expectation conclusion has 32. The explicit Fact C.5 citation/use node is also
accounted for. These source and formal traces cover 59 nodes. The remaining
three are explicit physical-index, feature-index and B-normalization context.
Thus all 62 nodes are accounted for; there is no unexplained mathematical
region. The correspondence links in root-coverage.json do not invent formal
proof-dependency edges or treat a printed source assertion as a caller premise.

The source cosine chain retains constant/mixed/positive feature cases, the
sqrt(2) normalization, difference/sum frequencies, diagonal zero frequency and
nonzero-frequency cancellations. The weighted chain retains all four n±j±k
frequencies and their standing range. The direct Fact C.5 consumer use is
correctly at p12.4/Ex110, not inferred from an implementation import. No
untruncated B-moment or range theorem is substituted for the deterministic
frame identities.

## Applicability and integral challenges

The row-law port concerns the exact actual physical row under the exact fixed
column-product mu, including measurability. The name stdGaussian or a reported
canonical node is not an application. The physical-coordinate evaluation must
match the standard-Gaussian/basis semantics in the fixed type context. That
check remains internal and open; there is no arbitrary ambient transfer or
new row-law certificate.

Canonical retained-radius scalar integrability is separately exposed before
identifying the scalar a with each actual row's retained-radius coefficient.
This closes the coverage of the scalar totalization concern from the type
audit, without proving it. Canonical truncated outer-product moment
applicability and integrability, followed by actual same-mu row transport,
remain separate open obligations. A source formula or old theorem name is a
specification to match, not an admitted proof premise.

Actual Y integrability explicitly concerns almost-everywhere strong
measurability and finite norm integral in the actual complete Matrix L2
operator-norm structure. It is not merely coordinate integrability without a
matrix bridge. The two expectation-transport options are correctly OR:
continuous-linear-map transport through M -> d^{-1}(M tensor t_i t_i^T), or
continuous entry evaluations and finite-coordinate integral comparison. Each
option must match its norms, integrability and the literal actual Y. They are
inferred formal bookkeeping options, not two source-authored proofs or two
simultaneous public requirements. Likewise, possible bounded-truncation and
Gaussian-moment integrability methods are not turned into a false AND of
source hypotheses.

The actual matrix and its mean retain the inclusive cutoff, inverse d,
Gaussian-first paired indices, exact common scalar and unchanged sample
measure. No common truncation event conditions the law. Neither injectivity
nor identical distribution of the matrices is needed or supplied. The q=0
constant-feature endpoint remains, with n=1 and the actual midpoint weights.
All nonzero denominator facts remain internal, without kappa/tau inputs.

The consumer has explicit routes for deterministic tensor/frame algebra,
integrability of both actual finite sums, and finite Bochner integral/scalar
exchange. It does not replace integrals of actual sums by displayed sums of
means without those obligations. The unweighted identity must produce a
I_(r^2), using I_r tensor I_r and the exact d normalization; the weighted
identity must use the actual cos((2q+1)theta_i) factors. These routes use no
independence hypothesis.

The producer and consumer integrability outputs prevent their Bochner
equalities from being accepted through nonintegrable zero defaults. The
canonical scalar-a integral has its own open well-definedness port. Completeness
is the synthesized fixed matrix-space instance, not a caller certificate.
No default branch, positivity/bias estimate on a, formal mean matrix, compiled
parent name or process status is used to discharge an internal premise.

## Blockers versus open ports

Genuine source-statement/coverage/topology blockers: **none found**.

All 13 INTERNAL ports remain unproved: exact row law; scalar-a integrability;
canonical-to-actual a identification; canonical radial moment applicability;
actual row-moment transport; actual Y integrability; the CLM and entrywise
alternatives plus their OR join; literal frame applicability; tensor/sum
algebra; both actual sums' integrability; and finite Bochner exchange. Their
presence accounts for omitted proofs and applicability, without certifying
any one of them or adding public hypotheses. No genuine source defect is
asserted merely because these expected mathematical obligations are open.

All own raw/type/R7 originals and all ten authorized SG files remain unchanged.
No mathematical proof search, API search, implementation read, production
write, registry/C/L/Git change, compiled edge, source VERIFIED status, normal
intake or proof/process permission is granted.
