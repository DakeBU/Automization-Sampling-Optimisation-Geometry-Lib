# Independent type-only judgment v1

Stage: TYPES_ONLY, frozen after the independent RAW_SOURCE_ONLY v1 freeze and
before any supplied SG graph. This is a statement/definition-semantics judgment,
not Lean compilation, a proof certificate, source-publication acceptance, or an
approval of any unseen topology. Root is the sole prover.

## Exact inputs

Selective packet:
`.astis/huanjian-gc-source-row-law-20261112/selective-type-definition-packet.json`,
9976 bytes, SHA-256
`71806be7febb91c6ea9a847ce022065cec7eebf6b224503663fcbb7921bc5353`.
The packet names statement seal
`f9476ec7454a0927d3a1068226ad635b464d9b5d631f4992421d4b3b39b70ec3`.
That seal identity was checked against the assigned identity; the seal artifact
itself was not separately read. The two exact signature-string hashes and
product-definition excerpt-string hashes were recomputed successfully. Earlier
raw artifacts were all rehashed and unchanged before reading the packet.

Producer signature hash:
`82e3c608d456b2d190e50a7426aa5cb0c3f5a9c622906c7cb02cfe86cf3caf38`.
Consumer signature hash:
`93587ca60509760c39e7cfc60b71ec7fbc9059fd3cb98b1ec0c6b4da5e7d7c31`.

Only the exact packet, the earlier raw-source freeze, and mandatory process
instructions were used. Referenced receipt paths, Mathlib files, provider code,
prior reports, decoder output, implementations, ledgers, and graphs were not
opened. The packet's explanatory route sentence is exposure metadata only and
was not treated as proof evidence.

## Result

No blocking statement-semantic gap found for the bounded canonical source-column
experiment. The producer asserts each actual row's standard Gaussian marginal,
and the private consumer asserts the source all-good cutoff probability on that
same experiment. The types do not claim joint row independence. They do not
assert the full p1 independence clause, Fact C.6, full Lemma 4.4, or the main
lower-bound theorem.

This conclusion concerns the signatures and canonical meanings only. Actual
construction of both output fields, original-experiment tail transport,
measurability of the good event, finite union bookkeeping, and the probability
complement calculation remain proof obligations. The packet's definition
receipts are context about the standard objects, not target proof certificates.

## Seven semantic slots

1. Objects. D is the real Euclidean space with d coordinates; E is the real
Euclidean space with q+1 coordinates; an outcome omega is a tuple of q+1
D-valued columns. For each i, row i omega has a-th coordinate omega a i.
WithLp.toLp 2 changes the presentation to the canonical Euclidean row carrier;
it does not insert a scaling, permutation, covariance factor, or alternate row.
By the supplied canonical Euclidean norm meaning, norm(row i omega)^2 is exactly
sum_a (omega a i)^2, the source R_i.

2. Domains. d,q are natural numbers. hq is exactly 2*q+1<d. It implies d>=2,
and q=0 remains available. Fin d and Fin(q+1) use zero-based labels; i.val+1 and
a.val+1 match the source ranges 1<=i<=d and 1<=a<=r with r=q+1. No new dimension
or nonzero-r assumption is needed. The inherited source kappa>=2 pertains to the
spectral grid, which is absent and unnecessary here.

3. Quantifiers. The producer applies for every d,q in the source range and then
for every actual physical row i. The consumer applies for every such d,q and
uses a single omega beneath the universal quantifier over rows. It is not a
collection of unrelated marginal integrals or a probability evaluated on a
single generic canonical row.

4. Assumptions. The sole explicit logical binder is hq, a SOURCE standing-range
condition. Natural-number/Euclidean/finite-function/Borel structures are TYPING
context. mu is a definition of the source iid column experiment rather than a
hypothesis requiring an independence witness. No conditional tau bound,
concentration estimate, moment estimate, joint row law, integrability witness,
measurability gate, or claimed conclusion has been added as a public binder.
The packet's actual probability and sigma-finiteness instances are canonical
structure facts used to interpret the measure; they are not input assumptions.

5. Conclusions. The producer's MeasurePreserving output expands to two
conclusions: the actual row map is measurable, and its pushforward of mu equals
stdGaussian E. This is the desired marginal law plus its standard event-law
transport regularity. It neither assumes the result nor says different row
maps are independent. The consumer concludes

    ENNReal.ofReal (999/1000 : R) <= mu good,
    good={omega | for all i, norm(row i omega)^2 <= L}.

The good event is the actual source T in the column space. Its complement is
exactly the finite existential event that some actual row has squared norm
strictly greater than L. Event measurability follows mathematically from the
producer's measurable row maps, continuous norm-square, and finite intersection;
that should be discharged within implementation, not supplied as an extra
source hypothesis.

6. Scopes and senses. Measure.pi is the canonical finite product of the factor
stdGaussian D measures. On a Euclidean D with its canonical Borel structure,
stdGaussian is the standard centered covariance-identity Gaussian, even though
its definition uses an orthonormal basis. The packet's product definition and
actual probability/sigma-finiteness context make mu a probability law, so the
measure inequality is a probability statement with the intended normalization.
The source experiment with independent g_1,...,g_r is represented canonically
by these product coordinates. This is a concrete source-law realization; the
signatures do not quantify over an arbitrary alternate probability space with
independent column random variables. Transfer to an arbitrary extended source
experiment, if later needed, requires the equality of the joint column law to
this finite product and the associated event transport. That transfer is outside
this bounded type interface; it is not a flaw in its stated concrete scope.

7. Constants and endpoints. r is the real cast of q+1. L is literally
2*r+3*Real.log(1000*(d:R)); hq makes the logarithm input positive and at least
2000, so no nonpositive-log fallback is entered. The threshold is exact real
999/1000, not natural-number division. ENNReal.ofReal embeds this positive
finite rational without truncation, giving exactly source 0.999. The universal
good condition is <= L, so the bad event is > L. The q=0 endpoint is retained.
The producer does not mention a tail parameter x, and the consumer does not
change the source x>=0 or s>=0 endpoints because it evaluates the one source
cutoff. No factor d, factor r, or square has been lost.

## Original experiment versus separate marginals

The actual functions omega -> omega a are the columns in the canonical product
space. Their joint law is by definition the finite product of standard
d-Gaussian laws, which is exactly the source iid assumption. The row map then
reads the corresponding actual coordinates. Thus the producer does not replace
an actual row by an unrelated standard-r Gaussian random variable: it supplies
the law equality from that actual row to the canonical row law.

The consumer uses the identical D, E, Omega, mu and row definitions. Its finite
any-bad event is therefore a subset of the same column experiment. Once each
actual row tail is transported using the producer, a union bound applies
without joint row independence. No inference from marginal identities to joint
independence is licensed by these types.

## Bounded residuals and nonclaims

- No blocking added assumption, constant error, endpoint error, or coordinate
  mismatch found in the exact selective signatures.
- Canonical model versus arbitrary source probability space is an explicit
  interface scope limitation, not automatic universal-experiment transport.
- Measurability and map_eq are proof outputs; all-good event measurability and
  complement bookkeeping should be proved, not made future theorem hypotheses.
- Full joint row independence, p11 tail-moment expectation, truncated matrix
  independence, matrix concentration, Fact C.6 and Lemma 4.4 remain separate.

Freeze next: await the supplied SG graph and challenge its source topology
against this already frozen raw and type-only interpretation.
