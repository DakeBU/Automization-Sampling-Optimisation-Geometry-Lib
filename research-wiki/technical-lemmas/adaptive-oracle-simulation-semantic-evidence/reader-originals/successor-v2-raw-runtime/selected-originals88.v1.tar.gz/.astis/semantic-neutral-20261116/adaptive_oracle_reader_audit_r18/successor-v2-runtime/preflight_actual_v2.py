"""Independent read-only actual v2 fixture/assignment checks; never launches browser/server."""
from pathlib import Path
import ast
import hashlib
import json
import re

OWN=Path(__file__).resolve().parent
ROOT=OWN.parent
REPO=ROOT.parents[2]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assignment=OWN/'execution-assignment.ROOT.actual-v2.json'
a=json.loads(assignment.read_text())
checks=[]
def check(name,passed,detail=None):
    checks.append({'name':name,'pass':bool(passed),'detail':detail})
check('exact-actual-assignment-sha',sha(assignment)=='a291b00199047560b54dd2f1480d1d94cc30f748770c2d418a4be99d67d0e2f9')
check('ROOT-authorization-specific-runtime',a['authorization']=='ROOT_AUTHORIZED_AFTER_SOURCE_REVIEW' and 'one actual desktop1440x1000/mobile390x844' in a['execution_custody'])
for row in a['frozen_inputs']:
    check('frozen-input:'+row['path'],Path(row['path']).is_file() and sha(row['path'])==row['sha256'])
check('exact24-frozen-inputs',len(a['frozen_inputs'])==24)
v2=Path(a['preview_root'])
v1=REPO/'.astis/huanjian-gc-adaptive-oracle-simulation-20261116/metadata-drafts/reader-preparation-v1/isolated-preview-v1'
m=json.loads((v2/'preview-freeze-manifest.json').read_text())
old=json.loads((v1/'preview-freeze-manifest.json').read_text())
check('v2-manifest-sha',sha(v2/'preview-freeze-manifest.json')==a['preview_manifest_sha256']=='4c45858dc2ff77e6cf3fb0c3198ded46d7ef4820d342170e2d9223e372bb9ebf')
check('same118-input-freeze-manifest',sha(v2/'input-freeze-manifest.json')==sha(v1/'input-freeze-manifest.json')=='a62c0621d77ac967a67192a33e3eac0eea2c2e55bbd45cb3eb9908eccd976f27')
freeze=json.loads((v2/'input-freeze-manifest.json').read_text())
check('all118-snapshot-inputs-exact',len(freeze['files'])==118 and all(sha(v2/'input-snapshot'/r['path'])==r['sha256'] and (v2/'input-snapshot'/r['path']).read_bytes()==(v1/'input-snapshot'/r['path']).read_bytes() for r in freeze['files']))
delta=[]
for variant,data in m['variants'].items():
    fixture=v2/'fixtures'/variant
    actual={str(p.relative_to(fixture)) for p in fixture.rglob('*') if p.is_file()}
    expected={r['path'] for r in data['files']}
    check('exact-file-set-and-all-bytes:'+variant,actual==expected and all(sha(fixture/r['path'])==r['sha256'] and (fixture/r['path']).stat().st_size==r['bytes'] for r in data['files']),{'count':len(actual)})
    # The v2 manifest explicitly uses prior candidate104 as both new variants'
    # baseline; prior historical original103 is preserved in its old directory.
    before={r['path']:r for r in old['variants']['candidate']['files']}
    after={r['path']:r for r in data['files']}
    check('same-path-set-as-v1:'+variant,set(before)==set(after))
    changed=[p for p in after if (fixture/p).read_bytes()!=(v1/'fixtures/candidate'/p).read_bytes()]
    delta.append({'variant':variant,'changed_paths':changed})
    check('exact-allowed-path-delta:'+variant,changed==(['assets/mgf-reader-overlay.css'] if variant=='candidate' else []))
check('candidate-exact104',len(m['variants']['candidate']['files'])==a['selected_served_leaf_count']==104)
selection=json.loads((v2.parent/'candidate-served.selection.v2.json').read_text())
check('selected104-list-exact',selection['files']==m['variants']['candidate']['files'])
for key in ['proof_commit','lesson_sha256','publication_sha256','input_freeze_manifest_sha256']:
    check('unchanged-manifest-field:'+key,m[key]==old[key])
check('source-binding-and-artifact-exact',a['source_reviewed_publication_binding_sha256']=='38ae6f3bf655bb00e7b6054b55d2936fc06d254393ff607d4336cdbfb85201f6' and sha(a['actual_source_review_artifact']['path'])==a['actual_source_review_artifact']['sha256']=='04398c6f37ade7e9713b7ced032062ce9f9d85cbc416c7047986ffa39dddcee6')
check('preserved-original-FAIL',sha(ROOT/'actual-result.json')==a['preserved_original_failure_result_sha256']=='f7e3488bdca1e854664f1eb2e91f48169e554293964ed5019915a792ceb01578' and json.loads((ROOT/'actual-result.json').read_text())['status']=='FAIL')
check('preserved-actual-diagnostic',sha(ROOT/'diagnosis-v1/diagnostic-result.actual-v1.json')==a['actual_diagnostic_result_sha256']=='a209eae553a0da5cadc3e1c26c0c358139925c0fd711ec02e0134cf504524650')
css=v2/'fixtures/candidate/assets/mgf-reader-overlay.css'
oldcss=v1/'fixtures/candidate/assets/mgf-reader-overlay.css'
append=(v2.parent/'inline-math-local-scroll.APPEND.DRAFT.css').read_bytes()
check('CSS-exact-append-only',css.read_bytes()==oldcss.read_bytes()+append,{'old_sha256':sha(oldcss),'old_bytes':oldcss.stat().st_size,'new_sha256':sha(css),'new_bytes':css.stat().st_size,'append_bytes':len(append)})
text=append.decode(); clean=re.sub(r'/\*.*?\*/','',text,flags=re.S).strip()
selector,body=clean.split('{',1);body=body.rsplit('}',1)[0]
expected_selector='body[data-mgf-preview="huanjian-adaptive-oracle-simulation"][data-preview-variant="candidate"] .proof-reader .assumption-ledger li > mjx-container[jax="CHTML"]:not([display="true"])'
props=dict((k.strip(),v.strip()) for k,v in (part.split(':',1) for part in body.split(';') if part.strip()))
check('CSS-exact-top-level-assumption-inline-scope',selector.strip()==expected_selector)
check('CSS-only-six-reviewed-properties',props=={'display':'inline-block','max-width':'100%','overflow-x':'auto','overflow-y':'hidden','vertical-align':'middle','padding-block':'.125em'},props)
for file,key in [('browser_check.py','runner_sha256'),('browser_geometry.py','geometry_sha256'),('browser_anchor_wait.py','anchor_wait_sha256'),('browser_inline_regression.py','inline_regression_sha256')]:
    ast.parse((OWN/file).read_text())
    check('exact-reviewed-checker:'+file,sha(OWN/file)==a[key])
for name in ['browser_geometry.py','browser_anchor_wait.py']:
    check('original-helper-byte-identical:'+name,(OWN/name).read_bytes()==(ROOT/name).read_bytes())
tree=ast.parse((OWN/'prepare_checker.DRAFT.py').read_text())
insertions=next(ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and n.targets[0].id=='insertions')
restored=(OWN/'browser_check.py').read_text()
for anchor,addition in insertions:
    check('one-exact-checker-addition:'+anchor.strip(),restored.count(anchor+addition)==1)
    restored=restored.replace(anchor+addition,anchor)
check('all-original485-code-exactly-retained',restored==(ROOT/'browser_check.py').read_text())
check('actual-Chrome-launcher-hash',sha(a['chrome']['path'])==a['chrome']['binary_sha256']=='c9a0f292a25c3771f1895ec3397d2cbbee3ce07ce967acd35f34a38978b4aacd')
check('no-successor-runtime-result-preexists',not any((OWN/p).exists() for p in ['runtime-process','runtime-output','actual-result.json']))
result={'schema':'r18-independent-actual-v2-preflight-v1','status':'EXECUTABLE_PREFLIGHT' if all(c['pass'] for c in checks) else 'PREFLIGHT_ISSUE',
 'assignment_sha256':sha(assignment),'preview_manifest_sha256':sha(v2/'preview-freeze-manifest.json'),'checks':checks,'delta':delta,
 'new_browser_or_server_started_by_reader':False,'actual_browser_or_visual_acceptance':'PENDING: no actual v2 outcomes or PNGs yet',
 'no_source_verdict_or_V_public_main_purification_credit':True}
p=OWN/'ACTUAL-V2-PREFLIGHT.v1.json';p.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':result['status'],'checks':len(checks),'false':[c for c in checks if not c['pass']],'delta':delta,'result_sha256':sha(p)},indent=2))
