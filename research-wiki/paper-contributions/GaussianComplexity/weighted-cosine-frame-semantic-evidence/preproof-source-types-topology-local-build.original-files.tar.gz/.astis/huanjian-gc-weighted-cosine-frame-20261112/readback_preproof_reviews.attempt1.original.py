"""Bind independently frozen exact source/type/topology judgments, not proof truth."""
from pathlib import Path
import hashlib
import json

workspace = Path(__file__).resolve().parent
sha = lambda raw: hashlib.sha256(raw).hexdigest()
sg = Path('.astis/semantic-neutral-20261111/wf_sg_2cb7')
tc = Path('.astis/semantic-neutral-20261111/wf_tc_8ea0')
manifests = [
    (sg / 'RAW_FREEZE.json', sg, 'bcc921a94fd9d552fbc9e410eb3cce1731b5234fc5a073412cb13026c8ad0d56'),
    (sg / 'typed_overlay/TYPED_FREEZE.json', sg, '782cdb7a3ee26d91d0dd45c9a99b34370d22de2a457d1b1cfb802a5474d97455'),
    (tc / 'freeze-manifest.json', tc, 'da1e800bdeb38c0b9661278de6b385d5a428305184d82bfb671f279a46f018c3'),
    (tc / 'type-only/type-only-freeze-manifest.json', tc / 'type-only', '10c130cbc5e75cd2d8e4dc7eeac9fd390cc1dfb9e4ca2c54e1f7f65422a254c8'),
    (tc / 'topology-challenge/TOPOLOGY_CHALLENGE_FREEZE.json', tc, '44c12f21c122bd13bfcdb596c6f2ac0231adabeba53bf5eefa703a57bd8deb9f'),
]
originals = {}
for path, base, digest in manifests:
    raw = path.read_bytes()
    assert sha(raw) == digest, str(path)
    originals[str(path)] = {'path': str(path), 'bytes': len(raw), 'sha256': sha(raw)}
    manifest = json.loads(raw)
    for item in manifest['files']:
        original = base / item['path']
        content = original.read_bytes()
        assert len(content) == item['bytes'] and sha(content) == item['sha256'], str(original)
        originals[str(original)] = {'path': str(original), 'bytes': len(content), 'sha256': sha(content)}
gaps = json.loads((sg / 'typed_overlay/stopping_boundary_and_gaps.json').read_bytes())
assert gaps['semantic_blockers_in_exact_signatures'] == []
verdict_path = tc / 'topology-challenge/challenge-verdict.json'
verdict = json.loads(verdict_path.read_bytes())
assert sha(verdict_path.read_bytes()) == 'f624918eb801dd10e1513688afceefa81aa1fa8f2baf1632edff20e31c822928'
assert verdict['verdict'] == 'ACCEPTED_BOUNDED_SOURCE_TOPOLOGY_WITH_OPEN_PROOF_OBLIGATIONS'
for key in ('blocking_source_gaps', 'blocking_topology_gaps', 'required_mathematical_repairs'):
    assert verdict[key] == []
assert verdict['producer_closure']['gaussian_input'] is False
assert verdict['consumer_closure']['original_family_adapters_inherited'] is False
assert verdict['no_implementation_or_API_read'] and verdict['no_global_edits_or_ledger_calls']
assert verdict['no_proof_grant'] and verdict['no_process_grant']
record = {
    'source_type_verdict': 'accepted', 'independent_topology_verdict': 'accepted',
    'remaining_mathematical_source_topology_gaps': [], 'formalizer_API_pristine': False,
    'statement_seal_sha256': 'fca4e21eaa1e3107b6cfcf99c2a08c6dc7884c5a62f1dd4f626fbf3042cc4998',
    'SG_original_verdict': gaps['statement_scope'], 'TC_original_verdict': verdict['verdict'],
    'independent_originals': list(originals.values()),
    'primary_binder_clarification': verdict['primary_binder_classifications'],
    'mathematical_obligations': verdict['remaining_internal_proof_obligations'],
    'source_scope': 'Deterministic coefficient and canonical integrable marginal second-moment sum including q=0. Actual original-family law transport, centering and concentration remain open.',
    'authority': 'Independent source/type/topology judgments only. Existing user authorization supports normal intake. No proof, process permission grant or full-source completion.',
}
raw = (json.dumps(record, ensure_ascii=False, indent=2) + '\n').encode()
with (workspace / 'reviewed-preproof-inputs.json').open('xb') as out:
    out.write(raw)
print(json.dumps({'originals_rehashed': len(originals), 'record_sha256': sha(raw),
                  'source_type': 'accepted', 'topology': 'accepted', 'required_repairs': []}))
