from pathlib import Path
import json,hashlib,os,stat,datetime
ROOT=Path('/Users/zhouhuanjian/ASTIS-GC/.astis/semantic-neutral-20261110/kr_tc_72a0bf');P=ROOT/'phase3';sha=lambda b:hashlib.sha256(b).hexdigest()
def earlier():
 out=[]
 for s in ['phase1','phase2a','phase2b','phase2c']:
  b=(ROOT/f'{s}.manifest.json').read_bytes();m=json.loads(b)
  assert all(sha((ROOT/s/x['path']).read_bytes())==x['sha256'] and stat.S_IMODE((ROOT/s/x['path']).stat().st_mode)==0o444 for x in m['files'])
  assert stat.S_IMODE((ROOT/s).stat().st_mode)==0o555
  out.append({'stage':s,'manifest_sha256':sha(b),'all_hashes_modes_unchanged':True})
 return out
before=earlier();grantpath=P/'qualified-prospective-grant.json';g=json.loads(grantpath.read_bytes())
assert sha(grantpath.read_bytes())=='de404e2102d7cf74ef9462a3677bd81aa6e0398d529b9ee25f0059394743fe13'
assert g['prospective_target_Lean_proof_API_allowed_after_this_grant'] is True and g['root_sole_mathematical_worker'] is True
assert g['target_proof_API_currently_allowed_before_successful_intake_and_readback'] is False
assert all(sha(Path(x['path']).read_bytes())==x['sha256'] for x in g['independent_inputs'])
fs=sorted(p for p in P.rglob('*') if p.is_file());assert not any(p.is_symlink() for p in P.rglob('*'))
m={'stage':'phase3-independent-qualified-prospective-process-grant-after-mathematical-freeze','files':[{'path':str(p.relative_to(P)),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in fs]}
mp=ROOT/'phase3.manifest.json';mp.write_text(json.dumps(m,indent=2)+'\n')
for p in fs:os.chmod(p,0o444)
ds=[P]+[p for p in P.rglob('*') if p.is_dir()]
for p in sorted(ds,key=lambda p:len(p.parts),reverse=True):os.chmod(p,0o555)
os.chmod(mp,0o444)
assert all(stat.S_IMODE(p.stat().st_mode)==0o444 for p in fs) and all(stat.S_IMODE(p.stat().st_mode)==0o555 for p in ds)
assert all(sha((P/x['path']).read_bytes())==x['sha256'] for x in m['files']);assert earlier()==before
assert all(sha(Path(x['path']).read_bytes())==x['sha256'] for x in g['independent_inputs'])
receipt={'stage':'phase3','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'decision':'qualified prospective grant only; intake not executed, proof/API still barred until actual successful3events+guards+root readback','manifest_sha256':sha(mp.read_bytes()),'grant_path':str(grantpath),'grant_sha256':sha(grantpath.read_bytes()),'grant_independent_inputs':len(g['independent_inputs']),'all_bound_inputs_rehashed_before_and_after_freeze':True,'payload_files':len(fs),'payload_directories':len(ds),'all_files_0444':True,'all_directories_0555':True,'actual_manifest_hash_mode_recheck':True,'earlier_freezes':before,'reviewer_executed_intake':False,'root_API_pristine':False,'private_foreign_values_or_inventories_exported':False}
rp=ROOT/'phase3.freeze.receipt.json';rp.write_text(json.dumps(receipt,indent=2)+'\n');os.chmod(rp,0o444);print(json.dumps(receipt,indent=2))
