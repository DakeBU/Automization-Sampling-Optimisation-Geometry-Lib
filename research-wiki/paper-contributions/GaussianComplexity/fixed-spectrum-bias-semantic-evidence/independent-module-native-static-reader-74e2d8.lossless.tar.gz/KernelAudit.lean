import AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumBias
import Tests.GaussianComplexityFixedSpectrumBias
import Lean
noncomputable section
open Lean Meta Elab Command MeasureTheory ProbabilityTheory
open scoped BigOperators Interval
set_option linter.unusedVariables false
def expectedProducer : Prop := ∀ {d : ℕ} (hd : 2 ≤ d) {κ : ℝ} (hκ : 2 ≤ κ)
    (n : ℕ) (hn : 1 ≤ n) (hnd : n < d) (hgap : Real.sqrt κ ≤ (d : ℝ) - (n : ℝ)),
  let θ : Fin d → ℝ := fun i => ((i.val : ℝ) + 1 / 2) * Real.pi / (d : ℝ)
  let eigenvalue : Fin d → ℝ := fun i => (κ + 1) / 2 + (κ - 1) / 2 * Real.cos (θ i)
  let Λ : Matrix (Fin d) (Fin d) ℝ := Matrix.diagonal eigenvalue
  let μ : Measure (EuclideanSpace ℝ (Fin d)) :=
    multivariateGaussian (0 : EuclideanSpace ℝ (Fin d)) Λ⁻¹
  let Q : EuclideanSpace ℝ (Fin d) → ℝ := fun x =>
    ∑ i : Fin d, Real.cos ((n : ℝ) * θ i) * (WithLp.ofLp x i) ^ 2
  let M : ℝ := ∫ x : EuclideanSpace ℝ (Fin d), ‖x‖ ^ 2 ∂μ
  let b : ℝ := ∫ x : EuclideanSpace ℝ (Fin d), Q x ∂μ
  0 < M ∧ 0 < (-1 : ℝ) ^ n * b ∧
  (1 - Real.exp (-4)) * Real.exp (-3 * (n : ℝ) / Real.sqrt κ) ≤ |b| / M ∧
  |b| / M ≤ Real.exp (-2 * (n : ℝ) / Real.sqrt κ)

def expectedConsumer : Prop := ∀ {d : ℕ} (hd : 2 ≤ d) {κ : ℝ} (hκ : 2 ≤ κ)
    (n : ℕ) (hn : 1 ≤ n) (hnd : n < d) (hgap : Real.sqrt κ ≤ (d : ℝ) - (n : ℝ)),
  let θ : Fin d → ℝ := fun i => ((i.val : ℝ) + 1 / 2) * Real.pi / (d : ℝ)
  let eigenvalue : Fin d → ℝ := fun i => (κ + 1) / 2 + (κ - 1) / 2 * Real.cos (θ i)
  let Λ : Matrix (Fin d) (Fin d) ℝ := Matrix.diagonal eigenvalue
  let μ : Measure (EuclideanSpace ℝ (Fin d)) :=
    multivariateGaussian (0 : EuclideanSpace ℝ (Fin d)) Λ⁻¹
  let Q : EuclideanSpace ℝ (Fin d) → ℝ := fun x =>
    ∑ i : Fin d, Real.cos ((n : ℝ) * θ i) * (WithLp.ofLp x i) ^ 2
  let M : ℝ := ∫ x : EuclideanSpace ℝ (Fin d), ‖x‖ ^ 2 ∂μ
  (μ {x : EuclideanSpace ℝ (Fin d) | (-1 : ℝ) ^ n * Q x ≤ 0}).toReal ≤
    2 * Real.exp (6 * (n : ℝ) / Real.sqrt κ) / ((1 - Real.exp (-4)) ^ 2 * M)
def auditReachable (env : Environment) (owned : NameSet) (roots : Array Name) : MetaM NameSet := do
  let mut pending := roots
  let mut seen : NameSet := {}
  for _ in [:1000] do
    if pending.isEmpty then break
    let n := pending.back!
    pending := pending.pop
    if seen.contains n then continue
    seen := seen.insert n
    let ci ← getConstInfo n
    for d in ci.getUsedConstantsAsSet.toList do
      if owned.contains d && !seen.contains d then pending := pending.push d
  unless pending.isEmpty do throwError "Bounded local closure exceeded 1000 steps"
  return seen

def auditFirstPublic (env : Environment) (root : Name) : MetaM NameSet := do
  let mut pending := #[root]
  let mut seen : NameSet := {}
  let mut parents : NameSet := {}
  for _ in [:1000] do
    if pending.isEmpty then break
    let n := pending.back!
    pending := pending.pop
    if seen.contains n then continue
    seen := seen.insert n
    let ci ← getConstInfo n
    for d in ci.getUsedConstantsAsSet.toList do
      if d.toString.startsWith "AutoSamplingTheory." && d != root then
        parents := parents.insert d
      else if d.toString.startsWith "_private.AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumBias." ||
          d.toString.startsWith "_private.Tests.GaussianComplexityFixedSpectrumBias." then
        if !seen.contains d then pending := pending.push d
  unless pending.isEmpty do throwError "First-public closure exceeded 1000 steps"
  return parents

run_elab do
  let env ← getEnv
  let modNames := #[`AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumBias,
    `Tests.GaussianComplexityFixedSpectrumBias]
  let ownedPairs := env.constants.toList.filter fun (n, _) =>
    match env.getModuleIdxFor? n with
    | none => false
    | some idx => modNames.contains env.header.moduleNames[idx.toNat]!
  let owned := NameSet.ofList (ownedPairs.map Prod.fst)
  let suffixes := ["actual_diagonal_gaussian_exponential_bias", "log_remainder_integral",
    "log_integral_identities", "log_integral_bounds", "spectral_ratio_log_bounds",
    "spectral_ratio_power_bounds", "actual_gaussian_zero_threshold_probability_le"]
  let mut roots : Array Name := #[]
  for suffix in suffixes do
    let candidates := ownedPairs.filter fun (n, _) => n.toString.endsWith ("." ++ suffix) || n.toString == suffix
    unless candidates.length == 1 do throwError "Expected one handwritten declaration {suffix}, found {candidates.length}"
    roots := roots.push candidates.head!.1
  let producer ← getConstInfo roots[0]!
  let consumer ← getConstInfo roots[6]!
  let ep ← getConstInfo ``expectedProducer
  let ec ← getConstInfo ``expectedConsumer
  unless ← isDefEq producer.type (ep.value? (allowOpaque := true)).get! do throwError "Producer seal mismatch"
  unless ← isDefEq consumer.type (ec.value? (allowOpaque := true)).get! do throwError "Consumer seal mismatch"
  logInfo "EXACT_SIGNATURES producer=true consumer=true"
  let reach ← auditReachable env owned #[roots[0]!, roots[6]!]
  let producerReach ← auditReachable env owned #[roots[0]!]
  logInfo m!"OWNED_COUNT {ownedPairs.length}"
  logInfo m!"ROOT_REACHABLE_COUNT {reach.toList.length}"
  for (n, ci) in ownedPairs.mergeSort (fun a b => a.1.toString < b.1.toString) do
    let category := if roots.contains n then "handwritten" else if (n.toString.splitOn "_proof_").length > 1 then "generated-proof" else if (n.toString.splitOn "_simp_").length > 1 then "generated-simp" else "OTHER"
    let axs ← Lean.collectAxioms n
    logInfo m!"OWNED {n}\nCATEGORY {category} REACHABLE {reach.contains n} PRODUCER_REACHABLE {producerReach.contains n}\nAXIOMS {axs}"
    if category != "handwritten" then
      let t := (← ppExpr ci.type).pretty
      logInfo m!"GENERATED_TYPE {t.take 1000}"
  for n in [roots[0]!, roots[6]!] do
    logInfo m!"FIRST_PUBLIC {n}\nPARENTS {(← auditFirstPublic env n).toList}"
    let ci ← getConstInfo n
    let relevant := ci.getUsedConstantsAsSet.toList.filter fun d =>
      d.toString.startsWith "AutoSamplingTheory." || d.toString.startsWith "_private.AutoSamplingTheory." ||
      d.toString.startsWith "ProbabilityTheory." || d.toString.startsWith "ENNReal." ||
      d.toString.startsWith "MeasureTheory.MemLp."
    logInfo m!"DIRECT_RELEVANT {relevant}"
  logInfo m!"PRODUCER_TYPE {← ppExpr producer.type}"
  logInfo m!"CONSUMER_TYPE {← ppExpr consumer.type}"
