from pathlib import Path
import datetime, hashlib, json, subprocess
sha = lambda b: hashlib.sha256(b).hexdigest()
R = Path('.astis/huanjian-gc-fixed-spectrum-first-order-integration-20261108')
I = R/'independent-reader'; Q = I/'actual-sourceV-own-metadata-overlay-v3'
for name,digest in {'actual-sourceV-ownprojection-review.json':'71bac94c2d16dab1169ca19f1cc927ab9f144a63d38af96fa4be41b6d8f3a370',
                    'actual-root-STAB-ownprojection-readback.json':'5460ab04d35a7e329d6416320ba01e8ae0ba7393562db6465624db7e7ea750dd'}.items():
    assert sha((Q/name).read_bytes()) == digest
    assert not json.loads((Q/name).read_bytes()).get('blocking_objections',[])
p = Path('research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-first-order.json')
before = subprocess.check_output(['git','show','9d306d837fbddf1518b0035494baaf5c21c24488:'+str(p)])
after = p.read_bytes()
def delta(x,y,path=''):
    if isinstance(x,dict) and isinstance(y,dict):
        out=[]
        for k in sorted(x.keys()|y.keys()):
            key=path+'/'+k.replace('~','~0').replace('/','~1')
            out.extend(delta(x[k],y[k],key) if k in x and k in y else [key])
        return out
    return [] if x==y else [path]
record = json.loads((I/'UNAUTHORIZED-own-frontier-projection-v3.template.json').read_bytes())
assert record['before_sha256'] == sha(before) and record['after_sha256'] == sha(after)
assert record['changed_json_paths'] == delta(json.loads(before),json.loads(after))
record['state'] = 'EXACT_OWN_PROJECTION_REVIEWED_AFTER_ACTUAL_INDEPENDENT_V_AND_SOLE_STAB'
record['authorized_by'] = '/root'
record['reviewed_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
record['independent_existing_V_projection_review'] = {'path':str(Q/'actual-sourceV-ownprojection-review.json'),'sha256':sha((Q/'actual-sourceV-ownprojection-review.json').read_bytes())}
record['independent_actual_STAB_readback'] = {'path':str(Q/'actual-root-STAB-ownprojection-readback.json'),'sha256':sha((Q/'actual-root-STAB-ownprojection-readback.json').read_bytes())}
record['boundary'] = 'Only mechanical metadata for actual sourceV306 and actualSTAB621; no mathematical statement/sourcegraph/binder/parent change, root source verdict, browser or local acceptance.'
out = R/'root-exact-own-frontier-projection-review-v3.json'; assert not out.exists()
out.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'root_exact_projection_review':str(out),'sha256':sha(out.read_bytes()),
                  'actual_named_metadata_paths':len(record['changed_json_paths']),'new_source_verdict':False}))
