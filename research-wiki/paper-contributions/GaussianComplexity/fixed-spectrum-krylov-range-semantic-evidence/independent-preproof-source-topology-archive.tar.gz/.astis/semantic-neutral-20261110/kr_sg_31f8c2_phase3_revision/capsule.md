独立挑战经原始 source span 和实际 Set.range literal 重读后，R1/R2均有来源支持；这是作者修订，等待独立 exact-overlay recheck，非sourceV或topology批准。

R1：e-witness现在只消费 C5.range-reverse + definition-only E.range-existential。E.range-columns以及其在e-range中的作用原样保留；不再把列缩放/column-span theorem重复列为witness处直接父边。typed P.reverse→T.witness同步显式化image定义。若只有range(B)⊆K，不能取得任意u∈K的c。

R2：新增内部数学subobligation E.diagonal-power-action：((Λ^j).mulVec g_a)_i=λ_i^j(g_a)_i，含j=0的identity action；并明确有限加权polynomial lift。它绑定e-span及typed P.objects/P.polynomial/P.triangular中的P.diagonal-action。非对角矩阵或把j0误作entrywise power会破坏此桥；q0、零g、零λ无问题。没有新caller certificate/假设，也没有声称已编译。

提供FULL source-graph.v2.json、FULL type-source-overlay.v2.json与精确structured-delta-and-lineage.json。原520项coverage、pins、P/T signatures、所有binder/definitions、C5分量与C6路线均不变；原Phase1/2文件及权限逐项保存。全部剩余实际证明/编译义务仍开放。封存后暂停供独立精确版本复核。
