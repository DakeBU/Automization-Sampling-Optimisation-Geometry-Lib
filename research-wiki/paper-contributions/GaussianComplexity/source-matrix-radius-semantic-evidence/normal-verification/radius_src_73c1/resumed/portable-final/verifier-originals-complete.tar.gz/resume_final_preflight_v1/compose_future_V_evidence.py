"""Pure evidence composition. No API, state, ledger or file mutation."""
from pathlib import Path
import copy,hashlib,json
ORIGINAL=Path("research-wiki/paper-contributions/GaussianComplexity/source-matrix-radius-semantic-evidence/actual-PROVED_LOCAL-evidence.full.json")
EXPECTED_SHA256="e2ca572ea630b2a9df348206e21fb92f36c43954cbb6c83a02e8e8144bdd34c7"
def compose(additional):
 raw=ORIGINAL.read_bytes()
 if hashlib.sha256(raw).hexdigest()!=EXPECTED_SHA256:raise ValueError("Original PL payload hash changed")
 original=json.loads(raw)
 if len(original)!=25:raise ValueError("Original PL payload field count changed")
 if not isinstance(additional,dict) or set(original)&set(additional):raise ValueError("New evidence must use disjoint additional keys; never overwrite original PL values")
 ref=additional.get("independent_verification")
 if not isinstance(ref,str) or not ref.strip():raise ValueError("independent_verification must be a nonempty STRING reference")
 details=additional.get("independent_verification_details")
 if not isinstance(details,dict) or not details:raise ValueError("independent_verification_details must hold separate structured detail")
 result=copy.deepcopy(original)
 result.update(copy.deepcopy(additional))
 if not all(result[k]==v for k,v in original.items()):raise AssertionError("Original PL values were not preserved inline")
 return result
