"""Freeze source-only independent challenge; no Lean/API execution or shared writes."""
from pathlib import Path
from collections import Counter, defaultdict
import datetime, hashlib, json, re

ROOT = Path('/Users/zhouhuanjian/ASTIS-GC')
DEST = ROOT / '.astis/semantic-neutral-20261112/mp_tc_84b1/topology-v1'
SG = ROOT / '.astis/semantic-neutral-20261112/mp_sg_52ad/background-graph-freeze-v1'
PACKET = ROOT / '.astis/huanjian-real-matrix-positive-integral-20261112/selective-type-definition-packet.json'
PAPER = ROOT / '.astis/huanjian-resume-20261103/2610.20492v1.html'
ML = ROOT / '.lake/packages/mathlib/Mathlib/Analysis/Convex/Integral.lean'

def sha(b): return hashlib.sha256(b).hexdigest()
def rel(p): return str(p.relative_to(ROOT))
def rec(p):
    b = p.read_bytes()
    return {'path': rel(p), 'bytes': len(b), 'sha256': sha(b)}
def readj(p): return json.loads(p.read_text())
def writej(name, data):
    (DEST / name).write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')

expected = {
    'background-source-graph.json': '46178eb3e91bade03e2d419ff44423801e1a408d9f126fa2ebfa32342e47cb47',
    'freeze-manifest.json': '690b88567793ee26bcc04df298edcf8794e557c870f998551b73f9b363056126',
    'coverage.json': 'e4a99f31dd47a2cae21a614e45859a5d5216428b49a2081e12520e186e0db10c',
    'internal-ports-and-source-gaps.json': '209f05c0f67342b5ee141c7795715ab37a17fc29d15b6e177b8c853fcc65941f',
    'source-inventory.json': '0cccc68d8933d184078e1a7b7fb2ee8bf48b65f9451cac99d5d321ed476d5c2a',
    'source-locators.json': '3d1ef9b0bc770be6f2eeb1f77e5f521fc13f09802024b52e8a24f2f816287a6f',
    'source-exposure-and-attribution.json': '580c14aee040c6e731e35d93204932727e16608a50ed27e6b4a202066bf91811',
    'background-reading-report.md': '1b79f60514fb95292a93e1220f7a1c17341ad00bf067f9f2c3c1ea39b36b8043',
    'README.md': 'dfa43fda43e0427f2044d0dc1975c435eafc5df057669286c83e3e2081bbbdf2',
    'freeze-manifest.sha256': 'd51e6a61bc4629fae0b4168ed7f10dc8606ad3789f91532ebdf604bd81784ecc',
}
public_records = []
for name, digest in expected.items():
    r = rec(SG / name)
    assert r['sha256'] == digest, (name, r)
    public_records.append(r)
assert sha(PACKET.read_bytes()) == 'd2d9493c6fd09222fbe183fcb296bd0c104328a462a03f28b7c9930caa9b9e95'
packet = readj(PACKET)
g = readj(SG / 'background-source-graph.json')
inv = readj(SG / 'source-inventory.json')
loc = readj(SG / 'source-locators.json')
ports = readj(SG / 'internal-ports-and-source-gaps.json')
manifest = readj(SG / 'freeze-manifest.json')
cov = readj(SG / 'coverage.json')

origin_bytes = {
    'PAPER': PAPER.read_bytes(),
    'MATHLIB': ML.read_bytes(),
    'LITERAL_PRINT': packet['minimal_definition_context']['literal_current_prints_and_instances'].encode(),
}
origin_expected = {
    'PAPER': '6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915',
    'MATHLIB': '1b3115887fabf0dccc2fed689d1f1ddc7a114b5de4594e752c02908a445aafb4',
    'LITERAL_PRINT': 'ae2456e958755109ab3908f7a2baee94ed345331779c691f73aa4c141acdc3aa',
}
for origin, b in origin_bytes.items(): assert sha(b) == origin_expected[origin]
origin_text = {k: b.decode() for k, b in origin_bytes.items()}

bindings = {
    'packet_sha256': 'd2d9493c6fd09222fbe183fcb296bd0c104328a462a03f28b7c9930caa9b9e95',
    'statement_seal_sha256': 'a5179ed392ef8e55ab470a3a98ebd542e35301f51472e9cdd7bc168a88bafa26',
    'producer_signature_sha256': '283e07e3c85b9a5cce5c3c40f574f23f593dfcca5e35be4d3e2800f378208b19',
    'definition_context_sha256': 'f43d358af135d42c8585f927f7e20b2b3363af2bf28eed98298f2996a2f8e591',
    'unchanged_R9_consumer_signature_sha256': 'd5ac54443c79ea7b35b09ddcd6b5e3c40bef081bbe4f196cae5ab3ead35aa2ea',
    'primary_paper_source_sha256': origin_expected['PAPER'],
    'mathlib_convex_integral_source_sha256': origin_expected['MATHLIB'],
    'mathlib_pin': 'db584cd6d46c92f209a44c0f1c829460d327499d',
}
for artifact in [g, inv, ports, manifest, cov]:
    for k, v in bindings.items(): assert artifact['bindings'][k] == v, k
for k, v in loc['source_hashes'].items():
    assert v == origin_expected[k], (k, v)

locator_checks = []
def check_locator(l, origin, location):
    assert origin in origin_bytes, (location, origin)
    b, t = origin_bytes[origin], origin_text[origin]
    a, z = l['utf8_byte_start'], l['utf8_byte_end_exclusive']
    ca, cz = l['unicode_char_start'], l['unicode_char_end_exclusive']
    assert 0 <= a <= z <= len(b)
    assert 0 <= ca <= cz <= len(t)
    assert len(t[:ca].encode()) == a and len(t[:cz].encode()) == z
    assert b[a:z] == t[ca:cz].encode()
    assert sha(b[a:z]) == l['raw_fragment_sha256']
    assert t[:ca].count('\n') + 1 == l['lf_line_start_1based']
    assert t[:max(ca, cz-1)].count('\n') + 1 == l['lf_line_end_1based']
    locator_checks.append({'artifact_location': location, 'origin': origin, 'locator': l, 'exact_raw_and_coordinates_match': True})
def walk(x, location, inherited_origin=None):
    if isinstance(x, dict):
        origin = x.get('origin', inherited_origin)
        if 'utf8_byte_start' in x:
            check_locator(x, origin, location)
        else:
            for k, v in x.items(): walk(v, location + '/' + k, origin)
    elif isinstance(x, list):
        for i, v in enumerate(x): walk(v, location + '/' + str(i), inherited_origin)
for name, artifact in [('source-inventory.json', inv), ('source-locators.json', loc), ('background-source-graph.json', g)]:
    walk(artifact, name)
assert len(locator_checks) == 239
unique_locs = {(r['origin'], r['locator']['utf8_byte_start'], r['locator']['utf8_byte_end_exclusive']) for r in locator_checks}
assert len(unique_locs) == 58

items = inv['items']
assert len(items) == 68 and Counter(x['disposition'] for x in items) == {'NODE': 31, 'EXCLUDED': 37}
assert set(loc['units']) == {x['id'] for x in items}
fragments = []
atom_reviews = []
for item in items:
    ident = item['id']
    assert loc['units'][ident] == {'origin': item['origin'], 'locator': item['locator']}
    fp = SG / 'source-fragments' / (ident + '.txt')
    l = item['locator']
    assert fp.read_bytes() == origin_bytes[item['origin']][l['utf8_byte_start']:l['utf8_byte_end_exclusive']]
    fragments.append(rec(fp))
    if item['origin'] == 'PAPER':
        challenge = ('Concrete p14 application need only; no arbitrary-f theorem attribution and no new R9 premise.' if item['disposition'] == 'NODE' else 'Excluded from shared bridge; concrete R9 moment/algebra/frame/centering/norm work is neither assumed nor discharged.')
    elif item['origin'] == 'MATHLIB':
        challenge = ('Exact upstream specification/proof/context, not a compiled ASTIS parent or a new caller hypothesis.' if item['disposition'] == 'NODE' else 'Other exposed upstream context/theorem explicitly excluded; its extra hypotheses and conclusion give no target proof credit.')
    else:
        challenge = 'Exact supplied definition expansion; its mathematical/application obligations remain internal and include full PSD Hermitian conjunct.'
    atom_reviews.append({'id': ident, 'origin': item['origin'], 'source_disposition': item['disposition'], 'independent_disposition': item['disposition'], 'meaning_reviewed': item['meaning'], 'locator': item['locator'], 'source_element_id': item.get('source_element_id'), 'challenge': challenge, 'finding': 'NO_GENUINE_COVERAGE_OR_ATTRIBUTION_BLOCKER', 'source_fragment': rec(fp)})

theorems = re.findall(r'(?m)^theorem\s+([^\s(:]+)', origin_text['MATHLIB'])
assert len(theorems) == 22
excluded_ml = [x for x in items if x['origin'] == 'MATHLIB' and x['disposition'] == 'EXCLUDED' and x['id'].startswith('ML.EXCLUDED.')]
if len(excluded_ml) != 21:
    excluded_ml = [x for x in items if x['origin'] == 'MATHLIB' and x['disposition'] == 'EXCLUDED' and x['locator']['lf_line_start_1based'] >= 84]
assert len(excluded_ml) == 21
selected_lines = set()
for item in items:
    if item['origin'] == 'MATHLIB' and item['disposition'] == 'NODE':
        selected_lines.update(range(item['locator']['lf_line_start_1based'], item['locator']['lf_line_end_1based'] + 1))
assert set(range(54, 84)) <= selected_lines

nodes = {n['id']: n for n in g['nodes']}
assert len(nodes) == 50 and len(g['edges']) == 68 and len(g['hyperedges']) == 1
assert {x['id'] for x in items if x['disposition'] == 'NODE'} == {x['id'] for x in g['nodes'] if x.get('origin') in origin_bytes}
assert not g['compiled_parents'] and not g['genuine_source_gaps']
assert len(ports['ports']) == 13 and not ports['genuine_source_gaps']
assert {x['id'] for x in ports['ports']} == {x for x in nodes if x.startswith('INTERNAL.')}

def edge_challenge(e):
    to = e['to']
    if to.startswith('ML.'):
        return 'Printed upstream proof dependency and exact consumer-use locator checked; no ASTIS compiled call claimed.'
    if to in ['INTERNAL.PSD-cone-definition', 'INTERNAL.PSD-cone-convex', 'INTERNAL.PSD-cone-closed']:
        return 'Full Hermitian-plus-quadratic PSD geometry must be proved in actual L2Operator topology, including empty index; definition/source text is not a formal hypothesis.'
    if to == 'INTERNAL.AE-and-probability':
        return 'Only authored hf/hpos/probability inputs; AE remains AE and representative/Borel/nonempty setup stays internal.'
    if to == 'INTERNAL.convex-integral-application':
        return 'All exact upstream conditions and matrix ambient structures must be internally discharged before this route applies.'
    if to == 'INTERNAL.direct-Hermitian-integral':
        return 'Direct alternative must internally justify AE Hermitian integral transport with real entries/conjugate transpose and Bochner integrability.'
    if to == 'INTERNAL.direct-quadratic-integral':
        return 'Direct alternative must internally commute each fixed-vector continuous linear quadratic evaluation with actual integral and preserve AE nonnegativity.'
    if to == 'INTERNAL.direct-PSD-combine':
        return 'Hermitian AND all quadratic positivity within direct alternative; not an OR between PSD conjuncts.'
    if to in ['INTERNAL.actual-residual-hf', 'INTERNAL.actual-residual-hpos']:
        return 'Actual same-mu untruncated-majorant minus Yi-square residual; literal closed cutoff, all integrability and full PSD retained internally.'
    if to == 'INTERNAL.actual-residual-integral':
        return 'Generic conclusion plus internal residual inputs; individual integrabilities, subtraction and expected-majorant identification still required.'
    if to == 'APPLICATION.R9-PSD-residual':
        return 'Intended residual-positivity interface only; not full R9 fourth-moment/frame/final PSD/norm theorem.'
    if to == 'INTERNAL.centered-square-consumers':
        return 'Planned centered/weighted square positivity family; actual integrability/AE PSD and later identity/scaling/norm arguments remain internal.'
    if to == 'APPLICATION.centered-weighted-squares':
        return 'Supports integral lower PSD facts only; does not close noncommutative variance identity, cosine upper comparison or final norms.'
    raise AssertionError(e)
edge_reviews = []
pred = defaultdict(set)
succ = defaultdict(set)
for i, e in enumerate(g['edges'], 1):
    assert e['from'] in nodes and e['to'] in nodes and e['compiled_dependency'] is False
    assert e['consumer_use_sites']
    pred[e['to']].add(e['from']); succ[e['from']].add(e['to'])
    edge_reviews.append({'edge_number_1based': i, 'from': e['from'], 'to': e['to'], 'kind': e['kind'], 'source_meaning': e['meaning'], 'consumer_use_sites': e['consumer_use_sites'], 'independent_challenge': edge_challenge(e), 'verdict': 'UNPROVED_SOURCE_OR_INTERNAL_OBLIGATION_NOT_COMPILED', 'genuine_blocker': False})
hyper = g['hyperedges'][0]
assert hyper['id'] == 'OR.integral-PSD'
assert hyper['premise_formula'] == 'INTERNAL.convex-integral-application OR INTERNAL.direct-PSD-combine'
assert hyper['conclusion'] == 'FORMAL.shared-producer'
for p in ['INTERNAL.convex-integral-application', 'INTERNAL.direct-PSD-combine']:
    pred['FORMAL.shared-producer'].add(p); succ[p].add('FORMAL.shared-producer')
visiting, done = set(), set()
def visit(n):
    assert n not in visiting, ('cycle', n)
    if n in done: return
    visiting.add(n)
    for m in succ[n]: visit(m)
    visiting.remove(n); done.add(n)
for n in nodes: visit(n)
def closure(n):
    result, todo = set(), [n]
    while todo:
        x = todo.pop()
        if x not in result: result.add(x); todo.extend(pred[x])
    return result
roots = ['FORMAL.shared-producer', 'APPLICATION.R9-PSD-residual', 'APPLICATION.centered-weighted-squares', 'ML.contract.conclusion']
closures = {x: closure(x) for x in roots}
assert [len(closures[x]) for x in roots] == [34, 40, 38, 17]
union = set.union(*closures.values())
assert len(union) == 44
endpoint = 'PAPER.integrated-uncentered-bound'
contexts = set(nodes) - union - {endpoint}
assert contexts == {'ML.typing-context', 'ML.integral-mem-doc', 'ML.borel-setup', 'DEF.conjTranspose', 'DEF.HasFiniteIntegral'}

port_cautions = {
    'INTERNAL.PSD-cone-definition': 'Full Hermitian and every Finsupp quadratic predicate, not just diagonal/entry positivity; finite empty carrier included.',
    'INTERNAL.PSD-cone-convex': 'Internal convexity of entire real PSD set; no public convex-cone certificate.',
    'INTERNAL.PSD-cone-closed': 'Internal closedness in actual L2Operator topology; no unrelated norm/topology substitution.',
    'INTERNAL.Matrix-complete-space': 'Generic finite real matrix normed/vector/complete applicability including empty n; no actual generic typeclass synthesis checked here.',
    'INTERNAL.AE-and-probability': 'Match exact authored hf/hpos/probability; no new Nonempty n, pointwise Measurable f, Borel Omega, SeparableSpace or representative binder.',
    'INTERNAL.convex-integral-application': 'Closed-convex OR branch only; theorem name and printed proof do not establish current exact application.',
    'INTERNAL.direct-Hermitian-integral': 'Direct OR branch; exact AE transpose/entry integral transport internally justified.',
    'INTERNAL.direct-quadratic-integral': 'Direct OR branch; fixed-vector evaluation linear in matrix, actual integrability and integral commutation internal.',
    'INTERNAL.direct-PSD-combine': 'AND of Hermitian and quadratic obligations inside direct alternative; no need to implement both complete OR routes.',
    'INTERNAL.actual-residual-hf': 'Actual A_i - Yi^2 under same original mu, no added generic hf to R9.',
    'INTERNAL.actual-residual-hpos': 'Actual untruncated tensor majorant minus literal closed-cutoff square; full pointwise/AE PSD internally proved.',
    'INTERNAL.actual-residual-integral': 'Individual integrabilities for integral subtraction, exact source majorant expectation/tensor/sum transport retained; not full R9 bound.',
    'INTERNAL.centered-square-consumers': 'Actual centered/weighted squares integrability and AE PSD first; not mean/cosine/variance/norm theorem merely from generic positivity.',
}
port_reviews = []
for p in ports['ports']:
    assert not p['compiled_parents'] and not p['genuine_SOURCE_GAP']
    port_reviews.append({'id': p['id'], 'source_obligation': p['meaning'], 'independent_challenge': port_cautions[p['id']], 'status': 'OPEN_UNPROVED_INTERNAL', 'new_Gaussian_public_premise': False, 'genuine_blocker': False, 'compiled_parent_claim': False})

# Guard only our own previous frozen originals, never other actors' old verdicts.
old_manifests = []
for root_name, paths in {
    'ri_tc_24a6': ['SHA256SUMS', 'TYPE-SHA256SUMS', 'GRAPH-SHA256SUMS-v1', 'conceptual-v1/SHA256SUMS'],
    'mm_tc_7f32': ['SHA256SUMS', 'type-v1/SHA256SUMS', 'topology-v1/SHA256SUMS', 'conceptual-v1/SHA256SUMS'],
    'mv_tc_93d1': ['SHA256SUMS', 'type-v1/SHA256SUMS', 'topology-v1/SHA256SUMS'],
    'mp_tc_84b1': ['type-v1/SHA256SUMS'],
}.items():
    for suffix in paths:
        m = ROOT / '.astis/semantic-neutral-20261112' / root_name / suffix
        records = []
        for line in m.read_text().splitlines():
            digest, name = line.split('  ', 1)
            path = m.parent / name
            assert sha(path.read_bytes()) == digest, path
            records.append(rec(path))
        old_manifests.append({'manifest': rec(m), 'records': records, 'all_expected_hashes_match': True})
pre = DEST / 'upstream-before-sg'
assert sha((pre / 'freeze.json').read_bytes()) == 'a5399934b1de78e888033bbb8ba482d54362dd85cd4c64e31e294727c7092ffe'
pre_data = readj(pre / 'freeze.json')
for key in ['reading', 'reader_script']:
    r = pre_data[key]
    assert sha((ROOT / r['path']).read_bytes()) == r['sha256']
assert sha((DEST.parent / 'type-v1/freeze.json').read_bytes()) == '87c37fa423e8b8d8725a5d7253b97d313be94bb2c25652461d3363aca27d3335'

manifest_by_path = {r['path']: r for r in manifest['files']}
used = [r for r in public_records if Path(r['path']).name not in ['freeze-manifest.json', 'freeze-manifest.sha256']] + fragments
for r in used:
    name = str((ROOT / r['path']).relative_to(SG))
    mr = manifest_by_path[name]
    assert r['sha256'] == mr['sha256'] and r['bytes'] == mr['bytes']
unopened = [r for r in manifest['files'] if r['path'].startswith('inputs/')]
assert len(unopened) == 6

writej('atom-review.json', {'verdict': 'NO_GENUINE_COVERAGE_OR_ATTRIBUTION_BLOCKER', 'counts': {'atoms': 68, 'NODE': 31, 'EXCLUDED': 37}, 'all_atoms': atom_reviews, 'all_upstream_theorems': theorems, 'other_upstream_theorems_explicitly_excluded': 21, 'selected_upstream_54_83_missing_lines': sorted(set(range(54,84)) - selected_lines)})
writej('edge-review.json', {'nodes': 50, 'directed_edges': 68, 'no_dangling_edges': True, 'acyclic_including_OR_coverage_links': True, 'all_edges': edge_reviews, 'OR': {'id': hyper['id'], 'alternatives': ['INTERNAL.convex-integral-application', 'INTERNAL.direct-PSD-combine'], 'conclusion': 'FORMAL.shared-producer', 'status': 'BOTH_ALTERNATIVES_UNPROVED_ONE_SUFFICES', 'direct_subroute_AND': ['INTERNAL.direct-Hermitian-integral', 'INTERNAL.direct-quadratic-integral'], 'unselected_branch_not_added_as_AND': True}})
writej('port-review.json', {'genuine_blockers': [], 'open_internal_ports': 13, 'ports': port_reviews, 'no_proof_or_permission_grant': True})
writej('root-coverage.json', {'coverage_only_not_proof_reachability': True, 'OR_alternatives_both_expanded_for_review_not_both_required': True, 'roots': [{'root': x, 'review_closure_count': len(closures[x]), 'nodes': sorted(closures[x])} for x in roots], 'root_union_count': len(union), 'root_union': sorted(union), 'source_application_endpoint_correspondence': {'from': 'APPLICATION.R9-PSD-residual', 'to': endpoint, 'kind': 'APPLICATION_TO_SOURCE_ENDPOINT_NOT_ADDED_PROOF_EDGE', 'meaning': 'Residual integral positivity supports the concrete Ex115 expectation comparison; full original R9 graph remains separate.'}, 'global_source_or_definition_context': sorted(contexts), 'fully_accounted_nodes': 50, 'unaccounted_nodes': [], 'unchanged_R9_signature_is_interface_not_complete_source_closure': True})
writej('locator-checks.json', {'sources': origin_expected, 'locator_occurrences_checked': 239, 'distinct_origin_raw_spans': 58, 'persisted_source_fragment_copies_checked': 68, 'normalization': 'NONE; exact original UTF8 bytes', 'checks': locator_checks})
writej('input-manifest.json', {'bindings': bindings, 'public_SG_artifacts_opened_and_checked': public_records, 'public_source_fragment_copies_opened_and_checked': fragments, 'SG_inputs_metadata_only_filenames_incidentally_seen_CONTENT_NOT_OPENED': unopened, 'SG_private_type_or_builder_hash_references_not_independently_certified': {'type_audit_sha256': g['bindings']['type_audit_sha256'], 'type_manifest_sha256': g['bindings']['type_manifest_sha256']}, 'independent_sources': [rec(PAPER), rec(ML), rec(PACKET)], 'literal_print_source': {'kind': 'string in own exact packet', 'sha256': origin_expected['LITERAL_PRINT']}, 'source_first_before_SG_freeze': rec(pre / 'freeze.json'), 'own_prior_originals_preserved': old_manifests, 'nominal_pin_is_supplied_not_independently_Git_verified': True})

local = [p for p in DEST.rglob('*') if p.is_file() and p.name != 'SHA256SUMS' and p != DEST/'freeze.json']
local_records = [rec(p) for p in sorted(local)]
writej('freeze.json', {
    'kind': 'INDEPENDENT_SHARED_BACKGROUND_SOURCE_ATTRIBUTION_TOPOLOGY_CHALLENGE',
    'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'verdict': 'ACCEPT_BOUNDED_SOURCE_ATTRIBUTION_COVERAGE_AND_UNPROVED_TOPOLOGY_ONLY',
    'genuine_blockers': [],
    'open_internal_ports': 13,
    'counts_independently_checked': {'atoms': 68, 'NODE': 31, 'EXCLUDED': 37, 'nodes': 50, 'directed_edges': 68, 'OR': 1, 'locator_occurrences': 239, 'distinct_origin_spans': 58, 'source_fragments': 68, 'upstream_theorems': 22, 'upstream_other_theorems_excluded': 21},
    'bindings': bindings,
    'source_layers': {'PAPER': 'Actual p14 application; not printed arbitrary-f matrix theorem.', 'MATHLIB': 'Exact fixed upstream complete-real-normed closed-convex-set integral theorem/proof; no completed ASTIS application inferred.', 'ASTIS': 'Authored arbitrary-f real PSD matrix specialization; full geometry and applicability internal.'},
    'own_source_first_freeze': rec(pre/'freeze.json'),
    'own_prior_type_freeze': rec(DEST.parent/'type-v1/freeze.json'),
    'SG_public_inputs_unchanged': True,
    'old_own_originals_hash_guard_passed': True,
    'new_Gaussian_hf_hpos_or_geometry_binders': False,
    'empty_finite_index_retained': True,
    'AE_not_strengthened_to_pointwise': True,
    'both_OR_routes_required': False,
    'actual_R9_full_proof_or_norm_conclusion_claimed': False,
    'actual_Mathlib_application_or_compiled_call_verified': False,
    'new_implementation_or_API_search': False,
    'source_VERIFIED_or_proof_status_or_permission_grant': False,
    'normal_intake_or_proof_search_authorized_by_this_review': False,
    'local_records': local_records,
})
records = sorted([p for p in DEST.rglob('*') if p.is_file() and p.name != 'SHA256SUMS'])
(DEST/'SHA256SUMS').write_text(''.join(sha(p.read_bytes()) + '  ' + str(p.relative_to(DEST)) + '\n' for p in records))
print(json.dumps({'freeze': rec(DEST/'freeze.json'), 'report': rec(DEST/'report.md'), 'input_manifest': rec(DEST/'input-manifest.json'), 'exposure': rec(DEST/'exposure.json'), 'checksum_manifest': rec(DEST/'SHA256SUMS'), 'genuine_blockers': [], 'open_internal_ports': 13, 'checked': len(records)}, indent=2))
