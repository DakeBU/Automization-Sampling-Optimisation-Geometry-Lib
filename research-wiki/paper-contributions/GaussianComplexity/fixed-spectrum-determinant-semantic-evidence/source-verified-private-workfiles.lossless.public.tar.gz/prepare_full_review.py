from pathlib import Path
import json,hashlib,subprocess,sys
sys.path.insert(0,'tools');import astis_semantic_roundtrip as rt;import astis_publication as pub;import astis_advance as adv
sha=lambda b:hashlib.sha256(b).hexdigest()
b=Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-determinant-semantic-evidence');ap=Path('research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-determinant.json');a=json.loads(ap.read_bytes())
assert a['state']=='blind-reconstructed' and a['publication_binding_sha256']=='c70bb9b23e335acf768bb889f8229fcdf2a7af160e10fa89779d00dcba58374b'
pub.check_advance([a['lean']['declaration']],reviewed=False)
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert head=='15fbef72d04a1e9d1e647289a099a6ff8f829125'
assert adv.current_advances()['ASTIS-SA-20261108-GaussianComplexityFixedSpectrumDeterminant']['state']=='PROVED_LOCAL'
packet=rt.semantic_reviewer_packet(a);p=b/'full-anti-anchored-reviewer-packet.json';assert not p.exists();p.write_text(json.dumps(packet,ensure_ascii=False,indent=2)+'\n')
paths=[ap,Path(a['lean']['file']),Path('Tests/GaussianComplexityFixedSpectrumDeterminant.lean'),Path('AutoSamplingTheory/TechnicalLemmas/Measure/DisplacementJacobianEntropy.lean'),Path('AutoSamplingTheory/TechnicalLemmas/Measure/GaussianPrecisionDensity.lean'),Path('AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumAdmissibility.lean'),Path('website/content/declaration_lessons/huanjian-fixed-spectrum-determinant.json'),Path('website/content/publications/huanjian-fixed-spectrum-determinant.json'),Path('runs/substantive_advances.jsonl'),Path('runs/substantive_discoveries.jsonl')]
record={'checked_candidate_commit':head,'mathematical_candidate':'a0310046dc10c06ce9f61959094322fb9016be1e','full_packet_path':str(p),'full_packet_raw_sha256':sha(p.read_bytes()),'full_packet_canonical_sha256':packet['packet_sha256'],'publication_binding_sha256':a['publication_binding_sha256'],'exact_inputs':{str(q):sha(q.read_bytes()) for q in paths},'instruction':'Deliver only after independent phase2 selective comparison freeze. HEAD/audit/ledgers fixed through fullsource/module review. Existing DJE canonical lemma is ONE actual producer ASTIS parent; actual Test has THREE. Root creates no source verdict/VERIFIED.'}
(b/'full-review-input-pins.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
