"""Commit one compiled packet with exact bounded evidence and preserved foreign state."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys
import tarfile

sys.dont_write_bytecode = True
sys.path.insert(0, 'tools')
import astis_advance as advance

workspace = Path(__file__).resolve().parent.relative_to(Path.cwd())
paper = Path('research-wiki/paper-contributions/GaussianComplexity')
evidence = paper / 'radial-fourth-matrix-semantic-evidence'
cell_path = Path('research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-radial-fourth-matrix.json')
ledger = Path('runs/substantive_advances.jsonl')
discoveries = Path('runs/substantive_discoveries.jsonl')
sha = lambda raw: hashlib.sha256(raw).hexdigest()
dump = lambda value: (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode()


def git(*args):
    return subprocess.check_output(['git', *args])


def create(path, raw):
    with path.open('xb') as out:
        out.write(raw)


baseline = json.loads((workspace / 'preproof-baseline.private.json').read_bytes())
head = git('rev-parse', 'HEAD').decode().strip()
assert head == baseline['head'] == 'a7244d6ad6043e03c126be08d9d32e2ae19a9e41'
assert not git('diff', '--cached', '--name-only')
assert git('diff', 'HEAD', '--name-only').decode().splitlines() == [str(ledger)]
assert ledger.read_bytes() == git('show', f'{head}:{ledger}') + (evidence / 'normal-EXPLORING-append.exact.jsonl').read_bytes()
states = advance._replay_advances([json.loads(line) for line in ledger.read_bytes().splitlines()])
assert states.pop('ASTIS-SA-20261111-GaussianComplexityRadialFourthMatrix')['state'] == 'EXPLORING'
assert states == baseline['all_foreign_states']
assert discoveries.read_bytes() == git('show', f'{head}:{discoveries}')
discovery_states = advance._replay_discoveries([json.loads(line) for line in discoveries.read_bytes().splitlines()])
for path, digest in baseline['all_existing_frontier_hashes'].items():
    assert sha(Path(path).read_bytes()) == digest, path
controls = json.loads((workspace / 'intake-controls.private.json').read_bytes())
for path, digest in controls.items():
    assert sha(Path(path).read_bytes()) == digest, path

concept_root = Path('.astis/semantic-neutral-20261111/r4_tc_d390/conceptual-audit')
concept_manifest = concept_root / 'MANIFEST.json'
assert sha(concept_manifest.read_bytes()) == '28fa4c03545b350c85b0f25b822a0d988865bd72ee753a3bba5656cdd35f6f81'
concept_files = [concept_manifest]
for item in json.loads(concept_manifest.read_bytes())['artifacts']:
    path = concept_root / item['path']
    raw = path.read_bytes()
    assert len(raw) == item['bytes'] and sha(raw) == item['sha256']
    concept_files.append(path)
judgment_raw = (concept_root / 'JUDGMENT.json').read_bytes()
assert sha(judgment_raw) == '0fd937d6f4185a1946f68e769f2c422388b121e16203bdd72978aec6baefeb5a'
judgment = json.loads(judgment_raw)
assert judgment['judgment'] == 'NO_ADDITIONAL_CONCEPTUAL_CORRESPONDENCE_FOUND'
assert judgment['new_mirrors'] == [] and not judgment['ledger_mutated']
cell = json.loads(cell_path.read_bytes())
cell['conceptual_mirror_audit'] = {
    **judgment['conceptual_mirror_audit'],
    'evidence': str(evidence / 'conceptual-additional-mirror-audit.original.json'),
    'independent_reviewer': judgment['reviewer'],
}
cell['graph_contribution']['functor_view'] = 'no-new-edge-with-reason'
cell['graph_contribution']['visual_review'] = 'The existing validated weighted-Gaussian symmetry bridge is retained. Actual scalar fourth-moment reuse is a canonical compiled parent. Shared graph delivery remains pending.'
cell_path.write_bytes(dump(cell))
create(evidence / 'conceptual-additional-mirror-audit.original.json', judgment_raw)
create(evidence / 'conceptual-additional-mirror-manifest.original.json', concept_manifest.read_bytes())
seal_path = paper / 'radial-fourth-matrix-statement-seal.json'
assert sha(seal_path.read_bytes()) == 'cc628d801ed367e1e57e99d69449d36a90b2803f7371986b964b4864409f6dec'
seal = json.loads(seal_path.read_bytes())
P, T = [Path(seal[key]['planned_file']) for key in ('producer', 'actual_private_consumer')]
draft = json.loads((evidence / 'publication-draft-record.json').read_bytes())
assert sha(P.read_bytes()) == draft['producer_sha256'] == '346fc4b30dd5252f422c803eb7f77160cf7657dabe74c67fc8f23de1d5e674f6'
assert sha(T.read_bytes()) == draft['private_consumer_sha256'] == '9bb4d6223404f1d96a262d0d8c85a1c2edab31dae3cb6fc949a6d5abbbec2f24'
create(evidence / 'actual-local-mathematical-result.json', dump({
    'actual_compilation': draft['build'], 'actual_kernel': draft['kernel'],
    'literal_types_kernel_applied': True, 'raw_Expr_structural_equality': False,
    'owned_theorems': 4, 'handwritten_roots': 2, 'generated_reachable_internal': 2,
    'allowed_axioms_only': ['propext', 'Classical.choice', 'Quot.sound'],
    'canonical_actual_parent_edges': draft['actual_public_ASTIS_parents'],
    'formalizer_API_pristine': False, 'new_target_preseal_proof_attempts': 0,
    'normal_intake_receipt': '.astis/huanjian-resume-20261103/20261111T164203633248Z-radial-fourth-matrix-normal-preproof-intake.receipt.json',
    'actual_intake_readback_tool_chunk': 'cd60bb',
    'status': 'Compiled bounded mathematics; independent final source/native acceptance and normal proof submission remain pending.',
}))
create(evidence / 'local-attempt-diagnoses.json', dump({
    'sealed_statements_changed': False,
    'producer_failures': [
        'Attempt1 exposed explicit PiLp coordinate continuity, namespace and dependent-Pi API elaboration issues.',
        'Attempt2 isolated the integral_map named-argument distinction between integrand f and map phi. Corrected phi without changing the proposition.',
    ],
    'consumer_failures': [
        'Attempt1 exposed opaque Kronecker unfolding and a missing mulVec notation scope.',
        'Attempt2 isolated scalar extraction through the Kronecker map. Entrywise ring algebra closed the same square identity.',
    ],
    'PSD_API_probe': 'ClosedIciTopology for real matrices was unavailable through the tested generic instance. The consumer proves the real PSD cone closed and convex internally, then uses Convex.integral_mem.',
    'source_map_harness': 'The original generated script had a literal-newline syntax error before any map write. Original script, generated file and actual failure receipt are retained. Version2 produced the exact map.',
    'decoder_custody_harness': 'The original snapshot loop collided on equal basenames before changing audit/publication metadata. Version2 uses full relative paths and checks existing identical original decoder copies.',
    'publication_boundary': 'Draft v2 removes transient review-phase wording. Original v1 retained, with code, statement and anonymous packet unchanged.',
    'interpretation': 'These are corrected API and evidence-harness issues. No mathematical counterexample or extra source premise is asserted.',
}))

review_inputs = json.loads((workspace / 'reviewed-preproof-inputs.json').read_bytes())
originals = [Path(item['path']) for item in review_inputs['independent_originals']]
originals += concept_files
safe_names = [
    'actual-environment-before-seal.json', 'preseal-exposure.json', 'statement-seal-v1.json',
    'selective-type-definition-packet.json', 'actual-independent-raw-freezes-rehashed.json',
    'actual-seal-and-reservation-summary.json', 'normal-intake-attempted.once.json',
    'reviewed-preproof-inputs.json', 'latest-original-owner-after-row-moment-V.json',
    'StatementFormation.lean', 'DefinitionMeaning.lean', 'MatrixOrderAPIProbe.lean',
    'RadialFourthMomentKernelProbe.lean', 'producer-attempt1.raw.lean.txt', 'producer-attempt2.raw.lean.txt',
    'consumer-attempt1.raw.lean.txt', 'consumer-attempt2.raw.lean.txt',
]
originals += [workspace / name for name in safe_names]
originals += sorted(workspace.glob('*.py'))
originals += sorted(path for path in (workspace / 'publication-draft-v1-originals').rglob('*') if path.is_file())
runner = Path('.astis/huanjian-resume-20261103')
for receipt_path in sorted(runner.glob('*-radial-fourth-matrix-*.receipt.json')):
    receipt = json.loads(receipt_path.read_bytes())
    log = Path(receipt['log']).resolve().relative_to(Path.cwd().resolve())
    assert sha(log.read_bytes()) == receipt['log_sha256']
    originals += [receipt_path, log]
originals = sorted(set(originals))
for path in originals:
    assert path.is_file() and not path.is_symlink() and path.stat().st_size < 5_000_000, path
    assert 'baseline.private' not in path.name and 'intake-controls.private' not in path.name
archive_path = evidence / 'preproof-source-types-topology-local-build.original-files.tar.gz'
with tarfile.open(archive_path, 'x:gz') as archive:
    for path in originals:
        archive.add(path, arcname=str(path), recursive=False)
with tarfile.open(archive_path, 'r:gz') as archive:
    for path in originals:
        assert archive.extractfile(str(path)).read() == path.read_bytes(), path
create(evidence / 'preproof-source-types-topology-local-build.original-manifest.json', dump({
    'files': {str(path): {'bytes': path.stat().st_size, 'sha256': sha(path.read_bytes())} for path in originals},
    'scope': 'Bounded own source/type/topology/conceptual/decoder custody and actual local build originals. All full preservation/control snapshots remain local.',
}))
slug = 'huanjian-gaussian-radial-fourth-matrix.json'
files = [P, T, cell_path, seal_path, ledger,
         Path('website/content/declaration_lessons') / slug,
         Path('website/content/publications') / slug,
         Path('research-wiki/semantic-roundtrip/audits') / slug,
         *sorted(path for path in evidence.rglob('*') if path.is_file()), *concept_files]
assert len(files) == len(set(files))
subprocess.run(['git', 'add', '-f', '--', *map(str, files)], check=True)
assert set(git('diff', '--cached', '--name-only').decode().splitlines()) == set(map(str, files))
subprocess.run(['git', 'diff', '--cached', '--check'], check=True)
subprocess.run(['git', 'commit', '-m', 'Prove the Gaussian radial fourth matrix moment and actual squared-summand PSD bound'], check=True)
commit = git('rev-parse', 'HEAD').decode().strip()
for path in files:
    assert git('show', f'{commit}:{path}') == path.read_bytes(), path
assert not git('diff', 'HEAD', '--name-only')
record = {
    'mathematical_candidate': commit, 'parent': head,
    'producer_sha256': draft['producer_sha256'], 'private_consumer_sha256': draft['private_consumer_sha256'],
    'publication_binding_sha256': draft['publication_binding_sha256'],
    'source_lean_map_sha256': sha((evidence / 'source-lean-map.draft.json').read_bytes()),
    'archive_sha256': sha(archive_path.read_bytes()), 'original_archive_files': len(originals),
    'exact_carried_files': len(files), 'foreign_full_advance_states_preserved': len(states),
    'all_discovery_states_preserved': len(discovery_states),
    'older_frontier_regular_files_preserved': len(baseline['all_existing_frontier_hashes']),
    'foreign_controls_preserved': len(controls), 'formalizer_API_pristine': False,
    'state': 'EXPLORING; exact bounded mathematics compiled; independent final source/native review pending',
}
create(workspace / 'actual-immutable-math-candidate.json', dump(record))
print(json.dumps(record))
