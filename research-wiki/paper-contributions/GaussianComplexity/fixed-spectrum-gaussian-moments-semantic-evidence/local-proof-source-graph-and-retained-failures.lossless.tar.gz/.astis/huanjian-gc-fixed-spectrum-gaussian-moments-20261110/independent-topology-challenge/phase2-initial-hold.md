# Initial exact Gaussian-moments source-graph review — HOLD

**HOLD: one precise active-condition terminology defect. Exact seal meaning/binders remain ACCEPT.** No source theorem refutation, signature change, topology redesign or additional mathematical assumption is requested.

Exact reviewed phase2 artifacts: FREEZE `10c8d1e3034f41e007f3898aaedc29d1de44e5ec869b4e118cc2eceb21267945`; graph `54afc6149bc90dce57e27306383f4d74e49f48347ea6a5b352eafd89b9dc88c1`; coverage `9ff5d9c0d8d0966ba221bf3fbcf794a895f4062778e526da5ad25d568d266511`; closures `bd49b987084fc3be7176598da4520d712bb9bbde639128f094a5bec80e6b6612`; seal projection `37e7ea59b6426e388da585237102e84fbab228badb036544368a0442e088499b`. The unchanged seal is `eed0782fa32075cdf6313e802293764bd6b07ca991974b9e56c8d520a8e13354`.

## H-COVARIANCE-CONDITION-TERMINOLOGY

The graph's main nodes and global convention correctly state precision Λ and covariance Λ⁻¹. However the **active required condition** `C-inverse.required` says:

> Inverse covariance is diagonal with entries lambda_i^-1 and positive definite

Read literally, inverse covariance is Λ and has entries λᵢ, not λᵢ⁻¹. This conflicts with the otherwise correct sealed law and graph. It is an annotation/condition-labeling defect, not a newly discovered mathematical failure of the target source result.

Exact affected required-field pointers:

- `/conditional_requirements/C-inverse/required`
- `/edges/1/conditional_discharge/1/required` (E02)
- `/edges/2/conditional_discharge/0/required` (E03)
- `/edges/4/conditional_discharge/1/required` (E05)

Related active ambiguity should be normalized in the same minimal successor:

- `/conditional_requirements/C-L2/required`
- `/edges/3/conditional_discharge/1/required` (E04)
- `/edges/4/conditional_discharge/0/required` (E05)
- `/edges/7/conditional_discharge/1/required` (E08)
- `/edges/0/mechanism` (E01: “precision and inverse covariance”)

Minimal repair: preserve every frozen original, and append a typed clarification/resolved successor at these exact pointers saying **covariance Λ⁻¹, equivalently inverse precision**, with diagonal entries λᵢ⁻¹; inverse covariance is Λ. Retain every formula, signature, node/edge ID, conditional dependency, coverage disposition and open boundary. The historical quoted phase1 wording can remain explicitly historical. Do not silently rewrite the old freeze or change source/Lean claims.

## Completed mathematical/topology checks

The producer closure was independently recomputed from all prerequisites: 16 nodes and 11 edges, exactly matching the supplied closure. It contains actual-law identification, positive spectrum, diagonal inverse, Gaussian second-order/coordinate moments, pointwise norm/Q identities, integrability and finite expectation linearity. It contains no C7, alias, Haar/rotated law, algorithm/query or variance-proof dependency. The full Lemma 4.5/C8 conclusion is not used as a producer premise.

The actual private-consumer closure was independently recomputed: 33 nodes and 28 edges, exactly matching the supplied closure. It contains the NEW Gaussian producer AND C7 pointwise/convergence AND all-integer aliasing, with finite weighted-series summability, finite-grid/tsum exchange, zero n-mode/product-to-sum, normalized signed aliases and successor indexing. The new Gaussian integral has not been replaced by a deterministic sum definition. All-Int shifts, alias k=0/negative branches, 1≤n<d discharge and d/√κ factor remain correct.

The Gaussian integral/finite-sum exchange is explicit and separate from the scalar finite-grid/infinite-series exchange. Both Integrable outputs and supported-series Summable are derived obligations, not inputs. The actual covariance constructor/default-matrix behavior and Bochner default-zero hazards remain guarded by internal SPD/law/integrability obligations, not extra binders.

All 13 SOURCE_GAP nodes have incoming producer-obligation edges. All condition providers are reachable through their edge prerequisites or explicitly denote that target's own internal obligation. The latter is labelled `INTERNAL_DERIVATION_TO_BE_PROVED`, not silently assumed. No free moment/integrability/interchange premise was found. The two Gaussian background completion alternatives are typed as unselected OR choices, not flattened into simultaneous requirements. Existing C7/alias source routes are not compiler dependency certificates.

## Exhaustive source coverage and bounded context

All 278 unique coverage records have explicit disposition: 105 NODE, 173 EXCLUDED, with valid node references. The original 64 blocks, 124 math attachments and 10 links remain unchanged. Across the complete projected inventory, 75 source-text blocks, 164 math attachments and 23 links were independently compared with the original pinned HTML; there are no mismatches. All graph node anchors, edge use sites and conditional source anchors resolve in that source.

Necessary supplementary raw S2 norm/precision conventions and the delimited p8.1 marginal assertion were independently read. The actual source explicitly assigns covariance A⁻¹ to precision A, corroborating the requested terminology repair. The p8.1 Gaussian marginal/variance fact is kept separate from its independence/fourth-moment/variance assertions; no whole variance route enters the producer closure.

Closed C8 resummations, fourth moments, independence, variances, normalized bias, rotations, Krylov/adaptive laws, TV/oracle/cost and main bounds remain explicitly OPEN/excluded. The original covariance wording observation in phase1 does not alter its correct retained raw formula.

## Independence and preservation

Only the exact allowed graph, coverage, closure, seal-projection and freeze records were read; author verdict labels embedded in those JSON files are exposure and were not relied on. No private extractor script, cognition, rationale, review capsule or structural-verdict file was opened. No candidate Lean/proof, moment API, build, browser, ledger or shared write occurred.

An initial checker treated a synthetic heading locator as a real HTML ID while validating its link. That lookup was corrected to scope/tag/original-line resolution; this was a local checker issue and produced no source/graph discrepancy. Detailed successful comparison evidence is retained in `phase2-check-results.initial.json`.

All own earlier raw, seal and inventory freezes remain unchanged. This initial HOLD is immutable. Final exact graph admission awaits only the separately frozen minimal condition-terminology successor; all other checks above may be reused unchanged.
