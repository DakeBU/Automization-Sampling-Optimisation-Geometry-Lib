import AutoSamplingTheory.ExampleCases.ProximalBPS.ActualPrescribedPathDensity

namespace PBPSGibbsSurvivalWork98
open MeasureTheory
open scoped BigOperators

/-- Integrable adjacent differences telescope across an energy grid. The
    pointwise path may jump; only endpoint energies need to match. -/
theorem finite_energy_balance (n : ℕ) (a u : Fin (n+1) → ℝ)
    (f g : ℝ → ℝ)
    (hf : ∀ j : Fin n, IntervalIntegrable f volume (a j.castSucc) (a j.succ))
    (hg : ∀ j : Fin n, IntervalIntegrable g volume (a j.castSucc) (a j.succ))
    (hstep : ∀ j : Fin n,
      (∫ s in a j.castSucc..a j.succ, f s) -
        (∫ s in a j.castSucc..a j.succ, g s) = u j.succ - u j.castSucc) :
    IntervalIntegrable f volume (a 0) (a (Fin.last n)) ∧
    IntervalIntegrable g volume (a 0) (a (Fin.last n)) ∧
    u (Fin.last n) - u 0 =
      (∫ s in a 0..a (Fin.last n), f s) -
        (∫ s in a 0..a (Fin.last n), g s) := by
  induction n with
  | zero => simp
  | succ n ih =>
    have hh := ih (fun i => a i.castSucc) (fun i => u i.castSucc)
      (fun j => hf j.castSucc) (fun j => hg j.castSucc)
      (fun j => by simpa only [Fin.succ_castSucc] using hstep j.castSucc)
    have hfl := hf (Fin.last n)
    have hgl := hg (Fin.last n)
    have hs := hstep (Fin.last n)
    refine ⟨hh.1.trans hfl, hh.2.1.trans hgl, ?_⟩
    have hfi := intervalIntegral.integral_add_adjacent_intervals hh.1 hfl
    have hgi := intervalIntegral.integral_add_adjacent_intervals hh.2.1 hgl
    simp only [Fin.succ_last] at hs hfi hgi
    linarith [hh.2.2]

end PBPSGibbsSurvivalWork98
#print axioms PBPSGibbsSurvivalWork98.finite_energy_balance
