# Independent typed judgment, frozen before proposed graph exposure

I read only the newly authorized selective type/definition packet outside my own artifacts. Its original bytes are copied without normalization as selective-type-definition-packet.original.json, SHA256 44cecb47245a0d1ab06d634f8b1dcd408c8368437e37cea1f0bde46fc2669ae3 (12093 bytes). Both exact signature strings and all 11 definition literal strings independently hash to the packet's stated hashes. I did not read the underlying canonical source files whose names/hashes the packet records, any implementation proof, another graph, ledger, old verdict, Git, network, global state or API inventory.

This judgment follows my immutable phase-1 mathematical reconstruction SHA256 50208c71a2b13245e70ea68b5fdb2a65a73b039eef4b034caa14438460a48d83, manifest 8987e0b49f7f4357b80e9a5c736c6708d3959f56072473208587629e8ed7e3ec. Phase 1 was not changed or reopened. The packet reports a seal digest, but I have not read that seal or treated its existence as a mathematical verdict. No target proof or compiler/API check is part of this source-only review.

## Independent mathematical verdict

The two exact interfaces are mathematically source-consistent within the stated bounded role: the producer is a valid canonical finite-dimensional generalization of the unnamed standard Gaussian radial moment in C.2 p10; the private consumer is the exact source marginal row-tail bound at the literal L. Neither interface contains an EXCESS proof-ingredient premise. No source repair or signature change is required by this reading. This is an interface/source judgment, not proof certification, compilation evidence, VERIFIED, admission of the full Fact C.6, or approval of an unseen proposed graph.

Producer signature SHA256: 7b27efe79e0ebbc31760b1e4bb17e8591bbca4335e35fd3fdbe4c642ee50c6b3.
Private consumer signature SHA256: 3dc0457798c1b594a16ad8f7ab8e863d8cd469c9fe0b940550e05a23cdd2d94a.

## Producer: actual law, norm, dimension and binders

The producer quantifies over an arbitrary universe-polymorphic carrier E with a real inner-product-space structure, finite dimension and its Borel measurable structure. Its conclusion is
 Integrable (z -> exp(||z||^2/3)) (stdGaussian E)
 AND integral exp(||z||^2/3) d(stdGaussian E) = 3^((real finrank_R E)/2).

All producer binders are TYPING/carrier information:
* E : Type* chooses the carrier.
* NormedAddCommGroup E and InnerProductSpace R E provide the compatible Euclidean/Hilbert norm and linear structure.
* FiniteDimensional R E fixes a genuine finite-dimensional setting, so finrank is the finite natural dimension, not Cardinal.toNat applied to an uncontrolled infinite dimension.
* MeasurableSpace E and BorelSpace E give precisely the Borel sigma algebra compatible with that norm topology.

These binders are not hidden exponential moment, integrability, probability, tail, normalization, domination, truncation or concentration estimates. Arbitrary finite-dimensional real inner-product E is broader than the source's R^(q+1); it is legitimate canonical library generality, not a claim that the source explicitly quantified over arbitrary E.

The literal stdGaussian definition is an actual pushforward of the finite product of gaussianReal 0 1 coordinate measures through the canonical orthonormal basis map. It is not an arbitrary measure accompanied by a caller's law certificate, nor a density defined up to an unspecified normalization factor. With the canonical standard gaussianReal 0 1 meaning supplied by the packet, it is the normalized, centered, identity-covariance Gaussian. The basis map is an orthonormal identification; the norm squared is the sum of coordinate squares. Thus the direct product Gaussian integral in my phase-1 freeze applies. The mathematical review accepts these canonical meanings from the provided selective context; it does not falsely claim independent readback of unprovided gaussianReal, WithLp norm-instance, complex-power, or wholefile implementations.

The exponent explicitly casts Module.finrank R E to R before dividing by 2. The base is the positive real 3, so the real power agrees with exp((real dimension/2)log3). There is no natural-number half-dimension truncation and no interpretation as 3^(dimension)/2. In dimension 1 the right side is sqrt3; in dimension 2 it is 3.

Dimension 0 is a valid producer extension. The finite coordinate product over Fin 0 is the mass-one measure on the empty coordinate tuple, its basis sum is zero, and finite-dimensional E of finrank 0 is the zero space. Hence stdGaussian E is concentrated at zero; exp(||0||^2/3)=1 is integrable with integral 1, and 3^(0/2)=1. The source row dimension r=q+1 never reaches 0; this extension must be labeled generic-library coverage rather than a source endpoint. No Nontrivial E, positive-dimension or q restriction should be inserted merely to avoid the empty case.

The producer returns Integrable as a conclusion. The supplied Integrable definition expands to AE strong measurability and finite integral of the norm. This is the correct internal discharge of the omitted source ingredient. The real Bochner integral definition has a default-zero branch for nonintegrable functions, but the conjunction demands the actual integrability fact independently. The moment cannot be satisfied by choosing that default branch. The integrability conclusion is source-implicit analytic well-definedness, not an additional public source hypothesis.

## Consumer: exact source marginal tail

The consumer has natural d,q and hq : 2*q+1<d. Natural q matches source integer q>=0. The hq condition is the source standing range inherited from Lemma 4.4 / C.2. It is retained exactly as sealed; I am not proposing to remove it because a more general scalar statement would be possible.

Internally hq implies d>=2, r=q+1>=1 and 2r<=d. In particular d is nonzero, 1000*(real d)>0, log(1000*(real d))>=0, L>=0, and the reciprocal on the right is positive and finite. These are discharged consequences, not extra binders. The ENNReal.ofReal conversion therefore embeds the intended positive real probability bound; it does not make a negative reciprocal vanish by clipping.

The local E is EuclideanSpace R (Fin(q+1)), whose supplied PiLp/WithLp specialization gives the L2 Euclidean norm, not the sup norm on raw functions. Its finite real dimension is q+1. The local measure is the actual stdGaussian E. Consequently ||z||^2 has precisely the source law R_i=||gamma_i||^2 for one gamma_i~N(0,I_r). There is no B-row scaling d^(-1/2), no t_i factor, no r^2-dimensional surrogate, and no target N(0,Lambda^-1) law.

The local threshold is literally
 L = 2*(real(q+1)) + 3*log(1000*(real d)).
The set {z : L<||z||^2} is exactly the source bad event R_i>L. The threshold equality belongs to the complementary good event R_i<=L. This is not a >= bad-event substitution or a norm rather than squared-norm event. Continuity of squared norm makes this strict superlevel set Borel; no measurability premise is added.

The source computation supplying the consumer is the following obligation chain, not an extra signature assumption:
1. Specialize the producer to this E and internally identify finrank_R E=q+1, obtaining both exponential integrability and the exact real exponent.
2. Apply exponential Markov with positive threshold exp(L/3), respecting strict-tail containment.
3. Simplify 3^(r/2)*exp(-L/3) to exp(r*((log3)/2-2/3))/(1000*d).
4. Use r>=0 and (log3)/2<2/3 to bound the numerator by 1, obtaining the stated ENNReal probability bound.

Equivalently, this is the source Ex104 at real x=log(1000*d)>=0. The Markov and logarithmic/exponential algebra remain genuine proof obligations. Their mathematical availability does not certify that a future implementation has discharged them.

## Coverage sufficiency and residual obligations

The producer exactly supplies the unnamed moment assertion A3.SS2.p10.m3 together with its missing analytic well-definedness. The consumer supplies the single-row specialization at L used between Ex104 and Ex105. It is sufficient for that direct marginal row-tail use.

The pair does not by itself assert or formalize the general Ex104 tail for every real x>=0, the all-d-row event probability 0.999, the shifted tail for every s>=0, or the tail-integral bias bound. They are visible downstream source obligations, even though their elementary mathematics is clear. To transfer the consumer to the original family, one must identify each gamma_i's marginal with stdGaussian on this Euclidean space. Then a finite union bound, without any independence requirement, gives the good event with probability 0.999. To obtain the bias bound one must additionally derive the shifted tail and perform the nonnegative tail integral. None of these may be counted as already covered solely from the two signatures.

The source rows really are independent by the original starter/coordinate construction, but the exact marginal consumer neither assumes nor concludes that family-level fact. It therefore cannot stand in for the actual row construction or a joint law theorem. For the union-bound consumer, joint independence is unnecessary; a matching marginal law for every row and finite indexing suffice.

Fact C.5, matrix Bernstein, full Fact C.6, full Lemma 4.4, the Krylov representation proof, Gaussian fourth moments and the Section 4.3 separating-test conclusion remain outside the selected pair. They do not become incoming parents of the Gaussian moment because they are nearby in the source or named consumers. The all-row event's later p17 use must remain a downstream edge.

## Exposure and freeze boundary

After this typed judgment was written, no other author's proposed graph had been exposed. The next permitted step is a comparison against that graph with this judgment held fixed. Any new conclusion caused by newly exposed graph records must be identified as that later comparison, not retroactively inserted into this independent reading.

