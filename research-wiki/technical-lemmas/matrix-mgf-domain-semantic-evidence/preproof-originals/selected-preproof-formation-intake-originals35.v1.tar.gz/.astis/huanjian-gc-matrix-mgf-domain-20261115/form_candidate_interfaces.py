"""R17 statement formation only, before seal/admission/target proof search."""
from pathlib import Path
import json,hashlib
r=Path.cwd();w=r/'.astis/huanjian-gc-matrix-mgf-domain-20261115'
old=r/'.astis/huanjian-gc-trace-mgf-domain-20261115'
P='''∀ {ι : Type u} {Ω : Type v} [Fintype ι] [DecidableEq ι] [MeasurableSpace Ω]
  {μ : Measure Ω} [IsProbabilityMeasure μ],
  ∀ (f : Ω → Matrix ι ι ℝ), Integrable f μ →
    (∀ᵐ ω ∂μ, (f ω).PosDef) → (∫ ω, f ω ∂μ).PosDef
'''
oldT=(old/'T.candidate.v2.txt').read_text()
assert hashlib.sha256(oldT.encode()).hexdigest()=='9013c0f1a28e9f9a0b2175208ea91abaded7fa3a760172f7b8ead404aebbefe1'
cut='  ∀ s : ℝ, ∀ useCos minus : Bool,\n';assert oldT.count(cut)==1
T=oldT.split(cut)[0]+cut+'''    let G : Ω → M := fun ω => NormedSpace.exp (s • S useCos minus ω)
    let MX : M := ∫ ω, G ω ∂μ
    let B : ℝ := r ^ 2 * Real.exp (|s| * ((d : ℝ) * Rstar))
    Integrable G μ ∧ MX.PosDef ∧
      Matrix.trace MX = (∫ ω, Matrix.trace (G ω) ∂μ) ∧
      0 < Matrix.trace MX ∧ Matrix.trace MX ≤ B
'''
for n,t in [('P.candidate.v1.txt',P),('T.candidate.v1.txt',T)]:
    q=w/n;assert not q.exists();q.write_text(t)
header='''import AutoSamplingTheory.TechnicalLemmas.Probability.RealMatrixPositiveIntegral
import AutoSamplingTheory.TechnicalLemmas.Analysis.MatrixTraceExponentialBounds
import Mathlib.MeasureTheory.Integral.Bochner.ContinuousLinearMap

open MeasureTheory ProbabilityTheory
open scoped BigOperators Matrix.Norms.L2Operator MatrixOrder ENNReal
noncomputable section
universe u v
namespace MatrixMgfDomainInterfaceFormation
'''
probe=header+'\ndef P : Prop :=\n'+P+'\ndef T : Prop :=\n'+T+'''\n#check P
#check T
#print P
#print T
end MatrixMgfDomainInterfaceFormation
'''
q=w/'InterfaceFormation.v1.lean';assert not q.exists();q.write_text(probe)
out={'phase':'CANDIDATE_STATEMENTS_ONLY_NOT_SEALED_OR_PROVED',
 'base_source_commit':'960c7dbe2215ba2f76d2346e2e86883ee7a43d95',
 'last_actual_public_commit':'eaca3074c0599067e0d6c6e6d9ab13a42030e780',
 'source_scope':'Author-derived canonical real probability integral of AE positive-definite integrable matrices; private material consumer for full matrix-valued exponential means of the original Gaussian four signed sums. Tropp positivity/mean-log-domain caveat and Gaussian C2 literal experiment are provenance, not a standalone printed generic integral theorem.',
 'P_kind':'canonical-library-node proposed; probability/integrability/AE-PD are explicit generic data assumptions, not added premises of the private Gaussian source target',
 'P_planned_file':'AutoSamplingTheory/TechnicalLemmas/Probability/RealMatrixPositiveDefIntegral.lean',
 'P_planned_name':'AutoSamplingTheory.TechnicalLemmas.Probability.RealMatrixPositiveDefIntegral.integral_posDef',
 'T_planned_file':'Tests/GaussianComplexityMatrixMgfDomain.lean',
 'T_planned_name':'AutoSamplingTheory.Tests.GaussianComplexityMatrixMgfDomain.actual_source_four_matrix_mgfs_integrable_posDef_and_trace_bounded',
 'P_signature_sha256':hashlib.sha256(P.encode()).hexdigest(),'T_signature_sha256':hashlib.sha256(T.encode()).hexdigest(),
 'private_T_definition_continuity':'All original lets through Rstar copied byte-for-byte from the sealed R16 literal source signature. Only conclusion data now names actual matrix exponential G and its true full-law matrix mean MX; no extra source input.',
 'bounded_reuse_observations':[
 'Existing actual canonical RealMatrixPositiveIntegral.integral_posSemidef retained unchanged; potential producer, not a new duplicate.',
 'Bounded rg over ASTIS .lean and selected pinned Mathlib Integral/CStar/Matrix paths found no exact integral_posDef/strict-positive-mean lemma among inspected hits; no global absence claim.',
 'Pinned Mathlib norm_cfc_le(_iff) and scalar integral_pos_iff_support_of_nonneg_ae APIs exist; inspected statement names only, no target theorem proof.',
 'R16 canonical all-real trace envelope remains one actual compiled node; realistic material consumer is the exact trace bound of the new matrix mean, once integrability/commutation are derived internally.'],
 'not_claimed':'No seal, independent SG/topology admission, target proof, normal intake/PL/V, matrix log theorem, Lieb/master-tail/Bernstein/C6/main lower bound, oracle/precision/cost adapter, main/site/purification or Goal completion.',
 'preservation':'No old R16/PBPS/SPHMC/other chat source, ledger/frontier/Registry/shared graph/site/ref/Goal modified. No detached/background ASTIS.'}
q=w/'pre-intake.candidate-v1.json';assert not q.exists();q.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:out[k] for k in ['phase','P_signature_sha256','T_signature_sha256','not_claimed']}))
