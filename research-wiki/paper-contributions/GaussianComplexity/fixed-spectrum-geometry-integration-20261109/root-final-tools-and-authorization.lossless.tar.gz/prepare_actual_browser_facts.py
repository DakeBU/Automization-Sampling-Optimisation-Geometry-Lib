from pathlib import Path
import hashlib,json,subprocess
P=Path('.astis/huanjian-gc-fixed-spectrum-geometry-integration-20261109')
B=Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-geometry-integration-20261109')
E=Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-geometry-semantic-evidence')
CORE='b3581af0fc7e517e6cf5b883f4af064ddaa72aa2'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
ref=lambda p:{'path':str(p),'sha256':sha(p.read_bytes())}
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==CORE
assert not subprocess.check_output(['git','diff','HEAD','--name-only']).strip()
checks={}
for role,label in {'canonical_lean':'official-lean','publication':'publication','contributor':'contributor',
    'semantic':'semantic','frontier':'frontier','site_build':'site-build','site_check':'site-check','graph_check':'graph-check'}.items():
    paths=list(Path('.astis/huanjian-resume-20261103').glob('*-geometry-core-'+label+'.receipt.json'))
    assert len(paths)==1,role
    q=paths[0];r=json.loads(q.read_bytes());assert r['exit_code']==0 and r['head_before']==r['head_after']==CORE
    assert sha(Path(r['log']).read_bytes())==r['log_sha256'];checks[role]=ref(q)
facts={'facts_kind':'fixed-spectrum-geometry-actual-prebrowser-facts-v1','supplied_by':'/root',
    'candidate_commit':'ab8b47caed9f781191f8408154cd355c7e7c104c',
    'publication_binding_sha256':'69c4f115a417c0aea6a8ebc9384cfc66ff07e6fae92de806831b79075a4760fa',
    'proposal_report_sha256':'6f9045472dc9f11da494942d065b093efab12c2cf385f6d83a379ad771a5e904',
    'browser_checker_sha256':'e579e632b218e028310130e068230db3be8d0cca4d0e01714ea0f4b49c46268c',
    'browser_common_sha256':'2be36d2794fa949989bbeee2db10606c68ff966ef1de27c2337b5b6a4c90ace0',
    'source_verifier_to_preserve':'/root/source_reader_9a6d2f',
    'integration_owner':'huanjian_gc_20261109_fixed_spectrum_geometry_integration',
    'accepted_immutable_core':CORE,'source_V_first_carrying_commit':'62813df927fd3c156dd57099cc11613074d91bc0',
    'candidate_source_digest':'297ae396356a67e6549d51efc2d0353f04c7c90023cdbdc83ba173d1fe59034c',
    'source_digest':'6905b946089555464e4eedadfad3644fb4df3ee5d49ffc8445c16bb7fd997108',
    'planned_original_PNGs':44,'planned_native_geometry_rows':12,'planned_old_DensityAffinity_DOM_regressions':2,
    'actual_checks_before_browser':checks,
    'source_V_append':ref(E/'actual-source-V-append.exact.json'),
    'STAB_append':ref(B/'sole-STAB-append.exact.jsonl'),
    'source_V_actual_execution_manifest':ref(E/'original-source-verifier/normal-V-preparation/execution/execution-manifest.json'),
    'accepted_source_audit':ref(Path('research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-geometry.json')),
    'source_review_run':ref(E/'fresh-source-reader-9a6d2f/phase3/reviewer-run.json'),
    'own_frontier_current':ref(Path('research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-geometry.json')),
    'own_frontier_projection_review':ref(B/'actual-own-frontier-projection.json'),
    'actual_gate':ref(Path('.astis/site-lean-gate.json')),'site_metadata':ref(Path('_site/data/build-metadata.json')),
    'sole_STAB_application_receipt':ref(B/'exact-shared-application-receipt.json'),
    'source_V_own_frontier_projection_review':ref(E/'source-V-own-frontier-projection-independent-review.json')}
out=P/'actual-prebrowser-facts-v1.json';assert not out.exists()
out.write_text(json.dumps(facts,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'actual_facts':str(out),'sha256':sha(out.read_bytes()),'actual8same_core_receipts':True,
    'execute_browser_authorized':False,'new_source_verdict':False,'core':CORE}))
