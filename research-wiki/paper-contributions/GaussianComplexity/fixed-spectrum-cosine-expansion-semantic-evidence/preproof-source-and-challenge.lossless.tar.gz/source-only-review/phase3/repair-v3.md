# Phase 3: κ-only standing port

This version makes only the topology repair requested by the independent `H-KAPPA-ONLY-PORT`. It does not change the source, seal, mathematical target, theorem assumptions, phase1 or phase2. The HOLD identified a graph representation mismatch, not a mathematical counterexample or a new source binder.

I independently re-read the pinned raw paragraph and its exact math element `#S4.SS1.p1.m4`. Its alttext and TeX annotation are `\kappa\geq 2`; it is distinct from neighboring `#S4.SS1.p1.m3`, which is `d\geq 2`. The κ-only element occupies bytes `[205729,205970)` of the pinned HTML and has SHA-256 `92cc26f8268fb2fc2c9b9905e8671314491418e91e0ef42b02b511ae93577503`.

`source-graph-v3.json` preserves the combined `source.standing` node as context and adds `source.standing.kappa_only`, directly anchored at that κ-only math element. Its selector metadata explicitly excludes dimension and marks the context relationship as provenance rather than an AND dependency. Only the `source.standing` parent entries of `C7-e1` and `C7-e3` are replaced by `source.standing.kappa_only`.

The exact graph diff is preserved. The coverage delta reassigns the exact `m4` math/source-id record to the κ-only node; the surrounding paragraph remains combined standing context. Every other phase2 coverage record, region, source node and edge remains inherited unchanged. The version has 25 nodes and the same 13 AND edges.

The seal stays at SHA-256 `748538057656b235eed54272a87e66f4bf87bdbeb79a9831795b53e72ae74a36`. The already challenged rho definition, Gaussian trace separation, weighted finite-sum bridge, all-natural private intermediate, and other packet boundaries are not reopened or expanded. No proof, API search, implementation inspection, shared write, source V or actual-use certification occurred. This successor awaits the independent challenger's decision.
