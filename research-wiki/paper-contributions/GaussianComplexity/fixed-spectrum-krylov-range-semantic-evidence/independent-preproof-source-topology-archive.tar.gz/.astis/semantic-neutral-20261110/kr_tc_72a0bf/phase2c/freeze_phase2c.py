from pathlib import Path
import hashlib,json,stat,os,datetime
ROOT=Path('/Users/zhouhuanjian/ASTIS-GC/.astis/semantic-neutral-20261110/kr_tc_72a0bf');P=ROOT/'phase2c';sha=lambda b:hashlib.sha256(b).hexdigest()
def previous():
 out=[]
 for s in ['phase1','phase2a','phase2b']:
  m=json.loads((ROOT/f'{s}.manifest.json').read_bytes())
  assert all(sha((ROOT/s/x['path']).read_bytes())==x['sha256'] and stat.S_IMODE((ROOT/s/x['path']).stat().st_mode)==0o444 for x in m['files'])
  assert stat.S_IMODE((ROOT/s).stat().st_mode)==0o555
  out.append({'stage':s,'manifest_sha256':sha((ROOT/f'{s}.manifest.json').read_bytes()),'unchanged':True})
 return out
a=previous();fs=sorted(p for p in P.rglob('*') if p.is_file());assert not any(p.is_symlink() for p in P.rglob('*'))
m={'stage':'phase2c-accepted-exact-mathematical-revision-before-root-process-exposure','files':[{'path':str(p.relative_to(P)),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in fs]}
mp=ROOT/'phase2c.manifest.json';mp.write_text(json.dumps(m,indent=2)+'\n')
for p in fs:os.chmod(p,0o444)
ds=[P]+[p for p in P.rglob('*') if p.is_dir()]
for p in sorted(ds,key=lambda p:len(p.parts),reverse=True):os.chmod(p,0o555)
os.chmod(mp,0o444)
assert all(stat.S_IMODE(p.stat().st_mode)==0o444 for p in fs) and all(stat.S_IMODE(p.stat().st_mode)==0o555 for p in ds)
assert all(sha((P/x['path']).read_bytes())==x['sha256'] for x in m['files']);assert previous()==a
receipt={'stage':'phase2c','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'mathematical_decision':'ACCEPT exact v2 overlay; R1/R2 closed; no target proof/compile/global sourceV','manifest_sha256':sha(mp.read_bytes()),'files':len(fs),'all_files_0444':True,'all_directories_0555':True,'actual_hash_mode_recheck':True,'earlier_freezes':a,'root_process_request_read_before_math_freeze':False}
rp=ROOT/'phase2c.freeze.receipt.json';rp.write_text(json.dumps(receipt,indent=2)+'\n');os.chmod(rp,0o444);print(json.dumps(receipt,indent=2))
