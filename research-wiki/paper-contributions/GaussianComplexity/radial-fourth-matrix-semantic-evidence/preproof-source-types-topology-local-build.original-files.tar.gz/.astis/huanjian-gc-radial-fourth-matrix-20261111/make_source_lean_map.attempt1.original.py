"""Bind source and Lean byte spans using the existing exact locator implementation."""
from pathlib import Path

previous = Path('.astis/huanjian-gc-truncated-radial-covariance-20261111/make_source_lean_map.py').read_text()
locators = previous.split('mappings = [', 1)[0]
locators = locators.replace('truncated-row-second-moment-semantic-evidence', 'radial-fourth-matrix-semantic-evidence')
locators = locators.replace('FixedSpectrumTruncatedRowMoment', 'FixedSpectrumRadialFourthMoment')
tail = r'''
mappings = [
    mapping(['S4.Thmtheorem4.p1.m2', 'S4.Thmtheorem4.p1.m3'],
            [(P, 24, 24), (T, 15, 15)], 'The standing query range, including q=0 and positive row dimension r=q+1.'),
    mapping(['A3.SS2.p1.m1', 'A3.SS2.p1.m5'],
            [(P, 25, 28), (P, 105, 121), (T, 16, 19)],
            'The canonical one-row Gaussian law and Euclidean radius. The actual product-coordinate pushforward is internal; original-family row transport remains outside this theorem.'),
    mapping(['A3.Ex113.m1'], [(P, 23, 34), (P, 35, 78)],
            'Complete exact producer statement and quartic/entry/matrix integrability, before use of its Bochner expectation.'),
    mapping(['A3.SS2.p14.2', 'A3.Ex113.m1'], [(P, 80, 103)],
            'Actual Gaussian reflection invariance cancels each distinct-coordinate weighted entry.'),
    mapping(['A3.SS2.p14.m1', 'A3.Ex113.m1'], [(P, 105, 188)],
            'Scalar fourth moment three, second moment one, independent mixed moment one and finite sums give r+2. All entries and scalar transport are integrable.'),
    mapping(['S4.E11.m1', 'A3.SS2.p5.m2', 'A3.Ex85.m1'], [(T, 21, 24)],
            'Exact midpoint row index and frequencies0..q. Source row j=i.val+1, constant coordinate one and higher sqrt(2) normalization.'),
    mapping(['A3.SS2.p10.m1', 'A3.SS2.p10.m2', 'A3.Ex107.m1'], [(T, 19, 29), (T, 50, 55)],
            'Literal closed cutoff and actual Gaussian-first Kronecker summand with inverse-d scaling.'),
    mapping(['A3.SS2.p14.m2', 'A3.SS2.p14.m3', 'A3.Ex114.m1'], [(T, 68, 101)],
            'Both rank-one square identities, ordinary Kronecker matrix multiplication and indicator idempotence give the exact actual squared summand and its integrability.'),
    mapping(['A3.SS2.p14.3', 'A3.Ex115.m2'], [(T, 14, 35), (T, 103, 141)],
            'The source-supported individual PSD consequence preceding the displayed sum. The aggregate display is provenance for the termwise step and is not a claimed aggregate theorem.'),
    mapping(['A3.Ex113.m1', 'A3.SS2.p14.3', 'A3.Ex115.m2'], [(T, 142, 158)],
            'The consumer materially uses producer integrability and exact mean through the same fixed continuous linear tensor map, then evaluates the integrated PSD residual.'),
]
draft = json.loads((evidence / 'publication-draft-record.json').read_bytes())
record = {
    'kind': 'Root-authored exact source/Lean map for independent review',
    'source_sha256': sha(raw), 'actual_ASTIS_proof_parents': draft['actual_public_ASTIS_parents'],
    'mappings': mappings,
    'proof_background': [
        {'declaration': 'ProbabilityTheory.stdGaussian_map',
         'source': code_span(Path('.lake/packages/mathlib/Mathlib/Probability/Distributions/Gaussian/Multivariate.lean'), 128, 135),
         'consumer': code_span(P, 80, 103), 'meaning': 'Canonical-law coordinate reflection invariance.'},
        {'declaration': 'ProbabilityTheory.map_pi_eq_stdGaussian',
         'source': code_span(Path('.lake/packages/mathlib/Mathlib/Probability/Distributions/Gaussian/Multivariate.lean'), 137, 143),
         'consumer': code_span(P, 105, 121), 'meaning': 'Actual canonical product-coordinate law bridge.'},
        {'declaration': 'ProbabilityTheory.IsGaussian.memLp_id',
         'source': code_span(Path('.lake/packages/mathlib/Mathlib/Probability/Distributions/Gaussian/Fernique.lean'), 186, 203),
         'consumer': code_span(P, 45, 61), 'meaning': 'Actual finite Gaussian fourth-norm moment supplies matrix-entry domination.'},
        {'declaration': 'AutoSamplingTheory.TechnicalLemmas.StochasticProcesses.GaussianFourthMoment.integral_pow_four_gaussianReal_zero',
         'source': code_span(Path('AutoSamplingTheory/TechnicalLemmas/StochasticProcesses/GaussianFourthMoment.lean'), 23, 89),
         'consumer': code_span(P, 132, 138), 'meaning': 'Reuse the identical compiled scalar fourth-moment node already used by Brownian quadratic variation.'},
        {'declaration': 'Convex.integral_mem',
         'source': code_span(Path('.lake/packages/mathlib/Mathlib/Analysis/Convex/Integral.lean'), 57, 65),
         'consumer': code_span(T, 123, 141), 'meaning': 'The internally proved closed convex PSD cone contains the Bochner residual integral.'},
    ],
    'mathlib_pin': 'db584cd6d46c92f209a44c0f1c829460d327499d',
    'scope': 'Canonical Ex113 and individual Ex114/p14 PSD consequence. Original-family transport, sums, centered variance, concentration and full-paper reader integration remain open.',
}
path = evidence / 'source-lean-map.draft.json'
with path.open('x') as out:
    json.dump(record, out, ensure_ascii=False, indent=2)
    out.write('
')
print(json.dumps({'path': str(path), 'sha256': sha(path.read_bytes()),
                  'source_locator_entries': sum(len(item['source']) for item in mappings),
                  'Lean_spans': sum(len(item['lean']) for item in mappings)}))
'''
tail = tail.replace("out.write('\n+')", "out.write('\\n')")
generated = Path(__file__).resolve().parent / 'make_source_lean_map.generated.py'
with generated.open('x') as out:
    out.write(locators + tail)
exec(compile(locators + tail, str(generated), 'exec'))
