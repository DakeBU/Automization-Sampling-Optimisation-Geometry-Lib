from pathlib import Path
from html.parser import HTMLParser
import hashlib
import json
from bs4 import BeautifulSoup

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[2]
SOURCE = ROOT / '.astis/huanjian-resume-20261103/2610.20492v1.html'
EXPECTED = '6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
raw = SOURCE.read_bytes()
assert hashlib.sha256(raw).hexdigest() == EXPECTED
text = raw.decode('utf-8')
lines = [0]
for i, c in enumerate(text):
    if c == '\n':
        lines.append(i + 1)

class SpanParser(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=False)
        self.nodes = []
        self.stack = []
    def pos(self):
        l, c = self.getpos()
        return lines[l-1] + c
    def handle_starttag(self, tag, attrs):
        start = self.pos()
        node = dict(tag=tag, attrs=dict(attrs), start_char=start,
                    start_tag_end_char=start+len(self.get_starttag_text()),
                    parent=self.stack[-1] if self.stack else None)
        i = len(self.nodes)
        self.nodes.append(node)
        if tag in {'area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr'}:
            node['end_char'] = node['start_tag_end_char']
        else:
            self.stack.append(i)
    def handle_startendtag(self, tag, attrs):
        self.handle_starttag(tag, attrs)
        i = len(self.nodes)-1
        if self.stack and self.stack[-1] == i:
            self.stack.pop()
        self.nodes[i]['end_char'] = self.nodes[i]['start_tag_end_char']
    def handle_endtag(self, tag):
        for j in range(len(self.stack)-1, -1, -1):
            if self.nodes[self.stack[j]]['tag'] == tag:
                end = text.find('>', self.pos())+1
                for i in self.stack[j:]:
                    self.nodes[i]['end_char'] = end
                del self.stack[j:]
                break

p = SpanParser()
p.feed(text)
assert not p.stack

def digest(b): return hashlib.sha256(b).hexdigest()
def jsonwrite(name, data):
    (BASE/name).write_text(json.dumps(data, ensure_ascii=False, indent=2)+'\n')
def readable(node):
    soup = BeautifulSoup(node, 'html.parser')
    for m in soup.find_all('math'):
        m.replace_with(' ⟦'+(m.get('alttext') or m.get_text(' ', strip=True))+'⟧ ')
    return soup.get_text(' ', strip=True)

sections = []
all_units = []
for anchor, filename in [('S2','section2'), ('S4','section4'), ('A3.SS3','appendixC3'), ('bib.bib3','bibliography22')]:
    ns = [(i,n) for i,n in enumerate(p.nodes) if n['attrs'].get('id') == anchor]
    assert len(ns)==1
    _, n = ns[0]
    a,b = n['start_char'],n['end_char']
    frag = text[a:b]
    fragment_bytes = frag.encode('utf-8')
    (BASE/(filename+'.raw.html')).write_bytes(fragment_bytes)
    units = []
    for idx, q in enumerate(p.nodes):
        x,y = q['start_char'],q['end_char']
        if not (a <= x < y <= b):
            continue
        attrs=q['attrs']
        classes=(attrs.get('class') or '').split()
        kinds=[]
        if attrs.get('id'): kinds.append('labelled-element')
        if q['tag'] in {'h1','h2','h3','h4','h5','h6'}: kinds.append('heading')
        if q['tag'] == 'p': kinds.append('paragraph')
        if q['tag'] == 'math': kinds.append('math')
        if q['tag'] == 'cite': kinds.append('citation-use')
        if q['tag'] == 'a': kinds.append('cross-reference-or-link')
        for cls,kind in [('ltx_equation','equation'),('ltx_equationgroup','equation-group'),('ltx_theorem','theorem-environment'),('ltx_proof','proof-environment'),('ltx_para','paragraph-container'),('ltx_item','list-item'),('ltx_bibitem','bibliography-entry')]:
            if cls in classes: kinds.append(kind)
        if not kinds: continue
        z=text[x:y]
        rec=dict(unit=f'{anchor}:raw:{len(units)+1:04d}', scope=anchor, kinds=kinds,
                 tag=q['tag'], id=attrs.get('id'), classes=classes, attrs=attrs,
                 start_char=x,end_char=y,start_byte=len(text[:x].encode('utf-8')),
                 end_byte=len(text[:y].encode('utf-8')),raw_sha256=digest(z.encode('utf-8')),
                 text=readable(z), math_alttext=attrs.get('alttext') if q['tag']=='math' else None,
                 raw_html=z)
        units.append(rec)
    soup=BeautifulSoup(fragment_bytes,'html.parser')
    for m in soup.find_all('math'):
        m.replace_with(' ⟦'+(m.get('alttext') or m.get_text(' ',strip=True))+'⟧ ')
    block=[]
    # Paragraph/container selection is deliberately source ordered and lossless via the raw fragment.
    for e in soup.find_all(['h1','h2','h3','h4','h5','h6','p','table']):
        if e.name=='p' and e.find_parent('table'): continue
        if e.name=='table' and e.find_parent('table'): continue
        block.append('['+(e.get('id') or e.find_parent(id=True).get('id') if e.find_parent(id=True) else anchor)+'] '+e.get_text(' ',strip=True))
    if not block:
        block.append('['+anchor+'] '+readable(frag))
    (BASE/(filename+'.readable.txt')).write_text('\n\n'.join(block)+'\n')
    jsonwrite(filename+'.raw_units.json',units)
    sections.append(dict(anchor=anchor,raw_file=filename+'.raw.html',raw_sha256=digest(fragment_bytes),bytes=len(fragment_bytes),unit_count=len(units),start_char=a,end_char=b))
    all_units += units

jsonwrite('raw_unit_inventory.json',all_units)
jsonwrite('raw_extraction_manifest.json',dict(source_path=str(SOURCE),source_sha256=EXPECTED,
    extraction='Exact UTF-8 byte-preserving source slices. HTMLParser spans use original document; BeautifulSoup is used only for readable views and metadata.',
    scopes=sections,raw_unit_count=len(all_units),scope_limitation='S2, S4, A3.SS3 and displayed bibliography [22] (bib.bib3) are the mathematical scope. The initially mistaken DOM id bib.bib22 was read and exposed displayed bibliography [19]; its title/metadata are an incidental exposure and supply no mathematics. Cross-reference destinations outside these scopes are not consulted.'))
print(json.dumps(sections,indent=2))
