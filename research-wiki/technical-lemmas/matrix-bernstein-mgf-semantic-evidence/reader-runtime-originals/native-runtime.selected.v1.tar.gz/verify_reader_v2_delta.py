#!/usr/bin/env python3
"""Independently verify the author's six-page source-anchor class repair."""
import datetime as dt
import difflib
import hashlib
import json
from pathlib import Path
import re

OWN = Path(__file__).resolve().parent
REPO = OWN.parents[3]
BASE = REPO / '.astis/huanjian-gc-weighted-mgf-20261114'
OLD = BASE / 'reader-preview-v1'
NEW = BASE / 'reader-preview-v2'

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def main():
    assert sha(OLD / 'preview-freeze-manifest.json') == 'f2cbc9d412344fe2ec1d97a5c8bab21f83ffdc4d8e34d58d6f17e63d0d4e99c4'
    assert sha(NEW / 'preview-freeze-manifest.json') == 'c93f60d6b51a0da491bd748d54bdbc68fbdbc2f86653de5914539afb2aaee7d1'
    assert sha(NEW / 'reader_overlay.py') == 'd0970e97904d550a69d0b403dd2bda50e56d7639bc1c9bbe00ab23293c8038a1'
    assert (OLD / 'render_preview.py').read_bytes() == (NEW / 'render_preview.py').read_bytes()
    assert (OLD / 'input-freeze-manifest.json').read_bytes() == (NEW / 'input-freeze-manifest.json').read_bytes()
    old = json.loads((OLD / 'preview-freeze-manifest.json').read_text())
    new = json.loads((NEW / 'preview-freeze-manifest.json').read_text())
    inputs = json.loads((NEW / 'input-freeze-manifest.json').read_text())
    snapshots = []
    for row in inputs['files']:
        a = OLD / 'input-snapshot' / row['path']
        b = NEW / 'input-snapshot' / row['path']
        assert a.read_bytes() == b.read_bytes() and sha(b) == row['sha256'] and b.stat().st_size == row['bytes']
        snapshots.append({'path': str(b), 'sha256': row['sha256'], 'bytes': row['bytes']})
    expected_snapshot_paths = {row['path'] for row in inputs['files']}
    assert {str(p.relative_to(NEW / 'input-snapshot')) for p in (NEW / 'input-snapshot').rglob('*') if p.is_file()} == expected_snapshot_paths
    fixture_files = []
    changed = {}
    source_delta = []
    for variant in ['original', 'candidate']:
        prior = {row['path']: row for row in old['variants'][variant]['files']}
        current = {row['path']: row for row in new['variants'][variant]['files']}
        assert set(prior) == set(current)
        assert {str(p.relative_to(NEW / 'fixtures' / variant)) for p in (NEW / 'fixtures' / variant).rglob('*') if p.is_file()} == set(current)
        changed[variant] = []
        for relative, row in current.items():
            a, b = OLD / 'fixtures' / variant / relative, NEW / 'fixtures' / variant / relative
            assert sha(b) == row['sha256'] and b.stat().st_size == row['bytes']
            fixture_files.append({'path': str(b), 'sha256': row['sha256'], 'bytes': row['bytes']})
            before, after = a.read_bytes(), b.read_bytes()
            if before != after:
                changed[variant].append(relative)
                assert variant == 'candidate' and relative.startswith('data/lesson-sources/') and relative.endswith('.lean.html')
                assert before.count(b'<pre><code class="language-lean">') == 1
                assert before.replace(b'<pre><code class="language-lean">', b'<pre><code class="native-anchored-lean">', 1) == after
                assert re.findall(rb'<span id="L\d+"', before) == re.findall(rb'<span id="L\d+"', after)
                source_delta.append({'path': relative, 'old_sha256': sha(a), 'new_sha256': sha(b), 'only_pre_code_class_changed': True, 'line_anchor_count_unchanged': len(re.findall(rb'<span id="L\d+"', after))})
    assert changed['original'] == [] and len(changed['candidate']) == 6
    assert (OLD / 'reader_overlay.py').read_bytes().count(b'language-lean') == 1
    expected_overlay = (OLD / 'reader_overlay.py').read_bytes().replace(b'language-lean', b'native-anchored-lean', 1)
    assert expected_overlay == (NEW / 'reader_overlay.py').read_bytes()
    diff_files = []
    for row in new['changed_files']:
        relative = row['path']
        before = (NEW / 'fixtures/original' / relative).read_bytes() if row['original_sha256'] else b''
        after = (NEW / 'fixtures/candidate' / relative).read_bytes() if row['candidate_sha256'] else b''
        exact = ''.join(difflib.unified_diff(before.decode().splitlines(keepends=True), after.decode().splitlines(keepends=True), fromfile='original/' + relative, tofile='candidate/' + relative))
        path = NEW / row['diff']
        assert path.read_text() == exact
        diff_files.append({'path': str(path), 'sha256': sha(path), 'bytes': path.stat().st_size})
    receipt_path = REPO / '.astis/huanjian-resume-20261103/20261114T085512527140Z-matrix-mgf-reader-v2-minimal-anchor-repair-render.receipt.json'
    receipt = json.loads(receipt_path.read_text())
    assert receipt['exit_code'] == 0 and sha(receipt['log']) == receipt['log_sha256']
    report = {'schema': 'independent-reader-preview-v2-minimal-anchor-repair-verification-v1', 'status': 'STATIC_EXACT_DELTA_ACCEPTED;RUNTIME_NOT_RUN;ROOT_EXECUTION_REQUIRES_ITS_NEXT_CONFIRMATION', 'utc': dt.datetime.now(dt.timezone.utc).isoformat(), 'prior_preview_manifest_sha256': sha(OLD / 'preview-freeze-manifest.json'), 'new_preview_manifest_sha256': sha(NEW / 'preview-freeze-manifest.json'), 'new_overlay_sha256': sha(NEW / 'reader_overlay.py'), 'renderer_byte_identical': True, 'renderer_sha256': sha(NEW / 'render_preview.py'), 'input_manifest_byte_identical': True, 'input_manifest_sha256': sha(NEW / 'input-freeze-manifest.json'), 'input_snapshot_count': len(snapshots), 'all120_input_snapshot_bytes_identical': True, 'all109_original_fixture_files_identical': True, 'candidate_changed_source_pages': source_delta, 'only6_candidate_source_pre_code_class_changes': True, 'all_other104_candidate_fixture_files_identical': True, 'original_and_candidate_graph_JS_CSS_math_code_download_payloads_unchanged': True, 'all_new_original_candidate_diffs_exact': True, 'root_render_receipt': {'path': str(receipt_path), 'sha256': sha(receipt_path), 'exit_code': 0, 'generation_observed_HEAD': receipt['head_before'], 'log_path': receipt['log'], 'log_sha256': receipt['log_sha256']}, 'mathematical_candidate': new['proof_commit'], 'lesson_sha256': new['lesson_sha256'], 'publication_sha256': new['publication_sha256'], 'snapshot_files': snapshots, 'fixture_files': fixture_files, 'diff_files': diff_files, 'highlighter_compatibility_reason': 'Numbered full-source wrapper no longer matches the frozen code.language-lean selector that replaces children via innerHTML. Proof-step code still matches and remains byte unchanged. Actual DOM anchor survival must be retested; no runtime acceptance is inferred.', 'normal_API_or_Chrome_calls': 0, 'global_production_renderer_CSS_JS_or_metadata_edits': 0}
    path = OWN / 'reader-v2-minimal-anchor-repair-verification.json'
    path.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({'status': report['status'], 'report_sha256': sha(path), 'input_snapshots_identical': 120, 'original_fixture_files_identical': 109, 'candidate_changed_source_pages': 6, 'all_other_candidate_files_identical': 104, 'ROOT_render_receipt_sha256': sha(receipt_path)}))

if __name__ == '__main__':
    main()
