from pathlib import Path
import datetime, difflib, gzip, hashlib, json
sha = lambda b: hashlib.sha256(b).hexdigest()
R = Path('.astis/huanjian-gc-fixed-spectrum-first-order-integration-20261108')
previous = R/'graph-selection-repair-v2'; P = R/'graph-selection-repair-v3'
assert not P.exists(); P.mkdir()
before = Path('website/static/underlying-lean-graph.js').read_bytes()
assert sha(before) == 'cb899b6cff1e241a47ee88bff0fb72d04a56af7e4134bfe30168d44a2f00c6e7'
v2 = (previous/'underlying-lean-graph.planned-after.js').read_bytes()
line = next(row for row in v2.splitlines(True) if b'document.querySelectorAll("[data-functor-jump]")' in row)
assert line.count(b'requestAnimationFrame(fit)') == 1
new_line = line.replace(b'requestAnimationFrame(fit)',b'requestAnimationFrame(()=>fit({readable:true}))')
assert v2.count(line) == 1
after = v2.replace(line,new_line,1)
for name,raw in [('before.raw.js.gz',before),('planned-after.raw.js.gz',after)]:
    p=P/name; p.write_bytes(gzip.compress(raw,mtime=0)); assert gzip.decompress(p.read_bytes()) == raw
(P/'underlying-lean-graph.planned-after.js').write_bytes(after)
diff=''.join(difflib.unified_diff(before.decode().splitlines(True),after.decode().splitlines(True),fromfile='a/website/static/underlying-lean-graph.js',tofile='b/website/static/underlying-lean-graph.js'))
(P/'exact-UI-repair.diff').write_text(diff)
x=json.loads((previous/'proposal-report.json').read_bytes())
x.update({'version':3,'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'planned_after_sha256':sha(after),
    'superseded_proposal_preserved':{'path':str(previous/'proposal-report.json'),'sha256':sha((previous/'proposal-report.json').read_bytes()),
        'reason':'Independent review identified actual data-functor-jump caller queues a default fit after selectNode, overriding v2. Preserve v2 as correct only for its narrower paths.'},
    'diagnosis':'Searched native selection changes layout without framing it. selectNode must queue readable fit after setView defaults, and the native functor preset caller must not queue a later overriding default fit.',
    'change':'Two locations only: enqueue readable fit after rendering any searched selectNode; make the actual native functor preset trailing fit explicitly readable. Explicit Fit still frames all, non-query fitting keeps its previous semantics, manual pan/zoom remain available afterward. New selection intentionally resets the camera in a searched slice.',
    'required_review':'Independent exact final diff/callback-order review before applying; v4 native full SVG/label geometry at both widths for parent/module navigation, actual emitted functor preset and functor-to-module path. Preserve38main captures and old guards; extra paths can be honestly DOM/UI-only.'})
x['before_archive']={'path':str(P/'before.raw.js.gz'),'sha256':sha((P/'before.raw.js.gz').read_bytes())}
x['after_archive']={'path':str(P/'planned-after.raw.js.gz'),'sha256':sha((P/'planned-after.raw.js.gz').read_bytes())}
x['diff']={'path':str(P/'exact-UI-repair.diff'),'sha256':sha((P/'exact-UI-repair.diff').read_bytes())}
(P/'proposal-report.json').write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
assert Path('website/static/underlying-lean-graph.js').read_bytes() == before
print(json.dumps({'proposal':str(P/'proposal-report.json'),'sha256':sha((P/'proposal-report.json').read_bytes()),
                  'planned_after_sha256':sha(after),'not_applied':True}))
