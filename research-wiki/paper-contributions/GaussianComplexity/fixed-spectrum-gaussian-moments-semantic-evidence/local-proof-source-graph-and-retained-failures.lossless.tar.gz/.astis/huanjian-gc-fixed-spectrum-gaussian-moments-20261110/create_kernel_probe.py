from pathlib import Path
import json
W = Path('.astis/huanjian-gc-fixed-spectrum-gaussian-moments-20261110')
s = json.loads((W / 'statement-seal-v2.json').read_text())
sig = s['actual_private_consumer']['signature']
head, body = sig.split(' :\n', 1)
params = head.removeprefix('private theorem actual_gaussian_cosine_alias_series')
expected = 'def ExpectedPrivate : Prop := ∀' + params + ',\n' + body + '\n'
example = s['producer']['signature'].replace('theorem actual_diagonal_gaussian_quadratic_means', 'example', 1).rstrip() + ''' := by
  exact AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumGaussianMoments.actual_diagonal_gaussian_quadratic_means hd hκ n hn hnd

'''
old = Path('.astis/huanjian-gc-fixed-spectrum-grid-alias-20261109/KernelAndExactMeaningV2.lean').read_text()
tail = old[old.index('run_cmd do'):]
alias = 'AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumGridAlias.actual_midpoint_grid_cosine_alias'
target = s['producer']['name']
tail = tail.replace(alias, target)
tail = tail.replace('    n == target || n.toString.endsWith ".actual_weighted_inverse_grid_alias_series"',
                    '    n == target || n.toString.endsWith ".actual_gaussian_cosine_alias_series"')
mark = '  let c7 := `AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumCosineExpansion.actual_inverse_spectrum_cosine_expansion\n'
assert mark in tail
tail = tail.replace(mark, mark + '  let grid := `' + alias + '\n')
tail = tail.replace('publicParents.length == 2 && publicParents.contains target && publicParents.contains c7',
                    'publicParents.length == 3 && publicParents.contains target && publicParents.contains c7 && publicParents.contains grid')
tail = tail.replace('Actual consumer must use exactly new canonical alias and C7:',
                    'Actual Gaussian consumer must use exactly means producer, canonical C7 and GridAlias:')
mark = '          logInfo m!"ACTUAL_GENERATED_AUXILIARY_USES {u}: {ap.getUsedConstants.toList}"\n'
assert mark in tail
tail = tail.replace(mark, mark + '          logInfo m!"ACTUAL_GENERATED_AUXILIARY_COMPLETE_PROOF_REPR {u}: {repr ap}"\n')
probe = '''import Tests.GaussianComplexityFixedSpectrumGaussianMoments
open MeasureTheory ProbabilityTheory
open scoped BigOperators
open Lean
set_option autoImplicit false

''' + example + expected + tail
p = W / 'KernelAndExactMeaning.lean'
assert not p.exists()
p.write_text(probe)
print(p)
