"""Seal this real v3 presentation run and separately bound the v4 byte-identity transfer."""
import hashlib
import json
from pathlib import Path

OWN=Path(__file__).resolve().parent
REPO=OWN.parents[3]
BASE=REPO/'.astis/huanjian-gc-matrix-laplace-20261114'
V3=BASE/'reader-preview-v3';V4=BASE/'reader-preview-v4'

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
def leaf(p):
    assert p.resolve().is_relative_to(OWN) and p.is_file()
    return {'path':str(p.relative_to(OWN)),'bytes':p.stat().st_size,'sha256':sha(p)}

def main():
    contract=OWN/'independent-browser-contract.v1.json'
    c=json.loads(contract.read_text())
    assert sha(contract)=='8014f171e503a9ed9d918176f82b09f1e847ca964b5a4cc54c09cd62b6dc30c5'
    assert sha(OWN/'browser_check.py')==c['wrapper_sha256']
    for row in c['owned_inputs']:assert sha(Path(row['path']))==row['sha256']
    result_path=OWN/'browser-output-v1/candidate/actual-checks.json'
    process_path=OWN/'browser-process-v1/candidate/process-receipt.json'
    r=json.loads(result_path.read_text());p=json.loads(process_path.read_text())
    assert r['status']=='PASS' and p['exit_code']==0 and p['exception'] is None
    assert len(r['checks'])==398 and all(x['pass'] for x in r['checks'])
    assert len(r['screenshots'])==103 and r['browser_started']
    assert r['reader_identity']['metadata_version']=='authored-v3'
    assert r['reader_identity']['frozen_fixture_manifest_sha256']=='9209609b560905e6cd11a69082ac4bdb89e752a66fe3e99ba38e17508d2103b7'
    assert r['contract_sha256']==sha(contract)==p['contract_sha256']
    assert not r['javascript_errors'] and not r['blocked_external_requests']
    assert p['actual_checks']['sha256']==sha(result_path)
    for stream in ['stdout','stderr']:assert sha(OWN/p[stream]['path'])==p[stream]['sha256']
    screenshots=[]
    for row in r['screenshots']:
        path=OWN/row['path'];assert sha(path)==row['sha256'];screenshots.append(path)
    identity_path=OWN/'v3-v4-site-byte-identity.v1.json'
    identity=json.loads(identity_path.read_text())
    assert identity['all_207_path_bytes_sha_and_direct_bytes_identical'] and not identity['v4_browser_executed']
    assert sha(V3/'preview-freeze-manifest.json')==identity['v3_preview_manifest_sha256']
    assert sha(V4/'preview-freeze-manifest.json')==identity['v4_preview_manifest_sha256']
    # Copy exact checked input originals for independent replay/custody; no modified or synthesized pages.
    copied=[]
    for version,root in [('v3',V3),('v4',V4)]:
        for name in ['preview-freeze-manifest.json','input-freeze-manifest.json']:
            dest=OWN/'input-originals'/version/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes((root/name).read_bytes());copied.append(dest)
    m=json.loads((V3/'preview-freeze-manifest.json').read_text())
    for variant in ['original','candidate']:
        for row in m['variants'][variant]['files']:
            source=V3/'fixtures'/variant/row['path']
            assert sha(source)==row['sha256']
            dest=OWN/'input-originals/v3/fixtures'/variant/row['path'];dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(source.read_bytes());copied.append(dest)
    for source in c['sources']:
        raw=source['raw'];a=V3/'input-snapshot'/raw
        assert sha(a)==source['sha256']
        dest=OWN/'input-originals/v3/input-snapshot'/raw;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(a.read_bytes());copied.append(dest)
    downloads=sorted((OWN/'browser-output-v1/candidate').glob('*.lean'))
    assert len(downloads)==20
    font_checks=[x for x in r['checks'] if x['name'].endswith('graph-public-P-readable-after-existing-UI-zoom-pan')]
    observed_images=['desktop-step-5.png','mobile-step-5.png','mobile-source-T-anchor.png','mobile-source-T-glyph-segment-1.png','desktop-graph-public-P-actual-UI-zoom-pan.png','mobile-graph-public-P-actual-UI-zoom-pan.png','mobile-graph-detail-reader-and-edges.png','mobile-source-T-bottom-glyph.png','mobile-proof-initial.png','desktop-parent-context.png']
    for name in observed_images:assert (OWN/'browser-output-v1/candidate'/name) in screenshots
    report={
      'schema':'independent-laplace-native-reader-outcome-v1',
      'status':'ACTUAL_V3_PRESENTATION_CHECKS_PASSED;ROOT_AND_FRESH_REVIEW_SEPARATE',
      'mathematical_commit':c['mathematical_candidate'],'actual_browser_target':'reader-preview-v3 candidate only',
      'actual_preview_manifest_sha256':identity['v3_preview_manifest_sha256'],'contract_sha256':sha(contract),'wrapper_sha256':sha(OWN/'browser_check.py'),
      'actual_process_receipt_sha256':sha(process_path),'actual_checks_sha256':sha(result_path),'actual_process_exit_code':p['exit_code'],
      'actual_started_utc':p['started'],'actual_ended_utc':p['ended'],'actual_chrome':r['actual_chrome'],
      'viewports':c['viewports'],'actual_check_count':398,'false_checks':0,'new_PNG_count':103,'actual_module_download_count':20,
      'source_and_fold_identity':{'P_lines':96,'T_lines':193,'four_source_pages_total_lines':663,'source_pages':c['sources'],'six_folds':'P/P/P/T/T/T byte-exact','adjacent_source_starts':[1,53,86,1,77,165]},
      'observed_checks':['MathJax formulas and overflow right reach','initial folded statement/proof and six steps','expanded step code/source/copy/download actions','four complete source pages with headers, anchors, every-line layout, longest full codepoint horizontal/vertical reach and bottom full-codepoint visibility','actual clipboard and complete-module downloads','source-index to reader to bounded graph navigation','exact seven graph nodes and nine edges; public P has no ASTIS theorem parent; private T has source module only','real wheel/pointer zoom, full identity in detail and actual parent/source navigation','actual parent-context page lists P/Radius/Structure for private T and no ASTIS mathematical parent for public P'],
      'measurement_method':'Actual Chrome geometry of final full Unicode codepoint in the original Text node, using trimEnd only to select non-whitespace endpoint; all positive width/height, header, viewport and horizontal bounds retained. DOM text and fixture bytes unchanged.',
      'page_javascript_errors':[],'external_browser_requests':[],'all_frozen_candidate_fixture_bytes_unchanged_after_run':True,
      'visual_inspection_by_this_actor':{'actual_PNGs_opened':observed_images,'finding':'No new blocking reader defect observed in these actual images. Full source is intentionally horizontally scrollable. Initial disclosures are closed; adjacent source/module/copy actions and formula panels are visible.'},
      'graph_readability_limits':{'default_fit_effective_font_desktop_px':font_checks[0]['detail']['default_fit']['effectiveFontPx'],'default_fit_effective_font_mobile_px':font_checks[1]['detail']['default_fit']['effectiveFontPx'],'after_actual_UI_zoom_desktop_px':font_checks[0]['detail']['after_real_wheel_and_pointer_UI']['effectiveFontPx'],'after_actual_UI_zoom_mobile_px':font_checks[1]['detail']['after_real_wheel_and_pointer_UI']['effectiveFontPx'],'limitation':'Default-fit graph labels remain small. Zoomed long labels remain ellipsized; mobile selected node can extend past the viewport. Complete exact declaration is readable in the detail panel and navigation was actually exercised. This is not a claim of fully legible whole-graph fit.'},
      'v4_transfer':{'v4_preview_manifest_sha256':identity['v4_preview_manifest_sha256'],'independent_207_served_files_path_size_hash_and_direct_bytes_identity':True,'identity_report_sha256':sha(identity_path),'v4_browser_run':False,'scope':'Only observations of identical served pages transfer to v4. This does not independently approve the metadata/source repair or invent a new v4 process/PNG.'},
      'old_v2_context':'Separate prior directory reader-runtime/ retained unchanged; its actual398 PASS checks/103 PNGs belong to obsolete v2 context and are not current v3 evidence.',
      'preparation_failure':'Initial static extractor incorrectly counted two full inline disclosure pre blocks with the six step pre blocks. Attempt1 source retained in old directory; fixed only harness scoping to details.proof-reader-step. No page changed and no browser outcome inferred from that static failure.',
      'truth_boundary':'Isolated reader presentation/native browser outcome only; not public deployment, root website acceptance, source-fidelity review, metadata gate, VERIFIED/normal V transition or mathematical/whole-Goal completion.',
      'production_Git_ledger_API_writes':0,'server_lifecycle':'foreground process only; shutdown/server_close/worker.join completed before process receipt sealed',
      'input_original_copies':'After-run byte-identical copies of the frozen actual v3 served inputs, plus v3/v4 manifests. Actual server served the original frozen v3 fixture path recorded by contract.'
    }
    write(OWN/'native-reader-outcome.v1.json',report)
    leaves=[OWN/n for n in ['native-reader-outcome.v1.json','independent-browser-contract.v1.json','sourcebody-byte-exact.v1.json','v3-v4-site-byte-identity.v1.json','browser_check.py','browser_extensions.py','extra_measurements.py','prepare_browser.py','record_prepare.py','prepare-attempt2.stdout.raw','prepare-attempt2.stderr.raw','prepare-attempt2.receipt.json','verify_v4_site_identity.py','finalize_reader_evidence.py']]
    leaves += [result_path,process_path]+[OWN/p[s]['path'] for s in ['stdout','stderr']]+screenshots+downloads+copied
    assert len({str(x) for x in leaves})==len(leaves)
    write(OWN/'presentation-selected-originals.manifest.v1.json',{'schema':'explicit-independent-presentation-evidence-leaves-v1','actual_run':'v3','v4_new_browser_run':False,'math_native_239_manifest_untouched':True,'old_v2_PNGs_or_results_in_current_leaves':False,'private_workspace_guards_excluded':True,'leaves':[leaf(x) for x in leaves]})
    print(json.dumps({'actual_v3_checks_passed':398,'new_actual_PNGs':103,'v4_transfer_only_by_207_identical_served_files':True,'report_sha256':sha(OWN/'native-reader-outcome.v1.json'),'manifest_sha256':sha(OWN/'presentation-selected-originals.manifest.v1.json'),'evidence_leaves':len(leaves)}))

if __name__=='__main__':main()
