from pathlib import Path
import sys,subprocess,json,datetime,time,hashlib,base64,os,stat
root=Path("/Users/zhouhuanjian/ASTIS-GC/.astis/semantic-neutral-20261111/kr_src_c47e12");p=root/'phase3'
h=lambda b:hashlib.sha256(b).hexdigest()
child_code=r"""from pathlib import Path
import json,hashlib,stat,datetime
root=Path("/Users/zhouhuanjian/ASTIS-GC/.astis/semantic-neutral-20261111/kr_src_c47e12");p=root/'phase3'
h=lambda b:hashlib.sha256(b).hexdigest()
earlier=[]
for name,sha in [('phase1','a167e2a7d8d37008db6c3ba80e23598c86479896be084604ce46bdb9b16b3741'),('phase2','9c019cdbac59fdc3675474f0434573cb812e44350f63af017153fa2487dbddd2')]:
 ep=root/name;mp=ep/'hash-manifest.json';assert h(mp.read_bytes())==sha
 m=json.loads(mp.read_text())
 for r in m['files']:
  path=ep/r['path'];b=path.read_bytes()
  assert len(b)==r['bytes'] and h(b)==r['sha256'] and stat.S_IMODE(path.stat().st_mode)==0o444,r['path']
 assert {str(x.relative_to(ep))for x in ep.rglob('*')if x.is_file()}=={r['path']for r in m['files']}|{'hash-manifest.json'}
 assert stat.S_IMODE(mp.stat().st_mode)==0o444
 assert all(stat.S_IMODE(x.stat().st_mode)==0o555 for x in [ep]+[x for x in ep.rglob('*')if x.is_dir()])
 earlier.append({'phase':name,'manifest_sha256':sha,'files':len(m['files'])+1,'exact_file_set_bytes_and_modes_unchanged':True})
(p/'earlier-phases-unchanged-at-archive-freeze.json').write_text(json.dumps({'time_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':earlier},indent=2)+'\n')
fp=p/'mathematical-freeze.json'
assert h(fp.read_bytes())=='1739d07708cc6e6d21ccdabf99fe08e9144c2104ed7db31d3936ee38a2001f7b'
f=json.loads(fp.read_text())
for r in f['core_artifacts']:
 b=(p/r['path']).read_bytes();assert len(b)==r['bytes'] and h(b)==r['sha256'],r['path']
for name,r in json.loads((p/'input-manifest.json').read_text()).items():
 b=(p/'inputs'/name).read_bytes();assert len(b)==r['bytes'] and h(b)==r['sha256'],name
receipts=0
for rp in sorted((p/'audit').glob('*.receipt.json')):
 r=json.loads(rp.read_text())
 for k in ['stdout','stderr']:
  b=(rp.parent/r[k]['path']).read_bytes();assert len(b)==r[k]['bytes'] and h(b)==r[k]['sha256']
 receipts+=1
print(json.dumps({'pre_archive_validation':'PASS','earlier_phase_files_unchanged':111,'phase3_math_freeze_and_inputs_unchanged':True,'raw_command_receipts_valid':receipts,'mapping_native_schema_or_other_review_results_seen':False,'source_verifier_transition':False},indent=2))
"""
start=datetime.datetime.now(datetime.timezone.utc).isoformat();t0=time.monotonic()
argv=['/opt/anaconda3/bin/python','-c',child_code]
r=subprocess.run(argv,cwd='/Users/zhouhuanjian/ASTIS-GC',stdout=subprocess.PIPE,stderr=subprocess.PIPE)
receipt={'schema':'original-phase3-final-execution-receipt-v1','wrapper_argv':sys.argv,'wrapper_file_sha256':h(Path(__file__).read_bytes()),'child_argv':argv,'cwd':'/Users/zhouhuanjian/ASTIS-GC','started_utc':start,'ended_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'elapsed_seconds':time.monotonic()-t0,'exit_code':r.returncode,'stdout_raw_base64':base64.b64encode(r.stdout).decode('ascii'),'stderr_raw_base64':base64.b64encode(r.stderr).decode('ascii'),'stdout_sha256':h(r.stdout),'stderr_sha256':h(r.stderr),'note':'Exact byte streams without normalization. Receipt is included in the subsequently written detached complete hash manifest. Final hash-report output appears in the original tool transcript.','mathematical_freeze_sha256':'1739d07708cc6e6d21ccdabf99fe08e9144c2104ed7db31d3936ee38a2001f7b','process_only_commit_id_seen_after_judgment_authorship_before_math_freeze':'972d8994a816bc63d2dd6fb2db1c2c638fa9a48f','commit_independently_verified':False,'mapping_native_schema_or_other_review_results_seen':False,'source_verifier_transition':False}
rp=p/'original-execution-receipt.json';rp.write_text(json.dumps(receipt,indent=2)+'\n')
sys.stdout.buffer.write(r.stdout);sys.stdout.buffer.flush()
sys.stderr.buffer.write(r.stderr);sys.stderr.buffer.flush()
if r.returncode:raise SystemExit(r.returncode)
rows=[]
for path in sorted(p.rglob('*')):
 if path.is_file() and path.name!='hash-manifest.json':
  assert not path.is_symlink(),str(path)
  os.chmod(path,0o444);b=path.read_bytes()
  rows.append({'path':str(path.relative_to(p)),'bytes':len(b),'sha256':h(b),'mode':'0444'})
manifest={'schema':'immutable-phase3-complete-manifest-v1','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reviewer':'/root/krylov_fresh_source_c47e12','scope':'All phase3 files except this detached hash manifest itself. Includes all original inputs, independent mathematical judgment, honest exposure, complete command/raw-stream records, canonical declaration windows and original final execution receipt.','source_id':'arXiv:2610.20492v1','source_raw_sha256':'6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915','canonical_packet_sha256':'fa176cb7c2ff06fd19a0fdbc721b8dc64069eb3902a6012d41fe52a5f12f90d1','publication_binding_sha256_as_reported':'7b97440eda9692f238e20ad1f0e985b5c38b4fc4f358ccffb02535b92df14ea7','mathematical_freeze_sha256':'1739d07708cc6e6d21ccdabf99fe08e9144c2104ed7db31d3936ee38a2001f7b','phase1_all84_and_phase2_all27_unchanged':True,'files':rows,'file_mode':'0444','directory_mode':'0555','mapping_native_schema_or_other_review_results_seen':False,'source_verifier_transition':False}
mp=p/'hash-manifest.json';mp.write_text(json.dumps(manifest,indent=2)+'\n');os.chmod(mp,0o444)
for d in sorted([x for x in p.rglob('*')if x.is_dir()],key=lambda x:len(x.parts),reverse=True):os.chmod(d,0o555)
os.chmod(p,0o555)
for path in [p]+list(p.rglob('*')):
 assert stat.S_IMODE(path.stat().st_mode)==(0o555 if path.is_dir() else 0o444),str(path)
for row in rows:
 b=(p/row['path']).read_bytes();assert len(b)==row['bytes'] and h(b)==row['sha256']
print(json.dumps({'phase3_manifest_sha256':h(mp.read_bytes()),'phase3_mathematical_freeze_sha256':'1739d07708cc6e6d21ccdabf99fe08e9144c2104ed7db31d3936ee38a2001f7b','original_execution_receipt_sha256':h(rp.read_bytes()),'mathematical_judgment_json_sha256':h((p/'mathematical-source-proof-reader-judgment.json').read_bytes()),'files_in_manifest':len(rows),'total_frozen_files':len(rows)+1,'all_files_0444_and_directories_0555':True,'earlier_phase_files_unchanged':111,'source_verifier_transition':False,'exit_code':0},indent=2))

