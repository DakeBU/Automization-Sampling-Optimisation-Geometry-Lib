# Independent raw-source expectation freeze v1

Role: DISTINCT SOURCE TOPOLOGY CHALLENGER, preparation only.
Direction fingerprint: raw-Tropp-one-sided-mgf-and-native-consumer / separate-Gaussian-two-sided-use.

This freeze precedes receipt of a literal sealed P/T, definition audit, or proposed Source Proof Graph. It does not infer the next exact target. It is not a graph acceptance, theorem seal, source repair, proof proposal, Lean result, or Gaussian completion claim.

## Independence and authority

- Only the two assigned primary sources, repository instructions/protocols, the named audit skills, and read-only PDF tooling instructions were opened for substance.
- No proposed SG, current target/header, Lean proof body, declaration lesson, or prior verdict was opened. An initial filename discovery listed historical repository artifact names only; no such artifact contents were consumed.
- No Lean build, proof worker, browser, ASTIS background process, ledger/frontier update, source repair, or shared repository write was performed.
- All new files are inside `.astis/semantic-neutral-20261114/bernstein_mgf_tc_29d8`.
- Gaussian has the current user-directed priority over the older four-paper scheduling text. This role does not modify any queue, owner, Goal, frontier, or prior evidence.
- Proof ingredients must remain internal dependency edges. A source-derived estimate does not become an extra Gaussian main-theorem premise merely because a producer exists.
- Reuse/canonicality of existing compiled nodes is a later, separate audit. No private Gaussian result was inspected or duplicated here.

## Pinned sources and inspected regions

1. Joel A. Tropp, *User-Friendly Tail Bounds for Sums of Random Matrices*, author revision of 15 June 2011, 32-page preprint. PDF SHA-256 `f4c3cff8661011395e793972a1f8d9a199fae4ca0fd098535d7a42166cf8fc86`.
   - Original: `.astis/semantic-neutral-20261113/bernstein_raw_intake_74ab/Tro11-User-Friendly-preprint.pdf`.
   - Full raw copy and layout extraction are frozen in `inputs/`.
   - Complete rendered PDF pages 7, 8, 23, 24, 25, 26 were visually inspected. Relevant text on page 9 (expectation order), page 12 (Corollary 3.7), and page 1 (version/title) was also read.
2. *On Complexity of Gaussian Sampling*, arXiv `2610.20492v1`, pinned HTML SHA-256 `6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915`.
   - Original: `.astis/huanjian-resume-20261103/2610.20492v1.html`.
   - Full raw copy, exact C.2 HTML slice, and C.2 prose/math-alttext extraction are frozen in `inputs/`.
   - C.2 was read through Fact C.6, Ex121, the parameter substitution, event bookkeeping, and its Lemma 4.4 consumer.
   - No literal `Tropp` occurrence was found in the complete pinned HTML. The Gaussian text names the two-sided bounded matrix Bernstein inequality without an identified Tropp citation. Tropp is therefore an external mathematical match, not a cited-source identity silently attached to the Gaussian paper.

## Source conventions that must survive a later target audit

### Domains, order, functional calculus, and norm

- Tropp §2.1: finite complex matrices, square by default; self-adjoint means Hermitian. A real symmetric realization is a specialization requiring an explicit semantic adapter.
- `lambda_min` and `lambda_max` are algebraic extremal eigenvalues of a self-adjoint matrix. They are not entry extrema or singular-value extrema.
- The semidefinite order is Loewner order: the difference is positive semidefinite. It is not entrywise order or a scalar operator-norm estimate.
- The norm is the Euclidean vector norm or its associated spectral/operator norm (maximum singular value). A generic library matrix norm is not automatically the source norm.
- §2.3 defines scalar `f : R -> R` on self-adjoint matrices by unitary diagonalization, `f(A) = Q f(Lambda) Q*`. Definition semantics include independence from the chosen eigenbasis.
- The transfer rule (2.2) compares two scalar functions on the same spectral argument: `f(a) <= g(a)` on an interval containing the spectrum implies `f(A) <=_PSD g(A)`. It does not assert that every scalar increasing function is operator monotone for two different matrices.
- §2.4 defines the matrix exponential by this functional calculus or its matrix power series; it is positive definite. `I + A <=_PSD exp(A)` is (2.3).
- The matrix exponential is explicitly not operator monotone. Trace-exponential monotonicity (2.5) is a different fact and cannot be replaced with matrix-exponential order monotonicity.

### Probability, almost sure scope, and regularity

- §2.2 imposes the standing convention that random variables are sufficiently regular for the expectations, limit interchanges, and other operations being performed. The paper often omits the words "almost surely" from random relations.
- Thus the eigenvalue bound in Lemma 6.7 is an almost-sure bound, although those words are omitted locally. A pointwise-everywhere requirement would be stronger and needs a representative/normalization audit.
- Expectation is matrix expectation; `E X = 0` means zero as a matrix, and the conclusion is an order relation between deterministic matrices.
- No independent distribution assumption is needed for the single random matrix in Lemma 6.7. Independence appears for the family in Theorem 6.1 and in the master-tail consumer.
- A one-sided spectral upper bound alone does not supply all negative-tail second-moment regularity. The source's broad standing regularity convention must remain visible. Exact measurability/integrability/domination statements must be audited or derived, never silently inferred or turned into extra Gaussian main premises.
- §2.7 supplies expectation preservation of semidefinite order (2.13). Expected sums, scalar factors, identity matrices, products with deterministic matrices, and almost-sure inequalities require their actual regularity domains in a formal interface.

## Lemma 6.7: exact mathematical expectations

Source statement, pages 25-26:

For a random self-adjoint matrix `X` with `E X = 0` and `lambda_max(X) <= 1` almost surely,

`E exp(theta X) <=_PSD exp((exp(theta) - theta - 1) E(X^2))` for every `theta > 0`.

The zero center is exact, the spectral radius bound is normalized to one, and the parameter domain is strictly positive. No lower eigenvalue bound, positive-semidefiniteness of `X`, two-sided norm bound, finite-family independence, or Gaussian law occurs in this lemma's displayed hypotheses.

The raw proof contains these substantive regions; they are expected coverage items if a future packet includes the complete lemma route:

1. Fix `theta > 0`. Define a scalar function on the whole real line by `(exp(theta*x) - theta*x - 1)/x^2` for `x != 0`, with the specified value `theta^2/2` at zero. The source calls this a smooth function. The value at zero is part of the definition, not an arbitrary off-domain fallback.
2. The assertion that this function is increasing is left as an exercise in differential calculus. Consequently `f(x) <= f(1)` for every real `x <= 1`. This range includes negative `x`; restricting the claim to nonnegative `x` would miss the one-sided source domain.
3. Apply transfer rule (2.2) using the spectral upper bound to obtain `f(X) <=_PSD f(1) I` almost surely.
4. The matrix identity and congruence estimate are `exp(theta X) = I + theta X + X f(X) X <=_PSD I + theta X + f(1) X^2`. A functional-calculus identity and order preservation under this congruence are substantive bridges even though the source gives them in one line.
5. Take expectations, use the zero center, and obtain `E exp(theta X) <=_PSD I + f(1) E(X^2)`.
6. Use (2.3) at the self-adjoint deterministic matrix `f(1) E(X^2)`, then identify `f(1) = exp(theta) - theta - 1`.

These are a reconstruction of the author's printed regions, not a newly proposed proof route. None may be treated as a free source-theorem hypothesis. A future packet may deliberately isolate one component, in which case the rest remains an explicit external boundary rather than mandatory in-packet proof work.

## Native consumer: Theorem 6.1

- Pages 23-24: a finite independent family of random self-adjoint `d x d` matrices, with `E X_k = 0` and `lambda_max(X_k) <= R` almost surely.
- Total variance is exactly `sigma^2 := ||sum_k E(X_k^2)||` in the spectral norm, rather than an arbitrary bound or the sum of individual norms.
- The displayed event is `lambda_max(sum_k X_k) >= t`, and the stated threshold range is `t >= 0`.
- The theorem gives Bennett, Bernstein, and split Bernstein bounds. The Bernstein part is `d exp(-t^2 / (2 (sigma^2 + R t/3)))`.
- Page 24 emphasizes that the minimum eigenvalues may be arbitrarily small. Applying the theorem to `X_k` and `-X_k` may require different `R` values. A two-sided norm statement is a further adapter, not the literal one-sided theorem.
- Page 26 first normalizes `R = 1` and cites one-homogeneity of the summands and two-homogeneity of variance for scaling.
- Each summand's mgf estimate is supplied by Lemma 6.7 with `g(theta) = exp(theta) - theta - 1`.
- At the actual consumer use site, Corollary 3.7 is invoked for every `theta > 0` with deterministic `A_k = E(X_k^2)`. The passage from `lambda_max(sum E X_k^2)` to the spectral norm needs the positivity of the variance sum.
- Corollary 3.7 itself requires an independent self-adjoint family, fixed self-adjoint `A_k`, and `g : (0,infinity) -> [0,infinity]` with the mgf bound. It uses logarithm monotonicity (2.8), trace-exponential monotonicity (2.5), the master tail bound (3.5), trace <= dimension times largest eigenvalue for a positive-definite matrix, and spectral mapping with nonnegative `g`.
- Theorem 6.1 then selects `theta = log(1 + t/sigma^2)` and gives the scalar bound `h(u) >= (u^2/2)/(1+u/3)` for `u >= 0` by comparing derivatives; it obtains the split forms by the displayed scalar comparisons.
- The full Lieb/master-tail chain has not been audited or discharged here. It must remain open; Lemma 6.7 by itself is not the Bernstein concentration theorem.

Endpoint caution is an unresolved audit item, not a source repair: the printed Theorem 6.1 has `t >= 0`, but its selected optimizer and divisions expose `t=0`, `sigma^2=0`, and `R=0` cases. The exact source standing conventions or separate endpoint treatment must be checked before sealing any totalized formula or adding positivity binders. The printed lemma itself uses `theta>0`; extending it to `theta=0` is not required by its literal statement. No condition above is being newly promoted to a Gaussian paper proposition.

## Separate Gaussian consumer and expected adapter boundary

In Gaussian C.2, `r=q+1`, `n=2q+1`, and `B` has `d` rows and `r^2` columns. Independent Gaussian row vectors generate the truncated real symmetric matrices `Y_i`; the centered matrices are defined as `Z_i = Y_i - E Y_i`.

- C.2 sets `L = 2r + 3 log(1000d)` and provides the operator-norm radius `R_* = 2r(L+1)/d` for each `Z_i` and each deterministic weighted matrix `cos(n theta_i) Z_i`.
- It derives the matrix second-moment bound and the variance upper bound `v_* = 2r(r+2)/d`, including the centered identity `E Z_i^2 = E Y_i^2 - (E Y_i)^2 <=_PSD E Y_i^2` and the squared-weight comparison.
- Paragraph `A3.SS2.p15` asserts that both sequences are independent, centered, and self-adjoint. These claims need internal dependency discharge from the actual construction; they are not new main-paper premises.
- Exact Ex121 (`A3.Ex121`) is, for `t>0`,
  `P(||sum_i Z_i||_op > t) <= 2 r^2 exp(-t^2 / (2 (v_* + R_* t/3)))`.
  The same bound is asserted for the cosine-weighted sum.
- The matrix dimension is `r^2`; the Gaussian parameter `d` counts rows. Confusing these would give the wrong dimension factor.
- Relative to raw Tropp Theorem 6.1(ii), this use needs an explicit adapter for real symmetric matrices, both signs, the norm event, the factor two, an upper bound on variance, and the strict `>` event. A common two-sided radius follows from the source's norm bound; it must not be inferred from Tropp's original one-sided bound alone.
- Deterministic cosine multiplication must preserve independence, center, self-adjointness, and the common radius, and must respect the squared-weight variance bound. These are mathematical dependencies inside the Gaussian construction.
- Ex122-124 set `z=log(1000r^2)` and `Delta=sqrt(2 v_* z)+2 R_* z/3`, perform the displayed denominator comparison, obtain failure at most `0.002` for each matrix, then union-bound the two matrix events to probability at least `0.996`.
- Ex125-126 intersect with the truncation event (failure at most `0.001`), use the bias identities, and reach the `0.995` simultaneous event. Those are downstream consumer regions; they do not follow merely from an mgf lemma.
- Fact C.6 then controls the two Gram matrices; Lemma 4.4 uses the range identity and both bounds on the same event for every coefficient vector. No exact target in this longer chain is selected by this freeze.

## Likely missing-port / graph-challenge checklist

These are expected audit obligations, not claims about current library absence:

1. Full-real scalar definition and its removable value at zero; source-asserted smoothness and monotonicity exercise; endpoint and parameter domains.
2. Finite-dimensional self-adjoint functional calculus, basis-independent definition semantics, transfer rule, spectral-range hypotheses, and the matrix exponential identity at zero eigenvalues as well as nonzero ones.
3. Congruence/order and square positivity; no illicit global operator monotonicity of exponential.
4. Measurability, integrability, and expectation algebra/order under the exact §2.2 standing regularity contract; one-sided spectral boundedness must not substitute for all moment assumptions.
5. Correct center, exact second-moment matrix, scalar multiplication convention, and spectral norm; no entrywise exponential, Frobenius norm, or square-of-expectation substitution.
6. Conditional discharge at the actual Lemma 6.7 -> Corollary 3.7 -> Theorem 6.1 use sites, including nonnegativity of `g`, positivity of variance, scaling, optimization, and the unnamed scalar Bennett-to-Bernstein estimate when they are in scope.
7. Keep Lieb/master-tail and unaudited endpoint/zero cases explicitly open. Do not use them as informal badges of completed Bernstein proof.
8. Keep Gaussian Ex121's two-sided adapter and its dimension/radius/variance/event bookkeeping separate from Tropp's literal statement, and keep the external match separate from actual bibliography attribution.
9. For any future isolated component, mark every out-of-packet source region or dependency as an explicit exclusion/boundary; do not declare whole-lemma, whole-Theorem-6.1, or Gaussian closure from component coverage.
10. Once literal sealed P/T + complete definition audit + SG arrive, compare source domains/quantifiers/assumptions/scopes/constants against that exact packet, review every in-scope proof region and consumer edge, and only then issue a scoped topology verdict. No acceptance is issued now.

Status: RAW_EXPECTATIONS_FROZEN; ready for a later sealed packet. No mathematical failure class, source-invalid finding, proof result, or completion credit is recorded.
