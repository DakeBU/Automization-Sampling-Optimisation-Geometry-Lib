"""Check frozen raw locators, dispositions and focused dependency closures."""

from hashlib import sha256
import json
from pathlib import Path


out = Path(__file__).resolve().parent
root = out.parents[3]
graph = json.loads((out / 'source-graph.json').read_text())
coverage = json.loads((out / 'coverage.json').read_text())
raw = (root / graph['raw_source']).read_bytes()
assert sha256(raw).hexdigest() == graph['raw_source_sha256']
source = raw.decode('utf-8')
items = {item['source_id']: item for item in coverage['items']}
nodes = {node['id']: node for node in graph['nodes']}
parents = {edge['to']: edge['from_all'] for edge in graph['edges']}
assert len(items) == coverage['inventory_items']
assert len(nodes) == len(graph['nodes']) and len(parents) == len(graph['edges'])

for item in items.values():
    loc = item['locator']
    byte_start, byte_end = loc['raw_utf8_start'], loc['raw_utf8_end']
    char_start, char_end = loc['char_start'], loc['char_end']
    span = raw[byte_start:byte_end]
    assert span.decode('utf-8') == source[char_start:char_end]
    assert sha256(span).hexdigest() == loc['span_sha256']
    assert raw.count(b'\n', 0, byte_start) + 1 == loc['lf_line_start']
    assert raw.count(b'\n', 0, byte_end - 1) + 1 == loc['lf_line_end']
    if item['disposition'] == 'NODE':
        assert item['source_id'] in nodes[item['graph_node']]['source_ids']
    else:
        assert item['disposition'] == 'EXCLUDED' and item['reason']

for edge in graph['edges']:
    assert edge['to'] in nodes and all(parent in nodes for parent in edge['from_all'])
    assert edge['use_site'] in nodes[edge['to']]['source_ids'] and edge['discharge_or_use']


def closure(node):
    found = set()
    for parent in parents.get(node, []):
        found |= {parent} | closure(parent)
    return found


assert set(parents['shifted-tail']) == {'row-tail', 'shift-substitution'}
assert set(parents['tail-moment-identity']) == {'nonnegative-layer-cake', 'integrate-envelope'}
assert set(parents['tail-moment-upper']) == {'tail-moment-identity', 'integrate-envelope'}
assert 'radial-mean' not in closure('tail-moment-identity')
assert 'tail-moment-upper' not in closure('scalar-bias-identity')
assert set(parents['scalar-bias-upper']) == {'scalar-bias-identity', 'tail-moment-upper', 'row-dimension-positive'}
assert {'shifted-tail', 'nonnegative-layer-cake', 'radial-mean', 'complementary-truncations'} <= closure('scalar-bias-upper')
assert all(items[anchor]['disposition'] == 'EXCLUDED' for anchor in (
    'A3.SS2.p1.2#row-independence', 'A3.Ex105.m1', 'A3.Ex107.m1',
    'A3.Ex108.m1#covariance', 'A3.SS2.p12.4#Fact-C.5-link', 'A3.Ex110.m1',
))
print(f"Revalidated {len(items)} byte/character spans, {len(parents)} hyperedges and scalar closure checks.")
for label in ('A3.Ex106.m2#identity', 'A3.Ex106.m2#bound', 'A3.Ex108.m1#a',
              'A3.Ex109.m1#identity', 'A3.Ex109.m1#bound'):
    loc = items[label]['locator']
    print(f"{label} line {loc['lf_line_start']} [{loc['raw_utf8_start']},{loc['raw_utf8_end']}) {loc['span_sha256']}")
