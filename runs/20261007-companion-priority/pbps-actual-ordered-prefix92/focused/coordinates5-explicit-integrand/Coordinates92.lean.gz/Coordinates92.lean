import AutoSamplingTheory.ExampleCases.ProximalBPS.ActualAbsoluteNextEventTime
import Mathlib.MeasureTheory.Constructions.Pi
import Mathlib.Order.Fin.Tuple

/-! Internal ordered-simplex induction coordinates for sealed92. -/
namespace OrderedCoordinates92
open MeasureTheory
open scoped NNReal ENNReal
noncomputable section
set_option autoImplicit false

private theorem strictMono_snoc (n : ℕ) (f : Fin (n + 1) → ℝ) (u : ℝ) :
    StrictMono (Fin.snoc f u) ↔ StrictMono f ∧ f (Fin.last n) < u := by
  rw [Fin.strictMono_iff_lt_succ, Fin.forall_iff_castSucc]
  simp only [Fin.succ_castSucc, Fin.snoc_castSucc,
    Fin.snoc_last, Fin.succ_last]
  rw [← Fin.strictMono_iff_lt_succ, and_comm]

private theorem simplex_snoc (n : ℕ) (T : ℝ≥0) (t : Fin n → ℝ) (u : ℝ) :
    (StrictMono (Fin.cons (0 : ℝ) (Fin.snoc t u)) ∧
      ∀ i, (Fin.snoc t u : Fin (n+1) → ℝ) i < (T : ℝ)) ↔
    (StrictMono (Fin.cons (0 : ℝ) t) ∧ ∀ i, t i < (T : ℝ)) ∧
      (Fin.cons (0 : ℝ) t : Fin (n+1) → ℝ) (Fin.last n) < u ∧ u < (T : ℝ) := by
  rw [Fin.cons_snoc_eq_snoc_cons, strictMono_snoc]
  simp only [Fin.forall_iff_castSucc, Fin.snoc_castSucc, Fin.snoc_last]
  tauto

private theorem snoc_volume_preserving (n : ℕ) :
    MeasurePreserving (fun p : ℝ × (Fin n → ℝ) => Fin.snoc p.2 p.1)
      (volume.prod volume) (volume : Measure (Fin (n+1) → ℝ)) := by
  have h := (volume_preserving_piFinSuccAbove (fun _ : Fin (n+1) => ℝ) (Fin.last n)).symm
  change MeasurePreserving (fun p : ℝ × (Fin n → ℝ) =>
    @Fin.insertNth n (fun _ : Fin (n+1) => ℝ) (Fin.last n) p.1 p.2) (volume.prod volume) volume at h
  simpa only [Fin.insertNth_last'] using h

private def Δ (n : ℕ) (T : ℝ≥0) : Set (Fin n → ℝ) :=
  {t | StrictMono (Fin.cons (0 : ℝ) t) ∧ ∀ i, t i < (T : ℝ)}

private theorem simplex_lintegral_snoc (n : ℕ) (T : ℝ≥0)
    (hn : MeasurableSet (Δ n T)) (hs : MeasurableSet (Δ (n+1) T))
    (F : (Fin (n+1) → ℝ) → ℝ≥0∞) (hF : Measurable F) :
    (∫⁻ t in Δ (n+1) T, F t) =
      ∫⁻ t in Δ n T, ∫⁻ u in Set.Ioo
        ((Fin.cons (0 : ℝ) t : Fin (n+1) → ℝ) (Fin.last n)) (T : ℝ),
        F (Fin.snoc t u) := by
  let G : (Fin (n+1) → ℝ) → ℝ≥0∞ := (Δ (n+1) T).indicator F
  have hg : Measurable G := hF.indicator hs
  have hcomp := (snoc_volume_preserving n).lintegral_comp hg
  rw [lintegral_indicator hs] at hcomp
  rw [← hcomp]
  rw [lintegral_prod_symm (μ := volume) (ν := volume)
    (fun p : ℝ × (Fin n → ℝ) => G (Fin.snoc p.2 p.1))
    (hg.comp (snoc_volume_preserving n).measurable).aemeasurable]
  rw [← lintegral_indicator hn]
  apply lintegral_congr
  intro t
  by_cases ht : t ∈ Δ n T
  · rw [Set.indicator_of_mem ht, ← lintegral_indicator measurableSet_Ioo]
    apply lintegral_congr
    intro u
    have he : (Fin.snoc t u : Fin (n+1) → ℝ) ∈ Δ (n+1) T ↔
        ((Fin.cons (0 : ℝ) t : Fin (n+1) → ℝ) (Fin.last n) < u ∧ u < (T : ℝ)) := by
      change (StrictMono (Fin.cons (0 : ℝ) (Fin.snoc t u)) ∧
        ∀ i, (Fin.snoc t u : Fin (n+1) → ℝ) i < (T : ℝ)) ↔ _
      rw [simplex_snoc]
      exact and_iff_right ht
    simp only [G, Set.indicator_apply, he, Set.mem_Ioo]
  · rw [Set.indicator_of_notMem ht]
    have hz : ∀ u : ℝ, G (Fin.snoc t u) = 0 := by
      intro u
      apply Set.indicator_of_notMem
      intro h
      exact ht ((simplex_snoc n T t u).mp h).1
    simp only [hz, lintegral_zero]

end
end OrderedCoordinates92
