# Frozen raw-source interpretation

This is independent source-only groundwork for one bounded row-law producer and
its actual scalar consumer. It contains no proposed formal types, definitions,
interface, implementation, or theorem-completion claim. The root remains the sole
mathematical prover. Source topology and coverage are not independently approved
by this extractor.

The sole mathematical source is the pinned
`.astis/huanjian-resume-20261103/2610.20492v1.html`: 951991 UTF-8 bytes,
SHA-256 `6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915`.
All exact byte, character, line and raw-fragment hash locators are in
`locators.json`. The contiguous bounded inventory runs from the Appendix C.2
heading through the end of p11, source lines 3314–3569. Standing assumptions and
two later use-site paragraphs are separately recorded as context.

## Printed objects and probability meaning

Lemma 4.4 (`S4.Thmtheorem4`, lines 1207–1231) starts with independent vectors
`g_1,...,g_(q+1)` having law `N(0,I_d)`, with `q>=0` and `2q+1<d`. Section 2
specifies integer dimension and integer query-budget indexing; Lemma 4.3 also
explicitly calls `q` an integer. The Section 4 construction uses `d>=2`.
These are the source standing ranges, not a later concentration hypothesis.
The condition involving `tau_(d,q)<=1/2` belongs to Lemma 4.4's final uniform
bound and is not used to obtain a row marginal or this bad-row estimate.

C.2 p1 (lines 3317–3329) sets `r=q+1`, `n=2q+1` and, for `1<=i<=d`, defines

`gamma_i = ((g_1)_i,...,(g_r)_i)^T`.

These are the rows formed from the **same original columns**. There is no new
draw when defining a row. The accompanying deterministic cosine vector is
`t_i=(1,sqrt(2) cos theta_i,...,sqrt(2) cos(q theta_i))^T`. The matrix `B` has
`d` rows and `r^2` columns, with row `d^(-1/2)(gamma_i tensor t_i)^T`.
The cosine vector and tensor matrix are preserved source context; they are not
needed for the scalar probability-of-any-bad-row consumer.

P1 then explicitly states that `gamma_1,...,gamma_d` are independent
`N(0,I_r)`. The source prints this stronger **joint-row assertion** without a
coordinate-by-coordinate derivation. The narrower producer considered here is
only the marginal component: for every fixed original row `i`, the distribution
of `gamma_i` under the original column experiment is the canonical
`r`-dimensional standard Gaussian law. The full joint-row independence assertion
is a separate open/excluded proof boundary of this packet.

The source does not name a particular sample space. Its probability is the law
of the independent random columns on whatever underlying probability space
carries them. Equivalently at the level of distribution, the column tuple has
the product of `r` copies of `N(0,I_d)`. The canonical marginal law instead lives
on `R^r`; it is the image of the original experiment under the row map. For a
Borel subset `E` of `R^r`, the precise marginal statement is

`P_original(gamma_i in E) = N(0,I_r)(E)`.

It follows that the original-experiment expectation of a function of this row
can be computed using this canonical marginal whenever the integral is defined.
It does not identify an original random row pointwise with a newly drawn
canonical vector, does not replace all rows by one canonical sample, and does
not establish the joint law of the family from its marginals.

The omitted elementary marginal bridge is visible in the graph: a fixed
coordinate of a standard `d`-Gaussian is a standard scalar Gaussian;
independence of the columns survives their fixed coordinate projections; the
resulting `r`-tuple has law `N(0,I_r)`. That bridge uses column independence and
the standard-Gaussian law meaning. It does not need independence between rows.
No claim is made here that this bridge has been formally implemented.

## Exact cutoff consumer and constants

C.2 p10 (lines 3532–3556) defines

`R_i=||gamma_i||^2`, and `L=2r+3 log(1000d)`.

The norm is the Euclidean norm (Section 2). The threshold is for its **square**.
The source then prints the exact exponential moment

`E_original exp(R_i/3)=3^(r/2)`.

The standard Gaussian integral yielding this identity is not expanded in the
source. It can be understood as the canonical marginal integral of
`z -> exp(||z||^2/3)`, transported to the original row by its marginal law.
The source names Markov's inequality, and prints, for every real `x>=0`,

`P_original(R_i>2r+3x)
 <= exp((r/2) log 3 - 2r/3 - x)
 <= exp(-x)`.

The last step explicitly cites `(log 3)/2<2/3`. Here `log` has its natural
logarithm meaning, supported by the exponential cancellation in these displayed
formulas; no different base is compatible with that calculation.

The source then prints

`T={R_i<=L for every i}`,

and says its probability is at least `1-d/(1000d)=0.999`.
This **printed good-event consequence** is the preferred actual consumer anchor
(`A3.Ex105.m1`, `A3.SS2.p10.3`, `A3.SS2.p10.m6`).

The following fully explicit calculation is a **source-supported inference**,
not an additional printed display:

1. Set `x=log(1000d)>=0` in the single-row tail, obtaining, for each original
   row `i`, `P_original(R_i>L)<=1/(1000d)`.
2. The bad event is `there exists i in {1,...,d}: R_i>L`, the exact complement
   of `T`. A finite union bound gives
   `P_original(any bad row)<=sum_i P_original(R_i>L)<=d/(1000d)=0.001`.
3. Taking the complement gives the printed `P_original(T)>=0.999`.

Every probability in this calculation belongs to the **original column
experiment**. A canonical single-row estimate is sufficient only after it is
identified with each original row's marginal probability. The finite union
bound requires no independence of the bad events or of the rows. A formal
result stating only a canonical one-row probability, without the original-row
law identification, would leave the actual consumer disconnected.

The inequalities `R_i>L` and `R_i<=L` have complementary endpoints. No
zero-mass-boundary assumption or strict/non-strict conversion is needed. The
source constants are exactly `2`, `3`, `1000`, `1/(1000d)`, `0.001`, and `0.999`;
they are not the later matrix-concentration constants.

## Zero-query endpoint

The source permits integer `q=0`; then `r=1`, `n=1`, and `2q+1<d` gives
integer `d>=2`. The row is the one-dimensional vector `((g_1)_i)`, and its
canonical marginal is `N(0,I_1)`. The cosine vector is just `(1)`; any cosine
index range `1,...,q` is empty. The squared row norm is `(g_1)_i^2`, and

`L=2+3 log(1000d)`, `E exp(R_i/3)=sqrt(3)`.

The same original-row tail and finite union calculation apply. Neither `q>0`
nor `r>=2` is justified as an extra assumption. The source range does not admit
`r=0` or `d=0`, and this packet makes no off-source extension to them.

## Preserved neighboring regions and gaps

The inventory explicitly excludes C.2 p2–p9 and Facts C.5/C.6 from the narrow
producer's proof boundary. Their source text and all formula locators are
retained. In particular, p6 uses the row second moment to compute a Gram
expectation; that is a distinct consumer from the scalar tail/union consumer.
No tensor expectation, range identity, centering, variance, operator norm,
concentration, main theorem, oracle, or query-cost result is supplied here.

P11 (lines 3557–3569) is read and preserved as an excluded adjacent
continuation. It prints, for `s>=0`,

`P_original(R_i>L+s)<=exp(-s/3)/(1000d)`,

and

`E_original[R_i 1_{R_i>L}]
 = L P_original(R_i>L) + integral_0^infinity P_original(R_i>L+s) ds
 <= (L+3)/(1000d)`.

These use the same marginal row law, but the shifted tail and integrated bias
are separate mathematical obligations. No bias theorem is credited here.

Two later paragraphs were read only to identify use sites. P12 calls the
truncated matrices independent and computes their radial-symmetry expectation;
the full independence/centering/bias chain remains separate. P17 states that
the original and truncated sums agree on `T`, and combines failure probability
`0.001` for `T` with `0.004` for concentration to obtain `0.995`. That context
confirms the scalar event is used on the original experiment. It does not grant
any matrix or concentration result to this packet.

The graph preserves two explicit `SOURCE_GAP` nodes: the unexpanded standard-law
coordinate/marginal bridge, and the unexpanded Gaussian exponential-integral
calculation. These labels describe omissions in the printed argument, not a
claim of falsity or a proposed source repair. The cutoff substitution, finite
union bound and bad-event complement are labeled source-supported inferences.
The good-event bound itself is printed.

## Access and freeze boundary

Initial rg --files for AGENTS/SKILL unintentionally listed prior audit filenames
(names only, no contents opened); all subsequent reads are exact mandatory
instructions and pinned source only.

The precise access caveat and instruction digests are retained in
`access_manifest.json`. No previous SAU code, Lean lessons, audit content,
verdicts, decoder packets, current source-V reports, ledger, or ATLAS content
was read. No subagents, global writes, commits, permissions, or implementation
actions were taken. The raw interpretation, graph, exhaustive bounded
inventory, locators and access manifest are frozen together before any type or
implementation proposal; successor work must preserve this frozen evidence.
