from pathlib import Path
from collections import Counter
import hashlib,json
root=Path('/Users/zhouhuanjian/ASTIS-GC')
base=root/'.astis/huanjian-gc-fixed-spectrum-bias-20261110/independent-source-graph'
p1=base/'phase1';out=base/'phase2'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
load=lambda p:json.loads(p.read_text())
encode=lambda x:(json.dumps(x,indent=2,ensure_ascii=False)+'\n').encode()
canonical_sha=lambda x:hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()
assert sha(p1/'phase1-freeze.json')=='68309ef6d866f304eb8f1fcc333736033fac96da40aed870d9d1b09cc22d300b'
frozen=load(p1/'phase1-freeze.json')
for a in frozen['artifacts']:assert sha(root/a['path'])==a['sha256']
projection=root/'.astis/huanjian-gc-fixed-spectrum-bias-20261110/strict-preproof-seal-projection-v1.json'
assert sha(projection)=='b245ddf40403f7aca7d2f0be6de9953cf1fb2bda57e840d9ee6bf6156aac8511'
s=load(projection);assert s['seal_sha256']=='45e323a4f42c0061a6de06c791041cd5b9907e662e7b17753062745e43128760'
for role in ['producer','actual_private_consumer']:assert hashlib.sha256(s[role]['signature'].encode()).hexdigest()==s[role]['signature_sha256']
inv=load(p1/'raw-unit-inventory.json');history=load(p1/'raw-unit-dispositions.json')['rows'];byid={u['id']:u for u in inv['units']}
nodes=[];routes=[]
def node(i,kind,statement,anchors=(),role='source',note=None):
 nodes.append({'id':i,'kind':kind,'statement':statement,'role':role,'source_anchors':[{'id':a,'raw_unit_ordinal':byid[a]['raw_unit_ordinal'],'source_unit_key':byid[a]['source_unit_key'],'original_lines':byid[a]['original_lines'],'math':byid[a]['math'],'references':byid[a]['references'],'raw_html_sha256':byid[a]['raw_html_sha256']} for a in anchors],'status':'OPEN_INTERNAL_OBLIGATION' if kind in ['SOURCE_GAP','LOCAL_INTERNAL_OBLIGATION'] else 'SOURCE_OR_LOCAL_STATEMENT_NOT_CERTIFIED_PROVED','note':note})
def edge(i,target,inputs,sites,description,local=False):
 routes.append({'id':i,'consumer':target,'inputs':inputs,'logic':'AND','consumer_use_sites':[{'id':a,'raw_unit_ordinal':byid[a]['raw_unit_ordinal'],'original_lines':byid[a]['original_lines']} for a in sites],'use_site_relation':'Local exact zero-threshold statement; listed source sites supply mechanism provenance only.' if local else 'Actual author use site in pinned source.','description':description,'discharge':'Internal proof dependencies only. No result, integrability condition, callback, event bound or moment certificate becomes a new public premise.'})
# Standing domain and literal objects.
node('D_family','STANDING_PREMISE','d≥2 and κ≥2 in the fixed family.',('S4.SS1.p1.1','S4.Thmtheorem5.p1.1'))
node('D_mode','SOURCE_PREMISE','Natural representation of source integer mode: 1≤n<d.',('S4.Thmtheorem5.p1.1',))
node('D_gap','SOURCE_PREMISE','√κ≤(d:ℝ)−(n:ℝ); equality allowed, no rounding/truncated subtraction.',('S4.Thmtheorem5.p2.1','A3.SS3.p11.1'))
node('D_objects','SOURCE_DEFINITION','Euclidean norm; θ_i=(i−1/2)π/d; λ_i=(κ+1)/2+(κ−1)cosθ_i/2; Λ=diag λ; ρ=(√κ−1)/(√κ+1); D_n=diag cos(nθ_i).',('S2.p1.1','S4.E11','S4.Thmtheorem5.p1.1'))
node('D_actual','LITERAL_ACTUAL_LAW','μ=N(0,Λ⁻¹), Q(x)=Σ cos(nθ_i)x_i², M=∫‖x‖²dμ and b=∫Qdμ. The literal integral b is source μ_n.',('S4.Thmtheorem5.p1.1',))
node('G_covariance_domain','SOURCE_GAP','Derive d>0, √κ>1, 1≤λ_i≤κ, positive diagonal precision/inverse covariance and legitimate Gaussian covariance semantics.',('S4.E11','A3.SS3.p8.1'))
node('G_actual_probability','SOURCE_GAP','Certify the displayed actual Gaussian is a probability measure with covariance Λ⁻¹ and centered Gaussian coordinate marginals. No abstract law or PSD certificate as input.',('S4.Thmtheorem5.p1.1','A3.SS3.p8.1'))
node('G_actual_second_integrability','SOURCE_GAP','Actual coordinate second moments E U_i²=1/λ_i; coordinate squares and the two finite quadratic sums are measurable/integrable, so real Bochner integrals are actual expectations.',('A3.SS3.p4.1','A3.Ex140'))
node('G_finite_quadratic_means','SOURCE_GAP','Expand the actual Euclidean norm and diagonal quadratic, and commute finite sums with expectations using actual integrability.',('A3.Ex140',))
node('N_actual_mean_sums','SOURCE_IDENTITY','M=Σ_i1/λ_i and b=Σ_i cos(nθ_i)/λ_i.',('A3.Ex140',),note='Source/prior-mean prerequisite, not new mean-proof credit. No canonical Lean API or prior verification was inspected.')
node('G_rho_domain','SOURCE_GAP','From κ≥2 derive 0<ρ<1, all scalar/log denominators positive, 1−ρ^{2d}>0, and 1+ρ^{2d}>0.',('A3.SS3.p2.1','A3.SS3.p9.1','A3.SS3.p9.2'))
# Full author route for exact means, retained as source prerequisites rather than assumed formulas.
node('G_geometric_cosine','SOURCE_GAP','Geometric series for ±iθ and real/complex cosine identities; justify the two convergent geometric sums and algebraic ρ denominator identities.',('A3.SS3.p2.1','A3.EGx14','A3.Ex136'))
node('N_cosine_expansion','SOURCE_IDENTITY','Fact C.7: inverse spectrum=(1/√κ)(1+2Σ_{j≥1}(−ρ)^j cos(jθ)) for every real θ.',('A3.Thmtheorem7','A3.Ex133'))
node('N_absolute_uniform','SOURCE_ESTIMATE','Absolute and uniform convergence bounded by Σρ^j=ρ/(1−ρ).',('A3.Thmtheorem7.p1.2','A3.Ex137','A3.SS3.p2.4'))
node('G_grid_alias','SOURCE_GAP','Finite cosine sum identity for all integer k, including zero/special 2d multiples and the nonzero sine denominator case.',('A3.Ex139','A3.SS3.p3.2'))
node('G_series_grid_interchange','SOURCE_GAP','Apply absolute convergence to interchange the cosine series with the finite grid sum, preserving source mode/domain.',('A3.SS3.p4.2',))
node('N_exact_M','SOURCE_PREREQUISITE','M=(d/√κ)(1−ρ^{2d})/(1+ρ^{2d}); author keeps modes j=2ad and sums the geometric series.',('S4.EGx1','A3.Ex138','A3.SS3.p5.1','A3.EGx15'),note='Expanded source route is recorded, but reuse/existence of a canonical compiled declaration is not certified and earns no new mean credit.')
node('G_signed_alias_classes','SOURCE_GAP','Product-to-sum; surviving j=n,2ad+n,2ad−n; disjointness from 1≤n<d; coefficient parity and convergent geometric resummation.',('A3.SS3.p6.1','A3.Ex144','A3.SS3.p6.2','A3.EGx16'))
node('N_exact_b','SOURCE_PREREQUISITE','(−1)^n b=(d/√κ)(ρ^n−ρ^{2d−n})/(1+ρ^{2d}).',('S4.EGx1','A3.Ex138','A3.EGx16'),note='Actual-law C.8 mean prerequisite; no new canonical API or proof credit asserted.')
# Bias outputs and domain guards.
node('G_positive_M','SOURCE_GAP','The actual exact M is positive: d/√κ>0, 0<ρ<1 and d>0 imply positive numerator/denominator. No division-default positivity shortcut.',('A3.Ex138','A3.Ex150'))
node('N_positive_M','DERIVED_SOURCE_OUTPUT','0<M.',('A3.Ex138','A3.Ex150'))
node('G_signed_positive','SOURCE_GAP','Since n<d and 0<ρ<1, ρ^n>ρ^{2d−n}; use actual signed mean formula and positive prefactors.',('A3.SS3.p9.1',))
node('N_signed_positive','SOURCE_OUTPUT','0<(−1)^n b.',('A3.SS3.p9.1',))
node('G_ratio_domains','SOURCE_GAP','Convert signed positive b to |b|, divide the actual exact means using M>0, and justify power-factor/cancellation identities.',('A3.SS3.p9.1','A3.Ex150'))
node('N_ratio','SOURCE_IDENTITY','β=|b|/M=ρ^n(1−ρ^{2(d−n)})/(1−ρ^{2d}). Ratio of means, not expected ratio.',('A3.Ex150',))
node('N_correction_lower','SOURCE_ESTIMATE','1−ρ^{2(d−n)}≤(1−ρ^{2(d−n)})/(1−ρ^{2d}).',('A3.SS3.p9.2','A3.Ex151'))
node('N_correction_upper','SOURCE_ESTIMATE','(1−ρ^{2(d−n)})/(1−ρ^{2d})≤1.',('A3.SS3.p9.2','A3.Ex151'))
node('G_log_integral_domains','SOURCE_GAP','0<1/√κ<1; continuous integrands on [0,1/√κ], denominators bounded away from zero; prove log-ratio integral using the fundamental theorem, plus elementary split/integral evaluation.',('A3.Ex152','A3.Ex153','A3.Ex154','A3.Ex155','A3.Ex156'))
node('N_log_integral','SOURCE_IDENTITY','log(1/ρ)=log((√κ+1)/(√κ−1))=2∫₀^{1/√κ}(1−t²)⁻¹dt=2/√κ+2∫₀^{1/√κ}t²/(1−t²)dt.',('A3.SS3.p10.1','A3.Ex152','A3.Ex153','A3.Ex154'))
node('N_log_lower','SOURCE_ESTIMATE','2/√κ≤log(1/ρ), from nonnegative remainder integral.',('A3.SS3.p10.2',))
node('N_log_upper','SOURCE_ESTIMATE','log(1/ρ)≤(2/√κ)(1+1/[3(κ−1)])≤8/(3√κ)<3/√κ using κ≥2.',('A3.Ex155','A3.Ex156','A3.SS3.p10.3'))
node('G_power_log_exp','SOURCE_GAP','Relate ρ^k to exp(−k log(1/ρ)); positivity and order reversal on multiplying by nonnegative source modes; real casts of natural powers/differences.',('A3.Ex157','A3.Ex158'))
node('N_power_lower','SOURCE_ESTIMATE','exp(−3n/√κ)≤ρ^n.',('A3.Ex157',))
node('N_power_upper','SOURCE_ESTIMATE','ρ^n≤exp(−2n/√κ).',('A3.Ex157',))
node('N_tail_factor','SOURCE_ESTIMATE','Under √κ≤d−n, ρ^{2(d−n)}≤exp(−4(d−n)/√κ)≤exp(−4).',('A3.SS3.p11.1','A3.Ex158'))
node('N_bias_lower','SOURCE_OUTPUT','(1−exp(−4))exp(−3n/√κ)≤|b|/M, with exact constants.',('S4.Ex17','A3.SS3.p11.2','A3.Ex159'))
node('N_bias_upper','SOURCE_OUTPUT','|b|/M≤exp(−2n/√κ). This proof branch needs no extra gap, although the sealed four-output theorem includes the source gap for its lower branch.',('S4.Ex17','A3.Ex159'))
node('P_root','EXACT_PRODUCER_ROOT','All four outputs: M>0; (−1)^n b>0; exact lower exponential bias; exact upper exponential bias.',('S4.Thmtheorem5','S4.Thmtheorem5.p2.1','S4.Ex17','A3.SS3.p9.1','A3.Ex159'),role='exact-producer')
# Actual Q variance prerequisites for the new zero-threshold consumer; no whole-norm variance branch.
node('G_fourth','SOURCE_GAP','For actual centered Gaussian coordinates E U_i⁴=3/λ_i², including finite fourth moment and measurable coordinate squares.',('A3.SS3.p8.1',))
node('G_independence','SOURCE_GAP','Diagonal actual Gaussian gives independent coordinates, and measurable squaring preserves that independence.',('A3.SS3.p8.1','A3.Ex149'))
node('G_weighted_L2','SOURCE_GAP','Finite cosine-weighted sum of actual coordinate squares is in L²; this is an internally produced actual-law fact.',('A3.SS3.p8.1','A3.Ex149'))
node('N_Q_L2','SOURCE_IMPLICIT_ANALYTIC_PREREQUISITE','Actual MemLp Q 2 μ.',('A3.SS3.p8.1','A3.Ex149'),note='Source-backed prior-variance prerequisite. The whitelist claim of earlier verification is not independently certified here.')
node('G_finite_Q_variance','SOURCE_GAP','From Q L² under actual probability derive integrability, finite evariance and real variance as finite centered square integral. Do not exploit toReal(∞)=0.',('A3.Ex149','S4.Ex26'))
node('G_weighted_variance','SOURCE_GAP','Var(U_i²)=2/λ_i² from actual second/fourth moments; finite independent weighted-sum variance has squared coefficients.',('A3.SS3.p8.1','A3.Ex149'))
node('N_Q_exact_variance','SOURCE_PREREQUISITE','Var Q=2Σ_i cos²(nθ_i)/λ_i².',('A3.Ex149',))
node('N_Q_variance_2M','SOURCE_PREREQUISITE','Var Q≤2M via λ_i≥1, cos²≤1 and actual M=Σ1/λ_i.',('A3.Ex149','S4.Thmtheorem5.p1.2'),note='Actual variance prerequisite, not a hypothesis and not the full source contrast 8M result.')
# Local actual event/application, explicitly not author zero-threshold result.
node('C_zero_event','LOCAL_NUMERICAL_DEFINITION','F(x)=(−1)^n Q(x); E₀={x:F(x)≤0}; actual μ(E₀).toReal. No τ parameter is set to zero in a source theorem.',('S4.Ex18','S4.Ex26'),role='private-non-anchor',note='Source sites provide signed-quadratic/Chebyshev provenance only; their actual nonzero-τ event differs.')
node('G_sign_centered','LOCAL_INTERNAL_OBLIGATION','|(−1)^n|=1; expectation scales, F is actual L², evariance finite and Var F=Var Q≤2M.',('S4.SS3.SSS0.Px2.p3.1','S4.Ex26'),role='private-non-anchor')
node('N_signed_actual_mean','LOCAL_NUMERICAL_IDENTITY','m=∫F dμ=(−1)^n b=|b|>0, using the actual signed-positive producer output.',('A3.SS3.p9.1','S4.SS3.SSS0.Px2.p3.1'),role='private-non-anchor')
node('G_event_probability','LOCAL_INTERNAL_OBLIGATION','Q and F are measurable finite polynomials; E₀ is measurable; actual Gaussian probability makes μ(E₀)≤1 finite before ENNReal.toReal.',('S4.Ex26',),role='private-non-anchor')
node('G_positive_factor','LOCAL_INTERNAL_OBLIGATION','c=1−exp(−4)>0; exp(−3n/√κ)>0; M>0 and all Chebyshev/cancellation denominators are strictly positive.',('A3.Ex159','S4.Ex26'),role='private-non-anchor')
node('N_signed_mean_lower','LOCAL_NUMERICAL_ESTIMATE','m≥c exp(−3n/√κ) M>0, materially using the new lower bias output and actual M.',('A3.Ex159','S4.Ex26'),role='private-non-anchor')
node('G_Chebyshev','SOURCE_GAP','Actual finite centered second-moment Chebyshev inequality at a positive mean; source names this theorem but does not expand it.',('S4.SS3.SSS0.Px2.p3.2','S4.Ex26'))
node('N_zero_event_Chebyshev','LOCAL_NUMERICAL_ESTIMATE','{F≤0}⊆{|F−m|≥m}; μ(E₀).toReal≤Var F/m²≤2M/m², with actual event, actual Q L²/variance and positive m.',('S4.Ex26',),role='private-non-anchor')
node('G_probability_constant','LOCAL_INTERNAL_OBLIGATION','Use m≥c exp(−3n/√κ)M>0 to bound 2M/m²≤2 exp(6n/√κ)/(c² M). Prove reciprocal-square/exp algebra with positive M and c; exact 2 and 6 are local derived constants.',('A3.Ex159','S4.Ex26'),role='private-non-anchor')
node('C_root','EXACT_PRIVATE_CONSUMER_ROOT','μ{x:(−1)^n Q(x)≤0}.toReal≤2 exp(6n/√κ)/((1−exp(−4))² M).',('S4.Ex26',),role='private-non-anchor',note='Not a quoted source bound, not full Ex26, and no .9 good-event, rotated law, algorithm, query or TV result.')
# Related original source consumer conditions remain context, outside exact target closures.
node('S_original_contrast','SOURCE_CONTEXT_ONLY','Original n=2q+1, τ=τ_dq, S_A=signed rotated Chebyshev quadratic−2τ‖x‖². Full Ex25 also gives positive contrast mean under τ≤β/4 and contrast variance≤8M under τ≤1/2.',('S4.SS3.p3.1','S4.Ex18','S4.SS3.SSS0.Px2.p2.3','S4.Ex25'),role='context-only')
node('S_original_probability','SOURCE_CONTEXT_ONLY','Original Ex26 uses Mβ²≥320 for π_A(E_A)≥0.9 after actual rotated law/contrast; it is not the new E₀ bound.',('S4.SS3.SSS0.Px2.p2.3','S4.Ex26'),role='context-only')
# Author-route edges, each with its actual consumer use-site.
edge('r_covariance','G_covariance_domain',['D_family','D_objects'],['A3.SS3.p8.1'],'Positivity/inverse guards from the literal family.')
edge('r_actualprob','G_actual_probability',['D_actual','G_covariance_domain'],['A3.SS3.p4.1','A3.SS3.p8.1'],'Certify actual probability/covariance, never assume a replacement law.')
edge('r_second','G_actual_second_integrability',['G_actual_probability'],['A3.SS3.p4.1'],'Actual Gaussian finite second moments.')
edge('r_quadmean','G_finite_quadratic_means',['D_actual','D_objects','G_actual_second_integrability'],['A3.Ex140'],'Finite sums and integrability.')
edge('r_meansums','N_actual_mean_sums',['G_finite_quadratic_means'],['A3.SS3.p4.2'],'These sums are what C.7 expands.')
edge('r_rhodomain','G_rho_domain',['D_family','D_objects'],['A3.SS3.p2.1','A3.SS3.p9.1'],'Real square root/log/power denominator domain.')
edge('r_geometric','G_geometric_cosine',['G_rho_domain'],['A3.EGx14','A3.Ex136'],'Source geometric-series proof and denominator algebra.')
edge('r_expansion','N_cosine_expansion',['G_geometric_cosine'],['A3.SS3.p4.2'],'Fact C.7 inverse-spectrum identity.')
edge('r_uniform','N_absolute_uniform',['G_rho_domain'],['A3.Ex137','A3.SS3.p4.2'],'Geometric majorant justifies absolute/uniform convergence.')
edge('r_grid','G_grid_alias',['D_family','D_objects'],['A3.SS3.p5.1','A3.SS3.p6.2'],'Finite grid aliasing used in both exact means.')
edge('r_interchange','G_series_grid_interchange',['N_cosine_expansion','N_absolute_uniform','N_actual_mean_sums'],['A3.SS3.p4.2'],'Source explicitly authorizes interchange.')
edge('r_exactM','N_exact_M',['G_series_grid_interchange','G_grid_alias','G_rho_domain'],['A3.SS3.p9.1','A3.Ex150'],'Keep j=2ad and sum the mean norm series; actual source mean prerequisite.')
edge('r_bclasses','G_signed_alias_classes',['G_series_grid_interchange','G_grid_alias','D_mode','G_rho_domain'],['A3.Ex144','A3.SS3.p6.2'],'Product-to-sum and three disjoint alias classes.')
edge('r_exactb','N_exact_b',['G_signed_alias_classes'],['A3.SS3.p9.1','A3.Ex150'],'Actual signed mean formula.')
edge('r_Mpositiveguard','G_positive_M',['N_exact_M','G_rho_domain','G_covariance_domain'],['A3.Ex150'],'Positive actual denominator, not totalized division default.')
edge('r_Mpositive','N_positive_M',['G_positive_M'],['A3.Ex150'],'Produce first exact target output.')
edge('r_signedpositiveguard','G_signed_positive',['N_exact_b','D_mode','G_rho_domain','G_covariance_domain'],['A3.SS3.p9.1'],'Source power-order strict positivity.')
edge('r_signedpositive','N_signed_positive',['G_signed_positive'],['A3.Ex150'],'Produce second exact target output.')
edge('r_ratioguards','G_ratio_domains',['N_exact_M','N_exact_b','N_positive_M','N_signed_positive','G_rho_domain','D_mode'],['A3.Ex150'],'Actual ratio and absolute/sign cancellation.')
edge('r_ratio','N_ratio',['G_ratio_domains'],['A3.Ex151','A3.SS3.p11.2'],'Exact normalized actual bias.')
edge('r_correctionlower','N_correction_lower',['G_rho_domain','D_mode'],['A3.SS3.p11.2'],'Positive denominator at most 1; lower correction factor needs no tail-gap condition.')
edge('r_correctionupper','N_correction_upper',['G_rho_domain','D_mode'],['A3.SS3.p11.2'],'Exponent order gives correction≤1 without gap.')
edge('r_logintegralguard','G_log_integral_domains',['G_rho_domain','D_family'],['A3.Ex152','A3.Ex153','A3.Ex154','A3.Ex155'],'Actual nonsingular compact integration interval.')
edge('r_logintegral','N_log_integral',['G_log_integral_domains'],['A3.SS3.p10.2'],'Fundamental theorem and split remainder.')
edge('r_loglower','N_log_lower',['N_log_integral'],['A3.Ex157','A3.Ex158'],'Nonnegative remainder; used separately for upper power and tail.')
edge('r_logupper','N_log_upper',['N_log_integral','D_family'],['A3.Ex157'],'Bound denominator by 1−κ⁻¹; integrate t²; exact κ≥2 constants.')
edge('r_poweridentities','G_power_log_exp',['G_rho_domain','D_mode'],['A3.Ex157','A3.Ex158'],'Correct exponent signs and real casts.')
edge('r_powerlower','N_power_lower',['G_power_log_exp','N_log_upper'],['A3.SS3.p11.2'],'The 3 constant gives the lower power bound.')
edge('r_powerupper','N_power_upper',['G_power_log_exp','N_log_lower'],['A3.SS3.p11.2'],'The 2 constant gives the upper power bound.')
edge('r_tail','N_tail_factor',['G_power_log_exp','N_log_lower','D_gap'],['A3.SS3.p11.2'],'Tail≤exp(−4) uses exactly the extra spacing premise.')
edge('r_biaslower','N_bias_lower',['N_ratio','N_correction_lower','N_power_lower','N_tail_factor','G_rho_domain'],['A3.Ex159','S4.Ex17'],'One conjunctive author route; exact (1−exp(−4)),3 retained.')
edge('r_biasupper','N_bias_upper',['N_ratio','N_correction_upper','N_power_upper'],['A3.Ex159','S4.Ex17'],'Upper branch independent of D_gap; exact 2 retained.')
edge('r_producer','P_root',['N_positive_M','N_signed_positive','N_bias_lower','N_bias_upper'],['S4.Ex17','A3.Ex159'],'All four exact producer outputs, not merely the final pair.')
# Prior actual Q variance source route, kept separate from normalized-bias algebra.
edge('r_fourth','G_fourth',['G_actual_probability'],['A3.SS3.p8.1'],'Actual fourth moments, not free certificates.')
edge('r_independence','G_independence',['G_actual_probability','D_objects'],['A3.Ex149'],'Independence of actual diagonal coordinates and squares.')
edge('r_weightedL2','G_weighted_L2',['G_fourth','D_actual','D_objects'],['A3.Ex149'],'Finite weighted polynomial sum of coordinate squares.')
edge('r_QL2','N_Q_L2',['G_weighted_L2'],['A3.Ex149','S4.Ex26'],'Actual Q L² output of source variance prerequisite.')
edge('r_finiteQ','G_finite_Q_variance',['N_Q_L2','G_actual_probability'],['A3.Ex149','S4.Ex26'],'Actual finite evariance before real variance.')
edge('r_weightedvar','G_weighted_variance',['G_fourth','G_actual_second_integrability','G_independence','G_finite_Q_variance'],['A3.Ex149'],'Actual scalar square variance and independent weighted sum.')
edge('r_Qexact','N_Q_exact_variance',['G_weighted_variance'],['A3.Ex149'],'Exact cosine-squared coefficient sum.')
edge('r_Qbound','N_Q_variance_2M',['N_Q_exact_variance','N_actual_mean_sums','G_covariance_domain','D_objects'],['S4.SS3.SSS0.Px2.p3.1','S4.Ex26'],'cos²≤1 and λ≥1; use actual M sum, not closed M upper.')
# New private actual event route, not a second proof of the author's different event.
edge('r_signcentered','G_sign_centered',['C_zero_event','N_Q_L2','N_Q_variance_2M','G_finite_Q_variance'],['S4.Ex26'],'Actual sign scaling and centered second moments; all integer source modes.',True)
edge('r_signedmean','N_signed_actual_mean',['C_zero_event','G_actual_second_integrability','N_signed_positive'],['S4.Ex26'],'Actual expectation equals signed b and positive sign converts it to |b|.',True)
edge('r_eventprob','G_event_probability',['C_zero_event','G_actual_probability','D_actual'],['S4.Ex26'],'Actual measurable event and finite probability conversion.',True)
edge('r_positivefactor','G_positive_factor',['N_positive_M'],['A3.Ex159','S4.Ex26'],'Derive 1−exp(−4)>0 and positivity of all exponentials; no extra binder.',True)
edge('r_meanlower','N_signed_mean_lower',['N_bias_lower','N_positive_M','N_signed_actual_mean','G_positive_factor'],['S4.Ex26'],'Material use of new lower exponential bias, not the upper output.',True)
edge('r_cheb','G_Chebyshev',['G_sign_centered','G_event_probability'],['S4.SS3.SSS0.Px2.p3.2','S4.Ex26'],'Finite actual centered second moment and actual event semantics.',True)
edge('r_zerocheb','N_zero_event_Chebyshev',['G_Chebyshev','N_signed_actual_mean','G_sign_centered','G_event_probability'],['S4.Ex26'],'Apply at m>0 to zero-sublevel inclusion; use VarF≤2M.',True)
edge('r_probabilityalgebra','G_probability_constant',['N_zero_event_Chebyshev','N_signed_mean_lower','G_positive_factor','N_positive_M'],['S4.Ex26'],'Positive reciprocal-square arithmetic; exact local factor 2 and exponent 6.',True)
edge('r_consumer','C_root',['G_probability_constant'],['S4.Ex26'],'Exact private event bound only.',True)
# Structural checks: genuine source/local AND routes only, no manufactured OR alternatives.
ids={n['id'] for n in nodes};assert len(ids)==len(nodes)
assert all(e['consumer'] in ids and all(x in ids for x in e['inputs']) for e in routes)
byconsumer={}
for e in routes:byconsumer.setdefault(e['consumer'],[]).append(e)
def closure(target):
 seen=set();active=set();used=set()
 def walk(k):
  assert k not in active,'cycle '+k
  if k in seen:return
  active.add(k)
  for e in byconsumer.get(k,[]):
   used.add(e['id'])
   for v in e['inputs']:walk(v)
  active.remove(k);seen.add(k)
 walk(target)
 return {'root':target,'nodes':sorted(seen),'routes':sorted(used),'internal_source_gap_obligations':sorted(n['id'] for n in nodes if n['id'] in seen and n['kind']=='SOURCE_GAP'),'local_internal_obligations':sorted(n['id'] for n in nodes if n['id'] in seen and n['kind']=='LOCAL_INTERNAL_OBLIGATION'),'explicit_source_premise_nodes':sorted(n['id'] for n in nodes if n['id'] in seen and n['kind'] in ['STANDING_PREMISE','SOURCE_PREMISE']),'source_prerequisite_credit':'Exact actual means and Q variance/L² are source-backed prerequisites. Their author routes are expanded here, but no prior compiler/verification claim or new proof credit is certified.'}
closures={'producer_all_outputs':closure('P_root'),'private_actual_consumer':closure('C_root')}
assert all(x in closures['producer_all_outputs']['nodes'] for x in ['N_positive_M','N_signed_positive','N_bias_lower','N_bias_upper'])
assert all(x in closures['private_actual_consumer']['nodes'] for x in ['N_positive_M','N_signed_positive','N_bias_lower','N_Q_L2','N_Q_variance_2M'])
assert all(x not in closures['private_actual_consumer']['nodes'] for x in ['N_bias_upper','N_power_upper','P_root','S_original_contrast','S_original_probability'])
# All 366 frozen source rows retain full fields/history and one precise successor.
selected={}
for n in nodes:
 for a in n['source_anchors']:selected.setdefault(a['raw_unit_ordinal'],[]).append(n['id'])
fragments={
'S4.Thmtheorem5':{'included':'Actual source domain/definitions, exact means as prior source prerequisites, signed positivity and conditional normalized-bias pair.','excluded':'New proof credit for full Lemma4.5 or all of its variance outputs.'},
'S4.Thmtheorem5.p1.1':{'included':'Actual diagonal Gaussian/Q/M/source μ_n=b, ρ and mode definitions.','excluded':'No free-law or free-mean premises accepted.'},
'S4.Thmtheorem5.p1.2':{'included':'Actual Q variance≤2M as private-consumer prerequisite.','excluded':'Norm variance and closed M upper outputs, unnecessary to these exact targets.'},
'S4.EGx1':{'included':'Both actual C8 mean formulas as source prerequisites for normalized bias.','excluded':'No new mean-proof credit or API verification.'},
'A3.Ex138':{'included':'Both exact actual means as source prerequisites; positivity and ratio use them.','excluded':'No prior compiler-certification inferred.'},
'A3.SS3.p8.1':{'included':'Actual Gaussian fourth moments, squared independence, λ≥1 and finite Q-L²/variance prerequisites.','excluded':'A public moment/independence/L² assumption and the norm-variance conclusion.'},
'S4.SS3.SSS0.Px2.p3.1':{'included':'Signed actual mean and centered-moment/Chebyshev provenance for local event route.','excluded':'Full fixed-A rotated-law application, norm-contrast computation and source .9 probability.'},
'S4.Ex18':{'included':'Signed-quadratic structure as source provenance, plus explicit original nonzero-τ contrast context.','excluded':'An identification of source τ_dq with zero or of source S_A with new F.'},
'S4.Ex25':{'included':'Original contrast mean/variance as context boundary only.','excluded':'Claim that private zero-threshold bound is the original Ex25 statement or uses its 8M constant.'},
'S4.Ex26':{'included':'Named Chebyshev mechanism and original .9 application as context; private route explicitly tagged local.','excluded':'Claim of a quoted zero-threshold source constant or full Ex26/rotated/main theorem.'},
'S4.SS3.SSS0.Px2.p2.3':{'included':'Original τ/β and 320 threshold conditions as context boundary only.','excluded':'Requiring or proving these source probability-application conditions for the private zero-threshold theorem.'}}
def reason(u):
 k=u['kind'];a,b=u['original_lines'];ident=u['id']
 if k in ['section-context','heading','proof-block','paragraph-container']:return 'Structural wrapper/heading; substantive descendant source units have independent successors. Full raw context remains preserved.'
 if k=='paragraph' and u['text_with_tex'].strip()=='∎':return 'Proof-end marker only. In particular A3.SS3.p11.3 is listed by the projection as an anchor but contains no mathematical formula; the actual final estimate is A3.Ex159.'
 if k=='tbody':return 'Raw formula row retained with original ID, ordinal, source key, math and true parent display '+str(u['containing_display_id'])+'; its mathematics is duplicated by the separately selected containing display or outside these exact roots. Explicit raw NODE→EXCLUDED successor carries no deletion.'
 if k=='internal-reference':return 'Reference use-site/href retained in raw fields and its selected or explicitly excluded containing source region; not a separate exact-target mathematical obligation.'
 if k=='external-citation' or u['scope'].startswith('cited-bibliography'):return 'Historical family/Krylov provenance [22], outside the exact normalized-bias and local zero-threshold roots. C.3 bias proof cites no external bibliography result.'
 if ident=='A3.Ex148':return 'Actual norm-square variance row is not needed: private F is signed Q only, without the source −2τ‖x‖² contrast. Actual Q variance/L² remain selected; original raw norm row is preserved.'
 if ident=='A3.SS3.p8.2':return 'Closed norm-mean upper M≤d/√κ is unnecessary to normalized bias or private zero-threshold Chebyshev bound, whose denominator is the actual positive M.'
 if u['scope']=='section2-complete':return 'Oracle/randomized-algorithm/TV/query-complexity context is not a theorem target or premise of these actual Gaussian scalar/probability roots. Literal Euclidean convention is separately selected.'
 if 1501<=a<=1600:return 'Full limitations/Krylov-dimension/accuracy-obstruction discussion lies outside these exact roots; phase1 cognition and original references preserve the broader author context.'
 if 1373<=a<=1456:return 'Original q/κ/δ uniform asymptotic, β/M growth and d0 selection are not needed by the private zero-threshold result. Selected original-condition context does not claim their proof.'
 if 1479<=a<=1500:return 'Averaged algorithm-vs-target TV contradiction and main query bound are outside both exact targets.'
 if 1128<=a<=1254:return 'Krylov representation/uniform algorithmic cosine event is outside the actual target bias and zero-threshold roots; source positive-mode definition is separately selected.'
 if 1302<=a<=1342:return 'Admissibility and main theorem algorithm budget/TV setup is outside the exact targets; separately selected n/τ source context is not a new target premise.'
 if 1054<=a<=1127:return 'Main lower-bound statement, known-spectrum remarks or Haar-rotation setup is outside the exact diagonal roots; standing grid/domain is separately selected.'
 if ident=='S4.SS2.SSS0.Px3.p2.1':return 'Actual Y-to-U orthogonal transport is outside the literal diagonal theorems. A later full source application must prove it internally, never add a callback premise.'
 return 'Substantive raw source context outside the selected normalized-bias/prior-moment/local-event components, or a duplicated aggregate captured by exact selected formula units; no silent full-section obligation is imposed.'
# Prefer named integral rows rather than treating the two aggregate equation groups as independent proof obligations.
exclude_override={'A3.EGx18':'Aggregate log-integral display. Exact mathematical rows A3.Ex152/A3.Ex153/A3.Ex154 are separate NODEs; original aggregate and all formulas remain preserved.','A3.EGx19':'Aggregate log-upper display. Exact mathematical rows A3.Ex155/A3.Ex156 are separate NODEs; original aggregate and all formulas remain preserved.'}
rows=[]
for j,(u,h) in enumerate(zip(inv['units'],history)):
 assert u['raw_unit_ordinal']==h['raw_unit_ordinal']==j
 keep=j in selected and u['id'] not in exclude_override
 succ={'disposition':'NODE' if keep else 'EXCLUDED','graph_nodes':selected.get(j,[]) if keep else [],'reason':None if keep else exclude_override.get(u['id'],reason(u)),'target_fragment':fragments.get(u['id']),'history_change':h['disposition']+' -> '+('NODE' if keep else 'EXCLUDED')}
 rows.append({'raw_unit_ordinal':j,'raw_source_unit':u,'phase1_disposition':h,'exact_target_successor':succ})
assert len(rows)==366 and len({r['raw_source_unit']['source_unit_key'] for r in rows})==366
# Exact binder and definition audit. Private scope is challenged independently, not inferred from names.
public_binders=[{'binder':'d : Nat','class':'TYPING'},{'binder':'hd : 2≤d','class':'STANDING'},{'binder':'κ : Real','class':'TYPING'},{'binder':'hκ : 2≤κ','class':'SOURCE'},{'binder':'n : Nat','class':'TYPING'},{'binder':'hn : 1≤n','class':'SOURCE'},{'binder':'hnd : n<d','class':'SOURCE'},{'binder':'hgap : √κ≤(d:Real)−(n:Real)','class':'SOURCE'}]
audit={'schema':1,'status':'PROPOSED_INDEPENDENT_SOURCE_EXTRACTOR_ASSESSMENT_PENDING_DISTINCT_CHALLENGE','projection':{'path':str(projection.relative_to(root)),'sha256':sha(projection),'full_seal_sha256_unread':s['seal_sha256']},'producer':{'name':s['producer']['name'],'exact_signature':s['producer']['signature'],'signature_sha256':s['producer']['signature_sha256'],'expanded_binder_count':8,'binder_audit':public_binders,'binder_assessment':'No EXCESS public binder found in this exact projection. The source includes κ≥2,1≤n<d and the closed gap √κ≤d−n; d≥2 is standing family. Projection audit compresses hn/hnd into one row; they remain two explicit logical binders here.','all_output_assessment':['M>0 is source-implicit from actual exact mean/positive domain and must be proved.','Signed mean>0 is expressly derived in A3.SS3.p9.1.','Lower bias retains exact1−exp(−4),3 and the source closed gap.','Upper bias retains exact2; its minimal source subbranch does not need the gap, but the sealed combined theorem legitimately retains the gap for the lower branch.'],'status':'SOURCE_ALIGNED_CANDIDATE_NOT_PROVED_OR_SELF_APPROVED'},'private_consumer':{'name':s['actual_private_consumer']['name'],'exact_signature':s['actual_private_consumer']['signature'],'signature_sha256':s['actual_private_consumer']['signature_sha256'],'is_source_anchor':False,'role':'Private actual-law numerical specialization of a source Chebyshev mechanism','new_assumed_private_numeric_premises':[],'domain_assessment':'Same actual family/mode/gap domain as producer; no free moment, law, mean, variance, L², independence, denominator-positivity or good-event certificate inputs. Reused SOURCE/STANDING provenance of shared domain does not turn this local event theorem into a source Anchor.','independent_source_relation':'The source uses Z=S_A(Y)=signed rotated Q−2τ_dq‖Y‖² with nonzero concrete τ and variance8M, then obtains a .9 good-event probability after a320 threshold. The private theorem instead bounds the actual signed-Q zero sublevel under diagonal μ, with variance2M. This is a legitimate separately identified numerical consequence of the bias and Q-variance ingredients, not the same event and not a source-quoted constant.','constant_assessment':'Positive actual signed mean m≥(1−exp(−4))exp(−3n/√κ)M, actual VarQ≤2M and Chebyshev give local factor2 and exponent6. Positivity and reciprocal-square/exp algebra remain internal obligations; neither number is accepted just because the projection quotes it.','strict_event_assessment':'Event is exactly {signed Q≤0}; its complement is signed Q>0. Chebyshev uses the positive mean m, so {F≤0} lies inside {|F−m|≥m}. No boundary atom or changed inequality convention is silently assumed.','toReal_assessment':'Actual μ is a probability measure; event measurable and finite must be proved before probability toReal conversion. toReal(∞)=0 cannot certify this theorem.','minimal_new_producer_outputs':['N_positive_M','N_signed_positive','N_bias_lower'],'unused_producer_output':'N_bias_upper is not mathematically needed by this private application.','existing_actual_prerequisites':['Q L² under the same literal Gaussian','VarQ≤2M with actual finite variance','Actual Gaussian probability/covariance and integrability'],'not_needed':['Norm variance or full norm-contrast8M result','Closed M upper/lower in d, growth Mβ²≥320 or .9 probability','τ_dq=0, arbitrary-τ domain binder, q/δ/TV regime or n=2q+1','Rotated-target callback or a full source-application result'],'implementation_use_status':'No implementation/API inspected. Later proof review must confirm material lower-bias and actual Q-L²/2M variance use; invocation/counting alone is insufficient.','status':'COHERENT_NON_ANCHOR_NUMERICAL_SCOPE_PENDING_DISTINCT_REVIEW_AND_PROOF'},'literal_definition_audit':{'index':'Fin index j equals source i=j.val+1, so i−1/2=j.val+1/2.','law':'Actual inverse-precision Gaussian on finite Euclidean space. Positive diagonal covariance/inverse semantics must be established internally; totalized inverse/sqrt behavior is not a surrogate.','moments':'M and b are actual finite integrals after internal integrability proofs; not free values or nonintegrable-default stand-ins.','ratio':'M>0 is produced before division and sign/absolute conversion; β is ratio of means, not expectation of a pointwise ratio.','gap':'Real subtraction of natural casts exactly matches d−n; closed equality allowed. No added integer ceiling/floor/truncated-subtraction premise.','constants':'Ordinary exp; derive1−exp(−4)>0. All exponents/divisions retain original constants3,2 and signs.','event':'Actual diagonal signed-Q closed sublevel, no source τ=0 assertion and no invented off-source ratio semantics.'},'open_internal_guards':['Actual covariance/probability and finite actual moments','Mean/source identities, denominator/log/integral/power domains','Q L² and finite centered variance','Event measurability/finiteness and positive Chebyshev mean','Positive factor and exact local probability-constant algebra'],'no_completion_claim':'This assessment is not a proof, compiled-dependency graph, independent source-coverage approval or VERIFIED transition.'}
outputs={}
outputs['statement-projection-audit.json']=encode(audit)
audit_sha=hashlib.sha256(outputs['statement-projection-audit.json']).hexdigest()
graph={'schema':1,'status':'SOURCE_FIRST_GRAPH_PROPOSED_WITH_OPEN_OBLIGATIONS','source_sha256':inv['source_sha256'],'projection_sha256':sha(projection),'statement_audit_sha256':audit_sha,'phase1_freeze_sha256':sha(p1/'phase1-freeze.json'),'nodes':nodes,'routes':routes,'OR_routes':[],'logic_note':'No alternative author proof appears for the selected bias clauses. Source scalar route, actual Q-variance prerequisite and distinct private zero-event application remain separate. The private event is not an alternative proof of the source nonzero-τ probability claim.','prior_result_credit':'Exact actual mean and actual Q-variance/L² author routes are explicit prerequisites, not newly proved API claims. The whitelist assertion of prior verification was not used as a proof certificate.','independence':'Only this new exact projection and own frozen raw source/cognition were used. Prior related source/Variances exposure is disclosed in phase1; no new other-agent, Lean/API/Mathlib/proof/lesson/reviewer artifact read.','no_self_acceptance':True}
outputs['source-proof-graph.json']=encode(graph);graph_sha=hashlib.sha256(outputs['source-proof-graph.json']).hexdigest()
coverage={'schema':1,'status':'EXACT_TARGET_SUCCESSORS_PENDING_DISTINCT_RAW_SOURCE_REVIEW','source_sha256':inv['source_sha256'],'projection_sha256':sha(projection),'graph_sha256':graph_sha,'phase1_freeze_sha256':sha(p1/'phase1-freeze.json'),'raw_units':366,'successor_counts':dict(Counter(r['exact_target_successor']['disposition'] for r in rows)),'raw_identity':'All current raw ordinals and original tag/line/column source keys are preserved; original/synthetic IDs, prior Variances ordinal mappings, math/reference fields and earlier204/162 dispositions remain unchanged history.','rows':rows,'source_marker_correction':'A3.SS3.p11.3, though listed by the projection, is only ∎ and explicitly EXCLUDED. The final paired inequality is A3.Ex159.','named_TBODY_policy':'Named source formula rows and true parent IDs remain preserved; selected log rows are NODEs, aggregate groups explicitly EXCLUDED as duplicates. Other raw NODE→EXCLUDED transitions name exact-target scope/duplication reasons.','scope_boundary':'No claim of completing full C.3, S4 probability application, rotated family, algorithm result, oracle/TV theorem or limitations branch.'}
outputs['exact-target-coverage.json']=encode(coverage);coverage_sha=hashlib.sha256(outputs['exact-target-coverage.json']).hexdigest()
closure_packet={'schema':1,'status':'MINIMAL_MATHEMATICAL_ROOT_CLOSURES_WITH_OPEN_OBLIGATIONS','projection_sha256':sha(projection),'graph_sha256':graph_sha,'coverage_sha256':coverage_sha,'closures':closures,'consumer_required_producer_projection':['N_positive_M','N_signed_positive','N_bias_lower'],'consumer_not_required':['P_root','N_bias_upper','N_power_upper','S_original_contrast','S_original_probability'],'consumer_prior_actual_projection':['N_Q_L2','N_Q_variance_2M'],'not_minimal_dependency_confusion':'A later Lean consumer may apply a bundled four-output producer. Its unused upper-bias conclusion is not a necessary mathematical source edge for this private bound. The private result also uses only Q L²/variance, not the two-quadratic contrast8M branch.','source_application_still_not_claimed':['Concrete source n=2q+1, τ=τ_dq, q/δ/κ/large-d/TV conditions','Actual Y-to-U orthogonal transport and matrix-polynomial identity','Positive source nonzero-τ contrast mean, Mβ²≥320 and .9 probability','Any full source query-bound or limitations result'],'independent_challenge_required':True}
outputs['root-closures.json']=encode(closure_packet)
inputs={'schema':1,'phase':'NEW_BIAS_PHASE2_EXACT_PROJECTION_ONLY','current_new_input':{'path':str(projection.relative_to(root)),'sha256':sha(projection),'full_seal_sha256_unread':s['seal_sha256']},'own_frozen_raw_inputs':[{'path':str((p1/f).relative_to(root)),'sha256':sha(p1/f)} for f in ['phase1-freeze.json','raw-unit-inventory.json','raw-unit-dispositions.json','raw-cognition.md','exposure-input-manifest.json']],'phase1_all_artifact_hashes_rechecked_unchanged':True,'prior_exposure_manifest_sha256':sha(p1/'exposure-input-manifest.json'),'new_other_exposure':'Parent phase2 scope/hash/independence instructions only.','not_read':['Full Bias seal','New Bias implementation/API/Mathlib/proof/lesson/audit/reviewer or other-agent outputs','Old Variances graph/implementation/API as new mathematical input','Normal ledger/frontier/global/site state'],'not_run':['Lean/proof search/build','ASTIS API/harness','Network','Normal intake/global mutation'],'write_boundary':str(out.relative_to(root)),'generation_script_sha256':sha(out/'build_source_packet.py'),'mathematical_authority_boundary':'Source topology and candidate statement assessment only. No compiled dependency or independent mathematical coverage approval.'}
outputs['machine-inputs.json']=encode(inputs)
lineage={'schema':1,'predecessor_raw_freeze':{'path':str((p1/'phase1-freeze.json').relative_to(root)),'sha256':sha(p1/'phase1-freeze.json')},'projection':{'path':str(projection.relative_to(root)),'sha256':sha(projection),'full_seal_sha256_unread':s['seal_sha256']},'unchanged_raw_rows_canonical_sha256':canonical_sha(inv['units']),'unchanged_history_rows_canonical_sha256':canonical_sha(history),'successor_raw_rows_canonical_sha256':canonical_sha([r['raw_source_unit'] for r in rows]),'successor_history_rows_canonical_sha256':canonical_sha([r['phase1_disposition'] for r in rows]),'all366_raw_units_preserved':True,'history204_NODE_162_EXCLUDED_retained':True,'outputs':[{'path':str((out/n).relative_to(root)),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)} for n,b in outputs.items()],'delta':'First exact-target phase2 successor after new Bias raw-first freeze. All target-specific inclusions/exclusions are append-only; no phase1 bytes changed.','open_review':'Distinct challenger must review graph, raw-unit successors and both root closures. No self-approved completeness.'}
assert lineage['unchanged_raw_rows_canonical_sha256']==lineage['successor_raw_rows_canonical_sha256']
assert lineage['unchanged_history_rows_canonical_sha256']==lineage['successor_history_rows_canonical_sha256']
outputs['binding-lineage.json']=encode(lineage)
# Final mechanical evidence before append-only freeze.
for a in frozen['artifacts']:assert sha(root/a['path'])==a['sha256']
assert len(rows)==len(history)==366
for r in rows:
 e=r['exact_target_successor'];assert e['disposition'] in ['NODE','EXCLUDED']
 assert e['graph_nodes'] if e['disposition']=='NODE' else e['reason']
for name in list(outputs)+['phase2-freeze.json']:assert not (out/name).exists(),name
for name,data in outputs.items():
 with (out/name).open('xb') as f:f.write(data)
freeze={'schema':1,'status':'NEW_BIAS_PHASE2_FROZEN_SOURCE_ONLY_PENDING_DISTINCT_CHALLENGE','phase1_freeze_sha256':sha(p1/'phase1-freeze.json'),'projection_sha256':sha(projection),'full_seal_sha256_unread':s['seal_sha256'],'artifacts':[{'path':str((out/n).relative_to(root)),'sha256':sha(out/n),'bytes':(out/n).stat().st_size} for n in ['build_source_packet.py']+list(outputs)],'counts':{'semantic_nodes':len(nodes),'AND_routes':len(routes),'OR_routes':0,'raw_units':len(rows),'coverage_successors':coverage['successor_counts'],'producer_closure_nodes':len(closures['producer_all_outputs']['nodes']),'consumer_closure_nodes':len(closures['private_actual_consumer']['nodes'])},'assessment':'Public source-domain/four-output bias candidate and explicit non-Anchor zero-threshold numeric scope are coherent; no new classification HOLD found in this projection. This is not proof or independent completeness approval.','prior_history_preserved':True,'no_proof_API_build_or_global_mutation':True}
with (out/'phase2-freeze.json').open('xb') as f:f.write(encode(freeze))
print(json.dumps({'freeze_sha256':sha(out/'phase2-freeze.json'),'counts':freeze['counts'],'artifacts':freeze['artifacts']},indent=2))
