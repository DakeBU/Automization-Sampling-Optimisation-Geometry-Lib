from pathlib import Path
import json, hashlib

HERE=Path(__file__).resolve().parent
assert not (HERE/'FREEZE.json').exists(), 'Phase 1 is already frozen'
def write(name,obj):
    (HERE/name).write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n')

structure=json.loads((HERE/'source_structure_inventory.json').read_text())
coverage=[]
for x in structure:
    c=set(x['class'].split())
    boundary=x['id'] in ['S3','S5','A3.SS4']
    is_container=bool(c & {'ltx_section','ltx_subsection','ltx_paragraph','ltx_proof'})
    item={**x,'disposition':'EXCLUDED' if boundary or is_container else 'NODE'}
    if boundary:
        item['reason']='Boundary marker exposed by selected raw line range; mathematical content outside reviewed scope was not read.'
    elif is_container:
        item['reason']='Structural container; all substantive paragraph, theorem, and display children are separately inventoried. Exclusion gives no mathematical completion credit.'
    else:
        item['node_id']='raw:'+x['id']
        item['kind']='statement' if 'ltx_theorem' in c else 'display' if c & {'ltx_equation','ltx_equationgroup'} else 'source-prose'
        item['status']='source-cognition-only; no implementation or candidate comparison'
    coverage.append(item)

citations=[
 {'node_id':'raw:citation22:1058','line':1058,'consumer':'S4.p1','kind':'external-citation','meaning':'Prior constant-accuracy Gaussian lower bound; contextual statement only'},
 {'node_id':'raw:citation22:1086','line':1086,'consumer':'S4.SS1.p1','kind':'external-citation','meaning':'Prior Section 9.2 fixed-spectrum construction'},
 {'node_id':'raw:citation22:1112','line':1112,'consumer':'S4.Thmtheorem2.p1','kind':'external-citation','meaning':'Identification of k=2 spectrum with original construction'},
 {'node_id':'raw:citation22:1146','line':1146,'consumer':'S4.SS2.SSS0.Px1.p1','kind':'external-citation','meaning':'Prior Lemma 9.2 deferred-rotation argument'}]
for x in citations:
    x.update(disposition='NODE',reference_href='#bib.bib3',bibliography_lines=[1847,1855],external_source_opened=False)
write('coverage_inventory.json',{'scope':'complete S4 and A3.SS3 plus actual S2 standing definitions','unit_policy':'Each paragraph, statement, display, citation and structural container receives an explicit disposition. Containment duplicates are retained, not counted as independent mathematical advances.','units':coverage,'citation_use_sites':citations,'coverage_limit':'This inventory was formed independently from raw source. It has not been approved by a distinct topology reviewer.'})

edges=[]
def edge(consumer,ingredients,site,meaning):
    edges.append({'consumer':consumer,'ingredients':ingredients,'connective':'AND','consumer_use_lines':site,'meaning':meaning,'provenance':'raw pinned source only'})
edge('A3.Thmtheorem7',['standing:k>=2','definition:r','background:complex-geometric-series','A3.Ex136'],[3864,3899],'Pointwise reciprocal-spectrum expansion')
edge('A3.Thmtheorem7:absolute-uniform-convergence',['standing:0<r<1','A3.Ex137','background:uniform-geometric-tail'],[3889,3897],'Absolute and uniform convergence over every real theta')
edge('A3.Ex139',['definition:midpoint-grid','background:finite-cosine-sum'],[3916,3931],'Finite-grid alias identity for every integer frequency')
edge('A3.Ex140',['definition:U~N(0,Lambda^-1)','background:Gaussian-coordinate-second-moment'],[3932,3940],'Actual Gaussian mean expressions')
edge('A3.EGx15',['A3.Thmtheorem7','A3.Thmtheorem7:absolute-uniform-convergence','A3.Ex139','A3.Ex140','background:alternating-geometric-series'],[3941,3966],'Exact M via surviving 2ad modes')
edge('A3.EGx16',['A3.Thmtheorem7','A3.Thmtheorem7:absolute-uniform-convergence','A3.Ex139','A3.Ex140','A3.Ex144','standing:1<=n<d','background:cosine-product-to-sum','background:parity-and-disjoint-alias-classes','background:alternating-geometric-series'],[3967,4005],'Exact signed cosine moment')
edge('A3.Thmtheorem8',['A3.EGx15','A3.EGx16'],[3903,4005],'Both finite-grid formulas')
edge('S4.Thmtheorem5:means',['A3.Thmtheorem8'],[4009,4012],'C.8 supplies the means in Lemma 4.5')
edge('S4.Thmtheorem5:variances',['definition:diagonal-Gaussian-law','background:Gaussian-fourth-moment','background:coordinate-independence','standing:lambda_i>=1','background:cosine-square<=1','A3.EGx17','A3.EGx15'],[4013,4037],'Exact Gaussian variance sums and upper bounds by 2M<=2d/sqrt(k)')
edge('A3.Ex150',['A3.Thmtheorem8','standing:0<r<1','standing:1<=n<d','derived:M>0','derived:(-1)^n mu_n>0'],[4038,4051],'Positive signed moment and exact normalized bias')
edge('A3.Ex157',['definition:r','A3.EGx18','A3.EGx19','standing:k>=2','standing:n>=1'],[4063,4109],'Exponential power squeeze from the logarithmic integral')
edge('A3.Ex158',['A3.EGx18','standing:d-n>=sqrt(k)'],[4110,4119],'Finite-grid alias tail <=exp(-4)')
edge('S4.Thmtheorem5:bias-bound',['A3.Ex150','A3.Ex151','A3.Ex157','A3.Ex158'],[4120,4132],'Guarded two-sided normalized bias estimate')
edge('S4.Ex15',['S4.Thmtheorem3','S4.Thmtheorem4'],[1242,1253],'Uniform Krylov control applies to adaptive output on the joint-law-preserving extension')
edge('S4.Ex22',['S4.Thmtheorem3','S4.Thmtheorem4','S4.Ex20','definition:S_A','definition:E_A','background:Chebyshev-polynomial-spectral-calculus'],[1376,1412],'Input-averaged algorithm passing probability <=.01')
edge('S4.Ex23',['S4.Thmtheorem5:bias-bound','assumed:q<=(delta/256)sqrt(k)log d','derived:d-n>=sqrt(k)'],[1424,1437],'Uniform target bias lower bound b d^(-delta/4)')
edge('S4.Ex24',['S4.Ex20','S4.Ex23','S4.Thmtheorem5:means','assumed:k<=d^(1-delta)'],[1438,1456],'Choose d_0(delta) to make tau<=beta/4 and M beta^2>=320')
edge('S4.Ex25',['S4.Thmtheorem5:means','S4.Thmtheorem5:variances','definition:S_A','derived:tau<=beta/4','derived:tau<=1/2','background:L2-triangle-for-centered-variables'],[1457,1470],'Mean >=beta M/2 and variance <=8M for the target statistic')
edge('S4.Ex26',['S4.Ex25','derived:M beta^2>=320','background:Chebyshev-inequality'],[1471,1479],'Per-input target passing probability >=.9')
edge('S4.Ex27',['S4.Ex22','S4.Ex26','assumed:per-input-TV<=epsilon<=.1','background:TV-event-bound','background:average-over-Haar-input'],[1484,1498],'Contradiction .89<=epsilon<=.1')
edge('S4.Thmtheorem1',['S4.Thmtheorem6','S4.Ex27','background:integer-fixed-cap-query-complexity-definition'],[1329,1498],'Sampling lower bound under full stated quantifiers')
edge('S4.Ex29',['S4.Thmtheorem7','standing:(q+1)^2>=d','standing:n=2q+1<d','background:finite-grid-cosine-square-sum'],[1540,1559],'Uniform Krylov statistic cannot remain small after full-space saturation')
edge('S4.Ex30',['deferred:FactC6-Bernstein-certificate-floor','S4.Thmtheorem5:bias-bound-upper','necessary-for-this-test:a<beta','definition:n=2q+1'],[1564,1588],'This threshold/certificate route is limited to O(sqrt(k)log d), independently of epsilon')
write('source_proof_edges.json',{'truth':'Source-derived proof cognition, not compiler dependencies or accepted topology','alternative_routes':'No alternative sufficient proof routes are supplied in this slice. All listed hyperedges describe the local printed route.','edges':edges,'gaps':[{'id':'SOURCE_GAP:L4.7-generic-rank','source_anchor':'S4.Thmtheorem7','lines':[1526,1539],'residual':'Derive almost-sure rank min{d,(q+1)^2} for columns Lambda^j g_a using distinct eigenvalues. No proof in reviewed scope.'}],'deferred':[{'anchor':'S4.Thmtheorem3','proof':'Appendix C.1','read':False},{'anchor':'S4.Thmtheorem4','proof':'Appendix C.2','read':False},{'anchor':'S4.Thmtheorem6','proof':'Appendix C.4','read':False},{'anchor':'Section4.4 certificate floor','proof':'Fact C.6 Bernstein calculation','read':False}]})

write('exposure_and_tool_log.json',{
 'agent':'/root/source_reader_c24a61',
 'phase':'1 raw-source cognition only',
 'initial_context':'Delegated task, environment, generic tool/developer instructions; source path/hash/scope were supplied. No candidate, reconstruction, lesson, audit, repository graph, other-agent artifact or prior verdict was supplied or opened.',
 'forbidden_material_read':False,
 'source_reads':json.loads('['+','.join((HERE/'raw_read_log.jsonl').read_text().splitlines())+']'),
 'other_operations':[
  {'chunk':'c04bd2','tool':'exec_command','operation':'Check exact ancestor AGENTS paths and read existing file','command':'for p in /AGENTS.md /Users/AGENTS.md /Users/zhouhuanjian/AGENTS.md /Users/zhouhuanjian/ASTIS-GC/AGENTS.md; do if test -f "$p"; then printf \'\\nFILE %s\\n\' "$p"; cat "$p"; fi; done','read_existing':['AGENTS.md']},
  {'chunk':'83ceee','tool':'exec_command','command':'cat docs/theorem-publication-protocol.md docs/proof-digestion-protocol.md docs/evidence-routed-memory-protocol.md','note':'Aggregate tool output emitted a truncation notice; exact input files are preserved and the proof-digestion file was subsequently reread separately.'},
  {'chunk':'e8a995','tool':'exec_command','command':'rg --files .agents/skills -g SKILL.md','output':'skill_path_inventory.txt','note':'Only skill path names were listed; no repository search for theorem target names was performed.'},
  {'chunk':'9882bf','tool':'exec_command','operation':'Check exact protocol/skill/source/output ancestor AGENTS files','checked':['docs/AGENTS.md','.agents/AGENTS.md','.agents/skills/AGENTS.md','.astis/AGENTS.md','.astis/huanjian-resume-20261103/AGENTS.md','.astis/semantic-neutral-20261110/AGENTS.md','.astis/semantic-neutral-20261110/src_c24a61/AGENTS.md','.astis/semantic-neutral-20261110/src_c24a61/phase1/AGENTS.md'],'result':'None existed'},
  {'chunk':'e0c7ac','tool':'exec_command','command':'cat .agents/skills/astis-semantic-roundtrip/SKILL.md'},
  {'chunk':'5ba7d3','tool':'exec_command','command':'cat docs/proof-digestion-protocol.md'},
  {'chunk':'686b42','tool':'exec_command','operation':'Check .agents/skills/astis-semantic-roundtrip/AGENTS.md','result':'Did not exist'},
  {'chunk':'b74fca','tool':'exec_command','operation':'Read/pin exact source bytes, assert supplied SHA256, copy five already-read process files, write input_inventory.json; inspect only raw HTML heading lines','outputs':['pinned_source.html','input_inventory.json','protocol_01.txt','protocol_02.txt','protocol_03.txt','protocol_04.txt','protocol_05.txt','read_001_heading_index.txt'],'note':'Heading index reveals whole-paper titles, theorem names/numbers and navigation only; no other paper section body was exposed by this operation.'},
  {'tool':'apply_patch','operation':'Write read_source.py v1 only in owned directory','artifact':'read_source_v1.py'},
  {'chunk':'542a42','tool':'exec_command','operation':'First standing-definition read (raw exact; projection v1)','note':'Projection v1 failed to render multiline MathML alttext. Raw fragment was preserved; complete reread read_003 supersedes this projection.'},
  {'chunk':'93b964','tool':'exec_command','command':'cp .astis/semantic-neutral-20261110/src_c24a61/phase1/read_source.py .astis/semantic-neutral-20261110/src_c24a61/phase1/read_source_v1.py'},
  {'tool':'apply_patch','operation':'Replace reader projection with HTMLParser that preserves multiline math alttext; write only owned reader file','artifact':'read_source.py'},
  {'chunk':'eb199a','tool':'exec_command','operation':'Locate bibliography hrefs in already-read S4 and C3; search exact raw id bib.bib22','output':'read_008_citation_locator.json','note':'Display reference [22] actually links bib.bib3. Erroneous locator bib.bib22 exposed only its line number 1820, no bibliographic text.'},
  {'chunk':'7caa6e','tool':'exec_command','operation':'Locate exact raw id bib.bib3','result':'Line 1847 and that li opening tag, including display [22]'},
  {'chunk':'f0202c','tool':'exec_command','operation':'HTMLParser structure inventory of already-read S2,S4,C3; print only structural IDs/class/line intervals','output':'source_structure_inventory.json','note':'Boundary metadata S3/S5/A3.SS4 appears because interval endpoints touched container opening tags; no content from those containers was printed.'},
  {'tool':'apply_patch','operation':'Write independent cognition.md from raw-source reading only'},
  {'tool':'apply_patch','operation':'Write this record generator in owned directory; creates coverage/proof-edge/exposure artifacts without reading repository content beyond owned copies'},
 ],
 'read_projection_policy':'The .raw.html fragments preserve exact source text. The .read.txt files are views with raw line numbers and original MathML alttext. read_002 uses superseded v1; read_003 supplies complete standing definition text.',
 'incidental_raw_source_exposure':['Complete source heading index','Source title/authors and abstract at 281-308','Bibliography reference [22] plus its first Cited-by line at 1847-1855'],
 'independence_attestation':'All mathematical cognition and source-proof edges were formed before any candidate, Lean declaration, reconstruction or prior judgment was read. No source comparison, repair acceptance, implementation proof acceptance or repository truth mutation occurred.',
 'writes_boundary':str(HERE),
 'next_step':'Freeze this Phase 1 once. Stop. Wait for a later strict Phase 2 whitelist.'
})
(HERE/'skill_path_inventory.txt').write_text('''.agents/skills/astis-open-problem/SKILL.md
.agents/skills/astis-semantic-roundtrip/SKILL.md
.agents/skills/astis-conversion-window/SKILL.md
.agents/skills/astis-proof-dag/SKILL.md
.agents/skills/astis-proof-export/SKILL.md
.agents/skills/astis-slt-reuse/SKILL.md
.agents/skills/astis-source-dependency-audit/SKILL.md
.agents/skills/astis-substantive-advance/SKILL.md
.agents/skills/astis-formalize-paper/SKILL.md
.agents/skills/astis-cross-library-coordination/SKILL.md
''')
print(json.dumps({'coverage_units':len(coverage),'citation_use_sites':len(citations),'source_hyperedges':len(edges),'files_created':['coverage_inventory.json','source_proof_edges.json','exposure_and_tool_log.json','skill_path_inventory.txt']},indent=2))
