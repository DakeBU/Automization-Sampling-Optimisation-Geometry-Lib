from pathlib import Path
import copy
import datetime
import hashlib
import json
import subprocess

ROOT = Path('/Users/zhouhuanjian/ASTIS-GC')
OWN = ROOT / '.astis/semantic-neutral-20261109/src_82a91d'
OUT = OWN / 'frontier-projection-after-sourceV'
TARGET = ROOT / 'research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-grid-alias.json'
PUBLIC_RECEIPT = 'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-grid-alias-semantic-evidence/actual-source-V/API-result.json'
ACTOR = '/root/source_reader_82a91d'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def write(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT).decode()

def changes(a, b, path=''):
    if type(a) != type(b):
        return [path]
    if isinstance(a, dict):
        result = []
        for key in sorted(set(a) | set(b)):
            if key not in a or key not in b:
                result.append(path + '/' + key)
            else:
                result += changes(a[key], b[key], path + '/' + key)
        return result
    if isinstance(a, list):
        if len(a) != len(b):
            return [path]
        return [p for i, (x, y) in enumerate(zip(a, b)) for p in changes(x, y, path + '/' + str(i))]
    return [] if a == b else [path]

OUT.mkdir(parents=True, exist_ok=True)
assert not (OUT / 'projection-result.json').exists(), 'Projection already performed'
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
head = git('rev-parse', 'HEAD').strip()
assert head == '3cb4f0b7f5f4f8bf9fc6644d13e9581bccad3508'
baseline_diffs = git('diff', '--name-only').splitlines()
assert baseline_diffs == ['runs/substantive_advances.jsonl']
raw = TARGET.read_bytes()
assert sha(raw) == '0584c6f0a471298d7fd959e9430a90dfdec7761b5be89cc07b5d9290ea3e6069'
before = json.loads(raw)
actual_file = OWN / 'normal-sourceV-runtime/API-result.json'
actual_raw = actual_file.read_bytes()
assert sha(actual_raw) == 'ecc331c8d93c8ab6f359038782e375571f69a3629109ddc09bd732308eb55466'
actual = json.loads(actual_raw)
assert actual['worker_id'] == ACTOR and actual['normal_API_attempt_count'] == 1
assert actual['resulting_target_state'] == 'VERIFIED' and actual['exit_code'] == 0
assert actual['head_after'] == head
evidence_file = OWN / 'normal-sourceV-runtime/original-evidence.json'
evidence_raw = evidence_file.read_bytes()
assert sha(evidence_raw) == '9075300e2ea7fef6f62470c04849b51be151c20b6424ca220cb38d3ce6aa260a'
evidence = json.loads(evidence_raw)
assert len(evidence) == 12
canonical_evidence_hash = sha(json.dumps(evidence, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode())
assert canonical_evidence_hash == '95d1c3ff915f190c4072c33962b809103a69a4aa07b0e9fd22c53aa833f17c9a'
public = ROOT / PUBLIC_RECEIPT
public_exists = public.is_file()
if public_exists:
    assert public.read_bytes() == actual_raw
for row in json.loads((OWN / 'normal-sourceV-runtime/FREEZE.json').read_text())['files']:
    assert sha((OWN / 'normal-sourceV-runtime' / row['path']).read_bytes()) == row['sha256']

after = copy.deepcopy(before)
after['status'] = 'independently_verified'
after['statement_seal']['status'] = 'EXACT_ORIGINAL_SIGNATURES_INDEPENDENT_SOURCE_WHOLE_MODULE_STATIC_READER_ACCEPTED_NORMAL_SOURCE_V_ACCEPTED'
after['source_proof_coverage']['current_compiled_scope']['source_VERIFIED'] = True
after['evidence']['independent_verification'] = (
    'Original independent verifier /root/source_reader_82a91d executed exactly one normal '
    'tools.astis_advance.transition_advance PROVED_LOCAL -> VERIFIED for '
    'ASTIS-SA-20261109-GaussianComplexityFixedSpectrumGridAlias at 2026-11-09T14:40:49+00:00; '
    'API returned None, exit0. Actual verified_commit/carrier3cb4f0b7f5f4f8bf9fc6644d13e9581bccad3508; '
    'fresh native producer/Test/kernel corecbf3c22b901a484c463f417a3e206bb200622294; '
    'accepted full source/whole-module/static reader93a7005b3e861ddc58484fb3a21abd83ad44722b. '
    'No new build at metadata heads. Actual owned API-result proof: '
    '.astis/semantic-neutral-20261109/src_82a91d/normal-sourceV-runtime/API-result.json '
    '(1767bytes, SHA256ecc331c8d93c8ab6f359038782e375571f69a3629109ddc09bd732308eb55466); '
    'public byte-identical receipt target: ' + PUBLIC_RECEIPT + '. '
    'The original8069-byte appended event has SHA2569dc1b2a3da3d43934cf7bd68ee773c8bd3cbc1deebae0844aa6058e18db4fdd4. '
    'All other advance states, discovery bytes/states and the original ledger prefix were preserved. '
    'This frontier update is metadata projection only, with no new ledger/API call.'
)
boundary = (
    'Verified locally: the exact original all-integer midpoint-grid alias and the actual private '
    'summable weighted reciprocal-grid alias series, with literal sealed types, produced convergence, '
    'actual alias+C7 use and only standard recursive axioms. Source-blind decoding and independent '
    'source/whole-module/static-reader review, including the corrected lambda_i/r definitions and '
    'natural mode domain, are accepted with disclosed ambient filename-cue limits; the original '
    'independent verifier executed normal sourceV at3cb4 with native corecbf3 and static reader93a. '
    'Latest-main sole-STAB local/remote integration, aggregate release, generated site/current reader '
    'browser/mobile/remote acceptance and purification/Exposition Seal remain pending. Gaussian '
    'expectation identification, alias-tail partitions/closed means, full FactC8, Lemma4.5 variance/bias, '
    'Krylov, both full main lower bounds and actual oracle/precision/TV/deterministic-cap/expected-cost '
    'adapters remain open. The midpoint/Lobatto relation remains conceptual, not a Lean implication; '
    'foreign queues remain untouched. Earlier admission/reader/source-gap pending wording retained '
    'elsewhere in this cell is phase history; this current verified-local projection is authoritative '
    'only for the selected scope.'
)
after['evidence']['execution_boundary'] = boundary
after['evidence']['independent_source_review']['normal_sourceV_transition'] = (
    'Executed once by original independent verifier /root/source_reader_82a91d at '
    '2026-11-09T14:40:49+00:00 using the normal API; PROVED_LOCAL -> VERIFIED, return None, exit0; '
    'verified_commit3cb4f0b7f5f4f8bf9fc6644d13e9581bccad3508. Exact receipt target: ' + PUBLIC_RECEIPT
)
after['evidence']['sourceV_projection'] = {
    'kind': 'metadata-projection-of-already-executed-independent-sourceV',
    'projected_by_original_verifier': ACTOR,
    'advance_id': actual['advance_id'], 'state': 'VERIFIED',
    'sourceV_event_time': actual['ledger_event_created_at'],
    'verified_commit': actual['head_after'],
    'checked_commit_layers': copy.deepcopy(evidence['checked_commit_layers']),
    'original_normal_API_attempt_count': 1, 'API_return_value': None, 'API_exit_code': 0,
    'projection_is_new_verification': False, 'projection_ledger_or_API_calls': 0,
    'API_result': {'public_path': PUBLIC_RECEIPT, 'actual_owned_path': str(actual_file.relative_to(ROOT)),
                   'bytes': len(actual_raw), 'sha256': sha(actual_raw)},
    'exact_original_event': {'bytes': 8069, 'sha256': '9dc1b2a3da3d43934cf7bd68ee773c8bd3cbc1deebae0844aa6058e18db4fdd4'},
    'original_evidence': {
        'field_count': 12, 'field_names': list(evidence), 'bytes': len(evidence_raw),
        'raw_sha256': sha(evidence_raw), 'compact_canonical_sha256': canonical_evidence_hash,
        'later_existing_V_release_rule': 'Preserve EVERY one of the original12 evidence fields and all their values; ONLY add post_integration.',
    },
    'accepted_review': {
        'reviewer_packet_sha256': 'f381a1ca1e1aa488cc8cc259e0bae1f9d00a2b391e9ff4966cc64e0ae57875bb',
        'publication_binding_sha256': 'c7b557be6ccb8b31fb252c496a4f5535d950fddd8ff3d06a6029527cbdee3f5d',
        'review_run_sha256': '2f6adfb5ca211aa4d480b28750734f84e917d6ff16358e60ca53f5516f4aef62',
    },
    'earlier_source_proof_reader_learning_role_source_gap_phase_history_preserved': True,
    'pending': ['sole-STAB and latest-main integration', 'local/remote release',
                'site/current-reader browser/mobile/remote acceptance', 'purification/Exposition Seal',
                'Gaussian expectation identification and closed full FactC8',
                'Lemma4.5 variance/bias and Krylov', 'both full main lower bounds and oracle/cost adapters'],
}
allowed = {
    '/status', '/statement_seal/status',
    '/source_proof_coverage/current_compiled_scope/source_VERIFIED',
    '/evidence/independent_verification', '/evidence/execution_boundary',
    '/evidence/independent_source_review/normal_sourceV_transition', '/evidence/sourceV_projection',
}
actual_changes = set(changes(before, after))
assert actual_changes == allowed, actual_changes
assert isinstance(after['evidence']['independent_verification'], str)
new_raw = (json.dumps(after, ensure_ascii=False, indent=2) + '\n').encode()
(OUT / 'frontier.before.raw.json').write_bytes(raw)
(OUT / 'frontier.after.raw.json').write_bytes(new_raw)
assert TARGET.read_bytes() == raw
TARGET.write_bytes(new_raw)
assert TARGET.read_bytes() == new_raw
assert set(changes(before, json.loads(TARGET.read_bytes()))) == allowed
assert json.loads(evidence_file.read_text()) == evidence
assert actual_file.read_bytes() == actual_raw
after_diffs = git('diff', '--name-only').splitlines()
assert set(after_diffs) == set(baseline_diffs) | {str(TARGET.relative_to(ROOT))}
assert git('rev-parse', 'HEAD').strip() == head
write('allowed-field-path-diff.json', {
    'allowed_paths': sorted(allowed), 'actual_paths': sorted(actual_changes),
    'exact_match': True,
    'all_other_fields_and_phase_history_equal': True,
    'independent_verification_remains_STRING': True,
})
write('projection-result.json', {
    'actor': ACTOR, 'started_utc': started, 'ended_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'head_before_and_after': head, 'target': str(TARGET.relative_to(ROOT)),
    'before': {'sha256': sha(raw), 'bytes': len(raw)},
    'after': {'sha256': sha(new_raw), 'bytes': len(new_raw)},
    'only_file_written_outside_owned_directory': str(TARGET.relative_to(ROOT)),
    'baseline_tracked_diff_paths': baseline_diffs, 'resulting_tracked_diff_paths': after_diffs,
    'ledger_or_API_calls': 0, 'new_verification_claim': False,
    'public_receipt_existed_at_projection': public_exists,
    'public_receipt_copy_required_before_root_carrier_commit': not public_exists,
    'expected_public_receipt_sha256': sha(actual_raw),
    'original_evidence12_fields_unchanged': True,
    'status': after['status'], 'source_VERIFIED': True,
})
print(json.dumps({'target': str(TARGET.relative_to(ROOT)), 'status': after['status'],
                  'before_sha256': sha(raw), 'after_sha256': sha(new_raw),
                  'exact_changed_path_count': len(actual_changes), 'ledger_API_calls': 0,
                  'public_receipt_copy_pending_root': not public_exists}, indent=2))
