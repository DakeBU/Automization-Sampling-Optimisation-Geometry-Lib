"""R16 isolated-reader checker. Preparation only until a separate ROOT execution assignment exists."""
import argparse
import datetime as dt
from functools import partial
import hashlib
from http.server import SimpleHTTPRequestHandler,ThreadingHTTPServer
import json
import os
from pathlib import Path
import re
import sys
import tempfile
import threading
import time
import traceback
from urllib.parse import urljoin,quote
from browser_geometry import GEOMETRY,VISIBLE,GLYPH,scroll_center,zoom_pan_actual_ui,core_label_readable

OWN=Path(__file__).resolve().parent
REPO=OWN.parents[2]
ITEM='huanjian-trace-exponential-domain'
PFILE='AutoSamplingTheory/TechnicalLemmas/Analysis/MatrixTraceExponentialBounds.lean'
TFILE='Tests/GaussianComplexityTraceMgfDomain.lean'
P='AutoSamplingTheory.TechnicalLemmas.Analysis.MatrixTraceExponentialBounds.trace_exp_pos_and_le_card_mul_exp_abs_mul_norm'
T='AutoSamplingTheory.Tests.GaussianComplexityTraceMgfDomain.actual_source_four_trace_mgfs_integrable_positive_and_bounded'
SOURCES=[('P',PFILE,P,18,60),('T',TFILE,T,21,183),
 ('Radius','AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumSourceMatrixRadius.lean','AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumSourceMatrixRadius.actual_source_truncated_matrix_norm_bounds',101,226),
 ('Structure','AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumSourceMatrixStructure.lean','AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumSourceMatrixStructure.actual_source_centered_matrix_structure',13,148)]

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,d):Path(p).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')

class QuietHandler(SimpleHTTPRequestHandler):
    def log_message(self,*_):pass

def parse():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--preview-root',type=Path,required=True)
    parser.add_argument('--assignment',type=Path,default=OWN/'execution-assignment.json')
    return parser.parse_args()

def main(args,a):
    preview=args.preview_root.resolve();manifest_path=preview/'preview-freeze-manifest.json'
    assert preview==Path(a['preview_root']).resolve()
    assert sha(__file__)==a['runner_sha256'] and sha(OWN/'browser_geometry.py')==a['geometry_sha256']
    assert sha(manifest_path)==a['preview_manifest_sha256']
    assert re.fullmatch('[0-9a-f]{64}',a['source_reviewed_publication_binding_sha256'])
    for row in a['frozen_inputs']:assert sha(row['path'])==row['sha256']
    manifest=json.loads(manifest_path.read_text());assert manifest['proof_commit']=='30172847ec40c24426f0b39afc4887719810eca0'
    assert manifest['lesson_sha256']==a['lesson_sha256'] and manifest['publication_sha256']==a['publication_sha256']
    selected=manifest['variants']['candidate'];fixture=preview/'fixtures/candidate';snapshot=preview/'input-snapshot'
    fixture_paths=lambda:{str(p.relative_to(fixture)) for p in fixture.rglob('*') if p.is_file()}
    assert fixture_paths()=={row['path'] for row in selected['files']}
    for row in selected['files']:assert sha(fixture/row['path'])==row['sha256']
    unit=json.loads((snapshot/'website/content/declaration_lessons'/f'{ITEM}.json').read_text())['units'][0]
    assert len(unit['steps'])==5
    assert [s['lean_source_path'] for s in unit['steps']]==[PFILE]*3+[TFILE]*2
    assert [s['lean_source']['LF_lines_1based'] for s in unit['steps']]==[[1,37],[38,51],[52,60],[1,136],[137,183]]
    for label,raw,name,anchor,lines in SOURCES:
        exact=(snapshot/raw).read_bytes();assert len(exact.decode().splitlines())==lines
        if label=='P':assert hashlib.sha256(exact).hexdigest()=='1ef6f49fa5f0a8b3b61ba42d31bca1bb744bebb64e433075d0ca25ab82570b76'
        if label=='T':assert hashlib.sha256(exact).hexdigest()=='72311555e65cacc8b129510f2158abc9e2e6a230882a2169f6504e80f394fedb'
    chrome=Path(a['chrome']['path']);assert sha(chrome)==a['chrome']['binary_sha256']
    output=OWN/'runtime-output';output.mkdir(exist_ok=False)
    tmp=OWN/'chrome-tmp';tmp.mkdir(exist_ok=True);os.environ['TMPDIR']=str(tmp);tempfile.tempdir=str(tmp)
    checks=[];screenshots=[];requests=[];responses=[];console=[];errors=[];blocked=[]
    def check(name,ok,detail=None):checks.append({'name':name,'pass':bool(ok),'detail':detail})
    def shot(page,name,full=False):
        path=output/(name+'.png');page.screenshot(path=str(path),full_page=full)
        screenshots.append({'path':str(path.relative_to(OWN)),'sha256':sha(path)})
    server=ThreadingHTTPServer(('127.0.0.1',0),partial(QuietHandler,directory=str(fixture)))
    worker=threading.Thread(target=server.serve_forever,daemon=True);worker.start()
    origin='http://127.0.0.1:'+str(server.server_port);started=False;version=None
    try:
        from playwright.sync_api import sync_playwright
        with sync_playwright() as playwright:
            browser=playwright.chromium.launch(executable_path=str(chrome),headless=True);started=True;version=browser.version
            for label,width,height in [('desktop',1440,1000),('mobile',390,844)]:
                context=browser.new_context(permissions=['clipboard-read','clipboard-write'],viewport={'width':width,'height':height},device_scale_factor=1,accept_downloads=True)
                def route(route):
                    url=route.request.url
                    if url.startswith(origin+'/') or url.startswith(('data:','blob:')):route.continue_()
                    else:blocked.append(url);route.abort()
                context.route('**/*',route);page=context.new_page()
                page.on('request',lambda r:requests.append({'url':r.url,'method':r.method,'resource_type':r.resource_type}))
                page.on('response',lambda r:responses.append({'url':r.url,'status':r.status}))
                page.on('console',lambda m:console.append({'type':m.type,'text':m.text}))
                page.on('pageerror',lambda e:errors.append(str(e)))
                def goto(path,math=False):
                    page.goto(urljoin(origin+'/',path),wait_until='networkidle')
                    if math:
                        page.wait_for_function('!!(window.MathJax&&MathJax.startup&&MathJax.startup.promise)')
                        page.evaluate('async()=>{await MathJax.startup.promise;await MathJax.typesetPromise();}')
                def layout(stage):
                    g=page.evaluate('()=>({viewport:innerWidth,html:document.documentElement.scrollWidth,body:document.body.scrollWidth})')
                    check(label+'-'+stage+'-document-horizontal-containment',g['html']<=g['viewport']+1 and g['body']<=g['viewport']+1,g)
                try:
                    goto(selected['proof_path'],math=True);article=page.locator('article.proof-reader')
                    steps=article.locator('details.proof-reader-step')
                    check(label+'-exactly-five-progressive-proof-steps',steps.count()==5)
                    check(label+'-five-steps-initially-folded',steps.evaluate_all('(xs)=>xs.length===5&&xs.every(x=>!x.open)'))
                    assumptions=article.locator('details.assumption-ledger')
                    check(label+'-assumptions-initially-folded',assumptions.count()==1 and not assumptions.evaluate('(e)=>e.open'))
                    check(label+'-statement-and-proof-initially-folded',article.locator('details.inline-lean').evaluate_all('(xs)=>xs.length>=2&&xs.every(x=>!x.open)'))
                    check(label+'-main-mathematical-formula-rendered',article.locator('.reader-main-equation mjx-container').count()>0)
                    check(label+'-initial-MathJax-no-errors',page.locator('mjx-merror,[data-mjx-error]').count()==0)
                    layout('proof-initial');shot(page,label+'-proof-initial-folded',full=True)
                    article.locator('details').evaluate_all('(xs)=>xs.forEach(x=>x.open=true)');page.evaluate('async()=>{await MathJax.typesetPromise();}')
                    code=steps.locator('pre.code-block>code').all_text_contents()
                    check(label+'-five-adjacent-source-code-spans',len(code)==5)
                    check(label+'-P60-first-three-folds-exact',''.join(code[:3]).encode()==(snapshot/PFILE).read_bytes())
                    check(label+'-T183-last-two-folds-exact',''.join(code[3:]).encode()==(snapshot/TFILE).read_bytes())
                    check(label+'-all243-source-lines-exact',len(''.join(code).splitlines())==243)
                    for i,stepdata in enumerate(unit['steps']):
                        step=steps.nth(i);raw=stepdata['lean_source_path'];first=stepdata['lean_source']['LF_lines_1based'][0]
                        check(label+'-step'+str(i+1)+'-rendered-title',step.locator(':scope>summary').text_content().strip()==str(i+1)+'. '+stepdata['title'])
                        check(label+'-step'+str(i+1)+'-visible-mathematical-prose-and-formula',bool(step.locator('.reader-step-body>p').first.text_content().strip()) and step.locator('.proof-reader-equation mjx-container').count()>0)
                        check(label+'-step'+str(i+1)+'-exact-displayed-Lean',code[i]==stepdata['lean'])
                        source=step.locator('a[data-step-source]');download=step.locator('a[download]');copy=step.locator('button[data-lean-copy]')
                        check(label+'-step'+str(i+1)+'-one-adjacent-copy-source-download',source.count()==download.count()==copy.count()==1)
                        check(label+'-step'+str(i+1)+'-correct-source-and-start-anchor',source.get_attribute('href').endswith(raw+'.html#L'+str(first)) and download.get_attribute('href').endswith('downloads/lean/'+raw) and step.locator('details[data-step-source-path]').get_attribute('data-step-source-path')==raw)
                        copy.click();copied=page.evaluate('navigator.clipboard.readText()')
                        check(label+'-step'+str(i+1)+'-actual-copy-byte-exact',copied.encode()==stepdata['lean'].encode())
                        with page.expect_download() as pending:download.click()
                        destination=output/(label+'-step'+str(i+1)+'-whole-module.lean');pending.value.save_as(str(destination))
                        check(label+'-step'+str(i+1)+'-actual-whole-module-download-exact',destination.read_bytes()==(snapshot/raw).read_bytes())
                        prior=page.url
                        with page.expect_navigation(wait_until='networkidle'):source.click()
                        anchor=page.locator('#L'+str(first));g=anchor.evaluate(VISIBLE)
                        check(label+'-step'+str(i+1)+'-actual-source-anchor-navigation',page.url.endswith(raw+'.html#L'+str(first)) and g['positive'] and g['top']>=g['header']-1,g)
                        page.go_back(wait_until='networkidle');page.wait_for_url(prior)
                        page.locator('article.proof-reader details').evaluate_all('(xs)=>xs.forEach(x=>x.open=true)')
                        if i in [0,4]:
                            scroll_center(page.locator('details.proof-reader-step').nth(i).locator(':scope>summary'));shot(page,label+'-representative-step'+str(i+1))
                    equations=page.locator('.proof-reader-equation');formula_geometry=[]
                    for i in range(equations.count()):
                        g=equations.nth(i).evaluate("""el=>{const max=el.scrollWidth-el.clientWidth;el.scrollLeft=max;return{max,actual:el.scrollLeft,overflow:getComputedStyle(el).overflowX};}""")
                        formula_geometry.append(g)
                        check(label+'-formula'+str(i)+'-right-reachable-if-overflow',g['max']<=1 or (g['actual']>=g['max']-1 and g['actual']>0 and g['overflow'] in ['auto','scroll']),g)
                    check(label+'-expanded-MathJax-no-errors',page.locator('mjx-merror,[data-mjx-error]').count()==0)
                    table=page.locator('[data-source-comparison] .table-scroll')
                    check(label+'-source-assumption-comparison-present',table.count()==1)
                    if table.count():
                        scroll_center(table);g=table.evaluate("el=>{el.scrollLeft=el.scrollWidth-el.clientWidth;return{max:el.scrollWidth-el.clientWidth,actual:el.scrollLeft,overflow:getComputedStyle(el).overflowX};}")
                        check(label+'-source-table-right-reachable',g['max']<=1 or (g['actual']>=g['max']-1 and g['overflow'] in ['auto','scroll']),g)
                        shot(page,label+'-expanded-assumption-comparison')
                    layout('proof-expanded')
                except Exception:
                    check(label+'-proof-stage-completed',False,traceback.format_exc());shot(page,label+'-proof-stage-failure')

                for source_label,raw,name,anchor,line_count in SOURCES:
                    try:
                        path='data/lesson-sources/'+raw+'.html#L'+str(anchor);goto(path)
                        exact=(snapshot/raw).read_bytes();spans=page.locator('pre span[id^="L"]')
                        check(label+'-'+source_label+'-whole-source-body-exact',page.locator('pre').text_content().encode()==exact)
                        check(label+'-'+source_label+'-source-line-count',spans.count()==line_count)
                        prefix=('private theorem ' if source_label=='T' else 'theorem ')+name.split('.')[-1]
                        check(label+'-'+source_label+'-correct-file-and-declaration-header',page.locator('h1').first.text_content()=='Exact source context' and raw in page.title() and raw in page.locator('[data-exact-source-file]').text_content() and page.locator('#L'+str(anchor)).text_content().strip().startswith(prefix))
                        g=page.locator('#L'+str(anchor)).evaluate(VISIBLE)
                        check(label+'-'+source_label+'-actual-anchor-visible-below-header',g['positive'] and g['top']>=g['header']-1,g)
                        shot(page,label+'-source-'+source_label+'-anchor')
                        measured=spans.evaluate_all("""xs=>xs.map(el=>{const t=el.firstChild,r=document.createRange();r.setStart(t,0);r.setEnd(t,t.textContent.trimEnd().length);const b=r.getBoundingClientRect(),q=el.getBoundingClientRect();return{id:el.id,textWidth:b.width,lineHeight:q.height};})""")
                        check(label+'-'+source_label+'-all-source-lines-have-real-layout',len(measured)==line_count and all(x['lineHeight']>0 for x in measured),measured)
                        widest=max(measured,key=lambda x:x['textWidth']);glyph=page.locator('#'+widest['id']).evaluate(GLYPH,'rightmost')
                        check(label+'-'+source_label+'-widest-line-final-full-codepoint-visible',glyph['visible'] and glyph['lineVisible'],glyph)
                        if glyph['container']['max']>1:shot(page,label+'-source-'+source_label+'-widest-right-glyph')
                        bottom=page.locator('#L'+str(line_count)).evaluate(GLYPH,'targeted')
                        check(label+'-'+source_label+'-bottom-full-codepoint-visible',bottom['visible'] and bottom['lineVisible'],bottom)
                        if source_label=='T':shot(page,label+'-source-T-bottom')
                        copy=page.locator('.native-source-context button[data-lean-copy]');check(label+'-'+source_label+'-complete-source-copy-present',copy.count()==1)
                        copy.click();check(label+'-'+source_label+'-actual-complete-source-copy-exact',page.evaluate('navigator.clipboard.readText()').encode()==exact)
                        layout('source-'+source_label)
                    except Exception:
                        check(label+'-'+source_label+'-source-stage-completed',False,traceback.format_exc());shot(page,label+'-source-'+source_label+'-failure')

                try:
                    goto('source-index.html');links=page.locator('main li a')
                    check(label+'-source-index-four-exact-labels',links.all_text_contents()==[x[2] for x in SOURCES])
                    check(label+'-source-index-private-T-explicitly-not-public','associated private application; no public node' in links.nth(1).locator('..').text_content())
                    shot(page,label+'-source-index',full=True)
                    for i,(_,raw,name,anchor,_) in enumerate(SOURCES):
                        goto('source-index.html');link=page.locator('main li a').nth(i)
                        with page.expect_navigation(wait_until='networkidle'):link.click()
                        check(label+'-source-index-link'+str(i)+'-actual-exact-anchor',page.url.endswith(raw+'.html#L'+str(anchor)) and page.locator('#L'+str(anchor)).count()==1)
                    goto('parent-context.html');main_content=page.locator('main')
                    check(label+'-public-P-no-ASTIS-parent-private-T-three-real-parents','only Mathlib parents; no ASTIS mathematical parent is claimed' in main_content.text_content() and main_content.locator('li a').all_text_contents()==[P,SOURCES[2][2],SOURCES[3][2]] and 'It has no separate public theorem node' in main_content.text_content())
                    shot(page,label+'-parent-context',full=True)
                    graph=context.request.get(origin+'/data/underlying-lean-graph.json').json()
                    nodes={n['id']:n for n in graph['nodes']};edges={(e['source'],e['target'],e['relation']) for e in graph['edges']}
                    modules=[x[1][:-5].replace('/','.') for x in SOURCES]
                    check(label+'-exact-bounded-graph-node-identity',set(nodes)=={'module:'+m for m in modules}|{'decl:'+x[2] for x in [SOURCES[0],SOURCES[2],SOURCES[3]]})
                    check(label+'-no-public-private-T-declaration-node',not any(T.split('.')[-1] in n for n in nodes))
                    expected_edges={('module:'+m,'module:'+modules[1],'imports') for m in [modules[0],modules[2],modules[3]]}|{('module:'+m,'decl:'+name,'declares') for m,name in [(modules[0],P),(modules[2],SOURCES[2][2]),(modules[3],SOURCES[3][2])]}|{('decl:'+name,'module:'+modules[1],'source reference (scanner)') for name in [P,SOURCES[2][2],SOURCES[3][2]]}
                    check(label+'-exact-solid-structure-and-reference-overlay-truth',edges==expected_edges and not any(e[1]=='decl:'+P and e[0].startswith('decl:') for e in edges))
                    for source_label,raw,name,anchor,_ in [SOURCES[0],SOURCES[2],SOURCES[3]]:
                        goto('lean-foundations.html?view=lean&focus='+quote('decl:'+name,safe=''))
                        page.wait_for_selector('.ulg-node.selected')
                        check(label+'-graph-'+source_label+'-actual-focus',page.locator('.ulg-node.selected').get_attribute('data-id')=='decl:'+name)
                        measured=zoom_pan_actual_ui(page,page.locator('.ulg-node.selected'))
                        check(label+'-graph-'+source_label+'-native-wheel-pointer-exercised',measured['native_pointer_and_wheel_exercised'],measured)
                        check(label+'-graph-'+source_label+'-node-and-core-label-inside-actual-SVG-clip',measured['core_label_readable_inside_actual_SVG_clip'],measured)
                        shot(page,label+'-graph-'+source_label+'-actual-node-viewport')
                        styles=page.locator('path.ulg-edge').evaluate_all("xs=>xs.map(e=>({formal:e.classList.contains('formal-edge'),overlay:e.classList.contains('overlay-edge'),dash:getComputedStyle(e).strokeDasharray}))")
                        check(label+'-graph-'+source_label+'-formal-solid-reference-dashed',any(x['formal'] and x['dash']=='none' for x in styles) and any(x['overlay'] and x['dash']!='none' for x in styles),styles)
                        detail=page.locator('[data-graph-detail]');heading=detail.locator('header h2')
                        check(label+'-graph-'+source_label+'-full-exact-ID-in-detail',heading.text_content()==name)
                        scroll_center(heading);visible=heading.evaluate(VISIBLE)
                        check(label+'-graph-'+source_label+'-full-ID-detail-real-visible-area',visible['positive'] and visible['intersectionHeight']>=min(visible['height']-1,120),visible)
                        if source_label=='P':shot(page,label+'-graph-P-full-ID-detail')
                        link=detail.locator('.ulg-links a.primary').first;expected=nodes['decl:'+name]['url']
                        check(label+'-graph-'+source_label+'-exact-local-context-link',link.get_attribute('href')==expected)
                        with page.expect_navigation(wait_until='networkidle'):link.click()
                        check(label+'-graph-'+source_label+'-actual-context-navigation',page.url==urljoin(origin+'/',expected))
                        if source_label=='P':
                            page.wait_for_function('!!(window.MathJax&&MathJax.startup&&MathJax.startup.promise)')
                            page.evaluate('async()=>{await MathJax.startup.promise;await MathJax.typesetPromise();}')
                            canonical=page.locator('article.proof-reader')
                            check(label+'-canonical-P-reader-same-five-folds-initially-closed',canonical.locator('details.proof-reader-step').evaluate_all('(xs)=>xs.length===5&&xs.every(x=>!x.open)'))
                            check(label+'-canonical-P-reader-rendered-main-formula',canonical.locator('.reader-main-equation mjx-container').count()>0 and page.locator('mjx-merror,[data-mjx-error]').count()==0)
                            check(label+'-canonical-P-reader-exact-five-source-spans',canonical.locator('details.proof-reader-step pre.code-block>code').all_text_contents()==[s['lean'] for s in unit['steps']])
                    layout('final-context')
                except Exception:
                    check(label+'-source-index-parent-graph-stage-completed',False,traceback.format_exc());shot(page,label+'-graph-stage-failure')
                context.close()
            browser.close()
    except Exception:
        check('browser-stage-completed',False,traceback.format_exc())
    finally:
        server.shutdown();server.server_close();worker.join()
    check('fixture-file-set-unchanged',fixture_paths()=={row['path'] for row in selected['files']})
    for row in selected['files']:check('fixture-unchanged:'+row['path'],sha(fixture/row['path'])==row['sha256'])
    check('no-external-browser-requests',not blocked,blocked);check('no-page-javascript-errors',not errors,errors)
    check('no-console-errors',not [x for x in console if x['type']=='error'],console)
    check('no-HTTP-error-responses',not [x for x in responses if x['status']>=400],responses)
    result={'schema':'r16-independent-actual-isolated-reader-result-v1','actual_preview_root':str(preview),'preview_manifest_sha256':sha(manifest_path),'source_reviewed_binding':a['source_reviewed_publication_binding_sha256'],'mathematical_commit':manifest['proof_commit'],'actual_assignment_sha256':sha(args.assignment),'runner_sha256':sha(__file__),'checks':checks,'screenshots':screenshots,'requests':requests,'responses':responses,'console':console,'page_errors':errors,'blocked_external_requests':blocked,'actual_Chrome_version':version,'browser_started':started,'status':'ENV_BLOCKED' if not started else 'PASS' if all(x['pass'] for x in checks) else 'FAIL','all_screenshots_are_actual_full_viewport_or_full_page_no_optional_crops':True,'old_packet_acceptance_inherited':False,'render_executed_by_this_checker':False,'normal_API_Lean_production_Git_shared_writes':0,'server_and_worker_stopped':True,'independent_visual_acceptance':'PENDING actual PNG review; check flags alone are not independent acceptance'}
    dump(OWN/'actual-result.json',result)
    print(json.dumps({'status':result['status'],'checks':len(checks),'false_checks':[x['name'] for x in checks if not x['pass']],'actual_PNGs':len(screenshots),'actual_result_sha256':sha(OWN/'actual-result.json')}))
    return 0 if result['status']=='PASS' else 2 if result['status']=='ENV_BLOCKED' else 1

def captured():
    args=parse()
    if not args.assignment.is_file():raise RuntimeError('Preparation only: no ROOT post-source-review execution assignment. No browser/render/server may start.')
    a=json.loads(args.assignment.read_text())
    if a.get('authorization')!='ROOT_AUTHORIZED_AFTER_SOURCE_REVIEW':raise RuntimeError('ROOT post-review authorization required before browser execution.')
    process=OWN/'runtime-process';process.mkdir(exist_ok=False)
    out=process/'stdout.raw';err=process/'stderr.raw';sys.stdout.flush();sys.stderr.flush()
    o=out.open('xb',buffering=0);e=err.open('xb',buffering=0);os.dup2(o.fileno(),1);os.dup2(e.fileno(),2);o.close();e.close()
    start=time.monotonic();started=dt.datetime.now(dt.timezone.utc).isoformat();code=1;exception=None
    try:code=main(args,a)
    except BaseException as ex:exception={'type':type(ex).__name__,'message':str(ex)};traceback.print_exc();code=130 if isinstance(ex,KeyboardInterrupt) else 1
    sys.stdout.flush();sys.stderr.flush()
    dump(process/'receipt.json',{'schema':'r16-actual-reader-OS-process-receipt-v1','argv':[sys.executable,*sys.argv],'cwd':str(Path.cwd()),'pid':os.getpid(),'ppid':os.getppid(),'started_utc':started,'ended_utc':dt.datetime.now(dt.timezone.utc).isoformat(),'elapsed_seconds':time.monotonic()-start,'actual_exit_code':code,'exception':exception,'stdout':{'path':str(out.relative_to(OWN)),'bytes':out.stat().st_size,'sha256':sha(out)},'stderr':{'path':str(err.relative_to(OWN)),'bytes':err.stat().st_size,'sha256':sha(err)},'runner_sha256':sha(__file__),'assignment_sha256':sha(args.assignment),'actual_result_sha256':sha(OWN/'actual-result.json') if (OWN/'actual-result.json').exists() else None,'actual_OS_fd1_fd2_until_exit':True,'no_reconstructed_success_receipt':True})
    return code

if __name__=='__main__':sys.exit(captured())
