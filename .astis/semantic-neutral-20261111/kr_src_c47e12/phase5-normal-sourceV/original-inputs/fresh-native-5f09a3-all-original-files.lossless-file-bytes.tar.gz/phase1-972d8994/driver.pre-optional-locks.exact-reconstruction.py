from pathlib import Path
import subprocess, json, hashlib, datetime, os, time

REPO=Path('/Users/zhouhuanjian/ASTIS-GC')
PHASE=Path(__file__).resolve().parent
CAND='972d8994a816bc63d2dd6fb2db1c2c638fa9a48f'
LEAN='/Users/zhouhuanjian/.elan/toolchains/leanprover--lean4---v4.33.0/bin/lean'
def sha(data): return hashlib.sha256(data).hexdigest()
def run(argv, tag, cwd=REPO, env=None, timeout=300):
    start=datetime.datetime.now(datetime.timezone.utc).isoformat(); clock=time.monotonic()
    p=subprocess.run(argv,cwd=cwd,env=env,capture_output=True,timeout=timeout)
    i=len(list((PHASE/'logs').glob('*.json'))) if (PHASE/'logs').exists() else 0
    d=PHASE/'logs'; d.mkdir(exist_ok=True)
    (d/f'{i:03d}-{tag}.stdout').write_bytes(p.stdout)
    (d/f'{i:03d}-{tag}.stderr').write_bytes(p.stderr)
    rec={'argv':list(map(str,argv)),'cwd':str(cwd),'env_overrides':env,'start_utc':start,'duration_seconds':time.monotonic()-clock,'exit_code':p.returncode,'stdout_sha256':sha(p.stdout),'stderr_sha256':sha(p.stderr),'stdout_file':f'logs/{i:03d}-{tag}.stdout','stderr_file':f'logs/{i:03d}-{tag}.stderr'}
    (d/f'{i:03d}-{tag}.json').write_text(json.dumps(rec,indent=2)+'\n')
    print(tag,p.returncode,len(p.stdout),p.stderr.decode()[:1000],flush=True)
    return p
def extract(path):
    p=run(['git','show',CAND+':'+path],'extract-'+Path(path).name)
    if p.returncode: raise RuntimeError(path)
    target=PHASE/'candidate'/path; target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(p.stdout)
    return p.stdout
def native_env():
    mf=json.loads((REPO/'lake-manifest.json').read_text())
    roots=[str(PHASE/'lib')]+[str(REPO/mf['packagesDir']/p['name']/'.lake/build/lib/lean') for p in mf['packages'] if (REPO/mf['packagesDir']/p['name']/'.lake/build/lib/lean').is_dir()]
    # Deliberately do not inherit ambient Lean/Lake/dynamic-library setup.
    return {'HOME':str(Path.home()),'PATH':'/usr/bin:/bin:/usr/sbin:/sbin','LANG':'en_US.UTF-8','LEAN_PATH':':'.join(roots)}
def preflight(label):
    run([LEAN,'--version'],label+'-version')
    mf=(REPO/'lake-manifest.json').read_bytes()
    rows=[]
    for p in json.loads(mf)['packages']:
        d=REPO/'.lake/packages'/p['name']; h=run(['git','-C',str(d),'rev-parse','HEAD'],label+'-'+p['name']+'-head'); s=run(['git','-C',str(d),'status','--porcelain=v1','--untracked-files=all','--ignore-submodules=none'],label+'-'+p['name']+'-status')
        rows.append({'name':p['name'],'head':h.stdout.decode().strip(),'expected':p['rev'],'head_exit':h.returncode,'status_exit':s.returncode,'status':s.stdout.decode()})
    r={'lean_sha256':sha(Path(LEAN).read_bytes()),'manifest_sha256':sha(mf),'dependencies':rows,'native_env':native_env()}
    (PHASE/(label+'-environment.json')).write_text(json.dumps(r,indent=2)+'\n')
    assert r['lean_sha256']=='1b370cfcbf44e80d1b004ab1b1ab9a4c73951f9f7c242140bcff9bc577576554'
    assert r['manifest_sha256']=='b83ca83b9cf7caa85fa8b023c2ff9a3fb7a7cce7e1c332e810c348535ec49c37'
    assert all(x['head']==x['expected'] and x['head_exit']==0 and x['status_exit']==0 and x['status']=='' for x in rows)
def build(path):
    src=PHASE/'candidate'/path; obj=PHASE/'lib'/Path(path).with_suffix('.olean'); obj.parent.mkdir(parents=True,exist_ok=True)
    p=run([LEAN,'--root='+str(PHASE/'candidate'),'-o',str(obj),'-i',str(obj.with_suffix('.ilean')),str(src)],'native-'+Path(path).stem,cwd=PHASE/'candidate',env=native_env())
    if p.returncode: raise RuntimeError('native build failed: '+path)
    return obj
if __name__=='__main__':
    preflight('before-native')
    sealpath='research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-krylov-range-statement-seal.json'
    # Avoid retaining the full seal or exposing unrelated fields in the command log.
    p=subprocess.run(['git','show',CAND+':'+sealpath],cwd=REPO,capture_output=True)
    assert p.returncode==0 and sha(p.stdout)=='f47e23a601d1a8e0ff4760224676313e0f1999877a97156841a65c01847e5d82'
    seal=json.loads(p.stdout); allowed={'name','planned_file','signature','signature_sha256'}
    filtered={k:{a:b for a,b in seal[k].items() if a in allowed} for k in ['producer','actual_private_consumer']}
    (PHASE/'filtered-statement-seal.json').write_text(json.dumps({'candidate':CAND,'original_path':sealpath,'original_sha256':sha(p.stdout),'git_show_argv':['git','show',CAND+':'+sealpath],'exit_code':p.returncode,'stderr':p.stderr.decode(),'filtered_fields':filtered},ensure_ascii=False,indent=2)+'\n')
    for path in ['AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumKrylovRange.lean','Tests/GaussianComplexityFixedSpectrumKrylovRange.lean']:
        build(path)
