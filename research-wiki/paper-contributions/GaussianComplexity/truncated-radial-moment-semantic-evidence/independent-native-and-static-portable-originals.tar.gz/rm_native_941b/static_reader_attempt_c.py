from dataclasses import dataclass, field
from hashlib import sha256
from html.parser import HTMLParser
import json
from pathlib import Path
import re
import sys
from urllib.parse import urlsplit

from native import out, repo, candidate, blobs, proof, consumer, seal_path, map_path, slug, write_blob

renderer_paths = [f'tools/{name}.py' for name in (
    'astis_site', 'astis_source', 'astis_publication', 'astis_frontier_cells', 'astis_semantic_roundtrip', 'astis_semantic_roundtrip_core',
)] + [f'website/scripts/{name}.py' for name in (
    'declaration_lessons', 'inline_lean', 'publication_reader', 'source_lineage', 'samplewiki_navigation',
    'formalization_progress', 'library_shelves', 'cross_domain', 'discrete_sampling', 'mcmc_library',
)]
cell_id = 'ASTIS-SW-GAUSSIAN-COMPLEXITY-truncated-radial-moment'
cell_path = f'research-wiki/frontier-cells/{cell_id}.json'
assertion = {}
void_tags = set('area base br col embed hr img input link meta param source track wbr'.split())


def require(name, condition):
    assertion[name] = bool(condition)
    print(f'{name}: {bool(condition)}', flush=True)
    assert condition, name


def digest(data):
    return sha256(data).hexdigest()


@dataclass
class Element:
    tag: str
    attrs: dict = field(default_factory=dict)
    children: list = field(default_factory=list)
    start: int = 0
    end: int = 0

    def find(self, tag=None, **attrs):
        for child in self.children:
            if isinstance(child, str):
                continue
            if (tag is None or child.tag == tag) and all(child.attrs.get(k) == v for k, v in attrs.items()):
                yield child
            yield from child.find(tag, **attrs)

    def text(self):
        return ''.join(c if isinstance(c, str) else c.text() for c in self.children)


class Tree(HTMLParser):
    def __init__(self, text):
        super().__init__(convert_charrefs=True)
        self.starts = [0, *(m.end() for m in re.finditer('\n', text))]
        self.stack = [Element('root')]
        self.feed(text)
        self.close()

    def absolute_char(self):
        line, column = self.getpos()
        return self.starts[line - 1] + column

    def handle_starttag(self, tag, attrs):
        node = Element(tag, dict(attrs), start=self.absolute_char())
        self.stack[-1].children.append(node)
        if tag not in void_tags:
            self.stack.append(node)

    def handle_startendtag(self, tag, attrs):
        self.stack[-1].children.append(Element(tag, dict(attrs), start=self.absolute_char(), end=self.absolute_char() + len(self.get_starttag_text())))

    def handle_endtag(self, tag):
        for i in range(len(self.stack) - 1, 0, -1):
            if self.stack[i].tag == tag:
                self.stack[i].end = self.absolute_char() + len(tag) + 3
                del self.stack[i:]
                return

    def handle_data(self, data):
        self.stack[-1].children.append(data)

    @property
    def root(self):
        return self.stack[0]


def unique(items):
    assert len(items) == 1, len(items)
    return items[0]


def only(iterator):
    return unique(list(iterator))


def check_source_span(raw, source_tree, x, family):
    a, b = x['char_start'], x['char_end']
    p, q = x['raw_utf8_start'], x['raw_utf8_end']
    key = x['source_id']
    node = only(source_tree.root.find(id=key.split('#')[0]))
    require(f'{family} {key} anchor enclosure', node.start <= a < b <= node.end)
    if '#' not in key:
        require(f'{family} {key} whole HTML anchor', a == node.start and b == node.end)
    else:
        # These five locators are byte-exact pieces of the anchor's TeX
        # annotation or alttext, rather than independent DOM fragment IDs.
        require(f'{family} {key} parent TeX locator', 'ltx_Math' in node.attrs['class'])
    require(f'{family} {key} UTF-8 and SHA256', raw.encode()[p:q] == raw[a:b].encode() and len(raw[:a].encode()) == p and digest(raw.encode()[p:q]) == x['span_sha256'])
    require(f'{family} {key} LF lines and column', raw.count('\n', 0, a) + 1 == x['lf_line_start'] and a - raw.rfind('\n', 0, a) - 1 == x['lf_column0_start'] and raw.count('\n', 0, b - 1) + 1 == x['lf_line_end'])


def verify_map(seal, source_map):
    raw_bytes = (out / '2610.20492v1.html').read_bytes()
    raw = raw_bytes.decode()
    source_tree = Tree(raw)
    require('map and seal source SHA256', digest(raw_bytes) == source_map['source_sha256'] == seal['source']['raw_sha256'])
    for x in seal['source']['anchors']:
        check_source_span(raw, source_tree, x, 'seal')
    for i, mapping in enumerate(source_map['mappings'], 1):
        for x in mapping['source']:
            check_source_span(raw, source_tree, x, f'map {i}')
        for x in mapping['lean']:
            path = x['path']
            byte_data = (blobs / path).read_bytes()
            char_data = byte_data.decode()
            start, end = x['LF_lines_1based']
            data_lines = char_data.splitlines(keepends=True)
            a, b = x['decoded_char_span']
            p, q = x['raw_UTF8_byte_span']
            require(f'map {i} {Path(path).name} L{start}–{end}',
                    digest(byte_data) == x['file_sha256'] and digest(byte_data[p:q]) == x['span_sha256']
                    and len(char_data[:a].encode()) == p and len(char_data[:b].encode()) == q
                    and byte_data[p:q] == char_data[a:b].encode()
                    and char_data[a:b] == ''.join(data_lines[start - 1:end]))


def main():
    renderer_hashes = {path: write_blob(path) for path in [*renderer_paths, cell_path]}
    sys.path[:0] = [str(blobs / 'website/scripts'), str(blobs / 'tools')]
    import astis_site
    import astis_publication
    import declaration_lessons
    import publication_reader
    import source_lineage

    seal = json.loads((blobs / seal_path).read_text())
    source_map = json.loads((blobs / map_path).read_text())
    site = out / 'static-site'
    page = f'proofs/source-{slug}.html'
    chapter = f'example-cases/samplewiki/companions/gaussian-sampling-complexity.html'
    producer = seal['producer']['name']
    modules, decls = astis_site.scan_project_sources()
    declarations = {d.full_name: d for d in decls}
    unit, = declaration_lessons.load_units()
    item, = astis_publication.load()
    actual_cell = json.loads((blobs / cell_path).read_text())
    # The only runtime data adapter is the narrow publication inventory. No
    # prior actor semantic review record is supplied or read by this lane.
    bounded = {'declarations': declarations, 'lessons': {producer: unit}, 'cells': {cell_id: actual_cell}, 'audits': {}}
    astis_publication.inputs = lambda: bounded
    astis_site._ACTIVE_GIT = astis_site.GitContext(candidate, candidate[:12], '', '', False, False, set())
    astis_site._ACTIVE_GATE = astis_site.GateEvidence(False, False, candidate, '', '', [], 'Bounded static preview.')
    theme = site / 'textbook/index.html'
    theme.parent.mkdir(parents=True, exist_ok=True)
    theme.write_text('<html lang="en"><head><link rel="stylesheet" href="../assets/site.css"><link rel="stylesheet" href="../assets/information-architecture.css"></head><body></body></html>\n')
    require('exact bounded input identity', unit['declaration'] == producer and item['id'] == slug and item['chapter_path'] == chapter and publication_reader.source_proof_path(item) == page)
    proof_html = publication_reader.source_card(item, page)
    focused = astis_site.page(item['title'], page, proof_html, active='SampleWiki', extra_head='<link rel="stylesheet" href="../assets/proof-readers.css">')
    astis_site.write_page(site, page, source_lineage.canonical_shell(focused, page, site))
    astis_site.write_page(site, chapter, astis_site.page('Gaussian Sampling Complexity', chapter, publication_reader.companion_publication_block([item], chapter), active='SampleWiki'))
    declaration_lessons.export_sources(site, [unit])
    text = (site / page).read_text()
    parsed = Tree(text).root
    article = only(parsed.find('article', **{'data-authored-declaration': producer}))
    steps = list(article.find('details', **{'class': 'proof-reader-step reader-proof-disclosure'}))
    p = (blobs / proof).read_bytes()
    t = (blobs / consumer).read_bytes()
    require('five proof steps, each collapsed', len(steps) == 5 and all('open' not in s.attrs for s in steps))
    current_end = p.index(b'  let E :=', p.index(b':= by\n') + len(b':= by\n'))
    actual_folds = []
    for i, (node, step) in enumerate(zip(steps, unit['steps'], strict=True), 1):
        fold = only(node.find('details'))
        code = only(fold.find('code', **{'class': 'language-lean'})).text().encode()
        formula = only(node.find('div', **{'class': 'proof-reader-equation'})).text()
        require(f'fold {i} authored heading, prose, TeX and closed Lean', (
                'open' not in fold.attrs and next(node.find('summary')).text() == f'{i}. {step["title"]}'
                and only(node.find('p')).text() == step['text'] and formula == '\\[' + step['formula'] + '\\]'))
        require(f'fold {i} exact code vs authored metadata', code == step['lean'].encode())
        if i <= 4:
            begin = p.index(code)
            end = begin + len(code)
            require(f'fold {i} exact contiguous immutable producer byte span', p.count(code) == 1 and p[current_end:begin] in {b'', b'\n'})
            start_line = p.count(b'\n', 0, begin) + 1
            end_line = p.count(b'\n', 0, end - 1) + 1
            current_end = end
        else:
            require('fold 5 exact complete immutable private consumer', code == t)
            begin, end = 0, len(t)
            start_line, end_line = 1, len(t.splitlines())
        actual_folds.append({'step': i, 'lines': [start_line, end_line], 'byte_span': [begin, end], 'sha256': digest(code)})
    require('four producer folds cover full tactic body', p[current_end:].startswith(b'\nend AutoSamplingTheory.') and p[current_end:].count(b'\n') == 2)
    fold_stmt = only(article.find('details', **{'class': 'inline-lean inline-lean-statement'}))
    fold_proof = only(article.find('details', **{'class': 'inline-lean inline-lean-proof'}))
    stmt = only(fold_stmt.find('code', **{'class': 'language-lean'})).text().encode()
    exact = only(fold_proof.find('code', **{'class': 'language-lean'})).text().encode()
    decl_start = p.index(b'theorem actual_standard_row_tail_first_moment')
    decl_cut = p.index(b':= by\n')
    require('closed separate exact producer statement and full listing', 'open' not in fold_stmt.attrs and 'open' not in fold_proof.attrs and stmt == p[decl_start:decl_cut].rstrip() and exact == p[decl_start:].rstrip())
    for s in (fold_stmt, fold_proof):
        require(f'{s.attrs["class"]} static copy and download markup', 'data-lean-copy' in only(s.find('button')).attrs and only(s.find('a', download=Path(proof).name)).attrs['href'] == '../downloads/lean/' + proof)
    t_href = '../data/lesson-sources/' + consumer + '.html#L18'
    require('private consumer source link in focused page', only(article.find('a', href=t_href)).text() == 'Complete private scalar bias proof')
    target = (site / page).parent / urlsplit(t_href).path
    target_tree = Tree(target.read_text()).root
    lines = list(only(target_tree.find('pre')).find('span'))
    require('private L18 target and full export identity', len(lines) == len(t.splitlines()) and all(el.attrs['id'] == f'L{i}' and el.text().encode() == line for i, (el, line) in enumerate(zip(lines, t.splitlines(), strict=True), 1)) and lines[17].text().startswith('private theorem actual_truncated_radial_bias'))
    source = item['source']
    require('versioned paper anchor present', len(list(parsed.find('a', href=source['url']))) == 2 and source['url'].split('#')[1] == 'A3.SS2.p11')
    chapter_tree = Tree((site / chapter).read_text()).root
    require('chapter focused route generated', only(chapter_tree.find('a', href='../../../' + page)).text() == 'Read full statement and proof →')
    require('candidate local status stays unreviewed', actual_cell['status'] == 'claimed' and not astis_publication.verified_binding(item['bindings'][0], bounded))
    verify_map(seal, source_map)
    result = {'commit': candidate, 'renderer_inputs': renderer_hashes, 'renderer_methods': ['publication_reader.source_card', 'publication_reader.companion_publication_block', 'astis_site.page', 'declaration_lessons.render_unit', 'declaration_lessons.export_sources', 'source_lineage.canonical_shell'], 'assertions': assertion, 'five_folds': actual_folds, 'proof_route': page, 'private_export': 'data/lesson-sources/' + consumer + '.html'}
    (out / 'static-result.json').write_text(json.dumps(result, indent=2) + '\n')


if __name__ == '__main__':
    main()
