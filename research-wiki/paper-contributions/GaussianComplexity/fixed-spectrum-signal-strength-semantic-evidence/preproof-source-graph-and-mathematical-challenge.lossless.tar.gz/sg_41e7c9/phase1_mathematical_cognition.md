# Source-only cognition frozen before any candidate statement

This is my independent reading of the pinned original arXiv:2610.20492v1 HTML, restricted to full Section 2, full Section 4, Appendix C.3 (`A3.SS3`), and displayed bibliography entry [22]. It is a source cognition record, not a claim of Lean verification, source correction, or independently approved source coverage. No candidate signature, project definition, proof implementation, lesson, audit, frontier, sibling review, or previous verdict was read. The raw source and its formulas remain authoritative over the prose below.

## Exact source scope and extraction

The original SHA-256 is `6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915`. Exact source slices are saved as `section2.raw.html`, `section4.raw.html`, `appendixC3.raw.html`, and `bibliography22.raw.html`. Their spans are determined directly on the original UTF-8 text by a source-position HTML parser. All original MathML, `alttext`, source labels, HTML attributes, cross-reference URLs, and proof paragraphs are retained in those byte-preserving slices. Readable projections replace each MathML expression with its original `alttext`; they are convenience views, not replacement originals.

`raw_unit_inventory.json` contains 809 records: every labelled element, paragraph, displayed-equation container or row, equation group, theorem/proof environment, heading, mathematical expression, citation use, and link in the four scopes. Nested raw units are intentional: a theorem statement and each contained mathematical expression both have traceable spans. The inventory contains 350 mathematical-expression units and 86 paragraph units. Each record retains source character/byte bounds, raw HTML, and its SHA-256. The inventory is exhaustive at this raw-unit level; graph disposition and independent coverage approval belong to later stages.

Displayed bibliography [22] is `bib.bib3`, not `bib.bib22`. I initially selected `bib.bib22` by its suffix, exposed displayed [19]'s title and bibliographic metadata, then corrected the selection by following the raw Section 4 citation links. This incidental exposure supplied no mathematical argument. No cited paper itself was opened or consulted.

## Section 2: exact mathematical conventions

`S2.p1` fixes Euclidean norm, the identity matrix, and the Loewner order for symmetric matrices: `A ≼ B` means `B-A` is positive semidefinite. `S2.p2` fixes real `O(n)` with Haar probability, its determinant-sign components each of probability one half, and conditional Haar probabilities `μ_{n,b}`. The determinant-sign notation is present in this supplied scope; I do not infer that it is needed by every Section 4 result.

The target class is centered Gaussian. For integer `d ≥ 1` and `κ ≥ 1`, the precision matrices satisfy symmetry and `I_d ≼ A ≼ κ I_d` (`S2.Ex1`). The potential is `f_A(x)=xᵀAx/2`, the target is `π_A=N(0,A^{-1})`, and the first-order oracle returns `(xᵀAx/2, Ax)` (`S2.E1`, numbered (1)). The source explicitly proves exact value-and-gradient, gradient-only, and matrix-vector oracle equivalence by extracting `Ax` or computing `⟨x,Ax⟩/2`; no approximate/noisy oracle is in scope.

The randomized algorithm's query and stopping rules are Borel functions of its randomness and previous replies. Its randomness is independent of the input; its output is an arbitrary `R^d`-valued Borel function of that same information. A fixed query budget `T` caps every run for every admissible input and every realization of randomness. It is not an expected-query bound.

TV is `sup_B |P(B)-Q(B)| = (1/2)∫|p-q|dλ` (`S2.Ex2`), with measurable `B` and a common dominating measure. Every measurable `[0,1]`-valued test has expectation difference bounded by TV. `Q_G(d,κ,ε)` (`S2.E2`, numbered (2)) is the infimum of nonnegative integer fixed budgets admitting an algorithm with uniform-in-input output-law TV at most `ε`, for `0<ε<1`. The output law averages the algorithm's entire seed. These measurability, independence, worst-input, and deterministic-cap conventions cannot be silently weakened to per-seed accuracy or an average budget.

## Section 4: objects, results, and complete proof route

`S4.p1` attributes the `Ω(log d)` constant-accuracy `κ=2` centered-Gaussian lower bound to [22]. Theorem 4.1 (`S4.Thmtheorem1`) states: for every fixed `δ∈(0,1)`, there is `d₀(δ)` such that all integer `d≥d₀(δ)`, `2≤κ≤d^{1-δ}`, and `0<ε≤1/10` satisfy `Q_G(d,κ,ε) ≥ (δ/256)√κ log d` (`S4.Ex9`). It also holds with known spectrum, but does not increase as `ε→0`. The comparison to Theorem 3.1 is source context only; that theorem's body was not read.

The hard family (`S4.SS1`, equation (11), `S4.E11`) has `d≥2`, `κ≥2`, angles `θ_i=(i-1/2)π/d`, eigenvalues `λ_i=(κ+1)/2+(κ-1)cos θ_i/2`, and diagonal `Λ`. Draw Haar `O` independently of the algorithm's randomness and set `A=OΛOᵀ`. The spectrum and Gaussian normalizing constant may be known; the eigenbasis is unknown. Remark 4.2 says the `κ=2` family is recovered, and `A=(κ-1)A₂-(κ-2)I` with the same rotation, giving mutual reply simulation. It previews a high-frequency statistic with `n=2q+1`: outputs have tiny cosine coefficient while target means have bias `exp(-Θ(n/√κ))`.

Lemma 4.3 (`S4.Thmtheorem3`): for integer `q≥0`, `2q+1<d`, and output `X`, independent standard Gaussian starting vectors `g_1,…,g_{q+1}` exist so that `OᵀX∈K_q` almost surely. `K_q` is the span of `Λ^j g_a`, with `a≤q+1`, `0≤j≤q` (`S4.Ex10`). The extra start vector covers arbitrary output outside query/reply spans. The equivalent degree-at-most-`q` polynomial coefficients may depend on the full extended experiment, so pointwise-in-fixed-coefficients probability estimates are insufficient. Section 4 explicitly attributes deferred rotation to [22, Lemma 9.2] and defers its proof to C.1. I have not checked that external theorem or C.1.

Lemma 4.4 (`S4.Thmtheorem4`): for an absolute `C>0`, set `τ_{d,q}=C[(q+1)√(log d/d)+(q+1)(q+1+log d)log d/d]` (`S4.Ex13`). Under `2q+1<d`, independent standard Gaussian starts, and the conditional premise `τ≤1/2`, with probability at least .99 every `u∈K_q` obeys `|uᵀD_nu|≤2τ||u||²` (`S4.Ex14`), with `n=2q+1` and `D_n=diag(cos(nθ_i))`. Because `λ_i` is a nonconstant affine function of `cos θ_i`, cosine-basis and power-basis Krylov spans agree, and this bound is independent of `κ`. Combining the two lemmas gives the output inequality `|XᵀOD_nOᵀX|≤2τ||X||²` (`S4.Ex15`). C.2 is the deferred proof, not consulted here.

Lemma 4.5 (`S4.Thmtheorem5`) fixes `κ≥2`, `U∼N(0,Λ^{-1})`, `ρ=(√κ-1)/(√κ+1)`, integer `1≤n<d`, `M=E||U||²`, `μ_n=E[UᵀD_nU]`. It gives exact formulas (`S4.EGx1`):

`M = (d/√κ)(1-ρ^{2d})/(1+ρ^{2d})`,

`(-1)^n μ_n = (d/√κ)(ρ^n-ρ^{2d-n})/(1+ρ^{2d})`.

Both variances are at most `2M≤2d/√κ`. If `d-n≥√κ`, then `(1-e^{-4})e^{-3n/√κ}≤|μ_n|/M≤e^{-2n/√κ}` (`S4.Ex17`). Its proof is exactly the C.3 scope read below. For `Y|O∼π_A`, `U=OᵀY` has the specified diagonal Gaussian law, and norms and the cosine statistic are invariant under this rotation. That is the explicit consumer adapter from diagonal moments to target samples, not another Gaussian sampling claim.

Lemma 4.6 (`S4.Thmtheorem6`) states `I≼OΛOᵀ≼κI` for every orthogonal `O`; its proof is deferred to C.4. This is the adapter making the family admissible under the uniform oracle guarantee. C.4 was not consulted.

The proof of Theorem 4.1 (`S4.SS3`) assumes a successful algorithm with `q≤(δ/256)√κ log d`. It uses Lemma 4.6 for admissibility, sets `n=2q+1`, and defines (`S4.EGx2`) the test statistic

`S_A(x)=(-1)^n xᵀ T_n((2A-(κ+1)I)/(κ-1))x -2τ||x||²`,

and event `E_A={x:S_A(x)>0}`. The Chebyshev identity `T_n(cos θ_i)=cos(nθ_i)` identifies the polynomial matrix with `OD_nOᵀ`. The geometric explanation uses weights `|⟨x,Oe_i⟩|²/||x||²` only for `x≠0`. The event definition itself includes zero safely through a strict inequality, without a norm division.

The algorithmic branch (`S4.SS3.SSS0.Px1`) proves `q+1≤d^{(1-δ)/2}log d`, hence `n=o(d)`, and substitutes into `τ` to obtain `τ≲d^{-δ/2}(log d)^{3/2}+d^{-δ}(log d)^3≲d^{-δ/2}(log d)^3→0` (`S4.Ex20`). Thus sufficiently large `d`, depending only on `δ`, discharges `n<d` and `τ≤1/2`. Lemma 4.3 uses an extension preserving the joint law of `(O,X)`; Lemma 4.4 applies simultaneously to its whole random Krylov space. On the .99 event `S_A(X)≤0`, so `E_A[ρ_A^Alg(E_A)]≤.01` (`S4.Ex22`). Uniformity in the Krylov vector is essential because `X` depends on the experiment.

The target branch (`S4.SS3.SSS0.Px2`) puts `β=|μ_n|/M`. The parameter range yields `d-n≥√κ` eventually, discharging the conditional bias premise. Lemma 4.5 and `3n/√κ≤3+(3δ/128)log d` give `β≥b d^{-δ/4}`, `b=(1-e^{-4})e^{-3}` (`S4.Ex23`). The same lemma's mean formula, `ρ≤e^{-1/√κ}`, and `d≥√κ` give `M≥d/(2√κ)≥d^{(1+δ)/2}/2`. Consequently `τ/β→0` and `Mβ²≥(b²/2)√d→∞` (`S4.Ex24`). All estimates are explicitly uniform over the claimed parameter range, allowing a common `d₀(δ)` with `τ≤β/4` and `Mβ²≥320`.

For fixed `A` and `Y∼π_A`, set `Z=S_A(Y)`. Exact signed mean and both variance bounds imply `EZ=(β-2τ)M≥βM/2`. The centered-variable `L²` triangle inequality gives `Var Z≤(√(2M)+2τ√(2M))²≤8M` (`S4.Ex25`). Chebyshev then gives `π_A(E_A)≥1-32/(Mβ²)≥.9` (`S4.Ex26`). In the contradiction branch, the per-input TV guarantee applies to this input-dependent measurable event for each fixed `A`; averaging afterwards produces `.89≤E_A[π_A(E_A)-ρ_A^Alg(E_A)]≤ε≤.1` (`S4.Ex27`). The algorithmic and target probability branches are jointly required for this route, not alternative proofs.

Section 4.4 is substantive scope mathematics. The condition-number limitation uses Lemma 4.7 (`S4.Thmtheorem7`): `dim K_q=min{d,(q+1)²}` almost surely for independent standard Gaussian starts. Distinct eigenvalues are part of the preceding explanation. Once `(q+1)²≥d`, the space is all of `R^d`; if also `n=2q+1<d`, then `Σ_i cos²(nθ_i)=d/2`, so some coordinate gives statistic ratio at least `1/√2` (`S4.Ex29`), incompatible with a uniform upper bound of `1/2`. The paragraph says the separating test requires such a `1/2` bound; the actual theorem proof above makes `τ` much smaller eventually. I record the exact phrasing rather than replace the lemma's stated premise `τ≤1/2` with a different premise. The dimension-lemma proof is not present in the supplied C.3 scope.

The accuracy limitation requires threshold `t≥a` for the algorithmic uniform bound and `t<|μ_n|/M` for the target test. It says the Bernstein calculation in Fact C.6 requires `a≥c/√d` even to certify failure below one. Thus `c/√d≤a<|μ_n|/M≤e^{-2(2q+1)/√κ}` (`S4.Ex30`), giving `q=O(√κ log d)` independently of `ε`. Fact C.6's proof was not read, so that cited internal quantitative requirement remains an unverified out-of-scope input, not a fact established by this extraction. Remark 4.8 states only limitations of this proof; stronger fixed-spectrum lower bounds remain open.

## Appendix C.3: every proof region and its direction

The opening paragraph recalls the grid and inverse-spectrum plan. Fact C.7 (`A3.Thmtheorem7`) gives, for every real `θ`,

`2/(κ+1+(κ-1)cos θ) = (1/√κ)[1+2Σ_{j≥1}(-ρ)^j cos(jθ)]` (`A3.Ex133`),

with absolute and uniform convergence in `θ`. The subsection inherits `κ≥2`, hence `0<ρ<1`, from Lemma 4.5 and the Section 4 family; the fact's text itself explicitly quantifies only `θ`.

Its proof (`A3.SS3.p2`) first sums the two complex geometric series to obtain the rational expression `(1-ρ²)/(1+2ρ cos θ+ρ²)` (`A3.EGx14`, rows `A3.Ex134`–`A3.Ex135`). It then uses both algebraic identities in `A3.Ex136`: `(1-ρ)/(1+ρ)=1/√κ`, and the denominator divided by `(1-ρ)²` equals `(κ+1+(κ-1)cos θ)/2`. Combining gives the expansion. The majorant `Σ |(-ρ)^j cos(jθ)|≤Σρ^j=ρ/(1-ρ)` (`A3.Ex137`) establishes absolute and uniform convergence. No external citation is attached to geometric-series summation, complex-exponential identities, or the uniform-majorant step; they are mathematical inputs used by the source rather than external works I independently consulted.

Fact C.8 (`A3.Thmtheorem8`) gives the same two exact moment formulas for `1≤n<d` (`A3.Ex138`). Its proof begins with the all-integer finite-grid identity (`A3.Ex139`): the sum of `cos(kθ_i)` is `d(-1)^a` if `k=2ad`, `a∈Z`, and zero otherwise. The paragraph proves the nonmultiple case by `sin(kπ)/(2sin(kπ/(2d)))=0`, and the multiple case by direct cosine evaluation. The Gaussian second moments identify `M=Σ_i1/λ_i` and `μ_n=Σ_i cos(nθ_i)/λ_i` (`A3.Ex140`). Fact C.7 explicitly permits interchanging its absolutely convergent series with the finite grid sum.

For `M` (`A3.SS3.p5`, `A3.EGx15`, rows `A3.Ex141`–`A3.Ex143`), only positive multiples `j=2ad` survive. Summing `Σ_{a≥1}(-1)^a ρ^{2ad}` yields exactly the stated rational mean.

For `μ_n` (`A3.SS3.p6`, `A3.Ex144`), the constant mode vanishes and product-to-sum yields the two grid sums at frequencies `j-n` and `j+n`. The source classifies all surviving positive `j`: `j=n`, `j=2ad+n`, and `j=2ad-n`, with `a≥1`. The three classes are disjoint because `1≤n<d`. The grid values are `d` or `d(-1)^a`, and `(-ρ)^{2ad±n}=(-1)^nρ^{2ad±n}`. The series and its geometric summation are displayed in `A3.EGx16` (rows `A3.Ex145`–`A3.Ex147`), ending with `(d/√κ)(ρ^n-ρ^{2d-n})/(1+ρ^{2d})`. This branch is distinct from the `M` branch; both are needed for the later ratio.

The proof of Lemma 4.5 (`A3.SS3.4`) first invokes Fact C.8 for both means (`p7`). The variance paragraph (`p8`) uses diagonal-Gaussian coordinate independence, `EU_i⁴=3/λ_i²`, and `Var(U_i²)=2/λ_i²`, then `λ_i≥1`. It computes both variances separately as `2Σ1/λ_i²` and `2Σcos²(nθ_i)/λ_i²`, each at most `2M` (`A3.EGx17`, `A3.Ex148`–`A3.Ex149`). The mean formula also gives `M≤d/√κ`. There is no cited proof of the Gaussian fourth-moment or diagonal-independence facts in this subsection; they must remain explicit mathematical inputs in any exhaustive source graph.

The normalized-bias paragraph (`p9`) uses `n<d`, `0<ρ<1` to obtain `ρ^n>ρ^{2d-n}`, hence `(-1)^n μ_n>0`, and divides the exact means to get `|μ_n|/M=ρ^n(1-ρ^{2(d-n)})/(1-ρ^{2d})` (`A3.Ex150`). The fraction is between `1-ρ^{2(d-n)}` and one (`A3.Ex151`); positivity of the denominator is part of this use.

The logarithm paragraph (`p10`) derives `log(1/ρ)=log((√κ+1)/(√κ-1))=2∫_0^{1/√κ}(1-t²)^{-1}dt=2/√κ+2∫_0^{1/√κ}t²/(1-t²)dt` (`A3.EGx18`, rows `A3.Ex152`–`A3.Ex154`). Nonnegativity gives the lower bound `2/√κ`. Using `1-t²≥1-κ^{-1}` and `κ≥2` yields the upper bound `2/√κ(1+1/[3(κ-1)])≤8/(3√κ)<3/√κ` (`A3.EGx19`, `A3.Ex155`–`A3.Ex156`). Exponentiation gives `e^{-3n/√κ}≤ρ^n≤e^{-2n/√κ}` (`A3.Ex157`). The integral/log identity and elementary integration are used by the source without citation and are not independently certified here.

The final paragraph (`p11`) explicitly assumes `d-n≥√κ`; it uses the lower logarithmic bound to obtain `ρ^{2(d-n)}≤e^{-4(d-n)/√κ}≤e^{-4}` (`A3.Ex158`). Combining the ratio fraction with the power bounds proves `(1-e^{-4})e^{-3n/√κ}≤|μ_n|/M≤e^{-2n/√κ}` (`A3.Ex159`). The additional distance-to-grid-edge premise is required for the fixed constant `1-e^{-4}`; the unconditional exact moments and variance estimates do not depend on that premise.

## Preliminary source topology, before a sealed candidate exists

The source structure is: Section 2 conventions → Section 4 hard family; hard family plus oracle conventions and external deferred-rotation input → Lemma 4.3; independent Gaussian starts plus high-frequency cosine structure → Lemma 4.4; inverse-spectrum expansion + grid orthogonality + Gaussian second moments → Fact C.8; Fact C.8 plus Gaussian fourth moments/independence and elementary spectral bounds → the exact-mean/variance part of Lemma 4.5; Fact C.8 plus positive-power ordering + logarithm/power estimates + `d-n≥√κ` → its conditional bias part. Lemmas 4.3 and 4.4 meet at the algorithmic probability branch; Lemma 4.5 and orthogonal target transport meet at the target probability branch; Lemma 4.6 supplies admissibility; both probability branches and uniform per-input TV meet at the contradiction proving Theorem 4.1.

Section 4.4 branches into two limitations and does not prove a stronger lower bound: dimension saturation plus a coordinate cosine witness obstructs the uniform-space method, and the Fact C.6 threshold floor plus target-bias upper bound obstructs accuracy growth for the present test. Theorem 3.1 is a comparison reference, not a proof prerequisite inferred from adjacent prose. Bibliographic cited-by backlinks are navigation, not proof-direction edges. There are no alternative OR proof routes explicitly developed in the supplied source slice. Any implementation alternative must be recorded separately and cannot overwrite this source route.

## Provenance, limits, and exposure declaration

The only mathematical content consulted is the four original source scopes plus the incidental [19] bibliography metadata already disclosed. I read the specified repository operating/semantic protocols as process instructions. I did not read `website/content`, Lean sources, Mathlib, local source-correspondence/index content, other `.astis` directories, other reviewers, candidate files, audits, lessons, frontiers, or previous verdicts. I did not inspect or infer a selected target from the neutral output directory name. No code search, proof search, compilation, external web consultation, external-paper consultation, or canonical-state mutation occurred. The helper script imports installed BeautifulSoup via `/opt/anaconda3/bin/python` and writes solely in this owned directory.

In particular, [22] is only bibliographic attribution to OpenAI (2026), *Subpolynomial query complexity for well-conditioned log-concave sampling*, with the exact original link retained in the raw entry. Its Section 9.2 and Lemma 9.2 have not been read or checked. C.1, C.2, C.4, Fact C.6, the proof of Lemma 4.7, and Theorem 3.1 are out-of-scope source references, not proved in this cognition record. I do not manufacture their precise assumptions or proof interiors. Any graph node using them must preserve that consultation limit.

This phase-1 freeze precedes receipt of the strictly minimal sealed-statement/definition projection. It does not approve a candidate, certify implementation dependency, approve my own coverage, or replace the required distinct topology/global closure reviewer.
