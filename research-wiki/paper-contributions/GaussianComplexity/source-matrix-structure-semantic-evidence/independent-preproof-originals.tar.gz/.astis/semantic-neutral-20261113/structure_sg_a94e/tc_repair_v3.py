from pathlib import Path
import copy, datetime, difflib, hashlib, json

OUT=Path(__file__).resolve().parent
def sha(p): return hashlib.sha256((OUT/p).read_bytes()).hexdigest()
def write(name,obj):
    p=OUT/name
    if p.exists(): raise RuntimeError(f'Will not overwrite existing successor {name}')
    p.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
oldgraph='source-graph.source-only.v2.json'
oldcoverage='source-coverage.RAWFIRST.v1.json'
oldports='internal-obligation-ports.v2.json'
assert sha(oldgraph)=='894d743f6b9c7234f700addc71724f032d8025927b88936ad7f79e7c8430b925'
assert sha(oldcoverage)=='57e10a38bf7ca3aaf8221d923abd95e640c14279991d90d0ac214f1098936bec'
assert sha(oldports)=='8bd8d3e3a6ca74922593a61e04f58fe500f37c7c81298737f1fdb079af5c22db'
oldhashes={p:sha(p) for p in [oldgraph,oldcoverage,oldports]}
g=json.loads((OUT/oldgraph).read_text())
c=json.loads((OUT/oldcoverage).read_text())
p=json.loads((OUT/oldports).read_text())
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
drop={'A3.SS2.p14.6','A3.Ex120'}
for n in g['nodes']:
    if n['id']=='weighted-Z':
        assert {a['source_id'] for a in n['source_anchors']}=={'A3.SS2.p13.3',*drop}
        n['source_anchors']=[a for a in n['source_anchors'] if a['source_id'] not in drop]
g['version']='source-only-v3-explicit-variance-exclusion'
g['created_utc']=now
g['successor_of']={'path':oldgraph,'sha256':oldhashes[oldgraph],
 'delta':'Remove p14.6 and Ex120 anchors from weighted-Z. Their substantive variance claims are explicitly EXCLUDED in source-coverage.source-only.v3.json. The family remains identified at p13.3. No statements, nodes, edges, proof routes, source premises or target signatures change.'}
write('source-graph.source-only.v3.json',g)

for b in c['blocks']:
    if b['id'] in drop:
        b['disposition']='EXCLUDED'
        b.pop('node_ids',None); b.pop('note',None)
        b['reason']=('Quantitative variance comparison for the weighted centered sequence, including the assertion that its variance parameter is no larger and the displayed equality/positive-semidefinite inequality E[(cos(n theta_i) Z_i)^2] = cos^2(n theta_i) E[Z_i^2] <= E[Z_i^2]. These variance claims are outside the bounded p15 first structural assertion; the weighted family itself is already identified at p13.3.')
c['counts']={'total':len(c['blocks']),'NODE':sum(b['disposition']=='NODE' for b in c['blocks']),
             'EXCLUDED':sum(b['disposition']=='EXCLUDED' for b in c['blocks'])}
c['version']='source-only-v3-explicit-variance-exclusion'
c['successor_of']={'path':oldcoverage,'sha256':oldhashes[oldcoverage],
 'delta':'Only p14.6 and Ex120 change from NODE to explicit EXCLUDED variance claims; original locators/hashes and all other block/fragment dispositions are preserved.'}
write('source-coverage.source-only.v3.json',c)

p['version']='source-only-v3-exact-graph-coverage-binding'
p['source_graph_path']='source-graph.source-only.v3.json'
p['source_graph_sha256']=sha('source-graph.source-only.v3.json')
p['source_coverage_path']='source-coverage.source-only.v3.json'
p['source_coverage_sha256']=sha('source-coverage.source-only.v3.json')
p['successor_of']={'path':oldports,'sha256':oldhashes[oldports],
 'delta':'Correct stale graph binding from raw-first v1 to exact proposed v3 graph and add exact proposed v3 coverage binding. All seven mathematical port bodies are unchanged.'}
write('internal-obligation-ports.v3.json',p)

diffpairs=[(oldgraph,'source-graph.source-only.v3.json'),(oldcoverage,'source-coverage.source-only.v3.json'),(oldports,'internal-obligation-ports.v3.json')]
diff=''.join(''.join(difflib.unified_diff((OUT/a).read_text().splitlines(keepends=True),(OUT/b).read_text().splitlines(keepends=True),fromfile=a,tofile=b)) for a,b in diffpairs)
(OUT/'tc-repair-v3.exact.diff').write_text(diff)

# Machine-check the bounded delta independently of the readable unified diff.
oldg=json.loads((OUT/oldgraph).read_text()); oldc=json.loads((OUT/oldcoverage).read_text()); oldp=json.loads((OUT/oldports).read_text())
assert len(g['nodes'])==len(oldg['nodes']) and g['edges']==oldg['edges']
for a,b in zip(oldg['nodes'],g['nodes']):
    if a['id']=='weighted-Z':
        aa=copy.deepcopy(a);aa['source_anchors']=[x for x in aa['source_anchors'] if x['source_id'] not in drop];assert aa==b
    else: assert a==b
changed=[]
for a,b in zip(oldc['blocks'],c['blocks']):
    if a!=b:
        assert a['id'] in drop
        for k in ['id','tag','char_start','char_end_exclusive','byte_start','byte_end_exclusive','line_start_1based','line_end_1based','raw_sha256']: assert a[k]==b[k]
        changed.append(a['id'])
assert set(changed)==drop
assert c['mixed_paragraph_fragments']==oldc['mixed_paragraph_fragments']
assert p['ports']==oldp['ports'] and p['seal_sha256']==oldp['seal_sha256']
assert p['source_graph_sha256']==sha(p['source_graph_path'])
assert p['source_coverage_sha256']==sha(p['source_coverage_path'])
assert oldhashes=={f:sha(f) for f in oldhashes}
nodeids={n['id'] for n in g['nodes']}
for n in g['nodes']:
    assert all(a['source_id'] not in drop for a in n['source_anchors'])
for b in c['blocks']:
    if b['disposition']=='NODE': assert set(b.get('node_ids',[]))<=nodeids
    else: assert 'node_ids' not in b
check={'created_utc':now,'status':'PASS-bounded-delta-and-exact-bindings-only; distinct TC re-review pending',
 'old_inputs_unchanged':oldhashes,'coverage_changed_ids':changed,'coverage_counts':c['counts'],
 'graph_node_count':len(g['nodes']),'graph_edges_unchanged':True,'port_bodies_unchanged':True,
 'source_graph_sha256':p['source_graph_sha256'],'source_coverage_sha256':p['source_coverage_sha256'],
 'current_ports_sha256':sha('internal-obligation-ports.v3.json'),
 'seal_sha256':p['seal_sha256'],'no_claim':'No target proof, new premise, mathematical/source verdict, or topology self-approval.'}
write('tc-repair-v3.check.json',check)
print(json.dumps(check,indent=2))
