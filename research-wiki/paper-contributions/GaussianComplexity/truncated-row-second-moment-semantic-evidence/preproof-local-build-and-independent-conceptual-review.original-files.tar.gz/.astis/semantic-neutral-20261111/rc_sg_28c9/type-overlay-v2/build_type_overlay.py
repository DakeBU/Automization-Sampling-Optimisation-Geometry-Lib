from pathlib import Path
import hashlib,json
from datetime import datetime,timezone
BASE=Path('/Users/zhouhuanjian/ASTIS-GC')
RAWFREEZE=BASE/'.astis/semantic-neutral-20261111/rc_sg_28c9'
OUT=RAWFREEZE/'type-overlay-v2'
IN=BASE/'.astis/huanjian-gc-truncated-radial-covariance-20261111/selective-type-definition-packet-v2.json'
H=lambda b:hashlib.sha256(b).hexdigest()
b=IN.read_bytes();assert H(b)=='ca055c5b2b92df9c5426ff2ddcf8d91677971381a5f309320a3859be6235ee8b'
p=json.loads(b)
assert p['statement_seal_sha256']=='ee9d261db9301f0fa750102f8105c27fbbbcef9e8a19f900636b705f461b18dd'
assert p['minimal_definition_context_sha256']=='d3517d6dbb577297688a00f792940dc691ed4c23f16ecc96d63d1239cc2a679a'
for k in ['producer','actual_private_consumer']:assert H(p[k]['signature'].encode())==p[k]['signature_sha256']
c=p['minimal_definition_context'];assert H(c['literal_kernel_print_bodies'].encode())==c['literal_kernel_print_bodies_sha256']
m=json.loads((RAWFREEZE/'freeze-manifest.json').read_text())
assert H((RAWFREEZE/'freeze-manifest.json').read_bytes())=='6ef5690685a487a0b2de8953221a434db6f761a0478786bd5b7cf45951dbfc3f'
for f in m['files']:assert H((RAWFREEZE/f['relative_path']).read_bytes())==f['sha256']
g=json.loads((RAWFREEZE/'source-graph.json').read_text())
def write(n,x):
 f=OUT/n
 if isinstance(x,bytes):f.write_bytes(x)
 elif isinstance(x,str):f.write_text(x,encoding='utf-8')
 else:f.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
write('input-type-packet-v2.json',b)
write('producer-signature.txt',p['producer']['signature'])
write('consumer-signature.txt',p['actual_private_consumer']['signature'])
write('canonical-definitions-print.txt',c['literal_kernel_print_bodies'])
write('bochner-integral-underlying-definition.txt',c['integral_definition_source']['text'])

binders=[
 {'declarations':['P','T'],'binder':'d : ℕ','classification':'TYPING + STANDING','judgment':'Matches finite ambient/source row count; d>0 follows from hq. No independent positivity binder.'},
 {'declarations':['P','T'],'binder':'q : ℕ','classification':'TYPING + STANDING','judgment':'Natural q includes 0. The source q≥0 condition is inherent, not strengthened.'},
 {'declarations':['P','T'],'binder':'hq : 2*q+1<d','classification':'STANDING','judgment':'Exact source strict inequality. It is retained even though radial isotropy has a more general library formulation.'},
 {'declarations':['T'],'binder':'i : Fin d','classification':'TYPING','judgment':'An arbitrary row, corresponding to source 1-based row i.val+1. No probabilistic event or covariance hypothesis attached.'}
]
local=[
 ('E','EuclideanSpace ℝ (Fin (q+1))','P,T','literal carrier','Real Euclidean r-vector with r=q+1, coordinate values exposed through WithLp.ofLp.'),
 ('μ','stdGaussian E','P,T','literal measure','The actual canonical standard Gaussian law, not an arbitrary measure plus a law certificate.'),
 ('r','((q+1:ℕ):ℝ)','P,T','literal scalar dimension','Real cast of positive natural dimension; division in a is real division.'),
 ('R','fun x => ‖x‖^2','P,T','literal squared Euclidean norm','Matches R_i; scalar R is measurable/integrable internally.'),
 ('L','2*r+3*Real.log (1000*(d:ℝ))','P,T','literal cutoff','Source deterministic common cutoff; no extra truncation event binder.'),
 ('a','(∫ x, Set.indicator {y | R y≤L} R x ∂μ)/r','P,T','literal coefficient','Unnormalized retained moment divided by dimension, with no division by event probability; independent of row i.'),
 ('G','fun x => Matrix.vecMulVec (WithLp.ofLp x) (WithLp.ofLp x)','P,T','literal rank one','Entry G_ab=x_a*x_b; uncentered second moment as in source.'),
 ('kept','Set.indicator {y | R y≤L} G','P','literal matrix indicator','G on retained event and zero off event, equivalent to multiplying by real 0/1 indicator. Equality boundary is retained.'),
 ('θ','fun j => ((j.val:ℝ)+1/2)*Real.pi/(d:ℝ)','T','literal deterministic midpoint row','With source row index j_src=j.val+1 this is (j_src-1/2)π/d. The bounded raw slice defines features in terms of θ_i but does not itself define the midpoint grid; the full-grid attribution is supplied by the handoff, not independently certified from that slice.'),
 ('t','fun j k => if k.val=0 then 1 else Real.sqrt 2*Real.cos ((k.val:ℝ)*θ j)','T','literal source feature row','Frequencies k.val=0,...,q; first coordinate exactly 1. At q=0 every k is 0 and t=(1). No assumed feature bound.'),
 ('Y','Set.indicator {y | R y≤L} (fun x => (d:ℝ)⁻¹ • Matrix.kronecker (G x) (Matrix.vecMulVec (t i) (t i)))','T','literal truncated Kronecker summand','Gamma coordinates are first tensor coordinates; feature coordinates are second. Indicator-outside form equals source scalar indicator product; prove this simple pointwise identity internally if needed.')
]
canon=[
 ('ProbabilityTheory.stdGaussian','map of product gaussianReal 0 1 by an orthonormal-basis coordinate expansion','Correct actual marginal standard Gaussian, with canonical measurability/probability/invariance facts remaining internal proof obligations.'),
 ('EuclideanSpace','PiLp 2 of real coordinates','Correct Euclidean L2 carrier. The canonical PiLp norm facts are standard background, not a new source premise.'),
 ('WithLp.ofLp','self.1 coordinate function','No representative selection or alternative random vector is introduced.'),
 ('Matrix.vecMulVec','Matrix.of (fun x y => w x*v y)','Exact real outer product with source transpose convention.'),
 ('Matrix.kronecker','Matrix.kroneckerMap (fun x1 x2 => x1*x2)','Ordered pair indices agree with gamma-first convention. The packet explicitly states the canonical kroneckerMap entry convention; no factor reversal is allowed.'),
 ('Set.indicator','if x∈s then f x else 0','Cutoff and boundary match the source; scalar and matrix zero branches are literal.'),
 ('MeasureTheory.Integrable','AEStronglyMeasurable f μ ∧ HasFiniteIntegral f μ','A genuine measurability/norm-integrability conjunction, appearing as a target conclusion.'),
 ('MeasureTheory.integral','printed wrapper plus exact underlying CompleteSpace/Integrable branch','Totalized Bochner integral returns zero for nonintegrable input, so scalar truncated radial integrability and matrix integrability must be derived internally; target equality alone cannot certify an expectation.'),
 ('Matrix.instL2OpNormedAddCommGroup','toNorm supplied by l2OpNormedAddCommGroupAux with the L2 metric structure','Matches actual scoped Euclidean operator norm; finite-dimensional completeness is canonical. No source operator-norm estimate is claimed.'),
 ('Matrix.l2OpNormedAddCommGroupAux','NormedAddCommGroup.induced through EuclideanSpace continuous linear maps','The norm is Euclidean L2 operator norm, not an unexplained array norm. It is compatible with finite coordinate integration.'),
 ('Matrix.toEuclideanCLM','orthonormal coordinate matrix equivalence followed by continuous-linear-map conversion','Agrees with the Euclidean linear-operator meaning; no proof implementation dependency is inferred from this definition reference.'),
 ('Matrix','m→n→α','Actual finite real arrays; for Y use ordered product coordinates with r² total coordinates.'),
 ('Matrix.of','Equiv.refl','Literal array/matrix equivalence, with no changed entries.'),
 ('Matrix.one','Matrix.diagonal (fun _ => 1)','The target 1 matrix is exactly I_r.'),
 ('Matrix.diagonal','if i=j then d i else 0','The resulting identity entries are Kronecker deltas; finite index equality is decidable.'),
 ('Matrix.instL2OpNormedSpace','matrix module with norm_smul_le under L2 operator norm','Scalar multiplication is ordinary real matrix scalar multiplication and is coherent with the scoped norm.')
]
write('binder-definition-audit.json',{'schema':'independent-type-meaning-audit-v2','input_sha256':H(b),'statement_seal_sha256':p['statement_seal_sha256'],'context_sha256_supplied_by_handoff':p['minimal_definition_context_sha256'],'binder_rows':binders,'excess_public_binders':[],'local_let_definitions':[dict(name=n,literal=f,declarations=decl,kind=kind,judgment=j) for n,f,decl,kind,j in local],'canonical_definition_rows':[dict(name=n,actual_print_meaning=body,judgment=j) for n,body,j in canon],'scope':c['imports_and_scope'],'scope_judgment':'Meaning is sealed together with L2Operator scope. A signature string without this context is not the entire reviewed mathematical meaning. No Lean elaboration or instance search was run by this reviewer.','not_source_binders':['Gaussian invariance','finite Gaussian moments','coordinate and matrix integrability','source positive denominator facts','trace exchange','deterministic Kronecker transport','matrix completeness'],'false_closure_risk':'The scalar integral is totalized too; its truncated radial moment must be proved integrable internally even though scalar integrability is not an additional target conjunct. No signature change is required.'})

mapping={
'S.qd':('P,T source binders','d q : ℕ and hq match source; positivity internal.'),
'S.g':('source standing context; no family-valued target here','The targets directly integrate the canonical marginal law rather than taking g_a samples. Do not claim a compiled joint/family distribution adapter.'),
'D.r':('P,T literal local r','Positive r=q+1, cast to real.'),
'D.index':('T binder and product-coordinate typing','Fin d row i corresponds to source i+1; coordinate Fin(q+1) corresponds to source coordinates 1,...,r.'),
'D.vectors':('P,T G plus T literal t','Canonical x realizes one gamma marginal; WithLp.ofLp gives its coordinates. T uses exact deterministic source cosine feature shape.'),
'S.gamma':('P,T literal μ','Canonical N(0,I_r) one-row law; no independence theorem about d source rows is a target.'),
'D.LR':('P,T literal local R,L','Matches the displayed common cutoff and squared norm.'),
'D.a':('P,T literal local a','Exactly the retained radial scalar; common across rows because its definition contains no i.'),
'D.Y':('T literal Y','Pointwise indicator placement equivalence and ordered Kronecker entries are internal bookkeeping.'),
'G.positive':('P,T internal proof obligation','Derive q+1>0, d>0, and nonzero real casts. Do not add public positivity binders.'),
'G.radial':('P internal proof obligation','Derive actual canonical Gaussian orthogonal/sign/permutation invariance and cutoff invariance, or a separately disclosed source-compatible route.'),
'G.integrable':('P integrability target plus internal scalar/coordinate obligations; T integrability target','Prove finite moment/measurability/trace facts under actual μ. Matrix target integrability uses sealed L2Operator norm.'),
'G.coordinates':('P internal source-bridge obligation','Discharge off-diagonal cancellation/equal-diagonal isotropy including r=1; no public symmetry premise.'),
'G.trace':('P internal source-bridge obligation','Identify scalar by finite trace/expectation interchange and division by positive r.'),
'C.common':('P,T definition semantics','The same μ,R,L,r definition yields the same a for every private row i. Random-family re-expression remains a later adapter.'),
'C.cov':('P public planned source-facing root','Target is Integrable kept μ and integral kept=a•1 under the actual source cutoff.'),
'G.EY':('T private internal transport obligation','Use producer matrix integrability/equality materially; pull deterministic real factors/linear Kronecker map through integral.'),
'C.EY':('T actual private planned root','Target is Integrable Y μ and integral Y=(a/d)•kronecker 1 (outer t_i t_i).')}
assert set(mapping)=={n['id'] for n in g['nodes']}
write('typed-source-graph-overlay.json',{'schema':'independent-typed-source-graph-overlay-v2','frozen_raw_graph_sha256':H((RAWFREEZE/'source-graph.json').read_bytes()),'frozen_raw_manifest_sha256':H((RAWFREEZE/'freeze-manifest.json').read_bytes()),'input_packet_sha256':H(b),'statement_seal_sha256':p['statement_seal_sha256'],'producer':p['producer'],'consumer':p['actual_private_consumer'],'node_mapping':[{'source_node':n['id'],'obligation_location':mapping[n['id']][0],'judgment':mapping[n['id']][1],'compiled_status':'UNIMPLEMENTED / not inspected'} for n in g['nodes']],'source_root_mapping':{'C.cov':p['producer']['name'],'C.EY':p['actual_private_consumer']['name']},'required_future_material_edge':{'from':p['producer']['name'],'to':p['actual_private_consumer']['name'],'must_use':['producer integrability conjunct','producer covariance equality conjunct'],'status':'planned obligation, not a checked Lean dependency'},'source_backward_closures':g['root_backward_closure'],'new_public_assumptions':[],'omitted_source_bridges_discharged_by_types_alone':False,'dependencies_caution':'The graph maps obligations to public/private declarations. It does not invent provider theorem names or certify proof terms, imports, compiler dependencies, or mathematical completion.'})

judgment={
 'schema':'independent-source-type-judgment-v2',
 'decision':'TYPE/MEANING COMPATIBLE with the frozen bounded one-row source mathematics; implementation and independent topology review remain pending',
 'normal_intake_or_verification_permission':False,
 'proof_seen':False,'api_retrieval_performed':False,'compiler_executed':False,
 'seal_sha256':p['statement_seal_sha256'],
 'producer_signature_sha256':p['producer']['signature_sha256'],
 'consumer_signature_sha256':p['actual_private_consumer']['signature_sha256'],
 'canonical_definition_context_sha256_as_supplied':p['minimal_definition_context_sha256'],
 'independently_rehashed':['complete v2 packet','both decoded signature strings','embedded canonical print text','all twelve raw-frozen evidence files','raw freeze manifest'],
 'hash_limit':'Statement-seal and context digests are exact identifiers supplied within the authenticated packet. Their external serialization construction was not provided or independently replayed; no claim of reproducing those two digests is made.',
 'source_fit':{'producer':'Actual canonical Gaussian truncated rank-one moment, with explicit target matrix integrability and correct a I_r equality.','consumer':'Actual deterministic one-row summand and literal identity-Kronecker mean; producer use remains a proof obligation.','common_scalar':'a depends only on d,q and the shared canonical Gaussian/cutoff; neither a definition depends on i.','q0_r1':'Included. Fin(q+1)=Fin1, feature condition always selects 1, isotropy comparisons are vacuous, trace division is by 1.','norm':'Actual scoped Euclidean L2 operator norm is visible in literal canonical structure; no operator-norm inequality is a source result here.','conventions':'Euclidean squared norm, real casts, ordinary outer product, identity delta entries, gamma-first ordered Kronecker factors, retained ≤ boundary, and unconditioned retained moment all match.'},
 'remaining_obligations':['Prove canonical Gaussian invariance/measurability/finite moments internally under actual μ.','Prove scalar truncated R integrability internally so totalized integral has its source expectation meaning.','Prove producer matrix Integrable and covariance equality, with no public theorem-shaped premises.','Prove private Y Integrable and mean, materially consuming both producer conjuncts.','Compile exact sealed declarations and show scope/instances match the packet.','Complete distinct source topology challenge and later semantic/proof review.'],
 'boundary_limits':['No source tail/bias/frame/operator-norm/concentration/main-bound result is accepted by this overlay.','No joint family or cross-row independence result is targeted or certified; a future random-family realization adapter is separate.','The bounded source defines t_i using θ_i but not the midpoint grid itself. Its midpoint attribution is handoff context; no independent raw membership for that grid is fabricated. The expectation transport is valid for each deterministic θ, so this does not create a missing premise or obstruction to the bounded identity.','No normal intake, VERIFIED/stabilization, publication, final source acceptance, or completion status is granted.'],
 'v1_exposure':{'packet_path':'.astis/huanjian-gc-truncated-radial-covariance-20261111/selective-type-definition-packet.json','sha256':'c4e34c2162e9c9c2796edd9e3acf7ea45d0d58e1da0f06dd70c7dc9e5e810cde','seal':'d3abb9deb50f519941b7ef9d53f172ca6e2adcc51d79834de25a0b3234b20a4b','exposure':'Read only after raw source freeze. Most canonical bodies were referenced but absent. Omission was reported to root; no typed freeze was produced from v1.','v2_change':'Complete actual #print bodies and evidence revision added. Target signature hashes and L2Operator scope unchanged; context/seal updated. V1 was not treated as unseen.'},
 'raw_freeze_unchanged':True
}
write('judgment.json',judgment)
write('judgment.md','''# Independent typed overlay judgment

The v2 producer and actual private consumer signatures are compatible with the frozen bounded one-row source mathematics. No excess public binder appears. The targets retain natural q=0, the literal source cutoff, the unconditioned retained radial moment a, and gamma-first Kronecker order. Matrix integrability is a target conclusion under the explicit Euclidean L2Operator scope.

The coefficient a is common across every row because its literal definition contains only the same d,q, canonical Gaussian law, radius, and threshold. In the consumer, i occurs only in the deterministic cosine feature row. At q=0 the row has one entry, equal to 1. The Fin d row index translates to source 1-based index i.val+1; the supplied midpoint formula then reads (i_source−1/2)π/d. The frozen bounded source defines t_i in terms of θ_i but does not itself define the grid. I have not fabricated source membership for that external grid attribution. The selected expectation identity itself holds for every deterministic feature row, so no grid identity, frame property, or feature bound is needed.

Canonical definitions confirm real Euclidean vectors, actual standard Gaussian pushforward measure, ordinary rank-one matrices, real indicator with retained equality boundary, identity delta entries, and ordered Kronecker pair indices. The norm structure is explicitly induced through Euclidean continuous linear maps. The exact underlying Bochner definition has a totalized zero branch for nonintegrable inputs. Both matrix integrabilities are target conjuncts; scalar truncated radial integrability must also be proved internally so the scalar a has its source expectation meaning.

The overlay assigns every frozen source node to a public producer obligation, private consumer obligation, literal definition, or standing/source-law context. These assignments are obligations, not compiled dependencies. Gaussian symmetry, finite moments, isotropy, trace exchange, and expectation transport remain unproved here. The consumer must materially use both producer conjuncts. No caller-supplied covariance, symmetry, integrability, tail estimate, or feature bound is introduced.

The canonical one-row measure formulation represents the source marginal law directly. It does not by itself prove a joint gamma family law or cross-row independence. Re-expression under a separately defined source random family would need a law adapter. That is outside this minimal packet.

V1 was seen after the raw freeze. Its canonical print-body omission was reported before any typed freeze. V2 adds those bodies while preserving target signatures and matrix norm scope. This judgment uses v2 and preserves v1 exposure. The raw evidence was rehashed unchanged. No implementation, proof/API retrieval, or compiler run was used. This typed semantic judgment grants no normal intake, VERIFIED transition, publication, source completion, or final acceptance.
''')
manifest={'schema':'independent-typed-overlay-freeze-v2','frozen_at_utc':datetime.now(timezone.utc).isoformat(),'phase':'TYPE ONLY after independent raw freeze; no proof implementation seen','raw_manifest_path':str(RAWFREEZE/'freeze-manifest.json'),'raw_manifest_sha256':H((RAWFREEZE/'freeze-manifest.json').read_bytes()),'type_input_path':str(IN),'type_input_sha256':H(b),'statement_seal_sha256_supplied':p['statement_seal_sha256'],'context_sha256_supplied':p['minimal_definition_context_sha256'],'files':[],'manifest_exclusions':['type-freeze-manifest.json (self-reference impossible)','TYPE-FREEZE-RECEIPT.json (authenticates manifest)'],'no_acceptance_authority':True}
for f in sorted(OUT.rglob('*')):
 if f.is_file() and f.name not in {'type-freeze-manifest.json','TYPE-FREEZE-RECEIPT.json'}:
  fb=f.read_bytes();manifest['files'].append({'relative_path':str(f.relative_to(OUT)),'bytes':len(fb),'sha256':H(fb)})
write('type-freeze-manifest.json',manifest)
mb=(OUT/'type-freeze-manifest.json').read_bytes()
receipt={'phase':'v2 typed overlay frozen without raw mutation','manifest_path':str(OUT/'type-freeze-manifest.json'),'manifest_bytes':len(mb),'manifest_sha256':H(mb),'listed_file_count':len(manifest['files']),'judgment_sha256':H((OUT/'judgment.json').read_bytes()),'typed_overlay_sha256':H((OUT/'typed-source-graph-overlay.json').read_bytes()),'binder_definition_audit_sha256':H((OUT/'binder-definition-audit.json').read_bytes()),'source_manifest_rechecked_unchanged':H((RAWFREEZE/'freeze-manifest.json').read_bytes()),'no_acceptance_authority':True}
write('TYPE-FREEZE-RECEIPT.json',receipt)
print(json.dumps(receipt,indent=2))
