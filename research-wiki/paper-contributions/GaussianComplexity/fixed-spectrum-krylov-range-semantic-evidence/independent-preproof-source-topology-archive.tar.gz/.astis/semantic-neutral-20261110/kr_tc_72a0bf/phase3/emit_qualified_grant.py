from pathlib import Path
import json,hashlib,datetime
OUT=Path(__file__).parent;ROOT=OUT.parent;W=Path('.astis/huanjian-gc-fixed-spectrum-krylov-range-20261110')
sha=lambda b:hashlib.sha256(b).hexdigest()
req=json.loads((OUT/'prospective-admission-request.raw.json').read_bytes());rows={}
def add(p,kind):
 p=Path(p);b=p.read_bytes();rows[str(p)]={'path':str(p),'sha256':sha(b),'kind':kind}
for p in ['.astis/huanjian-resume-20261103/2610.20492v1.html','research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-krylov-range-statement-seal.json']:
 add(p,'exact-original-source-or-seal')
for stage in ['phase1','phase2a','phase2b','phase2c']:
 add(ROOT/f'{stage}.manifest.json','prior-independent-mathematical-freeze-manifest')
 add(ROOT/f'{stage}.freeze.receipt.json','actual-independent-mathematical-freeze-execution')
for rel in ['phase1/phase1_independent_math.md','phase2a/phase2a_binder_definition_audit.md','phase2b/phase2b_topology_judgment.md','phase2c/mathematical-judgment.md']:
 add(ROOT/rel,'independent-mathematical-judgment')
for p in ['.astis/semantic-neutral-20261110/kr_sg_31f8c2_phase3_revision/source-graph.v2.json','.astis/semantic-neutral-20261110/kr_sg_31f8c2_phase3_revision/type-source-overlay.v2.json','.astis/semantic-neutral-20261110/kr_sg_31f8c2_phase3_revision/structured-delta-and-lineage.json','.astis/semantic-neutral-20261110/kr_sg_31f8c2/coverage.json']:
 add(p,'exact-source-topology-reviewed-input')
for x in json.loads((OUT/'W-inputs.metadata.json').read_bytes()):add(x['path'],'qualified-process-history-input')
for x in json.loads((OUT/'R-receipts.index.json').read_bytes()):add(x['path'],'actual-R-execution-receipt');add(x['data']['log'],'actual-R-execution-log')
for x in json.loads((OUT/'E-metadata-check.json').read_bytes()):add(x['path'],'exact-own-metadata-input')
for p in [W/'prospective-admission-request.json',Path(req['own_frontier']),W/'intake-baseline.private.json',W/'preproof-baseline.private.json']:
 add(p,'private-hash-only-or-pre-intake-process-boundary')
for p in [OUT/'prospective-process-review.md',OUT/'current-process-metadata.json',OUT/'history-audit.receipts.json',OUT/'phase3_runtime_record.md']:
 add(p,'independent-prospective-process-judgment-or-evidence')
assert rows[str(W/'admit_normal_intake_prepared.py')]['sha256']=='593d25fd5c50a683e7f56937f28e7dc8c65fe05aa8414c47b69ab491a3a84cc7'
assert rows[str(W/'intake-baseline.private.json')]['sha256']=='304c4ecd11824649723b12c2113e46bd29578cbd45728200487faab9f05f865b'
assert rows[str(W/'preproof-baseline.private.json')]['sha256']=='94079fa026adb63d208d54522b3ddb4aabae19e170f0a2138427ce1ad1199313'
grant={
 'kind':'QUALIFIED_PROSPECTIVE_PROCESS_GRANT_NOT_PROOF_OR_SOURCEV',
 'grant_id':'KR_TC_72A0BF_QUALIFIED_PROSPECTIVE_V1_20261110',
 'issued_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'issuer':'independent challenger /root/krylov_range_topology_72a0bf',
 'advance_id':req['advance_id'],'owner':req['owner'],
 'prospective_target_Lean_proof_API_allowed_after_this_grant':True,
 'root_sole_mathematical_worker':True,
 'prepared_intake_script_sha256':req['prepared_intake_script_sha256'],
 'private_baseline_sha256':req['private_baseline_sha256'],
 'private_preproof_baseline_sha256':req['private_preproof_baseline_sha256'],
 'independent_inputs':list(rows.values()),
 'target_proof_API_currently_allowed_before_successful_intake_and_readback':False,
 'reviewer_executed_intake':False,
 'root_API_pristine':False,
 'qualified_history':'Prior C7/Gram work, adjacent canonical proof/API/header/rfl exposure, preseal and postseal abstract route planning, reserved-lambda parser failure, metric elaboration and LF metadata correction remain actual history. No retroactive pristine claim.',
 'mathematical_review_boundary':'Own raw-first, exact-type, SG challenge and accepted exact-v2 mathematical judgments were actually frozen before root process exposure. No actual target proof/compiled parent or global sourceV is certified.',
 'future_allowed_action':'Root alone may run only the exact prepared script at the bound hash for this advance, with exact raw grant SHA argument, exact private baseline SHA argument, PYTHONOPTIMIZE=0 and active assertions.',
 'proof_API_start_condition':[
  'Actual prepared execution returns exit0, not merely a grant or partial printed state.',
  'Every exact input/hash/HEAD/marker/target-absence and complete private preservation preguard passes.',
  'Exactly the normal proposal, CLAIMED and EXPLORING calls append exactly3 rows for this advance after the original ledger prefix.',
  'Every tracked/frontier/control/state/owner postguard passes; same foreign values, original twelve sourceVs and reader HOLDs remain protected.',
  'Root performs actual readback of final EXPLORING owner, exact append and preservation evidence before target proof/API retrieval.'
 ],
 'once_failure_boundary':'Any hash drift, partial event append, exception, failed guard or incomplete readback means no target proof/API authority. Preserve actual evidence and permanent marker; no replay/re-propose/reset/ledger rewrite or recovery mutation is granted.',
 'own_frontier_scope':'Its current claimed label is only an explicit reserved source-scope fragment, not a prior normal ledger CLAIMED event or source proof. The pre-intake cell hash is bound; only the prepared script bounded own-cell update is allowed after its guards.',
 'protected_scope_counts_only':{'foreign_states':299,'foreign_frontier_files':459,'tracked_regular_files':128851,'foreign_controls':927,'counts_are_not_math_credit':True},
 'private_policy':'Private baseline hashes/schema/counts only; no full foreign values/path-hash inventories may be exported. No restricted ATLAS content/index/projection or ignored giant dump traversal/hash; no nested repository access.',
 'scope':'Only the exact sealed deterministic range(B)=K_q component and genuine same-witness Euclidean energy/signed quadratic consumer, after successful admission. All actual proof/compile/source/semantic/publication gates still apply.',
 'not_granted':['sourceV','STAB','global owner or lease takeover','root Tests/shared imports/Registry/global graph','site/browser/push','publication','purification/ExpositionSeal','Goal action','C6/concentration/full Lemma4.4','Haar/adaptive/measurable-choice/oracle/precision/TV/query-cap/expected-cost adapters','either full main bound']
}
p=OUT/'qualified-prospective-grant.json';assert not p.exists();p.write_text(json.dumps(grant,ensure_ascii=False,indent=2)+'\n')
summary={'grant':str(p),'sha256':sha(p.read_bytes()),'independent_inputs':len(rows),'future_exact_script_only':True,'target_proof_API_currently_allowed':False,'intake_not_executed':True}
(OUT/'grant-emission.receipt.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
