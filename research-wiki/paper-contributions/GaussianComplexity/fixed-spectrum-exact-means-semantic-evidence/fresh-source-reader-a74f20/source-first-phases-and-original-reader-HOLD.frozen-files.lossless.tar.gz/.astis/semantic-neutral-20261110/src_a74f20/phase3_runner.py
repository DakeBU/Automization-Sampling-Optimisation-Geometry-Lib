from pathlib import Path
import subprocess,json,hashlib,os,sys,time
ROOT=Path('/Users/zhouhuanjian/ASTIS-GC')
BASE=ROOT/'.astis/semantic-neutral-20261110/src_a74f20/phase3'
SRC=BASE/'native-src'
OUT=BASE/'native-out'
COMMIT='d823dddd8b7f203af3191b94ba2eb763fc0edc9b'
E='research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-exact-means-semantic-evidence/'
PROD='AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumExactMeans.lean'
TEST='Tests/GaussianComplexityFixedSpectrumExactMeans.lean'
PARENTS=['AutoSamplingTheory/ExampleCases/GaussianComplexity/'+n+'.lean' for n in ['FixedSpectrumGaussianMoments','FixedSpectrumCosineExpansion','FixedSpectrumGridAlias']]
def sha(b):return hashlib.sha256(b).hexdigest()
def savej(p,o):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(o,indent=2,ensure_ascii=False)+'\n')
def run(label,cmd,cwd=ROOT,env=None):
    BASE.mkdir(parents=True,exist_ok=True)
    original=label
    attempt=2
    while (BASE/(label+'.receipt.json')).exists():
        label=original+'-attempt'+str(attempt);attempt+=1
    start=time.time()
    proc=subprocess.run(cmd,cwd=cwd,env=env,capture_output=True)
    (BASE/(label+'.stdout')).write_bytes(proc.stdout)
    (BASE/(label+'.stderr')).write_bytes(proc.stderr)
    result={'label':label,'command':cmd,'cwd':str(cwd),'exit_code':proc.returncode,'elapsed_seconds':time.time()-start,'stdout_sha256':sha(proc.stdout),'stderr_sha256':sha(proc.stderr),'stdout_bytes':len(proc.stdout),'stderr_bytes':len(proc.stderr),'LEAN_PATH':None if env is None else env.get('LEAN_PATH')}
    savej(BASE/(label+'.receipt.json'),result)
    print(json.dumps(result,ensure_ascii=False))
    return proc
def context():
    manifest=json.loads((SRC/'lake-manifest.json').read_text())
    tc=(SRC/'lean-toolchain').read_text().strip().replace('/','--').replace(':','---')
    lean=Path('/Users/zhouhuanjian/.elan/toolchains')/tc/'bin/lean'
    paths=[OUT,ROOT/'.lake/build/lib/lean']+[ROOT/'.lake/packages'/p['name']/'.lake/build/lib/lean' for p in manifest['packages']]
    env=os.environ.copy();env['LEAN_PATH']=':'.join(map(str,paths));env['LEAN_SRC_PATH']=str(SRC)
    return lean,env
action=sys.argv[1]
if action=='overlay':
    excluded={Path(PROD).with_suffix(''),Path(TEST).with_suffix('')}
    created=[]
    def overlay(source,dest,relative):
        dest.mkdir(parents=True,exist_ok=True)
        for p in source.iterdir():
            rel=relative/p.name;q=dest/p.name
            if any(str(rel).startswith(str(x)+'.') for x in excluded):continue
            if p.is_dir():
                if any(str(x).startswith(str(rel)+'/') for x in excluded):overlay(p,q,rel)
                elif not q.exists():q.symlink_to(p,target_is_directory=True);created.append(str(q))
            elif not q.exists():q.symlink_to(p);created.append(str(q))
    for namespace in ['AutoSamplingTheory','Tests']:
        p=ROOT/'.lake/build/lib/lean'/namespace
        if p.is_dir():overlay(p,OUT/namespace,Path(namespace))
    savej(BASE/'cache-overlay.json',{'reason':'Lean resolves an entire namespace prefix from the first existing LEAN_PATH package root; mirror read-only cached siblings into isolated output so no root cache is written and candidate outputs are fresh.','excluded_candidate_stems':[str(x) for x in excluded],'links':created})
    print('CREATED_READONLY_CACHE_LINKS',len(created))
elif action=='setup':
    paths=[PROD,TEST,'lean-toolchain','lake-manifest.json','lakefile.lean',E+'KernelExactTypesAndAllPrivateProvidersBounded.lean',E+'source-to-lean-map-v1.json','research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-exact-means.json','website/content/declaration_lessons/huanjian-fixed-spectrum-exact-means.json','website/content/publications/huanjian-fixed-spectrum-exact-means.json']+PARENTS
    snapshots=[]
    for path in paths:
        r=run('snapshot-'+Path(path).name,['git','show',COMMIT+':'+path])
        if r.returncode:raise SystemExit(r.returncode)
        target=SRC/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(r.stdout)
        snapshots.append({'path':path,'snapshot':str(target.relative_to(ROOT)),'sha256':sha(r.stdout),'bytes':len(r.stdout)})
    assert sha((SRC/PROD).read_bytes())=='8dfb13585403a127830dfc841dafaf7e6f95057db10253f38b0ab7a66802b6c8'
    assert sha((SRC/TEST).read_bytes())=='d30744e67541fa07729002f06fde01f84a4fa1984b6f24d1014285db50ccc696'
    packet=ROOT/(E+'fresh-source-reviewer-packet.json');p=json.loads(packet.read_text())
    assert sha(json.dumps({k:v for k,v in p.items() if k!='packet_sha256'},sort_keys=True,separators=(',',':'),ensure_ascii=False).encode())==p['packet_sha256']=='1308b03966a9ca556f8887626401384b5fa33062e9e087ac8bb234129bbd61f7'
    (BASE/'canonical-reviewer-packet.json').write_bytes(packet.read_bytes())
    m=json.loads((SRC/(E+'source-to-lean-map-v1.json')).read_text())
    g=ROOT/m['source_graph']['path'];gb=g.read_bytes();assert sha(gb)==m['source_graph']['sha256'];(BASE/'source-proof-graph-v1.json').write_bytes(gb)
    savej(BASE/'snapshot-manifest.json',{'commit':COMMIT,'snapshots':snapshots,'packet_raw_sha256':sha(packet.read_bytes()),'packet_canonical_sha256':p['packet_sha256'],'source_graph_sha256':sha(gb)})
    lean,env=context();print('LEAN',lean,'EXISTS',lean.exists())
    run('lean-version',[str(lean),'--version'],SRC,env)
    run('lean-help',[str(lean),'--help'],SRC,env)
    manifest=json.loads((SRC/'lake-manifest.json').read_text())
    cache=[]
    for path in PARENTS:
        stem=ROOT/'.lake/build/lib/lean'/Path(path).with_suffix('')
        for suffix in ['.olean','.olean.private','.olean.server','.ilean','.ir']:
            q=Path(str(stem)+suffix)
            if q.is_file():cache.append({'path':str(q),'sha256':sha(q.read_bytes()),'bytes':q.stat().st_size})
    packages=[]
    for p in manifest['packages']:
        package=ROOT/'.lake/packages'/p['name'];r=run('package-head-'+p['name'],['git','rev-parse','HEAD'],package)
        packages.append({'name':p['name'],'pinned':p['rev'],'actual':r.stdout.decode().strip(),'matches':r.stdout.decode().strip()==p['rev']})
    savej(BASE/'environment-and-direct-cache.json',{'lean':str(lean),'lean_binary_sha256':sha(lean.read_bytes()),'toolchain_file_sha256':sha((SRC/'lean-toolchain').read_bytes()),'manifest_sha256':sha((SRC/'lake-manifest.json').read_bytes()),'LEAN_PATH':env['LEAN_PATH'],'direct_ASTIS_cached_artifacts':cache,'packages':packages})
elif action in ['production','test','kernel','deps','definition-probe']:
    lean,env=context()
    if action=='deps':
        r=run('production-import-deps',[str(lean),'--deps',PROD],SRC,env)
        deps=[]
        for line in r.stdout.decode().splitlines():
            q=Path(line)
            if q.is_file():deps.append({'path':str(q),'sha256':sha(q.read_bytes()),'bytes':q.stat().st_size})
        savej(BASE/'import-dependency-cache-hashes.json',deps)
    else:
        file=PROD if action=='production' else TEST if action=='test' else 'OwnDefinitionAndCacheProbe.lean' if action=='definition-probe' else 'KernelExactTypesAndAllPrivateProvidersBounded.lean'
        if action=='kernel':
            (SRC/file).write_bytes((SRC/(E+file)).read_bytes())
        target=OUT/Path(file).with_suffix('.olean');target.parent.mkdir(parents=True,exist_ok=True)
        ilean=target.with_suffix('.ilean')
        r=run('fresh-'+action,[str(lean),'-o',str(target),'-i',str(ilean),file],SRC,env)
    print('CHECK_EXIT',r.returncode)
    if r.stdout:print(r.stdout.decode()[:2000])
    if r.stderr:print(r.stderr.decode()[:2000])
    raise SystemExit(r.returncode)
