# Independent type-only source judgment

Reviewer `/root/radial_exp_fresh_source_6c28`. This judgment follows the verified Phase 1 freeze `c5337fc016d3c17c3d1966994e367451b39bb6d7044b68d9a8b7ffe129122d66` and uses only the exact selective type and definition packet SHA-256 `44cecb47245a0d1ab06d634f8b1dcd408c8368437e37cea1f0bde46fc2669ae3`. The two signatures and all eleven definition literals were independently rehashed. This judgment precedes exposure to the proof implementation, lesson, decoder reconstruction, correspondence or topology records, prior verdict and native build evidence.

## Verdict

**Producer. Source-equivalent at the row specialization, with a valid generalization to every finite-dimensional real inner-product space.** The exact fixed-parameter exponential moment in `A3.SS2.p10.m3` and the finite integrability implicit in that use are supplied by the two conjuncts. The generalization includes dimension zero and introduces no analytic premise.

**Private consumer. Source-equivalent to the single-row truncation-threshold corollary of `A3.Ex104`.** Its specialization \(x=\log(1000d)\) yields the exact bound on \(\mathbb P(R_i>L)\) used by the source. This is a partial implementation of the scalar truncation paragraph. The variable-\(x\) chain and simultaneous event in the source remain separate conclusions.

## Producer correspondence

Exact signature digest `7b27efe79e0ebbc31760b1e4bb17e8591bbca4335e35fd3fdbe4c642ee50c6b3`.

| Semantic slot | Typed reading and source comparison |
| --- | --- |
| Objects | The integration variable is a point \(z\) in \(E\). The law is the concrete `stdGaussian E`. Its body takes the product of `gaussianReal 0 1` over the finite orthonormal coordinate basis and maps it by orthonormal synthesis. This is the centered standard Gaussian law of the paper's unscaled \(\gamma_i\) when \(E=\mathbb R^{q+1}\). The integrand uses \(R(z)=\|z\|^2\). |
| Domains | \(E\) is a finite-dimensional real inner-product space with its Borel measurable structure. `FiniteDimensional` is `Module.Finite` over \(\mathbb R\), and `Module.finrank` takes the natural cardinal rank in this finite setting. The norm in the paper is the Euclidean norm. Specialization to `EuclideanSpace ℝ (Fin (q + 1))` uses the \(p=2\) norm as supplied by `PiLp`. |
| Quantifiers | The producer is universal over the carrier and its instances, for the fixed tilt \(1/3\). It has no free tail or Gaussian-law parameter, \(d\), \(q\) or row index. The source statement for each \(i\) follows by the common standard marginal of \(\gamma_i\). |
| Assumptions | The carrier binders give the normed additive group, compatible real inner product, finite real dimension, and measurable space equal to the Borel sigma algebra. These are type information for this law. Independence of coordinates is in the product measure defining `stdGaussian`. The paper's cross-row independence and \(2q+1<d\) are unnecessary for the moment after specializing to a single marginal. No analytic result, law witness, positivity of dimension, or integrability occurs as a premise. |
| Conclusion | The pair of conclusions is \(\exp(\|z\|^2/3)\in L^1(\operatorname{stdGaussian} E)\) in the sense of `Integrable`, and its integral equals \(3^{\operatorname{finrank}_{\mathbb R}(E)/2}\). The first conjunct explicitly supplies the finite expectation used for Markov. |
| Scopes and senses | `Integrable` expands to a.e. strong measurability and finite extended integral of the norm, hence the complete real Bochner integral takes the actual integrable branch of its definition. The use of a concrete measure realizes the row law. The row of \(B\) has its separate tensor factor and \(d^{-1/2}\) scaling. Neither enters \(R(z)\). |
| Constant dependencies | The tilt is exactly \(1/3\), the base exactly positive real \(3\), and the exponent is the real cast of the dimension divided by real \(2\). The positive-base `Real.rpow` is the ordinary real power \(e^{(\operatorname{finrank}/2)\log3}\). For odd dimension this preserves the half-integer exponent. |

For the basis identification, orthonormal synthesis preserves the norm. In \(\mathbb R^r\) it is an orthogonal change of coordinates, so the joint density \((2\pi)^{-r/2}\exp(-\|z\|^2/2)\) and volume are invariant. Thus the use of a canonical orthonormal basis imposes no extra orientation on the paper row. `EuclideanSpace ℝ (Fin (q + 1))` has dimension \(q+1\), matching \(r\). In dimension zero the product is the unit mass on the empty vector and synthesis gives zero. The integrand equals \(1\) and \(3^0=1\). In the minimum source case \(q=0\), the dimension is one and the integral is \(\sqrt3\). The coefficient is fixed at \(1/3\), so the broader Gaussian tilt interval and its boundary \(1/2\) from Phase 1 are auxiliary background.

## Private consumer correspondence

Exact signature digest `3dc0457798c1b594a16ad8f7ab8e863d8cd469c9fe0b940550e05a23cdd2d94a`.

| Semantic slot | Typed reading and source comparison |
| --- | --- |
| Objects | The lets set \(E=\text{EuclideanSpace }\mathbb R\,(\text{Fin }(q+1))\), \(\mu=\operatorname{stdGaussian} E\), and \(L=2(q+1)+3\log(1000d)\). The event is in the row-law carrier. Under the marginal pushforward of any original \(\gamma_i\), the event has the paper probability \(\mathbb P(R_i>L)\). |
| Domains | \(d,q\) are natural numbers. \(q+1\) is taken in \(\mathbb N\) and cast to \(\mathbb R\) in \(L\). The product \(1000d\), its inverse and its logarithm are real operations. The carrier has the actual Euclidean norm, whose square is the sum of the \(q+1\) coordinate squares. |
| Quantifiers | The type quantifies over \(d,q\) with the paper constraint. The variable inside the set comprehension is a point of \(E\), not the source tail parameter \(x\). The same typed law instantiation works for each paper index \(1\le i\le d\). There is no quantification over a row family or simultaneous joint experiment. |
| Assumptions | The only explicit proof premise is \(2q+1<d\), exactly the standing constraint in Lemma 4.4. It gives \(d\ge2\), hence \(\log(1000d)\ge0\) and a positive finite reciprocal. It is stronger than needed for a purely marginal abstract cutoff lemma and matches the paper slice. The measure is canonical. The type adds no measurability, integrability, tail, determinant, spectral, or matrix-concentration premise. |
| Conclusion | \(\mu\{z:L<\|z\|^2\}\le\operatorname{ENNReal.ofReal}((1000d)^{-1})\). This is the last comparison of `A3.Ex104.m1` at \(x=\log(1000d)\), since \(e^{-\log(1000d)}=(1000d)^{-1}\). |
| Scopes and senses | The strict event is exactly the complement of one row's retained \(\{R_i\le L\}\). It is Borel by continuity. On the positive real inverse, `ENNReal.ofReal` is the ordinary nonnegative embedding with no clipping. The finite probability comparison is the same as the source's real-valued probability inequality. |
| Constant dependencies | The factor \(2\) multiplies \(r=q+1\), the factor \(3\) multiplies \(\log(1000d)\), and the denominator is \(1000d\). The dimension of the Gaussian is \(r\), and \(d\) appears in the cutoff and tail budget, never in the norm or Gaussian scale. No cosine, frequency, \(\kappa\), \(\tau_{d,q}\), or adjustable absolute constant appears. |

At \(q=0,d=2\) this gives the one-coordinate strict tail at \(L=2+3\log 2000\) with bound \(1/2000\), consistent with the paper. The set complement retains equality at \(L\) with no atom argument needed. The source joint event is \(\bigcap_{i=1}^d\{R_i\le L\}\) with mass at least \(999/1000\). Its derivation uses a union bound over the marginal conclusion, with no use of cross-row independence in that inference. The private consumer's proposition supplies that marginal conclusion only.

## Residual source boundaries

- The public producer states the fixed \(1/3\) identity and integrability, not a general \(\lambda\)-moment formula. Gaussian density normalization, basis change and product-factor reasoning are background steps. They should be identified as proof ingredients in any later implementation review.
- The displayed arbitrary-\(x\) estimate for \(x\ge0\), including \(x=0\) and the intermediate exponential with \(\frac r2\log3-\frac{2r}{3}-x\), is wider than the exact private consumer interface. The joint \(\mathcal T\) bound at `A3.Ex105` and its common probability space are also outside that type. These are coverage residuals of the bounded packet, not changes in the meaning of either proposition.
- The shifted \(s\ge0\) tail and bias integral `A3.Ex106`, the use of \(a\) and the matrix expectation identities `A3.Ex107–Ex110`, and the simultaneous Gram-matrix conclusions retain the downstream boundary from Phase 1. The interfaces do not claim independent proof of the joint Gaussian row construction, the cosine design, or those downstream assertions.

## Recorded execution

In `/Users/zhouhuanjian/ASTIS-GC`, the following Phase 1 check exited 0 (chunk `2b0840`) and printed all four entries OK followed by the verified Phase 1 freeze digest above.

```sh
shasum -a 256 -c .astis/semantic-neutral-20261110/re_src_6c28/phase1/freeze.sha256 && shasum -a 256 .astis/semantic-neutral-20261110/re_src_6c28/phase1/freeze.sha256
```

The packet digest and literal read exited 0 (chunk `72b7cb`).

```sh
shasum -a 256 .astis/huanjian-gc-radial-exponential-20261110/selective-type-definition-packet.json && cat .astis/huanjian-gc-radial-exponential-20261110/selective-type-definition-packet.json
python3 .astis/semantic-neutral-20261110/re_src_6c28/phase2/verify_packet.py > .astis/semantic-neutral-20261110/re_src_6c28/phase2/packet_execution.txt 2>&1 && cat .astis/semantic-neutral-20261110/re_src_6c28/phase2/packet_execution.txt
```

The literal verification exited 0 (chunk `449b0e`). Its original output is `packet_execution.txt`. It checks packet-contained definitions and their span lengths, without opening the referenced implementation files.
