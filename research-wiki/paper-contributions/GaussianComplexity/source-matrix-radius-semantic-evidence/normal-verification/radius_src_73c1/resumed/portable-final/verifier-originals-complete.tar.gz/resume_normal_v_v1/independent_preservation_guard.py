"""Independent read-only full preservation/once preflight. Never emit full private input."""
from pathlib import Path
import collections,copy,hashlib,json,os,stat,subprocess,sys,time
sys.dont_write_bytecode=True
ROOT=Path.cwd()
W=ROOT/".astis/huanjian-gc-source-matrix-radius-20261113"
OUT=Path(__file__).resolve().parent
ADV="ASTIS-SA-20261113-GaussianComplexitySourceMatrixRadius"
LEDGER="runs/substantive_advances.jsonl"
HELD="9e5ee5685d4f05fcfba9bcf700af25b8ec61386b"
PHASE=sys.argv[1] if len(sys.argv)>1 else "before"
assert PHASE in {"before","precall","post"}
EXPECTED_STATE="VERIFIED" if PHASE=="post" else "PROVED_LOCAL"
EXPECTED_V_COUNT=1 if PHASE=="post" else 0
OWN_C="research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-source-matrix-radius.json"
sha=lambda b:hashlib.sha256(b).hexdigest()
def canon(o):return json.dumps(o,ensure_ascii=False,sort_keys=True,separators=(",",":")).encode()
def fingerprint(p):
 try: s=p.lstat()
 except FileNotFoundError:return {"kind":"missing"}
 if stat.S_ISLNK(s.st_mode):return {"mode":stat.S_IMODE(s.st_mode),"kind":"symlink","target":os.readlink(p)}
 if not stat.S_ISREG(s.st_mode):return {"kind":"nonregular","mode":stat.S_IMODE(s.st_mode)}
 return {"mode":stat.S_IMODE(s.st_mode),"kind":"regular","bytes":s.st_size,"sha256":sha(p.read_bytes())}
def index_records(raw):
 records=[]
 for row in raw.split(b"\0"):
  if row:
   meta,path=row.split(b"\t",1); fields=meta.split()
   records.append((os.fsdecode(path),meta.decode(),int(fields[2])))
 return records
def fold_advances(records):
 states={}
 for r in records:
  aid=r.get("advance_id")
  if not isinstance(aid,str) or not aid:continue
  if r.get("event")=="proposal":
   x=copy.deepcopy(r)
   for k,v in [("frontier_cell","global"),("target_declarations",[]),("checkpoint_count",0),("no_progress_streak",0),("needs_diagnosis",False)]:x.setdefault(k,v)
   states[aid]=x
  elif aid in states and r.get("event")=="transition":
   x=states[aid];s=r.get("to_state",x.get("state"));x["state"]=s;x["last_actor"]=r.get("worker_id",x.get("last_actor",""))
   if s=="CLAIMED":x["owner_id"]=r.get("worker_id","");x["no_progress_streak"]=0;x["needs_diagnosis"]=False
   x["modes"]=list(r.get("modes") or x.get("modes") or [])
   if r.get("evidence"):
    x["latest_evidence"]=copy.deepcopy(r["evidence"])
    if s=="PROVED_LOCAL" and r["evidence"].get("publication_declarations"):x["publication_declarations"]=r["evidence"]["publication_declarations"]
   x["updated_at"]=r.get("created_at",x.get("updated_at"))
  elif aid in states and r.get("event")=="checkpoint":
   x=states[aid];prev=x.get("latest_checkpoint") or {};same=prev.get("route_fingerprint")==r.get("route_fingerprint") and prev.get("progress_signature")==r.get("progress_signature")
   streak=int(x.get("no_progress_streak",0))+1 if same else 1
   x["checkpoint_count"]=int(x.get("checkpoint_count",0))+1;x["no_progress_streak"]=streak;x["needs_diagnosis"]=streak>=3;x["latest_checkpoint"]=copy.deepcopy(r);x["updated_at"]=r.get("created_at",x.get("updated_at"))
 return states
def fold_discoveries(records):
 state={}
 for r in records:
  did=r.get("discovery_id")
  if not isinstance(did,str) or not did:continue
  if r.get("event")=="discovery":
   x=copy.deepcopy(r);x.setdefault("frontier_cell","global");x.setdefault("metadata",{});state[did]=x
  elif r.get("event")=="discovery_transition" and did in state:
   x=state[did];x["status"]=r.get("to_status",x.get("status"));x["updated_at"]=r.get("created_at",x.get("updated_at"))
   if r.get("note"):x["latest_note"]=r["note"]
   x["latest_actor"]=r.get("actor",x.get("latest_actor",""))
 return state
start=time.time()
baseline_bytes=(W/"preproof-baseline.private.json").read_bytes();baseline_sha=sha(baseline_bytes);b=json.loads(baseline_bytes);del baseline_bytes
discovery_baseline_bytes=(W/"preproof-discoveries.private.json").read_bytes();discovery_baseline_sha=sha(discovery_baseline_bytes);db=json.loads(discovery_baseline_bytes);del discovery_baseline_bytes
head_before=subprocess.check_output(["git","rev-parse","HEAD"],text=True).strip()
index_before=subprocess.check_output(["git","ls-files","--stage","-z"])
raw=(ROOT/LEDGER).read_bytes()
rows=raw.splitlines(keepends=True)
records=[json.loads(x) for x in rows]
own=[r for r in records if r.get("advance_id")==ADV]
PL=[r for r in own if r.get("event")=="transition" and r.get("to_state")=="PROVED_LOCAL"]
V=[r for r in own if r.get("event")=="transition" and r.get("to_state")=="VERIFIED"]
plpath=ROOT/"research-wiki/paper-contributions/GaussianComplexity/source-matrix-radius-semantic-evidence/actual-PROVED_LOCAL-evidence.full.json"
plbytes=plpath.read_bytes();pl=json.loads(plbytes)
own_pl_rows=[line for line,r in zip(rows,records) if r.get("advance_id")==ADV and r.get("event")=="transition" and r.get("to_state")=="PROVED_LOCAL"]
oldledger=b["all_existing_tracked_fingerprints"].get(LEDGER) or b["actual_control_fingerprints"].get(LEDGER)
prefix_size=oldledger["bytes"]
suffix=raw[prefix_size:]
suffix_records=[json.loads(x) for x in suffix.splitlines()]
states=fold_advances(records)
own_state=states.pop(ADV)
discovery_raw=(ROOT/"runs/substantive_discoveries.jsonl").read_bytes()
discovery_records=[json.loads(x) for x in discovery_raw.splitlines()]
discoveries=fold_discoveries(discovery_records)
fps=dict(b["all_existing_tracked_fingerprints"])
overlap=set(fps)&set(b["actual_control_fingerprints"])
overlap_consistent=all(fps[p]==b["actual_control_fingerprints"][p] for p in overlap)
fps.update(b["actual_control_fingerprints"])
bad_fp=[]
for p,expected in fps.items():
 if p!=LEDGER and fingerprint(ROOT/p)!=expected:bad_fp.append(p)
bad_frontier=[p for p,h in b["all_existing_frontier_hashes"].items() if sha((ROOT/p).read_bytes())!=h]
old_index_records=index_records(b["tracked_git_index"].encode())
new_index_records=index_records(index_before)
oldidx={p:m for p,m,s in old_index_records}
newidx={p:m for p,m,s in new_index_records}
index_unique_stage0=all(s==0 for p,m,s in old_index_records+new_index_records) and len(oldidx)==len(old_index_records) and len(newidx)==len(new_index_records)
bad_index=[p for p,m in oldidx.items() if p!=LEDGER and newidx.get(p)!=m]
new_paths=set(newidx)-set(oldidx)
allowed_exact={
"AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumSourceMatrixRadius.lean",
"Tests/GaussianComplexityFixedSpectrumSourceMatrixRadius.lean",
"website/content/declaration_lessons/huanjian-gaussian-source-matrix-radius.json",
"website/content/publications/huanjian-gaussian-source-matrix-radius.json",
"research-wiki/semantic-roundtrip/audits/huanjian-gaussian-source-matrix-radius.json",
"research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-source-matrix-radius.json"
}
def owned_new_path(p):return p in allowed_exact or p.startswith("research-wiki/paper-contributions/GaussianComplexity/source-matrix-radius")
bad_new=[p for p in new_paths if not owned_new_path(p)]
current_frontiers={str(p.relative_to(ROOT)) for p in (ROOT/"research-wiki/frontier-cells").glob("*.json") if p.is_file()}
new_frontiers=current_frontiers-set(b["all_existing_frontier_hashes"])
bad_new_frontiers=new_frontiers-{"research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-source-matrix-radius.json"}
head_after=subprocess.check_output(["git","rev-parse","HEAD"],text=True).strip()
index_after=subprocess.check_output(["git","ls-files","--stage","-z"])
tracked_clean=subprocess.run(["git","diff-index","--quiet","HEAD","--"]).returncode==0
checks={
"held_HEAD_before_and_after":head_before==head_after==HELD,
"index_unchanged_during_check":index_before==index_after,
"tracked_worktree_scope_exact": (tracked_clean if PHASE!="post" else set(os.fsdecode(x) for x in subprocess.check_output(["git","diff","--name-only","-z"]).split(b"\0") if x)=={LEDGER,OWN_C}),
"held_index_stage_hash_exact":sha(index_before)=="489731b57b16e2f4961df393f8c833e54b58994f76229596b85a5db986917465",
"original_ledger_prefix_byte_preserved":sha(raw[:prefix_size])==oldledger["sha256"],
"ledger_suffix_valid_complete_lines":not suffix or suffix.endswith(b"\n"),
"ledger_suffix_exact_own_advance_only":all(r.get("advance_id")==ADV for r in suffix_records),
"independent_full_foreign_replay_equal_baseline":states==b["all_foreign_states"],
"own_current_state_exact":own_state.get("state")==EXPECTED_STATE,
"own_proposal_count_exactly1":sum(r.get("event")=="proposal" for r in own)==1,
"own_PROVED_LOCAL_count_exactly1":len(PL)==1,
"own_VERIFIED_count_exact":len(V)==EXPECTED_V_COUNT,
"original_PL_payload_raw_hash_exact":sha(plbytes)=="e2ca572ea630b2a9df348206e21fb92f36c43954cbb6c83a02e8e8144bdd34c7",
"all25_PL_values_equal_actual_once_ledger_evidence":len(PL)==1 and len(pl)==25 and PL[0].get("evidence")==pl,
"original_PL_append_line_hash_exact":len(own_pl_rows)==1 and sha(own_pl_rows[0])=="cd0fe1d69bf33d3db43c6646d27c46135d205ff67f27c60175164fd8f99b6360",
"foreign_frontier_files_preserved":not bad_frontier,
"no_new_foreign_frontier_file":not bad_new_frontiers,
"discovery_ledger_exact_original_hash":sha(discovery_raw)==db["ledger_sha256"],
"overlapping_original_fingerprint_entries_consistent":overlap_consistent,
"all_original_nonledger_tracked_and_control_fingerprints_preserved":not bad_fp,
"old_index_entries_preserved_except_owned_ledger":not bad_index,
"old_and_new_index_all_unique_stage0":index_unique_stage0,
"all_new_tracked_paths_within_R10_owned_scope":not bad_new
}
if PHASE=="post":
 current_cell=(ROOT/OWN_C).read_bytes()
 expected_cell=(OUT/"ownC.prospective.json").read_bytes()
 checks["ownC_exactly_prospective_schema_checked_bytes"]=current_cell==expected_cell
 checks["post_V_retains_all25_original_PL_values_inline"]=len(V)==1 and all(V[0].get("evidence",{}).get(k)==v for k,v in pl.items())
 checks["post_V_independent_identity_exact"]=len(V)==1 and V[0].get("worker_id")==V[0].get("evidence",{}).get("verifier_id")=="radius_src_73c1_independent_resumed_verifier" and V[0].get("worker_id")!=own_state.get("owner_id")
 checks["post_V_required_string_schema"]=len(V)==1 and isinstance(V[0]["evidence"].get("independent_verification"),str) and bool(V[0]["evidence"]["independent_verification"].strip())
summary={"phase":PHASE,"held_commit":HELD,"result":"PASS" if all(checks.values()) else "HOLD_WITH_FAILED_CHECKS","checks":checks,"bounded_counts":{"foreign_full_states":len(states),"foreign_frontier_hashes":len(b["all_existing_frontier_hashes"]),"new_frontier_files":len(new_frontiers),"unexpected_new_foreign_frontier_files":len(bad_new_frontiers),"existing_tracked_fingerprints":len(b["all_existing_tracked_fingerprints"]),"captured_control_fingerprints":len(b["actual_control_fingerprints"]),"unique_original_fingerprint_paths":len(fps),"overlapping_original_fingerprint_paths":len(overlap),"nonledger_fingerprint_mismatches":len(bad_fp),"foreign_frontier_mismatches":len(bad_frontier),"old_index_entries":len(oldidx),"new_index_entries":len(newidx),"new_owned_tracked_paths":len(new_paths)-len(bad_new),"unexpected_new_tracked_paths":len(bad_new),"index_mismatches":len(bad_index),"discovery_full_states_dynamic":len(discoveries),"own_proposals":sum(r.get("event")=="proposal" for r in own),"own_PL_transitions":len(PL),"own_V_transitions":len(V),"own_suffix_records":len(suffix_records),"original_PL_fields":len(pl)},"bounded_hashes":{"private_baseline_sha256":baseline_sha,"private_discoveries_baseline_sha256":discovery_baseline_sha,"current_ledger_sha256":sha(raw),"current_discovery_ledger_sha256":sha(discovery_raw),"current_full_index_sha256":sha(index_before),"current_full_foreign_states_canonical_sha256":sha(canon(states)),"current_full_discovery_states_canonical_sha256":sha(canon(discoveries)),"new_tracked_pathset_canonical_sha256":sha(canon(sorted(new_paths))),"unexpected_new_tracked_pathset_canonical_sha256":sha(canon(sorted(bad_new))),"current_PL_payload_sha256":sha(plbytes),"original_PL_append_line_sha256":sha(own_pl_rows[0]) if len(own_pl_rows)==1 else None},"helper_logic_assessment":"Original helper full-state/file/index comparisons are sound for captured existing artifacts. Independent checks additionally require exact ledger prefix and own-only suffix, actual once-history/payload equality, dynamic discovery replay count, consistent overlapping fingerprints, unique stage0 index, no new foreign frontier and narrow ownership of all newly tracked paths. No hard-coded discovery count is trusted.","private_material_policy":"All full private baselines, states, file/index maps and evidence values stay only in local memory/original private files; this result emits bounded counts/hashes/booleans only.","elapsed_seconds":round(time.time()-start,3),"normal_API_calls":EXPECTED_V_COUNT,"canonical_edits":False,"precall_qualification":"This is preflight at heldHEAD, not permission to call normalV. Fresh before/precall/post checks and final native visual/four-gate package plus explicit ROOT exact-once release remain required."}
(OUT/("private_guard."+PHASE+".json")).write_text(json.dumps(summary,indent=2)+"\n")
print(json.dumps(summary,indent=2))
