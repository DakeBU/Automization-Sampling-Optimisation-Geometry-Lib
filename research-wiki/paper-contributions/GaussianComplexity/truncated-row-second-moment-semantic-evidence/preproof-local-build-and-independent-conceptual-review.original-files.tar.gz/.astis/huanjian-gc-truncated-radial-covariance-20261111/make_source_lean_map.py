"""Locate source formulas and the exact compiled proof and statement spans."""
from html.parser import HTMLParser
from pathlib import Path
import hashlib
import json

evidence = Path('research-wiki/paper-contributions/GaussianComplexity/truncated-row-second-moment-semantic-evidence')
raw = Path('.astis/huanjian-resume-20261103/2610.20492v1.html').read_bytes()
text = raw.decode()
sha = lambda data: hashlib.sha256(data).hexdigest()
assert sha(raw) == '6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
offsets = [0] + [i + 1 for i, char in enumerate(text) if char == '\n']


class SourceElements(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=False)
        self.stack = []
        self.elements = {}

    def source_offset(self):
        line, col = self.getpos()
        return offsets[line - 1] + col

    def handle_starttag(self, tag, attrs):
        if tag not in {'area', 'base', 'br', 'col', 'embed', 'hr', 'img', 'input', 'link', 'meta', 'param', 'source', 'track', 'wbr'}:
            self.stack.append((tag, dict(attrs).get('id'), self.source_offset()))

    def handle_endtag(self, tag):
        for i in range(len(self.stack) - 1, -1, -1):
            if self.stack[i][0] == tag:
                _, identifier, start = self.stack[i]
                if identifier:
                    self.elements[identifier] = (start, text.index('>', self.source_offset()) + 1)
                del self.stack[i:]
                return


parser = SourceElements()
parser.feed(text)


def source_span(identifier):
    first, last = parser.elements[identifier]
    data = text[first:last].encode()
    a, b = len(text[:first].encode()), len(text[:last].encode())
    assert raw[a:b] == data and f'id="{identifier}"'.encode() in data
    return {
        'source_id': identifier, 'char_start': first, 'char_end': last,
        'raw_utf8_start': a, 'raw_utf8_end': b,
        'lf_line_start': text.count('\n', 0, first) + 1,
        'lf_column0_start': first - text.rfind('\n', 0, first) - 1,
        'lf_line_end': text.count('\n', 0, last) + 1, 'span_sha256': sha(data),
    }


P = Path('AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumTruncatedRowMoment.lean')
T = Path('Tests/GaussianComplexityFixedSpectrumTruncatedRowMoment.lean')


def code_span(path, first, last):
    raw_code = path.read_bytes()
    lines = raw_code.splitlines(keepends=True)
    assert 1 <= first <= last <= len(lines)
    prefix, body = b''.join(lines[:first - 1]), b''.join(lines[first - 1:last])
    return {'path': str(path), 'file_sha256': sha(raw_code),
            'LF_lines_1based': [first, last],
            'raw_UTF8_byte_span': [len(prefix), len(prefix) + len(body)],
            'decoded_char_span': [len(prefix.decode()), len(prefix.decode()) + len(body.decode())],
            'span_sha256': sha(body)}


def mapping(identifiers, ranges, meaning):
    return {'source': [source_span(x) for x in identifiers],
            'lean': [code_span(*entry) for entry in ranges], 'meaning': meaning}


mappings = [
    mapping(['S4.Thmtheorem4.p1.m2', 'S4.Thmtheorem4.p1.m3'],
            [(P, 21, 21), (T, 20, 20)], 'Natural query count including zero and the standing 2q+1<d range.'),
    mapping(['A3.SS2.p1.m1', 'A3.SS2.p1.m5', 'A3.SS2.p10.m1', 'A3.SS2.p10.m2'],
            [(P, 22, 26), (T, 21, 25)],
            'Actual row dimension, canonical single-row standard law, squared radius and literal cutoff. Original joint-row law transport is a separate obligation.'),
    mapping(['A3.Ex108.m1'], [(P, 27, 33), (P, 34, 92)],
            'The exact scalar and matrix statement, with scalar and matrix integrability supplied internally.'),
    mapping(['A3.SS2.p12.2', 'A3.Ex108.m1'], [(P, 93, 125), (P, 127, 145)],
            'The source radial-symmetry invocation is expanded into actual standard-law isometry invariance, sign cancellation and equal diagonals.'),
    mapping(['A3.Ex108.m1'], [(P, 147, 180)],
            'The coefficient is identified by the retained squared-radius trace and positive dimension, then entrywise equality yields the source matrix identity.'),
    mapping(['S4.E11.m1', 'A3.SS2.p5.m2', 'A3.Ex85.m1'], [(T, 27, 29)],
            'The literal deterministic source feature. Source row j=i.val+1 gives the midpoint angle, and feature frequencies run from zero to q. Constant coordinate one and higher sqrt(2) normalization come directly from Ex85.'),
    mapping(['A3.SS2.p12.m1', 'A3.SS2.p12.m2', 'A3.SS2.p12.3'],
            [(P, 22, 27), (T, 21, 26)],
            'The scalar a uses the common canonical marginal and cutoff. Its definition is independent of the summand index. The earlier scalar range and bias are recorded in the preceding packet.'),
    mapping(['A3.Ex107.m1'], [(T, 30, 34), (T, 48, 56)],
            'The actual truncated single-row matrix with tensor factor order and inverse dimension scaling.'),
    mapping(['A3.SS2.p12.m5'], [(T, 35, 38), (T, 57, len(T.read_text().splitlines()) - 2)],
            'Both producer components are consumed through the actual continuous linear deterministic Kronecker map, proving integrability and the exact source matrix expectation.'),
]
draft = json.loads((evidence / 'publication-draft-record.json').read_bytes())
record = {
    'kind': 'Root-authored exact source/Lean map for independent review',
    'source_sha256': sha(raw), 'actual_ASTIS_proof_parents': draft['actual_public_ASTIS_parents'],
    'mappings': mappings,
    'proof_background': [
        {'declaration': 'ProbabilityTheory.stdGaussian_map',
         'source': code_span(Path('.lake/packages/mathlib/Mathlib/Probability/Distributions/Gaussian/Multivariate.lean'), 128, 135),
         'mathlib_pin': 'db584cd6d46c92f209a44c0f1c829460d327499d',
         'consumer': code_span(P, 93, 101),
         'meaning': 'Canonical standard-Gaussian law invariance for the actual linear isometries.'},
    ],
    'scope': 'Exact Ex108 and p12.m5 canonical one-row statements. Source-index adapters are explicit provenance. Original joint input-law transport, aggregate frame means, centered/variance/concentration bounds and full-paper public integration remain pending.',
}
path = evidence / 'source-lean-map.draft.json'
with path.open('x') as out:
    json.dump(record, out, ensure_ascii=False, indent=2)
    out.write('\n')
print(json.dumps({'path': str(path), 'sha256': sha(path.read_bytes()),
                  'source_locator_entries': sum(len(m['source']) for m in mappings),
                  'Lean_spans': sum(len(m['lean']) for m in mappings)}))
