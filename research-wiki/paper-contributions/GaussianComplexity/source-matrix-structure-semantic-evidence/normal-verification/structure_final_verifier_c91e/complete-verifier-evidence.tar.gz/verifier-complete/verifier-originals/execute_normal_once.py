"""One explicit normal API call; exact post-state inspection prevents replay."""
from pathlib import Path
import datetime, hashlib, importlib.util, json, os, stat, subprocess, sys, traceback
sys.dont_write_bytecode = True
O = Path(__file__).resolve().parent
def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m
p = load_module('verifier_preflight', O/'preflight.py')
s = load_module('verifier_snapshot_checker', O/'check_snapshot.py')
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def record(path, obj): p.write(path,obj)
def inspect_own():
    raw = Path(p.L).read_bytes()
    assert raw.endswith(b'\n') and all(raw.splitlines()), 'unclean ledger tail: do not invoke recovery'
    events = [json.loads(x) for x in raw.splitlines() if json.loads(x).get('advance_id') == p.ADV]
    pls = [e for e in events if e.get('to_state') == 'PROVED_LOCAL']
    vs = [e for e in events if e.get('to_state') == 'VERIFIED']
    return raw,pls,vs
def main():
    start = now(); payload = p.read(O/'VERIFIED-evidence.full.json')
    ready = p.read(O/'ROOT-READY.received.json')
    assert ready['authorized_actor'] == payload['verifier_id'] == 'structure_final_verifier_c91e'
    assert ready['held_head'] == payload['verified_commit'] == p.HELD
    assert p.git('rev-parse','HEAD').decode().strip() == p.HELD
    original = p.read(p.E/'actual-PROVED_LOCAL-evidence.full.json')
    assert len(original) == 26 and all(payload[k] == v for k,v in original.items())
    raw,pls,vs = inspect_own()
    assert len(pls) == 1 and len(vs) == 0, 'inspect existing transition; never replay'
    marker = O/'normal-VERIFIED-call.once.json'
    assert not marker.exists(), 'once marker exists: inspect ledger instead of retrying'
    # First enforce the held full snapshot, then the older protected baseline.
    held = s.check('held-preflight',payload,after=False)
    old_before = p.guard('PROVED_LOCAL')
    fresh = p.snapshot('before-normalV')
    record(O/'before-normalV-preservation.bounded.json',{
        'status':'PASS','held_snapshot_check':held,'old_full_baseline_guard':old_before,
        'fresh_private_snapshot':fresh,'full_private_maps_exported':False})
    # Reinspect exact state immediately before the one call marker.
    raw2,pls2,vs2 = inspect_own()
    assert raw2 == raw and len(pls2) == 1 and not vs2
    cell_before = Path(p.C).read_bytes()
    assert p.read(p.C)['status'] == 'proved_locally'
    (O/'cell-before.exact.json').write_bytes(cell_before)
    assert stat.S_IMODE(Path(p.C).stat().st_mode) == stat.S_IMODE(Path(p.C).lstat().st_mode)
    marker_obj = {'created_at':now(),'verifier_id':payload['verifier_id'],
        'advance_id':p.ADV,'from_state':'PROVED_LOCAL','to_state':'VERIFIED',
        'held_head':p.HELD,'payload_sha256':p.sha((O/'VERIFIED-evidence.full.json').read_bytes()),
        'ledger_before_sha256':p.sha(raw),'normal_API_calls_authorized':1,
        'rule':'Marker prevents retries. Always inspect exact ledger suffix/state after any exception.'}
    fd = os.open(marker,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    with os.fdopen(fd,'w') as f:
        json.dump(marker_obj,f,ensure_ascii=False,indent=2); f.write('\n'); f.flush(); os.fsync(f.fileno())
    print('Preconditions and both full preservation baselines PASS; invoking one normal VERIFIED API.',flush=True)
    sys.path.insert(0,'tools'); import astis_advance
    api_started = now(); api_error = None
    try:
        astis_advance.transition_advance(p.ADV,'VERIFIED',worker_id=payload['verifier_id'],
            modes=['independent-verification'],evidence=payload,
            path=Path(p.L),discovery_path=Path('runs/substantive_discoveries.jsonl'))
    except BaseException as e:
        api_error = {'type':type(e).__name__,'message':str(e),'traceback':traceback.format_exc()}
    afterraw,afterpls,aftervs = inspect_own()
    suffix = afterraw[len(raw):] if afterraw.startswith(raw) else b''
    api_receipt = {'started_at':api_started,'ended_at':now(),'api':'astis_advance.transition_advance',
        'advance_id':p.ADV,'to_state':'VERIFIED','worker_id':payload['verifier_id'],
        'calls':1,'exception':api_error,'ledger_prefix_preserved':afterraw.startswith(raw),
        'PL_count_after':len(afterpls),'VERIFIED_count_after':len(aftervs),
        'exact_suffix_lines':len(suffix.splitlines()),'exact_suffix_sha256':p.sha(suffix),
        'append_survives_exception_must_not_retry':True}
    record(O/'normal-API.receipt.json',api_receipt)
    assert afterraw.startswith(raw) and suffix.endswith(b'\n') and len(suffix.splitlines()) == 1, 'API outcome incomplete; inspect, never replay'
    event = json.loads(suffix)
    assert len(afterpls) == 1 and len(aftervs) == 1 and event in aftervs
    assert event['evidence'] == payload and event['worker_id'] == payload['verifier_id']
    # Normal API never writes C. Complete only this owned cell after exact append.
    candidate = (O/'candidate-cell.exact.json').read_bytes()
    mode = stat.S_IMODE(Path(p.C).stat().st_mode)
    temporary = Path(p.C).with_suffix('.verifier-c91e.tmp')
    with temporary.open('xb') as f:
        f.write(candidate); f.flush(); os.fsync(f.fileno())
    temporary.chmod(mode); os.replace(temporary,Path(p.C))
    old_after = p.guard('VERIFIED')
    exact_after = s.check('before-normalV',payload,after=True)
    record(O/'after-normalV-preservation.bounded.json',{
        'status':'PASS','old_full_baseline_guard':old_after,'fresh_held_snapshot_check':exact_after,
        'owner_retained':p.read(p.C)['owner_id'],'full_private_maps_exported':False})
    # Run the actual full schema after the write, recording complete raw streams.
    d = O/'commands/postwrite-frontier'; d.mkdir(parents=True,exist_ok=False)
    argv = [sys.executable,'tools/astis_frontier_cells.py','check']; begun = now()
    r = subprocess.run(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    (d/'stdout').write_bytes(r.stdout); (d/'stderr').write_bytes(r.stderr)
    receipt = {'argv':argv,'started_at':begun,'ended_at':now(),'exit_code':r.returncode,
        'head':p.git('rev-parse','HEAD').decode().strip(),
        'stdout_sha256':p.sha(r.stdout),'stderr_sha256':p.sha(r.stderr),
        'schema_script_sha256':p.sha(Path('tools/astis_frontier_cells.py').read_bytes())}
    record(d/'receipt.json',receipt)
    assert r.returncode == 0, 'postwrite schema failed; do not replay V'
    c = p.read(p.C)
    assert isinstance(c['evidence']['independent_verification'],str) and c['evidence']['independent_verification']
    assert c['evidence']['independent_verification_details'] == payload
    assert all(c['evidence']['independent_verification_details'][k] == v for k,v in original.items())
    assert c['owner_id'] == 'huanjian_gc_20261113_source_matrix_structure'
    outcome = {'status':'VERIFIED_LOCAL_ONCE_OWNER_AND_GLOBAL_HOLD_RETAINED',
        'started_at':start,'ended_at':now(),'verifier_id':payload['verifier_id'],
        'verified_commit':p.HELD,'actual_compiled_math_commit':p.MATH,
        'normal_API_calls':1,'actual_PROVED_LOCAL_transitions':1,'actual_VERIFIED_transitions':1,
        'original_PL_fields_inline_unchanged_in_V_and_Cdetails':26,
        'payload_sha256':p.sha((O/'VERIFIED-evidence.full.json').read_bytes()),
        'actual_VERIFIED_append_sha256':p.sha(suffix),
        'cell_after_sha256':p.sha(Path(p.C).read_bytes()),
        'postwrite_full_frontier_schema_exit':r.returncode,
        'all_old_and_fresh_full_preservation_guards':'PASS',
        'ownC_evidence_independent_verification_is_string':True,
        'owner_retained':c['owner_id'],
        'only_ownC_plus_exact_normal_ledger_append_changed':True,
        'source_review_Lean_build_browser_replayed':False,
        'reader_original':'FAIL','conditional_runtime_and_visual':'PASS_GLOBALLY_UNAPPLIED',
        'mobile_sourceL13_fixed_header_limitation_retained':True,
        'integration_publication_purification_whole_Goal':'HOLD',
        'full_private_maps_exported':False}
    record(O/'normal-VERIFIED-outcome.bounded.json',outcome)
    print(json.dumps(outcome,ensure_ascii=False,indent=2),flush=True)
if __name__ == '__main__': main()
