from hashlib import sha256
from pathlib import Path
import json
import os
import shlex
import subprocess
import sys

out = Path(__file__).resolve().parent
repo = out.parents[2]
candidate = '49259190ed5aa40ac0696699eb2aaf9635a3697d'
blobs = out / 'blobs'
proof = 'AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumTruncatedRadialMoment.lean'
consumer = 'Tests/GaussianComplexityFixedSpectrumTruncatedRadialMoment.lean'
modules = [
    'AutoSamplingTheory/TechnicalLemmas/Measure/RadonNikodym.lean',
    'AutoSamplingTheory/TechnicalLemmas/Measure/IsotropicGaussianDensity.lean',
    'AutoSamplingTheory/TechnicalLemmas/Probability/StdGaussianRadialExponential.lean',
    'AutoSamplingTheory/TechnicalLemmas/Probability/StdGaussianMoment.lean',
    proof,
    consumer,
]
base = 'research-wiki/paper-contributions/GaussianComplexity/'
seal_path = base + 'truncated-radial-moment-statement-seal.json'
map_path = base + 'truncated-radial-moment-semantic-evidence/source-lean-map.draft.json'
slug = 'huanjian-gaussian-truncated-radial-moment'
inputs = modules + [
    'lean-toolchain', 'lake-manifest.json', seal_path, map_path,
    'website/content/declaration_lessons/' + slug + '.json',
    'website/content/publications/' + slug + '.json',
]
expected = {
    proof: 'f0f1a83f03793d1c3619a91980f3969d8fa09f579d617a3bb8ec295320fabffd',
    consumer: 'd9820c4438e058c12e7bd1a08dc32704bd6bbd192c0522f8c9edbca7e62ae944',
    'lake-manifest.json': 'b83ca83b9cf7caa85fa8b023c2ff9a3fb7a7cce7e1c332e810c348535ec49c37',
}


def run(args, cwd=repo, env=None):
    print(shlex.join(map(str, args)), f'[cwd={cwd}]', flush=True)
    proc = subprocess.run(args, cwd=cwd, env=env, capture_output=True)
    if proc.stderr:
        sys.stderr.buffer.write(proc.stderr)
        sys.stderr.flush()
    print(f'exit={proc.returncode}', flush=True)
    proc.check_returncode()
    return proc.stdout


def write_blob(path):
    content = run(['git', 'cat-file', 'blob', f'{candidate}:{path}'])
    target = blobs / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(content)
    digest = sha256(content).hexdigest()
    assert path not in expected or digest == expected[path], (path, digest)
    return digest


def audit_source():
    return {path: write_blob(path) for path in inputs}


def audit_dependencies(manifest):
    packages = []
    build_paths = []
    for package in manifest['packages']:
        name = package['name']
        path = repo / manifest['packagesDir'] / name
        actual = run(['git', '-C', path, 'rev-parse', 'HEAD']).decode().strip()
        status = run(['git', '--no-optional-locks', '-C', path, 'status', '--porcelain=v1', '--untracked-files=all']).decode()
        print(f'{name}: {actual}, porcelain={status!r}', flush=True)
        assert actual == package['rev'] and not status, (name, actual, status)
        packages.append({'name': name, 'head': actual, 'porcelain': status})
        compiled = path / '.lake' / 'build' / 'lib' / 'lean'
        if compiled.is_dir():
            assert not (compiled / 'AutoSamplingTheory').exists()
            assert not (compiled / 'Tests').exists()
            build_paths.append(str(compiled.resolve()))
    assert len(packages) == 9
    return packages, build_paths


def main():
    assert run(['git', 'rev-parse', f'{candidate}^{{commit}}']).decode().strip() == candidate
    hashes = audit_source()
    toolchain = (blobs / 'lean-toolchain').read_text().strip()
    assert toolchain == 'leanprover/lean4:v4.33.0'
    lean = Path.home() / '.elan' / 'toolchains' / 'leanprover--lean4---v4.33.0' / 'bin' / 'lean'
    machine = run(['file', lean]).decode().strip()
    version = run([lean, '--version']).decode().strip()
    lean_digest = sha256(lean.read_bytes()).hexdigest()
    print(machine, version, lean_digest, sep='\n', flush=True)
    assert 'Mach-O 64-bit executable arm64' in machine
    assert version == 'Lean (version 4.33.0, arm64-apple-darwin24.6.0, commit d8b18978322de05a8f3dba51ef03cf5461676c17, Release)'
    assert lean_digest == '1b370cfcbf44e80d1b004ab1b1ab9a4c73951f9f7c242140bcff9bc577576554'
    manifest = json.loads((blobs / 'lake-manifest.json').read_bytes())
    packages, dep_build_paths = audit_dependencies(manifest)
    raw = repo / '.astis/huanjian-resume-20261103/2610.20492v1.html'
    raw_digest = sha256(raw.read_bytes()).hexdigest()
    assert raw_digest == '6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
    (out / '2610.20492v1.html').write_bytes(raw.read_bytes())
    prefix = out / 'native-prefix'
    prefix.mkdir(exist_ok=False)
    env = os.environ.copy()
    for name in tuple(env):
        if name.startswith(('LEAN', 'LAKE', 'ELAN', 'DYLD')):
            env.pop(name)
    env['LEAN_PATH'] = os.pathsep.join([str(prefix), *dep_build_paths])
    print(f"LEAN_PATH={env['LEAN_PATH']}", flush=True)
    receipt = {
        'commit': candidate, 'lean': str(lean), 'version': version, 'lean_sha256': lean_digest,
        'machine': machine, 'source_sha256': raw_digest, 'manifest_packages': packages,
        'blobs_sha256': hashes, 'lean_path': env['LEAN_PATH'], 'compiles': [],
    }
    for path in modules:
        artifact = prefix / Path(path).with_suffix('.olean')
        artifact.parent.mkdir(parents=True, exist_ok=True)
        args = [str(lean), '-o', str(artifact), path]
        stdout = run(args, cwd=blobs, env=env)
        (out / f'{Path(path).stem}.lean.stdout').write_bytes(stdout)
        if stdout:
            print(stdout.decode(), end='', flush=True)
        receipt['compiles'].append({'args': args, 'cwd': str(blobs), 'olean_sha256': sha256(artifact.read_bytes()).hexdigest()})
        (out / 'native-manifest.json').write_text(json.dumps(receipt, indent=2) + '\n')


if __name__ == '__main__':
    main()
