from pathlib import Path
import json,hashlib,subprocess,sys
sys.path.insert(0,'tools');import astis_semantic_roundtrip as rt;import astis_publication as pub;import astis_advance as adv
sha=lambda b:hashlib.sha256(b).hexdigest()
b=Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-admissibility-semantic-evidence')
ap=Path('research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-admissibility.json');a=json.loads(ap.read_bytes())
assert a['state']=='blind-reconstructed' and a['publication_binding_sha256']=='e4e245c817d124b16e93b4f999df81132f1e50a9e38535903cb5c036417c0e94'
pub.check_advance([a['lean']['declaration']],reviewed=False)
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert head=='83fec39dfa6202cdf9bc687affb10aafbc216ab8'
assert adv.current_advances()['ASTIS-SA-20261107-GaussianComplexityFixedSpectrumAdmissibility']['state']=='PROVED_LOCAL'
packet=rt.semantic_reviewer_packet(a);p=b/'full-anti-anchored-reviewer-packet.json';assert not p.exists();p.write_text(json.dumps(packet,ensure_ascii=False,indent=2)+'\n')
paths=[ap,Path(a['lean']['file']),Path('Tests/GaussianComplexityFixedSpectrumAdmissibility.lean'),Path('website/content/declaration_lessons/huanjian-fixed-spectrum-admissibility.json'),Path('website/content/publications/huanjian-fixed-spectrum-admissibility.json'),Path('runs/substantive_advances.jsonl'),Path('runs/substantive_discoveries.jsonl')]
record={'checked_candidate_commit':head,'mathematical_candidate':'2df0cd116cd21a71113ae67997b7482878633460','full_packet_path':str(p),'full_packet_raw_sha256':sha(p.read_bytes()),'full_packet_canonical_sha256':packet['packet_sha256'],'publication_binding_sha256':a['publication_binding_sha256'],'exact_inputs':{str(p):sha(p.read_bytes()) for p in paths},'instruction':'Deliver only after independent source phase2 selective comparison freeze. Keep HEAD, audit and ledgers fixed during whole-module/source review. No source verdict or VERIFIED transition is created by root.'}
(b/'full-review-input-pins.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
