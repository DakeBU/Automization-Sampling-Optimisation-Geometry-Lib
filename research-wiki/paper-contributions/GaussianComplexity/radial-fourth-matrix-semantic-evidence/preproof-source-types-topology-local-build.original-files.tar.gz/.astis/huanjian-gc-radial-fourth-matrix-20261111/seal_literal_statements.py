"""Freeze the literal fourth-moment propositions and all meaning-carrying definitions."""
from datetime import datetime, timezone
from html.parser import HTMLParser
from pathlib import Path
import hashlib
import json

workspace = Path(__file__).resolve().parent.relative_to(Path.cwd())
paper = Path('research-wiki/paper-contributions/GaussianComplexity')
evidence = paper / 'radial-fourth-matrix-semantic-evidence'
runner = Path('.astis/huanjian-resume-20261103')
source_path = runner / '2610.20492v1.html'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def dump(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode()


def create(path, raw):
    with path.open('xb') as out:
        out.write(raw)


def checked_run(stem):
    path = runner / (stem + '.receipt.json')
    raw = path.read_bytes()
    receipt = json.loads(raw)
    log = Path(receipt['log']).read_bytes()
    assert receipt['exit_code'] == 0 and sha(log) == receipt['log_sha256']
    return {'receipt': str(path), 'sha256': sha(raw), 'log_sha256': sha(log)}, log


raw_source = source_path.read_bytes()
assert len(raw_source) == 951991
assert sha(raw_source) == '6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
source = raw_source.decode()
offsets = [0] + [i + 1 for i, c in enumerate(source) if c == '\n']


class Locators(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=False)
        self.stack = []
        self.spans = {}

    def source_offset(self):
        line, column = self.getpos()
        return offsets[line - 1] + column

    def handle_starttag(self, tag, attrs):
        if tag in {'area', 'base', 'br', 'col', 'embed', 'hr', 'img', 'input', 'link', 'meta', 'param', 'source', 'track', 'wbr'}:
            return
        self.stack.append((tag, dict(attrs).get('id'), self.source_offset()))

    def handle_endtag(self, tag):
        for index in range(len(self.stack) - 1, -1, -1):
            if self.stack[index][0] == tag:
                _, identifier, start = self.stack[index]
                if identifier:
                    end = source.index('>', self.source_offset()) + 1
                    assert identifier not in self.spans
                    self.spans[identifier] = (start, end)
                del self.stack[index:]
                return


parser = Locators()
parser.feed(source)
anchor_ids = [
    'S4.Thmtheorem4.p1.m2', 'S4.Thmtheorem4.p1.m3',
    'S4.E11.m1', 'A3.SS2.p1', 'A3.SS2.p5.m2', 'A3.Ex85',
    'A3.SS2.p10.m1', 'A3.SS2.p10.m2', 'A3.Ex107.m1',
    'A3.Ex113.m1', 'A3.SS2.p14.2', 'A3.SS2.p14.m1',
    'A3.SS2.p14.m2', 'A3.SS2.p14.m3', 'A3.Ex114.m1',
    'A3.SS2.p14.3', 'A3.EGx11',
]
anchors = []
for identifier in anchor_ids:
    start, end = parser.spans[identifier]
    first_byte, last_byte = len(source[:start].encode()), len(source[:end].encode())
    raw = source[start:end].encode()
    assert raw == raw_source[first_byte:last_byte]
    anchors.append({
        'source_id': identifier, 'char_span': [start, end],
        'UTF8_byte_span': [first_byte, last_byte],
        'LF_lines_1based': [source.count('\n', 0, start) + 1, source.count('\n', 0, end) + 1],
        'span_sha256': sha(raw),
    })
formation, formation_log = checked_run('20261111T054941559694Z-radial-fourth-matrix-literal-Prop-only-formation')
meaning, meaning_log = checked_run('20261111T055057133546Z-radial-fourth-matrix-actual-definition-meaning')
assert b'ProducerStatement : Prop' in formation_log and b'ConsumerStatement : Prop' in formation_log
for name in ('Matrix.PosSemidef', 'Matrix.IsHermitian', 'Matrix.conjTranspose', 'dotProduct',
             'Matrix.instHMulOfFintypeOfMulOfAddCommMonoid', 'Matrix.instMulOfFintypeOfAddCommMonoid'):
    assert name.encode() in meaning_log
previous_context_path = paper / 'truncated-row-second-moment-semantic-evidence/minimal-definition-context.v2.json'
previous_context = json.loads(previous_context_path.read_bytes())
assert sha(previous_context['literal_kernel_print_bodies'].encode()) == previous_context['literal_kernel_print_bodies_sha256']
mul_path = Path('.lake/packages/mathlib/Mathlib/Data/Matrix/Mul.lean')
context = {
    'allowed_only': 'Literal canonical definitions, measures, dimensions, norms, matrix product and PSD conventions. No proposed proof or extra mathematical premise.',
    'mathlib_pin': 'db584cd6d46c92f209a44c0f1c829460d327499d',
    'imports_and_scope': ['import Mathlib', 'open MeasureTheory ProbabilityTheory', 'open scoped Matrix.Norms.L2Operator'],
    'literal_current_prints_and_instances': meaning_log.decode(),
    'literal_current_prints_sha256': sha(meaning_log), 'actual_current_print_receipt': meaning,
    'literal_shared_canonical_definition_prints': previous_context['literal_kernel_print_bodies'],
    'literal_shared_canonical_definition_prints_sha256': previous_context['literal_kernel_print_bodies_sha256'],
    'shared_definition_provenance': str(previous_context_path),
    'integral_definition_source': previous_context['integral_definition_source'],
    'matrix_multiplication_instance_source': {
        'path': str(mul_path), 'LF_lines_1based': [294, 303],
        'text': ''.join(mul_path.read_text().splitlines(keepends=True)[293:303]),
    },
    'meaning': [
        'E is real Euclidean space with q+1 coordinates, its Euclidean norm and Borel sigma-algebra. WithLp.ofLp exposes coordinates.',
        'The actual law is stdGaussian E, defined as the orthonormal-basis pushforward of independent gaussianReal 0 1 coordinates. Gaussian moment and symmetry certificates are not premises.',
        'Matrix indices are finite. vecMulVec v v has entries v_i v_j. The identity is the real diagonal identity. Kronecker indices place Gaussian coordinates first and deterministic feature coordinates second.',
        'The declared matrix norm is the canonical Euclidean L2 operator norm, with its finite-dimensional topology. Integrable is a.e. strong measurability plus finite norm integral. Both matrix integrabilities are conclusions. The Bochner nonintegrable default is zero.',
        'Ordinary matrix multiplication is the finite sum of products. squared x is Y x multiplied by itself, without entrywise squaring.',
        'PosSemidef M asserts Hermitian symmetry and nonnegative quadratic forms for every finitely supported vector. On the finite real paired index set this is the Loewner upper-minus-lower conclusion.',
        'The feature length is explicitly the sum of squared real coordinates, avoiding any function-space norm convention. The cutoff uses the closed event R≤L. No retained-probability normalization is introduced.',
        'The midpoint grid uses source row i_src=i.val+1 and frequencies k=0,...,q. The constant coordinate is one and the higher coordinates are sqrt(2) cos(k theta_i). q=0 gives one coordinate.',
    ],
}
producer = (workspace / 'producer-signature.draft.txt').read_bytes()
consumer = (workspace / 'consumer-signature.draft.txt').read_bytes()
assert not any(token in producer + consumer for token in (b':= by', b'sorry', b'admit', b'axiom'))
environment = json.loads((workspace / 'actual-environment-before-seal.json').read_bytes())
assert environment['manifest_sha256'] == sha(Path('lake-manifest.json').read_bytes())
exposure = json.loads((workspace / 'preseal-exposure.json').read_bytes())
assert exposure['formalizer_API_pristine'] is False
assert exposure['new_target_proof_attempts_before_seal'] == 0
seal = {
    'schema_version': 1, 'seal_id': 'GAUSSIAN-COMPLEXITY-RADIAL-FOURTH-MATRIX-20261111-v1',
    'created_utc': datetime.now(timezone.utc).isoformat(),
    'state': 'EXACT_LITERAL_PROPS_FORMED;UNPROVED;INDEPENDENT_TYPE_TOPOLOGY_PENDING',
    'source': {'version': 'arXiv2610.20492v1', 'raw': str(source_path), 'raw_sha256': sha(raw_source),
               'anchors': anchors,
               'scope': 'C.2 Ex113 matrix fourth moment and the individual PSD consequence of Ex114/p14.3 preceding the aggregate first EGx11 inequality.'},
    'producer': {
        'name': 'AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumRadialFourthMoment.actual_radial_fourth_moment_matrix',
        'planned_file': 'AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumRadialFourthMoment.lean',
        'signature': producer.decode(), 'signature_sha256': sha(producer),
        'outcome': 'Integrable R times the unnormalized rank-one Gaussian matrix, with exact mean (r+2) times the identity.',
    },
    'actual_private_consumer': {
        'name': 'AutoSamplingTheory.Tests.GaussianComplexityFixedSpectrumRadialFourthMoment.actual_truncated_summand_second_moment_bound',
        'planned_file': 'Tests/GaussianComplexityFixedSpectrumRadialFourthMoment.lean',
        'signature': consumer.decode(), 'signature_sha256': sha(consumer),
        'outcome': 'The actual deterministic cosine-row squared summand is integrable and its mean has the individual PSD upper bound with coefficient (r+2) times the explicit feature squared length divided by d squared.',
        'consumer_edge': 'Materially consume both the producer integrability and its exact mean. Prove square algebra, PSD indicator removal and integral transport internally.',
        'source_status': 'Termwise source-supported inference, not a separately numbered source equation. The source displays its aggregate immediately afterward.',
    },
    'binder_audit': [
        {'binder': 'd q : Nat; hq : 2*q+1<d', 'class': 'SOURCE', 'source_ids': ['S4.Thmtheorem4.p1.m2', 'S4.Thmtheorem4.p1.m3'], 'meaning': 'Standing source range, including q=0 and positive r=q+1.'},
        {'binder': 'consumer i : Fin d', 'class': 'SOURCE_INDEX', 'source_ids': ['A3.Ex107.m1', 'A3.Ex114.m1'], 'meaning': 'Arbitrary individual summand row under the canonical common marginal law.'},
        {'binder': 'let E,mu,r,R,G,weighted,L,theta,t,feature,Y,squared,upper', 'class': 'DEFINITION', 'meaning': 'Literal canonical or source formulas, with no certificate or estimate encoded as a supplied premise.'},
    ],
    'EXCESS_public_binders': [],
    'proof_components_forbidden_as_extra_binders': [
        'Gaussian fourth or mixed moment, reflection invariance, independence or moment integrability certificate',
        'Quartic domination, measurability, integrability or expectation equality',
        'Rank-one square formula, Kronecker square formula, PSD hypothesis or integral monotonicity conclusion',
        'Cosine frame norm bound, orthogonality or aggregate identity',
        'Positive q or distinct-coordinate assumption excluding q=0',
    ],
    'scope_boundary': 'Canonical marginal fourth matrix moment and actual individual squared summand bound. Original-family transport, aggregation, centered variance, concentration, both main bounds, oracle/TV/cost adapters, public integration and purification remain separate.',
    'shared_floor_audit': 'Same canonical Gaussian law, matrix and feature definitions. Existing compiled declarations retain their canonical node identities. Conceptual sign/trace similarity does not create an uncompiled Lean implication.',
    'actual_statement_formation': formation, 'actual_definition_meaning': meaning,
    'actual_environment': environment, 'preseal_exposure': exposure,
    'formalizer_API_pristine': False,
    'new_target_proof_attempts_before_seal': 0,
    'new_target_proof_API_retrieval_begun': False,
    'minimal_definition_context_sha256': sha(dump(context)),
}
evidence.mkdir(exist_ok=False)
create(evidence / 'minimal-definition-context.json', dump(context))
create(evidence / 'actual-definition-meaning.log', meaning_log)
for name in ('StatementFormation.lean', 'DefinitionMeaning.lean'):
    create(evidence / (name + '.raw.txt'), (workspace / name).read_bytes())
seal_raw = dump(seal)
seal_path = paper / 'radial-fourth-matrix-statement-seal.json'
create(seal_path, seal_raw)
create(workspace / 'statement-seal-v1.json', seal_raw)
for path in (seal_path, workspace / 'statement-seal-v1.json'):
    path.chmod(0o444)
packet = {
    'roles': 'Exact type and canonical definition context only. Independent raw-source freezes precede this handoff.',
    'producer': seal['producer'], 'actual_private_consumer': seal['actual_private_consumer'],
    'source': {'raw': str(source_path), 'sha256': sha(raw_source)},
    'minimal_definition_context': context, 'statement_seal_sha256': sha(seal_raw),
    'minimal_definition_context_sha256': sha(dump(context)),
}
create(workspace / 'selective-type-definition-packet.json', dump(packet))
print(json.dumps({'seal': str(seal_path), 'seal_sha256': sha(seal_raw),
                  'producer_signature_sha256': sha(producer), 'consumer_signature_sha256': sha(consumer),
                  'context_sha256': sha(dump(context)), 'selective_packet_sha256': sha(dump(packet))}))
