from html.parser import HTMLParser
from pathlib import Path
import json, hashlib
BASE=Path(__file__).parent
SOURCE=Path('.astis/huanjian-resume-20261103/2610.20492v1.html')
class N:
 def __init__(self,t,a,l,p=None): self.tag=t; self.a=dict(a); self.l=l; self.end=l; self.p=p; self.c=[]
class P(HTMLParser):
 def __init__(self): super().__init__(convert_charrefs=True); self.root=N('root',[],1); self.stack=[self.root]; self.ids={}
 def handle_starttag(self,t,a):
  n=N(t,a,self.getpos()[0],self.stack[-1]); self.stack[-1].c.append(n)
  if 'id' in n.a:self.ids[n.a['id']]=n
  if t not in {'area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr'}:self.stack.append(n)
 def handle_endtag(self,t):
  for i in range(len(self.stack)-1,0,-1):
   if self.stack[i].tag==t:
    for n in self.stack[i:]:n.end=self.getpos()[0]
    del self.stack[i:];break
 def handle_data(self,s):self.stack[-1].c.append(s)
def txt(n):
 if isinstance(n,str):return n
 if n.tag=='math':return '$'+n.a.get('alttext','')+'$'
 return ''.join(txt(c) for c in n.c)
def blocks(n):
 for c in n.c:
  if isinstance(c,str):continue
  if c.tag in {'p','h2','h3','h4','h5','h6'} or c.tag=='table' and 'ltx_equation' in c.a.get('class',''):
   yield c
  else:yield from blocks(c)
def walk(n):
 yield n
 for c in n.c:
  if not isinstance(c,str):yield from walk(c)
def sha(b):return hashlib.sha256(b).hexdigest()
raw=SOURCE.read_bytes()
assert sha(raw)=='6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
s=raw.decode(); lines=raw.splitlines(keepends=True); p=P(); p.feed(s)
sections=[]; inventory=[]
for key in ['S2','S4','A3.SS3']:
 n=p.ids[key]
 fragment=b''.join(lines[n.l-1:n.end]); (BASE/(key+'.raw.html')).write_bytes(fragment)
 bs=list(blocks(n)); output=[]
 for j,b in enumerate(bs):
  text=' '.join(txt(b).split()); anchor=b.a.get('id',key+'-heading-'+str(j))
  output.append(f'[{anchor} L{b.l}-{b.end}] '+text)
  inventory.append({'section':key,'id':anchor,'tag':b.tag,'class':b.a.get('class',''),'lines':[b.l,b.end],'disposition':('EXCLUDED' if text=='∎' or b.tag in {'h2','h3','h5'} else 'NODE'),'disposition_reason':('proof terminator' if text=='∎' else 'navigation or section heading' if b.tag in {'h2','h3','h5'} else 'source mathematical/proof content'),'text':text,'text_sha256':sha(text.encode()),'ancestor_source_ids':[a.a['id'] for a in ([b.p] if b.p else []) if 'id' in a.a],'source_math_ids':[a.a.get('id') for a in walk(b) if a.tag=='math'],'source_link_uses':[{'href':a.a.get('href'),'text':' '.join(txt(a).split())} for a in walk(b) if a.tag=='a']})
 (BASE/(key+'.read.txt')).write_text('\n\n'.join(output)+'\n')
 sections.append({'id':key,'lines':[n.l,n.end],'raw_slice_sha256':sha(fragment),'read_sha256':sha((BASE/(key+'.read.txt')).read_bytes()),'blocks':len(bs)})
(BASE/'source-inventory.json').write_text(json.dumps({'source':str(SOURCE),'source_sha256':sha(raw),'scope':sections,'items':inventory},ensure_ascii=False,indent=2)+'\n')
print(json.dumps(sections,indent=2))
