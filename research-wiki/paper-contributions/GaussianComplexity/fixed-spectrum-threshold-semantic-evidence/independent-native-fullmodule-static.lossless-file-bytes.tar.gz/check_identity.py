from pathlib import Path
import json,hashlib
r=Path(__file__).resolve().parent;repo=r.parents[2]
def head(root):
 gd=root/".git"
 if gd.is_file():gd=(root/gd.read_text().strip().removeprefix("gitdir: ")).resolve()
 common=(gd/(gd/"commondir").read_text().strip()).resolve() if (gd/"commondir").exists() else gd
 v=(gd/"HEAD").read_text().strip()
 if not v.startswith("ref: "):return v
 ref=v[5:]
 for d in [gd,common]:
  if (d/ref).is_file():return (d/ref).read_text().strip()
 for d in [gd,common]:
  p=d/"packed-refs"
  if p.exists():
   for line in p.read_text().splitlines():
    if line.endswith(" "+ref):return line.split()[0]
 raise RuntimeError("No ref found")
manifest=json.loads((repo/"lake-manifest.json").read_text());rows=[{"name":p["name"],"expected":p["rev"],"actual":head(repo/manifest["packagesDir"]/p["name"])} for p in manifest["packages"]];assert all(x["expected"]==x["actual"] for x in rows)
assert head(repo)=="521b422bad98d4297e86058b4a31e1f15aa4b064"
core=["AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumThreshold.lean","Tests/GaussianComplexityFixedSpectrumThreshold.lean"]
expected=[("b502c1c19e158cf5012d7eb8f374164bac582011c41b9f0bcbc68a32f442b28f",13129),("a14b973691a8185b3d247b940f364b998cd22dc32e775f90fce6eaab78880ea8",11933)]
checks=[]
for p,(h,n) in zip(core,expected):
 b=(repo/p).read_bytes();actual=hashlib.sha256(b).hexdigest();assert actual==h and len(b)==n;checks.append({"path":p,"sha256":actual,"bytes":len(b),"matches_pinned_candidate":True})
report={"method":"Filesystem-only reads of HEAD/ref identity and literal candidate byte hashes; no Git command or repository mutation","candidate":head(repo),"packages":rows,"new_files":checks}
(r/"identity-check.json").write_text(json.dumps(report,indent=2)+"\n");print(json.dumps(report,indent=2))
