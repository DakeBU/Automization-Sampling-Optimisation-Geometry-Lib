python3 .astis/semantic-neutral-20261110/src_d63b90/extract_source.py extract S4.SS1 S4.Thmtheorem5 S4.SS2.SSS0.Px3.p1 S4.SS2.SSS0.Px3.p2 A3.SS3
