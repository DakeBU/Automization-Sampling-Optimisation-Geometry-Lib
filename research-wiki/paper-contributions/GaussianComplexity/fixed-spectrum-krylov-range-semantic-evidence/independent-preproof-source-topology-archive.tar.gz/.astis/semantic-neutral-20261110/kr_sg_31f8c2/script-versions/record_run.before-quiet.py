from pathlib import Path
import subprocess,sys,json,datetime,hashlib
root=Path(__file__).resolve().parent
label=sys.argv[1];cmd=sys.argv[2:]
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
r=subprocess.run(cmd,cwd=root.parents[2],capture_output=True)
out=root/'commands';out.mkdir(exist_ok=True)
(out/(label+'.stdout')).write_bytes(r.stdout)
(out/(label+'.stderr')).write_bytes(r.stderr)
rec={'label':label,'argv':cmd,'cwd':str(root.parents[2]),'started':started,'ended':datetime.datetime.now(datetime.timezone.utc).isoformat(),'returncode':r.returncode,'stdout_bytes':len(r.stdout),'stderr_bytes':len(r.stderr),'stdout_sha256':hashlib.sha256(r.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(r.stderr).hexdigest()}
(out/(label+'.receipt.json')).write_text(json.dumps(rec,indent=2)+'\n')
sys.stdout.buffer.write(r.stdout);sys.stderr.buffer.write(r.stderr)
print(json.dumps(rec),file=sys.stderr)
sys.exit(r.returncode)
