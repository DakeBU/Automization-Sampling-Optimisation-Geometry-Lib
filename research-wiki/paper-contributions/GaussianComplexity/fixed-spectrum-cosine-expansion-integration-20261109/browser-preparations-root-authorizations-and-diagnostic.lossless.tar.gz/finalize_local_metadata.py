"""Project only an actually completed original-verifier release and selected-core acceptance."""
from pathlib import Path
import gzip
import hashlib
import json
import shutil
import subprocess
import sys
import tarfile

R = Path(sys.argv[1])
P = Path('.astis/huanjian-gc-fixed-spectrum-cosine-expansion-integration-20261109')
B = Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-cosine-expansion-integration-20261109')
E = Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-cosine-expansion-semantic-evidence')
C = Path('research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-cosine-expansion.json')
CORE = '7ad39273de26a0ed0315db46be231b5585e26409'
ADV = 'ASTIS-SA-20261109-GaussianComplexityFixedSpectrumCosineExpansion'
VERIFIER = '/root/cosine_fresh_source_5d8c2a'
sha = lambda b: hashlib.sha256(b).hexdigest()
dump = lambda x: (json.dumps(x, ensure_ascii=False, indent=2) + '\n').encode()
git = lambda *args: subprocess.check_output(['git', *args])
assert git('rev-parse', 'HEAD').decode().strip() == CORE
receipt_raw = (R / 'actual-release-receipt.json').read_bytes()
receipt = json.loads(receipt_raw)
assert receipt['status'] == 'OBSERVED_ONE_EXISTING_V_RELEASE' and receipt['normal_API_calls'] == 1
assert receipt['source_verifier'] == VERIFIER and receipt['integration_core'] == CORE
assert receipt['source_checked_commit'] == '37645c774481c4cad19fc29bcaa76799da64db7d'
append = (R / 'actual-release-append.exact.jsonl').read_bytes()
assert append.endswith(b'\n') and len(append.splitlines()) == 1 and sha(append) == receipt['actual_append_sha256']
event = json.loads(append)
assert (event['advance_id'], event['from_state'], event['to_state'], event['worker_id']) == (ADV, 'STABILIZING', 'VERIFIED', VERIFIER)
original = json.loads((E / 'actual-source-V/actual-append-observed.exact.jsonl').read_bytes())['evidence']
assert len(original) == 13 and {k: v for k, v in event['evidence'].items() if k != 'post_integration'} == original
ledger = Path('runs/substantive_advances.jsonl').read_bytes()
assert ledger == git('show', CORE + ':runs/substantive_advances.jsonl') + append
assert Path('runs/substantive_discoveries.jsonl').read_bytes() == git('show', CORE + ':runs/substantive_discoveries.jsonl')
accept = B / 'independent-reader/local-acceptance-and-eligibility-v1/local-integration-acceptance-v1.json'
eligible = B / 'independent-reader/local-acceptance-and-eligibility-v1/existing-V-normalpark-eligibility-v1.json'
pixels = B / 'independent-reader/original48-independent-review-v1/actual48-original-pixel-review.json'
for p, wanted in [(accept, 'a5cc552698a9bb71ae8253f91743cb9ab50cd507006a3a4b1abf399ac7b5edf2'),
                  (eligible, '2933895aa62216adcf786ef92fe224fe631aaed18622c27f35251ecffe34677e'),
                  (pixels, '5f047e4104fcac3c16df3c030dc1f05c37192466414a772287c52ee49c1765fb')]:
    assert sha(p.read_bytes()) == wanted
assert json.loads(accept.read_bytes())['accepted_immutable_core'] == CORE
assert json.loads(pixels.read_bytes())['actual_originals_opened'] == 48
before = C.read_bytes()
assert sha(before) == '76d456791e12fb52c17243fd5b4046642a57e93037867316a566912d73919640'
foreign = {str(p): sha(p.read_bytes()) for p in C.parent.rglob('*.json') if p != C}
assert len(foreign) == 445
out = B / 'actual-existing-V-release'
out.mkdir(exist_ok=False)
for name in ['actual-release-receipt.json', 'actual-release-append.exact.jsonl', 'actual-call-evidence.json', 'API-observation.json', 'preflight-receipt.json']:
    shutil.copyfile(R / name, out / name)
with tarfile.open(out / 'release-preparations-and-actual-runtime.lossless.tar.gz', 'w:gz') as archive:
    archive.add(R, arcname='actual-runtime')
    source = Path('.astis/semantic-neutral-20261109/src_cosine_5d8c2a')
    for path in sorted(source.glob('normal-release-preparation*')):
        if path.is_dir():
            archive.add(path, arcname=path.name)
    for path in sorted(P.glob('root-*-release-*-authorization*.json')):
        archive.add(path, arcname=path.name)
history = B / 'final-metadata-before'
history.mkdir(exist_ok=False)
(history / 'frontier.raw.json.gz').write_bytes(gzip.compress(before, mtime=0))
cell = json.loads(before)
cell['status'] = 'stabilized'
cell['evidence']['root_build'] = 'Actual immutable core ' + CORE + ': canonical ASTIS Lean/build/Tests/fake-closure gate PASS (9662 jobs), plus all8 official gates and122 focused software tests. Exact receipts/logs: ' + str(B / 'actual-core7ad-checks')
cell['evidence']['graph_regeneration'] = 'Actual same-core site build/site check/C7 graph-check PASS; actual own-site Chrome48 originals/20native/14math and independent all48 original pixel acceptance. Scope/scroll/global-neighbour limits: ' + str(accept)
cell['evidence']['local_integration_acceptance'] = {
    'accepted_immutable_core': CORE, 'independent_acceptance': str(accept), 'independent_original48_review': str(pixels),
    'existing_V_release_receipt': str(out / 'actual-release-receipt.json'), 'actual_release_append_sha256': sha(append),
    'original_verifier_and_all13_source_evidence_fields_preserved': True,
    'original_application_and_source_phase_metadata_preserved_as_history': True,
    'remote_main_merge_or_owner_release': False, 'purification_or_ExpositionSeal': False,
    'fresh_build_at_metadata_successor_claimed': False
}
boundary = ('The unchanged sealed scalar C7 identity, absolute summability and fixed-kappa uniformity, with a genuine '
            'private weighted finite-grid interchange, have original independent source/whole-module/fresh-Lean '
            'acceptance at37645 and local integration acceptance at immutable7ad. All8 official gates/122tests '
            'and actual own-site desktop/mobile48 originals/20native records passed, with independent actual '
            'all48 pixel review and disclosed viewport/scroll/global-neighbour limits. The ORIGINAL source '
            'verifier normally released existing V, preserving all13 original evidence fields and adding '
            'only post_integration. This metadata projection is not a fresh build or source verdict. '
            'Poisson is independently validated/stabilized conceptual memory, not a Lean implication. '
            'C8 Gaussian expectation/closed aliases/moments/variance/bias/Krylov, actual adaptive/seed/history/'
            'output law, oracle/precision/TV/deterministic worst-cap/explicit expected-cost adapters, both '
            'full main bounds, remote publication/original-owner release, purification/Exposition Seal and '
            'whole Goal remain open.')
cell['evidence']['execution_boundary'] = boundary
cell['source_detail_audit']['gap'] = 'Selected C7 and private interchange locally accepted; actual Gaussian C8 identification/closed moments and later Lemma4.5/main-route estimates remain separate. Remote delivery and postmerge purification/Exposition Seal remain pending.'
cell['source_detail_audit']['fidelity_boundary'] = boundary
cell['statement_seal']['status'] = 'EXACT_SEALED_C7_SOURCE_AND_LOCAL_INTEGRATION_ACCEPTED_REMOTE_PURIFICATION_PENDING'
cell['graph_contribution']['visual_review'] = str(pixels) + '; actual48 originals, selected-node/viewport scope only; no global190-neighbour or every-code-line pixel claim.'
C.write_bytes(dump(cell))
readme = Path('research-wiki/paper-contributions/GaussianComplexity/README.md')
old_readme = readme.read_bytes()
(history / 'README.raw.md.gz').write_bytes(gzip.compress(old_readme, mtime=0))
prefix = ('## 2026-11-09 UTC: full scalar C7 and genuine finite-grid interchange locally accepted\n\n'
          'Original source V checks mathematical candidate37645; first carrying commit8af00592. Local integration '
          'is accepted at immutable `7ad39273de26a0ed0315db46be231b5585e26409`, with actual9662-job Lean/Tests, '
          'all8 official gates,122 focused regressions and own-site desktop/mobile48 original PNGs/20native '
          'records. The independent reader actually opened all48; root8. Viewport, code/long-formula scrolling '
          'and global-neighbour/ellipsis limits remain explicit. The ORIGINAL source verifier made one normal '
          'existing-V release, preserving all13 original source evidence fields and proof owner. Read '
          '`fixed-spectrum-cosine-expansion-integration-20261109/resume-checkpoint.json`.\n\n'
          'This final metadata successor is not a fresh build, new source verdict, remote publication/old-owner '
          'release, purification/Exposition Seal or whole-Goal completion. Both complete main lower bounds, '
          'C8 exact Gaussian moments/aliases/variance/bias/Krylov and actual adaptive/oracle/TV/precision/'
          'deterministic worst-cap/expected-cost adapters remain open. Root remains sole mathematical worker '
          'and all other queues are preserved. All earlier entries below are phase history.\n\n')
readme.write_bytes(prefix.encode() + old_readme)
checkpoint = {'selected_local_scope': 'Full scalar C7 and actual private finite-grid interchange',
              'accepted_immutable_core': CORE, 'checked_source_candidate': original['verified_commit'],
              'original_source_verifier': VERIFIER, 'normal_state_after_actual_release': 'VERIFIED',
              'actual_release_append_sha256': sha(append), 'all13_original_source_evidence_fields_preserved': True,
              'local_acceptance': str(accept), 'independent_original48_review': str(pixels),
              'normal_release_receipt': str(out / 'actual-release-receipt.json'),
              'metadata_carrier_commit': 'Read actual Git history of this file; not predicted.',
              'fresh_build_at_metadata_successor': False, 'next_math': 'C8 source-first exact alias/moment packet not yet sealed or proved.',
              'same_Goal_continues': True, 'whole_Goal_complete': False, 'remote_and_postmerge_purification': 'pending'}
(B / 'resume-checkpoint.json').write_bytes(dump(checkpoint))
assert {str(p): sha(p.read_bytes()) for p in C.parent.rglob('*.json') if p != C} == foreign
assert Path('runs/substantive_advances.jsonl').read_bytes() == ledger
print(json.dumps({'state': 'ACTUAL_EXISTING_V_AND_LOCAL_ACCEPTANCE_PROJECTED_METADATA_ONLY',
                  'selected_core': CORE, 'own_frontier_before_sha256': sha(before),
                  'own_frontier_after_sha256': sha(C.read_bytes()), 'actual_release_append_sha256': sha(append),
                  'foreign_raw_frontiers_preserved': 445, 'normal_API_calls_in_this_script': 0,
                  'new_source_verdict_fresh_build_or_remote_acceptance': False}))
