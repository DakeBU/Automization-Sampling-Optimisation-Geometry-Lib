Own static checker attempt1 failed before emitting a verdict. Command: python3 .astis/semantic-neutral-20261114/mgf_fresh_source_5b7e/check_browser_v4_measurement.py

Actual tool output (combined capture; no separate OS stdout/stderr claimed):

```text
Traceback (most recent call last):
  File "/Users/zhouhuanjian/ASTIS-GC/.astis/semantic-neutral-20261114/mgf_fresh_source_5b7e/check_browser_v4_measurement.py", line 129, in <module>
    len(preservation['files']) == 115 and all(
        ~~~~~~~~~~~~^^^^^^^^^
KeyError: 'files'
```

The checker used the prior manifest field name files; this v3 preservation manifest uses all_files. Its own check code needs that schema correction. No candidate/script/fixture/runtime flag or mathematical input was modified, and no Chrome/API/build ran. Original checker and partial copied originals remain preserved; attempt2 uses a fresh subdirectory.
