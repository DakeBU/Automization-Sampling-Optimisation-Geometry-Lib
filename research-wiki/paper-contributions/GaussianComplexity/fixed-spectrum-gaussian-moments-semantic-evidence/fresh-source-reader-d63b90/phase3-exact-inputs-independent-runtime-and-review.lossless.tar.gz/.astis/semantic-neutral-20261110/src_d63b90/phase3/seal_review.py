from pathlib import Path
import json,hashlib,datetime
ROOT=Path('/Users/zhouhuanjian/ASTIS-GC');O=ROOT/'.astis/semantic-neutral-20261110/src_d63b90/phase3';COMMIT='25922bb4c3b5a14ec882ebd4d876ed4a309b8843';PACKET='e1adea42232f6dd227d77cf8cf1696fd211b85993d3939f2dbe02032586e2f22';BIND='a9b67ab0b35b750530b517e14f081f53ccb1d70e1bc39d769d15a8737d2bad17'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,value):p=O/name;p.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n');return p
source_scopes=[
('2c6387',0,'Exact producer and focused Test snapshots','Both complete candidate .lean files, imports/scopes/full proofs.'),
('e8d3d7',0,'Exact authored lesson and publication snapshots','Both complete authorized JSON files. Current author assumption classifications and parent claims were treated as claims to check, not earlier reviewer conclusions.'),
('4b9ea2',0,'Authorized v2 packet JSON keys and canonical-with-hash calculation','Packet metadata structure only at this first packet read.'),
('35bfd0',0,'Authorized v2 packet contract, anti-anchoring, module context and hashes','Four false anti-anchoring flags, source-review schema, current full module and candidate assumptions. Canonical hash excludes packet_sha256.'),
('a9c4c5',0,'tools/astis_semantic_roundtrip.py lines1-160','Generic artifact-backed audit/proposal schema code; no canonical target audit/registry opened.'),
('e79458',0,"rg -n 'packet_sha256|source_review|semantic_slots|reviewer_packet_sha256|review_run_sha256|def _.*hash|def _sha' tools/astis_semantic_roundtrip.py",'Generic tool code matches.'),
('68e116',0,'sed -n 1,280p .lake/packages/mathlib/Mathlib/Probability/Distributions/Gaussian/Multivariate.lean','Actual standard/multivariate Gaussian definitions and mean/covariance/variance proofs.'),
('a1f643',0,'git show '+COMMIT+':AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumGridAlias.lean','Complete canonical dependency implementation at checked commit.'),
('f5883c',0,'git show '+COMMIT+':AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumCosineExpansion.lean','Complete canonical dependency implementation at checked commit.'),
('6f3fb8',0,'Lean/Environment.lean targeted getModuleIdxFor/moduleNames search','Pinned Lean API names only.'),
('ddeb86',0,'Pinned Lean Util files matching Axiom/Collect','Pinned tool-source paths only.'),
('43685f',0,'tools/astis_semantic_roundtrip_core.py targeted source_review/slots/schema search','Generic validator code names/lines only.'),
('0df1d5',0,'Gaussian/Basic.lean and Fernique.lean targeted memLp_dual/integrable_fun_id search','Pinned Mathlib declarations only.'),
('a5e641',0,'Gaussian/Basic.lean lines102-145 and Fernique.lean lines186-220','Actual Gaussian linear-functional Lp and vector-integrability implementations.'),
('32b706',0,'Variance.lean variance_eq_integral; L2Space/Bochner Basic/ContinuousLinearMap selected API searches','Pinned moment/integral API signatures and paths.'),
('41d84f',0,'Lean Environment lines1180-1205; Lean CollectAxioms whole; semantic_roundtrip_core lines552-650','Actual module ownership/recursive axiom inspector and canonical proposal validation code.'),
('adb034',2,'Lean Declaration/Expr value/getUsedConstants search; attempted Lean/Kernel.lean search','Declaration API matches printed; Lean/Kernel.lean path absent. No candidate failure.'),
('fba350',0,'Variance lines148-164; L2Space lines25-48; Bochner Basic lines242-251,281-293','Variance integral rewrite, square integrability, finite integral sum and constant multiplication implementations.'),
('3641a9',0,'PiL2 real_norm_sq_eq and Matrix PosDef/NonsingularInverse targeted searches','Pinned norm/positive-definite/inverse API locations.'),
('a7570f',0,'Lean Meta/Check and Environment kernel-check search; Declaration lines478-494','Kernel-check API and opaque/theorem value access code.'),
('dd15af',0,'PiL2 lines150-166; Matrix PosDef lines150-177 and diagonal/inverse searches','Norm identity and positive-definite predicate/lemma locations.'),
('3478b5',0,'Lean Meta/Check lines365-395; Matrix PosDef lines185-205,507-521; NonsingularInverse lines451-463','Actual Kernel.check bridge and diagonal/inverse positive-definite/left-inverse proofs.'),
('47c8cd',0,'tools/astis_publication.py targeted binding/review-context/extraction search','Generic publication binding code only.'),
('50865f',0,'L1Space/Integrable finite-sum search; selected InfiniteSum files API search','Pinned Mathlib finite sum/infinite sum API matches.'),
('93b2d8',0,'astis_publication lines100-165; semantic_roundtrip_core lines34-65,315-366','Exact binding/review-context construction and proposal enum/shape code.'),
('5a517e',0,'L1Space/Integrable lines430-454; InfiniteSum comparison/finite-tsum search','Actual finite integrability proof and summability comparison location.'),
('d71ea3',0,'git show exact two dependency sources, lean-toolchain and lake-manifest; Mathlib git rev-parse; manual binding reconstruction','Only declared dependency/source/toolchain inputs; publication context reconstructed from exact authorized snapshots without invoking global API.'),
('57ea9b',0,'Mathlib Matrix folders targeted mulVec_diagonal search','Pinned matrix-coordinate API locations.'),
('879f05',0,'Pinned Lean ForEachExpr/Expr targeted fold API search','Pinned reviewer-tool API locations.'),
('0d3e24',0,'Lean Expr lines2050-2085; Matrix/Mul lines746-757','Actual expression traversal and diagonal matrix-vector multiplication API.'),
('9b33dc',1,'astis_publication lines1-100; selected InfiniteSum files tsum_finsetSum search','Generic publication code (not invoked); following narrow API search had no matches, causing aggregate exit1.'),
('2b2ca2',0,'website/scripts/declaration_lessons.py targeted progressive/Lean disclosure search','Static reader schema/renderer hook code only; no site/state scan invoked.'),
('ebb441',0,'declaration_lessons lines190-218,244-274,1-32; inline_lean targeted disclosure/split search','Static statement/proof adjacency and schema code only.'),
('eed7ee',0,'Selected InfiniteSum tsum_finsetSum search; ENNReal lines524-539','Pinned scalar convergence comparison implementation.'),
('b9cf32',0,'inline_lean.py lines1-111; selected InfiniteSum search','Exact static declaration split/disclosure helper; no renderer invoked on global inventory.'),
('eee315',0,'Own runtime/inspected-declarations.json public/private target summaries','Actual fresh compiled types, parent references, named-binder uses and recursive axioms.'),
('0ad57f',0,'Own inspected-declarations.json remaining auxiliary types/summary','All seven elaboration-only simp auxiliary types inspected; no outside reviewer material.'),
('e14847',0,'Own exact candidate snapshots, source/reconstruction hashes and static split helper','Closure scan and static folding checks; helper AST extracted without importing renderer or scanning project.'),
('e8ad6f',1,'Own runtime/independent-inspection.json parse','Reviewer-data filename collision found: wrapper metadata had overwritten the first data result. Retained successful kernel log; reran inspector to a distinct data path.'),
('a3bf55',0,'Own overwritten inspection filename root type','Confirmed own metadata collision only; no new external input.')]
records=[{'chunk_id':c,'exit_code':e,'read_command_or_exact_bounded_scope':s,'exposure':x} for c,e,s,x in source_scopes]
api_paths=[
'.lake/packages/mathlib/Mathlib/Probability/Distributions/Gaussian/Multivariate.lean',
'.lake/packages/mathlib/Mathlib/Probability/Distributions/Gaussian/Basic.lean',
'.lake/packages/mathlib/Mathlib/Probability/Distributions/Gaussian/Fernique.lean',
'.lake/packages/mathlib/Mathlib/Probability/Moments/Variance.lean',
'.lake/packages/mathlib/Mathlib/MeasureTheory/Function/L2Space.lean',
'.lake/packages/mathlib/Mathlib/MeasureTheory/Function/L1Space/Integrable.lean',
'.lake/packages/mathlib/Mathlib/MeasureTheory/Integral/Bochner/Basic.lean',
'.lake/packages/mathlib/Mathlib/MeasureTheory/Integral/Bochner/ContinuousLinearMap.lean',
'.lake/packages/mathlib/Mathlib/Analysis/InnerProductSpace/PiL2.lean',
'.lake/packages/mathlib/Mathlib/LinearAlgebra/Matrix/PosDef.lean',
'.lake/packages/mathlib/Mathlib/LinearAlgebra/Matrix/NonsingularInverse.lean',
'.lake/packages/mathlib/Mathlib/Data/Matrix/Mul.lean',
'.lake/packages/mathlib/Mathlib/Topology/Algebra/InfiniteSum/ENNReal.lean',
 'tools/astis_semantic_roundtrip.py','tools/astis_semantic_roundtrip_core.py','tools/astis_publication.py','website/scripts/declaration_lessons.py','website/scripts/inline_lean.py']
leanroot=Path('/Users/zhouhuanjian/.elan/toolchains/leanprover--lean4---v4.33.0/src/lean/Lean')
external=[{'path':str(leanroot/x),'sha256':sha(leanroot/x),'scope':'Only API ranges/searches recorded in read ledger; not a fresh compiler/library build.'} for x in ['Environment.lean','Declaration.lean','Expr.lean','Meta/Check.lean','Util/CollectAxioms.lean']]
write('pinned-api-source-hashes.json',{'sources':[{'path':p,'sha256':sha(ROOT/p)} for p in api_paths],'pinned_lean_sources':external})
runtime=[]
for p in sorted((O/'runtime').glob('*.json')):
    v=json.loads(p.read_text())
    if isinstance(v,dict) and all(k in v for k in ['args','exit_code','elapsed_seconds','log_sha256']):
        assert sha(ROOT/v['log_path'])==v['log_sha256'];runtime.append(v)
write('actual-runtime-command-index.json',runtime)
ledger={'phase':3,'reviewer':'/root/source_reader_d63b90','checked_commit':COMMIT,'canonical_reviewer_packet_sha256':PACKET,'publication_binding_sha256':BIND,'actual_reads':records,'runtime_command_records':'actual-runtime-command-index.json','initial_candidate_capture':'initial-input-manifest.json','prior_freezes_preserved':True,'whole_v2_context_visible_only_after_phase2_freeze':True,'prior_canonical_audit_or_other_reviews_read':False,'root_frontier_sourcegraph_ledger_maps_capsules_or_runtime_conclusions_read':False,'canonical_API_or_source_V_called':False,'independently_verified_set':False,'global_build_wholeTests_site_server_browser_OS_network_used':False,'writes':'All intentional writes under this NEW phase3 directory; private overlay only. Lake env was used only to read actual LEAN_PATH. Reused cache files were read/copied, not rebuilt or mutated.','runtime_failure_disposition':'Initial Test import-resolution failure corrected by copying exact reused ASTIS cache files into overlay. Reviewer-only notation/API/data-file mistakes retained; final candidate/probe successes selected explicitly, without hiding failures.','private_generated_auxiliary_scope':'All 11 owned declarations independently kernel/type/axiom checked. Seven generated simp artifacts not reachable from final theorem closure are recorded with no separate theorem credit.'}
write('exposure-toolread-ledger.json',ledger)
# Recheck only immutable input hashes needed to seal this review, not broader tests.
initial=json.loads((O/'initial-input-manifest.json').read_text())
for x in initial['candidate_files']:
    assert sha(ROOT/x['path'])==x['sha256'];assert sha(O/'candidate'/x['path'])==x['sha256']
source=ROOT/'.astis/huanjian-resume-20261103/2610.20492v1.html';assert sha(source)=='6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
for path,digest in [('phase1/phase1-freeze.json','763446abce7e48ec32330ff4a7ee1538187a8fe9d9a80e6f29fa82b7276b054d'),('phase2/FREEZE.json','dec575f0e6af490e52fdd8fc691336d7df39ce25cf7999cf8cffd434a6222baa')]:assert sha(O.parent/path)==digest
for x in json.loads((O/'runtime/reused-cache-manifest.json').read_text()):assert sha(Path(x['cache_path']))==x['cache_sha256']
summary=json.loads((O/'runtime/inspection-summary.json').read_text());assert len(summary['owned_declarations'])==11;assert all(x['kernel_checked'] for x in summary['owned_declarations']);assert all(set(x['recursive_axioms'])<={'propext','Classical.choice','Quot.sound'} for x in summary['owned_declarations']);assert all(x['used_in_body'] for x in summary['material_named_binders'])
needed=['producer','focused-test-overlay-complete','independent-inspection-final','independent-source-meaning-final'];assert all(next(x for x in runtime if x['label']==label)['exit_code']==0 for label in needed)
evidence=['full-review.md','initial-input-manifest.json','dependency-and-publication-binding-check.json','actual-runtime-command-index.json','pinned-api-source-hashes.json','exposure-toolread-ledger.json','static-reader-and-closure-check.json','static-exact-fold-statement.txt','static-exact-fold-proof.txt','runtime/inspected-declarations.json','runtime/inspection-summary.json','runtime/reused-cache-manifest.json','runtime/overlay-reused-copies.json']
run={'reviewer':'/root/source_reader_d63b90','phase':3,'completed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checked_commit':COMMIT,'reviewer_packet_raw_sha256':initial['reviewer_packet_raw_sha256'],'reviewer_packet_sha256':PACKET,'publication_binding_sha256':BIND,'phase1_freeze_sha256':'763446abce7e48ec32330ff4a7ee1538187a8fe9d9a80e6f29fa82b7276b054d','phase2_freeze_sha256':'dec575f0e6af490e52fdd8fc691336d7df39ce25cf7999cf8cffd434a6222baa','decision':'ACCEPT','semantic_verdict':'equivalent-after-elaboration','blocking_deltas':[],'runtime_selected_successes':needed,'owned_declarations_checked':11,'actual_ASTIS_consumer_parents':summary['actual_direct_ASTIS_consumer_parents'],'source_V_or_API_transition':False,'independently_verified_set':False,'evidence_artifacts':[{'path':str((O/p).relative_to(ROOT)),'sha256':sha(O/p)} for p in evidence]}
runpath=write('review-run.json',run);runhash=sha(runpath)
slots={
'objects':{'original':'Fixed midpoint spectrum Lambda, U~N(0,Lambda inverse), M=E||U||^2 and mu_n=E[U^T D_n U].','reconstructed':'Canonical literal multivariateGaussian 0 Lambda inverse on real Euclidean space; actual squared norm and coordinate Q=sum_i cos(n theta_i)x_i^2.','relation':'equivalent','evidence':'Raw S4.E11, S4.Thmtheorem5.p1.1 and A3.Ex140; whole-module definitions and elaborated type match. IndependentSourceMeaning proves the diagonal quadratic-coordinate identity.'},
'domains':{'original':'Integer d>=2; real kappa>=2; i=1,...,d; integer 1<=n<d.','reconstructed':'d:Nat>=2, kappa:Real>=2, n:Nat with 1<=n<d; Fin d zero-based coordinates and angle (i+1/2)pi/d.','relation':'equivalent','evidence':'Exact index bijection to source angle (i-1/2)pi/d. No added separation/asymptotic/query range. Fresh elaborated type has only these numerical premises.'},
'quantifiers':{'original':'Every admissible d,kappa,n and any U of the specified Gaussian law; all spectrum/statistic definitions fixed by them.','reconstructed':'Universally quantified d,hd,kappa,hkappa,n,hn,hnd followed by five fixed let definitions; law-dependent expectations are canonical-law integrals.','relation':'equivalent','evidence':'Fresh compiled type and complete module scopes inspected. No hidden scoped parameters, arbitrary-law callback or witness binder.'},
'assumptions':{'original':'Hard-family grid definitions and d>=2,kappa>=2,1<=n<d; Gaussian law.','reconstructed':'Same ranges and literal Gaussian definition. Positivity, actual inverse, Gaussian L2/centering/coordinate moments and integrability are proved internally.','relation':'same','evidence':'Source Ex140 context; fresh producer proof constructs all domain and moment facts. hd/hn/hnd intentionally retain source bounds even though the analytic proof uses fewer bounds.'},
'conclusion':{'original':'A3.Ex140: M=sum_i lambda_i inverse and mu_n=sum_i cos(n theta_i)/lambda_i, as ordinary finite Gaussian expectations.','reconstructed':'Both corresponding exact real Bochner integral identities plus actual integrability of both integrands.','relation':'explicit-elaboration','evidence':'Finite Gaussian coordinate L2 implies square integrability; finite sums/constant multiples produce both integrabilities before finite integral linearity. These are outputs, not new public premises. Closed C8, variances and bias are not claimed.'},
'scopes':{'original':'Real Euclidean centered Gaussian covariance Lambda inverse; ordinary finite expectations and diagonal quadratic form.','reconstructed':'Same measure/carrier/covariance and signed quadratic function, with actual Bochner integrability; standard totalized inverses/Gaussian square root restricted to an internally proved positive-definite nonsingular input.','relation':'equivalent','evidence':'Pinned Mathlib constructor/mean/covariance proofs read; inverse/SPD conditions discharged. Whole-module/11-declaration kernel/type/axiom checks and independent coordinate-meaning theorem pass.'},
'constant_dependencies':{'original':'Exact half-grid, pi, fixed eigenvalue coefficients; dependency only on d,kappa,n.','reconstructed':'Same coefficients and dependencies; no unspecified constants, factor two, asymptotic estimate or extra parameter. Private series uses d/sqrt(kappa) and exact source rho.','relation':'same','evidence':'Source Eq11/Ex140/Ex144 and compiled definitions inspected. Private signed-alias normalization and product-to-sum cancellation checked; actual 2*r^(j+1) bound is produced and used.'}}
deltas=[
{'slot':'domains','severity':'informational','description':'One-based coordinates and positive integer modes are represented by Fin d and bounded natural modes.','evidence':'Exact coordinate/mode bijections; the angle shift is +1/2 on Fin d.'},
{'slot':'objects','severity':'informational','description':'Fixed-law integration and a literal coordinate sum express the source random-vector expectations and diagonal quadratic form.','evidence':'Identical covariance Lambda inverse and law-dependent moments; separate Lean matrix-coordinate check compiles.'},
{'slot':'conclusion','severity':'informational','description':'The source-implicit integrability of both Gaussian integrands is explicit as a formal conclusion.','evidence':'Produced from actual coordinate Gaussian L2 and finite integrable sums. No integrability/moment certificate is a hypothesis and no source repair is proposed.'},
{'slot':'scopes','severity':'informational','description':'Private consumer substitutes the normalized all-integer alias coefficient and reindexes positive series modes as j+1.','evidence':'Source Ex139/Ex144 equality, integer casts before subtraction, and d/sqrt(kappa) normalization are preserved. Fresh compiled proof directly uses the Gaussian producer, C7 and GridAlias; ha_bound/hFmajor/hFnorm/hF are materially used.'}]
review={'state':'accepted','reviewer':'/root/source_reader_d63b90','independent_from_formalizer':True,'independent_from_decoder':True,'reviewer_packet_sha256':PACKET,'publication_binding_sha256':BIND,'checked_commit':COMMIT,'review_run_sha256':runhash,'run_artifact':str(runpath.relative_to(ROOT)),'evidence':'Independent three-phase review at commit '+COMMIT+'. Source-only and selective phase freezes preceded full context. v2 canonical packet '+PACKET+' and publication binding '+BIND+' verified. Fresh isolated producer/Test compile; all 11 owned declarations independently kernel/type/recursive-axiom checked; actual three ASTIS consumer parents and used alias-majorant binders inspected; independent matrix-coordinate test and static exact closed-Lean disclosure hooks checked. ACCEPT only Ex140 producer plus private Gaussian alias-series precursor, whole-module/static reader and focused fresh runtime. No closed C8/full Lemma4.5/variance/bias, repository/global/site/UI/graph/deployment/source-V claim; no independently_verified setting. Full details in '+str((O/'full-review.md').relative_to(ROOT))+'.'}
proposal={'semantic_slots':slots,'deltas':deltas,'verdict':'equivalent-after-elaboration','source_review':review}
assert set(proposal)=={'semantic_slots','deltas','verdict','source_review'};assert len(slots)==7;assert all(x['relation'] in {'same','equivalent','explicit-elaboration'} for x in slots.values());assert all(x['severity']=='informational' for x in deltas)
proposalpath=write('canonical-application-proposal.json',proposal)
files=[{'path':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(O.rglob('*')) if p.is_file() and p.name!='FREEZE.json']
freeze={'phase':3,'reviewer':'/root/source_reader_d63b90','frozen_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checked_commit':COMMIT,'canonical_reviewer_packet_sha256':PACKET,'publication_binding_sha256':BIND,'review_run_sha256':runhash,'canonical_application_proposal_sha256':sha(proposalpath),'decision':'ACCEPT','semantic_verdict':'equivalent-after-elaboration','source_V_or_API_transition':False,'independently_verified_set':False,'files':files}
p=write('FREEZE.json',freeze)
print(json.dumps({'freeze_path':str(p.relative_to(ROOT)),'freeze_sha256':sha(p),'frozen_artifacts':len(files),'review_run_sha256':runhash,'proposal_path':str(proposalpath.relative_to(ROOT)),'proposal_sha256':sha(proposalpath),'report_sha256':sha(O/'full-review.md'),'runtime_commands':len(runtime)},indent=2))
