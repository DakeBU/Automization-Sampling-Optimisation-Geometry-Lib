from pathlib import Path
import json,hashlib,stat,sys
phase=Path(__file__).resolve().parent.parent
base=phase.parent
sha=lambda b:hashlib.sha256(b).hexdigest()
def newjson(p,x):
    with p.open("x",encoding="utf-8") as f:json.dump(x,f,ensure_ascii=False,indent=2);f.write("\n")
inputs=[
("inputs/selective-fresh-source-phase2-input.json",9323,"92a4b1401ec63ee22409929bd3c6528b1b25bbc822066a3944a8c9f0bbfca173"),
("inputs/minimal-extra-law-definitions-for-fresh-source.json",8679,"9882d7a29b9d635a000cdf754bc48e840c4f40fa552521b1925afd2b0b41c908")]
for name,n,h in inputs:
    b=(phase/name).read_bytes()
    assert len(b)==n and sha(b)==h,name
p=json.loads((phase/inputs[0][0]).read_bytes())
assert sha(p["source"]["original_text"].encode())==p["source"]["text_sha256"]
assert sha(p["lean"]["statement"].encode())==p["lean"]["statement_sha256"]
assert sha(p["blind_reconstruction"]["text"].encode())==p["blind_reconstruction"]["text_sha256"]
assert sha(p["actual_private_consumer_literal_signature"].encode())=="bb6980ae60846fd877143ff5346823cf5e1a7d559fe4580bb278f0c0720607a6"
for d in p["minimal_meaning_carrying_definitions"]:
    if "literal_sha256" in d:assert sha(d["literal_definition"].encode())==d["literal_sha256"]
extra=json.loads((phase/inputs[1][0]).read_bytes())
for d in extra["definitions"]:assert sha(d["literal_definition_or_context"].encode())==d["literal_sha256"]
visible=json.loads((phase/"logs/list-agents-complete-visible-return-transcription.txt").read_text())
event=json.loads((phase/"logs/unplanned-collaboration-status-exposure-v1.json").read_text())
assert visible==event["returned_result"]
assert len(visible["agents"])==4
status=json.loads((phase/"analysis/phase2-closeout-status-v3.json").read_text())
assert status["status"]=="CLOSED_PROVISIONAL_COMPARISON_NOT_FINAL_GATE"
assert status["final_fresh_source_gate"] is False and status["sourceV_executed"] is False
assert status["sourceV_authority"] is False
p1=base/"phase1-source-only"
mbytes=(p1/"MANIFEST.json").read_bytes()
assert sha(mbytes)=="58d9f9f1814eed78bfe5c4c3e3ff0398fc2e3091fba2af905bfb174d0d13ac04"
old=json.loads(mbytes)
for rec in old["files"]:
    f=p1/rec["path"]
    assert f.stat().st_size==rec["bytes"] and sha(f.read_bytes())==rec["sha256"],rec["path"]
    assert stat.S_IMODE(f.stat().st_mode)==0o444,rec["path"]
assert stat.S_IMODE((p1/"MANIFEST.json").stat().st_mode)==0o444
old_dirs=[p1]+[x for x in p1.rglob("*") if x.is_dir()]
assert all(stat.S_IMODE(x.stat().st_mode)==0o555 for x in old_dirs)
rp=base/"phase1-source-only.receipt.json"
rbytes=rp.read_bytes()
assert sha(rbytes)=="e2d9d1c6e19c4da8247a1654c46e0a2972e1b60d0808941483eb7b6526c0b3fa"
assert stat.S_IMODE(rp.stat().st_mode)==0o444
r=json.loads(rbytes)
outer={"status":r["status"],"receipt_path":str(rp),"receipt_sha256":sha(rbytes)}
outer.update(r["frozen_validation"])
old_stdout=(json.dumps(outer,ensure_ascii=False,indent=2)+"\n").encode()
assert (base/"phase1-finalizer-v1.stdout").read_bytes()==old_stdout
assert (base/"phase1-finalizer-v1.stderr").read_bytes()==r["child_stderr"].encode()
assert all(stat.S_IMODE((base/name).stat().st_mode)==0o444 for name in ("phase1-finalizer-v1.stdout","phase1-finalizer-v1.stderr"))
preservation={"phase1_manifest_sha256":sha(mbytes),"phase1_receipt_sha256":sha(rbytes),"phase1_payload_files_including_manifest":len(old["files"])+1,"phase1_directory_count":len(old_dirs),"phase1_payload_bytes_hashes_and_modes_unchanged":True,"phase1_modes":"files0444/dirs0555","phase1_sibling_streams":"Match exact reconstruction from original fixed-hash receipt, remain0444","phase1_stdout_sha256":sha(old_stdout),"phase1_stderr_sha256":sha(r["child_stderr"].encode())}
newjson(phase/"logs/pre-freeze-phase1-and-input-integrity-v1.json",{"inputs":[{"path":x[0],"bytes":x[1],"sha256":x[2]} for x in inputs],"phase1":preservation,"complete_visible_list_return_matches_structure":True,"validation_kind":"Own evidence byte/mode integrity only; no new mathematical/native/sourceV examination"})
newjson(phase/"logs/freeze-child-command-v1.json",{"python_orig_argv":sys.orig_argv,"cwd":str(Path.cwd()),"stdout_stderr":"Captured completely by outer wrapper in sibling receipt and outer stream files","action":"Freeze actual phase2 as non-final-gate historical evidence; no old artifact overwritten","scope":"Only own phase2 snapshots/logs/status and old phase1 evidence-integrity reads after root cutoff"})
assert not (phase/"MANIFEST.json").exists()
assert not any(x.is_symlink() for x in phase.rglob("*"))
files=sorted(x for x in phase.rglob("*") if x.is_file())
entries=[{"path":str(x.relative_to(phase)),"bytes":x.stat().st_size,"sha256":sha(x.read_bytes()),"frozen_mode":"0444"} for x in files]
report_sha=sha((phase/"analysis/selective-seven-slots-final-v2.md").read_bytes())
initial_sha=sha((phase/"analysis/selective-seven-slots-initial-v1.md").read_bytes())
closeout_sha=sha((phase/"analysis/phase2-closeout-status-v3.json").read_bytes())
manifest={"schema":"cg-phase2-selective-type-manifest-v1","phase":"phase2-selective-type-decoder","status":status["status"],"final_fresh_source_gate":False,"sourceV_authority":False,"sourceV_executed":False,"source_sha256":"6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915","initial_seven_slot_sha256":initial_sha,"final_provisional_comparison_sha256":report_sha,"closeout_status_sha256":closeout_sha,"phase1_preservation":preservation,"files":entries,"manifest_self_excluded":True,"receipt":"../phase2-selective-type-decoder.receipt.json","hash_cycle_policy":"Manifest hashes every other phase payload; sibling receipt hashes manifest and captures finalizer argv/stdout/stderr; receipt never hashes itself; outer streams are sibling terminal artifacts.","exposure_limit":"Actual late collaborator/source-map/process metadata and extra-context background-proof exposures retained. Not pristine, not final gate, no mathematical refutation/repair inferred.","final_tool_events":[{"tool":"apply_patch","action":"Add own freeze script only; all predecessor bytes retained."},{"tool":"exec_command","action":"Outer wrapper runs this script, writes read-only sibling receipt and stdout/stderr, then pauses."}]}
newjson(phase/"MANIFEST.json",manifest)
mh=sha((phase/"MANIFEST.json").read_bytes())
for x in files+[phase/"MANIFEST.json"]:x.chmod(0o444)
dirs=sorted([x for x in phase.rglob("*") if x.is_dir()],key=lambda x:len(x.parts),reverse=True)
for x in dirs+[phase]:x.chmod(0o555)
for rec in entries:
    x=phase/rec["path"]
    assert sha(x.read_bytes())==rec["sha256"] and stat.S_IMODE(x.stat().st_mode)==0o444,rec["path"]
assert stat.S_IMODE((phase/"MANIFEST.json").stat().st_mode)==0o444
assert sha((phase/"MANIFEST.json").read_bytes())==mh
assert all(stat.S_IMODE(x.stat().st_mode)==0o555 for x in dirs+[phase])
print(json.dumps({"status":"FROZEN_NOT_FINAL_FRESH_SOURCE_GATE","phase":str(phase),"manifest_sha256":mh,"initial_seven_slot_sha256":initial_sha,"final_provisional_comparison_sha256":report_sha,"closeout_status_sha256":closeout_sha,"payload_files_including_manifest":len(entries)+1,"directories_including_phase":len(dirs)+1,"all_payload_modes":"0444","all_phase_directory_modes":"0555","phase1_all_original_bytes_hashes_modes_preserved":True,"actual_inputs_verified":2,"late_collaboration_metadata_exposure":True,"extra_context_background_proof_bodies_exposure":True,"candidate_C5_implementation_read":False,"final_sourceV_authority":False,"sourceV_executed":False,"native_or_compile_executed":False,"pause":True},ensure_ascii=False,indent=2))
