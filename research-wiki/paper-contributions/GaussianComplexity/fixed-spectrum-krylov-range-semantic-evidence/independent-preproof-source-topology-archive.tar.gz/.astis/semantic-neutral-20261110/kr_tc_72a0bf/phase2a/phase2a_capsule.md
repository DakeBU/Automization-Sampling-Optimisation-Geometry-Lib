# Phase 2a bounded independent capsule

Typed-mathematical-scope judgment: ACCEPT the selected P/T signatures and literal object semantics as a bounded C.2 algebraic component, with no EXCESS binder. This does not approve any proof, actual compiled dependency, source graph, publication or completion status.

P signature SHA256 `4d5056d57aa0536b95af7aa9f7c3b6860ab7c9652b0bb306b6bad42434235ab6`; T `082eda7b36ecff3e87a62358e4f234b6d6c129b491405de3761fa83f79412969`. Both match the permitted fields extracted from seal raw SHA256 `f47e23a601d1a8e0ff4760224676313e0f1999877a97156841a65c01847e5d82`. Input reports literal Prop formation only, targets not compiled.

* d/q/κ and arbitrary real array x are typing/data; κ>=2 is hard-family STANDING; 2q+1<d is the enclosing source lemma's explicit SOURCE condition. T's v∈K is its source domain restriction. All proof ingredients remain internal. q=0, zero starts/vectors and dependent generating families are included.
* Zero-based Fin indices give the source half-grid and exactly q+1 starts / modes 0 through q. B uses start-then-mode tensor coordinates, scale 1/sqrt(d), constant mode 1, higher mode sqrt(2). K includes Λ⁰ and is algebraic real span; image is actual existential Set.range.
* T explicitly uses EuclideanSpace L2 norm/real inner product via WithLp.toLp 2, avoiding raw-function supremum norm. All ten minimal canonical literal/header fragments and raw character/byte/LF locations check exactly; no proof body was exposed.
* P isolates range(B)=K. Arbitrary deterministic starts are a justified strengthening of the Gaussian context. T's signed weighted identity is the underlying finite-matrix identity implying the source's displayed absolute equality; it is not the full displayed bound.
* P materially supplies the existential representation in T, followed by exact energy/weighted pullbacks for the same c. This is a legitimate mathematical prospective consumer; statement text cannot certify that its absent proof actually calls P. No concentration, high-probability theorem or full C.5 credit follows.

The detailed judgment is in `phase2a_binder_definition_audit.md`. Original-source locators were rechecked and interpreted mathematically, rather than accepted by counting matching bytes. Phase 1 manifest/hashes/modes remain unchanged. No SG or root narrative/verdict/plan, target Lean/API/proof, frontier/ledger/Goal/STAB/publication or ATLAS access occurred. No read/validation failure or output truncation occurred in Phase 2a. Freeze then pause before SG comparison or separate process/control review.
