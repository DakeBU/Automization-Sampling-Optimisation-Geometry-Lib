# Phase 1: source-only reconstruction, 31f8c2

This is an independently reconstructed source graph and coverage proposal, not a Lean proof, target-signature review, source-fidelity verdict, or independent approval of its own coverage. No target signature or project-owned meaning-carrying definition has been supplied or read. A separate topology reviewer remains necessary under the protocol. No claim of zero pretraining or absolute pristine reasoning is made: the author has ordinary pretrained mathematical knowledge. The precise observed exposures and truncations are retained in `exposure-and-command-history.json`.

The only mathematical input read was the fixed original HTML, 951991 bytes, SHA256 `6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915`. The mathematical scope is Sections 4.1 and 4.2 and the whole of Appendix C.2, with the focal conclusions being the range component of Fact C.5 and the exact algebraic representations in C.2 paragraph 19. Reading all C.2 is necessary to distinguish those deterministic identities from the probabilistic estimates that consume them. Adjacent original-paper lines were incidentally exposed by an overbroad search; they are not used to replace reading this scope.

## Objects, conventions, and quantifiers

The hard family in 4.1 assumes an integer dimension d≥2 and κ≥2. Its coordinates are indexed by i=1,…,d. Put θᵢ=(i−1/2)π/d, λᵢ=(κ+1)/2+(κ−1)cos θᵢ/2, and Λ=diag(λ₁,…,λ_d). The paper draws an orthogonal O with Haar law independently of the algorithm's private randomness, sets A=OΛOᵀ, uses potential xᵀAx/2, and targets N(0,A⁻¹). The fixed spectrum is known; the hidden basis is O. Haar randomness, potential normalization, and the target distribution are context for Lemma 4.4, not premises needed for the deterministic range or coefficient identities.

Section 4.2 defines the block Krylov subspace

K_q(g₁,…,g_{q+1})=span{Λʲg_a : 1≤a≤q+1, 0≤j≤q}.

Here q is an integer ≥0. Lemma 4.3 assumes 2q+1<d and gives independent standard Gaussian starting vectors whose block space contains OᵀX almost surely; their polynomial coefficients may depend on the extended experiment. This representation is an upstream application-context input, not a necessary parent of the deterministic identity range(B)=K_q for already supplied vectors. The extra starting vector accounts for the algorithm's unconstrained output. No independence from O or from adaptive coefficients is asserted by the text in this slice; independence among the g_a is what is expressly stated. Uniformity over all coefficient vectors prevents an invalid fixed-coefficient argument.

For Lemma 4.4, n=2q+1 and D_n=diag(cos(nθᵢ)). There exists one absolute C>0, independent of d,q,κ and the vectors, such that τ=C[(q+1)√(log d/d)+(q+1)(q+1+log d)log d/d] has the stated probabilistic consequence. The quantifier order is C first, then every admissible q,d and Gaussian experiment; if τ≤1/2, one event has probability at least .99 and on that event every u∈K_q satisfies |uᵀD_nu|≤2τ‖u‖². It is not a family of separately likely events indexed by u.

Appendix C.2 inherits these standing assumptions even where Fact C.5 does not repeat them. It sets r=q+1. Feature coordinates are j=0,…,q, starting-vector coordinates are a=1,…,r, and γᵢ=((g₁)ᵢ,…,(g_r)ᵢ)ᵀ∈Rʳ. The tᵢ∈Rʳ have coordinate 0 equal to 1 and coordinate j≥1 equal to √2 cos(jθᵢ). The γᵢ are independent N(0,I_r) because the original standard Gaussian vectors have independent coordinates and are independent of each other.

B is d by r² with row i equal to d^(−1/2)(γᵢ⊗tᵢ)ᵀ. In a consistent pair indexing (a,j),

B_{i,(a,j)}=d^(−1/2)(g_a)ᵢ η_j cos(jθᵢ), where η₀=1 and η_j=√2 for j≥1.

The first Kronecker factor is γ, the second is t. A different flattening is harmless only when applied consistently to B, c, transposes, and Kronecker identities. A coefficient vector c has r² coordinates indexed by the same pairs. The word range means the image of the linear map c↦Bc, equivalently the span of its columns. The norm is the ordinary Euclidean norm on the relevant finite dimensional real space. Consequently the Gram quadratic is a sum of coordinate products with no extra d factor: the d^(−1/2) scaling is already inside B.

The q=0 endpoint has r=1 and tᵢ=(1). Empty positive-frequency ranges cause no extra assumption. The case u=0 or c=0 is included in all exact identities and estimates. No nonzero-vector or unique-coefficient condition occurs.

## The range component of Fact C.5

The source route is a single triangular polynomial change of coordinates, followed by invariance of span under nonzero column scaling. Let α=(κ+1)/2 and β=(κ−1)/2. Since κ≥2, β≠0. The Chebyshev identity cos(jθ)=T_j(cos θ) yields

cos(jθᵢ)=P_j(λᵢ), where P_j(x)=T_j((x−α)/β).

T₀=1 and, for j≥1, T_j has degree j and leading coefficient 2^(j−1); hence P₀ has leading coefficient 1 and P_j has nonzero leading coefficient 2^(j−1)β^(−j). These standard Chebyshev facts are invoked without an in-slice proof. They are an explicit representation-conversion leaf rather than a new mathematical assumption of Fact C.5.

For each fixed a, write P_j(x)=Σ_{k=0}^j h_{jk}xᵏ. Then

((g_a)ᵢ cos(jθᵢ))ᵢ = Σ_{k=0}^j h_{jk} Λᵏg_a.

The coefficient matrix (h_{jk})_{0≤j,k≤q} is triangular with nonzero diagonal, so it is invertible. Thus both families generate the same span, in both directions. Repeating this for all a gives the equality of the full joint spans. The columns of B are precisely those cosine-feature vectors times d^(−1/2)η_j. All those factors are nonzero under d≥2, so the column span remains the same. Using range(B)=column span then gives range(B)=K_q.

This is an AND-route: the polynomial identity, the nonzero leading coefficients/triangular inverse, the actual column formula with nonzero normalizations, and the definition of Krylov span all participate. Two span inclusions are not alternative OR-proofs. The paper gives no second sufficient source route in this slice. Replacing the Chebyshev notation by its recurrence would be a possible expansion of the same algebra, not a separately source-attributed route.

The deterministic conclusion holds for arbitrary supplied real g_a; neither Gaussianity, independence, Haar law, a concentration event, nor τ≤1/2 is needed for it. The frequency restriction 2q+1<d is inherited context for C.2 but not needed by this triangular span argument. Distinct eigenvalues and independence of the resulting feature columns are also unnecessary. An invertible coefficient transformation preserves span even if evaluated vectors are dependent or zero. In particular, r² can exceed d under 2q+1<d; the range identity alone does not prove full column rank.

The nonconstant affine parameter is essential for the general statement. If κ=1, Λ=I and all Λʲg_a repeat g_a, whereas cosine multiplication can enlarge the span. For example, take d=4,q=1,g₁=e₁+e₂,g₂=0. The first two cos θᵢ differ, so g₁ and diag(cos θᵢ)g₁ are independent; range(B) has dimension 2 and K₁ has dimension 1. This example lies outside the paper's κ≥2 domain and diagnoses the role of the nonzero slope; it does not refute the source. At q=0 the slope is not needed. Dropping nonzero column scaling can also destroy range equality. Conversely, extending q beyond the frequency restriction does not invalidate the algebraic basis conversion, although it can invalidate other C.5 components.

## Complete C.2 context and its actual dependency structure

C.5 contains six assertions, not just range equality. Its remaining deterministic pieces are ‖tᵢ‖²≤2r, Σᵢtᵢtᵢᵀ=dI_r, and Σᵢcos(nθᵢ)tᵢtᵢᵀ=0. Its stochastic pieces are E[BᵀB]=I_{r²} and E[BᵀD_nB]=0.

The common cosine-sum lemma is Σᵢcos(kθᵢ)=0 for integer 0<|k|<2d. The source proves it by multiplying by 2sin(kπ/(2d)), applying the sine difference formula at adjacent endpoints, telescoping, and then dividing by a nonzero sine. The zero mode is d, not 0. This bound on frequency is a real condition; at k=2d each cosine equals −1 and the sum is −d.

The constant coordinate of t handles the 0,0 and 0,j matrix entries separately. Product to sum handles positive j,k. When j=k the difference frequency is zero and contributes d; the positive sum frequency vanishes. When j≠k both relevant sums vanish. This proves the Gram identity. Multiplying three cosines produces the four frequencies n±j±k. The source checks 1≤n−j−k≤n±j±k≤n+j+k≤4q+1<2d, so all four vanish. This proves weighted cancellation; it genuinely uses n=2q+1 and the standing dimension bound. The √2 feature scaling gives identity, rather than a diagonal matrix with entries d/2, in the unweighted Gram calculation. The t norm bound follows directly from cos²≤1.

The row outer-product formula is BᵀB=(1/d)Σᵢ(γᵢγᵢᵀ⊗tᵢtᵢᵀ), with an added weight cos(nθᵢ) in BᵀD_nB. Using E[γᵢγᵢᵀ]=I_r and finite linearity of expectation converts the two deterministic feature sums into the two expectation identities. These expectations require the Gaussian second moments (or an isotropic replacement) but not the range-conversion argument. Independence across i is needed later for concentration, not for these expectation identities.

C.6 proves one simultaneous operator-norm event with probability ≥.995. It is retained in the graph as context and a genuine parent of the final inequalities, not a parent of the exact representation equalities. Its source route is:

1. For Rᵢ=‖γᵢ‖² and L=2r+3log(1000d), the Gaussian moment generating function E exp(Rᵢ/3)=3^(r/2), Markov's inequality, and (log3)/2<2/3 give P(Rᵢ>2r+3x)≤e^(−x), x≥0. The union event T={all Rᵢ≤L} has probability ≥.999. A tail integral gives E[Rᵢ1_{Rᵢ>L}]≤(L+3)/(1000d).
2. Define independent truncated Yᵢ=(1/d)(γᵢγᵢᵀ⊗tᵢtᵢᵀ)1_{Rᵢ≤L}. Radial symmetry gives E[γᵢγᵢᵀ1_{Rᵢ≤L}]=aI_r, where a=(1/r)E[Rᵢ1_{Rᵢ≤L}], 0≤a≤1, and 1−a≤(L+3)/(1000rd). The same a works for every i. Thus ΣE Yᵢ=aI and the weighted expectation is zero. Radial truncation matters: an arbitrary coordinatewise truncation cannot simply inherit this scalar expectation.
3. Set Zᵢ=Yᵢ−E Yᵢ. Using the feature norm yields ‖Zᵢ‖op≤R*=2r(L+1)/d, also for cos(nθᵢ)Zᵢ. Gaussian fourth moments give E[Rᵢγᵢγᵢᵀ]=(r+2)I_r; dropping the truncation in a positive semidefinite expression and using the deterministic Gram identity yields ΣE Yᵢ²⪯[2r(r+2)/d]I. Hence both centered sequences have variance parameter at most v*=2r(r+2)/d.
4. Both sequences are independent, centered, self-adjoint matrices of dimension r². The source invokes the two-sided bounded matrix Bernstein inequality, with prefactor 2r² and exponent −t²/[2(v*+R*t/3)]. This named external inequality has no bibliographic citation in the selected paragraph; its applicability assumptions are explicitly supplied by the prior steps. It is an external analytical leaf, not an in-slice proved theorem.
5. Put z=log(1000r²), Δ=√(2v*z)+2R*z/3. The displayed expansion shows the Bernstein exponent is at least z. Each bound fails with probability at most .002, so the two centered bounds hold together with probability .996. Intersecting T costs .001, giving .995. On T the original and truncated sums agree; the unweighted bias is (1−a)I, while the weighted bias is zero.
6. The integer restriction gives d≥2 and 2r≤d. Hence z=O(log d), L+3=O(r+log d), r+2≤3r, and Δ+(1−a) is bounded by an absolute multiple of r√(log d/d)+r(r+log d)log d/d. Choosing the same universal C large enough gives the asserted τ bound. The paper suppresses the numerical absolute constant in this simplification; the graph exposes that bookkeeping node rather than a new premise.

The earlier range identity is not used in any of these six concentration steps. C.6 uses the feature norm, unweighted feature Gram, weighted feature cancellation, and the Gaussian law. It does not consume the κ-dependent triangular basis conversion.

## Paragraph 19: one witness and two exact algebraic identities

On the simultaneous event from C.6, fix u∈K_q. The range component of C.5 gives a coefficient vector c with u=Bc. The same c is then used for both displays:

‖u‖²=cᵀBᵀBc,

uᵀD_nu=cᵀBᵀD_nBc,

and therefore also |uᵀD_nu|=|cᵀBᵀD_nBc|.

These exact equalities are ordinary matrix multiplication, transpose, and Euclidean norm identities. They are pointwise deterministic and need no concentration assumptions, no τ bound, no probability law, and no full-rank assumption. For example the second follows by substitution, (Bc)ᵀ=cᵀBᵀ, and associativity; the first is the special identity ‖v‖²=vᵀv with v=Bc. No symmetry of D_n is necessary for this exact substitution identity. The source's D_n is diagonal real, as required for its subsequent weighted-statistic interpretation. Expanding in coordinates confirms both sides carry the same embedded 1/d normalization from the two B factors.

The stochastic event is a parent only of the inequalities following those equalities. The Gram event supplies cᵀBᵀBc≥(1−τ)‖c‖² by bounding cᵀ(BᵀB−I)c in absolute value by τ‖c‖². The weighted event gives |cᵀBᵀD_nBc|≤τ‖c‖². Combining them is legitimate because they use one coefficient vector and hold for every c on the same event. Since τ≤1/2, 1−τ≥1/2>0; dividing yields |uᵀD_nu|≤τ/(1−τ)‖u‖²≤2τ‖u‖². Finally .995≥.99 weakens the probability to Lemma 4.4's advertised value.

The coefficient need not be unique, and choosing it separately for each u after the event is fixed creates no extra probabilistic independence requirement: the deterministic inequalities hold simultaneously for every c. Replacing c by different unrelated witnesses in the two estimates would destroy the stated argument. Omitting the equality u=Bc would leave the two quadratic expressions unconnected. Using only range(B)⊆K_q would not produce a coefficient for arbitrary u∈K_q; the reverse inclusion is the direction consumed at this site.

The source's output application in 4.2 further uses Lemma 4.3 and orthogonality of O to transfer to |XᵀOD_nOᵀX|≤2τ‖X‖². Those are additional application parents, not parents of paragraph 19's coefficient algebra. Target moments (Lemma 4.5), admissibility (Lemma 4.6), the lower-bound testing argument, and the comparison to κ=2 are not needed for the focal algebra. Their complete paragraph/equation/math inventory receives explicit context/exclusion dispositions rather than silent omission.

## Coverage and limitations

`source-pins.json` contains every id-bearing element in the three selected exact sections. `coverage.json` assigns each exactly one NODE or EXCLUDED disposition, with explanations and semantic node references. Raw source HTML slices are retained verbatim. The scan covers table equation groups and their separate tbody row ids, as well as inline and block math, including math whose class is `ltx_math_unparsed`. A scan for `ltx_equation` alone would miss the C.2 final pair A3.Ex130/A3.Ex131, which live inside A3.EGx13; those ids and math are explicitly covered here.

`source-graph.json` gives mathematical statements, leaf classifications, AND hyperedges, consumer use sites, standing context versus necessary parents, and conditional-discharge descriptions. It does not infer Lean entailment from a source outline, source similarity, or an import. There are no verified alternative source OR-routes in this slice. The graph is an authored source reconstruction, awaiting a distinct topology review; mechanical complete-ID coverage does not itself certify mathematical correctness. No target Lean fidelity or source-validity verdict is made in Phase 1.

The extraction uses standard-library HTMLParser only to locate exact spans and produce readable math-alttext views. The raw pin uses the original source substring and its original UTF8 encoding, not DOM-normalized text. Offsets are zero-based half-open Unicode-character and UTF8-byte intervals. LF line numbers are one-based and inclusive; a terminal LF belongs to the preceding line. HTML-decoded attributes and readable text are separately marked as derived. Source hash and each pin are checked again before freezing.
