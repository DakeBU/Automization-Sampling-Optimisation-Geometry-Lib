from pathlib import Path
import json,hashlib,subprocess,sys,datetime
sys.path.insert(0,'tools')
import astis_site
sha=lambda raw:hashlib.sha256(raw).hexdigest()
b=Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-normalizer-integration-20261108')
ev=Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-normalizer-semantic-evidence')
v=ev/'fresh-source-reader-640251/verification-transition'
head=subprocess.check_output(['git','rev-parse','HEAD']).decode().strip()
assert head=='c8c157a69aaad4007cb801a781e980a27005bb02'
def ref(p,encoding=None):
 p=Path(p);result={'path':str(p),'sha256':sha(p.read_bytes())}
 if encoding:result['encoding']=encoding
 return result
append=v/'normal-V-append.exact.jsonl'
if subprocess.run(['git','ls-files','--error-unmatch','--',str(append)],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode:
 rows=json.loads((ev/'source-verified-frozen-raw-packaging/manifest.json').read_bytes())['files']
 row=next(r for r in rows if r['original_path']==str(append))
 append_ref=ref(row['gzip_path'],'gzip')
else:append_ref=ref(append)
a={'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'authorized_by':'/root','authorization_kind':'normalizer-postcore-readonly-context',
 'advance_id':'ASTIS-SA-20261108-GaussianComplexityFixedSpectrumNormalizer',
 'proof_owner_to_preserve':'huanjian_gc_20261108_fixed_spectrum_normalizer',
 'source_verifier_to_preserve':'/root/norm_fresh_source_640251',
 'integration_owner':'huanjian_gc_20261108_fixed_spectrum_normalizer_integration',
 'accepted_immutable_core':head,'source_digest':astis_site.source_digest(),
 'publication_binding_sha256':'b2f41e36a9d705ff68da71f72f0ec14f1cd2ff105bcf0ae5000ef1406a5d1f41',
 'proposal_report_sha256':'6b86afe6caeaf8e1cc83fc782b1221c7b316edfa20f2439cd204d840da4bc87a',
 'browser_checker_sha256':'acd0b2be49b2c3059f9ae4659058a18c157f3dda673f4ebfb6e0d7a51e7a408f',
 'new_source_verdict':False,'parking_authorized':False,
 'source_lineage':{
 'checked_commit':'813268bc2683a82269364caffbc0c7490a884204',
 'accepted_audit_first_commit':'cc9e72d2a140a577258ed3a9c2c782cb561f3709',
 'source_V_first_commit':'cc9e72d2a140a577258ed3a9c2c782cb561f3709',
 'accepted_audit':ref('research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-normalizer.json'),
 'source_review_run':ref(ev/'fresh-source-reader-640251/phase3/review-run.json'),
 'source_V_before':ref(v/'before-ledger.lossless.jsonl.gz','gzip'),
 'source_V_after':ref(v/'after-ledger.lossless.jsonl.gz','gzip'),
 'source_V_append':append_ref,
 'source_V_API_receipt':ref(v/'actual-normal-V-API.receipt.json')},
 'scope':'Exact frozen v3 proposal/unchanged v2 checker via narrowly pinned v3 binding overlay. Read-only source lineage/protection preflight only. Actual same-core canonical gates, site/browser/independent visual acceptance and normal park remain separate.'}
p=b/'postcore-protection-context.json';assert not p.exists();p.write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'path':str(p),'sha256':sha(p.read_bytes()),'core':head,'source_digest':a['source_digest']}))
