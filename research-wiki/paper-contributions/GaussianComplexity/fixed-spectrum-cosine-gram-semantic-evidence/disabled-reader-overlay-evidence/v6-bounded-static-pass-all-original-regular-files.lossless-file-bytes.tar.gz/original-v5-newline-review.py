"""Replay exact original counterexample and independent newline/export controls."""
from review import *

old=(D/'proposal-v4.exact.py').read_bytes();new=(D/'proposal.py').read_bytes()
before=b"                source_lines[raw] = path.read_text(encoding='utf-8').splitlines()"
after=b"                literal = path.read_bytes().decode('utf-8')\n                source_lines[raw] = literal.split('\\n')\n                if source_lines[raw][-1] == '':\n                    source_lines[raw].pop()"
assert old.count(before)==1 and old.replace(before,after)==new
js('exact-delta-check.json',{'v4_sha256':sha(old),'v5_sha256':sha(new),'exactly_the_advertised_source_lines_assignment_changed':True,
 'raw_download_writer_unchanged':True,'matching_routing_panel_copy_URL_path_symlink_candidate_logic_unchanged':True})

frozen=json.loads((D/'original-counterexample/frozen-original-observed-defect.json').read_bytes())
raw=(D/'original-counterexample/UnicodeLineSeparator.lean').read_bytes()
literal='theorem sample : True := by\n  trivial\n'
assert sha(raw)==frozen['source_sha256'] and sha(literal.encode())==frozen['literal_sha256']
file('OriginalUnicodeCounterexample.lean',raw)
u=fixture_unit([],canonical='OriginalUnicodeCounterexample.lean',line=2)
actions=v5.exact_lean_step_actions(u,{'lean':literal},page);put('replay-original/actions.html',actions)
out=D/'replay-original/export';v5.export_sources(out,[u])
source=out/'data/lesson-sources/OriginalUnicodeCounterexample.lean.html'
tree=parse(source.read_bytes().decode('utf-8'))
context=parse(actions).descendants('a')[0].attrs['href'];fragment=urlsplit(context).fragment
anchor=[n for n in tree.descendants('span') if n.attrs.get('id')==fragment];assert len(anchor)==1
actual=[n.attrs['id'] for n in tree.descendants('span') if n.text().startswith('theorem sample')]
assert fragment=='L2' and actual==['L2'] and anchor[0].text()=='theorem sample : True := by'
assert (out/'data/lesson-sources/OriginalUnicodeCounterexample.lean').read_bytes()==raw
js('replay-original/result.json',{'original_frozen_source_sha256':sha(raw),'original_frozen_literal_sha256':sha(literal.encode()),
 'same_exact_source_and_literal_bytes':True,'v5_returned_context':context,'actual_code_sourceHTML_anchor':actual,
 'anchor_text':anchor[0].text(),'raw_download_exact':True,'original_U2028_counterexample_fixed':True,
 'scope':'New v5 replay; original frozen v4 counterexample/result remains unchanged.'})

# Every expected position is explicit. Line counts are independently checked
# from raw LF byte counts, including blank terminal LF lines.
cases=[
 {'id':'lf','whole':'-- prefix\nα\nβ\n','literal':'α\nβ\n','line':2,'end_line':3,'spans':3},
 {'id':'crlf','whole':'-- prefix\r\nα\r\nβ\r\n','literal':'α\r\nβ\r\n','line':2,'end_line':3,'spans':3},
 {'id':'crlf-no-normalized-match','whole':'-- prefix\r\nα\r\nβ\r\n','literal':'α\nβ\n','line':None,'end_line':None,'spans':3},
 {'id':'cr-before-lf','whole':'-- prefix\rstill-comment\nα\nβ\n','literal':'α\nβ\n','line':2,'end_line':3,'spans':3},
 {'id':'cr-only','whole':'α\rβ\r','literal':'α\rβ\r','line':None,'end_line':None,'spans':1},
 {'id':'u2028','whole':'-- prefix\u2028still-comment\nα\nβ\n','literal':'α\nβ\n','line':2,'end_line':3,'spans':3},
 {'id':'u2029','whole':'-- prefix\u2029still-comment\nα\nβ\n','literal':'α\nβ\n','line':2,'end_line':3,'spans':3},
 {'id':'u0085','whole':'-- prefix\u0085still-comment\nα\nβ\n','literal':'α\nβ\n','line':2,'end_line':3,'spans':3},
 {'id':'vertical-tab','whole':'-- prefix\vstill-comment\nα\nβ\n','literal':'α\nβ\n','line':2,'end_line':3,'spans':3},
 {'id':'form-feed','whole':'-- prefix\fstill-comment\nα\nβ\n','literal':'α\nβ\n','line':2,'end_line':3,'spans':3},
 {'id':'unicode-in-literal','whole':'-- 🧪 é\nα\u2028β\nγ\n','literal':'α\u2028β\nγ\n','line':2,'end_line':3,'spans':3},
 {'id':'no-terminal-lf','whole':'-- prefix\nα\nβ','literal':'α\nβ','line':2,'end_line':3,'spans':3},
 {'id':'one-terminal-lf','whole':'-- prefix\nα\nβ\n','literal':'α\nβ\n','line':2,'end_line':3,'spans':3},
 {'id':'two-terminal-lf','whole':'-- prefix\nα\nβ\n\n','literal':'α\nβ\n\n','line':2,'end_line':4,'spans':4},
 {'id':'three-terminal-lf','whole':'-- prefix\nα\nβ\n\n\n','literal':'α\nβ\n\n\n','line':2,'end_line':5,'spans':5},
 {'id':'snippet-ending-before-lf','whole':'-- prefix\nα\nβ\n-- tail\n','literal':'α\nβ','line':2,'end_line':3,'spans':4},
 {'id':'snippet-terminal-lf-preceding-line','whole':'-- prefix\nα\nβ\n-- tail\n','literal':'α\nβ\n','line':2,'end_line':3,'spans':4},
 {'id':'one-blank-line','whole':'\n','literal':'\n','line':1,'end_line':1,'spans':1},
 {'id':'two-blank-lines','whole':'\n\n','literal':'\n\n','line':1,'end_line':2,'spans':2},
 {'id':'empty-source','whole':'','literal':'','line':None,'end_line':None,'spans':0},
]
matrix=[];presentation=[]
for case in cases:
 name='newline/'+case['id']+'.lean';b=case['whole'].encode();lit=case['literal'].encode();file(name,b)
 # Explicit local citation has no theorem line; empty source is a valid export
 # fixture without pretending to contain a canonical declaration.
 u=fixture_unit([name]);out=D/'newline-matrix'/case['id'];v5.export_sources(out,[u])
 htmlfile=out/'data/lesson-sources'/(name+'.html');rawhtml=htmlfile.read_bytes().decode('utf-8')
 tree=parse(rawhtml);spans=[n for n in tree.descendants('span') if re.fullmatch('L[0-9]+',n.attrs.get('id',''))]
 assert len(spans)==case['spans'] and [n.attrs['id'] for n in spans]==['L'+str(i) for i in range(1,len(spans)+1)]
 count=b.count(b'\n')+(1 if b and not b.endswith(b'\n') else 0);assert count==case['spans']
 assert (out/'data/lesson-sources'/name).read_bytes()==b
 a=v5.exact_lean_step_actions(u,{'lean':case['literal']},page);put('newline-matrix/'+case['id']+'/actions.html',a)
 links=parse(a).descendants('a') if a else []
 if case['line'] is None:assert not links
 else:
  assert len(links)==2 and urlsplit(links[0].attrs['href']).fragment=='L'+str(case['line'])
  offset=b.index(lit);end=offset+len(lit);assert b.count(b'\n',0,offset)+1==case['line']
  assert b.count(b'\n',0,end-1)+1==case['end_line']
  first=spans[case['line']-1].text();expected=case['literal'].partition('\n')[0]
  assert first==expected
 row={'case':case['id'],'source_sha256':sha(b),'literal_sha256':sha(lit),'sourceHTML_span_count':len(spans),
  'expected_context_line':case['line'],'expected_inclusive_end_line_terminal_LF_preceding':case['end_line'],
  'raw_download_exact':True,'strict_byte_match_and_LF_anchor_checks':'PASS'}
 matrix.append(row)
 # Static HTML newline-preprocessing fixture only, no browser claim. CR
 # conversion is performed before parsing tags, as an HTML parser does.
 normalized_html=rawhtml.replace('\r\n','\n').replace('\r','\n')
 pre=parse(normalized_html).descendants('pre');assert len(pre)==1
 text=pre[0].text()
 expected=case['whole'].replace('\r\n','\n').replace('\r','\n')
 if expected and not expected.endswith('\n'):expected+='\n'
 presentation.append({'case':case['id'],'expected_normalized_source_with_one_terminal_display_LF':expected,
  'actual_sourceHTML_code_text_after_CR_preprocessing':text,'match':text==expected,
  'scope':'Static CR preprocessing and HTML text extraction only; no live browser screenshot/acceptance.'})
js('newline-matrix-results.json',matrix);js('sourceHTML-CR-presentation-controls.json',presentation)
assert all(r['strict_byte_match_and_LF_anchor_checks']=='PASS' for r in matrix)

# Concrete presentation regression compared with unchanged production for a
# normal CRLF source. Keep exact source and raw exports, do not implement repair.
example='-- prefix\r\ntheorem sample : True := by\r\n  trivial\r\n'
file('CRLFPresentation.lean',example)
u=fixture_unit(['CRLFPresentation.lean']);source_input=fixture/'CRLFPresentation.lean'
comparisons={}
for kind,renderer in renderers.items():
 renderer.ROOT=fixture;out=D/'counterexample-CRLF'/kind;renderer.export_sources(out,[u]);path=out/'data/lesson-sources/CRLFPresentation.lean.html';h=path.read_bytes().decode('utf-8')
 pre=parse(h.replace('\r\n','\n').replace('\r','\n')).descendants('pre');assert len(pre)==1
 comparisons[kind]={'sourceHTML_sha256':sha(path.read_bytes()),'normalized_code_text':pre[0].text(),
   'raw_sourceHTML_contains_CR_before_span_end':'\r</span>\n' in h,
   'raw_source_download_exact':(out/'data/lesson-sources/CRLFPresentation.lean').read_bytes()==example.encode() if kind=='proposal' else None}
expected=example.replace('\r\n','\n')
assert comparisons['production']['normalized_code_text']==expected
assert comparisons['proposal']['normalized_code_text']!=expected
assert comparisons['proposal']['normalized_code_text']==expected.replace('\n','\n\n')
put('counterexample-CRLF/CRLFPresentation.original.lean',example)
regression={'case':'Ordinary CRLF source now has doubled code-view line breaks after static HTML CR preprocessing',
 'source_sha256':sha(example.encode()),'source_bytes_hex':example.encode().hex(),'comparisons':comparisons,
 'expected_code_text':expected,'regression_confirmed_against_unchanged_production':True,
 'root_cause':'v5 retains each CR from CRLF at the end of a span, then export appends another LF after the closing span. The CR and LF are separated by markup, so CR preprocessing makes two line breaks.',
 'minimal_repair_boundary':'Keep LF-based anchor partition and raw downloads; ensure sourceHTML presentation emits one display line break for each CRLF boundary, without retaining CR inside a span and separately appending another LF. Review the repaired overlay independently.',
 'scope':'Static HTML source/CR preprocessing regression; no live browser acceptance or mathematical verdict.'}
js('counterexample-CRLF/observed-regression.json',regression)
js('scope-and-progress.json',{'candidate':C,'exact_v4_to_v5_delta':'Only advertised source_lines raw UTF8/LF change',
 'real_C5_six_routes_and_exact_folds':'PASS','copy_JS_contract':'All6 panels structurally meet unchanged handler selectors; no JS/clipboard execution claimed',
 'original_frozen_U2028_counterexample':'FIXED on exact original hashes','newline_matrix_cases_passed':len(matrix),
 'previous_exact_match_controls_passed':len(controls),'previous_path_URL_symlink_controls_passed':len(security),'previous_canonical_export_controls_passed':len(compat),
 'sourceHTML_presentation_mismatches':[r['case'] for r in presentation if not r['match']],
 'new_regression':regression,'decision':'DEFECT in CRLF sourceHTML presentation; stop after freeze, no HOLD release',
 'fixture_limits':'Actual renderer/export_sources/base.page with identity source_lineage global-shell fixture, unpublished Git and false gate. No live browser/JS/clipboard/global acceptance.',
 'preservation':'All prior frozen directories untouched; no tracked/shared changes or reviewer repair implementation.'})
print(json.dumps({'real_C5_routes':['P34','P54','P125','P156','T59','T13'],'full_T_bytes':7494,
 'original_U2028_counterexample':'FIXED with exact original hashes','newline_anchor_raw_download_cases_passed':len(matrix),
 'matching_controls_passed':len(controls),'path_URL_symlink_controls_passed':len(security),'canonical_export_controls_passed':len(compat),
 'new_defect':'CRLF sourceHTML emits CR inside span plus LF outside; static HTML CR preprocessing doubles line breaks versus production',
 'decision':'DEFECT; no HOLD release'},indent=2))
