# Independent source/type comparison

Verdict: **accepted as mathematically equivalent canonical one-row forms**, with no excess premise, constant drift, index drift, altered matrix sense, or source-scope mismatch. This verdict concerns only the exact pinned signatures and canonical definitions. It does not certify any proof, compiled dependency, normal verification transition, intake, or process action.

The packet hash is `899221eab62ec75aa1eb8d90f62c4a2e86c154037b934042433b11acce08b6d2`; statement seal `cc628d801ed367e1e57e99d69449d36a90b2803f7371986b964b4864409f6dec`; literal definition context `6e519e17615212c920c3e18e57c9dd416ac5addf2511a949c1bb8050b1adee43`. The producer and consumer signature strings independently rehash to `249edf1f3d15639eca0c0db2f827bca4981faf3648653ef83fb731abe564af32` and `d177e72a66ec143642b0518887a170f7906d9fc528a87ea399d02ee00842bfac`.

## Producer

The producer asserts integrability of the matrix-valued quartic function

\[
x\longmapsto \|x\|_2^2\,xx^\top
\]

under the canonical standard Gaussian measure on r=q+1 real Euclidean coordinates, together with

\[
\int \|x\|_2^2xx^\top\,d\mu(x)=(r+2)I_r.
\]

This is Ex113 in a canonical one-row realization, with the source's implicit integrability made explicit as a conclusion. The natural binders d,q and inequality 2q+1<d retain the source standing range. The producer does not need all that range for the local moment identity, but the retained source premise is not excess.

The standard Gaussian definition is an orthonormal-basis pushforward of a product of variance-one scalar Gaussians. It is not definitionally a product in the particular `WithLp.ofLp` coordinate basis. Identifying those coordinate laws is a genuine internal mathematical bridge: orthonormal-basis invariance gives independent N(0,1) coordinates. No law certificate or symmetry hypothesis has been added to the public theorem.

Finite absolute fourth and mixed moments give entrywise integrability. Passing from finite entries to `Integrable` in the matrix operator norm, and commuting continuous coordinate evaluation with the Bochner integral, must also be proved internally. These expansions preserve the source proof boundary.

## Consumer

For every deterministic finite row index i, the consumer asserts integrability of the ordinary matrix square Y(x)Y(x) and

\[
\mathbb E[Y^2]\preceq
\frac{(r+2)\sum_{k=0}^{q}t_i[k]^2}{d^2}
(I_r\otimes t_it_i^\top).
\]

The sum in the coefficient is the Euclidean feature squared length ||t_i||_2^2, not a norm on the function-valued t. This is precisely the uncentered, individual inference frozen in the raw reading, with the exact feature length retained. It precedes the source's sum over rows and has no concentration event. The producer's integrability is materially needed to transport the weighted moment through the fixed tensor map; its exact matrix mean supplies the coefficient r+2. A signature alone cannot establish that a later implementation actually uses those two components.

The row mapping is i_src=i.val+1. Therefore the typed midpoint (i.val+1/2)pi/d equals the source (i_src-1/2)pi/d. The frequency map is k_src=k.val, retaining the constant coordinate k=0 and frequencies 1,...,q. Gaussian coordinate labels separately map a_src=a.val+1. Tensor pairs keep Gaussian coordinates first and frequency coordinates second. There is no silent swap or unrecorded flattening into Fin(r^2).

The cutoff is exactly R<=L with L=2r+3 log(1000d). The indicator returns zero outside the closed event and introduces no retained-mass normalization. Since hq implies d>=2, the reciprocal and squared denominator have the intended source values.

## Canonical definitions and integrals

The supplied matrix multiplication definition is the finite sum of products. Thus `squared` is a matrix square. The outer-product, identity and Kronecker definitions have the expected entries and factor order. Over Real, the supplied `PosSemidef` definition means transpose symmetry and nonnegative quadratic forms. Because the index set is finite, testing all finitely supported vectors tests every vector. `PosSemidef(upper-integral)` has the correct Loewner direction.

The integral is totalized to zero outside complete matrix spaces or outside integrability. Here the matrix codomains are complete finite-dimensional real normed spaces, and both the producer and consumer conclude integrability of the exact function they integrate. The full conjunctions therefore prevent fallback-zero semantics from weakening either mathematical assertion. Integrability is not a public premise or an unverified choice branch.

## q=0 and source scope

At q=0, r=1 and Fin(q+1) is a singleton. Its only frequency has value zero, so t_i=(1), its squared length is one, and the feature matrix is (1). The producer is integrability of G^4 and E[G^4]=3. The consumer is

\[
\mathbb E[d^{-2}G^4\mathbf1_{\{G^2\le L\}}]\le3/d^2.
\]

The mixed diagonal sum is empty and there is no off-diagonal case. No q>=1 condition appears or is needed.

The consumer is a termwise source-supported inference, not a separately displayed source equation. Its measure is a canonical one-row realization, so it does not by itself prove transport to an original joint ambient probability space. No summation, centered variance, matrix Bernstein or full Gram concentration result is claimed.

## Proof obligations, without a semantic blocker

The substantive obligations are the standard-normal scalar fourth/mixed moment evaluations, sign symmetry, Euclidean coordinate norm expansion, finite-dimensional norm integrability, coordinate/integral transport, rank-one and tensor square algebra, measurable cutoff, PSD indicator removal, and integration of PSD order. They are explicit in the expanded graph and must be discharged inside the mathematical proof. None is a new theorem assumption or an invented process-permission condition. No semantic repair is proposed.

`semantic-comparison.json` audits every theorem binder and signature let and expands all relevant canonical definitions. `seven-slot-comparison.json` records the seven semantic slots separately for both roots. `proof-component-graph.json` gives exact expanded backward closures for the integrability and mean/order components, and for both conjunctions. The graph records mathematical proof ingredients only; it makes no claim about compiler-observed implementation dependencies.

All raw originals remain byte-identical. Only the supplied type/definition packet and my own raw freeze were inspected in this phase. No implementation, proof API, previous packet report, TC reading, or other review verdict was opened.
