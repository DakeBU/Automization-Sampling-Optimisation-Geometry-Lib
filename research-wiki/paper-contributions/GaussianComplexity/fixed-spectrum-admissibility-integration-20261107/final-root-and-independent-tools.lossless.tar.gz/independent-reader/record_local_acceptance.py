from pathlib import Path
import json,hashlib,gzip,datetime,subprocess,struct,sys
sys.dont_write_bytecode=True
R=Path('/Users/zhouhuanjian/ASTIS-GC');sys.path.insert(0,str(R/'tools'))
import astis_site,astis_publication as pub
O=R/'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-admissibility-integration-20261107/independent-integration-reader-review'
B=R/'.astis/huanjian-gc-fixed-spectrum-admissibility-integration-20261107/browser/live-20261108T012931887653Z'
CORE='6483deccec5b721527d9102b7a57102c0205149d';BINDING='e4e245c817d124b16e93b4f999df81132f1e50a9e38535903cb5c036417c0e94'
sha=lambda b:hashlib.sha256(b).hexdigest()
def put(p,x):assert not p.exists(),str(p);p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def cmd(*a):return subprocess.check_output(a,cwd=R)
assert cmd('git','rev-parse','HEAD').decode().strip()==CORE
reportbytes=(B/'report.json').read_bytes();assert sha(reportbytes)=='b6293034ea320c2437ff6f368ddcffb8bd6ce2fee5f11c722b84ecc53b06e1ca'
browser=json.loads(reportbytes);assert browser['status']=='passed' and not browser['errors'] and len(browser['screenshots'])==36
assert browser['head']==browser['actual_gate_commit']==browser['site_commit']==CORE
script=R/'.astis/huanjian-gc-fixed-spectrum-admissibility-integration-20261107/check_final_reader.py';assert sha(script.read_bytes())=='b61cca469b8c90051b6418a2f6efc73d3cba7c1fb31b401e755c33e8225fbe7c'
metadata=(R/'_site/data/build-metadata.json').read_bytes();gate=(R/'.astis/site-lean-gate.json').read_bytes()
assert sha(metadata)==browser['site_metadata_sha256'] and sha(gate)==browser['actual_gate_sha256']
m,g=json.loads(metadata),json.loads(gate)
assert m['git']['commit']==g['commit']==CORE and m['gate']['current'] and m['gate']['passed'] and g['passed']
assert browser['source_digest']==m['source_digest']==g['source_digest']==astis_site.source_digest()=='a800967790651d635b025d7d6bdb8ca112f5e2a5ebdb9a50252789cd762f0e62'
for p,h in browser['input_pins'].items():assert sha((R/p).read_bytes())==h and cmd('git','show',CORE+':'+p)==(R/p).read_bytes()
pub.check_advance(['AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumAdmissibility.actual_precision_admissible'],reviewed=True)
item=next(i for i in pub.load() if i['id']=='huanjian-fixed-spectrum-admissibility');assert pub.binding_digest(item,item['bindings'][0])==BINDING
receipt_specs=[
 ('exactHEAD_official_Lean','20261107T160011569521Z-fixed-spectrum-admissibility-canonical-exactHEAD-Lean.receipt.json',0,'e70944102896a6e22198c1403b5a5040cf1bd833745bf7478b5cf77463a3ecbf'),
 ('canonical_site_build','20261107T160124254951Z-fixed-spectrum-admissibility-canonical-site-build.receipt.json',0,'6140dd831d06b983bd0e961405ab71bc4710a87953a975aed862ae89292fe48f'),
 ('canonical_site_check','20261107T160226805171Z-fixed-spectrum-admissibility-canonical-site-check.receipt.json',0,'4d1fa4ac549f33810c8a646fab361b322326a66f7e88792118708261daf1317a'),
 ('initial_wrong_graph_output_argument','20261107T160226806620Z-fixed-spectrum-admissibility-canonical-graph-check.receipt.json',1,None),
 ('corrected_actual_existing_site_graph','20261107T160306903894Z-fixed-spectrum-admissibility-canonical-existing-site-graph.receipt.json',0,'ba9170f780a8ea2452d932e1916bb43afa9b39c4a375fb8fe9f001730cabb4d1'),
 ('approved_actual_Chrome','20261108T012922341633Z-fixed-spectrum-admissibility-final-browser.receipt.json',0,'3db3ee04dcfad78080d2fe0191ce5845e7747e7f1176f94898309cbf2fc4d5c8'),
 ('fresh_independent_full_protection','20261108T013211784957Z-fixed-spectrum-admissibility-independent-final-protection.receipt.json',0,'776a4b1c2632d78eaf3d46c6aa36299c83e537ea87e03e6559476b4899edb0e3'),
]
checks=[]
for role,name,exitcode,expected in receipt_specs:
 p=R/'.astis/huanjian-resume-20261103'/name;r=json.loads(p.read_bytes());raw=Path(r['log']).read_bytes()
 assert r['exit_code']==exitcode and r['head_before']==r['head_after']==CORE and sha(raw)==r['log_sha256']
 if expected:assert sha(raw)==expected
 checks.append({'role':role,'receipt':str(p.relative_to(R)),'receipt_sha256':sha(p.read_bytes()),'raw_log_sha256':sha(raw),'actual_exit_code':exitcode,'elapsed_seconds':r['elapsed_seconds'],'command':r['command']})
actual_names={p.name for p in B.glob('*.png')};assert actual_names=={r['file'] for r in browser['screenshots']}
observations=[]
for row in browser['screenshots']:
 p=B/row['file'];raw=p.read_bytes();assert sha(raw)==row['sha256'] and raw[:8]==b'\x89PNG\r\n\x1a\n'
 width,height=struct.unpack('>II',raw[16:24]);assert (width,height) in [(1440,1000),(390,844)]
 f=p.name
 if '-first.' in f:note='Compact rendered I<=A<=kappaI and A>0 with closed adjacent Lean; main text readable and source details folded.'
 elif '-assumptions.' in f:note='Actual d>=2/kappa>=2/fullO/either determinant sign, literal half-grid, PSD quadratic-form sense and no added proof premises visible; mobile screenshot is only a vertically scrolled portion of the full ledger.'
 elif '-proof-step1.' in f:note='Closed-envelope cosine coefficient derivation and both scalar endpoint formulas render; corresponding Lean disclosure stays adjacent.'
 elif '-proof-step2.' in f:note='Actual diagonal PSD differences render. On390 the long single-line equation continues in a local horizontal region with explicit scroll notice; no all-equation-in-one-viewport claim.'
 elif '-proof-step3.' in f:note='Actual orthogonal conjugation and both matrix difference formulas render with transpose and distinct D-/D+.'
 elif '-proof-step4.' in f:note='Positive identity contribution gives strict positivity as output. On390 the single-line quadratic formula uses an explicit local horizontal-scroll notice; no fullpage overflow.'
 elif '-proof-step5.' in f:note='Same literal A consumer is distinct from producer, with normalized Gaussian density formula including sqrt(detA), reald/2, exponential quadratic and Lebesgue dx.'
 elif '-standard-reuse.' in f:note='Producer Samplinglib-parent list is empty; Mathlib names and attributed source are readable. Long names wrap; mobile viewport does not contain the entire lower source note.'
 elif '-exact-statement.' in f:note='Exact Lean statement disclosure opened. Desktop captures its initial code lines;390 capture begins with explanation before the code body. DOM exact-source equality is checked by actual browser, not inferred from this viewport.'
 elif '-exact-proof.' in f:note='Exact Lean proof disclosure opened. Captures begin with explanatory prose and only initial code on desktop;390 code continues below viewport. Actual browser checks exact source bytes and local code scrolling.'
 elif '-module.' in f:note='Full module disclosure shows actual imports/source beginning and namespace, with module download. On390 long source lines use local code scrolling; the image is not the whole file. Module teaching-route Notmapped label is a separate preserved presentation status, not a denial of actual paper publication binding.'
 elif f.startswith('case-boundary-'):note='Full Theorem4.1 remains explicitly not formalized; actual precursor boundaries and source ranges are shown. Long boundary text continues below viewport.'
 elif f.startswith('source-index-'):note='Reviewed-work index is initially folded, identifies building blocks rather than complete paper results, and preserves the single SampleWiki reading context.'
 elif '-source-index-open.' in f:note='Actual new source-index item and full statement/proof link are visibly opened; native click reaches complete focused source reader in the actual browser run.'
 elif '-graph-module-native-click.' in f:note='Native owner-module neighbor click shows actual imports and downstream root/Registry/Test module structure; structural edges are not theorem implication. Mobile focuses selected module while some neighbors lie outside viewport.'
 elif f.startswith('canonical-Gaussian-'):note='Existing canonical GaussianPrecisionDensity declaration is one unique node with full inspector name. Its preserved PARTIAL/source-present badge is not upgraded; actual focused Test reuse/compile evidence is separate from graph reputation status.'
 elif f.startswith('existing-conceptual-'):note='Existing oracle-factorization conceptual bridge remains proposal/not-Lean-certified, source-reviewed mechanism only; no new admissibility candidate or formal parent/transport. Mobile entry focuses selected bridge; other context may lie beyond viewport.'
 elif '-graph-focused.' in f:note='Unique new compiled producer node is focused at readable scale; source correspondence/fidelity are dashed and own module ownership is structural. Mobile surrounding context is intentionally off-canvas; no whole-atlas readability claim.'
 else:raise AssertionError(f)
 observations.append({'file':str(p.relative_to(R)),'raw_sha256':sha(raw),'width':width,'height':height,'actually_viewed_original':True,'view_method':'tools.view_image detail=original, direct per-file view in six batches of six; no contact sheets or substituted images','reviewer':'/root/admiss_integration_reader','observation':note})
fresh=O/'final-protection-readback/postcore-readback.json';assert sha(fresh.read_bytes())=='dbe935d0841c13d2ed8621f35e6e5f212b0521b9af44e6c8a901fc649397615d'
fp=json.loads(fresh.read_bytes());assert fp['core']==CORE and fp['protected_foreign_content_count']==6892 and fp['foreign_advances']==281 and fp['foreign_frontier_count']==440 and fp['README_exact_bytes_preserved']
V=R/'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-admissibility-semantic-evidence/fresh-source-reader-742806'
manifests={}
for phase,h in [('phase1','146f481aaf35414e07619113050d547e8a75c85da2d868571f7f4a19c05fa50c'),('phase2','144b7d85641bf676f75967cba7898bc906313cbbbd6dbb1078c830e4469b2e7b'),('phase3','514f6f00525752261b570858d549aa5d7e67f2cccee9f6dec00546e3dbfdb2b4')]:
 p=V/phase/'manifest.json';assert sha(p.read_bytes())==h
 x=json.loads(p.read_bytes());count=0
 for row in x['files']:
  q=p.parent/row['path'];assert sha(q.read_bytes())==row['sha256'],str(q);count+=1
 manifests[phase]={'manifest_sha256':h,'actual_all_payloads_hash_checked':count}
assert cmd('git','rev-parse','HEAD').decode().strip()==CORE
origin=cmd('git','rev-parse','origin/main').decode().strip();assert origin=='d9bcd4231df69061c5221f8d557ee179a945c1eb';cmd('git','merge-base','--is-ancestor','origin/main','HEAD')
out={'reviewer':'/root/admiss_integration_reader','recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'state':'LOCAL_INTEGRATION_ACCEPTED','accepted_immutable_core':CORE,'publication_binding_sha256':BINDING,'scope':'Actual source-faithful pointwise cosine-grid precision admissibility plus genuine same-A canonical Gaussian density consumer, sourceV lineage, exactHEAD officialLean/site/graph/realChrome and all36original viewport inspections; no wholepaper or remote/purification claim.','blocking_objections':[],'actual_checks':checks,'browser_script_sha256':sha(script.read_bytes()),'browser_report':str((B/'report.json').relative_to(R)),'browser_report_sha256':sha(reportbytes),'browser_version':browser['browser_version'],'actual_original_images_viewed':observations,'actual_original_image_count':len(observations),'all36_direct_originals_viewed_no_contact_sheet':True,'actual_browser_coverage':{'progressive_initial_folds_and_math':True,'all_five_steps_opened_at1440_and390':True,'exact_adjacent_Lean_and_code_hscroll':browser['pages'],'actual_native_source_index_clicks':browser['visible_source_index_clicks'],'actual_native_graph_nodes_and_module_neighbor':browser['graphs'],'current_HEAD_gate_site_source_digest_identical':browser['source_digest']},'source_route_caveat':'Both actual page rows have immutable_link_syntax_checked=null because module links use own-site routes. The generic report sentence about GitHub-link syntax is conditional, not credited as an executed check. Own-site full module/download and local immutable Git source bytes actually passed. External GitHub/publicreader availability remains unverified and separate.','graph_status_caveat':'The identical existing GaussianPrecisionDensity node retains historical PARTIAL/source-present graph reputation despite independent actual compilation and consumer use; no unreviewed badge change or duplicated node. New producer ASTIS proof parents remain empty. Both models are byte-identical and no admissibility oracle-factorization substrate incidence is introduced.','viewport_limits':['390 formulas in proofsteps2/4 intentionally use local horizontal regions with explicit scroll notices; no all-formula-in-one-viewport or manual-touch testing claim.','Exact statement/proof screenshots begin at disclosure prose; full code byte equality comes from actual browser/source/download/immutableGit checks, not from claiming every code line appears in one screenshot.','Module screenshots show actual source beginning; long code can scroll locally. Assumption/source/boundary text is vertical and longer than one viewport.','Focused mobile graph shows selected readable node and inspector; surrounding context can be outside viewport. Fit/full-atlas label legibility and manual touch gestures are not certified.'],'fresh_protection_readback':{'path':str(fresh.relative_to(R)),'raw_sha256':sha(fresh.read_bytes()),'foreign_states':281,'foreign_frontiers':440,'protected_foreign_content':6892,'older_GC_evidence':3223,'README_and_Atlas_stat_preserved':True,'sourceV_lineage':fp['sourceV_lineage']},'fresh_source_frozen_phase_payloads_checked':manifests,'origin_main_localref_current':origin,'root_separate_visual_review':'Root reports17 current original views independently; this acceptance relies on this reviewer actualall36 direct views. Root evidence is separately recorded by root.','ledger_or_shared_or_API_mutations_by_this_acceptance':False,'parking_authorized_or_executed':False,'remaining_open':['Separate explicit normal parking authorization and final lossless browser archive/metadata packaging','Remote original-owner release/publication/publicreader and postmerge purification/Exposition Seal','C4 determinant/basis-independent known-normalizer product/calculus/Hessian/minimizer and moment/Krylov background','True adaptive/seed/transcript/output law, Gaussian target/TV parameter, finiteprecision and deterministic-cap/expected-cost adapters','Both complete main lower bounds and overall Goal']}
put(O/'actual-local-integration-acceptance.json',out)
put(O/'actual-local-integration-acceptance.freeze.json',{'reviewer':out['reviewer'],'accepted_immutable_core':CORE,'acceptance_sha256':sha((O/'actual-local-integration-acceptance.json').read_bytes()),'browser_report_sha256':sha(reportbytes),'original_png_count':36,'all_original_hashes':[{'file':x['file'],'raw_sha256':x['raw_sha256']} for x in observations],'current_protection_report_sha256':sha(fresh.read_bytes())})
print(json.dumps({'state':out['state'],'acceptance_sha256':sha((O/'actual-local-integration-acceptance.json').read_bytes()),'freeze_sha256':sha((O/'actual-local-integration-acceptance.freeze.json').read_bytes()),'actual_originals_viewed':len(observations),'source_phase_payloads':manifests}))
