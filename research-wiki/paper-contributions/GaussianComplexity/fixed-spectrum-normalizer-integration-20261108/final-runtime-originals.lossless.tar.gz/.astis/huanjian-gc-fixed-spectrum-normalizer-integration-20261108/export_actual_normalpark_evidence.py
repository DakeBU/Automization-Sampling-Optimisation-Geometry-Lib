"""Faithful public format projections only; no independent decision or lifecycle API."""
from pathlib import Path
import argparse, datetime, gzip, hashlib, json

B = Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-normalizer-integration-20261108')
CORE = 'a5ec44836422e56ca5cfab14f951ed84bbfc9324'
DIGEST = '92a908be0defdf1b5994f5ff4fe8a0e545cdca0f6c229cd1141c36338129bd21'
ACTOR = '/root/norm_integration_reader'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
dump = lambda value: (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode()
def ref(p):
    p = Path(p)
    return {'path': str(p), 'sha256': sha(p.read_bytes())}
def read_ref(row):
    raw = Path(row['path']).read_bytes()
    assert sha(raw) == row['sha256'], row['path']
    return raw
def write(p, value):
    assert not p.exists()
    p.write_bytes(dump(value))
    return ref(p)

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--acceptance', required=True)
parser.add_argument('--image-review', required=True)
parser.add_argument('--eligibility', required=True)
args = parser.parse_args()
paths = {key: Path(getattr(args, key.replace('-', '_'))) for key in ['acceptance', 'image-review', 'eligibility']}
for p in paths.values():
    assert p.is_relative_to(B / 'independent-reader')
raws = {key: p.read_bytes() for key, p in paths.items()}
objects = {key: json.loads(raw) for key, raw in raws.items()}
acceptance, review, eligibility = objects['acceptance'], objects['image-review'], objects['eligibility']
assert acceptance['state'] == 'LOCAL_INTEGRATION_READER_ACCEPTED' and acceptance['reviewer'] == ACTOR
assert acceptance['new_source_verdict'] is False and acceptance['parking_authorized_or_executed'] is False
assert acceptance['accepted_immutable_core'] == CORE
assert review['state'] == 'ORIGINAL46_REVIEW_COMPLETED' and review['reviewer'] == ACTOR
assert review['accepted_immutable_core'] == CORE and review['blocking_objections'] == []
assert review['raw_receipts_actually_read'] and review['foreign_graph_delta_actually_reviewed']
assert eligibility['state'] == 'NORMALPARK_ELIGIBILITY_REVIEWED_NOT_EXECUTED' and eligibility['reviewer'] == ACTOR
assert eligibility['accepted_immutable_core'] == CORE and eligibility['new_source_verdict'] is False and eligibility['lifecycle_API_called'] is False
assert eligibility['local_reader_acceptance'] == ref(paths['acceptance'])
assert acceptance['independent_original_image_review'] == ref(paths['image-review'])
assert acceptance['sourceV_lineage'] == eligibility['sourceV_lineage']
assert eligibility['normal_API_actor_to_preserve'] == '/root/norm_fresh_source_640251'
image_manifest = json.loads((B / 'successor-original-images/lossless-public-originals-manifest.json').read_bytes())
exports = {r['original']: r for r in image_manifest['files']}
assert len(exports) == len(review['images']) == 46
image_rows = []
for r in review['images']:
    assert r['reviewer'] == ACTOR and r['actually_viewed_original'] is True and len(r['observation'].strip()) >= 32
    e = exports[r['path']]
    assert r['sha256'] == e['raw_image_sha256'] and all(r[k] == e[k] for k in ['width', 'height'])
    original = gzip.decompress(read_ref(e['lossless_public_export']))
    assert original.startswith(b'\x89PNG\r\n\x1a\n') and sha(original) == r['sha256']
    image_rows.append({'id': Path(r['path']).name, 'actual_reviewed': True, 'decision': 'accepted', 'notes': r['observation'], 'image': e['lossless_public_export'], 'raw_image_sha256': r['sha256'], 'source_independent_row_verbatim': r})
assert len({r['id'] for r in image_rows}) == 46
checks_manifest = json.loads((B / 'successor-actual-checks/all-nine-manifest.json').read_bytes())
assert checks_manifest['immutable_core'] == CORE and checks_manifest['source_digest'] == DIGEST
assert checks_manifest['actual_completed_passing_checks'] == 9
check_rows = []
for row in checks_manifest['checks']:
    r = json.loads(read_ref(row['public_receipt']))
    assert r['exit_code'] == 0 and r['head_before'] == r['head_after'] == CORE
    lograw = gzip.decompress(read_ref(row['public_log']))
    assert sha(lograw) == r['log_sha256'] == row['raw_log_sha256']
    check_rows.append({'id': row['role'], 'receipt': row['public_receipt'], 'log': row['public_log']})
assert len(check_rows) == len({r['id'] for r in check_rows}) == 9
core_checks = {r['role']: r['receipt'] for r in acceptance['actual_checks']}
assert all(row['original_receipt'] == core_checks[row['role']] for row in checks_manifest['checks'])
report_path = Path(acceptance['browser_report']['path'])
report_raw = read_ref(acceptance['browser_report'])
browser = json.loads(report_raw)
assert browser['status'] == 'passed' and browser['head'] == CORE and browser['source_digest'] == DIGEST
assert review['browser_report_sha256'] == sha(report_raw)
out = B / 'normalpark-evidence-exports'
assert not out.exists()
out.mkdir()
common = {'projection_author': '/root', 'checked_core_commit': CORE, 'source_digest_sha256': DIGEST, 'recorded_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'projection_kind': 'Faithful hash-bound schema projection of existing actual independent decisions and real execution artifacts; not a new review, build, source verdict or lifecycle action.'}
images_ref = write(out / 'actual46-image-review.projection.json', {**common, 'reviewer': ACTOR, 'decision': 'accepted', 'blocking': [], 'source_independent_review': ref(paths['image-review']), 'global_decision_derivation': 'Independent LOCAL_INTEGRATION_READER_ACCEPTED plus completed per-original review with zero blocking objections, all actual-view flags and original byte identities. Per-row findings are copied without rewriting.', 'images': image_rows})
checks_ref = write(out / 'actual9-checks.projection.json', {**common, 'source_public_manifest': ref(B / 'successor-actual-checks/all-nine-manifest.json'), 'checks': check_rows})
eligibility_ref = write(out / 'normalpark-eligibility.projection.json', {**common, 'reviewer': ACTOR, 'eligible_for_normalpark': True, 'blocking': [], 'source_independent_eligibility': ref(paths['eligibility']), 'normal_API_actor_to_preserve': eligibility['normal_API_actor_to_preserve'], 'preserved_original_verifier_fields': eligibility['preserved_original_verifier_fields']})
reader_ref = write(out / 'independent-reader-acceptance.projection.json', {**common, 'reviewer': ACTOR, 'decision': 'accepted', 'blocking': [], 'source_independent_acceptance': ref(paths['acceptance']), 'source_independent_eligibility': ref(paths['eligibility']), 'eligibility_receipt_sha256': eligibility_ref['sha256'], 'actual_image_review_sha256': images_ref['sha256'], 'nine_actual_checks_sha256': checks_ref['sha256'], 'join_scope': 'This root-authored export joins already existing independent acceptance and later eligibility; it does not claim that the earlier acceptance originally contained the later eligibility hash.', 'new_source_verdict': False, 'remote_or_purification_or_wholeGoal_credit': False})
report_export = out / 'browser-report.original.json'
report_export.write_bytes(report_raw)
manifest_ref = write(out / 'manifest.json', {**common, 'original_sources': {key: ref(p) for key, p in paths.items()}, 'reader': reader_ref, 'eligibility': eligibility_ref, 'images': images_ref, 'checks': checks_ref, 'actual_browser_report_lossless_copy': ref(report_export), 'raw_browser_report_origin': str(report_path), 'helper': ref(Path(__file__)), 'API_called': False, 'required_check_ids': sorted(r['id'] for r in check_rows)})
print(json.dumps({'manifest': manifest_ref, 'reader': reader_ref, 'eligibility': eligibility_ref, 'images': images_ref, 'checks': checks_ref, 'decisions_newly_made': False, 'API_called': False}, ensure_ascii=False))
