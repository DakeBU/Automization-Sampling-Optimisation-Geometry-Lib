import Tests.GaussianComplexityFixedSpectrumSourceMatrixMean
open Lean
run_cmd do
  let paths ← Lean.searchPathRef.get
  logInfo m!"ACTUAL_NATIVE_SEARCH_PATH {paths}"
