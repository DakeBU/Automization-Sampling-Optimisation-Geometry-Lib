from verify import *
config=json.loads((D/'environment.json').read_text())
src=D/'fresh-strict/source'; out=D/'fresh-strict/lib'; src.mkdir(parents=True,exist_ok=True); out.mkdir(parents=True,exist_ok=True)
dep_paths=[]
for raw in config['lake_lean_path'].split(':'):
 p=pathlib.Path(raw); p=p if p.is_absolute() else (R/p).resolve()
 if p==(R/'.lake/build/lib/lean').resolve(): continue
 dep_paths.append(str(p))
assert all(str(R/'.lake/build/lib/lean')!=p for p in dep_paths)
env=os.environ.copy(); env['LEAN_PATH']=':'.join([str(out)]+dep_paths)
js('fresh-strict/import-path.json',{'LEAN_PATH':env['LEAN_PATH'],'dependency_paths':dep_paths,'cached_project_library_excluded':True,'project_imports_available_only_from_new_output':True})
for label,p in [('P',P),('T',T),('probe','IndependentNativeKernel.lean')]:
 target=src/p; target.parent.mkdir(parents=True,exist_ok=True)
 target.write_bytes((D/'fresh/source/IndependentNativeKernel.lean').read_bytes() if label=='probe' else gitbytes(p))
 dest=out/p.replace('.lean','.olean'); dest.parent.mkdir(parents=True,exist_ok=True)
 r=run('strict-fresh-'+label,[config['lean_binary'],'-o',str(dest),'-i',str(out/p.replace('.lean','.ilean')),p],cwd=src,env=env); assert r.returncode==0
js('fresh-strict/symlink-inventory.json',[{'path':str(p.relative_to(D)),'target':os.readlink(p)} for p in (D/'fresh-strict').rglob('*') if p.is_symlink()])
js('fresh-strict/artifacts.json',[{'path':str(p.relative_to(D)),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in (D/'fresh-strict').rglob('*') if p.is_file()])
for pkg in config['dependencies']:
 r=run('dependency-'+pkg['name']+'-full-status',['git','status','--porcelain','--untracked-files=all'],cwd=R/'.lake/packages'/pkg['name']); assert r.returncode==0 and not r.stdout
parent=run('candidate-parent',['git','rev-parse',C+'^']).stdout.decode().strip(); assert parent=='37eea55086ce04651d5b8f8a7348bc16d1b157cb'
print('STRICT_NATIVE_FRESH_P_T_PROBE_PASS; NO_CACHED_PROJECT_LIBRARY; NINE_DEPENDENCIES_FULL_STATUS_CLEAN')
