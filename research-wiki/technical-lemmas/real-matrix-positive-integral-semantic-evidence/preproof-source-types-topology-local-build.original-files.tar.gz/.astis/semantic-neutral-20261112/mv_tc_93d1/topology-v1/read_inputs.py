from pathlib import Path
from collections import OrderedDict
import json
import runpy
import sys

ROOT = Path('/Users/zhouhuanjian/ASTIS-GC')
OWN = ROOT/'.astis/semantic-neutral-20261112/mv_tc_93d1'
SG = ROOT/'.astis/semantic-neutral-20261112/mv_sg_42f6/source-graph-freeze-v1'
mode = sys.argv[1]
lo,hi = (int(v) for v in sys.argv[2:4]) if len(sys.argv)>2 else (0,1000)
sys.argv = [str(OWN/'read_raw.py'),'silent']
r = runpy.run_path(str(OWN/'read_raw.py'))
c = json.loads((SG/'post-seal-coverage.json').read_text())
groups = OrderedDict()
for n,a in enumerate(c['items']):
    groups.setdefault(a['source_element_id'],[]).append((n,a))
if mode=='counts':
    print(json.dumps({'atoms':len(c['items']),'source_groups':len(groups)}))
elif mode=='read':
    for n,(ident,atoms) in enumerate(groups.items()):
        if lo<=n<hi:
            print(json.dumps({'group':n,'source_id':ident,'own_raw_text':r['by_id'][ident].clean(),
                'atoms':[{'ordinal':k+1,**{key:val for key,val in a.items() if key in
                    ['id','kind','meaning','semantic_slice','disposition','reason','audited_meaning_clarification']}}
                    for k,a in atoms]},ensure_ascii=False))
