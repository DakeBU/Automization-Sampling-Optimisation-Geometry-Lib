# Independent radial-fourth raw source packet

Frozen before type exposure. Read `raw-reading.md`, `source-graph.json`, `coverage.json`, and `locators.json`.

The primary root is the individual bound

`E[Y_i²] ⪯ ((r+2)||t_i||²/d²)(I_r ⊗ t_i t_iᵀ)`.

It is the termwise inference immediately before the paper sums in C.2 EGx11. Ex113 and Ex114 are its two other recorded roots. The packet excludes all sums, centered variance and concentration. q=0/r=1 is retained.

Exact source pin: 951991 bytes; SHA-256 `6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915`.

`evidence-manifest.json` binds instructions, source identity, independence and all content artifacts. `SHA256SUMS` binds those artifacts and the manifest. No Lean/API/implementation/prior-graph content was inspected. This is raw topology evidence, not self-review or a proof/verification/process grant. Awaiting type-only input.
