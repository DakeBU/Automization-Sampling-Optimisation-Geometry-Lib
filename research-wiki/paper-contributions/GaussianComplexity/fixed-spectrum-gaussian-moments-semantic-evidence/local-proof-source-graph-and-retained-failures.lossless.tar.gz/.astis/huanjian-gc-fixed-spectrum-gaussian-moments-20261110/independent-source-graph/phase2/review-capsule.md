# Source graph review capsule

Extractor proposal only; distinct mathematical topology review is pending. No implementation Lean or moment API has been read.

The public producer projects Appendix C.3 p4.1/Ex140: actual Gaussian integrability and both expectation-to-grid identities. The private consumer additionally projects p4.2/p6.1/Ex144: the genuine Gaussian weighted alias-series precursor, with supported summability.

Pinned raw SHA256: `6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915`. Exact statement seal SHA256: `eed0782fa32075cdf6313e802293764bd6b07ca991974b9e56c8d520a8e13354`.

38 nodes, 28 consumer-use-site hyperedges, 13 visible SOURCE_GAP bridges. Coverage has 278 unique items, including all 64 core paragraph/display/header blocks and every attached formula/link occurrence.

The analytic bridge is actual Gaussian law → zero mean / inverse covariance / integrable second moments → coordinate squares → finite integral linearity → Ex140. The scalar route is C7 normalization and absolute convergence + finite grid/tsum exchange + zero grid mode + product-to-sum → Ex144. All-integer aliases normalize its inner sums; |a|≤1 and a geometric bound produce supported-series summability.

The source does not print the actual-law realization, the coordinate/norm/quadratic integrability arguments, or the finite expectation linearity details. They stay as SOURCE_GAP nodes. The literal standard Gaussian constructor must be justified on SPD covariance internally. These are proof ingredients, never extra source binders.

Signed indexing matters: the source j≥1 becomes Nat j+1, cast to Int before subtracting n; j−n can be negative. k=0 remains in the divisible alias branch. The dimension factor d is extracted from each inner finite sum to give the sealed d/√κ coefficient.

Closed C8 resummations, fourth moments, independence, variances, bias, rotated/Krylov/adaptive laws, global bounds and publication/integration/purification remain OPEN. The external [22] citation is contextual and supplies no selected proof dependency.

Review `source-graph.json`, `coverage-inventory.json`, `root-closures.json`, and `seal-projection.json` against the pinned raw source and exact seal. `structural-validation.json` is only shape/hash checking. The phase1 private cognition is intentionally not required for independent review.
