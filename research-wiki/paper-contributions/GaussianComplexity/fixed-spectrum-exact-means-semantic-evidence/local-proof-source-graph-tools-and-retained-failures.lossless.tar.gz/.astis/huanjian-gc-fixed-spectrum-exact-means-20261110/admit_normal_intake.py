"""Disabled until exact independent source/topology admission is frozen."""
from pathlib import Path
import hashlib, json, sys
sys.dont_write_bytecode = True
W = Path('.astis/huanjian-gc-fixed-spectrum-exact-means-20261110')
B = Path('research-wiki/paper-contributions/GaussianComplexity')
E = B / 'fixed-spectrum-exact-means-semantic-evidence'
C = Path('research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-exact-means.json')
L = Path('runs/substantive_advances.jsonl')
ADV = 'ASTIS-SA-20261110-GaussianComplexityFixedSpectrumExactMeans'
OWNER = 'huanjian_gc_20261110_fixed_spectrum_exact_means'
sha = lambda b: hashlib.sha256(b).hexdigest()
dump = lambda x: (json.dumps(x, ensure_ascii=False, indent=2) + '\n').encode()
def ref(p):
    return {'path': str(p), 'sha256': sha(p.read_bytes()), 'bytes': p.stat().st_size}
def put(p, b):
    assert not p.exists(), p
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(b)
grant = json.loads((W / 'root-preproof-admission-grant.json').read_bytes())
assert grant['source_graph_and_distinct_topology_admitted'] is True
assert grant['target_Lean_proof_authored_or_new_API_retrieved'] is False
sealpath = W / 'statement-seal-v1.json'
sealraw = sealpath.read_bytes()
assert sha(sealraw) == grant['seal_sha256'] == '81900673dcb74d8e5a321be926904feadd368478f651c619cb3675ee0cc92e3e'
for r in grant['actual_frozen_review_inputs']:
    assert sha(Path(r['path']).read_bytes()) == r['sha256'], r['path']
s = json.loads(sealraw)
b = json.loads((W / 'preproof-baseline.json').read_bytes())
before = L.read_bytes()
assert sha(before) == b['ledger']['sha256']
for name, h in b['all_frontier_hashes'].items():
    assert sha(Path(name).read_bytes()) == h, name
for name, h in b['protected_shared_hashes'].items():
    assert sha(Path(name).read_bytes()) == h, name
assert not C.exists() and not E.exists()
sys.path.insert(0, 'tools')
import astis_advance as advance
states = advance._replay_advances([json.loads(x) for x in before.splitlines()])
assert states == b['all_current_SAU_states'] and ADV not in states
assert not [k for k, v in states.items() if v['state'] == 'STABILIZING']
assert b['foreign_lane_still_occupied_no_transfer']
hold = b['actual_latest_fetch_observation']
assert sha(Path(hold['path']).read_bytes()) == hold['sha256']
prod = s['producer']['planned_file']
test = s['actual_private_consumer']['planned_file']
assert not Path(prod).exists() and not Path(test).exists()
name = s['producer']['name']
publicseal = B / 'fixed-spectrum-exact-means-statement-seal.json'
put(publicseal, sealraw)
put(E / 'preproof-source-admission.json', dump(grant))
put(E / 'producer.signature.lean.txt', s['producer']['signature'].encode())
put(E / 'consumer.signature.lean.txt', s['actual_private_consumer']['signature'].encode())
searched = s['shared_floor_audit']['searched_before_seal']
old = json.loads(Path('research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-gaussian-moments.json').read_bytes())
cell = {'schema_version': 3, 'cell_id': C.stem, 'route': 'samplewiki-route', 'mode': 'faithfulPaper',
    'title': 'Actual closed C8 Gaussian means with positive normalized bias ratio',
    'source_anchor': 'arXiv2610.20492v1 S4.E11/S4.Thmtheorem5; A3.Ex138,p5.1/Ex141-143,p6.2/Ex145-147; actual consumer p8.2,p9.1/Ex150',
    'target_statement': s['producer']['signature'], 'status': 'claimed', 'owner_id': OWNER,
    'advance_id': ADV, 'parents': [],
    'consumers': ['Sealed private actual Gaussian positive norm mean/upper bound, signed quadratic positivity and exact normalized-bias ratio; unproved at intake.',
        'Planned Lemma4.5 variance and exponential bias/full sampling lower bound; not certified by this packet.'],
    'shared_floor_audit': {'searched': searched, 'classification': 'adapt', 'decision': 'adapt_existing',
        'canonical_declaration': name, 'canonical_shared_cell': '',
        'notes': 'Post-admission exact canonicality and geometric/residue API retrieval required. Reuse canonical GaussianMoments/C7/GridAlias and found generic APIs. No duplicate wrapper; any genuinely missing shared leaf must follow shared-cell protocol.'},
    'reuse_plan': {'searched_existing': searched, 'reused_declarations': [], 'new_shared_declarations': [],
        'known_consumers': [], 'planned_consumers': ['actual_gaussian_closed_means_bias_ratio; materially use BOTH new actual closed mean formulas.'],
        'no_duplicate_wrapper': True, 'decision_reason': 'One coupled source FactC8 pair; its actual bias-ratio consumer needs both closed means. Integrability/mean-to-grid are canonical inputs inside the proof, never new public hypotheses.'},
    'reader_contract': old['reader_contract'],
    'graph_contribution': {'lean_view': 'new-node', 'overview_view': 'no-change-with-reason',
        'functor_view': 'none-found', 'edge_semantics': 'formal-solid; overlays-dashed',
        'color_semantics': 'evidence-status; library-scope', 'focus_targets': [name],
        'visual_review': 'Exact independent preproof source topology only; no new compiled node or site/graph/conceptual acceptance.'},
    'source_detail_audit': {'primary_edition': 'arXiv2610.20492v1', 'primary_anchor': 'A3.Ex138;A3.Ex141-147;A3.SS3.p8.2;A3.SS3.p9.1;A3.Ex150',
        'detail_status': 'omitted',
        'gap': 'Positive-mode alias class exhaustiveness/disjointness, signed frequencies/parity, all convergent geometric tails and index/exponent arithmetic, r/denominator/mean positivity, actual closed expectation and normalized ratio must be produced internally. M upper bound does not require variance/fourth moments. Broader source context remains outside.',
        'consulted': [{'source': 'Pinned raw source, new independent raw-first graph and distinct topology/binder/definition challenge',
            'anchor': 'S4.E11/Thmtheorem5;A3.Ex138,p5-p6/Ex141-147;p8.2,p9.1/Ex150',
            'hypothesis_adapter': 'Exactly d>=2,kappa>=2 and Nat1<=n<d. Actual Gaussian covarianceLambda inverse. No supplied r-range, series, positive-moment or variance/query/bias-gap premise.'}],
        'fidelity_boundary': s['truth_boundary']},
    'learning_contract': {'control_plane_math_authority': False, 'process_memory_checked': True,
        'process_memory_ids': old['learning_contract']['process_memory_ids'], 'failure_class': 'NONE',
        'salvage': {'required': False, 'status': 'not-applicable', 'reason': 'Only Prop-type formation and source admission so far; no new Lean target proof attempted.', 'promoted_fragments': [], 'discarded_fragments': []},
        'parallelism': {'decision': 'serial', 'direction_fingerprints': [],
            'expected_information_gain': 'Root sole mathematical worker. Source extraction and distinct challenge own separate source/coverage uncertainties; conditional integration preparation cannot execute while foreign owner holds the lane.',
            'shared_verified_context_digest': s['producer']['signature_sha256']},
        'cross_route_blind_spot_audit': {'required': False, 'status': 'not-applicable', 'evidence': '', 'canonical_route': '', 'selection_reason': 'No parallel proof routes.'},
        'reader_backpressure': {'purification_status': 'pending', 'exposition_seal_status': 'pending', 'exposition_evidence': '',
            'source_expansion_nodes': [], 'lean_expansion_nodes': [], 'assumptions_preserved': True, 'boundary_preserved': True}},
    'statement_seal': {'path': str(publicseal), 'sha256': sha(sealraw), 'signature_sha256': s['producer']['signature_sha256'],
        'status': 'EXACT_TYPE_FORMED_INDEPENDENT_PREPROOF_ADMITTED_NO_PROOF'},
    'source_proof_coverage': {'preproof_admission': ref(E / 'preproof-source-admission.json'),
        'internal_obligations_still_unproved': s['internal_dependencies_not_premises']},
    'evidence': {'execution_boundary': s['truth_boundary'], 'focused_checks': [],
        'preproof_source_admission': str(E / 'preproof-source-admission.json'), 'actual_consumer_seal': s['actual_private_consumer'],
        'independent_verification': '', 'root_build': '', 'graph_regeneration': '', 'pr': '', 'known_foreign_lane_HOLD_observation': hold},
    'blocked': {'reason': '', 'children': []}}
p = advance.AdvanceProposal(advance_id=ADV, task_id='ASTIS-SW-GAUSSIAN-COMPLEXITY-2026',
    goal='Prove the actual closed FactC8 Gaussian norm/cosine means and consume both in a genuine positive-sign/norm-bound/normalized-bias ratio.',
    source_anchor=cell['source_anchor'], theorem_delta=s['producer']['signature'], truth_boundary=s['truth_boundary'], created_by=OWNER,
    dag_inputs=('source:arXiv2610.20492v1:A3.Ex138/Ex141-147', 'canonical:actualGaussianMoments/C7/GridAlias candidate reuse, not public premises'),
    proposed_files=(prod, test, str(C), 'website/content/declaration_lessons/huanjian-fixed-spectrum-exact-means.json', 'website/content/publications/huanjian-fixed-spectrum-exact-means.json'),
    focused_checks=('lake env lean ' + prod, 'lake build Tests.GaussianComplexityFixedSpectrumExactMeans'),
    modes=('source-reading', 'proof-design', 'compiler-diagnosis'), priority=50, frontier_cell=C.stem, target_declarations=(name,))
p.validate()
advance.propose_advance(p)
advance.transition_advance(ADV, 'CLAIMED', worker_id=OWNER,
    evidence={'exact_statement_seal': ref(publicseal), 'preproof_admission': ref(E / 'preproof-source-admission.json'), 'truth_boundary': s['truth_boundary']})
advance.transition_advance(ADV, 'EXPLORING', worker_id=OWNER,
    evidence={'preproof_admission': ref(E / 'preproof-source-admission.json'), 'source_graph_and_distinct_topology_admitted': True,
        'new_Lean_target_proof_and_API_retrieval_start_after_this_event': True, 'shared_integration_authorized': False, 'truth_boundary': s['truth_boundary']})
C.write_bytes(dump(cell))
after = L.read_bytes()
assert after.startswith(before)
appended = after[len(before):]
assert len(appended.splitlines()) == 3
new = advance._replay_advances([json.loads(x) for x in after.splitlines()])
assert new[ADV]['state'] == 'EXPLORING' and {k: v for k, v in new.items() if k != ADV} == states
for name, h in b['all_frontier_hashes'].items():
    assert sha(Path(name).read_bytes()) == h, name
for name, h in b['protected_shared_hashes'].items():
    assert sha(Path(name).read_bytes()) == h, name
put(E / 'normal-EXPLORING-append.exact.jsonl', appended)
put(E / 'normal-intake-preservation.json', dump({'normal_API_calls': 3, 'advance_id': ADV, 'owner': OWNER, 'state': 'EXPLORING',
    'raw_prefix_preserved': True, 'foreign_SAU_states_preserved': len(states), 'foreign_frontier_raw_files_preserved': len(b['all_frontier_hashes']),
    'append': ref(E / 'normal-EXPLORING-append.exact.jsonl'), 'new_cell': ref(C), 'local_STAB': [],
    'foreign_lane_still_occupied': True, 'new_proof_or_sourceV_or_integration_credit': False}))
print(json.dumps({'state': 'EXPLORING', 'normal_API_calls': 3, 'append_sha256': sha(appended),
    'foreign_states_preserved': len(states), 'foreign_frontiers_preserved': len(b['all_frontier_hashes']), 'mathematical_result_or_sourceV': False}))
