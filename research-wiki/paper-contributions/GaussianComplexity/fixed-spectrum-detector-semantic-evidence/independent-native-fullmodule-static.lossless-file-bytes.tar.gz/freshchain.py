from pathlib import Path
import subprocess,os,json,hashlib,shutil,sys
W=Path(__file__).resolve().parent; ROOT=W.parents[2]
def run(argv,env=None):
 print('ACTUAL_CHILD_COMMAND '+json.dumps(argv),flush=True)
 p=subprocess.run(argv,cwd=ROOT,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 print(p.stdout.decode(errors='replace'),flush=True)
 print('ACTUAL_CHILD_EXIT '+str(p.returncode),flush=True)
 if p.returncode: sys.exit(p.returncode)
 return p.stdout
lean=run(['elan','which','lean']).decode().strip()
search=run(['lake','env','printenv','LEAN_PATH']).decode().strip()
lib=W/'freshlib'; pd=lib/'AutoSamplingTheory/ExampleCases/GaussianComplexity'; pd.mkdir(parents=True)
for p in W.glob('FreshProducer.olean*'):
 shutil.copyfile(p,pd/('FixedSpectrumDetector'+p.name.removeprefix('FreshProducer')))
consumer=lib/'Tests/GaussianComplexityFixedSpectrumDetector.olean'; consumer.parent.mkdir()
env=dict(os.environ); env['LEAN_PATH']=str(lib)+':'+search
print('ACTUAL_FRESH_LEAN_PATH '+env['LEAN_PATH'],flush=True)
run([lean,'-o',str(consumer),'Tests/GaussianComplexityFixedSpectrumDetector.lean'],env)
run([lean,'-o',str(W/'IndependentKernelAudit.olean'),str(W/'IndependentKernelAudit.lean')],env)
for p in sorted(lib.rglob('*')):
 if p.is_file(): print('ACTUAL_FRESH_IMPORTED_ARTIFACT '+json.dumps({'path':str(p.relative_to(ROOT)),'size':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}),flush=True)
