#!/usr/bin/env python3
"""Source-only artifact QA and freeze manifest. No repository control-plane IO."""
import sys
sys.dont_write_bytecode = True
import extract_source as x
import hashlib
import json
from pathlib import Path
BASE=x.BASE
def dump(name,obj):
    (BASE/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

process_paths=['AGENTS.md','docs/theorem-publication-protocol.md','docs/proof-digestion-protocol.md',
               'docs/evidence-routed-memory-protocol.md','.agents/skills/astis-source-dependency-audit/SKILL.md']
process=[{'path':p,'bytes':(x.REPO/p).stat().st_size,'sha256':digest(x.REPO/p),'role':'mandated process-only input; not mathematical evidence'} for p in process_paths]
dump('input_exposure_log.json',{
 'role':'Independent raw-source cognition/topology extractor; phase1 only.',
 'read_inputs':[{'path':str(x.SOURCE.relative_to(x.REPO)),'bytes':len(x.blob),'sha256':x.EXPECTED,'role':'sole mathematical input; full file read computationally to parse, bounded regions read substantively'},*process],
 'task_cues':['Parent assigned the next bounded fixed-spectrum moments slice, named Lemma 4.5, Appendix C.3, Section 4.1/Section 2 and Section 4.3.',
               'Parent stated it is the sole proof worker and a prior local integration is being released separately; no integration contents or verdicts were supplied/read.',
               'No sealed Lean interface was supplied or inferred; the root will seal the producer/actual-consumer interface after this freeze.'],
 'ambient_exposure':['Inherited system/developer/user instructions and approved-command-prefix labels contain older integration/geometry/normalizer/first-order packet names and paths. These are ambient labels, not reviewed mathematical evidence.',
                     'Mandated AGENTS.md contains scheduling/frontier/handoff pointers and an embedded Latest Bench handoff with some proof-plan labels. Those literal process lines were visible in the mandated AGENTS read; linked files and plans were not opened or used.',
                     'The other required process documents contain implementation/publication examples, lifecycle names, external workflow links and earlier source lessons. Read as process rules only, not as evidence about this paper or implementation.'],
 'raw_source_incidental_exposure':['Initial broad rg over the one allowed raw HTML searched Lemma 4.5, A3.SS3, license, S4 subsection ids and 4.5. Its output was truncated and included source ToC/backlinks, static icon/license text, and matching references outside the subsequently declared bounded regions. Absolute blindness to all other raw-source lines is not claimed.',
                                  'A structure-only scan of raw Section 4 printed headings, theorem labels and first approximately 220 readable characters for each structural item, including Section 4.4 limitation headings/snippets and Lemma 4.7/Remark 4.8 labels. Section 4.4 was not substantively expanded and is explicitly excluded.',
                                  'The raw bibliography item [22] displays backlinks into Sections 1 and 4 and Table 1. Those are navigation cues; their targets were not read.',
                                  'Raw title/authors/license metadata was inspected directly. Email/affiliation data in the author metadata was incidental and is not used mathematically.'],
 'tools_and_failures':[{'action':'pwd and exact cat/sed reads of mandated process files','result':'Initial combined output truncated; theorem-publication/proof-digestion and AGENTS blocks were subsequently read separately to complete process exposure.'},
                       {'action':'shasum -a 256 and wc -c on raw source','result':'Pinned digest and 951991-byte size match.'},
                       {'action':'python import bs4','result':'Unavailable; no package installed, no network attempted. Standard-library HTMLParser used instead.'},
                       {'action':'first task-local extractor run','result':'Task-local path-parent indexing error caused FileNotFoundError before any extra input was read; corrected within own script.'},
                       {'action':'raw HTML parser inspection and artifact generation','result':'All mathematical reads from the pinned raw HTML only. Scripts and generated files confined to this phase1 directory.'}],
 'not_accessed':['implementation Lean, imports, Tests, lake packages or API searches','claim/proof/publication/audit/candidate packets or old review graphs/verdicts','handoff/progress/README/frontier/ledger/source-index contents as separate files','canonical queue/model/ledger or other-paper control-plane state','ATLAS or restricted materials','external cited preprint [22] or any linked external source','browser, network, native-app/OS UI, provider/model calls, subagents or git operations'],
 'writes':'Only newly created .astis/huanjian-gc-fixed-spectrum-moments-20261109/source-only-review/phase1/ files; no shared/canonical writes or commits.',
 'status':'Frozen source understanding; independent challenge pending, no VERIFIED or source theorem credit.'})

metadata=[]
for node in x.parser.root.walk():
    if node.tag=='title' or 'ltx_authors' in node.attrs.get('class','').split() or node.attrs.get('id')=='license-tr':
        label='title' if node.tag=='title' else ('authors' if node.attrs.get('id')!='license-tr' else 'license')
        name='raw-metadata-'+label+'.html'
        (BASE/name).write_bytes(x.excerpt(node).encode('utf-8'))
        metadata.append({**x.record(node),'label':label,'readable':x.clean(x.rendered(node)),
                         'raw_excerpt_file':name,'links':[{'href':n.attrs.get('href'),'text':x.clean(x.rendered(n))} for n in node.walk() if n.tag=='a' and n.attrs.get('href')]})
dump('source_provenance.json',{
 'title':'On Complexity of Gaussian Sampling','authors':['Huanjian Zhou','Taiji Suzuki'],
 'revision':'arXiv:2610.20492v1','input_path':str(x.SOURCE.relative_to(x.REPO)),'sha256':x.EXPECTED,'bytes':len(x.blob),
 'bibliographic_locator':'https://arxiv.org/html/2610.20492v1','new_fetch':False,
 'provenance_limit':'This phase reused a pre-existing parent-pinned snapshot; it did not inspect a download receipt or infer one.',
 'license_notice':'arXiv.org perpetual non-exclusive license',
 'license_notice_href':x.ids['license-tr'].attrs['href'],
 'license_limit':'Recorded as displayed. No CC/open-content license or permission for any external cited work is asserted. No external text/package imported or republished.',
 'metadata':metadata})

graph=json.loads((BASE/'source_graph.json').read_text())
regions=json.loads((BASE/'declared_regions.json').read_text())
anchors=json.loads((BASE/'all_source_anchors.json').read_text())
math=json.loads((BASE/'all_math_anchors.json').read_text())
links=json.loads((BASE/'all_source_links.json').read_text())
coverage=json.loads((BASE/'paragraph_display_citation_coverage.json').read_text())
ids={n['id'] for n in graph['nodes']}
assert len(ids)==len(graph['nodes'])
def check_record(rec):
    data=x.blob[rec['start_byte']:rec['end_byte_exclusive']]
    assert hashlib.sha256(data).hexdigest()==rec['raw_sha256'], rec
for rec in anchors+math+links+coverage+regions:
    check_record(rec)
    if rec.get('node_id'): assert rec['node_id'] in ids
    for key in rec.get('node_ids',[]): assert key in ids
for region in regions:
    assert (BASE/region['raw_excerpt_file']).read_bytes()==x.blob[region['start_byte']:region['end_byte_exclusive']]
for item in metadata:
    check_record(item)
    assert digest(BASE/item['raw_excerpt_file'])==item['raw_sha256']
for n in graph['nodes']:
    for a in n.get('source_anchors',[]): assert a in x.ids
    for a in n.get('claimed_or_used_at',[])+n.get('stated_at',[]): assert a in x.ids
for e in graph['hyperedges']:
    assert e['consumer'] in ids
    assert set(e['parents'])<=ids
    assert e['semantics']=='AND'
    assert e['conditional_discharge']
    for a in e['consumer_use_sites']: assert a in x.ids
for e in graph['reference_edges']:
    assert e['from'] in ids and e['to'] in ids
    for a in e['consumer_use_sites']: assert a in x.ids
adj={key:[] for key in ids}
for e in graph['hyperedges']:
    for p in e['parents']: adj[p].append(e['consumer'])
state={}
def visit(key):
    assert state.get(key)!=1, 'cycle: '+key
    if state.get(key)==2: return
    state[key]=1
    for child in adj[key]: visit(child)
    state[key]=2
for key in ids: visit(key)
expected=[]
for region in regions:
    expected += [n.attrs['id'] for n in x.ids[region['id']].walk() if n.attrs.get('id')]
assert sorted(expected)==sorted(n['id'] for n in anchors)
assert len(set(expected))==len(expected)
assert all(m['tex'] and m['alttext_equals_annotation'] for m in math)
assert all(l['target_exists_in_pinned_snapshot'] for l in links if l['href'].startswith('#'))
assert all(c['disposition'] in {'NODE','EXCLUDED'} for c in coverage)
assert all(c.get('node_id') or c.get('node_ids') or c.get('reason') for c in coverage)
dump('structural_validation.json',{
 'result':'PASS: artifact structure and pin consistency only',
 'checks':['Raw source digest and size match parent pin.','Every region excerpt byte-for-byte matches its source span.',
           'Every anchor/math/link/coverage raw hash matches source byte offsets.','All source ids in every declared region inventoried exactly once.',
           'Every paragraph/display/citation/theorem/heading coverage record has explicit NODE/EXCLUDED disposition.',
           'Every math alttext exists and equals its TeX annotation.','Every local link resolves in pinned snapshot.',
           'Graph node ids unique, all parent/consumer references valid, all consumer-use anchors exist.',
           'AND dependency graph acyclic; citation/provenance edges kept separate.','All conditional edges carry explicit discharge text.'],
 'limits':['Not a mathematical proof check.','Not an independent topology review.','Not a seal of any implementation interface.','No formal theorem/source-completion credit.'],
 'counts':{'regions':len(regions),'source_ids':len(anchors),'math':len(math),'links':len(links),'coverage_records':len(coverage),'nodes':len(ids),'AND_hyperedges':len(graph['hyperedges']),'typed_reference_edges':len(graph['reference_edges'])}})

# Discard only this script's newly generated import bytecode, not source evidence.
cache=BASE/'__pycache__'
if cache.exists():
    for item in cache.iterdir():
        assert item.name.startswith('extract_source.') and item.suffix=='.pyc'
        item.unlink()
    cache.rmdir()
files=[]
for path in sorted(BASE.iterdir()):
    if path.is_file() and path.name!='manifest.json':
        files.append({'path':path.name,'bytes':path.stat().st_size,'sha256':digest(path)})
manifest={
 'schema':'source-only-phase1-manifest-v1','freeze_status':'FROZEN_SOURCE_UNDERSTANDING_PENDING_INDEPENDENT_CHALLENGE',
 'source_sha256':x.EXPECTED,'source_bytes':len(x.blob),
 'boundary':'Only phase1 raw-source graph, evidence and coverage; no implementation statement/route/API/claim or canonical state mutation.',
 'files':files,
 'manifest_hash_rule':'manifest.json intentionally does not hash itself; external sha256 of this file is the freeze handle.'}
dump('manifest.json',manifest)
print(json.dumps({'manifest_sha256':digest(BASE/'manifest.json'),'source_graph_sha256':digest(BASE/'source_graph.json'),
                  'understanding_sha256':digest(BASE/'phase1-source-understanding.md'),'coverage_sha256':digest(BASE/'paragraph_display_citation_coverage.json'),
                  'files':len(files),'validation':'PASS structure only; independent challenge pending'}))
