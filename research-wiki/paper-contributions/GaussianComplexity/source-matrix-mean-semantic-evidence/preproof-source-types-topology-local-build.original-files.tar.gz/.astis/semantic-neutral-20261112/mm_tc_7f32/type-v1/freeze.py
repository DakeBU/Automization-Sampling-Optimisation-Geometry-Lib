from pathlib import Path
import datetime
import hashlib
import json

ROOT = Path('/Users/zhouhuanjian/ASTIS-GC')
OWN = ROOT / '.astis/semantic-neutral-20261112/mm_tc_7f32'
DEST = OWN/'type-v1'
PACKET = ROOT/'.astis/huanjian-gc-source-matrix-mean-20261112/selective-type-definition-packet.json'

def sha(b):
    return hashlib.sha256(b).hexdigest()

def digest(p):
    b = p.read_bytes()
    return {'path':str(p.relative_to(ROOT)), 'bytes':len(b), 'sha256':sha(b)}

def write(name, obj):
    (DEST/name).write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n')

assert digest(PACKET)['sha256'] == 'efdba6eea9aa32da4cd9ea8d5022548ac128179f1ba73661fefa342f6ca4d95c'
p = json.loads(PACKET.read_text())
assert p['statement_seal_sha256'] == 'b55a1acb837288d580a667903987e5f809610626eb4848c750ff8d3a6c01149b'
assert p['minimal_definition_context_sha256'] == '92117d5029065dcbd8e1a218bb175a7c32d37e9dd34ac2f5255125e2f9c48cfa'
assert p['producer']['signature_sha256'] == '099bcbe9d6cc440754282873a7f1e1001584c3566fc771a70bf9f1a3846b85fe'
assert p['actual_private_consumer']['signature_sha256'] == '00c0b050a632e03d9b169acdb6632ae85a9ec43cc2b5e8aa26b7b6152a711b7e'
for key in ['producer','actual_private_consumer']:
    assert sha(p[key]['signature'].encode()) == p[key]['signature_sha256']
c = p['minimal_definition_context']
assert sha(c['literal_current_prints_and_instances'].encode()) == c['literal_current_prints_sha256']
assert len(c['literal_definition_excerpts']) == 6
assert all(sha(a['literal_source'].encode()) == a['literal_source_sha256'] for a in c['literal_definition_excerpts'])
raw = (ROOT/p['source']['raw']).read_bytes()
assert sha(raw) == p['source']['raw_sha256'] == '6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
assert len(p['source']['anchors']) == 7
for a in p['source']['anchors']:
    assert sha(raw[a['raw_utf8_start']:a['raw_utf8_end']]) == a['span_sha256']
    assert raw.decode()[a['char_start']:a['char_end']].encode() == raw[a['raw_utf8_start']:a['raw_utf8_end']]

assert digest(OWN/'raw-freeze.json')['sha256'] == '30a7d626b681fb59c522969a9be91797d1ca794f5e0433ea6941dfc7064c3fa8'
raw_preserved = []
for line in (OWN/'SHA256SUMS').read_text().splitlines():
    expected,name = line.split('  ',1)
    assert digest(OWN/name)['sha256'] == expected
    raw_preserved.append(digest(OWN/name))
prior_input = json.loads((OWN/'input-manifest.json').read_text())
for a in prior_input['prior_R7_preserved_by_existing_checksum_manifests']:
    assert digest(ROOT/a['path'])['sha256'] == a['sha256']
write('input-manifest.json', {
    'packet':digest(PACKET),
    'assignment':digest(DEST/'assignment.txt'),
    'statement_seal_sha256_as_named':p['statement_seal_sha256'],
    'producer_signature_sha256_recomputed':p['producer']['signature_sha256'],
    'consumer_signature_sha256_recomputed':p['actual_private_consumer']['signature_sha256'],
    'definition_context_sha256_as_named':p['minimal_definition_context_sha256'],
    'literal_print_sha256_recomputed':c['literal_current_prints_sha256'],
    'all_six_embedded_excerpt_hashes_recomputed_match':True,
    'all_seven_raw_source_span_hashes_and_char_byte_maps_match':True,
    'prior_raw_records_preserved':raw_preserved,
    'prior_R7_records_preserved_count':len(prior_input['prior_R7_preserved_by_existing_checksum_manifests']),
})
names = ['assignment.txt','audit.md','exposure.json','freeze.py','input-manifest.json']
freeze = {
    'kind':'independent-fixed-type-binder-definition-source-scope-audit',
    'version':1,'actor':'/root/row_indep_topology_24a6',
    'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'finding':'NO_TYPE_BINDER_DEFINITION_OR_SOURCE_SCOPE_ISSUE_FOUND',
    'genuine_type_source_blockers':[],
    'packet':digest(PACKET),
    'statement_seal_sha256':p['statement_seal_sha256'],
    'producer_signature_sha256':p['producer']['signature_sha256'],
    'consumer_signature_sha256':p['actual_private_consumer']['signature_sha256'],
    'definition_context_sha256':p['minimal_definition_context_sha256'],
    'local_records':[digest(DEST/name) for name in names],
    'prior_raw_freeze':digest(OWN/'raw-freeze.json'),
    'raw_and_R7_originals_preserved':True,
    'new_target_source_graph_seen':False,
    'new_target_implementation_or_proofs_seen':False,
    'target_proof_attempts_or_API_searches':0,
    'topology_applicability_compiled_edge_normal_intake_or_proof_permission_grant':False,
    'unproved_internal_obligations':[
        'Canonical scalar retained-radius integrability despite totalized integral definition.',
        'Actual physical-row law under fixed standard-Gaussian column product and canonical-to-actual expectation transport.',
        'Actual closed-cutoff matrix integrability under synthesized L2Operator structure and literal tensor/scalar first-moment algebra.',
        'Exact deterministic cosine Gram identities and internal finite Bochner integral linearity for actual sums.',
        'Eventual actual material producer/consumer calls and proof applicability checks.'
    ],
    'next_boundary':'Await root-authorized source graph for a separate distinct topology/applicability challenge; no such review has begun.',
}
write('freeze.json',freeze)
records = [digest(DEST/name) for name in names]+[digest(DEST/'freeze.json')]
(DEST/'SHA256SUMS').write_text(''.join(f"{a['sha256']}  {Path(a['path']).name}\n" for a in records))
print(json.dumps({'freeze':digest(DEST/'freeze.json'),'audit':digest(DEST/'audit.md'),
                  'exposure':digest(DEST/'exposure.json'),'finding':freeze['finding'],
                  'prior_raw_and_R7_records_preserved':True},indent=2))
