from pathlib import Path
import hashlib,json,stat
phase=Path(__file__).resolve().parent.parent
base=phase.parent
sha=lambda b:hashlib.sha256(b).hexdigest()
data=(phase/"inputs/selective-fresh-source-phase2-input.json").read_bytes()
assert len(data)==9323 and sha(data)=="92a4b1401ec63ee22409929bd3c6528b1b25bbc822066a3944a8c9f0bbfca173"
p=json.loads(data)
checks=[]
def check_text(label,text,expected):
    actual=sha(text.encode("utf-8"))
    row={"label":label,"utf8_bytes":len(text.encode("utf-8")),"expected_sha256":expected,"actual_sha256":actual,"matches":actual==expected,"normalization":"none"}
    checks.append(row)
    return row
check_text("source.original_text",p["source"]["original_text"],p["source"]["text_sha256"])
check_text("lean.statement",p["lean"]["statement"],p["lean"]["statement_sha256"])
check_text("blind_reconstruction.text",p["blind_reconstruction"]["text"],p["blind_reconstruction"]["text_sha256"])
for d in p["minimal_meaning_carrying_definitions"]:
    if d.get("literal_sha256"):
        check_text("definition."+d["name"],d["literal_definition"],d["literal_sha256"])
    else:
        checks.append({"label":"definition."+d["name"],"utf8_bytes":len(d["literal_definition"].encode("utf-8")),"actual_sha256":sha(d["literal_definition"].encode("utf-8")),"expected_sha256":None,"matches":None,"normalization":"none"})
p1=base/"phase1-source-only"
mbytes=(p1/"MANIFEST.json").read_bytes()
assert sha(mbytes)=="58d9f9f1814eed78bfe5c4c3e3ff0398fc2e3091fba2af905bfb174d0d13ac04"
manifest=json.loads(mbytes)
for rec in manifest["files"]:
    f=p1/rec["path"]
    assert f.stat().st_size==rec["bytes"] and sha(f.read_bytes())==rec["sha256"],rec["path"]
    assert stat.S_IMODE(f.stat().st_mode)==0o444,rec["path"]
assert stat.S_IMODE((p1/"MANIFEST.json").stat().st_mode)==0o444
dirs=[p1]+[x for x in p1.rglob("*") if x.is_dir()]
assert all(stat.S_IMODE(x.stat().st_mode)==0o555 for x in dirs)
rbytes=(base/"phase1-source-only.receipt.json").read_bytes()
assert sha(rbytes)=="e2d9d1c6e19c4da8247a1654c46e0a2972e1b60d0808941483eb7b6526c0b3fa"
assert stat.S_IMODE((base/"phase1-source-only.receipt.json").stat().st_mode)==0o444
check={"input_bytes":len(data),"input_sha256":sha(data),"text_hash_checks":checks,"source_paraphrase_status":"A supplied source contract/paraphrase, compared against own phase1 pinned-raw cognition; not substituted for original paper.","statement_compiled_field":{"value":p["lean"]["compiled"],"status":"supplied metadata only; no independent compile/native verification"},"publication_binding_sha256":{"value":p["publication_binding_sha256"],"status":"supplied reference; full context not read or verified"},"canonical_full_reviewer_packet_sha256":{"value":p["canonical_full_reviewer_packet_sha256"],"status":"supplied reference only; packet not read"},"decoder_provenance":{"actor":p["blind_reconstruction"]["decoder"],"packet_sha256":p["blind_reconstruction"]["decoder_packet_sha256"],"run_sha256":p["blind_reconstruction"]["decoder_run_sha256"],"source_text_visible":p["blind_reconstruction"]["source_text_visible"],"status":"supplied provenance; actual supplied text hashed and compared, not independent access to actor transcript or original anonymous packet"},"private_signature_sha256_computed":sha(p["actual_private_consumer_literal_signature"].encode("utf-8")),"phase1_preservation":{"manifest_sha256":sha(mbytes),"receipt_sha256":sha(rbytes),"payloads_including_manifest":len(manifest["files"])+1,"directories":len(dirs),"all_file_hashes_bytes_unchanged":True,"file_modes":"0444","directory_modes":"0555","receipt_mode":"0444"}}
with (phase/"analysis/input-and-phase1-integrity-v1.json").open("x") as f:json.dump(check,f,ensure_ascii=False,indent=2);f.write("\n")
print(json.dumps(check,ensure_ascii=False,indent=2))
