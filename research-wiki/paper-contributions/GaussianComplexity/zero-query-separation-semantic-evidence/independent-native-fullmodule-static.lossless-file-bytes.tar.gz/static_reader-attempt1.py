from verify import *
import ast, re, html
S=D/'candidate'
# Snapshot the exact production Python import closure at the candidate, never execute a global build.
pending=['tools/astis_site.py','website/scripts/declaration_lessons.py','website/scripts/inline_lean.py','tools/astis_publication.py']; seen=set()
while pending:
 p=pending.pop()
 if p in seen: continue
 seen.add(p); b=gitbytes(p); write('candidate/'+p,b)
 tree=ast.parse(b)
 names=[]
 for n in ast.walk(tree):
  if isinstance(n,ast.Import): names += [x.name.split('.')[0] for x in n.names]
  if isinstance(n,ast.ImportFrom) and n.module: names.append(n.module.split('.')[0])
 for name in names:
  for folder in ['tools','website/scripts']:
   q=folder+'/'+name+'.py'
   if subprocess.run(['git','cat-file','-e',C+':'+q],cwd=R,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode==0: pending.append(q); break
sys.path[:0]=[str(S/'tools'),str(S/'website/scripts')]
import astis_site as base, declaration_lessons as lessons, inline_lean, astis_publication as pub
base._ACTIVE_GIT=base.GitContext(C,C[:12],'','',False,False,set())
modules,decls=base.scan_project_sources(); known={d.full_name:d for d in decls}; base._SOURCE_BY_NAME=known
assert set(m.source_file for m in modules)=={P,T}
unit=json.loads((S/'website/content/declaration_lessons/huanjian-zero-query-separation.json').read_text())['units'][0]
assert len(unit['steps'])==6
steps=[]
for i,s in enumerate(unit['steps'],1):
 code=s['lean']; matches=[]
 for p in [P,T]:
  text=(S/p).read_text(); off=text.find(code)
  if off>=0: matches.append({'file':p,'start_char':off,'end_char_exclusive':off+len(code),'start_line':text.count('\n',0,off)+1})
 assert matches, i
 steps.append({'step':i,'bytes':len(code.encode()),'sha256':sha(code.encode()),'exact_contiguous_matches':matches})
assert unit['steps'][5]['lean'].encode()==(S/T).read_bytes()
page=lessons.lesson_path(unit['declaration']); out=D/'static-output'; out.mkdir(exist_ok=True)
rendered=lessons.render_unit(unit,page)
write('static-output/'+page,base.page(unit['title'],page,rendered))
# Source exporter requires a canonical theme page. This is an explicitly labelled isolated shell fixture,
# produced by the normal page function; it is not an accepted whole-site rendering or screenshot.
theme=base.page('Isolated canonical-theme fixture','textbook/index.html','<p>Static source export fixture.</p>').replace('</head>','<link rel="stylesheet" href="../assets/information-architecture.css"></head>')
write('static-output/textbook/index.html',theme)
lessons.export_sources(out,[unit])
# Exact module download loop is the unchanged production build_site loop at lines3203-3207,
# executed only for the two scanned candidate modules, without invoking build_site.
for module in modules:
 write('static-output/downloads/lean/'+module.source_file,(S/module.source_file).read_bytes())
 write('static-output/modules/'+base.slugify(module.name)+'.html',base.page(module.name,'modules/'+base.slugify(module.name)+'.html',base.render_source_module(module,[])))
assert (out/'downloads/lean'/P).read_bytes()==(S/P).read_bytes()
assert (out/'downloads/lean'/T).read_bytes()==(S/T).read_bytes()
export=(out/'data/lesson-sources'/ (T+'.html')).read_text(); line15=(S/T).read_text().splitlines()[14]
assert '<span id="L15">'+html.escape(line15,quote=True)+'</span>' in export
sourceurl=lessons.source_link(unit['sources'][1],page); assert sourceurl.endswith(T+'.html#L15') and sourceurl in rendered
details=re.findall(r'<details\b[^>]*>',rendered)
assert details and not any(re.search(r'\bopen(?:\s|=|>)',x) for x in details)
sig,proof=inline_lean.split_statement(inline_lean.display_source(known[unit['declaration']].source_text)); assert ':= by' not in sig and proof.startswith(':= by')
assert re.search(r'<details class="inline-lean inline-lean-statement"',rendered) and re.search(r'<details class="inline-lean inline-lean-proof"',rendered)
hrefs=re.findall(r'href="([^"]+)"',rendered)
tlinks=[x for x in hrefs if 'GaussianComplexityZeroQuerySeparation' in x]
step6=rendered.index('6. '+unit['steps'][5]['title']); sourcepos=rendered.index(sourceurl)
js('static-reader.json',{'candidate':C,'scope':'Isolated exact production functions; no browser/pixel/MathJax/desktop/mobile or whole-site acceptance. Canonical-theme shell is a labelled fixture.','production_python_files':sorted(seen),'steps':steps,'all_details_initially_closed':True,'all_T_bytes_in_step6':3551,'T_actual_statement_line':15,'T_source_export_line15_exact':True,'P_T_downloads_exact':True,'P_statement_and_proof_split':True,'concise_formula':unit['formula'],'T_links_from_lesson':tlinks,'T_nearby_download_button_in_step6':False,'source_citation_distance_from_step6_start_chars':sourcepos-step6,'limitation':'Step6 full T code has no adjacent T download/source actions; the T #L15 citation appears in later Sources/dependencies fold. T download file exists in isolated output but lesson direct download actions address P only.'})
# Exact locator checks operate on decoded Unicode positions, raw bytes for file hashes.
mapping=json.loads((S/E/'source-to-lean-map-v1.json').read_text()); assert len(mapping['rows'])==38
checked=[]
for row in mapping['rows']:
 loc=row['lean']; p=loc['file']; b=(R/p).read_bytes() if p.startswith('.lake/') else gitbytes(p); txt=b.decode('utf8'); a=loc['start_character_offset']; z=loc['end_character_offset_exclusive']; block=txt[a:z]
 assert sha(b)==loc['file_sha256'],row['id']; assert sha(block.encode())==loc['exact_locator_block_sha256'],row['id']
 assert txt[a:].startswith(loc['exact_start_marker']),row['id']
 if loc['exact_end_marker_exclusive']: assert txt[z:].startswith(loc['exact_end_marker_exclusive']),row['id']
 assert txt.count('\n',0,a)+1==loc['line'],row['id']
 assert txt.count('\n',0,z-1)+1==loc['end_line'],row['id']
 write('map-excerpts/'+row['id'].replace('/','_')+'.txt',block)
 checked.append({'id':row['id'],'file':p,'bytes':len(b),'raw_file_sha256':sha(b),'decoded_character_start':a,'decoded_character_end_exclusive':z,'block_sha256':sha(block.encode()),'first_line':loc['line'],'last_line':loc['end_line']})
absrow=next(r for r in mapping['rows'] if r['id']=='S-abs_le'); ap=R/absrow['lean']['file']; at=ap.read_text(); a=absrow['lean']['start_character_offset']; assert at[:a].rstrip().endswith('@[to_additive]')
write('definition-context/abs_le-to_additive.txt',at[max(0,a-20):absrow['lean']['end_character_offset_exclusive']])
js('map-validation.json',{'rows':checked,'row_count':len(checked),'Unicode_decoded_offsets':True,'abs_le':'Actual immediately preceding @[to_additive] generates abs_le from existing mabs_le; no ASTIS conversion edge or new theorem.'})
seal=json.loads((S/'research-wiki/paper-contributions/GaussianComplexity/zero-query-separation-statement-seal.json').read_text())
for i,c in enumerate(seal['definition_semantics_audit']):
 b=(R/c['file']).read_bytes(); assert sha(b)==c['whole_file_sha256']; write('definition-context/'+c['name']+'.txt','\n'.join(b.decode().splitlines()[c['first_line']-1:c['last_line_inclusive']])+'\n')
fake=[]
for p in [P,T]:
 clean=base.sanitize_lean((S/p).read_text()); tokens=re.findall(r'\b(?:sorry|admit|axiom|unsafe)\b|Prop\s*:=\s*True|:=\s*trivial\b',clean); fake += [{'file':p,'tokens':tokens}]; assert not tokens
js('focused-fake-closure.json',fake)
# Bounded normal publication metadata validation is explicitly unreviewed: strict_names=None.
item=json.loads((S/'website/content/publications/huanjian-zero-query-separation.json').read_text())['items'][0]
cellpath='research-wiki/frontier-cells/'+item['bindings'][0]['cell']+'.json'; write('candidate/'+cellpath,gitbytes(cellpath)); cell=json.loads((S/cellpath).read_text())
audit=json.loads((S/'research-wiki/semantic-roundtrip/audits/huanjian-zero-query-separation.json').read_text())
data={'declarations':known,'lessons':{unit['declaration']:unit},'cells':{cell['cell_id']:cell},'audits':{audit['id']:audit}}
errors=pub.validate(items=[item],data=data,strict_names=None)
js('bounded-publication-reviewed-false.json',{'function':'astis_publication.validate(items=[exact candidate item], data=exact scoped objects, strict_names=None)','reviewed':False,'errors':errors,'computed_publication_binding_sha256':pub.binding_digest(item,item['bindings'][0],data),'source_review_state_observed':audit['source_review']['state'],'scope':'Bounded metadata/source/exposition binding validation. Does not invoke global check_advance or global semantic registry; no source review acceptance.'})
assert not errors,errors
print('STATIC_READER_AND_38_MAP_ROWS_PASS; bounded publication reviewed=False PASS; T link adjacency limitation recorded')
