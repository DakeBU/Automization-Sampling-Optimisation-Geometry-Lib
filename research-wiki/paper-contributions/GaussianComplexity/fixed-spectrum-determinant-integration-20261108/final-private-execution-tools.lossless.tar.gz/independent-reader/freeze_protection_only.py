"""Freeze the actually executed, explicitly authorized protection-only readback."""
from pathlib import Path
import datetime, gzip, hashlib, json
R=Path('/Users/zhouhuanjian/ASTIS-GC')
O=R/'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-determinant-integration-20261108/independent-integration-reader-review/postcore-protection-readback'
report=O/'postcore-readback.json'
receipt=R/'.astis/huanjian-resume-20261103/20261108T032209974527Z-fixed-spectrum-determinant-independent-protection-only.receipt.json'
authorization=R/'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-determinant-integration-20261108/postcore-protection-context.json'
sha=lambda b:hashlib.sha256(b).hexdigest()
assert sha(report.read_bytes())=='2ecf798b66693f848d3e6020a4eb3b42f7d9e66698ed94132ea06af588dc730c'
assert sha(authorization.read_bytes())=='baed7cb87125b29326d4a33a142a9116a363de631addeafd24872f01df5239ec'
value=json.loads(report.read_bytes());actual=json.loads(receipt.read_bytes());log=Path(actual['log'])
core='39798cba03364fea6587c4cb8c8e55eb320d5b42'
assert value['state']=='POSTCORE_READBACK_PASS_NOT_LOCAL_SITE_ACCEPTANCE' and value['readback_phase']=='protection-only'
assert value['actual_Lean_site_browser_checks_claimed'] is False and value['actual_original_images_viewed_by_this_helper']==0
assert value['new_source_verdict'] is False and value['parking_authorized_or_executed'] is False
assert actual['exit_code']==0 and actual['head_before']==actual['head_after']==core
assert sha(log.read_bytes())==actual['log_sha256']=='323a5eb268ba977818de4449a9cce51f459014c98a866a678185e47df90beb11'
assert value['sourceV_lineage']['actual_original_source_verifier']=='/root/reader_835194'
assert value['sourceV_lineage']['proof_owner']=='huanjian_gc_20261108_fixed_spectrum_determinant'
assert value['protection']['foreign_advances']==282 and value['protection']['foreign_frontiers']==441
rows=[]
for name,path in [('postcore-readback.json.raw.gz',report),('actual-command.receipt.json.raw.gz',receipt),('actual-command.stdout.raw.gz',log),('authorization.json.raw.gz',authorization),('freeze-driver.py.raw.gz',Path(__file__))]:
 raw=path.read_bytes();archive=gzip.compress(raw,mtime=0);dest=O/name
 assert not dest.exists();dest.write_bytes(archive);assert gzip.decompress(dest.read_bytes())==raw
 rows.append({'original':str(path.relative_to(R)),'raw_sha256':sha(raw),'raw_bytes':len(raw),'archive':str(dest.relative_to(R)),'archive_sha256':sha(archive)})
freeze={'reviewer':'/root/det_integration_reader','recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'phase':'Actual explicitly authorized protection-only execution; no local acceptance','immutable_core':core,'authorization_raw_sha256':sha(authorization.read_bytes()),'report_raw_sha256':sha(report.read_bytes()),'actual_receipt_raw_sha256':sha(receipt.read_bytes()),'actual_command':actual['command'],'actual_started_utc':actual['started_utc'],'actual_exit_code':actual['exit_code'],'actual_elapsed_seconds':actual['elapsed_seconds'],'raw_log_sha256':sha(log.read_bytes()),'lossless_archives':rows,'actual_new_source_verdicts':0,'actual_lifecycle_API_calls':0,'actual_build_site_browser_actions':0,'actual_original_image_views':0,'local_acceptance_or_parking':False,'scope':'Unique original independent sourceV and its exact checked/accepted/firstV Git lineage; current sole STAB, exact6sharedpayloads,282foreignstates,441foreignfrontiers,all7432protectedforeigncontents,olderGC,README,othercasevalues/Section4.4suffix/bothmodels and Atlas directory stat only. Genuine source_API receipt is reused unchanged, never repeated. Official gate/site/browser remain separately pending.','stopped_after_freeze':True}
dest=O/'freeze.json';assert not dest.exists();dest.write_text(json.dumps(freeze,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'state':value['state'],'phase':value['readback_phase'],'report_sha256':sha(report.read_bytes()),'actual_receipt_sha256':sha(receipt.read_bytes()),'freeze_sha256':sha(dest.read_bytes()),'exit_code':actual['exit_code'],'elapsed_seconds':actual['elapsed_seconds'],'raw_log_sha256':sha(log.read_bytes()),'new_source_verdicts_or_API_build_site_browser_actions':0},indent=2))
