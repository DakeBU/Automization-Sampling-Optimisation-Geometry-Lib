from pathlib import Path
import hashlib,json
W=Path('.astis/huanjian-gc-fixed-spectrum-grid-alias-20261109')
def ref(p):
 b=p.read_bytes(); return {'path':str(p),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
s=json.loads((W/'statement-seal-v1.json').read_text())
s['seal_id']='GC-FIXED-SPECTRUM-GRID-ALIAS-20261109-v2'
s['predecessor']=ref(W/'statement-seal-v1.json')
s['preformation_correction']={
 'classification':'IMPLEMENTATION_FAILED',
 'reason':'Lean reserves alias as a command token. Alpha-rename the consumer local coefficient to a; no mathematical/binder/body change.',
 'failed_receipt':ref(Path('.astis/huanjian-resume-20261103/20261109T131539506364Z-grid-alias-exact-signature-type-formation-v1.receipt.json')),
 'no_target_proof_or_admission_occurred':True}
c=s['actual_private_consumer']['signature'].replace('let alias :','let a :').replace('alias (','a (')
s['actual_private_consumer']['signature']=c
s['actual_private_consumer']['signature_sha256']=hashlib.sha256(c.encode()).hexdigest()
(W/'consumer-signature-v2.txt').write_text(c)
(W/'producer-signature-v2.txt').write_text(s['producer']['signature'])
formation=(W/'ExactStatementFormation.lean').read_text().replace('let alias :','let a :').replace('alias (','a (')
(W/'ExactStatementFormationV2.lean').write_text(formation)
(W/'statement-seal-v2.json').write_text(json.dumps(s,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'seal':ref(W/'statement-seal-v2.json'),'formation':ref(W/'ExactStatementFormationV2.lean')},ensure_ascii=False))
