from pathlib import Path
import json, hashlib, datetime
out=Path(__file__).resolve().parent
base=out.parent
src=(base/'raw/inputs/2610.20492v1.html').read_bytes()
st=src.decode()
g=json.loads((out/'SOURCE-GRAPH.v3.json').read_text())
c=json.loads((out/'SOURCE-COVERAGE.v3.json').read_text())
ports=json.loads((out/'INTERNAL-PORTS.v2.json').read_text())
manifest=json.loads((out/'FINAL-MANIFEST.v1.json').read_text())
ownblocks=json.loads((base/'raw/source-blocks.json').read_text())
errors=[]
counts={}
def check(a,group,owner):
    counts[group]=counts.get(group,0)+1
    bs=src[a['byte_start']:a['byte_end_exclusive']]
    cs=st[a['char_start']:a['char_end_exclusive']].encode()
    if bs != cs or hashlib.sha256(bs).hexdigest() != a['raw_sha256']:
        errors.append({'group':group,'owner':owner,'kind':'byte-char-hash'})
    if 'line_start_1based' in a:
        start=st[:a['char_start']].count('\n')+1
        end=st[:a['char_end_exclusive']-1].count('\n')+1
        if start != a['line_start_1based'] or end != a['line_end_1based']:
            errors.append({'group':group,'owner':owner,'kind':'line','computed':[start,end],'stored':[a['line_start_1based'],a['line_end_1based']]})
for n in g['nodes']:
    for a in n.get('source_anchors',[]):
        check(a,'node_anchor',n['id'])
for e in g['edges']:
    for a in e.get('consumer_use_sites',[]):
        check(a,'edge_use_site',e['id'])
for key in ['blocks','mixed_fragments','display_components']:
    for a in c[key]:
        check(a,key,a.get('id',a.get('source_id')))
expected={(x['line'],x['tag']) for x in ownblocks if 3315 <= x['line'] < 3835}
actual={(x['line_start_1based'],x['tag']) for x in c['blocks'] if 3315 <= x['line_start_1based'] < 3835}
missing=sorted(expected-actual)
extra=sorted(actual-expected)
ids={n['id'] for n in g['nodes']}
edge_errors=[]
for e in g['edges']:
    for node in e['parents']+[e['consumer']]:
        if node not in ids:
            edge_errors.append({'edge':e['id'],'missing_node':node})
parents={n:[] for n in ids}
for e in g['edges']:
    parents[e['consumer']]+=e['parents']
def closure(n,stack=()):
    if n in stack:
        raise AssertionError('cycle '+str(stack+(n,)))
    result={n}
    for p in parents[n]:
        result |= closure(p,stack+(n,))
    return result
roots={n:sorted(closure(n)) for n in ['P-Ex125','T-Ex126-deterministic']}
for key,f in [('source_graph_sha256','SOURCE-GRAPH.v3.json'),('source_coverage_sha256','SOURCE-COVERAGE.v3.json')]:
    assert ports[key] == hashlib.sha256((out/f).read_bytes()).hexdigest()
# Check only current admitted input entries; do not open any other listed files.
print('manifest_keys',list(manifest))
print('manifest current entries', {k:v for k,v in manifest.items() if k != 'files'})
if isinstance(manifest.get('files'),dict):
    for f in ['SOURCE-GRAPH.v3.json','SOURCE-COVERAGE.v3.json','BINDER-DEFINITION-AUDIT.v1.json','INTERNAL-PORTS.v2.json']:
        assert manifest['files'][f] == hashlib.sha256((out/f).read_bytes()).hexdigest()
check_out={'version':'independent-original-locator-and-closure-check-v1','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_sha256':hashlib.sha256(src).hexdigest(),'locator_counts':counts,'locator_errors':errors,'C2_all_block_comparison':{'expected_blocks':len(expected),'coverage_blocks':len(actual),'missing':missing,'unexpected':extra},'node_count':len(g['nodes']),'edge_count':len(g['edges']),'source_gap_count':sum(n['kind'].startswith('SOURCE_GAP') for n in g['nodes']),'edge_reference_errors':edge_errors,'root_closures':roots,'port_graph_and_coverage_bindings_recomputed':True}
(out/'independent-locator-closure-check.v1.json').write_text(json.dumps(check_out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(check_out,indent=2))
