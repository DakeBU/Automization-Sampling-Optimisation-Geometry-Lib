from pathlib import Path
import hashlib,json,stat
base=Path(__file__).resolve().parent
source=(base/'inputs/2610.20492v1.html').read_bytes()
assert hashlib.sha256(source).hexdigest()=='6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
supplied=json.loads((base/'input-manifest.json').read_bytes())
for name,expected in supplied.items():
    b=(base/'inputs'/name).read_bytes()
    assert len(b)==expected['bytes'] and hashlib.sha256(b).hexdigest()==expected['sha256'],name
anchors=json.loads((base/'anchors.json').read_bytes())['anchors']
text=source.decode('utf-8')
for a in anchors:
    b=source[a['byte_start_0']:a['byte_end_0_exclusive']]
    assert b==text[a['char_start_0']:a['char_end_0_exclusive']].encode('utf-8'),a['source_id']
    assert hashlib.sha256(b).hexdigest()==a['sha256'],a['source_id']
    assert source[:a['byte_start_0']].count(b'\n')+1==a['lf_start_line_1'],a['source_id']
coverage=json.loads((base/'coverage.json').read_bytes())
assert all(i['disposition'] in ('NODE','EXCLUDED') and i['reason'] for i in coverage['items'])
entries=[]
for p in sorted(base.rglob('*')):
    if p.is_file():
        assert p.name!='frozen-manifest.json','Refuse to overwrite an existing freeze'
        b=p.read_bytes()
        entries.append({'path':str(p.relative_to(base)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'frozen_mode':'0444'})
manifest={'kind':'Independent raw-source phase-1 mathematical freeze','source_sha256':hashlib.sha256(source).hexdigest(),'target_types_exposed':False,'other_author_graph_exposed':False,'no_lean_or_api_search':True,'input_normalization':'none; original supplied bytes retained','files':entries,'manifest_self_hash':'Deliberately omitted to avoid recursive self-hashing; exact manifest hash is printed in actual freeze result and bound by external freeze execution receipt.','directory_mode':'0555','receipt_boundary':'execution-receipt-all-pre-freeze.json retains actual prior shell inputs/results including failed lookup; final freeze command/result is captured in sibling phase1-freeze-execution-receipt.json.'}
(base/'frozen-manifest.json').write_bytes((json.dumps(manifest,indent=2)+'\n').encode())
for p in base.rglob('*'):
    if p.is_file():p.chmod(0o444)
for p in sorted((p for p in base.rglob('*') if p.is_dir()),key=lambda p:len(p.parts),reverse=True):p.chmod(0o555)
base.chmod(0o555)
files=[p for p in base.rglob('*') if p.is_file()]
dirs=[base]+[p for p in base.rglob('*') if p.is_dir()]
assert all(stat.S_IMODE(p.stat().st_mode)==0o444 for p in files)
assert all(stat.S_IMODE(p.stat().st_mode)==0o555 for p in dirs)
print('FROZEN_FILES',len(files),'FROZEN_DIRS',len(dirs),'ANCHORS',len(anchors),'COVERAGE_ITEMS',len(coverage['items']))
for n in ('inputs/2610.20492v1.html','independent-math-freeze.md','coverage.json','anchors.json','exposure-inventory.json','execution-receipt-all-pre-freeze.json','frozen-manifest.json'):
    b=(base/n).read_bytes()
    print('FROZEN_SHA256',n,hashlib.sha256(b).hexdigest(),'BYTES',len(b))
print('INPUT_BYTES_UNCHANGED',len(supplied),'FILE_MODES_0444',len(files),'DIR_MODES_0555',len(dirs),'EXIT_STATUS_EXPECTED',0)

