from pathlib import Path
from html import unescape
import hashlib, json, stat

OWN = Path(__file__).resolve().parent
BASE = OWN.parents[1]
AUTHOR = BASE / 'z_sg_7d14a2_scope_label_successor'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def pinned(path, digest, size=None):
    data = path.read_bytes()
    assert sha(data) == digest, path
    assert size is None or len(data) == size, path
    assert stat.S_IMODE(path.stat().st_mode) == 0o444, path
    return data

manifest_bytes = pinned(AUTHOR/'successor-manifest.json', '4d8b303ff7d687850edcea33b4d1a3cd884952634f0362ccb40e3535ccf2fb5a')
receipt_bytes = pinned(AUTHOR/'successor-receipt.json', '192171a75db1b579ef47c4f528de72783d31eb09369f6dda758f572e3b839242')
manifest = json.loads(manifest_bytes)
for item in manifest['payloads']:
    pinned(AUTHOR/item['file'], item['sha256'], item['bytes'])

old = pinned(AUTHOR/'original-root-closure-map.json', 'dcbc5fef1a4a047ad71db98f6810b6475dafc474414a88fc77ccb63ed7862d8a', 4948)
new = pinned(AUTHOR/'corrected-root-closure-map.json', 'e6d1ad7e661fb6aeec27a08eb04d3f5018c67c283f42f53dd22bd0fd72147118', 4961)
assert old == (BASE/'z_sg_7d14a2/root-closure-map.json').read_bytes()
assert old == (OWN.parent/'phase2b/inputs/z_sg_7d14a2/root-closure-map.json').read_bytes()

differences = []
same_scalars = []
containers = []

def pointer_part(value):
    return str(value).replace('~', '~0').replace('/', '~1')

def compare(a, b, pointer=''):
    assert type(a) is type(b), pointer
    if isinstance(a, dict):
        assert list(a) == list(b), pointer
        containers.append({'pointer':pointer, 'kind':'object', 'ordered_keys':list(a), 'preserved':True})
        for key in a:
            compare(a[key], b[key], pointer+'/'+pointer_part(key))
    elif isinstance(a, list):
        assert len(a) == len(b), pointer
        containers.append({'pointer':pointer, 'kind':'array', 'length':len(a), 'preserved':True})
        for index, (x, y) in enumerate(zip(a, b)):
            compare(x, y, pointer+'/'+str(index))
    elif a != b:
        differences.append({'pointer':pointer, 'old':a, 'new':b})
    else:
        same_scalars.append({'pointer':pointer, 'value':a})

compare(json.loads(old), json.loads(new))
assert len(differences) == 1
delta = differences[0]
assert delta['pointer'] == '/roots/2/conditional_scope'
assert delta['old'] == 'Unconditional within H:ranges, H:fixed-budget, and H:uniform-accuracy where applicable'
assert delta['new'] == 'Conditional on 2T + 1 > d, within H:ranges, H:fixed-budget, and H:uniform-accuracy where applicable'
first_difference = next(i for i,(a,b) in enumerate(zip(old,new)) if a != b)
old_value = delta['old'].encode()
new_value = delta['new'].encode()
end = first_difference + len(old_value)
assert old[first_difference:end] == old_value
assert new == old[:first_difference]+new_value+old[end:]

original_source = (BASE.parent/'huanjian-resume-20261103/2610.20492v1.html').read_bytes()
assert sha(original_source) == '6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
anchor = pinned(AUTHOR/'source-anchor-raw.html', '765c6cfbe19f86588fe24a8e941b1f42f27b6a236ec754228102372d36f5465d', 1361)
assert anchor == original_source[176161:177522]
assert 'alttext="2T+1>d"' in unescape(anchor.decode())
assert json.loads(old)['roots'][2]['root'] == 'L:large-branch-conclusion'
assert json.loads(old)['roots'][2]['statement'] == json.loads(new)['roots'][2]['statement']

prior_receipts = {
    'phase1':'e8cfa26b72ce8b0ecd2867b5c785de39a0fc3ab8f8da82d2afd0fb415fb40eed',
    'phase2a':'d1ebfedc5a9939a239ccc9ccfb5c5ba7d766c934f3669cebe2a6fb9ad7fcc5ed',
    'phase2b':'f2033ffdae1308a6d4c22395aa55d89e86f727d0ff8e218a212894ea9aab9b40'
}
for phase, digest in prior_receipts.items():
    folder = OWN.parent/phase
    saved_receipt = json.loads(pinned(folder/'receipt.json', digest))
    pinned(folder/'manifest.json', saved_receipt['manifest']['sha256'], saved_receipt['manifest']['bytes'])
    for item in json.loads((folder/'manifest.json').read_bytes())['files']:
        pinned(folder/item['path'], item['sha256'], item['bytes'])

for folder, manifest_name, digest in [
    ('z_sg_7d14a2','phase1-manifest.json','c6139e1da52ec5caaaa7d7aaa091a54a37c2f22fbcec1e028924de0d600267af'),
    ('z_sg_7d14a2_phase2','phase2-manifest.json','6ae4fe9f4777cc37e0afe6bc262ac5b7885c3bc83ebb69d077c9882a0fbe67f4')
]:
    pinned(BASE/folder/manifest_name, digest)
    for item in json.loads((BASE/folder/manifest_name).read_bytes())['payloads']:
        pinned(BASE/folder/item['file'], item['sha256'], item['bytes'])

pinned(BASE/'z_sg_7d14a2/phase1-receipt.json','83255eeb8220e5aa641e8d9e081cb6550f100726851a32a366d64562d7b4c1d0')
pinned(BASE/'z_sg_7d14a2_phase2/phase2-receipt.json','b354d131bd2b43d18288206bf33b8ea21282fb4e5f253c109c42f517af6f5593')

used = ['successor-manifest.json','successor-receipt.json','handoff-for-independent-delta-review.md','original-root-closure-map.json','corrected-root-closure-map.json','exact-json-delta.json','source-anchor-raw.html','source-anchor-receipt.json','value-preservation-report.json','exposure-ledger.json']
(OWN/'inputs').mkdir(exist_ok=True)
for name in used:
    (OWN/'inputs'/name).write_bytes((AUTHOR/name).read_bytes())

result = {
    'schema':'independently-recomputed-one-label-delta-v1',
    'actor':'/root/zeroquery_topology_38cf91',
    'old_sha256':sha(old), 'new_sha256':sha(new),
    'differences':differences,
    'unchanged_scalar_count_independently_computed':len(same_scalars),
    'changed_scalar_count_independently_computed':len(differences),
    'container_count_independently_computed':len(containers),
    'all_container_shapes_ordered_keys_array_order_preserved':True,
    'unchanged_scalars':same_scalars,
    'containers':containers,
    'byte_delta':{'original_start_inclusive':first_difference,'original_end_exclusive':end,'old_string_bytes':len(old_value),'new_string_bytes':len(new_value),'outside_bytes_identical':True},
    'raw_source_anchor_exactly_matches_pinned_original_range':[176161,177522],
    'own_prior_freezes_unchanged':True,
    'source_author_original_phase1_and_phase2_payloads_unchanged':True,
    'verdict':'ACCEPT_METADATA_SCOPE_LABEL_CLARIFICATION_ONLY',
    'mathematical_HOLD':'none before or after; original phase2b qualified acceptance remains unmodified',
    'no_new_source_assumption_or_mathematical_repair':True,
    'no_graph_type_or_proof_permission_change':True
}
(OWN/'delta-check.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({key:result[key] for key in ['verdict','differences','unchanged_scalar_count_independently_computed','changed_scalar_count_independently_computed','container_count_independently_computed','byte_delta','own_prior_freezes_unchanged']},indent=2))
