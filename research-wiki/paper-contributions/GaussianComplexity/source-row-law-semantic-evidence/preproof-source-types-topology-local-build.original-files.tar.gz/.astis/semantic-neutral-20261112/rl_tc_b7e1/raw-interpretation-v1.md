# Raw-source interpretation freeze v1

Role: independent raw-source/topology challenger. Root remains sole prover.
Stage: RAW_SOURCE_ONLY. No proposed Lean type, implementation, supplied Source
Proof Graph, decoder output, prior source/semantic verdict, packet history,
ledger, ATLAS content or canonical publication record has been read. This file
records mathematical interpretation only; it grants no proof or publication
acceptance.

## Pinned source and exact bounded scope

Pinned HTML: `.astis/huanjian-resume-20261103/2610.20492v1.html`, 951991 bytes,
SHA-256 `6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915`.
Exact UTF-8 byte ranges and individual excerpt hashes are in
`raw-source-locators.json`; literal extracted HTML is preserved alongside this
reading. The evidence is the raw HTML, with MathML `alttext` used only for
readable transcription.

The source title is *On Complexity of Gaussian Sampling*. The input experiment
is explicit in Lemma 4.4 (`S4.Thmtheorem4.p1.1`, raw line 1210). Appendix C.2
starts at raw line 3314; its p1 gives the row construction and row-law assertion,
and p10-p11 give the cutoff, tail, union statement, and tail-moment integral.

## Standing range versus this small mathematical boundary

The Section 4.1 construction has integer dimension d >= 2 and kappa >= 2
(`S4.SS1.p1.1`, raw line 1086). Lemma 4.4 has nonnegative query budget q with
2q+1 < d (`S4.Thmtheorem4.p1.1`, raw line 1210). The integer nature of q is the
query-budget/degree indexing convention and is explicit in the adjacent Lemma
4.3 statement (`S4.Thmtheorem3.p1.1`, raw line 1164), which was also directly
read. Appendix C.2 sets r=q+1 and n=2q+1, so r >= 1. The q=0 endpoint is
included and then r=1, n=1, d>=2. All row indices are 1 <= i <= d and column
indices 1 <= a <= r.

Lemma 4.4 additionally conditions its final uniform Krylov estimate on
 tau_(d,q) <= 1/2. That condition, the sufficiently large absolute C of Fact
C.6, n, kappa, the cosine grid, and deterministic t_i have no role in the row
marginal or finite bad-row union argument. A separately declared elementary
row-law/union result can mathematically generalize to arbitrary finite d>=1,
r>=1, but d>=1 must be described as a generalization rather than the exact
Section 4 standing range. No tau hypothesis should be promoted to a premise
of the narrow row-law/union result merely because it appears in Lemma 4.4.

## Original experiment and narrow producer

The original experiment is a single probability law P carrying jointly
independent random columns g_1,...,g_r, each in R^d with standard Gaussian
law N(0,I_d). The row is the actual random vector

    gamma_i(omega) = ((g_1(omega))_i,...,(g_r(omega))_i) in R^r.

This is Appendix C.2 `A3.Ex85`, raw line 3319. The next paragraph
`A3.SS2.p1.2`, raw line 3326, explicitly asserts that gamma_1,...,gamma_d are
independent N(0,I_r). The bounded producer under examination is only the
marginal part: for each original row i, the law of this gamma_i under P is the
canonical standard r-dimensional Gaussian probability measure N(0,I_r).

SOURCE-SUPPORTED UNNUMBERED INFERENCE: coordinate i of a standard d-dimensional
Gaussian is scalar N(0,1); projecting the independent columns preserves their
independence; hence the r coordinates of a fixed gamma_i are independent scalar
N(0,1), giving its standard r-dimensional Gaussian law. Appendix C.2 asserts
the result rather than supplying a numbered proof of this projection/product
law step. This is not an additional named theorem in the paper.

The original column assumptions also imply full joint independence of all
rows (and the source explicitly says so). That stronger conclusion is separate
from the narrow producer. Marginal identities by themselves do NOT imply joint
independence. This audit does not count the independence clause of p1 as
discharged by a theorem that proves only each marginal law.

## Exact tail and actual intended finite consumer

Define on the same original experiment

    R_i = ||gamma_i||^2 = sum_(a=1)^r ((g_a)_i)^2,
    L = 2r + 3 log(1000d).

The norm is the Euclidean norm; L uses natural logarithm, with the source's
multiplicative 1000*d inside log. These are `A3.SS2.p10.1`, raw line 3533.
The source states E exp(R_i/3)=3^(r/2). Its Markov argument is, for every real
x>=0,

    P(R_i > 2r+3x)
      <= exp((r/2) log 3 - 2r/3 - x)
      <= exp(-x),

using (log 3)/2 < 2/3 (`A3.Ex104`, raw line 3538, and p10.2 at line 3545).
The bad tail is STRICT >; its complement uses <=. Equality at the cutoff is
part of the good event, and x=0 is included.

SOURCE-SUPPORTED UNNUMBERED INFERENCE: substitute x=log(1000d), which is
nonnegative on the source range, to obtain for each actual original row

    P({omega : R_i(omega) > L}) <= 1/(1000d).

The source then defines

    T = {omega : R_i(omega) <= L for every i=1,...,d}

(`A3.Ex105`, raw line 3547) and states P(T)>=0.999 (`A3.SS2.p10.3`, raw line
3554). Its literal intended complementary consumer is therefore

    P(union_(i=1)^d {omega : R_i(omega) > L})
      <= sum_(i=1)^d P(R_i > L)
      <= d/(1000d) = 1/1000.

SOURCE-SUPPORTED UNNUMBERED INFERENCE: finite union bound and event complement
are the unnamed bridge behind the source word “Consequently.” Row independence
is NOT required for this bridge. All events must be events of the same actual
original column experiment, with the actual row maps above. The source does
not state this complementary event as a separately numbered theorem.

The row-law identity can transport the canonical standard-r Gaussian tail to
each actual row probability. A computation solely under a separately introduced
standard-r Gaussian law is not yet the intended original-experiment consumer
unless the law equality/pushforward transport is supplied. A list of unrelated
marginal integrals also has no original finite union event until those marginals
are tied to row maps on the same original experiment. Conversely, once each
actual row event has its tail bound on P, no joint-independence theorem is
needed for this finite union step.

## p11 endpoint and retained boundary

For every s>=0 the same source tail gives

    P(R_i > L+s) <= exp(-s/3)/(1000d).

This is `A3.SS2.p11.1`, raw line 3558, by x=log(1000d)+s/3. The integral at
`A3.EGx10`, raw lines 3561-3569, is

    E[R_i * 1_{R_i>L}]
      = L P(R_i>L) + integral_(s=0)^infinity P(R_i>L+s) ds
      <= (L+3)/(1000d).

The endpoint s=0 is allowed; the indicator is strict R_i>L. This is a
nonnegative scalar tail integral for one row, not an integral defining a joint
row law. It is available as a later distinct use of the marginal tail; it is
not required merely to bound the event that any row crosses L.

The inspected p2-p9 cosine, expectation, range, and Fact C.6 concentration
material supplies context but is excluded from this bounded delta because its
conclusions are not needed for the row marginal or finite union event. Joint
row independence, truncated matrix independence, matrix concentration, the
whole of Fact C.6, full Lemma 4.4, main lower-bound theorem, oracle/coupling,
and query-cost statements remain separate and unapproved by this reading.

## Freeze discipline

This raw interpretation was completed before any proposed Lean types or
supplied graph were visible. Await exact selective type input next. A later
type-only judgment must be frozen before a supplied SG graph is inspected.
Any subsequent source correction creates a versioned successor; do not edit
this frozen reading silently.
