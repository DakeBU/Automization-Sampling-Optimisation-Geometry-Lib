"""Readback only: never call proposal/transition APIs or infer success."""
from pathlib import Path
import hashlib,json,subprocess,sys
sys.dont_write_bytecode=True
sys.path.insert(0,'tools')
import astis_advance as adv
W=Path(__file__).resolve().parent.relative_to(Path.cwd())
E=Path('research-wiki/paper-contributions/GaussianComplexity/radial-exponential-semantic-evidence')
C=Path('research-wiki/frontier-cells/ASTIS-SHARED-std-gaussian-radial-exponential.json')
L=Path('runs/substantive_advances.jsonl')
ADV='ASTIS-SA-20261110-StdGaussianRadialExponential';OWNER='huanjian_gc_20261110_std_gaussian_radial_exponential'
sha=lambda b:hashlib.sha256(b).hexdigest()
rp=Path(sys.argv[1]);admission_digest=sys.argv[2]
r=json.loads(rp.read_bytes())
assert r['exit_code']==0 and sha(Path(r['log']).read_bytes())==r['log_sha256']
assert str(W/'admit_normal_intake_after_topology.py') in r['command'] and admission_digest in r['command']
pre=json.loads((W/'admission-preservation-baseline.private.json').read_bytes())
control=json.loads((W/'intake-baseline.private.json').read_bytes())
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==pre['head']==r['head_before']==r['head_after']
now=L.read_bytes();old=now[:pre['ledger_bytes']];app=now[len(old):]
assert sha(old)==pre['ledger_sha256']
assert app==(E/'normal-EXPLORING-append.exact.jsonl').read_bytes()
assert sha(app)==json.loads((E/'normal-intake-preservation.json').read_bytes())['append_sha256']
rows=[json.loads(z) for z in app.splitlines()]
assert len(rows)==3 and all(z['advance_id']==ADV for z in rows)
assert [(z['event'],z.get('state',z.get('to_state'))) for z in rows]==[('proposal','PROPOSED'),('transition','CLAIMED'),('transition','EXPLORING')]
assert rows[0]['created_by']==OWNER and all(z['worker_id']==OWNER for z in rows[1:])
states=adv._replay_advances([json.loads(z) for z in now.splitlines()])
assert states[ADV]['state']=='EXPLORING' and states[ADV]['owner_id']==OWNER
assert {a:x for a,x in states.items() if a!=ADV}==pre['all_foreign_states']
for p,h in pre['all_tracked_regular_file_hashes'].items():
    if p!=str(L):assert sha(Path(p).read_bytes())==h,p
for p,h in pre['all_existing_frontier_hashes'].items():assert sha(Path(p).read_bytes())==h,p
for p,h in control['foreign_control_hashes'].items():assert sha(Path(p).read_bytes())==h,p
c=json.loads(C.read_bytes());assert c['owner_id']==OWNER and c['status']=='claimed'
assert c['statement_seal']['sha256']=='0cd51a158ffacbf0c4cd7677d78cb61c5be7d8a428fbf5dd01581ff99545f3fb'
assert c['truth_boundary']==states[ADV]['truth_boundary']
assert c['evidence']['preproof_source_admission']['sha256']==admission_digest==sha((E/'preproof-source-admission.json').read_bytes())
assert not c['learning_contract']['reader_backpressure']['assumptions_preserved']
for p in ['AutoSamplingTheory/TechnicalLemmas/Probability/StdGaussianRadialExponential.lean','Tests/GaussianComplexityRadialExponential.lean',str(W/'StatementFormation.lean')]:assert not Path(p).exists(),p
assert (W/'normal-intake-attempted.once.json').is_file()
out={'actual_state':'EXPLORING','root_actual_readback_after_real_intake_and_all_postguards':True,'normal_API_calls_completed_once':3,'actual_append_sha256':sha(app),'actual_intake_receipt_sha256':sha(rp.read_bytes()),'actual_intake_log_sha256':r['log_sha256'],'foreign_states_preserved':len(pre['all_foreign_states']),'old_frontiers_preserved':len(pre['all_existing_frontier_hashes']),'tracked_regular_files_preserved_except_ledger':len(pre['all_tracked_regular_file_hashes'])-1,'foreign_controls_preserved':len(control['foreign_control_hashes']),'target_formal_proof_API_may_begin_only_NOW':True,'target_proof_or_sourceV_or_global_credit':False,'same_goal_original_global_lease_and_all13_prior_sourceV_values_preserved':True}
with (W/'root-confirmed-actual-intake-success.json').open('x') as f:json.dump(out,f,indent=2);f.write('\n')
print(json.dumps(out))
