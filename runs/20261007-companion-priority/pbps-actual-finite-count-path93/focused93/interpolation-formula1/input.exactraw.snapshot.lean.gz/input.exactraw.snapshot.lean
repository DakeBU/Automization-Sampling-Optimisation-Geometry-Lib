import AutoSamplingTheory.ExampleCases.ProximalBPS.ActualOrderedPrefix
import AutoSamplingTheory.ExampleCases.ProximalBPS.ActualConditionalNextWaitSurvival
import AutoSamplingTheory.ExampleCases.ProximalBPS.ActualPhysicalTimeMeasurability

/-! Internal proof ingredients for the sealed candidate93, not a public result.
The set-law premise below will be filled by the actual survival theorem88.
No premise is added to the sealed source-facing statement. -/
namespace PathInterfaces93
open InnerProductSpace MeasureTheory ProbabilityTheory
open scoped ContDiff NNReal ENNReal Topology Interval
noncomputable section
set_option autoImplicit false

private theorem measurable_finite_fold {X Y : Type*}
    [MeasurableSpace X] [MeasurableSpace Y] (n : ℕ)
    (f : X → Y → Fin n → X)
    (hf : ∀ j, Measurable (fun p : X × Y => f p.1 p.2 j))
    (x : Y → X) (hx : Measurable x) :
    Measurable (fun y => Fin.foldl n (fun z j => f z y j) (x y)) := by
  induction n with
  | zero => simpa only [Fin.foldl_zero] using hx
  | succ n ih =>
    have hr := ih (fun z y j => f z y j.castSucc) (fun j => hf j.castSucc)
    simpa only [Fin.foldl_succ_last, Function.comp_def, id_eq] using
      (hf (Fin.last n)).comp (hr.prodMk measurable_id)

private theorem survival_history_measure {Ω H : Type*}
    [MeasurableSpace Ω] [MeasurableSpace H]
    (μ : Measure Ω) (history : Ω → H) (S : Set Ω) (weight : H → ℝ≥0∞)
    (hh : Measurable history)
    (hset : ∀ A : Set H, MeasurableSet A →
      μ (history ⁻¹' A ∩ S) = ∫⁻ h in A, weight h ∂Measure.map history μ) :
    Measure.map history (μ.restrict S) = (Measure.map history μ).withDensity weight := by
  apply Measure.ext
  intro A hA
  rw [Measure.map_apply hh hA, Measure.restrict_apply (hA.preimage hh),
    withDensity_apply weight hA]
  exact hset A hA

private theorem survival_history_all_tests {Ω H : Type*}
    [MeasurableSpace Ω] [MeasurableSpace H]
    (μ : Measure Ω) (history : Ω → H) (S : Set Ω) (weight : H → ℝ≥0∞)
    (hh : Measurable history) (hw : Measurable weight)
    (hset : ∀ A : Set H, MeasurableSet A →
      μ (history ⁻¹' A ∩ S) = ∫⁻ h in A, weight h ∂Measure.map history μ)
    (F : H → ℝ≥0∞) (hF : Measurable F) :
    (∫⁻ w in S, F (history w) ∂μ) =
      ∫⁻ h, F h * weight h ∂Measure.map history μ := by
  rw [← lintegral_map hF hh, survival_history_measure μ history S weight hh hset,
    lintegral_withDensity_eq_lintegral_mul _ hw hF]
  exact lintegral_congr fun _ => mul_comm _ _

/- A total history interpolation on arbitrary (possibly unrealizable) histories.
The path space has its coordinate-product measurable structure. -/
private theorem measurable_record_step {X Y : Type*}
    [MeasurableSpace X] [MeasurableSpace Y]
    (Φ : Y → ℝ≥0 → X → X)
    (hΦ : Measurable (fun p : Y × ℝ≥0 × X => Φ p.1 p.2.1 p.2.2))
    (s : ℝ≥0) :
    Measurable (fun p : ((ℝ≥0 × X) ⊕ Unit) × (X × Y) =>
      p.1.elim (fun a => if a.1 ≤ s then Φ p.2.2 (s - a.1) a.2 else p.2.1)
        (fun _ => p.2.1)) := by
  classical
  let e := MeasurableEquiv.sumProdDistrib (ℝ≥0 × X) Unit (X × Y)
  have hl : Measurable (fun p : (ℝ≥0 × X) × (X × Y) =>
      if p.1.1 ≤ s then Φ p.2.2 (s - p.1.1) p.1.2 else p.2.1) := by
    apply Measurable.ite (measurableSet_le measurable_fst.fst measurable_const)
    · exact hΦ.comp (measurable_snd.snd.prodMk
        ((measurable_const.sub measurable_fst.fst).prodMk measurable_fst.snd))
    · exact measurable_snd.fst
  convert (hl.sumElim (measurable_snd.fst :
    Measurable (fun p : Unit × (X × Y) => p.2.1))).comp e.measurable using 1
  funext p
  rcases p with ⟨a | a, q⟩ <;> rfl

private theorem measurable_history_interpolation {X Y : Type*}
    [MeasurableSpace X] [MeasurableSpace Y]
    (Φ : Y → ℝ≥0 → X → X)
    (hΦ : Measurable (fun p : Y × ℝ≥0 × X => Φ p.1 p.2.1 p.2.2))
    (n : ℕ) (T : ℝ≥0)
    (h : Y → Fin n → ((ℝ≥0 × X) ⊕ Unit)) (hh : Measurable h)
    (z₀ : Y → X) (hz₀ : Measurable z₀) :
    Measurable (fun y => fun s : {s : ℝ≥0 // s ≤ T} =>
      Fin.foldl n (fun z j => (h y j).elim
        (fun a => if a.1 ≤ s.val then Φ y (s.val - a.1) a.2 else z)
        (fun _ => z)) (z₀ y)) := by
  classical
  apply measurable_pi_lambda
  intro s
  apply measurable_finite_fold n _ _ z₀ hz₀
  intro j
  exact (measurable_record_step Φ hΦ s.val).comp
    (((measurable_pi_apply j).comp (hh.comp measurable_snd)).prodMk measurable_id)

/- The last eligible index, rather than a maximum chosen by an unmeasurable
path-space operation, determines each coordinate of the literal fold. -/
private theorem finite_fold_last_eligible {X : Type*} (n : ℕ)
    (b : Fin n → Prop) [DecidablePred b] (v : Fin n → X) (x : X)
    (j : Fin n) (hj : b j) (hafter : ∀ k : Fin n, j < k → ¬ b k) :
    Fin.foldl n (fun z k => if b k then v k else z) x = v j := by
  induction n with
  | zero => exact Fin.elim0 j
  | succ n ih =>
    induction j using Fin.lastCases with
    | last => simp only [Fin.foldl_succ_last, if_pos hj]
    | cast j =>
      rw [Fin.foldl_succ_last, if_neg (hafter (Fin.last n) (Fin.castSucc_lt_last j))]
      exact ih (fun k => b k.castSucc) (fun k => v k.castSucc) j hj
        (fun k hk => hafter k.castSucc (Fin.castSucc_lt_castSucc_iff.mpr hk))


private theorem measurable_terminal_record_weight {X Y : Type*}
    [MeasurableSpace X] [MeasurableSpace Y]
    (L : Y → X → ℝ≥0 → ℝ)
    (hL : Measurable (fun p : (Y × X) × ℝ≥0 => L p.1.1 p.1.2 p.2))
    (T : ℝ≥0) :
    Measurable (fun p : ((ℝ≥0 × X) ⊕ Unit) × Y =>
      p.1.elim (fun a => ENNReal.ofReal (Real.exp (-L p.2 a.2 (T - a.1)))) (fun _ => 0)) := by
  let e := MeasurableEquiv.sumProdDistrib (ℝ≥0 × X) Unit Y
  have hl : Measurable (fun p : (ℝ≥0 × X) × Y =>
      ENNReal.ofReal (Real.exp (-L p.2 p.1.2 (T - p.1.1)))) :=
    (hL.comp (f := fun p : (ℝ≥0 × X) × Y => ((p.2, p.1.2), T - p.1.1))
      ((measurable_snd.prodMk measurable_fst.snd).prodMk
        (measurable_const.sub measurable_fst.fst))).neg.exp.ennreal_ofReal
  convert (hl.sumElim (measurable_const : Measurable (fun _ : Unit × Y => (0 : ℝ≥0∞)))).comp
    e.measurable using 1
  funext p
  rcases p with ⟨a | a, q⟩ <;> rfl

private theorem real_time_history_fold {X : Type*} (Φ : ℝ → X → X)
    (n : ℕ) (t : Fin n → ℝ) (ht : ∀ k, 0 ≤ t k) (z : Fin n → X) (z₀ : X)
    (s : ℝ≥0) (j : Fin n) (hj : t j ≤ (s : ℝ))
    (hafter : ∀ k : Fin n, j < k → (s : ℝ) < t k) :
    Fin.foldl n (fun x k => if Real.toNNReal (t k) ≤ s then
      Φ (((s - Real.toNNReal (t k)) : ℝ≥0) : ℝ) (z k) else x) z₀ =
      Φ ((s : ℝ) - t j) (z j) := by
  have hcoe (k : Fin n) : (Real.toNNReal (t k) : ℝ) = t k := Real.coe_toNNReal (t k) (ht k)
  have hj' : Real.toNNReal (t j) ≤ s := by
    exact_mod_cast (show (Real.toNNReal (t j) : ℝ) ≤ (s : ℝ) by rw [hcoe]; exact hj)
  have ha (k : Fin n) (hjk : j < k) : ¬ Real.toNNReal (t k) ≤ s := by
    intro hk
    have hkr : (Real.toNNReal (t k) : ℝ) ≤ (s : ℝ) := by exact_mod_cast hk
    rw [hcoe] at hkr
    exact not_lt_of_ge hkr (hafter k hjk)
  rw [finite_fold_last_eligible n (fun k => Real.toNNReal (t k) ≤ s)
    (fun k => Φ (((s - Real.toNNReal (t k)) : ℝ≥0) : ℝ) (z k)) z₀ j hj' ha,
    NNReal.coe_sub hj', hcoe]

set_option maxHeartbeats 1000000 in
private theorem actual_prescribed_path_interpolation
    {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℝ E]
    [FiniteDimensional ℝ E] [MeasurableSpace E] [BorelSpace E]
    {V : E → ℝ} {α β : ℝ≥0} {η : ℝ}
    (hα : 0 < (α : ℝ)) (hαβ : α ≤ β) (hV : ContDiff ℝ 2 V)
    (hH : ∀ x v : E,
      (α : ℝ) * ‖v‖ ^ 2 ≤ (fderiv ℝ (fderiv ℝ V) x v) v ∧
      (fderiv ℝ (fderiv ℝ V) x v) v ≤ (β : ℝ) * ‖v‖ ^ 2)
    (hη : 0 < η) (hβη : (β : ℝ) * η ≤ 1) :
    let c : E → E → E := fun y xRef => y - η • gradient V xRef
    let Φ : E → E → ℝ → (E × E) → (E × E) := fun y xRef t z =>
      (c y xRef + Real.cos t • (z.1 - c y xRef) +
          (Real.sqrt η * Real.sin t) • z.2,
       (-Real.sin t / Real.sqrt η) • (z.1 - c y xRef) + Real.cos t • z.2)
    let S : E → (E × E) → (E × E) := fun xRef z =>
      (z.1, z.2 - (2 * inner ℝ z.2 (gradient V z.1 - gradient V xRef) /
        ‖gradient V z.1 - gradient V xRef‖ ^ 2) • (gradient V z.1 - gradient V xRef))
    let Rec := (ℝ≥0 × (E × E)) ⊕ Unit
    let Hist : ℕ → Type _ := fun n => Fin (n + 1) → Rec
    let Δ : (n : ℕ) → ℝ≥0 → Set (Fin n → ℝ) := fun n T =>
      {t | StrictMono (Fin.cons (0 : ℝ) t) ∧ ∀ i, t i < (T : ℝ)}
    let Prefix : (n : ℕ) → ℝ≥0 → Type := fun n T => {t : Fin n → ℝ // t ∈ Δ n T}
    let zAt : E → E → (E × E) → (n : ℕ) → (T : ℝ≥0) →
        Prefix n T → Fin (n + 1) → (E × E) := fun y xRef z₀ n T t =>
      Fin.induction z₀ (fun i z =>
        S xRef (Φ y xRef (t.val i - (Fin.cons (0 : ℝ) (t.val : Fin n → ℝ) : Fin (n + 1) → ℝ) i.castSucc) z))
    let K : E → E → (E × E) → (n : ℕ) → (T : ℝ≥0) →
        Prefix n T → Hist n := fun y xRef z₀ n T t j =>
      Sum.inl (Real.toNNReal ((Fin.cons (0 : ℝ) (t.val : Fin n → ℝ) : Fin (n + 1) → ℝ) j), zAt y xRef z₀ n T t j)
    let Path : ℝ≥0 → Type _ := fun T => {s : ℝ≥0 // s ≤ T} → E × E
    let Ψ : E → E → (E × E) → (n : ℕ) → (T : ℝ≥0) → Hist n → Path T :=
      fun y xRef z₀ n T h s =>
        Fin.foldl (n + 1) (fun z j => (h j).elim
          (fun a => if a.1 ≤ s.val then Φ y xRef ((s.val - a.1 : ℝ≥0) : ℝ) a.2 else z)
          (fun _ => z)) z₀
    let Γ : E → E → (E × E) → (n : ℕ) → (T : ℝ≥0) → Prefix n T → Path T :=
      fun y xRef z₀ n T t => Ψ y xRef z₀ n T (K y xRef z₀ n T t)
    ∀ n : ℕ, ∀ T : ℝ≥0, ∀ y xRef : E, ∀ z₀ : E × E,
      ∀ t : Prefix n T, ∀ s : {s : ℝ≥0 // s ≤ T}, ∀ j : Fin (n + 1),
        (Fin.cons (0 : ℝ) (t.val : Fin n → ℝ) : Fin (n + 1) → ℝ) j ≤ (s.val : ℝ) →
        (∀ k : Fin (n + 1), j < k → (s.val : ℝ) < (Fin.cons (0 : ℝ) (t.val : Fin n → ℝ) : Fin (n + 1) → ℝ) k) →
        Γ y xRef z₀ n T t s =
          Φ y xRef ((s.val : ℝ) - (Fin.cons (0 : ℝ) (t.val : Fin n → ℝ) : Fin (n + 1) → ℝ) j) (zAt y xRef z₀ n T t j) := by
  classical
  let c : E → E → E := fun y xRef => y - η • gradient V xRef
  let Φ : E → E → ℝ → (E × E) → (E × E) := fun y xRef t z =>
    (c y xRef + Real.cos t • (z.1 - c y xRef) +
        (Real.sqrt η * Real.sin t) • z.2,
     (-Real.sin t / Real.sqrt η) • (z.1 - c y xRef) + Real.cos t • z.2)
  let S : E → (E × E) → (E × E) := fun xRef z =>
    (z.1, z.2 - (2 * inner ℝ z.2 (gradient V z.1 - gradient V xRef) /
      ‖gradient V z.1 - gradient V xRef‖ ^ 2) • (gradient V z.1 - gradient V xRef))
  let Rec := (ℝ≥0 × (E × E)) ⊕ Unit
  let Hist : ℕ → Type _ := fun n => Fin (n + 1) → Rec
  let Δ : (n : ℕ) → ℝ≥0 → Set (Fin n → ℝ) := fun n T =>
    {t | StrictMono (Fin.cons (0 : ℝ) t) ∧ ∀ i, t i < (T : ℝ)}
  let Prefix : (n : ℕ) → ℝ≥0 → Type := fun n T => {t : Fin n → ℝ // t ∈ Δ n T}
  let zAt : E → E → (E × E) → (n : ℕ) → (T : ℝ≥0) →
      Prefix n T → Fin (n + 1) → (E × E) := fun y xRef z₀ n T t =>
    Fin.induction z₀ (fun i z =>
      S xRef (Φ y xRef (t.val i - (Fin.cons (0 : ℝ) (t.val : Fin n → ℝ) : Fin (n + 1) → ℝ) i.castSucc) z))
  let K : E → E → (E × E) → (n : ℕ) → (T : ℝ≥0) →
      Prefix n T → Hist n := fun y xRef z₀ n T t j =>
    Sum.inl (Real.toNNReal ((Fin.cons (0 : ℝ) (t.val : Fin n → ℝ) : Fin (n + 1) → ℝ) j), zAt y xRef z₀ n T t j)
  let Path : ℝ≥0 → Type _ := fun T => {s : ℝ≥0 // s ≤ T} → E × E
  let Ψ : E → E → (E × E) → (n : ℕ) → (T : ℝ≥0) → Hist n → Path T :=
    fun y xRef z₀ n T h s =>
      Fin.foldl (n + 1) (fun z j => (h j).elim
        (fun a => if a.1 ≤ s.val then Φ y xRef ((s.val - a.1 : ℝ≥0) : ℝ) a.2 else z)
        (fun _ => z)) z₀
  let Γ : E → E → (E × E) → (n : ℕ) → (T : ℝ≥0) → Prefix n T → Path T :=
    fun y xRef z₀ n T t => Ψ y xRef z₀ n T (K y xRef z₀ n T t)
  change
    ∀ n : ℕ, ∀ T : ℝ≥0, ∀ y xRef : E, ∀ z₀ : E × E,
      ∀ t : Prefix n T, ∀ s : {s : ℝ≥0 // s ≤ T}, ∀ j : Fin (n + 1),
        (Fin.cons (0 : ℝ) (t.val : Fin n → ℝ) : Fin (n + 1) → ℝ) j ≤ (s.val : ℝ) →
        (∀ k : Fin (n + 1), j < k → (s.val : ℝ) < (Fin.cons (0 : ℝ) (t.val : Fin n → ℝ) : Fin (n + 1) → ℝ) k) →
        Γ y xRef z₀ n T t s =
          Φ y xRef ((s.val : ℝ) - (Fin.cons (0 : ℝ) (t.val : Fin n → ℝ) : Fin (n + 1) → ℝ) j) (zAt y xRef z₀ n T t j)
  intro n T y xRef z₀ t s j hj hafter
  have hnonneg (k : Fin (n + 1)) :
      0 ≤ (Fin.cons (0 : ℝ) (t.val : Fin n → ℝ) : Fin (n + 1) → ℝ) k := by
    have hk := t.property.1.monotone (Fin.zero_le k)
    simpa only [Fin.cons_zero] using hk
  exact real_time_history_fold (Φ y xRef) (n + 1)
    (Fin.cons (0 : ℝ) (t.val : Fin n → ℝ)) hnonneg
    (zAt y xRef z₀ n T t) z₀ s.val j hj hafter

#print axioms actual_prescribed_path_interpolation
end
end PathInterfaces93
