import Tests.GaussianComplexityFixedSpectrumExactMeans
open MeasureTheory ProbabilityTheory Lean
open scoped BigOperators
open scoped MatrixOrder

example {d : ℕ} (c : Fin d → ℝ) (x : EuclideanSpace ℝ (Fin d)) :
    dotProduct (WithLp.ofLp x) ((Matrix.diagonal c).mulVec (WithLp.ofLp x)) =
      ∑ i : Fin d, c i * (WithLp.ofLp x i) ^ 2 := by
  classical
  simp only [dotProduct, Matrix.mulVec_diagonal]
  apply Finset.sum_congr rfl
  intro i _
  ring

example {d : ℕ} (x : EuclideanSpace ℝ (Fin d)) :
    ‖x‖ ^ 2 = ∑ i : Fin d, (WithLp.ofLp x i) ^ 2 :=
  EuclideanSpace.real_norm_sq_eq x

example {d : ℕ} (m : EuclideanSpace ℝ (Fin d)) (S : Matrix (Fin d) (Fin d) ℝ) :
    multivariateGaussian m S =
      (stdGaussian (EuclideanSpace ℝ (Fin d))).map
        (fun x => m + Matrix.toEuclideanCLM (𝕜 := ℝ) (CFC.sqrt S) x) := rfl

#print ProbabilityTheory.multivariateGaussian
#print axioms AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumGaussianMoments.actual_diagonal_gaussian_quadratic_means
#print axioms AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumCosineExpansion.actual_inverse_spectrum_cosine_expansion
#print axioms AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumGridAlias.actual_midpoint_grid_cosine_alias

run_cmd do
  let env ← getEnv
  for n in env.header.moduleNames do
    logInfo m!"IMPORTED_MODULE {n}"
  logInfo "OWN_DEFINITION_COORDINATE_AND_CACHE_PROBE_PASS"
