from pathlib import Path
import hashlib
import json

ROOT=Path('/Users/zhouhuanjian/ASTIS-GC')
BASE=ROOT/'.astis/huanjian-gc-fixed-spectrum-first-order-20261108'
PHASE1=BASE/'source-graph/phase1'
PRIVATE=BASE/'source-graph/phase2-candidate-overlay-v1'
PUBLIC=ROOT/'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-first-order-semantic-evidence/source-only-review/phase2-candidate-overlay-v1'
PHASE1_HASH='756e51e694cd0d720e7b7fdec87d754292f4b8a109d080e41e9c3249d949a30f'
SOURCE_HASH='6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
HASHES={
 'preproof-exact-statement-candidate-seal.json':'464ea7820b3545baa17669528532199017cf42a5255d6b2bfa88076c1b6992f0',
 'producer-exact-signature.txt':'452c547235344031f5f8c3035dc3f590a876741993c7ae9a1be2a7e129a948c1',
 'consumer-exact-signature.txt':'f0059bed1e49535a1dde0aba66a62bf371958bc8915d40a2b6c65c5df8366e4d',
 'PresealStatements.lean':'1fa7e4ca83c3e15b636b85e52fbb5dc0b92e87bfb910109556f96e0b1c54818f',
}
def sha(b):
 if isinstance(b,str):b=b.encode()
 return hashlib.sha256(b).hexdigest()
def read_json(p):return json.loads(p.read_text())
assert sha((PHASE1/'manifest.json').read_bytes())==PHASE1_HASH
p1manifest=read_json(PHASE1/'manifest.json')
for f in p1manifest['files']:
 b=(PHASE1/f['path']).read_bytes()
 assert len(b)==f['bytes'] and sha(b)==f['sha256']
inputs={n:(BASE/n).read_bytes() for n in HASHES}
for n,b in inputs.items():assert sha(b)==HASHES[n],n
seal=json.loads(inputs['preproof-exact-statement-candidate-seal.json'])
coverage=read_json(PHASE1/'coverage.json')['units']
p1nodes=read_json(PHASE1/'nodes.json')['nodes']
p1ids={x['id'] for x in p1nodes}
producer='AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumFirstOrder.actual_first_order_query'
consumer='actual_reference_precision_first_order_consumer (private)'

for p in [PRIVATE,PUBLIC]:
 assert not p.exists(),f'Do not overwrite prior evidence: {p}'
 p.mkdir(parents=True)

files={}
for n,b in inputs.items():files['candidate-inputs/'+n]=b

windows=[
 ('Mathlib/Analysis/Calculus/Gradient/Basic.lean',43,89,'Definitions of HasGradientAtFilter, HasGradientAt, gradient and their real inner-product meaning.'),
 ('Mathlib/Data/Matrix/Mul.lean',72,73,'dotProduct definition only.'),
 ('Mathlib/Data/Matrix/Mul.lean',696,705,'Authorized mulVec definition window; includes mulVec_apply rfl at704-705, recorded as incidental exposure.'),
 ('Mathlib/LinearAlgebra/UnitaryGroup.lean',54,61,'Necessary unitaryGroup alias and parameter context, no proof body.'),
 ('Mathlib/LinearAlgebra/UnitaryGroup.lean',286,295,'Necessary orthogonalGroup alias: transpose is inverse, no determinant-one condition.'),
 ('Mathlib/Analysis/Normed/Lp/WithLp.lean',38,60,'WithLp structure with constructor toLp and projection ofLp; coordinate-preserving wrapper.'),
 ('Mathlib/Analysis/InnerProductSpace/PiL2.lean',110,114,'EuclideanSpace alias to PiLp2, necessary carrier meaning only.'),
]
definition_windows=[]
for name,start,end,purpose in windows:
 lines=(ROOT/'.lake/packages/mathlib'/name).read_text().splitlines(keepends=True)
 text=''.join(lines[start-1:end])
 definition_windows.append({'path':'.lake/packages/mathlib/'+name,'lines_inclusive':[start,end],
                            'window_sha256':sha(text),'text':text,'purpose':purpose})

candidate_inputs={
 'schema':'gc-source-only-phase2-candidate-inputs-v1',
 'role':'independent phase1 source graph extractor, now endpoint-aware candidate overlay',
 'phase1_manifest_sha256':PHASE1_HASH,'source_raw_sha256':SOURCE_HASH,
 'only_root_private_inputs_read':[{'path':str((BASE/n).relative_to(ROOT)),'bytes':len(b),'sha256':sha(b)} for n,b in inputs.items()],
 'producer_declaration':producer,'consumer_declaration':consumer,
 'target_implementation_read':False,'target_mathematical_proof_experiment':False,'proof_API_retrieval':False,
 'compiler_fixture_interpretation':'Only Prop definitions plus #check/#print. This role did not run a compiler and did not inspect the cited receipt/log.',
 'root_previous_proof_exposure':'The supplied exact seal openly records root exposure to previous FirstOrderQuery, FixedSpectrumAffine and Admissibility implementations. This role has not read them; no root proof-independence claim is made.',
 'frozen_source_graph_not_changed':True,
}

producer_binders=[
 {'syntax':'{d : Nat}','classification':'SOURCE + TYPING','source':['S4.SS1.p1.1:s02'],'meaning':'Finite real dimension; Nat and Fin d implement the source positive integer dimension.'},
 {'syntax':'(hd : 2 <= d)','classification':'SOURCE','source':['S4.SS1.p1.1:s02'],'meaning':'Retains the exact hard-family dimension range. d!=0 needed by the grid denominator is derived, not an extra premise.'},
 {'syntax':'{kappa : Real}','classification':'SOURCE + TYPING','source':['S4.SS1.p1.1:s02'],'meaning':'Real spectral parameter.'},
 {'syntax':'(hKappa : 2 <= kappa)','classification':'SOURCE','source':['S4.SS1.p1.1:s02'],'meaning':'Exact hard-family parameter range; no delta/epsilon restriction is needed locally.'},
 {'syntax':'(O : Matrix.orthogonalGroup (Fin d) Real)','classification':'SOURCE + TYPING','source':['S2.p2.1:s01','S4.SS1.p1.2:s01','S4.Thmtheorem6.p1.1:s01'],
  'meaning':'Arbitrary full real orthogonal matrix, not SO(d), not a single sign component and not an additional Haar-distributed random variable.'},
 {'syntax':'let theta i := (i.val + 1/2) * pi / d','classification':'DEFINITION','source':['S4.E11'],
  'meaning':'Literal source half-node grid after i_source=i.val+1. Then i_source-1/2=i.val+1/2; real arithmetic, not natural-number division.'},
 {'syntax':'let A := O * diagonal(lambda) * O.transpose','classification':'DEFINITION','source':['S4.E11','S4.SS1.p1.2:s01'],
  'meaning':'Actual precision matrix with literal source cosine eigenvalues; symmetry is a consequence of this definition, never an assumed binder.'},
 {'syntax':'let f x := dotProduct (ofLp x) (A mulVec ofLp x) / 2','classification':'DEFINITION','source':['S2.SS0.SSS0.Px1.p1.2:s01','S4.SS1.p1.2:s02','A3.SS4.p2.1:s01'],
  'meaning':'Same source quadratic with factor1/2 and zero additive constant on all of real Euclidean space.'},
 {'syntax':'let query x := toLp 2 (A mulVec ofLp x)','classification':'DEFINITION','source':['S2.E1'],
  'meaning':'Actual exact precision matrix-vector product at the same x. It is neither A-inverse covariance action nor an O-only reply.'},
 {'syntax':'forall x : EuclideanSpace Real (Fin d)','classification':'SOURCE + TYPING','source':['S2.SS0.SSS0.Px1.p1.2:s02','S2.E1'],
  'meaning':'All query points including zero, not an almost-everywhere/positive-radius/nonzero query condition.'},
 {'syntax':'HasGradientAt f (query x) x','classification':'OUTPUT','source':['S2.E1','A3.SS4.p2.1:s01'],
  'meaning':'Actual Frechet differentiability with derivative represented by the proposed vector via the real Riesz map. Not a supplied numerical-gradient premise.'},
 {'syntax':'(f x, gradient f x) = (inner Real x (query x)/2, query x)','classification':'OUTPUT','source':['S2.E1','S2.SS0.SSS0.Px1.p2.1:s02'],
  'meaning':'True value and total mathematical gradient equal the exact reconstructed pair. HasGradientAt output discharges any otherwise-default-zero concern for total gradient.'},
]
consumer_binders=[
 {'syntax':'d, hd, kappa, hKappa, O, theta','classification':'SOURCE + DEFINITION + TYPING',
  'source':['S4.SS1.p1.1:s02','S4.E11','S4.Thmtheorem2.p1.1:s02'],
  'meaning':'Same source ranges and SAME latent O for both parameter values; no independent reference rotation.'},
 {'syntax':'let A : Real -> Matrix := fun eta => O * diagonal(lambda_eta) * O.transpose','classification':'DEFINITION',
  'source':['S4.E11','S4.Thmtheorem2.p1.1:s02'],
  'meaning':'Uniform literal polynomial/cosine formula used only at eta=kappa and eta=2. The local auxiliary body also has values outside eta>=2, but no admissibility or oracle claim is made there. No invented fallback branch.'},
 {'syntax':'let f := quadratic of A kappa','classification':'DEFINITION','source':['S4.SS1.p1.2:s02','S2.E1'],
  'meaning':'The actual kappa precision potential; not the reference potential and not covariance.'},
 {'syntax':'let referenceQuery x := toLp 2 (A 2 mulVec ofLp x)','classification':'DEFINITION','source':['S4.Thmtheorem2.p1.1:s01','S4.Thmtheorem2.p1.1:s02','S4.Thmtheorem2.p1.1:s03'],
  'meaning':'Actual same-point A_2 precision reply, with same d, theta and O. No reply-correctness assumption is supplied.'},
 {'syntax':'let reconstructed x := (kappa-1) smul referenceQuery x - (kappa-2) smul x','classification':'DEFINITION',
  'source':['S4.Thmtheorem2.p1.1:s02','S4.Thmtheorem2.p1.1:s03'],
  'meaning':'Forward known affine arithmetic reconstructing A_kappa x from A_2 x. There is no division by kappa-1 in the exact consumer.'},
 {'syntax':'forall x : EuclideanSpace Real (Fin d)','classification':'SOURCE + TYPING','source':['S2.E1','S4.Thmtheorem2.p1.1:s03'],
  'meaning':'Every point including zero; one same point in original and reconstructed quantities.'},
 {'syntax':'HasGradientAt f (reconstructed x) x and actual value/gradient pair equality','classification':'OUTPUT',
  'source':['S2.E1','S4.Thmtheorem2.p1.1:s02','S4.Thmtheorem2.p1.1:s03'],
  'meaning':'Compose actual first-order output with the affine precision reply identity; no gradient, symmetry or affine response correctness hypothesis is added.'},
]
binder_audit={
 'schema':'gc-source-only-phase2-binder-audit-v1',
 'producer':producer_binders,'consumer':consumer_binders,
 'EXCESS':[],
 'must_not_add':['A symmetry','HasGradientAt or gradient correctness','an affine reply identity','response correctness gate','a differentiability witness','normalizer/integrability','SC/smoothness','Haar event','seed restriction','nonzero query x'],
 'retained_source_ranges_are_not_excess':'The derivative identity may be mathematically true on larger parameter ranges, but the candidate faithfully retains the hard-family d>=2 and kappa>=2 scope.',
 'status':'No excess input found in these exact signatures; advisory preproof audit only.'}

seven_slots={
 'schema':'gc-source-only-phase2-seven-slot-audit-v1',
 'not_canonical_semantic_roundtrip':'Source visible to this role. This is not a source-blind decoder, not a compiled-code review and not a canonical packet-bound postcompile semantic acceptance.',
 'producer':{
  'objects':{'verdict':'MATCH','source':['S4.E11','S4.SS1.p1.2','S2.E1'],'comparison':'Literal theta/lambda, real precision A=O Lambda O^T, real quadratic f, exact matrix-vector query; value-gradient pair is the source FO reply.'},
  'domains':{'verdict':'MATCH','source':['S4.SS1.p1.1:s02','S2.p2.1:s01','S2.SS0.SSS0.Px1.p1.2:s02'],'comparison':'d>=2, kappa>=2, full O(d), all x in R^d including0. Fin d is a coordinate reindexing, and EuclideanSpace is l2 via PiLp2/WithLp.'},
  'quantifiers':{'verdict':'MATCH','source':['S4.Thmtheorem6.p1.1','S2.E1'],'comparison':'For every d,kappa in source range, every O, then every x. A/f/query are fixed from d,kappa,O before the all-x conclusion. No seed/a.e./existentially selected query.'},
  'assumptions':{'verdict':'MATCH_NO_EXCESS','source':['S4.SS1.p1.1:s02','S4.SS1.p1.2:s01'],'comparison':'Only source d/kappa/O inputs and literal definitions. Symmetry, derivative existence and reply correctness are to be proved, not premises.'},
  'conclusion':{'verdict':'MATCH_RESTRICTED_SOURCE_SUBCLAIM','source':['S2.E1','A3.SS4.p2.1:s01'],'comparison':'Genuine HasGradientAt with gradient Ax and exact quadratic value pair. S2 states the actual gradient formula; C.4 motivates the omitted calculus. No C-infinity/Hessian/SC/smooth/minimizer output is claimed.'},
  'scopes_senses':{'verdict':'MATCH_WITH_EXPLICIT_INFERRED_BRIDGES','source':['S2.E1','S4.SS1.p1.2','A3.SS4.p2.1'],'comparison':'Actual mathematical Frechet/Riesz gradient, not an opaque assumed oracle. C.4 does not literally write gradV=Ax; that bridge is labelled inferred. Hidden O is a mathematical object binder, not algorithmic disclosure.'},
  'constant_dependencies':{'verdict':'MATCH','source':['S4.E11','S2.E1'],'comparison':'Exact constants pi,1/2,(kappa+1)/2,(kappa-1)/2; no hidden C,d0,delta,epsilon,normalizer,finite-precision or expected-cost constant.'},
 },
 'consumer':{
  'objects':{'verdict':'MATCH','source':['S4.Thmtheorem2.p1.1:s02','S4.Thmtheorem2.p1.1:s03','S2.E1'],'comparison':'Same-O A_kappa and A_2; referenceQuery is actual A_2 x. Reconstructed vector equals actual A_kappa x by the source affine identity, which must be discharged internally.'},
  'domains':{'verdict':'MATCH','source':['S4.SS1.p1.1:s02','S4.Thmtheorem2.p1.1:s02'],'comparison':'Same hard-family d>=2,kappa>=2 and arbitrary full orthogonal O. The local family function at eta is used only for eta=kappa and eta=2; no off-range spectral claim.'},
  'quantifiers':{'verdict':'MATCH','source':['S4.Thmtheorem2.p1.1:s02','S4.Thmtheorem2.p1.1:s03'],'comparison':'For every one shared O, all same query points x. No existential coupling of unrelated rotations and no query-at-a-different-point substitution.'},
  'assumptions':{'verdict':'MATCH_NO_EXCESS','source':['S4.Thmtheorem2.p1.1:s02','S2.E1'],'comparison':'No supplied gradient, matrix symmetry, response correctness, or affine identity binder. Existing affine producer is an intended dependency from the seal, not a new public premise and not independently checked by this role.'},
  'conclusion':{'verdict':'MATCH_FORWARD_POINTWISE_SUBCLAIM','source':['S4.Thmtheorem2.p1.1:s03','S2.E1'],'comparison':'True kappa-potential HasGradientAt and value-gradient reply reconstructed from the reference2 matvec expression. Source says either direction; this private consumer realizes only the forward mathematical subclaim, not reverse simulation or algorithm counts.'},
  'scopes_senses':{'verdict':'MATCH_WITH_EXPLICIT_INFERRED_COMPOSITION','source':['S2.E1','S4.Thmtheorem2.p1.1:s02','S4.Thmtheorem2.p1.1:s03'],'comparison':'First-order combination is an inferred elementary elaboration of two literal source interfaces. It is deterministic and exact at one point; no transcript, hidden-seed, output-law, TV or machine-arithmetic semantics.'},
  'constant_dependencies':{'verdict':'MATCH','source':['S4.Thmtheorem2.p1.1:s02'],'comparison':'Known kappa-1 and kappa-2 scalar coefficients. The forward formula has no division; nonzero kappa-1 is relevant only to the unclaimed reverse direction and follows from kappa>=2 if needed.'},
 },
 'repair_required':False,'blocking_semantic_delta_found':False,
}

# New overlay obligations refine the first-order projection of a larger phase1 calculus node.
overlay_nodes=[
 {'id':'OVL:S2-gradient-literal','kind':'exact-source-projection','statement':'S2.E1 literally states grad f_A(x)=A*x as part of FO_A(x)=(f_A(x),grad f_A(x))=(x^T A x/2,A*x).','phase1_sources':['SRC:S2.E1:display'],
  'source_condition':'A in the S2 precision class, introduced in the immediately preceding source paragraph.'},
 {'id':'OVL:S2-pair-literal','kind':'exact-source-projection','statement':'S2.E1 literally states the actual value-gradient pair equals the quadratic value and precision-matvec pair.','phase1_sources':['SRC:S2.E1:display'],
  'source_condition':'A in the S2 precision class; the finite real Euclidean queryx is arbitrary.'},
 {'id':'OVL:P','kind':'candidate-output','statement':'Exact producer conjunction HasGradientAt plus actual value-gradient pair equality.','phase1_sources':['SRC:S2.E1:display','INF:gradient','INF:fo-hard-family']},
 {'id':'OVL:C','kind':'candidate-output','statement':'Exact private forward same-O reference2 consumer conjunction.','phase1_sources':['SRC:S4.Thmtheorem2.p1.1:s02','SRC:S4.Thmtheorem2.p1.1:s03','INF:fo-affine-transport']},
 {'id':'IB:P-symmetry','kind':'internal-open-bridge','statement':'The literal real diagonal orthogonal conjugation is symmetric.','phase1_sources':['INF:symmetry'],'must_be_binder':False},
 {'id':'IB:P-source-admissibility','kind':'internal-open-source-instantiation','statement':'To instantiate the literal S2.E1 precision-class interface for every hard-familyO, discharge symmetry and I<=A<=kappaI internally, by proof/reuse, never a new premise.','phase1_sources':['SRC:S2.Ex1:display','SRC:S4.Thmtheorem6.p1.1:s01','SRC:A3.SS4.p1.1:s02','INF:symmetry'],'must_be_binder':False,
  'scope':'Source-interface eligibility, not a newly claimed admissibility output or a claim that all C.4 conclusions are closed.'},
 {'id':'IB:P-coordinate-geometry','kind':'internal-open-bridge','statement':'WithLp coordinates, matrix mulVec/dotProduct and real l2 inner product agree for this literal quadratic and query.','phase1_sources':['INF:index-range','SRC:S2.E1:display'],'must_be_binder':False},
 {'id':'IB:P-first-derivative','kind':'internal-open-bridge','statement':'Prove HasGradientAt of this literal quadratic with actual vector A*x at every x.','phase1_sources':['INF:gradient','INF:quadratic-differentiation'],'must_be_binder':False,
  'not_closed_by_projection':['C-infinity','Hessian A','strong convexity','smoothness','unique minimizer']},
 {'id':'IB:P-total-gradient','kind':'internal-open-bridge','statement':'Use derivative existence/uniqueness to identify the total gradient with query; discharge the total-definition default branch.','phase1_sources':['INF:gradient','SRC:S2.E1:display'],'must_be_binder':False},
 {'id':'IB:C-affine-forward','kind':'internal-open-bridge','statement':'Discharge actual same-O precision identity A_kappa*x=(kappa-1) A_2*x-(kappa-2)x via intended existing affine dependency.','phase1_sources':['INF:affine-forward-matvec','SRC:S4.Thmtheorem2.p1.1:s02'],'must_be_binder':False,
  'existing_producer_from_seal':'FixedSpectrumAffine.actual_affine_precision_query; statement/proof not opened by this role'},
 {'id':'IB:C-coordinate-arithmetic','kind':'internal-open-bridge','statement':'Transfer the same-point affine matrix-vector equality through WithLp to reconstructed=query in EuclideanSpace.','phase1_sources':['INF:affine-forward-matvec'],'must_be_binder':False},
 {'id':'IB:C-substitution','kind':'internal-open-bridge','statement':'Consume the new producer and reconstructed=query to obtain the true derivative and actual value-gradient pair, with no correctness premise.','phase1_sources':['INF:fo-affine-transport','SRC:S2.E1:display'],'must_be_binder':False},
]
allids=p1ids|{x['id'] for x in overlay_nodes}
overlay_edges=[]
def e(parents,child,use,why,kind='AND'):
 assert child in allids and all(x in allids for x in parents)
 overlay_edges.append({'id':f'OVL:E{len(overlay_edges)+1:02}','parents':parents,'consumer':child,
                        'consumer_use_site':use,'semantics':kind,'reason':why,
                        'status':'open obligation or source justification, not compiler-verified dependency'})
e(['SRC:S4.E11:display','SRC:S4.SS1.p1.2:s01','INF:symmetry'],'IB:P-symmetry','producer letA','No matrix symmetry binder; literal body supplies the fact.','SOURCE_JUSTIFICATION_AND_OPEN_PROOF')
e(['SRC:S2.E1:display'],'OVL:S2-gradient-literal','S2.E1 second equality, gradient component','Exact source projection: gradient Ax is literal in S2, unlike its absence as a standalone formula in C.4.','EXACT_SOURCE_PROJECTION')
e(['SRC:S2.E1:display'],'OVL:S2-pair-literal','S2.E1 full ordered pair','Exact source projection: actual value-gradient pair, not a merely defined numerical gradient oracle.','EXACT_SOURCE_PROJECTION')
e(['IB:P-symmetry','SRC:S4.Thmtheorem6.p1.1:s01','SRC:S2.Ex1:display'],'IB:P-source-admissibility','S2 preceding paragraph A in precision class -> hard-family application','Hard-family admissibility is an internal source-interface instantiation obligation, not an input assumption.','SOURCE_JUSTIFICATION_AND_OPEN_PROOF')
e(['SRC:S4.E11:display','INF:index-range','SRC:S2.E1:display'],'IB:P-coordinate-geometry','producer theta/f/query/value equality','Check source index shift and actual coordinate/Euclidean meanings.','SOURCE_JUSTIFICATION_AND_OPEN_PROOF')
e(['IB:P-symmetry','IB:P-coordinate-geometry'],'IB:P-first-derivative','producer first conjunct','Prove the actual first derivative; not the whole C.4 regularity package.')
e(['IB:P-first-derivative'],'IB:P-total-gradient','producer second conjunct, gradient f x','HasGradientAt output prevents using a default-zero gradient value.')
e(['IB:P-first-derivative','IB:P-total-gradient','IB:P-coordinate-geometry'],'OVL:P','producer forall x, conjunction','Both derivative output and value/gradient pair must be established.')
e(['OVL:S2-gradient-literal','OVL:S2-pair-literal','IB:P-source-admissibility'],'OVL:P','source meaning of producer gradient/pair outputs','S2 explicitly supplies the source formula after precision-class eligibility. HasGradientAt and total-gradient recovery remain standard-meaning elaboration/proof obligations.','EXACT_SOURCE_JUSTIFICATION_NOT_COMPILED_PROOF')
e(['SRC:S4.Thmtheorem2.p1.1:s02','INF:affine-forward-matvec'],'IB:C-affine-forward','consumer referenceQuery/reconstructed','Same d, grid and O; exact forward scalar coefficients.','SOURCE_JUSTIFICATION_AND_OPEN_PROOF')
e(['IB:C-affine-forward','IB:P-coordinate-geometry'],'IB:C-coordinate-arithmetic','consumer reconstructed/query equality','Lift actual coordinate equality through the coordinate-preserving wrapper.')
e(['OVL:P','IB:C-coordinate-arithmetic'],'IB:C-substitution','consumer forall x, both conjuncts','New producer and actual affine reply identity are AND; no response-correctness assumption.')
e(['IB:C-substitution'],'OVL:C','private consumer conclusion','Exact pointwise forward composition, with neither count nor transcript claim.')

closure={
 'schema':'gc-source-only-phase2-backward-closure-v1','nodes':overlay_nodes,'edges':overlay_edges,
 'producer_backward_closure':{
  'raw_roots':['S2.p1.1','S2.p2.1','S2.E1','S2.SS0.SSS0.Px1.p1.2','S4.SS1.p1.1','S4.E11','S4.SS1.p1.2','A3.SS4.p2.1:s01'],
  'source_justification':'S2 explicitly states gradient Ax for this quadratic on the precision class; C.4 states smooth quadratic/Hessian. The actual derivative proof is an internal obligation, not supplied as an assumption.',
  'open_internal_bridges':['IB:P-symmetry','IB:P-source-admissibility','IB:P-coordinate-geometry','IB:P-first-derivative','IB:P-total-gradient'],
  'required_source_interface_eligibility':['SRC:S4.Thmtheorem6.p1.1:s01','SRC:A3.SS4.p1.1:s01','SRC:A3.SS4.p1.1:s02','INF:symmetry'],
  'source_domain_vs_derivative_route':'S2.E1 applies to A in the precision class. For the hard family this eligibility must be internally proved/reused; it cannot become a binder. The literal polynomial derivative identity can be proved directly from symmetry without consuming eigenvalue bounds, but that does not erase the source-interface eligibility obligation or advertise a newly closed admissibility theorem.'},
 'consumer_backward_closure':{
  'AND':['OVL:P','IB:C-affine-forward','IB:C-coordinate-arithmetic','IB:C-substitution'],
  'raw_roots':['S2.E1','S2.SS0.SSS0.Px1.p2.1:s02','S4.E11','S4.SS1.p1.2','S4.Thmtheorem2.p1.1:s02','S4.Thmtheorem2.p1.1:s03'],
  'source_condition_discharge':[
   {'condition':'same O/d/grid','discharge':'One O binder and one theta function are closed over by A(eta).'},
   {'condition':'reference parameter2','discharge':'referenceQuery uses A2 literally.'},
   {'condition':'same point x','discharge':'Both reference and reconstructed are applied to the same universal x.'},
   {'condition':'scalar coefficients','discharge':'Use kappa-1 and kappa-2 exactly. No inverse arithmetic occurs in this forward consumer.'},
   {'condition':'kappa-1 nonzero for reverse','discharge':'Not consumed by exact forward signature; would follow from hKappa>=2 for a separately claimed reverse theorem.'}],
  'intended_existing_dependency_not_verified_here':'FixedSpectrumAffine.actual_affine_precision_query is named only by the exact seal. This role did not inspect its declaration or proof.'},
 'AND_OR':{
  'current_producer':'Derivative existence AND coordinate/value identity AND total-gradient identification.',
  'current_consumer':'New producer AND actual same-O forward affine equality AND wrapper arithmetic/substitution.',
  'phase1_OR_preserved':'Phase1 FO-via-MV and direct-components are alternative mathematical expansions of transport. Current seal intends the MV composition; direct component-value affine route is not an extra AND premise.',
  'no_false_OR':'Forward and reverse reply transforms are distinct directional conclusions; both are required only for the unclaimed bidirectional equivalence.',
  'not_dependencies':['normalizer/Gaussian integral','Haar distribution','seed independence','Krylov/statistical lemmas','delta/epsilon range','expected-query or worst-cap count theorem']},
 'whole_source_result_not_closed':['full C.4 regularity/minimizer/normalizer package','whole Remark4.2 bidirectional algorithm equivalence','full lower bound theorem4.1','C1-C3/FactC6/4.7 proofs'],
}

def formula_match(u):
 mid=u['source']['source_element_id']
 if u['disposition']=='EXCLUDED':
  return 'structural-source-title-only',[],[], 'No additional candidate theorem claim.'
 if mid.startswith('S4.E11'):
  return 'literal-definitions-matched',['producer','consumer'],['objects','domains','quantifiers','constant_dependencies'],'Exact half-node grid/eigenvalue/diagonal definition, with Fin shift explained.'
 if mid in ['S4.SS1.p1.m3','S4.SS1.p1.m4']:
  return 'source-binder-matched',['producer','consumer'],['domains','assumptions'],'Exact d>=2 / kappa>=2 retained.'
 if mid=='S4.SS1.p1.m5':
  return 'partial-carrier-context',['producer','consumer'],['objects','domains','quantifiers'],'O(d) carrier matches; Haar distribution and seed independence are outside both endpoints.'
 if mid in ['S4.SS1.p1.m6','S4.SS1.p1.m7']:
  return 'literal-definitions-matched',['producer','consumer'],['objects','conclusion','scopes_senses'],'Actual precision conjugation or quadratic potential.'
 if mid=='S4.SS1.p2.m1':
  return 'latent-object-context',['producer','consumer'],['objects','scopes_senses'],'O is the hidden mathematical eigenbasis; binder does not grant algorithm access.'
 if mid.startswith('S2.E1'):
  return 'source-reply-conclusion-matched',['producer','consumer'],['objects','domains','conclusion','scopes_senses','constant_dependencies'],'Actual gradient/vector and value pair; consumer forward composition is inferred.'
 if mid=='S2.SS0.SSS0.Px1.p1.m6':
  return 'literal-quadratic-matched',['producer','consumer'],['objects','conclusion','constant_dependencies'],'Same x^T A x/2, zero additive constant.'
 if mid=='S2.SS0.SSS0.Px1.p1.m8':
  return 'all-query-domain-matched',['producer','consumer'],['domains','quantifiers'],'Every x in real Euclidean dimensiond including zero.'
 if mid.startswith('S2.SS0.SSS0.Px1.p2.m'):
  return 'source-reconstruction-meaning',['producer','consumer'],['objects','conclusion','scopes_senses'],'Precision matrix-vector reply contains the exact gradient and reconstructs exact value; no operational count claimed.'
 if mid=='S2.p2.m1':
  return 'full-orthogonal-carrier-matched',['producer','consumer'],['objects','domains','assumptions'],'Full O(d), with both determinant signs; no Haar law is asserted by these pointwise endpoints.'
 if mid in ['S2.p1.m1','S2.p1.m3','S2.p1.m4','S2.p1.m5','S2.p1.m6','S2.p1.m7','S2.Ex1.m1','S2.SS0.SSS0.Px1.p1.m5'] or mid.startswith('S2.Ex1'):
  return 'precision-geometry-source-context',['producer','consumer'],['objects','domains','scopes_senses'],'Source precision/Euclidean context. Candidate has literalA; symmetry and source membership are derived context, not new binders/outputs.'
 if mid.startswith('S4.Thmtheorem2.p1.m'):
  n=int(mid.rsplit('m',1)[1])
  if n<=4:
   return 'same-O-reference-affine-source',['consumer'],['objects','domains','assumptions','conclusion','constant_dependencies'],'Reference2, sameO, and literal affine matrix identity. Component transport is inferred and must be discharged internally.'
 if mid in ['A3.SS4.p2.m1']:
  return 'literal-quadratic-matched',['producer','consumer'],['objects','conclusion','scopes_senses'],'C.4 potential body matches; first derivative is inferred elementary elaboration, not a C.4 quotation.'
 if mid in ['A3.SS4.p1.m4','A3.SS4.p1.m5']:
  return 'literal-precision-and-orthogonality',['producer','consumer'],['objects','domains','assumptions'],'Actual definition/orthogonality needed for internal symmetry, not extra assumptions.'
 if mid.startswith('A3.SS4.p1.') or mid.startswith('S4.Thmtheorem6.'):
  return 'admissibility-context-not-output',['producer','consumer'],['domains','scopes_senses'],'Source hard-family admissibility is retained as context. Candidate does not newly close/claim these spectral inequalities.'
 if mid.startswith('A3.SS4.p2.'):
  return 'C4-remainder-not-closed',[],[], 'C-infinity/Hessian/SC/smooth/minimizer statements are not outputs of this candidate, even when logically related to the quadratic.'
 if mid.startswith(('A3.SS4.p3.','A3.Ex160')):
  return 'normalizer-remainder-not-used',[],[], 'Gaussian target/integral/determinant normalizer remains outside current gradient/value+affine endpoint.'
 return 'source-context-outside-current-endpoints',[],[], 'Preserved in frozen phase1. No current claim of algorithm counting, TV/seed/Krylov/target moments/limits or main lower-bound closure.'

formula_units=[]
for u in coverage:
 if not u['unit_kind'].endswith('formula'):continue
 status,endpoints,slots,note=formula_match(u)
 formula_units.append({'phase1_unit_id':u['unit_id'],'source_math_id':u['source']['source_element_id'],
                       'source_raw_sha256':u['source']['raw_sha256'],'source_latex':u['latex'],
                       'phase1_node_or_exclusion':u.get('node_id') or u.get('reason'),
                       'candidate_disposition':status,'endpoints':endpoints,'seven_slot_links':slots,
                       'other_slots':'No independent additional meaning; see containing source sentence and endpoint seven-slot audit.',
                       'note':note})
assert len(formula_units)==207
assert len({x['phase1_unit_id'] for x in formula_units})==207
formula_audit={
 'schema':'gc-source-only-phase2-formula-candidate-coverage-v1',
 'phase1_formula_occurrences':207,'mapped_formula_occurrences':len(formula_units),'unmapped':0,
 'rule':'Every frozen formula occurrence is either linked to relevant seven-slot matches, explicitly partial/context-only, or explicitly outside current endpoint closure. Matching source context does not mean a theorem was proved.',
 'formulas':formula_units,
}

boundaries={
 'schema':'gc-source-only-phase2-boundaries-v1',
 'closed_by_candidate_if_proved':['Actual first derivative exists at everyx and equals the literal precision matvec.','Actual quadratic value and gradient pair have the exact source first-order meaning.','Private forward same-O reference2 affine reconstruction supplies the same true first-order pair.'],
 'not_closed':{
  'C4_remainder':['C-infinity theorem','Hessian theorem','1-strong convexity theorem','kappa-smoothness theorem','unique-minimizer theorem','Gaussian normalizer/integral theorem'],
  'reply_directions':'Current private consumer is kappa-from2 forward reconstruction only; source either-direction equivalence is not fully proved by that signature.',
  'cost':'The formula uses one reference-reply expression, but no operational at-most-one-query theorem, finite horizon, adaptive transcript, stopping rule, seed or algorithm simulation is present.',
  'expected_vs_worst_cap':'S2 exact complexity uses a deterministic cap for every input and seed. No expected-cost definition/conversion or count theorem is supplied.',
  'accuracy':'No output distribution, TV guarantee, seed average, target-sampling law or finite-precision error is in these signatures.',
  'parameters':'Theorem4.1 delta,d0,epsilon and kappa<=d^(1-delta) are not required local derivative/affine premises and no larger-range/accuracy lower bound is proved.',
  '4.4':'The proof-route limitations stay intact. Current local semantics neither repairs nor overturns those limitations and does not decide whether stronger fixed-spectrum lower bounds exist.',
  'O_information':'The mathematical O binder is not permission for an algorithm to access hiddenO or choose its sign; no hidden-basis information model is formalized here.'},
 'inverse_arithmetic':{'current':'No division by kappa-1 occurs in either exact endpoint.','reverse_only':'The source reverse transformation needs kappa-1!=0, internally implied by hKappa>=2; no added nonzero binder is warranted.'},
 'source_literal_vs_inferred':{
  'literal':['S2 Eq1 actual value/gradient/precision-matvec formula','Eq11 hard-family formula','Remark4.2 same-O affine matrix identity and either matvec reply determination','C4 quadratic/C-infinity/Hessian wording'],
  'inferred':['Fin index alignment','first-derivative calculus bridge when reading C4 alone','WithLp/real-inner coordinate adapters','HasGradientAt-to-total-gradient identification','componentwise first-order affine composition'],
  'not_repaired':'No source correction or changed mathematical premise proposed.'},
}

exposures={
 'schema':'gc-source-only-phase2-definition-provenance-v1','windows':definition_windows,
 'definition_searches_only':[
  'Exact-name orthogonalGroup/unitaryGroup/EuclideanSpace/WithLp definition location scans.',
  'File-name-only lookup for WithLp/PiL2 paths. No proof API search or theorem selection.'
 ],
 'incidental_exposure':[
  {'kind':'authorized-window-overlap','detail':'Matrix.Mul696-705 includes lemma mulVec_apply and its rfl body at704-705. This was within the expressly authorized range, not an API search; it is not used as an implementation route in this audit.'},
  {'kind':'extra-name-only','detail':'EuclideanSpace definition-location regex also printed alias names equiv, proj_l, proj, single, sumEquivProd and finAddEquivProd. Bodies were not opened.'},
  {'kind':'extra-name-only','detail':'WithLp definition-location regex also printed delabToLp, equiv, map, congr, addEquiv, linearEquiv, withLpMap and withLpCongr. Bodies were not opened.'},
  {'kind':'necessary-carrier-alias','detail':'EuclideanSpace PiL2:110-114 was opened only to establish PiLp2 carrier meaning. It contains no proof.'}
 ],
 'HasGradientAt_meaning':'Real HasFDerivAtFilter with toDual of the proposed vector, at the full neighborhood ofx. This genuinely asserts derivative existence.',
 'gradient_total_definition':'Inverse Riesz of fderiv; documented zero fallback off differentiability is neutralized by the required HasGradientAt output, not assumed away.',
 'coordinate_wrapper':'WithLp is a structure with toLp constructor and ofLp field, not a covariance transform or a basis change.',
 'remaining_geometric_obligation':'The actual real l2 inner-product/coordinate dotProduct compatibility must be proved internally. No inner-product instance theorem or derivative lemma was retrieved here.',
}

clarifications={
 'schema':'gc-source-only-phase2-source-anchor-clarifications-v1',
 'phase1_original_bytes_unchanged':True,'phase1_manifest_sha256':PHASE1_HASH,
 'change_kind':'Endpoint-aware explicit source-parent/topology refinement; no candidate statement or binder changes.',
 'S2_literal_vs_C4_elaboration':{
  'literal_parent':'SRC:S2.E1:display',
  'literal_source':'FO_A(x)=(f_A(x),grad f_A(x))=(x^T A x/2,A x).',
  'source_scope':'The immediately preceding paragraph introduces A in the S2 precision class. Hard-family application therefore requires internal admissibility/symmetry discharge.',
  'C4_only':'C.4 explicitly states C-infinity and HessianA for the quadratic, but does not itself display gradV_A=Ax. Calling the gradient formula inferred is correct only as a C.4-only expansion, never as a claim that the paper omits it.',
  'phase1_limitation':'Phase1 included the exact S2.E1 display and the hard-family FO integration node, but INF:gradient itself anchored the C.4 calculus expansion. Its explicit gradient-source parent was insufficiently direct for the candidate endpoint.',
  'phase2_refinement':'OVL:S2-gradient-literal and OVL:S2-pair-literal project the literal S2 display and become explicit exact-source parents of OVL:P, with IB:P-source-admissibility retaining the source-class condition.',
  'still_elaborated_not_literal':'HasGradientAt as genuine Frechet/Riesz derivative existence and recovery of Mathlib total gradient from it are standard-meaning elaborations/proof obligations. These logical structures are not literally written in the paper.',
  'no_proof_credit':'Adding source parents clarifies provenance; it does not prove these source formulas, the candidate, or C.4 remainder.'},
 'forward_arithmetic_clarification':{
  'exact_consumer':'Forward A_kappa-from-A2 formula contains multiplication by kappa-1, no division.',
  'not_required_current_bridge':'Do not force a kappa-1 nonzero premise or inverse arithmetic into the forward closure.',
  'reverse_boundary':'Remark4.2 reverse/full-equivalence direction would internally use kappa-1!=0 from kappa>=2.'},
 'candidate_hashes_unchanged':{
  'producer':HASHES['producer-exact-signature.txt'],'consumer':HASHES['consumer-exact-signature.txt']},
}

verdict={
 'schema':'gc-source-only-phase2-advisory-verdict-v1',
 'verdict':'RECOMMEND_ADMISSION_OF_THESE_EXACT_BOUNDED_CANDIDATES_AFTER_DISTINCT_TOPOLOGY_CHALLENGE',
 'source_admission_effect':False,'status':'ADVISORY_SOURCE_FIDELITY_REVIEW_COMPLETE; DISTINCT_RAW_TOPOLOGY_CHALLENGE_PENDING',
 'producer_sha256':HASHES['producer-exact-signature.txt'],'consumer_sha256':HASHES['consumer-exact-signature.txt'],
 'candidate_seal_sha256':HASHES['preproof-exact-statement-candidate-seal.json'],'phase1_manifest_sha256':PHASE1_HASH,
 'source_fidelity_findings':['No EXCESS binder detected.','Literal grid/precision/quadratic and actual Frechet-gradient semantics match the bounded source claim.','The private consumer is a faithful forward pointwise elaboration of S2 plus the same-O affine Remark, with all correctness supplied as intended proof dependencies.'],
 'repair_required':False,'HOLD_for_mathematical_or_source_mismatch':False,
 'remaining_gates':['Distinct actor challenges raw-source coverage, topology and exact producer/consumer overlay before root claim/proof search.','Root must keep all internal bridges as proof obligations, not add convenience premises.','Ordinary compiled-code/source-blind roundtrip/source review/publication gates follow after an implementation exists.'],
 'not_certified':['any Lean proof or compiler truth','existing affine producer correctness','canonical postcompile semantic roundtrip','SOURCE_VERIFIED/SOURCE_ADMITTED','SAU claim','full C4 or lower-bound completion','operational or expected query counts'],
 'independence':'This role independently froze raw-source graph before endpoint disclosure; endpoint-aware overlay is not source-blind. It has not inspected target implementation, previous implementation proofs or other actors private artifacts.'}

readme='''# Phase 2 exact-candidate overlay v1

This advisory overlay is bound to the unchanged phase1 manifest `756e51e694cd0d720e7b7fdec87d754292f4b8a109d080e41e9c3249d949a30f` and the exact four candidate files listed in `candidate-inputs.json`. It recommends admission of these bounded signatures after a distinct raw-source/topology challenge. It does not itself admit source truth, claim an SAU, certify a Lean proof or replace the later blinded semantic round trip.

The producer faithfully asserts a genuine Frechet/Riesz gradient for the literal Eq11 precision quadratic at every real Euclidean query point, together with the exact value-gradient pair. `HasGradientAt` is an output. Symmetry, derivative existence, gradient correctness and response correctness are absent from the hypotheses and must remain internal proof obligations. `Fin d` uses the source index i=i.val+1, so its i.val+1/2 grid is exact. Full real orthogonalGroup retains both determinant signs. The WithLp wrapper preserves coordinates; query is actual precision A*x, not covariance inverse or hiddenO-only information.

The private consumer uses the same O, same grid and actual reference2 precision reply. Its forward vector is `(kappa-1)*A_2*x-(kappa-2)*x`. The exact signature does not divide by kappa-1. Nonzero kappa-1 is needed only for a separately claimed reverse direction, and follows from kappa>=2 without a new binder. The new actual-gradient producer and the actual forward affine dependency are AND ingredients. Phase1's direct-components route remains an alternative; it is not another required premise.

S2.E1 literally states both gradient Ax and the full actual value-gradient pair, for A in the precision class. Applying that source interface to every hard-familyO requires internal admissibility/symmetry discharge. C.4 alone has no standalone gradient display; the gradient is not absent from the paper. This overlay explicitly adds the S2 gradient/pair source parents and records the narrower role of phase1's C.4 calculus node in `source-anchor-clarifications.json`. HasGradientAt and total-gradient recovery remain standard-meaning elaborations and proof obligations.

The seven semantic slots are audited separately for producer and consumer. All207 formula occurrences in the frozen source slice are linked to the relevant slots or explicitly retained as context/outside the current endpoint. A context formula match does not mean that formula has been proved. In particular, the candidate does not close C-infinity, Hessian, SC, smoothness, minimizer or normalizer results from the remainder of C.4. The first-derivative projection of phase1's larger calculus node is the only intended local mathematical delta.

This is pointwise exact semantics. It does not prove a one-query operational count, an adaptive/stopping/transcript simulation, a seed/output-law/TV guarantee, finite-precision arithmetic cost, expected-cost conversion or either main lower bound. S2 budgets remain deterministic runwise caps. Theorem4.1 delta/epsilon and Section4.4 route limitations stay outside these local endpoints. O is a mathematical latent-object binder, not algorithmic disclosure of the hidden basis.

The only mathematical-library reads were the recorded definition windows. The authorized Matrix.Mul window also exposed the two-line `mulVec_apply` rfl lemma; definition-location scans showed some extra definition names without their bodies. These are recorded in `definition-provenance.json`; no proof API retrieval, proof experiment or target implementation read occurred. The supplied seal already discloses root exposure to old implementations, so this packet makes no proof-independence claim about root.
'''

def put(name,obj):files[name]=(json.dumps(obj,ensure_ascii=False,indent=2)+'\n').encode()
put('candidate-inputs.json',candidate_inputs)
put('binder-audit.json',binder_audit)
put('seven-slot-audit.json',seven_slots)
put('backward-closure-and-routes.json',closure)
put('formula-candidate-coverage.json',formula_audit)
put('definition-provenance.json',exposures)
put('source-anchor-clarifications.json',clarifications)
put('truth-boundary.json',boundaries)
put('advisory-verdict.json',verdict)
files['README.md']=readme.encode()

checks={
 'phase1_manifest_unchanged':True,'phase1_all_bound_files_rehashed_unchanged':True,
 'candidate_four_hashes_match':True,'producer_seven_slots_present':len(seven_slots['producer'])==7,
 'consumer_seven_slots_present':len(seven_slots['consumer'])==7,'all207_formula_occurrences_disposed':len(formula_units)==207,
 'all_overlay_edge_endpoints_resolve':True,'no_EXCESS_binder':not binder_audit['EXCESS'],
 'proof_or_API_work':'NOT_PERFORMED','independent_topology_challenge':'PENDING',
 'mechanical_check_limit':'These checks validate evidence shape/hash binding, not Lean truth or source topology acceptance.'}
put('structural-checks.json',checks)

manifest={
 'schema':'gc-source-only-phase2-manifest-v1','freeze_id':'gc-fixed-spectrum-first-order-source-overlay-phase2-v1-20261108',
 'phase1_manifest_sha256':PHASE1_HASH,'source_raw_sha256':SOURCE_HASH,
 'exact_candidate_seal_sha256':HASHES['preproof-exact-statement-candidate-seal.json'],
 'status':'FROZEN_ADVISORY_OVERLAY_PENDING_DISTINCT_TOPOLOGY_CHALLENGE',
 'files':[{'path':n,'bytes':len(b),'sha256':sha(b)} for n,b in sorted(files.items())],
 'no_overwrite':'Any correction requires a separately named successor; phase1 and this v1 remain exact bytes.',
 'manifest_self_hash':'manifest.sha256 hashes these exact manifest.json bytes.'}
put('manifest.json',manifest)
mh=sha(files['manifest.json'])
files['manifest.sha256']=(mh+'  manifest.json\n').encode()
for out in [PRIVATE,PUBLIC]:
 for n,b in files.items():
  p=out/n;assert not p.exists();p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
 for f in manifest['files']:
  b=(out/f['path']).read_bytes();assert sha(b)==f['sha256'] and len(b)==f['bytes']
 assert sha((out/'manifest.json').read_bytes())==mh
assert sha((PHASE1/'manifest.json').read_bytes())==PHASE1_HASH
print(json.dumps({'status':manifest['status'],'manifest_sha256':mh,'bound_files':len(manifest['files']),
                  'producer_sha256':HASHES['producer-exact-signature.txt'],'consumer_sha256':HASHES['consumer-exact-signature.txt'],
                  'formula_occurrences':len(formula_units),'overlay_nodes':len(overlay_nodes),'overlay_edges':len(overlay_edges),
                  'private_dir':str(PRIVATE.relative_to(ROOT)),'public_dir':str(PUBLIC.relative_to(ROOT)),
                  'advisory_verdict':verdict['verdict']},ensure_ascii=False,indent=2))
