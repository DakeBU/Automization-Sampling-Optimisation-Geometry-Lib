"""Mechanical projection of completed independent reviews; no lifecycle calls."""
from pathlib import Path
import ast, datetime, gzip, hashlib, json, os, shutil, subprocess, sys
sys.dont_write_bytecode = True
P = Path('.astis/huanjian-gc-fixed-spectrum-geometry-integration-20261109')
B = Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-geometry-integration-20261109')
E = Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-geometry-semantic-evidence')
N = Path('.astis/semantic-neutral-20261109/src_9a6d2f/normalpark-preparation')
C = Path('research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-geometry.json')
R = B.parent / 'README.md'
L = Path('runs/substantive_advances.jsonl')
CORE = 'b3581af0fc7e517e6cf5b883f4af064ddaa72aa2'
ADV = 'ASTIS-SA-20261109-GaussianComplexityFixedSpectrumGeometry'
sha = lambda b: hashlib.sha256(b).hexdigest()
dump = lambda x: (json.dumps(x, ensure_ascii=False, indent=2) + '\n').encode()
git = lambda *a: subprocess.check_output(['git', *a])
def ref(p):
    return {'path': str(p), 'sha256': sha(p.read_bytes())}
def get(p, expected):
    raw = p.read_bytes()
    assert sha(raw) == expected, p
    return json.loads(raw)
def fresh(p, raw):
    assert not p.exists(), p
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(raw)
def copytree(src, dst):
    assert not dst.exists(), dst
    shutil.copytree(src, dst, ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
    rows = []
    for q in src.rglob('*'):
        if not q.is_file() or '__pycache__' in q.parts or q.suffix == '.pyc':
            continue
        to = dst / q.relative_to(src)
        assert q.read_bytes() == to.read_bytes(), q
        rows.append({'original': ref(q), 'public': ref(to)})
    return rows

assert git('rev-parse', 'HEAD').decode().strip() == CORE
assert git('diff', 'HEAD', '--name-only').decode().splitlines() == [str(L)]
before_ledger = git('show', 'HEAD:' + str(L))
ledger = L.read_bytes()
append = (N/'execution/actual-normalpark-append.raw.jsonl').read_bytes()
assert sha(append) == '42ffbad99ab4e638c314d83d7c2978d3f197fe00c8f2a975381ed02cd45e395e'
assert ledger == before_ledger + append
assert sha(ledger) == '820b899aae7ed60f17711496f6a4ac556346f48dbb46eff8feefe0f20903d2b2'
execution = get(N/'execution/execution-manifest.json', '7dc16b48f54002a7eb9c5af97d2f8f304445da63e5258833c564f5b959975bae')
manifest = get(N/'execution/execution-payload-manifest.json', 'e1af4ecb3ed800cedcf5639d2ad36f1eb0cc0f7c966b6e0971afe1480661e13b')
for row in manifest['files']:
    q = N/'execution'/row['path']
    assert sha(q.read_bytes()) == row['sha256'] and q.stat().st_size == row['bytes'], q
original = json.loads((E/'actual-source-V-append.exact.json').read_bytes())
event = json.loads(append)
assert event['worker_id'] == execution['actor'] == '/root/source_reader_9a6d2f'
assert execution['normal_API_calls'] == 1
assert (event['from_state'], event['to_state']) == ('STABILIZING', 'VERIFIED')
assert len(original['evidence']) == 7
assert set(event['evidence']) == set(original['evidence']) | {'post_integration_normalpark'}
assert all(event['evidence'][k] == v for k, v in original['evidence'].items())

sys.path[:0] = ['tools', 'website/scripts']
import astis_advance as advance
import astis_site as site
states_before = advance._replay_advances([json.loads(x) for x in before_ledger.splitlines()])
states = advance._replay_advances([json.loads(x) for x in ledger.splitlines()])
assert states[ADV]['state'] == 'VERIFIED'
assert states[ADV]['owner_id'] == 'huanjian_gc_20261109_fixed_spectrum_geometry'
assert not [k for k, v in states.items() if v['state'] == 'STABILIZING']
assert {k:v for k,v in states.items() if k != ADV} == {k:v for k,v in states_before.items() if k != ADV}
assert len(states) - 1 == 285
old = C.read_bytes()
assert sha(old) == 'e38dc3ca9af01e35d980b7f031955fbd3a3b71d1a824cc5bfa69641a4fc20fa7'
old_readme = R.read_bytes()
foreign = {str(q): sha(q.read_bytes()) for q in C.parent.rglob('*.json') if q != C}
assert len(foreign) == 444
protected = [Path(q) for q in [
    'website/content/graph_memory_index.json', 'website/content/functor_hypergraph.json',
    'runs/substantive_discoveries.jsonl', 'lake-manifest.json',
    'research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-geometry.json',
    'AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumGeometry.lean',
    'Tests/GaussianComplexityFixedSpectrumGeometry.lean',
    'website/content/declaration_lessons/huanjian-fixed-spectrum-geometry.json',
    'website/content/publications/huanjian-fixed-spectrum-geometry.json',
    'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-geometry-statement-seal.json']]
protected_hashes = {str(q): sha(q.read_bytes()) for q in protected}
assert site.source_digest() == '6905b946089555464e4eedadfad3644fb4df3ee5d49ffc8445c16bb7fd997108'
accepted_private = P/'independent-reader/local-acceptance-and-eligibility-v1/local-integration-acceptance-v1.json'
accepted = get(accepted_private, '8c55eae9be56c02a891ad58b424858426b0d9ad3dab94d5fab98aadaa1bf6c58')
assert accepted['status'] == 'ACCEPTED_SCOPED_LOCAL_INTEGRATION' and accepted['immutable_core'] == CORE
assert accepted['recording_actor'] == '/root/geometry_integration_reader'
get(P/'independent-reader/original44-independent-review-v1/independent-original44-pixel-review-ACCEPT.json',
    'da97bbbbc0450626f7e86fa88b5ad56ee52feb6e6c7f1bb7426e4e310c77aad5')
for role, row in accepted['actual_acceptance_evidence']['official8_same_core_gates'].items():
    r = get(Path(row['path']), row['sha256'])
    assert r['exit_code'] == 0 and r['head_before'] == r['head_after'] == CORE, role
    assert sha(Path(r['log']).read_bytes()) == r['log_sha256'] == row['log_sha256']
copies = copytree(N, B/'original-source-verifier/normalpark-preparation')
for name in ['original44-independent-review-v1', 'local-acceptance-and-eligibility-v1']:
    copies += copytree(P/'independent-reader'/name, B/'independent-reader'/name)
for name in ['root-local-acceptance-and-normalpark-eligibility-authorization-v1.json',
             'root-normalpark-helper-and-preflight-review-v1.json',
             'root-exact-existing-V-normalpark-execution-review-v1.json']:
    fresh(B/name, (P/name).read_bytes())
fresh(B/'final-metadata-before/frontier.raw.json.gz', gzip.compress(old, mtime=0))
fresh(B/'final-metadata-before/README.raw.md.gz', gzip.compress(old_readme, mtime=0))

integration = {
    'state': 'LOCAL_ACCEPTED_EXISTING_V_RELEASED_REMOTE_PURIFICATION_OPEN',
    'accepted_immutable_core': CORE,
    'source_checked_commit': 'ab8b47caed9f781191f8408154cd355c7e7c104c',
    'source_V_first_carrying_commit': '62813df927fd3c156dd57099cc11613074d91bc0',
    'local_acceptance': ref(B/'independent-reader/local-acceptance-and-eligibility-v1/local-integration-acceptance-v1.json'),
    'normalpark_execution': ref(B/'original-source-verifier/normalpark-preparation/execution/execution-manifest.json'),
    'normalpark_append_sha256': sha(append), 'original_source_V_seven_fields_preserved': True,
    'original_source_verifier_normal_API_calls': 1, 'root_lifecycle_API_calls': 0,
    'eight_same_core_checks': ref(B/'actual-delivery-evidence-manifest.json'),
    'actual44_originals_report': ref(B/'actual-browser-v1-originals/report.json'),
    'independent_all44_pixel_review': ref(B/'independent-reader/original44-independent-review-v1/independent-original44-pixel-review-ACCEPT.json'),
    'root_actual8_original_review': ref(B/'root-actual-original8-review.json'),
    'accepted_reader_limits': accepted['actual_reader_scope']['pixel_limits_preserved_verbatim'],
    'historical_pending_at_creation_records_preserved': True,
    'preproof_obligations_are_history_not_blanket_closed': True,
    'new_source_verdict': False, 'metadata_successor_is_not_a_fresh_build': True,
    'remote_owner_release_confirmed': False, 'remote_published': False,
    'purification_or_Exposition_Seal_complete': False, 'Goal_complete': False}
boundary = ('Selected literal actual C4 six-property geometry and real private fixed-input Borel reply consumer are independently source-reviewed and locally accepted. '
    'Checked mathematical candidate ab8b47ca; original source-V first carried by62813df9; actual immutable integration/9660-job official Lean plus seven other gates/Chrome44-original desktop-mobile core b3581af0. '
    'All44 originals independently opened; root8. Original source verifier performed one existing-V normalpark, preserving all seven original evidence fields and proof owner, with only a separate post-integration block; STAB empty. '
    'Author strict angle/cosine/Hessian-criterion route and parent standalone source-audit debt remain distinct. Joint hidden-input/adaptive/private-seed/history/output laws, TV/precision/deterministic worst-query cap/explicit expected-cost adapters, moments/Krylov and both full main lower bounds, remote original-owner release/delivery and postmerge purification/Exposition Seal remain open. '
    'Later metadata packaging is not a fresh build, remote acceptance or new source verdict.')
replacements = {
    ('statement_seal','status'): 'EXACT_PRODUCER_AND_ACTUAL_CONSUMER_INDEPENDENT_SOURCE_VERIFIED_AND_LOCAL_INTEGRATION_ACCEPTED',
    ('evidence','execution_boundary'): boundary,
    ('source_detail_audit','fidelity_boundary'): boundary,
    ('source_detail_audit','gap'): 'Selected actual C4 six-property geometry and fixed-input actual Borel reply consumer proved and independently source/local-integration accepted. Author strict angle/cosine/eigenvalue prefix and Hessian-criterion route, historical parent standalone audits, joint/adaptive/precision/TV/cap/cost/main bounds and remote/purification remain separate; old preproof obligation list is retained as history, not blanket discharged.',
    ('graph_contribution','visual_review'): 'Actual core b3581af0 desktop1440/mobile390 source index, adjacent exact Lean/module/download and affected native graph reviewed. All44 current original images independently opened; root8. Three canonical producer parents and two private Test parents are kernel evidence. Twelve native geometry rows: eight have corresponding originals; four extra preset/cross-view rows plus two old DensityAffinity regressions are DOM/UI-only. Name scans remain dashed/incomplete. Existing FirstOrder typed Functor is regression only, no new Geometry transport or certified implication. Long mobile formula scrolling, code below some captured viewports and local-only delivery limits remain in the original reviews.',
    ('evidence','root_build'): str(B/'actual-core8-checks/20261109T020933433704Z-geometry-core-official-lean.receipt.json'),
    ('evidence','graph_regeneration'): str(B/'actual-core8-checks/20261109T021403945771Z-geometry-core-graph-check.receipt.json'),
    ('evidence','canonical_integration','state'): integration['state']}
# Reuse only the already independently reviewed pure JSON span parser; no
# module import/execution of the application helper, hence no mutation/API.
tree = ast.parse((P/'apply_reviewed_shared_v3.py').read_text())
fn = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'spans')
namespace = {'json': json}
exec(compile(ast.Module(body=[fn], type_ignores=[]), '<reviewed-pure-spans>', 'exec'), namespace)
text = old.decode(); spans = namespace['spans'](text); edits = []
for path, value in replacements.items():
    a, z = spans[path]
    assert isinstance(json.loads(text[a:z]), str)
    edits.append((a, z, json.dumps(value, ensure_ascii=False), list(path)))
cell = json.loads(old); last = next(reversed(cell['evidence']))
_, point = spans[('evidence',last)]
addition = ',\n' + '\n'.join('    '+x for x in ('"post_integration_acceptance": '+json.dumps(integration,ensure_ascii=False,indent=2)).splitlines())
edits.append((point, point, addition, ['evidence','post_integration_acceptance']))
chunks = []; cursor = 0; count = 0; inverse = []
for a, z, new, path in sorted(edits):
    assert a >= cursor
    chunks.append(text[cursor:a]); count += a-cursor
    inverse.append({'path':path,'before_start':a,'before_end':z,'after_start':count,'after_end':count+len(new),'old_raw':text[a:z],'new_raw':new})
    chunks.append(new); count += len(new); cursor = z
chunks.append(text[cursor:]); after = ''.join(chunks)
restored = after
for row in reversed(inverse):
    a,z = row['after_start'],row['after_end']
    assert restored[a:z] == row['new_raw']
    restored = restored[:a]+row['old_raw']+restored[z:]
assert restored.encode() == old
after_cell = json.loads(after)
for key in ['target_statement','parents','owner_id','advance_id','status','source_proof_coverage','reuse_plan']:
    assert cell[key] == after_cell[key], key
assert cell['statement_seal']['sha256'] == after_cell['statement_seal']['sha256']
C.write_bytes(after.encode())
prefix = (f'## 2026-11-09 UTC: actual fixed-spectrum geometry locally accepted; existing V released\n\n'
    f'The literal cosine-family quadratic is globally C-infinity, has genuine gradient derivative A, is1-strongly convex with kappa-Lipschitz gradient, and has value0 uniquely minimized at0. Its real private fixed-input Borel reply consumer materially uses the new producer. Independent source/whole-module/fresh-Lean review checked `ab8b47caed9f781191f8408154cd355c7e7c104c`; source V first occurs in62813df9. Local integration is accepted at immutable `{CORE}`: official9660-job Lean/Tests, all8 same-core gates and actual Chrome1440/390. All44 original PNGs were independently opened; root8. Viewport/long-formula/local-only delivery limits remain explicit.\n\n'
    'The ORIGINAL source verifier made one normal existing-V release, preserving all7 original evidence fields and proof owner and adding only the separate post-integration layer; STAB is empty. This metadata successor is not a fresh build, a new source verdict or a remote release. No JS/CSS change was needed. See `fixed-spectrum-geometry-integration-20261109/resume-checkpoint.json`.\n\n'
    'Both complete main lower bounds, moments/Krylov, joint/adaptive/private-seed/history/output-law, TV/finiteprecision/deterministic worst-cap/explicit expected-cost adapters, author alternate C4 route and historical parent standalone audits, remote original-owner release/publication and postmerge purification/Exposition Seal remain open. Raw-only independent Lemma4.5/AppendixC.3 source graph phase1 is frozen; no next exact statement seal, target proof/API search or new mathematical claim has begun. Continue the same Goal, root sole mathworker, with all other states/frontiers/queues preserved. Earlier headings below remain phase history.\n\n')
R.write_bytes(prefix.encode()+old_readme)
checkpoint = dict(integration, recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    source_digest=site.source_digest(), accepted_source_audit=ref(Path('research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-geometry.json')),
    current_ledger_sha256=sha(ledger), STAB=[], truth_boundary=boundary,
    next='First commit this evidence/metadata-only projection after focused checks. Then choose the next minimal actual-consumer packet from frozen raw-source Lemma4.5/AppendixC.3 cognition; audit and seal exact binders/definitions, obtain a distinct independent topology challenge/admission before target proof/API search. Continue both full main bounds and adapters.')
fresh(B/'resume-checkpoint.json', dump(checkpoint))
assert L.read_bytes() == ledger and R.read_bytes().endswith(old_readme)
assert foreign == {str(q):sha(q.read_bytes()) for q in C.parent.rglob('*.json') if q != C}
assert all(sha(Path(name).read_bytes()) == h for name,h in protected_hashes.items())
assert site.source_digest() == '6905b946089555464e4eedadfad3644fb4df3ee5d49ffc8445c16bb7fd997108'
fresh(B/'final-local-metadata-projection.json', dump({
    'state':'ROOT_MECHANICAL_PROJECTION_OF_COMPLETED_INDEPENDENT_ACCEPTANCE_AND_ORIGINAL_ACTOR_RELEASE',
    'core':CORE,'frontier_before_sha256':sha(old),'frontier_after':ref(C),'lossless_edits':inverse,
    'inverse_restores_all_old_frontier_bytes':True,'README_before_sha256':sha(old_readme),'README_after':ref(R),
    'old_README_exact_suffix_preserved':True,'foreign_frontiers_preserved':len(foreign),
    'foreign_SAU_states_preserved':len(states)-1,'protected_raw_hashes':protected_hashes,
    'ledger_after_original_actor_one_normalpark':sha(ledger),'original_V_seven_fields_preserved':True,
    'root_lifecycle_API_calls':0,'new_source_verdict':False,'fresh_build_or_remote_or_purification_or_Goal_credit':False,
    'actual_original_evidence_copies':copies,'source_digest_unchanged':site.source_digest()}))
print(json.dumps({'metadata_projection':ref(B/'final-local-metadata-projection.json'),
    'evidence_files_copied':len(copies),'foreign_frontiers_preserved':len(foreign),
    'STAB':[],'Goal_complete':False}))
