# Phase 1: original-source cognition, before candidate exposure

Reader/run: `/root/targetlaw_fresh_source_9c7d21`.
Role in this run: independent original-source reader; neither formalizer nor decoder.
This document records the pinned paper's mathematical content and its invoked background. It issues no candidate-fidelity verdict and no source-validity verdict.

## 1. Source and scope

The only mathematical source input is the raw HTML of *On Complexity of Gaussian Sampling*, pinned as `.astis/huanjian-resume-20261103/2610.20492v1.html`: 951991 bytes, SHA-256 `6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915`.

I read the complete selected regions `S2`, `S4.SS1`, `S4.SS2.SSS0.Px3`, `A3.SS3`, and `A3.SS4`. I also read all of `S4.SS2` as immediately surrounding raw-paper context, and the raw bibliography entry `bib.bib3` reached by the source's own reference [22]. These are preserved as exact UTF-8 byte slices, with offsets/hashes in `source_inventory.json`. Human-readable `rendered/*.txt` use the HTML's decoded math `alttext`, not an inferred translation of MathML. The raw slices remain authoritative.

The assigned bounded subject is source Gaussian laws and target norm moments. The precise statement or definition that will later be compared is unknown to me at this freeze. No Lean statement, source seal, candidate definition, candidate proof, authored exposition, anonymous reconstruction, semantic registry, implementation source graph, prior semantic verdict, or repair proposal was read. The procedural documents and exposure limitations are separately enumerated in `phase1_input_exposure_ledger.md`.

## 2. Objects, carriers, standing parameters, and notation

From `S2.p1`, the norm is the Euclidean norm on real finite-dimensional vectors; `I_d` is the real `d × d` identity. For real symmetric matrices, `A ≼ B` means that `B − A` is positive semidefinite.

From `S2.p2`, `O(n) = {O ∈ R^{n×n} : OᵀO = I_n}` is equipped with Haar **probability** measure. Its determinant `+1` and `−1` components each have probability `1/2`; the notation `μ_{n,b}` denotes Haar probability conditioned on determinant `b ∈ {−1,+1}`. The target-moment calculation does not introduce a determinant-component conditioning.

The general precision class in `S2.SS0.SSS0.Px1.p1` has an integer `d ≥ 1` and a real parameter `κ ≥ 1`:

\[
\mathcal A_{d,\kappa}=\{A\in\mathbb R^{d\times d}: A=A^\top,\ I_d\preceq A\preceq\kappa I_d\}.
\]

An input is a precision matrix `A` from this class. It specifies

\[
f_A(x)=\tfrac12x^\top Ax,\qquad \pi_A=N(0,A^{-1}),\qquad x\in\mathbb R^d.
\]

Thus the mean vector is zero and the covariance matrix in the target notation is **the inverse of the input precision matrix**. The lower spectral bound makes the inverse nondegenerate. The paper deliberately restricts to centered Gaussians to remove target-location hardness. The spectral normalization to `1` and `κ` is presented as a rescaling convention.

The hard family in `S4.SS1.p1` narrows the parameter range to integers `d ≥ 2` and real `κ ≥ 2`, with coordinate indices `i = 1,…,d`:

\[
\theta_i=\frac{(i-\tfrac12)\pi}{d},\qquad
\lambda_i=\frac{\kappa+1}{2}+\frac{\kappa-1}{2}\cos\theta_i,\qquad
\Lambda=\operatorname{diag}(\lambda_1,\ldots,\lambda_d).
\]

The spectrum and all these numbers are deterministic. One draws `O ∼ Haar(O(d))`, independently of the algorithm's private randomness, and sets `A = OΛOᵀ`. For this input the potential is still `xᵀAx/2` and the target is still `N(0,A^{-1})`. The spectrum may be supplied to the algorithm. The unknown component is the eigenbasis `O`.

## 3. Probability and expectation senses

There are distinct probability roles in the selected source.

1. **Input prior:** the hard-family rotation `O` is Haar random. This is a law on real orthogonal matrices.
2. **Algorithm experiment:** a randomized algorithm uses input-independent internal randomness, and Borel query/stopping/output functions of this randomness and the previous replies. Its output `X` has a law `ρ_A^Alg` for each fixed input `A`. The total variation accuracy requirement averages all internal randomness and is uniform over inputs. Query budgets are deterministic per-run caps.
3. **Exact target experiment:** for each rotation, an exact target draw satisfies `Y | O ∼ π_A`. In `S4.SS2.SSS0.Px3.p2`, the source sets `U = OᵀY` and states that its law is `N(0,Λ^{-1})`. Orthogonality gives the pointwise identities

\[
\|Y\|^2=\|U\|^2,\qquad
Y^\top O D_n O^\top Y=U^\top D_nU.
\]

The source-moment lemma itself begins directly with `U ∼ N(0,Λ^{-1})`; its expectations and variances are with respect to this Gaussian law. In the target-sample interpretation, the same numbers describe the target statistics for a fixed `O`, and hence also after averaging the random rotation. The source's conditional target specification must be retained when discussing `Y`; it does not specify one Gaussian covariance for the unconditioned Haar-mixture law of `Y`.

For `U`, `Λ^{-1}` is diagonal with diagonal entries `1/λ_i`. Appendix `A3.SS3.p8` explicitly uses: the coordinates `U_i` are independent; each is centered Gaussian with variance `1/λ_i`; `E U_i^4 = 3/λ_i^2`; and `Var(U_i^2) = 2/λ_i^2`. Appendix `A3.SS3.p4` explicitly uses `E U_i^2 = 1/λ_i`. These are consequences of the specified Gaussian law in the source argument, not additional premises imposed on a target law.

The scalar statistic `||U||²` is the squared Euclidean norm. Its expectation `E||U||²` must be kept distinct from a square of an expected norm. The paper uses ordinary scalar expectation/variance for these real statistics. Finite moments are supplied by the Gaussian facts invoked in its proof; the lemma does not list a separate integrability assumption.

The paper's `TV(P,Q)` is the supremum over measurable sets, equivalently half the integral of the absolute density difference against a common dominating measure. For measurable `[0,1]`-valued `h`, the difference of expectations is at most TV. This contextual accuracy notion is not a premise of the exact target-moment lemma.

## 4. Exact target moments and ranges in Lemma 4.5

`S4.Thmtheorem5` is Lemma 4.5, “Moments under the target.” It assumes `κ ≥ 2`, the hard-family `Λ`, and `U ∼ N(0,Λ^{-1})`. Define

\[
r=\varrho_\kappa=\frac{\sqrt\kappa-1}{\sqrt\kappa+1}.
\]

For an integer `1 ≤ n < d`, set

\[
D_n=\operatorname{diag}(\cos(n\theta_i)),\qquad
M=\mathbb E\|U\|^2,\qquad
\mu_n=\mathbb E[U^\top D_nU].
\]

The exact conclusions are

\[
M=\frac d{\sqrt\kappa}\frac{1-r^{2d}}{1+r^{2d}},\qquad
(-1)^n\mu_n=\frac d{\sqrt\kappa}\frac{r^n-r^{2d-n}}{1+r^{2d}}.
\]

The same lemma states

\[
\operatorname{Var}(\|U\|^2)\le 2M\le\frac{2d}{\sqrt\kappa},\qquad
\operatorname{Var}(U^\top D_nU)\le 2M\le\frac{2d}{\sqrt\kappa}.
\]

If the additional separation condition `d − n ≥ √κ` holds, it further states

\[
(1-e^{-4})e^{-3n/\sqrt\kappa}
\le\frac{|\mu_n|}{M}\le e^{-2n/\sqrt\kappa}.
\]

The constants `2`, `3`, `4`, and `1 − e^{−4}` are explicit numerical constants. The dimension and conditioning dependence are shown in the formulas. There is no unspecified algorithm-dependent constant in these moment conclusions. The source's `κ ≥ 2` is used in the logarithmic estimate in Appendix C.3. All exact moment identities and variance bounds precede the extra `d − n` condition; that extra condition applies to the displayed normalized-bias estimate. The strict upper endpoint `n < d` and inclusive lower endpoint `n ≥ 1` are stated. No assertion for `n = 0`, `n = d`, or `κ = 1` is included by this lemma.

The surrounding Krylov application uses `n = 2q+1`, but the target-moment lemma quantifies over every integer `1 ≤ n < d`; its own statement imposes neither odd parity nor a query budget. The source's sign formula `(-1)^n μ_n` retains the parity dependence even when the later application chooses an odd frequency.

## 5. The source's argument in Appendix C.3

The following is a reconstruction of the **source's displayed argument**, rather than a new proof route or a judgment of a candidate implementation.

### Inverse-spectrum expansion: Fact C.7

`A3.Thmtheorem7` states for every real `θ`:

\[
\frac{2}{\kappa+1+(\kappa-1)\cos\theta}
=\frac1{\sqrt\kappa}\left(1+2\sum_{j\ge1}(-r)^j\cos(j\theta)\right),
\]

and the series is absolutely and uniformly convergent in `θ`. Its proof uses `0 < r < 1`, rewrites the cosine geometric series with complex exponentials, and obtains

\[
1+2\sum_{j\ge1}(-r)^j\cos(j\theta)
=\frac{1-r^2}{1+2r\cos\theta+r^2}.
\]

It then uses `(1−r)/(1+r)=1/√κ` and

\[
\frac{1+2r\cos\theta+r^2}{(1-r)^2}
=\frac{\kappa+1+(\kappa-1)\cos\theta}{2}.
\]

The uniform absolute majorant is `Σ_{j≥1} r^j = r/(1−r)`. The complex exponentials are part of this deterministic analytic identity; the Gaussian vectors and matrices in the target calculation are real.

### Finite-grid sums and exact moments: Fact C.8

`A3.Thmtheorem8` restates the two exact formulas for `M` and `(-1)^n μ_n`. Its proof first records, for every integer `k`,

\[
\sum_{i=1}^d\cos(k\theta_i)=
\begin{cases}
d(-1)^a,&k=2ad,\ a\in\mathbb Z,\\
0,&k\notin2d\mathbb Z.
\end{cases}
\]

For the second case the proof uses the finite cosine sum `sin(kπ)/(2 sin(kπ/(2d))) = 0`; for the first case it evaluates every summand as `(-1)^a`. The proof then passes from Gaussian coordinates to the deterministic inverse-spectrum sums

\[
M=\sum_i\lambda_i^{-1},\qquad
\mu_n=\sum_i\cos(n\theta_i)\lambda_i^{-1}.
\]

Fact C.7 permits interchange of its absolutely convergent series with the finite grid sum. For `M`, precisely `j = 2ad`, `a ≥ 1`, survive, yielding

\[
M=\frac d{\sqrt\kappa}\left(1+2\sum_{a\ge1}(-1)^a r^{2ad}\right)
=\frac d{\sqrt\kappa}\frac{1-r^{2d}}{1+r^{2d}}.
\]

For `μ_n`, the zero-frequency term vanishes because `1 ≤ n < d`. The product-to-sum identity gives

\[
\mu_n=\frac1{\sqrt\kappa}\sum_{j\ge1}(-r)^j
\left[\sum_i\cos((j-n)\theta_i)+\sum_i\cos((j+n)\theta_i)\right].
\]

The surviving classes are `j = n`, `j = 2ad+n`, and `j = 2ad−n` for `a ≥ 1`. The source explicitly uses `1 ≤ n < d` to make these three classes disjoint. The signs use `(-r)^{2ad±n} = (-1)^n r^{2ad±n}`. Summing the geometric tails gives

\[
(-1)^n\mu_n
=\frac d{\sqrt\kappa}\left[r^n+\sum_{a\ge1}(-1)^a(r^{2ad+n}+r^{2ad-n})\right]
=\frac d{\sqrt\kappa}\frac{r^n-r^{2d-n}}{1+r^{2d}}.
\]

### Variances

`A3.SS3.p7` invokes Fact C.8 for the asserted means. In `A3.SS3.p8`, diagonal Gaussian covariance supplies independent coordinates and their second/fourth moments. With `λ_i ≥ 1`, the proof writes

\[
\operatorname{Var}(\|U\|^2)=2\sum_i\lambda_i^{-2}
\le2\sum_i\lambda_i^{-1}=2M,
\]

\[
\operatorname{Var}(U^\top D_nU)
=2\sum_i\frac{\cos^2(n\theta_i)}{\lambda_i^2}\le2M.
\]

The exact formula for `M` then supplies `M ≤ d/√κ`. The source treats the finite-sum variance calculation as part of the proof; it does not replace it by a moment-bound hypothesis on the input law.

### Normalized bias

`A3.SS3.p9` uses `n < d` and `0 < r < 1` to obtain `(-1)^n μ_n > 0`. Division of the two exact moment formulas gives

\[
\frac{|\mu_n|}{M}=r^n\frac{1-r^{2(d-n)}}{1-r^{2d}},\qquad
1-r^{2(d-n)}\le\frac{1-r^{2(d-n)}}{1-r^{2d}}\le1.
\]

`A3.SS3.p10` writes

\[
\log(1/r)=\log\frac{\sqrt\kappa+1}{\sqrt\kappa-1}
=2\int_0^{1/\sqrt\kappa}\frac{dt}{1-t^2}
=\frac2{\sqrt\kappa}+2\int_0^{1/\sqrt\kappa}\frac{t^2}{1-t^2}\,dt.
\]

The nonnegative remainder gives the lower bound `2/√κ`. Bounding the denominator below by `1−κ^{-1}` and using `κ ≥ 2` gives the upper estimates

\[
\log(1/r)\le\frac2{\sqrt\kappa}\left(1+\frac1{3(\kappa-1)}\right)
\le\frac8{3\sqrt\kappa}<\frac3{\sqrt\kappa}.
\]

Exponentiation yields `e^{−3n/√κ} ≤ r^n ≤ e^{−2n/√κ}`. Finally, `A3.SS3.p11` uses `d−n ≥ √κ` and the lower logarithm bound to get `r^{2(d−n)} ≤ e^{−4}`. Combining these inequalities gives the source's final normalized-bias interval.

## 6. Admissibility and normalizer argument in Appendix C.4

The source's Lemma 4.6 states that for **every** real orthogonal `O`, `A = OΛOᵀ` satisfies `I_d ≼ A ≼ κ I_d`. Its source proof in `A3.SS4.p1` starts from `0 < θ_i < π`, giving `−1 < cos θ_i < 1` and hence `1 < λ_i < κ`; orthogonal conjugation supplies the matrix bounds.

`A3.SS4.p2` calls the same quadratic potential `V_A(x)=xᵀAx/2`. It is smooth with Hessian `A`, is `1`-strongly convex and `κ`-smooth, and has value zero at zero and value at least `||x||²/2 > 0` for nonzero `x`. Thus the source identifies zero as its unique minimizer.

`A3.SS4.p3` identifies the associated target as `N(0,A^{-1})` and invokes Gaussian integration for

\[
Z_A=(2\pi)^{d/2}(\det A)^{-1/2}
=(2\pi)^{d/2}(\det\Lambda)^{-1/2}.
\]

Because `Λ` is fixed, this is independent of the rotation and known whenever the spectrum is public. The selected passages do not separately define a measure-theoretic Gaussian construction, nor display a defining integral for `Z_A`; “Gaussian integration” uses the standard Euclidean Gaussian normalization convention. A precise density/base-measure construction is therefore background to be identified, not a construction recovered from candidate code.

## 7. Source-region accounting and contextual boundaries

| Raw region | Content retained in this cognition | Boundary |
|---|---|---|
| `S2.p1–p2` | Euclidean norm, matrix order, orthogonal/Haar conventions | Standing notation |
| `S2.SS0.SSS0.Px1`, `S2.E1` | Precision class, centered target, quadratic potential, exact first-order/matrix-vector equivalence | Defines input/target objects; no target-moment assumption |
| `S2.SS0.SSS0.Px2–Px4`, `S2.E2` | Borel randomized algorithms, uniform TV accuracy, deterministic query caps | Context distinct from exact target law |
| `S4.SS1.p1–p2`, `S4.E11` | Cosine grid, deterministic spectrum, Haar rotation, public-spectrum convention | Hard-family standing assumptions |
| `S4.Thmtheorem2` | `κ=2` comparison and informal cosine-bias motivation | Context only; no asymptotic constant replaces Lemma 4.5's explicit constants |
| `S4.SS2.p1` | Four-lemma organization | Context only |
| `S4.SS2.SSS0.Px1` | Gaussian-generated block Krylov output representation; coefficients may depend on experiment | Context preserved; proof in C.1 is outside the assigned selected proof regions |
| `S4.SS2.SSS0.Px2` | `n=2q+1`, `D_n`, uniform Krylov bound with absolute `C`, `τ_{d,q}≤1/2`, probability `0.99` | Context preserved; proof in C.2 is outside the assigned selected proof regions; these premises are not inherited by Lemma 4.5 |
| `S4.SS2.SSS0.Px3`, `S4.Thmtheorem5`, `S4.EGx1`, `S4.Ex17` | Complete target-moment statement and rotated-target explanatory paragraph | Core subject |
| `S4.SS2.SSS0.Px4`, `S4.Thmtheorem6` | Every-rotation admissibility statement | Core distribution/precision context |
| `A3.SS3.p1`, Fact C.7 and its proof | Complete inverse-spectrum expansion, absolute/uniform convergence | Deterministic analytic dependency |
| Fact C.8, `A3.SS3.p3–p6`, `A3.Ex139–Ex144`, `A3.EGx15–EGx16` | Complete finite-grid summation and exact means | Deterministic sums plus Gaussian second moments |
| `A3.SS3.p7–p8`, `A3.EGx17` | Mean invocation, coordinate fourth moments, both variance calculations | Gaussian background invoked inside proof |
| `A3.SS3.p9–p11`, `A3.Ex150–Ex159`, `A3.EGx18–EGx19` | Complete sign, ratio, logarithmic and boundary-separation argument | Extra separation only in final bias bound |
| `A3.SS4.p1–p3`, `A3.Ex160` | Complete admissibility, quadratic-potential and normalizer argument | Standard Gaussian integration invoked |
| `bib.bib3` | [22], OpenAI (2026), *Subpolynomial query complexity for well-conditioned log-concave sampling*, OpenAI Math Release preprint | Bibliographic provenance only; external text was not opened |

Source reference [22] appears in the selected hard-family and deferred-rotation context. Appendix C.3 and C.4 contain no external citation supplying an explicit Gaussian-construction theorem. This phase reads no external preprint, library, API documentation, implementation graph, or old source review to fill that background.

## 8. Background left explicit rather than inferred from implementation

The following mathematical facts/conventions are used or named by the selected source but not developed there into full foundational constructions:

- The real multivariate Gaussian probability `N(m,Σ)` on Euclidean Borel space, and the interpretation of `Σ` as covariance.
- The linear-image rule for a Gaussian under the orthogonal map used to pass from conditional target `Y` to `U`; in particular the covariance conjugation and the zero mean.
- Independence of coordinates for the diagonal-covariance Gaussian and its one-dimensional second and fourth moments, including finiteness.
- Linearity of finite-sum expectation and the finite-sum variance formulas under independence, used for the norm and cosine quadratic form.
- Gaussian integration for the positive-definite quadratic target and the determinant normalizer.
- Basic spectral behavior under orthogonal conjugation, positive-definite inversion, geometric-series/product-to-sum/finite-cosine-sum identities, and the logarithmic integral identity used in the deterministic calculation.

These are identified as invoked background, with no claim here that an implementation already supplies them and no proposal to assume their conclusions as public target hypotheses. The paper is explicit about the Gaussian law, its mean, its covariance, and the scalar moment consequences that its proof uses. It is not explicit in these selected passages about a particular formal definition of a Gaussian measure, density construction, or conditional-probability API.

## 9. Freeze boundary

No later candidate material has informed this document. Subsequent comparison must preserve this phase-1 file and its hashes and must state any further exposure separately. Exact artifact identity, permissions, procedural-input hashes, source slice hashes, and the exposure ledger are bound by the manifest and receipt. Phase 1 stops before any selective anonymous reconstruction/type/definition packet is supplied.
