from pathlib import Path
from html.parser import HTMLParser
from html import unescape
import re,json,hashlib
ROOT=Path('/Users/zhouhuanjian/ASTIS-GC')
OWN=ROOT/'.astis/semantic-neutral-20261110/z_sg_7d14a2'
SOURCE=ROOT/'.astis/huanjian-resume-20261103/2610.20492v1.html'
b=SOURCE.read_bytes()
assert len(b)==951991 and hashlib.sha256(b).hexdigest()=='6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
void={b'area',b'base',b'br',b'col',b'embed',b'hr',b'img',b'input',b'link',b'meta',b'param',b'source',b'track',b'wbr'}
stack=[]; spans={}
for m in re.finditer(rb'<(/?)([A-Za-z][A-Za-z0-9:_-]*)\b([^<>]*?)>',b):
 close,tag,attrs=m.group(1),m.group(2).lower(),m.group(3)
 if close:
  assert stack and stack[-1][0]==tag,(m.start(),tag,stack[-1] if stack else None)
  otag,start,id=stack.pop()
  if id: spans[id]={'anchor':id,'start_byte':start,'end_byte_exclusive':m.end(),'tag':tag.decode()}
 elif tag not in void and not attrs.rstrip().endswith(b'/'):
  im=re.search(rb'\bid="([^"]+)"',attrs)
  stack.append((tag,m.start(),im.group(1).decode() if im else None))
class Text(HTMLParser):
 def __init__(self):super().__init__();self.parts=[];self.math=0
 def handle_starttag(self,tag,attrs):
  a=dict(attrs)
  if tag=='math':
   self.parts.append('$'+a.get('alttext','[NO ALTTEXT]')+'$');self.math+=1
  elif not self.math and tag in ('p','h2','h3','h4','h5','h6','tr'):self.parts.append('\n')
 def handle_endtag(self,tag):
  if tag=='math':self.math-=1
  elif not self.math and tag in ('p','h2','h3','h4','h5','h6','tr'):self.parts.append('\n')
 def handle_data(self,s):
  if not self.math:self.parts.append(s)
def txt(raw):
 p=Text();p.feed(raw.decode());return re.sub(r'\n[ \t\n]+','\n',re.sub(r'[ \t]+',' ',''.join(p.parts))).strip()
fragments=['S2','S3.p1','S3.Thmtheorem1','S3.SS3.p1','S3.SS3.SSS0.Px1']
(OWN/'raw-original.html').write_bytes(b)
records=[]
for a in fragments:
 rec=spans[a].copy();raw=b[rec['start_byte']:rec['end_byte_exclusive']]
 rec.update(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),file='raw-'+a+'.html')
 (OWN/rec['file']).write_bytes(raw);records.append(rec)
 (OWN/('derivative-'+a+'.txt')).write_text(txt(raw)+'\n')
selected=[]
for a,rec in spans.items():
 if any(spans[f]['start_byte']<=rec['start_byte'] and rec['end_byte_exclusive']<=spans[f]['end_byte_exclusive'] for f in fragments):
  raw=b[rec['start_byte']:rec['end_byte_exclusive']];r=rec.copy();r.update(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
  if rec['tag']=='math':
   alt=re.search(rb'\balttext="([^"]*)"',raw);r['alttext']=unescape(alt.group(1).decode()) if alt else None
  elif rec['tag'] in ('p','h2','h3','h4','h5','h6'):r['derivative_text']=txt(raw)
  selected.append(r)
(OWN/'raw-fragment-index.json').write_text(json.dumps({'primary_source':str(SOURCE),'source_bytes':len(b),'source_sha256':hashlib.sha256(b).hexdigest(),'offset_convention':'zero-based byte offsets [start_byte,end_byte_exclusive) in pinned raw original; UTF-8; no normalization','fragments':records,'elements':sorted(selected,key=lambda x:(x['start_byte'],-x['end_byte_exclusive']))},indent=2,ensure_ascii=False)+'\n')
print(json.dumps(records,indent=2));
for a in fragments:print('\nDERIVATIVE',a,'\n'+(OWN/('derivative-'+a+'.txt')).read_text())
