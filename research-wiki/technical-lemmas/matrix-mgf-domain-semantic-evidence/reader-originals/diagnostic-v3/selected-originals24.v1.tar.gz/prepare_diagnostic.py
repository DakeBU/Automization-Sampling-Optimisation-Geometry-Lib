"""Syntax/pin preparation only; no Chrome, server, or fixture render."""
import ast, datetime as dt, hashlib, json, os, subprocess, sys, time, traceback
from pathlib import Path
OWN=Path(__file__).resolve().parent;REPO=OWN.parents[2]
PREVIEW=REPO/'.astis/huanjian-gc-matrix-mgf-domain-20261115/reader-preview-v1/static-closure-v3'
ORIGINAL=REPO/'.astis/semantic-neutral-20261115/matrix_domain_reader_61e4'
PYTHON=REPO/'.astis/huanjian-gc-integration-20261105/browser-venv/bin/python'
NODE=REPO/'.astis/huanjian-gc-integration-20261105/browser-venv/lib/python3.12/site-packages/playwright/driver/node'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,x):
    with Path(p).open('x') as f:f.write(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def main():
    checks=[]
    def check(name,ok,detail=None):
        checks.append({'name':name,'pass':bool(ok),'detail':detail})
        if not ok:raise AssertionError(name)
    script=OWN/'diagnose_v3.py';tree=ast.parse(script.read_text())
    check('new-script-Python-AST',True)
    strings=[ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id in ['SAMPLE','OVERFLOW']]
    for n in ast.walk(tree):
        if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr in ['evaluate','wait_for_function'] and n.args and isinstance(n.args[0],ast.Constant) and isinstance(n.args[0].value,str):strings.append(n.args[0].value)
    for i,s in enumerate(strings):
        r=subprocess.run([str(NODE),'--check'],input='('+s+');',capture_output=True,text=True)
        check('actual-node-check-JS-'+str(i),r.returncode==0,{'actual_exit_code':r.returncode,'stdout':r.stdout,'stderr':r.stderr})
    check('no-programmed-scroll-or-transform',not any(x in script.read_text() for x in ['scrollIntoView','scrollTo(','scrollBy(','style.transform','setAttribute(\'transform']))
    check('no-API-Lean-Git-subprocess-in-runtime',not any(isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and isinstance(n.func.value,ast.Name) and n.func.value.id=='subprocess' for n in ast.walk(tree)))
    check('exact-original-v3-pin',sha(PREVIEW/'preview-freeze-manifest.json')=='cb35d92094afe575fc6dfa96e2960508bd5c4e699f3c46e5d19c521afc697965')
    original=json.loads((ORIGINAL/'execution-assignment.json').read_text())
    frozen=[PREVIEW/'preview-freeze-manifest.json',PREVIEW/'input-freeze-manifest.json',ORIGINAL/'actual-result.json',ORIGINAL/'browser_check.py',ORIGINAL/'browser_geometry.py',ORIGINAL/'execution-assignment.json']
    check('original-FAIL-result-pin',sha(frozen[2])=='74fd21200be988619c1ff27fd253049cc84c96641461aaf3fb54ca52beb9384f')
    check('actual-Chrome-binary-current-pin',sha(original['chrome']['path'])==original['chrome']['binary_sha256'])
    draft={'schema':'R17-new-observational-diagnostic-assignment-v1','authorization':'PREPARED_ONLY_AWAIT_ROOT_REVIEW_AND_FRESH_SCOPED_APPROVAL','diagnostic_script_sha256':sha(script),'preview_root':str(PREVIEW),'frozen_inputs':[{'path':str(p),'sha256':sha(p)} for p in frozen],'chrome':original['chrome'],'scope':'Only original-v3 step5 source click / networkidle immediate geometry and natural stable-or-5s samples in desktop1440x1000/mobile390x844, plus mobile original T module actual disclosure clicks and read-only overflow-owner/ancestor computed metrics. No acceptance rerun, no programmed anchor scrolling/transform, no UI repair, no mathematical/source/normalAPI credit.','stability_observation':{'four_samples_100ms_apart_max_delta_css_px':.25,'minimum_elapsed_ms':500,'maximum_elapsed_seconds':5},'planned_screenshots':5,'planned_command':[str(PYTHON),str(script),'--assignment',str(OWN/'execution-assignment.json')]}
    write(OWN/'execution-assignment.draft.json',draft)
    check('no-browser-runtime-exists',not any((OWN/p).exists() for p in ['runtime-process','runtime-output','actual-diagnostic.json','chrome-tmp','execution-assignment.json']))
    report={'schema':'R17-observational-diagnostic-preparation-v1','status':'PREPARED_ONLY_NO_BROWSER','checks':checks,'JavaScript_syntax_checks':len(strings),'diagnostic_script_sha256':sha(script),'draft_assignment_sha256':sha(OWN/'execution-assignment.draft.json'),'original_v3_runtime_still_FAIL':True,'original_result_unchanged':sha(ORIGINAL/'actual-result.json'),'important_mechanical_boundary':'Summary clicks use normal Playwright click auto-reveal. After step5 source.click and networkidle, only DOM/layout reads, observation waits, and PNG capture occur before trace completes; no manual scroll. Mobile module opens every main details by actual summary clicks; it does not inherit the original later pre-centering write. All oversized elements and ancestor computed metrics are recorded, including offscreen declaration excerpt and locally clipped pre content.','planned_command':draft['planned_command'],'root_must_create_new_authorized_assignment_and_request_fresh_scoped_browser_approval':True}
    write(OWN/'preparation-result.json',report)
    print(json.dumps({'status':report['status'],'script_sha256':report['diagnostic_script_sha256'],'draft_assignment_sha256':report['draft_assignment_sha256'],'checks':len(checks),'JS_syntax_checks':len(strings),'preparation_result_sha256':sha(OWN/'preparation-result.json')}))
if __name__=='__main__':
    p=OWN/'static-process';p.mkdir(exist_ok=False)
    for fd,n in [(1,'stdout.raw'),(2,'stderr.raw')]:
        f=(p/n).open('xb',buffering=0);os.dup2(f.fileno(),fd);f.close()
    utc=dt.datetime.now(dt.timezone.utc).isoformat();start=time.monotonic();code=0
    try:main()
    except BaseException:traceback.print_exc();code=1
    sys.stdout.flush();sys.stderr.flush()
    write(p/'receipt.json',{'schema':'R17-actual-observational-diagnostic-preparation-OS-receipt-v1','argv':[sys.executable,*sys.argv],'cwd':str(Path.cwd()),'pid':os.getpid(),'started_utc':utc,'ended_utc':dt.datetime.now(dt.timezone.utc).isoformat(),'elapsed_seconds':time.monotonic()-start,'actual_exit_code':code,'script_sha256':sha(__file__),'stdout_sha256':sha(p/'stdout.raw'),'stderr_sha256':sha(p/'stderr.raw'),'no_browser_server_render_or_API':True})
    sys.exit(code)
