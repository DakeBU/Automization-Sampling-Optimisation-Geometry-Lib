#!/opt/anaconda3/bin/python
import hashlib,json,pathlib,re,stat,tarfile
BASE=pathlib.Path(__file__).resolve().parent;ROLE=BASE.parent
ROOT=pathlib.Path('/Users/zhouhuanjian/ASTIS-GC')
def sha(data):return hashlib.sha256(data).hexdigest()
manifest=json.loads((BASE/'inputs/fresh-native-0a91de-original-freeze-manifest.json').read_text())
with tarfile.open(BASE/'inputs/fresh-native-0a91de-all-original-files.lossless-file-bytes.tar.gz','r:gz') as tf:
    native_raw=tf.extractfile('raw/independent_kernel.stdout').read()
expected=next(r for r in manifest['files'] if r['path']=='raw/independent_kernel.stdout')
assert len(native_raw)==expected['bytes'] and sha(native_raw)==expected['sha256']
(BASE/'native-selected/raw__independent_kernel.stdout').write_bytes(native_raw)
lines=native_raw.decode().splitlines()
passes=[line for line in lines if 'ROOT_CLOSED_EXACT_PROP_KERNEL_PASS ' in line]
parents=[line for line in lines if 'ROOT_FIRST_PUBLIC_ASTIS_PARENTS ' in line]
axioms=[line for line in lines if 'OWNED_RECURSIVE_AXIOMS_REACHABLE_CLOSED ' in line]
count=[line for line in lines if 'OWNED_MODULE_PROVENANCE_INVENTORY_COUNT ' in line]
assert len(passes)==2 and len(parents)==2 and len(axioms)==26 and len(count)==1
assert count[0].rstrip().endswith('26')
for line in axioms:
    tail=line.rsplit(': [',1)[1].rstrip(']')
    names={x.strip() for x in tail.split(',') if x.strip()}
    assert names<={'propext','Classical.choice','Quot.sound'},line
build=json.loads((BASE/'native-selected/fresh-build-results.json').read_text())
phase3_inputs=json.loads((ROLE/'phase3/input_inventory.json').read_text())
candidate_hashes={r['source']:r['sha256'] for r in phase3_inputs if r['method']=='git show'}
for row in build:
    assert row['source_sha256']==candidate_hashes[row['source']]
    assert row['exit_code']==0 and row['preexisting'] is False
    assert row['olean_mtime']>=row['start_unix']
    assert not any('/ASTIS-GC/.lake/build/lib/lean/' in item for item in row['resolved_deps'])
reader=json.loads((BASE/'native-selected/static-reader-findings.json').read_text())
assert reader['reader_delivery']=='HOLD' and len(reader['six_code_and_formula_folds'])==6
for step in reader['six_code_and_formula_folds']:
    assert step['exact_code'] and step['exact_formula']
    assert not step['copy_neighbor'] and not step['download_neighbor'] and not step['exact_module_source_neighbor']
overlay=json.loads((BASE/'canonical-audit-attachment-overlay.json').read_text())
original=json.loads((BASE/'inputs/huanjian-fixed-spectrum-cosine-gram.json').read_text())
proposed=json.loads((BASE/'proposed-canonical-audit.json').read_text())
contract=json.loads((BASE/'attachment_contract.json').read_text())
assert overlay['state']=='accepted' and overlay['source_review']['state']=='accepted'
assert overlay['verdict']=='equivalent-after-elaboration' and overlay['repairs']==[]
assert overlay['source_review']['reviewer']=='/root/cosine_gram_fresh_source_7e41d9'
assert overlay['source_review']['independent_from_formalizer'] is True
assert overlay['source_review']['independent_from_decoder'] is True
assert re.fullmatch('[0-9a-f]{64}',overlay['source_review']['review_run_sha256'])
assert sha((ROOT/overlay['source_review']['run_artifact']).read_bytes())==overlay['source_review']['review_run_sha256']
assert overlay['source_review']['reviewer_packet_sha256']=='68eb57daeb019b886f64e96ea800777ac04f83af39d582ae8ff9a01c3d497921'
assert all(proposed[key]==original[key] for key in contract['protected_unchanged_top_level_fields'])
assert all(proposed[key]==overlay[key] for key in overlay)
assert sha((ROOT/contract['canonical_audit']).read_bytes())==contract['baseline_audit_raw_sha256']
prior=[]
for phase,expected_hash in [('phase1','80d4eefdb9d3d733e60d4ea52d00207c5ca62e03c1964b94e404525c2e472079'),
                            ('phase2','8a5ff1011acb383f99d2411649240d48023186cac33c24323d9e95402361625e'),
                            ('phase3','3ce8cdccd41e6e93d361466e444efbde32e7de8bcac420e79ee322bc8435dbac')]:
    directory=ROLE/phase
    assert sha((directory/'manifest.json').read_bytes())==expected_hash
    entries=json.loads((directory/'manifest.json').read_text())['payloads']
    for row in entries:
        path=directory/row['path'];data=path.read_bytes()
        assert sha(data)==row['sha256'] and len(data)==row['bytes']
        assert stat.S_IMODE(path.stat().st_mode)==0o444
    assert stat.S_IMODE(directory.stat().st_mode)==0o555
    prior.append({'phase':phase,'manifest_sha256':expected_hash,'verified_payload_count':len(entries)})
result={'phase_boundary':'Native evidence first exposed after frozen Phase3 mathematical judgment; no retrospective modification.',
        'original_native_archive_all264_files_integrity_verified':True,
        'original_native_kernel_stdout_sha256':sha(native_raw),
        'actual_native_root_exact_prop_pass_lines':passes,'actual_native_first_public_ASTIS_parent_lines':parents,
        'actual_native_all_owned_axiom_checked_lines':len(axioms),'actual_native_inventory_line':count,
        'native_G_P_T_source_hashes_match_own_reviewed_candidate':True,
        'native_outputs_are_third_party_original_records_not_this_roles_native_execution':True,
        'all_six_reader_neighbor_HOLD_preserved':True,'browser_global_acceptance':False,
        'overlay_matches_parent_supplied_minimal_schema_checks':True,
        'formal_metadata_gate_execution_by_this_role':False,
        'own_review_run_raw_sha256_verified_at_actual_artifact':overlay['source_review']['review_run_sha256'],
        'canonical_audit_and_all_protected_values_unmodified':True,
        'prior_phases_verified_unchanged':prior,'SourceV_or_ledger_called':False}
(BASE/'postfreeze_closure_verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
