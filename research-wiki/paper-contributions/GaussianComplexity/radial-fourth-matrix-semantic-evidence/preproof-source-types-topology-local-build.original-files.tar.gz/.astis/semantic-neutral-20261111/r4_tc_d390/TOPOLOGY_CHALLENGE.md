# Independent mathematical topology challenge

Verdict: **ACCEPT MATHEMATICAL/SOURCE TOPOLOGY FOR THE EXACT CANONICAL ONE-ROW TARGET BUNDLE, WITH EXPLICIT BACKGROUND OBLIGATIONS UNPROVED**.

I found no blocking mathematical or source-provenance gap in the supplied raw graph plus typed overlay when they are read within their stated scope. No repair overlay is required for the exact sealed producer and individual consumer. This accepts coverage and the mathematical dependency route, not a proof, compiled dependency edge, source-family transport theorem, publication status, or process permission.

My raw source judgment and type-only judgment were frozen before this graph handoff and remain unchanged. The source graph and its current typed overlay were read only after those freezes. No implementation, Lean proof API, compiler history, earlier packet report, or ledger/integration state was inspected. All output is confined to my own neutral directory.

## Exact evidence

- Pinned HTML: 951991 bytes, SHA256 `6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915`.
- Raw SG manifest: `r4_sg_55d8/evidence-manifest.json`, SHA256 `32fb1c7a85b209dab52ab69c8f73f009bf623a6b9af91c0a84418191d234d802`.
- Raw SG graph: `r4_sg_55d8/source-graph.json`, SHA256 `6352e9e12a60a28f5b8de65b10c503eb2561a4e3c2f09c216964562b7610e419`.
- Typed overlay manifest: `r4_sg_55d8/typed-overlay-v1/typed-overlay-manifest.json`, SHA256 `bc82c04245246b7101d494dd09cbbdd0170d69bccdd41420f82a23a7649468ff`.
- Typed component graph: `r4_sg_55d8/typed-overlay-v1/proof-component-graph.json`, SHA256 `565f6dfbe1eec3c4975a1e2dd9765b129abe282f1ea65ff28890afede92ba47f`.
- Exact type packet SHA256 `899221eab62ec75aa1eb8d90f62c4a2e86c154037b934042433b11acce08b6d2`; statement seal `cc628d801ed367e1e57e99d69449d36a90b2803f7371986b964b4864409f6dec`; definition context `6e519e17615212c920c3e18e57c9dd416ac5addf2511a949c1bb8050b1adee43`.
- Producer signature SHA256 `249edf1f3d15639eca0c0db2f827bca4981faf3648653ef83fb731abe564af32`; consumer signature SHA256 `d177e72a66ec143642b0518887a170f7906d9fc528a87ea399d02ee00842bfac`.
- My earlier raw report SHA256 `a1c17e48cc7f0e0c15fce3fca3329d68235aa7c944247dd598d8ec29a6b1b8e3`; my earlier type-only report SHA256 `f768d3b29aa59e60178eec9403cea27bc3215561cedb370d10ab0898dde5b1d3`.

The exact structural checks and a reproducible independent checker are in `TOPOLOGY_STRUCTURAL_CHECK.json` and `check_topology_structure.py`. Their results are structural evidence, separate from this mathematical judgment.

## Backward closures and all target ports

The raw graph has 18 nodes and 38 edges. Recomputed root sizes are 11 for `M.radial-fourth`, 9 for `M.square`, and 18 for `R.individual-second-moment`. All three declared backward closures match their actual prerequisite relation.

The typed graph has 35 nodes and 71 edges. Every edge matches the consumer's declared prerequisite, both graphs are acyclic, and the expanded root records contain the exact original node payloads and all induced edges. All six roots are present:

| Root | Closure nodes | Closure edges | Mathematical route checked |
|---|---:|---:|---|
| `P.integrable` | 14 | 17 | Actual Gaussian law, fourth/mixed moments, diagonal absolute finiteness, off-diagonal domination, strong measurability, finite-entry to operator-norm integrability |
| `P.mean` | 19 | 27 | Producer integrability, scalar-to-Bochner evaluation, diagonal values, sign cancellation, matrix identity |
| `P.bundle` | 20 | 29 | Both producer conjuncts |
| `T.integrable` | 22 | 37 | Producer integrability, exact matrix square, fixed continuous tensor map, measurable cutoff |
| `T.PSD` | 33 | 67 | Integrability, pointwise PSD removal, integrated Loewner comparison, exact tensor mean |
| `T.bundle` | 34 | 69 | Both consumer conjuncts |

The whole producer and consumer conjunctions have their own roots. The producer integrability port materially enters the consumer's integrability, its order-integration step, and its exact tensor-mean step. The producer mean port enters the exact tensor-mean step. The graph correctly does not require `P.mean` to prove `T.integrable`. These are sound mathematical intended-use edges; a type/graph packet cannot establish that a later implementation actually uses them.

## Gaussian-law bridge and the original-family boundary

`D.mu` records the actual `stdGaussian` measure, rather than introducing a Gaussian-law certificate as a theorem premise. `B.coordinate-law` explicitly requires the internal mathematical bridge from its orthonormal-basis pushforward definition to independent standard Gaussian coordinates in the specific `WithLp.ofLp` coordinate basis. Thus the graph does not silently equate arbitrary normal marginals or covariance identity with a joint standard Gaussian law.

The bridge is a genuine obligation. Its presence is coverage, not evidence that orthogonal invariance or coordinate-law transport has been proved. Both the independent raw reading and the typed graph require this same missing background fact.

The original source experiment starts with the family `g_1,...,g_r` and then takes rows `gamma_i`. The exact sealed types instead integrate one canonical row under `stdGaussian E`. This is a correct law-level realization of the source row identity and individual bound. The supplied scope explicitly excludes proving a distributional adapter on the original common probability space or an across-row family theorem. That limitation is respected by both roots and binders.

In particular, this review does not create an implication from dimension assumptions alone to a Gaussian law. The raw node `D.gaussian-row` is explicitly a standing source law; its definition/domain ancestors specify its meaning and applicability. Likewise the raw graph's bundled row definitions carry grid and cutoff context into some closures even though those facts are unnecessary for an isolated radial moment. Those contextual source edges are not a claim of mathematical necessity or compiled Lean implication. The typed producer closure appropriately has no cosine feature or cutoff ancestor.

If a later publication broadens the claim to the original ambient family, the minimal separately reviewable addition is a law/expectation adapter: identify each source row's pushforward with the canonical law, transport integrability and the matrix integral through that row map, and preserve the deterministic feature and row index. Cross-row independence is still unnecessary for these individual statements. This is a future scope boundary, not a missing parent of the current canonical types.

## Fourth moments, sign cancellation, and quartic integrability

`B.scalar-moments` includes the scalar second moment 1, fourth moment 3, finite absolute moments through degree four, and the distinct-coordinate mixed square moment 1 using independence. `P.diagonal` uses the Euclidean radius expansion to sum exactly one fourth moment and `r-1` mixed moments. This produces `r+2`, not `d+2` or `r^2+2`.

`B.weighted-entry-finite` handles diagonal absolute finiteness and the valid pointwise inequality

\[
|R v_a v_b|\leq \tfrac12 R(v_a^2+v_b^2).
\]

Its full backward closure contains the finite-moment and radius-expansion ingredients. This is the legitimate source of its integrability claim. A scalar totalized-integral equality alone would not be an adequate port for that argument; the closure's finite-moment content must not be discarded when later condensing components. The raw diagonal node also explicitly retains integrability. No new mathematical ingredient or repair is missing from the current full closures.

`B.weighted-measurable` supplies actual strong measurability, and `B.matrix-norm-integrability` bridges finite absolute entry integrals to finite operator-norm integral. Consequently `P.integrable` is a genuine matrix Bochner-integrability target, rather than an assumption or a zero-fallback convention.

`B.sign-symmetry` includes preservation of both the law and `R` by a coordinate reflection. `P.off-diagonal` depends on this symmetry and the integrable entry/Bochner transport route. The off-diagonal scalar integrand changes sign even when the reflected coordinate also occurs in one summand of `R`; the full radius is reflection invariant. The graph therefore covers both the cancellation and the regularity needed to make it valid.

`B.coordinate-integral-transport` explicitly states that coordinate evaluation commutes with the Bochner integral. Without that node, scalar entry calculations alone would leave the matrix target unconnected. Its presence closes the source-to-type regularity gap at the topology level, with the bridge itself still unproved.

## Exact square, PSD order, and integration

`D.Y-square` retains the exact closed cutoff, `d^-1` normalization, source Gaussian-first Kronecker order, and ordinary matrix multiplication. `B.square-algebra` includes both rank-one square identities, Kronecker multiplication, and indicator idempotence. It yields

\[
Y^2=\mathbf1_{R\leq L}W,\qquad
W=\frac{S}{d^2}((R G)\otimes F),
\quad S=\sum_k t_k^2,\quad F=tt^\top.
\]

The factors and powers are correct. The indicator occurs once, the square is not entrywise, and the feature length appears once as a scalar in addition to the outer-product feature matrix.

`B.fixed-tensor-linear` makes the deterministic tensor/scalar map an explicit continuous real linear map. Together with `P.integrable`, the exact square identity and measurable closed cutoff, it proves the required integrability route for `squared`. It does not require a tail estimate or cutoff positivity.

`B.W-PSD` supplies symmetry and positivity of the rank-one tensor expression using nonnegative `R` and `S/d^2`. `B.indicator-PSD` then compares `W-Y^2` in the Loewner order. This is a PSD comparison, not the false entrywise comparison that would fail on negative off-diagonal entries.

`B.integrate-PSD-order` includes integrability of both matrices, nonnegative quadratic-form integration, and real symmetry. `B.exact-tensor-mean` separately consumes the producer integrability and exact mean through the fixed tensor map. Together they give precisely

\[
\operatorname{PosSemidef}\left(
\frac{(r+2)\sum_k t_k^2}{d^2}(I_r\otimes F)
-\int Y^2\,d\mu\right).
\]

There is no circular use of the consumer bound, a public PSD certificate, a retained-mass normalization, or an imported aggregate variance estimate.

## Feature provenance, source coverage, and small dimensions

`D.row-feature` retains the complete source recipe, not an abstract unrelated feature: source row `i_src=i.val+1`, midpoint `(i.val+1/2)pi/d`, constant coordinate 1, and frequencies `0,...,q` with `sqrt(2)` only for positive frequencies. Its raw links and anchors reach `S4.E11`, `A3.Ex85`, and the explicit source frequency indexing. The consumer target retains the explicit sum of feature coordinate squares, so no function-space norm convention is smuggled into its coefficient.

The source-supported individual inequality is correctly labeled an inference from Ex113, Ex114 and the PSD indicator-removal sentence. The source's next display is a sum. The packet does not pretend that the inferred individual result is separately numbered, or that the displayed aggregate is a premise of the termwise bound.

Independent byte/Unicode/line rehashing checked all 317 locator records against the pinned raw HTML. An independent HTML parse verified the bounded union has exactly 98 atomic items, 186 unique math IDs and 378 unique DOM IDs, all assigned exactly once. Every math member's original alttext and atomic owner agrees with the source. The partial exclusions in the combined spectrum display and mixed-scope paragraphs are explicit. The excluded aggregate display is retained as provenance only; the feature norm bound, cosine Gram sum, radial-bias scalar, centering, variance parameter, Bernstein estimate, and whole Lemma 4.4 are excluded consistently with the sealed targets.

For `q=0`, `r=1` and `d>=2`, the mixed-coordinate sum is empty, off-diagonal cancellation is vacuous, and the sole feature coordinate is 1. The producer reduces to the integrable scalar fourth moment with mean 3. The consumer reduces to the scalar truncated second-moment bound with upper coefficient `3/d^2`. All six root routes remain meaningful; no node requires a second coordinate or a positive query count.

The graph adds no source-extraneous moment, regularity, PSD, concentration, aggregate, or positivity premise. It keeps the required proof ingredients internal. Neither structural closure completeness nor this source/topology acceptance proves any of those ingredients in Lean.

## Final disposition

No blocking gap and no required repair for this exact packet. The outstanding mathematical obligations are exactly the explicitly represented Gaussian-coordinate law/moment/symmetry facts and finite-dimensional algebra, integrability, Bochner, tensor, and PSD bridges. They remain obligations for the sole prover and later independent verification. Original-family transport, aggregate concentration and full Lemma 4.4 remain outside this acceptance.
