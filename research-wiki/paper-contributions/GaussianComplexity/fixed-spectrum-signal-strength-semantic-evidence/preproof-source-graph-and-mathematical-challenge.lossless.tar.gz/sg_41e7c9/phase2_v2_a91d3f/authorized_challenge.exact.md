# Phase 2b: independent mathematical source-topology challenge

Actor: `/root/signal_topology`. Phase 1 raw-first cognition and Phase 2a
statement/binder/definition judgment remain unchanged. This judgment is frozen
before process/chronology metadata and without implementation, API search,
extractor private cognition/rationale, an extractor verdict artifact, prior
review verdicts, or a parent mathematical verdict.

## Decision and its scope

**The two exact selected root routes are mathematically coherent, with their
named standard-input gaps retained. No selected-root mathematical HOLD was
found. Raw-region coverage is substantively present, not merely counted.**

**HOLD an unqualified claim that this is already a faithful general-purpose
Source Proof Graph for all stated source facts in the full read slice.** There
is one specific source-generality/adapter-scoping ambiguity, H1 below, and a
separate conditional-preview qualification, H2. Neither refutes either sealed
statement or prevents the bounded odd-frequency numerical derivation. They
must not be silently erased by calling the whole read slice topology-reviewed.

This is a source-topology judgment, not a proof-success judgment. The proposed
graph has explicit unresolved standard foundational inputs and unopened
appendix/citation boundaries. Acceptance of its exact root architecture does
not discharge any of them in Lean, certify Theorem 4.1, certify full Ex26, or
promote the private event application into a source Anchor.

## Newly exposed evidence

The following exact authorized files were byte-hash verified before review:

| File in extractor `phase2_c34b8a` | SHA-256 |
| --- | --- |
| `source_graph.json` | `fbcb70da3c08ab8796ec556d023758c3695f167d190f273965cbe4929cf550ea` |
| `source_unit_dispositions.json` | `bdb12bbea7f51e71ca23142f31a7b1a37252871df04ac4aeb2ee8b12a22ba3d4` |
| `root_closures.json` | `d45c34cbfca23fd259ece55eebaaf8048f0ab136654e85f6c25f450745576696` |
| `conditional_discharge_audit.json` | `950e1dd68e4d95b186fae5e1d933d3a533802cbf525336bfc03fde74670dff9c` |

The optional Phase 1 `raw_unit_inventory.json` was also read, SHA-256
`b26b0696aea724e49221efeb08c0c8dbea1cfcce71e69cd904ae122a811c9b6b`.
All paths are under the explicitly authorized extractor directory. No
extractor freeze, statement-definition judgment, provenance, cognition or
build script was opened. Inside the authorized records, I read the proposed
nodes/edges, raw dispositions, root-membership data and proposed mathematical
premise discharges. Approval/status fields were not used as authority; their
standalone verdict values were not requested in the filtered reads.

For direct comparison I reopened only the pinned original HTML already read
in Phase 1, retaining its verified digest
`6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915`.
No mathematical content outside S2, S4, A3.SS3 and bib.bib3 was opened.

## Raw coverage: content review and independent byte checks

The inventory's exact byte ranges, SHA-256 values and raw HTML all matched the
pinned bytes. Every source ID in the four scoped DOM subtrees appears in the
inventory, without an out-of-scope source ID. Inventory/disposition unit sets
and per-unit hashes agree. Those checks establish retrieval integrity only.

I separately read the source text of every paragraph and display/display group
in those scopes alongside its proposed mapping. That review finds the
substantive regions identified in my independent Phase 1 map present:

- both directions of exact oracle simulation, Borel/seed/output semantics,
  per-run caps, uniform seed-averaged TV and its event/test meaning;
- the full hard-family grid and random-rotation definitions, known-spectrum
  scope, affine kappa=2 remark and citation use;
- the extra starting vector, experiment-dependent coefficients, simultaneous
  Krylov control and law-preserving extension;
- both unconditional moment formulas, Gaussian variance calculations, sign
  and normalized ratio, conditional bias and the rotation interpretation;
- the unnumbered eventual-frequency, tau, domain, bias, M, product and common
  threshold bookkeeping, then centered-variable variance and Chebyshev/TV
  comparisons;
- the two method limitations, their missing/unopened proof inputs, and the
  explicit open boundary for stronger results on the same family;
- all of C.7's rational and convergence arguments, both C.8 aliasing tails,
  disjointness and parity, both variances, the exact ratio, logarithmic integral
  estimates and the final conditional bias step;
- bibliography [22], including actual consumer locations rather than treating
  bibliography backlinks as proof directions.

The EXCLUDED entries are duplicate enclosing containers or headings and their
navigation subelements, with substantive descendants mapped. I found no
substantive proof paragraph excluded merely because it was unnumbered. QED
tokens remaining in node-mapped paragraphs do not create extra mathematics.
The root-membership lists are not used as proof that a raw unit has been
discharged.

One minor mapping refinement is warranted: raw unit
`A3.SS3:raw:0043` (`A3.SS3.p2.3`) contains both “Combining these identities
proves the expansion” and “Finally”. It is mapped only to `c:majorant`.
The graph nevertheless records the combination at `e:c7` with this exact
consumer use site, so the proof region is present. Associating the unit also
with `c:c7`, or splitting the two sentences, would make the disposition agree
with that already-present edge. I do not treat this as a missing proof region.

A locator correction to my own frozen Phase 1 prose is explicit here, without
editing that freeze: Loewner order is in `S2.p1`, not `S2.p2`. The raw bytes
confirm the proposed `s:notation` locator is correct. This correction comes
from the raw source, not an extractor approval.

## Exact selected-root mathematics

The public route uses the scalar regime rather than the hypothetical
successful-algorithm bundle. This is the right distinction: the selected
actual moments do not require epsilon, an algorithm witness, a favorable
random event, or a TV premise. `e:n`, `e:distance` and `e:domain` record the
uniform frequency/domain argument; the supplied CD02 calculation has the
correct powers. Dividing the worst-case bound
`delta*d^((1-delta)/2)*log(d)/128 + 1 + d^((1-delta)/2)` by d tends to zero
for fixed delta, independently of kappa and q. Consequently one threshold
chosen before kappa/q can ensure d>=2 and n+sqrt(kappa)<=d. This discharges
the actual source frequency and distance-to-grid-edge conditions, not just
their names.

The algebraic/Gaussian source chain has the correct direction. Geometric
identity, rho algebra and uniform absolute majorant join at C.7. C.7 and
Gaussian second-moment meaning feed finite-grid means. The grid filter for M
and the three disjoint frequency classes for the signed mean join at C.8;
neither mean is treated as an alternative proof of the other. The sign and
positive normalization follow exact means, 0<rho<1 and n<d. The logarithm
integral bounds give the correct negative-exponential directions. The extra
distance condition is used for the lower-bias correction factor, not
retroactively added to unconditional means/variances.

`e:beta-lower` retains the coefficient calculation
`3n/sqrt(kappa)<=3+(3delta/128)log d<=3+(delta/4)log d`; its B is the
source positive scalar. `e:M-lower` uses a valid weakening of the C.3 rho
bound and d>=sqrt(kappa), then the exact rational M formula. It preserves
both successive M lower bounds. `e:signal` squares a nonnegative bias lower
bound and multiplies a positive M lower bound; the dimension exponents reduce
to one half and the constant remains B^2/2. These estimates are simultaneous
for the same actual law and scalar parameters.

The signal-product component of Ex24 is correctly separated from tau/beta.
Neither the tau branch, the concentration lemma, rotation, TV nor external
[22] is in the public root's backward closure. That absence matches the
actual source numerical dependence; sharing a paragraph or display is not
a proof implication.

The private route adds the actual diagonal-law variance/sign calculation and
Chebyshev to the public signal route. Its additional threshold is legitimate:
a fixed natural D with sqrt(D)>=40/B^2 makes the signal lower bound at least
20, and taking the maximum with the public delta-only threshold preserves
uniformity. The signed raw statistic has mean beta*M>0 and variance at most
2M; the proposed probability ratio is `2/(M*beta^2)`, so the stated numerical
threshold yields at most 1/10. Event measurability and finite probability
interpretation of `.toReal` are not supplied as public assumptions.

This private event is not the shifted detector. `a:private-chebyshev` and the
private root are typed as adaptations/non-Anchors. The original shifted test,
rotation adapter, tau/beta and 320 threshold remain separate and outside
both selected roots. I found no edge giving the private result credit for
full Ex26 and no event substitution that would erase the norm-dependent shift.

I independently recomputed both backward closures from dependency-true edges.
Their node, edge, leaf and source-gap lists exactly match the submitted lists.
The public closure retains Gaussian semantics, geometric series, trigonometry,
log calculus and real-power/asymptotic standard-input gaps. The private closure
adds the probability-inequality gap and the needed variance branch. Those gap
nodes are unresolved inputs, not certificates. Counts and closure equality
alone were not used to judge any mathematical edge.

## AND/OR, consumer sites and boundary checks

No alternative sufficient route to either selected root is given by the read
source. The conjunctions at C.7, C.8, the M/bias product and the private
threshold/probability application are appropriate. A shared source display's
two estimates are not falsely ANDed at the public root. Attribution to [22]
is correctly non-implicational for the hard-grid definition; the actual
deferred-rotation use is a separate source input on the algorithm branch.

Every proposed consumer locator resolves in the raw document. The principal
source uses occur at the consuming paragraph/display rather than only at a
producer's theorem statement. The full theorem branch records output
measurability/model semantics, joint-law preservation, all-vector control,
centering/L2 triangle rather than invented independence of the two target
statistics, per-input TV before averaging, and admissibility. C.1, C.2, C.4,
the dimension proof and Fact C.6 are not silently filled from implementation.

The earlier caution about the limitation's “supremum at most 1/2” wording
remains. The source's Lemma 4.4 has conclusion 2tau under tau<=1/2; this is
not literally a general <=1/2 conclusion. The graph faithfully reports the
source's stated obstruction and keeps it outside the selected roots. That
method-limit claim must not be published as a newly certified exact numerical
consequence of the lemma's bare threshold, or as an impossibility result for
all fixed-spectrum lower-bound methods.

## H1: general source facts versus the specialized literal adapter

Affected graph path:

`s:cosine-statistic -> e:literal-law -> a:literal-law -> e:trace ->
c:trace-means -> c:mean-M/c:mean-b -> c:c8`, and the corresponding
`a:literal-law -> c:variance` path.

`s:cosine-statistic` explicitly includes the query choice n=2q+1, whereas
`a:literal-law` is the sealed-interface adapter with Fin d coordinates and
actual Bochner means. The latter is then made a dependency of author-source
nodes `c:trace-means` and `c:variance`. Downstream `c:c8` is labeled a source
fact for every integer 1<=n<d, and the source Lemma 4.5 nodes have the same
general frequency scope. The raw source C.8/Lemma 4.5 are not restricted to
odd n. No general-frequency analogue of the adapter is stated in this graph.

For the two selected roots, n is indeed 2q+1, so this path is a valid
specialized numerical route and does not refute either exact statement. For
a general Source Proof Graph, however, the current dependency typing leaves
an unresolved choice: either these source-fact nodes are specialized instances
of their cited facts, or the adapter has silently imported a query-specific
constraint into a general author proof. A source statement for all frequencies
cannot be credited from an exclusively odd-frequency parent without making
that distinction explicit. There is also a provenance-direction distinction:
the author's second-moment calculation does not itself depend on Fin/Bochner
translation to the selected interface.

**Required resolution before unqualified whole-slice topology acceptance:**
make the generic source cosine quadratic/law/mean semantics distinct from the
query-frequency choice and selected literal-interface adapter, or explicitly
type the affected graph nodes as odd-frequency instances while retaining the
unrestricted source-fact boundary. The literal-interface adaptation should be
visibly separate from what the author's general C.3 proof used. This is a
request to correct statement/edge scope, not a request for a new proof or an
implementation change. No source correction is asserted.

## H2: conditional remark preview needs an explicit retained regime

`e:kappa2-preview` has parents `s:uniform-krylov` and `s:lemma45-bias`, child
`s:kappa2-comparison`, and an empty conditional-discharge list. The source
Remark 4.2 forecasts the output/target contrast. The two quoted lemmas have
real conditions: integer frequency range, a small tau for the all-vector
probability estimate, and d-n>=sqrt(kappa) for the lower normalized bias.
Those conditions are discharged on the eventual small-query theorem route,
but no edge or audit entry attaches that regime to this remark-preview use.
The remark node does not itself state it as a conditional comparison.

For exact root closure this does not matter: the remark is outside both
roots, and the selected lower-bias use at `e:beta-lower` has a correct explicit
discharge. For unqualified whole-slice graph acceptance, mark this preview as
explanatory/non-implicational with its conditions retained, or attach the
precise intended scalar/event/domain regime to the use. Do not display the
remark's contrast as an unconditional consequence for arbitrary q. This
qualification is independent of the private event adaptation.

## Frozen disposition

- Exact selected public numerical route: ACCEPT mathematical topology with
  the named unresolved source inputs; no implementation/proof certification.
- Exact selected private actual-law zero-event route: ACCEPT mathematical
  adaptation topology with the named unresolved inputs; no source-Anchor or
  shifted-detector credit.
- Raw paragraph/display coverage: substantively represented, with the small
  C.7 unit-mapping refinement recorded above.
- Whole-slice general Source Proof Graph claim: HOLD for H1 and H2's explicit
  scope/conditional-use resolutions. These are graph-fidelity issues, not
  negative mathematical evidence against either sealed statement.

No process or chronology metadata has influenced these judgments. A later
process-admission audit, if requested, must be a new append-only record and
must leave the mathematical cognition, statement judgment and this graph
judgment unchanged.
