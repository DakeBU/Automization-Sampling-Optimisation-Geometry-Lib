from pathlib import Path
from html.parser import HTMLParser
import json,hashlib,re

ROOT=Path('/Users/zhouhuanjian/ASTIS-GC')
OUT=ROOT/'.astis/semantic-neutral-20261110/tau_tc_19abf4/phase2b-v2'
INPUT=OUT/'inputs';INPUT.mkdir(parents=True,exist_ok=True)
WL=ROOT/'.astis/semantic-neutral-20261110/tau_sg_74c208/phase2-v2/reviewer-read-whitelist.json'
wb=WL.read_bytes();assert hashlib.sha256(wb).hexdigest()=='d28712d8ffb8a3db9afe3eb9204248f18114b5cd061190e0ecae36565b5ef970'
(INPUT/'reviewer-read-whitelist.json.raw').write_bytes(wb)
whitelist=json.loads(wb);loaded={}
for row in whitelist['allowed_files']:
    p=Path(row['path']);b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==row['sha256'] and len(b)==row['bytes']
    (INPUT/(p.name+'.raw')).write_bytes(b)
    loaded[p.name]=b if p.name.endswith('.html') else json.loads(b)
raw=loaded['source.raw.html'];source=raw.decode()
inv=loaded['inventory.json'];records={r['stable_id']:r for r in inv['records']};assert len(records)==327
for r in records.values():
    b=raw[r['start_byte']:r['end_byte_exclusive']]
    assert len(b)==r['length'] and hashlib.sha256(b).hexdigest()==r['sha256']
class Plain(HTMLParser):
    def __init__(self):super().__init__();self.data=[];self.skip=0
    def handle_starttag(self,t,a):
        d=dict(a)
        if t=='math':self.skip+=1;self.data.append(' $'+d.get('alttext','')+'$ ')
        elif not self.skip and t in ['p','tr']:self.data.append('\n')
    def handle_endtag(self,t):
        if t=='math':self.skip-=1
    def handle_data(self,d):
        if not self.skip:self.data.append(d)
intervals=loaded['raw-source-intervals.json']['selected_intervals'];parts=loaded['raw-coverage-partition.json'];residuals=[]
for i in intervals:
    b=raw[i['start_byte']:i['end_byte_exclusive']];assert len(b)==i['length'] and hashlib.sha256(b).hexdigest()==i['sha256']
    cursor=i['start_byte']
    for p in [p for p in parts if p['region']==i['name']]:
        assert p['start_byte']==cursor
        b=raw[p['start_byte']:p['end_byte_exclusive']];assert len(b)==p['length'] and hashlib.sha256(b).hexdigest()==p['sha256']
        for ident in p['inventory_covering']:
            r=records[ident];assert r['start_byte']<=p['start_byte'] and p['end_byte_exclusive']<=r['end_byte_exclusive']
        if not p['inventory_covering']:
            q=Plain();q.feed(b.decode());s=' '.join(''.join(q.data).split())
            if s:residuals.append({'region':i['name'],'start_byte':p['start_byte'],'text':s})
        cursor=p['end_byte_exclusive']
    assert cursor==i['end_byte_exclusive']
assert not residuals
g=loaded['source-graph.json'];nodes={n['id']:n for n in g['nodes']};edges={e['id']:e for e in g['hyperedges']}
assert len(nodes)==len(g['nodes']) and len(edges)==len(g['hyperedges'])
for n in nodes.values():
    for a in n.get('source_use_regions',[]):
        r=records[a['inventory_id']]
        for k in ['source_id','start_byte','end_byte_exclusive','sha256']:assert r[k]==a[k]
for e in edges.values():
    assert e['conclusion'] in nodes
    for p in e['premises']:assert p in nodes
    for a in e.get('consumer_use_sites',[]):
        r=records[a['inventory_id']]
        for k in ['source_id','start_byte','end_byte_exclusive','sha256']:assert r[k]==a[k]
def closure(root):
    seen=set();used=set()
    def visit(n):
        if n in seen:return
        seen.add(n)
        for e in edges.values():
            if e['conclusion']==n:
                used.add(e['id'])
                for q in e['premises']:visit(q)
    visit(root);return {'nodes':sorted(seen),'hyperedges':sorted(used)}
for c in g['closures']:
    computed=closure(c['root']);assert c['nodes']==computed['nodes'] and c['hyperedges']==computed['hyperedges']
states={};stack=[]
def acyclic(n):
    assert states.get(n)!=1,stack+[n]
    if states.get(n)==2:return
    states[n]=1;stack.append(n)
    for e in edges.values():
        if e['conclusion']==n:
            for q in e['premises']:acyclic(q)
    stack.pop();states[n]=2
for n in nodes:acyclic(n)
for filename,expected in [('record-coverage.json',set(records)),('paragraph-coverage.json',{r['stable_id'] for r in records.values() if r['layer']=='paragraph'})]:
    rows=loaded[filename];ids={r['inventory_id'] for r in rows};assert len(rows)==len(ids) and ids==expected
    for r in rows:
        assert r['disposition']==records[r['inventory_id']]['disposition']
        for n in r['graph_nodes']:assert n in nodes
        if r['disposition']=='NODE':assert r['graph_nodes']
expected_sigs={'producer':'edfd8e6c839d2ad5523754abbb7b1285a5d08edb2d964780103d38c9ef5e562b','private_consumer':'fdefed7cbdb8755772eb5f852335c37473bb5ab6c55c6c29b92e4430977073db'}
statements=loaded['exact-statements.json']
for k,h in expected_sigs.items():
    assert hashlib.sha256(statements[k]['signature'].encode()).hexdigest()==h==statements[k]['signature_sha256']
    node='producer' if k=='producer' else 'private-consumer';assert nodes[node]['claim']==statements[k]['signature']
assert 'selected-odd-adapter' in edges['actual-means']['premises']
assert any(c.get('discharged_by')=='selected-odd-adapter' and '1<=n<d' in c['condition'] for c in edges['actual-means']['conditions_and_discharge'])
assert 'frequency-gap-eventual' in closure('actual-means')['nodes']
for e in ['c2-truncation','c2-two-events','c2-intersect']:assert 'ext-Markov-finite-union' in edges[e]['premises']
for root in ['producer','private-consumer']:
    assert not {'source-C-witness','gap-Bernstein','gap-polynomial-detector','citation22','ext-Markov-finite-union'}.intersection(closure(root)['nodes'])
for root in ['generic-means','generic-variance','generic-sign-ratio','generic-bias']:
    assert not {'frequency','selected-odd-adapter'}.intersection(closure(root)['nodes'])
assert not {'source-cutoff','Mbeta-growth','source-target-pass'}.intersection(closure('paragraph:S4.SS3.SSS0.Px1.p1')['nodes'])

line_starts=[0]+[m.end() for m in re.finditer('\n',source)]
class RawWalk(HTMLParser):
    def __init__(self):super().__init__(convert_charrefs=False);self.stack=[];self.checked=[]
    def pos(self):
        l,c=self.getpos();return line_starts[l-1]+c
    def handle_starttag(self,t,a):
        if t not in {'area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr'}:self.stack.append({'tag':t,'attrs':dict(a),'start':self.pos()})
    def handle_endtag(self,t):
        for j in range(len(self.stack)-1,-1,-1):
            if self.stack[j]['tag']==t:
                r=self.stack[j];del self.stack[j:];z=source.index('>',self.pos())+1;a=r['attrs'];cl=a.get('class','')
                if (t=='p' and 'ltx_p' in cl) or (t=='math' and a.get('display')=='block') or (t=='table' and 'ltx_equation' in cl) or t=='cite':
                    aa=len(source[:r['start']].encode());zz=len(source[:z].encode())
                    if any(i['start_byte']<=aa and zz<=i['end_byte_exclusive'] for i in intervals):
                        covering=[v['stable_id'] for v in records.values() if v['start_byte']<=aa and zz<=v['end_byte_exclusive']]
                        assert covering,a.get('id');self.checked.append(a.get('id'))
                return
walk=RawWalk();walk.feed(source)
clips=OUT/'source-clips';clips.mkdir(exist_ok=True);reread=[]
for ident in ['src:A3.SS2.p10','src:A3.SS2.p16','src:A3.SS2.p17','src:A3.SS3.p9','src:A3.Thmtheorem8.p1','src:S4.Thmtheorem5.p1','src:S4.SS3.SSS0.Px2.p2','src:S4.SS3.SSS0.Px2.p3']:
    r=records[ident];b=raw[r['start_byte']:r['end_byte_exclusive']];(clips/(r['source_id']+'.html.raw')).write_bytes(b)
    q=Plain();q.feed(b.decode());t=''.join(q.data);(clips/(r['source_id']+'.reading.txt')).write_text(t)
    reread.append({'source_id':r['source_id'],'sha256':hashlib.sha256(b).hexdigest(),'text':t})
result={'graph_sha256':hashlib.sha256((INPUT/'source-graph.json.raw').read_bytes()).hexdigest(),'input_hashes_raw_records_locators_intervals_partition':'PASS','coverage_records':327,'paragraph_blocks':71,'independent_raw_p_display_citation_elements':len(walk.checked),'uncovered_readable_source':residuals,'all_closures_recomputed':'PASS','acyclic':'PASS','exact_signatures':'UNCHANGED','generic_frequency_separation':'PASS','numeric_C_and_rotation_separation':'PASS','algorithm_cutoff_order':'PASS','TC2B-1_current_fields':edges['actual-means'],'TC2B-1_local_backward_closure':closure('actual-means'),'TC2B-2_current_input_node':nodes['ext-Markov-finite-union'],'TC2B-2_current_edges':{k:edges[k] for k in ['c2-truncation','c2-two-events','c2-intersect']},'boundary':'Byte/structure checks plus localized field evidence; mathematical acceptance is a separate written judgment.'}
(OUT/'independent-checks.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({k:v for k,v in result.items() if not k.startswith('TC2B')},indent=2))
for r in reread:
    print('\nRAW REREAD',r['source_id'],r['sha256']);print(r['text'])
