python3 - <<'PY'
import sys,runpy,json
sys.argv=['extract_source.py','context']
g=runpy.run_path('.astis/semantic-neutral-20261110/src_d63b90/extract_source.py')
p=g['p']; render=g['textnode']
print('Document title:',g['html'][g['html'].find('<title>'):g['html'].find('</title>')+8])
for ident,n in p.ids.items():
    if n.tag in {'h2','h3','h4'} and ('notation' in render(n).lower() or 'preliminar' in render(n).lower()): print(ident,render(n))
for ident in ['bib.bib3']:
    n=p.ids.get(ident)
    if n: print('Citation:',ident,render(n))
PY
