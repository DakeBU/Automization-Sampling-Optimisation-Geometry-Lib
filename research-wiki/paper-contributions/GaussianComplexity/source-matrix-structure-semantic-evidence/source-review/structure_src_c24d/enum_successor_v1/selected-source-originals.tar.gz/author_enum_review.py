from pathlib import Path
import json,hashlib,datetime,copy
out=Path(__file__).resolve().parent; parent=out.parent; repo=Path('/Users/zhouhuanjian/ASTIS-GC')
W=Path('.astis/huanjian-gc-source-matrix-structure-20261113'); E=Path('research-wiki/paper-contributions/GaussianComplexity/source-matrix-structure-semantic-evidence')
commit='7c364dbeaf44c1f23defe10534e6cd3dffdac172'
def H(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(name,value):
 p=out/name;p.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n');return p,H(p)
# Preserve selected exact decoder custody originals with portable local paths.
source_originals=[]
for anon in ['anon_328a','anon_96ec']:
 for name in ['input.json','result.json','reconstruction.md']:
  rel=E/'decoder-originals'/anon/name; src=parent/'phase3-inputs'/rel; dest=out/'originals/decoder-originals'/anon/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(src.read_bytes());source_originals.append({'original_artifact':str(src.relative_to(repo)),'portable_copy':str(dest.relative_to(out)),'sha256':H(dest)})
rel=E/'decoder-originals/input-metadata-projection.json';src=parent/'phase3-inputs'/rel;dest=out/'originals/decoder-originals/input-metadata-projection.json';dest.write_bytes(src.read_bytes());source_originals.append({'original_artifact':str(src.relative_to(repo)),'portable_copy':str(dest.relative_to(out)),'sha256':H(dest)})
save('PORTABLE-SELECTED-DECODER-ORIGINALS.json',{'scope':'unaltered original anonymous decoder custody evidence reused; no decoder rerun or projection edits','files':source_originals})
inspection=out/'EXACT-ENUM-DELTA-REVIEW-INPUTS.json';delta=json.loads(inspection.read_text())
prior_authored=out/'originals/EXPOSITION-SOURCE-MAP-CONCEPTUAL-REVIEW.v3.json'
authored={
 'reviewer':'structure_src_c24d','independent_from_author':True,'state':'accepted','reviewed_reader_commit':commit,
 'kind':'bounded incremental enum-only authored/publication review successor',
 'prior_substantive_review':{'portable_artifact':str(prior_authored.relative_to(out)),'original_artifact':str((parent/'EXPOSITION-SOURCE-MAP-CONCEPTUAL-REVIEW.v3.json').relative_to(repo)),'sha256':H(prior_authored),'substantive_judgment':'Explicitly reused unchanged: six proof steps, narrative/formula/assumption scopes, P148/T108 exact-once source map, three actual P parents/private T only P, bounded none-found conceptual audit.'},
 'current_delta':'Only source.wording_status in authored lesson source and publication source is changed from faithful paraphrase with explicit analytic prerequisites to faithful paraphrase. Corresponding candidate context copies, publication binding hashes and canonical reviewer packet hashes refresh. No source text, Lean statements/bodies, Gaussian experiment, actual expectation, assumptions, formulas, proof steps, source map or decoder changes.',
 'enum_contract':'tools/astis_publication.py:172 explicitly permits faithful paraphrase; raw excerpt retained at raw/002-exact-enum-validation-code.stdout.',
 'mathematical_justification':'The current value correctly classifies the already reviewed faithful source paraphrase. The analytic-prerequisite elaboration remains explicit in the unchanged statement and proof rather than inside an enum label. No new semantic delta, repair or mathematical assumption is introduced.',
 'exact_delta_check':{'portable_artifact':str(inspection.relative_to(out)),'sha256':H(inspection)},
 'current_authored_sources':[{'path':str(p.relative_to(out/'inputs/current')),'sha256':H(p)} for p in [out/'inputs/current/website/content/declaration_lessons/huanjian-gaussian-source-matrix-structure.json',out/'inputs/current/website/content/publications/huanjian-gaussian-source-matrix-structure.json']],
 'findings':[],'gate_boundary':'This is source/exposition acceptance of the enum-only current successor. It does not retroactively claim that the earlier invalid-enum publication admission passed, and does not independently assert current publication-gate success.',
 'no_math_rebuild_layout_native_or_normal_verification':True}
authored_path,authored_hash=save('EXPOSITION-ENUM-SUCCESSOR-REVIEW.v4.json',authored)
summary=[]
for role in ['P','T']:
 packet_path=out/'inputs/current'/W/f'fresh-{role}-review.v4.json';p=json.loads(packet_path.read_text())
 prior_run_path=out/'originals'/f'{role}-source-review-run.v3.json';prior=json.loads(prior_run_path.read_text());slots=copy.deepcopy(prior['semantic_slots'])
 assert len(slots)==7 and prior['verdict']=='equivalent-after-elaboration'
 evidence='Bounded independent enum-only successor review at immutable reader '+commit+'. Exact full-object comparison with preserved v3 source/decoder/publication packet originals finds only the two source.wording_status leaves changing to the allowed value faithful paraphrase and refreshed packet/context hashes. Source original, exact P/T code, statements, assumptions, formulas, source-map spans, whole-module line coverage and anonymous decoder results are unchanged. The prior independent substantive seven-slot source judgment is explicitly reused, not fabricated as a new whole-math review. Actual current packet canonical hashes and P/T publication bindings independently rehash correctly. No ROOT normalization, math rebuild, reader/layout/native claim or normal verification.'
 run={'reviewer':'structure_src_c24d','independent_from_formalizer':True,'independent_from_decoder':True,'formalizer':p['roles']['formalizer'],'decoder':p['roles']['blind_decoder'],'audit_id':prior['audit_id'],'target_role':role,'state':'accepted','verdict':'equivalent-after-elaboration','reviewed_reader_commit':commit,'kind':'incremental enum-only current-packet acceptance reusing unchanged v3 substantive review',
 'reviewer_packet_sha256':p['packet_sha256'],'reviewer_packet_file_byte_sha256':H(packet_path),'publication_binding_sha256':p['publication_binding_sha256'],
 'source_statement_sha256':p['source']['text_sha256'],'lean_statement_sha256':p['lean']['statement_sha256'],'decoder_packet_sha256':p['blind_reconstruction']['decoder_packet_sha256'],'decoder_run_sha256':p['blind_reconstruction']['decoder_run_sha256'],'reconstruction_text_sha256':p['blind_reconstruction']['text_sha256'],'source_text_visible_to_decoder':False,
 'prior_substantive_review':{'original_artifact':str((parent/f'{role}-source-review-run.v3.json').relative_to(repo)),'portable_artifact':str(prior_run_path.relative_to(out)),'sha256':H(prior_run_path),'prior_reviewer_packet_sha256':prior['reviewer_packet_sha256'],'prior_publication_binding_sha256':prior['publication_binding_sha256'],'seven_slots_copied_without_change':slots==prior['semantic_slots']},
 'source_raw_first_freeze':{'portable_artifact':'originals/SOURCE-EXPECTATIONS-FROZEN.json','sha256':H(out/'originals/SOURCE-EXPECTATIONS-FROZEN.json')},
 'whole_module_source_freeze':{'portable_artifact':'originals/WHOLE-CODE-SOURCE-FROZEN.json','sha256':H(out/'originals/WHOLE-CODE-SOURCE-FROZEN.json')},
 'exact_current_delta_review':{'portable_artifact':str(inspection.relative_to(out)),'sha256':H(inspection)},'current_authored_incremental_review':{'portable_artifact':str(authored_path.relative_to(out)),'sha256':authored_hash},
 'semantic_slots':slots,'deltas':[],'repairs':[],'review_evidence':evidence,
 'scope_boundary':'Source fidelity acceptance only. Private T remains a private real consumer with no public API credit. No publication-gate/Lean truth/native/layout/graph/concentration/lower-bound/normalV or Goal-completion verdict is issued.'}
 run_path,run_hash=save(f'{role}-source-review-run.v4.json',run)
 result={k:run[k] for k in ['semantic_slots','deltas','verdict','repairs','reviewer','independent_from_formalizer','independent_from_decoder','review_evidence']};result.update({'review_run_sha256':run_hash,'reviewer_packet_sha256':p['packet_sha256']})
 result_path,result_hash=save(f'{role}-source-review-result.v4.json',result)
 overlay={'id':prior['audit_id'],'state':'accepted','semantic_slots':slots,'deltas':[],'verdict':'equivalent-after-elaboration','source_review':{'state':'accepted','reviewer':'structure_src_c24d','independent_from_formalizer':True,'independent_from_decoder':True,'reviewer_packet_sha256':p['packet_sha256'],'evidence':evidence+' Original substantive review SHA-256 '+H(prior_run_path)+'. Current review run: '+str(run_path.relative_to(repo))+' SHA-256 '+run_hash+'.','review_run_sha256':run_hash,'run_artifact':str(run_path.relative_to(repo))},'repairs':[],'publication_binding_sha256':p['publication_binding_sha256']}
 overlay_path,overlay_hash=save(f'{role}-audit-overlay.v4.json',overlay)
 summary.append({'role':role,'audit_id':prior['audit_id'],'overlay_artifact':str(overlay_path.relative_to(repo)),'overlay_sha256':overlay_hash,'current_run_sha256':run_hash,'original_substantive_run_sha256':H(prior_run_path),'current_packet_sha256':p['packet_sha256'],'current_binding_sha256':p['publication_binding_sha256']})
save('CURRENT-ACCEPTANCE-SUMMARY.v4.json',{'reviewer':'structure_src_c24d','reviewed_reader_commit':commit,'state':'accepted','kind':'bounded enum-only successor; no normalV','reviews':summary,'authored_incremental_review_sha256':authored_hash})
print(json.dumps(summary,indent=2));print('AUTHORED_INCREMENTAL_REVIEW_SHA256',authored_hash)
