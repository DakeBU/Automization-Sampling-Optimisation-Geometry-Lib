"""Freeze importable local production Python closure before executing renderers."""
import ast,json
from run import ROOT,REPO,run,sha
I=ROOT/'inputs';m=json.loads((ROOT/'input-manifest.json').read_text());seen=set()
def visit(p):
    if p in seen:return
    seen.add(p)
    if p not in m['files']:
        r=run('renderer-dependency-'+str(len(seen)),['git','show',m['candidate_commit']+':'+p]);assert r.returncode==0
        assert r.stdout==(REPO/p).read_bytes()
        d=I/p;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(r.stdout)
        m['files'][p]={'sha256':sha(r.stdout),'bytes':len(r.stdout),'worktree_equal_at_freeze':True}
    tree=ast.parse((I/p).read_text())
    for n in ast.walk(tree):
        names=[x.name.split('.')[0] for x in n.names] if isinstance(n,ast.Import) else [n.module.split('.')[0]] if isinstance(n,ast.ImportFrom) and n.module else []
        for name in names:
            for prefix in ['tools','website/scripts']:
                q=prefix+'/'+name+'.py'
                if (REPO/q).is_file():visit(q);break
for p in list(m['files']):
    if p.endswith('.py'):visit(p)
(ROOT/'input-manifest.json').write_text(json.dumps(m,indent=2)+'\n')
(ROOT/'renderer-python-closure.json').write_text(json.dumps({'candidate':m['candidate_commit'],'files':[{'path':p,'sha256':m['files'][p]['sha256']} for p in sorted(seen)]},indent=2)+'\n')
(ROOT/'reader_static.rejected-import-v1.py').write_bytes((ROOT/'reader_static.py').read_bytes())
(ROOT/'verifier-failures.json').write_text(json.dumps([{'receipt':'receipts/reader-static-driver.json','class':'ENV_BLOCKED','scope':'Independent isolated production Python runtime only','reason':'Frozen primary render modules lacked their local astis_source import dependency. No candidate Lean or renderer behavior verdict; resolve by freezing exact transitive local production Python import sources.','rejected_version':'reader_static.rejected-import-v1.py'}],indent=2)+'\n')
pm=json.loads((REPO/'research-wiki/process-memory.json').read_text())
(ROOT/'process-memory-consulted.json').write_text(json.dumps({'registry_sha256':sha((REPO/'research-wiki/process-memory.json').read_bytes()),'entries_consulted':pm['entries'],'scope':'All three existing entries read. No directly applicable row-independence theorem restriction; process evidence types preserved.'},indent=2)+'\n')
print(json.dumps({'frozen_production_Python_modules':len(seen)}))
