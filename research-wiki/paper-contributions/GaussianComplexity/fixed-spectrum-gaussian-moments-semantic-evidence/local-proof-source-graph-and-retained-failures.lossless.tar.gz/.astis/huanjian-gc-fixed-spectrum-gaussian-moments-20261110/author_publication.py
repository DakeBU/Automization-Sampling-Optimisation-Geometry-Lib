from pathlib import Path
import hashlib, json, sys
sys.dont_write_bytecode = True
sys.path.insert(0, 'tools')
import astis_publication as pub
import astis_semantic_roundtrip as rt
W = Path('.astis/huanjian-gc-fixed-spectrum-gaussian-moments-20261110')
E = Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-gaussian-moments-semantic-evidence')
S = json.loads((W / 'statement-seal-v2.json').read_text())
sha = lambda b: hashlib.sha256(b.encode() if isinstance(b, str) else b).hexdigest()
def put(p, x):
    p = Path(p)
    assert not p.exists(), p
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(x, ensure_ascii=False, indent=2) + '\n')
name = S['producer']['name']
file = Path(S['producer']['planned_file'])
test = Path(S['actual_private_consumer']['planned_file'])
sig = S['producer']['signature']
csig = S['actual_private_consumer']['signature']
for p, s, n in [(file, sig, 'theorem actual_diagonal_gaussian_quadratic_means'),
                 (test, csig, 'private theorem actual_gaussian_cosine_alias_series')]:
    assert p.read_text().split(n, 1)[1].split(' := by', 1)[0] == s.split(n, 1)[1].rstrip(), p
focus = Path('.astis/huanjian-resume-20261103/20261109T160228634551Z-gaussian-moments-actual-gaussian-consumer-focused-build-v1.receipt.json')
kernel = Path('.astis/huanjian-resume-20261103/20261109T160338648836Z-gaussian-moments-actual-kernel-sealed-types-and-parent-uses-v1.receipt.json')
for p in [focus, kernel]:
    x = json.loads(p.read_text())
    assert x['exit_code'] == 0 and sha(Path(x['log']).read_bytes()) == x['log_sha256']
klog = Path(json.loads(kernel.read_text())['log']).read_text()
assert 'ACTUAL_PRIVATE_SEALED_LITERAL_KERNEL_TYPE_APPLICATION_PASS' in klog and 'sorryAx' not in klog
short = 'Under the actual centered Gaussian with diagonal inverse-precision covariance, the squared norm and cosine quadratic form have the reciprocal-spectrum means below. Both integrands are integrable.'
formula = r'\mathbb E\|U\|^2=\sum_{i=1}^{d}\lambda_i^{-1},\qquad\mathbb E[U^\top D_nU]=\sum_{i=1}^{d}\frac{\cos(n\theta_i)}{\lambda_i}.'
assumptions = [
    r'Fix integers \(d\ge2\) and \(1\le n<d\), and a real parameter \(\kappa\ge2\). Lean represents the positive integer mode by a natural number with these exact bounds.',
    r'For \(i=1,\ldots,d\), set \(\theta_i=(i-\tfrac12)\pi/d\), \(\lambda_i=(\kappa+1)/2+(\kappa-1)\cos\theta_i/2\), and \(\Lambda=\operatorname{diag}(\lambda_i)\). The Lean index is \(i\in\mathrm{Fin}\,d\), so its angle is \((i.\mathrm{val}+1/2)\pi/d\).',
    r'Let \(U\sim N(0,\Lambda^{-1})\) in real Euclidean space and \(D_n=\operatorname{diag}(\cos(n\theta_i))\). The measure is literally \(\mathrm{multivariateGaussian}\,0\,\Lambda^{-1}\); its matrix argument is covariance, while \(\Lambda\) is precision.',
    r'The displayed quadratic form has coordinate presentation \(Q(x)=\sum_i\cos(n\theta_i)x_i^2\): multiplication by a diagonal matrix scales its ith coordinate, and the dot product then gives this sum. No arbitrary law, covariance witness or moment certificate is supplied.'
]
steps = [
    {'title': 'Establish the intended inverse-precision domain',
     'text': 'The cosine lower bound and κ≥2 give λ_i≥1. Thus Λ is positive definite. Multiplying the diagonal reciprocal matrix by Λ gives the identity, which proves the actual matrix inverse formula. This avoids relying on the totalized inverse outside its invertible domain; the covariance is positive definite as well.',
     'formula': r'\lambda_i\ge\frac{\kappa+1}{2}-\frac{\kappa-1}{2}=1,\qquad\Lambda^{-1}=\operatorname{diag}(\lambda_i^{-1})\succ0.',
     'lean': 'heigenlower/heigenpos produce positivity from Real.neg_one_le_cos. hΛpos uses Matrix.PosDef.diagonal, and hΛpos.inv.posSemidef supplies the covariance API domain. hinv uses Matrix.inv_eq_left_inv and an actual diagonal multiplication identity, with heigenne discharging every cancellation.'},
    {'title': 'Obtain actual Gaussian coordinate second moments',
     'text': 'Coordinate projections are continuous linear functionals of the fixed Gaussian measure, so each belongs to L². Its mean is zero by commuting the projection with the vector integral. Mathlib evaluates its variance as the diagonal covariance entry. Centering therefore identifies the actual second moment with λ_i⁻¹.',
     'formula': r'\mathbb E U_i=0,\qquad U_i\in L^2,\qquad\mathbb E U_i^2=\operatorname{Var}(U_i)=(\Lambda^{-1})_{ii}=\lambda_i^{-1}.',
     'lean': 'hcoordL2 calls IsGaussian.memLp_dual for EuclideanSpace.proj. hmean uses ContinuousLinearMap.integral_comp_comm and integral_id_multivariateGaussian. hmoment uses variance_eval_multivariateGaussian, variance_eq_integral, the zero mean and hinv. hcoordint is the produced integrability of each coordinate square.'},
    {'title': 'Integrate the two finite coordinate sums',
     'text': 'The Euclidean norm squared is the sum of coordinate squares. Q is the literal finite diagonal quadratic sum defined above. Finite sums and constant multiples of integrable functions are integrable; finite integral linearity and the coordinate second moments give both means. No independence or fourth moments are needed here.',
     'formula': r'\|x\|^2=\sum_i x_i^2,\quad Q(x)=\sum_i\cos(n\theta_i)x_i^2,\quad\int\sum_i c_ix_i^2\,d\mu=\sum_i c_i\int x_i^2\,d\mu.',
     'lean': 'hnorm is EuclideanSpace.real_norm_sq_eq. hnormint and hQint use integrable_finsetSum and Integrable.const_mul, then integral_finsetSum and integral_const_mul justify the two actual Bochner integral equalities. The source-domain hd/hn/hnd remain in the exact sealed interface even though this analytic proof works for a larger range.'},
    {'title': 'Pass the actual Gaussian mean to the cosine expansion',
     'text': 'For the private consumer, define r and the integer alias coefficient beside the series below. The new producer first supplies Q-integrability and the actual Gaussian expectation-to-grid identity. C7 supplies the normalized reciprocal spectrum and absolute convergence at each grid point. Since the cosine weight has absolute value at most one, the weighted series is summable and the finite grid sum can be exchanged with it.',
     'formula': r'\begin{gathered}r=\frac{\sqrt\kappa-1}{\sqrt\kappa+1},\quad A_d(k)=\begin{cases}(-1)^{k/(2d)},&2d\mid k,\\0,&2d\nmid k,\end{cases}\quad k\in\mathbb Z,\\\mu_n=\mathbb E Q(U)=\frac1{\sqrt\kappa}\left[\sum_i\cos(n\theta_i)+2\sum_{j\ge1}(-r)^j\sum_i\cos(n\theta_i)\cos(j\theta_i)\right].\end{gathered}',
     'lean': 'The private actual_gaussian_cosine_alias_series calls actual_diagonal_gaussian_quadratic_means in hactual; its integrability and expectation equality are used in the final result. Canonical actual_inverse_spectrum_cosine_expansion supplies heq/habs. hmajor/hsgnorm prove weighted absolute convergence and Summable.tsum_finsetSum is the scalar finite-grid exchange, separate from the Gaussian finite-integral linearity above.'},
    {'title': 'Evaluate the two signed alias modes',
     'text': 'The range 1≤n<d makes the constant grid mode zero. Product-to-sum and the all-integer midpoint alias identity evaluate the remaining two inner sums. Each contributes d times A_d, giving the displayed factor d/√κ. Summability of the supported series is produced. In Lean j≥1 is represented by Nat j+1, cast to Int before subtracting n, so negative shifted modes remain intact.',
     'formula': r'\mathbb E Q(U)=\frac d{\sqrt\kappa}\sum_{j\ge1}(-r)^j\bigl[A_d(j-n)+A_d(j+n)\bigr],\qquad\sum_{j\ge1}\left|(-r)^j\bigl[A_d(j-n)+A_d(j+n)\bigr]\right|<\infty.',
     'lean': 'hcos calls canonical actual_midpoint_grid_cosine_alias at n and at both integer shifts. hnnon/hzero discharge the low-mode guard, hprod is product-to-sum, and hterm proves 2G_j=dF_j. hFpoint transports summability to F and hseries/hexchange finish the equality. The compiled private consumer has exactly the new Gaussian means, C7 and GridAlias as public ASTIS parents after generated auxiliaries are expanded.'}
]
boundary = 'This packet proves the actual diagonal Gaussian expectation-to-grid identities and an actual private summable Gaussian cosine alias-series precursor. Closed C8 tail partitions/resummations, fourth moments/independence/variances, normalized bias, orthogonal target transport, Krylov and adaptive algorithm/output laws remain open. Exact oracle, TV precision, deterministic worst-case query caps, explicit expected-cost adapters and both full main lower bounds remain open. Independent source verification, shared integration, desktop/mobile/graph acceptance, remote publication and purification/Exposition Seal are separate stages.'
source = {'url': 'https://arxiv.org/html/2610.20492v1#A3.Ex140',
    'edition': 'arXiv2610.20492v1; raw HTML SHA2566bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915',
    'anchor': 'A3.SS3.p4.1/A3.Ex140; standing family S4.SS1.p1.1/S4.E11; actual law and integer range S4.Thmtheorem5.p1.1. Private Gaussian alias-series precursor A3.SS3.p4.2,p6.1/A3.Ex144.',
    'wording_status': 'faithful paraphrase', 'attribution': 'Huanjian Zhou and Taiji Suzuki, On Complexity of Gaussian Sampling.',
    'scope': 'Two actual Gaussian means reduced to reciprocal grid sums, with implicit integrability made explicit as outputs. The private consumer gives the Gaussian alias-supported series, not closed FactC8 or full Lemma4.5.'}
unit = {'kind': 'theorem', 'reading_layout': 'progressive', 'declaration': name,
    'title': 'Actual Gaussian quadratic means on the cosine spectrum',
    'reader_note': 'The two expectation identities appear first. Parameters, actual measure, formula proof and exact Lean are folded beside them.',
    'statement': short, 'formula': formula, 'assumptions': assumptions,
    'notation': [{'symbol': r'\(\mu,\ M,\ \mu_n\)',
        'text': 'The fixed Gaussian measure and its two genuine integrals; neither integrand is defined to equal a deterministic sum.',
        'formula': r'\mu=N(0,\Lambda^{-1}),\quad M=\int\|x\|^2\,d\mu,\quad\mu_n=\int Q(x)\,d\mu.'}],
    'steps': steps, 'astis_dependencies': [],
    'mathlib_dependencies': ['Matrix.PosDef.diagonal', 'Matrix.PosDef.inv', 'Matrix.inv_eq_left_inv',
        'IsGaussian.memLp_dual', 'MeasureTheory.MemLp.integrable_sq', 'ContinuousLinearMap.integral_comp_comm',
        'ProbabilityTheory.integral_id_multivariateGaussian', 'ProbabilityTheory.variance_eval_multivariateGaussian',
        'ProbabilityTheory.variance_eq_integral', 'EuclideanSpace.real_norm_sq_eq',
        'MeasureTheory.integrable_finsetSum', 'MeasureTheory.integral_finsetSum', 'MeasureTheory.integral_const_mul', 'Real.neg_one_le_cos'],
    'lean_statement': 'Exactly the sealed d>=2, κ>=2, Nat mode1<=n<d; literal midpoint spectrum, diagonal precision, actual multivariateGaussian covariance Λ inverse and coordinate Q. Both integrability facts and both expectation identities are conclusions.',
    'lean_proof': 'Positive diagonal and actual inverse are internal. Actual Gaussian L², centering and covariance produce coordinate moments; finite integral linearity gives both means. The private consumer materially joins this new node to canonical C7 and all-integer GridAlias.',
    'boundary': boundary, 'sources': [{**source, 'label': 'Zhou–Suzuki Appendix C.3 actual Gaussian moments and alias-series use'}],
    'tests': ['lake build Tests.GaussianComplexityFixedSpectrumGaussianMoments']}
put('website/content/declaration_lessons/huanjian-fixed-spectrum-gaussian-moments.json', {'schema_version': 1, 'units': [unit]})
aid = 'ASTIS-RT-20261110-HuanjianFixedSpectrumGaussianMoments'
binding = {'declaration': name, 'cell': 'ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-gaussian-moments',
    'role': 'proof-edge', 'supports': ['actual-norm-mean', 'actual-cosine-quadratic-mean', 'actual-integrability'],
    'boundary': boundary, 'audit_id': aid, 'assumption_deltas': [
        {'source': 'd>=2, κ>=2 and positive integer1<=n<d in the literal hard family.',
         'lean': 'Exactly d:Nat, hd:2<=d, κ:Real, hκ:2<=κ, n:Nat, hn:1<=n, hnd:n<d.',
         'classification': 'same', 'reason': 'No positivity, inverse, covariance, L², moment, independence or interchange certificate becomes an input. Source mode is represented by Nat with its full positive range.'},
        {'source': 'U~N(0,Λ^-1), with Λ the diagonal cosine precision; M=E||U||² and μ_n=E[U^T D_n U].',
         'lean': 'Literal multivariateGaussian0 Λ^-1 on real Euclidean space; actual norm² and coordinate presentation Q=Σcos(nθ_i)x_i².',
         'classification': 'same', 'reason': 'The constructor takes covariance, not precision. Positive definiteness and actual diagonal inversion are proved. Diagonal multiplication followed by dot product gives the coordinate presentation; no arbitrary law callback or redefining Q as its expected value.'},
        {'source': 'Since E U_i²=1/λ_i, finite sums give Ex140.',
         'lean': 'Both integrability facts are outputs; coordinate L², zero mean, covariance and actual finite-integral linearity are proved inside.',
         'classification': 'source-implicit', 'reason': 'These make the source expectations meaningful and prevent totalized Bochner integrals from serving as default-zero shortcuts. No fourth-moment or independence assumption is required for these means.'},
        {'source': 'C7 and the finite cosine aliases yield the weighted μ_n series before the tail resummations.',
         'lean': 'Private actual Gaussian Q-integrability and integral alias-series equality, with Summable produced and Int subtraction before evaluating shifts.',
         'classification': 'same', 'reason': 'The NEW Gaussian means and both canonical C7/GridAlias nodes are actually called. Infinite exchange is scalar finite-grid/tsum exchange, not an assumed Gaussian Fubini premise; no closed C8 result is claimed.'}]}
text = ' '.join([short, formula, *assumptions])
item = {'id': 'huanjian-fixed-spectrum-gaussian-moments', 'library': 'samplewiki',
    'chapter': 'gaussian-sampling-complexity', 'chapter_path': 'example-cases/samplewiki/companions/gaussian-sampling-complexity.html',
    'title': unit['title'], 'source': source, 'statement': text,
    'formulae': [{'label': 'Actual Gaussian expectation-to-grid means', 'tex': formula}], 'assumptions': assumptions,
    'obligations': [{'id': 'actual-norm-mean', 'label': 'Actual Gaussian squared-norm mean is the reciprocal spectrum sum.'},
        {'id': 'actual-cosine-quadratic-mean', 'label': 'Actual cosine quadratic mean is the weighted reciprocal spectrum sum.'},
        {'id': 'actual-integrability', 'label': 'Both actual Gaussian integrands are integrable.'}], 'bindings': [binding]}
put('website/content/publications/huanjian-fixed-spectrum-gaussian-moments.json', {'schema_version': 1, 'items': [item]})
head, body = sig.split(' :\n', 1)
statement = '∀' + head.removeprefix('theorem actual_diagonal_gaussian_quadratic_means') + ',\n' + body
context = ['Fin d is the standard finite index type with values zero through d minus one; the displayed sums run over every coordinate.',
    'EuclideanSpace Real (Fin d) has its usual Euclidean norm. WithLp.ofLp exposes the real coordinate vector, and Matrix.diagonal is the ordinary diagonal matrix.',
    'ProbabilityTheory.multivariateGaussian m S is the image of the standard Gaussian by x↦m+toEuclideanCLM(CFC.sqrt S)x. The argument S is covariance on its positive semidefinite domain; the standard totalized square root is zero outside that domain.',
    'Matrix inverse and real inverse are standard totalized inverses. Integrable is actual Bochner integrability under the displayed measure, and the integral is the real Bochner integral. The proposition asserts integrability as part of its conclusion.',
    'Real.cos, Real.pi, casts to reals, natural exponents and all finite sums have their standard meanings.']
audit = {'id': aid, 'state': 'draft',
    'source': {'source_id': 'arxiv2610.20492v1-actual-diagonal-gaussian-means', 'url': source['url'],
        'anchor': source['anchor'], 'original_text': text, 'text_sha256': sha(text), 'source_snapshot_sha256': S['source']['raw']['sha256']},
    'lean': {'declaration': name, 'file': str(file), 'statement': statement, 'statement_sha256': sha(statement),
        'formalizer': 'huanjian_gc_20261110_fixed_spectrum_gaussian_moments', 'compiled': True, 'decoder_context': context},
    'reconstruction': {}, 'semantic_slots': {}, 'deltas': [], 'verdict': 'pending',
    'source_review': {'state': 'pending'}, 'repairs': []}
pub.inputs.cache_clear()
pub.load.cache_clear()
audit['publication_binding_sha256'] = pub.binding_digest(item, binding)
audit['publication_context'] = pub.review_context(item, binding)
put('research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-gaussian-moments.json', audit)
pub.check_advance([name], reviewed=False)
packet = rt.decoder_packet(audit)
neutral = Path('.astis/semantic-neutral-20261110/47c18e')
assert not neutral.exists()
neutral.mkdir(parents=True)
put(neutral / 'input.json', packet)
put(E / 'decoder-input.json', packet)
record = {'producer_raw_sha256': sha(file.read_bytes()), 'Test_raw_sha256': sha(test.read_bytes()),
    'producer_signature_sha256': S['producer']['signature_sha256'],
    'private_consumer_signature_sha256': S['actual_private_consumer']['signature_sha256'],
    'actual_public_ASTIS_producer_parents': [], 'actual_public_ASTIS_private_consumer_parents': [name,
        'AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumCosineExpansion.actual_inverse_spectrum_cosine_expansion',
        'AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumGridAlias.actual_midpoint_grid_cosine_alias'],
    'generated_auxiliaries_expanded_with_complete_proof_repr': True,
    'publication_binding_sha256': audit['publication_binding_sha256'], 'anonymous_statement_sha256': sha(statement),
    'anonymous_packet_canonical_sha256': packet['packet_sha256'], 'neutral_input': str(neutral / 'input.json'),
    'neutral_input_raw_sha256': sha((neutral / 'input.json').read_bytes()),
    'actual_focus_receipt': str(focus), 'actual_kernel_receipt': str(kernel),
    'compile_scope': 'Actual current files over ca3665 HEAD; these new files are not yet an immutable candidate commit.',
    'source_review': 'pending', 'decoder': 'pending', 'sourceV_or_integration_or_Goal_complete': False}
put(E / 'publication-draft-record.json', record)
print(json.dumps(record, ensure_ascii=False))
