import Tests.GaussianComplexityFixedSpectrumNormalizer
open Lean in
run_cmd do
  let env ← getEnv
  let producer := `AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumNormalizer.actual_normalizing_integral
  let matches := env.constants.toList.filter fun (name, _) =>
    name.toString.startsWith "_private.Tests.GaussianComplexityFixedSpectrumNormalizer" &&
    name.toString.endsWith ".actual_gaussian_density_consumer"
  unless matches.length == 1 do throwError "Expected exactly one actual named Test consumer"
  let consumer := matches.head!.1
  let expectedProducer := [
    `AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumAdmissibility.actual_precision_admissible,
    `AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumDeterminant.actual_precision_det,
    `AutoSamplingTheory.TechnicalLemmas.Measure.GaussianPrecisionDensity.multivariateGaussian_eq_withDensity_of_posDef]
  for (name, expected) in [(producer, expectedProducer), (consumer, producer :: expectedProducer)] do
    let some info := env.find? name | throwError "Missing actual target"
    let some proof := info.value? (allowOpaque := true) | throwError "Missing actual proof"
    let used := proof.getUsedConstants.toList.filter fun n => n.toString.startsWith "AutoSamplingTheory."
    unless used.length == expected.length && expected.all used.contains do
      throwError m!"Actual ASTIS parents differ for {name}: {used}"
    logInfo m!"ACTUAL_TARGET {name}"
    for dep in used do logInfo m!"ACTUAL_ASTIS_PARENT {dep}"
  logInfo "Actual production and Test ASTIS parent inventories match exactly; no credit from imports/counts."
