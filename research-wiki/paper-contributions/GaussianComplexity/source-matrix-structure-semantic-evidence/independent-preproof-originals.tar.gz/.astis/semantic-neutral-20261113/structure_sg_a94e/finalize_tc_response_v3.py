from pathlib import Path
import datetime, hashlib, json

OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[2]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def own(n):return sha(OUT/n)
def write(n,d):
    p=OUT/n
    if p.exists():raise RuntimeError(f'Refusing to overwrite {n}')
    p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
cp=ROOT/'.astis/semantic-neutral-20261113/structure_tc_b7c6/phase2/challenge.v1.json'
rp=ROOT/'.astis/semantic-neutral-20261113/structure_tc_b7c6/phase2/REPORT.v1.md'
assert sha(cp)=='7e72a3ba826a97ca7a9748c645a6b14fca14cfe7aaadf61af1820f9a21a7ae03'
assert sha(rp)=='8cf9ca1a4f94e580df31030bd6fa25d135c6d9a54e28c98223e47e1a622d6cad'
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
response={'version':'source-only-TC-response-v3','created_utc':now,
 'status':'PROPOSED-BOUNDED-CORRECTIONS; awaiting distinct TC re-review; no source/topology/normalV verdict',
 'exact_challenge':{'path':str(cp.relative_to(ROOT)),'sha256':sha(cp),'findings':['TC1','TC2']},
 'exact_TC_report':{'path':str(rp.relative_to(ROOT)),'sha256':sha(rp)},
 'seal_sha256':'0164b6bcb7f1362c27e459eccf6a68a72a7cea81272f15377e7c193af18e3c60',
 'responses':[
  {'finding':'TC1','acknowledgment':'The v2 port map retained the raw-first v1 graph digest. That was stale for the proposed v2 packet.',
   'change':'Versioned internal-obligation-ports.v3.json binds source_graph_path and source_graph_sha256 to source-graph.source-only.v3.json. It also binds the exact successor coverage path/digest. All seven mathematical port bodies are unchanged.',
   'evidence':['tc-repair-v3.exact.diff','tc-repair-v3.check.json']},
  {'finding':'TC2','acknowledgment':'The complete p14.6 and Ex120 blocks assert substantive variance claims, while weighted-Z represented only their family expression.',
   'change':'Versioned successor coverage marks both complete blocks EXCLUDED with an explicit variance-identity/PSD-inequality reason. Successor graph removes only those two redundant anchors from weighted-Z, preserving its p13.3 family-expression source anchor. No variance prerequisite is added.',
   'exact_original_locators':[
     {'source_id':'A3.SS2.p14.6','lines_1based':[3691,3691],'byte_range_half_open':[831401,832121],'char_range_half_open':[822921,823634],'raw_sha256':'71609139dde2a1506954bab586d353f71e528fd510e2f46a5d80f4ee2d27c1b5'},
     {'source_id':'A3.Ex120','lines_1based':[3692,3698],'byte_range_half_open':[832122,833842],'char_range_half_open':[823635,825324],'raw_sha256':'0c518b77984fa7f3b19ae18d7508bb2a434df786bc107bbb9c7174f4e10877cc'}],
   'evidence':['tc-repair-v3.exact.diff','tc-repair-v3.check.json']}
 ],
 'successor_packet':{n:own(n) for n in ['source-graph.source-only.v3.json','source-coverage.source-only.v3.json','internal-obligation-ports.v3.json','tc-repair-v3.exact.diff','tc-repair-v3.check.json']},
 'unchanged_boundaries':['All raw/v1/v2 source, audit, graph, coverage, port and manifest files remain unchanged.','All graph node statements and edges remain unchanged.','No new caller hypothesis, target proof, source verdict, SAU intake or canonical/ledger mutation.','Independent mean-Hermitian OR routes and source q=0 scope remain unchanged.'],
 'manifest_path_discrepancy':{
   'parent_supplied_missing_path':'.astis/semantic-neutral-20261113/structure_tc_b7c6/phase2/MANIFEST.v1.json',
   'parent_supplied_hash':'4e62f4a27e831b3ecbfbf5ae047b015301aca6ab875cb85f8924a14bc22ce2f4',
   'observed_available_manifest':'.astis/semantic-neutral-20261113/structure_tc_b7c6/phase2/FINAL-MANIFEST.json',
   'observed_available_sha256':'bbf3bd3d69be736c26867484ee4bc055ac54ac865303e5d1e55a97cfaac52dd3',
   'resolution':'The response binds the independently hash-verified exact challenge and report directly. The missing-path read failure, bounded path discovery and successful identity read are preserved; no old TC decision is rewritten or normalized.'
 },
 'required_next_action':'Distinct TC re-review of the exact successor graph, coverage and port map. Extractor does not approve its own repair.'}
write('tc-response.v3.json',response)
names=['source-graph.source-only.v3.json','source-coverage.source-only.v3.json','internal-obligation-ports.v3.json','tc-repair-v3.exact.diff','tc-repair-v3.check.json','tc-response.v3.json','tc_repair_v3.py','finalize_tc_response_v3.py']
manifest={'version':'source-only-successor-packet-v3','created_utc':now,
 'exact_challenge_sha256':sha(cp),'seal_sha256':response['seal_sha256'],
 'files':{n:own(n) for n in names},
 'preserved_predecessors':json.loads((OUT/'tc-repair-v3.check.json').read_text())['old_inputs_unchanged'],
 'check':'Exact bounded-delta assertions pass; graph and coverage hashes in ports recompute; no mathematical/source approval is implied.',
 'review_status':'distinct-TC-re-review-pending'}
write('SUCCESSOR-MANIFEST.v3.json',manifest)
print(json.dumps(manifest,indent=2))
