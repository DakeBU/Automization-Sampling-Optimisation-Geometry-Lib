from pathlib import Path
import json,hashlib,copy,difflib,re,datetime
r=Path(__file__).resolve().parent;repo=r.parents[2];old=repo/".astis/semantic-neutral-20261110/module_6bc291";e=repo/"research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-signal-strength-semantic-evidence"
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
expectedOld="b03582c72b2c874bbbe2a2896a2dc9d70dbd60f920e435f74d171df277b52904"
assert sha(old/"freeze.json")==expectedOld
frozen=json.loads((old/"freeze.json").read_text());originalChecks=[]
for a in frozen["artifacts"]:
 assert sha(old/a["path"])==a["sha256"],a["path"]
 originalChecks.append(a["path"])
pred=e/"source-to-lean-map-v1.json";proposal=e/"exact-C7-locator-precision-overlay-proposal.json";succ=e/"source-to-lean-map-v2-exact-C7-locators.json"
p=json.loads(proposal.read_text());b1=pred.read_bytes();b2=succ.read_bytes();a=json.loads(b1);b=json.loads(b2)
assert sha(pred)==p["predecessor"]["sha256"]=="e98394470a5ae8e6c3d82896112005a9adf5401506450a618498bf8f25d898a0"
assert sha(proposal)=="0d308e333a518f8a44dd94aabf847d68b662b1bb9ccfa9710c2c052749385ee0"
assert sha(succ)==p["successor"]["sha256"]=="7c7f501685077eb30ee9d6160a69046039404034ce429146783509f1a27303bc"
assert b1==(old/"inputs/source-to-lean-map-v1.json").read_bytes()
(r/"inputs/source-to-lean-map-v1.json").write_bytes(b1)
def differences(x,y,path=""):
 if type(x)!=type(y):return [{"path":path,"before":x,"after":y}]
 if isinstance(x,dict):
  assert x.keys()==y.keys(),path
  return [d for k in x for d in differences(x[k],y[k],path+"/"+k)]
 if isinstance(x,list):
  assert len(x)==len(y),path
  return [d for i,(xx,yy) in enumerate(zip(x,y)) for d in differences(xx,yy,path+"/"+str(i))]
 return [] if x==y else [{"path":path,"before":x,"after":y}]
diffs=differences(a,b);assert diffs==p["changes"] and len(diffs)==10
indices=[53,54,55,56,70];expectedNodes=["c:c7","c:geometric","c:rho-algebra","c:majorant","gap:geometric-series"]
assert [a["rows"][i]["source_node"] for i in indices]==expectedNodes
publicFile="AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumCosineExpansion.lean"
text=(repo/publicFile).read_text();lines=text.splitlines();declaration=lines[74]
assert declaration.startswith("theorem actual_inverse_spectrum_cosine_expansion ")
assert "private" not in declaration and "protected" not in declaration
ns=[re.match(r"namespace (.+)",line).group(1) for line in lines[:74] if re.match(r"namespace (.+)",line)]
assert ns==["AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumCosineExpansion"]
publicName=ns[0]+".actual_inverse_spectrum_cosine_expansion"
for i in indices:
 before=a["rows"][i]["providers"][0];after=b["rows"][i]["providers"][0]
 assert before["line"]==15 and before["marker"]=="theorem "
 assert after["line"]==75 and after["marker"]=="theorem actual_inverse_spectrum_cosine_expansion"
 assert before["file"]==after["file"]==publicFile
 assert before["full_file_sha256"]==after["full_file_sha256"]==sha(repo/publicFile)
 assert declaration.startswith(after["marker"])
restored=copy.deepcopy(b)
for d in reversed(diffs):
 parts=d["path"].strip("/").split("/");node=restored
 for k in parts[:-1]:node=node[int(k)] if isinstance(node,list) else node[k]
 assert node[parts[-1]]==d["after"];node[parts[-1]]=d["before"]
assert restored==a
restoredBytes=(json.dumps(restored,ensure_ascii=False,indent=2)+"\n").encode();assert restoredBytes==b1
forward=copy.deepcopy(a)
for d in diffs:
 node=forward;parts=d["path"].strip("/").split("/")
 for k in parts[:-1]:node=node[int(k)] if isinstance(node,list) else node[k]
 assert node[parts[-1]]==d["before"];node[parts[-1]]=d["after"]
assert forward==b
assert (json.dumps(forward,ensure_ascii=False,indent=2)+"\n").encode()==b2
(r/"inverse-restored-v1.json").write_bytes(restoredBytes)
(r/"exact-locator.diff").write_text("".join(difflib.unified_diff(b1.decode().splitlines(True),b2.decode().splitlines(True),fromfile="frozen-v1",tofile="reviewed-v2",n=1)))
currentChecks=[]
for file,h in p["current_unchanged_mathematical_files"].items():
 assert sha(repo/file)==h,file
 currentChecks.append({"path":file,"sha256":h})
# Check protected mathematics against the original independent freeze, not only proposal claims.
for file in ["AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumSignalStrength.lean","Tests/GaussianComplexityFixedSpectrumSignalStrength.lean","website/content/declaration_lessons/huanjian-fixed-spectrum-signal-strength.json","website/content/publications/huanjian-fixed-spectrum-signal-strength.json"]:
 assert (repo/file).read_bytes()==(old/"inputs"/file.replace("/","__")).read_bytes(),file
assert (repo/"research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-signal-strength-statement-seal.json").read_bytes()==(old/"inputs/.astis__huanjian-gc-fixed-spectrum-signal-strength-20261110__statement-seal-v1.json").read_bytes()
assert a["actual_public_parents"]==b["actual_public_parents"]
assert a["source_graph_sha256"]==b["source_graph_sha256"]
reuse=json.loads((old/"canonical-reuse.json").read_text());priorC7=[x for x in reuse["objects"] if x["source"]==publicFile][0]
assert priorC7["source_sha256"]==sha(repo/publicFile)
report={"scope":"Independent metadata precision overlay only after preserved original freeze","original_freeze_sha256":expectedOld,"original_artifacts_rechecked_unchanged":len(originalChecks),"proposal_sha256":sha(proposal),"predecessor_sha256":sha(pred),"successor_sha256":sha(succ),"exact_diff_fields":diffs,"changed_provider_count":5,"changed_field_count":10,"changed_source_nodes":expectedNodes,"all_other_JSON_values_unchanged":True,"inverse_restores_exact_original_JSON":True,"inverse_restores_exact_original_raw_bytes":True,"inverse_raw_sha256":hashlib.sha256(restoredBytes).hexdigest(),"forward_patch_reproduces_exact_successor_raw_bytes":True,"named_public_declaration":{"name":publicName,"file":publicFile,"line":75,"line_text":declaration,"file_sha256":sha(repo/publicFile),"prior_own_native_receipt_sha256":priorC7["receipt_sha256"],"new_native_run":False},"protected_current_files":currentChecks,"source_statements_statuses_roots_and_other_provider_fields_unchanged":True,"compiled_parent_sets_unchanged":True,"source_graph_hash_unchanged":True,"decision":"ACCEPT exact C7 locator precision overlay only","closes_original_locator_precision_HOLD_for_v2_only":True,"original_v1_and_original_review_freeze_remain_unchanged":True,"source_equivalence_or_sourceV_authority":False,"canonical_or_global_acceptance_authority":False,"new_Lean_native_static_browser_gate_or_canonical_mutations":[],"created_utc":datetime.datetime.now(datetime.timezone.utc).isoformat()}
(r/"overlay-check-report.json").write_text(json.dumps(report,ensure_ascii=False,indent=2)+"\n")
print(json.dumps(report,ensure_ascii=False,indent=2))
