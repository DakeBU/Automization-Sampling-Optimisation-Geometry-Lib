#!/usr/bin/env python3
"""Optional portable reproduction; original executed evidence remains authoritative."""
import argparse,hashlib,json,os,pathlib,subprocess
ap=argparse.ArgumentParser();ap.add_argument('--repo',type=pathlib.Path,required=True);ap.add_argument('--output',type=pathlib.Path,required=True);a=ap.parse_args()
here=pathlib.Path(__file__).resolve().parent;m=json.loads((here/'input-manifest.json').read_text())
repo=a.repo.resolve();out=a.output.resolve();out.mkdir(parents=True,exist_ok=False)
lean=pathlib.Path.home()/'.elan/toolchains/leanprover--lean4---v4.33.0/bin/lean'
assert hashlib.sha256(lean.read_bytes()).hexdigest()==m['lean_binary']['sha256']
def run(label,args,cwd=repo,env=None):
    p=subprocess.run([str(s) for s in args],cwd=cwd,env=env,capture_output=True)
    (out/(label+'.stdout')).write_bytes(p.stdout);(out/(label+'.stderr')).write_bytes(p.stderr)
    (out/(label+'.receipt.json')).write_text(json.dumps({'argv':[str(s) for s in args],'cwd':str(cwd),'exit_code':p.returncode,'stdout_sha256':hashlib.sha256(p.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(p.stderr).hexdigest()},indent=2)+'\n')
    assert p.returncode==0,label
    return p
run('version',[lean,'--version']);run('binary-file',['file',lean])
for d in m['dependencies']:
    dep=repo/'.lake/packages'/d['name']
    assert run('dep-'+d['name']+'-head',['git','rev-parse','HEAD'],dep).stdout.decode().strip()==d['head']
    assert not run('dep-'+d['name']+'-status',['git','status','--porcelain=v1','--untracked-files=all'],dep).stdout
olean=out/'olean';olean.mkdir();env=dict(os.environ);env['LEAN_PATH']=os.pathsep.join([str(olean)]+[str(repo/'.lake/packages'/d['name']/'.lake/build/lib/lean') for d in m['dependencies']])
for i,p in enumerate(m['modules']):
    src=here/'inputs'/p;assert hashlib.sha256(src.read_bytes()).hexdigest()==m['files'][p]['sha256']
    dst=olean/pathlib.Path(p).with_suffix('.olean');dst.parent.mkdir(parents=True,exist_ok=True)
    run('compile-'+str(i),[lean,'-R',here/'inputs','-o',dst,src],here/'inputs',env)
literal=here/'scratch/LiteralApplications.lean'
run('literal',[lean,'-R',here/'scratch','-o',olean/'LiteralApplications.olean',literal],here/'scratch',env)
inspection=(here/'scratch/InspectNativeV2.lean').read_text()
inspection=inspection.replace('/Users/zhouhuanjian/ASTIS-GC/.astis/semantic-neutral-20261112/wf_native_64a2/native-environment-v2.json',str(out/'native-environment.json'))
probe=out/'InspectNativeReplay.lean';probe.write_text(inspection)
run('inspection',[lean,'-R',out,probe],out,env)
print('Fresh six-module native reproduction completed; inspect its new receipts separately from the original evidence.')
