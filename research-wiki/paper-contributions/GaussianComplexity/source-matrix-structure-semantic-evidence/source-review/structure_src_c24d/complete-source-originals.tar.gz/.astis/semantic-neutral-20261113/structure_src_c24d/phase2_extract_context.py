from pathlib import Path
import subprocess,json,hashlib
out=Path(__file__).resolve().parent
math=Path('/Users/zhouhuanjian/ASTIS-GC/.lake/packages/mathlib')
pin='db584cd6d46c92f209a44c0f1c829460d327499d'
requests={
 'Mathlib/LinearAlgebra/Matrix/Defs.lean':[(50,65)],
 'Mathlib/Topology/Instances/Matrix.lean':[(35,90)],
 'Mathlib/Topology/UniformSpace/Matrix.lean':[(15,42)],
 'Mathlib/MeasureTheory/Constructions/BorelSpace/Basic.lean':[(47,53),(105,138),(631,654)],
 'Mathlib/Probability/Distributions/Gaussian/Multivariate.lean':[(45,95),(130,145)],
 'Mathlib/Probability/Independence/Basic.lean':[(125,145),(660,678)],
 'Mathlib/LinearAlgebra/Matrix/Hermitian.lean':[(35,55)],
 'Mathlib/MeasureTheory/Function/L1Space/Integrable.lean':[(44,69)],
 'Mathlib/MeasureTheory/Integral/Bochner/Basic.lean':[(136,170),(266,280)]}
manifest=[]
for rel,ranges in requests.items():
 p=subprocess.run(['git','-C',str(math),'show',pin+':'+rel],capture_output=True)
 dest=out/'phase2-inputs/mathlib'/rel; dest.parent.mkdir(parents=True,exist_ok=True); dest.write_bytes(p.stdout)
 manifest.append({'path':rel,'revision':pin,'sha256':hashlib.sha256(p.stdout).hexdigest(),'exit_code':p.returncode,'stderr':p.stderr.decode()})
 print('\n===== '+rel+' =====')
 lines=p.stdout.decode().splitlines()
 for start,end in ranges:
  for j in range(start,end+1):
   if j<=len(lines): print(f'{j}: {lines[j-1]}')
(out/'phase2-mathlib-context-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
