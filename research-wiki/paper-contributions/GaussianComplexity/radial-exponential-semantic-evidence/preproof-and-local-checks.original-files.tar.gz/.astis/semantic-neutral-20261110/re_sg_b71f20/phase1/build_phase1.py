from pathlib import Path
import json, hashlib, datetime, sys
BASE=Path(__file__).resolve().parent
inv=json.loads((BASE/'source-inventory-raw.json').read_text())
ex=json.loads((BASE/'anchored-excerpts.json').read_text())
items={x['source_id']:x for x in inv['items']}
def A(i):
    x=items.get(i,ex.get(i))
    if x is None:raise KeyError(i)
    return {'source_id':i,**x['anchor']}
nodes=[]
def node(ident,kind,statement,refs,status='source-asserted; not formalized',scope='selected scalar spine'):
    nodes.append({'id':ident,'kind':kind,'mathematical_content':statement,'source_anchors':[A(i) for i in refs],'status':status,'scope':scope})
node('standing-parameters','source-standing','q is an integer ≥0; 2q+1<d. Set r=q+1 and n=2q+1; hence r≥1, d≥2, 2r≤d. i ranges from 1 through d. q=0 is admitted.',['S4.Thmtheorem4.p1.m2','S4.Thmtheorem4.p1.m3','A3.SS2.p1','A3.SS2.p18'])
node('hard-family-context','source-context','d≥2, κ≥2; θ_i=(i−1/2)π/d; λ_i=(κ+1)/2+(κ−1)cosθ_i/2; Λ=diag λ. Haar O, A=OΛOᵀ, potential and target are context only.',['S4.SS1.p1'],scope='context; not a scalar parent')
node('construction-citation-22','external-citation-context','Source [22], OpenAI (2026), Subpolynomial query complexity for well-conditioned log-concave sampling; Section9.2 construction and Lemma9.2 deferred rotation. This citation is not a scalar-moment proof.',['S4.SS1.p1','S4.SS2.SSS0.Px1.p1','bib.bib3'],scope='context only')
node('krylov-context','source-definition-context','K_q=span{Λ^j g_a:1≤a≤q+1,0≤j≤q}; n=2q+1; D_n=diag cos(nθ_i). Definition and intended uniform consumer only.',['S4.SS2.SSS0.Px1.p2','S4.SS2.SSS0.Px2.p1'],scope='context; not a scalar parent')
node('starter-law','source-standing','g_1,…,g_{q+1} are independent N(0,I_d) vectors. The scalar reconstruction uses this law as standing setup, directly restated in Lemma4.4, not the output-representation conclusion.',['S4.Thmtheorem3.p1.m4','S4.Thmtheorem4.p1.m4','S4.Thmtheorem4.p1.m5'])
node('row-definition-law','source-definition-and-law','γ_i=((g_1)_i,…,(g_r)_i)∈ℝ^r. For each fixed i, γ_i∼N(0,I_r), with coordinate variance one.',['A3.SS2.p1'])
node('row-independence-context','source-assertion-context','γ_1,…,γ_d are independent. This is needed for the matrix branch and is not a parent of the scalar moment/tail/union-bound/bias.',['A3.SS2.p1'],scope='separate downstream fact; not a scalar parent')
node('t-and-B-context','source-definition-context','t_i=(1,√2cosθ_i,…,√2cos(qθ_i))∈ℝ^r; B∈ℝ^{d×r²} has i-th row d^(−1/2)(γ_i⊗t_i)ᵀ.',['A3.SS2.p1'],scope='scaling guard and downstream context')
node('R-definition','source-definition','R_i=||γ_i||²≥0, with no factor 1/d and no t_i factor.',['A3.SS2.p10.m2'])
node('L-definition','source-definition','L=2r+3log(1000d), literally; d≥2 implies log(1000d)>0, and r≥1 implies L>0.',['A3.SS2.p10.m1'])
node('basic-regularity-gap','SOURCE_GAP','The source leaves measurability implicit: Gaussian random vectors are measurable; squared norm and exponential are continuous/Borel; R_i≥0 and exp(R_i/3)>0. Finite exponential integrability is derived by the Gaussian computation, not assumed here.',['A3.SS2.p10'],'background bridge; unformalized')
node('gaussian-density-scaling-gap','SOURCE_GAP','Unwritten background route A: N(0,I_r) has density (2π)^(−r/2)exp(−||z||²/2); multiplying by exp(||z||²/3) leaves exp(−||z||²/6). Scale z=√3 y; Jacobian 3^(r/2). Normalization gives finite integral 3^(r/2).',['A3.SS2.p10.m3'],'background derivation; not literally supplied by source')
node('gaussian-product-gap','SOURCE_GAP','Unwritten alternative route B: standard Gaussian independent coordinates; Tonelli/product integration of nonnegative factors; each 1D expectation exp(Z²/3) equals √3 by its Gaussian integral. Product gives finite 3^(r/2). This is OR-alternative to the r-dimensional scaling route.',['A3.SS2.p10.m3'],'background derivation; not literally supplied by source')
node('moment-one-third','source-unnamed-estimate','E exp(R_i/3)=3^(r/2), under the actual N(0,I_r) row law; finite integrability is part of the omitted background computation.',['A3.SS2.p10.m3'])
node('markov-reuse','named-reused-result','For measurable nonnegative integrable W and a>0, P(W>a)≤E W/a. Source names Markov’s inequality here, without a bibliographic link. W=exp(R_i/3), a=exp((2r+3x)/3).',['A3.SS2.p10.1'],'reused background; not proved here')
node('log-three-comparison','source-unnamed-estimate','(log3)/2<2/3. Source gives no derivation; possible elementary bridge: exp(4/3)>1+4/3+(4/3)²/2=29/9>3.',['A3.SS2.p10.m5'])
node('single-row-tail','source-unnamed-estimate','For each i and every real x≥0, P(R_i>2r+3x)≤exp((r/2)log3−2r/3−x)≤exp(−x).',['A3.SS2.p10.m4','A3.Ex104.m1'])
node('log-substitution-gap','SOURCE_GAP','For d≥2: x0=log(1000d)≥0; exp(−x0)=1/(1000d); 2r+3x0=L. For s≥0, x=x0+s/3≥0 and 2r+3x=L+s.',['A3.SS2.p10','A3.SS2.p11'],'unwritten algebra/domain bridge; unformalized')
node('tail-at-L','source-implicit-estimate','For each i, P(R_i>L)≤1/(1000d).',['A3.SS2.p10'])
node('T-event','source-definition','T={R_i≤L for every i=1,…,d}. Its complement is the union of {R_i>L}.',['A3.Ex105.m1'])
node('T-probability','source-unnamed-estimate','P(T)≥1−d/(1000d)=0.999 by finite union bound; independence is not used.',['A3.SS2.p10.m6'])
node('shifted-tail','source-unnamed-estimate','For each i and every real s≥0, P(R_i>L+s)≤exp(−s/3)/(1000d).',['A3.SS2.p11'])
node('layer-cake-gap','SOURCE_GAP','For R≥0,L≥0: R1_{R>L}=L1_{R>L}+(R−L)_+ and (R−L)_+=∫₀∞1_{R>L+s}ds. Nonnegative Tonelli gives the expectation identity before finiteness; ∫₀∞exp(−s/3)ds=3. No boundary atom assumption needed.',['A3.Ex106.m1','A3.Ex106.m2'],'background bridge; unformalized')
node('tail-first-moment','source-unnamed-estimate','E[R_i1_{R_i>L}]=L P(R_i>L)+∫₀∞P(R_i>L+s)ds≤(L+3)/(1000d).',['A3.Ex106.m1','A3.Ex106.m2'])
node('second-moment','source-unnamed-background-estimate','E R_i=r from the r standard Gaussian coordinate second moments. Source asserts it without derivation; this is separate from Gaussian fourth moments.',['A3.SS2.p12.m3'])
node('a-definition','source-definition','a=(1/r)E[R_i1_{R_i≤L}]; it is the same for each i because the single-row laws agree. r≥1 is required for division.',['A3.Ex108.m1','A3.SS2.p12'])
node('scalar-bias','source-unnamed-estimate','0≤a≤1 and 1−a=(1/r)E[R_i1_{R_i>L}]≤(L+3)/(1000rd).',['A3.SS2.p12.m4','A3.Ex109.m1'])
node('radial-covariance-consumer','source-unnamed-estimate-context','By radial symmetry E[γ_iγ_iᵀ1_{R_i≤L}]=aI_r. This separate consumer identifies scalar a as a matrix covariance multiplier; it is not needed for the scalar moment or tail.',['A3.Ex108.m1'],scope='separate downstream symmetry branch')
node('Y-definition-consumer','source-definition-context','Y_i=d^(−1)(γ_iγ_iᵀ⊗t_it_iᵀ)1_{R_i≤L}; independent truncated matrices.',['A3.Ex107.m1'],scope='downstream matrix branch')
node('C5-use-consumer','reused-source-result-context','Using C.5 and E Y_i=(a/d)(I_r⊗t_it_iᵀ), the sums of expectations are aI_{r²} and zero in the weighted case. C.5 proof is excluded.',['A3.SS2.p12.m5','A3.Ex110.m1'],scope='downstream use site; C.5 remains excluded boundary')
node('matrix-concentration-boundary','EXCLUDED_BOUNDARY','C.6 matrix branch: centered independent self-adjoint summands, operator/variance bounds using C.5 and Gaussian fourth moments; named bounded matrix Bernstein; two matrix estimates jointly fail with probability ≤0.004. This branch is not reconstructed as a proved result.',['A3.SS2.p13','A3.SS2.p14','A3.SS2.p15','A3.SS2.p16'],'excluded proof; source consumer context only',scope='separate matrix branch')
node('probability-bias-consumer','source-consumer-context','On T original/truncated sums agree. Intersect T (failure≤0.001) with the two concentration events (failure≤0.004): probability≥0.995. Norm bounds are Δ+(1−a) and Δ; no event independence is assumed.',['A3.SS2.p17'],scope='downstream use; not closure of full C.6')
node('C6-full-boundary','EXCLUDED_BOUNDARY','Full simultaneous Gram concentration and absorption into τ_{d,q}; the selected scalar spine is only one ingredient.',['A3.Thmtheorem6','A3.SS2.p18'],'excluded full conclusion',scope='excluded')
node('L44-full-boundary','EXCLUDED_BOUNDARY','Full uniform Krylov-space bound, τ≤1/2, coefficient-vector comparison and probability0.99.',['S4.Thmtheorem4','A3.SS2.p19'],'excluded full conclusion',scope='excluded')
node('C5-full-boundary','EXCLUDED_BOUNDARY','Cosine basis, range(B)=K_q, orthogonality, and matrix expectation identities; no role as parent of the selected scalar estimates.',['A3.Thmtheorem5','A3.SS2.p3','A3.SS2.p4','A3.SS2.p5','A3.SS2.p6','A3.SS2.p7','A3.SS2.p8'],'excluded full proof/conclusion',scope='excluded')
edges=[]
def edge(ident,parents,child,use,discharge,kind='AND',route=None):
    edges.append({'id':ident,'premises':parents,'conclusion':child,'logic':kind,'route':route,'consumer_use_site':A(use),'conditional_premises_discharge':discharge,'authority':'source-only reconstruction; no formal implication certificate'})
edge('e-row-marginal',['standing-parameters','starter-law'],'row-definition-law','A3.SS2.p1','Reindex starter coordinates; a fixed row has r independent variance-one Gaussian coordinates. Across-row independence is not required.')
edge('e-R',['row-definition-law'],'R-definition','A3.SS2.p10.m2','Literal squared Euclidean norm; dimensions r, no B-row scaling.')
edge('e-moment-route-A',['row-definition-law','R-definition','basic-regularity-gap','gaussian-density-scaling-gap'],'moment-one-third','A3.SS2.p10.m3','Gaussian normalization/scaling derives the integral value and finite exponential integrability. No moment/tail certificate is assumed.',route='moment-route-A-density')
edge('e-moment-route-B',['row-definition-law','R-definition','basic-regularity-gap','gaussian-product-gap'],'moment-one-third','A3.SS2.p10.m3','Nonnegative product integration and 1D Gaussian integral derive the same finite value. This is an alternative to route A.',route='moment-route-B-product')
edge('e-tail',['moment-one-third','basic-regularity-gap','markov-reuse','log-three-comparison','standing-parameters'],'single-row-tail','A3.Ex104.m1','x≥0 is explicit; threshold exp((2r+3x)/3)>0; monotone exp matches strict events; r≥1 gives nonpositive r((log3)/2−2/3).')
edge('e-tail-L',['single-row-tail','L-definition','log-substitution-gap'],'tail-at-L','A3.SS2.p10.3','d≥2 establishes x0≥0, positive denominator and exp(−log(1000d))=1/(1000d).')
edge('e-good-event',['tail-at-L','T-event','standing-parameters'],'T-probability','A3.SS2.p10.3','Union bound over exactly d rows: d/(1000d)=0.001. No independence.')
edge('e-shifted',['single-row-tail','L-definition','log-substitution-gap'],'shifted-tail','A3.SS2.p11','s≥0 implies x0+s/3≥0; exact threshold L+s.')
edge('e-layercake-bias',['tail-at-L','shifted-tail','layer-cake-gap','L-definition','R-definition'],'tail-first-moment','A3.Ex106.m2','R≥0,L≥0; nonnegative Tonelli; integrate exp(−s/3) to3; resulting upper bound finite.')
edge('e-mean-square',['row-definition-law','R-definition'],'second-moment','A3.SS2.p12.m3','Sum r standard Gaussian coordinate variances; no fourth moment.')
edge('e-a',['standing-parameters','second-moment','R-definition'],'a-definition','A3.Ex108.m1','r≥1; the truncated nonnegative R is dominated by integrable R; equal marginal laws make a common scalar.')
edge('e-scalar-bias',['a-definition','second-moment','tail-first-moment','standing-parameters'],'scalar-bias','A3.Ex109.m1','Split indicators {R≤L} and {R>L}; divide by positive r. 0≤a≤1 by domination.')
edge('e-symmetry',['a-definition','row-definition-law','second-moment'],'radial-covariance-consumer','A3.Ex108.m1','Separate isotropic Gaussian symmetry and radial indicator; finite second moments justify entries; trace fixes coefficient. Does not feed moment/tail.')
edge('e-Y',['t-and-B-context','R-definition','L-definition','row-independence-context'],'Y-definition-consumer','A3.Ex107.m1','Per-row measurable truncation preserves across-row independence. This downstream branch alone uses it.')
edge('e-C5-context',['Y-definition-consumer','radial-covariance-consumer','C5-full-boundary'],'C5-use-consumer','A3.Ex110.m1','Conditional C.5 identities are source-used here; full C.5 proof remains explicitly outside selected closure.',kind='CONSUMER_CONTEXT')
edge('e-final-probability-use',['T-probability','scalar-bias','C5-use-consumer','matrix-concentration-boundary'],'probability-bias-consumer','A3.SS2.p17','Conditional on separately supplied matrix estimates: union failure0.001+0.004; agreement on T; unweighted bias1−a and weighted zero expectation. Matrix branch is excluded, so no full theorem is certified.',kind='CONSUMER_CONTEXT')
groups={
'S4.SS1.p1':('NODE','hard-family-context','Context definition, with bibliography use separately tracked; not a scalar dependency.'),
'S4.SS1.p2':('EXCLUDED',None,'Known spectrum and normalizer discussion, outside selected scalar spine.'),
'S4.Thmtheorem2':('EXCLUDED',None,'κ=2 comparison, oracle equivalence and testing heuristic; no scalar moment/tail dependency.'),
'S4.SS2.SSS0.Px1.p1':('NODE','construction-citation-22','Deferred-rotation citation provenance only; output representation proof is excluded.'),
'S4.SS2.SSS0.Px1.p2':('NODE','krylov-context','Krylov definition is downstream context, not a scalar moment premise.'),
'S4.Thmtheorem3.p1':('NODE','starter-law','Mixed statement paragraph: standing q/range/starter law retained; output representation clause remains excluded full-theorem context.'),
'S4.SS2.SSS0.Px1.p3':('EXCLUDED',None,'Additional output starter explanation, adaptive polynomial coefficients, representation equivalence and proof deferral; scalar law is restated directly in Lemma4.4.'),
'S4.SS2.SSS0.Px2.p1':('NODE','krylov-context','Frequency/diagonal-statistic definition and intended consumer context only.'),
'S4.Thmtheorem4.p1':('NODE','standing-parameters','Mixed statement paragraph: q/range/starter-law setup retained; full τ and simultaneous uniform conclusion excluded separately.'),
'S4.SS2.SSS0.Px2.p2':('EXCLUDED',None,'Proof deferral and κ-independent change-of-basis discussion; full uniform bound is outside scalar closure.'),
'S4.SS2.SSS0.Px2.p3':('EXCLUDED',None,'Uniform-bound application to algorithm output; outside selected scalar closure.'),
'A3.SS2.p1':('NODE','row-definition-law','Literal r/n, t, gamma, independent row law and B scaling; cross-row independence and B context are separate graph nodes.'),
'A3.SS2.p2':('EXCLUDED',None,'Whole-matrix proof strategy; downstream uniform theorem, not scalar proof ingredient.'),
'A3.Thmtheorem5.p1':('EXCLUDED',None,'Full C.5 result is a separate excluded matrix/cosine obligation.'),
'A3.SS2.p3':('EXCLUDED',None,'C.5 range proof, Chebyshev polynomials and triangular invertibility; no scalar role.'),
'A3.SS2.p4':('EXCLUDED',None,'C.5 telescoping cosine sum and sine nonvanishing; no scalar role.'),
'A3.SS2.p5':('EXCLUDED',None,'C.5 entrywise cosine orthogonality and frequency ranges; no scalar role.'),
'A3.SS2.p6':('EXCLUDED',None,'C.5 matrix expectation computation; no scalar exponential-moment dependency.'),
'A3.SS2.p7':('EXCLUDED',None,'C.5 triple product-to-sum and weighted expectation computation; no scalar dependency.'),
'A3.SS2.p8':('EXCLUDED',None,'C.5 deterministic norm bound for t; only downstream matrix summands use it.'),
'A3.SS2.p9':('EXCLUDED',None,'Strategy transition to simultaneous matrix concentration; no scalar proof ingredient.'),
'A3.Thmtheorem6.p1':('EXCLUDED',None,'Full C.6 concentration conclusion; selected scalar statements are only ingredients.'),
'A3.SS2.p10':('NODE','single-row-tail','Literal L/R, moment, Markov reuse, numerical comparison, T and its union-bound probability; separately expanded graph nodes.'),
'A3.SS2.p11':('NODE','tail-first-moment','Shifted strict tail and layer-cake expectation bound; background bridge explicit.'),
'A3.SS2.p12':('NODE','scalar-bias','Scalar a and bias plus explicitly separate radial-symmetry/truncated-matrix/C.5 consumer branch.'),
'A3.SS2.p13':('EXCLUDED',None,'Centered matrix/summand operator bounds, including deterministic cosine weights; separate matrix branch.'),
'A3.SS2.p14':('EXCLUDED',None,'Gaussian fourth moments, sign symmetry, squared rank-one matrices and matrix variance calculation; not needed by selected scalar moment/tail/bias.'),
'A3.SS2.p15':('EXCLUDED',None,'Named two-sided bounded matrix Bernstein and its prerequisites; separate matrix concentration branch, no scalar parent.'),
'A3.SS2.p16':('EXCLUDED',None,'Matrix threshold Δ, z, algebraic expansion, two0.002 failures and joint0.996 probability; downstream budget recorded as excluded boundary.'),
'A3.SS2.p17':('NODE','probability-bias-consumer','Exact downstream use of T and scalar bias: agreement, expectation identities, union0.001+0.004 and0.995; not proof closure of excluded matrix branch.'),
'A3.SS2.p18':('EXCLUDED',None,'Asymptotic/log constant absorption into τ and full C.6 closure; parameters2r≤d and d≥2 separately retained as standing arithmetic.'),
'A3.SS2.p19':('EXCLUDED',None,'Full Lemma4.4 proof, C.5 representation, τ≤1/2 norm comparison, simultaneous quantifier and0.995≥0.99; outside scalar closure.')}
wrappers={'S4.Thmtheorem3':'Full output representation theorem is excluded; only nested standing law fields retained.','S4.Thmtheorem4':'Full uniform Lemma4.4 is excluded; nested standing setup retained.','A3.Thmtheorem5':'Full FactC.5 and its proof are excluded.','A3.SS2.2':'C.5 proof wrapper; all inner substantive regions explicitly excluded.','A3.Thmtheorem6':'Full FactC.6 is excluded; scalar subproof and probability consumer are separately retained.','A3.SS2.3':'C.6 proof wrapper; mixed scope is resolved by paragraph and formula inventory rather than claiming full theorem coverage.','A3.SS2.4':'Full Lemma4.4 proof wrapper is excluded.'}
coverage=[]
for x in inv['items']:
    z=dict(x);sid=x['source_id']
    candidates=[(g,items[g]['anchor']['char_end']-items[g]['anchor']['char_start']) for g in groups if g in items and items[g]['anchor']['char_start']<=x['anchor']['char_start'] and x['anchor']['char_end']<=items[g]['anchor']['char_end']]
    if sid in wrappers:disp,n,why='EXCLUDED',None,wrappers[sid]
    elif x['tag'].startswith('h'):disp,n,why='EXCLUDED',None,'Navigation/section heading; all substantive child regions independently inventoried.'
    elif candidates:
        g=min(candidates,key=lambda t:t[1])[0];disp,n,why=groups[g];z['logical_region']=g
    else:disp,n,why='EXCLUDED',None,'Non-substantive wrapper or cross-reference outside a selected logical paragraph; no mathematical proof content omitted.'
    if x['tag']=='math' and sid.startswith('S4.Thmtheorem3') and sid not in ['S4.Thmtheorem3.p1.m1','S4.Thmtheorem3.p1.m2','S4.Thmtheorem3.p1.m4']:
        disp,n,why='EXCLUDED',None,'Output object/representation clause; full Lemma4.3 is outside selected scalar law.'
    if x['tag']=='math' and sid.startswith('S4.Thmtheorem4') and sid not in ['S4.Thmtheorem4.p1.m2','S4.Thmtheorem4.p1.m3','S4.Thmtheorem4.p1.m4','S4.Thmtheorem4.p1.m5']:
        disp,n,why='EXCLUDED',None,'Full uniform-theorem C/τ/K_q/probability clause; only standing scalar law fields retained.'
    if sid.startswith('S4.Ex') and z.get('logical_region') in ['S4.Thmtheorem3.p1','S4.Thmtheorem4.p1']:
        disp,n,why='EXCLUDED',None,'Displayed representation/τ/uniform conclusion belongs to excluded full theorem.'
    if 'ltx_cite' in x['classes'] or (x.get('href') and x['href'].startswith('#bib')):
        disp,n,why='NODE','construction-citation-22','Exact cited source provenance retained; no scalar implication inferred from the citation.'
    z.update({'disposition':disp,'graph_node':n,'reason':why});coverage.append(z)
coverage.append({'source_id':'bib.bib3','tag':'bibliography-entry','classes':['ltx_bibitem'],'href':None,'anchor':ex['bib.bib3']['anchor'],'text':ex['bib.bib3']['textext'],'disposition':'NODE','graph_node':'construction-citation-22','reason':'The single explicitly expanded bibliography entry reused by the declared Section4 source slice; context provenance only.','logical_region':'outside-slice citation expansion'})
graph={'artifact_role':'Independent source-only proof-graph reconstruction, frozen before any target types','source':{k:inv[k] for k in ['source_sha256','source_bytes','source_characters','offset_conventions','scope_roots']},'status':'DRAFT_SOURCE_RECONSTRUCTION_FROZEN_FOR_PHASE2; no independent approval; no source theorem proved','nodes':nodes,'edges':edges,'OR_routes':[{'conclusion':'moment-one-third','alternatives':['moment-route-A-density','moment-route-B-product'],'semantics':'Each listed hyperedge is independently sufficient as an unformalized background route; routes A and B are OR, never a flattened AND. Source only asserts the identity and does not choose either expanded route.'}],'selected_scalar_nodes':['moment-one-third','single-row-tail','tail-at-L','T-probability','shifted-tail','tail-first-moment','scalar-bias'],'prohibited_scalar_parents':['C5-full-boundary','C6-full-boundary','L44-full-boundary','row-independence-context','radial-covariance-consumer','matrix-concentration-boundary','hard-family-context','krylov-context','Y-definition-consumer','C5-use-consumer','probability-bias-consumer'],'coverage_file':'coverage.json','mathematics_file':'mathematics.md'}
(BASE/'source-graph.json').write_text(json.dumps(graph,indent=2,ensure_ascii=False)+'\n')
summary={'scope':inv['scope_roots'],'inventory_items':len(coverage),'NODE':sum(x['disposition']=='NODE' for x in coverage),'EXCLUDED':sum(x['disposition']=='EXCLUDED' for x in coverage),'classification_rule':'Each inventoried paragraph/formula/equation wrapper/theorem/proof wrapper/citation/reference/heading gets exactly one disposition. Nested rows are lossless textual coverage, not proof-edge multiplicity. Mixed paragraphs have explicit component scope; full conclusions remain excluded.','source_gaps':[x['id'] for x in nodes if x['kind']=='SOURCE_GAP'],'independent_coverage_approval':'not performed by this author; remains separate','formalization_credit':'none','items':coverage}
(BASE/'coverage.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n')
out={'nodes':len(nodes),'edges':len(edges),'coverage_items':len(coverage),'NODE':summary['NODE'],'EXCLUDED':summary['EXCLUDED'],'source_gaps':summary['source_gaps'],'status':'source reconstruction only; no self-approval'}
receipt={'argv':sys.argv,'time_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':0,'stdout':json.dumps(out,indent=2)+'\n','stderr':'','reads':['source-inventory-raw.json','anchored-excerpts.json'],'writes':['source-graph.json','coverage.json']}
(BASE/'execution'/'build-phase1-execution.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(receipt['stdout'],end='')
