"""Normal intake after independently accepted statement and topology. No proof or verification transition."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys

if sys.flags.optimize != 0 or os.environ.get('PYTHONOPTIMIZE') != '0':
    raise RuntimeError('Explicit PYTHONOPTIMIZE=0 and active assertions are required')
sys.dont_write_bytecode = True
sys.path.insert(0, 'tools')
import astis_advance as adv

W = Path(__file__).parent
E = Path('research-wiki/paper-contributions/GaussianComplexity/radial-exponential-semantic-evidence')
C = Path('research-wiki/frontier-cells/ASTIS-SHARED-std-gaussian-radial-exponential.json')
L = Path('runs/substantive_advances.jsonl')
ADV = 'ASTIS-SA-20261110-StdGaussianRadialExponential'
OWNER = 'huanjian_gc_20261110_std_gaussian_radial_exponential'
sha = lambda b: hashlib.sha256(b).hexdigest()
dump = lambda x: (json.dumps(x, ensure_ascii=False, indent=2) + '\n').encode()
def put(path, data):
    assert not path.exists(), path
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)
def ref(path):
    path = Path(path)
    data = path.read_bytes()
    return {'path':str(path),'bytes':len(data),'sha256':sha(data)}
def controls():
    import stat
    regular=lambda p:p.exists() and stat.S_ISREG(p.lstat().st_mode)
    names={str(p) for p in Path('research-wiki/frontier-cells').rglob('*') if regular(p)}
    names|={str(p) for p in Path('runs').iterdir() if regular(p)}
    names.add('website/content/samplewiki_companion_frontiers.json')
    for p in Path('.astis').iterdir():
        if regular(p) and any(t in p.name.lower() for t in ['queue','control','global','goal','steer','execution']):names.add(str(p))
    for n in ['control','queues','runtime','harness','state','locks']:
        d=Path('.astis')/n
        if d.is_dir() and not d.is_symlink():names|={str(p) for p in d.rglob('*') if regular(p)}
    known=json.loads(Path('.astis/huanjian-gc-fixed-spectrum-krylov-range-20261110/intake-baseline.private.json').read_bytes())
    names|=set(known['foreign_control_hashes'])
    # ONLY the known portable original phase5. Never enumerate its parent/private sibling.
    root=Path('.astis/semantic-neutral-20261111/kr_src_c47e12/phase5-normal-sourceV')
    m=json.loads((root/'hash-manifest.json').read_bytes())
    assert m['full_private_foreign_baselines_included'] is False
    for item in m['files']:
        rel=item['path']
        assert not Path(rel).is_absolute() and '..' not in Path(rel).parts
        names.add(str(root/rel))
    names.add(str(root/'hash-manifest.json'))
    own_roots=['research-wiki/paper-contributions/GaussianComplexity/radial-exponential-semantic-evidence/']
    own_exact={
        'research-wiki/paper-contributions/GaussianComplexity/radial-exponential-statement-seal.json',
        'AutoSamplingTheory/TechnicalLemmas/Probability/StdGaussianRadialExponential.lean',
        'Tests/GaussianComplexityRadialExponential.lean',
        'website/content/declaration_lessons/huanjian-std-gaussian-radial-exponential.json',
        'website/content/publications/huanjian-std-gaussian-radial-exponential.json',
        'research-wiki/semantic-roundtrip/audits/huanjian-std-gaussian-radial-exponential.json'}
    for raw in subprocess.check_output(['git','ls-files','--others','--exclude-standard','-z']).split(b'\0'):
        if raw:
            n=raw.decode()
            if n not in own_exact and not any(n.startswith(p) for p in own_roots) and regular(Path(n)):names.add(n)
    return sorted(n for n in names if regular(Path(n)))

assert len(sys.argv) == 4, 'admission record, exact record SHA256, private baseline SHA256'
admission_path = Path(sys.argv[1])
assert sha(admission_path.read_bytes()) == sys.argv[2]
admission = json.loads(admission_path.read_bytes())
assert admission['kind'] == 'EXACT_INDEPENDENT_TOPOLOGY_EVIDENCE_FOR_NORMAL_INTAKE'
assert admission['topology_review_status'] == 'accepted_with_overlay'
assert admission['root_sole_mathematical_worker'] is True
assert admission['prepared_intake_script_sha256'] == sha(Path(__file__).read_bytes())
assert admission['private_baseline_sha256'] == sys.argv[3]
for row in admission['independent_inputs']:
    assert sha(Path(row['path']).read_bytes()) == row['sha256'], row['path']
baselinepath = W / 'intake-baseline.private.json'
assert sha(baselinepath.read_bytes()) == sys.argv[3]
b = json.loads(baselinepath.read_bytes())
prepath = Path(b['preproof_snapshot']['path'])
assert sha(prepath.read_bytes()) == b['preproof_snapshot']['sha256']
pre = json.loads(prepath.read_bytes())
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip() == pre['head']
sp = W / 'statement-seal-v1.json'
assert sha(sp.read_bytes()) == '0cd51a158ffacbf0c4cd7677d78cb61c5be7d8a428fbf5dd01581ff99545f3fb'
s = json.loads(sp.read_bytes())
prod = s['producer']['planned_file']
test = s['actual_private_consumer']['planned_file']
name = s['producer']['name']
assert not Path(prod).exists() and not Path(test).exists()
assert not (W/'StatementFormation.lean').exists()
publicseal = Path('research-wiki/paper-contributions/GaussianComplexity/radial-exponential-statement-seal.json')
assert publicseal.read_bytes() == sp.read_bytes()
assert sha(C.read_bytes()) == b['own_frontier']['sha256']
assert set(b['control_paths']) <= set(controls())
for path, h in b['foreign_control_hashes'].items():
    assert sha(Path(path).read_bytes()) == h, path
before = L.read_bytes()
assert sha(before) == pre['ledger_sha256'] and len(before) == pre['ledger_bytes']
states = adv._replay_advances([json.loads(z) for z in before.splitlines()])
assert states == pre['all_foreign_states'] and ADV not in states
assert states['ASTIS-SA-20261110-GaussianComplexityFixedSpectrumTargetLaw']['state'] == 'VERIFIED'
assert states['ASTIS-SA-20261110-GaussianComplexityZeroQuerySeparation']['state'] == 'VERIFIED'
assert states['ASTIS-SA-20261110-GaussianComplexityFixedSpectrumCosineGram']['state'] == 'VERIFIED'
assert states['ASTIS-SA-20261110-GaussianComplexityFixedSpectrumKrylovRange']['state'] == 'VERIFIED'
tracked = [p.decode() for p in subprocess.check_output(['git','ls-files','-z']).split(b'\0') if p]
assert set(tracked) == set(pre['all_tracked_regular_file_hashes'])
for path, h in pre['all_tracked_regular_file_hashes'].items():
    assert sha(Path(path).read_bytes()) == h, path
for path, h in pre['all_existing_frontier_hashes'].items():
    assert sha(Path(path).read_bytes()) == h, path
assert json.loads(C.read_bytes())['owner_id'] == OWNER
put(E/'preproof-source-admission.json', admission_path.read_bytes())
put(W/'intake-tracked-private-preservation.json', dump({
    'all_tracked_hashes_except_own_ledger_and_frontier':{
        p:h for p,h in pre['all_tracked_regular_file_hashes'].items() if p not in {str(L),str(C)}},
    'all_foreign_states':states, 'raw_private_not_for_public_copy':True}))
cell = json.loads(C.read_bytes())
boundary = cell['truth_boundary']
proposal = adv.AdvanceProposal(
    advance_id=ADV, task_id='ASTIS-SW-GAUSSIAN-COMPLEXITY-2026',
    goal='Prove actual standard-Gaussian quadratic exponential integrability and moment, materially consumed by the literal source row truncation tail.',
    source_anchor=cell['source_anchor'], theorem_delta=s['producer']['signature'],
    truth_boundary=boundary, created_by=OWNER,
    dag_inputs=('source:arXiv2610.20492v1 A3.SS2.p10.m3; A3.Ex104; A3.SS2.p10.m1 literal L',
        'Exact canonical stdGaussian/Integrable/integral/real-rpow/finrank/Euclidean definitions. Generic finite real Hilbert and dimension0 extension explicitly reviewed; proof-API retrieval only after accepted independent source topology and actual normal intake readback.'),
    proposed_files=(prod,test,str(C),str(publicseal),
        'website/content/declaration_lessons/huanjian-std-gaussian-radial-exponential.json',
        'website/content/publications/huanjian-std-gaussian-radial-exponential.json',
        'research-wiki/semantic-roundtrip/audits/huanjian-std-gaussian-radial-exponential.json'),
    focused_checks=('lake env lean '+prod,'lake build Tests.GaussianComplexityRadialExponential'),
    modes=('source-reading','proof-design','compiler-diagnosis'),priority=50,
    frontier_cell=C.stem,target_declarations=(name,))
proposal.validate()
fd = os.open(W/'normal-intake-attempted.once.json', os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
with os.fdopen(fd,'wb') as f:
    f.write(dump({'advance':ADV,'permanent_no_replay_marker':True,'proof_API_not_allowed_until_all3_events_and_postguards_pass':True}))
try:
    adv.propose_advance(proposal)
    adv.transition_advance(ADV,'CLAIMED',worker_id=OWNER,evidence={
        'exact_statement_seal':ref(sp),'preproof_admission':ref(E/'preproof-source-admission.json'),'truth_boundary':boundary})
    adv.transition_advance(ADV,'EXPLORING',worker_id=OWNER,evidence={
        'preproof_admission':ref(E/'preproof-source-admission.json'),
        'target_proof_API_search_starts_only_after_all_postguards':True,
        'preseal_planning_and_old_related_implementation_exposure_retained':True,
        'no_pristine_history_or_self_sourceV_claim':True,'no_own_STAB_authority':True,'truth_boundary':boundary})
except BaseException:
    observed = L.read_bytes()
    put(W/'normal-intake-failed-observed-ledger.PRIVATE.raw.jsonl', observed)
    put(W/'normal-intake-failed-no-replay.json',dump({'ledger_starts_with_original_prefix':observed.startswith(before),'normal_intake_attempted_once':True,'proof_API_authority':False,'next':'Readonly determine exact completed events and legal remaining recovery; never re-propose/reset/rewrite history.'}))
    raise
after = L.read_bytes()
assert after.startswith(before)
app = after[len(before):]
assert len(app.splitlines()) == 3
rows = [json.loads(z) for z in app.splitlines()]
assert all(z['advance_id']==ADV for z in rows)
new = adv._replay_advances([json.loads(z) for z in after.splitlines()])
assert new[ADV]['state']=='EXPLORING' and new[ADV]['owner_id']==OWNER
assert {k:v for k,v in new.items() if k!=ADV} == states
for path, h in pre['all_tracked_regular_file_hashes'].items():
    if path not in {str(L),str(C)}:
        assert sha(Path(path).read_bytes()) == h, path
for path, h in pre['all_existing_frontier_hashes'].items():
    assert sha(Path(path).read_bytes()) == h, path
assert set(b['control_paths']) <= set(controls())
for path, h in b['foreign_control_hashes'].items():
    assert sha(Path(path).read_bytes()) == h, path
assert sha(C.read_bytes())==b['own_frontier']['sha256']
cell['evidence']['preproof_source_admission'] = ref(E/'preproof-source-admission.json')
cell['evidence']['execution_boundary'] = 'Normal intake completed: PROPOSED, CLAIMED, EXPLORING, followed by preservation checks. Target remains unproved. '+boundary
cell['reservation_only'] = 'Normal ledger intake completed. Frontier claimed status records the current exploration owner.'
cell['statement_seal']['status'] = 'EXACT_LITERAL_PROP_FORMED_UNPROVED;INDEPENDENT_TOPOLOGY_ACCEPTED_WITH_OVERLAY'
cell['truth_boundary'] = boundary
C.write_bytes(dump(cell))
assert json.loads(C.read_bytes())['owner_id']==OWNER
put(E/'normal-EXPLORING-append.exact.jsonl',app)
put(E/'normal-intake-preservation.json',dump({'actual_normal_API_calls':3,'state':'EXPLORING',
    'advance_id':ADV,'owner':OWNER,'append_sha256':sha(app),'foreign_states_preserved':len(states),
    'foreign_frontiers_preserved':len(pre['all_existing_frontier_hashes']),
    'protected_tracked_files_preserved':len(pre['all_tracked_regular_file_hashes'])-1,
    'foreign_raw_private':True,'no_proof_or_sourceV_STAB_or_global_credit':True}))
print(json.dumps({'state':'EXPLORING','actual_normal_API_calls':3,'append_sha256':sha(app),
    'foreign_states_preserved':len(states),'foreign_frontiers_preserved':len(pre['all_existing_frontier_hashes']),
    'proof_or_sourceV_credit':False}))
