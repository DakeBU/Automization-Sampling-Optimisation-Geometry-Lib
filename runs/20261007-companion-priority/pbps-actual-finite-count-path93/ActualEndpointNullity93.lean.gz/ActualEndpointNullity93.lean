import AutoSamplingTheory.ExampleCases.ProximalBPS.ActualOrderedPrefix
import AutoSamplingTheory.ExampleCases.ProximalBPS.ActualPhysicalTimeMeasurability
import Mathlib.MeasureTheory.Constructions.Pi

open InnerProductSpace MeasureTheory ProbabilityTheory Filter
open scoped NNReal ENNReal

namespace EndpointInterfaces93

private theorem subtype_coordinate_null (n : ℕ) (D : Set (Fin n → ℝ))
    (i : Fin n) (t : ℝ) :
    (Measure.comap (fun x : D => x.val) (volume : Measure (Fin n → ℝ)))
      {x | x.val i = t} = 0 := by
  have hm : MeasurableSet {x : D | x.val i = t} :=
    measurableSet_eq_fun ((measurable_pi_apply i).comp measurable_subtype_coe) measurable_const
  apply le_antisymm _ zero_le
  calc
    _ ≤ (volume : Measure (Fin n → ℝ))
        ((fun x : D => x.val) '' {x | x.val i = t}) :=
      Measure.comap_apply_le _ _ hm.nullMeasurableSet
    _ ≤ (volume : Measure (Fin n → ℝ)) {x | x i = t} := by
      apply measure_mono
      rintro x ⟨y, hy, rfl⟩
      exact hy
    _ = 0 := Measure.pi_hyperplane (fun _ : Fin n => (volume : Measure ℝ)) i t

private theorem weighted_map_coordinate_null
    {Ω X : Type*} [MeasurableSpace Ω] [MeasurableSpace X]
    (P : Measure Ω) (B : Set Ω) (H : Ω → X)
    (n : ℕ) (D : Set (Fin n → ℝ)) (K : D → X) (q : D → ℝ≥0∞)
    (obs : X → ℝ) (i : Fin n) (t : ℝ)
    (hH : Measurable H) (hK : Measurable K) (hobs : Measurable obs)
    (hcoord : ∀ x, obs (K x) = x.val i)
    (hlaw : Measure.map H (P.restrict B) =
      Measure.map K ((Measure.comap (fun x : D => x.val) volume).withDensity q)) :
    P ({w | obs (H w) = t} ∩ B) = 0 := by
  have hs : MeasurableSet {x | obs x = t} := measurableSet_eq_fun hobs measurable_const
  have hnull := withDensity_absolutelyContinuous
    (Measure.comap (fun x : D => x.val) volume) q (subtype_coordinate_null n D i t)
  have heval := congrArg (fun μ : Measure X => μ {x | obs x = t}) hlaw
  rw [Measure.map_apply hH hs, Measure.map_apply hK hs,
    Measure.restrict_apply (hs.preimage hH)] at heval
  have heq : K ⁻¹' {x | obs x = t} = {x : D | x.val i = t} := by
    ext x
    simp only [Set.mem_preimage, Set.mem_ofPred_eq, hcoord]
  rw [heq, hnull] at heval
  exact heval

#print axioms weighted_map_coordinate_null

private theorem live_prefix_strict_guard {X : Type*}
    (r : ℕ → (ℝ≥0 × X) ⊕ Unit)
    (hmono : Monotone (fun k => (r k).elim
      (fun a => (a.1 : WithTop ℝ≥0)) (fun _ => ⊤)))
    (hstrict : ∀ k a b, r k = Sum.inl a → r (k+1) = Sum.inl b → a.1 < b.1)
    (n : ℕ) (T : ℝ≥0)
    (hend : (r n).elim (fun a => (a.1 : WithTop ℝ≥0)) (fun _ => ⊤) < T) :
    (∀ j : Fin (n+1), ∃ a, r j.val = Sum.inl a) ∧
      StrictMono (fun j : Fin (n+1) => (r j.val).elim (fun a => (a.1 : ℝ)) (fun _ => 0)) ∧
      (∀ j : Fin n, (r j.succ.val).elim (fun a => (a.1 : ℝ)) (fun _ => 0) < T) := by
  have hfinite (k : ℕ) (hk : k ≤ n) :
      (r k).elim (fun a => (a.1 : WithTop ℝ≥0)) (fun _ => ⊤) < T :=
    lt_of_le_of_lt (hmono hk) hend
  have hlive (j : Fin (n+1)) : ∃ a, r j.val = Sum.inl a := by
    have hh := hfinite j.val (Nat.le_of_lt_succ j.isLt)
    cases hr : r j.val with
    | inl a => exact ⟨a, rfl⟩
    | inr u => simp only [hr, Sum.elim_inr, not_top_lt] at hh
  refine ⟨hlive, ?_, ?_⟩
  · apply Fin.strictMono_iff_lt_succ.mpr
    intro j
    obtain ⟨a, ha⟩ := hlive j.castSucc
    obtain ⟨b, hb⟩ := hlive j.succ
    simp only [ha, hb, Sum.elim_inl]
    exact NNReal.coe_lt_coe.mpr (hstrict j.val a b ha hb)
  · intro j
    obtain ⟨a, ha⟩ := hlive j.succ
    have hh := hfinite j.succ.val (Nat.le_of_lt_succ j.succ.isLt)
    rw [ha] at hh ⊢
    exact NNReal.coe_lt_coe.mpr (WithTop.coe_lt_coe.mp hh)

#print axioms live_prefix_strict_guard

open scoped ContDiff Topology Interval BigOperators
noncomputable section
set_option maxHeartbeats 1000000 in
private theorem actual_fixed_horizon_endpoint_nullity
    {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℝ E]
    [FiniteDimensional ℝ E] [MeasurableSpace E] [BorelSpace E]
    {V : E → ℝ} {α β : ℝ≥0} {η : ℝ}
    (hα : 0 < (α : ℝ)) (hαβ : α ≤ β) (hV : ContDiff ℝ 2 V)
    (hH : ∀ x v : E,
      (α : ℝ) * ‖v‖ ^ 2 ≤ (fderiv ℝ (fderiv ℝ V) x v) v ∧
      (fderiv ℝ (fderiv ℝ V) x v) v ≤ (β : ℝ) * ‖v‖ ^ 2)
    (hη : 0 < η) (hβη : (β : ℝ) * η ≤ 1) :
    let c : E → E → E := fun y xRef => y - η • gradient V xRef
    let Φ : E → E → ℝ → (E × E) → (E × E) := fun y xRef t z =>
      (c y xRef + Real.cos t • (z.1 - c y xRef) +
          (Real.sqrt η * Real.sin t) • z.2,
       (-Real.sin t / Real.sqrt η) • (z.1 - c y xRef) + Real.cos t • z.2)
    let S : E → (E × E) → (E × E) := fun xRef z =>
      (z.1, z.2 - (2 * inner ℝ z.2 (gradient V z.1 - gradient V xRef) /
        ‖gradient V z.1 - gradient V xRef‖ ^ 2) • (gradient V z.1 - gradient V xRef))
    let rate : E → (E × E) → ℝ := fun xRef z =>
      Real.sqrt η * max 0 (inner ℝ z.2 (gradient V z.1 - gradient V xRef))
    let Λ : E → E → (E × E) → ℝ≥0 → ℝ := fun y xRef z t =>
      ∫ s in (0 : ℝ)..(t : ℝ), rate xRef (Φ y xRef s z)
    let τ : E → E → (E × E) → ℝ≥0 → WithTop ℝ≥0 := fun y xRef z e =>
      MeasureTheory.hittingAfter
        (fun t : ℝ≥0 => fun a : (E × E) × (E × E) × ℝ≥0 =>
          Λ a.1.1 a.1.2 a.2.1 t - (a.2.2 : ℝ))
        (Set.Ici (0 : ℝ)) 0 ((y, xRef), z, e)
    let next : E → E → ℝ≥0 → ((ℝ≥0 × (E × E)) ⊕ Unit) →
        ((ℝ≥0 × (E × E)) ⊕ Unit) := fun y xRef e r =>
      match r with
      | Sum.inr _ => Sum.inr ()
      | Sum.inl a =>
        if τ y xRef a.2 e = ⊤ then Sum.inr () else
          Sum.inl (a.1 + (τ y xRef a.2 e).untopD 0,
            S xRef (Φ y xRef (((τ y xRef a.2 e).untopD 0 : ℝ≥0) : ℝ) a.2))
    let record : E → E → (E × E) → (ℕ → ℝ≥0) → ℕ →
        ((ℝ≥0 × (E × E)) ⊕ Unit) := fun y xRef z₀ e n =>
      Nat.rec (Sum.inl (0, z₀)) (fun k r => next y xRef (e k) r) n
    let P : Measure (ℕ → ℝ) := Measure.infinitePi (fun _ : ℕ => expMeasure (1 : ℝ))
    let ε : (ℕ → ℝ) → ℕ → ℝ≥0 := fun w k => Real.toNNReal (w k)
    let history : E → E → (E × E) → (n : ℕ) → (ℕ → ℝ) →
        (Fin (n + 1) → ((ℝ≥0 × (E × E)) ⊕ Unit)) :=
      fun y xRef z₀ n w j => record y xRef z₀ (ε w) j.val
    let Rec := (ℝ≥0 × (E × E)) ⊕ Unit
    let Hist : ℕ → Type _ := fun n => Fin (n + 1) → Rec
    let readTime : Rec → ℝ := fun r => match r with
      | Sum.inl q => (q.1 : ℝ)
      | Sum.inr _ => 0
    let Δ : (n : ℕ) → ℝ≥0 → Set (Fin n → ℝ) := fun n T =>
      {t | StrictMono (Fin.cons (0 : ℝ) t) ∧ ∀ i, t i < (T : ℝ)}
    let Prefix : (n : ℕ) → ℝ≥0 → Type := fun n T => {t : Fin n → ℝ // t ∈ Δ n T}
    let m : (n : ℕ) → (T : ℝ≥0) → Measure (Prefix n T) := fun n T =>
      Measure.comap (fun t : Prefix n T => t.val) (volume : Measure (Fin n → ℝ))
    let zAt : E → E → (E × E) → (n : ℕ) → (T : ℝ≥0) →
        Prefix n T → Fin (n + 1) → (E × E) := fun y xRef z₀ n T t =>
      Fin.induction z₀ (fun i z =>
        S xRef (Φ y xRef (t.val i - (Fin.cons (0 : ℝ) (t.val : Fin n → ℝ) : Fin (n + 1) → ℝ) i.castSucc) z))
    let K : E → E → (E × E) → (n : ℕ) → (T : ℝ≥0) →
        Prefix n T → Hist n := fun y xRef z₀ n T t j =>
      Sum.inl (Real.toNNReal ((Fin.cons (0 : ℝ) (t.val : Fin n → ℝ) : Fin (n + 1) → ℝ) j), zAt y xRef z₀ n T t j)
    let qReal : E → E → (E × E) → (n : ℕ) → (T : ℝ≥0) →
        Prefix n T → ℝ := fun y xRef z₀ n T t =>
      ∏ i : Fin n,
        rate xRef (Φ y xRef (t.val i - (Fin.cons (0 : ℝ) (t.val : Fin n → ℝ) : Fin (n + 1) → ℝ) i.castSucc)
          (zAt y xRef z₀ n T t i.castSucc)) *
        Real.exp (-Λ y xRef (zAt y xRef z₀ n T t i.castSucc)
          (Real.toNNReal (t.val i - (Fin.cons (0 : ℝ) (t.val : Fin n → ℝ) : Fin (n + 1) → ℝ) i.castSucc)))
    let q : E → E → (E × E) → (n : ℕ) → (T : ℝ≥0) →
        Prefix n T → ℝ≥0∞ := fun y xRef z₀ n T t =>
      ENNReal.ofReal (qReal y xRef z₀ n T t)
    let A : (n : ℕ) → ℝ≥0 → Set (Hist n) := fun n T =>
      {h | (∀ j, ∃ a : ℝ≥0 × (E × E), h j = Sum.inl a) ∧
        StrictMono (fun j => readTime (h j)) ∧
        ∀ i : Fin n, readTime (h i.succ) < (T : ℝ)}
    let eventTime : E → E → (E × E) → (ℕ → ℝ) → ℕ → WithTop ℝ≥0 :=
      fun y xRef z₀ w j => (record y xRef z₀ (ε w) j).elim
        (fun a => (a.1 : WithTop ℝ≥0)) (fun _ => ⊤)
    ∀ y xRef : E, ∀ z₀ : E × E, ∀ T : ℝ≥0,
      ∀ᵐ w ∂P, ∀ j : ℕ, 0 < j → eventTime y xRef z₀ w j ≠ (T : WithTop ℝ≥0) := by
  classical
  let c : E → E → E := fun y xRef => y - η • gradient V xRef
  let Φ : E → E → ℝ → (E × E) → (E × E) := fun y xRef t z =>
    (c y xRef + Real.cos t • (z.1 - c y xRef) +
        (Real.sqrt η * Real.sin t) • z.2,
     (-Real.sin t / Real.sqrt η) • (z.1 - c y xRef) + Real.cos t • z.2)
  let S : E → (E × E) → (E × E) := fun xRef z =>
    (z.1, z.2 - (2 * inner ℝ z.2 (gradient V z.1 - gradient V xRef) /
      ‖gradient V z.1 - gradient V xRef‖ ^ 2) • (gradient V z.1 - gradient V xRef))
  let rate : E → (E × E) → ℝ := fun xRef z =>
    Real.sqrt η * max 0 (inner ℝ z.2 (gradient V z.1 - gradient V xRef))
  let Λ : E → E → (E × E) → ℝ≥0 → ℝ := fun y xRef z t =>
    ∫ s in (0 : ℝ)..(t : ℝ), rate xRef (Φ y xRef s z)
  let τ : E → E → (E × E) → ℝ≥0 → WithTop ℝ≥0 := fun y xRef z e =>
    MeasureTheory.hittingAfter
      (fun t : ℝ≥0 => fun a : (E × E) × (E × E) × ℝ≥0 =>
        Λ a.1.1 a.1.2 a.2.1 t - (a.2.2 : ℝ))
      (Set.Ici (0 : ℝ)) 0 ((y, xRef), z, e)
  let next : E → E → ℝ≥0 → ((ℝ≥0 × (E × E)) ⊕ Unit) →
      ((ℝ≥0 × (E × E)) ⊕ Unit) := fun y xRef e r =>
    match r with
    | Sum.inr _ => Sum.inr ()
    | Sum.inl a =>
      if τ y xRef a.2 e = ⊤ then Sum.inr () else
        Sum.inl (a.1 + (τ y xRef a.2 e).untopD 0,
          S xRef (Φ y xRef (((τ y xRef a.2 e).untopD 0 : ℝ≥0) : ℝ) a.2))
  let record : E → E → (E × E) → (ℕ → ℝ≥0) → ℕ →
      ((ℝ≥0 × (E × E)) ⊕ Unit) := fun y xRef z₀ e n =>
    Nat.rec (Sum.inl (0, z₀)) (fun k r => next y xRef (e k) r) n
  let P : Measure (ℕ → ℝ) := Measure.infinitePi (fun _ : ℕ => expMeasure (1 : ℝ))
  let ε : (ℕ → ℝ) → ℕ → ℝ≥0 := fun w k => Real.toNNReal (w k)
  let history : E → E → (E × E) → (n : ℕ) → (ℕ → ℝ) →
      (Fin (n + 1) → ((ℝ≥0 × (E × E)) ⊕ Unit)) :=
    fun y xRef z₀ n w j => record y xRef z₀ (ε w) j.val
  let Rec := (ℝ≥0 × (E × E)) ⊕ Unit
  let Hist : ℕ → Type _ := fun n => Fin (n + 1) → Rec
  let readTime : Rec → ℝ := fun r => match r with
    | Sum.inl q => (q.1 : ℝ)
    | Sum.inr _ => 0
  let Δ : (n : ℕ) → ℝ≥0 → Set (Fin n → ℝ) := fun n T =>
    {t | StrictMono (Fin.cons (0 : ℝ) t) ∧ ∀ i, t i < (T : ℝ)}
  let Prefix : (n : ℕ) → ℝ≥0 → Type := fun n T => {t : Fin n → ℝ // t ∈ Δ n T}
  let m : (n : ℕ) → (T : ℝ≥0) → Measure (Prefix n T) := fun n T =>
    Measure.comap (fun t : Prefix n T => t.val) (volume : Measure (Fin n → ℝ))
  let zAt : E → E → (E × E) → (n : ℕ) → (T : ℝ≥0) →
      Prefix n T → Fin (n + 1) → (E × E) := fun y xRef z₀ n T t =>
    Fin.induction z₀ (fun i z =>
      S xRef (Φ y xRef (t.val i - (Fin.cons (0 : ℝ) (t.val : Fin n → ℝ) : Fin (n + 1) → ℝ) i.castSucc) z))
  let K : E → E → (E × E) → (n : ℕ) → (T : ℝ≥0) →
      Prefix n T → Hist n := fun y xRef z₀ n T t j =>
    Sum.inl (Real.toNNReal ((Fin.cons (0 : ℝ) (t.val : Fin n → ℝ) : Fin (n + 1) → ℝ) j), zAt y xRef z₀ n T t j)
  let qReal : E → E → (E × E) → (n : ℕ) → (T : ℝ≥0) →
      Prefix n T → ℝ := fun y xRef z₀ n T t =>
    ∏ i : Fin n,
      rate xRef (Φ y xRef (t.val i - (Fin.cons (0 : ℝ) (t.val : Fin n → ℝ) : Fin (n + 1) → ℝ) i.castSucc)
        (zAt y xRef z₀ n T t i.castSucc)) *
      Real.exp (-Λ y xRef (zAt y xRef z₀ n T t i.castSucc)
        (Real.toNNReal (t.val i - (Fin.cons (0 : ℝ) (t.val : Fin n → ℝ) : Fin (n + 1) → ℝ) i.castSucc)))
  let q : E → E → (E × E) → (n : ℕ) → (T : ℝ≥0) →
      Prefix n T → ℝ≥0∞ := fun y xRef z₀ n T t =>
    ENNReal.ofReal (qReal y xRef z₀ n T t)
  let A : (n : ℕ) → ℝ≥0 → Set (Hist n) := fun n T =>
    {h | (∀ j, ∃ a : ℝ≥0 × (E × E), h j = Sum.inl a) ∧
      StrictMono (fun j => readTime (h j)) ∧
      ∀ i : Fin n, readTime (h i.succ) < (T : ℝ)}
  let eventTime : E → E → (E × E) → (ℕ → ℝ) → ℕ → WithTop ℝ≥0 :=
    fun y xRef z₀ w j => (record y xRef z₀ (ε w) j).elim
      (fun a => (a.1 : WithTop ℝ≥0)) (fun _ => ⊤)
  change
    ∀ y xRef : E, ∀ z₀ : E × E, ∀ T : ℝ≥0,
      ∀ᵐ w ∂P, ∀ j : ℕ, 0 < j → eventTime y xRef z₀ w j ≠ (T : WithTop ℝ≥0)
  intro y xRef z₀ T
  have h76 := AutoSamplingTheory.ExampleCases.ProximalBPS.ActualFiniteJumpRecursion.actual_fixed_reference_finite_jump_recursion
    hα hαβ hV hH hη hβη
  have hmono (w : ℕ → ℝ) : Monotone (eventTime y xRef z₀ w) :=
    (h76.2.2.2.2.2.1 y xRef z₀ (ε w)).2
  have hgood := AutoSamplingTheory.TechnicalLemmas.Probability.UnitExponentialProduct.unit_exponential_product_laws.2.2.2.1
  have hguard : ∀ᵐ w ∂P, ∀ n : ℕ,
      eventTime y xRef z₀ w n < ((T+1 : ℝ≥0) : WithTop ℝ≥0) →
        history y xRef z₀ n w ∈ A n (T+1) := by
    filter_upwards [hgood] with w hw
    intro n hn
    have hstrict (k : ℕ) (a b : ℝ≥0 × (E × E))
        (ha : record y xRef z₀ (ε w) k = Sum.inl a)
        (hb : record y xRef z₀ (ε w) (k+1) = Sum.inl b) : a.1 < b.1 :=
      (h76.2.2.2.2.2.2.2.2.2 y xRef z₀ (ε w) k a ha).2 b
        (Real.toNNReal_pos.mpr (hw k).1) hb
    have hh := live_prefix_strict_guard (record y xRef z₀ (ε w)) (hmono w) hstrict n (T+1) hn
    have heq (r : Rec) : readTime r = r.elim (fun a => (a.1 : ℝ)) (fun _ => 0) := by
      cases r <;> rfl
    exact ⟨hh.1, by simpa only [history, heq] using hh.2.1,
      by simpa only [history, heq] using hh.2.2⟩
  have hzero (n : ℕ) : P ({w | eventTime y xRef z₀ w (n+1) = (T : WithTop ℝ≥0)} ∩
      {w | history y xRef z₀ (n+1) w ∈ A (n+1) (T+1)}) = 0 := by
    have h92 := AutoSamplingTheory.ExampleCases.ProximalBPS.ActualOrderedPrefix.actual_ordered_prefix_law
      hα hαβ hV hH hη hβη (n+1) (T+1)
    have hh := h92.2.2.2.2 y xRef z₀
    let obs : Hist (n+1) → ℝ := fun h => readTime (h (Fin.last (n+1)))
    have hread : Measurable readTime := by
      apply Measurable.sumElim
      · exact measurable_coe_nnreal_real.comp measurable_fst
      · exact measurable_const
    have hobs : Measurable obs := hread.comp (measurable_pi_apply (Fin.last (n+1)))
    have hK : Measurable (K y xRef z₀ (n+1) (T+1)) :=
      h92.2.2.1.comp (measurable_const (a := ((y,xRef),z₀)) |>.prodMk measurable_id)
    have hcoord (t : Prefix (n+1) (T+1)) :
        obs (K y xRef z₀ (n+1) (T+1) t) = t.val (Fin.last n) := by
      have hpos : 0 < t.val (Fin.last n) := by
        have ht := t.property.1 (show (0 : Fin (n+2)) < (Fin.last n).succ by
          change 0 < n+1; omega)
        simpa only [Fin.cons_zero, Fin.cons_succ] using ht
      change (Real.toNNReal ((Fin.cons (0 : ℝ) (t.val : Fin (n+1) → ℝ) : Fin (n+2) → ℝ) (Fin.last (n+1))) : ℝ) = _
      change (Real.toNNReal (t.val (Fin.last n)) : ℝ) = _
      exact Real.coe_toNNReal _ hpos.le
    have hz := weighted_map_coordinate_null P
      (history y xRef z₀ (n+1) ⁻¹' A (n+1) (T+1)) (history y xRef z₀ (n+1))
      (n+1) (Δ (n+1) (T+1)) (K y xRef z₀ (n+1) (T+1))
      (q y xRef z₀ (n+1) (T+1)) obs (Fin.last n) (T : ℝ)
      hh.1 hK hobs hcoord hh.2.2.2.2.2.1
    apply measure_mono_null _ hz
    intro w hw
    refine ⟨?_, hw.2⟩
    obtain ⟨a, ha⟩ := hw.2.1 (Fin.last (n+1))
    change record y xRef z₀ (ε w) (n+1) = Sum.inl a at ha
    have he : a.1 = T := by
      have ht := hw.1
      change (record y xRef z₀ (ε w) (n+1)).elim _ _ = _ at ht
      rw [ha] at ht
      exact WithTop.coe_inj.mp ht
    change readTime (record y xRef z₀ (ε w) (n+1)) = (T : ℝ)
    rw [ha]
    exact congrArg (fun x : ℝ≥0 => (x : ℝ)) he
  have havoid (n : ℕ) : ∀ᵐ w ∂P, ¬ (eventTime y xRef z₀ w (n+1) = (T : WithTop ℝ≥0) ∧
      history y xRef z₀ (n+1) w ∈ A (n+1) (T+1)) := by
    rw [ae_iff]
    simpa only [not_not, Set.ofPred_and] using hzero n
  filter_upwards [hguard, ae_all_iff.mpr havoid] with w hg hn
  intro j hj heq
  obtain ⟨n, rfl⟩ := Nat.exists_eq_succ_of_ne_zero (Nat.ne_of_gt hj)
  apply hn n
  refine ⟨heq, hg (n+1) ?_⟩
  rw [heq]
  exact WithTop.coe_lt_coe.mpr (lt_add_one T)

#print axioms actual_fixed_horizon_endpoint_nullity
end
end EndpointInterfaces93
