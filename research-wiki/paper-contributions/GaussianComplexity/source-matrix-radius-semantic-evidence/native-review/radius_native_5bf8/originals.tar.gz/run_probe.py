from runner import *
s=json.loads((OUT/'settings.json').read_text())
label=sys.argv[1];src=OUT/sys.argv[2]
saved=OUT/'probe-inputs'/label;saved.mkdir(parents=True,exist_ok=False)
(saved/src.name).write_bytes(src.read_bytes())
(saved/'input.json').write_text(json.dumps({'source':str(src),'sha256':sha(src),'label':label},indent=2)+'\n')
run(label,['/Users/zhouhuanjian/.elan/toolchains/leanprover--lean4---v4.33.0/bin/lean',src],cwd=Path(s['snapshot']),env={'LEAN_PATH':s['LEAN_PATH']})
