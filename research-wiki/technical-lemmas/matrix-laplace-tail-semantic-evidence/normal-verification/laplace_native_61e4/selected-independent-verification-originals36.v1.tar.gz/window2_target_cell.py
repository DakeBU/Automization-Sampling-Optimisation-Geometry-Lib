"""Separate independent target-cell projection after actual normal V and all API-window guards."""
from common import *

def differences(a,b,path=''):
    if type(a) is not type(b):return [path]
    if isinstance(a,dict):
        result=[]
        for k in sorted(set(a)|set(b)):
            child=path+'/'+k
            if k not in a or k not in b:result.append(child)
            else:result+=differences(a[k],b[k],child)
        return result
    if isinstance(a,list):return [] if a==b else [path]
    return [] if a==b else [path]

def main():
    assert not (OWN/'window2-success.json').exists()
    first=read(OWN/'window1-success.json');public=read(OWN/'normal-V-outcome.public-summary.json');process=read(OWN/'window1-process.receipt.json')
    assert first['all_window1_postguards_passed'] and first['all_frontiers_including_target_unchanged']
    assert process['exit_code']==public['actual_exit_code']==0 and public['normal_API_calls']==1
    assert public['verified_commit']==CARRIER and public['verifier_id']==VERIFIER
    assert file_sha(OWN/'normal-V-exact-target-append.jsonl')==public['exact_appended_record_sha256']
    x=inputs()
    before=snapshot('window2-before')
    assert before['advances'][ADV]['state']=='VERIFIED' and before['advances'][ADV]['owner_id']==PROVER
    assert sum(r.get('advance_id')==ADV and r.get('to_state')=='VERIFIED' for r in before['records'])==1
    assert git('window2-initial-worktree-diff','diff','--name-only','HEAD','-z').split(b'\0')==[ADVPATH.encode(),b'']
    old_bytes=(REPO/CELL).read_bytes();old=json.loads(old_bytes);assert old['status']=='proved_locally' and old['owner_id']==PROVER and old['advance_id']==ADV
    (OWN/'target-cell.before.exact.json').write_bytes(old_bytes)
    projected=copy.deepcopy(old);projected['status']='independently_verified'
    evidence=projected['evidence']
    evidence['independent_verification']=str((OWN/'normal-V-outcome.public-summary.json').relative_to(REPO))
    evidence['normal_VERIFIED']={
      'advance_id':ADV,'verified_carrier':CARRIER,'verifier_id':VERIFIER,'normal_API_calls':1,'actual_exit_code':0,
      'full_inline_V_evidence':ident(OWN/'normal-V-final-payload.full.json'),
      'actual_exact_append':ident(OWN/'normal-V-exact-target-append.jsonl'),
      'actual_OS_process_receipt':ident(OWN/'window1-process.receipt.json'),
      'public_normal_V_outcome':ident(OWN/'normal-V-outcome.public-summary.json'),
      'original24_top_level_fields_unchanged':True,
      'actual_math_build_commit':MATH,'new_Lean_build_at_verified_metadata_carrier':False,
      'all_frontiers_including_target_unchanged_during_API_window':True,
      'cell_projection_scope':'Separate second window by the independent verifier; only this target cell changes. No stabilization/main/site/global graph/purification or whole-Goal completion.'
    }
    stage=evidence['current_normal_stage'];stage['advance_state']='VERIFIED';stage['cell_status']='independently_verified';stage['theorem_VERIFIED']=True
    stage['verifier_id']=VERIFIER;stage['verified_metadata_carrier']=CARRIER;stage['actual_math_build_identity']=MATH
    evidence['actual_current_normal_counts']['proof_VERIFIED']=1
    presentation=evidence['current_presentation_evidence_binding']
    presentation['state']=x['reader']['status']
    presentation['current_reader_acceptance']=ident(x['readerpath'])
    presentation['targeted_supplement']=copy.deepcopy(x['reader']['actual_targeted_supplement'])
    presentation['independent_visual_presentation']=copy.deepcopy(x['reader']['independent_corrective_review'])
    presentation['raw_original398_clip_limitation_and_supplement_FAIL_retained']=True
    presentation['optional_v3_executed']=False
    projected['consumer_scope']['first_realistic_consumer']['state']='ACTUAL_PRIVATE_COMPILED; immutable native/current v4 source and bounded isolated reader independently accepted; material four-family consumer checked within one normal independent proof VERIFIED. No separate public T node or independent T declaration V; stabilization remains pending.'
    projected['reuse_plan']['new_shared_declarations_status']='ACTUAL_COMPILED_IMMUTABLE1d110; independent native/source/bounded isolated reader accepted; normalPL1 and independent normal proofV1 at metadata carrier999b; stabilization/purification remain pending.'
    boundary=old['truth_boundary'];prefix=boundary.split('One normal PROVED_LOCAL',1)[0];suffix=boundary[boundary.index('Authored-v4 served bytes'):]
    projected['truth_boundary']=prefix+'One normal PROVED_LOCAL and one normal independent VERIFIED are recorded; the verified metadata/source/reader carrier is999b89925e95e463e0269148010f794dc27bb26a, while the actual independent Lean build identity remains immutable1d110. Current-v3 Chrome and independent bounded visual acceptance are complete. The old two-parent SVG clip finding is closed by four real supplemental viewport/node/core-label observations combined independently with the earlier same-fixture detail/source/navigation evidence. The original398 flags and the supplemental exit1/167checks/2false, wrong desktop crops and unexecuted mobile post-crop actions remain unchanged and explicit. The failed supplemental contract is not promoted to PASS and optional v3 was not executed. '+suffix
    assert projected['truth_boundary'].startswith(prefix) and projected['truth_boundary'].endswith(suffix)
    projected['phase_snapshot']='One actual normal PROVED_LOCAL and one normal independent VERIFIED by laplace_native_61e4_independent_verifier at exact carrier999b; immutable1d110 mathematical build/native and accepted current source/reader evidence reused without new Lean/browser/source work. All frontiers were unchanged in the API window; this target cell is now projected independently in a separate guarded window. Supplement raw FAIL/crop limitations and cancelled v3 remain preserved. Original stabilization owners remain held; no production/main/global graph/site/purification or whole-Goal completion.'
    changes=differences(old,projected)
    allowed=['/status','/evidence/independent_verification','/evidence/normal_VERIFIED','/evidence/current_normal_stage','/evidence/actual_current_normal_counts/proof_VERIFIED','/evidence/current_presentation_evidence_binding','/consumer_scope/first_realistic_consumer/state','/reuse_plan/new_shared_declarations_status','/truth_boundary','/phase_snapshot']
    assert all(any(path==base or path.startswith(base+'/') for base in allowed) for path in changes),changes
    for key in old:
        if key not in {'status','evidence','consumer_scope','reuse_plan','truth_boundary','phase_snapshot'}:assert projected[key]==old[key],key
    assert projected['consumer_scope']['first_realistic_consumer']['public_node'] is False
    assert projected['consumer_scope']['second_realistic_consumer']==old['consumer_scope']['second_realistic_consumer']
    assert projected['target_statement']==old['target_statement'] and projected['private_consumer_statement']==old['private_consumer_statement'] and projected['statement_seal']==old['statement_seal']
    sys.path.insert(0,str(REPO))
    from tools import astis_frontier_cells as cells
    probe=copy.deepcopy(projected);probe['__path__']=CELL
    validation=cells.validate_cells([probe]);assert not validation,validation
    new_bytes=(json.dumps(projected,ensure_ascii=False,indent=2)+'\n').encode()
    (OWN/'target-cell.projected.exact.json').write_bytes(new_bytes)
    write(OWN/'target-cell.projection-delta.json',{'advance_id':ADV,'independent_projector':VERIFIER,'changed_field_paths':changes,'mathematical_statement_private_consumer_and_seal_unchanged':True,'mathematical_truth_boundary_prefix_and_noncompletion_suffix_unchanged':True,'all_other_target_fields_unchanged':True,'target_cell_before_sha256':sha(old_bytes),'target_cell_after_sha256':sha(new_bytes),'focused_target_cell_schema_validation_errors':validation})
    print(json.dumps({'event':'projecting_only_target_cell','advance_id':ADV,'from_status':'proved_locally','to_status':'independently_verified'}),flush=True)
    with (REPO/CELL).open('wb') as handle:handle.write(new_bytes);handle.flush();os.fsync(handle.fileno())
    after=snapshot('window2-after')
    guards=postguards(before,after,{CELL},frontier_exception=CELL)
    assert before['advraw']==after['advraw'] and before['discraw']==after['discraw']
    assert (REPO/CELL).read_bytes()==new_bytes
    assert set(x.decode() for x in git('window2-final-worktree-diff','diff','--name-only','HEAD','-z').split(b'\0') if x)=={ADVPATH,CELL}
    write(OWN/'window2-success.json',{'advance_id':ADV,'verified_commit':CARRIER,'independent_projector':VERIFIER,'target_cell_status':'independently_verified','normal_API_calls_in_window2':0,'only_target_cell_projected':True,'all_window2_postguards_passed':True,'both_ledgers_exact_bytes_unchanged':True,'HEAD_index_all_other_tracked_and_other_frontiers_unchanged':True,'guards':guards,'target_cell_before_sha256':sha(old_bytes),'target_cell_after_sha256':sha(new_bytes),'source_mathematical_semantics_unchanged':True})
    print(json.dumps({'event':'window2_all_postguards_passed','target_cell_status':'independently_verified','normal_API_calls_in_window2':0}),flush=True)

if __name__=='__main__':main()
