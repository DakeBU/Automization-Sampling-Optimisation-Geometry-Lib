"""Bind the exact compiled delta to the original EGx11 source spans."""
from pathlib import Path

previous = Path('.astis/huanjian-gc-truncated-radial-covariance-20261111/make_source_lean_map.py').read_text()
prefix = previous.split('mappings = [', 1)[0]
prefix = prefix.replace('truncated-row-second-moment-semantic-evidence', 'weighted-cosine-frame-semantic-evidence')
prefix = prefix.replace('FixedSpectrumTruncatedRowMoment', 'FixedSpectrumWeightedFrameBound')
tail = r'''
mappings = [
    mapping(['S4.Thmtheorem4.p1.m2', 'S4.Thmtheorem4.p1.m3'],
            [(P, 15, 16), (T, 15, 18)],
            'Standing source range, natural q including zero, r=q+1 and positive denominators.'),
    mapping(['S4.E11.m1', 'A3.SS2.p5.m2', 'A3.Ex85.m1'],
            [(P, 17, 22), (T, 21, 25)],
            'Literal half-grid, source row i.val+1, constant feature one and higher sqrt(2) cosine coordinates.'),
    mapping(['A3.Ex87.m1', 'A3.Ex102.m1'],
            [(P, 40, 51)],
            'Canonical compiled cosine-frame theorem supplies both squared feature norm and exact Gram. No new norm theorem.'),
    mapping(['A3.Ex116.m1', 'A3.Ex117.m1'],
            [(P, 14, 27), (P, 52, 61), (P, 62, 88)],
            'The source deterministic comparison is lifted by the identity tensor, positive scalar and exact d normalization. It has no Gaussian proof premise.'),
    mapping(['A3.SS2.p1.m1', 'A3.SS2.p1.m5', 'A3.SS2.p10.m1', 'A3.SS2.p10.m2'],
            [(T, 16, 20), (T, 36, 40), (T, 63, 69)],
            'Actual canonical single-row Gaussian, radius and closed cutoff. Original experiment row-map and marginal transport remain open.'),
    mapping(['A3.Ex107.m1'], [(T, 26, 33), (T, 44, 62)],
            'Actual Gaussian-first paired-index Kronecker row template, inverse-d scaling and sum of marginal second moments.'),
    mapping(['A3.Ex113.m1'],
            [(T, 63, 66), (T, 153, 166)],
            'The same canonical radial fourth matrix theorem supplies both actual integrability and exact mean, materially used through each tensor map.'),
    mapping(['A3.SS2.p14.m2', 'A3.SS2.p14.m3', 'A3.Ex114.m1'],
            [(T, 71, 105)],
            'Ordinary rank-one and Kronecker squares, indicator idempotence and the actual square integrability.'),
    mapping(['A3.SS2.p14.3', 'A3.Ex115.m1', 'A3.Ex115.m2'],
            [(T, 106, 152), (T, 167, 172)],
            'PSD truncation deletion, integrability of finite sums, real PSD cone integration and exact aggregate mean.'),
    mapping(['A3.Ex115.m2', 'A3.Ex116.m1', 'A3.Ex117.m1'],
            [(T, 173, 179)],
            'Actual compiled deterministic producer is consumed to close the uncentered marginal second-moment sum, with no original-family or centered-variance credit.'),
]
draft = json.loads((evidence / 'publication-draft-record.json').read_bytes())
record = {
    'kind': 'Root-authored exact source/Lean map for independent review',
    'source_sha256': sha(raw),
    'actual_ASTIS_proof_parents': draft['actual_public_ASTIS_parents'],
    'mappings': mappings,
    'proof_background': [
        {'declaration': 'AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumCosineGram.actual_cosine_frame_gram',
         'source': code_span(Path('AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumCosineGram.lean'), 14, 26),
         'consumer': code_span(P, 40, 51),
         'meaning': 'One canonical emitted node supplies both norm and Gram conclusions.'},
        {'declaration': 'Matrix.PosSemidef.kronecker',
         'source': code_span(Path('.lake/packages/mathlib/Mathlib/Analysis/Matrix/Order.lean'), 213, 220),
         'consumer': code_span(P, 62, 69), 'meaning': 'Tensoring positive matrices preserves PSD order.'},
        {'declaration': 'AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumRadialFourthMoment.actual_radial_fourth_moment_matrix',
         'source': code_span(Path('AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumRadialFourthMoment.lean'), 23, 34),
         'consumer': code_span(T, 63, 66), 'meaning': 'Actual canonical fourth matrix moment and its integrability.'},
        {'declaration': 'Convex.integral_mem',
         'source': code_span(Path('.lake/packages/mathlib/Mathlib/Analysis/Convex/Integral.lean'), 57, 65),
         'consumer': code_span(T, 134, 152), 'meaning': 'Closed convex real PSD cone contains the aggregate residual integral.'},
    ],
    'mathlib_pin': 'db584cd6d46c92f209a44c0f1c829460d327499d',
    'scope': 'Exact deterministic EGx11 coefficient and canonical integrable marginal second-moment sum. Original-family adapters, centered variance, concentration, main bounds and integrated reader remain open.',
}
path = evidence / 'source-lean-map.draft.json'
with path.open('x') as out:
    json.dump(record, out, ensure_ascii=False, indent=2)
    out.write(chr(10))
print(json.dumps({'path': str(path), 'sha256': sha(path.read_bytes()),
                  'source_locator_entries': sum(len(m['source']) for m in mappings),
                  'Lean_spans': sum(len(m['lean']) for m in mappings)}))
'''
generated = Path(__file__).resolve().parent / 'make_source_lean_map.generated.py'
with generated.open('x') as out:
    out.write(prefix + tail)
exec(compile(prefix + tail, str(generated), 'exec'))
