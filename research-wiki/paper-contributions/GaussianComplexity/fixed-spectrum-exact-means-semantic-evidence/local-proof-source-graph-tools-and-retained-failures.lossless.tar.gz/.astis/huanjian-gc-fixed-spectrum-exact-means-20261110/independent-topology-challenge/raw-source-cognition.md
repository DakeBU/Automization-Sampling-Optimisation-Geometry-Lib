# Independent raw cognition: C8 closed means and exact normalized bias

Frozen before opening this packet's seal, standard-definition input or new extractor projection. This actor retains disclosed earlier C7/grid/Gaussian-means review context; the assignment also supplied the relevant anchors and risks. No zero-cue claim is made.

The pinned paper is the same 951991-byte HTML, SHA-256 `6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915`. A fresh read covered S4.SS1.p1.1, S4.E11, the entire Lemma 4.5 statement and all of Appendix C.3. Earlier source-only parsing code was reused only to display this raw source. No new seal, target implementation, API, graph, ledger or private extractor rationale has been opened.

## Source targets and standing objects

For d≥2, κ≥2 and integer 1≤n<d, the source has literal midpoint θᵢ=(i−1/2)π/d, λᵢ=(κ+1)/2+((κ−1)/2)cosθᵢ, precision Λ=diag(λᵢ), actual U∼N(0,Λ⁻¹) and Dₙ=diag(cos(nθᵢ)). Covariance is Λ⁻¹, not Λ. Let r=(√κ−1)/(√κ+1). Its strict range 0<r<1 and all positive spectral/square-root/series denominators must be internally derived.

M=E‖U‖² and μₙ=E[UᵀDₙU] are actual Gaussian integrals. A candidate cannot define them to be the desired rational formulas or merely deterministic sums. Source Fact C.8/Ex138 asserts both closed means:

\[
M=\frac d{\sqrt\kappa}\frac{1-r^{2d}}{1+r^{2d}},\qquad
(-1)^n\mu_n=\frac d{\sqrt\kappa}\frac{r^n-r^{2d-n}}{1+r^{2d}}.
\]

The new result must retain actual norm/Q integrability, avoiding totalized Bochner-integral defaults. The existing actual Gaussian-to-finite-grid bridge is an upstream ingredient, not a theorem-shaped public hypothesis and not itself either closed formula.

## Unweighted route p5 / Ex141–143

Ex140 first identifies M with the finite reciprocal-eigenvalue sum. C7 supplies the inverse-spectrum cosine series with a separate constant 1 and factor 2. The source then exchanges that absolutely convergent scalar series with the finite grid sum.

For positive source j, only j=2ad with integer a≥1 survives the grid alias. The source's a=0 mode is not part of the positive-j sum; its constant term was already separated. The alias contributes d(−1)^a, and (−r)^(2ad)=r^(2ad). Thus p5's series is d/√κ times [1+2Σ_{a≥1}(−1)^a r^(2ad)]. Its geometric ratio is **−r^(2d)**, not +r^(2d); the tail starts at a=1. The source simplifies this to [1−2r^(2d)/(1+r^(2d))] and then the closed M fraction.

The zero/multiple/nonmultiple cases of the all-integer alias theorem remain distinct. Continuous averaging would discard the surviving 2d modes and falsely give M=d/√κ. Their finite correction must remain.

## Weighted route p6 / Ex144–147

Before tail evaluation, source p6.1 removes Σᵢcos(nθᵢ)=0 using 1≤n<d, and product-to-sum cancels C7's factor 2. Ex144 has 1/√κ times the positive-j series with grid frequencies **j−n and j+n**, both in ℤ.

The full supported positive-j set is the disjoint union of:

1. j=n, with the j−n alias value d;
2. j=2ad+n, a≥1, with value d(−1)^a from j−n;
3. j=2ad−n, a≥1, with value d(−1)^a from j+n.

Completeness, injectivity and disjointness must all be accounted for. For j−n negative, signed integer aliasing is still the premise; source range n<d rules out any negative lattice multiple with positive j. Casting positive j to Nat and truncating j−n would create a spurious zero alias (e.g. d=3,n=2,j=1). The plus/minus tail classes start at a=1, not a=0. The minus class has positive first exponent 2d−n because n<d. Taking n=d would make classes overlap, so strict source range matters.

The source parity step is (−r)^(2ad±n)=(−1)^n r^(2ad±n). It holds for every allowed n; n is not assumed odd or query-related. Removing this common parity factor leaves the leading r^n and the two tails with exponents 2ad+n and 2ad−n. Ex145/146 respectively regroup and geometrically sum them, with common denominator 1+r^(2d). Ex147 cancels the r^(2d+n) term and gives the stated signed closed mean.

Absolute/supported-series summability must justify the infinite partition, reindexing and regrouping. Prove any needed class bounds, residue equalities or geometric tail values internally. They may not be public inputs merely because a future helper could produce them. These are scalar-series operations after Gaussian expectations have already become finite sums; no Gaussian-integral/infinite-series Fubini assumption is needed by the author's route.

## Private actual-integral consumer p8.2 and p9.1 / Ex150

For actual m=E‖U‖² and b=E[UᵀDₙU], the source's exact formulas and 0<r<1 imply m>0 and m≤d/√κ. p8.2 explicitly says the M upper bound follows from the exact M formula. The adjacent Ex148–149 variance bounds and fourth moments are **not prerequisites** of that upper bound.

Because n<d, one has n<2d−n and r^n>r^(2d−n). Hence (−1)^n b>0; it is false to replace this by b>0 for every n. Dividing the two actual means, with positivity/nonzero denominators internally discharged, yields the exact normalized absolute bias

\[
\frac{|b|}{m}=r^n\frac{1-r^{2(d-n)}}{1-r^{2d}}.
\]

No desired closed value is to be hidden in a definition of m or b, and positivity/sign/denominator conditions must be outputs or proved dependencies rather than input certificates. This is a substantive use of both actual closed Gaussian means; a detached rational identity with cosmetic unused integral names is not that consumer.

The Nat expressions 2*d−n and d−n are faithful to source integer differences only after 1≤n<d is used. Their additive exponent identities and positivity cannot be obtained by unexamined Nat subtraction. There is no new condition d−n≥√κ for exact sign, M upper or Ex150. No upper restriction κ≤d^(1−δ) belongs here.

## Required topology and scope

Both exact means are conjunctive outputs with different scalar tail subroutes. Gaussian moment/integrability bridge AND C7/finite-grid exchange AND all-integer aliases feed those routes; unweighted single-tail and weighted three-class regrouping are not alternative sufficient OR proofs of the whole joint target. Source proof ingredients must be dependency edges, never silently promoted to binders.

The private ratio/M-upper closure must depend on the closed means plus radius/power/denominator/sign arithmetic. It must not inherit Ex148–149 just because the M-upper sentence follows the variance display, nor Ex151 because its inequalities follow the ratio equality.

Full C.3 was read for exhaustive coverage. Ex138 and Ex141–147 are in-scope; some Ex IDs are tbody rows within grouped tables, so their math must not disappear under a table wrapper. The p6.2 paragraph contains separate class, disjointness, parity and composition obligations; silence about an unnamed substep is not coverage.

Excluded from this exact packet: Ex148–149 variance/fourth moments/independence; Ex151 correction-fraction inequalities; p10 logarithmic/power estimates and p11 exponential bias bounds/extra gap condition; rotated target transport, algorithms, oracle/TV/precision/cost and full lower bounds. The larger Lemma 4.5 statement is source context, not an already-proved premise closing these new claims. No new source V, completion or integration credit follows from this review.
