from pathlib import Path
import hashlib
import json
import os
import stat
from datetime import datetime, timezone

base=Path(__file__).resolve().parent
owner=base.parent
repo=Path('/Users/zhouhuanjian/ASTIS-GC')
rel='.astis/semantic-neutral-20261110/cg_tc_8f2b60/phase2a/'
raw_path=repo/'.astis/huanjian-resume-20261103/2610.20492v1.html'
raw=raw_path.read_bytes()
raw_sha=hashlib.sha256(raw).hexdigest()
assert len(raw)==951991
assert raw_sha=='6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
phase1=owner/'phase1'
manifest1=phase1/'manifest.json'
manifest1_bytes=manifest1.read_bytes()
assert hashlib.sha256(manifest1_bytes).hexdigest()=='d67f2864ba332e90e91cc8ba16c09db822f5229e0526b9223e6e920b607bca91'
m1=json.loads(manifest1_bytes)
for x in m1['artifacts']:
    p=phase1/x['path']
    b=p.read_bytes()
    assert len(b)==x['bytes'] and hashlib.sha256(b).hexdigest()==x['sha256'],x['path']
    assert stat.S_IMODE(p.stat().st_mode)==0o444,x['path']
assert stat.S_IMODE(manifest1.stat().st_mode)==0o444
assert stat.S_IMODE(phase1.stat().st_mode)==0o555
receipt1=owner/'phase1-freeze-receipt.json'
assert hashlib.sha256(receipt1.read_bytes()).hexdigest()=='c717be0ef061eb6e41b9c06c53003529523a8500fc3e6b4c0e9891c9bd0f320b'
assert stat.S_IMODE(receipt1.stat().st_mode)==0o444

projection=json.loads((base/'strict-statement-projection.json').read_bytes())
assert projection['source_raw_sha256']==raw_sha
inputs=json.loads((base/'input-verification.json').read_text())['inputs']
density=base/'additional-canonical-Gaussian-density-definitions.json'
inputs.append({'path':str(repo/'.astis/huanjian-gc-fixed-spectrum-cosine-gram-20261110'/density.name),
               'snapshot':density.name,'bytes':len(density.read_bytes()),'sha256':hashlib.sha256(density.read_bytes()).hexdigest()})
definitions=json.loads((base/'literal-string-hash-checks.json').read_bytes())
audit={
 'stage':'PHASE2a exact-type/minimal-definition audit before author SG',
 'decision':'PASS_LITERAL_PROJECTION_NO_EXCESS_BINDERS',
 'decision_scope':'Literal supplied signatures and authorized canonical definitions only; no elaboration, production-file identity or implementation proof has been checked.',
 'source_raw_sha256':raw_sha,'source_bytes':len(raw),
 'producer_signature_sha256':hashlib.sha256(projection['producer_signature'].encode()).hexdigest(),
 'consumer_signature_sha256':hashlib.sha256(projection['consumer_signature'].encode()).hexdigest(),
 'independent_binder_audit':[
   {'owner':owner_name,'binder':binder,'class':cls,'reason':reason}
   for owner_name in ['producer','private_consumer']
   for binder,cls,reason in [
      ('d:Nat','TYPING','Finite ambient dimension; d>=2 follows from hq.'),
      ('q:Nat','SOURCE','Nonnegative integer degree/query budget, including q=0.'),
      ('hq:2*q+1<d','SOURCE','Explicit Lemma4.4 source range inherited by C2/FactC5 context.')]],
 'classification_authority':'Independent reading of signatures and immutable raw cognition; supplied root binder_audit is exposed assertion, not authority.',
 'definition_kinds':{'theta':'literal','t':'literal','D':'literal','B':'literal','mu':'literal-canonical-Gaussian-construction','canonical_Gaussian_definitions':'literal'},
 'quantifier_domain_checks':{
    'all_q_including_zero':True,'strict_n_less_d_preserved':True,
    'd_ge_two_entailed':True,'real_half_shift':True,
    'constant_mode_one_nonconstant_sqrt_two':True,
    'frame_dimension_q_plus_one':True,'B_column_product_index':True,
    'covariance_dimension_d_times_q_plus_one':True,
    'frame_scalar_d_and_B_inverse_sqrt_d':True,
    'all_ordered_entry_pairs_integrable_and_integrated':True},
 'Gaussian_semantics':{
    'fixed_actual_measure':True,'free_measure_or_moment_certificate':False,
    'generic_nonPSD_fallback_exposed':True,'selected_covariance':'identity (PSD; justify internally)',
    'gaussianReal_zero_variance_branch_exposed':True,'selected_scalar_variance':'1 (nonzero)',
    'selected_density':'(sqrt(2*pi))^(-1)*exp(-x^2/2)',
    'source_column_Gaussian_joint_law_bridge':'Internal proof obligation if used; not caller hypothesis.',
    'totalized_integral_shortcut_blocked_by_explicit_Integrable_conclusions':True},
 'proof_ingredients_not_certified':[
    'identity covariance PSD and its CFC square-root behavior',
    'measurability of canonical pushforward maps and coordinate polynomials',
    'actual Gaussian coordinate moments and source independent-column/row-law bridge',
    'actual entry integrability from Gaussian law',
    'finite-sum/constant integration and product-index identity bookkeeping',
    'inverse sqrt d squared equals inverse d under d>0',
    'matrix-valued versus entrywise expectation adapter if later used'],
 'not_closed':['range(B)=Krylov','full FactC5','FactC6 concentration','full Lemma4.4','adaptive/oracle/TV/cost/main lower bounds','reader delivery'],
 'additional_definitions_requested':[
    {'name':'ProbabilityTheory.gaussianPDF','purpose':'Inspect actual non-Dirac scalar Gaussian density.'},
    {'name':'ProbabilityTheory.gaussianPDFReal','purpose':'Inspect normalization and exponent behind ENNReal.ofReal alias.'}],
 'additional_definition_need_satisfied':True,'further_definition_request':[],
 'literal_definition_hash_checks':definitions,
 'upstream_whole_file_hashes_and_line_locators':'Given by package metadata only; no Mathlib file was opened during this stage.',
 'inputs':inputs,
 'prior_phase1_unchanged':{'manifest_sha256':hashlib.sha256(manifest1_bytes).hexdigest(),
    'receipt_sha256':hashlib.sha256(receipt1.read_bytes()).hexdigest(),'artifact_files_0444':164,'phase1_mode':'0555'},
 'proof_or_API_or_native_or_sourceV_execution':False,'author_SG_seen':False,
 'failure_class':'NONE','failures':[],'truncation':False,
 'human_audit_sha256':hashlib.sha256((base/'type-definition-audit.md').read_bytes()).hexdigest()
}
(base/'type-definition-audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n')

initial_task='''Phase1 freeze收到。现PHASE2a只允许exactsealedtypes/minimaldefs：.astis/huanjian-gc-fixed-spectrum-cosine-gram-20261110/strict-statement-projection.json 6296B SHA8c881cf422b5c637472f868839a93849468c203a8e0f8cedabcf40139136c549；additional-canonical-Gaussian-definitions.json（同W目录）1299B SHA70d5c296f08f41d214fa9baae07f5601787e0d4ffcb087756e0d22743ef0ca51；multivariateGaussian-literal-definition.txt（同W目录）566B SHA0d32e6c37ec13dc0bdbce701ed77a7e2da591a748c8d8f92eb81a72cc2228171。不要打开其余W、rootplanning/seal全过程、任何implementation/API/SG/其他verdict/native/ledger。自己核验rawhash与真实literal签名/定义，并独立classification、quantifier/domain/constants/endpoints/q0、所有隐藏hyp/regularity/Gaussian fallback/entrywise actual means与integrability意义；包内root binderclassification不是权威。若需额外定义请具体name+purpose，root只送必要literalbody，不读proof。先将自己的type/definition审计完整实际input/commands/失败/exposure冻结于新phase2a，旧phase1全部bytes/hash/modes不改；再报告接authorSG，不提前看。无mathproof/sourceV/global权限。'''
request='''Phase2a三份输入hash/size均核验；phase1全部164文件hash/0444与dir0555保持，rawhash重核验。签名本身未见新增hyp，实际Gaussian entries/integrability为结论。为完成literal law语义审计，请只补充 `ProbabilityTheory.gaussianPDF` 的literal body及其直接用于指数/归一化的 `gaussianPDFReal`（如gaussianPDF只是ENNReal.ofReal别名）literal body/必要定义签名；用途是确认gaussianReal(0,1)的非Dirac分支确为规范标准正态密度，而非仅依赖definition说明。不要proof/APIlemma/SG。CFC.sqrt I/toEuclideanCLM/WithLp目前可按 canonical操作审计，无需整个泛化实现。'''
supplement='''补送only requested纯定义包：.astis/huanjian-gc-fixed-spectrum-cosine-gram-20261110/additional-canonical-Gaussian-density-definitions.json 1233B SHA1a9fc0110902d684b95e7ceeb50136058a89912aead7eabd46d387a36373599d。当前pinned Mathlib Real.lean L166完整gaussianPDF与L49–50完整gaussianPDFReal，无proof/APIlemma。按真实input记载并独立审计；不开放其余W/SG。'''
status_message='''Phase2a独立审计完成：就已给literal projection，producer三项精确匹配raw；private consumer固定真实identity-covariance Gaussian并把逐entry Integrable作为结论，未见EXCESS binder。补充密度定义已hash核验：variance1避开Dirac，(sqrt(2π))^-1 exp(-x²/2)归一化形状明确；generic nonPSD fallback在固定I上不可被用作证明捷径。审计明确保留实际law→moments/integrability、map/索引/有限和积分等内部proof义务，且未编译/未见production/SG。正在冻结phase2a，随后只接authorSG。'''
(base/'communications.json').write_text(json.dumps([
 {'direction':'received','sender':'/root','kind':'NEW_TASK','body':initial_task},
 {'direction':'sent','recipient':'/root','tool':'collaboration.send_message','body':request},
 {'direction':'received','sender':'/root','kind':'MESSAGE','body':supplement},
 {'direction':'sent','recipient':'/root','tool':'collaboration.send_message','body':status_message}
],ensure_ascii=False,indent=2)+'\n')

old="The projection includes an author's binder classification and prose meanings. They were read as exposed assertions, not accepted as authority. The following conclusions come from the actual signature strings, literal definition bodies and the independent raw cognition. The package's claimed upstream whole-file hashes/line numbers were not verified by reading Mathlib files, because this stage expressly authorizes only the named literal-definition packages. Serialized literal bodies were independently hashed and matched their declared hashes."
new=old+' No Lean elaboration or production-module inspection was performed; this PASS applies to the supplied literal projection under the specified canonical names, not to an unseen compiled declaration or its surrounding scope.'
body=(base/'type-definition-audit.md').read_text()
assert body.count(new)==1
(base/'type-definition-audit-v1.md').write_text(body.replace(new,old))
patch='*** Begin Patch\n*** Update File: '+str(base/'type-definition-audit.md')+'\n@@\n-'+old+'\n+'+new+'\n*** End Patch'
(base/'type-definition-audit-scope-clarification-actual.patch').write_text(patch)
for target,snapshot in [('read-exact-inputs.py','read-exact-inputs.py'),('read-density-input.py','read-density-input.py'),
                        ('type-definition-audit.md','type-definition-audit-v1.md'),('freeze-type-audit.py','freeze-type-audit.py')]:
    patch='*** Begin Patch\n*** Add File: '+str(base/target)+'\n'+''.join('+'+line+'\n' for line in (base/snapshot).read_text().splitlines())+'*** End Patch'
    (base/(target+'-actual-addfile.patch')).write_text(patch)
commands={
 'cwd':str(repo),'stage':'PHASE2a',
 'input_scope':'Four named file packages; raw hash and own immutable phase1; no other W artifact or repository API/implementation.',
 'events':[
   {'tool':'apply_patch','input_artifact':'read-exact-inputs.py-actual-addfile.patch','observed_output':{}},
   {'tool':'exec_command','command':'/opt/anaconda3/bin/python '+rel+'read-exact-inputs.py','stdout_artifact':'read-exact-inputs.stdout.txt','chunk_id':'701deb','exit_code':0,'original_token_count':2348,'truncation':False},
   {'tool':'collaboration.send_message','input_locator':'communications.json request entry','observed_output':{}},
   {'tool':'apply_patch','input_artifact':'read-density-input.py-actual-addfile.patch','observed_output':{}},
   {'tool':'exec_command','command':'/opt/anaconda3/bin/python '+rel+'read-density-input.py','stdout_artifact':'read-density-input.stdout.txt','chunk_id':'e83123','exit_code':0,'original_token_count':643,'truncation':False},
   {'tool':'apply_patch','input_artifact':'type-definition-audit.md-actual-addfile.patch','observed_output':{}},
   {'tool':'apply_patch','input_artifact':'type-definition-audit-scope-clarification-actual.patch','observed_output':{}},
   {'tool':'collaboration.send_message','input_locator':'communications.json status entry','observed_output':{}},
   {'tool':'apply_patch','input_artifact':'freeze-type-audit.py-actual-addfile.patch','observed_output':{}},
   {'tool':'exec_command','command':'/opt/anaconda3/bin/python '+rel+'freeze-type-audit.py','stdout_locator':'External phase2a-freeze-receipt.json and tool stdout receipt hashes','exit_code_policy':'Failure aborts; success verifies every manifest hash/mode and writes receipt.'}],
 'stderr':'','failures':[],'transport_truncations':[],
 'patch_capture_note':'Add-file literal inputs retained from their unchanged initial bodies; the exact one-line scope clarification patch is separately retained. No command input contains or reads a proof/API lemma.'
}
(base/'command-transcript.json').write_text(json.dumps(commands,ensure_ascii=False,indent=2)+'\n')
exposure={
 'raw_phase_completed_before_type_exposure':True,'phase1_manifest_sha256':hashlib.sha256(manifest1_bytes).hexdigest(),
 'authorized_file_inputs':inputs,'extra_definition_request_and_response':'communications.json',
 'root_binder_classification_seen_but_not_authority':True,
 'author_SG_exposure':False,'implementation_exposure':False,'proof_or_API_lemma_exposure':False,
 'root_planning_or_seal_history_exposure':False,'other_verdict_exposure':False,'native_or_sourceV_or_ledger_exposure':False,
 'computation_scope':['byte/hash/mode checks','JSON literal string hash checks','own audit packaging'],
 'no_Lean_or_mathproof_run':True,'upstream_files_opened':False,
 'source_validation_limit':'Literal projection under specified canonical names only; no elaboration or production-module inspection.',
 'all_inputs_outputs_saved':True,'failures':[],'truncations':[],
 'next_stage':'Author SG may be received only after this immutable audit freeze.'
}
(base/'exposure.json').write_text(json.dumps(exposure,ensure_ascii=False,indent=2)+'\n')

artifacts=[]
for f in sorted(base.iterdir(),key=lambda p:p.name):
    if f.name=='manifest.json':continue
    assert f.is_file()
    b=f.read_bytes()
    artifacts.append({'path':f.name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'frozen_mode':'0444'})
manifest={
 'kind':'independent-exact-type-definition-audit-freeze','stage':'PHASE2a',
 'prior_phase1_manifest_sha256':hashlib.sha256(manifest1_bytes).hexdigest(),'source_raw_sha256':raw_sha,
 'decision':audit['decision'],'artifacts':artifacts,
 'permissions':{'files':'0444','phase2a_directory':'0555'},
 'no_hash_cycle':'manifest excludes itself and the external receipt; external receipt hashes this manifest and is not itself hashed within its body.',
 'author_SG_seen':False,'implementation_or_proof_seen':False
}
(base/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
for f in base.iterdir():os.chmod(f,0o444)
os.chmod(base,0o555)
for x in artifacts:
    f=base/x['path']
    assert hashlib.sha256(f.read_bytes()).hexdigest()==x['sha256']
    assert stat.S_IMODE(f.stat().st_mode)==0o444
assert stat.S_IMODE((base/'manifest.json').stat().st_mode)==0o444
assert stat.S_IMODE(base.stat().st_mode)==0o555
receipt={
 'kind':'PHASE2a-type-definition-freeze-receipt','utc':datetime.now(timezone.utc).isoformat(),
 'directory':str(base),'manifest_sha256':hashlib.sha256((base/'manifest.json').read_bytes()).hexdigest(),
 'audit_md_sha256':hashlib.sha256((base/'type-definition-audit.md').read_bytes()).hexdigest(),
 'audit_json_sha256':hashlib.sha256((base/'type-definition-audit.json').read_bytes()).hexdigest(),
 'decision':audit['decision'],'decision_scope':audit['decision_scope'],
 'artifact_count_excluding_manifest':len(artifacts),'verified_files_0444':len(artifacts)+1,'verified_directory_mode':'0555',
 'all_manifest_hashes_match':True,'phase1_all_bytes_hashes_modes_unchanged':True,
 'phase1_manifest_sha256':hashlib.sha256(manifest1_bytes).hexdigest(),'phase1_receipt_sha256':hashlib.sha256(receipt1.read_bytes()).hexdigest(),
 'source_raw_sha256':raw_sha,'author_SG_seen':False,'proof_or_API_or_native_or_sourceV_run':False,
 'failures':[],'truncations':[],
 'freeze_command':'/opt/anaconda3/bin/python '+rel+'freeze-type-audit.py',
 'no_hash_cycle':'Receipt is outside PHASE2a and not listed by its manifest; its own hash is printed only.',
 'next_action':'Pause and receive author SG only; compare it with immutable raw cognition and this type/definition audit.'
}
receipt_path=owner/'phase2a-freeze-receipt.json'
receipt_path.write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
os.chmod(receipt_path,0o444)
print(json.dumps({'receipt':str(receipt_path),'receipt_sha256':hashlib.sha256(receipt_path.read_bytes()).hexdigest(),**receipt},ensure_ascii=False,indent=2))
