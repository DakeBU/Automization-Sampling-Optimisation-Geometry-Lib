"""Independent read-only audit of the preserved v5 actual browser artifacts; no browser rerun."""
import ast,datetime as dt,hashlib,json,os,re,struct,sys,time,traceback
from html.parser import HTMLParser
from pathlib import Path
OUT=Path(__file__).resolve().parent;OWN=OUT.parent;REPO=OWN.parents[2]
PREVIEW=REPO/'.astis/huanjian-gc-matrix-mgf-domain-20261115/reader-preview-v1/static-closure-v5';FIXTURE=PREVIEW/'fixtures/candidate';SNAPSHOT=PREVIEW/'input-snapshot'
PINS={'browser_check.py':'bea9db797093f7cb14fc32c01d6894984c3ee1f2dd264dc440ec130d431798f7','browser_geometry.py':'cc7eb67308d24fd5dbf87345b9e48ac1140ff7879bb05a96e08bc01a13d9efd4','browser_anchor_wait.py':'6b29bfff8201a6cb34503c0de8de5da1cf84b4285be104074f38254b51f6ec96','execution-assignment.json':'2476111825d66764a11a425b2441d175b9aab384d4cf17362e4e29fa9691586b','actual-result.json':'c7f4e06ddcbe0faae278e66d6c3b1cfca7383c2af401db054b0e6068af2c16ba'}
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,x):
    with Path(p).open('x') as f:f.write(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
class Node:
    def __init__(self,t='',a=()):self.tag=t;self.attrs=dict(a);self.children=[]
    def text(self):return ''.join(x if isinstance(x,str) else x.text() for x in self.children)
    def has(self,c):return c in self.attrs.get('class','').split()
    def find(self,p):
        out=[]
        for x in self.children:
            if isinstance(x,Node):
                if p(x):out.append(x)
                out.extend(x.find(p))
        return out
class Parse(HTMLParser):
    def __init__(self,s):super().__init__(convert_charrefs=True);self.root=Node();self.stack=[self.root];self.feed(s)
    def handle_starttag(self,t,a):
        n=Node(t,a);self.stack[-1].children.append(n)
        if t not in {'area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr'}:self.stack.append(n)
    def handle_endtag(self,t):
        for i in range(len(self.stack)-1,0,-1):
            if self.stack[i].tag==t:self.stack=self.stack[:i];break
    def handle_data(self,s):self.stack[-1].children.append(s)
def intersect(a,b):
    w=max(0,min(a['right'],b['right'])-max(a['left'],b['left']));h=max(0,min(a['bottom'],b['bottom'])-max(a['top'],b['top']))
    return w,h,w*h
def signature(s):
    g=s['geometry'];p=s['pre_scroll'] or {'left':0,'top':0}
    return [s['window_scroll']['x'],s['window_scroll']['y'],p['left'],p['top'],*[g[k] for k in ['left','right','top','bottom']],g['header'],*[g['clip'][k] for k in ['left','right','top','bottom']]]
def main():
    checks=[]
    def check(n,ok,detail=None):
        checks.append({'name':n,'pass':bool(ok),'detail':detail})
        if not ok:raise AssertionError(n)
    check('all-five-actual-runtime-pins',all(sha(OWN/p)==h for p,h in PINS.items()))
    j=json.loads((OWN/'actual-result.json').read_text());receipt=json.loads((OWN/'runtime-process/receipt.json').read_text());a=json.loads((OWN/'execution-assignment.json').read_text())
    check('actual-OS-exit0-no-exception',receipt['actual_exit_code']==0 and receipt['exception'] is None)
    check('actual-OS-streams-exact',all(sha(OWN/receipt[k]['path'])==receipt[k]['sha256'] and (OWN/receipt[k]['path']).stat().st_size==receipt[k]['bytes'] for k in ['stdout','stderr']))
    check('actual-result-and-receipt-identities',receipt['actual_result_sha256']==PINS['actual-result.json'] and receipt['assignment_sha256']==PINS['execution-assignment.json'] and receipt['runner_sha256']==PINS['browser_check.py'])
    check('actual-523-checks-no-false',j['status']=='PASS' and len(j['checks'])==523 and not [c for c in j['checks'] if not c['pass']])
    lookup={c['name']:c for c in j['checks']};check('all-actual-check-names-unique',len(lookup)==523)
    summary=json.loads((OWN/'runtime-process/stdout.raw').read_text());check('actual-stdout-matches-real-result',summary['status']=='PASS' and summary['checks']==523 and summary['false_checks']==[] and summary['actual_result_sha256']==PINS['actual-result.json'])
    check('v5-manifest-exact',sha(PREVIEW/'preview-freeze-manifest.json')==j['preview_manifest_sha256']=='08e7fdb3607a2330623fb5c68aee4e7e50c61e3a77aa2029846180312b455b61')
    check('all-assignment-input-pins-still-exact',all(sha(r['path'])==r['sha256'] for r in a['frozen_inputs']))
    m=json.loads((PREVIEW/'preview-freeze-manifest.json').read_text());rows=m['variants']['candidate']['files']
    check('all110-actual-fixture-paths-and-bytes-unchanged',len(rows)==110 and {str(p.relative_to(FIXTURE)) for p in FIXTURE.rglob('*') if p.is_file()}=={r['path'] for r in rows} and all(sha(FIXTURE/r['path'])==r['sha256'] and (FIXTURE/r['path']).stat().st_size==r['bytes'] for r in rows))
    names={}
    for n in ast.parse((OWN/'browser_check.py').read_text()).body:
        if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id in ['ITEM','PFILE','TFILE','P','T','PSD','TRACE','SOURCES']:names[n.targets[0].id]=eval(compile(ast.Expression(n.value),'<pure own literal targets>','eval'),{'__builtins__':{}},names)
    sources=names['SOURCES'];by_label={s[0]:s for s in sources};unit=json.loads((SNAPSHOT/'website/content/declaration_lessons/huanjian-matrix-mgf-domain.json').read_text())['units'][0]
    check('P-T-byte-identities-no-new-math-build-claim',sha(SNAPSHOT/names['PFILE'])=='d3c6e5a194fecf1ae1abe45c70310f4f47d66e903b098019c326ee0d3018b024' and sha(SNAPSHOT/names['TFILE'])=='60e9f7b928ebc1b8a0d9efad93f39f1b172fe0a871893d67eb1015582c5d5c61' and j['mathematical_commit']=='a8bb8ea5b4474be5214bd83ae380a612e2cecb78' and j['source_reviewed_binding']=='5e79fa3d4390c4d1e689174b0c014d67fb8dbfb550f986b4af7d8474ef644691')
    dom=Parse((FIXTURE/m['variants']['candidate']['proof_path']).read_text()).root;article=dom.find(lambda n:n.tag=='article' and n.has('proof-reader'))[0];steps=article.find(lambda n:n.tag=='details' and n.has('proof-reader-step'))
    check('all-five-adjacent-spans-exact262-lines',len(steps)==5 and [s.find(lambda n:n.tag=='pre')[0].text() for s in steps]==[s['lean'] for s in unit['steps']] and ''.join(s['lean'] for s in unit['steps'][:2]).encode()==(SNAPSHOT/names['PFILE']).read_bytes() and ''.join(s['lean'] for s in unit['steps'][2:]).encode()==(SNAPSHOT/names['TFILE']).read_bytes() and sum(len(s['lean'].splitlines()) for s in unit['steps'])==262)
    check('initial-main-disclosures-HTML-closed',all('open' not in n.attrs for n in dom.find(lambda n:n.tag=='main')[0].find(lambda n:n.tag=='details')))
    source_doms={}
    for label,raw,decl,anchor,lines in sources:
        d=Parse((FIXTURE/('data/lesson-sources/'+raw+'.html')).read_text()).root;source_doms[label]=d
        check(label+'-complete-source-bytes-lines-anchor-and-download',d.find(lambda n:n.tag=='pre')[0].text().encode()==(SNAPSHOT/raw).read_bytes()==(FIXTURE/('downloads/lean/'+raw)).read_bytes() and len((SNAPSHOT/raw).read_text().splitlines())==lines and d.find(lambda n:n.attrs.get('id')=='L'+str(anchor))[0].text().strip().startswith(('private theorem ' if label=='T' else 'theorem ')+decl.split('.')[-1]))
    downloads=[]
    for p in sorted((OWN/'runtime-output').glob('*.lean')):
        match=re.fullmatch('(desktop|mobile)-step([1-5])-whole-module.lean',p.name)
        if match:raw=unit['steps'][int(match[2])-1]['lean_source_path']
        else:
            match=re.fullmatch('(desktop|mobile)-source-(P|T|PSD|TRACE|Radius|Structure)-whole-module.lean',p.name)
            raw=by_label[match[2]][1] if match else names['TFILE'] if re.fullmatch('(desktop|mobile)-private-T-module-context-download.lean',p.name) else None
        check('actual-download-byte-exact:'+p.name,raw is not None and p.read_bytes()==(SNAPSHOT/raw).read_bytes())
        downloads.append({'path':str(p.relative_to(OWN)),'bytes':p.stat().st_size,'sha256':sha(p),'source_path':raw})
    check('all24-actual-downloads-present',len(downloads)==24)
    clipboard=[c for c in j['checks'] if c['name'].endswith('-actual-copy-byte-exact') or c['name'].endswith('-actual-complete-source-copy-exact')]
    expected_clipboard={label+'-step'+str(i)+'-actual-copy-byte-exact' for label in ['desktop','mobile'] for i in range(1,6)}|{label+'-'+s[0]+'-actual-complete-source-copy-exact' for label in ['desktop','mobile'] for s in sources}
    check('all22-actual-clipboard-comparison-records-present',len(clipboard)==22 and {c['name'] for c in clipboard}==expected_clipboard and all(c['pass'] for c in clipboard))
    expected_cases={label+'-step'+str(i) for label in ['desktop','mobile'] for i in range(1,6)}|{label+'-source-'+s[0] for label in ['desktop','mobile'] for s in sources}
    traces=j['natural_source_anchor_stability_traces'];check('all22-generic-natural-stability-cases-exact',len(traces)==22 and {t['case'] for t in traces}==expected_cases)
    trace_summaries=[]
    for t in traces:
        ss=t['samples'];g=t['settled_geometry'];tail=ss[-4:];iw,ih,area=intersect(g,g['clip'])
        check(t['case']+'-raw-immediate-settled-and-temporal-order',len(ss)>=4 and t['immediate_geometry']==ss[0]['geometry'] and g==ss[-1]['geometry'] and all(b['elapsed_ms']>a['elapsed_ms'] for a,b in zip(ss,ss[1:])))
        check(t['case']+'-four-stable-samples-independent-recompute',all(max(z)-min(z)<=.25 for z in zip(*(signature(s) for s in tail))) and all(b['elapsed_ms']-a['elapsed_ms']>=100 for a,b in zip(tail,tail[1:])) and 500<=ss[-1]['elapsed_ms']<5000 and t['stable'])
        check(t['case']+'-strict-original-visibility-header-predicate-recomputed',iw>0 and ih>0 and g['top']>=g['header']-1 and g['positive'] and abs(ih-g['intersectionHeight'])<1e-9 and abs(iw-g['intersectionWidth'])<1e-9)
        case=t['case'].split('-',1)[1]
        if case.startswith('step'):
            s=unit['steps'][int(case[4:])-1];raw=s['lean_source_path'];anchor=s['lean_source']['LF_lines_1based'][0]
        else:s=by_label[case[7:]];raw,anchor=s[1],s[3]
        check(t['case']+'-exact-source-target-URL',t['target'].endswith(raw+'.html#L'+str(anchor)))
        check(t['case']+'-same-bbox-wait-not-forced-target-scroll',t['no_programmatic_scroll_style_transform_or_animation_change'] and all(s['pre_scroll']=={'left':0,'top':0} for s in ss))
        trace_summaries.append({'case':t['case'],'target':t['target'],'samples':len(ss),'immediate_top':t['immediate_geometry']['top'],'immediate_intersection_height':t['immediate_geometry']['intersectionHeight'],'settled_top':g['top'],'settled_header':g['header'],'settled_intersection_height':ih,'stability_complete_elapsed_ms':ss[-1]['elapsed_ms'],'last_four_samples_recomputed':True})
    graphs=[]
    for c in j['checks']:
        if not c['name'].endswith('-readable-node-core-label-inside-real-SVG-clip'):continue
        d=c['detail'];g=d['after_native_UI'];clip=g['clip'];n=g['node'];l=g['labelRect'];sr=g['svg'];vp=g['viewport'];nw,nh,na=intersect(n,clip);lw,lh,la=intersect(l,clip);nf=na/(n['width']*n['height']);lf=la/(l['width']*l['height'])
        check(c['name']+'-independent-clipped-bbox-recompute',nf>=.98 and lf>=.95 and abs(nf-g['intersectionFraction'])<1e-9 and abs(lf-g['labelVisibleFraction'])<1e-9 and g['effectiveFontPx']>=12 and lw>=min(80,l['width']) and lh>=min(12,l['height']) and clip['left']>=max(0,sr['left']) and clip['right']<=min(vp['width'],sr['right']) and clip['top']>=max(g['headerBottom']+8,sr['top']) and clip['bottom']<=min(vp['height']-8,sr['bottom']) and d['native_pointer_and_wheel_exercised'] and not d['direct_SVG_transform_or_node_style_writes'])
        graphs.append({'case':c['name'],'node_visible_fraction':nf,'label_visible_fraction':lf,'effective_font_px':g['effectiveFontPx'],'label':g['label'],'label_visible_width':lw,'label_visible_height':lh})
    check('all-six-native-graph-focuses-recomputed',len(graphs)==6)
    graph=json.loads((FIXTURE/'data/underlying-lean-graph.json').read_text());modules=[s[1][:-5].replace('/','.') for s in sources]
    expected_nodes={'module:'+s for s in modules}|{'decl:'+sources[i][2] for i in [0,2,3,4,5]}
    expected_edges={('module:'+modules[2],'module:'+modules[0],'imports')}|{('module:'+modules[i],'module:'+modules[1],'imports') for i in [0,3,4,5]}|{('module:'+modules[i],'decl:'+sources[i][2],'declares') for i in [0,2,3,4,5]}|{('decl:'+names['PSD'],'decl:'+names['P'],'source reference (scanner)')}|{('decl:'+sources[i][2],'module:'+modules[1],'source reference (scanner)') for i in [0,3,4,5]}
    check('exact11nodes15edges-directed-reference-topology-recomputed',len(graph['nodes'])==11 and {n['id'] for n in graph['nodes']}==expected_nodes and len(graph['edges'])==15 and {(e['source'],e['target'],e['relation']) for e in graph['edges']}==expected_edges and 'do not assert theorem implication' in graph['reference_contract'])
    for label in ['desktop','mobile']:
        for focus,node_id in [('P','decl:'+names['P']),('PSD','decl:'+names['PSD']),('private-T-module','module:'+modules[1])]:
            prefix=label+'-graph-'+focus
            for title,incoming in [('Immediate-prerequisites',True),('Immediate-consumers',False)]:
                actual=lookup[prefix+'-'+title+'-exact-neighbor-directions']['detail'];expected=[e['source'] if incoming else e['target'] for e in graph['edges'] if e['target' if incoming else 'source']==node_id]
                check(prefix+'-'+title+'-actual-DOM-vs-recomputed-graph',sorted(actual['actual'])==sorted(expected))
            vg=lookup[prefix+'-full-ID-detail-real-visible-area']['detail'];_,height,_=intersect(vg,vg['clip'])
            check(prefix+'-detail-full-ID-visible-area-recomputed',height>=min(vg['height']-1,120) and lookup[prefix+'-actual-context-navigation']['pass'])
    glyphs=[]
    for c in j['checks']:
        if not c['name'].endswith('full-codepoint-visible'):continue
        d=c['detail'];g=d['glyph'];clip=d['actualVisibleClip'];source_label=c['name'].split('-')[1];raw=source_doms[source_label].find(lambda n:n.attrs.get('id')==d['lineId'])[0].text();selected=raw.encode('utf-16-le')[2*d['selectedGlyphStartUTF16']:2*d['selectedGlyphEndUTF16']].decode('utf-16-le');left=max(0,clip['left']-g['left']);right=max(0,g['right']-clip['right'])
        check(c['name']+'-raw-codepoint-and-visible-geometry-recomputed',selected==d['selectedGlyph'] and len(selected)==1 and [ord(x) for x in selected]==d['codePoints'] and left<=1 and right<=1 and g['width']>0 and g['height']>0 and g['top']>=clip['top'] and g['bottom']<=clip['bottom'] and d['lineVisible'])
        glyphs.append({'case':c['name'],'line':d['lineId'],'codepoint':ord(selected),'left_bbox_overhang_css_px':left,'right_bbox_overhang_css_px':right})
    check('24-glyph-measurements-recomputed',len(glyphs)==24)
    shots=[]
    for s in j['screenshots']:
        p=OWN/s['path'];raw=p.read_bytes();w,h=struct.unpack('>II',raw[16:24]);check('actual-original-PNG-pin:'+p.name,sha(p)==s['sha256'] and raw[:8]==b'\x89PNG\r\n\x1a\n' and w in [390,1440]);shots.append({**s,'width':w,'height':h})
    check('all50-original-PNGs-no-extra-missing-image',len(shots)==50 and len({s['path'] for s in shots})==50 and {str(p.relative_to(OWN)) for p in (OWN/'runtime-output').glob('*.png')}=={s['path'] for s in shots})
    layout={label:lookup[label+'-final-context-document-horizontal-containment']['detail'] for label in ['desktop','mobile']}
    check('mobile-actual-body-html390-no-overflow',layout['mobile']=={'viewport':390,'html':390,'body':390})
    check('desktop-actual-body-html1440',layout['desktop']=={'viewport':1440,'html':1440,'body':1440})
    check('actual-local-network-no-errors-and-server-thread-stopped',len(j['requests'])==len(j['responses'])==1646 and not j['console'] and not j['page_errors'] and not j['blocked_external_requests'] and all(r['status']<400 for r in j['responses']) and j['server_and_worker_stopped'])
    result={'schema':'R17-v5-independent-actual-data-audit-v1','checks':checks,'actual_runtime_pins':PINS,'actual_runtime_status':'PASS','actual_OS_receipt_sha256':sha(OWN/'runtime-process/receipt.json'),'actual_downloads':downloads,'actual_clipboard_equality_records':clipboard,'clipboard_payloads_separately_serialized':False,'natural_stability_trace_summaries':trace_summaries,'all22_traces_recomputed':True,'graph_clipped_bbox_recomputations':graphs,'glyph_recomputations':glyphs,'max_horizontal_Range_bbox_overhang_css_px':max(x['right_bbox_overhang_css_px'] for x in glyphs),'actual_original_screenshots':shots,'actual_final_layout':layout,'all_original_runtime_artifacts_unchanged':True,'no_browser_or_API_Lean_Git_site_source_write_by_audit':True}
    write(OUT/'actual-data-audit.json',result)
    print(json.dumps({'audit':'COMPLETE','checks':len(checks),'original_PNGs_hash_checked':50,'natural_traces_recomputed':22,'downloads_exact':24,'clipboard_equality_records':22,'graph_clip_cases':6,'glyph_cases':24,'actual_data_audit_sha256':sha(OUT/'actual-data-audit.json')}))
if __name__=='__main__':
    p=OUT/'process';p.mkdir(exist_ok=False)
    for fd,n in [(1,'stdout.raw'),(2,'stderr.raw')]:
        f=(p/n).open('xb',buffering=0);os.dup2(f.fileno(),fd);f.close()
    utc=dt.datetime.now(dt.timezone.utc).isoformat();start=time.monotonic();code=0
    try:main()
    except BaseException:traceback.print_exc();code=1
    sys.stdout.flush();sys.stderr.flush()
    write(p/'receipt.json',{'schema':'R17-actual-readonly-v5-reader-review-OS-receipt-v1','argv':[sys.executable,*sys.argv],'cwd':str(Path.cwd()),'pid':os.getpid(),'started_utc':utc,'ended_utc':dt.datetime.now(dt.timezone.utc).isoformat(),'elapsed_seconds':time.monotonic()-start,'actual_exit_code':code,'script_sha256':sha(__file__),'stdout_sha256':sha(p/'stdout.raw'),'stderr_sha256':sha(p/'stderr.raw'),'no_browser_API_Lean_Git_or_source_action':True})
    sys.exit(code)
