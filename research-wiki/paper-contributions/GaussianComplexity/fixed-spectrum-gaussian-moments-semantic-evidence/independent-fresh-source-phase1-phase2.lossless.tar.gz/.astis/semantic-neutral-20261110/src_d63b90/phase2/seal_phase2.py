from pathlib import Path
import json,hashlib,datetime
root=Path('/Users/zhouhuanjian/ASTIS-GC');out=root/'.astis/semantic-neutral-20261110/src_d63b90/phase2'
reads=[]
def add(chunk,cmd,exposure,max_tokens):
    p=out/f'read-{len(reads)+1:02d}.sh';p.write_text(cmd+'\n')
    reads.append({'sequence':len(reads)+1,'tool':'functions.exec -> tools.exec_command','cwd':str(root),'exact_command_file':str(p.relative_to(root)),'command_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'observed_result_chunk_id':chunk,'observed_exit_code':0,'max_output_tokens':max_tokens,'visible_exposure':exposure})
add('be7347',"""python3 - <<'PY'
from pathlib import Path
import hashlib
p=Path('.astis/semantic-neutral-20261110/src_d63b90/phase2-inputs/selective-input.json')
b=p.read_bytes();h=hashlib.sha256(b).hexdigest();assert h=='42970541548f93e09cb5f099017ef2015c75e3c7a80ce7aa9cedbdbc350b1ed6'
print('raw_sha256',h)
print(b.decode())
PY""",'Only exact selective-input.json after matching authorized raw digest. Public anonymous statement, approved definition strings, blind reconstruction, source restatement/anchors, private anonymous statement and supplied decoder hash references became visible.',15000)
add('aed576',"""python3 - <<'PY'
from pathlib import Path
import hashlib,json
p=Path('.astis/semantic-neutral-20261110/src_d63b90/phase2-inputs/manifest.json');b=p.read_bytes();h=hashlib.sha256(b).hexdigest();assert h=='67444172f33625e9c495418a47a574e41c59907e8bb6bd73ccda7b7047200701';print('raw_sha256',h);print(b.decode())
q=Path('.astis/semantic-neutral-20261110/src_d63b90/phase2-inputs/selective-input.json');j=json.loads(q.read_text())
for name,value,digest in [('source.original_text',j['source']['original_text'],j['source']['text_sha256']),('lean_statement.statement',j['lean_statement']['statement'],j['lean_statement']['statement_sha256']),('blind_reconstruction.text',j['blind_reconstruction']['text'],j['blind_reconstruction']['text_sha256'])]:
    actual=hashlib.sha256(value.encode()).hexdigest();print(name,actual,'matches',actual==digest);assert actual==digest
PY""",'Only exact manifest; verified the three embedded string hashes. No new candidate context beyond authorized selective input.',6000)
add('bc3110','cat .astis/semantic-neutral-20261110/src_d63b90/phase1/source-cognition.md .astis/semantic-neutral-20261110/src_d63b90/phase1/source-seven-slots.json','Own frozen phase-1 raw-source cognition and seven source slots reread.',9500)
add('33b177',"""python3 - <<'PY'
from pathlib import Path
from html.parser import HTMLParser
import hashlib,json,re
root=Path('/Users/zhouhuanjian/ASTIS-GC');p=root/'.astis/semantic-neutral-20261110/src_d63b90/phase1/phase1-freeze.json';b=p.read_bytes();assert hashlib.sha256(b).hexdigest()=='763446abce7e48ec32330ff4a7ee1538187a8fe9d9a80e6f29fa82b7276b054d';j=json.loads(b)
for x in j['files']:
    q=root/x['path'];assert hashlib.sha256(q.read_bytes()).hexdigest()==x['sha256']
src=root/'.astis/huanjian-resume-20261103/2610.20492v1.html';b=src.read_bytes();assert hashlib.sha256(b).hexdigest()=='6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915';s=b.decode()
class Text(HTMLParser):
    def __init__(self): super().__init__();self.parts=[];self.depth=0
    def handle_starttag(self,tag,attrs):
        if tag=='math':self.parts.append('$'+dict(attrs)['alttext']+'$');self.depth+=1
    def handle_endtag(self,tag):
        if tag=='math':self.depth-=1
    def handle_data(self,text):
        if not self.depth:self.parts.append(text)
print('Phase1 freeze verified:',len(j['files']),'files')
for ident in ['A3.SS3.p4.1','A3.SS3.p4.2','A3.SS3.p6.1']:
    m=re.search(r'<p id="'+re.escape(ident)+r'"[^>]*>',s);assert m;end=s.index('</p>',m.start())+4;t=Text();t.feed(s[m.start():end]);print(ident, ''.join(t.parts))
start=s.index('<table id="A3.Ex140"');end=s.index('</table>',start)+8;t=Text();t.feed(s[start:end]);print('A3.Ex140',''.join(t.parts))
start=s.index('<table id="A3.Ex144"');end=s.index('</table>',start)+8;t=Text();t.feed(s[start:end]);print('A3.Ex144',''.join(t.parts))
PY""",'Own 37 phase-1-frozen artifacts hashchecked, including own source-extraction tool by bytes only. Pinned source hashverified and exact raw source p4.1,p4.2,p6.1,Ex140,Ex144 emitted. No candidate implementation or other review read.',4000)
ledger={'phase':2,'reviewer_task':'/root/source_reader_d63b90','decoder_identity_supplied':'/root/decoder_47c18e','authorization':'Explicit parent phase2 message and exact manifest-path clarification; selective statement/reconstruction comparison only.','new_external_input_paths':['.astis/semantic-neutral-20261110/src_d63b90/phase2-inputs/selective-input.json','.astis/semantic-neutral-20261110/src_d63b90/phase2-inputs/manifest.json'],'source_cognition_preceded_candidate_exposure':True,'phase1_freeze_preserved':True,'candidate_public_statement_read':True,'candidate_private_statement_read':True,'approved_definition_context_read':True,'blind_reconstruction_read':True,'source_identity_visible':True,'implementation_or_proof_read':False,'whole_module_read':False,'production_or_test_files_read':False,'lessons_or_publication_context_read':False,'prior_verdicts_repairs_or_other_reviews_read':False,'graphs_frontier_or_ledger_api_read':False,'canonical_full_packet_located_or_opened':False,'canonical_full_packet_hash_reference_only':'3e850055902cef5e2b0fd3864319ead356f648b0aed2c18595b5fb9e27f922a8','network_browser_build_or_global_mutation':False,'toolreads':reads,'artifact_only_mutations':[{'chunk_id':'48e9b2','exit_code':0,'action':'Created phase2/phase2-review.md from independent comparison.'},{'chunk_id':'92aa7e','exit_code':0,'action':'Clarified proof-use language and wrote seven-slot-comparison.json.'}],'decoder_independence_limit':'Decoder source-hidden/run identity evidence was supplied in selective-input.json; source reviewer did not independently reopen or replay the decoder run.','scope_boundary':'Statement-level comparison accepted; no implementation/compilation/dependency-use/publication/source-V credit. Stop pending explicit phase3 authority.'}
(out/'exposure-toolread-ledger.json').write_text(json.dumps(ledger,indent=2)+'\n')
inputs=[]
for path,expected in [('.astis/semantic-neutral-20261110/src_d63b90/phase2-inputs/selective-input.json','42970541548f93e09cb5f099017ef2015c75e3c7a80ce7aa9cedbdbc350b1ed6'),('.astis/semantic-neutral-20261110/src_d63b90/phase2-inputs/manifest.json','67444172f33625e9c495418a47a574e41c59907e8bb6bd73ccda7b7047200701'),('.astis/semantic-neutral-20261110/src_d63b90/phase1/phase1-freeze.json','763446abce7e48ec32330ff4a7ee1538187a8fe9d9a80e6f29fa82b7276b054d'),('.astis/huanjian-resume-20261103/2610.20492v1.html','6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915')]:
    p=root/path;b=p.read_bytes();actual=hashlib.sha256(b).hexdigest();assert actual==expected;inputs.append({'path':path,'bytes':len(b),'sha256':actual})
(out/'raw-inputs-manifest.json').write_text(json.dumps({'phase':2,'actual_inputs':inputs,'canonical_full_packet_hash_reference_only':ledger['canonical_full_packet_hash_reference_only']},indent=2)+'\n')
files=[]
for p in sorted(out.iterdir()):
    if p.is_file() and p.name!='FREEZE.json':files.append({'path':str(p.relative_to(root)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
freeze={'phase':2,'reviewer_task':'/root/source_reader_d63b90','frozen_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'phase1_freeze_sha256':'763446abce7e48ec32330ff4a7ee1538187a8fe9d9a80e6f29fa82b7276b054d','public_statement_fidelity_verdict':'equivalent','blocking_deltas':0,'private_consumer_statement_verdict':'source-faithful-actual-Gaussian-Q-to-series-target','implementation_or_runtime_acceptance':False,'source_V_authorized_or_recorded':False,'next_authority':'Explicit parent phase3 authority required before whole-module/proof/runtime inspection.','inputs':inputs,'files':files}
p=out/'FREEZE.json';p.write_text(json.dumps(freeze,indent=2)+'\n')
print(json.dumps({'freeze_path':str(p.relative_to(root)),'freeze_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'frozen_files':len(files),'report_sha256':hashlib.sha256((out/'phase2-review.md').read_bytes()).hexdigest(),'comparison_sha256':hashlib.sha256((out/'seven-slot-comparison.json').read_bytes()).hexdigest(),'ledger_sha256':hashlib.sha256((out/'exposure-toolread-ledger.json').read_bytes()).hexdigest()},indent=2))
