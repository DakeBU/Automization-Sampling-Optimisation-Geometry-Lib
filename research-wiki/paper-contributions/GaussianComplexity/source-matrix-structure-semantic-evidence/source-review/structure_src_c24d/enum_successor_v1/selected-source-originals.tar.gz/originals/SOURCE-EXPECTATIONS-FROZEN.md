# Raw-first source freeze — Gaussian centered-matrix structure

Pinned original: `2610.20492v1.html`, SHA-256 `6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915`.

The target is the first statement at C.2 `A3.SS2.p15.1`. The two sequences are `(Z_i)_i` and `(cos(n theta_i) Z_i)_i`. Each sequence is internally independent, centered, and self-adjoint. The source does not claim joint independence of the combined family.

For natural `q >= 0`, `2q+1 < d`, set `r=q+1`, `n=2q+1`, `theta_i=(i-1/2)pi/d`, `t_i=(1,sqrt(2)cos theta_i,...,sqrt(2)cos(q theta_i))`, and independent `gamma_i ~ N(0,I_r)`. The exact cutoff is `L=2r+3 log(1000d)` and

`Y_i=(1/d)(gamma_i gamma_i^T tensor t_i t_i^T) 1_{||gamma_i||^2 <= L}`,

`Z_i=Y_i-E[Y_i]`.

The expectation is the actual finite-matrix Gaussian integral. The radial formula `E[Y_i]=(a/d)(I_r tensor t_i t_i^T)` is an identity requiring proof if used, not a definition that may replace the expectation without that identity. Measurability, integrability, and expectation linearity are proof obligations to discharge for the actual experiment. The meaning is standard finite real matrices, standard product Borel structure and the genuine finite-dimensional integral, whose entries equal scalar expectations. A custom carrier/measure structure or totalized-zero center cannot establish that meaning by name alone.

`q=0` is covered. Cosine weights may be zero or negative; independence survives deterministic maps without invertibility. The source defines both sequences from the same Gaussian rows. Self-adjointness is pointwise symmetry of real matrices, and consequently also almost sure symmetry. No extra positive-q, positive/nonzero-weight, covariance, independence, centering, or self-adjointness hypothesis may replace the derivation.

The source-only proof dependencies and exhaustive bounded coverage decisions are in `SOURCE-EXPECTATIONS-FROZEN.json`. Bernstein, variance/norm bounds, Gram concentration, truncation bias probabilities, range/Krylov identities, and the final Lemma 4.4 estimate receive no completion credit from this structure review.

No candidate code, statement seal, prior review contents, graph or compiler verdict has been read. An initial broad filename-only discovery emitted names of old artifacts; the full replay and disclosure are preserved. Candidate proof correctness, source fidelity, native/build status and normal verification remain unreviewed. The next phase requires exact immutable final candidate modules and necessary parent definitions, followed by separate fresh anti-anchored P/T packets.
