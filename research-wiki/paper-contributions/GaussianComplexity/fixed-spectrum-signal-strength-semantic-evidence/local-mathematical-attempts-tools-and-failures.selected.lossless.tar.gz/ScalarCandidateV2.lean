import AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumBias
import AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumModeGap

noncomputable section

private theorem spectral_tail_le_third {κ : ℝ} (hκ : 2 ≤ κ)
    (d : ℕ) (hd : Real.sqrt κ ≤ (d : ℝ)) :
    let r : ℝ := (Real.sqrt κ - 1) / (Real.sqrt κ + 1)
    0 ≤ r ∧ r ^ (2 * d) ≤ (1 : ℝ) / 3 := by
  let s : ℝ := Real.sqrt κ
  let r : ℝ := (s - 1) / (s + 1)
  change 0 ≤ r ∧ r ^ (2 * d) ≤ (1 : ℝ) / 3
  have hs : 0 < s := Real.sqrt_pos.2 (by linarith)
  have hs1 : 1 ≤ s := Real.le_sqrt_of_sq_le (by nlinarith)
  have hr0 : 0 ≤ r := div_nonneg (by linarith) (by linarith)
  have hrlin : r ≤ 1 - 1 / s := by
    calc
      _ ≤ (s - 1) / s := div_le_div_of_nonneg_left (by linarith) hs (by linarith)
      _ = _ := by field_simp
  have hrexp : r ≤ Real.exp (-(1 / s)) := by
    have h := Real.add_one_le_exp (-(1 / s))
    linarith
  have hp := pow_le_pow_left₀ hr0 hrexp (2 * d)
  have hexponent : ((2 * d : ℕ) : ℝ) * (-(1 / s)) ≤ (-2 : ℝ) := by
    have hds : s ≤ (d : ℝ) := hd
    have hcast : ((2 * d : ℕ) : ℝ) = 2 * (d : ℝ) := by push_cast; rfl
    rw [hcast]
    have hdiv : (2 : ℝ) ≤ 2 * (d : ℝ) / s := by
      apply (le_div_iff₀ hs).2
      nlinarith
    calc
      _ = -(2 * (d : ℝ) / s) := by ring
      _ ≤ -2 := neg_le_neg hdiv
  have hexp3 : (3 : ℝ) ≤ Real.exp 2 := by
    have h := Real.add_one_le_exp (2 : ℝ)
    norm_num at h
    exact h
  have hexp : Real.exp (-2) ≤ (1 : ℝ) / 3 := by
    rw [Real.exp_neg]
    simpa only [one_div] using
      (inv_le_inv₀ (Real.exp_pos (2 : ℝ)) (by norm_num : (0 : ℝ) < 3)).2 hexp3
  refine ⟨hr0, ?_⟩
  calc
    _ ≤ (Real.exp (-(1 / s))) ^ (2 * d) := hp
    _ = Real.exp (((2 * d : ℕ) : ℝ) * (-(1 / s))) :=
      (Real.exp_nat_mul _ _).symm
    _ ≤ Real.exp (-2) := Real.exp_le_exp.mpr hexponent
    _ ≤ _ := hexp

private theorem source_norm_scale_lower {d : ℕ} (hd : 0 < (d : ℝ))
    {δ κ : ℝ} (hκ0 : 0 < κ) (hκcap : κ ≤ (d : ℝ) ^ (1 - δ)) :
    (d : ℝ) ^ ((1 + δ) / 2) / 2 ≤ (d : ℝ) / (2 * Real.sqrt κ) := by
  have hs : 0 < Real.sqrt κ := Real.sqrt_pos.2 hκ0
  have hroot : Real.sqrt κ ≤ (d : ℝ) ^ ((1 - δ) / 2) := by
    calc
      _ ≤ Real.sqrt ((d : ℝ) ^ (1 - δ)) := Real.sqrt_le_sqrt hκcap
      _ = _ := by
        rw [Real.sqrt_eq_rpow, ← Real.rpow_mul hd.le]
        congr 1
        ring
  apply (le_div_iff₀ (by positivity : 0 < 2 * Real.sqrt κ)).2
  have hmul := mul_le_mul_of_nonneg_left hroot
    (Real.rpow_nonneg hd.le ((1 + δ) / 2))
  have heq : (d : ℝ) ^ ((1 + δ) / 2) * (d : ℝ) ^ ((1 - δ) / 2) = (d : ℝ) := by
    rw [← Real.rpow_add hd, show ((1 + δ) / 2 + (1 - δ) / 2 : ℝ) = 1 by ring,
      Real.rpow_one]
  rw [heq] at hmul
  nlinarith
