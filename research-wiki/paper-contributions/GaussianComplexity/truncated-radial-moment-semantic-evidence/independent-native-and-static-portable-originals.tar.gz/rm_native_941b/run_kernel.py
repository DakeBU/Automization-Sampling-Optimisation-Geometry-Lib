from hashlib import sha256
import json
import os
import sys
import subprocess
import shlex
from pathlib import Path

from native import out, blobs, run, seal_path

seal = json.loads((blobs / seal_path).read_text())
formation = ['import Lean', 'import Tests.GaussianComplexityFixedSpectrumTruncatedRadialMoment', '', 'open MeasureTheory ProbabilityTheory', '']
for key, local in [('producer', 'sealedProducer'), ('actual_private_consumer', 'sealedConsumer')]:
    info = seal[key]
    signature = info['signature']
    assert sha256(signature.encode()).hexdigest() == info['signature_sha256']
    binder, body = signature.split(' :\n', 1)
    formation.append(f'def {local} : Prop :=\n  ∀ {binder},\n{body}\n')
    print(f'{local} exact literal signature SHA256 {info["signature_sha256"]}', flush=True)

attempt = sys.argv[1]
source = out / f'Kernel_{attempt}.lean'
tail = out / 'KernelTail.lean.txt'
source.write_text('\n'.join(formation) + '\n' + tail.read_text())
manifest = json.loads((out / 'native-manifest.json').read_text())
env = {key: val for key, val in os.environ.items() if not key.startswith(('LEAN', 'LAKE', 'ELAN', 'DYLD'))}
env['LEAN_PATH'] = manifest['lean_path']
print(f"LEAN_PATH={env['LEAN_PATH']}", flush=True)
args = [manifest['lean'], '-o', str(out / f'Kernel_{attempt}.olean'), source.name]
print(shlex.join(args), f'[cwd={out}]', flush=True)
process = subprocess.run(args, cwd=out, env=env)
print(f'exit={process.returncode}', flush=True)
process.check_returncode()
