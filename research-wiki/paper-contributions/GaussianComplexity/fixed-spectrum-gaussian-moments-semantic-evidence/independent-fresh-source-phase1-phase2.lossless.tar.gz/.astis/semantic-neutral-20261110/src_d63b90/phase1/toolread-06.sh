cat .agents/skills/astis-semantic-roundtrip/SKILL.md
