from pathlib import Path
import json,hashlib,datetime,subprocess,sys
sys.path.insert(0,'tools')
import astis_site
sha=lambda raw:hashlib.sha256(raw).hexdigest()
b=Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-normalizer-integration-20261108')
p=b/'postcore-protection-context.json';assert sha(p.read_bytes())=='e465a1dfbb81380c9481bfb1b88b5f8d45d0e91e9b3446be4a1aea526f844316'
a=json.loads(p.read_bytes());head=subprocess.check_output(['git','rev-parse','HEAD']).decode().strip()
assert head==a['accepted_immutable_core']=='c8c157a69aaad4007cb801a781e980a27005bb02'
def ref(path):
 path=Path(path);return {'path':str(path),'sha256':sha(path.read_bytes())}
gate=Path('.astis/site-lean-gate.json');site=Path('_site/data/build-metadata.json')
g=json.loads(gate.read_bytes());m=json.loads(site.read_bytes())
assert g['passed'] and m['gate']['passed'] and m['gate']['current']
assert g['commit']==m['git']['commit']==head
assert g['source_digest']==m['source_digest']==astis_site.source_digest()==a['source_digest']
labels={'canonical_lean':'fixed-spectrum-normalizer-canonical-lean',
 'site_build':'fixed-spectrum-normalizer-site-build','site_check':'fixed-spectrum-normalizer-site-check',
 'graph_check':'fixed-spectrum-normalizer-graph-check','publication':'fixed-spectrum-normalizer-core-publication',
 'contributor':'fixed-spectrum-normalizer-core-contributor','semantic':'fixed-spectrum-normalizer-core-semantic',
 'frontier':'fixed-spectrum-normalizer-core-frontier'}
checks={}
for role,label in labels.items():
 rows=sorted(Path('.astis/huanjian-resume-20261103').glob('*-'+label+'.receipt.json'))
 assert len(rows)==1,(role,len(rows));r=json.loads(rows[0].read_bytes())
 assert r['exit_code']==0 and r['head_before']==r['head_after']==head
 assert sha(Path(r['log']).read_bytes())==r['log_sha256']
 checks[role]=ref(rows[0])
a.update({'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'actual_gate':ref(gate),'site_metadata':ref(site),'actual_checks_before_browser':checks,
 'scope':'Actual immutable-core official Lean, publication/contributor/semantic/frontier, site build/check and graph check completed. Authorizes unchanged frozen v2 browser via v3 proposal-binding overlay to inspect local site. No independent image acceptance, parking or new source verdict.'})
out=b/'actual-gates-browser-context.json';assert not out.exists();out.write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'path':str(out),'sha256':sha(out.read_bytes()),'core':head,'source_digest':a['source_digest'],
 'actual_gate_sha256':a['actual_gate']['sha256'],'site_metadata_sha256':a['site_metadata']['sha256'],'actual_completed_checks':len(checks)}))
