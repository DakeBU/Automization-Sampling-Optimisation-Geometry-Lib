from pathlib import Path
import datetime, difflib, gzip, hashlib, json, subprocess
sha = lambda b: hashlib.sha256(b).hexdigest()
R = Path('.astis/huanjian-gc-fixed-spectrum-first-order-integration-20261108')
P = R/'graph-selection-repair-v1'; assert not P.exists(); P.mkdir()
js = Path('website/static/underlying-lean-graph.js'); before = js.read_bytes()
needle = b'    if (window.MathJax?.typesetPromise) window.MathJax.typesetPromise([detail]).catch(()=>{}); render();\n'
assert before.count(needle) == 1
after = before.replace(needle,needle +
    b'    // Expanding a searched branch changes node positions; frame the new selection.\n'
    b'    if (state.query) fit({readable:true});\n',1)
assert subprocess.check_output(['git','show','87ecd4d421de0146a062435f63e9dcb1f815c807:'+str(js)]) == before
for name, raw in [('before.raw.js.gz',before),('planned-after.raw.js.gz',after)]:
    p = P/name; p.write_bytes(gzip.compress(raw,mtime=0)); assert gzip.decompress(p.read_bytes()) == raw
(P/'underlying-lean-graph.planned-after.js').write_bytes(after)
diff = ''.join(difflib.unified_diff(before.decode().splitlines(True),after.decode().splitlines(True),fromfile='a/'+str(js),tofile='b/'+str(js)))
(P/'exact-UI-repair.diff').write_text(diff)
original_dir = R/'independent-reader/browser/live-20261108T151138243939Z'
root_files = ['actual-1440-first.png','actual-390-first.png','actual-390-assumptions.png',
    'actual-390-proof-step4.png','actual-1440-proof-step4.png','actual-390-exact-proof.png',
    'actual-390-source-index-open.png','actual-390-graph-focused.png','existing-conceptual-390-typed-supplement.png',
    'actual-1440-exact-proof.png','actual-390-module.png','actual-390-proof-step6.png','actual-390-graph-module-native-click.png']
journal = R/'root-original13-review-v3.json'
assert not journal.exists()
journal.write_text(json.dumps({'reviewed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'reviewer':'/root','core':'87ecd4d421de0146a062435f63e9dcb1f815c807',
    'browser_report_sha256':sha((original_dir/'report.json').read_bytes()),
    'actual_originals_opened_with_view_image_original':[
        {'file':n,'sha256':sha((original_dir/n).read_bytes()),'viewed_original':True} for n in root_files],
    'status':'HOLD','blocking_image':'actual-390-graph-module-native-click.png',
    'finding':'Root independently opened the native module-click frame and confirms selected module card is almost fully outside the mobile SVG right edge. Other reviewed main formulas render correctly, initial disclosures are folded, source index and module source are accessible. Long equations advertise local horizontal scrolling; screenshots are viewport-only and do not prove full long content visible in one frame.',
    'not_claimed':'Root has not opened the other25 originals, and this journal is not independent source V or local acceptance.'},ensure_ascii=False,indent=2)+'\n')
report = {'state':'PROPOSED_NOT_APPLIED_NOT_VERIFIED','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'held_core':'87ecd4d421de0146a062435f63e9dcb1f815c807',
    'held_browser_report_sha256':'5468e1cebe2d8af0086375ea803bdcb28fe30ef461607322c71e172c4d98ec38',
    'independent_pixel_HOLD_sha256':'3f2c3abcdb4172fe9074f0877c809820574aa97ad7bc11d5d7999c2e53764ccc',
    'held_original':{'path':str(original_dir/'actual-390-graph-module-native-click.png'),
        'sha256':sha((original_dir/'actual-390-graph-module-native-click.png').read_bytes())},
    'path':str(js),'before_sha256':sha(before),'planned_after_sha256':sha(after),
    'before_archive':{'path':str(P/'before.raw.js.gz'),'sha256':sha((P/'before.raw.js.gz').read_bytes())},
    'after_archive':{'path':str(P/'planned-after.raw.js.gz'),'sha256':sha((P/'planned-after.raw.js.gz').read_bytes())},
    'diff':{'path':str(P/'exact-UI-repair.diff'),'sha256':sha((P/'exact-UI-repair.diff').read_bytes())},
    'diagnosis':'selectNode re-renders a changed searched branch but retains the previous layout camera. Initial deep links/resize call readable fit; native selection did not. There is no pending recenter animation to await in that path.',
    'change':'After rendering a searched selection, synchronously reuse existing fit({readable:true}) for the new selected node. Non-query views, explicit Fit, graph topology, identities, statuses, source/scanner edge semantics, zoom/pan controls and data remain unchanged.',
    'source_Lean_manifest_publication_audit_ledger_frontier_unchanged':True,
    'new_source_verdict_or_lifecycle_API':False,
    'required_review':'Independent exact JS diff/behavior review and separate stronger v4 browser checker; actual selected rectangle fully inside canvas after native module/parent clicks at both widths, not image counts. Explicit one-path protected-baseline exception only.',
    'future_acceptance':'New immutable core and ALL real same-core gates, new scoped OS permission and actual original review. Original v3 PASS report/38PNG/pixelHOLD remain immutable. No park or local acceptance yet.'}
(P/'proposal-report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
assert js.read_bytes() == before
print(json.dumps({'proposal':str(P/'proposal-report.json'),'sha256':sha((P/'proposal-report.json').read_bytes()),
                  'before':sha(before),'after':sha(after),'tracked_UI_not_applied':True}))
