(()=>({viewport:{width:innerWidth,height:innerHeight},
 html:{clientWidth:document.documentElement.clientWidth,scrollWidth:document.documentElement.scrollWidth,offsetWidth:document.documentElement.offsetWidth},
 body:{clientWidth:document.body.clientWidth,scrollWidth:document.body.scrollWidth,offsetWidth:document.body.offsetWidth},
 windowScroll:{x:scrollX,y:scrollY},
 openDisclosures:[...document.querySelectorAll('article.proof-reader details')].map((e,i)=>({index:i,open:e.open,summary:e.querySelector(':scope>summary').textContent.trim()}))}));
(()=>{
 const viewport={width:innerWidth,height:innerHeight};
 const rect=r=>({left:r.left,right:r.right,top:r.top,bottom:r.bottom,width:r.width,height:r.height});
 const path=e=>{const a=[];for(let p=e;p&&p.nodeType===1;p=p.parentElement){let s=p.tagName.toLowerCase();
   if(p.id){a.unshift(s+'#'+p.id);break;}const ps=p.parentElement?[...p.parentElement.children].filter(x=>x.tagName===p.tagName):[];
   if(ps.length>1)s+=':nth-of-type('+(ps.indexOf(p)+1)+')';a.unshift(s);}return a.join(' > ');};
 const props=['display','position','width','min-width','max-width','height','box-sizing','overflow','overflow-x','overflow-y',
   'white-space','overflow-wrap','word-break','padding-left','padding-right','margin-left','margin-right','border-left-width',
   'border-right-width','font-size','line-height','contain','transform','grid-template-columns','flex','flex-shrink'];
 const computed=e=>{const s=getComputedStyle(e);return Object.fromEntries(props.map(p=>[p,s.getPropertyValue(p)]));};
 const basic=e=>({path:path(e),tag:e.tagName,id:e.id,className:typeof e.className==='string'?e.className:e.className.baseVal,
   rect:rect(e.getBoundingClientRect()),clientWidth:e.clientWidth,scrollWidth:e.scrollWidth,offsetWidth:e.offsetWidth,
   computed:computed(e),scroll:{left:e.scrollLeft,top:e.scrollTop}});
 const ancestry=e=>{const out=[];for(let p=e.parentElement;p;p=p.parentElement)out.push(basic(p));return out;};
 const clipBeforeBody=(e,r)=>{let left=r.left,right=r.right;const clips=[];
   for(let p=e.parentElement;p&&p!==document.body&&p!==document.documentElement;p=p.parentElement){
    const s=getComputedStyle(p);if(['auto','scroll','hidden','clip'].includes(s.overflowX)){
      const q=p.getBoundingClientRect();left=Math.max(left,q.left+p.clientLeft);right=Math.min(right,q.left+p.clientLeft+p.clientWidth);
      clips.push({path:path(p),overflowX:s.overflowX,left:q.left+p.clientLeft,right:q.left+p.clientLeft+p.clientWidth});}}
   return{left,right,width:Math.max(0,right-left),clips};};
 const pseudo=(e,which)=>{const s=getComputedStyle(e,which);return{which,content:s.content,display:s.display,width:s.width,
  position:s.position,left:s.left,right:s.right,whiteSpace:s.whiteSpace,transform:s.transform};};
 const matched=e=>{const out=[];const walk=(rules,href,conditions=[],active=true)=>{for(const rule of rules){
   if(rule.selectorText){try{if(e.matches(rule.selectorText)){
    const relevant=props.filter(p=>rule.style.getPropertyValue(p)).map(p=>[p,rule.style.getPropertyValue(p),rule.style.getPropertyPriority(p)]);
    if(relevant.length)out.push({href,conditions,active,selector:rule.selectorText,properties:relevant});}}catch(_){}}
   if(rule.styleSheet){try{walk(rule.styleSheet.cssRules,rule.styleSheet.href,conditions,active);}catch(ex){out.push({href:rule.href,error:String(ex)});}}
   if(rule.cssRules){let conditionActive=true;
    if(rule.constructor.name==='CSSMediaRule')conditionActive=matchMedia(rule.conditionText).matches;
    if(rule.constructor.name==='CSSSupportsRule')conditionActive=CSS.supports(rule.conditionText);
    walk(rule.cssRules,href,[...conditions,{condition:rule.conditionText||rule.name||rule.constructor.name,active:conditionActive}],active&&conditionActive);}}};
   for(const sheet of document.styleSheets){try{walk(sheet.cssRules,sheet.href);}catch(ex){out.push({href:sheet.href,error:String(ex)});}}
   return out;};
 const all=[...document.querySelectorAll('*')],outliers=[],localScrollers=[],documentCandidates=[];
 for(const e of all){const r=e.getBoundingClientRect();if(r.width<=0||r.height<=0)continue;
   if(e.scrollWidth>e.clientWidth+1)localScrollers.push(basic(e));
   if(r.right>viewport.width+1||r.left<-1){const clipped=clipBeforeBody(e,r),b=basic(e);
    outliers.push({...b,bodyContributionClip:clipped});
    if(clipped.width>0&&(clipped.right>viewport.width+1||clipped.left<-1))documentCandidates.push({...b,
      bodyContributionClip:clipped,ancestors:ancestry(e),outerHTML:e.outerHTML.slice(0,1600),
      before:pseudo(e,'::before'),after:pseudo(e,'::after'),matchingLayoutRules:matched(e)});}}
 const textCandidates=[];const walk=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT);
 while(walk.nextNode()){const t=walk.currentNode;if(!t.textContent.trim())continue;const e=t.parentElement;
   if(!e||e.closest('script,style,noscript'))continue;const range=document.createRange();range.selectNodeContents(t);
   for(const rr of range.getClientRects()){if(rr.width<=0||rr.height<=0||!(rr.right>viewport.width+1||rr.left<-1))continue;
    const clipped=clipBeforeBody(e,rr);if(clipped.width>0&&(clipped.right>viewport.width+1||clipped.left<-1))
      textCandidates.push({text:t.textContent,rangeRect:rect(rr),bodyContributionClip:clipped,
        parent:basic(e),ancestors:ancestry(e),matchingParentLayoutRules:matched(e)});}}
 const inlineMath=[...document.querySelectorAll('mjx-container:not([display="true"])')].map(e=>({...basic(e),parentText:e.parentElement.textContent}));
 return{viewport,roots:[basic(document.documentElement),basic(document.body),basic(document.querySelector('main'))],
  windowScroll:{x:scrollX,y:scrollY},allElementCount:all.length,outliers,localScrollers,documentCandidates,textCandidates,inlineMath,
  noProgrammaticScrollStyleTransformAnimationMutation:true};
});
