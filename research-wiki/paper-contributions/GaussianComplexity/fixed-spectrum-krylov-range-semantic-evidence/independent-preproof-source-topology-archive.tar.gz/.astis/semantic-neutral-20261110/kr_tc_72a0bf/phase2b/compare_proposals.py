from pathlib import Path
import json,hashlib,stat,re,datetime
OUT=Path(__file__).parent;ROOT=OUT.parent;sha=lambda b:hashlib.sha256(b).hexdigest()
sg=json.loads((OUT/'author-source-graph.json').read_bytes())
cov=json.loads((OUT/'author-coverage.json').read_bytes())
typed=json.loads((OUT/'author-type-source-overlay.json').read_bytes())
own=json.loads((ROOT/'phase1/source_pins.json').read_bytes());op={x['id']:x for x in own['pins']}
cp={x['id']:x for x in cov['records']}
assert len(cp)==len(cov['records']) and set(cp)==set(op)
pin_errors=[]
for ident,p in op.items():
 c=cp[ident]
 pairs=[(c['tag'],p['tag']), (c['char_span_0based_halfopen'],[p['char_start'],p['char_end_exclusive']]),(c['utf8_span_0based_halfopen'],[p['utf8_byte_start'],p['utf8_byte_end_exclusive']]),(c['lf_lines_1based_inclusive'],[p['line_start_1based'],p['line_end_inclusive_1based']]),(c['sha256_raw_utf8'],p['raw_utf8_sha256'])]
 if p['tag']=='math':pairs.append((c['alttext_dom_attribute'],p['alttext']))
 if any(a!=b for a,b in pairs):pin_errors.append(ident)
assert not pin_errors
nodes={x['id']:x for x in sg['nodes']};assert len(nodes)==len(sg['nodes'])
assert all(c['disposition'] in ['NODE','EXCLUDED'] for c in cov['records'])
assert all(c.get('node_ids') and set(c['node_ids'])<=set(nodes) if c['disposition']=='NODE' else bool(c.get('reason')) for c in cov['records'])
assert all(set(n['source_ids'])<=set(op) for n in nodes.values())
assert all(e['consumer'] in nodes and set(e['parents'])<=set(nodes) and e['operator']=='AND' for e in sg['and_hyperedges'])
edges={}
for e in sg['and_hyperedges']:edges.setdefault(e['consumer'],[]).extend(e['parents'])
def closure(node,trail=()):
 assert node not in trail,('cycle',trail,node)
 found={node}
 for p in edges.get(node,[]):found |= closure(p,trail+(node,))
 return found
focal={n:sorted(closure(n)) for n in ['C5.range','C2.witness','C2.energy-equality','C2.form-equality']}
for n,c in focal.items():assert not set(c)&{'G.rows-law','C6.event','HF.experiment','K.output-context','C5.aggregate','C5.gram-expectation','C5.weighted-expectation'}
source=Path(own['source']).read_bytes();assert sha(source)==own['source_sha256']
for c in cov['anonymous_citations']:
 a,z=c['utf8_span_0based_halfopen'];assert sha(source[a:z])==c['sha256_raw_utf8']
assert len(cov['anonymous_citations'])==3
exact=[]
for name,root in zip(['P','T'],typed['roots']):
 b=(ROOT/'phase2a'/f'{name}.signature.txt').read_bytes()
 assert root['exact_signature'].encode('utf8')==b
 assert root['exact_signature_sha256']==sha(b)
 exact.append({'root':root['root'],'signature_sha256':sha(b),'matches_own_frozen_typed_input':True})
preserved=[]
for stage,h in [('phase1','05c869d5248141c2cab0604796c0b18f5695d11c9fd272265ec6b65cd1f9475a'),('phase2a','ca0f7cb34ebb3296c9bbd2db344b2edb23fb8fab0adca4f0f59ef3da384365e7')]:
 b=(ROOT/f'{stage}.manifest.json').read_bytes();assert sha(b)==h;m=json.loads(b)
 assert all(sha((ROOT/stage/x['path']).read_bytes())==x['sha256'] and stat.S_IMODE((ROOT/stage/x['path']).stat().st_mode)==0o444 for x in m['files'])
 assert stat.S_IMODE((ROOT/stage).stat().st_mode)==0o555
 preserved.append({'stage':stage,'manifest_sha256':h,'all_hashes_and_modes_unchanged':True})
for k,v in [('source-graph-nodes',sg['nodes']),('source-graph-edges',sg['and_hyperedges']),('type-overlay-all',typed)]:
 (OUT/(k+'.derived-reading.json')).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
(OUT/'coverage-all-dispositions.derived-reading.tsv').write_text('source_id\ttag\tdisposition\tnode_ids_or_reason\n'+'\n'.join('\t'.join([c['id'],c['tag'],c['disposition'],','.join(c.get('node_ids',[])) if c['disposition']=='NODE' else c['reason']]) for c in cov['records'])+'\n')
result={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'mechanical_scope':'raw pin/identity/closure bookkeeping only; mathematical judgment is separately authored','all_original_source_ids_matched':len(cp),'math_ids':sum(x['tag']=='math' for x in cov['records']),'table_or_tbody_ids':sum(x['tag'] in ['table','tbody'] for x in cov['records']),'source_pin_errors':pin_errors,'anonymous_citations_exactly_rechecked':3,'unresolved_node_or_source_references':[],'focal_closures':focal,'exact_typed_roots':exact,'earlier_freezes':preserved,'focal_table_inline_math':[cp[x] for x in ['A3.Ex130.m1','A3.Ex130.m2','A3.Ex131.m1','A3.Ex131.m2']]}
(OUT/'mechanical-comparison.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False,indent=2))
