from runner import *
import re
COMMIT='4c3251454100a4591113b16ed119fdf758c876b7'
def readcmd(label,argv,cwd=ROOT):
    p,code=run(label,argv,cwd=cwd);return p.with_suffix('.stdout').read_bytes()
assert readcmd('exact-candidate',['git','rev-parse','HEAD']).decode().strip()==COMMIT
assert 'Lean (version 4.33.0,' in readcmd('exact-toolchain',['lake','env','lean','--version']).decode()
snap=OUT/'snapshot';snap.mkdir(exist_ok=True)
def blob(path):
    p=snap/path;p.parent.mkdir(parents=True,exist_ok=True)
    raw=readcmd('blob-'+path.replace('/','__'),['git','show',COMMIT+':'+path]);p.write_bytes(raw)
    assert (ROOT/path).read_bytes()==raw, 'working source differs: '+path
    return raw
for path in ['AGENTS.md','docs/theorem-publication-protocol.md','docs/proof-digestion-protocol.md','docs/evidence-routed-memory-protocol.md','docs/contributor-codex-contract.md','.agents/skills/astis-substantive-advance/SKILL.md','.agents/skills/astis-semantic-roundtrip/SKILL.md','research-wiki/process-memory.json','lean-toolchain','lake-manifest.json','lakefile.lean','research-wiki/paper-contributions/GaussianComplexity/source-matrix-radius-statement-seal.json']:
    blob(path)
manifest=json.loads((snap/'lake-manifest.json').read_text());assert len(manifest['packages'])==9
packages=[]
for p in manifest['packages']:
    base=ROOT/'.lake/packages'/p['name']
    h=readcmd('package-head-'+p['name'],['git','rev-parse','HEAD'],base).decode().strip()
    status=readcmd('package-status-'+p['name'],['git','status','--porcelain','--untracked-files=no'],base).decode()
    assert h==p['rev'] and not status, p['name']
    packages.append({'name':p['name'],'HEAD':h,'tracked_dirty':bool(status)})
readcmd('lean-help',['lake','env','lean','--help'])
lp=readcmd('original-lean-path',['lake','env','printenv','LEAN_PATH']).decode().strip().split(':')
native=OUT/'native';assert not native.exists();native.mkdir()
paths=[str(native)]+[str((ROOT/x).resolve()) if not x.startswith('/') else x for x in lp if Path(x).resolve()!= (ROOT/'.lake/build/lib/lean').resolve()]
assert not any(str(ROOT/'.lake/build') in x for x in paths)
settings={'commit':COMMIT,'native':str(native),'snapshot':str(snap),'LEAN_PATH':':'.join(paths),'packages':packages}
(OUT/'settings.json').write_text(json.dumps(settings,indent=2)+'\n')
targets=['AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumSourceMatrixRadius','Tests.GaussianComplexityFixedSpectrumSourceMatrixRadius']
seen=set();order=[];imports={}
def visit(mod):
    if mod in seen:return
    seen.add(mod);path=mod.replace('.','/')+'.lean';raw=blob(path)
    # This discovery is checked against lean --deps after building; no import is taken as a theorem edge.
    text=re.sub(r'/\-.*?\-/','',raw.decode(),flags=re.S)
    imps=[]
    for line in text.splitlines():
        if re.match(r'^\s*(public\s+)?import\s',line):
            imps += re.sub(r'^\s*(public\s+)?import\s+','',line).split('--')[0].split()
    imports[mod]=imps
    for x in imps:
        if x=='AutoSamplingTheory' or x.startswith('AutoSamplingTheory.') or x.startswith('Tests.'):visit(x)
    order.append(mod)
for m in targets:visit(m)
settings.update(targets=targets,order=order,imports=imports)
(OUT/'settings.json').write_text(json.dumps(settings,indent=2)+'\n')
(OUT/'snapshot-hashes.json').write_text(json.dumps({str(p.relative_to(snap)):sha(p) for p in sorted(snap.rglob('*')) if p.is_file()},indent=2)+'\n')
print(json.dumps({'closure_size':len(order),'order':order,'packages':packages,'LEAN_PATH':settings['LEAN_PATH']},indent=2))
