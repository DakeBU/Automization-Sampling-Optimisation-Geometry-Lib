from pathlib import Path
from html.parser import HTMLParser
import hashlib, json, re

ROOT = Path(__file__).resolve().parent
SOURCE = Path('/Users/zhouhuanjian/ASTIS-GC/.astis/huanjian-resume-20261103/2610.20492v1.html')
PIN = '6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
raw = SOURCE.read_bytes()
assert hashlib.sha256(raw).hexdigest() == PIN
s = raw.decode('utf-8')

def section(sid):
    start = s.index('<section id="' + sid + '"')
    depth = 0
    for m in re.finditer(r'</?section\b[^>]*>', s[start:]):
        depth += -1 if m.group().startswith('</') else 1
        if depth == 0:
            return start, start + m.end()
    raise ValueError(sid)

class Readable(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.out = []
        self.math_depth = 0
    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if self.math_depth:
            self.math_depth += 1
            return
        if tag == 'math':
            self.math_depth = 1
            self.out.append(' $' + a.get('alttext', '[MISSING ALTTEXT]') + '$ ')
        elif tag in ['p','h1','h2','h3','h4','h5','h6','tr','li']:
            self.out.append('\n')
        elif tag == 'br':
            self.out.append('\n')
    def handle_endtag(self, tag):
        if self.math_depth:
            self.math_depth -= 1
        elif tag in ['p','h1','h2','h3','h4','h5','h6','tr','li']:
            self.out.append('\n')
    def handle_data(self, data):
        if not self.math_depth:
            self.out.append(data)
    def result(self):
        return re.sub(r'\n{3,}', '\n\n', ''.join(self.out)).strip() + '\n'

manifest = {'source': str(SOURCE), 'source_sha256': PIN, 'offset_convention': 'zero-based UTF-8 byte offsets, half-open [start,end)', 'slices': []}
citations = set()
for sid in ['S2','S4','A3.SS3']:
    a,b = section(sid)
    piece = s[a:b]
    for c in re.findall(r'<cite\b[^>]*>.*?</cite>',piece,re.S):
        citations.update(re.findall(r'href="[^"]*#([^"]+)"',c))
    filename = sid + '.raw.html'
    payload = piece.encode('utf-8')
    (ROOT / filename).write_bytes(payload)
    t = Readable(); t.feed(piece)
    (ROOT / (sid + '.readable.txt')).write_text(t.result())
    manifest['slices'].append({'id':sid,'file':filename,'byte_start':len(s[:a].encode()),'byte_end':len(s[:b].encode()),'sha256':hashlib.sha256(payload).hexdigest(),'bytes':len(payload)})
for bid in sorted(citations):
    match = re.search(r'<li\b[^>]*\bid="' + re.escape(bid) + r'"[^>]*>',s)
    assert match, bid
    a = match.start(); b = s.index('</li>', a) + len('</li>')
    piece = s[a:b]; payload=piece.encode('utf-8'); filename=bid+'.raw.html'
    (ROOT / filename).write_bytes(payload)
    t=Readable();t.feed(piece)
    (ROOT / (bid+'.readable.txt')).write_text(t.result())
    manifest['slices'].append({'id':bid,'file':filename,'byte_start':len(s[:a].encode()),'byte_end':len(s[:b].encode()),'sha256':hashlib.sha256(payload).hexdigest(),'bytes':len(payload)})
manifest['genuine_in_scope_bibliography_ids']=sorted(citations)
(ROOT/'raw_slice_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(manifest,indent=2))
