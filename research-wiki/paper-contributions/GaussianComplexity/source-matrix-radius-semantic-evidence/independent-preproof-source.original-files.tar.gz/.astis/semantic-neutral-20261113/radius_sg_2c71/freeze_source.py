"""Source-only packet builder. No Lean, seal, proof implementation or API reads."""
from pathlib import Path
from html.parser import HTMLParser
from hashlib import sha256
import json, re, datetime

R = Path(__file__).parent
S = (R / 'originals/2610.20492v1.html').read_bytes().decode('utf-8')
IDX = json.loads((R / 'source-element-index.json').read_text())

def dump(name, value):
    with (R / name).open('x') as f:
        json.dump(value, f, ensure_ascii=False, indent=2)
        f.write('\n')

class Text(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.parts, self.math = [], 0
    def handle_starttag(self, t, attrs):
        a = dict(attrs)
        if t == 'math':
            self.math += 1
            self.parts.append('$' + a.get('alttext', '') + '$')
        elif not self.math and t in ['p', 'div', 'tr', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6']:
            self.parts.append('\n')
    def handle_endtag(self, t):
        if t == 'math': self.math -= 1
        elif not self.math and t in ['p', 'div', 'tr', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6']:
            self.parts.append('\n')
    def handle_data(self, d):
        if not self.math: self.parts.append(d)

def locator(key):
    x = dict(IDX[key]); a, b = x['char']; raw = S[a:b].encode()
    x.update(raw_utf8_byte=[len(S[:a].encode()), len(S[:b].encode())],
             LF_line=[S.count('\n',0,a)+1, S.count('\n',0,b)+1],
             sha256=sha256(raw).hexdigest(), original_path='raw-units/'+key+'.html')
    p = R / x['original_path']
    if p.exists(): assert p.read_bytes() == raw
    else: p.write_bytes(raw)
    t = Text(); t.feed(raw.decode())
    plain = '\n'.join(re.sub(r'\s+', ' ', v).strip() for v in ''.join(t.parts).split('\n'))
    plain = re.sub('\n{3,}', '\n\n', plain).strip()+'\n'
    x['derived_path_v2'] = 'raw-units/'+key+'.v2.txt'
    (R/x['derived_path_v2']).write_text(plain)
    return x

lo, hi = IDX['A3.SS2']['char']
units = [x for x in IDX.values() if lo <= x['char'][0] < x['char'][1] <= hi and x['tag'] in ['p','table']]
extra = ['A3.SS2','A3.Thmtheorem5','A3.Thmtheorem6','S4.SS1.p1','S4.SS2.SSS0.Px1.p2','S4.Thmtheorem4']
keys = sorted(set([x['id'] for x in units]+extra+[
    'A3.SS2.p1.1','A3.SS2.p1.2','A3.SS2.p4.1','A3.SS2.p8','A3.SS2.p10.1',
    'A3.SS2.p12.3','A3.SS2.p12.m3','A3.SS2.p12.m4','A3.SS2.p12.m5',
    'A3.SS2.p13.m1','A3.SS2.p13.m2','A3.SS2.p13.2','A3.SS2.p13.3',
    'A3.SS2.p13.m4','S4.Thmtheorem4.p1.m2','S4.Thmtheorem4.p1.m3',
    'S4.Thmtheorem4.p1.m4','S4.Thmtheorem4.p1.m5','S4.E11']), key=lambda k: IDX[k]['char'][0])
locs = {k: locator(k) for k in keys}
dump('source-unit-locators-v2.json', {'source_sha256':sha256(S.encode()).hexdigest(),
    'coordinates':'0-based half-open Unicode-code-point chars and raw UTF8 bytes; 1-based LF lines, end line inclusive',
    'units':list(locs.values()), 'v1_preserved':True,
    'derived_text_correction':'v1 regex stripped text containing a less-than sign in substituted alttext, notably Lemma 4.4. v2 uses HTMLParser with MathML nesting suppression. Raw originals and locators unchanged.'})

N = []
def node(id, kind, statement, anchors, note=''):
    N.append(dict(id=id,kind=kind,statement=statement,anchors=[locs[a] for a in anchors],note=note))
node('src.assumptions','source-premise','q is a nonnegative integer, 2q+1<d; the q+1 original d-dimensional g vectors are independent standard Gaussians.', ['S4.Thmtheorem4.p1.m2','S4.Thmtheorem4.p1.m3','S4.Thmtheorem4.p1.m4','S4.Thmtheorem4.p1.m5'])
node('src.params','source-definition','r=q+1, n=2q+1, 1<=i<=d.', ['A3.SS2.p1.1'])
node('src.theta','source-definition','theta_i=(i-1/2)pi/d, the half grid.', ['S4.E11','A3.SS2.p4.1'], 'Only theta from the spectral-grid display is required; lambda, kappa, Haar O and A are excluded.')
node('src.row','source-definition-and-law','t_i=(1,sqrt(2)cos theta_i,...,sqrt(2)cos(q theta_i)); gamma_i=((g_1)_i,...,(g_r)_i); gamma_i has N(0,I_r) law.', ['A3.Ex85','A3.SS2.p1.2'], 'Independence is source context but not needed for a single-row norm bound; B definition is excluded.')
node('src.t.bound','unnamed-estimate','||t_i||^2=1+2 sum_(j=1)^q cos^2(j theta_i)<=1+2q<=2r.', ['A3.Ex87','A3.Ex102'], 'Only first component of Ex87 is in this packet; the two matrix sum identities are excluded.')
node('src.cutoff','source-definition','L=2r+3 log(1000d), R_i=||gamma_i||^2.', ['A3.SS2.p10.1'], 'MGF, Markov and tail/event estimates in the same paragraph are excluded.')
node('src.Y','source-definition','Y_i=d^-1 (gamma_i gamma_i^T tensor t_i t_i^T) 1_{R_i<=L}.', ['A3.Ex107'], 'Closed cutoff, actual original Gaussian rows, r^2 by r^2 real matrix.')
node('src.radial.mean','internal-paper-step','E[gamma_i gamma_i^T 1_{R_i<=L}]=a I_r; a=r^-1 E[R_i 1_{R_i<=L}].', ['A3.Ex108'], 'Source radial-symmetry route; derivation details are visible in gap.radial below, not added as public assumptions.')
node('src.a.range','unnamed-estimate','E[R_i]=r and 0<=a<=1.', ['A3.SS2.p12.m3','A3.SS2.p12.m4'], 'Uses nonnegative truncated R dominated by R. No tail-probability estimate is required.')
node('src.Y.mean','internal-paper-step','E[Y_i]=(a/d)(I_r tensor t_i t_i^T).', ['A3.SS2.p12.m5'])
node('src.Z','source-definition','Z_i=Y_i-E[Y_i].', ['A3.SS2.p13.m1'])
node('src.Y.norm','unnamed-estimate','||Y_i||op=(R_i ||t_i||^2/d)1_{R_i<=L}<=2rL/d.', ['A3.Ex111'], 'Left component of the display; all outcomes, not only the truncation event.')
node('src.Ymean.norm','unnamed-estimate','||E[Y_i]||op=a ||t_i||^2/d<=2r/d.', ['A3.Ex111'], 'Right component of the display; this is the actual mean under the original Gaussian law.')
node('src.radius','source-anchor','||Z_i||op<=2r(L+1)/d=:R_*.', ['A3.Ex112'])
node('src.cos.abs','standard-input','|cos(n theta_i)|<=1.', ['A3.SS2.p13.m4'])
node('src.weighted.radius','source-anchor','||cos(n theta_i) Z_i||op<=R_*.', ['A3.SS2.p13.3'])
node('gap.rankone.tensor','SOURCE_GAP','Omitted standard derivation of operator norms of rank-one outer products, their tensor product, and I_r tensor (t_i t_i^T).', ['A3.Ex111'], 'omitted-derivation, not a demonstrated false source statement or extra source premise; source gives the equalities explicitly.')
node('gap.radial','SOURCE_GAP','Omitted details behind "By radial symmetry": matrix-entry integrability and symmetry, equal diagonal moments, trace/radial scalar formula.', ['A3.Ex108'], 'omitted-derivation, not source invalidity. Gaussian law plus finite moments supply internal obligations; no API availability claim.')
node('gap.expectation.transport','SOURCE_GAP','Omitted linearity/fixed-tensor transport from the radial mean to the actual Y mean, including the required integration applicability.', ['A3.SS2.p12.m5'], 'omitted-derivation; measurability/integrability remain internal edges.')
node('gap.triangle','SOURCE_GAP','Omitted norm triangle/subtraction and scalar arithmetic combining the two component bounds.', ['A3.SS2.p13.2','A3.Ex112'], 'The source says Hence; this is a source proof bridge, not a target hypothesis.')
node('gap.scalar.norm','SOURCE_GAP','Omitted scalar-homogeneity of the real operator norm for cosine times Z_i.', ['A3.SS2.p13.3'], 'omitted-derivation, not an extra premise.')

E=[]
def edge(a,b,site,usage): E.append(dict(prerequisite=a,consumer=b,consumer_use_site=locs[site],usage=usage,semantics='source dependency overlay; not compiler-backed'))
for a,b,site,use in [
('src.params','src.row','A3.Ex85','r determines gamma/t dimensions'),('src.theta','src.row','A3.Ex85','half-grid angles in deterministic t'),
('src.assumptions','src.row','A3.SS2.p1.2','original g law induces each gamma standard law'),
('src.row','src.t.bound','A3.Ex102','substitute deterministic cosine coordinates'),
('src.params','src.cutoff','A3.SS2.p10.1','r in L'),('src.row','src.cutoff','A3.SS2.p10.1','R is row squared norm'),
('src.cutoff','src.Y','A3.Ex107','same closed radial cutoff'),('src.row','src.Y','A3.Ex107','original gamma and deterministic t outer/tensor'),
('src.row','src.radial.mean','A3.Ex108','standard row law and radial cutoff'),('src.cutoff','src.radial.mean','A3.Ex108','radial threshold and R'),('gap.radial','src.radial.mean','A3.Ex108','symmetry, trace and integrability bridge'),
('src.radial.mean','src.a.range','A3.SS2.p12.m4','a from nonnegative cutoff moment'),('src.row','src.a.range','A3.SS2.p12.m3','Gaussian second moment E R = r'),
('src.Y','src.Y.mean','A3.SS2.p12.m5','Y literal formula'),('src.radial.mean','src.Y.mean','A3.SS2.p12.m5','insert radial truncated mean'),('gap.expectation.transport','src.Y.mean','A3.SS2.p12.m5','fixed tensor/scale integral applicability'),
('src.Y','src.Y.norm','A3.Ex111','actual Y and indicator'),('src.t.bound','src.Y.norm','A3.Ex111','uses ||t||^2<=2r'),('src.cutoff','src.Y.norm','A3.Ex111','R<=L on retained outcomes; nonnegative L off cutoff'),('gap.rankone.tensor','src.Y.norm','A3.Ex111','operator-norm equality'),
('src.Y.mean','src.Ymean.norm','A3.Ex111','actual mean equality'),('src.a.range','src.Ymean.norm','A3.Ex111','0<=a<=1'),('src.t.bound','src.Ymean.norm','A3.Ex111','deterministic norm bound'),('gap.rankone.tensor','src.Ymean.norm','A3.Ex111','norm of identity tensor rank-one'),
('src.Y','src.Z','A3.SS2.p13.m1','Y in centering'),('src.Y.mean','src.Z','A3.SS2.p13.m1','actual expectation in centering'),
('src.Z','src.radius','A3.Ex112','centered literal summand'),('src.Y.norm','src.radius','A3.Ex112','first triangle term'),('src.Ymean.norm','src.radius','A3.Ex112','second triangle term'),('gap.triangle','src.radius','A3.Ex112','sum of component bounds equals R_*'),
('src.radius','src.weighted.radius','A3.SS2.p13.3','unweighted radius'),('src.cos.abs','src.weighted.radius','A3.SS2.p13.3','contraction coefficient'),('gap.scalar.norm','src.weighted.radius','A3.SS2.p13.3','operator norm scalar homogeneity')]:edge(a,b,site,use)

coverage=[]
def disp(k):
    if k in ['A3.SS2.p1.1','A3.Ex85']: return ['src.params','src.row'], 'The source definitions needed by actual Y.'
    if k=='A3.SS2.p1.2': return ['src.row'], 'Gaussian row law; B clause separately excluded as downstream context.'
    if k=='A3.Ex87': return ['src.t.bound'], 'Only ||t_i||^2<=2r; unweighted/weighted sum identities excluded, not radius prerequisites.'
    if k=='A3.SS2.p4.1': return ['src.theta'], 'Only recalled theta definition; cosine cancellation proof in the rest is excluded.'
    if k in ['A3.SS2.p8.1','A3.Ex102']: return ['src.t.bound'], 'Pointwise t bound is used explicitly in p13.'
    if k=='A3.SS2.p10.1': return ['src.cutoff'], 'Only L and R definitions; exponential moment, Markov tail and log constant estimate excluded.'
    if k in ['A3.SS2.p12.1','A3.Ex107']: return ['src.Y'], 'Actual truncated summand definition. Independence assertion retained as context only.'
    if k in ['A3.SS2.p12.2','A3.Ex108']: return ['src.radial.mean','gap.radial'], 'Source radial route for the actual mean.'
    if k=='A3.SS2.p12.3': return ['src.a.range'], 'Same a and E R=r; 0<=a<=1 is required. Bias estimate Ex109 excluded.'
    if k=='A3.SS2.p12.4': return ['src.Y.mean','gap.expectation.transport'], 'Only actual mean formula; subsequent invocation of Fact C.5 for sum identities is excluded.'
    if k=='A3.SS2.p13.1': return ['src.Z','src.Y.norm','src.Ymean.norm','gap.rankone.tensor'], 'Centering definition and announced use of t bound.'
    if k=='A3.Ex111': return ['src.Y.norm','src.Ymean.norm','gap.rankone.tensor'], 'Both equality-and-bound components retained.'
    if k in ['A3.SS2.p13.2','A3.Ex112']: return ['src.radius','gap.triangle'], 'Exact centered radius and omitted triangle bridge.'
    if k=='A3.SS2.p13.3': return ['src.weighted.radius','src.cos.abs','gap.scalar.norm'], 'Weighted radius and absolute-cosine contraction.'
    # Explicit reasons cover every substantive paragraph/display in the connected C.2 envelope.
    a,b=IDX[k]['char']
    if IDX['A3.SS2.p14']['char'][0] <= a < IDX['A3.SS2.p15']['char'][0]: return [], 'Separate variance packet: fourth moments, squares, PSD expectation order, v_* and weighted variance are not used to prove radius.'
    if IDX['A3.SS2.p15']['char'][0] <= a < IDX['A3.SS2.p16']['char'][0]: return [], 'Downstream matrix Bernstein application consumes R_* and v_*; concentration/tail theorem excluded from radius output, direct consumer edges retained separately.'
    if IDX['A3.SS2.p16']['char'][0] <= a < IDX['A3.SS2.p17']['char'][0]: return [], 'Downstream z/Delta definitions, expansion, failure budgets and union bound consume R_*; no reverse prerequisite to radius.'
    if IDX['A3.SS2.p17']['char'][0] <= a < IDX['A3.SS2.p18']['char'][0]: return [], 'Downstream agreement on T, expectation/bias recombination, event intersection and Gram concentration; not radius prerequisites.'
    if IDX['A3.SS2.p18']['char'][0] <= a < IDX['A3.SS2.p19']['char'][0]: return [], 'Downstream absolute-constant/O(log d) simplification for tau and Fact C.6; useful dimension observation does not introduce an extra radius binder.'
    if a >= IDX['A3.SS2.p19']['char'][0]: return [], 'Final Lemma 4.4 Krylov-space consumer and quadratic-form estimates; excluded from radius statement/proof.'
    if IDX['A3.SS2.p3']['char'][0] <= a < IDX['A3.SS2.p8']['char'][0]: return [], 'Fact C.5 range, orthogonality or expectation-sum proof; only theta recall and pointwise t bound are required for radius.'
    if k=='A3.Ex109': return [], 'Truncation bias 1-a bound is stronger/different than 0<=a<=1 and used downstream, not needed for radius.'
    if k in ['A3.Ex110','A3.SS2.p12.5']:return [], 'Sum-of-means and weighted zero-mean identities are downstream concentration inputs, not radius inputs.'
    if IDX['A3.SS2.p10']['char'][0] <= a < IDX['A3.SS2.p12']['char'][0]:return [], 'Truncation-event probability and tail/bias calculation are excluded; the definitions L,R are separately retained.'
    if k=='A3.Ex86': return [], 'Fact C.5 range and two Gram expectations are not radius prerequisites.'
    if k=='A3.Ex103' or k.startswith('A3.Thmtheorem6.'): return [], 'Fact C.6 concentration theorem is downstream of radius and separate variance/tail application.'
    return [], 'Strategy/transition narrative or container context; no additional mathematical prerequisite for the bounded p13 radius claim.'
for x in sorted(units,key=lambda x:x['char'][0]):
    ns,reason=disp(x['id']);coverage.append(dict(source_unit=x['id'],locator=locs[x['id']],disposition='NODE' if ns else 'EXCLUDED',nodes=ns,reason=reason))
# All material outside the C.2 envelope that was read for definitions has explicit component scope.
context=[
 dict(unit='S4.SS1.p1',NODE=['src.theta'],EXCLUDED='lambda/kappa/Haar rotation/A/f/pi and citation [22] construction similarity are not used by radius; no bibliography premise is imported.'),
 dict(unit='S4.SS2.SSS0.Px1.p2',EXCLUDED='Krylov space definition is context for Lemma 4.4, not needed to define or bound the p13 matrices.'),
 dict(unit='S4.Thmtheorem4',NODE=['src.assumptions'],EXCLUDED='C, tau, tau<=1/2, 0.99 event and final quadratic-form conclusion are downstream scope; not radius assumptions.'),
 dict(unit='A3.Thmtheorem5',NODE=['src.t.bound'],EXCLUDED='range, E Gram identities, and matrix sum identities excluded except the first norm estimate in Ex87.'),
 dict(unit='A3.Thmtheorem6',EXCLUDED='concentration assertion is downstream; not part of radius output.')]
dump('raw-source-coverage-freeze-v1.json', dict(author='radius_sg_2c71',stage='RAW_SOURCE_FROZEN_BEFORE_SEAL_READ',source_sha256=sha256(S.encode()).hexdigest(),
    scope='Full connected C.2 p1-p19 paragraph/display inventory, plus scoped definitions and standing law from Section 4. Radius claim p13 only.',
    coverage=coverage,context_disposition=context,source_alternative_routes=[],
    no_source_implementation_equivalence_claim=True,independent_topology_review='REQUIRED: extractor cannot approve own topology'))
downstream=[
 dict(from_node='src.radius',to='outside.bernstein.unweighted',site=locator('A3.Ex121'),use='R_* t/3 in Bernstein denominator; other conditional inputs independent/centered/self-adjoint and v_* must be discharged outside this packet.'),
 dict(from_node='src.weighted.radius',to='outside.bernstein.weighted',site=locator('A3.SS2.p15.2'),use='same tail bound for cosine-weighted sum; weighted bound consumed, not reverse dependency.'),
 dict(from_node='src.radius',to='outside.Delta',site=locator('A3.Ex122'),use='2 R_* z/3 in Delta.'),
 dict(from_node='src.radius',to='outside.tail.algebra',site=locator('A3.Ex123'),use='R_* in direct expansion and nonnegative term.'),
 dict(from_node='src.radius',to='outside.tau.simplification',site=locator('A3.EGx12'),use='Substituting R_* gives 4r(L+1)z/(3d); absolute-constant simplification remains outside.')]
dump('source-proof-graph-freeze-v1.json',dict(nodes=N,edges=E,downstream_consumer_edges=downstream,
    route_semantics='One author route: (Y norm AND actual mean norm AND triangle) -> radius; (radius AND |cos|<=1 AND scalar norm) -> weighted radius. No false AND with variance/tail or independent alternative mean route.',
    source_gaps=[n['id'] for n in N if n['kind']=='SOURCE_GAP'],
    source_contract_gap='None established by this source-only reading; omitted derivations are not source-invalid verdicts.',
    status='PROPOSED_SOURCE_TOPOLOGY; independent challenge required; no proof/API/implementation audit performed'))
frozen = ['raw-source-coverage-freeze-v1.json','source-proof-graph-freeze-v1.json','source-unit-locators-v2.json']
dump('raw-freeze-receipt-v1.json',dict(stage='before first sealed-interface file read',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    source_sha256=sha256(S.encode()).hexdigest(),files=[dict(path=p,sha256=sha256((R/p).read_bytes()).hexdigest()) for p in frozen],
    exposures=['parent supplied source/seal hashes, high-level target formulas and binder descriptions before task start; no seed topology supplied',
               'repository instruction/protocol files', 'raw pinned HTML; parser-derived source text and raw HTML windows'],
    not_read=['statement seal contents','producer/consumer Lean','existing implementation, proof search or compiled results','other source graph/reviewer verdicts including R9'],
    extraction_correction_preserved='v1 derived text issue preserved; v2 correct; all raw bytes unchanged'))
print(json.dumps(dict(freeze_files=[dict(path=p,sha256=sha256((R/p).read_bytes()).hexdigest()) for p in frozen],source_units=len(coverage),nodes=len(N),edges=len(E),downstream_edges=len(downstream)),indent=2))
