from pathlib import Path
import json, hashlib, subprocess, datetime
sha = lambda raw: hashlib.sha256(raw).hexdigest()
base = Path('research-wiki/paper-contributions/GaussianComplexity')
ev = base/'fixed-spectrum-normalizer-semantic-evidence'
out = ev/'actual-consumer-interface'
out.mkdir(exist_ok=False)
seal = json.loads((base/'fixed-spectrum-normalizer-statement-seal.json').read_bytes())
head = subprocess.check_output(['git','rev-parse','HEAD']).decode().strip()
assert head == 'da5360ef615a04397fb53bf5c53194cf3ec13b9f'
assert json.loads((ev/'producer-source-admission.json').read_bytes())['overall_implementation_admission'] is False
assert not Path(seal['production_file']).exists() and not Path(seal['real_consumer']['file']).exists()
sig = seal['exact_signature_utf8'].split('  Integrable weight')[0].replace('theorem actual_normalizing_integral','example',1)
sig += ('  ProbabilityTheory.multivariateGaussian (0 : EuclideanSpace ℝ (Fin d)) A⁻¹ =\n'
        '    (volume : Measure (EuclideanSpace ℝ (Fin d))).withDensity (fun x =>\n'
        '      ENNReal.ofReal (weight x /\n'
        '        (∫ y : EuclideanSpace ℝ (Fin d), weight y ∂volume)))\n')
(out/'candidate-exact-signature.txt').write_text(sig)
binders, proposition = sig[len('example '):].split(' :\n',1)
probe = ('import AutoSamplingTheory.TechnicalLemmas.Measure.GaussianPrecisionDensity\n'
         'import Mathlib.LinearAlgebra.UnitaryGroup\n'
         'open Matrix MeasureTheory\nopen scoped BigOperators\n\n'
         '#check (∀ '+binders+',\n'+proposition.rstrip()+')\n')
pp=Path('.astis/huanjian-fixed-spectrum-normalizer-20261108/ConsumerSignatureOnly.lean')
assert not pp.exists()
pp.write_text(probe)
windows = [
 ('canonical-GPD-interface.txt','AutoSamplingTheory/TechnicalLemmas/Measure/GaussianPrecisionDensity.lean',48,53),
 ('actual-Gaussian-constructor.txt','.lake/packages/mathlib/Mathlib/Probability/Distributions/Gaussian/Multivariate.lean',162,171),
 ('withDensity-meaning-and-neighbor-exposure.txt','.lake/packages/mathlib/Mathlib/MeasureTheory/Measure/WithDensity.lean',34,46),
 ('matrix-inverse-meaning-and-neighbor-exposure.txt','.lake/packages/mathlib/Mathlib/LinearAlgebra/Matrix/NonsingularInverse.lean',161,172)]
rows=[]
for name, path, lo, hi in windows:
    p=Path(path);raw=p.read_bytes();clip=b''.join(raw.splitlines(keepends=True)[lo-1:hi]);q=out/name;q.write_bytes(clip)
    rows.append({'source':str(p),'source_sha256':sha(raw),'lines':[lo,hi],
                 'excerpt':str(q),'excerpt_raw_sha256':sha(clip),'raw_bytes':len(clip)})
audit={
 'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'producer_source_admission_commit':head,'consumer_signature_sha256':sha(sig.encode()),
 'definition_kind':'literal', 'binder_audit':[
  {'binder':'d:ℕ','classification':'TYPING','meaning':'Finite dimension, same as producer.'},
  {'binder':'hd:2≤d','classification':'SOURCE','anchor':'S4.SS1.p1'},
  {'binder':'κ:ℝ','classification':'TYPING','meaning':'Source condition parameter.'},
  {'binder':'hκ:2≤κ','classification':'SOURCE','anchor':'S4.SS1.p1'},
  {'binder':'O:orthogonalGroup (Fin d) ℝ','classification':'SOURCE','meaning':'Pointwise full O(d), both signs; no determinant-one or Haar/randomness premise.'}],
 'EXCESS':[], 'literal_lets':'Exactly producer θ/diagonalValue/A/weight, byte-preserved prefix; same A in covariance and weight.',
 'actual_measure':'Mathlib multivariateGaussian 0 A⁻¹ is pushforward of actual standard Gaussian by CFC.sqrt A⁻¹. Invalid covariance fallback is not silently accepted: actual PosDef/inverse covariance validity must follow internally from existing actual_admissible and generic matrix API.',
 'normalization_base':'Actual unnormalized canonical Euclidean Lebesgue volume, unchanged producer meaning/instance. withDensity assigns each measurable set the lintegral of its ENNReal density.',
 'normalizer':'Denominator is the actual Bochner integral of this very weight over volume, not a separately named coefficient/certificate. Its positivity and finiteness must be derived from the new producer output and source spectrum positivity.',
 'totalized_operations':'Real division and ENNReal.ofReal are total operations. The proof must derive strictly positive actual integral and nonnegative density, avoiding zero-denominator or negative-part conventions. Matrix inverse is adjugate times ring inverse determinant; actual PosDef/nonzero det are produced internally.',
 'required_actual_use':'Private Test consumer must actually depend on new actual_normalizing_integral and the identical canonical GaussianPrecisionDensity result. Derive hA from existing actual_precision_admissible, and use actual_precision_det if the exact product coefficient adapter needs it. No supplied PosDef, determinant, integrability, normalization or correct-density certificate.',
 'source_relation':'S2/S4.SS1 actual N(0,Ainv) and actual quadratic potential; C4 Gaussian integration. Exact integral-normalized density is a standard source-implicit elaboration, not verbatim source formula. Only Z is orientation-independent; actual A remains in the target and exponent.',
 'necessary_definition_windows':rows,
 'exposure':'Root inherits prior GPD/admissibility/determinant full-module knowledge from previous packets. Current consumer lookup read GPD 48–53 signature and Gaussian constructor162–171. Meaning windows accidentally include withDensity_apply 44–46 implementation and isUnit_det_transpose161–163 proof/ inv_def172 header; regex discovery also emitted standard one-line withDensity/inverse proof references. No current target integration proof/API retrieval or implementation. Earlier rawsource graph/topology freezes predate this exposure. All windows retained honestly.',
 'other_exposure_discovery_commands':[
  "rg -n '^(def|noncomputable def|irreducible_def) withDensity|^def inv |^noncomputable def inv ' [WithDensity.lean NonsingularInverse.lean] returned no lines (exit1), not a mathematical failure.",
  "Refined definition-discovery regex also emitted standard neighbor instance names and one-line proof references at WithDensity289,547,572 and NonsingularInverse251,263,267; no Gaussian target proof."],
 'proof_or_sourceV':False,'consumer_typecheck':'Pending actual proposition-only elaboration.',
 'truth_boundary':'Actual normalized-law use only; full C4 calculus/minimizer, moments/Krylov, actual algorithms/oracle/precision/TV/deterministic/expected-cost adapters, both main lower bounds, remote/purification/Seal/Goal remain open.'}
(out/'interface-audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'producer_source_admission_commit':head,'consumer_signature_sha256':sha(sig.encode()),
                  'probe':str(pp),'definition_windows':len(rows),'proof_started':False}))
