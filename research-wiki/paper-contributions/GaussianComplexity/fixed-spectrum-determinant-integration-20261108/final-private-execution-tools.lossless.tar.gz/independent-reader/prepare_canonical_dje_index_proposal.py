"""Exact conditional two-path compilation-only index proposal; no shared writes."""
from pathlib import Path
import copy, datetime, difflib, gzip, hashlib, json, subprocess, sys
sys.dont_write_bytecode=True
R=Path('/Users/zhouhuanjian/ASTIS-GC');S=R/'.astis/huanjian-gc-fixed-spectrum-determinant-integration-20261108/independent-reader'
P=R/'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-determinant-integration-20261108/independent-integration-reader-review/proposal'
O=P/'canonical-dje-index-supplement'
CORE='39798cba03364fea6587c4cb8c8e55eb320d5b42'
PARENT='AutoSamplingTheory.TechnicalLemmas.Measure.DisplacementJacobianEntropy.det_conjStarAlgAut_eq'
CHILD='AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumDeterminant.actual_precision_det'
PATHS=['AutoSamplingTheory/TechnicalLemmas/Registry.lean','Tests/Basic.lean']
sha=lambda b:hashlib.sha256(b).hexdigest()
canon=lambda x:json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
assert not O.exists();assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==CORE
basepath=P/'proposal-report.json';assert sha(basepath.read_bytes())=='ab826ff9e6fbbd2db0f0fa766ceadaccf470448152727e48b987bab0ae7161ac'
base=json.loads(basepath.read_bytes());original={r['path']:r for r in base['shared_paths']}
before={p:(R/p).read_bytes() for p in PATHS}
for path,raw in before.items():assert sha(raw)==original[path]['planned_after_sha256'] and raw==subprocess.check_output(['git','show',CORE+':'+path],cwd=R)
entry='''  {
    key := "measure.det-conj-star-alg-aut-existing-canonical",
    localDecl := "AutoSamplingTheory.TechnicalLemmas.Measure.DisplacementJacobianEntropy.det_conjStarAlgAut_eq",
    upstreamDecl := "Existing ASTIS finite real unitary-conjugation determinant identity; compilation-only inventory admission",
    upstreamFile := "AutoSamplingTheory/TechnicalLemmas/Measure/DisplacementJacobianEntropy.lean:154; legacy source-audit debt remains",
    status := LemmaMemoryStatus.formalizedLocal,
    tags := ["determinant", "unitary-conjugation", "existing-compiled-node", "compilation-only-index", "legacy-source-audit-debt"],
    saldUse := "The actual fixed-spectrum cosine-grid determinant producer literally reuses this identical canonical declaration; normal indexing exposes its existing owning module and conservative source-name reference",
    note := "Index admission of an EXISTING public compiled declaration, not a new theorem, proof, SAU or mathematical packet. Exact canonical source SHAa1bf2e9e21e00f1ad7dd01acadc47ea914c2a03b45c82db2aeb927336612fd85 remains unchanged. For every finite index type, real unitary matrix U and arbitrary real matrix B, det(conjStarAlgAut U B)=detB. No determinant-one, positivity, symmetry, spectral-window or Gaussian premise. Existing Tests.DisplacementJacobianEntropy checks this declaration and the new fixed-spectrum producer contains it as its ONE actual kernel ASTIS parent; the held39798 official root gate also compiled the actual reused code. formalizedLocal here records compilation and canonical retrieval only. Legacy source/whole-module publication audit debt of this old module is explicitly retained: the new producer sourceV by /root/reader_835194 does not create a sourceV, fresh source-fidelity verdict or publication coverage for this old parent module. No new source result or main-bound progress is credited. The graph module ownership is structural and the true parent-to-producer name scan remains dashed, incomplete and not a kernel dependency export. No duplicate canonical node, new formal conceptual transport or oracle-factorization candidate is introduced."
  },
'''
needle=b'  {\n    key := "gaussian-complexity.fixed-spectrum-determinant",'
assert before[PATHS[0]].count(needle)==1 and PARENT.encode() not in before[PATHS[0]].replace(b'Its ONE actual compiled ASTIS producer parent is existing DisplacementJacobianEntropy.det_conjStarAlgAut_eq',b'')
afterreg=before[PATHS[0]].replace(needle,entry.encode()+needle,1)
assert afterreg.replace(entry.encode(),b'',1)==before[PATHS[0]]
assert before[PATHS[0]].count(b'status := LemmaMemoryStatus.formalizedLocal')==619
assert afterreg.count(b'status := LemmaMemoryStatus.formalizedLocal')==620
needle=b'formalizedTechnicalLemmaCount = 619';assert before[PATHS[1]].count(needle)==1
afterbasic=before[PATHS[1]].replace(needle,b'formalizedTechnicalLemmaCount = 620',1)
plans={PATHS[0]:afterreg,PATHS[1]:afterbasic}
sys.path.insert(0,str(R/'tools'));import astis_site as site
entries=site.parse_registry();assert not [e for e in entries if e.local_decl==PARENT]
baseline,_=site.enrich_entries(copy.deepcopy(entries))
new=site.RegistryEntry(key='measure.det-conj-star-alg-aut-existing-canonical',local_decl=PARENT,upstream_decl='Existing ASTIS finite real unitary-conjugation determinant identity; compilation-only inventory admission',upstream_file='AutoSamplingTheory/TechnicalLemmas/Measure/DisplacementJacobianEntropy.lean:154; legacy source-audit debt remains',status='formalizedLocal',tags=['determinant','unitary-conjugation','existing-compiled-node','compilation-only-index','legacy-source-audit-debt'],sald_use='Actual same canonical node',note='Compilation-only index; legacy source-audit debt retained')
enriched,_=site.enrich_entries(copy.deepcopy(entries)+[new])
row=lambda e:{'source_file':e.source_file,'source_line':e.source_line,'dependencies':e.dependencies,'consumers':e.consumers,'status':e.status,'explicit_test':e.explicit_test,'source_text_sha256':sha(e.source_text.encode())}
oldrows={e.local_decl:row(e) for e in baseline};newrows={e.local_decl:row(e) for e in enriched}
deltas={name:{'before':oldrows[name],'after':newrows[name]} for name in oldrows if oldrows[name]!=newrows[name]}
assert set(deltas)=={CHILD}
assert deltas[CHILD]['before']['dependencies']==[] and deltas[CHILD]['after']['dependencies']==[PARENT]
stripped=copy.deepcopy(deltas[CHILD]['after']);stripped['dependencies']=[];assert stripped==deltas[CHILD]['before']
assert newrows[PARENT]['dependencies']==[] and newrows[PARENT]['consumers']==[CHILD]
assert newrows[PARENT]['source_file']=='AutoSamplingTheory/TechnicalLemmas/Measure/DisplacementJacobianEntropy.lean' and newrows[PARENT]['source_line']==154 and newrows[PARENT]['explicit_test'] is True
inventory=json.loads((R/'_site/data/site-data.json').read_bytes())
actual=[x for x in inventory['declarations'] if x['full_name']==PARENT];assert len(actual)==1 and actual[0]['local_status']=='Compiled' and actual[0]['route_status']=='Not mapped' and actual[0]['has_placeholder'] is False
graphraw=(R/'_site/data/underlying-lean-graph.json').read_bytes();graph=json.loads(graphraw)
assert not [n for n in graph['nodes'] if n['id']=='decl:'+PARENT]
assert len([n for n in graph['nodes'] if n['id']=='module:AutoSamplingTheory.TechnicalLemmas.Measure.DisplacementJacobianEntropy'])==1
models={p:sha((R/p).read_bytes()) for p in base['unchanged_models']};assert models==base['unchanged_models']
O.mkdir(exist_ok=False)
def archive(name,raw):
 path=O/name;assert not path.exists();data=gzip.compress(raw,mtime=0);path.write_bytes(data);assert gzip.decompress(data)==raw
 return {'path':str(path.relative_to(R)),'raw_sha256':sha(raw),'gzip_sha256':sha(data),'raw_bytes':len(raw)}
rows=[];diff=b''
for i,path in enumerate(PATHS,1):
 rows.append({'path':path,'before_sha256':sha(before[path]),'proposed_after_sha256':sha(plans[path]),'before_archive':archive(f'path-{i}.before.raw.gz',before[path]),'proposed_after_archive':archive(f'path-{i}.proposed-after.raw.gz',plans[path])})
 diff+=b''.join(difflib.diff_bytes(difflib.unified_diff,before[path].splitlines(keepends=True),plans[path].splitlines(keepends=True),fromfile=('a/'+path).encode(),tofile=('b/'+path).encode()))
scanner={'scope':'Actual existing conservative source scanner, parse_registry plus virtual additional RegistryEntry passed to enrich_entries in memory; no shared Registry write, graph/site build, Lean or lifecycle API.','actual_canonical_parent_before_unregistered':True,'actual_old_graph_parent_node_missing':True,'actual_source_inventory_parent':actual[0],'actual_scanner_old_entry_delta':deltas,'actual_new_canonical_parent_scanner_row':newrows[PARENT],'actual_registry_rows_before':len(baseline),'actual_registry_rows_after_virtual_index':len(enriched),'all_older_foreign_Registry_scanner_rows_unchanged':True,'actual_old_generated_graph_raw_sha256':sha(graphraw),'no_generated_graph_rewritten':True}
scannerrow=archive('actual-readonly-scanner.json.raw.gz',canon(scanner))
entryrow=archive('exact-new-entry.raw.gz',entry.encode())
report={'reviewer':'/root/det_integration_reader','recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'phase':'Exact conditional supplementary canonical existing-DJE compilation-only index admission','verdict':'NO_BLOCKING_OBJECTION_TO_EXACT_TWO_PATH_CONDITIONAL_SUPPLEMENT','held_immutable_core':CORE,'original_six_path_proposal_report_sha256':sha(basepath.read_bytes()),'original_six_after_history_preserved':True,'shared_paths':rows,'shared_path_count':2,'existing_public_canonical_declaration':PARENT,'new_source_producer':CHILD,'new_mathematical_declarations':0,'new_SAUs_or_source_verdicts':0,'existing_canonical_nodes_newly_indexed':1,'actual_formalizedLocal_records_before':619,'proposed_administrative_count_after':620,'status_meaning':'formalizedLocal is compilation/retrieval inventory only for this already existing canonical declaration. It is not a new mathematical result, sourceV, or completed old-module publication/semantic audit. Legacy source-audit debt is visible in tags/summary, upstreamFile and note.','exact_new_entry':entryrow,'all_old_Registry_bytes_preserved_by_exact_entry_removal':True,'no_new_import_required':'Existing imported FixedSpectrumDeterminant already imports canonical DJE; existing source inventory and module node resolve it. Registry is metadata only.','actual_readonly_scanner':scannerrow,'expected_bounded_graph_delta':{'one_new_canonical_node':'decl:'+PARENT,'node_status':'compiled, compilation-only Registry inventory; visible legacy-source-audit-debt tags; no source-fidelity overlay','new_edges':[{'source':'module:AutoSamplingTheory.TechnicalLemmas.Measure.DisplacementJacobianEntropy','target':'decl:'+PARENT,'relation':'declares'},{'source':'decl:'+PARENT,'target':'decl:'+CHILD,'relation':'source reference (scanner)'}],'only_prior_Registry_scanner_row_changed':CHILD,'all_older_foreign_nodes_edges_preserved':'Expected from unchanged old rows/generators/models; actual regenerated graph comparison is required before acceptance.'},'generator_edits':[],'conceptual_models_unchanged':models,'all_case_execution_theorem0_Section4_4_and_older_frontier_ledger_bytes_unchanged':True,'rejected_alternatives':{'all_authored_missing_parents':'Would broaden PBPS/SPHMC and other queues by about42 parents; unnecessary for this packet.','generator_theoremname_hardcode':'Rejected; canonical metadata admission uses existing generic index/scanner.','authored_list_as_scanner':'Rejected; only actual conservative source-name scan may supply scanner edge.','referenceOnly_or_portCandidate':'Would mislabel an existing locally compiled and actually consumed declaration as external or merely planned.','new_wrapper_or_duplicate_proof':'Rejected; same compiled canonical lemma must retain one identity.'},'raw_diff':archive('exact-two-path-index.diff.raw.gz',diff),'application_preconditions':['Root sole existing STAB, exact old39798 before hashes, explicit review/application of only these two archived after payloads.','Preserve original6proposal, held39798/core/gate/site/hold artifacts and source bindingc70/accepted-auditc542/sourceV; no history rewrite.','Freeze a new immutable core; genuinely rerun required canonical final gates/site/graph and then explicitly authorized unchanged Chrome checker.','Supplement future protection guards with this exact2pathoverlay/current620 and corrected parent compilation-only/legacy-audit status prose; freeze current helper hashes separately.','Actual new graph must show exactly one canonical parent, genuine dashed scan, no fake formal edge, no old foreign-node/edge/model drift.'], 'actual_build_site_browser_API_shared_or_ledger_mutations':False,'local_reader_acceptance_still_on_hold':True}
reportpath=O/'supplementary-index-proposal.json';reportpath.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
archive('proposal-preparation-driver.py.raw.gz',Path(__file__).read_bytes())
for path,raw in before.items():assert (R/path).read_bytes()==raw
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==CORE
print(json.dumps({'report':str(reportpath.relative_to(R)),'report_sha256':sha(reportpath.read_bytes()),'exact_diff_raw_sha256':sha(diff),'Registry_proposed_after_sha256':sha(afterreg),'TestsBasic_proposed_after_sha256':sha(afterbasic),'scanner_raw_sha256':scannerrow['raw_sha256'],'only_old_scanner_entry_changed':list(deltas),'new_canonical_nodes':1,'new_Lean_theorems':0,'administrative_count':'619->620','shared_applied':False},indent=2))
