# Typed overlay for Appendix C.2 p11–p12

| Pinned input | SHA-256 |
|---|---|
| Phase 1 manifest | `c47055339e578f82411d68b7956c5f33cd32b542e39f95dad7559002ae2dd27a` |
| Phase 1 source graph | `1310e3e205d88ed776f238a8aa0892f2a434e0b5b8d91e9b2c25210572cd0813` |
| Selective type and definition packet | `0e99a3a59cef7c404de38185ada1dd9df6fc5483ea888a917bf20eaf65b1cd9d` |
| Referenced statement seal | `387aa7a644c79f304dc86667b2b70b87a911011ebf61a6efdc3202e550f17fc8` |
| Producer signature | `f4a31dd5801f83ccc2f6c88a4cd38a5392ed2d2f0c03b00afbf47c35029da6d7` |
| Private consumer signature | `bdee81d17f529d8d510b0cd0a95e531889fa33d63f7d75ba3a29c1464834e87c` |

The types support source correspondence for the p11 equality, the p11 bound, and the p12 scalar result. This overlay records semantic proof obligations and dependencies. Proof completion and actual implementation topology are outside the selective packet.

## Binder and definition audit

| Item in each exact type | Classification or meaning |
|---|---|
| Implicit `d : ℕ` | `TYPING`. Ambient dimension. |
| Implicit `q : ℕ` | `TYPING`. The source’s nonnegative integer index, with `q + 1` positive by the carrier and the successor. |
| Explicit `hq : 2 * q + 1 < d` | `STANDING`. The paper’s dimension regime. It supplies `d ≥ 2`, and hence the positivity used for the logarithm and its denominator. The local arithmetic would already work with `d ≥ 1`. |
| `E := EuclideanSpace ℝ (Fin (q + 1))` and its inferred structure | `TYPING`. The packet expands `EuclideanSpace` to `PiLp 2` and `PiLp` to `WithLp` on real coordinate functions. Thus `‖x‖` is the Euclidean norm in dimension `q + 1`. `FiniteDimensional` is `Module.Finite`, and `BorelSpace` identifies the measurable structure with the Borel σ-algebra. Real completeness selects the complete-codomain case of the Bochner integral. |
| `μ := stdGaussian E` | Literal canonical law. The supplied definition pushes forward the product of `gaussianReal 0 1` coordinates indexed by `Fin (Module.finrank ℝ E)` along the map from coefficients to their linear combination in `stdOrthonormalBasis ℝ E`. The finite-dimensional orthonormal basis has `q + 1` vectors. Its coefficient map is an isometry, so the resulting law is the `N(0,I_r)` row marginal in the source. |
| `R := fun x => ‖x‖ ^ 2`, `r := ((q + 1 : ℕ) : ℝ)` and `L := 2 * r + 3 * Real.log (1000 * (d : ℝ))` | Literal squared norm, real dimension cast and cutoff. `R` is continuous and nonnegative, and `r > 0`. The packet’s `Real.log` uses the inverse exponential of the absolute value on nonzero arguments and zero at zero. Here the argument exceeds one, so the cutoff uses the ordinary natural logarithm with `log(1000d) ≥ 0` and `L ≥ 0`. |
| `badMoment := Set.indicator {x : E \| L < R x} R` and consumer's weak indicator | `Set.indicator` has the given value on the set and zero elsewhere. The packet also gives the corresponding `Set.piecewise` branch rule. These terms are `R(x) 1_{R(x)>L}` and `R(x) 1_{R(x)≤L}`, respectively. Continuity of `R` makes both threshold sets Borel. At equality the retained branch has value `R(x)` and the upper-tail branch has value zero. |
| `tail s := (μ {x : E \| L + s < R x}).toReal` | Real probability of the strict event at each real `s`. `ENNReal.toReal` coerces `toNNReal`, and `toNNReal` uses `WithTop.untopD 0`. The probability mass of `μ` is one because the coordinate factors are probability laws and the coefficient map is measurable. Thus all event measures are finite and the finite branch agrees with the real-valued source probability. |
| `Set.Ioi (0 : ℝ)`, `volume` and `IntegrableOn tail` | `Set.Ioi 0` is `{s \| 0 < s}` and `IntegrableOn tail (Ioi 0) volume` is `Integrable tail (volume.restrict (Ioi 0))`, with restriction to the displayed measurable set. The packet’s `Real.measureSpace` uses the canonical volume instance from the orthonormal basis’s additive Haar measure. In one real dimension its unit-length normalization gives Lebesgue measure. The unit-interval normalization and zero mass of `{0}` are measure facts used by the correspondence. The supplied volume literals end at `Basis.addHaar`. |
| `Integrable` and the integral notation | `Integrable f μ` expands to `AEStronglyMeasurable f μ ∧ HasFiniteIntegral f μ`, where the latter is `∫⁻ x, ‖f x‖ₑ ∂μ < ∞`. The supplied Bochner definition takes the `L1.integral` branch for complete real codomain and integrable `f`, and otherwise has value zero. The moment uses `μ`, and the set integral uses `volume.restrict (Ioi 0)`. The producer establishes both integrability conditions. In the consumer the Gaussian norm mean and domination establish the conditions for both truncations. |
| `a := (∫ x, Set.indicator {y : E \| R y ≤ L} R x ∂μ) / r` | Literal scalar component of Ex108. Division by the positive `r` is multiplication by `1/r`. The equality of the source row marginals means their expectations all agree with this single canonical expectation, giving the common scalar. |

Both types have exactly the three displayed binders `d`, `q` and `hq`. The `let` terms fix their values locally. There are zero `SOURCE`, `RULED` or `EXCESS` binders. The canonical law absorbs the fixed-row marginal premise of the source computation. For any source row `γ_i`, the pushforward law gives the event correspondence by measurability and the integral correspondence by measurability and integrability. Cross-row independence, the all-rows event, radial matrix covariance, C.5 and downstream concentration are outside these dependencies.

## Producer judgments

| Conclusion | Source judgment | Exact local obligations |
|---|---|---|
| `Integrable badMoment μ` | Derived completion of Ex106, using the source gap for the first moment. | Prove measurability and finiteness of the nonnegative strict truncation. The nonnegative layer-cake relation and finite right side supply this in the frozen source route. |
| `IntegrableOn tail (Ioi 0) volume` | Derived completion of Ex106, using the source gap for the tail integral. | Finite probability conversion preserves order, so the real tail function is nonincreasing and Borel. On `Ioi 0` it is nonnegative and bounded by the integrable shifted exponential envelope. |
| `(∫ x, badMoment x ∂μ) = L * tail 0 + (∫ s in Ioi 0, tail s ∂volume)` | Matches the p11 equality at `A3.Ex106.m1` and `A3.Ex106.m2#identity`. | Use the extended nonnegative layer-cake identity, finite event mass and the two integrability facts to pass to real integrals. The integral from zero to infinity and the restricted integral on the open half-line agree because the singleton `{0}` is null. The separate term `L * tail 0` is retained. |
| `(∫ x, badMoment x ∂μ) ≤ (L + 3) / (1000 * (d : ℝ))` | Matches the p11 bound at `A3.Ex106.m2#bound`. | Apply the exact equality, the boundary estimate from the shifted tail at `s = 0`, and the integrated shifted bound. |

The reused Ex104 bound applies at `x = log(1000d) + s/3`. Its premise `x ≥ 0` follows from `s ≥ 0` and the log sign. The threshold becomes `L+s` and the resulting exponential is `exp(−s/3)/(1000d)`. This supplies the shifted-tail premise of the p11 argument. For the boundary term, `s = 0` is admissible and multiplication by `L ≥ 0` preserves the bound. For the integral, the Lebesgue calculation on `Ioi 0` gives `∫ exp(−s/3) ds = 3`, so the shifted tail integral is at most `3/(1000d)`.

The extended layer-cake step uses the pointwise identity `badMoment(x) = L * 1_{R(x)>L} + (R(x)−L)₊` and the length of the strict section `{s ∈ Ioi 0 : L+s<R(x)}`. That length is `(R(x)−L)₊`. Joint measurability follows from continuity of `(x,s) ↦ R(x)−L−s`. Nonnegative Tonelli exchanges the integrals over Gaussian measure and the restricted real volume. For each `s` the Gaussian integral of the event indicator gives the finite measure of the event. This yields the extended equality before any Bochner integral is used. Its finite right side follows from `L * tail 0` being finite and the integrable tail envelope. The two integrability outputs then justify identifying the extended quantities with the real integrals in the producer.

In the frozen route the equality uses the layer-cake step and the resulting finiteness. An integrable envelope and finite event mass suffice for that finiteness. The upper bound then uses the exponential integral value `3` and the numerical bound on `L * tail 0`. This preserves the `tail-moment-identity` and `tail-moment-upper` nodes as distinct claims.

## Private scalar consumer judgments

| Conclusion | Source judgment | Immediate mathematical inputs |
|---|---|---|
| `0 ≤ a ∧ a ≤ 1` | Matches `A3.SS2.p12.m4`. | The retained truncation lies between zero and `R`. Its integral lies between zero and `r` by the exact radial mean and integrability. Divide by `r > 0`. |
| `1 - a = (∫ x, Set.indicator {y : E \| L < R y} R x ∂μ) / r` | Matches `A3.Ex109.m1#identity`. | Use `a` from the scalar component of Ex108, the integrable complementary truncations, the exact total `∫ R ∂μ = r`, and `r > 0`. The two indicated variables sum pointwise to the untruncated variable, including at equality. |
| `1 - a ≤ (L + 3) / (1000 * r * (d : ℝ))` | Matches `A3.Ex109.m1#bound`. | Apply the bias identity and the producer’s upper bound to the strict moment, then divide by `r > 0` and combine real denominators. The p11 layer-cake equality and shifted-tail estimate enter through that upper-bound route. |

The exact radial mean dependency is the `A3.SS2.p12.m3` assertion with its omitted coordinate calculation. Under the supplied Gaussian definition, integrate after the orthonormal coefficient map. The squared norm there is the sum of the `r` squared coefficients. Each coefficient has the `gaussianReal 0 1` marginal, hence its square has integral `1` by mean zero and variance one. The finite sum is integrable and its integral equals `r`. The two measurable truncations are each dominated by `R`, giving their integrability independently of the p11 producer. This supports the scalar range and identity directly. The final inequality consumes the producer’s upper-bound conjunct and the independently established bias identity. The appearance of all four p11 facts in one producer signature is a packaging choice.
