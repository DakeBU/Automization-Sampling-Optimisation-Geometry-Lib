from pathlib import Path
import datetime, hashlib, json, sys

R = Path('.astis/huanjian-gc-fixed-spectrum-first-order-integration-20261108')
P = Path('.astis/semantic-neutral-20261108/src_4e8f6a/normalpark-preparation-v2')
sha = lambda b: hashlib.sha256(b).hexdigest()
manifest = P/'preparation-manifest.json'
assert sha(manifest.read_bytes()) == 'b3b518fde0cab9876668bffc4ee8dbc075cb5c48d6f6abc7d17c8dc6adeb190a'
d = json.loads(manifest.read_bytes())
for row in d['artifacts']:
    raw = (P/row['path']).read_bytes()
    assert sha(raw) == row['sha256'] and len(raw) == row['bytes']
old = P.parent/'normalpark-preparation/preparation-manifest.json'
assert sha(old.read_bytes()) == d['held_core87_prep_manifest_sha256']
old_d = json.loads(old.read_bytes())
for row in old_d['artifacts']:
    raw = (old.parent/row['path']).read_bytes()
    assert sha(raw) == row['sha256'] and len(raw) == row['bytes']
sys.path.insert(0, str(P.resolve()))
import park_common
b = json.loads((P/'preservation-baseline.json').read_bytes())
states = park_common.protected(b)
assert states[park_common.ADV]['state'] == 'STABILIZING'
assert [k for k, v in states.items() if v['state'] == 'STABILIZING'] == [park_common.ADV]
out = R/'root-normalpark-v2-preparation-review.json'
assert not out.exists()
value = {
    'recorded_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'reviewer': '/root', 'scope': 'Independent static complete helper/common guard review and frozen preparation integrity, no acceptance or API authority',
    'manifest': {'path': str(manifest), 'sha256': sha(manifest.read_bytes())},
    'bindings': d['bindings'], 'actual_new_payload_hashes_verified': len(d['artifacts']),
    'actual_old_CORE87_payload_hashes_preserved': len(old_d['artifacts']),
    'actual_baseline_protected_readback': {'states': len(states), 'foreign_states': 284,
        'frontiers': len(b['frontier_raw_hashes']), 'critical_raw_pins': len(b['critical_raw_pins']),
        'frozen_originals': len(b['frozen_originals'])},
    'findings': [
        'No execution by default: templates fail closed, --execute and separately hashed exact root authorization are both required.',
        'Current9b HEAD/index/only-current-ledger mutation, exact original sourceV306/STAB621/audita148/owner and all original V evidence are pinned.',
        'Native accepted context consistency and actual same-core eight gate receipts, v4 report/receipt and exact report log path are required.',
        'All38 actual PNG hashes/dimensions and distinct independent opened-original pixel review are required; native8 geometry is recomputed from real rectangles and keeps extra4 DOM-only.',
        'Later local acceptance and parking eligibility are separate artifacts; no old pending adapter or held87 acceptance is admitted.',
        'The single allowed transition preserves every original V evidence key/value and adds only post_integration_normalpark; source-checked commit remains9d.',
        'One-shot execution-started guard prevents blind retries; postconditions require exact old ledger prefix plus one event, original actor and proof owner, no remainingSTAB, and no foreign or canonical collateral edit.',
    ],
    'blocking_objections_to_guarded_future_use': [], 'execution_authorized': False,
    'local_acceptance_created': False, 'new_source_verdict': False, 'lifecycle_API_called': False,
}
out.write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n')
print(json.dumps({'path': str(out), 'sha256': sha(out.read_bytes()),
                  'new_payloads': len(d['artifacts']), 'old_payloads': len(old_d['artifacts']),
                  'execution_authorized': False}))
