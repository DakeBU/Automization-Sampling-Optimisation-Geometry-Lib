"""Bounded real-browser acceptance of the actual first-order observation reconstruction reader."""
import functools
import datetime
import hashlib
import http.server
import json
from pathlib import Path
import re
import subprocess
import sys
import threading
from urllib.parse import quote, urljoin, urlsplit

from playwright.sync_api import sync_playwright

ROOT = Path.cwd()
SITE = ROOT / '_site'
OUT = ROOT / '.astis/huanjian-gc-first-order-query-integration-20261107/browser' / ('live-' + datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ'))
OUT.mkdir(parents=True, exist_ok=True)
sys.path.insert(0, str(ROOT / 'website/scripts'))
sys.path.insert(0, str(ROOT / 'tools'))
import inline_lean

PREFIX = 'AutoSamplingTheory.ExampleCases.GaussianComplexity.'
TARGETS = {'actual': PREFIX + 'FirstOrderQuery.actual_first_order_query'}
rows = {r['declaration']: r for r in json.loads((SITE / 'data/declaration-exposition.json').read_text())}
declarations = inline_lean.declarations()
report = {'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
          'mode': 'HTTP with installed headless Chrome, isolated temporary profile; external requests blocked',
          'pages': [], 'graphs': [], 'errors': [], 'screenshots': []}


class Quiet(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *_):
        pass


server = http.server.ThreadingHTTPServer(('127.0.0.1', 0), functools.partial(Quiet, directory=str(SITE)))
threading.Thread(target=server.serve_forever, daemon=True).start()
base = f'http://127.0.0.1:{server.server_port}/'
expected_commit = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
metadata_path = SITE / 'data/build-metadata.json'
metadata = json.loads(metadata_path.read_text())
assert metadata['git']['commit'] == expected_commit
actual_gate = json.loads((ROOT / '.astis/site-lean-gate.json').read_text())
assert actual_gate['passed'] and metadata['source_digest'] == actual_gate['source_digest']
assert metadata['gate']['passed'] and metadata['gate']['current']
report['mode'] = 'Actual local final site over HTTP with isolated installed Chrome; external hosts blocked'
report['site_metadata'] = metadata
report['site_metadata_sha256'] = hashlib.sha256(metadata_path.read_bytes()).hexdigest()
report['actual_compiled_gate_commit'] = actual_gate['commit']
report['actual_compiled_source_digest'] = actual_gate['source_digest']
report['compilation_boundary'] = 'Actual canonical gate at the separately named immutable commit; exact current Lean source digest matches. Current metadata-only HEAD is not relabeled as an additional build.'
report['visible_source_index_clicks'] = []
report['external_GitHub_HTML_checked'] = False
report['external_source_route'] = 'Historical GitHub HTML504 host route remains frozen; Own-site complete module/downloads are checked against actual source and an immutable Git object; external GitHub URL syntax is separately conditional and external HTML is not checked.'

def screenshot(page, name):
    path = OUT / (name + '.png')
    page.screenshot(path=str(path))
    report['screenshots'].append({'file': path.name, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()})


def math_ready(page):
    page.wait_for_function('Boolean(window.MathJax?.startup?.promise)', timeout=30000)
    page.evaluate('() => MathJax.startup.promise')
    assert page.locator('mjx-container').count() > 0
    assert page.locator('mjx-merror, [data-mjx-error]').count() == 0


def no_page_overflow(page):
    assert not page.evaluate('document.documentElement.scrollWidth > innerWidth + 1'), page.url



report['mode'] = 'MINIMAL ACTUAL CONCEPT VIEW DIAGNOSTIC ONLY; not full reader acceptance'
try:
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True, executable_path='/Applications/Google Chrome.app/Contents/MacOS/Google Chrome')
        report['browser_version'] = browser.version
        context = browser.new_context()
        context.route(re.compile(r'https?://(?!127\.0\.0\.1:)'), lambda route: route.abort())
        page = context.new_page()
        page.on('pageerror', lambda e: report['errors'].append(str(e)))
        bridge = 'transport:gaussian-quadratic-oracle-factorization'
        report['diagnostics'] = []
        for width in (1440,390):
            page.set_viewport_size({'width':width,'height':1000 if width>400 else 844})
            page.goto(base+'lean-foundations.html?view=functor&focus='+quote(bridge,safe=''), wait_until='domcontentloaded')
            page.wait_for_selector('.ulg-canvas[data-view="functor"][data-local="false"]')
            page.wait_for_function("document.querySelector('[data-graph-detail]').dataset.kind === 'concept-bridge'")
            detail=page.locator('[data-graph-detail]')
            math_ready(page)
            text=detail.inner_text();markup=detail.inner_html()
            (OUT/f'conceptual-{width}-detail.txt').write_text(text)
            (OUT/f'conceptual-{width}-detail.html').write_text(markup)
            detail.scroll_into_view_if_needed()
            screenshot(page,f'conceptual-{width}-diagnostic-details')
            report['diagnostics'].append({'width':width,'heading_texts':detail.locator('h2,h3,dt').all_inner_texts(),'actual_detail_inner_text':text,'actual_detail_text_content':detail.text_content(),'actual_bridge_node_count':page.locator(f'.ulg-node[data-id="{bridge}"]').count(),'canvas_view':page.locator('.ulg-canvas').get_attribute('data-view'),'canvas_local':page.locator('.ulg-canvas').get_attribute('data-local'),'detail_hyperedge_sections':detail.locator('.ulg-hyperedge').count(),'status':'RAW_DIAGNOSTIC_NO_ACCEPTANCE_VERDICT'})
        browser.close()
        report['status']='diagnostic-only-not-acceptance'
finally:
    server.shutdown();server.server_close()
    (OUT/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'status':report.get('status'),'diagnostics':report.get('diagnostics'),'report':str(OUT/'report.json')},ensure_ascii=False))
