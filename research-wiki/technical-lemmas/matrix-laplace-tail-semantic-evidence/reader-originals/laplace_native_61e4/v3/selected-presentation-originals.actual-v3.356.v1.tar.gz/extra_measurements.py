
def source_bottom(page, source_label, line_count, label, check, screenshot):
    bottom=page.locator('#L'+str(line_count))
    measurement=bottom.evaluate('''async el=>{
      document.documentElement.style.setProperty('scroll-behavior','auto','important');
      document.body.style.setProperty('scroll-behavior','auto','important');
      for(let p=el;p;p=p.parentElement)p.style.setProperty('scroll-behavior','auto','important');
      el.scrollIntoView({behavior:'instant',block:'center',inline:'nearest'});
      await new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)));
      const pre=el.closest('pre'),text=el.firstChild,raw=text.textContent,end=raw.trimEnd().length;
      let start=Math.max(0,end-1);
      if(start>0&&raw.charCodeAt(start)>=0xDC00&&raw.charCodeAt(start)<=0xDFFF&&raw.charCodeAt(start-1)>=0xD800&&raw.charCodeAt(start-1)<=0xDBFF)start--;
      const range=document.createRange();range.setStart(text,start);range.setEnd(text,end);
      pre.scrollLeft=0;
      let r=range.getBoundingClientRect(),b=pre.getBoundingClientRect();
      if(r.right>b.right-4)pre.scrollLeft+=r.right-b.right+8;
      await new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)));
      r=range.getBoundingClientRect();b=pre.getBoundingClientRect();
      let header=0;const hs=[...document.querySelectorAll('header,.mobile-bar,.verification-strip')];
      for(let pass=0;pass<hs.length+1;pass++)for(const h of hs){const s=getComputedStyle(h),q=h.getBoundingClientRect();if(['fixed','sticky'].includes(s.position)&&s.display!=='none'&&s.visibility!=='hidden'&&q.width>0&&q.height>0&&q.right>0&&q.left<innerWidth&&q.bottom>0&&q.top<=header+1)header=Math.max(header,q.bottom);}
      return {lineId:el.id,glyph:raw.slice(start,end),glyphCodePoints:Array.from(raw.slice(start,end),c=>c.codePointAt(0)),startUTF16:start,endUTF16:end,width:r.width,height:r.height,left:r.left,right:r.right,top:r.top,bottom:r.bottom,header,containerLeft:b.left,containerRight:b.right,viewportHeight:innerHeight,visible:r.width>0&&r.height>0&&r.left>=b.left-1&&r.right<=b.right+1&&r.top>=header+4&&r.bottom<=innerHeight-4};
    }''')
    check(label+'-'+source_label+'-bottom-full-codepoint-glyph-actually-visible',measurement['visible'],measurement)
    screenshot(page,label+'-source-'+source_label+'-bottom-glyph')

def parent_context(page, origin, label, check, screenshot):
    page.goto(origin+'/proofs/huanjian-matrix-laplace-tail.html',wait_until='networkidle')
    link=page.locator('.mgf-preview-nav a[href$="parent-context.html"]')
    with page.expect_navigation(wait_until='networkidle'):link.click()
    main=page.locator('main')
    expected=[
      'AutoSamplingTheory.TechnicalLemmas.Probability.MatrixLaplaceTail.max_eigenvalue_tail_le_iInf_trace_exp',
      'AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumSourceMatrixRadius.actual_source_truncated_matrix_norm_bounds',
      'AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumSourceMatrixStructure.actual_source_centered_matrix_structure']
    check(label+'-actual-parent-context-navigation',page.url.endswith('/parent-context.html'))
    check(label+'-parent-context-public-P-no-ASTIS-parent-and-private-T-not-public',
      'only Mathlib parents; no ASTIS mathematical parent is claimed' in main.text_content()
      and 'It has no separate public theorem node' in main.text_content())
    links=main.locator('li a')
    check(label+'-parent-context-exact-three-private-T-parents',links.count()==3 and links.all_text_contents()==expected)
    screenshot(page,label+'-parent-context',full=True)
    for i in range(3):
      page.goto(origin+'/parent-context.html',wait_until='networkidle')
      target=page.locator('main li a').nth(i)
      href=target.get_attribute('href')
      with page.expect_navigation(wait_until='networkidle'):target.click()
      check(label+'-parent-context-link-'+str(i+1)+'-actual-source-anchor',page.url.endswith('/'+href) and page.locator('#'+href.split('#')[1]).count()==1)
      screenshot(page,label+'-parent-context-source-'+str(i+1))
