# Next Gram packet: independent original-source expectations

This record is frozen before any new ROOT P/T signature, proof, API search, old audit/native verdict, or new SG map is read. Original arXiv2610.20492v1 HTML SHA256 is 6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915. Required original C.2 p1–p19, Fact C.6, and S4 Lemma4.4 plus standing definitions were re-read directly. Prior exposure: this reviewer completed the earlier structure packet; it does not claim an absence of that earlier source/signature exposure. No new Gram statement or implementation has been seen.

## Source layers to keep distinct

A. C.2 p17 / Ex125 gives exact actual Gram reconciliation on the source-local event T. It is an eventwise equality, not itself a probability theorem.

B. C.2 p17 / Ex126 converts the two centered-sum deviation inequalities on the intersection with T into the two actual Gram norm inequalities. Its eventwise implication is distinct from proving that the intersection has probability at least0.995.

C. C.2 p19 / EGx13 uses actual Gram operator-norm bounds to control every coefficient vector c and u=Bc. Ex132 additionally uses tau<=1/2. A claim for every u in the Krylov space also needs the separate range(B)=K_q identity; a claim only about Bc does not.

D. Full Fact C.6 and Lemma4.4 additionally require tail probabilities, Bernstein, the union bound, scalar threshold simplification/absolute-constant choice, and (for Lemma4.4) Krylov range. None is silently supplied by an eventwise algebra/norm packet.

## Literal original objects

- q is natural/nonnegative; source hq is2q+1<d. It internally implies d>=2, d>0, r=q+1>=1 and2r<=d. q=0 is included. No q>0, nonzero coefficient, nonzero vector, nonzero weight, extra cutoff or positivity caller assumption is source-justified.
- r=q+1 and n=2q+1. The original Gaussian experiment has independent columns g_a~N(0,I_d), a=1..r. Actual physical row gamma_i=((g_1)_i,...,(g_r)_i) is in R^r. Standard Gaussian column coordinates and regrouping imply the joint row law. A row marginal/law/independence certificate is an internal dependency, not a replacement experiment or caller premise.
- theta_i=(i-1/2)pi/d with source i=1..d. A zero-based Fin index must use i.val+1-1/2. t_i has coordinate0=1 and coordinates j=1..q equal sqrt(2)cos(j theta_i). The exact deterministic frame matters here; generic bounded features do not give its aggregate identities.
- B is d by r^2; row i is d^(-1/2)(gamma_i tensor t_i)^T. Pair indices(a,j), (b,k) identify the r^2 coefficient coordinates. B_(i,(a,j))=d^(-1/2)(gamma_i)_a(t_i)_j. This is real square-root dimension normalization, not1/d,1/r,1/r^2, or1/sqrt(r^2).
- D_n is the d by d diagonal matrix with entries w_i=cos(n theta_i). The weighted Gram matrix is B^T D_n B, of size r^2 by r^2. B^T B also has this size, and the identity matrix in Ex125/126 is I_(r^2), not I_d or I_r.
- L=2r+3log(1000d), R_i=||gamma_i||_2^2, and T={all i:R_i<=L}. These are actual row norms, not column norms. The cutoff is inclusive. Y_i=d^(-1)(gamma_i gamma_i^T tensor t_i t_i^T)1_(R_i<=L). Its off-event zero is the literal truncation indicator.
- mu remains the original unconditional Gaussian experiment for every actual mean. Z_i=Y_i-E_mu[Y_i]. No conditioning on T, resampling, surrogate law, arbitrary mean, or radial proxy is substituted.
- The source scalar is a=(1/r)E[R_i1_(R_i<=L)], the same for all i. In a canonical row-marginal integral form it must be transported to the same actual experiment. True measurability/integrability and probability normalization are internally derived before using expectation; a totalized integral alone is not a mean certificate.

## Exact internal aggregate obligations

1. Pointwise Gram algebra, before truncation:
   B^T B=sum_i d^(-1)(gamma_i gamma_i^T tensor t_i t_i^T),
   B^T D_n B=sum_i w_i d^(-1)(gamma_i gamma_i^T tensor t_i t_i^T).
   The factor(d^(-1/2))^2=d^(-1) uses actual d>0. Tensor-entry order, transpose and diagonal multiplication must match the pair-indexed definitions.
2. On T, every original summand equals its Y_i at the same outcome. This equality is pointwise for all outcomes in the exact T, including cutoff equality. An almost-sure formula or a different good event is not a literal substitute without a separately stated transport.
3. The exact source frame satisfies sum_i t_i t_i^T=d I_r and sum_i w_i t_i t_i^T=0. These are internally proved deterministic cosine identities. The source p4–p7 proof uses midpoint cosine sums, products-to-sums and the frequency range1<=n-j-k<=n±j±k<=4q+1<2d. Their directions are frame identities -> aggregate means -> Gram reconciliation; not Gram reconciliation -> frame hypotheses.
4. Under the actual original law, individual means are E_mu Y_i=(a/d)(I_r tensor t_i t_i^T). Hence sum_i E_muY_i=a I_(r^2) and sum_i w_i E_muY_i=0. Weighted aggregate cancellation is not the assertion that every Y_i has mean0. These mean/frame/normalization/Gram conclusions must be proved internally; none may enter a source-facing stochastic theorem as a caller certificate.
5. The bias has exact sign: on T,
   B^T B-I_(r^2)=sum_i Z_i-(1-a)I_(r^2),
   B^T D_n B=sum_i w_i Z_i.
   A plus sign in the first exact equality is wrong even though a later triangle inequality could hide it. Weighted reconciliation has no residual bias term because the weighted actual means sum to0.
6. The source establishes0<=a<=1 using nonnegativity of R, truncation and E[R]=r. In particular1-a>=0. This fact matters when the norm of the bias is written as1-a rather than|1-a|. Identity operator norm is1 in the nonempty r^2-dimensional Euclidean space. The quantitative upper bound1-a<=(L+3)/(1000rd) is used later to simplify to tau, not for Ex125 or the elementary Ex126 eventwise implication.

## Source-local antecedents versus excess certificates

For the eventwise Ex125 equalities, membership in the literal T is the source-local condition. For eventwise Ex126 bounds, the antecedents additionally are the two displayed centered-sum deviation conditions from Ex124:
   ||sum_i Z_i||_op<=Delta and ||sum_i w_i Z_i||_op<=Delta,
with source Delta=sqrt(2 v_* z)+2 R_* z/3, z=log(1000r^2), v_*=2r(r+2)/d and R_*=2r(L+1)/d. The same-outcome intersection is essential.

On that intersection, triangle inequality and exact actual aggregate means give
   ||B^T B-I_(r^2)||_op<=Delta+(1-a),
   ||B^T D_n B||_op<=Delta.
Those are the deterministic contents of Ex126. Source-local event/deviation antecedents must remain explicit when that is the sealed scope. A stochastic probability theorem must prove the probability of those events internally; a probability/Bernstein-ready/concentration certificate is not an allowed caller premise. A generic deterministic norm lemma could use abstract norm bounds as a separately labelled mathematical generalization; it cannot silently replace the source stochastic theorem.

The source probability arithmetic is separate: P(T)>=0.999; each deviation fails with probability<=0.002; simultaneous centered deviations have probability>=0.996; intersection has probability>=0.995. Source does not assert independence between these events. A union bound suffices. Independence of the two matrix families or their aggregate sums is not needed or supplied here. Full Bernstein still needs its own actual independent/centered/self-adjoint, norm and variance dependencies.

## Deterministic quadratic consumer expectations

For an actual Gram bound||B^T B-I||_op<=eta, every c satisfies
   ||Bc||_2^2=c^T B^T Bc >=(1-eta)||c||_2^2.
For||B^T D_nB||_op<=xi, every c satisfies
   |(Bc)^T D_n(Bc)|=|c^T B^T D_nBc|<=xi||c||_2^2.
The source specialization is eta=xi=tau_(d,q) after the separate simplification step. If retaining literal Ex126 thresholds before simplification, eta=Delta+(1-a) and xi=Delta are distinct. Euclidean vector norms and the matching L2 operator matrix norm must be used; a sup/Frobenius norm substitution changes the stated constants and meaning.

The simultaneous-for-all-c quantifier is crucial. Coefficients may depend on the whole experiment, so no independence or determinism assumption about c relative to the Gaussian input is warranted. c=0 and u=0 stay covered. For the final Ex132 ratio,1-tau>0 is needed and follows from source tau<=1/2; it is not needed for Ex125/126 or the two elementary quadratic inequalities. The range(B)=K_q step is needed only to transfer from every Bc to every Krylov u. That range proof additionally uses the source nonconstant affine spectrum/triangular cosine-polynomial change of basis; it is not a consequence of norm bounds alone.

## Provisional source-only directions and later challenge checks

- original independent-column experiment -> actual row law + true individual means;
- exact midpoint frame and n=2q+1 frequency identities -> actual aggregate means;
- literal B normalization/pair indexing -> pointwise untruncated Gram identities;
- exact T -> original/truncated summand equality;
- those identities + actual aggregate means + actual Z definition -> Ex125;
- Ex125 + same-outcome source deviations + a<=1 -> Ex126 norm bounds;
- actual Gram norm bounds + Euclidean quadratic algebra -> all-c consumer;
- range(B)=K_q plus the all-c consumer, with tau<=1/2 only at the inversion stage -> final uniform Krylov estimate.

Later challenge: detect omitted aggregate/frame/cosine frequency steps; a proxy or conditioned mean; wrong Gram dimension or normalization; exact-event drift; inclusive/strict cutoff drift; q0 exclusion; hidden mean/frame/Gram/probability certificates; probability claims supplied by caller instead of dependencies; wrong edge direction; false AND of alternative derivations; an unjustified independence requirement between deviation events; misplaced tau<=1/2; lost adaptive/all-c simultaneity; unproved range transfer; and norm semantics changing constants.

No new signature, graph, implementation or API has influenced this record. It is a raw source-expectations freeze only: no proof, source-fidelity, normalV, SAU, ledger, frontier or canonical acceptance is claimed.
