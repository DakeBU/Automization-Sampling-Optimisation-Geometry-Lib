from pathlib import Path
import hashlib,json,datetime
ROOT=Path('/Users/zhouhuanjian/ASTIS-GC')
OUT=ROOT/'.astis/semantic-neutral-20261110/src_a83e10'
E=ROOT/'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-signal-strength-semantic-evidence'
P1='f4b7e781a584005ade0a21cb0d1df46b1d154b9b94df33d2f83bced7ffe9f822'
P2='951a69f26cb0f2e4f58a644a7e57f081c593d8b62da6093c0a88dfbc7e30e9e9'
PACKET='992f9be35a150ec4fd8f75bfc19adce51a93bfc19574b07d27c35eb1ca0cb3a0'
BINDING='aa982161b75c7550ba8168b07d4c45218f497e7463c99e250d66012c622de195'
SOURCE='6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
COMMIT='df64aaa6088b6ac88c35696acfed906031964d72'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def digest(o):return hashlib.sha256(json.dumps(o,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def load(p):return json.loads(p.read_text())
def write(n,o):(OUT/n).write_text(json.dumps(o,ensure_ascii=False,indent=2)+'\n')
for n,h in [('phase1.freeze.json',P1),('phase2.freeze.json',P2)]:
    assert sha(OUT/n)==h
    f=load(OUT/n)
    assert all(sha(OUT/x['path'])==x['sha256'] for x in f['files'])
bound=load(OUT/'phase3_bound_inputs.json')
assert bound['binding_matches'] and bound['review_context_matches_packet_exactly']
assert bound['canonical_reviewer_packet_digest_matches']
assert all(x['same_as_candidate'] for x in bound['whitelisted_candidate_files'])
assert all(x['exact_contiguous_substring'] for x in bound['selected_lesson_steps'])
assert bound['selected_lesson_steps'][-1]['full_test_byte_text_equality']
packet=load(E/'fresh-source-reviewer-packet.json')
rows=load(E/'source-to-lean-map-v1.json')['rows']
specific={
 's:target-oracle':'Only the inverse-precision centered target semantics is consumed; the bundled oracle/class definition receives no new oracle credit.',
 's:grid':'The literal midpoint precision grid agrees after zero-based reindexing; positive diagonal semantics are internally supplied.',
 's:cosine-statistic':'Odd n=2q+1 is the selected application; it is not imposed on generic source moments.',
 's:scalar-regime':'Numeric premises alone suffice for this branch; successful-algorithm and epsilon assumptions are irrelevant here.',
 's:moment-normalization':'Same-law M and b actual integrals; beta=abs(b)/M with no dimension divisor.',
 's:uniform-n':'The author asymptotic remains source topology; ModeGap supplies only the needed finite endpoint through a sufficient envelope.',
 's:distance-domain':'The source little-o route and the canonical finite sufficient gap endpoint are distinguished.',
 's:beta-lower':'Exact intermediate 3delta/128 is retained in the local proof before relaxation; B has the source value.',
 's:M-lower':'Elementary nonstrict exp(-2)<=1/3 suffices; strict source exp(-2)<1/3 is not separately emitted.',
 's:signal-product':'Exact finite lower inequality is proved; Tendsto-to-infinity is not a separate emitted theorem.',
 's:lemma45-bias':'General frequency canonical Bias is instantiated after the selected gap is internally discharged.',
 'c:c7':'Complete complex-geometric proof and absolute/uniform-in-theta convergence were read in CosineExpansion.',
 'c:geometric':'Complete private geometric calculation preserves the source rational normalization.',
 'c:rho-algebra':'Radius algebra matches the inverse spectrum; no covariance swap.',
 'c:majorant':'Geometric majorant is uniform in theta for fixed kappa, not in unbounded kappa.',
 'c:c8':'Complete ExactMeans proves both finite-grid signed means in general 1<=n<d; no odd-only restriction.',
 'c:grid-sum':'All-integer GridAlias includes negative frequencies and zero, with a proved nonzero sine denominator off aliases.',
 'c:trace-means':'Actual GaussianMoments integrability/means and ExactMeans finite-sum/tsum exchange are both present.',
 'c:mean-M':'Alternating signed alias/geometric sum retains the finite-d correction.',
 'c:mean-b':'Support reindexing, summability, disjoint alias families and parity preserve the exact signed mean.',
 'c:ratio':'Positive actual M and signed b justify the exact ratio; no totalized-division substitute.',
 'c:log-powers':'Complete inherited FTC/log proof supplies sufficient final exponential bounds. Exact rational kappa-1 and strict intermediate credit is excluded.',
 'c:bias':'Extra d-n>=sqrt(kappa) is used only where source lower-bias tail needs it, and discharged by ModeGap.',
 'c:variance':'Complete canonical Gaussian fourth moments, coordinate independence, L2 and weighted-sum variances support the private consumer.',
 'gap:gaussian-semantics':'GaussianMoments/Variances prove selected actual covariance, positive-definite inverse and finite moments internally; source gap is not a caller premise.',
 'gap:geometric-series':'Read complete canonical complex and real geometric summations; source omitted foundational input is internally supplied.',
 'gap:trigonometry':'GridAlias and ExactMeans actually provide the finite integer-grid and product-to-sum uses.',
 'gap:log-calculus':'Read complete Bias private FTC/log/integral providers; these are implementation dependencies, not public assumptions.',
 'gap:power-asymptotics':'Only guarded real-power algebra and finite mode/signal thresholds are claimed; full author asymptotic families remain un-emitted.',
 'gap:chebyshev':'Private Test uses actual finite-law variance Chebyshev; source shifted L2-triangle assembly remains excluded.',
 'a:literal-law':'Generic source Gaussian semantics precedes the selected Fin/Bochner odd-frequency adapter; direction is preserved.',
 'a:domain':'ModeGap supplies all finite domain/gap conditions before every kappa and q; no certificate binder.',
 'a:positive-M-beta':'M and beta positivity are derived outputs; signed b rather than b itself is positive.',
 'root:public-signal':'The complete producer proves exactly the sealed five-conjunct actual-law numerical consequence.',
 'a:private-threshold':'N>=40/B^2 and the max threshold are chosen before varying parameters; they yield signal>=20 without tau/320 claims.',
 'a:private-chebyshev':'Read full Test: actual MemLp, mean=beta*M, variance<=2M, positive-cutoff event inclusion and finite ofReal-toReal conversion.',
 'root:private-zero-event':'Private zero-threshold diagonal-law event only; not shifted, rotated, full Ex26, TV or a new Anchor.',
 's:generic-cosine-statistic':'Generic source n is arbitrary integer 1<=n<d; the canonical theorem and downstream selection preserve it.',
 's:generic-moment-law':'Actual source precision/covariance and moments are generic; no query/Fin/Bochner prerequisite is invented.'
}
row_judgments=[]
for i,r in enumerate(rows,1):
    selected=bool(r['selected_roots'])
    assert not selected or r['source_node'] in specific
    row_judgments.append({'ordinal':i,'source_node':r['source_node'],
      'input_row_sha256':digest(r),'selected_roots':r['selected_roots'],
      'source_anchors':r['source_anchors'],'claimed_status':r['implementation_status'],
      'judgment':'accepted-bounded-correspondence' if selected else 'accepted-off-root-no-new-credit',
      'independent_reason':specific.get(r['source_node'],
       'Compared with the original source cognition. This off-root source/context/remaining-boundary row is not asserted as newly implemented or as a dependency of the selected result.'),
      'not_claimed':'Compiler-backed exact dependency certificate or whole-source completion.'})
assert len(row_judgments)==92 and sum(bool(r['selected_roots']) for r in row_judgments)==39
write('phase3_row_judgments.json',{'schema':1,'reviewer':'/root/source_reader_a83e10',
 'candidate_commit':COMMIT,'source_map_sha256':sha(E/'source-to-lean-map-v1.json'),
 'rows_reviewed':92,'selected_union':39,'off_root':53,'rows':row_judgments,
 'authority':'Independent source cognition plus complete authorized code/provider reading; correspondence input fields are claims, not prior verdict authority.'})

write('phase3_fullmodule_source_exposition_judgment.json',{
 'schema':1,'reviewer':'/root/source_reader_a83e10','candidate_commit':COMMIT,
 'full_module_read':True,'both_private_scalar_proofs_read':True,'complete_private_test_read':True,
 'canonical_provider_modules_read':['FixedSpectrumModeGap','FixedSpectrumBias','FixedSpectrumExactMeans','FixedSpectrumGaussianMoments','FixedSpectrumCosineExpansion','FixedSpectrumGridAlias','FixedSpectrumVariances','GaussianFourthMoment'],
 'public_binder_judgment':'Only numeric source premises; law/moments/domain/gap/signal/positivity facts are internal dependencies or outputs; no excess public mathematical premise.',
 'literal_definition_judgment':'Exact midpoint inverse-precision Gaussian and actual same-law Bochner means. Full norm and beta normalization agree; PSD/inverse/integrability supplied internally.',
 'private_providers':{
  'spectral_tail_le_third':'Adequate elementary nonstrict r^(2d)<=exp(-2)<=1/3; source strict intermediate not separately emitted.',
  'source_norm_scale_lower':'Positive-domain sqrt/rpow comparison proves exact source norm-power scale; local domains supplied by source regime.'},
 'public_proof_judgment':'Exact source cap, common threshold and same-law Bias/ExactMeans produce both M bounds, positivity and finite B^2 sqrt(d)/2 signal lower.',
 'private_application_judgment':'Actual-law signed-Q zero-event bound proved from an internally enlarged common threshold, actual L2/sign/variance, Chebyshev and finite measure conversion. No shifted-detector credit.',
 'source_correspondence_judgment':'All92 rows reviewed;39 selected. Generic source moment semantics precede selected odd adapter; source-author routes and implementation sufficient endpoints/intermediate exclusions remain distinct.',
 'lesson_steps':[{'step':x['step'],'title':x['title'],'formula_judgment':'mathematically accepted within stated source regime','snippet_exact':x['exact_contiguous_substring'],'full_test_equal':x['full_test_byte_text_equality']} for x in bound['selected_lesson_steps']],
 'publication_scope_judgment':'Prerequisite for selected actual M/signal obligations only; private Test remains NON-ANCHOR. No full Ex24/tau, shifted Ex26, main theorem, oracle/TV/cost or delivery completion.',
 'binding_sha256':BINDING,'reviewer_packet_sha256':PACKET,
 'blocking_deltas':[],'repairs_proposed':[],
 'source_and_exposition_verdict':'PASS_BOUNDED_COMPLETE_MODULE_SOURCE_AND_EXPOSITION_REVIEW',
 'execution_evidence':'None newly executed; no Lean/native/static acceptance/browser/site rerun. Intended kernel code inspected only.',
 'findings':'phase3_findings.md','rows':'phase3_row_judgments.json'})

authorized_evidence=['fresh-source-reviewer-packet.json','source-graph-v2.json',
 'source-unit-dispositions-v2.json','root-closures-v2.json','conditional-discharge-audit-v2.json',
 'source-to-lean-map-v1.json','KernelExactTypesAndAllOwnedBounded.lean']
standard_files={
 '.lake/packages/mathlib/Mathlib/Probability/Distributions/Gaussian/Multivariate.lean':'definitions and evaluation APIs at 158-240',
 '.lake/packages/mathlib/Mathlib/Probability/Distributions/Gaussian/Basic.lean':'IsGaussian and probability instance at 40-56',
 '.lake/packages/mathlib/Mathlib/Probability/Moments/Variance.lean':'variance signatures and Chebyshev at 390-410',
 'tools/astis_publication.py':'bounded digest/binding_payload/review_context rules only; no inputs/load/validation executed',
 'tools/astis_semantic_roundtrip.py':'bounded proposal/source_review field adaptation rules only; no registry or evaluation executed'}
run={
 'schema':1,'reviewer':'/root/source_reader_a83e10','candidate_commit':COMMIT,
 'phase':'phase3-full-producer-private-provider-source-exposition',
 'independent_from_formalizer':True,'independent_from_decoder':True,
 'formalizer_identity_as_supplied':packet['roles']['formalizer'],
 'decoder_identity_as_supplied':packet['roles']['blind_decoder'],
 'phase1_freeze_sha256':P1,'phase2_freeze_sha256':P2,
 'earlier_freezes_all_payloads_reverified_unchanged':True,
 'incidental_older_filename_exposure_disclosed':True,'pristine_zero_exposure_claim':False,
 'derived_scope_extraction_clarification_preserved':True,
 'primary_source_sha256':SOURCE,'source_read_in':'independent phase1 FULL S2/S4/C3 and displayed22 actual DOM bib.bib3',
 'canonical_reviewer_packet_digest_excluding_packet_sha256':PACKET,
 'canonical_reviewer_packet_full_file_sha256':sha(E/'fresh-source-reviewer-packet.json'),
 'publication_binding_sha256':BINDING,'bounded_context_reconstruction_matches':True,
 'whitelisted_candidate_files':bound['whitelisted_candidate_files'],
 'authorized_correspondence_and_intended_audit_code':[{'path':str((E/n).relative_to(ROOT)),'sha256':sha(E/n)} for n in authorized_evidence],
 'minimal_standard_or_helper_reading':[{'path':p,'sha256':sha(ROOT/p),'read_scope':scope} for p,scope in standard_files.items()],
 'own_findings':[{'path':n,'sha256':sha(OUT/n)} for n in ['phase3_findings.md','phase3_row_judgments.json','phase3_fullmodule_source_exposition_judgment.json','phase3_bound_inputs.json']],
 'source_mapping_scope':{'all_rows':92,'selected_union':39,'off_root':53,'public_root_nodes':34,'private_root_nodes':39},
 'lesson_scope':'All six formulas/prose and exact snippets; step6 equals entire Test.',
 'historical_status_text_policy':'Current whitelisted correspondence/lesson claims mentioning H1/H2 or prior review are not mathematical authority; no prior review archive opened.',
 'not_read':['canonical audit shard','Registry completion labels','prior source/topology review archives','other actor findings','root current native/kernel/static results','external cited22 paper content'],
 'not_executed':['Lean build/check','native tests','intended kernel audit','static acceptance gates','browser/site/sourceV checks'],
 'not_mutated':['production files','proofs','sourceV','canonical audit','ledger','frontier','source graph','site','prior freeze'],
 'bounded_computation_only':['explicit whitelist file/commit hashes','exact publication binding and sanitized context reconstruction','literal snippet matching','own frozen identified source-unit mapping projection'],
 'result':'Source/complete-module/exposition review accepted for public selected numerical result plus private zero-event scope only.'}
write('phase3_run_provenance.json',run)
runsha=sha(OUT/'phase3_run_provenance.json')

slots={
 'objects':{
  'relation':'explicit-elaboration',
  'original':'Actual U~N(0,Lambda inverse), midpoint precision spectrum, cosine quadratic, M=E norm(U)^2 and mu_n=E Q(U).',
  'reconstructed':'Literal Fin d reindexing, diagonal Lambda, multivariateGaussian0Lambda inverse and same-law Bochner means M,b; beta=abs(b)/M.',
  'evidence':'Frozen raw-source cognition; complete GaussianMoments/ExactMeans and standard Gaussian definitions show actual covariance and moments, with no project fallback. phase3_findings.md provider closure.'},
 'domains':{
  'relation':'same',
  'original':'Fixed0<delta<1, eventually natural d, real2<=kappa<=d^(1-delta), naturalq<=delta/256 sqrt(kappa)logd, n=2q+1. Generic source moments retain1<=n<d.',
  'reconstructed':'Identical real/natural scalar domain and inclusive endpoints, includingq=0; source finite dimension/mode/gap conditions are produced internally.',
  'evidence':'Complete ModeGap and actual producer/test call sites; generic ExactMeans/Bias/Variances are instantiated downstream, never restricted to odd n as author-source premises.'},
 'quantifiers':{
  'relation':'same',
  'original':'For every fixed delta there is one threshold before every varying d,kappa,q, uniform across the source scalar regime.',
  'reconstructed':'Exists naturald0 after delta and before all d,kappa,q. Private Test enlarges that delta-only witness using an absoluteN chosen before the varying parameters.',
  'evidence':'Producer choosesD before intro d,kappa,q; private choosesmaxD(maxK(N^2)) before intros. Full proofs read; frozen phase2 seven-slot judgment.'},
 'assumptions':{
  'relation':'same',
  'original':'Only numeric source regime for this extracted analytic consequence. Gaussian semantics/moments, gap, positivity and source estimates are proof ingredients, not additional theorem premises.',
  'reconstructed':'Same numeric binders; literal lets supply the law/objects. Every needed finite moment, positive domain, gap, sign and signal fact is internally proved or called from canonical providers.',
  'evidence':'Complete new module plus both private scalar proofs and full Test read. No moment/law/gap/signal/probability certificate input. Named source gaps remain provenance, not binders.'},
 'conclusion':{
  'relation':'equivalent',
  'original':'Selected unnamed M lower estimates and Ex24 signal component: M>=d/(2sqrtkappa)>=d^((1+delta)/2)/2 and M beta^2>=(B^2/2)sqrtd; positive M,beta follow from actual source formulas.',
  'reconstructed':'Exactly five conjuncts: positiveM,positivebeta,both separate M bounds and the exact finite signal inequality. Private actual-lawzero-event probability<=1/10 is a separately scoped local consequence.',
  'evidence':'Complete producer guarded correction/power/bias/product algebra and full private finite-threshold/Chebyshev proof. positivity comes from signed actual mean, not b>0.'},
 'scopes':{
  'relation':'explicit-elaboration',
  'original':'Actual diagonal target means; beta is ratio of expectations with full Euclidean norm. Author shifted rotated detector and full tau/TV/main route have additional obligations.',
  'reconstructed':'Same actual law and normalization. Public result is selected numerical prerequisite only; private event is signedQ<=0 under diagonal law, expressly not shifted or rotated Ex26.',
  'evidence':'All92 correspondence rows/39selected and both roots reviewed against independent source cognition; six-step exposition preserves the zero-event boundary and source-author versus implementation route distinctions.'},
 'constant_dependencies':{
  'relation':'same',
  'original':'Exact capdelta/256, B=(1-exp(-4))*exp(-3)>0, normfactor1/2 and signalB^2/2; threshold depends only ondelta. No epsilon growth.',
  'reconstructed':'Identical coefficients with b=source mu_n and B=source positiveb. Retains3delta/128 before relaxation; privateN>=40/B^2 yields signal20 and probability1/10.',
  'evidence':'Exact proofs/formulas in steps2-6. Elementary nonstrict exp(-2)<=1/3 is sufficient; no separate strict exp(-2)<1/3, full author log intermediate, Tendsto infinity or source320 detector credit is asserted.'}
}
proposal={
 'state':'accepted','semantic_slots':slots,'deltas':[],
 'verdict':'equivalent-after-elaboration',
 'source_review':{
  'state':'accepted','reviewer':'/root/source_reader_a83e10',
  'independent_from_formalizer':True,'independent_from_decoder':True,
  'review_run_sha256':runsha,'reviewer_packet_sha256':PACKET,
  'run_artifact':str((OUT/'phase3_run_provenance.json').relative_to(ROOT)),
  'evidence':'Independent source cognition frozen before candidate exposure; unchanged phase1/phase2 preserved. Complete producer, both private scalar proofs, full actual-law probability Test, all authorized canonical provider bodies, all92 correspondence rows with39selected, both closures, all21 discharge entries and all6 authored formulas/snippets reviewed. Exact current module/Test/lesson/publication/providers match candidate df64aaa6088b6ac88c35696acfed906031964d72; publication binding aa982161b75c7550ba8168b07d4c45218f497e7463c99e250d66012c622de195 recomputed from explicit whitelist; reviewer packet canonical digest verified. Verdict covers only selected public actual-Gaussian numerical M/SNR consequence and PRIVATE diagonal-law signedQ<=0 probability consumer. No shifted detector/main/oracle/TV/cost/sourceV/native/site or whole-paper completion. No reruns of Lean/native/static acceptance/browser checks; intended kernel code inspected only. Incidental older filename exposure and derived-extraction provenance remain explicitly disclosed. See phase3_findings.md and bound row/complete-module/exposition artifacts.',
  'scope':'Bounded complete-module source and mathematical exposition review; no new compiler/execution certification or controlled canonical application.'}}
assert set(proposal)=={'state','semantic_slots','deltas','verdict','source_review'}
assert set(slots)=={'objects','domains','quantifiers','assumptions','conclusion','scopes','constant_dependencies'}
assert all(set(s)=={'relation','original','reconstructed','evidence'} for s in slots.values())
write('phase3_canonical_five_field_proposal.json',proposal)
names=['phase3_findings.md','phase3_row_judgments.json','phase3_fullmodule_source_exposition_judgment.json',
 'phase3_run_provenance.json','phase3_canonical_five_field_proposal.json','phase3_bound_inputs.json',
 'phase3_bound_inputs.py','finalize_phase3.py']
freeze={'schema':1,'phase':'phase3-complete-module-source-exposition-and-five-field-proposal-frozen',
 'reviewer':'/root/source_reader_a83e10','frozen_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'candidate_commit':COMMIT,'primary_source_sha256':SOURCE,
 'phase1_freeze_sha256':P1,'phase2_freeze_sha256':P2,'earlier_payloads_unchanged':True,
 'reviewer_packet_sha256':PACKET,'publication_binding_sha256':BINDING,
 'reviewer_run_sha256':runsha,'proposal_sha256':sha(OUT/'phase3_canonical_five_field_proposal.json'),
 'blocking_deltas':[],'verdict':'equivalent-after-elaboration',
 'files':[{'path':n,'bytes':(OUT/n).stat().st_size,'sha256':sha(OUT/n)} for n in names],
 'canonical_application_performed':False,'production_or_sourceV_mutation':False,
 'execution_claim':'No Lean/native/static acceptance/browser/site rerun; intended kernel audit code read only.',
 'stop_boundary':'Frozen five-field proposal for parent controlled application only.'}
write('phase3.freeze.json',freeze)
freezesha=sha(OUT/'phase3.freeze.json')
(OUT/'phase3.freeze.sha256').write_text(freezesha+'  phase3.freeze.json\n')
for n in names+['phase3.freeze.json','phase3.freeze.sha256']:(OUT/n).chmod(0o444)
print(json.dumps({'freeze_path':str(OUT/'phase3.freeze.json'),'freeze_sha256':freezesha,
 'proposal_path':str(OUT/'phase3_canonical_five_field_proposal.json'),'proposal_sha256':freeze['proposal_sha256'],
 'reviewer_run_sha256':runsha,'verdict':proposal['verdict'],'blocking_deltas':[]},indent=2))
