import hashlib
import json
import subprocess
import time
from pathlib import Path

ROOT = Path('/Users/zhouhuanjian/ASTIS-GC')
OUT = ROOT / 'research-wiki/paper-contributions/GaussianComplexity/affinity-tensorization-semantic-evidence/fresh-source-module-review'
TARGETS = {
    'candidate-source': ['lake', 'env', 'lean', 'AutoSamplingTheory/ExampleCases/GaussianComplexity/AffinityTensorization.lean'],
    'test-source': ['lake', 'env', 'lean', 'Tests/GaussianComplexityAffinityTensorization.lean'],
    'product-parent-source': ['lake', 'env', 'lean', 'AutoSamplingTheory/ExampleCases/GaussianComplexity/ProductDensity.lean'],
    'mixture-parent-source': ['lake', 'env', 'lean', 'AutoSamplingTheory/ExampleCases/GaussianComplexity/MixtureDensities.lean'],
}

def main():
    import concurrent.futures
    def check(item):
        label, cmd = item
        start = time.time()
        source = ROOT / cmd[-1]
        before = hashlib.sha256(source.read_bytes()).hexdigest()
        p = subprocess.run(cmd, cwd=ROOT, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        data = p.stdout.encode()
        log = OUT / (label + '.log')
        log.write_bytes(data)
        rec = {'label': label, 'command': cmd, 'exit_code': p.returncode,
               'elapsed_seconds': time.time()-start, 'source_sha256_before': before,
               'source_sha256_after': hashlib.sha256(source.read_bytes()).hexdigest(),
               'log_path': str(log.relative_to(ROOT)), 'log_sha256': hashlib.sha256(data).hexdigest(),
               'check_kind': 'fresh direct Lean source elaboration; imported dependency oleans reused; not a Lake replay'}
        (OUT / (label+'.receipt.json')).write_text(json.dumps(rec, indent=2)+'\n')
        return rec
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as ex:
        for rec in ex.map(check, TARGETS.items()):
            print(json.dumps(rec), flush=True)

if __name__ == '__main__':
    main()
