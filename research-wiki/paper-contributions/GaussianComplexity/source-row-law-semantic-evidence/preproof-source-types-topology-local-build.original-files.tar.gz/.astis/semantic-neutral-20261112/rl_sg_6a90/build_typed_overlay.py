"""Create a separate exact-type interpretation overlay; import no target code."""
from pathlib import Path
import hashlib
import json

OUT=Path('.astis/semantic-neutral-20261112/rl_sg_6a90')
PACKET=Path('.astis/huanjian-gc-source-row-law-20261112/selective-type-definition-packet.json')
EXPECTED='71806be7febb91c6ea9a847ce022065cec7eebf6b224503663fcbb7921bc5353'
def digest(b): return hashlib.sha256(b).hexdigest()
def read(name): return json.loads((OUT/name).read_text())
def write(name,value): (OUT/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
packet_bytes=PACKET.read_bytes()
assert digest(packet_bytes)==EXPECTED
packet=json.loads(packet_bytes)
for k in ['producer','actual_private_consumer']:
    assert digest(packet[k]['signature'].encode())==packet[k]['signature_sha256']
context=packet['minimal_definition_context']
assert digest(context['literal_current_prints_and_instances'].encode())==context['literal_current_prints_sha256']
for excerpt in context['product_measure_literal_definition_excerpts']:
    assert digest(excerpt['literal_source'].encode())==excerpt['literal_source_sha256']
raw_manifest=read('freeze_manifest.json')
for item in raw_manifest['artifacts']:
    b=Path(item['path']).read_bytes()
    assert len(b)==item['bytes'] and digest(b)==item['sha256'],item['path']
(OUT/'phase2_selective_packet.json').write_bytes(packet_bytes)

common={
 'phase':'TYPED_OVERLAY_FROZEN_ON_RAW_SOURCE',
 'selective_packet':str(PACKET),'selective_packet_sha256':EXPECTED,
 'raw_freeze_manifest_sha256':digest((OUT/'freeze_manifest.json').read_bytes()),
 'statement_seal_sha256':packet['statement_seal_sha256'],
 'producer_signature_sha256':packet['producer']['signature_sha256'],
 'consumer_signature_sha256':packet['actual_private_consumer']['signature_sha256'],
 'root_formalizer_API_pristine':False,
 'authority_boundary':'Exact types and canonical meaning context only; no target implementation/API candidates, proof certificate, independent source-review verdict, process grant, or proof-completion credit.'
}

audit={
 **common,
 'visible_input_binders':[
  {'binder':'d : Nat','classification':'TYPING','source':['S2.SS0.SSS0.Px1.p1','S4.Thmtheorem4'],'meaning':'Natural coordinate count. Positivity is discharged by hq, not an extra input.'},
  {'binder':'q : Nat','classification':'SOURCE','source':['S4.Thmtheorem3','S4.Thmtheorem4','S2.SS0.SSS0.Px4.p1'],'meaning':'Integer nonnegative query budget encoded by Nat. q=0 is retained.'},
  {'binder':'hq : 2*q+1<d','classification':'SOURCE','source':['S4.Thmtheorem4'],'meaning':'Exactly the source range. It implies d>=2 and q+1>=1.'}
 ],
 'let_bindings_are_definitions_not_assumptions':['D','E','Omega','mu','row','r','L','good'],
 'producer_conclusion_quantifier':{'binder':'forall i : Fin d','position':'conclusion','meaning':'Each original physical coordinate row, with source index i.val+1. It does not quantify independent replacement row draws.'},
 'producer_output_expansion':[
  {'field':'MeasurePreserving.measurable','classification':'OUTPUT','meaning':'Measurable(row i), proved by the producer rather than required as a premise.'},
  {'field':'MeasurePreserving.map_eq','classification':'OUTPUT','meaning':'Measure.map(row i)mu=stdGaussian E, proved by the producer rather than required as a premise.'}
 ],
 'excess_binders_in_exact_visible_signatures':[],
 'absent_mathematical_premises':[
  'row law or row measurability', 'joint-row independence','exponential integrability or moment identity',
  'single-row tail','finite union estimate','all-good probability',
  'tau_(d,q)<=1/2','kappa','centering/variance/concentration','oracle/cost claims'
 ],
 'inferred_canonical_instances':{
  'meaning':'Euclidean, measurable-space, finite-dimensional and finite-index structures are canonical for the literal carriers. The packet reports actual standard-Gaussian/product probability and factor sigma-finiteness instances; these are not additional theorem binders.',
  'input_context_sha256':context['literal_current_prints_sha256'],
  'limitation':'Canonical meaning and instance availability do not prove the target row transport or consumer estimate.'
 },
 'definitions':[
  {'object':'D, E','kind':'literal','expansion':'EuclideanSpace Real (Fin d), EuclideanSpace Real (Fin(q+1))','source_meaning':'Finite Euclidean column/row spaces. Squared row norm is the sum of q+1 coordinate squares.','boundary':'No arbitrary chosen geometry or rescaling.'},
  {'object':'Omega','kind':'literal','expansion':'Fin(q+1) -> D','source_meaning':'An outcome is the entire original tuple of q+1 columns.','boundary':'No stdGaussian Omega claim, no replacement by one canonical row, and no arbitrary ambient probability parameter.'},
  {'object':'mu','kind':'literal canonical finite product','expansion':'Measure.pi(fun _ : Fin(q+1) => stdGaussian D)','source_meaning':'Canonical realization of the independent standard d-Gaussian columns.','boundary':'Product interpretation must support the row-law bridge; product definition/instance prints are not a target proof certificate.'},
  {'object':'row i','kind':'literal','expansion':'omega |-> WithLp.toLp 2 (fun a : Fin(q+1) => omega a i)','source_meaning':'The source gamma_i, coordinate by coordinate, with zero-based Fin indices shifted to source one-based labels.','boundary':'No resampling, default value, altered coordinate, or norm normalization.'},
  {'object':'stdGaussian E','kind':'canonical library measure meaning','expansion':'Map of independent gaussianReal 0 1 coordinates through an orthonormal-basis expansion.','source_meaning':'Standard centered Euclidean Gaussian with identity covariance.','boundary':'Physical-coordinate law and the target row pushforward remain actual obligations; an orthonormal-basis definition alone is not their target proof.'},
  {'object':'MeasurePreserving(row i)mu(stdGaussian E)','kind':'output structure','expansion':'Measurable(row i) AND Measure.map(row i)mu=stdGaussian E','source_meaning':'Measurable marginal law transport from the original column experiment.','boundary':'No hidden premise bundle and no family joint-law conclusion.'},
  {'object':'r','kind':'literal','expansion':'Real cast of natural q+1','source_meaning':'Source r=q+1 used as a real scalar in cutoff/moment arithmetic.','boundary':'r>=1 from q:Nat; no r=0 extension.'},
  {'object':'L','kind':'literal','expansion':'2*r+3*Real.log(1000*(d:Real))','source_meaning':'Exact source squared-norm cutoff.','boundary':'hq implies d>=2, so the logarithm argument is positive; no off-source total-log behavior is used.'},
  {'object':'good','kind':'literal','expansion':'{omega | forall i : Fin d, norm(row i omega)^2<=L}','source_meaning':'Source T on the same original product outcome.','boundary':'Complement is a finite union of strict bad events; its measurability must be discharged internally.'},
  {'object':'ENNReal.ofReal(999/1000:Real)','kind':'literal','expansion':'Positive real rational embedded in extended nonnegative reals.','source_meaning':'Exact source 0.999 probability threshold.','boundary':'The positive-part definition of ofReal leaves this positive number unchanged; probability normalization remains mu Omega=1.'}
 ],
 'project_owned_meaning_definitions_introduced':[],
 'fallback_or_characterization_definition_risks':'No new local fallback, witness choice, or characterized/quotient definition is present in these exact signatures.',
 'scope_observation':'The producer covers a canonical product realization of source independent columns; applying it in another ambient coupling still requires that coupling\u2019s actual column-law transport. This signature does not silently prove such a separate ambient theorem.',
 'zero_query_endpoint':{'q':0,'row_dimension':1,'number_of_columns':1,'minimum_d':2,'cutoff':'2+3*log(1000*d)','extra_positive_query_hypothesis':False}
}
write('typed_binder_definition_audit.json',audit)

nodes=[
 {'id':'typed.exact-inputs','kind':'SEALED_SIGNATURE_CONTEXT','meaning':'Natural d,q with source hq:2*q+1<d. Both signatures share this range.','source_nodes':['source.dimension','source.columns']},
 {'id':'typed.column-product-meaning','kind':'CANONICAL_DEFINITION_MEANING','meaning':'Omega is a tuple of q+1 Euclidean d-columns; mu is their finite product standard Gaussian probability measure. Canonical definitions and actual instances are allowed meaning context.','source_nodes':['source.columns']},
 {'id':'obligation.column-realization','kind':'MATHEMATICAL_DEPENDENCY_OBLIGATION','meaning':'Establish the relevant independent-column standard-law properties of this exact product realization; do not treat a definition excerpt as the new row-law certificate.','source_nodes':['source.columns','gap.fixed-row-coordinate-law']},
 {'id':'typed.literal-row','kind':'CANONICAL_DEFINITION_MEANING','meaning':'row i reads coordinate i of every original column at the same omega, rewrapped into E. Source gamma_i with shifted Fin labels.','source_nodes':['source.row']},
 {'id':'obligation.row-measurable','kind':'PRODUCER_OUTPUT_OBLIGATION','meaning':'Measurable(row i) for every original i. This is an output, not an assumed regularity field.','source_nodes':['gap.fixed-row-coordinate-law','inference.row-marginal']},
 {'id':'obligation.row-pushforward','kind':'PRODUCER_OUTPUT_OBLIGATION','meaning':'Measure.map(row i)mu=stdGaussian E for each i, using the actual product-column law and coordinate standard-Gaussian meaning.','source_nodes':['gap.fixed-row-coordinate-law','inference.row-marginal']},
 {'id':'target.producer','kind':'SEALED_PRODUCER_TARGET','name':packet['producer']['name'],'signature_sha256':packet['producer']['signature_sha256'],'meaning':'Both measurable and map_eq output fields for every original row. No joint-row assertion.','source_nodes':['inference.row-marginal']},
 {'id':'typed.literal-cutoff-event','kind':'CANONICAL_DEFINITION_MEANING','meaning':'r=Real(q+1); L=2*r+3*log(1000*d); good is all rows having squared Euclidean norm<=L on the same omega.','source_nodes':['source.radius-cutoff','source.good-event']},
 {'id':'obligation.canonical-exp-integrable','kind':'MATHEMATICAL_DEPENDENCY_OBLIGATION','meaning':'Integrability of z |-> exp(norm(z)^2/3) under stdGaussian E at actual dimension q+1. Packet gives no exact theorem statement to certify applicability.','source_nodes':['gap.exp-moment-calculation']},
 {'id':'obligation.canonical-exp-moment','kind':'MATHEMATICAL_DEPENDENCY_OBLIGATION','meaning':'Canonical exponential integral equals 3^(r/2). Source prints the resulting row identity but not the integral calculation; cited existing-result applicability is still to be supplied.','source_nodes':['source.exp-moment','gap.exp-moment-calculation']},
 {'id':'obligation.transport-row-integral','kind':'MATHEMATICAL_DEPENDENCY_OBLIGATION','meaning':'Use the actual producer output to transport integrability and the exact exponential moment to each row under mu.','source_nodes':['source.exp-moment']},
 {'id':'obligation.strict-row-tail','kind':'MATHEMATICAL_DEPENDENCY_OBLIGATION','meaning':'Internal source Markov estimate for strict R_i>2*r+3*x, x>=0, with the printed (log3)/2<2/3 constant.','source_nodes':['source.markov','source.log-constant','source.single-row-tail']},
 {'id':'obligation.original-cutoff-tail','kind':'MATHEMATICAL_DEPENDENCY_OBLIGATION','meaning':'At x=log(1000*d)>=0, each original bad-row event has mu probability<=1/(1000*d).','source_nodes':['inference.original-cutoff-tail']},
 {'id':'obligation.finite-bad-union','kind':'MATHEMATICAL_DEPENDENCY_OBLIGATION','meaning':'Finite union of exactly d strict bad events has mu probability<=d/(1000*d)=1/1000; no joint-row independence.','source_nodes':['inference.any-bad-row']},
 {'id':'obligation.good-complement','kind':'MATHEMATICAL_DEPENDENCY_OBLIGATION','meaning':'Measurable good is the complement of the strict bad union; mu is a probability measure. Convert to the exact positive ENNReal threshold.','source_nodes':['source.good-event']},
 {'id':'target.consumer','kind':'SEALED_PRIVATE_CONSUMER_TARGET','name':packet['actual_private_consumer']['name'],'signature_sha256':packet['actual_private_consumer']['signature_sha256'],'meaning':'ENNReal.ofReal(999/1000)<=mu good in the same column-product experiment; preferred source anchor is the printed p10 good-event consequence.','source_nodes':['source.good-event']},
 {'id':'typed.joint-rows-excluded','kind':'EXCLUDED_PROOF_BOUNDARY','meaning':'Source full joint-row independence is preserved as context, not inferred from target.producer and not needed for the finite union.','source_nodes':['context.joint-row-law']},
 {'id':'typed.other-claims-excluded','kind':'EXCLUDED_PROOF_BOUNDARY','meaning':'No shifted-tail bias, centering, matrix norm/variance, concentration, main theorem, oracle or cost claim.','source_nodes':['context.shifted-tail-bias','context.actual-later-use']}
]

edges=[
 (['typed.exact-inputs','typed.column-product-meaning'],'obligation.column-realization','Producer fixed-row law','Product realization is a mathematical law fact, not a new assumption.'),
 (['obligation.column-realization','typed.literal-row'],'obligation.row-measurable','Producer measurable output','Finite coordinate row map must be measurable on the actual product measurable space.'),
 (['obligation.column-realization','typed.literal-row'],'obligation.row-pushforward','Producer map_eq output','Fixed-coordinate column marginals and column independence identify the canonical E-law.'),
 (['obligation.row-measurable','obligation.row-pushforward'],'target.producer','Producer exact signature','Both structure fields are conclusions; neither is supplied as a public premise.'),
 (['typed.exact-inputs','typed.literal-cutoff-event'],'obligation.canonical-exp-integrable','Consumer source exponential ingredient','q+1>=1; exact coefficient1/3 and canonical row measure must match the dependency.'),
 (['obligation.canonical-exp-integrable'],'obligation.canonical-exp-moment','Consumer source exponential ingredient','Exact Gaussian integral calculation/applicable existing statement remains required.'),
 (['target.producer','obligation.canonical-exp-integrable','obligation.canonical-exp-moment'],'obligation.transport-row-integral','Consumer p10 moment use','Material use of the actual producer; transported integrability and integral live under mu.'),
 (['obligation.transport-row-integral','typed.literal-cutoff-event'],'obligation.strict-row-tail','Consumer source Ex104','Nonnegative exponential; positive Markov threshold; x>=0; source numerical log inequality.'),
 (['obligation.strict-row-tail','typed.exact-inputs','typed.literal-cutoff-event'],'obligation.original-cutoff-tail','Consumer p10 all-good consequence','hq gives integer d>=2; x=log(1000*d)>=0; threshold exactly L.'),
 (['obligation.original-cutoff-tail'],'obligation.finite-bad-union','Consumer p10 all-good consequence','d measurable original bad events; finite union subadditivity, no independence premise.'),
 (['obligation.finite-bad-union','target.producer','typed.column-product-meaning','typed.literal-cutoff-event'],'obligation.good-complement','Consumer p10 printed good event','Producer measurable output supports radius/event measurability; all<=L complements exists>L; mu total mass1.'),
 (['obligation.good-complement'],'target.consumer','Consumer exact signature','999/1000 positive rational and ENNReal.ofReal preserve the printed0.999 normalization.')
]
write('typed_source_graph.json',{
 **common,
 'raw_graph_path':str(OUT/'raw_source_graph.json'),
 'raw_graph_sha256':digest((OUT/'raw_source_graph.json').read_bytes()),
 'raw_graph_is_unchanged':True,
 'nodes':nodes,
 'edges':[{'from':a,'to':b,'consumer_use_site':c,'conditions_to_discharge_internally':d,'edge_kind':'dependency/meaning overlay, never a new public binder'} for a,b,c,d in edges],
 'forbidden_inferences':[
  'Marginal row laws imply full joint-row independence.',
  'Canonical one-row probability alone is already an original-column union estimate.',
  'A product-definition or probability-instance print certifies the target row-law proof.',
  'The consumer may assume its moment/tail/union or producer outputs as extra public hypotheses.'
 ],
 'gap_list':[
  'Canonical product-column realization and physical-coordinate row law, including measurability output.',
  'Canonical exponential integrability and exact moment applicability at coefficient1/3 and dimension q+1; exact dependency statement is not in the selective packet.',
  'Transport of integrability/moment to each original row using the producer.',
  'Strict Markov tail, source-cutoff substitution, finite bad union, measurable complement and exact probability arithmetic.'
 ]
})

raw_inventory=read('bounded_inventory.json')
def typed_mapping(atom):
    ident=atom['source_id']
    if atom['region']=='A3.SS2.p1':
        if ident in ['A3.SS2.p1.m4','A3.SS2.p1.m5']:
            return {'nodes':['typed.joint-rows-excluded'],'meaning':'Printed joint assertion stays excluded; its fixed-row marginal component is separately represented by the producer output.'}
        if atom['disposition']=='EXCLUDED':
            return {'nodes':['typed.other-claims-excluded'],'meaning':'Frequency or tensor context remains excluded from this target.'}
        return {'nodes':['typed.literal-row','obligation.row-measurable','obligation.row-pushforward','target.producer'],'meaning':'Original row construction; combined display retains the excluded cosine-vector companion. No joint claim is promoted.'}
    if atom['region']=='A3.SS2.p10':
        if ident=='A3.SS2.p10.m1': names=['typed.literal-cutoff-event']
        elif ident=='A3.SS2.p10.m2': names=['typed.literal-row','typed.literal-cutoff-event']
        elif ident=='A3.SS2.p10.m3': names=['obligation.canonical-exp-integrable','obligation.canonical-exp-moment','obligation.transport-row-integral']
        elif ident in ['A3.SS2.p10.m4','A3.Ex104','A3.Ex104.m1','A3.SS2.p10.m5']: names=['obligation.strict-row-tail']
        elif ident in ['A3.Ex105','A3.Ex105.m1']: names=['typed.literal-cutoff-event','obligation.good-complement']
        elif ident in ['A3.SS2.p10.3','A3.SS2.p10.m6']: names=['obligation.original-cutoff-tail','obligation.finite-bad-union','obligation.good-complement','target.consumer']
        else: names=['obligation.transport-row-integral','obligation.strict-row-tail','obligation.original-cutoff-tail','obligation.finite-bad-union','obligation.good-complement']
        return {'nodes':names,'meaning':'Printed p10 ingredient/consequence, with original-experiment union bookkeeping explicitly inferred and discharged internally.'}
    return {'nodes':['typed.other-claims-excluded'],'meaning':atom['reason_or_scope']}

typed_atoms=[]
for atom in raw_inventory['source_atoms']:
    typed_atoms.append({**atom,'raw_disposition_preserved':True,'typed_overlay':typed_mapping(atom)})
write('typed_coverage.json',{
 **common,
 'raw_inventory_sha256':digest((OUT/'bounded_inventory.json').read_bytes()),
 'source_scope':raw_inventory['scope'],
 'source_regions':raw_inventory['regions'],
 'semantic_component_inventory':raw_inventory['semantic_component_inventory'],
 'all_source_atoms':typed_atoms,
 'linked_references':raw_inventory['linked_references'],
 'named_unlinked_external_input':raw_inventory['named_unlinked_external_input'],
 'unread_or_unexpanded_regions':raw_inventory['unread_or_unexpanded_regions'],
 'counts':raw_inventory['exhaustiveness_check'],
 'all_raw_atom_dispositions_preserved':True,
 'new_source_inferences_promoted_to_printed':False,
 'source_location_file':str(OUT/'locators.json'),
 'source_location_file_sha256':digest((OUT/'locators.json').read_bytes()),
 'auxiliary_anchors':[
  {'anchor':'S4.Thmtheorem4','meaning':'Source Gaussian columns/range. Final tau hypothesis is not imported into the row-law or scalar event target.'},
  {'anchor':'S4.Thmtheorem3','meaning':'Explicit integer query range corroborates Nat q.'},
  {'anchor':'S2.SS0.SSS0.Px1.p1','meaning':'Integer dimension convention.'},
  {'anchor':'S2.SS0.SSS0.Px4.p1','meaning':'Nonnegative integer deterministic query budgets.'},
  {'anchor':'A3.SS2.p12','disposition':'EXCLUDED','meaning':'Later truncated-matrix independence/centering/radial bias is not provided by these types.'},
  {'anchor':'A3.SS2.p17','disposition':'EXCLUDED','meaning':'Later use of T confirms same original experiment, with no concentration or matrix proof credit.'}
 ]
})

write('typed_overlay.json',{
 **common,
 'producer':packet['producer'],
 'actual_private_consumer':packet['actual_private_consumer'],
 'definition_context_sha256':packet['minimal_definition_context_sha256'],
 'definition_prints_sha256':context['literal_current_prints_sha256'],
 'raw_source_interpretation_sha256':digest((OUT/'raw_interpretation.md').read_bytes()),
 'interpretation':'See typed_interpretation.md; exact types select the source canonical column-product realization and retain source q=0, with both producer fields as outputs and the all-good event in the same experiment.',
 'audit_path':str(OUT/'typed_binder_definition_audit.json'),
 'graph_path':str(OUT/'typed_source_graph.json'),
 'coverage_path':str(OUT/'typed_coverage.json'),
 'new_mismatch_identified_in_visible_types':False,
 'remaining_gaps':'Visible exact-type correspondence is not proof closure. Mathematical dependencies are explicitly open in typed_source_graph.json and typed_interpretation.md.',
 'raw_source_joint_assertion_status':'Preserved as stronger printed context and excluded from narrow proof credit; not inferred from marginal outputs.'
})

graph=json.loads((OUT/'typed_source_graph.json').read_text())
ids={n['id'] for n in graph['nodes']}
raw_graph=read('raw_source_graph.json')
rawids={n['id'] for n in raw_graph['nodes']}
for n in graph['nodes']: assert all(x in rawids for x in n['source_nodes'])
for e in graph['edges']:
    assert e['to'] in ids and all(x in ids for x in e['from'])
for a,b in zip(raw_inventory['source_atoms'],typed_atoms):
    assert a['source_id']==b['source_id'] and a['disposition']==b['disposition']
    assert all(x in ids for x in b['typed_overlay']['nodes'])
assert len(raw_inventory['source_atoms'])==len(typed_atoms)==145
for item in raw_manifest['artifacts']:
    assert digest(Path(item['path']).read_bytes())==item['sha256']
write('typed_integrity_checks.json',{
 **common,
 'checks_passed':[
  'Exact selective input bytes/hash verified.',
  'Both exact signature-string hashes verified.',
  'Canonical print-string and product-definition excerpt hashes verified.',
  'Every raw frozen artifact rehashed unchanged before and after typed overlay generation.',
  'All145 raw atom IDs/dispositions are preserved one-to-one with typed mapping.',
  'Typed graph nodes refer only to existing raw source nodes; all typed edge/mapping endpoints resolve.'
 ],
 'not_a_mathematical_proof_or_independent_review':True
})

artifacts=['phase2_selective_packet.json','typed_interpretation.md','typed_overlay.json','typed_source_graph.json','typed_binder_definition_audit.json','typed_coverage.json','typed_integrity_checks.json','build_typed_overlay.py']
write('typed_freeze_manifest.json',{
 **common,
 'new_artifacts':[{'path':str(OUT/x),'bytes':len((OUT/x).read_bytes()),'sha256':digest((OUT/x).read_bytes())} for x in artifacts],
 'phase2_input_access':[
  str(PACKET),str(OUT/'freeze_manifest.json'),
  'Own raw artifacts explicitly bound in freeze_manifest.json; rehashed, not revised.'
 ],
 'phase2_no_reads':['target implementation or API candidates','root proof history','TC reports','old verdicts or decoder content','ledger','underlying definition receipts or Mathlib files beyond the selective packet excerpts'],
 'raw_filename_only_exposure_disclosure':'Initial rg --files for AGENTS/SKILL unintentionally listed prior audit filenames (names only, no contents opened); all subsequent reads are exact mandatory instructions and pinned source only.',
 'exposure_scope_note':'The preceding disclosure describes phase1. In phase2 this role intentionally read the exact selective types/canonical definitions after raw freeze; it is not serving as a source-blind decoder.',
 'raw_artifacts_unchanged':True,
 'freeze_policy':'Preserve this typed interpretation and raw originals. Later implementation/review changes require explicitly hashed successor overlays; no proof or process grant follows from this freeze.'
})
for name in ['typed_source_graph.json','typed_binder_definition_audit.json','typed_coverage.json','typed_overlay.json','typed_freeze_manifest.json']:
    print(digest((OUT/name).read_bytes())+'  '+str(OUT/name))
