from pathlib import Path
from hashlib import sha256
from bs4 import BeautifulSoup
p=Path('.astis/huanjian-resume-20261103/2610.20492v1.html')
b=p.read_bytes()
s=BeautifulSoup(b,'html.parser')
for ident in ['S4.SS1','S4.SS2.SSS0.Px1','S4.SS2.SSS0.Px2']:
 e=s.find(id=ident)
 print('\nANCHOR',ident)
 print(e.get_text(' ',strip=True))
 print('PARAGRAPH_AND_DISPLAY_IDS',[(c.name,c.get('id')) for c in e.find_all(id=True) if c.name in ['div','p','table','tbody']])
