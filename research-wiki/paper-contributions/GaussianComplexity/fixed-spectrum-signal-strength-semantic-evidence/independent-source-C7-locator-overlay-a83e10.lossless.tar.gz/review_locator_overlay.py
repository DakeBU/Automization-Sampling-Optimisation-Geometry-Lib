from pathlib import Path
import datetime,hashlib,json,copy
ROOT=Path('/Users/zhouhuanjian/ASTIS-GC')
BASE=ROOT/'.astis/semantic-neutral-20261110/src_a83e10'
OUT=BASE/'locator_precision_overlay'
E=ROOT/'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-signal-strength-semantic-evidence'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text())
def write(n,v):(OUT/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
proposalpath=E/'exact-C7-locator-precision-overlay-proposal.json'
newpath=E/'source-to-lean-map-v2-exact-C7-locators.json'
oldpath=E/'source-to-lean-map-v1.json'
assert sha(proposalpath)=='0d308e333a518f8a44dd94aabf847d68b662b1bb9ccfa9710c2c052749385ee0'
assert sha(newpath)=='7c7f501685077eb30ee9d6160a69046039404034ce429146783509f1a27303bc'
assert sha(oldpath)=='e98394470a5ae8e6c3d82896112005a9adf5401506450a618498bf8f25d898a0'
p=load(proposalpath); old=load(oldpath); new=load(newpath)
# Compare JSON values without displaying or using preexisting source_review content.
changes=[]
def difference(a,b,path=''):
    if type(a)!=type(b):
        changes.append({'path':path,'before':a,'after':b});return
    if isinstance(a,dict):
        assert set(a)==set(b), 'Unexpected key-set mutation at '+path
        for k in a:
            if k=='source_review':
                assert a[k]==b[k], 'Existing source_review field changed'
            else:difference(a[k],b[k],path+'/'+k)
    elif isinstance(a,list):
        assert len(a)==len(b), 'Unexpected list-length mutation at '+path
        for i,(x,y) in enumerate(zip(a,b)):difference(x,y,path+'/'+str(i))
    elif a!=b:changes.append({'path':path,'before':a,'after':b})
difference(old,new)
assert changes==p['changes']
assert len(changes)==10
expected_indices=[53,54,55,56,70]
expected_nodes=['c:c7','c:geometric','c:rho-algebra','c:majorant','gap:geometric-series']
assert len(old['rows'])==len(new['rows'])==92
assert [new['rows'][i]['source_node'] for i in expected_indices]==expected_nodes
providerpath=ROOT/'AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumCosineExpansion.lean'
providerhash=sha(providerpath)
assert providerhash=='659d6baf40abad2c48e7fced98c6c46a07624817cf14ef2de5a8146e82522de7'
lines=providerpath.read_text().splitlines()
assert lines[74].startswith('theorem actual_inverse_spectrum_cosine_expansion ')
assert lines[14].startswith('private theorem radius_bounds ')
for i in expected_indices:
    assert old['rows'][i]['providers'][0]['line']==15
    assert old['rows'][i]['providers'][0]['marker']=='theorem '
    assert new['rows'][i]['providers'][0]['line']==75
    assert new['rows'][i]['providers'][0]['marker']=='theorem actual_inverse_spectrum_cosine_expansion'
    assert new['rows'][i]['providers'][0]['full_file_sha256']==providerhash
restored=copy.deepcopy(new)
for c in changes:
    keys=c['path'].strip('/').split('/'); v=restored
    for k in keys[:-1]:v=v[int(k)] if isinstance(v,list) else v[k]
    last=keys[-1]
    if isinstance(v,list):v[int(last)]=c['before']
    else:v[last]=c['before']
assert restored==old
frozen=[]
for name,expected in [('phase1.freeze.json','f4b7e781a584005ade0a21cb0d1df46b1d154b9b94df33d2f83bced7ffe9f822'),
 ('phase2.freeze.json','951a69f26cb0f2e4f58a644a7e57f081c593d8b62da6093c0a88dfbc7e30e9e9'),
 ('phase3.freeze.json','70eb35cfe123ea3a4a7b6da8f5797824295461d634b116ca1a82e7e549a59c28')]:
    assert sha(BASE/name)==expected
    f=load(BASE/name)
    assert all(sha(BASE/x['path'])==x['sha256'] for x in f['files'])
    frozen.append({'path':name,'sha256':expected,'all_payloads_unchanged':True})
assert sha(BASE/'phase3_canonical_five_field_proposal.json')=='f05c4af13db556783d31b1ffe49e1670073e9e8d2a6a88fd26f18d0a448bbcf7'
filehashchecks=[]
for path,expected in p['current_unchanged_mathematical_files'].items():
    actual=sha(ROOT/path)
    assert actual==expected
    filehashchecks.append({'path':path,'sha256':actual,'matches_pinned_proposal':True,'contents_not_newly_inspected':True})
checks={'scope':'Metadata/locator precision only; direct bounded JSON differences, hash and line reads, with no static acceptance gate.',
 'input_pins_match':True,'old_map_unchanged':True,'row_count':92,
 'exact_field_change_count':10,'changes':changes,'changed_rows':expected_nodes,
 'only_line_and_marker_fields_change':True,'same_provider_file_and_full_file_sha256':True,
 'old_line15':lines[14],'new_line75':lines[74],
 'inverse_restores_exact_old_JSON_value':restored==old,
 'source_review_field_unchanged_and_not_used_as_evidence':True,
 'source_and_provider_dependency_fields_unchanged':True,
 'mathematical_file_hashes':filehashchecks,'earlier_freezes':frozen,
 'original_five_field_proposal_unchanged':True}
write('checks.json',checks)
judgment={'reviewer':'/root/source_reader_a83e10','review_kind':'separate locator-precision overlay',
 'decision':'ACCEPT_METADATA_LOCATOR_PRECISION_ONLY','blocking_deltas':[],
 'reason':'Exactly five closure locators now identify the public inverse-spectrum cosine-expansion theorem at actual line75 rather than a generic theorem substring matching private radius_bounds at line15. The public theorem and its complete already-reviewed private provider closure remain in the same hash-pinned module. This improves locator precision while preserving source correspondence meaning.',
 'source_rows':expected_nodes,'field_changes':10,
 'mathematical_meaning_change':False,'provider_dependency_change':False,
 'source_proposition_status_or_binding_change':False,
 'relation_to_original_review':'Original Phase3 mathematical/source/exposition verdict equivalent-after-elaboration and its exact five-field proposal remain byte-exact, valid within their original bounded scope, and are neither revised nor replaced. This overlay supplies no additional mathematical or completion credit.',
 'retained_limits':'Public selected actual-Gaussian numerical norm/SNR and PRIVATE diagonal-law zero-event scope only; no shifted detector, Ex26, main theorem, oracle/TV/cost/sourceV/native/site completion.',
 'exposure_and_provenance':'Phase1 incidental older filename-only exposure remains disclosed. BeautifulSoup scope artifacts remain derived extractions; the full original HTML SHA6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915 is primary source authority.',
 'canonical_application_performed':False}
write('judgment.json',judgment)
run={'reviewer':'/root/source_reader_a83e10','scope':'Separate tiny metadata/source-correspondence locator review after original full mathematical verdict.',
 'inputs':[{'path':str(x.relative_to(ROOT)),'sha256':sha(x)} for x in [proposalpath,newpath,oldpath,providerpath]],
 'old_review_preservation':frozen,
 'original_five_field_proposal_sha256':'f05c4af13db556783d31b1ffe49e1670073e9e8d2a6a88fd26f18d0a448bbcf7',
 'read_limits':'No other actor verdicts read. Existing source_review value compared for equality only, never displayed or treated as authority. Provider newly read only to resolve line15/75 and current hash.',
 'checks_sha256':sha(OUT/'checks.json'),'judgment_sha256':sha(OUT/'judgment.json'),
 'not_executed':['compiler','Lean','native','static acceptance gate','browser','canonical/ledger/frontier/sourceV calls'],
 'not_mutated':['all phase1/2/3 files','original five canonical proposal fields','production/source/proof/Test/lesson/publication','canonical/audit/ledger/frontier/sourceV'],
 'result':'Accepted locator-only overlay; no residual blocker and no revision/replacement of original mathematical verdict.'}
write('run.json',run)
names=['review_locator_overlay.py','checks.json','judgment.json','run.json']
freeze={'reviewer':'/root/source_reader_a83e10','phase':'separate-locator-precision-overlay-frozen',
 'frozen_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'original_phase3_freeze_sha256':'70eb35cfe123ea3a4a7b6da8f5797824295461d634b116ca1a82e7e549a59c28',
 'original_proposal_sha256':'f05c4af13db556783d31b1ffe49e1670073e9e8d2a6a88fd26f18d0a448bbcf7',
 'original_review_revised_or_replaced':False,'decision':judgment['decision'],'residual_blockers':[],
 'run_sha256':sha(OUT/'run.json'),'judgment_sha256':sha(OUT/'judgment.json'),
 'files':[{'path':n,'bytes':(OUT/n).stat().st_size,'sha256':sha(OUT/n)} for n in names]}
write('freeze.json',freeze)
digest=sha(OUT/'freeze.json')
(OUT/'freeze.sha256').write_text(digest+'  freeze.json\n')
for n in names+['freeze.json','freeze.sha256']:(OUT/n).chmod(0o444)
print(json.dumps({'freeze_path':str(OUT/'freeze.json'),'freeze_sha256':digest,
 'run_sha256':freeze['run_sha256'],'judgment_sha256':freeze['judgment_sha256'],
 'residual_blockers':[],'original_full_mathematical_review':'unchanged; not revised or replaced'},indent=2))
