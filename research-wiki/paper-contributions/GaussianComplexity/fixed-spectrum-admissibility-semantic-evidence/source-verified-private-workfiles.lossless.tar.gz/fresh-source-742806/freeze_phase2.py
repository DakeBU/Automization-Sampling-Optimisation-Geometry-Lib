from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json

ROOT = Path('/Users/zhouhuanjian/ASTIS-GC')
BASE = ROOT / 'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-admissibility-semantic-evidence'
PRIOR = BASE / 'fresh-source-reader-742806/phase1'
OUT = BASE / 'fresh-source-reader-742806/phase2'
INPUT = BASE / 'phase2-selective-input.json'
EXPECTED_INPUT = '97e17ebbba605f053397adfb9ee5b2d0c425e95edbd9dab5b0804b9b098ede53'
EXPECTED_PRIOR = '146f481aaf35414e07619113050d547e8a75c85da2d868571f7f4a19c05fa50c'

def sha(b):
    return hashlib.sha256(b).hexdigest()

def write_json(p, data):
    p.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')

input_bytes = INPUT.read_bytes()
assert sha(input_bytes) == EXPECTED_INPUT
assert sha((PRIOR / 'manifest.json').read_bytes()) == EXPECTED_PRIOR
prior_manifest = json.loads((PRIOR / 'manifest.json').read_text())
for f in prior_manifest['files']:
    assert sha((PRIOR / f['path']).read_bytes()) == f['sha256']
packet = json.loads(input_bytes)
anonymous = packet['anonymous_decoder_packet']
lean = anonymous['lean']
reconstruction = packet['blind_reconstruction']
assert len(lean['approved_definition_context']) == 5
assert sha(lean['statement'].encode()) == lean['statement_sha256']
assert sha(reconstruction['reconstructed_theorem_text'].encode()) == reconstruction['reconstructed_text_sha256']
assert anonymous['packet_sha256'] == reconstruction['packet_sha256'] == reconstruction['input_canonical_packet_sha256']
assert reconstruction['source_text_visible'] is False
assert reconstruction['source_equivalence_judged'] is False
OUT.mkdir(parents=True, exist_ok=False)
(OUT / 'raw-inputs').mkdir()
(OUT / 'raw-inputs/selective-input.raw.json').write_bytes(input_bytes)
(OUT / 'anonymous-statement.extracted.txt').write_text(lean['statement'])
(OUT / 'blind-reconstruction.extracted.txt').write_text(reconstruction['reconstructed_theorem_text'])
write_json(OUT / 'approved-context.extracted.json', lean['approved_definition_context'])

comparison = {
    'reviewer_id': 'fresh-source-reader-742806',
    'phase': '2-selective-source-vs-statement-and-independent-reconstruction',
    'phase1_manifest_sha256': EXPECTED_PRIOR,
    'selective_input_raw_sha256': EXPECTED_INPUT,
    'seven_semantic_slots': {
        'objects': {
            'source': 'Eq. (11) theta_i, lambda_i, Lambda; full real orthogonal O; actual rotated precision A=O Lambda O^T; identities and Loewner bounds.',
            'anonymous_and_decoder': 'The local theta and A definitions explicitly form O times the exact cosine diagonal times O.transpose. Matrix numeral 1 is identity and kappa • 1 is kappa times identity. Decoder reconstructs the same objects.',
            'comparison': 'same for the short Lemma 4.6. Candidate explicit PosDef is an output about this actual A. The actual precision producer is not replaced by an arbitrary already-admissible matrix.',
            'source_scope_limit': 'No potential V_A, target N(0,A^{-1}) or normalizer Z_A object is in this statement.',
            'blocking_delta_for_short_lemma': False
        },
        'domains': {
            'source': 'Integer d>=2, real kappa>=2, source indices 1,...,d, real d-by-d matrices and full O(d), including either determinant sign; all real vectors for Loewner order.',
            'anonymous_and_decoder': 'd:Nat with hd:2<=d; kappa:Real with h_kappa:2<=kappa; i:Fin d is zero-based; O:Matrix.orthogonalGroup (Fin d) Real. Approved context explicitly supplies full O(d), both transpose products and both determinant signs. PSD/PD are over finitely supported real coordinate vectors.',
            'comparison': 'same finite-dimensional real domain. Since Fin d is finite, every coordinate vector has finite support, so no vector restriction is introduced.',
            'reindexing': 'Source index j=i.val+1 gives (j-1/2)pi/d=(i.val+1/2)pi/d; the displayed diagonal order is preserved under this coordinate relabeling.',
            'blocking_delta_for_short_lemma': False
        },
        'quantifiers': {
            'source': 'For every allowed d,kappa, fix their exact grid and then for every O in full O(d), the same A is admissible; quadratic-form order is universal over every vector.',
            'anonymous_and_decoder': 'Universal d and kappa with their source bounds, universal O; theta and A are lets inside this scope. All three conjuncts refer to the same locally defined A. PSD covers every vector and PD every nonzero vector.',
            'comparison': 'same. No existential grid choice, selected orientation, Haar-a.s. weakening, probability law, algorithm or query-budget restriction is introduced.',
            'blocking_delta_for_short_lemma': False
        },
        'assumptions': {
            'source': 'Source-standing d>=2,kappa>=2, exact grid, real carriers, and orthogonality. Positive definiteness, spectral bounds and admissibility are consequences, not extra inputs.',
            'anonymous_and_decoder': 'Only hd:2<=d, h_kappa:2<=kappa, and O in full orthogonal group are input restrictions. The exact grid and A are local literal definitions. A.PosDef, (A-1).PosSemidef and (kappa•1-A).PosSemidef occur to the right as a conclusion conjunction.',
            'binder_classification': [
                {'binder': 'd:Nat and kappa:Real', 'classification': 'TYPING'},
                {'binder': 'hd:2<=d', 'classification': 'SOURCE-standing family range'},
                {'binder': 'h_kappa:2<=kappa', 'classification': 'SOURCE-standing family range'},
                {'binder': 'O:full orthogonal group', 'classification': 'SOURCE orthogonality encoded by carrier'},
                {'binder': 'theta and A lets', 'classification': 'literal source construction, not premises'}
            ],
            'comparison': 'No EXCESS premise is visible in the selective statement. In particular produced PosDef is not assumed, and no supplied producer-bound certificate is passed as a theorem hypothesis.',
            'blocking_delta_for_short_lemma': False
        },
        'conclusion': {
            'source': 'Short Lemma 4.6: I_d<=A<=kappa I_d. C.4 additionally derives smooth quadratic potential, unique minimizer, actual inverse-covariance Gaussian and Gaussian normalizer.',
            'anonymous_and_decoder': 'A.PosDef and A-I_d positive semidefinite and kappa I_d-A positive semidefinite. Approved definitions make the latter two exactly the lower and upper quadratic-form/Loewner bounds; Hermitian means real symmetry.',
            'comparison': 'Equivalent to the short source lemma on this domain. Explicit positive definiteness is redundant semantic strengthening of the written conclusion: source lower bound x^T A x>=||x||^2 gives strict positivity for nonzero real x. It is also consistent with C.4 strict eigenvalue discussion.',
            'source_scope_limit': 'No Gaussian target identity, potential regularity/minimizer statement, determinant identity or normalization integral follows as an asserted interface of this selective statement alone. Their mathematical derivability must not be confused with having reviewed their actual implementation/publication.',
            'blocking_delta_for_short_lemma': False,
            'full_C4_coverage': 'not supplied by this statement'
        },
        'scopes_senses': {
            'source': 'Loewner/quadratic-form matrix order, not entrywise comparison; full real half-grid; pointwise admissibility; exact construction; actual Gaussian target and Lebesgue normalizer remain separate full-C.4 scope.',
            'anonymous_and_decoder': 'Matrix subtraction and real scalar multiplication are explicit. Real type for theta forces 1/2 to be real one-half and i.val,d to be real casts; it is not natural-number division. hd implies the cast d is nonzero despite real division totalization. Finite support is exhaustive on Fin d. Decoder explicitly preserves all these senses.',
            'comparison': 'same for the short source result. The anonymous statement is deterministic and makes no target-measure or sampling assertion.',
            'sensitive_checks': {
                'full_O_both_signs': 'preserved by approved orthogonal-group context',
                'all_finite_support_quadratic_forms': 'all real coordinate vectors, since Fin d finite',
                'real_half_grid': 'preserved literally after source index shift',
                'produced_PosDef': 'conclusion, not binder',
                'precision_vs_covariance': 'A is the source precision; no covariance object is asserted here',
                'Gaussian_exponent_measure': 'not asserted in candidate; phase1 exp(-x^T A x/2), Lebesgue dx contract remains for later full-C.4 claims'
            },
            'blocking_delta_for_short_lemma': False
        },
        'constant_dependencies': {
            'source': 'theta depends on d,i; lambda on d,kappa,i; A on d,kappa,O. Bounds exactly 1,kappa. No large-d threshold, delta or epsilon for admissibility.',
            'anonymous_and_decoder': 'Same literal coefficients, parameter dependencies and bounds. d=2 and kappa=2 are included. No hidden/existential constant, asymptotic threshold, delta, epsilon, kappa<=d^(1-delta), probability or query restriction.',
            'comparison': 'same. Full-C.4 Z_A independence from O and Theorem 4.1 lower-bound constants are outside the candidate statement, not silently generalized.',
            'blocking_delta_for_short_lemma': False
        }
    },
    'selective_verdict': 'SEMANTICALLY_EQUIVALENT_TO_SHORT_LEMMA_4_6_WITH_REDUNDANT_POSDEF_OUTPUT',
    'scope_qualification': 'Selective source/statement comparison only; full C.4, code, proof closure, actual definition implementation, whole module and reader/publication acceptance remain unreviewed.',
    'blocking_deltas_for_short_lemma': [],
    'blind_reconstruction_comparison': 'Independent supplied reconstruction accurately describes all anonymous statement slots using the five approved contexts; no mismatch found.',
    'provenance_limit': 'This phase verifies raw selective bytes, statement text hash and reconstruction text hash. Decoder/run provenance is supplied in the authorized selective packet; referenced external paths were not opened or replayed.'
}
write_json(OUT / 'seven-slot-comparison.json', comparison)

deltas = {
    'phase': '2-selective-only',
    'deltas': [
        {'id': 'D1', 'kind': 'equivalent-reindexing', 'blocking': False,
         'detail': 'Source j=1..d maps to anonymous i=0..d-1 by j=i+1; real (j-1/2) equals (i+1/2).'},
        {'id': 'D2', 'kind': 'redundant-conclusion', 'blocking': False,
         'detail': 'Explicit A.PosDef is produced, not assumed; lower Loewner bound I_d<=A already forces it on nonzero real vectors.'},
        {'id': 'D3', 'kind': 'source-scope-boundary', 'blocking_for_short_lemma': False,
         'blocking_for_claim_of_full_C4_coverage': True,
         'detail': 'Potential C-infinity/Hessian/strong convexity/smoothness/unique minimizer, actual N(0,A^{-1}) law, determinant invariance, exp(-half quadratic) Lebesgue integral and exact Z_A are not asserted here.'}
    ],
    'no_drift_checks': [
        'Full O(d), both determinant signs.',
        'All real coordinate vectors via finite-support semantics on finite Fin d.',
        'Real one-half grid, source range d>=2 supplies nonzero denominator.',
        'Only source d,kappa bounds and orthogonality as logical inputs.',
        'Actual rotated cosine-diagonal precision, not arbitrary pre-admissible A.',
        'No import of main lower-bound d_0(delta), delta, epsilon or kappa upper bound.'
    ],
    'deferred_to_phase3': [
        'Truth of approved contexts against actual meaning-carrying definitions and imported ancestry.',
        'Whole-module imports, scoped assumptions, private helpers and proof ingredient discharge.',
        'Actual use of full O(d), finite-support PSD/PD and real literal grid in candidate production text.',
        'No positivity/admissibility assumption smuggling elsewhere in the actual theorem context.',
        'Proof closure and fake-closure review, compiled/Test evidence.',
        'Authored reader lesson/publication accurately claims the narrow producer and leaves full C.4/main lower bound explicit.',
        'Any actual Gaussian target implementation preserves precision A, covariance A^{-1}, exp(-half quadratic), Lebesgue measure and exact normalizer.'
    ],
    'candidate_code_or_reader_acceptance': 'not assessed'
}
write_json(OUT / 'deltas-and-deferred-boundaries.json', deltas)

exposure = {
    'reviewer_id': 'fresh-source-reader-742806', 'phase': '2',
    'phase1_manifest_sha256': EXPECTED_PRIOR,
    'newly_opened_authorized_input': str(INPUT.relative_to(ROOT)),
    'new_input_raw_sha256': EXPECTED_INPUT,
    'seen_this_phase': ['Anonymous statement', 'Exactly five approved definition strings', 'Supplied genuine independent blind reconstruction', 'Their packet/run/provenance hashes and path metadata'],
    'not_opened': ['Current production code', 'Tests', 'Authored lesson', 'Publication', 'Audit', 'Full canonical reviewer packet', 'Preproof source graphs/topology', 'Other reviewer verdicts', 'Decoder run/input/exposure paths named in selective packet'],
    'prior_exposure_caveat': 'Phase1 filename-only enumeration caveat remains disclosed in immutable phase1 exposure record; no new filename discovery search in phase2.',
    'hash_checks': ['Selective raw input matched pinned 97e17ebb...', 'All phase1 manifest-listed bytes remain unchanged', 'Anonymous statement SHA matched f2392fc6...', 'Blind reconstructed text SHA matched 205efbc5...', 'Packet IDs/hashes cross-match inside authorized packet'],
    'canonical_packet_hash_status': 'Reported canonical hash 255d9aa7729ef4ab791199024074f21618ce2d1b3fa28648d8d29d2ab8729285 preserved; its serializer/run were not independently replayed.',
    'source_text_visible': True, 'anonymous_statement_visible': True,
    'blind_reconstruction_visible': True,
    'candidate_module_or_proof_visible': False,
    'candidate_prose_or_publication_visible': False,
    'other_verdict_contents_visible': False,
    'mutations': ['Own phase2 outputs and private freeze_phase2.py helper only'],
    'subagents_spawned': False,
    'proof_construction_performed': False,
    'verdict_boundary': 'Selective semantic source/statement comparison only, not proof/module/publication acceptance.',
    'stop_condition': 'Second freeze complete; stop until root explicitly supplies whole-module/full-context phase.'
}
write_json(OUT / 'exposure.selective-only.json', exposure)

(OUT / 'README.md').write_text('''# Fresh source reader 742806 — phase two selective freeze

This second freeze compares only the pinned selective anonymous statement,
five approved definitions and supplied independent blind reconstruction to the
immutable phase-one raw-source contract. No code, Tests, authored lesson,
publication, full reviewer packet, preproof graph or other verdict was opened.

The short source Lemma 4.6 matches semantically, with equivalent index relabeling
and redundant produced positive definiteness. Full C.4 and main lower-bound
coverage remain explicit boundaries. This is not proof/module/reader acceptance.

manifest.json binds all phase-two files except itself; manifest.sha256 seals it.
This phase is frozen; future whole-module review belongs in a new phase.
''')
manifest = {
    'schema': 'fresh-source-reader-phase2-selective-freeze-v1',
    'reviewer_id': 'fresh-source-reader-742806',
    'frozen_at_utc': datetime.now(timezone.utc).isoformat(),
    'phase1_manifest_sha256': EXPECTED_PRIOR,
    'selective_input_raw_sha256': EXPECTED_INPUT,
    'anonymous_canonical_packet_sha256': anonymous['packet_sha256'],
    'statement_sha256': lean['statement_sha256'],
    'decoder_run_sha256': reconstruction['decoder_run_sha256'],
    'reconstructed_text_sha256': reconstruction['reconstructed_text_sha256'],
    'generator': {'path': str(Path(__file__).relative_to(ROOT)),
                  'sha256': sha(Path(__file__).read_bytes())},
    'files': [{'path': str(p.relative_to(OUT)), 'sha256': sha(p.read_bytes()),
               'bytes': p.stat().st_size}
              for p in sorted(OUT.rglob('*')) if p.is_file()],
    'selective_verdict': comparison['selective_verdict'],
    'full_module_exposed': False,
    'proof_module_reader_acceptance': 'not assessed',
    'next_phase': 'STOP; await explicitly authorized full code/prose/module/consumer/ancestry context'
}
write_json(OUT / 'manifest.json', manifest)
manifest_sha = sha((OUT / 'manifest.json').read_bytes())
(OUT / 'manifest.sha256').write_text(manifest_sha + '  manifest.json\n')
print(json.dumps({
    'phase2_path': str(OUT), 'manifest_sha256': manifest_sha,
    'selective_raw_sha256': EXPECTED_INPUT,
    'comparison_sha256': sha((OUT / 'seven-slot-comparison.json').read_bytes()),
    'deltas_sha256': sha((OUT / 'deltas-and-deferred-boundaries.json').read_bytes()),
    'exposure_sha256': sha((OUT / 'exposure.selective-only.json').read_bytes()),
    'selective_verdict': comparison['selective_verdict']
}, indent=2))
