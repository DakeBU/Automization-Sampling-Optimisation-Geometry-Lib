from pathlib import Path
import hashlib
import json
import stat

base=Path(__file__).resolve().parent
repo=Path('/Users/zhouhuanjian/ASTIS-GC')
W=repo/'.astis/huanjian-gc-fixed-spectrum-cosine-gram-20261110'
names=['statement-seal-v1.json','preseal-planning.json','additional-preseal-source-role-exposure.json',
       'postseal-informal-planning.json','actual-environment-at-seal.json','StatementFormation.raw.lean.txt',
       'statement-formation.json','seal_statements.py','reserve_frontier_no_intake.py','prepare_normal_intake.py',
       'admit_normal_intake_prepared.py','prepared-intake-safe-summary.json']
expected={'statement-seal-v1.json':'a5e464a34ee276e62267d21f0965c1a0b1ef905bed27e679a85ecee3cd7fd45c',
          'admit_normal_intake_prepared.py':'0f3970a7f388e783e88f6c4aa8b8676a23daea3d6e4f4ebafa597eaee79e75ed'}
(base/'W').mkdir()
records=[]
for name in names:
    p=W/name;b=p.read_bytes();digest=hashlib.sha256(b).hexdigest()
    if name in expected:assert digest==expected[name],name
    (base/'W'/name).write_bytes(b)
    records.append({'path':str(p),'snapshot':'W/'+name,'bytes':len(b),'raw_sha256':digest,'mode':oct(stat.S_IMODE(p.stat().st_mode))})
C=repo/'research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-cosine-gram.json'
b=C.read_bytes();(base/'C.json').write_bytes(b)
records.append({'path':str(C),'snapshot':'C.json','bytes':len(b),'raw_sha256':hashlib.sha256(b).hexdigest(),'mode':oct(stat.S_IMODE(C.stat().st_mode))})
private=[]
for name,digest in [('preproof-baseline.private.json','b66cbc1bc55833a725ac230cdea12fee3529b3ccdd484fcaacf9b18f7fde3d72'),
                    ('intake-baseline.private.json','c282409e8408237f99431e815cf19a71abac8b5dc3420412adecae4200d81981')]:
    p=W/name;b=p.read_bytes();actual=hashlib.sha256(b).hexdigest();assert actual==digest,name
    obj=json.loads(b)
    summary={'path':str(p),'bytes':len(b),'raw_sha256':actual,'mode':oct(stat.S_IMODE(p.stat().st_mode)),
             'schema':obj.get('schema'),'top_level_key_names':list(obj),
             'top_level_container_counts':{k:len(v) for k,v in obj.items() if isinstance(v,(list,dict))}}
    private.append(summary)
(base/'public-input-inventory.json').write_text(json.dumps(records,indent=2)+'\n')
(base/'private-hash-schema-count-checks.json').write_text(json.dumps(private,indent=2)+'\n')
selected=['statement-seal-v1.json','prepared-intake-safe-summary.json']
out=['PUBLIC INPUT INVENTORY\n'+json.dumps(records,indent=2),
     'PRIVATE HASH/SCHEMA/COUNTS ONLY; NO SNAPSHOT OR FOREIGN STATE EXPORT\n'+json.dumps(private,indent=2)]
out+=['INPUT W/'+name+'\n'+(base/'W'/name).read_text() for name in selected]
out.append('INPUT C\n'+(base/'C.json').read_text())
stdout='\n\n'.join(out)+'\n';(base/'read-initial-process-inputs.stdout.txt').write_text(stdout);print(stdout,end='')
