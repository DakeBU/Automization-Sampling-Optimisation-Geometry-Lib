from pathlib import Path
import json,hashlib,subprocess
r=Path.cwd();w=r/'.astis/huanjian-gc-matrix-mgf-domain-20261115'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
c=r/'research-wiki/frontier-cells/ASTIS-SHARED-REAL-MATRIX-EXPONENTIAL-DOMAIN.json'
e=r/'research-wiki/technical-lemmas/matrix-mgf-domain-semantic-evidence'
assert not c.exists() and not e.exists()
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()=='960c7dbe2215ba2f76d2346e2e86883ee7a43d95'
tc=r/'.astis/semantic-neutral-20261115/matrix_domain_tc_79ad/topology-review.v1.json'
assert sha(tc)=='7d02c7990fd8e25172e643be800380011745d5377321bd01ec142fb3f4a4a6ad'
assert json.loads(tc.read_text())['verdict']=='ADMIT_EXACT_SEAL_AND_SOURCE_TOPOLOGY_WITH_EXPLICIT_ACCEPTED_V2_OVERLAY'
d=w/'metadata-drafts/frontier-cell.candidate.v1.json'
assert sha(d)=='df1aaf97532751a303ea9d82a7f3e3cad389463dfc99ffc8b6e2796c7c35e950'
x=json.loads(d.read_text())
for k in ['draft_only','registration_pending','draft_status_qualification']:x.pop(k,None)
x['status']='queued'
x['base_commit']='960c7dbe2215ba2f76d2346e2e86883ee7a43d95'
x['phase_snapshot']='Exact author seal and independent source topology plus explicit reviewed two-edge overlay admitted for proof. Initial cell installed before normal proposal/claim; no target proof or PL/V.'
x['statement_seal']['status']='STATEMENT_SEALED_AND_DISTINCT_PREPROOF_TOPOLOGY_ADMITTED'
x['source_proof_coverage'].update({'state':'source-topology-reviewed-mathematical-gaps-open','review_files':[str(tc.relative_to(r)),'.astis/semantic-neutral-20261115/matrix_domain_sg_48bc/source-graph.v1.json',str((w/'source-topology-repair.proposed-v2.json').relative_to(r))],'source_gap_discharge':'All four source gap obligations still mathematically unproved at initial installation.','independent_verdict_scope':'Only preproof exact statement/topology; no future source fidelity or Lean truth.'})
x['learning_contract']['failure_class']='IMPLEMENTATION_FAILED'
x['learning_contract']['process_memory_ids']=['ASTIS-PM-QUADRATIC-TILT-MEASURE-ROLES','ASTIS-NK-GRADIENT-FLOW-ZERO-TIME','ASTIS-NK-GD-INVERSE-DOMAIN']
x['learning_contract']['parallelism'].update({'decision':'parallel','direction_fingerprints':['source-only-graph48bc','raw-first-distinct-topology79ad','root-only-Lean-proof'],'expected_information_gain':'Source graph and distinct source-only challenge admitted the sealed problem. Root remains the sole prover; no competing mathematical proof search.','shared_verified_context_digest':'1b52776e9793f302109cb649dd0c82c666193086aa7546006e36651ee389e638'})
x['learning_contract']['cross_route_blind_spot_audit']['selection_reason']='Only ROOT proof route will be implemented; source reconstruction and review are distinct uncertainties, not parallel proof routes. Optional source-only OR route is unimplemented.'
e.mkdir(parents=True)
copies=[(w/'statement-seal.sealed.v1.json',r/'research-wiki/technical-lemmas/matrix-mgf-domain-statement-seal.json'),(w/'binder-definition-audit.sealed.v1.json',e/'binder-definition-audit.original.v1.json'),(w/'preproof-admission.v1.json',e/'preproof-source-admission.original.v1.json'),(w/'source-topology-repair.proposed-v2.json',e/'source-topology-repair.independently-accepted-v2.json'),(w/'metadata-drafts/reuse-and-mirror.root-instruction-record.v1.json',e/'reuse-and-mirror.root-instruction-record.v1.json')]
for a,b in copies:assert not b.exists();b.write_bytes(a.read_bytes())
x['statement_seal']['file']='research-wiki/technical-lemmas/matrix-mgf-domain-statement-seal.json'
x['statement_seal']['binder_audit']=str((e/'binder-definition-audit.original.v1.json').relative_to(r))
x['conceptual_mirror_audit']['evidence']=str((e/'reuse-and-mirror.root-instruction-record.v1.json').relative_to(r))
c.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'initial_cell':str(c.relative_to(r)),'sha256':sha(c),'normal_API_calls':0,'target_proof_calls':0,'old_files_modified':0}))
