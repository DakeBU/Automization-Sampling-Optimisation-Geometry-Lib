from pathlib import Path
import sys, json, hashlib, datetime, traceback

BASE=Path(__file__).resolve().parent
INPUTS=BASE/'inputs'
def sha(b): return hashlib.sha256(b).hexdigest()
def read(name):
    p=INPUTS/name if name != 'input-manifest.json' else BASE/name
    b=p.read_bytes()
    reads.append({'path':str(p.relative_to(BASE)),'bytes':len(b),'sha256':sha(b),'read_kind':'full file bytes'})
    return b
reads=[]
out=[]
def emit(s):
    s=str(s);out.append(s);print(s)
mode=sys.argv[1]
receipt={'argv':sys.argv,'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'mode':mode}
status=0
try:
    if mode == 'validate':
        m=json.loads(read('input-manifest.json'))
        results={}
        for n,e in m.items():
            b=read(n);results[n]={'bytes':len(b),'sha256':sha(b),'matches':len(b)==e['bytes'] and sha(b)==e['sha256']}
        emit(json.dumps(results,indent=2))
    elif mode == 'instruction':
        name=sys.argv[2];lo=int(sys.argv[3]);hi=int(sys.argv[4]);s=read(name).decode('utf-8')
        emit(f'FILE {name}; character interval [{lo},{min(hi,len(s))}); total {len(s)}')
        emit(s[lo:hi])
    elif mode == 'source-index':
        from bs4 import BeautifulSoup
        s=read('2610.20492v1.html').decode('utf-8');soup=BeautifulSoup(s,'html.parser')
        for el in soup.find_all(id=True):
            ident=el['id']
            if ident == 'S4' or ident.startswith('S4.') or ident=='A3' or ident.startswith('A3.'):
                if el.name in ['section','h2','h3','h4'] or ident.endswith('m3') or ('C.6' in el.get_text(' ',strip=True)[:90]):
                    emit(ident+' | '+el.name+' | '+el.get_text(' ',strip=True)[:180])
    elif mode == 'source-region':
        from bs4 import BeautifulSoup
        s=read('2610.20492v1.html').decode('utf-8');soup=BeautifulSoup(s,'html.parser');ident=sys.argv[2]
        el=soup.find(id=ident)
        if el is None: raise ValueError('No source ID '+ident)
        emit(str(el) if len(sys.argv)>3 and sys.argv[3]=='raw' else el.get_text(' ',strip=True))
    else: raise ValueError('Unknown mode '+mode)
except Exception:
    status=1;emit(traceback.format_exc())
receipt.update({'end_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':status,'input_reads':reads,'stdout':'\n'.join(out)+'\n','stderr':'','limits':'Agent exposure is only printed stdout; full byte reads for hashing/parsing are recorded separately.'})
(BASE/'execution').mkdir(exist_ok=True)
tag='-'.join(sys.argv[1:]).replace('/','_')
path=BASE/'execution'/('exec-'+tag+'.json')
if path.exists(): path=path.with_name(path.stem+'-'+receipt['start_utc'].replace(':','_')+'.json')
path.write_text(json.dumps(receipt,indent=2,ensure_ascii=False)+'\n')
sys.exit(status)
