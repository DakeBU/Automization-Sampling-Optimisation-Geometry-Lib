from pathlib import Path
import subprocess,json,hashlib,datetime
OUT=Path(__file__).parent
inputs=json.loads((OUT/'input-read-receipts.json').read_bytes())
receipts=[]
for x in inputs:
 p=subprocess.run(['cat',x['path']],capture_output=True)
 assert p.returncode==0 and hashlib.sha256(p.stdout).hexdigest()==x['sha256']
 (OUT/(x['copy']+'.read.stdout')).write_bytes(p.stdout)
 (OUT/(x['copy']+'.read.stderr')).write_bytes(p.stderr)
 receipts.append({'argv':['cat',x['path']],'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'returncode':p.returncode,'stdout_bytes':len(p.stdout),'stdout_sha256':hashlib.sha256(p.stdout).hexdigest(),'stderr_bytes':len(p.stderr),'stderr_sha256':hashlib.sha256(p.stderr).hexdigest(),'provenance':'actual subprocess capture of this rerun; replaces initial same-byte literal input-stream copies, not a claim of earlier shell redirection'})
(OUT/'raw-read-capture-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n')
print(json.dumps(receipts,indent=2))
