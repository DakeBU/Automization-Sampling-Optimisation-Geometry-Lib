#!/opt/anaconda3/bin/python
import hashlib,io,json,pathlib,tarfile
ROOT=pathlib.Path('/Users/zhouhuanjian/ASTIS-GC');BASE=pathlib.Path(__file__).resolve().parent
rel='research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-cosine-gram-semantic-evidence/fresh-native-0a91de-all-original-files.lossless-file-bytes.tar.gz'
data=(ROOT/rel).read_bytes();digest=hashlib.sha256(data).hexdigest()
assert digest=='eef1e3597a76509f5ae76b47ac52ba5e0d9597b20680bc036fc357e7f363cca4'
(BASE/'inputs/fresh-native-0a91de-all-original-files.lossless-file-bytes.tar.gz').write_bytes(data)
manifest=json.loads((BASE/'inputs/fresh-native-0a91de-original-freeze-manifest.json').read_text())
expected={r['path']:r for r in manifest['files']}
expected['freeze-manifest.json']={'bytes':len((BASE/'inputs/fresh-native-0a91de-original-freeze-manifest.json').read_bytes()),'sha256':'613ca1b57a2a9bb65592a0d8998968c07d60bb2e86e722144cab4206c9c0fa6d'}
expected['freeze-outer-receipt.json']={'bytes':len((BASE/'inputs/fresh-native-0a91de-original-outer-receipt.json').read_bytes()),'sha256':'4f982018a158fc9e1b4e2e270dcfd2fd0f9a4f0f5584158f0f053826448df7e5'}
selected={'fresh-build-plan.json','fresh-build-results.json','independent-kernel-receipt.json',
          'raw/independent_kernel.receipt.json','raw/all_owned_exact_closed_prop_types.receipt.json',
          'raw/all_owned_exact_closed_prop_types.stdout','fresh-src/IndependentKernel.lean','OwnedTypes.lean',
          'independent-owned-kernel-summary.json','build_fresh.py',
          'raw/fresh_1_FixedSpectrumCosineGram_resolved_deps.stdout',
          'raw/fresh_2_GaussianComplexityFixedSpectrumCosineGram_resolved_deps.stdout',
          'static-reader-findings.json'}
with tarfile.open(fileobj=io.BytesIO(data),mode='r:gz') as archive:
    members=archive.getmembers();regular=[m for m in members if m.isfile()]
    candidates=[m for m in regular if m.name.endswith('findings.json') and not m.name.endswith('static-reader-findings.json')]
    valid=[m for m in candidates if hashlib.sha256(archive.extractfile(m).read()).hexdigest()=='7287d0d751f44786643207352cf326a9f5d7300070a13b8b8596c81da2111052']
    assert len(valid)==1
    prefix=valid[0].name[:-len('findings.json')]
    records=[];extracted=[]
    (BASE/'native-selected').mkdir(exist_ok=True)
    for member in regular:
        assert member.name.startswith(prefix),member.name
        name=member.name[len(prefix):]
        assert name in expected,name
        content=archive.extractfile(member).read();h=hashlib.sha256(content).hexdigest()
        assert len(content)==expected[name]['bytes'] and h==expected[name]['sha256'],name
        records.append({'member':member.name,'relative':name,'bytes':len(content),'sha256':h,'archive_mode':format(member.mode,'04o')})
        if name in selected:
            output='native-selected/'+name.replace('/','__')
            (BASE/output).write_bytes(content)
            extracted.append({'source_member':name,'snapshot':output,'bytes':len(content),'sha256':h})
    assert {r['relative'] for r in records}==set(expected)
    assert len(records)==len(set(r['relative'] for r in records))
result={'archive_source':rel,'archive_bytes':len(data),'archive_sha256':digest,'member_prefix':prefix,
        'all_payload_and_two_envelope_files_verified':True,'verified_regular_file_count':len(records),
        'manifest_payload_count':len(manifest['files']),'regular_file_records':records,
        'selected_semantically_expanded_native_inputs':extracted,
        'scope':'All bytes were hashed for integrity; only selected math/native/build/static findings are displayed. No UI proposal review or private foreign baseline read; no native process rerun by source reviewer.'}
(BASE/'native_archive_verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='regular_file_records'},indent=2))
for r in extracted:
    if r['source_member'] in ['independent-owned-kernel-summary.json','raw/all_owned_exact_closed_prop_types.stdout','fresh-src/IndependentKernel.lean']:
        obj=(BASE/r['snapshot']).read_bytes()
        print('DEFERRED_LARGE_NATIVE_TEXT',r['snapshot'],len(obj))
    else:
        print('SELECTED_NATIVE_TEXT',r['snapshot']);print((BASE/r['snapshot']).read_text())
