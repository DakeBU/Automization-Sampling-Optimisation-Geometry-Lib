import AutoSamplingTheory.ExampleCases.ProximalBPS.ActualAbsoluteNextEventTime
import Mathlib.Order.Fin.Tuple
namespace OrderedIntegral92
open MeasureTheory ProbabilityTheory InnerProductSpace
open scoped NNReal ENNReal Topology ContDiff Interval
noncomputable section
set_option autoImplicit false

private def readTime {Z : Type*} (r : (ℝ≥0 × Z) ⊕ Unit) : ℝ :=
  match r with
  | Sum.inl q => q.1
  | Sum.inr _ => 0

private theorem readTime_measurable {Z : Type*} [MeasurableSpace Z] :
    Measurable (@readTime Z) := by
  apply Measurable.sumElim
  · exact measurable_coe_nnreal_real.comp measurable_fst
  · exact measurable_const

private theorem live_measurable {Z : Type*} [MeasurableSpace Z] :
    MeasurableSet {r : (ℝ≥0 × Z) ⊕ Unit | ∃ a, r = Sum.inl a} := by
  have heq : {r : (ℝ≥0 × Z) ⊕ Unit | ∃ a, r = Sum.inl a} = Set.range Sum.inl := by
    ext r
    simp only [Set.mem_ofPred_eq, Set.mem_range, eq_comm]
  rw [heq]
  exact measurableSet_range_inl

private theorem history_guard_measurable {Z : Type*} [MeasurableSpace Z] (n : ℕ) (T : ℝ≥0) :
    MeasurableSet {h : Fin (n + 1) → ((ℝ≥0 × Z) ⊕ Unit) |
      (∀ j, ∃ a : ℝ≥0 × Z, h j = Sum.inl a) ∧
      StrictMono (fun j => readTime (h j)) ∧
      ∀ i : Fin n, readTime (h i.succ) < (T : ℝ)} := by
  simp only [StrictMono, Set.ofPred_and, Set.ofPred_forall]
  apply MeasurableSet.inter
  · exact MeasurableSet.iInter fun j => live_measurable.preimage (measurable_pi_apply j)
  · apply MeasurableSet.inter
    · exact MeasurableSet.iInter fun i => MeasurableSet.iInter fun j =>
        MeasurableSet.iInter fun _ => measurableSet_lt
          (readTime_measurable.comp (measurable_pi_apply i))
          (readTime_measurable.comp (measurable_pi_apply j))
    · exact MeasurableSet.iInter fun i => measurableSet_lt
        (readTime_measurable.comp (measurable_pi_apply i.succ)) measurable_const


private def guard {Z : Type*} (n : ℕ) (T : ℝ≥0)
    (h : Fin (n+1) → ((ℝ≥0 × Z) ⊕ Unit)) : Prop :=
  (∀ j, ∃ a, h j = Sum.inl a) ∧
  StrictMono (fun j => readTime (h j)) ∧
  ∀ i : Fin n, readTime (h i.succ) < (T : ℝ)

private theorem guard_snoc {Z : Type*} (n : ℕ) (T : ℝ≥0)
    (h : Fin (n+1) → ((ℝ≥0 × Z) ⊕ Unit)) (r : (ℝ≥0 × Z) ⊕ Unit) :
    guard (n+1) T (Fin.snoc h r) ↔
      guard n T h ∧ (∃ a, r = Sum.inl a) ∧
        readTime (h (Fin.last n)) < readTime r ∧ readTime r < (T : ℝ) := by
  unfold guard
  have ht : (fun j => readTime ((Fin.snoc h r : Fin (n+2) → _) j)) =
      Fin.snoc (fun j => readTime (h j)) (readTime r) := by
    funext j
    induction j using Fin.lastCases with
    | last => simp only [Fin.snoc_last]
    | cast i => simp only [Fin.snoc_castSucc]
  rw [ht, Fin.strictMono_iff_lt_succ]
  simp only [Fin.forall_iff_castSucc, Fin.snoc_castSucc, Fin.snoc_last,
    Fin.succ_castSucc, Fin.succ_last]
  rw [Fin.strictMono_iff_lt_succ]
  tauto

private theorem record_history_snoc {Z : Type*}
    (record : ℕ → ((ℝ≥0 × Z) ⊕ Unit)) (n : ℕ) :
    (fun j : Fin (n+2) => record j.val) =
      Fin.snoc (fun j : Fin (n+1) => record j.val) (record (n+1)) := by
  funext j
  induction j using Fin.lastCases with
  | last => simp only [Fin.snoc_last, Fin.val_last]
  | cast i => simp only [Fin.snoc_castSucc, Fin.val_castSucc]

private theorem record_guard_step {Z : Type*}
    (record : ℕ → ((ℝ≥0 × Z) ⊕ Unit)) (n : ℕ) (T : ℝ≥0) :
    guard (n+1) T (fun j => record j.val) ↔
      guard n T (fun j => record j.val) ∧
      ((∃ a, record n = Sum.inl a) ∧ (∃ a, record (n+1) = Sum.inl a) ∧
        readTime (record n) < readTime (record (n+1)) ∧
        readTime (record (n+1)) < (T : ℝ)) := by
  rw [record_history_snoc, guard_snoc]
  simp only [Fin.val_last]
  constructor
  · rintro ⟨hg, hn, hlo, hhi⟩
    exact ⟨hg, hg.1 (Fin.last n), hn, hlo, hhi⟩
  · rintro ⟨hg, _, hn, hlo, hhi⟩
    exact ⟨hg, hn, hlo, hhi⟩

private theorem record_event_step {Ω Z : Type*}
    (record : Ω → ℕ → ((ℝ≥0 × Z) ⊕ Unit)) (n : ℕ) (T : ℝ≥0) :
    {w | guard (n+1) T (fun j => record w j.val)} =
      {w | guard n T (fun j => record w j.val)} ∩
      {w | (∃ a, record w n = Sum.inl a) ∧
        (∃ a, record w (n+1) = Sum.inl a) ∧
        readTime (record w n) < readTime (record w (n+1)) ∧
        readTime (record w (n+1)) < (T : ℝ)} := by
  ext w
  exact record_guard_step (record w) n T

set_option maxHeartbeats 2400000 in
private theorem actual_prefix_step_integral
    {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℝ E]
    [FiniteDimensional ℝ E] [MeasurableSpace E] [BorelSpace E]
    {V : E → ℝ} {α β : ℝ≥0} {η : ℝ}
    (hα : 0 < (α : ℝ)) (hαβ : α ≤ β) (hV : ContDiff ℝ 2 V)
    (hH : ∀ x v : E,
      (α : ℝ) * ‖v‖ ^ 2 ≤ (fderiv ℝ (fderiv ℝ V) x v) v ∧
      (fderiv ℝ (fderiv ℝ V) x v) v ≤ (β : ℝ) * ‖v‖ ^ 2)
    (hη : 0 < η) (hβη : (β : ℝ) * η ≤ 1) :
    let c : E → E → E := fun y xRef => y - η • gradient V xRef
    let Φ : E → E → ℝ → (E × E) → (E × E) := fun y xRef t z =>
      (c y xRef + Real.cos t • (z.1 - c y xRef) +
          (Real.sqrt η * Real.sin t) • z.2,
       (-Real.sin t / Real.sqrt η) • (z.1 - c y xRef) + Real.cos t • z.2)
    let S : E → (E × E) → (E × E) := fun xRef z =>
      (z.1, z.2 - (2 * inner ℝ z.2 (gradient V z.1 - gradient V xRef) /
        ‖gradient V z.1 - gradient V xRef‖ ^ 2) • (gradient V z.1 - gradient V xRef))
    let rate : E → (E × E) → ℝ := fun xRef z =>
      Real.sqrt η * max 0 (inner ℝ z.2 (gradient V z.1 - gradient V xRef))
    let Λ : E → E → (E × E) → ℝ≥0 → ℝ := fun y xRef z t =>
      ∫ s in (0 : ℝ)..(t : ℝ), rate xRef (Φ y xRef s z)
    let τ : E → E → (E × E) → ℝ≥0 → WithTop ℝ≥0 := fun y xRef z e =>
      MeasureTheory.hittingAfter
        (fun t : ℝ≥0 => fun a : (E × E) × (E × E) × ℝ≥0 =>
          Λ a.1.1 a.1.2 a.2.1 t - (a.2.2 : ℝ))
        (Set.Ici (0 : ℝ)) 0 ((y, xRef), z, e)
    let next : E → E → ℝ≥0 → ((ℝ≥0 × (E × E)) ⊕ Unit) →
        ((ℝ≥0 × (E × E)) ⊕ Unit) := fun y xRef e r =>
      match r with
      | Sum.inr _ => Sum.inr ()
      | Sum.inl a =>
        if τ y xRef a.2 e = ⊤ then Sum.inr () else
          Sum.inl (a.1 + (τ y xRef a.2 e).untopD 0,
            S xRef (Φ y xRef (((τ y xRef a.2 e).untopD 0 : ℝ≥0) : ℝ) a.2))
    let record : E → E → (E × E) → (ℕ → ℝ≥0) → ℕ →
        ((ℝ≥0 × (E × E)) ⊕ Unit) := fun y xRef z₀ e n =>
      Nat.rec (Sum.inl (0, z₀)) (fun k r => next y xRef (e k) r) n
    let P : Measure (ℕ → ℝ) := Measure.infinitePi (fun _ : ℕ => expMeasure (1 : ℝ))
    let ε : (ℕ → ℝ) → ℕ → ℝ≥0 := fun w k => Real.toNNReal (w k)
    let history : E → E → (E × E) → (n : ℕ) → (ℕ → ℝ) →
        (Fin (n + 1) → ((ℝ≥0 × (E × E)) ⊕ Unit)) :=
      fun y xRef z₀ n w j => record y xRef z₀ (ε w) j.val
    let Rec := (ℝ≥0 × (E × E)) ⊕ Unit
    let Hist : ℕ → Type _ := fun n => Fin (n + 1) → Rec
    let readTime : Rec → ℝ := fun r => match r with
      | Sum.inl q => (q.1 : ℝ)
      | Sum.inr _ => 0
    let Δ : (n : ℕ) → ℝ≥0 → Set (Fin n → ℝ) := fun n T =>
      {t | StrictMono (Fin.cons (0 : ℝ) t) ∧ ∀ i, t i < (T : ℝ)}
    let Prefix : (n : ℕ) → ℝ≥0 → Type := fun n T => {t : Fin n → ℝ // t ∈ Δ n T}
    let m : (n : ℕ) → (T : ℝ≥0) → Measure (Prefix n T) := fun n T =>
      Measure.comap (fun t : Prefix n T => t.val) (volume : Measure (Fin n → ℝ))
    let zAt : E → E → (E × E) → (n : ℕ) → (T : ℝ≥0) →
        Prefix n T → Fin (n + 1) → (E × E) := fun y xRef z₀ n T t =>
      Fin.induction z₀ (fun i z =>
        S xRef (Φ y xRef (t.val i - (Fin.cons (0 : ℝ) (t.val : Fin n → ℝ) : Fin (n + 1) → ℝ) i.castSucc) z))
    let K : E → E → (E × E) → (n : ℕ) → (T : ℝ≥0) →
        Prefix n T → Hist n := fun y xRef z₀ n T t j =>
      Sum.inl (Real.toNNReal ((Fin.cons (0 : ℝ) (t.val : Fin n → ℝ) : Fin (n + 1) → ℝ) j), zAt y xRef z₀ n T t j)
    let qReal : E → E → (E × E) → (n : ℕ) → (T : ℝ≥0) →
        Prefix n T → ℝ := fun y xRef z₀ n T t =>
      ∏ i : Fin n,
        rate xRef (Φ y xRef (t.val i - (Fin.cons (0 : ℝ) (t.val : Fin n → ℝ) : Fin (n + 1) → ℝ) i.castSucc)
          (zAt y xRef z₀ n T t i.castSucc)) *
        Real.exp (-Λ y xRef (zAt y xRef z₀ n T t i.castSucc)
          (Real.toNNReal (t.val i - (Fin.cons (0 : ℝ) (t.val : Fin n → ℝ) : Fin (n + 1) → ℝ) i.castSucc)))
    let q : E → E → (E × E) → (n : ℕ) → (T : ℝ≥0) →
        Prefix n T → ℝ≥0∞ := fun y xRef z₀ n T t =>
      ENNReal.ofReal (qReal y xRef z₀ n T t)
    let A : (n : ℕ) → ℝ≥0 → Set (Hist n) := fun n T =>
      {h | (∀ j, ∃ a : ℝ≥0 × (E × E), h j = Sum.inl a) ∧
        StrictMono (fun j => readTime (h j)) ∧
        ∀ i : Fin n, readTime (h i.succ) < (T : ℝ)}
    ∀ n : ℕ, ∀ T : ℝ≥0, ∀ y xRef : E, ∀ z₀ : E × E,
      let a : Hist n → ℝ := fun h => readTime (h (Fin.last n))
      let append : Hist n × ℝ → Hist (n+1) := fun p =>
        Fin.snoc p.1 (match p.1 (Fin.last n) with
          | Sum.inl r => Sum.inl (r.1 + Real.toNNReal (p.2 - a p.1),
              S xRef (Φ y xRef (p.2 - a p.1) r.2))
          | Sum.inr _ => Sum.inr ())
      let D : Hist n → ℝ → ℝ≥0∞ := fun h u =>
        if a h < u ∧ u < (T : ℝ) then
          match h (Fin.last n) with
          | Sum.inl r => ENNReal.ofReal (rate xRef (Φ y xRef (u - a h) r.2) *
              Real.exp (-Λ y xRef r.2 (Real.toNNReal (u - a h))))
          | Sum.inr _ => 0
        else 0
      ∀ F : Hist (n+1) → ℝ≥0∞, Measurable F →
        let J : Hist n → ℝ≥0∞ := fun h => ∫⁻ u : ℝ, F (append (h,u)) * D h u
        Measurable J ∧
        (∫⁻ w in history y xRef z₀ (n+1) ⁻¹' A (n+1) T,
          F (history y xRef z₀ (n+1) w) ∂P) =
        ∫⁻ w in history y xRef z₀ n ⁻¹' A n T,
          J (history y xRef z₀ n w) ∂P := by
  classical
  let c : E → E → E := fun y xRef => y - η • gradient V xRef
  let Φ : E → E → ℝ → (E × E) → (E × E) := fun y xRef t z =>
    (c y xRef + Real.cos t • (z.1 - c y xRef) +
        (Real.sqrt η * Real.sin t) • z.2,
     (-Real.sin t / Real.sqrt η) • (z.1 - c y xRef) + Real.cos t • z.2)
  let S : E → (E × E) → (E × E) := fun xRef z =>
    (z.1, z.2 - (2 * inner ℝ z.2 (gradient V z.1 - gradient V xRef) /
      ‖gradient V z.1 - gradient V xRef‖ ^ 2) • (gradient V z.1 - gradient V xRef))
  let rate : E → (E × E) → ℝ := fun xRef z =>
    Real.sqrt η * max 0 (inner ℝ z.2 (gradient V z.1 - gradient V xRef))
  let Λ : E → E → (E × E) → ℝ≥0 → ℝ := fun y xRef z t =>
    ∫ s in (0 : ℝ)..(t : ℝ), rate xRef (Φ y xRef s z)
  let τ : E → E → (E × E) → ℝ≥0 → WithTop ℝ≥0 := fun y xRef z e =>
    MeasureTheory.hittingAfter
      (fun t : ℝ≥0 => fun a : (E × E) × (E × E) × ℝ≥0 =>
        Λ a.1.1 a.1.2 a.2.1 t - (a.2.2 : ℝ))
      (Set.Ici (0 : ℝ)) 0 ((y, xRef), z, e)
  let next : E → E → ℝ≥0 → ((ℝ≥0 × (E × E)) ⊕ Unit) →
      ((ℝ≥0 × (E × E)) ⊕ Unit) := fun y xRef e r =>
    match r with
    | Sum.inr _ => Sum.inr ()
    | Sum.inl a =>
      if τ y xRef a.2 e = ⊤ then Sum.inr () else
        Sum.inl (a.1 + (τ y xRef a.2 e).untopD 0,
          S xRef (Φ y xRef (((τ y xRef a.2 e).untopD 0 : ℝ≥0) : ℝ) a.2))
  let record : E → E → (E × E) → (ℕ → ℝ≥0) → ℕ →
      ((ℝ≥0 × (E × E)) ⊕ Unit) := fun y xRef z₀ e n =>
    Nat.rec (Sum.inl (0, z₀)) (fun k r => next y xRef (e k) r) n
  let P : Measure (ℕ → ℝ) := Measure.infinitePi (fun _ : ℕ => expMeasure (1 : ℝ))
  let ε : (ℕ → ℝ) → ℕ → ℝ≥0 := fun w k => Real.toNNReal (w k)
  let history : E → E → (E × E) → (n : ℕ) → (ℕ → ℝ) →
      (Fin (n + 1) → ((ℝ≥0 × (E × E)) ⊕ Unit)) :=
    fun y xRef z₀ n w j => record y xRef z₀ (ε w) j.val
  let Rec := (ℝ≥0 × (E × E)) ⊕ Unit
  let Hist : ℕ → Type _ := fun n => Fin (n + 1) → Rec
  let readTime : Rec → ℝ := fun r => match r with
    | Sum.inl q => (q.1 : ℝ)
    | Sum.inr _ => 0
  let Δ : (n : ℕ) → ℝ≥0 → Set (Fin n → ℝ) := fun n T =>
    {t | StrictMono (Fin.cons (0 : ℝ) t) ∧ ∀ i, t i < (T : ℝ)}
  let Prefix : (n : ℕ) → ℝ≥0 → Type := fun n T => {t : Fin n → ℝ // t ∈ Δ n T}
  let m : (n : ℕ) → (T : ℝ≥0) → Measure (Prefix n T) := fun n T =>
    Measure.comap (fun t : Prefix n T => t.val) (volume : Measure (Fin n → ℝ))
  let zAt : E → E → (E × E) → (n : ℕ) → (T : ℝ≥0) →
      Prefix n T → Fin (n + 1) → (E × E) := fun y xRef z₀ n T t =>
    Fin.induction z₀ (fun i z =>
      S xRef (Φ y xRef (t.val i - (Fin.cons (0 : ℝ) (t.val : Fin n → ℝ) : Fin (n + 1) → ℝ) i.castSucc) z))
  let K : E → E → (E × E) → (n : ℕ) → (T : ℝ≥0) →
      Prefix n T → Hist n := fun y xRef z₀ n T t j =>
    Sum.inl (Real.toNNReal ((Fin.cons (0 : ℝ) (t.val : Fin n → ℝ) : Fin (n + 1) → ℝ) j), zAt y xRef z₀ n T t j)
  let qReal : E → E → (E × E) → (n : ℕ) → (T : ℝ≥0) →
      Prefix n T → ℝ := fun y xRef z₀ n T t =>
    ∏ i : Fin n,
      rate xRef (Φ y xRef (t.val i - (Fin.cons (0 : ℝ) (t.val : Fin n → ℝ) : Fin (n + 1) → ℝ) i.castSucc)
        (zAt y xRef z₀ n T t i.castSucc)) *
      Real.exp (-Λ y xRef (zAt y xRef z₀ n T t i.castSucc)
        (Real.toNNReal (t.val i - (Fin.cons (0 : ℝ) (t.val : Fin n → ℝ) : Fin (n + 1) → ℝ) i.castSucc)))
  let q : E → E → (E × E) → (n : ℕ) → (T : ℝ≥0) →
      Prefix n T → ℝ≥0∞ := fun y xRef z₀ n T t =>
    ENNReal.ofReal (qReal y xRef z₀ n T t)
  let A : (n : ℕ) → ℝ≥0 → Set (Hist n) := fun n T =>
    {h | (∀ j, ∃ a : ℝ≥0 × (E × E), h j = Sum.inl a) ∧
      StrictMono (fun j => readTime (h j)) ∧
      ∀ i : Fin n, readTime (h i.succ) < (T : ℝ)}
  change ∀ n : ℕ, ∀ T : ℝ≥0, ∀ y xRef : E, ∀ z₀ : E × E,
      let a : Hist n → ℝ := fun h => readTime (h (Fin.last n))
      let append : Hist n × ℝ → Hist (n+1) := fun p =>
        Fin.snoc p.1 (match p.1 (Fin.last n) with
          | Sum.inl r => Sum.inl (r.1 + Real.toNNReal (p.2 - a p.1),
              S xRef (Φ y xRef (p.2 - a p.1) r.2))
          | Sum.inr _ => Sum.inr ())
      let D : Hist n → ℝ → ℝ≥0∞ := fun h u =>
        if a h < u ∧ u < (T : ℝ) then
          match h (Fin.last n) with
          | Sum.inl r => ENNReal.ofReal (rate xRef (Φ y xRef (u - a h) r.2) *
              Real.exp (-Λ y xRef r.2 (Real.toNNReal (u - a h))))
          | Sum.inr _ => 0
        else 0
      ∀ F : Hist (n+1) → ℝ≥0∞, Measurable F →
        let J : Hist n → ℝ≥0∞ := fun h => ∫⁻ u : ℝ, F (append (h,u)) * D h u
        Measurable J ∧
        (∫⁻ w in history y xRef z₀ (n+1) ⁻¹' A (n+1) T,
          F (history y xRef z₀ (n+1) w) ∂P) =
        ∫⁻ w in history y xRef z₀ n ⁻¹' A n T,
          J (history y xRef z₀ n w) ∂P

  intro n T y xRef z₀
  dsimp only
  intro F hF
  let a : Hist n → ℝ := fun h => readTime (h (Fin.last n))
  let append : Hist n × ℝ → Hist (n+1) := fun p =>
    Fin.snoc p.1 (match p.1 (Fin.last n) with
      | Sum.inl r => Sum.inl (r.1 + Real.toNNReal (p.2 - a p.1),
          S xRef (Φ y xRef (p.2 - a p.1) r.2))
      | Sum.inr _ => Sum.inr ())
  let D : Hist n → ℝ → ℝ≥0∞ := fun h u =>
    if a h < u ∧ u < (T : ℝ) then
      match h (Fin.last n) with
      | Sum.inl r => ENNReal.ofReal (rate xRef (Φ y xRef (u - a h) r.2) *
          Real.exp (-Λ y xRef r.2 (Real.toNNReal (u - a h))))
      | Sum.inr _ => 0
    else 0
  let J : Hist n → ℝ≥0∞ := fun h => ∫⁻ u : ℝ, F (append (h,u)) * D h u
  change Measurable J ∧ _
  have h91 := AutoSamplingTheory.ExampleCases.ProximalBPS.ActualAbsoluteNextEventTime.actual_absolute_next_event_time_law
    hα hαβ hV hH hη hβη y xRef z₀ n
  rcases h91 with ⟨hHist, _, _, _, _, _, _, hb⟩
  have hconst := hb (fun _ => T) measurable_const
  rcases hconst with ⟨_, _, _, _, _, _, _, _, _, _, _, _, _, hf⟩
  obtain ⟨hJ, hloc⟩ := hf (fun p => F p.1) (hF.comp measurable_fst)
  have hread : readTime = @OrderedIntegral92.readTime (E × E) := by
    funext r; cases r <;> rfl
  have hA : MeasurableSet (A n T) := by
    simpa only [A, hread] using history_guard_measurable (Z := E × E) n T
  have hid := hloc (A n T) hA
  have hAeq (k : ℕ) : A k T = {h | guard k T h} := by
    dsimp only [A, guard]
    rw [hread]
  have hevent :
      {w | (∃ r, record y xRef z₀ (ε w) n = Sum.inl r) ∧
        (∃ r, record y xRef z₀ (ε w) (n+1) = Sum.inl r) ∧
        readTime (record y xRef z₀ (ε w) n) < readTime (record y xRef z₀ (ε w) (n+1)) ∧
        readTime (record y xRef z₀ (ε w) (n+1)) < (T : ℝ)} ∩
        history y xRef z₀ n ⁻¹' A n T = history y xRef z₀ (n+1) ⁻¹' A (n+1) T := by
    rw [Set.inter_comm]
    symm
    rw [hAeq, hAeq, hread]
    exact record_event_step (fun w => record y xRef z₀ (ε w)) n T
  change Measurable J at hJ
  refine ⟨hJ, ?_⟩
  change (∫⁻ w in
      {w | (∃ r, record y xRef z₀ (ε w) n = Sum.inl r) ∧
        (∃ r, record y xRef z₀ (ε w) (n+1) = Sum.inl r) ∧
        readTime (record y xRef z₀ (ε w) n) < readTime (record y xRef z₀ (ε w) (n+1)) ∧
        readTime (record y xRef z₀ (ε w) (n+1)) < (T : ℝ)} ∩
      history y xRef z₀ n ⁻¹' A n T,
      F (history y xRef z₀ (n+1) w) ∂P) =
    ∫⁻ h in A n T, J h ∂(Measure.map (history y xRef z₀ n) P) at hid
  rw [hevent] at hid
  have hHist' : Measurable (history y xRef z₀ n) := hHist
  exact hid.trans (setLIntegral_map (μ := P) hA hJ hHist')

end
end OrderedIntegral92

set_option pp.deepTerms true
#check @OrderedIntegral92.actual_prefix_step_integral
#print axioms OrderedIntegral92.actual_prefix_step_integral
