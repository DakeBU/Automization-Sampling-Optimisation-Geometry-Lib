# Independent fixed type/binder/definition audit: actual matrix variance

**No type, binder, definition or source-scope issue was found in the exact
sealed packet.** No new source graph, implementation, proof or API search was
used. This is a type/source-meaning finding, not topology or mathematical/API
applicability acceptance, a compiled edge, normal verification or permission.

The actor's raw freeze was completed before this new type exposure and is
unchanged at `c0bf670eba58674aac8b29d8fd313428955e76f13c20680ae47c84f1f4b536db`.
Its p13/p14/p15 locator correction remains: Z is defined in p13, second-moment
and centered/weighted comparisons are p14, and Bernstein p15 is outside this
target. No global seal timing claim is inferred from the actor's raw phase.

## Exact binding

The exact reviewed packet is
`.astis/huanjian-gc-source-matrix-variance-20261112/selective-type-definition-packet.json`,
SHA-256 `b9b93126880486157e88e9a59abcd2b89d81b4cf34d46fa9dc51f88d2b6e0170`.
It names seal `5f905cafe6035238cebdedd4f841e87b703e741b4c8aa204471d89e4c07e8a14`
and context `c8f86ad1db7cf3798073ff5bde1d859cd2f95dcd54dbe7f759fa4b2022c5383a`.
The exact signature strings independently hash to producer
`d5ac54443c79ea7b35b09ddcd6b5e3c40bef081bbe4f196cae5ab3ead35aa2ea`
and consumer `95e81a02e5302de9a42e3b60038ffad6195315ac2eca99a4e6abb39978609f7e`.
The current literal-print hash, all eight embedded standard excerpt hashes and
all eight raw-source span hashes were recomputed and matched. This binds the
packet bytes; no unspecified separate seal/context serialization is claimed
to have been independently recomputed.

## Binder audit and exact literal objects

Natural d,q are carrier/query typing. The only logical input is the standing
source inequality 2q+1<d. All local lets define the actual objects and are not
logical hypotheses; the binder table's DEFINITION label is a separate semantic
audit, not an extra source-premise category. No EXCESS public binder was found.

The sample space is q+1 columns in real Euclidean d-space, with the explicitly
written product standard-Gaussian measure mu. Row i collects the actual
physical coordinate i from each column into Euclidean(q+1)-space. All Y means,
squares, centered variables and their expectations use that same literal
mu. There is no arbitrary ambient law, replaced row sample, supplied mean
matrix, or row/moment/Gram/PSD/variance certificate.

The literal definitions have r=q+1, L=2r+3log(1000d), physical angle
(i.val+1-1/2)pi/d, feature0=1 and featurek=sqrt(2)cos(k theta_i). The cutoff is
inclusive, and the actual row outer product is the first Kronecker factor.
The matrix paired indices put Gaussian coordinates first and feature
coordinates second, giving r^2 by r^2 real matrices. The factor is exactly
inverse d before squaring; the eventual square therefore has inverse-d-squared
normalization. Zero outside the cutoff is the literal source indicator, not
an existence/default repair or a common-event conditioning operation.

The coefficient C is a literal local let 2r(r+2)/d, the source variance
coefficient. It is not Lemma 4.4's existential absolute C and is not a caller
parameter. No a, a-bias bound, R-star bound, tau, kappa or truncation-success
probability enters either signature. Joint independence and iid matrix laws
are not hypotheses or conclusions of this packet.

The source range retains q=0. Then r=1 and the feature is the constant 1;
both actual variance bounds and the n=1 cosine weights remain. Positive/nonzero
d and r and the coefficient's nonnegativity must be derived internally, with
no positivity certificate binder.

## Matrix product, PSD and norm meanings

The packet's actual Mul instance and standard literal excerpts identify
ordinary finite matrix multiplication: (MN)_ij=sum_k M_ik N_kj. Thus Y_i*Y_i,
Z_i*Z_i and the weighted product are matrix squares, not entrywise products,
Hadamard squares or scalar squared norms. The Gaussian-first factor order
in Matrix.kroneckerMap is explicit. No alternate function-pointwise Mul
instance is being used for these expressions.

Matrix.PosSemidef expands to IsHermitian and nonnegative quadratic form for
all finitely supported vectors. On the finite paired index set this is the
usual finite-dimensional PSD condition; over the real scalars Hermitian means
symmetric. The producer asks for PosSemidef(C I - sum_i E_mu[Y_i^2]), the
source's Loewner upper bound. It is neither an entrywise inequality nor an
assumed PSD fact. The predicate itself includes Hermitian structure of that
difference, but does not replace the separate internal argument that the
actual summed expected squares are PSD.

The supplied synthesized Matrix L2Operator normed-ring/normed-space and
completeness instances, together with the literal norm excerpts, identify the
norm as the Euclidean operator norm. It is not the entry maximum, a Frobenius
norm or a norm of the sample-space column function. Norm selection supplies
the intended meaning, not an operator-norm bound proof. Its standard linear
identification's injectivity is not a new source/random-map hypothesis.

## Producer and actual centered consumer outputs

The producer concludes integrability of every actual Y_i*Y_i and PSD
domination of their actual expectation sum by C I. Both fields are outputs.
It does not publicly assume an untruncated fourth moment, source rank-one
square formula, t-norm/Gram identity or actual first mean.

The private consumer defines mean_i as the actual Bochner integral of Y_i
under mu and Z_i=Y_i-mean_i. Its deterministic weight is precisely
cos((2q+1)theta_i). It concludes that every Z_i*Z_i and every
(w_i Z_i)*(w_i Z_i) is integrable, and that the operator norms of their two
sums of actual expectations are each at most C. These are genuine real norm
inequalities, not symbolic PSD notation or bounds on supplied formal variance
matrices.

Neither norm expression is E[(sum_i Z_i)^2] or E[(sum_i w_i Z_i)^2]. No
independence/cross-term cancellation bridge is needed or silently presumed.
The fixed consumer does not separately conclude E[Z_i]=0 or a Bernstein
centering certificate; centering here is the literal source definition.
Any needed mean-zero or centered-square identity must be established
internally for its variance proof. No p15 Bernstein outcome is covered.

The norm conclusion requires the internal Hermitian/PSD facts for actual Y,
mean, Z and summed expected squares, the source centered-square comparison,
the deterministic scalar-square comparison with 0<=w_i^2<=1, and the
PSD-to-operator-norm bridge. The producer's upper Loewner bound alone does not
supply those facts. None may become a new convenience binder or a second
target theorem assumed as a certificate.

## Integration and remaining internal applicability

Integrable means an almost-everywhere strongly measurable representative and
finite extended-norm integral, using the actual finite complete matrix normed
space. The explicit integrability conclusions prevent accepting second
moments through the Bochner integral's nonintegrable zero default. Its
representative clause is a standard output predicate, not a replacement of the
literal source matrix definition or an externally supplied representative.

The definition of mean_i also uses a totalized Bochner integral. Integrability
of Y_i itself is not a separate output of these signatures; it remains an
internal source-faithfulness/centering obligation. A later proof must also
justify the required fixed-left/right-matrix products and finite integral
exchanges in E[(Y_i-EY_i)^2]=E[Y_i^2]-(EY_i)^2. This requires no extra
commutativity assumption between Y_i and its mean. No type-only argument here
discharges any such premise or certifies an existing row/mean theorem's
application.

Likewise, the actual row law under the fixed standard-Gaussian product,
canonical Gaussian fourth-moment integrability/coefficient, actual-row moment
transport, rank-one/tensor square algebra, PSD truncation removal under
expectation, exact unweighted source frame bounds and identities, and
integral/PSD/norm compatibility all remain unproved. The standard-Gaussian
definition's basis semantics must match physical evaluation coordinates;
a Gaussian name or historical canonical record is not an applicability
proof. Exact material use of the producer by the private consumer is intended
in the packet, but cannot be inferred from the types.

The packet explicitly sets formalizer_API_pristine=false. The root's zero
new-target proof/API-attempt report is recorded as supplied context, not
independently checked implementation history. The embedded ordinary
matrix-product/norm identity header/body fragments are allowed standard
definition context, not new target proofs. This actor has made no proof/API
attempt and has not opened any target implementation or SG opinion.

Await the separate post-seal source graph for the distinct topology and
applicability-coverage challenge. No new graph has been selected or admitted
using extractor opinions in this phase.
