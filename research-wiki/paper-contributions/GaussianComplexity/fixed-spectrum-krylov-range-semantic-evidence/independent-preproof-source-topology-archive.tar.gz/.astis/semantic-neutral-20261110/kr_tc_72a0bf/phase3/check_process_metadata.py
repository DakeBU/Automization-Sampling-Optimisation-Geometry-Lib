from pathlib import Path
import json,hashlib,subprocess,datetime,stat
OUT=Path(__file__).parent;W=Path('.astis/huanjian-gc-fixed-spectrum-krylov-range-20261110');ROOT=OUT.parent
sha=lambda b:hashlib.sha256(b).hexdigest()
req=json.loads((OUT/'prospective-admission-request.raw.json').read_bytes())
private=[];parsed={}
for name,expected in [('intake-baseline.private.json',req['private_baseline_sha256']),('preproof-baseline.private.json',req['private_preproof_baseline_sha256'])]:
 p=W/name;b=p.read_bytes();assert sha(b)==expected;x=json.loads(b);parsed[name]=x
 schema={k:type(v).__name__ for k,v in x.items()}
 counts={k:len(v) for k,v in x.items() if isinstance(v,(dict,list))}
 private.append({'path':str(p),'bytes':len(b),'sha256':sha(b),'schema_only':schema,'counts_only':counts,'copied_or_exported_private_values':False})
pre=parsed['preproof-baseline.private.json'];base=parsed['intake-baseline.private.json']
assert len(pre['all_foreign_states'])==299 and len(pre['all_existing_frontier_hashes'])==459 and len(pre['all_tracked_regular_file_hashes'])==128851
assert len(base['foreign_control_hashes'])==927 and len(base['control_paths'])==929
assert req['advance_id'] not in pre['all_foreign_states']
assert base['preproof_snapshot']['sha256']==req['private_preproof_baseline_sha256']
assert base['normal_API_calls_so_far']==0
# Inspect only key metadata internally; never export the foreign path/hash inventories.
protected_names=list(pre['all_tracked_regular_file_hashes'])+list(base['foreign_control_hashes'])
restricted_prefixes=['.atlas-upstream/','ATLAS/','atlas-upstream/','research-wiki/atlas-memory/','research-wiki/atlas-index/']
assert not any(any(n.startswith(k) for k in restricted_prefixes) for n in protected_names)
current_head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert current_head==pre['head']
ledger=Path('runs/substantive_advances.jsonl').read_bytes();assert len(ledger)==pre['ledger_bytes'] and sha(ledger)==pre['ledger_sha256']
cellpath=Path(req['own_frontier']);cb=cellpath.read_bytes();assert sha(cb)==req['own_frontier_sha256']==base['own_frontier']['sha256'];cell=json.loads(cb)
(OUT/'own-frontier.raw.json').write_bytes(cb)
assert cell['owner_id']==req['owner'] and cell['status']=='claimed'
assert 'Reserved planning fragment only' in cell['truth_boundary']
assert 'not target proofs or normal SAU intake' in cell['truth_boundary']
assert not (W/'normal-intake-attempted.once.json').exists()
sealpath=Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-krylov-range-statement-seal.json');sb=sealpath.read_bytes();assert sha(sb)==req['seal_sha256'] and sb==(W/'statement-seal-v1.json').read_bytes();seal=json.loads(sb)
(OUT/'root-statement-seal.process-only.raw.json').write_bytes(sb)
assert all(not Path(p).exists() for p in [seal['producer']['planned_file'],seal['actual_private_consumer']['planned_file'],str(W/'StatementFormation.lean')])
env=json.loads((OUT/'actual-environment-before-statement-formation.json').read_bytes())
assert sha(Path('lake-manifest.json').read_bytes())==env['manifest_sha256'];assert Path('lean-toolchain').read_text()==env['toolchain_raw']
assert sha(Path(env['actual_native_binary']).read_bytes())==env['native_binary_sha256']
deps=[]
for d in env['actual_dependencies']:
 p=Path('.lake/packages')/d['name'];h=subprocess.check_output(['git','-C',str(p),'rev-parse','HEAD'],text=True).strip();status=subprocess.check_output(['git','-C',str(p),'status','--porcelain=v1','--untracked-files=all'])
 assert h==d['manifest_rev']==d['actual_HEAD'] and status==b''
 deps.append({'name':d['name'],'HEAD':h,'matches_manifest_and_actual_formation':True,'porcelain_clean':True})
assert len(deps)==9
# Freeze chronology is independently observed from own actual receipts, not root narrative.
mathreceipt=json.loads((ROOT/'phase2c.freeze.receipt.json').read_bytes());assert mathreceipt['root_process_request_read_before_math_freeze'] is False
defs0=json.loads((OUT/'minimal-definition-context.json').read_bytes());defs1=json.loads((OUT/'minimal-definition-context-exact-LF.json').read_bytes())
assert len(defs0['definitions'])==len(defs1['definitions'])==10
result={'checked_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'private_schema_count_hash_metadata_only':private,'no_restricted_prefix_in_guarded_path_keys':True,'private_values_or_inventories_exported':False,'HEAD':current_head,'ledger_raw_hash_and_size_preserved':True,'all_foreign_states_preserved_by_exact_ledger_bytes':299,'own_cell_hash':sha(cb),'source_scope_fragment_label_not_normal_CLAIMED':True,'marker_P_T_and_live_formation_probe_absent':True,'exact_public_and_W_seal_equal':True,'toolchain':env['toolchain_raw'],'native_binary_sha256':env['native_binary_sha256'],'manifest_sha256':env['manifest_sha256'],'all9_dependencies':deps,'core_seal_and_initial_definition_context_preserved_with_exact_LF_overlay':True,'math_freeze_before_process_read':mathreceipt,'prepared_script_sha256':sha((W/'admit_normal_intake_prepared.py').read_bytes()),'intake_executed_by_reviewer':False}
(OUT/'current-process-metadata.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False,indent=2))
