from pathlib import Path
import datetime, gzip, hashlib, json

R = Path('.astis/huanjian-gc-fixed-spectrum-first-order-integration-20261108')
I = R/'independent-reader'
sha = lambda b: hashlib.sha256(b).hexdigest()
ref = lambda p: {'path': str(p), 'sha256': sha(p.read_bytes())}
f = I/'local-acceptance-and-normalpark-eligibility-v4/freeze.json'
assert sha(f.read_bytes()) == 'd9844ff1e40d55477d363fb1310cedf7a0f6e6c20f6bcb0ee084ef777683aee2'
freeze = json.loads(f.read_bytes())
for key in ['capsule', 'local_acceptance', 'normalpark_eligibility', 'provenance',
            'actual_recording_receipt', 'actual_recording_rawlog', 'actual_preservation']:
    p = Path(freeze[key]['path'])
    assert sha(p.read_bytes()) == freeze[key]['sha256']
for row in freeze['raw_archives']:
    original, archive = row['original'], row['archive']
    raw, gz = Path(original['path']).read_bytes(), Path(archive['path']).read_bytes()
    assert sha(raw) == original['sha256'] and sha(gz) == archive['sha256']
    assert gzip.decompress(gz) == raw
local = json.loads(Path(freeze['local_acceptance']['path']).read_bytes())
eligible = json.loads(Path(freeze['normalpark_eligibility']['path']).read_bytes())
assert local['status'] == 'accepted' and eligible['eligible_for_normal_park'] is True
assert local['blocking_objections'] == eligible['blocking_objections'] == []
out = R/'actual-accepted-normalpark-bundle-v2.json'
assert not out.exists()
bundle = {
    'state': 'READY_FOR_SEPARATE_ROOT_PARK_AUTHORIZATION',
    'recorded_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'assembled_by': '/root',
    'accepted_immutable_core': '9b1e90d25711668203c6e252cfe5a748f95c8ad4',
    'browser_context': ref(R/'root-final-browser-context-v4.json'),
    'artifacts': {
        'bound_context_review': ref(I/'late-context-independent-review-v4/late-context-decision.json'),
        'browser_report': ref(I/'browser/live-20261108T160740169669Z/report.json'),
        'browser_command_receipt': ref(Path('.astis/huanjian-resume-20261103/20261108T160725345032Z-fixed-spectrum-first-order-final-browser-v4.receipt.json')),
        'pixel_review': ref(I/'original38-independent-review-v4/pixel-review.json'),
        'local_acceptance': freeze['local_acceptance'],
        'parking_eligibility': freeze['normalpark_eligibility'],
    },
    'note': 'Actual exact native artifacts only. This bundle is not execution permission; prospective guarded preflight and later separate exact root authorization remain required. No new source or remote/wholeGoal verdict.',
}
out.write_text(json.dumps(bundle, ensure_ascii=False, indent=2)+'\n')
print(json.dumps(ref(out)))
