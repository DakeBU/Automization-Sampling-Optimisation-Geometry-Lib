# Variances and target contrast: independent RAW phase 1

This is an independently frozen source reconstruction and inventory, **not a seal, graph admission, proof, source V or completion claim**. No new variance seal/producer/consumer, current implementation/API, lesson/audit, graph, ledger/frontier, root rationale or extractor file has been read.

Exposure is not zero: this actor previously reviewed C7, all-integer grid aliasing, actual Gaussian means and C8 exact-means source packets, including earlier sightings of C.3's neighboring variance text. The present task supplied the anchors and scope. The complete C.3 and the requested bounded additional regions were freshly read from the actual pinned paper. A new source-only HTML locator was written in this directory; it reads only that raw HTML and does not load old extractor or implementation artifacts.

Source pin: `.astis/huanjian-resume-20261103/2610.20492v1.html`, 951991 bytes, SHA-256 `6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915`.

## 1. Actual Gaussian objects and variance route

Standing hard-family parameters are d≥2 and κ≥2, with the literal midpoint θᵢ, cosine eigenvalues λᵢ and precision Λ=diag(λᵢ). The target-coordinate law is **U∼N(0,Λ⁻¹)**: covariance is Λ⁻¹, so the i-th variance is vᵢ=1/λᵢ. It is not λᵢ or 1/λᵢ². The means are actual M=E‖U‖² and μₙ=E[UᵀDₙU], Dₙ=diag(cos(nθᵢ)), for integer 1≤n<d.

The p8.1 paragraph has distinct substantive components:

- Diagonal covariance of an actual Gaussian law makes the coordinate family independent. This is a property to establish from the law, not an added independence premise.
- Each coordinate is centered Gaussian with variance 1/λᵢ; hence E[Uᵢ²]=1/λᵢ and E[Uᵢ⁴]=3/λᵢ², giving Var(Uᵢ²)=2/λᵢ².
- λᵢ≥(κ+1)/2−(κ−1)/2=1 follows from the literal spectrum and cosine lower bound.
- The source then gives two separate actual-variance formulas, Ex148 and Ex149:

\[
\operatorname{Var}(\|U\|^2)=2\sum_i\lambda_i^{-2}
\le 2\sum_i\lambda_i^{-1}=2M,
\]
\[
\operatorname{Var}(U^\top D_nU)
=2\sum_i\frac{\cos^2(n\theta_i)}{\lambda_i^2}\le 2M.
\]

The required omitted analytical bridges include actual coordinate fourth-moment integrability, square integrability of each coordinate square, preservation of independence under squaring/deterministic weighting, finite variance addition/cross-covariance cancellation, variance scaling by real constants, and literal Euclidean norm/diagonal quadratic coordinate identities. They are internal dependencies, not new theorem hypotheses. Signed cosine weights do not require nonnegativity; their **squares** occur in the variance formula. Source bounds use λᵢ≥1 and |cos|≤1.

The norms/quadratic forms and variances must refer to actual observables under the fixed law. A formal variance definition or totalized integral cannot be replaced by the displayed deterministic envelope or exploit a nonintegrable/default value. Finite fourth-coordinate moments must support L2 of the quadratic observables and all needed centering/linearity operations.

## 2. M upper is a separate dependency

The source p8.2 says explicitly: **the exact formula for M gives M≤d/√κ**. Thus the complete source bound is Var(R),Var(Q)≤2M≤2d/√κ, but the M upper proof comes from C8's exact norm mean and radius/denominator facts. Ex148–149, coordinate independence and fourth moments are not prerequisites of M upper merely because its sentence follows their display.

The actual mean-to-grid identity M=Σᵢ1/λᵢ and the actual closed M value are source-backed upstream components. They do not make the new fourth-moment/variance assertions true by definition. No new upper-spectrum or fourth-moment certificate may be supplied as a public convenience premise.

## 3. Contrast statistic, centered L2 triangle and coefficient scope

The source defines n=2q+1 and τ=τ_{d,q} in its **downstream test**, with

\[
S_A(x)=(-1)^n x^\top T_n\!\left(\frac{2A-(\kappa+1)I}{\kappa-1}\right)x
-2\tau\|x\|^2,
\qquad E_A=\{x:S_A(x)>0\}.
\]

The norm coefficient is exactly **−2τ**, not −τ or −4τ. The event is strict positivity. The source geometric weight interpretation is stated only for x≠0; that restriction is not a Gaussian-variance premise or a restriction on the polynomial statistic, which is defined also at x=0.

For fixed A and actual target sample Y∼π_A, write Z=S_A(Y), and β=|μₙ|/M. The signed quadratic mean is (−1)^n μₙ=βM, while the norm-square mean is M. Ex25 states

\[
EZ=(\beta-2\tau)M\ge\beta M/2,
\]
\[
\operatorname{Var}(Z)
\le(\sqrt{2M}+2\tau\sqrt{2M})^2\le8M.
\]

The author explicitly uses the **L2 triangle inequality for centered variables**. The two statistics Q(Y) and ‖Y‖² are generally dependent. Coordinate independence used earlier does not imply independence or zero covariance between these two global quadratic forms. Dropping their covariance and simply adding their variances would not reconstruct this source route. The signed multiplier has absolute value 1 for every integer n; the source's variance lemma itself does not require n odd.

For the displayed triangle expression, 0≤τ is needed to replace |2τ| by 2τ, and τ≤1/2 gives the final 8M bound. The source's τ is nonnegative by its explicit definition, not an arbitrary real with only an upper bound. The mean lower bound separately uses τ≤β/4 and M≥0, with strict positive M and β supplying a usable positive EZ for concentration. These are different mathematical guards, not one interchangeable threshold.

An implementation may have a different valid route, but it cannot silently identify that route with the author's L2 argument or force two alternative proofs into one AND. No alternative complete author route appears in the raw region read here.

## 4. Exact τ, β and probability thresholds

The neighboring Lemma 4.4 statement was read only to recover the definition/condition used by the requested p1.2. It has an absolute C>0, integer q≥0 with 2q+1<d, independent standard starting vectors and

\[
\tau_{d,q}=C\left[(q+1)\sqrt{\frac{\log d}{d}}
+\frac{(q+1)(q+1+\log d)\log d}{d}\right].
\]

For d≥2 these terms are nonnegative. Its algorithm-side statement is conditional on τ_{d,q}≤1/2 and gives probability ≥0.99 of uniform Krylov control. **That probability conclusion is not a Gaussian-variance or target-contrast proof ingredient.** Only the source threshold's meaning/range can be shared; the random starting vectors are not the target U/Y variables.

In the target subsection, M and μₙ are also written as traces and explicitly called target means, relying on the earlier actual Gaussian identities. β is the normalized **actual** bias, not a free unrelated scalar. The source chooses sufficiently large d, in the surrounding theorem's parameter range, so that the algorithmic conditions hold and additionally

\[\tau\le\beta/4,\qquad M\beta^2\ge320.\]

Its asymptotic derivation uses the earlier q bound, n=o(d), κ≤d^(1−δ), d−n≥√κ, the exponential bias bound, and a lower M bound. Those are separate threshold-selection/whole-bound obligations. They are not assumptions of Lemma 4.5's diagonal Gaussian variance statement. They must not be treated as already proved merely by establishing the conditional Ex25 contrast estimate.

The following Chebyshev step is, for every fixed A in the hard family,

\[
\pi_A(E_A)=P(Z>0)
\ge1-\frac{\operatorname{Var}(Z)}{(EZ)^2}
\ge1-\frac{32}{M\beta^2}\ge0.9.
\]

The constants are 2τ, 8M, 32 and 320. Finite variance/L2, positive EZ and measurable event/statistic are internal analytical prerequisites. A target lower probability of 0.9 is distinct from the algorithm-side 0.99 event and from any later TV contradiction. No full lower bound, uniform d₀ selection or algorithmic probability conclusion is certified by this phase.

## 5. Rotated-law boundary

The immediate source application after Lemma 4.5 explicitly says **Y conditional on O has law π_A**, U=OᵀY has law N(0,Λ⁻¹), and the norm/rotated diagonal quadratic identities preserve the two statistics. The test definition additionally uses T_n(cosθᵢ)=cos(nθᵢ) and orthogonal matrix-polynomial conjugation to identify its actual quadratic with the diagonal statistic.

A result only for a literal diagonal U-law does not itself prove that adapter for Y or the actual S_A(Y). One must separately establish actual Gaussian covariance pushforward and the pointwise statistic/norm identities, or explicitly keep that use boundary open. Fixing A/O for this argument does not require a Haar average, an algorithm seed or independence between Y and O; Y depends on O through A in the conditional formulation. Conversely, unconditional randomized-input averaging is not the same probability statement as the fixed-A target bound.

## 6. Source inventory and future checks

The raw inventory covers full C.3, the exact standing/grid/Lemma 4.5 regions, Lemma 4.4's threshold context, the rotated-law application, test definition/geometry and full target-pass subsection, including Ex25 and its Chebyshev follow-up. Named aligned table rows Ex148/149 are separate units; source paragraphs carrying multiple claims retain all attached formulas and links. Structural headings/containers receive descriptive raw roles, not proof credit.

Future exact statement/graph review must distinguish: coordinate Gaussian fourth moments and independence; finite variance addition; λ/cosine estimates; the independent exact-M upper node; actual centered contrast L2; each source threshold; diagonal versus rotated law; and actual measure/function definitions versus deterministic expressions. Proof-result binders must not replace these dependencies.

This phase has not seen a new producer/consumer or graph and makes no decision about one. Earlier means/C7/grid results are prior role context, not newly certified mathematics here. Bias exponent/logarithm work, threshold asymptotics, rotated transport, event concentration, adaptive/algorithm/TV/cost/main-result claims remain separate source components unless a later exact packet explicitly includes and discharges them. No target proof, API, build, browser/network/OS automation, ledger, frontier, shared model or current-Goal transition was performed. Phase 1 stops after this raw freeze.
