#!/usr/bin/env python3
import json
from runner import *
seal=json.loads((REPO/'research-wiki/paper-contributions/GaussianComplexity/source-matrix-mean-statement-seal.json').read_text())
closure=json.loads((OWN/'closure.json').read_text())
prod=seal['producer']['name']
priv='_private.Tests.GaussianComplexityFixedSpectrumSourceMatrixMean.0.'+seal['actual_private_consumer']['name']
def literal(key,name):
    s=seal[key]['signature'];assert sha(s.encode())==seal[key]['signature_sha256']
    head,body=s.split(' :\n',1)
    return 'def '+name+' : Prop := ∀ '+head.strip()+',\n'+body+'\n'
path=OWN/'fresh/src/WholeModuleProbe.lean'
path.write_text('''import Tests.GaussianComplexityFixedSpectrumSourceMatrixMean
open Lean MeasureTheory ProbabilityTheory
open scoped BigOperators Matrix.Norms.L2Operator
set_option autoImplicit false
set_option maxRecDepth 10000
set_option maxHeartbeats 0
'''+literal('producer','IndependentLiteralP')+literal('actual_private_consumer','IndependentLiteralT')+'''
run_cmd do
  setEnv ((← getEnv).setExporting false)
  let env ← getEnv
  let modules : List String := MODULES
  let roots : List Name := [ROOTP, ROOTT]
  let allowed := [`propext, `Classical.choice, `Quot.sound]
  let mut data : Array Json := #[]
  for (n, ci) in env.constants.toList do
    if let some idx := env.getModuleIdxFor? n then
      let mod := env.header.moduleNames[idx.toNat]!
      if modules.contains mod.toString then
        let some body := ci.value? true | throwError "Whole-module body absent {n}"
        let closed := !ci.type.hasLooseBVars && !ci.type.hasFVar && !ci.type.hasMVar &&
          !body.hasLooseBVars && !body.hasFVar && !body.hasMVar
        unless closed do throwError "Unclosed owned declaration {n}"
        let axioms ← Lean.collectAxioms n
        unless axioms.all (fun a => allowed.contains a) do throwError "Disallowed axioms {n}: {axioms}"
        let kind := match ci with
          | .thmInfo _ => "theorem"
          | .defnInfo _ => "definition"
          | .opaqueInfo _ => "opaque"
          | _ => "other"
        let ppType ← Lean.Elab.Command.liftTermElabM <| return (← Lean.Meta.ppExpr ci.type).pretty
        data := data.push <| Json.mkObj [
          ("name", toJson n.toString), ("module", toJson mod.toString),
          ("kind", toJson kind), ("closed", toJson closed),
          ("level_params", toJson (ci.levelParams.map Name.toString)),
          ("axioms", toJson (axioms.toList.map Name.toString)),
          ("type_used", toJson (ci.type.getUsedConstants.toList.map Name.toString)),
          ("body_used", toJson (body.getUsedConstants.toList.map Name.toString)),
          ("type_pretty", toJson ppType), ("type_raw", toJson (reprStr ci.type)),
          ("body_raw", toJson (reprStr body))]
  let mut checks : Array Json := #[]
  for n in roots do
    let ci := env.find! n
    let lit := if n == roots.head! then `IndependentLiteralP else `IndependentLiteralT
    let literal := (env.find! lit).value! true
    Lean.Elab.Command.liftCoreM <| addDecl <| Declaration.thmDecl {
      name := Name.mkSimple (if n == roots.head! then "IndependentKernelApplicationP" else "IndependentKernelApplicationT")
      levelParams := ci.levelParams
      type := mkConst lit
      value := mkConst n (ci.levelParams.map Level.param)
    }
    checks := checks.push <| Json.mkObj [("root",toJson n.toString),
      ("raw_expr_structurally_equal",toJson (ci.type == literal)),
      ("sealed_literal_kernel_application",toJson true)]
  liftIO <| IO.FS.writeFile "DUMPPATH" ((Json.mkObj [("constants",Json.arr data),("literal_checks",Json.arr checks)]).compress)
  logInfo m!"Fresh whole-module constants inspected: {data.size}; sealed literal applications: {checks.size}"

-- Concrete analytical typeclass checks use the same L2 operator norm scope.
example (d q : ℕ) : IsProbabilityMeasure
    (Measure.pi (fun _ : Fin (q+1) => stdGaussian (EuclideanSpace ℝ (Fin d)))) := inferInstance
example (d q : ℕ) : SigmaFinite
    (Measure.pi (fun _ : Fin (q+1) => stdGaussian (EuclideanSpace ℝ (Fin d)))) := inferInstance
example (q : ℕ) : CompleteSpace (Matrix (Fin (q+1)) (Fin (q+1)) ℝ) := inferInstance
example (q : ℕ) : CompleteSpace
    (Matrix (Fin (q+1) × Fin (q+1)) (Fin (q+1) × Fin (q+1)) ℝ) := inferInstance
example (q : ℕ) : FiniteDimensional ℝ (Matrix (Fin (q+1)) (Fin (q+1)) ℝ) := inferInstance
example (q : ℕ) : NormedSpace ℝ
    (Matrix (Fin (q+1) × Fin (q+1)) (Fin (q+1) × Fin (q+1)) ℝ) := inferInstance
example (q : ℕ) (L : ℝ) :
    Integrable (Set.indicator {x : EuclideanSpace ℝ (Fin (q+1)) | ‖x‖ ^ 2 ≤ L}
      (fun x => ‖x‖ ^ 2)) (stdGaussian (EuclideanSpace ℝ (Fin (q+1)))) := by
  exact (AutoSamplingTheory.TechnicalLemmas.Probability.StdGaussianMoment.integrable_norm_sq_and_integral_stdGaussian
    (E := EuclideanSpace ℝ (Fin (q+1)))).1.indicator (measurableSet_le (by fun_prop) measurable_const)
#synth NormedAddCommGroup (Matrix (Fin 2) (Fin 2) ℝ)
#check @MeasureTheory.integral_map
#check @MeasureTheory.MeasurePreserving.integrable_comp_of_integrable
#check @ContinuousLinearMap.integrable_comp
#check @ContinuousLinearMap.integral_comp_comm
#check @LinearMap.toContinuousLinearMap
#check @MeasureTheory.integral_finsetSum
#check @MeasureTheory.integrable_finsetSum
#print axioms IndependentKernelApplicationP
#print axioms IndependentKernelApplicationT
'''.replace('MODULES',repr(closure['topological_order']).replace("'",'"')).replace('ROOTP','`'+prod).replace('ROOTT','`'+priv).replace('DUMPPATH',str(OWN/'local/native-wholemodule.json')))
(OWN/'local').mkdir(exist_ok=True)
print(path)
