"""Perform the normal exploration intake after independent source and topology review."""
from pathlib import Path
import hashlib
import json
import stat
import subprocess
import sys

sys.dont_write_bytecode = True
sys.path.insert(0, 'tools')
import astis_advance as advance
import astis_frontier_cells as frontiers

workspace = Path(__file__).resolve().parent.relative_to(Path.cwd())
paper = Path('research-wiki/paper-contributions/GaussianComplexity')
evidence = paper / 'truncated-row-second-moment-semantic-evidence'
seal_path = paper / 'truncated-row-second-moment-statement-seal-v2.json'
cell_path = Path('research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-truncated-row-second-moment.json')
ledger = Path('runs/substantive_advances.jsonl')
advance_id = 'ASTIS-SA-20261111-GaussianComplexityTruncatedRowMoment'
owner = 'huanjian_gc_20261111_truncated_row_moment'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def dump(obj):
    return (json.dumps(obj, ensure_ascii=False, indent=2) + '\n').encode()


def create(path, raw):
    with path.open('xb') as out:
        out.write(raw)


def git(*args):
    return subprocess.check_output(['git', *args])


def replay(raw):
    return advance._replay_advances([json.loads(line) for line in raw.splitlines()])


inputs = {
    '.astis/semantic-neutral-20261111/rc_sg_28c9/freeze-manifest.json': '6ef5690685a487a0b2de8953221a434db6f761a0478786bd5b7cf45951dbfc3f',
    '.astis/semantic-neutral-20261111/rc_sg_28c9/type-overlay-v2/type-freeze-manifest.json': '341c0a7d6e98ed1d62498ee8c74ee2a75d71eaeb7fab2b92eff1b1d46f5fa697',
    '.astis/semantic-neutral-20261111/rc_sg_28c9/type-overlay-v2/judgment.json': '7b400bde39541bb16dcf123e8d38de2364681a557d4b5799b0206fc8da801d22',
    '.astis/semantic-neutral-20261111/rc_tc_c61a/type_only_judgment_v2.md': 'b75e202001bd26e0dcb590092040791c1898e8a5e9eb25e642318a623de2b8fc',
    '.astis/semantic-neutral-20261111/rc_tc_c61a/type_only_freeze_v2.json': '7eb06f2ead5e12a5c4bd6bf311ae4535b0ff4832fe2abee1235cd68a39b5f26f',
    '.astis/semantic-neutral-20261111/rc_tc_c61a/topology_challenge_verdict.json': '7f6d2b1afab961e6fd7e50eef81e59632cd4f558292830d75e2d494335f793c5',
    '.astis/semantic-neutral-20261111/rc_tc_c61a/topology_challenge_manifest.json': '9d43828dabe00fd18dd53a2557cbd5dd547a4b4649d814d46d3118c405909a0d',
    '.astis/semantic-neutral-20261111/rc_tc_c61a/proposed_minimal_provenance_overlay.json': 'a966b192841e30a00d6962e20b2ef2973e55b2e56225b2b4310eb065d8cae145',
    '.astis/semantic-neutral-20261111/rc_sg_28c9/provenance-repair-review/repair-review-freeze-manifest.json': '3193b29500b1e8eb1ded1fd769a85a324450e51b5a6aac904434ac8eea77e74f',
    '.astis/semantic-neutral-20261111/rc_sg_28c9/provenance-repair-review/repair-review-judgment.json': '49605da6ecd1ed713831af472f26f7548d7fccbb5a0cfe761cac3c9f6eddf753',
    '.astis/semantic-neutral-20261111/rc_sg_28c9/provenance-repair-review/reviewed-port-overlay.json': '28bb9e240a5fa18ca6d9a0e7e6efafe83842f44b425a5c6957fa49149d75e85f',
    '.astis/semantic-neutral-20261111/rc_sg_28c9/provenance-repair-review/closure-and-integrity-checks.json': '90bfd4d5feab5cf9bcc8bbfa3f2713d9106f4c9fd8a10aa4271c09489c2d507d',
}
for name, digest in inputs.items():
    assert sha(Path(name).read_bytes()) == digest, name
review_root = Path('.astis/semantic-neutral-20261111/rc_sg_28c9/provenance-repair-review')
judgment = json.loads((review_root / 'repair-review-judgment.json').read_bytes())
assert judgment['decision'].startswith('ACCEPT') and judgment['all_prior_freezes_unchanged']
assert not judgment['implementation_or_proof_apis_seen']
closure = json.loads((review_root / 'closure-and-integrity-checks.json').read_bytes())
for name in ['all_port_ids_unique', 'all_edge_endpoints_defined', 'all_original_10_hyperedges_refined_exactly_once',
             'acyclic', 'all_ports_in_some_complete_root_backward_closure',
             'covariance_contains_no_theta_feature_or_literal_attribution_port',
             'mean_mathematical_closure_contains_no_added_grid_context',
             'original_source_node_closures_of_both_mathematical_roots_unchanged']:
    assert closure[name], name
assert closure['orphan_ports'] == []
seal_raw = seal_path.read_bytes()
assert sha(seal_raw) == 'ee9d261db9301f0fa750102f8105c27fbbbcef9e8a19f900636b705f461b18dd'
seal = json.loads(seal_raw)
baseline = json.loads((workspace / 'preproof-baseline.private.json').read_bytes())
assert git('rev-parse', 'HEAD').decode().strip() == baseline['head']
assert not git('diff', 'HEAD', '--name-only') and not git('diff', '--cached', '--name-only')
assert git('ls-files', '--stage').decode() == baseline['tracked_git_index']
before = ledger.read_bytes()
assert len(before) == baseline['ledger_bytes'] and sha(before) == baseline['ledger_sha256']
states = replay(before)
assert states == baseline['all_foreign_states'] and advance_id not in states
for name, digest in baseline['all_existing_frontier_hashes'].items():
    assert sha(Path(name).read_bytes()) == digest, name
P, T = [seal[key]['planned_file'] for key in ('producer', 'actual_private_consumer')]
assert not Path(P).exists() and not Path(T).exists()
cell_before = cell_path.read_bytes()
assert sha(cell_before) == 'cde353908b2b0d79f171578ce1658dc0e8a1efbe933812fd8359f9be3fd1f26d'
cell = json.loads(cell_before)
assert cell['status'] == 'claimed' and cell['owner_id'] == owner
assert not frontiers.validate_cells(frontiers.load_cells())

known = set(json.loads(Path('.astis/huanjian-gc-truncated-radial-moment-20261110/intake-controls.private.json').read_bytes()))
known.update(str(p) for p in Path('runs').iterdir())
known.add('website/content/samplewiki_companion_frontiers.json')
for name in ('control', 'queues', 'runtime', 'harness', 'state', 'locks'):
    root = Path('.astis') / name
    if root.is_dir() and not root.is_symlink():
        known.update(str(p) for p in root.rglob('*'))
for path in Path('.astis').iterdir():
    if any(word in path.name.lower() for word in ('queue', 'control', 'goal', 'steer', 'execution')):
        known.add(str(path))
known.update(x.decode() for x in git('ls-files', '--others', '--exclude-standard', '-z').split(b'\0') if x)
controls = {}
for name in sorted(known):
    path = Path(name)
    if path in (ledger, cell_path, seal_path) or path.is_relative_to(evidence) or name.startswith('.atlas-upstream/'):
        continue
    if path.exists():
        info = path.lstat()
        if stat.S_ISREG(info.st_mode) and info.st_size < 100_000_000:
            controls[name] = sha(path.read_bytes())
create(workspace / 'intake-controls.private.json', dump(controls))

record = {
    'kind': 'Prover readback of independently completed source/type/topology judgments',
    'topology_review_status': 'accepted',
    'statement_seal_sha256': sha(seal_raw),
    'reserved_cell_sha256': sha(cell_before),
    'independent_inputs': [{'path': name, 'sha256': digest} for name, digest in inputs.items()],
    'reviewed_overlay': {'path': str(review_root / 'reviewed-port-overlay.json'),
                         'sha256': inputs[str(review_root / 'reviewed-port-overlay.json')]},
    'review_boundary': 'Mathematical source/type/topology acceptance and repaired literal-feature provenance. Joint source row law transport, proof, source verification and integrated publication are separate.',
    'prover_source_VERIFIED_calls': 0,
    'no_extra_process_grant': 'Normal intake follows the mathematical independent reviews and existing user authorization.',
}
record_raw = dump(record)
record_path = evidence / 'preproof-source-admission.json'
create(record_path, record_raw)
proposal = advance.AdvanceProposal(
    advance_id=advance_id, task_id='ASTIS-SW-GAUSSIAN-COMPLEXITY-2026',
    goal='Prove the unnormalized truncated Gaussian row second moment and consume it in the actual single-row matrix mean.',
    source_anchor=cell['source_anchor'], theorem_delta=seal['producer']['signature'],
    truth_boundary=seal['scope_boundary'], created_by=owner,
    dag_inputs=(cell['source_anchor'], 'Canonical standard Gaussian and matrix Bochner definitions. All symmetry, scalar and matrix integrability and deterministic Kronecker extraction are internal obligations.'),
    proposed_files=tuple(p for p in cell['owned_files'] if not p.endswith('/')),
    focused_checks=('lake env lean ' + P, 'lake build Tests.GaussianComplexityFixedSpectrumTruncatedRowMoment'),
    modes=('source-reading', 'proof-design', 'compiler-diagnosis'), priority=50,
    frontier_cell=cell_path.stem, target_declarations=(seal['producer']['name'],),
)
proposal.validate()
create(workspace / 'normal-intake-attempted.once.json', dump({
    'advance_id': advance_id, 'before_ledger_sha256': sha(before),
    'independent_math_review_record_sha256': sha(record_raw), 'no_replay': True,
}))
evidence_event = {
    'independent_topology': {'file': str(record_path), 'sha256': sha(record_raw)},
    'statement_seal_sha256': sha(seal_raw), 'truth_boundary': seal['scope_boundary'],
}
advance.propose_advance(proposal)
advance.transition_advance(advance_id, 'CLAIMED', worker_id=owner, evidence=evidence_event)
advance.transition_advance(advance_id, 'EXPLORING', worker_id=owner, evidence=evidence_event)
after = ledger.read_bytes()
assert after.startswith(before)
append = after[len(before):]
events = [json.loads(line) for line in append.splitlines()]
assert len(events) == 3 and all(event['advance_id'] == advance_id for event in events)
assert [event.get('state', event.get('to_state')) for event in events] == ['PROPOSED', 'CLAIMED', 'EXPLORING']
now = replay(after)
assert now.pop(advance_id)['state'] == 'EXPLORING' and now == states
assert git('diff', 'HEAD', '--name-only').decode().splitlines() == [str(ledger)]
for name, digest in baseline['all_existing_frontier_hashes'].items():
    assert sha(Path(name).read_bytes()) == digest, name
for name, digest in controls.items():
    assert sha(Path(name).read_bytes()) == digest, name
assert cell_path.read_bytes() == cell_before
cell['evidence']['preproof_source_admission'] = evidence_event['independent_topology']
cell['evidence'].pop('normal_API_and_target_proof_calls')
cell['evidence']['normal_API_calls'] = 3
cell['evidence']['target_proof_calls'] = 0
cell['statement_seal']['status'] = 'EXACT_V2_TYPES_AND_DEFINITIONS;INDEPENDENT_TOPOLOGY_AND_PROVENANCE_REPAIR_ACCEPTED;UNPROVED'
cell['reservation_only'] = 'Normal ledger now records EXPLORING under the named owner.'
cell_path.write_bytes(dump(cell))
create(evidence / 'normal-EXPLORING-append.exact.jsonl', append)
summary = {
    'state': 'EXPLORING', 'append_sha256': sha(append), 'actual_normal_API_calls': 3,
    'foreign_full_states_preserved': len(states),
    'older_frontier_files_preserved': len(baseline['all_existing_frontier_hashes']),
    'foreign_controls_preserved': len(controls), 'target_proof_or_sourceV': False,
    'baseline_commit': baseline['head'],
}
create(evidence / 'normal-intake-preservation.json', dump(summary))
assert not frontiers.validate_cells(frontiers.load_cells())
print(json.dumps(summary))
