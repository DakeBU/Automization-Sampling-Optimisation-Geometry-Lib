"""New packet-specific real clipboard/navigation/graph UI checks."""
import json
from pathlib import Path
from urllib.parse import urljoin, urlparse

PFILE = 'AutoSamplingTheory/TechnicalLemmas/Probability/MatrixBernsteinMgf.lean'
TFILE = 'Tests/GaussianComplexityBernsteinWeightedMgf.lean'

def step_actions(page, context, steps, source_root, output, label, check, screenshot, variant):
    wanted = [PFILE] * 3 + [TFILE] * 3
    starts = [1, 45, 88, 1, 120, 139]
    for index, raw in enumerate(wanted):
        step = steps.nth(index)
        code = step.locator('pre.code-block > code').text_content()
        source = step.locator('a[data-step-source]')
        downloads = step.locator('a[download]')
        buttons = step.locator('button[data-lean-copy]')
        adjacent = source.count() == downloads.count() == buttons.count() == 1
        check(label + '-step-' + str(index + 1) + '-adjacent-source-copy-full-download', adjacent,
              {'source_links': source.count(), 'downloads': downloads.count(), 'copy_buttons': buttons.count(), 'expected_source': raw})
        if not adjacent:
            continue
        check(label + '-step-' + str(index + 1) + '-correct-P-P-P-T-T-T-source',
              source.get_attribute('href').endswith(raw + '.html#L' + str(starts[index]))
              and downloads.get_attribute('href').endswith('downloads/lean/' + raw)
              and step.locator('details[data-step-source-path]').get_attribute('data-step-source-path') == raw)
        buttons.click()
        actual_clipboard = page.evaluate('navigator.clipboard.readText()')
        check(label + '-step-' + str(index + 1) + '-actual-clipboard-exact-displayed-code', actual_clipboard == code)
        with page.expect_download() as pending:
            downloads.click()
        destination = output / (label + '-step-' + str(index + 1) + '-full-module.lean')
        pending.value.save_as(str(destination))
        check(label + '-step-' + str(index + 1) + '-actual-download-complete-module-byte-exact', destination.read_bytes() == (source_root / raw).read_bytes())
        prior_url = page.url
        with page.expect_navigation(wait_until='networkidle'):
            source.click()
        anchor = page.locator('#L' + str(starts[index]))
        check(label + '-step-' + str(index + 1) + '-actual-source-navigation',
              page.url.endswith(raw + '.html#L' + str(starts[index])) and anchor.count() == 1)
        geometry = anchor.evaluate('''el=>{const r=el.getBoundingClientRect(),h=document.querySelector('.mobile-bar'),s=h?getComputedStyle(h):null;return {top:r.top,bottom:r.bottom,height:r.height,header:s&&s.display!=='none'&&['fixed','sticky'].includes(s.position)?h.getBoundingClientRect().bottom:0};}''')
        check(label + '-step-' + str(index + 1) + '-adjacent-source-anchor-below-header', geometry['top'] >= geometry['header'] - 1, geometry)
        page.go_back(wait_until='networkidle')
        page.wait_for_url(prior_url)
        page.locator('details').evaluate_all('(xs)=>xs.forEach(x=>x.open=true)')

def source_extra(page, raw, exact, output, label, check):
    spans = page.locator('pre span[id^="L"]')
    coverage = spans.evaluate_all('''xs=>xs.map(el=>{const r=el.getBoundingClientRect(); const text=el.textContent; return {id:el.id,characters:text.length,height:r.height,width:r.width,nonempty:text.trim().length>0};})''')
    check(label + '-' + ('P' if raw == PFILE else 'T') + '-every-source-line-has-real-layout',
          len(coverage) == len(exact.splitlines()) and all(row['height'] > 0 for row in coverage), coverage)
    button = page.locator('.native-source-context button[data-lean-copy]')
    if button.count() == 1:
        button.click()
        copied = page.evaluate('navigator.clipboard.readText()')
        check(label + '-' + ('P' if raw == PFILE else 'T') + '-actual-copy-complete-source-byte-exact', copied.encode() == exact.encode())

def graph_font(node):
    return node.evaluate('''el=>{const t=el.querySelector('text.label'),b=t.getBBox(),r=t.getBoundingClientRect(),m=t.getScreenCTM(),nr=el.getBoundingClientRect();return {text:t.textContent,fontCSS:parseFloat(getComputedStyle(t).fontSize),scale:Math.hypot(m.a,m.b),effectiveFontPx:parseFloat(getComputedStyle(t).fontSize)*Math.hypot(m.a,m.b),left:nr.left,right:nr.right,top:nr.top,bottom:nr.bottom,width:nr.width,height:nr.height,viewportWidth:innerWidth,viewportHeight:innerHeight};}''')

def zoom_real_ui(page, node, screenshot, label):
    svg = page.locator('[data-graph-svg]')
    svg.scroll_into_view_if_needed()
    page.wait_for_timeout(100)
    before = graph_font(node)
    # Native existing wheel/pointer handlers only; never set SVG transforms.
    for _ in range(5):
        current = graph_font(node)
        if current['effectiveFontPx'] >= 13:
            break
        box = svg.bounding_box()
        viewport = page.viewport_size
        x = min(max((current['left'] + current['right']) / 2, max(12, box['x'] + 12)), viewport['width'] - 12)
        y = min(max((current['top'] + current['bottom']) / 2, max(80, box['y'] + 12)), viewport['height'] - 20)
        page.mouse.move(x, y)
        page.mouse.wheel(0, -850)
        page.wait_for_timeout(100)
    # Pan with actual pointer events to bring the zoomed selected node center in view.
    for _ in range(4):
        current = graph_font(node)
        box = svg.bounding_box()
        viewport = page.viewport_size
        desired_x = viewport['width'] / 2
        desired_y = max(110, min(viewport['height'] / 2, box['y'] + box['height'] / 2))
        dx = desired_x - (current['left'] + current['right']) / 2
        dy = desired_y - (current['top'] + current['bottom']) / 2
        if abs(dx) < 12 and abs(dy) < 12:
            break
        start_x = max(15, min(viewport['width'] - 15, box['x'] + 18))
        start_y = max(90, min(viewport['height'] - 30, box['y'] + 18))
        move_x = max(-start_x + 8, min(viewport['width'] - start_x - 8, dx))
        move_y = max(-start_y + 80, min(viewport['height'] - start_y - 8, dy))
        page.mouse.move(start_x, start_y)
        page.mouse.down()
        page.mouse.move(start_x + move_x, start_y + move_y, steps=8)
        page.mouse.up()
        page.wait_for_timeout(100)
    after = graph_font(node)
    screenshot(page, label + '-actual-UI-zoom-pan')
    return {'default_fit': before, 'after_real_wheel_and_pointer_UI': after, 'DOM_transform_mutation': False,
            'default_fit_effective_font_below_12px': before['effectiveFontPx'] < 12}

def graph_extra(page, context, origin, selected, label, check, screenshot, P, PMOD, TMOD):
    page.locator('[data-graph-svg]').scroll_into_view_if_needed()
    page.wait_for_timeout(100)
    selected_node = page.locator('.ulg-node.selected')
    default = graph_font(selected_node)
    screenshot(page, label + '-graph-default-fit-selected')
    measured = zoom_real_ui(page, selected_node, screenshot, label + '-graph-public-P')
    after = measured['after_real_wheel_and_pointer_UI']
    check(label + '-graph-public-P-readable-after-existing-UI-zoom-pan',
          after['effectiveFontPx'] >= 12 and after['right'] > 0 and after['left'] < page.viewport_size['width']
          and after['bottom'] > 70 and after['top'] < page.viewport_size['height'], measured)
    edge_style = page.locator('path.ulg-edge').evaluate_all('''xs=>xs.map(x=>({formal:x.classList.contains('formal-edge'),overlay:x.classList.contains('overlay-edge'),dash:getComputedStyle(x).strokeDasharray,marker:getComputedStyle(x).markerEnd}))''')
    check(label + '-graph-rendered-solid-formal-dashed-source-arrows',
          any(x['formal'] and x['dash'] == 'none' for x in edge_style)
          and any(x['overlay'] and x['dash'] != 'none' for x in edge_style), edge_style)
    # Actual on-page local navigation, not external primary-source links.
    goto = lambda path: page.goto(origin + '/' + path, wait_until='networkidle')
    goto('source-index.html')
    screenshot(page, label + '-source-index')
    reader = page.locator('a[href*="proofs/huanjian-matrix-bernstein-mgf.html"]').first
    check(label + '-source-index-own-reader-link-present', reader.count() == 1)
    with page.expect_navigation(wait_until='networkidle'):
        reader.click()
    check(label + '-source-index-actual-reader-navigation', '/proofs/huanjian-matrix-bernstein-mgf.html' in page.url)
    graph_nav = page.locator('.mgf-preview-nav a[href*="lean-foundations"]').first
    with page.expect_navigation(wait_until='networkidle'):
        graph_nav.click()
    page.wait_for_selector('.ulg-node.selected')
    check(label + '-reader-actual-Lean-graph-navigation', page.locator('.ulg-node.selected').get_attribute('data-id') == 'decl:' + P)
    graph = context.request.get(origin + '/data/underlying-lean-graph.json').json()
    desired = [n for n in graph['nodes'] if n['kind'] == 'declaration' and n['id'] != 'decl:' + P]
    desired += [next(n for n in graph['nodes'] if n['id'] == 'module:' + TMOD)]
    for number, item in enumerate(desired, 1):
        goto('lean-foundations.html?view=lean')
        search = page.locator('[data-graph-search]')
        search.fill(item['label'])
        node = page.locator('.ulg-node[data-id="' + item['id'] + '"]')
        node.wait_for()
        page.wait_for_timeout(100)
        node.scroll_into_view_if_needed()
        node.click(timeout=10000)
        page.wait_for_timeout(100)
        check(label + '-parent-' + str(number) + '-actual-selected-node', page.locator('.ulg-node.selected').get_attribute('data-id') == item['id'])
        readable = zoom_real_ui(page, page.locator('.ulg-node.selected'), screenshot, label + '-parent-' + str(number))
        check(label + '-parent-' + str(number) + '-readable-existing-graph-UI', readable['after_real_wheel_and_pointer_UI']['effectiveFontPx'] >= 12, readable)
        detail = page.locator('[data-graph-detail]')
        detail.scroll_into_view_if_needed()
        screenshot(page, label + '-parent-' + str(number) + '-detail')
        link = detail.locator('.ulg-links a.primary').first
        check(label + '-parent-' + str(number) + '-exact-local-reader-or-source-link', link.get_attribute('href') == item['url'])
        with page.expect_navigation(wait_until='networkidle'):
            link.click()
        check(label + '-parent-' + str(number) + '-actual-parent-navigation', page.url == urljoin(origin + '/', item['url']))
        screenshot(page, label + '-parent-' + str(number) + '-opened-context')
    return {'default_fit': default, 'default_fit_limitation_preserved': default['effectiveFontPx'] < 12,
            'readability_observed_after_real_existing_UI_zoom_pan': True, 'parents_and_private_module_navigated': len(desired)}
