import json, pathlib
from html.parser import HTMLParser
BASE=pathlib.Path(__file__).resolve().parent
SOURCE=pathlib.Path('/Users/zhouhuanjian/ASTIS-GC/.astis/huanjian-handoff-20261019/2610.20492v1.html')
raw=SOURCE.read_text()
class Node:
    def __init__(self,tag='',attrs=(),parent=None,start=0):
        self.tag=tag; self.attrs=dict(attrs); self.parent=parent; self.children=[]; self.start=start; self.end=start
    def text(self):
        if self.tag=='math' and 'alttext' in self.attrs:
            return '$'+self.attrs['alttext']+'$'
        return ' '.join(x.text() if isinstance(x,Node) else x for x in self.children).strip()
class Parser(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True); self.root=Node(); self.stack=[self.root]; self.ids={}
        self.offset=[0]
        for line in raw.splitlines(keepends=True): self.offset.append(self.offset[-1]+len(line))
    def absolute(self):
        line,col=self.getpos(); return self.offset[line-1]+col
    def handle_starttag(self,tag,attrs):
        n=Node(tag,attrs,self.stack[-1],self.absolute()); self.stack[-1].children.append(n)
        if 'id' in n.attrs: self.ids[n.attrs['id']]=n
        if tag not in ['area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr']:
            self.stack.append(n)
        else: n.end=self.absolute()+len(self.get_starttag_text())
    def handle_startendtag(self,tag,attrs):
        self.handle_starttag(tag,attrs)
        if self.stack[-1].tag==tag: self.stack.pop().end=self.absolute()+len(self.get_starttag_text())
    def handle_endtag(self,tag):
        for i in range(len(self.stack)-1,0,-1):
            if self.stack[i].tag==tag:
                for n in self.stack[i:]: n.end=raw.find('>',self.absolute())+1
                del self.stack[i:]; return
    def handle_data(self,data): self.stack[-1].children.append(data)
p=Parser(); p.feed(raw)
requested=['A3.Ex85','A3.Ex107','A3.SS2.p10','A3.SS2.p13','A3.Ex112','A3.Ex121','A3.SS2.p15','A3.SS2.p15.2']
def record(n):
    return {'id':n.attrs.get('id'),'tag':n.tag,'start':n.start,'end':n.end,'text':n.text(),'raw_html':raw[n.start:n.end]}
anchors=[record(p.ids[v]) for v in requested]
neighbor_ids={}
for v in ['A3.Ex85','A3.Ex107']:
    n=p.ids[v]; siblings=[x for x in n.parent.children if isinstance(x,Node)]; j=siblings.index(n)
    neighbor_ids[v]={'parent':n.parent.attrs.get('id'),'preceding_ids':[x.attrs.get('id') for x in siblings[max(0,j-6):j]],'following_ids':[x.attrs.get('id') for x in siblings[j+1:j+3]]}
out={'source':str(SOURCE),'requested':requested,'anchors':anchors,'neighbor_ids':neighbor_ids}
(BASE/'gaussian-selected.raw.json').write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n')
for a in anchors: print(a['id']+'\n'+a['text']+'\n')
print('NEIGHBOR IDS',json.dumps(neighbor_ids,ensure_ascii=False))
