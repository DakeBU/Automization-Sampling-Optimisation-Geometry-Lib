from pathlib import Path
import subprocess,json,hashlib,datetime
R=Path.cwd();W=Path(__file__).resolve().parent;sha=lambda b:hashlib.sha256(b).hexdigest()
C='65776f88e92b9680e6afe0d4c20b7390e4521241'
records=[]
def run(argv):
 p=subprocess.run(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 records.append({'argv':argv,'exit_code':p.returncode,'stdout':p.stdout.decode(errors='replace'),'stderr':p.stderr.decode(errors='replace')})
 assert p.returncode==0,records[-1]
 return p.stdout
head=run(['git','rev-parse','HEAD']).decode().strip();assert head==C
m=json.loads(Path('lake-manifest.json').read_bytes()); deps=[]
for d in m['packages']:
 p=Path('.lake/packages')/d['name'];rev=run(['git','-C',str(p),'rev-parse','HEAD']).decode().strip();assert rev==d['rev']
 status=run(['git','-C',str(p),'status','--porcelain=v1','--untracked-files=no']).decode()
 deps.append({'name':d['name'],'head':rev,'manifest_revision':d['rev'],'tracked_dirty_porcelain':status})
map=json.loads(Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-detector-semantic-evidence/source-to-lean-map-v1.json').read_bytes()); checked=[]
for f in sorted(set(r['lean']['file'] for r in map['rows'])):
 p=Path(f);raw=p.read_bytes()
 if f.startswith('.lake/packages/mathlib/'):
  gitraw=run(['git','-C','.lake/packages/mathlib','show','HEAD:'+f.removeprefix('.lake/packages/mathlib/')])
 else:gitraw=run(['git','show',C+':'+f])
 assert raw==gitraw,f
 checked.append({'path':f,'size':len(raw),'sha256':sha(raw),'pinned_git_bytes_equal':True})
initial=json.loads((W/'initial-bindings.json').read_text());bound=[]
for row in initial['bindings']:
 p=Path(row['path']);raw=p.read_bytes();candidate=run(['git','show',C+':'+str(p)])
 assert raw==candidate and sha(raw)==row['commit_sha256'],str(p)
 bound.append({'path':str(p),'size':len(raw),'sha256':sha(raw),'unchanged_since_initial':True})
status=run(['git','status','--porcelain=v1','--untracked-files=normal']).decode()
diff=run(['git','diff','--name-status',C]).decode()
r={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'actual_head':head,'candidate':C,'tracked_diff_from_candidate':diff,'worktree_status':status,'dependencies':deps,'all_locator_files_pinned_git_bytes_equal':checked,'initial_bound_inputs_unchanged':bound,'commands':records}
(W/'final-context-results.json').write_text(json.dumps(r,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({k:v for k,v in r.items() if k!='commands'},indent=2,ensure_ascii=False))
