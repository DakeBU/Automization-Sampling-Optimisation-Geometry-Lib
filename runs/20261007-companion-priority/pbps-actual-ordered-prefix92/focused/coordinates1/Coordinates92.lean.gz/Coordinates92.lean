import AutoSamplingTheory.ExampleCases.ProximalBPS.ActualAbsoluteNextEventTime
import Mathlib.MeasureTheory.Constructions.Pi
import Mathlib.Order.Fin.Tuple

/-! Internal ordered-simplex induction coordinates for sealed92. -/
namespace OrderedCoordinates92
open MeasureTheory
open scoped NNReal ENNReal
noncomputable section
set_option autoImplicit false

private theorem strictMono_snoc (n : ℕ) (f : Fin (n + 1) → ℝ) (u : ℝ) :
    StrictMono (Fin.snoc f u) ↔ StrictMono f ∧ f (Fin.last n) < u := by
  rw [Fin.strictMono_iff_lt_succ, Fin.forall_iff_castSucc]
  simp only [Fin.succ_castSucc, Fin.snoc_castSucc, Fin.castSucc_last,
    Fin.snoc_last, Fin.succ_last]
  rw [← Fin.strictMono_iff_lt_succ]

private theorem simplex_snoc (n : ℕ) (T : ℝ≥0) (t : Fin n → ℝ) (u : ℝ) :
    (StrictMono (Fin.cons (0 : ℝ) (Fin.snoc t u)) ∧
      ∀ i, Fin.snoc t u i < (T : ℝ)) ↔
    (StrictMono (Fin.cons (0 : ℝ) t) ∧ ∀ i, t i < (T : ℝ)) ∧
      (Fin.cons (0 : ℝ) t : Fin (n+1) → ℝ) (Fin.last n) < u ∧ u < (T : ℝ) := by
  rw [Fin.cons_snoc_eq_snoc_cons, strictMono_snoc]
  simp only [Fin.forall_iff_castSucc, Fin.snoc_castSucc, Fin.snoc_last]
  tauto

private theorem snoc_volume_preserving (n : ℕ) :
    MeasurePreserving (fun p : ℝ × (Fin n → ℝ) => Fin.snoc p.2 p.1)
      (volume.prod volume) (volume : Measure (Fin (n+1) → ℝ)) := by
  have h := (volume_preserving_piFinSuccAbove (fun _ : Fin (n+1) => ℝ) (Fin.last n)).symm
  simpa only [MeasurableEquiv.piFinSuccAbove_symm_apply, Fin.insertNth_last'] using h

end
end OrderedCoordinates92
