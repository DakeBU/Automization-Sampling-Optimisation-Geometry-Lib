"""Exercise the bounded production render in a real browser at two widths."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import mimetypes
import subprocess
import sys
from urllib.parse import unquote, urlsplit

from playwright.sync_api import sync_playwright

revision = '1baba1dd32bb79b66a541251f5a16ae6fdc54076'
site, output = (Path(x).resolve() for x in sys.argv[1:])
if output.exists():
    output = output / ('attempt-' + datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ'))
output.mkdir(exist_ok=False)
host = 'https://samplewiki.test'
slug = 'huanjian-gaussian-truncated-radial-moment'
lesson_file = f'website/content/declaration_lessons/{slug}.json'
source_index = '/example-cases/samplewiki/companions/gaussian-sampling-complexity.html'
proof_path = f'/proofs/source-{slug}.html'
private_path = '/data/lesson-sources/Tests/GaussianComplexityFixedSpectrumTruncatedRadialMoment.lean.html'
chrome = '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'


def git_blob(path):
    return subprocess.check_output(['git', 'show', f'{revision}:{path}'])


def sha(data):
    return hashlib.sha256(data).hexdigest()


lesson = json.loads(git_blob(lesson_file))['units'][0]
formula = lesson['formula']
files = {path: (site / path.lstrip('/')).read_bytes() for path in (source_index, proof_path, private_path)}
report = {
    'commit': revision, 'scope': 'Bounded production-render HTML and exact local static assets via intercepted browser requests',
    'render_sha256': {path: sha(data) for path, data in files.items()},
    'assets': {}, 'pages': [], 'errors': [],
    'public_integration': 'HOLD', 'canonical_source_index_and_graph': 'HOLD',
}


def intercept(route):
    url = urlsplit(route.request.url)
    path = unquote(url.path)
    if url.netloc != 'samplewiki.test':
        route.abort()
        return
    if path in files:
        route.fulfill(body=files[path], content_type='text/html; charset=utf-8')
        return
    if path.startswith('/assets/'):
        rel = Path(path.removeprefix('/assets/'))
        assert not rel.is_absolute() and '..' not in rel.parts
        candidate = Path('website/static') / rel
        if candidate.is_file():
            raw = candidate.read_bytes()
            assert raw == git_blob(candidate)
            report['assets'][path] = sha(raw)
            mime = mimetypes.guess_type(path)[0] or 'application/octet-stream'
            route.fulfill(body=raw, content_type=mime)
            return
    route.fulfill(status=404, body='Outside the bounded render')


def open_details(details):
    assert details.get_attribute('open') is None
    details.locator(':scope > summary').click()
    assert details.get_attribute('open') is not None


def no_overflow(page):
    return page.evaluate('document.documentElement.scrollWidth <= innerWidth + 1')


def math_ready(page, scope):
    page.wait_for_function('Boolean(window.MathJax?.startup?.promise)', timeout=30000)
    page.evaluate('() => MathJax.startup.promise')
    scope.locator('mjx-container').first.wait_for(timeout=12000, state='visible')
    assert scope.locator('mjx-merror, [data-mjx-error]').count() == 0


try:
    with sync_playwright() as playwright:
        browser = playwright.chromium.launch(headless=True, executable_path=chrome)
        report['browser_version'] = browser.version
        for width, height in [(1440, 1000), (390, 844)]:
            context = browser.new_context(viewport={'width': width, 'height': height})
            context.route('**/*', intercept)
            page = context.new_page()
            page.on('pageerror', lambda error: report['errors'].append(str(error)))
            assert page.goto(host + source_index, wait_until='domcontentloaded').status == 200
            index_fold = page.locator('details.paper-verified-index')
            open_details(index_fold)
            unit_fold = page.locator('details.paper-verified-unit').filter(has=page.locator(f'a[href$="source-{slug}.html"]'))
            open_details(unit_fold)
            link = unit_fold.locator(f'a[href$="source-{slug}.html"]')
            assert link.count() == 1 and link.is_visible()
            link.click()
            page.wait_for_url(host + proof_path)
            article = page.locator(f'article[data-authored-declaration="{lesson["declaration"]}"]')
            main = article.locator('.reader-main-equation')
            assert article.locator('details[open]').count() == 0
            math_ready(page, main)
            assert main.locator('mjx-container').count() == 1 and no_overflow(page)
            assert formula in files[proof_path].decode().replace('&amp;', '&').replace('&gt;', '>').replace('&lt;', '<')
            assert main.locator('mjx-container').evaluate('(el) => el.getBoundingClientRect().width <= el.parentElement.clientWidth + 1')
            shot = output / f'main-{width}.png'
            main.screenshot(path=str(shot))

            complete = article.locator('details').filter(has=page.get_by_text('Complete source statement and conditions', exact=True))
            assert complete.count() == 1
            open_details(complete)
            math_ready(page, complete)
            assert complete.locator('mjx-container').count() >= 3
            complete.locator(':scope > summary').click()
            assumptions = article.locator('.assumption-ledger')
            open_details(assumptions)
            assert assumptions.get_by_text('The discarded event is', exact=False).is_visible()
            assumptions.locator(':scope > summary').click()

            steps = article.locator('details.reader-proof-disclosure')
            assert steps.count() == 5
            step_controls = []
            for i, expected in enumerate(lesson['steps']):
                step = steps.nth(i)
                open_details(step)
                math_ready(page, step)
                lean = step.locator(':scope > details')
                open_details(lean)
                code = lean.locator('code.language-lean')
                assert code.is_visible() and code.text_content().strip('\n') == expected['lean'].strip('\n')
                assert no_overflow(page)
                step_controls.append({
                    'copy': lean.locator('[data-lean-copy]').count(),
                    'download': lean.locator('a[download]').count(),
                })
                step.locator(':scope > summary').click()
            provenance = article.locator('details.proof-reader-provenance')
            open_details(provenance)
            private_link = provenance.locator('a[href*="lesson-sources"][href$="#L18"]')
            assert private_link.count() == 1
            private_link.click()
            page.wait_for_url(host + private_path + '#L18')
            assert page.locator('#L18').text_content() == 'private theorem actual_truncated_radial_bias'
            report['pages'].append({
                'width': width, 'height': height, 'visible_main_math': True, 'complete_source_math': True,
                'assumption_fold': True, 'exact_step_folds': 5, 'step_controls': step_controls,
                'companion_link': proof_path, 'private_context_link': private_path + '#L18',
                'screenshot': {'file': shot.name, 'sha256': sha(shot.read_bytes())},
            })
            context.close()
        browser.close()
    assert not report['errors'], report['errors']
    report['bounded_browser'] = 'PASS'
except BaseException as error:
    report['bounded_browser'] = 'FAILED'
    report['exception'] = repr(error)
    raise
finally:
    (output / 'actual-browser-report.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'bounded_browser': report.get('bounded_browser'), 'report': str(output / 'actual-browser-report.json'), 'completed_widths': [x['width'] for x in report['pages']]}))
