import Tests.GaussianComplexityFixedSpectrumGridAlias
open scoped BigOperators
open Lean
set_option autoImplicit false

example {d : ℕ} (hd : 2 ≤ d) (k : ℤ) :
  let θ : Fin d → ℝ := fun i => ((i.val : ℝ) + 1 / 2) * Real.pi / (d : ℝ)
  (∑ i : Fin d, Real.cos ((k : ℝ) * θ i)) =
    (d : ℝ) * (if (2 * (d : ℤ)) ∣ k then
      (-1 : ℝ) ^ (k / (2 * (d : ℤ))) else 0) := by
  exact AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumGridAlias.actual_midpoint_grid_cosine_alias hd k

def ExpectedPrivate : Prop := ∀ {d : ℕ} (hd : 2 ≤ d)
    {κ : ℝ} (hκ : 2 ≤ κ) (n : ℕ) (hn : 1 ≤ n) (hnd : n < d),
  let θ : Fin d → ℝ := fun i => ((i.val : ℝ) + 1 / 2) * Real.pi / (d : ℝ)
  let eigenvalue : Fin d → ℝ := fun i => (κ + 1) / 2 + (κ - 1) / 2 * Real.cos (θ i)
  let r : ℝ := (Real.sqrt κ - 1) / (Real.sqrt κ + 1)
  let a : ℤ → ℝ := fun k =>
    if (2 * (d : ℤ)) ∣ k then (-1 : ℝ) ^ (k / (2 * (d : ℤ))) else 0
  Summable (fun j : ℕ => (-r) ^ (j + 1) *
    (a (((j + 1 : ℕ) : ℤ) - (n : ℤ)) +
      a (((j + 1 : ℕ) : ℤ) + (n : ℤ)))) ∧
  (∑ i : Fin d, Real.cos ((n : ℝ) * θ i) / eigenvalue i) =
    ((d : ℝ) / Real.sqrt κ) * ∑' j : ℕ, (-r) ^ (j + 1) *
      (a (((j + 1 : ℕ) : ℤ) - (n : ℤ)) +
        a (((j + 1 : ℕ) : ℤ) + (n : ℤ)))


run_cmd do
  let env := (← getEnv).setExporting false
  setEnv env
  let target := `AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumGridAlias.actual_midpoint_grid_cosine_alias
  let c7 := `AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumCosineExpansion.actual_inverse_spectrum_cosine_expansion
  let wanted := env.constants.toList.filter fun (n, _) =>
    n == target || n.toString.endsWith ".actual_weighted_inverse_grid_alias_series"
  unless wanted.length == 2 do throwError "Expected exactly two actual packet theorem constants"
  let allowed := [`propext, `Classical.choice, `Quot.sound]
  for (n, ci) in wanted do
    match ci with
    | .thmInfo _ => pure ()
    | _ => throwError "Actual packet constant must be a theorem: {n}"
    let some proof := ci.value? true | throwError "Missing actual kernel proof term"
    let used := proof.getUsedConstants.toList
    let astis := used.filter fun k => k.toString.startsWith "AutoSamplingTheory."
    if n == target then
      unless astis.isEmpty do throwError "Unexpected public ASTIS producer parent: {astis}"
    else
      unless astis.length == 2 && astis.contains target && astis.contains c7 do
        throwError "Actual consumer must use exactly new canonical alias and C7: {astis}"
    let axs ← Lean.collectAxioms n
    unless axs.all (fun a => allowed.contains a) do throwError "Unexpected axiom: {axs}"
    logInfo m!"ACTUAL_THEOREM_CONSTANT {n}"
    logInfo m!"ACTUAL_TYPE {n}: {ci.type}"
    logInfo m!"DIRECT_ASTIS {n}: {astis}"
    logInfo m!"DIRECT_ALL {n}: {used}"
    logInfo m!"KERNEL_AXIOMS {n}: {axs}"
    if n != target then
      Lean.Elab.Command.liftCoreM <| addDecl <| Declaration.thmDecl {
        name := Name.mkSimple "ActualPrivateSealedTypeCheck"
        levelParams := []
        type := mkConst (Name.mkSimple "ExpectedPrivate")
        value := mkConst n
      }
      logInfo "ACTUAL_PRIVATE_SEALED_LITERAL_KERNEL_TYPE_APPLICATION_PASS"

#print axioms ActualPrivateSealedTypeCheck
#print axioms AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumGridAlias.actual_midpoint_grid_cosine_alias
