from html.parser import HTMLParser
from pathlib import Path
import hashlib,json,re
root=Path('/Users/zhouhuanjian/ASTIS-GC')
out=root/'.astis/huanjian-gc-fixed-spectrum-variances-20261110/independent-source-graph'
source=root/'.astis/huanjian-resume-20261103/2610.20492v1.html'
data=source.read_bytes(); raw=data.decode(); lines=raw.splitlines()
assert hashlib.sha256(data).hexdigest()=='6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
class Node:
 def __init__(self,tag,attrs,line,parent=None):
  self.tag=tag; self.attrs=dict(attrs); self.line=line; self.end=line; self.parent=parent; self.parts=[]; self.children=[]
 def text(self):
  if self.tag=='math': return '$'+self.attrs.get('alttext','')+'$'
  if self.tag=='annotation': return ''
  return re.sub(r'\s+',' ',''.join(x.text() if isinstance(x,Node) else x for x in self.parts)).strip()
 def walk(self):
  yield self
  for x in self.children: yield from x.walk()
class Parser(HTMLParser):
 def __init__(self): super().__init__(convert_charrefs=True); self.root=Node('root',[],1);self.stack=[self.root]
 def handle_starttag(self,tag,attrs):
  n=Node(tag,attrs,self.getpos()[0],self.stack[-1]);self.stack[-1].children.append(n);self.stack[-1].parts.append(n)
  if tag not in ('meta','link','img','br','hr','input','wbr','source','area','base','embed','param','track','col'): self.stack.append(n)
 def handle_endtag(self,tag):
  for i in range(len(self.stack)-1,0,-1):
   if self.stack[i].tag==tag:
    for n in self.stack[i:]: n.end=self.getpos()[0]
    del self.stack[i:]; return
 def handle_data(self,s): self.stack[-1].parts.append(s)
p=Parser();p.feed(raw)
allnodes=list(p.root.walk()); byid={n.attrs['id']:n for n in allnodes if 'id' in n.attrs}
scopes=[('S4-statement-through-proof',1054,1500),('C3-complete',3837,4134),('cited-bibliography-entry',1847,1864)]
units=[]
for n in allnodes:
 scope=next((name for name,lo,hi in scopes if lo<=n.line<=hi),None)
 if scope is None: continue
 classes=n.attrs.get('class','').split()
 kind=None
 if n.tag=='section':kind='section-context'
 elif 'ltx_bibitem' in classes:kind='bibliography-entry'
 elif 'ltx_theorem' in classes:kind='theorem-block'
 elif 'ltx_proof' in classes:kind='proof-block'
 elif n.tag in ('h2','h3','h4','h5','h6'):kind='heading'
 elif n.tag=='div' and 'ltx_para' in classes:kind='paragraph-container'
 elif n.tag=='p':kind='paragraph'
 elif n.tag=='table' and ('ltx_equation' in classes or 'ltx_equationgroup' in classes):kind='display'
 elif n.tag=='tbody':kind='tbody'
 elif 'ltx_cite' in classes:kind='external-citation'
 elif n.tag=='a' and n.attrs.get('href','').startswith('#'):kind='internal-reference'
 if kind is None:continue
 ident=n.attrs.get('id')
 if ident is None:
  anc=n.parent
  while anc and not anc.attrs.get('id'):anc=anc.parent
  ident=(anc.attrs.get('id') if anc else 'source')+'::'+n.tag+'@'+str(n.line)
 maths=[{'id':m.attrs.get('id'),'line':m.line,'tex':m.attrs.get('alttext'),'display':m.attrs.get('display')} for m in n.walk() if m.tag=='math']
 refs=[{'line':a.line,'href':a.attrs.get('href'),'title':a.attrs.get('title'),'text':a.text()} for a in n.walk() if a.tag=='a' and a.attrs.get('href','').startswith('#')]
 hi=next(hi for name,lo,hi in scopes if name==scope)
 end=min(n.end,hi)
 text=n.text()
 if n.end>hi:
  text='[Structural container extends past the bounded scope; substantive units are inventoried separately.]'
  maths=[];refs=[]
 units.append({'id':ident,'kind':kind,'scope':scope,'original_lines':[n.line,end],'container_original_end':n.end,'text_with_tex':text,'math':maths,'references':refs,'raw_html_sha256':hashlib.sha256(('\n'.join(lines[n.line-1:end])+'\n').encode()).hexdigest()})
(out/'raw-unit-inventory.json').write_text(json.dumps({'source_path':str(source.relative_to(root)),'source_sha256':hashlib.sha256(data).hexdigest(),'scopes':scopes,'units':units},indent=2,ensure_ascii=False)+'\n')
with (out/'raw-source-reading.txt').open('w') as f:
 for u in units:
  if u['kind'] in ('heading','paragraph','display'):
   f.write(f"{u['id']} [{u['original_lines'][0]}-{u['original_lines'][1]}] {u['kind']}\n{u['text_with_tex']}\n\n")
for name,lo,hi in scopes: (out/(name+'.raw.html')).write_text('\n'.join(lines[lo-1:hi])+'\n')
print('Source SHA256',hashlib.sha256(data).hexdigest());print('Units',len(units));print('Reading file',out/'raw-source-reading.txt')
