from pathlib import Path
from bs4 import BeautifulSoup
from html.parser import HTMLParser
import hashlib
import json
import sys

BASE = Path(__file__).resolve().parent
RAW = BASE.parents[3] / 'huanjian-resume-20261103/2610.20492v1.html'
# The source locator is fixed rather than discovered from an evidence index.
RAW = Path('/Users/zhouhuanjian/ASTIS-GC/.astis/huanjian-resume-20261103/2610.20492v1.html')
b = RAW.read_bytes()
assert len(b) == 951991
assert hashlib.sha256(b).hexdigest() == '6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
raw = b.decode()
soup = BeautifulSoup(raw, 'html.parser')


class SpanParser(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=False)
        self.stack = []
        self.spans = {}
        self.starts = [0] + [i + 1 for i, c in enumerate(raw) if c == '\n']

    def pos(self):
        line, col = self.getpos()
        return self.starts[line - 1] + col

    def handle_starttag(self, tag, attrs):
        ident = dict(attrs).get('id')
        start = self.pos()
        end = start + len(self.get_starttag_text())
        if tag in {'area', 'base', 'br', 'col', 'embed', 'hr', 'img', 'input', 'link', 'meta', 'param', 'source', 'track', 'wbr'}:
            if ident:
                self.spans[ident] = (start, end)
        else:
            self.stack.append((tag, ident, start))

    def handle_startendtag(self, tag, attrs):
        ident = dict(attrs).get('id')
        if ident:
            self.spans[ident] = (self.pos(), self.pos() + len(self.get_starttag_text()))

    def handle_endtag(self, tag):
        for i in range(len(self.stack) - 1, -1, -1):
            if self.stack[i][0] == tag:
                end = raw.index('>', self.pos()) + 1
                for _, ident, start in self.stack[i:]:
                    if ident:
                        self.spans[ident] = (start, end)
                self.stack = self.stack[:i]
                break


p = SpanParser()
p.feed(raw)
keys = ['S4.SS1', 'S4.SS2.SSS0.Px1', 'S4.SS2.SSS0.Px2', 'S4.Thmtheorem4', 'A3.SS2']
keys += [t['id'] for t in soup.find(id='A3.SS2').find_all(id=True)
         if ('ltx_para' in t.get('class', []) or 'ltx_equation' in t.get('class', [])
             or 'ltx_theorem' in t.get('class', []) or 'ltx_proof' in t.get('class', []))]
keys = list(dict.fromkeys(keys))
meta = []
for key in keys:
    a, z = p.spans[key]
    fragment = raw[a:z]
    tag = BeautifulSoup(fragment, 'html.parser')
    for math in tag.find_all('math'):
        math.replace_with(' $' + math.get('alttext', math.get_text(' ', strip=True)) + '$ ')
    txt = tag.get_text(' ', strip=True) + '\n'
    (BASE / (key + '.html')).write_bytes(fragment.encode())
    (BASE / (key + '.txt')).write_text(txt)
    meta.append({'id': key, 'byte_start': len(raw[:a].encode()),
                 'byte_end_exclusive': len(raw[:z].encode()),
                 'line_start': raw.count('\n', 0, a) + 1,
                 'line_end': raw.count('\n', 0, z) + 1,
                 'sha256': hashlib.sha256(fragment.encode()).hexdigest(),
                 'bytes': len(fragment.encode())})
(BASE / 'source-spans-complete.json').write_text(json.dumps(meta, indent=2) + '\n')
selected = ['A3.SS2.p9', 'A3.Thmtheorem6'] + ['A3.SS2.p' + str(i) for i in range(10, 20)]
out = '\n'.join('ANCHOR ' + key + '\n' + (BASE / (key + '.txt')).read_text() for key in selected)
(BASE / 'raw-03-excluded-tail-output.txt').write_text(out)
print(out)
