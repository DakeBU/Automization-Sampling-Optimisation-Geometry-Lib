from pathlib import Path
import json, hashlib, gzip, datetime, subprocess
R=Path('/Users/zhouhuanjian/ASTIS-GC')
O=R/'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-admissibility-integration-20261107/independent-integration-reader-review/proposal/reader-boundary-correction-review'
P=R/'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-admissibility-semantic-evidence/reader-boundary-correction/proposal.json'
sha=lambda b:hashlib.sha256(b).hexdigest()
def put(p,x):
 assert not p.exists(),str(p)
 p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
assert sha(P.read_bytes())=='bbec9dc0e0939c711a7556d2e9646adb45e0cde3eab1a85ed339207c2a38a629'
proposal=json.loads(P.read_bytes()); assert len(proposal['paths'])==2
O.mkdir(parents=True,exist_ok=False)
rows=[]
for row in proposal['paths']:
 p=R/row['path']; old=p.read_bytes(); packed=(R/row['planned_after_archive']).read_bytes()
 assert sha(old)==row['before_sha256'] and sha(packed)==row['gzip_sha256']
 new=gzip.decompress(packed); assert sha(new)==row['planned_after_sha256']
 a=row['single_exact_replacement']['old'].encode(); b=row['single_exact_replacement']['new'].encode()
 assert old.count(a)==1 and old.replace(a,b,1)==new
 before=json.loads(old); after=json.loads(new)
 if '/declaration_lessons/' in row['path']:
  pointer='/units/0/boundary'; before['units'][0]['boundary']=after['units'][0]['boundary']
 else:
  pointer='/items/0/bindings/0/boundary'; before['items'][0]['bindings'][0]['boundary']=after['items'][0]['bindings'][0]['boundary']
 assert before==after
 rows.append({'path':row['path'],'before_sha256':sha(old),'planned_after_sha256':sha(new),'exact_json_pointer':pointer,'exact_single_byte_replacement_confirmed':True})
receipt=R/'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-admissibility-semantic-evidence/actual-checks/completed-executions/20261107T150046387678Z-fixed-spectrum-admissibility-explicit-actual-consumer.receipt.json'
r=json.loads(receipt.read_bytes()); assert r['exit_code']==0
log=receipt.with_name(receipt.name.replace('.receipt.json','.log.gz')); raw=gzip.decompress(log.read_bytes()); assert sha(raw)==r['log_sha256']
assert b'Build completed successfully' in raw and b'ACTUAL COMPILED ASTIS PARENTS' in raw
test=R/'Tests/GaussianComplexityFixedSpectrumAdmissibility.lean'; testbytes=test.read_bytes(); assert sha(testbytes)=='59a064649635a38002d752d4e42ae0051700c415e5ab9f323fb007576b2226d1'
assert b'(FixedSpectrumAdmissibility.actual_precision_admissible (d := d) hd (\xce\xba := \xce\xba) h\xce\xba O).1' in testbytes
assert b'multivariateGaussian_eq_withDensity_of_posDef (n := d) A hA' in testbytes
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
v={'reviewer':'/root/admiss_integration_reader','recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':head,'proposal_sha256':sha(P.read_bytes()),'verdict':'ACCEPT_EXACT_TWO_SCALAR_STATUS_CORRECTION_ONLY','paths':rows,'reason':'The actual same-A Gaussian law-density Test obtains positivity from the new producer and applies the existing canonical density theorem. Genuine receipt/raw log compile evidence verifies the compiled-status correction. Only two authored boundary scalars change; no statement, assumptions, steps, code, anonymous packet, mathematical claim or historical seal changes.','source_verification':'Not issued by this integration role; pending independent raw-first source/whole-module review.','application_conditions':['Refresh canonical draft publication binding after applying exact approved bytes.','Use fresh corrected binding and prose in subsequent full source/module review, never reuse the old binding.'],'genuine_build_evidence':{'receipt_sha256':sha(receipt.read_bytes()),'raw_log_sha256':sha(raw),'actual_test_sha256':sha(testbytes)},'shared_or_ledger_or_API_mutations':False,'build_site_browser_runs':[]}
put(O/'verdict.json',v)
put(O/'freeze.json',{'reviewer':v['reviewer'],'phase':'Separate exact-proposal reader-boundary correction review only','files':[{'path':str((O/'verdict.json').relative_to(R)),'sha256':sha((O/'verdict.json').read_bytes())}], 'proposal_sha256':sha(P.read_bytes())})
print(json.dumps({'verdict_path':str((O/'verdict.json').relative_to(R)),'verdict_sha256':sha((O/'verdict.json').read_bytes()),'freeze_sha256':sha((O/'freeze.json').read_bytes())}))
