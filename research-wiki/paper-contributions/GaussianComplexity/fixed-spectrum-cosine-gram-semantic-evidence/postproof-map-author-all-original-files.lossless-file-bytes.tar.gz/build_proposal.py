from pathlib import Path
from hashlib import sha256
from bs4 import BeautifulSoup
import json,re

R=Path('/Users/zhouhuanjian/ASTIS-GC')
O=R/'.astis/huanjian-gc-fixed-spectrum-cosine-gram-20261110/source-map-author-1d7a46'
inputs=json.loads((O/'inputs.json').read_text())
meta={x['path']:x for x in inputs}
def read(path): return (O/meta[path]['snapshot']).read_bytes().decode('utf-8')
def dump(path,obj): path.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
P='AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumCosineGram.lean'
T='Tests/GaussianComplexityFixedSpectrumCosineGram.lean'
G='AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumGridAlias.lean'
W='.astis/huanjian-gc-fixed-spectrum-cosine-gram-20261110/'
S='.astis/semantic-neutral-20261110/cg_sg_1d7a46/'
M='.lake/packages/mathlib/Mathlib/'
K='.astis/huanjian-resume-20261103/20261110T155942501800Z-cosine-gram-actual-kernel-exact-types-all-owned.log'
rawgraph=json.loads(read(S+'phase1/source_graph.json'))
index=json.loads(read(S+'phase1/source_index.json'))
rawnodes={x['id']:x for x in rawgraph['nodes']}
rawids={x['id']:x for x in index['items']}
seals=json.loads(read(W+'statement-seal-v1.json'))
kernel=read(K)
used={n:set(x.strip() for x in v.split(',')) for n,v in re.findall(r'OWNED_DECL_USED ([^:]+): \[(.*?)\]',kernel,re.S)}
public='AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumCosineGram.actual_cosine_frame_gram'
private=next(n for n in used if n.endswith('.actual_gaussian_gram_means'))
alias='AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumGridAlias.actual_midpoint_grid_cosine_alias'
actual_parents={n:[x.strip() for x in body.split(',') if x.strip()] for n,body in re.findall(r'ACTUAL_PUBLIC_ASTIS_PARENTS ([^:]+): \[(.*?)\]',kernel,re.S)}
assert actual_parents=={public:[alias],private:[public]}
axioms={n:[x.strip() for x in v.split(',') if x.strip()] for n,v in re.findall(r'OWNED_DECL_AXIOMS ([^:]+): \[(.*?)\]',kernel,re.S)}
reach=dict(re.findall(r'OWNED_DECL_REACHABLE_FROM_ACTUAL_ROOT ([^:]+): (true|false)',kernel))
assert len(used)==26==len(axioms)==len(reach)
assert all(v=='true' for v in reach.values())
assert all(set(v)<= {'propext','Classical.choice','Quot.sound'} for v in axioms.values())
generated=[n for n in used if n not in [public,private]]
assert len(generated)==24
dump(O/'compiler-metadata.json',{'input_log':K,'raw_log_sha256':meta[K]['raw_wholefile_sha256'],
 'inspector_source':'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-cosine-gram-semantic-evidence/KernelExactTypesAndAllOwnedBounded.lean',
 'handwritten_compiled_roots':[public,private],'observed_first_public_ASTIS_parents':actual_parents,
 'owned_total':26,'generated_implementation_providers':generated,'provider_count':24,
 'reachability_values':reach,'axiom_lists':axioms,
 'interpretation':'Mechanical parse of the supplied existing constants/axioms/reachability output. No Lean was run here. Provider names are not source Anchors or separate mathematical graph nodes.'})

slices=[]
def locator(path,start,end,ident,startmarker,endmarker):
 text=read(path)
 assert 0<=start<end<=len(text)
 block=text[start:end]
 assert '\r' not in block
 exact=block.encode('utf-8')
 row={'slice_id':ident,'file':path,'raw_wholefile_sha256':meta[path]['raw_wholefile_sha256'],
 'character_start_inclusive':start,'character_end_exclusive':end,'character_length':end-start,
 'byte_start_inclusive':len(text[:start].encode('utf-8')),'byte_end_exclusive':len(text[:end].encode('utf-8')),
 'start_line_1based_inclusive':text.count('\n',0,start)+1,
 'end_line_1based_inclusive':text.count('\n',0,end-1)+1,
 'literalLF':block,'exact_block_sha256':sha256(exact).hexdigest(),
 'start_marker':startmarker,'end_marker':endmarker,'end_marker_included':False,
 'line_convention':'1-based inclusive line numbers; a final LF belongs to the preceding line. Character offsets are 0-based Unicode code points of strict UTF-8 decode, before any newline normalization; end is exclusive. literalLF is exact and has no CR.'}
 (O/'slices'/(ident+'.lean.txt')).write_bytes(exact)
 slices.append(row)
 return ident
def span(path,a,b,ident,scope=None):
 text=read(path); lo,hi=scope or (0,len(text))
 start=text.index(a,lo,hi); end=text.index(b,start+len(a),hi)
 return locator(path,start,end,ident,a,b)
def lines(path,a,b,ident):
 text=read(path); ss=text.splitlines(keepends=True)
 start=sum(map(len,ss[:a-1]));end=sum(map(len,ss[:b]))
 return locator(path,start,end,ident,ss[a-1],ss[b] if b<len(ss) else '<EOF>')

root_slices={}
for path,name,draft,sealname,key in [(P,'theorem actual_cosine_frame_gram',W+'producer-signature.draft.txt','producer','P'),(T,'private theorem actual_gaussian_gram_means',W+'consumer-signature.draft.txt','actual_private_consumer','T')]:
 text=read(path); start=text.index(name); sep=text.index('\n:= by\n',start); end=text.index('\nend AutoSamplingTheory.',sep)
 statement=text[start:sep+1]
 assert statement==read(draft)==seals[sealname]['signature']
 assert sha256(statement.encode()).hexdigest()==seals[sealname]['signature_sha256']
 root_slices[key]={'declaration':locator(path,start,end,key+'.declaration',name,'\nend AutoSamplingTheory.'),
 'statement':locator(path,start,sep+1,key+'.statement',name,':= by\n'),
 'proof':locator(path,sep+1,end,key+'.proof',':= by\n','\nend AutoSamplingTheory.'),
 'scope':(sep+1,end)}

rows=[]
def mapping(ident,path,a,b,nodeids,anchors,meaning,canonical_calls=(),scope=None,relation='source-conclusion-and-proof-step-correspondence'):
 sid=span(path,a,b,ident,scope)
 assert set(nodeids)<=set(rawnodes)
 assert set(anchors)<=set(rawids)
 rows.append({'slice_id':sid,'compiled_owner_canonical_id':'lean:'+ (public if path==P else private),
 'source_node_ids':nodeids,'source_anchors':anchors,'correspondence':relation,
 'mathematical_role':meaning,'canonical_references':['lean:'+x for x in canonical_calls]})

ps=root_slices['P']['scope'];ts=root_slices['T']['scope']
mapping('P.literal-setup',P,'  classical\n','  have hmode', ['domain','theta','rn','frame','D'],['S4.E11.m1','S4.Ex12.m1','A3.Ex85.m1'], 'Literal theta/t/D, integer cosine C, coordinate scales c, odd n and the source domain; no added theorem hypothesis.',scope=ps)
mapping('P.cosine-mode',P,'  have hmode','  have hzero',['cosine.zero','domain'],['A3.SS2.p4.2','A3.SS2.p4.m6'], 'Specializes the existing stronger integer alias to the bounded signed frequency window, retaining a separate k=0 value d. This realizes the source cancellation conclusion through canonical reuse, rather than identifying P as the literal sine-telescoping source proof.',[alias],ps,'source-conclusion-via-existing-canonical-lemma')
mapping('P.positive-cancellation',P,'  have hzero','  have hprod',['cosine.zero'],['A3.SS2.p4.m6'],'Restricts hmode to positive frequencies below 2d.',scope=ps)
mapping('P.product-identity',P,'  have hprod','  have hpair',['trig.product-to-sum'],['A3.Ex92.m1'],'Pointwise two-cosine product-to-sum.',['Real.two_mul_cos_mul_cos'],ps)
mapping('P.pair-sum',P,'  have hpair','  have htriple',['gram.nonconstant-entries'],['A3.Ex91.m2','A3.Ex92.m1'],'Finite-sum product-to-sum with factor 1/2; scales are applied later.',scope=ps)
mapping('P.triple-sum',P,'  have htriple','  have ht',['weighted.triple-expansion'],['A3.Ex97.m1','A3.Ex98.m2'],'Four frequencies n-(a-b), n+(a-b), n-(a+b), n+(a+b), a permutation of the paper four signed frequencies, with exact coefficient 1/4.',scope=ps)
mapping('P.coordinate-scales',P,'  have ht','  have hjbound',['frame','trig.zero-angle'],['A3.Ex85.m1','A3.SS2.p5.m2'],'Source zero-coordinate scale 1 versus positive-coordinate sqrt(2); cos(0)=1 handles constant-coordinate cases.',scope=ps)
mapping('P.coordinate-bounds',P,'  have hjbound','  have hgram',['gram.frequency-window','weighted.frequency-window'],['A3.SS2.p5.3','A3.Ex96.m1'],'Fin(q+1) supplies 0<=j<=q; integer casts/arithmetic discharge local frequency bounds.',scope=ps)
mapping('P.unweighted-entries',P,'  have hgram','  have hweighted',['gram.constant-entries','gram.nonconstant-entries','gram.frequency-window','algebra.sqrt-two'],['A3.Ex90.m1','A3.Ex91.m2','A3.Ex92.m1','A3.Ex93.m1','A3.SS2.p5.3'],'Complete entry cases including j=k=0, positive diagonal, and unequal coordinates; no Gaussian input.',['Real.sq_sqrt'],ps)
mapping('P.weighted-entries',P,'  have hweighted','  change t.transpose',['weighted.frequency-window','weighted.triple-zero'],['A3.Ex96.m1','A3.Ex99.m2'],'Discharges all four strict nonzero frequency bounds from hq and index bounds, including q=0.',scope=ps)
mapping('P.unweighted-matrix',P,'  constructor\n  · ext j k\n    change (∑ i : Fin d, t i j * t i k)','  constructor\n  · ext j k\n    change (∑ i : Fin d, (t.transpose * D)',['det.unweighted','linear.entry-algebra'],['A3.SS2.p5.m8'],'Entry extensionality yields t^Tt=dI.',scope=ps)
mapping('P.weighted-matrix',P,'  constructor\n  · ext j k\n    change (∑ i : Fin d, (t.transpose * D)','  · intro i\n    have hb',['det.weighted','linear.entry-algebra'],['A3.SS2.p7.3','A3.SS2.p7.m5'],'Literal diagonal multiplication, coordinate scales and weighted cancellation yield t^TDt=0.',scope=ps)
text=read(P); start=text.index('  · intro i\n    have hb',ps[0]);sid=locator(P,start,ps[1],'P.row-norm','  · intro i\n    have hb','\nend AutoSamplingTheory.')
rows.append({'slice_id':sid,'compiled_owner_canonical_id':'lean:'+public,'source_node_ids':['det.row-norm','trig.cosine-square-bound','algebra.sqrt-two'],'source_anchors':['A3.Ex102.m1'],'correspondence':'source-conclusion-and-proof-step-correspondence','mathematical_role':'Square bound per coordinate; exact Fin sum 1+2q; conclude <=2(q+1), including q=0.','canonical_references':['lean:Real.sq_sqrt','lean:Real.cos_sq_le_one']})

mapping('T.literal-setup',T,'  classical\n','  have hframe',['domain','theta','rn','frame','D','gaussian.input','B'],['S4.E11.m1','S4.Ex12.m1','A3.Ex85.m1','A3.SS2.p1.2'],'Actual finite product coordinate space, canonical multivariateGaussian 0 I and literal d^-1/2 Gaussian-first tensor rows.',['ProbabilityTheory.multivariateGaussian'],ts)
mapping('T.frame-consumption',T,'  have hframe','  have hgram',['det.unweighted','det.weighted'],['A3.Ex94.m2','A3.Ex95.m1','A3.Ex100.m2','A3.Ex101.m1'],'One actual ASTIS parent declaration P is called; only its unweighted and weighted projections are subsequently used. The producer row-norm clause is not an extra mathematical parent of the private means. ',[public],ts)
mapping('T.unweighted-entry-projection',T,'  have hgram','  have hweighted',['det.unweighted'],['A3.SS2.p5.m8'],'Extracts the unweighted entry formula from P.1.',[public],ts)
mapping('T.weighted-entry-projection',T,'  have hweighted','  have hL2',['det.weighted'],['A3.SS2.p7.m5'],'Extracts the weighted entry formula from P.2.1, without consuming P row norm.',[public],ts)
mapping('T.actual-coordinate-L2',T,'  have hL2','  have hmean',['gaussian.input','gaussian.second-moment'],['A3.SS2.p1.2','A3.SS2.p6.m1'],'Actual canonical Gaussian coordinate L2 via Gaussian dual linear projections.',['ProbabilityTheory.IsGaussian.memLp_dual','ProbabilityTheory.isGaussian_multivariateGaussian','EuclideanSpace.proj'],ts)
mapping('T.actual-coordinate-mean',T,'  have hmean','  have hxyint',['gaussian.second-moment'],['A3.SS2.p6.m1'],'Actual coordinate mean zero via CLM integral commutation and canonical Gaussian vector mean.',['ContinuousLinearMap.integral_comp_comm','ProbabilityTheory.IsGaussian.integrable_fun_id','ProbabilityTheory.integral_id_multivariateGaussian'],ts)
mapping('T.coordinate-product-L1',T,'  have hxyint','  have hxymean',['gaussian.second-moment','matrix.expectation-algebra'],['A3.SS2.p6.m1','A3.Ex94.m2'],'L2 x L2 gives integrable actual coordinate product.',['MeasureTheory.MemLp.integrable_mul'],ts)
mapping('T.coordinate-second-moment',T,'  have hxymean','  have hdpos',['gaussian.second-moment'],['A3.SS2.p6.m1'],'Identity PSD, actual canonical covariance and proved zero means give the actual product integral delta; no assumed covariance/independence input.',['ProbabilityTheory.covariance_eval_multivariateGaussian','ProbabilityTheory.covariance','Matrix.PosSemidef.one'],ts)
mapping('T.sqrt-d-normalization',T,'  have hdpos','  have hf',['domain','B','matrix.expectation-algebra'],['A3.SS2.p1.m8','A3.Ex94.m2'],'Derives d>0 from hq and scale^2*d=1; no extra nonzero/normalization binder.',['Real.sq_sqrt'],ts)
mapping('T.actual-unweighted-entry',T,'  have hf','  have hfw',['B','matrix.expectation-algebra'],['A3.SS2.p1.m8','A3.Ex94.m2'],'Actual B^TB entry expanded into finite deterministic coefficients times actual coordinate products.',scope=ts)
mapping('T.actual-weighted-entry',T,'  have hfw','  change ∀ a b',['B','D','matrix.expectation-algebra'],['A3.SS2.p1.m8','A3.Ex100.m2'],'Actual B^TDB entry with literal diagonal weight expanded into finite coordinate-product sum.',scope=ts)
mapping('T.integrable-summands',T,'  intro a b\n','  refine ⟨?_, ?_, ?_, ?_⟩',['gaussian.second-moment','matrix.expectation-algebra'],['A3.Ex94.m2','A3.Ex100.m2'],'Finite deterministic coefficient multiplication preserves each coordinate-product L1; pair-index delta is simplified.',['MeasureTheory.Integrable.const_mul'],ts)
mapping('T.unweighted-entry-L1',T,'  · rw [hf]\n','  · rw [hfw]\n',['matrix.expectation-algebra'],['A3.Ex94.m2'],'Explicit L1 conclusion for the actual unweighted Gram entry via finite sum.',['MeasureTheory.integrable_finsetSum'],ts)
mapping('T.weighted-entry-L1',T,'  · rw [hfw]\n','  · rw [hf, integral_finsetSum',['matrix.expectation-algebra'],['A3.Ex100.m2'],'Explicit L1 conclusion for the actual weighted Gram entry via finite sum.',['MeasureTheory.integrable_finsetSum'],ts)
mapping('T.unweighted-entry-integral',T,'  · rw [hf, integral_finsetSum','  · rw [hfw, integral_finsetSum',['consumer.expected-unweighted','matrix.expectation-algebra'],['A3.Ex94.m2','A3.Ex95.m1'],'Finite integral interchange, actual coordinate moments, deterministic Gram, normalization and ordered-pair identity cases yield actual identity mean.',['MeasureTheory.integral_finsetSum','MeasureTheory.integral_const_mul'],ts)
text=read(T);start=text.index('  · rw [hfw, integral_finsetSum',ts[0]);sid=locator(T,start,ts[1],'T.weighted-entry-integral','  · rw [hfw, integral_finsetSum','\nend AutoSamplingTheory.')
rows.append({'slice_id':sid,'compiled_owner_canonical_id':'lean:'+private,'source_node_ids':['consumer.expected-weighted','matrix.expectation-algebra'],'source_anchors':['A3.Ex100.m2','A3.Ex101.m1'],'correspondence':'source-conclusion-and-proof-step-correspondence','mathematical_role':'Finite integral interchange, actual coordinate moments and deterministic weighted Gram yield actual zero mean.','canonical_references':['lean:MeasureTheory.integral_finsetSum','lean:MeasureTheory.integral_const_mul']})

canonical=[]
def canon(name,path,a,b,nodeids,role,origin='handwritten declaration',line_span=None):
 sid=lines(path,*line_span,'C'+str(len(canonical))) if line_span else span(path,a,b,'C'+str(len(canonical)))
 canonical.append({'canonical_id':'lean:'+name,'compiled_constant':name,'definition_or_lemma_locator_slice':sid,
 'source_node_ids':nodeids,'role':role,'origin':origin,
 'observed_directly_in_owned_root_body':[n for n in [public,private] if name in used[n]],
 'dependency_contract':'A source-text call/definition locator is not a new Lean implication; direct-constant observations come only from the supplied root used-constant output. Imports and mechanism similarity are not edges.'})
canon(alias,G,'theorem actual_midpoint_grid_cosine_alias','\nend AutoSamplingTheory.',['cosine.zero'],'Single existing ASTIS integer midpoint-grid alias specialized inside P. Same compiled lemma has one canonical row across all uses.')
trig=M+'Analysis/Complex/Trigonometric.lean';sqrt=M+'Analysis/Real/Sqrt.lean';mv=M+'Probability/Distributions/Gaussian/Multivariate.lean';gb=M+'Probability/Distributions/Gaussian/Basic.lean';gf=M+'Probability/Distributions/Gaussian/Fernique.lean';l1=M+'MeasureTheory/Function/L1Space/Integrable.lean';bi=M+'MeasureTheory/Integral/Bochner/Basic.lean';cl=M+'MeasureTheory/Integral/Bochner/ContinuousLinearMap.lean'
canon('Real.two_mul_cos_mul_cos',trig,'theorem two_mul_cos_mul_cos','theorem two_mul_sin_mul_cos',['trig.product-to-sum'],'Exact real two-cosine identity used by P.')
canon('Real.cos_sq_le_one',trig,'theorem cos_sq_le_one','theorem abs_sin_le_one',['trig.cosine-square-bound'],'Exact real square bound used in P row norm.')
canon('Real.sq_sqrt',sqrt,None,None,['algebra.sqrt-two','B'],'Real square-root square under nonnegative argument, used for sqrt2 and positive sqrt d normalization.',line_span=(178,178))
canon('ProbabilityTheory.IsGaussian.memLp_dual',gb,'lemma IsGaussian.memLp_dual','@[fun_prop]\nlemma IsGaussian.integrable_dual',['gaussian.second-moment'],'Actual Gaussian projection MemLp p at finite p, instantiated p=2.')
canon('ProbabilityTheory.isGaussian_multivariateGaussian',mv,'instance isGaussian_multivariateGaussian','@[simp]\nlemma integral_id_multivariateGaussian',['gaussian.input'],'Canonical actual-law Gaussian instance inferred in T.')
canon('ProbabilityTheory.integral_id_multivariateGaussian',mv,'@[simp]\nlemma integral_id_multivariateGaussian','lemma integral_id_multivariateGaussian\'',['gaussian.second-moment'],'Canonical vector mean equals the literal mean parameter.')
canon('ProbabilityTheory.covariance_eval_multivariateGaussian',mv,'lemma covariance_eval_multivariateGaussian','lemma variance_eval_multivariateGaussian',['gaussian.second-moment'],'Actual coordinate covariance under the explicit PSD premise, internally supplied at I.')
canon('ProbabilityTheory.IsGaussian.integrable_fun_id',gf,'@[to_fun integrable_fun_id]','@[to_fun memLp_two_fun_id]',['gaussian.second-moment'],'Generated function-syntax integrability alias used in T.hmean.','Generated by the exact @[to_fun integrable_fun_id] attribute on IsGaussian.integrable_id; no handwritten lemma integrable_fun_id is fabricated.')
canon('ContinuousLinearMap.integral_comp_comm',cl,'theorem integral_comp_comm [CompleteSpace E]','theorem integral_apply',['matrix.expectation-algebra'],'Projection commutes with integral after actual identity-function integrability.')
canon('MeasureTheory.MemLp.integrable_mul',l1,'lemma MemLp.integrable_mul','end NormedRing',['gaussian.second-moment'],'Holder product integrability, instantiated L2 x L2 -> L1.')
canon('MeasureTheory.Integrable.const_mul',l1,'@[fun_prop]\ntheorem Integrable.const_mul {','@[fun_prop]\ntheorem Integrable.const_mul\'',['matrix.expectation-algebra'],'Deterministic real coefficients preserve product integrability.')
canon('MeasureTheory.integrable_finsetSum',l1,'@[fun_prop]\ntheorem integrable_finsetSum {','@[deprecated (since := "2026-04-08")] alias integrable_finset_sum :=',['matrix.expectation-algebra'],'L1 of each finite actual Gram sum.')
canon('MeasureTheory.integral_finsetSum',bi,'theorem integral_finsetSum {','@[deprecated (since := "2026-04-08")] alias integral_finset_sum :=',['matrix.expectation-algebra'],'Finite integral-sum interchange with summand integrability discharged in T.')
canon('MeasureTheory.integral_const_mul',bi,'theorem integral_const_mul {','theorem integral_mul_const',['matrix.expectation-algebra'],'Deterministic coefficients pull through actual integrals.')
canon('ProbabilityTheory.covariance',M+'Probability/Moments/Covariance.lean','noncomputable def covariance','@[inherit_doc]',['gaussian.second-moment'],'Literal centered product integral unfolded using the separately proved zero means.')
canon('Matrix.PosSemidef.one',M+'LinearAlgebra/Matrix/PosDef.lean','protected lemma one [StarOrderedRing R]','protected theorem natCast',['gaussian.second-moment'],'Actual identity PSD supplied internally to covariance evaluation.')
canon('ProbabilityTheory.multivariateGaussian',mv,'/-- Multivariate Gaussian measure','lemma multivariateGaussian_of_not_posSemidef',['gaussian.input'],'Actual mean-plus-covariance-square-root Gaussian pushforward; documentation records non-PSD convention.','Literal meaning-bearing definition; no caller-supplied covariance certificate.')
canon('ProbabilityTheory.stdGaussian',mv,'def stdGaussian : Measure E :=','\n\n',['gaussian.input'],'Literal product-standard-real-Gaussian orthonormal-basis pushforward; definition context, not a newly asserted direct T theorem parent.')
canon('ProbabilityTheory.gaussianReal',M+'Probability/Distributions/Gaussian/Real.lean','def gaussianReal (','\n\n',['gaussian.input'],'Literal variance-zero dirac / nonzero Gaussian density definition; actual standard call uses variance1.')
canon('EuclideanSpace.proj',M+'Analysis/InnerProductSpace/PiL2.lean','abbrev EuclideanSpace.proj (','\n\n',['gaussian.input'],'Literal coordinate projection abbreviation used by Gaussian L2 and means.')
canon('PiLp.proj',M+'Analysis/Normed/Lp/PiLp.lean','def proj (i : ι) : PiLp p β →L','\n\n',['gaussian.input'],'Literal continuous coordinate map behind EuclideanSpace.proj; declaration-definition context, not an inferred ASTIS parent.')

# The same declaration has one canonical row, no matter how many proof slices use it.
canonical.extend([
 {'canonical_id':'lean:'+public,'compiled_constant':public,'definition_or_lemma_locator_slice':'P.declaration','source_node_ids':['det.unweighted','det.weighted','det.row-norm'],'role':'Actual producer declaration; exact statement slice P.statement, proof slice P.proof.'},
 {'canonical_id':'lean:'+private,'compiled_constant':private,'source_spelling':'AutoSamplingTheory.Tests.GaussianComplexityFixedSpectrumCosineGram.actual_gaussian_gram_means','definition_or_lemma_locator_slice':'T.declaration','source_node_ids':['consumer.expected-unweighted','consumer.expected-weighted','gaussian.second-moment','matrix.expectation-algebra'],'role':'Actual private consumer declaration; compiled private name is read from raw kernel output, not guessed.'}])
assert len({x['canonical_id'] for x in canonical})==len(canonical)
for r in rows:
 assert set(r['canonical_references'])<=set(x['canonical_id'] for x in canonical)

raw_source=read(S+'phase1/inputs/2610.20492v1.html')
soup=BeautifulSoup(raw_source,'html.parser')
extra=[]
for ident in ['A3.Ex139','A3.SS3.p3']:
 el=soup.find(id=ident)
 assert el is not None
 extra.append({'anchor':'#'+ident,'text':el.get_text(' ',strip=True),'role':'Context for existing Gla source attribution only; not a newly completed source result.'})
dump(O/'source-context-Gla.json',extra)
source_refs={a:{k:rawids[a][k] for k in ['locator','byte_start','byte_end_exclusive','sha256']} for a in sorted(set(a for r in rows for a in r['source_anchors']))}
proposal={'schema':'astis-source-to-lean-locator-correspondence-proposal/v1',
 'artifact_kind':'POST_PROOF_MECHANICAL_LOCATOR_PROPOSAL',
 'boundary':'This phase has seen implementation after both original source freezes. It is not source-blind, a new source verdict, a Lean proof, a publication record or a completion claim.',
 'source_revision':'arXiv:2610.20492v1','raw_source_sha256':index['raw_sha256'],
 'source_lineage':{'raw_graph_sha256':meta[S+'phase1/source_graph.json']['raw_wholefile_sha256'],'typed_overlay_sha256':meta[S+'phase2/typed_overlay.json']['raw_wholefile_sha256']},
 'locator_convention':slices[0]['line_convention'],
 'whole_file_inputs':[{'file':p,'raw_wholefile_sha256':meta[p]['raw_wholefile_sha256']} for p in [P,T,G]],
 'root_declarations':[{'canonical_id':'lean:'+public,'statement_slice':'P.statement','proof_slice':'P.proof','declaration_slice':'P.declaration','source_roots':['det.unweighted','det.weighted','det.row-norm'],'exact_draft_signature_sha256':meta[W+'producer-signature.draft.txt']['raw_wholefile_sha256']},
 {'canonical_id':'lean:'+private,'statement_slice':'T.statement','proof_slice':'T.proof','declaration_slice':'T.declaration','source_roots':['consumer.expected-unweighted','consumer.expected-weighted'],'additional_well_definedness_conclusions':'Actual entrywise L1 for both Grams; source implicit second-moment expectation meaning made explicit.','exact_draft_signature_sha256':meta[W+'consumer-signature.draft.txt']['raw_wholefile_sha256']}],
 'canonical_rows':canonical,'correspondence_slices':rows,'locator_slices':slices,'raw_source_anchor_locators':source_refs,
 'actual_first_public_ASTIS_parent_observation':{'evidence_file':K,'raw_wholefile_sha256':meta[K]['raw_wholefile_sha256'],'parents':actual_parents,'interpretation':'Existing raw used-constant traversal metadata plus explicit source call sites. No import edge or mathematical-similarity edge is substituted.'},
 'compiler_provider_policy':{'owned_total':26,'handwritten_roots':2,'generated_implementation_providers':24,'metadata_file':'compiler-metadata.json','policy':'No generated provider is a separate source Anchor or mathematical node. The same existing compiled Gla theorem has one canonical row; no duplicate aliases are invented.'},
 'source_route_differences':[{'source_node_ids':['cosine.telescope','trig.sine-difference','finite.telescope','trig.integer-endpoints','trig.nonzero','cosine.zero'],'actual_locator_slices':['P.cosine-mode','C0'],'actual_canonical_id':'lean:'+alias,'correspondence':'The author shows local midpoint sine telescoping. P instead specializes the existing stronger signed integer alias, whose complete actual proof is located at C0. Its nondivisible branch uses Real.sin_mul_sum_cos and a nonzero sine argument. This records canonical reuse of the cancellation conclusion, not a claim that P literally contains the source telescope.'},
 {'source_node_ids':['gaussian.input','gaussian.second-moment'],'actual_locator_slices':['T.actual-coordinate-L2','T.actual-coordinate-mean','T.coordinate-second-moment'],'correspondence':'T uses actual canonical Gaussian moment/covariance leaves and supplies Matrix.PosSemidef.one. It does not directly unfold CFC.sqrt or prove CFC.sqrt I=I locally; those canonical definition internals are delegated to the actual covariance lemma, not turned into caller premises.'}],
 'context_only_links':[{'source_anchor':'A3.Ex125.m1','from_source_nodes':['consumer.expected-unweighted','consumer.expected-weighted'],'context':'Original-minus-truncated means in the later C.6 proof.','formal_dependency':False,'role':'Context only, never a required formal AND parent of the present declarations.'}],
 'unclosed_source_boundary':['Range(B)=Krylov','C.6 concentration and its probability/absolute-constant accounting','full Lemma4.4','either main result','oracle/Haar/adaptive/TV/cap/cost adapters'],
 'use_contract':'Only mathematical correspondence, exact source/code locators and immutable graph/overlay hash lineage are proposed. Fresh independent source review must make its own judgment from raw source and actual code.'}
dump(O/'source-to-lean-map.PROPOSAL.json',proposal)
report={'kind':'mechanical locator generation','root_declarations':2,'correspondence_slices':len(rows),'locator_slices':len(slices),'canonical_rows':len(canonical),'all_slice_hashes_generated_from_exact_utf8':True,'no_Lean_execution':True}
(O/'logs/build.stdout').write_text(json.dumps(report,ensure_ascii=False)+'\n')
(O/'logs/build.stderr').write_bytes(b'')
print(json.dumps(report,ensure_ascii=False))
