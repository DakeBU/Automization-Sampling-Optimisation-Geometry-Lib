"""Bounded actual fixture byte/link/code checks. No browser or mathematical verdict."""
from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import urlsplit,unquote
from collections import Counter
import hashlib,json,re
ROOT=Path(__file__).resolve().parents[4]
PREP=Path(__file__).resolve().parent
OWN=PREP/'isolated-preview-v2'
SITE=OWN/'fixtures/candidate'
sha=lambda b:hashlib.sha256(b).hexdigest()
load=lambda p:json.loads(p.read_bytes())
def save(p,j):p.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
class Parsed(HTMLParser):
 def __init__(self):
  super().__init__(convert_charrefs=True);self.links=[];self.ids=set();self.blocks=[];self.pre=0;self.parts=[];self.step_count=0;self.copy_count=0;self.step_source_count=0;self.disabled=0
 def handle_starttag(self,t,a):
  d=dict(a)
  if 'id' in d:self.ids.add(d['id'])
  self.links.extend((k,v) for k,v in a if k in ('href','src') and v)
  self.step_count+=int('data-mgf-step' in d)
  self.copy_count+=int('data-lean-copy' in d)
  self.step_source_count+=int('data-step-source' in d)
  self.disabled+=int('data-preview-unserved-href' in d)
  if t=='pre':
   self.pre+=1
   if self.pre==1:self.parts=[]
 def handle_data(self,d):
  if self.pre:self.parts.append(d)
 def handle_endtag(self,t):
  if t=='pre':
   self.pre-=1
   if self.pre==0:self.blocks.append(''.join(self.parts))
manifest=load(OWN/'preview-freeze-manifest.json');freeze=load(OWN/'input-freeze-manifest.json')
checks=[];failures=[]
def check(ok,label,detail=None):
 checks.append({'check':label,'passed':bool(ok)})
 if not ok:failures.append({'check':label,'detail':detail})
rows=manifest['variants']['candidate']['files']
actual={str(p.relative_to(SITE)) for p in SITE.rglob('*') if p.is_file()}
check(actual=={r['path'] for r in rows},'exact selected candidate leaf set')
for r in rows:
 p=SITE/r['path'];b=p.read_bytes()
 check(not p.is_symlink() and p.is_file() and p.stat().st_size==r['bytes'] and sha(b)==r['sha256'],'served bytes:'+r['path'])
for r in freeze['files']:
 p=OWN/'input-snapshot'/r['path'];b=p.read_bytes()
 check(not p.is_symlink() and len(b)==r['bytes'] and sha(b)==r['sha256'],'input frozen bytes:'+r['path'])
parsed={}
for p in SITE.rglob('*.html'):
 x=Parsed();x.feed(p.read_text());parsed[p.resolve()]=x
local_fail=[];external=[];active=0
for p,x in parsed.items():
 for a,v in x.links:
  u=urlsplit(v)
  if u.scheme or u.netloc:external.append(v);continue
  active+=1;target=(p.parent/unquote(u.path) if u.path else p).resolve()
  if not target.is_relative_to(SITE.resolve()) or not target.exists():local_fail.append({'page':str(p.relative_to(SITE.resolve())),'attr':a,'url':v,'reason':'missing/escaped local path'})
  elif u.fragment and target.suffix=='.html' and unquote(u.fragment) not in parsed.get(target,Parsed()).ids:local_fail.append({'page':str(p.relative_to(SITE.resolve())),'url':v,'reason':'missing anchor'})
check(not local_fail,'all active local HTML URLs and anchors close',local_fail)
css_fail=[];css_external=[]
for p in SITE.rglob('*.css'):
 text=p.read_text()
 urls=re.findall(r'url\(\s*[\'"]?([^\s\)\'\"]+)',text)
 urls+=re.findall(r'@import\s+[\'"]([^\'\"]+)',text)
 for v in urls:
  u=urlsplit(v)
  if u.scheme or u.netloc:
   if not v.startswith('data:'):css_external.append(v)
   continue
  target=(p.parent/unquote(u.path)).resolve()
  if not target.is_relative_to(SITE.resolve()) or not target.is_file():css_fail.append({'css':str(p.relative_to(SITE)),'url':v})
check(not css_fail,'local CSS imports and url assets close',css_fail)
check(not css_external,'candidate CSS has no external font/import request',css_external)
unit=load(OWN/'input-snapshot/website/content/declaration_lessons/huanjian-adaptive-oracle-simulation.json')['units'][0]
P=unit['declaration'];PF=unit['steps'][0]['lean_source_path'];TF=unit['steps'][4]['lean_source_path']
proof=SITE/manifest['variants']['candidate']['proof_path'];lesson=SITE/manifest['variants']['candidate']['lesson_path']
for p in (proof,lesson):
 x=parsed[p.resolve()]
 check(x.step_count==5 and x.step_source_count==5 and x.copy_count>=5,'five code/source/copy actions:'+str(p.relative_to(SITE)))
 for s in unit['steps']:check(s['lean'] in x.blocks,'literal adjacent code span:'+str(p.relative_to(SITE))+':'+str(s['lean_source']['LF_lines_1based']))
check([x['lean_source_path'] for x in unit['steps']]==[PF,PF,PF,PF,TF],'exact P/P/P/P/T partition')
sources=[PF,TF,'AutoSamplingTheory/TechnicalLemmas/Analysis/QuadraticRegularizationOracle.lean','AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumFirstOrder.lean']
for p in sources:
 b=(OWN/'input-snapshot'/p).read_bytes();source=SITE/('data/lesson-sources/'+p+'.html')
 check((SITE/'downloads/lean'/p).read_bytes()==b,'lossless complete module download:'+p)
 check(parsed[source.resolve()].blocks==[b.decode()],'exact complete source-page text:'+p)
for p,h in [(PF,'9c0f0c9134aa4360f8bc8384d73f311826224dbe056adb56658d4c393cd33e25'),(TF,'9c28703d8adcc9e33b187371b021c3d1cea902172ce7ba89f1d257d80f7ef6ae')]:
 check(sha((OWN/'input-snapshot'/p).read_bytes())==h,'frozen570 source identity:'+p)
for name,expected in [('lean-toolchain','302cd63c54178885b89e669f33b38f12f4dd7ae7e5cac537b3203e3768d8fb2b'),('lake-manifest.json','b83ca83b9cf7caa85fa8b023c2ff9a3fb7a7cce7e1c332e810c348535ec49c37')]:
 check(sha((OWN/'input-snapshot'/name).read_bytes())==expected,'pinned toolchain/manifest:'+name)
g=load(SITE/'data/underlying-lean-graph.json');ids={n['id'] for n in g['nodes']};graph_fail=[]
for n in g['nodes']:
 if not n.get('url'):continue
 u=urlsplit(n['url'])
 if u.scheme or u.netloc:continue
 target=(SITE/unquote(u.path)).resolve()
 if not target.is_file() or (u.fragment and unquote(u.fragment) not in parsed.get(target,Parsed()).ids):graph_fail.append(n['id'])
check(not graph_fail,'all bounded graph node URLs close',graph_fail)
T='AutoSamplingTheory.Tests.GaussianComplexityAdaptiveFirstOrderSimulation.actual_fixed_spectrum_first_order_matvec_joint_laws_and_costs'
RUN='AutoSamplingTheory.TechnicalLemmas.Analysis.QuadraticRegularizationOracle.run'
FO='AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumFirstOrder.actual_first_order_query'
refs={(e['source'],e['target']) for e in g['edges'] if e['relation']=='source reference (scanner)'}
expected={('decl:'+RUN,'decl:'+P)}|{('decl:'+n,'module:Tests.GaussianComplexityAdaptiveFirstOrderSimulation') for n in [P,FO]}
check(refs==expected,'exact bounded P/run and T/P/FO source-reference edges',sorted(refs))
check('decl:'+T not in ids and g['hyperedges']==[] and g['graph_memory_index']=={'family_ids':[]},'no separate public T node or global/functor credit')
mathjax=[r for r in rows if r['path'].startswith('assets/vendor/mathjax@3.2.2/')]
check(bool(mathjax) and (SITE/'assets/vendor/mathjax@3.2.2/tex-mml-chtml.js').is_file(),'existing local MathJax main/explicit assets selected')
check(any('/output/chtml/fonts/woff-v2/' in r['path'] for r in mathjax) and any('/input/tex/extensions/' in r['path'] for r in mathjax),'local MathJax fonts and TeX extensions included')
css=(SITE/'assets/mgf-reader-overlay.css').read_text()
check('@media (max-width: 760px)' in css and 'overflow-x: auto' in css,'responsive containment rules present; no computed-layout claim')
current_lesson=ROOT/'website/content/declaration_lessons/huanjian-adaptive-oracle-simulation.json';current_pub=ROOT/'website/content/publications/huanjian-adaptive-oracle-simulation.json'
check(sha(current_lesson.read_bytes())==manifest['lesson_sha256'] and sha(current_pub.read_bytes())==manifest['publication_sha256'],'current installed metadata equals selected frozen version')
selection={'schema':'bounded-reader-served-selector.v1','source_base':str(SITE.relative_to(ROOT)),'files':rows,'scope':'Exact candidate fixture only; not original baseline, input snapshot, browser profile or any source/native/math/reader acceptance.'}
selection_path=PREP/'candidate-served.selection.v2.json';save(selection_path,selection)
report={'kind':'ACTUAL_BOUNDED_STATIC_BYTE_LINK_CLOSURE_NOT_READER_ACCEPTANCE','scope':'This exact isolated candidate only. No browser/server/Lean/API/Git/production change and no mathematical/source/reader verdict.',
 'fixture_root':str(SITE.relative_to(ROOT)),'proof_path':str(proof.relative_to(SITE)),'lesson_path':str(lesson.relative_to(SITE)),
 'proof_commit':'57016008083947405bc7d430838537014a40f987','binding_context_reference':None,
 'preview_manifest':{'file':str((OWN/'preview-freeze-manifest.json').relative_to(ROOT)),'sha256':sha((OWN/'preview-freeze-manifest.json').read_bytes())},
 'selection':{'file':str(selection_path.relative_to(ROOT)),'bytes':selection_path.stat().st_size,'sha256':sha(selection_path.read_bytes()),'leaves':len(rows)},
 'counts':{'checks':len(checks),'false_checks':len(failures),'HTML_pages':len(parsed),'active_local_HTML_references':active,'disabled_unserved_shared_shell_links':sum(x.disabled for x in parsed.values()),'MathJax_explicit_leaves':len(mathjax),'source_modules':len(sources),'graph_nodes':len(g['nodes']),'graph_edges':len(g['edges'])},
 'checks':checks,'failures':failures,'prior_mechanism':'R17 reviewed isolated navigation closure reused. Unselected shared-shell destinations are disabled, without copying unrelated pages or inheriting old runtime results.',
 'reader_runtime_pending':['desktop/mobile computed layout','MathJax typesetting/network requests and glyphs','copy clipboard behavior','download OS/browser behavior','pan/zoom and focus/clip geometry','independent current-presentation acceptance'],
 'stage_boundary':'Caption is an explicit ROOT-reviewed snapshot field. This static script supplies no independent native/source/reader acceptance, normal PL/V or full publication verification.'}
save(PREP/'static-closure.actual.v2.json',report)
print(json.dumps({'checks':len(checks),'failures':failures,'selection_leaves':len(rows),'report_sha256':sha((PREP/'static-closure.actual.v2.json').read_bytes()),'selection_sha256':sha(selection_path.read_bytes())},ensure_ascii=False,indent=2))
raise SystemExit(bool(failures))
