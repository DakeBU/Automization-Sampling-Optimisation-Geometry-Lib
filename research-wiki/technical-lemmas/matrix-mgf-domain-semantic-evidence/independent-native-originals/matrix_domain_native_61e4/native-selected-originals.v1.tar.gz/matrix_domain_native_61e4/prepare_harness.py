"""New exact R17 literal interfaces and application tests, using prior lossless audit mechanics only."""
from native_common import *
import re
PUBLIC='AutoSamplingTheory.TechnicalLemmas.Probability.RealMatrixPositiveDefIntegral.integral_posDef'
SUFFIX='.actual_source_four_matrix_mgfs_integrable_posDef_and_trace_bounded'
def main():
    closure=json.loads((OWN/'actual-import-closure.json').read_text());h=OWN/'harness-v1';h.mkdir(exist_ok=False)
    p=(OWN/'immutable-inputs/P.literal.txt').read_text().strip();t=(OWN/'immutable-inputs/T.literal.txt').read_text().strip()
    text='''import Tests.GaussianComplexityMatrixMgfDomain
import Lean
open MeasureTheory ProbabilityTheory Lean Elab Term
open scoped BigOperators Matrix.Norms.L2Operator MatrixOrder ENNReal
noncomputable section
universe u v
elab "native_actual_T" : term => do
  let env ← getEnv
  let found := env.constants.toList.filter fun (n, _) =>
    n.toString.endsWith ".actual_source_four_matrix_mgfs_integrable_posDef_and_trace_bounded"
  unless found.length == 1 do throwError "Expected unique actual private R17 T, found {found.length}"
  return mkConst found.head!.1
namespace NativeLiteralApplications

'''
    text+='theorem literal_P :\n'+p+' := by\n  intro ι Ω instF instD instM μ instPr f hf hPD\n  exact '+PUBLIC+' f hf hPD\n\n'
    text+='''theorem P_empty_indices {Ω : Type v} [MeasurableSpace Ω]
    {μ : Measure Ω} [IsProbabilityMeasure μ] :
    (∫ _ω : Ω, (0 : Matrix (Fin 0) (Fin 0) ℝ) ∂μ).PosDef := by
  have hp : (0 : Matrix (Fin 0) (Fin 0) ℝ).PosDef := by
    apply Matrix.PosDef.of_dotProduct_mulVec_pos Matrix.isHermitian_zero
    intro x hx
    have hz : x = 0 := by ext i; exact Fin.elim0 i
    exact False.elim (hx hz)
  exact '''+PUBLIC+''' (fun _ : Ω => 0) (integrable_const 0)
    (ae_of_all μ fun _ => hp)

theorem P_singleton_identity {Ω : Type v} [MeasurableSpace Ω]
    {μ : Measure Ω} [IsProbabilityMeasure μ] :
    (∫ _ω : Ω, (1 : Matrix (Fin 1) (Fin 1) ℝ) ∂μ).PosDef := by
  exact '''+PUBLIC+''' (fun _ : Ω => 1) (integrable_const 1)
    (ae_of_all μ fun _ => Matrix.PosDef.one)

def nullBad (x : ℝ) : Matrix (Fin 1) (Fin 1) ℝ := if x = 0 then 1 else 0

theorem P_ae_PD_dirac_null_bad :
    (∫ x : ℝ, nullBad x ∂Measure.dirac (0 : ℝ)).PosDef := by
  apply '''+PUBLIC+''' nullBad (integrable_dirac (by simp))
  simpa only [ae_dirac_eq, Filter.eventually_pure] using
    (show (nullBad 0).PosDef by simpa [nullBad] using
      (Matrix.PosDef.one : (1 : Matrix (Fin 1) (Fin 1) ℝ).PosDef))

theorem null_bad_is_not_pointwise_PD : ¬ ∀ x : ℝ, (nullBad x).PosDef := by
  intro h
  have hp := (h 1).diag_pos (i := (0 : Fin 1))
  norm_num [nullBad] at hp

'''
    text+='theorem literal_T :\n'+t+' := by\n  intro d q hq\n  exact native_actual_T hq\n\n'
    body=t.split('\n',1)[1];q0=re.sub(r'\bq\b','0',body);d2=re.sub(r'\bd\b','2',q0)
    text+='theorem literal_T_q0 {d : ℕ} (hd : 1 < d) :\n'+q0+' := by\n  exact native_actual_T (d := d) (q := 0) hd\n\n'
    text+='theorem literal_T_q0_d2 :\n'+d2+' := by\n  exact native_actual_T (d := 2) (q := 0) (by norm_num)\n\n'
    names=['literal_P','P_empty_indices','P_singleton_identity','P_ae_PD_dirac_null_bad','null_bad_is_not_pointwise_PD','literal_T','literal_T_q0','literal_T_q0_d2']
    for use,minus in [(False,False),(False,True),(True,False),(True,True)]:
        label=('cos' if use else 'ordinary')+('_negative' if minus else '_positive');name='allreal_'+label;names.append(name)
        generic=t.replace('∀ useCos minus : Bool,','let useCos := '+str(use).lower()+'; let minus := '+str(minus).lower()+';')
        text+='theorem '+name+' :\n'+generic+' := by\n  intro d q hq\n  dsimp only\n  intro s\n  exact native_actual_T hq s '+str(use).lower()+' '+str(minus).lower()+'\n\n'
        for value,tag in [('0','zero'),('(-1)','negative'),('1','positive')]:
            name='q0_d2_'+label+'_s_'+tag;names.append(name)
            specialized=d2.replace('∀ s : ℝ, ∀ useCos minus : Bool,','let s : ℝ := '+value+'; let useCos := '+str(use).lower()+'; let minus := '+str(minus).lower()+';')
            text+='theorem '+name+' :\n'+specialized+' := by\n  exact native_actual_T (d := 2) (q := 0) (by norm_num) '+value+' '+str(use).lower()+' '+str(minus).lower()+'\n\n'
    text+='end NativeLiteralApplications\n'
    for name in names:text+='#print axioms NativeLiteralApplications.'+name+'\n'
    text+='\nset_option pp.all true in\n#check @'+PUBLIC+'\nset_option pp.all true in\n#check native_actual_T\n'
    (h/'NativeLiteralApplications.lean').write_text(text)
    prior=REPO/'.astis/semantic-neutral-20261115/trace_exp_native_61e4/harness-v3'
    for name in ['NativeAudit.lean','NativeTransitiveGraph.lean']:
        s=(prior/name).read_text().replace('Tests.GaussianComplexityTraceMgfDomain','Tests.GaussianComplexityMatrixMgfDomain').replace('NativeAuditR16','NativeAuditR17').replace('NativeTransitiveR16','NativeTransitiveR17')
        s=s.replace('AutoSamplingTheory.TechnicalLemmas.Analysis.MatrixTraceExponentialBounds.trace_exp_pos_and_le_card_mul_exp_abs_mul_norm',PUBLIC).replace('.actual_source_four_trace_mgfs_integrable_positive_and_bounded',SUFFIX)
        s=s.replace(str(prior.parent),str(OWN)).replace('30172847ec40c24426f0b39afc4887719810eca0',COMMIT)
        if name=='NativeAudit.lean':
            modules='def modules : Array String := #[\n  '+',\n  '.join(json.dumps(x) for x in closure['topological_order']+['NativeLiteralApplications'])+']\n\n'
            s,count=re.subn(r'def modules : Array String := #\[.*?\]\s*\n(?=def atJ)',modules,s,count=1,flags=re.S);assert count==1
        (h/name).write_text(s)
    write_json(OWN/'harness-mechanism-custody.json',{'candidate_commit':COMMIT,'prior_mechanics_only':[{'file':str(prior/n),'sha256':file_sha(prior/n)} for n in ['NativeAudit.lean','NativeTransitiveGraph.lean']],'old_checks_verdicts_receipts_olean_not_reused':True,'new_literal_sealed_P_T_and_application_tests':names,'P_ae_test_has_a_genuinely_non_PD_null_outcome':True,'ASTIS_math_source_unchanged':True})
    packages=json.loads((OWN/'verified-package-inputs.json').read_text());env=lean_env(packages['packages']);flags=[str(LEAN),'-DmaxRecDepth=32768','-DmaxHeartbeats=0','-Ddebug.skipKernelTC=false']
    commands=[{'id':'literal-types-and-boundaries','argv':flags+['-o',str(OUT/'NativeLiteralApplications.olean'),str(h/'NativeLiteralApplications.lean')]},{'id':'lossless-raw-type-value-kernel','argv':flags+['--run',str(h/'NativeAudit.lean')]},{'id':'complete-recursive-type-value-graph','argv':flags+['--run',str(h/'NativeTransitiveGraph.lean')]}]
    write_json(OWN/'harness-commands.json',commands)
    files=list(h.iterdir())+[OWN/n for n in ['native_common.py','prepare_harness.py','harness-mechanism-custody.json','compile-assignment.json','compile-completed.json','harness-commands.json']]+[p for p in OUT.rglob('*') if p.is_file()]
    assignment={'candidate_commit':COMMIT,'only_fresh_this_assignment_ASTIS_output_present':True,'inputs':[{'path':str(p.relative_to(OWN)),'sha256':file_sha(p)} for p in files]};write_json(OWN/'harness-assignment.json',assignment)
    for c in commands:
        for row in assignment['inputs']:assert file_sha(OWN/row['path'])==row['sha256']
        run(c['id'],c['argv'],cwd=h,env=env)
    write_json(OWN/'harness-completed.json',{'candidate_commit':COMMIT,'all_actual_exit_zero':True,'literal_kernel_DAG_and_recursive_closure_complete':True})
if __name__=='__main__':main()
