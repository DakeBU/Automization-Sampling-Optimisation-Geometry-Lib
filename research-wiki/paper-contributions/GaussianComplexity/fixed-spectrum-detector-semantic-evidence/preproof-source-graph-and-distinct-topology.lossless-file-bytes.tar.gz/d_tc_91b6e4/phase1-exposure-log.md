# Phase 1 actual input and exposure log

This is an affirmative log of actual visible inputs, including incidental filename exposure and unsuccessful extraction attempts. It is not a retrospective zero-exposure attestation.

1. Received the parent assignment in the new-task message. It states the role, exclusive output directory, source path/size/hash, sealed-statement hash (metadata only), forbidden inputs and staged phase boundaries. No parent proof plan or prior mathematical verdict accompanied that assignment.
2. Initial command: `pwd && rg --files -g 'AGENTS.md' -g 'proof-digestion-protocol.md' -g 'evidence-routed-memory-protocol.md'` in the repository. This returned the three expected instruction paths plus these incidental **filenames only**:

   * `research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-first-order-semantic-evidence/fresh-source-reader-4e8f6a/phase1/inputs/AGENTS.md`
   * `research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-first-order-semantic-evidence/fresh-source-reader-4e8f6a/phase1/inputs/evidence-routed-memory-protocol.md`
   * `research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-first-order-semantic-evidence/fresh-source-reader-4e8f6a/phase1/inputs/proof-digestion-protocol.md`
   * `research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-normalizer-semantic-evidence/fresh-source-reader-640251/phase1/instructions/AGENTS.md`
   * `research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-normalizer-semantic-evidence/fresh-source-reader-640251/phase1/instructions/evidence-routed-memory-protocol.md`
   * `research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-normalizer-semantic-evidence/fresh-source-reader-640251/phase1/instructions/proof-digestion-protocol.md`
   * `research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-geometry-semantic-evidence/fresh-source-reader-9a6d2f/phase1/instructions/AGENTS.md`

   None of those incidental files was opened, searched for content or used as mathematical input. Their paths reveal previous artifact category names/actor-like identifiers. The parent was notified before this freeze. Broad file discovery was not repeated.
3. Read `AGENTS.md` and the two requested protocols by `cat`, then bounded `sed` reads to recover any combined-output truncation; instruction files were read completely. The protocol's generic binder/definition/probability discipline was visible. AGENTS includes unrelated program/scheduling/old handoff prose; no linked records were opened and no scheduling or mutation API was called. The explicit assignment governs the bounded neutral audit.
4. Read bytes of the exact pinned HTML to compute its length/SHA256 and inspect its opening title; then read its heading list and the beginning of §4 as raw HTML. No browser, network, alternate source edition, source index or external [22] text was accessed.
5. Attempted a BeautifulSoup extraction, which failed immediately at `import bs4` (`ModuleNotFoundError`) before the source read or any output creation. The subsequent `cat` of intended outputs failed because those files did not exist. No dependency was installed.
6. Created the assigned directory and a small stdlib `html.parser` extraction script there. One initial path calculation pointed at nonexistent `ASTIS-GC/huanjian-resume-20261103/2610.20492v1.html` and failed without reading file content. The next extraction failed because `offset` collided with an HTMLParser attribute after reading the allowed source. Both errors were corrected in the same script before the freeze. No mathematical inference came from these failures.
7. The successful extraction reads only the allowed original HTML and writes local renditions to this actor's directory. Full substantive paper text was read via `text-full.txt`, with §2/§4 and Appendix C read separately first. Every mathematical expression in the scoped §2/§4/C raw sections is checked to occur in the rendition by an in-order MathML-ID coverage assertion (45, 221, 528 respectively).
8. Generated cognition and this exposure record from that raw-only reading. Independently checked source size/hash and artifact hashes are in the manifest. Shell/Python standard libraries and tool/runtime instructions are operational inputs, not mathematical theorem sources.

As of phase1 freeze: no sealed signature content, source graph content, implementation Lean, tests, Mathlib proofs, root proofplan/exposure record, old review/lesson/publication/audit content or other `.astis` record has been opened. The only incidental exposure beyond the explicit mathematical whitelist is the filename inventory above plus general repository instructions expressly requested by the parent. This record must survive later phases.
