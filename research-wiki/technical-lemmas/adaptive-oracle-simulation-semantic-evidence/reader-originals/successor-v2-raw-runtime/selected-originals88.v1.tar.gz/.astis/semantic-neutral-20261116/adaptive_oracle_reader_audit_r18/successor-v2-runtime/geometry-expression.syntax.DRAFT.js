(el=>{
 const rect=r=>({left:r.left,right:r.right,top:r.top,bottom:r.bottom,width:r.width,height:r.height});
 const style=getComputedStyle(el),parent=el.parentElement,ps=getComputedStyle(parent),pr=parent.getBoundingClientRect();
 const visibleMath=el.querySelector(':scope > mjx-math');
 const assistive=el.querySelector(':scope > mjx-assistive-mml');
 const native=[...(assistive?assistive.querySelectorAll('math'):[])];
 const nativeAudit=native.map(m=>{const ancestry=[];for(let p=m;p;p=p.parentElement){
   const s=getComputedStyle(p);ancestry.push({tag:p.tagName,display:s.display,visibility:s.visibility,ariaHidden:p.getAttribute('aria-hidden')});
   if(p===el)break;}
   return{text:m.textContent,namespace:m.namespaceURI,ancestry,
    semanticSubtreeAvailable:!!m.textContent.trim()&&m.namespaceURI==='http://www.w3.org/1998/Math/MathML'&&
     ancestry.every(x=>x.display!=='none'&&x.visibility!=='hidden'&&x.ariaHidden!=='true')};});
 const glyphs=visibleMath?[...visibleMath.querySelectorAll('mjx-c')].filter(e=>!e.closest('mjx-assistive-mml')):[];
 const glyphBoxes=glyphs.map(g=>({className:g.className,rect:rect(g.getBoundingClientRect()),geometry:(el=>{
  const r=el.getBoundingClientRect();let header=0;const hs=[...document.querySelectorAll('header,.mobile-bar,.verification-strip')];
  for(let pass=0;pass<hs.length+1;pass++)for(const h of hs){const s=getComputedStyle(h),q=h.getBoundingClientRect();if(['fixed','sticky'].includes(s.position)&&s.display!=='none'&&s.visibility!=='hidden'&&q.width>0&&q.height>0&&q.right>0&&q.left<innerWidth&&q.bottom>0&&q.top<=header+1)header=Math.max(header,q.bottom);}
  let c={left:0,right:innerWidth,top:header+4,bottom:innerHeight-4};
  for(let p=el.parentElement;p;p=p.parentElement){const s=getComputedStyle(p),q=p.getBoundingClientRect();if(['hidden','clip','scroll','auto'].includes(s.overflowX)){c.left=Math.max(c.left,q.left+p.clientLeft);c.right=Math.min(c.right,q.left+p.clientLeft+p.clientWidth);}if(['hidden','clip','scroll','auto'].includes(s.overflowY)){c.top=Math.max(c.top,q.top+p.clientTop);c.bottom=Math.min(c.bottom,q.top+p.clientTop+p.clientHeight);}}
  const iw=Math.max(0,Math.min(r.right,c.right)-Math.max(r.left,c.left)),ih=Math.max(0,Math.min(r.bottom,c.bottom)-Math.max(r.top,c.top));
  return {left:r.left,right:r.right,top:r.top,bottom:r.bottom,width:r.width,height:r.height,header,clip:c,intersectionWidth:iw,intersectionHeight:ih,positive:iw>0&&ih>0};
})(g)}))
   .filter(g=>g.rect.width>0&&g.rect.height>0);
 const last=glyphBoxes.length?glyphBoxes[glyphBoxes.length-1]:null;
 const allGlyphsVerticallyInsideActualClip=glyphBoxes.length>0&&glyphBoxes.every(g=>
   g.rect.top>=g.geometry.clip.top&&g.rect.bottom<=g.geometry.clip.bottom);
 const r=el.getBoundingClientRect();
 return{rect:rect(r),geometry:(el=>{
  const r=el.getBoundingClientRect();let header=0;const hs=[...document.querySelectorAll('header,.mobile-bar,.verification-strip')];
  for(let pass=0;pass<hs.length+1;pass++)for(const h of hs){const s=getComputedStyle(h),q=h.getBoundingClientRect();if(['fixed','sticky'].includes(s.position)&&s.display!=='none'&&s.visibility!=='hidden'&&q.width>0&&q.height>0&&q.right>0&&q.left<innerWidth&&q.bottom>0&&q.top<=header+1)header=Math.max(header,q.bottom);}
  let c={left:0,right:innerWidth,top:header+4,bottom:innerHeight-4};
  for(let p=el.parentElement;p;p=p.parentElement){const s=getComputedStyle(p),q=p.getBoundingClientRect();if(['hidden','clip','scroll','auto'].includes(s.overflowX)){c.left=Math.max(c.left,q.left+p.clientLeft);c.right=Math.min(c.right,q.left+p.clientLeft+p.clientWidth);}if(['hidden','clip','scroll','auto'].includes(s.overflowY)){c.top=Math.max(c.top,q.top+p.clientTop);c.bottom=Math.min(c.bottom,q.top+p.clientTop+p.clientHeight);}}
  const iw=Math.max(0,Math.min(r.right,c.right)-Math.max(r.left,c.left)),ih=Math.max(0,Math.min(r.bottom,c.bottom)-Math.max(r.top,c.top));
  return {left:r.left,right:r.right,top:r.top,bottom:r.bottom,width:r.width,height:r.height,header,clip:c,intersectionWidth:iw,intersectionHeight:ih,positive:iw>0&&ih>0};
})(el),clientWidth:el.clientWidth,scrollWidth:el.scrollWidth,
   scrollLeft:el.scrollLeft,maxScrollLeft:el.scrollWidth-el.clientWidth,
   computed:{display:style.display,maxWidth:style.maxWidth,overflowX:style.overflowX,overflowY:style.overflowY,
    fontSize:style.fontSize,fontSizePx:parseFloat(style.fontSize),lineHeight:style.lineHeight,
    paddingTop:style.paddingTop,paddingBottom:style.paddingBottom},
   parent:{rect:rect(pr),contentLeft:pr.left+parent.clientLeft+parseFloat(ps.paddingLeft),
    contentRight:pr.left+parent.clientLeft+parent.clientWidth-parseFloat(ps.paddingRight),
    contentWidth:parent.clientWidth-parseFloat(ps.paddingLeft)-parseFloat(ps.paddingRight),fontSize:ps.fontSize},
   directVisibleMathPresent:!!visibleMath,directAssistivePresent:!!assistive,nativeMathMLCount:native.length,
   nativeMathML:nativeAudit,normalizedFormula:native.length?native[0].textContent.replace(/\s+/g,''):'',
   glyphCount:glyphBoxes.length,visibleGlyphBoxes:glyphBoxes,lastVisibleGlyph:last,
   allVisibleGlyphsVerticallyInsideActualClip:allGlyphsVerticallyInsideActualClip,
   assistiveSubtreeTouched:false,sourceAnchorScrollModified:false};
});
(xs=>xs.map(el=>{
 const rect=r=>({left:r.left,right:r.right,top:r.top,bottom:r.bottom,width:r.width,height:r.height});
 const style=getComputedStyle(el),parent=el.parentElement,ps=getComputedStyle(parent),pr=parent.getBoundingClientRect();
 const visibleMath=el.querySelector(':scope > mjx-math');
 const assistive=el.querySelector(':scope > mjx-assistive-mml');
 const native=[...(assistive?assistive.querySelectorAll('math'):[])];
 const nativeAudit=native.map(m=>{const ancestry=[];for(let p=m;p;p=p.parentElement){
   const s=getComputedStyle(p);ancestry.push({tag:p.tagName,display:s.display,visibility:s.visibility,ariaHidden:p.getAttribute('aria-hidden')});
   if(p===el)break;}
   return{text:m.textContent,namespace:m.namespaceURI,ancestry,
    semanticSubtreeAvailable:!!m.textContent.trim()&&m.namespaceURI==='http://www.w3.org/1998/Math/MathML'&&
     ancestry.every(x=>x.display!=='none'&&x.visibility!=='hidden'&&x.ariaHidden!=='true')};});
 const glyphs=visibleMath?[...visibleMath.querySelectorAll('mjx-c')].filter(e=>!e.closest('mjx-assistive-mml')):[];
 const glyphBoxes=glyphs.map(g=>({className:g.className,rect:rect(g.getBoundingClientRect()),geometry:(el=>{
  const r=el.getBoundingClientRect();let header=0;const hs=[...document.querySelectorAll('header,.mobile-bar,.verification-strip')];
  for(let pass=0;pass<hs.length+1;pass++)for(const h of hs){const s=getComputedStyle(h),q=h.getBoundingClientRect();if(['fixed','sticky'].includes(s.position)&&s.display!=='none'&&s.visibility!=='hidden'&&q.width>0&&q.height>0&&q.right>0&&q.left<innerWidth&&q.bottom>0&&q.top<=header+1)header=Math.max(header,q.bottom);}
  let c={left:0,right:innerWidth,top:header+4,bottom:innerHeight-4};
  for(let p=el.parentElement;p;p=p.parentElement){const s=getComputedStyle(p),q=p.getBoundingClientRect();if(['hidden','clip','scroll','auto'].includes(s.overflowX)){c.left=Math.max(c.left,q.left+p.clientLeft);c.right=Math.min(c.right,q.left+p.clientLeft+p.clientWidth);}if(['hidden','clip','scroll','auto'].includes(s.overflowY)){c.top=Math.max(c.top,q.top+p.clientTop);c.bottom=Math.min(c.bottom,q.top+p.clientTop+p.clientHeight);}}
  const iw=Math.max(0,Math.min(r.right,c.right)-Math.max(r.left,c.left)),ih=Math.max(0,Math.min(r.bottom,c.bottom)-Math.max(r.top,c.top));
  return {left:r.left,right:r.right,top:r.top,bottom:r.bottom,width:r.width,height:r.height,header,clip:c,intersectionWidth:iw,intersectionHeight:ih,positive:iw>0&&ih>0};
})(g)}))
   .filter(g=>g.rect.width>0&&g.rect.height>0);
 const last=glyphBoxes.length?glyphBoxes[glyphBoxes.length-1]:null;
 const allGlyphsVerticallyInsideActualClip=glyphBoxes.length>0&&glyphBoxes.every(g=>
   g.rect.top>=g.geometry.clip.top&&g.rect.bottom<=g.geometry.clip.bottom);
 const r=el.getBoundingClientRect();
 return{rect:rect(r),geometry:(el=>{
  const r=el.getBoundingClientRect();let header=0;const hs=[...document.querySelectorAll('header,.mobile-bar,.verification-strip')];
  for(let pass=0;pass<hs.length+1;pass++)for(const h of hs){const s=getComputedStyle(h),q=h.getBoundingClientRect();if(['fixed','sticky'].includes(s.position)&&s.display!=='none'&&s.visibility!=='hidden'&&q.width>0&&q.height>0&&q.right>0&&q.left<innerWidth&&q.bottom>0&&q.top<=header+1)header=Math.max(header,q.bottom);}
  let c={left:0,right:innerWidth,top:header+4,bottom:innerHeight-4};
  for(let p=el.parentElement;p;p=p.parentElement){const s=getComputedStyle(p),q=p.getBoundingClientRect();if(['hidden','clip','scroll','auto'].includes(s.overflowX)){c.left=Math.max(c.left,q.left+p.clientLeft);c.right=Math.min(c.right,q.left+p.clientLeft+p.clientWidth);}if(['hidden','clip','scroll','auto'].includes(s.overflowY)){c.top=Math.max(c.top,q.top+p.clientTop);c.bottom=Math.min(c.bottom,q.top+p.clientTop+p.clientHeight);}}
  const iw=Math.max(0,Math.min(r.right,c.right)-Math.max(r.left,c.left)),ih=Math.max(0,Math.min(r.bottom,c.bottom)-Math.max(r.top,c.top));
  return {left:r.left,right:r.right,top:r.top,bottom:r.bottom,width:r.width,height:r.height,header,clip:c,intersectionWidth:iw,intersectionHeight:ih,positive:iw>0&&ih>0};
})(el),clientWidth:el.clientWidth,scrollWidth:el.scrollWidth,
   scrollLeft:el.scrollLeft,maxScrollLeft:el.scrollWidth-el.clientWidth,
   computed:{display:style.display,maxWidth:style.maxWidth,overflowX:style.overflowX,overflowY:style.overflowY,
    fontSize:style.fontSize,fontSizePx:parseFloat(style.fontSize),lineHeight:style.lineHeight,
    paddingTop:style.paddingTop,paddingBottom:style.paddingBottom},
   parent:{rect:rect(pr),contentLeft:pr.left+parent.clientLeft+parseFloat(ps.paddingLeft),
    contentRight:pr.left+parent.clientLeft+parent.clientWidth-parseFloat(ps.paddingRight),
    contentWidth:parent.clientWidth-parseFloat(ps.paddingLeft)-parseFloat(ps.paddingRight),fontSize:ps.fontSize},
   directVisibleMathPresent:!!visibleMath,directAssistivePresent:!!assistive,nativeMathMLCount:native.length,
   nativeMathML:nativeAudit,normalizedFormula:native.length?native[0].textContent.replace(/\s+/g,''):'',
   glyphCount:glyphBoxes.length,visibleGlyphBoxes:glyphBoxes,lastVisibleGlyph:last,
   allVisibleGlyphsVerticallyInsideActualClip:allGlyphsVerticallyInsideActualClip,
   assistiveSubtreeTouched:false,sourceAnchorScrollModified:false};
}));
