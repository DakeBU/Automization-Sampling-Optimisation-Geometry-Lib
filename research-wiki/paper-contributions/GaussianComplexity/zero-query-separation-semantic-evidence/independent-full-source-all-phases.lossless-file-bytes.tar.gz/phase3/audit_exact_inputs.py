from pathlib import Path
import json,hashlib,re
BASE=Path(__file__).resolve().parent
REPO=Path('/Users/zhouhuanjian/ASTIS-GC')
def sha(b):return hashlib.sha256(b).hexdigest()
def dump(name,data):(BASE/name).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
P=(BASE/'inputs/P.lean').read_text();T=(BASE/'inputs/T.lean').read_text()
M=json.loads((BASE/'inputs/correspondence.json').read_text())
R=json.loads((BASE/'inputs/reviewer_packet.json').read_text())
L=json.loads((BASE/'inputs/lesson.json').read_text())['units'][0]
U=json.loads((BASE/'inputs/pub.json').read_text())['items'][0]
S=json.loads((BASE/'inputs/seal.json').read_text())
CTX=R['candidate_publication_context']
paths={
 'AutoSamplingTheory/ExampleCases/GaussianComplexity/ZeroQuerySeparation.lean':P,
 'Tests/GaussianComplexityZeroQuerySeparation.lean':T
}
snapdir=BASE/'mathlib_inputs';snapdir.mkdir(exist_ok=True)
snapshots=[]
for path in dict.fromkeys(row['lean']['file'] for row in M['rows'] if row['lean']['file'].startswith('.lake/packages/mathlib/Mathlib/')):
    p=REPO/path;b=p.read_bytes();text=b.decode();paths[path]=text
    out=snapdir/path.removeprefix('.lake/packages/mathlib/Mathlib/').replace('/','__')
    out.write_bytes(b)
    snapshots.append({'original':path,'snapshot':str(out.relative_to(BASE)),'bytes':len(b),'sha256':sha(b)})
rows=[]
for row in M['rows']:
    l=row['lean'];text=paths[l['file']];a=l['start_character_offset'];b=l['end_character_offset_exclusive'];block=text[a:b]
    checks={
      'file_hash':sha(text.encode())==l['file_sha256'],
      'offset_range':0<=a<b<=len(text),
      'block_hash':sha(block.encode())==l['exact_locator_block_sha256'],
      'start_marker':text.startswith(l['exact_start_marker'],a),
      'end_marker':l['exact_end_marker_exclusive'] is None or text.startswith(l['exact_end_marker_exclusive'],b),
      'start_line':text.count('\n',0,a)+1==l['line']
    }
    # Record both natural end-line conventions rather than silently rewriting metadata.
    last_covered_line=text.count('\n',0,b-1)+1
    endpoint_line=text.count('\n',0,b)+1
    checks['end_line_in_supported_convention']=l['end_line'] in {last_covered_line,endpoint_line}
    rows.append({'id':row['id'],'checks':checks,'all_checks_pass':all(checks.values()),'declared_end_line':l['end_line'],'last_covered_line':last_covered_line,'endpoint_line':endpoint_line,'unicode_chars':b-a,'utf8_bytes':len(block.encode()),'exact_block':block,'source_claim_review':'See independent_review.md; locator success is not source truth'})
dump('locator_audit.json',{'convention':'Offsets are decoded Unicode characters, not UTF-8 byte offsets; hashes are raw UTF-8 bytes','rows':rows,'all_38_pass':len(rows)==38 and all(r['all_checks_pass'] for r in rows),'snapshots':snapshots})
folds=[]
for i,step in enumerate(L['steps'],1):
    code=step['lean'];hay=P if i<=4 else T
    a=hay.find(code)
    folds.append({'step':i,'title':step['title'],'literal_match':a>=0,'source':'P' if i<=4 else 'T','unicode_start':a,'unicode_end_exclusive':a+len(code) if a>=0 else None,'code_sha256':sha(code.encode()),'bytes':len(code.encode()),'complete_T':i==6 and code==T})
dump('fold_audit.json',{'steps':folds,'all_six_literal':len(folds)==6 and all(x['literal_match'] for x in folds),'step6_full_T':folds[-1]['complete_T']})

canonical_payload={k:v for k,v in R.items() if k!='packet_sha256'}
canon_hash=sha(json.dumps(canonical_payload,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())
ct_lesson={k:v for k,v in L.items() if k!='boundary'}
checks={
 'packet_canonical_hash':canon_hash==R['packet_sha256']=='698e80cd3f8ff7485ee94c15987e8c2c7b72f6bf49da88f792c3cafb81f0e6a6',
 'publication_binding_supplied_matches_phase2':R['publication_binding_sha256']=='6191ef91c7d9b320585d3cf7a2385ad81b9515930d6e5b2e1106773be58e58b2',
 'context_full_P':CTX['current_lean_module']==P,
 'context_file_raw_hash':CTX['file']==sha(P.encode()),
 'context_source':CTX['source']==U['source'],
 'context_statement':CTX['statement']==U['statement'],
 'context_formulae':CTX['formulae']==U['formulae'],
 'context_assumptions':CTX['assumptions']==U['assumptions'],
 'context_obligations':CTX['obligations']==U['obligations'],
 'context_lesson_without_boundary':CTX['lesson']==ct_lesson,
 'context_binding':CTX['binding']=={k:v for k,v in U['bindings'][0].items() if k in ['declaration','role','supports']},
 'context_assumption_candidates':CTX['candidate_assumptions']==[{k:v for k,v in a.items() if k in ['source','lean']} for a in U['bindings'][0]['assumption_deltas']],
 'P_type_seal_exact':P[P.index('theorem actual_'):P.index(':= by',P.index('theorem actual_'))]==S['producer']['signature'],
 'T_type_seal_exact':T[T.index('private theorem'):T.index(':= by',T.index('private theorem'))]==S['actual_private_consumer']['signature'],
 'phase2_public_literal':R['lean']==json.loads((BASE.parent/'phase2/input.raw.json').read_text())['lean'],
 'phase2_blind_reconstruction':R['blind_reconstruction']==json.loads((BASE.parent/'phase2/input.raw.json').read_text())['blind_reconstruction'],
 'no_placeholders_in_P_T':re.search(r'\b(sorry|admit|axiom|unsafe|implemented_by|native_decide|run_tac)\b',P+'\n'+T) is None,
 'P_owned_theorem_count_one':len(re.findall(r'^theorem ',P,re.M))==1,
 'T_private_theorem_count_one':len(re.findall(r'^private theorem ',T,re.M))==1,
 'actual_call_in_T':T.count('AutoSamplingTheory.ExampleCases.GaussianComplexity.ZeroQuerySeparation.actual_zero_query_gaussian_event_gap hd hκ')==1
}
dump('exact_input_audit.json',{'checks':checks,'all_checks_pass':all(checks.values()),'canonical_reviewer_packet_sha256':canon_hash,'binding_status':'supplied identifier/context comparison only; no publication tool/native validation performed','full_context_lesson_keys':list(CTX['lesson']),'standalone_lesson_keys':list(L)})
print(json.dumps({'locator_rows':len(rows),'all_locators_pass':all(r['all_checks_pass'] for r in rows),'failed_locator_checks':[{k:v for k,v in r.items() if k!='exact_block'} for r in rows if not r['all_checks_pass']],'six_literal_folds':folds,'exact_input_checks':checks},ensure_ascii=False,indent=2))
