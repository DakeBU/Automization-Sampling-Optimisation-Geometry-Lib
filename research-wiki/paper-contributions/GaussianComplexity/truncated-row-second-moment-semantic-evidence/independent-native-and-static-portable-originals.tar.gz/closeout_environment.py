from pathlib import Path
import json,subprocess,hashlib,datetime
R=Path.cwd();O=R/'.astis/semantic-neutral-20261111/rc_native_68bc';E=json.loads((O/'environment.json').read_text());sha=lambda b:hashlib.sha256(b).hexdigest()
def run(args):
 p=subprocess.run(args,cwd=R,capture_output=True);return {'command':args,'exit_code':p.returncode,'stdout':p.stdout.decode(),'stderr':p.stderr.decode()}
r={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':run(['git','rev-parse','HEAD']),'tracked_status':run(['git','status','--porcelain=v1','--untracked-files=no']),'binary_sha256':sha(Path(E['binary']).read_bytes()),'toolchain_sha256':sha((R/'lean-toolchain').read_bytes()),'manifest_sha256':sha((R/'lake-manifest.json').read_bytes()),'packages':[]}
for pkg in E['packages']:
 path=R/'.lake/packages'/pkg['name'];head=run(['git','-C',str(path),'rev-parse','HEAD']);status=run(['git','-C',str(path),'status','--porcelain=v1','--untracked-files=all','--ignore-submodules=none']);r['packages'].append({'name':pkg['name'],'head':head,'complete_porcelain':status});assert head['exit_code']==0 and head['stdout'].strip()==pkg['expected_revision'] and status['exit_code']==0 and status['stdout']==''
assert r['head']['stdout'].strip()==E['candidate'];assert r['tracked_status']['stdout']=='';assert r['binary_sha256']==E['binary_sha256'];assert r['toolchain_sha256']==E['toolchain_exact_git_sha256'];assert r['manifest_sha256']==E['manifest_exact_git_sha256']
(O/'closeout-environment.json').write_text(json.dumps(r,indent=2)+'\n');print('HEAD, tracked cleanliness, binary/toolchain/manifest and all9 package HEAD/full porcelain remain unchanged.')
