"""Guarded one-call existing-V lease parking; prepare/execute require concrete auth.

Merely compiling this driver does not run any API or prepare an authorized request.
Every rejection or partial append after the persisted attempt guard is final here.
"""
from pathlib import Path
import contextlib, datetime, gzip, hashlib, io, json, os, subprocess, sys, time, traceback
sys.dont_write_bytecode = True
ROOT = Path('/Users/zhouhuanjian/ASTIS-GC')
OUT = ROOT / 'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-query-integration-20261107/independent-integration-reader-review'
DIR = OUT.parent
CORE = '9e9306ec2f5648611b4001f97a82cd02bb24db44'
DIGEST = '6aeb1b4c5d76c1d4853e89c548bf46d2b53c75a388778f1fb7f1373bdba3bd50'
ADV = 'ASTIS-SA-20261107-GaussianComplexityFixedSpectrumQuery'
ACTOR = '/root/foq_integration_reader_review'
PROOF = 'huanjian_gc_20261107_fixed_spectrum_query'
INTEGRATOR = 'huanjian_gc_20261107_fixed_spectrum_query_integration'
VERIFIER = '/root/reader_361904'
CHECKED = 'de220a52922fc2aa2c007ea14bf2c2949030b8d2'
ACCEPTED = 'dd661f1bd36a83de9efe6bb5d0784e0ab1e56802'
DECL = 'AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumAffine.actual_affine_precision_query'
SOURCE = ROOT / 'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-query-semantic-evidence'
LEDGER = ROOT / 'runs/substantive_advances.jsonl'
DISC = ROOT / 'runs/substantive_discoveries.jsonl'
AUDIT = ROOT / 'research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-query.json'
CELL = ROOT / 'research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-query.json'
AUTH = DIR / 'existing-V-parking-execution-authorization.json'
READER = OUT / 'actual-local-integration-acceptance.json'
CAVEAT = DIR / 'current-browser-report-prose-caveats.json'
REQUEST = OUT / 'local-integration-parking.request.json'
PREFLIGHT = OUT / 'local-integration-parking.preflight.json'
ATTEMPT = OUT / 'local-integration-parking.attempt-guard.json'
RECEIPT = OUT / 'local-integration-parking.normal-api.receipt.json'
sys.path.insert(0, str(ROOT / 'tools'))
import astis_advance as a
import astis_publication as pub
import astis_site as site
sha = lambda raw: hashlib.sha256(raw).hexdigest()
canon = lambda item: json.dumps(item, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()
obj = lambda path: json.loads(path.read_bytes())
def head(): return subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
def desc(path): return {'path': str(path.relative_to(ROOT)), 'raw_sha256': sha(path.read_bytes())}
def put(path, item):
    assert not path.exists(), str(path)
    path.write_text(json.dumps(item, ensure_ascii=False, indent=2) + '\n')
def archive(path, raw):
    assert not path.exists(), str(path)
    path.write_bytes(gzip.compress(raw, compresslevel=9, mtime=0))
    assert gzip.decompress(path.read_bytes()) == raw
    return {**desc(path), 'decompressed_raw_sha256': sha(raw), 'decompressed_bytes': len(raw)}
def unpack(item):
    path = ROOT / item['path']; raw = path.read_bytes()
    assert sha(raw) == item['raw_sha256']
    value = gzip.decompress(raw)
    assert sha(value) == item['decompressed_raw_sha256']
    return value
def old_unpack(item):
    raw = (ROOT / item['path']).read_bytes(); assert sha(raw) == item['gzip_sha256']
    value = gzip.decompress(raw); assert sha(value) == item['raw_sha256']; return value
def hashes(folder):
    return {str(p.relative_to(ROOT)): sha(p.read_bytes()) for p in sorted(folder.rglob('*')) if p.is_file()}
def frontier_hashes():
    return {str(p.relative_to(ROOT)): sha(p.read_bytes()) for p in sorted((ROOT / 'research-wiki/frontier-cells').glob('*.json'))}
def fixed_inputs():
    prep = obj(OUT / 'preparation-report.json')
    assert sha((OUT / 'preparation-report.json').read_bytes()) == 'd18f57fb92715929a4270794b48e1616020d4b12ae48b29164460c224eb7055d'
    for item in prep['shared_paths']:
        assert sha((ROOT / item['path']).read_bytes()) == item['planned_after_sha256']
    for path, digest in prep['source_test_publication_lesson_pins'].items():
        assert sha((ROOT / path).read_bytes()) == digest
    inputs = json.loads(old_unpack(prep['foreign_source_content_inputs']))
    assert len(inputs) == 6524
    for path, pin in inputs.items():
        p = ROOT / path
        raw = os.fsencode(os.readlink(p)) if p.is_symlink() else p.read_bytes()
        if path == 'website/content/functor_hypergraph.json':
            assert sha(raw) == '94b56f87136ca97820893e5531d16d36334d44bc6b9e41981d39aa700f8fe782'
        else:
            assert sha(raw) == pin['sha256'] and len(raw) == pin['bytes'], path
    oldgit = json.loads(old_unpack(prep['tracked_git_objects'])); assert len(oldgit) == 122505
    actualgit = {}
    for line in subprocess.check_output(['git', 'ls-files', '--stage', '-z'], cwd=ROOT).split(b'\0'):
        if line:
            metadata, path = line.split(b'\t', 1); mode, blob, stage = metadata.decode().split()
            assert stage == '0'; actualgit[os.fsdecode(path)] = [mode, blob]
    assert all(actualgit.get(k) == v for k, v in oldgit.items() if k != 'website/content/functor_hypergraph.json')
    for path, digest in json.loads(old_unpack(prep['old_GaussianComplexity_evidence'])).items():
        assert sha((ROOT / path).read_bytes()) == digest
    atlas = (ROOT / '.atlas-upstream').stat()
    assert [atlas.st_dev, atlas.st_ino, atlas.st_mtime_ns] == [prep['untracked_Atlas'][x] for x in ['device', 'inode', 'mtime_ns']]
    return prep
def common(auth_hash):
    assert head() == CORE and site.source_digest() == DIGEST
    assert len(auth_hash) == 64 and sha(AUTH.read_bytes()) == auth_hash
    auth = obj(AUTH)
    assert auth['authorized_actor'] == ACTOR and auth['authorized_SAU'] == ADV
    assert auth['authorized_integration_owner'] == INTEGRATOR
    assert auth['core'] == CORE and auth['source_digest'] == DIGEST
    assert auth['current_actual_independent_images'] == 26
    assert auth['authorization_by'] == '/root' and auth['root_current_actual_original_images'] == 13
    assert sha((ROOT / auth['root_image_report']).read_bytes()) == auth['root_image_report_raw_sha256'] == 'b7dce858f9e4d6e77f4bab3f764faa313b76cc7c3a153f8e1c4a34f1800a2fce'
    assert auth['original_source_verifier'] == VERIFIER and auth['source_checked_commit'] == CHECKED
    assert auth['first_accepted_audit_carrying_commit'] == ACCEPTED and auth['proof_owner'] == PROOF
    assert auth['accepted_audit_raw_sha256'] == '602ee696d314948391e6371a9a452285407d0064d93576db651071f02ccbf593'
    assert auth['original_source_V_append_raw_sha256'] == 'b60e55ebd0e5dd7de4a54c8b47e6ba62e9793b60b7673f5e60506d4badad5806'
    assert auth['publication_binding_sha256'] == 'fafc6866bd79667295b685939cb04e42374863753ab3e205c43ce6d0780e3970'
    assert auth['ledger_before_exact_raw_sha256'] == 'a3b154e9f52869cb036e652b41b444bc423009f383fdcd3bf430d2a7ebb42b71'
    assert auth['new_source_VERIFIED_or_math_verdict_or_build_browser_remote_merge_purification_Goal_complete_authorized'] is False
    assert auth['report_prose_caveats_raw_sha256'] == '67a2b99c4b939b87ed5d6b9f8c201ef99a35dd73cde3174686d64dc1178dcb3b'
    assert auth['independent_reader_report_raw_sha256'] == sha(READER.read_bytes()) == '6c3bee343ca21373d6b1e8ef6a6242c6eedadf2a7314b52324769ccafe1e00fb'
    reader = obj(READER)
    assert reader['verdict'] == 'ACCEPT_LOCAL_INTEGRATION_AT_EXACT_READER_SUCCESSOR' and reader['all26_NEW_original_files_individually_opened_view_image_original']
    assert sha(CAVEAT.read_bytes()) == '67a2b99c4b939b87ed5d6b9f8c201ef99a35dd73cde3174686d64dc1178dcb3b'
    assert sha(AUDIT.read_bytes()) == '602ee696d314948391e6371a9a452285407d0064d93576db651071f02ccbf593'
    assert obj(AUDIT)['source_review']['reviewer'] == VERIFIER and obj(AUDIT)['source_review']['state'] == 'accepted'
    item = next(x for x in pub.load() if x['id'] == 'huanjian-fixed-spectrum-query')
    assert pub.binding_digest(item, item['bindings'][0]) == 'fafc6866bd79667295b685939cb04e42374863753ab3e205c43ce6d0780e3970'
    cert = DIR / 'status-successor-actual-root-lean-gate-certificate.json'
    assert sha(cert.read_bytes()) == '4f3d597a743f9f5aad082199dd7a52392174911ce4df1b2cc4f87d123b54802f'
    assert cert.read_bytes() == (ROOT / '.astis/site-lean-gate.json').read_bytes()
    assert obj(cert)['passed'] and obj(cert)['commit'] == CORE and obj(cert)['source_digest'] == DIGEST
    assert sha((ROOT / '_site/data/build-metadata.json').read_bytes()) == '5a3c1e53d8455ecd363c7a97d6c64690c360bd3c803d809c9f9b41be0f04759e'
    metadata = obj(ROOT / '_site/data/build-metadata.json')
    assert metadata['gate']['passed'] and metadata['gate']['current'] and metadata['gate']['commit'] == CORE
    return auth, fixed_inputs()

def main():
    assert len(sys.argv) == 3 and sys.argv[1] in ('prepare', 'execute'), 'Usage: driver prepare|execute CONCRETE_ROOT_AUTHORIZATION_RAW_SHA256'
    mode, auth_hash = sys.argv[1:]
    assert not ATTEMPT.exists() and not RECEIPT.exists(), 'Persisted attempt/receipt exists: STOP, never automatically retry'
    auth, prep = common(auth_hash)
    if mode == 'prepare':
        assert not REQUEST.exists() and not PREFLIGHT.exists(), 'Preparation already exists; do not repeat automatically'
        before = LEDGER.read_bytes()
        assert sha(before) == 'a3b154e9f52869cb036e652b41b444bc423009f383fdcd3bf430d2a7ebb42b71' and before.endswith(b'\n')
        states = a.current_advances(); own = states[ADV]
        assert own['state'] == 'STABILIZING' and own['owner_id'] == PROOF and own['latest_evidence']['integration_owner'] == INTEGRATOR
        assert [k for k, v in states.items() if v['state'] == 'STABILIZING'] == [ADV]
        foreign = {k: v for k, v in states.items() if k != ADV}; assert len(foreign) == 280
        assert canon(foreign) == old_unpack(prep['ledger_protection']['runs/substantive_advances.jsonl']['foreign_projection'])
        original = [line for line in before.splitlines(keepends=True) if sha(line) == 'b60e55ebd0e5dd7de4a54c8b47e6ba62e9793b60b7673f5e60506d4badad5806']
        assert len(original) == 1
        event = json.loads(original[0]); se = event['evidence']
        assert event['worker_id'] == VERIFIER and event['to_state'] == 'VERIFIED' and se['verified_commit'] == CHECKED
        assert se['semantic_roundtrip_audit']['accepted_audit_raw_sha256'] == sha(AUDIT.read_bytes())
        evidence = {
            'verifier_id': ACTOR, 'verified_commit': CORE,
            'parking_kind': 'mechanical-existing-verification-parking-after-actual-local-acceptance',
            'authorization': desc(AUTH), 'original_source_verifier_id': VERIFIER,
            'original_source_verified_metadata_commit': CHECKED,
            'first_commit_carrying_accepted_source_metadata': ACCEPTED,
            'original_source_V_append_sha256': sha(original[0]),
            'original_immutable_mathematical_candidate': '1ff1cb79413a853e977a50e598ce04211806dad8',
            'checked_source_tree_audit_state': 'blind-reconstructed / source pending; accepted bytes were not in checked tree',
            'current_source_audit_accepted_at_successor_metadata': True,
            'proving_owner_preserved': PROOF, 'released_integration_owner': INTEGRATOR,
            'publication_declarations': [DECL],
            'gate': {'kind': 'Reuse genuine exact9e official9650job gate and matching actual site/graph/Chrome26 plus independently viewed26 NEW originals; no rerun or new source verdict.', 'actual_core_commit': CORE, 'actual_source_digest': DIGEST, 'canonical_root_gate': desc(DIR / 'status-successor-actual-root-lean-gate-certificate.json'), 'actual_final_site_metadata': desc(DIR / 'status-successor-site-build-metadata.json'), 'independent_26image_local_acceptance': desc(READER), 'browser_report_prose_corrections': desc(CAVEAT), 'normal_reviewed_publication_admission': 'Required and performed by the actual normal schema-v4 API; no replacement/cached assertion.'},
            'source_audit': {'kind': 'Reuse unchanged original independent source V; no new source verdict', 'original_verifier': VERIFIER, 'original_actual_source_V_append_sha256': sha(original[0]), 'original_source_evidence': se['source_audit'], 'current_accepted_audit': desc(AUDIT), 'publication_binding_sha256': prep['publication_binding_sha256'], 'new_source_verdict': False},
            'semantic_roundtrip_audit': se['semantic_roundtrip_audit'],
            'fake_closure_scan': {'kind': 'Reuse genuine original independent sanitized scan and exact9e actual canonical root ASTIS success; no new scan/verdict', 'original_source_verifier': VERIFIER, 'existing_source_scan': se['fake_closure_scan'], 'actual_root_ASTIS_success_at': CORE, 'actual_source_bytes_unchanged': True},
            'local_acceptance_scope': 'Only actual sameO d>=2,kappa>=2 pointwise bidirectional precision replies/reference condition number2 and real two-hidden-input consumer, canonical Registry617 and source/Lean/site/formal/typed graphs at1440/390. Internal matrix identity is a proof component, not a separately exported theorem; ASTIS proof parents empty and standard APIs disclosed.',
            'truth_boundary': 'Local lease release only. No Gaussian target/covariance/TV, spectral/PD/normalizer, adaptive seed/transcript/output, deterministic/expected/precision/bit-cost adapter or either complete main lower bound. Typed bridge remains nonformal/dashed candidate reuse, strict2T<n determinant information law only. Remote publication/merge/public availability, purification/Seal/full paper/whole Goal are separate and incomplete.',
            'external_UI_boundary': 'External GitHub HTMLfalse/publicsourcefalse and own-site externalURLcheck null/notexecuted retained. Local module/download/immutableGit actual bytes checked. q+focus/native clicks readable; optional code/longconcept formula localhscroll, no manualtouch/wholeatlas-at-once claim.',
            'new_mathematical_source_or_semantic_verdict': False, 'remote_or_other_queue_mutation': False,
            'reclaim_rule': 'Any later integration/publication needs a later authorized normal STABILIZING claim.',
        }
        request = {'advance_id': ADV, 'to_state': 'VERIFIED', 'worker_id': ACTOR, 'modes': ['mechanical-existing-verification-parking', 'release-local-integration-lease-after-local-acceptance'], 'evidence': evidence}
        put(REQUEST, request)
        preflight = {'core': CORE, 'source_digest': DIGEST, 'authorization': desc(AUTH), 'request': desc(REQUEST), 'ledger_prefix': archive(OUT / 'before-parking-ledger-prefix.raw.jsonl.gz', before), 'foreign_states': archive(OUT / 'before-parking-foreign-states.json.gz', canon(foreign)), 'all_frontier_hashes': archive(OUT / 'before-parking-frontier-hashes.json.gz', canon(frontier_hashes())), 'entire_source_evidence_hashes': archive(OUT / 'before-parking-source-evidence-hashes.json.gz', canon(hashes(SOURCE))), 'discovery_raw_sha256': sha(DISC.read_bytes()), 'audit_raw_sha256': sha(AUDIT.read_bytes()), 'own_frontier_raw_sha256': sha(CELL.read_bytes()), 'proof_owner': PROOF, 'original_source_verifier': VERIFIER, 'normal_API_invocations': 0, 'normal_API_not_yet_invoked': True}
        put(PREFLIGHT, preflight)
        print(json.dumps({'status': 'PREPARED_NO_LIFECYCLE_MUTATION', 'request': desc(REQUEST), 'preflight': desc(PREFLIGHT), 'actual_API_calls': 0})); return

    assert REQUEST.exists() and PREFLIGHT.exists(), 'Missing concrete authorized preparation'
    pre = obj(PREFLIGHT); request = obj(REQUEST)
    assert sha(REQUEST.read_bytes()) == pre['request']['raw_sha256'] and sha(AUTH.read_bytes()) == pre['authorization']['raw_sha256']
    before = LEDGER.read_bytes(); assert before == unpack(pre['ledger_prefix'])
    foreign = json.loads(unpack(pre['foreign_states']))
    assert {k: v for k, v in a.current_advances().items() if k != ADV} == foreign
    assert a.current_advances()[ADV]['state'] == 'STABILIZING'
    assert hashes(SOURCE) == json.loads(unpack(pre['entire_source_evidence_hashes']))
    assert frontier_hashes() == json.loads(unpack(pre['all_frontier_hashes'])) and sha(DISC.read_bytes()) == pre['discovery_raw_sha256']
    put(ATTEMPT, {'actor': ACTOR, 'advance_id': ADV, 'request': desc(REQUEST), 'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'allowed_normal_API_invocations': 1, 'retry_rule': 'Never automatically retry after this persisted guard, including rejection or partial append.'})
    stream = io.StringIO(); error = None; start = time.monotonic()
    with contextlib.redirect_stdout(stream), contextlib.redirect_stderr(stream):
        try:
            a.transition_advance(ADV, to_state='VERIFIED', worker_id=ACTOR, modes=request['modes'], evidence=request['evidence'])
            print('The single normal API returned after its real reviewed publication/roundtrip gate. No new source verdict/build/browser run.')
        except Exception:
            error = traceback.format_exc(); print(error)
    rawlog = stream.getvalue().encode(); log = OUT / 'local-integration-parking.normal-api.log'
    assert not log.exists(); log.write_bytes(rawlog)
    after = LEDGER.read_bytes(); prefix_ok = after.startswith(before); append = after[len(before):] if prefix_ok else b''
    receipt = {'actual_API': 'tools.astis_advance.transition_advance', 'actual_API_invocations': 1, 'actor': ACTOR, 'request': desc(REQUEST), 'elapsed_seconds': time.monotonic() - start, 'exit_code': 1 if error else 0, 'error': error, 'core_before': CORE, 'head_after': head(), 'raw_stdout': desc(log), 'raw_stdout_lossless_gzip': archive(OUT / 'local-integration-parking.normal-api.log.gz', rawlog), 'ledger_before_sha256': sha(before), 'ledger_after_sha256': sha(after), 'original_prefix_preserved': prefix_ok, 'append_bytes': len(append), 'append_sha256': sha(append), 'original_source_verifier_retained': VERIFIER, 'new_source_or_math_verdict': False}
    put(RECEIPT, receipt)
    if error:
        print(json.dumps({'status': 'API_REJECTED_STOP_NO_RETRY', 'receipt': desc(RECEIPT), 'actual_append_bytes': len(append)})); sys.exit(1)
    try:
        assert prefix_ok and len(append.splitlines()) == 1
        event = json.loads(append)
        assert event['advance_id'] == ADV and event['from_state'] == 'STABILIZING' and event['to_state'] == 'VERIFIED' and event['worker_id'] == ACTOR and event['evidence'] == request['evidence']
        states = a.current_advances()
        assert states[ADV]['state'] == 'VERIFIED' and states[ADV]['owner_id'] == PROOF and states[ADV]['latest_evidence']['original_source_verifier_id'] == VERIFIER
        assert {k: v for k, v in states.items() if k != ADV} == foreign and not [k for k, v in states.items() if v['state'] == 'STABILIZING']
        assert LEDGER.read_bytes() == after and sha(DISC.read_bytes()) == pre['discovery_raw_sha256']
        assert sha(AUDIT.read_bytes()) == pre['audit_raw_sha256'] and sha(CELL.read_bytes()) == pre['own_frontier_raw_sha256']
        assert hashes(SOURCE) == json.loads(unpack(pre['entire_source_evidence_hashes'])) and frontier_hashes() == json.loads(unpack(pre['all_frontier_hashes']))
        common(auth_hash)
    except Exception:
        put(OUT / 'local-integration-parking.postcondition-failure.json', {'actual_normal_API_returned': True, 'error': traceback.format_exc(), 'receipt': desc(RECEIPT), 'rule': 'One API may already have appended. Do not retry or roll back; retain evidence and STOP.'}); raise
    exact = OUT / 'local-integration-parking.exact-append.jsonl'
    assert not exact.exists(); exact.write_bytes(append)
    archive(OUT / 'local-integration-parking.exact-append.jsonl.gz', append)
    protection = {'original_prefix_preserved': True, 'exact_normal_append_events': 1, 'exact_append_sha256': sha(append), 'ledger_after_sha256': sha(after), 'foreign_states_unchanged': 280, 'all_frontier_files_byte_unchanged': len(json.loads(unpack(pre['all_frontier_hashes']))), 'own_frontier_byte_unchanged': True, 'source_phase1_3_and_all_source_evidence_unchanged': len(json.loads(unpack(pre['entire_source_evidence_hashes']))), 'discoveries_unchanged': pre['discovery_raw_sha256'], 'accepted_audit_unchanged': pre['audit_raw_sha256'], 'original_seven_shared_after_bytes_unchanged': True, 'only_preapproved_functor_scalar_exception_remains94b56': True, 'other_protected_content_inputs_unchanged': 6523, 'other_protected_git_objects_unchanged': 122504, 'oldGC_evidence_Atlas_unchanged': True, 'proof_owner_preserved': PROOF, 'original_source_verifier_preserved': VERIFIER, 'actual_empty_STAB_after': []}
    pp = OUT / 'local-integration-parking.protection.json'; put(pp, protection)
    summary = {'actor': ACTOR, 'operation': 'Exactly one explicitly authorized normal API STABILIZING to EXISTING VERIFIED local lease parking/release', 'core': CORE, 'authorization': desc(AUTH), 'actual_API_receipt': desc(RECEIPT), 'protection': desc(pp), 'final_state': 'VERIFIED', 'proof_owner_preserved': PROOF, 'original_source_verdict_originator_preserved': VERIFIER, 'source_checked_commit': CHECKED, 'source_checked_tree_audit_still_blind': True, 'first_accepted_metadata_commit': ACCEPTED, 'accepted_audit_raw_sha256': sha(AUDIT.read_bytes()), 'actual26_NEWimage_acceptance': desc(READER), 'unique_append_sha256': sha(append), 'ledger_after_sha256': sha(after), 'single_stabilization_lane': [], 'own_frontier_not_projected_here': True, 'new_math_source_semantic_verdicts': 0, 'new_compilation_browser_or_remote_runs': 0, 'remote_merge_purification_Seal_bothmainbounds_or_Goal_completion': False, 'remaining_boundaries': auth.get('remaining_boundaries', request['evidence']['truth_boundary']), 'writes_stopped_after_summary': True}
    sp = OUT / 'local-integration-release-summary.json'; put(sp, summary)
    archive(OUT / 'executed-parking-driver.py.gz', Path(__file__).read_bytes())
    print(json.dumps({'state': 'VERIFIED', 'actual_empty_STAB': [], 'normal_API_calls': 1, 'append_sha256': sha(append), 'ledger_after_sha256': sha(after), 'receipt_sha256': sha(RECEIPT.read_bytes()), 'protection_sha256': sha(pp.read_bytes()), 'summary_sha256': sha(sp.read_bytes()), 'new_source_verdicts': 0, 'writes_stopped': True}))

if __name__ == '__main__': main()
