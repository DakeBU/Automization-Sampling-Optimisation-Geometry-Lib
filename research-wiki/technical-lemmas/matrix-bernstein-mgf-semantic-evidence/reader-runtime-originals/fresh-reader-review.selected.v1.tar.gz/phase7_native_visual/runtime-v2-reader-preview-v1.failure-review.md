# Independent actual runtime and image review: reader-preview-v1

Reviewer: `mgf_fresh_source_5b7e`.
Decision: **Candidate runtime is not accepted; a versioned source-anchor repair and fresh actual run are required. No proof VERIFIED.**

Failure class: `IMPLEMENTATION_FAILED` in the isolated presentation layer. The failure is not mathematical refutation, not a source-invalid finding, and not a failure of the original Gaussian or Tropp statement.

## Exact run identities and order

This is the actual **browser runner v2** operating on **reader-preview-v1**, not the new proposed reader-preview-v2. Its identities are:

- Reader fixture manifest: `f2cbc9d412344fe2ec1d97a5c8bab21f83ffdc4d8e34d58d6f17e63d0d4e99c4`.
- Browser script v2: `294d579ae3baccdb301470ce44e5f2a35e785f24408e2fa90add5927c56cf6a9`.
- Browser contract v2: `51b8bfe8a542b90452373368e6e97d9848eb0762ef12a6d556e987d1c5e6ad82`.
- Original actual-checks: `2ae020338ae4a1c26ee7e0bc99617b6d01ec211bedcf59a8292a98e6478d27aa`.
- Candidate actual-checks: `84b42f82310555c37fa25e9c31585bd872eedbaefcd52ef3f918f5dd2f88a33b`.

The independent source/code/reader/semantic judgments and presentation-only static review were frozen first. The reporter-only v2 repair was independently checked and frozen next. Only then were actual v2 original records read, followed by candidate records after ROOT confirmed completion. ROOT was the actual process invoker. This reviewer did not run Chrome, restart or poll its sessions, run an API, modify fixtures/tests, or reconstruct flags.

Actual process receipts, stdout/stderr, check JSON and all 24 original/50 candidate PNGs were copied byte-for-byte into `originals/` after verifying their declared hashes. The old reporter-v1 failure and its originals remain separately preserved and are not rewritten as completed checks.

## Actual original result

Original finished with exit 1, `FAIL`, browser_started=true, process exception=null, and 24 screenshots. Its 15 recorded false checks are:

- Six absent adjacent source/copy/full-download groups on desktop and the same six on mobile.
- Mobile source-assumption table cannot reach its right side: recorded overflow visible, width331, scrollWidth431, requested scroll100 but actual0.
- Expanded mobile proof document body width460 exceeds the390 viewport.
- Google Fonts external requests are blocked under the localhost-only contract.

The baseline images independently show the absent action groups and the clipped right side of the mobile assumptions table. Main prose and formula typography are readable, but those observations do not erase the recorded baseline failures.

## Actual candidate result and uncovered execution

Candidate finished with exit 1, `FAIL`, browser_started=true, process exception=null, and 50 screenshots. The actual JSON has **228 checks and 12 false entries**, not14. The 12 are six per viewport:

1. step1 actual source navigation false;
2. proof-stage completion false after waiting for missing `#L1`;
3. P complete-source line coverage false;
4. P source-stage completion false after waiting for missing `#L46`;
5. T complete-source line coverage false;
6. T source-stage completion false after waiting for missing `#L21`.

`candidate-v2-actual-failures.json` preserves the actual names and tracebacks. There is no top-level reporter exception, so this is a completed real FAIL result rather than the earlier reporter-write failure.

The failure happens during step1 navigation and aborts the rest of that proof-stage block. The presence of later graph screenshots does not mean that the other five adjacent step controls, expanded table/formula containment or every source-copy/anchor check completed. Those missing observations cannot be promoted into passing flags. The actual records do support step1's P path, exact displayed-code clipboard comparison and exact full-module download before navigation fails; they do not establish every later step's runtime control.

The actual P/T `pre` text equality checks precede the failing source-anchor access and are true. This salvages the full source text's runtime bytes without salvaging line-anchor functionality. The candidate has no page-JavaScript error and no blocked external request in its actual check record, but silent successful JavaScript can still destroy required DOM structure.

## Independent source-backed failure mechanism

The causal attribution is supported by the original HTML, the actual loaded JS and the real missing-selector tracebacks:

1. The frozen generator emits original source text with `<span id="L1">...` through all P121/T159 lines.
2. `reader_overlay.py` function `enhance_source` wraps that span structure in `<code class="language-lean">` inside the original `pre`.
3. The unchanged actual `assets/site.js` function `highlightLean` selects every `code.language-lean` (line368), reads only its `textContent`, escapes/tokenizes the text, and assigns the rebuilt markup to `node.innerHTML` (line389).
4. That replacement creates syntax-token spans, not the original `id="L..."` line spans. It therefore discards the pre-existing line ids while retaining source text.
5. The real runner sees a source-navigation URL but no `#L1` anchor, then cannot find `#L46` or `#L21` on the source pages. Its screenshots remain at the file header/first lines rather than the requested theorem line.

This explains why static raw HTML/source-byte checks passed while runtime source navigation failed. It is an interaction defect between the new wrapper's highlighting class and the existing highlighter, not evidence of changed Lean mathematics or source text.

The same wrapper is applied to all six selected source modules. Thus the risk boundary includes the four parent-source line anchors as well as P/T. Graph parent-context URL/navigation checks that do not assert the physical target line cannot certify those anchors. A minimal repair must preserve the numbered span structure through highlighting or exclude the line-anchored full-source block from this destructive highlighting pass; step-level code highlighting and all actual source bytes must remain unchanged. No fixture, production or test was changed by this reviewer.

## Independent image observations

The exact personally viewed PNG list and file hashes are recorded in `viewed-images-and-observations.json`. I viewed16 original and24 candidate images; all74 are preserved, and the unviewed images are not represented as personally inspected.

Observed desktop/mobile facts:

- Initial proof prose, the main MGF display and the folded statement/proof hierarchy are legible in the selected desktop/mobile images. The phone's long formula is visibly a horizontally scrollable local display, so a clipped initial right end is not called a full-formula readability pass.
- Candidate source filenames and copy/download labels wrap readably on390px screens, but the P/T error screenshots show the file beginning instead of the requested theorem line. Good header typography does not make that navigation successful.
- The source index displays complete wrapped identifiers, including the private T qualification `associated private application; no public node`. It is a vertically scrolling list, not a claim that every entry fits in one phone viewport.
- Graph default fit is **not physically readable as full node labels**, on desktop or mobile. The tiny upper-right node cluster is an overview only. Actual zoom/pan makes glyphs large, but SVG labels retain ellipses and the mobile canvas clips wide nodes. Neither a font-size flag nor a large zoomed glyph is evidence that the full SVG identifier is visible.
- The actual detail inspector does show full wrapped identifiers and source paths/line metadata for P, its four selected mathematical adapters, and the T module in the viewed phone/detail images. The T item is shown as a module, not as a new private theorem node. The desktop legend visibly separates solid Lean structural edges from dashed curated evidence edges; source/detail subtitles keep publication/source acceptance separate. These support only a bounded **zoom-plus-detail inspection** claim, not default-fit/all-SVG-label readability or theorem implication from a reference.
- The full inspector/source metadata and source index are useful surviving presentation content, but their line-target navigation remains blocked by the missing ids. The whole candidate therefore remains unaccepted.

## Preserved mathematical boundary and next work

The source-facing math remains the exact real normalized single-matrix MGF and its original-law fixed +cos normalized private application, including natural negative cosine values, q=0 and all positive s. The failed browser fixture is not a reason to add mathematical hypotheses, change the source statement, reinterpret the integral, weaken the conclusion or discard existing proved/source-reviewed fragments.

The prior phase5 acceptance was explicitly static and pending actual runtime; it is preserved unchanged. The current report records the actual runtime failure separately. It does not approve the subsequently proposed reader-preview-v2 repair, which must receive its own exact static review before a new real browser attempt. No normal proof VERIFIED, main/site delivery, full source consumer, purification or whole-goal completion is authorized by this report.
