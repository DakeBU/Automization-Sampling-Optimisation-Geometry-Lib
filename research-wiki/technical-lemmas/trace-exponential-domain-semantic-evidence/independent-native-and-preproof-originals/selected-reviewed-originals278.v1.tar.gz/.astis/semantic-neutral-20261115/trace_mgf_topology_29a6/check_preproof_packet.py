"""Read-only identity/coverage/topology checks. No Lean proof or API retrieval."""

from pathlib import Path
from html.parser import HTMLParser
import hashlib
import json
import re

ROOT = Path('/Users/zhouhuanjian/ASTIS-GC')
OWN = ROOT / '.astis/semantic-neutral-20261115/trace_mgf_topology_29a6'
SG = ROOT / '.astis/semantic-neutral-20261115/trace_mgf_source_graph_4c71'
SEAL = ROOT / '.astis/huanjian-gc-trace-mgf-domain-20261115'


def read_json(path):
    return json.loads(path.read_text())


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


pins = {
    SEAL / 'statement-seal.sealed.v1.json': 'baac7a9074f869cdd98c6a027176f7d33ec7531c60f0a4709f0fc01bf81ee04d',
    SEAL / 'binder-definition-audit.sealed.v1.json': '91eac9f3b05eacda20780fb44456b5398bb1211ab92e3b8eb4246ebba71ac5c5',
    SEAL / 'norm-scope-seal-supplement.v1.json': '8bfdff76c638b419b502c667fcc3959fee50532f46a28e9df5fb45d846e97fd5',
    SG / 'phase1/PHASE1-FROZEN.json': 'ea810b7b2ee6628357fbcba9cb7f8791bb1885a0a0935eca2153310ccd019fc7',
    SG / 'capsule.json': '175691dc92a65c07bab73b26448fd36ae5882979a502ebe917a67d3d8895fcf5',
    ROOT / '.astis/semantic-neutral-20261113/bernstein_raw_intake_74ab/Tro11-User-Friendly-preprint.pdf': 'f4c3cff8661011395e793972a1f8d9a199fae4ca0fd098535d7a42166cf8fc86',
    ROOT / '.astis/huanjian-handoff-20261019/2610.20492v1.html': '6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915',
    OWN / 'raw-first-freeze.v1.json': 'b43481c4809d308cc0a326552d2d48ecd92ef421a3a122dce6df0564d1bf432b',
}
pin_results = [{'path': str(p.relative_to(ROOT)), 'expected_sha256': h,
                'actual_sha256': digest(p), 'matches': digest(p) == h}
               for p, h in pins.items()]
assert all(x['matches'] for x in pin_results)

freeze = read_json(SG / 'phase1/PHASE1-FROZEN.json')
phase1_results = [{'path': x['path'], 'matches': digest(SG / 'phase1' / x['path']) == x['sha256']}
                  for x in freeze['files']]
assert all(x['matches'] for x in phase1_results)

seal = read_json(SEAL / 'statement-seal.sealed.v1.json')
script = (SEAL / 'StatementNormScopeAudit.lean').read_text()
formation = (SEAL / 'InterfaceFormation.v2.lean').read_text()
body_p = script.split('def CandidateP : Prop :=\n', 1)[1].split('\ndef CandidateT : Prop :=', 1)[0].strip()
body_t = script.split('def CandidateT : Prop :=\n', 1)[1].split('\n#check CandidateP', 1)[0].strip()
same_propositions = {
    'P': body_p == seal['canonical_producer']['exact_proposition'].strip(),
    'T': body_t == seal['private_real_consumer']['exact_proposition'].strip(),
    'formation_body_same_as_diagnostic': formation.split('#check CandidateP')[0] == script.split('#check CandidateP')[0],
    'P_signature_digest_matches': hashlib.sha256(seal['canonical_producer']['exact_proposition'].encode()).hexdigest() == seal['canonical_producer']['sha256'],
    'T_signature_digest_matches': hashlib.sha256(seal['private_real_consumer']['exact_proposition'].encode()).hexdigest() == seal['private_real_consumer']['sha256'],
}
assert all(same_propositions.values())
supplement = read_json(SEAL / 'norm-scope-seal-supplement.v1.json')
log_path = Path(supplement['actual_elaboration']['raw_stdout_stderr_log'])
log = log_path.read_text()
receipt = read_json(ROOT / supplement['actual_elaboration']['receipt'])
norm_checks = {
    'script_digest': digest(SEAL / 'StatementNormScopeAudit.lean') == supplement['statement_only_audit']['sha256'],
    'formation_digest': digest(SEAL / 'InterfaceFormation.v2.lean') == supplement['formation_context']['sha256'],
    'log_digest': digest(log_path) == supplement['actual_elaboration']['raw_log_sha256'],
    'receipt_digest': digest(ROOT / supplement['actual_elaboration']['receipt']) == supplement['actual_elaboration']['receipt_sha256'],
    'receipt_exit_zero': receipt['exit_code'] == 0,
    'full_print_and_synth_l2_operator': log.count('@Matrix.instL2OpNormedRing.') == 2,
    'script_contains_only_candidate_Prop_definitions_and_print_synth': len(re.findall(r'^def ', script, re.M)) == 2 and not re.search(r'^(?:theorem|lemma|axiom|instance)\b|\bsorry\b|\badmit\b', script, re.M),
}
assert all(norm_checks.values())

graph = read_json(SG / 'phase1/source-proof-graph.json')
coverage = read_json(SG / 'phase1/coverage-inventory.json')
ids = [n['id'] for n in graph['nodes']]
inventory_ids = [n['id'] for n in coverage['items']]
assert len(ids) == len(set(ids)) and len(inventory_ids) == len(set(inventory_ids))
unmatched_edges = [x for e in graph['edges'] for x in [e['to'], *e['from']] if x not in ids]
assert not unmatched_edges
adj = {x: set() for x in ids}
for e in graph['edges']:
    for source in e['from']:
        adj[source].add(e['to'])
visiting, visited = set(), set()


def dfs(x):
    assert x not in visiting, f'cycle at {x}'
    if x in visited:
        return
    visiting.add(x)
    for y in adj[x]:
        dfs(y)
    visiting.remove(x)
    visited.add(x)


for x in ids:
    dfs(x)


class RawC2Inventory(HTMLParser):
    voids = set('area base br col embed hr img input link meta param source track wbr'.split())

    def __init__(self):
        super().__init__()
        self.stack = []
        self.items = []
        self.group_members = {}

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag not in self.voids:
            self.stack.append((tag, attrs))
        if not any(x.get('id') == 'A3.SS2' for _, x in self.stack):
            return
        source_id = attrs.get('id', '')
        if tag == 'p' and source_id:
            self.items.append({'id': 'G:' + source_id, 'kind': 'raw-paragraph'})
        elif re.fullmatch(r'A3\.Ex\d+', source_id):
            self.items.append({'id': 'G:' + source_id, 'kind': 'raw-display-or-subdisplay'})
            groups = [x['id'] for _, x in self.stack if x.get('id', '').startswith('A3.EGx')]
            if groups:
                self.group_members.setdefault(groups[-1], []).append(source_id)
        elif tag == 'a' and attrs.get('class', '').split().count('ltx_ref') and attrs.get('href', '').startswith('#'):
            paragraph = next((x.get('id') for t, x in reversed(self.stack) if t == 'p'), None)
            if paragraph:
                self.items.append({'id': 'G:' + paragraph + ':ref', 'kind': 'raw-internal-citation', 'href': attrs['href']})

    def handle_endtag(self, tag):
        for i in range(len(self.stack) - 1, -1, -1):
            if self.stack[i][0] == tag:
                self.stack = self.stack[:i]
                break


raw = RawC2Inventory()
raw.feed((ROOT / '.astis/huanjian-handoff-20261019/2610.20492v1.html').read_text())
for x in raw.items:
    if x['kind'] == 'raw-internal-citation':
        matches = [n for n in coverage['items'] if n['id'].startswith(x['id'])]
    else:
        matches = [n for n in coverage['items'] if n['id'] == x['id']]
    x['matches'] = [{'inventory_id': n['id'], 'disposition': n['disposition'], 'reason': n.get('reason')}
                    for n in matches]
    assert len(matches) == 1, x

inventory_nodes = {n['id'] for n in coverage['items'] if n['disposition'] == 'NODE'}
graph_nongaps = {n['id'] for n in graph['nodes'] if n['kind'] != 'SOURCE_GAP'}
assert inventory_nodes == graph_nongaps
result = {
    'status': 'IDENTITY_AND_STRUCTURAL_CHECKS_PASS_NOT_A_MATHEMATICAL_PROOF',
    'pinned_identity': pin_results,
    'phase1_frozen_file_digests': phase1_results,
    'exact_Prop_formation_comparison': same_propositions,
    'actual_norm_raw_script_stdout_receipt_checks': norm_checks,
    'graph_structure': {'nodes': len(ids), 'edges': len(graph['edges']), 'acyclic': True,
                        'missing_edge_endpoints': unmatched_edges,
                        'inventory_NODE_set_equals_graph_non_gap_node_set': True,
                        'source_gap_ids': [n['id'] for n in graph['source_gaps']]},
    'coverage_count_recalculated': {'total': len(coverage['items']),
                                  'NODE': sum(n['disposition'] == 'NODE' for n in coverage['items']),
                                  'EXCLUDED': sum(n['disposition'] == 'EXCLUDED' for n in coverage['items'])},
    'independent_raw_C2_reconciliation': {'items': raw.items, 'equationgroup_expands_to_subdisplays': raw.group_members},
    'human_review_still_required': ['raw-source mathematical coverage', 'edge use-site semantics',
                                   'sufficient OR-route completeness', 'binder and definition meaning'],
    'not_done': ['No Lean theorem compilation', 'No target proof or API search', 'No git or ledger operations'],
}
(OWN / 'identity-coverage-structure-checks.v1.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'status': result['status'], 'graph_structure': result['graph_structure'],
                  'coverage_count': result['coverage_count_recalculated'],
                  'raw_C2_items_reconciled': len(raw.items)}, ensure_ascii=False))
