#!/usr/bin/env python3
"""Bounded private preparation only. Never applies a shared file or invokes lifecycle APIs."""
import sys
sys.dont_write_bytecode = True
import difflib
import gzip
import hashlib
import json
import subprocess
from pathlib import Path

R = Path('/Users/zhouhuanjian/ASTIS-GC')
O = Path(__file__).resolve().parent
CANDIDATE = '37645c774481c4cad19fc29bcaa76799da64db7d'
MAIN = '4f0e6584e26dc5226957f23108f0c2309296e0c5'
BASE = 'd9bcd4231df69061c5221f8d557ee179a945c1eb'
MOD = 'AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumCosineExpansion'
DECL = MOD + '.actual_inverse_spectrum_cosine_expansion'
A1MOD = 'AutoSamplingTheory.ExampleCases.GaussianComplexity.SphericalPoisson'
ADV = 'ASTIS-SA-20261109-GaussianComplexityFixedSpectrumCosineExpansion'
DISC = 'ASTIS-DISC-20261109-GaussianComplexityPoissonCosineMirror'
E = 'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-cosine-expansion-semantic-evidence/'
P = '.astis/huanjian-gc-fixed-spectrum-moments-20261109/poisson-mirror-independent-review/v1/'
FH = 'website/content/functor_hypergraph.json'
GM = 'website/content/graph_memory_index.json'
JS = 'website/static/underlying-lean-graph.js'
CASE = 'website/content/samplewiki_companion_frontiers.json'
PROD = 'AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumCosineExpansion.lean'
TEST = 'Tests/GaussianComplexityFixedSpectrumCosineExpansion.lean'
BINDING = '8ddbbdb086becb57b2b8212154d9f607b121f7955cfcce132927210eaa04b95c'

def sh(*args):
    return subprocess.check_output(args, cwd=R)

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def read(path):
    return (R / path).read_bytes()

def dump(rel, value):
    p = O / rel
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

def blob(rel, raw):
    p = O / rel
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(gzip.compress(raw, mtime=0))
    assert gzip.decompress(p.read_bytes()) == raw
    return {'archive': rel, 'raw_sha256': sha(raw), 'raw_bytes': len(raw),
            'archive_sha256': sha(p.read_bytes()), 'CRLF': raw.count(b'\r\n'),
            'lone_LF': raw.count(b'\n') - raw.count(b'\r\n')}

def json_spans(raw):
    """Token spans in characters; untouched text is retained, never reserialized."""
    s = raw.decode('utf-8')
    dec = json.JSONDecoder()
    spans = {}
    def ws(i):
        while i < len(s) and s[i].isspace(): i += 1
        return i
    def node(i, path):
        i = ws(i)
        start = i
        if s[i] == '{':
            i = ws(i + 1)
            if s[i] != '}':
                while True:
                    key, j = dec.raw_decode(s, i)
                    i = ws(j)
                    assert s[i] == ':'
                    i = ws(node(i + 1, path + (key,)))
                    if s[i] == '}': break
                    assert s[i] == ','
                    i = ws(i + 1)
            end = i + 1
        elif s[i] == '[':
            i = ws(i + 1)
            n = 0
            if s[i] != ']':
                while True:
                    i = ws(node(i, path + (n,)))
                    n += 1
                    if s[i] == ']': break
                    assert s[i] == ','
                    i = ws(i + 1)
            end = i + 1
        else:
            _, end = dec.raw_decode(s, i)
        spans[path] = (start, end)
        return end
    end = node(0, ())
    assert not s[end:].strip()
    assert json.loads(s) == dec.decode(s)
    return s, spans

def replace_token(raw, path, value):
    s, sp = json_spans(raw)
    a, b = sp[path]
    text = json.dumps(value, ensure_ascii=False)
    out = (s[:a] + text + s[b:]).encode()
    new_s, new_sp = json_spans(out)
    na, nb = new_sp[path]
    assert (new_s[:na] + s[a:b] + new_s[nb:]).encode() == raw
    return out

def append_array(raw, path, values):
    before = json.loads(raw)
    target = before
    for k in path: target = target[k]
    assert isinstance(target, list) and target
    s, sp = json_spans(raw)
    _, pos = sp[path + (len(target)-1,)]
    indent = 2 * (len(path) + 1)
    parts = []
    for value in values:
        parts.append('\n'.join(' ' * indent + line for line in json.dumps(value, ensure_ascii=False, indent=2).splitlines()))
    insertion = ',\n' + ',\n'.join(parts)
    out = (s[:pos] + insertion + s[pos:]).encode()
    assert (out.decode()[:pos] + out.decode()[pos+len(insertion):]).encode() == raw
    result = json.loads(out)
    t = result
    for k in path: t = t[k]
    assert t == target + values
    return out

def append_mapping(raw, path, additions):
    obj = json.loads(raw)
    for k in path: obj = obj[k]
    assert isinstance(obj, dict) and obj and not (set(obj) & set(additions))
    s, sp = json_spans(raw)
    _, pos = sp[path + (next(reversed(obj)),)]
    interior = json.dumps(additions, ensure_ascii=False, indent=2).splitlines()[1:-1]
    # JSON's first two spaces already represent the dictionary's own level.
    insertion = ',\n' + '\n'.join(' ' * (2*len(path)) + line for line in interior)
    out = (s[:pos] + insertion + s[pos:]).encode()
    assert (out.decode()[:pos] + out.decode()[pos+len(insertion):]).encode() == raw
    after = json.loads(out)
    for k in path: after = after[k]
    assert after == {**obj, **additions}
    return out

def changes(a, b, path=()):
    if type(a) != type(b): return [list(path)]
    if isinstance(a, dict):
        out = []
        for k in sorted(set(a) | set(b)):
            out += [list(path+(k,))] if k not in a or k not in b else changes(a[k], b[k], path+(k,))
        return out
    if isinstance(a, list):
        out = []
        for k in range(max(len(a),len(b))):
            out += [list(path+(k,))] if k >= len(a) or k >= len(b) else changes(a[k],b[k],path+(k,))
        return out
    return [] if a == b else [list(path)]

assert sh('git','rev-parse','HEAD').decode().strip() == CANDIDATE
assert not sh('git','status','--porcelain=v1','--untracked-files=no')
assert sh('git','merge-base',CANDIDATE,MAIN).decode().strip() == BASE
assert read(PROD) == sh('git','show',CANDIDATE+':'+PROD)
assert sha(read(PROD)) == '659d6baf40abad2c48e7fced98c6c46a07624817cf14ef2de5a8146e82522de7'
assert sha(read(TEST)) == '7deb7539b72061b79b82865a956ac6560f505884d4fcb3ebba92a3d5f58d4759'
audit = json.loads(read('research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-cosine-expansion.json'))
assert audit['state'] == 'blind-reconstructed' and audit['verdict'] == 'pending'
assert audit['publication_binding_sha256'] == BINDING
ledger = read('runs/substantive_advances.jsonl')
own = [json.loads(x) for x in ledger.splitlines() if json.loads(x).get('advance_id') == ADV]
assert own[-1]['to_state'] == 'PROVED_LOCAL'
assert not any(r.get('to_state') in ('VERIFIED','STABILIZING','MERGED') for r in own)

# Existing conceptual validation is real, distinct from the still absent source V.
candidate_raw = read(E+'poisson-cosine-mirror-candidate-v1.json')
assert sha(candidate_raw) == 'bcd24a72d1409f6b0b6747d85116d3317cb51c0d0612d5789d0affd5b317cd1e'
meta = json.loads(candidate_raw)['metadata']
validation = json.loads(read(P+'validation-execution/execution-receipt.json'))
append = read(P+'validation-execution/append.jsonl')
disc_before = read(P+'validation-execution/discovery-ledger.before.jsonl')
disc_current = read('runs/substantive_discoveries.jsonl')
assert validation['api_calls'] == 1 and validation['actor'] == '/root/cosine_topology_challenge'
assert validation['result'] == 'VALIDATED_CONCEPTUAL_ONLY'
assert validation['source_V_or_Lean_or_Goal_credit'] is False
assert sha(append) == validation['append_sha256'] == '2df032e4ca73519ff924dc076a237e84f81a713b0ede6d35f190308fd4dab3d9'
assert disc_current == disc_before + append
assert sha(disc_current) == validation['after_sha256']
event = json.loads(append)
assert event['discovery_id'] == DISC and event['to_status'] == 'validated'
assert event['actor'] == validation['actor'] and event['actor'] != own[-1]['worker_id']

# Stage A: expected bytes after a FUTURE REAL merge; never a substitute for ancestry.
incoming = sh('git','diff','--name-only',BASE,MAIN).decode().splitlines()
branch_changes = set(sh('git','diff','--name-only',BASE,CANDIDATE).decode().splitlines())
overlap = sorted(set(incoming) & branch_changes)
assert len(incoming) == 22 and overlap == [FH, JS]
merge_preview = sh('git','merge-tree',BASE,CANDIDATE,MAIN)
assert b'<<<<<<<' not in merge_preview and b'>>>>>>>' not in merge_preview
candidate_paths = set(sh('git','ls-tree','-r','--name-only',CANDIDATE).decode().splitlines())
main_rows = []
reconciled = {}
for i, path in enumerate(incoming):
    m = sh('git','show',MAIN+':'+path)
    c = sh('git','show',CANDIDATE+':'+path) if path in candidate_paths else None
    row = {'path':path, 'main':blob('stage-A/main/%02d.raw.gz'%i,m),
           'candidate':blob('stage-A/candidate/%02d.raw.gz'%i,c) if c is not None else None,
           'merge_strategy':'combine disjoint hunks, preserving both histories' if path in overlap else 'take exact incoming-main blob'}
    if path == FH:
        cs, cp = json_spans(c); ms, mp = json_spans(m)
        cd, md = json.loads(c),json.loads(m)
        ci = next(j for j,o in enumerate(cd['objects']) if o['id']=='concept:lower')
        mi = next(j for j,o in enumerate(md['objects']) if o['id']=='concept:lower')
        a,b = cp[('objects',ci)]; x,y = mp[('objects',mi)]
        r = (cs[:a]+ms[x:y]+cs[b:]).encode()
        assert changes(cd,json.loads(r)) == [['objects',ci,'label'],['objects',ci,'url']]
        assert (r.decode()[:a]+cs[a:b]+r.decode()[a+len(ms[x:y]):]).encode() == c
        assert json.loads(r)['objects'][ci] == md['objects'][mi]
    elif path == JS:
        old = b'"concept:lower":"Lower bounds / SampleWiki"'
        new = b'"concept:lower":"Lower Bounds"'
        assert c.count(old) == 1
        r = c.replace(old,new)
        assert r.replace(new,old) == c
        assert r.count(b'fit({readable:true})') == c.count(b'fit({readable:true})')
        assert b'if (state.query) requestAnimationFrame(()=>fit({readable:true}));' in r
        assert b'requestAnimationFrame(()=>fit({readable:true}))' in r
    else:
        r = m
    reconciled[path] = r
    if path in overlap:
        row['reconciled'] = blob('stage-A/reconciled/%02d.raw.gz'%i,r)
    row['expected_merged_raw_sha256'] = sha(r)
    main_rows.append(row)
dump('stage-A/reconciliation-manifest.json',{'candidate':CANDIDATE,'main':MAIN,'merge_base':BASE,
     'actual_merge_performed':False,'required_later_action':'sole stabilization owner performs a real git merge of main, retaining main ancestry; compare resulting raw blobs to this conditional preview',
     'incoming_paths':len(incoming),'main_only_paths':20,'overlap':overlap,
     'merge_tree':blob('stage-A/three-argument-merge-tree.raw.gz',merge_preview),
     'text_conflict_markers_found':False,'rows':main_rows})

# Concrete conceptual model additions faithfully copy the independently reviewed payload.
review = {
 'status':'independently-reviewed',
 'proposed_by':'huanjian_gc_20261109_fixed_spectrum_cosine_expansion',
 'independent_reviewer':'/root/cosine_topology_challenge',
 'discovery_id':DISC,
 'evidence':[E+'poisson-cosine-mirror-candidate-v1.json',P+'review.md',P+'validation-execution/execution-receipt.json',P+'validation-execution/append.jsonl'],
 'raw_proposal_sha256':sha(candidate_raw),
 'review_sha256':sha(read(P+'review.md')),
 'validation_receipt_sha256':sha(read(P+'validation-execution/execution-receipt.json')),
 'validation_append_sha256':sha(append),
 'scope':'Existing independent conceptual-only review and one actual normal discovery validation. No C7 source V, new A1 source verdict, Lean implication, circle/sign/measure certificate, Gaussian expectation or functor certification. Raw candidate pending labels remain historical.'}
bridge = {
 'id':meta['bridge_id'], 'label':'Poisson boundary reproduction / cosine inverse spectrum',
 'family_ids':[meta['family_id']], 'tails':[meta['domains'][0]], 'heads':[meta['domains'][1]],
 'relation_kind':'source-backed conceptual kernel correspondence; missing circle, pole and measure adapters',
 'status':'not-Lean-certified', 'formula':meta['formula'], 'mechanism':meta['mechanism'],
 'hypothesis_map':meta['hypothesis_map'], 'conclusion_map':meta['conclusion_map'],
 'failure_boundary':meta['failure_boundary'], 'source_ids':meta['source_ids'],
 'critical_estimates':meta['key_estimate'], 'source_mapping':meta['source_map'],
 'shared_stages':['measure','linear-algebra'], 'formal_refs':[],
 'url':'example-cases/samplewiki/companions/gaussian-sampling-complexity.html', 'review':review,
 'category_contract':{
  'objects':'Normalized boundary harmonic data and the scalar cosine inverse spectrum; auxiliary circle dimension2 is distinct from Gaussian ambient dimension d.',
  'morphisms':'Conceptual Poisson-kernel reading only. Angular/surface measure identification and positive-to-negative-pole rotation are missing adapters; no compiled morphism is assigned.',
  'identity':'No identity-law certificate or Lean-certified functor.',
  'composition':'No composition-law certificate; no composition into finite-grid aliases, Gaussian moments, oracle/TV/cost or either main bound.'}}
domains = [
 {'id':meta['domains'][0], 'label':'Poisson boundary harmonics',
  'space':'Normalized surface measure on S^(n-1), interior positive pole r e1, harmonic functions1 and x1',
  'energy':'Poisson reproduction and raw reciprocal-power spherical moments; multiply by1-r^2 for normalized kernel moments',
  'assumptions':'0<r<1; retain raw A1 n>=2/n>=3 ambiguity, existing n=2 extension and arbitrary-harmonic HFT-route source debt',
  'url':'example-cases/samplewiki/companions/gaussian-sampling-complexity.html'},
 {'id':meta['domains'][1], 'label':'Cosine inverse spectrum',
  'space':'Every real angle for fixed real kappa>=2, r=(sqrt(kappa)-1)/(sqrt(kappa)+1); auxiliary circle interpretation, not Gaussian dimension d',
  'energy':'Literal reciprocal spectrum and its absolutely and uniformly convergent positive cosine modes',
  'assumptions':'Uniform in theta only for fixed kappa. Negative-pole/angle and angular-surface adapters are uncertified; d-point grid aliases and C8 finite corrections are separate',
  'url':'example-cases/samplewiki/companions/gaussian-sampling-complexity.html'}]
family = {
 'id':meta['family_id'], 'label':'Poisson representation across boundary harmonics and cosine modes',
 'plain_language':'One normalized kernel mechanism relates boundary-harmonic reproduction to the scalar inverse-spectrum cosine expansion, after explicit sign, circle and measure adapters.',
 'domains':meta['domains'], 'functor_edges':[meta['bridge_id']],
 'formal_search_nodes':[A1MOD,MOD],
 'compiled_substrate_bindings':[
  {'node':A1MOD,'edges':[meta['bridge_id']],
   'role':'Existing source-present concrete spherical moments; canonical module search substrate only.',
   'truth_boundary':'Dashed conceptual incidence only. Preserve existing A1 source-underspecified n>=2/n>=3 ambiguity, disclosed n=2 extension and arbitrary-harmonic HFT-route debt. Raw moments need1-r^2 normalization; no negative-pole, circle-measure or C7 proof implication.',
   'declaration':A1MOD+'.spherical_poisson_moments',
   'evidence':[{'path':'AutoSamplingTheory/ExampleCases/GaussianComplexity/SphericalPoisson.lean','raw_sha256':sha(read('AutoSamplingTheory/ExampleCases/GaussianComplexity/SphericalPoisson.lean'))}]},
  {'node':MOD,'edges':[meta['bridge_id']],
   'role':'Current locally compiled scalar C7 and genuine private finite-grid interchange; canonical module search substrate only.',
   'truth_boundary':'Dashed conceptual incidence only, not a formal parent or certified transport. C7 has zero direct public ASTIS parents; its private Test has only C7. Fixed-kappa convergence does not evaluate grid aliases or Gaussian expectations; no C7 source V is asserted by this conceptual binding.',
   'declaration':DECL,
   'evidence':[{'path':PROD,'raw_sha256':sha(read(PROD))},{'path':TEST,'raw_sha256':sha(read(TEST))}]}],
 'reading_order':['A1 raw statement ambiguity and normalized surface measure','Multiply the two raw moments by1-r^2','C7 geometric series, exact1/sqrt(kappa) normalization and fixed-kappa uniformity','Missing auxiliary-circle, pole and measure adapters','Private finite-grid interchange; retain C8 alias corrections and later Gaussian/moment boundaries'],
 'do_not_conflate':meta['failure_boundary'], 'review':review}
sources = {}
for sid, anchor, title in zip(meta['source_ids'],['A1.SS1','A3.Thmtheorem7','A3.SS3.p4.2'],['Lemma A.1 Poisson representation and raw spherical moments','Fact C.7 scalar inverse-spectrum cosine expansion','C.8 finite-grid series-interchange source step']):
    sources[sid] = {'title':'Zhou–Suzuki, On Complexity of Gaussian Sampling: '+title,
      'url':'https://arxiv.org/html/2610.20492v1#'+anchor,'anchor':sid.split(':',1)[1],
      'version':'arXiv2610.20492v1','source_snapshot_sha256':meta['source_snapshot_sha256'],
      'truth_boundary':'Conceptual source catalog, not a new publication binding, source verdict or completed downstream theorem.'}

payloads = []
full_diff = []
def payload(path, before, after, why):
    assert before != after
    row={'path':path,'why':why,'baseline':'expected real-main-reconciled bytes' if path==FH else 'current mathematical candidate bytes',
         'before':blob('stage-B/before/%02d.raw.gz'%len(payloads),before) if before is not None else None,
         'after':blob('stage-B/after/%02d.raw.gz'%len(payloads),after)}
    if path.endswith('.json'):
        row['changed_json_paths']=changes(json.loads(before),json.loads(after))
    payloads.append(row)
    full_diff.extend(difflib.unified_diff((before or b'').decode().splitlines(keepends=True),after.decode().splitlines(keepends=True),
                     fromfile='a/'+path if before is not None else '/dev/null',tofile='b/'+path))

for path,prefix in [('AutoSamplingTheory.lean','AutoSamplingTheory.ExampleCases.GaussianComplexity.'),('Tests.lean','Tests.GaussianComplexity'),('AutoSamplingTheory/TechnicalLemmas/Registry.lean','AutoSamplingTheory.ExampleCases.GaussianComplexity.')]:
    b=read(path)
    old=('import '+prefix+'FixedSpectrumGeometry\n').encode()
    new=('import '+prefix+'FixedSpectrumCosineExpansion\n').encode()
    assert b.count(old)==1 and new not in b
    a=b.replace(old,old+new)
    if path.endswith('Registry.lean'):
        marker=b'  {\n    key := "gaussian-complexity.single-block-separation",'
        assert a.count(marker)==1
        entry=('''  {
    key := "gaussian-complexity.fixed-spectrum-cosine-expansion",
    localDecl := "'''+DECL+'''",
    upstreamDecl := "arXiv2610.20492v1 FactC.7 inverse-spectrum cosine expansion",
    upstreamFile := "A3.Ex133-137 and full proof A3.SS3.2; private finite-grid use A3.SS3.p4.2",
    status := LemmaMemoryStatus.formalizedLocal,
    tags := ["GaussianComplexity", "fixed-spectrum", "cosine-series", "uniform-convergence", "canonical-reuse"],
    saldUse := "The genuine private actual_inverse_grid_cosine_series consumes the new identity and absolute summability, proves weighted summability and exchanges the literal finite grid sum with the infinite series",
    note := "Mathematical candidate '''+CANDIDATE+''' and publication binding '''+BINDING+''' pin exact code, private Test and authored mathematics. Applying this conditional payload requires genuine current-binding independent source/whole-module review, normal source V, real reconciliation with current main and sole STAB. Exactly real kappa>=2; literal r=(sqrt(kappa)-1)/(sqrt(kappa)+1); pointwise reciprocal-spectrum identity for every real angle, absolute summability and all-real-angle uniform convergence for each fixed kappa. No dimension, Gaussian law, matrix, radius or convergence certificate is a public premise. ZERO direct public ASTIS producer parents; canonical Mathlib geometric, real-part and majorant APIs are proof ingredients. The genuine private Test has exactly ONE public ASTIS parent, this producer; it materializes the same literal d>=2 midpoint grid at all natural frequencies n and genuinely interchanges its weighted finite sum with the series. It creates no public or Registry node. Source1<=n<d remains necessary later for C8 alias classification and closed moments. The independently validated Poisson family is typed conceptual memory only: retain A1 n>=2/n>=3 ambiguity and n=2 extension/HFT-route debt, auxiliary-circle/sign/measure adapters, fixed-kappa uniformity and finite-grid alias corrections; no Lean implication or functor certificate. Gaussian expectation/target-law, C8 closed moments, variance/bias/Krylov, adaptive/seed/transcript/output laws, exact-oracle/finite-precision/TV/deterministic-cap/expected-cost adapters, both full main lower bounds, remote publication and postmerge purification/Exposition Seal remain separate."
  },
''').encode()
        a=a.replace(marker,entry+marker)
        assert a.count(b'key := "gaussian-complexity.fixed-spectrum-cosine-expansion"')==1
    payload(path,b,a,'one canonical public producer import/Registry entry; private Test remains private')
b=read('Tests/Basic.lean'); old=b'formalizedTechnicalLemmaCount = 624';assert b.count(old)==1
payload('Tests/Basic.lean',b,b.replace(old,b'formalizedTechnicalLemmaCount = 625'),'one genuine new public Registry node, count624 to625')

paragraph = ('The scalar Fact C7 inverse-spectrum expansion is also compiled locally: for exactly real \\(\\kappa\\ge2\\), the literal \\(r=(\\sqrt\\kappa-1)/(\\sqrt\\kappa+1)\\) gives the reciprocal cosine spectrum as \\(\\kappa^{-1/2}[1+2\\sum_{j\\ge1}(-r)^j\\cos(j\\theta)]\\) for every real angle. Absolute convergence and uniform convergence over all angles are outputs for each fixed kappa. Uniformity over unbounded kappa is not claimed. The scalar producer adds no dimension, matrix, Gaussian law or caller convergence premise. Its direct public ASTIS parent list is empty. The genuine private Test has only this C7 producer as its public ASTIS parent and proves the weighted finite-grid/series exchange on the literal d>=2 midpoint grid for every natural frequency n. This is a private intermediate, not a Registry node or C8 Gaussian moment theorem; source1<=n<d, alias corrections and exact closed moments remain later obligations. The independently validated Poisson bridge is conceptual only: A1 source ambiguity/HFT-route debt and auxiliary-circle, negative-pole and surface/angular-measure adapters remain explicit; neither substrate implies the other in Lean. ')
b=read(CASE); d=json.loads(b);assert d['cases'][4]['id']=='ASTIS-SW-GAUSSIAN-COMPLEXITY-2026'
gp=('cases',4,'reader_guide',3); bp=('cases',4,'theorems',1,'boundary')
g=d['cases'][4]['reader_guide'][3]; t=d['cases'][4]['theorems'][1]['boundary']
gmarker='Moments/Krylov and all full lower-bound transports remain separate.'
tmarker='Gaussian target-law/TV parameter transport,'
assert g.count(gmarker)==1 and t.count(tmarker)==1
a=replace_token(b,gp,g.replace(gmarker,paragraph+gmarker)); a=replace_token(a,bp,t.replace(tmarker,paragraph+tmarker))
assert changes(d,json.loads(a)) == [list(gp),list(bp)]
assert replace_token(replace_token(a,bp,t),gp,g)==b
payload(CASE,b,a,'only own Gaussian reader guide scalar and fixed-spectrum theorem boundary scalar; all other cases, execution and exact main ranges preserved')

cardpath='research-wiki/sampling-sde-library/cards/'+MOD+'.md'
assert not (R/cardpath).exists()
card='''# '''+MOD+'''

- Conditional unapplied integration for mathematical candidate `'''+CANDIDATE+'''` and publication binding `'''+BINDING+'''`. Application requires genuine current-binding independent source review and normal source V, a real merge preserving current main ancestry and all other-chat changes, sole stabilization ownership and exact payload review. This preparation is not source V, runtime/pixel acceptance or park eligibility.
- Sole public declaration: `actual_inverse_spectrum_cosine_expansion`. Its only hypothesis is real `kappa >= 2`; `r=(sqrt(kappa)-1)/(sqrt(kappa)+1)` is literal. For every real theta, the reciprocal spectrum is `kappa^(-1/2) (1 + 2 sum_{j>=1} (-r)^j cos(j theta))`. The square root is nonnegative, and Lean's `j:Nat` uses mode `j+1`.
- Pointwise identity, absolute summability and uniform convergence over all real angles for each fixed kappa are outputs. Radius bounds, positive/nonzero denominators and convergence are proved internally. There is no dimension, Gaussian law, matrix, radius or convergence certificate premise; uniformity as kappa tends to infinity is not claimed.
- ZERO direct public ASTIS producer parents. Existing Mathlib complex geometric summation, real-part algebra and geometric majorant APIs are used. The standard recursive kernel axioms are only propext, Classical.choice and Quot.sound in the recorded successful local check; this preparation does not rerun or upgrade that check.
- Genuine private Test `actual_inverse_grid_cosine_series` has exactly ONE public ASTIS parent, the new C7 producer. At the literal d>=2 midpoint grid and any natural frequency n it materially uses the identity and absolute summability, proves weighted summability, normalizes the actual reciprocal eigenvalues and interchanges the finite sum and infinite series. It is not a new public/Registry node. Source1<=n<d remains required later for C8 alias classification and closed moments.
- Six authored formula steps and exact adjacent initially folded Lean stay in `website/content/declaration_lessons/huanjian-fixed-spectrum-cosine-expansion.json`; the existing `website/content/publications/huanjian-fixed-spectrum-cosine-expansion.json` owns source correspondence. Attribution: Huanjian Zhou and Taiji Suzuki, arXiv2610.20492v1 Fact C.7/A3.Ex133-137, full proof A3.SS3.2; private finite-grid source use A3.SS3.p4.2. No parallel source-index entry is needed.
- The separately independently validated `family:poisson-representation` / `transport:poisson-boundary-to-cosine-spectrum` is typed conceptual memory, rendered as dashed candidate-substrate incidence. A1 retains its raw n>=2/n>=3 ambiguity, disclosed n=2 extension and arbitrary-harmonic HFT-route debt. Its positive pole and normalized surface measure need explicit negative-pole, auxiliary-circle and angular/surface adapters before any formal transport. Continuous-circle averaging is not the finite d-point grid: alias modes and finite C8 corrections survive. This is not a Lean implication, certified functor or new A1/C7 source verdict.
- Remaining: Gaussian expectation/second moments and orthogonal target-law adapters, exact C8 closed moments/variance/bias/Krylov, adaptive/private-seed/history/transcript/output laws, exact-oracle/finite-precision/TV/deterministic worst-query caps and explicit expected-cost reductions, both complete main lower bounds, remote publication and postmerge purification/Exposition Seal. Main d/kappa/epsilon/delta ranges and Section4.4 limitations remain in their unchanged canonical statements; TV alone does not transfer unbounded expected costs. Local acceptance, remote owner release, purification and whole-Goal completion are separate.
'''
payload(cardpath,None,card.encode(),'new canonical module card; no duplication of authored lesson or generated source index')

b=read(GM);before_mem=json.loads(b);assert not any(x['id']==family['id'] for x in before_mem['families'])
a=append_array(b,('families',),[family]);payload(GM,b,a,'append one independently validated conceptual family and two dashed candidate substrates; all existing memory untouched')
b=reconciled[FH]; md=json.loads(b)
assert not (set(x['id'] for x in md['objects']) & set(meta['domains']))
assert not any(x['id']==bridge['id'] for x in md['hyperedges'])
a=append_array(b,('objects',),domains); a=append_array(a,('hyperedges',),[bridge]);a=append_mapping(a,('sources',),sources)
payload(FH,b,a,'append two domains, one conceptual bridge and three exact source-catalog anchors AFTER real-main reconciliation; no formal witnesses')
assert len(payloads)==8

# Bounded static assertions, not official graph/site/Lean acceptance.
fd=json.loads(a); gd=json.loads(gzip.decompress((O/payloads[-2]['after']['archive']).read_bytes()))
assert fd['objects'][:-2]==md['objects'] and fd['hyperedges'][:-1]==md['hyperedges']
assert all(fd['sources'][k]==v for k,v in md['sources'].items())
assert gd['families'][:-1]==before_mem['families']
assert bridge['formal_refs']==[] and bridge['status']=='not-Lean-certified'
assert set(bridge['category_contract'])=={'objects','morphisms','identity','composition'}
assert set(bridge['source_ids']) <= set(fd['sources'])
assert all(x['node'] in family['formal_search_nodes'] and x['edges']==[bridge['id']] for x in family['compiled_substrate_bindings'])
assert fd['objects'][next(i for i,x in enumerate(fd['objects']) if x['id']=='concept:lower')]['label']=='Lower Bounds'
dump('stage-B/payload-manifest.json',{'state':'CONDITIONAL_UNAPPLIED_PREPARATION_ONLY','candidate':CANDIDATE,'main_required_ancestor':MAIN,'publication_binding_sha256':BINDING,
  'source_V_exists_at_preparation':False,'normal_state_at_preparation':'PROVED_LOCAL','STAB_performed':False,
  'payload_count':8,'rows':payloads,'case_changed_paths':[list(gp),list(bp)],
  'public_producer_direct_ASTIS_parents':[],'private_Test_direct_public_ASTIS_parents':[DECL],
  'static_assertions_only':True,'official_graph_site_build_browser_or_Lean_run':False})
(O/'stage-B/conditional-exact.diff').write_bytes(''.join(full_diff).encode())

# Freeze bounded real evidence, without repeating a full tracked-source or 4.8GB scan.
critical=[PROD,TEST,'website/content/declaration_lessons/huanjian-fixed-spectrum-cosine-expansion.json',
 'website/content/publications/huanjian-fixed-spectrum-cosine-expansion.json',
 'research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-cosine-expansion.json',
 'research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-cosine-expansion.json',
 'research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-spherical-poisson-moments.json',
 'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-cosine-expansion-statement-seal.json',
 'research-wiki/paper-contributions/GaussianComplexity/README.md',E+'local-proof-capsule.json',
 E+'poisson-cosine-mirror-candidate-v1.json','AutoSamplingTheory/ExampleCases/GaussianComplexity/SphericalPoisson.lean',
 'runs/substantive_advances.jsonl','runs/substantive_discoveries.jsonl',
 'AGENTS.md','docs/theorem-publication-protocol.md','docs/proof-digestion-protocol.md','docs/evidence-routed-memory-protocol.md',
 'Libraries/conceptual-mirror-protocol.json','Libraries/frontloaded-shared-spine.json',
 'research-wiki/process-memory.json','website/scripts/cross_domain.py','lean-toolchain','lake-manifest.json',
 P+'review.md',P+'input-manifest.json',P+'validation-execution/execution-receipt.json',P+'validation-execution/readback.json',P+'validation-execution/append.jsonl']
pins=[]
for i,path in enumerate(critical):
    assert (R/path).is_file(),path
    raw=read(path)
    pins.append({'path':path,**blob('bounded-inputs/%02d.raw.gz'%i,raw)})
capsule=json.loads(read(E+'local-proof-capsule.json'))
kernel_lines=[]
for i,check in enumerate(capsule['actual_checks']):
    rr=read(check['receipt']); receipt=json.loads(rr)
    lp=check['receipt'].removesuffix('.receipt.json')+'.log'
    log=read(lp)
    assert sha(rr)==check['sha256'] and sha(log)==check['raw_log_sha256'] and receipt['exit_code']==0
    pins.extend([{'path':check['receipt'],**blob('bounded-inputs/receipt-%d.raw.gz'%i,rr)},
                 {'path':lp,**blob('bounded-inputs/log-%d.raw.gz'%i,log)}])
    if i==2:
        lines=log.decode().splitlines()
        kernel_lines=[x for x in lines if x.startswith(('DIRECT_ASTIS ','ACTUAL_PRIVATE_'))]
        assert 'DIRECT_ASTIS '+DECL+': []' in kernel_lines
        assert 'DIRECT_ASTIS _private.Tests.GaussianComplexityFixedSpectrumCosineExpansion.0.actual_inverse_grid_cosine_series: ['+DECL+']' in kernel_lines
        assert 'ACTUAL_PRIVATE_SEALED_LITERAL_KERNEL_TYPE_APPLICATION_PASS' in kernel_lines
dump('bounded-input-manifest.json',{'scope':'bounded exact relevant files and raw receipts only; no complete protected-baseline rescan or foreign-state inventory claim',
 'candidate':CANDIDATE,'source_V_pending':True,'pending_audit_sha256':sha(read('research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-cosine-expansion.json')),
 'actual_normal_state':'PROVED_LOCAL','own_last_event':own[-1],'actual_mirror_validation':validation,
 'mirror_discovery_prefix_and_exact_sole_append_verified':True,'raw_kernel_lines_independently_inspected':kernel_lines,
 'historical_scope':'Receipt heads are their actual prior compilation heads, not a fabricated current-head run. Capsule/raw-candidate pending mirror strings remain history; actual discovery validation is separate evidence.',
 'pins':pins})
dump('provenance-retention-plan.json',{'required':'Retain exact original review and validation evidence when sole stabilization owner packages this typed mirror; private evidence paths in model review are actual existing paths, not invented public copies.',
 'optional_public_copy_rule':'If public durability is needed, copy originals losslessly under the existing semantic-evidence directory; review exact copy paths/hash and update only the new mirror review evidence paths before application. Any such change is a new exact payload revision. Do not rewrite historical review/candidate labels.',
 'originals':[{'path':p,'sha256':sha(read(p)),'bytes':len(read(p))} for p in [P+'review.md',P+'input-manifest.json',P+'validation-execution/execution-receipt.json',P+'validation-execution/readback.json',P+'validation-execution/append.jsonl']]})

# Verify bounded inputs and tracked state remain untouched after private preparation.
assert not sh('git','status','--porcelain=v1','--untracked-files=no')
assert sh('git','rev-parse','HEAD').decode().strip()==CANDIDATE
assert read('runs/substantive_advances.jsonl')==ledger
assert read('runs/substantive_discoveries.jsonl')==disc_current
for pin in pins: assert sha(read(pin['path']))==pin['raw_sha256']
dump('preparation-checks.json',{'all_private_archives_roundtrip_exactly':True,'two_case_scalar_inverse_restores_original_bytes':True,
 'array_mapping_insertion_inverse_restores_original_bytes':True,'old_model_values_exactly_equal':True,
 'main_lower_bounds_label_url_and_branch_mobile_fit_preserved':True,'no_text_conflict_markers_in_old_three_argument_merge_preview':True,
 'tracked_worktree_clean_before_and_after':True,'HEAD_before_and_after':CANDIDATE,
 'source_V_or_STAB_or_build_browser_API_issued':False,'source_fidelity_verdict_granted':False,
 'new_generic_framework_or_shared_execution_helper':False})
print(json.dumps({'stage_A_manifest_sha256':sha((O/'stage-A/reconciliation-manifest.json').read_bytes()),
 'stage_B_manifest_sha256':sha((O/'stage-B/payload-manifest.json').read_bytes()),
 'exact_diff_sha256':sha((O/'stage-B/conditional-exact.diff').read_bytes()),'payloads':len(payloads)},indent=2))
