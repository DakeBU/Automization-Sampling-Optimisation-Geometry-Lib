"""Seal exact formed interfaces and source semantics before target proof search."""
from pathlib import Path
import datetime, gzip, hashlib, json, subprocess, sys
sys.dont_write_bytecode = True
P = Path('.astis/huanjian-gc-fixed-spectrum-moments-20261109/cosine-expansion')
S = P.parent/'source-only-review/phase1'
B = Path('research-wiki/paper-contributions/GaussianComplexity')
E = B/'fixed-spectrum-cosine-expansion-semantic-evidence'
sha = lambda b: hashlib.sha256(b).hexdigest()
dump = lambda x: (json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode()
def ref(p): return {'path':str(p),'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size}
def put(p, raw):
    assert not p.exists(), p
    p.parent.mkdir(parents=True,exist_ok=True); p.write_bytes(raw)
def git(*args): return subprocess.check_output(['git',*args])
assert git('rev-parse','HEAD').decode().strip() == '14b2417024d232bac1452eb4f60d7a8fe6d19258'
assert not git('diff','HEAD','--name-only').strip()
assert sha((S/'manifest.json').read_bytes()) == '215fe8eba52b906f54c08471d9d0e896b956cb6726af15a335f4815bac60c6d3'
for row in json.loads((S/'manifest.json').read_bytes())['files']:
    q=S/row['path']; assert sha(q.read_bytes())==row['sha256'] and q.stat().st_size==row['bytes']
receipt=Path('.astis/huanjian-resume-20261103/20261109T051616981380Z-cosine-expansion-signature-formation-v2.receipt.json')
r=json.loads(receipt.read_bytes()); assert r['exit_code']==0
log=Path(r['log']); assert sha(log.read_bytes())==r['log_sha256']
formed=(P/'statement-formation-v2.lean').read_text()
producer=formed.split('def producerStatement',1)[1].split('\ndef consumerStatement',1)[0]
producer='theorem actual_inverse_spectrum_cosine_expansion'+producer.replace(' : Prop :=',' :',1).rstrip()+'\n'
consumer=formed.split('def consumerStatement',1)[1].split('\n#check',1)[0]
consumer='private theorem actual_inverse_grid_cosine_series'+consumer.replace(' : Prop :=',' :',1).rstrip()+'\n'
assert 'sorry' not in producer+consumer and ':=' not in producer.split('\n')[0]
put(E/'producer.signature.lean.txt',producer.encode())
put(E/'consumer.signature.lean.txt',consumer.encode())
put(E/receipt.name,receipt.read_bytes()); put(E/(log.name+'.gz'),gzip.compress(log.read_bytes(),mtime=0))
for v in [1,2]:
    q=P/f'statement-formation-v{v}.lean'
    put(E/(q.name+'.gz'),gzip.compress(q.read_bytes(),mtime=0))
oldreceipt=Path('.astis/huanjian-resume-20261103/20261109T051541950204Z-cosine-expansion-signature-formation-v1.receipt.json')
oldr=json.loads(oldreceipt.read_bytes()); oldlog=Path(oldr['log'])
assert oldr['exit_code']==1 and sha(oldlog.read_bytes())==oldr['log_sha256']
put(E/oldreceipt.name,oldreceipt.read_bytes()); put(E/(oldlog.name+'.gz'),gzip.compress(oldlog.read_bytes(),mtime=0))
manifest=Path('lake-manifest.json'); m=json.loads(manifest.read_bytes()); packages=[]
for row in m['packages']:
    q=Path(m['packagesDir'])/row['name']
    head=subprocess.check_output(['git','-C',str(q),'rev-parse','HEAD'],text=True).strip()
    clean=subprocess.check_output(['git','-C',str(q),'status','--porcelain','--untracked-files=no'])
    assert head==row['rev'] and not clean, row['name']
    packages.append({'name':row['name'],'actual_HEAD':head,'manifest_rev':row['rev'],'tracked_and_index_clean':True})
lean=Path(subprocess.check_output(['lake','env','which','lean'],text=True).strip())
source=Path('.astis/huanjian-resume-20261103/2610.20492v1.html')
assert sha(source.read_bytes())=='6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
ledger=Path('runs/substantive_advances.jsonl'); lr=ledger.read_bytes()
assert sha(lr)=='820b899aae7ed60f17711496f6a4ac556346f48dbb46eff8feefe0f20903d2b2'
sys.path.insert(0,'tools'); import astis_advance as advance
states=advance._replay_advances([json.loads(x) for x in lr.splitlines()])
assert not [k for k,v in states.items() if v['state']=='STABILIZING']
baseline={
    'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'HEAD':git('rev-parse','HEAD').decode().strip(),'origin_main_after_actual_successful_fetch_this_turn':git('rev-parse','origin/main').decode().strip(),
    'fetch_evidence_boundary':'Actual tools.exec_command git fetch origin returned exit0 this turn; this file records subsequent observed ref, not a fabricated fetch receipt or timestamp.',
    'Lean_version':subprocess.check_output(['lake','env','lean','--version'],text=True).strip(),'Lean_binary':ref(lean),
    'manifest':ref(manifest),'packages':packages,'raw_source':ref(source),'source_phase1_manifest':ref(S/'manifest.json'),
    'all_existing_SAU_states':states,'ledger':ref(ledger),'STAB':[],
    'all_existing_frontier_raw_hashes':{str(q):sha(q.read_bytes()) for q in Path('research-wiki/frontier-cells').glob('*.json')},
    'protected_shared_raw_hashes':{str(q):sha(q.read_bytes()) for q in map(Path,[
        'website/content/graph_memory_index.json','website/content/functor_hypergraph.json','runs/substantive_discoveries.jsonl'])},
    'remote_original_owner_release_confirmed':False,'new_goal_or_detached_ASTIS_or_ledger_API_calls':False,
    'exposure':'Root read frozen raw-source C3/S4 moments cognition and exact excerpt. Preseal standard TendstoUniformly definitions plus adjacent iff theorem statements were read at UniformConvergence.lean65-120; existing local Poisson module filenames and declaration-name headers only. No target proof-body/API search, implementation proof, claimed source verdict or source theorem proof has occurred.',
    'process_memory_search':'rg Poisson|Fourier|cosine|GaussianComplexity|reserved returned no match; no new process rule invented.'}
put(P/'baseline.json',dump(baseline))
put(E/'environment-and-preservation-baseline.json.gz',gzip.compress(dump(baseline),mtime=0))
seal={
    'schema_version':1,'seal_id':'GC-FIXED-SPECTRUM-COSINE-EXPANSION-20261109-v1',
    'state':'EXACT_SIGNATURES_TYPE_FORMED_SOURCE_ADMISSION_PENDING_NO_TARGET_PROOF',
    'source':{'title':'On Complexity of Gaussian Sampling','version':'arXiv:2610.20492v1','raw_sha256':sha(source.read_bytes()),
        'producer_anchors':['A3.Thmtheorem7','A3.Ex133','A3.Ex134','A3.Ex135','A3.Ex136','A3.Ex137'],
        'standing_anchors':['S4.E11','A3.SS3.p1.1'],'consumer_anchors':['A3.Ex140','A3.SS3.p4.2'],
        'independent_raw_cognition_manifest':ref(S/'manifest.json')},
    'producer':{'name':'AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumCosineExpansion.actual_inverse_spectrum_cosine_expansion',
        'planned_file':'AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumCosineExpansion.lean',
        'signature':producer,'signature_sha256':sha(producer.encode()),'definition_kind':'literal',
        'outputs':['Pointwise inverse-spectrum cosine series for every real theta','Absolute convergence at every real theta','Uniform convergence of positive-index partial sums on all real theta']},
    'actual_private_consumer':{'name':'actual_inverse_grid_cosine_series','planned_file':'Tests/GaussianComplexityFixedSpectrumCosineExpansion.lean',
        'signature':consumer,'signature_sha256':sha(consumer.encode()),'definition_kind':'literal',
        'actual_use_required':'Apply the new expansion and its absolute summability at every literal source grid point, produce summability of each weighted series and of the finite sum, genuinely interchange the finite grid and infinite series, and normalize actual reciprocal eigenvalues internally. A wrapper/unused producer/#check is not a consumer.',
        'mathematical_scope':'Actual finite-grid reciprocal-spectrum weighted cosine sum, including n=0 for unweighted trace and positive n for the future cosine-moment computation. No Gaussian expectation identification or closed finite-grid moment formula is claimed here.',
        'source_delta':'Private intermediate finite-sum interchange is valid for every natural n; source later restricts1<=n<d for alias classification and exact moments. Those restrictions are neither assumed nor discharged by this intermediate. Dimension d>=2 and kappa>=2 remain the literal hard-family standing inputs.'},
    'binder_audit':[
        {'binder':'producer kappa:Real','class':'TYPING','reason':'Real condition parameter.'},
        {'binder':'producer h_kappa:2<=kappa','class':'STANDING','reason':'Literal Section4.1/C3 hard-family standing range; no radius/positivity or convergence premise.'},
        {'binder':'theta:Real under forall conclusion','class':'TYPING','reason':'All real angles, not an input regularity assumption.'},
        {'binder':'consumer d:Nat and hd:2<=d','class':'STANDING','reason':'Literal finite hard-family dimension and range.'},
        {'binder':'consumer kappa:Real and h_kappa:2<=kappa','class':'STANDING','reason':'Same source parameter range.'},
        {'binder':'consumer n:Nat','class':'TYPING','reason':'A natural cosine frequency in a private generalized intermediate; no new source-facing moment claim.'}],
    'definition_audit':[
        {'object':'r','kind':'literal','meaning':'(sqrt(kappa)-1)/(sqrt(kappa)+1), real nonnegative principal square root. Bounds0<r<1 and denominator positivity are internally produced, never premises.'},
        {'object':'positive-index series','kind':'literal','meaning':'j:Nat maps to source index j+1. Finset.range N contains exactly first N positive-index terms; N=0 gives empty sum. Natural powers and real frequency casts explicit.'},
        {'object':'tsum','kind':'literal','meaning':'Standard real infinite sum. Its totalized off-summable default does not license the identity; source-domain summability is an explicit produced output and is materially used by consumer.'},
        {'object':'Summable of real norm','kind':'literal','meaning':'Pointwise absolute convergence because the real norm is absolute value; not merely convergence of the signed series.'},
        {'object':'TendstoUniformly atTop','kind':'literal','meaning':'For every real epsilon>0, eventually for N all real theta have absolute partial-sum/tsum error<epsilon. Standard Real uniformity is fixed, with no project-owned Prop wrapper or extra typeclass premise.'},
        {'object':'theta_i/eigenvalue_i','kind':'literal','meaning':'Fin d index i corresponds to source i+1: theta=(i.val+1/2)pi/d; eigenvalue=(kappa+1)/2+(kappa-1)cos(theta)/2. No fallback, characterization or assumed eigenvalue bound.'},
        {'object':'finite weighted inverse sum','kind':'literal','meaning':'Sum over Fin d of cos(n theta_i)/lambda_i. Pure actual spectral sum; its identification with Gaussian mean remains separate.'}],
    'EXCESS_binders':[],
    'internal_dependencies_not_premises':['Square-root/radius/denominator positivity','Complex geometric series and Euler real-part algebra or an exactly justified canonical equivalent','Absolute summability and geometric domination','Uniform tail bound on all angles','Literal eigenvalue reciprocal normalization','Finite weighted summability and finite-sum/tsum interchange'],
    'statement_formation':{'receipt':ref(receipt),'exit_code':0,'proof_credit':False,
        'initial_failure':'v1 used reserved lambda token for eigenvalue let-name; parser failure is IMPLEMENTATION_FAILED for type formation only. v2 alpha-renames to eigenvalue without a mathematical change. All failed logs and compiler recovery output retained; no recovery sorry term is authored or accepted mathematics.',
        'unused_binder_warnings':'Prop-valued type-formation definitions do not use proof arguments computationally; no assertion was proved.'},
    'reuse_boundary':'Existing local spherical Poisson declarations are about Laplacian/harmonicity/normalization, not this cosine-series interface; only name inventory was read. Exact ASTIS/Mathlib proof API retrieval occurs after independent admission; no library availability or duplicate-free proof is yet certified.',
    'conceptual_boundary':'Fourier/geometric-series similarity is not a Lean implication or new conceptual hyperedge. Postproof conceptual audit still required.',
    'truth_boundary':'Only sealed FactC7 and genuine finite-grid series interchange target. No proof/consumer exists yet. C8 grid alias sums/closed exact Gaussian moments, variance/bias/log-power estimates, Krylov and both full main lower bounds, joint/adaptive/oracle/precision/TV/deterministic-cap/expected-cost adapters, local integration/remote delivery/purification and wholeGoal remain open.',
    'roles':'Root sole mathematical proof worker. Independent sourcegraph author and distinct topology/binder challenger must admit this exact seal before target proof/API search.'}
put(B/'fixed-spectrum-cosine-expansion-statement-seal.json',dump(seal))
for v in [1,2]: (P/f'statement-formation-v{v}.lean').unlink()
assert ledger.read_bytes()==lr and not git('diff','HEAD','--name-only').strip()
print(json.dumps({'seal':ref(B/'fixed-spectrum-cosine-expansion-statement-seal.json'),
    'producer_signature_sha256':sha(producer.encode()),'consumer_signature_sha256':sha(consumer.encode()),
    'packages_checked':len(packages),'prior_frontiers':len(baseline['all_existing_frontier_raw_hashes']),
    'temporary_formation_probes_archived_losslessly_then_removed':True,'target_proof_or_API_search':False,'normal_ledger_API_calls':0}))
