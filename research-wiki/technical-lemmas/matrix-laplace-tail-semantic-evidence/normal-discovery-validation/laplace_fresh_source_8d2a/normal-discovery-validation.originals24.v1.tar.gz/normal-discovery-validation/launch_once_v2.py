from pathlib import Path
import json,subprocess,sys
p=Path(__file__).parent
for name in ['normal-discovery-validation.once.marker.json','normal-api.status.json','operation-v2.status.json']:
 if (p/name).exists():raise SystemExit('STOP: existing action marker/status; inspect suffix, never replay')
with (p/'operation-v2.stdout.txt').open('x') as sout,(p/'operation-v2.stderr.txt').open('x') as serr:
 result=subprocess.run([sys.executable,str(p/'run_once_v2.py')],cwd='/Users/zhouhuanjian/ASTIS-GC',stdout=sout,stderr=serr,check=False)
(p/'operation-v2.status.json').write_text(json.dumps({'actual_process_exit_status':result.returncode,'command':['python3',str(p/'run_once_v2.py')],'automatic_replay':False},indent=2)+'\n')
print((p/'operation-v2.stdout.txt').read_text(),end='')
if result.returncode:print((p/'operation-v2.stderr.txt').read_text(),end='',file=sys.stderr)
raise SystemExit(result.returncode)
