python3 - <<'PY'
from pathlib import Path
import re
p=Path('.astis/huanjian-resume-20261103/2610.20492v1.html')
s=p.read_text()
for ident in ['S4.SS1','S4.Thmtheorem5','A3.SS3']:
    m=re.search(r'<[^>]+\bid="'+re.escape(ident)+r'"[^>]*>',s)
    print(ident, 'offset',m.start() if m else None)
    if m: print(s[m.start():m.start()+7000])
PY
