from pathlib import Path
import json,hashlib,stat,datetime
OWN=Path('/Users/zhouhuanjian/ASTIS-GC/.astis/semantic-neutral-20261110/z_sg_7d14a2_phase2')
P1=OWN.parent/'z_sg_7d14a2'
def sha(b):return hashlib.sha256(b).hexdigest()
new=json.loads((OWN/'input-receipts.json').read_text())
for e in new['new_inputs']:
 b=(OWN/e['copy']).read_bytes();assert len(b)==e['bytes'] and sha(b)==e['sha256']
a=json.loads((OWN/'selective-types-input.json').read_text());b=json.loads((OWN/'selective-standard-definitions-input.json').read_text())
for key,filename in [('producer','literal-public-type.txt'),('private_consumer','literal-private-type.txt')]:
 raw=(OWN/filename).read_bytes();assert raw==a[key]['signature'].encode() and sha(raw)==a[key]['signature_sha256']
for e in a['approved_minimal_definition_context']+b['definitions']:assert sha(e['exact_excerpt'].encode())==e['excerpt_sha256']
mraw=(P1/'phase1-manifest.json').read_bytes();rraw=(P1/'phase1-receipt.json').read_bytes()
assert sha(mraw)=='c6139e1da52ec5caaaa7d7aaa091a54a37c2f22fbcec1e028924de0d600267af'
assert sha(rraw)=='83255eeb8220e5aa641e8d9e081cb6550f100726851a32a366d64562d7b4c1d0'
for e in json.loads(mraw)['payloads']:
 p=P1/e['file'];x=p.read_bytes();assert len(x)==e['bytes'] and sha(x)==e['sha256'] and stat.S_IMODE(p.stat().st_mode)==0o444
assert stat.S_IMODE(P1.stat().st_mode)==0o555
ids={n['id'] for n in json.loads((P1/'source-graph.json').read_text())['nodes']}
overlay=json.loads((OWN/'type-alignment-overlay.json').read_text())
for o in overlay['objects']:assert set(o['source_support_ids'])<=ids
assert overlay['typed_relation']['actual_implementation_edge'] is False
assert not overlay['source_mismatches_found']
root=json.loads((OWN/'source-root-map.json').read_text())
assert root['algorithmic_root']['status'].startswith('OPEN')
assert root['full_main_theorem']['status'].startswith('UNCLOSED')
report={'status':'PASS_MECHANICAL_ONLY','checks':['Two authorized raw input byte counts/digests verified.','Both exact literal signature digests verified.','All six authorized meaning-carrying definition excerpt digests verified.','Phase1 manifest, receipt and all 24 payload byte hashes/modes remain unchanged.','All overlay source references belong to frozen Phase1 graph.','Algorithm/root openness and non-actual-invocation flags retained.'],'not_asserted':['Independent source/topology approval','Mathematical proof closure','API/target proof checks','Lean compilation','Actual private-consumer invocation','Full Theorem3.1 closure']}
(OWN/'mechanical-validation.json').write_text(json.dumps(report,indent=2)+'\n')
payload=[]
for p in sorted(OWN.iterdir()):
 assert p.is_file()
 if p.name not in ('phase2-manifest.json','phase2-receipt.json'):
  x=p.read_bytes();payload.append({'file':p.name,'bytes':len(x),'sha256':sha(x),'frozen_mode':'0444'})
manifest={'schema':'phase2-selective-type-alignment-freeze-manifest-v1','phase':'PHASE2_EXACT_TYPE_OVERLAY_FROZEN','owned_directory':str(OWN),'base_phase1_manifest_sha256':sha(mraw),'base_phase1_receipt_sha256':sha(rraw),'source_raw_sha256':'6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915','payload_count':len(payload),'payloads':payload,'manifest_excludes':'Itself and phase2-receipt.json to avoid self-hash cycle; receipt binds manifest; receipt digest delivered out of band.','role_boundary':'Source-author exact-type overlay only. Pause before implementation/proof/API/full-seal/other-review exposure; independent topology acceptance pending.'}
mb=(json.dumps(manifest,indent=2)+'\n').encode();(OWN/'phase2-manifest.json').write_bytes(mb)
receipt={'schema':'phase2-selective-type-alignment-freeze-receipt-v1','phase':'PHASE2_EXACT_TYPE_OVERLAY_FROZEN','frozen_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'manifest':{'file':'phase2-manifest.json','bytes':len(mb),'sha256':sha(mb)},'payload_count':len(payload),'phase1_unchanged':True,'phase1_manifest_sha256':sha(mraw),'literal_public_signature_sha256':a['producer']['signature_sha256'],'literal_private_signature_sha256':a['private_consumer']['signature_sha256'],'files_mode':'0444','directory_mode':'0555','type_source_mismatches_found':[],'actual_invocation_or_compiled_dependency':'not asserted','source_algorithm_and_main_roots':'open/unclosed','independent_topology_acceptance':'pending','receipt_self_digest':'Delivered out of band.'}
rb=(json.dumps(receipt,indent=2)+'\n').encode();(OWN/'phase2-receipt.json').write_bytes(rb)
for p in OWN.iterdir():p.chmod(0o444)
OWN.chmod(0o555)
assert all(stat.S_IMODE(p.stat().st_mode)==0o444 for p in OWN.iterdir())
print(json.dumps({'receipt_path':str(OWN/'phase2-receipt.json'),'receipt_bytes':len(rb),'receipt_sha256':sha(rb),'manifest_path':str(OWN/'phase2-manifest.json'),'manifest_bytes':len(mb),'manifest_sha256':sha(mb),'payload_count':len(payload),'total_frozen_files':len(payload)+2,'all_files_0444':True,'directory_0555':True,'phase1_unchanged':True},indent=2))
