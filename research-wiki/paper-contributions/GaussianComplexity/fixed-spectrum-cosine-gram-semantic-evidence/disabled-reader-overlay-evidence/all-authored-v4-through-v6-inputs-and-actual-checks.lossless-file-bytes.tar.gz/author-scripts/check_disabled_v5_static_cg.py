from pathlib import Path
import hashlib, importlib.util, json, sys
from bs4 import BeautifulSoup
sys.dont_write_bytecode = True
sys.path[:0] = ['website/scripts', 'tools']
sha = lambda b: hashlib.sha256(b).hexdigest()
R = Path.cwd()
W = Path(__file__).parent
D = W/'disabled-v5-cosine-gram-static'
assert not D.exists()
D.mkdir()
production = Path('website/scripts/declaration_lessons.py')
before = production.read_bytes()
assert sha(before) == 'b22394faeb8de07109826174d05856f4a561b20f9301e1f1d031b466fd6f2596'
q = W/'reader-step-neighbor-proposal-v5/proposed/website/scripts/declaration_lessons.py'
assert sha(q.read_bytes()) == '64f7c70a7501b7143d16ef2317d8a0685c6ad37be6bd1f8cea2a021c7a6672e4'
spec = importlib.util.spec_from_file_location('disabled_exact_step_v4', q)
dl = importlib.util.module_from_spec(spec)
spec.loader.exec_module(dl)
dl.ROOT = R
dl.CONTENT = R/'website/content/declaration_lessons'
lesson = Path('website/content/declaration_lessons/huanjian-fixed-spectrum-cosine-gram.json')
lesson_raw = lesson.read_bytes()
u = json.loads(lesson_raw)['units'][0]
P = Path('AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumCosineGram.lean')
T = Path('Tests/GaussianComplexityFixedSpectrumCosineGram.lean')
expected = [(P, 34), (P, 54), (P, 125), (P, 156), (T, 59), (T, 13)]
page = dl.lesson_path(u['declaration'])
fragment = dl.render_unit(u, page)
(D/'prospective-fragment.html').write_text(fragment)
soup = BeautifulSoup(fragment, 'html.parser')
assert not soup.select('details[open]')
folds = [x.parent for x in soup.find_all('summary') if x.get_text(strip=True) == 'Corresponding Lean step']
assert len(folds) == 6
routes = []
for fold, step, (path, line) in zip(folds, u['steps'], expected):
    assert fold.has_attr('data-lean-code-panel')
    assert fold.select_one('button[data-lean-copy]')
    assert fold.select_one('[data-lean-copy-status]')
    assert fold.find('code').get_text() == step['lean']
    action = fold.find(class_='lean-source-actions')
    links = {x.get_text(strip=True): x for x in action.find_all('a')}
    assert set(links) == {'Exact source context', 'Download exact Lean source'}
    assert links['Exact source context']['href'].endswith(str(path)+'.html#L'+str(line))
    assert links['Download exact Lean source']['href'].endswith(str(path))
    assert links['Download exact Lean source'].has_attr('download')
    routes.append({'source': str(path), 'line': line, 'copy_panel_and_controls_present': True})
assert u['steps'][-1]['lean'].encode() == T.read_bytes()
out = D/'export'
out.mkdir()
fixture = Path('_site/textbook/index.html').read_bytes()
(out/'textbook').mkdir()
(out/'textbook/index.html').write_bytes(fixture)
dl.export_sources(out, [u])
for path in [P, T]:
    exported = out/'data/lesson-sources'/path
    assert exported.read_bytes() == path.read_bytes()
    context = BeautifulSoup(exported.with_suffix('.lean.html').read_text(), 'html.parser')
    download = context.find('a', attrs={'download': True})
    assert download and download['href'] == path.name
    assert (exported.parent/download['href']).read_bytes() == path.read_bytes()
for path, line in expected:
    context = BeautifulSoup((out/'data/lesson-sources'/path).with_suffix('.lean.html').read_text(), 'html.parser')
    assert context.find(id='L'+str(line))
# Replay the original independent frozen U+2028 counterexample, exact bytes.
finding_path = W/'reader-step-neighbor-v4-independent-0a91de/findings.json'
assert sha(finding_path.read_bytes()) == 'e1cd945656648863a028686541b375f4c7a9a824518fbcc45ebc5215e81ed057'
counter = json.loads(finding_path.read_bytes())['independent_counterexample']
raw_counter = bytes.fromhex(counter['source_bytes_hex'])
assert sha(raw_counter) == counter['source_sha256']
literal = raw_counter.partition(b'\n')[2]
assert sha(literal) == counter['literal_sha256']
fixture_root = D/'unicode-fixture'
fixture_root.mkdir()
(fixture_root/'UnicodeLineSeparator.lean').write_bytes(raw_counter)
dl.ROOT = fixture_root.resolve()
fixture_unit = {'sources': [{'path': 'UnicodeLineSeparator.lean'}]}
actions = BeautifulSoup(dl.exact_lean_step_actions(fixture_unit, {'lean': literal.decode()}, 'lessons/test.html'), 'html.parser')
context_link = next(a['href'] for a in actions.find_all('a') if a.get_text() == 'Exact source context')
assert context_link.endswith('#L2')
fixture_out = D/'unicode-output'
(fixture_out/'textbook').mkdir(parents=True)
(fixture_out/'textbook/index.html').write_bytes(fixture)
dl.export_sources(fixture_out, [fixture_unit])
context_path = fixture_out/'data/lesson-sources/UnicodeLineSeparator.lean.html'
context_soup = BeautifulSoup(context_path.read_text(), 'html.parser')
assert context_soup.find(id='L2').get_text() == literal.decode().split('\n')[0]
assert (fixture_out/'data/lesson-sources/UnicodeLineSeparator.lean').read_bytes() == raw_counter
dl.ROOT = R

assert production.read_bytes() == before and lesson.read_bytes() == lesson_raw
record = {'scope': 'Root prospective STATIC check of DISABLED v4 only, not independent acceptance or actual clipboard/browser/MathJax/desktop/mobile/site/HOLD release.',
          'proposed_sha256': sha(q.read_bytes()), 'production_unchanged_sha256': sha(before),
          'lesson_unchanged_sha256': sha(lesson_raw), 'all_six_exact_routes': routes,
          'six_unchanged_literal_closed_folds': True, 'full_Test_bytes': len(T.read_bytes()),
          'old_theme_fixture_sha256': sha(fixture), 'original_frozen_Unicode_counterexample_replayed_and_correctly_routed': True, 'reader_HOLD_still_pending': True}
(D/'actual-prospective-static-check.json').write_text(json.dumps(record, indent=2)+'\n')
print(json.dumps(record))
