"""Exact limited successor diff and inherited closure checks, no target proof."""
from pathlib import Path
from collections import defaultdict
import json
import hashlib
import datetime

B = Path('.astis/huanjian-gc-fixed-spectrum-bias-20261110')
OLD = B / 'independent-source-graph/phase2'
NEW = OLD / 'clarification-v2'
OUT = B / 'independent-topology-challenge/phase2b/successor-v2'


def pin(p):
    raw = p.read_bytes()
    return {'path': str(p), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def load(p):
    return json.loads(p.read_bytes())


def canon(x):
    return hashlib.sha256(json.dumps(x, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


master_path = NEW / 'exact-successor-inputs-freeze-v2.json'
assert pin(master_path)['sha256'] == '993a4c25db9741d996556731ae36b5f7deb293f2b4d1ab8a19189aea69258d61'
master = load(master_path)
input_pins = [pin(master_path)]
for ref in [master['clarification_freeze'], master['original_hold_reference_binding']] + master['artifacts']:
    if not ref['path'].endswith('.json'):
        continue  # author generator is not read
    info = pin(Path(ref['path']))
    assert info['sha256'] == ref['sha256']
    if info not in input_pins:
        input_pins.append(info)
prior_checks = load(B / 'independent-topology-challenge/phase2b/original-graph-checks.json')
for ref in prior_checks['inputs']:
    assert pin(Path(ref['path'])) == ref
g0, g = load(OLD / 'source-proof-graph.json'), load(NEW / 'source-proof-graph-v2.json')
c0, c = load(OLD / 'exact-target-coverage.json'), load(NEW / 'exact-target-coverage-binding-v2.json')
r0, r = load(OLD / 'root-closures.json'), load(NEW / 'root-closures-binding-v2.json')
declared = load(NEW / 'typed-changes-v2.json')
changes = []


def diff(x, y, pointer):
    if type(x) != type(y):
        changes.append({'pointer': pointer, 'old': x, 'new': y})
    elif isinstance(x, dict):
        for k in sorted(set(x) | set(y)):
            p = pointer + '/' + k.replace('~', '~0').replace('/', '~1')
            if k not in x:
                changes.append({'pointer': p, 'old_absent': True, 'new': y[k]})
            elif k not in y:
                changes.append({'pointer': p, 'old': x[k], 'new_absent': True})
            else:
                diff(x[k], y[k], p)
    elif isinstance(x, list):
        assert len(x) == len(y)
        for i, (a, b) in enumerate(zip(x, y)):
            diff(a, b, pointer + '/' + str(i))
    elif x != y:
        changes.append({'pointer': pointer, 'old': x, 'new': y})


diff(g0['nodes'], g['nodes'], '/nodes')
diff(g0['routes'], g['routes'], '/routes')
assert len(changes) == 7 == declared['exact_allowed_semantic_field_change_count']
by_pointer = {x['json_pointer']: x for x in declared['changes']}
assert set(by_pointer) == {x['pointer'] for x in changes}
for x in changes:
    d = by_pointer[x['pointer']]
    assert x.get('old') == d['old_value'] and x['new'] == d['new_value']
for k in g0:
    assert k in ['schema', 'nodes', 'routes'] or g[k] == g0[k]
assert g0['schema'] == 1 and g['schema'] == 2
assert set(g) - set(g0) == {'binding_successor'}
for k in c0:
    assert k in ['schema', 'graph_sha256'] or c[k] == c0[k]
for k in r0:
    assert k in ['schema', 'graph_sha256', 'coverage_sha256'] or r[k] == r0[k]
assert c0['schema'] == r0['schema'] == 1 and c['schema'] == r['schema'] == 2
assert set(c) - set(c0) == {'binding_successor'}
assert set(r) - set(r0) == {'binding_successor', 'conditional_premise_audit'}
assert c['graph_sha256'] == r['graph_sha256'] == pin(NEW / 'source-proof-graph-v2.json')['sha256']
assert r['coverage_sha256'] == pin(NEW / 'exact-target-coverage-binding-v2.json')['sha256']
assert canon(c['rows']) == c['binding_successor']['current_rows_canonical_sha256'] == c['binding_successor']['predecessor_rows_canonical_sha256']
assert canon(r['closures']) == r['binding_successor']['current_closures_canonical_sha256'] == r['binding_successor']['predecessor_closures_canonical_sha256']
nodes, edges = {n['id']: n for n in g['nodes']}, {e['id']: e for e in g['routes']}
incoming = defaultdict(list)
for e in g['routes']:
    assert e['logic'] == 'AND'
    incoming[e['consumer']].append(e)
assert len(nodes) == 58 and len(edges) == 50 and g['OR_routes'] == []


def closure(root):
    seen, routes, active = set(), set(), set()

    def visit(n):
        assert n not in active
        if n in seen:
            return
        active.add(n)
        for e in incoming[n]:
            routes.add(e['id'])
            for p in e['inputs']:
                visit(p)
        active.remove(n)
        seen.add(n)

    visit(root)
    return {'nodes': sorted(seen), 'routes': sorted(routes),
            'node_source_anchors': sorted({a['id'] for n in seen for a in nodes[n]['source_anchors']}),
            'route_use_site_anchors': sorted({a['id'] for e in routes for a in edges[e]['consumer_use_sites']})}


roots = {}
for owner, data in r['closures'].items():
    d = closure(data['root'])
    assert d['nodes'] == data['nodes'] and d['routes'] == data['routes']
    roots[owner] = d
subroots = {}
for n, prior in prior_checks['every_target_and_selected_guard_subroot'].items():
    d = closure(n)
    assert d['nodes'] == prior['nodes'] and d['routes'] == prior['routes']
    assert d['node_source_anchors'] == prior['node_source_anchor_ids']
    assert d['route_use_site_anchors'] == prior['route_use_site_anchor_ids']
    subroots[n] = d
for n in nodes:
    closure(n)
premises = nodes['G_Chebyshev']['conditional_premises']
assert len(premises) == 1
p = premises[0]
assert p['formula'] == '0 < t' and p['actual_discharge_parent'] == 'N_signed_actual_mean'
application = edges[p['actual_application_route']]
assert application['id'] == 'r_zerocheb' and application['consumer'] == 'N_zero_event_Chebyshev'
assert p['actual_discharge_parent'] in application['inputs']
discharges = application['conditional_premise_discharges']
assert len(discharges) == 1 and discharges[0]['premise_id'] == p['id']
assert discharges[0]['incoming_parent'] == p['actual_discharge_parent']
assert 'N_signed_positive' in closure('N_signed_actual_mean')['nodes']
assert 'N_signed_actual_mean' not in closure('G_Chebyshev')['nodes']
assert 'N_signed_actual_mean' in closure('N_zero_event_Chebyshev')['nodes']
assert 'conditional' in edges['r_cheb']['conclusion_kind']
assert r['conditional_premise_audit']['actual_positive_threshold_parent'] == 'N_signed_actual_mean'
preserved = []
for sub, name in [('phase1', 'SHA256SUMS.phase1'), ('phase2a', 'SHA256SUMS.phase2a'),
                  ('phase2a', 'SHA256SUMS.postseal-process-v1'), ('phase2b', 'SHA256SUMS.original-HOLD')]:
    base = B / 'independent-topology-challenge' / sub
    for line in (base / name).read_text().splitlines():
        sha, filename = line.split('  ', 1)
        assert pin(base / filename)['sha256'] == sha
    preserved.append(pin(base / name))
original_binding = load(NEW / 'original-hold-reference-binding-v2.json')
for ref in original_binding['original_challenger_hold_references']:
    assert pin(Path(ref['path']))['sha256'] == ref['sha256_parent_supplied']
projection = pin(B / 'strict-preproof-seal-projection-v1.json')
assert projection['sha256'] == 'b245ddf40403f7aca7d2f0be6de9953cf1fb2bda57e840d9ee6bf6156aac8511'
raw = pin(Path('.astis/huanjian-resume-20261103/2610.20492v1.html'))
assert raw['sha256'] == '6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'


def fresh(name, obj):
    p = OUT / name
    assert not p.exists()
    p.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n')
    return pin(p)


actual_diff = fresh('independent-seven-field-diff.json', {
    'old_graph': pin(OLD / 'source-proof-graph.json'), 'new_graph': pin(NEW / 'source-proof-graph-v2.json'),
    'actual_recursive_semantic_field_diff': changes, 'exact_seven_match_declared_values': True,
    'other_graph_metadata_delta': 'schema1→2 and added binding_successor only',
    'coverage_metadata_delta': 'schema1→2, current graph hash, binding_successor only',
    'root_metadata_delta': 'schema1→2, current graph/coverage hashes, binding_successor and conditional audit only'})
result = fresh('limited-rereview-checks.json', {
    'run_id': 'BIAS-INDEPENDENT-TYPED-SUCCESSOR-V2-REREVIEW-20261110',
    'frozen_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'input_pins': input_pins,
    'actual_diff': actual_diff, 'current_source_and_projection': [raw, projection],
    'original_author_machine_inputs_rechecked_unchanged': prior_checks['inputs'],
    'coverage_rows_history_dispositions_exact_unchanged': True, 'provided_closures_exact_unchanged': True,
    'all_previous_root_subroot_node_route_anchor_sets_independently_recomputed_unchanged': True,
    'roots': roots, 'subroots': subroots,
    'conditional_audit': {'generic_rule_has_unproved_positive_threshold_antecedent': True,
                          'actual_application': 'r_zerocheb', 'actual_incoming_discharge_parent': 'N_signed_actual_mean',
                          'parent_derived_from_new_signed_positive_output': True,
                          'no_new_public_premise_or_free_positive_mean': True},
    'old_own_checksum_sets_and_members_preserved': preserved,
    'original_HOLD_reference_binding_checked': original_binding['original_challenger_hold_references'],
    'creator_statement_audit_and_binding_content': 'HASH_ONLY_NOT_PARSED',
    'author_generator_private_cognition_target_implementation_API_Mathlib_not_read': True,
    'check_result': 'PASS_BOUNDED_SUCCESSOR_SCOPE',
    'initial_inline_attempt_note': 'Stopped on its overstrict schema-equality assertion before any output; schema1→2 metadata is now explicitly recorded. No source or graph defect inferred.'})
print(json.dumps({'diff': actual_diff, 'checks': result,
                  'root_counts': {k: [len(v['nodes']), len(v['routes'])] for k, v in roots.items()}}, indent=2))
