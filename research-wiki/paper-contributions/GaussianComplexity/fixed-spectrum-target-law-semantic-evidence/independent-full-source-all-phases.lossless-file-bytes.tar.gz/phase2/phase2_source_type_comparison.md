# Phase 2: selective source/type/reconstruction comparison

Reader: `/root/targetlaw_fresh_source_9c7d21`, distinct from the supplied formalizer `huanjian_gc_20261110_fixed_spectrum_target_law` and decoder `/root/neutral_decoder_6c2d91`.

## Finding and strict scope

The visible public type and independent reconstruction agree with a **fixed-orthogonal-basis Gaussian-law auxiliary** supported by the raw paper. Its forward-pushforward form is equivalent, for a fixed orthogonal basis, to the paper's inverse-coordinate law. The private signature states a source-supported squared-norm integrability and inverse-spectrum mean consequence under the actual target Gaussian. No blocking semantic mismatch is identified in the visible propositions, using the supplied approved definition meanings on their positive-definite parameter domain.

This is a bounded comparison of statements and supplied definition context. It does not certify the unseen code, actual dependency use, compilation, kernel/native evidence, authored exposition, publication correspondence, source topology, or reader delivery. In particular, the private signature establishes only a possible semantic consumer, not an observed invocation of the public theorem. It is not a verdict that all of Lemma 4.5 or a lower bound is formalized.

The source-only account was frozen first at SHA-256 `d80ae7b6e13f65663fa21fa3fcbe6509fd7b5e469adad6b121a85d93541fd1a2`; its manifest/receipt were verified unchanged before this packet was read. The raw paper remains primary. The packet's `original_text` is an attributed auxiliary-contract paraphrase, not a raw quotation and not evidence by its adjective “faithful.”

## Exact selective input

The only new file opened was `research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-target-law-semantic-evidence/selective-fresh-source-phase2-input.json`, 8345 bytes, raw SHA-256 `6cc5f85056b6841ada1a54fc0d9dc40389924e612aa228727dff37b21ebbd685`. Exact bytes are copied as `selective_packet.json`.

Its public statement hash independently recomputed to `f53b64002b52696a8b17d4a6daff1b52ca160b82b4c2a0db0999c8236822f02f`; its reconstruction hash to `47a675dad1d1a572cd394b3387321fc6ea3b5605cb5ed2721b81c61db95818be`; its attributed source-paraphrase hash to `888763790e2e306bfac0e10aed9be2dbe7cda6398fe5c7a547668238f84ff0a4`.

The full reviewer packet was not opened. Its supplied identities are only metadata at this phase: canonical packet hash `87e0d4528bfb55d403f04a0a9a7181326dbd92bf1431d92a5c355dd699471767`, raw file hash `7825279129ff5d926b4c2a206e80854cbab2810fbcd7459137982a6bc8dec999`. Likewise the supplied publication binding hash `3f8f86b61bf73df0bf7a51f989239ca2246fa5c88de21364b468816869ee86bc` does not by itself verify any withheld content.

## Seven semantic slots

### 1. Objects

The raw source `S4.SS1.p1` defines the real diagonal precision `Λ` on the cosine grid, an orthogonal real matrix `O`, and `A = OΛOᵀ`. `S2.SS0.SSS0.Px1.p1` and `A3.SS4.p3.1` define the target as `N(0,A^{-1})`. `S4.SS2.SSS0.Px3.p2.1` identifies the rotated-coordinate law as `N(0,Λ^{-1})`.

The displayed type uses these same literal matrices and the map `R(z)=Oz` on `EuclideanSpace ℝ (Fin d)`. Its measures have the literal mean parameter zero and covariance parameters `Λ⁻¹` and `A⁻¹`. The approved meanings make the bundled-coordinate conversions ordinary coordinate conversions; they add no randomization, scaling, change of norm, or choice of representative. The decoder reconstructs the same objects and identifies the parameters as covariances.

For the grid, the source's index `j∈{1,…,d}` and type's `i∈Fin d` are related by `j=i.val+1`. Consequently `(j−1/2)π/d = (i.val+1/2)π/d` exactly. The affine cosine spectrum is identical. `Λ⁻¹` and `A⁻¹` denote square-matrix inverses, while the scalar `λ_i⁻¹` in the private signature is a reciprocal.

Result: objects aligned after the explicit index bijection.

### 2. Domains

The source hard family has integer `d≥2`, real `κ≥2`, `O∈O(d)`, and vectors in ordinary real Euclidean `d`-space. The displayed type has exactly `d:ℕ`, `hd:2≤d`, `κ:ℝ`, `hκ:2≤κ`, and the full real `Matrix.orthogonalGroup (Fin d) ℝ`. The approved group meaning includes both determinant signs and both transpose-inverse identities. The decoder retains these domains and no determinant-one restriction.

The source's general precision class in Section 2 also permits `d≥1`, `κ≥1`, but this candidate explicitly addresses the narrower Section 4 hard-family auxiliary; it does not purport to state a general rotation theorem over all Gaussian covariances. All matrices in this auxiliary are nondegenerate: the raw C.4 argument gives `1<λ_i<κ`, so `Λ` and its orthogonal conjugate are positive definite, as are their inverses. This is a consequence of the source parameter domain, not an extra hypothesis.

Result: hard-family domains aligned; general Gaussian-rotation generality is not claimed.

### 3. Quantifiers

The type is universal in dimension, conditioning parameter, and each fixed orthogonal `O`. Every displayed `let` is local to that choice. There is no existential witness, chosen covariance, algorithm, query budget, concentration event, probability threshold, or additional constant.

The paper draws `O` randomly to construct a hard input, then speaks of an exact conditional target draw `Y|O∼π_A`. Its Gaussian target is nevertheless defined for each admissible matrix, and Lemma 4.6 explicitly establishes admissibility for every `O`. The displayed theorem isolates the deterministic Gaussian transformation fact for every fixed `O`; it does not state a joint law for `(O,Y)`, independence of a target sample from `O`, a conditional-probability version, or a measurable kernel construction. Those are separate experiment-level assertions.

The conditional sentence by itself is ordinarily interpreted up to almost-everywhere conditioning versions. The every-fixed-`O` auxiliary is supported by the actual source definitions and ordinary Gaussian linear transformation for each orthogonal matrix; it must not be advertised as having constructed or verified a conditional law for a random basis. The packet's attributed auxiliary wording correctly limits its claim to the fixed basis.

Result: quantifiers aligned with the stated auxiliary, with the random/conditional experiment explicitly outside its conclusion.

### 4. Assumptions

The only visible logical restrictions are `2≤d`, `2≤κ`, and orthogonality carried by the type of `O`. Dimension/real-field carriers are typing; the numerical ranges and orthogonal domain come directly from the hard-family setup. The squared-norm private signature has the same restrictions. It makes `Integrable` a conclusion, not an assumed moment bound.

No visible premise assumes positive definiteness, a Gaussian-law equality, Gaussian moments, normalizer equality, integrability, measurability of the rotation, the sought norm mean, a completed producer theorem, or a target-pass event. The source implies positive definiteness internally from the grid and orthogonality; the rotation is an ordinary continuous linear map. The selected raw proof uses finite Gaussian moments inside its argument. Those proof ingredients have not been moved into displayed public binders.

The paraphrase says that an existing admissibility theorem supplies positive definiteness internally. I have not observed such a call or the proof body. The proposition needs no extra positive-definiteness binder, but actual discharge and dependency use remain to be examined later.

Result: no excess assumption visible in the selective signatures. This is not a whole-module binder audit.

### 5. Conclusion

The public conclusion is an equality of measures:

\[
(R_O)_\#\gamma_{0,\Lambda^{-1}}=\gamma_{0,(O\Lambda O^\top)^{-1}},\qquad R_Oz=Oz.
\]

Here `γ` is the Gaussian probability with the displayed mean and covariance according to the supplied approved construction. The raw sentence instead starts with target `Y` and states that `U=OᵀY` has the diagonal inverse-precision Gaussian law. For a fixed orthogonal `O`, these are equivalent law identities: `O` and `Oᵀ` are inverse linear maps, so applying the inverse pushforward reverses either identity. This does not rely on equality of moments alone or treat an arbitrary law with the same covariance as Gaussian.

The blind reconstruction gives exactly this forward-pushforward equality, including its Borel-set formulation. That formulation is equivalent because the rotation is measurable. It does not strengthen the proposition to a pointwise density equality, a joint coupling, or a sample-by-sample equality between separately chosen Gaussian variables.

The private proposition is

\[
\|x\|^2\in L^1(\gamma_{0,A^{-1}}),\qquad
\int\|x\|^2\,d\gamma_{0,A^{-1}}=\sum_i\lambda_i^{-1}.
\]

This matches the raw `M=Σ_i 1/λ_i` in `A3.Ex140`, together with the squared-norm identity for the rotated target in `S4.SS2.SSS0.Px3.p2.1` and the Gaussian moment facts used in C.3. The `Integrable` conclusion ensures that the displayed real integral has its ordinary finite expectation meaning. The signature only asserts the finite inverse-spectrum mean, not the closed formula for `M` or any variance/cosine-moment statement.

Result: public conclusion equivalent to the fixed-basis source law auxiliary; private conclusion source-supported within its limited scope. Actual proof and consumption remain unobserved.

### 6. Scopes, senses, and definition semantics

The visible public relation is exact equality of Borel probability measures on the finite real Euclidean space. It is neither an accuracy approximation nor an event estimate. Means are zero vectors; the Gaussian covariance parameters are the precision inverses. The norm in the private proposition is the ordinary Euclidean L2 norm, matching the source.

The type's `Measure.map` has the usual pushforward meaning on the continuous matrix-vector map, so no nonmeasurable-map fallback is relevant here. The local grid, diagonal matrix, conjugation, and coordinate map definitions are literal source formulas after reindexing.

The approved Gaussian context defines `multivariateGaussian m S` by mapping a standard covariance-one Gaussian through `x↦m+sqrt(S)x`; on positive-semidefinite `S` this has mean `m` and covariance `S`. This is a construction of the source's ordinary `N(m,S)` meaning on the parameters used here. Its documented off-positive-semidefinite zero-square-root/Dirac extension, and the total matrix-inverse operation outside nonsingular inputs, do not affect this theorem because its displayed hypotheses imply positive-definite `Λ`, `A`, and their inverses. No source-specific fallback object is introduced by the local definitions. I did not inspect actual library bodies in phase 2; these semantics are the approved selective definition context, not a newly checked library implementation.

The decoder restricts its explanatory `γ_{0,S}` convention to positive-semidefinite `S` and explicitly notes that the actual matrices are positive definite. Omitting discussion of the unreachable off-domain fallback from the reconstruction loses no in-domain meaning. It also correctly retains matrix inverse versus scalar division and full orthogonal group versus determinant-one subgroup.

Result: the displayed definitions agree in the reachable source domain under the approved meanings; actual library/body and full-module verification are deferred.

### 7. Constants and dependencies

The local constants are the source's `0`, `1/2`, `π`, and the hard-family lower bounds `d≥2`, `κ≥2`. The equality has no unspecified multiplicative or asymptotic constant, no hidden dependence on `O`, and no probability of failure. The private mean has exactly `d` inverse-eigenvalue summands.

The source's `n`, query budget `q`, bias constants `1−e^{-4}`, `2`, `3`, the closed `M` expression involving `r`, and variance constants are absent because neither displayed proposition claims the corresponding parts of Lemma 4.5. Those parts remain outside this auxiliary's scope. This is a limitation that must remain visible, not a changed constant in a claimed full-moment theorem.

Result: no constant drift within the claimed law/norm-mean auxiliary.

## Private semantic consumption versus code evidence

The private signature's measure is literally `multivariateGaussian 0 A⁻¹`; its integrand is literally the squared Euclidean norm; its right side is the literal inverse-spectrum sum. Thus it can serve as a semantic consumer of the rotated Gaussian-law auxiliary: one may transport the squared norm and then use diagonal Gaussian moments. This is a compatible mathematical interface.

I have not seen its proof, any invocation name, any dependency extraction, the theorem's enclosing module, or its actual compiled use. It could in principle be proved along a different valid route. Neither the presence of this signature nor the source paraphrase's assertion of internal reuse establishes actual reuse. The later immutable-module review must inspect what is really called and discharged.

## Differences and remaining boundary

The observed differences are representational or explicitly scoped: zero-based indexing; forward versus inverse rotation of laws; a fixed-basis auxiliary separated from the random conditional experiment; a standard-library Gaussian construction with unreachable off-domain totalizations; and explicit integrability as a private conclusion. None requires a source repair on the visible propositions.

The unreviewed boundaries are concrete: actual implementation and scoped-module context; actual producer/consumer calls and all hidden proof assumptions; proof cleanliness and compiler/native evidence; authored formula proofs and their use of the source; full publication correspondence; source-proof topology; and rendered reader delivery. The packet's `compiled:true`, role/access metadata, and content hashes identify supplied claims and bytes; they do not establish these deferred facts by themselves.

The phase-1 exposure caveats remain in force: three prior-review directory names were printed without opening their contents, a broad scan displayed additional formulas only from the pinned raw source, and ordinary pretraining familiarity cannot be ruled out. No pristine-recognition claim is made. This phase stops before the immutable candidate and full-module/source/reader inputs.
