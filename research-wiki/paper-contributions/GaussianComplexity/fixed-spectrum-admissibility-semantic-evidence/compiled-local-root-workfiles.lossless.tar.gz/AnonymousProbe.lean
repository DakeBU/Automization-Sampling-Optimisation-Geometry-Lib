import AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumAdmissibility
open Matrix
set_option autoImplicit false
example : (
∀ {d : ℕ} (hd : 2 ≤ d)
    {κ : ℝ} (hκ : 2 ≤ κ)
    (O : Matrix.orthogonalGroup (Fin d) ℝ),
    let θ : Fin d → ℝ := fun i => ((i.val : ℝ) + 1 / 2) * Real.pi / (d : ℝ)
    let A : Matrix (Fin d) (Fin d) ℝ :=
      (O : Matrix (Fin d) (Fin d) ℝ) *
        Matrix.diagonal (fun i => (κ + 1) / 2 + (κ - 1) / 2 * Real.cos (θ i)) *
        (O : Matrix (Fin d) (Fin d) ℝ).transpose
    A.PosDef ∧ (A - 1).PosSemidef ∧
      (κ • (1 : Matrix (Fin d) (Fin d) ℝ) - A).PosSemidef
) ↔ (
∀ {d : ℕ} (hd : 2 ≤ d)
    {κ : ℝ} (hκ : 2 ≤ κ)
    (O : Matrix.orthogonalGroup (Fin d) ℝ),
    let θ : Fin d → ℝ := fun i => ((i.val : ℝ) + 1 / 2) * Real.pi / (d : ℝ)
    let A : Matrix (Fin d) (Fin d) ℝ :=
      (O : Matrix (Fin d) (Fin d) ℝ) *
        Matrix.diagonal (fun i => (κ + 1) / 2 + (κ - 1) / 2 * Real.cos (θ i)) *
        (O : Matrix (Fin d) (Fin d) ℝ).transpose
    (A.IsHermitian ∧ ∀ ⦃x : Fin d →₀ ℝ⦄, x ≠ 0 →
      0 < x.sum (fun i xi => x.sum (fun j xj => star xi * A i j * xj))) ∧
    ((A - 1).IsHermitian ∧ ∀ x : Fin d →₀ ℝ,
      0 ≤ x.sum (fun i xi => x.sum (fun j xj => star xi * (A - 1) i j * xj))) ∧
    ((κ • (1 : Matrix (Fin d) (Fin d) ℝ) - A).IsHermitian ∧ ∀ x : Fin d →₀ ℝ,
      0 ≤ x.sum (fun i xi => x.sum (fun j xj =>
        star xi * (κ • (1 : Matrix (Fin d) (Fin d) ℝ) - A) i j * xj)))
) := Iff.rfl
example : (
∀ {d : ℕ} (hd : 2 ≤ d)
    {κ : ℝ} (hκ : 2 ≤ κ)
    (O : Matrix.orthogonalGroup (Fin d) ℝ),
    let θ : Fin d → ℝ := fun i => ((i.val : ℝ) + 1 / 2) * Real.pi / (d : ℝ)
    let A : Matrix (Fin d) (Fin d) ℝ :=
      (O : Matrix (Fin d) (Fin d) ℝ) *
        Matrix.diagonal (fun i => (κ + 1) / 2 + (κ - 1) / 2 * Real.cos (θ i)) *
        (O : Matrix (Fin d) (Fin d) ℝ).transpose
    A.PosDef ∧ (A - 1).PosSemidef ∧
      (κ • (1 : Matrix (Fin d) (Fin d) ℝ) - A).PosSemidef
) := by
  intro d hd κ hκ O
  exact AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumAdmissibility.actual_precision_admissible hd hκ O
