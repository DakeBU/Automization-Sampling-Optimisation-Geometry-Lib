"""Future read-only acceptance guards. Import defines helpers; it creates no evidence."""
from pathlib import Path
import argparse, datetime, gzip, hashlib, json, os, re, struct, subprocess, sys, tarfile
sys.dont_write_bytecode=True
R=Path('/Users/zhouhuanjian/ASTIS-GC')
S=R/'.astis/huanjian-gc-fixed-spectrum-normalizer-integration-20261108/independent-reader'
O=R/'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-normalizer-integration-20261108/independent-reader'
P=O/'proposal-v2'
ACTOR='/root/norm_integration_reader'
ADV='ASTIS-SA-20261108-GaussianComplexityFixedSpectrumNormalizer'
OWNER='huanjian_gc_20261108_fixed_spectrum_normalizer'
CELL='ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-normalizer'
MATH='8d33e06485edc17320cc01308af40da44945659d'
BINDING='b2f41e36a9d705ff68da71f72f0ec14f1cd2ff105bcf0ae5000ef1406a5d1f41'
DECL='AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumNormalizer.actual_normalizing_integral'
ADMISS='AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumAdmissibility.actual_precision_admissible'
DET='AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumDeterminant.actual_precision_det'
GPD='AutoSamplingTheory.TechnicalLemmas.Measure.GaussianPrecisionDensity.multivariateGaussian_eq_withDensity_of_posDef'
PARENTS=[ADMISS,DET,GPD]
CONSUMER=PARENTS+[DECL]
REPORT_SHA='64b266f7c9f9bbd3cfe6421346022c78f2f841ab5122d8b1e6dee64288cc3920'
FREEZE_SHA='cb1f1630c6877efb3c48cccd5bb0f2e8c1439ef4e7db8dc30c9abab745738927'
AUDIT='research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-normalizer.json'
CHECKER=S/'check_final_reader_v2.py'
HEX64=re.compile(r'[0-9a-f]{64}\Z'); COMMIT=re.compile(r'[0-9a-f]{40}\Z')
sha=lambda b:hashlib.sha256(b).hexdigest()
canon=lambda x:json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
dump=lambda x:(json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode()
def cmd(*args):return subprocess.check_output(args,cwd=R)
def head():return cmd('git','rev-parse','HEAD').decode().strip()
def gitraw(c,p):return cmd('git','show',c+':'+p)
def rel(p):return str(p.relative_to(R))
def resolve(p):
 assert isinstance(p,str) and p and '\x00' not in p
 q=Path(p);q=(q if q.is_absolute() else R/q).resolve();assert q.is_relative_to(R),str(q);return q
def read_ref(ref):
 assert isinstance(ref,dict) and HEX64.fullmatch(ref['sha256'])
 raw=resolve(ref['path']).read_bytes();assert sha(raw)==ref['sha256'],ref['path'];return raw
def json_ref(ref):return json.loads(read_ref(ref))
def decoded_ref(ref):
 raw=read_ref(ref);assert ref.get('encoding','raw') in ('raw','gzip');return gzip.decompress(raw) if ref.get('encoding')=='gzip' else raw
def unpack(row):
 raw=resolve(row['path']).read_bytes();assert sha(raw)==row['gzip_sha256'];data=gzip.decompress(raw)
 assert sha(data)==row['raw_sha256'] and len(data)==row['raw_bytes'];return data
def modules():
 if str(R/'tools') not in sys.path:sys.path.insert(0,str(R/'tools'))
 import astis_advance,astis_publication,astis_site
 return astis_advance,astis_publication,astis_site
def parse_args(description):
 p=argparse.ArgumentParser(description=description);p.add_argument('--authorization-json',required=True);p.add_argument('--authorization-sha256',required=True);p.add_argument('--output');return p.parse_args()
def load_authorization(args):
 ref={'path':args.authorization_json,'sha256':args.authorization_sha256};a=json_ref(ref)
 assert a['authorized_by']=='/root' and a['authorization_kind']=='normalizer-postcore-readonly-context'
 assert a['advance_id']==ADV and a['proof_owner_to_preserve']==OWNER
 assert a['new_source_verdict'] is False and a['parking_authorized'] is False
 assert a['publication_binding_sha256']==BINDING and a['proposal_report_sha256']==REPORT_SHA
 assert COMMIT.fullmatch(a['accepted_immutable_core']) and HEX64.fullmatch(a['source_digest'])
 assert HEX64.fullmatch(a['browser_checker_sha256']) and sha(CHECKER.read_bytes())==a['browser_checker_sha256']
 assert a['source_verifier_to_preserve'] not in (ACTOR,OWNER,'/root')
 assert a['integration_owner'] not in (ACTOR,a['source_verifier_to_preserve'])
 return a,ref
def source_lineage(a):
 adv,_,_=modules();core=a['accepted_immutable_core'];l=a['source_lineage'];checked=l['checked_commit'];first=l['source_V_first_commit'];accepted=l['accepted_audit_first_commit']
 for c in [checked,first,accepted]:assert COMMIT.fullmatch(c)
 for x,y in [(MATH,checked),(checked,accepted),(accepted,first),(first,core)]:cmd('git','merge-base','--is-ancestor',x,y)
 raw=read_ref(l['accepted_audit']);audit_sha=sha(raw);assert rel(resolve(l['accepted_audit']['path']))==AUDIT
 assert raw==(R/AUDIT).read_bytes()==gitraw(core,AUDIT)==gitraw(first,AUDIT)==gitraw(accepted,AUDIT)
 audit=json.loads(raw);assert audit['state']=='accepted' and audit['publication_binding_sha256']==BINDING
 assert audit['lean']['formalizer']==OWNER and audit['source_review']['reviewer']==a['source_verifier_to_preserve']
 assert audit['reconstruction']['decoder'] not in (OWNER,ACTOR,'/root',a['source_verifier_to_preserve'])
 run=read_ref(l['source_review_run']);assert sha(run)==audit['source_review']['review_run_sha256']
 assert resolve(l['source_review_run']['path'])==resolve(audit['source_review']['run_artifact'])
 before=decoded_ref(l['source_V_before']);after=decoded_ref(l['source_V_after']);append=decoded_ref(l['source_V_append'])
 assert before.endswith(b'\n') and append.endswith(b'\n') and len(append.splitlines())==1 and after==before+append
 assert gitraw(checked,'runs/substantive_advances.jsonl')==before and gitraw(first,'runs/substantive_advances.jsonl')==after
 event=json.loads(append);e=event['evidence'];v=a['source_verifier_to_preserve']
 assert event['advance_id']==ADV and event['worker_id']==v and event['from_state']=='PROVED_LOCAL' and event['to_state']=='VERIFIED'
 assert e['verifier_id']==v and e['verified_commit']==checked and all(e[k] for k in ['gate','source_audit','fake_closure_scan'])
 assert json_ref(l['source_V_API_receipt']).get('returncode',json_ref(l['source_V_API_receipt']).get('exit_code'))==0
 raw=(R/'runs/substantive_advances.jsonl').read_bytes();assert raw.startswith(after) and raw.count(append)==1
 tail=raw[len(after):];assert len(tail.splitlines())==1
 stab=json.loads(tail);assert stab['advance_id']==ADV and stab['worker_id']==a['integration_owner'] and stab['from_state']=='VERIFIED' and stab['to_state']=='STABILIZING'
 states=adv.current_advances();own=states[ADV]
 assert own['owner_id']==OWNER and own['state']=='STABILIZING' and [k for k,v in states.items() if v['state']=='STABILIZING']==[ADV]
 assert own['latest_evidence']['integration_owner']==a['integration_owner']
 return {'checked_commit':checked,'accepted_audit_first_commit':accepted,'source_V_first_commit':first,'audit_sha256':audit_sha,'source_verifier_preserved':v,'proof_owner_preserved':OWNER,'new_source_verdict':False,'source_V_append_sha256':sha(append),'source_review_run_sha256':sha(run)}
def protections(a):
 adv,pub,_=modules();core=a['accepted_immutable_core'];assert head()==core
 assert sha((P/'proposal-report.json').read_bytes())==REPORT_SHA and sha((P/'freeze.json').read_bytes())==FREEZE_SHA
 p=json.loads((P/'proposal-report.json').read_bytes());assert len(p['shared_paths'])==6 and p['formal_ASTIS_producer_parents']==PARENTS
 for row in p['shared_paths']:
  raw=(R/row['path']).read_bytes();assert sha(raw)==row['planned_after_sha256'] and raw==unpack(row['planned_after_archive'])==gitraw(core,row['path']),row['path']
 for path,digest in {**p['source_Test_lesson_publication_pins'],**p['unchanged_models']}.items():assert sha((R/path).read_bytes())==digest and gitraw(core,path)==(R/path).read_bytes(),path
 item=next(x for x in pub.load() if x['id']=='huanjian-fixed-spectrum-normalizer');assert pub.binding_digest(item,item['bindings'][0])==BINDING
 f=json.loads((R/'website/content/samplewiki_companion_frontiers.json').read_bytes());v=p['protected_case_values']
 assert sha(canon(f['execution']))==v['execution_sha256'] and sha(canon(f['cases'][4]['theorems'][0]))==v['determinant_theorem_index0_sha256']
 assert f['cases'][4]['theorems'][1]['boundary'].endswith(v['Section4_4_limitation_suffix'])
 f['cases'][4]['reader_guide'][3]='<OWN_NORMALIZER_SCALAR>';f['cases'][4]['theorems'][1]['boundary']='<OWN_NORMALIZER_SCALAR>';assert sha(canon(f))==v['all_other_case_values_sha256']
 states=adv.current_advances();discs=adv.current_discoveries();counts={}
 for path,row in p['ledger_protection'].items():
  raw=(R/path).read_bytes();assert raw.startswith(unpack(row['raw_prefix'])) and raw.endswith(b'\n')
  expected=json.loads(unpack(row['foreign_projection']));now={k:v for k,v in states.items() if k!=ADV} if 'advances' in path else {k:v for k,v in discs.items() if v.get('advance_id')!=ADV}
  assert now==expected;counts[path]=len(now)
 protected=json.loads(unpack(p['protected_foreign_content']))
 for path,row in protected.items():
  q=R/path;raw=os.fsencode(os.readlink(q)) if q.is_symlink() else q.read_bytes();assert sha(raw)==row['sha256'] and len(raw)==row['bytes'],path
 current={}
 for line in cmd('git','ls-files','--stage','-z').split(b'\0'):
  if line:
   md,path=line.split(b'\t',1);mode,blob,stage=md.decode().split();assert stage=='0';current[os.fsdecode(path)]=[mode,blob]
 for path,row in json.loads(unpack(p['protected_git_objects'])).items():assert current.get(path)==row,path
 for field in ['foreign_frontiers','older_GaussianComplexity_evidence']:
  for path,digest in json.loads(unpack(p[field])).items():assert sha((R/path).read_bytes())==digest,path
 expectedfrontiers=json.loads(unpack(p['foreign_frontiers']))
 currentfrontiers={rel(q):sha(q.read_bytes()) for q in (R/'research-wiki/frontier-cells').glob('*.json') if q.stem!=CELL}
 assert currentfrontiers==expectedfrontiers
 atlas=(R/'.atlas-upstream').stat();expected=p['untracked_Atlas'];assert (atlas.st_dev,atlas.st_ino,atlas.st_mtime_ns)==(expected['device'],expected['inode'],expected['mtime_ns'])
 return {'six_after_payloads_exact':True,'foreign_counts':counts,'all442_old_frontiers_and_older_GC_evidence_preserved':True,'all_foreign_tracked_bytes_preserved':True,'models_unchanged':p['unchanged_models'],'GPD_source_publication_debt_preserved':True,'README_protected':p['README_preservation']}
def authorized_context(a):return {'sourceV_lineage':source_lineage(a),'protection':protections(a)}
def actual_checks(a):
 _,_,site=modules();core=a['accepted_immutable_core'];gate=json_ref(a['actual_gate']);meta=json_ref(a['site_metadata'])
 assert resolve(a['actual_gate']['path'])==R/'.astis/site-lean-gate.json' and resolve(a['site_metadata']['path'])==R/'_site/data/build-metadata.json'
 assert gate['passed'] and meta['gate']['passed'] and meta['gate']['current'] and gate['commit']==meta['git']['commit']==head()==core
 assert gate['source_digest']==meta['source_digest']==site.source_digest()==a['source_digest']
 required={'canonical_lean':'canonical','site_build':'website/scripts/build_site.py','site_check':'website/scripts/check_site.py','graph_check':'graph-check','publication':'astis_publication.py','contributor':'astis_contributor_contract.py','semantic':'astis_semantic_roundtrip.py','frontier':'astis_frontier_cells.py','browser':rel(CHECKER)}
 assert set(a['actual_checks'])==set(required);rows=[]
 for role,needle in required.items():
  ref=a['actual_checks'][role];r=json_ref(ref);assert r['exit_code']==0 and r['head_before']==r['head_after']==core and r['elapsed_seconds']>=0
  raw=resolve(r['log']).read_bytes();assert sha(raw)==r['log_sha256'];command=r['command'];assert isinstance(command,list) and all(isinstance(x,str) for x in command)
  if role=='canonical_lean':
   output=raw.decode();assert output.splitlines().count('ASTIS check passed')==1
   assert command[1:] in (['tools/astis.py','check'],['website/scripts/lean_gate.py'])
   if command[1:]==['website/scripts/lean_gate.py']:
    wrapper='website/scripts/lean_gate.py';assert (R/wrapper).read_bytes()==gitraw(core,wrapper) and sha((R/wrapper).read_bytes())=='d69c42b3aee3a60775646711f220e8c558fb447af741616d88bdb8df82d18f91'
    assert gate['commands']==['python3 tools/astis.py check']
    marker='Recorded current Lean gate evidence at .astis/site-lean-gate.json';assert output.splitlines().count(marker)==1 and output.rstrip().endswith(marker)
    start=datetime.datetime.strptime(r['started_utc'],'%Y%m%dT%H%M%S%fZ').replace(tzinfo=datetime.timezone.utc);recorded=datetime.datetime.fromisoformat(gate['generated_at']);assert recorded.tzinfo is not None and 0<=(recorded-start).total_seconds()<=r['elapsed_seconds']+2
  else:assert needle in str(command),(role,command)
  rows.append({'role':role,'receipt':ref,'raw_log_sha256':sha(raw),'command':command})
 return rows
def expected_png_names():
 names=set()
 for w in (1440,390):
  for n in ['first','assumptions',*[f'proof-step{i}' for i in range(1,7)],'standard-reuse','exact-statement','exact-proof','module','source-index-open','graph-focused','graph-module-native-click']:
   names.add(f'actual-{w}-{n}.png')
  for n in [f'case-boundary-{w}',f'source-index-{w}',*[f'canonical-parent{i}-{w}-graph-native-parent-click' for i in range(1,4)],f'canonical-Gaussian-{w}-graph-focused',f'canonical-GPD-{w}-debt-card',f'existing-conceptual-{w}-unchanged']:names.add(n+'.png')
 assert len(names)==46;return names
def browser_evidence(a):
 b=json_ref(a['browser_report']);p=resolve(a['browser_report']['path']);assert p.name=='report.json' and p.parent.is_relative_to(S/'browser')
 assert b['status']=='passed' and b['errors']==[] and b['head']==b['actual_gate_commit']==b['site_commit']==a['accepted_immutable_core']
 assert b['source_digest']==a['source_digest'] and b['publication_binding_sha256']==BINDING and b['producer_ASTIS_parents']==PARENTS and b['consumer_ASTIS_parents']==CONSUMER
 assert b['site_metadata_sha256']==a['site_metadata']['sha256'] and b['actual_gate_sha256']==a['actual_gate']['sha256'] and b['external_GitHub_HTML_checked'] is False
 assert len(b['pages'])==2 and {x['width'] for x in b['pages']}=={1440,390}
 for row in b['pages']:
  assert row['target']==DECL and row['producer_ASTIS_parents']==PARENTS and row['consumer_ASTIS_parents']==CONSUMER and row['fullpage_overflow'] is False
  for key in ['closed_initially','six_formula_steps_opened','adjacent_exact_statement_and_proof','full_module_download_immutable_git_bytes_verified','consumer_private_name_only']:assert row[key] is True
  link=row['immutable_link_syntax_checked']
  if link is None:assert row['module_link_branch']=='own-site module only; GitHub syntax branch not executed'
  else:assert re.fullmatch(r'https://github\.com/[^/]+/[^/]+/blob/'+a['accepted_immutable_core']+r'/AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumNormalizer\.lean#L\d+(?:-L\d+)?',link)
 assert len(b['visible_source_index_clicks'])==2 and all(x['actual_click'] for x in b['visible_source_index_clicks'])
 assert len(b['GPD_debt_cards'])==2 and all(x['actual_visible_warning_checked'] and x['native_canonical_reader_click'] and x['native_inventory_card_click'] for x in b['GPD_debt_cards'])
 assert len(b['screenshots'])==46 and {x['file'] for x in b['screenshots']}==expected_png_names()=={x.name for x in p.parent.glob('*.png')}
 images=[]
 for row in b['screenshots']:
  q=p.parent/row['file'];raw=q.read_bytes();assert sha(raw)==row['sha256'] and raw[:8]==b'\x89PNG\r\n\x1a\n';w,h=struct.unpack('>II',raw[16:24]);assert (w,h) in [(1440,1000),(390,844)] and f'-{w}' in q.name
  images.append({'path':rel(q),'sha256':sha(raw),'width':w,'height':h,'bytes':len(raw)})
 return b,images
def validate_visual_review(a,images):
 review=json_ref(a['independent_original_image_review']);assert review['reviewer']==ACTOR and review['state']=='ORIGINAL46_REVIEW_COMPLETED'
 assert review['accepted_immutable_core']==a['accepted_immutable_core'] and review['browser_report_sha256']==a['browser_report']['sha256'] and review['blocking_objections']==[]
 expected={x['path']:x for x in images};assert len(review['images'])==46 and {x['path'] for x in review['images']}==set(expected)
 for row in review['images']:
  assert all(row[k]==expected[row['path']][k] for k in ['sha256','width','height']) and row['reviewer']==ACTOR and row['actually_viewed_original'] is True
  assert isinstance(row['observation'],str) and len(row['observation'].strip())>=32
 assert review['raw_receipts_actually_read'] is True and review['foreign_graph_delta_actually_reviewed'] is True
 return review
def verify_lossless_archive(a,images):
 m=json_ref(a['retained_archive_manifest']);raw=resolve(m['archive']).read_bytes();assert sha(raw)==m['archive_sha256']
 expected={x['path']:x['sha256'] for x in images};expected[a['browser_report']['path']]=a['browser_report']['sha256']
 assert len(m['files'])==47 and {x['original'] for x in m['files']}==set(expected)
 with tarfile.open(resolve(m['archive']),'r:gz') as tar:
  members=tar.getmembers();assert len(members)==47 and {x.name for x in members}=={x['member'] for x in m['files']}
  assert all(x.isfile() and not Path(x.name).is_absolute() and '..' not in Path(x.name).parts for x in members)
  for row in m['files']:
   original=resolve(row['original']).read_bytes();assert sha(original)==row['raw_sha256']==expected[row['original']] and tar.extractfile(row['member']).read()==original
 return {'archive_sha256':sha(raw),'actual_original_PNGs':46,'lossless47members':True,'visual_review_performed_by_archive_checker':False}
def write_result(path,value):
 p=resolve(path);assert p.is_relative_to(O) and p.suffix=='.json' and not p.exists();p.parent.mkdir(parents=True,exist_ok=True)
 value=dict(value);value['recorded_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();p.write_bytes(dump(value));return {'path':rel(p),'sha256':sha(p.read_bytes())}
