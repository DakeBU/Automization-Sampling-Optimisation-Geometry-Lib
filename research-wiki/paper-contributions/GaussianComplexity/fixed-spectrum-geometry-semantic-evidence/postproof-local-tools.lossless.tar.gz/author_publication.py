from pathlib import Path
import hashlib, json, sys
sys.path.insert(0, 'tools')
import astis_publication as pub
import astis_semantic_roundtrip as rt

P = Path('.astis/huanjian-gc-fixed-spectrum-geometry-20261109')
B = Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-geometry-semantic-evidence')
S = json.loads(Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-geometry-statement-seal.json').read_bytes())
sha = lambda x: hashlib.sha256(x.encode() if isinstance(x, str) else x).hexdigest()
def put(p, x):
    p = Path(p)
    assert not p.exists(), str(p)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(x, ensure_ascii=False, indent=2)+'\n')
name, file, sig = S['producer']['declaration'], S['producer']['planned_file'], S['producer']['signature']
code = Path(file).read_text()
assert code[code.index('theorem actual_potential_geometry'):].split(' := by', 1)[0]+'\n' == sig
test = Path(S['private_actual_consumer']['planned_file'])
tc = test.read_text()
assert tc[tc.index('private theorem actual_first_order_oracle_measurable'):].split(' := by', 1)[0]+'\n' == S['private_actual_consumer']['signature']
focus = Path('.astis/huanjian-resume-20261103/20261108T182641603446Z-fixed-spectrum-geometry-actual-Borel-consumer-notation-scope.receipt.json')
kernel = Path('.astis/huanjian-resume-20261103/20261108T183227132529Z-fixed-spectrum-geometry-kernel-and-exact-meaning-scaffold-v2.receipt.json')
for p in [focus, kernel]:
    r = json.loads(p.read_bytes())
    assert r['exit_code'] == 0 and sha(Path(r['log']).read_bytes()) == r['log_sha256']
klog = Path(json.loads(kernel.read_bytes())['log']).read_text()
assert klog.count('ACTUAL_ASTIS_PARENT ') == 5
assert 'Exact sealed full-forall producer application and literal private-consumer type application checked.' in klog
flog = Path(json.loads(focus.read_bytes())['log']).read_text()
assert flog.count('depends on axioms: [propext,') == 2 and 'sorryAx' not in flog
admiss = 'AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumAdmissibility.actual_precision_admissible'
first = 'AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumFirstOrder.actual_first_order_query'
converse = 'AutoSamplingTheory.TechnicalLemmas.Analysis.StrongConvexGradientConverse.strongConvexOn_of_gradient_inner_lower_bound'
parents = [admiss, first, converse]
short = 'The actual quadratic is globally C∞, 1-strongly convex and κ-smooth, with zero minimum uniquely at the origin.'
formula = r'D(\nabla f_A)(x)=A.'
assumptions = [
    r'Let \(d\in\mathbb N\) with \(d\ge2\), let \(\kappa\in\mathbb R\) with \(\kappa\ge2\), and fix any full real \(O\in O(d)\), including either determinant sign.',
    r'For \(i=1,\ldots,d\), set \(\theta_i=(i-\tfrac12)\pi/d\), \(\lambda_i=(\kappa+1)/2+(\kappa-1)\cos\theta_i/2\), and \(A=O\operatorname{diag}(\lambda_i)O^\top\). The zero-based Lean coordinate \(j\) represents \(i=j.\mathrm{val}+1\).',
    r'The potential is literally \(f_A(x)=x^\top Ax/2\) on all Euclidean \(\mathbb R^d\), with no additive shift. All spatial points and pairs are arbitrary.',
    r'The Hessian is the genuine real Fréchet derivative of the Euclidean gradient. Strong convexity uses the modulus \(r^2/2\); smoothness means \(\|\nabla f_A(x)-\nabla f_A(y)\|\le\kappa\|x-y\|\).',
    'Symmetry, spectral bounds, differentiability, Hessian, convexity, norm bounds and minimizer properties are produced internally. They are not extra caller assumptions. Haar randomness, seeds and query budgets are outside this local statement.'
]
steps = [
    {'title': 'Write the same quadratic and establish smoothness', 'text': 'Represent the actual matrix action by its continuous linear map H. Its coordinates and Euclidean inner product give the same potential. The identity map, H, inner product and scalar multiplication are smooth of every finite order.', 'formula': r'Hx=Ax,\qquad f_A(x)=\tfrac12\langle x,Hx\rangle\in C^\infty.', 'lean': 'hf is the coordinate identity from Matrix.inner_toEuclideanCLM. hcinfty uses ContDiff.inner and ContDiff.mul on the actual f; infinity is ordinary C-infinity, distinct from analytic omega.'},
    {'title': 'Differentiate the genuine gradient', 'text': 'The existing exact first-order result constructs the actual gradient Ax at every point. Its equality with the fixed linear map H turns the derivative of the gradient into H itself.', 'formula': r'\nabla f_A(x)=Hx,\qquad D(\nabla f_A)(x)[v]=Hv.', 'lean': 'hgrad invokes canonical actual_first_order_query, hg identifies the total gradient after genuine existence, and hhessian rewrites by that identity before applying H.hasFDerivAt.'},
    {'title': 'Use the produced lower and upper quadratic bounds', 'text': 'Apply the existing actual admissibility theorem to the literal source matrix. Positive semidefiniteness of A−I and κI−A gives both Euclidean quadratic inequalities. No matrix certificate is supplied by the caller.', 'formula': r'\|v\|^2\le\langle v,Hv\rangle\le\kappa\|v\|^2.', 'lean': 'hA is the canonical actual_precision_admissible result. hquad converts its PSD outputs through the exact CLM action; hlower and hupper use inner_self_eq_norm_sq. The source strict grid prefix remains a separate source route; these closed bounds are already supplied by the canonical parent.'},
    {'title': 'Obtain the source strong-convexity constant', 'text': 'Linearity converts the lower quadratic bound into quantitative monotonicity of the genuine gradient. The existing canonical gradient criterion gives strong convexity with modulus one, including the required one-half normalization.', 'formula': r'\langle\nabla f_A(y)-\nabla f_A(x),y-x\rangle\ge\|y-x\|^2.', 'lean': 'hstrong actually invokes StrongConvexGradientConverse.strongConvexOn_of_gradient_inner_lower_bound with produced hgrad and hlower. This is a sufficient implementation route; the author’s Hessian route remains distinct in the source graph. It adds no assumption or constant.'},
    {'title': 'Control the Euclidean gradient norm', 'text': 'For a self-adjoint operator, the absolute Rayleigh quotients determine the operator norm. The upper quadratic bound and nonnegativity bound that norm by κ. Apply it to x−y to obtain the source Lipschitz gradient inequality.', 'formula': r'\|H\|\le\kappa,\qquad\|\nabla f_A(x)-\nabla f_A(y)\|\le\kappa\|x-y\|.', 'lean': 'hnorm uses ContinuousLinearMap.norm_eq_iSup_rayleighQuotient, handling the zero vector separately. hsmooth uses H.le_opNorm. This is the induced Euclidean operator norm, with no coordinate/Frobenius norm or dimension factor.'},
    {'title': 'Identify the global minimizer', 'text': 'The literal formula gives value zero at the origin. The lower quadratic bound makes the value strictly positive at every other point, so the origin is a global minimizer and every global minimizer equals it.', 'formula': r'f_A(0)=0,\qquad f_A(x)\ge\tfrac12\|x\|^2>0\quad(x\ne0).', 'lean': 'hzero, hnonneg and hpositive prove actual values. isMinOn_iff turns the final biconditional into comparison with every global competitor; the reverse implication supplies existence at zero as well as uniqueness.'},
    {'title': 'Consume regularity for the actual fixed-input oracle', 'text': 'The private Test uses the new scalar smoothness and genuine gradient derivative to obtain continuity. It separately identifies that gradient with the same actual Ax reply, then proves the ordered value/reply pair Borel measurable for this fixed input.', 'formula': r'x\longmapsto\bigl(f_A(x),Ax\bigr)\quad\text{is Borel measurable}.', 'lean': 'hscalar consumes the new producer C-infinity output; hgradient consumes its HasFDerivAt output. hquery uses canonical actual_first_order_query, and Continuous.borel_measurable finishes the actual pair. The compiled private proof has exactly new geometry and canonical first-order parents; it is not a public or Registry node. This source-model bridge does not establish joint-in-O or adaptive histories.'}
]
boundary = ('Selected actual C4 geometric conclusions and a genuine fixed-input actual reply Borel consumer are established locally. The source strict angle/cosine prefix remains a separate source route; closed bounds are reused from canonical admissibility. Joint random-input/adaptive/seed/transcript/output-law semantics, TV and finite-precision adapters, deterministic worst-query caps and explicit expected-cost accounting, both full main lower bounds, remote acceptance and postmerge purification/Exposition Seal remain separate.')
source = {'url': 'https://arxiv.org/html/2610.20492v1#A3.SS4', 'edition': 'arXiv2610.20492v1; raw HTML SHA2566bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915', 'anchor': 'S4.SS1/E11 literal hard family; AppendixC.4 geometric properties; S2.E1 exact first-order and Borel-model context.', 'wording_status': 'faithful paraphrase', 'attribution': 'Huanjian Zhou and Taiji Suzuki, On Complexity of Gaussian Sampling.', 'scope': 'Actual literal potential C4 geometry. Fixed-input Borel reply is a separately proved source-model background bridge, not a numbered C4 assertion or a complete adaptive algorithm.'}
unit = {'kind': 'theorem', 'reading_layout': 'progressive', 'declaration': name, 'title': 'Actual fixed-spectrum potential geometry', 'reader_note': 'The geometric conclusion is shown first; the full family, assumptions, formula proof and exact Lean are folded below.', 'statement': short, 'formula': formula, 'assumptions': assumptions,
    'notation': [{'symbol': r'\(H,f_A\)', 'text': 'The exact precision action on the Euclidean carrier and the same centered source quadratic.', 'formula': r'Hx=Ax,\qquad f_A(x)=\tfrac12\langle x,Hx\rangle.'}],
    'steps': steps, 'astis_dependencies': parents,
    'mathlib_dependencies': ['Matrix.inner_toEuclideanCLM', 'Matrix.PosSemidef.dotProduct_mulVec_nonneg', 'HasGradientAt.gradient', 'ContDiff.inner', 'ContDiff.mul', 'ContinuousLinearMap.hasFDerivAt', 'ContinuousLinearMap.norm_eq_iSup_rayleighQuotient', 'ContinuousLinearMap.le_opNorm', 'isMinOn_iff'],
    'lean_statement': 'The literal source family with exactly d>=2,kappa>=2/full real O; smoothness, genuine Hessian, strong convexity, gradient bound,zero value and unique global minimizer are all outputs.',
    'lean_proof': 'The adjacent exact source uses three canonical ASTIS parents and standard Euclidean calculus, PSD and Rayleigh facts. The private actual Borel consumer genuinely uses the new regularity result plus the canonical actual first-order identity; it adds no public node or operational theorem.',
    'boundary': boundary, 'sources': [{**source, 'label': 'Zhou–Suzuki Eq11, AppendixC.4 and Section2 model'}], 'tests': ['lake build Tests.GaussianComplexityFixedSpectrumGeometry']}
lesson_path = Path('website/content/declaration_lessons/huanjian-fixed-spectrum-geometry.json')
put(lesson_path, {'schema_version': 1, 'units': [unit]})
def allstrings(x):
    if isinstance(x, str): yield x
    elif isinstance(x, dict):
        for v in x.values(): yield from allstrings(v)
    elif isinstance(x, list):
        for v in x: yield from allstrings(v)
assert not any('\\\\' in text for text in allstrings(unit)), 'Accidental doubled TeX slash'
binding = {'declaration': name, 'cell': 'ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-geometry', 'role': 'proof-edge', 'supports': ['actual-fixed-spectrum-potential-geometry'], 'boundary': boundary,
    'assumption_deltas': [
        {'source': 'Actual S4.1 family d>=2,kappa>=2 and every full real O, with literal Eq11 potential.', 'lean': 'Exactly those source inputs; all regularity, spectral/norm, convexity and minimizer facts are outputs or proved internal dependencies.', 'classification': 'same', 'reason': 'No generic A, matrix certificate, regularity or minimizer premise replaces the actual source family; both determinant signs are retained.'},
        {'source': 'C4 says C-infinity with Hessian A,1-strong convexity,kappa-smoothness and unique origin minimizer with zero value.', 'lean': 'Global ordinary ContDiff infinity, genuine HasFDerivAt of Euclidean gradient with exact matrix CLM, StrongConvexOn univ1, actual gradient norm inequality, f0=0 and global IsMinOn iff x=0.', 'classification': 'source-implicit', 'reason': 'Frechet/Riesz, Euclidean coordinate/operator representation, modulus r^2/2 and global minimizer predicate expose standard meanings rather than adding assumptions. The implementation uses canonical quantitative-gradient monotonicity for strong convexity; author Hessian topology remains separate.'},
        {'source': 'S2 exact reply and Borel algorithm model require appropriate actual reply measurability for fixed input.', 'lean': 'Private Test derives standard-Borel measurability of the literal same-A value/matvec pair using new regularity and actual gradient identity.', 'classification': 'source-implicit', 'reason': 'This omitted model bridge is proved as a real consumer, not attributed as an explicit numbered paper lemma and not inserted as a public premise. Joint/adaptive/precision/cap/TV/cost statements remain unproved.'}],
    'audit_id': 'ASTIS-RT-20261109-HuanjianFixedSpectrumGeometry'}
text = ' '.join([short, formula, *assumptions])
item = {'id': 'huanjian-fixed-spectrum-geometry', 'library': 'samplewiki', 'chapter': 'gaussian-sampling-complexity', 'chapter_path': 'example-cases/samplewiki/companions/gaussian-sampling-complexity.html', 'title': unit['title'], 'source': source, 'statement': text, 'formulae': [{'label': 'Actual Hessian', 'tex': formula}], 'assumptions': assumptions, 'obligations': [{'id': 'actual-fixed-spectrum-potential-geometry', 'label': 'Actual C4 global smoothness, Hessian, strong-convexity/smoothness constants and unique zero minimizer; fixed-input actual Borel consumer separately checked.'}], 'bindings': [binding]}
put('website/content/publications/huanjian-fixed-spectrum-geometry.json', {'schema_version': 1, 'items': [item]})
statement = '∀ '+sig[len('theorem actual_potential_geometry '):].replace('(O : Matrix.orthogonalGroup (Fin d) ℝ) :', '(O : Matrix.orthogonalGroup (Fin d) ℝ),', 1)
context = ['Fin d has values zero through d minus one; casts, halves, real division and cosine have their usual finite real meanings. All theta/A/f lets are literal definitions, not new quantified hypotheses.',
    'Matrix.orthogonalGroup over real is the full real square orthogonal group: transpose is inverse in both orders and either determinant sign is allowed.',
    'EuclideanSpace real (Fin d) is the real L2 coordinate space. WithLp.toLp2 and ofLp preserve coordinates. The continuous linear map associated to a matrix sends a vector to toLp2 of matrix times its coordinate vector.',
    'ContDiff real infinity means globally continuous derivatives of every finite order, distinct from analytic omega. HasFDerivAt is genuine real Frechet derivative existence at the stated point.',
    'gradient is the inverse Riesz image of the total Frechet derivative. Its conventional default at nondifferentiable points is not an existence witness; the assertion also includes global smoothness and the genuine derivative of the gradient.',
    'StrongConvexOn univ with modulus one means convexity with Jensen correction a*b*norm(x-y)^2/2 for nonnegative a,b summing to one. The norm inequality shown is global Euclidean gradient Lipschitzness.',
    'IsMinOn f univ x means f(x)<=f(y) for every y. Its biconditional with x=0 includes existence at0 and uniqueness, while the separate zero-value conjunct fixes the minimum value.']
audit = {'id': binding['audit_id'], 'state': 'draft', 'source': {'source_id': 'arxiv2610.20492v1-ActualFixedSpectrumGeometry', 'url': source['url'], 'anchor': source['anchor'], 'original_text': text, 'text_sha256': sha(text), 'source_snapshot_sha256': S['source']['sha256']},
    'lean': {'declaration': name, 'file': file, 'statement': statement, 'statement_sha256': sha(statement), 'formalizer': 'huanjian_gc_20261109_fixed_spectrum_geometry', 'compiled': True, 'decoder_context': context},
    'reconstruction': {}, 'semantic_slots': {}, 'deltas': [], 'verdict': 'pending', 'source_review': {'state': 'pending'}, 'repairs': []}
ap = Path('research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-geometry.json')
put(ap, audit)
pub.inputs.cache_clear()
pub.load.cache_clear()
audit['publication_binding_sha256'] = pub.binding_digest(item, binding)
audit['publication_context'] = pub.review_context(item, binding)
ap.write_text(json.dumps(audit, ensure_ascii=False, indent=2)+'\n')
pub.check_advance([name], reviewed=False)
packet = rt.decoder_packet(audit)
neutral = Path('.astis/semantic-neutral-20261109/91f0b8e4')
neutral.mkdir(parents=True, exist_ok=False)
put(neutral/'input.json', packet)
put(B/'decoder-input.json', packet)
(B/'anonymous-statement.txt').write_text(statement)
record = {'production_raw_sha256': sha(Path(file).read_bytes()), 'Test_raw_sha256': sha(test.read_bytes()),
    'producer_signature_sha256': S['producer']['signature_sha256'], 'private_consumer_signature_sha256': S['private_actual_consumer']['signature_sha256'],
    'actual_direct_ASTIS_producer_parents': parents, 'actual_direct_ASTIS_private_consumer_parents': [name, first],
    'publication_binding_sha256': audit['publication_binding_sha256'], 'anonymous_statement_sha256': sha(statement),
    'anonymous_packet_canonical_sha256': packet['packet_sha256'], 'neutral_input': str(neutral/'input.json'), 'neutral_input_raw_sha256': sha((neutral/'input.json').read_bytes()),
    'actual_focus_receipt': str(focus), 'actual_kernel_and_sealed_meaning_receipt': str(kernel),
    'decoded_formula_leading_slashes_checked': True, 'private_consumer_has_no_new_Registry_node': True,
    'source_review': 'pending', 'decoder': 'pending', 'sourceV_or_integration_or_Goal_complete': False}
put(B/'publication-draft-record.json', record)
print(json.dumps(record))
