from pathlib import Path
import os, stat, json, hashlib, datetime
ROOT=Path('/Users/zhouhuanjian/ASTIS-GC/.astis/semantic-neutral-20261110/kr_tc_72a0bf')
PAYLOAD=ROOT/'phase1'
files=sorted(p for p in PAYLOAD.rglob('*') if p.is_file())
assert files and all(not p.is_symlink() for p in PAYLOAD.rglob('*'))
manifest={'stage':'phase1-raw-source-baseline-before-seal-definitions-SG','coordinate_scope':'source pins derive from original raw bytes, not normalized DOM','files':[{'path':str(p.relative_to(PAYLOAD)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files]}
mp=ROOT/'phase1.manifest.json'
mp.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
for p in files:os.chmod(p,0o444)
dirs=sorted([PAYLOAD]+[p for p in PAYLOAD.rglob('*') if p.is_dir()],key=lambda p:len(p.parts),reverse=True)
for p in dirs:os.chmod(p,0o555)
os.chmod(mp,0o444)
assert all(stat.S_IMODE(p.stat().st_mode)==0o444 for p in files)
assert all(stat.S_IMODE(p.stat().st_mode)==0o555 for p in dirs)
assert all(hashlib.sha256((PAYLOAD/x['path']).read_bytes()).hexdigest()==x['sha256'] for x in manifest['files'])
receipt={'stage':'phase1','action':'actually hashed every payload file; wrote manifest; chmod payload files 0444 and directories 0555; independently rechecked every mode and hash','finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'payload':str(PAYLOAD),'payload_files':len(files),'payload_directories':len(dirs),'manifest':str(mp),'manifest_bytes':mp.stat().st_size,'manifest_sha256':hashlib.sha256(mp.read_bytes()).hexdigest(),'files_all_mode_0444':True,'directories_all_mode_0555':True,'manifest_file_mode_0444':True,'manifest_recheck_passed':True,'source_sha256':'6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915','candidate_and_SG_exposure':'none','receipt_is_actual_execution_not_planned':True}
rp=ROOT/'phase1.freeze.receipt.json';rp.write_text(json.dumps(receipt,indent=2)+'\n');os.chmod(rp,0o444)
print(json.dumps(receipt,indent=2))
