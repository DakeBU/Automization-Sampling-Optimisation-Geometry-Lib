import copy
import gzip
import hashlib
import io
import json
import subprocess
import sys
import tarfile
import time
from pathlib import Path

ROOT = Path('/Users/zhouhuanjian/ASTIS-GC')
sys.path.insert(0, str(ROOT))
from tools import astis_advance as advance
from tools import astis_publication as publication
from tools import astis_semantic_roundtrip as semantic

BASE = ROOT / 'research-wiki/paper-contributions/GaussianComplexity/affinity-tensorization-semantic-evidence/fresh-source-module-review'
TARGET = 'ASTIS-SA-20261107-GaussianComplexityAffinityTensorization'
AUDIT = ROOT / 'research-wiki/semantic-roundtrip/audits/huanjian-affinity-tensorization.json'
PACKET = ROOT / 'research-wiki/paper-contributions/GaussianComplexity/affinity-tensorization-semantic-evidence/fresh-reviewer-packet.json'
CANDIDATE = '4014feb9c6dff0b4e0dcb9fb49ae1b961cf3cf0b'

def sha(b):
    return hashlib.sha256(b).hexdigest()

def canon(v):
    return json.dumps(v, sort_keys=True, ensure_ascii=False, separators=(',', ':')).encode()

def save_json(name, v):
    (BASE / name).write_text(json.dumps(v, indent=2, ensure_ascii=False)+'\n')

def main():
    started = time.time()
    code_paths = [
        'AutoSamplingTheory/ExampleCases/GaussianComplexity/AffinityTensorization.lean',
        'Tests/GaussianComplexityAffinityTensorization.lean',
        'website/content/declaration_lessons/huanjian-affinity-tensorization.json',
        'website/content/publications/huanjian-affinity-tensorization.json',
    ]
    candidate_bytes = []
    for s in code_paths:
        b = (ROOT/s).read_bytes()
        obj = subprocess.check_output(['git', 'show', CANDIDATE+':'+s], cwd=ROOT)
        assert b == obj, s
        candidate_bytes.append({'path':s,'sha256':sha(b),'matches_candidate_gitobject':True})
    raw_audit = AUDIT.read_bytes()
    audit = json.loads(raw_audit)
    assert audit['state'] == 'blind-reconstructed'
    packet = json.loads(PACKET.read_bytes())
    assert sha(PACKET.read_bytes()) == '1667083a35060d3432439711b3c68fa6d66352b3a82504c4594fb968977e2f38'
    assert packet['packet_sha256'] == semantic.semantic_reviewer_packet(audit)['packet_sha256']
    assert audit['source']['original_text'] == packet['source']['original_text']
    assert audit['reconstruction']['text'] == packet['blind_reconstruction']['text']
    assert audit['publication_context'] == packet['candidate_publication_context']
    item = next(x for x in publication.load() if x['id']=='huanjian-affinity-tensorization')
    binding = item['bindings'][0]
    actual_binding = publication.binding_digest(item, binding)
    assert actual_binding == audit['publication_binding_sha256'] == '9104d934f897b788965a51b8681eb96cf568a43d3a7b7dc5ed743ffe0469533d'
    result_path = BASE/'source-review-result-v1.json'
    result = json.loads(result_path.read_bytes())
    assert sha(result_path.read_bytes()) == '471933a4406724e150e30985c61013474c73c5fa2def4c7155d812c53cd5a5be'
    assert sha((BASE/'review-run-v1.json').read_bytes()) == result['review_run_sha256']

    ledger_path = ROOT/'runs/substantive_advances.jsonl'
    ledger = ledger_path.read_bytes()
    records = [json.loads(line) for line in ledger.splitlines()]
    state = advance._replay_advances(records)
    foreign = {k:v for k,v in state.items() if k != TARGET}
    assert len(foreign)==277
    assert state[TARGET]['state']=='PROVED_LOCAL'
    assert state[TARGET]['owner_id']=='huanjian_gc_20261107_ex71'
    assert not [x for x in state.values() if x['state']=='STABILIZING']
    compressed = gzip.compress(ledger, mtime=0)
    (BASE/'ledger-prefix-before-projection.jsonl.gz').write_bytes(compressed)
    (BASE/'foreign-states-before-projection.json.gz').write_bytes(gzip.compress(canon(foreign), mtime=0))
    (BASE/'canonical-audit-before-projection.json.gz').write_bytes(gzip.compress(raw_audit, mtime=0))

    frontiers = sorted((ROOT/'research-wiki/frontier-cells').glob('*.json'))
    own_frontier = 'ASTIS-SW-GAUSSIAN-COMPLEXITY-affinity-tensorization.json'
    old_frontiers = [p for p in frontiers if p.name != own_frontier]
    assert len(old_frontiers)==436
    frontier_map = {str(p.relative_to(ROOT)):sha(p.read_bytes()) for p in frontiers}
    tar_buf = io.BytesIO()
    with tarfile.open(fileobj=tar_buf, mode='w') as tar:
        for p in frontiers:
            b=p.read_bytes(); info=tarfile.TarInfo(str(p.relative_to(ROOT)));info.size=len(b);info.mtime=0
            tar.addfile(info, io.BytesIO(b))
    (BASE/'frontier-bytes-before-projection.tar.gz').write_bytes(gzip.compress(tar_buf.getvalue(),mtime=0))
    save_json('projection-preflight-v1.json', {
        'candidate_commit':CANDIDATE,'actual_current_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
        'candidate_bytes':candidate_bytes,'publication_binding_sha256':actual_binding,
        'packet_raw_sha256':sha(PACKET.read_bytes()),'packet_canonical_sha256':packet['packet_sha256'],
        'original_source_text_sha256':audit['source']['text_sha256'],'original_decoder_text_sha256':audit['reconstruction']['text_sha256'],
        'canonical_audit_before_sha256':sha(raw_audit),'ledger_prefix_bytes':len(ledger),'ledger_prefix_sha256':sha(ledger),
        'ledger_prefix_lines':len(records),'foreign_states_count':len(foreign),'foreign_states_canonical_sha256':sha(canon(foreign)),
        'frontier_count':len(frontiers),'old_frontier_count':len(old_frontiers),'frontier_bytes':frontier_map,
        'target_state':'PROVED_LOCAL','owner_id':state[TARGET]['owner_id'],'single_stabilization_lane':[],
        'no_canonical_mutation_performed':True,
    })

    proposed = copy.deepcopy(audit)
    proposed['state']='source-reviewed'
    for key in ['semantic_slots','deltas','verdict','repairs']:
        proposed[key]=copy.deepcopy(result[key])
    proposed['source_review']={
        'state':'accepted','reviewer':result['reviewer'],
        'independent_from_formalizer':True,'independent_from_decoder':True,
        'reviewer_packet_sha256':result['reviewer_packet_sha256'],
        'review_run_sha256':result['review_run_sha256'],
        'evidence':result['review_evidence'],
        'run_artifact':str(result_path.relative_to(ROOT)),
        'projection_note':'Mechanical projection of the already frozen independent source review; no new mathematical verdict is inferred.'
    }
    (BASE/'proposed-canonical-audit-v1.json.gz').write_bytes(gzip.compress((json.dumps(proposed,indent=2,ensure_ascii=False)+'\n').encode(),mtime=0))
    registry=semantic.load_registry()
    registry['audits']=[proposed if x.get('id')==audit['id'] else x for x in registry['audits']]
    errors=semantic.validate_registry(registry)
    log='\n'.join(errors)+'\n'
    (BASE/'projection-semantic-preflight-v1.log').write_text(log)
    save_json('projection-semantic-preflight-v1.receipt.json',{
        'command':'tools.astis_semantic_roundtrip.validate_registry(actual merged registry with only in-memory proposed target audit)',
        'exit_code':1 if errors else 0,'elapsed_seconds':time.time()-started,'errors':errors,
        'log_sha256':sha(log.encode()),'canonical_audit_unchanged':AUDIT.read_bytes()==raw_audit,
        'ledger_unchanged':ledger_path.read_bytes()==ledger,'api_called':False,
        'reason':'Exact frozen conclusion relation stronger-in-lean conflicts with frozen equivalent-after-elaboration verdict under the real semantic validator.'
    })
    archives=[]
    for p in sorted(BASE.glob('*.log')):
        b=p.read_bytes();dest=p.with_suffix(p.suffix+'.gz');z=gzip.compress(b,mtime=0);dest.write_bytes(z)
        assert gzip.decompress(z)==b
        archives.append({'source':str(p.relative_to(ROOT)),'source_sha256':sha(b),'archive':str(dest.relative_to(ROOT)),'archive_sha256':sha(z),'roundtrip_exact':True,'source_unchanged':True})
    for p in sorted((ROOT/'.astis/ex71-independent-source-module-review').glob('*')):
        if not p.is_file():continue
        b=p.read_bytes();dest=BASE/(p.name+'.gz');z=gzip.compress(b,mtime=0);dest.write_bytes(z)
        assert gzip.decompress(z)==b
        archives.append({'source':str(p.relative_to(ROOT)),'source_sha256':sha(b),'archive':str(dest.relative_to(ROOT)),'archive_sha256':sha(z),'roundtrip_exact':True,'source_unchanged':True})
    save_json('lossless-archives-v1.json',{'archives':archives,'all_original_logs_and_frozen_run_result_bytes_preserved':True})
    print(json.dumps({'errors':errors,'canonical_audit_unchanged':AUDIT.read_bytes()==raw_audit,'ledger_unchanged':ledger_path.read_bytes()==ledger,'foreign_states':len(foreign),'old_frontiers':len(old_frontiers),'api_called':False},indent=2))
    return 1 if errors else 0

if __name__=='__main__':
    raise SystemExit(main())
