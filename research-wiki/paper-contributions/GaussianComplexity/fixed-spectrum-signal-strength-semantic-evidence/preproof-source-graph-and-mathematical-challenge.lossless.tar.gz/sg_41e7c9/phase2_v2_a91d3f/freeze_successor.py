from pathlib import Path
from datetime import datetime, timezone
from collections import Counter
import hashlib
import json

BASE=Path(__file__).resolve().parent
P1=BASE.parent
OLD=P1/'phase2_c34b8a'
sha=lambda b:hashlib.sha256(b).hexdigest()
def read(p): return json.loads(p.read_text())
def write(name,x):
    (BASE/name).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
assert sha((P1/'phase1_freeze.json').read_bytes())=='69372fb70615bbc7cc6ddc0fe9a6baa96177126d2eb67647882d19626ca67509'
assert sha((OLD/'phase2_freeze.json').read_bytes())=='956452028bad9e1892f1af17bd20f68b59adea53302f8c4f56cd19e527f6deeb'
f1=read(P1/'phase1_freeze.json');f2=read(OLD/'phase2_freeze.json')
for directory,manifest in [(P1,f1),(OLD,f2)]:
    for x in manifest['files']:
        b=(directory/x['path']).read_bytes()
        assert sha(b)==x['sha256'] and len(b)==x['bytes']
assert sha((BASE/'authorized_challenge.exact.md').read_bytes())=='d3eff5947e4b01cf24258cba849dd6c04b3b828a1a9ac3b0dabe00b910e2e28c'
assert sha((BASE/'sealed_projection.exact.json').read_bytes())=='e8322849cd533289522de2de96ae5913364b1446dee114d4224956c1ced02fca'
g=read(BASE/'source_graph.json');c=read(BASE/'source_unit_dispositions.json')
r=read(BASE/'root_closures.json');generics=read(BASE/'generic_source_boundary_closures.json')
u=read(P1/'raw_unit_inventory.json')
ids={n['id'] for n in g['nodes']}
rawids={x['id'] for x in u if x['id']}
assert len(ids)==len(g['nodes'])==92
assert len(g['hyperedges'])==59
assert len(c['units'])==len(u)==809
assert Counter(x['disposition'] for x in c['units'])=={'NODE':752,'EXCLUDED':57}
for x,y in zip(c['units'],u):
    assert x['unit']==y['unit'] and x['raw_sha256']==y['raw_sha256'] and x['reason']
    if x['disposition']=='NODE': assert x['node_ids'] and set(x['node_ids'])<=ids
assert all(set(n['source_anchors'])<=rawids for n in g['nodes'])
assert all(set(e['parents']+[e['child']])<=ids and set(e['consumer_use_sites'])<=rawids for e in g['hyperedges'])
parents={n:[] for n in ids}
for e in g['hyperedges']:
    if e['dependency']: parents[e['child']].extend(e['parents'])
active=set();seen=set()
def visit(n):
    assert n not in active,('cycle',n)
    if n in seen:return
    active.add(n)
    for p in parents[n]:visit(p)
    active.remove(n);seen.add(n)
for n in ids:visit(n)
def recompute(root):
    ns=set();es=set();todo=[root]
    while todo:
        n=todo.pop()
        if n in ns:continue
        ns.add(n)
        for e in g['hyperedges']:
            if e['dependency'] and e['child']==n:
                es.add(e['id']);todo.extend(e['parents'])
    leafs=sorted(n for n in ns if not any(e['dependency'] and e['child']==n for e in g['hyperedges']))
    return sorted(ns),sorted(es),leafs,sorted(n for n in ns if n.startswith('gap:'))
for x in r['roots']+generics['roots']:
    ns,es,ls,gs=recompute(x['root'])
    assert (ns,es,ls,gs)==(x['node_ids'],x['edge_ids'],x['leaf_ids'],x['source_gap_ids'])
for x in generics['roots']:
    assert not(set(x['node_ids'])&set(generics['forbidden_selected_prerequisites']))
    assert not any(n.startswith('a:') or n.startswith('root:') for n in x['node_ids'])
for x in r['roots']:
    assert not({'s:shifted-detector','s:shifted-target-test','s:tau-beta','s:uniform-krylov','ext:22'}&set(x['node_ids']))
oldroots=read(OLD/'root_closures.json')['roots']
for before,after in zip(oldroots,r['roots']):
    assert before['source_gap_ids']==after['source_gap_ids']
    assert set(after['node_ids'])-set(before['node_ids'])=={'s:generic-cosine-statistic','s:generic-moment-law'}
    assert not(set(before['node_ids'])-set(after['node_ids']))
    assert set(after['edge_ids'])-set(before['edge_ids'])=={'e:generic-cosine-definition','e:generic-law-semantics'}
preview=next(e for e in g['hyperedges'] if e['id']=='e:kappa2-preview')
assert preview['dependency'] is False and preview['logic']=='non-implicational' and preview['conditional_discharge']
mapping=next(x for x in c['units'] if x['unit']=='A3.SS3:raw:0043')
assert set(mapping['node_ids'])=={'c:c7','c:majorant'}
# Verify exact JSON field differences by applying each operation to its old tree.
def apply_patch(old,ops):
    target=json.loads(json.dumps(old))
    for op in ops:
        parts=[p.replace('~1','/').replace('~0','~') for p in op['path'].split('/')[1:]]
        cur=target
        for part in parts[:-1]:cur=cur[int(part)] if isinstance(cur,list) else cur[part]
        key=int(parts[-1]) if isinstance(cur,list) else parts[-1]
        if op['operation']=='add':
            if isinstance(cur,list):cur.insert(key,op['after'])
            else:cur[key]=op['after']
        elif op['operation']=='replace':
            assert cur[key]==op['before'];cur[key]=op['after']
        else:
            assert cur[key]==op['before'];del cur[key]
    return target
d=read(BASE/'exact_field_diff.json')
for x in d['files']:
    assert sha((OLD/x['path']).read_bytes())==x['before_sha256']
    assert sha((BASE/x['path']).read_bytes())==x['after_sha256']
    assert apply_patch(read(OLD/x['path']),x['changes'])==read(BASE/x['path'])
write('successor_integrity_check.json',dict(status='STRUCTURAL_CHECKS_PASS_NOT_INDEPENDENT_MATHEMATICAL_APPROVAL',
    original_phase1_payloads_unchanged=len(f1['files']),original_phase2_payloads_unchanged=len(f2['files']),
    raw_inventory_unchanged=True,raw_units=809,node_count=92,hyperedge_count=59,
    dispositions={'NODE':752,'EXCLUDED':57},all_original_ids_and_hashes_match=True,
    selected_and_generic_closures_recomputed=True,dependency_graph_acyclic=True,
    generic_source_boundaries_exclude_selected_interface_query_nodes=True,
    preview_explicitly_non_implicational_with_conditions=True,
    C7_combination_plus_finally_mapping_preserved=True,
    all_exact_field_diffs_reconstruct_successor=True,
    unchanged_selected_root_SOURCE_GAP_lists=True,
    corrected_coverage_approval='PENDING_SAME_DISTINCT_CHALLENGER'))
manifest=dict(schema='append-only-source-graph-successor-freeze-v2',
    created_utc=datetime.now(timezone.utc).isoformat(),stage='FROZEN_REPAIR_PROPOSAL_PENDING_SAME_DISTINCT_CHALLENGER',
    original_phase1_freeze_sha256='69372fb70615bbc7cc6ddc0fe9a6baa96177126d2eb67647882d19626ca67509',
    predecessor_phase2_freeze_sha256='956452028bad9e1892f1af17bd20f68b59adea53302f8c4f56cd19e527f6deeb',
    authorized_challenge_sha256='d3eff5947e4b01cf24258cba849dd6c04b3b828a1a9ac3b0dabe00b910e2e28c',
    original_whole_slice_HOLD_history_preserved=True,sealed_statement_and_definitions_unchanged=True,
    source_cognition='Unchanged phase1 cognition; original source is the mathematics. Challenge supplies graph-scope correction input only.',
    graph='source_graph.json',coverage='source_unit_dispositions.json',closures='root_closures.json',
    generic_source_boundaries='generic_source_boundary_closures.json',conditional_audit='conditional_discharge_audit.json',
    exact_field_diff='exact_field_diff.json',repair_rationale='repair_rationale.md',provenance='repair_scope_and_provenance.json',
    implementation_API_or_candidate_proof_exposure=False,
    independent_coverage_approval='PENDING_SAME_DISTINCT_CHALLENGER',files=[])
for f in sorted(BASE.iterdir()):
    if f.is_file() and f.name not in {'phase2_v2_freeze.json','phase2_v2_freeze.sha256'}:
        b=f.read_bytes();manifest['files'].append(dict(path=f.name,bytes=len(b),sha256=sha(b)))
mb=(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode()
(BASE/'phase2_v2_freeze.json').write_bytes(mb)
(BASE/'phase2_v2_freeze.sha256').write_text(sha(mb)+'  phase2_v2_freeze.json\n')
print(json.dumps(dict(freeze_path=str(BASE/'phase2_v2_freeze.json'),sha256=sha(mb),
    hashes={x:sha((BASE/x).read_bytes()) for x in ['source_graph.json','source_unit_dispositions.json','root_closures.json','generic_source_boundary_closures.json','conditional_discharge_audit.json','exact_field_diff.json','repair_scope_and_provenance.json','repair_rationale.md']},
    corrected_coverage_approval='PENDING_SAME_DISTINCT_CHALLENGER'),indent=2))
