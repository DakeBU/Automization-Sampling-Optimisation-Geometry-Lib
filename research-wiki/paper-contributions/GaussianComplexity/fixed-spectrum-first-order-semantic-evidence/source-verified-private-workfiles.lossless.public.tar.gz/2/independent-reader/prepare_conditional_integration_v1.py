"""CONDITIONAL byte proposal only. Does not edit shared paths or call lifecycle APIs."""
from pathlib import Path
import copy,datetime,difflib,gzip,hashlib,json,os,re,subprocess,sys
sys.dont_write_bytecode=True
R=Path('/Users/zhouhuanjian/ASTIS-GC')
S=R/'.astis/huanjian-gc-fixed-spectrum-first-order-integration-20261108/independent-reader'
O=S/'conditional-proposal-v1'
E=R/'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-first-order-semantic-evidence'
HEAD='9d306d837fbddf1518b0035494baaf5c21c24488'
ADV='ASTIS-SA-20261108-GaussianComplexityFixedSpectrumFirstOrder'
OWNER='huanjian_gc_20261108_fixed_spectrum_first_order'
CELL='ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-first-order'
PREFIX='AutoSamplingTheory.ExampleCases.GaussianComplexity.'
DECL=PREFIX+'FixedSpectrumFirstOrder.actual_first_order_query'
MODULE=PREFIX+'FixedSpectrumFirstOrder'
ADMISS=PREFIX+'FixedSpectrumAdmissibility.actual_precision_admissible'
AFFINE=PREFIX+'FixedSpectrumAffine.actual_affine_precision_query'
BINDING='51d5a5e9390a0d66c2d5b72d042a042eec8d3d60433043ea3909bf9320ccb31e'
BRIDGE='transport:gaussian-quadratic-oracle-factorization';FAMILY='family:gaussian-oracle-hardness'
sha=lambda b:hashlib.sha256(b).hexdigest()
dump=lambda v:(json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode()
canon=lambda v:json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
def cmd(*a):return subprocess.check_output(a,cwd=R)
def archive(name,raw):
 p=O/name;assert not p.exists();p.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(p.read_bytes())==raw
 return {'path':str(p.relative_to(R)),'raw_sha256':sha(raw),'gzip_sha256':sha(p.read_bytes()),'raw_bytes':len(raw)}
def once(raw,a,b):
 a=a.encode() if isinstance(a,str) else a;b=b.encode() if isinstance(b,str) else b;assert raw.count(a)==1,a;return raw.replace(a,b,1)

# Raw JSON spans permit local edits without normalizing any old CRLF/LF bytes.
def spans(text):
 dec=json.JSONDecoder();out={}
 def ws(i):
  while i<len(text) and text[i].isspace():i+=1
  return i
 def value(i,path):
  i=ws(i);start=i
  if text[i]=='{':
   i=ws(i+1)
   while text[i]!='}':
    key,j=dec.raw_decode(text,i);i=ws(j);assert text[i]==':';i=value(i+1,path+(key,));i=ws(i)
    if text[i]==',':i=ws(i+1)
    else:assert text[i]=='}'
   i+=1
  elif text[i]=='[':
   i=ws(i+1);n=0
   while text[i]!=']':
    i=value(i,path+(n,));n+=1;i=ws(i)
    if text[i]==',':i=ws(i+1)
    else:assert text[i]==']'
   i+=1
  else:_,i=dec.raw_decode(text,i)
  out[path]=(start,i);return i
 end=value(0,());assert not text[end:].strip();return out
def token_edits(raw,operations):
 text=raw.decode();ss=spans(text);edits=[]
 for kind,path,value in operations:
  a,b=ss[path]
  if kind=='replace':
   new=json.dumps(value,ensure_ascii=False);edits.append((a,b,new,path))
  elif kind=='append':
   arr=json.loads(text[a:b]);assert arr
   last=ss[path+(len(arr)-1,)];indent=re.match(r'[ \t]*',text[text.rfind('\n',0,last[0])+1:last[0]]).group()
   eol='\r\n' if '\r\n' in text[max(a,last[0]-100):last[0]] else '\n'
   pretty=json.dumps(value,ensure_ascii=False,indent=2).splitlines();insert=','+eol+'\n'.join(indent+x for x in pretty).replace('\n',eol)
   edits.append((last[1],last[1],insert,path))
  else:raise ValueError(kind)
 for a,b,new,path in sorted(edits,reverse=True):text=text[:a]+new+text[b:]
 result=text.encode();json.loads(result)
 return result,[{'path':list(path),'before_char_start':a,'before_char_end':b,'removed_raw_sha256':sha(raw.decode()[a:b].encode()),'inserted_raw_sha256':sha(new.encode()),'inserted_bytes':len(new.encode())} for a,b,new,path in edits]

assert cmd('git','rev-parse','HEAD').decode().strip()==HEAD and not O.exists()
pins_path=E/'full-review-input-pins.json';pins=json.loads(pins_path.read_bytes());assert pins['checked_candidate_commit']==HEAD
for p,h in pins['exact_inputs'].items():assert sha((R/p).read_bytes())==h and cmd('git','show',HEAD+':'+p)==(R/p).read_bytes(),p
assert pins['publication_binding_sha256']==BINDING
proposalpath=E/'conceptual-oracle-factorization/existing-bridge-substrate-supplement-v1.json';pr=proposalpath.read_bytes();assert sha(pr)=='52c7027af4de67a4ab99b3141daa9d900fad878b7c016bd0cea86ea8d487585a';proposal=json.loads(pr);m=proposal['metadata']
reviewpath=E/'conceptual-oracle-factorization/independent-review/review-v1.json';reviewraw=reviewpath.read_bytes();assert sha(reviewraw)=='d26df0070bed3549b90087003af5e26884d58788e6f23586db3f0476bcb23597';review=json.loads(reviewraw);assert review['verdict']=='ACCEPT' and review['shared_models_modified'] is False and review['current_theorem_source_VERIFIED'] is False
valpath=E/'conceptual-oracle-factorization/independent-review/validation-transition.receipt.json';valraw=valpath.read_bytes();assert sha(valraw)=='d3fc6410a4900d1db5429643b4e64a6053b999778e303638e7b47d92d75228ea';assert json.loads(valraw)['exit_code']==0
for p,h in proposal['baseline_models'].items():assert sha((R/p).read_bytes())==h
sys.path[:0]=[str(R/'tools'),str(R/'website/scripts')]
import astis_advance as advance,astis_publication as publication,astis_site as site
item=next(x for x in publication.load() if x['id']=='huanjian-fixed-spectrum-first-order');assert publication.binding_digest(item,item['bindings'][0])==BINDING
unit=json.loads((R/'website/content/declaration_lessons/huanjian-fixed-spectrum-first-order.json').read_bytes())['units'][0];assert len(unit['steps'])==6 and unit['astis_dependencies']==[ADMISS]
capsule=json.loads((E/'local-proof-capsule.json').read_bytes());assert capsule['actual_direct_ASTIS_producer_parents']==[ADMISS] and set(capsule['actual_direct_ASTIS_private_consumer_parents'])=={AFFINE,DECL}
paths=['AutoSamplingTheory.lean','Tests.lean','Tests/Basic.lean','AutoSamplingTheory/TechnicalLemmas/Registry.lean','website/content/samplewiki_companion_frontiers.json','research-wiki/sampling-sde-library/cards/'+MODULE+'.md','website/content/graph_memory_index.json','website/content/functor_hypergraph.json']
before={p:(R/p).read_bytes() if (R/p).exists() else None for p in paths};assert before[paths[5]] is None
plans={}
for path,anchor,new in [(paths[0],'import '+PREFIX+'FixedSpectrumNormalizer\n','import '+MODULE+'\n'),(paths[1],'import Tests.GaussianComplexityFixedSpectrumNormalizer\n','import Tests.GaussianComplexityFixedSpectrumFirstOrder\n'),(paths[3],'import '+PREFIX+'FixedSpectrumNormalizer\n','import '+MODULE+'\n')]:plans[path]=once(before[path],anchor,anchor+new)
count=before[paths[3]].count(b'status := LemmaMemoryStatus.formalizedLocal');assert count==622
plans[paths[2]]=once(before[paths[2]],'formalizedTechnicalLemmaCount = 622','formalizedTechnicalLemmaCount = 623')
entry='''  {
    key := "gaussian-complexity.fixed-spectrum-first-order",
    localDecl := "AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumFirstOrder.actual_first_order_query",
    upstreamDecl := "arXiv2610.20492v1 Eq1 actual fixed-spectrum first-order observation and genuine derivative existence",
    upstreamFile := "S2.E1 first-order pair; S4.E11 literal cosine-grid family; Remark4.2 same-O affine response; AppendixC.4 derivative meaning",
    status := LemmaMemoryStatus.formalizedLocal,
    tags := ["GaussianComplexity", "fixed-spectrum", "Frechet-gradient", "exact-precision-reply", "canonical-reuse"],
    saldUse := "The real private Test combines the new actual gradient/value producer with the existing canonical SAME-O reference2 affine precision reply; derivative existence is an output, not a premise",
    note := "Mathematical candidate9d306d837fbddf1518b0035494baaf5c21c24488 and publication binding51d5a5e9390a0d66c2d5b72d042a042eec8d3d60433043ea3909bf9320ccb31e pin exact source, Test and authored mathematics. Current independent source/whole-module review, normal source V and sole STAB are prerequisites to applying this conditional integration. Exactlyd>=2,kappa>=2, every full real orthogonal O including either determinant sign, and every actual x: the literal cosine-grid precision response Ax is a genuine Euclidean Frechet gradient of the centered potential xTAx/2 and gives its exact value/gradient pair. Existing FixedSpectrumAdmissibility.actual_precision_admissible is the ONE direct kernel ASTIS producer parent; symmetry, real CLM/coordinate identification, derivative existence and Riesz-functional algebra are internal. No derivative, gradient, admissibility or reply certificate is an extra public premise. The real private Test has exactly TWO direct kernel ASTIS parents: this producer and FixedSpectrumAffine.actual_affine_precision_query. Its forward same-O reference2 response uses multiplication by kappa-1; no reciprocal/nonzero bridge is a new consumer premise. The private Test creates no public or Registry node. Existing block FirstOrderQuery is a conceptual sibling, not a formal parent. The separately independently validated supplement retains the same typed transport ID and old review/critical-estimate history; dashed module correspondence is not Lean implication or functor certification. C-infinity/Hessian/strong-convexity/smoothness/minimizer, operational query caps, adaptive/private-seed/transcript/output laws, target-law/TV, finite precision/arithmetic and deterministic/expected-cost adapters, both complete main bounds, remote publication and postmerge purification/ExpositionSeal remain separate."
  },
'''
assert DECL.encode() not in before[paths[3]]
plans[paths[3]]=once(plans[paths[3]],'  {\n    key := "gaussian-complexity.single-block-separation",',entry+'  {\n    key := "gaussian-complexity.single-block-separation",')
assert plans[paths[3]].count(b'status := LemmaMemoryStatus.formalizedLocal')==623
assert plans[paths[3]].replace(entry.encode(),b'',1).replace(('import '+MODULE+'\n').encode(),b'',1)==before[paths[3]]
case=json.loads(before[paths[4]]);guide=case['cases'][4]['reader_guide'][3];boundary=case['cases'][4]['theorems'][1]['boundary'];suffix=boundary[boundary.index(' Section 4.4 limits'):]
newpara=r'The actual fixed-spectrum first-order reply is also compiled and independently source-reviewed: for the same literal precision and every point, genuine derivative existence gives \(\nabla f_A(x)=Ax\) and \(f_A(x)=\langle x,Ax\rangle/2\). Its sole producer parent is canonical actual admissibility. A genuine private Test combines this producer with the identical same-O affine provider to reconstruct the actual kappa value/gradient pair from the reference2 precision reply. This is a pointwise mathematical consequence, not an operational one-query or adaptive transcript theorem. '
newguide=guide.replace('Remaining C4 calculus/minimizer',newpara+'Remaining C4 calculus/minimizer',1);newboundary=boundary.replace('Remaining C4 calculus/minimizer',newpara+'Remaining C4 calculus/minimizer',1)
assert newguide!=guide and newboundary!=boundary and newboundary.endswith(suffix)
raw=before[paths[4]]
for a,b in [(guide,newguide),(boundary,newboundary)]:raw=once(raw,json.dumps(a,ensure_ascii=False),json.dumps(b,ensure_ascii=False))
aftercase=json.loads(raw);maskedbefore=copy.deepcopy(case);maskedafter=copy.deepcopy(aftercase)
for obj in [maskedbefore,maskedafter]:obj['cases'][4]['reader_guide'][3]='<OWN>';obj['cases'][4]['theorems'][1]['boundary']='<OWN>'
assert maskedbefore==maskedafter;plans[paths[4]]=raw
plans[paths[5]]=('''# AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumFirstOrder

- Conditional integration payload: applying requires genuine current-binding independent source V, sole STAB and separately reviewed exact shared patch. This preparation grants no source verdict or reader acceptance.
- Candidate `'''+HEAD+'''`; publication binding `'''+BINDING+'''`.
- Sole public declaration `actual_first_order_query`, for exactly `d >= 2`, real `kappa >= 2`, every full real orthogonal `O` with either determinant sign, and every Euclidean query `x`.
- Literal cosine-grid precision `A=O diagonal(lambda) O^T`, centered potential `f(x)=x^T A x/2`, and exact precision response `q(x)=Ax`. The theorem produces `HasGradientAt f (q x) x` before using the total gradient, and the actual pair equals `(inner x (q x)/2,q x)`. It does not substitute `O x`, inverse precision or covariance multiplication for the response.
- ONE direct kernel ASTIS producer parent: identical `FixedSpectrumAdmissibility.actual_precision_admissible`. Symmetry, CLM/coordinate compatibility, Frechet derivative and Riesz identification are internal proof ingredients; none becomes a public certificate premise.
- Genuine private Test: `actual_reference_precision_first_order_consumer` combines the new producer with identical `FixedSpectrumAffine.actual_affine_precision_query`, using the SAME hidden O. Its TWO direct kernel ASTIS parents are these producers, and only the forward affine component is consumed: `g=(kappa-1) A2 x-(kappa-2)x`. Reference2 is a parameter, not two queries. No reciprocal/nonzero premise is added. The Test has no public or Registry declaration.
- Six authored steps and exact adjacent initially folded Lean live in `website/content/declaration_lessons/huanjian-fixed-spectrum-first-order.json`; the publication of the same basename supplies source correspondence. It attributes Zhou--Suzuki arXiv2610.20492v1 Eq1, Eq11, Remark4.2 and C4 derivative meaning. Source proof review is a separate prerequisite, never inferred from this card.
- Existing `transport:gaussian-quadratic-oracle-factorization` / `family:gaussian-oracle-hardness` receive only their independently mechanism-reviewed pointwise-substrate supplement after source V. All old bindings, critical estimates and historical review remain unchanged. Status stays `not-Lean-certified`, `formal_refs=[]`, with dashed canonical module incidence only. The block FirstOrderQuery remains a conceptual sibling, not a Lean parent or cross-route reduction.
- Remaining: C-infinity/Hessian/strong-convexity/smoothness/unique-minimizer outputs, operational finite-horizon query caps, adaptive/private-seed/transcript/output-law lifting, actual Gaussian target/TV and finite-precision/arithmetic adapters, deterministic/expected-cost conversions, both complete main lower bounds, remote publication and postmerge purification/Exposition Seal. Fixed-spectrum main d/kappa/epsilon/delta ranges, determinant-sign ranges and Section4.4 limitation remain separate and unchanged.
''').encode()
gm=json.loads(before[paths[6]]);fm=json.loads(before[paths[7]]);fi=next(i for i,x in enumerate(gm['families']) if x['id']==FAMILY);bi=next(i for i,x in enumerate(fm['hyperedges']) if x['id']==BRIDGE);oldfamily=gm['families'][fi];oldbridge=fm['hyperedges'][bi]
assert oldbridge==proposal['existing_bridge_snapshot'] and oldbridge['formal_refs']==[] and not any(x['node']==MODULE for x in oldfamily['compiled_substrate_bindings'])
plans[paths[6]],gm_edits=token_edits(before[paths[6]],[('append',('families',fi,'compiled_substrate_bindings'),m['new_actual_substrate_binding'])])
critical=copy.deepcopy(m['critical_estimate']);critical['supplement_review']={'reviewer':review['reviewer'],'verdict':'ACCEPT','scope':review['scope'],'proposal_path':str(proposalpath.relative_to(R)),'proposal_sha256':sha(pr),'review_path':str(reviewpath.relative_to(R)),'review_sha256':sha(reviewraw),'validation_receipt':str(valpath.relative_to(R)),'validation_receipt_sha256':sha(valraw),'current_theorem_sourceV_granted_by_this_mechanism_review':False}
ops=[]
for key in ['formula','hypothesis_map','conclusion_map','failure_boundary']:
 assert m[key].startswith(oldbridge[key]);ops.append(('replace',('hyperedges',bi,key),m[key]))
assert m['source_mapping'][:-1]==oldbridge['source_mapping']
ops.extend([('append',('hyperedges',bi,'critical_estimates'),critical),('append',('hyperedges',bi,'source_mapping'),m['source_mapping'][-1])])
plans[paths[7]],fm_edits=token_edits(before[paths[7]],ops)
ng=json.loads(plans[paths[6]]);nf=json.loads(plans[paths[7]]);newfamily=ng['families'][fi];newbridge=nf['hyperedges'][bi]
assert newfamily['compiled_substrate_bindings'][:-1]==oldfamily['compiled_substrate_bindings'] and newfamily['review']==oldfamily['review']
assert newbridge['critical_estimates'][:-1]==oldbridge['critical_estimates'] and newbridge['source_mapping'][:-1]==oldbridge['source_mapping'] and newbridge['review']==oldbridge['review']
assert all(newbridge[k]==oldbridge[k] for k in oldbridge if k not in ['formula','hypothesis_map','conclusion_map','failure_boundary','critical_estimates','source_mapping'])
# Existing binding/review/critical-estimate object token slices survive unchanged.
oldss=spans(before[paths[6]].decode());newss=spans(plans[paths[6]].decode())
for j in range(len(oldfamily['compiled_substrate_bindings'])):
 path=('families',fi,'compiled_substrate_bindings',j);a,b=oldss[path];x,y=newss[path];assert before[paths[6]].decode()[a:b]==plans[paths[6]].decode()[x:y]
for array in ['critical_estimates','source_mapping']:
 for j in range(len(oldbridge[array])):
  p=('hyperedges',bi,array,j);a,b=spans(before[paths[7]].decode())[p];x,y=spans(plans[paths[7]].decode())[p];assert before[paths[7]].decode()[a:b]==plans[paths[7]].decode()[x:y]
for file,path in [(paths[6],('families',fi,'review')),(paths[7],('hyperedges',bi,'review'))]:
 a,b=spans(before[file].decode())[path];x,y=spans(plans[file].decode())[path];assert before[file].decode()[a:b]==plans[file].decode()[x:y]
assert set(plans)==set(paths)
# Source-name scanner preflight only; not a kernel-export or actual site build.
entries=site.parse_registry();assert not any(x.local_decl==DECL for x in entries) and sum(x.local_decl==ADMISS for x in entries)==1
v=site.RegistryEntry(key='gaussian-complexity.fixed-spectrum-first-order',local_decl=DECL,upstream_decl='Conditional future inventory',upstream_file='Source Eq1/Eq11',status='formalizedLocal',tags=['fixed-spectrum'],sald_use='Actual private consumer',note='CONDITIONAL')
virtual,_=site.enrich_entries(copy.deepcopy(entries+[v]));own=next(x for x in virtual if x.local_decl==DECL)
scanner=list(own.dependencies);assert scanner==[ADMISS]
states=advance.current_advances();discoveries=advance.current_discoveries();assert states[ADV]['state']=='PROVED_LOCAL';assert discoveries[proposal['discovery_id']]['status']=='validated'
foreignstates={k:v for k,v in states.items() if k!=ADV};frontiers={str(p.relative_to(R)):sha(p.read_bytes()) for p in sorted((R/'research-wiki/frontier-cells').glob('*.json'))}
def source_digest(overrides):
 d=hashlib.sha256();files=[R/'AutoSamplingTheory.lean',*sorted((R/'AutoSamplingTheory').rglob('*.lean')),R/'Tests.lean',*sorted((R/'Tests').rglob('*.lean')),R/'lakefile.lean',R/'lean-toolchain',R/'lake-manifest.json']
 for p in files:
  if p.exists():name=str(p.relative_to(R));d.update(name.encode());d.update(b'\0');d.update(overrides.get(name,p.read_bytes()));d.update(b'\0')
 return d.hexdigest()
candidate_digest=source_digest({});assert candidate_digest==site.source_digest();predicted_digest=source_digest(plans)
protected={};index_blobs={}
for row in cmd('git','ls-files','--stage','-z').decode().split('\0'):
 if row:
  meta,p=row.split('\t',1);mode,blob,stage=meta.split();assert stage=='0';index_blobs[p]=blob
for p in index_blobs:
 if not p or p in paths or p=='research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-first-order.json' or p.startswith(str(S.relative_to(R))+'/'):continue
 q=R/p;raw=os.fsencode(os.readlink(q)) if q.is_symlink() else q.read_bytes();protected[p]={'sha256':sha(raw),'blob':index_blobs[p],'symlink':q.is_symlink()}
O.mkdir(parents=True)
diff=b'';rows=[]
for i,p in enumerate(paths,1):
 raw=before[p];after=plans[p];diff+=''.join(difflib.unified_diff((raw or b'').decode().splitlines(keepends=True),after.decode().splitlines(keepends=True),fromfile='a/'+p,tofile='b/'+p)).encode()
 rows.append({'path':p,'before_exists':raw is not None,'before_sha256':sha(raw) if raw is not None else None,'planned_after_sha256':sha(after),'before_archive':archive(f'path-{i}.before.raw.gz',raw) if raw is not None else None,'planned_after_archive':archive(f'path-{i}.planned-after.raw.gz',after),'before_CRLF':raw.count(b'\r\n') if raw else 0,'after_CRLF':after.count(b'\r\n'),'before_lone_LF':raw.count(b'\n')-raw.count(b'\r\n') if raw else 0,'after_lone_LF':after.count(b'\n')-after.count(b'\r\n')})
(O/'exact-shared-proposal.diff').write_bytes(diff)
baseline={'candidate':HEAD,'protected_tracked':protected,'foreign_SAU_states':foreignstates,'all_discovery_states':discoveries,'all_frontier_raw_hashes':frontiers,'own_source_audit_current_draft_sha256':pins['exact_inputs']['research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-first-order.json'],'future_source_audit_exception':'Only this exact own audit may acquire the genuine independently accepted current-binding audit, separately authorized and pinned later. No other metadata exception.','future_ledger_exception':'Only legitimate own PROVED_LOCAL-to-VERIFIED followed by sole-STAB transition, separately bound later; all old raw prefix and foreign states unchanged.','own_frontier_current_bytes_protected':True,'all_models_before':proposal['baseline_models']}
baseline_ref=archive('protected-baseline.json.raw.gz',dump(baseline));archive('before-SAU-ledger.raw.gz',(R/'runs/substantive_advances.jsonl').read_bytes());archive('before-discovery-ledger.raw.gz',(R/'runs/substantive_discoveries.jsonl').read_bytes())
report={'reviewer':'/root/norm_integration_reader','state':'CONDITIONAL_INTEGRATION_PREPARED_NOT_APPLIED_NOT_ACCEPTED','candidate_commit':HEAD,'candidate_source_digest':candidate_digest,'predicted_source_digest_after_exact_proposed_Lean_payloads':predicted_digest,'publication_binding_sha256':BINDING,'sourceV_status':'PENDING separate fresh PHASE3; no verdict granted here','shared_paths':rows,'shared_path_count':8,'formal_ASTIS_producer_parents':[ADMISS],'private_Test_ASTIS_parents':[DECL,AFFINE],'no_private_Test_Registry_node':True,'administrative_count':'622->623: one genuinely new declaration; Basic count assertion itself is administrative','existing_parent_inventory_admission_needed':False,'source_correspondence':'Candidate publication/lesson already supplies source-mapped reader data. Their exact bytes/binding stay unchanged. Only caseguide3 and fixed-spectrum theorem1 boundary scalar are proposed; all other case JSON values and Section4.4 suffix preserved.','source_Test_lesson_publication_pins':{p:h for p,h in pins['exact_inputs'].items() if p not in ['runs/substantive_advances.jsonl','runs/substantive_discoveries.jsonl','research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-first-order.json']},'full_review_input_pins':{'path':str(pins_path.relative_to(R)),'sha256':sha(pins_path.read_bytes())},'local_proof_capsule':{'path':str((E/'local-proof-capsule.json').relative_to(R)),'sha256':sha((E/'local-proof-capsule.json').read_bytes())},'conceptual_supplement':{'proposal':{'path':str(proposalpath.relative_to(R)),'sha256':sha(pr)},'independent_review':{'path':str(reviewpath.relative_to(R)),'sha256':sha(reviewraw)},'existing_actual_validation_receipt':{'path':str(valpath.relative_to(R)),'sha256':sha(valraw)},'same_existing_ids':[FAMILY,BRIDGE],'new_bridge_or_formal_refs':False,'GraphMemory_edits':gm_edits,'Functor_edits':fm_edits,'old_bindings_critical_estimates_source_mapping_reviews_token_bytes_preserved':True,'mixed_CRLF_not_normalized':True,'old_status_relation_category_formalrefs_preserved':True,'mechanism_review_is_not_current_theorem_sourceV':True},'protected_baseline':baseline_ref,'foreign_SAU_count':len(foreignstates),'frontier_count':len(frontiers),'virtual_source_scanner_preflight':{'references':scanner,'only_in_memory':True,'not_kernel_export_or_actual_graph_build':True},'diff_sha256':sha(diff),'mandatory_later_gates':['Fresh current-binding independent source V, normal API, and sole STAB owner explicit application authorization','Root review exact8payloads and independent model supplement byte patch','Immutable integration core and real canonical Lean/rootTests/fakeclosure, publication/contributor/semantic/frontier checks','Actual same-head sitebuild/sitecheck/graphcheck and branch delta inspection','Explicit new OS/browser authorization; actual desktop/mobile38 originals, two old DensityAffinity DOM/UI regressions, independent actual-original review','Separate local acceptance and normalpark authorizations; original source verifier actor preserves original evidence'], 'CSS_unchanged_sha256':'a41ffd9d41e8c281aa716fcff25e42e5cb8d14208badff456a0dff7dfbb1b766','no_apply_build_browser_sourceV_STAB_acceptance_park_API':True,'uncertainties':['Final source verifier identity/audit verdict/normal source V append are not frozen yet. Later bound context must pin them; this proposal does not invent a sourceV.','Future actual integration commit, current gate/site/graph/browsing receipts and actual original images do not exist yet. Candidate and predicted source digests are preparation facts, not executed gates.','Source-facing lesson/publication fixes during fresh review would invalidate this exact proposal and require a new version; originals stay immutable.'],'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
for p,raw in before.items():assert ((R/p).read_bytes() if (R/p).exists() else None)==raw
assert cmd('git','rev-parse','HEAD').decode().strip()==HEAD
for p,h in pins['exact_inputs'].items():assert sha((R/p).read_bytes())==h
(O/'proposal-report.json').write_bytes(dump(report));archive('preparation-driver.py.raw.gz',Path(__file__).read_bytes())
freeze={'state':report['state'],'report_sha256':sha((O/'proposal-report.json').read_bytes()),'files':[{'path':str(p.relative_to(R)),'sha256':sha(p.read_bytes())} for p in sorted(O.iterdir()) if p.is_file()],'applied':False,'sourceV_STAB_API_build_browser_acceptance':False};(O/'freeze.json').write_bytes(dump(freeze))
print(json.dumps({'report':str((O/'proposal-report.json').relative_to(R)),'report_sha256':sha((O/'proposal-report.json').read_bytes()),'freeze_sha256':sha((O/'freeze.json').read_bytes()),'diff_sha256':sha(diff),'candidate_source_digest':candidate_digest,'predicted_postintegration_source_digest':predicted_digest,'shared_paths':len(rows),'applied':False},indent=2))
