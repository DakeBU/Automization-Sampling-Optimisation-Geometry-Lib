from pathlib import Path
from bs4 import BeautifulSoup
import json
import re

base = Path(__file__).resolve().parent
s = BeautifulSoup((base / 'A3.SS2.html').read_bytes(), 'html.parser')
spans = {x['id']: x for x in json.loads((base / 'source-spans-complete.json').read_text())}
rows = []


def row(source_id, disposition, stable_id, meaning, scope, consumers=None):
    parent = source_id
    t = s.find(id=source_id)
    if source_id not in spans and t is not None:
        p = t.find_parent(class_='ltx_para')
        parent = p.get('id') if p else 'A3.SS2'
    r = {'source_id': source_id, 'disposition': disposition, 'stable_id': stable_id,
         'meaning_or_reason': meaning, 'packet_scope': scope,
         'consumer_use_sites': consumers or []}
    if parent in spans:
        r['exact_span_or_enclosing_paragraph'] = spans[parent]
    rows.append(r)


paragraphs = {
 'A3.SS2.p1': ('NODE', 'raw.cg.def.frame-tensor-row', 'r=q+1; n=2q+1; t_i, gamma_i; gamma_i independent standard Gaussian; B row literal and dimensions', 'definitions-and-law-context', ['A3.SS2.p5','A3.SS2.p6','A3.SS2.p7','A3.SS2.p8']),
 'A3.SS2.p2': ('NODE', 'raw.cg.consumer.strategy', 'u=Bc; norm and weighted quadratic form pass through the two Gram matrices; expectations and concentration are distinct stages', 'consumer-boundary-open', ['A3.SS2.p19']),
 'A3.Thmtheorem5.p1': ('NODE', 'raw.cg.factC5.composite-open', 'Fact C.5 statement; six parts are split in component coverage below, with no aggregate closure', 'statement-split-open', []),
 'A3.SS2.p3': ('EXCLUDED', 'raw.cg.excluded.range-proof', 'Chebyshev triangular invertible basis change and nonzero column normalizations prove range(B)=K_q; outside deterministic packet closure', 'excluded-open-range', ['A3.SS2.p19']),
 'A3.SS2.p4': ('NODE', 'raw.cg.leaf.midpoint-cosine-sum', 'Signed integer frequency 0<|k|<2d; sine-difference telescoping; nonzero sine-factor discharge', 'deterministic-provider', ['A3.SS2.p5','A3.SS2.p7']),
 'A3.SS2.p5': ('NODE', 'raw.cg.frame.unweighted-gram', 'All constant, mixed, positive-mode diagonal/off-diagonal cases; frequency inequalities; symmetry; sum t_i t_i^T=dI_r', 'deterministic-target', ['A3.SS2.p6','A3.SS2.p12','A3.SS2.p14']),
 'A3.SS2.p6': ('NODE', 'raw.cg.private.gaussian-unweighted-mean', 'Actual Gaussian second moment, normalized tensor-row Gram, finite-sum expectation; E[B^TB]=I_(r^2)', 'private-consumer-open', ['A3.SS2.p9','A3.SS2.p17']),
 'A3.SS2.p7': ('NODE', 'raw.cg.frame.weighted-and-private-mean', 'Split into signed-frequency bound, triple cosine cancellation, weighted frame sum, and actual Gaussian weighted mean below', 'mixed-deterministic-and-private-consumer', ['A3.SS2.p12','A3.SS2.p17']),
 'A3.SS2.p8': ('NODE', 'raw.cg.frame.row-norm', 'Exact norm expansion and cos^2<=1 yield ||t_i||^2<=1+2q<=2r', 'deterministic-target', ['A3.SS2.p13','A3.SS2.p14']),
 'A3.SS2.p9': ('EXCLUDED', 'raw.cg.excluded.concentration-transition', 'Transition from expectations to simultaneous operator-norm deviations; not supplied by deterministic identities', 'excluded-open-concentration', []),
 'A3.Thmtheorem6.p1': ('EXCLUDED', 'raw.cg.excluded.factC6', 'Simultaneous Gram concentration with probability 0.995; requires entire later route', 'excluded-open-concentration', ['A3.SS2.p19']),
 'A3.SS2.p10': ('EXCLUDED', 'raw.cg.excluded.gaussian-truncation-tail', 'Gaussian exponential moment, Markov tail, event T with probability 0.999', 'excluded-open-concentration', []),
 'A3.SS2.p11': ('EXCLUDED', 'raw.cg.excluded.truncation-bias', 'Tail-integral formula and bias bound for R_i 1_(R_i>L)', 'excluded-open-concentration', []),
 'A3.SS2.p12': ('EXCLUDED', 'raw.cg.excluded.radial-truncated-means', 'Y_i and common radial scalar a; two frame sums consumed at Ex110; extra isotropy is required', 'excluded-open-concentration-consumer', []),
 'A3.SS2.p13': ('EXCLUDED', 'raw.cg.excluded.centered-summand-norm', 'Row norm consumed at Ex111; truncated tensor operator norms and centering supply R_*', 'excluded-open-concentration-consumer', []),
 'A3.SS2.p14': ('EXCLUDED', 'raw.cg.excluded.fourth-moment-variance', 'Gaussian fourth moments, matrix-square formulas, PSD indicator removal; row norm and frame Gram consumed at Ex115-117', 'excluded-open-concentration-consumer', []),
 'A3.SS2.p15': ('EXCLUDED', 'raw.cg.excluded.matrix-Bernstein', 'Independent centered self-adjoint sequences and two-sided bounded matrix Bernstein; no citation is printed here', 'excluded-open-concentration', []),
 'A3.SS2.p16': ('EXCLUDED', 'raw.cg.excluded.Bernstein-threshold-union', 'z, Delta, direct expansion, failure probability 0.002 per bound and union probability 0.996', 'excluded-open-concentration', []),
 'A3.SS2.p17': ('EXCLUDED', 'raw.cg.excluded.remove-truncation', 'On T original/truncated sums agree; centering/bias formulas and probability intersection give 0.995', 'excluded-open-concentration', []),
 'A3.SS2.p18': ('EXCLUDED', 'raw.cg.excluded.simplify-tau', 'Integer dimension consequences 2r<=d; logarithmic simplifications; absolute constant chosen in tau', 'excluded-open-concentration', []),
 'A3.SS2.p19': ('EXCLUDED', 'raw.cg.excluded.full-lemma4.4-proof', 'C.6 event plus range(B)=K_q plus tau<=1/2 give uniform quadratic estimate, with probability 0.99', 'excluded-open-full-lemma', []),
}
for key, data in paragraphs.items():
    row(key, *data)

parts = [
 ('A3.Ex86', 'EXCLUDED', 'raw.cg.factC5.range-part', 'range(B)=K_q is not closed by this packet', 'excluded-open-range'),
 ('A3.Ex86', 'NODE', 'raw.cg.factC5.unweighted-mean-part', 'E[B^TB]=I_(r^2), real Gaussian-law private consumer', 'private-consumer-open'),
 ('A3.Ex86', 'NODE', 'raw.cg.factC5.weighted-mean-part', 'E[B^TD_nB]=0, real Gaussian-law private consumer', 'private-consumer-open'),
 ('A3.Ex87', 'NODE', 'raw.cg.factC5.row-norm-part', '||t_i||^2<=2r', 'deterministic-target'),
 ('A3.Ex87', 'NODE', 'raw.cg.factC5.unweighted-frame-part', 'sum_i t_i t_i^T=dI_r', 'deterministic-target'),
 ('A3.Ex87', 'NODE', 'raw.cg.factC5.weighted-frame-part', 'sum_i cos(n theta_i)t_i t_i^T=0', 'deterministic-target'),
 ('A3.SS2.p7', 'NODE', 'raw.cg.leaf.no-zero-no-alias-four-frequencies', 'Ex96 with n=2q+1, 0<=j,k<=q, n<d bounds every signed frequency in [1,2d)', 'deterministic-provider'),
 ('A3.SS2.p7', 'NODE', 'raw.cg.leaf.triple-cosine-cancellation', 'Ex97-99 and the constant-coordinate multipliers prove each weighted frame entry vanishes', 'deterministic-provider'),
 ('A3.SS2.p7', 'NODE', 'raw.cg.private.gaussian-weighted-mean', 'Ex100-101 consume actual Gaussian second moments, integrability and weighted frame cancellation', 'private-consumer-open'),
]
for x in parts:
    row(*x)

display_meanings = {
85: 'Literal definitions of t_i and gamma_i',
86: 'Split Fact C.5 range and two Gaussian expectation claims; see component entries',
87: 'Three deterministic target parts; see component entries',
88: 'Sine-difference telescoping first equality', 89: 'Telescoping terminal sine(k pi)-sin0=0',
90: 'Constant coordinate squared and constant/nonconstant cross terms',
91: 'Positive-mode product normalization 2 cos(j theta)cos(k theta)',
92: 'Product-to-sum frequencies j-k and j+k', 93: 'Diagonal d versus off-diagonal zero',
94: 'Gaussian unweighted Gram expectation as normalized tensor sum',
95: 'Unweighted frame sum gives identity of dimension r^2',
96: 'Every n plus/minus j plus/minus k lies strictly between 0 and 2d',
97: 'Weighted triple-cosine sum left-hand side',
98: 'Four-term product-to-sum with coefficient 1/4', 99: 'All four cosine sums vanish',
100: 'Gaussian weighted Gram expectation as tensor sum', 101: 'Weighted frame sum gives zero',
102: 'Row norm expansion and two inequality steps',
}
for tag in s.find_all(id=True):
    if not re.fullmatch(r'A3\.Ex\d+', tag['id']):
        continue
    number = int(tag['id'].split('Ex')[1])
    p = tag.find_parent(class_='ltx_para')['id']
    disp, parent_id, meaning, scope, _ = paragraphs[p]
    row(tag['id'], disp, 'raw.cg.display.' + str(number),
        display_meanings.get(number, meaning + '; exact displayed formula retained in source snapshot'), scope)

context = [
 ('S4.SS1', 'NODE', 'raw.cg.context.midpoint-grid', 'd>=2, kappa>=2 and Eq11 midpoint theta grid; lambda/Lambda retained as separate excluded-range context', 'source-standing-definitions'),
 ('S4.SS1.p1', 'NODE', 'raw.cg.context.grid-standing-paragraph', 'Standing d,kappa and midpoint grid component; other mathematical components of this paragraph explicitly split below', 'source-standing-definitions'),
 ('S4.E11', 'NODE', 'raw.cg.context.grid-display', 'theta component of Eq11; lambda/Lambda components separately excluded as range background', 'source-standing-definitions'),
 ('S4.SS1.p1', 'EXCLUDED', 'raw.cg.context.affine-eigenvalues', 'lambda_i and Lambda definitions are retained as background for the excluded range/Krylov proof', 'excluded-open-range'),
 ('S4.SS1.p1', 'EXCLUDED', 'raw.cg.context.construction-citation', '[22, Section9.2] construction attribution; no citation is invoked in the current cosine-identity proof', 'excluded-external-citation-context'),
 ('S4.SS1.p1', 'EXCLUDED', 'raw.cg.context.random-rotation-target', 'Random O, precision A, potential and target law are outside deterministic frame packet', 'excluded-source-context'),
 ('S4.SS1.p2', 'EXCLUDED', 'raw.cg.context.algorithm-information', 'Deterministic spectrum supplied to algorithm, known normalizing constant, and hidden eigenbasis', 'excluded-source-context'),
 ('S4.Thmtheorem2.p1', 'EXCLUDED', 'raw.cg.context.remark4.2', 'Comparison with original kappa=2 construction and query lower-bound narrative', 'excluded-source-context'),
 ('S4.SS2.SSS0.Px1.p1', 'EXCLUDED', 'raw.cg.context.deferred-rotation-citation', '[22, Lemma9.2] and algorithm rotational argument belong to Lemma4.3, not this deterministic route', 'excluded-external-citation-context'),
 ('S4.SS2.SSS0.Px1.p2', 'NODE', 'raw.cg.context.Krylov-definition', 'K_q=span{Lambda^j g_a : 1<=a<=q+1,0<=j<=q}; retained to understand excluded range identity', 'definition-boundary-open'),
 ('S4.Ex10', 'NODE', 'raw.cg.context.Krylov-display', 'Exact Krylov-space definition display', 'definition-boundary-open'),
 ('S4.Thmtheorem3.p1', 'EXCLUDED', 'raw.cg.context.lemma4.3', 'Algorithm-output Gaussian Krylov representation; does not prove frame identities', 'excluded-source-context'),
 ('S4.Ex11', 'EXCLUDED', 'raw.cg.context.lemma4.3-display', 'Almost-sure output membership in K_q', 'excluded-source-context'),
 ('S4.SS2.SSS0.Px1.p3', 'EXCLUDED', 'raw.cg.context.extra-start-vector', 'Output may lie outside query/reply span; random polynomial coefficients and C.1 deferral', 'excluded-source-context'),
 ('S4.SS2.SSS0.Px2.p1', 'NODE', 'raw.cg.context.n-Dn-definition', 'n=2q+1; D_n diagonal cosine weights; high-frequency motivation', 'source-definitions'),
 ('S4.Ex12', 'NODE', 'raw.cg.context.n-Dn-display', 'Exact n and D_n formula', 'source-definitions'),
 ('S4.Thmtheorem4', 'EXCLUDED', 'raw.cg.context.lemma4.4-full-statement', 'Full probabilistic uniform bound, absolute constant and tau threshold are downstream open; source binders retained in cognition', 'excluded-open-full-lemma'),
 ('S4.Ex13', 'EXCLUDED', 'raw.cg.context.tau-display', 'tau_(d,q) definition belongs to full concentration/uniform bound', 'excluded-open-full-lemma'),
 ('S4.Ex14', 'EXCLUDED', 'raw.cg.context.uniform-bound-display', 'All u in K_q quadratic inequality belongs to full Lemma4.4', 'excluded-open-full-lemma'),
 ('S4.SS2.SSS0.Px2.p2', 'EXCLUDED', 'raw.cg.context.kappa-independent-range', 'Nonconstant affine eigenvalue-to-cosine map and equivalence of spans concern excluded range/Krylov obligation', 'excluded-open-range'),
 ('S4.SS2.SSS0.Px2.p3', 'EXCLUDED', 'raw.cg.context.output-consumer', 'Use of Lemmas4.3+4.4 for algorithm output', 'excluded-source-context'),
 ('S4.Ex15', 'EXCLUDED', 'raw.cg.context.output-bound-display', 'Quadratic statistic of rotated algorithm output', 'excluded-source-context'),
 ('S4', 'EXCLUDED', 'raw.cg.context.section4-preamble', 'Direct-child inventory exposed Theorem4.1 and lower-bound narrative; no use in this deterministic audit', 'excluded-incidental-source-context'),
 ('A3.Thmtheorem5', 'NODE', 'raw.cg.factC5.wrapper', 'Composite statement represented by explicit part entries; no aggregate closure', 'statement-split-open'),
 ('A3.Thmtheorem6', 'EXCLUDED', 'raw.cg.factC6.wrapper', 'Statement is covered by excluded FactC6 paragraph and display entries', 'excluded-open-concentration'),
]
for x in context:
    row(*x)

required_paras = {t['id'] for t in s.find_all(class_='ltx_para')}
required_displays = {t['id'] for t in s.find_all(id=True) if re.fullmatch(r'A3\.Ex\d+', t['id'])}
covered = {x['source_id'] for x in rows}
missing = sorted((required_paras | required_displays) - covered)
assert not missing, missing
report = {
 'phase': 'raw-only-pre-type-pre-author-graph',
 'meaning_of_NODE': 'A source-coverage/topology item; never an implemented or proved claim',
 'mathematical_review_status': 'independent raw cognition frozen; exact types and author graph unseen',
 'source_sha256': '6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915',
 'rows': rows,
 'representation_exclusion': 'Nested MathML m1/m2 ids are the rendering/encoding of their parent formula, not additional mathematical claims; headings/wrappers are formatting, with theorem wrappers separately listed.',
 'mechanical_completeness': {'C2_para_count': len(required_paras), 'C2_display_anchor_count': len(required_displays), 'missing': missing},
 'source_gap_status': 'No deterministic gap inferred from raw formulas; Gaussian moments/integrability remain proof ingredients for actual-law private consumers, not assumed public premises.',
}
(base / 'source-only-coverage.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(report['mechanical_completeness'], indent=2))
print('Coverage rows:', len(rows))
