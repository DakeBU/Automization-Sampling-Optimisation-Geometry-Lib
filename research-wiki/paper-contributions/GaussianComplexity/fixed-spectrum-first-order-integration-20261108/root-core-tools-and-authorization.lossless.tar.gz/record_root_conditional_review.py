from pathlib import Path
import datetime, gzip, hashlib, json, subprocess
sha = lambda b: hashlib.sha256(b).hexdigest()
R = Path('.astis/huanjian-gc-fixed-spectrum-first-order-integration-20261108')
P = R / 'independent-reader/conditional-proposal-v1'
report = P / 'proposal-report.json'
freeze = P / 'freeze.json'
assert sha(report.read_bytes()) == '43bff1329cd5b697a845184e1ff9d27004c93d46edb2251f855c4a90d92e5604'
assert sha(freeze.read_bytes()) == '00333a58d298cf2003f23d6aa4e2e6fe4a5d6b8308c5d683c0acf2c6fa6ad27f'
r = json.loads(report.read_bytes())
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == r['candidate_commit']
assert not subprocess.check_output(['git', 'diff', 'HEAD', '--name-only'], text=True).strip()
for row in json.loads(freeze.read_bytes())['files']:
    assert sha(Path(row['path']).read_bytes()) == row['sha256']
for row in r['shared_paths']:
    p = Path(row['path']); assert p.exists() == row['before_exists']
    assert not p.exists() or sha(p.read_bytes()) == row['before_sha256']
    for key in ['before_archive', 'planned_after_archive']:
        a = row[key]
        if a:
            z = Path(a['path']).read_bytes(); raw = gzip.decompress(z)
            assert sha(z) == a['gzip_sha256'] and sha(raw) == a['raw_sha256']
            assert len(raw) == a['raw_bytes']
    if row['path'] in ['website/content/graph_memory_index.json', 'website/content/functor_hypergraph.json']:
        before = gzip.decompress(Path(row['before_archive']['path']).read_bytes())
        after = gzip.decompress(Path(row['planned_after_archive']['path']).read_bytes())
        assert before.count(b'\r\n') == after.count(b'\r\n')
assert len(r['shared_paths']) == 8
out = R / 'root-conditional-proposal-review-v1.json'
assert not out.exists()
out.write_text(json.dumps({
    'recorded_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'reviewer': '/root', 'kind': 'Coordinator exact integration-diff review, not independent source verdict',
    'state': 'CONDITIONALLY_REVIEWED_NO_APPLICATION_AUTHORIZATION',
    'candidate_commit': r['candidate_commit'], 'proposal_report_sha256': sha(report.read_bytes()),
    'proposal_freeze_sha256': sha(freeze.read_bytes()), 'shared_payloads_verified': 8,
    'frozen_payload_hashes_verified': 21,
    'human_readback': [
        'Root and aggregate Test add the exact new module once; Basic622->623 is administrative inventory only.',
        'Registry adds exactly one new public producer; no private Test or old ancestor V promotion.',
        'Caseguide changes exactly two owned Gaussian scalar strings by the same pointwise-gradient paragraph; all old prefix/suffix and Section4.4 bounds retained.',
        'New modulecard states exact d>=2,kappa>=2/fullO, genuine derivative, actual producer1/Test2 parents and all remaining truth boundaries.',
        'GraphMemory adds one canonical module substrate binding to the existing family.',
        'Functor retains all old content and typed noncertification; four scalar fields append the new pointwise formula/forward-only boundary and two arrays append one estimate/source mapping.',
        'Old review/critical estimates/source maps remain historical, no new formal_refs or determinant-to-eigenbasis implication.',
        'Source-reviewed wording in reader scalars is conditional on genuine later current-binding source V; not true publication acceptance at preparation time.'
    ],
    'gate': 'No application until genuine independent current-binding source acceptance and normal V, fresh origin main ancestry reconciliation, explicit sole normal STAB authorization and exact eight-path baseline readback.',
    'actual_gates_browser_or_acceptance': False, 'source_verdict_created': False,
    'shared_paths_applied': False, 'lifecycle_transition_performed': False
}, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'conditional_review': str(out), 'sha256': sha(out.read_bytes()),
                  'no_application_authorized': True, 'tracked_tree_unchanged': True}))
