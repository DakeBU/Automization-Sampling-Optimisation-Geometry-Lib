# Phase 1: independent raw-source reconstruction, C.7 → C.8

Role: source/topology/binder challenger, not a proof worker. Status: frozen source-only baseline for a later candidate challenge; no candidate verdict, Statement Seal approval, Lean certification, or registry transition is given here.

## Scope and independence

Only the pinned paper HTML and the five requested governance files were read. The source is `.astis/huanjian-resume-20261103/2610.20492v1.html`, 951991 bytes, SHA-256 `6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915`. It identifies the paper as *On Complexity of Gaussian Sampling*. Exact raw-element hashes and original UTF-8 byte boundaries are in `raw-source-manifest.json`.

Governance read: `AGENTS.md`, `docs/contributor-codex-contract.md`, `docs/theorem-publication-protocol.md`, `docs/proof-digestion-protocol.md`, `docs/evidence-routed-memory-protocol.md`. The relevant rule is that source hypotheses become binders and proof ingredients become discharged edges, with independent source reconstruction before implementation-driven topology.

No existing moments source graph, existing phase 1/2 material, statement seal, production declaration, Lean/Mathlib proof or API, prior review, implementation, lesson, ATLAS, Bench, model tool, network, browser, ledger API, or repository status/frontier was opened. Writes are confined to this phase 1 directory. No agent was spawned.

This is **not zero-cue**: the assignment gave the paper path/hash, the C.7/C.8 anchors, the role, and topic-bearing `fixed-spectrum-moments` / `cosine-topology-challenge` paths. The inherited tool/permission descriptions also contain unrelated earlier fixed-spectrum task names. Those are environmental cues, not independently read mathematical evidence. A source-only `rg` request printed some surrounding theorem labels and downstream formulas; the report does not treat those snippets as prior review. One HTML-locator implementation initially collided with HTMLParser's internal `offset` field; it was renamed before any manifest was produced. This was a local extraction-tool correction, not a mathematical route failure.

The raw source was read through C.7's complete statement and proof (`A3.Thmtheorem7`, `A3.SS3.2`), C.3's introductory paragraph, Section 4.1, Lemma 4.5's definitions/statement and immediate application paragraph, and C.8's complete statement/proof. The neighboring proof of Lemma 4.5 was displayed as surrounding source context; its variance/bias arguments are outside this review's theorem target.

## Mathematical meaning fixed from the source

Section 4.1 sets real κ≥2 and integer dimension d≥2, with grid index i=1,…,d:

\[
\theta_i=(i-\tfrac12)\pi/d,\quad
\lambda_i=(\kappa+1)/2+((\kappa-1)/2)\cos\theta_i,
\quad \Lambda=\operatorname{diag}(\lambda_1,\ldots,\lambda_d).
\]

The random orthogonal rotation and potential in that subsection explain the hard-family application. They are not ingredients of C.7's scalar cosine identity. Lemma 4.5 defines the parameter literally by

\[\rho=\varrho_\kappa=(\sqrt\kappa-1)/(\sqrt\kappa+1).\]

It also defines U∼N(0,Λ⁻¹), Dₙ=diag(cos(nθᵢ)), M=E‖U‖² and μₙ=E[UᵀDₙU] for integer 1≤n<d. These explain C.8's consumer, not extra premises for C.7. The conditional bias premise d−n≥√κ belongs later in Lemma 4.5 and is absent from both C.7 and C.8. Neither an odd-n premise nor n=2q+1 belongs to these facts. The upper restriction κ≤d^(1−δ) appearing in the surrounding main lower-bound theorem is not used by this scalar expansion or finite-grid calculation.

C.7 asserts, for every real θ,

\[
\frac{2}{\kappa+1+(\kappa-1)\cos\theta}
=\frac1{\sqrt\kappa}\left(1+2\sum_{j\ge1}(-\rho)^j\cos(j\theta)\right),
\]

and absolute and uniform convergence in θ of the displayed series. This is an equality of real quantities. Complex exponentials occur in its proof, not in the statement's carrier. The claim ranges over all real θ, not only the d grid points. The source index j is a positive integer: there is a separately written constant 1 and a factor 2 outside the positive-mode sum.

The source statement contains three related deliverables: the equality, absolute convergence at every θ, and uniform convergence over the whole real θ-domain. It does not assume a pre-existing summability or uniform-convergence certificate.

## Source route and exact AND/OR semantics

The raw source presents **one** proof route for C.7. It contains no alternate-route citation or disjunction. The following node IDs are this independent report's labels, not repository graph identities.

| Node | Raw location | Source content / role |
|---|---|---|
| C7-S | `A3.Thmtheorem7.p1.1`, `A3.Ex133`, `A3.Thmtheorem7.p1.2` | Real-θ domain, target equality, and both convergence claims. |
| RHO | `S4.Thmtheorem5.p1.1`; recalled at `A3.SS3.p2.1` | Literal ρ definition; the proof invokes 0<ρ<1. |
| GEO | `A3.SS3.p2.1`, `A3.Ex134` | Apply geometric-series identity to the positive and negative complex phases. |
| RAT | `A3.Ex135` | Combine the two complex fractions into (1−ρ²)/(1+2ρ cosθ+ρ²). |
| PAR | `A3.SS3.p2.2`, `A3.Ex136` | Both parameter identities, including the exact (1−ρ)² normalization. |
| EQ | `A3.SS3.p2.3` | Combine the rational expression and parameter identities to obtain the expansion. |
| MAJ | `A3.Ex137` | Bound absolute terms by the positive geometric series with total ρ/(1−ρ). |
| CONV | `A3.SS3.p2.4` | Conclude absolute and uniform convergence. |
| USE | `A3.Ex140`, `A3.SS3.p4.2` | Convert Gaussian means to finite inverse-eigenvalue sums and consume C.7 to interchange grid and series sums. |

AND edges in the source route:

1. Literal RHO definition **and** κ≥2 supply the invoked range 0<ρ<1.
2. That range **and** the real-angle complex-exponential facts supply the two geometric expansions in GEO. The `+iθ` and `−iθ` pieces are both used; they are not two independent sufficient routes.
3. GEO **and** the algebra/denominator facts supply RAT.
4. RAT **and both** identities in PAR supply EQ.
5. Range 0<ρ<1 **and** |cos(jθ)|≤1 supply MAJ; MAJ **and** the standard majorant/uniform-convergence bridge supply CONV.
6. EQ **and** absolute convergence **and** uniform convergence comprise C7-S's complete output. The equality proof and convergence proof are separate obligations, not alternative proofs of the whole package.
7. For C.8, C7-S's equality and convergence output **and** the grid/inverse-eigenvalue identification feed USE. C.8's root also needs its independent finite-grid orthogonality and Gaussian-moment conversion. It is incorrect to flatten C.7, Gaussian moments and grid orthogonality as three alternative ways to prove C.7.

There is no source OR-route to import from a prospective implementation. A real-only geometric/trigonometric argument, Poisson-kernel theorem, or separately admitted library route could later be an explicit alternative implementation route; none is stated as an alternative in this raw source.

## Omitted background bridges that must remain visible

These are omitted standard bridges in a short paper proof, not a finding that its result is false. A complete source proof graph must either expand them or expose them as `SOURCE_GAP/background` nodes with their discharge recorded. They may not silently become new public assumptions.

| Bridge | Consumer use | Why it matters |
|---|---|---|
| B-RANGE | `A3.SS3.p2.1` | Obtain √κ>1 and 0<ρ<1 from the literal definition and κ≥2, rather than assume ρ's range independently. |
| B-PHASE | `A3.Ex134` | For real θ, the two complex phases have modulus 1; geometric ratios are −ρe^(±iθ) and have modulus <1. Real/complex coercions and Euler/cosine identities must agree. |
| B-SERIES | `A3.Ex134` | The positive-index geometric sum and addition/scalar operations on convergent series justify the displayed infinite-sum equality. A syntactic infinite sum alone supplies none of these facts. |
| B-DENOM | `A3.Ex134`–`A3.Ex136` | The complex 1+ρe^(±iθ), real 1−ρ, √κ and final spectral denominators are nonzero under standing assumptions. They are facts to discharge, not source binders. |
| B-ALG | `A3.Ex135`, `A3.Ex136`, `A3.SS3.p2.3` | Combining conjugate fractions and the two ρ identities preserves the factor 2 and √κ normalization. |
| B-MAJORANT | `A3.Ex137` | |cos(jθ)|≤1 and positivity of ρ produce a θ-independent summable geometric majorant. |
| B-UNIFORM | `A3.SS3.p2.4` | The stated total bound must be connected to a majorant test or uniform-tail criterion. Merely having a uniformly bounded total of absolute values for each θ is not, without that bridge, a proof of uniform convergence. Here the termwise geometric majorant is the source's missing standard justification. |
| B-GRID | `A3.Ex140`, `A3.SS3.p4.2` | At θᵢ, 1/λᵢ equals C.7's scalar left side; finite addition and bounded multiplication preserve the convergent series when forming M and μₙ. |

C.7 cites no named external theorem or paper within its proof; “geometric-series identity” is the source's explicit generic background input. The Section 4.1 citation `[22, Section 9.2]` is construction provenance, not a hidden C.7 analytic theorem. Its source was not opened.

## Binder and definition baseline for phase 2

| Item | Source status | Candidate audit consequence |
|---|---|---|
| κ real, κ≥2 | Standing source range | Preserve or explicitly label a generalization; do not import unrelated upper bounds. |
| θ real, arbitrary | Explicit C.7 domain | A theorem only at finite grid angles loses source scope. |
| ρ=(√κ−1)/(√κ+1) | Meaning-carrying literal definition | No default branch, independent free ρ, or off-source fallback semantics. A general-ρ helper is possible only with an adapter deriving this instance internally. |
| j≥1 integer | Series typing/index convention | An ℕ-indexed implementation must explicitly shift both exponent and cosine mode by 1, or prove removal of the j=0 term with the constant adjusted. |
| 0<ρ<1, denominator nonvanishing | Produced from standing definitions | Proof dependencies, not extra source assumptions. |
| Summability / geometric identity / exponential-cosine identity / uniform convergence | Proof ingredients or output | They cannot be source-facing input binders merely because a producer theorem exists. |
| d, i, λᵢ, n, U, Gaussian law, M, μₙ | C.8/application context | Not required for C.7's scalar assertion. |
| Finite-sum/series interchange certificate | Produced C.8 step | No new public premise in C.8. |

This is not a Statement Seal: no final candidate signature has been seen. A later candidate must expand project-owned Prop aliases, structures and instances before classification. In particular, a bundled “spectrum” or “expansion certificate” may conceal exactly the derived ingredients listed above.

## Convergence and indexing stress points

Absolute convergence means convergence of the absolute-value series for each real θ. Uniform convergence means uniformity on all of ℝ in θ; it is not uniformity in κ over its entire unbounded range. The source majorant and its constant depend on κ via ρ. Uniformity over the finite grid alone is weaker than C.7. A result that only identifies a totalized infinite sum, without proving convergence and its intended meaning, misses part of C.7.

The sign is `(-ρ)^j`, not a constant negative sign times ρ^j. The cosine argument is jθ in radians. In a 0-based finite grid, θ at index r must be (r+1/2)π/d for r=0,…,d−1; using (r−1/2)π/d silently changes the grid. The original grid has d terms and excludes both endpoint angles 0 and π.

For C.8, the grid orthogonality formula (`A3.Ex139`) ranges over **all integer k**: the nonzero case is k=2ad with a∈ℤ, with value d(−1)^a. It is not “all nonzero modes vanish.” In the positive-j expansion for M, only j=2ad with a≥1 survive. For μₙ, product-to-sum produces j−n and j+n; its three surviving classes are j=n, j=2ad+n (a≥1), j=2ad−n (a≥1). The last two forms are not interchangeable if a starts at 0. Their disjointness uses 1≤n<d. The sign relation for 2ad±n is the source's integer parity step. None of this imposes an odd-n restriction.

## C.8 consumer check and coverage

`A3.Ex140` uses E[Uᵢ²]=1/λᵢ to write M=Σᵢ1/λᵢ and μₙ=Σᵢcos(nθᵢ)/λᵢ. `A3.SS3.p4.2` explicitly names C.7 as permission to exchange its absolutely convergent series with this **finite** grid sum. This is not an exchange with a Gaussian integral, not an infinite grid, and not a new Tonelli/Fubini hypothesis. Uniform convergence is a C.7 deliverable; pointwise convergence already suffices for finite linear combinations, while the source invokes the stronger absolute convergence it has proved.

The full C.8 proof was checked to determine the use's direction. Its coverage is:

| Raw region | Disposition |
|---|---|
| `A3.Thmtheorem8`, `A3.Ex138` | NODE C8-S: exact M and signed μₙ formulas, range 1≤n<d. |
| `A3.SS3.p3.1`, `A3.Ex139`, `A3.SS3.p3.2` | NODE C8-GRID: finite cosine orthogonality and both divisibility cases. |
| `A3.SS3.p4.1`, `A3.Ex140` | NODE C8-MEAN: scalar second moments to finite spectral sums. |
| `A3.SS3.p4.2` | NODE USE: explicit C.7 series exchange consumer. |
| `A3.SS3.p5.1`, `A3.Ex141`–`A3.Ex143` | NODE C8-M: select even multiples of d and sum the signed geometric progression. |
| `A3.SS3.p6.1`, `A3.Ex144` | NODE C8-PRODUCT: zero constant mode and product-to-sum. |
| `A3.SS3.p6.2`, `A3.Ex145`–`A3.Ex147` | NODE C8-MU: disjoint mode classes, parity, remaining geometric sums, final simplification. |
| `A3.SS3.p6.3` | EXCLUDED: proof-end symbol only. |

C.7 coverage is exhaustive within its complete statement/proof: every substantive paragraph and display is assigned C7-S, RHO, GEO, RAT, PAR, EQ, MAJ or CONV in the table above. The proof title and terminal symbol carry no additional mathematical step. `A3.SS3.p1` is NODE context for recalled grid/λ definitions; its roadmap to later variances/bias is EXCLUDED from C.7. Section 4.1's deterministic spectrum definitions (`S4.E11`) and Lemma 4.5's ρ/moment definitions are NODE context. Section 4.1's random rotation, known normalizer and κ=2 comparison, and Lemma 4.5's later variance/bias assertions/application rotation are EXCLUDED from the C.7 route because they are neither used nor needed in its scalar proof. They remain paper context; exclusion does not claim they are formalized.

## Frozen handoff

Phase 1 ends here. The fixed deliverables are this bounded report, exact raw source manifest, and the deterministic locator script; `SHA256SUMS` freezes all three. No conclusion is made about any unseen source graph, binder packet, or theorem candidate. The next admissible step is a separate phase 2 comparison with the root-supplied exact candidate; phase 1 files must remain unchanged.
