from pathlib import Path
import argparse, datetime, hashlib, json, subprocess, sys

R = Path('.astis/huanjian-gc-fixed-spectrum-first-order-integration-20261108')
I = R/'independent-reader'
L = Path('.astis/huanjian-resume-20261103')
sha = lambda b: hashlib.sha256(b).hexdigest()
ref = lambda p: {'path': str(p), 'sha256': sha(p.read_bytes())}
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
assert head == '9b1e90d25711668203c6e252cfe5a748f95c8ad4'
assert not subprocess.check_output(['git', 'diff', 'HEAD', '--name-only'], text=True).strip()
a = json.loads((I/'UNAUTHORIZED-final-browser-context-v4.template.json').read_bytes())
a.update({'state': 'ROOT_AUTHORIZED_BOUND_LOCAL_BROWSER_EXECUTION_ONLY_NOT_ACCEPTANCE',
          'authorized_by': '/root', 'execute_browser_authorized': True,
          'accepted_immutable_core': head,
          'authorized_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()})
a['actual_gate'] = ref(Path('.astis/site-lean-gate.json'))
a['site_metadata'] = ref(Path('_site/data/build-metadata.json'))
a['own_frontier_projection_review'] = ref(R/'root-exact-own-frontier-projection-review-v3.json')
names = {
    'canonical_lean': '20261108T155405574474Z-fixed-spectrum-first-order-ui-successor-canonical-lean',
    'publication': '20261108T155406744017Z-fixed-spectrum-first-order-ui-successor-publication',
    'contributor': '20261108T155406744015Z-fixed-spectrum-first-order-ui-successor-contributor',
    'semantic': '20261108T155406744112Z-fixed-spectrum-first-order-ui-successor-semantic',
    'frontier': '20261108T155406744073Z-fixed-spectrum-first-order-ui-successor-frontier',
    'site_build': '20261108T155549832278Z-fixed-spectrum-first-order-ui-successor-site-build',
    'site_check': '20261108T155955986324Z-fixed-spectrum-first-order-ui-successor-site-check',
    'graph_check': '20261108T155955986309Z-fixed-spectrum-first-order-ui-successor-graph-check',
}
a['actual_checks_before_browser'] = {}
for role, name in names.items():
    p = L/(name+'.receipt.json')
    r = json.loads(p.read_bytes())
    assert r['exit_code'] == 0 and r['head_before'] == r['head_after'] == head
    assert sha(Path(r['log']).read_bytes()) == r['log_sha256']
    a['actual_checks_before_browser'][role] = ref(p)
a['instruction'] = ('Execute only the independently frozen v4 checker on the genuine current '
    'canonical _site artifact built at this exact UI successor core. Preserve the held CORE87 '
    'browser report, all38 original images and independent HOLD. Local HTTP and installed '
    'headless Chrome require separate NEW scoped v4 OS permission; the old v3 prefix is not reused. '
    'This canonical runtime work is distinct from the earlier owned STATIC source-review preview '
    'and its refusal: no file URL or denied BrowserUse transport. The38 main original captures '
    'and8 native geometry rows must be actually obtained; the4 extra preset/cross-view rows are '
    'DOM/UI-only. No source verdict, API, local acceptance, normalpark, remote or wholeGoal authority.')
out = R/'root-final-browser-context-v4.json'
assert not out.exists()
out.write_text(json.dumps(a, ensure_ascii=False, indent=2)+'\n')
sys.path.insert(0, str(I.resolve()))
import first_order_browser_common_v4 as common
args = argparse.Namespace(authorization_json=str(out), authorization_sha256=sha(out.read_bytes()))
value, reference = common.load_authorization(args)
readback = common.authorized_context(value)
p = R/'actual-browser-context-v4-readonly-preflight.json'
assert not p.exists()
p.write_text(json.dumps({
    'recorded_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'kind': 'Exact sourceV/STAB/newcore/eightactualreceipts/one-reviewed-JS-exception preflight only',
    'authorization': reference, 'readback': readback,
    'browser_launched': False, 'acceptance_created': False,
}, ensure_ascii=False, indent=2)+'\n')
print(json.dumps({'actual_context': str(out), 'raw_sha256': sha(out.read_bytes()),
                  'readonly_preflight': str(p), 'preflight_sha256': sha(p.read_bytes()),
                  'all8_actual_receipts_same_core': True, 'browser_launched': False}))
