# Frozen raw-first topology inventory

Role: independent source-topology challenger, not a proof worker. This is a source-only preread, not acceptance of an unseen statement, implementation, extractor graph, or proof. No statement/definition projection has been received.

The authoritative source is the full exact HTML snapshot in `raw-inputs/source.html`, SHA256 `6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915`. `source-regions/` and `source-units/` preserve original UTF-8 slices, without whitespace or MathML normalization. Source offsets are bytes in that snapshot. Reading text is an aid only. `raw-source-inventory.json` assigns NODE or EXCLUDED to each selected paragraph, theorem/fact, display group/row, block math, and citation use; nested records deliberately overlap so an aligned display cannot disappear behind its paragraph. This is the challenger's inventory, not the extractor's graph.

## Quantifiers and definitions

1. Section 4.1 fixes a hard family for integer d >= 2 and kappa >= 2. Theta_i=(i-1/2) pi/d, lambda_i=(kappa+1)/2+(kappa-1) cos(theta_i)/2, Lambda=diag(lambda_i), and A=O Lambda O^T are literal definitions. O is Haar orthogonal, independent of the algorithm's private randomness. The spectrum is deterministic and may be supplied to the algorithm. No spectral-information restriction is an admissible added hypothesis.
2. Section 2 makes query budgets deterministic integer caps for every input and seed. Algorithms and outputs are Borel, with randomness independent of the input. Q_G is the infimum of such integer caps with a uniform per-input TV guarantee. These are source standing conventions, rather than concentration or moment premises.
3. K_q is the span of Lambda^j g_a for 1<=a<=q+1 and 0<=j<=q. The coefficients representing an adaptive output can depend on the full extended experiment. Lemma 4.3 does not grant independence of those coefficients from g. Its statement grants mutually independent standard Gaussian g_a; it does not state that those g_a are independent of O or X. The event in Lemma 4.4 must therefore hold simultaneously for every vector in K_q.
4. Lemma 4.4 first asserts existence of one absolute C>0. Then q is a nonnegative integer, n=2q+1<d, and g_a are iid N(0,I_d). Tau is exactly

   C*((q+1)*sqrt(log(d)/d) + (q+1)*(q+1+log(d))*log(d)/d).

   The factors, including the second log(d), must all survive literal-definition review. The source does not define tau as a bound chosen separately for each parameter triple. The source concentration conclusion is conditional on tau<=1/2, and has probability >=0.99 for one event controlling every u in K_q. Kappa independence follows from the invertible affine cosine/power change of basis, not from a concentration premise supplied to the consumer.
5. Appendix C.2 makes the meaning of C precise: Fact C.6 requires a sufficiently large absolute C; its proof first obtains an absolute c and then chooses C>=c. The same fixed C is reused in the proof of Lemma 4.4. C is not arbitrary positive in the concentration statement. A family of literal numerical expressions with a free C is not, by formula agreement alone, the source concentration theorem.
6. Theorem 4.1 has order: for every fixed delta in (0,1), there exists d0(delta), for every integer d>=d0(delta), every 2<=kappa<=d^(1-delta), and every 0<epsilon<=1/10, the Q_G lower bound holds. There is no new concentration-constant hypothesis in this source theorem. Its proof works with every integer q<=delta*sqrt(kappa)*log(d)/256 simultaneously over this range.
7. The eventual estimates in Section 4.3 are made after the source absolute C is fixed. Constants hidden in the tau comparison, including C', absorb that fixed C. The source's phrase 'depending only on delta' must be read with that ordering. A stronger claim of a single cutoff uniform over unbounded free C cannot be inferred: at any fixed admissible (d,q), positive tau grows linearly with C. A separate numerical-family theorem with a cutoff depending on C has a different quantifier order; no judgment about any such unseen target is made here.
8. The q+1 bound and n=o(d), the tau bound, d-n>=sqrt(kappa), and all later choices of cutoff are eventual and uniform over the stated kappa/q range. The +1 in q+1 and n must be discharged by increasing the cutoff. q=0 is included. None of those eventual inequalities may be asserted for all d merely because they hold past the final cutoff.
9. Lemma 4.5 is for kappa>=2, U~N(0,Lambda^-1), and integer 1<=n<d. M=E||U||^2 and mu_n=E[U^T D_n U]. Its exact formulas and both variance bounds hold before imposing d-n>=sqrt(kappa). Only the displayed lower normalized-bias bound needs that extra separation. The source sign is (-1)^n mu_n>0; beta=|mu_n|/M. Positivity of M and beta are proved facts, not public hypotheses.
10. In Section 4.3, b=(1-exp(-4))*exp(-3)>0 is fixed, and beta>=b*d^(-delta/4). The M lower bound, tau/beta ->0, and M*beta^2 ->infinity use different source steps. Their combined cutoffs yield tau<=1/2, n<d, d-n>=sqrt(kappa), tau<=beta/4, and M*beta^2>=320. These are proved conditions required at consumer use sites, not added main-theorem premises.
11. S_A is the signed Chebyshev quadratic form minus 2*tau*||x||^2, and E_A={x:S_A(x)>0}. The polynomial matrix formula makes E_A independent of a choice of eigenbasis; for fixed A it is Borel. Geometric energy weights require x!=0, but S_A and E_A are defined for x=0 too and S_A(0)=0. An x!=0 premise cannot leak into the event or theorem.
12. With fixed A and Y~pi_A, orthogonal transport U=O^T Y identifies target moments. Z=S_A(Y) uses the same Y in both quadratic forms, so the two forms are generally dependent. The source explicitly uses the centered L2 triangle inequality, not independence or variance additivity. Finite second moments of the forms follow from Gaussian fourth moments. Mean positivity uses tau<=beta/4; the final variance estimate <=8M also uses tau<=1/2. Chebyshev is applied to {Z<=0} using E Z>0 and Var Z finite, giving the strict-event probability P(Z>0)>=0.9 for every fixed A in the hard family.

## Independently reconstructed source edges, with consumer use sites

Every row below is an AND of its listed inputs for that particular step; the rows themselves do not form one global AND. No alternative proof is given in this bounded source slice.

| Consumer/source use site | Required source inputs and discharge |
| --- | --- |
| A3.SS2.p3, range(B)=K_q | Section 4.1 affine spectrum; kappa>=2 so affine slope nonzero; Chebyshev degree and nonzero leading coefficient; triangular invertible basis change; nonzero column scalings. |
| A3.SS2.p4-p6, Gram expectation | Finite-grid cosine sum for 0<|k|<2d; product-to-sum; indices <=q with 2q+1<d; Gaussian covariance I; tensor-row definition of B. |
| A3.SS2.p7, weighted zero expectation | n=2q+1; every n +/- j +/- k lies between 1 and 4q+1<2d; cosine-sum cancellation; covariance I; tensor identity. This is a separate zero-centering edge. |
| A3.SS2.p8, t_i norm bound | |cos|<=1, r=q+1. |
| A3.SS2.p10-p11, truncation event and tail bias | Gaussian chi-square exponential moment; Markov; union bound; tail integration formula; L=2r+3log(1000d). |
| A3.SS2.p12, truncated expectations | Radial symmetry; identical Gaussian laws; r>0; Fact C.5 deterministic sum and weighted-zero identities; tail bias. |
| A3.SS2.p13, summand norm | Tensor/rank-one norms; t_i norm bound; 0<=a<=1; |cos(n theta_i)|<=1. |
| A3.SS2.p14, variance parameters | Gaussian fourth moments; rank-one square identities; positive-semidefinite truncation removal; t_i norm and tight-frame sum; centered-square identity. Weighted sequence uses cos^2<=1 and PSD variance, not an independence argument between the two sequences. |
| A3.SS2.p15-p16, simultaneous centered concentration | Each sequence is independent, centered, self-adjoint; norm and variance bounds; two-sided bounded matrix Bernstein with dimension r^2; z=log(1000r^2), Delta expansion; union bound. |
| A3.SS2.p17-p18, Fact C.6 | Truncation event .999 and centered concentration event .996 intersect by union bound, giving .995; truncated bias; d>=2 and 2r<=d from 2q+1<d; absolute log simplifications; existence of absolute c; choose fixed C>=c. The tau<=1/2 condition is not needed for Fact C.6 itself. |
| A3.SS2.p19, Lemma 4.4 | Fact C.5 range(B); simultaneous two matrix bounds of Fact C.6; tau<=1/2. The single event bounds every coefficient vector and hence every u. .995 is weakened to .99. |
| A3.SS3.p2, Fact C.7 | 0<rho_kappa<1; complex geometric series; algebraic rho/sqrt(kappa) identities; geometric majorant for absolute uniform convergence. |
| A3.SS3.p3-p6, Fact C.8 | Complete finite-grid alias identity for all integer frequencies; Gaussian coordinate second moments; Fact C.7 and absolute convergence; product-to-sum; disjoint alias classes 1<=n<d; geometric summation. |
| A3.SS3.p7-p8, Lemma 4.5 means and variances | Fact C.8; independent Gaussian coordinates from diagonal covariance; fourth moments; lambda_i>=1; |cos|<=1. M<=d/sqrt(kappa) uses the exact M formula. |
| A3.SS3.p9-p11, Lemma 4.5 normalized bias | Exact formulas, n<d, 0<rho<1 imply sign; ratio formula; logarithm integral bounds use kappa>=2; d-n>=sqrt(kappa) discharges the e^-4 lower-bias factor. |
| S4.SS3.SSS0.Px1.p1, tau small | q cap; kappa<=d^(1-delta); delta in (0,1); literal tau with fixed absolute C; eventual absorption of +1 and log factors; powers dominate log powers. This yields n<d and tau<=1/2. |
| S4.SS3.SSS0.Px1.p1, algorithmic event bound | Lemma 4.3 on an extension preserving joint (O,X); Lemma 4.4 with n<d and tau<=1/2 discharged; spectral identity T_n(cos theta_i)=cos(n theta_i); signed quadratic <=absolute quadratic. Gives averaged algorithm probability <=.01, not necessarily a per-A output bound. |
| S4.SS3.SSS0.Px2.p2, beta lower bound | n=o(d), sqrt(kappa)=o(d) yield d-n>=sqrt(kappa); Lemma 4.5 lower bias; query cap gives 3n/sqrt(kappa)<=3+(3delta/128)log d; exponent slack 3delta/128<=delta/4 for d>=1. |
| S4.SS3.SSS0.Px2.p2, M lower bound | rho<=exp(-1/sqrt(kappa)), available from stronger C.3 bound; d>=sqrt(kappa); rho^(2d)<=exp(-2)<1/3; exact M formula; kappa upper bound. |
| S4.SS3.SSS0.Px2.p2, final numeric cutoff | tau upper estimate AND beta lower estimate imply tau/beta<=C'/b*d^(-delta/4)*log^3 d ->0; M lower AND beta lower imply M*beta^2>=b^2*sqrt(d)/2 ->infinity. Finite conjunction of eventual conditions yields one cutoff for fixed delta and the already fixed source C. |
| S4.SS3.SSS0.Px2.p3, shifted detector mean | Orthogonal target transport; spectral matrix identity; source signed mean beta*M and norm mean M; linearity of expectation; tau<=beta/4. |
| S4.SS3.SSS0.Px2.p3, shifted detector variance | Both variance bounds <=2M; centered L2 triangle with factor 2tau; tau>=0; tau<=1/2; finite Gaussian fourth moments. |
| S4.SS3.SSS0.Px2.p3, target event | Positive shifted mean, variance <=8M, Chebyshev, M*beta^2>=320; E_A corresponds exactly to Z>0. Result is uniform for each fixed A. |
| S4.SS3.SSS0.Px3.p1, contradiction | Per-input TV guarantee for measurable E_A; admissibility Lemma 4.6; average algorithm bound <=.01; pointwise target bound >=.9; averaging; epsilon<=.1. The numerical difference is .89. |

## Explicit gaps / external and omitted bridges

These are visible source obligations. They are not findings that the underlying mathematical assertions are false, and they do not certify local formal availability.

- `SOURCE_GAP:absolute-C`: A3.SS2.p18 uses absolute big-O comparisons and existence of c without a numeral. The source establishes existence of a sufficiently large absolute C; no particular numeral may inherit the concentration conclusion without a separate derivation or source ruling.
- `SOURCE_GAP:eventual-uniform-cutoff`: S4.SS3.SSS0.Px1.p1 and Px2.p2 omit the explicit uniform cutoff construction and elementary power/log limits. It must cover all d beyond the cutoff, all admissible kappa, and all q under the cap, including the +1 terms and the finite conjunction of conditions. The C dependence/order must be retained.
- `external-uncited:matrix-Bernstein`: A3.SS2.p15 invokes the two-sided bounded self-adjoint matrix Bernstein inequality without a bibliography citation in that paragraph. Independence, centering, dimension, summand norm and PSD variance assumptions are supplied by preceding paragraphs; the theorem itself is an external standard input, not a new source hypothesis.
- `external-uncited:Gaussian-moments-mgf`: The chi-square exponential moment, fourth moments and independence consequences are used in C.2 and C.3; some fourth-moment arithmetic is expanded, while the Gaussian facts themselves remain external standard inputs.
- `external-uncited:Markov-tail-integral-L2-Chebyshev`: Markov, tail integration, union bounds, centered L2 triangle, and Chebyshev are named or directly invoked. Their mathematical preconditions are part of the internal proof obligations. No bibliography citation was found in the bounded C.2/C.3/Section 4.3 raw regions for these inputs.
- `SOURCE_GAP:target-transport-spectral-event`: Section 4.2 states orthogonal transport and Section 4.3 gives the Chebyshev polynomial statistic; the Gaussian pushforward, matrix polynomial conjugation and event measurability bridges are not expanded into separate proofs. Their premises are supplied by hard-family definitions, not by an added moment/event binder.
- `imported-source-interface:Lemma4.3`: The exact statement and citation to [22, Lemma 9.2] are inventoried. Appendix C.1 was not read in this bounded task; this pass does not accept its deferred-rotation proof or any upstream assimilation.
- `imported-source-interface:Lemma4.6`: The admissibility statement is inventoried, while Appendix C.4 was not read in this bounded task. It is a distinct input to the final contradiction, rather than a new hypothesis on the hard family.
- Source [22] is preserved byte-for-byte in `source-regions/bib.bib3.html.raw`; it is the OpenAI (2026) Subpolynomial query complexity preprint. It is cited for the construction and the deferred-rotation interface. This pass has not read or admitted that external source.

## Challenge tests to apply only after a sealed statement is supplied

Check complete binder/definition expansion; literal tau factors; exact quantifier order for free C versus fixed source C; endpoint d/q/kappa/delta conventions; cutoff dependency; scalar numerical eventuality versus concentration; exact M/beta/sign definitions; same-Y covariance handling; event strictness; no moment/concentration/cutoff conclusion reintroduced as a source theorem premise. These are preregistered tests, not acceptance of any future target.

The raw pass is frozen before receipt of an extractor graph or sealed target. A later statement-only phase and a still later topology challenge must retain their own inputs, exposure records, and verdict digests; neither may rewrite this preread.
