"""Prepared only. No preflight or normal API call without separate later authorization."""
from pathlib import Path
import argparse
import copy
import hashlib
import json
import os
import subprocess
import sys
from datetime import datetime, timezone

sys.dont_write_bytecode = True
ROOT = Path('/Users/zhouhuanjian/ASTIS-GC')
PREP = Path(__file__).resolve().parent
ADV = 'ASTIS-SA-20261109-GaussianComplexityFixedSpectrumCosineExpansion'
VERIFIER = '/root/cosine_fresh_source_5d8c2a'
OWNER = 'huanjian_gc_20261109_fixed_spectrum_cosine_expansion'
CHECKED = '37645c774481c4cad19fc29bcaa76799da64db7d'
sha = lambda b: hashlib.sha256(b).hexdigest()


def load(path):
    return json.loads(Path(path).read_bytes())


def put(path, value):
    with Path(path).open('xb') as f:
        f.write((json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode())


def complete_records(raw):
    # Pure: never call current_advances/load_jsonl/recover_jsonl before this check.
    if raw and not raw.endswith(b'\n'):
        raise RuntimeError('HOLD: incomplete ledger tail; no recovery or API permitted')
    records = [json.loads(line) for line in raw.splitlines() if line.strip()]
    if not all(isinstance(record, dict) for record in records):
        raise RuntimeError('HOLD: non-object JSONL record')
    return records


def replay(records):
    # Exact pure replay semantics inspected in astis_advance.py:344-389.
    state = {}
    for record in records:
        event, advance_id = record.get('event'), record.get('advance_id')
        if not isinstance(advance_id, str) or not advance_id:
            continue
        if event == 'proposal':
            item = dict(record)
            item.setdefault('frontier_cell', 'global')
            item.setdefault('target_declarations', [])
            item.setdefault('checkpoint_count', 0)
            item.setdefault('no_progress_streak', 0)
            item.setdefault('needs_diagnosis', False)
            state[advance_id] = item
            continue
        if advance_id not in state:
            continue
        current = state[advance_id]
        if event == 'transition':
            to_state = record.get('to_state', current.get('state'))
            current['state'] = to_state
            current['last_actor'] = record.get('worker_id', current.get('last_actor', ''))
            if to_state == 'CLAIMED':
                current['owner_id'] = record.get('worker_id', '')
                current['no_progress_streak'], current['needs_diagnosis'] = 0, False
            current['modes'] = list(record.get('modes') or current.get('modes') or [])
            if record.get('evidence'):
                current['latest_evidence'] = record['evidence']
                if to_state == 'PROVED_LOCAL' and record['evidence'].get('publication_declarations'):
                    current['publication_declarations'] = record['evidence']['publication_declarations']
            current['updated_at'] = record.get('created_at', current.get('updated_at'))
        elif event == 'checkpoint':
            previous = current.get('latest_checkpoint') or {}
            same = (previous.get('route_fingerprint') == record.get('route_fingerprint') and
                    previous.get('progress_signature') == record.get('progress_signature'))
            streak = int(current.get('no_progress_streak', 0)) + 1 if same else 1
            current['checkpoint_count'] = int(current.get('checkpoint_count', 0)) + 1
            current['no_progress_streak'] = streak
            current['needs_diagnosis'] = streak >= 3
            current['latest_checkpoint'] = dict(record)
            current['updated_at'] = record.get('created_at', current.get('updated_at'))
    return state


def authorize(path, phase):
    if path is None:
        raise RuntimeError('DISABLED: no separate root authorization supplied')
    auth_path = Path(path).resolve()
    if auth_path.is_relative_to(PREP):
        raise RuntimeError('DISABLED: authorization must be newly supplied outside frozen preparation')
    auth = load(auth_path)
    manifest_raw = (PREP / 'manifest.json').read_bytes()
    assert auth['actor'] == '/root'
    assert auth['prepared_manifest_sha256'] == sha(manifest_raw)
    for item in json.loads(manifest_raw)['files']:
        raw = (PREP / item['path']).read_bytes()
        assert len(raw) == item['bytes'] and sha(raw) == item['sha256']
    if phase == 'preflight':
        assert auth['action'] == 'authorize-read-only-preflight'
        assert auth['preflight_enabled'] is True and auth['execution_enabled'] is False
    else:
        assert auth['action'] == 'authorize-one-normal-VERIFIED'
        assert auth['execution_enabled'] is True and auth['max_normal_api_calls'] == 1
        assert auth['exclusive_serialized_window_confirmed'] is True
    return auth, {'path': str(auth_path), 'sha256': sha(auth_path.read_bytes())}


def static_bindings(contract):
    for item in contract['fixed_files']:
        raw = (ROOT / item['path']).read_bytes()
        assert sha(raw) == item['sha256'], item['path']
    proposal = load(PREP / 'accepted-audit-proposal-v2.json')
    audit = load(ROOT / contract['audit_path'])
    assert audit == load(PREP / 'expected-accepted-audit-v2.json'), 'actual accepted audit differs from strict v2 overlay'
    for key, expected in proposal['proposed_audit_fields'].items():
        assert audit[key] == expected, ('actual accepted audit patch not present', key)
    assert audit['state'] == 'source-reviewed' and audit['source_review']['state'] == 'accepted'
    assert audit['publication_binding_sha256'] == contract['publication_binding_sha256']
    assert audit['lean']['declaration'] == contract['public_declaration']
    assert audit['lean']['statement_sha256'] == contract['anonymous_statement_sha256']
    assert audit['lean']['formalizer'] == OWNER
    assert audit['reconstruction']['decoder'] == '/root/decode_b4e6a1'
    assert audit['source_review']['reviewer'] == VERIFIER not in {OWNER, '/root', '/root/decode_b4e6a1'}
    assert audit['source_review']['checked_commit'] == CHECKED
    for item in contract['phase_manifests']:
        base = ROOT / item['directory']
        raw = (base / 'manifest.json').read_bytes()
        assert sha(raw) == item['sha256']
        for f in json.loads(raw)['files']:
            data = (base / f['path']).read_bytes()
            assert len(data) == f['bytes'] and sha(data) == f['sha256']
    # The checked mathematical commit is immutable; current HEAD may include later metadata.
    for item in contract['checked_commit_sources']:
        result = subprocess.run(['git', 'show', CHECKED + ':' + item['path']], cwd=ROOT,
                                capture_output=True, check=True)
        assert sha(result.stdout) == item['sha256']
    return {'path': contract['audit_path'], 'sha256': sha((ROOT / contract['audit_path']).read_bytes()),
            'state': audit['state'], 'source_review_state': audit['source_review']['state']}


def snapshot(contract, accepted_audit):
    raw = (ROOT / contract['advance_ledger']).read_bytes()
    records = complete_records(raw)
    states = replay(records)
    assert ADV in states
    foreign = {k: v for k, v in states.items() if k != ADV}
    assert len(foreign) == 286
    assert states[ADV]['owner_id'] == OWNER
    assert set(states[ADV]['publication_declarations']) == {contract['public_declaration']}
    frontier = {}
    for p in sorted((ROOT / 'research-wiki/frontier-cells').rglob('*.json')):
        frontier[p.relative_to(ROOT).as_posix()] = sha(p.read_bytes())
    assert contract['target_frontier'] in frontier
    assert len({k: v for k, v in frontier.items() if k != contract['target_frontier']}) == 445
    assert load(ROOT / contract['target_frontier'])['owner_id'] == OWNER
    protected = {}
    for name in contract['protected_models_and_discovery']:
        data = (ROOT / name).read_bytes()
        if name.endswith('.jsonl'):
            complete_records(data)  # no discovery recovery either
        protected[name] = {'bytes': len(data), 'sha256': sha(data)}
    observed_head = subprocess.run(['git', 'rev-parse', 'HEAD'], cwd=ROOT,
                                   capture_output=True, check=True).stdout.decode().strip()
    return raw, {'ledger_sha256': sha(raw), 'ledger_bytes': len(raw),
                 'complete_record_count': len(records), 'all_states': states,
                 'foreign_states': foreign, 'frontier_hashes': frontier,
                 'protected_models_and_discovery': protected, 'accepted_audit': accepted_audit,
                 'observed_HEAD': observed_head}


def runtime_dir(path, contract):
    out = Path(path).resolve()
    allowed = (ROOT / contract['allowed_runtime_root']).resolve()
    assert out.is_relative_to(allowed) and out != allowed
    return out


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('phase', choices=['preflight', 'execute'])
    parser.add_argument('--authorization', type=Path)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    # Authorization gating precedes all actual audit/ledger/frontier reads and any API import.
    auth, auth_ref = authorize(args.authorization, args.phase)
    contract = load(PREP / 'normal-V-contract.json')
    out = runtime_dir(args.out, contract)
    accepted_audit = static_bindings(contract)
    before, snap = snapshot(contract, accepted_audit)
    assert snap['all_states'][ADV]['state'] == 'PROVED_LOCAL'
    if args.phase == 'preflight':
        out.mkdir(parents=True, exist_ok=False)
        with (out / 'before-ledger.exact.jsonl').open('xb') as f:
            f.write(before)
        put(out / 'before-snapshot.json', snap)
        put(out / 'preflight-receipt.json', {
            'status': 'READ_ONLY_PREFLIGHT_PASSED_NOT_VERIFIED', 'normal_API_calls': 0,
            'observed_at_utc': datetime.now(timezone.utc).isoformat(), 'authorization': auth_ref,
            'prepared_manifest_sha256': sha((PREP / 'manifest.json').read_bytes()),
            'snapshot_sha256': sha((out / 'before-snapshot.json').read_bytes()),
            'before_ledger_sha256': sha(before), 'checked_commit': CHECKED,
            'accepted_audit': accepted_audit, 'foreign_state_count': 286,
            'foreign_frontier_count': 445, 'execution_authorized': False})
        return
    receipt_raw = (out / 'preflight-receipt.json').read_bytes()
    assert sha(receipt_raw) == auth['preflight_receipt_sha256']
    receipt = json.loads(receipt_raw)
    assert receipt['normal_API_calls'] == 0 and receipt['execution_authorized'] is False
    assert receipt['prepared_manifest_sha256'] == sha((PREP / 'manifest.json').read_bytes())
    assert sha((out / 'before-snapshot.json').read_bytes()) == receipt['snapshot_sha256']
    assert snap == load(out / 'before-snapshot.json'), 'HOLD: state changed after preflight'
    assert before == (out / 'before-ledger.exact.jsonl').read_bytes()
    # Exclusive marker is created before the one call. A failed call is never automatically retried.
    put(out / 'normal-API-attempt.once.json', {'action': 'one normal transition_advance call',
        'authorization': auth_ref, 'checked_commit': CHECKED,
        'armed_at_utc': datetime.now(timezone.utc).isoformat()})
    evidence = copy.deepcopy(load(PREP / 'verification-evidence-template.json'))
    evidence['source_audit']['observed_accepted_audit'] = accepted_audit
    evidence['normal_V_preflight_receipt'] = {'path': str(out / 'preflight-receipt.json'),
                                             'sha256': sha(receipt_raw)}
    put(out / 'actual-call-evidence.json', evidence)
    sys.path.insert(0, str(ROOT))
    from tools import astis_advance as advance
    assert advance._replay_advances(complete_records(before)) == snap['all_states']
    failure = None
    try:
        advance.transition_advance(ADV, 'VERIFIED', worker_id=VERIFIER,
                                   evidence=evidence, path=ROOT / contract['advance_ledger'],
                                   discovery_path=ROOT / contract['discovery_ledger'])
    except BaseException as exc:
        failure = repr(exc)
    # Observe actual bytes before deciding success. Never construct or predict an append/time/hash.
    after = (ROOT / contract['advance_ledger']).read_bytes()
    with (out / 'after-observed-ledger.exact.jsonl').open('xb') as f:
        f.write(after)
    observation = {'API_call_attempts': 1, 'API_exception': failure,
                   'before_ledger_sha256': sha(before), 'after_ledger_sha256': sha(after),
                   'old_prefix_preserved': after.startswith(before)}
    if after.startswith(before):
        appended = after[len(before):]
        with (out / 'actual-append-observed.exact.jsonl').open('xb') as f:
            f.write(appended)
        observation['observed_append_sha256'] = sha(appended)
        observation['observed_append_bytes'] = len(appended)
    put(out / 'API-observation.json', observation)
    assert failure is None, 'HOLD: API failed; retain observations; no retry or manual append'
    assert after.startswith(before)
    added = complete_records(after[len(before):])
    assert len(added) == 1
    event = added[0]
    assert (event['advance_id'], event['from_state'], event['to_state']) == (ADV, 'PROVED_LOCAL', 'VERIFIED')
    assert event['worker_id'] == event['evidence']['verifier_id'] == VERIFIER
    assert event['evidence']['verified_commit'] == CHECKED
    assert event['evidence'] == evidence
    _, post = snapshot(contract, accepted_audit)
    assert post['foreign_states'] == snap['foreign_states']
    assert post['frontier_hashes'] == snap['frontier_hashes']
    assert post['protected_models_and_discovery'] == snap['protected_models_and_discovery']
    assert post['all_states'][ADV]['state'] == 'VERIFIED'
    assert post['all_states'][ADV]['owner_id'] == OWNER
    assert static_bindings(contract) == accepted_audit
    put(out / 'after-snapshot.json', post)
    put(out / 'VERIFIED-actual-receipt.json', {
        'status': 'OBSERVED_ONE_NORMAL_VERIFIED_TRANSITION', 'normal_API_calls': 1,
        'checked_commit': CHECKED, 'worker_and_verifier': VERIFIER, 'owner_unchanged': OWNER,
        'actual_event_created_at_observed_from_ledger': event['created_at'],
        'actual_append_sha256': sha(after[len(before):]), 'raw_old_prefix_preserved': True,
        'foreign_states_preserved': 286, 'foreign_frontiers_preserved': 445,
        'all_frontiers_models_discovery_preserved': True, 'truth_boundary': evidence['truth_boundary']})


if __name__ == '__main__':
    main()
