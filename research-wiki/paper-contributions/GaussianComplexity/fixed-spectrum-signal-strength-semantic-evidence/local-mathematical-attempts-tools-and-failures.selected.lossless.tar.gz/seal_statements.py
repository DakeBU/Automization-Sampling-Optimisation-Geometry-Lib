from pathlib import Path
import json,hashlib,subprocess,datetime,gzip,sys
sys.dont_write_bytecode=True
sys.path.insert(0,'tools')
import astis_advance as adv
W=Path('.astis/huanjian-gc-fixed-spectrum-signal-strength-20261110')
sha=lambda b:hashlib.sha256(b).hexdigest()
dump=lambda x:(json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode()
def ref(p):
    p=Path(p);return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())}
def put(p,b):
    assert not p.exists(),p
    p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
def git(*args):return subprocess.check_output(['git',*args],text=True).strip()
head=git('rev-parse','HEAD')
assert head=='348f1f34ada0e9d4f46dfa1a4b1b983ab748bb62'
assert not (W/'StatementFormation.lean').exists()
probe=(W/'statement-formation-probe.raw.lean.txt').read_bytes()
assert sha(probe)=='74a5478626ad9e9e2e86e838f556bec3b7408a1ef17576c6f15312d10aa06f6f'
assert gzip.decompress((W/'StatementFormation.lean.gz').read_bytes())==probe
rp=Path('.astis/huanjian-resume-20261103/20261110T005606000892Z-signal-strength-exact-source-regime-Prop-only-statement-formation.receipt.json')
rr=json.loads(rp.read_bytes());assert rr['exit_code']==0 and sha(Path(rr['log']).read_bytes())==rr['log_sha256']
source=Path('.astis/huanjian-resume-20261103/2610.20492v1.html')
assert sha(source.read_bytes())=='6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
lean=subprocess.check_output(['lake','env','lean','--version'],text=True).strip()
prefix=subprocess.check_output(['lake','env','lean','--print-prefix'],text=True).strip()
binary=Path(prefix)/'bin/lean'
assert '4.33.0' in lean and sha(binary.read_bytes())=='1b370cfcbf44e80d1b004ab1b1ab9a4c73951f9f7c242140bcff9bc577576554'
manifest=Path('lake-manifest.json')
assert sha(manifest.read_bytes())=='b83ca83b9cf7caa85fa8b023c2ff9a3fb7a7cce7e1c332e810c348535ec49c37'
packages=[]
for p in json.loads(manifest.read_bytes())['packages']:
    d=Path('.lake/packages')/p['name'];h=git('-C',str(d),'rev-parse','HEAD');st=git('-C',str(d),'status','--porcelain')
    assert h==p['rev'] and not st
    packages.append({'name':p['name'],'actual_HEAD':h,'manifest_rev':p['rev'],'tracked_and_untracked_clean':True})
L=Path('runs/substantive_advances.jsonl')
states=adv._replay_advances([json.loads(x) for x in L.read_bytes().splitlines()])
base={'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'working_HEAD':head,'Lean_actual':lean,'binary':ref(binary),'manifest':ref(manifest),'packages':packages,'ledger':ref(L),'all_current_SAU_states':states,'all_frontier_hashes':{str(p):sha(p.read_bytes()) for p in Path('research-wiki/frontier-cells').glob('*.json')},'existing_ModeGap_original_verifier_may_finish_separately':'Source62 is already authorized for exactly one normal sourceV; this seal does not authorize or count that mutation as new signal-strength work. Refresh normal intake preservation baseline after its byte-exact carry.','no_target_proof_or_API_search_or_new_SAU_or_STAB':True}
put(W/'preproof-baseline.json',dump(base))
exposure={'root_prior_exposure':'Root authored the canonical Gaussian stack and ModeGap packet, has full original-source and old-proof knowledge, and has seen the earlier packet independent reviews. No pristine root ignorance is claimed.','scope_selection_before_seal':'Root reread the original C.3 and4.3 raw-derived text, considered concrete tau/event versus signal-strength packet boundaries and informal arithmetic implications of exact M and polynomial bias. It selected the explicit M lower and M beta squared lower with a PRIVATE zero-threshold actual-law probability consumer. Informal possible proof ingredients include the existing finite gap, radius-tail control, power arithmetic and Chebyshev; these are root expectations, not the source graph or reviewer evidence.','new_tools_before_seal':'Only exact target/name inventory (no matches), raw-source reading/extraction, exact signature composition and Prop-valued statement formation. A python3 source-parser invocation lacked bs4; the same read-only source extraction succeeded with installed /opt/anaconda3 Python. This is environmental, not mathematical evidence. No new target proof body or new generic Mathlib proof/API retrieval.','temporary_probe':'The successful Prop-valued formation probe is byte-preserved as non-Lean text and lossless gzip and ACTUALLY deleted before this seal, with no proof credit.','role_independence':'Raw-first graph and distinct topology roles must freeze their own cognition before receiving the strict statement/definition projection; root route expectations and prior verdicts are excluded.'}
put(W/'preseal-exposure-disclosure.json',dump(exposure))
prod=(W/'producer-signature.txt').read_text();cons=(W/'consumer-signature.txt').read_text()
assert not Path('AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumSignalStrength.lean').exists()
assert not Path('Tests/GaussianComplexityFixedSpectrumSignalStrength.lean').exists()
binders=[]
for owner in ['producer','private_consumer']:
    for binder,kind,reason in [
      ('delta:Real','TYPING','Real fixed parameter.'),
      ('0<delta;delta<1','SOURCE','Original fixed delta in(0,1).'),
      ('FORALL d:Nat','TYPING','Natural finite dimension.'),
      ('d0<=d','SOURCE','Original sufficiently-large dimension qualifier; d0 is produced internally.'),
      ('FORALL kappa:Real','TYPING','Real condition-number carrier.'),
      ('2<=kappa;kappa<=(d:Real)^(1-delta)','SOURCE','Original inclusive condition range.'),
      ('FORALL q:Nat','TYPING','Source nonnegative INTEGER deterministic query cap, including0.'),
      ('(q:Real)<=(delta/256)*sqrt(kappa)*log(d:Real)','SOURCE','Original exact query cap. No expected-cost interpretation.')]:
        binders.append({'owner':owner,'binder':binder,'class':kind,'reason':reason})
producer={'name':'AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumSignalStrength.eventual_actual_gaussian_signal_strength','planned_file':'AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumSignalStrength.lean','signature':prod,'signature_sha256':sha(prod.encode()),'definition_kind':'literal'}
consumer={'name':'actual_gaussian_source_query_zero_event_le_tenth','planned_file':'Tests/GaussianComplexityFixedSpectrumSignalStrength.lean','signature':cons,'signature_sha256':sha(cons.encode()),'definition_kind':'literal','is_source_anchor':False,'Registry_node':False,'scope_difference':'PRIVATE zero-threshold signed-cosine bad-event bound under the actual diagonal Gaussian, uniform in the original scalar source regime. The actual source detector subtracts2*tau*norm squared and uses a rotated law. This consumer does NOT prove that detector or fullEx26.'}
defs=[{'object':'delta,d0,d,kappa,q,n','definition_kind':'literal','meaning':'Fixed original scalar regime, natural dimension/query cap and literal n=2*q+1. d0 is an existential output before all varying parameters, not an assumed certificate.'},{'object':'theta,eigenvalue,Lambda','definition_kind':'literal','meaning':'Source midpoint grid and diagonal precision, with Fin d zero-based i.val corresponding to source i=i.val+1.'},{'object':'mu','definition_kind':'literal','meaning':'Centered multivariateGaussian with covariance Lambda inverse, not Lambda. Positive spectral domain/PSD/inverse and integrability must be established internally on the selected source regime; standard off-domain conventions are not new fallback definitions.'},{'object':'Q,M,b,beta,B','definition_kind':'literal','meaning':'Same actual-law cosine quadratic and Bochner-integral means. beta=abs(b)/M, B=(1-exp(-4))*exp(-3). Lean b denotes source mu_n; Lean B denotes source scalar b. beta normalization has no dimension factor. M and beta positivity are outputs.'},{'object':'rpow,sqrt,log,toReal,event','definition_kind':'standard literal','meaning':'All positive-base/log/sqrt and finite-measure toReal uses require internal domain proofs. Private event is the actual signed Q<=0 measurable event; no free law, moment or event-probability certificate.'}]
seal={'schema_version':1,'seal_id':'GC-FIXED-SPECTRUM-ACTUAL-SIGNAL-STRENGTH-20261110-v1','state':'EXACT_LITERAL_TYPES_FORMED_PREPROOF_SOURCE_TOPOLOGY_PENDING','source':{'title':'On Complexity of Gaussian Sampling','version':'arXiv2610.20492v1','raw':ref(source),'standing_anchors':['S2','S4.SS1.p1','S4.SS3.p2','S4.SS3.p3','S4.Thmtheorem5'],'producer_anchors':['S4.SS3.SSS0.Px2.p1','S4.SS3.SSS0.Px2.p2','S4.Ex23','S4.Ex24','A3.SS3'],'scope':'Actual M lower bounds and literal M beta squared>=B squared sqrt(d)/2, uniformly under the original fixed-delta,condition-number,query-cap range. The private actual-law zero-event application is explicitly narrower than the original shifted detector.'},'producer':producer,'actual_private_consumer':consumer,'binder_audit':binders,'existential_output_audit':[{'owner':o,'output':'EXISTS d0:Nat','class':None,'is_input_assumption':False,'dependencies':['delta','source proof constants'],'quantifier_order':'After fixed delta and its guards, before ALL d,kappa,q; no per-kappa/q threshold or law/gap/growth input.'} for o in ['producer','private_consumer']],'EXCESS_public_binders':[],'definition_audit':defs,'no_project_owned_Prop_alias_inputs':True,'internal_dependencies_not_extra_binders':['Source finite dimension/mode/gap validity','Actual covariance positivity, moments/integrability and exact mean M','Actual signed bias and its source-query polynomial lower bound','All positivity/cast/power/sqrt estimates','Private variance and genuine Chebyshev/event finite-measure estimates'],'scope_boundary':['No concrete tau_dq or tau/beta smallness','No shifted contrast or fullEx25/26','No rotated-law transport or Chebyshev matrix-polynomial event identity','No Krylov/Haar/concentration/adaptive histories/output law','No algorithm/oracle/TV/precision or expected-cost adapter','No main-lower-bound/full source assembly/global integration/site/browser/public/purification/whole-Goal completion'],'statement_formation':{'receipt':ref(rp),'proof_credit':False,'exit_code':0,'warning_scope':'Unused hdelta proof arguments in Prop-valued formation definitions only.','deleted_probe':ref(W/'statement-formation-probe.raw.lean.txt'),'lossless_gzip':ref(W/'StatementFormation.lean.gz'),'temporary_Lean_probe_currently_absent':True},'preseal_exposure':ref(W/'preseal-exposure-disclosure.json'),'shared_floor_audit':{'searched_before_seal':'Exact proposed names/filename inventory in AutoSamplingTheory,Tests and existing frontier cells returned no match. No generic API absence claim; generic Samplinglib/Mathlib retrieval deferred until independent source/topology admission.','status':'provisional-reuse-existing-actual-Gaussian-spine','canonicality':'Do not duplicate public compiled Gaussian nodes. A source-only graph is not a compiled dependency claim. Exact emitted parents and any repeated provider need later kernel/whole-module audit.'},'role_boundary':'One root proof worker. Source graph and different topology review before new proof/API search; fresh decoder, fresh anti-anchored source review, independent native/full-module/reader after proof. No normal state transition or new ownership is claimed by this seal.'}
put(W/'statement-seal-v1.json',dump(seal))
projection={'purpose':'After own raw-first cognition: exact statements and literal definition semantics only. No implementation, dependency suggestions, source graph, binder verdict, root proof-route expectations or prior mathematical verdict.','source':seal['source'],'producer':{k:producer[k] for k in ['name','planned_file','signature','signature_sha256','definition_kind']},'actual_private_consumer':{k:consumer[k] for k in ['name','planned_file','signature','signature_sha256','definition_kind','is_source_anchor','Registry_node','scope_difference']},'definition_audit':defs}
put(W/'strict-preproof-seal-projection-v1.json',dump(projection))
print(json.dumps({'seal':ref(W/'statement-seal-v1.json'),'projection':ref(W/'strict-preproof-seal-projection-v1.json'),'baseline_states':len(states),'temporary_Lean_probe_absent':True,'proof_or_new_SAU_started':False}))
