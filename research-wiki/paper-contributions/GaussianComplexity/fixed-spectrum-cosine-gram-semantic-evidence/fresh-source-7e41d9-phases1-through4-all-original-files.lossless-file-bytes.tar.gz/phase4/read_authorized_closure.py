#!/opt/anaconda3/bin/python
import hashlib,json,pathlib
ROOT=pathlib.Path('/Users/zhouhuanjian/ASTIS-GC');BASE=pathlib.Path(__file__).resolve().parent
E='research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-cosine-gram-semantic-evidence/'
spec=[(E+'fresh-native-0a91de-original-findings.json','7287d0d751f44786643207352cf326a9f5d7300070a13b8b8596c81da2111052'),
      (E+'fresh-native-0a91de-original-freeze-manifest.json','613ca1b57a2a9bb65592a0d8998968c07d60bb2e86e722144cab4206c9c0fa6d'),
      (E+'fresh-native-0a91de-original-outer-receipt.json','4f982018a158fc9e1b4e2e270dcfd2fd0f9a4f0f5584158f0f053826448df7e5'),
      ('research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-cosine-gram.json',None)]
(BASE/'inputs').mkdir(exist_ok=True)
records=[]
for name,expected in spec:
    data=(ROOT/name).read_bytes();digest=hashlib.sha256(data).hexdigest()
    if expected:assert digest==expected,(name,digest)
    target='inputs/'+pathlib.Path(name).name
    (BASE/target).write_bytes(data)
    rec={'source':name,'snapshot':target,'bytes':len(data),'sha256':digest,
         'supplied_expected_sha256':expected}
    records.append(rec);print('INPUT',json.dumps(rec));print(data.decode())
(BASE/'input_inventory.json').write_text(json.dumps(records,indent=2)+'\n')
