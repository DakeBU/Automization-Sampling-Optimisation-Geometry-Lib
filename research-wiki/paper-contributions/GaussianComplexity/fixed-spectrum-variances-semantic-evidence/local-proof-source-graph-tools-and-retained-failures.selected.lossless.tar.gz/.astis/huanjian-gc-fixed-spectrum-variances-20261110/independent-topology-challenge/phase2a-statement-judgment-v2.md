# Variance strict projection: limited corrected-input judgment v2

**ACCEPT for this exact strict v2 statement/binder/definition/meaning projection.** `H-PRIVATE-TAU-ANCHOR-CLASSIFICATION` is resolved by the explicit public/private audit separation. The original v1 HOLD is retained unchanged as historical evidence. This is not final source-topology admission, proof verification, compilation credit or source V.

Exact input: `strict-preproof-seal-projection-v2.json`, 11071 bytes, SHA-256 `76136b7367d19fd1b98583adc5f4fae17330a817ad2c1a330300e399b0925b85`. It binds full-seal-v2 SHA-256 `77e6ee5f01804f871bcd798cb7a1e87093d08be3193ea280dc9b0783e5fddec9`. Neither full seal was opened. This limited review uses the previously frozen raw cognition and exact v1 judgment, followed by the separately frozen process audit, and then the authorized strict v2 correction. No extractor graph has been read.

## Exact repair independently checked

The public `binder_audit` now has exactly the original seven producer entries, equal to v1's original seven entries. d/κ/n carriers are TYPING, d≥2 and κ≥2 are STANDING, and 1≤n and n<d are SOURCE. There is no τ, integrability, fourth moment, independence, variance or upper-bound premise in this public Anchor audit, and no EXCESS public binder.

The private helper is explicitly a non-Anchor Internal Provider / local numerical generalization, with `is_source_anchor:false` and `Registry_node:false`. Its arbitrary real τ carrier is separate from the Source Anchor taxonomy. Each logical guard 0≤τ and τ≤1/2 has `source_anchor_classification:null`, `assumed_in_private:true`, `proved_fact:false` and `inherited_by_public_anchor:false`. The exact inequalities remain genuine private assumptions; they have not been relabeled TYPING or proved. The boundary explicitly says there is no sixth Anchor bin and promotion of these assumptions into the public paper Anchor would be EXCESS.

The concrete source application still has its own τ_dq, n=2q+1, query/large-d conditions and rotated-target transport. Mean separation and probability need their original extra conditions. The corrected private audit explicitly leaves these later application bridges internal and unclaimed. No RULED source correction or invented source provenance is needed to accept this properly separated local helper.

Both exact signature strings are byte-identical to v1, independently rehashed:

- Producer: 1146 bytes, SHA-256 `f50522ee008465b5b71e626aefdf25cb48c61377b85cb4545d76099a808d14ec`.
- Private consumer: 901 bytes, SHA-256 `452584c79fa900334f60d073de72607eadbc221f913ade78050765fcf2d9c9b2`.

Source metadata, all definition-audit entries and both embedded standard definition strings are exactly unchanged. The only projection changes are the full-seal hash/predecessor link and this audit-scope metadata repair, as recorded by the exact recursive diff. The complete producer record is unchanged; the complete old private-consumer record is unchanged after removing only the three added role/Anchor/registry fields from v2. No source formula, semantic signature, output or public mode range changed.

## Inherited mathematical and semantic admission limits

The previous independent raw/statement reasoning still applies. The measure is the actual centered Gaussian with covariance Λ⁻¹, with Λ the source diagonal precision; covariance positivity/invertibility and constructor interpretation remain internal obligations. M is the actual norm-square integral. The producer outputs actual L2 facts, exact variances with factor 2 and denominator λᵢ², the two ≤2M bounds and 2M≤2d/√κ. These are not definitions or input certificates.

Real variance is totalized through `evariance.toReal`, and its centered mean is totalized too. Actual MemLp2/probability/centering/finite-moment facts must therefore be established internally, rather than relying on default values. The private Z has substantive actual L2 and variance outputs. A valid use must materially consume both norm-square and cosine-quadratic outputs and handle their dependence through a valid centered L2/covariance estimate; it may not assume the two statistics are independent. Actual proof use remains a later check.

No full Ex25, mean separation, positive mean, Chebyshev probability, algorithmic event, rotated-Y law or main lower-bound credit is admitted. Final exhaustive coverage, source/proof-premise distinction, conditional discharge and both source-root closures remain pending the exact frozen extractor machine graph.

## Exposure and process qualification retained

The independent statement v1 judgment was frozen before the detailed API-exposure disclosure. The separate process audit records a broad accidental preseal API declaration-name/initial-signature-line query. It does not certify pristine API-blind ordering or root never seeing APIs. The record's no-proof-body/no-target-authorship claims are attributed to the disclosure, not independently proved by reading forbidden logs or implementation. This limitation survives v2 acceptance; it is neither erased by metadata correction nor used as mathematical evidence.

Prior C7/grid/means review exposure and root-relayed matching classification HOLD remain disclosed. No fresh-zero-cue or verdict-blind claim is made. The raw cognition, v1 HOLD and separate process-audit files/checksum sets were independently rechecked unchanged while freezing this limited successor.

No implementation, new proof plan, actual API inventory, extractor graph/private rationale, full seal, build, ledger/normal transition, source V, site or shared mutation was performed. Stop before topology review; this verdict does not open a proof gate by itself.
