"""Run current production lesson renderer on bounded immutable candidate input."""
import hashlib,html,json,pathlib,re,shutil,sys
from html.parser import HTMLParser
from run import ROOT,REPO
sys.path[:0]=[str(REPO/'tools'),str(REPO/'website/scripts')]
import astis_site as base, declaration_lessons as lessons, inline_lean, astis_publication as pub
m=json.loads((ROOT/'input-manifest.json').read_text());inputs=ROOT/'inputs'
unit=json.loads((inputs/'website/content/declaration_lessons/huanjian-gaussian-weighted-cosine-frame.json').read_text())['units'][0]
item=json.loads((inputs/'website/content/publications/huanjian-gaussian-weighted-cosine-frame.json').read_text())['items'][0]
# Repoint source reads and bound the parser to exactly the six frozen modules.
base.ROOT=inputs;lessons.ROOT=inputs;pub.ROOT=inputs
base.project_lean_paths=lambda: [inputs/p for p in m['modules']]
mods,decls=base.scan_project_sources();known={d.full_name:d for d in decls}
base._SOURCE_BY_NAME=known;inline_lean.declarations.cache_clear()
base._ACTIVE_GIT=base.GitContext(commit=m['candidate_commit'],ref='frozen-native-verifier',remote_url='',web_root='',commit_published=False,public_source_links=False,dirty_files=set())
assert len(decls)==6
binding=pub.binding_digest(item,item['bindings'][0],{'declarations':known,'lessons':{unit['declaration']:unit}})
assert binding=='dafe229bd9184d3640797f51b3dfd581c8408ede198d973d58ba3cd8af7becdd',binding
page='proofs/source-'+item['id']+'.html'
body=lessons.render_unit(unit,page)
out=ROOT/'reader';(out/'proofs').mkdir(parents=True,exist_ok=True)
target=out/page;target.write_text(base.page(unit['title'],page,body))
class Node:
    def __init__(self,tag,attrs,parent=None): self.tag=tag;self.attrs=dict(attrs);self.parent=parent;self.children=[];self.data=''
    def all(self,tag): return ([self] if self.tag==tag else [])+[a for c in self.children for a in c.all(tag)]
    def text(self): return self.data+''.join(c.text() for c in self.children)
class Parse(HTMLParser):
    def __init__(self):super().__init__();self.root=Node('root',[]);self.stack=[self.root]
    def handle_starttag(self,t,a):
        n=Node(t,a,self.stack[-1]);self.stack[-1].children.append(n)
        if t not in {'meta','link','br','hr','input','img','source','area','base','embed','param','track','wbr'}:self.stack.append(n)
    def handle_endtag(self,t):
        for i in range(len(self.stack)-1,0,-1):
            if self.stack[i].tag==t:self.stack=self.stack[:i];break
    def handle_data(self,d):self.stack[-1].data+=d
p=Parse();p.feed(body)
details=p.root.all('details');assert all('open' not in n.attrs for n in details)
steps=[n for n in details if 'reader-proof-disclosure' in n.attrs.get('class','').split()];assert len(steps)==6
step_receipts=[]
for i,(node,step) in enumerate(zip(steps,unit['steps']),1):
    nested=[n for n in node.children if n.tag=='div'][0]
    folds=nested.all('details');assert len(folds)==1
    code=folds[0].all('code');assert len(code)==1 and code[0].text()==step['lean']
    owners=[p for p in m['modules'] if step['lean'] in (inputs/p).read_text()]
    assert len(owners)==1,(i,owners)
    raw=(inputs/owners[0]).read_text();start=raw.index(step['lean']);line=raw[:start].count('\n')+1
    step_receipts.append({'step':i,'source':owners[0],'start_line':line,'lines':len(step['lean'].splitlines()),'sha256':hashlib.sha256(step['lean'].encode()).hexdigest(),'fold_exact':True,'initially_closed':True})
consumer=next(d for d in decls if d.short_name=='actual_uncentered_second_moment_sum_bound')
assert consumer.source_line==14
source=(inputs/consumer.source_file).read_text();declpart=source.splitlines()[13:180]
# The source ends at line181 and the exact whole module is 181 lines.
assert len(source.splitlines())==181
assert 'private theorem actual_uncentered_second_moment_sum_bound' in source.splitlines()[13]
joined=''.join(s['lean'] for s in unit['steps'][2:])
assert joined==source.replace('\n\n  -- Integrate the whole PSD residual sum','\n  -- Integrate the whole PSD residual sum')
assert unit['steps'][0]['lean']+unit['steps'][1]['lean'] in (inputs/m['modules'][4]).read_text()
assert item['statement']==unit['statement'] and item['assumptions']==unit['assumptions']
assert item['formulae'][0]['tex']==unit['formula']
assert item['formulae'][1]['tex']==unit['steps'][3]['formula']
assert item['formulae'][2]['tex']==unit['steps'][5]['formula']
# Generate bounded exact local source anchors and downloads using production code.
lessons.export_sources(out,[unit])
for d in decls:
    download=out/'downloads/lean'/d.source_file;download.parent.mkdir(parents=True,exist_ok=True);download.write_bytes((inputs/d.source_file).read_bytes())
    modulepath=out/'modules'/(base.slugify(d.module)+'.html');modulepath.parent.mkdir(exist_ok=True)
    modulepath.write_text('<!doctype html><html><body><pre id="complete-module-source">'+html.escape((inputs/d.source_file).read_text())+'</pre></body></html>')
links=[n.attrs.get('href','') for n in p.root.all('a')]
local_source=[l for l in links if 'data/lesson-sources/' in l]
assert len(local_source)==1 and local_source[0].endswith('.lean.html#L14')
for l in [x for x in links if 'downloads/lean/' in x or 'modules/' in x or 'data/lesson-sources/' in x]:
    dest=(target.parent/l.split('#')[0]).resolve();assert dest.is_relative_to(out) and dest.exists(),l
    if '#' in l: assert 'id="'+l.split('#')[1]+'"' in dest.read_text(),l
runtime=[]
for path in [REPO/'tools/astis_site.py',REPO/'tools/astis_publication.py',REPO/'website/scripts/declaration_lessons.py',REPO/'website/scripts/inline_lean.py',REPO/'website/scripts/source_lineage.py']:
    b=path.read_bytes();dst=ROOT/'runtime'/path.relative_to(REPO);dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(b)
    runtime.append({'path':str(path.relative_to(REPO)),'sha256':hashlib.sha256(b).hexdigest()})
result={'candidate_commit':m['candidate_commit'],'binding_sha256':binding,'production_renderer_runtime':runtime,'six_exact_adjacent_step_folds':step_receipts,'all_details_initially_closed':True,'consumer_module_lines':181,'consumer_starts_at':14,'consumer_four_step_concat_complete_except_one_blank_separator_line':True,'static_source_links_resolve':True,'rendered_page':str(target.relative_to(ROOT)),'html_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'scope':'Bounded production render_unit and export_sources; exact frozen source with local anchor/download files. No whole site generated. No public/integration/status acceptance.','HOLD':['actual browser desktop','actual browser mobile','graph interactions','copy runtime','download runtime','public delivery','MathJax runtime layout']}
(ROOT/'reader-static.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
