from pathlib import Path
import gzip, hashlib, json, subprocess, tarfile

R = Path('.astis/huanjian-gc-fixed-spectrum-first-order-integration-20261108')
J = Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-first-order-integration-20261108')
CORE = '9b1e90d25711668203c6e252cfe5a748f95c8ad4'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == CORE
assert not subprocess.check_output(['git', 'diff', '--cached', '--name-only']).strip()
checks = J/'finalmetadata-checks'
checks.mkdir()
labels = ['fixed-spectrum-first-order-final-local-metadata-projection',
          'fixed-spectrum-first-order-finalmetadata-publication',
          'fixed-spectrum-first-order-finalmetadata-contributor',
          'fixed-spectrum-first-order-finalmetadata-semantic',
          'fixed-spectrum-first-order-finalmetadata-frontier']
for label in labels:
    receipts = list(Path('.astis/huanjian-resume-20261103').glob('*-'+label+'.receipt.json'))
    assert len(receipts) == 1
    p = receipts[0]
    d = json.loads(p.read_bytes())
    assert d['exit_code'] == 0 and d['head_before'] == d['head_after'] == CORE
    log = Path(d['log'])
    raw = log.read_bytes()
    assert sha(raw) == d['log_sha256']
    (checks/p.name).write_bytes(p.read_bytes())
    z = checks/(log.name+'.gz')
    z.write_bytes(gzip.compress(raw, mtime=0))
    assert gzip.decompress(z.read_bytes()) == raw
files = sorted(p for p in J.rglob('*') if p.is_file())
tracked = set(subprocess.check_output(['git', 'ls-files', '-z']).decode().split('\0'))
ignored_result = subprocess.run(['git', 'check-ignore', '-z', '--stdin'],
    input=b'\0'.join(str(p).encode() for p in files)+b'\0', capture_output=True)
assert ignored_result.returncode in (0, 1)
ignored = set(ignored_result.stdout.decode().split('\0'))
def unsafe(p):
    raw = p.read_bytes()
    if p.suffix in ['.gz', '.png', '.zip'] or b'\0' in raw: return False
    return b'\r\n' in raw or raw.endswith(b'\n\n') or any(line.endswith((b' ', b'\t')) for line in raw.splitlines())
excluded = [p for p in files if str(p) not in tracked and (str(p) in ignored or unsafe(p))]
private = sorted(R.glob('*.py')) + [R/'independent-reader'/name for name in
    ['check_final_reader_v4.py', 'first_order_browser_common_v4.py',
     'prepare_ui_successor_v4.py', 'record_local_acceptance_and_eligibility_v4.py']]
originals = sorted(set(excluded+private))
archive, manifest = J/'final-runtime-originals.lossless.tar.gz', J/'final-runtime-originals.manifest.json'
assert not archive.exists() and not manifest.exists()
with tarfile.open(archive, 'w:gz') as t:
    for p in originals: t.add(p, arcname=str(p), recursive=False)
with tarfile.open(archive, 'r:gz') as t:
    assert len(t.getmembers()) == len(originals)
    for p in originals: assert t.extractfile(str(p)).read() == p.read_bytes()
manifest.write_text(json.dumps({'archive': str(archive), 'archive_sha256': sha(archive.read_bytes()),
    'originals_retained_without_normalization_or_deletion': True,
    'scope': 'Final metadata packaging only; actual accepted build/UI core9b and original actor normalpark evidence remain distinct. No fresh-build/newsource/remote/wholeGoal credit.',
    'files': [{'original': str(p), 'member': str(p), 'raw_sha256': sha(p.read_bytes()),
               'raw_bytes': p.stat().st_size} for p in originals]}, ensure_ascii=False, indent=2)+'\n')
mutable = [Path('runs/substantive_advances.jsonl'),
           Path('research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-first-order.json'),
           Path('research-wiki/paper-contributions/GaussianComplexity/README.md')]
paths = sorted(set([p for p in files if p not in excluded]+mutable+[archive, manifest]))
subprocess.run(['git', 'add', '--', *map(str, paths)], check=True)
subprocess.run(['git', 'diff', '--cached', '--check'], check=True)
staged = subprocess.check_output(['git', 'diff', '--cached', '--name-only', '-z']).decode().strip('\0').split('\0')
for name in staged:
    p = Path(name)
    assert p in mutable or p.is_relative_to(J), name
    assert subprocess.check_output(['git', 'show', ':'+name]) == p.read_bytes(), name
for p in mutable: assert subprocess.check_output(['git', 'show', ':'+str(p)]) == p.read_bytes()
out = J/'final-staging-readback.json'
assert not out.exists()
result = {'accepted_immutable_core': CORE, 'stage': 'FINAL_METADATA_ONLY_NO_FRESH_BUILD_CREDIT',
    'staged_paths_before_this_result': len(staged), 'all_staged_bytes_match_live_exactly': True,
    'mutable_ledger_frontier_README_staged_directly_and_exact': {str(p): sha(p.read_bytes()) for p in mutable},
    'archive': str(archive), 'archive_sha256': sha(archive.read_bytes()),
    'raw_originals_retained': len(originals), 'unsafe_or_ignored_direct_stage_exclusions': [str(p) for p in excluded],
    'foreign_or_next_packet_path_staged': False, 'new_sourceV_or_root_lifecycle_API': False, 'Goal_complete': False}
out.write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n')
subprocess.run(['git', 'add', '--', str(out)], check=True)
assert subprocess.check_output(['git', 'show', ':'+str(out)]) == out.read_bytes()
subprocess.run(['git', 'diff', '--cached', '--check'], check=True)
print(json.dumps({'staged_paths': len(staged)+1, 'raw_originals_losslessly_retained': len(originals),
                  'unsafe_or_ignored_direct_stage_exclusions': len(excluded),
                  'mutable_and_all_staged_index_bytes_exact': True, 'Goal_complete': False}))
