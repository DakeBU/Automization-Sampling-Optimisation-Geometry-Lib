import AutoSamplingTheory.ExampleCases.ProximalBPS.ActualAbsoluteNextEventTime

/-! Private final conversion; the all-test premise must be produced by induction. -/
namespace OrderedMeasureClosure92
open MeasureTheory
open scoped ENNReal
noncomputable section
set_option autoImplicit false

private theorem law_and_mass_of_all_tests {Ω X H : Type*}
    [MeasurableSpace Ω] [MeasurableSpace X] [MeasurableSpace H]
    (P : Measure Ω) [IsProbabilityMeasure P] (m : Measure X)
    (B : Set Ω) (history : Ω → H) (K : X → H) (q : X → ℝ≥0∞)
    (hH : Measurable history) (hK : Measurable K) (hq : Measurable q)
    (htest : ∀ F : H → ℝ≥0∞, Measurable F →
      (∫⁻ w in B, F (history w) ∂P) = ∫⁻ t, F (K t) * q t ∂m) :
    Measure.map history (P.restrict B) = Measure.map K (m.withDensity q) ∧
      (∫⁻ t, q t ∂m) = P B ∧ P B ≤ 1 := by
  refine ⟨?_, ?_, prob_le_one⟩
  · apply Measure.ext_of_lintegral
    intro F hF
    rw [lintegral_map hF hH, lintegral_map hF hK,
      lintegral_withDensity_eq_lintegral_mul m hq (hF.comp hK)]
    exact (htest F hF).trans (lintegral_congr fun _ => mul_comm _ _)
  · have h := htest (fun _ => 1) measurable_const
    simpa only [one_mul, lintegral_const, Measure.restrict_apply MeasurableSet.univ,
      Set.univ_inter] using h.symm

end
end OrderedMeasureClosure92
