"""Seal full v5 review, exact original replay and new CRLF regression."""
import datetime, hashlib, json, os, pathlib, stat

D=pathlib.Path(__file__).resolve().parent
def sha(b):return hashlib.sha256(b).hexdigest()
def put(rel,b):
 p=D/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b if isinstance(b,bytes) else b.encode());return p
def js(rel,o):return put(rel,json.dumps(o,ensure_ascii=False,indent=2)+'\n')
progress=json.loads((D/'scope-and-progress.json').read_bytes())
replay=json.loads((D/'replay-original/result.json').read_bytes())
reg=json.loads((D/'counterexample-CRLF/observed-regression.json').read_bytes())
receipt=json.loads((D/'review.receipt.json').read_bytes());assert receipt['exit_code']==0
findings={
 'schema':'astis-independent-disabled-v5-ui-review/v1',
 'candidate':'72e5d1405284f729f4eb600c5ae5dd556365b7e2',
 'reviewer':'reader-step-neighbor-v5-independent-0a91de',
 'proposal_sha256':sha((D/'proposal.py').read_bytes()),
 'v4_sha256':sha((D/'proposal-v4.exact.py').read_bytes()),
 'production_sha256':sha((D/'production.py').read_bytes()),
 'patch_sha256':sha((D/'reader-step-neighbor.patch').read_bytes()),
 'decision':'v4 Unicode routing defect fixed; new CRLF sourceHTML presentation regression requires repair; no HOLD release',
 'exact_delta':'Independently asserted exact v4 renderer with only the one advertised source_lines assignment replacement equals complete supplied v5 bytes. Matching/copy/routing/path/URL/symlink/candidate/download logic otherwise byte-identical.',
 'original_frozen_counterexample_replay':replay,
 'real_C5_static':{
   'routes':['P34','P54','P125','P156','T59','T13'],
   'all_six_code_and_formula_folds_exact_and_initially_closed':True,
   'all_six_copy_panel_button_live_status_structures_meet_actual_candidate_JS_selectors':True,
   'full_T_bytes':7494,'full_T_sha256':'90b43f488d3fe9b6c95d4c039d0f771ee5bfecdd699b72dfa52465643f0b0dee',
   'P_and_T_sourceHTML_and_byte_exact_raw_downloads':True,
   'scope':'Structural/static checks only; no unavailable JavaScript, clipboard or live browser success claimed.'},
 'independent_controls':{
   'newline_anchor_raw_download_cases_passed':progress['newline_matrix_cases_passed'],
   'newline_cases':'LF, exact CRLF versus nonmatching normalized LF, CR-only and embedded CR, U+2028/U+2029/U+0085/vertical-tab/form-feed, multibyte text, zero/one/two/three terminal LFs, empty/blank files, snippet ending before LF and terminal-LF-inclusive end lines.',
   'matching_controls_passed':progress['previous_exact_match_controls_passed'],
   'path_URL_symlink_controls_passed':progress['previous_path_URL_symlink_controls_passed'],
   'canonical_export_controls_passed':progress['previous_canonical_export_controls_passed'],
   'matching_validation_scope':'Actual rerun in v5 of unique, absent, overlapping/repeated, cross-file, duplicate-citation, canonical-only, UTF8 and newline byte matching; bounded unsafe path/URL/source-symlink rejection and positive compatibility fixtures. Not a security proof or whole-site compatibility claim.'},
 'new_regression':reg,
 'other_CR_presentation_mismatch_cases':progress['sourceHTML_presentation_mismatches'],
 'required_minimal_concrete_repair_boundary':[
   'Keep raw-LF sourceHTML anchor partition so the exact frozen U+2028 counterexample remains fixed.',
   'Normalize only sourceHTML presentation at CRLF/terminal-CR boundaries so a CR retained inside a span is not followed by a second display LF outside the span. Preserve strict raw UTF8 source bytes for matching and downloads.',
   'Retain focused assertions for exact source anchors and raw downloads, plus the ordinary CRLF sourceHTML fixture demonstrating one display line break per source line after static HTML CR preprocessing. Cover the CR-only terminal case too.',
   'Review the next disabled overlay independently. Do not adopt shared code, repeat native mathematics, rewrite any earlier review/HOLD or claim browser/global delivery from static output.'
 ],
 'real_attempt_accounting':{
   'new_review_driver_exit_code':0,'new_failed_verifier_attempts':0,
   'retained_raw_outputs':['review.stdout.raw.txt','review.stderr.raw.txt','review.receipt.json'],
   'previous_unavailable_JS_runtime_attempts':'Not repeated or relabeled. This review checks exact existing handler selectors against actual generated DOM structures only; unavailable runtime/clipboard/browser acceptance stays unavailable.',
   'author_reports':'No author PASS report used as acceptance evidence. Supplied renderer/patch bytes and independent replay controls determine these findings.'},
 'fixture_limits':'Actual production/proposed renderer functions and export_sources/base.page used with identity source_lineage shell overlay, unpublished Git and passed=false gate. CR preprocessing is an explicit static parser-input fixture, not a live browser observation.',
 'preservation':'Only specifically requested exact own v4 renderer, original review script and frozen original Unicode source/record were copied read-only into this review. All prior freezes/HOLDs remain byte-identical; no tracked/shared file or metadata changed and no reviewer renderer repair implemented.',
 'authority_boundary':'Prospective UI-only review. No mathematical/sourceV/native build/JavaScript/clipboard/browser/global acceptance. Stop after freeze.'
}
js('findings.json',findings)
put('findings.txt',
 'v5 exactly changes only source_lines raw UTF8/LF partition. Original frozen U+2028 source/literal hashes replay successfully.\n'
 'Real C5 P34/P54/P125/P156/T59/T13, six exact formula/code/closed/copy-panel structures, fullT7494B and exact P/T downloads pass static checks.\n'
 '20 newline/anchor/raw-download,15 matching,35 path/URL/symlink,2 canonical-export controls pass.\n'
 'New CRLF presentation regression: CR remains inside each numbered span while another LF is appended outside; static HTML CR preprocessing doubles ordinary CRLF line breaks versus production. CR-only terminal source also gains an extra break.\n'
 'Minimal repair: preserve LF anchor partition and raw downloads while avoiding duplicate CRLF/terminal-CR display breaks; retain original Unicode and new CRLF regressions.\n'
 'No new verifier failures, no unavailable JS/clipboard/browser/global acceptance, no earlier HOLD change, no shared adoption or renderer repair implemented.\n')
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
js('freeze-invocation.json',{'command':['python3',str(D/'finalize.py')],'started_at_utc':now,
 'scope':'Every descendant including exact renderer/proposal/patch bytes, frozen original counterexample inputs, independent scripts, full static outputs and all raw attempts. Exactly two envelope files excluded only to avoid recursive hashes.',
 'regular_file_mode':'0444','directory_mode':'0555','symlink_policy':'Retain actual link text plus resolved own-root targets; freeze targets0444 and parent directories0555.'})
envelope={'freeze-manifest.json','freeze-outer-receipt.json'}
allpaths=sorted(D.rglob('*'))
links=[p for p in allpaths if p.is_symlink()]
files=[p for p in allpaths if p.is_file() and not p.is_symlink() and p.relative_to(D).as_posix() not in envelope]
dirs=[D]+[p for p in allpaths if p.is_dir() and not p.is_symlink()]
for p in links:assert p.resolve().is_relative_to(D) and p.resolve().is_file()
manifest={'schema':'astis-full-ui-v5-review-freeze/v1','scope':'All descendants without payload truncation; two explicit envelope files excluded from recursive hash list.',
 'explicit_envelope_files':sorted(envelope),
 'regular_files':[{'path':p.relative_to(D).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes()),'mode':'0444'} for p in files],
 'directories':[{'path':'.' if p==D else p.relative_to(D).as_posix(),'mode':'0555'} for p in dirs],
 'symbolic_link_fixtures':[{'path':p.relative_to(D).as_posix(),'link_text':os.readlink(p),'link_text_sha256':sha(os.readlink(p).encode()),
   'resolved_target':p.resolve().relative_to(D).as_posix(),'resolved_target_sha256':sha(p.resolve().read_bytes()),'containment':'under own review root; target0444/parent0555'} for p in links]}
mf=js('freeze-manifest.json',manifest)
outerreceipt={'schema':'astis-ui-v5-freeze-outer-receipt/v1','created_at_utc':now,
 'manifest_sha256':sha(mf.read_bytes()),'findings_sha256':sha((D/'findings.json').read_bytes()),
 'payload_regular_files':len(files),'payload_bytes':sum(p.stat().st_size for p in files),'directories':len(dirs),'symbolic_link_fixtures':len(links),
 'regular_file_mode':'0444','directory_mode':'0555','decision':'Original Unicode fixed; CRLF presentation regression; no HOLD release','earlier_freezes':'untouched'}
outer=js('freeze-outer-receipt.json',outerreceipt)
for p in files+[mf,outer]:p.chmod(0o444)
for p in sorted(dirs,key=lambda p:len(p.parts),reverse=True):p.chmod(0o555)
for row in manifest['regular_files']:
 p=D/row['path'];assert sha(p.read_bytes())==row['sha256'] and stat.S_IMODE(p.stat().st_mode)==0o444
for p in dirs:assert stat.S_IMODE(p.stat().st_mode)==0o555
for p in links:assert stat.S_IMODE(p.resolve().stat().st_mode)==0o444 and stat.S_IMODE(p.parent.stat().st_mode)==0o555
assert sha(mf.read_bytes())==outerreceipt['manifest_sha256']
print(json.dumps({**outerreceipt,'outer_receipt_sha256':sha(outer.read_bytes()),'frozen':True},indent=2))
