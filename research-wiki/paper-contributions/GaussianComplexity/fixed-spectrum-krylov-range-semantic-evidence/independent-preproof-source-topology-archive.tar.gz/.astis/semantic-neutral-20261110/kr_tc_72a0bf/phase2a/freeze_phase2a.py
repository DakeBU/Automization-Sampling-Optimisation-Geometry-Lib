from pathlib import Path
import os,stat,json,hashlib,datetime
ROOT=Path('/Users/zhouhuanjian/ASTIS-GC/.astis/semantic-neutral-20261110/kr_tc_72a0bf')
PAYLOAD=ROOT/'phase2a';sha=lambda b:hashlib.sha256(b).hexdigest()
def phase1_check():
 p=ROOT/'phase1.manifest.json';assert sha(p.read_bytes())=='05c869d5248141c2cab0604796c0b18f5695d11c9fd272265ec6b65cd1f9475a'
 m=json.loads(p.read_bytes())
 assert all(sha((ROOT/'phase1'/x['path']).read_bytes())==x['sha256'] for x in m['files'])
 assert all(stat.S_IMODE((ROOT/'phase1'/x['path']).stat().st_mode)==0o444 for x in m['files'])
 assert stat.S_IMODE((ROOT/'phase1').stat().st_mode)==0o555
 return True
assert phase1_check()
files=sorted(p for p in PAYLOAD.rglob('*') if p.is_file())
assert files and all(not p.is_symlink() for p in PAYLOAD.rglob('*'))
m={'stage':'phase2a-typed-binder-definition-judgment-before-SG','files':[{'path':str(p.relative_to(PAYLOAD)),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in files]}
mp=ROOT/'phase2a.manifest.json';mp.write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n')
for p in files:os.chmod(p,0o444)
dirs=sorted([PAYLOAD]+[p for p in PAYLOAD.rglob('*') if p.is_dir()],key=lambda p:len(p.parts),reverse=True)
for p in dirs:os.chmod(p,0o555)
os.chmod(mp,0o444)
assert all(stat.S_IMODE(p.stat().st_mode)==0o444 for p in files)
assert all(stat.S_IMODE(p.stat().st_mode)==0o555 for p in dirs)
assert all(sha((PAYLOAD/x['path']).read_bytes())==x['sha256'] for x in m['files'])
assert phase1_check()
receipt={'stage':'phase2a','action':'actual file-by-file hash manifest; chmod payload files 0444 and directories 0555; recheck all hashes/modes and both pre/post Phase1 integrity','finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'payload':str(PAYLOAD),'payload_files':len(files),'payload_directories':len(dirs),'manifest':str(mp),'manifest_sha256':sha(mp.read_bytes()),'files_all_mode_0444':True,'directories_all_mode_0555':True,'manifest_file_mode_0444':True,'manifest_recheck_passed':True,'phase1_all_hashes_and_modes_unchanged':True,'phase1_manifest_sha256':'05c869d5248141c2cab0604796c0b18f5695d11c9fd272265ec6b65cd1f9475a','P_signature_sha256':'4d5056d57aa0536b95af7aa9f7c3b6860ab7c9652b0bb306b6bad42434235ab6','T_signature_sha256':'082eda7b36ecff3e87a62358e4f234b6d6c129b491405de3761fa83f79412969','SG_exposure':'none','receipt_is_actual_execution_not_planned':True}
rp=ROOT/'phase2a.freeze.receipt.json';rp.write_text(json.dumps(receipt,indent=2)+'\n');os.chmod(rp,0o444)
print(json.dumps(receipt,indent=2))
