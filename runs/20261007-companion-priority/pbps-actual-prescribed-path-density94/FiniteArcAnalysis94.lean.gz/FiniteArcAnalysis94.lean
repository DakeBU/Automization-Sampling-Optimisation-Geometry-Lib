import Mathlib.MeasureTheory.Integral.IntervalIntegral.Basic
import Mathlib.Topology.Order.OrderClosed

open MeasureTheory Set Filter
open scoped Topology

namespace PBPSFiniteArcAnalysis94

/-- Endpoint values may differ; open-arc agreement suffices for integration. -/
theorem arc_integral {f g : ℝ → ℝ} {a b : ℝ} (hab : a ≤ b)
    (hg : Continuous g) (heq : EqOn f g (Ioo a b)) :
    IntervalIntegrable f volume a b ∧
      (∫ s in a..b, f s) = ∫ s in a..b, g s := by
  refine ⟨(hg.intervalIntegrable a b).congr_uIoo ?_,
    intervalIntegral.integral_congr_Ioo_of_le hab heq⟩
  rw [uIoo_of_le hab]
  exact heq.symm

/-- Agreement with the incoming continuous arc identifies the left limit. -/
theorem incoming_left_limit {X : Type*} [TopologicalSpace X]
    {f g : ℝ → X} {a b : ℝ} (hab : a < b)
    (hg : Continuous g) (heq : EqOn f g (Ioo a b)) :
    Tendsto f (𝓝[<] b) (𝓝 (g b)) := by
  apply (hg.continuousAt.tendsto.mono_left nhdsWithin_le_nhds).congr'
  filter_upwards [Ioo_mem_nhdsLT hab] with s hs
  exact (heq hs).symm

/-- Finite adjacent arcs give integrability and the exact sum, even if some
    intervals have zero length. No agreement at the partition points is used. -/
theorem finite_arc_integral (n : ℕ) (a : Fin (n + 1) → ℝ)
    (f : ℝ → ℝ) (g : Fin n → ℝ → ℝ) (ha : Monotone a)
    (hg : ∀ j, Continuous (g j))
    (heq : ∀ j, EqOn f (g j) (Ioo (a j.castSucc) (a j.succ))) :
    IntervalIntegrable f volume (a 0) (a (Fin.last n)) ∧
      (∫ s in a 0..a (Fin.last n), f s) =
        ∑ j : Fin n, ∫ s in a j.castSucc..a j.succ, g j s := by
  induction n with
  | zero => simp
  | succ n ih =>
    have hpre := ih (fun j => a j.castSucc) (fun j => g j.castSucc)
      (fun i j hij => ha (by simpa using hij)) (fun j => hg j.castSucc)
      (fun j => by simpa using heq j.castSucc)
    have hlast := arc_integral (ha (Fin.castSucc_le_succ (Fin.last n)))
      (hg (Fin.last n)) (heq (Fin.last n))
    refine ⟨hpre.1.trans hlast.1, ?_⟩
    rw [Fin.sum_univ_castSucc]
    simp only [Fin.succ_castSucc]
    rw [← hpre.2, ← hlast.2]
    exact (intervalIntegral.integral_add_adjacent_intervals hpre.1 hlast.1).symm

#print axioms arc_integral
#print axioms incoming_left_limit
#print axioms finite_arc_integral

end PBPSFiniteArcAnalysis94
