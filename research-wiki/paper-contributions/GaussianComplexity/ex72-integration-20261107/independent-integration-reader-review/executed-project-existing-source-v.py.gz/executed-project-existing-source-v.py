"""Mechanically project one real, already appended source V into its own cell.

The source verifier has stopped writing. This script generates no source verdict,
never calls a lifecycle API, and never writes a ledger/audit/shared integration
path. Its only shared write is the explicitly authorized Ex72 cell metadata.
"""
from pathlib import Path
import copy
import datetime
import difflib
import gzip
import hashlib
import json
import subprocess
import sys
import time

sys.dont_write_bytecode = True
ROOT = Path('/Users/zhouhuanjian/ASTIS-GC')
STAGE = ROOT / '.astis/huanjian-gc-ex72-integration-20261107/independent-reader-preparation'
OUT = ROOT / 'research-wiki/paper-contributions/GaussianComplexity/ex72-integration-20261107/independent-integration-reader-review'
SOURCE = ROOT / 'research-wiki/paper-contributions/GaussianComplexity/tv-amplification-semantic-evidence/fresh-source-v2/phase3'
CELL = ROOT / 'research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-tv-amplification.json'
AUDIT = ROOT / 'research-wiki/semantic-roundtrip/audits/huanjian-tv-amplification.json'
ADV = 'ASTIS-SA-20261107-GaussianComplexityTVAmplification'
VERIFIER = '/root/ex72_fresh_source_v2'
OWNER = 'huanjian_gc_20261107_ex72'
MATH = 'ebf76119351b23ef0718fc69aa5081515bab0b52'
METADATA = 'e4a1b8d60822706df62a7d4bab23814d7187c622'
BINDING = 'fdfc58efe464c10868cac35682d8bd5202e0fc69f46880f957582e707b667265'
REPORT = OUT / 'existing-source-v-frontier-projection.json'
assert not REPORT.exists(), 'Do not overwrite frozen projection evidence'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def canonical(obj):
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()


def checked(path, expected):
    raw = path.read_bytes()
    assert sha(raw) == expected, str(path)
    return raw, json.loads(raw)


def descriptor(path):
    raw = path.read_bytes()
    return {'path': str(path.relative_to(ROOT)), 'sha256': sha(raw)}


def archive(path, raw):
    assert not path.exists()
    packed = gzip.compress(raw, compresslevel=9, mtime=0)
    path.write_bytes(packed)
    assert gzip.decompress(path.read_bytes()) == raw
    return {'path': str(path.relative_to(ROOT)), 'sha256': sha(packed), 'raw_sha256': sha(raw), 'raw_bytes': len(raw)}


receipt_raw, receipt = checked(SOURCE / 'actual-source-V-and-preservation-receipt.json', '61548d073a14e5d420640d6b97b5f5225ae602995093b5d60592180685459571')
closeout_raw, closeout = checked(SOURCE / 'closeout.json', 'cb18d531f8c504cde6e01b9b4118dc19f8015feb2b0f65b93e0df842f73928b2')
manifest_raw, manifest = checked(SOURCE / 'manifest.json', '29ac9b98a1736b6c2ba2d08becd30ab3048666a833b6e2d9ea24ca7d49a9a352')
run_raw, run = checked(SOURCE / 'independent-review-run.json', '32277ca886cc0ea865d92e68e95c64976b859a015f1af77fd677e70089355939')
assert closeout['stop_writes'] is True and closeout['reviewer'] == VERIFIER
assert receipt['independent_verifier'] == VERIFIER and receipt['source_V_state'] == 'VERIFIED'
assert receipt['exactly_one_normal_API_append'] and receipt['owner_retained'] == OWNER
assert receipt['head'] == closeout['head'] == METADATA
assert run['reviewer'] == VERIFIER and run['immutable_math_candidate'] == MATH
assert run['checked_metadata_head'] == METADATA and run['publication_binding_sha256'] == BINDING
assert run['fidelity_judgment'] == closeout['verdict'] == 'equivalent-after-elaboration'
assert run['blocking_mathematical_or_source_deltas'] == []
assert run['source_graph_mapping']['source_gap_count'] == 20
assert run['source_graph_mapping']['all_source_gap_ids_mapped']
assert run['independence']['distinct_from_both'] and run['independence']['prior_semantic_verdicts_read'] is False
for filename, item in manifest['files'].items():
    raw = (SOURCE / filename).read_bytes()
    assert len(raw) == item['bytes'] and sha(raw) == item['sha256'], filename
    if item.get('compression'):
        original = gzip.decompress(raw)
        assert len(original) == item['decompressed_bytes'] and sha(original) == item['decompressed_sha256'], filename
audit_raw, audit = checked(AUDIT, '67b1c0484faf78ca170cc65a407bac46d26b40a316daf3cb19edc1cefb6933ab')
assert audit['state'] == 'source-reviewed' and audit['source_review']['state'] == 'accepted'
assert audit['source_review']['reviewer'] == VERIFIER and audit['verdict'] == 'equivalent-after-elaboration'
assert audit['publication_binding_sha256'] == BINDING
candidate_audit = subprocess.check_output(['git', 'show', MATH + ':' + str(AUDIT.relative_to(ROOT))], cwd=ROOT)
assert json.loads(candidate_audit)['state'] == 'draft'

ledger_path = ROOT / 'runs/substantive_advances.jsonl'
discovery_path = ROOT / 'runs/substantive_discoveries.jsonl'
ledger = ledger_path.read_bytes()
discoveries = discovery_path.read_bytes()
assert sha(ledger) == receipt['ledger_after_sha256'] == '7dc1c9f7e12c582121afe9741f00e21863a24cf929d2ddb3c289ab35eb11dd29'
prefix = gzip.decompress((SOURCE / 'ledger-prefix.raw.jsonl.gz').read_bytes())
append = gzip.decompress((SOURCE / 'verified-append.raw.jsonl.gz').read_bytes())
assert sha(append) == '504cc436c70a4e893bf8fcbf1f307061dd365d53945a4f810f7b886e4409bb72'
assert ledger == prefix + append and len(append) == 2755 and len(append.splitlines()) == 1
event = json.loads(append)
assert event['advance_id'] == ADV and event['event'] == 'transition'
assert event['worker_id'] == VERIFIER and event['from_state'] == 'PROVED_LOCAL' and event['to_state'] == 'VERIFIED'
assert event['evidence']['verified_commit'] == METADATA
assert event['evidence']['gate']['math_candidate_commit'] == MATH
assert event['evidence']['source_audit']['sha256'] == sha(audit_raw)
sys.path.insert(0, str(ROOT / 'tools'))
import astis_advance as advance
import astis_publication as publication
states = advance._replay_advances(json.loads(row) for row in ledger.splitlines())
assert states[ADV]['state'] == 'VERIFIED' and states[ADV]['owner_id'] == OWNER
assert states[ADV]['last_actor'] == VERIFIER
assert not any(s['state'] == 'STABILIZING' for s in states.values())
foreign_states = {k: v for k, v in states.items() if k != ADV}
assert canonical(foreign_states) == canonical(json.loads(gzip.decompress((SOURCE / 'foreign-projected-states.json.gz').read_bytes())))
assert len(foreign_states) == 278
item = next(i for i in publication.load() if i['id'] == 'huanjian-tv-amplification')
assert publication.binding_digest(item, item['bindings'][0]) == BINDING
preparation = json.loads((OUT / 'preparation-report-v3.json').read_bytes())
for path, expected in preparation['source_test_publication_lesson_pins'].items():
    assert sha((ROOT / path).read_bytes()) == expected, path
    assert subprocess.check_output(['git', 'show', MATH + ':' + path], cwd=ROOT) == (ROOT / path).read_bytes(), path
for row in preparation['shared_paths']:
    p = ROOT / row['path']
    assert (sha(p.read_bytes()) if p.exists() else None) == row['before_sha256'], row['path']

frontier_map = json.loads(gzip.decompress((SOURCE / 'foreign-frontier-files.json.gz').read_bytes()))
assert len(frontier_map) == 437
for path, expected in frontier_map.items():
    assert sha((ROOT / path).read_bytes()) == expected, path
before = CELL.read_bytes()
assert sha(before) == '7cec15d2875429d8314aba9f56cc8cc6d2087e1ead7f80f5d4a8921d2b172a92'
original = json.loads(before)
assert original['status'] == 'proved_locally' and original['advance_id'] == ADV and original['owner_id'] == OWNER
after_object = copy.deepcopy(original)
after_object['status'] = 'independently_verified'
boundary = ('Existing fresh source/whole-module VERIFIED fact only, mechanically projected from the unique normal API event by '
            '/root/ex72_fresh_source_v2. Mathematical code/Test candidate ebf76119351b23ef0718fc69aa5081515bab0b52 is distinct from '
            'verified metadata commit e4a1b8d60822706df62a7d4bab23814d7187c622; the candidate audit was draft then, and the later canonical '
            'audit is source-reviewed/accepted. Static candidate reader content/disclosures are within that source V; the source verifier browser '
            'file-URL security rejection is retained and supplies no live acceptance. Root/Registry/aggregate Tests/canonical gate/site/graph/actual '
            'Chrome, remote publication, merge, purification/Exposition Seal and whole Goal remain pending. Both main lower bounds and all '
            'oracle/transcript/TV-precision/deterministic worst-case cap/expected-cost/hidden-eigenbasis adapters remain open.')
after_object['evidence']['execution_boundary'] = boundary
after_object['evidence']['independent_verification'] = (
    'Existing independent VERIFIED event by /root/ex72_fresh_source_v2, projected without a new source verdict or ledger append. '
    'Actual receipt: ' + str((SOURCE / 'actual-source-V-and-preservation-receipt.json').relative_to(ROOT)) +
    ' (SHA256 ' + sha(receipt_raw) + '); exact unique append SHA256 ' + sha(append) +
    '; independent review-run SHA256 ' + sha(run_raw) + '; current source-reviewed/accepted audit SHA256 ' + sha(audit_raw) + '. ' + boundary)
after_object['evidence']['source_phase_history'] = [{
    'status': original['status'], 'execution_boundary': original['evidence']['execution_boundary'],
    'source_detail_audit': original['source_detail_audit'], 'source_proof_coverage': original['source_proof_coverage'],
    'scope': 'Exact original preprojection/source-only pending wording retained as historical provenance. Source-only fields/files below are unchanged; the later actual-code mapping is separate evidence.'
}]
after_object['evidence']['independent_source_verification'] = {
    'projection_kind': 'mechanical existing-V fact only; no new mathematical/source verdict or lifecycle event',
    'source_verifier': VERIFIER, 'proof_owner_retained': OWNER,
    'immutable_mathematical_candidate': MATH, 'verified_metadata_commit': METADATA,
    'candidate_audit_state_then': 'draft', 'candidate_audit_raw_sha256_then': sha(candidate_audit),
    'current_canonical_audit': descriptor(AUDIT), 'current_source_phase': 'source-reviewed / accepted',
    'existing_verdict': audit['verdict'], 'publication_binding_sha256': BINDING,
    'actual_source_V_receipt': descriptor(SOURCE / 'actual-source-V-and-preservation-receipt.json'),
    'source_closeout': descriptor(SOURCE / 'closeout.json'), 'source_manifest': descriptor(SOURCE / 'manifest.json'),
    'normal_API_wrapper_receipt': descriptor(SOURCE / 'apply-source-verification.receipt.json'),
    'exact_normal_API_append': {'archive': descriptor(SOURCE / 'verified-append.raw.jsonl.gz'), 'raw_sha256': sha(append), 'raw_bytes': len(append)},
    'actual_ledger_after_sha256': sha(ledger),
    'review_run': descriptor(SOURCE / 'independent-review-run.json'), 'review_result': descriptor(SOURCE / 'review-result.json'),
    'source_first_expectation_sha256': run['phase1_expectation_sha256'],
    'source_versus_blind_freeze_sha256': run['phase2_comparison_sha256'],
    'reader_scope': run['static_reader']['environmental_limit'],
    'remaining_boundary': boundary,
}
after_object['evidence']['source_to_implementation_mapping'] = {
    'existing_review_run': descriptor(SOURCE / 'independent-review-run.json'),
    'json_pointer': '/source_graph_mapping',
    'source_only_graph': {'path': run['source_graph_mapping']['path'], 'sha256': run['source_graph_mapping']['sha256']},
    'source_gap_count': 20, 'later_mapping_scope': run['source_graph_mapping']['boundary'],
    'historical_source_only_fields_and_files_preserved': True,
    'no_mass_gap_status_upgrade': True,
    'citation_boundary': 'External general Poisson representation remains a source citation leaf. The existing reviewer records only the needed actual-moment alternate route, and does not claim the general theorem or separately exported min-overlap/min-sqrt statements.',
}
assert after_object['source_detail_audit'] == original['source_detail_audit']
assert after_object['source_proof_coverage'] == original['source_proof_coverage']
restored = copy.deepcopy(after_object)
restored['status'] = original['status']
restored['evidence'] = original['evidence']
assert restored == original
new_evidence_keys = {'execution_boundary', 'independent_verification', 'source_phase_history', 'independent_source_verification', 'source_to_implementation_mapping'}
assert {k: v for k, v in after_object['evidence'].items() if k not in new_evidence_keys} == {
    k: v for k, v in original['evidence'].items() if k not in new_evidence_keys}
assert isinstance(after_object['evidence']['independent_verification'], str) and after_object['evidence']['independent_verification'].strip()
after = (json.dumps(after_object, ensure_ascii=False, indent=2) + '\n').encode()

# Save exact originals/diff before the one authorized live metadata write.
before_archive = archive(OUT / 'source-v-frontier.before.raw.json.gz', before)
after_archive = archive(OUT / 'source-v-frontier.after.raw.json.gz', after)
raw_diff = b''.join(difflib.diff_bytes(difflib.unified_diff, before.splitlines(True), after.splitlines(True),
    fromfile=('before/' + str(CELL.relative_to(ROOT))).encode(), tofile=('after/' + str(CELL.relative_to(ROOT))).encode()))
diff_archive = archive(OUT / 'source-v-frontier.mechanical.diff.gz', raw_diff)
assert CELL.read_bytes() == before and ledger_path.read_bytes() == ledger and AUDIT.read_bytes() == audit_raw
CELL.write_bytes(after)
isolated = STAGE / 'exact-source-v-frontier-check'
isolated.mkdir(exist_ok=False)
copy_path = isolated / CELL.name
copy_path.write_bytes(CELL.read_bytes())
assert copy_path.read_bytes() == after == CELL.read_bytes()
check_command = ['/opt/anaconda3/bin/python', '-B', 'tools/astis_frontier_cells.py', 'check', '--root', str(isolated.relative_to(ROOT))]
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
tick = time.monotonic()
check = subprocess.run(check_command, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
elapsed = time.monotonic() - tick
check_log = archive(OUT / 'targeted-source-v-frontier-check.log.gz', check.stdout)
check_receipt = {'command': check_command, 'started_utc': started, 'exit_code': check.returncode, 'elapsed_seconds': elapsed,
                 'live_cell': str(CELL.relative_to(ROOT)), 'isolated_exact_copy': str(copy_path.relative_to(ROOT)),
                 'live_and_copy_sha256': sha(after), 'byte_equality_checked_before_and_after': True,
                 'scope': 'Normal Frontier Cell validator on exactly one actual-cell byte copy; no global/root/source-review/build/browser check', 'log': check_log}
check_receipt_path = OUT / 'targeted-source-v-frontier-check.receipt.json'
assert not check_receipt_path.exists()
check_receipt_path.write_bytes((json.dumps(check_receipt, ensure_ascii=False, indent=2) + '\n').encode())
assert check.returncode == 0, check.stdout.decode()
assert b'ASTIS Frontier Cell protocol check passed: 1 registered cells' in check.stdout
assert copy_path.read_bytes() == CELL.read_bytes() == after

assert ledger_path.read_bytes() == ledger and discovery_path.read_bytes() == discoveries and AUDIT.read_bytes() == audit_raw
assert advance._replay_advances(json.loads(row) for row in ledger_path.read_bytes().splitlines()) == states
for path, expected in frontier_map.items():
    assert sha((ROOT / path).read_bytes()) == expected, path
for filename, item in manifest['files'].items():
    assert sha((SOURCE / filename).read_bytes()) == item['sha256'], filename
assert (SOURCE / 'manifest.json').read_bytes() == manifest_raw and (SOURCE / 'closeout.json').read_bytes() == closeout_raw
for row in preparation['shared_paths']:
    p = ROOT / row['path']
    assert (sha(p.read_bytes()) if p.exists() else None) == row['before_sha256'], row['path']
protection = {
    'actor': '/root/ex72_integration_reader_review', 'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'operation': 'Mechanical one-cell metadata projection of existing independent normal source V',
    'source_verdict_originated': False, 'new_ledger_events': 0,
    'source_V_receipt': descriptor(SOURCE / 'actual-source-V-and-preservation-receipt.json'),
    'source_closeout': descriptor(SOURCE / 'closeout.json'), 'canonical_audit': descriptor(AUDIT),
    'cell': str(CELL.relative_to(ROOT)), 'before_sha256': sha(before), 'after_sha256': sha(after),
    'before': before_archive, 'after': after_archive, 'lossless_raw_diff': diff_archive,
    'status_before': original['status'], 'status_after': after_object['status'],
    'only_authorized_top_level_fields_changed': ['status', 'evidence'],
    'nonempty_string_independent_verification': True, 'typed_source_verification_and_mapping_evidence': True,
    'all_original_source_only_fields_statuses_and_citation_boundaries_preserved': True,
    'all_original_other_cell_contracts_preserved': restored == original,
    'ledger_exactly_unchanged_sha256': sha(ledger), 'discovery_ledger_exactly_unchanged_sha256': sha(discoveries),
    'all_279_projected_states_unchanged': True, 'all_278_foreign_states_preserved': True,
    'all_437_foreign_frontier_files_byte_preserved': True,
    'source_review_phase3_manifest_files_byte_preserved': True,
    'seven_shared_paths_remain_before_bytes': True,
    'actual_targeted_check_receipt': descriptor(check_receipt_path),
    'single_stabilization_lane': [], 'proof_owner_retained': OWNER,
    'candidate_audit_was_draft_then': True,
    'remaining_boundary': boundary,
    'writes_stopped_after_report': True,
}
REPORT.write_bytes((json.dumps(protection, ensure_ascii=False, indent=2) + '\n').encode())
archive(OUT / 'executed-project-existing-source-v.py.gz', Path(__file__).read_bytes())
print(json.dumps({'status': 'passed', 'cell_before_sha256': sha(before), 'cell_after_sha256': sha(after),
                  'report_sha256': sha(REPORT.read_bytes()), 'targeted_check_receipt_sha256': sha(check_receipt_path.read_bytes()),
                  'new_source_verdicts': 0, 'new_ledger_events': 0, 'foreign_frontiers_preserved': 437,
                  'independent_verification_type': 'nonempty string', 'writes_stopped': True}, indent=2))
