#!/opt/anaconda3/bin/python
import hashlib,json,pathlib
BASE=pathlib.Path(__file__).resolve().parent
packet=json.loads((BASE/'inputs/fresh-source-reviewer-packet.json').read_text())
print('PACKET_KEYS',[(k,type(v).__name__,len(v) if hasattr(v,'__len__') else None) for k,v in packet.items()])
for k,v in packet.items():
    if k not in ['candidate_publication_context','source','lean','blind_reconstruction']:
        print(k,json.dumps(v,ensure_ascii=False,indent=2))
context=packet['candidate_publication_context']
print('CONTEXT_KEYS',[(k,type(v).__name__,len(v) if hasattr(v,'__len__') else None) for k,v in context.items()])
for k,v in context.items():
    if k not in ['current_lean_module','source','statement','assumptions','formulae']:
        print('CONTEXT',k,json.dumps(v,ensure_ascii=False,indent=2))
matches=[]
for ascii_flag in [False,True]:
  for indent in [None,2,4]:
    for compact in [False,True]:
      for trailing in ['', '\n']:
        kwargs={'sort_keys':True,'ensure_ascii':ascii_flag,'indent':indent}
        if compact:kwargs['separators']=(',',':')
        payload=(json.dumps(packet,**kwargs)+trailing).encode()
        digest=hashlib.sha256(payload).hexdigest()
        if digest=='68eb57daeb019b886f64e96ea800777ac04f83af39d582ae8ff9a01c3d497921':
          matches.append({'ensure_ascii':ascii_flag,'indent':indent,'compact':compact,'trailing_LF':bool(trailing),'sha256':digest})
print('SUPPLIED_CANONICAL_HASH_SCHEME_MATCHES',json.dumps(matches))
mapping=json.loads((BASE/'inputs/research-wiki__paper-contributions__GaussianComplexity__fixed-spectrum-cosine-gram-semantic-evidence__source-to-lean-map-v1.json').read_text())
print('MAP_KEYS',[(k,type(v).__name__,len(v) if hasattr(v,'__len__') else None) for k,v in mapping.items()])
(BASE/'canonical_packet_hash_scheme.json').write_text(json.dumps(matches,indent=2)+'\n')
