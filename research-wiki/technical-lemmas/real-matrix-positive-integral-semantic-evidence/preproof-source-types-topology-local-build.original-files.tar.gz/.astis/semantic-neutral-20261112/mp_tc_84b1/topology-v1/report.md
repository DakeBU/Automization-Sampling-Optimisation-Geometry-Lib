# Independent shared-background source, attribution and topology challenge

**Accept the bounded source/attribution coverage and unproved obligation
topology. No genuine source, attribution, coverage or application-interface
blocker was found. All 13 internal mathematical/applicability ports remain
open.** This review neither proves the shared theorem nor verifies a Mathlib
application, a compiled parent/call, the complete R9 theorem, normal V,
integration or permission.

## Source-first chronology and exact binding

Before any new SG inventory/graph exposure, this actor independently read all
344 lines of the actual fixed external Mathlib
Analysis/Convex/Integral.lean. Its source-first reading froze at
`a5399934b1de78e888033bbb8ba482d54362dd85cd4c64e31e294727c7092ffe`;
its exact source bytes are 21375 bytes, SHA-256
`1b3115887fabf0dccc2fed689d1f1ddc7a114b5de4594e752c02908a445aafb4`.
The earlier independent shared type freeze is unchanged at
`87c37fa423e8b8d8725a5d7253b97d313be94bb2c25652461d3363aca27d3335`.
The prior R9 raw reading supplies paper-application evidence; neither that raw
reading nor the new external source is described as a printed generic PSD
matrix lemma in the paper.

The reviewed shared seal is
`a5179ed392ef8e55ab470a3a98ebd542e35301f51472e9cdd7bc168a88bafa26`,
packet `d2d9493c6fd09222fbe183fcb296bd0c104328a462a03f28b7c9930caa9b9e95`,
producer `283e07e3c85b9a5cce5c3c40f574f23f593dfcca5e35be4d3e2800f378208b19`,
context `f43d358af135d42c8585f927f7e20b2b3363af2bf28eed98298f2996a2f8e591`
and unchanged actual R9 consumer
`d5ac54443c79ea7b35b09ddcd6b5e3c40bef081bbe4f196cae5ab3ead35aa2ea`.
All public SG records bind these same exact objects and source hashes.

Ten public top-level source artifacts and the 68 source-fragment copies were
read/hash-checked. Six inputs/ snapshot filenames and their manifest hash
metadata were incidentally seen. Their type-audit, builder, type-manifest,
literal-print and source-copy contents were not opened; no separate snapshot
hash certification is claimed. The actual fixed upstream file, original paper
bytes and own exact packet's literal prints are the independent authorities
used for the checks. No new ASTIS implementation, root old/new proof, library
search outside the authorized fixed source or SG private rationale was read.

## The three source layers remain distinct

The paper p14 supplies a concrete integration-of-PSD need, including the actual
closed-cutoff Y_i square, removing its indicator, Ex115's expected-majorant
comparison and expected centered/weighted-square positivity needs. It does not
state a theorem about arbitrary finite n, measurable Omega, probability mu
and integrable AE-PSD f.

The external Mathlib theorem Convex.integral_mem, at lines 57-58 with inherited
context 46-47, supplies closed-convex-set membership of an actual integrable
AE-valued probability expectation in a complete real normed space. Its printed
proof is in the selected source; it is an upstream theorem/proof, not an
ASTIS-owned completed matrix specialization.

The arbitrary-f real-matrix PSD theorem is the explicit ASTIS-authored
specialization. Its hf and hpos are genuine authored theorem inputs. The PSD
cone's full meaning/geometry, actual matrix structures and exact theorem
application must be discharged internally. These inputs are not attributed to
the Gaussian paper and are not added to its unchanged R9 Source Anchor.
No source repair or new paper theorem is asserted.

## Every inventory item, locator and selected proof region

All 68 inventory items were inspected: 31 NODE and 37 EXCLUDED. Their origin
labels distinguish PAPER, MATHLIB and LITERAL_PRINT. All 239 locator occurrences
were checked against those exact independent source bytes for SHA-256,
UTF-8/codepoint mapping and inclusive LF ranges. All 58 distinct origin/span
pairs match. All 68 persisted source fragments equal the unnormalized original
bytes selected by their locators.

All substantive p14 paragraph/display regions are represented or excluded,
including the four clauses in p14.2, the Ex115-117 rows, the two clauses in
Ex118 and the two in Ex120. The concrete Gaussian fourth moment, tensor/frame
algebra, centered equality, variance scale and final norm results are explicitly
outside this shared bridge, with their existing R9 obligations remaining open.
Those exclusions do not turn them into assumptions or prove them by naming the
consumer.

For the upstream source, inherited context 46-47 and all selected lines 54-83
are covered without a missing line. Independent enumeration finds 22 theorem
declarations in the file; all 21 outside Convex.integral_mem are explicitly
excluded. The exposed whole-file header/import/overview, other average/Jensen/
strict/interior results and their additional hypotheses gain no target proof
credit. Only the six listed literal definition blocks are the definition
window; no complete containing definition-source file coverage is claimed.

The upstream proof's Borel setup, AE representative, separable range,
nonempty intersection witness, AE integral/integrability rewrite, closure
membership, simple approximants, convergence, probability weights and final
closed-convex limit composition are all retained. Their mathematical order
and consumer-use locators match the actual source. The proof's internal
nonempty anchor and local Borel/separability setup are not new public
assumptions on sample space, matrix index or PSD cone.

## Topology, roots and alternatives

All 50 nodes and 68 directed edges were inspected. The single explicit OR is
the closed-convex integral application OR the direct Hermitian-and-quadratic
integral route. Within the direct route, Hermitian and every quadratic-form
positivity are correctly an AND. The graph does not require cone closedness/
convexity in that alternative merely because those facts belong to the cone
route, and it does not require proving both routes. No dangling edge or cycle
was found after the explicit alternative links are included for coverage.

The shared-producer reverse closure contains 34 nodes. The intended R9
PSD-residual application has 40, the second centered/weighted-square family
38, and the printed upstream conclusion has 17. Their union accounts for 44
nodes. The paper integrated-comparison endpoint is separately mapped as
source/application correspondence, not a proof premise, taking the coverage
union to 45. The remaining five nodes are inherited upstream typing,
documentation, Borel setup, and the conjugate-transpose/finite-integral
definition expansions. These global source/definition contexts are explicitly
accounted for, so all 50 nodes are covered without an unexplained mathematical
region.

The application node carrying the unchanged R9 signature is an intended
interface reference, not a claim that this graph closes every dependency of
the full R9 theorem. Ex113's concrete moment, Ex116-117's frame algebra and
all final norm/centering arguments remain in their original R9 boundary.
The source assertion ML.contract.conclusion is an external theorem
specification to match with all conditions, not a new formal hypothesis
legalizing the desired shared conclusion.

## Internal applicability challenges retained

The cone route must identify the actual set of real finite matrices satisfying
full Hermitian and quadratic positivity, prove its convexity and closedness
in the actual L2Operator topology, and match the complete real matrix space to
upstream E. It cannot substitute entrywise positivity, an unrelated function
norm topology, or a caller-supplied geometry certificate.

The upstream signature needs probability, AE membership and actual
integrability. It does not need a new pointwise Measurable f, Borel Omega,
SeparableSpace E, supplied representative, Nonempty n or Nonempty cone
binder. Its proof obtains an anchor from AE membership under a nonzero
probability law. Empty matrix indices remain allowed: norm/completeness and
full predicate membership must be handled with that scope, and any chosen
API's extra nonempty condition must be discharged or bypassed internally.

The direct route must justify AE Hermitian integral transport and each
fixed-vector real linear evaluation of the matrix quadratic form, including
continuity, integrability and commuting with the actual Bochner integral.
The matrix evaluation is linear in the matrix for a fixed vector; no
nonlinear-in-f exchange is implied. Both PSD conjuncts are required. AE is
not silently upgraded to all-outcome positivity. The actual finite matrix
space is complete and uses the declared L2Operator norm; a nonintegrable
zero-default integral is not a proof route because authored hf is required.

For the concrete Ex115 use, the residual must be the actual untruncated
majorant A_i minus actual Y_i^2, with

    A_i=(R_i ||t_i||^2 / d^2)(gamma_i gamma_i^T tensor t_i t_i^T).

Its literal function, original same mu, closed-cutoff identity, integrability
and full pointwise/AE PSD all remain internal. It must not be replaced by a
supplied PSD expected matrix or by assuming pointwise positivity of the final
C I - sum_i Y_i^2, which is not the source argument. To identify its integral
as E[A_i]-E[Y_i^2], the actual individual integrability requirements for
subtraction must also be proved, not inferred merely from residual
integrability. Tensor transport, fourth-moment evaluation, finite summation
and the remaining source frame bound are separate work. The shared result
does not directly produce the final R9 C I bound.

For the centered/weighted families, actual squared-map integrability and
Hermitian/PSD facts must precede the generic application. Positivity of their
integrals supports needed lower PSD facts, but does not itself prove Ex118's
noncommutative centered identity, mean-square subtraction comparison, cosine
upper scaling or the final operator-norm bounds. The graph's planned-use
labels preserve that limitation; no private test or historical name becomes
a public provider or a compiled application.

## Verdict boundary

Genuine attribution/source/coverage/application-interface blockers: **none
found**. All 13 INTERNAL ports remain unproved; the direct subroute's two
conjuncts and the cone route's hypotheses are not counted as completed merely
because the source theorem has a printed proof. Current Mathlib applicability,
the new ASTIS proof, concrete R9 residual construction, actual producer calls
and all normal verification remain unreviewed.

Old type/R7/R8/R9 artifacts and the source-first reading freeze remain
unchanged. Public SG source inputs/fragments remain unchanged; unopened SG
snapshots were not written. No shared metadata, ledger/C/registry/Git change,
source VERIFIED, proof, normal V, integration or permission is granted.
