from runner import *
from collections import defaultdict
reader=OUT/'reader';reader.mkdir(exist_ok=True)
candidate='4b58558a6003444af9964fba077e74bf5e63052d'
paths=['website/content/declaration_lessons/huanjian-gaussian-source-matrix-radius.json','website/content/publications/huanjian-gaussian-source-matrix-radius.json','research-wiki/paper-contributions/GaussianComplexity/source-matrix-radius-semantic-evidence/source-lean-map.authored-v1.json']
snapshot=reader/'candidate';snapshot.mkdir(exist_ok=True)
for path in paths:
    p,_=run('reader-blob-'+path.replace('/','__'),['git','show',candidate+':'+path])
    dst=snapshot/path;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(p.with_suffix('.stdout').read_bytes())
    assert dst.read_bytes()==(ROOT/path).read_bytes()
u=json.loads((snapshot/paths[0]).read_text())['units'][0]
pub=json.loads((snapshot/paths[1]).read_text())['items'][0]
mapping=json.loads((snapshot/paths[2]).read_text())
assert u['reading_layout']=='progressive' and len(u['steps'])==6
P='AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumSourceMatrixRadius.lean'
T='Tests/GaussianComplexityFixedSpectrumSourceMatrixRadius.lean'
raws={}
for path in [P,T]:
    p,_=run('reader-math-blob-'+path.replace('/','__'),['git','show',candidate+':'+path])
    raw=p.with_suffix('.stdout').read_bytes();raws[path]=raw
    assert raw==(OUT/'snapshot'/path).read_bytes()
combined=[''.join(x['lean'] for x in u['steps'][:4]),''.join(x['lean'] for x in u['steps'][4:])]
assert combined==[raws[P].decode(),raws[T].decode()]
covered=defaultdict(set);source_span_count=0;lean_span_count=0
for m in mapping['mappings']:
    for a in m['source']:
        b=(ROOT/a['file']).read_bytes();assert hashlib.sha256(b).hexdigest()==a['file_sha256']
        sub=b[a['raw_utf8_start']:a['raw_utf8_end']]
        assert hashlib.sha256(sub).hexdigest()==a['span_sha256']
        assert sub.decode()==b.decode()[a['char_start']:a['char_end']]
        source_span_count+=1
    for a in m['lean']:
        b=raws[a['path']];assert hashlib.sha256(b).hexdigest()==a['file_sha256']
        lo,hi=a['raw_UTF8_byte_span'];sub=b[lo:hi]
        assert hashlib.sha256(sub).hexdigest()==a['span_sha256']
        cs,ce=a['decoded_char_span'];assert sub.decode()==b.decode()[cs:ce]
        ls,le=a['LF_lines_1based'];assert sub.decode()==''.join(b.decode().splitlines(keepends=True)[ls-1:le])
        covered[a['path']].update(range(ls,le+1));lean_span_count+=1
assert covered[P]==set(range(1,227)) and covered[T]==set(range(1,96))
text=json.dumps(u,ensure_ascii=False)
assert 'private' in text.lower() and 'q=0' in text and 'Bochner' in text and '2r(L+1)' in text
assert all(u['steps'][i]['formula'] and u['steps'][i]['text'] for i in range(6))
result={'candidate':candidate,'math_sources_unchanged_from_native_candidate':True,'authored_folds':6,'fold_line_counts':[len(x['lean'].splitlines()) for x in u['steps']],
 'producer_lines_complete':226,'private_consumer_lines_complete':95,'source_map_source_spans_verified':source_span_count,'source_map_lean_spans_verified':lean_span_count,
 'source_map_line_coverage':{p:len(v) for p,v in covered.items()},'literal_file_byte_equality_in_six_folds':True,
 'native_comparison':'Authored formula proof matches the checked native mathematical route and internally discharges hq-dependent signs, a∈[0,1], integrability via actualMean, rankone matrix norms and final actual centered/cosine-weighted triangle estimate.',
 'scope_boundary':'Public producer P only; centered/cosine-weighted T private. No concentration/fullLemma4.4/mainlowerbound/oracle/precision/TV/cap/cost or normalV credit.',
 'input_hashes':{path:sha(snapshot/path) for path in paths}}
(reader/'static-result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
