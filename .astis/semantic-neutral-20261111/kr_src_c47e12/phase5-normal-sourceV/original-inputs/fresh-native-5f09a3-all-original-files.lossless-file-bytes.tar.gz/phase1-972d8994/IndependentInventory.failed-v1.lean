import Tests.GaussianComplexityFixedSpectrumKrylovRange
import Lean
open Lean Meta Elab Command Matrix Polynomial
open scoped BigOperators
set_option autoImplicit false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

def independentExpectedP {d q : ℕ} (κ : ℝ) (hκ : 2 ≤ κ) (hq : 2 * q + 1 < d)
    (x : EuclideanSpace ℝ (Fin d × Fin (q + 1))) : Prop :=
  let θ : Fin d → ℝ := fun i => ((i.val : ℝ) + 1 / 2) * Real.pi / (d : ℝ)
  let eigenvalue : Fin d → ℝ := fun i => (κ + 1) / 2 + (κ - 1) / 2 * Real.cos (θ i)
  let Λ : Matrix (Fin d) (Fin d) ℝ := Matrix.diagonal eigenvalue
  let g : Fin (q + 1) → Fin d → ℝ := fun a i => WithLp.ofLp x (i, a)
  let t : Matrix (Fin d) (Fin (q + 1)) ℝ := fun i k =>
    if k.val = 0 then 1 else Real.sqrt 2 * Real.cos ((k.val : ℝ) * θ i)
  let B : Matrix (Fin d) (Fin (q + 1) × Fin (q + 1)) ℝ := fun i a =>
    (Real.sqrt (d : ℝ))⁻¹ * g a.1 i * t i a.2
  let K : Submodule ℝ (Fin d → ℝ) :=
    Submodule.span ℝ (Set.range (fun a : Fin (q + 1) × Fin (q + 1) =>
      (Λ ^ a.2.val).mulVec (g a.1)))
  Set.range (fun c : Fin (q + 1) × Fin (q + 1) → ℝ => B.mulVec c) =
    (K : Set (Fin d → ℝ))


def independentExpectedT {d q : ℕ} (κ : ℝ) (hκ : 2 ≤ κ) (hq : 2 * q + 1 < d)
    (x : EuclideanSpace ℝ (Fin d × Fin (q + 1))) : Prop :=
  let θ : Fin d → ℝ := fun i => ((i.val : ℝ) + 1 / 2) * Real.pi / (d : ℝ)
  let eigenvalue : Fin d → ℝ := fun i => (κ + 1) / 2 + (κ - 1) / 2 * Real.cos (θ i)
  let Λ : Matrix (Fin d) (Fin d) ℝ := Matrix.diagonal eigenvalue
  let g : Fin (q + 1) → Fin d → ℝ := fun a i => WithLp.ofLp x (i, a)
  let t : Matrix (Fin d) (Fin (q + 1)) ℝ := fun i k =>
    if k.val = 0 then 1 else Real.sqrt 2 * Real.cos ((k.val : ℝ) * θ i)
  let B : Matrix (Fin d) (Fin (q + 1) × Fin (q + 1)) ℝ := fun i a =>
    (Real.sqrt (d : ℝ))⁻¹ * g a.1 i * t i a.2
  let K : Submodule ℝ (Fin d → ℝ) :=
    Submodule.span ℝ (Set.range (fun a : Fin (q + 1) × Fin (q + 1) =>
      (Λ ^ a.2.val).mulVec (g a.1)))
  let D : Matrix (Fin d) (Fin d) ℝ :=
    Matrix.diagonal (fun i => Real.cos (((2 * q + 1 : ℕ) : ℝ) * θ i))
  ∀ v : Fin d → ℝ, v ∈ K →
    ∃ c : Fin (q + 1) × Fin (q + 1) → ℝ,
      B.mulVec c = v ∧
      ‖(WithLp.toLp 2 v : EuclideanSpace ℝ (Fin d))‖ ^ 2 =
        (∑ a : Fin (q + 1) × Fin (q + 1), c a * ((B.transpose * B).mulVec c) a) ∧
      (inner ℝ (WithLp.toLp 2 v : EuclideanSpace ℝ (Fin d))
        (WithLp.toLp 2 (D.mulVec v) : EuclideanSpace ℝ (Fin d))) =
        (∑ a : Fin (q + 1) × Fin (q + 1), c a * ((B.transpose * D * B).mulVec c) a)


def actualModule (env : Environment) (n : Name) : String :=
  match env.getModuleIdxFor? n with
  | some i => (env.header.moduleNames[i]!).toString
  | none => "CURRENT"
def constKind (c : ConstantInfo) : String :=
  match c with
  | .axiomInfo _ => "axiom"
  | .thmInfo _ => "theorem"
  | .defnInfo _ => "definition"
  | .opaqueInfo _ => "opaque"
  | .quotInfo _ => "quotient"
  | .inductInfo _ => "inductive"
  | .ctorInfo _ => "constructor"
  | .recInfo _ => "recursor"
def jnames (a : Array Name) : Json := toJson (a.map Name.toString)
def closed (e : Expr) : Bool :=
  !e.hasFVar && !e.hasMVar && !e.hasLevelMVar && !e.hasLooseBVars
run_meta do
  let env := (← getEnv).setExporting false
  let mods := #["AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumKrylovRange", "Tests.GaussianComplexityFixedSpectrumKrylovRange"]
  let mut owned : Array Name := #[]
  for (n, _) in env.constants.toList do
    if mods.contains (actualModule env n) then owned := owned.push n
  owned := owned.qsort Name.lt
  let mut rows : Array Json := #[]
  for n in owned do
    let ci := env.find? n |>.get!
    let v := ci.value? (allowOpaque := true)
    let axs ← collectAxioms n
    let directType := ci.type.getUsedConstants
    let directValue := v.map Expr.getUsedConstants |>.getD #[]
    let parentRows := directValue.map fun p => Json.mkObj [("name",toJson p.toString),("module",toJson (actualModule env p))]
    rows := rows.push <| Json.mkObj [
      ("name",toJson n.toString),("module",toJson (actualModule env n)),("kind",toJson (constKind ci)),
      ("levels",toJson (ci.levelParams.map Name.toString)),("type_raw",toJson (repr ci.type).pretty),
      ("type_pp",toJson (← ppExpr ci.type).pretty), ("closed_type",toJson (closed ci.type)),
      ("is_prop",toJson (← isProp ci.type)),("has_value",toJson v.isSome),
      ("closed_value",toJson (v.map closed)),("direct_type_constants",jnames directType),
      ("direct_value_constants",jnames directValue),("direct_value_parents",toJson parentRows),
      ("axioms",jnames axs), ("std3_only",toJson (axs.all fun a => #[``propext,``Classical.choice,``Quot.sound].contains a))]
  let p := `AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumKrylovRange.actual_cosine_feature_krylov_range
  let t := owned.find? fun n => n.toString.endsWith ".actual_krylov_quadratic_coordinates"
  let mut comparisons : Array Json := #[]
  for (actual, expected) in #[(p,`independentExpectedP),(t.get!,`independentExpectedT)] do
    let ec := (← getConstInfo expected).value! (allowOpaque := true)
    let exp ← lambdaTelescope ec fun xs body => mkForallFVars xs body
    let act := (← getConstInfo actual).type
    let literal := act == exp
    comparisons := comparisons.push <| Json.mkObj [("actual",toJson actual.toString),("expected",toJson expected.toString),("literal_expr_equal",toJson literal),("expected_closed",toJson (closed exp)),("expected_is_prop",toJson (← isProp exp)),("defeq",toJson (← isDefEq act exp)),("expected_type_raw",toJson (repr exp).pretty)]
  let output := Json.mkObj [("owned",toJson rows),("exact_seal_type_comparisons",toJson comparisons),("owned_count",toJson owned.size)]
  liftIO <| IO.FS.writeFile "/Users/zhouhuanjian/ASTIS-GC/.astis/huanjian-gc-fixed-spectrum-krylov-range-20261110/independent-native-reader-5f09a3/phase1-972d8994/native-inventory.json" output.pretty
