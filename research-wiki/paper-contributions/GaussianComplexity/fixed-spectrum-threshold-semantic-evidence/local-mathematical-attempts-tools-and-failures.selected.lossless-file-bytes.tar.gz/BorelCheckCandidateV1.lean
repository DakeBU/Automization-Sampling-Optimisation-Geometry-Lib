import AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumThreshold
noncomputable section
open MeasureTheory
open scoped BigOperators
example (d n : ℕ) (θ : Fin d → ℝ) (τ : ℝ) :
    Measurable (fun x : EuclideanSpace ℝ (Fin d) =>
      (-1 : ℝ) ^ n * (∑ i : Fin d, Real.cos ((n : ℝ) * θ i) *
        (WithLp.ofLp x i) ^ 2) - 2 * τ * ‖x‖ ^ 2) := by
  have hcoord (i : Fin d) : Measurable (fun x : EuclideanSpace ℝ (Fin d) =>
      WithLp.ofLp x i) := (EuclideanSpace.proj i).continuous.measurable
  exact ((Finset.measurable_sum _ (fun i _ => (hcoord i).pow_const 2 |>.const_mul _)).const_mul _).sub
    ((measurable_norm.pow_const 2).const_mul (2 * τ))
