import Mathlib

noncomputable section
open MeasureTheory ProbabilityTheory
open scoped BigOperators Matrix.Norms.L2Operator
set_option pp.universes true

-- Only standard definition semantics and actual instances, before target proof search.
#print MeasureTheory.Integrable
#print MeasureTheory.HasFiniteIntegral
#print MeasureTheory.AEStronglyMeasurable
#print MeasureTheory.integral
#print Set.indicator
#print Matrix
#print Matrix.vecMulVec
#print Matrix.kronecker
#print Matrix.kroneckerMap
#print EuclideanSpace
#print WithLp.toLp
#print ProbabilityTheory.stdGaussian
#print MeasureTheory.Measure.pi

section
variable {d q : ℕ}
#synth NormedAddCommGroup
  (Matrix (Fin (q + 1) × Fin (q + 1)) (Fin (q + 1) × Fin (q + 1)) ℝ)
#synth NormedSpace ℝ
  (Matrix (Fin (q + 1) × Fin (q + 1)) (Fin (q + 1) × Fin (q + 1)) ℝ)
#synth CompleteSpace
  (Matrix (Fin (q + 1) × Fin (q + 1)) (Fin (q + 1) × Fin (q + 1)) ℝ)
#synth IsProbabilityMeasure
  (Measure.pi (fun _ : Fin (q + 1) => stdGaussian (EuclideanSpace ℝ (Fin d))))
#synth SigmaFinite (stdGaussian (EuclideanSpace ℝ (Fin d)))
end
