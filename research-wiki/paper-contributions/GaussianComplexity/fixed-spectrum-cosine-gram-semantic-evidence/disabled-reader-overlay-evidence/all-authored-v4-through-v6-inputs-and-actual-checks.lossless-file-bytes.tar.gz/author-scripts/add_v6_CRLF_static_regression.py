from pathlib import Path
W = Path(__file__).parent
p = W/'check_disabled_v6_static_cg.py'
text = p.read_text()
needle = 'assert production.read_bytes() == before and lesson.read_bytes() == lesson_raw'
assert text.count(needle) == 1
extra = '''# CRLF and terminal CR must not add a redundant HTML display break.
cr_cases = {'CRLF.lean': b'-- prefix\\r\\ntheorem sample : True := by\\r\\n  trivial\\r\\n',
            'TerminalCR.lean': b'-- prefix\\r'}
for filename, raw_cr in cr_cases.items():
    (fixture_root/filename).write_bytes(raw_cr)
    dl.ROOT = fixture_root.resolve()
    cr_out = D/('output-'+filename)
    (cr_out/'textbook').mkdir(parents=True)
    (cr_out/'textbook/index.html').write_bytes(fixture)
    dl.export_sources(cr_out, [{'sources': [{'path': filename}]}])
    raw_export = cr_out/'data/lesson-sources'/filename
    assert raw_export.read_bytes() == raw_cr
    cr_html = raw_export.with_suffix('.lean.html').read_bytes().decode()
    cr_soup = BeautifulSoup(cr_html, 'html.parser')
    spans = cr_soup.find('pre').find_all('span', recursive=False)
    assert all(not span.get_text().endswith('\\r') for span in spans)
    assert len(spans) == (3 if filename == 'CRLF.lean' else 1)
dl.ROOT = R
'''
text = text.replace(needle, extra+'\n'+needle)
text = text.replace("'reader_HOLD_still_pending': True", "'CRLF_and_terminal_CR_presentation_regressions_pass': True, 'reader_HOLD_still_pending': True")
p.write_text(text)
print('Added CRLF and terminal-CR regressions before the first v6 static run')
