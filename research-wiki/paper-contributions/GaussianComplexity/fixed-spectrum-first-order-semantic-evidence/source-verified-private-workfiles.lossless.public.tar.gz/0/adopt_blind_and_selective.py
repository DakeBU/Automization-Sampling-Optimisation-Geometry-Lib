from pathlib import Path
import hashlib, json, shutil, sys
sys.path.insert(0, 'tools')
import astis_semantic_roundtrip as rt
sha = lambda raw: hashlib.sha256(raw).hexdigest()
canon = lambda x: json.dumps(x, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()
def put(p, x):
    p = Path(p)
    assert not p.exists(), p
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(x, ensure_ascii=False, indent=2) + '\n')
B = Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-first-order-semantic-evidence')
N = Path('.astis/semantic-neutral-20261108/a12f0e76')
D = N / 'decoding'
F = Path('.astis/semantic-neutral-20261108/src_4e8f6a/phase1')
assert sha((N / 'input.json').read_bytes()) == 'a0d2cdbe708081c8e08945c0402e9957491f9b7a8cbd77d39ab799f88bb253f2'
packet = json.loads((N / 'input.json').read_bytes())
assert sha(canon({k: v for k, v in packet.items() if k != 'packet_sha256'})) == packet['packet_sha256'] == '3a46747a45e2faec9985325b4ca350eea512be012259d6b087ae4bf678ffa70f'
manifest = D / 'provenance/manifest.json'
assert sha(manifest.read_bytes()) == '9f95fdaa891eaa87c1c076ec1816473de9fcfeaa8197e13af2e294d290b2a50d'
m = json.loads(manifest.read_bytes())
for row in m['artifacts']:
    raw = (D / row['path']).read_bytes()
    assert sha(raw) == row['actual_raw_sha256'] and len(raw) == row['bytes']
run = json.loads((D / 'decoder-run.json').read_bytes())
assert not run['source_text_visible'] and not run['read_boundary']['repo_files_opened_other_than_designated_input']
assert sha((D / 'decoder-run.json').read_bytes()) == '7e57601d974bdaca871f1db47faf2ca617b55ab87c2bd23303eaa66e3c5d79f8'
assert run['input_commitments']['whole_json_canonical_sha256'] == sha(canon(packet)) == '763f488ccaa62d29252265c81d60dce95b2f62dbc749c22a2285053990061419'
fm = F / 'freeze_manifest.json'
assert sha(fm.read_bytes()) == 'cf4dd57dc05d19cb3ca6938032a7730d402aba6220a200ae4a3afe2aca721fac'
fresh = json.loads(fm.read_bytes())
assert fresh['status'] == 'FROZEN_AWAITING_SEPARATE_ANONYMOUS_COMPARISON_INPUTS'
for row in fresh['artifacts']:
    raw = (F / row['path']).read_bytes()
    assert sha(raw) == row['sha256'] and len(raw) == row['bytes']
public_fresh = B / 'fresh-source-reader-4e8f6a/phase1'
assert not public_fresh.exists()
shutil.copytree(F, public_fresh)
for p in F.rglob('*'):
    if p.is_file(): assert (public_fresh / p.relative_to(F)).read_bytes() == p.read_bytes()
dest = B / 'blind-f49d8a'
assert not dest.exists()
shutil.copytree(D, dest)
shutil.copy2(N / 'input.json', dest / 'input.json')
for p in D.rglob('*'):
    if p.is_file(): assert (dest / p.relative_to(D)).read_bytes() == p.read_bytes()
text = (D / 'reconstruction.txt').read_text()
assert sha(text.encode()) == 'c252bedd494363e0a001c32c6c0aed53c856e8ecaaf370843d122d52bc8c7ce2'
projection = {'decoder': '/root/decode_f49d8a', 'source_text_visible': False, 'reconstructed_theorem_text': text, 'reconstructed_text_sha256': sha(text.encode()), 'input_artifacts': packet['input_artifacts'], 'packet_sha256': packet['packet_sha256'], 'decoder_run_sha256': sha((D / 'decoder-run.json').read_bytes()), 'original_run_artifact': str(dest / 'decoder-run.json'), 'original_manifest_sha256': sha(manifest.read_bytes()), 'ambient_exposure': json.loads((D / 'input-exposure.json').read_bytes()), 'projection_note': 'Root mechanical schema projection of actual independent immutable decoder output. Original outputs are lossless; packet excludes its own hash field whereas whole-JSON canonical hash includes it. No source fidelity verdict is supplied.'}
put(dest / 'output-canonical-projection.json', projection)
audit_path = Path('research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-first-order.json')
audit = json.loads(audit_path.read_bytes())
assert audit['state'] == 'draft' and rt.decoder_packet(audit) == packet
audit['reconstruction'] = {'text': text, 'text_sha256': sha(text.encode()), 'decoder': projection['decoder'], 'decoder_run_sha256': projection['decoder_run_sha256'], 'decoder_packet_sha256': packet['packet_sha256'], 'source_text_visible': False, 'lean_statement_sha256': audit['lean']['statement_sha256'], 'input_artifacts': packet['input_artifacts'], 'run_artifact': str(dest / 'decoder-run.json'), 'ambient_exposure_record': str(dest / 'input-exposure.json'), 'ambient_identity_cues_disclosed': True, 'current_source_title_version_anchor_or_target_declaration_explicitly_supplied': False}
audit['state'] = 'blind-reconstructed'
audit_path.write_text(json.dumps(audit, ensure_ascii=False, indent=2) + '\n')
assert rt.decoder_packet(audit) == packet
selective_projection = dict(projection)
selective_projection['original_run_artifact'] = str(D / 'decoder-run.json')
selective = {'schema_version': 1, 'stage': 'SELECTIVE_ANONYMOUS_SOURCE_COMPARISON_BEFORE_FULL_MODULE_CONTEXT', 'input_scope': 'Only the anonymous proposition, approved standard definitions and actual independent blind reconstruction with honest ambient/hash provenance. No current target declaration/module/proof/authored lesson/publication context, prior source verdict or repair is included.', 'anonymous_decoder_packet': packet, 'blind_reconstruction': selective_projection, 'provenance': {'actual_neutral_input': str(N / 'input.json'), 'actual_neutral_input_raw_sha256': sha((N / 'input.json').read_bytes()), 'independent_decoder_manifest_raw_sha256': sha(manifest.read_bytes()), 'independent_decoder_run_raw_sha256': sha((D / 'decoder-run.json').read_bytes()), 'own_source_phase1_freeze_manifest_raw_sha256': sha(fm.read_bytes()), 'all21_actual_source_phase1_artifacts_verified': True, 'packet_self_field_hash_and_whole_JSON_hash_distinguished': True, 'whole_JSON_canonical_sha256': sha(canon(packet))}}
neutral_input = F.parent / 'phase2-selective-input.json'
put(neutral_input, selective)
put(B / 'phase2-selective-input.json', selective)
put(B / 'blind-adoption-receipt.json', {'independent_decoder': projection['decoder'], 'source_fresh_actor': '/root/source_reader_4e8f6a', 'source_phase1_freeze_manifest_sha256': sha(fm.read_bytes()), 'actual_source_phase1_artifacts_and_public_copies_verified': len(fresh['artifacts']) * 2, 'blind_raw_outputs_and_public_copies_verified': True, 'actual_anonymous_packet_raw_sha256': sha((N / 'input.json').read_bytes()), 'anonymous_packet_canonical_sha256': packet['packet_sha256'], 'whole_JSON_canonical_sha256': sha(canon(packet)), 'ambient_exposure_preserved': True, 'state': audit['state'], 'selective_neutral_input': str(neutral_input), 'selective_input_raw_sha256': sha(neutral_input.read_bytes()), 'root_source_verdict_created': False, 'sourceV': False})
print(json.dumps({'state': audit['state'], 'selective_input': str(neutral_input), 'selective_input_raw_sha256': sha(neutral_input.read_bytes()), 'source_phase1_raw_sha256': sha(fm.read_bytes()), 'sourceV': False}))
