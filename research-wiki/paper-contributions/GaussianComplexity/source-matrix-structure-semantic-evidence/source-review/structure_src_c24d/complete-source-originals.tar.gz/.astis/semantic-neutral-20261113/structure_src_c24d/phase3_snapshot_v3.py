from pathlib import Path
import json,hashlib
repo=Path('/Users/zhouhuanjian/ASTIS-GC'); out=Path(__file__).resolve().parent; old=out/'phase3-inputs'; new=out/'phase3-current-v3-inputs'
rels=['.astis/huanjian-gc-source-matrix-structure-20261113/fresh-P-review.v3.json','.astis/huanjian-gc-source-matrix-structure-20261113/fresh-T-review.v3.json','.astis/huanjian-gc-source-matrix-structure-20261113/candidate-publication-context.v2.json','website/content/declaration_lessons/huanjian-gaussian-source-matrix-structure.json','website/content/publications/huanjian-gaussian-source-matrix-structure.json','research-wiki/paper-contributions/GaussianComplexity/source-matrix-structure-semantic-evidence/source-lean-map.authored-v1.json','research-wiki/paper-contributions/GaussianComplexity/source-matrix-structure-semantic-evidence/conceptual-mirror-audit.authored-v1.json']
manifest=[]
def diff(a,b,path='$'):
 if type(a)!=type(b): return [{'path':path,'old':a,'current':b}]
 if isinstance(a,dict):
  out=[]
  for k in sorted(set(a)|set(b)):
   if k not in a or k not in b: out.append({'path':path+'.'+k,'old':a.get(k),'current':b.get(k)})
   else: out+=diff(a[k],b[k],path+'.'+k)
  return out
 if isinstance(a,list):
  if len(a)!=len(b): return [{'path':path,'old':a,'current':b}]
  return sum((diff(x,y,path+f'[{i}]') for i,(x,y) in enumerate(zip(a,b))),[])
 return [] if a==b else [{'path':path,'old':a,'current':b}]
for rel in rels:
 b=(repo/rel).read_bytes(); dest=new/rel; dest.parent.mkdir(parents=True,exist_ok=True); dest.write_bytes(b); manifest.append({'path':rel,'sha256':hashlib.sha256(b).hexdigest(),'size':len(b)})
 prior=rel.replace('fresh-P-review.v3','fresh-P-review.v1').replace('fresh-T-review.v3','fresh-T-review.v1').replace('candidate-publication-context.v2','candidate-publication-context.v1')
 print('\n===== DIFF',prior,'TO',rel,'=====\n',json.dumps(diff(json.loads((old/prior).read_text()),json.loads(b)),ensure_ascii=False,indent=2))
(out/'phase3-current-v3-input-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n'); print('\n===== V3 SNAPSHOT MANIFEST =====\n',json.dumps(manifest,indent=2))
