# Source-only reconstruction of Appendix C.2, p10–p12 scalar argument

The source is *On Complexity of Gaussian Sampling*, arXiv:2610.20492v1, pinned in `.astis/huanjian-resume-20261103/2610.20492v1.html` with SHA-256 `6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915`. This reconstruction uses the pinned HTML, `docs/proof-digestion-protocol.md`, and `.agents/skills/astis-semantic-roundtrip/SKILL.md`. The exact source line evidence and command are recorded in `raw-anchor-evidence.txt`.

## Standing scope and measures

- Lemma 4.4 fixes the nonnegative integer order \(q\) under \(2q+1<d\) and starts with independent vectors \(g_1,\ldots,g_{q+1}\sim N(0,I_d)\). Appendix C.2 sets \(r=q+1\), \(n=2q+1\), and indexes rows by \(1\le i\le d\). In particular, \(r\ge 1\) and \(d\ge 2\). [S4.Thmtheorem4.p1.m2–m5, A3.SS2.p1.m1–m3]
- The row \(\gamma_i=((g_1)_i,\ldots,(g_r)_i)^\top\in\mathbb R^r\) has standard multivariate Gaussian law \(N(0,I_r)\). The full row family is independent. The scalar statements can be expressed with the common row marginal because every \(R_i\) below has the same law. Their source probabilities and expectations refer to the Gaussian experiment that gives the row laws, or equivalently to the marginal for any one-row expression. The all-row event refers to the joint experiment. The tail integral separately uses Lebesgue measure \(ds\) on the real half-line. The equality of scalar expectations across rows follows from their common law, and the all-row union bound only needs the marginal bounds. [A3.Ex85.m1, A3.SS2.p1.m4–m5, A3.Ex105, A3.Ex106, A3.SS2.p12.m1–m2]

## Tail and truncated first moment

- Put \(L=2r+3\log(1000d)\) and \(R_i=\|\gamma_i\|_2^2\). The cutoff depends on \(r,d\), is common to every row, and is positive on the standing range. The shifted tail bound follows from the one-point Gaussian exponential moment \(\mathbb E e^{R_i/3}=3^{r/2}\), Markov's inequality at \(x\ge0\), and \((\log3)/2<2/3\):
  \[
  \mathbb P(R_i>2r+3x)
  \le \exp\bigl((r/2)\log3-2r/3-x\bigr)\le e^{-x}.
  \]
  Taking \(x=\log(1000d)+s/3\) for every real \(s\ge0\) meets the Markov range and yields \(\mathbb P(R_i>L+s)\le e^{-s/3}/(1000d)\). The endpoint \(s=0\) is included and bounds the mass of the strict event \(R_i>L\). The same endpoint feeds the p10 all-row event \(\mathcal T=\{R_i\le L\text{ for all }i\}\), with probability at least \(1-d/(1000d)=0.999\). [A3.SS2.p10.m1–m5, A3.Ex104, A3.Ex105, A3.SS2.p10.m6, A3.SS2.p11.m1–m2]
- For each row, p11 supplies an identity and a bound in a single display:
  \[
  \mathbb E[R_i\mathbf 1_{\{R_i>L\}}]
  =L\mathbb P(R_i>L)+\int_0^\infty \mathbb P(R_i>L+s)\,ds
  \le \frac{L+3}{1000d}.
  \]
  The first term is the cutoff times the mass of the strict tail event. The integral represents the positive excess above \(L\). The omitted argument splits the random variable pointwise into \(L\mathbf 1_{\{R_i>L\}}+(R_i-L)_+\). For a fixed \(R_i\), the latter is the Lebesgue integral of \(\mathbf 1_{\{R_i>L+s\}}\) over \(s\ge0\). Joint measurability and nonnegativity allow Tonelli, and the real expectation is justified by finite Gaussian first moment or the tail majorant. Using \(s=0\) and \(L\ge0\) bounds the first term by \(L/(1000d)\), while \(\int_0^\infty e^{-s/3}\,ds=3\) gives the remaining \(3/(1000d)\). The choice of whether to include \(s=0\) in the Lebesgue integral is immaterial, whereas the pointwise truncation events are fixed and strict on the upper part. [A3.SS2.p11.m1–m2, A3.Ex106.m1–m2]

## Scalar normalization and bias

- The kept mass uses the weak cutoff and produces the common scalar \(a=r^{-1}\mathbb E[R_i\mathbf 1_{\{R_i\le L\}}]\). Since \(\mathbb E R_i=r\), the two complementary events give
  \[
  0\le a\le1,\qquad
  1-a=\frac1r\mathbb E[R_i\mathbf 1_{\{R_i>L\}}]
      \le\frac{L+3}{1000rd}.
  \]
  Both identities are real-valued and use the same row and cutoff. The same \(a\) works for every \(i\), so it depends on \(r,d\) via the common row law and cutoff. The explicit bound uses \(r>0\). The partition of mass handles \(R_i=L\) on the kept side. The first moment follows by summing the unit coordinate variances, and nonnegative kept and discarded pieces of the integrable \(R_i\) justify splitting the expectation. [A3.Ex108.m1, A3.SS2.p12.m1–m4, A3.Ex109.m1]
- The source states the exponential moment from the Gaussian law and omits the one-dimensional Gaussian integral or chi-square calculation and its product lift. It also omits measurability, integrability, exchange of integrals, the half-line exponential evaluation, and complementary-indicator bookkeeping in the displayed derivations. The Gaussian law and standing range supply these proof ingredients. The p11 moment identity and estimate feed the p12 scalar bias directly, and the p10 all-row probability estimate is a separate consumer of the endpoint. [A3.SS2.p10.m3–m6, A3.Ex104–A3.Ex106, A3.SS2.p12.m3–m4, A3.Ex109]
- Downstream, p12 introduces truncated matrices \(Y_i\), identifies the kept second-moment matrix as \(aI_r\) by radial symmetry, and uses the common scalar in the expectations of the matrix sums through Fact C.5. Those matrix statements identify the downstream boundary of the scalar result. The scalar chain above ends at the first-moment partition and the normalized bias bound. [A3.Ex107–A3.Ex110, A3.SS2.p12.5]
