from pathlib import Path
import subprocess,sys,json
r=Path(__file__).resolve().parent;repo=r.parents[2]
parents=["AutoSamplingTheory/TechnicalLemmas/StochasticProcesses/GaussianFourthMoment.lean","AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumGaussianMoments.lean","AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumCosineExpansion.lean","AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumGridAlias.lean","AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumExactMeans.lean"]
for i,s in enumerate(parents+["AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumVariances.lean","Tests/GaussianComplexityFixedSpectrumVariances.lean"]):
 out=r/"oleans"/Path(s).with_suffix(".olean")
 if out.is_symlink():out.unlink()
 label="isolated-final-"+str(i)+"-"+Path(s).stem
 result=subprocess.run([sys.executable,str(r/"run_recorded.py"),label,"lean","-o",str(out),s],cwd=repo)
 if result.returncode:sys.exit(result.returncode)
result=subprocess.run([sys.executable,str(r/"run_recorded.py"),"isolated-final-kernel","lean",str(r/"KernelAudit.lean")],cwd=repo)
sys.exit(result.returncode)
