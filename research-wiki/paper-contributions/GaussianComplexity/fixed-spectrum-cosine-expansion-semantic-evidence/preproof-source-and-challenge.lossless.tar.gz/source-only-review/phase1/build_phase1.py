#!/usr/bin/env python3
"""Generate bounded raw evidence and inventories from the single pinned input."""
import extract_source as x
from pathlib import Path
import hashlib
import json

BASE = x.BASE
def write_json(name, value):
    (BASE / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

spec = json.loads((BASE / 'source_graph_spec.json').read_text())
regions = spec['declared_regions']
nodes = {n['id']: n for n in spec['nodes']}
mapping = {}
for node in spec['nodes']:
    for anchor in node.get('source_anchors', []):
        assert anchor in x.ids, anchor
        assert anchor not in mapping, anchor
        mapping[anchor] = node['id']

all_nodes = []
region_records = []
text_parts = []
for region in regions:
    key = region['anchor']
    node = x.ids[key]
    record = {**region, **x.record(node)}
    raw_file = 'raw-' + key + '.html'
    (BASE / raw_file).write_bytes(x.excerpt(node).encode('utf-8'))
    record['raw_excerpt_file'] = raw_file
    region_records.append(record)
    text_parts.append('===== #' + key + ' =====\n' + x.readable(node))
    for child in node.walk():
        all_nodes.append((key, child))
assert len({id(n) for _,n in all_nodes}) == len(all_nodes), 'Overlapping declared regions'

seen_ids = {n.attrs['id'] for _,n in all_nodes if n.attrs.get('id')}
overrides = spec['coverage_exclusions']
def disposition(node):
    chain = [node, *x.ancestors(node)]
    for item in chain:
        key = item.attrs.get('id')
        if key in overrides:
            return {'disposition':'EXCLUDED','reason':overrides[key]}
        if key in mapping:
            return {'disposition':'NODE','node_id':mapping[key]}
    return {'disposition':'EXCLUDED','reason':'Structural wrapper or source navigation; no independent mathematical claim.'}

anchors, coverage, math, links = [], [], [], []
counters = {}
for region, node in all_nodes:
    base = {**x.record(node), 'region':region}
    if node.attrs.get('id'):
        anchors.append({**base, **disposition(node)})
    classes = node.attrs.get('class','').split()
    kinds = []
    if node.tag == 'p' and 'ltx_p' in classes: kinds.append('paragraph')
    if 'ltx_para' in classes: kinds.append('paragraph-block')
    if 'ltx_equation' in classes or 'ltx_equationgroup' in classes: kinds.append('display-container-or-row')
    if 'ltx_theorem' in classes: kinds.append('theorem-or-fact-or-remark')
    if node.tag in {'h2','h3','h4','h5','h6'}: kinds.append('heading')
    if node.tag == 'cite': kinds.append('citation')
    for kind in kinds:
        counters[(region,kind)] = counters.get((region,kind),0) + 1
        locator = node.attrs.get('id') or f'{region}::{kind}[{counters[(region,kind)]}]'
        d = disposition(node)
        if kind == 'heading':
            d = {'disposition':'EXCLUDED','reason':'Heading/label; substantive statement and proof text are separately inventoried.'}
        elif kind == 'paragraph-block':
            child_ids = sorted({disposition(child).get('node_id') for child in node.walk() if disposition(child).get('node_id')})
            d = {'disposition':'NODE','node_ids':child_ids,'note':'Paragraph-block container; mathematical paragraph/display children have their own exact dispositions.'} if child_ids else d
        coverage.append({**base,'locator':locator,'kind':kind,'text':x.clean(x.rendered(node)),**d})
    if node.tag == 'math':
        tex = node.attrs.get('alttext','')
        annotation = [a for a in node.walk() if a.tag == 'annotation' and a.attrs.get('encoding') == 'application/x-tex']
        annotation_text = ''.join(c for a in annotation for c in a.children if isinstance(c,str))
        math.append({**base,'tex':tex,'tex_sha256':x.sha(tex),'annotation_tex':annotation_text,
                     'alttext_equals_annotation':tex == annotation_text,**disposition(node)})
    if node.tag == 'a':
        href = node.attrs.get('href')
        if href:
            target = href[1:] if href.startswith('#') else None
            d = disposition(node)
            role = 'source-reference'
            if region == 'bib.bib3':
                role = 'bibliography-backlink-or-catalog-locator'
                d = {'disposition':'EXCLUDED','reason':'Bibliographic locator/backlink; cited work identity is represented by citation.openai22. External work and backlink targets are not read or imported.'}
            elif region == 'license-tr':
                role = 'license-notice'
                d = {'disposition':'NODE','node_id':'provenance.license'}
            links.append({**base,'text':x.clean(x.rendered(node)), 'href':href,'title':node.attrs.get('title'),
                          'target_in_declared_region': target in seen_ids if target else False,
                          'target_exists_in_pinned_snapshot':target in x.ids if target else None,
                          'role':role,**d})

for n in spec['nodes']:
    n['source_records'] = [x.record(x.ids[a]) for a in n.get('source_anchors',[])]
write_json('source_graph.json',spec)
write_json('declared_regions.json',region_records)
write_json('all_source_anchors.json',anchors)
write_json('paragraph_display_citation_coverage.json',coverage)
write_json('all_math_anchors.json',math)
write_json('all_source_links.json',links)
(BASE / 'readable-excerpts.txt').write_text('\n\n'.join(text_parts) + '\n')
write_json('coverage_summary.json',{
    'scope':'Exactly the declared raw regions only; no whole-paper/source-completion or formalization credit.',
    'independent_topology_review':'Pending distinct challenge; extractor does not approve own topology.',
    'raw_source_sha256':x.EXPECTED,
    'regions':len(regions),'all_source_ids':len(anchors),'math':len(math),'links':len(links),
    'coverage_records':len(coverage),'coverage_by_kind':{kind:sum(1 for c in coverage if c['kind']==kind) for kind in sorted({c['kind'] for c in coverage})},
    'missing_math_alttext':[m['id'] for m in math if not m['tex']],
    'math_alttext_annotation_mismatches':[m['id'] for m in math if not m['alttext_equals_annotation']],
    'unresolved_local_links':[l['href'] for l in links if l['href'].startswith('#') and not l['target_exists_in_pinned_snapshot']],
    'source_graph_nodes':len(spec['nodes']),'hyperedges':len(spec['hyperedges']),
    'readable_is_derived':'Math uses exact decoded alttext; raw byte slices and every math raw hash remain authoritative.'})
print(json.dumps({'regions':len(regions),'anchors':len(anchors),'math':len(math),'links':len(links),'coverage_records':len(coverage),'nodes':len(spec['nodes']),'hyperedges':len(spec['hyperedges'])}))
