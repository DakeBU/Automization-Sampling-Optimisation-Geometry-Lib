import AutoSamplingTheory.ExampleCases.ProximalBPS.ActualHazardClock
import AutoSamplingTheory.TechnicalLemmas.Probability.UnitExponentialProduct
import Mathlib.MeasureTheory.Integral.IntervalIntegral.FundThmCalculus
import Mathlib.MeasureTheory.Integral.Bochner.ContinuousLinearMap

/-! Prospective statement only. Actual first finite PBPS event, Appendix A.1
(A.1),(A.2) and the first density factor implicit in (A.7), arXiv2609.06905v1.
The finite subprobability and marked-test packaging is attributed ASTIS completion.
Literal actual Exp1 coordinate0, stopped wait and zero-normal identity reflection
are retained. F defaults to0 only outside the restricted positive finite event;
missing probability includes waits beyond T or infinite, without renormalization.
Full path law, unused-tail conditioning, reversal, invariance, semigroup/allL2,
implementation, error, unbounded expected query cost, main/composition remain OPEN. -/
namespace AutoSamplingTheory.ExampleCases.ProximalBPS.ActualFiniteFirstEventLaw
open InnerProductSpace MeasureTheory ProbabilityTheory Filter
open scoped ContDiff NNReal ENNReal Topology Interval
noncomputable section
set_option autoImplicit false

private def actual_finite_first_event_law_statement
    {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℝ E]
    [FiniteDimensional ℝ E] [MeasurableSpace E] [BorelSpace E]
    {V : E → ℝ} {α β : ℝ≥0} {η : ℝ}
    (hα : 0 < (α : ℝ)) (hαβ : α ≤ β) (hV : ContDiff ℝ 2 V)
    (hH : ∀ x v : E,
      (α : ℝ) * ‖v‖ ^ 2 ≤ (fderiv ℝ (fderiv ℝ V) x v) v ∧
      (fderiv ℝ (fderiv ℝ V) x v) v ≤ (β : ℝ) * ‖v‖ ^ 2)
    (hη : 0 < η) (hβη : (β : ℝ) * η ≤ 1) : Prop :=
    let P : Measure (ℕ → ℝ) := Measure.infinitePi (fun _ : ℕ => expMeasure (1 : ℝ))
    let ε : (ℕ → ℝ) → ℕ → ℝ≥0 := fun sample k => Real.toNNReal (sample k)
    let c : E → E → E := fun y xRef => y - η • gradient V xRef
    let Φ : E → E → ℝ → (E × E) → (E × E) := fun y xRef t z =>
      (c y xRef + Real.cos t • (z.1 - c y xRef) +
          (Real.sqrt η * Real.sin t) • z.2,
       (-Real.sin t / Real.sqrt η) • (z.1 - c y xRef) + Real.cos t • z.2)
    let S : E → (E × E) → (E × E) := fun xRef z =>
      (z.1, z.2 - (2 * inner ℝ z.2 (gradient V z.1 - gradient V xRef) /
        ‖gradient V z.1 - gradient V xRef‖ ^ 2) • (gradient V z.1 - gradient V xRef))
    let rate : E → (E × E) → ℝ := fun xRef z =>
      Real.sqrt η * max 0 (inner ℝ z.2 (gradient V z.1 - gradient V xRef))
    let Λ : E → E → (E × E) → ℝ≥0 → ℝ := fun y xRef z t =>
      ∫ s in (0 : ℝ)..(t : ℝ), rate xRef (Φ y xRef s z)
    let τ : E → E → (E × E) → ℝ≥0 → WithTop ℝ≥0 := fun y xRef z e =>
      MeasureTheory.hittingAfter
        (fun t : ℝ≥0 => fun a : (E × E) × (E × E) × ℝ≥0 =>
          Λ a.1.1 a.1.2 a.2.1 t - (a.2.2 : ℝ))
        (Set.Ici (0 : ℝ)) 0 ((y, xRef), z, e)
    let U : E → E → (E × E) → (ℕ → ℝ) → WithTop ℝ≥0 :=
      fun y xRef z sample => τ y xRef z (ε sample 0)
    let F : E → E → (E × E) → (ℕ → ℝ) → ℝ :=
      fun y xRef z sample => ((U y xRef z sample).untopD 0 : ℝ≥0)
    let A : E → E → (E × E) → ℝ≥0 → Set (ℕ → ℝ) :=
      fun y xRef z T => {sample | (0 : WithTop ℝ≥0) < U y xRef z sample ∧
        U y xRef z sample ≤ (T : WithTop ℝ≥0)}
    let d : E → E → (E × E) → ℝ → ℝ := fun y xRef z s =>
      rate xRef (Φ y xRef s z) * Real.exp (-Λ y xRef z (Real.toNNReal s))
    let ρ : E → E → (E × E) → ℝ≥0 → Measure ℝ := fun y xRef z T =>
      (volume.restrict (Set.Ioc (0 : ℝ) (T : ℝ))).withDensity
        (fun s => ENNReal.ofReal (d y xRef z s))
    let J : E → E → (E × E) → ℝ → (ℝ≥0 × (E × E)) :=
      fun y xRef z s => (Real.toNNReal s, S xRef (Φ y xRef s z))
    ∀ y xRef : E, ∀ z : E × E,
      Measurable (U y xRef z) ∧ Measurable (F y xRef z) ∧
      Measurable (J y xRef z) ∧
      (∀ T : ℝ≥0,
        MeasurableSet (A y xRef z T) ∧
        Measure.map (F y xRef z) (P.restrict (A y xRef z T)) = ρ y xRef z T ∧
        Measure.map (fun sample => J y xRef z (F y xRef z sample))
          (P.restrict (A y xRef z T)) = Measure.map (J y xRef z) (ρ y xRef z T) ∧
        IsFiniteMeasure (ρ y xRef z T) ∧
        (ρ y xRef z T).real Set.univ = 1 - Real.exp (-Λ y xRef z T) ∧
        ρ y xRef z T Set.univ ≤ 1 ∧
        (∀ h : (ℝ≥0 × (E × E)) → ℝ, Measurable h →
          ∀ M : ℝ, 0 ≤ M → (∀ a, |h a| ≤ M) →
            Integrable h (Measure.map (J y xRef z) (ρ y xRef z T)) ∧
            Integrable (fun sample => h (J y xRef z (F y xRef z sample)))
              (P.restrict (A y xRef z T)) ∧
            Integrable (fun s => h (J y xRef z s) * d y xRef z s)
              (volume.restrict (Set.Ioc (0 : ℝ) (T : ℝ))) ∧
            (∫ sample, h (J y xRef z (F y xRef z sample))
                ∂P.restrict (A y xRef z T)) =
              ∫ s, h (J y xRef z s) * d y xRef z s
                ∂volume.restrict (Set.Ioc (0 : ℝ) (T : ℝ))))

end
end AutoSamplingTheory.ExampleCases.ProximalBPS.ActualFiniteFirstEventLaw
