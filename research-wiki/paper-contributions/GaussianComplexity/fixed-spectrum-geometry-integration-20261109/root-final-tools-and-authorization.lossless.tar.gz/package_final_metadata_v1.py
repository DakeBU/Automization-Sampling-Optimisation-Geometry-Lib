"""Preserve and stage actual final delivery/release evidence, without new gates."""
from pathlib import Path
import gzip, hashlib, json, shutil, subprocess, tarfile
P = Path('.astis/huanjian-gc-fixed-spectrum-geometry-integration-20261109')
B = Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-geometry-integration-20261109')
sha = lambda b: hashlib.sha256(b).hexdigest()
dump = lambda x: (json.dumps(x, ensure_ascii=False, indent=2)+'\n').encode()
git = lambda *a: subprocess.check_output(['git', *a])
assert git('rev-parse','HEAD').decode().strip() == 'b3581af0fc7e517e6cf5b883f4af064ddaa72aa2'
assert not git('diff','--cached','--name-only').strip()
mutable = [Path('runs/substantive_advances.jsonl'),
    Path('research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-geometry.json'),
    B.parent/'README.md']
assert set(git('diff','HEAD','--name-only').decode().splitlines()) == set(map(str,mutable))
assert sha(mutable[0].read_bytes()) == '820b899aae7ed60f17711496f6a4ac556346f48dbb46eff8feefe0f20903d2b2'
review_src = P/'independent-reader/final-metadata-readback-v1'
assert review_src.is_dir()
# The root separately checks the independent report before invoking this helper.
review_dst = B/'independent-reader/final-metadata-readback-v1'
assert not review_dst.exists()
shutil.copytree(review_src, review_dst, ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
for q in review_src.rglob('*'):
    if q.is_file() and '__pycache__' not in q.parts and q.suffix != '.pyc':
        assert q.read_bytes() == (review_dst/q.relative_to(review_src)).read_bytes()
checks = B/'final-metadata-focused-checks'; checks.mkdir()
receipts = sorted(Path('.astis/huanjian-resume-20261103').glob('*-geometry-final-metadata-*.receipt.json'))
receipts += list(Path('.astis/huanjian-resume-20261103').glob('*-geometry-final-local-metadata-projection.receipt.json'))
assert len(receipts) == 5
for q in receipts:
    r = json.loads(q.read_bytes()); raw = Path(r['log']).read_bytes()
    assert r['exit_code'] == 0 and sha(raw) == r['log_sha256']
    (checks/q.name).write_bytes(q.read_bytes())
    (checks/(Path(r['log']).name+'.gz')).write_bytes(gzip.compress(raw,mtime=0))
tools = sorted(q for q in P.iterdir() if q.is_file())
archive = B/'root-final-tools-and-authorization.lossless.tar.gz'
assert not archive.exists()
with tarfile.open(archive,'w:gz') as t:
    for q in tools: t.add(q,arcname=q.name,recursive=False)
with tarfile.open(archive,'r:gz') as t:
    for q in tools: assert t.extractfile(q.name).read() == q.read_bytes()
(B/'root-final-tools-and-authorization.manifest.json').write_bytes(dump({
    'scope':'Actual completed local delivery, original-verifier release and mechanical metadata packaging. Not a fresh build or remote/purification/Goal result.',
    'archive':str(archive),'sha256':sha(archive.read_bytes()),
    'files':[{'original':str(q),'member':q.name,'sha256':sha(q.read_bytes())} for q in tools]}))
tracked = set(git('ls-files','-z').decode().strip('\0').split('\0'))
pack = B/'final-frozen-raw-packaging'; pack.mkdir(); safe=[]; wrapped=[]
for q in sorted(q for q in B.rglob('*') if q.is_file() and str(q) not in tracked):
    raw=q.read_bytes(); binary=q.suffix in ['.gz','.zip','.png'] or b'\0' in raw
    ignored = subprocess.run(['git','check-ignore','-q','--',str(q)]).returncode == 0
    bad = not binary and (b'\r\n' in raw or raw.endswith(b'\n\n') or any(line.endswith((b' ',b'\t')) for line in raw.splitlines()))
    if ignored or bad:
        z=pack/(str(len(wrapped)).zfill(3)+'-'+q.name+'.gz')
        z.write_bytes(gzip.compress(raw,mtime=0)); assert gzip.decompress(z.read_bytes())==raw
        wrapped.append({'original_path':str(q),'raw_sha256':sha(raw),'raw_bytes':len(raw),
            'gzip_path':str(z),'gzip_sha256':sha(z.read_bytes()),'original_retained_unchanged':True}); safe.append(z)
    else: safe.append(q)
mp=pack/'manifest.json'; mp.write_bytes(dump({'scope':'Lossless wrappers for ignored/EOL/whitespace raw evidence only; originals preserved.','files':wrapped})); safe.append(mp)
safe=sorted(set(safe+mutable)); subprocess.run(['git','add','--',*map(str,safe)],check=True)
staged=git('diff','--cached','--name-only','-z').decode().strip('\0').split('\0')
assert set(staged)==set(map(str,safe))
for name in staged: assert git('show',':'+name)==Path(name).read_bytes(),name
subprocess.run(['git','diff','--cached','--check'],check=True)
assert len(list((B/'actual-browser-v1-originals').glob('*.png'))) == 44
print(json.dumps({'staged_paths':len(staged),'actual_original_PNGs':44,'raw_wrappers':len(wrapped),
    'all_index_bytes_equal_live':True,'mutable_paths':list(map(str,mutable)),
    'fresh_build_remote_purification_or_Goal_credit':False}))
