from pathlib import Path
import json,hashlib,copy,stat,subprocess,datetime
OUT=Path(__file__).parent;ROOT=OUT.parent;sha=lambda b:hashlib.sha256(b).hexdigest()
inputs=json.loads((OUT/'input-receipts.json').read_bytes());captures=[]
for x in inputs:
 p=subprocess.run(['cat',x['path']],capture_output=True);assert p.returncode==0 and sha(p.stdout)==x['sha256']
 (OUT/(x['copy']+'.captured.stdout')).write_bytes(p.stdout);(OUT/(x['copy']+'.captured.stderr')).write_bytes(p.stderr)
 captures.append({'argv':['cat',x['path']],'returncode':p.returncode,'stdout_bytes':len(p.stdout),'stdout_sha256':sha(p.stdout),'stderr_bytes':len(p.stderr),'stderr_sha256':sha(p.stderr),'provenance':'actual rerun capture; initial tool output of large structured delta was truncated'})
oldsg=json.loads((ROOT/'phase2b/author-source-graph.json').read_bytes());newsg=json.loads((OUT/'source-graph.v2.json').read_bytes())
oldt=json.loads((ROOT/'phase2b/author-type-source-overlay.json').read_bytes());newt=json.loads((OUT/'type-source-overlay.v2.json').read_bytes());delta=json.loads((OUT/'structured-delta-and-lineage.json').read_bytes())
def apply(orig,changes):
 result=copy.deepcopy(orig)
 for c in changes:
  path=[x.replace('~1','/').replace('~0','~') for x in c['path'].split('/')[1:]];target=result
  for x in path[:-1]:target=target[int(x)] if isinstance(target,list) else target[x]
  key=int(path[-1]) if isinstance(target,list) else path[-1]
  if c['operation']=='add':
   assert not isinstance(target,list) and key not in target
  else:assert target[key]==c['before'],c['path']
  target[key]=copy.deepcopy(c['after'])
 return result
assert apply(oldsg,delta['source_graph_exact_changes'])==newsg
assert apply(oldt,delta['typed_overlay_exact_changes'])==newt
assert [dict(x,obligations=[]) for x in oldt['roots']]==[dict(x,obligations=[]) for x in newt['roots']]
on={x['id']:x for x in oldsg['nodes']};nn={x['id']:x for x in newsg['nodes']};oe={x['id']:x for x in oldsg['and_hyperedges']};ne={x['id']:x for x in newsg['and_hyperedges']}
assert set(on)<=set(nn) and set(oe)<=set(ne)
assert {x for x in on if on[x]!=nn[x]}=={'C5.polynomials','C5.span-conversion','C2.witness'}
assert {x for x in oe if oe[x]!=ne[x]}=={'e-span','e-witness'}
assert ne['e-range']==oe['e-range'] and nn['E.range-columns']==on['E.range-columns']
assert ne['e-witness']['parents']==['C5.range-reverse','E.range-existential']
assert ne['e-range-reverse']['parents']==['C5.range']
assert 'E.diagonal-power-action' in ne['e-span']['parents']
ob={x['id']:x for x in newt['mathematical_obligations']}
for k in ['P.objects','P.polynomial','P.triangular']:assert ob[k]['requires_internal_subobligations']==['P.diagonal-action'] and 'E.diagonal-power-action' in ob[k]['source_nodes']
for root in newt['roots']:assert 'P.diagonal-action' in root['obligations']
assert all(e['consumer'] in nn and set(e['parents'])<=set(nn) for e in ne.values())
for x in delta['lineage']['coverage_unchanged'],delta['lineage']['source_pins_unchanged']:
 assert sha(Path(x['path']).read_bytes())==x['sha256']
earlier=[]
for stage in ['phase1','phase2a','phase2b']:
 mpath=ROOT/f'{stage}.manifest.json';m=json.loads(mpath.read_bytes())
 assert all(sha((ROOT/stage/x['path']).read_bytes())==x['sha256'] and stat.S_IMODE((ROOT/stage/x['path']).stat().st_mode)==0o444 for x in m['files'])
 assert stat.S_IMODE((ROOT/stage).stat().st_mode)==0o555
 earlier.append({'stage':stage,'manifest_sha256':sha(mpath.read_bytes()),'hashes_modes_unchanged':True})
result={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'captures':captures,'author_structured_delta_exactly_replays':True,'all_prior_roots_except_obligation_accounting_unchanged':True,'unmodified_other_nodes_edges_C6_and_conjuncts':True,'coverage_pins_unchanged':True,'R1_immediate_edge':ne['e-witness'],'R2_leaf':nn['E.diagonal-power-action'],'R2_edge':ne['e-span'],'R2_typed_bindings':newt['internal_representation_bindings'],'earlier_freezes':earlier,'mechanical_checks_not_mathematical_verdict':True}
(OUT/'exact-recheck.receipts.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False,indent=2))
