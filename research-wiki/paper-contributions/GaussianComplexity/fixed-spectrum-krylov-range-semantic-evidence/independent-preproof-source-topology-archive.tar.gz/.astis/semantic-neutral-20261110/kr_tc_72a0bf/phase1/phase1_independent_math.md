# Phase 1: independent raw-source mathematical baseline

This is a challenger baseline, frozen before exposure to a proposed Statement Seal, project definitions, implementation, Source Proof Graph, or any earlier review. It is neither an acceptance verdict on an unseen target nor a proof-completion claim. The sole mathematical source read is the pinned original HTML, arXiv:2610.20492v1, 951991 bytes, SHA256 `6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915`.

## Exact scope and reading method

Read all of S4.SS1 (4.1, the hard family), S4.SS2 (4.2, all four lemma statements and connecting paragraphs), and A3.SS2 (C.2, including every Fact C.5/C.6 proof paragraph, every table formula, and the final proof of Lemma 4.4). `source_pins.json` gives every in-scope HTML ID a raw character interval, UTF8 byte interval, LF line interval and raw-fragment hash. The three full raw section fragments are also preserved. The reading projection is derived only from this HTML and includes *all* math elements, including those with `display="inline"` inside equation tables. All 252 math alttexts match their raw `application/x-tex` annotations exactly after HTML entity decoding. Exact raw MathML/HTML for C.5's range argument and the entire final proof was additionally displayed directly by `sed`. The source-derived textual projection is a convenience for reading, never the source-byte coordinate system.

Whole-source parser inventory was needed to locate the three section boundaries; no out-of-scope mathematical section text was output or used. The opening S4 theorem, C.1, C.3, C.4, and external reference [22] were not read. Their mathematical claims are only known to the extent explicitly restated in the three allowed sections. The allowed procedural documents contain links and file names; those linked files were not followed.

## Objects and quantifiers

The hard family fixes integer dimension d >= 2 and real kappa >= 2. For i = 1,...,d,

    theta_i = (i - 1/2) pi / d,
    lambda_i = (kappa + 1)/2 + ((kappa - 1)/2) cos(theta_i),
    Lambda = diag(lambda_1,...,lambda_d).

O is Haar orthogonal and independent of the algorithm's private randomness; A = O Lambda O^T; f_A(x) = x^T A x/2 and pi_A = N(0,A^{-1}). The spectrum is deterministic and can be supplied to the algorithm. This describes the hard instance; it is not an additional probabilistic input needed to prove the deterministic range identity.

For an integer q >= 0, the Krylov space is exactly

    K_q(g_1,...,g_{q+1}) = span { Lambda^j g_a : 1 <= a <= q+1, 0 <= j <= q }.

It includes the power j = 0 and exactly q+1 starting vectors. A q-query algorithm's output X has a representation O^T X in this space almost surely when 2q+1 < d (Lemma 4.3); the q+1-st vector accounts for an output outside the span of query points and replies. The equivalent polynomial representation has each p_a of degree *at most* q. Its coefficients may depend on the entire extended experiment. The source says the g_a are mutually independent standard Gaussian vectors. It does not say they are independent of O or of the whole extended experiment. No such extra independence may be inferred merely from the Gaussian representation.

For the uniform bound, n = 2q+1 and D_n = diag(cos(n theta_i)). There exists an absolute C > 0, uniform over the permitted dimensions, budgets and kappa, defining

    tau_dq = C [ (q+1) sqrt(log(d)/d)
                 + (q+1)(q+1+log(d)) log(d)/d ].

If 2q+1 < d and tau_dq <= 1/2, then with probability >= .99,

    forall u in K_q, |u^T D_n u| <= 2 tau_dq ||u||^2.

The quantifier order is one event of probability at least .99 followed by *every* vector in the random space. It is stronger than an estimate separately in probability for every fixed u, or for coefficients independent of the g_a. The source proves the stronger matrix event with probability >= .995 and weakens the numerical lower bound at the end.

## Exact C.2 construction

Set r = q+1. The mode index is j = 0,...,q; the start-vector index is a = 1,...,r; the spatial index is i = 1,...,d.

    t_i = (1, sqrt(2) cos(theta_i), ..., sqrt(2) cos(q theta_i))^T in R^r,
    gamma_i = ((g_1)_i,...,(g_r)_i)^T in R^r,
    B in R^(d x r^2), row_i(B) = d^(-1/2) (gamma_i tensor t_i)^T.

With a tensor coordinate ordered (a,j),

    B[i,(a,0)] = d^(-1/2) (g_a)_i,
    B[i,(a,j)] = sqrt(2) d^(-1/2) (g_a)_i cos(j theta_i)  for j >= 1.

The constant mode has normalization 1, not sqrt(2). The common spatial normalization is d^(-1/2), not d^(-1) or r^(-1/2). All matrices and vectors are real; transposes are ordinary real transposes. If a formal representation uses reversed tensor order, that is a permutation of coefficient coordinates requiring an explicit semantic correspondence, not literal equality of indexed matrices.

Independence and the N(0,I_d) laws of the g_a imply that gamma_1,...,gamma_d are independent N(0,I_r). This re-indexing of a finite Gaussian array is a genuine distributional bridge for C.6. It is absent from, and unnecessary for, the deterministic span calculation.

## Independent expansion of range(B) = K_q

The source use site is A3.SS2.p3, especially math IDs m2--m11. It invokes the identity cos(j theta) = T_j(cos theta), with T_j a degree-j Chebyshev polynomial having nonzero leading coefficient. Write alpha = (kappa+1)/2 and beta = (kappa-1)/2. Since beta != 0, P_j(x) = T_j((x-alpha)/beta) has degree j and nonzero leading coefficient. For j >= 1 this coefficient is 2^(j-1) beta^(-j), while P_0 = 1. Then P_j(lambda_i) = cos(j theta_i).

For each a define the cosine generating vector C_(a,j) by its i-th coordinate (g_a)_i cos(j theta_i). Expanding P_j proves C_(a,j) lies in span{Lambda^m g_a : 0 <= m <= j}. Conversely, the nonzero diagonal of the finite triangular coefficient transform shows x^j is a linear combination of P_0,...,P_j, hence Lambda^j g_a lies in span{C_(a,m) : 0 <= m <= j}. Taking the union over a proves equality of the two spans. The nonzero column factors d^(-1/2) and sqrt(2) leave the span unchanged, and matrix range equals the span of its columns. These are the source proof's mathematical bridges.

The word "basis" in the source does not establish independence of the *evaluated generating vectors*. They can be zero or linearly dependent for particular g. What is invertible is the coefficient transformation between the two polynomial generating lists. A faithful range proof must not divide by entries of g, assume all g_a nonzero, require a family of vectors to be linearly independent, or assume B has full column rank. It does not need distinct eigenvalues, Haar O, Gaussianity, concentration, cosine sums, n, tau, or 2q+1 < d. The standing d >= 2 supplies nonzero normalization; the standing kappa >= 2 supplies beta != 0. The latter can be generalized to kappa != 1, but that would be a labeled generalization rather than a newly invented source premise.

The exclusion of kappa = 1 is meaningful. With d = 4, q = 1, g_1 the all-ones vector, g_2 = 0, and kappa = 1, Lambda = I, so K_q has dimension one. The constant and cos(theta_i) columns of B are not proportional, so range(B) has dimension two. Thus dropping the nonconstant-affine condition destroys the asserted equality, even with 2q+1 < d. This is an analytic counterexample argument, not a computer-checked experiment or an API search.

The case q = 0 works: r = 1, t_i = (1), n = 1, and B is the single column d^(-1/2) g_1. The higher-mode family is empty; degree-at-most-q and Lambda^0 conventions must preserve this endpoint.

## Algebraic representation of energy and weighted quadratic form

For every deterministic c in R^(r^2), put u = Bc. Direct finite matrix algebra, without an event or a Gaussian law, gives

    ||u||^2 = c^T B^T B c,
    u^T D_n u = c^T B^T D_n B c.

Coordinatewise, writing H_i(c) = sum_(a=1)^r sum_(j=0)^q (g_a)_i (t_i)_j c_(a,j), these are

    u_i = d^(-1/2) H_i(c),
    ||u||^2 = (1/d) sum_i H_i(c)^2,
    u^T D_n u = (1/d) sum_i cos(n theta_i) H_i(c)^2.

These are representation equalities, distinct from expectation identities and norm inequalities. A3.SS2.p2 and p9 announce them; the split table elements A3.Ex130.m1/m2 and A3.Ex131.m1/m2 actually use them. A cover that extracts only `display="block"` misses the two substantive equalities and their accompanying inequalities in A3.EGx13.

For arbitrary u in K_q, the range identity supplies *existence* of c with u = Bc. No unique or canonical coefficient choice is required for the source theorem, and a global default/fallback coefficient definition is not supplied by the source. The same pair of matrix norm inequalities yields, for every c on the same event,

    (1-tau) ||c||^2 <= c^T B^T B c = ||u||^2,
    |c^T B^T D_n B c| <= tau ||c||^2.

The first bound uses the operator norm of B^T B-I and the real identity c^T I c=||c||^2; the second uses the operator norm of B^T D_n B. These norm-to-quadratic estimates are mathematical dependencies, not public hypotheses beyond the internal conditional matrix-to-vector lemma. Since tau <= 1/2, 1-tau > 0 and tau >= 0 (from its definition), so combining gives tau/(1-tau) <= 2 tau and the source conclusion. No division by ||u|| or ||c|| is needed; zero vectors are included.

## C.5 and C.6 proof structure, with use sites

C.5 has separately provable deterministic and probabilistic conjuncts. Besides the range identity, it states E[B^T B]=I_(r^2), E[B^T D_n B]=0, ||t_i||^2 <= 2r, sum_i t_i t_i^T=dI_r, and sum_i cos(n theta_i)t_i t_i^T=0. Treating the single Fact label as a reason that all conjuncts depend on each other creates false ANDs.

* A3.SS2.p4 / A3.Ex88--89: telescoping 2 sin(k pi/(2d)) sum_i cos(k theta_i), for integer 0<|k|<2d, proves the cosine sum vanishes; nonzero sine permits cancellation. It does not apply at k=0.
* p5 / Ex90--93: constant-coordinate entries and product-to-sum give the unweighted t outer-product sum. The j=k case contributes d, so it cannot be discarded with the nonzero-frequency rule.
* p6 / Ex94--95: E[gamma_i gamma_i^T]=I_r and the row/tensor identity give the unweighted Gram expectation. Inter-row independence is unnecessary for this expectation alone.
* p7 / Ex96--101: n=2q+1 makes every n +/- j +/- k a positive frequency, at most 4q+1<2d. A triple product-to-sum then gives the weighted t sum, which together with E[gamma_i gamma_i^T]=I_r gives the weighted Gram expectation. This is a distinct branch from p5's zero-frequency diagonal term.
* p8 / Ex102: |cos|<=1 gives ||t_i||^2=1+2 sum_(j=1)^q cos^2(j theta_i)<=1+2q<=2r.

C.6 controls both full r^2 by r^2 matrices simultaneously. Its source route is truncation AND bias/variance/norm estimates AND two matrix Bernstein applications AND event union bookkeeping; there is no alternative OR-route asserted in C.2.

* p10 / Ex104--105: chi-square exponential moment E exp(R_i/3)=3^(r/2), Markov's inequality, and L=2r+3 log(1000d) give the common truncation event T with probability >=.999.
* p11 / Ex106: the same tail bound and the tail-integral formula give E[R_i 1_(R_i>L)] <= (L+3)/(1000d).
* p12 / Ex107--110: Y_i=(gamma_i gamma_i^T tensor t_i t_i^T)1_(R_i<=L)/d; Gaussian radial symmetry makes E[gamma_i gamma_i^T 1_(R_i<=L)]=aI_r with the *same* a for all i. Thus 0<=a<=1, 1-a <=(L+3)/(1000rd), sum E Y_i=aI, while the weighted expectation is exactly zero. A weighted bias term need not be added: the source cancels it using the weighted cosine identity and the common scalar a.
* p13 / Ex111--112: centered Z_i=Y_i-EY_i have operator norm <=R_* =2r(L+1)/d; multiplication by the fixed cosine weight preserves this bound.
* p14 / Ex113--120: Gaussian fourth moments give E[R_i gamma_i gamma_i^T]=(r+2)I_r; PSD truncation removal, the rank-one square identities and C.5's t estimates give variance v_*=2r(r+2)/d for both sequences. Centering subtracts (E Y_i)^2, not an arbitrary norm equality.
* p15 / Ex121: the external two-sided bounded self-adjoint matrix Bernstein inequality is invoked without an explicit numbered citation in this C.2 paragraph. The source does not prove that theorem here. Its hypotheses are discharged by the preceding independence/centering/self-adjointness/norm/variance steps. The ambient matrix size produces prefactor 2r^2. This must remain an explicit external mathematical ingredient, not an axiom silently attached to the range identity or a compiler import rendered as proof implication.
* p16 / Ex122--124: z=log(1000r^2), Delta=sqrt(2v_*z)+2R_*z/3, direct algebra, and a union bound yield both centered inequalities with probability >=.996.
* p17 / Ex125--126: on T the truncated and original sums agree; the unweighted shift is -(1-a)I and the weighted shift is zero. Intersecting T and the centered event yields probability >=.995 and bounds Delta+(1-a), Delta.
* p18 / Ex127--128: integer 2q+1<d implies d>=2 and 2r<=d; therefore z=O(log d), L+3=O(r+log d), r+2<=3r. Absolute constant estimates absorb Delta+(1-a) into the one source tau. No kappa-dependent or sample-dependent constant is introduced.
* p19 / Ex129--132: the simultaneous matrix event AND the deterministic range representation AND norm-to-quadratic algebra AND tau<=1/2 give the uniform vector event. The numerical weakening .995>=.99 finishes the stated probability.

The source does not impose r^2 <= d as an independent premise. Indeed, the lemma's basic 2q+1<d permits r^2>d. A small Gram deviation with tau<1 forces injectivity on that event; this is a consequence, not permission to add a dimension premise to the source statement. When tau is not small, C.6's bound can be large and is not contradicted by rank deficiency.

## Boundaries to challenge later, without seeing a graph

1. The range equality needs the two-direction triangular generating-list argument, matrix-range/column-span correspondence, and nonzero scaling. Gaussian concentration, Haar rotation, Gaussian target moments and admissibility are context rather than necessary parent edges for that equality.
2. C.6 consumes specific C.5 moment/t identities, but does not consume C.5's range equality. C.5's range conjunct consumes no expectation or concentration conjunct. A graph may compress these behind a shared Fact only if drill-down preserves the true dependency split.
3. Final energy/weighted identities are deterministic matrix algebra. Their conjunction with range membership is distinct from the norm-event inputs that subsequently turn equalities into estimates.
4. Lemma 4.3 and external [22, Lemma 9.2] are used to apply the uniform theorem to the algorithm output (S4.Ex15), not to prove the standalone uniform theorem for independent Gaussian starts. Lemma 4.5 target moments and Lemma 4.6 admissibility are peer inputs for a later lower bound, not parents of C.5/C.6/4.4.
5. C.2 presents one sufficient route. A different algebraic or probabilistic route may be valid, but must be labeled as an alternative; it is not another jointly necessary conjunct of the author's proof. Source graph, actual compiled dependency graph, and conceptual/shared-mechanism overlay have distinct truth contracts.
6. The public binders must not assume the desired range equality, a polynomial-representation witness, a Gram concentration estimate, a good event, full rank, eigenbasis independence of the starts, or a uniform quadratic estimate solely because a producer theorem is planned. Such results belong inside proofs. A route-local conditional matrix-to-vector lemma may legitimately expose its own explicitly conditional hypotheses, but it does not thereby reproduce the unconditional source anchor.
7. The definitions K_q, B, t_i, gamma_i, D_n and tau are literal finite formulas on their public source carriers. A chosen coefficient witness, if later introduced, is an implementation choice that must be audited for existence and representative dependence; it is not an additional source definition.

## Coverage and epistemic limits

`coverage.json` assigns every selected source ID an explicit NODE or EXCLUDED disposition, including paragraph sub-IDs, theorem wrappers, equation-group/table/body IDs, and every math ID. Each mathematical element is associated with its source proof unit or an explicit contextual exclusion, with a raw pin. This is coverage bookkeeping only; counts do not certify mathematics, source completeness beyond the three sections, compilation, or novelty.

No Lean code was read, written or run; no API was searched; no candidate definitions, seals, SGs, verdicts, registry, frontier, ledger, Goal, STAB or publication artifacts were inspected or changed. No global ownership was acquired, no subagent spawned, and no detached/background work was used. No restricted ATLAS content, index or projection was accessed.

The model has ordinary pretrained mathematical knowledge (e.g. finite matrix algebra and the Chebyshev recurrence); it cannot attest that no source text occurred in pretraining. Independence here means the logged runtime exposure boundary, and not a claim to erase model weights. The asserted leading coefficients and counterexample above are independent mathematical reasoning, explicitly separated from what the source itself writes. The source extraction preserves original raw bytes for pins; it does not claim visual rendering QA of every MathML glyph.

Initial combined procedural-file stdout was truncated by the tool; that is recorded in `first_call_record.txt`. There were no shell/parser/read failures in the subsequent actual captures. Rerun captures are labeled as reruns and do not retroactively reconstruct the uncaptured original stdout. No mathematical verdict on a sealed candidate or proposed SG is issued at this stage. Phase 2 must first expose exact sealed statements and minimal meaning-carrying definitions, after which a second independent mathematical judgment will be frozen before any proposed graph is read.
