from pathlib import Path
import sys,json,hashlib,gzip,subprocess
sys.path.insert(0,'tools');import astis_advance as a;import astis_publication as p
ADV='ASTIS-SA-20261107-GaussianComplexityFixedSpectrumAdmissibility';OWNER='huanjian_gc_20261107_fixed_spectrum_admissibility_integration';DECL='AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumAdmissibility.actual_precision_admissible'
OUT=Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-admissibility-integration-20261107');sha=lambda b:hashlib.sha256(b).hexdigest()
assert not (OUT/'normal-stab-claim.json').exists()
branch=subprocess.check_output(['git','branch','--show-current'],text=True).strip();assert branch=='huanjian/gaussian-fixed-spectrum-admissibility-20261107'
subprocess.run(['git','merge-base','--is-ancestor','origin/main','HEAD'],check=True)
s=a.current_advances();assert s[ADV]['state']=='VERIFIED' and s[ADV]['owner_id']=='huanjian_gc_20261107_fixed_spectrum_admissibility';assert not [k for k,v in s.items() if v['state']=='STABILIZING']
p.check_advance([DECL],reviewed=True);item=next(x for x in p.load() if x['id']=='huanjian-fixed-spectrum-admissibility');assert p.binding_digest(item,item['bindings'][0])=='e4e245c817d124b16e93b4f999df81132f1e50a9e38535903cb5c036417c0e94'
planp=OUT/'independent-integration-reader-review/proposal/proposal-report.json';assert sha(planp.read_bytes())=='4aa865058b3c49a415e8e6d47c78da4885d90f5871d035d1cc79b0a46fbeb537';plan=json.loads(planp.read_bytes());assert len(plan['shared_paths'])==6
for f,h in plan['source_Test_lesson_publication_pins'].items():assert sha(Path(f).read_bytes())==h
ap=Path('research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-admissibility.json');audit=json.loads(ap.read_bytes());assert audit['state']=='accepted' and audit['source_review']['reviewer']=='/root/reader_742806'
ledger=Path('runs/substantive_advances.jsonl');before=ledger.read_bytes();db=Path('runs/substantive_discoveries.jsonl').read_bytes();z=OUT/'normal-stab-claim-ledger-prefix.jsonl.gz';z.write_bytes(gzip.compress(before,mtime=0));assert gzip.decompress(z.read_bytes())==before
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
a.transition_advance(ADV,to_state='STABILIZING',worker_id=OWNER,evidence={'canonical_branch':branch,'integration_owner':OWNER,'publication_declarations':[DECL],'accepted_source_V_first_carrying_commit':head,'accepted_audit_sha256':sha(ap.read_bytes()),'source_verifier':'/root/reader_742806','scope':'Exact independently reviewed six shared paths only; one canonical precision-admissibility producer/Registry node. GaussianPrecisionDensity canonical same-A Test reuse is not a producer parent. Both graph model files unchanged, no new mirror or oracle binding. Real root/site/graph/Chrome acceptance still pending; all foreign queues and frozen Bench preserved.'})
after=ledger.read_bytes();now=a.current_advances();assert after.startswith(before) and len(after[len(before):].splitlines())==1 and all(now[k]==v for k,v in s.items() if k!=ADV) and Path('runs/substantive_discoveries.jsonl').read_bytes()==db
r={'branch':branch,'owner':OWNER,'accepted_metadata_first_carrying_commit':head,'before_sha256':sha(before),'after_sha256':sha(after),'exact_prefix_preserved':True,'append_events':1,'append_sha256':sha(after[len(before):]),'foreign_states_preserved':len(s)-1,'state':now[ADV]['state'],'single_lane':[k for k,v in now.items() if v['state']=='STABILIZING'],'new_source_verdict':False}
(OUT/'normal-stab-claim.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
