"""Generate new exact-seal applications and adapt only the prior lossless DAG mechanism."""
import json
import re
from native_common import *

def main():
    assert not (OWN / 'native-command-assignment.json').exists()
    closure = json.loads((OWN / 'actual-import-closure.json').read_text())
    packages = json.loads((OWN / 'verified-package-inputs.json').read_text())
    assert packages['candidate_commit'] == closure['candidate_commit'] == COMMIT
    seal = json.loads((OWN / 'immutable-inputs/statement-seal.sealed.v1.json').read_text())
    p = (OWN / 'immutable-inputs/P.proposition.sealed.v1.txt').read_text().strip()
    t = (OWN / 'immutable-inputs/T.proposition.sealed.v1.txt').read_text().strip()
    checks = []
    for role, proposition in [('P', p), ('T',t)]:
        source = (CAND / seal[role]['proposed_file']).read_text()
        name = seal[role]['proposed_declaration'].split('.')[-1]
        m = re.search(r'\btheorem\s+' + name + r'\b(.*?)\s*:=\s*by', source, re.S)
        assert m
        if role == 'T':
            assert m.group(1).strip() == ':\n' + proposition
        checks.append({'role':role, 'source_sha256':file_sha(CAND / seal[role]['proposed_file']), 'sealed_literal_sha256':sha((proposition+'\n').encode()), 'source_declaration_signature':m.group(1), 'exact_kernel_type_check_in_command':'raw-kernel-audit'})
    harness = OWN / 'harness'
    harness.mkdir(exist_ok=True)
    text = '''import Tests.GaussianComplexityLaplaceTail
import Lean
open MeasureTheory ProbabilityTheory Lean Elab Term
open scoped BigOperators Matrix.Norms.L2Operator MatrixOrder ENNReal
noncomputable section
universe u v
elab "native_actual_T" : term => do
  let env ← getEnv
  let found := env.constants.toList.filter fun (n, _) =>
    n.toString.endsWith ".actual_source_four_sums_laplace_tail"
  unless found.length == 1 do throwError "Expected exactly one actual private T, found {found.length}"
  return mkConst found.head!.1
namespace NativeLiteralApplications

'''
    text += 'theorem literal_P :\n' + p + ' := by\n  intro Ω inst μ instμ ι instι instDec instNon X hX hherm t\n  exact ' + seal['P']['proposed_declaration'] + ' μ X hX hherm t\n\n'
    text += 'theorem literal_T :\n' + t + ' := by\n  intro d q hq\n  exact native_actual_T hq\n\n'
    body = t.split('\n',1)[1]
    body_q0 = re.sub(r'\bq\b','0',body)
    body_d2 = re.sub(r'\bd\b','2',body_q0)
    text += 'theorem literal_T_q0 {d : ℕ} (hd : 1 < d) :\n' + body_q0 + ' := by\n  exact native_actual_T (d := d) (q := 0) hd\n\n'
    text += 'theorem literal_T_q0_d2 :\n' + body_d2 + ' := by\n  exact native_actual_T (d := 2) (q := 0) (by norm_num)\n\n'
    # Each exact let-chain remains intact; specialize only the two finite switches.
    for use_cos, minus in [(False,False),(False,True),(True,False),(True,True)]:
        label = ('cos' if use_cos else 'ordinary') + ('_negative' if minus else '_positive')
        clause = body_d2.replace('∀ useCos minus : Bool,', 'let useCos := ' + str(use_cos).lower() + '; let minus := ' + str(minus).lower() + ';')
        text += 'theorem family_' + label + ' :\n' + clause + ' := by\n  intro s hs a\n  exact native_actual_T (d := 2) (q := 0) (by norm_num) s hs a ' + str(use_cos).lower() + ' ' + str(minus).lower() + '\n\n'
    text += 'end NativeLiteralApplications\n'
    for n in ['literal_P','literal_T','literal_T_q0','literal_T_q0_d2','family_ordinary_positive','family_ordinary_negative','family_cos_positive','family_cos_negative']:
        text += '#print axioms NativeLiteralApplications.' + n + '\n'
    (harness / 'NativeLiteralApplications.lean').write_text(text)
    # Mechanism reuse only: serializers, structural decoder, kernel checks.
    mechanism = REPO / '.astis/semantic-neutral-20261114/weighted_mgf_native_8c2d/harness/NativeAudit.lean'
    kernel = mechanism.read_text().replace('Tests.GaussianComplexityBernsteinWeightedMgf','Tests.GaussianComplexityLaplaceTail').replace('NativeAudit8c2d','NativeAudit61e4')
    kernel = kernel.replace(str(mechanism.parent.parent),str(OWN))
    kernel = kernel.replace('AutoSamplingTheory.TechnicalLemmas.Probability.MatrixBernsteinMgf.centered_bounded_matrix_mgf',seal['P']['proposed_declaration'])
    kernel = kernel.replace('.actual_source_weighted_normalized_single_summand_mgf','.actual_source_four_sums_laplace_tail')
    kernel = kernel.replace('4869db55d340cee39f0ba4d49fb0a7a4309ba2d6',COMMIT)
    module_text = 'def modules : Array String := #[\n  ' + ',\n  '.join(json.dumps(m) for m in closure['topological_order'] + ['NativeLiteralApplications']) + ']\n\n'
    kernel,n = re.subn(r'def modules : Array String := #\[.*?\]\s*\n(?=def atJ)',module_text,kernel,count=1,flags=re.S)
    assert n == 1
    (harness / 'NativeAudit.lean').write_text(kernel)
    write_json(OWN / 'mechanism-provenance.json', {'source_path':str(mechanism), 'source_sha256':file_sha(mechanism), 'mechanism_only':True, 'prior_receipts_or_verdicts_read_or_reused':False, 'current_harness_sha256':file_sha(harness/'NativeAudit.lean')})
    write_json(OWN / 'literal-source-interface.json',{'candidate_commit':COMMIT,'targets':checks, 'actual_value_rechecked_against_literal_type': 'pending raw-kernel-audit', 'T_private':True})
    assert not OUT.exists()
    OUT.mkdir()
    env = lean_env(packages['packages'])
    commands = [{'id':'lean-version', 'argv':[str(LEAN),'--version'], 'cwd':str(CAND), 'env':env}]
    for n,module in enumerate(closure['topological_order']):
        relative = module.replace('.','/')
        commands.append({'id':f'build-{n:02d}', 'argv':[str(LEAN),'-DmaxRecDepth=16384','-DmaxHeartbeats=0','-Ddebug.skipKernelTC=false','-o',str(OUT/(relative+'.olean')),relative+'.lean'], 'cwd':str(CAND), 'env':env})
    commands.append({'id':'literal-applications','argv':[str(LEAN),'-DmaxRecDepth=16384','-DmaxHeartbeats=0','-Ddebug.skipKernelTC=false','-o',str(OUT/'NativeLiteralApplications.olean'),str(harness/'NativeLiteralApplications.lean')], 'cwd':str(harness), 'env':env})
    commands.append({'id':'raw-kernel-audit','argv':[str(LEAN),'-DmaxRecDepth=32768','-DmaxHeartbeats=0','-Ddebug.skipKernelTC=false','--run',str(harness/'NativeAudit.lean')], 'cwd':str(harness), 'env':env})
    write_json(OWN/'native-commands.json',commands)
    inputs = [p for p in CAND.rglob('*') if p.is_file()] + [p for p in (OWN/'immutable-inputs').iterdir() if p.is_file()] + list(harness.iterdir())
    inputs += [OWN / n for n in ['actual-import-closure.json','verified-package-inputs.json','native_common.py','run_native.py','freeze.py','native-commands.json']]
    write_json(OWN/'native-command-assignment.json',{'candidate_commit':COMMIT,'root_assignment':'explicit parent immutable proof-only native audit task','inputs':[{'path':str(p.relative_to(OWN)),'sha256':file_sha(p)} for p in inputs], 'initial_ASTIS_output_empty':not any(OUT.iterdir()),'source_ASTIS_modules':len(closure['topological_order']), 'native_command_count':len(commands)})
    print(json.dumps({'commands_frozen':len(commands),'source_modules':len(closure['topological_order'])}))

if __name__ == '__main__': main()
