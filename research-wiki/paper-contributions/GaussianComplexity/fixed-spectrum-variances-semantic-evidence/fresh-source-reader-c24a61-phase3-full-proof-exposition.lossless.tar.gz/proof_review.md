# Independent source, proof, and exposition review at b8810598

The reviewed candidate is `b881059811fb9bcd8d81f60e6bc7cc85498fc2d7`. The complete production module has SHA-256 `c2a546926e439e3ed985bb6a64a5be647e5320750c3ef75fd20e49c8c63c1060`; the complete Test module has SHA-256 `9f3d872f0719d7cccf314affcb79c4322e409bb213de0284850f56bc8035a8d5`. Their working bytes equal their bytes at that commit. The canonical reviewer packet hash recomputes to `0a53fd8039a1e1254bedce1508bd9fd94f378724e2c8d79cf57cab675f1701fe`, and the current publication binding independently recomputes to `8bdbee09a451232660a793e46b50337c0e7941a8b069afe32839a23756a0a189` using the exact whole module, toolchain, dependency manifest, source/publication fields, full authored lesson, and current binding fields.

My Phase 1 raw-source cognition and Phase 2 statement judgment were frozen before this implementation or its exposition was opened. The Phase 2 freeze remains `1fcf2ffc915e6010d6a813e7d3d8f7cd2e8b942eddc76b400c20290300c28e36`. The production statement equals the canonical statement after whitespace normalization; the private Test statement likewise equals the exact private statement reviewed in Phase 2. The full module contains no additional scoped mathematical inputs. No older implementation, canonical prior source judgment, or concurrent independent reader output was opened.

## Judgment and scope

The current proof and authored exposition support the source variance slice reviewed in Phase 2: the actual diagonal Gaussian's two L2 facts, two exact quadratic variance formulas, two bounds by 2M, and the bound 2M<=2d/sqrt(kappa). No blocking source-fidelity delta was found. The appropriate proposed semantic verdict is `equivalent-after-elaboration`, with the semantic audit state proposed as `source-reviewed` and its independent source-review substate as `accepted`. This is an unapplied field proposal; no canonical audit, sourceV, frontier, ledger, or normal VERIFIED transition was performed.

The private Test theorem proves a generalized numerical L2/variance claim for real 0<=tau<=1/2. Its covariance-positivity/Young proof is a valid route variant at the source's common bound 2M. It is not a compiled general Minkowski theorem or a literal reproduction of every source proof step. Its exact scope excludes the mean clause of Ex25, the probability estimate, the rotated target-law identification, the concrete threshold/mode, and all sampling lower bounds.

The canonical packet's `compiled=true` field is a supplied assertion, not a build receipt produced by this review. I ran no Lean, native, global, site, browser, or OS acceptance check. A distinct completed native/static reader's evidence can be bound later without changing this run's account of what was done.

## Actual law and scalar analytic branches

Production lines 45–62 use the same literal local definitions and only the source's d>=2, kappa>=2, and 1<=n<d inputs. The law is `multivariateGaussian 0 Lambda^{-1}` on standard EuclideanSpace. Under the Mathlib definition read at its pinned dependency commit, the matrix is covariance. A non-PSD argument would produce the totalized fallback, so the PSD branch must genuinely be proved.

Production lines 78–108 do this work. `heigenlower` proves lambda_i>=1 from the cosine lower bound, `heigenpos` and `hLambdaPos` prove positive definiteness, and `hinv` proves the exact diagonal reciprocal inverse using a checked left inverse. The actual covariance Lambda^{-1} is positive definite and hence PSD. The coordinate projection is measure-preserving to the centered scalar Gaussian with variance `(lambda_i^{-1}).toNNReal`; positivity makes its real value the genuine reciprocal. Both the scalar L2 conclusion and scalar square-variance identity are transferred along this actual pushforward. No law callback or PSD/moment witness is an input binder.

The two private production helpers at lines 24–43 have distinct purposes. The L2 helper uses Gaussian exponential integrability at zero and the general integrable-power API to establish integrability of x^4, then applies the actual L2-square equivalence. The scalar variance helper obtains E G^2=v from the scalar variance and zero mean, uses the L2-guarded variance subtraction theorem, and materially calls the existing canonical `GaussianFourthMoment.integral_pow_four_gaussianReal_zero`. The shared provider's complete 93-line module was read: it differentiates the Gaussian MGF four times and uses the moment/derivative theorem at zero. Its domain includes zero scalar variance, and the private adapters preserve that domain. The current production file contains no duplicate fourth-moment implementation.

The order differs slightly from the source prose: scalar square variance is computed first, then transported to an actual coordinate, rather than emitting a separate actual-coordinate fourth-moment equality before variance subtraction. The actual Gaussian pushforward supplies the semantic bridge. No new standalone coordinate fourth-moment API or proof credit is claimed. Likewise lambda_i<=kappa, d>0, and kappa-1>0 are source-domain consequences bundled into a broad source-graph node, but are not separately emitted new facts by this chosen variance implementation; the source-to-Lean map states this narrowing explicitly.

## Independence, finite sums, and both exact formulas

Production lines 109–117 establish joint Gaussianity of the actual coordinate family by transporting the identity Gaussian through the EuclideanSpace-to-Pi continuous linear equivalence. The covariance API is applied to the proved PSD inverse matrix, and `hinv` makes its off-diagonal entries zero. The jointly Gaussian zero-covariance criterion then produces actual coordinate independence. These are derived facts about this measure, not supplied family assumptions.

Lines 118–142 prove a weighted-square result for every finite real weight vector. Each weighted square is L2 by scaling the actual coordinate-square L2 fact. Measurable weighted squaring of independent coordinates supplies pairwise independence of the actual summands. `memLp_finsetSum` proves the sum is L2, and `IndepFun.variance_sum` consumes every individual L2 fact and pairwise independence witness. The function-valued finite sum is explicitly identified with its pointwise form. Scaling the scalar square variances gives the exact coefficient `2 sum_i a_i^2/lambda_i^2`.

Lines 143–148 identify the Euclidean squared norm with the coordinate-square sum and specialize weights to one and cosine. This produces both exact variance formulas and both explicit L2 conclusions. Q itself is the literal diagonal coordinate formula; no separate emitted matrix-polynomial or orthogonal-transport theorem is claimed. The source formula x^T D_n x and this coordinate sum have the same diagonal meaning, but the full S_A(Y) identification remains outside the theorem.

The real variance convention is not exploited to close a false finite-variance claim: both square-L2 inputs and both sum-L2 outputs are genuine. The inspected `MemLp.evariance_ne_top` theorem makes finite evariance a standard consequence on a finite measure; the production code need not emit an extra call to that consequence. Its variance subtraction/addition APIs are themselves used with actual L2 hypotheses. This distinguishes an available mathematical implication from a separately emitted Lean dependency.

## The two mean branches

Lines 149–168 materially use the existing actual Gaussian mean theorem's M clause. That exact shared 103-line module was read: it proves coordinate-square integrability and second moments for the same literal law, then integrates the finite norm-square sum. The projection `.2.2.1` in the variance proof is the actual squared-norm integral identity, not an assumed or invented M. Reciprocal nonnegativity, reciprocal<=1, and cos^2<=1 compare each inverse-square term with the corresponding reciprocal. These inequalities and the actual M identity give each <=2M conclusion.

The final dimension bound has a separate dependency. Production lines 169–185 call the existing actual exact-means declaration and select its M clause. The exact shared 436-line module and its public API were read. It uses the actual mean bridge, inverse-spectrum cosine series, finite-grid aliasing, absolute-summability exchange, and geometric sums; the used M formula has the source's `(1-r^{2d})/(1+r^{2d})` sign and denominator. The two directly used upstream source APIs were inspected at their current exact signatures; their older source reviews were not read or renewed by this run.

In the current variance proof, kappa>=2 yields sqrt(kappa)>1 and r>0; then r^{2d}>=0, the denominator is positive, and the ratio is <=1. A nonnegative scale d/sqrt(kappa) gives M<=d/sqrt(kappa). This is not inferred from the variance identities. It does not require d-n>=sqrt(kappa), beta, a query bound, or a sufficiently-large-d premise.

## The private Test theorem and its source route variant

The complete Test module is an actual theorem proof with the exact Phase 2 domain. Lines 40–43 call the new public theorem and destructure precisely the two L2 outputs and the two <=2M bounds, discarding its exact variance formulas and dimension bound. Both L2 outputs enter the L2 proof for Z. Both 2M bounds enter the signed-Q bound and cross-term calculation.

Let N be the squared norm and X=(-1)^n Q. Lines 44–50 prove the sign square is one and Var X=Var Q; no oddness assumption is needed. Line 51 derives M>=0 from Var N>=0 and Var N<=2M. This uses a proved finite variance comparison and agrees with the nonnegative actual integral; it is not a square-root default argument.

Lines 54–57 use actual L2 to expand the nonnegative variance of X+N, obtaining

`-2 Cov(X,N) <= Var X + Var N <=4M`.

Lines 58–65 expand Var(X-2tau N), with actual scaled N still L2. Lines 66–74 multiply the cross-term inequality by nonnegative 2tau and the N variance bound by nonnegative 4tau^2, then derive

`Var Z <= 2M + 8tau M + 8tau^2 M = 2M(1+2tau)^2`.

Finally 0<=tau<=1/2 bounds the last square by 4, and M>=0 gives Var Z<=8M. No independence between the whole observables Q and N is asserted or needed.

The source takes the L2 triangle of centered random variables and inserts the common bound 2M. At M>=0 its resulting expression `(sqrt(2M)+2tau sqrt(2M))^2` equals `2M(1+2tau)^2`. Thus the implementation proves exactly the needed common-bound intermediate estimate through a different centered L2/Young calculation. It does not prove the fully general bound `(sqrt(Var X)+2tau sqrt(Var N))^2`, and the source graph must not be relabeled as a compiled general-Minkowski certificate. The current source-to-Lean map explicitly says this; the current lesson's final step explains the covariance route and the private scope accurately.

For a later source application, n=2q+1, tau=tau_{d,q}, its nonnegative/small-threshold guards, orthogonal target-law transport, and Chebyshev matrix-polynomial identity must be proved at the use site. Tau<=beta/4 belongs to the mean clause, M beta^2>=320 to the target probability, and the gap d-n>=sqrt(kappa) to the bias estimate. The private Test theorem proves none of these facts and introduces none into the public Anchor.

## Source graph, map, and authored exposition

The supplied graph is source topology with 38 nodes and 31 AND routes, not a Lean certificate. All 38 node IDs have explicit entries in the current source-to-Lean map, and the map's source-graph hash matches the exact v2 graph bytes. The 30 selected raw units retain both A3.Ex148 and A3.Ex149, the M-upper paragraph, both original law/definition domains, and the private variance clause with its contextual guards. The excluded mean/bias/algorithm parts remain outside this selected result. The graph's inherited raw-first/extraction and classification-history claims were not used as mathematical proof or as a prior source-fidelity verdict.

The source-only minimal consumer closure properly needs both L2 and both <=2M outputs, while not requiring the closed-M dimension upper output. The actual Lean consumer calls the bundled public producer, so its actual Lean dependency transitively includes that producer's exact-mean branch. These two dependency questions must remain distinct.

The full current lesson and publication were read and match their b881 commit bytes. Every one of the six folded Lean blocks is an exact substring of the current production module, except the final block, which equals the entire current Test module. The packet's lesson differs from the current full lesson only by omission of its `boundary` field, exactly as the review-context exporter is defined to filter it; all mathematical statement, formula, assumptions, steps, sources, dependencies, and tests match. The full current boundary and publication binding explicitly keep the broader source and delivery obligations open. No text claims a source-wide result from the private tau helper.

## Holds and residuals

There is no blocking source-fidelity or proof/exposition HOLD for the selected variance result or the separately labeled private numerical route variant. There is an execution-evidence HOLD on any normal VERIFIED/build claim from this run: no native/static execution receipt was produced or inspected here. The separately completed independent reader's exact-candidate evidence may be added as a later binding without pretending it was rerun by me.

Full Lemma 4.5, its exponential bias/log estimates, rotated target-law transport, concrete query threshold/mode, uniform Krylov/concentration/adaptive-history laws, exact oracle/TV/deterministic query caps, expected-cost adapters, and the main lower bounds remain outside this acceptance. Global/site/browser/OS delivery, serialized integration, purification, and an Exposition Seal are also outside this run. No source repair is independently required, so the proposal deliberately leaves any existing repairs field untouched.
