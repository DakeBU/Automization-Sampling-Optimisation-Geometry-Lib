"""Minimal source-only successor for TC-B1; all previous artifacts immutable."""
from pathlib import Path
from copy import deepcopy
from datetime import datetime,timezone
import hashlib,json

REPO=Path('/Users/zhouhuanjian/ASTIS-GC')
OWN=Path(__file__).parent
P1=OWN.parent
P2=P1/'phase2'
FB=REPO/'.astis/semantic-neutral-20261110/d_tc_91b6e4/phase2b'
sha=lambda b:hashlib.sha256(b).hexdigest()
def dump(name,data):
    (OWN/name).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')

feedback_expected={
 'topology-challenge-report.md':'36a04ed23b445832d63f154f525ec766324f9458cb9c7de1636f67fd0921464e',
 'verdict.json':'63b4657ec13995fc5d6361a4f2265a339c4c43025b35e83da087d244c225ac95',
 'edge-closure-evidence.json':'a47d35aa22256474affbbede5de80bdb7c393f77cbc86ff7e05bd2f7dd874420',
 'manifest.json':'9a76d64794d7d98c2f9cb97e04f93ebbaf1c966bfa4f8bffe60bb22f38e2e2f2'}
feedback=[]
for name,h in feedback_expected.items():
    b=(FB/name).read_bytes();assert sha(b)==h
    feedback.append({'path':str((FB/name).relative_to(REPO)),'bytes':len(b),'sha256':h,
                     'read_scope':'Hash/list metadata only; contents not semantically opened' if name=='manifest.json' else 'Authorized frozen mathematical feedback only'})

def verify_previous(directory,manifest_name,expected):
    b=(directory/manifest_name).read_bytes();assert sha(b)==expected
    m=json.loads(b)
    for f in m['files']:
        p=directory/f['file'];assert sha(p.read_bytes())==f['sha256']
    return {'manifest':str((directory/manifest_name).relative_to(REPO)),'sha256':expected,'all_recorded_files_unchanged':True}

preserved=[
 verify_previous(P1,'phase1_manifest.json','71d3bf703026ca41943bf19af1212a1eabfd72c02a6d1fe2fe72b8d7c11521cc'),
 verify_previous(P2,'phase2_manifest.json','030c8a767d484f3058e241df7819ab11100a6527c87585dfbf9055333852a8e1')]
oldb=(P1/'source_graph.json').read_bytes();oldsha=sha(oldb)
assert oldsha=='2d47aa63ead6a81895dd7f81e0a3f854ec9c5041a42dc4d48faa66687ccfe2c1'
old=json.loads(oldb);new=deepcopy(old)
edge_index=next(i for i,e in enumerate(new['hyperedges']) if e['id']=='e:target-L2')
node_index=next(i for i,n in enumerate(new['nodes']) if n['id']=='br:polynomial-conjugation')
edge=new['hyperedges'][edge_index];producer=new['nodes'][node_index]
assert edge['consumer']=='sg:target-L2'
assert 'br:polynomial-conjugation' not in edge['premises']
assert all(c['consumer']!='sg:target-L2' for c in producer['consumer_uses'])
consumed={'producer':'br:polynomial-conjugation',
 'consumed_output':'Replace T_n(B) in Z=S_A(Y) by O D_n O^T before applying the target cosine quadratic-form mean and variance.'}
backlink={'edge':'e:target-L2','consumer':'sg:target-L2','use_site':edge['consumer_use_site'],'logic':edge['logic']}
edge['premises'].append('br:polynomial-conjugation')
edge['output_consumption'].append(consumed)
producer['consumer_uses'].append(backlink)
dump('source_graph_v2.json',new)
newsha=sha((OWN/'source_graph_v2.json').read_bytes())

operations=[
 {'op':'add','path':f'/hyperedges/{edge_index}/premises/-','value':'br:polynomial-conjugation'},
 {'op':'add','path':f'/hyperedges/{edge_index}/output_consumption/-','value':consumed},
 {'op':'add','path':f'/nodes/{node_index}/consumer_uses/-','value':backlink}]
delta={
 'kind':'MINIMAL_PRESERVED_SOURCE_GRAPH_SUCCESSOR','version':'v2','addresses_finding':'TC-B1',
 'base_graph':str((P1/'source_graph.json').relative_to(REPO)),'base_sha256':oldsha,
 'successor_graph':'source_graph_v2.json','successor_sha256':newsha,
 'exact_json_patch_operations':operations,
 'source_use_site':['S4.SS3.SSS0.Px2.p3.1','S4.Ex25'],
 'source_recheck':{
  'raw_source_sha256':'6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915',
  'full_paragraph_display_blocks_reread':['S4.SS3.p3','S4.SS3.p4','S4.SS2.SSS0.Px3.p2','S4.SS3.SSS0.Px2.p3'],
  'reason':'The literal definition of S_A uses the matrix Chebyshev polynomial. At Ex25 the author sets Z=S_A(Y) and uses cosine-form means/variances, so the existing polynomial-conjugation bridge is consumed at this step. The existing target-coordinate-transfer node alone gives the rotated cosine form, not the polynomial identity.'},
 'classification':'Graph-extraction dependency omission; no source or exact-signature refutation.',
 'not_changed':[
  'All previous frozen files, hashes and old HOLD record',
  'All node identities, source coverage dispositions and other hyperedge records',
  'Exact producer/consumer signatures, definitions and meanings',
  'Phase2 exact local overlay and its two conjunctive branches',
  'Source n=2q+1 and tau=tau_(d,q); full O and strict-zero semantics',
  'All existing unproved standard/law/probability/algorithm/TV/cost boundaries'],
 'not_added':['No normalized energy-geometry premise','No MAIN/public binder','No theorem or proof claim','No independent acceptance status'],
 'independent_rereview':'PENDING; original independent actor must challenge successor; old HOLD remains a historical frozen finding.'
}
dump('exact_delta_tc_b1.json',delta)

# Machine checks only certify the requested JSON mutation and graph ancestry.
expected=deepcopy(old)
expected['hyperedges'][edge_index]['premises'].append('br:polynomial-conjugation')
expected['hyperedges'][edge_index]['output_consumption'].append(consumed)
expected['nodes'][node_index]['consumer_uses'].append(backlink)
assert new==expected
assert len(new['nodes'])==len(old['nodes']) and len(new['hyperedges'])==len(old['hyperedges'])
def ancestors(graph,target):
    reverse={}
    for e in graph['hyperedges']:reverse.setdefault(e['consumer'],set()).update(e['premises'])
    seen=set();todo=list(reverse.get(target,[]))
    while todo:
        a=todo.pop()
        if a in seen:continue
        seen.add(a);todo.extend(reverse.get(a,[]))
    return seen
before=ancestors(old,'sg:target-L2');after=ancestors(new,'sg:target-L2')
assert 'br:polynomial-conjugation' not in before and 'br:polynomial-conjugation' in after
assert 'sg:energy-geometry' not in after
assert after-before=={'br:polynomial-conjugation'}
expected_links={(p,e['id'],e['consumer'],e['consumer_use_site'],e['logic'])
 for e in new['hyperedges'] for p in e['premises']}
actual_links={(n['id'],c['edge'],c['consumer'],c['use_site'],c['logic'])
 for n in new['nodes'] for c in n['consumer_uses']}
assert actual_links==expected_links
checks={'status':'ARTIFACT_DIFF_AND_ANCESTRY_ONLY','exact_three_append_operations_only':True,
 'previous_freezes':preserved,'base_node_and_edge_identities_unchanged':True,
 'coverage_inventory_unchanged':True,'target_L2_new_ancestors':sorted(after-before),
 'polynomial_conjugation_reaches_target_L2':True,'normalized_energy_geometry_is_not_target_L2_ancestor':True,
 'all_consumer_use_backlinks_match':True,
 'mathematical_proof_or_independent_topology_acceptance':False,'independent_rereview':'PENDING'}
dump('artifact_diff_and_ancestry_checks.json',checks)

packet={
 'purpose':'Independent rereview of the original extractor minimal TC-B1 successor; no implementation proof.',
 'finding':'TC-B1','candidate_successor_sha256':newsha,
 'reviewer_exact_read_whitelist':[
  {'path':'.astis/huanjian-resume-20261103/2610.20492v1.html','sha256':'6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915',
   'required_scope':'S4.SS3.p3, S4.SS3.p4, S4.SS2.SSS0.Px3.p2, S4.SS3.SSS0.Px2.p3; original previously authorized selected slice remains available'},
  {'path':str((P1/'source_graph.json').relative_to(REPO)),'sha256':oldsha},
  {'path':str((OWN/'source_graph_v2.json').relative_to(REPO)),'sha256':newsha},
  {'path':str((OWN/'exact_delta_tc_b1.json').relative_to(REPO))},
  {'path':str((OWN/'artifact_diff_and_ancestry_checks.json').relative_to(REPO)),'scope':'Artifact checks only; independently recompute mathematical closure'},
  {'path':str((P1/'coverage_inventory.json').relative_to(REPO)),'sha256':'63f9a219a6b0d20cbe40acfcdae91f4049c4666363fbfddc48e0f0f4285e377a'},
  {'path':str((P1/'standard_bridges.json').relative_to(REPO)),'sha256':'f61b903f2aaa76ec0b23f059683528c0513b1ab3695ebf68cb0a431f8119b4c2'},
  {'path':str((P2/'source_graph_overlay_v1.json').relative_to(REPO)),'sha256':'a71c6d355c792971abca484dbf784be6cbdf897a1a199e802d26c8b7ecca170d','scope':'Unchanged historical overlay; old base-graph hash reference preserved. Source IDs/meanings unchanged in v2.'},
  {'path':str((P2/'target_binding.json').relative_to(REPO)),'sha256':'a07abce2a0633ed52d68cec12672d83ac7229151468361548827d3208b453bbd'},
  {'path':str((P2/'exact_types/producer-signature.txt').relative_to(REPO)),'sha256':'c1abe1c57e12337dc3592297e624edd757deb18f9eae17ecdc9faca40e2609f4'},
  {'path':str((P2/'exact_types/consumer-signature.txt').relative_to(REPO)),'sha256':'364843a1d3e581a3b9498eed483b0dff44faad722a67d90c46566da038fc4d2e'},
  *[{'path':f['path'],'sha256':f['sha256'],'scope':f['read_scope']} for f in feedback]
 ],
 'challenge':[
  'Does the new e:target-L2 premise consume the exact polynomial-conjugation output needed before applying cosine-form target moments to Z=S_A(Y)?',
  'Does br:polynomial-conjugation have the exact matching consumer-use backlink?',
  'Are there exactly the three append operations and no signature/definition/coverage/other-edge mutation?',
  'Is normalized energy geometry still explanatory rather than a forced necessary premise?',
  'Are all unproved standard inputs and unfinished law/probability/algorithm/TV/cost boundaries retained?'],
 'withheld':['All actors raw cognition','All private/conclusive process or exposure notes','root plans/history','implementation Lean/Tests','Any new library/API proof material'],
 'authority':'Original HOLD remains frozen. Only the distinct reviewing actor may issue the successor topology verdict; no proof credit from this packet.',
 'status':'CANDIDATE_SUCCESSOR_AWAITING_INDEPENDENT_REREVIEW'
}
dump('successor_reviewer_packet.json',packet)
dump('actual_input_whitelist_and_exposure.json',{
 'role':'Original source extractor, minimal successor after independent feedback',
 'new_authorized_inputs':feedback,
 'raw_source_reread':delta['source_recheck'],
 'existing_knowledge':'Own frozen source graph/coverage/bridge/type/overlay artifacts only; previous freezes byte-verified without editing.',
 'additional_exposure':'Authorized mathematical HOLD report/verdict/edge evidence only; no topology raw cognition or root process/plan/implementation read.',
 'new_library_searches':False,'Lean_or_API_experiment':False,
 'mutation_scope':str(OWN.relative_to(REPO)),'previous_freezes':preserved,
 'result_boundary':'Three graph append operations; all proof/status claims remain unasserted.'})
print(json.dumps({'successor_sha256':newsha,'old_graph_sha256':oldsha,'exact_delta_operations':3,
 'new_target_L2_ancestor':sorted(after-before),'independent_rereview':'PENDING','proof_credit':False}))
