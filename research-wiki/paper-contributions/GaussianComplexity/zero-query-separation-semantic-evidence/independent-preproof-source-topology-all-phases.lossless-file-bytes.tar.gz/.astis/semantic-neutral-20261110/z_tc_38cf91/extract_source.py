from pathlib import Path
from html.parser import HTMLParser
from html import unescape
import hashlib, json

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT.parents[1] / 'huanjian-resume-20261103/2610.20492v1.html'
raw = SOURCE.read_bytes()
assert len(raw) == 951991
assert hashlib.sha256(raw).hexdigest() == '6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
text = raw.decode('utf-8')
targets = ['S2', 'S3.p1', 'S3.Thmtheorem1', 'S3.p2', 'S3.SS3.p1', 'S3.SS3.SSS0.Px1']

class Regions(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=False)
        self.stack=[]
        self.regions={}
        self.lines=[0]
        self.lines += [i+1 for i,c in enumerate(text) if c=='\n']
    def pos(self):
        line,col=self.getpos()
        return self.lines[line-1]+col
    def handle_starttag(self,tag,attrs):
        if tag in {'area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr'}:
            return
        self.stack.append((tag,dict(attrs).get('id'),self.pos()))
    def handle_startendtag(self,tag,attrs):
        pass
    def handle_endtag(self,tag):
        if not self.stack or self.stack[-1][0]!=tag:
            raise ValueError((tag,self.stack[-3:]))
        _,ident,start=self.stack.pop()
        if ident in targets:
            stop=text.index('>',self.pos())+1
            self.regions[ident]=(start,stop)

class Readable(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.parts=[]
        self.math_depth=0
    def handle_starttag(self,tag,attrs):
        if self.math_depth:
            self.math_depth+=1
        elif tag=='math':
            self.parts.append(' $'+dict(attrs).get('alttext','')+'$ ')
            self.math_depth=1
        elif tag in {'p','h2','h3','h4','h5','table','li','dt','dd'}:
            self.parts.append('\n')
    def handle_endtag(self,tag):
        if self.math_depth:
            self.math_depth-=1
        elif tag in {'p','h2','h3','h4','h5','table','li','dt','dd'}:
            self.parts.append('\n')
    def handle_data(self,s):
        if not self.math_depth:
            self.parts.append(s)
    def view(self):
        return '\n'.join(' '.join(line.split()) for line in ''.join(self.parts).splitlines() if line.strip())+'\n'

class MathInventory(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=False)
        self.items=[]
        self.current=None
        self.annotation=False
    def handle_starttag(self,tag,attrs):
        attrs=dict(attrs)
        if tag=='math':
            self.current={'id':attrs.get('id'),'alttext_decoded':attrs.get('alttext'),'original_start_tag':self.get_starttag_text(),'annotations':[]}
        elif tag=='annotation' and self.current is not None:
            self.annotation=True
            self.current['annotations'].append({'encoding':attrs.get('encoding'),'text':''})
    def handle_endtag(self,tag):
        if tag=='annotation':
            self.annotation=False
        elif tag=='math' and self.current is not None:
            self.current['alttext_matches_tex_annotation']=all(self.current['alttext_decoded']==a['text'] for a in self.current['annotations'] if a['encoding']=='application/x-tex')
            self.items.append(self.current)
            self.current=None
    def handle_data(self,s):
        if self.annotation and self.current is not None:
            self.current['annotations'][-1]['text']+=s
    def handle_entityref(self,s):
        self.handle_data(unescape('&'+s+';'))
    def handle_charref(self,s):
        self.handle_data(unescape('&#'+s+';'))

parser=Regions()
parser.feed(text)
assert set(parser.regions)==set(targets)
manifest={'source_path':str(SOURCE),'source_bytes':len(raw),'source_sha256':hashlib.sha256(raw).hexdigest(),'regions':[]}
for ident in targets:
    start,stop=parser.regions[ident]
    first=len(text[:start].encode('utf-8'))
    last=len(text[:stop].encode('utf-8'))
    piece=raw[first:last]
    target=ROOT/'phase1/raw'/f'{ident}.exactraw.html'
    target.write_bytes(piece)
    view=Readable()
    view.feed(piece.decode('utf-8'))
    out=ROOT/'phase1/raw'/f'{ident}.alttext-view.txt'
    out.write_text(view.view())
    math=MathInventory()
    math.feed(piece.decode('utf-8'))
    (ROOT/'phase1/raw'/f'{ident}.math-alttext.json').write_text(json.dumps(math.items,indent=2,ensure_ascii=False)+'\n')
    manifest['regions'].append({'id':ident,'byte_start_inclusive':first,'byte_end_exclusive':last,'bytes':len(piece),'sha256':hashlib.sha256(piece).hexdigest(),'path':str(target.relative_to(ROOT)),'view_path':str(out.relative_to(ROOT)),'view_note':'Derived readability aid, math replaced by decoded original alttext; exactraw bytes authoritative.'})
(ROOT/'phase1/raw-source-regions.json').write_text(json.dumps(manifest,indent=2)+'\n')
for ident in targets:
    print('REGION',ident)
    print((ROOT/'phase1/raw'/f'{ident}.alttext-view.txt').read_text())
