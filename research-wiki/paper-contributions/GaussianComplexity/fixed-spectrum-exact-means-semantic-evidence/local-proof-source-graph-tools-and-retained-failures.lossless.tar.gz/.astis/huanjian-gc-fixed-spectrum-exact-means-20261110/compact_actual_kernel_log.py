from pathlib import Path
import hashlib,json,gzip
w=Path('.astis/huanjian-gc-fixed-spectrum-exact-means-20261110')
rp=Path('.astis/huanjian-resume-20261103/20261109T181105677218Z-exact-means-kernel-exact-types-all-private-provider-closure-v2.receipt.json')
r=json.loads(rp.read_text());assert r['exit_code']==0
p=Path(r['log']);out=w/'actual-kernel-v2-bounded-lossy-view.txt'
assert not out.exists()
lines=[];drop=False
with p.open() as f:
 for l in f:
  if l.startswith('OWNED_DECL_COMPLETE_BODY_REPR '):drop=True
  elif l.startswith(('OWNED_DECL_TYPE ','OWNED_DECL_USED ','OWNED_DECL_AXIOMS ','OWNED_DECL_REACHABLE_FROM_ACTUAL_ROOT ','ALL_OWNED_DECLARATIONS_KERNEL_INSPECTED ','ACTUAL_ROOT ','ACTUAL_PUBLIC_ASTIS_PARENTS ','ACTUAL_ALL_REACHABLE_OWNED ','ACTUAL_PRIVATE_SEALED_LITERAL_KERNEL_TYPE_APPLICATION_PASS',"'ActualPrivateSealedTypeCheck'", "'AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumExactMeans.actual_diagonal_gaussian_exact_means'")):drop=False
  if not drop:lines.append(l)
out.write_text(''.join(lines))
record={'scope':'Bounded lossy projection removing complete Expr repr blocks only; original private raw receipt/log remain authoritative. This is not a new execution.','original_receipt':str(rp),'original_raw_log_sha256':r['log_sha256'],'original_raw_log_bytes':p.stat().st_size,'actual_exit_code':r['exit_code'],'actual_elapsed_seconds':r['elapsed_seconds'],'projection_path':str(out),'projection_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'owned_reachable_true':sum('OWNED_DECL_REACHABLE_FROM_ACTUAL_ROOT' in l and l.rstrip().endswith('true') for l in lines),'owned_unreachable_elaboration_simp':sum('OWNED_DECL_REACHABLE_FROM_ACTUAL_ROOT' in l and l.rstrip().endswith('false') for l in lines)}
(w/'actual-kernel-v2-bounded-view-manifest.json').write_text(json.dumps(record,indent=2)+'\n')
probe=(w/'KernelExactTypesAndAllPrivateProviders.lean').read_text()
assert '    logInfo m!"OWNED_DECL_COMPLETE_BODY_REPR {n}: {repr body}"\n' in probe
(w/'KernelExactTypesAndAllPrivateProvidersBounded.lean').write_text(probe.replace('    logInfo m!"OWNED_DECL_COMPLETE_BODY_REPR {n}: {repr body}"\n','    -- The kernel body is checked above; omit unbounded Expr pretty-printing.\n'))
print(json.dumps(record))
