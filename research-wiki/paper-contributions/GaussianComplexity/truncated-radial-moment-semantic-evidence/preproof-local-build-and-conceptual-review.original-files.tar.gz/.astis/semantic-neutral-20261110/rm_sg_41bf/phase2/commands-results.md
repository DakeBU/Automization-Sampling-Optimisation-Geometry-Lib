# Selective type audit commands and results

The commands ran with `/Users/zhouhuanjian/ASTIS-GC` as the working directory. The only new input was the authorized selective packet. The Phase 1 source artifacts retain their existing freeze.

- `shasum -a 256 .astis/huanjian-gc-truncated-radial-moment-20261110/selective-type-definition-packet.json` exited 0 and returned `0e99a3a59cef7c404de38185ada1dd9df6fc5483ea888a917bf20eaf65b1cd9d`.
- `cat .astis/huanjian-gc-truncated-radial-moment-20261110/selective-type-definition-packet.json` exited 0 and printed the full packet, including both signatures and the supplied definition groups.

The UTF-8 literal audit ran as follows.

```sh
python3 -c '
from hashlib import sha256
from pathlib import Path
import json
path = Path(".astis/huanjian-gc-truncated-radial-moment-20261110/selective-type-definition-packet.json")
packet = json.loads(path.read_bytes())
for name in ("producer", "private_consumer"):
    entry = packet[name]
    actual = sha256(entry["signature"].encode("utf-8")).hexdigest()
    assert actual == entry["signature_sha256"], (name, actual)
    print(name, actual)
for group in ("previous_pinned_definition_literals", "actual_compiled_definition_prints", "canonical_real_volume_source_definitions"):
    entries = packet["definition_context"][group]
    assert all(sha256(entry["literalLF"].encode("utf-8")).hexdigest() == entry["literal_sha256"] for entry in entries)
    print(group, len(entries), "literal hashes verified")
'
```

It exited 0 with these results.

```text
producer f4a31dd5801f83ccc2f6c88a4cd38a5392ed2d2f0c03b00afbf47c35029da6d7
private_consumer bdee81d17f529d8d510b0cd0a95e531889fa33d63f7d75ba3a29c1464834e87c
previous_pinned_definition_literals 8 literal hashes verified
actual_compiled_definition_prints 8 literal hashes verified
canonical_real_volume_source_definitions 2 literal hashes verified
```

`shasum -a 256 -c .astis/semantic-neutral-20261110/rm_sg_41bf/phase1/SHA256SUMS` exited 0 and reported `OK` for all six frozen Phase 1 files.

The final layout and locator check used the following command. A preliminary check exposed an unescaped vertical bar in the logarithm explanation. The final table spells out absolute value.

```sh
python3 -c '
from pathlib import Path
import re
overlay = Path(".astis/semantic-neutral-20261110/rm_sg_41bf/phase2/typed-overlay.md").read_text()
tables = re.findall(r"(?:^\|[^\n]+\n)+", overlay, flags=re.MULTILINE)
expected_widths = [2, 2, 3, 3]
assert len(tables) == len(expected_widths)
for table, width in zip(tables, expected_widths, strict=True):
    assert all(len(re.split(r"(?<!\\)\|", row)) == width + 2 for row in table.splitlines())
anchors = ("A3.Ex106.m2#identity", "A3.Ex106.m2#bound", "A3.Ex109.m1#identity", "A3.Ex109.m1#bound", "A3.SS2.p12.m3")
assert all(anchor in overlay for anchor in anchors)
print(len(tables), "Markdown tables,", sum(len(table.splitlines()) for table in tables), "rows and", len(anchors), "critical source locators verified")
'
```

It exited 0 and printed `4 Markdown tables, 32 rows and 5 critical source locators verified`.
