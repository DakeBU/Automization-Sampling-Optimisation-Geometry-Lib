"""Seal own bounded portable evidence and re-read every member."""
import datetime,gzip,io,json,pathlib,tarfile
from run import ROOT,sha
receipts=[]
for p in sorted((ROOT/'receipts').glob('*.json')):
    v=json.loads(p.read_text())
    for k in ['stdout','stderr']:
        b=(ROOT/v[k]['path']).read_bytes();assert len(b)==v[k]['bytes'] and sha(b)==v[k]['sha256'],p
    assert v['elapsed_seconds']>=0 and len(v['HEAD_at_start'])==40 and v['argv'] and v['cwd']
    receipts.append({'path':str(p.relative_to(ROOT)),'exit_code':v['exit_code']})
assert [x for x in receipts if x['exit_code']!=0]==[{'path':'receipts/reader-static-driver.json','exit_code':1}]
excluded={'native-all-bodies.json','portable-manifest.json','portable-evidence.tar.gz','evidence-seal.json'}
members=[]
for p in sorted(ROOT.rglob('*')):
    if not p.is_file():continue
    rel=str(p.relative_to(ROOT))
    if rel in excluded or '__pycache__' in p.parts or 'native-olean' in p.parts:continue
    assert not p.is_symlink()
    b=p.read_bytes();members.append({'path':rel,'bytes':len(b),'sha256':sha(b)})
manifest={'scope':'Own bounded scripts, generated audit Lean, frozen exact relevant inputs/protocols/renderer code, bounded original spans/archive, types, receipts/streams and report. No ASTIS oleans, large native body dump, whole foreign/control/private snapshot or ATLAS data export.','compile_candidate':'66e0bb9b748d68816a8443d60696656c9340222f','member_count_excluding_this_manifest':len(members),'members':members,'receipt_count':len(receipts),'receipts_all_streams_rehashed':True,'receipts':receipts,'local_hash_bound_excluded_native_dump':json.loads((ROOT/'native-summary.json').read_text())['large_full_dump']}
mp=ROOT/'portable-manifest.json';mp.write_text(json.dumps(manifest,indent=2)+'\n')
want={v['path']:v for v in members};b=mp.read_bytes();want['portable-manifest.json']={'path':'portable-manifest.json','bytes':len(b),'sha256':sha(b)}
archive=ROOT/'portable-evidence.tar.gz'
with archive.open('wb') as f:
    with gzip.GzipFile(filename='',mode='wb',fileobj=f,mtime=0) as gz:
        with tarfile.open(fileobj=gz,mode='w') as tar:
            for name,v in sorted(want.items()):
                b=(ROOT/name).read_bytes();assert len(b)==v['bytes'] and sha(b)==v['sha256']
                info=tarfile.TarInfo(name);info.size=len(b);info.mode=0o644;info.mtime=0
                tar.addfile(info,io.BytesIO(b))
seen=set();size=0
with tarfile.open(archive,'r:gz') as tar:
    for z in tar.getmembers():
        assert z.isfile() and z.name in want and z.name not in seen
        b=tar.extractfile(z).read();v=want[z.name]
        assert len(b)==v['bytes'] and sha(b)==v['sha256']
        seen.add(z.name);size+=len(b)
assert seen==set(want)
result={'candidate_compile_only':'66e0bb9b748d68816a8443d60696656c9340222f','report_json':{'path':'report.json','bytes':(ROOT/'report.json').stat().st_size,'sha256':sha((ROOT/'report.json').read_bytes())},'report_md':{'path':'report.md','sha256':sha((ROOT/'report.md').read_bytes())},'manifest':{'path':mp.name,'bytes':mp.stat().st_size,'sha256':sha(mp.read_bytes()),'listed_files_excluding_manifest':len(members)},'archive':{'path':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),'members':len(seen),'uncompressed_member_bytes':size,'all_members_reread_and_hash_verified':True},'preproof_archive_nested_members_all_reread':204,'coordinate_span_checks':47,'whole_ASTIS_modules_freshly_compiled':3,'module_owned_declarations':3,'new_handwritten':2,'new_generated':0,'own_command_receipts':len(receipts),'rejected_own_setup_attempts':1,'truth_boundary':'Bounded native/whole-module/static acceptance only. No source-fidelity, ledger/ownership release/integration permission, globalgraph/fullsite/browser/mobile/MathJax/clipboard/interactive download/root Tests/fullrepo/publication/purification credit.'}
(ROOT/'evidence-seal.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
