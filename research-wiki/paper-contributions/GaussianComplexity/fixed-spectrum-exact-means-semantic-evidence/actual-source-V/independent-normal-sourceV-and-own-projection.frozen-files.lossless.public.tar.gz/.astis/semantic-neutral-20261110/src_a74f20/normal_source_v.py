from pathlib import Path
from types import SimpleNamespace
import sys,os,json,hashlib,subprocess,time,gzip,zipfile,io,contextlib,traceback
sys.dont_write_bytecode=True
ROOT=Path('/Users/zhouhuanjian/ASTIS-GC');BASE=ROOT/'.astis/semantic-neutral-20261110/src_a74f20';OUT=BASE/'normal-sourceV-runtime'
E=ROOT/'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-exact-means-semantic-evidence'
CELL=Path('research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-exact-means.json')
SAU='ASTIS-SA-20261110-GaussianComplexityFixedSpectrumExactMeans';VERIFIER='/root/source_reader_a74f20';OWNER='huanjian_gc_20261110_fixed_spectrum_exact_means';COMMIT='6eca29f8704a024f9bbf2de986d8aa9fbe8c6129'
TARGET='AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumExactMeans.actual_diagonal_gaussian_exact_means'
LEDGER=ROOT/'runs/substantive_advances.jsonl';DISC=ROOT/'runs/substantive_discoveries.jsonl'
sys.path[:0]=[str(ROOT/'tools'),str(ROOT/'website/scripts'),str(ROOT)]
from tools import astis_advance as advance
from tools import astis_harness as durable
def sha(b):return hashlib.sha256(b).hexdigest()
def canon(o):return json.dumps(o,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
def put(name,o):
 p=OUT/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(o,indent=2,ensure_ascii=False)+'\n');return p
def head():return subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
def state(b):return advance._replay_advances([json.loads(x) for x in b.splitlines() if x.strip()])
def check_old():
 rows=[]
 for phase in ['phase1','phase2','phase3','phase3-reader-v2']:
  p=BASE/phase/'freeze-manifest.json';m=json.loads(p.read_text())
  for v in m['files']:assert sha((ROOT/v['path']).read_bytes())==v['sha256'],v['path']
  rows.append({'phase':phase,'manifest_sha256':sha(p.read_bytes()),'verified_file_count':len(m['files'])})
 return rows
def protected_files():
 w=ROOT/'.astis/huanjian-gc-fixed-spectrum-exact-means-20261110'
 manifest=json.loads((w/'candidate-actual-protected-source-trees-v2.json').read_text());paths=[]
 for row in manifest['actual_nonempty_protected_trees']:
  p=ROOT/row['path'];found=sorted(x for x in p.rglob('*') if x.is_file()) if p.is_dir() else [p]
  assert len(found)==row['actual_files'],row['path'];paths+=found
 shared=json.loads((w/'preproof-baseline.json').read_text())['protected_shared_hashes']
 for name,expected in shared.items():
  expected=expected['sha256'] if isinstance(expected,dict) else expected
  assert sha((ROOT/name).read_bytes())==expected,name
  paths.append(ROOT/name)
 return sorted(set(paths))
action=sys.argv[1];OUT.mkdir(parents=True,exist_ok=True)
if action=='preflight':
 assert not (OUT/'before-state.json').exists(),'Before snapshot already exists; do not overwrite.'
 assert head()==COMMIT
 audit_path=ROOT/'research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-exact-means.json';audit=json.loads(audit_path.read_text());proposal=json.loads((BASE/'phase3-reader-v2/canonical-audit-four-field-proposal.json').read_text())
 assert sha(audit_path.read_bytes())=='357e192b7a81486caba7e57d742e90c9380b365d3ea74197c3a3a50d4679e49e'
 assert all(audit[k]==proposal[k] for k in ['semantic_slots','deltas','verdict','source_review'])
 oldaudit=json.loads((BASE/'phase3-reader-v2/snapshot/research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-exact-means.json').read_text())
 for k in ['source','lean','reconstruction','repairs','publication_context','publication_binding_sha256']:assert audit[k]==oldaudit[k],k
 pinned={'AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumExactMeans.lean':'8dfb13585403a127830dfc841dafaf7e6f95057db10253f38b0ab7a66802b6c8','Tests/GaussianComplexityFixedSpectrumExactMeans.lean':'d30744e67541fa07729002f06fde01f84a4fa1984b6f24d1014285db50ccc696','website/content/declaration_lessons/huanjian-fixed-spectrum-exact-means.json':'4252152a1df92598351878fe7a0089feebd400de30f8398f7752b19d958c69d6'}
 for name,h in pinned.items():
  b=(ROOT/name).read_bytes();assert sha(b)==h
  assert subprocess.check_output(['git','show',COMMIT+':'+name],cwd=ROOT)==b
 import astis_publication as pub
 import astis_semantic_roundtrip_core as core
 item=json.loads((ROOT/'website/content/publications/huanjian-fixed-spectrum-exact-means.json').read_text())['items'][0];binding=item['bindings'][0];unit=json.loads((ROOT/'website/content/declaration_lessons/huanjian-fixed-spectrum-exact-means.json').read_text())['units'][0]
 data={'declarations':{TARGET:SimpleNamespace(source_file=next(iter(pinned)))},'lessons':{TARGET:unit}}
 assert pub.binding_digest(item,binding,data)==audit['publication_binding_sha256']=='782a2b00ab19c7773c613a275c9371427951632b4f1b1cb974490af25ff70816'
 assert pub.review_context(item,binding,data)==audit['publication_context']
 assert core.semantic_reviewer_packet(audit)['packet_sha256']=='a5ad7c23afaa9804cdf88c8794e63304d3ed287ff33f0958794fa32190526040'
 m=json.loads((E/'source-to-lean-map-v2-reviewed.json').read_text());loc=[]
 assert len(m['nodes'])==46
 for k,v in m['nodes'].items():
  line=(ROOT/v['file']).read_text().splitlines()[v['line']-1];assert v['provider'] in line,k
  loc.append({'node':k,'file':v['file'],'line':v['line'],'provider':v['provider'],'actual_line':line,'pass':True})
 put('source-map46-locators.json',loc)
 old=check_old();raw=LEDGER.read_bytes();assert raw.endswith(b'\n');states=state(raw);own=states[SAU]
 assert own['state']=='PROVED_LOCAL' and own['owner_id']==OWNER and own['publication_declarations']==[TARGET]
 (OUT/'advance-ledger.before.raw.jsonl').write_bytes(raw);(OUT/'discovery-ledger.before.raw.jsonl').write_bytes(DISC.read_bytes());put('all-SAU-states.before.json',states)
 foreign_frontiers={};allfront=list(sorted((ROOT/'research-wiki/frontier-cells').rglob('*.json')))
 with zipfile.ZipFile(OUT/'all-frontiers.before.raw.zip','w',compression=zipfile.ZIP_STORED) as archive:
  for p in allfront:
   archive.write(p,p.relative_to(ROOT));foreign_frontiers[str(p.relative_to(ROOT))]=sha(p.read_bytes())
 (OUT/'own-frontier.before.raw.json').write_bytes((ROOT/CELL).read_bytes())
 protected={}
 with zipfile.ZipFile(OUT/'protected.before.raw.zip','w',compression=zipfile.ZIP_STORED) as archive:
  for p in protected_files():archive.write(p,p.relative_to(ROOT));protected[str(p.relative_to(ROOT))]=sha(p.read_bytes())
 baseline=json.loads((ROOT/'.astis/huanjian-gc-fixed-spectrum-exact-means-20261110/preproof-baseline.json').read_text());base_states=baseline['all_current_SAU_states']
 hist=[]
 for k,v in base_states.items():
  if k==SAU:continue
  expected=v.get('state') if isinstance(v,dict) else v
  assert states[k]['state']==expected,k
  hist.append(k)
 for name,v in baseline['all_frontier_hashes'].items():
  if name==str(CELL):continue
  expected=v['sha256'] if isinstance(v,dict) else v;assert foreign_frontiers[name]==expected,name
 # Preserve every original metadata gate receipt/log, including the actual failure.
 gate_rows=[]
 for p in sorted((E/'final-local-metadata-gates').iterdir()):
  if p.is_file():q=OUT/'root-gates'/p.name;q.parent.mkdir(exist_ok=True);q.write_bytes(p.read_bytes())
 for p in sorted((E/'final-local-metadata-gates').glob('*.receipt.json')):
  r=json.loads(p.read_text());z=p.with_name(p.name.replace('.receipt.json','.log.gz'));data=gzip.decompress(z.read_bytes());assert sha(data)==r['log_sha256']
  gate_rows.append({'receipt':str(p.relative_to(ROOT)),'receipt_sha256':sha(p.read_bytes()),'exit_code':r['exit_code'],'log_uncompressed_sha256':sha(data),'command':r['command']})
 put('root-gates-checked.json',gate_rows)
 before=put('before-state.json',{'head':COMMIT,'advance_ledger_sha256':sha(raw),'advance_ledger_bytes':len(raw),'discovery_ledger_sha256':sha(DISC.read_bytes()),'all_foreign_SAU_state_hashes':{k:sha(canon(v)) for k,v in states.items() if k!=SAU},'frontier_raw_hashes':foreign_frontiers,'protected_raw_hashes':protected,'prior_freezes':old,'historical_foreign_states_checked':len(hist),'historical_frontier_hashes_checked':len(baseline['all_frontier_hashes']),'foreign_lane_still_occupied_no_transfer':baseline['foreign_lane_still_occupied_no_transfer'],'own_state':{'state':own['state'],'owner_id':own['owner_id'],'publication_declarations':own['publication_declarations']},'pinned_current_inputs':pinned,'canonical_audit_sha256':sha(audit_path.read_bytes()),'projection_exact':True,'source_map_locators_passed':46,'normal_V_authorized_only':True})
 print(json.dumps({'PREFLIGHT_STATIC_PASS':True,'before_state_sha256':sha(before.read_bytes()),'foreign_SAU_count':len(states)-1,'frontier_count':len(foreign_frontiers),'protected_file_count':len(protected),'historical_foreign_states_checked':len(hist)},indent=2))
elif action=='gates':
 commands=[('publication',['/opt/anaconda3/bin/python','tools/astis_publication.py','check','--base','8bec676ecdade94d82112066d27970bcba4dea8c']),('contributor',['/opt/anaconda3/bin/python','tools/astis_contributor_contract.py','check','--base','8bec676ecdade94d82112066d27970bcba4dea8c']),('semantic',['/opt/anaconda3/bin/python','tools/astis_semantic_roundtrip.py','check']),('frontier',['/opt/anaconda3/bin/python','tools/astis_frontier_cells.py','check'])]
 receipts=[]
 for label,cmd in commands:
  assert head()==COMMIT;t=time.time();env=os.environ.copy();env['PYTHONDONTWRITEBYTECODE']='1';env['LEAN_NUM_THREADS']='2';env['ASTIS_ATLAS_ROOT']=str(ROOT/'.atlas-upstream/v1');r=subprocess.run(cmd,cwd=ROOT,env=env,capture_output=True)
  (OUT/('current-'+label+'.stdout')).write_bytes(r.stdout);(OUT/('current-'+label+'.stderr')).write_bytes(r.stderr)
  receipt={'command':cmd,'cwd':str(ROOT),'head_before':COMMIT,'head_after':head(),'exit_code':r.returncode,'elapsed_seconds':time.time()-t,'stdout_sha256':sha(r.stdout),'stderr_sha256':sha(r.stderr)};put('current-'+label+'.receipt.json',receipt);receipts.append(receipt);print(label,json.dumps(receipt),flush=True)
  assert r.returncode==0 and receipt['head_after']==COMMIT,label
 put('current-four-metadata-gates.json',{'passes':True,'receipts':receipts})
elif action=='execute':
 assert head()==COMMIT
 before=json.loads((OUT/'before-state.json').read_text());raw=(OUT/'advance-ledger.before.raw.jsonl').read_bytes();assert LEDGER.read_bytes()==raw
 assert sha((ROOT/'research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-exact-means.json').read_bytes())==before['canonical_audit_sha256']
 assert all(sha((ROOT/p).read_bytes())==h for p,h in before['pinned_current_inputs'].items())
 assert all(sha((ROOT/p).read_bytes())==h for p,h in before['frontier_raw_hashes'].items())
 assert all(sha((ROOT/p).read_bytes())==h for p,h in before['protected_raw_hashes'].items())
 assert json.loads((OUT/'current-four-metadata-gates.json').read_text())['passes']
 evidence={
  'gate':{'current_metadata_gates':str((OUT/'current-four-metadata-gates.json').relative_to(ROOT)),'sha256':sha((OUT/'current-four-metadata-gates.json').read_bytes()),'all_four_exit_zero':True},
  'verifier_id':VERIFIER,'verified_commit':COMMIT,
  'source_audit':{'audit':'research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-exact-means.json','sha256':'357e192b7a81486caba7e57d742e90c9380b365d3ea74197c3a3a50d4679e49e','reviewer_packet_sha256':'a5ad7c23afaa9804cdf88c8794e63304d3ed287ff33f0958794fa32190526040','review_run_sha256':'52c8c7c1f532cd570bb3687a1fd38664680b450150fb97f456bca136a0eef770'},
  'fake_closure_scan':{'artifact':str((BASE/'phase3/fake-closure-static-scan.json').relative_to(ROOT)),'sha256':sha((BASE/'phase3/fake-closure-static-scan.json').read_bytes()),'kernel_owned_declarations':37,'only_standard_permitted_axioms':True},
  'publication_declarations':[TARGET],
  'whole_module_review':{'production_sha256':'8dfb13585403a127830dfc841dafaf7e6f95057db10253f38b0ab7a66802b6c8','test_sha256':'d30744e67541fa07729002f06fde01f84a4fa1984b6f24d1014285db50ccc696','original_review_run_sha256':'d7d691020732f44872aacde30b9a484c99a59662dba79dd3ebbcee40e66435f7'},
  'native_evidence':{'fresh_native_commit':'d823dddd8b7f203af3191b94ba2eb763fc0edc9b','reused_unchanged':True,'fresh_native_at_verified_carrier':False,'freeze_manifest_sha256':'4932582ef2ff7976624eaf2672910a11aeb447292b1a72e1f84e9b63a67ff621'},
  'reader_evidence':{'exact_reader_commit':'64922804e1f7f0927e85bb6a26aeb24d06eea6f7','review_run_sha256':'52c8c7c1f532cd570bb3687a1fd38664680b450150fb97f456bca136a0eef770','static_acceptance':'exact six source panels, full unchanged Test consumer and complete numbered source export','browser_acceptance':False},
  'publication_binding_sha256':'782a2b00ab19c7773c613a275c9371427951632b4f1b1cb974490af25ff70816',
  'source_map':{'artifact':str((OUT/'source-map46-locators.json').relative_to(ROOT)),'sha256':sha((OUT/'source-map46-locators.json').read_bytes()),'actual_current_locators_passed':46},
  'preservation_before':{'artifact':str((OUT/'before-state.json').relative_to(ROOT)),'sha256':sha((OUT/'before-state.json').read_bytes()),'foreign_lane_no_transfer':True},
  'prior_freezes':before['prior_freezes'],
  'dependency_cache_binding':{'artifact':str((BASE/'phase3/actual-transitive-dependency-cache-hashes.json').relative_to(ROOT)),'sha256':sha((BASE/'phase3/actual-transitive-dependency-cache-hashes.json').read_bytes()),'module_count':5166,'artifact_count':20649},
  'truth_boundary':'Normal independent source VERIFIED only for both actual closed C8 Gaussian means/integrability and genuine actual-integral mean-upper/sign/exact-ratio consumer. No full Lemma4.5 variance/exponential bounds, STAB/integration/Registry/shared graph/site/browser/remote/purification/Goal completion.'
 }
 with (OUT/'EXACTLY_ONE_API_CALL.intent.json').open('x') as f:json.dump({'advance_id':SAU,'to_state':'VERIFIED','worker_id':VERIFIER,'verified_commit':COMMIT},f)
 stdout=io.StringIO();stderr=io.StringIO();t=time.time()
 try:
  with contextlib.redirect_stdout(stdout),contextlib.redirect_stderr(stderr):
   returned=advance.transition_advance(SAU,'VERIFIED',worker_id=VERIFIER,modes=['independent-source-verification','whole-module-review','runtime-preservation'],evidence=evidence)
 except BaseException:
  (OUT/'transition.stdout').write_text(stdout.getvalue());(OUT/'transition.stderr').write_text(stderr.getvalue()+traceback.format_exc());put('transition-return.json',{'returned':False,'exception':traceback.format_exc(),'elapsed_seconds':time.time()-t});raise
 (OUT/'transition.stdout').write_text(stdout.getvalue());(OUT/'transition.stderr').write_text(stderr.getvalue());put('transition-return.json',{'returned':True,'actual_return_value':returned,'elapsed_seconds':time.time()-t,'api_call_count':1})
 after=LEDGER.read_bytes();assert after.startswith(raw);append=after[len(raw):];assert len(append.splitlines())==1;event=json.loads(append);assert event['advance_id']==SAU and event['from_state']=='PROVED_LOCAL' and event['to_state']=='VERIFIED' and event['worker_id']==VERIFIER and event['evidence']==evidence
 (OUT/'ACTUAL-normal-V-append.raw.jsonl').write_bytes(append);put('ACTUAL-normal-V-event.pretty.json',event);(OUT/'ACTUAL-normal-V-event.canonical.json').write_bytes(canon(event))
 text=append.decode();decoder=json.JSONDecoder();pos=1;raw_evidence=None
 while True:
  while text[pos].isspace() or text[pos]==',':pos+=1
  if text[pos]=='}':break
  key,end=decoder.raw_decode(text,pos);pos=end
  while text[pos].isspace() or text[pos]==':':pos+=1
  start=pos;value,end=decoder.raw_decode(text,start)
  if key=='evidence':raw_evidence=text[start:end].encode();assert value==event['evidence']
  pos=end
 assert raw_evidence is not None
 (OUT/'ACTUAL-V-evidence.raw.json').write_bytes(raw_evidence);put('ACTUAL-V-evidence.pretty.json',event['evidence']);(OUT/'ACTUAL-V-evidence.canonical.json').write_bytes(canon(event['evidence']))
 put('ACTUAL-V-evidence-key-inventory.json',{'actual_key_count':len(event['evidence']),'actual_keys':list(event['evidence']),'per_value_canonical_sha256':{k:sha(canon(v)) for k,v in event['evidence'].items()},'canonical_evidence_sha256':sha(canon(event['evidence'])),'later_release_rule':'Retain ALL actual original keys and value bytes/semantics; only add post_integration. Never assume a fixed12/13-field shape.'})
 cell=json.loads((ROOT/CELL).read_text());cell['status']='independently_verified';statement=f'Independent normal source V by {VERIFIER} at carrier {COMMIT}; actual normal API append '+str((OUT/'ACTUAL-normal-V-append.raw.jsonl').relative_to(ROOT))+f' SHA256 {sha(append)}. Exact source/whole-module and repaired static reader accepted; native d823 evidence reused unchanged. No STAB/shared/browser/remote/purification completion.'
 cell['evidence']['independent_verification']=statement;cell['evidence']['independent_source_review']['normal_sourceV_transition']={'state':'VERIFIED','verifier_id':VERIFIER,'verified_commit':COMMIT,'actual_append':str((OUT/'ACTUAL-normal-V-append.raw.jsonl').relative_to(ROOT)),'actual_append_sha256':sha(append),'evidence_key_inventory':str((OUT/'ACTUAL-V-evidence-key-inventory.json').relative_to(ROOT))}
 cell['source_proof_coverage']['current_compiled_scope']['source_VERIFIED']=True
 cell['evidence']['exact_reader_repair_v2']='Exact successor64922804 independently accepted: six literal code panels, entire Test consumer and complete numbered repository-source context. Original reader HOLD remains historical.'
 cell['statement_seal']['status']='EXACT_ORIGINAL_SIGNATURES_INDEPENDENT_SOURCE_WHOLE_MODULE_STATIC_READER_ACCEPTED_NORMAL_SOURCE_VERIFIED'
 boundary=f'Selected actual closed C8 means/integrability and genuine actual-integral mean-upper/sign/exact-ratio consumer are independently source VERIFIED by {VERIFIER} at carrier {COMMIT}. Fresh native/kernel/cache checks at d823 are reused unchanged; exact reader successor64922804 has bounded static acceptance. Shared latest-main integration, actual desktop/mobile/graph, remote publication and purification remain pending. Fourth moments/variance, exponential bias, actual adaptive/oracle/TV/precision/deterministic-cap/expected-cost adapters and both full main bounds remain open.'
 for obj,key in [(cell['source_detail_audit'],'gap'),(cell['source_detail_audit'],'fidelity_boundary'),(cell['evidence'],'execution_boundary')]:obj[key]=boundary
 durable.atomic_write_text(ROOT/CELL,json.dumps(cell,indent=2,ensure_ascii=False)+'\n')
 (OUT/'own-frontier.after.raw.json').write_bytes((ROOT/CELL).read_bytes());(OUT/'advance-ledger.after.raw.jsonl').write_bytes(after)
 beforestates=json.loads((OUT/'all-SAU-states.before.json').read_text());afterstates=state(after)
 assert set(beforestates)==set(afterstates)
 assert all(beforestates[k]==afterstates[k] for k in beforestates if k!=SAU)
 assert afterstates[SAU]['state']=='VERIFIED' and afterstates[SAU]['owner_id']==OWNER
 foreign={p:h for p,h in before['frontier_raw_hashes'].items() if p!=str(CELL)}
 assert all(sha((ROOT/p).read_bytes())==h for p,h in foreign.items())
 assert all(sha((ROOT/p).read_bytes())==h for p,h in before['protected_raw_hashes'].items())
 assert DISC.read_bytes()==(OUT/'discovery-ledger.before.raw.jsonl').read_bytes()
 assert head()==COMMIT
 preserved=put('after-preservation-checks.json',{'passes':True,'head_unchanged':COMMIT,'raw_advance_ledger_prefix_preserved':True,'exactly_one_normal_transition_append':True,'append_sha256':sha(append),'append_bytes':len(append),'actual_evidence_key_count':len(event['evidence']),'foreign_SAU_states_exactly_preserved':len(beforestates)-1,'foreign_frontier_raw_files_preserved':len(foreign),'protected_raw_files_preserved':len(before['protected_raw_hashes']),'discovery_ledger_unchanged':True,'own_SAU_state':'VERIFIED','own_frontier_status':'independently_verified','independent_verification_is_nonempty_string':isinstance(cell['evidence']['independent_verification'],str) and bool(cell['evidence']['independent_verification']),'prior_freezes':check_old(),'no_foreign_lane_transfer':True,'no_STAB_or_shared_completion':True})
 print(json.dumps({'ACTUAL_NORMAL_V':'VERIFIED','api_return':returned,'append_sha256':sha(append),'actual_evidence_key_count':len(event['evidence']),'after_preservation_sha256':sha(preserved.read_bytes()),'own_frontier_sha256':sha((ROOT/CELL).read_bytes())},indent=2))
else:raise SystemExit('Unknown action')
