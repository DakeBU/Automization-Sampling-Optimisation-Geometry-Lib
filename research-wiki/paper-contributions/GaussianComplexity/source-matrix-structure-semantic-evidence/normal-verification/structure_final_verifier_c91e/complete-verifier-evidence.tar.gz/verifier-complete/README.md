# Selected complete independent normal-verifier evidence

This archive preserves the exact normal V append/payload, before/after owned
cell, bounded guard outcomes, actual API and command receipts, current final
package review and original execution scripts. The exact 26-field historical PL
payload and exact original PL append are retained separately as well as inline
in the V payload and cell details.

`native-reader-selected-evidence.tar.gz` occurs exactly once with SHA-256
`b37c5a0a7d0ddb64332709849743762e5cb48e9adbb01a6fdde61a97c9fdb8ad`.
It contains the peer's complete selected native/reader evidence, all 231 native
original files and lossless mathematical DAG, exact runtime fixtures, reports,
screenshots and four actual final CLI gates. The separate unchanged selected
source-review archive occurs once with SHA-256
`ce677c3d2a90d22905030fa5944c19baf8fc0f91577b682371fed812b0e90df9`.

Full private preservation maps, whole indexes, foreign/control snapshots and
private checker implementations are excluded. The executed orchestration script
therefore references local-only preservation modules that are intentionally not
included. The command's exact normal API invocation, payload, streams and final
outcome remain available; preservation claims have bounded reports rather than
exported foreign state. This is a selected evidence archive, not a repository
snapshot.

Extract in a new directory and run `python3 tinycheck.py` from the extracted root
to verify archive payload hashes and exact PL/V/cell carry. This performs no
Lean build, browser run, source review, ledger mutation or repeated normal API
call. `payload-manifest.json` inventories every payload member. Its seal is the
terminal internal metadata; external archive closure hashes the archive itself.

The original reader FAIL, conditional PASS but globally UNAPPLIED, source-L13
fixed-header limitation and global integration/publication/purification/Goal
HOLD remain explicit. See `verifier-originals/VERIFICATION-JUDGMENT.md`.
