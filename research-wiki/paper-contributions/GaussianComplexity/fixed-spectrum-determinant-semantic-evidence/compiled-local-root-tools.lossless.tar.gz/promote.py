from pathlib import Path
import json,hashlib
private=Path('.astis/huanjian-fixed-spectrum-determinant-20261108');b=Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-determinant-semantic-evidence')
seal=json.loads((b.parent/'fixed-spectrum-determinant-statement-seal.json').read_bytes());consumer=json.loads((b/'actual-consumer-interface/statement-seal.json').read_bytes());p=Path(seal['production_file']);test=Path('Tests/GaussianComplexityFixedSpectrumDeterminant.lean');assert not p.exists() and not test.exists()
proof=(private/'Proof.lean').read_text().split('#print axioms')[0]
doc='''/-!
# Actual fixed-spectrum precision determinant

Zhou--Suzuki, arXiv:2610.20492v1 Eq11 and the determinant component of
Appendix C.4. The actual cosine-grid precision has the displayed diagonal
product as determinant, pointwise for every full real orthogonal O, either
determinant sign. Exactly source d>=2 and kappa>=2 are retained; these bounds
are not needed for this algebraic identity but feed the actual Gaussian
consumer through the existing source admissibility producer.

The existing public DisplacementJacobianEntropy.det_conjStarAlgAut_eq is the
canonical conjugation-invariance proof node and is reused literally here.
No duplicate generic invariant or determinant-one premise is introduced.
The focused Test consumes this exact determinant result, existing actual
admissibility and canonical GaussianPrecisionDensity in the same actual
inverse-precision law, exposing the spectrum-only density coefficient while
retaining the actual hidden orientation in the quadratic exponent.

Unweighted Gaussian-integral/known-Z statements, full C.4 calculus/minimizer,
moments/Krylov, true oracle/TV/precision/cost adapters and main bounds remain
separate. This pointwise identity is fixed-spectrum background, not a
determinant-sign lower-bound claim.
-/

'''
needle='namespace AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumDeterminant';assert proof.count(needle)==1;code=proof.replace(needle,doc+needle,1);start=code.index('theorem actual_precision_det');end=code.index(' := by',start);assert code[start:end]+'\n'==seal['exact_signature_utf8'];p.write_text(code)
header='''import AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumDeterminant
import AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumAdmissibility
import AutoSamplingTheory.TechnicalLemmas.Measure.GaussianPrecisionDensity
open Matrix MeasureTheory ProbabilityTheory
open AutoSamplingTheory.ExampleCases.GaussianComplexity
open AutoSamplingTheory.TechnicalLemmas.Measure.GaussianPrecisionDensity
open scoped BigOperators
set_option autoImplicit false

/-- Actual same-A source Gaussian density. The coefficient consumes the new
determinant producer; positivity is produced internally by existing source
admissibility. No supplied determinant/PosDef/density certificate. -/
'''
body=''' := by
  show_term
    let θ : Fin d → ℝ := fun i => ((i.val : ℝ) + 1 / 2) * Real.pi / (d : ℝ)
    let diagonalValue : Fin d → ℝ := fun i =>
      (κ + 1) / 2 + (κ - 1) / 2 * Real.cos (θ i)
    let A : Matrix (Fin d) (Fin d) ℝ :=
      (O : Matrix (Fin d) (Fin d) ℝ) * Matrix.diagonal diagonalValue *
        (O : Matrix (Fin d) (Fin d) ℝ).transpose
    change ProbabilityTheory.multivariateGaussian (0 : EuclideanSpace ℝ (Fin d)) A⁻¹ =
      (volume : Measure (EuclideanSpace ℝ (Fin d))).withDensity (fun x =>
        ENNReal.ofReal (Real.sqrt (∏ i : Fin d, diagonalValue i) /
          (2 * Real.pi) ^ ((d : ℝ) / 2) *
          Real.exp (-((WithLp.ofLp x) ⬝ᵥ (A *ᵥ WithLp.ofLp x)) / 2)))
    have hA : A.PosDef :=
      (FixedSpectrumAdmissibility.actual_precision_admissible (d := d) hd (κ := κ) hκ O).1
    have hdet : A.det = ∏ i : Fin d, diagonalValue i :=
      FixedSpectrumDeterminant.actual_precision_det (d := d) hd (κ := κ) hκ O
    have hμ := multivariateGaussian_eq_withDensity_of_posDef (n := d) A hA
    rw [hdet] at hμ
    exact hμ

#print axioms FixedSpectrumDeterminant.actual_precision_det
#print axioms FixedSpectrumAdmissibility.actual_precision_admissible
#print axioms multivariateGaussian_eq_withDensity_of_posDef
open Lean in
run_cmd do
  let env ← getEnv
  let some info := env.find? `AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumDeterminant.actual_precision_det | throwError "Missing actual source determinant theorem"
  let some proof := info.value? (allowOpaque := true) | throwError "Missing actual determinant proof"
  let parents := proof.getUsedConstants.filter fun n => n.toString.startsWith "AutoSamplingTheory"
  logInfo m!"ACTUAL COMPILED ASTIS PRODUCER PARENTS {parents}"
'''
testcode=header+consumer['exact_consumer_signature_utf8'].rstrip('\n')+body;test.write_text(testcode)
print(json.dumps({'production_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'Test_sha256':hashlib.sha256(test.read_bytes()).hexdigest(),'sealed_producer_and_consumer_signature_bytes_preserved':True,'actual_Lean_build':'pending','public_generic_invariant_added':False}))
