from pathlib import Path
from datetime import datetime, timezone
import contextlib
import hashlib
import io
import json
import subprocess
import sys
import time
import traceback
from types import SimpleNamespace

ROOT=Path('/Users/zhouhuanjian/ASTIS-GC')
BASE=ROOT/'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-determinant-semantic-evidence'
PUBLIC=BASE/'fresh-source-reader-835194/phase3-verification-transition'
PRIVATE=ROOT/'.astis/huanjian-fixed-spectrum-determinant-20261108/fresh-source-835194/verification-transition'
PHASE3=BASE/'fresh-source-reader-835194/phase3'
HEAD='15fbef72d04a1e9d1e647289a099a6ff8f829125'
REVIEWER='/root/reader_835194'
ADVANCE='ASTIS-SA-20261108-GaussianComplexityFixedSpectrumDeterminant'
OWNER='huanjian_gc_20261108_fixed_spectrum_determinant'
CELL='ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-determinant'
DECL='AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumDeterminant.actual_precision_det'
EXPECTED_PROPOSED='c5428384132af254a57bde4cbd2bb23f21db8f9295dc908901dfc7a927570501'
EXPECTED_EVIDENCE='abe13246570ef1f494fc194451286be4abc9a7b00e154eadbba8fac3da644b8b'
sys.path[:0]=[str(ROOT),str(ROOT/'tools'),str(ROOT/'website/scripts')]
from tools import astis_advance as advance
from tools import astis_publication as publication
from tools import astis_frontier_cells as cells

def sha(data):return hashlib.sha256(data).hexdigest()
def canonical(value):return json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
def save(path,value):
 path.parent.mkdir(parents=True,exist_ok=True)
 path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
def now():return datetime.now(timezone.utc).isoformat()
def head():return subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
def state(data):return advance._replay_advances([json.loads(line) for line in data.splitlines() if line.strip()])
def frontend():
 result={}
 for path in cells.cell_paths():
  data=path.read_bytes();obj=json.loads(data)
  result[str(path.relative_to(ROOT))]={'sha256':sha(data),'cell_id':obj.get('cell_id'),'status':obj.get('status')}
 return result

PRIVATE.mkdir(parents=True,exist_ok=True);PUBLIC.mkdir(parents=True,exist_ok=True)
assert not (PUBLIC/'API-attempt-intent.json').exists(), 'Existing attempt sentinel: inspect actual state/receipt; never repeat the API automatically.'
pins=json.loads((BASE/'full-review-input-pins.json').read_text())
assert head()==HEAD
for name,expected in pins['exact_inputs'].items():assert sha((ROOT/name).read_bytes())==expected,name
packet_raw=(BASE/'full-anti-anchored-reviewer-packet.json').read_bytes();packet=json.loads(packet_raw)
assert sha(packet_raw)==pins['full_packet_raw_sha256']=='bb096873bb361f7f9ac704126b3c4faa78ab266ee6482b4c727ce567f12810f5'
assert sha(canonical({k:v for k,v in packet.items() if k!='packet_sha256'}))==packet['packet_sha256']=='4279d2edebdb52f56851cd8a9d7d736034dd6b48c20875356394dec6edcf00ca'
proposed=(PHASE3/'proposed-canonical-accepted-audit.json').read_bytes();assert sha(proposed)==EXPECTED_PROPOSED
evidence_raw=(PUBLIC/'proposed-normal-verification-evidence.json').read_bytes();assert sha(evidence_raw)==EXPECTED_EVIDENCE
evidence=json.loads(evidence_raw)
item=json.loads((ROOT/'website/content/publications/huanjian-fixed-spectrum-determinant.json').read_text())['items'][0]
lesson=json.loads((ROOT/'website/content/declaration_lessons/huanjian-fixed-spectrum-determinant.json').read_text())['units'][0]
local_data={'declarations':{DECL:SimpleNamespace(source_file='AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumDeterminant.lean')},'lessons':{DECL:lesson}}
binding=publication.binding_digest(item,item['bindings'][0],local_data)
assert binding==packet['publication_binding_sha256']=='c70bb9b23e335acf768bb889f8229fcdf2a7af160e10fa89779d00dcba58374b'

ledger=ROOT/'runs/substantive_advances.jsonl';discovery=ROOT/'runs/substantive_discoveries.jsonl'
before=ledger.read_bytes();before_discovery=discovery.read_bytes();before_states=state(before)
assert sha(before)==pins['exact_inputs']['runs/substantive_advances.jsonl']=='131b121b968af6661a2ae8b394c87945af5827614b373dc23e60f4f138ca11d7'
assert before_states[ADVANCE]['state']=='PROVED_LOCAL'
assert before_states[ADVANCE]['owner_id']==OWNER
foreign_before={k:v for k,v in before_states.items() if k!=ADVANCE};assert len(foreign_before)==282
frontiers_before=frontend()
foreign_frontiers={k:v for k,v in frontiers_before.items() if v['cell_id']!=CELL};assert len(foreign_frontiers)==441
assert len(frontiers_before)-len(foreign_frontiers)==1
audit_path=ROOT/'research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-determinant.json'
audit_before=audit_path.read_bytes();assert sha(audit_before)=='c25115fe897a31cc6f42101af337b3183f3c479c1b9835dd4cbe2e803057fe50'
prior_review_files={str(p.relative_to(ROOT)):sha(p.read_bytes()) for p in BASE.rglob('*') if p.is_file() and not p.is_relative_to(PUBLIC)}
for path,expected in prior_review_files.items():assert sha((ROOT/path).read_bytes())==expected
(PRIVATE/'advance-ledger-before.jsonl').write_bytes(before)
(PRIVATE/'audit-before.json').write_bytes(audit_before)
save(PRIVATE/'foreign-states-before.json',foreign_before)
save(PRIVATE/'all-frontiers-before.json',frontiers_before)
save(PRIVATE/'prior-review-files-before.json',prior_review_files)
save(PUBLIC/'preflight-preservation.json',{'actual_actor':REVIEWER,'checked_immutable_commit':HEAD,'advance_id':ADVANCE,'from_state':'PROVED_LOCAL','proof_owner':OWNER,'foreign_states':len(foreign_before),'foreign_frontiers':len(foreign_frontiers),'advance_ledger_before_sha256':sha(before),'discovery_ledger_before_sha256':sha(before_discovery),'audit_before_sha256':sha(audit_before),'proposed_audit_sha256':sha(proposed),'evidence_sha256':sha(evidence_raw),'publication_binding_sha256':binding,'all_preflight_pins_match':True,'created_at_utc':now()})

# Only this exact independently reviewed canonical audit is installed.
audit_path.write_bytes(proposed)
assert audit_path.read_bytes()==proposed
assert head()==HEAD and ledger.read_bytes()==before
intent={'actual_actor':REVIEWER,'checked_immutable_commit':HEAD,'advance_id':ADVANCE,'API_calls_intended':1,'API':'tools.astis_advance.transition_advance','to_state':'VERIFIED','worker_id':REVIEWER,'evidence_sha256':sha(evidence_raw),'canonical_audit_after_sha256':sha(proposed),'started_at_utc':now(),'retry_policy':'Never repeat automatically; inspect current state and receipt first if uncertain.'}
save(PUBLIC/'API-attempt-intent.json',intent)
capture=io.StringIO();start=time.monotonic();api_error=None;api_calls=0
with contextlib.redirect_stdout(capture),contextlib.redirect_stderr(capture):
 print('ACTUAL_ACTOR',REVIEWER)
 print('CHECKED_IMMUTABLE_COMMIT',HEAD)
 print('API_CALL tools.astis_advance.transition_advance('+ADVANCE+', VERIFIED, worker_id='+REVIEWER+', evidence_sha256='+sha(evidence_raw)+')')
 print('STARTED_AT_UTC',intent['started_at_utc'])
 try:
  api_calls=1
  advance.transition_advance(ADVANCE,'VERIFIED',worker_id=REVIEWER,evidence=evidence)
  print('API_RETURNED_SUCCESS')
 except BaseException:
  api_error=traceback.format_exc();print(api_error)
 print('FINISHED_AT_UTC',now())
 print('API_CALLS',api_calls)
elapsed=time.monotonic()-start
raw_log=capture.getvalue().encode();(PUBLIC/'actual-normal-API.log').write_bytes(raw_log)

# Inspect once after the actual result; never retry this API.
after=ledger.read_bytes();after_states=state(after);after_frontiers=frontend()
append=after[len(before):] if after.startswith(before) else b''
(PUBLIC/'actual-normal-append.jsonl').write_bytes(append)
appended=[json.loads(line) for line in append.splitlines() if line.strip()]
foreign_after={k:v for k,v in after_states.items() if k!=ADVANCE}
prior_unchanged=all((ROOT/path).is_file() and sha((ROOT/path).read_bytes())==expected for path,expected in prior_review_files.items())
preservation={
 'append_only_prefix_preserved':after.startswith(before),
 'all_282_foreign_states_unchanged':foreign_before==foreign_after,
 'all_441_foreign_frontiers_unchanged':all(after_frontiers.get(k)==v for k,v in foreign_frontiers.items()),
 'all_frontiers_including_target_unchanged':frontiers_before==after_frontiers,
 'discovery_ledger_unchanged':discovery.read_bytes()==before_discovery,
 'all_prior_selected_review_results_unchanged':prior_unchanged,
 'producer_Test_lesson_publication_dependencies_unchanged':all(sha((ROOT/name).read_bytes())==expected for name,expected in pins['exact_inputs'].items() if name not in ['runs/substantive_advances.jsonl','research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-determinant.json']),
 'proof_owner_unchanged':after_states[ADVANCE]['owner_id']==before_states[ADVANCE]['owner_id']==OWNER,
 'HEAD_unchanged':head()==HEAD,
 'canonical_audit_exact_reviewed_bytes':audit_path.read_bytes()==proposed,
 'one_actual_append':len(appended)==1,
 'append_is_independent_verified_transition':len(appended)==1 and appended[0].get('advance_id')==ADVANCE and appended[0].get('from_state')=='PROVED_LOCAL' and appended[0].get('to_state')=='VERIFIED' and appended[0].get('worker_id')==REVIEWER and appended[0].get('evidence')==evidence
}
actual_state=after_states[ADVANCE]['state']
success=api_error is None and actual_state=='VERIFIED' and all(preservation.values())
receipt={
 'actual_actor':REVIEWER,'checked_immutable_commit':HEAD,'advance_id':ADVANCE,
 'actual_command':['python3','.astis/huanjian-fixed-spectrum-determinant-20261108/fresh-source-835194/execute_authorized_verification.py'],
 'actual_API':'tools.astis_advance.transition_advance','API_calls':api_calls,
 'started_at_utc':intent['started_at_utc'],'finished_at_utc':now(),'elapsed_seconds':elapsed,
 'exit_code':0 if success else 1,'API_exception':api_error,
 'actual_state':actual_state,'actual_last_actor':after_states[ADVANCE].get('last_actor'),
 'proof_owner_before_after':{'before':before_states[ADVANCE]['owner_id'],'after':after_states[ADVANCE]['owner_id']},
 'append_sha256':sha(append),'append_bytes':len(append),'append_records':len(appended),
 'advance_ledger_before_sha256':sha(before),'advance_ledger_after_sha256':sha(after),
 'discovery_ledger_before_after_sha256':{'before':sha(before_discovery),'after':sha(discovery.read_bytes())},
 'canonical_audit_before_after_sha256':{'before':sha(audit_before),'after':sha(audit_path.read_bytes())},
 'normal_verification_evidence_sha256':sha(evidence_raw),'publication_binding_sha256':binding,
 'raw_API_log_sha256':sha(raw_log),'preservation_checks':preservation,
 'no_STABILIZING_shared_site_remote_action':True,'success':success
}
save(PUBLIC/'actual-verification-preservation-receipt.json',receipt)
artifacts=[]
for base in [PRIVATE,PUBLIC]:
 for path in sorted(base.rglob('*')):
  if path.is_file() and path.name not in ['preservation-manifest.json','preservation-freeze-receipt.json']:
   data=path.read_bytes();artifacts.append({'path':str(path.relative_to(ROOT)),'sha256':sha(data),'bytes':len(data)})
script=Path(__file__);artifacts.append({'path':str(script.relative_to(ROOT)),'sha256':sha(script.read_bytes()),'bytes':len(script.read_bytes())})
manifest={'schema_version':1,'actual_actor':REVIEWER,'checked_immutable_commit':HEAD,'API_calls':api_calls,'actual_state':actual_state,'proof_owner':OWNER,'preservation_checks':preservation,'prior_review_file_count':len(prior_review_files),'artifacts':artifacts,'manifest_hash_rule':'Excludes itself and preservation freeze receipt.'}
save(PUBLIC/'preservation-manifest.json',manifest)
freeze={'actual_actor':REVIEWER,'checked_immutable_commit':HEAD,'API_calls':api_calls,'actual_state':actual_state,'success':success,'preservation_manifest_sha256':sha((PUBLIC/'preservation-manifest.json').read_bytes()),'actual_receipt_sha256':sha((PUBLIC/'actual-verification-preservation-receipt.json').read_bytes()),'append_sha256':sha(append),'advance_ledger_after_sha256':sha(after),'raw_API_log_sha256':sha(raw_log)}
save(PUBLIC/'preservation-freeze-receipt.json',freeze)
print(json.dumps(freeze,indent=2));print('PRESERVATION_CHECKS',json.dumps(preservation,sort_keys=True))
sys.exit(0 if success else 1)
