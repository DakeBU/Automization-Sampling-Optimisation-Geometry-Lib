from pathlib import Path
import re,json
R=Path('/Users/zhouhuanjian/ASTIS-GC')
O=R/'.astis/huanjian-gc-fixed-spectrum-cosine-gram-20261110/source-map-author-1d7a46'
p=R/'.astis/huanjian-resume-20261103/20261110T155942501800Z-cosine-gram-actual-kernel-exact-types-all-owned.log'
s=p.read_text()
parts=[]
for line in s.splitlines():
 if line.startswith(('ACTUAL_','FIRST_','ALL_','OWNED_DECL_REACHABLE','OWNED_DECL_AXIOMS','SOURCE_','MODULE_')):
  parts.append(line)
parts.append('PREFIX '+s[:3200])
(O/'logs/kernel-header-query.stdout').write_text('\n'.join(parts)+'\n')
(O/'logs/kernel-header-query.stderr').write_bytes(b'')
parts=[]
for n,body in re.findall(r'OWNED_DECL_USED ([^:]+): \[(.*?)\]',s,re.S):
 if n.endswith(('actual_gaussian_gram_means','actual_cosine_frame_gram')):
  parts.append('ROOT '+n)
  parts.append('\n'.join(t.strip() for t in body.split(',') if any(x in t for x in ['Gaussian','integr','covariance','PosSemidef','EuclideanSpace.proj','sqrt','two_mul_cos','cos_sq','actual_'])))
(O/'logs/kernel-root-constants-query.stdout').write_text('\n'.join(parts)+'\n')
(O/'logs/kernel-root-constants-query.stderr').write_bytes(b'')
report={'queries_captured':['70321f','a0e279'],'actual_existing_log_only':True,'no_Lean_execution':True}
(O/'logs/kernel-query-capture.stdout').write_text(json.dumps(report)+'\n')
(O/'logs/kernel-query-capture.stderr').write_bytes(b'')
print(json.dumps(report))
