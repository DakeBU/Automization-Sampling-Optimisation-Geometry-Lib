#!/opt/anaconda3/bin/python
import pathlib
from bs4 import BeautifulSoup
BASE = pathlib.Path(__file__).resolve().parent
soup = BeautifulSoup((BASE/'inputs/2610.20492v1.html').read_bytes(), 'html.parser')
def readable(tag):
    other = BeautifulSoup(str(tag), 'html.parser')
    for math in other.find_all('math'):
        math.replace_with(' $' + math.get('alttext', math.get_text(' ', strip=True)) + '$ ')
    return other.get_text('\n', strip=True)
theorem = soup.find(id='S4.Thmtheorem4')
container = theorem.parent
print('CONTAINER', container.get('id'))
print(readable(container))
for item in container.previous_siblings:
    if not getattr(item, 'name', None):
        continue
    print('PRECEDING', item.name, item.get('id'))
    print(readable(item))
    if item.name.startswith('h'):
        break
