"""Create a distinct checker successor with exactly the reviewed natural-anchor observation delta."""
import difflib,hashlib,json
from pathlib import Path
OWN=Path(__file__).resolve().parent;OLD=OWN.parent/'matrix_domain_reader_61e4'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,x):
    with Path(p).open('x') as f:f.write(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
assert sha(OLD/'browser_check.py')=='64101b5e78fe02d97a92650ff397750d387811a576f4932743972c682e183f94'
assert sha(OLD/'browser_geometry.py')=='cc7eb67308d24fd5dbf87345b9e48ac1140ff7879bb05a96e08bc01a13d9efd4'
before=(OLD/'browser_check.py').read_text();s=before
def replace(old,new):
    global s
    assert s.count(old)==1,old
    s=s.replace(old,new)
replace('from browser_geometry import GEOMETRY,VISIBLE,GLYPH,scroll_center,zoom_pan_actual_ui,core_label_readable\n','from browser_geometry import GEOMETRY,VISIBLE,GLYPH,scroll_center,zoom_pan_actual_ui,core_label_readable\nfrom browser_anchor_wait import wait_for_natural_anchor\n')
replace("    assert sha(__file__)==a['runner_sha256'] and sha(OWN/'browser_geometry.py')==a['geometry_sha256']\n","    assert sha(__file__)==a['runner_sha256'] and sha(OWN/'browser_geometry.py')==a['geometry_sha256']\n    assert sha(OWN/'browser_anchor_wait.py')==a['anchor_wait_sha256']\n")
replace('    checks=[];screenshots=[];requests=[];responses=[];console=[];errors=[];blocked=[]\n','    checks=[];screenshots=[];requests=[];responses=[];console=[];errors=[];blocked=[];anchor_traces=[]\n')
replace("                        anchor=page.locator('#L'+str(first));g=anchor.evaluate(VISIBLE)\n","                        anchor=page.locator('#L'+str(first));settling=wait_for_natural_anchor(page,anchor,VISIBLE);g=settling['settled_geometry']\n                        anchor_traces.append({'case':label+'-step'+str(i+1),'target':page.url,**settling})\n                        check(label+'-step'+str(i+1)+'-natural-source-anchor-stable',settling['stable'])\n")
replace("                        g=page.locator('#L'+str(anchor)).evaluate(VISIBLE)\n","                        settling=wait_for_natural_anchor(page,page.locator('#L'+str(anchor)),VISIBLE);g=settling['settled_geometry']\n                        anchor_traces.append({'case':label+'-source-'+source_label,'target':page.url,**settling})\n                        check(label+'-'+source_label+'-natural-source-anchor-stable',settling['stable'])\n")
replace("'checks':checks,'screenshots':screenshots,'requests':requests","'checks':checks,'natural_source_anchor_stability_traces':anchor_traces,'screenshots':screenshots,'requests':requests")
with (OWN/'browser_check.py').open('x') as f:f.write(s)
with (OWN/'browser_geometry.py').open('xb') as f:f.write((OLD/'browser_geometry.py').read_bytes())
diff=''.join(difflib.unified_diff(before.splitlines(True),s.splitlines(True),fromfile='preserved-original641/browser_check.py',tofile='new-successor/browser_check.py'))
with (OWN/'browser-check-only-natural-anchor-wait.exact.diff').open('x') as f:f.write(diff)
write(OWN/'mechanism-custody.json',{'schema':'R17-distinct-successor-mechanism-custody-v1','old_runner_sha256':sha(OLD/'browser_check.py'),'new_runner_sha256':sha(OWN/'browser_check.py'),'geometry_byte_exact_unchanged_sha256':sha(OWN/'browser_geometry.py'),'anchor_wait_sha256':sha(OWN/'browser_anchor_wait.py'),'exact_diff_sha256':sha(OWN/'browser-check-only-natural-anchor-wait.exact.diff'),'only_runtime_delta':'Generic observational natural-source-anchor settling before all22 pre-existing step/direct-source anchor readability predicates. Adds22 stability checks and full immediate/settled traces. Original strict positive-intersection/header predicates, glyph tolerance, graph clipping/font thresholds, screenshots and other actions remain byte-identical.','source_index_boundary':'Source-index link checks still test actual URL/unique anchor identity only; they were not source-anchor readability predicates. No new target scroll or scroll disable is introduced.','observational_helper_has_no_scroll_style_transform_animation_write':True,'existing_scroll_center_for_disclosure_graph_and_glyph_interactions_not_changed':True,'old_runtime_501_3false_exit1_and50PNG_untouched':True,'no_old_or_diagnostic_acceptance_inherited':True,'runtime_not_executed':True})
print(json.dumps({'runner_sha256':sha(OWN/'browser_check.py'),'geometry_sha256':sha(OWN/'browser_geometry.py'),'anchor_wait_sha256':sha(OWN/'browser_anchor_wait.py'),'diff_sha256':sha(OWN/'browser-check-only-natural-anchor-wait.exact.diff')}))
