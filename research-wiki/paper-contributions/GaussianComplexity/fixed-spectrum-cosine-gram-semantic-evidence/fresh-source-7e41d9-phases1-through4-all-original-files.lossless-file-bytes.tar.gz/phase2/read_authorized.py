#!/opt/anaconda3/bin/python
import hashlib
import json
import pathlib
BASE=pathlib.Path(__file__).resolve().parent
paths=[('/Users/zhouhuanjian/ASTIS-GC/research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-cosine-gram-semantic-evidence/selective-fresh-source-phase2-input.json',9323,'92a4b1401ec63ee22409929bd3c6528b1b25bbc822066a3944a8c9f0bbfca173'),
('/Users/zhouhuanjian/ASTIS-GC/.astis/huanjian-gc-fixed-spectrum-cosine-gram-20261110/minimal-extra-law-definitions.pure-v2.json',6369,'049827eefa3ef85667ac175f5de2a7e264cc00733adb50d0bfe8d21711422dcd')]
records=[]
(BASE/'inputs').mkdir(exist_ok=True)
for name,size,expected in paths:
    path=pathlib.Path(name); data=path.read_bytes()
    digest=hashlib.sha256(data).hexdigest()
    assert len(data)==size and digest==expected,(name,len(data),digest)
    (BASE/'inputs'/path.name).write_bytes(data)
    records.append({'path':name,'bytes':len(data),'sha256':digest,'snapshot':'inputs/'+path.name})
    print('AUTHORIZED_INPUT',json.dumps(records[-1]))
    print(data.decode())
(BASE/'input_inventory.json').write_text(json.dumps(records,indent=2)+'\n')
