# R17 matrix-MGF-domain topology challenge: raw-first freeze v1

Status: RAW_FIRST_CHECKLIST_FROZEN; graph not received or inspected; no admission or proof verdict.

Owned review directory: `.astis/semantic-neutral-20261115/matrix_domain_tc_79ad/`.
This is a distinct SOURCE-only topology challenge. No implementation Lean,
old graph/verdict, extractor private rationale, ledger, API, or shared metadata
was read or mutated for the mathematical review. No target proof search ran.

## Pinned evidence and read order

1. Read `AGENTS.md` and `docs/proof-digestion-protocol.md`.
2. Rehashed both raw source bytes, before reading any graph:
   - Tropp author preprint: SHA-256 `f4c3cff8661011395e793972a1f8d9a199fae4ca0fd098535d7a42166cf8fc86`.
   - Gaussian HTML: SHA-256 `6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915`.
3. Independently read raw-source conversions: Tropp §§2.1–2.7, §§3.1–3.6,
   Theorem 6.1 and Lemma 6.7/proof; Gaussian Lemma 4.4 and Appendix C.2,
   including Fact C.5, all Fact C.6 proof paragraphs, and the final Lemma 4.4
   transfer. Visually inspected complete Tropp PDF pages 8–11. Checked raw
   HTML ids `A3.Ex107`–`A3.Ex112`, `A3.Ex121`, `A3.SS2.p15.2`.
4. Only after these raw reads, read and rehashed the exact author interface:
   - statement seal SHA-256 `1b52776e9793f302109cb649dd0c82c666193086aa7546006e36651ee389e638`;
   - binder/definition audit SHA-256 `ab17ddb4d2b402194af7b4668054d580956a80a103da938a25978d94e03e7744`.
   Author labels and the inherited status wording are not an independent verdict.

## Frozen challenge checklist

1. **Exact roots.** Graph must bind the exact seal, exact P and T statement
   digests, exact literal-definition audit, and the two pinned source hashes.
   All scoped conclusions of T must have a backward route, including true
   matrix integrability, PD mean, trace commutation, positive trace, and bound.
2. **Source provenance.** P is the author-stated generic probability/AE-PD
   Bochner-integral library fact, not a printed Tropp theorem. T is an omitted
   source-derived finite/PD-domain bridge. No author-derived bridge may be
   labeled a printed result, Lean theorem, or completed source proof.
3. **Tropp coverage.** Account for finite square matrices, self-adjointness,
   spectral functional calculus, regularity convention (§2.2), exponential
   PD (§2.4), the logarithm's PD cone (§2.5), expectation preserving PSD
   order (§2.7), and §3.1's explicit caveat that exponential expectations
   need not exist for every real parameter. Printed all-moments language
   does not discharge exponential integrability. Downstream §3.3–3.6 and
   §6.1 must be context or explicitly excluded, never used to assume T.
4. **Gaussian coverage.** Explicitly disposition C.2 setup/Fact C.5 feature
   norm bound; truncation definition Ex107; radial mean formula and 0≤a≤1
   paragraph Ex108–109; actual mean formula; Ex110; centered definition;
   Ex111–112; weighted-radius sentence; Bernstein consumer Ex121/p15.2.
   Tail/bias, covariance/variance, probability budgets, simplification and
   final Krylov transfer may be excluded with a precise scope reason.
5. **Full law and indices.** T retains Ω=(Fin(q+1)→D) and the full product of
   standard d-dimensional Gaussian laws. Row i is `((g_b)_i)_b`; the true
   law of this row and any covariance/radial identities must be derived or
   explicitly cited. Independence is not a newly assumed public premise.
6. **Literal definitions.** Retain q+1 probes/features, q=0, r=q+1,
   midpoint α=(i+1−1/2)π/d, zeroth feature exactly 1, √2 cosine features,
   Gaussian-first/feature-second Kronecker order, dimension r², d⁻¹ scaling,
   and inclusive own-row `‖row i ω‖²≤L` with L=2r+3log(1000d).
7. **Actual means.** `mean i=∫Y_i dμ` is a full-law Bochner integral;
   centered Z uses that mean. No symbolic aI substitution or totalized
   integral is allowed to hide unproved Y integrability. The source's
   Eγγᵀ1=aI route requires its own radial-symmetry and moment obligations.
8. **T binder boundary.** Only natural d,q and hq:2q+1<d, then all real s
   and the two Bool choices are public data. Derive d≥2, r≥1, positivity,
   probability normalization, measurability, integrability, Hermitian
   sums and finite bounds internally. No τ≤1/2, C sufficiently large,
   typical event, moment/variance bound, norm bound, witness or gate becomes
   a binder. P's integrability and AE-PD hypotheses must be discharged in T.
9. **Four cases and endpoints.** Cover (ordinary,+), (ordinary,−),
   (cosine,+), (cosine,−), all s∈ℝ including 0 and negative s, and q=0.
   The minus choice is a global sign, not a new random sign or an equality
   in law. |cos|≤1 and |sign|=1 explain the shared bound.
10. **Radius scope.** R*=2r(L+1)/d must be produced from the source's
    separate `‖Y_i‖≤2rL/d` and `‖EY_i‖≤2r/d` routes, with consumer site
    Ex112. The weaker `‖EY_i‖≤2rL/d` alone does not supply this exact R*.
    The sum has deterministic radius dR*, not R* and not a variance term.
11. **True exponential.** G is the matrix-algebra exponential exp(sS),
    never entrywise exp, exp(E[sS]), E of trace only, or product of separate
    exponentials. Noncommutativity may not be bypassed by a scalar mgf
    multiplication rule (§3.3 warns explicitly against it).
12. **Integrability route.** Measurable bounded Y → actual mean; Hermitian
    bounded Z → all signed weighted S; continuous exp and a finite
    deterministic norm envelope → Bochner-integrable G under probability μ.
    Source omissions here remain SOURCE_GAP/author-derived bridge nodes.
13. **PD route.** Self-adjoint sS → pointwise PD G via spectral exp; generic
    P then gives PD MX. Integrability and probability mass are essential
    inputs to P. Positive trace, or PSD plus positive trace, is insufficient
    (diag(1,0) is a counterexample). No uniform spectral lower bound is
    silently required by P, nor is an arbitrary zero measure permitted.
14. **Trace route.** Finite-dimensional trace commutes with the proved
    Bochner integral; PD and nonempty dimension r² give positive trace.
    The unnormalized bound is exactly
    `r² exp(|s| ((d:ℝ)R*))`; the factor r² cannot be r or d, and μ(univ)=1
    must be used. The scalar envelope is author-derived, not a paper variance
    or Bernstein estimate. No universal C or probability budget enters it.
15. **Consumer sites/directions.** Each prerequisite edge names where it is
    consumed, not only its producer location. Bounds/regularity flow toward
    G integrability/PD/trace and T; T is preparatory to a possible true-MGF
    log-domain consumer. Ex121 is downstream context, not proof input.
16. **AND/OR semantics.** Dependencies jointly necessary for one selected
    route may form an AND. Alternative radial/PSD-order mean routes,
    alternative strict-integral arguments, or alternative exponential
    norm arguments must stay explicit OR routes, never one inflated AND.
    Ordinary/cosine and ± cases are coverage cases, not competing proofs.
17. **Hidden external inputs.** Name Gaussian law/covariance/radial
    symmetry, Euclidean/Kronecker operator norm and symmetry facts,
    measurability, bounded integrability, spectral exp/norm estimate,
    strict positivity of the probability integral, and finite trace
    continuity where actually needed. Mere import or theorem-name lists
    are not mathematical discharge. No implementation topology may decide
    the author's route.
18. **SOURCE_GAP honesty and bounded verdict.** Omitted full matrix-MGF
    well-definedness and PD-integral infrastructure remain visible gaps/
    author-derived bridges. A complete source topology may represent an
    unproved gap; it cannot certify its Lean closure. No matrix log theorem,
    Lieb/master-tail/Bernstein proof, C.6 proof, main lower bound, oracle,
    precision/cost adapter, public completion or Goal completion is claimed.

Next action: await the parent's exact graph capsule path/hash, then test it
against this frozen checklist without reading extractor private rationale.
