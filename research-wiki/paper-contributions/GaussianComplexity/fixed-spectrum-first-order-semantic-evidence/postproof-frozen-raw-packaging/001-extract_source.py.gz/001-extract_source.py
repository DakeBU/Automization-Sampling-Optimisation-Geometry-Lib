from html.parser import HTMLParser
from pathlib import Path
import hashlib, json, shutil

ROOT = Path('/Users/zhouhuanjian/ASTIS-GC')
OUT = ROOT / '.astis/semantic-neutral-20261108/src_4e8f6a/phase1'
SOURCE = ROOT / '.astis/huanjian-resume-20261103/2610.20492v1.html'

class Node:
    def __init__(self, tag='', attrs=(), line=0):
        self.tag, self.attrs, self.line, self.children = tag, dict(attrs), line, []

class Parser(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.root = Node('root')
        self.stack = [self.root]
        self.ids = {}
    def handle_starttag(self, tag, attrs):
        node = Node(tag, attrs, self.getpos()[0])
        self.stack[-1].children.append(node)
        if 'id' in node.attrs:
            self.ids[node.attrs['id']] = node
        if tag not in {'area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr'}:
            self.stack.append(node)
    def handle_startendtag(self, tag, attrs):
        self.handle_starttag(tag, attrs)
        if self.stack[-1].tag == tag:
            self.stack.pop()
    def handle_endtag(self, tag):
        for index in range(len(self.stack)-1, 0, -1):
            if self.stack[index].tag == tag:
                del self.stack[index:]
                return
    def handle_data(self, data):
        self.stack[-1].children.append(data)

BLOCKS = {'section','div','p','h1','h2','h3','h4','h5','h6','li','table','tr','blockquote','figure','figcaption','dl','dt','dd'}
def render(node):
    if isinstance(node, str):
        return node
    if node.tag == 'math':
        return ' $' + node.attrs.get('alttext', '') + '$ '
    if node.tag in {'script','style'}:
        return ''
    ident = node.attrs.get('id')
    mark = ('\n['+ident+'; HTML line '+str(node.line)+']\n') if ident and node.tag in BLOCKS else ''
    body = ''.join(render(c) for c in node.children)
    if node.tag in BLOCKS:
        return '\n' + mark + body + '\n'
    if node.tag == 'br':
        return '\n'
    return body

raw = SOURCE.read_bytes()
assert len(raw) == 951991
assert hashlib.sha256(raw).hexdigest() == '6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
parser = Parser()
parser.feed(raw.decode())
paths = [SOURCE, ROOT/'AGENTS.md', ROOT/'.agents/skills/astis-semantic-roundtrip/SKILL.md', ROOT/'docs/proof-digestion-protocol.md', ROOT/'docs/theorem-publication-protocol.md', ROOT/'docs/evidence-routed-memory-protocol.md']
inventory = []
for p in paths:
    dest = OUT/'inputs'/p.name
    shutil.copyfile(p, dest)
    b = p.read_bytes()
    inventory.append({'original_path': str(p), 'snapshot':str(dest.relative_to(OUT)), 'bytes':len(b), 'sha256':hashlib.sha256(b).hexdigest()})
(OUT/'inputs_manifest.json').write_text(json.dumps(inventory, indent=2)+'\n')
for ident in ['S1','S2','S4','A3.SS4']:
    value = render(parser.ids[ident])
    lines = [' '.join(line.split()) for line in value.splitlines()]
    text = '\n'.join(line for line in lines if line)
    dest = OUT/'extracted'/(ident+'.txt')
    dest.write_text(text+'\n')
    print(ident, len(text), 'chars', 'first:', text[:180])

