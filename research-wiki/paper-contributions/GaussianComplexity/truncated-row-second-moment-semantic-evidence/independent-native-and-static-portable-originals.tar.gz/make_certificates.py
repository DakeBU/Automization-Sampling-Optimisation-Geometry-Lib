from pathlib import Path
import json,hashlib,subprocess
R=Path.cwd();O=R/'.astis/semantic-neutral-20261111/rc_native_68bc';s=json.loads((O/'inputs/statement-seal-v2.exact.json').read_text());P=s['producer']['name'];T='_private.Tests.GaussianComplexityFixedSpectrumTruncatedRowMoment.0.'+s['actual_private_consumer']['name']
for k in ['producer','actual_private_consumer']:
 assert hashlib.sha256(s[k]['signature'].encode()).hexdigest()==s[k]['signature_sha256']
p='import Tests.GaussianComplexityFixedSpectrumTruncatedRowMoment\nimport Lean.Util.CollectAxioms\nimport Lean.Util.FoldConsts\nnoncomputable section\nopen MeasureTheory ProbabilityTheory\nopen scoped Matrix.Norms.L2Operator\nset_option autoImplicit false\nnamespace Native68bc\n'
p+='theorem public_seal_certificate\n    '+s['producer']['signature'].rstrip()+' := by\n  exact '+P+' hq\n\n'
p+='theorem private_seal_certificate\n    '+s['actual_private_consumer']['signature'].rstrip()+' := by\n  exact '+T+' hq i\n\n'
p+='end Native68bc\n\n#print axioms Native68bc.public_seal_certificate\n#print axioms Native68bc.private_seal_certificate\n#print '+P+'\n#print '+T+'\n'
p+='\n#print Matrix.instL2OpNormedAddCommGroup\n#print Matrix.l2OpNormedAddCommGroupAux\n#print Matrix.l2_opNorm_def\n#print EuclideanSpace\n#print ProbabilityTheory.stdGaussian\n#print Matrix.vecMulVec\n#print Set.indicator\n#print Matrix.kronecker\n#print WithLp.ofLp\n'
p+='''\nopen Lean Elab Command
private def owned68bc (n : Name) : Bool :=
  n.toString.startsWith "AutoSamplingTheory." || n.toString.startsWith "_private.Tests.GaussianComplexityFixedSpectrumTruncatedRowMoment."
run_elab do
  let env ← getEnv
  let targets := #[`'''+P+''', `'''+T+''']
  let mut frontier := targets.toList
  let mut visited : NameSet := {}
  while !frontier.isEmpty do
    let n := frontier.head!
    frontier := frontier.tail!
    if !visited.contains n then
      visited := visited.insert n
      let some c := env.find? n | throwError "missing target {n}"
      let ds := c.getUsedConstantsAsSet.toList
      let bodyDs := match c.value? (allowOpaque := true) with
        | some v => v.getUsedConstants.toList
        | none => []
      let axs ← collectAxioms n
      logInfo m!"OWNED_DECL {n}"
      logInfo m!"BODY_DIRECT {n}: {bodyDs}"
      logInfo m!"OWNED_DIRECT {n}: {bodyDs.filter owned68bc}"
      logInfo m!"AXIOMS {n}: {axs}"
      for dep in ds do
        if owned68bc dep && !visited.contains dep then frontier := dep :: frontier
  logInfo m!"REACHABLE_OWNED {visited.toList}"
'''
(O/'native-src/Certificates.lean').write_text(p)
b=subprocess.check_output(['git','show','86c9bb627c61955f2a47f492c59a044230536739:research-wiki/paper-contributions/GaussianComplexity/truncated-row-second-moment-semantic-evidence/preseal-exposure-correction.json']);assert hashlib.sha256(b).hexdigest()=='1cc398074722d3e54ba5d86b64dfbc41088bb8bb7089b35c256df45b3a70936c';(O/'inputs/preseal-exposure-correction.exact.json').write_bytes(b)
print('Generated sealed certificates from exact frozen signature strings; correction retained without rewriting historical seal.')
