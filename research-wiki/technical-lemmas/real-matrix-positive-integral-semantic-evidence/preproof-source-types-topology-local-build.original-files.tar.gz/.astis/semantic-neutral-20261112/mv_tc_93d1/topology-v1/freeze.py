from pathlib import Path
from collections import Counter
import datetime
import hashlib
import json
import runpy
import sys

ROOT = Path('/Users/zhouhuanjian/ASTIS-GC')
OWN = ROOT/'.astis/semantic-neutral-20261112/mv_tc_93d1'
DEST = OWN/'topology-v1'
SG = ROOT/'.astis/semantic-neutral-20261112/mv_sg_42f6/source-graph-freeze-v1'
INPUTS = {
    'freeze-manifest.json':'7ffb2efb54166fe004c4369751daa953fc07bfcf772bbad159baaf92e9aace8b',
    'freeze-manifest.sha256':'54434636c135011f1bf493dd54c225b668605ec0faf668cb49bfd16de32c6470',
    'source-proof-graph.json':'83d87c553a977e0010ed376a7590d3430b73959600108b041c9c1bfb66271f09',
    'post-seal-coverage.json':'a5f9b7e5bf7c7661d4d7ad12f832f2af5f3f18e9bf89463c476ef9f5ddabae09',
    'internal-ports-and-source-gaps.json':'96e839165132fd33b5ae7364c3c834e61a22da9b49c968fb3b0017da673fb80d',
    'README.md':'6f640f1d5de79cecc886de9c4c592a62a67c47d037c54da6bdfbf831251b7371',
    'source-reading-report.md':'c949223146137843229d8d2c48a1e542463d242f3151384814eaa4df1b85cfa5',
    'graph-input-exposure-chronology.json':'43d68cf42e64554d22385b01eb21fc3bdaa5a2d7dfa5d2938cb5fbca6faa5adc',
}

def sha(b):
    return hashlib.sha256(b).hexdigest()

def digest(path):
    b = path.read_bytes()
    return {'path':str(path.relative_to(ROOT)), 'bytes':len(b), 'sha256':sha(b)}

def write(name,obj):
    (DEST/name).write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n')

docs = {}
for name,val in INPUTS.items():
    assert digest(SG/name)['sha256'] == val
    if name.endswith('.json'):
        docs[name] = json.loads((SG/name).read_text())
g = docs['source-proof-graph.json']
c = docs['post-seal-coverage.json']
p = docs['internal-ports-and-source-gaps.json']
manifest = docs['freeze-manifest.json']
assert (SG/'freeze-manifest.sha256').read_text().split()[0] == INPUTS['freeze-manifest.json']
manifest_rows = {a['path']:a for a in manifest['files']}
for name in INPUTS:
    if name in manifest_rows:
        assert manifest_rows[name]['sha256'] == INPUTS[name]
        assert manifest_rows[name]['bytes'] == digest(SG/name)['bytes']
unopened = [a for a in manifest['files'] if a['path'].startswith('inputs/')]
assert len(unopened) == 4
packetpath = ROOT/'.astis/huanjian-gc-source-matrix-variance-20261112/selective-type-definition-packet.json'
assert digest(packetpath)['sha256'] == 'b9b93126880486157e88e9a59abcd2b89d81b4cf34d46fa9dc51f88d2b6e0170'
packet = json.loads(packetpath.read_text())
expected = {
    'statement_seal_sha256':packet['statement_seal_sha256'],
    'packet_sha256':digest(packetpath)['sha256'],
    'producer_signature_sha256':packet['producer']['signature_sha256'],
    'consumer_signature_sha256':packet['actual_private_consumer']['signature_sha256'],
    'definition_context_sha256':packet['minimal_definition_context_sha256'],
    'mathlib_pin':packet['minimal_definition_context']['mathlib_pin'],
}
for doc in [g,c,p,manifest,docs['graph-input-exposure-chronology.json']]:
    for key,val in expected.items():
        assert doc['bindings'][key] == val
    assert doc['bindings'] == g['bindings']

preserved = []
for rel in ['SHA256SUMS','type-v1/SHA256SUMS']:
    sums = OWN/rel
    for line in sums.read_text().splitlines():
        val,name = line.split('  ',1)
        assert digest(sums.parent/name)['sha256'] == val
        preserved.append(digest(sums.parent/name))
    preserved.append(digest(sums))
assert digest(OWN/'raw-freeze.json')['sha256'] == 'c0bf670eba58674aac8b29d8fd313428955e76f13c20680ae47c84f1f4b536db'
assert digest(OWN/'type-v1/freeze.json')['sha256'] == '0ea162c064a81d8403a1b5152c2b863790d161eebeea10ade73e3f2d5b7c9cab'
rawinput = json.loads((OWN/'input-manifest.json').read_text())
old_counts = {}
for label,rows in rawinput['prior_R7_R8_preserved_by_checksum_manifests'].items():
    for a in rows:
        assert digest(ROOT/a['path'])['sha256'] == a['sha256']
    old_counts[label] = len(rows)

sourcepath = ROOT/packet['source']['raw']
raw = sourcepath.read_bytes()
source = raw.decode()
assert sha(raw) == packet['source']['raw_sha256'] == '6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
occurrences = []

def walk(x,path):
    if isinstance(x,dict):
        if 'utf8_byte_start' in x:
            a,b = x['utf8_byte_start'],x['utf8_byte_end_exclusive']
            u,v = x['unicode_char_start'],x['unicode_char_end_exclusive']
            checks = {
                'raw_sha256':sha(raw[a:b]) == x['raw_fragment_sha256'],
                'unicode_utf8_map':source[u:v].encode() == raw[a:b],
                'LF_start':raw[:a].count(b'\n')+1 == x['lf_line_start_1based'],
                'LF_inclusive_end':raw[:b-1].count(b'\n')+1 == x['lf_line_end_1based'],
            }
            assert all(checks.values()),(path,checks)
            occurrences.append({'record_path':path,'locator':x,'checks':checks})
        for key,val in x.items():
            walk(val,path+'/'+key)
    elif isinstance(x,list):
        for n,val in enumerate(x):
            walk(val,path+'/'+str(n))

for name,doc in docs.items():
    walk(doc,name)
assert len(occurrences) == 374
assert len({(a['locator']['utf8_byte_start'],a['locator']['utf8_byte_end_exclusive']) for a in occurrences}) == 90
sys.argv = [str(OWN/'read_raw.py'),'silent']
reader = runpy.run_path(str(OWN/'read_raw.py'))
by_id = reader['by_id']
units = [n.attrs['id'] for n in reader['r'].nodes if n.start>=731260 and n.end and n.end<=828341
         and n.tag in ['p','table'] and 'id' in n.attrs]
assert len(units) == 67 and units == [a['element_id'] for a in c['units']]
assert len(c['items']) == len({a['id'] for a in c['items']}) == 105
assert len({a['source_element_id'] for a in c['items']}) == 77
assert Counter(a['disposition'] for a in c['items']) == {'NODE':50,'EXCLUDED':55}
for a in c['items']:
    assert not a['disposition_changed'] and a['post_seal_disposition'] == a['disposition']
    ownloc = by_id[a['source_element_id']].locator()
    assert ownloc['raw_fragment_sha256'] == a['locator']['raw_fragment_sha256']
p15 = [a for a in c['items'] if a['source_element_id'].startswith('A3.SS2.p15') or a['source_element_id']=='A3.Ex121']
assert len(p15) == 6 and all(a['disposition']=='EXCLUDED' for a in p15)

def atom_comment(a):
    name = a['id']
    if a['disposition']=='EXCLUDED':
        if name.startswith('bernstein.'):
            return 'Entire p15 Bernstein context is excluded; no independence, mean-zero or self-adjoint certificate is borrowed from it.'
        if name.startswith('firstmean.'):
            return 'Exact scalar-a/first-mean formulas are not prerequisites for actual generic centering; actual Y integrability remains an explicit internal port.'
        if name.startswith('norm.') or name=='center.norm-prelude':
            return 'R-star summand/operator bounds are outside this variance delta; the separate scalar cosine bound is retained where needed.'
        return 'Raw clause matches the stated outside-target B/range/weighted-frame/tail/bias/concentration context and supplies no new prerequisite certificate.'
    if name=='fourth.invocation':
        return 'The exact source invokes untruncated Gaussian fourth moments. The graph explicitly clarifies raw retained-unrestricted editorial wording; no indicator is added to Ex113.'
    if name.startswith('fourth.'):
        return 'Exact untruncated r+2 matrix moment/sign/diagonal source content retained; actual law and weighted integrability applications remain unproved.'
    if name.startswith('square.'):
        return 'Exact ordinary matrix-square/PSD/tensor/frame aggregate source step retained, with integrability, Hermitian/quadratic order and constants discharged only internally later.'
    if name.startswith('center.') or name.startswith('weighted.'):
        return 'Literal actual centering or source expected-square/variance comparison retained; no commutativity, independence, mean certificate or PSD-to-norm shortcut.'
    if name=='weight.cos-bound':
        return 'Source scalar |cos|<=1 retained separately from excluded R-star context; both 0<=w^2 and w^2<=1 still require internal use.'
    if name.startswith('c5.'):
        return 'Source unweighted feature norm/Gram proof, coordinate cases and frequency/normalization conditions match; q=0 is preserved and weighted cancellation is not substituted.'
    return 'Literal source standing/experiment/grid/actual-object or typing context matches the fixed source/type boundary, with no extra public premise.'

write('atom-review.json',{'version':1,'items':[
    {'ordinal_1based':n+1,'id':a['id'],'source_element_id':a['source_element_id'],
     'semantic_slice':a.get('semantic_slice'),'disposition':a['disposition'],
     'review':'ACCEPT_BOUNDED_RAW_SOURCE_DISPOSITION','independent_comment':atom_comment(a),
     'locator':a['locator'],'actual_source_element_read_and_hash_checked':True,
     'formal_proof_credit':False} for n,a in enumerate(c['items'])]})

ids = {n['id'] for n in g['nodes']}
assert len(g['nodes']) == 80 and len(g['edges']) == 129
assert {n['id'] for n in g['nodes'] if 'source_element_id' in n} == {a['id'] for a in c['items'] if a['disposition']=='NODE'}
assert all(e['from'] in ids and e['to'] in ids and e['compiled_dependency'] is False for e in g['edges'])
assert not any(s['element_id'].startswith('A3.SS2.p15') or s['element_id']=='A3.Ex121' for e in g['edges'] for s in e['consumer_use_sites'])
assert len(g['hyperedges']) == 2
expected_OR = {
    'INTERNAL.tensor-transport':['INTERNAL.tensor-CLM','INTERNAL.tensor-entries'],
    'INTERNAL.Y-integrable':['INTERNAL.Y-integrable-direct','INTERNAL.Y-integrable-reuse'],
}
for h in g['hyperedges']:
    assert h['premise_formula'] == ' OR '.join(expected_OR[h['conclusion']])
or_links = [(f,t) for t,fs in expected_OR.items() for f in fs]

def ancestors(root):
    result = {root}
    while True:
        old = set(result)
        for e in g['edges']:
            if e['to'] in result:
                result.add(e['from'])
        for f,t in or_links:
            if t in result:
                result.add(f)
        if old == result:
            return sorted(result)

formal_closures = {name:ancestors(name) for name in g['roots']}
source_roots = ['square.sum-final','center.variance-assertion','weighted.variance-assertion']
source_closures = {name:ancestors(name) for name in source_roots}
covered = set().union(*(set(v) for v in list(formal_closures.values())+list(source_closures.values())))
context = {'c2.indices','c2.B-context','c5.feature-indices'}
assert len(covered)==77 and covered|context==ids
remaining = set(ids)
pairs = [(e['from'],e['to']) for e in g['edges']]+or_links
while remaining:
    ready = {n for n in remaining if not any(t==n and f in remaining for f,t in pairs)}
    assert ready,'cycle'
    remaining -= ready
write('root-coverage.json',{
    'version':1,'formal_root_reverse_closures_OR_expanded_for_review_only':formal_closures,
    'source_endpoint_reverse_closures':source_closures,
    'source_correspondence_links_not_theorem_premises':[
        {'formal_root':'FORMAL.producer','source_endpoint':'square.sum-final',
         'basis':'Ex117 exact source inequality and INTERNAL.uncentered-algebra/OUTPUT.uncentered-PSD consumer-use sites match the fixed producer signature.'},
        {'formal_root':'FORMAL.private-consumer','source_endpoints':['center.variance-assertion','weighted.variance-assertion'],
         'basis':'Both internal PSD-to-norm ports and output consumer-use sites match p14.5/Ex119 and p14.6/Ex120; source assertions are specifications, not caller certificates.'}
    ],
    'source_and_formal_union':77,'explicit_nonproof_typing_normalization_context':sorted(context),
    'all_80_nodes_accounted':True,'unexplained_nodes':[],
    'acyclic_with_explicit_OR_links':True,
    'OR_policy':'Both alternatives are listed for coverage review only, not simultaneously required in a proof.',
    'compiled_proof_root_closure_certified':False,
})

def edge_comment(e):
    kind = e['kind']
    if 'alternative' in kind:
        return 'One alternative internal method only; explicit OR result is not an AND or a guessed compiled provider.'
    if kind.startswith('Direct source') or kind.startswith('Explicit source'):
        return 'Direction and exact original consumer-use site match the source clause; no compiled proof credit.'
    if 'Sealed target' in kind:
        return 'Corresponds to the fixed output under actual definitions only; this is not proof or a supplied theorem premise.'
    if 'norm' in kind:
        return 'Both lower PSD and C-I upper PSD, actual Euclidean operator norm and C nonnegativity remain internal; upper domination alone is insufficient.'
    if 'INTERNAL' in kind:
        return 'Correct open applicability/integrability/order/noncommutative integral obligation, never a new public hypothesis or checked API application.'
    return 'Source-supported omitted derivation remains explicit and unproved, without source assertions being assumed as formal certificates.'

write('edge-review.json',{'version':1,'edges':[
    {'ordinal_1based':n+1,'from':e['from'],'to':e['to'],'kind':e['kind'],
     'review':'ACCEPT_SOURCE_OR_OPEN_INTERNAL_TOPOLOGY','independent_comment':edge_comment(e),
     'consumer_use_sites':e['consumer_use_sites'],'all_locator_checks_pass':True,
     'compiled_dependency_verified':False} for n,e in enumerate(g['edges'])],
    'OR_reviews':[{'id':h['id'],'conclusion':h['conclusion'],'formula':h['premise_formula'],
                   'review':'ACCEPT_ALTERNATIVE_ROUTES_ONLY','selected_or_proved_route':None}
                  for h in g['hyperedges']]})

assert len(p['ports']) == 23
assert {a['id'] for a in p['ports']} == {n['id'] for n in g['nodes'] if n['id'].startswith('INTERNAL.')}
assert not g['compiled_parents'] and not g['genuine_source_gaps'] and not p['genuine_source_gaps']
port_additions = {
    'INTERNAL.centering-algebra':'Must also justify the integrable constant M^2 term and mu(total)=1, alongside both YM and MY terms. No commutativity or probability certificate becomes a binder.',
    'INTERNAL.weighted-order':'Both 0<=w_i^2 and w_i^2<=1, scalar-square identity and lower PSD of weighted expected-square/sum must be established internally.',
    'INTERNAL.weighted-PSD-to-norm':'The actual weighted sum needs lower as well as upper Loewner bounds, not merely a relabelled upper-order statement.',
    'INTERNAL.row-law':'Match physical coordinate/basis semantics and same actual product mu; no ambient transfer or name-only Gaussian application.',
    'INTERNAL.Y-integrable-reuse':'Optional reuse branch remains unproved/unselected; an actually public provider with exact applicability is required if selected, and private tests supply none.',
}
write('port-review.json',{'version':1,'genuine_blockers':[],'ports':[
    {'id':a['id'],'kind':a['kind'],'obligation':a['obligation'],
     'review':'EXPECTED_STILL_UNPROVED_INTERNAL_MATHEMATICAL_APPLICABILITY_PORT',
     'independent_required_discharge_note':port_additions.get(a['id'],'Exact fixed source/type hypotheses must be discharged internally; no current proof or API application is certified.'),
     'still_open':True,'source_coverage_blocker':False,'public_binder':False,
     'compiled_provider_or_application_verified':False} for a in p['ports']],
    'alternative_policy':'All 23 records remain open; the two OR pairs are not requirements to prove both alternatives.'})
write('locator-checks.json',{'version':1,'source':digest(sourcepath),'occurrences':374,
                           'unique_raw_spans':90,'all_checks_pass':True,'checks':occurrences})
write('input-manifest.json',{
    'public_SG_inputs':[digest(SG/name) for name in INPUTS],
    'unopened_SG_snapshot_references_as_manifest_metadata_only':unopened,
    'unopened_snapshot_bytes_or_hashes_independently_checked':False,
    'fixed_type_packet':digest(packetpath),'exact_fixed_type_bindings_checked':expected,
    'prior_R9_raw_type_records_preserved':preserved,'prior_R7_R8_preservation_counts':old_counts,
    'source':digest(sourcepath),
    'SG_original_raw_or_type_manifest_content_not_reopened':True,
})
names = ['assignment.txt','report.md','exposure.json','read_inputs.py','freeze.py',
         'atom-review.json','root-coverage.json','edge-review.json','port-review.json',
         'locator-checks.json','input-manifest.json']
freeze = {
    'version':1,'kind':'distinct-independent-R9-source-coverage-topology-applicability-coverage-freeze',
    'actor':'/root/row_indep_topology_24a6','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'finding':'ACCEPT_BOUNDED_SOURCE_COVERAGE_AND_UNPROVED_TOPOLOGY_ONLY',
    'genuine_source_coverage_root_path_blockers':[],'still_open_INTERNAL_ports':23,
    'counts':{'atoms':105,'NODE':50,'EXCLUDED':55,'continuous_units':67,'atom_source_elements':77,
              'nodes':80,'edges':129,'OR_hyperedges':2,'p15_atoms_all_excluded':6,
              'locator_occurrences':374,'unique_raw_spans':90,'formal_producer_reverse_closure':48,
              'formal_consumer_reverse_closure':66,'source_formal_union':77,'explicit_context_nodes':3,
              'all_nodes_accounted':80},
    'exact_type_bindings':expected,
    'SG_source_graph':digest(SG/'source-proof-graph.json'),'SG_freeze_manifest':digest(SG/'freeze-manifest.json'),
    'local_records':[digest(DEST/name) for name in names],
    'prior_raw_freeze':digest(OWN/'raw-freeze.json'),'prior_type_freeze':digest(OWN/'type-v1/freeze.json'),
    'old_own_and_public_SG_artifacts_preserved':True,'unopened_SG_snapshots_written':False,
    'implementation_or_new_library_proof_seen':False,'target_proof_API_search_or_Lean_attempts':0,
    'mathematical_or_API_applicability_proof_verified':False,
    'compiled_edge_source_VERIFIED_normal_V_integration_or_permission_grant':False,
    'truth_boundary':'Bounded obligation coverage/topology only. All 23 ports, actual uncentered/centered/weighted proofs, API applications, material calls, compiled verification and repository admission remain unproved/unreviewed here.',
}
write('freeze.json',freeze)
for name,val in INPUTS.items():
    assert digest(SG/name)['sha256'] == val
records = [digest(DEST/name) for name in names]+[digest(DEST/'freeze.json')]
(DEST/'SHA256SUMS').write_text(''.join(f"{a['sha256']}  {Path(a['path']).name}\n" for a in records))
print(json.dumps({'freeze':digest(DEST/'freeze.json'),'report':digest(DEST/'report.md'),
                  'root_coverage':digest(DEST/'root-coverage.json'),'input_manifest':digest(DEST/'input-manifest.json'),
                  'finding':freeze['finding'],'counts':freeze['counts'],'genuine_blockers':[],
                  'still_open_internal_ports':23,'old_own_and_public_SG_preserved':True},indent=2))
