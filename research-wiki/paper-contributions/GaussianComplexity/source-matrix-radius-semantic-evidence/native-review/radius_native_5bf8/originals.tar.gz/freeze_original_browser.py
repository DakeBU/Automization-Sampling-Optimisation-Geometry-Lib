from runner import *
r=json.loads((OUT/'reader/browser-original/report.json').read_text())
assert r['candidate']=='c4d031f237fa0e16fbba16987ca6b34c7f3dfd98'
assert r['production_css_sha256']=='4509e56205aa4bb94c3fa32c7b2b0bd98a9b44a71c23e09f18d5affe038512ad'
assert len(r['contexts'])==4 and len(r['source_checks'])==8
assert not r['page_errors'] and not r['failed_requests'] and not r['http_errors']
assert all(c['initial']['proofSteps']==6 and c['initial']['openDetails']==0 and c['all_expanded']['mathErrors']==0 for c in r['contexts'])
assert all(x['byte_exact'] for c in r['contexts'] for x in c['code_folds'])
assert len(r['layout_failures'])==1
f=r['layout_failures'][0];m=f['measurement']
assert f['viewport']==390 and f['path']=='proofs/source-huanjian-gaussian-source-matrix-radius.html'
assert m['clientWidth']==335 and m['scrollWidth']==496 and m['overflowX']=='visible' and m['scrollLeftAfter100']==0
assert r['server_thread_joined']
assert sha(OUT/'math-judgment.json')=='15034ad5253adb449a5b3e52daf9997ce45ae80a49f739a26c6eeb63a21c1042'
mf=json.loads((OUT/'math-freeze-manifest.json').read_text())
assert all(sha(OUT/p)==v for p,v in mf['files'].items())
closed=[]
for p in sorted((OUT/'receipts').glob('*.json')):
    if p.name.endswith('.pending.json'):continue
    v=json.loads(p.read_text())
    assert sha(p.with_suffix('.stdout'))==v['stdout_sha256'] and sha(p.with_suffix('.stderr'))==v['stderr_sha256']
    closed.append({'path':str(p.relative_to(OUT)),'exit':v['exit'],'sha256':sha(p),'stdout_sha256':v['stdout_sha256'],'stderr_sha256':v['stderr_sha256']})
verdict={'candidate':r['candidate'],'native_math_judgment':'PASS unchanged from frozen independent native run',
 'original_reader_judgment':'FAIL:390px publication assumption table clips and cannot scroll horizontally',
 'all_four_contexts_completed':True,'all_eight_source_navigation_download_checks_completed':True,
 'all_226P_plus95T_lines_in6initially_folded_disclosures':True,'MathJax_and_requests_clean':True,
 'precise_mobile_failure':f,
 'independent_visual_inspection':{'files':['390-context1-table-left.png','1440-context1-table-left.png','390-context0-private-T.png','1440-context0-private-T.png','390-context1-initial.png','1440-context0-initial.png'],
 'finding':'Desktop statement/formulas/progressive folds and private consumer labels are readable. Mobile initial folds and private consumer are readable with indicated formula/code horizontal scroll. Expanded mobile publication assumption table loses right-hand content at the viewport; attempted table scrolling does not reveal it. This matches the visible/clip overflow chain in the actual report.'},
 'scope':'Bounded fixture only; gate/audit/cell badges visibly unverified. No global navigation or remote citation acceptance. No normalV.',
 'receipt_index':closed}
(OUT/'reader/original-verdict.json').write_text(json.dumps(verdict,indent=2)+'\n')
roots=[OUT/'reader/browser-original',OUT/'reader-site-c4d031f']
files={str(p.relative_to(OUT)):sha(p) for root in roots for p in sorted(root.rglob('*')) if p.is_file()}
for p in [OUT/'reader/original-verdict.json',OUT/'reader/prebrowser-freeze.json',OUT/'math-judgment.json',OUT/'math-freeze-manifest.json',OUT/'check_browser.py',OUT/'runner.py']:
    files[str(p.relative_to(OUT))]=sha(p)
(OUT/'reader/original-browser-freeze.json').write_text(json.dumps({'frozen_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'original_result':'FAIL','native_result':'PASS','files':files},indent=2)+'\n')
print(json.dumps({'original_verdict_sha256':sha(OUT/'reader/original-verdict.json'),'original_freeze_sha256':sha(OUT/'reader/original-browser-freeze.json'),'closed_receipts':len(closed),'failure':'CSS table clipped at390 only','native_math_freeze_still_exact':True}))
