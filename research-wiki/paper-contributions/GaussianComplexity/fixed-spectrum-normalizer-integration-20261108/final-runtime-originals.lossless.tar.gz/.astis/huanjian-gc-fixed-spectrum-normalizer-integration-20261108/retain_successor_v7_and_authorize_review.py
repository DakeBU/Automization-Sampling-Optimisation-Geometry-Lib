from pathlib import Path
import datetime, gzip, hashlib, json, struct, tarfile
sha = lambda raw: hashlib.sha256(raw).hexdigest()
B = Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-normalizer-integration-20261108')
D = Path('.astis/huanjian-gc-fixed-spectrum-normalizer-integration-20261108/independent-reader/browser/live-20261108T111533307182Z')
def ref(p):
    p = Path(p)
    return {'path': str(p), 'sha256': sha(p.read_bytes())}
base = B / 'actual-gates-successor-selector-v7-context.json'
assert sha(base.read_bytes()) == '19a075a344722474d8450e9e7483ac9e00e69cd14b2068a188d732df20dc18ec'
a = json.loads(base.read_bytes())
report = json.loads((D / 'report.json').read_bytes())
assert report['status'] == 'passed' and report['errors'] == []
assert report['head'] == a['accepted_immutable_core'] == 'a5ec44836422e56ca5cfab14f951ed84bbfc9324'
pngs = sorted(D.glob('*.png'))
assert len(pngs) == len(report['screenshots']) == 46
expected = {r['file']: r['sha256'] for r in report['screenshots']}
images = B / 'successor-original-images'
assert not images.exists()
images.mkdir()
exports = []
for p in pngs:
    raw = p.read_bytes()
    assert sha(raw) == expected[p.name] and raw[:8] == b'\x89PNG\r\n\x1a\n'
    w, h = struct.unpack('>II', raw[16:24])
    assert (w, h) in [(1440, 1000), (390, 844)]
    z = images / (p.name + '.gz')
    z.write_bytes(gzip.compress(raw, mtime=0))
    assert gzip.decompress(z.read_bytes()) == raw
    exports.append({'original': str(p), 'raw_image_sha256': sha(raw), 'width': w, 'height': h, 'lossless_public_export': {**ref(z), 'compression': 'gzip'}})
files = [D / 'report.json', *pngs]
archive = B / 'successor-browser-original47.lossless.tar.gz'
assert not archive.exists()
with tarfile.open(archive, 'w:gz') as t:
    for p in files: t.add(p, arcname=p.name, recursive=False)
with tarfile.open(archive, 'r:gz') as t:
    assert len(t.getmembers()) == 47
    for p in files: assert t.extractfile(p.name).read() == p.read_bytes()
manifest = B / 'successor-browser-original47.manifest.json'
manifest.write_text(json.dumps({'archive': str(archive), 'archive_sha256': sha(archive.read_bytes()), 'files': [{'original': str(p), 'member': p.name, 'raw_sha256': sha(p.read_bytes()), 'raw_bytes': p.stat().st_size} for p in files], 'same_new_actual_run_only': True, 'independent_visual_review_claimed_by_archive_checker': False}, indent=2) + '\n')
image_manifest = images / 'lossless-public-originals-manifest.json'
image_manifest.write_text(json.dumps({'immutable_core': a['accepted_immutable_core'], 'files': exports, 'PNG_raw_bytes_unchanged': True, 'actual_visual_review_claimed': False}, indent=2) + '\n')
rp = Path('.astis/huanjian-resume-20261103/20261108T111522609766Z-fixed-spectrum-normalizer-final-browser-selector-v7.receipt.json')
r = json.loads(rp.read_bytes())
assert r['exit_code'] == 0 and r['head_before'] == r['head_after'] == a['accepted_immutable_core']
lograw = Path(r['log']).read_bytes()
assert sha(lograw) == r['log_sha256']
checks = B / 'successor-actual-checks'
(checks / rp.name).write_bytes(rp.read_bytes())
lp = checks / (Path(r['log']).name + '.gz')
lp.write_bytes(gzip.compress(lograw, mtime=0))
assert gzip.decompress(lp.read_bytes()) == lograw
public_checks = json.loads((checks / 'first-eight-manifest.json').read_bytes())['checks']
public_checks.append({'role': 'browser', 'original_receipt': ref(rp), 'public_receipt': ref(checks / rp.name), 'public_log': {**ref(lp), 'compression': 'gzip'}, 'raw_log_sha256': sha(lograw)})
(checks / 'all-nine-manifest.json').write_text(json.dumps({'immutable_core': a['accepted_immutable_core'], 'source_digest': a['source_digest'], 'checks': public_checks, 'actual_completed_passing_checks': 9}, indent=2) + '\n')
a.update({'recorded_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'actual_checks': {**a['actual_checks_before_browser'], 'browser': ref(rp)}, 'browser_report': ref(D / 'report.json'), 'retained_archive_manifest': ref(manifest), 'lossless_public_originals_manifest': ref(image_manifest), 'scope': 'Read-only authorization to the actual independent integration reader to open all46 current ORIGINAL PNGs, read all9 actual exact-a5ec receipts/raw logs, examine the changed source/graph branch and one exact CSS exception, and judge whether the mobile GPD clipping HOLD is repaired. Old c8 HOLD and failed v6 partial evidence remain intact. The separate old DensityAffinity two-width sample is native-UI/DOM geometry only, not image review. No local acceptance is inferred from automated success; no new source verdict or parking authorized.'})
out = B / 'actual-successor-originals-independent-review-context.json'
assert not out.exists()
out.write_text(json.dumps(a, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'review_context': ref(out), 'browser_report': a['browser_report'], 'archive_manifest': ref(manifest), 'public_images': 46, 'actual_checks': 9, 'review_or_acceptance_claimed': False}))
