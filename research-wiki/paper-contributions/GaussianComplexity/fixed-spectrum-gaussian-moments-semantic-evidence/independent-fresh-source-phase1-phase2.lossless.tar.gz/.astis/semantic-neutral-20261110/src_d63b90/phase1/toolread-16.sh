python3 - <<'PY'
import sys,runpy,json
from pathlib import Path
sys.argv=['extract_source.py','inventory']
g=runpy.run_path('.astis/semantic-neutral-20261110/src_d63b90/extract_source.py')
p=g['p']; s=g['html']; scope=p.ids['A3.SS3']; out=[]
for ident,n in p.ids.items():
    if scope.start<=n.start and n.end<=scope.end and n.tag in {'div','table','tbody'}:
        out.append({'id':ident,'tag':n.tag,'class':n.attrs.get('class',''),'lines':[s.count('\n',0,n.start)+1,s.count('\n',0,n.end)+1]})
f=Path('.astis/semantic-neutral-20261110/src_d63b90/phase1/source-unit-inventory.json')
f.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
PY
