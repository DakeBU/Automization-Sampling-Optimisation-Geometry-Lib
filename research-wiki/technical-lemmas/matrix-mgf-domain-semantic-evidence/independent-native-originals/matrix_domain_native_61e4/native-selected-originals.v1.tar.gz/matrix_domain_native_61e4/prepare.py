"""Extract only explicit immutable imports; freshly verify upstream identities and cache bytes."""
import ast
from concurrent.futures import ThreadPoolExecutor
import json
import re
from native_common import *

P='AutoSamplingTheory.TechnicalLemmas.Probability.RealMatrixPositiveDefIntegral'
T='Tests.GaussianComplexityMatrixMgfDomain'

def main():
    assert not (OWN/'actual-import-closure.json').exists()
    assert git('immutable-commit','rev-parse',COMMIT).decode().strip()==COMMIT
    head=git('observed-HEAD-only','rev-parse','HEAD').decode().strip()
    CAND.mkdir(exist_ok=True)
    sources={};imports={};order=[];active=set();rows={}
    def visit(module):
        if module in order:return
        assert module not in active
        active.add(module)
        path=module.replace('.','/')+'.lean'
        blob=git('explicit-source-'+str(len(sources)),'cat-file','blob',COMMIT+':'+path)
        oid=git('explicit-OID-'+str(len(sources)),'rev-parse',COMMIT+':'+path).decode().strip()
        sources[module]=blob
        imported=[]
        for line in blob.decode().splitlines():
            m=re.match(r'^\s*(?:public\s+|private\s+|meta\s+)?import\s+(.+)',line)
            if m:imported.extend(m.group(1).split('--',1)[0].split())
        imports[module]=imported
        for dep in imported:
            if dep.startswith(('AutoSamplingTheory','Tests')):visit(dep)
        dest=CAND/path;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(blob)
        rows[module]={'module':module,'path':path,'git_blob_oid':oid,'sha256':sha(blob),'bytes':len(blob),'lines':len(blob.decode().splitlines()),'imports':imported,'actual_ASTIS_imports':[x for x in imported if x.startswith(('AutoSamplingTheory','Tests'))]}
        active.remove(module);order.append(module)
    visit(P);visit(T)
    assert rows[P]['sha256']=='d3c6e5a194fecf1ae1abe45c70310f4f47d66e903b098019c326ee0d3018b024'
    assert rows[T]['sha256']=='60e9f7b928ebc1b8a0d9efad93f39f1b172fe0a871893d67eb1015582c5d5c61'
    for name in ['lean-toolchain','lake-manifest.json','lakefile.lean']:
        (CAND/name).write_bytes(git('immutable-'+name.replace('.','-'),'cat-file','blob',COMMIT+':'+name))
    assert file_sha(CAND/'lean-toolchain')=='302cd63c54178885b89e669f33b38f12f4dd7ae7e5cac537b3203e3768d8fb2b'
    assert file_sha(CAND/'lake-manifest.json')=='b83ca83b9cf7caa85fa8b023c2ff9a3fb7a7cce7e1c332e810c348535ec49c37'
    originals=OWN/'immutable-inputs';originals.mkdir(exist_ok=True)
    sealbytes=(REPO/'research-wiki/technical-lemmas/matrix-mgf-domain-statement-seal.json').read_bytes();(originals/'statement-seal.sealed.v1.json').write_bytes(sealbytes)
    seal=json.loads(sealbytes)
    for role,key,module in [('P','canonical_producer',P),('T','private_real_consumer',T)]:
        literal=seal[key]['exact_proposition'];assert sha(literal.encode())==seal[key]['sha256']
        name=seal[key]['declaration'].split('.')[-1]
        signature=re.search(r'\btheorem\s+'+name+r'\s*:\s*(.*?)\s*:=\s*by',sources[module].decode(),re.S).group(1)
        assert signature.strip()==literal.strip()
        (originals/(role+'.literal.txt')).write_text(literal)
    write_json(OWN/'actual-import-closure.json',{'candidate_commit':COMMIT,'observed_HEAD_not_build_claim':head,'P':P,'T':T,'topological_order':order,'modules':[rows[m] for m in order],'no_global_inventory_command_or_archive':True,'only_explicit_ASTIS_import_paths_extracted':True,'ASTIS_olean_reused':False})
    # Canonical policy input stays private; only its exact minimal regex/stripper is public evidence.
    private=OWN/'local-private';private.mkdir(exist_ok=True)
    policy=git('canonical-policy-private','cat-file','blob',COMMIT+':tools/astis.py')
    (private/'canonical-tools-astis.py.exact').write_bytes(policy)
    tree=ast.parse(policy.decode());nodes=[n for n in tree.body if (isinstance(n,ast.Assign) and any(isinstance(x,ast.Name) and x.id=='FORBIDDEN_REGEX' for x in n.targets)) or (isinstance(n,ast.FunctionDef) and n.name=='strip_lean_comments_and_strings')]
    assert len(nodes)==2
    minimal='import re\n'+ast.unparse(ast.Module(body=nodes,type_ignores=[]))+'\n'
    (OWN/'scan_policy.py').write_text(minimal)
    write_json(OWN/'scan-policy-provenance.json',{'immutable_canonical_policy_sha256':sha(policy),'minimal_policy_sha256':sha(minimal.encode()),'exact_regex_and_comment_string_stripper_extracted_via_Python_AST':True,'full_policy_and_its_preparation_command_streams_private_excluded':True})
    reference=REPO/'.astis/semantic-neutral-20261114/bernstein_exp_native_72c4/package-artifact-digests.json'
    sealed={x['package']:x for x in json.loads(reference.read_text())['packages']}
    packages=[]
    for package in json.loads((CAND/'lake-manifest.json').read_text())['packages']:
        name=package['name'];src=REPO/'.lake/packages'/name
        revision=git('package-revision-'+name,'-C',str(src),'rev-parse','HEAD').decode().strip()
        status=git('package-clean-'+name,'-C',str(src),'-c','core.fsmonitor=false','status','--porcelain','--untracked-files=no')
        assert revision==package['rev'] and not status
        root=reference.parent/'clean-packages'/name/'.lake/build/lib/lean'
        frozen=sealed[name]['files']
        assert {str(p.relative_to(root)) for p in root.rglob('*') if p.is_file()}=={x['path'] for x in frozen}
        def verify(row):
            p=root/row['path'];before=p.stat();h=file_sha(p);after=p.stat()
            assert before.st_size==after.st_size==row['bytes'] and before.st_mtime_ns==after.st_mtime_ns and h==row['sha256']
            return row['bytes']
        with ThreadPoolExecutor(max_workers=8) as pool:count=sum(pool.map(verify,frozen))
        packages.append({'name':name,'revision':revision,'tracked_source_clean':True,'effective_lean_path':str(root),'artifact_files_freshly_rehashed':len(frozen),'artifact_bytes_freshly_rehashed':count,'exact_membership_and_bytes_match_reference':True,'read_only_reuse':True})
        print(json.dumps({'package_bytes_freshly_rehashed_now':name,'files':len(frozen),'bytes':count}),flush=True)
    assert len(packages)==9 and packages[0]['revision']=='db584cd6d46c92f209a44c0f1c829460d327499d'
    write_json(OWN/'verified-package-inputs.json',{'candidate_commit':COMMIT,'packages':packages,'reference_seal_sha256':file_sha(reference),'reference_role':'Previously verified upstream cache metadata only; every actual file freshly rehashed for this R17 assignment. No old ASTIS output or prior mathematical verdict reused.','ASTIS_olean_reused':False})
    print(json.dumps({'explicit_source_closure_archived':len(order),'all_nine_packages_fresh_byte_verification_complete':True}),flush=True)

if __name__=='__main__':main()
