from pathlib import Path
import hashlib
import json

ROOT = Path('/Users/zhouhuanjian/ASTIS-GC')
BASE = ROOT / '.astis/semantic-neutral-20261110/src_a74f20'
OUT = BASE / 'phase2'
def sha(b):
    return hashlib.sha256(b).hexdigest()
def emit(name, obj):
    (OUT/name).write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n')

inputs=[]
for name,expected in [('manifest.json','e6a665fdcd24e37e913aad795b77f50ec2f2aaea805c161c7adc62a7f1f7a977'),('selective-input.json','c40c778612c2a6c649c33347d5621ab1cd59c11971eb6986c219cc3a504be4fe')]:
    data=(BASE/'phase2-inputs'/name).read_bytes()
    assert sha(data)==expected
    target='input-'+name
    (OUT/target).write_bytes(data)
    inputs.append({'path':str((BASE/'phase2-inputs'/name).relative_to(ROOT)),'sha256':sha(data),'snapshot':target,'semantic_read':'whole authorized input'})

phase1=[]
for name,expected in [('source-input.html','6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'),('source-cognition.md','a4ae560ad489377e200f8162b9ba740fbca14a5d23b107d3401f73fdaa4c25b7')]:
    data=(BASE/'phase1'/name).read_bytes()
    assert sha(data)==expected
    phase1.append({'path':str((BASE/'phase1'/name).relative_to(ROOT)),'sha256':sha(data),'phase2_read':'mechanical hash check only; semantic contents retained from frozen phase1; no modification'})

cmd1="""python3 - <<'PY'
from pathlib import Path
import hashlib
base=Path('.astis/semantic-neutral-20261110/src_a74f20/phase2-inputs')
for name,expected in [('manifest.json','e6a665fdcd24e37e913aad795b77f50ec2f2aaea805c161c7adc62a7f1f7a977'),('selective-input.json','c40c778612c2a6c649c33347d5621ab1cd59c11971eb6986c219cc3a504be4fe')]:
    data=(base/name).read_bytes()
    actual=hashlib.sha256(data).hexdigest()
    print('INPUT',name,'SHA256',actual,'MATCH',actual==expected)
    if actual!=expected: raise SystemExit('HASH MISMATCH')
    print(data.decode())
PY"""
cmd2="""python3 - <<'PY'
from pathlib import Path
import hashlib,json
b=Path('.astis/semantic-neutral-20261110/src_a74f20')
p=json.loads((b/'phase2-inputs/selective-input.json').read_text())
checks=[('source restatement',p['source']['original_text'],p['source']['text_sha256']),('exact statement',p['lean_statement']['statement'],p['lean_statement']['statement_sha256']),('reconstruction',p['blind_reconstruction']['text'],p['blind_reconstruction']['text_sha256'])]
for label,text,expected in checks:
    actual=hashlib.sha256(text.encode()).hexdigest()
    print(label,actual,'MATCH',actual==expected)
    if actual!=expected: raise SystemExit('PAYLOAD TEXT HASH MISMATCH')
for name,expected in [('source-input.html','6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'),('source-cognition.md','a4ae560ad489377e200f8162b9ba740fbca14a5d23b107d3401f73fdaa4c25b7')]:
    actual=hashlib.sha256((b/'phase1'/name).read_bytes()).hexdigest()
    print('phase1',name,actual,'MATCH',actual==expected)
    if actual!=expected: raise SystemExit('PHASE1 INPUT MISMATCH')
print('private consumer statement',hashlib.sha256(p['private_consumer_statement'].encode()).hexdigest())
PY"""
emit('tool-commands.json',{'workdir':str(ROOT),'commands':[{'command':cmd1,'actual_exit_code':0,'actual_output_chunk_id':'0db0f2'},{'command':cmd2,'actual_exit_code':0,'actual_output_chunk_id':'10721b'},{'tool':'apply_patch','changes':['Add phase2 independent-statement-review.md and semantic-slots-deltas-verdict.json','Save exact preceding tool result objects to phase2/actual-tool-results.json','Add own freeze_phase2.py'],'actual_patch_result':{},'output_id':None,'note':'No process exit code or generated output ID exposed for patches.'},{'command':'python3 .astis/semantic-neutral-20261110/src_a74f20/freeze_phase2.py','actual_exit_code':None,'actual_output_chunk_id':None,'note':'Terminal sealing command; actual result will be saved in separate post-seal receipt, avoiding invented/self-referential result data.'}],'exact_tool_results':'actual-tool-results.json'})
emit('read-exposure.json',{'reviewer':'/root/source_reader_a74f20','phase':'2','authority':'Parent strict phase2 whitelist message only; no full proof/runtime/reader/normal V authority.','phase1_manifest_sha256':'5afcacc0ea702615faed565f8b99ed770d712c9839c1bedde12f9bd7ca4591db','inputs':inputs,'phase1_inputs_checked':phase1,'semantic_exposure':['Entire selective whitelist input and its manifest','Frozen own phase1 source cognition retained from phase1','Own newly authored phase2 reasoning, slots/deltas/verdict, and tooling'],'incidental_exposures':['The source restatement includes assertions that denominator and integrability facts are proved internally. These assertions were not treated as proof evidence.','Reconstruction metadata identifies its decoder and reports source_text_visible=false; actual decoder history was not observed.','Parent canonical packet digest was supplied as opaque reference; packet itself was not opened.'],'not_read':['Candidate Lean proofs/modules','Lessons/publication context','Earlier semantic slots/deltas/verdicts/repairs','Prior graphs/reviews/frontiers/ledgers','Runtime/compiler/axiom evidence','External references/Mathlib APIs','Other agents mathematical work except the explicitly authorized new blind reconstruction'],'phase1_preserved':True,'compiled_flags_used_as_fidelity_evidence':False,'zero_cue_claim':False,'stop_boundary':'Freeze phase2 and stop for next authority; statement-only source equivalence is not full implementation/publication acceptance.'})

files=sorted(p for p in OUT.iterdir() if p.is_file() and p.name not in {'freeze-manifest.json','seal-receipt.json'})+[BASE/'freeze_phase2.py']
emit('freeze-manifest.json',{'reviewer':'/root/source_reader_a74f20','phase':'2','status':'FROZEN_STATEMENT_ONLY_EQUIVALENT_NO_BLOCKING_DELTA','files':[{'path':str(p.relative_to(ROOT)),'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size} for p in files],'receipt_policy':'Separate seal-receipt.json records actual terminal command completion; receipt is outside this non-self-referential freeze. No frozen artifact is modified after sealing.'})
print(json.dumps({'phase2_manifest_sha256':sha((OUT/'freeze-manifest.json').read_bytes()),'review_sha256':sha((OUT/'independent-statement-review.md').read_bytes()),'slots_deltas_verdict_sha256':sha((OUT/'semantic-slots-deltas-verdict.json').read_bytes()),'read_exposure_sha256':sha((OUT/'read-exposure.json').read_bytes()),'tool_commands_sha256':sha((OUT/'tool-commands.json').read_bytes()),'file_count':len(files),'status':'FROZEN_STATEMENT_ONLY_EQUIVALENT_NO_BLOCKING_DELTA'},indent=2))
