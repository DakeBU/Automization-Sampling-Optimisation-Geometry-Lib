"""Apply only the exact independent accepted proposal; never issue source V."""
from pathlib import Path
import gzip
import hashlib
import json

P = Path('.astis/huanjian-gc-fixed-spectrum-moments-20261109/cosine-expansion')
Q = Path('.astis/semantic-neutral-20261109/src_cosine_5d8c2a/normal-V-preparation')
A = Path('research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-cosine-expansion.json')
sha = lambda b: hashlib.sha256(b).hexdigest()

freeze = (Q / 'manifest.json').read_bytes()
for row in json.loads(freeze)['files']:
    raw = (Q / row['path']).read_bytes()
    assert sha(raw) == row['sha256'] and len(raw) == row['bytes']
proposal_raw = (Q / 'accepted-audit-proposal-v2.json').read_bytes()
assert sha(proposal_raw) == '5620a2e165b51da446395d3870c964ab1d7963d336b8714c493c60615ca92ba1'
proposal = json.loads(proposal_raw)
before = A.read_bytes()
old = json.loads(before)
assert old['state'] == 'blind-reconstructed' and old['source_review']['state'] == 'pending'
after = dict(old)
after.update(proposal['proposed_audit_fields'])
for key in ('source', 'lean', 'reconstruction', 'publication_binding_sha256', 'publication_context'):
    assert old[key] == after[key]
assert after['state'] == 'source-reviewed' and after['source_review']['state'] == 'accepted'
assert after['source_review']['reviewer'] == '/root/cosine_fresh_source_5d8c2a'
assert after['source_review']['checked_commit'] == '37645c774481c4cad19fc29bcaa76799da64db7d'
expected_raw = (Q / 'expected-accepted-audit-v2.json').read_bytes()
assert sha(expected_raw) == 'd69ed9ec5f0ca79d062406291e46230c26b0afe765d58c3f0536bedd32b68ee6'
assert after == json.loads(expected_raw)
report = Path(after['source_review']['review_evidence']).read_bytes()
assert sha(report) == 'c5d30681f2ea122011a711c34e090eff878f9d8855412655698121e2107e02bd'
out = P / 'actual-independent-audit-application-v2'
out.mkdir(exist_ok=False)
(out / 'before.raw.json.gz').write_bytes(gzip.compress(before, mtime=0))
A.write_bytes(expected_raw)
assert A.read_bytes() == expected_raw
receipt = {
    'actor': '/root', 'action': 'exact-independent-proposal-application-only',
    'before_sha256': sha(before), 'after_sha256': sha(expected_raw),
    'prepared_manifest_sha256': sha(freeze), 'proposal_sha256': sha(proposal_raw),
    'changed_top_level_fields': [k for k in old if old[k] != after[k]],
    'independent_reviewer': after['source_review']['reviewer'],
    'normal_API_calls': 0, 'new_root_source_verdict': False,
    'frontier_ledger_models_unchanged_by_this_script': True
}
(out / 'application-receipt.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(receipt, ensure_ascii=False))
