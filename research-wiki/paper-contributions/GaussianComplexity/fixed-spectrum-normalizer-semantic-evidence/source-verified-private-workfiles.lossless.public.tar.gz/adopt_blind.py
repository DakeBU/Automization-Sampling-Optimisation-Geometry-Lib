from pathlib import Path
import json,hashlib,shutil,sys
sys.path.insert(0,'tools')
import astis_semantic_roundtrip as rt
sha=lambda raw:hashlib.sha256(raw).hexdigest()
def put(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
b=Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-normalizer-semantic-evidence')
n=Path('.astis/semantic-neutral-20261108/a7f6d291');d=n/'decoding'
pkt=json.loads((n/'input.json').read_bytes())
assert pkt==json.loads((b/'decoder-input.json').read_bytes())
assert sha((n/'input.json').read_bytes())=='601b89ac19165a248480b8cd548db34a8d2d8ab77cc0305087c4b5f71f630864'
assert sha(json.dumps({k:v for k,v in pkt.items() if k!='packet_sha256'},ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())==pkt['packet_sha256']=='2add603422beb7a4ef0b70040e33b0de5e4f426b08def0b84fd2f8f4e016ec0f'
assert sha((d/'manifest.json').read_bytes())=='569e6e65f25b650c00c674a26a953aac3b75afea748d95a7d67f5e7e0847087d'
m=json.loads((d/'manifest.json').read_bytes())
for r in m['artifacts']:
 raw=(d/r['path']).read_bytes();assert sha(raw)==r['sha256'] and len(raw)==r['bytes']
assert m['source_text_visible'] is False and not m['other_evidence_files_opened']
assert m['input']['supplied_packet_sha256']==pkt['packet_sha256']
assert m['input']['canonical_sha256']==sha(json.dumps(pkt,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())
text=(d/'reconstruction.txt').read_text();assert sha(text.encode())=='a659390be292d9c674300a7d1910a96f344da42d57cde16a51a32798ece68e23'
runhash=sha((d/'decoder-run.json').read_bytes());assert runhash=='e4407dee65bb58000a559e543c3795740faa02034e8057ac693853a7e53a6729'
phase1=b/'fresh-source-reader-640251/phase1'
private=Path('.astis/huanjian-fixed-spectrum-normalizer-20261108/fresh-source-640251/phase1')
mf=phase1/'freeze-manifest.json';assert sha(mf.read_bytes())=='37aa749167ad7e814f36e4d2e1028e9b5316ab2326edcd0205efb1c1a2f5f2ec'
fm=json.loads(mf.read_bytes())
assert not fm['candidate_or_reconstruction_exposure_at_completion']
for r in fm['files']:
 for root,kind in [(phase1,'public'),(private,'private')]:
  raw=(root/r['path']).read_bytes();assert sha(raw)==r[kind+'_sha256'] and len(raw)==r[kind+'_bytes']
dest=b/'blind-691853';dest.mkdir(exist_ok=False)
for p in [n/'input.json',*[p for p in d.iterdir() if p.is_file()]]:
 shutil.copy2(p,dest/p.name);assert (dest/p.name).read_bytes()==p.read_bytes()
x={'decoder':'/root/decode_691853','source_text_visible':False,
 'reconstructed_theorem_text':text,'reconstructed_text_sha256':sha(text.encode()),
 'input_artifacts':pkt['input_artifacts'],'packet_sha256':pkt['packet_sha256'],
 'decoder_run_sha256':runhash,'original_run_artifact':str(dest/'decoder-run.json'),
 'original_manifest_sha256':sha((d/'manifest.json').read_bytes()),
 'ambient_exposure':json.loads((d/'input-exposure.json').read_bytes()),
 'projection_note':'Root mechanical canonical field projection from the immutable independent reconstruction/run. Original decoder outputs unchanged; full-JSON canonical hash and exporter packet hash use explicitly different self-field conventions.'}
put(dest/'output-canonical-projection.json',x)
ap=Path('research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-normalizer.json');a=json.loads(ap.read_bytes())
assert a['state']=='draft' and rt.decoder_packet(a)==pkt
a['reconstruction']={'text':text,'text_sha256':sha(text.encode()),'decoder':x['decoder'],
 'decoder_run_sha256':runhash,'decoder_packet_sha256':pkt['packet_sha256'],'source_text_visible':False,
 'lean_statement_sha256':a['lean']['statement_sha256'],'input_artifacts':pkt['input_artifacts'],
 'run_artifact':str(dest/'decoder-run.json'),'ambient_exposure_record':str(dest/'input-exposure.json'),
 'ambient_identity_cues_disclosed':True,'current_source_title_version_anchor_or_target_declaration_explicitly_supplied':False}
a['state']='blind-reconstructed';put(ap,a);assert rt.decoder_packet(a)==pkt
selective={'schema_version':1,'stage':'SELECTIVE_ANONYMOUS_SOURCE_COMPARISON_BEFORE_FULL_MODULE_CONTEXT',
 'input_scope':'Only genuine anonymous proposition/plain approved definition context and actual independent blind reconstruction, with honest input/ambient exposure provenance. No current target module/proof/authored source prose/publication context/prior verdicts/repairs.',
 'anonymous_decoder_packet':pkt,'blind_reconstruction':x,
 'provenance':{'actual_neutral_input':str(n/'input.json'),'actual_neutral_input_raw_sha256':sha((n/'input.json').read_bytes()),
 'independent_decoder_manifest_sha256':sha((d/'manifest.json').read_bytes()),'independent_decoder_run_sha256':runhash,
 'source_fresh_phase1_manifest_raw_sha256':sha(mf.read_bytes()),
 'source_phase1_actual_public_private_payload_hashes_verified':len(fm['files'])*2,'blindcopies_lossless':True,
 'exporter_packet_hash_excludes_self_field':True,'decoder_whole_JSON_canonical_hash_includes_self_field':m['input']['canonical_sha256']}}
put(b/'phase2-selective-input.json',selective)
put(b/'blind-adoption-receipt.json',{'independent_actor':x['decoder'],'all_raw_canonical_statement_output_run_hashes_verified':True,
 'source_phase1_manifest_sha256':sha(mf.read_bytes()),'actual_phase1_public_private_payloads_verified':len(fm['files'])*2,
 'canonical_hash_conventions_explicitly_distinguished':True,'ambient_exposure_record_preserved':True,
 'state':a['state'],'selective_input_raw_sha256':sha((b/'phase2-selective-input.json').read_bytes()),
 'root_source_verdict_created':False,'source_review':'pending'})
print(json.dumps({'state':a['state'],'selective_input_raw_sha256':sha((b/'phase2-selective-input.json').read_bytes()),
 'reconstruction_sha256':sha(text.encode()),'actual_phase1_payloads_verified':len(fm['files'])*2,'sourceV':False}))
