"""Author and freeze bounded phase-1 source cognition, graph, and coverage."""
from pathlib import Path
import hashlib, json, shutil

ROOT=Path('/Users/zhouhuanjian/ASTIS-GC')
OUT=ROOT/'.astis/huanjian-gc-fixed-spectrum-geometry-20261109/source-auditor'
PUB=ROOT/'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-geometry-semantic-evidence/source-only-review/phase1'
PUB.mkdir(parents=True,exist_ok=True)
def dump(name,obj):
    (OUT/name).write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n')
nodes=[]
def node(id,kind,statement,anchors,scope='target'):
    nodes.append(dict(id=id,kind=kind,statement=statement,source_anchors=anchors,scope=scope,
                      evidence='SOURCE_GAP_OPEN' if kind=='SOURCE_GAP' else 'RAW_SOURCE_RECONSTRUCTION'))
node('D.euclidean','definition','R^d, Euclidean norm and inner product, d by d identity',['S2.p1.1'])
node('D.loewner','definition','For symmetric A,B: A <= B iff B-A is positive semidefinite',['S2.p1.1'])
node('D.orthogonal','definition','Full real O(d)={O : O^T O=I_d}; no determinant restriction',['S2.p2.1'])
node('D.class','definition','Ambient precision class: real symmetric A with I_d <= A <= kappa I_d; introduced for d>=1,kappa>=1',['S2.Ex1','S2.SS0.SSS0.Px1.p1.1'])
node('D.parameters','standing-local-source','Hard-family local conditions: integer d>=2, real kappa>=2, index i=1,...,d',['S4.SS1.p1.1','S4.E11'])
node('D.grid','definition','theta_i=(i-1/2)pi/d; lambda_i=(kappa+1)/2+(kappa-1)cos(theta_i)/2; Lambda=diag(lambda_1,...,lambda_d)',['S4.E11'])
node('D.precision','definition','For each real O in O(d), A=O Lambda O^T',['S4.SS1.p1.2'])
node('D.potential','literal-definition','f_A(x)=x^T A x/2; Appendix C.4 uses V_A for the identical literal formula',['S2.SS0.SSS0.Px1.p1.2','S4.SS1.p1.2','A3.SS4.p2.1'])
node('D.target','definition-context','pi_A=N(0,A^{-1}); target-law formula retained as context, not an integration result',['S2.SS0.SSS0.Px1.p1.2','S4.SS1.p1.2','A3.SS4.p3.1'],'context')
node('D.oracle','literal-definition-and-source-assertion','FO_A(x)=(f_A(x),grad f_A(x))=(x^T A x/2,Ax), exact value and Euclidean gradient',['S2.E1'])
node('C.algorithm','source-model-context','Queries, stopping decisions and output are Borel functions of seed and prior responses; seed independent of input; fixed budget is an every-run cap',['S2.SS0.SSS0.Px2.p1.1'],'context')
node('C.outputlaw','source-model-context','For fixed input A, rho_A^Alg is the output law including all internal randomness',['S2.SS0.SSS0.Px4.p1.1'],'context')
node('C.publicspectrum','source-model-context','Spectrum is deterministic/public; eigenbasis unknown. Normalizer knowledge is excluded analytic branch',['S4.SS1.p2.1'],'context')
node('G.angle','SOURCE_GAP','Index and arithmetic expansion: 1<=i<=d and d>=2 imply 0<(i-1/2)pi/d<pi',['S4.E11','A3.SS4.p1.1'])
node('S.angle','source-assertion','For all i=1,...,d, 0<theta_i<pi',['A3.SS4.p1.1'])
node('S.cosine','source-assertion','For all i, -1<cos(theta_i)<1',['A3.SS4.p1.1'])
node('S.eigenvalues','source-assertion','For all i, 1<lambda_i<kappa',['A3.SS4.p1.1'])
node('G.symmetry','SOURCE_GAP','Diagonal Lambda is symmetric, so (O Lambda O^T)^T=O Lambda O^T',['S4.SS1.p1.2','S4.SS2.SSS0.Px4.p1.1'])
node('G.orthogonalnorm','SOURCE_GAP','Square real O^T O=I implies O O^T=I and ||O^T x||=||x||',['S2.p2.1','A3.SS4.p1.1'])
node('G.conjugation','SOURCE_GAP','x^T A x=sum_i lambda_i ((O^T x)_i)^2; strict spectral bounds imply the closed quadratic-form sandwich',['S4.E11','A3.SS4.p1.1'])
node('S.bounds','source-assertion','For every O in full real O(d), I_d <= A <= kappa I_d',['A3.SS4.p1.1','S4.Thmtheorem6.p1.1'])
node('S.lemma46','source-anchor','Lemma 4.6: every O in O(d) gives the Loewner sandwich for A=O Lambda O^T',['S4.Thmtheorem6'])
node('G.membership','SOURCE_GAP','The source introduction says the hard family belongs to the prescribed class: combine symmetry with Loewner bounds',['S4.SS2.SSS0.Px4.p1.1','S2.Ex1'])
node('G.polynomial','SOURCE_GAP','A fixed finite real quadratic polynomial is C^infinity; no positivity or invertibility is required for regularity',['A3.SS4.p2.1'])
node('S.cinfty','source-assertion','V_A is C^infinity on all of R^d',['A3.SS4.p2.1'])
node('G.derivatives','SOURCE_GAP','For symmetric A: Df_A(x)[h]=<Ax,h>; grad f_A(x)=Ax; D^2f_A(x)[h,k]=<Ah,k>, Hessian matrix A',['S2.E1','A3.SS4.p2.1'])
node('S.gradient','source-assertion','For every x, the Euclidean gradient of f_A at x is Ax',['S2.E1'])
node('S.hessian','source-assertion','For every x, Hessian V_A(x)=A',['A3.SS4.p2.1'])
node('G.hessiancriteria','SOURCE_GAP','On all Euclidean R^d, Hessian lower bound I gives strong convexity with coefficient 1/2 in the first-order inequality; symmetric Hessian bounds 0<=H<=kappa I give kappa-Lipschitz gradient',['A3.SS4.p2.1'])
node('S.strongconvex','source-assertion','For all x,y, V_A(y)>=V_A(x)+<Ax,y-x>+||y-x||^2/2 (usual source Euclidean convention)',['A3.SS4.p2.1'])
node('S.smooth','source-assertion','For all x,y, ||Ax-Ay||<=kappa||x-y|| (usual source Euclidean smoothness convention)',['A3.SS4.p2.1'])
node('S.zero','source-assertion','V_A(0)=0',['A3.SS4.p2.1'])
node('S.growth','source-assertion','For every x, V_A(x)>=||x||^2/2',['A3.SS4.p2.1'])
node('S.positive','source-assertion','For every x!=0, V_A(x)>=||x||^2/2>0',['A3.SS4.p2.1'])
node('S.minimizer','source-assertion','Zero is the unique global minimizer on all of R^d',['A3.SS4.p2.1'])
node('G.oraclecontinuous','SOURCE_GAP','For each fixed A, the literal numeric map x |-> (x^T A x/2,Ax) is continuous into R x R^d; the paper does not state this bridge',['S2.E1','S2.SS0.SSS0.Px2.p1.1'])
node('G.oracleborel','SOURCE_GAP','For fixed admissible A, the actual value-and-gradient oracle is Borel between standard Euclidean Borel spaces, by the literal equality and continuity-to-Borel; not asserted as a separate source theorem',['S2.E1','S2.SS0.SSS0.Px2.p1.1'])

routes=[]
def route(id,parents,consumer,use,step,provenance='author-route-expanded'):
    routes.append(dict(id=id,operator='AND',prerequisites=parents,consumer=consumer,
                       consumer_use_site=use,step=step,provenance=provenance))
route('R.angle-expansion',['D.parameters','D.grid'],'G.angle','A3.SS4.p1.1: Since 0<theta_i<pi','Recover finite indexing and positive denominator')
route('R.angle',['G.angle'],'S.angle','A3.SS4.p1.1: Since 0<theta_i<pi','Source implicit arithmetic')
route('R.cosine',['S.angle'],'S.cosine','A3.SS4.p1.1: we have -1<cos(theta_i)<1','Cosine range on open (0,pi)')
route('R.eigen',['S.cosine','D.parameters','D.grid'],'S.eigenvalues','A3.SS4.p1.1: and hence 1<lambda_i<kappa','Multiply by (kappa-1)/2>0 and simplify endpoints')
route('R.symmetry',['D.grid','D.precision'],'G.symmetry','S4.SS2.SSS0.Px4.p1.1: belongs to prescribed class','Transpose of orthogonal conjugate of diagonal')
route('R.orthogonalnorm',['D.orthogonal'],'G.orthogonalnorm','A3.SS4.p1.1: with O orthogonal','Square-matrix inverse identity and norm preservation')
route('R.conjugation',['D.grid','D.precision','S.eigenvalues'],'G.conjugation','A3.SS4.p1.1: As A=O Lambda O^T ... this gives','Expand quadratic form; relax strict eigenvalue bounds')
route('R.bounds',['G.conjugation','G.orthogonalnorm','G.symmetry','D.loewner'],'S.bounds','A3.SS4.p1.1: this gives I_d<=A<=kappa I_d','Identify quadratic PSD inequalities with Loewner order')
route('R.lemma',['S.bounds'],'S.lemma46','S4.Thmtheorem6; proof referral S4.SS2.SSS0.Px4.p1.1 to A3.SS4','Bind the C.4 result to Lemma4.6; this is a source proof attribution')
route('R.membership',['S.bounds','G.symmetry','D.class'],'G.membership','S4.SS2.SSS0.Px4.p1.1: hard family belongs to prescribed class','Discharge class symmetry and both order inequalities')
route('R.polynomial',['D.potential','D.euclidean'],'G.polynomial','A3.SS4.p2.1: potential ... is C-infinity','Finite quadratic polynomial regularity')
route('R.cinfty',['G.polynomial'],'S.cinfty','A3.SS4.p2.1: is C-infinity','Source statement of global regularity')
route('R.derivatives',['D.potential','G.symmetry','D.euclidean'],'G.derivatives','S2.E1 and A3.SS4.p2.1: gradient Ax and Hessian A','Quadratic differentiation; symmetry removes the symmetrization factor')
route('R.gradient',['G.derivatives'],'S.gradient','S2.E1: grad f_A(x)=Ax','Source exact first-order identification')
route('R.hessian',['G.derivatives'],'S.hessian','A3.SS4.p2.1: with Hessian A','Source constant Hessian identification')
route('R.criteria',['S.bounds','S.cinfty','S.hessian','D.euclidean'],'G.hessiancriteria','A3.SS4.p2.1: Thus it is ...','Unstated Euclidean Hessian criteria and source conventions')
route('R.strongconvex',['G.hessiancriteria'],'S.strongconvex','A3.SS4.p2.1: 1-strongly convex','Lower Hessian criterion')
route('R.smooth',['G.hessiancriteria'],'S.smooth','A3.SS4.p2.1: kappa-smooth','Upper PSD Hessian criterion')
route('R.zero',['D.potential'],'S.zero','A3.SS4.p2.1: Moreover V_A(0)=0','Evaluate literal quadratic at zero')
route('R.growth',['D.potential','S.bounds','D.loewner'],'S.growth','A3.SS4.p2.1: V_A(x)>=||x||^2/2','Use lower quadratic form bound; independent of derivative route')
route('R.positive',['S.growth','D.euclidean'],'S.positive','A3.SS4.p2.1: >0 for x!=0','Strict norm positivity for nonzero vectors')
route('R.unique',['S.zero','S.positive'],'S.minimizer','A3.SS4.p2.1: so 0 is its unique minimizer','Zero attains the lower value and every nonzero point has larger value')
route('R.oracle-continuity',['D.oracle','D.euclidean'],'G.oraclecontinuous','S2.E1 read at S2 randomized algorithm paragraph','Literal polynomial oracle pair; omission of model bridge','auditor-source-model-completion')
route('R.oracle-borel',['G.oraclecontinuous','D.oracle'],'G.oracleborel','S2.SS0.SSS0.Px2.p1.1: Borel functions of previous oracle responses','Continuous-to-Borel for fixed actual oracle via Eq1; no adaptive transcript theorem','auditor-source-model-completion')

graph=dict(schema='phase1-source-only-geometry-v1',phase='PHASE1_FROZEN_PRE_INTERFACE',
           source_sha256='6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915',
           author_graph_roots=['S.lemma46','G.membership','S.cinfty','S.gradient','S.hessian','S.strongconvex','S.smooth','S.zero','S.growth','S.positive','S.minimizer'],
           additional_source_model_bridge='G.oracleborel',nodes=nodes,routes=routes,
           route_semantics='Each route conjoins only its prerequisites. Multiple sufficient routes would be OR, never flatten into one AND. Source gives one C.4 geometry route; minimizer has no calculus/normalizer prerequisite.',
           completion_options=[dict(target='G.oraclecontinuous',operator='OR',provenance='auditor options for an omitted bridge, not author-attributed alternatives',
             options=[dict(id='O.coordinate-polynomial',sufficient=['Eq1 numeric pair is finite coordinate polynomials']),
                      dict(id='O.factorized-continuity',sufficient=['quadratic scalar f_A continuous','fixed linear Ax continuous','pairing continuous'])],
             warning='Choose either sufficient option. Do not conjoin both options or turn either continuity conclusion into a public theorem premise.')],
           conditional_discharge=[
             dict(use='strict eigenvalue interval',premise='kappa-1>0',discharged_by='D.parameters: kappa>=2'),
             dict(use='orthogonal transfer for O^T x',premise='O O^T=I although source defines O^T O=I',discharged_by='G.orthogonalnorm (open completion obligation)'),
             dict(use='actual gradient Ax / Hessian A',premise='A symmetric',discharged_by='G.symmetry (open completion obligation)'),
             dict(use='strong convexity / smoothness criteria',premise='global differentiability and Hessian identities',discharged_by='S.cinfty and S.hessian, whose omitted proofs remain G.polynomial/G.derivatives'),
             dict(use='unique global minimizer',premise='nonzero points strictly larger',discharged_by='S.positive from S.growth and Euclidean norm positivity'),
             dict(use='actual oracle Borel',premise='numeric pair is actual value/gradient pair',discharged_by='S2.E1 source assertion D.oracle; no arbitrary response parameter')],
           not_claimed=['implementation or compiler truth','independently accepted topology/coverage','any SOURCE_GAP discharged','joint measurability in O or kappa','adaptive transcript/output measurability','Gaussian integration or normalizer','query cap/TV/lower-bound theorem','main lower-bound parameter restrictions as local geometry hypotheses'])
dump('source-graph.json',graph)

units=json.loads((OUT/'source-items.raw.json').read_text())
atoms=json.loads((OUT/'source-atoms.raw.json').read_text())
N=lambda *ids:dict(disposition='NODE',nodes=list(ids))
X=lambda why:dict(disposition='EXCLUDED',reason=why)
unitmap={
'S2.p1.1':N('D.euclidean','D.loewner'),
'S2.p2.1':N('D.orthogonal'),
'S2.SS0.SSS0.Px1.p1.1':N('D.class'),
'S2.Ex1':N('D.class'),
'S2.SS0.SSS0.Px1.p1.2':N('D.potential','D.target','D.oracle'),
'S2.E1':N('D.oracle','S.gradient'),
'S2.SS0.SSS0.Px1.p2.1':X('Exact-query equivalence and query complexity are outside the geometry and fixed-input oracle-map bridge; Eq1 numeric formula is separately retained.'),
'S2.SS0.SSS0.Px2.p1.1':N('C.algorithm'),
'S2.SS0.SSS0.Px3.p1.1':X('TV definition outside selected geometry/oracle-map scope.'),
'S2.Ex2':X('TV definition outside selected geometry/oracle-map scope.'),
'S2.SS0.SSS0.Px3.p1.2':X('Dominating-measure formulation and bounded-test TV estimate outside selected scope.'),
'S2.SS0.SSS0.Px4.p1.1':N('C.outputlaw'),
'S2.E2':X('Uniform sampling query-complexity definition, including epsilon and deterministic cap, is outside this result.'),
'S2.SS0.SSS0.Px4.p1.2':X('Uniform accuracy and every-run cap versus expected cost are recorded boundaries, not geometry conclusions.'),
'S4.SS1.p1.1':N('D.parameters'),
'S4.E11':N('D.grid'),
'S4.SS1.p1.2':N('D.precision','D.potential','D.target'),
'S4.SS1.p2.1':N('C.publicspectrum'),
'S4.Thmtheorem2':X('Remark4.2 affine kappa=2 comparison, oracle simulation and oscillatory lower-bound test are independent of Lemma4.6/C.4 geometry.'),
'S4.Thmtheorem2.p1.1':X('Remark4.2 affine kappa=2 comparison, oracle simulation and oscillatory lower-bound test are outside this bounded result.'),
'S4.Thmtheorem6':N('S.lemma46'),
'S4.Thmtheorem6.p1.1':N('S.bounds','S.lemma46'),
'A3.SS4.p1.1':N('S.angle','S.cosine','S.eigenvalues','S.bounds'),
'A3.SS4.p2.1':N('D.potential','S.cinfty','S.hessian','S.strongconvex','S.smooth','S.zero','S.growth','S.positive','S.minimizer'),
'A3.SS4.p3.1':N('D.target'),
'A3.Ex160':X('Gaussian integration and determinant-invariant normalizer formula form a separate analytic branch; not a geometry or fixed-input oracle prerequisite.'),
'A3.SS4.p3.2':X('Known rotation-independent normalizer conclusion belongs to the excluded Gaussian integration/determinant branch.'),
'S4.SS2.SSS0.Px4.p1.1':N('G.membership','S.lemma46'),
'S4.Thmtheorem1':X('Theorem4.1 lower bound is outside scope. delta, d0(delta), kappa<=d^(1-delta) and epsilon<=1/10 do not narrow local d>=2,kappa>=2 geometry.'),
'S4.Thmtheorem1.p1.1':X('Main lower-bound parameter quantifiers retained only to distinguish them from local geometry assumptions.'),
'S4.Ex9':X('Main query lower-bound display outside selected result.'),
'bib.bib3':X('Bibliography [22] is construction provenance; cited external text was not retrieved and is not used as a C.4 geometric dependency.')}
assert set(unitmap)=={u['anchor'] for u in units}
fragments=[
dict(source='S2.p2.1',clause='Haar measure; two determinant components of mass 1/2; conditioned mu_n,b',**X('Distributional background excluded from the pointwise result; full O(d) definition retained.')),
dict(source='S2.SS0.SSS0.Px1.p1.1',clause='Centered-target motivation and rescaling without loss',**X('Motivation/rescaling proof outside fixed hard-family geometry; ambient d>=1,kappa>=1 retained without broadening local contract.')),
dict(source='S2.SS0.SSS0.Px2.p1.1',clause='Seed independence and deterministic fixed cap',**N('C.algorithm')),
dict(source='S2.SS0.SSS0.Px4.p1.1',clause='0<epsilon<1 and following query complexity definition',**X('Accuracy/query complexity outside scope; only fixed-input output-law context retained.')),
dict(source='S4.SS1.p1.1',clause='Similar to [22, Section9.2] and extension from [1,2]',**X('Construction attribution only; local formula Eq11 is independently explicit.')),
dict(source='S4.SS1.p1.2',clause='Draw O Haar independently of private seed',**X('Hard-instance distribution unnecessary for every-O deterministic geometry; no SO(d) restriction introduced.')),
dict(source='S4.SS1.p2.1',clause='In particular the normalizing constant is known',**X('Separate normalization branch; deterministic/public spectrum context remains.')),
dict(source='A3.SS4.p3.1',clause='Gaussian integration gives',**X('Analytic Gaussian integration branch excluded, not erased.'))]
overrides={}
def override(ids,disp):
    for id in ids: overrides[id]=disp
override(['S2.p1.m1','S2.p1.m2','S2.p1.m3'],N('D.euclidean'))
override(['S2.p1.m4','S2.p1.m5','S2.p1.m6','S2.p1.m7'],N('D.loewner'))
override(['S2.p2.m1'],N('D.orthogonal'))
override(['S2.p2.m'+str(i) for i in range(2,8)],X('Haar determinant-component probabilities/conditioning are excluded distributional background; no determinant restriction on pointwise geometry.'))
override(['S2.SS0.SSS0.Px1.p1.m5'],N('D.class'))
override(['S2.SS0.SSS0.Px1.p1.m6'],N('D.potential'))
override(['S2.SS0.SSS0.Px1.p1.m7'],N('D.target'))
override(['S2.SS0.SSS0.Px1.p1.m8'],N('D.euclidean'))
override(['S2.SS0.SSS0.Px4.p1.m3'],X('epsilon accuracy interval outside scope.'))
override(['S4.SS1.p1.m1','S4.SS1.p1.m2'],X('Original [1,2] construction comparison outside pointwise geometry.'))
override(['S4.SS1.p1.m3','S4.SS1.p1.m4'],N('D.parameters'))
override(['S4.SS1.p1.m5'],X('Haar randomness is excluded from the pointwise every-O geometry; full O(d) is retained by D.orthogonal.'))
override(['S4.SS1.p1.m6'],N('D.precision'))
override(['S4.SS1.p1.m7'],N('D.potential'))
override(['S4.SS1.p1.m8'],N('D.target'))
override(['S4.Thmtheorem2.m1'],unitmap['S4.Thmtheorem2'])
override(['S4.Thmtheorem1.m1'],unitmap['S4.Thmtheorem1'])
override(['A3.SS4.p1.m1'],N('S.angle'))
override(['A3.SS4.p1.m2'],N('S.cosine'))
override(['A3.SS4.p1.m3'],N('S.eigenvalues'))
override(['A3.SS4.p1.m4'],N('D.precision'))
override(['A3.SS4.p1.m5'],N('D.orthogonal'))
override(['A3.SS4.p1.m6'],N('S.bounds'))
for i,ids in [(1,['D.potential']),(2,['S.cinfty']),(3,['S.hessian']),(4,['S.strongconvex']),(5,['S.smooth']),(6,['S.zero']),(7,['S.growth','S.positive']),(8,['S.positive']),(9,['S.minimizer'])]:
    override(['A3.SS4.p2.m'+str(i)],N(*ids))
atomcoverage=[]
for atom in atoms:
    a=atom['atom_id']; container=atom['container']; href=atom['href']
    if a in overrides: disp=overrides[a]
    elif atom['kind']=='a':
        if href=='#bib.bib3': disp=X('[22] construction provenance only; no invoked external geometry/calculus theorem.')
        elif container=='bib.bib3': disp=X('Bibliography locator/backlink is navigational provenance; external source not retrieved.')
        elif container=='S4.Thmtheorem2.p1.1': disp=unitmap[container]
        elif href in ('#A3.SS4','#S4.Thmtheorem6'): disp=N('S.lemma46')
        else: raise ValueError(('unclassified-link',atom))
    elif container in unitmap: disp=unitmap[container]
    else: raise ValueError(('unclassified-atom',atom))
    atomcoverage.append(dict(**atom,**disp))
coverage=dict(schema='phase1-source-only-coverage-v1',phase='PHASE1_FROZEN_PRE_INTERFACE',
              inventory_boundary='All paragraph/theorem/display units, inline formula atoms, and citation/reference link occurrences within S2, S4.SS1, Lemma4.6 and A3.SS4; only proof-referral sentence, Theorem4.1 statement, and bib[22] as bounded context.',
              audit_status='EXTRACTOR_RECONSTRUCTION_ONLY; independent topology/coverage review pending; no source-VERIFIED claim',
              paragraph_and_display_inventory=[dict(**u,**unitmap[u['anchor']]) for u in units],
              mixed_paragraph_clause_dispositions=fragments,formula_and_citation_inventory=atomcoverage,
              source_gaps=[n['id'] for n in nodes if n['kind']=='SOURCE_GAP'],
              source_external_citation_policy='All [22] occurrences explicitly excluded as construction provenance; no C.4 geometric/calculus external citation is present.',
              consumer_use_sites='Every route in source-graph.json contains the consumer prose location; proof-location links are attribution/navigation, not theorem prerequisites.',
              counts=dict(source_units=len(units),formula_and_link_atoms=len(atoms),source_nodes=len(nodes),routes=len(routes),source_gaps=sum(n['kind']=='SOURCE_GAP' for n in nodes)))
dump('source-coverage.json',coverage)

nodeids={n['id'] for n in nodes}
assert len(nodeids)==len(nodes)
for r in routes:
    assert r['consumer'] in nodeids and set(r['prerequisites'])<=nodeids and r['consumer_use_site']
for disp in list(unitmap.values())+[a for a in atomcoverage]+fragments:
    assert (disp['disposition']=='NODE' and set(disp['nodes'])<=nodeids) or (disp['disposition']=='EXCLUDED' and disp['reason'])
# Structural acyclicity, not a mathematical correctness or coverage approval.
pending={n['id']:set() for n in nodes}
for r in routes: pending[r['consumer']].update(r['prerequisites'])
ordered=[]
while pending:
    free=[k for k,v in pending.items() if not v]
    assert free, 'Graph cycle'
    ordered.extend(free)
    for k in free: pending.pop(k)
    for v in pending.values(): v.difference_update(free)
dump('structural-check.json',dict(status='PASS_STRUCTURAL_ONLY',source_units=len(units),atoms=len(atoms),
                                all_units_and_atoms_disposed=True,acyclic=True,topological_order=ordered,
                                warning='Inventory shape and graph acyclicity do not establish mathematical validity or independently approve coverage.'))

selected=['initial-cognition.md','source-graph.json','source-coverage.json','source-regions.json','source-items.raw.json','source-atoms.raw.json','read-hashes.json','structural-check.json']
for name in selected: shutil.copyfile(OUT/name,PUB/name)
files=[]
for path in sorted(OUT.rglob('*')):
    if path.is_file() and path.name not in ('phase1-freeze.json',):
        b=path.read_bytes(); files.append(dict(path=str(path.relative_to(ROOT)),bytes=len(b),sha256=hashlib.sha256(b).hexdigest()))
manifest=dict(phase='PHASE1_FROZEN_PRE_INTERFACE',role='independent mathematical source/dependency extractor',
              source_bytes=951991,source_sha256='6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915',
              no_interface_or_implementation_exposure=True,independent_coverage_approval='PENDING_SEPARATE_REVIEW',
              files=files,public_mirrors=[str((PUB/name).relative_to(ROOT)) for name in selected],
              phase2='STOP. Await separate root authorization and raw sealed interfaces/minimal definition windows.')
dump('phase1-freeze.json',manifest)
shutil.copyfile(OUT/'phase1-freeze.json',PUB/'phase1-freeze.json')
for name in ['initial-cognition.md','source-graph.json','source-coverage.json','phase1-freeze.json']:
    print(name,hashlib.sha256((OUT/name).read_bytes()).hexdigest())
print(json.dumps(coverage['counts'],sort_keys=True))
