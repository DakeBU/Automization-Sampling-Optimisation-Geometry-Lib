from pathlib import Path
import json, hashlib, datetime, sys
sys.path.insert(0, 'tools')
import astis_advance as a
sha = lambda raw: hashlib.sha256(raw).hexdigest()
def put(path, obj):
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n')
base = Path('research-wiki/paper-contributions/GaussianComplexity')
ev = base / 'fixed-spectrum-normalizer-semantic-evidence'
sp = base / 'fixed-spectrum-normalizer-statement-seal.json'
assert sha(sp.read_bytes()) == '3b3c752a771f2d5481c4708f9f4821494c5598cbe48363ad91d0b9061f4127a2'
seal = json.loads(sp.read_bytes())
sg = ev / 'source-only-review/phase1'
top = ev / 'topology-challenge/phase1'
last = top / 'topology-admission-checkpoint-v1'
manifests = [(sg/'manifest.json', 'bb527878ab86ded101b8b619a2ab770c43ac1247bdd1790f67eeb258415a5512'),
             (sg/'phase2-overlay-v1/manifest.json', 'd85f09c05d1c8f78a8452b09880982a7b4129a00ce3fd48b5ac19dfb58e1f8e1'),
             (last/'manifest.json', '55ca0ac9a90bf3bf229f67e247d54116c687177570e18dbfe1ed941dc56eda12')]
n = 0
for path, expected in manifests:
    assert sha(path.read_bytes()) == expected
    m = json.loads(path.read_bytes())
    rows = m.get('files', []) + m.get('actual_raw_inputs', []) + m.get('frozen_outputs', [])
    for row in rows:
        p = Path(row.get('path', row.get('archive_file', row.get('file'))))
        raw = p.read_bytes()
        assert sha(raw) == row['sha256'], str(p)
        assert len(raw) == row['bytes'], str(p)
        n += 1
assert sha((top/'phase1-manifest.json').read_bytes()) == 'e832f88a84ab7d55424ac49240b18b2219c7f89ade6b778a6395d633a9a5cad5'
assert sha((top/'binder-definition-checkpoint/input-manifest.json').read_bytes()) == 'a12d0f2ff29ba59c5352dcb10278f3e3bda635a3ae084ed6122e0f02c23ccf54'
for relative, expected in json.loads((last/'manifest.json').read_bytes())['prior_rawfirst_and_binder_files_verified_unchanged'].items():
    assert sha((top/relative).read_bytes()) == expected
vp = last/'source-admission-verdict.json'
assert sha(vp.read_bytes()) == '932ddeb44a93e7e7b1967b759396b6ee4c243d24339d88c52b4eb779927455da'
v = json.loads(vp.read_bytes())
assert v['status'] == 'PREPROOF_SOURCE_ADMITTED_EXACT_PRODUCER_ONLY'
assert not v['blocking_findings'] and not v['EXCESS']
assert v['signature_sha256'] == seal['signature_sha256']
assert v['seal_sha256'] == sha(sp.read_bytes())
assert not Path(seal['production_file']).exists() and not Path(seal['real_consumer']['file']).exists()
record = {
    'recorded_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'state': 'ISOLATED_EXACT_PRODUCER_SOURCE_GATE_ADMITTED_ONLY_CONSUMER_INTERFACE_NEXT',
    'source_graph_actor': '/root/norm_source_graph_391602',
    'distinct_challenger': '/root/norm_topology_570830',
    'seal_raw_sha256': sha(sp.read_bytes()), 'signature_sha256': seal['signature_sha256'],
    'sourcegraph_manifest': str(sg/'manifest.json'),
    'sourcegraph_overlay_manifest': str(sg/'phase2-overlay-v1/manifest.json'),
    'distinct_final_verdict': str(vp), 'distinct_final_verdict_sha256': sha(vp.read_bytes()),
    'distinct_final_manifest': str(last/'manifest.json'),
    'distinct_final_manifest_sha256': sha((last/'manifest.json').read_bytes()),
    'actual_manifest_payloads_rechecked': n, 'EXCESS': [],
    'graph_interpretation_requirements': v['graph_interpretation_requirements'],
    'selected_unproved_math': [
        'Actual Gaussian weight measurability and finite integral from literal source inputs',
        'Actual unweighted Euclidean integral value, retaining determinant/conjugation/diagonal product parents',
        'Positive diagonal product/sqrt nonzero and real half-power identity, all parities',
        'Literal source one-based grid to Fin d and Euclidean coordinate quadratic adapters'],
    'source_implicit_convention': v['source_explicitness'],
    'exposure': v['exposure_qualification'],
    'overall_implementation_admission': False,
    'next_gate': 'Immutable producer admission commit; then exact actual same-A inverse-precision Gaussian integral-normalized density consumer seal, critical definition audit/type elaboration and distinct source review before any target implementation/API.',
    'truth_boundary': seal['truth_boundary'],
    'proof_sourceV_or_consumer_complete': False}
ap = ev/'producer-source-admission.json'
assert not ap.exists()
put(ap, record)
cp = Path('research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-normalizer.json')
cell = json.loads(cp.read_bytes())
cell['statement_seal']['status'] = 'ELABORATED_DISTINCT_PRODUCER_SOURCE_ACCEPTED_CONSUMER_PENDING'
cell['evidence']['producer_source_admission'] = str(ap)
cell['evidence']['execution_boundary'] = 'Independent raw-first graph, exact binders/definitions, exhaustive effective coverage and distinct topology admission only. Integrable AND actual integral-value obligations remain unproved; exact actual Gaussian consumer admission precedes target implementation/API. No proof/sourceV/integration/completion.'
cell['source_proof_coverage'] = {
    'phase1_sourcegraph': str(sg/'source-proof-graph.json'),
    'phase1_coverage': str(sg/'coverage-inventory.json'),
    'candidate_graph_overlay': str(sg/'phase2-overlay-v1/graph-coverage-overlay.json'),
    'candidate_seven_slot_matching': str(sg/'phase2-overlay-v1/matching-seven-slots.json'),
    'distinct_topology_review': str(vp),
    'distinct_challenge_overlay': str(last/'graph-challenge-overlay.json'),
    'distinct_backward_closure': str(last/'producer-backward-closure.json'),
    'graph_interpretation_requirements': v['graph_interpretation_requirements'],
    'selected_unproved_math': record['selected_unproved_math'],
    'original_freezes_unchanged': True, 'proof_credit': False}
cell['source_detail_audit']['gap'] = 'The source shorthand Gaussian integration and source-implicit Lebesgue convention are independently admitted for the exact sealed producer. Actual finiteness and value, det/product/positive-root and literal-grid adapters remain proof obligations. Consumer/class/calculus/main/adaptive/precision/TV/cost gates remain separate.'
put(cp, cell)
aid = 'ASTIS-SA-20261108-GaussianComplexityFixedSpectrumNormalizer'
states = a.current_advances()
assert states[aid]['state'] == 'CLAIMED'
assert not [s for s in states.values() if s['state'] == 'STABILIZING']
ledger = Path('runs/substantive_advances.jsonl')
before = ledger.read_bytes()
discovery = Path('runs/substantive_discoveries.jsonl').read_bytes()
frontiers = {str(p): p.read_bytes() for p in cp.parent.glob('*.json') if p != cp}
a.transition_advance(aid, to_state='EXPLORING', worker_id='huanjian_gc_20261108_fixed_spectrum_normalizer', evidence={
    'source_admission': str(ap), 'exact_signature_sha256': seal['signature_sha256'],
    'distinct_source_coverage_topology_verdict': str(vp),
    'consumer_gate': 'Pending exact actual Gaussian consumer interface/type/critical definitions seal and independent admission before target proof/API.',
    'targetproof_API_started': False})
after = ledger.read_bytes()
now = a.current_advances()
assert after.startswith(before) and len(after[len(before):].splitlines()) == 1
assert all(now[k] == s for k, s in states.items() if k != aid)
assert Path('runs/substantive_discoveries.jsonl').read_bytes() == discovery
assert all(Path(p).read_bytes() == raw for p, raw in frontiers.items())
put(ev/'normal-exploring-preservation.json', {
    'actual_state': now[aid]['state'], 'before_ledger_sha256': sha(before),
    'after_ledger_sha256': sha(after), 'append_sha256': sha(after[len(before):]),
    'append_events': 1, 'exact_old_prefix_preserved': True,
    'foreign_states_preserved': len(states)-1,
    'foreign_frontier_files_preserved': len(frontiers),
    'discovery_ledger_unchanged': True, 'target_proof_started': False,
    'consumer_implementation_admitted': False, 'sourceV': False})
rp = base/'README.md'
old = rp.read_bytes()
lead = ('# Current continuation: actual normalizer producer source admitted; exact consumer next\n\n'
        'Read `fixed-spectrum-normalizer-semantic-evidence/producer-source-admission.json`. Exact signature3e2c0dd7/seal3b3c752a has independent raw-first source graph, binder/definition, exhaustive coverage and distinct topology admission. Integrable AND actual unweighted Euclidean Gaussian integral value are still unproved. Source Lebesgue-normalizer meaning is a disclosed implicit convention; target semantic context, inferred determinant bridge and independent integrability obligation remain explicit. Next seal/audit/type-check the genuine same-A Gaussian integral-normalized density consumer and obtain distinct admission before target proof/API.\n\n'
        'Root remains sole mathematical worker. All283 foreign states/442 old frontier files and append-only prefixes/discoveries are preserved; prior determinant final000d64ea/core55b7b539 stays locally accepted/released. Exactconsumer/proof/sourceV/root/site/graph/remote/purification/Seal and whole Goal completion remain separate. Full C4 calculus/minimizer, both main lower bounds and actual adaptive/oracle/precision/TV/deterministic/expected-cost adapters remain open. Existing original-owner remote hold and all other paper queues remain intact. Older checkpoints below are preserved phase history.\n\n').encode()
rp.write_bytes(lead + old)
assert rp.read_bytes()[len(lead):] == old
print(json.dumps({'state': now[aid]['state'], 'producer_source_gate': True,
                  'consumer_and_targetproof_API': 'pending', 'actual_payloads_rechecked': n,
                  'foreign_states_preserved': len(states)-1,
                  'foreign_frontiers_preserved': len(frontiers)}))
