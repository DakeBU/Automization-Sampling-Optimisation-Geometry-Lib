import hashlib,json,os,pathlib,re
from run import ROOT,REPO,run
m=json.loads((ROOT/'input-manifest.json').read_text())
env=dict(os.environ);env['LEAN_PATH']=os.pathsep.join(m['lean_path'])
env.pop('LEAN_SRC_PATH',None)
outputs=[]
for i,p in enumerate(m['modules']):
    src=ROOT/'scratch'/p
    astis_imports=re.findall(r'^import (AutoSamplingTheory[^\s]+|Tests[^\s]+)',src.read_text(),re.M)
    assert all(x.replace('.','/')+'.lean' in m['modules'][:i] for x in astis_imports),(p,astis_imports)
    dst=ROOT/'native-olean'/pathlib.Path(p).with_suffix('.olean');dst.parent.mkdir(parents=True,exist_ok=True)
    r=run('compile-'+str(i),[m['lean_binary']['path'],'-R',str(ROOT/'scratch'),'-o',str(dst),str(src)],cwd=ROOT/'scratch',env=env)
    assert r.returncode==0,p
    outputs.append({'module':p,'output':str(dst.relative_to(ROOT)),'sha256':hashlib.sha256(dst.read_bytes()).hexdigest(),'imports':astis_imports})
(ROOT/'native-build.json').write_text(json.dumps({'candidate_commit':m['candidate_commit'],'outputs':outputs,'lean_path':m['lean_path'],'fresh_astis_only':True},indent=2)+'\n')
print(json.dumps({'modules_compiled':len(outputs),'all_exit_zero':True}))
