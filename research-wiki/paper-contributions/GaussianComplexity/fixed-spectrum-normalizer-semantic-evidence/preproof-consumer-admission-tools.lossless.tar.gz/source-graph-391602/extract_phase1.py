from pathlib import Path
from datetime import datetime, timezone
from bs4 import BeautifulSoup
import copy, hashlib, json, re

ROOT = Path('/Users/zhouhuanjian/ASTIS-GC')
PRIVATE = ROOT / '.astis/huanjian-fixed-spectrum-normalizer-20261108/source-graph-391602'
PUBLIC = ROOT / 'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-normalizer-semantic-evidence/source-only-review/phase1'
SOURCE = ROOT / '.astis/huanjian-resume-20261103/2610.20492v1.html'
EXPECTED = '6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
PRIVATE.mkdir(parents=True, exist_ok=True)
PUBLIC.mkdir(parents=True, exist_ok=True)
(PUBLIC / 'raw-excerpts').mkdir(exist_ok=True)
raw = SOURCE.read_bytes()
sha = lambda b: hashlib.sha256(b).hexdigest()
assert sha(raw) == EXPECTED
frozen_at = datetime.now(timezone.utc).isoformat()
(PRIVATE / '2610.20492v1.original.raw.html').write_bytes(raw)
soup = BeautifulSoup(raw, 'html.parser')

def dump(path, obj):
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

def text(element):
    element = copy.deepcopy(element)
    for math in element.find_all('math'):
        math.replace_with('$' + math.get('alttext', '') + '$')
    return element.get_text(' ', strip=True)

def raw_span(anchor):
    rx = rb'<(?P<tag>[A-Za-z][A-Za-z0-9]*)\b[^>]*\bid="' + re.escape(anchor.encode()) + rb'"[^>]*>'
    m = re.search(rx, raw)
    assert m, anchor
    tag = m.group('tag')
    depth = 0
    for token in re.finditer(rb'</?' + tag + rb'\b[^>]*>', raw[m.start():]):
        depth += -1 if token.group().startswith(b'</') else 1
        if depth == 0:
            return m.start(), m.start() + token.end()
    raise ValueError(anchor)

regions = ['S2', 'S4.Thmtheorem1', 'S4.SS1', 'S4.SS2.SSS0.Px4', 'S4.SS4', 'A3.SS4']
excerpts = []
for anchor in regions + ['bib.bib3', 'S1.p1.1']:
    start, end = raw_span(anchor)
    content = raw[start:end]
    filename = anchor + '.raw.html'
    (PUBLIC / 'raw-excerpts' / filename).write_bytes(content)
    excerpts.append({'anchor': anchor, 'byte_start_inclusive': start, 'byte_end_exclusive': end,
                     'sha256': sha(content), 'bytes': len(content), 'file': 'raw-excerpts/' + filename,
                     'role': 'selected-region' if anchor in regions else 'context-only'})
    (PRIVATE / (anchor + '.inspection.txt')).write_text(text(soup.find(id=anchor)) + '\n', encoding='utf-8')

nodes = []
def node(id, kind, anchors, statement, **extra):
    nodes.append({'id': id, 'kind': kind, 'anchors': anchors, 'statement': statement,
                  'evidence_status': 'source-only-extracted; independent topology review pending', **extra})

node('N.euclidean-order', 'standing-convention', ['S2.p1.1'], 'Euclidean norm, identity matrix, and A≼B meaning B−A positive semidefinite.')
node('N.orthogonal', 'source-definition', ['S2.p2.m1'], 'O(d)={O∈ℝ^(d×d): OᵀO=I_d}. Haar randomness is generation context, not needed by the universal normalizer conclusion.')
node('N.precision-class', 'source-definition', ['S2.Ex1'], '𝒜_(d,κ) consists of real symmetric A with I_d≼A≼κI_d; S2 permits integer d≥1 and κ≥1.')
node('N.quadratic', 'source-definition', ['S2.SS0.SSS0.Px1.p1.m6','A3.SS4.p2.m1'], 'f_A(x)=V_A(x)=xᵀAx/2, with no additive shift in the literal displayed potential.')
node('N.target', 'source-definition', ['S2.SS0.SSS0.Px1.p1.m7','S4.SS1.p1.2','A3.SS4.p3.m1'], 'The associated target is π_A=N(0,A^(−1)); A is the precision, not the covariance.')
node('N.grid-domain', 'source-premise', ['S4.SS1.p1.1'], 'Hard-family definition is stated for integer d≥2 and real κ≥2; indices in the displayed diagonal are i=1,…,d.')
node('N.theta', 'literal-source-definition', ['S4.E11'], 'θ_i=(i−1/2)π/d.')
node('N.lambda', 'literal-source-definition', ['S4.E11'], 'λ_i=(κ+1)/2+(κ−1)cos(θ_i)/2.')
node('N.diagonal', 'literal-source-definition', ['S4.E11'], 'Λ=diag(λ_1,…,λ_d).')
node('N.rotation', 'literal-source-definition', ['S4.SS1.p1.2'], 'A=OΛOᵀ. Source samples Haar O independently of the algorithm seed; Lemma 4.6 and the normalizer discussion hold for every orthogonal O.')
node('N.fixed-spectrum', 'source-statement', ['S4.SS1.p2.1'], 'The spectrum is deterministic and may be supplied to the algorithm; the hidden component is its eigenbasis O.')
node('N.angle-bounds', 'source-proof-step', ['A3.SS4.p1.m1'], '0<θ_i<π for every i=1,…,d.')
node('N.cosine-bounds', 'source-proof-step', ['A3.SS4.p1.m2'], '−1<cos θ_i<1.')
node('N.eigenvalue-bounds', 'source-proof-step', ['A3.SS4.p1.m3'], '1<λ_i<κ.')
node('N.admissibility', 'source-lemma-and-proof-step', ['S4.Thmtheorem6','A3.SS4.p1.1'], 'For every O∈O(d), I_d≼A≼κI_d for A=OΛOᵀ.')
node('N.symmetry', 'source-implicit-algebraic-consequence', ['S4.SS1.p1.2','S2.Ex1'], 'A is real symmetric because Λ is real diagonal and A=OΛOᵀ; the displayed Lemma 4.6 itself states only the spectral inequalities.')
node('N.smooth-hessian', 'source-proof-step', ['A3.SS4.p2.m2','A3.SS4.p2.m3'], 'V_A is C∞ and ∇²V_A(x)=A.')
node('N.convex-smooth', 'source-proof-step', ['A3.SS4.p2.m4','A3.SS4.p2.m5'], 'V_A is 1-strongly convex and κ-smooth.')
node('N.coercivity-zero', 'source-proof-step', ['A3.SS4.p2.m6','A3.SS4.p2.m7'], 'V_A(0)=0; V_A(x)≥||x||²/2>0 for x≠0.')
node('N.unique-minimizer', 'source-proof-step', ['A3.SS4.p2.1'], '0 is the unique minimizer of V_A.')
node('N.normalizer-detA', 'source-display-claim', ['A3.Ex160'], 'Z_A=(2π)^(d/2)(det A)^(−1/2). The source introduces this by “Gaussian integration gives”; it supplies no explicit Z_A integral definition here.')
node('N.det-invariance', 'source-display-equality', ['A3.Ex160'], 'det(OΛOᵀ)=det Λ, used by the second equality of A3.Ex160. The determinant calculation is omitted.')
node('N.normalizer-detLambda', 'source-display-claim', ['A3.Ex160'], 'Z_A=(2π)^(d/2)(det Λ)^(−1/2).')
node('N.independent-O', 'source-proof-conclusion', ['A3.SS4.p3.2'], 'Since Λ is fixed, Z_A is independent of O.')
node('N.public-known', 'source-statement-and-conclusion', ['S4.SS1.p2.1','A3.SS4.p3.2'], 'Z_A is known whenever the spectrum is public. This is a value/information statement; there is no evaluation-cost bound.')
node('N.diagonal-product', 'source-implicit-algebraic-consequence', ['S4.E11','A3.Ex160'], 'det Λ=∏_(i=1)^d λ_i, so the normalizer can be written (2π)^(d/2)(∏ λ_i)^(−1/2). The product formula is not displayed in the selected source.')
node('N.actual-integral', 'source-implicit-normalizer-interpretation', ['S2.SS0.SSS0.Px1.p1.2','S4.SS1.p2.1','A3.Ex160'], 'Under the ordinary unweighted Gaussian convention, Z_A is the mass ∫_(ℝ^d) exp(−xᵀAx/2) dx against Lebesgue volume. This interpretation is inferred, not an explicit source integral definition.')
node('N.finite-positive-mass', 'source-implicit-analytic-consequence', ['A3.Ex160'], 'The inferred Lebesgue mass is finite and strictly positive because its displayed Gaussian value has positive finite factors. No separate finiteness/integrability assertion is written in C.4.')

gap_specs = [
 ('G.index-angle', ['A3.SS4.p1.1'], 'From d≥2, 1≤i≤d and θ_i=(i−1/2)π/d derive 0<θ_i<π.'),
 ('G.cos-strict', ['A3.SS4.p1.1'], 'Strict cosine bounds on (0,π).'),
 ('G.affine-spectrum', ['A3.SS4.p1.1'], 'Use κ−1>0 and −1<cosθ_i<1 in the literal affine formula to obtain 1<λ_i<κ.'),
 ('G.orthogonal-order', ['A3.SS4.p1.1'], 'Expand xᵀAx as Σ_i λ_i (Oᵀx)_i² and ||Oᵀx||=||x|| to transport diagonal bounds to I≼A≼κI; obtain symmetry as well.'),
 ('G.quadratic-calculus', ['A3.SS4.p2.1'], 'For a real symmetric matrix, prove polynomial C∞, gradient Ax and Hessian A; transport Hessian bounds to the named strong-convexity/smoothness conventions.'),
 ('G.minimizer', ['A3.SS4.p2.1'], 'Evaluate the quadratic at zero, obtain coercivity from I≼A, and use strict positivity away from zero to show unique minimizer.'),
 ('G.integral-convention', ['S4.SS1.p2.1','A3.Ex160'], 'No explicit base-measure/integral definition of Z_A occurs in the selected source. Identify the usual Gaussian normalizer with ∫ exp(−V_A) against unweighted Lebesgue volume; do not replace it by a Gaussian expectation or a determinant-defined proxy.'),
 ('G.gaussian-integration', ['A3.SS4.p3.1','A3.Ex160'], 'The omitted standard Gaussian integral for real symmetric positive definite A gives an integrable exp(−xᵀAx/2), finite positive mass, and mass=(2π)^(d/2)(det A)^(−1/2). No external citation is given at this use site.'),
 ('G.det-conjugation', ['A3.Ex160'], 'det(ABC)=detA detB detC, det(Oᵀ)=detO and OᵀO=I imply (detO)²=1 and hence det(OΛOᵀ)=detΛ. Both determinant components are allowed.'),
 ('G.det-diagonal', ['S4.E11','A3.Ex160'], 'The determinant of the literal diagonal matrix is ∏ λ_i; positivity and finiteness follow from the finite positive eigenvalues.'),
 ('G.real-half-powers', ['A3.Ex160'], 'Interpret d/2 as real half dimension and t^(−1/2) as 1/√t with the positive real square root for t>0. Source gives no separate power/square-root convention; positivity must be discharged, not added as a public premise.'),
 ('G.fixed-known', ['S4.SS1.p2.1','A3.SS4.p3.2'], 'Substitute the fixed deterministic Λ in the scalar formula to obtain O-independence, and use publicly supplied eigenvalues to determine the value; no numerical precision or cost analysis is supplied.')
]
for id, anchors, statement in gap_specs:
    node(id, 'SOURCE_GAP', anchors, statement, gap_class='omitted-standard-bridge' if id!='G.integral-convention' else 'source-implicit-semantic-convention', lean_discharge='not inspected; no claim')

edges=[]
def edge(id, inputs, output, use, role, discharge=None):
    edges.append({'id':id,'operator':'AND','inputs':inputs,'output':output,'consumer_use_site':use,'role':role,
                  'conditional_premises_discharge':discharge or [],'provenance':'raw-source reconstruction; not Lean dependencies'})
edge('E01',['N.grid-domain','N.theta','G.index-angle'],'N.angle-bounds','A3.SS4.p1.1','angle bookkeeping')
edge('E02',['N.angle-bounds','G.cos-strict'],'N.cosine-bounds','A3.SS4.p1.1','strict cosine bound')
edge('E03',['N.grid-domain','N.lambda','N.cosine-bounds','G.affine-spectrum'],'N.eigenvalue-bounds','A3.SS4.p1.1','affine interval', ['κ−1>0 follows from κ≥2'])
edge('E04',['N.orthogonal','N.diagonal','N.rotation','N.eigenvalue-bounds','G.orthogonal-order'],'N.admissibility','A3.SS4.p1.1','diagonal-to-rotated spectral bound',['OᵀO=I comes from O∈O(d); all λ_i are in (1,κ)'])
edge('E05',['N.diagonal','N.rotation','G.orthogonal-order'],'N.symmetry','A3.SS4.p1.1','symmetric real precision')
edge('E06',['N.quadratic','N.symmetry','G.quadratic-calculus'],'N.smooth-hessian','A3.SS4.p2.1','quadratic calculus')
edge('E07',['N.smooth-hessian','N.admissibility','G.quadratic-calculus'],'N.convex-smooth','A3.SS4.p2.1','Hessian-to-regularity',['Hessian=A; I≼A≼κI from C4 p1'])
edge('E08',['N.quadratic','N.admissibility','G.minimizer'],'N.coercivity-zero','A3.SS4.p2.1','quadratic lower bound')
edge('E09',['N.coercivity-zero','G.minimizer'],'N.unique-minimizer','A3.SS4.p2.1','strict away-from-zero minimum',['x≠0 is the local comparison condition, not an assumption on all x'])
edge('E10',['N.quadratic','N.target','G.integral-convention'],'N.actual-integral','A3.SS4.p3.1 → A3.Ex160','inferred ordinary normalizer meaning')
edge('E11',['N.symmetry','N.admissibility','N.actual-integral','G.gaussian-integration','G.real-half-powers'],'N.normalizer-detA','A3.SS4.p3.1 / A3.Ex160 first equality','compressed Gaussian integration',['SPD follows from symmetry and I≼A; integrability is produced by the Gaussian integral, not assumed'])
edge('E12',['N.orthogonal','N.rotation','G.det-conjugation'],'N.det-invariance','A3.Ex160 second equality','determinant invariance',['(detO)²=1 follows from OᵀO=I; detO=+1 is not required'])
edge('E13',['N.normalizer-detA','N.det-invariance'],'N.normalizer-detLambda','A3.Ex160 second equality','substitution')
edge('E14',['N.diagonal','N.eigenvalue-bounds','G.det-diagonal'],'N.diagonal-product','A3.Ex160 interpreted using S4.E11','optional product representation',['every λ_i>1, finite d'])
edge('E15',['N.normalizer-detA','G.gaussian-integration','G.real-half-powers'],'N.finite-positive-mass','A3.Ex160','inferred finite positive actual mass',['detA>0 is generated by the positive-definite Gaussian integration bridge'])
edge('E16',['N.fixed-spectrum','N.normalizer-detLambda','G.fixed-known'],'N.independent-O','A3.SS4.p3.2','remove eigenbasis dependence')
edge('E17',['N.fixed-spectrum','N.normalizer-detLambda','G.fixed-known'],'N.public-known','A3.SS4.p3.2 and S4.SS1.p2.1','known value under public spectrum',['public-spectrum premise is local to the information claim, not to the equality or integral finiteness'])

paragraph_nodes = {
 'S2.p1.1':['N.euclidean-order'], 'S2.p2.1':['N.orthogonal'],
 'S2.SS0.SSS0.Px1.p1.1':['N.precision-class'],
 'S2.SS0.SSS0.Px1.p1.2':['N.quadratic','N.target'],
 'S4.SS1.p1.1':['N.grid-domain'], 'S4.SS1.p1.2':['N.rotation','N.quadratic','N.target'],
 'S4.SS1.p2.1':['N.fixed-spectrum','N.public-known'],
 'S4.SS2.SSS0.Px4.p1.1':['N.admissibility'], 'S4.Thmtheorem6.p1.1':['N.admissibility'],
 'A3.SS4.p1.1':['N.angle-bounds','N.cosine-bounds','N.eigenvalue-bounds','N.admissibility'],
 'A3.SS4.p2.1':['N.smooth-hessian','N.convex-smooth','N.coercivity-zero','N.unique-minimizer'],
 'A3.SS4.p3.1':['N.target','N.normalizer-detA'],
 'A3.SS4.p3.2':['N.independent-O','N.public-known']
}
display_nodes={'S2.Ex1':['N.precision-class'],'S4.E11':['N.theta','N.lambda','N.diagonal'],'A3.Ex160':['N.normalizer-detA','N.det-invariance','N.normalizer-detLambda']}
exclude_reasons={
 'S2.SS0.SSS0.Px1.p2.1':'Oracle-access equivalence, gradient/function reconstruction and query-complexity equality are outside the scalar normalizer component.',
 'S2.SS0.SSS0.Px2.p1.1':'Borel algorithms, private randomness, output/stopping rules and deterministic query caps are algorithmic context, not normalizer hypotheses.',
 'S2.SS0.SSS0.Px3.p1.1':'Total variation definition is accuracy context; normalizer is an exact scalar mass.',
 'S2.SS0.SSS0.Px3.p1.2':'Dominating measure here belongs to the TV identity; it does not explicitly define the normalizer base measure. Bounded-test TV bound is outside scope.',
 'S2.SS0.SSS0.Px4.p1.1':'Output law and sampling-complexity definition are outside exact Gaussian integration.',
 'S2.SS0.SSS0.Px4.p1.2':'Uniform TV accuracy, seed averaging and deterministic-vs-expected query caps are scope context only.',
 'S4.Thmtheorem1.p1.1':'Lower-bound parameter quantifiers δ∈(0,1), d≥d0(δ), 2≤κ≤d^(1−δ), 0<ε≤1/10 are recorded only for scope separation; they are not premises of Eq11/C4 normalizer value.',
 'S4.Thmtheorem2.p1.1':'κ=2 affine-query equivalence, Krylov statistic comparison, moments and √κ query-factor explanation are background lower-bound analysis, not normalizer proof.',
 'S4.SS4.p1.1':'Scope separation: the lower-bound theorem has restricted κ range and no increasing ε-dependence; these are not normalizer limitations.',
 'S4.SS4.SSS0.Px1.p1.1':'Krylov representation, distinct eigenvalues and enlarged-space generator count concern failure of the uniform-statistic lower-bound route.',
 'S4.Thmtheorem7.p1.1':'Lemma4.7 dimension of random Krylov space is a lower-bound-analysis limitation; not needed for exact normalizer.',
 'S4.SS4.SSS0.Px1.p2.1':'Krylov full-dimensionality, cosine-square identity and unit-coordinate test are analysis-limit calculations only.',
 'S4.SS4.SSS0.Px1.p2.2':'Comparison with Lemma4.4 threshold 1/2 limits a separating-test proof, not integration or admissibility.',
 'S4.SS4.SSS0.Px2.p1.1':'Threshold conditions, Chebyshev/Lemma4.5, Bernstein/FactC.6 and normalized-bias decay concern accuracy lower-bound analysis only.',
 'S4.SS4.SSS0.Px2.p1.2':'Logarithmic q bound and inability to improve ε-dependence by constants/thresholds are scope exclusions.',
 'S4.Thmtheorem8.p1.1':'Remark4.8 explicitly says the limits concern the proof and leaves stronger fixed-spectrum lower bounds open; no restriction on normalizer equality.'
}
table_exclusions={
 'S2.E1':'Exact first-order oracle value/gradient formula is outside scalar integration; the quadratic itself is separately inventoried at its literal definition.',
 'S2.Ex2':'TV distance formula, including its arbitrary common dominating measure, does not define Z_A or its base measure.',
 'S2.E2':'Sampling query-complexity infimum, deterministic cap and uniform TV requirement are outside the normalizer.',
 'S4.Ex9':'Main lower bound Q_G≥(δ/256)√κ log d is scope-only and is not proved or claimed by this graph.',
 'S4.Ex28':'Random Krylov dimension formula is scope-only.',
 'S4.Ex29':'Rayleigh-quotient obstruction for a full Krylov space is scope-only.',
 'S4.Ex30':'Threshold/Bernstein/bias inequality limits the lower-bound proof and is scope-only.'
}

inventory=[]
def add_item(id, kind, anchor, value, assigned=None, reason=None, **extra):
    assert bool(assigned) != bool(reason), (id,assigned,reason)
    inventory.append({'id':id,'kind':kind,'anchor':anchor,'source_text_inspection_only':value,
                      'disposition':'NODE' if assigned else 'EXCLUDED','nodes':assigned or [],
                      **({'reason':reason} if reason else {}),**extra})

seen=set()
for region in regions:
    root=soup.find(id=region)
    for e in [root]+root.find_all(True):
        cl=e.get('class',[]); aid=e.get('id')
        if (e.name=='p' and 'ltx_p' in cl):
            if aid not in seen:
                seen.add(aid)
                add_item(aid,'substantive-paragraph',aid,text(e),paragraph_nodes.get(aid),exclude_reasons.get(aid))
        elif e.name=='table' and 'ltx_equation' in cl:
            add_item(aid,'reused-display',aid,text(e),display_nodes.get(aid),table_exclusions.get(aid))
        elif e.name=='div' and 'ltx_theorem' in cl:
            assigned=['N.admissibility'] if aid=='S4.Thmtheorem6' else None
            reasons={'S4.Thmtheorem1':'Theorem4.1 is scope-only lower-bound context; its full parameter order is retained in its paragraph item.', 'S4.Thmtheorem2':'Remark4.2 lower-bound construction comparison is not a Gaussian-integration dependency.', 'S4.Thmtheorem7':'Lemma4.7 random Krylov dimension is outside exact scalar normalization.', 'S4.Thmtheorem8':'Remark4.8 concerns limits of the lower-bound proof, not the normalizer.'}
            add_item(aid,'theorem-or-remark',aid,text(e),assigned,reasons.get(aid))
        elif e.name=='cite':
            parent=e.find_parent('p'); pa=parent.get('id'); idx=len([x for x in inventory if x['kind']=='external-citation-use'])+1
            add_item('cite-'+str(idx),'external-citation-use',pa,text(e),reason='OpenAI [22] construction provenance/comparison only. No external result is cited for the C4 Gaussian-integration step.',references=[a.get('href') for a in e.find_all('a')])
        elif e.name=='a' and 'ltx_ref' in cl and not e.find_parent('cite'):
            parent=e.find_parent(['p','h6']); pa=parent.get('id') if parent else region
            idx=len([x for x in inventory if x['kind']=='reference-use'])+1
            href=e.get('href','')
            assigned=['N.admissibility'] if href=='#A3.SS4' else None
            add_item('ref-'+str(idx),'reference-use',pa or region,text(e),assigned,None if assigned else 'Reused internal reference is lower-bound/analysis context or a section title; it contributes no scalar-normalizer proof edge.',reference=href)
        elif e.name=='math':
            parent=e.find_parent('p'); pa=parent.get('id') if parent else None
            table=e.find_parent('table'); ta=table.get('id') if table else None
            assigned=display_nodes.get(ta) if ta else paragraph_nodes.get(pa)
            reason=table_exclusions.get(ta) if ta else exclude_reasons.get(pa)
            if not assigned and not reason:
                reason='Formula occurs in a scope-only theorem/remark title, not a normalizer dependency.'
            # Precisely separate the oracle part of the mixed target/oracle paragraph.
            if aid in ['S2.SS0.SSS0.Px1.p1.m8']:
                assigned=None;reason='Point domain is introduced for the first-order oracle, outside integration; the ambient R^d target domain is separately retained in the source contract.'
            if pa=='S2.p2.1' and aid!='S2.p2.m1':
                assigned=None;reason='Haar components, their 1/2 probabilities, and determinant-conditioned Haar measure are generation conventions; they are not normalizer premises.'
            add_item(aid,'inline-or-display-formula',aid,e.get('alttext',''),assigned,reason)

add_item('bib.bib3','bibliography-entry','bib.bib3',text(soup.find(id='bib.bib3')),reason='OpenAI (2026), Subpolynomial query complexity for well-conditioned log-concave sampling, is cited for construction/comparison. Its proof is not an input to the C4 scalar normalizer claim; no upstream document was opened.')

contract={
 'schema':'astis-source-only-phase1/v1', 'status':'FROZEN_SOURCE_ONLY; independent topology/coverage review pending',
 'extractor':'/root/norm_source_graph_391602', 'freeze_time_utc':frozen_at,
 'source':{'title':'On Complexity of Gaussian Sampling','authors':'Zhou / Suzuki','version':'arXiv:2610.20492v1','path':str(SOURCE.relative_to(ROOT)),'sha256':EXPECTED},
 'selected_regions':regions,'exact_candidate_visible':False,'implementation_lean_visible':False,
 'seven_semantic_slots':{
  'objects':{'explicit':'The literal cosine grid θ_i, eigenvalues λ_i, diagonal Λ, orthogonal O, rotated precision A=OΛOᵀ, quadratic f_A=V_A=xᵀAx/2, target π_A=N(0,A^(−1)), and scalar Z_A in A3.Ex160.', 'inferred':'Z_A denotes actual unweighted Gaussian mass, rather than a formula used to define a proxy.'},
  'domains':{'explicit':'Eq11 hard family: integer d≥2, κ≥2, i=1,…,d, O∈O(d), x∈ℝ^d. S2 broader precision class uses d≥1 and κ≥1.', 'inferred':'κ and all matrix/vector entries are real; the ordinary normalizer uses Lebesgue volume on finite-dimensional ℝ^d. No base measure is explicitly written for Z_A.'},
  'quantifiers':{'explicit':'Fix any allowed d,κ and the deterministic Eq11 spectrum. For every O∈O(d), C4 gives the same Z_A. The spectrum may be public; then its normalizing value is known.', 'scope_note':'Haar sampling and seed independence describe the hard-instance distribution, not an almost-sure restriction or additional requirement for the equality.'},
  'assumptions':{'SOURCE':['integer d≥2','κ≥2','literal Eq11 grid/diagonal','O∈O(d)'], 'STANDING':['real Euclidean quadratic/centered Gaussian conventions from S2'], 'TYPING':['finite d×d real matrices and d-vectors','indices 1,…,d'], 'proof_ingredients_not_binders':['spectral positivity and admissibility','symmetry and determinant invariance','determinant product and positivity','Gaussian integrability, finite positive mass, and value','positive real half-power identities'], 'RULED':[], 'EXCESS':[], 'interpretation_boundary':'This is a raw-source contract, not an audit of any unseen candidate binder list.'},
  'conclusion':{'explicit':'A3.Ex160: Z_A=(2π)^(d/2)(det A)^(−1/2)=(2π)^(d/2)(det Λ)^(−1/2); C4 p3.2: independent of O and known whenever spectrum is public.', 'source_implicit_consequences':['Actual integral ∫_(ℝ^d)exp(−xᵀAx/2) dx equals that value under ordinary unweighted Lebesgue convention.','Mass is finite and strictly positive.','det Λ=∏λ_i gives diagonal product form.'], 'separate_full_C4_conclusions':['I≼A≼κI for every O','C∞, Hessian A, 1-strong convexity, κ-smoothness','V_A(0)=0, V_A(x)≥||x||²/2 and unique minimizer zero']},
  'scopes_senses':{'mass':'An exact scalar normalizing mass of the literal unshifted quadratic. The source does not display its defining integral.', 'powers':'Positive real square root/inverse square root; real d/2 exponent are conventional inferences, supported by positive spectrum. No signed branch or integer-division convention is supplied.', 'orthogonal':'All real orthogonal matrices, including detO=−1, not just special orthogonal matrices.', 'separation':'No algorithm, TV guarantee, sampler, query lower bound, evaluation precision, running time or cost is concluded.'},
  'constant_dependencies':{'normalizer':'Depends on d and the fixed κ-dependent Eq11 eigenvalues, hence on d,κ and not O or any algorithm seed.', 'known_value':'Conditional only on access to the public deterministic spectrum; no complexity/precision dependence stated.', 'excluded_main_bound':'Theorem4.1: ∀ fixed δ∈(0,1), ∃d0(δ), ∀integer d≥d0(δ), 2≤κ≤d^(1−δ), 0<ε≤1/10, Q_G≥(δ/256)√κ log d. These additional parameters/ranges belong to the lower bound, not C4 normalization.'}
 },
 'literal_definition_audit':{'kind':'literal','formula_fidelity':'θ, λ, Λ, A and V are retained as displayed; no choice, fallback, off-source branch or characterization-by-normalizer is present in this contract.', 'Z_A':'Source claims a normalizing value but does not explicitly define Z_A by a displayed integral. The integral interpretation and analytic bridges remain marked source-implicit/SOURCE_GAP.'},
 'alternative_routes':{'source_explicit':[], 'policy':'The author gives one compressed Gaussian-integration route, followed by determinant invariance and fixed-spectrum information. No alternative author proofs are invented. Diagonal product is an optional consequence, not an extra conjunct required by the detA formula.'},
 'truth_boundary':['No implementation, proof API, current frontier, root seal, prior graph/review/verdict, publication, lesson or generated site was read.','No Lean proof, source fidelity acceptance, independent coverage approval, source-V status, theorem completion or publication status is asserted.','Independent topology review must still reread the source and this graph; extractor cannot approve its own coverage.']
}

graph={'schema':'astis-source-proof-graph/v1','status':'frozen source-only extraction; NOT independently reviewed',
       'source_sha256':EXPECTED,'nodes':nodes,'hyperedges':edges,
       'routes':[{'id':'R.author-normalizer','provenance':'Single compressed source route; not an alternative implementation design','operator':'AND','inputs':['N.normalizer-detA','N.det-invariance'],'output':'N.normalizer-detLambda'},
                 {'id':'R.product-consequence','provenance':'Optional source-implicit algebraic representation, not needed for R.author-normalizer','operator':'AND','inputs':['N.normalizer-detLambda','N.diagonal-product'],'output_description':'Z_A=(2π)^(d/2)(∏λ_i)^(−1/2)'}],
       'and_or_semantics':'Each hyperedge is one sufficient AND use-site. No mutually alternative routes are asserted. Optional product representation, calculus branch, and main-bound exclusions must not be flattened into premises of the normalizer equality.',
       'conditional_discharge_policy':'Derived positivity, determinant identities and integrability are proof edges/SOURCE_GAP obligations, never assumed public binders.'}

coverage={'schema':'astis-source-coverage-inventory/v1','status':'structurally complete extraction; independent substantive review pending','source_sha256':EXPECTED,'selected_regions':regions,'coverage_unit':'Every ltx_p paragraph, equation table, theorem/remark, math formula, explicit citation use and internal reference use in the selected raw regions; bibliography provenance separately listed. Headers have no independent mathematical claim.','items':inventory,
          'counts':{'items':len(inventory),'NODE':sum(i['disposition']=='NODE' for i in inventory),'EXCLUDED':sum(i['disposition']=='EXCLUDED' for i in inventory),'SOURCE_GAP_nodes':sum(n['kind']=='SOURCE_GAP' for n in nodes)},
          'independent_coverage_approved':False}

process_paths=['AGENTS.md','docs/contributor-codex-contract.md','docs/theorem-publication-protocol.md','docs/proof-digestion-protocol.md','docs/evidence-routed-memory-protocol.md','.agents/skills/astis-source-dependency-audit/SKILL.md','.agents/skills/astis-semantic-roundtrip/SKILL.md']
provenance={'schema':'astis-phase1-input-provenance/v1','freeze_time_utc':frozen_at,'extractor':'/root/norm_source_graph_391602','process_inputs':[{'path':p,'sha256':sha((ROOT/p).read_bytes())} for p in process_paths],
 'raw_input':{'path':str(SOURCE.relative_to(ROOT)),'sha256':sha(raw),'bytes':len(raw),'CRLF_count':raw.count(b'\r\n'),'LF_count':raw.count(b'\n'),'archive':str((PRIVATE/'2610.20492v1.original.raw.html').relative_to(ROOT)),'lossless_archive_sha256':sha((PRIVATE/'2610.20492v1.original.raw.html').read_bytes())},
 'raw_excerpts':excerpts,
 'exposure_log':[
  {'sequence':1,'material':'Parent assignment','scope':'Selected mathematical component and process paths; exact sealed candidate withheld.'},
  {'sequence':2,'material':'Required process documents and semantic-roundtrip SKILL.md','scope':'Process-only, including canonical seven slot names; required AGENTS incidental historical prose was visible.'},
  {'sequence':3,'material':'Pinned raw HTML hash/line endings','scope':'Verified expected raw SHA; no text normalization. Initial system Python bs4 import failed; Anaconda bs4 used for inspection only.'},
  {'sequence':4,'material':'Raw section/theorem IDs and selected source text','scope':regions},
  {'sequence':5,'material':'Raw-paper normalization-term search','scope':'Read paragraph matches only: S1.p1.1, S2.SS0.SSS0.Px1.p1.1, S4.SS1.p2.1, S4.SS3.SSS0.Px2.p1.1, A1.SS1.p2.1, A2.SS2.p2.1, A2.SS2.SSS1.p1.1, A2.SS2.SSS1.p2.2, A3.SS2.p3.1, A3.SS3.p1.1, A3.SS3.p9.1. Unrelated normalization mentions were not promoted into this graph.'},
  {'sequence':6,'material':'Raw bibliography bib.bib3 / [22]','scope':'Construction citation identity only; no upstream paper or target-proof/API search.'},
  {'sequence':7,'material':'Phase1 authoring from the raw source','scope':'Only owned phase1/public and source-graph-391602/private paths written.'}
 ],
 'forbidden_material_exposure':{'implementation_Lean':False,'root_seal_signature_audit_definition_candidate':False,'current_frontier_or_ledgers':False,'publication_lessons_generated_site':False,'previous_graph_review_verdict_repair':False,'global_evidence_filename_search':False},
 'actions_not_taken':['No build, theorem/proof edits, API search, shared/global/ledger mutation, new Goal or background ASTIS action.','No candidate comparison; phase2 has not started.'],
 'skill_usage':'astis-source-dependency-audit applied as source-only process. Missing bridges classified as source-contract-gap / internal-paper-step rather than searched in implementation libraries under the assigned phase1 isolation.'}

dump(PUBLIC/'source-contract.json',contract)
dump(PUBLIC/'source-proof-graph.json',graph)
dump(PUBLIC/'coverage-inventory.json',coverage)
dump(PUBLIC/'input-provenance.json',provenance)

summary=f'''# Phase 1 raw-first freeze

Frozen UTC: {frozen_at}. Extractor: `/root/norm_source_graph_391602`.

Status: **source-only extraction; independent topology/coverage review pending**. No Lean/proof/source-fidelity acceptance or completion is claimed. The exact candidate statement and implementation remain unseen. Phase 2 comparison has not begun.

The pinned original is `On Complexity of Gaussian Sampling`, arXiv:2610.20492v1, SHA-256 `{EXPECTED}`. The private archive is an exact byte copy; it has {len(raw)} bytes, no CRLF line endings, and {raw.count(bytes([10]))} LF bytes. Public raw excerpts retain exact byte slices and offsets. Inspection text is derived and is not source evidence.

The source contract is the literal Eq.11 family for integer d≥2 and κ≥2: θ_i=(i−1/2)π/d, λ_i=(κ+1)/2+(κ−1)cosθ_i/2, Λ=diag(λ_i), A=OΛOᵀ, with every O∈O(d). Section2 supplies the unshifted quadratic and centered target N(0,A⁻¹).

C.4 is `A3.SS4`; its normalizer display is `A3.Ex160`. It states Z_A=(2π)^(d/2)(detA)^(−1/2)=(2π)^(d/2)(detΛ)^(−1/2), followed by independence of O and known value whenever the fixed spectrum is public. The selected source does **not** explicitly define Z_A by an integral or name its base measure. The actual unweighted Lebesgue integral ∫exp(−xᵀAx/2)dx, finite positive mass, diagonal determinant product, and positive real half-power conventions are explicit source-implicit consequences/bridges in this extraction, never fabricated source definitions.

Full C.4 coverage keeps admissibility, C∞/Hessian/strong-convexity/smoothness, zero value/coercivity/unique minimizer, Gaussian mass/value, determinant invariance, O-independence, and public-spectrum known value distinct. The Gaussian integration and determinant algebra are compressed in the paper and remain SOURCE_GAP nodes. Derived integrability, positivity and determinant identities are edges, not extra public premises.

Theorem4.1 and the whole Section4.4 are exhaustively inventoried for scope separation. Their δ/d/κ/ε ranges, Krylov dimensions, statistics, concentration thresholds, TV/query lower bounds and limitations do not become normalizer assumptions or conclusions. No precision/evaluation-cost or sampling-algorithm claim follows from “known”. The construction citation [22] is provenance only, not a cited Gaussian-integral theorem.

The inventory has {len(inventory)} entries: {coverage['counts']['NODE']} NODE dispositions and {coverage['counts']['EXCLUDED']} explicit exclusions; the graph has {len(nodes)} nodes, including {coverage['counts']['SOURCE_GAP_nodes']} SOURCE_GAP nodes, and {len(edges)} use-site hyperedges. This count is a mechanical inventory, not self-approval of substantive coverage. The author supplies one compressed Gaussian-integration route; no alternative author proof has been invented. Optional product representation and collateral calculus remain separate branches rather than false AND premises.

Artifacts: `source-contract.json` contains all seven semantic slots; `source-proof-graph.json` contains use-site edges and conditional discharge; `coverage-inventory.json` contains every selected paragraph/display/theorem/formula/citation/reference disposition; `input-provenance.json` records input hashes, byte spans and exposures. `manifest.json` hashes every artifact and the exact archive; `manifest.sha256` seals the manifest.

**STOP: phase1 is frozen. Await the parent's phase2 input; do not read any candidate or implementation before this freeze is delivered.**
'''
(PUBLIC/'PHASE1-FREEZE.md').write_text(summary,encoding='utf-8')

# Structural checks are not a substitute for independent mathematical review.
known={n['id'] for n in nodes}
assert len(known)==len(nodes)
assert len({i['id'] for i in inventory})==len(inventory)
for e in edges:
    assert e['output'] in known and set(e['inputs'])<=known
    assert e['consumer_use_site']
for i in inventory:
    assert set(i['nodes'])<=known
    assert (i['disposition']=='NODE')==bool(i['nodes'])
    assert i['disposition']=='NODE' or i.get('reason')
for item in excerpts:
    b=(PUBLIC/item['file']).read_bytes()
    assert b==raw[item['byte_start_inclusive']:item['byte_end_exclusive']]
manifest={'schema':'astis-phase1-freeze-manifest/v1','freeze_time_utc':frozen_at,'source_sha256':EXPECTED,'status':'FROZEN_SOURCE_ONLY_UNREVIEWED','files':[]}
for p in sorted(PUBLIC.rglob('*')):
    if p.is_file() and p.name not in ['manifest.json','manifest.sha256']:
        b=p.read_bytes();manifest['files'].append({'path':str(p.relative_to(ROOT)),'sha256':sha(b),'bytes':len(b)})
for p in sorted(PRIVATE.iterdir()):
    if p.is_file():
        b=p.read_bytes();manifest['files'].append({'path':str(p.relative_to(ROOT)),'sha256':sha(b),'bytes':len(b)})
dump(PUBLIC/'manifest.json',manifest)
digest=sha((PUBLIC/'manifest.json').read_bytes())
(PUBLIC/'manifest.sha256').write_text(digest+'  manifest.json\n',encoding='ascii')
print(json.dumps({'freeze_time_utc':frozen_at,'public':str(PUBLIC),'counts':coverage['counts'],'nodes':len(nodes),'hyperedges':len(edges),'manifest_sha256':digest,'artifact_sha256':{p.name:sha(p.read_bytes()) for p in [PUBLIC/'source-contract.json',PUBLIC/'source-proof-graph.json',PUBLIC/'coverage-inventory.json',PUBLIC/'input-provenance.json',PUBLIC/'PHASE1-FREEZE.md']}},indent=2))
