"""Only read/parse/pin existing R16 evidence; never imports/calls any normal API or verification driver."""
from verification_common import *
import traceback

def main():
    E=REPO/'research-wiki/technical-lemmas/trace-exponential-domain-semantic-evidence'
    R=REPO/'.astis/semantic-neutral-20261115/trace_exp_reader_61e4'
    N=OWN.parent
    src=E/'source-review/trace_exp_fresh_source_51c8/originals'
    plpath=E/'PROVED_LOCAL-evidence.full.json';pl=read(plpath)
    assert file_sha(plpath)==PLSHA and len(pl)==24
    exact(OWN/'PROVED_LOCAL-original24.exact.json',plpath.read_bytes())
    araw=(REPO/ADVPATH).read_bytes();draw=(REPO/DISCPATH).read_bytes();ar,dr,adv,disc=replay(araw,draw)
    exact(PRIVATE/'preparation-A-ledger.exact.jsonl',araw);exact(PRIVATE/'preparation-D-ledger.exact.jsonl',draw)
    target=adv[ADV];rows=[x for x in ar if x.get('advance_id')==ADV]
    assert target['state']=='PROVED_LOCAL' and target['owner_id']==OWNER and target['publication_declarations']==target['target_declarations']==[P]
    assert sum(x.get('to_state')=='PROVED_LOCAL' for x in rows)==1 and not any(x.get('to_state')=='VERIFIED' for x in rows)
    assert next(x['evidence'] for x in rows if x.get('to_state')=='PROVED_LOCAL')==pl
    append=(E/'actual-PROVED_LOCAL-append.exact.jsonl').read_bytes();assert sha(append)==PLAPPENDSHA and any(line+b'\n'==append for line in araw.splitlines())
    head=git('preparation-HEAD','rev-parse','HEAD').decode().strip();branch=git('preparation-branch','symbolic-ref','HEAD').decode().strip()
    indexpath=Path(git('preparation-index-path','rev-parse','--git-path','index').decode().strip());indexpath=indexpath if indexpath.is_absolute() else REPO/indexpath
    exact(PRIVATE/'preparation-index.exact',indexpath.read_bytes())
    pins={k:ident(p) for k,p in {
      'PL':plpath,'PL_append':E/'actual-PROVED_LOCAL-append.exact.jsonl',
      'native_original':N/'native-mathematics-report.v1.json','native_carried':E/'independent-native-and-preproof-originals/readable-native-originals/native-mathematics-report.v1.json',
      'native_fake_scan':E/'independent-native-and-preproof-originals/readable-native-originals/fake-closure-scan.v1.json',
      'native_original_manifest':N/'public-safe-selected-originals.manifest.v1.json',
      'reader_original':R/'reader-acceptance-v1/reader-acceptance-report.json','reader_manifest_original':R/'reader-acceptance-v1/public-selected-originals.manifest.json',
      'public_audit':REPO/'research-wiki/semantic-roundtrip/audits/huanjian-trace-exponential-domain.json',
      'private_audit':E/'private-consumer-audit.source-reviewed.v2.json',
      'P_source_review':src/'phase3_P_successor_raw_review_result.json','T_source_review':src/'phase3_T_successor_raw_review_result.json',
      'source_successor_run':src/'phase3_source_scope_delta_review_run.immutable.json','source_full_run':src/'phase2_review_run.immutable.json',
      'decoder_receipt':E/'decoder-originals/blind_decoder_8a39/verification-receipt.v1.json'}.items()}
    data={k:pin_bytes(v) for k,v in pins.items()}
    assert sha(data['native_original'])==NATIVESHA and data['native_original']==data['native_carried']
    assert sha(data['reader_original'])==READERSHA and sha(data['reader_manifest_original'])==READERMANIFESTSHA
    for n in ['public_audit','private_audit']:
        audit=json.loads(data[n]);assert audit['state']=='source-reviewed' and audit['publication_binding_sha256']==BINDING
    slots={'objects','domains','quantifiers','assumptions','conclusion','scopes','constant_dependencies'}
    for n,expected in [('P_source_review','aa3f55d76f8e5b2293f5422595096b3ce2653f7c2c41bd6bf4047e115055ef1b'),('T_source_review','e24f30c0afeefa77e24c419aa07c996fb461b38bccacd8e1e893537115359af3')]:
        x=json.loads(data[n]);assert sha(data[n])==expected and set(x['semantic_slots'])==slots and not x['deltas'] and x['publication_binding_sha256']==BINDING and x['reviewer']=='trace_exp_fresh_source_51c8'
    full=json.loads(data['source_full_run']);assert len({full['reviewer'],full['formalizer'],full['blind_decoder']})==3 and full['source_only_phase1_frozen_before_candidate_read']
    assert sha(data['source_successor_run'])=='8543d7d7365431d074a20c5491750620d242a1b3125379fd8221d9e5270bf64c' and sha(data['source_full_run'])=='f5cbc9dac309eda9127f3551b368c6bd2d2765e5793947f7e59d7d44a1cd212c'
    original_gates=[]
    for row in pl['focused_checks']['actual_frozen_metadata_gates']:
        receipt=json.loads(pin_bytes(row));assert receipt['exit_code']==0 and receipt['head_before']==receipt['head_after']==pl['checked_metadata_commit']=='ef5cfe9feb38b716aa17595aedcaea81b18fb032'
        assert file_sha(Path(receipt['log']))==receipt['log_sha256'];original_gates.append({'gate':row['gate'],'actual_checked_commit':receipt['head_before'],'actual_exit_code':0,'original_receipt_sha256':row['sha256']})
    assert len(original_gates)==6
    for name in ['verification_common.py','verification_driver.py','prepare_readonly.py']:ast.parse((OWN/name).read_text(),filename=name)
    tree=ast.parse((OWN/'verification_driver.py').read_text());calls=[n for n in ast.walk(tree) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='transition_advance']
    assert len(calls)==1 and calls[0].args[0].id=='ADV' and calls[0].args[1].value=='VERIFIED'
    assert not any((OWN/n).exists() for n in ['normal-V-evidence.full.json','normal-V-exact-append.jsonl','normal-V-outcome.public.json','window1-OS-receipt.public.json'])
    pins['reader_carried']={'file':'ROOT_PENDING_EXACT_PUBLICSAFE_READER_CARRIER_OR_ARCHIVE','sha256':'ROOT_PENDING_CONTAINER_OR_FILE_SHA256','member':'OPTIONAL_EXACT_ORIGINAL_REPORT_MEMBER_IF_ARCHIVED','member_sha256':READERSHA}
    draft={'schema':'r16-independent-single-window-authorization-v1','authorization':'PREPARED_ONLY_NOT_AUTHORIZED','authorized_action':'NORMAL_PROOF_V_ONCE','advance_id':ADV,'owner_id':OWNER,'verifier_id':VERIFIER,'worker_id':VERIFIER,'normal_API_calls_authorized':1,'math_commit':MATH,'source_binding':BINDING,'carrier_commit':'ROOT_PENDING_FROZEN_SOURCE_EVIDENCE_CARRIER','expected_branch':branch,'expected_target_cell_sha256':'ROOT_PENDING_FRESH_CARRIER_TARGET_CELL_SHA256','expected_api_sha256':file_sha(REPO/'tools/astis_advance.py'),'scripts':{n:file_sha(OWN/n) for n in ['verification_common.py','verification_driver.py']},'separate_window2_authorization_required':True,'gate_summary':{'file':'ROOT_PENDING_ACTUAL_GATE_SUMMARY','sha256':'ROOT_PENDING_ACTUAL_GATE_SUMMARY_SHA256'},'evidence_pins':pins,'ROOT_window_hold':'ROOT must hold HEAD/branch/index/all other tracked/ledgers/frontiers stable for each individually authorized window. Window2 is never automatically launched.'}
    write(OWN/'window1.authorization.draft.json',draft)
    cellauth=copy.deepcopy(draft);cellauth.update({'authorized_action':'TARGET_CELL_PROJECTION_ONCE','normal_API_calls_authorized':0,'window1_outcome':{'file':'ROOT_PENDING_COMPLETED_WINDOW1_PUBLIC_OUTCOME','sha256':'ROOT_PENDING_REAL_OUTCOME_SHA256'},'expected_advance_ledger_sha256':'ROOT_PENDING_ACTUAL_WINDOW1_AFTER_LEDGER_SHA256','expected_discovery_ledger_sha256':'ROOT_PENDING_FRESH_DISCOVERY_LEDGER_SHA256'})
    write(OWN/'window2.authorization.draft.json',cellauth)
    write(OWN/'preparation-plan-and-guard-contract.json',{
      'status':'PREPARED_ONLY_NO_PROOF_V_OR_CELL_PROJECTION_EXECUTED','advance_id':ADV,'owner_id':OWNER,'independent_verifier_id':VERIFIER,'current_readonly_observation':{'PL_count':1,'V_count':0,'owner_and_exact_public_P_target_set_match':True,'original_PL_top_level_field_count':24,'original_PL_sha256':PLSHA,'original_PL_exact_append_sha256':PLAPPENDSHA,'HEAD_observed_not_final_authorized_carrier':head},
      'evidence_judgment':'The independently completed immutable301728 native/math/type/value/kernel checks, actual independent e441 source/wholemodule/seven-slot review, and independent actual isolated reader acceptance supply the narrow mathematical/source/reader boundaries in principle. This preparation is not a VERIFIED judgment or transition; exact carrier, all current gates/evidence custody and fresh private guards must still pass independently in the authorized window.',
      'original24_retention':'Deep-copy original PL and add only new disjoint top-level keys; each original key/value remains structurally identical inline, including historical reader pending snapshot. Exact original JSON bytes also retained separately.',
      'window1':'Only the one actual transition_advance(ADV, VERIFIED, worker_id=verifier_id). Atomic durable once-marker precedes it. Every frontier including target stays exact. Prefix and one exact JSONL suffix verified after call; on exception inspect actual suffix privately, never retry/append/rollback. API/replay/full ledger/index/foreign maps and raw streams remain local-private.',
      'window2':'New separate ROOT authorization only after actual window1 exit0 and all postguards. Fresh guards protect both exact ledgers, HEAD/branch/index, tracked modes/bytes, all other cells/foreign states. Only target cell status/evidence/current counters/reader refs/consumer status and precise phase boundary projected; statements/seal/source semantics/second planned consumer/purification unchanged.',
      'guard_contract':['Exact HEAD commit and symbolic branch plus HEAD and branch-ref files; exact index bytes/mode.','Every tracked file path/type/content/mode; permitted target content mutation never changes modes.','All original A-ledger bytes as prefix; every foreign A state and every D state including modes exact; entire D ledger exact.','Every frontier JSON file path/content/mode including old frontier files; all other old tracked frontiers also covered by whole tracked guard.','No detached ASTIS, Git mutation, stabilization/Registry/global graph/site/main or owner release. Local replay is not an origin/main stabilization status claim.'],
      'gate_identity_at_preparation':original_gates,'future_gate_requirement':'Draft requires six honest actual receipt/log bindings at the exact declared checked identity; no ef5c receipt can be relabeled as a new source-carrier run. Source-carrier binding/gate scope awaits ROOT packet before final execution authorization.',
      'public_boundary':'Explicit own allowlist only: bounded outcomes/postguard booleans, exact target append and inline target payload, real safe OS receipt with original raw-stream hashes, scripts, original24 target PL. Full guards, full ledgers, index, Git inventories and raw API streams remain local-private-guards; no automatic directory packaging.',
      'no_repeat_build_source_or_reader':'No Lean/cache/kernel/browser/source search or new source audit is run here or by the driver. Actual build identity remains301728; future carrier is evidence identity only.',
      'prepared_scripts_sha256':draft['scripts'],'evidence_pins_verified_readonly_except_future_carrier':{k:v for k,v in pins.items() if k!='reader_carried'},'driver_not_executed':True,'normal_API_calls_by_preparation':0,'cell_writes_by_preparation':0})
    print(json.dumps({'status':'PREPARED_ONLY','PL':1,'V':0,'original24_preserved':True,'driver_sha256':file_sha(OWN/'verification_driver.py'),'common_sha256':file_sha(OWN/'verification_common.py'),'plan_sha256':file_sha(OWN/'preparation-plan-and-guard-contract.json'),'normal_API_calls':0,'cell_writes':0}))

if __name__=='__main__':
    os.umask(0o077)
    directory=PRIVATE/'preparation-process';assert not directory.exists();private_dir(directory);out=directory/'stdout.raw';err=directory/'stderr.raw';start=time.monotonic();started=dt.datetime.now(dt.timezone.utc).isoformat();code=0
    for fd,p in [(1,out),(2,err)]:
        f=p.open('xb',buffering=0);os.dup2(f.fileno(),fd);f.close()
    try:main()
    except BaseException:traceback.print_exc();code=1
    sys.stdout.flush();sys.stderr.flush()
    receipt={'schema':'r16-normal-V-preparation-readonly-actual-OS-receipt-v1','argv':[sys.executable,*sys.argv],'cwd':str(REPO),'started_utc':started,'ended_utc':dt.datetime.now(dt.timezone.utc).isoformat(),'elapsed_seconds':time.monotonic()-start,'actual_exit_code':code,'stdout_sha256':file_sha(out),'stderr_sha256':file_sha(err),'raw_streams_private':True,'script_sha256':file_sha(__file__),'no_driver_API_or_cell_action_executed':True}
    write(directory/'receipt.private.json',receipt);write(OWN/'preparation-OS-receipt.public.json',receipt);sys.exit(code)
