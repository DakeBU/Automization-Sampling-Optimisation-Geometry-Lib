from pathlib import Path
from html.parser import HTMLParser
import json,hashlib,subprocess,sys,re,datetime
R=Path.cwd();O=R/'.astis/semantic-neutral-20261111/rc_native_68bc';C='86c9bb627c61955f2a47f492c59a044230536739';assert (O/'native-freeze.json').exists();native=json.loads((O/'native-freeze.json').read_text());assert native['status']=='PASS_BOUNDED_NATIVE';sha=lambda b:hashlib.sha256(b).hexdigest()
def git(path):return subprocess.check_output(['git','show',C+':'+path],cwd=R)
slug='huanjian-gaussian-truncated-row-second-moment';lp='website/content/declaration_lessons/'+slug+'.json';pp='website/content/publications/'+slug+'.json';cp='research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-truncated-row-second-moment.json';ap='research-wiki/semantic-roundtrip/audits/'+slug+'.json';mp='research-wiki/paper-contributions/GaussianComplexity/truncated-row-second-moment-semantic-evidence/source-lean-map.draft.json'
inputs={p:git(p) for p in [lp,pp,cp,ap,mp]};assert sha(inputs[mp])=='66ef26d364f97d3865cd1dd3bddd09399af6cd1fda2ad0ae8da6d4a6a898783f';u=json.loads(inputs[lp])['units'][0];item=json.loads(inputs[pp])['items'][0];cell=json.loads(inputs[cp]);audit=json.loads(inputs[ap]);mapping=json.loads(inputs[mp]);(O/'inputs/source-lean-map.draft.exact.json').write_bytes(inputs[mp]);(O/'inputs/lesson.exact.json').write_bytes(inputs[lp]);(O/'inputs/publication.exact.json').write_bytes(inputs[pp])
# Preserve only minimal selected rendering metadata: no foreign decoder/source reports copied.
(O/'inputs/render-metadata.selected.json').write_text(json.dumps({'cell':{'cell_id':cell['cell_id'],'status':cell['status'],'shared_floor_audit':{'canonical_declaration':cell['shared_floor_audit']['canonical_declaration']}},'audit':{k:audit.get(k) for k in ['id','state','verdict','deltas','repairs']}},indent=2)+'\n')
sys.path[:0]=[str(R/'tools'),str(R/'website/scripts')]
import astis_site as base,inline_lean,declaration_lessons,publication_reader,astis_publication
# Exact production functions, with their normal input lookups bounded to exact-Git data.
base.ROOT=O/'native-src';declaration_lessons.ROOT=base.ROOT;base._ACTIVE_GIT=base.GitContext(C,'bounded-exact-candidate','','',False,False,set())
mods,decls=base.scan_project_sources();base._SOURCE_BY_NAME={d.full_name:d for d in decls};inline_lean.declarations.cache_clear()
data={'declarations':base._SOURCE_BY_NAME,'lessons':{u['declaration']:u},'cells':{cell['cell_id']:cell},'audits':{audit['id']:audit}};astis_publication.inputs=lambda:data
page=declaration_lessons.lesson_path(u['declaration']);p_page=publication_reader.source_proof_path(item);lesson_html=declaration_lessons.render_unit(u,page);pub_html=publication_reader.source_card(item,p_page);(O/'lesson.fragment.html').write_text(lesson_html);(O/'publication.fragment.html').write_text(pub_html)
renderer=[]
for mod in list(sys.modules.values()):
 f=getattr(mod,'__file__',None)
 if not f:continue
 path=Path(f)
 try:rel=path.relative_to(R).as_posix()
 except ValueError:continue
 if not (rel.startswith('tools/') or rel.startswith('website/scripts/')) or path.suffix!='.py':continue
 b=path.read_bytes();g=git(rel);assert b==g,rel;renderer.append({'path':rel,'sha256':sha(b)})
# A small DOM parser checks actual output structure and decoded code, without a browser.
class Node:
 def __init__(self,tag='',attrs=(),parent=None):self.tag=tag;self.attrs=dict(attrs);self.children=[];self.parent=parent
 def text(self):return ''.join(c.text() if isinstance(c,Node) else c for c in self.children)
 def all(self,pred):return [x for c in self.children if isinstance(c,Node) for x in ([c] if pred(c) else [])+c.all(pred)]
class DOM(HTMLParser):
 def __init__(self,s):super().__init__(convert_charrefs=True);self.root=Node();self.cur=self.root;self.feed(s)
 def handle_starttag(self,tag,attrs):
  n=Node(tag,attrs,self.cur);self.cur.children.append(n)
  if tag not in {'area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr'}:self.cur=n
 def handle_endtag(self,tag):
  n=self.cur
  while n.parent and n.tag!=tag:n=n.parent
  if n.parent:self.cur=n.parent
 def handle_data(self,s):self.cur.children.append(s)
def cls(n,k):return k in n.attrs.get('class','').split()
P='AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumTruncatedRowMoment.lean';T='Tests/GaussianComplexityFixedSpectrumTruncatedRowMoment.lean';ps=git(P).decode();ts=git(T).decode();bounds=[(34,92),(93,125),(127,145),(147,180)];step_records=[]
for j,s in enumerate(u['steps']):
 expected=''.join(ps.splitlines(keepends=True)[bounds[j][0]-1:bounds[j][1]]) if j<4 else ts
 assert s['lean']==expected,(j,'authored Lean differs from exact Git')
 step_records.append({'step':j+1,'path':P if j<4 else T,'LF_lines_1based':list(bounds[j]) if j<4 else [1,87],'sha256':sha(expected.encode()),'line_count':len(expected.splitlines())})
render_results=[]
for label,txt in [('lesson',lesson_html),('publication',pub_html)]:
 dom=DOM(txt).root;plain=dom.text();steps=dom.all(lambda n:cls(n,'proof-reader-step'));assert len(steps)==5
 for j,n in enumerate(steps):
  assert n.tag=='details' and 'open' not in n.attrs
  inner=[c for c in n.all(lambda x:x.tag=='details') if c.all(lambda x:x.tag=='summary') and c.all(lambda x:x.tag=='summary')[0].text()=='Corresponding Lean step'];assert len(inner)==1
  fold=inner[0];assert 'open' not in fold.attrs;codes=fold.all(lambda x:x.tag=='code');assert len(codes)==1 and codes[0].text()==u['steps'][j]['lean']
  body=fold.parent;elements=[c for c in body.children if isinstance(c,Node)];at=elements.index(fold);assert at>=2 and elements[at-1].tag=='div' and cls(elements[at-1],'proof-reader-equation') and elements[at-2].tag=='p';assert u['steps'][j]['formula'] in elements[at-1].text();assert u['steps'][j]['text'] in elements[at-2].text()
 assert u['statement'] in plain
 for a in u['assumptions']:assert a in plain
 for f in item['formulae']:assert f['tex'] in plain
 cites=dom.all(lambda n:n.tag=='a' and n.text()=='Complete private matrix-mean proof');assert len(cites)==1 and cites[0].attrs['href'].endswith('data/lesson-sources/'+T+'.html#L19');assert ts.splitlines()[18]=='private theorem actual_truncated_matrix_summand_mean'
 # Full literal public signature and complete proof are also initially closed.
 panels=dom.all(lambda n:cls(n,'inline-lean'));assert len(panels)==2 and all('open' not in n.attrs for n in panels)
 statement=next(n for n in panels if cls(n,'inline-lean-statement'));actual=statement.all(lambda n:n.tag=='code')[-1].text();decl=base._SOURCE_BY_NAME[u['declaration']];sig,_=inline_lean.split_statement(inline_lean.display_source(decl.source_text));assert actual==sig
 render_results.append({'fragment':label,'statement_and_all_conditions_present':True,'both_formulae_present':True,'five_adjacent_closed_exact_Lean_folds':True,'public_statement_and_full_proof_closed':True,'private_citation_line':19,'sha256':sha(txt.encode())})
# Validate source and Lean locators as half-open spans against actual pinned original bytes.
raw=(R/'.astis/huanjian-resume-20261103/2610.20492v1.html').read_bytes();assert sha(raw)==mapping['source_sha256'];source=raw.decode();assert '\r' not in source
class Spans(HTMLParser):
 def __init__(self,s):super().__init__(convert_charrefs=False);self.s=s;self.lines=[0]+[m.end() for m in re.finditer('\n',s)];self.stack=[];self.ids={};self.feed(s)
 def pos(self):l,c=self.getpos();return self.lines[l-1]+c
 def handle_starttag(self,tag,attrs):
  attrs=dict(attrs);p=self.pos();sid=attrs.get('id');self.stack.append((tag,p,sid))
  if tag in {'area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr'}:self.stack.pop()
 def handle_endtag(self,tag):
  for i in range(len(self.stack)-1,-1,-1):
   if self.stack[i][0]==tag:
    stack=self.stack[i:];self.stack=self.stack[:i];end=self.s.index('>',self.pos())+1
    for t,start,sid in stack:
     if sid:self.ids[sid]=(start,end)
    return
sp=Spans(source);source_checks=[];lean_checks=[]
def check_span(b,cs,ce,bs,be,lo,hi,digest,col=None):
 text=b.decode();chunk=b[bs:be];assert text[cs:ce].encode()==chunk;assert len(text[:cs].encode())==bs and len(text[:ce].encode())==be;assert sha(chunk)==digest
 actual_lo=text.count('\n',0,cs)+1;actual_hi=text.count('\n',0,ce)+1-(1 if ce>cs and text[ce-1]=='\n' else 0);assert (actual_lo,actual_hi)==(lo,hi),(actual_lo,actual_hi,lo,hi)
 if col is not None:assert cs-(text.rfind('\n',0,cs)+1)==col
for idx,m in enumerate(mapping['mappings']):
 for a in m['source']:
  check_span(raw,a['char_start'],a['char_end'],a['raw_utf8_start'],a['raw_utf8_end'],a['lf_line_start'],a['lf_line_end'],a['span_sha256'],a['lf_column0_start']);assert sp.ids[a['source_id']]==(a['char_start'],a['char_end']),a['source_id'];source_checks.append({'mapping':idx,'source_id':a['source_id'],'status':'exact bytes/chars/LF/column/id-element span match'})
 for a in m['lean']:
  b=git(a['path']);assert sha(b)==a['file_sha256'];check_span(b,*a['decoded_char_span'],*a['raw_UTF8_byte_span'],*a['LF_lines_1based'],a['span_sha256']);lean_checks.append({'mapping':idx,'path':a['path'],'lines':a['LF_lines_1based'],'status':'exact Git file and bytes/chars/LF span match'})
background=[]
for a in mapping['proof_background']:
 for key in ['source','consumer']:
  s=a[key];b=(R/s['path']).read_bytes() if s['path'].startswith('.lake/') else git(s['path']);assert sha(b)==s['file_sha256'];check_span(b,*s['decoded_char_span'],*s['raw_UTF8_byte_span'],*s['LF_lines_1based'],s['span_sha256']);background.append({'role':key,'path':s['path'],'lines':s['LF_lines_1based'],'status':'exact pinned file and bytes/chars/LF span match'})
assert mapping['actual_ASTIS_proof_parents']=={k:v for k,v in native['actual_first_authored_parents'].items() if v}
# Also independently check the canonical seal's eight pinned source anchors.
seal=json.loads((O/'inputs/statement-seal-v2.exact.json').read_text());seal_checks=[]
for a in seal['source']['anchors']:
 check_span(raw,*a['char_span'],*a['UTF8_byte_span'],*a['LF_lines_1based'],a['span_sha256']);assert sp.ids[a['source_id']]==tuple(a['char_span']);seal_checks.append(a['source_id'])
report={'schema_version':1,'reviewer':'/root/radial_cov_native_68bc','candidate':C,'frozen_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PASS_BOUNDED_STATIC_STRUCTURE_ONLY','native_freeze_sha256':sha((O/'native-freeze.json').read_bytes()),'renderer_scope':'Actual production declaration_lessons.render_unit and publication_reader.source_card, unmodified function bodies. Normal lookups bounded to exact-Git lesson/publication/cell/audit and exact three-module source tree. Local-preview link context; no full site shell, browser, deployment or global status validation.','renderer_inputs':[{'path':p,'sha256':sha(b),'worktree_equal':(R/p).read_bytes()==b} for p,b in inputs.items()],'production_python_modules':sorted(renderer,key=lambda x:x['path']),'paths':{'lesson':page,'publication':p_page},'rendered_fragments':render_results,'exact_steps':step_records,'source_lean_map':{'sha256':sha(inputs[mp]),'source_checks':source_checks,'lean_checks':lean_checks,'proof_background_checks':background,'actual_parents_match_native':True},'seal_source_anchors_exact':seal_checks,'source_statement_assessment':'The bounded authored statement and conditions show d,q natural, standing 2q+1<d including q=0, r=q+1, canonical N(0,I_r), squared norm, exact cutoff, closed retained ball, original unnormalized Gaussian expectation, dimension denominator, explicit Euclidean operator norm, and the literal midpoint feature index adapter. Both retained-moment and single-row Kronecker-mean formulas are present. This is a bounded content/locator finding, not independent source-equivalence admission.','HOLD':['Real desktop rendering and full-page formula/layout legibility','Real mobile rendering and responsive behavior','Full-site generation, navigation and shared reader hierarchy','Indexes and graph contribution/source-vs-Lean semantics in integrated site','Actual copy/download controls and exact downloadable modules','Public source links, deployment and public integration','Whole-goal, full-paper and purification acceptance'],'browser_run':False,'global_integration':False,'V_transition':False,'foreign_raw_snapshots_archived':False}
(O/'static-freeze.json').write_text(json.dumps(report,indent=2)+'\n');(O/'static-freeze.sha256').write_text(sha((O/'static-freeze.json').read_bytes())+'  static-freeze.json\n');print((O/'static-freeze.sha256').read_text());print(json.dumps({'source_records':len(source_checks),'unique_source_ids':len({x['source_id'] for x in source_checks}),'lean_records':len(lean_checks),'background_records':len(background),'seal_anchors':len(seal_checks),'renderer_modules':len(renderer),'steps':step_records},indent=2))
