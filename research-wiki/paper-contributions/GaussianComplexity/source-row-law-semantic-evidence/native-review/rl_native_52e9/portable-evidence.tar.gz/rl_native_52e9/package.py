"""Freeze original bounded acceptance report and portable lossless streams."""
import datetime,json,pathlib,tarfile
from run import ROOT,sha
for ext in ['md','json']:
    dest=ROOT/('report.original.'+ext);assert not dest.exists();dest.write_bytes((ROOT/('report.'+ext)).read_bytes())
exclude={'portable-evidence.tar.gz','portable-manifest.json','evidence-seal.json'}
files=[];omitted=[]
for p in sorted(ROOT.rglob('*')):
    if not p.is_file():continue
    rel=p.relative_to(ROOT)
    if p.name in exclude or '__pycache__' in rel.parts:continue
    if rel.parts[0]=='native-olean' or p.name.startswith('native-all-bodies'):
        b=p.read_bytes();omitted.append({'path':str(rel),'bytes':len(b),'sha256':sha(b),'reason':'large local full native dump or reproducible compiled olean; source/scripts/hash retained'})
        continue
    # Packaging completion receipts are outside their own archive by design;
    # no acceptance-command receipt or original acceptance stream is excluded.
    if p.name.startswith(('package-driver.','package-check.')):continue
    b=p.read_bytes();files.append({'path':str(rel),'bytes':len(b),'sha256':sha(b)})
manifest={'checked_commit':'d0654e9bbed44ab852fc44598560799949d8bd12','root_name':ROOT.name,'files':files,'included_bytes':sum(x['bytes'] for x in files),'omitted_local_regenerable':omitted,'manifest_self_hash':'recorded externally in evidence-seal.json','acceptance_receipts_included':True,'packaging_completion_receipts':'external to own archive to avoid circularity'}
mp=ROOT/'portable-manifest.json';mp.write_text(json.dumps(manifest,indent=2)+'\n')
arc=ROOT/'portable-evidence.tar.gz'
with tarfile.open(arc,'w:gz') as tar:
    for x in files:tar.add(ROOT/x['path'],arcname=ROOT.name+'/'+x['path'],recursive=False)
    tar.add(mp,arcname=ROOT.name+'/'+mp.name,recursive=False)
with tarfile.open(arc,'r:gz') as tar:
    for x in files:
        b=tar.extractfile(ROOT.name+'/'+x['path']).read();assert len(b)==x['bytes'] and sha(b)==x['sha256']
    assert tar.extractfile(ROOT.name+'/'+mp.name).read()==mp.read_bytes()
seal={'checked_commit':manifest['checked_commit'],'archive':{'path':arc.name,'bytes':arc.stat().st_size,'sha256':sha(arc.read_bytes())},'manifest':{'path':mp.name,'sha256':sha(mp.read_bytes())},'original_report':{ext:{'path':'report.original.'+ext,'sha256':sha((ROOT/('report.original.'+ext)).read_bytes())} for ext in ['md','json']},'included_file_count':len(files)+1,'all_archive_entry_hashes_reread_and_verified':True,'no_shared_mutations_or_permission_grant':True}
(ROOT/'evidence-seal.json').write_text(json.dumps(seal,indent=2)+'\n')
assert arc.stat().st_size<5_000_000
print(json.dumps(seal,indent=2))
