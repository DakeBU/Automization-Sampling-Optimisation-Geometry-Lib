"""Prepare future browser checker by exact substitutions; AST-parse only, never run it."""
from pathlib import Path
import ast,datetime,gzip,hashlib,json
R=Path('/Users/zhouhuanjian/ASTIS-GC')
S=R/'.astis/huanjian-gc-fixed-spectrum-normalizer-integration-20261108/independent-reader'
O=R/'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-normalizer-integration-20261108/independent-reader/helper-preparation'
old=R/'.astis/huanjian-gc-fixed-spectrum-determinant-integration-20261108/check_final_reader.py'
out=S/'check_final_reader.py'
sha=lambda b:hashlib.sha256(b).hexdigest()
assert not out.exists() and not O.exists() and sha(old.read_bytes())=='d191bcb9ea513e71e0c2357315dee1821fdcccdab6dc6a2f473d5289589f0766'
s=old.read_text()
def replace(a,b):
 global s
 assert s.count(a)==1,(a[:120],s.count(a));s=s.replace(a,b,1)
s=s.replace('FixedSpectrumDeterminant','FixedSpectrumNormalizer').replace('actual_precision_det','actual_normalizing_integral').replace('fixed-spectrum-determinant','fixed-spectrum-normalizer')
replace('real Chrome determinant reader checks','real Chrome normalizer reader checks')
replace('from playwright.sync_api import sync_playwright', '''sys.dont_write_bytecode = True
from normalizer_acceptance_common import parse_args, load_authorization, authorized_context
authorization_args = parse_args(__doc__)
authorization, authorization_ref = load_authorization(authorization_args)
authorization_readback = authorized_context(authorization)
from playwright.sync_api import sync_playwright''')
replace('ROOT = Path.cwd()',"ROOT = Path.cwd()\nassert ROOT == Path('/Users/zhouhuanjian/ASTIS-GC')")
replace("BINDING = 'c70bb9b23e335acf768bb889f8229fcdf2a7af160e10fa89779d00dcba58374b'\nCANONICAL_PARENT = 'AutoSamplingTheory.TechnicalLemmas.Measure.DisplacementJacobianEntropy.det_conjStarAlgAut_eq'\nADMISSIBILITY = PREFIX + 'FixedSpectrumAdmissibility.actual_precision_admissible'\nCONSUMER_ASTIS_PARENTS = [ADMISSIBILITY, NAME, CANONICAL_GAUSSIAN]", "BINDING = 'b2f41e36a9d705ff68da71f72f0ec14f1cd2ff105bcf0ae5000ef1406a5d1f41'\nADMISSIBILITY = PREFIX + 'FixedSpectrumAdmissibility.actual_precision_admissible'\nDETERMINANT = PREFIX + 'FixedSpectrumDeterminant.actual_precision_det'\nPRODUCER_ASTIS_PARENTS = [ADMISSIBILITY, DETERMINANT, CANONICAL_GAUSSIAN]\nCONSUMER_ASTIS_PARENTS = PRODUCER_ASTIS_PARENTS + [NAME]")
for a,b in {
 'adcf336b0774dbbd5f8976b25e50c8723d14a6dab2582faee6db4d365afac9dc':'2a61f494afc9b6496527094edccefa39be9cd71a72b599e5fcd2ca5bc26cf4cf',
 '2be2c84620313264b486e20ba84904403e2ee54706bcfa2b36f929d896d9e1ec':'71040132321ec908370494d289571e7366b87658de6dd531829162dfc95c90d1',
 '4a3a9a3de61c2a4ffe4a8be518dcfb206273df337d7eedbd30c931c832131b95':'c38b809c1f71d652037443e4c47a1d448d15c3983a27aa1133d5aec4c85055f5',
 'b0ac72466ffe28e2b890400514b67236e02389e6a25e9f3d58e14f1cf5910ece':'68da4cb0de5380fea1796abfc6e193a35779009983dd3d9b10e03f1ca05bf0b0',
 "'AutoSamplingTheory/TechnicalLemmas/Measure/DisplacementJacobianEntropy.lean': 'a1bf2e9e21e00f1ad7dd01acadc47ea914c2a03b45c82db2aeb927336612fd85'":"'AutoSamplingTheory/TechnicalLemmas/Measure/GaussianPrecisionDensity.lean': '1a1b9a929076ab77bf0e0f207f0d3d4fa25ac30dd56b2275e1fc319970f0f5e5'",
}.items():replace(a,b)
replace("assert unit['astis_dependencies'] == [CANONICAL_PARENT] and len(unit['steps']) == 5 and unit['mathlib_dependencies']","assert unit['astis_dependencies'] == PRODUCER_ASTIS_PARENTS and len(unit['steps']) == 6 and unit['mathlib_dependencies']")
replace("assert capsule['actual_ASTIS_producer_parents'] == [CANONICAL_PARENT]","assert capsule['actual_ASTIS_producer_parents'] == PRODUCER_ASTIS_PARENTS")
replace("parent_id = 'decl:' + CANONICAL_PARENT\nparent_module_id = 'module:AutoSamplingTheory.TechnicalLemmas.Measure.DisplacementJacobianEntropy'","parent_ids = ['decl:' + x for x in PRODUCER_ASTIS_PARENTS]")
replace("assert sum(x['id'] == parent_id for x in graph['nodes']) == 1\nassert nodes[parent_id]['kind'] == 'declaration'\nassert sum(e['source'] == parent_module_id and e['target'] == parent_id and e['relation'] == 'declares' for e in graph['edges']) == 1\nparent_reference_edges = [e for e in graph['edges'] if e['source'] == parent_id and e['target'] == own_id]\nassert len(parent_reference_edges) == 1 and parent_reference_edges[0]['relation'] == 'source reference (scanner)'", "for parent, parent_id in zip(PRODUCER_ASTIS_PARENTS, parent_ids):\n    assert sum(x['id'] == parent_id for x in graph['nodes']) == 1 and nodes[parent_id]['kind'] == 'declaration'\n    parent_module = 'module:' + parent.rsplit('.', 1)[0]\n    assert sum(e['source'] == parent_module and e['target'] == parent_id and e['relation'] == 'declares' for e in graph['edges']) == 1\n    refs = [e for e in graph['edges'] if e['source'] == parent_id and e['target'] == own_id]\n    assert len(refs) == 1 and refs[0]['relation'] == 'source reference (scanner)'\nassert nodes[canonical_id]['status'] == 'compiled'\nassert 'compilation-only-index' in nodes[canonical_id]['summary'] and 'legacy-source-publication-audit-debt' in nodes[canonical_id]['summary']")
replace("OUT = ROOT / '.astis/huanjian-gc-fixed-spectrum-normalizer-integration-20261108/browser'", "OUT = ROOT / '.astis/huanjian-gc-fixed-spectrum-normalizer-integration-20261108/independent-reader/browser'")
replace("'pages': [], 'graphs': [], 'visible_source_index_clicks': [], 'errors': [], 'screenshots': [],", "'pages': [], 'graphs': [], 'GPD_debt_cards': [], 'visible_source_index_clicks': [], 'errors': [], 'screenshots': [],\n    'authorization': authorization_ref, 'authorization_readback': authorization_readback,")
s=s.replace("'producer_ASTIS_parents': [CANONICAL_PARENT]", "'producer_ASTIS_parents': PRODUCER_ASTIS_PARENTS")
replace("'canonical_Gaussian_dependency_role': 'Identical existing declaration reused with actual admissibility and new determinant in the same-A focused Test; GPD is not the determinant producer parent.'", "'canonical_Gaussian_dependency_role': 'Identical existing GPD is one of three actual producer parents and one of four private Test parents. Compilation-only inventory does not close historical source/publication audit debt.'")
replace("for phrase in ('either determinant sign', 'zero-based', 'no Haar-law', 'prefactor', 'quadratic exponent', 'odd dimensions', 'known-normalizer'):", "for phrase in ('either determinant sign', 'zero-based', 'unnormalized Euclidean Lebesgue', 'source-implicit', 'Only the normalizing scalar', 'odd dimensions'):")
replace('assert steps.count() == 5','assert steps.count() == 6')
replace('for i in range(5):','for i in range(6):')
replace("                if i == 1:\n                    assert CANONICAL_PARENT in nested.text_content()\n                if i == 4:\n                    for parent in ('FixedSpectrumNormalizer.actual_normalizing_integral', 'FixedSpectrumAdmissibility.actual_precision_admissible', 'GaussianPrecisionDensity.multivariateGaussian_eq_withDensity_of_posDef'):\n                        assert parent in nested.text_content()", "                # Exact authored correspondence is checked for every one of the six steps.\n                # Actual kernel parents remain separately pinned evidence.")
replace("            assert parent_list.count() == 1\n            assert parent_list.first.locator('code').text_content() == CANONICAL_PARENT\n            parent_source_href = parent_list.first.locator('a').get_attribute('href')\n            assert context.request.get(urljoin(page.url, parent_source_href)).status == 200", "            assert parent_list.count() == 3\n            for i, parent in enumerate(PRODUCER_ASTIS_PARENTS):\n                assert parent_list.nth(i).locator('code').text_content() == parent\n                parent_source_href = parent_list.nth(i).locator('a').get_attribute('href')\n                assert context.request.get(urljoin(page.url, parent_source_href)).status == 200")
replace("'five_formula_steps_opened': True", "'six_formula_steps_opened': True")
replace("'consumer_canonical_Gaussian_is_separate': True", "'consumer_uses_same_GPD': True")
replace("'full unweighted Gaussian integral/known-normalizer proposition'", "'actual unweighted Euclidean Gaussian normalizing integral'")
replace("            parent_neighbor = page.locator(f'[data-graph-detail] button[data-jump=\"{parent_id}\"]')\n            assert parent_neighbor.count() == 1\n            parent_neighbor.click()\n            page.wait_for_selector(f'.ulg-node.selected[data-id=\"{parent_id}\"]')\n            assert page.locator('[data-graph-detail]').get_attribute('data-kind') == 'declaration'\n            page.locator('[data-graph-canvas]').scroll_into_view_if_needed()\n            no_page_overflow(page)\n            screenshot(page, f'canonical-DJE-{width}-graph-native-parent-click')\n            focused_entry(page, own_id, NAME)", "            for i, parent_id in enumerate(parent_ids, 1):\n                focused_entry(page, own_id, NAME)\n                parent_neighbor = page.locator(f'[data-graph-detail] button[data-jump=\"{parent_id}\"]')\n                assert parent_neighbor.count() == 1\n                parent_neighbor.click()\n                page.wait_for_selector(f'.ulg-node.selected[data-id=\"{parent_id}\"]')\n                assert page.locator('[data-graph-detail]').get_attribute('data-kind') == 'declaration'\n                page.locator('[data-graph-canvas]').scroll_into_view_if_needed()\n                no_page_overflow(page)\n                screenshot(page, f'canonical-parent{i}-{width}-graph-native-parent-click')\n            focused_entry(page, own_id, NAME)")
replace("            screenshot(page, f'canonical-Gaussian-{width}-graph-focused')", """            screenshot(page, f'canonical-Gaussian-{width}-graph-focused')
            debt_link = page.locator('[data-graph-detail] .ulg-links a').filter(has_text='Open reader / evidence card')
            assert debt_link.count() == 1
            debt_card_href = debt_link.get_attribute('href')
            assert context.request.get(urljoin(page.url, debt_card_href)).status == 200
            debt_link.click()
            page.wait_for_load_state('domcontentloaded')
            debt_text = page.locator('body').text_content()
            for phrase in ('Compilation-only admission of the existing canonical density', 'historical source/publication audit debt', 'proved_locally without independent verification', 'no old sourceV or completed audit is claimed', 'legacy-source-publication-audit-debt'):
                assert phrase in debt_text, phrase
            assert 'Compiled' in debt_text and 'gaussian-precision-density-existing-canonical' in debt_text
            no_page_overflow(page)
            warning = page.locator('h2').filter(has_text='Proof architecture')
            warning.scroll_into_view_if_needed()
            screenshot(page, f'canonical-GPD-{width}-debt-card')
            report['GPD_debt_cards'].append({'width': width, 'canonical_declaration': CANONICAL_GAUSSIAN, 'route': debt_card_href, 'native_graph_card_click': True, 'actual_visible_warning_checked': True, 'old_sourceV_or_publication_credit': False})""")
replace("'native_canonical_DJE_parent_click': True", "'native_three_canonical_parent_clicks': True")
replace("'semantic_boundary': 'DJE is the ONE separately kernel-confirmed canonical producer parent. Its graph source-name edge remains dashed, not formal kernel proof evidence. Actual GaussianPrecisionDensity and admissibility reuse belongs to the three-parent private Test consumer. Structural imports/declares are not theorem implication; no duplicate determinant, density or conceptual transport is created.'", "'semantic_boundary': 'Exactly three separately kernel-confirmed canonical producer parents and four private Test parents. Displayed references are dashed incomplete source-name scans. GPD compilation inventory retains historical source/publication debt, visibly exposed through its own-site card. No duplicate density, new old-parent sourceV or conceptual transport is created.'")
replace("'no_new_determinant_candidate_or_formal_transport'", "'no_new_normalizer_candidate_or_formal_transport'")
assert 'CANONICAL_PARENT' not in s and 'canonical-DJE' not in s
ast.parse(s,filename=str(out));out.write_text(s);raw=out.read_bytes()
O.mkdir(parents=True,exist_ok=False);data=gzip.compress(raw,mtime=0);(O/'check_final_reader.py.raw.gz').write_bytes(data);assert gzip.decompress(data)==raw
manifest={'reviewer':'/root/norm_integration_reader','phase':'Preparation only; AST parse, no import/build/site/Chrome execution','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'script':str(out.relative_to(R)),'script_sha256':sha(raw),'base_script':str(old.relative_to(R)),'base_script_sha256':sha(old.read_bytes()),'script_archive_sha256':sha(data),'execution_status':'NOT_RUN','authorization_guard':'Requires root-bound postcore read-only context with independent accepted sourceV lineage, sole normal STAB and exact six applied payloads before any browser launch.','expected_original_images':46,'scope':['1440/390 short conclusion,folded assumptions,sixformula steps and adjacent exact Lean,provenance with three actual parents','Same-A four-parent private consumer; only scalar orientation independence and source-implicit integral convention','Actual source-index click; own-site complete module/download equal immutable local Git; GitHub syntax claim only on executed branch','Native three canonical graph-parent clicks and module click; same GPD canonical node and native own-site compilation/debt-card link','Both conceptual models and old GPD frontier/publication bytes exact; source scanners remain dashed incomplete references'],'actual_image_review':'No images from this script exist; all46future originals require fresh independent viewing.'}
(O/'browser-preparation-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'script_sha256':sha(raw),'manifest_sha256':sha((O/'browser-preparation-manifest.json').read_bytes()),'expected_images':46,'state':'PREPARED_AST_PARSED_NOT_RUN'},indent=2))
