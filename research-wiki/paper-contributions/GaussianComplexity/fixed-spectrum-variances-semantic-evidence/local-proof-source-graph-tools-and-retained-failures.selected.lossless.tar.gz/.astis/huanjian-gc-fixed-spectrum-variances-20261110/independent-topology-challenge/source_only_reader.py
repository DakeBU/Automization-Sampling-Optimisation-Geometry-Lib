"""Pinned-HTML locator only: no candidate, implementation, API or extractor input."""
from pathlib import Path
from html.parser import HTMLParser
import hashlib
import html
import sys

SOURCE = Path('/Users/zhouhuanjian/ASTIS-GC/.astis/huanjian-resume-20261103/2610.20492v1.html')
RAW = SOURCE.read_bytes()
assert len(RAW) == 951991
assert hashlib.sha256(RAW).hexdigest() == '6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
TEXT = RAW.decode('utf-8')
LINES = [0] + [i + 1 for i, c in enumerate(TEXT) if c == '\n']
VOID = {'area', 'base', 'br', 'col', 'embed', 'hr', 'img', 'input', 'link', 'meta', 'param', 'source', 'track', 'wbr'}


class Node:
    def __init__(self, tag, attrs, parent=None, start=0):
        self.tag, self.attrs, self.parent = tag, dict(attrs), parent
        self.start, self.end, self.children = start, None, []


class Reader(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=False)
        self.root = Node('root', [])
        self.stack, self.ids = [self.root], {}

    def source_offset(self):
        line, column = self.getpos()
        return LINES[line - 1] + column

    def handle_starttag(self, tag, attrs):
        node = Node(tag, attrs, self.stack[-1], self.source_offset())
        self.stack[-1].children.append(node)
        if node.attrs.get('id'):
            self.ids[node.attrs['id']] = node
        if tag in VOID:
            node.end = self.source_offset() + len(self.get_starttag_text())
        else:
            self.stack.append(node)

    def handle_endtag(self, tag):
        for i in range(len(self.stack) - 1, 0, -1):
            if self.stack[i].tag == tag:
                self.stack[i].end = TEXT.index('>', self.source_offset()) + 1
                self.stack = self.stack[:i]
                return

    def handle_startendtag(self, tag, attrs):
        self.handle_starttag(tag, attrs)
        if tag not in VOID:
            self.stack[-1].end = self.source_offset() + len(self.get_starttag_text())
            self.stack.pop()

    def handle_data(self, data):
        self.stack[-1].children.append(data)

    def handle_entityref(self, name):
        self.handle_data(html.unescape('&' + name + ';'))

    def handle_charref(self, name):
        self.handle_data(html.unescape('&#' + name + ';'))


READER = Reader()
READER.feed(TEXT)


def normalized(node):
    if isinstance(node, str):
        return node
    if node.tag == 'math':
        return '$' + node.attrs.get('alttext', '') + '$'
    if node.tag in {'script', 'style'}:
        return ''
    suffix = '\n' if node.tag in {'section', 'div', 'p', 'tr', 'li', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6'} else ' ' if node.tag in {'td', 'th'} else ''
    return ''.join(normalized(c) for c in node.children) + suffix


def walk(node):
    if not isinstance(node, Node):
        return
    yield node
    for child in node.children:
        yield from walk(child)


def record(node):
    assert node.end is not None
    b = TEXT[node.start:node.end].encode('utf-8')
    start = len(TEXT[:node.start].encode('utf-8'))
    return {'anchor': node.attrs.get('id'), 'tag': node.tag,
            'byte_start_inclusive': start, 'byte_end_exclusive': start + len(b),
            'raw_bytes': len(b), 'raw_sha256': hashlib.sha256(b).hexdigest(),
            'line_start': TEXT.count('\n', 0, node.start) + 1,
            'line_end': TEXT.count('\n', 0, node.end) + 1}


if __name__ == '__main__':
    for key in sys.argv[1:]:
        print('\nANCHOR', key)
        print(normalized(READER.ids[key]))
