from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,collections,sys
p=Path(__file__).parent;target=p/(sys.argv[1] if len(sys.argv)>1 else 'own-original-leaf-manifest.latest.json');sha=lambda b:hashlib.sha256(b).hexdigest();leaves=[];private_omitted_count=0
if target.exists():raise RuntimeError('Preserve old manifests; choose a fresh output name')
for f in sorted(p.rglob('*')):
 if not f.is_file() or f==target:continue
 rel=str(f.relative_to(p))
 if rel.startswith('normal-discovery-validation/local-private-guards/'):
  private_omitted_count+=1
  continue
 data=f.read_bytes();phase=rel.split('/')[0] if '/' in rel else 'cross-phase';category='own-authored-original';default=True;reason='Own authored review/run/log/script/freeze evidence.'
 if '__pycache__/' in rel or f.suffix=='.pyc':category='excluded-cache';default=False;reason='Derived interpreter cache; not custody evidence.'
 elif phase=='phase1' and ('/inputs/' in rel or f.name.startswith('tropp-page-') or f.name=='tropp_full_extracted.txt' or f.name.endswith('_extracted.txt') or f.name.endswith('_math.json') or f.name=='C2_raw_regions.json'):
  category='reference-only-source-or-process-input';default=False;reason='Whole raw PDF/HTML, source layout/extraction or process-instruction snapshot; reference by path/hash, do not bulk-package.'
 elif '/inputs/' in rel:
  if f.name in ['radius-citation-repair.proposal.v1.json','empty-astis-field-repair.proposal.v1.json','preproof-mathematical-fields-only.json','conceptual-mirror-proposal.authored-v1.json','conceptual-mirror-and-process-audit.authored-v1.json'] or f.name.startswith(('P.reviewer-packet.','T.reviewer-packet.','source-lean-correspondence.authored-')):
   category='exact-reviewed-input-original';default=True;reason='Exact current/obsolete packet, independent citation proposal, or bounded source-map input required for run custody.'
  elif 'anonymous_decoder_originals/' in rel:category='selective-decoder-custody-copy';default=False;reason='Decoder originals already have separate canonical custody; optional duplicate listed leaf-by-leaf.'
  elif f.suffix=='.lean' or 'declaration_lessons__' in f.name or 'publications__' in f.name or 'publication-context.' in f.name or 'lesson.authored-' in f.name:
   category='selective-mathematical-or-prose-input';default=True;reason='Exact P/T/necessary parent or authored prose/context input used by independent whole-module/source review.'
  elif 'manifest.json' in f.name or f.suffix=='.py' or f.name.endswith('.exact.diff'):
   category='selective-preview-mechanism-input';default=True;reason='Bounded preview manifest/renderer/overlay source directly inspected; no acceptance inherited.'
  else:category='reference-only-generated-preview-duplicate';default=False;reason='Generated bounded fixture already hash-bound by retained manifest; optional selective copy, not all-inputs bulk custody.'
 leaves.append({'path':rel,'phase':phase,'bytes':len(data),'sha256':sha(data),'custody_class':category,'include_by_default':default,'reason':reason})
obj={'schema':'own-original-leaf-custody-manifest-v1','created_at_utc':datetime.now(timezone.utc).isoformat(),'reviewer':'/root/laplace_fresh_source_8d2a','root':str(p.resolve()),'scope':'All own-directory file leaves existing now, except this self-referential manifest. Selective custody is per leaf; never copy the entire inputs directory by default.','source_and_instruction_policy':'Whole raw PDF/HTML/full layouts and process/cache instruction snapshots are reference-only. No private workspace guard, full external-state map, ATLAS or external cache directory is included or newly copied.','failure_receipt_limit':'Failure receipts are explicitly transcriptions from actual tool errors; no pre-correction script artifact is invented.','local_only_excluded_subtrees':['normal-discovery-validation/local-private-guards/**'],'local_private_guard_leaf_count_omitted':private_omitted_count,'counts':dict(collections.Counter(x['custody_class'] for x in leaves)),'default_selected_count':sum(x['include_by_default'] for x in leaves),'leaves':leaves}
target.write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n');print(json.dumps({'path':str(target),'sha256':sha(target.read_bytes()),'leaves':len(leaves),'default_selected':obj['default_selected_count']},indent=2))
