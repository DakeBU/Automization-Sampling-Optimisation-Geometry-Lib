from pathlib import Path
import json,hashlib,gzip,re,tarfile,sys
sys.dont_write_bytecode=True
sys.path.insert(0,'tools')
import astis_advance as adv
import astis_publication as pub
W=Path('.astis/huanjian-gc-fixed-spectrum-signal-strength-20261110')
E=Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-signal-strength-semantic-evidence')
C=Path('research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-signal-strength.json')
L=Path('runs/substantive_advances.jsonl')
ADV='ASTIS-SA-20261110-GaussianComplexityFixedSpectrumSignalStrength'
OWNER='huanjian_gc_20261110_fixed_spectrum_signal_strength'
sha=lambda b:hashlib.sha256(b).hexdigest()
dump=lambda x:(json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode()
def ref(p):
    p=Path(p);return {'path':str(p),'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size}
def put(p,b):
    assert not p.exists(),p
    p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
s=json.loads((W/'statement-seal-v1.json').read_bytes())
r=json.loads((E/'publication-draft-record.json').read_bytes())
b=json.loads((W/'intake-baseline-after-prior-packet-carry.json').read_bytes())
prod=Path(s['producer']['planned_file']);test=Path(s['actual_private_consumer']['planned_file']);name=s['producer']['name']
assert sha(prod.read_bytes())==r['producer_raw_sha256'] and sha(test.read_bytes())==r['Test_raw_sha256']
for p in [prod,test]:assert not re.search(r'\b(sorry|admit|axiom)\b|Prop\s*:=\s*True|:=\s*trivial\b',p.read_text())
inventory=json.loads((E/'actual-kernel-owned-inventory.json').read_bytes())
assert len(inventory['handwritten'])==4 and len(inventory['reachable_generated_proof_auxiliaries'])==2
assert len(inventory['unreachable_compiler_generated_simp_declarations'])==7
assert all(inventory['root_reachability'][n]=='true' for n in inventory['handwritten']+inventory['reachable_generated_proof_auxiliaries'])
checks=[]
for key in ['20261110T020923563896Z-signal-strength-native-production-actual-norm-and-bias-product','20261110T021312034630Z-signal-strength-native-complete-actual-Gaussian-probability-consumer','20261110T021436245999Z-signal-strength-kernel-exact-sealed-types-all-owned-canonical-parents']:
    p=Path('.astis/huanjian-resume-20261103')/(key+'.receipt.json');d=json.loads(p.read_bytes())
    assert d['exit_code']==0 and sha(Path(d['log']).read_bytes())==d['log_sha256']
    checks.append({'receipt':ref(p),'raw_log_sha256':d['log_sha256'],'scope':'Actual producer/Test/native kernel on HEADbeae working source bytes; not fresh immutable-candidate/sourceV/global/browser acceptance.'})
pub.check_advance([name],reviewed=False)
mirror={'status':'none-found','discovery_ids':[],'reason':'New source numerical signal composition materially reuses canonical Gaussian/mode-gap results and the SAME Mathlib Chebyshev declaration. No new cross-domain hypothesis/key-estimate/conclusion/failure/source transport is established. Existing conceptual mirrors and foreign queues gain no formal implication/status credit.'}
put(E/'postproof-conceptual-mirror-audit.json',dump(mirror))
failures={'mathematical_refutation':False,'sealed_interface_or_definition_change':False,'preproof_history':'Root pre/postseal informal planning retained. Original graph H1/H2 and raw0043 refinement held, repaired append-only in v2 and independently reviewed before prospective process admission. No pristine history or human waiver.','actual_Lean_attempts':'ScalarV1 overran a closed field_simp goal and lacked explicit rational/division normalization; ScalarV2 passed. ConsumerV1 redundant dsimp made no progress; ConsumerV2 passed; final Test removes only an unnecessary sequence-focus warning and native builds. Exact sealed types kernel-applied.','metadata_attempts':'AuthorV1 compared a stripped seal tail to an unstripped native signature tail, failed before output; V2 normalizes both trailing tails without source/type changes. CorrespondenceV1 retained a correct kernel inventory but stopped on a missing bundled target/oracle definition classification; V2 retains inventory byte-exact and explicitly maps target-law-only meaning and canonical generic bias. Unfrozen count-wording correction changes only prose; all92rows retained.','route_guard':'No fourth identical unchanged route attempt; no failed theorem or source premise alteration inferred.','retained_records':['publication-author-v1-failure.json','correspondence-package-v1-failure.json']}
put(E/'retained-failures-and-route-diagnosis.json',dump(failures))
digestion={'existing_substrate':r['actual_public_ASTIS_producer_parents']+r['actual_public_ASTIS_private_consumer_parents'],'bookkeeping':['Actual finite-tail correction to M','Guarded source condition-number power comparison','Exact query-cap exponential-to-power bias and product normalization','One uniform finite cutoff and genuine actual-law Chebyshev application'],'new_reusable':['Selected public actual source signal-strength prerequisite; no new shared technical library leaf is claimed.'],'new_topology':'Actual canonical mean/bias plus uniform mode/gap compose into the source M beta squared lower, then a private same-law zero-event probability. No mechanism-only relation is promoted to Lean implication.','purification':{'status':'pending','all_handwritten_reachable':True,'generated_proof_reachable':True,'compiler_generated_unreachable_simp':7,'no_duplicate_public_gaussian_nodes':True,'wrapper_only':False,'reader_default':'Concise norm/signal formula; full parameters, six formula/proof steps and exact Lean folded.','Exposition_Seal':'pending'}}
put(E/'proof-digestion-and-purification-boundary.json',dump(digestion))
allow={'producer-signature.txt','consumer-signature.txt','statement-seal-v1.json','strict-preproof-seal-projection-v1.json','StatementFormation.lean.gz','statement-formation-probe.raw.lean.txt','root-preproof-admission-grant.json','preseal-exposure-disclosure.json','postseal-informal-planning-exposure.json','ProducerBodyV1.lean.txt','ConsumerBodyV1.lean.txt','publication-author-v1-failure.json','correspondence-package-v1-failure.json'}
payload=[p for p in sorted(W.iterdir()) if p.is_file() and (p.name in allow or p.suffix in ['.lean','.py'])]
assert all(not re.search(rb'wxid_[a-z0-9]{8,}|/Library/Containers/com\.tencent',p.read_bytes()) for p in payload)
archive=E/'local-mathematical-attempts-tools-and-failures.selected.lossless.tar.gz'
assert not archive.exists()
with tarfile.open(archive,'w:gz') as t:
    for p in payload:t.add(p,arcname=p.name,recursive=False)
with tarfile.open(archive,'r:gz') as t:
    for p in payload:assert t.extractfile(p.name).read()==p.read_bytes()
put(E/'local-proof-archive-manifest.json',dump({'archive':ref(archive),'files':[ref(p) for p in payload],'scope':'Exact selected own statement/proof attempts/tools/failures only; full source/topology/process review bundles are separately preserved. Private foreign baselines and private draft payload excluded.'}))
actual=[]
for p in sorted(Path('.astis/huanjian-resume-20261103').glob('20261110T*-signal-strength-*.receipt.json')):
    d=json.loads(p.read_bytes());log=Path(d['log']);raw=log.read_bytes()
    assert sha(raw)==d['log_sha256'] and len(raw)<10_000_000
    assert not re.search(rb'wxid_[a-z0-9]{8,}|/Library/Containers/com\.tencent',p.read_bytes()+raw)
    q=E/'actual-local-checks'/p.name;put(q,p.read_bytes());z=E/'actual-local-checks'/(log.name+'.gz');put(z,gzip.compress(raw,mtime=0))
    actual.append({'receipt':ref(q),'log':ref(z),'exit_code':d['exit_code'],'proof_credit':any(c['receipt']['sha256']==sha(p.read_bytes()) for c in checks)})
put(E/'actual-local-checks-manifest.json',dump({'checks':actual,'scope':'Actual completed own local attempts including failed implementation/metadata checks. Formation/baseline/intake/metadata/static do not acquire native mathematical proof credit. Current package receipt is produced only after this archive and remains separate.'}))
for p,h in b['all_frontier_hashes'].items():assert sha(Path(p).read_bytes())==h,p
for p,h in b['protected_shared_hashes'].items():assert sha(Path(p).read_bytes())==h,p
baseline=json.loads((W/'preproof-baseline.json').read_bytes())
put(E/'compact-pinned-environment-and-preservation.json',dump({'seal_environment':{k:baseline[k] for k in ['observed_utc','working_HEAD','Lean_actual','binary','manifest','packages']},'intake_baseline_sha256':sha((W/'intake-baseline-after-prior-packet-carry.json').read_bytes()),'intake_HEAD':b['HEAD'],'foreign_frontiers':len(b['all_frontier_hashes']),'foreign_raw_states_public':False,'protected_shared_hashes':b['protected_shared_hashes']}))
before=L.read_bytes();states=adv._replay_advances([json.loads(x) for x in before.splitlines()])
assert states[ADV]['state']=='EXPLORING' and states[ADV]['owner_id']==OWNER
assert {k:v for k,v in states.items() if k!=ADV}==b['all_SAU_states']
cellraw=C.read_bytes();cell=json.loads(cellraw)
boundary='Exact unchanged source regime with one threshold before all kappa/q, literal actual inverse-precision Gaussian, positive actual M/beta and exact M lower/signal inequalities, plus genuine private actual-law zero-event probability<=1/10 compile locally. Both sealed types kernel-applied; all4handwritten and2generatedproof providers reachable,7unreachable compiler simp artifacts explicitly retained, standard3axioms only. Sufficient elementary radius-tail route and unemitted source asymptotic/log intermediates remain explicit. Fresh source/fullmodule/native/static and normal sourceV remain pending. No source tau/shifted rotated detector/fullEx26/algorithm/oracle/TV/precision/cost/main lower bounds, shared/global/site/public/purification/Seal/whole-Goal completion.'
ma={'status':'none-found','discovery_ids':[],'evidence':str(E/'postproof-conceptual-mirror-audit.json')}
evidence={'result_kind':'theorem-edge','theorem_delta':cell['target_statement'],'lean_files':[str(prod),str(test)],'lean_declarations':[name],'publication_declarations':[name],'focused_checks':checks,'truth_boundary':boundary,'conceptual_mirror_audit':ma,'actual_consumer':'Actual new M beta squared bound materially chooses uniform N-squared cutoff, yields20 and combines genuine same-law Gaussian signed mean/variance/MemLp with Chebyshev and finite toReal conversion. No assumed signal,law,event or growth premise; not a wrapper.','source_VERIFIED_or_integration':False}
adv.transition_advance(ADV,'PROVED_LOCAL',worker_id=OWNER,evidence=evidence)
after=L.read_bytes();assert after.startswith(before);app=after[len(before):];assert len(app.splitlines())==1
new=adv._replay_advances([json.loads(x) for x in after.splitlines()])
assert {k:v for k,v in new.items() if k!=ADV}==b['all_SAU_states']
put(E/'frontier-before-PROVED_LOCAL.raw.json.gz',gzip.compress(cellraw,mtime=0));put(E/'actual-PROVED_LOCAL-append.exact.jsonl',app)
capsule={'state':'PROVED_LOCAL_NOT_SOURCE_VERIFIED','advance_id':ADV,'owner':OWNER,'normal_PROVED_LOCAL_API_calls':1,'append_sha256':sha(app),'foreign_SAU_states_preserved':len(states)-1,'foreign_frontiers_preserved':len(b['all_frontier_hashes']),'producer':{**ref(prod),'declaration':name,'actual_ASTIS_parents':r['actual_public_ASTIS_producer_parents']},'private_consumer':{**ref(test),'actual_ASTIS_parents':r['actual_public_ASTIS_private_consumer_parents'],'public_Anchor':False,'Registry_node':False},'actual_checks':checks,'owned_inventory':ref(E/'actual-kernel-owned-inventory.json'),'exact_signatures_kernel_applied':True,'conceptual_mirror_audit':ma,'source_to_lean_map':ref(E/'source-to-lean-map-v1.json'),'truth_boundary':boundary,'sourceV_or_integration_or_Goal_complete':False}
put(E/'local-proof-capsule.json',dump(capsule))
cell['status']='proved_locally'
cell['parents']=['ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-mode-gap','ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-bias','ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-exact-means']
cell['consumers'][0]='Compiled private actual_gaussian_source_query_zero_event_le_tenth uses actual new signal bound to choose a uniform cutoff and derive actual signed-zero-event probability<=1/10.'
cell['evidence'].update({'execution_boundary':boundary,'focused_checks':[x['receipt']['path'] for x in checks],'local_proof_capsule':str(E/'local-proof-capsule.json'),'actual_compiled_public_ASTIS_producer_parents':r['actual_public_ASTIS_producer_parents'],'actual_compiled_public_ASTIS_consumer_parents':r['actual_public_ASTIS_private_consumer_parents'],'publication_binding_sha256':r['publication_binding_sha256']})
cell['statement_seal']['status']='EXACT_UNCHANGED_SIGNATURES_COMPILED;_SOURCE_GRAPH_H1_H2_HISTORY_AND_V2_RESOLUTION_RETAINED;_POSTPROOF_REVIEW_PENDING'
cell['source_proof_coverage'].update({'internal_obligation_list_is_preserved_preproof_history':True,'source_to_lean_map':ref(E/'source-to-lean-map-v1.json'),'current_compiled_scope':'Actual finite norm/signal endpoints and private zero-event probability. Source strict tail/log and standalone asymptotic intermediates remain explicit sufficient-route/unemitted boundaries.'})
cell['source_detail_audit']['gap']='Selected norm/signal and private zero-event bridges locally proved. Source/exposition/fullmodule/native semantic correspondence remains pending independent postproof review; concrete tau,shifted rotated detector/full theorem branches remain open.'
cell['source_detail_audit']['fidelity_boundary']=boundary
cell['reuse_plan']['reused_declarations']=r['actual_public_ASTIS_producer_parents']+[r['actual_public_ASTIS_private_consumer_parents'][-1],'Real.add_one_le_exp','Real.exp_nat_mul','Real.rpow_add','Real.rpow_mul','exists_nat_ge','ProbabilityTheory.meas_ge_le_variance_div_sq']
cell['reuse_plan']['known_consumers']=['Compiled private actual_gaussian_source_query_zero_event_le_tenth: actual uniform finite probability, NON-ANCHOR.']
cell['reuse_plan']['searched_existing'].append('Actual Samplinglib/Mathlib pinned retrieval evidence: '+str(E/'actual-shared-floor-reuse-search-audit.json'))
cell['shared_floor_audit']['searched'].append('Actual Samplinglib/Mathlib reuse and path-mismatch limits: '+str(E/'actual-shared-floor-reuse-search-audit.json'))
cell['conceptual_mirror_audit']=ma
cell['learning_contract']['failure_class']='IMPLEMENTATION_FAILED'
cell['learning_contract']['salvage']['reason']='Real scalar normalization and redundant tactic failures repaired with exact statement unchanged; actual compiled public/private and both handwritten providers reachable. Source graph predecessor HOLDs/v2 repair and non-pristine planning chronology retained. Compiler-generated simp residue separated from handwritten or generated proof providers.'
C.write_bytes(dump(cell))
print(json.dumps({'state':'PROVED_LOCAL','append_sha256':sha(app),'producer':ref(prod),'consumer':ref(test),'archive':ref(archive),'sourceV':False}))
