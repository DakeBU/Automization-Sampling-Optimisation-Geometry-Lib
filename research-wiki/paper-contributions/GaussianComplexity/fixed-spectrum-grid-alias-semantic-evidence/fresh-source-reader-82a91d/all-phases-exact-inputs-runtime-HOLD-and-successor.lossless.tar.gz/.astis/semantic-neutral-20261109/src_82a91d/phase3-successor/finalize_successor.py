from pathlib import Path
import copy
import datetime
import hashlib
import importlib.util
import json
import subprocess

ROOT = Path('/Users/zhouhuanjian/ASTIS-GC')
OWN = ROOT / '.astis/semantic-neutral-20261109/src_82a91d'
OUT = OWN / 'phase3-successor'
CANDIDATE = '93a7005b3e861ddc58484fb3a21abd83ad44722b'

def digest(data):
    return hashlib.sha256(data).hexdigest()

def write(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

started = datetime.datetime.now(datetime.timezone.utc).isoformat()
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT).decode().strip()
status = subprocess.check_output(['git', 'status', '--short', '--untracked-files=no'], cwd=ROOT).decode()
assert head == CANDIDATE and not status
manifest = json.loads((OUT / 'inputs/manifest.json').read_text())
for row in manifest['unchanged_math_inputs']:
    data = (ROOT / row['path']).read_bytes()
    assert digest(data) == row['sha256'] and len(data) == row['bytes']
for phase in ['phase1', 'phase2', 'phase3']:
    frozen = json.loads((OWN / phase / 'FREEZE.json').read_text())
    for row in frozen['files']:
        assert digest((OWN / phase / row['path']).read_bytes()) == row['sha256']

packet = json.loads((OUT / 'inputs/canonical-reviewer-packet-reader-v2.json').read_text())
previous = json.loads((OWN / 'phase3/decision.json').read_text())
phase2 = json.loads((OWN / 'phase2/decision.json').read_text())
report_hash = digest((OUT / 'review-report.md').read_bytes())
slots = copy.deepcopy(previous['semantic_slots'])
for row in slots.values():
    row['evidence'] += ' Successor review verified unchanged mathematical bytes and complete corrected current authored context at 93a7005b.'
slot_map = {'P2-D1': 'objects', 'P2-D2': 'conclusion', 'P2-D3': 'scopes',
            'P2-D4': 'scopes', 'P2-D5': 'conclusion', 'P2-D6': 'conclusion', 'P2-D7': 'domains'}
deltas = [
    {'slot': slot_map[row['id']], 'severity': 'informational',
     'description': row['description'],
     'evidence': 'Independent source-only phase1 reading and phase2 seven-slot comparison; actual phase3 literal-type/proof checks; successor has no changed mathematical bytes. Classification: ' + row['kind'] + '. Nonblocking.'}
    for row in phase2['semantic_deltas']
]
reviewer = '/root/source_reader_82a91d'
report_path = str((OUT / 'review-report.md').relative_to(ROOT))
evidence = (
    f'Independent phased source-first review: {report_path}, SHA256 {report_hash}. '
    'New exact full packet and current complete lesson reviewed at 93a7005b3e861ddc58484fb3a21abd83ad44722b; '
    'P3-R1 resolved. Whole production/Test/source/toolchain/manifest bytes unchanged; real fresh runtime, '
    'literal types, recursive axioms, generated auxiliaries and actual ASTIS use checked at '
    'cbf3c22b901a484c463f417a3e206bb200622294 and preserved in phase3. '
    'Accepted bounded source/whole-module/static authored reader scope; no new build at successor, '
    'sourceV/API write, rendered site/UI/mobile/browser/remote or whole-Goal acceptance.'
)
review = {
    'state': 'accepted', 'reviewer': reviewer,
    'independent_from_formalizer': True, 'independent_from_decoder': True,
    'reviewer_packet_sha256': packet['packet_sha256'], 'evidence': evidence,
    'review_run_sha256': report_hash, 'run_artifact': report_path,
}
proposal = {
    'id': 'ASTIS-RT-20261109-HuanjianFixedSpectrumGridAlias',
    'state': 'source-reviewed',
    'semantic_slots': slots, 'deltas': deltas,
    'verdict': 'equivalent-after-elaboration', 'source_review': review,
    'repairs': [],
    'publication_binding_sha256': packet['publication_binding_sha256'],
    'publication_context': packet['candidate_publication_context'],
}
write('canonical-audit-update-proposal.json', proposal)

# Pure mechanical packet reconstruction from delivered inputs only.
# Do not call load_registry or open any prior audit, verdict, or repair.
core_file = ROOT / 'tools/astis_semantic_roundtrip_core.py'
spec = importlib.util.spec_from_file_location('independent_roundtrip_schema_82a91d', core_file)
core = importlib.util.module_from_spec(spec)
spec.loader.exec_module(core)
synthetic = {
    'source': packet['source'],
    'lean': {**packet['lean'], 'formalizer': packet['roles']['formalizer']},
    'reconstruction': packet['blind_reconstruction'],
    **proposal,
}
regenerated = core.semantic_reviewer_packet(synthetic)
assert regenerated == packet
assert set(slots) == set(core.SEMANTIC_SLOTS)
for row in slots.values():
    assert row['relation'] in {'same', 'equivalent', 'explicit-elaboration'}
    assert all(isinstance(row[key], str) and row[key].strip() for key in ['original', 'reconstructed', 'evidence'])
assert all(row['slot'] in core.SEMANTIC_SLOTS and row['severity'] == 'informational'
           and row['description'] and row['evidence'] for row in deltas)
assert reviewer not in {packet['roles']['formalizer'], packet['roles']['blind_decoder']}
write('proposal-mechanical-checks.json', {
    'proposal_schema_fields_checked': True,
    'source_review_state': review['state'],
    'full_packet_regenerated_from_delivered_inputs_and_proposed_context': True,
    'exact_regenerated_packet_canonical_sha256': regenerated['packet_sha256'],
    'new_publication_binding_carried_exactly': regenerated['publication_binding_sha256'],
    'full_registry_loaded': False, 'prior_audit_or_repair_loaded': False,
    'actual_shared_audit_mutated': False,
})

write('decision.json', {
    'reviewer': reviewer, 'candidate_commit': CANDIDATE,
    'math_core_runtime_commit': 'cbf3c22b901a484c463f417a3e206bb200622294',
    'new_Lean_build_run': False,
    'reviewer_packet_sha256': packet['packet_sha256'],
    'publication_binding_sha256': packet['publication_binding_sha256'],
    'review_run_sha256': report_hash,
    'producer_source_fidelity': 'equivalent-after-elaboration',
    'whole_module_proof_binder_definition_acceptance': True,
    'private_consumer_source_fidelity_and_actual_use_acceptance': True,
    'static_current_authored_reader_acceptance': True,
    'current_bounded_source_review_acceptance': True,
    'P3-R1': 'resolved by exact source definitions and explicit natural mode domain',
    'new_issues': [], 'repairs': [],
    'canonical_audit_update_status': 'proposal only in owned directory; not applied',
    'canonical_audit_update_proposal_sha256': digest((OUT / 'canonical-audit-update-proposal.json').read_bytes()),
    'sourceV_API_status_write_performed': False,
    'rendered_site_UI_mobile_browser_remote_or_whole_Goal_credit': False,
})
write('input-exposure-manifest.json', {
    'phase': 'phase3 exposition-only successor', 'actor': reviewer,
    'new_inputs': manifest['files'], 'manifest_raw_sha256': digest((OUT / 'inputs/manifest.json').read_bytes()),
    'earlier_phase1_phase2_phase3_freezes_and_artifact_bytes_unchanged': True,
    'new_whitelisted_content': 'Exactly three delivered files read completely; current math/publication/toolchain/manifest byte checks; own earlier frozen source/review/runtime evidence.',
    'additional_mechanical_code_reads': [
        {'path': 'tools/astis_semantic_roundtrip.py', 'ranges': ['1-180']},
        {'path': 'tools/astis_semantic_roundtrip_core.py', 'ranges': ['34-95', '109-116', '260-280', '280-365', '555-645'],
         'additional': 'narrow symbol/line rg search; pure semantic_reviewer_packet invoked on delivered synthetic input only'},
    ],
    'no_prior_audit_verdict_repair_files_opened': True,
    'no_registry_loader_called': True,
    'ambient_exposure': 'Prior phased manifests remain authoritative, including filename-only truncation limitation; no zero-cue claim.',
})
ended = datetime.datetime.now(datetime.timezone.utc).isoformat()
write('final-verification-receipt.json', {
    'argv': ['python3', str(Path(__file__).relative_to(ROOT))], 'cwd': str(ROOT),
    'started_utc': started, 'ended_utc': ended, 'head': head, 'tracked_status': status,
    'head_after': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT).decode().strip(),
    'script_sha256': digest(Path(__file__).read_bytes()),
    'assertions_completed': True, 'no_Lean_command_executed': True,
})
files = []
for f in sorted(OUT.rglob('*')):
    if f.is_file() and f.name != 'FREEZE.json':
        b = f.read_bytes()
        files.append({'path': str(f.relative_to(OUT)), 'sha256': digest(b), 'bytes': len(b)})
write('FREEZE.json', {
    'phase': 'phase3 exposition-only successor', 'reviewer': reviewer,
    'candidate_commit': CANDIDATE,
    'frozen_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'reviewer_packet_sha256': packet['packet_sha256'],
    'publication_binding_sha256': packet['publication_binding_sha256'],
    'review_run_sha256': report_hash,
    'decision_sha256': digest((OUT / 'decision.json').read_bytes()),
    'canonical_audit_update_proposal_sha256': digest((OUT / 'canonical-audit-update-proposal.json').read_bytes()),
    'result': 'Current bounded source/whole-module/static reader accepted; P3-R1 resolved; proposal only; no sourceV/API/status write.',
    'files': files,
})
print(json.dumps({
    'freeze_path': str(OUT / 'FREEZE.json'),
    'freeze_sha256': digest((OUT / 'FREEZE.json').read_bytes()),
    'review_run_sha256': report_hash,
    'decision_sha256': digest((OUT / 'decision.json').read_bytes()),
    'proposal_sha256': digest((OUT / 'canonical-audit-update-proposal.json').read_bytes()),
    'new_packet_sha256': packet['packet_sha256'],
    'new_publication_binding_sha256': packet['publication_binding_sha256'],
    'files': len(files),
}, indent=2))
