# R15 independent source-only challenge freeze

FROZEN_SOURCE_ONLY_FRAMEWORK;PHASE2_GRAPH_REVIEW_PENDING

The source-only challenge framework was frozen before reading any source graph, root provisional intake, R14 proof/verdict or Lean implementation. No proof, normal API, Git, Chrome or production action was run.

## Independent requirements

- **P01 Matrix carrier and lambda_max** (Tropp §2.1 p7): Finite nonempty square real matrices specialize the complex source; sSup spectrum must denote largest algebraic real eigenvalue on the ae Hermitian domain, never norm.
- **P02 Regularity and ae transport** (Tropp §2.2 p7): AEStronglyMeasurable X and ae self-adjointness must internally discharge spectral-event/trace-exp measurability and null-set transport. No supplied tail or mgf certificate.
- **P03 Positive homogeneity** (Tropp Prop3.1 pp9-10 first identity): s>0 allows lambda_max(s X)=s lambda_max(X); all real thresholds retained.
- **P04 Scalar exponential event conversion** (Tropp Prop3.1 pp9-10 second identity): Strict monotonicity of exp converts >= events exactly; exp(s*t)>0 even for negative/zero t.
- **P05 Scalar Markov** (Tropp Prop3.1 pp9-10 third relation): Markov on nonnegative exp(lambda_max(s X)); extended expectation allowed. No independence or moment premise.
- **P06 Matrix exponential spectral mapping** (Tropp §2.3-2.4 pp7-8 and Prop3.1 p10): Series matrix exponential agrees with spectral functional calculus and exp(lambda_max(s X))=lambda_max(exp(s X)).
- **P07 Trace domination** (Tropp §2.4 p8 and Prop3.1 p10): Self-adjoint exp is positive definite; largest eigenvalue <= ordinary unnormalized trace.
- **P08 Expectation comparison and fixed-s inequality** (Tropp Prop3.1 p10 combine relations): Ae pointwise trace domination yields monotone nonnegative scalar expectation comparison.
- **P09 Infimum** (Tropp Prop3.1 p10 final sentence): One bound for each strictly positive real s yields infimum; no finite-mgf-only restriction.
- **P10 Extended expectation semantic expansion** (Tropp §3.1 p9 caveat and nonnegative scalar proof): Source never says ENNReal. Explicitly admit only as canonical nonnegative scalar extended-expectation interpretation, not entrywise extended matrix mgf nor finite Bochner expectation. Infinite terms are harmless; no assumption added.
- **T01 Original Gaussian experiment** (Gaussian S4.Thmtheorem4.p1.1 and C2 p1/Ex85): Literal q+1 independent N(0,I_d) vectors on unconditional product law; rows are coordinate reindexings. q=0 retained, hq implies d>=2,r>=1.
- **T02 Angles and feature vector** (Gaussian S4.SS1 Eq11 and C2 Ex85): Fin d shift i.val+1 reproduces source i=1..d, alpha=(i-1/2)pi/d; coordinates 0..q, constant first and sqrt2*cos otherwise.
- **T03 Literal cutoff matrix and dimension** (Gaussian C2 p10/Ex107): Inclusive own-row ||gamma_i||²<=L cutoff; d^-1(rowouter tensor featureouter), paired index Gaussian first. Square matrix size r².
- **T04 Actual unconditional mean** (Gaussian C2 p13): Y measurable, bounded and integrable before actual Bochner mean is interpreted as expectation; its mean is self-adjoint. No conditioned law.
- **T05 Four actual signed sums** (Gaussian C2 p13 and p15.2): Z=Y-EY; weights 1 or cos((2q+1)alpha_i); global +/- handled individually, no equal-law or equal-mgf shortcut.
- **T06 Internal regularity and boundedness** (Gaussian C2 p13/Ex112; source standing probability convention): Finite sums, |cos|<=1 and cutoff bounds internally give each S measurability, self-adjointness and uniform finite norm bound. Exact Gaussian independence/zero-mean estimates are not prerequisites for the fixed-s P application.
- **T07 Finite trace exponential** (Necessary semantic expansion of C2 bounded-summand setting): Continuous matrix exp and finite norm bound give measurable integrable real trace-exp for every fixed s; positivity from self-adjointness; ordinary trace carries dimension r².
- **T08 Extended-to-Bochner and application** (External matched Tropp Prop3.1 plus exact C2 objects): Prove lintegral of ofReal(trace-exp)=ofReal(actual Bochner integral) from positivity and integrability; take fixed positive s bound from P. T has only hq, s>0,a and cases as logical inputs.
- **B01 Spectral tail versus operator norm tail** (Gaussian C2 Ex121): Generic P/T use >= for largest algebraic eigenvalue and all real thresholds; C2 has strict norm > at positive t. Future norm transfer needs explicit both-sign event inclusion and union bound.
- **B02 External attribution and open frontier** (Tropp Prop3.1; Gaussian C2 Bernstein call): Gaussian C2 does not explicitly cite Tropp here. Independent matched background P does not close Lieb, independent-sum master tail, Bernstein, C6, Lemma4.4, main lower bounds or later adapters.

## Boundary attacks

- **F01 Replace lambda_max by norm**: A=diag(-3,1) has lambda_max=1, operator norm=3. For A=-I and t=0, spectral tail is 0 while norm tail is 1. Reject semantic identification; keep both signs for a later norm adapter.
- **F02 Normalize trace**: For deterministic A=diag(0,-1), t=0,s=1, event probability=1 but exp(-s*t)*(tr exp(sA)/2)=(1+exp(-1))/2<1. Normalized trace would make the claimed bound false.
- **F03 Use unconstrained real Bochner expectation**: Scalar X~Exp(rate=1) has all polynomial moments, while E exp(X)=infinity. At s=1,t=0, Lean nonintegrable real Bochner integral defaults to 0, producing false 1<=0. P needs nonnegative extended expectation; T must prove integrability internally.
- **F04 Drop negative sign using symmetry**: At q=0,d=2, the ordinary scalar cutoff sum has support endpoints -m and L-m, where 0<m=E sumY<1 and L=2+3 log(2000)>2; these are asymmetric. Hence global negation cannot have the same law. Retain four literal cases and prove each bound without equal mgf assumption.
- **F05 Exclude q=0 or use matrix size r/d**: q=0,d=2 is allowed by 2q+1<d, with r=1 and matrix size1. At q=1,d=4, size r²=4 although r=2. Check lower endpoint and unnormalized trace dimension.
- **F06 Turn source norm > into a spectral >= identity**: At an eigenvalue exactly equal to threshold, >= includes the boundary while > excludes it; positive and negative eigenvalue tails are separate. Only an explicit inclusion is permitted for later norm transfer.

## Phase 1 assessment

No mandatory seal repair identified from raw source and sealed interface alone. P extended scalar expectation is an explicitly declared nonnegative-expectation expansion; the source itself does not specify ENNReal. T requires actual boundedness/integrability and the extended-to-Bochner bridge internally. Graph admission remains pending. This is not a mathematical verification.
