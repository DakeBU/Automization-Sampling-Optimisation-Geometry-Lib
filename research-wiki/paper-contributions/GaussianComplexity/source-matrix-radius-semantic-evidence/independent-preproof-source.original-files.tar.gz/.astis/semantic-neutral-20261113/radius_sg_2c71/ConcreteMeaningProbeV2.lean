import AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumSourceMatrixVariance
import AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumSourceMatrixMean

noncomputable section
open MeasureTheory ProbabilityTheory
open scoped BigOperators Matrix Kronecker Matrix.Norms.L2Operator

/- This file only asks for elaborator/definition/instance information.
   It contains no target theorem or proof construction. -/
section
variable (q : ℕ)
set_option pp.all true in
#synth Norm (Matrix (Fin (q + 1) × Fin (q + 1)) (Fin (q + 1) × Fin (q + 1)) ℝ)
set_option pp.all true in
#synth NormedAddCommGroup (Matrix (Fin (q + 1) × Fin (q + 1)) (Fin (q + 1) × Fin (q + 1)) ℝ)
set_option pp.all true in
#synth NormedSpace ℝ (Matrix (Fin (q + 1) × Fin (q + 1)) (Fin (q + 1) × Fin (q + 1)) ℝ)
set_option pp.all true in
#synth CompleteSpace (Matrix (Fin (q + 1) × Fin (q + 1)) (Fin (q + 1) × Fin (q + 1)) ℝ)
#check @Matrix.toEuclideanCLM
#check @Matrix.l2_opNorm_def
#check @Matrix.cstar_norm_def
#check @ProbabilityTheory.stdGaussian
#check @MeasureTheory.Measure.pi
#check @MeasureTheory.integral
#check @MeasureTheory.Integrable
#check @WithLp.toLp
#check @WithLp.ofLp
#check @Matrix.kronecker
#check @Matrix.vecMulVec
end

#synth Norm (Matrix (Fin 1 × Fin 1) (Fin 1 × Fin 1) ℝ)
#print ProbabilityTheory.stdGaussian
#print MeasureTheory.Measure.pi
#print WithLp.toLp
#print WithLp.ofLp
#print Matrix.vecMulVec
