from pathlib import Path
import hashlib
import json
import sys

base=Path(__file__).resolve().parent
mode=sys.argv[1]
files={
 'raw':[('author-phase1/source_graph.json','c4b19d5410db563d3211b148277a34d2181cbf1133bef0b9932f0eb117ab5d4c')],
 'typed':[('author-phase2/typed_overlay.json','e91185a610e691520fa0ca329d329e42ec2a825a36a3a19167c802a9257fc6cd'),
          ('author-phase2/proof_obligations.json','b425c85c575075e18f86b5ff06965d70ea7d38185e713f83a6d14429049f6f82')],
 'coverage-schema':[('author-phase1/coverage.json','da152a145bb41d16bd224196e12a6feaad160afb3b7ee86d68ee6c8765532e05'),
                    ('author-phase1/source_index.json','699039d23b562b9af5cc25468cf0c1ca00d27c473772599258dd60a1ed39b2e4')]
}[mode]
out=[]
for name,digest in files:
    b=(base/name).read_bytes()
    assert hashlib.sha256(b).hexdigest()==digest,name
    if mode!='coverage-schema':text=b.decode()
    else:
        data=json.loads(b);summary={}
        for key,value in data.items():
            if isinstance(value,list):summary[key]={'length':len(value),'first_two':value[:2]}
            elif isinstance(value,dict):summary[key]={'keys':list(value)[:30],'length':len(value)}
            else:summary[key]=value
        text=json.dumps(summary,ensure_ascii=False,indent=2)
    out.append('INPUT '+name+' SHA256 '+digest+'\n'+text)
stdout='\n\n'.join(out)+'\n';(base/('read-author-'+mode+'.stdout.txt')).write_text(stdout);print(stdout,end='')
