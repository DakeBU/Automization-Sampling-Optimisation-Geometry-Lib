from pathlib import Path
import json,hashlib,gzip,datetime,subprocess,sys,os
sys.dont_write_bytecode=True
R=Path('/Users/zhouhuanjian/ASTIS-GC');sys.path.insert(0,str(R/'tools'))
import astis_advance as adv,astis_publication as pub
P=R/'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-admissibility-integration-20261107/independent-integration-reader-review/proposal'
O=P.parent/'postcore';O.mkdir(exist_ok=False)
CORE='6483deccec5b721527d9102b7a57102c0205149d';MATH='2df0cd116cd21a71113ae67997b7482878633460';CHECKED='83fec39dfa6202cdf9bc687affb10aafbc216ab8';AUDITFIRST='96a6da3fe9d7fbe17af5624552a1152743587150';VFIRST='4c1c45f7cecb6ac2351d328899848766c1683eb8'
ADV='ASTIS-SA-20261107-GaussianComplexityFixedSpectrumAdmissibility';OWNER='huanjian_gc_20261107_fixed_spectrum_admissibility';VERIFIER='/root/reader_742806';INTEGRATOR='huanjian_gc_20261107_fixed_spectrum_admissibility_integration'
DECL='AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumAdmissibility.actual_precision_admissible';BINDING='e4e245c817d124b16e93b4f999df81132f1e50a9e38535903cb5c036417c0e94'
sha=lambda b:hashlib.sha256(b).hexdigest()
canon=lambda x:json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
def cmd(*args):return subprocess.check_output(args,cwd=R)
def obj(c,p):return cmd('git','show',c+':'+p)
def put(p,x):assert not p.exists();p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def unpack(row):
 raw=(R/row['path']).read_bytes();assert sha(raw)==row['gzip_sha256'];data=gzip.decompress(raw);assert sha(data)==row['raw_sha256'];return data
assert cmd('git','rev-parse','HEAD').decode().strip()==CORE
rp=P/'proposal-report.json';assert sha(rp.read_bytes())=='4aa865058b3c49a415e8e6d47c78da4885d90f5871d035d1cc79b0a46fbeb537'
assert sha((P/'freeze.json').read_bytes())=='82a4a1d812cf79a977083d676df40483d8a1cccf24ccd68a38e6572f03b0d11b'
plan=json.loads(rp.read_bytes());assert len(plan['shared_paths'])==6
for row in plan['shared_paths']:
 p=row['path'];raw=(R/p).read_bytes();assert sha(raw)==row['planned_after_sha256'] and unpack(row['planned_after_archive'])==raw
 assert obj(CORE,p)==raw
 if row['before_exists']:assert sha(unpack(row['before_archive']))==row['before_sha256'] and obj(VFIRST,p)==unpack(row['before_archive'])
 else:assert subprocess.run(['git','cat-file','-e',VFIRST+':'+p],cwd=R,stdout=subprocess.PIPE,stderr=subprocess.PIPE).returncode!=0
for p,h in plan['source_Test_lesson_publication_pins'].items():assert sha((R/p).read_bytes())==h and obj(CORE,p)==(R/p).read_bytes()
item=next(x for x in pub.load() if x['id']=='huanjian-fixed-spectrum-admissibility');assert pub.binding_digest(item,item['bindings'][0])==BINDING
for p,h in plan['unchanged_models'].items():assert sha((R/p).read_bytes())==h and obj(CORE,p)==obj(MATH,p)==(R/p).read_bytes()
frontier=json.loads((R/'website/content/samplewiki_companion_frontiers.json').read_bytes());protected=plan['protected_case_values']
assert sha(canon(frontier['execution']))==protected['execution_sha256'] and sha(canon(frontier['cases'][4]['theorems'][0]))==protected['determinant_theorem_index0_sha256']
assert frontier['cases'][4]['theorems'][1]['boundary'].endswith(protected['Section4_4_limitation_suffix'])
frontier['cases'][4]['reader_guide'][3]='<OWN_ADMISSIBILITY_SCALAR>';frontier['cases'][4]['theorems'][1]['boundary']='<OWN_ADMISSIBILITY_SCALAR>'
assert sha(canon(frontier))==protected['all_other_case_values_sha256']
reg=(R/'AutoSamplingTheory/TechnicalLemmas/Registry.lean').read_bytes();oldreg=unpack(plan['shared_paths'][3]['before_archive'])
assert reg.count(b'status := LemmaMemoryStatus.formalizedLocal')==618
assert reg.count(b'key := "gaussian-complexity.fixed-spectrum-admissibility"')==1
assert (R/'Tests/Basic.lean').read_bytes().count(b'formalizedTechnicalLemmaCount = 618')==1
states=adv.current_advances();own=states[ADV];assert own['state']=='STABILIZING' and own['latest_evidence']['integration_owner']==INTEGRATOR
assert [k for k,v in states.items() if v['state']=='STABILIZING']==[ADV]
foreign_counts={}
for path,row in plan['ledger_protection'].items():
 raw=(R/path).read_bytes();prefix=unpack(row['raw_prefix']);assert raw.startswith(prefix)
 foreign=json.loads(unpack(row['foreign_projection']));current=states if 'advances' in path else adv.current_discoveries()
 assert all(current[k]==v for k,v in foreign.items());foreign_counts[path]=len(foreign)
inputs=json.loads(unpack(plan['protected_foreign_content']))
for p,row in inputs.items():
 q=R/p;raw=os.fsencode(os.readlink(q)) if q.is_symlink() else q.read_bytes();assert sha(raw)==row['sha256'],p
gitmap=json.loads(unpack(plan['protected_git_objects']));nowmap={}
for line in cmd('git','ls-files','--stage','-z').split(b'\0'):
 if not line:continue
 md,p=line.split(b'\t',1);mode,blob,stage=md.decode().split();assert stage=='0';nowmap[os.fsdecode(p)]=[mode,blob]
assert all(nowmap.get(p)==v for p,v in gitmap.items())
foreignfrontiers=json.loads(unpack(plan['foreign_frontiers']))
for p,h in foreignfrontiers.items():assert sha((R/p).read_bytes())==h,p
oldgc=json.loads(unpack(plan['older_GaussianComplexity_evidence']))
for p,h in oldgc.items():assert sha((R/p).read_bytes())==h,p
atlas=(R/'.atlas-upstream').stat();beforeatlas=plan['untracked_Atlas'];assert atlas.st_dev==beforeatlas['device'] and atlas.st_ino==beforeatlas['inode'] and atlas.st_mtime_ns==beforeatlas['mtime_ns']
readme='research-wiki/paper-contributions/GaussianComplexity/README.md';assert sha((R/readme).read_bytes())==inputs[readme]['sha256']
for a,b in [(MATH,CHECKED),(CHECKED,AUDITFIRST),(AUDITFIRST,VFIRST),(VFIRST,CORE)]:cmd('git','merge-base','--is-ancestor',a,b)
ap='research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-admissibility.json';auditbytes=(R/ap).read_bytes();audit=json.loads(auditbytes);assert sha(auditbytes)=='02a2529fc9d4d50afc09e6d36cfb11f61bf37cb93988f1c072ab789dc7d01356'
assert audit['state']=='accepted' and audit['source_review']['reviewer']==VERIFIER and audit['publication_binding_sha256']==BINDING
assert audit['lean']['formalizer']==OWNER and audit['reconstruction']['decoder']!=OWNER
assert json.loads(obj(CHECKED,ap))['state']=='blind-reconstructed'
assert obj(AUDITFIRST,ap)==obj(VFIRST,ap)==auditbytes and obj(CHECKED,ap)!=auditbytes
V=R/'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-admissibility-semantic-evidence/fresh-source-reader-742806/phase3-verification-transition'
append=(V/'advance-ledger.append.raw.jsonl').read_bytes();assert sha(append)=='beff8c6b9922a11027d25118f6f771bad79a1d3e966126c4cf79eecce498d032' and len(append)==4505 and len(append.splitlines())==1
before=gzip.decompress((V/'advance-ledger.before.raw.jsonl.gz').read_bytes());after=gzip.decompress((V/'advance-ledger.after.raw.jsonl.gz').read_bytes());assert after==before+append
assert obj(CHECKED,'runs/substantive_advances.jsonl')==obj(AUDITFIRST,'runs/substantive_advances.jsonl')==before
assert obj(VFIRST,'runs/substantive_advances.jsonl')==after
event=json.loads(append);assert event['worker_id']==VERIFIER and event['evidence']['verifier_id']==VERIFIER and event['evidence']['verified_commit']==CHECKED and event['from_state']=='PROVED_LOCAL' and event['to_state']=='VERIFIED'
current=(R/'runs/substantive_advances.jsonl').read_bytes();assert current.startswith(after) and len(current[len(after):].splitlines())==1
stab=json.loads(current[len(after):]);assert stab['to_state']=='STABILIZING' and stab['worker_id']==INTEGRATOR and stab['advance_id']==ADV
receipt=json.loads((V/'actual-execution.receipt.json').read_bytes());assert receipt['returncode']==0 and sha((V/'actual-execution.stdout.raw').read_bytes())==receipt['raw_stdout_sha256']
pres=json.loads((V/'complete-preservation-receipt.json').read_bytes());assert pres['API_calls']==1 and pres['actual_actor']==VERIFIER and pres['proof_owner_before_after']==OWNER and pres['append_sha256']==sha(append)
requests=[json.loads(line) for line in current.splitlines() if line.strip() and ADV.encode() in line]
assert len([e for e in requests if e.get('to_state')=='VERIFIED'])==1
review_run_path=R/audit['source_review']['run_artifact'];assert sha(review_run_path.read_bytes())==audit['source_review']['review_run_sha256']
gate_receipt=R/'.astis/huanjian-resume-20261103/20261107T160011569521Z-fixed-spectrum-admissibility-canonical-exactHEAD-Lean.receipt.json';gr=json.loads(gate_receipt.read_bytes());assert gr['exit_code']==0 and gr['head_before']==gr['head_after']==CORE and sha(Path(gr['log']).read_bytes())==gr['log_sha256']
gate=json.loads((R/'.astis/site-lean-gate.json').read_bytes());assert gate['passed'] and gate['commit']==CORE
assert cmd('git','rev-parse','HEAD').decode().strip()==CORE
out={'reviewer':'/root/admiss_integration_reader','recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'core':CORE,'phase':'Independent bounded postcore shared-write/sourceV-lineage/preservation readback','verdict':'POSTCORE_READBACK_PASS_NOT_LOCAL_SITE_ACCEPTANCE','actual_six_shared_paths_match_exact_reviewed_payloads':True,'one_canonical_Registry_entry_and_administrative_618':True,'all_old_Registry_bytes_preserved_by_exact_after_match':True,'source_Test_lesson_publication_and_binding_unchanged':True,'producer_ASTIS_parents':[],'canonical_Gaussian_reused_in_Test_only':True,'both_models_exact_bytes_preserved':plan['unchanged_models'],'determinant_index0_execution_other_case_values_and_Section4_4_suffix_preserved':True,'foreign_advances':foreign_counts['runs/substantive_advances.jsonl'],'foreign_discoveries':foreign_counts['runs/substantive_discoveries.jsonl'],'protected_foreign_content_count':len(inputs),'protected_old_git_objects_count':len(gitmap),'foreign_frontier_count':len(foreignfrontiers),'older_GC_evidence_count':len(oldgc),'README_exact_bytes_preserved':True,'Atlas_directory_stat_only_unchanged':True,'sourceV_lineage':{'math_draft_candidate':MATH,'checked_blind_audit_commit':CHECKED,'accepted_audit_first_commit':AUDITFIRST,'accepted_audit_and_normal_V_first_commit':VFIRST,'accepted_audit_sha256':sha(auditbytes),'independent_source_verifier':VERIFIER,'proof_owner':OWNER,'actual_normal_API_calls':1,'normal_V_append_sha256':sha(append),'normal_V_append_bytes':len(append),'ledger_at_96_was_exact_before_not_V':'Genuine staging omission; exact original independent append is first carried at4c with no repeated API/reset. Actual Git bytes independently compared.','current_ledger_prefix':sha(after),'one_current_STAB_append_only':True,'source_review_run_sha256':audit['source_review']['review_run_sha256']},'actual_exactHEAD_official_gate':{'receipt':str(gate_receipt.relative_to(R)),'receipt_sha256':sha(gate_receipt.read_bytes()),'raw_log_sha256':gr['log_sha256'],'elapsed_seconds':gr['elapsed_seconds'],'actual_gate_sha256':sha((R/'.astis/site-lean-gate.json').read_bytes())},'remaining_acceptance':['Actual final canonical sitebuild/sitecheck/graph receipts','Actual final approved Chrome run and all original desktop/mobile screenshots independently viewed','Final protection readback and explicit normal parking authorization','Remote/public delivery, purification/Exposition Seal, main lower bounds and wholeGoal'],'shared_or_API_or_ledger_or_build_or_browser_mutations':False}
put(O/'postcore-readback.json',out)
put(O/'freeze.json',{'reviewer':out['reviewer'],'core':CORE,'report_sha256':sha((O/'postcore-readback.json').read_bytes()),'proposal_report_sha256':sha(rp.read_bytes()),'proposal_freeze_preserved':'82a4a1d812cf79a977083d676df40483d8a1cccf24ccd68a38e6572f03b0d11b'})
print(json.dumps({'state':out['verdict'],'report_sha256':sha((O/'postcore-readback.json').read_bytes()),'freeze_sha256':sha((O/'freeze.json').read_bytes()),'foreign_advances':len(states)-1,'protected_content':len(inputs)}))
