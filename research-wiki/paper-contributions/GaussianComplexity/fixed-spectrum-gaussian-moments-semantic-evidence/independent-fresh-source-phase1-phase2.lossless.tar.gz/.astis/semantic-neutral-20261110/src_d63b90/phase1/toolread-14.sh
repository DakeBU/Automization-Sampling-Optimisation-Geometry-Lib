python3 - <<'PY'
import sys,runpy,re
sys.argv=['extract_source.py','context']
g=runpy.run_path('.astis/semantic-neutral-20261110/src_d63b90/extract_source.py')
html=g['html'];p=g['p'];render=g['textnode']
for m in list(re.finditer(r'notation|Throughout|throughout|conventions',html))[:12]:
    containers=[(n.end-n.start,ident,n) for ident,n in p.ids.items() if n.start<=m.start()<n.end and n.tag in {'div','section','p'}]
    if containers:
        _,ident,n=min(containers,key=lambda x:x[0]); print(ident, render(n))
PY
