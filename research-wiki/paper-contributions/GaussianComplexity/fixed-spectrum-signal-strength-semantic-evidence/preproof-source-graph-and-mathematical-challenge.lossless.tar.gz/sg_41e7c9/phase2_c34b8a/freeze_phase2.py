from pathlib import Path
from datetime import datetime, timezone
from collections import Counter
import hashlib
import json

BASE=Path(__file__).resolve().parent
P1=BASE.parent
sha=lambda b:hashlib.sha256(b).hexdigest()
def read(name): return json.loads((BASE/name).read_text())
def write(name,obj):
    (BASE/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
f1=json.loads((P1/'phase1_freeze.json').read_text())
assert sha((P1/'phase1_freeze.json').read_bytes())=='69372fb70615bbc7cc6ddc0fe9a6baa96177126d2eb67647882d19626ca67509'
for x in f1['files']:
    b=(P1/x['path']).read_bytes()
    assert len(b)==x['bytes'] and sha(b)==x['sha256']
g=read('source_graph.json')
c=read('source_unit_dispositions.json')
roots=read('root_closures.json')['roots']
u=json.loads((P1/'raw_unit_inventory.json').read_text())
assert len(c['units'])==len(u)==809
assert {x['unit'] for x in c['units']}=={x['unit'] for x in u}
for a,b in zip(c['units'],u):
    assert a['unit']==b['unit'] and a['raw_sha256']==b['raw_sha256']
    assert a['disposition'] in {'NODE','EXCLUDED'} and a['reason']
ids={n['id'] for n in g['nodes']}
assert len(ids)==len(g['nodes'])
for x in c['units']:
    if x['disposition']=='NODE': assert x['node_ids'] and set(x['node_ids'])<=ids
for e in g['hyperedges']:
    assert set(e['parents']+[e['child']])<=ids
    assert e['consumer_use_sites'] and e['use']
# Dependency cycle check and recomputation of each complete backward closure.
parents={n:[] for n in ids}
for e in g['hyperedges']:
    if e['dependency']: parents[e['child']].extend(e['parents'])
seen=set()
active=set()
def visit(n):
    assert n not in active,('dependency-cycle',n)
    if n in seen: return
    active.add(n)
    for p in parents[n]: visit(p)
    active.remove(n)
    seen.add(n)
for n in ids: visit(n)
for r in roots:
    todo=[r['root']]
    ns=set()
    es=set()
    while todo:
        n=todo.pop()
        if n in ns: continue
        ns.add(n)
        for e in g['hyperedges']:
            if e['dependency'] and e['child']==n:
                es.add(e['id'])
                todo.extend(e['parents'])
    assert sorted(ns)==r['node_ids'] and sorted(es)==r['edge_ids']
    assert not ({'s:shifted-detector','s:shifted-target-test','s:tau-beta','s:uniform-krylov','ext:22'}&ns)
pub=next(r for r in roots if r['root']=='root:public-signal')
priv=next(r for r in roots if r['root']=='root:private-zero-event')
assert 'c:variance' not in pub['node_ids']
assert {'c:variance','a:private-chebyshev','a:private-threshold'}<=set(priv['node_ids'])
rawids={x['id'] for x in u if x['id']}
assert all(set(n['source_anchors'])<=rawids for n in g['nodes'])
assert all(set(e['consumer_use_sites'])<=rawids for e in g['hyperedges'])
conditional=read('conditional_discharge_audit.json')
assert all(set(e.get('source_gap_ids',[]))<=ids for e in conditional['entries'])
write('phase2_integrity_check.json',dict(status='STRUCTURAL_CHECKS_PASS_NOT_MATHEMATICAL_COVERAGE_APPROVAL',
    phase1_files_rehashed_unchanged=len(f1['files']),raw_units=809,node_count=len(g['nodes']),
    hyperedge_count=len(g['hyperedges']),dispositions=dict(Counter(x['disposition'] for x in c['units'])),
    all_raw_units_have_exact_one_disposition=True,all_source_and_use_site_anchors_exist_in_raw_inventory=True,
    all_named_gaps_exist=True,dependency_graph_acyclic=True,full_backward_closures_recomputed=True,
    selected_roots_exclude_shifted_detector_tau_krylov_external22=True,
    public_root_excludes_variance_private_root_includes_variance_adaptation=True,
    independent_mathematical_coverage_approval='NOT_PERFORMED_REQUIRES_DISTINCT_REVIEWER'))
manifest=dict(schema='source-graph-phase2-freeze-v1',stage='FROZEN_BEFORE_IMPLEMENTATION_OR_PROOF_SEARCH',
    created_utc=datetime.now(timezone.utc).isoformat(),
    phase1=dict(path='../phase1_freeze.json',sha256='69372fb70615bbc7cc6ddc0fe9a6baa96177126d2eb67647882d19626ca67509',payload_files_unchanged=len(f1['files'])),
    projection=dict(path='sealed_projection.exact.json',sha256='e8322849cd533289522de2de96ae5913364b1446dee114d4224956c1ced02fca',bytes=5842),
    source_sha256='6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915',
    graph='source_graph.json',coverage='source_unit_dispositions.json',closures='root_closures.json',
    conditional_discharge='conditional_discharge_audit.json',statement_judgment='statement_definition_judgment.md',
    provenance='provenance_and_boundary.json',source_statement_hold=False,
    independent_coverage_status='PENDING_DISTINCT_REVIEWER',implementation_Lean_or_API_exposure=False,
    files=[])
for f in sorted(BASE.iterdir()):
    if f.is_file() and f.name not in {'phase2_freeze.json','phase2_freeze.sha256'}:
        b=f.read_bytes()
        manifest['files'].append(dict(path=f.name,bytes=len(b),sha256=sha(b)))
mb=(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode()
(BASE/'phase2_freeze.json').write_bytes(mb)
(BASE/'phase2_freeze.sha256').write_text(sha(mb)+'  phase2_freeze.json\n')
print(json.dumps(dict(freeze_path=str(BASE/'phase2_freeze.json'),freeze_sha256=sha(mb),
    hashes={n:sha((BASE/n).read_bytes()) for n in ['source_graph.json','source_unit_dispositions.json','root_closures.json','conditional_discharge_audit.json','statement_definition_judgment.md']},
    source_statement_hold=False,coverage='PROPOSED_REQUIRES_DISTINCT_REVIEWER'),indent=2))
