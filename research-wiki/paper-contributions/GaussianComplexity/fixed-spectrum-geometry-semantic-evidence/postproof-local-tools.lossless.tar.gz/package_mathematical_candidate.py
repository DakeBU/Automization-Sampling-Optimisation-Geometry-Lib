from pathlib import Path
import datetime, gzip, hashlib, json, subprocess, tarfile
P = Path('.astis/huanjian-gc-fixed-spectrum-geometry-20261109')
B = Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-geometry-semantic-evidence')
sha = lambda b: hashlib.sha256(b).hexdigest()
dump = lambda x: (json.dumps(x, ensure_ascii=False, indent=2)+'\n').encode()
assert subprocess.check_output(['git','rev-parse','HEAD'], text=True).strip() == '64497b461fb21c190f9c61bbd9a49db0894e1ad9'
assert not subprocess.check_output(['git','diff','--cached','--name-only']).strip()
old = json.loads((B/'admission-staging-readback.json').read_bytes())
old_wrapped = set(old['unsafe_or_ignored_raw_originals_not_staged_directly'])
checks = B/'postproof-actual-checks'; checks.mkdir()
receipts = []
for p in Path('.astis/huanjian-resume-20261103').glob('*.receipt.json'):
    r = json.loads(p.read_bytes())
    if r['head_before'] != '64497b461fb21c190f9c61bbd9a49db0894e1ad9': continue
    label = p.name
    if not ('-fixed-spectrum-geometry-' in label or '-geometry-local-' in label): continue
    receipts.append(p)
    raw = Path(r['log']).read_bytes()
    assert r['head_before'] == r['head_after'] and sha(raw) == r['log_sha256']
    (checks/p.name).write_bytes(p.read_bytes())
    z = checks/(Path(r['log']).name+'.gz')
    z.write_bytes(gzip.compress(raw,mtime=0)); assert gzip.decompress(z.read_bytes()) == raw
assert len(receipts) >= 13
tools = sorted(q for q in P.iterdir() if q.is_file() and q.suffix in ['.py','.lean','.gz'])
archive = B/'postproof-local-tools.lossless.tar.gz'
assert not archive.exists()
with tarfile.open(archive, 'w:gz') as t:
    for q in tools: t.add(q,arcname=str(q.relative_to(P)),recursive=False)
with tarfile.open(archive, 'r:gz') as t:
    assert len(t.getmembers()) == len(tools)
    for q in tools: assert t.extractfile(str(q.relative_to(P))).read() == q.read_bytes()
(B/'postproof-local-tools.manifest.json').write_bytes(dump({
    'archive':str(archive),'sha256':sha(archive.read_bytes()),'all_originals_retained':True,
    'files':[{'original':str(q),'member':str(q.relative_to(P)),'bytes':q.stat().st_size,'raw_sha256':sha(q.read_bytes())} for q in tools]}))
record = B/'mathematical-candidate-packaging.json'
record.write_bytes(dump({
    'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'normal_state':'PROVED_LOCAL', 'source_review':'pending',
    'actual_compiler_receipts_precede_this_candidate':True,
    'compiler_head':'64497b461fb21c190f9c61bbd9a49db0894e1ad9',
    'compiler_inputs':'Actual working-tree producer and Test pinned in local-proof-capsule.json; this later commit will first carry those exact Lean files. No retroactive build-at-candidate or sourceV claim.',
    'independent_blind_reconstruction':'blind-80a1c2/hash-manifest.json',
    'fresh_source_review_phase1':'separate independent actor in progress; no contents or verdict incorporated here',
    'publication_gate':'Expected rejection before independent source review is retained in postproof-actual-checks; local publication admission reviewed=False passed normally.',
    'new_shared_aggregation_or_site_runtime_or_remote_or_Goal_completion':False}))
tracked = set(subprocess.check_output(['git','ls-files','-z']).decode().split('\0'))
files = sorted(q for q in B.rglob('*') if q.is_file())
safe=[]; rows=[]; pack=B/'postproof-frozen-raw-packaging'; pack.mkdir()
for q in files:
    if str(q) in old_wrapped: continue
    if str(q) in tracked and subprocess.check_output(['git','show','HEAD:'+str(q)]) == q.read_bytes(): continue
    raw=q.read_bytes()
    ignored=subprocess.run(['git','check-ignore','-q','--',str(q)]).returncode == 0
    binary=q.suffix in ['.gz','.png','.zip'] or b'\0' in raw
    bad=not binary and (b'\r\n' in raw or raw.endswith(b'\n\n') or any(x.endswith((b' ',b'\t')) for x in raw.splitlines()))
    if ignored or bad:
        z=pack/(str(len(rows)).zfill(3)+'-'+q.name+'.gz')
        z.write_bytes(gzip.compress(raw,mtime=0)); assert gzip.decompress(z.read_bytes())==raw
        rows.append({'original_path':str(q),'raw_sha256':sha(raw),'raw_bytes':len(raw),'gzip_path':str(z),'gzip_sha256':sha(z.read_bytes()),'ignored':ignored,'raw_whitespace_or_blank_EOF':bad,'original_retained_unchanged':True})
        safe.append(z)
    else: safe.append(q)
mp=pack/'manifest.json'; mp.write_bytes(dump({'scope':'Frozen raw only, lossless; mutable records staged directly.','files':rows})); safe.append(mp)
mutable=[Path('research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-geometry.json'),
         Path('research-wiki/paper-contributions/GaussianComplexity/README.md'),Path('runs/substantive_advances.jsonl')]
math=[Path(x) for x in ['AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumGeometry.lean',
    'Tests/GaussianComplexityFixedSpectrumGeometry.lean','website/content/declaration_lessons/huanjian-fixed-spectrum-geometry.json',
    'website/content/publications/huanjian-fixed-spectrum-geometry.json','research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-geometry.json']]
safe=sorted(set(safe+mutable+math))
subprocess.run(['git','add','--',*map(str,safe)],check=True)
staged=subprocess.check_output(['git','diff','--cached','--name-only','-z']).decode().strip('\0').split('\0')
assert set(staged)==set(map(str,safe))
for name in staged: assert subprocess.check_output(['git','show',':'+name])==Path(name).read_bytes(),name
assert sha(math[0].read_bytes())=='d7edd1684006382e7e51ff717b5a9b82308181538ae824598961604dacea08d6'
assert sha(math[1].read_bytes())=='c6f90cc8ad43182a81e8b4343b28fff34e4fc81bc2e181d91002f3005a463b88'
subprocess.run(['git','diff','--cached','--check'],check=True)
print(json.dumps({'staged_paths':len(staged),'actual_receipts':len(receipts),'local_tool_originals':len(tools),'new_raw_wrappers':len(rows),'all_staged_bytes_equal_live':True,'sourceV':False}))
