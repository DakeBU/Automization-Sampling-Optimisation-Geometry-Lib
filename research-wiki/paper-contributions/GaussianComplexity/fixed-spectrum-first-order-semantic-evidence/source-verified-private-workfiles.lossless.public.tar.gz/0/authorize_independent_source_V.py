from pathlib import Path
import datetime, hashlib, json, subprocess
sha = lambda b: hashlib.sha256(b).hexdigest()
P = Path('.astis/semantic-neutral-20261108/src_4e8f6a/verification-transition-preparation')
m = P / 'preparation-manifest.json'
assert sha(m.read_bytes()) == 'b8621af58567edcf9579ff4b50fb970d5a8c1cdbdf9abc05ab319439e5a2471b'
manifest = json.loads(m.read_bytes()); assert len(manifest['artifacts']) == 18
for row in manifest['artifacts']:
    raw = (P / row['path']).read_bytes()
    assert len(raw) == row['bytes'] and sha(raw) == row['sha256']
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip() == manifest['checked_candidate_commit']
assert not subprocess.check_output(['git','diff','HEAD','--name-only'],text=True).strip()
old = json.loads((P / 'canonical-blind-audit.before.json').read_bytes())
new = json.loads((P / 'proposed-accepted-audit.json').read_bytes())
assert new['state'] == 'accepted' and old['state'] == 'blind-reconstructed'
assert new['source_review']['reviewer'] == '/root/source_reader_4e8f6a'
assert new['source_review']['phase3_manifest_sha256'] == '46fee361f6798fb8577c75479a563de2d30dbb2241059af624a29b3fbc4227a7'
assert new['source_review']['review_run_sha256'] == 'c7524efc49a5193ba912807ecd56c4b2669a65a7b3f04e7af7079ccb10c289e1'
assert all(new[k] == old[k] for k in ['id','source','lean','reconstruction','repairs','publication_binding_sha256','publication_context'])
assert new['publication_binding_sha256'] == '51d5a5e9390a0d66c2d5b72d042a042eec8d3d60433043ea3909bf9320ccb31e'
assert new['semantic_slots'] == json.loads(Path('.astis/semantic-neutral-20261108/src_4e8f6a/phase3/independent_source_semantic_verdict.json').read_bytes())['semantic_slots']
auth = json.loads((P / 'root-authorization.template.json').read_bytes())
assert auth['bindings'] == manifest['bindings']
auth['authorization'] = 'EXECUTE_ONCE_NORMAL_PROVED_LOCAL_TO_VERIFIED'
auth['authorized_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
auth['root_review'] = 'Root checked frozen independent Phase3, all134 payloads, all18 preparation payloads and full helper/common source. Only exact successor audit adoption + one normal API by actual independent actor; root creates no source verdict.'
auth['additional_raw_preservation_pins'] = {str(p):sha(p.read_bytes()) for p in map(Path,[
    'website/content/graph_memory_index.json','website/content/functor_hypergraph.json',
    'research-wiki/paper-contributions/GaussianComplexity/README.md','lake-manifest.json','lean-toolchain',
    'AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumFirstOrder.lean',
    'Tests/GaussianComplexityFixedSpectrumFirstOrder.lean'])}
auth['preparation_note'] = 'This is the separate exact root authorization. Execution remains by independent /root/source_reader_4e8f6a, not the proving root. No second API call after completion or automatic rollback.'
out = P / 'root-authorization.json'; assert not out.exists()
out.write_text(json.dumps(auth,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'authorization_path':str(out),'sha256':sha(out.read_bytes()),
    'actual_independent_actor_to_execute':'/root/source_reader_4e8f6a',
    'source_verdict_created_by_root':False,'API_called_by_root':False}))
