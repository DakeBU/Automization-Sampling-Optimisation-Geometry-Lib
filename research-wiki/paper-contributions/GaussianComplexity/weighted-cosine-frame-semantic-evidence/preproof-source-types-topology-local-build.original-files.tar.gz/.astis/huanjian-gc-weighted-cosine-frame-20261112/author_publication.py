"""Author exact formula exposition and export only anonymous types to the decoder."""
from pathlib import Path
import hashlib
import json
import sys

sys.dont_write_bytecode = True
sys.path.insert(0, 'tools')
import astis_publication as publication
import astis_semantic_roundtrip as semantic

workspace = Path(__file__).resolve().parent.relative_to(Path.cwd())
paper = Path('research-wiki/paper-contributions/GaussianComplexity')
evidence = paper / 'weighted-cosine-frame-semantic-evidence'
cell_path = Path('research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-weighted-cosine-frame.json')
runner = Path('.astis/huanjian-resume-20261103')
sha = lambda b: hashlib.sha256(b.encode() if isinstance(b, str) else b).hexdigest()


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x') as out:
        json.dump(value, out, ensure_ascii=False, indent=2)
        out.write('\n')


def receipt(stem):
    path = runner / (stem + '.receipt.json')
    obj = json.loads(path.read_bytes())
    log = Path(obj['log']).read_bytes()
    assert obj['exit_code'] == 0 and sha(log) == obj['log_sha256']
    return {'path': str(path), 'sha256': sha(path.read_bytes()), 'log_sha256': sha(log)}, log.decode()


seal = json.loads((workspace / 'statement-seal-v1.json').read_bytes())
P, T = [Path(seal[k]['planned_file']) for k in ('producer', 'actual_private_consumer')]
p_text, t_text = P.read_text(), T.read_text()
name = seal['producer']['name']
private_name = '_private.Tests.GaussianComplexityFixedSpectrumWeightedFrameBound.0.' + seal['actual_private_consumer']['name']
for key, text in [('producer', p_text), ('actual_private_consumer', t_text)]:
    short = seal[key]['name'].split('.')[-1]
    literal = text.split('theorem ' + short, 1)[1].split(' := by', 1)[0].lstrip() + '\n'
    assert literal == seal[key]['signature']
build, _ = receipt('20261112T042028260302Z-weighted-cosine-frame-final-clean-build')
kernel, log = receipt('20261112T042047188336Z-weighted-cosine-frame-exact-literal-kernel-and-parents')
frame_parent = seal['shared_floor_audit']['existing_canonical']
moment_parent = seal['shared_floor_audit']['existing_fourth_matrix_parent']
parents = {name: [frame_parent], private_name: [name, moment_parent]}
for target, required in parents.items():
    assert 'ACTUAL_SEALED_LITERAL_KERNEL_TYPE_APPLICATION_PASS ' + target in log
    start = log.index('ACTUAL_PUBLIC_ASTIS_PARENTS ' + target + ': [')
    stop = log.index(']', start)
    assert all(item in log[start:stop] for item in required)
assert 'ALL_OWNED_DECLARATIONS_KERNEL_INSPECTED 5' in log

title = 'A weighted cosine-frame bound and its Gaussian second-moment sum'
statement = r'The weighted cosine coefficient is bounded by \(\frac{2r(r+2)}d I_{r^2}\). The truncated Gaussian row templates satisfy the same bound after summing their marginal second moments.'
formula = (
    r'\begin{aligned}B_{\rm coeff}&:=\frac{r+2}{d^2}\sum_{i=1}^d\|t_i\|^2(I_r\otimes t_it_i^\top),\\'
    r'B_{\rm coeff}&\preceq \frac{2r(r+2)}d I_{r^2}.\end{aligned}'
)
square_formula = (
    r'\begin{aligned}Y_i(Z)&=\frac1d(ZZ^\top\otimes t_it_i^\top)\mathbf1_{\{R\le L\}},\\'
    r'Y_i(Z)^2&=\frac{R\|t_i\|^2}{d^2}(ZZ^\top\otimes t_it_i^\top)\mathbf1_{\{R\le L\}}.\end{aligned}'
)
sum_formula = (
    r'\begin{aligned}\sum_{i=1}^d\int Y_i(Z)^2\,d\gamma_r(Z)'
    r'&\preceq B_{\rm coeff}\\&\preceq\frac{2r(r+2)}d I_{r^2}.\end{aligned}'
)
assumptions = [
    r'Let \(d,q\in\mathbb N\), \(2q+1<d\), and \(r=q+1\). Thus \(d\ge2\), \(r\ge1\), and \(q=0\) is included.',
    r'For source rows \(i=1,\ldots,d\), put \(\theta_i=(i-\tfrac12)\pi/d\), \(t_i[0]=1\), and \(t_i[k]=\sqrt2\cos(k\theta_i)\) for \(1\le k\le q\). Lean uses source index \(i.val+1\).',
    r'Write \(S_i=\|t_i\|^2=\sum_{k=0}^q t_i[k]^2\) and \(F_i=t_it_i^\top\). All matrices are real, and paired tensor indices put the Gaussian/identity coordinate first and the feature coordinate second.',
    r'For the consumer only, \(Z\) has the canonical standard Gaussian probability law \(\gamma_r=N(0,I_r)\) on real Euclidean space, \(R=\|Z\|^2\), and \(L=2r+3\log(1000d)\). The cutoff is the closed event \(R\le L\).',
    r'The square is ordinary matrix multiplication. Every \(Y_i^2\) is proved Bochner integrable in the Euclidean operator norm. Each integral is a marginal expectation against \(\gamma_r\), with no retained-mass normalization.',
    r'The order \(\preceq\) means that the upper-minus-lower matrix is positive semidefinite. No Gram, norm, moment, integrability or order certificate is an extra hypothesis.',
]
boundary = (
    'This local result gives the deterministic weighted coefficient and the integrable canonical marginal second-moment sum. '
    'The same dummy integration variable in separate marginal integrals does not identify the original row family. '
    'Original-family row maps, marginal-law and expectation adapters, joint independence, centered variance, '
    'variance operator norms, Bernstein, Fact C.6 and full Lemma 4.4 remain open. '
    'Both main lower bounds, exact oracle/TV/precision/cost adapters, serialized integration, full desktop/mobile '
    'source-index/graph delivery and purification remain open.'
)
source = {
    'url': 'https://arxiv.org/html/2610.20492v1#A3.EGx11',
    'edition': 'arXiv:2610.20492v1; pinned HTML SHA256 ' + seal['source']['raw_sha256'],
    'anchor': 'Appendix C.2 EGx11 (Ex115–Ex117), with Ex113–Ex114, p14.3, Fact C.5, exact p1/p10 definitions and standing 2q+1<d',
    'wording_status': 'faithful paraphrase',
    'attribution': 'On Complexity of Gaussian Sampling, arXiv:2610.20492v1.',
    'scope': 'Deterministic coefficient comparison and canonical marginal realization of the uncentered second-moment sum.',
}
mathlib = [
    'Matrix.posSemidef_vecMulVec_self_star', 'Matrix.PosSemidef.kronecker',
    'Matrix.PosSemidef.smul', 'Matrix.posSemidef_sum', 'Matrix.kroneckerBilinear',
    'Matrix.one_kronecker_one', 'Matrix.sum_apply', 'Matrix.vecMulVec_mul_vecMulVec',
    'Matrix.mul_kronecker_mul', 'EuclideanSpace.real_norm_sq_eq',
    'ContinuousLinearMap.integrable_comp', 'ContinuousLinearMap.integral_comp_comm',
    'MeasureTheory.Integrable.indicator', 'MeasureTheory.integrable_finsetSum',
    'MeasureTheory.integral_finsetSum', 'MeasureTheory.integral_sub',
    'Matrix.posSemidef_iff_dotProduct_mulVec', 'Convex.integral_mem',
]


def code(text, first, last):
    return ''.join(text.splitlines(keepends=True)[first - 1:last])


steps = [
    {'title': 'Reuse the exact cosine frame',
     'text': 'The existing canonical frame theorem supplies both the feature squared-length bound and the Gram identity. Rewrite the Gram entries as a finite sum of outer products, then tensor by the identity to obtain the paired-coordinate identity. The signed high-frequency Gram conclusion is unused in this estimate.',
     'formula': r'S_i\le2r,\qquad\sum_iF_i=dI_r,\qquad\sum_i(I_r\otimes F_i)=dI_{r^2}.',
     'lean': code(p_text, 40, 61)},
    {'title': 'Expose a nonnegative weighted residual',
     'text': 'Each identity-tensored feature outer product is PSD. The norm bound makes every residual weight nonnegative. Sum these PSD matrices and multiply by the nonnegative exact scalar. The standing range gives the nonzero denominator needed for the final normalization.',
     'formula': r'\frac{2r(r+2)}d I_{r^2}-B_{\rm coeff}=\frac{r+2}{d^2}\sum_i(2r-S_i)(I_r\otimes F_i)\succeq0.',
     'lean': code(p_text, 62, 88)},
    {'title': 'Use the canonical fourth matrix moment',
     'text': 'Set up the actual Gaussian row templates and fixed continuous linear tensor maps. The existing radial fourth matrix theorem supplies integrability of RZZ transpose and its exact mean. Its integrability is transported to each untruncated square template W_i. This fold includes the complete private statement and setup.',
     'formula': r'\mathbb E_{\gamma_r}[RZZ^\top]=(r+2)I_r,\qquad W_i(Z)=\frac{S_i}{d^2}(RZZ^\top\otimes F_i).',
     'lean': code(t_text, 1, 70)},
    {'title': 'Square the truncated templates exactly',
     'text': 'Use the two rank-one square identities, Kronecker multiplication and indicator idempotence. Thus Y_i squared is the closed-event indicator times W_i. The event is measurable and W_i is integrable, giving integrability of every actual square. Each W_i is a nonnegative multiple of the tensor vector outer product and is PSD.',
     'formula': square_formula,
     'lean': code(t_text, 71, 118)},
    {'title': 'Integrate the aggregate PSD residual',
     'text': 'At every row and point, W_i minus Y_i squared is either zero or W_i. Sum these PSD residuals. Both finite sums are integrable. Prove that the finite-dimensional real PSD cone is closed and convex, then integrate the aggregate residual inside that cone.',
     'formula': r'0\preceq\int\Bigl(\sum_iW_i-\sum_iY_i^2\Bigr)\,d\gamma_r.',
     'lean': code(t_text, 120, 152)},
    {'title': 'Evaluate the sum and apply the deterministic producer',
     'text': 'Transport the exact radial fourth mean through each fixed tensor map and commute the finite sum with integration. This gives the aggregate upper matrix B_coeff. Add its integrated PSD residual to the deterministic producer residual. At q=0 the feature is one-dimensional and the bound remains the valid source value 6/d.',
     'formula': sum_formula,
     'lean': code(t_text, 153, 181)},
]
unit = {
    'kind': 'theorem', 'reading_layout': 'progressive', 'declaration': name, 'title': title,
    'reader_note': 'Open the assumptions and source steps for the exact objects and adjacent Lean.',
    'statement': statement, 'formula': formula, 'assumptions': assumptions, 'steps': steps,
    'astis_dependencies': [frame_parent], 'mathlib_dependencies': mathlib,
    'dependency_notes': 'The producer reuses the same compiled cosine-frame node for Gram and norm conclusions. The private aggregate consumer uses this producer and the canonical radial fourth matrix moment, including its integrability. No new feature-norm theorem or public copy of an individual bound is introduced.',
    'lean_statement': 'The exact weighted identity-tensored cosine coefficient has the source PSD upper bound.',
    'lean_proof': 'Reuse Gram and norm bounds, sum nonnegative PSD residuals, tensor and normalize. The actual private consumer integrates an aggregate PSD residual and uses the canonical fourth moment.',
    'boundary': boundary,
    'sources': [{**source, 'label': 'Appendix C.2 uncentered second-moment comparison'},
                {'path': str(T), 'line': 14, 'label': 'Complete private marginal second-moment sum proof',
                 'scope': 'Every squared summand is integrable and their canonical marginal expectations have the source PSD bound.'}],
    'tests': ['lake build Tests.GaussianComplexityFixedSpectrumWeightedFrameBound'],
}
slug = 'huanjian-gaussian-weighted-cosine-frame'
audit_id = 'ASTIS-RT-20261112-HuanjianGaussianWeightedCosineFrame'
lesson_path = Path('website/content/declaration_lessons') / (slug + '.json')
pub_path = Path('website/content/publications') / (slug + '.json')
audit_path = Path('research-wiki/semantic-roundtrip/audits') / (slug + '.json')
write(lesson_path, {'schema_version': 1, 'units': [unit]})
binding = {
    'declaration': name, 'cell': cell_path.stem, 'role': 'proof-edge',
    'supports': ['c2-weighted-coefficient-and-marginal-sum'], 'boundary': boundary, 'audit_id': audit_id,
    'assumption_deltas': [
        {'source': 'Exact half-grid features, r=q+1 and standing 2q+1<d.',
         'lean': 'Literal zero-based midpoint grid and features, q natural and q=0 retained.',
         'classification': 'same', 'reason': 'The index shift is source row i.val+1. All norm and Gram estimates are internal compiled dependencies.'},
        {'source': 'The middle and final comparisons in EGx11 are deterministic consequences of the feature norm and Gram identities.',
         'lean': 'A separate deterministic PSD coefficient theorem, with no Gaussian-law or moment binder.',
         'classification': 'same', 'reason': 'The scalar r+2 is a literal coefficient in this comparison. Local B denotes B_coeff, not the source rectangular random matrix.'},
        {'source': 'EGx11 sums expectations on the original Gaussian row family.',
         'lean': 'The private consumer sums integrals of literal row templates against canonical stdGaussian and proves each square integrable.',
         'classification': 'source-implicit', 'reason': 'This is the explicit canonical marginal realization. Original-family row maps, marginal laws and expectation transport remain open and are not inferred from a repeated dummy integration variable.'},
    ],
}
item = {
    'id': slug, 'library': 'samplewiki', 'chapter': 'gaussian-sampling-complexity',
    'chapter_path': 'example-cases/samplewiki/companions/gaussian-sampling-complexity.html',
    'title': title, 'source': source, 'statement': statement,
    'formulae': [{'label': 'Deterministic weighted coefficient', 'tex': formula},
                 {'label': 'Actual ordinary square', 'tex': square_formula},
                 {'label': 'Canonical marginal second-moment sum', 'tex': sum_formula}],
    'assumptions': assumptions,
    'obligations': [{'id': 'c2-weighted-coefficient-and-marginal-sum', 'label': 'EGx11 weighted coefficient with an actual integrable marginal-sum consumer.'}],
    'bindings': [binding],
}
write(pub_path, {'schema_version': 1, 'items': [item]})
binders, conclusion = seal['producer']['signature'].split(' :\n', 1)
literal = '∀ ' + binders + ',\n' + conclusion
source_text = (
    'For natural d and q with 2q+1<d, let r=q+1, theta_i=(i-1/2)pi/d for i=1,...,d, '
    'and t_i=(1,sqrt(2)cos(theta_i),...,sqrt(2)cos(q theta_i)). '
    'The deterministic weighted coefficient ((r+2)/d^2) sum_i ||t_i||^2 (I_r tensor t_i t_i^T) '
    'is at most (2r(r+2)/d) I_(r^2) in positive-semidefinite order. '
    'The source uses ||t_i||^2<=2r and sum_i t_i t_i^T=d I_r.'
)
audit = {
    'id': audit_id, 'state': 'draft',
    'source': {'source_id': 'arxiv2610.20492v1-c2-weighted-cosine-coefficient',
               'url': source['url'], 'anchor': source['anchor'], 'original_text': source_text,
               'text_sha256': sha(source_text), 'source_snapshot_sha256': seal['source']['raw_sha256']},
    'lean': {'declaration': name, 'file': str(P), 'statement': literal, 'statement_sha256': sha(literal),
             'formalizer': 'huanjian_gc_20261112_weighted_cosine_frame', 'compiled': True,
             'decoder_context': [
                 'Fin n has exactly the natural-number indices with value less than n. Every indicated finite sum runs over the entire finite carrier. The coercion from natural numbers to real numbers has its usual meaning.',
                 'Matrix m n real is a finite real array. Matrix.vecMulVec w v has entry w_i v_j. Matrix.one is the diagonal identity. Scalars multiply each entry. Matrix.kronecker A B has paired-index entry A_(i,j) B_(k,l), with the first index of each pair belonging to A.',
                 'Matrix.PosSemidef A requires Hermitian symmetry and nonnegative real quadratic forms for every vector, equivalently positive-semidefinite order. Matrix subtraction and scalar multiplication are ordinary real matrix operations.',
             ]},
    'reconstruction': {}, 'semantic_slots': {}, 'deltas': [], 'verdict': 'pending',
    'source_review': {'state': 'pending'}, 'repairs': [],
}
publication.inputs.cache_clear()
publication.load.cache_clear()
audit['publication_binding_sha256'] = publication.binding_digest(item, binding)
audit['publication_context'] = publication.review_context(item, binding)
write(audit_path, audit)
cell = json.loads(cell_path.read_bytes())
cell['parents'] = [frame_parent, moment_parent]
cell['evidence']['actual_compilation'] = build
cell['evidence']['actual_kernel'] = kernel
cell['evidence']['actual_public_ASTIS_parents'] = parents
cell['evidence'].pop('target_proof_calls', None)
cell['reuse_plan']['reused_declarations'] = [frame_parent, moment_parent, *mathlib]
cell['reuse_plan']['known_consumers'] = [private_name]
for key in ['source_ordered', 'source_statement_adjacent', 'natural_language_formula_proof',
            'hidden_assumptions_visible', 'lean_collapsed', 'external_dependencies_visible']:
    cell['reader_contract'][key] = True
cell['reader_contract']['status'] = 'Six adjacent source-ordered Lean folds, including the complete private aggregate proof. Independent source and native/static reader acceptance pending.'
cell_path.write_text(json.dumps(cell, ensure_ascii=False, indent=2) + '\n')
publication.check_advance([name], reviewed=False)
packet = semantic.decoder_packet(audit)
neutral = Path('.astis/semantic-neutral-20261112/wf_decode_3be7/input.json')
write(neutral, packet)
write(evidence / 'decoder-input.json', packet)
record = {
    'producer_sha256': sha(P.read_bytes()), 'private_consumer_sha256': sha(T.read_bytes()),
    'build': build, 'kernel': kernel, 'actual_public_ASTIS_parents': parents,
    'both_exact_literal_types_kernel_applied': True, 'raw_Expr_structural_equality': False,
    'owned_theorems': 5, 'handwritten': 2, 'generated_internal': 3,
    'publication_binding_sha256': audit['publication_binding_sha256'],
    'neutral_input': str(neutral), 'neutral_input_raw_sha256': sha(neutral.read_bytes()),
    'neutral_canonical_packet_sha256': packet['packet_sha256'], 'anonymous_statement_sha256': sha(literal),
    'step_code_sha256': [sha(step['lean']) for step in steps], 'source_review': 'pending',
}
write(evidence / 'publication-draft-record.json', record)
print(json.dumps(record))
