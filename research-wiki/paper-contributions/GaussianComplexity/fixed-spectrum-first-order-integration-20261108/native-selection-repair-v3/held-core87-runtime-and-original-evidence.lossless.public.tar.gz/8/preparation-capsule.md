# Original-verifier mechanical park preparation only

Current immutable core87 and accepted sourceV audit148 are pinned, with original
source verifier /root/source_reader_4e8f6a, checked source commit9d306d, first
sourceV-carrying commitf45ba48, original V306 append and sole root STAB621 append.
No new source verdict is needed, created or authorized by this preparation.

The helper copies the original V306 evidence directly from its exact raw event;
all existing key/value pairs are asserted equal. It adds only
post_integration_normalpark after actual external acceptance inputs pass. In
particular it does not replace verified_commit9d, source audit, verifier, gate,
fake-closure evidence, publication binding, proofowner or STATIC source scope.

Baseline protection covers285 SAUs/284 exact foreign states,444 frontier JSON
artifacts (443foreign plus own), discovery,40 explicit critical raw pins and416
frozen source/review/preparation/execution originals. HEAD/index and clean tracked
diff protect all tracked source/config/models/README without a125k-path sweep.
Current STAB owner is checked. Future actual tracked diff may be only the ledger.
The original sourceV and STAB event byte prefix must remain exact, plus one API
append. Any failure stops without a second API or automatic rollback.

Missing external inputs are typed in acceptance-contract.md. They include actual
bound context review, actual successful v3 browser report/foreground receipt,
38original PNGs and independent all38 pixel review, local acceptance and parking
eligibility. The helper validates hashes, actual report/log linkage and all38
original-image review entries, rather than inventing or viewing any screenshot.
Actual typed artifacts and separate exact future root authorization are required.

An actual read-only negative preflight using the missing template returned3,
FAIL_CLOSED_EXTERNAL_ACCEPTANCE_NOT_READY, with API=false and no canonical
mutation. Its raw log/receipt are preserved. No browser/escalation/commit/API was
performed. No future accepted artifact or filled evidence is fabricated here.
