from pathlib import Path
import difflib, hashlib, json
W = Path(__file__).parent
old = W/'reader-step-neighbor-proposal-v4/proposed/website/scripts/declaration_lessons.py'
D = W/'reader-step-neighbor-proposal-v5'
assert not D.exists()
sha = lambda b: hashlib.sha256(b).hexdigest()
assert sha(old.read_bytes()) == '01e205b8e16fe54ed32be93ac57b0ef42e3fcdccee84e3f878a8e34d6a03e93b'
production = Path('website/scripts/declaration_lessons.py')
assert sha(production.read_bytes()) == 'b22394faeb8de07109826174d05856f4a561b20f9301e1f1d031b466fd6f2596'
text = old.read_text()
needle = "source_lines[raw] = path.read_text(encoding='utf-8').splitlines()"
assert text.count(needle) == 1
replacement = "literal = path.read_bytes().decode('utf-8')\n                source_lines[raw] = literal.split('\\n')\n                if source_lines[raw][-1] == '':\n                    source_lines[raw].pop()"
text = text.replace(needle, replacement)
compile(text, '<disabled-reader-v5>', 'exec')
dest = D/'proposed/website/scripts/declaration_lessons.py'
dest.parent.mkdir(parents=True)
dest.write_text(text)
patch = ''.join(difflib.unified_diff(production.read_text().splitlines(keepends=True), text.splitlines(keepends=True), fromfile='a/website/scripts/declaration_lessons.py', tofile='b/website/scripts/declaration_lessons.py'))
(D/'reader-step-neighbor.patch').write_text(patch)
record = {'production_file': str(production), 'production_sha256': sha(production.read_bytes()),
          'prior_v4_proposed_sha256': sha(old.read_bytes()), 'proposed_file': str(dest),
          'proposed_sha256': sha(dest.read_bytes()), 'patch_sha256': sha(patch.encode()),
          'repair': 'Unify matching and exported source anchors on literal LF only. Decode exact UTF8 bytes without universal-newline conversion; Unicode separators and CR do not create extra line anchors. A terminal LF belongs to the preceding line, with no extra empty terminal anchor. Original raw downloads remain byte-identical.',
          'scope': 'DISABLED prospective renderer-only successor. All earlier freezes/HOLDs and real Unicode counterexample retained. No canonical mathematics/lesson/audit/binding change or production/browser/site/global/HOLD release.'}
(D/'proposal.json').write_text(json.dumps(record, indent=2)+'\n')
for p in [dest, D/'reader-step-neighbor.patch', D/'proposal.json']:
    p.chmod(0o444)
print(json.dumps(record))
