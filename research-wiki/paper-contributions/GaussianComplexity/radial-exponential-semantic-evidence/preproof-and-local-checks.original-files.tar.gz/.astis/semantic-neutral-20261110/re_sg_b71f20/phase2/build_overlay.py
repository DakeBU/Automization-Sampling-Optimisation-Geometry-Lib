from pathlib import Path
import json,hashlib,datetime,sys
BASE=Path(__file__).resolve().parent
PACK=BASE/'inputs'/'selective-type-definition-packet.json'
b=PACK.read_bytes();s=b.decode('utf-8');p=json.loads(s)
def sha(b):return hashlib.sha256(b).hexdigest()
assert sha(b)=='44cecb47245a0d1ab06d634f8b1dcd408c8368437e37cea1f0bde46fc2669ae3'
assert len(p['minimal_definition_context']['definitions'])==11
def anchor(v):
    lit=json.dumps(v,ensure_ascii=False)
    i=s.index(lit);j=i+len(lit)
    assert s.count(lit)==1
    return {'packet_char_halfopen':[i,j],'packet_utf8_halfopen':[len(s[:i].encode()),len(s[:j].encode())],'packet_lf_line':s.count('\n',0,i)+1,'raw_json_string_sha256':sha(s[i:j].encode()),'decoded_literal_sha256':sha(v.encode()),'decoded_literal_bytes':len(v.encode()),'decoded_literal_characters':len(v),'offset_note':'Offsets delimit the original JSON string including quote and escape bytes. Decoded literal preserves terminal LF.'}
type_rows={}
for k in ['producer','private_consumer']:
    q=p[k];a=anchor(q['signature']);assert a['decoded_literal_sha256']==q['signature_sha256']
    type_rows[k]={'name':q['name'],'planned_file_as_given_not_opened':q['planned_file'],'literal_signature':q['signature'],'literal_anchor':a,'status':'literal packet statement; no elaboration/proof/implementation evidence'}
defs_notes={
'ProbabilityTheory.stdGaussian':('literal measure construction','Product of actual gaussianReal 0 1 coordinates via finite-rank orthonormal synthesis; no arbitrary μ or law certificate. Gaussian normalization, product probability, measurability, basis invariance and source Euclidean law identification remain background edges.',['row-definition-law','moment-one-third']),
'MeasureTheory.Integrable':('literal analytic predicate, returned conclusion','AEStronglyMeasurable ∧ HasFiniteIntegral; neither is a producer or consumer premise.',['basic-regularity-gap','moment-one-third']),
'MeasureTheory.HasFiniteIntegral':('literal nonnegative integral finiteness predicate','ENNReal norm lintegral <∞. The exponential is nonnegative; Gaussian integration supplies finite value.',['gaussian-density-scaling-gap','gaussian-product-gap']),
'MeasureTheory.integral':('literal Bochner integral with totalization','Complete codomain ℝ and the explicitly returned Integrable proposition justify the expectation interpretation. No default-zero branch is the source quantity.',['moment-one-third']),
'Real.rpow':('literal real-power operator','Real part of complex power; with base3>0 agrees with exp(exponent·log3), an unproved background identity. Exponent is real finrank/2, with r=1→√3, r=0→1.',['moment-one-third','log-three-comparison']),
'Module.finrank':('literal natural finite rank','Cardinal.toNat(Module.rank ℝ E). FiniteDimensional avoids an infinite rank convention and permits genuine dimension0. For the source EuclideanSpace Fin(q+1), identify rank=q+1 by a separate dimension bridge.',['standing-parameters','moment-one-third']),
'FiniteDimensional':('literal typeclass abbreviation; TYPING','Module.Finite ℝ E, finitely generated real carrier. No analytic probability hypothesis is hidden in this finite-dimensional typing.',['standing-parameters']),
'BorelSpace':('literal typeclass field; TYPING','measurable_eq requires exactly the Borel sigma algebra. This carries the canonical measure/continuity domain, not a separate data regularity estimate.',['basic-regularity-gap','row-definition-law']),
'ENNReal.ofReal':('literal real-to-ENNReal conversion','r.toNNReal embedded in nonnegative extended reals. hq makes d≥2 and the inverse positive and finite, so no clipping changes the source reciprocal.',['tail-at-L','log-substitution-gap']),
'EuclideanSpace':('literal carrier abbreviation','PiLp 2 of functions on Fin(q+1); intended actual L2 norm, not an unwrapped function norm. Dimension and norm-square identities remain explicit background bridges.',['row-definition-law','R-definition']),
'PiLp':('literal norm-wrapper abbreviation','WithLp p (∀ i, α i), instantiated p=2. The WithLp norm identity is not another supplied literal; it must be justified as a background edge.',['R-definition'])}
definitions=[]
for d in p['minimal_definition_context']['definitions']:
    val=d['literalLF'];a=anchor(val);assert a['decoded_literal_sha256']==d['literal_sha256']
    assert d['character_span_0based_halfopen'][1]-d['character_span_0based_halfopen'][0]==len(val)
    assert d['utf8_byte_span_0based_halfopen'][1]-d['utf8_byte_span_0based_halfopen'][0]==len(val.encode())
    assert d['lf_lines_1based_inclusive'][1]-d['lf_lines_1based_inclusive'][0]+1==len(val.splitlines())
    kind,note,src=defs_notes[d['name']]
    definitions.append({'id':d['name'],'disposition':'NODE','literal':val,'literal_anchor':a,'meaning_class':kind,'meaning_audit':note,'source_graph_references':src,'provided_origin':{k:d[k] for k in ['file','wholefile_raw_sha256','character_span_0based_halfopen','utf8_byte_span_0based_halfopen','lf_lines_1based_inclusive']},'origin_limit':'Original-file locations and whole-file hashes are packet provenance only; those files were not opened or independently hashed.'})
assert len(definitions)==len(defs_notes)
binders=[
('producer','universe of Type*','TYPING','Implicit universe-polymorphic carrier; broader than concrete source ℝ^r.'),
('producer','{E : Type*}','TYPING','Arbitrary carrier of finite-dimensional real Euclidean geometry; source specialization is E=EuclideanSpace ℝ (Fin r).'),
('producer','[NormedAddCommGroup E]','TYPING','Additive normed carrier, supplying the norm used by the exponential.'),
('producer','[InnerProductSpace ℝ E]','TYPING','Real inner-product structure compatible with the norm; orthonormal transport is an unproved proof edge.'),
('producer','[FiniteDimensional ℝ E]','TYPING','Finite-dimensional carrier; expands to Module.Finite, no dimension positivity or moment premise.'),
('producer','[MeasurableSpace E]','TYPING','Measure carrier; compatible Borel structure follows from BorelSpace field.'),
('producer','[BorelSpace E]','TYPING','Literal measurable_eq field fixes the Borel measurable structure; no analytic estimate.'),
('private_consumer','{d : ℕ}','TYPING','Finite ambient dimension index; positivity d≥2 obtained from hq.'),
('private_consumer','{q : ℕ}','TYPING','Nonnegative integer query parameter, including q=0.'),
('private_consumer','(hq : 2 * q + 1 < d)','STANDING','Inherited source range for the unnamed C.6 scalar p10 estimate from Lemma4.4. It would be SOURCE when classifying the full Lemma4.4 itself; that is outside this target scope.')]
binder_rows=[{'target':t,'binder':x,'classification':cl,'reason':why,'disposition':'NODE','type_anchor':type_rows[t]['literal_anchor']} for t,x,cl,why in binders]
type_items=[
('producer','P-law','stdGaussian E', 'Actual fixed law, not a binder', ['row-definition-law']),
('producer','P-observable','x↦exp(‖x‖²/3)', 'Fixed squared-norm exponential with exponent coefficient1/3', ['R-definition','moment-one-third']),
('producer','P-integrability','Integrable f (stdGaussian E)', 'Conjunctive conclusion; measure and regularity proof ingredients remain edges', ['basic-regularity-gap','moment-one-third']),
('producer','P-moment','real integral = (3:ℝ)^((finrank ℝ E:ℝ)/2)', 'Conjunctive conclusion; source specialization requires Euclidean rank and law bridges; exponent division in ℝ', ['moment-one-third']),
('producer','P-extension','universe-polymorphic finite E, including dimension0', 'Canonical library generalization, not literal paper quantifier; empty product branch is extra unproved obligation', ['standing-parameters','moment-one-third']),
('private_consumer','T-E','let E := EuclideanSpace ℝ (Fin(q+1))','Literal source row carrier, q=0 has r=1; does not admit r=0', ['standing-parameters','row-definition-law']),
('private_consumer','T-mu','let μ := stdGaussian E','Actual marginal row law canonical model; equality in law to any source row is a background transport, not a binder', ['row-definition-law']),
('private_consumer','T-L','let L := 2*((q+1:ℕ):ℝ)+3*Real.log(1000*(d:ℝ))','Literal exact threshold; hq supplies positive log argument and d≥2', ['L-definition']),
('private_consumer','T-event','{x:E | L<‖x‖²}','Strict source event R>L; unscaled actual Euclidean norm square', ['R-definition','tail-at-L']),
('private_consumer','T-bound','μ(event)≤ENNReal.ofReal((1000*(d:ℝ))⁻¹)','Exact source one-row reciprocal bound embedded in ENNReal; hq internally discharges positivity', ['tail-at-L'])]
item_rows=[{'target':t,'id':i,'literal_component':v,'meaning':why,'source_graph_references':src,'disposition':'NODE','type_anchor':type_rows[t]['literal_anchor']} for t,i,v,why,src in type_items]
gaps=[
('bridge-canonical-law','stdGaussian E as measurable orthonormal pushforward of independent variance-one coordinate Gaussians; probability normalization, isotropy, source-row equality in law, and the generic orthonormal synthesis identity ‖Σ_i x_i•e_i‖²=Σ_i x_i².',['row-definition-law','R-definition','gaussian-product-gap']),
('bridge-euclidean-norm-rank','On EuclideanSpace ℝ (Fin(q+1)), finrank=q+1 and ‖x‖²=Σ_a x_a². Norm is PiLp2; no default function norm.',['standing-parameters','R-definition']),
('bridge-regularity','Borel/strong measurability of norm-square/exponential; finite exponential norm lintegral derived, not assumed.',['basic-regularity-gap','moment-one-third']),
('bridge-rpow','For base3>0 use positive real rpow = exp(log3·exponent) and real casts/algebra.',['moment-one-third','log-three-comparison']),
('bridge-zero-dimension','Empty Fin0 product probability maps to0, hence Dirac0 and integral of constant1; finite integrability and3^0=1. Producer-only case.',['standing-parameters']),
('bridge-markov-measure','Translate strict exponential Markov step into measure/ENNReal syntax; exp monotone, positive threshold and derived integrability.',['markov-reuse','single-row-tail']),
('bridge-log-and-bound','hq implies d≥2; x=log(1000d)≥0; log3/2<2/3; exp(−log(1000d))=(1000d)⁻¹>0. ofReal preserves positive finite source probability bound.',['standing-parameters','log-three-comparison','log-substitution-gap','tail-at-L'])]
gap_rows=[{'id':i,'kind':'UNPROVED_BACKGROUND_BRIDGE','meaning':v,'source_graph_references':src} for i,v,src in gaps]
graph={
'artifact_role':'Post-freeze source-to-literal-type overlay; separate from Source Proof Graph and any compiler DAG',
'phase1_binding':{'graph_path':'../phase1/source-graph.json','graph_sha256':'5cfcf774e44a2ca4a6f3656a30034a6f0bda1ccc04ce3d3fd40788e786bbfc57','mathematics_sha256':'e7f7f55a65a11b02ada01efc93f7c7046f0420511e2339a128497496c01bafac','manifest_sha256':'767ea1466ab8aded220b5324a23627cfc3209898f76b09657b489b611015f06c','source_graph_bytes_modified':False},
'selective_packet_sha256':sha(b),'literal_targets':type_rows,'binders':binder_rows,'typed_components':item_rows,'literal_definitions':definitions,'background_bridges':gap_rows,
'source_type_correspondences':[
{'literal_target':'producer','source_nodes':['moment-one-third','R-definition','row-definition-law','basic-regularity-gap'],'relation':'Specialize generalized carrier and actual standard Gaussian measure to positive row dimension r=q+1; finite integrability is the source implicit background now returned explicitly. Generic universe/E and dim0 are additional canonical-library scope, not source claims.'},
{'literal_target':'private_consumer','source_nodes':['tail-at-L','L-definition','R-definition','standing-parameters','row-definition-law'],'relation':'Exact canonical-marginal counterpart of single-row strict L-tail; fixed actual law, actual squared norm, exact constants. Not a joint-row event, expectation-bias, or full C.6 theorem.'}],
'planned_mathematical_routes':[
{'id':'P-positive-density','guard':'finrank ℝ E>0','premises':['bridge-canonical-law','bridge-regularity','bridge-rpow','source:gaussian-density-scaling-gap'],'conclusion':'producer restricted to this case','route_relation':'OR with P-positive-product; unproved'},
{'id':'P-positive-product','guard':'finrank ℝ E>0','premises':['bridge-canonical-law','bridge-regularity','bridge-rpow','source:gaussian-product-gap'],'conclusion':'producer restricted to this case','route_relation':'OR with P-positive-density; unproved'},
{'id':'P-zero','guard':'finrank ℝ E=0','premises':['bridge-zero-dimension','bridge-rpow'],'conclusion':'producer restricted to zero dimension','route_relation':'Separate case obligation for generic producer; never parent of the source positive-dimensional moment'},
{'id':'T-use-P','guard':'hq: 2q+1<d, hence r=q+1≥1','premises':['producer specialized to EuclideanSpace ℝ (Fin(q+1))','bridge-euclidean-norm-rank','bridge-markov-measure','bridge-log-and-bound'],'conclusion':'private_consumer','source_use_sites':['A3.SS2.p10.m3','A3.Ex104.m1','A3.SS2.p10.3'],'route_relation':'Hypothetical mathematical use only; no proof call or compiler dependency observed'}],
'case_logic':'Generic producer needs coverage of zero and positive dimension cases. Within positive dimension, either Gaussian density scaling OR coordinate product is a sufficient background route. Neither alternative nor dimension0 becomes a false AND prerequisite of the source moment.',
'explicit_exclusions':['Actual Lean proof code, declaration elaboration, library/API search and compiler dependencies','Root binder plan/verdict and other agent judgments','Joint-row T probability, tail-first-moment and a bias as conclusions of the private tail type','C.5, cross-row independence, radial covariance, fourth moments, Bernstein, full C.6 or Lemma4.4 as scalar proof parents'],
'truth_boundary':'Literal type comparison only. No EXCESS binder visible in the supplied boundary. Unproved backgrounds and source gaps remain explicit. No theorem/compiler proof, independent source approval, API run or semantic-verifier transition.'}
coverage={'scope':'Exactly two supplied literal types and 11 supplied definition literals, with complete within-packet binder/component inventory and explicit noncoverage boundaries.','definitions':definitions,'binders':binder_rows,'type_components':item_rows,'unproved_background_bridges':gap_rows,'excluded':graph['explicit_exclusions'],'counts':{'literal_types':len(type_rows),'definitions':len(definitions),'binders_including_universe':len(binder_rows),'meaning_components':len(item_rows),'unproved_typed_bridges':len(gap_rows),'EXCESS_visible':sum(x['classification']=='EXCESS' for x in binder_rows)}}
for fn,data in [('typed-source-overlay.json',graph),('typed-coverage.json',coverage)]:
    (BASE/fn).write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n')
out={'status':'literal hash/span integrity and bounded type comparison only','packet_bytes':len(b),'packet_sha256':sha(b),**coverage['counts'],'typed_routes':len(graph['planned_mathematical_routes']),'source_graph_modified':False}
stdout=json.dumps(out,indent=2)+'\n'
receipt={'argv':sys.argv,'time_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'actual_status':0,'stdout':stdout,'stderr':'','read':'phase2 own byte-exact copy of the one authorized selective packet','writes':['typed-source-overlay.json','typed-coverage.json']}
(BASE/'execution'/'build-overlay-execution-v2.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(stdout,end='')
