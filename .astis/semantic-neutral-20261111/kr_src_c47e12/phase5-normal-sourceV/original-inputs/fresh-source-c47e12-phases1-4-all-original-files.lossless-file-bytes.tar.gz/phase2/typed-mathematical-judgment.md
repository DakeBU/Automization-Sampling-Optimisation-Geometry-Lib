# Phase 2 independent type judgment

**Both supplied types faithfully express the bounded source interfaces.** I found no excess premise, unsupported strengthening, coefficient-scope error, endpoint error, scaling error, or metric error. This is a mathematical type comparison before implementation exposure; it does not certify a compiled theorem or proof.

The packet SHA-256 is `471d8f4351d80f33d478049a0a2d8716689b2140c043aa324d8132f9b3fb79cb`. The earlier independent mathematical freeze remains `e16737181cd0139bb4afe3e1cfc54d26e9224181f559fcb49efa25f67cf8a3b0`. All 84 phase1 files, exact file set and modes were verified unchanged before this comparison. The full seven-slot, recursive binder and ten-definition audit is in `typed-mathematical-judgment.json`.

## Range type

The first type's range is the actual existential image of B over every real coefficient array. K is the algebraic real span of all (Λ^j)g_a, with both indices running through Fin(q+1). Thus the powers are inclusive j=0,…,q, including Λ^0=I, and the pair index gives exactly (q+1)^2 listed generators.

Its angle ((i.val)+1/2)π/d is exactly the source angle (i−1/2)π/d under source i=i.val+1. κ≥2 and 2q+1<d match the standing and local source premises; the latter implies d≥2. Each nonconstant feature is √2 cos(jθ_i), the constant feature is 1, and B has the exact 1/√d scaling.

x is an arbitrary Euclidean array supplying g_a(i)=ofLp x(i,a). It is not a bundled law, span certificate, rank premise or proof obligation. The source initially samples standard Gaussian starters, but its range proof is deterministic for every realization and uses only the invertible triangular polynomial basis change and nonzero column scalings. Universal arbitrary x is consequently supported by that proof. It introduces no unproved probabilistic assertion.

## Coordinate type and exact metric

The second type says: for every v∈K, there exists **one c** such that Bc=v, the squared-norm identity, and the weighted inner identity all hold. The existential scopes over all three conjuncts. Representation is concluded internally rather than assumed as an extra theorem premise.

The left norm explicitly wraps v with WithLp.toLp 2 into EuclideanSpace R (Fin d). It is the ordinary Euclidean L2 norm, so its square is Σ_i v_i². It is not the supremum norm on the raw finite-function carrier. The right side is the ordinary sum Σ_a c_a((BᵀB)c)_a=cᵀBᵀBc. There is no norm of the raw function c in the type.

The real inner product is explicit. The supplied Euclidean characterization reads inner(x,y)=ofLp(y)·star(ofLp(x)); over R the star is identity and scalar multiplication commutes. Therefore the displayed inner(v,Dv) is Σ_i v_i(Dv)_i=vᵀDv. Its right side is cᵀBᵀDBc. The source prints the latter equality inside absolute values in Ex131; the signed equality follows directly from the same u=Bc representation and ordinary real matrix multiplication. It is a supported exact algebraic expansion of that source proof step.

No concentration event, τ≤1/2, Gram inequality, independent coefficients, full rank, nonzero vector or unit norm is needed for these exact identities. Those proof ingredients do not appear as public premises.

## Endpoints and scope

q=0 is preserved: both coefficient indices have one value, t=1, B=g/√d, Λ^0=I, K=span{g}, n=1 and d≥2. Zero or dependent starters are allowed. v=0 is covered with c=0. There is no division by ‖v‖.

These types cover the range portion of FactC.5 and the representation/exact quadratic-coordinate part of the Lemma4.4 proof. They do not state FactC.5's expectations, FactC.6's concentration, Lemma4.4's probabilistic τ-bound, the adaptive coupling, or the main query lower bound. No full-source-result credit follows from this bounded comparison.

Only the permitted packet and frozen phase1 material were used. File paths named by the packet were treated as identifiers and never opened. Literal payload hashes and locator lengths were checked; actual whole-library file contents or locator placement were not checked. No Lean/API/proving command, implementation review, repair verdict, or verifier transition occurred.

