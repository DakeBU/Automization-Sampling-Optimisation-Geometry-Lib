Phase1 来源数学/coverage 提案已完成；未读取目标 signatures、definitions、Lean、Mathlib API、旧审计或其他角色目录。本包不作目标 fidelity/sourceV 判断，也不自批 topology。需另人审核。

范围为固定原文 S4.SS1、S4.SS2 和完整 A3.SS2/C.2。原文 951991 bytes，SHA256 `6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915`。三个 exact HTML 原始切片以及逐元素字符/UTF8 byte offsets、LF lines、raw hashes 均保留。

数学核心：λ_i=α+βcosθ_i，β=(κ−1)/2≠0；Chebyshev 多项式给 cos(jθ_i)=P_j(λ_i)，其有限系数矩阵三角且对角非零。因此每个 a 的 cosine-feature span 与 {Λ^j g_a}_{j=0}^q 相同。B 的列仅多乘非零 d^(−1/2)η_j（η_0=1，j≥1 时η_j=√2），故 range(B)=K_q。该路线不需要 Gaussianity、independence、浓缩事件或列满秩。

C.2.p19 对每个 u∈K_q 取同一个 c 使 u=Bc，得到 ‖u‖²=cᵀBᵀBc 与 uᵀD_nu=cᵀBᵀD_nBc（以及绝对值等式）。这是确定性矩阵代数；C.6 事件只用于其后的上下界。τ≤1/2 只在消去同一 ‖c‖²、保证1−τ>0时进入。range 方向 K_q⊆range(B) 是此处实际消费的方向，不能只证明反向包含。

完整 C.2 的 t 特征正交、加权消失、二阶矩、截断、径向 bias、四阶矩、Bernstein 和统一事件路线均记录，以明确必要父边和上下文。仅有原文单一路线，没有伪造 OR-route；六个 C.5 分量不会全部变成 range 分量的父节点。κ=1 的退化边界有明确源域外例子；q=0 和零向量无遗漏。

coverage：520 个 id，252 math，39 paragraph div、72 p 元素、46 table（含10 equationgroup）、21 tbody display row id、3 无id citation，均 NODE 或 EXCLUDED(reason)。69 个 table 内 math 中33个自身 display 属性是 inline，已覆盖；不能只扫 ltx_equation 或 display=block。49 个数学节点、28 AND hyperedge、0 OR-route；这些计数只是结构核对，非数学批准。

限制：早期文档合并输出、宽 rg 和合并 inventory 输出曾截断；宽 rg 实际曝光同一原文的邻近范围。原始工具 transcript、诚实的捕获缺口、后来明确标注的重放 stdout 和所有修订脚本均保留，不自称零预训练/绝对 pristine。冻结 receipt 与 manifest 是本包封存边界；之后等待精确 signatures + minimal definitions 进入 Phase2。
