import Tests.GaussianComplexityFixedSpectrumGaussianMoments
import Lean

open Lean Elab Command Meta

private def moduleOf (env : Environment) (n : Name) : Name :=
  match env.getModuleIdxFor? n with
  | some i => env.header.moduleNames[i.toNat]!
  | none => env.mainModule

private def constantDeps (ci : ConstantInfo) : Array Name :=
  (ci.type.getUsedConstants ++ ((ci.value? true).map Expr.getUsedConstants).getD #[]).qsort Name.lt

private def kindOf (ci : ConstantInfo) : String :=
  match ci with
  | .axiomInfo _ => "axiom"
  | .thmInfo _ => "theorem"
  | .defnInfo _ => "definition"
  | .opaqueInfo _ => "opaque"
  | .ctorInfo _ => "constructor"
  | .recInfo _ => "recursor"
  | .inductInfo _ => "inductive"
  | .quotInfo _ => "quotient"

run_cmd do
  let env := (← getEnv).setExporting false
  let producer := `AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumGaussianMoments
  let focused := `Tests.GaussianComplexityFixedSpectrumGaussianMoments
  let owned (n : Name) := let m := moduleOf env n; m == producer || m == focused
  let names := (env.constants.toList.filter (fun x => owned x.1)).map Prod.fst
  let names := names.toArray.qsort Name.lt
  let mut rows : Array Json := #[]
  for n in names do
    let some ci := env.find? n | throwError "missing owned declaration {n}"
    let typ ← liftTermElabM <| Meta.ppExpr ci.type
    let mut kernelChecked := false
    if let some v := ci.value? true then
      liftTermElabM do
        Meta.checkWithKernel v
        let inferred ← Meta.inferType v
        unless ← Meta.isDefEq inferred ci.type do
          throwError "value/type mismatch {n}"
      kernelChecked := true
    let axs ← collectAxioms n
    let direct := constantDeps ci
    let mut visited : NameSet := {}
    let mut localReach : NameSet := {}
    let mut parents : NameSet := {}
    let mut todo := #[n]
    while !todo.isEmpty do
      let current := todo.back!
      todo := todo.pop
      if visited.contains current then continue
      visited := visited.insert current
      if owned current then
        localReach := localReach.insert current
        if let some info := env.find? current then
          for dep in constantDeps info do
            if owned dep then todo := todo.push dep
            else if dep.toString.startsWith "AutoSamplingTheory." then
              parents := parents.insert dep
    let jsonNames (xs : Array Name) := toJson (xs.map Name.toString)
    rows := rows.push <| Json.mkObj [
      ("name",toJson n.toString), ("module",toJson (moduleOf env n).toString),
      ("kind",toJson (kindOf ci)), ("type",toJson typ.pretty),
      ("kernel_checked_value",toJson kernelChecked),
      ("recursive_axioms",jsonNames axs),
      ("direct_constants",jsonNames direct),
      ("named_proof_binders",Json.arr <| (ci.value? true).getD ci.type |>.fold (init := #[]) fun acc e =>
        match e with
        | .letE name _ _ body _ =>
          if name.toString.startsWith "hF" || name.toString.startsWith "ha_bound" || name.toString.startsWith "hactual" then
            let marker := Name.mkSimple "INDEPENDENT_BINDER_USE_MARKER"
            acc.push (Json.mkObj [("name",toJson name.toString),("used_in_body",toJson ((body.instantiate1 (mkConst marker)).getUsedConstants.contains marker))])
          else acc
        | _ => acc),
      ("reachable_local_declarations",jsonNames (localReach.toArray.qsort Name.lt)),
      ("external_ASTIS_parents_through_local_aux",jsonNames (parents.toArray.qsort Name.lt))]
  let path := "/Users/zhouhuanjian/ASTIS-GC/.astis/semantic-neutral-20261110/src_d63b90/phase3/runtime/inspected-declarations.json"
  liftIO <| IO.FS.writeFile path (Json.pretty (toJson rows))
  logInfo m!"Owned declarations: {names.size}. Kernel/type/recursive-axiom/direct-constant/local-closure data written to {path}"
  for row in rows do
    logInfo m!"{(row.getObjValAs? String "name").toOption.getD "?"}: {(row.getObjVal? "recursive_axioms").toOption.getD Json.null}"
