from pathlib import Path
from hashlib import sha256
from html.parser import HTMLParser
import json
from bs4 import BeautifulSoup

REPO = Path('/Users/zhouhuanjian/ASTIS-GC')
OWN = REPO / '.astis/semantic-neutral-20261110/cg_sg_1d7a46'
PHASE = OWN / 'phase1'
RAW = REPO / '.astis/huanjian-resume-20261103/2610.20492v1.html'
EXPECTED = '6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
PROTOCOLS = ['AGENTS.md', 'docs/proof-digestion-protocol.md',
             'docs/theorem-publication-protocol.md',
             'docs/evidence-routed-memory-protocol.md',
             '.agents/skills/astis-source-dependency-audit/SKILL.md']

def dump(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')

raw = RAW.read_bytes()
assert sha256(raw).hexdigest() == EXPECTED
text = raw.decode('utf-8')
soup = BeautifulSoup(text, 'html.parser')
line_offsets = [0]
for pos, ch in enumerate(text):
    if ch == '\n':
        line_offsets.append(pos + 1)
byte_offsets = [0]
for ch in text:
    byte_offsets.append(byte_offsets[-1] + len(ch.encode('utf-8')))

class SpanParser(HTMLParser):
    void = {'area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr'}
    def __init__(self):
        super().__init__(convert_charrefs=False)
        self.stack = []
        self.spans = {}
        self.issues = []
    def current_offset(self):
        line, col = self.getpos()
        return line_offsets[line - 1] + col
    def store(self, tag, ident, start, end):
        if ident:
            assert ident not in self.spans, ('duplicate id', ident)
            self.spans[ident] = {'id': ident, 'tag': tag,
                'byte_start': byte_offsets[start], 'byte_end_exclusive': byte_offsets[end],
                'byte_length': byte_offsets[end] - byte_offsets[start],
                'sha256': sha256(raw[byte_offsets[start]:byte_offsets[end]]).hexdigest()}
    def handle_starttag(self, tag, attrs):
        start = self.current_offset()
        ident = dict(attrs).get('id')
        if tag in self.void:
            self.store(tag, ident, start, start + len(self.get_starttag_text()))
        else:
            self.stack.append((tag, ident, start))
    def handle_startendtag(self, tag, attrs):
        start = self.current_offset()
        self.store(tag, dict(attrs).get('id'), start, start + len(self.get_starttag_text()))
    def handle_endtag(self, tag):
        end = text.index('>', self.current_offset()) + 1
        matches = [i for i, value in enumerate(self.stack) if value[0] == tag]
        if not matches:
            self.issues.append({'unmatched_endtag': tag, 'offset': self.current_offset()})
            return
        match = matches[-1]
        for skipped in self.stack[match + 1:]:
            self.issues.append({'implicitly_closed': skipped[0], 'id': skipped[1]})
        value = self.stack[match]
        del self.stack[match:]
        self.store(*value, end)

parser = SpanParser()
parser.feed(text)
assert not parser.stack, parser.stack
assert not parser.issues, parser.issues

input_records = []
for rel in PROTOCOLS:
    src = REPO / rel
    data = src.read_bytes()
    dest = PHASE / 'inputs' / (rel.replace('/', '__'))
    dest.write_bytes(data)
    input_records.append({'path': str(src), 'sha256': sha256(data).hexdigest(),
                          'byte_length': len(data), 'snapshot': str(dest.relative_to(PHASE))})
(PHASE / 'inputs' / '2610.20492v1.html').write_bytes(raw)
input_records.append({'path': str(RAW), 'sha256': EXPECTED, 'byte_length': len(raw),
                      'snapshot': 'inputs/2610.20492v1.html'})
dump(PHASE / 'inputs.json', {'source_revision': 'arXiv:2610.20492v1',
    'title': soup.title.get_text(' ', strip=True), 'authors': ['Huanjian Zhou','Taiji Suzuki'],
    'inputs': input_records,
    'authorized_scope': 'Independent raw-source-only deterministic cosine-frame Gram packet; Gaussian second-moment consumer context; no implementation, sealed statement or previous evidence.'})

roots = ['S4.SS1', 'S4.SS2.SSS0.Px1', 'S4.SS2.SSS0.Px2', 'A3.SS2', 'bib.bib3']
items = []
for rootid in roots:
    elem = soup.find(id=rootid)
    assert elem is not None
    rootspan = parser.spans[rootid]
    (PHASE / 'source' / (rootid + '.html')).write_bytes(raw[rootspan['byte_start']:rootspan['byte_end_exclusive']])
    (PHASE / 'source' / (rootid + '.txt')).write_text(elem.get_text(' ', strip=True) + '\n')
    for el in [elem, *elem.find_all(id=True)]:
        ident = el['id']
        if any(item['id'] == ident for item in items):
            continue
        span = dict(parser.spans[ident])
        span.update({'root': rootid, 'classes': el.get('class', []),
            'parent_id': next((p.get('id') for p in el.parents if getattr(p,'get',None) and p.get('id')),None),
            'alttext_exact': el.get('alttext'), 'text': el.get_text(' ',strip=True),
            'locator': '#' + ident})
        items.append(span)
dump(PHASE / 'source_index.json', {'raw_sha256': EXPECTED,
    'offset_convention': 'Zero-based UTF-8 byte offsets into pinned raw; end exclusive; bytes include opening and closing element tags.',
    'span_parser': 'stdlib HTMLParser, convert_charrefs=False, explicit stack; zero unmatched/implicit/unclosed tags.',
    'roots': roots, 'items': items})

# Every raw math ID, display, theorem, proof and paragraph in the bounded read
# windows is inventoried once. Label/title wrappers are recorded too.
dump(PHASE / 'source' / 'all_ids.txt.json', [
    {'id': x['id'], 'tag': x['tag'], 'classes': x['classes'], 'text': x['text'],
     'alttext_exact': x['alttext_exact']} for x in items])
report = {'status': 'OK', 'source_sha256': EXPECTED, 'raw_bytes':len(raw),
          'raw_id_count':len(parser.spans),'bounded_id_count':len(items),
          'bounded_math_ids':sum(x['tag']=='math' for x in items),
          'roots': roots, 'parser_issues': parser.issues,
          'note': 'Source readback text duplicates visual MathML plus TeX annotation; original HTML and exact alttext retained.'}
dump(PHASE / 'logs' / 'prepare_output.json', report)
print(json.dumps(report, ensure_ascii=False))
