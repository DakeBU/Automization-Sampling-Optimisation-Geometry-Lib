from pathlib import Path
import bisect,datetime,hashlib,json,re
OUT=Path(__file__).resolve().parent
def H(p):return hashlib.sha256(p.read_bytes()).hexdigest()
s=(OUT/'original.2610.20492v1.RAW.html').read_text();sb=s.encode();starts=[0]+[m.end() for m in re.finditer('\n',s)]
B={b['id']:b for b in json.loads((OUT/'source-blocks.RAWFIRST.json').read_text())}
g=json.loads((OUT/'SOURCE-GRAPH.v2.json').read_text());c=json.loads((OUT/'SOURCE-COVERAGE.v2.json').read_text());p=json.loads((OUT/'INTERNAL-PORTS.v1.json').read_text())
def F(sid,a,z,dis,why,i):return {'source_id':sid,'fragment':i,'char_start':a,'char_end_exclusive':z,'byte_start':len(s[:a].encode()),'byte_end_exclusive':len(s[:z].encode()),'line_start_1based':bisect.bisect_right(starts,a),'line_end_1based':bisect.bisect_right(starts,max(a,z-1)),'raw_sha256':hashlib.sha256(s[a:z].encode()).hexdigest(),'disposition':dis,'reason':why}
b=B['S4.Thmtheorem4.p1.1'];a,z=b['char_start'],b['char_end_exclusive'];k=a+407;l=a+1757
assert s[k:k+4]=='Let ' and re.match(r'and\s+let',s[l:z])
c['mixed_fragments'] += [F(b['id'],a,k,'EXCLUDED','Absolute-C existence belongs to the full Lemma4.4 stochastic result, not this deterministic packet.',1),F(b['id'],k,l,'NODE','Exact q regime and original independent Gaussian column experiment.',2),F(b['id'],l,z,'EXCLUDED','Krylov-space definition and ensuing tau-definition connector are outside the packet.',3)]
b=B['S4.E11'];a,z=b['char_start'],b['char_end_exclusive'];m=re.search(r'<math\b[^>]*alttext="([^"]*)"',s[a:z]);assert m
u=a+m.start(1);v=a+m.end(1);k=s.index(r'\lambda_{i}=',u,v);theta_end=s.rfind(r',\qquad',u,k)
c['display_components']=[F(b['id'],u,theta_end,'NODE','Exact midpoint theta subformula; locator is original math alttext component.',1),F(b['id'],k,v,'EXCLUDED','lambda_i and Lambda spectrum definitions are not needed by literal B/Gram identity; no kappa premise is introduced.',2)]
c['display_components_policy']='Logical source-formula components are located in exact original alttext; their MathML/annotation duplicates express the same formulas, not additional claims.'
c['version']='GRAM-coverage-v3-complete-context-dispositions';c['predecessor']={'path':'SOURCE-COVERAGE.v2.json','sha256':H(OUT/'SOURCE-COVERAGE.v2.json')}
g['version']='GRAM-source-only-v3-final-proposed';g['predecessor_v2']={'path':'SOURCE-GRAPH.v2.json','sha256':H(OUT/'SOURCE-GRAPH.v2.json'),'delta':'Same mathematical nodes/edges/statements. Exact coverage successor adds explicit mixed source theorem/spectrum exclusions.'};g['coverage_path']='SOURCE-COVERAGE.v3.json'
for n,d in [('SOURCE-GRAPH.v3.json',g),('SOURCE-COVERAGE.v3.json',c)]: (OUT/n).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
p['version']='GRAM-internal-ports-v2-exact-final-graph-coverage-binding';p['predecessor']={'path':'INTERNAL-PORTS.v1.json','sha256':H(OUT/'INTERNAL-PORTS.v1.json')};p['source_graph_path']='SOURCE-GRAPH.v3.json';p['source_graph_sha256']=H(OUT/'SOURCE-GRAPH.v3.json');p['source_coverage_path']='SOURCE-COVERAGE.v3.json';p['source_coverage_sha256']=H(OUT/'SOURCE-COVERAGE.v3.json')
p['local_type_legend']={'D':'EuclideanSpace Real(Fin d)','E':'EuclideanSpace Real(Fin(q+1))','Omega':'Fin(q+1)->D','J':'Fin(q+1) x Fin(q+1)','M':'Matrix J J Real','mu':'Measure.pi(fun _ : Fin(q+1)=>stdGaussian D)','r':'((q+1:Nat):Real)','remaining_lets':'Exactly the current sealed L,theta,t,row,Y,mean,Z,a,w,B,G; no independent certificates.'}
(OUT/'INTERNAL-PORTS.v2.json').write_text(json.dumps(p,ensure_ascii=False,indent=2)+'\n')
checks=0
for b in c['blocks']+c['mixed_fragments']+c['display_components']:
 raw=s[b['char_start']:b['char_end_exclusive']].encode();assert raw==sb[b['byte_start']:b['byte_end_exclusive']];assert hashlib.sha256(raw).hexdigest()==b['raw_sha256'];assert b['disposition'] in ['NODE','EXCLUDED'];assert b['reason'];checks+=1
ids={n['id'] for n in g['nodes']};assert len(ids)==len(g['nodes'])
for e in g['edges']:assert set(e['parents']+[e['consumer']])<=ids
assert p['source_graph_sha256']==H(OUT/p['source_graph_path']);assert p['source_coverage_sha256']==H(OUT/p['source_coverage_path'])
lint={'checked_source_locators':checks,'blocks':len(c['blocks']),'fragment_records':len(c['mixed_fragments']),'display_components':len(c['display_components']),'nodes':len(g['nodes']),'edges':len(g['edges']),'source_gaps':sum(n['kind'].startswith('SOURCE_GAP') for n in g['nodes']),'errors':[],
 'scope':'Locator/hash/schema/current-binding lint only. Not independent topology approval, theorem proof or source/normalV verdict.'}
(OUT/'SOURCE-LINT.v1.json').write_text(json.dumps(lint,indent=2)+'\n')
print(json.dumps({'final_graph_sha256':H(OUT/'SOURCE-GRAPH.v3.json'),'final_coverage_sha256':H(OUT/'SOURCE-COVERAGE.v3.json'),'final_ports_sha256':H(OUT/'INTERNAL-PORTS.v2.json'),'audit_sha256':H(OUT/'BINDER-DEFINITION-AUDIT.v1.json'),**lint},indent=2))
