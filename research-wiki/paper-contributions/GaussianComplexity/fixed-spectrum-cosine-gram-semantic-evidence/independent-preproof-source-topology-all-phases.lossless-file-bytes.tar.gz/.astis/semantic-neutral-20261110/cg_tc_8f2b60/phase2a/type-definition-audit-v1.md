# Independent exact-type and minimal-definition audit

Stage PHASE2a, following the immutable raw-only cognition freeze. The author Source Proof Graph and every implementation/proof/API/native/source-V/prior-verdict artifact remain unseen. This audit decides the meaning and admissibility of the literal signatures; it does not certify a proof or award source closure.

## Result

The supplied producer signature expresses exactly the three deterministic Fact C.5 components selected in the raw freeze. Its only logical premise is the source range `2q+1<d`. The private consumer expresses actual Gaussian Gram-entry integrability and actual integral values under a fixed canonical Gaussian measure. It has no moment, integrability, covariance, event, or independence premise supplied by a caller. No EXCESS binder or invented project-owned definition fallback was found in these literal inputs.

This is a type/definition PASS for this bounded signature projection. The real Gaussian moments, finite-sum integration bridges and all other proof ingredients remain obligations inside the eventual proof. The result says nothing about an unseen implementation or author graph. Range/Krylov, concentration, the complete Fact C.5 and Lemma 4.4 remain open outside this packet.

## Input integrity and authority

The three initially authorized files were read in full after byte-count and SHA256 verification. The fixed raw HTML was independently rehashed at 951991 bytes and SHA256 `6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915`. Every phase1 manifest artifact still matches its recorded bytes/hash and mode `0444`; its manifest hash remains `d67f2864ba332e90e91cc8ba16c09db822f5229e0526b9223e6e920b607bca91`, and its directory remains `0555`.

The projection includes an author's binder classification and prose meanings. They were read as exposed assertions, not accepted as authority. The following conclusions come from the actual signature strings, literal definition bodies and the independent raw cognition. The package's claimed upstream whole-file hashes/line numbers were not verified by reading Mathlib files, because this stage expressly authorizes only the named literal-definition packages. Serialized literal bodies were independently hashed and matched their declared hashes.

One further pure-definition package was specifically requested: `gaussianPDF` and its `gaussianPDFReal` body, to inspect the density behind the non-Dirac `gaussianReal(0,1)` branch. The received 1233-byte package has SHA256 `1a9fc0110902d684b95e7ceeb50136058a89912aead7eabd46d387a36373599d`. It contains no proof or API lemma. Its two literal body hashes, and the two bodies in the original canonical Gaussian supplement, were independently checked. No other W-directory artifact was opened.

## Independent binder classification

Both declarations have the same complete public logical input list:

| Input | Independent classification | Raw justification |
|---|---|---|
| `d : ℕ` | TYPING | Finite Euclidean ambient dimension and finite row carrier. The source `d≥2` follows from the next range premise; it is not silently dropped. |
| `q : ℕ` | SOURCE | Source nonnegative integer query/degree parameter, including zero. Its Nat representation encodes the source integer/nonnegative convention rather than adding positivity. |
| `hq : 2*q+1<d` | SOURCE | Explicit Lemma 4.4 premise inherited by its C.2/Fact C.5 proof context. Fact C.5 does not restate the standing context, but the source reading in phase1 retained it. |

All other displayed names are literal `let` bindings or conclusion quantifiers. There is no project-owned `Prop` alias, structure or typeclass concealing a theorem-shaped assumption. Standard finite-carrier, real-vector-space, Borel/measure and decidable equality instances are typing conventions of these concrete canonical carriers, not extra mathematical hypotheses from a caller. In particular, the Gaussian law itself is fixed by the literal `μ` definition; it is not a free measure with a desired-moments certificate.

The `Integrable` propositions in the consumer are conclusions for every coefficient pair. They are source-implicit well-definedness content made explicit, not public premises. No measurable/finite-moment/normalization assumption was added to either theorem's input list.

## Quantifiers, carriers, endpoints and normalizations

The implicit `d,q` quantifiers are universal naturals, followed by the single range premise. The producer then defines one common `θ,t,D` and concludes a conjunction of two whole-matrix equalities and a bound for every row. It does not change `θ` or `D` between conjuncts. The row norm quantifier is inside the conclusion and ranges over all `Fin d`.

`hq` forces `d≥2`, `q+1≥1`, `n=2q+1≥1`, `n<d`, and the finite ranges needed by the raw argument. The source endpoint is strict. No `q>0`, `n≤d`, `4q+1<d`, asymptotic size condition or real-valued degree has replaced it. The signature uses no free `n` or `r`: their source values are literally encoded as `2*q+1` and `q+1`.

The grid is `((i.val : ℝ)+1/2)*π/(d:ℝ)`. The surrounding real arithmetic makes `1/2` real division. With source index `i_source=i.val+1`, this is exactly `(i_source-1/2)π/d`; no endpoint or half-shift was lost. The finite source index set is the full midpoint grid, and the denominator is nonzero from `hq`.

`t : Matrix (Fin d) (Fin(q+1)) ℝ` has frequency indices `k.val=0,…,q`. Its explicit branch gives the constant mode 1 and only its nonconstant modes `√2 cos(kθ)`. The producer's `tᵀ*t=d • 1` is the raw sum `Σ_i t_it_iᵀ=dI_r`, not the normalized frame Gram. The identity has dimension `r=q+1`, not `d` or `r²`. Its `D` is a real diagonal matrix with exactly `cos((2q+1)θ_i)` entries, so `tᵀ*D*t=0` has the correct weighted-entry sums. Ordinary real transpose matches the source's real Euclidean transpose.

The last conjunct is exactly `Σ_k (t i k)^2 ≤ 2((q:ℝ)+1)`, the squared Euclidean row norm of `t_i`. It makes no claim about the row norm of the random tensor matrix `B`. The constant-mode case is present for `q=0`: `Fin(q+1)` then has one frequency, its branch value is 1, and `n=1`. The signature does not discard that source boundary.

No `κ`, `λ`, `Λ`, Krylov subspace, absolute concentration constant or `τ` is needed to state these three components or these actual second-moment means. Their absence preserves the bounded source slice. It cannot be used to claim the excluded range/Krylov or probabilistic uniform-bound results.

## Literal Gaussian law and fallback audit

The consumer fixes

`E = EuclideanSpace ℝ (Fin d × Fin(q+1))`,
`μ = multivariateGaussian (0:E) (1:Matrix (Fin d × Fin(q+1)) (Fin d × Fin(q+1)) ℝ)`.

The covariance identity here has dimension `d*(q+1)`, the total number of source scalar entries, not the coefficient dimension `(q+1)²`. The literal multivariate definition is the pushforward of `stdGaussian E` by `x ↦ μ_mean + toEuclideanCLM(CFC.sqrt S)x`. At the selected `S=I` and zero mean it is the canonical centered identity-covariance Gaussian construction. The supplied generic docstring exposes a non-PSD branch collapsing to a Dirac measure. This branch is not hidden, but it is irrelevant at the fixed identity covariance: positivity and square-root identity are mathematical facts to discharge internally, not new caller hypotheses. This audit does not endorse arbitrary non-PSD inputs as Gaussian covariances.

`stdGaussian E` is literally a product of `gaussianReal 0 1` coefficients in `stdOrthonormalBasis ℝ E`, pushed forward by the finite orthonormal-basis sum. The presence of an orthonormal basis is a canonical finite-dimensional construction, not a project choice of a conditional expectation representative or an existence/default object. To identify this measure with independent source coordinates in the displayed `(i,a)` indexing, the later proof must justify the standard Gaussian coordinate/orthogonal-basis law, rather than assuming it. That obligation is not a reason to add source-facing moment or independence binders.

`gaussianReal μ v` is `dirac μ` only when `v=0`; at the literal `v=1` used here its body is `volume.withDensity(gaussianPDF 0 1)`. The requested density bodies show `gaussianPDF=ENNReal.ofReal gaussianPDFReal` and

`gaussianPDFReal μ v x=(√(2πv))⁻¹ exp(-(x-μ)^2/(2v))`.

Thus its selected `μ=0,v=1` branch has the standard normal density normalization and exponent. No zero-variance or division-by-zero branch is selected. Nonnegative-real variance and its real coercion are part of the literal canonical definition, not an unspecified variance parameter in the consumer.

All these supplied definitions are literal constructions. No project-owned `if existence then choose else zero`, quotient representative or characterized unique object occurs. Canonical `Measure.map`, orthonormal-basis synthesis, continuous-linear matrix action, `CFC.sqrt`, `WithLp.ofLp` and finite coordinate evaluation retain their ordinary canonical meanings. Measurability of the maps and the valid identity-covariance branch are internal proof ingredients; any totalization behavior of generic operations cannot replace those arguments.

## Tensor indexing, entries, integrability and means

For a coefficient-column pair `a=(a₁,a₂)`, the literal row formula is

`B(x)_(i,a)=(√d)⁻¹ * x_(i,a₁) * t_(i,a₂)`.

This matches the raw tensor order `γ_i ⊗ t_i`, with Gaussian index first and cosine index second. `WithLp.ofLp` exposes the underlying finite-coordinate function of `EuclideanSpace`; it is not a random-law change. The source starting vectors can be read as columns `g_(a₁)=(x_(i,a₁))_i`. Establishing their independent `N(0,I_d)` law from this fixed joint Gaussian remains an internal law bridge if that source interpretation is used. The signature does not assert an adaptive, conditional or algorithm-output law.

The normalization is exactly `(√d)⁻¹`; in Gram products its square must be reduced internally to `1/d` using `d>0`. No factor of `r`, `r²`, `√2` or tensor-column permutation has been inserted into `B`.

The consumer universally quantifies over all ordered coefficient pairs `a,b : Fin r × Fin r`. For each it concludes both real-valued Gram-entry integrability statements and the two actual Bochner-integral values. The unweighted integrand is the finite row sum of `(1/d) x_(i,a₁)x_(i,b₁)t_(i,a₂)t_(i,b₂)`; the weighted integrand has the extra deterministic `cos(nθ_i)` factor. This interpretation accounts for diagonal and cross terms. No independence between different rows is needed merely to integrate a finite Gram sum, but off-diagonal Gaussian-coordinate second moments must still be established under the actual law.

The identity conclusion `if a=b then 1 else 0` is the identity on the product coefficient index, equivalent to the source `I_(r²)` entries. Both Gaussian-index and frequency-index equality matter. The weighted conclusion is entrywise zero. Since the signature explicitly asserts both `Integrable` conclusions, totalized Bochner integrals cannot make a nonintegrable expression appear centered by returning zero. These are actual expectations under `μ`, rather than a symbolic covariance certificate or a separately assumed expectation matrix.

Finite-dimensional matrix expectation can be read entrywise as in the source. If a later interface uses a matrix-valued Bochner integral, the equivalence with these finitely many integrable entries must be discharged inside its adapter. This signature already exposes every entry and does not claim that an unseen matrix-valued integration bridge has been implemented.

## Unseen proof and next-stage obligations

The statement contains no conclusion-as-premise smuggling. A future implementation must call the deterministic producer and establish the law-to-second-moment, measurability/integrability, normalization, finite-sum integration and product-index identity bridges inside its private consumer. None of these are certified by this type audit. No event bound, random Gram positivity, concentration, range/Krylov, adaptive oracle, precision, total variation, cost, lower-bound or website-delivery claim follows at this stage.

The author Source Proof Graph may be received only after this audit is frozen. Its structure will be challenged against immutable phase1 raw cognition and this exact-type reading. It must represent all deterministic proof regions, the actual-law consumer dependencies and the excluded remaining boundaries. This audit has not used the author's graph or rationale to select the source topology.
