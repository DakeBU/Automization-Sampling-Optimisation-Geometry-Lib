"""Verify served-byte identity independently; no fictional v4 browser run."""
import hashlib
import json
from pathlib import Path
OWN=Path(__file__).resolve().parent
REPO=OWN.parents[3]
BASE=REPO/'.astis/huanjian-gc-matrix-laplace-20261114'
V3=BASE/'reader-preview-v3';V4=BASE/'reader-preview-v4'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(V3/'preview-freeze-manifest.json')=='9209609b560905e6cd11a69082ac4bdb89e752a66fe3e99ba38e17508d2103b7'
assert sha(V4/'preview-freeze-manifest.json')=='809059d961095cd0984a385d18f618be342480b89f69bfe2e75c6cd91862afd8'
a=json.loads((V3/'preview-freeze-manifest.json').read_text());b=json.loads((V4/'preview-freeze-manifest.json').read_text())
rows=[]
for variant in ['original','candidate']:
    aa={r['path']:r for r in a['variants'][variant]['files']};bb={r['path']:r for r in b['variants'][variant]['files']}
    assert aa==bb
    assert {str(p.relative_to(V3/'fixtures'/variant)) for p in (V3/'fixtures'/variant).rglob('*') if p.is_file()}==set(aa)
    assert {str(p.relative_to(V4/'fixtures'/variant)) for p in (V4/'fixtures'/variant).rglob('*') if p.is_file()}==set(bb)
    for path,row in aa.items():
        x=V3/'fixtures'/variant/path;y=V4/'fixtures'/variant/path
        assert sha(x)==sha(y)==row['sha256']
        assert x.stat().st_size==y.stat().st_size==row['bytes']
        assert x.read_bytes()==y.read_bytes()
        rows.append({'variant':variant,'path':path,'bytes':row['bytes'],'sha256':row['sha256'],'direct_bytes_equal':True})
assert len(rows)==207 and sum(r['variant']=='original' for r in rows)==103
report={'schema':'independent-v3-v4-served-byte-identity-v1','v3_preview_manifest_sha256':sha(V3/'preview-freeze-manifest.json'),'v4_preview_manifest_sha256':sha(V4/'preview-freeze-manifest.json'),'actual_browser_target':'reader-preview-v3 only','v4_browser_executed':False,'served_membership_complete':True,'served_files':rows,'original_files':103,'candidate_files':104,'all_207_path_bytes_sha_and_direct_bytes_identical':True,'observation_transfer_boundary':'Only observations of the exact identical served bytes/layout/navigation can transfer from actual v3 Chrome execution to v4. Metadata repair/source-fidelity acceptance is separate; no v4 browser process or screenshot is claimed.'}
(OWN/'v3-v4-site-byte-identity.v1.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'all207_served_files_byte_identical':True,'report_sha256':sha(OWN/'v3-v4-site-byte-identity.v1.json')}))
