from html.parser import HTMLParser
from pathlib import Path
import hashlib
import json
import sys

ROOT = Path('/Users/zhouhuanjian/ASTIS-GC')
RAW = ROOT / '.astis/huanjian-resume-20261103/2610.20492v1.html'
OUT = ROOT / '.astis/semantic-neutral-20261110/src_a74f20/phase1'
EXPECTED = '6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'

class Node:
    def __init__(self, tag='', attrs=(), start=0):
        self.tag, self.attrs, self.start = tag, dict(attrs), start
        self.end, self.children = start, []

class Parse(HTMLParser):
    def __init__(self, raw):
        super().__init__(convert_charrefs=True)
        self.raw = raw
        self.lines = [0]
        self.lines.extend(i + 1 for i, c in enumerate(raw) if c == '\n')
        self.root = Node()
        self.stack, self.ids = [self.root], {}
        self.feed(raw)
    def pos(self):
        line, col = self.getpos()
        return self.lines[line - 1] + col
    def handle_starttag(self, tag, attrs):
        n = Node(tag, attrs, self.pos())
        self.stack[-1].children.append(n)
        if 'id' in n.attrs:
            self.ids[n.attrs['id']] = n
        if tag not in {'area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr'}:
            self.stack.append(n)
        else:
            n.end = self.pos() + len(self.get_starttag_text())
    def handle_endtag(self, tag):
        for i in range(len(self.stack)-1, 0, -1):
            if self.stack[i].tag == tag:
                end = self.raw.find('>', self.pos()) + 1
                for n in self.stack[i:]:
                    n.end = end
                self.stack = self.stack[:i]
                break
    def handle_data(self, data):
        self.stack[-1].children.append(data)

def text_of(n):
    if isinstance(n, str):
        return n
    if n.tag == 'math' and 'alttext' in n.attrs:
        return ' $' + n.attrs['alttext'] + '$ '
    if n.tag in {'script','style','annotation','annotation-xml'}:
        return ''
    s = ''.join(text_of(c) for c in n.children)
    if n.tag in {'p','h1','h2','h3','h4','h5','li','tr','dt','dd','section','figure','table','tbody'}:
        s += '\n'
    return s

raw_bytes = RAW.read_bytes()
actual = hashlib.sha256(raw_bytes).hexdigest()
if actual != EXPECTED:
    raise SystemExit('RAW HASH MISMATCH ' + actual)
raw = raw_bytes.decode('utf-8')
p = Parse(raw)
OUT.mkdir(parents=True, exist_ok=True)
args = sys.argv[1:] or ['S4.SS1','S4.Thmtheorem5','A3.SS3']
metadata_only = '--metadata' in args
args = [x for x in args if x != '--metadata']
def descendants(n):
    yield n
    for c in n.children:
        if isinstance(c, Node):
            yield from descendants(c)
for ident in args:
    if ident == '--ids':
        for k, n in p.ids.items():
            if k in {'S4','S4.SS1','S4.Thmtheorem5','A3.SS3'} or k.startswith('S4.SS1.'):
                print(k, n.tag, n.attrs.get('class',''))
        continue
    n = p.ids.get(ident)
    if n is None:
        print('MISSING ID', ident)
        continue
    slug = ident.replace('/','_')
    if metadata_only:
        metadata = []
        for item in descendants(n):
            if 'id' in item.attrs or item.tag == 'a':
                metadata.append({'tag':item.tag,'id':item.attrs.get('id'), 'href':item.attrs.get('href'), 'text':' '.join(text_of(item).split())[:240]})
        (OUT / (slug + '.metadata.json')).write_text(json.dumps(metadata,indent=2)+'\n')
        print(ident, json.dumps(metadata,indent=2))
        continue
    fragment = raw[n.start:n.end]
    rendered = text_of(n)
    (OUT / (slug + '.raw.html')).write_text(fragment)
    (OUT / (slug + '.txt')).write_text(rendered)
    print('\n===== SOURCE', ident, 'TAG', n.tag, '=====\n' + rendered)
    print('FRAGMENT_SHA256', hashlib.sha256(fragment.encode()).hexdigest())
(OUT / 'raw-input.json').write_text(json.dumps({'path':str(RAW),'sha256':actual,'byte_count':len(raw_bytes)}, indent=2)+'\n')
print('RAW_SHA256', actual)
