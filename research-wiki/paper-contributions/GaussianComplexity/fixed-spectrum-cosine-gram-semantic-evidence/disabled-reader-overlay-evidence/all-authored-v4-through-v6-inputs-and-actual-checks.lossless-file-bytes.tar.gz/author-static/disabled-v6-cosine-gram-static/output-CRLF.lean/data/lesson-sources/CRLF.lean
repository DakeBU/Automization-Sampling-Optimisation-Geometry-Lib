-- prefix
theorem sample : True := by
  trivial
