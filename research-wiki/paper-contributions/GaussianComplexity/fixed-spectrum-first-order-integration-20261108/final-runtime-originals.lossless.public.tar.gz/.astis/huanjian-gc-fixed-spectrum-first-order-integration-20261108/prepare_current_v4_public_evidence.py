from pathlib import Path
import gzip, hashlib, json, shutil, subprocess

R = Path('.astis/huanjian-gc-fixed-spectrum-first-order-integration-20261108')
J = Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-first-order-integration-20261108')
N = Path('.astis/semantic-neutral-20261108/src_4e8f6a')
CORE = '9b1e90d25711668203c6e252cfe5a748f95c8ad4'
sha = lambda b: hashlib.sha256(b).hexdigest()
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == CORE
assert not subprocess.check_output(['git', 'diff', 'HEAD', '--name-only']).strip()
rows = []
def copy_tree(src, dst):
    assert not dst.exists(), str(dst)
    shutil.copytree(src, dst)
    for p in sorted(src.rglob('*')):
        if p.is_file():
            q = dst/p.relative_to(src)
            assert q.read_bytes() == p.read_bytes()
            rows.append({'original': str(p), 'public_copy': str(q), 'sha256': sha(p.read_bytes())})
for name in ['late-context-independent-review-v4', 'original38-independent-review-v4']:
    copy_tree(R/'independent-reader'/name, J/'independent-reader'/name)
copy_tree(R/'independent-reader/browser/live-20261108T160740169669Z', J/'actual-v4-browser-originals')
copy_tree(N/'normalpark-preparation-v2', J/'original-source-verifier/normalpark-preparation-v2')
for name in ['root-final-browser-context-v4.json', 'actual-browser-context-v4-readonly-preflight.json',
             'root-conditional-v4-static-and-diff-review.json', 'root-actual-v4-original8-review.json',
             'root-normalpark-v2-preparation-review.json', 'root-local-acceptance-v4-authorization.json']:
    p, q = R/name, J/name
    assert not q.exists()
    q.write_bytes(p.read_bytes())
    rows.append({'original': str(p), 'public_copy': str(q), 'sha256': sha(p.read_bytes())})
context = json.loads((R/'root-final-browser-context-v4.json').read_bytes())
out = J/'ui-successor-actual-checks'
out.mkdir()
checks = {}
for role, ref in context['actual_checks_before_browser'].items():
    p = Path(ref['path'])
    assert sha(p.read_bytes()) == ref['sha256']
    d = json.loads(p.read_bytes())
    assert d['exit_code'] == 0 and d['head_before'] == d['head_after'] == CORE
    log = Path(d['log'])
    raw = log.read_bytes()
    assert sha(raw) == d['log_sha256']
    receipt = out/p.name
    receipt.write_bytes(p.read_bytes())
    archive = out/(log.name+'.gz')
    archive.write_bytes(gzip.compress(raw, mtime=0))
    assert gzip.decompress(archive.read_bytes()) == raw
    checks[role] = {'original_receipt': ref, 'public_receipt': str(receipt),
                    'raw_log_sha256': sha(raw), 'public_log_gzip': str(archive),
                    'gzip_sha256': sha(archive.read_bytes()), 'elapsed_seconds': d['elapsed_seconds']}
for key in ['actual_gate', 'site_metadata']:
    p = Path(context[key]['path'])
    raw = p.read_bytes()
    assert sha(raw) == context[key]['sha256']
    q = out/(key+'.raw.json.gz')
    q.write_bytes(gzip.compress(raw, mtime=0))
    assert gzip.decompress(q.read_bytes()) == raw
manifest = {'scope': 'Lossless public copies of actual new-core8 gates, approved runtime38 originals, actual independent pixel review and preparation only. Local acceptance and normalpark remain separate.',
            'accepted_immutable_core': CORE, 'source_digest': context['source_digest'],
            'actual_eight_same_core_checks': checks,
            'copied_originals': rows, 'originals_retained_unchanged': True,
            'new_source_verdict': False, 'lifecycle_API_called': False,
            'local_acceptance_created_by_this_packager': False}
p = J/'actual-v4-public-evidence-manifest.json'
assert not p.exists()
p.write_text(json.dumps(manifest, ensure_ascii=False, indent=2)+'\n')
print(json.dumps({'manifest': str(p), 'sha256': sha(p.read_bytes()),
                  'lossless_original_copies': len(rows), 'actual_eight_receipts': len(checks),
                  'no_canonical_or_lifecycle_mutation': True}))
