from pathlib import Path
import json,hashlib,datetime,sys,gzip,shutil
sys.path.insert(0,'tools')
import astis_advance as a
sha=lambda raw:hashlib.sha256(raw).hexdigest()
def put(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
b=Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-normalizer-semantic-evidence')
aid='ASTIS-SA-20261108-GaussianComplexityFixedSpectrumNormalizer'
owner='huanjian_gc_20261108_fixed_spectrum_normalizer'
decl='AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumNormalizer.actual_normalizing_integral'
d=json.loads((b/'publication-draft-record.json').read_bytes());parents=d['actual_ASTIS_producer_parents'];consumer_parents=d['actual_ASTIS_consumer_parents']
files={'AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumNormalizer.lean':d['production_raw_sha256'],
       'Tests/GaussianComplexityFixedSpectrumNormalizer.lean':d['Test_raw_sha256']}
for p,h in files.items():assert sha(Path(p).read_bytes())==h
checks=[]
for p in sorted(Path('.astis/huanjian-resume-20261103').glob('*-fixed-spectrum-normalizer-*.receipt.json')):
 r=json.loads(p.read_bytes());raw=Path(r['log']).read_bytes();assert sha(raw)==r['log_sha256'];dest=b/'actual-checks';q=dest/p.name
 if not q.exists():shutil.copy2(p,q)
 z=dest/(Path(r['log']).name+'.gz')
 if not z.exists():z.write_bytes(gzip.compress(raw,mtime=0))
 assert gzip.decompress(z.read_bytes())==raw
 checks.append({'label':p.name,'receipt':str(q),'actual_exit_code':r['exit_code'],'raw_log_sha256':sha(raw),'elapsed_seconds':r['elapsed_seconds']})
def get(label):
 rows=[r for r in checks if r['label'].endswith('-'+label+'.receipt.json')];assert len(rows)==1 and rows[0]['actual_exit_code']==0;return rows[0]
build=get('fixed-spectrum-normalizer-focused-consumer-corrected');kernel=get('fixed-spectrum-normalizer-kernel-dependencies-corrected')
anon=get('fixed-spectrum-normalizer-anonymous-literal-application');publication=get('fixed-spectrum-normalizer-author-publication-draft')
mapping={
 'source-implicit-actual-Lebesgue-normalizer':'The sealed literal weight is integrated over the actual canonical Euclidean volume. Source convention remains explicitly INFERENCE, not a fabricated integral quotation. The exact numerator/sum/Fin adapter compiles unchanged.',
 'Gaussian-integration-implementation-OR-route':'Instead of redoing diagonal Gaussian integration, use the existing canonical actual Gaussian density and its probability mass. hmass gives lintegral of ofReal(c*weight)=1; continuity and nonnegativity feed lintegral_ofReal_ne_top_iff_integrable to prove finite integrability. c>0 then gives Integrable weight. This is an explicit implementation route; it does not rewrite the independent author source topology.',
 'integrability-AND-value':'hw independently proves full Integrable. hscaled uses the nonnegative integral conversion and integral_const_mul; positive B/sqrt(detA) arithmetic gives the ACTUAL unweighted integral value. Neither conjunct is a new premise or a totalized-zero shortcut.',
 'determinant-product-positive-root':'Existing actual_precision_det identifies actual detA with the literal full product. Existing actual_precision_admissible internally gives SPD and positive determinant; Real.sqrt_pos and Real.rpow_pos_of_pos supply nonzero denominators. Product positivity is thus derived without assuming it or newly claiming the historical strict grid/cosine proof.',
 'same-A-normalized-law-consumer':'Actual Test derives hA/hdet internally, consequentially uses new actual_normalizing_integral.2 to rewrite the actual integral denominator, derives its positivity, and applies the identical canonical GPD to this A. Actual kernel proof inventory contains new producer plus allthree existing canonical parents; not import/name-only evidence.'}
failures='First producer check failed only final local B unfolding; adding B to the final simp list preserved exact interface and yielded PASS. First Test check failed the congruence tactic under ENNReal.ofReal; explicit congrArg and nonzero denominator field simplification yielded PASS. That failed compiler recovery printed sorryAx, not a valid theorem or an intentional placeholder; its full failed raw source/log are retained. The private kernel inspection initially used reserved matches identifier; consumerEntries fixes diagnostic syntax only. No signature/source binder, theorem condition, heartbeat/query cap or environment pin changed.'
attempt=b/'proof-attempts';attempt.mkdir(exist_ok=False)
for name in ['producer-first.raw.lean.gz','consumer-first.raw.lean.gz','kernel-probe-keyword-failure.raw.lean.gz']:
 raw=(Path('.astis/huanjian-fixed-spectrum-normalizer-20261108')/name).read_bytes();q=attempt/name;q.write_bytes(raw);assert q.read_bytes()==raw
put(attempt/'implementation-failure-classification.json',{'failure_class':'IMPLEMENTATION_FAILED','mathematical_refutation':False,'description':failures,'salvage':'Both exact source producer and actual consumer compile; canonical proof parent and anonymous literal statement checks pass. No mathematical fragment was discarded or public premise added.'})
record={'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'state':'COMPILED_LOCAL_INDEPENDENT_SOURCE_REVIEW_PENDING',
 'mathematical_result':'For literal source d>=2,kappa>=2 and every full real O, actual exp(-x^T A x/2) is Integrable against unweighted Euclidean Lebesgue volume AND its actual integral equals (2pi)^(real d/2)/sqrt(product literal lambda).',
 'actual_consumer':'The same actual N(0,Ainv) equals volume.withDensity ofReal(weight/(actual integral of same weight)), with actual mass proved positive internally. Only Z is independent of O.',
 'source_gap_implementation_map':mapping,'production_and_Test_sha256':files,
 'actual_ASTIS_producer_parents':parents,'actual_ASTIS_consumer_parents':consumer_parents,
 'actual_standard_producer_and_consumer_axioms':['propext','Classical.choice','Quot.sound'],
 'actual_checks':{'focused_actual_producer_and_consumer':build,'kernel_parent_inventory':kernel,'anonymous_literal_statement_application':anon,'draft_publication_validation':publication},
 'implementation_failures':failures,'Test_name_projection':str(b/'actual-consumer-interface/test-private-name-projection.json'),
 'not_mathematical_novelty':'Build jobs, names, scripts, metadata and counts are observability only. Mathematical delta is actual finite Lebesgue mass/value and its genuine normalized-law use with exact canonical reuse.',
 'source_fidelity':'Draft; independent fresh raw-first and genuine anonymous blind decoding are in separate roles, before selective comparison and full-module/reader review.',
 'boundaries_open':['independent current sourceV, canonicalroot/site/graph/desktop-mobile immutable acceptance',
 'fullC4 calculus/minimizer and strict historical angle/cosine route, moments/Krylov',
 'actual adaptive/private-seed/transcript/output, exact oracle/finiteprecision/TV and deterministic worstcap/explicit expectedcost adapters',
 'both complete main lower bounds with distinct parameter domains',
 'remote originalowner release/publication, postmerge purification/ExpositionSeal and wholeGoal']}
put(b/'local-proof-capsule.json',record)
put(b/'actual-checks/completed-executions-manifest.json',{'rule':'Actual completed raw receipt/log pairs, including failed diagnostics. No running self-log snapshots.','checks':checks})
cp=Path('research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-normalizer.json')
foreign={str(p):p.read_bytes() for p in cp.parent.glob('*.json') if p!=cp}
x=json.loads(cp.read_bytes());x['status']='proved_locally'
x['conceptual_mirror_audit']['reason']='Actual proof reuses the identical canonical actual precision, determinant and Gaussian density nodes. Finite probability-density mass/integrability and positive normalization are direct ordinary measure/integration adapters, with no new cross-domain transport. No duplicate generic result or new weaker conceptual mirror is introduced; the unrelated existing oracle-factorization bridge remains unchanged.'
x['reuse_plan']['reused_declarations']=parents
x['reuse_plan']['decision_reason']='One literal source integral/value edge, reusing actual canonical matrix/density results and standard finite-mass integration facts. The genuine same-A Test uses the new integral in its actual denominator; no generic normalization wrapper or assumed certificate.'
x['shared_floor_audit']['note']=x['reuse_plan']['decision_reason']
x['evidence']['actual_compiled_producer_parents']=parents;x['evidence']['actual_compiled_Gaussian_consumer_parents']=consumer_parents
x['evidence']['local_proof_capsule']=str(b/'local-proof-capsule.json');x['evidence']['focused_checks']=[build['receipt'],kernel['receipt'],anon['receipt']]
x['evidence']['actual_consumer_interface']['status']='EXACT_PROPOSITION_COMPILED_ACTUAL_NEW_PRODUCER_DEPENDENCY_VERIFIED_LOCAL_SOURCE_REVIEW_PENDING'
x['evidence']['execution_boundary']=record['mathematical_result']+' Genuine same-A actual-integral normalized Gaussian consumer compiles; actual kernel parent inventory confirms real new producer use, standard three axioms only. Independent sourceV/integration/remote/purification/wholeGoal remain separate.'
x['source_detail_audit']['fidelity_boundary']=x['evidence']['execution_boundary']
x['source_proof_coverage']['current_implementation_mapping']=str(b/'local-proof-capsule.json')+'#/source_gap_implementation_map'
x['source_proof_coverage']['original_source_freezes_unchanged']=True
x['learning_contract']['failure_class']='IMPLEMENTATION_FAILED'
x['learning_contract']['salvage']={'required':True,'status':'completed','reason':failures,'promoted_fragments':['Exact integral/value producer and actual normalized-law consumer compile with actual canonical proof dependencies.'],'discarded_fragments':[]}
put(cp,x)
states=a.current_advances();assert states[aid]['state']=='EXPLORING'
lp=Path('runs/substantive_advances.jsonl');before=lp.read_bytes();discovery=Path('runs/substantive_discoveries.jsonl').read_bytes()
a.transition_advance(aid,to_state='PROVED_LOCAL',worker_id=owner,evidence={
 'result_kind':'theorem-edge','theorem_delta':record['mathematical_result'],'lean_files':list(files),
 'lean_declarations':[decl],'publication_declarations':[decl],
 'focused_checks':[build,kernel,anon,{'draft_publication':publication,'independent_source_review':'pending'}],
 'actual_compiled_producer_parents':parents,'actual_Gaussian_consumer_parents':consumer_parents,
 'conceptual_mirror_audit':x['conceptual_mirror_audit'],'capsule':str(b/'local-proof-capsule.json'),'truth_boundary':record['boundaries_open']})
after=lp.read_bytes();now=a.current_advances()
assert after.startswith(before) and len(after[len(before):].splitlines())==1
assert all(now[k]==v for k,v in states.items() if k!=aid)
assert Path('runs/substantive_discoveries.jsonl').read_bytes()==discovery and all(Path(p).read_bytes()==raw for p,raw in foreign.items())
put(b/'normal-proved-local-preservation.json',{'actual_state':now[aid]['state'],'before_sha256':sha(before),'after_sha256':sha(after),'append_sha256':sha(after[len(before):]),'append_events':1,'exact_prefix_preserved':True,'foreign_states_preserved':len(states)-1,'foreign_frontier_files_preserved':len(foreign),'discovery_ledger_unchanged':True,'sourceV_created_by_root':False,'canonical_integration':False})
rp=b.parent/'README.md';old=rp.read_bytes();lead=('# Current continuation: actual Gaussian integral and normalized-law consumer compile locally\n\nRead `fixed-spectrum-normalizer-semantic-evidence/local-proof-capsule.json`. Actual source weight is Integrable over unweighted Euclidean Lebesgue volume AND its actual integral equals (2pi)^(real d/2)/sqrt(productlambda), at exact d>=2,kappa>=2/fullrealO. Genuine same-A Gaussian normalized-law consumer uses that actual integral consequentially; kernel inventory confirms new producer plus three existing canonical parents, standard three axioms only. Normal PROVED_LOCAL, no self sourceV. Initial local-definition/congruence and inspection-keyword failures are preserved and corrected without changing statement or caps.\n\nFresh raw-first source reviewer and anonymous-only blind decoder are separate, followed by selective comparison/secondfreeze before full-module/reader/sourceV. Existing identical compiled nodes share canonical identity; no new conceptual transport. Both main lower bounds, full C4 calculus/minimizer/moments/Krylov, actual adaptive/oracle/precision/TV/deterministic/expected-cost adapters and canonical integration/remote/purification/Seal/wholeGoal remain open. All older results/foreign queues and checkpoints remain preserved.\n\n').encode();rp.write_bytes(lead+old);assert rp.read_bytes()[len(lead):]==old
print(json.dumps({'state':now[aid]['state'],'foreign_states_preserved':len(states)-1,'foreign_frontiers_preserved':len(foreign),'actual_producer_parents':parents,'actual_consumer_parent_count':len(consumer_parents),'sourceV':'pending'}))
