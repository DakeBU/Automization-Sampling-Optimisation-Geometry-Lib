from pathlib import Path
import json,hashlib,copy,datetime,stat
ROOT=Path('/Users/zhouhuanjian/ASTIS-GC')
BASE=ROOT/'.astis/semantic-neutral-20261110'
P1=BASE/'z_sg_7d14a2';P2=BASE/'z_sg_7d14a2_phase2';OWN=BASE/'z_sg_7d14a2_scope_label_successor'
def sha(x):return hashlib.sha256(x).hexdigest()
def save(n,o): (OWN/n).write_text(json.dumps(o,indent=2,ensure_ascii=False)+'\n')
original=(P1/'root-closure-map.json').read_bytes()
assert len(original)==4948 and sha(original)=='dcbc5fef1a4a047ad71db98f6810b6475dafc474414a88fc77ccb63ed7862d8a'
a=json.loads(original)
pointer='/roots/2/conditional_scope'
old='Unconditional within H:ranges, H:fixed-budget, and H:uniform-accuracy where applicable'
new='Conditional on 2T + 1 > d, within H:ranges, H:fixed-budget, and H:uniform-accuracy where applicable'
assert a['roots'][2]['root']=='L:large-branch-conclusion'
assert a['roots'][2]['conditional_scope']==old
marker=b'"root": "L:large-branch-conclusion"'
assert original.count(marker)==1
start=original.index(old.encode(),original.index(marker));end=start+len(old.encode())
corrected=original[:start]+new.encode()+original[end:]
b=json.loads(corrected)
expected=copy.deepcopy(a);expected['roots'][2]['conditional_scope']=new
assert b==expected
assert corrected[:start]==original[:start]
assert corrected[start+len(new.encode()):]==original[end:]
(OWN/'original-root-closure-map.json').write_bytes(original)
(OWN/'corrected-root-closure-map.json').write_bytes(corrected)
# Enumerate all scalar leaves and every container shape: exactly one scalar differs.
leaves=[];containers=[];deltas=[]
def esc(x):return str(x).replace('~','~0').replace('/','~1')
def walk(x,y,path=''):
 assert type(x) is type(y),(path,type(x),type(y))
 if isinstance(x,dict):
  assert list(x.keys())==list(y.keys()),path
  containers.append({'pointer':path,'type':'object','ordered_keys':list(x.keys()),'preserved':True})
  for k in x:walk(x[k],y[k],path+'/'+esc(k))
 elif isinstance(x,list):
  assert len(x)==len(y),path
  containers.append({'pointer':path,'type':'array','length':len(x),'preserved':True})
  for i,(v,w) in enumerate(zip(x,y)):walk(v,w,path+'/'+str(i))
 else:
  eq=x==y
  rec={'pointer':path,'preserved':eq}
  if eq:rec['value']=x
  else:
   rec.update(old_value=x,new_value=y);deltas.append({'op':'replace','path':path,'old_value':x,'value':y})
  leaves.append(rec)
walk(a,b)
assert deltas==[{'op':'replace','path':pointer,'old_value':old,'value':new}]
save('exact-json-delta.json',{'schema':'one-field-scope-label-metadata-successor-v1','original':{'path':str(P1/'root-closure-map.json'),'bytes':len(original),'sha256':sha(original)},'derived':{'file':'corrected-root-closure-map.json','bytes':len(corrected),'sha256':sha(corrected)},'json_delta':deltas,'byte_replacement':{'original_start_byte':start,'original_end_byte_exclusive':end,'old_utf8':old,'new_utf8':new,'bytes_before_and_after_replacement_identical':True},'scope':'Only the conditional_scope metadata string at this pointer changes. This is neither a new source assumption, mathematical repair, type change nor graph topology change.'})
save('value-preservation-report.json',{'schema':'recursive-value-preservation-v1','assertion':'Exactly one scalar JSON value differs; every other scalar value and every object/array shape/key order is preserved. Original and derived bytes outside the single string span are identical.','scalar_leaf_count':len(leaves),'unchanged_scalar_leaf_count':sum(e['preserved'] for e in leaves),'changed_scalar_leaf_count':sum(not e['preserved'] for e in leaves),'container_structure_count':len(containers),'scalar_leaves':leaves,'container_shapes':containers,'mathematical_or_topology_acceptance':'Not asserted; this is a mechanical preservation check.'})
# Existing own frozen packets are checked, never rewritten.
packets=[]
for directory,mname,rname,mhash,rhash in [(P1,'phase1-manifest.json','phase1-receipt.json','c6139e1da52ec5caaaa7d7aaa091a54a37c2f22fbcec1e028924de0d600267af','83255eeb8220e5aa641e8d9e081cb6550f100726851a32a366d64562d7b4c1d0'),(P2,'phase2-manifest.json','phase2-receipt.json','6ae4fe9f4777cc37e0afe6bc262ac5b7885c3bc83ebb69d077c9882a0fbe67f4','b354d131bd2b43d18288206bf33b8ea21282fb4e5f253c109c42f517af6f5593')]:
 mb=(directory/mname).read_bytes();rb=(directory/rname).read_bytes()
 assert sha(mb)==mhash and sha(rb)==rhash
 payload=[]
 for e in json.loads(mb)['payloads']:
  p=directory/e['file'];raw=p.read_bytes()
  assert len(raw)==e['bytes'] and sha(raw)==e['sha256'] and stat.S_IMODE(p.stat().st_mode)==0o444
  payload.append({'file':e['file'],'bytes':len(raw),'sha256':sha(raw),'unchanged':True,'mode':'0444'})
 assert stat.S_IMODE(directory.stat().st_mode)==0o555
 packets.append({'directory':str(directory),'manifest_sha256':sha(mb),'receipt_sha256':sha(rb),'all_payloads_unchanged':True,'directory_mode':'0555','payloads':payload})
save('original-packet-preservation.json',{'schema':'frozen-packets-preserved-v1','packets':packets,'explicit_preserved_objects':['Original generic-label root map bytes','All Phase1 source graph bytes','All Phase1 raw original/fragments/index/coverage bytes','Both exact literal Phase2 type bytes and hashes','All Phase2 overlay/root map/definition audit/coverage-selection bytes'],'old_TC_reports_or_verdict_files':'Not opened or written; the original TC nonblocking observation and original verdict remain untouched.','new_write_scope':str(OWN)})
rawpath=ROOT/'.astis/huanjian-resume-20261103/2610.20492v1.html'
raw=rawpath.read_bytes();assert len(raw)==951991 and sha(raw)=='6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
fragment=raw[176161:177522]
assert len(fragment)==1361 and sha(fragment)=='765c6cfbe19f86588fe24a8e941b1f42f27b6a236ec754228102372d36f5465d'
assert b'alttext="2T+1&gt;d"' in fragment
(OWN/'source-anchor-raw.html').write_bytes(fragment)
save('source-anchor-receipt.json',{'primary_raw_path':str(rawpath),'raw_bytes':len(raw),'raw_sha256':sha(raw),'anchor':'S3.SS3.SSS0.Px1.p1.2','offset_convention':'zero-based original UTF-8 byte range [176161,177522)','fragment_file':'source-anchor-raw.html','fragment_bytes':len(fragment),'fragment_sha256':sha(fragment),'independent_source_reading':'The raw source explicitly introduces the large-budget case with If 2T+1>d before claiming T≥d/2 and the claimed bound. The complement is explicitly assumed afterward. The old generic conditional_scope label fails to retain that already-existing branch condition; the source statement and source graph topology are unchanged.'})
(OWN/'source-anchor-and-scope-explanation.md').write_text('''# One-field scope-label successor

The original raw source paragraph `S3.SS3.SSS0.Px1.p1.2` explicitly makes the large-budget argument conditional on **2T + 1 > d**. Its following sentence proceeds under the complementary range 2T + 1 ≤ d. The existing root statement already names the conditional branch; this correction only carries that same scope into its standalone metadata label.

The derived `corrected-root-closure-map.json` replaces exactly `/roots/2/conditional_scope`:

- Old: `Unconditional within H:ranges, H:fixed-budget, and H:uniform-accuracy where applicable`
- New: `Conditional on 2T + 1 > d, within H:ranges, H:fixed-budget, and H:uniform-accuracy where applicable`

Every other JSON scalar value and every container shape/key order is preserved. Bytes outside this single value span are identical. The original generic-label map is retained both in its unchanged Phase 1 location and as the exact-byte snapshot `original-root-closure-map.json` here. This adds no mathematical assumption: the branch condition was already explicit in the source, root statement and relevant source graph edges.

The Phase 1 and Phase 2 graphs, raw coverage and exact types remain unchanged. No theorem is repaired, no branch is closed, and no source topology is rebuilt. This author-created derived artifact has not yet been accepted by the distinct topology challenger. No HOLD is introduced or implied.
''')
(OWN/'handoff-for-independent-delta-review.md').write_text('''# Handoff to the same distinct topology challenger

Review only the one-field successor recorded in `exact-json-delta.json`: `/roots/2/conditional_scope` now explicitly retains 2T + 1 > d. Use `source-anchor-raw.html` and its original byte receipt, the unchanged original root-map snapshot, the corrected derived map, and `value-preservation-report.json`.

The parent reports that the previous distinct TC Phase 2b verdict was `ACCEPT_BOUNDED_SOURCE_TOPOLOGY_AND_COVERAGE_WITH_OPEN_PROOF_OBLIGATIONS` and that the scope-label observation was nonblocking. This successor preserves that report and does not rewrite, downgrade, rerun or claim to extend the previous verdict. The original TC observation/report files were not opened or edited.

The source author independently reread the pinned raw paragraph and found the condition already explicit. This is only a metadata successor. The derived artifact needs your independent one-delta check before the parent's process grant. No acceptance of this successor by you is claimed here. No target proof/API experiment or implementation was inspected or started by this role.
''')
save('exposure-ledger.json',{'role':'original SOURCE AUTHOR; metadata successor only','new_parent_information':'Parent supplied the previous bounded TC acceptance label and nonblocking scope-label observation; no TC report/verdict file was opened.','actual_reads':['Own frozen Phase1 root-closure-map.json','Pinned original raw paragraph S3.SS3.SSS0.Px1.p1.2, via byte-pinned original HTML','Read-only hash/mode checks of own Phase1/Phase2 manifests, receipts and all their payloads'],'prohibited_inputs_opened':[],'root_process_full_seal_or_old_verdict_file_opened':False,'implementation_or_API_or_targetproof_experiment':False,'old_artifacts_modified':[],'shared_C_or_ledger_mutations':[],'network_calls':[],'write_scope':str(OWN),'independent_review_boundary':'This successor has no TC acceptance yet. Same distinct TC should independently check exactly this delta before process grant. No HOLD invented.'})
# Manifest and receipt bind all successor artifacts without modifying prior packets.
payload=[]
for p in sorted(OWN.iterdir()):
 assert p.is_file()
 if p.name not in ('successor-manifest.json','successor-receipt.json'):
  x=p.read_bytes();payload.append({'file':p.name,'bytes':len(x),'sha256':sha(x),'frozen_mode':'0444'})
manifest={'schema':'one-field-scope-label-successor-manifest-v1','owned_directory':str(OWN),'base_phase1_manifest_sha256':'c6139e1da52ec5caaaa7d7aaa091a54a37c2f22fbcec1e028924de0d600267af','base_phase2_manifest_sha256':'6ae4fe9f4777cc37e0afe6bc262ac5b7885c3bc83ebb69d077c9882a0fbe67f4','original_root_map_sha256':sha(original),'corrected_derived_root_map_sha256':sha(corrected),'changed_JSON_pointer':pointer,'payload_count':len(payload),'payloads':payload,'review_status':'Author-frozen metadata successor; independent same-TC one-delta review pending; no HOLD or new acceptance claim.','manifest_excludes':'Itself and successor-receipt.json to avoid self-hash cycle; receipt binds manifest, receipt hash delivered out of band.'}
mb=(json.dumps(manifest,indent=2)+'\n').encode();(OWN/'successor-manifest.json').write_bytes(mb)
receipt={'schema':'one-field-scope-label-successor-receipt-v1','frozen_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'manifest':{'file':'successor-manifest.json','bytes':len(mb),'sha256':sha(mb)},'original_root_map':{'bytes':len(original),'sha256':sha(original)},'corrected_derived_root_map':{'bytes':len(corrected),'sha256':sha(corrected)},'exactly_one_JSON_value_changed':pointer,'unchanged_scalar_leaves':sum(e['preserved'] for e in leaves),'changed_scalar_leaves':1,'original_phase1_and_phase2_preserved':True,'payload_count':len(payload),'all_files_mode':'0444','directory_mode':'0555','independent_successor_TC_review':'pending; not claimed','receipt_self_digest':'Delivered out of band.'}
rb=(json.dumps(receipt,indent=2)+'\n').encode();(OWN/'successor-receipt.json').write_bytes(rb)
for p in OWN.iterdir():p.chmod(0o444)
OWN.chmod(0o555)
assert all(stat.S_IMODE(p.stat().st_mode)==0o444 for p in OWN.iterdir())
print(json.dumps({'owned_directory':str(OWN),'manifest_bytes':len(mb),'manifest_sha256':sha(mb),'receipt_bytes':len(rb),'receipt_sha256':sha(rb),'corrected_root_map_bytes':len(corrected),'corrected_root_map_sha256':sha(corrected),'changed_scalar_values':len(deltas),'unchanged_scalar_values':sum(e['preserved'] for e in leaves),'preserved_container_shapes':len(containers),'payload_count':len(payload),'total_frozen_files':len(payload)+2,'old_packets_unchanged':True,'same_distinct_TC_delta_review':'pending'},indent=2))
