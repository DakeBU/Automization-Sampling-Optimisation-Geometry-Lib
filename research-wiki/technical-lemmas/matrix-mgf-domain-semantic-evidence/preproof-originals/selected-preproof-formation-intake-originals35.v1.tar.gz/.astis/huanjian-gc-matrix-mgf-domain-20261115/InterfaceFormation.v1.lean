import AutoSamplingTheory.TechnicalLemmas.Probability.RealMatrixPositiveIntegral
import AutoSamplingTheory.TechnicalLemmas.Analysis.MatrixTraceExponentialBounds
import Mathlib.MeasureTheory.Integral.Bochner.ContinuousLinearMap

open MeasureTheory ProbabilityTheory
open scoped BigOperators Matrix.Norms.L2Operator MatrixOrder ENNReal
noncomputable section
universe u v
namespace MatrixMgfDomainInterfaceFormation

def P : Prop :=
∀ {ι : Type u} {Ω : Type v} [Fintype ι] [DecidableEq ι] [MeasurableSpace Ω]
  {μ : Measure Ω} [IsProbabilityMeasure μ],
  ∀ (f : Ω → Matrix ι ι ℝ), Integrable f μ →
    (∀ᵐ ω ∂μ, (f ω).PosDef) → (∫ ω, f ω ∂μ).PosDef

def T : Prop :=
∀ {d q : ℕ} (hq : 2 * q + 1 < d),
  let D := EuclideanSpace ℝ (Fin d)
  let E := EuclideanSpace ℝ (Fin (q + 1))
  let Ω := Fin (q + 1) → D
  let μ : Measure Ω := Measure.pi (fun _ : Fin (q + 1) => stdGaussian D)
  let M := Matrix (Fin (q + 1) × Fin (q + 1)) (Fin (q + 1) × Fin (q + 1)) ℝ
  let r : ℝ := ((q + 1 : ℕ) : ℝ)
  let L : ℝ := 2 * r + 3 * Real.log (1000 * (d : ℝ))
  let α : Fin d → ℝ := fun i => ((i.val : ℝ) + 1 - 1 / 2) * Real.pi / (d : ℝ)
  let tvec : Fin d → Fin (q + 1) → ℝ := fun i k =>
    if k.val = 0 then 1 else Real.sqrt 2 * Real.cos ((k.val : ℝ) * α i)
  let row : Fin d → Ω → E := fun i ω =>
    WithLp.toLp 2 (fun b : Fin (q + 1) => ω b i)
  let Y : Fin d → Ω → M := fun i ω =>
    if ‖row i ω‖ ^ 2 ≤ L then
      (d : ℝ)⁻¹ • Matrix.kronecker
        (Matrix.vecMulVec (WithLp.ofLp (row i ω)) (WithLp.ofLp (row i ω)))
        (Matrix.vecMulVec (tvec i) (tvec i))
    else 0
  let mean : Fin d → M := fun i => ∫ ω, Y i ω ∂μ
  let Z : Fin d → Ω → M := fun i ω => Y i ω - mean i
  let w : Bool → Fin d → ℝ := fun useCos i =>
    if useCos = true then Real.cos (((2 * q + 1 : ℕ) : ℝ) * α i) else 1
  let sign : Bool → ℝ := fun minus => if minus = true then -1 else 1
  let S : Bool → Bool → Ω → M := fun useCos minus ω =>
    sign minus • ∑ i : Fin d, w useCos i • Z i ω
  let Rstar : ℝ := 2 * r * (L + 1) / (d : ℝ)
  ∀ s : ℝ, ∀ useCos minus : Bool,
    let G : Ω → M := fun ω => NormedSpace.exp (s • S useCos minus ω)
    let MX : M := ∫ ω, G ω ∂μ
    let B : ℝ := r ^ 2 * Real.exp (|s| * ((d : ℝ) * Rstar))
    Integrable G μ ∧ MX.PosDef ∧
      Matrix.trace MX = (∫ ω, Matrix.trace (G ω) ∂μ) ∧
      0 < Matrix.trace MX ∧ Matrix.trace MX ≤ B

#check P
#check T
#print P
#print T
end MatrixMgfDomainInterfaceFormation
