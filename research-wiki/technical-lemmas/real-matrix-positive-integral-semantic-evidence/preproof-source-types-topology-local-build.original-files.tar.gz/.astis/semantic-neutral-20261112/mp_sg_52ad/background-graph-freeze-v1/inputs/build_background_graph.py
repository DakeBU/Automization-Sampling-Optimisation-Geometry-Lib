from pathlib import Path
import hashlib,json,re,html,datetime,shutil
ROOT=Path('/Users/zhouhuanjian/ASTIS-GC');BASE=ROOT/'.astis/semantic-neutral-20261112/mp_sg_52ad';TYPE=BASE/'type-freeze-v1';OUT=BASE/'background-graph-freeze-v1'
MLPATH=ROOT/'.lake/packages/mathlib/Mathlib/Analysis/Convex/Integral.lean';PAPERPATH=ROOT/'.astis/huanjian-resume-20261103/2610.20492v1.html'
def sha(b):return hashlib.sha256(b).hexdigest()
def j(p):return json.loads(p.read_text())
assert not OUT.exists()
tm=(TYPE/'freeze-manifest.json').read_bytes();assert sha(tm)=='4b0bab616098bfd3af5c4cf825b9eda8ca3e5033deaf9b04a8b500b2a24b05ec'
for x in json.loads(tm)['files']:
 b=(TYPE/x['path']).read_bytes();assert len(b)==x['bytes'] and sha(b)==x['sha256']
ta=j(TYPE/'type-audit.json');assert sha((TYPE/'type-audit.json').read_bytes())=='33ba7adfa422cda6da33cf7c8714f4846791cdae4d05940658ec0e72832d6122'
packet=j(TYPE/'inputs/selective-type-definition-packet.json');MLB=MLPATH.read_bytes();ML=MLB.decode();assert sha(MLB)=='1b3115887fabf0dccc2fed689d1f1ddc7a114b5de4594e752c02908a445aafb4'
PB=PAPERPATH.read_bytes();PS=PB.decode();assert sha(PB)=='6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
for x in packet['source']['anchors']:
 frag=PB[x['raw_utf8_start']:x['raw_utf8_end']];assert sha(frag)==x['span_sha256'];assert frag==PS[x['char_start']:x['char_end']].encode()
PRINT=packet['minimal_definition_context']['literal_current_prints_and_instances'];PRB=PRINT.encode()
OUT.mkdir();(OUT/'inputs').mkdir();(OUT/'source-fragments').mkdir()
def dump(n,v):(OUT/n).write_text(json.dumps(v,ensure_ascii=False,sort_keys=True,indent=2)+'\n',encoding='utf-8')
def write(n,t):(OUT/n).write_text(t,encoding='utf-8')
shutil.copyfile(TYPE/'type-audit.json',OUT/'inputs/type-audit.json');(OUT/'inputs/type-manifest.json').write_bytes(tm);shutil.copyfile(BASE/'working/build_background_graph.py',OUT/'inputs/build_background_graph.py')
(OUT/'inputs/Mathlib.Analysis.Convex.Integral.lean.source.txt').write_bytes(MLB);(OUT/'inputs/2610.20492v1.html').write_bytes(PB);(OUT/'inputs/literal-definition-prints.txt').write_bytes(PRB)
bind=dict(ta['bindings'],type_audit_sha256=sha((TYPE/'type-audit.json').read_bytes()),type_manifest_sha256=sha(tm),mathlib_convex_integral_source_sha256=sha(MLB),primary_paper_source_sha256=sha(PB))
def locate(text,a,z):
 b=text.encode();x=len(text[:a].encode());y=len(text[:z].encode());return {'utf8_byte_start':x,'utf8_byte_end_exclusive':y,'unicode_char_start':a,'unicode_char_end_exclusive':z,'lf_line_start_1based':text.count('\n',0,a)+1,'lf_line_end_1based':text.count('\n',0,z-1)+1,'raw_fragment_sha256':sha(b[x:y])}
lines=ML.splitlines(keepends=True);line_offsets=[0]
for line in lines:line_offsets.append(line_offsets[-1]+len(line))
units={};inventory=[]
def add(id,origin,a,z,status,kind,meaning,reason=None,sl=None):
 text={'MATHLIB':ML,'PAPER':PS,'LITERAL_PRINT':PRINT}[origin];ll=locate(text,a,z)
 v={'id':id,'origin':origin,'locator':ll,'disposition':status,'kind':kind,'meaning':meaning,'status':'BACKGROUND_SOURCE_EXTRACTION_UNPROVED_NEW_TARGET'}
 if reason:v['reason']=reason
 if sl:v['semantic_slice']=sl
 inventory.append(v);units[id]={'origin':origin,'locator':ll};(OUT/'source-fragments'/f'{id}.txt').write_bytes(text[a:z].encode());return v
def ml(id,lo,hi,status,kind,m,r=None,sl=None):return add(id,'MATHLIB',line_offsets[lo-1],line_offsets[hi],status,kind,m,r,sl)
def element(id):
 m=re.search(r'<([A-Za-z][\w:]*)\b[^>]*\bid="'+re.escape(id)+r'"[^>]*>',PS);assert m,id;dep=1
 for n in re.finditer(r'</?'+re.escape(m[1])+r'\b[^>]*>',PS[m.end():]):
  dep+=-1 if n[0].startswith('</') else 1
  if not dep:return m.start(),m.end()+n.end()
 raise ValueError(id)
def paper(id,anchor,status,k,m,r=None,sl=None):
 a,z=element(anchor);v=add(id,'PAPER',a,z,status,k,m,r,sl);v['source_element_id']=anchor;return v

# Paper source: an application need, not the authored arbitrary-f theorem.
paper('PAPER.fourth-invocation','A3.SS2.p14.1','EXCLUDED','source moment invocation','Gaussian fourth moments invoked.','Shared positivity-under-integration does not supply a Gaussian moment.')
paper('PAPER.fourth-identity','A3.Ex113','EXCLUDED','source exact moment','E[R_i gamma_i gamma_i^T]=(r+2)I.','Concrete Gaussian input remains outside this generic bridge.')
paper('PAPER.offdiagonal','A3.SS2.p14.2','EXCLUDED','source proof clause','Off-diagonal sign-symmetry argument.','Concrete fourth-moment proof outside bridge.','First clause')
paper('PAPER.diagonal','A3.SS2.p14.2','EXCLUDED','source proof clause','Diagonal3+(r-1)=r+2.','Concrete fourth-moment proof outside bridge.','Second clause')
paper('PAPER.gaussian-square','A3.SS2.p14.2','EXCLUDED','rank-one source identity','(gamma gamma^T)^2=R gamma gamma^T.','Literal algebra of concrete consumer, not provided by generic bridge.','First Since identity')
paper('PAPER.feature-square','A3.SS2.p14.2','EXCLUDED','rank-one source identity','(t t^T)^2=||t||^2 t t^T.','Literal algebra of concrete consumer, not provided by generic bridge.','Second Since identity')
paper('PAPER.actual-Y-square-context','A3.Ex114','NODE','concrete application context','Actual Yi^2 equals its untruncated PSD tensor majorant times the closed local cutoff indicator.')
paper('PAPER.drop-cutoff','A3.SS2.p14.3','NODE','unnamed application need','Drop cutoff in a PSD expression before its expectation comparison. No arbitrary-f integration theorem is printed.')
paper('PAPER.integrated-uncentered-bound','A3.Ex115','NODE','source consumer use','Actual sum of squared-matrix expectations is PSD-dominated by its untruncated expected majorant.')
paper('PAPER.norm-factor-step','A3.Ex116','EXCLUDED','source order calculation','Replace ||t_i||^2 by2r.','Deterministic frame/order algebra is beyond generic integral positivity.')
paper('PAPER.frame-sum-step','A3.Ex117','EXCLUDED','source simplification','Simplify tensor Gram sum to2r(r+2)/d I.','Generic bridge alone gives no final variance bound.')
paper('PAPER.frame-citation','A3.SS2.p14.4','EXCLUDED','source use statement','Use ||t_i||^2<=2r and unweighted frame identity.','Concrete deterministic consumer obligation.','First sentence')
paper('PAPER.centered-equality','A3.Ex118','EXCLUDED','source exact mean identity','E Zi^2=E Yi^2-(EYi)^2.','Noncommutative integral expansion is separate from generic PSD preservation.','Equality clause')
paper('PAPER.centered-order-need','A3.Ex118','NODE','second source application need','The centered square mean is PSD-bounded by the uncentered mean; actual expected squares must retain full PSD.','Final inequality clause')
paper('PAPER.variance-parameter','A3.SS2.p14.5','EXCLUDED','source variance assertion','Centered sequence variance parameter bound.','Generic bridge does not establish the complete norm bound.')
paper('PAPER.variance-scale','A3.Ex119','EXCLUDED','source constant','v*=2r(r+2)/d.','No variance constant is concluded by generic bridge.')
paper('PAPER.weighted-variance','A3.SS2.p14.6','EXCLUDED','source variance assertion','Same weighted variance upper bound.','Generic bridge alone does not prove weighted variance.')
paper('PAPER.weight-square-equality','A3.Ex120','EXCLUDED','source scalar/mean algebra','E[(c_i Zi)^2]=c_i^2 E Zi^2.','Separate deterministic scalar integral algebra.','Equality clause')
paper('PAPER.weighted-PSD-need','A3.Ex120','NODE','second source application need','c_i^2 E Zi^2<=PSD E Zi^2 needs PSD of actual centered-square expectation.','Final inequality clause')

# Chosen bounded upstream background theorem, with full proof-region coverage.
ml('ML.typing-context',46,47,'NODE','upstream standing context','Arbitrary measurable alpha; complete normed real vector space E; actual mu,s,f.')
ml('ML.integral-mem-doc',54,56,'NODE','upstream source statement/documentation','Probability expectation of an integrable AE-valued function lies in a closed convex set. Doc cites Convex.sum_mem as finite analogue.')
for id,m,sl in [
 ('probability','IsProbabilityMeasure mu.','probability instance'),('convex','Convex Real s.','hs'),('closed','IsClosed s.','hsc'),('AE','AE x,f x in s.','hf'),('integrable','Integrable f mu.','hfi'),('conclusion','Integral_mu f belongs to s.','conclusion')]:
 ml('ML.contract.'+id,57,58,'NODE','upstream theorem binder/conclusion',m,sl=sl)
ml('ML.borel-setup',59,59,'NODE','upstream proof setup','borelize E is internal setup, not a public assumption on arbitrary sample space.')
ml('ML.AE-representative',60,60,'NODE','substantive upstream proof step','Extract a strongly measurable g AE equal to f from integrability.')
ml('ML.separable-range',61,62,'NODE','substantive upstream proof step','The range(g) intersect s inherits a separable space.')
ml('ML.nonempty-range',63,65,'NODE','substantive upstream proof step','AE membership and AE equality under probability supply a point in range(g) intersect s.')
ml('ML.AE-integral-rewrite',66,66,'NODE','substantive upstream proof step','Rewrite integral and integrability using AE equality.')
ml('ML.closure-membership',67,70,'NODE','substantive upstream proof step','g lies AE in closure(range(g) intersect s).')
ml('ML.simple-approximants',71,71,'NODE','upstream source definition','Define SimpleFunc approximants on the separable intersection with an anchor point.')
ml('ML.integral-limit',72,73,'NODE','upstream cited theorem application','tendsto_integral_approxOn_of_measurable supplies convergence of approximant integrals to integral g.')
ml('ML.closed-convex-final',74,74,'NODE','upstream proof composition','Closedness accepts the limit; convexity accepts each finite weighted approximant integral via hs.sum_mem.')
ml('ML.weights-nonnegative',75,75,'NODE','upstream unnamed estimate','All ENNReal.toReal measure weights are nonnegative.')
ml('ML.weights-sum-one',76,79,'NODE','upstream substantive proof step','Simple-function fiber weights sum to mu(univ)=1, with finiteness discharged.')
ml('ML.approximant-range',80,83,'NODE','upstream substantive proof step','SimpleFunc.approxOn_mem places every approximant value in range(g) intersect s, hence in s.')
ml('ML.header-and-navigation',1,45,'EXCLUDED','source license/import/overview context','License, imports, overview/Jensen navigation and scoped names.','Preserved as source exposure and provenance; imports do not certify ASTIS theorem dependencies.')
ml('ML.section-heading',48,53,'EXCLUDED','source heading/whitespace','Non-strict Jensen heading.','No separate mathematical claim.')
# Each other theorem is explicitly excluded; body spans end at its following documentation block.
decl=list(re.finditer(r'^theorem\s+(\S+)',ML,re.M))
for ix,m in enumerate(decl):
 if m[1]=='Convex.integral_mem':continue
 next_start=decl[ix+1].start() if ix+1<len(decl) else len(ML)
 doc=ML.rfind('/--',m.end(),next_start)
 end=doc if doc!=-1 else next_start
 add('ML.EXCLUDED.'+m[1],'MATHLIB',m.start(),end,'EXCLUDED','other upstream theorem and proof',m[1],'Other average/set-average/Jensen/strict-convex claims are outside this selected generic PSD-integral route. Full file exposure is disclosed; no new target dependency inferred.')

# Literal standard definition semantics supplied in the exact packet.
for id,start_pat,end_pat,m in [
 ('DEF.PSD','def Matrix.PosSemidef.','def Matrix.IsHermitian.','Full IsHermitian AND every finite quadratic form nonnegative.'),
 ('DEF.Hermitian','def Matrix.IsHermitian.','def Matrix.conjTranspose.','conjugate transpose equals the matrix.'),
 ('DEF.conjTranspose','def Matrix.conjTranspose.','def Matrix.vecMulVec.','Transpose then entrywise real star.'),
 ('DEF.Integrable','def MeasureTheory.Integrable.','def MeasureTheory.HasFiniteIntegral.','AE strongly measurable plus finite extended-norm integral.'),
 ('DEF.HasFiniteIntegral','def MeasureTheory.HasFiniteIntegral.','def MeasureTheory.AEStronglyMeasurable.','Extended-norm integral is below infinity.'),
 ('DEF.AEstrong','def MeasureTheory.AEStronglyMeasurable.','@[irreducible] def MeasureTheory.integral.','Existence of a strongly measurable AE-equal representative.')]:
 a=PRINT.index(start_pat);z=PRINT.index(end_pat,a+len(start_pat));add(id,'LITERAL_PRINT',a,z,'NODE','supplied literal standard definition',m)
dump('source-inventory.json',{'bindings':bind,'classification':'BACKGROUND_EXPANSION_NOT_PRIMARY_PAPER_GENERAL_THEOREM','items':inventory,
 'bounded_coverage':'Every substantive original p14 clause is NODE/EXCLUDED; upstream inherited context plus Convex.integral_mem lines54–83 is fully atomized. Every other theorem of the exposed upstream file is explicitly EXCLUDED. Only supplied standard literal definition blocks listed here are in definition scope.',
 'no_whole_paper_or_whole_mathlib_claim':True,'counts':{'items':len(inventory),'NODE':sum(x['disposition']=='NODE' for x in inventory),'EXCLUDED':sum(x['disposition']=='EXCLUDED' for x in inventory)}})
dump('source-locators.json',{'source_hashes':{'MATHLIB':sha(MLB),'PAPER':sha(PB),'LITERAL_PRINT':sha(PRB)},'convention':'Zero-based half-open UTF8 byte and Unicode character offsets in exact source snapshots; LF lines one-based inclusive; raw fragment hashes. Shared ranges carry semantic slices.','units':units})

portspec=[
 ('INTERNAL.PSD-cone-definition','Identify s={M:Matrix n n Real | PosSemidef M} with the complete supplied Hermitian/quadratic predicate, for all finite n including empty.'),
 ('INTERNAL.PSD-cone-convex','Prove/apply convexity of that full PSD set over Real; preserve the Hermitian conjunct as well as every quadratic inequality.'),
 ('INTERNAL.PSD-cone-closed','Prove/apply closedness in the actual L2Operator matrix topology; no entrywise/sup-topology mismatch or supplied geometry premise.'),
 ('INTERNAL.Matrix-complete-space','Match arbitrary finite real matrix L2Operator normed/real-vector/complete structures, including empty n, to upstream theorem E.'),
 ('INTERNAL.AE-and-probability','Match generic mu probability, arbitrary measurable Omega, hf and AE hpos to Convex.integral_mem without extra Measurable f, Nonempty n, nonempty-cone, Borel-Omega or representative assumptions.'),
 ('INTERNAL.convex-integral-application','Apply exact upstream Convex.integral_mem once cone geometry and all typed/AE/integrability instances match; identify set membership with full output PSD. No ASTIS proof is certified here.'),
 ('INTERNAL.direct-Hermitian-integral','Alternative: derive Hermitian of the integral from AE Hermitian f via justified continuous linear entry/conjugate-transpose maps and AE integral equality.'),
 ('INTERNAL.direct-quadratic-integral','Alternative: for every finite-support vector, justify its continuous real linear quadratic-in-matrix evaluation, integrability and commuting with the Bochner integral, then integrate its AE nonnegativity.'),
 ('INTERNAL.direct-PSD-combine','Combine direct Hermitian and quadratic integral conclusions. These two conjuncts form an AND inside the direct route; the whole direct route is OR with the closed-convex-set route.'),
 ('INTERNAL.actual-residual-hf','For source Ex115, construct the actual original-experiment PSD residual from the untruncated majorant minus Yi^2 and prove actual integrability internally; no new hf binder on R9.'),
 ('INTERNAL.actual-residual-hpos','Prove full pointwise/AE PSD of that actual residual from the closed local cutoff and literal rank-one/tensor definition, not by supplying a desired expectation bound as a premise.'),
 ('INTERNAL.actual-residual-integral','After generic application, identify its actual Bochner integral with the concrete expectation difference using justified integral subtraction, tensor transport and finite sum algebra. Shared positivity alone is not the final R9 bound.'),
 ('INTERNAL.centered-square-consumers','For Ex118/120, prove actual centered/weighted square integrability and AE full PSD internally, then use shared positivity for their actual integral matrices. The source-based second consumer family is planned; no compiled call or public private-test provider is claimed.')]
ports=[{'id':id,'kind':'INTERNAL_UNPROVED_APPLICABILITY_OR_ALGEBRA','meaning':m,'genuine_SOURCE_GAP':False,'compiled_parents':[]} for id,m in portspec]
dump('internal-ports-and-source-gaps.json',{'bindings':bind,'ports':ports,'genuine_source_gaps':[],
 'scope':'Paper omits this general lemma. That absence is explicit authored background expansion, not a source defect or permission to strengthen Gaussian binders.',
 'upstream_boundary':'The external theorem is present in a snapshotted source file; it is not an ASTIS-owned compiled parent or evidence of successful PSD-cone application.',
 'OR_policy':'Closed-convex-set theorem route OR direct Hermitian-and-quadratic integral route. All ports remain unproved.'})

nodes=[{'id':v['id'],'kind':v['kind'],'meaning':v['meaning'],'origin':v['origin'],'locator':v['locator'],'status':'SOURCE_PRESENT_NOT_NEW_TARGET_PROOF'} for v in inventory if v['disposition']=='NODE']
nodes += [{'id':v['id'],'kind':v['kind'],'meaning':v['meaning'],'status':'OPEN_INTERNAL'} for v in ports]
nodes += [
 {'id':'AUTHORED.hf','kind':'Generic authored contract input','meaning':'Integrable arbitrary actual f under probability mu.'},
 {'id':'AUTHORED.hpos','kind':'Generic authored contract input','meaning':'AE full PSD of arbitrary actual f.'},
 {'id':'AUTHORED.probability','kind':'Generic authored contract input','meaning':'Arbitrary probability mu.'},
 {'id':'FORMAL.shared-producer','kind':'Exact authored background target','name':packet['producer']['name'],'signature_sha256':packet['producer']['signature_sha256'],'status':'UNPROVED_NOT_PRINTED_IN_PAPER'},
 {'id':'APPLICATION.R9-PSD-residual','kind':'Intended actual consumer interface','name':packet['actual_consumer']['name'],'signature_sha256':packet['actual_consumer']['signature_sha256'],'status':'SEALED_UNCHANGED_UNPROVED'},
 {'id':'APPLICATION.centered-weighted-squares','kind':'Second source consumer family','meaning':'PSD of actual integral centered/weighted squares needed at Ex118/120.','status':'PLANNED_SOURCE_APPLICATION_NOT_COMPILED'}]
edges=[]
def e(a,b,use,m,kind='Background/source dependency'):
 if isinstance(use,str):use=[use]
 edges.append({'from':a,'to':b,'kind':kind,'meaning':m,'consumer_use_sites':[{'unit_id':u,**units[u]} for u in use],'compiled_dependency':False})
# Literal upstream proof graph (not invented paper topology).
e('ML.contract.integrable','ML.AE-representative','ML.AE-representative','Extract hfi.aestronglyMeasurable representative.')
e('ML.AE-representative','ML.separable-range','ML.separable-range','Strong measurability gives separable range intersection.')
for a in ['ML.contract.AE','ML.contract.probability','ML.AE-representative']:e(a,'ML.nonempty-range','ML.nonempty-range','AE membership/equality under probability produce the anchor point.')
for a in ['ML.AE-representative','ML.contract.integrable']:e(a,'ML.AE-integral-rewrite','ML.AE-integral-rewrite','AE equality rewrites actual integral/integrability.')
for a in ['ML.contract.AE','ML.AE-representative']:e(a,'ML.closure-membership','ML.closure-membership','AE membership transfers to closure of range intersection.')
for a in ['ML.separable-range','ML.nonempty-range','ML.AE-representative']:e(a,'ML.simple-approximants','ML.simple-approximants','Construct source SimpleFunc.approxOn sequence.')
for a in ['ML.simple-approximants','ML.closure-membership','ML.AE-integral-rewrite']:e(a,'ML.integral-limit','ML.integral-limit','Use named upstream approximation convergence source call.')
e('ML.simple-approximants','ML.weights-nonnegative','ML.weights-nonnegative','Finite integral coefficients are measureReal weights.')
for a in ['ML.simple-approximants','ML.contract.probability']:e(a,'ML.weights-sum-one','ML.weights-sum-one','Weights sum to mu(univ)=1; finiteness discharged in source.')
for a in ['ML.simple-approximants','ML.nonempty-range']:e(a,'ML.approximant-range','ML.approximant-range','approxOn_mem gives each value inside s.')
for a in ['ML.contract.convex','ML.contract.closed','ML.integral-limit','ML.weights-nonnegative','ML.weights-sum-one','ML.approximant-range']:e(a,'ML.closed-convex-final','ML.closed-convex-final','Convex weighted sums followed by closed-limit membership.')
for a in ['ML.closed-convex-final','ML.AE-integral-rewrite']:e(a,'ML.contract.conclusion','ML.closed-convex-final','Upstream proof concludes actual integral membership.')
# New authored background application, explicitly distinct from upstream proof and primary paper.
e('DEF.PSD','INTERNAL.PSD-cone-definition','DEF.PSD','Identify full real PSD cone.','Internal authored specialization')
for a in ['INTERNAL.PSD-cone-definition','DEF.Hermitian','DEF.PSD']:e(a,'INTERNAL.PSD-cone-convex','DEF.PSD','Convexity needs both Hermitian and quadratic clauses.','Internal unproved geometry')
for a in ['INTERNAL.PSD-cone-definition','DEF.Hermitian','DEF.PSD']:e(a,'INTERNAL.PSD-cone-closed','DEF.PSD','Closedness in actual L2Operator topology remains unproved.','Internal unproved geometry')
for a in ['AUTHORED.hf','AUTHORED.hpos','AUTHORED.probability','ML.contract.AE','ML.contract.integrable']:e(a,'INTERNAL.AE-and-probability','ML.contract.AE','Match the exact generic inputs without strengthening the contract.','Internal applicability')
for a in ['INTERNAL.PSD-cone-definition','INTERNAL.PSD-cone-convex','INTERNAL.PSD-cone-closed','INTERNAL.Matrix-complete-space','INTERNAL.AE-and-probability','ML.contract.conclusion']:e(a,'INTERNAL.convex-integral-application','ML.contract.conclusion','Closed-convex-set sufficient background route; not a compiled ASTIS proof.','Internal authored route')
for a in ['AUTHORED.hf','AUTHORED.hpos','DEF.Hermitian','DEF.AEstrong']:e(a,'INTERNAL.direct-Hermitian-integral','DEF.Hermitian','Alternative direct Hermitian transport needs actual integral/AE applicability.','Internal alternative route')
for a in ['AUTHORED.hf','AUTHORED.hpos','DEF.PSD','DEF.Integrable']:e(a,'INTERNAL.direct-quadratic-integral','DEF.PSD','Alternative direct real quadratic functional transport/positivity.','Internal alternative route')
for a in ['INTERNAL.direct-Hermitian-integral','INTERNAL.direct-quadratic-integral']:e(a,'INTERNAL.direct-PSD-combine','DEF.PSD','Both full PSD conjuncts are required within this alternative route.','Internal AND within direct route')
# OR applications to real consumers: no new Gaussian hypotheses or proof file assumed.
for a in ['PAPER.actual-Y-square-context','PAPER.drop-cutoff']:e(a,'INTERNAL.actual-residual-hf','PAPER.integrated-uncentered-bound','Concrete integrability must be derived under original product mu.','Intended actual consumer obligation')
for a in ['PAPER.actual-Y-square-context','PAPER.drop-cutoff']:e(a,'INTERNAL.actual-residual-hpos','PAPER.integrated-uncentered-bound','Concrete PSD residual must be proved internally before generic use.','Intended actual consumer obligation')
for a in ['FORMAL.shared-producer','INTERNAL.actual-residual-hf','INTERNAL.actual-residual-hpos']:e(a,'INTERNAL.actual-residual-integral','PAPER.integrated-uncentered-bound','Generic hf/hpos discharged at use; required intended application, no observed compiled call.','Intended actual shared-consumer use')
e('INTERNAL.actual-residual-integral','APPLICATION.R9-PSD-residual','PAPER.integrated-uncentered-bound','Return to unchanged concrete R9 expectation-difference interface.','Intended actual consumer interface')
for a in ['FORMAL.shared-producer','PAPER.centered-order-need','PAPER.weighted-PSD-need']:e(a,'INTERNAL.centered-square-consumers',['PAPER.centered-order-need','PAPER.weighted-PSD-need'],'Second family needs actual square integrability and PSD before application.','Planned concrete use')
e('INTERNAL.centered-square-consumers','APPLICATION.centered-weighted-squares',['PAPER.centered-order-need','PAPER.weighted-PSD-need'],'Integral PSD supports source comparisons, not a full variance proof.','Planned concrete use')
graph={'version':1,'classification':'ASTIS_AUTHORED_BACKGROUND_GRAPH_WITH_PRIMARY_APPLICATION_CONTEXT','bindings':bind,'owned_root_full_path':str(BASE),
 'background_source_full_path':str(MLPATH),'background_source_sha256':sha(MLB),'mathlib_pin_scope':'Nominal pin supplied by exact packet. Actual file bytes snapshotted and hashed; no Git operation was used to independently verify checkout metadata.',
 'primary_source_full_path':str(PAPERPATH),'nodes':nodes,'edges':edges,
 'hyperedges':[{'id':'OR.integral-PSD','premise_formula':'INTERNAL.convex-integral-application OR INTERNAL.direct-PSD-combine','conclusion':'FORMAL.shared-producer','origin':'Two unproved authored-background sufficient options; the paper does not print these as its proof routes.','status':'OPEN_UNPROVED'}],
 'scope_boundary':'Paper p14 supplies application need only. Upstream Convex.integral_mem supplies a general closed-convex integral statement/proof. PSD-cone specialization and concrete applications are authored internal work, not a paper general theorem or extra R9 premise.',
 'genuine_source_gaps':[],'compiled_parents':[],'new_shared_proof_seen':False,'independent_topology_acceptance':'PENDING_DISTINCT_REVIEWER; no self-approval','permission_or_status_grant':False}
dump('background-source-graph.json',graph)
dump('coverage.json',{'bindings':bind,'inventory_counts':{'items':len(inventory),'NODE':sum(v['disposition']=='NODE' for v in inventory),'EXCLUDED':sum(v['disposition']=='EXCLUDED' for v in inventory)},
 'primary_window':'Original A3.SS2.p14 all substantive clauses represented or excluded. Other primary source is not claimed covered.',
 'upstream_window':'Inherited variable context46–47 and full Convex.integral_mem54–83 proof. Every other theorem in the read file is EXCLUDED; no whole-library coverage claim.',
 'literal_definition_window':'Exactly listed supplied standard definition blocks, not their entire containing source files.',
 'selected_upstream_lines_disposed':list(range(54,84)),'primary_all_substantive_p_and_tables':[v['id'] for v in inventory if v['origin']=='PAPER'],
 'not_independent_approval':True})
dump('source-exposure-and-attribution.json',{'bindings':bind,'chronology':'Independent shared type verdict froze before this actor read the newly authorized Mathlib Convex/Integral.lean as background source. Original R9 p14 raw source reading predates the shared type; old originals are untouched.',
 'Mathlib_source_exposure':'Entire specified Integral.lean file344 LF lines was read, including existing upstream proof bodies. It is explicitly authorized background source, not ROOT old/new target implementation or an API-search verdict.',
 'primary_exposure':'Exact pinned paper HTML reread only for p14 and listed anchors; this does not imply that it states the authored generic theorem.',
 'formalizer_API_pristine':False,'old_local_exposure':'Parent reports old local proof/API fully exposed and no new shared proof/API attempt yet. No ROOT implementation, TC opinion, prior verdict or other graph was opened by this actor for this new background graph.',
 'new_ASTIS_proof_seen':False,'no_import_based_proof_edges':True,'no_extra_Gaussian_inputs':True,
 'no_git_or_shared_mutation':True,'no_proof_or_permission_grant':True})
write('background-reading-report.md','The general arbitrary-f probability lemma is an explicit ASTIS-authored background expansion. Paper p14 motivates an integrated PSD residual at Ex115 and expected centered/weighted-square positivity at Ex118/120; it does not print this general theorem. The fixed-pin Mathlib Convex.integral_mem source states/proves membership of an integrable AE-valued probability expectation in a closed convex set. Its representative, separability, nonempty-anchor, simple-approximation, probability weights and closed-limit proof regions are independently inventoried. Specialization to the full PSD cone still requires closedness/convexity in actual L2Operator topology and complete/AE/probability/integrability applicability. The direct Hermitian-and-quadratic integral route is an OR alternative, not falsely conjoined with the cone route. Each actual Gaussian residual/square must supply generic hf/hpos internally; no R9 binder changes or guessed public/private provider/compiled parents. All ports remain unproved. Type verdict precedes graph extraction; distinct topology review remains pending.\n')
write('README.md','Shared-background graph/source freeze after independent type verdict. Read background-source-graph.json, source-inventory.json, source-locators.json, internal-ports-and-source-gaps.json and attribution report. Primary paper application context, upstream background proof and ASTIS-authored expansion are explicitly distinct. No new target proof, compiled-parent or permission/status grant.\n')
m={'format':'astis-real-matrix-positive-integral-background-graph-freeze-v1','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'bindings':bind,'phase':'BACKGROUND_SOURCE_GRAPH_AFTER_TYPE_FREEZE','files':[]}
for f in sorted(OUT.rglob('*')):
 if f.is_file():b=f.read_bytes();m['files'].append({'path':str(f.relative_to(OUT)),'bytes':len(b),'sha256':sha(b)})
dump('freeze-manifest.json',m);dig=sha((OUT/'freeze-manifest.json').read_bytes());write('freeze-manifest.sha256',dig+'  freeze-manifest.json\n')
for f in OUT.rglob('*'):
 if f.is_file():f.chmod(0o444)
for d in sorted([d for d in OUT.rglob('*') if d.is_dir()],key=lambda d:len(d.parts),reverse=True):d.chmod(0o555)
OUT.chmod(0o555)
print(json.dumps({'background_graph_path':str(OUT),'graph_sha256':sha((OUT/'background-source-graph.json').read_bytes()),'inventory_sha256':sha((OUT/'source-inventory.json').read_bytes()),'coverage_sha256':sha((OUT/'coverage.json').read_bytes()),'locators_sha256':sha((OUT/'source-locators.json').read_bytes()),'ports_sha256':sha((OUT/'internal-ports-and-source-gaps.json').read_bytes()),'graph_manifest_sha256':dig,'atoms':len(inventory),'nodes':len(nodes),'edges':len(edges),'OR_routes':1,'internal_ports':len(ports),'genuine_source_gaps':[]},indent=2))
