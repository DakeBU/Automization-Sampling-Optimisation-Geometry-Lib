from pathlib import Path
from html.parser import HTMLParser
import hashlib
import json
import re

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT.parents[1] / 'huanjian-resume-20261103/2610.20492v1.html'
RAW = SOURCE.read_bytes()
EXPECTED = '6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
assert hashlib.sha256(RAW).hexdigest() == EXPECTED
TEXT = RAW.decode('utf-8')
LINES = [0]
for match in re.finditer('\n', TEXT):
    LINES.append(match.end())
BYTE = [0]
for char in TEXT:
    BYTE.append(BYTE[-1] + len(char.encode('utf-8')))


class Node:
    def __init__(self, tag, attrs, start, parent):
        self.tag, self.attrs, self.start, self.end = tag, dict(attrs), start, None
        self.parent, self.children = parent, []

    @property
    def id(self):
        return self.attrs.get('id')

    @property
    def classes(self):
        return self.attrs.get('class', '').split()

    def descendants(self):
        for child in self.children:
            if isinstance(child, Node):
                yield child
                yield from child.descendants()

    def render(self):
        if self.tag == 'math':
            return ' $' + self.attrs.get('alttext', '') + '$ '
        return ''.join(x.render() if isinstance(x, Node) else x for x in self.children)

    def normalized(self):
        return re.sub(r'\s+', ' ', self.render()).strip()

    def locator(self):
        assert self.end is not None
        return {'start_byte': BYTE[self.start], 'end_byte_exclusive': BYTE[self.end],
                'length': BYTE[self.end] - BYTE[self.start],
                'sha256': hashlib.sha256(RAW[BYTE[self.start]:BYTE[self.end]]).hexdigest()}


class Parser(HTMLParser):
    VOID = {'area', 'base', 'br', 'col', 'embed', 'hr', 'img', 'input', 'link', 'meta', 'param', 'source', 'track', 'wbr'}

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.root = Node('root', {}, 0, None)
        self.root.end = len(TEXT)
        self.stack = [self.root]
        self.by_id = {}

    def position_offset(self):
        line, column = self.getpos()
        return LINES[line - 1] + column

    def handle_starttag(self, tag, attrs):
        node = Node(tag, attrs, self.position_offset(), self.stack[-1])
        self.stack[-1].children.append(node)
        if node.id:
            assert node.id not in self.by_id, node.id
            self.by_id[node.id] = node
        if tag in self.VOID:
            node.end = node.start + len(self.get_starttag_text())
        else:
            self.stack.append(node)

    def handle_startendtag(self, tag, attrs):
        self.handle_starttag(tag, attrs)
        if self.stack[-1].tag == tag:
            self.stack.pop().end = self.position_offset() + len(self.get_starttag_text())

    def handle_endtag(self, tag):
        stop = TEXT.index('>', self.position_offset()) + 1
        assert self.stack[-1].tag == tag, (tag, self.stack[-1].tag, self.getpos())
        self.stack.pop().end = stop

    def handle_data(self, data):
        self.stack[-1].children.append(data)


PARSER = Parser()
PARSER.feed(TEXT)
assert len(PARSER.stack) == 1
NODES = list(PARSER.root.descendants())


def dump(ids):
    for ident in ids:
        node = PARSER.by_id[ident]
        print(ident, node.locator(), node.normalized())


if __name__ == '__main__':
    import sys
    if len(sys.argv) > 1 and sys.argv[1] == 'section':
        section = PARSER.by_id[sys.argv[2]]
        for node in section.descendants():
            if 'ltx_para' in node.classes or re.fullmatch('h[1-6]', node.tag):
                print(node.id, node.locator(), node.normalized())
    else:
        dump(sys.argv[1:])
