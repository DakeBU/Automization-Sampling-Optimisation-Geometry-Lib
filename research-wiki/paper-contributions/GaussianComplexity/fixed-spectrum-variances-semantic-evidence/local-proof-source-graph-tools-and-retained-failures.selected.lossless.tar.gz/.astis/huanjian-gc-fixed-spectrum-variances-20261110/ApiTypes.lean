import Mathlib.Probability.Distributions.Gaussian.Multivariate
import Mathlib.Probability.Moments.MGFAnalytic
import Mathlib.Probability.Distributions.Gaussian.HasGaussianLaw.Independence
import Mathlib.Tactic
open Lean
run_cmd do
  let env ← getEnv
  let names := ["ProbabilityTheory.IsGaussian.hasGaussianLaw_id",
    "ProbabilityTheory.HasGaussianLaw.map_equiv_fun", "PiLp.continuousLinearEquiv",
    "ProbabilityTheory.HasGaussianLaw.iIndepFun_of_covariance_eq_zero",
    "ProbabilityTheory.iIndepFun.indepFun", "ProbabilityTheory.IndepFun.comp",
    "MeasureTheory.MeasurePreserving.memLp_comp", "MeasureTheory.MemLp.comp_measurePreserving",
    "MeasureTheory.MeasurePreserving.variance_fun_comp", "MeasureTheory.MemLp.const_mul",
    "MeasureTheory.MemLp.finset_sum", "MeasureTheory.MemLp.sum", "MeasureTheory.MemLp.fun_sum",
    "ProbabilityTheory.variance_fun_sum", "ProbabilityTheory.IndepFun.variance_sum",
    "ProbabilityTheory.variance_const_mul", "ProbabilityTheory.variance_eq_sub",
    "ProbabilityTheory.variance_id_gaussianReal", "MeasureTheory.MemLp.sub_const",
    "MeasureTheory.MemLp.integrable_sq", "MeasureTheory.MemLp.integrable_norm_pow",
    "MeasureTheory.memLp_two_iff_integrable_sq_norm"]
  for (n, ci) in env.constants.toList do
    let s := n.toString
    if names.contains s || s.endsWith "MemLp.pow" ||
        s.startsWith "ProbabilityTheory.iIndepFun.indepFun" ||
        s.startsWith "MeasureTheory.MeasurePreserving.integral_comp" then
      logInfo m!"{n}: {ci.type}"
