

const source=fs.readFileSync("/Users/zhouhuanjian/ASTIS-GC/.astis/huanjian-gc-fixed-spectrum-cosine-gram-20261110/reader-step-neighbor-v4-independent-0a91de/copy-handler.exact.js",'utf8'),codes=JSON.parse(fs.readFileSync("/Users/zhouhuanjian/ASTIS-GC/.astis/huanjian-gc-fixed-spectrum-cosine-gram-20261110/reader-step-neighbor-v4-independent-0a91de/copy-handler-code-inputs.json",'utf8'));
await (async()=>{const results=[];for(const [index,text] of codes.entries())for(const mode of ['clipboard','fallback','clipboard-failure']){
 let handler,written=null,status={textContent:''},calls=[];
 const code={textContent:text};const panel={querySelector:s=>{calls.push(s);assert.equal(s,':scope > pre > code');return code}};
 const parent={querySelector:s=>{calls.push(s);assert.equal(s,'[data-lean-copy-status]');return status}};
 const button={disabled:false,parentElement:parent,closest:s=>{assert.equal(s,'[data-lean-code-panel]');return panel}};
 const selection={removeAllRanges:()=>calls.push('removeAllRanges'),addRange:()=>calls.push('addRange')};
 const document={addEventListener:(event,fn)=>{assert.equal(event,'click');handler=fn},createRange:()=>({selectNodeContents:n=>{assert.equal(n,code);written=n.textContent}}),execCommand:s=>{assert.equal(s,'copy');return true}};
 const navigator=mode==='fallback'?{}:{clipboard:{writeText:async value=>{if(mode==='clipboard-failure')throw Error('fixture failure');written=value}}};
 vm.runInNewContext(source,{document,navigator,window:{getSelection:()=>selection}});
 await handler({target:{closest:s=>{assert.equal(s,'[data-lean-copy]');return button}}});
 assert.equal(button.disabled,false);
 if(mode==='clipboard-failure'){assert.equal(status.textContent,'Copy failed; select the Lean code below.');assert.equal(written,null)}
 else{assert.equal(written,text);assert.equal(status.textContent,'Copied')}
 results.push({step:index+1,mode,passed:true,utf8Bytes:Buffer.byteLength(text,'utf8')});
 }fs.writeFileSync("/Users/zhouhuanjian/ASTIS-GC/.astis/huanjian-gc-fixed-spectrum-cosine-gram-20261110/reader-step-neighbor-v4-independent-0a91de/copy-handler-contract-results.json",JSON.stringify({scope:'Unchanged actual handler with mock DOM/clipboard; no live browser acceptance',results},null,2)+'\n');nodeRepl.write({checks:results.length,passed:results.length});})();
