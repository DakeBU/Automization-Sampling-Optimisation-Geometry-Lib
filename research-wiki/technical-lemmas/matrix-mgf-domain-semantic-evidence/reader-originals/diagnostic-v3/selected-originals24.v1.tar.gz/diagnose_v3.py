"""One separately authorized, observational R17 v3 timing/overflow diagnostic; no acceptance run."""
import argparse, datetime as dt, hashlib, json, os, sys, threading, time, traceback
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urljoin

OWN=Path(__file__).resolve().parent
REPO=OWN.parents[2]
PROOF='proofs/huanjian-matrix-mgf-domain.html'
MODULE='modules/tests-gaussiancomplexitymatrixmgfdomain.html'
TARGET='Tests/GaussianComplexityMatrixMgfDomain.lean.html#L187'

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,x):
    with Path(p).open('x') as f:f.write(json.dumps(x,ensure_ascii=False,indent=2)+'\n')

SAMPLE=r'''()=>{
 const e=document.getElementById('L187'),p=e.closest('pre'),r=e.getBoundingClientRect(),pr=p.getBoundingClientRect();
 const box=r=>({left:r.left,right:r.right,top:r.top,bottom:r.bottom,width:r.width,height:r.height});
 let header=0;const hs=[...document.querySelectorAll('header,.mobile-bar,.verification-strip')];
 for(let pass=0;pass<hs.length+1;pass++)for(const h of hs){const s=getComputedStyle(h),q=h.getBoundingClientRect();
  if(['fixed','sticky'].includes(s.position)&&s.display!=='none'&&s.visibility!=='hidden'&&q.width>0&&q.height>0&&q.right>0&&q.left<innerWidth&&q.bottom>0&&q.top<=header+1)header=Math.max(header,q.bottom);}
 let clip={left:0,right:innerWidth,top:header+4,bottom:innerHeight-4};
 for(let a=e.parentElement;a;a=a.parentElement){const s=getComputedStyle(a),q=a.getBoundingClientRect();
  if(['hidden','clip','scroll','auto'].includes(s.overflowX)){clip.left=Math.max(clip.left,q.left+a.clientLeft);clip.right=Math.min(clip.right,q.left+a.clientLeft+a.clientWidth);}
  if(['hidden','clip','scroll','auto'].includes(s.overflowY)){clip.top=Math.max(clip.top,q.top+a.clientTop);clip.bottom=Math.min(clip.bottom,q.top+a.clientTop+a.clientHeight);}}
 return{performance_ms:performance.now(),url:location.href,readyState:document.readyState,fontsStatus:document.fonts.status,
  viewport:{width:innerWidth,height:innerHeight},windowScroll:{x:scrollX,y:scrollY},scrollingElement:{top:document.scrollingElement.scrollTop,left:document.scrollingElement.scrollLeft,maxTop:document.scrollingElement.scrollHeight-document.scrollingElement.clientHeight},
  htmlScrollBehavior:getComputedStyle(document.documentElement).scrollBehavior,target:box(r),pre:{...box(pr),scrollLeft:p.scrollLeft,scrollTop:p.scrollTop,scrollWidth:p.scrollWidth,clientWidth:p.clientWidth,scrollHeight:p.scrollHeight,clientHeight:p.clientHeight,overflowX:getComputedStyle(p).overflowX,overflowY:getComputedStyle(p).overflowY},
  header,clip,intersectionWidth:Math.max(0,Math.min(r.right,clip.right)-Math.max(r.left,clip.left)),intersectionHeight:Math.max(0,Math.min(r.bottom,clip.bottom)-Math.max(r.top,clip.top))};
}'''

OVERFLOW=r'''()=>{
 const v=innerWidth;
 const path=e=>{let xs=[];for(let p=e;p&&xs.length<9;p=p.parentElement){let s=p.tagName.toLowerCase();if(p.id){s+='#'+p.id;xs.unshift(s);break;}if(p.classList.length)s+='.'+[...p.classList].join('.');xs.unshift(s);}return xs.join(' > ');};
 const rect=r=>({left:r.left,right:r.right,top:r.top,bottom:r.bottom,width:r.width,height:r.height});
 const info=e=>{const r=e.getBoundingClientRect(),s=getComputedStyle(e);return{path:path(e),tag:e.tagName,id:e.id,className:e.className,rect:rect(r),clientWidth:e.clientWidth,scrollWidth:e.scrollWidth,
   display:s.display,position:s.position,minWidth:s.minWidth,maxWidth:s.maxWidth,width:s.width,boxSizing:s.boxSizing,overflowX:s.overflowX,overflowY:s.overflowY,gridTemplateColumns:s.gridTemplateColumns,
   whiteSpace:s.whiteSpace,overflowWrap:s.overflowWrap,wordBreak:s.wordBreak,font:s.font,fontSize:s.fontSize,lineHeight:s.lineHeight,paddingLeft:s.paddingLeft,paddingRight:s.paddingRight,textLength:e.textContent.length};};
 const clippingAncestor=e=>{for(let p=e.parentElement;p;p=p.parentElement){const s=getComputedStyle(p);if(['auto','scroll','hidden','clip'].includes(s.overflowX))return info(p);}return null;};
 const rows=[];
 for(const e of document.querySelectorAll('body *')){const r=e.getBoundingClientRect(),s=getComputedStyle(e);if(s.display==='none'||r.width<=0)continue;
  if(r.right>v+.5||r.left<-.5||e.scrollWidth>e.clientWidth+1){const clip=clippingAncestor(e);let ancestors=[];for(let p=e.parentElement;p&&ancestors.length<9;p=p.parentElement)ancestors.push(info(p));
   rows.push({...info(e),rectOutsideViewport:r.right>v+.5||r.left<-.5,nearestXClippingAncestor:clip,localScrollPaneWithinViewport:!!clip&&['auto','scroll'].includes(clip.overflowX)&&clip.rect.left>=-.5&&clip.rect.right<=v+.5,ancestors});}}
 const targets=['html','body','main','.page-hero','.module-meta','.declaration-list','.declaration-list > details.declaration','.declaration-content','.declaration-list pre.code-block','#complete-module-source','#complete-module-source details','#complete-module-source pre.code-block'];
 return{performance_ms:performance.now(),url:location.href,viewport:{width:v,height:innerHeight},document:{html:document.documentElement.scrollWidth,body:document.body.scrollWidth,htmlRect:rect(document.documentElement.getBoundingClientRect()),bodyRect:rect(document.body.getBoundingClientRect())},
  allDetails:[...document.querySelectorAll('main details')].map(e=>({path:path(e),open:e.open})),targeted:targets.map(selector=>({selector,elements:[...document.querySelectorAll(selector)].map(info)})),overflowCandidates:rows,description:'Read-only computed geometry; rectOutsideViewport and locally clipped scroll contents are distinguished. No overflow-owner repair performed.'};
}'''

class Quiet(SimpleHTTPRequestHandler):
    def log_message(self,*_):pass

def open_all(main):
    # Actual summary clicks only. Playwright may naturally bring each click target into view.
    for detail in main.locator('details').all():
        if not detail.evaluate('(e)=>e.open'):detail.locator(':scope>summary').click()

def signature(s):
    return [s['windowScroll']['x'],s['windowScroll']['y'],s['pre']['scrollLeft'],s['pre']['scrollTop'],s['target']['top'],s['target']['bottom'],s['target']['left'],s['target']['right']]

def main(args,a):
    assert a['authorization']=='ROOT_AUTHORIZED_DIAGNOSTIC_ONLY'
    assert sha(__file__)==a['diagnostic_script_sha256']
    for row in a['frozen_inputs']:assert sha(row['path'])==row['sha256']
    preview=Path(a['preview_root']);fixture=preview/'fixtures/candidate'
    manifest=json.loads((preview/'preview-freeze-manifest.json').read_text())
    rows=manifest['variants']['candidate']['files']
    assert len(rows)==110 and {str(p.relative_to(fixture)) for p in fixture.rglob('*') if p.is_file()}=={r['path'] for r in rows}
    for r in rows:assert sha(fixture/r['path'])==r['sha256']
    chrome=Path(a['chrome']['path']);assert sha(chrome)==a['chrome']['binary_sha256']
    output=OWN/'runtime-output';output.mkdir(exist_ok=False)
    tmp=OWN/'chrome-tmp';tmp.mkdir(mode=0o700,exist_ok=False);os.environ['TMPDIR']=str(tmp)
    import tempfile
    tempfile.tempdir=str(tmp)
    server=ThreadingHTTPServer(('127.0.0.1',0),partial(Quiet,directory=str(fixture)))
    worker=threading.Thread(target=server.serve_forever,daemon=True);worker.start()
    origin='http://127.0.0.1:'+str(server.server_port)
    result={'schema':'R17-v3-actual-observational-timing-overflow-diagnostic-v1','not_an_acceptance_run':True,'no_new_normalAPI_V_Lean_Git_or_site_action':True,'preview_manifest_sha256':sha(preview/'preview-freeze-manifest.json'),'assignment_sha256':sha(args.assignment),'script_sha256':sha(__file__),'cases':[],'screenshots':[],'requests':[],'responses':[],'console':[],'page_errors':[],'blocked_external_requests':[],'exceptions':[]}
    browser=None
    def shot(page,name):
        p=output/(name+'.png');page.screenshot(path=str(p));result['screenshots'].append({'path':str(p.relative_to(OWN)),'sha256':sha(p)})
    try:
        from playwright.sync_api import sync_playwright
        with sync_playwright() as pw:
            try:
                browser=pw.chromium.launch(executable_path=str(chrome),headless=True)
                result['actual_Chrome_version']=browser.version
                for label,w,h in [('desktop',1440,1000),('mobile',390,844)]:
                    context=browser.new_context(viewport={'width':w,'height':h},device_scale_factor=1)
                    def route(route):
                        url=route.request.url
                        if url.startswith(origin+'/') or url.startswith(('data:','blob:')):route.continue_()
                        else:result['blocked_external_requests'].append(url);route.abort()
                    context.route('**/*',route);page=context.new_page()
                    page.on('request',lambda r:result['requests'].append({'url':r.url,'method':r.method,'resource_type':r.resource_type}))
                    page.on('response',lambda r:result['responses'].append({'url':r.url,'status':r.status}))
                    page.on('console',lambda m:result['console'].append({'type':m.type,'text':m.text}))
                    page.on('pageerror',lambda e:result['page_errors'].append(str(e)))
                    case={'viewport_label':label,'CSS_viewport':{'width':w,'height':h},'headless_not_physical_touch':True};result['cases'].append(case)
                    try:
                        page.goto(urljoin(origin+'/',PROOF),wait_until='networkidle')
                        page.wait_for_function('!!(window.MathJax&&MathJax.startup&&MathJax.startup.promise)')
                        page.evaluate('async()=>{await MathJax.startup.promise;await MathJax.typesetPromise();}')
                        open_all(page.locator('article.proof-reader'))
                        source=page.locator('details.proof-reader-step').nth(4).locator('a[data-step-source]')
                        assert source.get_attribute('href').endswith(TARGET)
                        with page.expect_navigation(wait_until='networkidle'):source.click()
                        t0=time.monotonic();first=page.evaluate(SAMPLE);first['relative_ms']=(time.monotonic()-t0)*1000
                        case['anchor_trace']=[first];shot(page,label+'-L187-networkidle-immediate')
                        stable=False
                        while time.monotonic()-t0<5:
                            page.wait_for_timeout(100);sample=page.evaluate(SAMPLE);sample['relative_ms']=(time.monotonic()-t0)*1000;case['anchor_trace'].append(sample)
                            tail=case['anchor_trace'][-4:]
                            if len(tail)==4 and sample['relative_ms']>=500 and all(max(v)-min(v)<=.25 for v in zip(*(signature(x) for x in tail))):stable=True;break
                        case['natural_stability']={'observed':stable,'max_observation_seconds':5,'four_samples_100ms_apart_tolerance_css_px':.25,'minimum_elapsed_ms':500,'no_programmatic_anchor_scroll_or_transform':True}
                        shot(page,label+'-L187-natural-settled-or-timeout')
                        case['after_final_screenshot']=page.evaluate(SAMPLE)
                        if label=='mobile':
                            page.goto(urljoin(origin+'/',MODULE),wait_until='networkidle')
                            open_all(page.locator('main'))
                            case['mobile_module_overflow_after_actual_disclosure_clicks']=page.evaluate(OVERFLOW)
                            shot(page,'mobile-T-module-overflow-after-disclosures')
                    except BaseException:
                        case['exception']=traceback.format_exc();result['exceptions'].append(case['exception'])
                    finally:context.close()
            finally:
                if browser:browser.close()
    except BaseException:result['exceptions'].append(traceback.format_exc())
    finally:
        server.shutdown();server.server_close();worker.join()
        result['server_and_worker_stopped']=not worker.is_alive()
    result['fixture110_bytes_unchanged']=all(sha(fixture/r['path'])==r['sha256'] for r in rows)
    result['status']='DIAGNOSTIC_COMPLETED' if not result['exceptions'] else 'DIAGNOSTIC_FAILED'
    dump(OWN/'actual-diagnostic.json',result)
    print(json.dumps({'status':result['status'],'acceptance_verdict':None,'cases':len(result['cases']),'actual_PNGs':len(result['screenshots']),'actual_diagnostic_sha256':sha(OWN/'actual-diagnostic.json'),'server_and_worker_stopped':result['server_and_worker_stopped']}))
    return 0 if not result['exceptions'] and result['fixture110_bytes_unchanged'] and result['server_and_worker_stopped'] else 1

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--assignment',type=Path,required=True);args=parser.parse_args()
    a=json.loads(args.assignment.read_text())
    if a.get('authorization')!='ROOT_AUTHORIZED_DIAGNOSTIC_ONLY':raise RuntimeError('Preparation only; a new ROOT diagnostic assignment and scoped browser approval are required.')
    os.umask(0o077);process=OWN/'runtime-process';process.mkdir(exist_ok=False)
    for fd,name in [(1,'stdout.raw'),(2,'stderr.raw')]:
        f=(process/name).open('xb',buffering=0);os.dup2(f.fileno(),fd);f.close()
    utc=dt.datetime.now(dt.timezone.utc).isoformat();start=time.monotonic();code=1
    try:code=main(args,a)
    except BaseException:traceback.print_exc()
    sys.stdout.flush();sys.stderr.flush()
    dump(process/'receipt.json',{'schema':'R17-actual-observational-diagnostic-OS-receipt-v1','argv':[sys.executable,*sys.argv],'cwd':str(Path.cwd()),'pid':os.getpid(),'ppid':os.getppid(),'started_utc':utc,'ended_utc':dt.datetime.now(dt.timezone.utc).isoformat(),'elapsed_seconds':time.monotonic()-start,'actual_exit_code':code,'script_sha256':sha(__file__),'assignment_sha256':sha(args.assignment),'stdout_sha256':sha(process/'stdout.raw'),'stderr_sha256':sha(process/'stderr.raw'),'actual_OS_fd1_fd2_until_exit':True,'acceptance_verdict':None})
    sys.exit(code)
