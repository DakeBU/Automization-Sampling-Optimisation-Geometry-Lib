from pathlib import Path
import hashlib
import json
from datetime import datetime, timezone
from bs4 import BeautifulSoup
from extract_source import ROOT, OUT, EXPECTED

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def write(name,value):
    (OUT/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')

assert not (OUT/'freeze.json').exists(), 'Phase one is already frozen; do not mutate it.'
g=json.loads((OUT/'source-graph.json').read_text())
c=json.loads((OUT/'coverage.json').read_text())
nodes={n['id'] for n in g['nodes']}
assert len(nodes)==len(g['nodes'])
assert all(r in nodes for e in g['edges'] for r in e['parents']+[e['child']])
assert all(r in nodes for u in c['units'] for r in u.get('nodes',[]))
assert all(u['disposition'] in ['NODE','EXCLUDED'] for u in c['units'])
assert all(u.get('reason') for u in c['units'] if u['disposition']=='EXCLUDED')
assert len({u['coverage_id'] for u in c['units']})==len(c['units'])

incoming={n:set() for n in nodes}
for e in g['edges']:
    incoming[e['child']].update(e['parents'])
remaining=set(nodes)
order=[]
while remaining:
    ready=sorted(n for n in remaining if not (incoming[n]&remaining))
    assert ready, 'Unexpected source graph cycle.'
    order.extend(ready)
    remaining.difference_update(ready)

s=BeautifulSoup((OUT/'source-original.html').read_bytes(),'html.parser')
assert sha(OUT/'source-original.html')==EXPECTED
missing_math=[]
for k in ['S1','S2','S4','A3.SS4']:
    for m in s.find(id=k).find_all('math'):
        if not any(p.name in ['p','table','tbody','figcaption','h2','h3','h4','h5','h6'] for p in m.parents):
            missing_math.append(m.get('id'))
assert not missing_math
for n in g['nodes']:
    assert all(s.find(id=a) is not None for a in n['source_anchors'])
for e in g['edges']:
    assert s.find(id=e['consumer_use_site']) is not None

write('structural-check.json',{
 'status':'structural-check-only-passed',
 'source_sha256':EXPECTED,
 'nodes':len(g['nodes']),'edges':len(g['edges']),
 'source_gap_nodes':sum(n['kind']=='SOURCE_GAP' for n in g['nodes']),
 'coverage_counts':c['coverage_counts'],
 'checks':['Every graph reference resolves','Every coverage node reference resolves','Every selected unit has NODE or EXCLUDED with a reason','Coverage IDs are unique','Directed graph is acyclic','All node/source-use anchors exist in the pinned original','Selected source mathematical fragments are inside inventoried block types','Full original raw source SHA256 matches the assigned pin'],
 'topological_order':order,
 'boundary':'This deterministic structure check neither independently approves mathematical coverage/topology nor proves any source statement or SOURCE_GAP.'})

helpers={}
for name in ['extract_source.py','build_phase1.py','freeze_phase1.py']:
    p=ROOT/'.astis/huanjian-fixed-spectrum-admissibility-20261107/source-graph'/name
    helpers[str(p.relative_to(ROOT))]=sha(p)
payload={p.name:sha(p) for p in sorted(OUT.iterdir()) if p.is_file() and p.name not in ['rawhashes.json','freeze.json']}
write('rawhashes.json',{'algorithm':'SHA-256','phase1_payload_files':payload,'private_helper_inputs':helpers,
  'self_exclusion':'rawhashes.json and freeze.json are excluded to avoid a self-referential hash; freeze.json binds rawhashes.json, and its own digest is sent to root.'})
write('freeze.json',{
 'phase':'phase1', 'role':'independent-source-only-extractor',
 'frozen_at_utc':datetime.now(timezone.utc).isoformat(),
 'source_sha256':EXPECTED,
 'rawhashes_sha256':sha(OUT/'rawhashes.json'),
 'source_graph_sha256':sha(OUT/'source-graph.json'),
 'coverage_sha256':sha(OUT/'coverage.json'),
 'source_contract_sha256':sha(OUT/'source-contract.json'),
 'exposure_manifest_sha256':sha(OUT/'exposure-manifest.json'),
 'raw_inputs_sha256':sha(OUT/'raw-inputs.json'),
 'payload_file_count':len(payload),
 'status':'frozen-before-candidate-exposure; pending-distinct-review-and-phase2',
 'stop_rule':'Do not mutate phase1 or inspect any candidate until root is sent these freeze hashes and then supplies the exact candidate and necessary meanings.'})
print(json.dumps({'freeze_sha256':sha(OUT/'freeze.json'), **json.loads((OUT/'freeze.json').read_text())},ensure_ascii=False,indent=2))
