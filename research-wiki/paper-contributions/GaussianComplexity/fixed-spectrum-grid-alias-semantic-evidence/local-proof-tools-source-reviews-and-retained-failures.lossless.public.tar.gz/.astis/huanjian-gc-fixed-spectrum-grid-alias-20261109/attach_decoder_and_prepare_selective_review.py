from pathlib import Path
import hashlib,json,sys
sys.dont_write_bytecode=True
sys.path.insert(0,'tools');import astis_semantic_roundtrip as rt
W=Path('.astis/huanjian-gc-fixed-spectrum-grid-alias-20261109')
E=Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-grid-alias-semantic-evidence')
D=Path('.astis/semantic-neutral-20261109/6c92f7')
sha=lambda b:hashlib.sha256(b).hexdigest()
dump=lambda o:(json.dumps(o,ensure_ascii=False,indent=2)+'\n').encode()
def put(p,b):
 assert not p.exists(),p;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
assert sha((D/'manifest.json').read_bytes())=='10c8f7f75f659abc201ba9917beda61ff26c4b69119c412e64e466db07e1287b'
run=json.loads((D/'decoder-run.json').read_text());recon=json.loads((D/'reconstruction.json').read_text());text=(D/'reconstructed-theorem.md').read_text()
assert sha((D/'input.json').read_bytes())==run['raw_input_sha256']=='9e27743f78f5722f849f1c50b80b35120f9eeab40e5b2b57e6862d897906845e'
assert sha((D/'decoder-run.json').read_bytes())==recon['decoder_run_sha256']=='57878d5a62d27e38378b9c24605a122a7490e4d26e33877cd0ec43d4f9eb0313'
assert text==recon['reconstructed_theorem_text'] and sha(text.encode())==recon['reconstructed_text_sha256']
assert run['source_text_visible'] is False and recon['source_text_visible'] is False
ap=Path('research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-grid-alias.json');old=ap.read_bytes();a=json.loads(old)
assert a['state']=='draft' and a['reconstruction']=={} and a['semantic_slots']=={} and a['source_review']=={'state':'pending'}
packet=rt.decoder_packet(a);assert packet['packet_sha256']==run['packet_canonical_sha256']
a['state']='blind-reconstructed'
a['reconstruction']={'text':text,'text_sha256':recon['reconstructed_text_sha256'],'decoder':'/root/decoder_6c92f7','source_text_visible':False,'lean_statement_sha256':a['lean']['statement_sha256'],'decoder_packet_sha256':packet['packet_sha256'],'decoder_run_sha256':sha((D/'decoder-run.json').read_bytes()),'input_artifacts':packet['input_artifacts'],'ambient_cues_disclosed':run['ambient_exposures'],'zero_ambient_cues_claimed':False}
dest=E/'independent-decoder-6c92f7';assert not dest.exists();dest.mkdir()
for p in D.iterdir():
 if p.is_file():put(dest/p.name,p.read_bytes())
put(E/'audit-before-independent-reconstruction.raw.json',old)
ap.write_bytes(dump(a))
full=rt.semantic_reviewer_packet(a);assert all(v is False for v in full['anti_anchoring'].values())
put(E/'fresh-source-reviewer-packet.json',dump(full))
seal=json.loads((W/'statement-seal-v2.json').read_text());head,body=seal['actual_private_consumer']['signature'].split(' :\n',1)
consumer='∀'+head.removeprefix('private theorem actual_weighted_inverse_grid_alias_series')+',\n'+body
white={'schema_version':1,'task':'selective-source-statement-reconstruction-comparison','parent_canonical_packet_sha256':full['packet_sha256'],'source':{k:full['source'][k] for k in ['source_id','anchor','original_text','text_sha256']},'lean_statement':{k:full['lean'][k] for k in ['statement','statement_sha256']},'approved_definition_context':a['lean']['decoder_context'],'blind_reconstruction':{k:full['blind_reconstruction'][k] for k in ['text','text_sha256','decoder','decoder_packet_sha256','decoder_run_sha256','source_text_visible']},'private_consumer_statement':consumer}
def keys(x):
 if isinstance(x,dict):
  for k,v in x.items():yield k;yield from keys(v)
 elif isinstance(x,list):
  for v in x:yield from keys(v)
for forbidden in ['candidate_publication_context','current_lean_module','lean_proof','lesson','publication_context','semantic_slots','deltas','verdict','repairs']:assert forbidden not in set(keys(white)),forbidden
raw=dump(white);assert b' := by' not in raw
base=Path('.astis/semantic-neutral-20261109/src_82a91d/phase2-inputs');assert not base.exists();base.mkdir(parents=True)
put(base/'selective-input.json',raw)
m={'scope':'Exactly one explicit-whitelist statement/reconstruction payload. Full canonical packet is a hash reference and may be delivered only at phase3 after independent statement-only comparison freezes.','whitelisted_paths':['source.{source_id,anchor,original_text,text_sha256}','lean.{statement,statement_sha256}','blind_reconstruction.{text,text_sha256,decoder,decoder_packet_sha256,decoder_run_sha256,source_text_visible}','audit.lean.decoder_context','sealed private consumer anonymous literal statement'],'excluded':'All implementation/proof/lesson/publication context, declaration/file identities, earlier semantic decisions/slots/deltas/repairs, proof graph and runtime evidence.','files':[{'path':'selective-input.json','sha256':sha(raw),'bytes':len(raw)}],'phase1_must_be_frozen_before_delivery':True,'source_fidelity_or_independence_verdict':False}
put(base/'manifest.json',dump(m));put(E/'strict-selective-phase2-input.json',raw);put(E/'strict-selective-phase2-manifest.json',dump(m))
print(json.dumps({'state':'blind-reconstructed','reconstruction_text_sha256':recon['reconstructed_text_sha256'],'full_reviewer_packet_canonical_sha256':full['packet_sha256'],'selective_payload_raw_sha256':sha(raw),'selective_manifest_sha256':sha((base/'manifest.json').read_bytes()),'source_review_or_actual_V_credit':False}))
