from pathlib import Path
import hashlib
import json
import gzip
import sys

base=Path(__file__).resolve().parent
repo=Path('/Users/zhouhuanjian/ASTIS-GC')
E=repo/'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-cosine-gram-semantic-evidence'
mode=sys.argv[1]
inventory=json.loads((base/'public-E-inventory.json').read_bytes())
(base/'E').mkdir(exist_ok=True)
for r in inventory:
    p=Path(r['path']);b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==r['raw_sha256']
    dst=base/'E'/r['relative_E_path'];dst.parent.mkdir(exist_ok=True,parents=True);dst.write_bytes(b)
    if p.suffix=='.gz':
        expanded=gzip.decompress(b)
        (dst.parent/(dst.name+'.decoded.txt')).write_bytes(expanded)
names={
 'diagnostics':['preproof-frontier-library-label-diagnostic.json','preproof-reader-flags-pending.json','preproof-reservation-preservation.json',
 '20261110T143917881647Z-cosine-gram-preproof-frontier-format-no-math-acceptance.receipt.json',
 '20261110T143917881647Z-cosine-gram-preproof-frontier-format-no-math-acceptance.receipt.log.gz'],
 'formation-logs':['20261110T141130894994Z-cosine-gram-draft-two-literal-Prop-only-formation.receipt.json',
 '20261110T141130894994Z-cosine-gram-draft-two-literal-Prop-only-formation.log.gz',
 '20261110T141739878001Z-cosine-gram-exact-statement-binder-definition-seal-no-proof.receipt.json',
 '20261110T141739878001Z-cosine-gram-exact-statement-binder-definition-seal-no-proof.log.gz'],
 'historical-C':['frontier-before-explicit-library-search-labels.raw.json.gz','frontier-initial-prospective-reader-flag-normalization.raw.json.gz'],
 'portable-index':['private-origin-portable-definition-and-input-index.json']
}[mode]
out=[]
for name in names:
    b=(base/'E'/name).read_bytes()
    content=gzip.decompress(b) if name.endswith('.gz') else b
    if mode=='historical-C':
        d=json.loads(content)
        text=json.dumps({'cell_id':d['cell_id'],'status':d['status'],'reader_contract':d['reader_contract'],
             'shared_floor_audit':d['shared_floor_audit'],'reuse_plan_searched_existing':d['reuse_plan']['searched_existing'],
             'statement_seal':d['statement_seal'],'target_statement_sha256':hashlib.sha256(d['target_statement'].encode()).hexdigest()},indent=2)
    else:text=content.decode()
    out.append('INPUT E/'+name+' rawSHA256 '+hashlib.sha256(b).hexdigest()+'\n'+text)
stdout='\n\n'.join(out)+'\n';(base/('read-E-'+mode+'.stdout.txt')).write_text(stdout);print(stdout,end='')
