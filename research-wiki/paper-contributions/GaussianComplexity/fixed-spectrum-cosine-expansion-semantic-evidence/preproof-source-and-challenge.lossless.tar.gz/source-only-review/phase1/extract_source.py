#!/usr/bin/env python3
"""Task-local exact-snapshot extractor; no implementation inputs or network."""
from html.parser import HTMLParser
from html import unescape
from pathlib import Path
import hashlib
import json
import re
import sys

BASE = Path(__file__).resolve().parent
REPO = BASE.parents[3]
SOURCE = REPO / '.astis/huanjian-resume-20261103/2610.20492v1.html'
EXPECTED = '6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
blob = SOURCE.read_bytes()
assert len(blob) == 951991 and hashlib.sha256(blob).hexdigest() == EXPECTED
raw = blob.decode('utf-8')
line_offsets = [0]
for match in re.finditer('\n', raw):
    line_offsets.append(match.end())

class Node:
    def __init__(self, tag, attrs, start, parent=None):
        self.tag, self.attrs, self.start, self.parent = tag, dict(attrs), start, parent
        self.end = None
        self.children = []
    def walk(self):
        yield self
        for child in self.children:
            if isinstance(child, Node):
                yield from child.walk()

class Parser(HTMLParser):
    VOID = {'area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr'}
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.root = Node('root', [], 0)
        self.stack = [self.root]
        self.ids = {}
    def position(self):
        line, col = self.getpos()
        return line_offsets[line - 1] + col
    def handle_starttag(self, tag, attrs):
        node = Node(tag, attrs, self.position(), self.stack[-1])
        self.stack[-1].children.append(node)
        if node.attrs.get('id'):
            assert node.attrs['id'] not in self.ids, node.attrs['id']
            self.ids[node.attrs['id']] = node
        if tag in self.VOID:
            node.end = node.start + len(self.get_starttag_text())
        else:
            self.stack.append(node)
    def handle_startendtag(self, tag, attrs):
        self.handle_starttag(tag, attrs)
        if self.stack[-1].tag == tag:
            self.stack[-1].end = self.position() + len(self.get_starttag_text())
            self.stack.pop()
    def handle_endtag(self, tag):
        end = raw.find('>', self.position()) + 1
        for i in range(len(self.stack) - 1, 0, -1):
            if self.stack[i].tag == tag:
                for node in self.stack[i:]:
                    node.end = end
                del self.stack[i:]
                return
    def handle_data(self, data):
        self.stack[-1].children.append(data)

parser = Parser()
parser.feed(raw)
parser.root.end = len(raw)
assert len(parser.stack) == 1
ids = parser.ids

def clean(text):
    return re.sub(r'\s+', ' ', text).strip()

def rendered(node, mark_math=True):
    if isinstance(node, str):
        return node
    if node.tag == 'math':
        tex = node.attrs.get('alttext', '')
        return (' [' + node.attrs['id'] + '] ' if mark_math and node.attrs.get('id') else ' ') + '$' + tex + '$ '
    text = ''.join(rendered(x, mark_math) for x in node.children)
    if node.tag in {'p','h1','h2','h3','h4','h5','h6','table','section','div','li','dt','dd'}:
        return '\n' + text + '\n'
    if node.tag == 'br':
        return '\n'
    return text

def readable(node):
    chunks = []
    for item in node.walk():
        if item.tag in {'h1','h2','h3','h4','h5','h6','p'} or ('ltx_equation' in item.attrs.get('class','').split()) or ('ltx_equationgroup' in item.attrs.get('class','').split()):
            if any(parent.tag in {'p','table'} or 'ltx_equation' in parent.attrs.get('class','').split() for parent in ancestors(item) if parent is not node):
                continue
            locator = item.attrs.get('id', '(unanchored ' + item.tag + ')')
            chunks.append('[' + locator + '] ' + clean(rendered(item)))
    return '\n\n'.join(chunks) if chunks else '[' + node.attrs.get('id',node.tag) + '] ' + clean(rendered(node))

def ancestors(node):
    parent = node.parent
    while parent is not None:
        yield parent
        parent = parent.parent

def sha(text):
    return hashlib.sha256(text.encode('utf-8')).hexdigest()

def excerpt(node):
    assert node.end is not None
    return raw[node.start:node.end]

def record(node):
    part = excerpt(node)
    prefix = raw[:node.start]
    return {'tag':node.tag,'id':node.attrs.get('id'),'anchor':('#'+node.attrs['id']) if node.attrs.get('id') else None,
            'start_byte':len(prefix.encode('utf-8')),'end_byte_exclusive':len((prefix+part).encode('utf-8')),
            'start_line':raw.count('\n',0,node.start)+1,'end_line':raw.count('\n',0,node.end)+1,
            'raw_sha256':sha(part)}

if len(sys.argv) >= 3 and sys.argv[1] == '--inspect':
    for key in sys.argv[2:]:
        node = ids[key]
        print(json.dumps(record(node),ensure_ascii=False))
        print(readable(node))
    sys.exit(0)

if len(sys.argv) >= 3 and sys.argv[1] == '--structure':
    for key in sys.argv[2:]:
        for node in ids[key].walk():
            if node.tag in {'section','h2','h3','h4','h5','h6'} or (node.attrs.get('class','').startswith('ltx_theorem')):
                print(node.tag,node.attrs.get('id',''),clean(rendered(node,False))[:220])
    sys.exit(0)

if len(sys.argv) >= 3 and sys.argv[1] == '--math':
    for key in sys.argv[2:]:
        for node in ids[key].walk():
            if node.tag == 'math':
                print(node.attrs.get('id','(no id)'),node.attrs.get('alttext',''))
    sys.exit(0)

if len(sys.argv) == 2 and sys.argv[1] == '--metadata':
    for node in parser.root.walk():
        if node.tag == 'title' or 'ltx_authors' in node.attrs.get('class','').split() or node.attrs.get('id') == 'license-tr':
            print(json.dumps(record(node),ensure_ascii=False))
            print(clean(rendered(node)))
    sys.exit(0)

if __name__ == '__main__':
    print('Use --inspect, --structure, --math or --metadata with raw source ids.')
