"""Independent read-only review of the one preserved observational diagnostic, not acceptance."""
import datetime as dt, hashlib, json, os, struct, sys, time, traceback
from pathlib import Path
OWN=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,x):
    with Path(p).open('x') as f:f.write(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def main():
    checks=[]
    def check(n,ok):
        checks.append({'name':n,'pass':bool(ok)})
        if not ok:raise AssertionError(n)
    p=OWN/'actual-diagnostic.json';j=json.loads(p.read_text());r=json.loads((OWN/'runtime-process/receipt.json').read_text())
    check('actual-diagnostic-pin',sha(p)=='f5774f5c3c4f2b04b375b934c700de93b2fa17e9a54cf8a57648dc095a68a9f2')
    check('actual-assignment-pin',sha(OWN/'execution-assignment.json')=='350bc0154accb10547bdea5151534d8bac56f5899a1dd6ee0a339f0140e652a6')
    check('actual-script-preserved',sha(OWN/'diagnose_v3.py')==r['script_sha256']=='c7c9cc91f6bc23624a1726ad9569eb083bff53c5efd6080be1fc425d74394963')
    check('actual-OS-exit0-null-acceptance',r['actual_exit_code']==0 and r['acceptance_verdict'] is None)
    check('actual-fd-streams',all(sha(OWN/('runtime-process/'+n+'.raw'))==r[n+'_sha256'] for n in ['stdout','stderr']))
    check('diagnostic-boundary-no-error',j['status']=='DIAGNOSTIC_COMPLETED' and j['not_an_acceptance_run'] and j['server_and_worker_stopped'] and j['fixture110_bytes_unchanged'] and not j['exceptions'] and not j['page_errors'] and not j['console'] and not j['blocked_external_requests'] and len(j['requests'])==len(j['responses'])==113 and all(x['status']<400 for x in j['responses']))
    traces=[]
    for c in j['cases']:
        t=c['anchor_trace'];label=c['viewport_label'];first,last=t[0],t[-1]
        check(label+'-natural-trace-multiple-timepoints',len(t)>=4 and all(b['relative_ms']>a['relative_ms'] for a,b in zip(t,t[1:])))
        check(label+'-initial-zero-intersection',first['intersectionHeight']==0)
        check(label+'-settled-strictly-visible-below-header',last['intersectionHeight']>0 and last['target']['top']>=last['header']-1)
        check(label+'-smooth-window-scroll-real-no-pre-scroll',all(s['htmlScrollBehavior']=='smooth' and s['pre']['scrollTop']==0 and s['pre']['scrollLeft']==0 for s in t) and last['windowScroll']['y']>first['windowScroll']['y'])
        check(label+'-motion-consistent-with-window-scroll',max(s['target']['top']+s['windowScroll']['y'] for s in t)-min(s['target']['top']+s['windowScroll']['y'] for s in t)<=.25)
        tail=t[-4:]
        signatures=[[s['windowScroll']['x'],s['windowScroll']['y'],s['pre']['scrollLeft'],s['pre']['scrollTop'],*[s['target'][k] for k in ['top','bottom','left','right']]] for s in tail]
        check(label+'-four-stable-samples-recomputed',all(max(z)-min(z)<=.25 for z in zip(*signatures)) and last['relative_ms']>=500 and all(b['relative_ms']-a['relative_ms']>=100 for a,b in zip(tail,tail[1:])) and c['natural_stability']['observed'])
        check(label+'-settled-PNG-followup-same-position',c['after_final_screenshot']['target']==last['target'] and c['after_final_screenshot']['windowScroll']==last['windowScroll'])
        first_stable=next(s for s in t if s['target']==last['target'] and s['windowScroll']==last['windowScroll'])
        traces.append({'viewport':label,'initial_top':first['target']['top'],'initial_intersection_height':first['intersectionHeight'],'stable_top':last['target']['top'],'stable_intersection_height':last['intersectionHeight'],'stable_header':last['header'],'first_final_position_ms':first_stable['relative_ms'],'last_stable_sample_ms':last['relative_ms'],'natural_window_y_initial':first['windowScroll']['y'],'natural_window_y_final':last['windowScroll']['y'],'sample_count':len(t),'full_trace_original_path':'actual-diagnostic.json'})
    o=j['cases'][1]['mobile_module_overflow_after_actual_disclosure_clicks'];target={x['selector']:x['elements'] for x in o['targeted']}
    grid=target['.declaration-list'][0];item=target['.declaration-list > details.declaration'][0];excerpt=target['.declaration-list pre.code-block'][0];complete=target['#complete-module-source'][0];fullpre=target['#complete-module-source pre.code-block'][0]
    check('mobile-body-overflow-real',o['document']['html']==390 and o['document']['body']==697)
    check('grid-auto-track-expands-direct-item',grid['display']=='grid' and grid['rect']['width']==354 and grid['scrollWidth']==679 and grid['gridTemplateColumns']=='679.297px' and item['minWidth']=='auto' and item['rect']['width']==679.296875 and item['rect']['right']==697.296875)
    check('excerpt-ancestor-is-outside-viewport',excerpt['rect']['right']==677.109375 and excerpt['rect']['right']>390 and excerpt['overflowX']=='auto')
    check('complete-source-local-pane-is-bounded',complete['rect']['left']==18 and complete['rect']['right']==372 and complete['scrollWidth']==354 and fullpre['rect']['right']<372 and fullpre['overflowX']=='auto' and fullpre['scrollWidth']>fullpre['clientWidth'])
    owner_counts={'all':len(o['overflowCandidates']),'locally_clipped_scroll_content':0,'closed_sidebar_offcanvas':0,'positive_right_overflow_outside_local_pane':0,'other':0}
    relevant=[]
    for row in o['overflowCandidates']:
        # Read every recorded owner and ancestor row; full originals stay unfiltered.
        check('owner-ancestor-shape-'+str(len(relevant))+'-'+row['path'],all(all(k in x for k in ['rect','display','minWidth','overflowX','width','font']) for x in [row,*row['ancestors']]))
        if row['localScrollPaneWithinViewport']:owner_counts['locally_clipped_scroll_content']+=1
        elif row['rect']['right']<0:owner_counts['closed_sidebar_offcanvas']+=1
        elif row['rect']['right']>390:
            owner_counts['positive_right_overflow_outside_local_pane']+=1;relevant.append({k:row[k] for k in ['path','rect','display','minWidth','gridTemplateColumns','clientWidth','scrollWidth','overflowX','nearestXClippingAncestor']})
        else:owner_counts['other']+=1
    images=[]
    for s in j['screenshots']:
        q=OWN/s['path'];raw=q.read_bytes();w,h=struct.unpack('>II',raw[16:24])
        check('original-PNG-pin-'+q.name,sha(q)==s['sha256'] and w in [390,1440])
        images.append({**s,'width':w,'height':h,'actually_viewed_original':True,'observation': 'Immediate screenshot shows an earlier source region during natural motion; it is not a settled-anchor failure image.' if 'immediate' in q.name else 'Settled source code is below the actual header and visually readable; this image accompanies the raw stable L187 geometry.' if 'settled' in q.name else 'Upper declaration excerpt extends beyond the right viewport while the later complete-source panel remains bounded, corroborating recorded grid/item metrics.'})
    check('all-five-actual-original-PNGs-viewed',len(images)==5)
    report={'schema':'R17-v3-independent-observational-diagnosis-v1','status':'DIAGNOSIS_COMPLETE_NOT_READER_ACCEPTANCE','diagnostic_actual_exit_code':0,'original_reader_status':'FAIL','original_reader_exit_code':1,'original_reader_checks':501,'original_reader_false_checks':3,'original_reader_result_sha256':'74fd21200be988619c1ff27fd253049cc84c96641461aaf3fb54ca52beb9384f','diagnostic_result_sha256':sha(p),'actual_assignment_sha256':sha(OWN/'execution-assignment.json'),'actual_OS_receipt_sha256':sha(OWN/'runtime-process/receipt.json'),'actual_Chrome_version':j['actual_Chrome_version'],'source_fixture':'original static-closure-v3','preview_manifest_sha256':j['preview_manifest_sha256'],'independent_checks':checks,'anchor_trace_summaries':traces,'anchor_finding':{'classification':'OBSERVED_PRE_SETTLEMENT_MEASUREMENT','actual_evidence':'Both actual link navigations continue natural window scrolling after networkidle, then L187 stabilizes visibly below the header with no source-target scroll write or transform. This supports adding an observational generic stability wait in a successor checker, not changing the original flags.','bounded_scope':'The observed settled trajectories belong to this separately authorized diagnostic with the same frozen v3 fixture. Original failed-run trajectories were not recorded and are not retroactively replaced. This does not certify any future fixture/run.','UI_hash_or_scroll_repair_required_by_this_evidence':False,'successor_wait_contract':'Observe natural window/pre scroll and target bbox every100ms until four stable samples within.25 CSSpx, minimum500ms, deadline5s; then apply the original strict positive-intersection/header predicate. No forced target scroll or disabled animation. Apply generically to all source-anchor readability checks.'},'mobile_overflow_finding':{'classification':'OBSERVED_GRID_INTRINSIC_WIDTH_LAYOUT_DEFECT','document':o['document'],'measured_owner_chain':[grid,item,excerpt],'normal_complete_source_local_scrolling':[complete,fullpre],'counts_all_owner_rows_read':owner_counts,'relevant_right_overflow_rows':relevant,'supported_minimal_UI_repair':'Only isolated candidate CSS: zero-min-width grid item/ancestors and bounded grid track, preserve local pre horizontal scrolling and complete-source bytes. No source/hash JS repair follows from the observed timing diagnosis.','causality_limit':'Raw metrics identify the expanded grid track/item and excerpt as the body overflow path; no counterfactual CSS experiment was performed in this diagnostic.'},'actual_original_images':images,'runtime_integrity':{'requests':113,'responses':113,'console':j['console'],'page_errors':j['page_errors'],'blocked_external_requests':j['blocked_external_requests'],'exceptions':j['exceptions'],'server_thread_stopped':j['server_and_worker_stopped'],'fixture110_bytes_unchanged':j['fixture110_bytes_unchanged']},'no_API_V_cell_ledger_Git_Lean_source_or_production_action':True,'no_browser_run_by_this_review':True,'created_utc':dt.datetime.now(dt.timezone.utc).isoformat()}
    write(OWN/'independent-diagnosis.json',report)
    write(OWN/'independent-diagnosis-run.json',{'schema':'R17-immutable-independent-diagnostic-review-run-v1','report_sha256':sha(OWN/'independent-diagnosis.json'),'actual_diagnostic_sha256':sha(p),'actual_OS_receipt_sha256':sha(OWN/'runtime-process/receipt.json'),'actual_original_PNGs_viewed':5,'not_acceptance':True,'original_FAIL_unchanged':True})
    print(json.dumps({'status':report['status'],'checks':len(checks),'report_sha256':sha(OWN/'independent-diagnosis.json'),'run_sha256':sha(OWN/'independent-diagnosis-run.json'),'actual_original_PNGs_viewed':5}))
if __name__=='__main__':
    p=OWN/'review-process';p.mkdir(exist_ok=False)
    for fd,n in [(1,'stdout.raw'),(2,'stderr.raw')]:
        f=(p/n).open('xb',buffering=0);os.dup2(f.fileno(),fd);f.close()
    utc=dt.datetime.now(dt.timezone.utc).isoformat();start=time.monotonic();code=0
    try:main()
    except BaseException:traceback.print_exc();code=1
    sys.stdout.flush();sys.stderr.flush()
    write(p/'receipt.json',{'schema':'R17-actual-readonly-diagnostic-review-OS-receipt-v1','argv':[sys.executable,*sys.argv],'cwd':str(Path.cwd()),'pid':os.getpid(),'started_utc':utc,'ended_utc':dt.datetime.now(dt.timezone.utc).isoformat(),'actual_exit_code':code,'elapsed_seconds':time.monotonic()-start,'script_sha256':sha(__file__),'stdout_sha256':sha(p/'stdout.raw'),'stderr_sha256':sha(p/'stderr.raw'),'no_new_browser_API_Lean_Git_site_source_action':True})
    sys.exit(code)
