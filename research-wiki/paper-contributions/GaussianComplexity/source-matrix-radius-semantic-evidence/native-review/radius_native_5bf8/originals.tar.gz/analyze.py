from runner import *
from collections import Counter
d=OUT/'inspection'
decls=[json.loads(l) for l in (d/'declarations.ndjson').read_text().splitlines()]
nodes=[json.loads(l) for l in (d/'expressions.ndjson').read_text().splitlines()]
assert [r['id'] for r in nodes]==list(range(len(nodes)))
by={r['name']['display']:r for r in decls}
refs={'app':['function','argument'],'lam':['domain','body'],'forall':['domain','body'],'let':['type','value','body'],'metadata':['body'],'projection':['body']}
for r in nodes:
    for k in refs.get(r['node']['ctor'],[]):assert 0<=r['node'][k]<r['id']
for r in decls:
    assert not any(r[k] for k in ['unsafe','partial','typeHasFVar','typeHasMVar','typeHasLooseBVars','valueHasFVar','valueHasMVar','valueHasLooseBVars'])
    assert 'PASS' in r['kernelCheck']
    for a in r['axioms']:assert a['display'] in ['propext','Classical.choice','Quot.sound']
def deps(n):
    r=by[n];return sorted(set(x['display'] for k in ['typeConstants','valueConstants'] for x in r[k]))
P=next(n for n in by if n.endswith('.actual_source_truncated_matrix_norm_bounds'))
T=next(n for n in by if n.endswith('.actual_source_centered_summand_radius'))
assert P in deps(T)
reached=set()
def walk(n):
    if n in reached or n not in by:return
    reached.add(n)
    for x in deps(n):walk(x)
walk(P);walk(T)
owned=[n for n,r in by.items() if r['owner']['display'].endswith('FixedSpectrumSourceMatrixRadius')]
assert len(owned)>=5
assert all(n in reached for n in owned),[n for n in owned if n not in reached]
edges={n:[x for x in deps(n) if x in by] for n in by}
(d/'actual-ASTIS-edges.json').write_text(json.dumps(edges,indent=2)+'\n')
# All exact serialized expression roots remain in the raw DAG; this file is a derived index only.
summary={'actual_declaration_count':len(decls),'actual_module_counts':dict(Counter(r['owner']['display'] for r in decls)),
 'unique_expression_nodes':len(nodes),'constructors':dict(Counter(r['node']['ctor'] for r in nodes)),
 'producer':P,'private_consumer':T,'owned_declarations':owned,'reachable_ASTIS_declarations':sorted(reached),
 'owned_all_reachable':True,'actual_producer_ASTIS_parents':edges[P],'actual_consumer_ASTIS_parents':edges[T],
 'owned_axioms':{n:[x['display'] for x in by[n]['axioms']] for n in owned},
 'complete_raw_hashes':{p.name:sha(p) for p in [d/'expressions.ndjson',d/'declarations.ndjson',d/'actual-ASTIS-edges.json']}}
(OUT/'math-inspection-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
