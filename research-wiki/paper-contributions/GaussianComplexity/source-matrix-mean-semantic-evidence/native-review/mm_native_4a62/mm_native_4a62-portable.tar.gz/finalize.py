#!/usr/bin/env python3
"""Freeze evidence and package only bounded portable originals; no circular self-hashes."""
import gzip,tarfile,io
from runner import *
from audit_core import filehash
def freeze():
    protocols=['AGENTS.md','CONTRIBUTING.md','.agents/prompts/collaborator-contribution.md',
      'docs/contributor-codex-contract.md','docs/theorem-publication-protocol.md','docs/proof-digestion-protocol.md',
      'docs/evidence-routed-memory-protocol.md','.agents/skills/astis-semantic-roundtrip/SKILL.md',
      '.agents/skills/astis-substantive-advance/SKILL.md']
    inputs=list(json.loads((OWN/'closure.json').read_text())['modules'].values())
    paths=[x['path'] for x in inputs]+[
      'website/content/declaration_lessons/huanjian-gaussian-source-matrix-mean.json',
      'website/content/publications/huanjian-gaussian-source-matrix-mean.json',
      'research-wiki/paper-contributions/GaussianComplexity/source-matrix-mean-statement-seal.json',
      E+'/source-lean-map.draft.json','lean-toolchain','lake-manifest.json','lakefile.lean',
      E+'/publication-draft-record.json',E+'/local-attempt-diagnoses.json',E+'/actual-local-mathematical-result.json',
      E+'/preproof-source-types-topology-local-build.original-manifest.json',
      E+'/preproof-source-types-topology-local-build.original-files.tar.gz',
      '.astis/huanjian-gc-source-matrix-mean-20261112/SourceMatrixMeanKernelProbe.lean',
      'Tests/GaussianComplexityFixedSpectrumTruncatedRowMoment.lean']+protocols
    py=json.loads((OWN/'renderer-python-closure.json').read_text())
    paths += [x['path'] for x in py['modules'].values()]
    seal=json.loads((REPO/'research-wiki/paper-contributions/GaussianComplexity/source-matrix-mean-statement-seal.json').read_text())
    paths.append(seal['source']['raw'])
    bindings=[]
    for rel in sorted(set(paths)):
        path=REPO/rel;bindings.append({'repository_relative_path':rel,'bytes':path.stat().st_size,'sha256':filehash(path)})
    for rel in protocols:
        target=OWN/'protocols'/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((REPO/rel).read_bytes())
    # Only exact bounded seal/map and compilation-history records are copied.
    for rel in ['research-wiki/paper-contributions/GaussianComplexity/source-matrix-mean-statement-seal.json',
      E+'/source-lean-map.draft.json',E+'/local-attempt-diagnoses.json',E+'/actual-local-mathematical-result.json']:
        target=OWN/'bound-inputs'/Path(rel).name;target.parent.mkdir(exist_ok=True);target.write_bytes((REPO/rel).read_bytes())
    env=json.loads((OWN/'environment.json').read_text())
    save('relevant-input-binding.json',{'candidate':CANDIDATE,
      'native_compile_credit_only_for':CANDIDATE,
      'binding_observed_HEAD':subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO).decode().strip(),
      'repository_inputs':bindings,'native_binary':{'path':env['lean_path'],'sha256':env['lean_binary_sha256'],'bytes':env['lean_binary_bytes']},
      'actual_package_pins':env['packages'],
      'later_metadata_carrier_rule':'Compare all repository inputs byte-for-byte and actual binary/package pins. Unchanged inputs permit evidence reuse only; this packet does not claim to compile a later HEAD.'})
    versions={}
    for p in sorted((OWN/'receipts').glob('*.receipt.json')):
        r=json.loads(p.read_text());label=r['label'];argv=r['argv']
        if label in ['independent-wholemodule-probe-v1','independent-wholemodule-probe-v2']:
            version='1' if label.endswith('v1') else '2'
            artifact=OWN/'fresh/src'/('WholeModuleProbe-v'+version+'.failed.lean')
        elif label=='independent-wholemodule-probe-v3':artifact=OWN/'fresh/src/WholeModuleProbe.lean'
        else:
            artifact=next((Path(a) if Path(a).is_absolute() else Path(r['cwd'])/a for a in argv[1:]
              if a.endswith(('.lean','.py')) and (Path(a) if Path(a).is_absolute() else Path(r['cwd'])/a).is_file()),None)
        if artifact is not None:versions[label]={'retained_input':str(artifact.relative_to(OWN)) if artifact.is_relative_to(OWN) else str(artifact),
          'bytes':artifact.stat().st_size,'sha256':filehash(artifact)}
    save('receipt-input-versions.json',versions)
    save('verifier-failures.json',{'native':[
      {'label':'independent-wholemodule-probe-v1','class':'IMPLEMENTATION_FAILED','reason':'Verifier private name quotation parsing and missing noncomputable section','exit_code':1,'original_source':'fresh/src/WholeModuleProbe-v1.failed.lean','original_generator':'make_native_probe-v1.failed.py'},
      {'label':'independent-wholemodule-probe-v2','class':'IMPLEMENTATION_FAILED','reason':'Verifier used unavailable Environment.find! and liftIO names','exit_code':1,'original_source':'fresh/src/WholeModuleProbe-v2.failed.lean','original_generator':'make_native_probe-v2.failed.py'}],
      'native_corrected_success':'independent-wholemodule-probe-v3',
      'preparer_failure':{'original_script':'prepare_renderer-v1.failed.py','class':'IMPLEMENTATION_FAILED','reason':'Lesson and publication basename collided in recorder label; no native theorem failed.',
        'outer_original_tool_chunk':'03de1c','outer_argv':['python3','.astis/semantic-neutral-20261112/mm_native_4a62/prepare_renderer.py'],
        'outer_cwd':str(REPO),'outer_exit_code':1,'honest_limit':'Original outer invocation was not wrapped in own subprocess recorder; no invented timestamp/elapsed/raw-stream separation is supplied. Completed child receipts and the exact returned tool-visible stream are retained.',
        'corrected_success':'prepare-renderer-v2'},
      'unchanged_route_repeated':False,'mathematical_refutation_claimed':False})
def report():
    env=json.loads((OWN/'environment.json').read_text());nat=json.loads((OWN/'native-wholemodule-summary.json').read_text())
    renders=json.loads((OWN/'bounded-rendering.json').read_text());spans=json.loads((OWN/'exact-byte-span-audit.json').read_text())
    receipts=[json.loads(p.read_text()) for p in sorted((OWN/'receipts').glob('*.receipt.json'))]
    native=[r for r in receipts if r['argv'][0]==env['lean_path']]
    assert all(r['start_HEAD']==CANDIDATE for r in native)
    evidence={name:{'sha256':filehash(OWN/name),'bytes':(OWN/name).stat().st_size} for name in [
      'environment.json','closure.json','native-wholemodule-summary.json','root-type-1.json','root-type-2.json',
      'root-probe-binding-before-replay.json','cache-boundary.json','bounded-rendering.json','renderer-python-closure.json',
      'exact-byte-span-audit.json','original-archive-member-readback.json','retained-old-boundary.json',
      'relevant-input-binding.json','receipt-input-versions.json','verifier-failures.json','REPRODUCE.md']}
    save('report.json',{'reviewer':'mm_native_4a62','role':'Independent fresh native/whole-module/bounded static reader verifier',
      'candidate':CANDIDATE,'verdict':'PASS_WITH_EXPLICIT_BOUNDED_SCOPE','source_fidelity_verdict':None,
      'not_actors':['formalizer','decoder','source reviewer','source topology extractor','topology challenger'],
      'independence':'No other actor source/semantic/topology/native verdict or decoder used; permitted root compiler/history data do not replace fresh evidence.',
      'native':{'binary_path':env['lean_path'],'binary_sha256':env['lean_binary_sha256'],'version':env['version'],
        'manifest_sha256':env['manifest_sha256'],'package_count':9,'all_actual_revisions_match_and_clean_including_untracked':True,
        'fresh_ASTIS_module_count':7,'fresh_compile_exit_codes':[0]*7,'starting_ASTIS_olean_count':0,
        'no_ASTIS_cached_olean_copied_or_reachable':True,'actual_search_path_receipt':'receipts/actual-native-search-path.receipt.json',
        'whole_module_constant_count':39,'whole_module_all_full_types_and_bodies_read':True,'whole_module_all_closed':True,
        'allowed_axioms_only':['propext','Classical.choice','Quot.sound'],'new_owned_count':3,'new_handwritten_roots':2,'new_generated_reachable':1,
        'full_seven_module_root_reachable_constants':32,'retained_old_generated_outside_root_closure':7,
        'old_private_canonical_matrix_application_module_outside_target_import_closure':True,
        'sealed_literal_kernel_applications':nat['literal_checks'],'root_original_probe_replayed_exit0':True,
        'actual_immediate_ASTIS_parents':nat['actual_immediate_ASTIS_parents'],
        'fresh_native_compile_credit_only_for':CANDIDATE},
      'analytical_checks':[
        'Actual root types and bodies use Matrix.instL2OpNormedAddCommGroup, Matrix.instL2OpNormedSpace and Matrix.instL2OpNormedRing, under Matrix.Norms.L2Operator. No default Pi norm substitution is claimed.',
        'Native instances establish completeness of row and tensor matrix spaces, finite-dimensional row matrices, normed tensor space, and probability/sigma-finiteness of the actual product Gaussian measure.',
        'The canonical scalar retained squared radius is natively integrable for arbitrary real cutoff L, using the already proved Gaussian squared-norm moment and measurable closed-ball indicator.',
        'Canonical truncated row matrix integrability is an actual theorem conclusion. Entry domination by retained squared radius and the finite-dimensional ofRows continuous equivalence in the fresh compiled parent discharge its analytical obligations.',
        'General integral_map needs AEMeasurable row and AEStronglyMeasurable kept on the map measure, both derived in the proof. No injectivity or measurable embedding is required for the noninjective physical-row projection.',
        'The actual fixed Kronecker map is made continuous by LinearMap.toContinuousLinearMap in the finite-dimensional row matrix space with the actual norm, and ContinuousLinearMap.integrable_comp/integral_comp_comm transport integrability and the mean.',
        'The private consumer derives deterministic Gram sums and finite integral/sum/scalar exchange from actual integrability outputs. The sole premise is hq with natural d,q, covering q=0; no independence, law, Gram or integrability certificate is added.'
      ],
      'static_reader':{'production_functions':renders['production_functions'],'frozen_transitive_Python_modules':19,
        'runtime_import_count':len(renders['runtime_local_imports']),'lesson_details_initially_closed':17,'publication_details_initially_closed':19,
        'source_ordered_proof_folds':6,'all_exact_source_bytes_formulae_and_progressive_authored_data_checked':True,
        'P_step_LF_ranges':[[45,78],[79,89],[90,118]],'T_step_LF_ranges':[[1,110],[111,143],[144,158]],
        'full_T_source_lines':158,'private_L17_anchor':True,'true_materialized_download_filebytes':True,
        'local_source_module_download_link_checks':len(renders['local_source_module_download_links']),
        'bounded_theme_and_empty_status_inputs':True},
      'byte_and_history':{'source_spans':len(spans['source_spans']),'Lean_spans':len(spans['Lean_spans']),
        'all_raw_byte_Unicode_character_LF_spans_exact':True,'original_archive_members_rehashed':218,
        'historical_exit_codes':{'P_firstbuild':0,'T_attempts':[1,1,0],'strict_probe':0},
        'nonmathematical_failures_not_used_as_counterevidence':True},
      'receipts':{'total':len(receipts),'native_binary_invocations':len(native),
        'native_failed_verifier_versions':2,'native_successful_invocations':sum(r['exit_code']==0 for r in native),
        'all_raw_stream_hashes_and_versions_preserved':True,'one_preparer_outer_invocation_limit':'See verifier-failures.json and tool-visible original stream.'},
      'large_local_dump':nat['local_full_type_body_dump'],'evidence_files':evidence,
      'scope_nonclaims':['source fidelity','source topology acceptance','normal VERIFIED','PROVED_LOCAL admission','integration permission','browser','mobile','MathJax runtime','copy or download interaction','global source index','graph','fullsite','deployment','Goal completion','recompilation of any later metadata carrier']})
    (OWN/'report.md').write_text('''# Independent native and bounded static reader verification

PASS for mathematical candidate `5fb1440f771bdae77ad31f27b2275447fe3e89e5` within this scope. No source-fidelity verdict or integration permission is issued.

The actual Lean 4.33.0 native binary, exact manifest and all nine package HEADs/clean states matched. Seven ASTIS modules exported from that candidate compiled in topological order into an initially empty output directory. Actual Lean search paths expose only those ASTIS outputs, pinned package caches and the native standard library.

All 39 constants owned by the seven actual modules had their complete types and proof bodies read from the native environment, were closed, and used only `propext`, `Classical.choice`, `Quot.sound`. The two new roots and one generated helper are reachable. Both independently formed sealed literals accepted the actual theorem constants in the kernel; their raw `Expr` structures differ. The unchanged original root probe also passed in the fresh environment. Actual parents are the row law and truncated row moment for P, and P and the cosine Gram theorem for T.

Thirty-two of the 39 module constants are in the target root dependency closure. Seven retained GridAlias generated simplification helpers are outside it. The old private canonical-row matrix application is in a different test module outside this import closure. These boundaries do not constitute global dead-code judgments.

Native analytical checks confirm the actual L2 operator matrix norm, completeness, probability/sigma-finiteness, retained scalar integrability and the finite-dimensional continuous tensor map. The physical-row integral transport uses the general noninjective `integral_map`, with measurability supplied by the proved row law and integrability. No law, mean, Gram or integrability certificate is a new premise.

The frozen 19-module Python import closure ran the real production lesson/source/module renderers and the exact production module export loop on isolated bounded inputs. All six proof steps are initially closed. P lines 45–78/79–89/90–118 and T lines 1–110/111–143/144–158 are exact and continuous. The complete 158-line private source, L17 anchor, local source/module links, adjacent exact Lean and materialized download bytes match. The theme carrier is a declared minimal fixture and empty cells/audits confer no status credit.

All 27 source spans and 30 Lean spans match raw UTF-8, Unicode character and LF coordinates. Every original archive member was rehashed (218/218). Historical exits are P first build 0, T attempts 1/1/0 and strict probe 0; implementation/API/schema failures are not mathematical refutations. Own verifier failures and changed versions are retained.

This is static/native evidence only. It grants no browser/mobile/MathJax/copy/download-interaction, global index/graph/fullsite/deployment, normal VERIFIED, admission, integration or Goal credit. Native compilation belongs only to the fixed candidate; later metadata carriers must compare `relevant-input-binding.json` and are not claimed recompiled. The approximately 817 MB full proof-body dump remains local with an exact hash and replay instructions.
''')
def package():
    excluded={'portable-manifest.json','portable-archive-rehash.json','final-seal.json','mm_native_4a62-portable.tar.gz'}
    paths=[]
    for p in sorted(OWN.rglob('*')):
        if not p.is_file():continue
        rel=p.relative_to(OWN)
        if p.name in excluded or any(x in rel.parts for x in ['__pycache__','local']) or str(rel).startswith('fresh/olean/'):continue
        paths.append(p)
    payload=[{'path':str(p.relative_to(OWN)),'bytes':p.stat().st_size,'sha256':filehash(p)} for p in paths]
    manifest=save('portable-manifest.json',{'candidate':CANDIDATE,'scope':'Bounded own scripts, probes, summaries, exact target inputs, renderer Python closure, receipts, streams and report; no oleans or huge body dump or full foreign review/control/private snapshots.',
      'payload_file_count':len(payload),'archive_member_count_expected':len(payload)+1,
      'own_receipt_count':len(list((OWN/'receipts').glob('*.receipt.json'))),'payload':payload,
      'manifest_self_hash_included':False,'external_seal':'final-seal.json'})
    archive=OWN/'mm_native_4a62-portable.tar.gz'
    with open(archive,'wb') as out:
        with gzip.GzipFile(filename='',mode='wb',fileobj=out,mtime=0) as gz:
            with tarfile.open(mode='w',fileobj=gz) as tf:
                for p in paths+[OWN/'portable-manifest.json']:
                    raw=p.read_bytes();info=tarfile.TarInfo(str(p.relative_to(OWN)));info.size=len(raw);info.mtime=0;info.mode=0o644;tf.addfile(info,io.BytesIO(raw))
    expected={x['path']:x for x in payload}
    expected['portable-manifest.json']={'path':'portable-manifest.json','bytes':(OWN/'portable-manifest.json').stat().st_size,'sha256':filehash(OWN/'portable-manifest.json')}
    reread=[]
    with tarfile.open(archive) as tf:
        members=tf.getmembers();assert len(members)==len(expected)
        assert len({m.name for m in members})==len(members) and {m.name for m in members}==set(expected)
        for m in members:
            raw=tf.extractfile(m).read();want=expected[m.name]
            assert len(raw)==want['bytes'] and sha(raw)==want['sha256']
            reread.append({'path':m.name,'bytes':len(raw),'sha256':sha(raw)})
    save('portable-archive-rehash.json',{'archive_sha256':filehash(archive),'archive_bytes':archive.stat().st_size,
      'payload_file_count':len(payload),'archive_member_count':len(reread),'every_actual_member_rehashed':True,'members':reread})
    save('final-seal.json',{'candidate':CANDIDATE,'verifier':'mm_native_4a62','report_verdict':'PASS_WITH_EXPLICIT_BOUNDED_SCOPE',
      'raw_hashes':{n:{'sha256':filehash(OWN/n),'bytes':(OWN/n).stat().st_size} for n in ['report.json','report.md','REPRODUCE.md',
        'relevant-input-binding.json','portable-manifest.json','mm_native_4a62-portable.tar.gz','portable-archive-rehash.json']},
      'payload_file_count':len(payload),'archive_member_count':len(reread),'own_receipt_count':manifest['own_receipt_count'],
      'native_compile_credit_only_for':CANDIDATE,'source_fidelity_verdict':None,'integration_permission':False,
      'no_circular_self_hash':True})
    print(json.dumps({'payload_file_count':len(payload),'archive_members':len(reread),'receipts':manifest['own_receipt_count'],
      'archive_bytes':archive.stat().st_size,'archive_sha256':filehash(archive),'report_sha256':filehash(OWN/'report.json')},indent=2))
if __name__=='__main__':freeze();report();package()
