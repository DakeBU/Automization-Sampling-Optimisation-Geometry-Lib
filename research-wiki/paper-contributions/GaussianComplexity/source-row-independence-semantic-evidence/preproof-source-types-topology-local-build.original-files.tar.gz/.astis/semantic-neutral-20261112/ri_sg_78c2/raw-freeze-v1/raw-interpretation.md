# Raw source interpretation, version 1

This is a frozen source-only preliminary reading. It is neither a Statement Seal nor an accepted topology, semantic verdict, compiled proof, publication, or permission to formalize. It precedes every new typed signature and implementation exposure. Final topology review awaits the exact Statement Seal and binder/definition audit.

The source is *On Complexity of Gaussian Sampling*, arXiv:2610.20492v1, pinned by the complete HTML input hash in the manifest. The chosen source assertion is the unnamed C.2 p1 claim that the vectors gamma_1,...,gamma_d are independent. The actual downstream consumer is the unnamed independence assertion immediately preceding Ex107, attached to those very truncated matrices.

The intended canonical specialization uses natural d,q with 2q+1<d and r=q+1. A sample is a tuple of r vectors in R^d, endowed with the product of r standard d-Gaussian laws; g_a is its a-th column projection. This canonical realization is the task's chosen boundary for the source's independent-column experiment. The source is not being asserted to restrict all possible realizations to this one space, and no arbitrary ambient/coupling transfer is claimed. No library/API for this realization has been inspected. The physical vector gamma_i=((g_a)_i)_(a=1,...,r) always uses the same column sample.

“Independent” means full finite joint independence of the vector-valued random maps, equivalently factorization for every family of Borel row events. It is stronger than pairwise independence. The source simultaneously gives each gamma_i the standard r-Gaussian marginal law. Those marginals are recorded as context; they do not establish the joint assertion and have no edge into it.

For i=1,...,d take theta_i=(i-1/2)pi/d and t_i=(1,sqrt(2)cos(theta_i),...,sqrt(2)cos(q theta_i))^T, with t coordinates indexed by j=0,...,q. The leading coordinate is exactly 1. The tensor order is gamma first and t second, as in the source B row. Set R_i=||gamma_i||^2 and L=2r+3 log(1000d). The actual matrix is

    Y_i = (1/d)(gamma_i gamma_i^T tensor t_i t_i^T) 1_{R_i <= L}.

It takes values in r^2 by r^2 real matrices. With row/column indices (a,j),(b,k), its entry is (1/d)(gamma_i)_a(gamma_i)_b(t_i)_j(t_i)_k times that same row-local indicator. Equality at L is included. This is a deterministic Borel-map candidate F_i of gamma_i, with a fixed i-dependent t_i. The source calls the resulting Y_i independent. It does not call the Y_i identically distributed, and no iid claim is inferred because the deterministic t_i varies with i. Neither conditioning on the simultaneous event T nor replacing each local cutoff by a common-event indicator is the source definition.

The q=0 case is retained. Then r=1, d>=2, t_i=(1), and Y_i is the 1 by 1 matrix (1/d)(g_1)_i^2 1_{(g_1)_i^2 <= 2+3 log(1000d)}. No positive-q assumption is introduced. The inequality also gives d>=2, so the displayed division and logarithm input have their natural source domain. No tau<=1/2, concentration event, C, kappa, eigenvalue parameter, moment, norm bound on t_i, radial mean, bias estimate, or variance assumption is needed for the selected independence assertions.

The source omits the argument from independent Gaussian columns to joint physical rows, and then from rows to separate truncated row maps. The omitted-bridge file lists product-law, finite-coordinate regrouping, sigma-field interpretation, measurable-map and independence-preservation ports. These are source-supported mathematical inferences to be discharged after a future seal; they are not proved here, not claimed as compiled parents, and not added as hypotheses.

The bounded inventory covers every substantive paragraph/display in Appendix C.2 from its first paragraph through the end of p12, plus the listed Section 4 definition and experiment context. It explicitly excludes the C.5 moment/cosine/range/norm assertions, the C.6 concentration statement, the tail proof and common-event probability, and the p11/p12 bias/mean route. Later PSD, centered variance, concentration proofs, original extended-ambient transfer, and main lower bounds lie outside this raw window and outside the selected delta. This is not whole-paper or whole-Lemma-4.4 coverage.

Definition/substitution and direct source consumer uses appear only in a preliminary draft graph. No source topology is accepted by this extractor. Its contents must remain distinguishable from a future graph finalized after statement sealing and from a compiler-backed Lean dependency graph.
