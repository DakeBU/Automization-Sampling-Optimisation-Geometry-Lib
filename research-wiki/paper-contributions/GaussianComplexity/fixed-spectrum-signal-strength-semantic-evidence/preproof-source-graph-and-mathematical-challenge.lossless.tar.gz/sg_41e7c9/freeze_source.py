from pathlib import Path
from datetime import datetime, timezone
from collections import Counter
import hashlib
import json
from bs4 import BeautifulSoup

base=Path(__file__).resolve().parent
root=base.parents[2]
source=root/'.astis/huanjian-resume-20261103/2610.20492v1.html'
source_bytes=source.read_bytes()
sha=lambda b:hashlib.sha256(b).hexdigest()
expected='6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
assert sha(source_bytes)==expected
units=json.loads((base/'raw_unit_inventory.json').read_text())
assert len(units)==809
assert len({x['unit'] for x in units})==len(units)
for x in units:
    b=x['raw_html'].encode('utf-8')
    assert sha(b)==x['raw_sha256']
    assert source_bytes[x['start_byte']:x['end_byte']]==b
scopes=json.loads((base/'raw_extraction_manifest.json').read_text())['scopes']
scope_checks=[]
for x in scopes:
    b=(base/x['raw_file']).read_bytes()
    assert sha(b)==x['raw_sha256']
    soup=BeautifulSoup(b,'html.parser')
    ours=[q for q in units if q['scope']==x['anchor']]
    labelled={q['id'] for q in ours if q['id']}
    assert labelled=={q['id'] for q in soup.find_all(id=True)}
    assert len(soup.find_all('math'))==sum('math' in q['kinds'] for q in ours)
    assert len(soup.find_all('p'))==sum('paragraph' in q['kinds'] for q in ours)
    scope_checks.append(dict(anchor=x['anchor'],raw_units=len(ours),
        labelled_elements=len(labelled),math_elements=len(soup.find_all('math')),
        paragraphs=len(soup.find_all('p')),all_raw_spans_match_original=True))
protocols=['AGENTS.md','docs/contributor-codex-contract.md',
 'docs/proof-digestion-protocol.md','docs/evidence-routed-memory-protocol.md',
 '.agents/skills/astis-source-dependency-audit/SKILL.md']
manifest=dict(schema='source-only-cognition-freeze-v1',stage='PHASE1_FROZEN_BEFORE_CANDIDATE',
 created_utc=datetime.now(timezone.utc).isoformat(),
 original_source=dict(path=str(source),sha256=expected),
 process_sources=[dict(path=p,sha256=sha((root/p).read_bytes())) for p in protocols],
 mathematical_scopes=['S2','S4','A3.SS3','bib.bib3 (displayed [22])'],
 cognition='phase1_mathematical_cognition.md',inventory='raw_unit_inventory.json',
 scope_checks=scope_checks,
 exposures=dict(candidate_signature=False,candidate_definitions=False,
     implementation_Lean=False,mathlib=False,candidate_lessons_audits_frontiers=False,
     other_reviewers=False,previous_verdicts=False,
     selected_target_inferred=False,external_cited_paper_consulted=False,
     incidental=['Initially selected DOM bib.bib22; saw displayed [19] bibliography title/metadata. Corrected to displayed [22] at bib.bib3 by following S4 links. No mathematics used from [19].',
     'Raw cross-reference href/title attributes expose destination labels/titles outside scope, but destination bodies were not read.']),
 limitations=['This extractor cannot independently approve its own source coverage.',
     'No statement approval or Lean dependency/compilation claim is made.',
     'C.1, C.2, C.4, Fact C.6, the proof of Lemma 4.7, Theorem 3.1, and cited [22] theorem interiors were not consulted.',
     'The full source file is parsed for spans, but only selected source bodies are mathematically read.'],
 files=[])
for f in sorted(base.iterdir()):
    if f.is_file() and f.name not in {'phase1_freeze.json','phase1_freeze.sha256'}:
        b=f.read_bytes()
        manifest['files'].append(dict(path=f.name,bytes=len(b),sha256=sha(b)))
b=(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode('utf-8')
(base/'phase1_freeze.json').write_bytes(b)
seal=sha(b)
(base/'phase1_freeze.sha256').write_text(seal+'  phase1_freeze.json\n')
print(json.dumps(dict(freeze_path=str(base/'phase1_freeze.json'),sha256=seal,
                     raw_units=len(units),scope_checks=scope_checks),indent=2))
