# Lemma 6.7: bounded source preparation

This packet reconstructs a source route. It supplies no Lean target, proof,
ingredient certificate, intake decision, Statement Seal, source acceptance, or
new frontier. R12 remains closing local V. Independent review of this authored
graph is pending.

The source boundary was frozen first in `RAW_EXPECTATIONS.freeze.md`, SHA-256
`9e18a3582df68e740a4e87e4e9e216139e254c125df259a262af17c11848a59f`.
`SOURCE_GRAPH.json` then records the source nodes, consumer use sites, explicit
exclusions, open ports, and the separate Gaussian adapter boundary. The small
`STRUCTURE_CHECK.json` checks references and graph shape only; it is not
mathematical review.

## Source and actual consumer

Tropp's author preprint, revised 15 June 2011, Lemma 6.7 (pp. 25-26), is a
single-matrix mgf estimate:

\[
\mathbb E X=0,\quad \lambda_{\max}(X)\le1
\quad\Longrightarrow\quad
\mathbb E e^{\theta X}\preceq
\exp\!\big((e^\theta-\theta-1)\mathbb E(X^2)\big),
\qquad\theta>0.
\]

The source's Section 2.2 makes the eigenvalue bound almost sure and gives an
unquantified standing regularity convention for expectations and limits. The
matrix is finite complex self-adjoint; the source is not limited to real
symmetric matrices. Independence is absent at this single-variable step.

The native consumer is Theorem 6.1. It applies Lemma 6.7 to each normalized
summand, then Corollary 3.7 with
\(A_k=\mathbb E(X_k^2)\) and \(g(\theta)=e^\theta-\theta-1\).
The positive-semidefinite total variance identifies
\(\rho=\lambda_{\max}(\sum_k A_k)=\|\sum_k A_k\|=\sigma^2\).
Scalar optimization gives Bennett part (i), an omitted scalar comparison for
\(h\) gives Bernstein part (ii), and two rational-function monotonicity estimates
give split part (iii).

The native background is:

```text
Lieb Theorem 3.2 [Lie73, Theorem 6]
  -> Jensen Corollary 3.3
  -> conditioned cgf Lemma 3.4 --+
                               +-> Master Tail Theorem 3.6
Laplace Proposition 3.1 --------+        -> Corollary 3.7
Lemma 6.7 ------------------------------------+-> Theorem 6.1
```

These arrows describe the source's use sites. Every background port remains
open without a supplied formal certificate. Golden-Thompson, scalar mgf
multiplication, and alternative Lieb proofs are not extra AND inputs of this
route.

## Semantic fields to preserve before any later signature

| Field | Source status | Exact boundary |
|---|---|---|
| X | SOURCE/TYPING | Random self-adjoint finite square complex matrix; compatible size is implicit. |
| Centering | SOURCE | The matrix expectation satisfies \(\mathbb E X=0\); this is not a zero scalar trace condition. |
| Upper spectral cap | SOURCE | \(\lambda_{\max}(X)\le1\); almost surely by Section 2.2. No lower cap or operator-norm cap is stated. |
| Theta | SOURCE | Every real \(\theta>0\), after X is fixed. The lemma makes no claim for negative theta. |
| Loewner order | SOURCE definition | \(A\preceq B\) means \(B-A\) positive semidefinite. It is not entrywise order. |
| Square and expectation | SOURCE formula | \(X^2=XX\), then matrix expectation \(\mathbb E(X^2)\). It is not \((\mathbb E X)^2\). |
| Matrix exponential | SOURCE definition | Spectral scalar exponential, equivalently the matrix power series; the scalar \(e^\theta\) coefficient is distinct. |
| Eigenvalue/norm | SOURCE definition | Algebraic maximum eigenvalue versus maximum singular value. For self-adjoint A, norm is max of both spectral signs. |
| Probability space | STANDING/TYPING only | No explicit base space, measure, sigma algebra, measurability predicate, or integration construction is supplied. |
| Analytic regularity | STANDING, unquantified | Section 2.2 justifies expectations, limit interchange, etc. It does not enumerate finite-second-moment hypotheses. |
| All higher moments | Absent from this lemma | The all-order introduction in Section 3.1 and moment-growth hypothesis of Theorem 6.2/Lemma 6.8 do not become Lemma 6.7 premises. |
| Finite family in Theorem 6.1 | SOURCE | Independence, common dimension d, centering for every k, and a common upper spectral bound R almost surely. |
| Theorem 6.1 threshold | SOURCE | All real \(t\ge0\), with an upper-eigenvalue event \(\{\lambda_{\max}(\sum X_k)\ge t\}\). |
| Positive R and variance | Source imprecision | Not explicitly stated, although scaling and printed formulas divide by R and \(\sigma^2\). Zero-scale interpretation remains unresolved. |

No actual binder audit is claimed: there is no target signature to inspect. In
any later source-facing audit, the monotonicity of f, the exponential identity,
congruence order, integrability discharge, mgf estimate, variance identification,
and two-tail adapter must be dependency edges. Their conclusions are not newly
authorized public premises.

## Internal omitted ports and failure boundary

The whole-line scalar function
\(f_\theta(x)=(e^{\theta x}-\theta x-1)/x^2\), with value
\(f_\theta(0)=\theta^2/2\), must be smooth and increasing for **all real x**.
The proof uses negative eigenvalues without a lower bound. The narrow independent
raw-source note in `scalar_check/scalar_reading.md` reconstructs this omitted
calculus using a finite-interval integral. This is an informal source check,
not a supplied proof certificate or review of the graph.

The matrix step uses scalar functional calculus and congruence:
\(f(X)\preceq f(1)I\) implies \(Xf(X)X\preceq f(1)X^2\).
It does not require X positive semidefinite, f operator monotone, or matrix
exponential operator monotone. The source separately uses trace-exponential
monotonicity in Corollary 3.7.

The expectation step needs legitimate matrix expectations and linearity/order.
A one-sided upper cap and centering allow an arbitrarily heavy negative tail,
so they do not alone imply a finite second moment. Conversely, at positive theta
the exponential is bounded above by \(e^\theta I\) under that cap, so its
integrability has a different boundary. The source relies on its broad
regularity convention for the displayed finite variance. Do not silently turn
that source imprecision into an attributed explicit hypothesis.

The printed optimizer \(\theta=\log(1+t/\sigma^2)\) is positive for
\(t>0,\sigma^2>0\). At \(t=0\), it is zero and the positive-theta infimum is
approached at the boundary; the printed word “attains” is imprecise there. The
shared split threshold has matching formulas in the positive-scale regime.
No source correction or endpoint convention is authorized by this packet.

## Gaussian background boundary

The pinned Gaussian original's Appendix C.2, `A3.SS2.p15` / `A3.Ex121`, invokes
an uncited two-sided bounded matrix Bernstein inequality for independent centered
real symmetric matrices of dimension \(r^2\), with norm cap \(R_*\), variance
envelope \(v_*\), and \(t>0\):

\[
\Pr\!\left(\left\|\sum_i Z_i\right\|_{\rm op}>t\right)
\le2r^2\exp\!\left(-\frac{t^2}{2(v_*+R_*t/3)}\right).
\]

The raw source gives the same bound for the cosine-weighted sequence. Tropp is
an independently selected external background source, not a citation found at
that Gaussian invocation.

A prospective adapter must derive the positive and negative spectral caps from
the norm cap, preserve independence/centering/squares under negation, join the
two tails through the self-adjoint norm identity and a union bound, replace the
exact variance by its upper envelope, preserve real/complex semantics if needed,
and handle the strict event by inclusion. The dimension prefactor is \(2r^2\);
the ambient Gaussian sample-count parameter d is not the matrix dimension at
this use site. These adapters remain open and do not change Gaussian public
hypotheses.

## Artifact boundary

The graph currently contains 96 nodes, 91 directed use-site edges, and 90
coverage records, including 19 explicit scope exclusions. Counts are structural
observability, not proof or completeness badges. All statement/proof fragments
in the declared core are assigned nodes; inspected interposed sibling results
and remarks are excluded with reasons. Full external Lieb proof, analytic
infrastructure, independent topology review, and any implementation remain
outside this completed preparation task.

No Lean file, API header, authored R12 lesson/decode/verdict, prior Bernstein
conclusion, queue, private guardmap, ledger, frontier, site, import, or shared
record was read as mathematical evidence or changed. No browser was launched;
no ASTIS background process or build ran. `MANIFEST.json` and `SHA256SUMS` pin the
local outputs and exact input originals.
