# Phase 1 source-only packet

Authoritative cognition: analysis/source-cognition-v1.md.
Authoritative source graph: analysis/source-proof-cognition-graph-v2.json.
Exposure and knowledge limits: analysis/scope-exposure-v1.json.
The graph v1 is retained; v2 corrects only the hard-grid display locator from the guessed S4.Ex11 to the observed S4.E11. No mathematical content changed.

inputs/ contains the exact pinned raw and exact authorized procedural snapshots.
raw/ contains original-byte HTML slices, math alttext, complete source proofs and byte/hash locator indices.
logs/ retains command text, stdout/stderr where separately exposed, complete initial tool results, both display truncations, the first process-creation failure and successful recovery.
scripts/ contains only source extraction and phase validation/freezing support; no Lean code.

This phase is a source-only cognition freeze before candidate interfaces, anonymous decoder, and full code. It is not a Lean/source fidelity verdict, a theorem proof, or a pretrained zero-knowledge/pristine guarantee.

Freeze hash graph: MANIFEST.json hashes every other payload (not itself). The sibling phase1-source-only.receipt.json records the manifest digest, validates file/directory modes and captures finalizer stdout/stderr; it is outside the phase payload and is not included by the manifest. The receipt does not hash itself. The printed receipt digest may be used externally. This avoids a hash cycle.

Do not edit or overwrite this phase. Any later exposure or correction belongs in a new phase, retaining all predecessors.
