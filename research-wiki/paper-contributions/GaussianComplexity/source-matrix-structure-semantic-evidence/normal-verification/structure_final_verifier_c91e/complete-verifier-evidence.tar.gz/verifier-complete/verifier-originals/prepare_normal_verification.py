"""Prepare concrete payload/cell without any control-plane mutation."""
from pathlib import Path
import copy, hashlib, json
O = Path('.astis/semantic-neutral-20261113/structure_final_verifier_c91e')
E = Path('research-wiki/paper-contributions/GaussianComplexity/source-matrix-structure-semantic-evidence')
F = Path('.astis/semantic-neutral-20261113/structure_final_native_f30b')
C = Path('research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-source-matrix-structure.json')
sha = lambda b: hashlib.sha256(b).hexdigest()
def read(p): return json.loads(p.read_bytes())
def write(p,o): p.write_text(json.dumps(o,ensure_ascii=False,indent=2)+'\n')
original = read(E/'actual-PROVED_LOCAL-evidence.full.json')
assert len(original) == 26 and sha((E/'actual-PROVED_LOCAL-evidence.full.json').read_bytes()) == 'a5122144f029a363c06e4769e82195ae925e4a09879b7da64def4b5c8dd71004'
assert read(O/'final-package-review.bounded.json')['status'].startswith('PASS_')
pre = read(O/'preliminary-readiness.bounded.json')
payload = copy.deepcopy(original)
current_reader = {
    'original_reader':'FAIL_MOBILE_PUBLICATION_TABLE',
    'conditional_reader':'PASS_ACTUAL_RUNTIME_POSITIVE_SCROLL_AND_INDEPENDENT_SAVED_SCREENSHOT_REVIEW',
    'original_report_sha256':'1378cb60969096e992b8e9fc4f4d5a4d5a4d5d42870aef8dce6d86ca3d157546',
    'conditional_report_sha256':'329efe2df2f20356885b578266b0ae447cf2a99ea5c5188c4d682d7e3354c08f',
    'positive_scroll_report_sha256':'412c74ddea1c6ca35eea379be614bb3f5c034098594d0412e2a26562349c4ca2',
    'actual_positive_scroll':{'original_after100_and_max':[0,0],'conditional_after100_and_max':[100,106],'right_edge_reachable':True},
    'candidate_CSS_globally_applied':False,
    'candidate_patch_sha256':'2442d520f5888f665b8bd76777334d36a3e3346888c4c9cb309ae891280a2bff',
    'production_CSS_sha256':'4509e56205aa4bb94c3fa32c7b2b0bd98a9b44a71c23e09f18d5affe038512ad',
    'conditional_CSS_sha256':'60acf59734f5f63567078cc8f442ca04f6e9e661acac745884f094ccc941d8b9',
    'independent_visual_reviewer':'structure_final_native_f30b',
    'reader_assessment':{'path':str(F/'reader-assessment.json'),'sha256':'6e116efc9f407c4ddb2239c968672c3319ffc4c18f978c92ca784aa546d8da74'},
    'remaining_mobile_limitation':'Fixed header partially covers source L13 target; unobscured line-anchor placement is NOT certified.',
    'integration_status':'HOLD: global CSS/site/navigation/source-anchor/global publication integration and purification remain unaccepted.',
    'historical_PL_reader_fields':'All original historical FAIL and conditional-positive-pending strings remain inline unchanged; this separate update supersedes only the pending current runtime/visual assessment.'}
payload.update({
    'verifier_id':'structure_final_verifier_c91e',
    'verified_commit':'cf75c5f89a8f93b79c255fb43a942f6d1b7d49e4',
    'gate':{
        'status':'PASS_LOCAL_MATH_SOURCE_NATIVE_AND_REQUIRED_CLI_GATES',
        'actual_native_compiled_commit':original['mathematical_candidate'],
        'all_seven_live_Lean_module_bytes_unchanged_from_actual_compiled_commit':pre['all_seven_module_bytes_unchanged'],
        'held_commit_claimed_compiled':False,
        'actual_held_CLI_gates':['publication --base 96fc5f68fa7e0390e43279fd3228aa60f9ad3a90: exit0','semantic-roundtrip check: exit0','contributor --base 96fc5f68fa7e0390e43279fd3228aa60f9ad3a90: exit0','full frontier check: exit0'],
        'CLI_summary':{'path':str(F/'gate-summary.json'),'sha256':'eb631585985bb8e72c4737cd4df8d4da6c31d5003920f57da048910fe902356e'},
        'original_root_build_and_full_value_checks':original['focused_checks'],
        'scope':'Unchanged-evidence reuse; no new Lean/browser/source review experiment. Root/global integration acceptance is separate.'},
    'source_audit':{
        'status':'ACCEPTED_EXISTING_INDEPENDENT_SOURCE_REVIEW_REUSED',
        'reviewer':'structure_src_c24d',
        'public_audit_id':'ASTIS-RT-20261113-HuanjianGaussianSourceMatrixStructure',
        'public_canonical_audit':'research-wiki/semantic-roundtrip/audits/huanjian-gaussian-source-matrix-structure.json',
        'public_binding_sha256':original['publication_binding_sha256'],
        'private_T_binding_sha256':'ad250e21bf49f797eb59e07e6bc8b900065ecefd9547bc5dced5f1d92c28de30',
        'original_and_current_seven_slot_review':original['independent_source_review'],
        'own_verifier_check':'All70 selected source archive members/bytes, source raw/whole-code freeze provenance, independent decoder/result/run chain and current accepted overlay/context/input equality verified. No source verdict rewritten or mathematical source review replayed.'},
    'semantic_roundtrip_audit':'ASTIS-RT-20261113-HuanjianGaussianSourceMatrixStructure: accepted, equivalent-after-elaboration, seven slots; separately accepted private T review retained.',
    'fake_closure_scan':{
        'status':'PASS_UNCHANGED_SEVEN_MODULE_NATIVE_EVIDENCE',
        'path':'.astis/semantic-neutral-20261113/structure_native_92af/fake-closure-scan.json',
        'sha256':'ca1f5ea1d47183158b73a9d924d9c4fa5532253380dd659b3888fb1fbbeb5c8e',
        'all_closed':True,'nonstandard_axioms':[],
        'standard_axioms':['propext','Classical.choice','Quot.sound'],
        'actual_complete_native_type_and_value_rechecks':9,
        'complete_structured_ExprDAG_nodes':26185,
        'universal_q0_q0d2_literal_root_value_checks':True,
        'standard_matrix_product_Borel_and_L2_topology_kernel_checks':True},
    'final_current_reader_update':current_reader,
    'final_native_reader_package':{
        'path':str(F/'selected-evidence.tar.gz'),
        'sha256':'b37c5a0a7d0ddb64332709849743762e5cb48e9adbb01a6fdde61a97c9fdb8ad',
        'bytes':26849221,'members':1174,
        'archive_closure_sha256':'ba168ab2de1ae28ea3e4fd1104313ea1e34663d5a619d0a0d4159ad1d43ef0dc',
        'own_manifest_membership_and_payload_hashes_verified':True,
        'own_complete_archive_member':'native-reader-selected-evidence.tar.gz',
        'private_preservation_maps_indexes_and_control_snapshots_exported':False},
    'original_PL_carry':{
        'field_count':26,'all_original_fields_inline_unchanged':True,
        'original_full_payload_sha256':'a5122144f029a363c06e4769e82195ae925e4a09879b7da64def4b5c8dd71004',
        'original_actual_append_sha256':'94ee6f11e85f34e783daf1438afa068998418a664733c14ca3689f9100aca391',
        'historical_reader_strings_preserved':True},
    'verification_scope':{
        'local_mathematics_and_source_native':'VERIFIED',
        'retained_owner':'huanjian_gc_20261113_source_matrix_structure',
        'stabilization_owner_transfer':False,
        'integration_publication_purification_whole_Goal':'HOLD',
        'same_original_unconditional_product_mu':True,
        'sole_hq_q0_inclusive_cutoff_actual_Bochner_mean_preserved':True,
        'separate_five_outputs_for_each_family_only':True,
        'no_combined_family_independence_iid_PSD_probability_tail_or_main_result_claim':True},
    'preservation_verification_plan':{
        'old_baseline_before_and_after':'Full foreign states/frontiers/discovery ledger and all captured tracked/control bytes/modes/index preserved.',
        'fresh_held_before_and_after':'Private full current tracked/index/state snapshot; exact old ledger prefix and one normal VERIFIED append; only ownC and ledger may change.',
        'full_private_maps_exported':False},
})
assert all(payload[k] == v for k,v in original.items()), 'original PL field altered'
cell = read(C); assert cell['status'] == 'proved_locally'
before = copy.deepcopy(cell)
cell['status'] = 'independently_verified'
cell['evidence']['independent_verification'] = (
    'Independent verifier structure_final_verifier_c91e at held cf75c5f8 accepted local math/source/native by unchanged seven-module evidence from actually compiled9ed997b7 and actual four current CLI gates. Original reader FAIL retained; exact conditional runtime/visual/positive-scroll PASS remains globally UNAPPLIED. Mobile sourceL13 fixed-header limitation, integration/publication/purification/whole-Goal HOLD and original owner retained. Full26 original PL evidence is inline unchanged in independent_verification_details.')
cell['evidence']['independent_verification_details'] = copy.deepcopy(payload)
cell['evidence']['final_current_reader_update'] = copy.deepcopy(current_reader)
assert all(cell[k] == v for k,v in before.items() if k not in ['status','evidence'])
assert all(cell['evidence'][k] == v for k,v in before['evidence'].items())
assert all(cell['evidence']['independent_verification_details'][k] == v for k,v in original.items())
write(O/'VERIFIED-evidence.full.json',payload)
write(O/'candidate-cell.exact.json',cell)
write(O/'ROOT-READY.received.json',{'source':'Explicit parent ROOT READY message','held_head':payload['verified_commit'],
    'authorized_actor':payload['verifier_id'],'at_most_one_normal_VERIFIED_API_call':True,
    'mutation_scope':[str(C),'runs/substantive_advances.jsonl'],
    'full26_original_PL_inline_carry_required':True,'private_guards_and_indexes_must_not_be_exported':True,
    'postwrite_full_frontier_schema_required':True,'owner_and_all_other_lanes_retained':True})
print(json.dumps({'status':'PREPARED_NO_C_OR_LEDGER_MUTATION','original_PL_fields_carried':26,
    'payload_sha256':sha((O/'VERIFIED-evidence.full.json').read_bytes()),
    'candidate_cell_sha256':sha((O/'candidate-cell.exact.json').read_bytes()),
    'independent_verification_type':type(cell['evidence']['independent_verification']).__name__}))
