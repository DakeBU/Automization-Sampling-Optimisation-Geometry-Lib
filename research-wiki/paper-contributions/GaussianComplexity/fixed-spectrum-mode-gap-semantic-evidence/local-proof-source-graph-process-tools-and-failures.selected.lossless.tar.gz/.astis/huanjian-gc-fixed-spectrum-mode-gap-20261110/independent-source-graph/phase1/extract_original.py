from html.parser import HTMLParser
from pathlib import Path
from collections import Counter
import hashlib,json,re
root=Path('/Users/zhouhuanjian/ASTIS-GC')
out=root/'.astis/huanjian-gc-fixed-spectrum-mode-gap-20261110/independent-source-graph/phase1'
source=root/'.astis/huanjian-resume-20261103/2610.20492v1.html'
payload=source.read_bytes();digest=hashlib.sha256(payload).hexdigest()
assert digest=='6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
html=payload.decode();lines=html.splitlines()
class Node:
 def __init__(self,tag,attrs,line,col,parent=None):
  self.tag=tag;self.attrs=dict(attrs);self.line=line;self.col=col;self.end=line;self.parent=parent;self.children=[];self.parts=[]
 def text(self):
  if self.tag=='math':return '$'+self.attrs.get('alttext','')+'$'
  if self.tag=='annotation':return ''
  return re.sub(r'\s+',' ',''.join(p.text() if isinstance(p,Node) else p for p in self.parts)).strip()
 def walk(self):
  yield self
  for p in self.children:yield from p.walk()
class Parser(HTMLParser):
 def __init__(self):super().__init__(convert_charrefs=True);self.root=Node('root',[],1,0);self.stack=[self.root]
 def handle_starttag(self,tag,attrs):
  n=Node(tag,attrs,*self.getpos(),self.stack[-1]);self.stack[-1].children.append(n);self.stack[-1].parts.append(n)
  if tag not in ('meta','link','img','br','hr','input','wbr','source','area','base','embed','param','track','col'):self.stack.append(n)
 def handle_endtag(self,tag):
  for j in range(len(self.stack)-1,0,-1):
   if self.stack[j].tag==tag:
    for n in self.stack[j:]:n.end=self.getpos()[0]
    del self.stack[j:];return
 def handle_data(self,text):self.stack[-1].parts.append(text)
p=Parser();p.feed(html);allnodes=list(p.root.walk());byid={n.attrs['id']:n for n in allnodes if n.attrs.get('id')}
scopes=[{'root_id':s,'name':name,'original_lines':[byid[s].line,byid[s].end]} for s,name in [('S2','section2-complete'),('S4','section4-complete'),('A3.SS3','appendixC3-complete')]]
bibliography_ids=sorted({n.attrs['href'][1:] for s in ['S2','S4','A3.SS3'] for n in byid[s].walk() if n.attrs.get('href','').startswith('#bib.')})
for s in bibliography_ids:scopes.append({'root_id':s,'name':'genuinely-cited-bibliography:'+s,'original_lines':[byid[s].line,byid[s].end]})
units=[];dispositions=[]
for n in allnodes:
 scope=next((s for s in scopes if s['original_lines'][0]<=n.line<=s['original_lines'][1]),None)
 if not scope:continue
 cl=n.attrs.get('class','').split();kind=None
 if n.tag=='section':kind='section-context'
 elif 'ltx_bibitem' in cl:kind='bibliography-entry'
 elif 'ltx_theorem' in cl:kind='theorem-block'
 elif 'ltx_proof' in cl:kind='proof-block'
 elif n.tag in ['h2','h3','h4','h5','h6']:kind='heading'
 elif n.tag=='div' and 'ltx_para' in cl:kind='paragraph-container'
 elif n.tag=='p':kind='paragraph'
 elif n.tag=='table' and ('ltx_equation' in cl or 'ltx_equationgroup' in cl):kind='display'
 elif n.tag=='tbody':kind='tbody'
 elif 'ltx_cite' in cl:kind='external-citation'
 elif n.tag=='a' and n.attrs.get('href','').startswith('#'):kind='internal-reference'
 elif n.tag in ['dt','dd']:kind='definition-term' if n.tag=='dt' else 'definition-description'
 elif n.tag=='li':kind='list-item'
 if not kind:continue
 parent=n.parent
 while parent and not parent.attrs.get('id'):parent=parent.parent
 ident=n.attrs.get('id') or ((parent.attrs.get('id') if parent else 'source')+'::'+n.tag+'@'+str(n.line))
 table=n.parent
 while table and table.tag!='table':table=table.parent
 tableid=table.attrs.get('id') if table else None
 u={'raw_unit_ordinal':len(units),'source_unit_key':f'{n.tag}@{n.line}:{n.col}','id':ident,'original_html_id':n.attrs.get('id'),'kind':kind,'scope':scope['name'],'original_lines':[n.line,n.end],'original_start_column':n.col,'parent_original_html_id':parent.attrs.get('id') if parent else None,'containing_display_id':tableid,'text_with_tex':n.text(),'math':[{'id':m.attrs.get('id'),'line':m.line,'tex':m.attrs.get('alttext'),'display':m.attrs.get('display')} for m in n.walk() if m.tag=='math'],'references':[{'line':a.line,'href':a.attrs.get('href'),'title':a.attrs.get('title'),'text':a.text()} for a in n.walk() if a.tag=='a' and a.attrs.get('href','').startswith('#')],'raw_html_LF_fragment_sha256':hashlib.sha256(('\n'.join(lines[n.line-1:n.end])+'\n').encode()).hexdigest()}
 units.append(u)
 disposition='NODE';reason=None
 if kind in ['section-context','heading','proof-block','paragraph-container']:
  disposition='EXCLUDED';reason='Structural wrapper/heading. Every substantive descendant statement, definition-bearing paragraph, proof paragraph, display, mathematical row and citation/reference is separately inventoried.'
 elif kind=='paragraph' and u['text_with_tex']=='∎':
  disposition='EXCLUDED';reason='Standalone proof-end marker, not a mathematical statement.'
 elif kind=='tbody' and u['original_html_id'] is None:
  disposition='EXCLUDED';reason='Anonymous rendering subcontainer; all mathematical fields remain here and are captured by display NODE '+str(tableid)+'.'
 elif kind=='internal-reference' and (scope['name'].startswith('genuinely-cited-bibliography') or u['parent_original_html_id'] in ['S2','S4','A3.SS3']):
  disposition='EXCLUDED';reason='Bibliography cited-by or section-heading navigation; exact reference metadata retained. Mathematical reference use-sites elsewhere are separately inventoried.'
 dispositions.append({'raw_unit_ordinal':u['raw_unit_ordinal'],'source_unit_key':u['source_unit_key'],'id':ident,'original_lines':u['original_lines'],'kind':kind,'disposition':disposition,'reason':reason,'raw_node_id':('mode-gap-raw:'+str(u['raw_unit_ordinal'])) if disposition=='NODE' else None})
assert len(units)==len({u['source_unit_key'] for u in units})
inv={'schema':1,'status':'NEW_RAW_SOURCE_ONLY_BEFORE_NEW_TARGET','source_path':str(source.relative_to(root)),'source_sha256':digest,'source_bytes':len(payload),'source_read_provenance':'Fresh parse and full source-only rereading of enumerated original sections. No earlier inventory/graph/verdict file was read as input in this phase.','scopes':scopes,'bibliography_ids_genuinely_used':bibliography_ids,'identity':'Unique fresh raw ordinal plus source tag/line/column. Original IDs and same-line synthetic-ID collisions retained without dictionary collapse. Earlier ordinals are neither imported nor used as mathematical authority.','units':units}
(out/'raw-unit-inventory.json').write_text(json.dumps(inv,indent=2,ensure_ascii=False)+'\n')
(out/'raw-unit-dispositions.json').write_text(json.dumps({'schema':1,'status':'TARGET_INDEPENDENT_RAW_DISPOSITIONS','rows':dispositions,'counts':dict(Counter(d['disposition'] for d in dispositions)),'kind_counts':dict(Counter(d['kind'] for d in dispositions)),'named_TBODY_policy':'Original named TBODY mathematical equation rows are raw NODEs; true containing display IDs are retained. Anonymous duplicated rendering containers explicitly name their capturing display.','not_claimed':'No exact-target coverage, Lean graph, proof or self-approved mathematical completeness.'},indent=2,ensure_ascii=False)+'\n')
with (out/'raw-source-reading.txt').open('w') as f:
 for u in units:
  if u['kind'] in ['heading','paragraph','display','definition-term','definition-description','list-item','bibliography-entry']:
   f.write(f"#{u['raw_unit_ordinal']} {u['id']} [{u['original_lines'][0]}-{u['original_lines'][1]}]\n{u['text_with_tex']}\n\n")
for s in scopes:
 lo,hi=s['original_lines'];name=s['name'].replace(':','-')
 (out/(name+'.raw.html')).write_text('\n'.join(lines[lo-1:hi])+'\n')
print(json.dumps({'source_sha256':digest,'scopes':scopes,'raw_units':len(units),'counts':dict(Counter(d['disposition'] for d in dispositions))},indent=2))
