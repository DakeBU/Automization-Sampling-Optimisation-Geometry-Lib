from pathlib import Path
import ast,datetime,difflib,gzip,hashlib,json

ROOT=Path('/Users/zhouhuanjian/ASTIS-GC')
OWN=ROOT/'.astis/semantic-neutral-20261110/tau_tc_19abf4'
OUT=OWN/'phase3';INPUT=OUT/'safe-process-inputs';INPUT.mkdir(exist_ok=True)
WORK=ROOT/'.astis/huanjian-gc-fixed-spectrum-threshold-20261110'
sha=lambda b:hashlib.sha256(b).hexdigest()
dump=lambda x:(json.dumps(x,indent=2,ensure_ascii=False)+'\n').encode()
inputs=[]
def safe_copy(path,expected=None,dest=None):
    p=Path(path);p=p if p.is_absolute() else ROOT/p;b=p.read_bytes()
    if expected:assert sha(b)==expected,str(p)
    name=dest or p.name;f=INPUT/name;f.write_bytes(b)
    row={'path':str(p.relative_to(ROOT)),'sha256':sha(b),'bytes':len(b),'copied_to':str(f.relative_to(OUT))};inputs.append(row)
    return b
process_rel='.astis/huanjian-gc-fixed-spectrum-threshold-20261110/strict-prospective-process-review-input.json'
process=json.loads(safe_copy(process_rel,'7de9e98d293fa94c7036015bdc30a0b59fe1c32d41e74159bbd86dbd93d417db'))
for row in process['allowed_process_inputs']:
    b=safe_copy(row['path'],row['sha256']);assert len(b)==row['bytes']
diagnosis_path='.astis/huanjian-gc-fixed-spectrum-threshold-20261110/preproof-typed-route-diagnosis.json'
safe_copy(diagnosis_path,'2090375b6127452c03eb4d599929d5c8efc0d5c93718e73170137b4ca7b69142')
v2_path='.astis/huanjian-gc-fixed-spectrum-threshold-20261110/admit_normal_intake_v2.py'
v2=safe_copy(v2_path,'54ce9f8feb88e5c067207e042e630e915bf6484db355ead4205bc857ba79ed46')
v1=(INPUT/'admit_normal_intake.py').read_bytes();ast.parse(v1.decode());tree=ast.parse(v2.decode())
old="baseline=json.loads((W/'preproof-baseline.json').read_bytes())"
new="assert len(sys.argv)==4, 'Pass exact independent private-baseline SHA256 as third runtime argument'\nassert sha((W/'preproof-baseline.json').read_bytes())==sys.argv[3]\n"+old
assert v2.decode()==v1.decode().replace(old,new)
script_delta=''.join(difflib.unified_diff(v1.decode().splitlines(keepends=True),v2.decode().splitlines(keepends=True),fromfile='admit_normal_intake.py',tofile='admit_normal_intake_v2.py'))
(OUT/'intake-control-v2.exact-diff.txt').write_text(script_delta)
calls=[n.func.attr for n in ast.walk(tree) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and isinstance(n.func.value,ast.Name) and n.func.value.id=='adv']
assert calls.count('propose_advance')==1 and calls.count('transition_advance')==2
probe=(INPUT/'statement-formation-probe.raw.lean.txt').read_bytes();assert gzip.decompress((INPUT/'StatementFormation.lean.gz').read_bytes())==probe
assert not (WORK/'StatementFormation.lean').exists()
seal=json.loads((INPUT/'statement-seal-v1.json').read_text())
for key in ['producer','actual_private_consumer']:
    assert sha(seal[key]['signature'].encode())==seal[key]['signature_sha256']
producer=(INPUT/'producer-signature.txt').read_bytes();consumer=(INPUT/'consumer-signature.txt').read_bytes()
assert producer.decode()==seal['producer']['signature'];assert consumer.decode()==seal['actual_private_consumer']['signature']
text=probe.decode();prodchunk=text.split('def producer_statement',1)[1].split('\ndef consumer_statement',1)[0]
conschunk=text.split('def consumer_statement',1)[1].split('\nend ThresholdStatementFormation',1)[0]
for chunk,sig,prefix in [(prodchunk,producer.decode(),'theorem eventual_actual_gaussian_threshold_small'),(conschunk,consumer.decode(),'private theorem actual_gaussian_source_query_shifted_event_le_tenth')]:
    h,b=chunk.split(' : Prop :=\n',1);sh,sb=sig.split(' :\n',1)
    assert h==sh[len(prefix):] and b.strip()==sb.strip()
assert 'sorry' not in text and 'axiom' not in text and 'theorem ' not in text
receipt_specs=[('.astis/huanjian-resume-20261103/20261110T033018075465Z-threshold-literal-Prop-only-statement-formation.receipt.json','4c2e8e207c223c69f9e950ec1b7686e592723d8c904b6706909bffd81b11a5be'),('.astis/huanjian-resume-20261103/20261110T033131027892Z-threshold-real-env-and-exact-statement-seal.receipt.json','31c14a527f8741536b757eee29aeb648b3d60019e00c9a051fa4fc43495d2a1f')]
receipts=[]
for p,h in receipt_specs:
    row=json.loads(safe_copy(p,h));log=safe_copy(row['log'],row['log_sha256']);assert row['exit_code']==0
    receipts.append({'started_utc':row['started_utc'],'elapsed_seconds':row['elapsed_seconds'],'receipt_sha256':h,'bound_log_sha256':sha(log),'exit_code':row['exit_code'],'head_before':row['head_before'],'head_after':row['head_after']})
base=ROOT/'.astis/semantic-neutral-20261110/tau_sg_74c208'
for phase,names in [('phase1',['run-manifest.json','freeze.json','exposure-disclosure.json']),('phase2',['run-manifest.json','freeze.json','structural-checks.json']),('phase2-v2',['run-manifest.json','freeze.json','affected-closure-checks.json'])]:
    for name in names:safe_copy(base/phase/name,dest='source-graph-'+phase+'-'+name)
f1=json.loads((INPUT/'source-graph-phase1-freeze.json').read_text());f2=json.loads((INPUT/'source-graph-phase2-freeze.json').read_text());f3=json.loads((INPUT/'source-graph-phase2-v2-freeze.json').read_text())
assert f1['run_manifest_sha256']==sha((INPUT/'source-graph-phase1-run-manifest.json').read_bytes())
assert f1['exposure_disclosure_sha256']==sha((INPUT/'source-graph-phase1-exposure-disclosure.json').read_bytes())
assert sha((INPUT/'source-graph-phase2-freeze.json').read_bytes())=='b72f4a4a31abb9b1b5cc359993f5bef80133964b0629793ee63c5da3f78713a5'
assert sha((INPUT/'source-graph-phase2-v2-freeze.json').read_bytes())=='7f2c34bf9a1ada4cc1c166c7912d59e47ced84f9fd2cc7a1d22e8c2e8bfb8a5f'
for frozen,phase in [(f2,'phase2'),(f3,'phase2-v2')]:assert frozen['run_manifest_sha256']==sha((INPUT/('source-graph-'+phase+'-run-manifest.json')).read_bytes())

prior={'phase1':'f28aba1f8685285b11bda9c555af55f03e63b204938ab45125f8b637a3e5d47e','phase2a':'b6f0d91a727569d03b74b9163bff16d0312a5884637c09b2409ebfadb12a52a2','phase2b':'2567748417894c9d7981b01f4db95492fe265e5e4773d8fc73f29b5dc67cd429','phase2b-v2':'5a6867cc2ac91ddce51f007fd0a2d9fa45de4366f5486012371b34727b19bf0c'}
prior_times={}
for phase,h in prior.items():
    p=OWN/phase/'FROZEN-MANIFEST.json';b=p.read_bytes();assert sha(b)==h;m=json.loads(b)
    for e in m['files']:assert sha((p.parent/e['path']).read_bytes())==e['sha256'],(phase,e['path'])
    prior_times[phase]=m['frozen_utc']

effective=datetime.datetime.now(datetime.timezone.utc).isoformat()
exposure={'phase':'3 separate prospective process audit','effective_utc':effective,'mathematical_manifests_unchanged':prior,'mathematical_freeze_times':prior_times,'inputs':inputs,'raw_foreign_baseline_or_state_snapshots_read':False,'raw_foreign_baseline_or_state_snapshots_copied':False,'private_baseline_commitment_only':process['private_baseline_commitment'],'late_root_coordination_disclosures':['Process-only archival of 456 exact selected mathematical-evidence files, no raw foreign snapshots; already disclosed conditional-prefix readback. Root reports no new target code/API/SAU/frontier and unchanged baseline ledger. These are disclosed assertions, not independently audited foreign state.','New private intake script v2 only; old script unchanged; exact two assertion-line delta independently verified and syntax-parsed, not executed.'],'validation_note':'One initial expected-delta comparison omitted the assertion explanatory message and failed; exact unified diff was inspected, correct two-line delta verified. No intake or mathematical code was executed.','reviewer_actions':'Only permitted read-only process/source-provenance inspection, byte/hash checks, Python syntax parsing, and writes under own phase3. No foreign/shared/Git/API/build/browser action.','C_metadata_amendment_required':False,'C_qualification':'Numeric positive-scale family only; not Source Anchor premises of Lemma4.4/Main. Existing explicit qualification sufficient.','no_retrospective_zero_planning_or_compliance_claim':True,'mathematical_verdicts_changed':False,'decision':'ACCEPT_PROSPECTIVE_QUALIFIED_LOCAL_ADMISSION','process_permission_starts_only_after_this_phase_is_frozen':True}
(OUT/'exposure-and-run-record.json').write_bytes(dump(exposure))
validation={'input_hashes':'PASS','probe_gzip_exact':'PASS','probe_headers_and_proposition_bodies_equal_sealed_types':'PASS','temporary_Lean_probe_absent_now':True,'logger_receipt_and_bound_raw_log_integrity':'PASS','receipts':receipts,'intake_v2_exact_delta_and_ast_parse':'PASS','intake_normal_API_call_counts':{'propose_advance':1,'transition_advance':2},'intake_execution_by_reviewer':False,'source_graph_process_freeze_bindings':'PASS','all_prior_frozen_math_hashes_unchanged':'PASS','private_guard_contents':'NOT_READ;runtime committed hash check required','source_or_proof_credit':False}
(OUT/'process-validation.json').write_bytes(dump(validation))

grant_inputs=[]
def grant_ref(path,h,**extra):grant_inputs.append({'path':str(path),'sha256':h,**extra})
for phase,h in prior.items():grant_ref(str((OWN/phase/'FROZEN-MANIFEST.json').relative_to(ROOT)),h,role='immutable independent mathematical phase')
for row in inputs:grant_ref(row['path'],row['sha256'],role='safe process provenance, exact seal, disclosure, signature or control artifact')
grant_ref('.astis/huanjian-gc-fixed-spectrum-threshold-20261110/preproof-baseline.json',process['private_baseline_commitment'],role='runtime-only private commitment; reviewer did not read raw contents',raw_contents_must_remain_private=True)
report=OUT/'independent-prospective-process-judgment.md';grant_ref(str(report.relative_to(ROOT)),sha(report.read_bytes()),role='independent prospective qualification')
grant_path=OUT/'prospective-local-admission-grant.json'
grant={'schema_version':1,'decision':'ACCEPT_PROSPECTIVE_QUALIFIED_LOCAL_ADMISSION','effective_utc':effective,'permission_effective_only_after_process_manifest_is_frozen':True,'prospective_target_Lean_proof_API_allowed_after_this_grant':True,'root_sole_mathematical_worker':True,'proof_work_requires_successful_guarded_normal_intake':True,'independent_inputs':grant_inputs,'source_sha256':'6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915','accepted_mathematical_graph_sha256':'58eba2c254cb645fdfb11e7d9c22f3ec0b7ca89855a8b55f8dd470ee20c0850c','allowed_intake_control':{'path':v2_path,'sha256':sha(v2),'normal_API_calls':3,'advance_id':'ASTIS-SA-20261110-GaussianComplexityFixedSpectrumThreshold','worker_id':'huanjian_gc_20261110_fixed_spectrum_threshold','exact_private_baseline_sha256':process['private_baseline_commitment'],'argv_after_script':[str(grant_path.relative_to(ROOT)),'<SHA256 of this exact grant file>',process['private_baseline_commitment']],'one_guarded_intake_only':True,'old_v1_script_not_forward_authorized':True,'on_guard_failure':'Stop; preserve actual records; no stale-baseline override or blind partial-intake retry.'},'exact_targets':[{'name':seal['producer']['name'],'path':seal['producer']['planned_file'],'signature_sha256':seal['producer']['signature_sha256']},{'name':seal['actual_private_consumer']['name'],'path':seal['actual_private_consumer']['planned_file'],'signature_sha256':seal['actual_private_consumer']['signature_sha256'],'private_non_Anchor':True}],'allowed_future_proof_API_scope':['After successful guarded normal intake, local proof development for these exact unchanged signatures by root only.','Read-only retrieval of existing canonical Gaussian/Bias/ModeGap/Variance/SignalStrength and necessary local/Mathlib APIs for these targets.','Internal providers inside the owned new module; genuine exact private diagonal-law shifted-event consumer; focused checks with fixed toolchain/manifest.','Bounded own evidence and normal own advance checkpoints; no self-VERIFIED, STAB or global transition.','Initial controlled writes only to own new producer/Test/frontier/evidence/seal paths and three own normal ledger events, with foreign-state postconditions; planned website/publication paths do not grant current publication permission.'],'mandatory_qualifications':['C/hC are the positive numeric-family scale domain, not source premises of Lemma4.4/Main and not a concentration witness.','Retain both preseal and postseal informal planning/API-name exposures and all three disclosure artifacts. No pristine zero-planning or retrospective compliance claim.','Every mathematical SOURCE_GAP remains unproved; proof ingredients remain internal dependencies, never new public hypotheses.','Signature or meaning-carrying definition changes require versioned successor and renewed affected independent gates.','Raw foreign guards remain private; this grant binds only safe hash/count metadata and runtime checks.'],'outstanding_local_process_HOLDs':[],'outstanding_out_of_scope_HOLDs':['All unproved mathematical obligations and later independent proof/semantic/source/native/publication gates.','Actual source absolute-C concentration, rotated/Krylov/Haar/adaptive/TV/oracle/full-main lower bound work is outside this grant.','Disclosed v9-prefix/global integration issue, actual original-owner release and fresh per-step identity/causal/STAB validation remain unresolved here.'],'not_granted':['Source-V/STAB/global lease or release authority','Foreign advances/frontiers or shared-root integration','Git/API publication, browser/site/public delivery, purification or whole-Goal completion','Human waiver, RULED source premise, source correction or retrospective compliance certification','Proof acceptance, compiled-edge credit or permission to alter sealed interfaces'],'C_metadata_amendment_required':False,'source_ruling':False,'mathematical_verdicts_changed':False,'retrospective_compliance_certified':False}
grant_path.write_bytes(dump(grant));grant_sha=sha(grant_path.read_bytes())
entries=[{'path':str(f.relative_to(OUT)),'bytes':f.stat().st_size,'sha256':sha(f.read_bytes())} for f in sorted(OUT.rglob('*')) if f.is_file() and f.name not in ['FROZEN-MANIFEST.json','FROZEN-MANIFEST.sha256']]
manifest={'freeze_id':'tau-tc-19abf4-phase3-prospective-process-admission','frozen_utc':effective,'effective_utc':effective,'prior_mathematical_manifest_sha256':prior,'all_prior_mathematical_files_hash_verified_unchanged':True,'decision':grant['decision'],'grant':{'path':str(grant_path.relative_to(ROOT)),'sha256':grant_sha},'permitted_intake_argv':['/opt/anaconda3/bin/python',v2_path,str(grant_path.relative_to(ROOT)),grant_sha,process['private_baseline_commitment']],'outstanding_local_process_HOLDs':[],'out_of_scope_HOLDs_retained':True,'raw_foreign_guards_read_or_copied':False,'proof_credit':False,'source_V_STAB_global_authority':False,'retrospective_compliance_certification':False,'files':entries}
f=OUT/'FROZEN-MANIFEST.json';f.write_bytes(dump(manifest));(OUT/'FROZEN-MANIFEST.sha256').write_text(sha(f.read_bytes())+'  FROZEN-MANIFEST.json\n')
for name in ['FROZEN-MANIFEST.json','prospective-local-admission-grant.json','independent-prospective-process-judgment.md','exposure-and-run-record.json','process-validation.json']:
    p=OUT/name;print(str(p.relative_to(ROOT)),sha(p.read_bytes()))
print('EFFECTIVE_UTC',effective)
