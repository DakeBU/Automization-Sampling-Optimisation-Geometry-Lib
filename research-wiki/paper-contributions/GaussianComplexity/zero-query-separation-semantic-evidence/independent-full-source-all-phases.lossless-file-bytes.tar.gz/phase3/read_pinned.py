from pathlib import Path
import subprocess,json,hashlib
BASE=Path(__file__).resolve().parent
REPO=Path('/Users/zhouhuanjian/ASTIS-GC')
COMMIT='eed870294de059136900110ade59b4a292a126ad'
E='research-wiki/paper-contributions/GaussianComplexity/zero-query-separation-semantic-evidence/'
specs=[
 ('P.lean','AutoSamplingTheory/ExampleCases/GaussianComplexity/ZeroQuerySeparation.lean',8126,'daa1be30e9478fdc744b0dce75e7accd0859dcc67123cfa5a411eed5045a2a92'),
 ('T.lean','Tests/GaussianComplexityZeroQuerySeparation.lean',3551,'2df4300e09f0ee12ee9448a68517d7dc0b5b01e41f644797bf1bf6f7d71a4406'),
 ('seal.json','research-wiki/paper-contributions/GaussianComplexity/zero-query-separation-statement-seal.json',None,None),
 ('lesson.json','website/content/declaration_lessons/huanjian-zero-query-separation.json',None,None),
 ('pub.json','website/content/publications/huanjian-zero-query-separation.json',None,None),
 ('correspondence.json',E+'source-to-lean-map-v1.json',None,'c88780cd868990738af8717ed3e2e00dd53d487d02ae7aa5f114b3481f7bcc2f'),
 ('reviewer_packet.json',E+'fresh-source-reviewer-packet.json',None,'0d80cbb9dccc960b46555474d2f85202448f416a06e0e0dd753b26317a9239c7')
]
records=[]
for name,path,size,sha in specs:
 argv=['git','show',COMMIT+':'+path]
 r=subprocess.run(argv,cwd=REPO,capture_output=True)
 (BASE/'tool_records'/(name+'.gitshow.stdout')).write_bytes(r.stdout)
 (BASE/'tool_records'/(name+'.gitshow.stderr')).write_bytes(r.stderr)
 records.append({'argv':argv,'cwd':str(REPO),'returncode':r.returncode,'stdout_raw_path':'tool_records/'+name+'.gitshow.stdout','stderr_raw_path':'tool_records/'+name+'.gitshow.stderr','stdout_bytes':len(r.stdout),'stdout_sha256':hashlib.sha256(r.stdout).hexdigest()})
 assert r.returncode==0,(name,r.stderr)
 if size is not None:assert len(r.stdout)==size,(name,len(r.stdout),size)
 if sha is not None:assert hashlib.sha256(r.stdout).hexdigest()==sha,(name,hashlib.sha256(r.stdout).hexdigest(),sha)
 (BASE/'inputs'/name).write_bytes(r.stdout)
(BASE/'tool_records/git_show_commands.json').write_text(json.dumps(records,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(records,ensure_ascii=False,indent=2))
