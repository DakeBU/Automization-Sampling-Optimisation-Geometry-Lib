import AutoSamplingTheory.TechnicalLemmas.Analysis.HessianStrongConvexity
import AutoSamplingTheory.TechnicalLemmas.Analysis.StrongConvexGibbsIntegrability
import AutoSamplingTheory.TechnicalLemmas.Measure.IsotropicGaussianDensity
import AutoSamplingTheory.TechnicalLemmas.Measure.Gibbs
import Mathlib.MeasureTheory.Measure.Tilted
import Mathlib.MeasureTheory.Integral.Prod

/- Prospective type-only header. No proof, Statement Seal or SAU claim. -/
namespace PBPSPhaseNormalizationCandidate103
open MeasureTheory InnerProductSpace ProbabilityTheory
open scoped ContDiff NNReal ENNReal Classical
noncomputable section
set_option autoImplicit false

def candidate
    {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℝ E]
    [FiniteDimensional ℝ E] [MeasurableSpace E] [BorelSpace E]
    {V : E → ℝ} {α β : ℝ≥0} {η : ℝ}
    (hα : 0 < (α : ℝ)) (hαβ : α ≤ β) (hV : ContDiff ℝ 2 V)
    (hH : ∀ x v : E,
      (α : ℝ) * ‖v‖ ^ 2 ≤ (fderiv ℝ (fderiv ℝ V) x v) v ∧
      (fderiv ℝ (fderiv ℝ V) x v) v ≤ (β : ℝ) * ‖v‖ ^ 2)
    (hη : 0 < η) (hβη : (β : ℝ) * η ≤ 1) : Prop := by
  classical
  exact
    let d : ℕ := Module.finrank ℝ E
    let Vy : E → E → ℝ := fun y x => V x + ‖x - y‖ ^ 2 / (2 * η)
    let U : E → E × E → ℝ := fun y z =>
      V z.1 + ‖z.1 - y‖ ^ 2 / (2 * η) + ‖z.2‖ ^ 2 / 2
    let w : E → E × E → ℝ := fun y z => Real.exp (-U y z)
    let ell : Measure (E × E) := (volume : Measure E).prod (volume : Measure E)
    let Zx : E → ℝ := fun y => ∫ x : E, Real.exp (-Vy y x) ∂volume
    let C : ℝ := (Real.sqrt (2 * Real.pi)) ^ d
    let Zphase : E → ℝ≥0∞ := fun y => ∫⁻ z, ENNReal.ofReal (w y z) ∂ell
    let piY : E → Measure E := fun y => (volume : Measure E).tilted (fun x => -Vy y x)
    let nu : E → Measure (E × E) := fun y =>
      ell.withDensity (fun z => (Zphase y)⁻¹ * ENNReal.ofReal (w y z))
    let gamma : Measure E := ProbabilityTheory.stdGaussian E
    ∀ y : E,
      Integrable (fun x => Real.exp (-Vy y x)) (volume : Measure E) ∧
      0 < Zx y ∧
      Zphase y = ENNReal.ofReal (Zx y * C) ∧
      0 < Zphase y ∧
      Zphase y < ⊤ ∧
      IsProbabilityMeasure (nu y) ∧
      nu y = (piY y).prod gamma

#check candidate
end
end PBPSPhaseNormalizationCandidate103
