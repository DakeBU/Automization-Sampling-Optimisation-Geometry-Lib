# Phase 1 independent source inventory

This reader uses source math alttext for readability. The raw HTML and byte locators are authoritative.
No sealed target or implementation Lean was read. Proof graph reconstruction is intentionally deferred.

## NODE src:S2.p1

source_definition; raw bytes [113642,115438); SHA256 f04281ad469a7d8ef07498b20d98d673a2689cab082910ffc640b7dbe363e8e2

Euclidean norm, identity matrix, and Loewner-order conventions.

We write $\|\cdot\|$ for the Euclidean norm and $I_{d}$ for the $d\times d$ identity matrix. For symmetric matrices $A$ and $B$ , the notation $A\preceq B$ means that $B-A$ is positive semidefinite.

## NODE src:S2.p2

source_definition; raw bytes [115439,118400); SHA256 bed92d74d2170dc58732b51c313c9b12d11b5b0d3bbb080609267d3a75df3743

Orthogonal group and Haar measure; determinant-conditioned Haar convention is background, unused in this bounded slice.

Let $O(n):=\{O\in\mathbb{R}^{n\times n}:O^{\top}O=I_{n}\}$ denote the real orthogonal group, equipped with Haar probability measure. It has two components, $\{\det O=+1\}$ , $\{\det O=-1\}$ , and each have Haar probability $1/2$ . For $b\in\{-1,+1\}$ , we write $\mu_{n,b}$ for Haar probability measure conditioned on $\det O=b$ .

## NODE src:S2.SS0.SSS0.Px1.p1

source_definition; raw bytes [118522,124857); SHA256 43faf856f1679cde1f381be72f9dc97a6409935d564839fb08f8d00184bb47b9

Precision class and centered Gaussian target; exact first-order oracle formula is separately excluded.

We restrict the target class to centered Gaussians. This restriction removes the hardness of locating the target and isolates the difficulty of sampling with an unknown covariance. For an integer $d\geq 1$ and a parameter $\kappa\geq 1$ , without loss of generality, we normalize the spectral bounds to $1$ and $\kappa$ by rescaling and consider the precision class $\mathcal{A}_{d,\kappa}:=\left\{A\in\mathbb{R}^{d\times d}:A=A^{\top},\quad I_{d}\preceq A\preceq\kappa I_{d}\right\}.$ An input $A\in\mathcal{A}_{d,\kappa}$ specifies the quadratic potential $f_{A}(x):=\frac{1}{2}x^{\top}Ax$ and the target distribution $\pi_{A}:=N(0,A^{-1})$ . At a point $x\in\mathbb{R}^{d}$ , the exact first-order oracle returns $\operatorname{FO}_{A}(x):=\bigl(f_{A}(x),\nabla f_{A}(x)\bigr)=\left(\frac{1}{2}x^{\top}Ax,Ax\right).$ (1)

## NODE src:S2.Ex1

source_definition; raw bytes [119831,121084); SHA256 3c29e55bc35a1b71616ec9f013d4d34a31fcd3d9e3bfe8cc27b0e491667b3220

Precision class and centered Gaussian target; exact first-order oracle formula is separately excluded.

$\mathcal{A}_{d,\kappa}:=\left\{A\in\mathbb{R}^{d\times d}:A=A^{\top},\quad I_{d}\preceq A\preceq\kappa I_{d}\right\}.$

## EXCLUDED src:S2.E1

reused_display; raw bytes [123015,124850); SHA256 a6ebb88418786a1b80a57a3609b02281210a09cb0144b1c8b5fce6249af35f11

Exact oracle reply formula is outside this bounded tau/detector packet.

$\operatorname{FO}_{A}(x):=\bigl(f_{A}(x),\nabla f_{A}(x)\bigr)=\left(\frac{1}{2}x^{\top}Ax,Ax\right).$ (1)

## EXCLUDED src:S2.SS0.SSS0.Px1.p2

proof_paragraph; raw bytes [124858,126285); SHA256 2d2d9accc133b161528218838791835eb9ed86366ba3271b72b5656f11ec2e26

Oracle-model equivalence is outside the tau-small and shifted-detector moment boundary.

On this class, exact first-order access is equivalent to exact matrix–vector access. Indeed, a first-order response contains $Ax$ , while a matrix–vector response determines both the gradient $Ax$ and the function value $\frac{1}{2}\langle x,Ax\rangle$ . Thus the exact value-and-gradient, gradient-only, and matrix–vector query complexities coincide.

## NODE src:S2.SS0.SSS0.Px2.p1

source_definition; raw bytes [126421,127625); SHA256 17509bc1b4fb2d4ac1c53f7761b99cbc650d8f59971eaf0e13420adcb03749eb

Borel algorithm/output, private randomness independent of input, deterministic per-run query cap.

A randomized algorithm chooses its queries and stopping decisions as Borel functions of its internal randomness and previous oracle responses, where the randomness is independent of the input. Its output may be any $\mathbb{R}^{d}$ -valued Borel function of the same information. The algorithm has fixed query budget $T$ if it makes at most $T$ queries for every admissible input and every realization of its internal randomness.

## EXCLUDED src:S2.SS0.SSS0.Px3.p1

source_definition; raw bytes [127757,132363); SHA256 3fc0d75e374cf9bb452e81f37d793b9c71ea8d436817db4dfefc4d493da2ff45

TV definition is context for the later contradiction; bounded extraction stops at the two test-probability estimates.

For probability measures $P$ and $Q$ on a common measurable space, their total variation distance is $\operatorname{TV}(P,Q):=\sup_{B}|P(B)-Q(B)|=\frac{1}{2}\int|p-q|\,d\lambda,$ where the supremum ranges over measurable sets, and $p$ and $q$ are the densities of $P$ and $Q$ with respect to any common dominating measure $\lambda$ . In particular, $|\mathbb{E}_{P}h-\mathbb{E}_{Q}h|\leq\operatorname{TV}(P,Q)$ for every measurable function $h$ taking values in $[0,1]$ .

## EXCLUDED src:S2.Ex2

reused_display; raw bytes [128330,129915); SHA256 b8bb95ca60aa442019852a2b9f146faf2b2fea98315d695ddbdc820e34fe50f3

TV formula supports the explicitly excluded final contradiction.

$\operatorname{TV}(P,Q):=\sup_{B}|P(B)-Q(B)|=\frac{1}{2}\int|p-q|\,d\lambda,$

## NODE src:S2.SS0.SSS0.Px4.p1

source_definition; raw bytes [132516,136546); SHA256 13d028a8e4881e6d543585d5baa71671bfea05b92e00fb1845c483f5f2aafa2a

Output law averages private randomness; Q_G definition separately excluded as surrounding theorem context.

For a fixed input $A$ , let $\rho_{A}^{\mathrm{Alg}}$ denote the law of the algorithm’s output, with all internal randomness included. For $0<\varepsilon<1$ , define $Q_{G}(d,\kappa,\varepsilon):=\inf\left\{T\in\mathbb{Z}_{\geq 0}:\begin{array}[]{l}\exists\,\mathrm{Alg}\text{ with fixed query budget }T\\[2.0pt] \text{such that }\displaystyle\sup_{A\in\mathcal{A}_{d,\kappa}}\operatorname{TV}\bigl(\rho_{A}^{\mathrm{Alg}},\pi_{A}\bigr)\leq\varepsilon\end{array}\right\}.$ (2) The accuracy requirement is uniform over inputs and concerns the output law after averaging over the algorithm’s seed. Throughout the paper, query budgets are deterministic caps on the number of queries in each run, rather than bounds on the expected number of queries.

## EXCLUDED src:S2.E2

reused_display; raw bytes [133493,136220); SHA256 6e0f27a01220746379e988a98806f27f8555d4b9b5ebac374e009f8cf890539b

Definition of query-complexity infimum is surrounding theorem context, not proved by this packet.

$Q_{G}(d,\kappa,\varepsilon):=\inf\left\{T\in\mathbb{Z}_{\geq 0}:\begin{array}[]{l}\exists\,\mathrm{Alg}\text{ with fixed query budget }T\\[2.0pt] \text{such that }\displaystyle\sup_{A\in\mathcal{A}_{d,\kappa}}\operatorname{TV}\bigl(\rho_{A}^{\mathrm{Alg}},\pi_{A}\bigr)\leq\varepsilon\end{array}\right\}.$ (2)

## EXCLUDED src:S4.p1

external_citation; raw bytes [197083,198758); SHA256 83dee67429c0e8d061cabb5df5175bf4498011bc82ff498ead2718f916de4197

Historical lower bound and forward reference to limitations, not a producer of the bounded tau/detector estimates.

The preprint [22] proved an $\Omega(\log d)$ query lower bound for centered Gaussian sampling with $I_{d}\preceq A\preceq 2I_{d}$ at total variation accuracy $\varepsilon=\frac{1}{10}$ . We subsequently examine the limitations of this analysis for establishing accuracy-dependent lower bounds in Section 4.4.

## EXCLUDED src:raw-byte-197205

external_citation; raw bytes [197205,197256); SHA256 0d5aff851532a095ebe94b13e5c14beef26645c502646be7f208106729a1e188

Historical lower bound and forward reference to limitations, not a producer of the bounded tau/detector estimates.

22

## NODE src:S4.Thmtheorem1

theorem_statement; raw bytes [198759,202512); SHA256 b5f1b62deae1f3fc852fe72ad6724650e78412fc9dd68be6faa49285ca9df6ff

Ambient Theorem 4.1 quantifier order and parameter range; this packet does not claim the complete lower bound.

Theorem 4.1 (Extension to general $\kappa$ ). For every fixed $\delta\in(0,1)$ , there exists $d_{0}(\delta)$ such that, for every integer $d\geq d_{0}(\delta)$ , $2\leq\kappa\leq d^{1-\delta}$ , and $0<\varepsilon\leq 1/10$ , $Q_{G}(d,\kappa,\varepsilon)\geq\frac{\delta}{256}\sqrt{\kappa}\log d.$

## NODE src:S4.Thmtheorem1.p1

theorem_statement; raw bytes [199359,202505); SHA256 2ae9bfa13b0062f1700cea020f9496c6cc9df1bb29fef3e90286fb0d05297bc5

Ambient Theorem 4.1 quantifier order and parameter range; this packet does not claim the complete lower bound.

For every fixed $\delta\in(0,1)$ , there exists $d_{0}(\delta)$ such that, for every integer $d\geq d_{0}(\delta)$ , $2\leq\kappa\leq d^{1-\delta}$ , and $0<\varepsilon\leq 1/10$ , $Q_{G}(d,\kappa,\varepsilon)\geq\frac{\delta}{256}\sqrt{\kappa}\log d.$

## NODE src:S4.Ex9

reused_display; raw bytes [201410,202498); SHA256 41aa130cf07235a4a09e67a60baf7254345de93ed25bf7bb469da10651584433

Ambient Theorem 4.1 quantifier order and parameter range; this packet does not claim the complete lower bound.

$Q_{G}(d,\kappa,\varepsilon)\geq\frac{\delta}{256}\sqrt{\kappa}\log d.$

## EXCLUDED src:S4.p2

proof_paragraph; raw bytes [202513,204397); SHA256 464fb51dbd8c0744078fae148ff7599c697aa22851a3113e9d8d4cfe497e9bdd

Comparison with Theorem 3.1 is not used in the bounded proof slice.

Compared with Theorem 3.1, this bound also covers $2\leq\kappa<4$ and $\frac{1}{16}<\varepsilon\leq\frac{1}{10}$ , and it holds even when the spectrum of $A$ is known to the algorithm. On the other hand, it does not grow as $\varepsilon\to 0$ and it requires $\kappa\leq d^{1-\delta}$ .

## NODE src:S4.SS1.p1

source_definition; raw bytes [204560,209900); SHA256 c8f6092fb5dc1a6d0871bc5a815650a5b859b6842c867faad054c12d619dfdcb

Hard-grid theta/lambda/Lambda, independent Haar rotation O, A, potential, and target.

We use a construction similar to that in [22, Section 9.2], with a cosine eigenvalue grid (Chebyshev nodes) and a random orthogonal rotation, while extending the spectral interval from $[1,2]$ to $[1,\kappa]$ . For $d\geq 2$ and $\kappa\geq 2$ , define $\theta_{i}=\frac{(i-\tfrac{1}{2})\pi}{d},\qquad\lambda_{i}=\frac{\kappa+1}{2}+\frac{\kappa-1}{2}\cos\theta_{i},\qquad\Lambda=\operatorname{diag}(\lambda_{1},\ldots,\lambda_{d}).$ (11) Draw $O\sim\operatorname{Haar}(\mathrm{O}(d))$ , independently of the algorithm’s private randomness, and set $A=O\Lambda O^{\top}$ . The associated potential and target are $f_{A}(x)=x^{\top}Ax/2$ and $\pi_{A}=N(0,A^{-1})$ .

## NODE src:raw-byte-204717

external_citation; raw bytes [204717,204768); SHA256 0d5aff851532a095ebe94b13e5c14beef26645c502646be7f208106729a1e188

Hard-grid theta/lambda/Lambda, independent Haar rotation O, A, potential, and target.

22

## NODE src:S4.E11

source_definition; raw bytes [205983,207807); SHA256 ce6e9c683b6bf400860cf79ef585e2a94972b3763274e12d0467460d933cc9ee

Hard-grid theta/lambda/Lambda, independent Haar rotation O, A, potential, and target.

$\theta_{i}=\frac{(i-\tfrac{1}{2})\pi}{d},\qquad\lambda_{i}=\frac{\kappa+1}{2}+\frac{\kappa-1}{2}\cos\theta_{i},\qquad\Lambda=\operatorname{diag}(\lambda_{1},\ldots,\lambda_{d}).$ (11)

## NODE src:S4.SS1.p2

source_definition; raw bytes [209901,210357); SHA256 9feb39b4eb5c7ce1475d76512680583cc47ac8d903dd76e4f2287eb779964a3a

Spectrum deterministic and available to algorithm; hidden random eigenbasis identifies input randomness.

The spectrum is deterministic and may be supplied to the algorithm. In particular, the Gaussian normalizing constant is known. The unknown component is the random eigenbasis represented by $O$ .

## EXCLUDED src:S4.Thmtheorem2

remark_statement; raw bytes [210358,217943); SHA256 531c0f26c543df8d7f5a4e5874d563f25f398d63191c788307aa86efd2c649b7

Remark 4.2 comparison and mechanism overview are not additional premises of the bounded estimates.

Remark 4.2 (Comparison with $\kappa=2$ case). At $\kappa=2$ , the spectrum in Eq. (11) recovers the original construction in [22]. More generally, if $A_{2}$ denotes the original precision matrix with the same rotation $O$ , then $A=(\kappa-1)A_{2}-(\kappa-2)I_{d}$ . Thus one matrix–vector reply for either matrix determines the corresponding reply for the other. The proof compares $\sum_{i}\cos(n\theta_{i})\langle x,Oe_{i}\rangle^{2}$ with $\|x\|^{2}$ , where $n=2q+1$ . For the output of a $q$ -query algorithm, the ratio is at most $d^{-\Omega(1)}$ in absolute value (Lemma 4.4), whereas under the target the ratio of the means has absolute value $e^{-\Theta(n/\sqrt{\kappa})}$ (Lemma 4.5). Hence the test works for $n$ up to order $\sqrt{\kappa}\log d$ , rather than $\log d$ as at $\kappa=2$ , which is the source of the factor $\sqrt{\kappa}$ in Theorem 4.1.

## EXCLUDED src:S4.Thmtheorem2.p1

remark_statement; raw bytes [210993,217936); SHA256 b2a8eec16aa9db80254659ef7c4735166d044f3e80b950f058b217f47189b4a3

Remark 4.2 comparison and mechanism overview are not additional premises of the bounded estimates.

At $\kappa=2$ , the spectrum in Eq. (11) recovers the original construction in [22]. More generally, if $A_{2}$ denotes the original precision matrix with the same rotation $O$ , then $A=(\kappa-1)A_{2}-(\kappa-2)I_{d}$ . Thus one matrix–vector reply for either matrix determines the corresponding reply for the other. The proof compares $\sum_{i}\cos(n\theta_{i})\langle x,Oe_{i}\rangle^{2}$ with $\|x\|^{2}$ , where $n=2q+1$ . For the output of a $q$ -query algorithm, the ratio is at most $d^{-\Omega(1)}$ in absolute value (Lemma 4.4), whereas under the target the ratio of the means has absolute value $e^{-\Theta(n/\sqrt{\kappa})}$ (Lemma 4.5). Hence the test works for $n$ up to order $\sqrt{\kappa}\log d$ , rather than $\log d$ as at $\kappa=2$ , which is the source of the factor $\sqrt{\kappa}$ in Theorem 4.1.

## EXCLUDED src:raw-byte-211688

external_citation; raw bytes [211688,211739); SHA256 0d5aff851532a095ebe94b13e5c14beef26645c502646be7f208106729a1e188

Remark 4.2 comparison and mechanism overview are not additional premises of the bounded estimates.

22

## EXCLUDED src:S4.SS2.p1

proof_paragraph; raw bytes [218131,220347); SHA256 fb357dd9c0c9e97c055101ab646223a06e8baee78fb7f6bf7b089dc3b398c12e

Roadmap to four lemmas, with no additional mathematical estimate.

This subsection states the four lemmas used in the proof of Theorem 4.1. Lemma 4.3 places the output of any $q$ -query algorithm in a block Krylov space generated by independent Gaussian vectors, Lemma 4.4 bounds a quadratic form with cosine weights uniformly over this space, Lemma 4.5 evaluates the same quadratic form under the target, and Lemma 4.6 verifies that the hard family is admissible. All proofs are deferred to Appendix C.

## NODE src:S4.SS2.SSS0.Px1.p1

external_citation; raw bytes [220486,220994); SHA256 c74996dec2835c66878b193d3686a3a3eef54575612fe7337b6f4e708a793046

Krylov argument attributed to [22, Lemma 9.2]; the external paper and Appendix C.1 proof are not opened.

We first control the information revealed by adaptive queries via a standard Krylov argument. The deferred-rotation argument of [22, Lemma 9.2] uses the rotational symmetry of the undisclosed eigenbasis to represent the algorithm’s output in a block Krylov space generated by independent Gaussian vectors.

## NODE src:raw-byte-220748

external_citation; raw bytes [220748,220799); SHA256 0d5aff851532a095ebe94b13e5c14beef26645c502646be7f208106729a1e188

Krylov argument attributed to [22, Lemma 9.2]; the external paper and Appendix C.1 proof are not opened.

22

## NODE src:S4.SS2.SSS0.Px1.p2

source_definition; raw bytes [220995,223561); SHA256 1af85b5a7ddf70728d8e165348d8ebc4d7aa5dead321f61eca77f9112baaaa6d

Literal block-Krylov span definition.

For vectors $g_{1},\ldots,g_{q+1}\in\mathbb{R}^{d}$ and $\Lambda=\operatorname{diag}(\lambda_{1},\ldots,\lambda_{d})$ , define $\mathcal{K}_{q}(g_{1},\ldots,g_{q+1})=\operatorname{span}\{\Lambda^{j}g_{a}:1\leq a\leq q+1,\ 0\leq j\leq q\}.$

## NODE src:S4.Ex10

source_definition; raw bytes [222173,223554); SHA256 46d0c8edd5baaaa1692636c4a64c4e6f7d0dd032773fdca2d8d5a1db86999814

Literal block-Krylov span definition.

$\mathcal{K}_{q}(g_{1},\ldots,g_{q+1})=\operatorname{span}\{\Lambda^{j}g_{a}:1\leq a\leq q+1,\ 0\leq j\leq q\}.$

## NODE src:S4.Thmtheorem3

lemma_statement; raw bytes [223562,226822); SHA256 aea49e67741ca12f83450077b07119978b6ac58d61960e8bddcf1ccf0c4a392f

Krylov representation, imported only as a source-named boundary; no extraction of its Appendix C.1 proof.

Lemma 4.3 (Krylov representation). Fix an integer $q\geq 0$ with $2q+1<d$ and let $X$ be the output. There exist independent vectors $g_{1},\ldots,g_{q+1}\sim N(0,I_{d})$ such that $O^{\top}X\in\mathcal{K}_{q}(g_{1},\ldots,g_{q+1})\qquad\text{almost surely}.$

## NODE src:S4.Thmtheorem3.p1

lemma_statement; raw bytes [223959,226815); SHA256 07dbf865228c9bd4aca76ae2b67273ca14c7c8c414a7a0713e8e54a33d166ac6

Krylov representation, imported only as a source-named boundary; no extraction of its Appendix C.1 proof.

Fix an integer $q\geq 0$ with $2q+1<d$ and let $X$ be the output. There exist independent vectors $g_{1},\ldots,g_{q+1}\sim N(0,I_{d})$ such that $O^{\top}X\in\mathcal{K}_{q}(g_{1},\ldots,g_{q+1})\qquad\text{almost surely}.$

## NODE src:S4.Ex11

reused_display; raw bytes [225573,226808); SHA256 eae0e68aeb8b063b359d6b179f9ecc85ab8a1295933f6aff9e6b2d43a0144ee5

Krylov representation, imported only as a source-named boundary; no extraction of its Appendix C.1 proof.

$O^{\top}X\in\mathcal{K}_{q}(g_{1},\ldots,g_{q+1})\qquad\text{almost surely}.$

## NODE src:S4.SS2.SSS0.Px1.p3

proof_paragraph; raw bytes [226823,229313); SHA256 dc087f31f8ad54bc41f66390055fe6e4de34f2756013ce51f4878d672ed038af

Extra output vector, adaptive polynomial coefficients, simultaneous-control requirement, and C.1 provenance.

The additional starting vector accounts for the output, which may lie outside the span of the query points and oracle replies. Equivalently, the lemma gives a representation $O^{\top}X=\sum_{a=1}^{q+1}p_{a}(\Lambda)g_{a}$ , where each $p_{a}$ has degree at most $q$ . The polynomial coefficients may depend on the entire extended experiment. We therefore control the output through an estimate that holds simultaneously for every vector in $\mathcal{K}_{q}$ . The proof of Lemma 4.3 is deferred to Appendix C.1.

## NODE src:S4.SS2.SSS0.Px2.p1

source_definition; raw bytes [229463,232225); SHA256 d88a7c167f41fe9222266d5c202aa1063306e5256ff13001cc69feacc253925d

n=2q+1 and cosine diagonal D_n; source explains high-frequency choice above degree-2q products.

We next control a high-frequency cosine statistic uniformly over the space in Lemma 4.3. For a query budget $q$ , set $n=2q+1,\qquad D_{n}=\operatorname{diag}\bigl(\cos(n\theta_{1}),\ldots,\cos(n\theta_{d})\bigr).$ The choice of $n$ places this statistic above all frequencies arising from products of two degree- $q$ cosine polynomials.

## NODE src:S4.Ex12

source_definition; raw bytes [230153,231671); SHA256 cbadcc8b91b46307fc20b4f8b9f88d71919327a5f53a3e9402c8b9afa4d7bd75

n=2q+1 and cosine diagonal D_n; source explains high-frequency choice above degree-2q products.

$n=2q+1,\qquad D_{n}=\operatorname{diag}\bigl(\cos(n\theta_{1}),\ldots,\cos(n\theta_{d})\bigr).$

## NODE src:S4.Thmtheorem4

lemma_statement; raw bytes [232226,238987); SHA256 de4bc9b7d7b5070b09a78b59e8aa752b9ac32f667e974fa910294824f08477d9

Absolute C>0, literal two-term tau, tau<=1/2 conditional, one probability event simultaneously for every Krylov vector.

Lemma 4.4 (Uniform bound on the Krylov space). There is an absolute constant $C>0$ such that the following holds. Let $q\geq 0$ satisfy $2q+1<d$ , let $g_{1},\ldots,g_{q+1}$ be independent $N(0,I_{d})$ vectors, and let $\mathcal{K}_{q}=\mathcal{K}_{q}(g_{1},\ldots,g_{q+1})$ . Define $\tau_{d,q}=C\left[(q+1)\sqrt{\frac{\log d}{d}}+\frac{(q+1)(q+1+\log d)\log d}{d}\right].$ If $\tau_{d,q}\leq 1/2$ , then, with probability at least $0.99$ , $|u^{\top}D_{n}u|\leq 2\tau_{d,q}\|u\|^{2}\qquad\text{for every }u\in\mathcal{K}_{q}.$

## NODE src:S4.Thmtheorem4.p1

lemma_statement; raw bytes [232635,238980); SHA256 00f66fac7ae3cca6c10e5cfeb93cf22f9622867593ccd7c9cbc09cde73fb9737

Absolute C>0, literal two-term tau, tau<=1/2 conditional, one probability event simultaneously for every Krylov vector.

There is an absolute constant $C>0$ such that the following holds. Let $q\geq 0$ satisfy $2q+1<d$ , let $g_{1},\ldots,g_{q+1}$ be independent $N(0,I_{d})$ vectors, and let $\mathcal{K}_{q}=\mathcal{K}_{q}(g_{1},\ldots,g_{q+1})$ . Define $\tau_{d,q}=C\left[(q+1)\sqrt{\frac{\log d}{d}}+\frac{(q+1)(q+1+\log d)\log d}{d}\right].$ If $\tau_{d,q}\leq 1/2$ , then, with probability at least $0.99$ , $|u^{\top}D_{n}u|\leq 2\tau_{d,q}\|u\|^{2}\qquad\text{for every }u\in\mathcal{K}_{q}.$

## NODE src:S4.Ex13

source_definition; raw bytes [235190,236791); SHA256 c5b3e4a8e58565322f59766ab9ce3a8d403cccb29066bc766b37f2181e5b9e56

Absolute C>0, literal two-term tau, tau<=1/2 conditional, one probability event simultaneously for every Krylov vector.

$\tau_{d,q}=C\left[(q+1)\sqrt{\frac{\log d}{d}}+\frac{(q+1)(q+1+\log d)\log d}{d}\right].$

## NODE src:S4.Ex14

reused_display; raw bytes [237500,238973); SHA256 e62d51e129adc8a0eefa1d7c40135bb94969bb84f17ef62d756432ad51b6819e

Absolute C>0, literal two-term tau, tau<=1/2 conditional, one probability event simultaneously for every Krylov vector.

$|u^{\top}D_{n}u|\leq 2\tau_{d,q}\|u\|^{2}\qquad\text{for every }u\in\mathcal{K}_{q}.$

## NODE src:S4.SS2.SSS0.Px2.p2

proof_paragraph; raw bytes [238988,241827); SHA256 28456b4e949b9583e7e4fd05575a42005531e26a238f9cbe7db31ba739c47e6f

C.2 provenance; affine spectral change of basis; kappa-independent uniform estimate.

The proof is deferred to Appendix C.2. Since $\lambda_{i}$ is a nonconstant affine function of $\cos\theta_{i}$ , the space $\mathcal{K}_{q}$ is equivalently spanned by the vectors $\bigl((g_{a})_{i}\cos(j\theta_{i})\bigr)_{i=1}^{d}$ , with $a\leq q+1$ and $j\leq q$ . Consequently, the estimate is independent of $\kappa$ .

## NODE src:S4.SS2.SSS0.Px2.p3

unnamed_estimate; raw bytes [241828,243948); SHA256 c792dce2ab5fcb473f99facdc43dd3359a4cc689bde11fd383746a56d8b789fd

Algorithm-output quadratic bound consumes representation and the uniform event.

On the event in Lemma 4.4, the output representation in Lemma 4.3 therefore gives $\bigl|X^{\top}OD_{n}O^{\top}X\bigr|\leq 2\tau_{d,q}\|X\|^{2}.$

## NODE src:S4.Ex15

reused_display; raw bytes [242596,243941); SHA256 157737dcd2bc4dcd361201ed42a53a36ed7536854618cf21f81d4c7cc9d66f02

Algorithm-output quadratic bound consumes representation and the uniform event.

$\bigl|X^{\top}OD_{n}O^{\top}X\bigr|\leq 2\tau_{d,q}\|X\|^{2}.$

## EXCLUDED src:S4.SS2.SSS0.Px3.p1

proof_paragraph; raw bytes [244077,244246); SHA256 8d548684ae61fda062d9d3589795e68bedef95570c62e75ef0b1955185e15211

Transition sentence introducing target moments.

We now evaluate the same cosine statistic under the target Gaussian.

## NODE src:S4.Thmtheorem5

lemma_statement; raw bytes [244247,253907); SHA256 602e32bda516ddd90a7fbdcc9aa784029f3d402a5d7273c4f57eb84f61717aee

Target law, rho_kappa, n range, M/mu_n, exact means, and both variance bounds.

Lemma 4.5 (Moments under the target). Let $\kappa\geq 2$ , $U\sim N(0,\Lambda^{-1})$ , and $\varrho_{\kappa}=\tfrac{\sqrt{\kappa}-1}{\sqrt{\kappa}+1}$ . For an integer $1\leq n<d$ , put $D_{n}=\operatorname{diag}(\cos(n\theta_{i}))$ , $M=\mathbb{E}\|U\|^{2}$ , and $\mu_{n}=\mathbb{E}[U^{\top}D_{n}U]$ . Then $\displaystyle M$ $\displaystyle=\frac{d}{\sqrt{\kappa}}\frac{1-\varrho_{\kappa}^{2d}}{1+\varrho_{\kappa}^{2d}},\quad\mbox{and }(-1)^{n}\mu_{n}=\frac{d}{\sqrt{\kappa}}\frac{\varrho_{\kappa}^{n}-\varrho_{\kappa}^{2d-n}}{1+\varrho_{\kappa}^{2d}}.$ Moreover, both $\operatorname{Var}(\|U\|^{2})$ and $\operatorname{Var}(U^{\top}D_{n}U)$ are at most $2M\leq 2d/\sqrt{\kappa}$ . If $d-n\geq\sqrt{\kappa}$ , then $(1-e^{-4})e^{-3n/\sqrt{\kappa}}\leq\frac{|\mu_{n}|}{M}\leq e^{-2n/\sqrt{\kappa}}.$

## NODE src:S4.Thmtheorem5.p1

lemma_statement; raw bytes [244647,252223); SHA256 eb2ac07c1365200feaa14c2d628a3b8e61fbb42475f465320b6e5f0d9ce5f7fb

Target law, rho_kappa, n range, M/mu_n, exact means, and both variance bounds.

Let $\kappa\geq 2$ , $U\sim N(0,\Lambda^{-1})$ , and $\varrho_{\kappa}=\tfrac{\sqrt{\kappa}-1}{\sqrt{\kappa}+1}$ . For an integer $1\leq n<d$ , put $D_{n}=\operatorname{diag}(\cos(n\theta_{i}))$ , $M=\mathbb{E}\|U\|^{2}$ , and $\mu_{n}=\mathbb{E}[U^{\top}D_{n}U]$ . Then $\displaystyle M$ $\displaystyle=\frac{d}{\sqrt{\kappa}}\frac{1-\varrho_{\kappa}^{2d}}{1+\varrho_{\kappa}^{2d}},\quad\mbox{and }(-1)^{n}\mu_{n}=\frac{d}{\sqrt{\kappa}}\frac{\varrho_{\kappa}^{n}-\varrho_{\kappa}^{2d-n}}{1+\varrho_{\kappa}^{2d}}.$ Moreover, both $\operatorname{Var}(\|U\|^{2})$ and $\operatorname{Var}(U^{\top}D_{n}U)$ are at most $2M\leq 2d/\sqrt{\kappa}$ .

## NODE src:S4.EGx1

reused_display; raw bytes [247955,250657); SHA256 f3c1a7e10fc428607da9568bcfa38ba01165b02f11f2821a9df4f2fc9830dddf

Target law, rho_kappa, n range, M/mu_n, exact means, and both variance bounds.

$\displaystyle M$ $\displaystyle=\frac{d}{\sqrt{\kappa}}\frac{1-\varrho_{\kappa}^{2d}}{1+\varrho_{\kappa}^{2d}},\quad\mbox{and }(-1)^{n}\mu_{n}=\frac{d}{\sqrt{\kappa}}\frac{\varrho_{\kappa}^{n}-\varrho_{\kappa}^{2d-n}}{1+\varrho_{\kappa}^{2d}}.$

## NODE src:S4.Thmtheorem5.p2

lemma_statement; raw bytes [252224,253900); SHA256 f8c0ae405cc94e39ef601d241fb45b9a2a0fd6ccc6a5a984bec7c57e3c804a29

Extra condition d-n>=sqrt(kappa) for the normalized target-bias bounds.

If $d-n\geq\sqrt{\kappa}$ , then $(1-e^{-4})e^{-3n/\sqrt{\kappa}}\leq\frac{|\mu_{n}|}{M}\leq e^{-2n/\sqrt{\kappa}}.$

## NODE src:S4.Ex17

reused_display; raw bytes [252714,253893); SHA256 bb9911e22ca8eb8a907e3c01c463d14bcf794ec556a92ce4900b4e17903a9bc7

Extra condition d-n>=sqrt(kappa) for the normalized target-bias bounds.

$(1-e^{-4})e^{-3n/\sqrt{\kappa}}\leq\frac{|\mu_{n}|}{M}\leq e^{-2n/\sqrt{\kappa}}.$

## NODE src:S4.SS2.SSS0.Px3.p2

proof_paragraph; raw bytes [253908,257439); SHA256 6e87e3be540a6117db3aad072b10fb6a183446cbdacbf506c9222bf268f168b4

C.3 provenance and rotation of target sample to diagonal coordinates, preserving norm and cosine quadratic form.

The proof is deferred to Appendix C.3. For an exact sample $Y\mid O\sim\pi_{A}$ , the vector $U=O^{\top}Y$ has law $N(0,\Lambda^{-1})$ , with $\|Y\|^{2}=\|U\|^{2}$ and $Y^{\top}OD_{n}O^{\top}Y=U^{\top}D_{n}U$ . The lemma therefore gives the means and variances of $\|Y\|^{2}$ and $Y^{\top}OD_{n}O^{\top}Y$ under the target.

## EXCLUDED src:S4.SS2.SSS0.Px4.p1

proof_paragraph; raw bytes [257590,257982); SHA256 35bd3c76a4c0985a6c1f749c6922269ecc324db406f03ce179f9a464233de06f

Admissibility proof referral to C.4 is outside this selected proof slice.

We finally verify that the hard family belongs to the prescribed class. The proof is deferred to Appendix C.4.

## NODE src:S4.Thmtheorem6

lemma_statement; raw bytes [257983,259803); SHA256 dac27bc94144d3bc1b83db6b8653450babb7d8ed2e39c3134d9f1bb4d2eece77

Admissibility is a named surrounding input for the algorithm experiment only; Appendix C.4 is not extracted.

Lemma 4.6 (Admissibility). For every $O\in\mathrm{O}(d)$ , the matrix $A=O\Lambda O^{\top}$ satisfies $I_{d}\preceq A\preceq\kappa I_{d}$ .

## NODE src:S4.Thmtheorem6.p1

lemma_statement; raw bytes [258372,259796); SHA256 96f1b9bb346624e5159a55dd51a6e8624561b24b223959df8ac9c2046f9e8160

Admissibility is a named surrounding input for the algorithm experiment only; Appendix C.4 is not extracted.

For every $O\in\mathrm{O}(d)$ , the matrix $A=O\Lambda O^{\top}$ satisfies $I_{d}\preceq A\preceq\kappa I_{d}$ .

## EXCLUDED src:S4.SS3.p1

proof_paragraph; raw bytes [260210,260390); SHA256 4c546c6fb022b9e8333be6e178d23b375307ea3a2659b093276aec2912902ba2

Roadmap sentence for comparing two probabilities.

We compare the probabilities of a single test event under algorithmic outputs and target samples.

## NODE src:S4.SS3.p2

standing_assumptions; raw bytes [260737,263598); SHA256 97dcab59badd84d9a256adc8a3c562b2394db2849bccc629bfef646a78d1da5c

Fix delta, kappa and epsilon; budget q bound; per-input TV guarantee; source invokes admissibility.

Fix $\delta\in(0,1)$ , $2\leq\kappa\leq d^{1-\delta}$ , and $0<\varepsilon\leq 1/10$ . Suppose that an algorithm uses at most $q\leq(\delta/256)\sqrt{\kappa}\log d$ queries and satisfies $\operatorname{TV}(\rho_{A}^{\mathrm{Alg}},\pi_{A})\leq\varepsilon$ for every admissible $A$ . Lemma 4.6 makes the hard family admissible.

## NODE src:S4.SS3.p3

source_definition; raw bytes [263599,268951); SHA256 ad29c8dbf29d5a26cd8cee201daeb53a4e004e6a2b637262a998a602b5e33bdd

Set n and tau; literal shifted polynomial detector S_A and strict test event E_A.

Set $n=2q+1$ and $\tau=\tau_{d,q}$ . Define statistic $S_{A}$ and the associated test event $E_{A}$ as $\displaystyle S_{A}(x)$ $\displaystyle:=(-1)^{n}x^{\top}T_{n}\!\left(\frac{2A-(\kappa+1)I_{d}}{\kappa-1}\right)x-2\tau\|x\|^{2},$ $\displaystyle E_{A}$ $\displaystyle:=\{x:S_{A}(x)>0\},$ where $T_{n}$ is the degree- $n$ Chebyshev polynomial of the first kind.

## NODE src:S4.EGx2

source_definition; raw bytes [264837,268398); SHA256 b164b398254da86f95de0b2c87ab8de803fd2eb2900764b3e1d530b4f4cbc50b

Set n and tau; literal shifted polynomial detector S_A and strict test event E_A.

$\displaystyle S_{A}(x)$ $\displaystyle:=(-1)^{n}x^{\top}T_{n}\!\left(\frac{2A-(\kappa+1)I_{d}}{\kappa-1}\right)x-2\tau\|x\|^{2},$ $\displaystyle E_{A}$ $\displaystyle:=\{x:S_{A}(x)>0\},$

## NODE src:S4.SS3.p4

proof_paragraph; raw bytes [268952,274531); SHA256 57fd7c0841c278687484b43de5592e474fe0a8b75ef6f1c1178c42583b316d41

For nonzero x only, normalized spectral weights and Chebyshev identity explain the signed detector threshold.

Geometrically, for $x\neq 0$ , the weights $w_{i}(x)=|\langle x,Oe_{i}\rangle|^{2}/\|x\|^{2}$ describe the fractions of its energy $\|x\|^{2}$ carried by the eigenvectors $Oe_{i}$ of $A$ . Using $T_{n}(\cos\theta_{i})=\cos(n\theta_{i})$ , the event $x\in E_{A}$ is equivalent to $(-1)^{n}\sum_{i}w_{i}(x)\cos(n\theta_{i})>2\tau$ . So $E_{A}$ is the event that the cosine coefficient $\sum_{i}w_{i}(x)\cos(n\theta_{i})$ of these weights at frequency $n$ exceeds $2\tau$ in absolute value and has the sign that it has under the target.

## NODE src:S4.SS3.SSS0.Px1.p1

unnamed_estimate; raw bytes [274682,284308); SHA256 503b884db81a73294471d52068955ba42f5eb314391e60ee56dfe0c02b092999

q+1 bound, n=o(d), two-term tau substitution, uniform eventual n<d/tau<=1/2, extended experiment, 0.99 event and averaged 0.01 pass bound.

The bound on $q$ gives $q+1\leq d^{(1-\delta)/2}\log d$ , so $n=o(d)$ . Substituting this bound into the definition of $\tau$ yields $\tau\lesssim d^{-\delta/2}(\log d)^{3/2}+d^{-\delta}(\log d)^{3}\lesssim d^{-\delta/2}(\log d)^{3}\longrightarrow 0$ Thus $n<d$ and $\tau\leq 1/2$ for sufficiently large $d$ depending only on $\delta$ , and the Lemma 4.3 and Lemma 4.4 apply. Let $X$ be the algorithmic output on the random input $A=O\Lambda O^{\top}$ . Lemma 4.3 places $O^{\top}X$ in $\mathcal{K}_{q}$ on an extension preserving the joint law of $(O,X)$ . Lemma 4.4 then gives $|X^{\top}OD_{n}O^{\top}X|\leq 2\tau\|X\|^{2}$ with probability at least $0.99$ . On this event, $S_{A}(X)\leq 0$ . Consequently, $\mathbb{E}_{A}[\rho_{A}^{\mathrm{Alg}}(E_{A})]\leq 0.01.$

## NODE src:S4.Ex20

reused_display; raw bytes [276182,277571); SHA256 548248ba49604acd34c1bcdcb5e40a9526ca9b107ab049f5ab1c33145c5223f9

q+1 bound, n=o(d), two-term tau substitution, uniform eventual n<d/tau<=1/2, extended experiment, 0.99 event and averaged 0.01 pass bound.

$\tau\lesssim d^{-\delta/2}(\log d)^{3/2}+d^{-\delta}(\log d)^{3}\lesssim d^{-\delta/2}(\log d)^{3}\longrightarrow 0$

## NODE src:S4.Ex21

reused_display; raw bytes [281428,282577); SHA256 5c3411723598918fc03beaf09a1a0c63874fd740ae99303e64200215dab24449

q+1 bound, n=o(d), two-term tau substitution, uniform eventual n<d/tau<=1/2, extended experiment, 0.99 event and averaged 0.01 pass bound.

$|X^{\top}OD_{n}O^{\top}X|\leq 2\tau\|X\|^{2}$

## NODE src:S4.Ex22

reused_display; raw bytes [283291,284301); SHA256 f39f057b5e9ec74fbe1611e0e07e38e25b425ff21be4008bdb7079ef3ddba4c2

q+1 bound, n=o(d), two-term tau substitution, uniform eventual n<d/tau<=1/2, extended experiment, 0.99 event and averaged 0.01 pass bound.

$\mathbb{E}_{A}[\rho_{A}^{\mathrm{Alg}}(E_{A})]\leq 0.01.$

## NODE src:S4.SS3.SSS0.Px2.p1

source_definition; raw bytes [284461,286135); SHA256 2ba91c6efe4be035f425f60295d2221e32f28af4c44577976a1b5cf359c0a4bc

M=trace(Lambda^-1), mu_n=trace(D_n Lambda^-1), beta=|mu_n|/M.

Let $M=\operatorname{tr}(\Lambda^{-1})$ denote the target mean squared norm, and let $\mu_{n}=\operatorname{tr}(D_{n}\Lambda^{-1})$ denote the target mean of the cosine statistic. Write $\beta=|\mu_{n}|/M$ for the normalized target bias.

## NODE src:S4.SS3.SSS0.Px2.p2

unnamed_estimate; raw bytes [286136,295412); SHA256 57cc3bfdcce5aeb6daf3de24978f9efe6f6fd650fe3af962997f7b9f00dcf5bc

Uniform gap condition, beta lower bound, fixed b, rho tail and M lower bound, tau/beta->0 and M beta^2->infinity, then d0(delta) with tau<=beta/4 and M beta^2>=320.

Since $n=o(d)$ and $\sqrt{\kappa}\leq d^{(1-\delta)/2}=o(d)$ , we have $d-n\geq\sqrt{\kappa}$ for sufficiently large $d$ . Lemma 4.5 and the the bound on $q$ therefore give $\beta\geq(1-e^{-4})e^{-3n/\sqrt{\kappa}}\geq b\,d^{-\delta/4},\qquad b=(1-e^{-4})e^{-3},$ where we used $3n/\sqrt{\kappa}\leq 3+(3\delta/128)\log d$ . Moreover, $\varrho_{\kappa}\leq e^{-1/\sqrt{\kappa}}$ and $d\geq\sqrt{\kappa}$ imply $\varrho_{\kappa}^{2d}\leq e^{-2}<1/3$ . The formula for $M$ in the same lemma yields $M\geq d/(2\sqrt{\kappa})\geq d^{(1+\delta)/2}/2$ . Together with the bound on $\tau$ above, these estimates imply $\frac{\tau}{\beta}\leq\frac{C^{\prime}}{b}d^{-\delta/4}(\log d)^{3}\longrightarrow 0,\qquad M\beta^{2}\geq\frac{b^{2}}{2}\sqrt{d}\longrightarrow\infty.$ All estimates are uniform over the stated parameter range. We may therefore choose $d_{0}(\delta)$ so that the conditions for the algorithmic bound above hold and, additionally, $\tau\leq\beta/4$ and $M\beta^{2}\geq 320$ .

## NODE src:S4.Ex23

reused_display; raw bytes [288233,289535); SHA256 dce85527ec2239579d8cc71900bcbafc7d29986ca68d32e4728d2981956b92fb

Uniform gap condition, beta lower bound, fixed b, rho tail and M lower bound, tau/beta->0 and M beta^2->infinity, then d0(delta) with tau<=beta/4 and M beta^2>=320.

$\beta\geq(1-e^{-4})e^{-3n/\sqrt{\kappa}}\geq b\,d^{-\delta/4},\qquad b=(1-e^{-4})e^{-3},$

## NODE src:S4.Ex24

reused_display; raw bytes [292798,294179); SHA256 398659b5c6092eadc286954963c70a21c5a633bf56223c29740962d935e25833

Uniform gap condition, beta lower bound, fixed b, rho tail and M lower bound, tau/beta->0 and M beta^2->infinity, then d0(delta) with tau<=beta/4 and M beta^2>=320.

$\frac{\tau}{\beta}\leq\frac{C^{\prime}}{b}d^{-\delta/4}(\log d)^{3}\longrightarrow 0,\qquad M\beta^{2}\geq\frac{b^{2}}{2}\sqrt{d}\longrightarrow\infty.$

## NODE src:S4.SS3.SSS0.Px2.p3

unnamed_estimate; raw bytes [295413,302179); SHA256 a2e7438c0a71ecee45c9fc818f8a1969703bef3c9b09ccb84ad84b8d3dd837b1

For each fixed A, shifted mean, centered-L2 variance estimate, and Chebyshev lower bound P(Z>0)>=0.9.

Now fix $A$ , draw $Y\sim\pi_{A}$ , and set $Z=S_{A}(Y)$ . Lemma 4.5 gives mean $(-1)^{n}\mu_{n}=\beta M$ for the signed cosine quadratic form and mean $M$ for $\|Y\|^{2}$ . Both variances are at most $2M$ . Hence, using the $L^{2}$ triangle inequality for centered variables, $\mathbb{E}Z=(\beta-2\tau)M\geq\frac{\beta M}{2},\qquad\operatorname{Var}(Z)\leq\bigl(\sqrt{2M}+2\tau\sqrt{2M}\bigr)^{2}\leq 8M.$ Chebyshev’s inequality gives, for every $A$ in the hard family, $\pi_{A}(E_{A})=\mathbb{P}(Z>0)\geq 1-\frac{\operatorname{Var}(Z)}{(\mathbb{E}Z)^{2}}\geq 1-\frac{32}{M\beta^{2}}\geq 0.9.$

## NODE src:S4.Ex25

reused_display; raw bytes [298334,300228); SHA256 15a4f4d7f9086a59cad497fcd87e47d377cb156537b82450ace28c1fcfd1dbda

For each fixed A, shifted mean, centered-L2 variance estimate, and Chebyshev lower bound P(Z>0)>=0.9.

$\mathbb{E}Z=(\beta-2\tau)M\geq\frac{\beta M}{2},\qquad\operatorname{Var}(Z)\leq\bigl(\sqrt{2M}+2\tau\sqrt{2M}\bigr)^{2}\leq 8M.$

## NODE src:S4.Ex26

reused_display; raw bytes [300531,302172); SHA256 8962bde118ad078290c36e2a7cb4795685bd66007629348933ba96973d9277bf

For each fixed A, shifted mean, centered-L2 variance estimate, and Chebyshev lower bound P(Z>0)>=0.9.

$\pi_{A}(E_{A})=\mathbb{P}(Z>0)\geq 1-\frac{\operatorname{Var}(Z)}{(\mathbb{E}Z)^{2}}\geq 1-\frac{32}{M\beta^{2}}\geq 0.9.$

## EXCLUDED src:S4.SS3.SSS0.Px3.p1

proof_paragraph; raw bytes [302307,304666); SHA256 bd1450769cba109f7dec070d45e0e6ebfd0be93ba82adadafa2e5c9d80f5115b

Final TV averaging contradiction is beyond the selected bounded endpoint; retained verbatim as an explicit exclusion.

Finally, the per-input TV guarantee implies $\pi_{A}(E_{A})-\rho_{A}^{\mathrm{Alg}}(E_{A})\leq\varepsilon$ . Averaging over the random input and using the two probability bounds gives $0.89\leq\mathbb{E}_{A}\!\left[\pi_{A}(E_{A})-\rho_{A}^{\mathrm{Alg}}(E_{A})\right]\leq\varepsilon\leq 0.1,$ a contradiction. ∎

## EXCLUDED src:S4.Ex27

reused_display; raw bytes [303271,304591); SHA256 1215118931d4d083523d625153c12f46bf4165ffa16525f1ee83e6334ca830e5

Final TV averaging contradiction is beyond the selected bounded endpoint; retained verbatim as an explicit exclusion.

$0.89\leq\mathbb{E}_{A}\!\left[\pi_{A}(E_{A})-\rho_{A}^{\mathrm{Alg}}(E_{A})\right]\leq\varepsilon\leq 0.1,$

## NODE src:bib.bib3

external_citation; raw bytes [352797,355519); SHA256 bf583f0ff8604e99bc1930e7de08205b90fe7c8c0f94a8c3e98258fe9dbe2133

Bibliographic identity only; no external theorem or proof is admitted from this item.

[22] OpenAI (2026) Subpolynomial query complexity for well-conditioned log-concave sampling. Note: OpenAI Math Release preprint OAI:Subpolynomial-query-complexity-for-well-conditioned-log-concave-sampling-September-26-2026 Cited by: §1.1, Table 1, Table 1, Remark 1.3, §1, §4.1, §4.2, Remark 4.2, §4.

## NODE src:A3.SS2.p1

source_definition; raw bytes [739163,743698); SHA256 4b07cd73f4561d56956c212747af710882b47f8d70253b679ed93e1cda9eafbc

r, n, normalized cosine row t_i, Gaussian row gamma_i, and row definition/dimensions of B.

Set $r=q+1$ and $n=2q+1$ . For $1\leq i\leq d$ , define $t_{i}=(1,\sqrt{2}\cos\theta_{i},\ldots,\sqrt{2}\cos(q\theta_{i}))^{\top},\qquad\gamma_{i}=((g_{1})_{i},\ldots,(g_{r})_{i})^{\top}.$ The vectors $\gamma_{1},\ldots,\gamma_{d}$ are independent $N(0,I_{r})$ . Let $B\in\mathbb{R}^{d\times r^{2}}$ have $i$ th row $d^{-1/2}(\gamma_{i}\otimes t_{i})^{\top}$ .

## NODE src:A3.Ex85

source_definition; raw bytes [740104,741765); SHA256 fc46424d064a72e91ad1a57987e6371dcddb652d50913b4c95b6cb929646caeb

r, n, normalized cosine row t_i, Gaussian row gamma_i, and row definition/dimensions of B.

$t_{i}=(1,\sqrt{2}\cos\theta_{i},\ldots,\sqrt{2}\cos(q\theta_{i}))^{\top},\qquad\gamma_{i}=((g_{1})_{i},\ldots,(g_{r})_{i})^{\top}.$

## EXCLUDED src:A3.SS2.p2

proof_paragraph; raw bytes [743699,746808); SHA256 9461bcbc2a2d0707345397a35b4b36b818bad89deadf2fd7f974a5ff101ccd5d

Strategy roadmap repeats the two matrix controls and upcoming concentration.

Our strategy is to write $u=Bc$ and control $\|u\|^{2}$ through $B^{\top}B$ , and $u^{\top}D_{n}u$ through $B^{\top}D_{n}B$ . The following fact verifies that the columns of $B$ span $\mathcal{K}_{q}$ and shows that these two matrices have expectations $I_{r^{2}}$ and $0$ , respectively. We will then prove concentration around these expectations to obtain a uniform bound on $\mathcal{K}_{q}$ .

## NODE src:A3.Thmtheorem5

fact_statement; raw bytes [746809,751148); SHA256 594da771a3b0a9077a24d6d235c11fc6634678161134e92a2b363c16a26c2626

Fact C.5: range, expected Gram matrices, deterministic cosine moments and row norm bound.

Fact C.5 (Cosine basis and moment identities). The matrix $B$ satisfies $\operatorname{range}(B)=\mathcal{K}_{q},\qquad\mathbb{E}[B^{\top}B]=I_{r^{2}},\qquad\mathbb{E}[B^{\top}D_{n}B]=0.$ Moreover, $\|t_{i}\|^{2}\leq 2r,\qquad\sum_{i}t_{i}t_{i}^{\top}=dI_{r},\qquad\sum_{i}\cos(n\theta_{i})t_{i}t_{i}^{\top}=0.$

## NODE src:A3.Thmtheorem5.p1

fact_statement; raw bytes [747217,751141); SHA256 8c5c51b54f540b686b80c1f8c7622b23d678e88c0bfe4c5391bad43599b5e199

Fact C.5: range, expected Gram matrices, deterministic cosine moments and row norm bound.

The matrix $B$ satisfies $\operatorname{range}(B)=\mathcal{K}_{q},\qquad\mathbb{E}[B^{\top}B]=I_{r^{2}},\qquad\mathbb{E}[B^{\top}D_{n}B]=0.$ Moreover, $\|t_{i}\|^{2}\leq 2r,\qquad\sum_{i}t_{i}t_{i}^{\top}=dI_{r},\qquad\sum_{i}\cos(n\theta_{i})t_{i}t_{i}^{\top}=0.$

## NODE src:A3.Ex86

reused_display; raw bytes [747595,749184); SHA256 41b8c2aa4b89e57e8a40fdfe74a1993cd8728f500dda26780670feb372b39fac

Fact C.5: range, expected Gram matrices, deterministic cosine moments and row norm bound.

$\operatorname{range}(B)=\mathcal{K}_{q},\qquad\mathbb{E}[B^{\top}B]=I_{r^{2}},\qquad\mathbb{E}[B^{\top}D_{n}B]=0.$

## NODE src:A3.Ex87

reused_display; raw bytes [749314,751134); SHA256 2fd35e00f5977b004c068684a5c80628f897e8a8e58990f3ae0f887db251409b

Fact C.5: range, expected Gram matrices, deterministic cosine moments and row norm bound.

$\|t_{i}\|^{2}\leq 2r,\qquad\sum_{i}t_{i}t_{i}^{\top}=dI_{r},\qquad\sum_{i}\cos(n\theta_{i})t_{i}t_{i}^{\top}=0.$

## NODE src:A3.SS2.p3

proof_paragraph; raw bytes [751263,756054); SHA256 70a50b8444b84fbd1c589f08cfc7406de60df80ef880fbbaf0be8043a31b0d77

Triangular invertible polynomial/cosine change of basis proves range(B)=K_q.

$\boxed{\operatorname{range}(B)=\mathcal{K}_{q}}$ . Since $\lambda_{i}=(\kappa+1)/2+(\kappa-1)\cos\theta_{i}/2$ , the identity $\cos(j\theta)=T_{j}(\cos\theta)$ expresses $\cos(j\theta_{i})$ as a degree- $j$ polynomial in $\lambda_{i}$ with nonzero leading coefficient. For each $a$ , the change of basis between $\bigl((g_{a})_{i}\cos(j\theta_{i})\bigr)_{i=1}^{d}$ and $\Lambda^{j}g_{a}$ , $0\leq j\leq q$ , is therefore triangular and invertible. The nonzero column normalizations in $B$ do not change its range, proving the first identity.

## NODE src:A3.SS2.p4

proof_paragraph; raw bytes [756055,762830); SHA256 93774182e96d807e98bd2511b36f4bd2657e423327848a65a28c0afff0c4aff0

Telescoping sine identity and nonzero sine denominator give cosine-grid cancellation for 0<|k|<2d.

$\boxed{\mathbb{E}[B^{\top}B]=I_{r^{2}}}$ . Recall that $\theta_{i}=(i-\tfrac{1}{2})\pi/d$ . For every integer $k$ with $0<|k|<2d$ , $\displaystyle 2\sin\!\left(\frac{k\pi}{2d}\right)\sum_{i=1}^{d}\cos(k\theta_{i})$ $\displaystyle=\sum_{i=1}^{d}\left[\sin\!\left(\frac{ki\pi}{d}\right)-\sin\!\left(\frac{k(i-1)\pi}{d}\right)\right]$ $\displaystyle=\sin(k\pi)-\sin(0)=0.$ Since $\sin(k\pi/(2d))\neq 0$ , this gives $\sum_{i}\cos(k\theta_{i})=0$ .

## NODE src:A3.EGx5

reused_display; raw bytes [757854,761674); SHA256 edb7ebc36d246729fd38de31c6b652f5c4f8529afda05562c652026f9ff56269

Telescoping sine identity and nonzero sine denominator give cosine-grid cancellation for 0<|k|<2d.

$\displaystyle 2\sin\!\left(\frac{k\pi}{2d}\right)\sum_{i=1}^{d}\cos(k\theta_{i})$ $\displaystyle=\sum_{i=1}^{d}\left[\sin\!\left(\frac{ki\pi}{d}\right)-\sin\!\left(\frac{k(i-1)\pi}{d}\right)\right]$ $\displaystyle=\sin(k\pi)-\sin(0)=0.$

## NODE src:A3.SS2.p5

proof_paragraph; raw bytes [762831,772440); SHA256 cdef6b30e730a2eb26002f44938ab8860bfe0a537b7fb65e11148f4e1539e199

Constant and nonconstant coordinate cases plus product-to-sum give sum t_i t_i^T=d I_r.

Index the coordinates of $t_{i}$ by $0,\ldots,q$ . The entries involving the constant coordinate satisfy $\sum_{i}(t_{i})_{0}^{2}=d,\qquad\sum_{i}(t_{i})_{0}(t_{i})_{j}=\sqrt{2}\sum_{i}\cos(j\theta_{i})=0\quad(1\leq j\leq q).$ For $1\leq j,k\leq q$ , the product-to-sum identity gives $\displaystyle\sum_{i}(t_{i})_{j}(t_{i})_{k}$ $\displaystyle=2\sum_{i}\cos(j\theta_{i})\cos(k\theta_{i})$ $\displaystyle=\sum_{i}\cos((j-k)\theta_{i})+\sum_{i}\cos((j+k)\theta_{i})$ $\displaystyle=\begin{cases}d,&j=k,\\ 0,&j\neq k.\end{cases}$ Indeed, $0<j+k\leq 2q<2d$ , while $j-k=0$ exactly when $j=k$ ; otherwise $0<|j-k|<2d$ . By symmetry, these calculations cover all matrix entries, and hence $\sum_{i}t_{i}t_{i}^{\top}=dI_{r}$ .

## NODE src:A3.Ex90

reused_display; raw bytes [763532,765222); SHA256 a1f78fb5b6767652a11599c2c21ca4397d7f39ffbb825bdb59dd5d4bd58da8ad

Constant and nonconstant coordinate cases plus product-to-sum give sum t_i t_i^T=d I_r.

$\sum_{i}(t_{i})_{0}^{2}=d,\qquad\sum_{i}(t_{i})_{0}(t_{i})_{j}=\sqrt{2}\sum_{i}\cos(j\theta_{i})=0\quad(1\leq j\leq q).$

## NODE src:A3.EGx6

reused_display; raw bytes [765664,770324); SHA256 4eaabe2dd22f90c125a5e4a3b33e0bc919034ff054f76aaec7c61fd3dbd6bd14

Constant and nonconstant coordinate cases plus product-to-sum give sum t_i t_i^T=d I_r.

$\displaystyle\sum_{i}(t_{i})_{j}(t_{i})_{k}$ $\displaystyle=2\sum_{i}\cos(j\theta_{i})\cos(k\theta_{i})$ $\displaystyle=\sum_{i}\cos((j-k)\theta_{i})+\sum_{i}\cos((j+k)\theta_{i})$ $\displaystyle=\begin{cases}d,&j=k,\\ 0,&j\neq k.\end{cases}$

## NODE src:A3.SS2.p6

proof_paragraph; raw bytes [772441,776661); SHA256 9b6d52c42b84212f5a05c7d54ce1f09dc959f2dd531e4cdbfef4830baaceb79b

Gaussian covariance and tensor sum give E[B^T B]=I_{r^2}.

Since $\mathbb{E}[\gamma_{i}\gamma_{i}^{\top}]=I_{r}$ , the row definition of $B$ now gives $\displaystyle\mathbb{E}[B^{\top}B]$ $\displaystyle=\frac{1}{d}\sum_{i}\bigl(\mathbb{E}[\gamma_{i}\gamma_{i}^{\top}]\otimes t_{i}t_{i}^{\top}\bigr)$ $\displaystyle=\frac{1}{d}\left(I_{r}\otimes\sum_{i}t_{i}t_{i}^{\top}\right)=I_{r^{2}}.$

## NODE src:A3.EGx7

reused_display; raw bytes [773349,776654); SHA256 c48f6706c4d0444211a2d301a0d3ec8b3db692ad3c3c4d3a0576c587b6cb80f6

Gaussian covariance and tensor sum give E[B^T B]=I_{r^2}.

$\displaystyle\mathbb{E}[B^{\top}B]$ $\displaystyle=\frac{1}{d}\sum_{i}\bigl(\mathbb{E}[\gamma_{i}\gamma_{i}^{\top}]\otimes t_{i}t_{i}^{\top}\bigr)$ $\displaystyle=\frac{1}{d}\left(I_{r}\otimes\sum_{i}t_{i}t_{i}^{\top}\right)=I_{r^{2}}.$

## NODE src:A3.SS2.p7

proof_paragraph; raw bytes [776662,789570); SHA256 e5f214d4db4f9d0f8d108a45b0f3cffa1715c084b2116dd93fb74934bf498eb3

Frequency interval 1..4q+1<2d gives weighted cosine cancellation and E[B^T D_n B]=0.

$\boxed{\mathbb{E}[B^{\top}D_{n}B]=0}$ . Since $n=2q+1$ , for $0\leq j,k\leq q$ we have $1\leq n-j-k\leq n\pm j\pm k\leq n+j+k\leq 4q+1<2d.$ Thus the cosine-sum identity above gives $\displaystyle\sum_{i}\cos(n\theta_{i})\cos(j\theta_{i})\cos(k\theta_{i})$ $\displaystyle=\quad$ $\displaystyle\frac{1}{4}\sum_{i}\bigl[\cos((n+j+k)\theta_{i})+\cos((n+j-k)\theta_{i})+\cos((n-j+k)\theta_{i})+\cos((n-j-k)\theta_{i})\bigr]$ $\displaystyle=\quad$ $\displaystyle 0.$ Each entry of $\sum_{i}\cos(n\theta_{i})t_{i}t_{i}^{\top}$ is a constant multiple of such a sum, so $\sum_{i}\cos(n\theta_{i})t_{i}t_{i}^{\top}=0$ . Consequently, $\displaystyle\mathbb{E}[B^{\top}D_{n}B]$ $\displaystyle=\frac{1}{d}\sum_{i}\cos(n\theta_{i})\bigl(\mathbb{E}[\gamma_{i}\gamma_{i}^{\top}]\otimes t_{i}t_{i}^{\top}\bigr)$ $\displaystyle=\frac{1}{d}\left(I_{r}\otimes\sum_{i}\cos(n\theta_{i})t_{i}t_{i}^{\top}\right)=0.$

## NODE src:A3.Ex96

reused_display; raw bytes [777992,779055); SHA256 504cb6c51e4b9a628181b23d9548da111766196d98b5de86bc9c95ab12012f4a

Frequency interval 1..4q+1<2d gives weighted cosine cancellation and E[B^T D_n B]=0.

$1\leq n-j-k\leq n\pm j\pm k\leq n+j+k\leq 4q+1<2d.$

## NODE src:A3.EGx8

reused_display; raw bytes [779135,784181); SHA256 487a48004dce94a66914e9f3302b3cba778ed4a051e24a3e52be89a7c6014fd9

Frequency interval 1..4q+1<2d gives weighted cosine cancellation and E[B^T D_n B]=0.

$\displaystyle\sum_{i}\cos(n\theta_{i})\cos(j\theta_{i})\cos(k\theta_{i})$ $\displaystyle=\quad$ $\displaystyle\frac{1}{4}\sum_{i}\bigl[\cos((n+j+k)\theta_{i})+\cos((n+j-k)\theta_{i})+\cos((n-j+k)\theta_{i})+\cos((n-j-k)\theta_{i})\bigr]$ $\displaystyle=\quad$ $\displaystyle 0.$

## NODE src:A3.EGx9

reused_display; raw bytes [785679,789563); SHA256 1271c1790cd77c177aa7e3dd80776a371b3372d8741a742788ccc907b8a4113d

Frequency interval 1..4q+1<2d gives weighted cosine cancellation and E[B^T D_n B]=0.

$\displaystyle\mathbb{E}[B^{\top}D_{n}B]$ $\displaystyle=\frac{1}{d}\sum_{i}\cos(n\theta_{i})\bigl(\mathbb{E}[\gamma_{i}\gamma_{i}^{\top}]\otimes t_{i}t_{i}^{\top}\bigr)$ $\displaystyle=\frac{1}{d}\left(I_{r}\otimes\sum_{i}\cos(n\theta_{i})t_{i}t_{i}^{\top}\right)=0.$

## NODE src:A3.SS2.p8

unnamed_estimate; raw bytes [789571,791236); SHA256 afddc30c486d0a5b9b2d50086d5331cd0b3b6e2caecdc347328f680be51daec2

Deterministic ||t_i||^2<=1+2q<=2r.

Finally, $\|t_{i}\|^{2}=1+2\sum_{j=1}^{q}\cos^{2}(j\theta_{i})\leq 1+2q\leq 2r.$ ∎

## NODE src:A3.Ex102

reused_display; raw bytes [789705,791138); SHA256 1e29d148a65c440f198a8d5d3f4c5c4e2b9049f684960caa8fee9e1f57478afe

Deterministic ||t_i||^2<=1+2q<=2r.

$\|t_{i}\|^{2}=1+2\sum_{j=1}^{q}\cos^{2}(j\theta_{i})\leq 1+2q\leq 2r.$

## EXCLUDED src:A3.SS2.p9

proof_paragraph; raw bytes [791244,792542); SHA256 a5a392a1325b01f7a3f6e35c6d61d96eb5ab4c0e45523bec2fe5b981957cd44d

Concentration roadmap; no new bound beyond the following fact.

We next bound the deviations of the two matrices from their expectations in operator norm. These simultaneous bounds will control both $\|Bc\|^{2}$ and $c^{\top}B^{\top}D_{n}Bc$ for every coefficient vector $c$ .

## NODE src:A3.Thmtheorem6

fact_statement; raw bytes [792543,795342); SHA256 2c5db3c27b6d906b28af649860b11c1c5c2bfbf2311904cb6763116c09e3cd44

Fact C.6 fixes sufficiently large absolute C; both Gram bounds hold on one event of probability >=0.995.

Fact C.6 (Simultaneous Gram-matrix concentration). For a sufficiently large absolute constant $C$ in the definition of $\tau_{d,q}$ , with probability at least $0.995$ , $\|B^{\top}B-I_{r^{2}}\|_{\rm op}\leq\tau_{d,q},\qquad\|B^{\top}D_{n}B\|_{\rm op}\leq\tau_{d,q}.$

## NODE src:A3.Thmtheorem6.p1

fact_statement; raw bytes [792955,795335); SHA256 d1136581bdd94bf87b9f20a6a998a7249af78232796ca6ad76a98def7b6e26f9

Fact C.6 fixes sufficiently large absolute C; both Gram bounds hold on one event of probability >=0.995.

For a sufficiently large absolute constant $C$ in the definition of $\tau_{d,q}$ , with probability at least $0.995$ , $\|B^{\top}B-I_{r^{2}}\|_{\rm op}\leq\tau_{d,q},\qquad\|B^{\top}D_{n}B\|_{\rm op}\leq\tau_{d,q}.$

## NODE src:A3.Ex103

reused_display; raw bytes [793875,795328); SHA256 c31a6ff3ef4cbfa88ea87b677f439eba3c2d3e394dc35531b3951f6dcfaef4e7

Fact C.6 fixes sufficiently large absolute C; both Gram bounds hold on one event of probability >=0.995.

$\|B^{\top}B-I_{r^{2}}\|_{\rm op}\leq\tau_{d,q},\qquad\|B^{\top}D_{n}B\|_{\rm op}\leq\tau_{d,q}.$

## NODE src:A3.SS2.p10

proof_paragraph; raw bytes [795457,800895); SHA256 f5893d415e7a14cf7f0a8c619b6997d2b6f23c7a86573a1a370dfafc961648ee

L and R_i definitions, Gaussian exponential moment, Markov tail, and 0.999 truncation event.

Truncation and its bias. Set $L=2r+3\log(1000d)$ and $R_{i}=\|\gamma_{i}\|^{2}$ . Since $\mathbb{E}e^{R_{i}/3}=3^{r/2}$ , Markov’s inequality gives, for $x\geq 0$ , $\mathbb{P}(R_{i}>2r+3x)\leq\exp\!\left(\frac{r}{2}\log 3-\frac{2r}{3}-x\right)\leq e^{-x},$ where the last inequality uses $(\log 3)/2<2/3$ . Consequently, the event $\mathcal{T}=\{R_{i}\leq L\text{ for every }i\}$ has probability at least $1-d/(1000d)=0.999$ .

## NODE src:A3.Ex104

reused_display; raw bytes [797409,798935); SHA256 a7ad8c5495d9db04ac3f588edd09164552546847909bc0dac943c0ef66c47f1d

L and R_i definitions, Gaussian exponential moment, Markov tail, and 0.999 truncation event.

$\mathbb{P}(R_{i}>2r+3x)\leq\exp\!\left(\frac{r}{2}\log 3-\frac{2r}{3}-x\right)\leq e^{-x},$

## NODE src:A3.Ex105

source_definition; raw bytes [799521,800320); SHA256 c643f1263d89efd72cc79b1d0f68141e6492993c4c94d522fd0f1bf81c112828

L and R_i definitions, Gaussian exponential moment, Markov tail, and 0.999 truncation event.

$\mathcal{T}=\{R_{i}\leq L\text{ for every }i\}$

## NODE src:A3.SS2.p11

unnamed_estimate; raw bytes [800896,804249); SHA256 4e0532392a0f28b7ee6823ad927724eb0d615f2671f46fa67bb231b1a3f4d45e

Shifted tail integration controls truncation bias by (L+3)/(1000d).

For $s\geq 0$ , the same tail bound gives $\mathbb{P}(R_{i}>L+s)\leq e^{-s/3}/(1000d)$ . Hence $\displaystyle\mathbb{E}[R_{i}\mathbf{1}_{\{R_{i}>L\}}]$ $\displaystyle=L\mathbb{P}(R_{i}>L)+\int_{0}^{\infty}\mathbb{P}(R_{i}>L+s)\,ds\leq\frac{L+3}{1000d}.$

## NODE src:A3.EGx10

reused_display; raw bytes [801924,804242); SHA256 672a7459c7e32cc4fe745460b6f20db6e5f8a095db5531d5ca7346a06680829f

Shifted tail integration controls truncation bias by (L+3)/(1000d).

$\displaystyle\mathbb{E}[R_{i}\mathbf{1}_{\{R_{i}>L\}}]$ $\displaystyle=L\mathbb{P}(R_{i}>L)+\int_{0}^{\infty}\mathbb{P}(R_{i}>L+s)\,ds\leq\frac{L+3}{1000d}.$

## NODE src:A3.SS2.p12

proof_paragraph; raw bytes [804250,812472); SHA256 3f2c83ee54eabdf9f98dd13156bea1fa63d7b2c95440208964402849c77c236d

Independent truncated Y_i, radial scalar a, 0<=a<=1 and bias bound; weighted truncated expectation stays zero.

Define the independent truncated matrices $Y_{i}=\frac{1}{d}(\gamma_{i}\gamma_{i}^{\top}\otimes t_{i}t_{i}^{\top})\mathbf{1}_{\{R_{i}\leq L\}}.$ By radial symmetry, $\mathbb{E}[\gamma_{i}\gamma_{i}^{\top}\mathbf{1}_{\{R_{i}\leq L\}}]=aI_{r},\qquad a=\frac{1}{r}\mathbb{E}[R_{i}\mathbf{1}_{\{R_{i}\leq L\}}].$ The scalar $a$ is the same for every $i$ . Since $\mathbb{E}R_{i}=r$ , we have $0\leq a\leq 1$ and $1-a=\frac{1}{r}\mathbb{E}[R_{i}\mathbf{1}_{\{R_{i}>L\}}]\leq\frac{L+3}{1000rd}.$ Moreover, $\mathbb{E}Y_{i}=(a/d)(I_{r}\otimes t_{i}t_{i}^{\top})$ . Fact C.5 therefore gives $\sum_{i}\mathbb{E}Y_{i}=aI_{r^{2}},\qquad\sum_{i}\cos(n\theta_{i})\mathbb{E}Y_{i}=0.$ Thus, the truncated weighted sum has zero expectation.

## NODE src:A3.Ex107

source_definition; raw bytes [804420,805656); SHA256 aa8878824a99bc9a00a98697189eda90e41c1f9996d9f10b237c86ec044ce0dd

Independent truncated Y_i, radial scalar a, 0<=a<=1 and bias bound; weighted truncated expectation stays zero.

$Y_{i}=\frac{1}{d}(\gamma_{i}\gamma_{i}^{\top}\otimes t_{i}t_{i}^{\top})\mathbf{1}_{\{R_{i}\leq L\}}.$

## NODE src:A3.Ex108

source_definition; raw bytes [805766,807298); SHA256 67681f5559fbaf004a73196029e84f0d6619a1e99842661c229d833dcd9ab7f6

Independent truncated Y_i, radial scalar a, 0<=a<=1 and bias bound; weighted truncated expectation stays zero.

$\mathbb{E}[\gamma_{i}\gamma_{i}^{\top}\mathbf{1}_{\{R_{i}\leq L\}}]=aI_{r},\qquad a=\frac{1}{r}\mathbb{E}[R_{i}\mathbf{1}_{\{R_{i}\leq L\}}].$

## NODE src:A3.Ex109

reused_display; raw bytes [808414,809636); SHA256 a7416f9a70b57e8bf3d75acbd19f26f3f1b271367be7fd19016911317e2675fb

Independent truncated Y_i, radial scalar a, 0<=a<=1 and bias bound; weighted truncated expectation stays zero.

$1-a=\frac{1}{r}\mathbb{E}[R_{i}\mathbf{1}_{\{R_{i}>L\}}]\leq\frac{L+3}{1000rd}.$

## NODE src:A3.Ex110

reused_display; raw bytes [810856,812321); SHA256 f2d464403380f8697a6a4f1149fb5eda40610f98bc04eb4c29060b15cd8bcf71

Independent truncated Y_i, radial scalar a, 0<=a<=1 and bias bound; weighted truncated expectation stays zero.

$\sum_{i}\mathbb{E}Y_{i}=aI_{r^{2}},\qquad\sum_{i}\cos(n\theta_{i})\mathbb{E}Y_{i}=0.$

## NODE src:A3.SS2.p13

unnamed_estimate; raw bytes [812473,818093); SHA256 8972c1e0948cb89ac310f36272c33d25e4a5cf20c409527c22221da4f7742d22

Centered Z_i and uniform summand norm R_*=2r(L+1)/d for both sequences.

Bounds for the centered summands. Put $Z_{i}=Y_{i}-\mathbb{E}Y_{i}$ . Using $\|t_{i}\|^{2}\leq 2r$ , we obtain $\|Y_{i}\|_{\rm op}=\frac{R_{i}\|t_{i}\|^{2}}{d}\mathbf{1}_{\{R_{i}\leq L\}}\leq\frac{2rL}{d},\qquad\|\mathbb{E}Y_{i}\|_{\rm op}=\frac{a\|t_{i}\|^{2}}{d}\leq\frac{2r}{d}.$ Hence $\|Z_{i}\|_{\rm op}\leq\frac{2r(L+1)}{d}=:R_{*}.$ The same bound holds for $\cos(n\theta_{i})Z_{i}$ , since $|\cos(n\theta_{i})|\leq 1$ .

## NODE src:A3.Ex111

reused_display; raw bytes [813593,815738); SHA256 a98249c1333c2dd2b532311800cb19ce6893451f3e39a4ba78af50caf3294182

Centered Z_i and uniform summand norm R_*=2r(L+1)/d for both sequences.

$\|Y_{i}\|_{\rm op}=\frac{R_{i}\|t_{i}\|^{2}}{d}\mathbf{1}_{\{R_{i}\leq L\}}\leq\frac{2rL}{d},\qquad\|\mathbb{E}Y_{i}\|_{\rm op}=\frac{a\|t_{i}\|^{2}}{d}\leq\frac{2r}{d}.$

## NODE src:A3.Ex112

source_definition; raw bytes [815834,816940); SHA256 7c0862579e0fb13f56317421cda9b6054680e327fba2f20dde74c3a0f3f40905

Centered Z_i and uniform summand norm R_*=2r(L+1)/d for both sequences.

$\|Z_{i}\|_{\rm op}\leq\frac{2r(L+1)}{d}=:R_{*}.$

## NODE src:A3.SS2.p14

proof_paragraph; raw bytes [818094,833849); SHA256 7c3f73ea3d271aed4ba8cb43157e35d0035a0943d38f891c23d17e8114faf029

Gaussian fourth moments, PSD truncation removal, tensor row sum, and common variance v_*=2r(r+2)/d.

The Gaussian fourth moments give $\mathbb{E}[R_{i}\gamma_{i}\gamma_{i}^{\top}]=(r+2)I_{r}.$ Indeed, the off-diagonal entries vanish by sign symmetry, while each diagonal entry equals $3+(r-1)=r+2$ . Since $(\gamma_{i}\gamma_{i}^{\top})^{2}=R_{i}\gamma_{i}\gamma_{i}^{\top}$ and $(t_{i}t_{i}^{\top})^{2}=\|t_{i}\|^{2}t_{i}t_{i}^{\top}$ , we have $Y_{i}^{2}=\frac{R_{i}\|t_{i}\|^{2}}{d^{2}}(\gamma_{i}\gamma_{i}^{\top}\otimes t_{i}t_{i}^{\top})\mathbf{1}_{\{R_{i}\leq L\}}.$ Dropping the truncation indicator in this positive semidefinite expression yields $\displaystyle\sum_{i}\mathbb{E}Y_{i}^{2}$ $\displaystyle\preceq\frac{r+2}{d^{2}}\sum_{i}\|t_{i}\|^{2}(I_{r}\otimes t_{i}t_{i}^{\top})$ $\displaystyle\preceq\frac{2r(r+2)}{d^{2}}\left(I_{r}\otimes\sum_{i}t_{i}t_{i}^{\top}\right)$ $\displaystyle=\frac{2r(r+2)}{d}I_{r^{2}}.$ Here we used $\|t_{i}\|^{2}\leq 2r$ and $\sum_{i}t_{i}t_{i}^{\top}=dI_{r}$ . Since $\mathbb{E}Z_{i}^{2}=\mathbb{E}Y_{i}^{2}-(\mathbb{E}Y_{i})^{2}\preceq\mathbb{E}Y_{i}^{2},$ the sequence $(Z_{i})_{i}$ has variance parameter at most $v_{*}:=\frac{2r(r+2)}{d}.$ The same is true for $(\cos(n\theta_{i})Z_{i})_{i}$ , because $\mathbb{E}[(\cos(n\theta_{i})Z_{i})^{2}]=\cos^{2}(n\theta_{i})\mathbb{E}Z_{i}^{2}\preceq\mathbb{E}Z_{i}^{2}.$

## NODE src:A3.Ex113

reused_display; raw bytes [818255,819402); SHA256 92653a199211b5ffd9f9ef250f302fb2ec45b79e6a342d80c16e59904d34b8c1

Gaussian fourth moments, PSD truncation removal, tensor row sum, and common variance v_*=2r(r+2)/d.

$\mathbb{E}[R_{i}\gamma_{i}\gamma_{i}^{\top}]=(r+2)I_{r}.$

## NODE src:A3.Ex114

reused_display; raw bytes [821601,823127); SHA256 5c8f50590e09a13f16d70297a5a496fc687c4c894fef3b0d9a860f0d4aebb61a

Gaussian fourth moments, PSD truncation removal, tensor row sum, and common variance v_*=2r(r+2)/d.

$Y_{i}^{2}=\frac{R_{i}\|t_{i}\|^{2}}{d^{2}}(\gamma_{i}\gamma_{i}^{\top}\otimes t_{i}t_{i}^{\top})\mathbf{1}_{\{R_{i}\leq L\}}.$

## NODE src:A3.EGx11

reused_display; raw bytes [823299,827749); SHA256 9442d0c8e11d70f05131835299bf4ba385b1bbbaaa46aa35762370d5fe8d790f

Gaussian fourth moments, PSD truncation removal, tensor row sum, and common variance v_*=2r(r+2)/d.

$\displaystyle\sum_{i}\mathbb{E}Y_{i}^{2}$ $\displaystyle\preceq\frac{r+2}{d^{2}}\sum_{i}\|t_{i}\|^{2}(I_{r}\otimes t_{i}t_{i}^{\top})$ $\displaystyle\preceq\frac{2r(r+2)}{d^{2}}\left(I_{r}\otimes\sum_{i}t_{i}t_{i}^{\top}\right)$ $\displaystyle=\frac{2r(r+2)}{d}I_{r^{2}}.$

## NODE src:A3.Ex118

reused_display; raw bytes [828836,830090); SHA256 295ba61f5ad10147734d5b23228915422063cf1bc9af5181c39f64672a51e0c7

Gaussian fourth moments, PSD truncation removal, tensor row sum, and common variance v_*=2r(r+2)/d.

$\mathbb{E}Z_{i}^{2}=\mathbb{E}Y_{i}^{2}-(\mathbb{E}Y_{i})^{2}\preceq\mathbb{E}Y_{i}^{2},$

## NODE src:A3.Ex119

source_definition; raw bytes [830542,831400); SHA256 54e4a0f21c38d120725a043f13a02d915bc2fded8a64f90a0313f18428381a5f

Gaussian fourth moments, PSD truncation removal, tensor row sum, and common variance v_*=2r(r+2)/d.

$v_{*}:=\frac{2r(r+2)}{d}.$

## NODE src:A3.Ex120

reused_display; raw bytes [832122,833842); SHA256 0c518b77984fa7f3b19ae18d7508bb2a434df786bc107bbb9c7174f4e10877cc

Gaussian fourth moments, PSD truncation removal, tensor row sum, and common variance v_*=2r(r+2)/d.

$\mathbb{E}[(\cos(n\theta_{i})Z_{i})^{2}]=\cos^{2}(n\theta_{i})\mathbb{E}Z_{i}^{2}\preceq\mathbb{E}Z_{i}^{2}.$

## NODE src:A3.SS2.p15

external_result; raw bytes [833850,836896); SHA256 c41e14e0d04d4d62400e1d94ef0da0ff68594e6312377623e1af064f712c5650

Uncited two-sided bounded matrix Bernstein, explicitly independent/centered/self-adjoint, same tail bound for both matrix sequences.

Applying matrix Bernstein. Both sequences consist of independent, centered, self-adjoint matrices. The two-sided bounded matrix Bernstein inequality gives, for $t>0$ , $\mathbb{P}\!\left(\left\|\sum_{i}Z_{i}\right\|_{\rm op}>t\right)\leq 2r^{2}\exp\!\left(-\frac{t^{2}}{2(v_{*}+R_{*}t/3)}\right),$ and the same bound holds for $\sum_{i}\cos(n\theta_{i})Z_{i}$ .

## NODE src:A3.Ex121

reused_display; raw bytes [834432,836206); SHA256 00bd8c7186bfa83e81d0e400d0350f75c60509ff5b5b30923009e0f4f9571f18

Uncited two-sided bounded matrix Bernstein, explicitly independent/centered/self-adjoint, same tail bound for both matrix sequences.

$\mathbb{P}\!\left(\left\|\sum_{i}Z_{i}\right\|_{\rm op}>t\right)\leq 2r^{2}\exp\!\left(-\frac{t^{2}}{2(v_{*}+R_{*}t/3)}\right),$

## NODE src:A3.SS2.p16

proof_paragraph; raw bytes [836897,842341); SHA256 205c947a835b9b1f1ff8b8826e17236d9b54f8367bc0eca8cf2111d81311a304

z and Delta; explicit quadratic expansion; 0.002 failure each and 0.996 simultaneous Bernstein event.

Set $z=\log(1000r^{2}),\qquad\Delta=\sqrt{2v_{*}z}+\frac{2R_{*}z}{3}.$ A direct expansion gives $\Delta^{2}-2z(v_{*}+R_{*}\Delta/3)=\frac{2R_{*}z}{3}\sqrt{2v_{*}z}\geq 0.$ Therefore each matrix bound fails with probability at most $2r^{2}e^{-z}=0.002$ . By a union bound, with probability at least $0.996$ , $\left\|\sum_{i}Z_{i}\right\|_{\rm op}\leq\Delta,\qquad\left\|\sum_{i}\cos(n\theta_{i})Z_{i}\right\|_{\rm op}\leq\Delta.$

## NODE src:A3.Ex122

source_definition; raw bytes [837029,838342); SHA256 3be96d7870580c00f1ac4e75c1609e7c5796e105ad05f735c51b696ca8eee1a0

z and Delta; explicit quadratic expansion; 0.002 failure each and 0.996 simultaneous Bernstein event.

$z=\log(1000r^{2}),\qquad\Delta=\sqrt{2v_{*}z}+\frac{2R_{*}z}{3}.$

## NODE src:A3.Ex123

reused_display; raw bytes [838457,839997); SHA256 b0152468ce7e2b09785d93006ed698805cb1ae313f51a1de83f194e30ac5bc22

z and Delta; explicit quadratic expansion; 0.002 failure each and 0.996 simultaneous Bernstein event.

$\Delta^{2}-2z(v_{*}+R_{*}\Delta/3)=\frac{2R_{*}z}{3}\sqrt{2v_{*}z}\geq 0.$

## NODE src:A3.Ex124

reused_display; raw bytes [840825,842334); SHA256 13830ac46a9e3bcf2355f45fb72d81b7b94608bf153666037aa1766f06b068bc

z and Delta; explicit quadratic expansion; 0.002 failure each and 0.996 simultaneous Bernstein event.

$\left\|\sum_{i}Z_{i}\right\|_{\rm op}\leq\Delta,\qquad\left\|\sum_{i}\cos(n\theta_{i})Z_{i}\right\|_{\rm op}\leq\Delta.$

## NODE src:A3.SS2.p17

proof_paragraph; raw bytes [842342,846952); SHA256 a3b75304da2c12694aca35bf85505c9ecf7e8526d95abf7c53eb4ac6cb6c4ef4

On truncation, original/truncated identities; union bound 0.995; unweighted bias Delta+(1-a), weighted Delta.

On $\mathcal{T}$ , the original and truncated sums agree. Using their expectations computed above, we obtain $B^{\top}B-I_{r^{2}}=\sum_{i}Z_{i}-(1-a)I_{r^{2}},\qquad B^{\top}D_{n}B=\sum_{i}\cos(n\theta_{i})Z_{i}.$ Intersecting $\mathcal{T}$ with the two concentration events therefore gives, with probability at least $1-0.001-0.004=0.995$ , $\|B^{\top}B-I_{r^{2}}\|_{\rm op}\leq\Delta+(1-a),\qquad\|B^{\top}D_{n}B\|_{\rm op}\leq\Delta.$

## NODE src:A3.Ex125

reused_display; raw bytes [842805,844686); SHA256 4aeed5cc673a5d53e21c8743db9e407f597744bdd0f5e7c3ce857cbca541b7c1

On truncation, original/truncated identities; union bound 0.995; unweighted bias Delta+(1-a), weighted Delta.

$B^{\top}B-I_{r^{2}}=\sum_{i}Z_{i}-(1-a)I_{r^{2}},\qquad B^{\top}D_{n}B=\sum_{i}\cos(n\theta_{i})Z_{i}.$

## NODE src:A3.Ex126

reused_display; raw bytes [845431,846945); SHA256 5004f3126cf3fb00b48f815b006a0477b06cabeb9f1d2ebc06b7c1b112326b63

On truncation, original/truncated identities; union bound 0.995; unweighted bias Delta+(1-a), weighted Delta.

$\|B^{\top}B-I_{r^{2}}\|_{\rm op}\leq\Delta+(1-a),\qquad\|B^{\top}D_{n}B\|_{\rm op}\leq\Delta.$

## NODE src:A3.SS2.p18

unnamed_estimate; raw bytes [846953,854680); SHA256 70d6092b84b0951f184795a152925a2e836c07187b0577830defbc1badd9f208

Integer budget yields d>=2 and 2r<=d; absolute O constants, absolute c>0, and choose absolute C>=c in tau.

Simplifying the bound. Since $2q+1<d$ , we have $d\geq 2$ and $2r\leq d$ . Thus $z=O(\log d)$ and $L+3=O(r+\log d)$ , with absolute implicit constants. Together with $r+2\leq 3r$ , these estimates imply $\displaystyle\Delta+(1-a)$ $\displaystyle\leq 2\sqrt{\frac{r(r+2)z}{d}}+\frac{4r(L+1)z}{3d}+\frac{L+3}{1000rd}$ $\displaystyle\leq c\left[r\sqrt{\frac{\log d}{d}}+\frac{r(r+\log d)\log d}{d}\right]$ for an absolute constant $c>0$ . Since $r=q+1$ , choosing the absolute constant $C$ in $\tau_{d,q}$ so that $C\geq c$ gives $\Delta+(1-a)\leq\tau_{d,q}$ . This proves both asserted bounds. ∎

## NODE src:A3.EGx12

reused_display; raw bytes [849319,852810); SHA256 3bd868ee172a9451e1581e6d183083c44c803b6296ef718a32fcb5af5f528f4d

Integer budget yields d>=2 and 2r<=d; absolute O constants, absolute c>0, and choose absolute C>=c in tau.

$\displaystyle\Delta+(1-a)$ $\displaystyle\leq 2\sqrt{\frac{r(r+2)z}{d}}+\frac{4r(L+1)z}{3d}+\frac{L+3}{1000rd}$ $\displaystyle\leq c\left[r\sqrt{\frac{\log d}{d}}+\frac{r(r+\log d)\log d}{d}\right]$

## NODE src:A3.SS2.p19

proof_paragraph; raw bytes [855117,864802); SHA256 acba76c02ff803fa9fc58f375bb3bc02d524bfd016bbdfe4e9623c96855dcaa6

Choose C for C.6; on one 0.995 event use range(B), Gram lower/coercive bound and weighted upper bound, tau<=1/2, simultaneous all-u, then relax to 0.99.

Choose the absolute constant $C$ sufficiently large for Fact C.6 to apply. Then, with probability at least $0.995$ , $\|B^{\top}B-I_{r^{2}}\|_{\rm op}\leq\tau_{d,q},\qquad\|B^{\top}D_{n}B\|_{\rm op}\leq\tau_{d,q}.$ On this event, let $u\in\mathcal{K}_{q}$ . By Fact C.5, we can write $u=Bc$ . The two matrix bounds give $\displaystyle\|u\|^{2}$ $\displaystyle=c^{\top}B^{\top}Bc\geq(1-\tau_{d,q})\|c\|^{2},$ $\displaystyle|u^{\top}D_{n}u|$ $\displaystyle=|c^{\top}B^{\top}D_{n}Bc|\leq\tau_{d,q}\|c\|^{2}.$ Since $\tau_{d,q}\leq 1/2$ , combining these inequalities yields $|u^{\top}D_{n}u|\leq\frac{\tau_{d,q}}{1-\tau_{d,q}}\|u\|^{2}\leq 2\tau_{d,q}\|u\|^{2}.$ These inequalities hold for every $c$ on the same event, so the conclusion holds simultaneously for every $u\in\mathcal{K}_{q}$ . Since $0.995\geq 0.99$ , the lemma follows. ∎

## NODE src:A3.Ex129

reused_display; raw bytes [855975,857428); SHA256 efbcc0c6852a2bc73592e1c653d9a9d4872ddfb1148f9cf668724e6155f50f69

Choose C for C.6; on one 0.995 event use range(B), Gram lower/coercive bound and weighted upper bound, tau<=1/2, simultaneous all-u, then relax to 0.99.

$\|B^{\top}B-I_{r^{2}}\|_{\rm op}\leq\tau_{d,q},\qquad\|B^{\top}D_{n}B\|_{\rm op}\leq\tau_{d,q}.$

## NODE src:A3.EGx13

reused_display; raw bytes [858432,861786); SHA256 b96f047d45eff5351667f6ecb71ffdd504fda66cdd7f6a506bc60972c99c1dcf

Choose C for C.6; on one 0.995 event use range(B), Gram lower/coercive bound and weighted upper bound, tau<=1/2, simultaneous all-u, then relax to 0.99.

$\displaystyle\|u\|^{2}$ $\displaystyle=c^{\top}B^{\top}Bc\geq(1-\tau_{d,q})\|c\|^{2},$ $\displaystyle|u^{\top}D_{n}u|$ $\displaystyle=|c^{\top}B^{\top}D_{n}Bc|\leq\tau_{d,q}\|c\|^{2}.$

## NODE src:A3.Ex132

reused_display; raw bytes [862263,863820); SHA256 c3e5f786196a3c8010ef4c2077eecd7d04bd188005eb7d1a9210654d78d6791d

Choose C for C.6; on one 0.995 event use range(B), Gram lower/coercive bound and weighted upper bound, tau<=1/2, simultaneous all-u, then relax to 0.99.

$|u^{\top}D_{n}u|\leq\frac{\tau_{d,q}}{1-\tau_{d,q}}\|u\|^{2}\leq 2\tau_{d,q}\|u\|^{2}.$

## NODE src:A3.SS3.p1

source_definition; raw bytes [865258,866684); SHA256 b11da7ea3ddaf345ba9badc69a035599e0e6e8b05d7da477e4c60a0c7ae15c93

Recall grid definitions and state cosine expansion/moments/variance/bias sequence.

Recall that $\theta_{i}=(i-\tfrac{1}{2})\pi/d$ and $\lambda_{i}=(\kappa+1)/2+(\kappa-1)\cos\theta_{i}/2$ . We first expand the inverse spectrum in cosine modes and sum this expansion over the grid. We then bound the variances and the normalized cosine bias.

## NODE src:A3.Thmtheorem7

fact_statement; raw bytes [866685,869759); SHA256 a0b6c496f00a6b5501e87cc35413b5af124a736c6c00b4b8e9ce5dde2bd92256

Fact C.7 inverse-spectrum cosine series for every real theta; absolute and uniform convergence.

Fact C.7 (Cosine expansion of the inverse spectrum). For every $\theta\in\mathbb{R}$ , $\frac{2}{\kappa+1+(\kappa-1)\cos\theta}=\frac{1}{\sqrt{\kappa}}\left(1+2\sum_{j\geq 1}(-\varrho_{\kappa})^{j}\cos(j\theta)\right).$ The series converges absolutely and uniformly in $\theta$ .

## NODE src:A3.Thmtheorem7.p1

fact_statement; raw bytes [867099,869752); SHA256 c07fcd208077eebca808a5167db3f0dad90eab6667ae1d52fe424e8421d96b89

Fact C.7 inverse-spectrum cosine series for every real theta; absolute and uniform convergence.

For every $\theta\in\mathbb{R}$ , $\frac{2}{\kappa+1+(\kappa-1)\cos\theta}=\frac{1}{\sqrt{\kappa}}\left(1+2\sum_{j\geq 1}(-\varrho_{\kappa})^{j}\cos(j\theta)\right).$ The series converges absolutely and uniformly in $\theta$ .

## NODE src:A3.Ex133

reused_display; raw bytes [867541,869373); SHA256 d0761c0b70ad57c4b12bdb326f38640916478304476f39777c36a92feee28af8

Fact C.7 inverse-spectrum cosine series for every real theta; absolute and uniform convergence.

$\frac{2}{\kappa+1+(\kappa-1)\cos\theta}=\frac{1}{\sqrt{\kappa}}\left(1+2\sum_{j\geq 1}(-\varrho_{\kappa})^{j}\cos(j\theta)\right).$

## NODE src:A3.SS3.p2

proof_paragraph; raw bytes [869874,878623); SHA256 a606486a76f545d3bb7195eca999599335d77c3843fdf5cb7afe98e35c47ef0e

0<rho<1, geometric-series identities, rational algebra, and uniform majorant prove C.7.

Since $0<\varrho_{\kappa}<1$ , the geometric-series identity gives $\displaystyle 1+2\sum_{j\geq 1}(-\varrho_{\kappa})^{j}\cos(j\theta)$ $\displaystyle=1-\frac{\varrho_{\kappa}e^{i\theta}}{1+\varrho_{\kappa}e^{i\theta}}-\frac{\varrho_{\kappa}e^{-i\theta}}{1+\varrho_{\kappa}e^{-i\theta}}$ $\displaystyle=\frac{1-\varrho_{\kappa}^{2}}{1+2\varrho_{\kappa}\cos\theta+\varrho_{\kappa}^{2}}.$ The definition of $\varrho_{\kappa}$ implies $\frac{1-\varrho_{\kappa}}{1+\varrho_{\kappa}}=\frac{1}{\sqrt{\kappa}},\qquad\frac{1+2\varrho_{\kappa}\cos\theta+\varrho_{\kappa}^{2}}{(1-\varrho_{\kappa})^{2}}=\frac{\kappa+1+(\kappa-1)\cos\theta}{2}.$ Combining these identities proves the expansion. Finally, $\sum_{j\geq 1}\left|(-\varrho_{\kappa})^{j}\cos(j\theta)\right|\leq\sum_{j\geq 1}\varrho_{\kappa}^{j}=\frac{\varrho_{\kappa}}{1-\varrho_{\kappa}},$ which proves absolute and uniform convergence. ∎

## NODE src:A3.EGx14

reused_display; raw bytes [870360,874348); SHA256 54244f1da32e3a02f1e71cd5359906c5bced4f27ec5ef0cd398628cf1250e663

0<rho<1, geometric-series identities, rational algebra, and uniform majorant prove C.7.

$\displaystyle 1+2\sum_{j\geq 1}(-\varrho_{\kappa})^{j}\cos(j\theta)$ $\displaystyle=1-\frac{\varrho_{\kappa}e^{i\theta}}{1+\varrho_{\kappa}e^{i\theta}}-\frac{\varrho_{\kappa}e^{-i\theta}}{1+\varrho_{\kappa}e^{-i\theta}}$ $\displaystyle=\frac{1-\varrho_{\kappa}^{2}}{1+2\varrho_{\kappa}\cos\theta+\varrho_{\kappa}^{2}}.$

## NODE src:A3.Ex136

reused_display; raw bytes [874701,876680); SHA256 ae2461e5f5c968abb13a3846ff44f5cd6c6babf2619b0a6673fa058a7ef2761d

0<rho<1, geometric-series identities, rational algebra, and uniform majorant prove C.7.

$\frac{1-\varrho_{\kappa}}{1+\varrho_{\kappa}}=\frac{1}{\sqrt{\kappa}},\qquad\frac{1+2\varrho_{\kappa}\cos\theta+\varrho_{\kappa}^{2}}{(1-\varrho_{\kappa})^{2}}=\frac{\kappa+1+(\kappa-1)\cos\theta}{2}.$

## NODE src:A3.Ex137

reused_display; raw bytes [876826,878478); SHA256 8f0c16dc388f14ddd7ea9dfd60cdeda8e32eb0e2be7b61a2e2e9b981df417fde

0<rho<1, geometric-series identities, rational algebra, and uniform majorant prove C.7.

$\sum_{j\geq 1}\left|(-\varrho_{\kappa})^{j}\cos(j\theta)\right|\leq\sum_{j\geq 1}\varrho_{\kappa}^{j}=\frac{\varrho_{\kappa}}{1-\varrho_{\kappa}},$

## NODE src:A3.Thmtheorem8

fact_statement; raw bytes [878631,881597); SHA256 b140aa800550bef09c6a308bbc1825c7cd915625a0b571108d8feef70846d135

Fact C.8 exact finite-grid M and signed mu_n for 1<=n<d.

Fact C.8 (Exact finite-grid moments). For $1\leq n<d$ , $M=\frac{d}{\sqrt{\kappa}}\frac{1-\varrho_{\kappa}^{2d}}{1+\varrho_{\kappa}^{2d}},\qquad(-1)^{n}\mu_{n}=\frac{d}{\sqrt{\kappa}}\frac{\varrho_{\kappa}^{n}-\varrho_{\kappa}^{2d-n}}{1+\varrho_{\kappa}^{2d}}.$

## NODE src:A3.Thmtheorem8.p1

fact_statement; raw bytes [879030,881590); SHA256 2fe26f97e77d6f838b48ce8b5414ed803f6828cbb5f065e3bbd4b8d6bc1a81f2

Fact C.8 exact finite-grid M and signed mu_n for 1<=n<d.

For $1\leq n<d$ , $M=\frac{d}{\sqrt{\kappa}}\frac{1-\varrho_{\kappa}^{2d}}{1+\varrho_{\kappa}^{2d}},\qquad(-1)^{n}\mu_{n}=\frac{d}{\sqrt{\kappa}}\frac{\varrho_{\kappa}^{n}-\varrho_{\kappa}^{2d-n}}{1+\varrho_{\kappa}^{2d}}.$

## NODE src:A3.Ex138

reused_display; raw bytes [879472,881583); SHA256 181bde7eb34ad4ad5b2113a81c6068cebb6e2e64aa18822ca7a53bcfc32ccac0

Fact C.8 exact finite-grid M and signed mu_n for 1<=n<d.

$M=\frac{d}{\sqrt{\kappa}}\frac{1-\varrho_{\kappa}^{2d}}{1+\varrho_{\kappa}^{2d}},\qquad(-1)^{n}\mu_{n}=\frac{d}{\sqrt{\kappa}}\frac{\varrho_{\kappa}^{n}-\varrho_{\kappa}^{2d-n}}{1+\varrho_{\kappa}^{2d}}.$

## NODE src:A3.SS3.p3

proof_paragraph; raw bytes [881712,886778); SHA256 6554b5d756b238e89c90ce4967640779084a3241daae5f54c7a40ced52761b4f

Cosine-grid sum for every integer k, including k=2ad alias classes.

For every integer $k$ , $\sum_{i=1}^{d}\cos(k\theta_{i})=\begin{cases}d(-1)^{a},&k=2ad,\quad a\in\mathbb{Z},\\ 0,&k\notin 2d\mathbb{Z}.\end{cases}$ Indeed, if $k\notin 2d\mathbb{Z}$ , the finite cosine sum is $\sin(k\pi)/(2\sin(k\pi/(2d)))=0$ . If $k=2ad$ , then $\cos(k\theta_{i})=\cos(2ai\pi-a\pi)=(-1)^{a}$ .

## NODE src:A3.Ex139

reused_display; raw bytes [882040,884013); SHA256 5d4973b57a76fc652616f4378c96e459d1488d3332a86ba95cc6f187224fa556

Cosine-grid sum for every integer k, including k=2ad alias classes.

$\sum_{i=1}^{d}\cos(k\theta_{i})=\begin{cases}d(-1)^{a},&k=2ad,\quad a\in\mathbb{Z},\\ 0,&k\notin 2d\mathbb{Z}.\end{cases}$

## NODE src:A3.SS3.p4

proof_paragraph; raw bytes [886779,889093); SHA256 24d5df02003d925217b9f4ad4c619c25fa5c4327a5f12ea83c3a94877c034a80

Coordinate Gaussian second moments and absolute convergence justify finite-sum/series interchange.

Since $\mathbb{E}U_{i}^{2}=1/\lambda_{i}$ , $M=\sum_{i}\frac{1}{\lambda_{i}},\qquad\mu_{n}=\sum_{i}\frac{\cos(n\theta_{i})}{\lambda_{i}}.$ Fact C.7 allows us to interchange the absolutely convergent series with the finite grid sum.

## NODE src:A3.Ex140

reused_display; raw bytes [887352,888660); SHA256 1352763ec4bd0c4549307b0922222718a425de1020b2c06fd137a2ae97c1afe1

Coordinate Gaussian second moments and absolute convergence justify finite-sum/series interchange.

$M=\sum_{i}\frac{1}{\lambda_{i}},\qquad\mu_{n}=\sum_{i}\frac{\cos(n\theta_{i})}{\lambda_{i}}.$

## NODE src:A3.SS3.p5

proof_paragraph; raw bytes [889094,894278); SHA256 e57dae4a042d89973d1f77b7f70a1bf71621375d4ee8e72b5e8c768c27502987

Only j=2ad survive; geometric summation gives exact M.

For $M$ , only the terms with $j=2ad$ , $a\geq 1$ , survive. Thus $\displaystyle M$ $\displaystyle=\frac{d}{\sqrt{\kappa}}\left(1+2\sum_{a\geq 1}(-1)^{a}\varrho_{\kappa}^{2ad}\right)$ $\displaystyle=\frac{d}{\sqrt{\kappa}}\left(1-\frac{2\varrho_{\kappa}^{2d}}{1+\varrho_{\kappa}^{2d}}\right)$ $\displaystyle=\frac{d}{\sqrt{\kappa}}\frac{1-\varrho_{\kappa}^{2d}}{1+\varrho_{\kappa}^{2d}}.$

## NODE src:A3.EGx15

reused_display; raw bytes [890009,894271); SHA256 e5b7af2460ec7ef26cc8eaaaa78a47b5a9ad1fd209c14f34d36580cee35fdd50

Only j=2ad survive; geometric summation gives exact M.

$\displaystyle M$ $\displaystyle=\frac{d}{\sqrt{\kappa}}\left(1+2\sum_{a\geq 1}(-1)^{a}\varrho_{\kappa}^{2ad}\right)$ $\displaystyle=\frac{d}{\sqrt{\kappa}}\left(1-\frac{2\varrho_{\kappa}^{2d}}{1+\varrho_{\kappa}^{2d}}\right)$ $\displaystyle=\frac{d}{\sqrt{\kappa}}\frac{1-\varrho_{\kappa}^{2d}}{1+\varrho_{\kappa}^{2d}}.$

## NODE src:A3.SS3.p6

proof_paragraph; raw bytes [894279,906572); SHA256 395f6472942052295639b626445b71635b2404d12479c62eb1b5c0b30bd795fb

Product-to-sum, three disjoint alias classes for 1<=n<d, sign and geometric summation give exact signed mu_n.

For $\mu_{n}$ , we have $\sum_{i}\cos(n\theta_{i})=0$ . Using the product-to-sum identity gives $\mu_{n}=\frac{1}{\sqrt{\kappa}}\sum_{j\geq 1}(-\varrho_{\kappa})^{j}\left[\sum_{i}\cos((j-n)\theta_{i})+\sum_{i}\cos((j+n)\theta_{i})\right].$ The first inner sum is nonzero precisely when $j=n$ or $j=2ad+n$ with $a\geq 1$ ; its value is respectively $d$ or $d(-1)^{a}$ . The second inner sum is nonzero precisely when $j=2ad-n$ with $a\geq 1$ , and then equals $d(-1)^{a}$ . These three classes are disjoint because $1\leq n<d$ . Moreover, $(-\varrho_{\kappa})^{2ad\pm n}=(-1)^{n}\varrho_{\kappa}^{2ad\pm n}$ . Consequently, $\displaystyle(-1)^{n}\mu_{n}$ $\displaystyle=\frac{d}{\sqrt{\kappa}}\left[\varrho_{\kappa}^{n}+\sum_{a\geq 1}(-1)^{a}\left(\varrho_{\kappa}^{2ad+n}+\varrho_{\kappa}^{2ad-n}\right)\right]$ $\displaystyle=\frac{d}{\sqrt{\kappa}}\left[\varrho_{\kappa}^{n}-\frac{\varrho_{\kappa}^{2d+n}+\varrho_{\kappa}^{2d-n}}{1+\varrho_{\kappa}^{2d}}\right]$ $\displaystyle=\frac{d}{\sqrt{\kappa}}\frac{\varrho_{\kappa}^{n}-\varrho_{\kappa}^{2d-n}}{1+\varrho_{\kappa}^{2d}}.$ ∎

## NODE src:A3.Ex144

reused_display; raw bytes [895184,897287); SHA256 7e778304af58747c9321437e8b821d10d9117296161f294936b6206df22689e9

Product-to-sum, three disjoint alias classes for 1<=n<d, sign and geometric summation give exact signed mu_n.

$\mu_{n}=\frac{1}{\sqrt{\kappa}}\sum_{j\geq 1}(-\varrho_{\kappa})^{j}\left[\sum_{i}\cos((j-n)\theta_{i})+\sum_{i}\cos((j+n)\theta_{i})\right].$

## NODE src:A3.EGx16

reused_display; raw bytes [901217,906474); SHA256 5e18d2b1be6be13a7680cacc8647ea7a331fbff779f5216fc672b41e25de866e

Product-to-sum, three disjoint alias classes for 1<=n<d, sign and geometric summation give exact signed mu_n.

$\displaystyle(-1)^{n}\mu_{n}$ $\displaystyle=\frac{d}{\sqrt{\kappa}}\left[\varrho_{\kappa}^{n}+\sum_{a\geq 1}(-1)^{a}\left(\varrho_{\kappa}^{2ad+n}+\varrho_{\kappa}^{2ad-n}\right)\right]$ $\displaystyle=\frac{d}{\sqrt{\kappa}}\left[\varrho_{\kappa}^{n}-\frac{\varrho_{\kappa}^{2d+n}+\varrho_{\kappa}^{2d-n}}{1+\varrho_{\kappa}^{2d}}\right]$ $\displaystyle=\frac{d}{\sqrt{\kappa}}\frac{\varrho_{\kappa}^{n}-\varrho_{\kappa}^{2d-n}}{1+\varrho_{\kappa}^{2d}}.$

## NODE src:A3.SS3.p7

proof_paragraph; raw bytes [906979,907380); SHA256 3a6686a2561d5fc72b13663b5959b042e24e5008497bcf483ced7a3ae29e77eb

Lemma 4.5 explicitly consumes C.8 for both means.

Fact C.8 gives the two asserted means.

## NODE src:A3.SS3.p8

proof_paragraph; raw bytes [907381,914571); SHA256 5236e15340dd6ba9f9d5727a1e53f702ab4fc32d994c3044a6dce05be41b300b

Independent diagonal coordinates, Gaussian fourth moments and lambda_i>=1 give both variances <=2M; exact M<=d/sqrt(kappa).

Variance bounds. Since $\Lambda$ is diagonal, the coordinates of $U$ are independent. Each $U_{i}$ is centered Gaussian with variance $1/\lambda_{i}$ , so $\mathbb{E}U_{i}^{4}=3/\lambda_{i}^{2}$ and $\operatorname{Var}(U_{i}^{2})=2/\lambda_{i}^{2}$ . Also, $\lambda_{i}\geq(\kappa+1)/2-(\kappa-1)/2=1$ . Hence $\displaystyle\operatorname{Var}(\|U\|^{2})$ $\displaystyle=2\sum_{i}\frac{1}{\lambda_{i}^{2}}\leq 2\sum_{i}\frac{1}{\lambda_{i}}=2M,$ $\displaystyle\operatorname{Var}(U^{\top}D_{n}U)$ $\displaystyle=2\sum_{i}\frac{\cos^{2}(n\theta_{i})}{\lambda_{i}^{2}}\leq 2M.$ The exact formula for $M$ gives $M\leq d/\sqrt{\kappa}$ .

## NODE src:A3.EGx17

reused_display; raw bytes [910223,913956); SHA256 0ad7d31d4bc68064192220935a81d971d6f629b9eaacf34a411a330e8c28eda8

Independent diagonal coordinates, Gaussian fourth moments and lambda_i>=1 give both variances <=2M; exact M<=d/sqrt(kappa).

$\displaystyle\operatorname{Var}(\|U\|^{2})$ $\displaystyle=2\sum_{i}\frac{1}{\lambda_{i}^{2}}\leq 2\sum_{i}\frac{1}{\lambda_{i}}=2M,$ $\displaystyle\operatorname{Var}(U^{\top}D_{n}U)$ $\displaystyle=2\sum_{i}\frac{\cos^{2}(n\theta_{i})}{\lambda_{i}^{2}}\leq 2M.$

## NODE src:A3.SS3.p9

proof_paragraph; raw bytes [914572,919931); SHA256 34a55f3f00fc270ebec97c75ac221de7bf6d91325c88d78ec9af7c444ea30df4

n<d gives positive signed mu_n and literal normalized-bias ratio with bounding fraction.

Normalized bias. Since $n<d$ and $0<\varrho_{\kappa}<1$ , we have $\varrho_{\kappa}^{n}>\varrho_{\kappa}^{2d-n}$ . Thus $(-1)^{n}\mu_{n}>0$ , and dividing the two moment formulas yields $\frac{|\mu_{n}|}{M}=\varrho_{\kappa}^{n}\frac{1-\varrho_{\kappa}^{2(d-n)}}{1-\varrho_{\kappa}^{2d}}.$ Because $0<\varrho_{\kappa}^{2d}<\varrho_{\kappa}^{2(d-n)}<1$ , the fraction satisfies $1-\varrho_{\kappa}^{2(d-n)}\leq\frac{1-\varrho_{\kappa}^{2(d-n)}}{1-\varrho_{\kappa}^{2d}}\leq 1.$

## NODE src:A3.Ex150

reused_display; raw bytes [916341,917708); SHA256 823df5cc5def4d897c21ba303b5c36c71ea5eeb73f1a59d817495e8c747ab2f0

n<d gives positive signed mu_n and literal normalized-bias ratio with bounding fraction.

$\frac{|\mu_{n}|}{M}=\varrho_{\kappa}^{n}\frac{1-\varrho_{\kappa}^{2(d-n)}}{1-\varrho_{\kappa}^{2d}}.$

## NODE src:A3.Ex151

reused_display; raw bytes [918518,919924); SHA256 f596bb57d1fc55db5822730aed4ff22d26e59eba2f2578cc2e1348397493e3f2

n<d gives positive signed mu_n and literal normalized-bias ratio with bounding fraction.

$1-\varrho_{\kappa}^{2(d-n)}\leq\frac{1-\varrho_{\kappa}^{2(d-n)}}{1-\varrho_{\kappa}^{2d}}\leq 1.$

## NODE src:A3.SS3.p10

proof_paragraph; raw bytes [919932,929821); SHA256 53b1101c24a5c0cf14013292068a3dcfd761eb63b1d6c65af86c791901e2eae0

Integral formula and kappa>=2 bound log(1/rho) between 2/sqrt(kappa) and 3/sqrt(kappa); exponentiation.

To bound the powers of $\varrho_{\kappa}$ , observe that $\displaystyle\log\frac{1}{\varrho_{\kappa}}$ $\displaystyle=\log\frac{\sqrt{\kappa}+1}{\sqrt{\kappa}-1}$ $\displaystyle=2\int_{0}^{1/\sqrt{\kappa}}\frac{dt}{1-t^{2}}$ $\displaystyle=\frac{2}{\sqrt{\kappa}}+2\int_{0}^{1/\sqrt{\kappa}}\frac{t^{2}}{1-t^{2}}\,dt.$ The last integral is nonnegative, giving $\log(1/\varrho_{\kappa})\geq 2/\sqrt{\kappa}$ . Throughout the integration interval, $1-t^{2}\geq 1-\kappa^{-1}$ , so $\displaystyle\log\frac{1}{\varrho_{\kappa}}$ $\displaystyle\leq\frac{2}{\sqrt{\kappa}}+\frac{2}{1-\kappa^{-1}}\int_{0}^{1/\sqrt{\kappa}}t^{2}\,dt$ $\displaystyle=\frac{2}{\sqrt{\kappa}}\left(1+\frac{1}{3(\kappa-1)}\right)\leq\frac{8}{3\sqrt{\kappa}}<\frac{3}{\sqrt{\kappa}}.$ Here we used $\kappa\geq 2$ . Exponentiating these bounds gives $e^{-3n/\sqrt{\kappa}}\leq\varrho_{\kappa}^{n}\leq e^{-2n/\sqrt{\kappa}}.$

## NODE src:A3.EGx18

reused_display; raw bytes [920337,924017); SHA256 98b1bbdc32f7c2ad38c63c6f0b3272ae00dcd6620138bbbc5a4a4f2d0c25062c

Integral formula and kappa>=2 bound log(1/rho) between 2/sqrt(kappa) and 3/sqrt(kappa); exponentiation.

$\displaystyle\log\frac{1}{\varrho_{\kappa}}$ $\displaystyle=\log\frac{\sqrt{\kappa}+1}{\sqrt{\kappa}-1}$ $\displaystyle=2\int_{0}^{1/\sqrt{\kappa}}\frac{dt}{1-t^{2}}$ $\displaystyle=\frac{2}{\sqrt{\kappa}}+2\int_{0}^{1/\sqrt{\kappa}}\frac{t^{2}}{1-t^{2}}\,dt.$

## NODE src:A3.EGx19

reused_display; raw bytes [925117,928433); SHA256 be9b5b015e1c3b3e2de27f1427a8b9c4d83335751d3e94e2eda17d5a740d4bb9

Integral formula and kappa>=2 bound log(1/rho) between 2/sqrt(kappa) and 3/sqrt(kappa); exponentiation.

$\displaystyle\log\frac{1}{\varrho_{\kappa}}$ $\displaystyle\leq\frac{2}{\sqrt{\kappa}}+\frac{2}{1-\kappa^{-1}}\int_{0}^{1/\sqrt{\kappa}}t^{2}\,dt$ $\displaystyle=\frac{2}{\sqrt{\kappa}}\left(1+\frac{1}{3(\kappa-1)}\right)\leq\frac{8}{3\sqrt{\kappa}}<\frac{3}{\sqrt{\kappa}}.$

## NODE src:A3.Ex157

reused_display; raw bytes [928814,929814); SHA256 f78f871ac598114d5edee3ce5526d4ce9ffcfbd1e851f0acb6c6051f191fef02

Integral formula and kappa>=2 bound log(1/rho) between 2/sqrt(kappa) and 3/sqrt(kappa); exponentiation.

$e^{-3n/\sqrt{\kappa}}\leq\varrho_{\kappa}^{n}\leq e^{-2n/\sqrt{\kappa}}.$

## NODE src:A3.SS3.p11

proof_paragraph; raw bytes [929822,934746); SHA256 b5a4e86316ba00a556e34d09f48b40cd000d3be0364b2c79c8355ee47f47ebb8

Extra d-n>=sqrt(kappa) gives rho tail<=e^-4 and two-sided normalized bias bound.

If $d-n\geq\sqrt{\kappa}$ , the lower bound on $\log(1/\varrho_{\kappa})$ also gives $\varrho_{\kappa}^{2(d-n)}=\exp\!\left(-2(d-n)\log\frac{1}{\varrho_{\kappa}}\right)\leq e^{-4(d-n)/\sqrt{\kappa}}\leq e^{-4}.$ Consequently, $(1-e^{-4})\varrho_{\kappa}^{n}\leq|\mu_{n}|/M\leq\varrho_{\kappa}^{n}$ . Combining this with the bounds on $\varrho_{\kappa}^{n}$ proves $(1-e^{-4})e^{-3n/\sqrt{\kappa}}\leq\frac{|\mu_{n}|}{M}\leq e^{-2n/\sqrt{\kappa}}.$ ∎

## NODE src:A3.Ex158

reused_display; raw bytes [930686,932260); SHA256 8c692dacbc3eeed8c30090f1f3f0155143ac096d3d7ef80d81e86c17ca248dc0

Extra d-n>=sqrt(kappa) gives rho tail<=e^-4 and two-sided normalized bias bound.

$\varrho_{\kappa}^{2(d-n)}=\exp\!\left(-2(d-n)\log\frac{1}{\varrho_{\kappa}}\right)\leq e^{-4(d-n)/\sqrt{\kappa}}\leq e^{-4}.$

## NODE src:A3.Ex159

reused_display; raw bytes [933465,934646); SHA256 4bdcc9c5eceaf3da391eee1a2738793d602eed1ddafd6f9f2243a83219f1232e

Extra d-n>=sqrt(kappa) gives rho tail<=e^-4 and two-sided normalized bias bound.

$(1-e^{-4})e^{-3n/\sqrt{\kappa}}\leq\frac{|\mu_{n}|}{M}\leq e^{-2n/\sqrt{\kappa}}.$
