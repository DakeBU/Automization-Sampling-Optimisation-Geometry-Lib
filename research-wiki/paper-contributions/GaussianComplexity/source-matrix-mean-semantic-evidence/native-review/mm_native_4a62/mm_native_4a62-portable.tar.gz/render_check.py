#!/usr/bin/env python3
"""Execute bounded production renderer functions against exact isolated inputs."""
import ast,sys,os,json,hashlib,re,posixpath
from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import urlsplit
OWN=Path(__file__).resolve().parent
CODE=OWN/'renderer-code';OUTPUT=OWN/'rendered'
sys.path[:0]=[str(CODE/'website/scripts'),str(CODE/'tools')]
import astis_site as base
import declaration_lessons as lessons
import publication_reader as reader
import inline_lean
import astis_publication as publication
CANDIDATE='5fb1440f771bdae77ad31f27b2275447fe3e89e5'
sha=lambda b:hashlib.sha256(b).hexdigest()
def save(name,x):
    p=OWN/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
class Node:
    def __init__(self,tag='',attrs=()):self.tag=tag;self.attrs=dict(attrs);self.children=[]
    def text(self):return ''.join(c.text() if isinstance(c,Node) else c for c in self.children)
    def all(self,tag=None,cls=None):
        found=[]
        if (tag is None or tag==self.tag) and (cls is None or cls in self.attrs.get('class','').split()):found.append(self)
        for c in self.children:
            if isinstance(c,Node):found.extend(c.all(tag,cls))
        return found
class DOM(HTMLParser):
    def __init__(self,s):
        super().__init__(convert_charrefs=True);self.root=Node();self.stack=[self.root];self.feed(s)
    def handle_starttag(self,t,a):
        n=Node(t,a);self.stack[-1].children.append(n)
        if t not in {'meta','link','br','hr','img','input','source','wbr','area','base','embed','param','track'}:self.stack.append(n)
    def handle_endtag(self,t):
        for i in range(len(self.stack)-1,0,-1):
            if self.stack[i].tag==t:self.stack=self.stack[:i];break
    def handle_data(self,s):self.stack[-1].children.append(s)
def exact_pre(n,expected):
    pres=n.all('pre');assert len(pres)==1,len(pres)
    assert pres[0].text()==expected,(pres[0].text()[:100],expected[:100])
def write(rel,s):
    p=OUTPUT/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s)
modules,decls=base.scan_project_sources()
known={d.full_name:d for d in decls}
base._SOURCE_BY_NAME=known;base._ALL_MODULES=modules
base._ACTIVE_GATE=base.GateEvidence(False,False,CANDIDATE,'','',[],'Bounded static verifier; aggregate gate not supplied')
base._ACTIVE_GIT=base.GitContext(CANDIDATE,'bounded-static-preview','','',False,False,set())
unit=lessons.load_units()[0]
item=json.loads((CODE/'website/content/publications/huanjian-gaussian-source-matrix-mean.json').read_text())['items'][0]
assert item['statement']==unit['statement'] and item['assumptions']==unit['assumptions']
name=unit['declaration'];P=known[name].source_file;T=unit['sources'][1]['path']
page=lessons.lesson_path(name)
lesson_html=lessons.render_unit(unit,page)
write(page,base.page(unit['title'],page,lesson_html))
# Provide only bounded authored inputs. Empty cells/audits deliberately confer no status credit.
publication.inputs=lambda:{'lessons':{name:unit},'declarations':known,'cells':{},'audits':{}}
pub_html=reader.source_card(item,item['chapter_path'])
write(item['chapter_path'],base.page(item['title'],item['chapter_path'],pub_html))
# The canonical-shell dependency requires a theme carrier. This is an explicit
# minimal bounded fixture, not an existing/full-site or visual-review claim.
write('textbook/index.html','<!doctype html><html><head><link rel="stylesheet" href="../assets/site.css"><link rel="stylesheet" href="../assets/information-architecture.css"></head><body></body></html>')
lessons.export_sources(OUTPUT,[unit])
# Execute the exact production build_site AST loop responsible for module
# downloads and module HTML, with only the bounded seven modules as its input.
tree=ast.parse((CODE/'tools/astis_site.py').read_text())
func=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='build_site')
loop=next(n for n in func.body if isinstance(n,ast.For) and isinstance(n.target,ast.Name) and n.target.id=='module'
          and any(isinstance(c,ast.Name) and c.id=='source_download' for c in ast.walk(n)))
production_loop=ast.get_source_segment((CODE/'tools/astis_site.py').read_text(),loop)
(OWN/'production-module-export-loop.py.txt').write_text(production_loop+'\n')
from collections import defaultdict
reverse=defaultdict(list)
for m in modules:
    for imp in m.imports:reverse[imp].append(m.name)
namespace=dict(vars(base));namespace.update({'modules':modules,'output':OUTPUT,'reverse_imports':reverse})
exec(compile(ast.Module(body=[loop],type_ignores=[]),'production-build_site-module-loop','exec'),namespace)
checks={}
for label,html in [('lesson',lesson_html),('publication',pub_html)]:
    doc=DOM(html).root
    details=doc.all('details')
    assert details and not any('open' in n.attrs for n in details)
    steps=doc.all('details','proof-reader-step');assert len(steps)==6
    for i,(step,authored) in enumerate(zip(steps,unit['steps']),1):
        assert authored['title'] in step.text()
        assert lessons.inline_text(authored['text']) in html
        assert authored['formula'] in step.text()
        lean=[x for x in step.all('details') if x is not step and x.all('summary') and x.all('summary')[0].text()=='Corresponding Lean step']
        assert len(lean)==1;exact_pre(lean[0],authored['lean'])
    first=doc.all('section','reader-first-pass');assert len(first)==1
    assert unit['formula'] in first[0].text()
    assert len(first[0].all('pre'))==1
    assert 'Actual truncated matrix' not in first[0].all('pre')[0].text() # exact Lean rather than authored prose
    for assumption in unit['assumptions']:assert lessons.inline_text(assumption) in html
    statement=doc.all('details','inline-lean-statement');proof=doc.all('details','inline-lean-proof')
    assert len(statement)==1 and len(proof)==1
    p_lines=(CODE/P).read_text().splitlines(keepends=True)
    exact_pre(statement[0],''.join(p_lines[16:43]).rstrip())
    exact_pre(proof[0],''.join(p_lines[16:]).rstrip())
    checks[label]={'all_details_initially_closed':len(details),'source_ordered_proof_folds':6,
      'all_authored_steps_formulae_assumptions_and_exact_lean_present':True,
      'exact_adjacent_P_statement_L17_43':True,'exact_complete_P_proof_L17_120':True,
      'compact_first_pass':True}
pubdoc=DOM(pub_html).root
for formula in item['formulae']:assert formula['tex'] in pubdoc.text()
for rel,bounds in [(P,[(45,78),(79,89),(90,118)]),(T,[(1,110),(111,143),(144,158)])]:
    lines=(CODE/rel).read_text().splitlines(keepends=True)
    selected=unit['steps'][:3] if rel==P else unit['steps'][3:]
    assert [step['lean'] for step in selected]==[''.join(lines[a-1:b]) for a,b in bounds]
    assert ''.join(s['lean'] for s in selected)==''.join(lines[bounds[0][0]-1:bounds[-1][1]])
    downloaded=OUTPUT/'downloads/lean'/rel
    assert downloaded.read_bytes()==(CODE/rel).read_bytes()
    module=next(m for m in modules if m.source_file==rel)
    module_rel='modules/'+base.slugify(module.name)+'.html'
    md=DOM((OUTPUT/module_rel).read_text()).root
    complete=next(n for n in md.all('section') if n.attrs.get('id')=='complete-module-source')
    exact_pre(complete,(CODE/rel).read_text())
    assert not any('open' in n.attrs for n in complete.all('details'))
    if rel==T:
        source_rel='data/lesson-sources/'+rel+'.html'
        sd=DOM((OUTPUT/source_rel).read_text()).root
        spans=[n for n in sd.all('span') if re.fullmatch(r'L\d+',n.attrs.get('id',''))]
        assert len(spans)==158 and [n.attrs['id'] for n in spans]==['L'+str(i) for i in range(1,159)]
        assert '\n'.join(n.text() for n in spans)+'\n'==(CODE/rel).read_text()
        assert spans[16].text()=='private theorem actual_source_truncated_sum_means'
    checks[rel]={'download_bytes':len(downloaded.read_bytes()),'download_sha256':sha(downloaded.read_bytes()),
      'exact_complete_module_code':True,'progressive_lean_ranges':bounds,'ranges_contiguous':True}
# Check actual local href targets for bounded source/module/download anchors.
link_checks=[]
for rel,html in [(page,lesson_html),(item['chapter_path'],pub_html)]:
    for a in DOM(html).root.all('a'):
        href=a.attrs.get('href','');u=urlsplit(href)
        if u.scheme or not any(s in u.path for s in ['data/lesson-sources/','downloads/lean/','modules/']):continue
        target=posixpath.normpath(posixpath.join(posixpath.dirname(rel),u.path))
        assert (OUTPUT/target).is_file(),(rel,href,target)
        if u.fragment:
            targetdoc=DOM((OUTPUT/target).read_text()).root
            assert any(n.attrs.get('id')==u.fragment for n in targetdoc.all()),(target,u.fragment)
        link_checks.append({'from':rel,'href':href,'target':target,'fragment_exists':True})
closure=json.loads((OWN/'renderer-python-closure.json').read_text())
runtime=[]
for name,mod in list(sys.modules.items()):
    file=getattr(mod,'__file__',None)
    if not file:continue
    p=Path(file).resolve()
    if p.is_relative_to(CODE):
        assert name in closure['modules'],name
        assert sha(p.read_bytes())==closure['modules'][name]['sha256']
        runtime.append(name)
    elif p.is_relative_to(OWN.parents[2]) and not p.is_relative_to(OWN):
        raise AssertionError('Nonisolated repo Python import '+str(p))
save('bounded-rendering.json',{'candidate':CANDIDATE,'production_functions':['declaration_lessons.render_unit','declaration_lessons.export_sources','astis_site.render_source_module','publication_reader.source_card'],
    'module_download_export':'Exact production ast.For loop extracted and executed from astis_site.build_site',
    'theme_carrier':'Explicit minimal theme fixture only; no fullsite or visual credit',
    'status_inputs':'Empty cells and audits; no verdict or gate credit imported',
    'checks':checks,'local_source_module_download_links':link_checks,
    'runtime_local_imports':sorted(runtime),'python_static_closure_count':closure['count'],
    'nonclaims':['browser','mobile','MathJax rendering','copy interaction','download interaction','global source index','graph','fullsite','deployment','Goal']})
print('BOUNDED STATIC PASS',len(checks),'checks',len(link_checks),'local links',len(runtime),'runtime modules')
