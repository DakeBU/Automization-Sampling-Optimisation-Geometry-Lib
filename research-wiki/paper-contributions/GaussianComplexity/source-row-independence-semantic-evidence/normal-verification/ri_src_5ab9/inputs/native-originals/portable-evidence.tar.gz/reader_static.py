"""Bounded calls to the exact production renderer, static DOM and source checks."""
import html,json,pathlib,re,sys
from html.parser import HTMLParser
from run import ROOT,REPO,sha
I=ROOT/'inputs';m=json.loads((ROOT/'input-manifest.json').read_text())
sys.path[:0]=[str(I/'tools'),str(I/'website/scripts')]
import astis_site as base,declaration_lessons as lessons,inline_lean,astis_publication as pub
u=json.loads((I/'website/content/declaration_lessons/huanjian-gaussian-source-row-independence.json').read_text())['units'][0]
item=json.loads((I/'website/content/publications/huanjian-gaussian-source-row-independence.json').read_text())['items'][0]
base.ROOT=lessons.ROOT=pub.ROOT=I
base.project_lean_paths=lambda:[I/p for p in m['modules']]
mods,decls=base.scan_project_sources();known={d.full_name:d for d in decls}
base._SOURCE_BY_NAME=known;base._ALL_MODULES=mods;inline_lean.declarations.cache_clear()
base._ACTIVE_GIT=base.GitContext(commit=m['candidate_commit'],ref='independent-row-independence-frozen-native',remote_url='',web_root='',commit_published=False,public_source_links=False,dirty_files=set())
base._ACTIVE_GATE=base.GateEvidence(passed=False,current=False,commit=m['candidate_commit'],source_digest='',generated_at='',commands=[],note='Bounded native evidence separate. Aggregate gate not asserted.')
binding=pub.binding_digest(item,item['bindings'][0],{'declarations':known,'lessons':{u['declaration']:u}})
assert binding==json.loads((I/m['E']/'publication-draft-record.json').read_text())['publication_binding_sha256']
page='proofs/source-'+item['id']+'.html';body=lessons.render_unit(u,page)
out=ROOT/'reader';target=out/page;target.parent.mkdir(parents=True,exist_ok=True);target.write_text(base.page(u['title'],page,body))
class Node:
    def __init__(self,tag,attrs,parent=None):self.tag=tag;self.attrs=dict(attrs);self.parent=parent;self.children=[];self.parts=[]
    def all(self,t):return ([self] if self.tag==t else [])+[z for c in self.children for z in c.all(t)]
    def text(self):return ''.join(p if isinstance(p,str) else p.text() for p in self.parts)
class Parse(HTMLParser):
    def __init__(self):super().__init__();self.root=Node('root',[]);self.stack=[self.root]
    def handle_starttag(self,t,a):
        n=Node(t,a,self.stack[-1]);self.stack[-1].children.append(n);self.stack[-1].parts.append(n)
        if t not in {'meta','link','br','hr','input','img','source','area','base','embed','param','track','wbr'}:self.stack.append(n)
    def handle_endtag(self,t):
        for i in range(len(self.stack)-1,0,-1):
            if self.stack[i].tag==t:self.stack=self.stack[:i];break
    def handle_data(self,d):self.stack[-1].parts.append(d)
def parse(s):
    p=Parse();p.feed(s);return p.root
p=parse(body);assert all('open' not in n.attrs for n in p.all('details'))
steps=[n for n in p.all('details') if 'reader-proof-disclosure' in n.attrs.get('class','').split()]
assert len(steps)==len(u['steps'])==6
expected=[(m['P'],21,57),(m['P'],59,77),(m['P'],78,86),(m['P'],88,96),(m['T'],1,59),(m['T'],61,81)]
receipts=[]
for i,(node,s,(path,a,b)) in enumerate(zip(steps,u['steps'],expected),1):
    div=next(n for n in node.children if n.tag=='div');folds=div.all('details');assert len(folds)==1
    code=folds[0].all('code');assert len(code)==1 and code[0].text()==s['lean']
    assert div.children[0].tag=='p' and div.children[1].tag=='div' and div.children[2] is folds[0]
    assert div.children[0].text()==parse(lessons.inline_text(s['text'])).text()
    assert div.children[1].text()=='\\['+s['formula']+'\\]'
    raw=(I/path).read_text();assert s['lean']==''.join(raw.splitlines(keepends=True)[a-1:b])
    assert raw.count(s['lean'])==1
    receipts.append({'step':i,'file':path,'LF_lines':[a,b],'sha256':sha(s['lean'].encode()),'exact_adjacent_formula_and_Lean':True,'initially_closed':True})
private=(I/m['T']).read_bytes();assert len(private.splitlines())==81
assert (u['steps'][4]['lean']+'\n'+u['steps'][5]['lean']).encode()==private
assert private.decode().splitlines()[59]==''
consumer=next(d for d in decls if d.short_name=='actual_truncated_matrices_measurable_and_independent');assert consumer.source_line==11
assert item['statement']==u['statement'] and item['assumptions']==u['assumptions']
assert item['formulae'][0]['tex']==u['formula']
for f in item['formulae']:assert f['tex'] in body
old='AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumSourceRowLaw.actual_source_row_marginal_law'
assert u['astis_dependencies']==[old]
assert 'actual private consumer uses this new independence producer and that same row-law node' in u['dependency_notes']
assert 'ProbabilityTheory.map_pi_eq_stdGaussian' in u['mathlib_dependencies']
assert 'MeasureTheory.Measure.infinitePi_eq_pi' in u['mathlib_dependencies']
assert 'ProbabilityTheory.iIndepFun.comp' in u['mathlib_dependencies']
theme=(REPO/'_site/textbook/index.html').read_bytes();d=out/'textbook/index.html';d.parent.mkdir(exist_ok=True);d.write_bytes(theme)
(I/'theme-reference.html').write_bytes(theme)
lessons.export_sources(out,[u])
for mod in mods:
    path=out/'modules'/(base.slugify(mod.name)+'.html');path.parent.mkdir(exist_ok=True);path.write_text(base.render_source_module(mod,[]))
    download=out/'downloads/lean'/mod.source_file;download.parent.mkdir(parents=True,exist_ok=True);download.write_bytes((I/mod.source_file).read_bytes())
    section=next(n for n in parse(path.read_text()).all('section') if n.attrs.get('id')=='complete-module-source')
    assert section.all('code')[-1].text()==(I/mod.source_file).read_text()
    assert download.read_bytes()==(I/mod.source_file).read_bytes()
links=[n.attrs.get('href','') for n in p.all('a')];local=[x for x in links if 'data/lesson-sources/' in x]
assert len(local)==1 and local[0].endswith('.lean.html#L11')
checked=[]
for l in [x for x in links if any(k in x for k in ['downloads/lean/','modules/','data/lesson-sources/'])]:
    dest=(target.parent/l.split('#')[0]).resolve();assert dest.is_relative_to(out) and dest.exists(),l
    if '#' in l:assert 'id="'+l.split('#')[1]+'"' in dest.read_text(),l
    checked.append(l)
exports=out/'data/lesson-sources'/m['T'];sp=parse(exports.with_suffix('.lean.html').read_text())
numbered={n.attrs['id']:n for n in sp.all('span') if n.attrs.get('id','').startswith('L')}
assert len(numbered)==81 and numbered['L11'].text().startswith('private theorem actual_truncated_matrices_measurable_and_independent')
assert ('\n'.join(numbered['L'+str(i)].text() for i in range(1,82))+'\n').encode()==private
result={'candidate_commit':m['candidate_commit'],'binding_sha256':binding,'six_steps':receipts,'all_details_initially_closed':True,'private_export_exact_81_lines':True,'original_separator_blank_line':60,'private_source_link_line':11,'actual_production_calls':['render_unit','export_sources','render_source_module'],'local_links_and_anchors_checked':checked,'all_formulas_present':True,'ASTIS_vs_Mathlib_dependency_distinction_present':True,'page':str(target.relative_to(ROOT)),'page_sha256':sha(target.read_bytes()),'theme_reference_sha256':sha(theme),'scope':'Bounded static output only. Download files materialized and byte-compared; no interactive click claim.','HOLD':['browser desktop/mobile','MathJax layout','clipboard runtime','interactive download runtime','fullsite/globalgraph','root Tests/fullrepo','source-fidelity verdict','publication/integration/purification']}
(ROOT/'reader-static.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
