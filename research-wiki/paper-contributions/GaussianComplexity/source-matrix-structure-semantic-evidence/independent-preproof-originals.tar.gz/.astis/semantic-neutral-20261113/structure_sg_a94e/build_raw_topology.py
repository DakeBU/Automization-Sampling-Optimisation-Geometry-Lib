from pathlib import Path
import datetime, hashlib, json, re, bisect

OUT=Path(__file__).resolve().parent
s=(OUT/'original.2610.20492v1.html.RAW').read_text()
allblocks=sum([json.loads((OUT/f'{k}-raw-blocks.v2.json').read_text()) for k in ['s4','c2']],[])
byid={x['id']:x for x in allblocks}
starts=[0]+[m.end() for m in re.finditer('\n',s)]
def loc(a,z):
    return {'char_start':a,'char_end_exclusive':z,'byte_start':len(s[:a].encode()),'byte_end_exclusive':len(s[:z].encode()),
            'line_start_1based':bisect.bisect_right(starts,a),'line_end_1based':bisect.bisect_right(starts,max(a,z-1)),
            'raw_sha256':hashlib.sha256(s[a:z].encode()).hexdigest()}
def refs(ids): return [{'source_id':i,**{k:v for k,v in byid[i].items() if k not in ['id','tag','text']}} for i in ids]
nodes=[]
def node(i,kind,statement,ids,**kw): nodes.append({'id':i,'kind':kind,'statement':statement,'source_anchors':refs(ids),**kw})
node('regime','standing-source','Integers d,q with q>=0 and 2q+1<d; independent columns g_a~N(0,I_d), a=1..q+1.', ['S4.Thmtheorem4.p1.1'])
node('grid','literal-definition','theta_i=(i-1/2)pi/d; deterministic finite cosine grid.', ['S4.SS1.p1.1','S4.E11'])
node('dimensions','literal-definition','r=q+1, n=2q+1; r>0,d>=2 follow internally; q=0 is included.', ['A3.SS2.p1.1'])
node('rows-and-basis','literal-definition','gamma_i=((g_1)_i,...,(g_r)_i), t_i=(1,sqrt(2)cos(theta_i),...,sqrt(2)cos(q theta_i)); B row d^(-1/2)(gamma_i tensor t_i)^T.', ['A3.Ex85','A3.SS2.p1.2'])
node('row-law','source-assertion','The gamma_i are independent N(0,I_r).', ['A3.SS2.p1.2'])
node('cutoff','literal-definition','L=2r+3 log(1000d), R_i=||gamma_i||^2; cutoff event is the literal closed condition R_i<=L.', ['A3.SS2.p10.1','A3.Ex107'])
node('Y','literal-definition','Y_i=(1/d)(gamma_i gamma_i^T tensor t_i t_i^T) 1_{R_i<=L}.', ['A3.SS2.p12.1','A3.Ex107'])
node('radial-mean','source-assertion','E[gamma_i gamma_i^T 1_{R_i<=L}]=a I_r; a=(1/r)E[R_i 1_{R_i<=L}] and a is independent of i.', ['A3.SS2.p12.2','A3.Ex108','A3.SS2.p12.3'])
node('actual-mean','source-assertion','E_mu Y_i=(a/d)(I_r tensor t_i t_i^T); E is actual expectation under the original experiment.', ['A3.SS2.p12.4'])
node('Z','literal-definition','Z_i=Y_i-E_mu Y_i, with same original mu; no surrogate or newly conditioned law.', ['A3.SS2.p13.1'])
node('weighted-Z','literal-definition','W_i=cos(n theta_i) Z_i; multiplier is a deterministic real scalar from q,d,i.', ['A3.SS2.p13.3','A3.SS2.p14.6','A3.Ex120'])
node('structure','target-source-assertion','Each of (Z_i)_i and (W_i)_i separately consists of independent, centered, self-adjoint matrices.', ['A3.SS2.p15.1'],
     caution='No assertion of joint independence for the union of the two families. No Bernstein bound is included.')
gaps=[
('gap-column-to-row','From the joint independent standard Gaussian column experiment derive all-coordinate product law, then measurable regrouping yields independent standard Gaussian rows. Do not replace experiment by an independent-row caller certificate.',['A3.SS2.p1.2']),
('gap-measurable-Y','Prove R_i and the outer-product/tensor matrix coordinate functions measurable; {R_i<=L} is a closed measurable cutoff; deterministic d,L,t_i; hence Y_i is a measurable finite-dimensional matrix-valued function of gamma_i.',['A3.Ex107']),
('gap-integrable-Y','Prove true Bochner integrability under the same probability mu. Cutoff yields bounded entries (|gamma_a gamma_b|<=R_i<=L on support) and finite dimension; alternatively Gaussian second moments dominate entries. Do not rely on totalized integral zero in the nonintegrable branch.',['A3.Ex107','A3.SS2.p12.4']),
('gap-actual-mean-transport','Prove coordinate integration equals the finite-dimensional actual matrix Bochner integral and transport the Gaussian row marginal to original mu before using a radial formula.',['A3.SS2.p12.4']),
('gap-Y-Hermitian','Outer products of real vectors are symmetric; tensor products, real scalar division and closed indicator preserve symmetry. Establish pointwise Y_i^*=Y_i.',['A3.Ex107']),
('gap-mean-Hermitian-integral','Integrability plus pointwise symmetry permits coordinate integral/transposition interchange, giving (E_mu Y_i)^*=E_mu Y_i directly. This is an expansion route; radial isotropy is unnecessary for it.',['A3.SS2.p12.4']),
('gap-mean-Hermitian-radial','The source radial formula gives E_mu Y_i=(a/d)(I_r tensor t_i t_i^T), hence symmetry. This is an alternative sufficient route to the same mean-Hermitian fact.',['A3.Ex108','A3.SS2.p12.4']),
('gap-centering','Once Y_i is Bochner integrable and mu is a probability measure, subtract its actual constant mean: Z_i is integrable and E_mu Z_i=E_mu Y_i-E_mu Y_i=0.',['A3.SS2.p13.1','A3.SS2.p15.1']),
('gap-independence-transform','Apply independence preservation under measurable per-index maps gamma_i -> Y_i -> Y_i-E_mu Y_i. The means are deterministic matrices under fixed original mu.',['A3.SS2.p12.1','A3.SS2.p13.1','A3.SS2.p15.1']),
('gap-weighted-transfer','For deterministic real w_i=cos((2q+1)theta_i), per-index multiplication preserves independence, true integrability/zero mean, and self-adjointness. The scalar |w_i|<=1 is only needed downstream for bounds, not structural transfer.',['A3.SS2.p13.3','A3.SS2.p15.1']),
]
for i,st,ids in gaps: node(i,'SOURCE_GAP',st,ids,classification='internal-paper-step',status='unproved internal obligation; never a caller certificate')
edges=[]
def edge(i,p,c,use,why,logic='AND'):
    edges.append({'id':i,'prerequisites':p,'consumer':c,'logic':logic,'consumer_use_site':refs(use),'discharge':why})
edge('e01',['regime','dimensions','rows-and-basis'],'gap-column-to-row',['A3.SS2.p1.2'],'Column coordinates are independent standard normals, and disjoint coordinate rows are measurably grouped.')
edge('e02',['gap-column-to-row'],'row-law',['A3.SS2.p1.2'],'Supply the asserted row law from the original columns.')
edge('e03',['row-law','grid','dimensions','cutoff','Y'],'gap-measurable-Y',['A3.SS2.p12.1'],'Per-index polynomial/closed-indicator map; fixed finite-dimensional codomain.')
edge('e04',['gap-measurable-Y','regime','cutoff','Y'],'gap-integrable-Y',['A3.SS2.p12.4'],'Bounded measurable finite-dimensional matrix under probability mu. No moment assumption added.')
edge('e05',['row-law','gap-integrable-Y','radial-mean'],'gap-actual-mean-transport',['A3.SS2.p12.4'],'Use the actual row pushforward and coordinate-Bochner equality; radial trace/normalization derives a internally.')
edge('e06',['gap-actual-mean-transport'],'actual-mean',['A3.SS2.p12.4'],'Identify actual mean; not a new definition or a supplied proxy.')
edge('e07',['Y'],'gap-Y-Hermitian',['A3.SS2.p15.1'],'Pointwise real outer-product tensor algebra; integrability is not needed for Y symmetry.')
edge('e08',['gap-Y-Hermitian','gap-integrable-Y'],'gap-mean-Hermitian-integral',['A3.SS2.p15.1'],'Integrate equal transpose entries with the actual mean.')
edge('e09',['actual-mean'],'gap-mean-Hermitian-radial',['A3.SS2.p15.1'],'Symmetric explicit actual mean.')
node('mean-Hermitian','derived-bridge','Actual mean E_mu Y_i is self-adjoint.',['A3.SS2.p15.1'],alternative_routes=['gap-mean-Hermitian-integral','gap-mean-Hermitian-radial'])
edge('e10a',['gap-mean-Hermitian-integral'],'mean-Hermitian',['A3.SS2.p15.1'],'Sufficient direct integral route.',logic='OR-route-A')
edge('e10b',['gap-mean-Hermitian-radial'],'mean-Hermitian',['A3.SS2.p15.1'],'Sufficient source radial route.',logic='OR-route-B')
edge('e11',['Z','gap-integrable-Y'],'gap-centering',['A3.SS2.p15.1'],'Constant integral is the same actual mean because mu(univ)=1; linearity discharges centering.')
edge('e12',['row-law','gap-measurable-Y','Z'],'gap-independence-transform',['A3.SS2.p15.1'],'Measurable per-index translate of row-local Y; mean is fixed.')
node('Z-structure','derived-bridge','The actual Z_i family is independent, centered, integrable and pointwise self-adjoint.',['A3.SS2.p15.1'])
edge('e13',['gap-independence-transform','gap-centering','gap-Y-Hermitian','mean-Hermitian','Z'],'Z-structure',['A3.SS2.p15.1'],'Combine independent transforms, actual mean zero, and Hermitian difference.')
edge('e14',['Z-structure','weighted-Z','grid','dimensions'],'gap-weighted-transfer',['A3.SS2.p15.1'],'All weights deterministic real; no frequency sign/nonzero assumption needed.')
edge('e15',['Z-structure','gap-weighted-transfer'],'structure',['A3.SS2.p15.1'],'Each sequence separately has the three source properties; true integrability accompanies centering.')

# Entire read scopes are inventoried. Excluded contextual blocks receive explicit reasons.
used={a['source_id'] for n in nodes for a in n['source_anchors']}
coverage=[]
for b in allblocks:
    sid=b['id']; item={k:v for k,v in b.items() if k!='text'}
    if sid in used:
        item.update(disposition='NODE',node_ids=[n['id'] for n in nodes if any(a['source_id']==sid for a in n['source_anchors'])],reason='Definition, standing premise, assertion, or adjacent use site needed by the bounded structural packet.')
    else:
        if b['tag'].startswith('h'): reason='Navigation/theorem heading; not an additional mathematical premise.'
        elif sid.startswith('S4.'):
            reason='Outside structural assertion closure: global lower-bound/algorithm/target/admissibility/limitations statement or proof; no use as a structural premise.'
        elif any(sid.startswith(f'A3.SS2.p{k}.') for k in [2,3,4,5,6,7,8]) or sid in ['A3.Ex86','A3.Ex87','A3.Ex90','A3.EGx5','A3.EGx6','A3.EGx7','A3.Ex96','A3.EGx8','A3.EGx9','A3.Ex102','A3.Thmtheorem5.p1.1','A3.Thmtheorem5.p1.2']:
            reason='Fact C.5 range, aggregate Gram moments, cosine cancellation, or vector norm bounds are downstream concentration inputs; not needed to establish row-local independence, centering or self-adjointness.'
        elif sid in ['A3.Ex104','A3.Ex105','A3.SS2.p10.2','A3.SS2.p10.3','A3.SS2.p11.1','A3.EGx10','A3.Ex109']:
            reason='Tail/MGF/event probability and truncation-bias estimates; structural conclusion needs literal cutoff and integrability, not these quantitative estimates.'
        elif sid in ['A3.Ex110','A3.SS2.p12.5']:
            reason='Zero mean of the aggregate uncentered weighted sum; distinct from individual E[Z_i]=0 and not needed for structural assertion.'
        elif any(sid.startswith(f'A3.SS2.p{k}.') for k in [13,14]) or sid in ['A3.Ex111','A3.Ex112','A3.Ex113','A3.Ex114','A3.EGx11','A3.Ex118','A3.Ex119']:
            reason='Quantitative summand norm/fourth-moment/variance calculation; not needed for the bounded structural packet.'
        else:
            reason='Downstream matrix Bernstein inequality, threshold inversion, probability union bound, bias reconciliation, or final Krylov-space conclusion; target stops at p15 first assertion.'
        item.update(disposition='EXCLUDED',reason=reason)
    coverage.append(item)

# Mixed paragraphs have exact raw partitions, so substantive excluded clauses are explicit.
splits=[('A3.SS2.p10.1','Since ',['NODE','EXCLUDED'],['Literal L,R definitions','MGF quantitative premise is outside structure closure']),
        ('A3.SS2.p12.3','Since ',['NODE','EXCLUDED'],['Same scalar across i','a in [0,1] and bias quantitative preparation are outside structure closure']),
        ('A3.SS2.p12.4','Fact', ['NODE','EXCLUDED'],['Actual individual matrix mean formula','Reference to Fact C.5 prepares aggregate expectation identities']),
        ('A3.SS2.p13.1','Using ',['NODE','EXCLUDED'],['Actual centered matrix definition Z=Y-E_mu Y','Quantitative norm estimate preparation']),
        ('A3.SS2.p15.1','The two-sided', ['NODE','EXCLUDED'],['First structural assertion; bounded target','Matrix Bernstein analytic invocation belongs to subsequent packet'])]
fragments=[]
for sid,mark,ds,rs in splits:
    b0=byid[sid]; a,z=b0['char_start'],b0['char_end_exclusive']; k=s.index(mark,a,z)
    for j,(u,v) in enumerate([(a,k),(k,z)]): fragments.append({'source_id':sid,'fragment':j+1,**loc(u,v),'disposition':ds[j],'reason':rs[j]})
for sid in ['A3.SS2.p13.3','A3.SS2.p14.6','A3.Ex120']:
    for item in coverage:
        if item['id']==sid: item['note']='NODE only for identifying the weighted sequence and deterministic scalar; its norm/variance inequality is contextual and excluded from this target.'

graph={'version':'source-only-v1','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
       'source_original_sha256':hashlib.sha256(s.encode()).hexdigest(),
       'scope':'Appendix C.2 p15 first assertion, with original experiment/standing definitions in S4 and adjacent full C.2 coverage inventory.',
       'before_target_signature_read':True,'implementation_or_old_audit_read':False,
       'topology_review_status':'REQUIRES DISTINCT RAW-SOURCE REVIEW; extractor does not approve its own topology',
       'nodes':nodes,'edges':edges,'alternative_route_semantics':'e10a OR e10b; never both required for actual-mean Hermitian. Source radial route can coexist with direct integral expansion.',
       'source_hypothesis_boundary':['q,d integer regime','independent standard Gaussian original columns'],
       'forbidden_public_certificates':['row independence/law','truncated mean formula','matrix integrability','measurability','self-adjointness','centering','norm/variance estimate','Bernstein-ready gate'],
       'q0':'q=0 => r=1,n=1,d>=2,t_i=(1); all off-diagonal row symmetry requirements are vacuous; cosine weights remain deterministic.',
       'no_claims':['No Lean proof','No fidelity/normalV acceptance','No topology approval','No SAU intake/stabilization']}
(OUT/'source-graph.RAWFIRST.v1.json').write_text(json.dumps(graph,ensure_ascii=False,indent=2)+'\n')
(OUT/'source-coverage.RAWFIRST.v1.json').write_text(json.dumps({'blocks':coverage,'mixed_paragraph_fragments':fragments,'counts':{'total':len(coverage),'NODE':sum(x['disposition']=='NODE' for x in coverage),'EXCLUDED':sum(x['disposition']=='EXCLUDED' for x in coverage)}},ensure_ascii=False,indent=2)+'\n')
files=['source-graph.RAWFIRST.v1.json','source-coverage.RAWFIRST.v1.json']
freeze={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'phase':'INDEPENDENT RAW TOPOLOGY FROZEN BEFORE EXACT SIGNATURE READ',
        'files':{f:hashlib.sha256((OUT/f).read_bytes()).hexdigest() for f in files},'source_sha256':hashlib.sha256(s.encode()).hexdigest()}
(OUT/'TOPOLOGY-RAWFREEZE.json').write_text(json.dumps(freeze,indent=2)+'\n'); print(json.dumps(freeze,indent=2))
