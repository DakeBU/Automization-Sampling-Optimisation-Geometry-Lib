import AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumVariances
import Tests.GaussianComplexityFixedSpectrumVariances
import Lean
noncomputable section
open Lean Meta Elab Command MeasureTheory ProbabilityTheory
open scoped BigOperators ENNReal NNReal Topology
def expectedProducer : Prop := ∀ {d : ℕ} (hd : 2 ≤ d) {κ : ℝ} (hκ : 2 ≤ κ)
    (n : ℕ) (hn : 1 ≤ n) (hnd : n < d),
  let θ : Fin d → ℝ := fun i => ((i.val : ℝ) + 1 / 2) * Real.pi / (d : ℝ)
  let eigenvalue : Fin d → ℝ := fun i => (κ + 1) / 2 + (κ - 1) / 2 * Real.cos (θ i)
  let Λ : Matrix (Fin d) (Fin d) ℝ := Matrix.diagonal eigenvalue
  let μ : Measure (EuclideanSpace ℝ (Fin d)) :=
    multivariateGaussian (0 : EuclideanSpace ℝ (Fin d)) Λ⁻¹
  let Q : EuclideanSpace ℝ (Fin d) → ℝ := fun x =>
    ∑ i : Fin d, Real.cos ((n : ℝ) * θ i) * (WithLp.ofLp x i) ^ 2
  let M : ℝ := ∫ x : EuclideanSpace ℝ (Fin d), ‖x‖ ^ 2 ∂μ
  MemLp (fun x : EuclideanSpace ℝ (Fin d) => ‖x‖ ^ 2) 2 μ ∧
  MemLp Q 2 μ ∧
  Var[fun x : EuclideanSpace ℝ (Fin d) => ‖x‖ ^ 2; μ] =
    2 * ∑ i : Fin d, 1 / (eigenvalue i) ^ 2 ∧
  Var[Q; μ] = 2 * ∑ i : Fin d, (Real.cos ((n : ℝ) * θ i)) ^ 2 / (eigenvalue i) ^ 2 ∧
  Var[fun x : EuclideanSpace ℝ (Fin d) => ‖x‖ ^ 2; μ] ≤ 2 * M ∧
  Var[Q; μ] ≤ 2 * M ∧
  2 * M ≤ 2 * (d : ℝ) / Real.sqrt κ

def expectedConsumer : Prop := ∀ {d : ℕ} (hd : 2 ≤ d) {κ : ℝ} (hκ : 2 ≤ κ)
    (n : ℕ) (hn : 1 ≤ n) (hnd : n < d) (τ : ℝ) (hτ0 : 0 ≤ τ) (hτ1 : τ ≤ 1 / 2),
  let θ : Fin d → ℝ := fun i => ((i.val : ℝ) + 1 / 2) * Real.pi / (d : ℝ)
  let eigenvalue : Fin d → ℝ := fun i => (κ + 1) / 2 + (κ - 1) / 2 * Real.cos (θ i)
  let Λ : Matrix (Fin d) (Fin d) ℝ := Matrix.diagonal eigenvalue
  let μ : Measure (EuclideanSpace ℝ (Fin d)) :=
    multivariateGaussian (0 : EuclideanSpace ℝ (Fin d)) Λ⁻¹
  let Q : EuclideanSpace ℝ (Fin d) → ℝ := fun x =>
    ∑ i : Fin d, Real.cos ((n : ℝ) * θ i) * (WithLp.ofLp x i) ^ 2
  let M : ℝ := ∫ x : EuclideanSpace ℝ (Fin d), ‖x‖ ^ 2 ∂μ
  let Z : EuclideanSpace ℝ (Fin d) → ℝ := fun x => (-1 : ℝ) ^ n * Q x - 2 * τ * ‖x‖ ^ 2
  MemLp Z 2 μ ∧ Var[Z; μ] ≤ 8 * M

run_elab do
  let env ← getEnv
  let suffixes := ["centered_gaussian_square_L2", "centered_gaussian_square_variance", "actual_gaussian_contrast_variance_le"]
  let mut roots := #[``AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumVariances.actual_diagonal_gaussian_quadratic_variances]
  for suffix in suffixes do
    let candidates := env.constants.toList.filter fun (n, _) => n.toString.endsWith ("." ++ suffix)
    unless candidates.length == 1 do throwError "Expected exactly one matching declaration: {suffix}; found {candidates.length}"
    roots := roots.push candidates.head!.1
  let producer ← getConstInfo roots[0]!
  let consumer ← getConstInfo roots[3]!
  let ep ← getConstInfo ``expectedProducer
  let ec ← getConstInfo ``expectedConsumer
  unless ← isDefEq producer.type (ep.value? (allowOpaque := true)).get! do
    throwError "Producer elaborated type differs from sealed signature"
  unless ← isDefEq consumer.type (ec.value? (allowOpaque := true)).get! do
    throwError "Consumer elaborated type differs from sealed signature"
  logInfo "EXACT_SIGNATURES producer=true consumer=true"
  for n in roots do
    let ci ← getConstInfo n
    let axioms ← Lean.collectAxioms n
    logInfo m!"ROOT {n}\nAXIOMS {axioms}"
    let deps := (ci.value? (allowOpaque := true)).get!.getUsedConstants
    let relevant := deps.filter fun x => x.toString.startsWith "AutoSamplingTheory." || x.toString.startsWith "_private.AutoSamplingTheory." || x.toString.startsWith "ProbabilityTheory." || x.toString.startsWith "MeasureTheory.MemLp."
    logInfo m!"DIRECT_RELEVANT {relevant}"
  logInfo m!"PRODUCER_TYPE {← ppExpr producer.type}"
  logInfo m!"CONSUMER_TYPE {← ppExpr consumer.type}"
