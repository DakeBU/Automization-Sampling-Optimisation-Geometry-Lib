"""Retain failed first harness; freeze and run a corrected private test-only successor."""
import json
from native_common import *

def main():
    original_assignment = json.loads((OWN/'native-command-assignment.json').read_text())
    for row in original_assignment['inputs']:
        assert file_sha(OWN/row['path']) == row['sha256']
    receipts = [json.loads(p.read_text()) for p in (OWN/'command-receipts').glob('*.receipt.json')]
    for i in range(11):
        assert any(r['label'] == f'build-{i:02d}' and r['exit_code'] == 0 for r in receipts)
    assert any(r['label']=='literal-applications' and r['exit_code']==1 for r in receipts)
    harness = OWN/'harness-v2'
    text = (OWN/'harness/NativeLiteralApplications.lean').read_text()
    assert text.count('  intro s hs a\n') == 4
    text = text.replace('  intro s hs a\n','  dsimp only\n  intro s hs a\n')
    (harness/'NativeLiteralApplications.lean').write_text(text)
    (harness/'NativeAudit.lean').write_bytes((OWN/'harness/NativeAudit.lean').read_bytes())
    packages = json.loads((OWN/'verified-package-inputs.json').read_text())['packages']
    env = lean_env(packages)
    flags = [str(LEAN),'-DmaxRecDepth=32768','-DmaxHeartbeats=0','-Ddebug.skipKernelTC=false']
    commands = [
      {'id':'literal-applications-v2','argv':flags+['-o',str(OUT/'NativeLiteralApplications.olean'),str(harness/'NativeLiteralApplications.lean')],'cwd':str(harness),'env':env},
      {'id':'raw-kernel-audit-v2','argv':flags+['--run',str(harness/'NativeAudit.lean')],'cwd':str(harness),'env':env},
      {'id':'complete-transitive-type-value-graph','argv':flags+['--run',str(harness/'NativeTransitiveGraph.lean')],'cwd':str(harness),'env':env}]
    write_json(OWN/'native-successor-commands.json',commands)
    inputs = [p for p in harness.iterdir() if p.is_file()] + [p for p in OUT.rglob('*') if p.is_file()]
    inputs += [OWN/n for n in ['native-command-assignment.json','native-successor-commands.json','run_successor.py']]
    assignment = {'candidate_commit':COMMIT,'reason':'test-only harness correction: zeta-reduce let chain before introducing scalar binders; production input and 11 independently recompiled source outputs unchanged','original_assignment_sha256':file_sha(OWN/'native-command-assignment.json'),'inputs':[{'path':str(p.relative_to(OWN)),'sha256':file_sha(p)} for p in inputs]}
    write_json(OWN/'native-successor-assignment.json',assignment)
    for command in commands:
        for row in assignment['inputs']:
            assert file_sha(OWN/row['path']) == row['sha256']
        print(json.dumps({'started_successor_command':command['id']}),flush=True)
        run(command['id'],command['argv'],cwd=command['cwd'],env=command['env'])
    write_json(OWN/'native-sequence-completed.json',{'candidate_commit':COMMIT,'source_builds':11,'first_harness_failure_retained':True,'successor_commands_all_exit_zero':True})

if __name__ == '__main__': main()
