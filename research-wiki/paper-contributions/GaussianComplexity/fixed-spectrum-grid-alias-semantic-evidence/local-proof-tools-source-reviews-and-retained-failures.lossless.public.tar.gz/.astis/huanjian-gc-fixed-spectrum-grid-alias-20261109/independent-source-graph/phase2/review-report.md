# Exact v2 bounded source admission

I recommend admitting seal GC-FIXED-SPECTRUM-GRID-ALIAS-20261109-v2 (SHA256 5abb51d681187baa67985c54f942a670cdc79e65a5ef12393dcaf8c94a376285) for the proposed all-integer alias anchor and actual private deterministic weighted alias-series consumer. This is source/binder/topology admission only, pending the distinct topology challenge. It is not proof acceptance or VERIFIED.

The independent raw-first source graph and exhaustive bounded inventory were frozen before the seal or formation confirmation was read. No implementation Lean, proof API, Registry, production lesson/audit, prior source graph or prior graph verdict was read. Filename-only search exposure is recorded. A challenger sent a preliminary seal-pass message after the freeze; I did not use that message as evidence. The exact seal hash, both signature hashes and formation-confirmation seal binding were independently recomputed; formation is not proof.

The producer preserves source every-integer k, including zero and negative aliases. Fin d has the exact source index shift i_source=i.val+1. Divisibility by positive 2*d selects the unique source quotient, with integer powers of -1, so negative parity is preserved and the nondivisible branch is literal zero. There is no extra convergence, denominator or frequency premise.

The consumer uses positive j+1 frequencies and Int subtraction before evaluating a(j+1-n). Its weighted reciprocal-grid sum retains the actual half-shifted eigenvalues. Constant elimination uses 1<=n<d; C7 factor2 cancels the product-to-sum half; the inner grid sums contribute d, producing d/sqrt(kappa). The coefficient series is required to be Summable in the conclusion. All binder inputs are TYPING, STANDING or SOURCE; EXCESS is empty. No project-owned Prop alias hides an input.

The intended proof must actually consume C7 and the new alias, produce weighted convergence and finite/series interchange, remove the constant term by alias at n, and apply alias at both j+1-n and j+1+n. This signature is a genuine meaningful consumer design; actual compiled use remains a later check and cannot be inferred from imports, parent names or a wrapper/#check.

Gaussian expectation identification p4/Ex140, unweighted tail closed resummation p5, weighted tail partition/regrouping/closed resummation p6.2/EGx16 and p7-p11 variance/bias are explicitly open or excluded. The deterministic left side is W_n; the source mu_n is an expectation requiring the separate bridge. C8 and Lemma4.5 remain open.

Phase1 stays immutable. Its context-only c8-means edge is explicitly incomplete and does not assert sufficiency; the exact bounded projection omits it. The all-integer branch proof remains a guarded case split. Coverage is exhaustive for the listed bounded raw roots only, with p7-p11 dispositions explicitly outside scope; no whole-paper coverage claim is made. A distinct reviewer must approve the extractor's graph.
