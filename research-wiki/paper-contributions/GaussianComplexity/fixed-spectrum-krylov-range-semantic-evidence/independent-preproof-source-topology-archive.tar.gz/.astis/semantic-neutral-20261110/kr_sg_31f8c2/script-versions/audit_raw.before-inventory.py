from pathlib import Path
from html.parser import HTMLParser
import hashlib, json, sys, datetime, subprocess

ROOT=Path(__file__).resolve().parent
REPO=ROOT.parents[2]
SOURCE=REPO/'.astis/huanjian-resume-20261103/2610.20492v1.html'
def sha(b): return hashlib.sha256(b).hexdigest()
def dump(p,x): (ROOT/p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def log(event):
    with (ROOT/'read-events.jsonl').open('a',encoding='utf-8') as f:
        f.write(json.dumps(dict(time=datetime.datetime.now(datetime.timezone.utc).isoformat(),**event),ensure_ascii=False)+'\n')

class ExactHTML(HTMLParser):
    def __init__(self,s):
        super().__init__(convert_charrefs=True)
        self.s=s; self.starts=[0]+[i+1 for i,c in enumerate(s) if c=='\n']; self.nodes=[]; self.stack=[]
    def pos(self):
        l,c=self.getpos(); return self.starts[l-1]+c
    def handle_starttag(self,t,a):
        attrs=dict(a); n={'tag':t,'attrs':attrs,'id':attrs.get('id'),'start':self.pos(),'start_tag_end':self.pos()+len(self.get_starttag_text()),'parent':self.stack[-1] if self.stack else None}
        k=len(self.nodes); self.nodes.append(n)
        if t in {'area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr'}:
            n['end']=n['start_tag_end']
        else:self.stack.append(k)
    def handle_endtag(self,t):
        for j in range(len(self.stack)-1,-1,-1):
            if self.nodes[self.stack[j]]['tag']==t:
                end=self.s.find('>',self.pos())+1
                for k in self.stack[j:]: self.nodes[k]['end']=end
                del self.stack[j:];break
    def handle_startendtag(self,t,a):
        self.handle_starttag(t,a)
        if self.stack and self.nodes[self.stack[-1]]['start']==self.pos():
            self.nodes[self.stack.pop()]['end']=self.pos()+len(self.get_starttag_text())

class Readable(HTMLParser):
    def __init__(self):super().__init__(convert_charrefs=True);self.out=[];self.math=0
    def handle_starttag(self,t,a):
        a=dict(a)
        if t=='math':
            if not self.math:self.out.append('$'+a.get('alttext','[missing alttext]')+'$')
            self.math+=1
        elif not self.math and t in {'p','div','section','table','h1','h2','h3','h4','h5','h6','li'}:
            self.out.append('\n')
    def handle_endtag(self,t):
        if t=='math':self.math-=1
    def handle_data(self,s):
        if not self.math:self.out.append(s)
def readable(s):
    r=Readable();r.feed(s);return '\n'.join(x.strip() for x in ''.join(r.out).splitlines() if x.strip())
def load_source():
    b=SOURCE.read_bytes();log({'action':'read-source','path':str(SOURCE),'bytes':len(b),'sha256':sha(b)})
    assert len(b)==951991 and sha(b)=='6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
    s=b.decode('utf-8');p=ExactHTML(s);p.feed(s);return b,s,p
def pin(n,s):
    a,b=n['start'],n['end'];raw=s[a:b]
    endline=s.count('\n',0,b-1)+1 if b>a else s.count('\n',0,b)+1
    return {'id':n['id'],'tag':n['tag'],'class':n['attrs'].get('class'),'display':n['attrs'].get('display'),
      'char_span_0based_halfopen':[a,b],'utf8_span_0based_halfopen':[len(s[:a].encode()),len(s[:b].encode())],
      'lf_lines_1based_inclusive':[s.count('\n',0,a)+1,endline],'sha256_raw_utf8':sha(raw.encode()),
      'alttext_dom_attribute':n['attrs'].get('alttext')}

def main():
    mode=sys.argv[1]
    if mode=='protocols':
        for i,name in enumerate(['AGENTS.md','docs/proof-digestion-protocol.md','docs/theorem-publication-protocol.md','docs/evidence-routed-memory-protocol.md','.agents/skills/astis-source-dependency-audit/SKILL.md']):
            b=(REPO/name).read_bytes();dest=ROOT/'protocols';dest.mkdir(exist_ok=True);(dest/f'{i}-{Path(name).name}').write_bytes(b)
            log({'action':'read-protocol','path':str(REPO/name),'bytes':len(b),'sha256':sha(b),'raw_saved':str(dest/f'{i}-{Path(name).name}')})
            print(name,len(b),sha(b))
    elif mode=='extract':
        b,s,p=load_source();out=ROOT/'raw';out.mkdir(exist_ok=True)
        selected=[]
        for ident in ['S4.SS1','S4.SS2','A3.SS2']:
            n=next(x for x in p.nodes if x['id']==ident)
            selected.append(n);raw=s[n['start']:n['end']]
            (out/f'{ident}.html').write_bytes(raw.encode())
            (out/f'{ident}.readable.txt').write_text(readable(raw)+'\n',encoding='utf-8')
        ids=[n for n in p.nodes if n['id'] and any(root['start']<=n['start'] and n['end']<=root['end'] for root in selected)]
        dump('source-pins.json',{'input':{'path':str(SOURCE),'bytes':len(b),'sha256':sha(b)},'offset_convention':'Unicode scalar character and UTF8 byte zero-based half-open; LF lines 1-based; terminal LF belongs to preceding line. Raw spans contain exact source bytes, no DOM normalization. alttext is HTMLParser decoded attribute and is not the raw pin.','sections':[pin(n,s) for n in selected],'elements':[pin(n,s) for n in ids]})
        print(json.dumps({'sections':[pin(n,s) for n in selected],'elements':len(ids)},ensure_ascii=False,indent=2))
    elif mode=='show':
        name=sys.argv[2];p=ROOT/'raw'/f'{name}.readable.txt';b=p.read_bytes();log({'action':'read-derived-source','path':str(p),'sha256':sha(b),'bytes':len(b)})
        print(b.decode())
    else:raise ValueError(mode)
if __name__=='__main__':main()
