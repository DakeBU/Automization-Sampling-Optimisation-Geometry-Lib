from pathlib import Path
import hashlib,json,sys
sys.dont_write_bytecode=True
sys.path.insert(0,'tools')
import astis_publication as pub
import astis_semantic_roundtrip as rt
W=Path('.astis/huanjian-gc-fixed-spectrum-grid-alias-20261109')
E=Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-grid-alias-semantic-evidence')
S=json.loads((W/'statement-seal-v2.json').read_text())
sha=lambda b:hashlib.sha256(b.encode() if isinstance(b,str) else b).hexdigest()
def put(p,x):
 p=Path(p);assert not p.exists(),p;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
name=S['producer']['name'];file=Path(S['producer']['planned_file']);test=Path(S['actual_private_consumer']['planned_file'])
sig=S['producer']['signature'];csig=S['actual_private_consumer']['signature']
for p,s,n in [(file,sig,'theorem actual_midpoint_grid_cosine_alias'),(test,csig,'private theorem actual_weighted_inverse_grid_alias_series')]:
 assert p.read_text().split(n,1)[1].split(' := by',1)[0]==s.split(n,1)[1].rstrip(),p
focus=Path('.astis/huanjian-resume-20261103/20261109T134008668848Z-grid-alias-final-focused-producer-and-consumer-build.receipt.json')
kernel=Path('.astis/huanjian-resume-20261103/20261109T134244443442Z-grid-alias-actual-kernel-expanded-auxiliaries-and-sealed-types-v2.receipt.json')
for p in [focus,kernel]:
 x=json.loads(p.read_text());assert x['exit_code']==0 and sha(Path(x['log']).read_bytes())==x['log_sha256']
klog=Path(json.loads(kernel.read_text())['log']).read_text();assert 'ACTUAL_PRIVATE_SEALED_LITERAL_KERNEL_TYPE_APPLICATION_PASS' in klog and 'sorryAx' not in klog
short='Every integer cosine mode on the midpoint grid vanishes except the signed aliases at multiples of twice the dimension.'
formula=r'\sum_{i=1}^{d}\cos(k\theta_i)=\begin{cases}d(-1)^a,&k=2ad,\ a\in\mathbb Z,\\0,&k\notin2d\mathbb Z.\end{cases}'
assumptions=[
 r'Fix an integer \(d\ge2\), and set \(\theta_i=(i-\tfrac12)\pi/d\) for \(i=1,\ldots,d\).',
 r'The frequency \(k\) is any integer, including zero and negative integers. Lean represents the source grid by \(i\in\mathrm{Fin}\,d\) and \(\theta(i)=(i.\mathrm{val}+1/2)\pi/d\).',
 r'In the alias case, \(a=k/(2d)\) is the exact integer quotient. Lean uses integer powers of the nonzero real number \(-1\), so negative aliases retain their parity. Away from divisibility the coefficient is literally zero.',
 r'The dimension, literal grid and integer frequency are the complete public inputs. Nonzero sine denominators, divisibility arithmetic and trigonometric identities are discharged inside the proof.'
]
steps=[
 {'title':'Use the finite midpoint cosine sum',
  'text':'Put x=kπ/(2d). The standard finite arithmetic-progression cosine identity gives a product formula. Its right side is half sin(kπ), hence zero for every integer k. This multiplication identity remains valid even when sin x vanishes.',
  'formula':r'\sin x\sum_{i=1}^{d}\cos(k\theta_i)=\sin(k\pi/2)\cos(k\pi/2)=\tfrac12\sin(k\pi)=0.',
  'lean':'hgrid transports Fin d to Finset.range d. Real.sin_mul_sum_cos, harg and harg\' give the exact midpoint identity; Real.sin_two_mul and Real.sin_int_mul_pi produce hzero. No new finite-sum formula is copied into a public wrapper.'},
 {'title':'Eliminate every nonalias frequency',
  'text':'If sin x were zero, x would be an integer multiple of π, forcing k to be a multiple of 2d. Therefore sin x is nonzero in the nonalias case, and the product formula forces the grid sum to vanish.',
  'formula':r'\sin\!\left(\frac{k\pi}{2d}\right)=0\ \Longrightarrow\ k=2dm\ (m\in\mathbb Z),\qquad 2d\nmid k\ \Longrightarrow\ S_d(k)=0.',
  'lean':'hsin uses Real.sin_eq_zero_iff, Real.pi_ne_zero and casts to produce the forbidden integer divisibility witness. The zero-product elimination uses this internally proved nonzero fact.'},
 {'title':'Evaluate the signed alias branch',
  'text':'For k=2ad, use the zero-based grid index ℓ=i−1. Each angle is aπ+2aℓπ, so every cosine equals (−1)^a. Summing d identical terms gives the signed alias value. The exact integer quotient handles zero and negative a as well.',
  'formula':r'k\theta_{\ell+1}=a\pi+2a\ell\pi,\qquad\cos(k\theta_{\ell+1})=(-1)^a,\qquad S_d(k)=d(-1)^a.',
  'lean':'Int.mul_ediv_cancel\' yields hq and its real cast. hangle, Real.cos_add_int_mul_two_pi and Real.cos_int_mul_pi evaluate each term; the finite constant sum gives d times the value.'},
 {'title':'Consume C7 on the actual inverse grid',
  'text':'For the private consumer, additionally fix κ≥2 and 1≤n<d, with the literal source λ_i and r. C7 supplies the reciprocal identity and absolute convergence at each actual grid point. Cosine weighting preserves summability, so the finite grid and infinite series can genuinely be exchanged.',
  'formula':r'\sum_i\frac{\cos(n\theta_i)}{\lambda_i}=\frac1{\sqrt\kappa}\left[\sum_i\cos(n\theta_i)+2\sum_{j\ge1}(-r)^j\sum_i\cos(n\theta_i)\cos(j\theta_i)\right].',
  'lean':'The private actual_weighted_inverse_grid_alias_series calls the canonical C7 producer for heq/habs. hs, hsg and hsumG produce convergence; heigen normalizes the literal reciprocal eigenvalues, and Summable.tsum_finsetSum is the actual exchange. The public alias theorem itself has no κ or C7 premise.'},
 {'title':'Keep only the two shifted alias modes',
  'text':'The range 1≤n<d makes the constant grid sum zero by the new alias theorem. Product-to-sum cancels C7\'s factor two. Apply the same all-integer theorem at j−n and j+n; each inner grid contributes d times its alias coefficient. Summability of the resulting series is produced too. All differences are formed in integers before evaluation.',
  'formula':r'A_d(k)=\mathbf1_{2d\mid k}(-1)^{k/(2d)},\qquad\sum_i\frac{\cos(n\theta_i)}{\lambda_i}=\frac d{\sqrt\kappa}\sum_{j\ge1}(-r)^j\bigl[A_d(j-n)+A_d(j+n)\bigr].',
  'lean':'hcos materializes the new producer. hnnon and hzero remove the constant; hprod uses Real.two_mul_cos_mul_cos and both integer frequencies. hterm proves 2G_j=dF_j. Nonzero d transports summability to F, and hseries plus hexchange proves the equality. The compiled private consumer has precisely C7 and the new alias as public ASTIS parents, after expanding generated local proof auxiliaries.'}
]
boundary='The all-integer midpoint alias identity and an actual private summable weighted reciprocal-grid alias series are compiled locally. Gaussian expectation-to-grid identification, the unweighted/weighted alias-tail partitions and closed resummations, full FactC8 and Lemma4.5 variance/bias, Krylov and both full main lower bounds remain open. Exact oracle, TV precision, deterministic worst-case query caps and explicit expected-cost adapters, independent source verification, local/remote integration and purification/Exposition Seal remain separate acceptance stages.'
source={'url':'https://arxiv.org/html/2610.20492v1#A3.Ex139','edition':'arXiv2610.20492v1; raw HTML SHA2566bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915','anchor':'A3.SS3.p3/A3.Ex139; literal grid S4.E11 and standing d S4.SS1.p1.m3. Private deterministic consumer A3.SS3.p4.2,p6.1/A3.Ex144; n range S4.Thmtheorem5.','wording_status':'faithful paraphrase','attribution':'Huanjian Zhou and Taiji Suzuki, On Complexity of Gaussian Sampling.','scope':'Exact all-integer grid identity. Private weighted alias-series use is a deterministic source-proof intermediate; Gaussian expectation identification and closed C8 means are not claimed.'}
unit={'kind':'theorem','reading_layout':'progressive','declaration':name,'title':'Signed cosine aliases on the midpoint grid','reader_note':'The finite-grid identity is shown first; parameters, formula proof and exact Lean are folded below.','statement':short,'formula':formula,'assumptions':assumptions,'notation':[{'symbol':r'\(S_d(k)\)','text':'The unnormalized sum on the actual d-point grid.','formula':r'S_d(k)=\sum_{i=1}^{d}\cos(k\theta_i).'}],'steps':steps,'astis_dependencies':[],'mathlib_dependencies':['Real.sin_mul_sum_cos','Real.sin_eq_zero_iff','Real.sin_two_mul','Real.sin_int_mul_pi','Real.cos_add_int_mul_two_pi','Real.cos_int_mul_pi','Fin.sum_univ_eq_sum_range','Int.mul_ediv_cancel\''],'lean_statement':'Exactly d:Nat with d>=2, arbitrary k:Int and the literal Fin d midpoint grid. Divisibility selects the exact integer quotient and real integer power.','lean_proof':'Guarded nonalias and alias cases use the canonical finite trigonometric product identity and integer-periodic cosine evaluation. The private actual inverse-grid consumer combines this producer with canonical C7 and genuine convergent finite-series exchange.','boundary':boundary,'sources':[{**source,'label':'Zhou–Suzuki Appendix C.3 midpoint aliases and actual weighted use'}],'tests':['lake build Tests.GaussianComplexityFixedSpectrumGridAlias']}
put('website/content/declaration_lessons/huanjian-fixed-spectrum-grid-alias.json',{'schema_version':1,'units':[unit]})
aid='ASTIS-RT-20261109-HuanjianFixedSpectrumGridAlias'
binding={'declaration':name,'cell':'ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-grid-alias','role':'proof-edge','supports':['nonalias-zero','signed-alias-value'],'boundary':boundary,'audit_id':aid,'assumption_deltas':[
 {'source':'Hard-family dimension d>=2, literal midpoint grid, every integer k.','lean':'Exactly d:Nat,hd:2<=d,k:Int; Fin index i corresponds to source i+1.','classification':'same','reason':'No κ, matrix, Gaussian-law, convergence or denominator premise occurs in the public alias interface.'},
 {'source':'The alias value is d(-1)^a when k=2ad with a an integer; otherwise zero.','lean':'Integer divisibility guard, exact k/(2*d) integer quotient and integer power of real -1.','classification':'source-implicit','reason':'The positive divisor is nonzero. Negative/zero aliases preserve parity, and the quotient outside the true branch has no effect.'},
 {'source':'Weighted C8 calculation uses C7, the alias at n and at integer j−n,j+n, with1<=n<d.','lean':'A private actual deterministic weighted series identity and Summable conclusion use both canonical producers. Natural series mode j+1 is cast to Int before subtraction.','classification':'same','reason':'No Gaussian expectation or closed tail sum is defined into the intermediate. Such later bridges remain open.'}]}
text=' '.join([short,formula,*assumptions])
item={'id':'huanjian-fixed-spectrum-grid-alias','library':'samplewiki','chapter':'gaussian-sampling-complexity','chapter_path':'example-cases/samplewiki/companions/gaussian-sampling-complexity.html','title':unit['title'],'source':source,'statement':text,'formulae':[{'label':'All-integer midpoint cosine aliases','tex':formula}],'assumptions':assumptions,'obligations':[{'id':'nonalias-zero','label':'Every nonmultiple of2d has zero grid cosine sum.'},{'id':'signed-alias-value','label':'Every multiple, including zero and negative frequencies, has exact signed alias value.'}],'bindings':[binding]}
put('website/content/publications/huanjian-fixed-spectrum-grid-alias.json',{'schema_version':1,'items':[item]})
head,body=sig.split(' :\n',1);statement='∀'+head.removeprefix('theorem actual_midpoint_grid_cosine_alias')+',\n'+body
context=['Fin d is the standard finite index type with values zero through d minus one. Its displayed sum ranges over every index exactly once.','Real.cos, Real.pi and casts from natural numbers and integers to reals have their standard meanings.','The divisor and quotient inside the conditional are integers. Divisibility has its standard integer meaning. An exponent of type Int on a real base is the standard integer power, including inverse powers at negative exponents.']
audit={'id':aid,'state':'draft','source':{'source_id':'arxiv2610.20492v1-midpoint-alias','url':source['url'],'anchor':source['anchor'],'original_text':text,'text_sha256':sha(text),'source_snapshot_sha256':S['source']['raw']['sha256']},'lean':{'declaration':name,'file':str(file),'statement':statement,'statement_sha256':sha(statement),'formalizer':'huanjian_gc_20261109_fixed_spectrum_grid_alias','compiled':True,'decoder_context':context},'reconstruction':{},'semantic_slots':{},'deltas':[],'verdict':'pending','source_review':{'state':'pending'},'repairs':[]}
pub.inputs.cache_clear();pub.load.cache_clear();audit['publication_binding_sha256']=pub.binding_digest(item,binding);audit['publication_context']=pub.review_context(item,binding)
put('research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-grid-alias.json',audit)
pub.check_advance([name],reviewed=False)
packet=rt.decoder_packet(audit)
neutral=Path('.astis/semantic-neutral-20261109/6c92f7');assert not neutral.exists();neutral.mkdir(parents=True)
put(neutral/'input.json',packet);put(E/'decoder-input.json',packet)
record={'producer_raw_sha256':sha(file.read_bytes()),'Test_raw_sha256':sha(test.read_bytes()),'producer_signature_sha256':S['producer']['signature_sha256'],'private_consumer_signature_sha256':S['actual_private_consumer']['signature_sha256'],'raw_compiler_auxiliaries_are_not_extra_public_nodes':True,'actual_public_ASTIS_producer_parents':[],'actual_public_ASTIS_private_consumer_parents':[name,'AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumCosineExpansion.actual_inverse_spectrum_cosine_expansion'],'publication_binding_sha256':audit['publication_binding_sha256'],'anonymous_statement_sha256':sha(statement),'anonymous_packet_canonical_sha256':packet['packet_sha256'],'neutral_input':str(neutral/'input.json'),'neutral_input_raw_sha256':sha((neutral/'input.json').read_bytes()),'actual_focus_receipt':str(focus),'actual_kernel_receipt':str(kernel),'source_review':'pending','decoder':'pending','sourceV_or_integration_or_Goal_complete':False}
put(E/'publication-draft-record.json',record);print(json.dumps(record,ensure_ascii=False))
