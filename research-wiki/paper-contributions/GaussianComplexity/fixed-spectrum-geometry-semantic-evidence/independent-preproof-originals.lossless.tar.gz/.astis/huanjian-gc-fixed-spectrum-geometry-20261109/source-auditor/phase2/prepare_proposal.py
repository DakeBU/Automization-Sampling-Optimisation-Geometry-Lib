"""Exact-interface semantic proposal only. No Lean, APIs, or lifecycle action."""
from pathlib import Path
import copy, hashlib, json, shutil

ROOT=Path('/Users/zhouhuanjian/ASTIS-GC')
BASE=ROOT/'.astis/huanjian-gc-fixed-spectrum-geometry-20261109/source-auditor'
OUT=BASE/'phase2'
PUB=ROOT/'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-geometry-semantic-evidence/source-only-review/phase2'
PUB.mkdir(parents=True,exist_ok=True)
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,obj): (OUT/name).write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n')
pins={
 'phase1-freeze.json':'2a8155895c3f7e94113783e329e6c902e055c271adf023fd3edc46b86bd80169',
 'source-graph.json':'78a48478d25d53743937c99bc566d0c986e8aea223219ea76ecd3c1ee173755c',
 'source-coverage.json':'f993e44e2bfca8e928c61eec97ca78947b19d78d054558291c201bc400cce8aa',
 'initial-cognition.md':'8e10555c490cd4d25cc28326f2903c2fdaf74dccf72a64584e599ec53681f3e3'}
for name,expected in pins.items(): assert sha(BASE/name)==expected
packet=json.loads((OUT/'inputs/preproof-raw-interface-packet.json').read_text())
assert sha(OUT/'inputs/preproof-raw-interface-packet.json')=='22eb732ccf7f4311f2c099e659e008dd0f87aa855c99f995b65a5132a9752207'

graph=copy.deepcopy(json.loads((BASE/'source-graph.json').read_text()))
graph['schema']='phase2-source-graph-successor-proposal-v2'
graph['phase']='PHASE2_PROPOSED_NOT_INDEPENDENTLY_ACCEPTED'
graph['predecessor']={'path':str((BASE/'source-graph.json').relative_to(ROOT)), 'sha256':pins['source-graph.json'], 'immutable':True}
byid={n['id']:n for n in graph['nodes']}
byroute={r['id']:r for r in graph['routes']}
byid['D.oracle']['kind']='literal-numeric-definition'
byid['D.oracle']['statement']='Eq1 numeric oracle pair x |-> (x^T A x/2,Ax). The source also asserts that Ax is the actual gradient; that assertion is represented separately by S.gradient and G.actualoracleidentification, not proved by the numeric definition.'
byid['G.conjugation']['statement']='x^T A x=sum_i lambda_i ((O^T x)_i)^2; eigenvalue bounds imply ||O^T x||^2 <= x^T A x <= kappa||O^T x||^2. This node does not yet replace ||O^T x|| by ||x||.'
byroute['R.conjugation']['step']='Expand the weighted sum and relax strict eigenvalue bounds; the intermediate bounds are in ||O^T x||^2. Norm preservation is consumed later by R.bounds.'
byid['G.oraclecontinuous']['statement']='For each fixed A, the literal numeric pair x |-> (x^T A x/2,Ax) is continuous into R x R^d. No differentiability or actual-gradient identification is required for this numeric-map branch.'
byid['G.oracleborel']['statement']='For each fixed hard-family input, the actual value-and-Euclidean-gradient oracle is Borel. Both numeric-pair continuity and the separately discharged actual-gradient identification are required; no joint/adaptive measurability theorem is asserted.'
newnode={
 'id':'G.actualoracleidentification','kind':'SOURCE_GAP',
 'statement':'Prove internally for every x that gradient f_A(x)=Ax (in the exact Euclidean carrier, query x=toLp 2 (A *v ofLp x)); hence (f_A(x),query x) is the actual value-and-gradient oracle, not merely a named numeric pair.',
 'source_anchors':['S2.E1','S2.SS0.SSS0.Px1.p1.2','A3.SS4.p2.1'],
 'scope':'target','evidence':'SOURCE_GAP_OPEN'}
graph['nodes'].append(newnode)
graph['routes'].append({
 'id':'R.actualoracleidentification','operator':'AND',
 'prerequisites':['D.potential','D.oracle','S.gradient'],
 'consumer':'G.actualoracleidentification',
 'consumer_use_site':'S2.E1 equality between (f_A,grad f_A) and (quadratic,Ax), consumed in the Borel-algorithm model at S2.SS0.SSS0.Px2.p1.1',
 'step':'Use the actual Euclidean gradient identity proved through G.derivatives, plus literal coordinate transport. Naming/defining the numeric pair alone does not discharge this equality.',
 'provenance':'author-source-assertion-expanded-for-actual-oracle-bridge'})
byroute['R.oracle-borel']['prerequisites']=['G.oraclecontinuous','G.actualoracleidentification']
byroute['R.oracle-borel']['step']='The literal numeric pair is continuous/Borel and the proved gradient identity identifies that pair with the actual oracle. This backward closure reaches S.gradient and G.derivatives; no new public premise is introduced.'
graph['conditional_discharge'][-1]={
 'use':'actual oracle Borel','premise':'numeric pair equals actual value/gradient pair',
 'discharged_by':'G.actualoracleidentification via S.gradient -> G.derivatives; raw S2.E1 states the identity, but D.oracle numeric definition does not prove it'}
graph['topology_delta']=[
 {'issue':'actual-oracle use site omitted the open derivative identity',
  'raw_source_mapping':'S2.E1 explicitly equates the actual value/gradient pair with the numeric pair; S2.SS0.SSS0.Px2.p1.1 consumes actual responses.',
  'change':'Separate literal numeric specification from actual-gradient identification; add G.actualoracleidentification and its route, and require it in R.oracle-borel.',
  'preserved':'Polynomial numeric-pair continuity has no derivative prerequisite; OR completion options remain OR.'},
 {'issue':'conjugation node could be read as an ||x|| sandwich before isometry was consumed',
  'raw_source_mapping':'A3.SS4.p1.1: As A=O Lambda O^T with O orthogonal, this gives the Loewner sandwich.',
  'change':'Narrow G.conjugation to the weighted sum and ||O^T x|| sandwich. R.bounds already consumes G.orthogonalnorm to obtain the ||x|| sandwich.',
  'preserved':'No new source hypothesis, conclusion, or source/signature repair.'}]
write('source-graph-v2.proposal.json',graph)

coverage=copy.deepcopy(json.loads((BASE/'source-coverage.json').read_text()))
coverage['schema']='phase2-source-coverage-successor-proposal-v2'
coverage['phase']='PHASE2_PROPOSED_NOT_INDEPENDENTLY_ACCEPTED'
coverage['predecessor']={'path':str((BASE/'source-coverage.json').relative_to(ROOT)),'sha256':pins['source-coverage.json'],'immutable':True}
coverage['audit_status']='PROPOSED_SUCCESSOR_ONLY; separate challenger must review actual v2 topology and exhaustive coverage; no source-VERIFIED claim.'
coverage['source_graph']={'path':'source-graph-v2.proposal.json','sha256':sha(OUT/'source-graph-v2.proposal.json')}
for item in coverage['paragraph_and_display_inventory']+coverage['formula_and_citation_inventory']:
    if item.get('anchor')=='S2.E1' or item.get('atom_id')=='S2.E1.m1':
        item['nodes'].append('G.actualoracleidentification')
coverage['source_gaps'].append('G.actualoracleidentification')
coverage['counts']['source_nodes']=len(graph['nodes'])
coverage['counts']['routes']=len(graph['routes'])
coverage['counts']['source_gaps']=len(coverage['source_gaps'])
coverage['successor_delta']='Same 32 source units and 120 formula/reference atoms; add the explicit Eq1 actual-gradient use-site obligation and narrow conjugation intermediate. All previous exclusions remain, with no added paper scope.'
write('source-coverage-v2.proposal.json',coverage)

obligations=[
 {'id':'O1','source_nodes':['G.angle','S.angle','S.cosine','S.eigenvalues'],
  'obligation':'Show Fin d index j corresponds to paper index i=j.val+1; hd gives d>0 and 0<theta_j<pi; hκ gives positive cosine scale and 1<lambda_j<κ.'},
 {'id':'O2','source_nodes':['G.symmetry','G.orthogonalnorm','G.conjugation','S.bounds','G.membership'],
  'obligation':'Derive real symmetry, square orthogonal norm preservation, the diagonal weighted-sum identity, and the closed Loewner bounds. Source strict grid bounds are proof results, not theorem binders. Use isometry only after the intermediate ||O^T x|| bound.'},
 {'id':'O3','source_nodes':['D.euclidean','D.potential','G.polynomial','S.cinfty'],
  'obligation':'Identify the EuclideanSpace carrier as WithLp 2 (Fin d -> R), with the supplied L2 norm identity. The literal coordinate quadratic is the source f_A=V_A and is C∞ globally. toLp/ofLp are inverse coordinate transport, not a change to a sup norm.'},
 {'id':'O4','source_nodes':['G.derivatives','S.gradient','S.hessian','G.actualoracleidentification'],
  'obligation':'Prove Df(x)[h]=<Ax,h> and gradient f x=query x internally using symmetry and the Euclidean inner product; prove the gradient derivative is Matrix.toEuclideanCLM A at every x. The supplied action window establishes CLM h=toLp 2 (A *v ofLp h), with no transpose or scaling. ContDiff discharges differentiability, so total gradient/fderiv definitions cannot hide a nondifferentiable default.'},
 {'id':'O5','source_nodes':['G.hessiancriteria','S.strongconvex','S.smooth'],
  'obligation':'Prove the source constants on the Euclidean norm: StrongConvexOn univ 1 expands to the Jensen inequality with (a*b/2)||x-y||^2, equivalent under established differentiability to the source first-order inequality. Prove the actual gradient is κ-Lipschitz, deriving the operator bound from the PSD sandwich or direct diagonal action.'},
 {'id':'O6','source_nodes':['S.zero','S.growth','S.positive','S.minimizer'],
  'obligation':'Evaluate f 0=0, derive f x>=||x||^2/2 and strict positivity for x!=0, and conclude IsMinOn f univ x iff x=0. The lower-growth route is independent of Hessian/normalizer proofs. IsMinOn on univ quantifies every global competitor.'},
 {'id':'O7','source_nodes':['G.oraclecontinuous','G.oracleborel','G.actualoracleidentification'],
  'obligation':'For fixed O (hence fixed A), prove the literal scalar/linear pair continuous and Borel in explicit borel(E) and borel(R x E), and discharge the actual-gradient identification separately. Either direct coordinate polynomial continuity OR factorized scalar-plus-linear continuity suffices; do not conjoin both routes. If a measurable-pair API uses a product measurable instance, align it with the explicit Borel product internally.'},
 {'id':'O8','source_nodes':['S.gradient','G.actualoracleidentification'],
  'obligation':'A proof using only the displayed constant derivative of gradient f must derive gradient f 0=0 before concluding gradient f x=A x. Prefer the direct literal-quadratic gradient identity; never add this identity or a zero-gradient premise to the sealed public interface.'}]
admission={
 'schema':'independent-exact-interface-admission-proposal-v1',
 'status':'PROPOSE_ADMIT_UNCHANGED_EXACT_INTERFACES_FOR_PROOF_SEARCH',
 'limits':'This is a preproof semantic proposal only. No implementation exists in the reviewed input. No compiled theorem, source VERDICT, own coverage approval, lifecycle transition, or proof completion is asserted.',
 'source_revision':packet['source_revision'],
 'source_sha256':packet['source']['sha256'],
 'phase1_freeze_sha256':pins['phase1-freeze.json'],
 'raw_interface_sha256':'22eb732ccf7f4311f2c099e659e008dd0f87aa855c99f995b65a5132a9752207',
 'producer_signature_sha256':packet['producer']['signature_sha256'],
 'private_consumer_signature_sha256':packet['private_consumer']['signature_sha256'],
 'signature_repair_proposed':False,
 'binder_audit':[
  {'binder':'{d : Nat}','class':'TYPING','meaning':'Finite real vector/matrix dimension; hd supplies the actual source restriction.'},
  {'binder':'hd : 2 <= d','class':'SOURCE','anchor':'S4.SS1.p1.1','meaning':'Local hard-family condition, retained exactly.'},
  {'binder':'{κ : R}','class':'TYPING','meaning':'Real source spectral parameter; hκ supplies the actual source restriction.'},
  {'binder':'hκ : 2 <= κ','class':'SOURCE','anchor':'S4.SS1.p1.1','meaning':'Local hard-family condition, retained exactly; no main-theorem upper restriction.'},
  {'binder':'O : Matrix.orthogonalGroup (Fin d) R','class':'SOURCE','anchor':'S2.p2.1; S4.Thmtheorem6.p1.1','expanded':'A finite real matrix satisfying transpose-inverse equations, exactly full O(d). The raw membership windows show both A*A^T=1 and A^T*A=1 equivalents; neither imposes det=+1.'},
  {'binder':'Inferred structures on Nat/Fin d/R/EuclideanSpace/product/Borel','class':'TYPING','meaning':'Canonical finite real Euclidean algebra, topology and measurable carriers, with no project-owned Prop bundles or mathematical witness/gate inputs.'}],
 'excess_binders':[],
 'definition_audit':[
  {'object':'theta','kind':'literal','source':'S4.E11','comparison':'j.val+1/2 equals source (i-1/2) after i=j.val+1; exactly d nodes, no endpoint insertion.'},
  {'object':'A','kind':'literal','source':'S4.E11; S4.SS1.p1.2','comparison':'O diagonal(lambda_j) O.transpose over real matrices; same multiplication order and half factors.'},
  {'object':'f','kind':'literal','source':'S2.SS0.SSS0.Px1.p1.2; A3.SS4.p2.1','comparison':'ofLp x dot (A *v ofLp x) / 2 is exactly x^T A x/2 in the supplied Euclidean coordinate carrier. No fallback, chosen object, normalization, or arbitrary function parameter.'},
  {'object':'query','kind':'literal','source':'S2.E1','comparison':'toLp 2 (A *v ofLp x) is transported source Ax. Actual Euclidean-gradient equality must be proved internally, not inferred from the consumer name.'}],
 'producer_conclusion_overlay':[
  {'exact':'ContDiff R infinity f','source_nodes':['S.cinfty'],'meaning':'C∞ on all Euclidean R^d; supplied definition distinguishes the smooth infinity branch from analytic omega.'},
  {'exact':'forall x, HasFDerivAt (gradient f) (Matrix.toEuclideanCLM A) x','source_nodes':['S.hessian','G.derivatives'],'meaning':'Global derivative of the actual gradient equals the source constant Hessian action A. The supplied action identity sends h to transported A*h; no transpose/coordinate-norm mismatch.'},
  {'exact':'StrongConvexOn univ 1 f','source_nodes':['S.strongconvex'],'meaning':'UniformConvexOn modulus r |-> r^2/2; Jensen form has a*b/2 times ||x-y||^2. It is the source 1-strong convexity convention, with convexity of univ discharged inside the proof.'},
  {'exact':'forall x y, norm(gradient f x-gradient f y)<=κ*norm(x-y)','source_nodes':['S.smooth'],'meaning':'Precisely κ-smooth in actual Euclidean gradient norm; no derivative/covariance scaling.'},
  {'exact':'f 0=0','source_nodes':['S.zero'],'meaning':'Same source normalization at zero, independent of the Gaussian normalizing constant.'},
  {'exact':'forall x, IsMinOn f univ x iff x=0','source_nodes':['S.minimizer'],'meaning':'Exact unique global minimizer, including attainment at zero, not merely stationarity or local minimality.'}],
 'consumer_overlay':{
  'exact':'Measurable from borel(E) to borel(R x E) of x |-> (f x,query x), E=EuclideanSpace R (Fin d)',
  'source_nodes':['D.oracle','C.algorithm','G.oraclecontinuous','G.actualoracleidentification','G.oracleborel'],
  'classification':'Standard-background realization of an omitted source-model bridge; not a verbatim source lemma and not a new source assumption.',
  'actuality_boundary':'Numeric pair is the source Eq1 formula. The interface is concrete, but an actual-oracle claim additionally requires the internally proved gradient equality. Producer constant-Hessian output alone does not fix an affine gradient offset.',
  'measured_variable':'Only x, for each fixed O and κ. Uniform theorem quantification over O is not joint measurability in O.',
  'background':'Finite coordinate polynomial and linear continuity, continuous pairing, continuous-to-Borel. No Gaussian integrability, inverse, determinant, Haar distribution, or target law enters this bridge.'},
 'semantic_deltas':[
  {'kind':'representation','assessment':'faithful-typed-realization','detail':'Fin d is zero-based; source indexing is one-based. WithLp/PiLp2 realizes the same real Euclidean space. Sup norm and SO(d) are not substituted.'},
  {'kind':'equivalent-formulation','assessment':'requires-internal-standard-adapter','detail':'Hessian as derivative of actual gradient; strong convexity as the Jensen inequality; minimizer as an iff on IsMinOn univ. These match the source under the stated literal quadratic/global smoothness.'},
  {'kind':'selected-source-closure','assessment':'explicitly-bounded','detail':'Producer exposes Appendix C.4 geometry. It does not separately output Lemma4.6 Loewner inequalities, all strict eigenvalue bounds, or a precision-class-membership theorem; those remain internal proof ingredients. Do not claim independent publication of the entire Lemma4.6 from this signature alone.'},
  {'kind':'source-implicit-model-bridge','assessment':'explicit-standard-background-extension','detail':'The private actual-oracle Borel consumer formalizes the source model obligation absent as an explicit source theorem. Keep that attribution separate from Appendix C.4 assertions.'}],
 'internal_proof_obligations_not_public_premises':obligations,
 'remaining_boundary':[
  'Every SOURCE_GAP remains unproved at this preproof stage; actual topology/coverage acceptance belongs to the different challenger.',
  'No joint Borel dependence on O, no Haar-instance law or independence theorem, no adaptive/stopped-transcript or randomized output-law construction.',
  'No deterministic cap verification, expected-query cost theorem, exact-oracle query-complexity equivalence, TV bound, or lower-bound theorem.',
  'No Gaussian density/integration, determinant invariance, normalizer, inverse/covariance, or sampling-law claim.',
  'No additional delta/d0/epsilon/kappa<=d^(1-delta) restrictions; the broader ambient d>=1,kappa>=1 class does not broaden this sealed local hard-family theorem.'],
 'versioned_source_graph':{'path':'source-graph-v2.proposal.json','sha256':sha(OUT/'source-graph-v2.proposal.json')},
 'versioned_source_coverage':{'path':'source-coverage-v2.proposal.json','sha256':sha(OUT/'source-coverage-v2.proposal.json')},
 'independent_review_required':'Different-role challenger must inspect this actual v2 successor and the raw interfaces/definitions. This extractor cannot approve its own coverage or issue a source-VERIFIED verdict.'}
write('exact-interface-admission.proposal.json',admission)

# Check only shape, predecessor immutability, node references and closure; not mathematical truth.
ids={n['id'] for n in graph['nodes']}
adj={id:set() for id in ids}
for r in graph['routes']:
    assert r['consumer'] in ids and set(r['prerequisites'])<=ids and r['consumer_use_site']
    adj[r['consumer']].update(r['prerequisites'])
def closure(id):
    seen=set(); todo=[id]
    while todo:
        x=todo.pop()
        if x not in seen: seen.add(x); todo.extend(adj[x])
    return seen
assert {'S.gradient','G.derivatives','G.actualoracleidentification'}<=closure('G.oracleborel')
assert 'G.derivatives' not in closure('G.oraclecontinuous')
assert 'G.orthogonalnorm' not in closure('G.conjugation')
assert 'G.orthogonalnorm' in closure('S.bounds')
assert 'S.hessian' not in closure('S.minimizer')
for name,expected in pins.items(): assert sha(BASE/name)==expected
admission['structural_check_only']={'node_references_valid':True,'actual_oracle_closure_reaches_gradient_obligation':True,'numeric_continuity_derivative_independent':True,'minimizer_hessian_independent':True,'phase1_pins_unchanged':True,'mathematical_or_independent_coverage_approval':False}
write('exact-interface-admission.proposal.json',admission)

raw_inputs=[]
for name in ['initial-raw-input-hashes.json','supplement-raw-input-hashes.json']:
    raw_inputs.extend(json.loads((OUT/name).read_text())['files'])
selected=['source-graph-v2.proposal.json','source-coverage-v2.proposal.json','exact-interface-admission.proposal.json','initial-raw-input-hashes.json','supplement-raw-input-hashes.json']
for name in selected: shutil.copyfile(OUT/name,PUB/name)
files=[]
for path in sorted(OUT.rglob('*')):
    if path.is_file() and path.name!='phase2-freeze.json':
        files.append({'path':str(path.relative_to(ROOT)),'bytes':path.stat().st_size,'sha256':sha(path)})
manifest={
 'schema':'phase2-source-and-exact-interface-proposal-freeze-v1',
 'phase':'PHASE2_PROPOSAL_FROZEN_AWAITING_DISTINCT_CHALLENGER',
 'phase1_predecessor_pins':pins,'raw_inputs':raw_inputs,'files':files,
 'public_mirrors':[str((PUB/name).relative_to(ROOT)) for name in selected],
 'exposure':{
  'authorized':'Pinned raw source/frozen phase1 artifacts; exact raw interface packet and ten standard-definition windows; supplementary full-O, WithLp/PiLp2 norm, matrix-CLM action windows and their supplied manifests.',
  'challenger_findings_seen':'Root transmitted two topology ambiguities, separately authorizing a versioned successor. Both independently assessed as real bookkeeping/use-site defects; no source/signature repair required.',
  'supplement_disclosure':'The authorized supplement manifest itself includes root generic lookup/exposure metadata. Only that disclosure and the supplied raw windows were read; no root prior seal, binder classifications, preseal audit or reuse rationale was opened.',
  'incidental':'One collaboration inventory call displayed an unrelated completed actor status/closeout snippet; no current Gaussian target implementation/proof was exposed or used.',
  'not_read_or_run':'No root full statement-seal/audit/reuse rationale, README/private target proof capsule, Gaussian implementation, source API retrieval, new proof search, Lean construction/check/build, browser/network, model/ATLAS, lifecycle/discovery API or shared/canonical/ledger mutation.',
  'initial_local_capture_error':'First input-copy command had a Path indexing typo and stopped before reading any standard window; corrected command read only the authorized paths.'},
 'verdict_boundary':'This is an admission proposal and versioned graph/coverage proposal. Extractor cannot source-VERIFIED or accept its own coverage; no compiled theorem verdict exists.',
 'next':'Distinct topology challenger reviews the exact successor payloads. Root may then decide preproof admission; implementation/review gates remain separate.'}
write('phase2-freeze.json',manifest)
shutil.copyfile(OUT/'phase2-freeze.json',PUB/'phase2-freeze.json')
for name in ['exact-interface-admission.proposal.json','source-graph-v2.proposal.json','source-coverage-v2.proposal.json','phase2-freeze.json']:
    print(name,sha(OUT/name))
print('source_units=32 atoms=120 nodes='+str(len(graph['nodes']))+' routes='+str(len(graph['routes']))+' gaps='+str(len(coverage['source_gaps'])))
