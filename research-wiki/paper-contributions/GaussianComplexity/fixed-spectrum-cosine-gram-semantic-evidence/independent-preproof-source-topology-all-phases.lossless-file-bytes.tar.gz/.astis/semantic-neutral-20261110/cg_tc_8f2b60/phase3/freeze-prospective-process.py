from pathlib import Path
import hashlib
import json
import os
import stat
import subprocess
from datetime import datetime, timezone

base=Path(__file__).resolve().parent
owner=base.parent
repo=Path('/Users/zhouhuanjian/ASTIS-GC')
W=repo/'.astis/huanjian-gc-fixed-spectrum-cosine-gram-20261110'
E=repo/'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-cosine-gram-semantic-evidence'
sha=lambda b:hashlib.sha256(b).hexdigest()
dump=lambda x:(json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode()
script_sha='0f3970a7f388e783e88f6c4aa8b8676a23daea3d6e4f4ebafa597eaee79e75ed'
private_sha='c282409e8408237f99431e815cf19a71abac8b5dc3420412adecae4200d81981'
preprivate_sha='b66cbc1bc55833a725ac230cdea12fee3529b3ccdd484fcaacf9b18f7fde3d72'
assert sha((W/'admit_normal_intake_prepared.py').read_bytes())==script_sha
assert stat.S_IMODE((W/'admit_normal_intake_prepared.py').stat().st_mode)==0o444
assert sha((W/'intake-baseline.private.json').read_bytes())==private_sha
assert sha((W/'preproof-baseline.private.json').read_bytes())==preprivate_sha
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()=='75dcc0c9c7d9591384c6e0705e118b1ab440cd6c'
assert not (W/'normal-intake-attempted.once.json').exists()
assert not (E/'preproof-source-admission.json').exists()
assert not (W/'intake-tracked-private-preservation.json').exists()
assert not (repo/'AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumCosineGram.lean').exists()
assert not (repo/'Tests/GaussianComplexityFixedSpectrumCosineGram.lean').exists()
safe=json.loads((base/'safe-process-binding-checks.json').read_bytes())
assert safe['normal_API_calls_so_far']==0 and safe['control_path_count']==834 and safe['foreign_control_hash_count']==832
assert safe['restricted_nested_ATLAS_key_count']==0
assert not safe['restricted_nested_directories_traversed_or_contents_read']

independent={}
def bind(path,digest=None,role='frozen-independent-evidence'):
    path=Path(path).resolve();b=path.read_bytes();actual=sha(b)
    if digest:assert actual==digest,str(path)
    key=str(path)
    if key in independent:assert independent[key]['sha256']==actual
    else:independent[key]={'path':key,'sha256':actual,'raw_sha256':actual,'bytes':len(b),'role':role}

math_specs=[
 ('phase1','d67f2864ba332e90e91cc8ba16c09db822f5229e0526b9223e6e920b607bca91','phase1-freeze-receipt.json','c717be0ef061eb6e41b9c06c53003529523a8500fc3e6b4c0e9891c9bd0f320b'),
 ('phase2a','e78c5dbf9db6caa7d8751c3913ef761a4faa8a3f5976b0463110bc73ec55df7c','phase2a-freeze-receipt.json','c0da5191cc33574686d0e97f03f9052c5927cbac0844615771b57db6031ffb16'),
 ('phase2b','eac2f78c05213bb860de05e7a4ccb556fed29b6bef3074ed380238f4a00198bf','phase2b-freeze-receipt.json','875e1afe3fa0c3b8b33b0d1276b7d3441d2ac68b610f7750fc7a87a1d5b7293f')
]
math_bindings=[]
for stage,msha,rname,rsha in math_specs:
    root=owner/stage;mb=(root/'manifest.json').read_bytes();assert sha(mb)==msha
    m=json.loads(mb)
    for entry in m['artifacts']:
        p=root/entry['path'];bind(p,entry['sha256'],'unchanged-prior-mathematical-freeze-artifact')
        assert len(p.read_bytes())==entry['bytes'] and stat.S_IMODE(p.stat().st_mode)==0o444
    for d in [root]+[p for p in root.rglob('*') if p.is_dir()]:assert stat.S_IMODE(d.stat().st_mode)==0o555
    bind(root/'manifest.json',msha,'prior-mathematical-manifest');bind(owner/rname,rsha,'prior-mathematical-freeze-receipt')
    assert stat.S_IMODE((root/'manifest.json').stat().st_mode)==0o444
    assert stat.S_IMODE((owner/rname).stat().st_mode)==0o444
    math_bindings.append({'stage':stage,'manifest_sha256':msha,'receipt_sha256':rsha,'all_original_hashes_and_modes_match':True})
author=repo/'.astis/semantic-neutral-20261110/cg_sg_1d7a46'
author_specs=[
 ('phase1','ededc4db5669a328807c9e0fbf9f719fdc92df4257c878bafd343965e25fb00b','86869756bdcdb1dfe0a33cba6d572705ebee9c6784ecee5660db72c3c00bfd91'),
 ('phase2','d96ad3ac8e44b7f0621d62c620c1c9e4f8e38b626fa4aa2a5b94a0aa0eb02fc9','7b0e78a7cca3ba7ce39fe90f479cb0d264405e6e964b5714cdb0b2b29c6ff801')
]
for stage,msha,rsha in author_specs:
    mp=author/(stage+'_manifest.json');mb=mp.read_bytes();assert sha(mb)==msha
    for entry in json.loads(mb)['files']:
        p=author/stage/entry['path'];bind(p,entry['sha256'],'original-author-source-or-typed-freeze-hash-binding-only')
        assert stat.S_IMODE(p.stat().st_mode)==0o444 and len(p.read_bytes())==entry['bytes']
    for d in [author/stage]+[p for p in (author/stage).rglob('*') if p.is_dir()]:assert stat.S_IMODE(d.stat().st_mode)==0o555
    bind(mp,msha,'original-author-mathematical-manifest');bind(author/(stage+'_receipt.json'),rsha,'original-author-mathematical-receipt')

public_inputs=json.loads((base/'public-input-inventory.json').read_bytes())
E_inputs=json.loads((base/'public-E-inventory.json').read_bytes())+json.loads((base/'supplemental-E-inputs.json').read_bytes())
for r in public_inputs:bind(r['path'],r['raw_sha256'],'actual-root-process-input-reviewed-in-phase3')
for r in E_inputs:bind(r['path'],r['raw_sha256'],'actual-public-preproof-record-or-runtime-evidence')
bind(E.parent/'fixed-spectrum-cosine-gram-statement-seal.json','a5e464a34ee276e62267d21f0965c1a0b1ef905bed27e679a85ecee3cd7fd45c','exact-public-seal')
bind(W/'intake-baseline.private.json',private_sha,'private-raw-hash-only-no-state-export')
bind(W/'preproof-baseline.private.json',preprivate_sha,'private-raw-hash-only-no-state-export')
bind(repo/'.astis/huanjian-resume-20261103/2610.20492v1.html','6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915','pinned-original-paper-raw-hash')
process_input_rows=[r for r in independent.values() if r['role'] in {
 'actual-root-process-input-reviewed-in-phase3','actual-public-preproof-record-or-runtime-evidence','exact-public-seal','private-raw-hash-only-no-state-export','pinned-original-paper-raw-hash'}]
(base/'actual-process-input-bindings.json').write_bytes(dump(process_input_rows))

review={
 'decision':'QUALIFIED_PROSPECTIVE_PROCESS_ONLY','material_unresolved_process_HOLDs':[],
 'not_sourceV_or_mathematical_completion':True,'root_sole_mathematical_worker':True,
 'history_qualification':'Root has disclosed related proof/API knowledge, related-code/source reads, actual preseal raw-source role route exposure and postseal informal uncompiled design. No pristine or prior-free history is claimed or retroactively approved.',
 'mathematical_freezes_unchanged':math_bindings,
 'C6_Ex125_original_mean_link':'Preserve phase2b context-only reading; no formal AND promotion, new mathematical HOLD or repair.',
 'prepared_intake_script_sha256':script_sha,'private_baseline_sha256':private_sha,'private_preproof_baseline_sha256':preprivate_sha,
 'safe_binding_check_path':str(base/'safe-process-binding-checks.json'),
 'success_gate':'Actual receipt exit0 and decoded raw8d399c9a21cb5fcb948fef41f1286aa63635a2ed87e5f3ba4d193a71b2488b42; old exit1/raw5530e21 retained.',
 'metadata_corrections':'Only reader two booleans true->false and explicit library searched-label fields; exact sealed mathematical types unchanged.',
 'runtime_prepared_zero_API':True,'control_count':834,'foreign_control_count':832,
 'private_export':'No full foreign/tracked/frontier/control snapshots exported; hashes, necessary schema/counts and safe binding booleans only.',
 'restricted_nested_ATLAS':'Not traversed/read/hashed; no guarded key names restricted content tree.',
 'script_statically_reviewed_not_executed':True,
 'execution_conditions':['exact raw grant/script/baseline/independent-input hashes','repository cwd','explicit PYTHONOPTIMIZE=0 and sys.flags.optimize=0','no bytecode writes','permanent O_EXCL once marker','normal proposal then CLAIMED then EXPLORING only','exact3 own append events and raw-prefix preservation','foreign states/frontiers/tracked/control hashes and owner postguards','final preservation output and successful complete execution'],
 'on_any_failure':'Readonly inspect actual ledger and marker; no rerun, re-proposal, replay, reset or history rewrite. No target proof/API until a separately legal recovery has been established.',
 'not_authorized':['sourceV','VERIFIED','STAB/stabilization','global lease or owner transfer','shared imports or Registry/site delivery','publication/browser acceptance','new or completed Goal','broader theorem closure','parallel mathematical prover'],
 'current_global_owner':'No lease inspected or granted; optional latest-main-owner process file not read.',
 'current_private_runtime_limit':'Reviewer did not export/replay complete current foreign ledger/filesystem; exact script must freshly enforce private baseline preconditions/postguards.',
 'actual_process_input_bindings_path':str(base/'actual-process-input-bindings.json'),
 'human_review_sha256':sha((base/'prospective-process-review.md').read_bytes())
}
(base/'prospective-process-review.json').write_bytes(dump(review))

for name in ['prospective-process-review.md','prospective-process-review.json','actual-process-input-bindings.json',
             'safe-process-binding-checks.json','private-hash-schema-count-checks.json','public-input-inventory.json',
             'public-E-inventory.json','supplemental-E-inputs.json']:
    bind(base/name,role='actual-independent-phase3-review-evidence')
for p in sorted(base.glob('*.stdout.txt')):bind(p,role='actual-saved-review-command-output')
independent_rows=sorted(independent.values(),key=lambda r:r['path'])
grant={
 'schema':'astis-qualified-prospective-process-grant/v1',
 'decision':'QUALIFIED_PROSPECTIVE','prospective_target_Lean_proof_API_allowed_after_this_grant':True,
 'root_sole_mathematical_worker':True,
 'prepared_intake_script':str(W/'admit_normal_intake_prepared.py'),'prepared_intake_script_sha256':script_sha,
 'private_baseline_path':str(W/'intake-baseline.private.json'),'private_baseline_sha256':private_sha,
 'private_preproof_baseline_sha256':preprivate_sha,
 'independent_inputs':independent_rows,
 'independent_inputs_rule':'Before invocation rehash every exact path; any mismatch invalidates this grant. Do not silently refresh hashes or treat recorded dispositions as proof success.',
 'authorized_once_action':{'advance_id':'ASTIS-SA-20261110-GaussianComplexityFixedSpectrumCosineGram','owner_id':'huanjian_gc_20261110_fixed_spectrum_cosine_gram',
   'normal_API_sequence':['proposal','CLAIMED','EXPLORING'],'permanent_once_marker':str(W/'normal-intake-attempted.once.json'),
   'replay_or_reset_authorized':False},
 'execution_environment':{'cwd':str(repo),'PYTHONOPTIMIZE':'0','sys.flags.optimize':0,'PYTHONDONTWRITEBYTECODE':'1','no_O_flags':True,
   'recorded_prepare_interpreter':'/opt/homebrew/opt/python@3.14/bin/python3.14'},
 'argument_order':['frozen grant path','exact raw grant SHA256 returned by independent freeze receipt','exact private intake-baseline SHA256 c282409e8408237f99431e815cf19a71abac8b5dc3420412adecae4200d81981'],
 'proof_API_authority_is_conditional':True,
 'proof_API_start_condition':'Root alone may start new target Lean proof bodies and exact proof-API retrieval only after this exact script successfully completes all3 normal events, unchanged raw-prefix/foreign/tracked/frontier/control/owner postguards, final own-C metadata/preservation output, and exits0. This Boolean grants no immediate bypass.',
 'on_any_failure':'Stop target proof/API. Inspect actual ledger/once-marker/completed events read-only. Never rerun, re-propose, replay, reset, delete the marker or rewrite history under this grant, even if no special failure receipt was written.',
 'history_not_retroactively_cleaned':review['history_qualification'],
 'mathematical_freeze_boundary':'Prior source/type/topology decisions remain unchanged and unproved implementation obligations remain open; C6 Ex125 original-mean link remains context-only.',
 'preservation_scope':'Exact existing private baseline foreign states, frontiers, tracked regular files and834/832 control paths, including ordinary foreign untracked regular and known ignored queue/control paths; no foreign global ownership, prior V/HOLD, old11 queued packets or PBPS/SPHMC value may be reclassified.',
 'private_data_rule':'Only private hashes/schema/counts are review/grant evidence. Full tracked/foreign snapshots and failure raw ledgers remain private W and must not be copied to public E or prompts.',
 'restricted_ATLAS_rule':'Do not traverse/read/hash nested restricted ATLAS repository contents; no broad claim of their content preservation is made.',
 'not_authorized':review['not_authorized'],
 'no_hash_cycle':'Grant does not reference its own hash or later phase3 manifest/receipt. Its exact raw hash is returned separately; manifest hashes this grant; receipt hashes manifest.'
}
grantpath=base/'prospective-grant.json'
grantpath.write_bytes(dump(grant))
grant_sha=sha(grantpath.read_bytes())

task='''PHASE2b原数学冻结已收到；保留C6 Ex125 original-mean链接context-only限定，勿升级formal AND，也不发明旧HOLD/repair。现单独PHASE3 prospective PROCESS审查（不是数学sourceV）才开放以下root过程输入：W=.astis/huanjian-gc-fixed-spectrum-cosine-gram-20261110 中 statement-seal-v1.json SHAa5e464a34ee276e62267d21f0965c1a0b1ef905bed27e679a85ecee3cd7fd45c、preseal-planning.json、additional-preseal-source-role-exposure.json（真实SG原始source路线消息在seal前到达，未事后伪装pristine）、postseal-informal-planning.json、actual-environment-at-seal.json、StatementFormation.raw.lean.txt、statement-formation.json、seal_statements.py、reserve_frontier_no_intake.py、prepare_normal_intake.py、admit_normal_intake_prepared.py（0444 SHA0f3970a7f388e783e88f6c4aa8b8676a23daea3d6e4f4ebafa597eaee79e75ed）、prepared-intake-safe-summary.json；C=research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-cosine-gram.json 与publicseal/E=fixed-spectrum-cosine-gram-semantic-evidence下全部本packet preproof记录（包括初始格式readerflags待定归位、显式库名标签gate失败5530...与纠正后actualgate8d399...，封存/数学types未改）。自己的所有原数学freezes与author原source/typedfreezes仅用于精确hash绑定。
PRIVATE W/preproof-baseline.private.json SHA b66cbc1bc55833a725ac230cdea12fee3529b3ccdd484fcaacf9b18f7fde3d72 与 W/intake-baseline.private.json SHAc282409e8408237f99431e815cf19a71abac8b5dc3420412adecae4200d81981 可仅核rawhash/必要schema/count，不输出/导出任何full foreign states/tracked snapshots。intake控制路径834/foreign832含普通foreign untracked regular与明确ignored queue路径；nested restricted ATLAS目录不遍历/read/hash内容。当前HEAD75dcc0c9c7d9591384c6e0705e118b1ab440cd6c，ZeroQuery已原actor正常V并完整carry，旧11queued+PBPS/SPHMC+foreignglobalowner仍保留。root无nextnormalproposal/claim/exploring、无目标Lean proof body/API检索，只有Prop-only formation及已披露源文/相关旧code/非编译informal路线设计；不能追认干净或毫无先验。
你只读审查，不执行preparedscript/正常API、不改C或生产source。独立决定是否QUALIFIED PROSPECTIVE允许精确script在显式PYTHONOPTIMIZE=0 activeassertions下按grant file/rawhash/privatebaselineexacthash参数执行一次 normal proposal→CLAIMED→EXPLORING，永久O_EXCLonce marker+全3事件和foreign/rawprefix/postguards通过后才允许root新目标Leanproof/API，失败inspect actualledger不重放/重置。不得sourceV/STAB/global/site/Goal授权。若不允许列具体修复；所有历史/exposure/raw先验限度仍保留。若允许，grant必须有 prospective_target_Lean_proof_API_allowed_after_this_grant=true、root_sole_mathematical_worker=true、prepared_intake_script_sha256、private_baseline_sha256和independent_inputs exact path/rawsha列表，指向你真实冻结的数学与root过程输入，真实证据而非自说同意。新phase3全部原始files0444/manifest+receipt无hashcycle，所有早期数学冻结不改。后续root执行前会重新全量核每个independent_inputs。'''
request='''Phase3读取到的E当前24个原文件仅含143917...失败receipt及解压log5530e21...（两条显式Samplinglib/Mathlib标签失败）；未含你提到的纠正后actual gate8d399... receipt/log。当前C确已加入标签，不能仅据此推断gate已通过。请补送该成功gate的精确原receipt/log路径+hash或其E精确副本；我不运行gate/normalAPI。其余审查仍继续，private baselines只hash/schema/count未复制foreign/tracked内容，prepared script尚未执行。'''
supplement='''正确，E缺成功receipt/log时不能从C推断通过。现已实际exact复制成功原始记录到你开放的同E：20261110T143958682117Z-cosine-gram-preproof-frontier-explicit-prior-libraries.receipt.json 750B SHAe65e67b2820baad2d2298b37154a4691b57fe6649798eb6c49d66e138b6c923a；对应同stem.log.gz 83B SHA9a480ab5a6a2d141177489c4b729aae2b628b3255fcef3405374e15bba87a860，解压rawlog SHA8d399c9a21cb5fcb948fef41f1286aa63635a2ed87e5f3ba4d193a71b2488b42。另已复制 preparedbaseline actual0API runtime：20261110T144250664877Z-cosine-gram-prepare-exact-control-baseline-no-API.receipt.json SHA88cc88cd2207c7c34394a179e8ce2457bc882b9030c83a31ca4f64312ae16364；同stem.log.gz SHA8a15b0adc0d7d15456d3e18c90addb50d003685352de583b9a2363ddd6cf3fc7，rawlog7ad13ccac2c2d6e6133ddbe5bd8ca01dbbc785214649a3b262601d2f09c3de48。原failed5530...保持不变，不重跑gate/任何API。此次只新增4个ownE文件，已有seal/C/script/privatebaselines/HEAD和所有原数学freezes都未改。15:12UTC freshgitfetch实际formalmain/live仍同WeightedRadialMGF STABILIZING（W/latest-main-owner-after-zero-query-complete-carry.json 可仅process参考），无global权。'''
status='''补送4个E原件已核验：成功gate receipt exit0与解压raw8d399...一致，prepared-baseline runtime明确PYTHONOPTIMIZE=0、0API、834/832。独立own-C差分只有reader两项true→false及Samplinglib/Mathlib标签字段，seal/types未改；私有baseline linkage/count与受限ATLAS路径计数0已安全核验，未导出foreign/tracked数据。静态script审查支持QUALIFIED PROSPECTIVE条件授权：仅精确hash脚本一次、全部independent_inputs预验、O_EXCL marker、3事件/rawprefix/foreign/postguards完整成功后root才可新目标proof/API；任何失败只读inspect不得重放。正在形成真实输入绑定的grant与phase3 freeze，尚未执行任何preparedscript/API。'''
last='''源数学/类型/topology冻结及所需成功gate已齐，root仍0新intake/proof/API，只在保留原baseline/HEAD等待你的真实phase3 grant freeze。若还有实质未决约束或缺input，请直接列；若仅整理freeze，可先完成已验证的有限prospective grant并保留未核事项为排除边界，不能为了等root而授予更广权威。root将必须重新核全independent_inputs，不会跳postguards。'''
(base/'communications.json').write_bytes(dump([
 {'direction':'received','sender':'/root','kind':'NEW_TASK','body':task},
 {'direction':'sent','recipient':'/root','tool':'collaboration.send_message','body':request},
 {'direction':'received','sender':'/root','kind':'MESSAGE','body':supplement},
 {'direction':'sent','recipient':'/root','tool':'collaboration.send_message','body':status},
 {'direction':'received','sender':'/root','kind':'MESSAGE','body':last}]))

script_names=['read-initial-process-inputs.py','read-process-bounded.py','read-public-evidence-inventory.py','read-public-evidence.py',
 'read-supplemental-process-evidence.py','check-process-bindings-safe.py','freeze-prospective-process.py']
for name in script_names+['prospective-process-review.md']:
    patch='*** Begin Patch\n*** Add File: '+str(base/name)+'\n'+''.join('+'+line+'\n' for line in (base/name).read_text().splitlines())+'*** End Patch'
    (base/(name+'-actual-addfile.patch')).write_text(patch)
events=[]
def patch(name):events.append({'tool':'apply_patch','input_artifact':name+'-actual-addfile.patch','observed_output':{}})
def cmd(script,args,stdout,chunk,tokens,**extra):
    events.append({'tool':'exec_command','cwd':str(repo),'command':'/opt/anaconda3/bin/python .astis/semantic-neutral-20261110/cg_tc_8f2b60/phase3/'+script+(' '+args if args else ''),
                   'stdout_artifact':stdout,'chunk_id':chunk,'exit_code':0,'original_token_count':tokens,**extra})
patch('read-initial-process-inputs.py');cmd('read-initial-process-inputs.py','','read-initial-process-inputs.stdout.txt','715073',7147,truncation='exec_command transport truncated at6000 tokens; complete stdout saved. Bounded history/formation/seal/scripts and C bindings subsequently inspected.')
patch('read-process-bounded.py')
for mode,chunk,tokens in [('history','220bba',1322),('formation','b0f331',1422),('admit-script','ad56cb',2972),('prepare-script','5e161b',1776),('reserve-script','6c0975',2653),('seal-script','c25a4f',2418)]:
    cmd('read-process-bounded.py',mode,'read-process-'+mode+'.stdout.txt',chunk,tokens)
patch('read-public-evidence-inventory.py');cmd('read-public-evidence-inventory.py','','read-public-evidence-inventory.stdout.txt','e890c0',2527)
events.append({'tool':'exec_command','cwd':str(repo),'command':'git rev-parse HEAD','stdout':'75dcc0c9c7d9591384c6e0705e118b1ab440cd6c\n','chunk_id':'44e219','exit_code':0,'original_token_count':11})
patch('read-public-evidence.py')
cmd('read-public-evidence.py','diagnostics','read-E-diagnostics.stdout.txt','9259ec',1042)
cmd('read-public-evidence.py','formation-logs','read-E-formation-logs.stdout.txt','c53911',915)
events.append({'tool':'collaboration.send_message','input_locator':'communications.json request entry','observed_output':{}})
patch('read-supplemental-process-evidence.py');cmd('read-supplemental-process-evidence.py','','read-supplemental-process-evidence.stdout.txt','8667cd',783)
cmd('read-public-evidence.py','historical-C','read-E-historical-C.stdout.txt','ce7280',940)
cmd('read-process-bounded.py','seal','read-process-seal.stdout.txt','d9e553',3356)
patch('check-process-bindings-safe.py');cmd('check-process-bindings-safe.py','','check-process-bindings-safe.stdout.txt','ee2c13',1130)
events.append({'tool':'collaboration.send_message','input_locator':'communications.json status entry','observed_output':{}})
patch('prospective-process-review.md');patch('freeze-prospective-process.py')
events.append({'tool':'exec_command','cwd':str(repo),'command':'/opt/anaconda3/bin/python .astis/semantic-neutral-20261110/cg_tc_8f2b60/phase3/freeze-prospective-process.py',
 'stdout_locator':'External phase3-freeze-receipt.json and tool stdout hashes','exit_code_policy':'Failure aborts; successful freeze returns grant/manifest/receipt hashes and verifies immutable files.'})
(base/'command-transcript.json').write_bytes(dump({'stage':'PHASE3_READONLY_PROSPECTIVE_PROCESS','events':events,'review_command_failures':[],
 'historical_gate_failure_retained':{'exit_code':1,'raw_log_sha256':'5530e21ab9f2b3767bdcb50884f37854cf046027bcd9718ebf4977284a4e1c66'},
 'no_preparedscript_or_normal_API_executed':True,'private_snapshot_export':False}))
(base/'exposure.json').write_bytes(dump({
 'stage':'PHASE3 only after immutable mathematical phase2b freeze','mathematical_freezes_used_only_for_exact_hash_binding':True,
 'original_author_source_typed_freezes_used_only_for_hash_binding':True,
 'root_process_inputs':str(base/'actual-process-input-bindings.json'),
 'supplement_request_recorded_without_inference_of_missing_success_gate':True,
 'root_prior_exposure_not_retroactively_pristine':True,'root_optional_main_owner_file_read':False,
 'private_baselines':'Raw hashes, necessary schema/counts and safe linkage booleans only; no full foreign/tracked/control/frontier snapshot copied.',
 'restricted_nested_ATLAS_read_or_traversed_or_hashed':False,
 'no_preparedscript_normal_API_Leanproof_sourceV_STAB_global_site_Goal_execution':True,
 'writes':'Own phase3 artifacts only; no C/production/old math/author source or typed artifact modified.',
 'transport_truncation':'Initial7147-token command output transport truncated; full actual stdout saved and bounded semantic rereads recovered used inputs.',
 'decision':'QUALIFIED_PROSPECTIVE_PROCESS_ONLY','scope_exclusions':review['not_authorized']}))

artifacts=[]
for f in sorted(base.rglob('*'),key=lambda p:str(p.relative_to(base))):
    if not f.is_file() or f==base/'manifest.json':continue
    b=f.read_bytes();artifacts.append({'path':str(f.relative_to(base)),'bytes':len(b),'sha256':sha(b),'frozen_mode':'0444'})
manifest={'kind':'qualified-prospective-process-review-freeze','stage':'PHASE3','decision':'QUALIFIED_PROSPECTIVE',
 'grant_path':str(grantpath),'grant_sha256':grant_sha,'independent_input_count':len(independent_rows),
 'mathematical_freezes_unchanged':math_bindings,'artifacts':artifacts,
 'permissions':{'files':'0444','all_phase3_directories':'0555'},
 'private_data_boundary':'No private full foreign/tracked snapshots archived; only hashes/schema/counts/safe booleans.',
 'no_hash_cycle':'Grant excludes own hash/manifest/receipt. Manifest hashes grant and excludes itself/external receipt. External receipt hashes manifest; receipt own hash printed only.'}
(base/'manifest.json').write_bytes(dump(manifest))
for f in base.rglob('*'):
    if f.is_file():os.chmod(f,0o444)
dirs=[base]+[d for d in base.rglob('*') if d.is_dir()]
for d in sorted(dirs,key=lambda p:len(p.parts),reverse=True):os.chmod(d,0o555)
for entry in artifacts:
    p=base/entry['path'];assert sha(p.read_bytes())==entry['sha256'] and stat.S_IMODE(p.stat().st_mode)==0o444
assert stat.S_IMODE((base/'manifest.json').stat().st_mode)==0o444
assert all(stat.S_IMODE(d.stat().st_mode)==0o555 for d in dirs)
for r in independent_rows:assert sha(Path(r['path']).read_bytes())==r['sha256'],r['path']
receipt={'kind':'PHASE3-qualified-prospective-process-freeze-receipt','utc':datetime.now(timezone.utc).isoformat(),
 'decision':'QUALIFIED_PROSPECTIVE','grant_path':str(grantpath),'grant_sha256':grant_sha,
 'manifest_sha256':sha((base/'manifest.json').read_bytes()),'process_review_md_sha256':sha((base/'prospective-process-review.md').read_bytes()),
 'prepared_intake_script_sha256':script_sha,'private_baseline_sha256':private_sha,'private_preproof_baseline_sha256':preprivate_sha,
 'independent_input_count':len(independent_rows),'all_independent_input_hashes_match_at_freeze':True,
 'verified_files_0444':len(artifacts)+1,'verified_directories_0555':len(dirs),
 'all_prior_mathematical_freezes_and_original_author_freezes_unchanged':True,
 'preparedscript_or_normal_API_or_target_proof_executed_by_reviewer':False,
 'private_foreign_tracked_snapshot_export':False,'restricted_nested_ATLAS_content_access':False,
 'conditional_scope':'One exact pinned normal proposal->CLAIMED->EXPLORING attempt; root alone may start new target proof/API only after all3 events and every preservation postguard/final output succeed. Any failure: readonly inspect actual ledger; no replay/reset.',
 'no_sourceV_STAB_global_site_or_Goal_authority':True,'history_not_retroactively_cleaned':True,
 'no_hash_cycle':'Receipt outside phase3 and not an input to manifest/grant; its raw hash printed only.',
 'next_action':'Return frozen grant and pause. Root must freshly verify every independent_inputs row before the exact qualified once execution.'}
rp=owner/'phase3-freeze-receipt.json';rp.write_bytes(dump(receipt));os.chmod(rp,0o444)
print(json.dumps({'receipt_path':str(rp),'receipt_sha256':sha(rp.read_bytes()),**receipt},ensure_ascii=False,indent=2))
