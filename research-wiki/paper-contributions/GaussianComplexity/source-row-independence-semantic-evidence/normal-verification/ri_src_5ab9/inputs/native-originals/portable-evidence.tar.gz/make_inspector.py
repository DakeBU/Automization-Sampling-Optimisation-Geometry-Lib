"""Generate independent native inspection; prior inspector is syntax scaffold only."""
import json,re
from run import ROOT,REPO
m=json.loads((ROOT/'input-manifest.json').read_text())
scaffold=REPO/'.astis/semantic-neutral-20261112/rl_native_52e9/scratch/InspectAllV2.lean'
s=scaffold.read_text()
s=s.replace('import Tests.GaussianComplexityFixedSpectrumSourceRowLaw','import Tests.GaussianComplexityFixedSpectrumSourceRowIndependence')
s=re.sub(r'private def modules : List String := .*', 'private def modules : List String := '+json.dumps([p[:-5].replace('/','.') for p in m['modules']]),s)
s=re.sub(r'IO.FS.writeFile "[^"]+"','IO.FS.writeFile "'+str(ROOT/'native-all-bodies.json')+'"',s)
s=s.replace('#check @MeasureTheory.integral_map','')
(ROOT/'scratch/InspectAll.lean').write_text(s)
seal=json.loads((ROOT/'inputs/research-wiki/paper-contributions/GaussianComplexity/source-row-independence-statement-seal.json').read_text())
s='import Tests.GaussianComplexityFixedSpectrumSourceRowIndependence\nimport Lean\nopen MeasureTheory ProbabilityTheory Lean Elab Command\nset_option autoImplicit false\n'
for label,k in [('Producer','producer'),('Consumer','actual_private_consumer')]:
    sig=seal[k]['signature'];assert sig.count('(hq : 2 * q + 1 < d) :\n')==1
    s+='def IndependentLiteral'+label+' : Prop := ∀ '+sig.replace('(hq : 2 * q + 1 < d) :\n','(hq : 2 * q + 1 < d),\n')+'\n'
s+='''
run_cmd do
  let env := (← getEnv).setExporting false
  setEnv env
  let producer := `AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumSourceRowIndependence.actual_source_rows_independent
  let roots := env.constants.toList.filter fun (n,_) => n == producer ||
    n.toString.endsWith ".actual_truncated_matrices_measurable_and_independent"
  unless roots.length == 2 do throwError "Wrong actual roots {roots.map Prod.fst}"
  for (n,c) in roots do
    let key := if n == producer then "IndependentLiteralProducer" else "IndependentLiteralConsumer"
    let literal := Name.mkSimple key
    let some expected := env.find? literal | throwError "Missing independent literal"
    let some typ := expected.value? true | throwError "Missing independent literal body"
    unless c.levelParams == [] do throwError "Unexpected universes {n}"
    liftCoreM <| addDecl <| Declaration.thmDecl {
      name := Name.mkSimple (key ++ "AppliedActual")
      levelParams := []
      type := mkConst literal
      value := mkConst n
    }
    logInfo m!"INDEPENDENT_SEAL_KERNEL_APPLICATION_PASS {n}"
    logInfo m!"INDEPENDENT_RAW_EXPR_EQUAL {n}: {c.type == typ}"
#print axioms IndependentLiteralProducerAppliedActual
#print axioms IndependentLiteralConsumerAppliedActual
'''
(ROOT/'scratch/IndependentLiteralCheck.lean').write_text(s)
api='''import Tests.GaussianComplexityFixedSpectrumSourceRowIndependence
open MeasureTheory ProbabilityTheory
set_option autoImplicit false
set_option pp.universes true
set_option pp.explicit true
set_option pp.proofs true
#check @ProbabilityTheory.map_pi_eq_stdGaussian
#print ProbabilityTheory.map_pi_eq_stdGaussian
#check @MeasureTheory.measurePreserving_pi
#check @MeasureTheory.measurePreserving_piCongrLeft
#check @MeasureTheory.Measure.infinitePi_eq_pi
#check @MeasureTheory.Measure.infinitePi_map_curry_symm
#check @MeasureTheory.Measure.infinitePi_map_curry
#check @ProbabilityTheory.iIndepFun_iff_map_fun_eq_pi_map
#check @ProbabilityTheory.iIndepFun.comp
#print ProbabilityTheory.iIndepFun
#print ProbabilityTheory.iIndep
#print ProbabilityTheory.iIndepSets
example (d : ℕ) : IsProbabilityMeasure (stdGaussian (EuclideanSpace ℝ (Fin d))) := inferInstance
example : IsProbabilityMeasure (gaussianReal 0 1) := inferInstance
example (q : ℕ) : IsProbabilityMeasure (Measure.pi (fun _ : Fin (q+1) => gaussianReal 0 1)) := inferInstance
example (d q : ℕ) : IsProbabilityMeasure (Measure.pi (fun _ : Fin (q+1) => stdGaussian (EuclideanSpace ℝ (Fin d)))) := inferInstance
example (d q : ℕ) : IsProbabilityMeasure (Measure.pi (fun _ : Fin (q+1) × Fin d => gaussianReal 0 1)) := inferInstance
example (q : ℕ) : SigmaFinite (Measure.pi (fun _ : Fin (q+1) => gaussianReal 0 1)) := inferInstance
example (d : ℕ) : SigmaFinite (stdGaussian (EuclideanSpace ℝ (Fin d))) := inferInstance
example (d : ℕ) : Measure.map (WithLp.toLp 2 : (Fin d → ℝ) → EuclideanSpace ℝ (Fin d))
    (Measure.pi (fun _ : Fin d => gaussianReal 0 1)) = stdGaussian (EuclideanSpace ℝ (Fin d)) := map_pi_eq_stdGaussian
'''
(ROOT/'scratch/StandardApplicability.lean').write_text(api)
print(json.dumps({'own_generated': ['InspectAll.lean','IndependentLiteralCheck.lean','StandardApplicability.lean'],'scaffold_only':str(scaffold.relative_to(REPO))}))
