from pathlib import Path
from hashlib import sha256
from bs4 import BeautifulSoup
p=Path('.astis/huanjian-resume-20261103/2610.20492v1.html')
b=p.read_bytes()
s=BeautifulSoup(b,'html.parser')
print('AUTHORS',[(x.get('class'),x.get_text(' ',strip=True)) for x in s.select('.ltx_authors')])
e=s.find(id='bib.bib3'); print('REFERENCE bib.bib3', e.get_text(' ',strip=True) if e else 'MISSING')
for ident in ['A3.SS2.p3','A3.SS2.p4','A3.SS2.p5','A3.SS2.p6','A3.SS2.p7','A3.SS2.p8']:
 e=s.find(id=ident)
 print(ident,'CHILDREN',[(x.name,x.get('id')) for x in e.children if getattr(x,'name',None)])
