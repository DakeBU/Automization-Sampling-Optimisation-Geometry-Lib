Postproof source-to-Lean MAPPING author proposal v1；未执行Lean、证明/API搜索、sourceV或发布批准。P/T原始字节分别498b9844…、c2d369b5…；精确signature仍为4d5056…/082eda…。

11项映射把冻结的repaired SG/raw source与实际Lean regions、50个actual-used canonical声明逐一连接；554个实际direct constants全部分类。source topology、kernel实际父边、conceptual实现对应分别记录，不由import/source轮廓推断编译依赖。

实际range路线经两个Polynomial.Sequence的degreeLT spans与加权线性evaluation。hpower对所有Nat n包含0，使用真正matrix diagonal powers；有限weighted-polynomial lift由F线性及span/comap transport表达。T直接调用P后仅用K⊆image及Set.range存在定义取同一个c；不重复column-span/scaling父边。T的显式Euclidean norm与signed inner分开映射到来源display等式部分，不声称其邻接不等式或由绝对值等式反推signed equality。

Kernel原log/receipt原样封存：T实际公开ASTIS父仅P，P无其他公开ASTIS父；两generated certificates无public数学节点。六lesson代码块均精确连续，step6为完整private Test。候选binding7b97440e…仅作为已授权输入记录，不授予接受。

四个定位查询非零退出及五个canonical span边界修正保留原输出/旧片段；没有清洗log。所有原始输入的copied snapshots、exact spans、实际脚本/命令输出与proposal封存在本目录，未修改原代码/旧freeze/公共metadata/ledger/Git。等待独立exact-candidate mapping/source/exposition复核。
