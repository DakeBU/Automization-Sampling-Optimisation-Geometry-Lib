from pathlib import Path
from html.parser import HTMLParser
import datetime, hashlib, html, json, re, bisect

ROOT=Path('/Users/zhouhuanjian/ASTIS-GC')
OUT=ROOT/'.astis/semantic-neutral-20261113/structure_sg_a94e'
SRC=ROOT/'.astis/huanjian-resume-20261103/2610.20492v1.html'
b=SRC.read_bytes(); s=b.decode('utf-8')
assert hashlib.sha256(b).hexdigest()=='6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
starts=[0]+[m.end() for m in re.finditer('\n',s)]
def locator(a,z):
    return {'char_start':a,'char_end_exclusive':z,'byte_start':len(s[:a].encode()),
            'byte_end_exclusive':len(s[:z].encode()),'line_start_1based':bisect.bisect_right(starts,a),
            'line_end_1based':bisect.bisect_right(starts,max(a,z-1))}
class Parser(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=False); self.stack=[]; self.nodes=[]
    def at(self):
        line,col=self.getpos(); return starts[line-1]+col
    def handle_starttag(self,tag,attrs):
        self.stack.append({'tag':tag,'attrs':dict(attrs),'a':self.at()})
        if tag in {'meta','link','br','img','hr','input','wbr','source'}: self.stack.pop()
    def handle_endtag(self,tag):
        for i in range(len(self.stack)-1,-1,-1):
            if self.stack[i]['tag']==tag:
                n=self.stack[i]; n['z']=self.at()+len(tag)+3
                self.nodes.append(n); self.stack=self.stack[:i]; break
def text(raw):
    math=[]
    def protect(m):
        math.append(html.unescape(m[1])); return f' MATHPLACEHOLDER{len(math)-1} '
    raw=re.sub(r'<math\b[^>]*alttext="([^"]*)"[^>]*>.*?</math>',protect,raw,flags=re.S)
    raw=re.sub(r'<annotation\b.*?</annotation>','',raw,flags=re.S)
    raw=re.sub('<[^>]+>',' ',raw)
    raw=re.sub(r'\s+',' ',html.unescape(raw)).strip()
    return re.sub(r'MATHPLACEHOLDER(\d+)',lambda m:'$'+math[int(m[1])]+'$',raw)
p=Parser();p.feed(s)
manifest={'version':2,'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'original_sha256':hashlib.sha256(b).hexdigest(),'fix':'Protect math alttext before stripping HTML tags; preserves less-than symbols.',
          'v1_preserved':True,'scopes':{},'outputs':{}}
for key,sid in [('c2','A3.SS2'),('s4','S4')]:
    scope=next(n for n in p.nodes if n['attrs'].get('id')==sid)
    nodes=[]
    for n in sorted(p.nodes,key=lambda n:n['a']):
        if scope['a']<=n['a']<scope['z'] and n['tag'] in {'p','table','h2','h3','h4','h6'}:
            if n['tag']=='table' and 'ltx_equation' not in n['attrs'].get('class',''): continue
            raw=s[n['a']:n['z']]
            nodes.append({'id':n['attrs'].get('id',f"heading-{n['a']}"),'tag':n['tag'],**locator(n['a'],n['z']),
                          'raw_sha256':hashlib.sha256(raw.encode()).hexdigest(),'text':text(raw)})
    for name,data in [(f'{key}-raw-blocks.v2.json',json.dumps(nodes,ensure_ascii=False,indent=2)+'\n'),
                      (f'{key}-readable.v2.txt','\n\n'.join(f"{n['id']} | lines {n['line_start_1based']}-{n['line_end_1based']} | chars [{n['char_start']},{n['char_end_exclusive']}) | bytes [{n['byte_start']},{n['byte_end_exclusive']})\n{n['text']}" for n in nodes)+'\n')]:
        (OUT/name).write_text(data); manifest['outputs'][name]=hashlib.sha256(data.encode()).hexdigest()
    manifest['scopes'][sid]=locator(scope['a'],scope['z'])
(OUT/'RAWFREEZE.v2.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(manifest,indent=2))
