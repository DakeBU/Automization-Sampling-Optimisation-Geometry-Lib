"""PREPARED ONLY. Each future window requires its own ROOT authorization and exact authorization SHA."""
from verification_common import *
import argparse,traceback

def target_counts(s):
    rows=[x for x in s['records'] if x.get('advance_id')==ADV]
    return rows,sum(x.get('to_state')=='PROVED_LOCAL' for x in rows),sum(x.get('to_state')=='VERIFIED' for x in rows)
def inspect_target(s,x,expected):
    target=s['adv'][ADV];rows,plcount,vcount=target_counts(s)
    assert target['state']==expected and target['owner_id']==OWNER and target['publication_declarations']==[P] and target['target_declarations']==[P]
    assert plcount==1 and vcount==(0 if expected=='PROVED_LOCAL' else 1)
    assert next(r['evidence'] for r in rows if r.get('to_state')=='PROVED_LOCAL')==x['pl']
    assert any(sha(line+b'\n')==PLAPPENDSHA for line in s['araw'].splitlines())
    return target
def payload(a,x,authpath):
    extra={
      'verifier_id':VERIFIER,'verified_commit':a['carrier_commit'],
      'gate':{'exact_checked_source_carrier':a['carrier_commit'],'six_actual_exit0_records':x['gates']['records'],'gate_summary':a['gate_summary'],'normal_API_publication_gate':'Actual transition_advance invokes check_advance with reviewed=True before append; no manual append or synthetic receipt.','new_Lean_build_at_source_carrier':False},
      'source_audit':{'binding':BINDING,'canonical_public_audit':x['pins']['public_audit'],'private_material_consumer_audit':x['pins']['private_audit'],'P_seven_slot_review':x['pins']['P_source_review'],'T_seven_slot_review':x['pins']['T_source_review'],'wholemodule_full_review':x['pins']['source_full_run'],'exact_six_scope_successor_review':x['pins']['source_successor_run'],'decoder_verification_receipt':x['pins']['decoder_receipt'],'original_source_blind_reconstruction_is_distinct_from_native_or_reader':True,'new_source_reaudit_claimed':False},
      'semantic_roundtrip_audit':{'state':'source-reviewed','public_audit':x['pins']['public_audit'],'private_audit':x['pins']['private_audit'],'publication_binding_sha256':BINDING,'independent_source_reviewer':'trace_exp_fresh_source_51c8','blind_decoder':'trace_domain_blind_decoder_8a39','source_fidelity_not_inferred_from_compilation_or_browser':True},
      'fake_closure_scan':{'actual_built_math_identity':MATH,'native_report':x['pins']['native_carried'],'original_native_report':x['pins']['native_original'],'actual_canonical_scan':x['pins']['native_fake_scan'],'all11_exact_ASTIS_sources_fresh_recompiled':True,'prior_ASTIS_olean_reused':False,'recursive_type_and_value_closure_checked':58863,'standard_axioms':['Classical.choice','Quot.sound','propext'],'unsafe':0,'sorryAx_or_unauthorized_axiom':False,'no_new_build_or_kernel_scan_at_source_carrier':True},
      'current_independent_reader_acceptance':{'exact_original_report':x['pins']['reader_original'],'exact_carried_report':x['pins']['reader_carried'],'original_explicit77_leaf_manifest':x['pins']['reader_manifest_original'],'status':'PASS_BOUNDED_ISOLATED_READER','necessary_reader_residuals':0,'actual_browser_exit_code':0,'actual_checks':389,'actual_false_checks':0,'original_PNGs_actually_viewed':36,'limits':copy.deepcopy(x['reader']['nonblocking_limits']),'unmeasured_boundaries':copy.deepcopy(x['reader']['unmeasured_boundaries']),'reader_acceptance_not_production_or_physical_touch':True},
      'original24_PL_retention':{'original_payload':x['pins']['PL'],'original_payload_sha256':PLSHA,'original_field_count':24,'all_original_fields_inline_equal':True,'reader_pending_at_PL_is_retained_as_historical_snapshot':True},
      'actual_verified_scope':'One public finite nonempty real-Hermitian all-real-s ordinary trace/cardinality/L2-operator-norm envelope, with its actual private four-family scalar Gaussian material consumer checked. No separate public T node, full matrix MGF/Lieb/Bernstein/master-tail/C6/main bound, integration, production/site/global graph, purification or whole-Goal completion.',
      'verified_carrier_vs_actual_build':'The verified_commit identifies the exact source/metadata/evidence carrier checked now. The independent fresh Lean/type/value/kernel build remains immutable30172847ec40c24426f0b39afc4887719810eca0, not ef5cfe9, bare1db9 or a later source/public carrier.',
      'authorization':ident(authpath)
    }
    assert not(set(extra)&set(x['pl']))
    result=copy.deepcopy(x['pl']);result.update(extra);assert all(result[k]==v for k,v in x['pl'].items())
    return result

def normal_window(a,authpath):
    marker=PRIVATE/'normal-V-attempted.once.json';assert not marker.exists()
    x=evidence_inputs(a);before=snapshot('window1-before',a);target=inspect_target(before,x,'PROVED_LOCAL')
    assert not git('window1-worktree-clean','diff','--name-only','HEAD','-z') and not git('window1-index-clean','diff','--cached','--name-only','-z')
    assert file_sha(REPO/CELL)==a['expected_target_cell_sha256'] and read(REPO/CELL)['status']=='proved_locally'
    for i,(raw,h) in enumerate(SOURCES.items()):assert sha(git('window1-carrier-source'+str(i),'show',a['carrier_commit']+':'+raw))==h
    v=payload(a,x,authpath);write(OWN/'normal-V-evidence.full.json',v)
    sys.path.insert(0,str(REPO));from tools import astis_advance as api
    assert api.DEFAULT_ADVANCE_LEDGER==REPO/ADVPATH and api.DEFAULT_DISCOVERY_LEDGER==REPO/DISCPATH
    # Durable once-marker must precede the sole normal API invocation.
    write(marker,{'local_private_do_not_publish':True,'advance_id':ADV,'verifier_id':VERIFIER,'carrier':a['carrier_commit'],'authorization_sha256':file_sha(authpath),'payload_sha256':file_sha(OWN/'normal-V-evidence.full.json'),'API_attempt_about_to_begin_once':True,'utc':dt.datetime.now(dt.timezone.utc).isoformat()})
    returned=False;error=None
    try:
        api.transition_advance(ADV,'VERIFIED',worker_id=VERIFIER,modes=tuple(target.get('modes',())),evidence=v)
        returned=True
    except BaseException:
        error=traceback.format_exc();print(error,file=sys.stderr)
    # Inspect actual suffix after either return or exception. Never re-invoke or roll back.
    current=(REPO/ADVPATH).read_bytes();exact(PRIVATE/'window1-actual-ledger-after-call.jsonl',current)
    suffix=current[len(before['araw']):] if current.startswith(before['araw']) else None
    if suffix is not None:exact(PRIVATE/'window1-actual-suffix.raw',suffix)
    write(PRIVATE/'window1-API-return.private.json',{'returned':returned,'exception':error,'old_prefix_preserved':suffix is not None,'actual_suffix_sha256':sha(suffix) if suffix is not None else None,'automatic_retry_or_rollback':False})
    after=snapshot('window1-after',a);guards=postguards(before,after,a,{ADVPATH})
    assert returned and error is None and suffix and suffix.endswith(b'\n') and len(suffix.splitlines())==1
    appended=json.loads(suffix);assert appended['event']=='transition' and appended['advance_id']==ADV and appended['from_state']=='PROVED_LOCAL' and appended['to_state']=='VERIFIED' and appended['worker_id']==VERIFIER and appended['evidence']==v
    assert all(appended['evidence'][k]==value for k,value in x['pl'].items())
    actual=inspect_target(after,x,'VERIFIED');assert actual['modes']==target['modes']
    exact(OWN/'normal-V-exact-append.jsonl',suffix)
    write(OWN/'window1-postguards.public.json',{'advance_id':ADV,'all_postguards_passed':True,'all_frontiers_including_target_unchanged':True,'original24_top_level_fields_unchanged':True,'exact_appended_record_sha256':sha(suffix),'exact_appended_record_bytes':len(suffix),'actual_normal_API_returned':True,'normal_API_calls':1,'guards':guards,'all_full_guard_maps_API_logs_ledger_index_snapshots_local_private':True,'actual_math_build_identity':MATH,'new_Lean_or_reader_run':False})
    print(json.dumps({'window':'normal-proof-V','advance_id':ADV,'normal_API_calls':1,'all_postguards_passed':True,'exact_appended_record_sha256':sha(suffix)}),flush=True)

def differences(a,b,path=''):
    if type(a) is not type(b):return [path]
    if isinstance(a,dict):return sum((differences(a[k],b[k],path+'/'+k) if k in a and k in b else [path+'/'+k] for k in sorted(set(a)|set(b))),[])
    if isinstance(a,list):return [] if a==b else [path]
    return [] if a==b else [path]
def select_public_evidence(label,success):
    names=['verification_common.py','verification_driver.py',label+'-OS-receipt.public.json']
    if success:
        names+=['PROVED_LOCAL-original24.exact.json','normal-V-evidence.full.json','normal-V-exact-append.jsonl','normal-V-outcome.public.json','window1-postguards.public.json']
        if label=='window2':names+=['window1-OS-receipt.public.json','window1-public-selected-originals.manifest.json','window2-postguards.public.json','target-cell-outcome.public.json']
    else:names+=[label+'-stopped.public.json']
    assert len(names)==len(set(names)) and all('/' not in n and 'private' not in n for n in names)
    leaves=[{'path':n,'bytes':(OWN/n).stat().st_size,'sha256':file_sha(OWN/n)} for n in names]
    write(OWN/(label+'-public-selected-originals.manifest.json'),{'schema':'r16-single-verification-window-explicit-own-public-leaves-v1','advance_id':ADV,'window':label,'actual_success_with_postguards':success,'files':leaves,'full_guards_ledger_index_git_output_API_raw_streams_excluded':True,'real_OS_receipt_public_copy_is_byte_exact':True,'OS_receipt_environment':'Explicit child whitelist only: HOME/PATH/LC_ALL/PYTHONDONTWRITEBYTECODE/PYTHONIOENCODING/GIT_OPTIONAL_LOCKS/ASTIS_ATLAS_ROOT. Literal known local paths; no inherited environment dump, credentials or ATLAS body.','no_raw_stdout_stderr_payload_append_or_receipt_rewrite':True})
def cell_window(a,authpath):
    marker=PRIVATE/'target-cell-attempted.once.json';assert not marker.exists()
    vout=json.loads(pin_bytes(a['window1_outcome']));assert vout['normal_API_calls']==1 and vout['actual_exit_code']==0 and vout['all_window1_postguards_passed'] and vout['all_frontiers_including_target_unchanged'] and vout['verified_commit']==a['carrier_commit']
    assert file_sha(OWN/'normal-V-exact-append.jsonl')==vout['exact_appended_record_sha256']
    x=evidence_inputs(a);before=snapshot('window2-before',a);inspect_target(before,x,'VERIFIED')
    assert sha(before['araw'])==a['expected_advance_ledger_sha256'] and sha(before['draw'])==a['expected_discovery_ledger_sha256']
    assert {n.decode() for n in git('window2-worktree','diff','--name-only','HEAD','-z').split(b'\0') if n}=={ADVPATH}
    oldraw=(REPO/CELL).read_bytes();assert sha(oldraw)==a['expected_target_cell_sha256'];old=json.loads(oldraw)
    assert old['status']=='proved_locally' and old['owner_id']==OWNER and old['advance_id']==ADV
    exact(PRIVATE/'window2-target-cell.before.exact.json',oldraw);new=copy.deepcopy(old);new['status']='independently_verified';e=new['evidence']
    e['independent_verification']={'verifier_id':VERIFIER,'normal_V':ident(OWN/'normal-V-outcome.public.json'),'current_reader':x['pins']['reader_carried'],'actual_math_build_identity':MATH,'source_binding':BINDING}
    e['normal_V']={'state':'VERIFIED','actual_calls':1,'actual_exact_append':ident(OWN/'normal-V-exact-append.jsonl'),'actual_normal_outcome':ident(OWN/'normal-V-outcome.public.json'),'verifier_id':VERIFIER,'verified_source_carrier':a['carrier_commit']}
    e['current_normal_stage'].update({'advance_state':'VERIFIED','cell_status':'independently_verified','theorem_VERIFIED':True,'normal_independent_proof_VERIFIED_calls':1,'verifier_id':VERIFIER,'verified_source_carrier':a['carrier_commit'],'actual_math_build_identity':MATH})
    e['reader_review'].update({'actual_browser_and_visual':'PASS_BOUNDED_ISOLATED_READER','current_acceptance':x['pins']['reader_carried'],'actual_browser_exit_code':0,'actual_checks':389,'actual_false_checks':0,'actual_original_PNGs':36,'blocking_reader_residuals':0,'physical_touch_or_production_acceptance':False})
    new['consumer_scope']['first_realistic_consumer']['state']='ACTUAL_PRIVATE_COMPILED_MATERIAL_CONSUMER; immutable301728 native/source and isolated reader accepted within one independent normal proof VERIFIED for public P; no separate public T node. Stabilization remains pending.'
    new['reuse_plan']['new_shared_declarations_status']='ACTUAL_IMMUTABLE301728_P_WITH_MATERIAL_PRIVATE_T; independent native/source/isolated reader accepted; normalPL1 and independent normal proofV1; integration/purification pending.'
    prefix=x['pl']['truth_boundary'].split('Main/shared imports/Registry/sourceIndex/global graph/site integration',1)[0]
    assert old['truth_boundary'].startswith(prefix)
    new['truth_boundary']=prefix+'One normal PROVED_LOCAL and one independent normal VERIFIED now exist for public P, with its private material consumer checked and no extra public T node. The verified source/evidence carrier is '+a['carrier_commit']+'; the actual fresh native Lean build remains immutable301728. The accepted isolated reader is separate from main/shared imports/Registry/sourceIndex/global graph/site integration, physical touch, purification and full-paper/whole-Goal completion; those remain held/open.'
    new['phase_snapshot']='PL1 and one independent normal proofV by '+VERIFIER+' at source/evidence carrier '+a['carrier_commit']+'. Immutable301728 native/source and the actual isolated reader are accepted; no new build or browser run. API window kept every frontier unchanged; only this cell is projected in this separately authorized second window. Main/site/global integration, original stabilization ownership and purification/full-paper remain held/open.'
    changed=differences(old,new);allowed=['/status','/evidence/independent_verification','/evidence/normal_V','/evidence/current_normal_stage','/evidence/reader_review','/consumer_scope/first_realistic_consumer/state','/reuse_plan/new_shared_declarations_status','/truth_boundary','/phase_snapshot']
    assert all(any(k==base or k.startswith(base+'/') for base in allowed) for k in changed)
    for k in ['target_statement','private_consumer_statement','statement_seal','source_anchor','source_proof_coverage','semantic_roundtrip','purification']:assert old[k]==new[k]
    assert new['consumer_scope']['first_realistic_consumer']['public_node'] is False and new['consumer_scope']['second_realistic_consumer']==old['consumer_scope']['second_realistic_consumer']
    sys.path.insert(0,str(REPO));from tools import astis_frontier_cells as cells
    probe=copy.deepcopy(new);probe['__path__']=CELL;assert not cells.validate_cells([probe])
    raw=(json.dumps(new,ensure_ascii=False,indent=2)+'\n').encode();exact(PRIVATE/'window2-target-cell.projected.exact.json',raw)
    write(marker,{'local_private_do_not_publish':True,'advance_id':ADV,'authorization_sha256':file_sha(authpath),'about_to_project_only_target_cell':True,'before_sha256':sha(oldraw),'after_sha256':sha(raw)})
    with (REPO/CELL).open('wb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
    after=snapshot('window2-after',a);guards=postguards(before,after,a,{CELL},cell_exception=CELL)
    assert before['araw']==after['araw'] and before['draw']==after['draw'] and (REPO/CELL).read_bytes()==raw
    write(OWN/'window2-postguards.public.json',{'advance_id':ADV,'all_postguards_passed':True,'only_target_cell_projected':True,'target_status':'independently_verified','changed_field_paths':changed,'before_cell_sha256':sha(oldraw),'after_cell_sha256':sha(raw),'both_ledgers_exact':True,'normal_API_calls':0,'all_other_tracked_frontiers_modes_HEAD_branch_index_unchanged':True,'source_sealed_math_and_other_target_semantics_unchanged':True,'guards':guards,'normal_V_outcome':ident(OWN/'normal-V-outcome.public.json')})
    print(json.dumps({'window':'target-cell','advance_id':ADV,'target_status':'independently_verified','all_postguards_passed':True,'normal_API_calls':0}),flush=True)

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--window',choices=['NORMAL_PROOF_V_ONCE','TARGET_CELL_PROJECTION_ONCE'],required=True);p.add_argument('--authorization',type=Path,required=True);p.add_argument('--authorization-sha256',required=True);p.add_argument('--child',action='store_true');args=p.parse_args()
    a=validate_authorization(args.authorization,args.authorization_sha256,args.window)
    if args.child:
        if args.window=='NORMAL_PROOF_V_ONCE':normal_window(a,args.authorization)
        else:cell_window(a,args.authorization)
        return 0
    label='window1' if args.window=='NORMAL_PROOF_V_ONCE' else 'window2';directory=PRIVATE/(label+'-OS-process');directory.mkdir(parents=True,exist_ok=False)
    out=directory/'stdout.raw';err=directory/'stderr.raw';argv=[sys.executable,str(Path(__file__).resolve()),*sys.argv[1:],'--child'];env={'HOME':'/Users/zhouhuanjian','PATH':str(Path(sys.executable).parent)+':/usr/bin:/bin','LC_ALL':'C','PYTHONDONTWRITEBYTECODE':'1','PYTHONIOENCODING':'utf-8','GIT_OPTIONAL_LOCKS':'0','ASTIS_ATLAS_ROOT':str(REPO/'.atlas-upstream/v1')}
    started=dt.datetime.now(dt.timezone.utc).isoformat();start=time.monotonic()
    with out.open('xb') as o,err.open('xb') as e:
        child=subprocess.Popen(argv,cwd=REPO,env=env,stdin=subprocess.DEVNULL,stdout=o,stderr=e);code=child.wait()
    receipt={'schema':'r16-independent-single-verification-window-actual-OS-receipt-v1','window':args.window,'argv':argv,'cwd':str(REPO),'pid':child.pid,'parent_pid':os.getpid(),'started_utc':started,'ended_utc':dt.datetime.now(dt.timezone.utc).isoformat(),'elapsed_seconds':time.monotonic()-start,'actual_exit_code':code,'raw_stdout':{'local_private':True,'bytes':out.stat().st_size,'sha256':file_sha(out)},'raw_stderr':{'local_private':True,'bytes':err.stat().st_size,'sha256':file_sha(err)},'authorization_sha256':file_sha(args.authorization),'scripts':a['scripts'],'actual_OS_fd1_fd2_captured_separately':True,'automatic_retry_rollback_or_window2_launch':False}
    write(directory/'receipt.private.json',{**receipt,'environment_explicit_whitelist':env,'stdout_file':str(out.relative_to(REPO)),'stderr_file':str(err.relative_to(REPO))})
    exact(OWN/(label+'-OS-receipt.public.json'),(directory/'receipt.private.json').read_bytes())
    if code!=0:
        write(OWN/(label+'-stopped.public.json'),{'status':'ACTUAL_FAILURE_STOP_NO_RETRY_NO_ROLLBACK','advance_id':ADV,'actual_exit_code':code,'API_attempt_marker_present':(PRIVATE/'normal-V-attempted.once.json').exists(),'actual_suffix_and_private_raw_logs_must_be_inspected_before_any_future_action':True,'no_success_or_cell_projection_claimed':True});select_public_evidence(label,False);return code
    if label=='window1':
        g=read(OWN/'window1-postguards.public.json');assert g['all_postguards_passed']
        outcome={'schema':'r16-independent-normal-proof-V-actual-public-outcome-v1','status':'NORMAL_V_ACTUALLY_RECORDED_AND_ALL_POSTGUARDS_PASSED','advance_id':ADV,'verified_commit':a['carrier_commit'],'verifier_id':VERIFIER,'normal_API_calls':1,'actual_exit_code':code,'original24_top_level_fields_unchanged':g['original24_top_level_fields_unchanged'],'exact_appended_record_sha256':g['exact_appended_record_sha256'],'exact_appended_record_bytes':g['exact_appended_record_bytes'],'actual_normal_API_returned':True,'all_window1_postguards_passed':True,'all_frontiers_including_target_unchanged':True,'actual_math_build_identity':MATH,'new_build_claimed_at_verified_carrier':False,'exact_append':ident(OWN/'normal-V-exact-append.jsonl'),'full_inline_payload':ident(OWN/'normal-V-evidence.full.json'),'actual_OS_receipt':ident(OWN/'window1-OS-receipt.public.json'),'raw_OS_streams_API_logs_full_ledgers_index_guards_private':True,'separate_target_cell_projection':'Not executed by window1; requires another ROOT authorization and fresh guards.'}
        write(OWN/'normal-V-outcome.public.json',outcome)
    else:write(OWN/'target-cell-outcome.public.json',{'schema':'r16-independent-target-cell-projection-actual-public-outcome-v1',**read(OWN/'window2-postguards.public.json'),'actual_exit_code':code,'actual_OS_receipt':ident(OWN/'window2-OS-receipt.public.json')})
    select_public_evidence(label,True)
    print(json.dumps({'window':args.window,'advance_id':ADV,'actual_exit_code':code,'status':'COMPLETED_WITH_POSTGUARDS','next_window_automatically_launched':False}),flush=True)
    return 0
if __name__=='__main__':sys.exit(main())
