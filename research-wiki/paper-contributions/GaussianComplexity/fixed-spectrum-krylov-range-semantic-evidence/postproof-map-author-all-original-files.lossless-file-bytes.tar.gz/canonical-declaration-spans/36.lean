def range (f : ι → α) : Set α := {x | ∃ y, f y = x}
