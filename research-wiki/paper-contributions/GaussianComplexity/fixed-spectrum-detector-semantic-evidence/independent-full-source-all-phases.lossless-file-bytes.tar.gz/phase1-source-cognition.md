# Phase 1: independent source-first cognition

Status: **SOURCE COGNITION FROZEN; NO CANDIDATE VERDICT.**

Reviewer scope: source reviewer only. This is neither a Lean proof, an implementation review, a source-proof-graph extraction, nor acceptance of a source-facing declaration. No exact candidate type, implementation, statement seal, decoder reconstruction, native review, old source review, or candidate consumer has been read. Later phases must compare against this record without rewriting it.

## Input and independence boundary

The mathematical source is Huanjian Zhou and Taiji Suzuki, *On Complexity of Gaussian Sampling*, arXiv:2610.20492v1, pinned local HTML:

`/Users/zhouhuanjian/ASTIS-GC/.astis/huanjian-resume-20261103/2610.20492v1.html`

Bytes: `951991`; SHA256: `6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915`.

The deliberate substantive reading comprises the abstract, full §1, full §2, full §4 (including §4.4), and full Appendix C. This includes every displayed formula in those scopes through the HTML MathML `alttext`, without substring clipping. The title/authors and the bibliography entry actually cited as [22] were also read from this same HTML. External reference [22] is identified by the paper as OpenAI (2026), *Subpolynomial query complexity for well-conditioned log-concave sampling*, an OpenAI Math Release preprint. Its external contents were not consulted or independently validated.

The phase assignment already disclosed the broad source interests (Eq. 11, the intrinsic statistic, strict event, eigenvector geometry, target coordinate/probability step) and the unverified report that focused Lean/native checks have passed. This is prior exposure, not evidence for source fidelity. It supplied no exact Lean target, type, declaration names, or implementation route. The AGENTS file itself includes unrelated project scheduling/status text and process lessons; those were necessarily visible when reading the applicable AGENTS but no referenced project data was opened.

I have general pre-existing mathematical knowledge of orthogonal linear algebra, polynomial evaluation, Chebyshev polynomials, Gaussian transformations/moments, and probability inequalities. I do not claim pretrained ignorance or absence of possible prior familiarity with the subject. All source-specific assertions below are pinned to the paper read here, and standard mathematical expansions are labeled as such.

One metadata lookup used an overly broad `ltx_authors` substring class match and accidentally emitted the full rendered article into a **truncated** tool output (original output about 30,635 tokens). This exposed additional raw-paper material outside the intended scopes, including portions of §3 / Appendix A / Appendix B / bibliography; it was not an implementation or prior-verdict exposure. I do not claim that every line in that truncated emission was available or fully read. The same lookup also read bibliography IDs `bib.bib22` and `bib.bib10`, whose displayed labels are actually [19] and [23]; they were not used as the intended [22] source. A corrected lookup read `bib.bib3`, the displayed [22]. The exposure manifest records this accident explicitly.

## Overall source understanding

The problem is sampling the centered Gaussian `π_A = N(0,A⁻¹)` for an unknown real symmetric precision matrix with `I_d ⪯ A ⪯ κ I_d`, using exact matrix-vector queries. Exact value-and-gradient, gradient-only, and matrix-vector oracle access are equivalent for these quadratics. Algorithms are Borel functions of an input-independent random seed and past replies; their query budget is a deterministic cap for **every** input and seed. Their output accuracy is measured after averaging their internal randomness, uniformly over admissible inputs (§2, Eq. 2).

Section 4 hides an eigenbasis while keeping the spectrum deterministic and potentially public. It extends a `[1,2]` construction to `[1,κ]`. The lower bound of Theorem 4.1 is

`∀ δ ∈ (0,1), ∃ d₀(δ), ∀ integers d ≥ d₀(δ), ∀ κ ∈ [2,d^(1−δ)], ∀ ε ∈ (0,1/10], Q_G(d,κ,ε) ≥ (δ/256) √κ log d`.

The dimension threshold depends only on δ; the proof's estimates are uniform over κ, q, and ε in the stated ranges. This theorem does not acquire an ε-dependent lower bound and does not claim the same route beyond the condition-number regime (§4.4). Knowledge of the full spectrum is permitted and does not invalidate this hardness construction.

The proof uses: a source-derived Krylov representation for arbitrary adaptive output (Lemma 4.3); a uniform cosine quadratic-form bound on the entire random Krylov space (Lemma 4.4); target moments and variances (Lemma 4.5); and admissibility (Lemma 4.6). The source's probability test is an intrinsic function of `A`, although its analysis is easiest in hidden eigen-coordinates. This record describes their meanings, without proposing a graph or inferring any implementation dependencies.

## Seven semantic slots

These seven explicitly named slots are the source-only comparison checklist for subsequent phases. They do not assert that a candidate realizes them.

### Slot 1 — carriers, indexing, coordinate convention

- Real Euclidean vectors `x ∈ ℝ^d`, real `d×d` matrices, standard inner product, Euclidean norm, transpose, and the identity matrix are the carriers. `O(d) = {O : OᵀO = I_d}` uses Haar probability (§2).
- Source indices are **one-based**, `i=1,…,d`; the coordinate vector is `e_i`. The **columns** `Oe_i` are eigenvectors in the original coordinates. A latent vector is `u = Oᵀx`; the original vector is `x = Ou` (Appendix C.1).
- A zero-based finite-index rendering must replace `(i−1/2)` by `(i+1/2)` after converting its index to a real number. Keeping `(i−1/2)` with a zero-based index shifts the grid and changes the construction.
- No probability or nonzero-vector restriction is needed for the raw quadratic-form coordinate identity. Normalized weights require `x ≠ 0`.

### Slot 2 — quantified data, ranges, and randomness

- The hard family definition in §4.1 assumes integer `d ≥ 2` and real `κ ≥ 2`. Eq. 11 fixes `θ_i`, `λ_i`, and `Λ` **before** drawing `O`.
- `O ~ Haar(O(d))` is independent of the algorithm's private randomness; `A = OΛOᵀ` is the random input. Admissibility and the target probability estimate hold for **every** orthogonal `O`, not merely Haar-almost every `O`.
- `q` is a nonnegative integer; in Lemmas 4.3–4.4, `2q+1 < d`. The proof sets the positive odd integer `n=2q+1`. Lemma 4.5 is stated for every integer `1 ≤ n < d`, without the oddness restriction.
- Lemma 4.3 constructs `q+1` mutually independent standard Gaussian vectors on an extension preserving the original joint law. It does **not** state that these vectors are independent of `O`, `X`, or the full extended experiment. The coefficients in `OᵀX = Σ_a p_a(Λ)g_a` may depend on the full experiment.
- `C>0` in `τ_{d,q}` is an absolute constant, chosen sufficiently large for the concentration lemma. The source does not replace this by an arbitrary unqualified numerical C.

### Slot 3 — literal hard-family definitions and intrinsic polynomial

Eq. 11 (`S4.E11`) is

`θ_i = ((i−1/2)π)/d`,

`λ_i = (κ+1)/2 + ((κ−1)/2) cos θ_i`,

`Λ = diag(λ_1,…,λ_d)`, `A = OΛOᵀ`.

For `d≥2, κ≥2`, `0<θ_i<π`, hence `1<λ_i<κ`; all λ are positive. The λ are distinct because the grid increases within `(0,π)` and cosine is strictly decreasing there. `A` is real symmetric positive definite and lies in the admissible class. The potential is `xᵀAx/2`; its target is `π_A=N(0,A⁻¹)`. The determinant and normalizing constant are fixed across O (Appendix C.4).

Let `H_A = (2A−(κ+1)I_d)/(κ−1)`. The division is scalar division of a matrix by the nonzero scalar `κ−1`. `T_n` is the degree-n Chebyshev polynomial of the first kind; the source statistic uses the ordinary **matrix polynomial** `T_n(H_A)`. It is not entrywise application of a scalar function and not an arbitrary witness matrix satisfying a convenient quadratic identity.

The literal identities from orthogonal conjugation and polynomial evaluation are

`H_A = O diag(cos θ_i) Oᵀ`,

`T_n(H_A) = O diag(T_n(cos θ_i)) Oᵀ = O D_n Oᵀ`,

where `D_n=diag(cos(n θ_i))`. The source gives the intrinsic formula and the scalar identity `T_n(cos θ)=cos(nθ)`; the conjugation/evaluation expansion is a standard mathematical bridge, not a new source premise.

### Slot 4 — statistic and strict event on the whole vector carrier

At §4.3 (`S4.EGx2`), with `τ=τ_{d,q}`,

`S_A(x) := (−1)^n xᵀ T_n(H_A) x − 2τ ‖x‖²`,

`E_A := {x : S_A(x) > 0}`.

This is a literal definition for all `x∈ℝ^d`. Its event is **strictly positive**. Values at exactly zero are excluded, so replacing `>` by `≥` changes the event and requires a separate null-boundary argument if probabilities are to agree. No such replacement is part of the definition. In particular `S_A(0)=0`, and `0∉E_A`, regardless of the later ratio discussion. For fixed A it is a continuous real quadratic polynomial and `E_A` is Borel (indeed open); this is a standard measurability bridge.

Keeping the source's `(−1)^n` matters: the target signed mean is positive. In the actual lower-bound proof n is odd, so the sign can be simplified to −1 only after preserving `n=2q+1`. An event for the **absolute** cosine coefficient alone accepts the opposite sign and is not the source event.

### Slot 5 — eigenvector geometry and normalized energy weights

For all x and orthogonal O, `u_i=(Oᵀx)_i=⟨x,Oe_i⟩`, and

`xᵀ O D_n Oᵀ x = Σ_i cos(nθ_i) |⟨x,Oe_i⟩|²`.

For `x≠0`, define exactly the source weights

`w_i(x)=|⟨x,Oe_i⟩|²/‖x‖²`.

The numerator is **squared projection on an eigenvector**, not the original coordinate `x_i²` unless O is the identity. Orthogonality gives `w_i≥0` and `Σ_i w_i=1`. Thus these are fractions of total energy in the eigenvectors of A. The statistic divided by `‖x‖²` is

`S_A(x)/‖x‖² = (−1)^n Σ_i w_i(x)cos(nθ_i) − 2τ`.

Therefore, for `x≠0`,

`x∈E_A ↔ (−1)^n Σ_i w_i(x)cos(nθ_i) > 2τ`.

This equivalence uses `‖x‖²>0`; it is not a formula that defines the weights at x=0. In the source τ≥0, so this also says that the coefficient has target sign and absolute value greater than 2τ. It does not say that every energy-weight vector is realizable by an algorithm. Individual eigenvector signs do not affect squared projections, and the intrinsic polynomial expression avoids using a choice of eigenbasis as the public definition.

### Slot 6 — target coordinate law, moments, and probability transfer

For **fixed** orthogonal O and `A=OΛOᵀ`, an exact sample `Y~π_A` satisfies `U=OᵀY ~ N(0,Λ⁻¹)` (§4.2). In the random-O experiment the paper states this conditionally as `Y | O ~ π_A`. The standard covariance transformation is

`Oᵀ A⁻¹ O = Λ⁻¹`.

The pointwise identities `‖Y‖²=‖U‖²` and `Yᵀ O D_n Oᵀ Y=UᵀD_nU` identify the actual source statistic under the law transform. In particular

`S_A(Y) = (−1)^n UᵀD_nU − 2τ‖U‖²`

and the strict event probability is the probability that this real random variable is `>0`. This is an exact event/law identity, not yet a concentration estimate. It applies to every fixed O; Haar invariance of Y itself is not required.

Lemma 4.5 defines `M=E‖U‖²=tr(Λ⁻¹)`, `μ_n=E[UᵀD_nU]=tr(D_nΛ⁻¹)`, `ρ=(√κ−1)/(√κ+1)`, and `β=|μ_n|/M`. For `κ≥2,1≤n<d`,

`M=(d/√κ)(1−ρ^(2d))/(1+ρ^(2d))`,

`(−1)^n μ_n=(d/√κ)(ρ^n−ρ^(2d−n))/(1+ρ^(2d))>0`,

`Var(‖U‖²)≤2M`, `Var(UᵀD_nU)≤2M`, and `M≤d/√κ`.

If additionally `d−n≥√κ`, then

`(1−exp(−4))exp(−3n/√κ) ≤ β ≤ exp(−2n/√κ)`.

The positivity of M and the sign identity are derived from the hard family and the n-range, rather than extra assumptions of its source-facing result. Finite fourth moments/integrability used in these formulas are properties of the target Gaussian, not arbitrary added hypotheses.

For `Z=S_A(Y)`, once the proof has derived `τ≤1/2`, `τ≤β/4`, and `Mβ²≥320`, it obtains

`EZ=(β−2τ)M≥βM/2>0`,

`Var Z≤(√(2M)+2τ√(2M))²≤8M`,

`π_A(E_A)=P(Z>0)≥1−Var Z/(EZ)²≥1−32/(Mβ²)≥0.9`.

The variance step uses the L² triangle inequality for centered variables, not independence of the two quadratic statistics (which generally are dependent). The strict-event Chebyshev bridge is `{Z≤0} ⊆ {|Z−EZ|≥EZ}` when EZ>0. It needs no assertion that `P(Z=0)=0`.

### Slot 7 — assumption provenance, output side, and remaining theorem boundary

`τ_{d,q}=C[(q+1)√(log d/d)+(q+1)(q+1+log d)log d/d]` (`S4.Ex13`). The target moments, norm conservation, coordinate covariance identity, polynomial conjugation identity, and event measurability are source consequences / standard bridges to be proved or supplied internally. Their mere availability as producer lemmas must not silently turn them into extra public hypotheses of a full faithful source anchor.

For a q-query output X, Lemma 4.3 gives latent Krylov membership and Lemma 4.4 simultaneously controls every vector in that Krylov space with probability at least 0.99 (under `2q+1<d` and `τ≤1/2`). Consequently the source obtains `|XᵀOD_nOᵀX|≤2τ‖X‖²`, hence `S_A(X)≤0`, on that event. This gives the **random-input average** `E_A[ρ_A^Alg(E_A)]≤0.01`. It does not give that bound for every fixed A.

The target estimate is in the opposite quantifier position: `π_A(E_A)≥0.9` for **every** hard-family A. The algorithm's presumed TV accuracy is also **per admissible input**, so `π_A(E_A)−ρ_A^Alg(E_A)≤ε` before averaging. The contradiction is `0.89≤E_A[π_A(E_A)−ρ_A^Alg(E_A)]≤ε≤0.1`.

The smallness/large-mean conditions are derived uniformly by taking d large depending only on δ. They are not premises of Theorem 4.1. A bounded coordinate/event lemma may legitimately state orthogonality, the literal family relation, and its natural typing/ranges; that alone does not close the target moments, Krylov representation/concentration, asymptotic uniformity, TV comparison, or the query lower bound. No such closure is certified in this phase.

## Definitions and standard bridges that a later comparison must preserve

1. **Orthogonal inverse and eigen-coordinates:** a square real orthogonal matrix has `OOᵀ=OᵀO=I`, inverse Oᵀ, columns an orthonormal basis, and norm-preserving transpose action. These expand the source's use of O(d); they are not new source restrictions.
2. **Matrix polynomial transport:** constant polynomial evaluates to a scalar multiple of I; powers conjugate using `OᵀO=I`; finite linear combinations then give `p(ODOᵀ)=Op(D)Oᵀ`. This supports the intrinsic statistic, without replacing its definition by spectral coordinates.
3. **Diagonal evaluation:** `p(diag a_i)=diag(p(a_i))`; pair with `T_n(cosθ_i)=cos(nθ_i)`. Matrix division is scalar division and κ−1 must be nonzero.
4. **Energy coordinates:** `Σ_i |(Oᵀx)_i|²=‖x‖²` and real `|r|²=r²`; division by positive squared norm gives normalized weights only for nonzero x.
5. **Law and event transport:** the Gaussian linear-image law, inverse-conjugation identity, and pointwise statistic equality give equality of pushforward event probabilities. One must retain the actual event and strict inequality, not just equality of means.
6. **Probability inequality:** finite second moments of Z permit Chebyshev; the source uses positivity of EZ to bound its lower tail including equality at zero. The variance estimate comes from centered L² norm subadditivity.
7. **A-dependent TV test:** the event may depend on fixed input A, since the TV bound is imposed separately for that A. Averaging the bounded measurable event probability over random O is a later operation. No fixed universal x-event independent of A is demanded by the source.

These are mathematically ordinary bridges identified from reading the source; no claim is made here about which library declarations exist or which have been compiled.

## Appendix C reading: what supports the source meaning

- **C.1:** latent coordinates, Haar-state revelations and Gaussianization explain the independent Gaussian generators, the extended experiment, and the extra output generator. The uniform bound must permit experiment-dependent polynomial coefficients; replacing it by a bound for fixed coefficients misses this source issue.
- **C.2:** the cosine-polynomial basis has triangular invertible correspondence with powers of Λ because λ is a nonconstant affine function of cos θ. The block matrix B has range exactly the Krylov space. Cosine sums make its unweighted expected Gram matrix identity and weighted expected Gram matrix zero; matrix Bernstein with truncation controls both simultaneously. The final bound is uniform over the entire space and independent of κ. Concentration details are not additional premises of the literal detector definition.
- **C.3:** the absolutely/uniformly convergent inverse-spectrum cosine expansion, finite-grid alias sums, independent diagonal Gaussian coordinates, and the bounds on `log(1/ρ)` establish the exact moments and target bias. The finite-grid correction `ρ^(2d−n)` and denominator `1+ρ^(2d)` are part of the formula, not negligible terms erased by the definition.
- **C.4:** open angular endpoints imply strict `1<λ_i<κ`; orthogonal conjugation gives admissibility. The normalization is independent of O because Λ is fixed.

## Boundaries and cautions visible before any candidate

- The literal statistic exists throughout its declared vector carrier; restricting only to a latent coordinate formula or excluding x=0 changes the public interface unless an explicit correspondence theorem restores it.
- The normalized energy reading is a nonzero-vector characterization, not the global definition. A totalized weight function returning zero at x=0 can be a formal convenience only if its off-source convention is stated and does not change the intrinsic event.
- Correct eigenvectors are `Oe_i`; using rows, `Oᵀe_i`, or x_i in the original basis generally changes the geometry.
- A formula with `|coefficient|>2τ` omits the target sign; a closed threshold changes the strict event; matrix entrywise Chebyshev changes the statistic.
- `n=2q+1` implies oddness, but the moment lemma's general n and sign must not be confused with a theorem valid only at odd n.
- Target probability is not merely an averaged-in-O statement. Algorithm probability is not strengthened to a pointwise-in-A statement by the source's argument.
- A distribution named “target” needs the actual covariance law `N(0,A⁻¹)` and its coordinate law, not a synthetic variable with only the desired moment inequalities.
- The hard-family hypotheses imply positivity, distinctness, admissibility, and moments; a full source-facing result may not simply assume the estimates that the proof must derive.
- Section 4.4 discusses limitations of this **analysis**, and explicitly leaves open stronger lower bounds for the same fixed-spectrum family. This is not a mathematical impossibility theorem for the family.
- One wording in §4.4 says the separating test requires the uniform supremum at most 1/2, while the displayed Lemma 4.4 bound is 2τ. The asymptotic proof can choose τ smaller as d grows; this wording is not used here to redefine τ or create a new candidate assumption. It is outside the central literal-statistic/coordinate identity comparison and would need its own scope if a later candidate claims that limitation in full.

## Subsequent review contract and pause

Phase 2 may compare only a specifically supplied anonymous exact type and a source-blind reconstruction whitelist against these seven slots. It must distinguish literal agreement, compatible abstraction with required downstream discharge, missing public semantics, excess premises, changed quantifiers, and genuinely out-of-scope obligations. Phase 3 may inspect the supplied actual definitions, full module/proof, consumer, correspondence, and reader material. No native/old source verdict has been requested or relied upon.

This Phase 1 establishes a frozen source reading, not mathematical `PROVED`, source-V acceptance, topology acceptance, publication acceptance, whole-Goal acceptance, or any verdict on unseen candidate material.
