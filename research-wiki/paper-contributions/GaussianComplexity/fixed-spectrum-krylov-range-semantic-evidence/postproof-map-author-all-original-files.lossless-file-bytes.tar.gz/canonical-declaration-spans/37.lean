def span (s : Set M) : Submodule R M :=
  sInf { p | s ⊆ p }
