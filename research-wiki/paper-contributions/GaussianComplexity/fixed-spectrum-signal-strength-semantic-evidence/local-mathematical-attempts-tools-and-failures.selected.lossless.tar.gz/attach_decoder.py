from pathlib import Path
import json,hashlib,sys
sys.dont_write_bytecode=True
sys.path.insert(0,'tools')
import astis_semantic_roundtrip as rt
W=Path('.astis/huanjian-gc-fixed-spectrum-signal-strength-20261110')
E=Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-signal-strength-semantic-evidence')
D=Path('.astis/semantic-neutral-20261110/d_5fa921')
sha=lambda b:hashlib.sha256(b).hexdigest()
dump=lambda x:(json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode()
def put(p,b):
    assert not p.exists(),p
    p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
runpath=D/'decoder_run.json'
runsha='fcc114cd45aae53287cb04fc69f364c2ebd158ddeaf0968a5c73f738804c6c2c'
assert sha(runpath.read_bytes())==runsha
assert (D/('decoder_run.freeze.'+runsha+'.json')).read_bytes()==runpath.read_bytes()
r=json.loads(runpath.read_bytes());rec=json.loads((D/'reconstruction.json').read_bytes())
assert sha((D/'reconstruction.json').read_bytes())=='58d802cc261cc81e8c7021649a56665c7b8ba8d23f5ee440ffcbd5d012cb6e89'
assert r['decoder_identity']=='/root/decoder_e5297c' and rec['source_text_visible'] is False
assert r['source_text_visible'] is False and rec['decoder_run_sha256']==runsha
body={k:v for k,v in rec.items() if k!='decoder_run_sha256'}
assert sha(json.dumps(body,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())==r['reconstruction_body_sha256_excluding_decoder_run_sha256']
text=rec['reconstructed_theorem_text']
assert sha(text.encode())==r['reconstructed_text_sha256']==rec['reconstructed_text_sha256']=='40a28047a12b20cb58ba450a33f1219c7291e8e6ecdc05aa9b77bdd0dae549f9'
p=Path('research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-signal-strength.json')
old=p.read_bytes();a=json.loads(old)
assert a['state']=='draft' and a['reconstruction']=={}
packet=rt.decoder_packet(a);rb=r['read_artifacts'][0]
assert packet['packet_sha256']==rb['canonical_packet_sha256']=='93cdb9a25d4d79c0fa365437fc859052fea99cb5cc6006c1779ce779ccf967d9'
assert sha((D/'input.json').read_bytes())==rb['raw_sha256']=='8c809b61bae65aeb3bd42d89a778cce27a409008822f9f177d9b249b8024fdab'
a['state']='blind-reconstructed'
a['reconstruction']={'text':text,'text_sha256':sha(text.encode()),'decoder':r['decoder_identity'],'source_text_visible':False,'lean_statement_sha256':a['lean']['statement_sha256'],'decoder_packet_sha256':packet['packet_sha256'],'decoder_run_sha256':runsha,'input_artifacts':packet['input_artifacts'],'ambient_cues_disclosed':[r['ambient_exposure']],'zero_ambient_cues_claimed':False}
for x in sorted(D.iterdir()):
    if x.is_file():put(E/'independent-decoder-e5297c'/x.name,x.read_bytes())
put(E/'audit-before-independent-reconstruction.raw.json',old)
p.write_bytes(dump(a))
full=rt.semantic_reviewer_packet(a)
assert all(x is False for x in full['anti_anchoring'].values())
put(E/'fresh-source-reviewer-packet.json',dump(full))
s=json.loads((W/'statement-seal-v1.json').read_bytes())
head,body=s['actual_private_consumer']['signature'].split(' :\n',1)
consumer='∀'+head.removeprefix('private theorem actual_gaussian_source_query_zero_event_le_tenth')+',\n'+body
white={'schema_version':1,'task':'selective-source-statement-reconstruction-comparison','parent_canonical_packet_sha256':full['packet_sha256'],'source':{k:full['source'][k] for k in ['source_id','anchor','original_text','text_sha256']},'lean_statement':{k:full['lean'][k] for k in ['statement','statement_sha256']},'approved_definition_context':a['lean']['decoder_context'],'blind_reconstruction':{k:full['blind_reconstruction'][k] for k in ['text','text_sha256','decoder','decoder_packet_sha256','decoder_run_sha256','source_text_visible']},'private_consumer_statement':consumer,'private_scope_note':'PRIVATE NON-ANCHOR actual diagonal-law zero-threshold event only, not the source shifted rotated detector or full Ex26.','private_standard_definition_context':['ENNReal.toReal is the standard conversion to real, with zero at infinity; actual finite-probability interpretation must be internally justified.','The private statement uses the same literal inverse-precision Gaussian and coordinate cosine quadratic as displayed. No probability/moment/signal/gap certificate is an input.']}
assert b' := by' not in dump(white)
put(W/'strict-selective-phase2-input.json',dump(white))
put(E/'strict-selective-phase2-input.json',dump(white))
print(json.dumps({'state':'blind-reconstructed','full_reviewer_packet_canonical_sha256':full['packet_sha256'],'strict_whitelist_raw_sha256':sha(dump(white)),'source_review_or_sourceV':False}))
