# C7 browser preparation — disabled and unexecuted

These are new C7-scoped files. No old Geometry/FirstOrder/Normalizer checker, common helper, approved command prefix or original proposal/freeze was changed. The existing Geometry checker supplied utility structure only; its old sourceV, core, audit, gate and44-image evidence is not inherited.

`check_final_reader_v1.py` and `c7_browser_common_v1.py` were inspected as source and parsed with `ast.parse` only. Neither was imported or executed. There was no server, browser, OS call/approval request, network access, build, lifecycle API, shared edit or commit. No actual runtime PASS or image exists from this preparation.

The root context template is explicitly disabled: `authorized_by=null`, `execute_browser_authorized=false`, `actual_facts_reviewed_by_root=false`. Future core commits, V/STAB appends, execution/application/readback evidence, source digest, actual gate/site refs and actual immutable/site pins are all null. The non-null candidate, publication binding, main95322 ancestor requirement, conditional proposal hashes and checker/common hashes are real existing input/expected-code pins, not predicted runtime facts.

The actual current accepted source-audit metadata was read only to bind the already recorded original source reviewer `/root/cosine_fresh_source_5d8c2a` and decoder `/root/decode_b4e6a1`. Its `state=source-reviewed`, accepted source review and binding8dd are valid independently of this preparation. No normal V result or new source judgment is issued or consumed as browser authority here. The eventual original V execution and exact append must be supplied as actual evidence. The conceptual validator is not the C7 source verifier.

Before the Playwright import or any server/output creation, the execution entrance requires an exact root-issued authorization bound to this checker/common. The read-only context guard then requires:

- actual sourceV first-carrying and immutable-core commits, with candidate37645, real main95322 and sourceV carrying commit all ancestors of the current immutable core;
- exact eight successor payload bytes, all34 incoming-main reconciliation expectations, unchanged README, and original ledger prefix followed by exactly one original normal V and one sole STAB;
- six distinct roles, original accepted audit/run and actual one-call V manifest fields; exact accepted sourceV own-cell projection if needed; separately accepted integration own-cell insertion, inverse and actual independent application readback;
- preserved foreign SAU state and exact discovery ledger, with the independent application readback binding actual raw foreign/frontier/protected preservation; this late guard is not a substitute for pre-application preservation;
- actual eight successful official receipts/logs at the same immutable core, the focused main95322 subject-reader tests, and current gate/site metadata/source digest;
- actual core source/UI/model pins and actual built-site data/assets/HTML pins, checked again at completion. No site generation may run concurrently.

`actual-context-contract.json` specifies the exact required refs and mechanical readback schemas. It does not create those future records. Root must fill the template from actual artifacts, review the disabled concrete result, and issue a separate exact root execution grant only after the real core gates. If actual record schemas or any payload/UI bytes differ, review a separately pinned successor; do not fill made-up compatibility facts or overwrite this frozen preparation.

The planned run uses installed headless Google Chrome against an ephemeral own-site127.0.0.1 HTTP server, blocking external browser HTTP hosts. It never uses fileURL or an own-preview service. Own-site downloads and source/module DOM must equal candidate/current Git bytes. A GitHub commit-link syntax branch, if reached, does not inspect GitHub HTML, remote publication or branch release.

The concrete planned checks are:

- C7 concise default formula, all five assumption clauses and six formula proof steps; exact1/sqrt(kappa), positive modes and fixed-kappa convergence remain in the pinned lesson. Adjacent exact initially folded statement/proof, per-step correspondence, native local code scrolling, actual production/private Test module bytes and downloads.
- Compiler evidence remains producer zero public ASTIS parents and private Test one C7 parent. The provenance list is empty, the Test creates no Registry node, and scanner overlays are never complete kernel evidence. No Geometry three-parent/seven-step pattern is reused as C7 semantics.
- Actual case/index/source links, both unchanged main-bound boundaries, native declaration→module selection, and exact model-to-rendered Poisson semantic rows. The Poisson bridge has two actual dashed candidate substrates, C7 and A1; native bridge/substrate/preset selections preserve the negative-pole/circle/measure/A1 ambiguity/alias boundaries and `not-Lean-certified`/empty formal refs.
- Existing FirstOrder typed supplement/preset/cross-view behavior and the old DensityAffinity long-code/prose geometry at each width. These remain regressions, with no new proof/source verdict.
- Native main Lower Bounds selection and its real reader link, plus four subject nav destinations, one H1/no page overflow/MathJax errors and the new planned source outline through native links. Sampling and Lower Bounds have original viewport images; Optimisation, Discrete and SLC–LSI outline checks are DOM-only and grant no unrelated lane proof/source/pixel acceptance.
- Explicit horizontal equation geometry catches overflow hidden by clipping; genuine local math/code scroll panes are tested and restored. Native graph geometry is read only after real selection/callbacks. There is no Fit, pan or transform mutation by the harness.

The planned count is **48 original PNGs** (24 at1440×1000 and24 at390×844), **20 native selection rows**,14 equation-layout rows and two old DensityAffinity DOM regressions. Every PNG records its actual SHA256 and real IHDR dimensions. Extra preset/cross-view and subject/source-outline DOM checks carry no extra screenshot claim. These counts describe required future output, not existing evidence.

Per width the24 originals are: default; assumptions; six proof steps; standard reuse; exact statement; exact proof; production module; case boundary; source index; open index; declaration graph; module native click; Poisson typed bridge; C7 substrate native click; A1 substrate native click; existing FirstOrder typed supplement; Lower Bounds native selection; Lower Bounds reader; Sampling subject entrance. Viewport captures do not claim that long assumptions/code/scrollable formulas fit entirely in one image. All48 actual originals still need a separate independent pixel review after a real run; script PASS is not pixel acceptance.

For later root review only, the new narrow invocation is:

```text
/opt/anaconda3/bin/python .astis/huanjian-resume-20261103/run_check.py cosine-expansion-final-browser-v1 .astis/huanjian-gc-integration-20261105/browser-venv/bin/python .astis/huanjian-gc-fixed-spectrum-cosine-expansion-integration-20261109/independent-reader/browser-preparation-v1/check_final_reader_v1.py --authorization-json <ACTUAL_ROOT_AUTHORIZATION_PATH> --authorization-sha256 <ACTUAL_ROOT_AUTHORIZATION_SHA256>
```

The angle-bracket arguments are intentionally unfilled documentation, not executable authorization. After reviewing actual core evidence and exact root authorization, root must request a **new** scoped OS approval for the fixed command prefix ending at this new C7 checker and label. No request or old-prefix reuse occurs now. This preparation grants no sourceV, STAB, park, local acceptance, remote release, purification/Exposition Seal or whole-Goal completion.
