import Mathlib.Probability.Distributions.Gaussian.Multivariate
import Mathlib.Probability.Moments.MGFAnalytic
import Mathlib.Probability.Distributions.Gaussian.HasGaussianLaw.Independence
import Mathlib.Tactic
noncomputable section
open MeasureTheory ProbabilityTheory
open scoped ProbabilityTheory ENNReal NNReal Topology

private theorem centered_gaussian_fourth (v : ℝ≥0) :
    (∫ x : ℝ, x ^ 4 ∂gaussianReal 0 v) = 3 * (v : ℝ) ^ 2 := by
  let f : ℝ → ℝ := fun t => Real.exp ((v : ℝ) * t ^ 2 / 2)
  have hf (t : ℝ) : HasDerivAt f ((v : ℝ) * t * f t) t := by
    convert ((((hasDerivAt_id t).pow 2).const_mul (v : ℝ)).div_const 2).exp using 1 <;>
      dsimp [f] <;> ring
  have h0 : deriv f = fun t => (v : ℝ) * t * f t := funext (fun t => (hf t).deriv)
  have h1 : deriv (fun t => (v : ℝ) * t * f t) =
      fun t => ((v : ℝ) + (v : ℝ) ^ 2 * t ^ 2) * f t := by
    funext t
    convert ((((hasDerivAt_id t).const_mul (v : ℝ)).mul (hf t)).deriv) using 1 <;> ring
  have h2 : deriv (fun t => ((v : ℝ) + (v : ℝ) ^ 2 * t ^ 2) * f t) =
      fun t => (3 * (v : ℝ) ^ 2 * t + (v : ℝ) ^ 3 * t ^ 3) * f t := by
    funext t
    convert (((hasDerivAt_const t (v : ℝ)).add
      (((hasDerivAt_id t).pow 2).const_mul ((v : ℝ) ^ 2))).mul (hf t)).deriv using 1 <;> ring
  have h3 : deriv (fun t => (3 * (v : ℝ) ^ 2 * t + (v : ℝ) ^ 3 * t ^ 3) * f t) =
      fun t => (3 * (v : ℝ) ^ 2 + 6 * (v : ℝ) ^ 3 * t ^ 2 + (v : ℝ) ^ 4 * t ^ 4) * f t := by
    funext t
    convert ((((hasDerivAt_id t).const_mul (3 * (v : ℝ) ^ 2)).add
      (((hasDerivAt_id t).pow 3).const_mul ((v : ℝ) ^ 3))).mul (hf t)).deriv using 1 <;> ring
  have hiter : iteratedDeriv 4 f = deriv (deriv (deriv (deriv f))) := by
    rw [show (4 : ℕ) = 3 + 1 from rfl, iteratedDeriv_succ,
      show (3 : ℕ) = 2 + 1 from rfl, iteratedDeriv_succ,
      show (2 : ℕ) = 1 + 1 from rfl, iteratedDeriv_succ,
      show (1 : ℕ) = 0 + 1 from rfl, iteratedDeriv_succ, iteratedDeriv_zero]
  have hvalue : iteratedDeriv 4 f 0 = 3 * (v : ℝ) ^ 2 := by
    rw [hiter, h0, h1, h2, h3]
    simp [f]
  have hmgf : mgf id (gaussianReal 0 v) = f := by
    simpa only [zero_mul, zero_add] using (mgf_fun_id_gaussianReal (μ := 0) (v := v))
  have hint : (0 : ℝ) ∈ interior (integrableExpSet id (gaussianReal 0 v)) := by
    simp [integrableExpSet_id_gaussianReal]
  have hm := iteratedDeriv_mgf_zero hint 4
  rw [hmgf] at hm
  exact hm.symm.trans hvalue

private theorem centered_gaussian_square_L2 (v : ℝ≥0) :
    MemLp (fun x : ℝ => x ^ 2) 2 (gaussianReal 0 v) := by
  have hint : (0 : ℝ) ∈ interior (integrableExpSet id (gaussianReal 0 v)) := by
    simp [integrableExpSet_id_gaussianReal]
  have hi := integrable_pow_of_mem_interior_integrableExpSet hint 4
  apply (memLp_two_iff_integrable_sq_norm (by fun_prop)).2
  simpa only [Pi.pow_apply, id_eq, Real.norm_eq_abs, sq_abs, ← pow_mul] using hi
