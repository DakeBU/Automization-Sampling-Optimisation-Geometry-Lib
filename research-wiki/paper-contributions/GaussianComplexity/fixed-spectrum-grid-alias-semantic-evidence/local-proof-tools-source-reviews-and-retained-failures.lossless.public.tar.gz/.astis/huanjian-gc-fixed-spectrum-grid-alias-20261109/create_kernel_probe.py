from pathlib import Path
import json
W=Path('.astis/huanjian-gc-fixed-spectrum-grid-alias-20261109')
s=json.loads((W/'statement-seal-v2.json').read_text())
sig=s['actual_private_consumer']['signature']
head,body=sig.split(' :\n',1)
params=head.removeprefix('private theorem actual_weighted_inverse_grid_alias_series')
expected='def ExpectedPrivate : Prop := ∀'+params+',\n'+body+'\n'
example=s['producer']['signature'].replace('theorem actual_midpoint_grid_cosine_alias','example',1).rstrip()+''' := by
  exact AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumGridAlias.actual_midpoint_grid_cosine_alias hd k

'''
probe='''import Tests.GaussianComplexityFixedSpectrumGridAlias
open scoped BigOperators
open Lean
set_option autoImplicit false

'''+example+expected+'''
run_cmd do
  let env := (← getEnv).setExporting false
  setEnv env
  let target := `AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumGridAlias.actual_midpoint_grid_cosine_alias
  let c7 := `AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumCosineExpansion.actual_inverse_spectrum_cosine_expansion
  let wanted := env.constants.toList.filter fun (n, _) =>
    n == target || n.toString.endsWith ".actual_weighted_inverse_grid_alias_series"
  unless wanted.length == 2 do throwError "Expected exactly two actual packet theorem constants"
  let allowed := [`propext, `Classical.choice, `Quot.sound]
  for (n, ci) in wanted do
    match ci with
    | .thmInfo _ => pure ()
    | _ => throwError "Actual packet constant must be a theorem: {n}"
    let some proof := ci.value? true | throwError "Missing actual kernel proof term"
    let used := proof.getUsedConstants.toList
    let astis := used.filter fun k => k.toString.startsWith "AutoSamplingTheory."
    if n == target then
      unless astis.isEmpty do throwError "Unexpected public ASTIS producer parent: {astis}"
    else
      unless astis.length == 2 && astis.contains target && astis.contains c7 do
        throwError "Actual consumer must use exactly new canonical alias and C7: {astis}"
    let axs ← Lean.collectAxioms n
    unless axs.all (fun a => allowed.contains a) do throwError "Unexpected axiom: {axs}"
    logInfo m!"ACTUAL_THEOREM_CONSTANT {n}"
    logInfo m!"ACTUAL_TYPE {n}: {ci.type}"
    logInfo m!"DIRECT_ASTIS {n}: {astis}"
    logInfo m!"DIRECT_ALL {n}: {used}"
    logInfo m!"KERNEL_AXIOMS {n}: {axs}"
    if n != target then
      Lean.Elab.Command.liftCoreM <| addDecl <| Declaration.thmDecl {
        name := Name.mkSimple "ActualPrivateSealedTypeCheck"
        levelParams := []
        type := mkConst (Name.mkSimple "ExpectedPrivate")
        value := mkConst n
      }
      logInfo "ACTUAL_PRIVATE_SEALED_LITERAL_KERNEL_TYPE_APPLICATION_PASS"

#print axioms ActualPrivateSealedTypeCheck
#print axioms AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumGridAlias.actual_midpoint_grid_cosine_alias
'''
p=W/'KernelAndExactMeaning.lean';assert not p.exists();p.write_text(probe);print(p)
