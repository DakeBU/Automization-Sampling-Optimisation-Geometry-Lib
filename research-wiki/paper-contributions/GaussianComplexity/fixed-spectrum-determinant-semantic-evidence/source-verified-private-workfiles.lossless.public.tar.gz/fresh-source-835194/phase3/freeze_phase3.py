from pathlib import Path
import copy
from datetime import datetime, timezone
import hashlib
import json
import subprocess
import sys

ROOT=Path('/Users/zhouhuanjian/ASTIS-GC')
PRIVATE=ROOT/'.astis/huanjian-fixed-spectrum-determinant-20261108/fresh-source-835194/phase3'
BASE=ROOT/'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-determinant-semantic-evidence'
PUBLIC=BASE/'fresh-source-reader-835194/phase3'
TRANSITION=BASE/'fresh-source-reader-835194/phase3-verification-transition'
HEAD='15fbef72d04a1e9d1e647289a099a6ff8f829125'
MATH='a0310046dc10c06ce9f61959094322fb9016be1e'
SOURCE='6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
PHASE1='8ad4cf3e03e191f570b02867ea8422b4b29282c46bb718ade51825de2366a3cc'
PHASE2='eee316c91f3e5165975e6318661117a668ee0ab3a72cf50abe2c5d94ee3bf3b7'
REVIEWER='/root/reader_835194'
ADVANCE='ASTIS-SA-20261108-GaussianComplexityFixedSpectrumDeterminant'
OWNER='huanjian_gc_20261108_fixed_spectrum_determinant'
DECL='AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumDeterminant.actual_precision_det'

def sha(data):return hashlib.sha256(data).hexdigest()
def canonical(value):return json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
def save(path,value):
 path.parent.mkdir(parents=True,exist_ok=True)
 path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
def load(path):return json.loads(path.read_text())

PUBLIC.mkdir(parents=True,exist_ok=True);TRANSITION.mkdir(parents=True,exist_ok=True)
pins=load(BASE/'full-review-input-pins.json')
packet_raw=(BASE/'full-anti-anchored-reviewer-packet.json').read_bytes()
packet=json.loads(packet_raw)
assert sha(packet_raw)=='bb096873bb361f7f9ac704126b3c4faa78ab266ee6482b4c727ce567f12810f5'
assert sha(canonical({k:v for k,v in packet.items() if k!='packet_sha256'}))==packet['packet_sha256']=='4279d2edebdb52f56851cd8a9d7d736034dd6b48c20875356394dec6edcf00ca'
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==HEAD
unchanged=[]
for name,expected in pins['exact_inputs'].items():
 actual=sha((ROOT/name).read_bytes());assert actual==expected,name
 unchanged.append({'path':name,'before_and_after_sha256':actual,'unchanged':True})
assert sha((ROOT/'.astis/huanjian-resume-20261103/2610.20492v1.html').read_bytes())==SOURCE
assert load(PRIVATE/'focused-build-result.json')['exit_code']==0
assert load(PRIVATE/'fresh-producer-lean-result.json')['exit_code']==0
assert load(PRIVATE/'fresh-test-lean-result.json')['exit_code']==0
assert load(PRIVATE/'reader/static-reader-checks.json')['passed']

coverage={
 'reviewer':REVIEWER,'baseline':'Own raw-source phase1 contract and phase2 selective freeze; preproof source graph read only afterward as lineage.',
 'selected_coverage':[
  {'source_region':'S4.E11 and S4.SS1.p1','status':'literal objects preserved','implementation':'Same d,kappa, midpoint grid, actual real orthogonal O, diagonal and conjugated precision. Source-to-Fin index j=i.val+1 preserves all factors.'},
  {'source_region':'A3.Ex160 second determinant substitution','status':'bounded determinant omission discharged','implementation':'Existing canonical DJE.det_conjStarAlgAut_eq on actual O and actual diagonal; real-star/transpose bridge proved entrywise.'},
  {'source_region':'S4.E11 diagonal and det Lambda in A3.Ex160','status':'standard representation bridge discharged','implementation':'Matrix.det_diagonal expands the literal diagonal determinant to its full finite product; no product certificate binder. This bridge was implicit in the source and was split out by the separate preproof phase2 overlay.'},
  {'source_region':'Associated target N(0,A^-1), quadratic potential','status':'genuine compiled Test consumer only','implementation':'Existing actual admissibility produces A.PosDef; unchanged GPD theorem identifies the existing multivariateGaussian covariance A^-1 with Euclidean volume.withDensity; new determinant substitutes only the prefactor.'}
 ],
 'source_graph_lineage_check':{
  'phase1_nodes':36,'phase1_AND_edges':27,'phase1_coverage_records':269,'phase1_DOM_elements':746,
  'phase2_extra_bridge':'det Lambda = product lambda_i, plus explicit source-one-based/Fin-zero-based adapter',
  'combined_normalizer_AND_preserved':'Gaussian integration AND determinant conjugation -> full A3.Ex160 chain. Determinant-only closure does not discharge analytic integration.',
  'knownZ_condition_preserved':'Public spectrum is retained as the knowledge condition; it is not inferred from determinant equality.',
  'conditioned_Haar_exclusion':'Unused conditioned determinant-sign Haar law is explicitly excluded while full O(d), both signs and Haar masses stay source context.',
  'reference_measure_correction':'The introductory unnormalized-density paragraph does not define a measure or integral. Z interpretation remains SOURCE_IMPLICIT; this agrees with the independent raw-first contract.',
  'approval_scope':'This review checks the selected determinant closure and its actual consumer. It does not promote the entire C.4 graph or all source obligations to completed Lean truth.'
 },
 'retained_open':['strict source interior-angle/cosine/eigenvalue route as its own coverage','unweighted Gaussian integral/known-Z proposition','C.4 calculus, strong convexity/smoothness and minimizer proof','moments and Krylov results','adaptive oracle/seed/transcript/output and finite-precision adapters','TV and deterministic/expected cost adapters','both complete main lower bounds','canonical integration, deployment, desktop Chrome reader acceptance, purification/Exposition Seal and whole Goal'],
 'no_source_repair_needed':True
}
save(PUBLIC/'source-coverage-and-reuse-review.json',coverage)

ancestry={
 'producer_ASTIS_direct_parents':['AutoSamplingTheory.TechnicalLemmas.Measure.DisplacementJacobianEntropy.det_conjStarAlgAut_eq'],
 'consumer_ASTIS_direct_parents':['AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumAdmissibility.actual_precision_admissible',DECL,'AutoSamplingTheory.TechnicalLemmas.Measure.GaussianPrecisionDensity.multivariateGaussian_eq_withDensity_of_posDef'],
 'critical_meanings':[
  'Mathlib orthogonalGroup is the real-trivial-star unitaryGroup alias; the actual real O is definitionally usable as unitary(Matrix ... R). specialOrthogonalGroup is a distinct determinant-one subtype and is not used.',
  'unitary carries star(U)*U=1 and U*star(U)=1; real star is trivial entrywise, so matrix star is transpose. Both determinant signs are permitted.',
  'Unitary.conjStarAlgAut_apply is literally U*B*star(U). The DJE parent is determinant-only for arbitrary real square B, with no PosDef, eigenvalue or determinant certificate input.',
  'DJE internally applies determinant multiplicativity and the unitary identity to get det(U)*det(star U)=1. No det U=1 premise is used.',
  'Matrix.det is the alternating/Leibniz determinant. Matrix.det_diagonal is the genuine full finite-product theorem, not a supplied spectral characterization.',
  'Mathlib multivariateGaussian is the existing standard-Gaussian covariance-square-root pushforward. Existing admissibility makes the actual precision positive definite; GPD proves the inverse covariance is positive definite and avoids the non-PSD degenerate fallback.',
  'The canonical density leaf uses volume on EuclideanSpace, not Gaussian probability as a reference. It proves the real exponent d/2 from rpow_natCast/sqrt/rpow multiplication, including odd dimension.',
  'The Test keeps the actual same A in covariance and exponent; only its determinant coefficient becomes the fixed grid product. PosDef is constructed internally by the existing actual admissibility theorem.'
 ],
 'axioms_for_producer_admissibility_GPD_consumer':['propext','Classical.choice','Quot.sound'],
 'fresh_evidence':'focused-build.log is a successful cached/replayed Lake build. fresh-producer-lean.log and fresh-test-lean.log separately recompile the actual producer and Test source without -o or source mutation.',
 'no_fake_closure_tokens':True,'new_duplicate_generic_invariant':False,'new_public_Test_or_Registry_declaration':False
}
save(PUBLIC/'critical-ancestry-review.json',ancestry)

selective=load(ROOT/'.astis/huanjian-fixed-spectrum-determinant-20261108/fresh-source-835194/phase2/selective-comparison.json')
mapping={'objects':'objects','domains':'domains','quantifiers':'quantifiers','assumptions':'assumptions','conclusion':'conclusion','scopes':'scopes_senses','constant_dependencies':'constant_dependencies'}
relations={'objects':'same','domains':'equivalent','quantifiers':'same','assumptions':'same','conclusion':'explicit-elaboration','scopes':'same','constant_dependencies':'explicit-elaboration'}
slots={}
for canonical_slot,prior_slot in mapping.items():
 previous=selective['seven_slots'][prior_slot]
 original=previous['source_contract']; reconstructed=previous['candidate_and_reconstruction']
 if canonical_slot=='conclusion':
  original='Selected determinant component: for actual A=O Lambda O^T, det A=det Lambda; the literal diagonal expands this to the complete product of the displayed lambda_i. Positivity, Gaussian normalization/known-Z and the rest of C.4 remain separate source context, not additional conclusion clauses claimed for this declaration.'
 evidence={
  'objects':'Raw source S4.E11 and actual production lines 35-41 construct exactly the same literal diagonal and precision. Whole module has no scoped mathematical variable/assumption bundles. Actual determinant semantics checked in Mathlib and DJE.',
  'domains':'Raw source d>=2,kappa>=2 and real O(d), both signs. Actual real orthogonalGroup alias and kernel elaboration verified; source j=i.val+1 is a bijection with Fin d. d=2,kappa=2 and odd dimensions remain included.',
  'quantifiers':'Every allowed d,kappa and actual full orthogonal O; all local lets share those binders. No existential witness, algorithm input, almost-sure restriction, det-one filter or Haar premise is introduced.',
  'assumptions':'Whole production/Test modules read. Public bounds are exactly source bounds. Producer uses no PosDef/spectral/product/determinant certificate. Consumer internally obtains PosDef from actual admissibility. Unused hd,hkappa warnings preserve the source interface rather than alter it.',
  'conclusion':'A3.Ex160 determinant replacement is expanded by the genuine Matrix.det_diagonal theorem. Producer proves precisely actual A.det=full literal product. The separate Test genuinely proves same-A volume-density equality from three actual kernel parents; it is not a theorem binder or integral/known-Z completion claim.',
  'scopes':'Actual current imports, namespace, proof and Test checked; no namespace/section hypotheses. Real star/transpose bridge uses same O. Rawsource/publication/lesson keep integral, full C.4, oracle/TV/cost and main bounds separate. Euclidean volume and unchanged A-dependent exponent are explicit in Test.',
  'constant_dependencies':'Exact source half-step and affine cosine constants preserved by real casts/reindexing. Test uses (d:R)/2 with real rpow, GPD derives this real normalization, and all scalar grid factors are independent of O. No unspecified or statistical constant appears.'
 }[canonical_slot]
 slots[canonical_slot]={'original':original,'reconstructed':reconstructed,'relation':relations[canonical_slot],'evidence':evidence}

exposure={
 'reviewer':REVIEWER,'phase':'PHASE3_FULL_CURRENT_SOURCE_MODULE_REVIEW',
 'ordered_freezes':{'phase1_manifest_sha256':PHASE1,'phase2_manifest_sha256':PHASE2,'full_packet_only_after_both':True},
 'new_content_inspected':[
  'Full anti-anchored packet and full-review-input-pins; current actual production, private Test, full DJE/GPD/admissibility modules; current authored lesson/publication and assumption deltas.',
  'Critical Mathlib unitary/orthogonal carrier, real star, actual determinant/diagonal theorem, unitary conjugation and Gaussian constructor source windows; full existing IsotropicGaussianDensity module.',
  'Repository declaration/inline Lean/publication source-card renderers and necessary bounded source-parser and semantic-validator/API implementation windows.',
  'Preproof source graph and coverage metadata after the independent raw-first and selective freezes. The first large graph/coverage diagnostic display was truncated; the entire narrow phase2 graph, relevant determinant/normalizer edges, coverage counts and corrections were then inspected separately.',
  'Original sealed consumer signature/projection record; failed show_term input, unchanged successful anonymous input, and timestamp-bounded failed/passed/named-consumer logs. Raw and gzip inputs are pinned.',
  'Only the current target advance records were summarized from the ledger, to establish PROVED_LOCAL and preserve proof ownership. The current audit is blind-reconstructed/pending; no prior source verdict was adopted.'
 ],
 'byte_snapshot_only_not_semantically_read':'Pinned complete ledger files and initial canonical audit were copied losslessly and hashed; unrelated ledger records were not rendered. Other topology-review verdicts suggested by root were not opened or used as authority.',
 'actual_commands':['lake build AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumDeterminant Tests.GaussianComplexityFixedSpectrumDeterminant','lake env lean AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumDeterminant.lean','lake env lean Tests/GaussianComplexityFixedSpectrumDeterminant.lean','bounded static renderer and exact projection checks'],
 'diagnostic_lookup_failures':[{'command':'rg on website/scripts/astis_site.py','result':'No such file; corrected to tools/astis_site.py by bounded filename lookup. No mathematical or candidate change.'},{'command':'rg on website/scripts/theorem_publication.py and publication_readers.py','result':'No such files; corrected to actual publication_reader.py through bounded filename lookup. No mathematical change.'}],
 'earlier_show_term_timeout':'IMPLEMENTATION_FAILED, not mathematical refutation or source invalidity. Raw failed log shows default 200000 heartbeat timeout; the exact proof succeeds after removal of only show_term and its indentation.',
 'private_name_projection':'Independent byte-level checks prove original sealed proposition and successful anonymous proof are unchanged after erasing the private Test name. Later kernel-inspection commands add no mathematical binder.',
 'source_of_verdict':'Own previously frozen rawsource contract, own seven-slot selective comparison, whole current modules/critical definitions, fresh Lean checks and own static reader checks; not previous verdicts.',
 'not_performed':['canonical audit write','VERIFIED transition API','ledger mutation','shared source/metadata edit','desktop/browser visual QA','remote deployment/publication','aggregate whole-repository gate'],
 'write_scope':[str(PRIVATE.relative_to(ROOT)),str(PUBLIC.relative_to(ROOT)),str(TRANSITION.relative_to(ROOT))],
 'read_scope_notes':'Only exact task-related source/lineage inputs and bounded code lookup were used; no broad old evidence discovery or global current-frontier scheduling was performed.'
}
save(PUBLIC/'exposure-log.json',exposure)

review_run={
 'schema_version':1,'actor':REVIEWER,'created_at_utc':datetime.now(timezone.utc).isoformat(),
 'checked_immutable_commit':HEAD,'mathematical_candidate':MATH,
 'reviewer_packet_raw_sha256':sha(packet_raw),'reviewer_packet_sha256':packet['packet_sha256'],
 'publication_binding_sha256':packet['publication_binding_sha256'],
 'source_sha256':SOURCE,'rawfirst_phase1_manifest_sha256':PHASE1,'selective_phase2_manifest_sha256':PHASE2,
 'independent_from_formalizer':True,'independent_from_decoder':True,
 'checks':{'focused_build_cached_replay':load(PRIVATE/'focused-build-result.json'),'fresh_actual_producer_Lean':load(PRIVATE/'fresh-producer-lean-result.json'),'fresh_actual_Test_Lean':load(PRIVATE/'fresh-test-lean-result.json'),'static_reader':load(PRIVATE/'reader/static-reader-checks.json'),'private_name_and_failed_diagnostic':load(PRIVATE/'private-name-and-diagnostic-checks.json'),'producer_seal_projection':load(PRIVATE/'producer-seal-projection-check.json')},
 'module_pins_unchanged':unchanged,
 'accepted_scope':'Bounded actual fixed-spectrum precision determinant/product theorem; whole current module/private consumer and authored mathematical explanation checked. Genuine same-A Test density consumer accepted as compiled use, without broader source closure.',
 'verdict':'equivalent-after-elaboration','blocking_deltas':0,'repairs':[],
 'canonical_audit_written':False,'normal_VERIFIED_API_calls':0,'actual_advance_state':'PROVED_LOCAL',
 'pending':['explicit root authorization for canonical audit installation and one normal independent VERIFIED API call','later integration, desktop Chrome/remote reader acceptance and purification'],
 'evidence_files':[str((PUBLIC/'source-coverage-and-reuse-review.json').relative_to(ROOT)),str((PUBLIC/'critical-ancestry-review.json').relative_to(ROOT)),str((PUBLIC/'exposure-log.json').relative_to(ROOT))]
}
save(PUBLIC/'review-run.json',review_run)
run_sha=sha((PUBLIC/'review-run.json').read_bytes())
review_result={
 'semantic_slots':slots,
 'deltas':[],
 'verdict':'equivalent-after-elaboration','repairs':[],
 'reviewer':REVIEWER,'independent_from_formalizer':True,'independent_from_decoder':True,
 'review_evidence':'Independent raw-first phase1 and selective phase2 freezes precede full current module review. Exact current producer/private Test, canonical DJE parent, real-star/unitary/determinant meanings, source diagonal-product/index bridges, actual same-A Euclidean density use, authored source/publication assumptions and static folded exact reader all checked. Focused Lake build and fresh actual Test Lean run pass with expected one/three ASTIS parents and only propext/Classical.choice/Quot.sound. Scope excludes unweighted integral/known-Z, full C.4/main bounds and integration/remote/purification. See packet/run-bound phase3 evidence.',
 'review_run_sha256':run_sha,'reviewer_packet_sha256':packet['packet_sha256'],
 'checked_immutable_commit':HEAD,'publication_binding_sha256':packet['publication_binding_sha256'],
 'scope':'Accepted independent source review for the bounded determinant/product declaration and its current whole-module/private-Test context. No broader paper or integration completion.'
}
save(PUBLIC/'review-result.json',review_result)

audit_path=ROOT/'research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-determinant.json'
proposed=load(audit_path)
assert proposed['state']=='blind-reconstructed' and proposed['verdict']=='pending'
proposed=copy.deepcopy(proposed)
proposed.update({'state':'accepted','semantic_slots':slots,'deltas':[],'verdict':review_result['verdict'],'repairs':[]})
proposed['source_review']={'state':'accepted','reviewer':REVIEWER,'independent_from_formalizer':True,'independent_from_decoder':True,'reviewer_packet_sha256':packet['packet_sha256'],'evidence':review_result['review_evidence'],'review_run_sha256':run_sha,'run_artifact':str((PUBLIC/'review-run.json').relative_to(ROOT))}
save(PUBLIC/'proposed-canonical-accepted-audit.json',proposed)
sys.path.insert(0,str(ROOT/'tools'))
import astis_semantic_roundtrip_core as rt
protocol={'decoder_blindness':'required','decoder_context_content_scan':'required','independent_source_review':'required','source_review_packet_binding':'required','independent_repair_review':'required','repair_review_packet_binding':'required','semantic_slots':list(rt.SEMANTIC_SLOTS),'decoder_allowed_inputs':list(rt.DECODER_INPUT_ARTIFACTS)}
errors=rt.validate_registry({'schema_version':1,'protocol':protocol,'audits':[proposed]})
save(PUBLIC/'proposed-audit-validation.json',{'command':'astis_semantic_roundtrip_core.validate_registry on isolated proposed audit with canonical protocol; no registry or canonical file writes','errors':errors,'passed':not errors,'proposed_reviewer_packet_matches_full_input':rt.semantic_reviewer_packet(proposed)['packet_sha256']==packet['packet_sha256']})
assert not errors,errors
assert rt.semantic_reviewer_packet(proposed)['packet_sha256']==packet['packet_sha256']

transition_evidence={
 'verifier_id':REVIEWER,'verified_commit':HEAD,
 'gate':'PASS cached/replayed focused producer+actual consumer Lake build (3651 jobs); PASS separate fresh producer and actual Test Lean source checks; exact expected one producer/three consumer ASTIS parents; standard three axioms only. See review-run and raw logs.',
 'source_audit':{'review_result':str((PUBLIC/'review-result.json').relative_to(ROOT)),'review_run_sha256':run_sha,'reviewer_packet_sha256':packet['packet_sha256'],'verdict':review_result['verdict'],'proposed_accepted_audit':str((PUBLIC/'proposed-canonical-accepted-audit.json').relative_to(ROOT))},
 'fake_closure_scan':{'artifact':str((PRIVATE/'static-module-inventory.json').relative_to(ROOT)),'sha256':sha((PRIVATE/'static-module-inventory.json').read_bytes()),'result':'No sorry/admit/axiom/postulate/Prop:=True/:=trivial fake closure in reviewed modules; kernel axioms are standard only.'},
 'publication_declarations':[DECL],
 'truth_boundary':coverage['retained_open']
}
save(TRANSITION/'proposed-normal-verification-evidence.json',transition_evidence)
save(TRANSITION/'proposed-transition-plan.json',{
 'actual_actor':REVIEWER,'checked_immutable_commit':HEAD,'advance_id':ADVANCE,
 'actual_state':'PROVED_LOCAL','proposed_next_state':'VERIFIED','proof_owner_before':OWNER,'proof_owner_expected_after':OWNER,
 'canonical_audit_write_authorized':False,'canonical_audit_installed':False,
 'API_calls':0,'planned_API_calls_after_explicit_authorization':1,
 'normal_API':'tools.astis_advance.transition_advance(advance_id, "VERIFIED", worker_id=reviewer, evidence=proposed-normal-verification-evidence)',
 'preconditions':['Explicit root authorization','Install exact proposed accepted audit after checking its expected current preimage hash','Recheck immutable HEAD, producer/Test/binding and ledger preimage','Use normal API once; do not manually append or change proof owner'],
 'advance_ledger_before_sha256':pins['exact_inputs']['runs/substantive_advances.jsonl'],
 'canonical_audit_before_sha256':pins['exact_inputs']['research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-determinant.json'],
 'future_preservation_receipt_required_fields':['actual_actor','checked_immutable_commit','append_sha256','advance_ledger_after_sha256','proof_owner_before_after','API_calls=1','actual_state'],
 'current_receipt_boundary':'No append hash or after-ledger hash is fabricated. Those fields can only be populated after the authorized actual API call.'})

# Copy fresh raw logs and exact renderer outputs into review evidence for bounded retrieval.
for name in ['focused-build.log','focused-build-result.json','fresh-producer-lean.log','fresh-producer-lean-result.json','fresh-test-lean.log','fresh-test-lean-result.json','static-module-inventory.json','private-name-and-diagnostic-checks.json','producer-seal-projection-check.json','reader/current-publication-card.html','reader/static-reader-checks.json']:
 dest=PUBLIC/'checks'/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes((PRIVATE/name).read_bytes())

summary='''# Independent full source/module review\n\nVerdict: **equivalent after elaboration**, for the actual fixed-spectrum precision determinant/product component at immutable commit `'''+HEAD+'''`. The raw-first and selective freezes preceded all full-module exposure.\n\nThe actual matrix, full real orthogonal carrier, both determinant signs, source parameter endpoints and source-to-Fin index mapping are preserved. The existing canonical determinant-conjugation lemma is the producer's sole ASTIS parent; the diagonal-product bridge is proved internally. No determinant-one, positive-definiteness, spectrum, product or correctness certificate is added as a public premise.\n\nThe actual private Test derives positive definiteness internally, consumes all three expected producers, and proves the same inverse-precision Gaussian law equals Euclidean volume with the displayed density. Only its coefficient loses orientation dependence; the quadratic exponent retains the actual matrix. Real `d/2` covers odd dimensions.\n\nThe focused Lake build and fresh actual Test Lean check pass. Kernel axioms are only `propext`, `Classical.choice`, and `Quot.sound`. The static repository renderer preserves formulas, closed disclosures, exact Lean statement/proof adjacency, assumption deltas and open scope. Desktop Chrome/remote reader acceptance is not part of this static check.\n\nThe earlier 200000-heartbeat failure is diagnostic implementation failure caused by `show_term` overhead: removing only that wrapper and indentation preserves the proof and succeeds. Erasing the later private Test name gives the original sealed anonymous proposition and identical successful proof.\n\nNo unweighted integral/known-Z, full C.4, oracle/precision/TV/cost or main lower-bound completion is inferred. Integration, remote publication, purification/Exposition Seal and the whole Goal remain separate. The proposed accepted audit passes the isolated canonical validator. It has **not** been installed, and no normal VERIFIED API call or ledger mutation has been performed.\n'''
(PUBLIC/'review-report.md').write_text(summary)

# One final exact preimage recheck before freezing, without any shared mutation.
for name,expected in pins['exact_inputs'].items():assert sha((ROOT/name).read_bytes())==expected,name
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==HEAD
artifacts=[]
for base in [PRIVATE,PUBLIC,TRANSITION]:
 for path in sorted(base.rglob('*')):
  if path.is_file() and path.name not in {'phase3-manifest.json','freeze-receipt.json'}:
   data=path.read_bytes();artifacts.append({'path':str(path.relative_to(ROOT)),'sha256':sha(data),'bytes':len(data)})
manifest={'schema_version':1,'freeze_id':'fresh-source-reader-835194-PHASE3-v1','frozen_at_utc':datetime.now(timezone.utc).isoformat(),'actual_actor':REVIEWER,'checked_immutable_commit':HEAD,'mathematical_candidate':MATH,'source_sha256':SOURCE,'phase1_manifest_sha256':PHASE1,'phase2_manifest_sha256':PHASE2,'full_reviewer_packet_raw_sha256':sha(packet_raw),'full_reviewer_packet_sha256':packet['packet_sha256'],'publication_binding_sha256':packet['publication_binding_sha256'],'verdict':review_result['verdict'],'review_run_sha256':run_sha,'canonical_audit_written':False,'API_calls':0,'actual_state':'PROVED_LOCAL','artifacts':artifacts,'manifest_hash_rule':'Excludes itself and freeze receipt; receipt binds exact manifest bytes.'}
save(PUBLIC/'phase3-manifest.json',manifest)
receipt={'freeze_id':manifest['freeze_id'],'checked_immutable_commit':HEAD,'verdict':review_result['verdict'],'API_calls':0,'actual_state':'PROVED_LOCAL'}
for key,path in [('manifest_sha256',PUBLIC/'phase3-manifest.json'),('review_run_sha256',PUBLIC/'review-run.json'),('review_result_sha256',PUBLIC/'review-result.json'),('proposed_audit_sha256',PUBLIC/'proposed-canonical-accepted-audit.json'),('exposure_log_sha256',PUBLIC/'exposure-log.json'),('transition_evidence_sha256',TRANSITION/'proposed-normal-verification-evidence.json'),('transition_plan_sha256',TRANSITION/'proposed-transition-plan.json')]:receipt[key]=sha(path.read_bytes())
save(PUBLIC/'freeze-receipt.json',receipt)
print(json.dumps(receipt,indent=2));print('FROZEN_ARTIFACTS',len(artifacts))
