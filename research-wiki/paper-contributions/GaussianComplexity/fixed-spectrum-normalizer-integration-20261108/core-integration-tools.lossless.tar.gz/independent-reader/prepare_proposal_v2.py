"""Freeze six exact conditional shared payloads; never apply or issue V/STAB."""
from pathlib import Path
import copy, datetime, difflib, gzip, hashlib, json, os, subprocess, sys
sys.dont_write_bytecode = True
R = Path('/Users/zhouhuanjian/ASTIS-GC')
S = R/'.astis/huanjian-gc-fixed-spectrum-normalizer-integration-20261108/independent-reader'
O = R/'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-normalizer-integration-20261108/independent-reader/proposal-v2'
E = R/'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-normalizer-semantic-evidence'
ADV = 'ASTIS-SA-20261108-GaussianComplexityFixedSpectrumNormalizer'
CELL = 'ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-normalizer'
ACTOR = '/root/norm_integration_reader'
OWNER = 'huanjian_gc_20261108_fixed_spectrum_normalizer'
HEAD = '813268bc2683a82269364caffbc0c7490a884204'
CANDIDATE = '8d33e06485edc17320cc01308af40da44945659d'
DECL = 'AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumNormalizer.actual_normalizing_integral'
ADMISS = 'AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumAdmissibility.actual_precision_admissible'
DET = 'AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumDeterminant.actual_precision_det'
GPD = 'AutoSamplingTheory.TechnicalLemmas.Measure.GaussianPrecisionDensity.multivariateGaussian_eq_withDensity_of_posDef'
RN = 'AutoSamplingTheory.TechnicalLemmas.Measure.RadonNikodym.measurableEquiv_map_withDensity'
AVERAGED = 'AutoSamplingTheory.ExampleCases.GaussianComplexity.AveragedBlockLaw.actual_averaged_block_product'
PARENTS = [ADMISS, DET, GPD]
BINDING = 'b2f41e36a9d705ff68da71f72f0ec14f1cd2ff105bcf0ae5000ef1406a5d1f41'
PATHS = ['AutoSamplingTheory.lean', 'Tests.lean', 'Tests/Basic.lean', 'AutoSamplingTheory/TechnicalLemmas/Registry.lean', 'website/content/samplewiki_companion_frontiers.json', 'research-wiki/sampling-sde-library/cards/AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumNormalizer.md']
PINS = {
 'AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumNormalizer.lean': '2a61f494afc9b6496527094edccefa39be9cd71a72b599e5fcd2ca5bc26cf4cf',
 'Tests/GaussianComplexityFixedSpectrumNormalizer.lean': '71040132321ec908370494d289571e7366b87658de6dd531829162dfc95c90d1',
 'website/content/declaration_lessons/huanjian-fixed-spectrum-normalizer.json': 'c38b809c1f71d652037443e4c47a1d448d15c3983a27aa1133d5aec4c85055f5',
 'website/content/publications/huanjian-fixed-spectrum-normalizer.json': '68da4cb0de5380fea1796abfc6e193a35779009983dd3d9b10e03f1ca05bf0b0',
 'AutoSamplingTheory/TechnicalLemmas/Measure/GaussianPrecisionDensity.lean': '1a1b9a929076ab77bf0e0f207f0d3d4fa25ac30dd56b2275e1fc319970f0f5e5',
}
MODELS = {'website/content/graph_memory_index.json': '019497faee75c5844ff3d3a08b0ce61c25256918cc29c45b2de5bbaca490b607', 'website/content/functor_hypergraph.json': '94b56f87136ca97820893e5531d16d36334d44bc6b9e41981d39aa700f8fe782'}
sha = lambda b: hashlib.sha256(b).hexdigest()
canon = lambda x: json.dumps(x, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()
dump = lambda x: (json.dumps(x, ensure_ascii=False, indent=2)+'\n').encode()
def cmd(*args): return subprocess.check_output(args, cwd=R)
def archive(name, raw):
 p=O/name; assert not p.exists(), str(p); p.write_bytes(gzip.compress(raw,mtime=0)); assert gzip.decompress(p.read_bytes())==raw
 return {'path':str(p.relative_to(R)), 'raw_sha256':sha(raw), 'gzip_sha256':sha(p.read_bytes()), 'raw_bytes':len(raw)}
def once(raw, old, new):
 a=old.encode(); assert raw.count(a)==1,old; return raw.replace(a,new.encode(),1)
def differences(a,b,p=''):
 assert type(a) is type(b)
 if isinstance(a,dict):
  assert a.keys()==b.keys(); return sum((differences(a[k],b[k],p+'/'+str(k)) for k in a),[])
 if isinstance(a,list):
  assert len(a)==len(b); return sum((differences(x,y,p+'/'+str(i)) for i,(x,y) in enumerate(zip(a,b))),[])
 return [] if a==b else [p]
assert not O.exists(); assert cmd('git','rev-parse','HEAD').decode().strip()==HEAD
cmd('git','merge-base','--is-ancestor',CANDIDATE,HEAD)
for p,h in {**PINS,**MODELS}.items(): assert sha((R/p).read_bytes())==h,p
for p in list(PINS)[:2]: assert cmd('git','show',CANDIDATE+':'+p)==(R/p).read_bytes()
sys.path.insert(0,str(R/'tools'))
import astis_advance as adv
import astis_publication as pub
import astis_site as site
item=next(x for x in pub.load() if x['id']=='huanjian-fixed-spectrum-normalizer')
assert pub.binding_digest(item,item['bindings'][0])==BINDING
unit=json.loads((R/list(PINS)[2]).read_bytes())['units'][0]
assert unit['astis_dependencies']==PARENTS and unit['reading_layout']=='progressive' and len(unit['steps'])==6
capsule=json.loads((E/'local-proof-capsule.json').read_bytes())
assert capsule['actual_ASTIS_producer_parents']==PARENTS
assert capsule['actual_ASTIS_consumer_parents']==PARENTS+[DECL]
before={p:(R/p).read_bytes() if (R/p).exists() else None for p in PATHS}
assert before[PATHS[-1]] is None
for p in PATHS[:-1]: assert before[p]==cmd('git','show',HEAD+':'+p),p
plans={}
plans[PATHS[0]]=once(before[PATHS[0]],'import AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumDeterminant\n','import AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumDeterminant\nimport AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumNormalizer\n')
plans[PATHS[1]]=once(before[PATHS[1]],'import Tests.GaussianComplexityFixedSpectrumDeterminant\n','import Tests.GaussianComplexityFixedSpectrumDeterminant\nimport Tests.GaussianComplexityFixedSpectrumNormalizer\n')
count=before[PATHS[3]].count(b'status := LemmaMemoryStatus.formalizedLocal'); assert count==620
plans[PATHS[2]]=once(before[PATHS[2]],'formalizedTechnicalLemmaCount = 620','formalizedTechnicalLemmaCount = 622')
gpd_entry='''  {
    key := "measure.gaussian-precision-density-existing-canonical",
    localDecl := "AutoSamplingTheory.TechnicalLemmas.Measure.GaussianPrecisionDensity.multivariateGaussian_eq_withDensity_of_posDef",
    upstreamDecl := "Existing ASTIS actual SPD inverse-precision Gaussian Lebesgue density; compilation-only inventory admission",
    upstreamFile := "AutoSamplingTheory/TechnicalLemmas/Measure/GaussianPrecisionDensity.lean:48; legacy source/publication audit debt remains",
    status := LemmaMemoryStatus.formalizedLocal,
    tags := ["Gaussian", "SPD-precision", "existing-compiled-node", "compilation-only-index", "legacy-source-publication-audit-debt"],
    saldUse := "Compilation-only admission of the existing canonical density, with historical source/publication audit debt. The old gaussian-precision-density frontier remains proved_locally without independent verification; no old sourceV or completed audit is claimed. The actual fixed-spectrum normalizing-integral producer literally reuses this identical canonical declaration; retain its existing canonical node identity and expose conservative source-name references",
    note := "Existing public compiled declaration inventory only: no new theorem, proof, SAU, sourceV or completed source/publication audit. Exact old module SHA1a1b9a929076ab77bf0e0f207f0d3d4fa25ac30dd56b2275e1fc319970f0f5e5 remains unchanged. Every finite dimension including zero and actual SPD real precision A: the existing multivariateGaussian with covariance Ainv equals the stated density against unweighted Euclidean Lebesgue volume, with real d/2. The new normalizer producer actually consumes this exact canonical node, existing actual admissibility and actual determinant as its three kernel ASTIS parents. Its new source review does not review this historical parent module. The old ASTIS-SHARED-gaussian-precision-density frontier remains proved_locally with no independent_verification, and the old gaussian-complexity-law-density source/publication debt remains unchanged. formalizedLocal records compilation and canonical retrieval only; the same already source-present partial graph node may acquire compilation inventory status without old source-fidelity credit. Its generic generated theorem card displays the explicit compilation-only and debt warning through saldUse, upstreamFile and tags; the full Registry note remains in source. The owning-module edge is structural; conservative name references remain dashed and incomplete, not a kernel dependency export. Natural existing references from AveragedBlockLaw and to RadonNikodym may become visible solely through this inventory admission. No other missing parent is swept in, no duplicate density or conceptual transport is created."
  },
'''
normal_entry='''  {
    key := "gaussian-complexity.fixed-spectrum-normalizer",
    localDecl := "AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumNormalizer.actual_normalizing_integral",
    upstreamDecl := "arXiv2610.20492v1 Eq11 and Appendix C.4 actual finite unweighted Gaussian normalizing integral",
    upstreamFile := "S4.SS1 Eq11/public-normalizer; S2 actual target; A3.SS4 Gaussian integration component of Ex160",
    status := LemmaMemoryStatus.formalizedLocal,
    tags := ["GaussianComplexity", "fixed-spectrum", "actual-normalizing-integral", "Lebesgue-integrability", "canonical-reuse"],
    saldUse := "The actual same-A inverse-precision Gaussian Test consequentially consumes the new actual integral in its weight divided by integral density; its positive actual mass is proved internally",
    note := "Mathematical candidate8d33e06485edc17320cc01308af40da44945659d and bindingb2f41e36a9d705ff68da71f72f0ec14f1cd2ff105bcf0ae5000ef1406a5d1f41 pin exact code and authored mathematics. Independent current source/whole-module review, normal source V and sole STAB are application prerequisites. Exactlyd>=2,kappa>=2 and every full real orthogonal O, including either determinant sign: the literal quadratic weight is Integrable against actual unweighted Euclidean Lebesgue volume and its actual integral equals (2pi)^(real d/2)/sqrt(full cosine-grid product). Actual precision admissibility, determinant and the identical GaussianPrecisionDensity declaration are the three genuine kernel ASTIS producer parents. Actual probability mass, continuity and nonnegativity prove finite integrability internally before recovering the real integral; no positivity, determinant, integrability, finite mass or normalization certificate is assumed. Using the canonical density and its probability mass is an explicit implementation OR-route, not a rewritten author Source Proof Graph. The Test-only private consumer contains all three old canonical parents plus this new integral producer; it creates no public or Registry consumer node. Only the normalizing scalar is independent of O; covariance and exponent retain actual A. The Lebesgue integral interpretation and explicit integrability are disclosed source-implicit elaborations. Historical GPD source/publication debt remains separate from this new review. Remaining C4 calculus/minimizer, strict historical angle/cosine route, moments/Krylov, true adaptive/private-seed/transcript/output laws, actual oracle/finiteprecision/TV, deterministic worstcap and explicit expectedcost adapters, both complete main lower bounds, remote publication and postmerge purification/ExpositionSeal remain separate."
  },
'''
reg=once(before[PATHS[3]],'import AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumDeterminant\n','import AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumDeterminant\nimport AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumNormalizer\n')
assert b'key := "measure.gaussian-precision-density-existing-canonical"' not in reg
assert b'localDecl := "'+GPD.encode()+b'"' not in reg
reg=once(reg,'  {\n    key := "gaussian-complexity.single-block-separation",',gpd_entry+normal_entry+'  {\n    key := "gaussian-complexity.single-block-separation",')
assert reg.replace((gpd_entry+normal_entry).encode(),b'',1).replace(b'import AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumNormalizer\n',b'',1)==before[PATHS[3]]
assert reg.count(b'status := LemmaMemoryStatus.formalizedLocal')==622
plans[PATHS[3]]=reg
f=json.loads(before[PATHS[4]]); guide=f['cases'][4]['reader_guide'][3]; boundary=f['cases'][4]['theorems'][1]['boundary']
suffix=boundary[boundary.index(' Section 4.4 limits'):]
old='The full unweighted Gaussian integral/known-normalizer proposition, C4 calculus/minimizer, moments/Krylov and all full lower-bound transports remain separate.'
new=r'The actual unweighted Euclidean Gaussian normalizing integral is also compiled and independently source-reviewed: the literal quadratic weight is integrable and \(Z_A=\int e^{-x^\top A x/2}\,dx=(2\pi)^{d/2}/\sqrt{\prod_i\lambda_i}\), with real \(d/2\). The actual same-A Gaussian Test uses this very integral in its normalized density. Its three producer parents are the existing actual precision admissibility, determinant and identical canonical Gaussian density; historical source/publication audit debt of the latter remains separate. Only \(Z_A\) is independent of orientation. Remaining C4 calculus/minimizer, the strict historical angle/cosine route, moments/Krylov and all full lower-bound transports remain separate.'
newguide=guide.replace(old,new,1); assert newguide!=guide and guide.count(old)==1
old='This mathematical density identity does not close the separate full unweighted Gaussian integral/known-normalizer proposition. C4 calculus/minimizer, Gaussian target-law/TV parameter transport, operational adaptive/seed/transcript/output simulation, deterministic/expected costs, finite-precision adapters and Krylov/moment/main-bound composition remain separate.'
new=r'The actual unweighted Euclidean Gaussian normalizing integral is additionally compiled and independently source-reviewed at the same exact source inputs: \(w_A(x)=e^{-x^\top A x/2}\) is integrable and \(Z_A:=\int w_A\,dx=(2\pi)^{d/2}/\sqrt{\prod_i\lambda_i}\). Its proof genuinely reuses actual admissibility, the actual determinant product and the identical canonical GaussianPrecisionDensity node; finite integrability and positive mass are derived internally from the actual Gaussian probability law. Interpreting the source normalizer as this unweighted Lebesgue integral is a disclosed standard source-implicit elaboration. A genuine same-A Test consumes this new integral to obtain \(N(0,A^{-1})(dx)=w_A(x)/Z_A\,dx\). Only \(Z_A\) is independent of \(O\); the covariance and exponent keep the actual hidden \(A\). The existing canonical density parent retains its historical source/publication audit debt. Remaining C4 calculus/minimizer, strict historical angle/cosine route, Gaussian target-law/TV parameter transport, operational adaptive/seed/transcript/output simulation, deterministic/expected costs, finite-precision adapters and Krylov/moment/main-bound composition remain separate.'
newboundary=boundary.replace(old,new,1); assert newboundary!=boundary and boundary.count(old)==1 and newboundary.endswith(suffix)
changed=before[PATHS[4]]
for a,b in [(guide,newguide),(boundary,newboundary)]:
 x=json.dumps(a,ensure_ascii=False).encode(); y=json.dumps(b,ensure_ascii=False).encode(); assert changed.count(x)==1; changed=changed.replace(x,y,1)
delta=differences(f,json.loads(changed)); assert set(delta)=={'/cases/4/reader_guide/3','/cases/4/theorems/1/boundary'}
plans[PATHS[4]]=changed
plans[PATHS[5]]=r'''# AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumNormalizer

- File: `AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumNormalizer.lean`.
- Sole public declaration: `actual_normalizing_integral`; one new mathematical node.
- Mathematical candidate: `8d33e06485edc17320cc01308af40da44945659d`; publication binding `b2f41e36a9d705ff68da71f72f0ec14f1cd2ff105bcf0ae5000ef1406a5d1f41`. Independent current source/whole-module review, normal source V and sole STAB are application prerequisites.
- Exactly `d >= 2`, `kappa >= 2` and every full real `O in O(d)`, including either determinant sign. Literal cosine-grid `A = O diagonal(lambda) O^T`; zero-based `j.val+1/2` is source one-based `i-1/2`.
- Result: the actual weight \(w_A(x)=e^{-x^\top A x/2}\) is integrable against unweighted Euclidean Lebesgue volume, and \(Z_A:=\int w_A\,dx=(2\pi)^{d/2}/\sqrt{\prod_i\lambda_i}\). The exponent `d/2` is real, including odd dimensions. The integral convention and explicit integrability are disclosed standard source-implicit elaborations of the paper normalizer.
- Actual producer parents: existing `FixedSpectrumAdmissibility.actual_precision_admissible`, `FixedSpectrumDeterminant.actual_precision_det` and the identical canonical `GaussianPrecisionDensity.multivariateGaussian_eq_withDensity_of_posDef`. No determinant, positivity, measurability, integrability, finite mass or normalization conclusion is a public premise.
- Proof: actual SPD and determinant product → canonical same-A density → unit probability mass → continuity/nonnegativity and finite nonnegative integral → actual finite integrability → actual real integral value. This Gaussian-density implementation OR-route does not alter the independently reconstructed author Source Proof Graph. No circular dependence on this new integral occurs in the old density parent.
- Real consumer: the private Test `actual_gaussian_density_consumer` expresses the same actual \(N(0,A^{-1})\) as \(w_A(x)/(\int w_A\,dx)\,dx\), with actual mass positivity derived internally. Its four actual kernel ASTIS parents are the three producer parents plus the new integral. The private name enables kernel reflection, without a public/Registry consumer node.
- Only \(Z_A\) is independent of orientation; covariance and exponent retain actual hidden `A`. No equality of differently oriented laws or algorithmic/TV transport follows.
- Existing GPD is one canonical node. Its compilation-only inventory admission exposes the actual parent and natural existing references; its old `ASTIS-SHARED-gaussian-precision-density` frontier remains `proved_locally`, without independent verification, and its historical `gaussian-complexity-law-density` source/publication audit debt remains. New normalizer source V does not review that old module. The generated GPD theorem card displays explicit debt warning in its proof architecture, external-location text and tags; its full Registry note remains available in source.
- Source: Zhou–Suzuki arXiv2610.20492v1 Eq11/S4.SS1, S2 target convention and Appendix C.4 Gaussian integration in A3.Ex160. Authored six-step mathematics: `website/content/declaration_lessons/huanjian-fixed-spectrum-normalizer.json`; corresponding publication uses the same basename.
- Graph: same canonical IDs; three producer references stay dashed source-name scans, independently supported by separate kernel inventory. Imports/declares are structural. No new mechanism bridge, Graph Memory or Functor model change.
- Remaining: C4 calculus/strong convexity/smoothness/unique minimizer, strict historical angle/cosine route, moments/Krylov, adaptive/private-seed/transcript/output laws, actual oracle/finite precision/TV and deterministic worstcap/explicit expectedcost adapters, both complete main lower bounds, remote release/publication, postmerge purification/Exposition Seal and whole Goal. The fixed-spectrum main theorem retains fixed delta in(0,1), large d,2<=kappa<=d^(1-delta),0<epsilon<=1/10; determinant-sign domains remain distinct. Section4.4 limits the current uniform-Krylov proof, not all stronger lower bounds.
'''.encode()
assert set(plans)==set(PATHS)
# Virtual scanner only. Deep-copy each list independently: enrich_entries mutates entries.
entries=site.parse_registry(); assert not [e for e in entries if e.local_decl in (GPD,DECL)]
def virtual_entry(key,decl,tags,note):
 return site.RegistryEntry(key=key,local_decl=decl,upstream_decl='Conditional virtual inventory',upstream_file='Existing local source',status='formalizedLocal',tags=tags,sald_use='Canonical reuse',note=note)
n=virtual_entry('gaussian-complexity.fixed-spectrum-normalizer',DECL,['actual-normalizing-integral'],'New source result; conditional proposal')
g=virtual_entry('measure.gaussian-precision-density-existing-canonical',GPD,['compilation-only-index','legacy-source-publication-audit-debt'],'Existing compiled node; old source/publication debt retained')
baseline,_=site.enrich_entries(copy.deepcopy(entries))
without,_=site.enrich_entries(copy.deepcopy(entries+[n]))
after,_=site.enrich_entries(copy.deepcopy(entries+[g,n]))
def row(e): return {'source_file':e.source_file,'source_line':e.source_line,'dependencies':e.dependencies,'consumers':e.consumers,'status':e.status,'explicit_test':e.explicit_test,'source_text_sha256':sha(e.source_text.encode())}
br={e.local_decl:row(e) for e in baseline}; wr={e.local_decl:row(e) for e in without}; ar={e.local_decl:row(e) for e in after}
assert wr[DECL]['dependencies']==[ADMISS,DET] and ar[DECL]['dependencies']==PARENTS
assert ar[GPD]['dependencies']==[RN] and ar[GPD]['consumers']==[AVERAGED,DECL]
old_deltas={k:{'before':v,'after':ar[k]} for k,v in br.items() if v!=ar[k]}
assert set(old_deltas)=={ADMISS,DET,AVERAGED,RN}
for k,d in old_deltas.items():
 a,b=copy.deepcopy(d['before']),copy.deepcopy(d['after'])
 if k in (ADMISS,DET): assert b['consumers']==a['consumers']+[DECL]; b['consumers']=a['consumers']
 elif k==AVERAGED: assert b['dependencies']==a['dependencies']+[GPD]; b['dependencies']=a['dependencies']
 else: assert set(b['consumers'])==set(a['consumers'])|{GPD}; b['consumers']=a['consumers']
 assert a==b
graphraw=(R/'_site/data/underlying-lean-graph.json').read_bytes(); graph=json.loads(graphraw)
gpds=[n for n in graph['nodes'] if n['id']=='decl:'+GPD]; assert len(gpds)==1 and gpds[0]['status']=='partial'
inventory=json.loads((R/'_site/data/site-data.json').read_bytes()); ir=[d for d in inventory['declarations'] if d['full_name']==GPD]
assert len(ir)==1 and ir[0]['local_status']=='Compiled' and ir[0]['has_placeholder'] is False
oldgpd=json.loads((R/'research-wiki/frontier-cells/ASTIS-SHARED-gaussian-precision-density.json').read_bytes())
assert oldgpd['status']=='proved_locally' and not oldgpd.get('independent_verification')
O.mkdir(parents=True,exist_ok=False)
rows=[]; diff=b''
for i,p in enumerate(PATHS,1):
 a,b=before[p],plans[p]; assert a!=b
 d={'path':p,'before_exists':a is not None,'before_sha256':sha(a) if a is not None else None,'planned_after_sha256':sha(b),'planned_after_archive':archive(f'path-{i}.planned-after.raw.gz',b)}
 if a is not None: d['before_archive']=archive(f'path-{i}.before.raw.gz',a)
 rows.append(d); diff+=b''.join(difflib.diff_bytes(difflib.unified_diff,(a or b'').splitlines(keepends=True),b.splitlines(keepends=True),fromfile=('a/'+p).encode() if a is not None else b'/dev/null',tofile=('b/'+p).encode()))
(S/'exact-proposed-shared-v2.diff').write_bytes(diff)
ledger={}; foreign={}
for p,replay in [('runs/substantive_advances.jsonl',adv._replay_advances),('runs/substantive_discoveries.jsonl',adv._replay_discoveries)]:
 raw=(R/p).read_bytes(); assert raw.endswith(b'\n'); ss=replay([json.loads(x) for x in raw.splitlines() if x.strip()])
 if 'advances' in p: own=ss.pop(ADV)
 else: ss={k:v for k,v in ss.items() if v.get('advance_id')!=ADV}
 foreign[p]=ss; ledger[p]={'raw_prefix':archive(Path(p).name+'.prefix.raw.gz',raw),'foreign_projection':archive(Path(p).name+'.foreign-projection.json.gz',canon(ss)),'foreign_projected_records':len(ss)}
assert own['state']=='PROVED_LOCAL' and own['owner_id']==OWNER
assert not [k for k,v in foreign['runs/substantive_advances.jsonl'].items() if v['state']=='STABILIZING']
markers=('FixedSpectrumNormalizer','fixed-spectrum-normalizer','huanjian-fixed-spectrum-normalizer')
gitmap={}; protected={}
for line in cmd('git','ls-files','--stage','-z').split(b'\0'):
 if not line: continue
 md,p=line.split(b'\t',1); p=os.fsdecode(p); mode,blob,stage=md.decode().split(); assert stage=='0'
 if p in PATHS or p in ledger or any(m in p for m in markers): continue
 gitmap[p]=[mode,blob]
 if not p.startswith('runs/'):
  q=R/p; raw=os.fsencode(os.readlink(q)) if q.is_symlink() else q.read_bytes(); protected[p]={'sha256':sha(raw),'bytes':len(raw)}
frontiers={str(p.relative_to(R)):sha(p.read_bytes()) for p in (R/'research-wiki/frontier-cells').glob('*.json') if p.stem!=CELL}
assert len(frontiers)==442
older={str(p.relative_to(R)):sha(p.read_bytes()) for p in (R/'research-wiki/paper-contributions/GaussianComplexity').rglob('*') if p.is_file() and not any(m in str(p.relative_to(R)) for m in markers)}
masked=copy.deepcopy(f); masked['cases'][4]['reader_guide'][3]='<OWN_NORMALIZER_SCALAR>'; masked['cases'][4]['theorems'][1]['boundary']='<OWN_NORMALIZER_SCALAR>'
inputs=list(PINS)+['AGENTS.md','docs/contributor-codex-contract.md','docs/theorem-publication-protocol.md','docs/proof-digestion-protocol.md','docs/evidence-routed-memory-protocol.md','docs/samplewiki-reader-navigation.md','.agents/skills/astis-substantive-advance/SKILL.md','website/scripts/underlying_lean_graph_textbook.py','tools/astis_site.py','research-wiki/frontier-cells/ASTIS-SHARED-gaussian-precision-density.json','website/content/publications/gaussian-complexity-law-density.json','website/content/declaration_lessons/gaussian-complexity-law-density.json']
inputs += [str((E/p).relative_to(R)) for p in ['local-proof-capsule.json','publication-draft-record.json','actual-baseline.json','initial-queue-and-frontier-protection.json','integration-preflight-canonical-parent-visibility.json','integration-preflight-canonical-parent-visibility-corrected.json']]
scanner={'scope':'Actual read-only parse_registry/enrich_entries virtual list admission; no Registry write or site/graph build. Each mutable input list independently deep-copied.','without_GPD_inventory':wr[DECL],'with_GPD_inventory':ar[DECL],'GPD_virtual_row':ar[GPD],'only_old_row_deltas':old_deltas,'actual_preexisting_graph_GPD':gpds[0],'actual_source_inventory_GPD':ir[0],'existing_generated_graph_sha256':sha(graphraw),'old_frontier_status':oldgpd['status'],'old_frontier_independent_verification':oldgpd.get('independent_verification'),'necessity':'GPD already exists as decl: source-present partial node; add_textbook emits scanner edges only among Registry decl_ids before later publication overlays. New producer without inventory shows two parents; minimal canonical GPD inventory exposes all three.','natural_extra_reference_edges':[[RN,GPD],[GPD,AVERAGED]],'not_kernel_evidence':'All graph references remain source reference (scanner), dashed and incomplete; actual kernel parents are separately pinned producer/Test evidence.'}
atlas=(R/'.atlas-upstream').stat()
report={
 'reviewer':ACTOR,'phase':'Exact conditional six-path proposal only; no shared application, sourceV, STAB or actual acceptance',
 'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head_at_start':HEAD,'mathematical_candidate':CANDIDATE,'publication_binding_sha256':BINDING,
 'verdict':'NO_BLOCKING_OBJECTION_TO_EXACT_CONDITIONAL_PROPOSAL','sourceV':'Not issued; fresh independent exact-binding source/whole-module review pending.','build_site_browser_runs':[],
 'shared_paths':rows,'shared_path_count':6,'new_mathematical_Registry_nodes':1,'existing_canonical_nodes_newly_indexed':1,'new_theorems':1,'administrative_count_only':'620 -> 622; one new normalizer plus one existing compiled GPD inventory; counts are not mathematics',
 'Registry_exact_insertions':{'normalizer':archive('normalizer-entry.raw.gz',normal_entry.encode()),'GPD_compilation_only':archive('GPD-entry.raw.gz',gpd_entry.encode())},'all_old_Registry_bytes_preserved':True,
 'formal_ASTIS_producer_parents':PARENTS,'formal_ASTIS_consumer_parents':PARENTS+[DECL],'private_Test_has_no_public_or_Registry_node':True,
 'source_Test_lesson_publication_pins':PINS,'unchanged_models':MODELS,'input_archives':{p:archive(f'input-{i+1}.raw.gz',(R/p).read_bytes()) for i,p in enumerate(inputs)},
 'actual_readonly_scanner':archive('actual-readonly-scanner.json.raw.gz',dump(scanner)),
 'GPD_debt_decision':'Existing canonical node ID retained. Compilation-only inventory status may become compiled, but old frontier proved_locally/no independent_verification and old publication/lesson bytes stay exact. The generated GPD theorem card visible saldUse, upstreamFile and tags plus graph debt tags make legacy source/publication audit debt reachable; the renderer does not display Registry note. New normalizer sourceV confers no old sourceV.',
 'bounded_natural_reference_delta':{'new_producer_incoming':PARENTS,'newly_visible_existing_references':[[RN,GPD],[GPD,AVERAGED]],'only_prior_Registry_rows_changed':list(old_deltas),'all_other_prior_scanner_rows_preserved':True},
 'frontier_scalar_pointer_delta':delta,'protected_case_values':{'execution_sha256':sha(canon(f['execution'])),'determinant_theorem_index0_sha256':sha(canon(f['cases'][4]['theorems'][0])),'all_other_case_values_sha256':sha(canon(masked)),'Section4_4_limitation_suffix':suffix,'Section4_4_suffix_sha256':sha(suffix.encode())},
 'raw_diff':archive('exact-proposed-shared.diff.gz',diff),'ledger_protection':ledger,'foreign_frontiers':{'count':len(frontiers),**archive('all-442-foreign-frontier-hashes.json.gz',canon(frontiers))},'older_GaussianComplexity_evidence':{'count':len(older),**archive('all-older-GaussianComplexity-evidence-hashes.json.gz',canon(older))},'protected_git_objects':{'count':len(gitmap),**archive('protected-tracked-git-objects.json.gz',canon(gitmap))},'protected_foreign_content':{'count':len(protected),**archive('protected-foreign-content-sha256.json.gz',canon(protected))},'own_state_at_snapshot':own['state'],
 'README_preservation':{'path':'research-wiki/paper-contributions/GaussianComplexity/README.md','sha256':sha((R/'research-wiki/paper-contributions/GaussianComplexity/README.md').read_bytes()),'scope':'Protected through local acceptance; root may append separately after normal parking.'},
 'untracked_Atlas':{'path':'.atlas-upstream','scope':'Stat only; no traversal/content access','device':atlas.st_dev,'inode':atlas.st_ino,'mtime_ns':atlas.st_mtime_ns},
 'application_preconditions':['Fresh independent current-binding sourceV and accepted whole-module/reader review.','Root explicit sole normal STAB/application authorization; other owners and queue preserved.','Exact all before hashes and absent new card; apply only six archived after payloads.','Freeze a new immutable core; actual current official rootTests/ASTIS/publication/contributor/semantic/frontier/site/graph checks.','Fresh actual Chrome desktop1440/mobile390 six-step readers and exact Lean folds/source-index/module/download/graph native clicks; independently inspect all original images and raw receipts.','Acceptance and normal parking are separate; no remote retry, push, merge or Bench mutation.'],
 'later_acceptance_scope':['Every exact current producer parent and four-parent private consumer shown without turning scanner references into kernel certificates.','GPD identical canonical ID; compilation-only/debt warning visible through generated own-site card saldUse, upstreamFile and tags; old source binding/frontier/audit bytes unchanged.','Only two allowed guide/boundary scalar changes; first main theorem, execution, full fixed theorem domain and Section4.4 limitation suffix exact.','Raw image visual review must be separately authored after actual image opening; no helper auto-certification or predecessor-image reuse.'],
 'remaining_open':['Fresh sourceV and local final immutable root/site/graph/browser acceptance','Remaining C4 calculus/minimizer and strict historical angle/cosine route; moments/Krylov','Adaptive/seed/transcript/output, actual oracle/finiteprecision/TV and worstcap/expectedcost adapters; both complete main lower bounds','Original owner PR385 release/remote publication, postmerge purification/ExpositionSeal and wholeGoal'],
 'supersedes':{'report':'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-normalizer-integration-20261108/independent-reader/proposal/proposal-report.json','sha256':'2cd9baeb7582c6d0efa5bb019045a4cf2ac707010beeda7dfc828edf4ffdb1be','reason':'Initial frozen proposal incorrectly said generated theorem_card renders Registry note. The actual renderer shows saldUse/upstreamFile/tags; v2 places debt explicitly there and preserves original artifacts.'},
 'preparation_failures_retained':'A read-only inline virtual preflight first omitted required RegistryEntry constructor metadata (TypeError). A later diagnostic reused mutable n across enrichment calls; final preparation independently deep-copies full entry lists and asserts exact 2-parent vs 3-parent result. No shared data or theorem changed.'
}
for p,h in {**PINS,**MODELS}.items(): assert sha((R/p).read_bytes())==h,p
for p,raw in before.items(): assert ((R/p).read_bytes() if (R/p).exists() else None)==raw,p
assert cmd('git','rev-parse','HEAD').decode().strip()==HEAD
report['head_at_end']=HEAD
(O/'proposal-report.json').write_bytes(dump(report))
freeze={'reviewer':ACTOR,'phase':report['phase'],'report_sha256':sha((O/'proposal-report.json').read_bytes()),'diff_raw_sha256':sha(diff),'shared_paths':rows,'models':MODELS,'application_authorized':False,'acceptance':'NOT_RUN'}
(O/'freeze.json').write_bytes(dump(freeze))
(O/'initial-worktree-status.txt').write_bytes(cmd('git','status','--short','--untracked-files=normal'))
archive('proposal-preparation-driver.py.raw.gz',Path(__file__).read_bytes())
print(json.dumps({'report':str((O/'proposal-report.json').relative_to(R)),'report_sha256':sha((O/'proposal-report.json').read_bytes()),'freeze_sha256':sha((O/'freeze.json').read_bytes()),'diff_raw_sha256':sha(diff),'shared_path_count':6,'foreign_SAUs':len(foreign['runs/substantive_advances.jsonl']),'foreign_frontiers':len(frontiers),'administrative_count':'620->622','applied':False},indent=2))
