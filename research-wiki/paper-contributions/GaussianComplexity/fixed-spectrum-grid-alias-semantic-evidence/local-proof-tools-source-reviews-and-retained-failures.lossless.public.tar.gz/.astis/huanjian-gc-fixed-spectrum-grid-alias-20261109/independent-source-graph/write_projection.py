from pathlib import Path
from hashlib import sha256
import json,datetime
D=Path('.astis/huanjian-gc-fixed-spectrum-grid-alias-20261109/independent-source-graph')
p2=D/'phase2'; seal=json.loads((p2/'inputs/statement-seal-v2.json').read_text()); formation=json.loads((p2/'inputs/type-formation-and-seal-confirmation-v2.json').read_text())
fixed='5abb51d681187baa67985c54f942a670cdc79e65a5ef12393dcaf8c94a376285'
assert sha256((p2/'inputs/statement-seal-v2.json').read_bytes()).hexdigest()==fixed
for key in ['producer','actual_private_consumer']:
 assert sha256(seal[key]['signature'].encode()).hexdigest()==seal[key]['signature_sha256']
assert formation['seal']['sha256']==fixed
frozen=json.loads((D/'phase1-freeze-manifest.json').read_text())
for rec in frozen['phase1_files']:assert sha256((D/rec['path']).read_bytes()).hexdigest()==rec['sha256'],rec['path']
checks=[
('producer-index','PASS','theta on Fin d is (i.val+1/2)*pi/d. Source i runs 1,...,d, so source_i=i.val+1 yields source_i-1/2=i.val+1/2. The d summands are neither endpoint grid nor continuous average.'),
('producer-domain','PASS','Source p3 says every integer k. The exact signature k:Int includes negative, zero, odd/even and divisible/nondivisible frequencies, with no extra parameter restriction.'),
('zero-frequency','PASS','k=0 is divisible; quotient=0, zpow(-1,0)=1, so RHS=d as the sum of d constant ones. This case is not covered by an unsafe sine-denominator division.'),
('negative-frequencies','PASS','Negative multiples have negative integer quotients. The exponent is Int, hence zpow, and -1 is nonzero. Its inverse equals itself, preserving source parity; cosine is even. Negative nonmultiples take literal zero. No toNat or Nat subtraction truncation occurs.'),
('quotient-branch','PASS','hd implies 2*(d:Int)>0. Under divisibility k/(2*d) is the unique integer a with k=2ad. The quotient is only semantically used in the divisible branch; the other branch is zero. This is an arithmetic literal definition, not a quotient-space representative choice.'),
('producer-binders','PASS','d:Nat is TYPING; hd:2<=d is STANDING at Section4.1; k:Int is SOURCE at p3. No κ, Gaussian law, random basis, radius/convergence/denominator hypothesis or proof-result binder appears.'),
('consumer-binders','PASS','d:Nat is TYPING, hd STANDING; κ:Real is TYPING with hκ STANDING κ>=2; n:Nat is TYPING with hn/hnd SOURCE 1<=n<d. Nat+these inequalities exactly represents the positive source integers n. No d-n>=sqrt(κ) or summability hypothesis is imported.'),
('consumer-local-definitions','PASS','All meaning-carrying project objects in the signature are literal let bodies theta/eigenvalue/r/a; no recursive project-owned Prop alias/structure/typeclass hides a logical input. Finite sum and real tsum/Summable have standard carrier semantics. eigenvalue and r agree with S4.E11 and Lemma4.5.'),
('consumer-positive-series','PASS','j:Nat corresponds to source j_source=j+1>=1. Both coefficient exponent and frequencies use j+1. The frequency j+1-n is formed after coercion into Int, preserving j+1<n and j+1=n cases. The exponent j+1 remains Nat as in the source positive-frequency series.'),
('consumer-normalization','PASS','C7 contributes 1/sqrt(κ) and factor 2. Product-to-sum contributes half, so the 2 cancels. Each grid inner sum contributes d*a(k); the exact sealed outside factor is d/sqrt(κ). The weighted finite grid sum is unnormalized.'),
('constant-elimination','PASS','Because 1<=n<d and d>=2, n is not a multiple of 2d; alias applied at k=n yields zero constant grid sum. This is a derived proof edge, not a new premise.'),
('product-to-sum','PASS','For each positive source frequency j+1, 2*cos((j+1)theta_i)*cos(n theta_i) becomes cos(((j+1)-n)theta_i)+cos(((j+1)+n)theta_i). The exact sealed two alias arguments match both signs.'),
('convergence-and-exchange','PASS-as-statement-obligation','C7 source absolute convergence on each theta, the finite grid and bounded cosine weights support weighted convergence and finite-sum/tsum exchange. The exact statement requires Summable of the supported series as a CONCLUSION. It cannot exploit nonsummable tsum default behavior. No implementation or successful proof is inspected.'),
('genuine-consumer','ADMISSIBLE-ONLY-WITH-POSTPROOF-USE-CHECK','The consumer conclusion exposes the actual reciprocal-grid sum and the supported-series identity, with no theorem-shaped input premise. It is a meaningful consumer design of C7+new alias. Its implementation must actually apply C7 and new alias at n,(j+1)-n,(j+1)+n and establish summability/exchange. Signature/type formation alone cannot certify that dependency or give Lean credit.'),
('open-bridges','PASS','No Gaussian variable/expectation appears in the target. The p4 identification and p6 tail partition/regrouping/closed geometric resummation remain explicit open excluded source obligations. Neither full C8 nor Lemma4.5 follows from this packet.'),
('topology-vs-imports','PASS','The projected source edges are author-use sites. Planned ASTIS parent names from the seal are expectations to check after proof; no imports, declaration inventory or root assertion was used as dependency evidence.')]
projection={
'schema_version':1,'seal_id':seal['seal_id'],'seal_sha256':fixed,'raw_source_sha256':'6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915',
'phase1_graph_sha256':sha256((D/'phase1/raw-first-author-graph.json').read_bytes()).hexdigest(),
'signatures':{k:{'name':seal[k]['name'],'signature_sha256':seal[k]['signature_sha256']} for k in ['producer','actual_private_consumer']},
'projection_nodes':[
 {'source_node':'standing-grid','interface':'producer and consumer theta; d,hd; consumer eigenvalue,hκ','disposition':'literal-source-standing'},
 {'source_node':'rho','interface':'consumer r','disposition':'literal-source-definition'},
 {'source_node':'integer-alias','interface':seal['producer']['name'],'disposition':'bounded-source-anchor-proposed'},
 {'source_node':'c7-expand','interface':'required actual C7 dependency inside consumer proof','disposition':'upstream-source-prerequisite-no-reverification'},
 {'source_node':'finite-series-exchange','interface':'consumer supported-series Summable and finite-sum/tsum identity','disposition':'internal-derived-obligation'},
 {'source_node':'weighted-constant-zero','interface':'consumer proof must apply alias at n','disposition':'internal-derived-obligation'},
 {'source_node':'weighted-product-sum','interface':'consumer proof must expose the two frequency shifts','disposition':'internal-derived-obligation'},
 {'source_node':'weighted-prealias-series','interface':'deterministic LHS of private consumer','disposition':'source Ex144 after explicitly excluded expectation adapter'},
 {'source_node':'weighted-alias-supported-series','interface':seal['actual_private_consumer']['name'],'disposition':'bounded-actual-private-consumer-proposed'}],
'projected_edges':[
 {'parents':['standing-grid'],'consumer':'integer-alias','use_site':'A3.SS3.p3;A3.Ex139','side_conditions':'d>=2; k arbitrary Int; branch cases collectively exhaustive'},
 {'parents':['c7-expand','finite-series-exchange','weighted-constant-zero','weighted-product-sum'],'consumer':'weighted-prealias-series','use_site':'A3.SS3.p4.2 and p6.1;A3.Ex144','side_conditions':'1<=n<d; pointwise C7 plus absolute convergence; no added premise'},
 {'parents':['weighted-prealias-series','integer-alias'],'consumer':'weighted-alias-supported-series','use_site':'A3.Ex144 inner grids; A3.SS3.p6.2 alias values before tail extraction','side_conditions':'Apply all-integer alias independently to j+1-n and j+1+n; n alias already used for constant term'}],
'binder_and_definition_checks':[dict(check=i,status=s,finding=f) for i,s,f in checks],
'EXCESS':[],
'explicit_open_exclusions':[
 {'source':'A3.SS3.p4.1;A3.Ex140','node':'expectation-to-grid','state':'OPEN/excluded','reason':'Gaussian second-moment identification, not part of deterministic interface'},
 {'source':'A3.SS3.p5.1;A3.EGx15','node':'unweighted-tail-resum','state':'OPEN/excluded','reason':'Unweighted trace alias extraction/closed geometric sum'},
 {'source':'A3.SS3.p6.2;A3.EGx16','node':'weighted-tail-classes;weighted-tail-resum','state':'OPEN/excluded','reason':'Three-class partition/disjointness/parity, infinite regrouping and closed weighted formula remain future dependencies'},
 {'source':'A3.SS3.p7-p11','state':'EXCLUDED/outside-bounded-slice','reason':'C8-to-Lemma4.5, Gaussian variance and normalized bias follow-up are not admitted by this packet'}],
'phase1_preserved_clarification':{
 'raw_graph_unmodified':True,
 'context_only_c8_edge':'The phase1 edge into c8-means is explicitly labelled incomplete and therefore is not a sufficient hyperedge or admitted closure. Its missing closed-tail parents are OPEN nodes. This exact bounded projection does not include that context edge at all. Do not flatten it into an AND implication certifying C8.',
 'branch_semantics':'The two p3 branch providers form a guarded exhaustive case split proving a universal identity. They are not competing OR proof routes or premises supplied by the user.'},
'bounded_verdict':'ADMIT_EXACT_V2_FOR_SOURCE_TOPOLOGY_AND_BINDER_SCOPE_ONLY_SUBJECT_TO_DISTINCT_TOPOLOGY_REVIEW',
'not_admitted':['Lean proof','actual compiled consumer use','Registry/frontier/ledger transition','whole C8','Gaussian mean identification','tail closed resummation','Lemma4.5 variance/bias','whole paper or Goal'],
'prior_graph_consulted':False,'implementation_exposure':False,'proof_API_exposure':False,'self_VERIFIED':False}
(p2/'exact-interface-projection.json').write_text(json.dumps(projection,indent=2)+'\n')
(p2/'review-report.md').write_text('''# Exact v2 bounded source admission

I recommend admitting seal GC-FIXED-SPECTRUM-GRID-ALIAS-20261109-v2 (SHA256 5abb51d681187baa67985c54f942a670cdc79e65a5ef12393dcaf8c94a376285) for the proposed all-integer alias anchor and actual private deterministic weighted alias-series consumer. This is source/binder/topology admission only, pending the distinct topology challenge. It is not proof acceptance or VERIFIED.

The independent raw-first source graph and exhaustive bounded inventory were frozen before the seal or formation confirmation was read. No implementation Lean, proof API, Registry, production lesson/audit, prior source graph or prior graph verdict was read. Filename-only search exposure is recorded. A challenger sent a preliminary seal-pass message after the freeze; I did not use that message as evidence. The exact seal hash, both signature hashes and formation-confirmation seal binding were independently recomputed; formation is not proof.

The producer preserves source every-integer k, including zero and negative aliases. Fin d has the exact source index shift i_source=i.val+1. Divisibility by positive 2*d selects the unique source quotient, with integer powers of -1, so negative parity is preserved and the nondivisible branch is literal zero. There is no extra convergence, denominator or frequency premise.

The consumer uses positive j+1 frequencies and Int subtraction before evaluating a(j+1-n). Its weighted reciprocal-grid sum retains the actual half-shifted eigenvalues. Constant elimination uses 1<=n<d; C7 factor2 cancels the product-to-sum half; the inner grid sums contribute d, producing d/sqrt(kappa). The coefficient series is required to be Summable in the conclusion. All binder inputs are TYPING, STANDING or SOURCE; EXCESS is empty. No project-owned Prop alias hides an input.

The intended proof must actually consume C7 and the new alias, produce weighted convergence and finite/series interchange, remove the constant term by alias at n, and apply alias at both j+1-n and j+1+n. This signature is a genuine meaningful consumer design; actual compiled use remains a later check and cannot be inferred from imports, parent names or a wrapper/#check.

Gaussian expectation identification p4/Ex140, unweighted tail closed resummation p5, weighted tail partition/regrouping/closed resummation p6.2/EGx16 and p7-p11 variance/bias are explicitly open or excluded. The deterministic left side is W_n; the source mu_n is an expectation requiring the separate bridge. C8 and Lemma4.5 remain open.

Phase1 stays immutable. Its context-only c8-means edge is explicitly incomplete and does not assert sufficiency; the exact bounded projection omits it. The all-integer branch proof remains a guarded case split. Coverage is exhaustive for the listed bounded raw roots only, with p7-p11 dispositions explicitly outside scope; no whole-paper coverage claim is made. A distinct reviewer must approve the extractor's graph.
''')
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
(p2/'exposure-timeline-final.json').write_text(json.dumps({'phase1_timeline':'phase1/exposure-timeline-through-freeze.json','events':[{'event':'E11','exposure':'After phase1 freeze, root bounded-scope reminder and formation exit0 message; separate challenger preliminary seal-pass message. No graph/implementation content.'},{'event':'E12','exposure':'Exact v2 seal and formation confirmation read and snapshotted; full metadata exposure includes named planned parent declarations and old-manifest path but no referenced files were opened.'},{'event':'E13','utc':now,'exposure':'Independent sealed-interface projection written from frozen raw graph. No prior graph evidence was consulted and no implementation/API/proof work occurred.'}]},indent=2)+'\n')
files=[]
for p in sorted(D.rglob('*')):
 if p.is_file() and p.name not in ['FINAL-MANIFEST.json','SHA256SUMS']:
  b=p.read_bytes();files.append({'path':str(p.relative_to(D)),'sha256':sha256(b).hexdigest(),'bytes':len(b)})
manifest={'created_utc':now,'immutable_by_protocol':True,'scope':'Independent bounded source-first graph, binder/interface projection only. Not self-approved topology/VERIFIED and no proof credit.','seal_sha256':fixed,'files':files}
(D/'FINAL-MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
lines=[]
for p in sorted(D.rglob('*')):
 if p.is_file() and p.name!='SHA256SUMS':lines.append(sha256(p.read_bytes()).hexdigest()+'  '+str(p.relative_to(D)))
(D/'SHA256SUMS').write_text('\n'.join(lines)+'\n')
for p in [p2/'exact-interface-projection.json',p2/'review-report.md',D/'FINAL-MANIFEST.json',D/'SHA256SUMS']:print(p,sha256(p.read_bytes()).hexdigest())
print('checks',len(checks),'EXCESS',len(projection['EXCESS']),'phase1 immutable verification PASS')
