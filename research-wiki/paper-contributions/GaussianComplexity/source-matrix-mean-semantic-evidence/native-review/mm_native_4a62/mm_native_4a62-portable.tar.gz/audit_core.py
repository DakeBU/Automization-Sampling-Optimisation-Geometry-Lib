#!/usr/bin/env python3
import tarfile
from collections import Counter
from runner import *
def filehash(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        while b:=f.read(1024*1024):h.update(b)
    return h.hexdigest()
def summarize():
    dump=OWN/'local/native-wholemodule.json';obj=json.loads(dump.read_text());constants=obj['constants']
    by={x['name']:x for x in constants};roots=[x['root'] for x in obj['literal_checks']]
    closure=json.loads((OWN/'closure.json').read_text());pmod=P[:-5].replace('/','.');tmod=T[:-5].replace('/','.')
    new={n for n,c in by.items() if c['module'] in [pmod,tmod]}
    def walk(root,owned,stop_public=False):
        seen=set();pending=[root];parents=set()
        while pending:
            n=pending.pop()
            if n in seen:continue
            seen.add(n)
            if n in by:
                c=by[n]
                pending.extend(c['body_used']+c['type_used'])
        return seen
    all_reach=set().union(*(walk(n,by) for n in roots))
    immediate={}
    for root in roots:
        parents=set();seen=set();pending=by[root]['body_used'][:]
        while pending:
            n=pending.pop()
            if n in seen:continue
            seen.add(n)
            if n in new and n!=roots[0]:
                pending.extend(by[n]['body_used']+by[n]['type_used'])
            elif n.startswith('AutoSamplingTheory.'):parents.add(n)
        immediate[root]=sorted(parents)
    expected={roots[0]:[
        'AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumSourceRowLaw.actual_source_row_marginal_law',
        'AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumTruncatedRowMoment.actual_truncated_row_second_moment'],
      roots[1]:[roots[0],
        'AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumCosineGram.actual_cosine_frame_gram']}
    assert all(immediate[r]==sorted(expected[r]) for r in roots),immediate
    assert all(c['closed'] for c in constants)
    assert all(set(c['axioms'])<={'propext','Classical.choice','Quot.sound'} for c in constants)
    assert all(n in all_reach for n in new)
    allowed_axioms=sorted(set().union(*(set(c['axioms']) for c in constants)))
    summaries=[]
    for c in sorted(constants,key=lambda c:c['name']):
        summary={k:v for k,v in c.items() if k not in ['body_raw','type_raw']}
        summary.update({'type_raw_sha256':sha(c['type_raw'].encode()),'type_raw_bytes':len(c['type_raw'].encode()),
          'body_raw_sha256':sha(c['body_raw'].encode()),'body_raw_bytes':len(c['body_raw'].encode()),
          'reachable_from_actual_roots':c['name'] in all_reach})
        summaries.append(summary)
    save('native-wholemodule-summary.json',{'candidate':CANDIDATE,'module_counts':dict(Counter(c['module'] for c in constants)),
        'constant_count':len(constants),'all_closed':True,'axioms':allowed_axioms,
        'new_module_owned_count':len(new),'new_roots':roots,'new_generated':sorted(new-set(roots)),
        'new_all_reachable':True,'actual_immediate_ASTIS_parents':immediate,
        'all_seven_module_constants_reachable_count':sum(c['name'] in all_reach for c in constants),
        'outside_root_closure_constants':[c['name'] for c in constants if c['name'] not in all_reach],
        'literal_checks':obj['literal_checks'],'constants':summaries,
        'local_full_type_body_dump':{'path':'local/native-wholemodule.json','bytes':dump.stat().st_size,'sha256':filehash(dump),
          'portable':False,'replay':'make_native_probe.py then actual native WholeModuleProbe.lean; all full types and proof bodies were read from env.constants/ConstantInfo.value? true'}})
    for i,n in enumerate(roots):
        save('root-type-'+str(i+1)+'.json',{k:by[n][k] for k in ['name','module','level_params','type_pretty','type_raw']})
    old='Tests/GaussianComplexityFixedSpectrumTruncatedRowMoment.lean'
    raw=must('old-retained-source-boundary',['git','show',CANDIDATE+':'+old])
    assert 'private theorem actual_truncated_matrix_summand_mean' in raw.decode()
    save('retained-old-boundary.json',{'path':old,'sha256':sha(raw),'module_in_target_ASTIS_import_closure':False,
        'authored_private':'actual_truncated_matrix_summand_mean',
        'status':'Retained unchanged outside this consumer import closure. Neither global dead-code nor a fresh compiled/native verdict on its generated helpers is asserted.',
        'no_source_or_generated_declaration_deleted':True})
    print('NATIVE SUMMARY',len(constants),'closed; new',len(new),'all reachable; all-seven reachable',sum(c['name'] in all_reach for c in constants))
def archive_spans():
    seal=json.loads((REPO/'research-wiki/paper-contributions/GaussianComplexity/source-matrix-mean-statement-seal.json').read_text())
    raw=(REPO/seal['source']['raw']).read_bytes();text=raw.decode('utf-8')
    assert sha(raw)==seal['source']['raw_sha256']
    source_results=[];lean_results=[]
    def source_span(x,where):
        a,b=x['char_start'],x['char_end'];ba,bb=x['raw_utf8_start'],x['raw_utf8_end']
        span=text[a:b];encoded=span.encode()
        assert len(text[:a].encode())==ba and len(text[:b].encode())==bb
        assert raw[ba:bb]==encoded and sha(encoded)==x['span_sha256'],where
        lf=text.replace('\r\n','\n').replace('\r','\n')
        assert lf==text,'source line normalization not identity: adapt offsets explicitly'
        start=lf[:a].count('\n')+1;end=lf[:b].count('\n')+1
        col=a-(lf.rfind('\n',0,a)+1)
        assert (start,end,col)==(x['lf_line_start'],x['lf_line_end'],x['lf_column0_start']),(where,start,end,col,x)
        source_results.append({'location':where,'source_id':x['source_id'],'sha256':sha(encoded),'bytes':len(encoded),
            'decoded_char_span':[a,b],'raw_UTF8_byte_span':[ba,bb],'LF_line_start_end':[start,end],'LF_column0_start':col})
    def lean_span(x,where):
        path=x['path'];b=(REPO/path).read_bytes();s=b.decode()
        assert sha(b)==x['file_sha256'],path
        ca,cb=x['decoded_char_span'];ba,bb=x['raw_UTF8_byte_span'];ls,le=x['LF_lines_1based']
        exact=''.join(s.splitlines(keepends=True)[ls-1:le])
        assert b[ba:bb]==s[ca:cb].encode()==exact.encode(),where
        assert sha(b[ba:bb])==x['span_sha256']
        assert len(s[:ca].encode())==ba and len(s[:cb].encode())==bb
        lean_results.append({'location':where,'path':path,'sha256':x['span_sha256'],'bytes':bb-ba,
            'decoded_char_span':[ca,cb],'raw_UTF8_byte_span':[ba,bb],'LF_lines_1based':[ls,le]})
    def walk(x,where):
        if isinstance(x,list):
            for i,v in enumerate(x):walk(v,where+'/'+str(i))
        elif isinstance(x,dict):
            if {'char_start','raw_utf8_start','source_id'}<=x.keys():source_span(x,where)
            elif {'path','raw_UTF8_byte_span','decoded_char_span'}<=x.keys():lean_span(x,where)
            else:
                for k,v in x.items():walk(v,where+'/'+k)
    for i,x in enumerate(seal['source']['anchors']):source_span(x,'seal/anchors/'+str(i))
    mapping=json.loads((REPO/E/'source-lean-map.draft.json').read_text())
    assert mapping['source_sha256']==sha(raw)
    # Correspondence span records only; source/topology verdict strings are not read as evidence.
    walk(mapping['mappings'],'map/mappings');walk(mapping['proof_background'],'map/proof_background')
    save('exact-byte-span-audit.json',{'source_sha256':sha(raw),'source_bytes':len(raw),'source_spans':source_results,
      'Lean_spans':lean_results,'all_raw_byte_Unicode_character_LF_spans_exact':True,
      'source_fidelity_verdict':None,'source_topology_verdicts_used':False})
    manifest_path=REPO/E/'preproof-source-types-topology-local-build.original-manifest.json'
    tar_path=REPO/E/'preproof-source-types-topology-local-build.original-files.tar.gz'
    expected=json.loads(manifest_path.read_text())['files'];assert len(expected)==218
    results=[];historical=[]
    tags=['producer-firstbuild','real-consumer-firstbuild','real-consumer-matrix-annotation-v2','real-consumer-implicit-sum-arguments-v3','exact-literal-kernel-and-real-parents']
    with tarfile.open(tar_path) as tf:
        members=tf.getmembers();assert len(members)==218 and all(m.isfile() for m in members)
        assert len(set(m.name for m in members))==218 and set(m.name for m in members)==set(expected)
        for m in members:
            payload=tf.extractfile(m).read();want=expected[m.name]
            assert len(payload)==want['bytes'] and sha(payload)==want['sha256'],m.name
            results.append({'path':m.name,'bytes':len(payload),'sha256':sha(payload)})
            if any(tag in m.name for tag in tags):
                target=OWN/'historical'/Path(m.name).name;target.parent.mkdir(exist_ok=True);target.write_bytes(payload)
                if m.name.endswith('.receipt.json'):
                    rec=json.loads(payload);historical.append({'path':m.name,'receipt':rec})
    assert len(historical)==5,len(historical)
    # Historical raw logs and receipts are preserved selectively; no foreign review packet is exported.
    exit_summary=[]
    for x in historical:
        r=x['receipt'];code=r.get('exit_code',r.get('returncode'))
        assert code in [0,1],(x,code)
        exit_summary.append({'path':x['path'],'exit_code':code,'fields':list(r)})
    expected_codes=[0,1,1,0,0]
    assert [x['exit_code'] for x in exit_summary]==expected_codes,exit_summary
    save('original-archive-member-readback.json',{'archive':str(tar_path.relative_to(REPO)),
      'archive_sha256':filehash(tar_path),'archive_bytes':tar_path.stat().st_size,
      'manifest_sha256':filehash(manifest_path),'members':results,'member_count':218,'every_member_rehashed':True,
      'only_hashes_used_for_foreign_review_members':True,'historical_relevant_receipts':exit_summary,
      'failure_classification':'P first build exit0; T implementation attempts exit1,exit1,exit0; original strict kernel probe exit0. Namespace/schema/typing/API errors are not mathematical counterevidence.'})
    print('SPANS',len(source_results),len(lean_results),'ARCHIVE',len(results),'HISTORY',expected_codes)
def replay():
    env=json.loads((OWN/'environment.json').read_text());pins=json.loads((REPO/'lake-manifest.json').read_text())
    assert sha((REPO/'lake-manifest.json').read_bytes())==env['manifest_sha256']
    assert filehash(env['lean_path'])==env['lean_binary_sha256']
    closure=json.loads((OWN/'closure.json').read_text())
    for m in closure['modules'].values():assert sha((REPO/m['path']).read_bytes())==m['sha256']
    for pkg in pins['packages']:
        root=REPO/'.lake/packages'/pkg['name']
        assert must('replay-pin-'+pkg['name']+'-head',['git','rev-parse','HEAD'],root).decode().strip()==pkg['rev']
        assert must('replay-pin-'+pkg['name']+'-status',['git','status','--porcelain=v1','--untracked-files=all'],root)==b''
    probe=REPO/'.astis/huanjian-gc-source-matrix-mean-20261112/SourceMatrixMeanKernelProbe.lean'
    raw=probe.read_bytes();assert sha(raw)=='95c613dc876aadd8924faa8bca69c7dcf9615d104cc39a1fb30a482a956f11d8'
    (OWN/'fresh/src/RootReplayProbe.lean').write_bytes(raw)
    save('root-probe-binding-before-replay.json',{'candidate':CANDIDATE,'root_probe_path':str(probe.relative_to(REPO)),
      'root_probe_sha256':sha(raw),'candidate_closure_files_still_equal':True,'binary_toolchain_manifest_and_all_9_actual_package_pins_still_equal_and_clean':True,
      'original_probe_source_inspected_before_replay':True})
    must('root-exact-probe-replay',[env['lean_path'],'RootReplayProbe.lean'],OWN/'fresh/src',native_env())
if __name__=='__main__':
    {'summarize':summarize,'archive-spans':archive_spans,'replay':replay}[sys.argv[1]]()
