import AutoSamplingTheory.ExampleCases.ProximalBPS.ActualAbsoluteNextEventTime
import Mathlib.MeasureTheory.Constructions.Pi

/-! Private algebra for the finite-prefix induction. All inputs here will be
instantiated by the literal flow/bounce/rate/hazard of the sealed target. -/
namespace OrderedRecursion92
open MeasureTheory
open scoped NNReal ENNReal
noncomputable section
set_option autoImplicit false

private def state {Z : Type*} (step : ℝ → Z → Z) (z₀ : Z) (n : ℕ) (t : Fin n → ℝ) :
    Fin (n+1) → Z :=
  Fin.induction z₀ (fun i z => step
    (t i - (Fin.cons (0 : ℝ) t : Fin (n+1) → ℝ) i.castSucc) z)

private theorem state_snoc_prefix {Z : Type*} (step : ℝ → Z → Z) (z₀ : Z)
    (n : ℕ) (t : Fin n → ℝ) (u : ℝ) (j : Fin (n+1)) :
    state step z₀ (n+1) (Fin.snoc t u) j.castSucc = state step z₀ n t j := by
  induction j using Fin.induction with
  | zero => rfl
  | succ i ih =>
    rw [← Fin.succ_castSucc]
    simp only [state, Fin.induction_succ] at ih ⊢
    rw [Fin.snoc_castSucc, Fin.cons_snoc_eq_snoc_cons, Fin.snoc_castSucc, ih]

private theorem state_snoc_last {Z : Type*} (step : ℝ → Z → Z) (z₀ : Z)
    (n : ℕ) (t : Fin n → ℝ) (u : ℝ) :
    state step z₀ (n+1) (Fin.snoc t u) (Fin.last (n+1)) =
      step (u - (Fin.cons (0 : ℝ) t : Fin (n+1) → ℝ) (Fin.last n))
        (state step z₀ n t (Fin.last n)) := by
  rw [show Fin.last (n+1) = (Fin.last n).succ from rfl]
  change step ((Fin.snoc t u : Fin (n+1) → ℝ) (Fin.last n) -
    (Fin.cons (0 : ℝ) (Fin.snoc t u) : Fin (n+2) → ℝ) (Fin.last n).castSucc)
    (state step z₀ (n+1) (Fin.snoc t u) (Fin.last n).castSucc) = _
  rw [Fin.snoc_last, Fin.cons_snoc_eq_snoc_cons, Fin.snoc_castSucc, state_snoc_prefix]

private def weight {Z : Type*} (step : ℝ → Z → Z) (factor : Z → ℝ → ℝ)
    (z₀ : Z) (n : ℕ) (t : Fin n → ℝ) : ℝ :=
  ∏ i : Fin n, factor (state step z₀ n t i.castSucc)
    (t i - (Fin.cons (0 : ℝ) t : Fin (n+1) → ℝ) i.castSucc)

private theorem weight_snoc {Z : Type*} (step : ℝ → Z → Z) (factor : Z → ℝ → ℝ)
    (z₀ : Z) (n : ℕ) (t : Fin n → ℝ) (u : ℝ) :
    weight step factor z₀ (n+1) (Fin.snoc t u) = weight step factor z₀ n t *
      factor (state step z₀ n t (Fin.last n))
        (u - (Fin.cons (0 : ℝ) t : Fin (n+1) → ℝ) (Fin.last n)) := by
  simp only [weight, Fin.prod_univ_castSucc]
  rw [state_snoc_prefix, Fin.snoc_last, Fin.cons_snoc_eq_snoc_cons, Fin.snoc_castSucc]
  congr 1
  apply Finset.prod_congr rfl
  intro i _
  simp only [state_snoc_prefix, Fin.snoc_castSucc]

end
end OrderedRecursion92
