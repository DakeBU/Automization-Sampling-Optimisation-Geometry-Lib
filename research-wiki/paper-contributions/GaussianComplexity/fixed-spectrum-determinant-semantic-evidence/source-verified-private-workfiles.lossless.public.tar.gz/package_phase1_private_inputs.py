from pathlib import Path
import tarfile,json,hashlib,subprocess
sha=lambda b:hashlib.sha256(b).hexdigest()
b=Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-determinant-semantic-evidence');m=json.loads((b/'fresh-source-reader-835194/phase1/phase1-manifest.json').read_bytes());rows=[r for r in m['artifacts'] if r['path'].startswith('.astis/')];assert len(rows)==18
p=b/'fresh-source-reader-835194/phase1-private-inputs.lossless.tar.gz';assert not p.exists()
with tarfile.open(p,'w:gz') as t:
 for r in rows:
  q=Path(r['path']);assert sha(q.read_bytes())==r['sha256'];t.add(q,arcname=r['path'],recursive=False)
with tarfile.open(p,'r:gz') as t:
 for r in rows:assert t.extractfile(r['path']).read()==Path(r['path']).read_bytes()
q=b/'fresh-source-reader-835194/phase1-private-inputs.manifest.json';q.write_text(json.dumps({'archive':str(p),'sha256':sha(p.read_bytes()),'all_members_roundtrip_verified':True,'restore_rule':'Restore exact original repository-relative paths in each member; all frozen originals retained locally.','files':rows},indent=2)+'\n');subprocess.run(['git','add','--',str(p),str(q)],check=True);print(json.dumps({'private_phase1_inputs_losslessly_packaged':len(rows),'archive_sha256':sha(p.read_bytes())}))
