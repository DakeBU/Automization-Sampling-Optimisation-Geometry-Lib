from pathlib import Path
import json
R=Path.cwd();O=R/'.astis/semantic-neutral-20261111/rc_native_68bc';s=json.loads((O/'inputs/statement-seal-v2.exact.json').read_text());P=s['producer']['name']
p='import Tests.GaussianComplexityFixedSpectrumTruncatedRowMoment\nimport Lean.Util.CollectAxioms\nimport Lean.Util.FoldConsts\nnoncomputable section\nopen MeasureTheory ProbabilityTheory\nopen scoped Matrix.Norms.L2Operator\nset_option autoImplicit false\n'
p+='''elab "privateTarget68bc" : term => do
  let env ← Lean.getEnv
  let found := env.constants.toList.find? (fun (n, _) => n.toString.endsWith "actual_truncated_matrix_summand_mean")
  let some (n, _) := found | throwError "private consumer missing"
  return Lean.mkConst n
namespace Native68bcV2
'''
p+='theorem public_seal_certificate\n    '+s['producer']['signature'].rstrip()+' := by\n  exact '+P+' hq\n\n'
p+='theorem private_seal_certificate\n    '+s['actual_private_consumer']['signature'].rstrip()+' := by\n  exact privateTarget68bc hq i\n\nend Native68bcV2\n'
p+='\n#print axioms Native68bcV2.public_seal_certificate\n#print axioms Native68bcV2.private_seal_certificate\n#check '+P+'\n'
p+='\n#print Matrix.instL2OpNormedAddCommGroup\n#print Matrix.l2OpNormedAddCommGroupAux\n#print Matrix.l2_opNorm_def\n#print EuclideanSpace\n#print ProbabilityTheory.stdGaussian\n#print Matrix.vecMulVec\n#print Set.indicator\n#print Matrix.kronecker\n#print WithLp.ofLp\n'
p+='''\nopen Lean Elab Command
private def owned68bc (n : Name) : Bool :=
  n.toString.startsWith "AutoSamplingTheory." || n.toString.startsWith "_private.Tests.GaussianComplexityFixedSpectrumTruncatedRowMoment."
run_elab do
  let env ← getEnv
  let found := env.constants.toList.find? (fun (n, _) => n.toString.endsWith "actual_truncated_matrix_summand_mean")
  let some (privateName, pc) := found | throwError "private missing"
  logInfo m!"ACTUAL_PRIVATE_NAME {privateName}"
  logInfo m!"ACTUAL_PRIVATE_TYPE {pc.type}"
  let targets := #[`'''+P+''', privateName]
  let mut frontier := targets.toList
  let mut visited : NameSet := {}
  while !frontier.isEmpty do
    let n := frontier.head!
    frontier := frontier.tail!
    if !visited.contains n then
      visited := visited.insert n
      let some c := env.find? n | throwError "missing target {n}"
      let ds := c.getUsedConstantsAsSet.toList
      let bodyDs := match c.value? (allowOpaque := true) with
        | some v => v.getUsedConstants.toList
        | none => []
      let axs ← collectAxioms n
      logInfo m!"OWNED_DECL {n}"
      logInfo m!"BODY_DIRECT {n}: {bodyDs}"
      logInfo m!"OWNED_DIRECT {n}: {bodyDs.filter owned68bc}"
      logInfo m!"AXIOMS {n}: {axs}"
      for dep in ds do
        if owned68bc dep && !visited.contains dep then frontier := dep :: frontier
  logInfo m!"REACHABLE_OWNED {visited.toList}"
'''
(O/'native-src/CertificatesV2.lean').write_text(p)
