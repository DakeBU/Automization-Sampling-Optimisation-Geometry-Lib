"""Conditional narrow guard repair only; preserve all live/frozen original helpers."""
from pathlib import Path
import ast, datetime, difflib, gzip, hashlib, io, json, subprocess, tarfile
R=Path('/Users/zhouhuanjian/ASTIS-GC')
S=R/'.astis/huanjian-gc-fixed-spectrum-determinant-integration-20261108/independent-reader'
P=R/'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-determinant-integration-20261108/independent-integration-reader-review/proposal/later-helper-preparation'
O=P/'official-wrapper-guard-repair'
CORE='39798cba03364fea6587c4cb8c8e55eb320d5b42'
sha=lambda b:hashlib.sha256(b).hexdigest()
oldmanifest=P/'preparation-manifest.json'
assert sha(oldmanifest.read_bytes())=='070ba1d78548318993e873723dd8ded0c80f2e088b8a5ff0d8cda9848c250e29'
old=json.loads(oldmanifest.read_bytes());assert not O.exists()
before={row['path']:(R/row['path']).read_bytes() for row in old['helpers']}
for row in old['helpers']:assert sha(before[row['path']])==row['raw_sha256']
common_path=str((S/'det_acceptance_common.py').relative_to(R));park_path=str((S/'park_existing_verified_once.py').relative_to(R))
text=before[common_path].decode()
needle="""  assert receipt['elapsed_seconds']>=0 and needle in str(receipt['command'])
  if role=='canonical_lean': assert 'check' in str(receipt['command'])
  rawlog=resolve(receipt['log']).read_bytes(); assert sha(rawlog)==receipt['log_sha256']
"""
replacement="""  assert receipt['elapsed_seconds']>=0
  rawlog=resolve(receipt['log']).read_bytes(); assert sha(rawlog)==receipt['log_sha256']
  if role=='canonical_lean':
   command=receipt['command']
   assert isinstance(command,list) and command and all(isinstance(x,str) for x in command)
   assert re.fullmatch(r'python(?:3(?:\\.\\d+)?)?',Path(command[0]).name)
   output=rawlog.decode('utf-8'); lines=output.splitlines()
   assert lines.count('ASTIS check passed')==1
   if command[1:]==['tools/astis.py','check']:
    pass  # The original direct canonical entry point, with its genuine success log.
   elif command[1:]==['website/scripts/lean_gate.py']:
    wrapper='website/scripts/lean_gate.py'; wrapperraw=(R/wrapper).read_bytes()
    assert wrapperraw==gitraw(core,wrapper)
    assert sha(wrapperraw)=='d69c42b3aee3a60775646711f220e8c558fb447af741616d88bdb8df82d18f91'
    assert gate['commands']==['python3 tools/astis.py check']
    marker='Recorded current Lean gate evidence at .astis/site-lean-gate.json'
    assert lines.count(marker)==1 and output.rstrip().endswith(marker)
    assert 'Lean gate failed; no site evidence was written.' not in output
    assert '::error title=ASTIS Lean gate failed::' not in output
    start=datetime.datetime.strptime(receipt['started_utc'],'%Y%m%dT%H%M%S%fZ').replace(tzinfo=datetime.timezone.utc)
    recorded=datetime.datetime.fromisoformat(gate['generated_at'])
    assert recorded.tzinfo is not None and 0 <= (recorded-start).total_seconds() <= receipt['elapsed_seconds']+2
   else: raise AssertionError('Unrecognized canonical Lean gate entry point; no receipt-shape shortcut.')
  else: assert needle in str(receipt['command'])
"""
assert text.count(needle)==1;aftercommon=text.replace(needle,replacement,1).encode();ast.parse(aftercommon)
text=before[park_path].decode()
needle="expected=P/'later-helper-preparation/preparation-manifest.json'"
replacement="expected=P/'later-helper-preparation/official-wrapper-guard-repair/updated-preparation-manifest.json'"
assert text.count(needle)==1;afterpark=text.replace(needle,replacement,1).encode();ast.parse(afterpark)
after={common_path:aftercommon,park_path:afterpark}
wrapperpath='website/scripts/lean_gate.py';wrapper=(R/wrapperpath).read_bytes()
assert wrapper==subprocess.check_output(['git','show',CORE+':'+wrapperpath],cwd=R)
assert sha(wrapper)=='d69c42b3aee3a60775646711f220e8c558fb447af741616d88bdb8df82d18f91'
receiptpath=R/'.astis/huanjian-resume-20261103/20261108T032045273009Z-fixed-spectrum-determinant-canonical-exactHEAD-Lean.receipt.json'
receiptraw=receiptpath.read_bytes();receipt=json.loads(receiptraw);logpath=Path(receipt['log']);log=logpath.read_bytes()
gatepath=R/'.astis/site-lean-gate.json';gateraw=gatepath.read_bytes();gate=json.loads(gateraw)
assert receipt['command']==['/opt/anaconda3/bin/python','website/scripts/lean_gate.py']
assert receipt['exit_code']==0 and receipt['head_before']==receipt['head_after']==CORE
assert sha(log)==receipt['log_sha256']=='30d5a5c6b2512e39af16f0e0ca0d1b5c19c39e00c55abb0e4eae042cee308f6c'
assert gate['commands']==['python3 tools/astis.py check'] and gate['commit']==CORE
assert log.decode().splitlines()[-2:]==['ASTIS check passed','Recorded current Lean gate evidence at .astis/site-lean-gate.json']
O.mkdir(exist_ok=False)
def archive(name,raw):
 path=O/name;assert not path.exists();data=gzip.compress(raw,mtime=0);path.write_bytes(data)
 assert gzip.decompress(data)==raw
 return {'path':str(path.relative_to(R)),'raw_sha256':sha(raw),'gzip_sha256':sha(data),'raw_bytes':len(raw)}
rows=[];diff=b''
for i,(path,raw) in enumerate(after.items(),1):
 rows.append({'path':path,'before_sha256':sha(before[path]),'proposed_after_sha256':sha(raw),'before_archive':archive(f'path-{i}.before.raw.gz',before[path]),'proposed_after_archive':archive(f'path-{i}.proposed-after.raw.gz',raw)})
 diff+=b''.join(difflib.diff_bytes(difflib.unified_diff,before[path].splitlines(keepends=True),raw.splitlines(keepends=True),fromfile=('a/'+path).encode(),tofile=('b/'+path).encode()))
diffrow=archive('exact-proposed-guard-repair.diff.raw.gz',diff)
evidence={'immutable_wrapper':archive('immutable-official-wrapper.py.raw.gz',wrapper),'actual_receipt':archive('actual-official-wrapper.receipt.json.raw.gz',receiptraw),'actual_stdout':archive('actual-official-wrapper.stdout.raw.gz',log),'actual_gate_shape':archive('actual-official-gate-shape.json.raw.gz',gateraw),'repair_preparation_driver':archive('prepare-guard-repair.py.raw.gz',Path(__file__).read_bytes())}
current={path:after.get(path,raw) for path,raw in before.items()}
helperrows=[];buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w') as tar:
 for row in old['helpers']:
  path=row['path'];raw=current[path];name=Path(path).name
  if path.endswith('.py'):ast.parse(raw,filename=path)
  if path.endswith('.json'):json.loads(raw)
  info=tarfile.TarInfo(name);info.size=len(raw);info.mode=0o644;info.mtime=0;info.uid=info.gid=0;info.uname=info.gname=''
  tar.addfile(info,io.BytesIO(raw))
  helperrows.append({'path':path,'raw_sha256':sha(raw),'raw_bytes':len(raw),'origin':'Exact proposed after payload' if path in after else 'Unchanged original frozen helper bytes','syntax_check':'ast.parse only' if path.endswith('.py') else 'JSON syntax only' if path.endswith('.json') else 'Preparation documentation only'})
currentarchive=gzip.compress(buf.getvalue(),mtime=0);tarpath=O/'updated-conditional-helpers.tar.gz';tarpath.write_bytes(currentarchive)
with tarfile.open(fileobj=io.BytesIO(currentarchive),mode='r:gz') as tar:
 for path,raw in current.items():assert tar.extractfile(Path(path).name).read()==raw
updated={'state':'PREPARATION_ONLY_AST_PARSED_NOT_EXECUTED','role':'/root/det_integration_reader','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_verifier_to_preserve':'/root/reader_835194','proof_owner_to_preserve':'huanjian_gc_20261108_fixed_spectrum_determinant','helpers':helperrows,'conditional_application_only':True,'live_original_helpers_unchanged':True,'original_preparation_manifest_sha256':sha(oldmanifest.read_bytes()),'lossless_preparation_archive':{'path':str(tarpath.relative_to(R)),'sha256':sha(currentarchive),'members':len(current)},'actual_updated_helper_executions':0,'new_source_verdict_or_gate_acceptance_or_parking_authorization':False}
updatedpath=O/'updated-preparation-manifest.json';updatedpath.write_text(json.dumps(updated,ensure_ascii=False,indent=2)+'\n')
review={'reviewer':'/root/det_integration_reader','recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'phase':'Bounded official-wrapper receipt-shape compatibility review and exact conditional guard repair only','verdict':'NO_BLOCKING_OBJECTION_TO_EXACT_CONDITIONAL_GUARD_REPAIR','genuine_mismatch':'The actual canonical receipt command is Python website/scripts/lean_gate.py; the original guard searches its direct command list for tools/astis.py and check. The immutable wrapper itself executes exactly that canonical child, fails without writing evidence on nonzero, then writes current commit/sourceDigest/commands and the final success marker. This is an implementation-shape mismatch, not a mathematical or source counterexample.','actual_evidence':evidence,'immutable_wrapper_sha256':sha(wrapper),'actual_receipt_sha256':sha(receiptraw),'actual_raw_log_sha256':sha(log),'actual_gate_shape_sha256':sha(gateraw),'actual_original_official_elapsed_seconds':receipt['elapsed_seconds'],'proposed_changes':rows,'exact_diff':diffrow,'unchanged_guards':['Exact passing receipt0/head_before/head_after/core','Actual gate passed/site current and identical core/sourceDigest/currentcomputedDigest','Raw log hash and actual command retained unchanged','All protected bytes/foreign states/sourceV/README/models and actual38original/39archive/acceptance requirements','Root explicit later parking authorization, exact prepared hashes and persisted exactlyone normalAPI guard'],'wrapper_specific_new_guards':['Exact Python wrapper argv, immutable Git wrapper bytes and independently reviewed rawSHA','Actual gate.commands canonical-child certificate','Exactly one actual ASTIS success line and one final recordedgate marker, no wrapper-failure marker','Generated gate timestamp lies within the actual wrapper receipt interval plus2seconds rounding margin'],'direct_case':'Exact Python tools/astis.py check remains accepted with its hash-checked actual ASTIS success log. No arbitrary command containing check is accepted.','parking_pointer_change':'Only the exact prepared-helper manifest path is updated to this separately frozen current manifest; all parking authorization and transition guards remain unchanged. Root must explicitly authorize the new proposed common/park hashes before any use.','updated_conditional_preparation_manifest':str(updatedpath.relative_to(R)),'updated_conditional_preparation_manifest_sha256':sha(updatedpath.read_bytes()),'updated_archive_sha256':sha(currentarchive),'all_live_original_helpers_and_original_archive_preserved':True,'actual_repaired_helper_import_or_execution':False,'new_build_or_site_or_browser_or_API_or_ledger_or_shared_mutation':False,'gate_or_sourceV_or_acceptance_or_parking_verdict_issued':False,'next_owner_action':'Review exact two-file after payloads and new preparation manifest. Only root may explicitly apply them and later authorize actual final checks/parking with the new hashes. Do not rerun the full build merely to fit a checker.'}
for path,raw in before.items():assert (R/path).read_bytes()==raw
reviewpath=O/'conditional-repair-review.json';reviewpath.write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'review_sha256':sha(reviewpath.read_bytes()),'updated_manifest_sha256':sha(updatedpath.read_bytes()),'diff_raw_sha256':sha(diff),'proposed_common_sha256':sha(aftercommon),'proposed_park_sha256':sha(afterpark),'updated_archive_sha256':sha(currentarchive),'live_original_helpers_unchanged':True,'actual_repaired_helper_executions':0},indent=2))
