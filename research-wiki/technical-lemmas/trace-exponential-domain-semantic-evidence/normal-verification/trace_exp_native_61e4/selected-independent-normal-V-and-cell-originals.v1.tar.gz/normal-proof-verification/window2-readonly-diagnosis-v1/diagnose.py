"""Only reconstruct the failed pure object and call the canonical validator; never runs a driver/action/API."""
import sys
from pathlib import Path
NORMAL=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(NORMAL))
from verification_common import *
import difflib,traceback
OUT=Path(__file__).resolve().parent

def main():
    source=NORMAL/'verification_driver.py';assert file_sha(source)=='e380649911243cf8df3c8258fc459889c2f595bdb811a8a939df21cc4a4a4b12'
    a=read(NORMAL/'window2.ROOT-authorization.v1.json');assert file_sha(NORMAL/'window2.ROOT-authorization.v1.json')=='2cf6b47e9f7261783ea0bd2ef8560db79f53fe8a5d16d4f12c041564c234c102'
    oldraw=(PRIVATE/'window2-target-cell.before.exact.json').read_bytes();assert sha(oldraw)==a['expected_target_cell_sha256']=='8f6a5225aefe5679c0606991c89c595c7c6aec67a66a70c07b847bf09e30bcd2'
    old=json.loads(oldraw);assert (REPO/CELL).read_bytes()==oldraw
    pl=json.loads(pin_bytes(a['evidence_pins']['PL']));assert len(pl)==24 and sha(pin_bytes(a['evidence_pins']['PL']))==PLSHA
    tree=ast.parse(source.read_text());fun=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='cell_window');diff=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='differences')
    begin=next(i for i,n in enumerate(fun.body) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='new' for t in n.targets))
    end=next(i for i,n in enumerate(fun.body) if i>begin and isinstance(n,ast.Expr) and isinstance(n.value,ast.Call) and ast.unparse(n.value.func)=='sys.path.insert')
    pure=fun.body[begin:end]
    forbidden={'snapshot','write','exact','cell_window','normal_window','transition_advance','open','Popen','run'}
    for n in ast.walk(ast.Module(body=pure,type_ignores=[])):
        if isinstance(n,ast.Call):assert (n.func.id if isinstance(n.func,ast.Name) else n.func.attr if isinstance(n.func,ast.Attribute) else '') not in forbidden
    ns={'copy':copy,'old':old,'a':a,'x':{'pl':pl,'pins':a['evidence_pins']},'ident':ident,'OWN':NORMAL,'REPO':REPO,'ADV':ADV,'VERIFIER':VERIFIER,'MATH':MATH,'BINDING':BINDING}
    exec(compile(ast.Module(body=[diff,*pure],type_ignores=[]),'<frozen-driver-pure-projection-only>','exec'),ns)
    failed=ns['new'];raw=(json.dumps(failed,ensure_ascii=False,indent=2)+'\n').encode()
    exact(OUT/'failed-proposed.RECONSTRUCTED_NOT_APPLIED.json',raw)
    exact(OUT/'failed-driver.exact.py',source.read_bytes())
    exact(OUT/'pure-projection.selected-AST.py',(ast.unparse(ast.Module(body=pure,type_ignores=[]))+'\n').encode())
    sys.path.insert(0,str(REPO));from tools import astis_frontier_cells as cells
    def errors(obj):
        probe=copy.deepcopy(obj);probe['__path__']=CELL;return cells.validate_cells([probe])
    old_errors=errors(old);failed_errors=errors(failed)
    repaired=copy.deepcopy(failed);repaired['evidence']['independent_verification']=str((NORMAL/'normal-V-outcome.public.json').relative_to(REPO))
    repaired_errors=errors(repaired);assert ns['differences'](failed,repaired)==['/evidence/independent_verification']
    exact(OUT/'minimal-fieldtype-fix.PROPOSED_NOT_APPLIED.json',(json.dumps(repaired,ensure_ascii=False,indent=2)+'\n').encode())
    write(OUT/'canonical-validator.actual-errors.json',{'canonical_validator_file':ident(REPO/'tools/astis_frontier_cells.py'),'actual_old_cell_errors':old_errors,'actual_failed_proposal_errors':failed_errors,'actual_minimal_repair_errors':repaired_errors,'all_three_calls_used_the_same_isolated_single_probe_context':True,'full_global_frontier_context_not_loaded':True})
    exact(OUT/'minimal-fieldtype-proposal.exact.diff',''.join(difflib.unified_diff(raw.decode().splitlines(True),(json.dumps(repaired,ensure_ascii=False,indent=2)+'\n').splitlines(True),fromfile='failed-proposed.RECONSTRUCTED_NOT_APPLIED.json',tofile='minimal-fieldtype-fix.PROPOSED_NOT_APPLIED.json')).encode())
    assert not (PRIVATE/'target-cell-attempted.once.json').exists() and (REPO/CELL).read_bytes()==oldraw
    write(OUT/'diagnosis-and-minimal-repair.proposal.json',{'status':'READONLY_DIAGNOSIS_AND_EXACT_PROPOSAL_ONLY_NOT_APPLIED','classification':'IMPLEMENTATION_FAILED_TARGET_CELL_FIELD_TYPE','actual_original_window2_exit_code':1,'failed_driver_original_sha256':file_sha(source),'actual_failure_OS_receipt':ident(NORMAL/'window2-OS-receipt.public.json'),'failed_window_no_write_preservation':ident(NORMAL/'window2-failure-preservation.public.json'),'old_cell_sha256':sha(oldraw),'actual_failed_validator_errors':failed_errors,'actual_old_cell_validator_errors':old_errors,'actual_minimal_repaired_validator_errors':repaired_errors,'cause':'The failed projection assigns an object to evidence.independent_verification. Canonical schema requires a nonempty string for independently_verified status.','global_context_conclusion':'Both the exact old cell and the one-field-repaired projection validate in the same isolated single-probe call, while the reconstructed failed object yields the recorded field-type error. This bounded failure is not caused by missing global context; no global schema change or validator bypass is proposed.','exact_repair':{'JSON_pointer':'/evidence/independent_verification','failed_type':'object','proposed_type':'string','proposed_value':repaired['evidence']['independent_verification'],'true_outcome_referenced':ident(NORMAL/'normal-V-outcome.public.json'),'only_difference_from_original_failed_proposal':True,'detailed_metadata_already_remains_in':['/evidence/normal_V','/evidence/current_normal_stage','/evidence/reader_review']},'reconstructed_failed_object_qualification':'Actual failed driver stopped before saving projected bytes. This is a deterministic reconstruction from its frozen AST pure construction only, same exact saved oldcell/auth/PL and unchanged normal-V outcome/append; not falsely labeled as a preexisting raw saved proposal.','future_flow_proposal':['Do not modify/re-execute the old failed driver, process directory or old marker paths.','Prepare a new projection-only successor directory/version, with private0700/0600 and umask077 and explicit references to the already completed original window1 outcome/append.','Apply only this field-type construction change in the new proposed action; preserve all sealed mathematics/source/audit/purification fields and the whole original V.','Use a distinct fresh ROOT action authorization and fresh guard window only if ROOT approves; one target cell write, normalAPI/V calls0.','Run canonical validator on the proposed object before creating the new once marker/write; log actual errors; after any failure preserve streams/guard/suffix data and stop, never rollback/replay.'],'unchanged':{'old_failed_driver':file_sha(source)=='e380649911243cf8df3c8258fc459889c2f595bdb811a8a939df21cc4a4a4b12','actual_cell_still_original':(REPO/CELL).read_bytes()==oldraw,'window2_marker_absent':not (PRIVATE/'target-cell-attempted.once.json').exists(),'normal_V_exact_append_sha256':file_sha(NORMAL/'normal-V-exact-append.jsonl'),'new_API_V_projection_schema_Git_source_mutations':0}})
    print(json.dumps({'status':'READONLY_DIAGNOSIS_PROPOSAL_ONLY','actual_failed_validator_errors':failed_errors,'actual_old_cell_errors':old_errors,'actual_minimal_repair_errors':repaired_errors,'proposal_sha256':file_sha(OUT/'diagnosis-and-minimal-repair.proposal.json'),'normal_API_V_cell_actions':0},ensure_ascii=False))

if __name__=='__main__':
    os.umask(0o077);directory=PRIVATE/'window2-readonly-diagnosis-v1-OS';assert not directory.exists();private_dir(directory);out=directory/'stdout.raw';err=directory/'stderr.raw';start=time.monotonic();started=dt.datetime.now(dt.timezone.utc).isoformat();code=0
    for fd,p in [(1,out),(2,err)]:
        f=p.open('xb',buffering=0);os.fchmod(f.fileno(),0o600);os.dup2(f.fileno(),fd);f.close()
    try:main()
    except BaseException:traceback.print_exc();code=1
    sys.stdout.flush();sys.stderr.flush();receipt={'schema':'r16-readonly-canonical-validator-diagnosis-actual-OS-receipt-v1','argv':[sys.executable,*sys.argv],'cwd':str(REPO),'pid':os.getpid(),'started_utc':started,'ended_utc':dt.datetime.now(dt.timezone.utc).isoformat(),'elapsed_seconds':time.monotonic()-start,'actual_exit_code':code,'stdout_sha256':file_sha(out),'stderr_sha256':file_sha(err),'raw_streams_private':True,'script_sha256':file_sha(__file__),'normal_API_V_or_cell_actions':0}
    write(directory/'receipt.private.json',receipt);exact(OUT/'diagnosis-OS.public.json',(directory/'receipt.private.json').read_bytes());sys.exit(code)
