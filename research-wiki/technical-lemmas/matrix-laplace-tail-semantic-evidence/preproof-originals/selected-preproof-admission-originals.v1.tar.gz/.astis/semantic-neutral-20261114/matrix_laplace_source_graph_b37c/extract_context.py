import json, runpy, pathlib
BASE=pathlib.Path(__file__).resolve().parent
d=runpy.run_path(str(BASE/'extract_source_stdlib.py'))
p=d['p']; record=d['record']
chosen=['A3.SS2.p1','A3.SS2.p12']
ids=[]
for ident,n in p.ids.items():
    if n.tag not in ['p','div'] or len(n.text())>10000: continue
    if n.attrs.get('class') and 'ltx_para' not in n.attrs['class']: continue
    txt=n.text()
    if ('g_{q+1}' in txt or 'g_{1},' in txt or 'g_{1},\\ldots' in txt or
        ('\\theta_{i}' in txt and any(w in txt for w in ['eigenangle','eigen-angle','angles','uniform','Haar']))):
        ids.append(ident)
chosen+=list(dict.fromkeys(ids))
rows=[record(p.ids[i]) for i in chosen]
(BASE/'gaussian-context.raw.json').write_text(json.dumps(rows,indent=2,ensure_ascii=False)+'\n')
print('CHOSEN CONTEXTS')
for r in rows: print(r['id']+'\n'+r['text']+'\n')
