"""Seal the exact source statements and reserve only their new Frontier Cell."""
from pathlib import Path
import hashlib
import json
import re
import stat
import subprocess
import sys

sys.dont_write_bytecode = True
sys.path.insert(0, 'tools')
import astis_advance as advance

workspace = Path(__file__).resolve().parent.relative_to(Path.cwd())
paper = Path('research-wiki/paper-contributions/GaussianComplexity')
evidence = paper / 'truncated-radial-moment-semantic-evidence'
previous = paper / 'radial-exponential-semantic-evidence'
seal_path = paper / 'truncated-radial-moment-statement-seal.json'
cell_path = Path('research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-truncated-radial-moment.json')
runner = Path('.astis/huanjian-resume-20261103')
advance_id = 'ASTIS-SA-20261110-GaussianComplexityTruncatedRadialMoment'
owner = 'huanjian_gc_20261110_truncated_radial_moment'
producer_path = 'AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumTruncatedRadialMoment.lean'
consumer_path = 'Tests/GaussianComplexityFixedSpectrumTruncatedRadialMoment.lean'
producer_name = ('AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumTruncatedRadialMoment.'
                 'actual_standard_row_tail_first_moment')
consumer_name = ('AutoSamplingTheory.Tests.GaussianComplexityFixedSpectrumTruncatedRadialMoment.'
                 'actual_truncated_radial_bias')


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def dump(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode()


def put(path, raw):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as output:
        output.write(raw)


def ref(path):
    return {'path': str(path), 'sha256': sha(path.read_bytes())}


def receipt(stem):
    path = runner / (stem + '.receipt.json')
    value = json.loads(path.read_bytes())
    log_path = Path(value['log'])
    assert value['head_before'] == value['head_after'] == head and value['exit_code'] == 0
    assert sha(log_path.read_bytes()) == value['log_sha256']
    return {'receipt': ref(path), 'log': ref(log_path)}, log_path.read_bytes()


head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
environment = json.loads((workspace / 'actual-environment-and-literals.json').read_bytes())
assert head == environment['head'] == 'cf12d3752b264ecd922c12851df9af7ee9ed73b7'
assert all(not Path(path).exists() for path in [producer_path, consumer_path, seal_path, cell_path, evidence])
producer = (workspace / 'producer-signature.explicit-volume.txt').read_bytes()
consumer = (workspace / 'consumer-signature.draft.txt').read_bytes()
assert sha(producer) == 'f4a31dd5801f83ccc2f6c88a4cd38a5392ed2d2f0c03b00afbf47c35029da6d7'
assert sha(consumer) == 'bdee81d17f529d8d510b0cd0a95e531889fa33d63f7d75ba3a29c1464834e87c'
formation, formation_log = receipt('20261110T233058303365Z-truncated-radial-moment-explicit-volume-Prop-formation-only')
assert b'PlannedFirstMoment : Prop' in formation_log and b'PlannedBiasConsumer : Prop' in formation_log
definition_receipt, definition_log = receipt('20261110T232916903630Z-truncated-radial-moment-exact-definition-meaning-only')
source_path = Path('.astis/huanjian-resume-20261103/2610.20492v1.html')
source = source_path.read_bytes()
assert sha(source) == environment['raw_source_sha256']
source_graph = Path('.astis/semantic-neutral-20261110/re_sg_b71f20/phase1/source-graph.json')
graph = json.loads(source_graph.read_bytes())
anchors = {a['source_id']: a for node in graph['nodes'] for a in node['source_anchors']}
source_spans = []
for identifier in ['A3.SS2.p1', 'A3.SS2.p10.m1', 'A3.SS2.p10.m3', 'A3.Ex104.m1', 'A3.SS2.p11', 'A3.SS2.p12']:
    anchor = anchors[identifier]
    assert sha(source[anchor['raw_utf8_start']:anchor['raw_utf8_end']]) == anchor['span_sha256']
    source_spans.append(anchor)

old_context = json.loads((previous / 'minimal-definition-context.json').read_bytes())
old_names = {'ProbabilityTheory.stdGaussian', 'MeasureTheory.Integrable', 'MeasureTheory.HasFiniteIntegral',
             'MeasureTheory.integral', 'EuclideanSpace', 'PiLp', 'BorelSpace', 'FiniteDimensional'}
retained = [d for d in old_context['definitions'] if d['name'] in old_names]
assert {d['name'] for d in retained} == old_names
for definition in retained:
    raw = Path(definition['file']).read_bytes()
    first, last = definition['utf8_byte_span_0based_halfopen']
    assert sha(raw) == definition['wholefile_raw_sha256']
    assert raw[first:last] == definition['literalLF'].encode()

definition_text = definition_log.decode()
starts = list(re.finditer(r'^(?:protected )?def ([\w.]+?)(?:\.\{[^}]+\})?\s*:', definition_text, re.M))
compiled = []
for index, match in enumerate(starts):
    first = match.start()
    last = starts[index + 1].start() if index + 1 < len(starts) else len(definition_text)
    literal = definition_text[first:last]
    compiled.append({'name': match[1], 'literalLF': literal, 'literal_sha256': sha(literal.encode()),
                     'log_character_span': [first, last],
                     'log_UTF8_byte_span': [len(definition_text[:first].encode()), len(definition_text[:last].encode())]})
assert {row['name'] for row in compiled} == {'Set.indicator', 'Set.piecewise', 'Set.Ioi',
    'MeasureTheory.IntegrableOn', 'MeasureTheory.Measure.restrict', 'ENNReal.toReal', 'ENNReal.toNNReal', 'Real.log'}

haar_file = Path('.lake/packages/mathlib/Mathlib/MeasureTheory/Measure/Haar/OfBasis.lean')
haar_raw = haar_file.read_bytes()
haar_source = haar_raw.decode()
volume_defs = []
for opening in ['instance (priority := 100) measureSpaceOfInnerProductSpace', 'instance Real.measureSpace : MeasureSpace ℝ']:
    first = haar_source.index(opening)
    delimiter = '\n' if opening.startswith('instance Real.measureSpace') else '\n\n'
    end = haar_source.find(delimiter, first)
    last = end + 1 if end != -1 else len(haar_source)
    literal = haar_source[first:last]
    volume_defs.append({'file': str(haar_file), 'file_sha256': sha(haar_raw),
        'literalLF': literal, 'literal_sha256': sha(literal.encode()), 'character_span': [first, last],
        'UTF8_byte_span': [len(haar_source[:first].encode()), len(haar_source[:last].encode())]})

context = {'scope': 'Exact canonical definitions for the literal propositions',
           'previous_pinned_definition_literals': retained,
           'actual_compiled_definition_prints': compiled,
           'compiled_definition_receipt': definition_receipt,
           'canonical_real_volume_source_definitions': volume_defs}
context_bytes = dump(context)
exposure = {
    'statement_seal_before_operational_new_target_proof_search': True,
    'source_only': 'Read pinned C.2 p11 and p12, earlier exact source topology and completed radial exponential packet, source planning and canonical measure/indicator definitions.',
    'prior_knowledge': 'The worker proved the preceding quadratic exponential moment and its cutoff Markov consumer. Knows related compiled first squared-norm moment and abstract layer-cake and tail arguments. No pristine prior-knowledge claim.',
    'actual_def_audit_exposure': 'Printed eight literal canonical definitions and read the real volume instance and a short Measure.restrict/restrictₗ definition window with adjacent simp theorem header. These were meaning checks, not operational layer-cake/target proof-API retrieval.',
    'preseal_revision': 'First Prop draft used inferred volume. The final literal explicitly names real volume for IntegrableOn and the tail integral. Both actual successful Prop formation runs and the original draft are preserved.',
    'definition_locator_repair': 'The first seal script failed before writes at the final Real.measureSpace declaration because no following blank line exists. Actual receipt 20261110T233441717409Z, original script and failure retained. The corrected locator uses its exact terminating LF or EOF.',
    'target_Lean_proof_files_and_normal_API': 'Absent; zero.'
}
boundary = ('Exact finite one-row truncated radial first moment, its source tail-integral equality and bound, '
            'and actual scalar bias with the same literal standard Gaussian row, threshold and range. '
            'The source q=0 case is included. The shifted tail, positive denominators, finite measure casts, '
            'layer cake and exact norm mean are internal proof ingredients. Joint row law, covariance '
            'symmetry, matrix sums and concentration, full C.6 and Lemma 4.4, the main bounds and public '
            'delivery remain separate. The original global owner retains its stabilization lane.')
seal = {
    'schema': 1, 'seal_id': 'GC-C2-TRUNCATED-RADIAL-FIRST-MOMENT-EXACT-20261110-v1',
    'state': 'EXACT_LITERAL_PROP_FORMED_UNPROVED',
    'source': {'version': 'arXiv2610.20492v1', 'raw': str(source_path), 'raw_sha256': sha(source),
               'anchors': source_spans, 'scope': boundary},
    'producer': {'name': producer_name, 'planned_file': producer_path, 'signature': producer.decode(),
                 'signature_sha256': sha(producer), 'declaration_level': 'Source Anchor'},
    'actual_private_consumer': {'name': consumer_name, 'planned_file': consumer_path,
        'signature': consumer.decode(), 'signature_sha256': sha(consumer),
        'consumer_obligation': 'Consume the proved first moment bound and split the actual norm-square expectation to obtain the scalar bias identity and bound.'},
    'binder_audit': [
        {'binder': 'd q : ℕ', 'class': 'TYPING', 'meaning': 'The natural dimension and query count of the source row family, including q=0.'},
        {'binder': 'hq : 2*q+1<d', 'class': 'STANDING', 'meaning': 'Inherited from the source setup. Positivity of d and r and of the threshold are derived.'},
    ],
    'EXCESS_public_binders': [], 'project_owned_Prop_aliases_or_hidden_bundles': [],
    'definition_semantics_audit': [
        'The row law is the canonical standard Gaussian on the actual Euclidean L2 space of dimension q+1. R is its unscaled squared norm and L is the literal source threshold.',
        'Set.indicator returns the squared norm on the strict bad event or weak good event, and zero elsewhere. These events are complements, including the threshold endpoint in the good event.',
        'The tail function takes the real value of the actual Gaussian probability of L+s<R. Probability masses are finite, so the ENNReal top branch does not enter the real conversion.',
        'The tail integral is with respect to explicit canonical real volume restricted to the open positive ray. The endpoint has zero Lebesgue mass, matching the source integral from zero to infinity.',
        'Integrable and IntegrableOn are conclusions. Finite Bochner integrals are established internally. The scalar a divides the actual truncated norm-square expectation by real r.'
    ],
    'minimal_definition_context_sha256': sha(context_bytes),
    'actual_literal_formation': formation,
    'actual_environment': environment,
    'preseal_exposure': exposure,
    'boundary': boundary,
}
seal_bytes = dump(seal)
put(workspace / 'statement-seal-v1.json', seal_bytes)
put(seal_path, seal_bytes)
(workspace / 'statement-seal-v1.json').chmod(0o444)
seal_path.chmod(0o444)
put(evidence / 'minimal-definition-context.json', context_bytes)
put(evidence / 'actual-definition-meaning.log', definition_log)
put(evidence / 'preseal-exposure.json', dump(exposure))
for name in ['StatementFormation.lean', 'StatementFormationExplicitVolume.lean', 'DefinitionMeaning.lean']:
    path = workspace / name
    put(evidence / (name + '.raw.txt'), path.read_bytes())
    path.unlink()
for name in ['producer-signature.draft.txt', 'producer-signature.explicit-volume.txt', 'consumer-signature.draft.txt',
             'preseal-explicit-volume-revision.json', 'actual-environment-and-literals.json']:
    put(evidence / name, (workspace / name).read_bytes())

selective = {'kind': 'Exact literal types and necessary canonical definitions only',
    'statement_seal_sha256': sha(seal_bytes),
    'producer': {'signature': producer.decode(), 'signature_sha256': sha(producer)},
    'private_consumer': {'signature': consumer.decode(), 'signature_sha256': sha(consumer)},
    'definition_context': context,
    'review_order': 'Read after independent raw-source reconstruction. Freeze typed judgments before graph challenge.'}
selective_bytes = dump(selective)
put(workspace / 'selective-type-definition-packet.json', selective_bytes)
put(evidence / 'selective-type-definition-packet.json', selective_bytes)

ledger = Path('runs/substantive_advances.jsonl').read_bytes()
assert sha(ledger) == environment['ledger_sha256']
states = advance._replay_advances([json.loads(line) for line in ledger.splitlines()])
assert advance_id not in states and states['ASTIS-SA-20261110-StdGaussianRadialExponential']['state'] == 'VERIFIED'
tracked = [item.decode() for item in subprocess.check_output(['git', 'ls-files', '-z']).split(b'\0') if item]
tracked_hashes = {}
for name in tracked:
    path = Path(name)
    info = path.lstat()
    assert stat.S_ISREG(info.st_mode) and not name.startswith('.atlas-upstream/') and info.st_size < 100_000_000
    tracked_hashes[name] = sha(path.read_bytes())
old_frontiers = {str(p): sha(p.read_bytes()) for p in Path('research-wiki/frontier-cells').rglob('*')
                 if p.is_file() and not p.is_symlink()}
private_baseline = {'head': head, 'ledger_bytes': len(ledger), 'ledger_sha256': sha(ledger),
    'all_foreign_states': states, 'all_tracked_regular_file_hashes': tracked_hashes,
    'all_existing_frontier_hashes': old_frontiers, 'scope': 'PRIVATE preservation only; never export.'}
put(workspace / 'preproof-baseline.private.json', dump(private_baseline))

searches = [
    'Samplinglib known local proof inventory and prior packet: actual quadratic exponential moment and exact Gaussian norm-square mean are separate existing ingredients. The new target is the literal source tail first moment plus its scalar-bias consumer.',
    'Mathlib exact definition audit of the standard Gaussian, Euclidean norm, indicators, integrability, measure restriction, real volume and ENNReal conversion. Layer-cake and other target proof APIs are reserved for after the independent topology review.'
]
slug = 'huanjian-gaussian-truncated-radial-moment.json'
cell = {
    'schema_version': 3, 'cell_id': cell_path.stem, 'route': 'samplewiki-route', 'mode': 'faithfulPaper',
    'title': 'Actual Gaussian row truncated first moment and scalar bias',
    'source_anchor': 'arXiv2610.20492v1 Appendix C.2 A3.SS2.p11 and p12 scalar component; p1 and p10 actual row law and threshold',
    'target_statement': producer.decode() + '\nPrivate actual consumer:\n' + consumer.decode(),
    'status': 'claimed', 'owner_id': owner, 'advance_id': advance_id,
    'reservation_only': 'Frontier reservation. Normal ledger intake has not occurred.',
    'parents': [], 'consumers': ['Actual scalar a and bias 1−a in Appendix C.2 p12, in the private consumer.'],
    'shared_floor_audit': {'searched': searches, 'classification': 'missing', 'decision': 'new_route_local',
        'canonical_declaration': producer_name, 'canonical_shared_cell': ''},
    'reuse_plan': {'searched_existing': searches, 'reused_declarations': [], 'new_shared_declarations': [],
        'known_consumers': [], 'planned_consumers': [consumer_name], 'no_duplicate_wrapper': True,
        'decision_reason': 'Prove the exact source tail integral and bound, then derive the bias for the actual truncated expectation.'},
    'reader_contract': {'reference_standard': 'textbook/chapter-01/section-1-3.html',
        **{key: False for key in ['source_ordered', 'source_statement_adjacent', 'natural_language_formula_proof',
                                 'hidden_assumptions_visible', 'lean_collapsed', 'external_dependencies_visible']},
        'status': 'Prospective; reader lesson not authored.'},
    'graph_contribution': {'lean_view': 'new-node', 'overview_view': 'no-change-with-reason',
        'functor_view': 'pending-audit', 'edge_semantics': 'formal-solid; overlays-dashed',
        'color_semantics': 'evidence-status; library-scope', 'focus_targets': [producer_name],
        'visual_review': 'Planned statement; actual proof parents require compiler evidence.'},
    'learning_contract': {'control_plane_math_authority': False, 'process_memory_checked': True,
        'process_memory_ids': [], 'failure_class': 'NONE',
        'salvage': {'required': False, 'status': 'not-applicable', 'reason': 'No target proof attempt.',
                    'promoted_fragments': [], 'discarded_fragments': []},
        'parallelism': {'decision': 'serial', 'direction_fingerprints': [],
                        'expected_information_gain': 'One Lean proof worker; independent source and topology judgments.',
                        'shared_verified_context_digest': ''},
        'cross_route_blind_spot_audit': {'required': False, 'status': 'not-applicable', 'evidence': '',
                                       'canonical_route': '', 'selection_reason': 'One implementation route.'},
        'reader_backpressure': {'purification_status': 'pending', 'exposition_seal_status': 'pending',
            'exposition_evidence': '', 'source_expansion_nodes': [], 'lean_expansion_nodes': [],
            'assumptions_preserved': False, 'boundary_preserved': True}},
    'source_detail_audit': {'primary_edition': 'arXiv2610.20492v1 raw SHA ' + sha(source),
        'primary_anchor': 'A3.SS2.p11 exact tail identity and bound; A3.SS2.p12 scalar bias',
        'detail_status': 'omitted', 'gap': 'The source states the tail integral identity without deriving the nonnegative layer-cake step. This finite-measure argument must be proved internally.',
        'consulted': [{'source': 'Pinned Mathlib actual MeasureTheory.IntegrableOn and real Bochner integral definitions',
            'anchor': 'Actual canonical definition context in the statement seal',
            'hypothesis_adapter': 'Separate the standard Gaussian probability expectation from canonical real volume on the positive ray.'}],
        'fidelity_boundary': boundary},
    'statement_seal': {'status': 'EXACT_LITERAL_PROP_FORMED_UNPROVED;INDEPENDENT_TOPOLOGY_PENDING',
        'file': str(seal_path), 'sha256': sha(seal_bytes), 'signature_sha256': sha(producer),
        'private_consumer_signature_sha256': sha(consumer)},
    'evidence': {'actual_literal_formation': formation, 'normal_API_and_target_proof_calls': 0},
    'blocked': {'reason': '', 'children': []},
    'owned_files': [producer_path, consumer_path, str(seal_path), str(cell_path), str(evidence) + '/',
        'website/content/declaration_lessons/' + slug, 'website/content/publications/' + slug,
        'research-wiki/semantic-roundtrip/audits/' + slug],
    'forbidden_shared_files': ['AutoSamplingTheory.lean', 'Tests.lean',
        'AutoSamplingTheory/TechnicalLemmas/Registry.lean', 'website/content/source_correspondence.json',
        'website/content/graph_memory_index.json', 'website/content/functor_hypergraph.json'],
    'truth_boundary': boundary, 'conceptual_mirror_audit': {'status': 'pending'},
}
put(cell_path, dump(cell))
summary = {'exact_seal_sha256': sha(seal_bytes), 'producer_signature_sha256': sha(producer),
    'private_consumer_signature_sha256': sha(consumer), 'selective_packet_sha256': sha(selective_bytes),
    'frontier_sha256': sha(cell_path.read_bytes()), 'foreign_states_guarded': len(states),
    'older_frontiers_guarded': len(old_frontiers), 'tracked_regular_files_guarded': len(tracked_hashes),
    'normal_API_and_proof_calls': 0, 'source_graph_review_pending': True}
put(workspace / 'actual-seal-and-reservation-summary.json', dump(summary))
print(json.dumps(summary))
