import Mathlib.MeasureTheory.Function.L2Space
import Mathlib.MeasureTheory.Integral.Prod
import Mathlib.Analysis.InnerProductSpace.Adjoint

open MeasureTheory
open scoped ENNReal InnerProductSpace
noncomputable section
set_option autoImplicit false
set_option maxHeartbeats 1200000

namespace PBPSActualL2Average107

theorem adjoint_contraction_pairing
    {α β : Type*} [MeasurableSpace α] [MeasurableSpace β]
    (μ : Measure α) (ν : Measure β) [IsProbabilityMeasure μ] [IsProbabilityMeasure ν]
    (Z : α × β → α) (hZ : MeasurePreserving Z (μ.prod ν) μ) :
    ∃ A : Lp ℝ 2 μ →L[ℝ] Lp ℝ 2 μ, ‖A‖ ≤ 1 ∧
      ∀ f g : Lp ℝ 2 μ,
        ⟪f, A g⟫_ℝ = ∫ p : α × β, f p.1 * g (Z p) ∂μ.prod ν := by
  have hfst : MeasurePreserving Prod.fst (μ.prod ν) μ := by
    refine ⟨measurable_fst, ?_⟩
    simp only [Measure.map_fst_prod, measure_univ, one_smul]
  let B : Lp ℝ 2 μ →L[ℝ] Lp ℝ 2 (μ.prod ν) :=
    (Lp.compMeasurePreservingₗᵢ ℝ Prod.fst hfst).toContinuousLinearMap
  let C : Lp ℝ 2 μ →L[ℝ] Lp ℝ 2 (μ.prod ν) :=
    (Lp.compMeasurePreservingₗᵢ ℝ Z hZ).toContinuousLinearMap
  let A : Lp ℝ 2 μ →L[ℝ] Lp ℝ 2 μ := B.adjoint.comp C
  have hB : ‖B‖ ≤ 1 := LinearIsometry.norm_toContinuousLinearMap_le _
  have hC : ‖C‖ ≤ 1 := LinearIsometry.norm_toContinuousLinearMap_le _
  refine ⟨A, ?_, ?_⟩
  · calc
      ‖A‖ ≤ ‖B.adjoint‖ * ‖C‖ := ContinuousLinearMap.opNorm_comp_le _ _
      _ = ‖B‖ * ‖C‖ := by rw [ContinuousLinearMap.adjoint.norm_map]
      _ ≤ 1 * 1 := mul_le_mul hB hC (norm_nonneg _) zero_le_one
      _ = 1 := one_mul 1
  · intro f g
    change ⟪f, B.adjoint (C g)⟫_ℝ = _
    rw [ContinuousLinearMap.adjoint_inner_right, L2.inner_def]
    have hb : (B f : α × β → ℝ) =ᵐ[μ.prod ν] (fun p => f p.1) :=
      Lp.coeFn_compMeasurePreserving f hfst
    have hc : (C g : α × β → ℝ) =ᵐ[μ.prod ν] (fun p => g (Z p)) :=
      Lp.coeFn_compMeasurePreserving g hZ
    apply integral_congr_ae
    filter_upwards [hb, hc] with p hp hq
    rw [hp, hq]
    simp [RCLike.inner_apply, mul_comm]

#print axioms adjoint_contraction_pairing

theorem expectation_identification
    {α β : Type*} [MeasurableSpace α] [MeasurableSpace β]
    (μ : Measure α) (ν : Measure β) [IsProbabilityMeasure μ] [IsProbabilityMeasure ν]
    (Z : α × β → α) (hZ : MeasurePreserving Z (μ.prod ν) μ) :
    ∃ A : Lp ℝ 2 μ →L[ℝ] Lp ℝ 2 μ, ‖A‖ ≤ 1 ∧
      ∀ G : α → ℝ, ∀ hG : MemLp G 2 μ,
        (∀ᵐ x ∂μ, Integrable (fun w => G (Z (x, w))) ν) ∧
        ∃ hOp : MemLp (fun x => ∫ w, G (Z (x, w)) ∂ν) 2 μ,
          A (hG.toLp G) = hOp.toLp (fun x => ∫ w, G (Z (x, w)) ∂ν) := by
  classical
  obtain ⟨A, hA, hpair⟩ := adjoint_contraction_pairing μ ν Z hZ
  refine ⟨A, hA, ?_⟩
  intro G hG
  have hfst : MeasurePreserving Prod.fst (μ.prod ν) μ := by
    refine ⟨measurable_fst, ?_⟩
    simp only [Measure.map_fst_prod, measure_univ, one_smul]
  have hprod : Integrable (fun p : α × β => G (Z p)) (μ.prod ν) :=
    (hG.comp_measurePreserving hZ).integrable (by norm_num)
  have hop : Integrable (fun x => ∫ w, G (Z (x, w)) ∂ν) μ := hprod.integral_prod_left
  have hAg : Integrable (A (hG.toLp G) : α → ℝ) μ :=
    (Lp.memLp (A (hG.toLp G))).integrable (by norm_num)
  have heq : (A (hG.toLp G) : α → ℝ) =ᵐ[μ] (fun x => ∫ w, G (Z (x, w)) ∂ν) := by
    apply Integrable.ae_eq_of_forall_setIntegral_eq _ _ hAg hop
    intro s hs hms
    let i : Lp ℝ 2 μ := indicatorConstLp 2 hs hms.ne (1 : ℝ)
    have hi : (i : α → ℝ) =ᵐ[μ] s.indicator (fun _ => (1 : ℝ)) := indicatorConstLp_coeFn
    have hi' := hfst.quasiMeasurePreserving.ae_eq hi
    have hg' := hZ.quasiMeasurePreserving.ae_eq hG.coeFn_toLp
    let H : α × β → ℝ := fun p => (s.indicator (fun _ => (1 : ℝ)) p.1) * G (Z p)
    have hH : Integrable H (μ.prod ν) := by
      convert hprod.indicator (hs.preimage measurable_fst) using 1
      funext p
      by_cases hp : p.1 ∈ s <;> simp [H, Set.indicator, hp]
    calc
      (∫ x in s, A (hG.toLp G) x ∂μ) = ⟪i, A (hG.toLp G)⟫_ℝ :=
        (L2.inner_indicatorConstLp_one hs hms.ne _).symm
      _ = ∫ p : α × β, i p.1 * (hG.toLp G) (Z p) ∂μ.prod ν := hpair i (hG.toLp G)
      _ = ∫ p : α × β, H p ∂μ.prod ν := by
        apply integral_congr_ae
        filter_upwards [hi', hg'] with p hp hq
        change i p.1 * (hG.toLp G) (Z p) = _
        rw [hp, hq]
      _ = ∫ x, ∫ w, H (x, w) ∂ν ∂μ := integral_prod H hH
      _ = ∫ x, s.indicator (fun _ => (1 : ℝ)) x * (∫ w, G (Z (x, w)) ∂ν) ∂μ := by
        simp only [H, integral_const_mul]
      _ = ∫ x in s, (∫ w, G (Z (x, w)) ∂ν) ∂μ := by
        rw [← integral_indicator hs]
        congr 1
        funext x
        by_cases hx : x ∈ s <;> simp [Set.indicator, hx]
  have hOp : MemLp (fun x => ∫ w, G (Z (x, w)) ∂ν) 2 μ := (Lp.memLp (A (hG.toLp G))).congr heq
  refine ⟨hprod.prod_right_ae, hOp, ?_⟩
  apply Lp.ext
  exact heq.trans hOp.coeFn_toLp.symm

#print axioms expectation_identification
end PBPSActualL2Average107
