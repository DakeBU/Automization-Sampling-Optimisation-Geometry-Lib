"""Freeze the authorized actual local acceptance; no normal release or source verdict."""
from pathlib import Path
import datetime, gzip, hashlib, json, subprocess
R=Path('/Users/zhouhuanjian/ASTIS-GC')
OWN=R/'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-determinant-integration-20261108/independent-integration-reader-review'
O=OWN/'local-acceptance-evidence';assert not O.exists()
accept=OWN/'actual-local-integration-acceptance.json'
context=OWN.parent/'local-acceptance-context.json'
receipt=R/'.astis/huanjian-resume-20261103/20261108T053030508268Z-fixed-spectrum-determinant-independent-local-acceptance.receipt.json'
S=R/'.astis/huanjian-gc-fixed-spectrum-determinant-integration-20261108/independent-reader'
CORE='55b7b53921b430056db42ef04186d92074f0c49b';sha=lambda b:hashlib.sha256(b).hexdigest()
assert sha(accept.read_bytes())=='247104a830259f98c7805443a75bd8d08bb906b9f9ecfe6e19564dd6579bb96a'
assert sha(context.read_bytes())=='a0911e8f7a00225227b3a22e08ebc04317307232f2319250c9ff71347b8e9ca9'
assert sha((S/'record_local_acceptance.py').read_bytes())=='0ba58f7598fd717721e31c52b6eb97f68fae4ffc9a47436722638eb2a0e03469'
assert sha((S/'det_acceptance_common.py').read_bytes())=='f3fefccfd197588845241075f8fb28c4fd599460e070c03dcdd01efa2bebedc3'
a=json.loads(accept.read_bytes());actual=json.loads(receipt.read_bytes());log=Path(actual['log'])
assert a['state']=='LOCAL_INTEGRATION_ACCEPTED' and a['reviewer']=='/root/det_integration_reader'
assert a['accepted_immutable_core']==CORE and a['publication_binding_sha256']=='c70bb9b23e335acf768bb889f8229fcdf2a7af160e10fa89779d00dcba58374b'
assert a['source_verifier_preserved']=='/root/reader_835194' and a['proof_owner_preserved']=='huanjian_gc_20261108_fixed_spectrum_determinant'
assert a['new_source_verdict'] is False and a['parking_authorized_or_executed'] is False
assert a['blocking_objections']==[] and a['actual_original_image_count']==38 and len(a['actual_original_images_viewed'])==38
assert a['fresh_protection']['canonical_Registry_count']==620 and a['fresh_protection']['foreign_advances']==282 and a['fresh_protection']['foreign_frontiers']==441
assert a['fresh_protection']['protected_foreign_content']==7432 and a['exact_graph_supplement']['all_older_foreign_nodes_and_edges_exactly_preserved'] is True
assert 'EXISTING compiled canonical Registry inventory node only' in a['parent_status_caveat']
assert 'legacy-source-audit-debt' in a['parent_status_caveat'] and 'PARTIAL' in a['parent_status_caveat']
assert 'no theorem, SAU, sourceV or fresh parent-module publication audit' in a['parent_status_caveat']
assert all(x['immutable_link_syntax_checked'] is None and x['external_GitHub_HTML_checked'] is False for x in a['source_link_scope'])
assert actual['exit_code']==0 and actual['head_before']==actual['head_after']==CORE
assert sha(log.read_bytes())==actual['log_sha256']=='a93456837a8bca21c46d8b8d577fd06dab836e8c22c98bb120752187af9293d2'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==CORE
O.mkdir(exist_ok=False)
rows=[]
for name,path in [('acceptance.json.raw.gz',accept),('actual-context.json.raw.gz',context),('actual-command.receipt.json.raw.gz',receipt),('actual-command.stdout.raw.gz',log),('executed-acceptance-recorder.py.raw.gz',S/'record_local_acceptance.py'),('executed-common-helper.py.raw.gz',S/'det_acceptance_common.py'),('freeze-driver.py.raw.gz',Path(__file__))]:
 raw=path.read_bytes();data=gzip.compress(raw,mtime=0);dest=O/name;assert not dest.exists();dest.write_bytes(data);assert gzip.decompress(data)==raw
 rows.append({'original':str(path.relative_to(R)),'raw_sha256':sha(raw),'raw_bytes':len(raw),'archive':str(dest.relative_to(R)),'archive_sha256':sha(data)})
freeze={'reviewer':'/root/det_integration_reader','recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'state':'LOCAL_INTEGRATION_ACCEPTED','accepted_immutable_core':CORE,'acceptance_sha256':sha(accept.read_bytes()),'actual_context_sha256':sha(context.read_bytes()),'actual_receipt_sha256':sha(receipt.read_bytes()),'actual_command':actual['command'],'actual_started_utc':actual['started_utc'],'actual_exit_code':actual['exit_code'],'actual_elapsed_seconds':actual['elapsed_seconds'],'raw_log_sha256':sha(log.read_bytes()),'actual_original_image_count':38,'completed_review':a['independent_original_image_review'],'fresh_final_readback':a['independent_postcore_readback'],'retention_verification':a['retained_archive_verification'],'archive_sha256':a['archive_sha256'],'lossless_archives':rows,'parent_status_boundary':a['parent_status_caveat'],'source_link_boundary':a['source_link_caveat'],'viewport_boundary':'All per-original notes and limits are retained. Some mobile exact-Lean code is below the captured viewport; actual DOM/source/download/localGit equality and code hscroll are independent real browser checks. Focused graphs are readable; no full-atlas/Fit/manual-touch claim.','new_source_verdicts':0,'normal_parking_API_calls':0,'shared_ledger_build_browser_or_remote_mutations':0,'scope':'Bounded determinant/product and genuine same-A Gaussian consumer local integration only. No full paper/main-bound/remote/publication/purification/ExpositionSeal/wholeGoal completion.','stopped_before_normal_release':True}
dest=OWN/'actual-local-integration-acceptance.freeze.json';assert not dest.exists();dest.write_text(json.dumps(freeze,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'state':a['state'],'acceptance_sha256':sha(accept.read_bytes()),'freeze_sha256':sha(dest.read_bytes()),'actual_receipt_sha256':sha(receipt.read_bytes()),'raw_log_sha256':sha(log.read_bytes()),'actual_exit_code':actual['exit_code'],'actual_elapsed_seconds':actual['elapsed_seconds'],'normal_parking_API_calls':0},indent=2))
