#!/usr/bin/env python3
"""Execute one frozen native command only after admitted immutable assignment."""
import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

OWN = Path(__file__).resolve().parent
REPO = OWN.parents[2]
ASSIGNMENT = OWN / 'native-command-assignment.json'
EXPECTATIONS = OWN / 'native-expectations.v1.md'
OUTPUT = OWN / 'native-output'
INITIALIZED = OWN / 'native-output-initialized.json'

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def owned(relative):
    path = (OWN / relative).resolve()
    if not path.is_relative_to(OWN):
        raise ValueError('Path escapes owned native root')
    return path

def read(path):
    return json.loads(Path(path).read_text())

def write_new(path, value):
    with Path(path).open('x') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')

def checked_input(item):
    path = owned(item['path'])
    if digest(path) != item['sha256']:
        raise ValueError('Pinned owned input changed: ' + str(path))
    return path

def observed_head():
    return subprocess.check_output(['git', '--no-optional-locks', '-C', str(REPO), 'rev-parse', 'HEAD']).decode().strip()

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command_id')
    args = parser.parse_args()
    if not ASSIGNMENT.is_file():
        raise ValueError('Preparation only: no admitted immutable complete P/T assignment')
    assignment = read(ASSIGNMENT)
    if assignment['schema'] != 'weighted-mgf-native-assignment-v1' or assignment['status'] != 'ROOT_ADMITTED_AND_ASSIGNED_IMMUTABLE_COMPLETE_P_AND_T':
        raise ValueError('ROOT source-topology admission plus complete immutable assignment required')
    if not re.fullmatch('[0-9a-f]{40}', assignment['candidate_commit']):
        raise ValueError('Explicit immutable candidate commit required; never inferred from live HEAD')
    if assignment['runner_sha256'] != digest(__file__) or assignment['expectations_sha256'] != digest(EXPECTATIONS):
        raise ValueError('Runner/expectation freeze changed')
    checked_input(assignment['admission_receipt'])
    for item in assignment['immutable_inputs']:
        checked_input(item)
    if set(assignment['candidate_sources']) != {'P', 'T'}:
        raise ValueError('Both complete immutable P/T sources required')
    for item in assignment['candidate_sources'].values():
        checked_input(item)
    packages_file = checked_input(assignment['verified_package_inputs'])
    packages = read(packages_file)
    if packages['status'] != 'READONLY_PACKAGE_BYTES_VERIFIED_FOR_THIS_ASSIGNMENT' or packages['candidate_commit'] != assignment['candidate_commit']:
        raise ValueError('Independent exact package-byte verification required before reuse')
    if len(packages['packages']) != 9 or not all(row['revision_and_source_artifact_bytes_verified'] for row in packages['packages']):
        raise ValueError('Exactly nine pinned clean packages must be byte verified')
    package_roots = {str(Path(row['effective_lean_path']).resolve()) for row in packages['packages']}
    commands_file = checked_input(assignment['commands'])
    command = read(commands_file)[args.command_id]
    if command['phase'] != 'native':
        raise ValueError('Metadata/browser/API commands require separate assignments')
    argv = command['argv']
    if not argv or not all(isinstance(value, str) for value in argv) or not Path(argv[0]).is_absolute():
        raise ValueError('Exact argv and absolute executable required')
    cwd = owned(command['cwd'])
    env = command['environment']
    if not all(isinstance(k, str) and isinstance(v, str) for k, v in env.items()):
        raise ValueError('Full explicit string environment required')
    components = env.get('LEAN_PATH', '').split(os.pathsep)
    if any(not component for component in components):
        raise ValueError('Ambient/empty LEAN_PATH components forbidden')
    resolved = [str(Path(component).resolve()) for component in components]
    if resolved[0] != str(OUTPUT.resolve()) or set(resolved[1:]) != package_roots:
        raise ValueError('LEAN_PATH must be fresh owned ASTIS output plus exactly frozen nine clean upstream roots')
    if not OUTPUT.is_dir():
        raise ValueError('Missing owned native output')
    assignment_sha = digest(ASSIGNMENT)
    if not INITIALIZED.exists():
        if any(OUTPUT.iterdir()):
            raise ValueError('First command requires initially empty fresh ASTIS output')
        write_new(INITIALIZED, {'assignment_sha256': assignment_sha, 'candidate_commit': assignment['candidate_commit'], 'output_initially_empty': True, 'utc': dt.datetime.now(dt.timezone.utc).isoformat()})
    elif read(INITIALIZED)['assignment_sha256'] != assignment_sha:
        raise ValueError('Output belongs to another immutable assignment')
    if not re.fullmatch('[a-z0-9_-]+', args.command_id):
        raise ValueError('Unsafe command ID')
    receipts = OWN / 'native-command-receipts'
    receipts.mkdir(exist_ok=True)
    stamp = dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    prefix = receipts / (stamp + '-' + args.command_id)
    stdout = prefix.with_suffix('.stdout.raw')
    stderr = prefix.with_suffix('.stderr.raw')
    head_before = observed_head()
    start_utc = dt.datetime.now(dt.timezone.utc).isoformat()
    start = time.monotonic()
    with stdout.open('xb') as out, stderr.open('xb') as err:
        completed = subprocess.run(argv, cwd=cwd, env=env, stdin=subprocess.DEVNULL, stdout=out, stderr=err, check=False)
    receipt = {
        'schema': 'weighted-mgf-native-command-receipt-v1', 'candidate_commit_compiled': assignment['candidate_commit'],
        'observed_repository_HEAD_before': head_before, 'observed_repository_HEAD_after': observed_head(),
        'observed_HEAD_is_not_asserted_as_build_HEAD': True,
        'assignment_sha256': assignment_sha, 'runner_sha256': digest(__file__), 'expectations_sha256': digest(EXPECTATIONS),
        'commands_sha256': digest(commands_file), 'command_id': args.command_id,
        'argv': argv, 'cwd': str(cwd), 'environment': env,
        'started_utc': start_utc, 'ended_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
        'elapsed_seconds': time.monotonic() - start, 'exit_code': completed.returncode,
        'stdout': {'path': str(stdout.relative_to(OWN)), 'bytes': stdout.stat().st_size, 'sha256': digest(stdout)},
        'stderr': {'path': str(stderr.relative_to(OWN)), 'bytes': stderr.stat().st_size, 'sha256': digest(stderr)},
    }
    target = prefix.with_suffix('.receipt.json')
    write_new(target, receipt)
    print(json.dumps({'command_id': args.command_id, 'exit_code': completed.returncode, 'receipt': str(target)}))
    return completed.returncode

if __name__ == '__main__':
    try:
        sys.exit(main())
    except (KeyError, OSError, ValueError) as error:
        print('Native runner refused: ' + str(error), file=sys.stderr)
        sys.exit(2)
