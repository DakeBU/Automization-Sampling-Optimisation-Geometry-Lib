# Phase 2 independent selective statement review

Reviewer: `/root/source_reader_d63b90`, distinct from decoder `/root/decoder_47c18e` and the proving root. This report follows the frozen source-only phase 1. It is confined to the two expressly authorized selective-input files, own phase-1 material, and the pinned raw source. It is not a whole-module, proof, compiler, dependency-use, publication, or source-V acceptance.

Independent statement-level fidelity verdict: **equivalent to the identified source subresult, with nonblocking representational and source-implicit conclusion differences**. No blocking semantic delta was found in the public anonymous proposition or its blind reconstruction. The source boundary is Appendix C.3 Ex140's two reciprocal-spectrum mean identities under the actual diagonal Gaussian. This is not acceptance of all Fact C.8, the variance/bias estimates, or complete Lemma 4.5.

The private anonymous series proposition is also a **genuine source-faithful downstream Gaussian consumer target at statement level**. It joins the actual Gaussian Q expectation to the Fourier/grid alias series, including convergence as an output. This finding gives no evidence yet that a proof compiles, uses the public result, reaches the private target, or is available to a public consumer.

## Bound inputs and independent sequence

The phase-1 freeze has SHA-256 `763446abce7e48ec32330ff4a7ee1538187a8fe9d9a80e6f29fa82b7276b054d`; its 37 entries were rechecked unchanged. The source HTML remains at `6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915`.

The only newly opened inputs were `phase2-inputs/selective-input.json` (raw SHA-256 `42970541548f93e09cb5f099017ef2015c75e3c7a80ce7aa9cedbdbc350b1ed6`) and `phase2-inputs/manifest.json` (`67444172f33625e9c495418a47a574e41c59907e8bb6bd73ccda7b7047200701`). The embedded source-restatement, public-statement and reconstruction string hashes all verified. The canonical full-packet hash `3e850055902cef5e2b0fd3864319ead356f648b0aed2c18595b5fb9e27f922a8` is a reference only: its file was not located or opened.

I first read and verified the selective proposition and reconstruction, then the expressly named manifest. I reread my frozen cognition and directly re-extracted raw source p4.1, p4.2, p6.1, Ex140 and Ex144. No candidate proof, lesson, publication context, prior semantic verdict, proposed repair, source graph, frontier, ledger/API state, production file, Tests, or other reader report was opened. Approved definition context and the blind reconstruction were visible only at this authorized phase. The reconstruction's own source-hidden claim is recorded as supplied evidence; I did not independently observe the decoder run.

## Seven semantic slots

1. **Objects.** The raw source defines Lambda as the fixed diagonal precision spectrum and U as N(0,Lambda inverse). The public proposition defines exactly that Gaussian measure on real Euclidean space, not an arbitrary law or a Gaussianity certificate. Its squared norm is the source's Euclidean squared norm. Its Q is the literal coordinate expansion of x^T D_n x. The reconstruction correctly identifies the covariance argument as Lambda inverse, retaining precision/covariance roles and mean zero. M and mu_n are actual expectations rather than inputs.
2. **Domains.** Source i=1,...,d becomes Fin d with values 0,...,d-1 and angle `(i+1/2) pi/d`. This is the exact index translation of `(i-1/2) pi/d` on the original index set. Dimension is a natural number with d>=2, kappa is real with kappa>=2, and n is natural with 1<=n<d. A positive integer mode is equivalently represented this way. The real Euclidean carrier, diagonal real matrix and finite sums are preserved.
3. **Quantifiers.** Every admissible d,kappa,n is quantified, in that order. The subsequent theta, spectrum, matrix, measure and Q are definitions. Fixing the canonical Gaussian law rather than universally quantifying a random variable of that law is equivalent for law-dependent moments. No extra premise selects a good covariance witness or moment value. The reconstruction records the quantifiers accurately.
4. **Assumptions.** Exactly d>=2,kappa>=2,1<=n<d are public numeric premises. Positivity/invertibility of Lambda, Gaussian second moments and integrability are not extra premises. There is no d-n>=sqrt(kappa), query/algorithm condition, asymptotic restriction, or supplied moment certificate. The source's Haar rotation belongs to the family context and is unnecessary for this diagonal Gaussian subresult. Under the displayed conditions, `1<=lambda_i` follows from cos>=-1; the grid in fact lies strictly between 0 and pi, so the decoder's supplementary `1<lambda_i<kappa` observation is mathematically correct.
5. **Conclusion.** The two real integrals equal the exact finite reciprocal-spectrum sums in Ex140. The public proposition additionally states integrability of both the squared norm and the signed Q. These are explicit analytic outputs of the same Gaussian calculation. They are implicit in the source's ordinary finite expectations and justified by finite Gaussian moments; they do not weaken the result or move a proof ingredient to a public binder. The blind reconstruction includes both integrability assertions and both equalities correctly. No closed-form rho evaluation, variance control or normalized-bias result is claimed here.
6. **Scopes and senses.** The measure is the actual multivariate Gaussian with covariance Lambda inverse under the supplied definition semantics. The approved totalized matrix inverse and Gaussian square-root definitions occur on a positive-definite nonsingular input, so their off-domain branches do not change the source object on this theorem's entire admissible domain. Integrable means actual Bochner integrability; for signed Q it entails absolute integrability, preventing totalized-integral fallback from providing the only meaning of an expectation. The norm is Euclidean; all sums cover all coordinates. The coordinate quadratic form has neither a missing dot-product factor nor a spurious factor of two.
7. **Constant dependencies.** The only numerical choices in the public proposition are the exact pi and half-grid factors. Dimension and kappa determine the measure; n additionally determines the cosine weights. No unmentioned constants, estimates, asymptotic limits, parameter-dependent exceptions or extra factor of two occur. The reconstruction preserves these dependencies.

## Literal definition audit

The eigenvalue formula is precisely `(kappa+1)/2 + ((kappa-1)/2) cos(theta_i)`. The Gaussian's second argument is covariance; using Lambda inverse is therefore essential and correct. The coordinate presentation `sum_i cos(n theta_i) x_i^2` equals `x^T diag(cos(n theta_i)) x` for real coordinates. `WithLp.ofLp` only exposes those coordinates in the Euclidean wrapper. On this admissible domain Lambda is positive definite, so ordinary matrix inverse equals the diagonal reciprocal spectrum. There is no source-facing characterized object chosen conditionally, arbitrary off-source substitute, or hidden free regularity premise in the displayed definitions.

This is a semantic audit of the exact visible definitions and approved context. Whether the production module has additional scoped variables, imports, aliases, instances, proof assumptions or fallback behavior remains a phase-3 question.

## Private actual-Gaussian series target

The private proposition retains the same d,kappa,n, grid, precision, literal Gaussian covariance and Q. It sets r to `(sqrt(kappa)-1)/(sqrt(kappa)+1)` and defines, for integer k,

    a(k) = (-1)^(k/(2d)) when 2d divides k, and 0 otherwise.

Here the power has an integer exponent and the quotient is exact in the divisibility branch. Since d>=2, the divisor is nonzero. This a is the normalized source grid sum:

    sum_i cos(k theta_i) = d a(k).

This is exactly the source Ex139 coefficient for every integer frequency, including negative k. Negative aliases have the correct sign because `(-1)^(-m)=(-1)^m`. The arguments `(j+1)-n` and `(j+1)+n` are formed in the integers, avoiding natural subtraction truncation at low frequencies.

Source Ex144 says

    mu_n = (1/sqrt(kappa)) sum_{ell>=1} (-r)^ell
              [sum_i cos((ell-n)theta_i) + sum_i cos((ell+n)theta_i)].

Replacing both inner sums by d a and writing ell=j+1 gives exactly the private proposition:

    integral Q dmu = (d/sqrt(kappa)) sum'_{j:N} (-r)^(j+1)
                         [a((j+1)-n)+a((j+1)+n)].

The factor two in the Fourier expansion cancels the half in product-to-sum, so the stated coefficient d/sqrt(kappa) is correct. The absent constant cosine mode is zero because 1<=n<d. Summability is a conclusion: with 0<r<1 and |a(k)|<=1, each term is bounded in absolute value by `2 r^(j+1)`, a summable geometric bound. This is also the source p4.2 absolute-convergence justification applied to the finite grid. Integrable Q is an output, rather than an assumption replacing the Gaussian mean edge.

The private target is substantive because its left-hand side remains the expectation under the literal source Gaussian while its right-hand side is the Fourier/grid alias series. It is not merely an implication taking either desired identity as a premise. It can consume the public mean calculation together with the separate inverse-spectrum expansion/grid argument as a downstream composition; the public proposition alone does not entail the series formula. It is not logically stronger than the entire public conjunction: its displayed conclusion omits the norm identity. “Stronger downstream consumer” here means the actual Gaussian Q-to-series composition, compared with a standalone deterministic alias identity. Actual proof calls, compilation, absence of hidden premises and downstream reachability are deliberately not inferred from the statement.

## Deltas, provenance and disposition

The nonblocking deltas are: source random-variable notation versus canonical-law integration; one-based versus zero-based coordinate indexing; positive integer mode versus bounded natural mode; matrix quadratic-form notation versus its coordinate sum; explicit integrability conclusions; and, for the private target, substitution of the normalized alias coefficient and positive-series reindexing. Each is justified above and in `seven-slot-comparison.json`.

The packet's `source.original_text` is an authored source restatement plus formal representation explanation. Its sentence asserting both integrands integrable is not verbatim Ex140, and its Lean/covariance exposition is not source wording. I compared against the raw source rather than treating that restatement as an independent authority. This is a provenance clarification, not a discovered mathematical source repair.

No source repair is proposed or accepted. No additional premise is needed by the displayed statement comparison. No source-facing completion credit is assigned beyond this subresult. Phase 2 ends here, pending explicit phase-3 authority on an immutable full candidate and the corresponding runtime evidence.
