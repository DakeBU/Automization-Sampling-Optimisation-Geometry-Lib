import json
from pathlib import Path
import re

from native import out, blobs, proof, consumer, seal_path, map_path, slug
from static_reader import Tree

source_map = json.loads((blobs / map_path).read_bytes())
static = json.loads((out / 'static-result.json').read_bytes())
assert len(static['assertions']) and all(static['assertions'].values())
covered = {proof: set(), consumer: set()}
for mapping in source_map['mappings']:
    for leaf in mapping['lean']:
        first, last = leaf['LF_lines_1based']
        covered[leaf['path']].update(range(first, last + 1))
for path, line in [(proof, 35), (consumer, 27)]:
    print('MISSING_SIGNATURE_LINE', path, line, (blobs / path).read_text().splitlines()[line - 1])
    assert line not in covered[path]
raw = (out / '2610.20492v1.html').read_text()
source = Tree(raw).root
for locator in [
    'A3.SS2.p1',
    'A3.SS2.p10.m2',
    'A3.SS2.p10.m3',
    'S4.Thmtheorem3.p1.m2',
    'A3.SS2.p18.m1',
]:
    node = next(source.find(id=locator))
    print('SOURCE_ANCHOR', locator, raw.count('\n', 0, node.start) + 1,
          node.attrs.get('alttext') or [m.attrs.get('alttext') for m in node.find('math') if m.attrs.get('alttext') == r'N(0,I_{r})'])
proof_page = out / 'static-site' / static['proof_route']
html = Tree(proof_page.read_text()).root
rendered_formulae = [node.text() for node in html.find('div') if 'proof-reader-equation' in node.attrs.get('class', '').split()]
print('FORMULA_COUNT', len(rendered_formulae))
print('FULL_EX106_DISPLAYED', False)
assert not any(r'\mathbb E[R\mathbf1_{\{R>L\}}]' in formula and r'\int_0^\infty' in formula for formula in rendered_formulae)

kernel = (out / 'kernel-b.log').read_text()
found = {}
for match in re.finditer(r'^TARGET (\S+) \([^\n]+\).*?^FIRST PROOF PARENTS \[(.*?)\]\nFIRST TYPE PARENTS \[\]', kernel, re.M | re.S):
    target, deps = match.groups()
    found[target] = [name.strip() for name in deps.split(',')]
assert set(found) == set(source_map['actual_ASTIS_proof_parents'])
for target, mapped in source_map['actual_ASTIS_proof_parents'].items():
    actual = set(found[target])
    authored = {name for name in actual if not re.fullmatch(re.escape(target) + r'\._proof_\d+_\d+', name)}
    assert authored == set(mapped)
    print('AUTHORED_FIRST_PARENTS_MATCH', target)
    for helper in sorted(actual - authored):
        print('KERNEL_GENERATED_HELPER', helper)
