from pathlib import Path
import os,sys,stat,json,hashlib,subprocess,datetime,traceback

ROOT=Path(__file__).resolve().parent; REPO=ROOT.parents[2]
utc=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
sha=lambda b:hashlib.sha256(b).hexdigest()
encode=lambda x:(json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode()
started=utc()
envelope={'payload-manifest.json','freeze-execution.receipt.json','freeze-execution.stdout','freeze-execution.stderr','freeze-envelope-hashes.json'}
assert not any((ROOT/x).exists() for x in envelope),'Do not overwrite a previous freeze.'
# This is a real final re-execution of the source-offset and full-coverage check.
argv=[sys.executable,str(ROOT/'verify_phase1.py')]
r=subprocess.run(argv,cwd=REPO,capture_output=True)
(ROOT/'freeze-verification.stdout').write_bytes(r.stdout)
(ROOT/'freeze-verification.stderr').write_bytes(r.stderr)
assert r.returncode==0,r.stderr.decode(errors='replace')
source=REPO/'.astis/huanjian-resume-20261103/2610.20492v1.html'
source_bytes=source.read_bytes();assert len(source_bytes)==951991
assert sha(source_bytes)=='6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
payload=[]
for path in sorted(ROOT.rglob('*')):
    assert not path.is_symlink(),str(path)
    if path.is_file() and path.name not in envelope:
        b=path.read_bytes();payload.append({'path':str(path.relative_to(ROOT)),'bytes':len(b),'sha256':sha(b),'frozen_mode':'0444'})
manifest={'schema':'phase1-payload-manifest-v1','created_utc':utc(),'root':str(ROOT),'source_path':str(source),'source_bytes':len(source_bytes),'source_sha256':sha(source_bytes),'files':payload,'envelope_exclusion_rule':'This manifest covers every static Phase1 payload file. The five named freeze-envelope files are excluded to avoid recursive self-hashing; freeze-envelope-hashes.json covers the other four and explicitly does not hash itself. All payload and envelope files receive 0444, and all directories receive 0555.','envelope_files':sorted(envelope)}
(ROOT/'payload-manifest.json').write_bytes(encode(manifest))
manifest_sha=sha((ROOT/'payload-manifest.json').read_bytes())
# Pre-open the final envelope streams. Actual chmod/stat verification happens
# before they are finalized through these descriptors, then every descriptor is
# closed. This avoids re-opening or relaxing a frozen directory to write receipts.
handles={name:(ROOT/name).open('w+b') for name in envelope if name!='payload-manifest.json'}
try:
    files=sorted(x for x in ROOT.rglob('*') if x.is_file())
    dirs=sorted([ROOT]+[x for x in ROOT.rglob('*') if x.is_dir()],key=lambda x:len(x.parts),reverse=True)
    executed=[]
    for path in files:
        os.chmod(path,0o444);executed.append({'path':str(path.relative_to(ROOT)),'operation':'chmod','requested_mode':'0444','actual_mode':format(stat.S_IMODE(path.stat().st_mode),'04o')})
    for path in dirs:
        os.chmod(path,0o555);executed.append({'path':'.' if path==ROOT else str(path.relative_to(ROOT)),'operation':'chmod','requested_mode':'0555','actual_mode':format(stat.S_IMODE(path.stat().st_mode),'04o')})
    assert all(x['requested_mode']==x['actual_mode'] for x in executed)
    for rec in payload:
        b=(ROOT/rec['path']).read_bytes();assert sha(b)==rec['sha256'] and len(b)==rec['bytes']
    receipt={'schema':'actual-phase1-freeze-execution-v1','status':'FROZEN_PHASE1','started_utc':started,'chmod_and_payload_recheck_completed_utc':utc(),'cwd':str(REPO),'invocation':['python3',str(Path(__file__).relative_to(REPO))],'actual_interpreter':sys.executable,'source_sha256_rechecked':sha(source_bytes),'payload_manifest_sha256':manifest_sha,'payload_files':len(payload),'all_files_including_envelope':len(files),'directories_including_root':len(dirs),'verification_command':argv,'verification_returncode':r.returncode,'verification_stdout_sha256':sha(r.stdout),'verification_stderr_sha256':sha(r.stderr),'actions':executed,'receipt_finalization':'The four non-manifest envelope handles were opened before chmod. After actual stat verification, the receipt and exact stdout/stderr and envelope hash index are written through those handles and closed; no permissions are relaxed.','scope_limit':'Actual filesystem freeze/structural checks only; no Lean proof, target fidelity judgment, self-approved topology review, Goal/ledger publication, or sourceV judgment.'}
    rb=encode(receipt);handles['freeze-execution.receipt.json'].write(rb);handles['freeze-execution.receipt.json'].flush()
    log=encode({'status':'FROZEN_PHASE1','root':str(ROOT),'source_sha256':sha(source_bytes),'payload_manifest_sha256':manifest_sha,'freeze_receipt_sha256':sha(rb),'source_graph_sha256':sha((ROOT/'source-graph.json').read_bytes()),'coverage_sha256':sha((ROOT/'coverage.json').read_bytes()),'capsule_sha256':sha((ROOT/'capsule.md').read_bytes()),'files_0444':len(files),'directories_0555':len(dirs),'complete_coverage_id_count':520,'mathematical_approval':'not claimed; independent topology review pending'})
    handles['freeze-execution.stdout'].write(log);handles['freeze-execution.stdout'].flush()
    handles['freeze-execution.stderr'].write(b'');handles['freeze-execution.stderr'].flush()
    hashes={'schema':'nonrecursive-freeze-envelope-hashes-v1','self_excluded':'freeze-envelope-hashes.json','files':[]}
    for name in sorted(envelope-{'freeze-envelope-hashes.json'}):
        b=(ROOT/name).read_bytes();hashes['files'].append({'path':name,'bytes':len(b),'sha256':sha(b),'mode':format(stat.S_IMODE((ROOT/name).stat().st_mode),'04o')})
    handles['freeze-envelope-hashes.json'].write(encode(hashes));handles['freeze-envelope-hashes.json'].flush()
    for handle in handles.values():handle.close()
    assert all(stat.S_IMODE(x.stat().st_mode)==0o444 for x in files)
    assert all(stat.S_IMODE(x.stat().st_mode)==0o555 for x in dirs)
    sys.stdout.buffer.write(log)
except BaseException:
    raw=traceback.format_exc().encode()
    h=handles.get('freeze-execution.stderr')
    if h and not h.closed:h.write(raw);h.flush()
    for h in handles.values():
        if not h.closed:h.close()
    sys.stderr.buffer.write(raw)
    raise
