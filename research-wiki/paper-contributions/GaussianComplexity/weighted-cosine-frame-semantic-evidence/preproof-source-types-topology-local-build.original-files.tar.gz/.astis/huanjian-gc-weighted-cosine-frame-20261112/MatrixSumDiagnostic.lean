import Mathlib.Analysis.Matrix.Order
open scoped Matrix.Norms.L2Operator

#print Matrix.sum_apply
#check Finset.sum_apply
#check Finset.sum_apply'

example {d r : ℕ} (t : Fin d → Fin r → ℝ) (j k : Fin r) :
    (∑ i : Fin d, Matrix.vecMulVec (t i) (t i)) j k =
      ∑ i : Fin d, t i j * t i k := by
  exact Matrix.sum_apply j k Finset.univ (fun i => Matrix.vecMulVec (t i) (t i))
