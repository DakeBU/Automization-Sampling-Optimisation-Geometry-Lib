# Independent static review of reader-preview-v2 anchor repair

Reviewer: `mgf_fresh_source_5b7e`.
Decision: **Accepted as the exact minimal static presentation repair; fresh actual runtime remains required.**

The failed reader-preview-v1/runtime-v2 review was frozen first, SHA `fcd72ce50bd7c30888ee44eb18acb940ea46f552c78b965acc4281c12a807d7d`. Only afterwards was this successor proposal opened and assessed. The old failure is neither erased nor reclassified as a pass.

Exact candidate identities:

- Repair proposal SHA `eb493d0f0e38db385921db88395e81dd8a9d2cf61e36751cb6531b6d3bf82388`.
- New preview manifest SHA `c93f60d6b51a0da491bd748d54bdbc68fbdbc2f86653de5914539afb2aaee7d1`.
- New overlay SHA `d0970e97904d550a69d0b403dd2bda50e56d7639bc1c9bbe00ab23293c8038a1`.
- Unchanged generator SHA `8a317f02a591fce3294357fcd3114a6b7a760ca5cd475b42594acc51563c0334`.
- Unchanged input manifest SHA `f35423c5e876d5f5d266aec79fc45ac395d4e5df75771fe579ab38906ba2121e`.

The actual full generator/overlay bytes and exact diff were checked against the previously fully read files. The overlay has exactly one replacement: the `enhance_source` wrapper uses `<code class="native-anchored-lean">` instead of `<code class="language-lean">`. No other code line changes. The supplied exact unified diff was independently regenerated and matches.

All120 snapshot input files remain byte-identical, including the six source modules, exact lesson/publication authored-v2, renderer modules, assets, toolchain and dependency manifest. The new original variant is byte-identical to the prior original variant for every file; the old original and candidate files still match their old manifest hashes.

Comparing the complete old/new candidate file sets shows exactly six changed files: the six selected complete-source HTML pages. Each differs only by that one code class. Every other candidate byte remains identical, including mathematical prose/formulas, assumptions and regularity, all six P/T proof-step folds, source/download actions, graphs, JS, CSS and full-module downloads.

For every changed complete-source page, independent parsing verifies the exact ordered L1..Ln span ids, the complete source text byte-for-byte, and the full download byte-for-byte against the already reviewed 4869 modules. P retains121 lines and T159; all four selected parent-source pages retain their full original line sets. The wrapper still supplies a direct `pre > code` child inside its copy panel.

The source-backed reason this addresses the diagnosed failure is precise: unchanged `site.js` highlights only `code.language-lean`, so this complete-source block is no longer selected for destructive `innerHTML` rebuilding. The six step-level folds retain their existing highlighting and contain the same code. Complete-source text is plain selectable Lean with numbered spans, not a different mathematical object or a reduced code excerpt.

The actual ROOT render receipt records exit0, with its exact log hash verified. This reviewer did not run the renderer, Chrome, server, API or build. A successful render and a statically retained id are not a substitute for a new real source-anchor/navigation/clipboard/geometry run.

This acceptance is only for the bounded presentation repair. It leaves the previous graph limitations intact: default-fit SVG labels are too small; zoomed SVG labels may be elliptical/cropped; full identifiers require the actual detail inspector. It grants no whole candidate runtime acceptance, proof VERIFIED, production/global renderer change, source theorem repair, main/site delivery or purification.

`independent-anchor-repair-static-checks.json` preserves the complete independent comparison and source checks. Exact input proposal, diff, new/old overlay, manifests, ROOT render receipt/log and the six changed source pages are retained under `originals/`.
