from pathlib import Path
import gzip, hashlib, json, subprocess, tarfile
sha = lambda b: hashlib.sha256(b).hexdigest()
B = Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-first-order-semantic-evidence')
checks = B/'actual-checks'
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip() == '9d306d837fbddf1518b0035494baaf5c21c24488'
for p in sorted(Path('.astis/huanjian-resume-20261103').glob('*-fixed-spectrum-first-order-*.receipt.json')):
    if (checks/p.name).exists(): continue
    r = json.loads(p.read_bytes()); raw = Path(r['log']).read_bytes(); assert sha(raw) == r['log_sha256']
    (checks/p.name).write_bytes(p.read_bytes())
    (checks/(Path(r['log']).name+'.gz')).write_bytes(gzip.compress(raw,mtime=0))
roots = [Path('.astis/huanjian-gc-fixed-spectrum-first-order-20261108'),
         Path('.astis/semantic-neutral-20261108/src_4e8f6a'),
         Path('.astis/huanjian-gc-fixed-spectrum-first-order-integration-20261108')]
archive = B/'source-verified-private-workfiles.lossless.tar.gz'; assert not archive.exists()
rows = []
with tarfile.open(archive,'w:gz') as t:
    for i, root in enumerate(roots):
        for p in sorted(q for q in root.rglob('*') if q.is_file()):
            member = str(Path(str(i))/p.relative_to(root)); t.add(p,arcname=member,recursive=False)
            rows.append({'original_path':str(p),'member':member,'raw_bytes':p.stat().st_size,'raw_sha256':sha(p.read_bytes())})
with tarfile.open(archive,'r:gz') as t:
    for row in rows:
        raw = t.extractfile(row['member']).read(); assert sha(raw) == row['raw_sha256'] and len(raw) == row['raw_bytes']
(B/'source-verified-private-workfiles.manifest.json').write_text(json.dumps({
    'archive':str(archive),'archive_sha256':sha(archive.read_bytes()),'all_members_roundtrip_verified':True,
    'all_originals_retained_unchanged':True,'integration_preparation_not_executed':True,'files':rows},indent=2)+'\n')
tracked = set(subprocess.check_output(['git','ls-files'],text=True).splitlines())
wrapped = set()
for n in ['preproof-frozen-raw-packaging','postproof-frozen-raw-packaging']:
    wrapped.update(r['original_path'] for r in json.loads((B/n/'manifest.json').read_bytes())['files'])
pack = B/'source-verified-frozen-raw-packaging'; assert not pack.exists(); pack.mkdir()
safe, rows = [], []
for p in sorted(q for q in B.rglob('*') if q.is_file()):
    if str(p) in wrapped: continue
    if str(p) in tracked and subprocess.check_output(['git','show','HEAD:'+str(p)]) == p.read_bytes(): continue
    raw = p.read_bytes(); binary = p.suffix in ['.gz','.zip','.png'] or b'\0' in raw
    ignored = subprocess.run(['git','check-ignore','-q','--',str(p)]).returncode == 0
    bad = not binary and (b'\r\n' in raw or raw.endswith(b'\n\n') or any(q.endswith((b' ',b'\t')) for q in raw.splitlines()))
    if ignored or bad:
        z = pack/(str(len(rows)).zfill(3)+'-'+p.name+'.gz'); z.write_bytes(gzip.compress(raw,mtime=0))
        assert gzip.decompress(z.read_bytes()) == raw
        rows.append({'original_path':str(p),'raw_sha256':sha(raw),'raw_bytes':len(raw),
                     'gzip_path':str(z),'gzip_sha256':sha(z.read_bytes()),'original_retained_unchanged':True})
        safe.append(z)
    else: safe.append(p)
mp = pack/'manifest.json'; mp.write_text(json.dumps({
    'scope':'Frozen raw artifacts losslessly wrapped only. Mutable audit/frontier/ledger directly staged and checked against live bytes.',
    'files':rows},indent=2)+'\n'); safe.append(mp)
mutable = [Path('research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-first-order.json'),
           Path('research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-first-order.json'),
           Path('runs/substantive_advances.jsonl')]
safe += mutable
subprocess.run(['git','add','--',*map(str,safe)],check=True)
subprocess.run(['git','diff','--cached','--check'],check=True)
for p in mutable: assert subprocess.check_output(['git','show',':'+str(p)]) == p.read_bytes()
assert sha(mutable[0].read_bytes()) == 'a14867ad5fd8723933500d4c264c91c05d6b11ef510090c3b6da216fcb402b57'
print(json.dumps({'staged_paths':len(safe),'frozen_raw_wrappers':len(rows),
    'mutable_audit_frontier_ledger_index_equals_live':True,'source_verdict_or_API_created_by_root':False,
    'next_commit_first_carries_accepted_audit_and_actual_independent_V':True}))
