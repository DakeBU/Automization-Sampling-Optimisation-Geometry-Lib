# R15 independent source graph capsule

The source-only graph was frozen before sealed P/T or their audit were read. Its SHA256 is `fef1100b26718cce7884f745a2cea3f75cb8a2c3897b885a660123b6c149758d`; it has 27 nodes, 45 acyclic source-use edges and 14 explicit exclusions. This is proposed coverage for a different reviewer to challenge, not self-approved coverage.

The pinned original Tropp PDF and Gaussian HTML hashes match the task. Tropp physical pages7–10 were rendered and visually inspected. The requested Gaussian equation IDs occur as A3.Ex85/107/112/121 and A3.SS2.p10/p13/p15/p15.2; C2 is the mathematical appendix designation, not the DOM prefix.

P matches Prop3.1 as a real self-adjoint specialization with explicitly disclosed nonnegative extended scalar expectation. The source does not define ENNReal. The completion is mathematically appropriate because trace exponential is positive on the source domain and the proof uses nonnegative Markov/monotonicity; infinity must not become Bochner default zero. The source §3.1 warning about mgf existence makes an added all-parameter finite-mgf assumption especially inappropriate. All real thresholds and all positive parameters are retained. Algebraic largest eigenvalue, nonempty finite dimension and ordinary trace are essential.

T matches the literal original unconditional Gaussian product experiment, own-row inclusive cutoff, ordinary mean centering, ordinary/cosine sums, and each sum's two global signs. Its matrix dimension is `(q+1)^2`. Its sealed type returns a tail inequality and does not separately return `Integrable`. Actual finite Bochner trace expectation must therefore be established inside the proof and retained as auditable dependency evidence; the seal alone is not that evidence.

The source and sealed binders introduce no mathematical EXCESS. The root audit's mixed classification labels can be normalized using the independent singleton bins in the source-vs-seal file; this is classification hygiene, not a statement correction. No production file was changed.

The fixed-s trace-integrability bridge is still open: deterministic bounded cutoff sums give a finite norm bound; spectral calculus gives `0<tr exp(sH)<=N exp(s*C)` for fixed positive s; measurability and finite probability yield the actual scalar integrability and the extended/Bochner agreement. AE event regularity, spectrum maximum semantics, Markov and infimum are also still proof obligations. The source Gaussian strict norm tail needs both signs, strict-to-nonstrict event inclusion and a union bound. No atom-free assertion is available.

This audit does not prove P/T, Eq121, Lieb, independent-sum mgf bounds, variance, Bernstein, C6, full LemmaC2 or any broader result. No Lean, browser, API, ledger or Git mutation was run. Initial failed extraction scripts, real command streams and receipts remain in this owned directory. A raw-only context matcher emitted a few additional g/angle source paragraphs; the source graph explicitly excludes them from its proof ancestry and preserves the stream.

Public challenge packet: `phase1.source-only.graph.frozen.v1.json`, `phase1.freeze.receipt.v1.json`, `phase2.source-vs-seal.v1.json`, this capsule, and the two original source pins. Reviewers should re-read raw sources and need not consume private tool history.
