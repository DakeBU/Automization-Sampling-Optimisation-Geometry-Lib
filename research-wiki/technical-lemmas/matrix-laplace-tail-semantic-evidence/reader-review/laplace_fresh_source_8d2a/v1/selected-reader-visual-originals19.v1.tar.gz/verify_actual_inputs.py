from pathlib import Path
from datetime import datetime
from html.parser import HTMLParser
import json,hashlib,struct,collections
B=Path('/Users/zhouhuanjian/ASTIS-GC');R=B/'.astis/semantic-neutral-20261114/laplace_native_61e4/reader-runtime-v3';O=Path(__file__).parent;W=B/'.astis/huanjian-gc-matrix-laplace-20261114';sha=lambda d:hashlib.sha256(d).hexdigest()
manifest=json.loads((R/'presentation-selected-originals.manifest.v1.json').read_text());assert sha((R/'presentation-selected-originals.manifest.v1.json').read_bytes())=='3cea83cd0e61df11cba9ab36dca51f1f64c79b18df1238b836d8f9c05f301451'
assert len(manifest['leaves'])==356
for x in manifest['leaves']:
 rel=Path(x['path']);assert not rel.is_absolute() and '..' not in rel.parts
 assert not any('guard' in part.lower() or 'foreign' in part.lower() or part=='.git' for part in rel.parts)
 data=(R/rel).read_bytes();assert len(data)==x['bytes'] and sha(data)==x['sha256']
# The native outcome leaf was hashed only; no acceptance prose/verdict was consumed.
receipt=json.loads((R/'browser-process-v1/candidate/process-receipt.json').read_text());checks=json.loads((R/'browser-output-v1/candidate/actual-checks.json').read_text());contract=json.loads((R/'independent-browser-contract.v1.json').read_text());assert sha((R/'independent-browser-contract.v1.json').read_bytes())==receipt['contract_sha256']==checks['contract_sha256'];assert sha((R/'browser_check.py').read_bytes())==receipt['wrapper_sha256']==checks['wrapper_sha256'];assert receipt['exit_code']==0 and receipt['exception'] is None
for key in ['stdout','stderr','actual_checks']:
 x=receipt[key];data=(R/x['path']).read_bytes();assert len(data)==x['bytes'] and sha(data)==x['sha256']
assert receipt['actual_checks']['sha256']=='591b27fa052af6bfcfd65f1de388a3b866b1442ec129120c9f08ea86c3b051be'
assert len(checks['checks'])==398 and len({x['name'] for x in checks['checks']})==398;assert all(x['pass'] is True for x in checks['checks']);assert checks['javascript_errors']==[] and checks['blocked_external_requests']==[]
for x in contract['owned_inputs']:
 data=(R/x['path']).read_bytes();assert sha(data)==x['sha256']
start=datetime.fromisoformat(receipt['started']).timestamp();end=datetime.fromisoformat(receipt['ended']).timestamp();pngs=[]
for x in checks['screenshots']:
 f=R/x['path'];data=f.read_bytes();assert sha(data)==x['sha256'];assert data[:8]==b'\x89PNG\r\n\x1a\n';width,height=struct.unpack('>II',data[16:24]);assert width==(1440 if f.name.startswith('desktop') else 390);pngs.append({'path':str(f),'runtime_relative_path':x['path'],'name':f.name,'sha256':sha(data),'bytes':len(data),'width':width,'height':height,'mtime_within_actual_process_window':start-1<=f.stat().st_mtime<=end+1})
assert len(pngs)==103 and len({x['path'] for x in pngs})==103;assert {f.name for f in (R/'browser-output-v1/candidate').glob('*.png')}=={x['name'] for x in pngs};assert all(x['mtime_within_actual_process_window'] for x in pngs)
(O/'all_actual_PNGs.manifest.json').write_text(json.dumps(pngs,indent=2)+'\n')
P='AutoSamplingTheory/TechnicalLemmas/Probability/MatrixLaplaceTail.lean';T='Tests/GaussianComplexityLaplaceTail.lean';sources={'P':P,'T':T,'Radius':'AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumSourceMatrixRadius.lean','Structure':'AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumSourceMatrixStructure.lean'}
assert sha((B/P).read_bytes())=='4924fede99548f6aab4f63605d2beed9dc435d6338a61d89ee301d9e83733749';assert sha((B/T).read_bytes())=='9ecf723f0487ddf50cb1d7c3102ebc04b58c472e56d2b16b186d91bc91cc6aac'
downloads=[]
for f in sorted((R/'browser-output-v1/candidate').glob('*.lean')):
 if '-step-' in f.name:n=int(f.name.split('-step-')[1].split('-')[0]);source=P if n<=3 else T
 else:source=sources[f.name.split('-complete-')[1].split('.')[0]]
 data=f.read_bytes();expected=(B/source).read_bytes();assert data==expected;downloads.append({'path':str(f),'source':source,'sha256':sha(data),'bytes':len(data),'entire_current_and_frozen_module_exact':True})
assert len(downloads)==20;(O/'actual_downloads.exactness.json').write_text(json.dumps(downloads,indent=2)+'\n')
class Pre(HTMLParser):
 def __init__(self):super().__init__(convert_charrefs=True);self.on=0;self.parts=[];self.blocks=[]
 def handle_starttag(self,t,a):
  if t=='pre':
   self.on+=1
   if self.on==1:self.parts=[]
 def handle_endtag(self,t):
  if t=='pre':
   self.on-=1
   if self.on==0:self.blocks.append(''.join(self.parts))
 def handle_data(self,d):
  if self.on:self.parts.append(d)
source_bodies=[]
for label,rel in sources.items():
 data=(B/rel).read_bytes();assert (W/'reader-preview-v3/fixtures/candidate/downloads/lean'/rel).read_bytes()==data;html=W/'reader-preview-v3/fixtures/candidate/data/lesson-sources'/(rel+'.html');a=Pre();a.feed(html.read_text());assert a.blocks==[data.decode()];source_bodies.append({'label':label,'source':rel,'sha256':sha(data),'lines':len(data.decode().splitlines()),'source_pre_and_fixture_download_equal_current_bytes':True})
 for device in ['desktop','mobile']:
  c=next(x for x in checks['checks'] if x['name']==device+'-'+label+'-every-source-line-has-real-layout');assert len(c['detail'])==len(data.decode().splitlines());assert all(x['height']>0 for x in c['detail'])
# Direct fixture recheck, including the original variant which was not newly browser-executed.
identity=json.loads((R/'v3-v4-site-byte-identity.v1.json').read_text());assert sha((R/'v3-v4-site-byte-identity.v1.json').read_bytes())=='a2296200cb7e3217d3d3269a837f7930a05ce05af5d44d5cdddc13e261daf443';assert len(identity['served_files'])==207
for x in identity['served_files']:
 a=(W/'reader-preview-v3/fixtures'/x['variant']/x['path']).read_bytes();b=(W/'reader-preview-v4/fixtures'/x['variant']/x['path']).read_bytes();assert a==b and len(a)==x['bytes'] and sha(a)==x['sha256']
assert sha((W/'reader-preview-v3/preview-freeze-manifest.json').read_bytes())==checks['reader_identity']['frozen_fixture_manifest_sha256']=='9209609b560905e6cd11a69082ac4bdb89e752a66fe3e99ba38e17508d2103b7';assert sha((W/'reader-preview-v4/preview-freeze-manifest.json').read_bytes())=='809059d961095cd0984a385d18f618be342480b89f69bfe2e75c6cd91862afd8'
for version in ['v3','v4']:
 m=json.loads((W/('reader-preview-'+version)/'preview-freeze-manifest.json').read_text())
 for variant,r in m['variants'].items():
  assert {str(f.relative_to(W/('reader-preview-'+version)/'fixtures'/variant)) for f in (W/('reader-preview-'+version)/'fixtures'/variant).rglob('*') if f.is_file()}=={x['path'] for x in r['files']}
  for x in r['files']:
   d=(W/('reader-preview-'+version)/'fixtures'/variant/x['path']).read_bytes();assert len(d)==x['bytes'] and sha(d)==x['sha256']
byname={x['name']:x for x in checks['checks']};graph_measurements=[]
for c in checks['checks']:
 if 'readable-existing-graph-UI' in c['name'] or 'readable-after-existing-UI-zoom-pan' in c['name']:
  d=c['detail'];graph_measurements.append({'check':c['name'],'default_font_px':d['default_fit']['effectiveFontPx'],'after_font_px':d['after_real_wheel_and_pointer_UI']['effectiveFontPx'],'after_bbox':{k:d['after_real_wheel_and_pointer_UI'][k] for k in ['left','right','top','bottom','viewportWidth','viewportHeight']},'DOM_transform_mutation':d['DOM_transform_mutation'],'coverage_limit':'Font/bbox values do not by themselves test intersection with the SVG clipping area; desktop parent1/2 screenshot finding retained.'})
(O/'raw_graph_measurements.with_limits.json').write_text(json.dumps(graph_measurements,indent=2)+'\n')
result={'reviewer':'/root/laplace_fresh_source_8d2a','native_outcome_verdict_not_read_or_inherited':True,'selected_manifest_all_leaf_hashes_verified':356,'actual_check_count':398,'actual_check_names_unique':True,'recorded_flags_true':398,'recorded_flags_are_not_visual_acceptance':True,'actual_PNG_files':103,'PNG_hash_count_unique':len({x['sha256'] for x in pngs}),'all_PNG_mtimes_within_actual_receipt_window':True,'actual_downloads_all_complete_byte_exact':20,'source_bodies_unchanged':source_bodies,'actual_clipboard_comparison_checks':sum('actual-clipboard' in x['name'] or 'actual-copy-complete-source' in x['name'] for x in checks['checks']),'runtime_browser':'Headless installed Google Chrome '+checks['actual_chrome']['runtime_browser_version'],'actual_viewports':contract['viewports'],'actual_process_receipt_sha256':'8e76c6556cc64e59f5ddf99ff2c4823708fa21b52b03bbfcf57ef5c554046045','actual_checks_sha256':'591b27fa052af6bfcfd65f1de388a3b866b1442ec129120c9f08ea86c3b051be','actual_run_target':'reader-preview-v3 candidate only','actual_v4_browser_run':False,'served_v3_v4_files_independently_compared':207,'served_identity_scope':'Only identical delivered bytes/rendered UI/navigation artifacts; not a fresh v4 process/metadata proof or source-fidelity decision.','no_API_Git_browser_fixture_or_production_mutation_by_this_reviewer':True,'check_group_counts':dict(collections.Counter(x['name'].split('-',1)[0] if not x['name'].startswith('fixture-unchanged:') else 'fixture-unchanged' for x in checks['checks']))}
(O/'independent_actual_chain_checks.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
