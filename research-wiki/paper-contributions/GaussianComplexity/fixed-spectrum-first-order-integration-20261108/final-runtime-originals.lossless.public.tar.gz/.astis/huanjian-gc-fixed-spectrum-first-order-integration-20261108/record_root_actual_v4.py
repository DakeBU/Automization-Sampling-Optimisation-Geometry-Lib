from pathlib import Path
import datetime, hashlib, json

R = Path('.astis/huanjian-gc-fixed-spectrum-first-order-integration-20261108')
D = R/'independent-reader/browser/live-20261108T160740169669Z'
P = D/'report.json'
sha = lambda b: hashlib.sha256(b).hexdigest()
report = json.loads(P.read_bytes())
assert sha(P.read_bytes()) == '0eac0b4cb4c12d545d09a0416a98dd06f5aa52ff88573d2741781360fee55494'
assert report['status'] == 'passed' and report['errors'] == []
assert report['head'] == '9b1e90d25711668203c6e252cfe5a748f95c8ad4'
images = {}
for row in report['screenshots']:
    raw = (D/row['file']).read_bytes()
    assert sha(raw) == row['sha256'] and raw[:8] == b'\x89PNG\r\n\x1a\n'
    size = [int.from_bytes(raw[16:20], 'big'), int.from_bytes(raw[20:24], 'big')]
    assert size in [[1440, 1000], [390, 844]]
    images[row['file']] = {**row, 'actual_dimensions': size}
assert len(images) == 38
observations = {
    'actual-390-graph-module-native-click.png': 'Selected module card and its rendered abbreviated label are fully visible inside the mobile canvas. Actual module detail begins below; full detail and all graph nodes are not claimed visible at once. Old right-offscreen selected-card HOLD is corrected in this original.',
    'actual-1440-graph-module-native-click.png': 'Selected module card is framed in the canvas, with actual module detail/full name and imports below. Solid module structure and dashed overlays remain distinct; some neighboring nodes extend beyond focused view as expected.',
    'actual-390-first.png': 'Concise statement and rendered gradient/value formula fit the mobile content width; exact Lean is closed by default. No missing-backslash or raw TeX defect observed.',
    'actual-1440-first.png': 'Main formula is rendered, exact Lean and full assumptions are closed, six-step progressive proof begins below, and actual current core gate strip is visible.',
    'actual-390-proof-step3.png': 'Open derivative-existence step has readable prose, rendered derivative formula and corresponding Lean explanation, without horizontal page overflow.',
    'actual-390-exact-statement.png': 'Exact-statement disclosure is open adjacent to the statement; explanatory notes fill this viewport. Exact code lies farther below; this image alone does not show all exact code.',
    'actual-390-module.png': 'Native full-module disclosure, copy/download controls and actual import/source prefix are visible. Code is locally scrollable; the full file is not claimed visible at once.',
    'actual-390-source-index-open.png': 'Actual source-index item opens to its reader link and explanation while neighboring source items remain reachable.',
}
geometry = report['native_selection_geometry']
assert len(geometry) == 8 and all(r['geometry']['ok'] for r in geometry)
assert all(r['geometry']['camera_actions_by_harness'] == [] for r in geometry)
out = R/'root-actual-v4-original8-review.json'
assert not out.exists()
value = {
    'recorded_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'reviewer': '/root', 'scope': 'Root actual8 original pixel inspection plus all38 raw image integrity and eight native DOM/UI geometry readback; independent review still separate',
    'actual_browser_report': {'path': str(P), 'sha256': sha(P.read_bytes())},
    'accepted_immutable_core': report['head'],
    'actual_all38_original_hashes_and_PNG_dimensions_verified': True,
    'actually_viewed_originals': [{**images[name], 'viewed_original': True, 'observation': obs} for name, obs in observations.items()],
    'native_geometry_rows': geometry,
    'extra_four_preset_crossview_rows': 'Read-only actual DOM/UI geometry only, no extra image or pixel-review claim',
    'blocking_objections_in_root_eight_actual_views': [],
    'new_source_verdict': False, 'local_acceptance_created': False,
    'normalpark_authorized': False, 'remote_or_wholeGoal_acceptance': False,
}
out.write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n')
print(json.dumps({'path': str(out), 'sha256': sha(out.read_bytes()), 'root_actual_original_views': len(observations), 'all_original_hashes_checked': len(images), 'new_source_or_local_acceptance_verdict': False}))
