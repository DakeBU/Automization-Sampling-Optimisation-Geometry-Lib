"""Projection-only successor. No proof transition exists here. Preparation does not authorize a cell write."""
from verification_common import *
import argparse,traceback

BEFORE='8f6a5225aefe5679c0606991c89c595c7c6aec67a66a70c07b847bf09e30bcd2'
FIXED='0becf6729aa2bc943b2a6ff4f36c5ea476a6d4e5212e58008512d36c6f26b7a7'
CARRIER='45564beb6e0dd5e4357718ea04347a50613ad502'
VOUT='88dceac7c7f79528f4efe737ad3cb755615bc3b33168c169a6f9d73d2fc87fa5'
VAPP='687201b4deea0187f8a94fa69b6f07aa16bc01237a6917c574e35ac197835784'
def differences(a,b,path=''):
    if type(a) is not type(b):return [path]
    if isinstance(a,dict):return sum((differences(a[k],b[k],path+'/'+k) if k in a and k in b else [path+'/'+k] for k in sorted(set(a)|set(b))),[])
    if isinstance(a,list):return [] if a==b else [path]
    return [] if a==b else [path]

def config(path,expected_sha,authorized):
    assert file_sha(path)==expected_sha;a=read(path)
    assert a['authorization']==('ROOT_EXPLICIT_PROJECTION_ONLY_SUCCESSOR_AUTHORIZATION' if authorized else 'PREPARED_ONLY_NOT_AUTHORIZED')
    assert a['authorized_action']=='PROJECT_PREVALIDATED_EXACT_CELL_BYTES_ONCE' and a['normal_API_calls_authorized']==0
    assert a['advance_id']==ADV and a['verifier_id']==VERIFIER and a['carrier_commit']==CARRIER and a['target_cell']==CELL
    assert a['expected_before_sha256']==BEFORE and a['expected_fixed_sha256']==FIXED and a['prior_failure_preserved']
    assert set(a['scripts'])=={'projection_only.py','verification_common.py'}
    for name,h in a['scripts'].items():assert file_sha(OWN/name)==h
    assert a['scripts']['verification_common.py']=='72830e709d292ca2f9ce2c8e8ed01ecd51b85b7614639c3dd5ebf4e405e15106'
    return a

def validate_inputs(a):
    data={k:pin_bytes(v) for k,v in a['pins'].items()}
    assert sha(data['cell_before'])==BEFORE and sha(data['fixed_bytes'])==FIXED
    assert sha(data['failed_proposed_bytes'])=='5dea6e6ec7724f61432a65f6b34c717f0a5775b0dbc16202cdbd36fa1724b22a'
    assert sha(data['V_outcome'])==VOUT and sha(data['V_append'])==VAPP and sha(data['PL24'])==PLSHA
    assert sha(data['failed_driver'])=='e380649911243cf8df3c8258fc459889c2f595bdb811a8a939df21cc4a4a4b12'
    assert sha(data['canonical_validator'])=='db02cb0abb9501310a00b2c61dca4b9ec4236e5ca1cc2a1528e68244bd6974b0'
    pl=json.loads(data['PL24']);v=json.loads(data['V_outcome']);app=json.loads(data['V_append']);old=json.loads(data['cell_before']);fixed=json.loads(data['fixed_bytes']);failed=json.loads(data['failed_proposed_bytes'])
    assert len(pl)==24 and all(app['evidence'][k]==value for k,value in pl.items())
    assert v['normal_API_calls']==1 and v['actual_exit_code']==0 and v['all_window1_postguards_passed'] and v['verified_commit']==CARRIER and v['verifier_id']==VERIFIER and v['exact_appended_record_sha256']==VAPP
    assert app['advance_id']==ADV and app['from_state']=='PROVED_LOCAL' and app['to_state']=='VERIFIED' and app['worker_id']==VERIFIER
    assert old['status']=='proved_locally' and fixed['status']=='independently_verified'
    assert differences(failed,fixed)==['/evidence/independent_verification']
    expected=str((REPO/a['pins']['V_outcome']['file']).relative_to(REPO));assert fixed['evidence']['independent_verification']==expected
    for k in ['target_statement','private_consumer_statement','statement_seal','source_anchor','source_proof_coverage','semantic_roundtrip','purification']:assert fixed[k]==old[k]
    assert fixed['consumer_scope']['first_realistic_consumer']['public_node'] is False and fixed['consumer_scope']['second_realistic_consumer']==old['consumer_scope']['second_realistic_consumer']
    assert file_sha(REPO/'tools/astis_advance.py')==a['expected_api_sha256']
    araw=(REPO/ADVPATH).read_bytes();draw=(REPO/DISCPATH).read_bytes();assert sha(araw)==a['expected_advance_ledger_sha256'] and sha(draw)==a['expected_discovery_ledger_sha256']
    records,_,states,_=replay(araw,draw);rows=[r for r in records if r.get('advance_id')==ADV]
    assert states[ADV]['state']=='VERIFIED' and states[ADV]['owner_id']==OWNER and states[ADV]['publication_declarations']==[P]
    assert sum(r.get('to_state')=='PROVED_LOCAL' for r in rows)==sum(r.get('to_state')=='VERIFIED' for r in rows)==1
    assert any(line+b'\n'==data['V_append'] for line in araw.splitlines())
    sys.path.insert(0,str(REPO));from tools import astis_frontier_cells as cells
    probe=copy.deepcopy(fixed);probe['__path__']=CELL;errors=cells.validate_cells([probe]);assert errors==[],errors
    return data,old,fixed,errors

def execute_projection(a,authpath):
    marker=PRIVATE/'projection-attempted.once.json';assert not marker.exists()
    data,old,fixed,errors=validate_inputs(a)
    before=snapshot('successor-before',a)
    assert {n.decode() for n in git('successor-before-worktree','diff','--name-only','HEAD','-z').split(b'\0') if n}=={ADVPATH}
    assert not git('successor-before-index','diff','--cached','--name-only','-z')
    raw=data['fixed_bytes'];assert (REPO/CELL).read_bytes()==data['cell_before'] and sha(raw)==FIXED
    exact(PRIVATE/'target-cell.before.exact.json',data['cell_before']);exact(PRIVATE/'target-cell.fixed.exact.json',raw)
    write(OWN/'canonical-schema-validation.actual.json',{'validator':a['pins']['canonical_validator'],'fixed_target_sha256':FIXED,'actual_errors':errors,'actual_pass_before_marker_or_write':True})
    write(marker,{'local_private_do_not_publish':True,'advance_id':ADV,'authorization_sha256':file_sha(authpath),'normal_API_calls':0,'before_sha256':BEFORE,'fixed_sha256':FIXED,'about_to_write_exact_prevalidated_bytes_once':True})
    with (REPO/CELL).open('wb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
    after=snapshot('successor-after',a);guards=postguards(before,after,a,{CELL},cell_exception=CELL)
    assert before['araw']==after['araw'] and before['draw']==after['draw'] and (REPO/CELL).read_bytes()==raw
    for name,row in a['pins'].items():
        if name!='cell_before':pin_bytes(row)
    write(OWN/'projection-postguards.public.json',{'status':'EXACT_FIXED_TARGET_PROJECTED_WITH_ALL_POSTGUARDS_PASSED','advance_id':ADV,'independent_projector':VERIFIER,'target_cell':CELL,'before_sha256':BEFORE,'actual_new_cell_sha256':file_sha(REPO/CELL),'expected_fixed_sha256':FIXED,'target_cell_status':'independently_verified','normal_API_calls_in_successor':0,'additional_proof_V_calls':0,'all_postguards_passed':True,'both_ledgers_exact':True,'HEAD_branch_index_modes_other_tracked_frontiers_foreign_states_exact':True,'sealed_math_source_audit_coverage_purification_unchanged':True,'original_failed_driver_and_failure_pins_unchanged':True,'original_normal_V_outcome_sha256':VOUT,'original_exact_V_append_sha256':VAPP,'guards':guards,'full_maps_raw_streams_private_only':True})
    print(json.dumps({'status':'EXACT_FIXED_CELL_PROJECTED','advance_id':ADV,'actual_new_cell_sha256':FIXED,'normal_API_calls':0,'additional_proof_V_calls':0,'all_postguards_passed':True}),flush=True)

def public_manifest(success):
    names=['projection_only.py','verification_common.py','projection-OS-receipt.public.json']
    names+=['canonical-schema-validation.actual.json','projection-postguards.public.json','projection-outcome.public.json'] if success else ['projection-stopped.public.json']
    write(OWN/'projection-public-selected-originals.manifest.json',{'schema':'r16-projection-only-successor-explicit-own-public-leaves-v1','actual_success':success,'normal_API_calls':0,'additional_proof_V_calls':0,'files':[{'path':n,'bytes':(OWN/n).stat().st_size,'sha256':file_sha(OWN/n)} for n in names],'full_guard_maps_whole_ledgers_index_git_output_raw_OS_streams_private_excluded':True,'actual_OS_receipt_public_copy_byte_exact':True,'old_failed_window_and_real_V_never_rewritten':True})

def main():
    os.umask(0o077)
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--read-only-precheck',action='store_true');parser.add_argument('--authorization',type=Path,required=True);parser.add_argument('--authorization-sha256',required=True);parser.add_argument('--child',action='store_true');args=parser.parse_args()
    a=config(args.authorization,args.authorization_sha256,not args.read_only_precheck)
    if args.read_only_precheck:
        assert not args.child;_,_,_,errors=validate_inputs(a)
        assert not (PRIVATE/'projection-attempted.once.json').exists()
        write(OWN/'read-only-precheck.actual.json',{'status':'PREPARED_ONLY_ALL_PINS_AND_ACTUAL_CANONICAL_SCHEMA_PASS','actual_validator_errors':errors,'pins_verified':a['pins'],'fixed_target_sha256':FIXED,'cell_before_sha256':BEFORE,'scripts':a['scripts'],'source_carrier':CARRIER,'normal_API_calls':0,'cell_writes':0,'new_guard_or_action_marker_not_created':True})
        print(json.dumps({'status':'PREPARED_ONLY','actual_validator_errors':errors,'normal_API_calls':0,'cell_writes':0,'fixed_target_sha256':FIXED}),flush=True);return 0
    if args.child:execute_projection(a,args.authorization);return 0
    directory=PRIVATE/'projection-OS-process';assert not directory.exists();private_dir(directory);out=directory/'stdout.raw';err=directory/'stderr.raw';argv=[sys.executable,str(Path(__file__).resolve()),*sys.argv[1:],'--child'];env={'HOME':'/Users/zhouhuanjian','PATH':str(Path(sys.executable).parent)+':/usr/bin:/bin','LC_ALL':'C','PYTHONDONTWRITEBYTECODE':'1','PYTHONIOENCODING':'utf-8','GIT_OPTIONAL_LOCKS':'0','ASTIS_ATLAS_ROOT':str(REPO/'.atlas-upstream/v1')};started=dt.datetime.now(dt.timezone.utc).isoformat();start=time.monotonic()
    with out.open('xb') as o,err.open('xb') as e:
        os.fchmod(o.fileno(),0o600);os.fchmod(e.fileno(),0o600);child=subprocess.Popen(argv,cwd=REPO,env=env,stdin=subprocess.DEVNULL,stdout=o,stderr=e);code=child.wait()
    receipt={'schema':'r16-projection-only-successor-actual-OS-receipt-v1','argv':argv,'cwd':str(REPO),'pid':child.pid,'parent_pid':os.getpid(),'started_utc':started,'ended_utc':dt.datetime.now(dt.timezone.utc).isoformat(),'elapsed_seconds':time.monotonic()-start,'actual_exit_code':code,'stdout':{'private':True,'bytes':out.stat().st_size,'sha256':file_sha(out)},'stderr':{'private':True,'bytes':err.stat().st_size,'sha256':file_sha(err)},'authorization_sha256':file_sha(args.authorization),'scripts':a['scripts'],'environment_explicit_whitelist':env,'normal_API_calls':0,'additional_proof_V_calls':0,'no_automatic_retry_rollback':True}
    write(directory/'receipt.private.json',receipt);exact(OWN/'projection-OS-receipt.public.json',(directory/'receipt.private.json').read_bytes())
    if code:
        write(OWN/'projection-stopped.public.json',{'status':'ACTUAL_FAILURE_STOP_NO_RETRY_NO_ROLLBACK','actual_exit_code':code,'advance_id':ADV,'new_projection_marker_present':(PRIVATE/'projection-attempted.once.json').exists(),'actual_current_cell_sha256':file_sha(REPO/CELL),'normal_API_calls':0,'additional_proof_V_calls':0,'inspect_original_private_streams_and_actual_bytes_before_future_action':True});public_manifest(False);return code
    outcome={**read(OWN/'projection-postguards.public.json'),'actual_exit_code':code,'actual_OS_receipt':ident(OWN/'projection-OS-receipt.public.json'),'original_normal_V_outcome':a['pins']['V_outcome'],'original_exact_normal_V_append':a['pins']['V_append'],'actual_math_build_identity':MATH,'verified_source_carrier':CARRIER,'no_new_build_reader_source_or_integration_claim':True}
    write(OWN/'projection-outcome.public.json',outcome);public_manifest(True)
    print(json.dumps({'status':'PROJECTION_ONLY_SUCCESSOR_COMPLETED','actual_exit_code':code,'cell_sha256':FIXED,'normal_API_calls':0,'additional_proof_V_calls':0}),flush=True);return 0
if __name__=='__main__':sys.exit(main())
