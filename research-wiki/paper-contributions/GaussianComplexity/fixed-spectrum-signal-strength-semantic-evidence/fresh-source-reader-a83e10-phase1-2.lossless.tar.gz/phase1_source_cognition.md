# Phase 1: independent raw-source cognition

Reviewer: `/root/source_reader_a83e10`. Role: fresh source reviewer, not formalizer or decoder. This account was written before any candidate signature, title, statement, implementation, lesson, proposed graph, canonical audit, frontier record, reconstruction, or prior review content was supplied. It makes no candidate-equivalence verdict and no whole-paper completion claim.

The pinned input is `.astis/huanjian-resume-20261103/2610.20492v1.html`, title **On Complexity of Gaussian Sampling**, SHA-256 `6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915`. I read the complete DOM subtrees S2, S4 (including S4.4), A3.SS3 (Appendix C.3), and the bibliography's displayed [22], whose actual DOM identity is `bib.bib3`. All formulas were read through their original MathML `alttext`/TeX and the adjacent raw prose. The extraction preserves original DOM IDs, every mathematical expression, citations and links. This is local source reading; no cited external paper was opened.

The frozen raw inventory contains 19 S2 units (45 math elements), 98 S4 units (221 math elements), and 51 A3.SS3 units (84 math elements), where units include structural headings and separately indexed citations as well as paragraphs and displays. Bibliography [22] is separately preserved as HTML/text and one bibliographic node. `coverage.json` gives a disposition to each extracted unit; `raw_source_inventory.json` retains their exact source text. Terminal proof symbols and headings are structural exclusions, not mathematical omissions. The independent source graph in `source_only_graph.json` records source routes and unread dependencies, not implementation dependencies.

## Exposure and reading limits

The assigned paper/source identity and GaussianComplexity contribution context were supplied by the parent. They are not a candidate statement. I have not inspected any candidate mathematical payload or actual earlier verdict.

A protocol-discovery command was overly broad: `rg --files -g '*contrib*' -g '*CONTRIB*' -g '*formalization-protocol*' -g 'AGENTS.md' .agents docs .`. Its output was truncated and incidentally showed existing contributor-log filenames under `research-wiki` and `runs`. Exact visible GaussianComplexity labels were:

* `research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-determinant-semantic-evidence/actual-checks/20261108T024346195970Z-fixed-spectrum-determinant-local-contributor.log.gz`
* the same prefix and timestamp ending `.receipt.json`
* `research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-determinant-semantic-evidence/actual-checks/20261108T020537963610Z-fixed-spectrum-determinant-source-admitted-contributor.receipt.json`

Other visible filenames concerned older PBPS records, including actual-phase-transition-kernel85, sharp-energy68, source-mean-gradient-domain54, actual-countable-endpoint105, actual-phase-reversal-volume96 and their contributor logs/receipts. No contents were opened. The status-like string `source-admitted` was a filename label only; it supplies no prior verdict content. Since the new target has not been supplied, I cannot determine whether an older filename label happens to coincide with its semantic identity. I did not infer a target from it, and I do not claim pristine zero incidental filename exposure. The parent was notified immediately, then directed this disclosed review to continue. No rescan or file opening was used to reconstruct the truncated result.

An initial DOM section-outline command showed headings/first 220 text characters for sections throughout the original paper (including S1, S3, other appendices, disclosure/acknowledgments), but those source regions were not read as full proof inputs. This account does not certify them. Raw bibliography backreferences mention locations outside the authorized slice; they were not followed. No `.astis` sibling scan, native app/browser action, proof/API work, canonical ledger mutation or production edit occurred. All writes are inside the newly created directory containing this account.

Protocols read: `AGENTS.md`; `docs/contributor-codex-contract.md`; `docs/formalization-protocol.md`; `docs/theorem-publication-protocol.md`; `docs/proof-digestion-protocol.md`; `docs/evidence-routed-memory-protocol.md`; `.agents/skills/astis-semantic-roundtrip/SKILL.md`; `.agents/skills/astis-source-dependency-audit/SKILL.md`; `.agents/skills/astis-substantive-advance/SKILL.md`. These are process inputs, not candidate proof evidence. The source-first invariant is that a source hypothesis remains a binder, while a proof ingredient remains an internally discharged dependency. Any later candidate judgment must compare all seven semantic slots and keep source, formal statement, mismatch and proposed repair distinct.

## S2: objects, domains, accuracy and cost

The ambient space is real Euclidean space with its Euclidean norm; Loewner order applies to symmetric real matrices. The source defines the real orthogonal group `O(n) = {O : OᵀO = Iₙ}` with Haar probability. Its two determinant components have probability one half; `μₙ,b` means conditioning Haar on determinant sign `b ∈ {-1,+1}`. This notation is part of the complete preliminaries, although Section 4 uses full Haar on O(d), not a determinant-sign prior.

For integer `d ≥ 1` and real parameter `κ ≥ 1`, the precision class is

\[
\mathcal A_{d,\kappa}=\{A\in\mathbb R^{d\times d}:A=A^\top,\ I_d\preceq A\preceq\kappa I_d\}.
\]

The normalized lower and upper spectral bounds are 1 and κ. A is the **precision**, and the centered target covariance is A⁻¹. The potential is `f_A(x)=xᵀAx/2`, the target is `π_A=N(0,A⁻¹)`, and the exact first-order oracle at arbitrary `x ∈ ℝᵈ` returns `(xᵀAx/2, Ax)` (Eq. 1). Exact gradient/matrix-vector replies and exact value-plus-gradient replies simulate each other with one reply because the value is `⟨x,Ax⟩/2`. This statement does not concern value-only, noisy, rounded or finite-bit access, nor computational time/bit complexity.

A randomized adaptive algorithm chooses queries and stopping decisions as Borel functions of internal randomness and previous replies. The seed is independent of the input. Its output may be **any** ℝᵈ-valued Borel function of this information; it is not required to lie in the span of queries/replies. A fixed query budget T is an upper bound on the number of queries for **every** admissible input and **every** seed realization. It is a deterministic per-run cap, not an expected number of queries or a high-probability budget.

TV is `sup_B |P(B)-Q(B)| = (1/2)∫|p-q|dλ`, with measurable B and any common dominating λ. The source's bounded-test inequality is for measurable `0 ≤ h ≤ 1`, with constant 1 in `|E_P h-E_Q h| ≤ TV(P,Q)`; using `|h|≤1` would require a different normalization/constant. `ρ_A^Alg` is the output **law**, already averaged over all internal randomness for fixed A.

For `0<ε<1`, Eq. 2 defines `Q_G(d,κ,ε)` as the infimum over **integer** `T ≥ 0` for which **there exists one** randomized algorithm of fixed budget T with `sup_{A∈𝒜} TV(ρ_A^Alg,π_A) ≤ ε`. The uniform input quantifier comes after the choice of the algorithm; it is not a separate algorithm for each input. The paper does not in this section construct a chosen optimizer attaining the infimum or a fallback object when the feasible set is empty. Such semantics would require their own justification in a formal definition.

## S4: hard family and theorem scope

Theorem 4.1 says: for **every fixed** `δ ∈ (0,1)`, **there exists** a threshold `d₀(δ)` such that for **every integer** `d ≥ d₀(δ)`, every `2 ≤ κ ≤ d^(1-δ)`, and every `0 < ε ≤ 1/10`,

\[
Q_G(d,\kappa,\varepsilon)\ge (\delta/256)\sqrt\kappa\log d.
\]

The large-d threshold depends only on δ, uniformly over the κ and ε ranges. The displayed lower-bound coefficient is δ/256; it is not an absolute constant uniform over δ. The bound is independent of ε within the stated interval; the section explicitly does not claim growth as ε→0. Section 4 compares this with Theorem 3.1, but that other theorem's proof was not reviewed here. It says the bound holds even when the algorithm knows the spectrum.

For `d ≥ 2`, `κ ≥ 2`, Eq. 11 fixes, for `i=1,...,d`,

\[
\theta_i=(i-\tfrac12)\pi/d,\quad
\lambda_i=(\kappa+1)/2+(\kappa-1)\cos\theta_i/2,\quad
\Lambda=\operatorname{diag}(\lambda_1,\ldots,\lambda_d).
\]

One draws `O ~ Haar(O(d))` independently of the algorithm's private seed, and sets `A=OΛOᵀ`. The spectrum and therefore the Gaussian normalizing constant are deterministic and may be supplied to the algorithm. The hidden information is the eigenbasis. In particular this is not determinant-sign uncertainty or normalization uncertainty. The target for each fixed O is `N(0,A⁻¹)`. The representation O need not be uniquely recoverable from A; the eventual test is written as a polynomial in A, so it is well defined without choosing a representative.

Remark 4.2 records an exact oracle adapter: if A₂ has the κ=2 grid with the same O, then `A=(κ-1)A₂-(κ-2)I`. One matrix-vector reply in either problem determines its counterpart in the other. This is an affine relation of **precision matrices**, not a claim that the two Gaussian target distributions agree or that an oracle reduction alone proves the lower bound. The remark explains the mechanism: at frequency `n=2q+1` the algorithmic statistic is small, whereas target normalized means have size exponential in `-n/√κ`.

### Lemmas 4.3--4.6 and their separate meanings

For vectors `g₁,...,g_{q+1}`, the block Krylov space is

\[
\mathcal K_q=\operatorname{span}\{\Lambda^j g_a:1\le a\le q+1,\ 0\le j\le q\}.
\]

Lemma 4.3: for integer `q≥0` with `2q+1<d`, the output X of a q-query algorithm has a representation `OᵀX∈𝒦_q` almost surely for **some mutually independent** standard Gaussian vectors `g₁,...,g_{q+1}`. The surrounding proof discussion interprets this on an extension preserving the joint law of (O,X). The source does not assert these g's are independent of (O,X), the original algorithm seed, or the full extended experiment. Polynomial coefficients in `OᵀX=∑_a p_a(Λ)g_a` may depend on the full experiment; each polynomial degree is ≤q. The extra `(q+1)`st start accounts for an output outside the query/reply span. The uniform-in-u estimate is necessary precisely because the coefficients may be adaptive. The proof of this representation is in unread Appendix C.1, and the source credits [22, Lemma 9.2].

For `n=2q+1`, define `D_n=diag(cos(nθ_i))`. The frequency exceeds those in a product of two degree-q cosine polynomials. Lemma 4.4 has an **absolute** `C>0`, independent of κ, with

\[
\tau_{d,q}=C\left[(q+1)\sqrt{\log(d)/d}
+(q+1)(q+1+\log d)\log(d)/d\right].
\]

For the same q condition and independent standard Gaussian starts, **if** `τ≤1/2`, then with probability at least 0.99,

\[
|u^\top D_nu|\le2\tau\|u\|^2\quad\text{simultaneously for every }u\in\mathcal K_q.
\]

This is one common high-probability event for all u, not an individually chosen event for each u. The κ-independence follows from the nonconstant affine relation between λ_i and cos θ_i, giving the same degree-q polynomial span. Applying Lemma 4.3 on that event yields `|XᵀOD_nOᵀX|≤2τ||X||²`. The factor 2 must be preserved. Appendix C.2 is the source proof and was not read in this phase.

Lemma 4.5: `κ≥2`, `U~N(0,Λ⁻¹)`, `ρ=(√κ-1)/(√κ+1)`, integer `1≤n<d`, `D_n=diag(cos(nθ_i))`, `M=E||U||²` and `μ_n=E[UᵀD_nU]`. Then

\[
M={d\over\sqrt\kappa}{1-\rho^{2d}\over1+\rho^{2d}},\qquad
(-1)^n\mu_n={d\over\sqrt\kappa}{\rho^n-\rho^{2d-n}\over1+\rho^{2d}}.
\]

Each of the two variances is at most `2M ≤ 2d/√κ`. **If additionally** `d-n≥√κ`, then

\[
(1-e^{-4})e^{-3n/\sqrt\kappa}
\le |\mu_n|/M\le e^{-2n/\sqrt\kappa}.
\]

The conditional gap assumption is attached to this two-sided exponential assertion, not to the exact means/variance formulas. The normalized quantity here is a **ratio of expectations**, `|E[UᵀD_nU]|/E||U||²`, not `E[|UᵀD_nU|/||U||²]` and not an almost-sure target bound. No need to substitute the special odd n into this general-integer moment lemma. For `Y|O~π_A`, rotation gives `U=OᵀY~N(0,Λ⁻¹)` and preserves the norm/statistic. This conditional target statement differs from the distribution of algorithm output X.

Lemma 4.6: **every** `O∈O(d)` gives `I≤OΛOᵀ≤κI`. This is the admissibility input consumed by the uniform TV hypothesis. Appendix C.4 is its unread proof; the inequalities are consistent with `0<θ_i<π` and the source's grid. The source section does not replace admissibility by a new hypothesis on a particular random input.

### S4.3: the actual sufficient route

The proof assumes a **single** algorithm with `q≤(δ/256)√κ log d` and per-input TV ≤ε on the full admissible class. It chooses `n=2q+1`, `τ=τ_{d,q}` and the polynomial test

\[
S_A(x)=(-1)^n x^\top T_n\!\left({2A-(\kappa+1)I\over\kappa-1}\right)x-2\tau\|x\|^2,
\quad E_A=\{x:S_A(x)>0\}.
\]

T_n is the first-kind Chebyshev polynomial. Spectral evaluation converts its first quadratic form to `(-1)^n xᵀOD_nOᵀx`. This test is a Borel event for each A. Its definition treats x=0 without a ratio, giving S_A(0)=0; the energy-weight interpretation `w_i=|⟨x,Oe_i⟩|²/||x||²` is explicitly only for x≠0. The test need not be evaluated by the algorithm: it is a mathematical distinguisher for the TV argument.

Algorithm branch: the κ bound and q bound give `q+1≤d^((1-δ)/2)log d`, `n=o(d)`, and

\[
\tau\lesssim d^{-\delta/2}(\log d)^{3/2}+d^{-\delta}(\log d)^3
\lesssim d^{-\delta/2}(\log d)^3\to0.
\]

For sufficiently large d depending only on δ, n<d and τ≤1/2. Lemmas 4.3 and 4.4 therefore imply `E_A` fails for X except with probability ≤0.01, so `E_A[ρ_A^Alg(E_A)]≤0.01`. This is averaged over the random hard input; it is not a bound for every fixed A's output law.

Target branch: `n=o(d)` and `√κ=o(d)` ensure `d-n≥√κ`. Put `β=|μ_n|/M`. Lemma 4.5 and the q bound imply

\[
\beta\ge b d^{-\delta/4},\quad b=(1-e^{-4})e^{-3}>0.
\]

The source uses `3n/√κ≤3+(3δ/128)log d`. Its weaker `ρ≤e^{-1/√κ}` and `d≥√κ` give `ρ^(2d)≤e^-2<1/3`, hence `M≥d/(2√κ)≥d^((1+δ)/2)/2`. Thus

\[
\tau/\beta\le(C'/b)d^{-\delta/4}(\log d)^3\to0,
\quad M\beta^2\ge(b^2/2)\sqrt d\to\infty.
\]

One chooses a common d₀(δ) making all earlier conditions true and `τ≤β/4`, `Mβ²≥320`. These are proof estimates produced by prior lemmas/asymptotics, not added public hypotheses of Theorem 4.1. The source provides asymptotic existence rather than a numerical formula for d₀.

For **every fixed hard input** A, draw Y from its target and let Z=S_A(Y). Its mean satisfies `EZ=(β-2τ)M≥βM/2`. The L² triangle inequality for **centered** variables gives `Var(Z)≤(√(2M)+2τ√(2M))²≤8M`; no independence of the norm statistic and cosine statistic is asserted. Chebyshev gives `π_A(E_A)≥1-32/(Mβ²)≥0.9`. The signed mean is positive because `(-1)^n μ_n>0`, not because μ_n itself is always positive.

The final TV step is per-input `π_A(E_A)-ρ_A^Alg(E_A)≤ε`, averaged over A. It combines the branches into `0.89≤E_A[π_A(E_A)-ρ_A^Alg(E_A)]≤ε≤0.1`, contradiction. The source route is an AND of admissibility, representation/uniform concentration and target moments/probability; it does not treat these as alternative sufficient proofs. No stronger conclusion for an expected-budget algorithm, an algorithm on only one A, or ε→0 follows from this argument.

### S4.4: limitations are about this proof

Lemma 4.7 asserts for every integer q≥0 and mutually independent Gaussian starts that `dim 𝒦_q=min{d,(q+1)²}` almost surely, using distinct λ_i. The read S4 slice contains no proof of this dimension assertion. This is an asserted source dependency, not something validated by a current Lean theorem or by reading the rest of C; its proof status outside this slice is unknown.

Once `(q+1)²≥d`, 𝒦_q=ℝᵈ a.s. If additionally `n=2q+1<d`, the grid identity gives `∑_i cos²(nθ_i)=d/2`; hence one coordinate has absolute weight ≥1/√2, so the uniform normalized quadratic-form supremum is ≥1/√2. This prevents a useful uniformly small bound of the kind required by the test once the Krylov space fills the space. The prose says the separating test requires the supremum at most 1/2; the actual Lemma 4.4 conclusion is `≤2τ`, and the theorem proof later enforces much smaller τ. These numerical roles must not be silently identified. The κ scale mentioned is `κ≳d/log²d` with q of order √κ log d. This is a limitation of the enlarged-space method, not a theorem that the fixed-spectrum family is easy or that all possible lower bounds stop there.

For accuracy, a threshold t must satisfy `a≤t<β`, where a is the uniform algorithm bound. The source appeals to the Bernstein calculation of **Fact C.6** for the methodological requirement `a≥c/√d` merely to certify failure probability <1. Fact C.6 lies in unread C.2; this invocation is retained as an unreviewed internal dependency. Combining it with `β≤e^{-2(2q+1)/√κ}` gives `q=O(√κ log d)`, independent of ε. Retuning this threshold/constants cannot yield accuracy growth through the same certificate. This is not an information-theoretic upper bound on query complexity or a refutation of stronger fixed-spectrum lower bounds. Remark 4.8 explicitly leaves that stronger-family question open.

## C.3: exact source proof of target moments

C.3 inherits the grid and `κ≥2` domain from Lemma 4.5. It uses `0<ρ<1`. Fact C.7 states, **for every real θ**, the absolutely and uniformly convergent expansion

\[
{2\over\kappa+1+(\kappa-1)\cos\theta}
={1\over\sqrt\kappa}\left(1+2\sum_{j\ge1}(-\rho)^j\cos(j\theta)\right).
\]

The left side is the inverse eigenvalue at θ. It is not a finite truncation or an asymptotic approximation. The proof is geometric-series summation with complex exponentials, giving

\[
1+2\sum_{j\ge1}(-\rho)^j\cos(j\theta)
={1-\rho^2\over1+2\rho\cos\theta+\rho^2}.
\]

The parameter identities are `(1-ρ)/(1+ρ)=1/√κ` and `(1+2ρ cosθ+ρ²)/(1-ρ)²=(κ+1+(κ-1)cosθ)/2`. Combining them gives the normalization in C.7. The bound `∑_{j≥1}|(-ρ)^j cos(jθ)|≤ρ/(1-ρ)` is uniform in θ, but **not** uniform in κ→∞. Fixing κ leaves a convergent geometric majorant. The proof invokes standard geometric series, complex exponential algebra and the uniform majorant criterion; their exact formal-library counterparts have not been inspected. There is no bibliographic citation in C.3 for them.

Fact C.8 starts with the exact grid identity for **every integer k**:

\[
\sum_{i=1}^d\cos(k\theta_i)=
\begin{cases}d(-1)^a&k=2ad,\ a\in\mathbb Z,\\0&k\notin2d\mathbb Z.\end{cases}
\]

The nonmultiple case uses `sin(kπ)/(2 sin(kπ/(2d)))=0`; the denominator is nonzero precisely under that case. For k=2ad every cosine equals (-1)^a. Negative k and k=0 are covered by the stated integer quantifier. This is aliasing on a **finite midpoint grid**, not continuous cosine orthogonality.

Gaussian coordinate second moments give `M=∑1/λ_i`, `μ_n=∑cos(nθ_i)/λ_i`. Absolute convergence from C.7 justifies interchanging its infinite series with the finite grid sum. For M, only j=2ad with a≥1 survives, leaving `1+2∑_{a≥1}(-1)^aρ^(2ad)` and its alternating geometric sum. This produces the exact `(1-ρ^(2d))/(1+ρ^(2d))` finite-d correction.

For μ_n, `∑cos(nθ_i)=0` for `1≤n<d`, and product-to-sum produces the two sums at frequencies j-n and j+n. The surviving **disjoint** classes are j=n; j=2ad+n, a≥1; j=2ad-n, a≥1. Their disjointness and positivity of these j values use `1≤n<d`. The sign is `(-ρ)^(2ad±n)=(-1)^nρ^(2ad±n)`. Summing the two alias tails gives the exact signed formula with `ρ^n-ρ^(2d-n)` and denominator `1+ρ^(2d)`. The alias correction cannot be dropped as if the grid were continuous.

The proof of Lemma 4.5 then uses diagonal covariance to obtain independent U_i. Each has variance 1/λ_i and fourth moment 3/λ_i², so `Var(U_i²)=2/λ_i²`. Since λ_i≥1, independence gives

\[
\operatorname{Var}(\|U\|^2)=2\sum_i\lambda_i^{-2}\le2M,\quad
\operatorname{Var}(U^\top D_nU)=2\sum_i\cos^2(n\theta_i)\lambda_i^{-2}\le2M.
\]

The formula for M yields `M≤d/√κ`. These are finite Gaussian moment identities with integrability supplied by Gaussianity, not extra premises that a source-facing statement may require from the caller. Variance of the weighted statistic is bounded despite cosines having either sign.

For the bias, n<d and 0<ρ<1 imply `(-1)^nμ_n>0` and M>0. Division gives

\[
\beta={|\mu_n|\over M}
=\rho^n{1-\rho^{2(d-n)}\over1-\rho^{2d}},\qquad
1-\rho^{2(d-n)}\le {1-\rho^{2(d-n)}\over1-\rho^{2d}}\le1.
\]

The positivity/order of the denominator and exponents is substantive; n=0, n=d and κ=1 are outside the lemma's stated domain. The proof next writes

\[
\log(1/\rho)=2\int_0^{1/\sqrt\kappa}{dt\over1-t^2}
={2\over\sqrt\kappa}+2\int_0^{1/\sqrt\kappa}{t^2\over1-t^2}\,dt.
\]

The residual integral is nonnegative and, since κ≥2,

\[
{2\over\sqrt\kappa}\le\log(1/\rho)
\le {2\over\sqrt\kappa}\left(1+{1\over3(\kappa-1)}\right)
\le{8\over3\sqrt\kappa}<{3\over\sqrt\kappa}.
\]

Thus `e^(-3n/√κ)≤ρ^n≤e^(-2n/√κ)`. If `d-n≥√κ`, then `ρ^(2(d-n))≤e^(-4(d-n)/√κ)≤e^-4`. The preceding exact ratio bound yields the final two-sided β estimate, with `1-e^-4` absolute and exponents 3 and 2 absolute. The κ≥2 restriction enters the coarse upper bound on the logarithm; no source correction to κ>1 is being asserted even where an isolated earlier formula would remain valid more broadly.

## Bibliography [22], dependency boundaries and freeze meaning

The displayed [22] is **OpenAI (2026), Subpolynomial query complexity for well-conditioned log-concave sampling**, an OpenAI Math Release preprint, with a link to the September-26-2026 article in the `openai/math` repository. Its actual DOM entry is `bib.bib3`, not `bib.bib22`.

Within the read S4 slice it is used at four citation occurrences: the opening κ=2 lower-bound attribution; the Section 9.2 construction provenance; Remark 4.2's κ=2 comparison; and the deferred-rotation argument credited to Lemma 9.2. These are distinct consumer uses. The bibliography does not establish the external theorem's exact assumptions, lemma numbering, proof, pinned upstream revision, or applicability adapter. All remain uncertified outside cited-paper content. No OpenAI upstream theorem was used as admitted mathematical truth here.

Unread internal proof dependencies are C.1 for 4.3, C.2 for 4.4 and Fact C.6, and C.4 for 4.6. Lemma 4.7's proof is absent from the inspected S4 text and not checked elsewhere. Standard Gaussian fourth moments/independence, finite cosine product identities, geometric sums, basic log/integral identities, L² triangle inequality, Chebyshev and uniform-majorant facts occur as ordinary unnamed source ingredients. The inventory retains their use sites; this phase has not verified compiled versions of them. No concrete mathematical counterexample or independently demonstrated false statement was found in the read formulas, but that observation is neither a proof audit of unread sections nor a source-fidelity verdict on any candidate.

This freeze is an original source account plus exhaustive extracted-unit coverage for a bounded slice. It does not accept any implementation, authored exposition, source graph, semantic slot comparison or repair overlay. Such judgments require the separately authorized later candidate projection, with this cognition left unchanged.
