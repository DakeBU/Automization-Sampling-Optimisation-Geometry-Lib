"""Freeze/syntax-check v5 successor inputs only. No Chrome, server, render, or API."""
import ast,datetime as dt,hashlib,json,os,subprocess,sys,time,traceback
from html.parser import HTMLParser
from pathlib import Path
OWN=Path(__file__).resolve().parent;REPO=OWN.parents[2];OLD=OWN.parent/'matrix_domain_reader_61e4'
W17=REPO/'.astis/huanjian-gc-matrix-mgf-domain-20261115';PREVIEW=W17/'reader-preview-v1/static-closure-v5';PREDECESSOR=PREVIEW.parent/'static-closure-v3'
DELIVERY=W17/'metadata-drafts/reader-ui-repair-v4/STATIC-UI-V5-DELIVERY.json';SELECTION=DELIVERY.parent/'candidate-served.selection.v5.json'
NODE=REPO/'.astis/huanjian-gc-integration-20261105/browser-venv/lib/python3.12/site-packages/playwright/driver/node'
PYTHON=REPO/'.astis/huanjian-gc-integration-20261105/browser-venv/bin/python'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,x):
    with Path(p).open('x') as f:f.write(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
class Node:
    def __init__(self,t='',a=()):self.tag=t;self.attrs=dict(a);self.children=[]
    def text(self):return ''.join(x if isinstance(x,str) else x.text() for x in self.children)
    def has(self,c):return c in self.attrs.get('class','').split()
    def find(self,p):
        out=[]
        for x in self.children:
            if isinstance(x,Node):
                if p(x):out.append(x)
                out.extend(x.find(p))
        return out
class Parse(HTMLParser):
    def __init__(self,s):super().__init__(convert_charrefs=True);self.root=Node();self.stack=[self.root];self.feed(s)
    def handle_starttag(self,t,a):
        n=Node(t,a);self.stack[-1].children.append(n)
        if t not in {'area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr'}:self.stack.append(n)
    def handle_endtag(self,t):
        for i in range(len(self.stack)-1,0,-1):
            if self.stack[i].tag==t:self.stack=self.stack[:i];break
    def handle_data(self,s):self.stack[-1].children.append(s)
def main():
    checks=[]
    def check(n,ok,detail=None):
        checks.append({'name':n,'pass':bool(ok),'detail':detail})
        if not ok:raise AssertionError(n)
    check('v5-delivery-exact-pin',sha(DELIVERY)=='87d41b69b7d6d864188431c09b1b27165707b08a54204dde730d1b6d9a6eaad8')
    check('v5-manifest-exact-pin',sha(PREVIEW/'preview-freeze-manifest.json')=='08e7fdb3607a2330623fb5c68aee4e7e50c61e3a77aa2029846180312b455b61')
    check('v5-selection-exact-pin',sha(SELECTION)=='b110fd48bf9c2e952134f58633bd28cab1597c4c242043e5d5fa02a14cb00742')
    delivery=json.loads(DELIVERY.read_text());selection=json.loads(SELECTION.read_text());m=json.loads((PREVIEW/'preview-freeze-manifest.json').read_text())
    check('all-explicit-delivery-file-pins',all(sha(REPO/r['path'])==r['sha256'] and (REPO/r['path']).stat().st_size==r['bytes'] for r in delivery['files']))
    fixture=PREVIEW/'fixtures/candidate';snapshot=PREVIEW/'input-snapshot';rows=m['variants']['candidate']['files']
    check('candidate110-selection-manifest-and-file-set-exact',len(rows)==110 and rows==selection['files'] and {str(p.relative_to(fixture)) for p in fixture.rglob('*') if p.is_file()}=={r['path'] for r in rows})
    for row in rows:check('actual-candidate-byte-pin:'+row['path'],sha(fixture/row['path'])==row['sha256'] and (fixture/row['path']).stat().st_size==row['bytes'])
    frozen=json.loads((PREVIEW/'input-freeze-manifest.json').read_text())
    check('frozen-input-snapshot-hash-unchanged',sha(PREVIEW/'input-freeze-manifest.json')==sha(PREDECESSOR/'input-freeze-manifest.json')=='deca5e55a617ce67f22a3cac687eb1140e1ec654e92380c612a177996ce1d219')
    check('all-explicit-snapshot-leaves-exact',all(sha(snapshot/r['path'])==r['sha256'] for r in frozen['files']))
    old=json.loads((PREDECESSOR/'preview-freeze-manifest.json').read_text());delta=[];count=0
    for variant,v in m['variants'].items():
        check(variant+'-v3-v5-same-served-path-set',{r['path'] for r in v['files']}=={r['path'] for r in old['variants'][variant]['files']})
        for row in v['files']:
            before=PREDECESSOR/'fixtures'/variant/row['path'];after=PREVIEW/'fixtures'/variant/row['path'];count+=1
            if before.read_bytes()!=after.read_bytes():delta.append(variant+'/'+row['path'])
    check('actual219-v3-v5-only-one-scoped-CSS-byte-delta',count==219 and delta==['candidate/assets/mgf-reader-overlay.css'],{'actual_served_files_compared':count,'actual_deltas':delta})
    old_css=(PREDECESSOR/'fixtures/candidate/assets/mgf-reader-overlay.css').read_text();new_css=(fixture/'assets/mgf-reader-overlay.css').read_text()
    suffix='''/* Bound the actual module grid track and its intrinsic-size grid item. */
body[data-mgf-preview="huanjian-matrix-mgf-domain"][data-preview-variant="candidate"] .declaration-list {
  grid-template-columns: minmax(0, 1fr);
}
body[data-mgf-preview="huanjian-matrix-mgf-domain"][data-preview-variant="candidate"] .declaration-list > details.declaration {
  min-width: 0; max-width: 100%;
}

'''
    check('CSS-exact-minimal-grid-append-no-other-change',new_css==old_css+suffix)
    check('original-geometry-byte-exact',sha(OWN/'browser_geometry.py')==sha(OLD/'browser_geometry.py')=='cc7eb67308d24fd5dbf87345b9e48ac1140ff7879bb05a96e08bc01a13d9efd4')
    check('original-runner-preserved',sha(OLD/'browser_check.py')=='64101b5e78fe02d97a92650ff397750d387811a576f4932743972c682e183f94')
    check('new-runner-helper-pins',sha(OWN/'browser_check.py')=='bea9db797093f7cb14fc32c01d6894984c3ee1f2dd264dc440ec130d431798f7' and sha(OWN/'browser_anchor_wait.py')=='6b29bfff8201a6cb34503c0de8de5da1cf84b4285be104074f38254b51f6ec96')
    runner=(OWN/'browser_check.py').read_text();old_runner=(OLD/'browser_check.py').read_text()
    predicates=["page.url.endswith(raw+'.html#L'+str(first)) and g['positive'] and g['top']>=g['header']-1","g['positive'] and g['top']>=g['header']-1"]
    check('all-original-strict-anchor-predicates-literal-unchanged',all(x in runner and x in old_runner for x in predicates))
    check('generic-natural-wait-calls-all-existing-source-readability-sites',runner.count('settling=wait_for_natural_anchor(')==2 and runner.count('natural-source-anchor-stable')==2)
    names={};tree=ast.parse(runner)
    for n in tree.body:
        if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id in ['ITEM','PFILE','TFILE','P','T','PSD','TRACE','SOURCES']:names[n.targets[0].id]=eval(compile(ast.Expression(n.value),'<pure checker constants>','eval'),{'__builtins__':{}},names)
    unit=json.loads((snapshot/'website/content/declaration_lessons/huanjian-matrix-mgf-domain.json').read_text())['units'][0]
    dom=Parse((fixture/m['variants']['candidate']['proof_path']).read_text()).root;steps=dom.find(lambda n:n.tag=='details' and n.has('proof-reader-step'))
    check('five-adjacent-262-lines-P-P-T-T-T-exact',len(steps)==5 and [s.find(lambda n:n.tag=='pre')[0].text() for s in steps]==[s['lean'] for s in unit['steps']] and ''.join(s['lean'] for s in unit['steps'][:2]).encode()==(snapshot/names['PFILE']).read_bytes() and ''.join(s['lean'] for s in unit['steps'][2:]).encode()==(snapshot/names['TFILE']).read_bytes())
    for label,raw,decl,anchor,lines in names['SOURCES']:
        source=Parse((fixture/('data/lesson-sources/'+raw+'.html')).read_text()).root
        check(label+'-full-source-and-download-byte-exact',source.find(lambda n:n.tag=='pre')[0].text().encode()==(snapshot/raw).read_bytes()==(fixture/('downloads/lean/'+raw)).read_bytes() and len((snapshot/raw).read_text().splitlines())==lines)
    expressions=[];geometry={};helper={}
    for filename in ['browser_check.py','browser_geometry.py','browser_anchor_wait.py']:
        parsed=ast.parse((OWN/filename).read_text(),filename=filename);check(filename+'-Python-AST',True)
        for n in parsed.body:
            if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and isinstance(n.value,ast.Constant) and isinstance(n.value.value,str):
                if filename=='browser_geometry.py' and n.targets[0].id in ['GEOMETRY','VISIBLE','GLYPH']:geometry[n.targets[0].id]=n.value.value;expressions.append((filename,n.value.value))
                if filename=='browser_anchor_wait.py' and n.targets[0].id=='OBSERVE_TEMPLATE':helper['OBSERVE_TEMPLATE']=n.value.value
        if filename=='browser_check.py':
            for n in ast.walk(parsed):
                if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr in ['evaluate','evaluate_all','wait_for_function'] and n.args and isinstance(n.args[0],ast.Constant) and isinstance(n.args[0].value,str):expressions.append((filename,n.args[0].value))
    expressions.append(('generic-natural-anchor-observer-composed',helper['OBSERVE_TEMPLATE'].replace('$VISIBLE$',geometry['VISIBLE'])))
    for i,(filename,s) in enumerate(expressions):
        r=subprocess.run([str(NODE),'--check'],input='('+s+');',capture_output=True,text=True)
        check(filename+'-JS-syntax-'+str(i),r.returncode==0,{'actual_exit_code':r.returncode,'stdout':r.stdout,'stderr':r.stderr})
    check('observer-has-no-scroll-style-transform-animation-write',not any(x in helper['OBSERVE_TEMPLATE'] for x in ['scrollIntoView','scrollTo(','scrollBy(','style.','setAttribute(']))
    original_assignment=json.loads((OLD/'execution-assignment.json').read_text());check('current-Chrome-binary-pin',sha(original_assignment['chrome']['path'])==original_assignment['chrome']['binary_sha256'])
    pins=[DELIVERY,SELECTION,PREVIEW/'preview-freeze-manifest.json',PREVIEW/'input-freeze-manifest.json',PREVIEW/'render_preview.py',PREVIEW/'reader_overlay.py',snapshot/'website/content/declaration_lessons/huanjian-matrix-mgf-domain.json',snapshot/'website/content/publications/huanjian-matrix-mgf-domain.json',fixture/'data/underlying-lean-graph.json',OWN/'browser_anchor_wait.py',*[snapshot/s[1] for s in names['SOURCES']]]
    draft={'authorization':'PREPARED_ONLY_AWAIT_ROOT_FRESH_SCOPED_APPROVAL','preview_root':str(PREVIEW),'runner_sha256':sha(OWN/'browser_check.py'),'geometry_sha256':sha(OWN/'browser_geometry.py'),'anchor_wait_sha256':sha(OWN/'browser_anchor_wait.py'),'preview_manifest_sha256':sha(PREVIEW/'preview-freeze-manifest.json'),'source_reviewed_publication_binding_sha256':'5e79fa3d4390c4d1e689174b0c014d67fb8dbfb550f986b4af7d8474ef644691','actual_source_review_run_sha256':'1b2e4964109b4ca0c495f9ad2ecf50ed7f1508adfe38370487a182ad5fc9466a','frozen_inputs':[{'path':str(p),'sha256':sha(p)} for p in pins],'lesson_sha256':m['lesson_sha256'],'publication_sha256':m['publication_sha256'],'chrome':original_assignment['chrome'],'execution_custody':'ROOT must independently review the new exact checker/helper and v5 static CSS-only fixture, create a distinct actual assignment, and request fresh scoped approval. No old approval or acceptance inherited.','previous_FAIL_result_sha256':'74fd21200be988619c1ff27fd253049cc84c96641461aaf3fb54ca52beb9384f','observational_diagnostic_sha256':'f5774f5c3c4f2b04b375b934c700de93b2fa17e9a54cf8a57648dc095a68a9f2','independent_diagnosis_sha256':'03a48583970387e6b52549534c5bfa98ec8be0f40e551e4899682d67109420e6'}
    write(OWN/'execution-assignment.draft.json',draft)
    schema=json.loads((OLD/'execution-assignment.schema.json').read_text());schema['title']='R17 distinct successor actual isolated-v5-reader assignment';schema['required'].append('anchor_wait_sha256');schema['properties']['anchor_wait_sha256']={'type':'string','pattern':'^[0-9a-f]{64}$'};schema['$comment']='Distinct actual assignment plus fresh scoped approval for new successor runner/helper and v5 CSS-only fixture. Original FAIL and actual diagnostic remain independent historical records.';write(OWN/'execution-assignment.schema.json',schema)
    check('no-runtime-Chrome-server-render-API-executed',not any((OWN/p).exists() for p in ['runtime-process','runtime-output','actual-result.json','chrome-tmp','execution-assignment.json']))
    report={'schema':'R17-v5-independent-successor-preparation-v1','status':'PREPARED_ONLY_NO_BROWSER','checks':checks,'runner_sha256':draft['runner_sha256'],'geometry_sha256':draft['geometry_sha256'],'anchor_wait_sha256':draft['anchor_wait_sha256'],'draft_assignment_sha256':sha(OWN/'execution-assignment.draft.json'),'schema_sha256':sha(OWN/'execution-assignment.schema.json'),'v5_manifest_sha256':draft['preview_manifest_sha256'],'JavaScript_syntax_checks':len(expressions),'actual_v3_v5_served_bytes_compared':219,'actual_delta_only':'candidate/assets/mgf-reader-overlay.css','source_semantics_or_math_reaudit_claim':False,'actual_original_501_3false_exit1_unchanged':True,'actual_diagnostic_not_reader_acceptance':True,'runtime_delta':'All22 source-anchor readability measurements observe natural window/pre/target/header-clip geometry until4stable samples100ms apart within.25CSSpx, min500ms/deadline5s; separate stability check, then original strict visibility/header predicate literally unchanged. Full immediate/settled traces preserved; no target scroll or animation disabling. Original non-anchor interactions and all glyph/graph thresholds unchanged.','actual_expected_screenshot_scope':'Same meaningful original50 states; no optional crops. Actual count and all false flags will be reported and original PNGs must be independently viewed after a separately authorized run.','truth_boundary':'Headless1440x1000 and390x844 CSS viewports, not physical touch, production site, source-fidelity review, Lean rebuild, PL or V. New runtime pending.','concrete_planned_invocation':[str(PYTHON),str(OWN/'browser_check.py'),'--preview-root',str(PREVIEW),'--assignment',str(OWN/'execution-assignment.json')]}
    write(OWN/'preparation-result.json',report)
    print(json.dumps({'status':report['status'],'checks':len(checks),'JS_syntax_checks':len(expressions),'runner_sha256':draft['runner_sha256'],'anchor_wait_sha256':draft['anchor_wait_sha256'],'draft_assignment_sha256':report['draft_assignment_sha256'],'preparation_result_sha256':sha(OWN/'preparation-result.json')}))
if __name__=='__main__':
    p=OWN/'static-process';p.mkdir(exist_ok=False)
    for fd,n in [(1,'stdout.raw'),(2,'stderr.raw')]:
        f=(p/n).open('xb',buffering=0);os.dup2(f.fileno(),fd);f.close()
    utc=dt.datetime.now(dt.timezone.utc).isoformat();start=time.monotonic();code=0
    try:main()
    except BaseException:traceback.print_exc();code=1
    sys.stdout.flush();sys.stderr.flush()
    write(p/'receipt.json',{'schema':'R17-actual-v5-successor-static-preparation-OS-receipt-v1','argv':[sys.executable,*sys.argv],'cwd':str(Path.cwd()),'pid':os.getpid(),'started_utc':utc,'ended_utc':dt.datetime.now(dt.timezone.utc).isoformat(),'elapsed_seconds':time.monotonic()-start,'actual_exit_code':code,'script_sha256':sha(__file__),'stdout_sha256':sha(p/'stdout.raw'),'stderr_sha256':sha(p/'stderr.raw'),'no_Chrome_browser_server_render_API':True})
    sys.exit(code)
