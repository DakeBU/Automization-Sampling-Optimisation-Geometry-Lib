from pathlib import Path
import hashlib
import json
from bs4 import BeautifulSoup

ROOT = Path('/Users/zhouhuanjian/ASTIS-GC')
SOURCE = ROOT / '.astis/huanjian-resume-20261103/2610.20492v1.html'
OUT = ROOT / 'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-admissibility-semantic-evidence/source-only-review/phase1'
EXPECTED = '6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'

def normalized(tag):
    clone = BeautifulSoup(str(tag), 'html.parser')
    for math in clone.find_all('math'):
        math.replace_with(' $' + math.get('alttext', math.get_text(' ', strip=True)) + '$ ')
    return ' '.join(clone.get_text(' ', strip=True).split())

if __name__ == '__main__':
    raw = SOURCE.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == EXPECTED
    soup = BeautifulSoup(raw, 'html.parser')
    OUT.mkdir(parents=True, exist_ok=True)
    ids = ['S1', 'S2', 'S4', 'A3.SS4']
    records = []
    for source_id in ids:
        tag = soup.find(id=source_id)
        assert tag is not None
        html = str(tag).encode()
        (OUT / ('raw-' + source_id + '.html')).write_bytes(html)
        blocks = []
        for x in tag.find_all(['p', 'table', 'tbody', 'figcaption', 'h2', 'h3', 'h4', 'h5', 'h6']):
            if x.name == 'p' and x.find_parent('table'):
                continue
            if x.name in ['table', 'tbody'] and not x.get('id'):
                continue
            if x.name == 'table' and x.find('tbody', id=True):
                continue
            blocks.append({'id': x.get('id'), 'kind': x.name, 'text': normalized(x)})
        (OUT / ('source-' + source_id + '.json')).write_text(json.dumps(blocks, ensure_ascii=False, indent=2) + '\n')
        records.append({'id': source_id, 'serialized_subtree_sha256': hashlib.sha256(html).hexdigest(), 'block_count': len(blocks)})
    (OUT / 'raw-inputs.json').write_text(json.dumps({'source_path': str(SOURCE.relative_to(ROOT)), 'source_sha256': EXPECTED, 'source_bytes': len(raw), 'serialization_note': 'raw-*.html are BeautifulSoup serialized exact selected source DOM subtrees; the full original file hash is authoritative.', 'selected_subtrees': records}, ensure_ascii=False, indent=2) + '\n')
