"""Retain first failed test harness; fix only CLM implicit parameters in a successor."""
import json
from native_common import *

def main():
    original=json.loads((OWN/'native-assignment.json').read_text())
    for row in original['inputs']:assert file_sha(OWN/row['path'])==row['sha256']
    receipts=[json.loads(p.read_text()) for p in (OWN/'command-receipts').glob('*.receipt.json')]
    assert all(any(r['label']==f'compile-{i:02d}' and r['exit_code']==0 for r in receipts) for i in range(11))
    assert any(r['label']=='literal-types-and-boundaries' and r['exit_code']==1 for r in receipts)
    harness=OWN/'harness-v2';harness.mkdir(exist_ok=False)
    source=(OWN/'harness/NativeLiteralApplications.lean').read_text()
    assert source.count('Matrix.toEuclideanCLM A')==1 and source.count('Matrix.toEuclideanCLM mixed')==4
    corrected=source.replace('Matrix.toEuclideanCLM A','(Matrix.toEuclideanCLM (𝕜 := ℝ) (n := ι)) A').replace('Matrix.toEuclideanCLM mixed','(Matrix.toEuclideanCLM (𝕜 := ℝ) (n := Fin 2)) mixed')
    (harness/'NativeLiteralApplications.lean').write_text(corrected)
    for name in ['NativeAudit.lean','NativeTransitiveGraph.lean']:(harness/name).write_bytes((OWN/'harness'/name).read_bytes())
    packages=json.loads((OWN/'verified-package-inputs.json').read_text())
    env=lean_env(packages['packages']);flags=[str(LEAN),'-DmaxRecDepth=32768','-DmaxHeartbeats=0','-Ddebug.skipKernelTC=false']
    commands=[{'id':'literal-types-and-boundaries-v2','argv':flags+['-o',str(OUT/'NativeLiteralApplications.olean'),str(harness/'NativeLiteralApplications.lean')]},{'id':'lossless-raw-type-value-kernel-v2','argv':flags+['--run',str(harness/'NativeAudit.lean')]},{'id':'complete-recursive-type-value-graph-v2','argv':flags+['--run',str(harness/'NativeTransitiveGraph.lean')]}]
    write_json(OWN/'native-successor-commands.json',commands)
    pinned=list(harness.iterdir())+[p for p in OUT.rglob('*') if p.is_file()]+[OWN/'native-assignment.json',OWN/'native-successor-commands.json',OWN/'run_successor.py']
    assignment={'candidate_commit':COMMIT,'reason':'Only extra private explicit L2-operator/mixed-spectrum test needed named 𝕜 and n parameters to coerce Matrix.toEuclideanCLM. Production source and already independently compiled ASTIS modules unchanged.','inputs':[{'path':str(p.relative_to(OWN)),'sha256':file_sha(p)} for p in pinned]}
    write_json(OWN/'native-successor-assignment.json',assignment)
    for command in commands:
        for row in assignment['inputs']:assert file_sha(OWN/row['path'])==row['sha256']
        print(json.dumps({'actual_successor_started':command['id']}),flush=True)
        run(command['id'],command['argv'],cwd=harness,env=env)
    write_json(OWN/'native-sequence.completed.json',{'candidate_commit':COMMIT,'ASTIS_modules_freshly_recompiled':11,'first_private_harness_failure_retained':True,'all_successor_actual_commands_exit_zero':True})

if __name__=='__main__':main()
