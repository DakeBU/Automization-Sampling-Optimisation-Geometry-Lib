# Phase 2a: independent exact-type, binder and definition audit

Decision: the selected P and T signatures are mathematically consistent with the bounded source components identified in the independently frozen Phase 1 baseline. No EXCESS public premise is present. This is approval of the selected *typed mathematical scope and literal object semantics only*, not proof approval, source-graph approval, verification of a compiled theorem, or confirmation of an actual compiled dependency. The input explicitly reports literal Prop formation only and `target_theorem_compiled=false` for both declarations. No target implementation or external theorem proof body was read or run.

P is `AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumKrylovRange.actual_cosine_feature_krylov_range`, planned in `AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumKrylovRange.lean`, signature SHA256 `4d5056d57aa0536b95af7aa9f7c3b6860ab7c9652b0bb306b6bad42434235ab6`.

T is `AutoSamplingTheory.Tests.GaussianComplexityFixedSpectrumKrylovRange.actual_krylov_quadratic_coordinates`, planned in `Tests/GaussianComplexityFixedSpectrumKrylovRange.lean`, signature SHA256 `082eda7b36ecff3e87a62358e4f234b6d6c129b491405de3761fa83f79412969`.

The selective input's raw SHA256 is `471d8f4351d80f33d478049a0a2d8716689b2140c043aa324d8132f9b3fb79cb`. Full-seal bytes were hashed only to `f47e23a601d1a8e0ff4760224676313e0f1999877a97156841a65c01847e5d82`; a whitelist extracted only name, planned_file, signature and signature_sha256 from its designated producer and actual_private_consumer objects. All eight corresponding fields match. No root binder audit, root planning/status narrative, proposed SG, old reviewer material, or root proof plan was exposed to this judgment.

## Every logical input

The same outer binders occur in P and T.

| Binder | Class | Independent source and mathematical judgment |
|---|---|---|
| `{d : ℕ}` | TYPING | Finite spatial dimension; original source uses d >= 2. The explicit source inequality hq below implies d >= 2, so no separate dimension premise is missing. |
| `{q : ℕ}` | TYPING | Integer query/mode budget with q >= 0 represented by naturals. q=0 remains included. |
| `(κ : ℝ)` | TYPING | Real hard-family spectral parameter. |
| `(hκ : 2 ≤ κ)` | STANDING | Exact hard-family standing restriction in S4.SS1.p1. It guarantees the nonconstant affine spectral map needed in the source range proof. It is stronger than the minimally sufficient κ != 1 but is source-supported, not an EXCESS convenience assumption. |
| `(hq : 2 * q + 1 < d)` | SOURCE | Explicit condition of the enclosing Lemma 4.4/C.2 proof whose range component is being isolated. It implies d>=2 and includes the required source index range. The deterministic span equality needs less; retaining the source proof's explicit admissible-budget condition is not assumption smuggling. |
| `(x : EuclideanSpace ℝ (Fin d × Fin (q+1)))` | TYPING | Arbitrary finite real array, one coordinate for each spatial/start pair. It is data, not a probability law, good-event certificate or span witness. The source range proof works pointwise for every realization, so universal deterministic x is a supported strengthening of the Gaussian context. |

T additionally quantifies `∀ v : Fin d → ℝ` (TYPING, arbitrary real vector), followed by `v ∈ K →` (SOURCE, the domain restriction “let u in K_q” at A3.SS2.p19.2). The existence of c is a conclusion, not an input. Its three conjuncts use the *same* c. There is no coefficient-independence condition, nonzero-vector condition, full-rank premise, concentration estimate, Gaussian assumption, representation certificate, supplied range equality, or r²<=d premise.

The standard instances determined by ℝ, Fin and finite products are TYPING: decidable equality, finite summation indices, real arithmetic, and the canonical finite real module/matrix/Euclidean structures. No project-owned Prop alias, structure, typeclass, arbitrary norm, or hidden mathematical predicate appears in either exact signature. This review does not inspect future file-level instance overrides or imports; any such change must be judged against this canonical-structure scope rather than treated as preapproved.

There are no RULED binders and no source repair is requested. There are no EXCESS binders. The labels above apply to this *bounded C.2 component*, not to an assertion that the source explicitly stated the strongest possible deterministic theorem in a separate named lemma.

## Literal meaning of every local object

* **θ:** A formal index i has i.val=0,...,d-1, corresponding to source i_source=i.val+1. Hence `(i.val+1/2)π/d` is exactly `(i_source-1/2)π/d`. The half is real division inferred in a real expression, not truncated natural division. Natural d is cast to ℝ. hq excludes d=0,1, so totalized real division adds no off-source value on the theorem's carrier.
* **eigenvalue and Λ:** `(κ+1)/2+(κ-1)/2*cos(θ i)` matches S4.E11. `Matrix.diagonal` has this value at equal indices and zero elsewhere. Matrix powers in K are the ordinary natural powers of this square real matrix, including Λ⁰=I, not entrywise powers. The canonical context says so; no power identity or actual proof dependency is certified by this type audit.
* **g:** `g a i = WithLp.ofLp x (i,a)` takes the underlying real array coordinate. Formal a.val=0,...,q corresponds to source starting index a_source=a.val+1. The use of spatial/start order in x and start/mode order for B's columns is consistent. No norm of x is used, and its Euclidean carrier supplies every possible array, not a bounded or random subset.
* **t:** The Fin(q+1) index k labels modes j=k.val=0,...,q. The zero mode is exactly 1; each positive mode is sqrt(2)cos(jθ_i). It matches A3.Ex85. When q=0 the higher-mode branch has no index; nothing presupposes q>=1.
* **B:** Columns are indexed `(a,j)` with a and j each in Fin(q+1), so their number is r² with r=q+1. `B i (a,j) = (sqrt d)^(-1) g_a(i) t_i(j)` is exactly the row `d^(-1/2)(gamma_i tensor t_i)^T`, with source tensor order start then mode. d>=2 makes sqrt(d)>0; sqrt(2)>0. No zero fallback is chosen. The constant mode's scale is 1/sqrt(d), while positive modes have sqrt(2)/sqrt(d); changing the first scale to sqrt(2) would be a different definition.
* **K:** `Submodule.span ℝ (Set.range (fun (a,j) => (Λ^j.val).mulVec(g a)))` is exactly the real linear span of all source generators with 1<=a_source<=q+1 and 0<=j<=q. `Set.range` covers all index pairs. No closure in a topology, probability support restriction, omitted zero mode, fewer starting vectors, or whole-space surrogate occurs.
* **D** (T only): `diag(cos((((2*q+1:ℕ):ℝ))*θ_i))` is D_n for integer n=2q+1. Casting is after the natural arithmetic; no floating or alternate high-frequency parameter is inserted.
* **Image and set coercion** (P): the left `Set.range` means exactly “there exists a real coefficient function c such that B.mulVec c is this vector.” The right `(K : Set (Fin d → ℝ))` is the carrier set of the source subspace. This is ordinary matrix image equals Krylov subspace, expressed as equality of sets. It is neither a supplied span certificate nor a theorem-shaped abstract image predicate.

All these project-level objects are literal `let` formulas; none is a characterized/choice definition or quotient representative. `Submodule.span` itself is the canonical intersection-of-containing-submodules definition, not an off-source fallback. The existential coefficient is not turned into a canonical global coefficient function; uniqueness is not claimed.

## Canonical definition fragments and actual metric

All ten supplied literals were independently matched against their specified raw canonical source files. Every whole-file hash, literal hash, original Unicode character interval, UTF8 byte interval and LF line interval agrees, including terminal LF ownership. The characterization header has no terminal LF, exactly as supplied. The five supplied exact context header/notation strings in item 10 are checked by exact literal occurrence before the theorem header; only these context strings and the supplied header are output, not its proof. Exact receipts are in `selective-validation.receipts.json`.

1. `Set.range`: `{x | ∃ y, f y = x}` confirms real existential image.
2. `Submodule.span`: `sInf {p | s ⊆ p}` confirms algebraic real span; it introduces no norm or source theorem assumption.
3. `dotProduct`: finite sum `∑ i, v i*w i` confirms the RHS scalar dot products, without averaging or weights.
4. `Matrix.mulVec`: row dot product confirms B.mulVec c and D.mulVec v are ordinary column-vector multiplication.
5. `Matrix.diagonal`: equality-test diagonal and zero off diagonal matches Λ and D.
6. `WithLp`: constructor toLp / projection ofLp preserve underlying coordinates, not raw-function supremum norms.
7. `PiLp`: the Lp-tagged dependent product type; fixing p=2 is material.
8. `EuclideanSpace`: `PiLp 2` over finite real coordinates supplies the intended Euclidean setting.
9. The PiLp function coercion is `ofLp`, so explicit projection/coercion does not transform coordinates.
10. The supplied `EuclideanSpace.inner_eq_star_dotProduct` header characterizes `inner x y` as `ofLp y dotProduct star(ofLp x)`. Over ℝ, star is the identity; commutativity gives the usual ∑x_i y_i. It is a canonical characterization *statement*, not a newly audited existence theorem, not a project-owned characterized definition, and not evidence that either target compiles.

T uses the norm of `(WithLp.toLp 2 v : EuclideanSpace ℝ (Fin d))`, not the norm of raw `Fin d → ℝ`. Thus its square is the Euclidean energy ∑v_i², not the supremum norm energy. Likewise `inner ℝ (toLp 2 v) (toLp 2 (D.mulVec v))` is ∑v_i(Dv)_i=v^T Dv. The order in the generic star-dot header has no complex-conjugation effect over ℝ. The coefficient sums on the right express c^T(B^T B)c and c^T(B^T D B)c, with ordinary transpose and real multiplication. The definition excerpts plus the fixed canonical real Euclidean context are enough for this semantic judgment; no generic target API search, proof-body search or extra project definition is needed.

## Conclusion scope and relation between P and T

P states the range conjunct of Fact C.5 (A3.Ex86) for every deterministic array of starts. It does not state C.5's two expectation identities, the t-moment identities, C.6 concentration, or Lemma 4.4's high-probability uniform inequality. Its universal deterministic x is stronger than requiring a standard Gaussian sample, and is justified by the pointwise polynomial proof A3.SS2.p3. This is a supported algebraic generalization, not a source correction or removed necessary hypothesis.

T states that every v in the same K admits a common coefficient c with Bc=v and the exact energy and weighted-form pullback identities. The energy equality is explicit in A3.Ex130. A3.Ex131 displays an *absolute-value* equality for the weighted forms; T records the signed matrix identity underneath it. That signed identity is a valid algebraic expansion of u=Bc and v^T Dv, and immediately implies the source displayed absolute equality. It should be described as that underlying exact algebraic representation, not as a verbatim transcription of the entire displayed estimate. T has neither a norm event nor either of the source inequalities.

P supplies precisely the nontrivial representation content of T: v∈K, together with equality of image and K, yields a c with Bc=v. The energy/weighted identities then hold for that same c by ordinary finite-dimensional real algebra. Therefore T is a mathematically appropriate prospective consumer of P, materially linking the public range result to the source's final coefficient-coordinate formulas. However, *an exact consumer statement does not show an actual proof calls P*. There is no proof body in this packet. Actual use, compiled theorem existence, dependency minimality, and any status word such as VERIFIED or PROVED remain unapproved.

T's quantifier order is ∀x ∀v∈K(x), ∃c with all three conclusions, not a fixed coefficient independent of x. It remains suitable inside the later common matrix event and does not itself prove that probability event or the uniform estimate. q=0 and zero vectors/starts are included; no division by a vector norm or coordinate is implicit.

## Mathematical obligations that must remain internal

For P, the unresolved proof content is the source's two-direction equality of generating spans: nonzero affine slope from hκ; Chebyshev cosine identity with degree and nonzero leading coefficient; the finite triangular polynomial coefficient transform; diagonal powers acting coordinatewise; nonzero column normalizations from hq; matrix image equaling column span. Vector-family independence is not a valid substitute. These are genuine mathematical ingredients, not new public hypotheses.

For T, representation must actually be obtained from P or independently proved, and the two finite real matrix pullback identities must actually be proved using Euclidean norm/inner-product semantics. Neither their availability in a library nor their use in a target has been checked here. A prospective SG must represent the range and algebraic branches without adding C.6, Haar rotation, target moments, admissibility or a good-event premise as necessary parents of these exact identities.

The original source locators were rechecked from raw HTML bytes under the Phase 1 pins for the hard-family grid, K, cosine-span remark, B construction, range statement/proof and final formulas. `source-locator-recheck.json` records those exact spans and math contents. Raw-coordinate agreement was followed by the explicit index, normalization and metric comparison above; it is not being used as a substitute for a source-semantic verdict.

## Limits and freeze boundary

No mathematical mismatch, excessive premise, missing source-supported binder or incorrect metric was found in these selected exact statements/definitions. The supported strengthenings (arbitrary deterministic starts and signed quadratic identity) must remain visible in descriptions. This acceptance is bounded to signature hashes P/T given above and the fixed canonical definitions/context; it cannot be replayed for changed signatures, project aliases, scoped instances, alternate norms or changed source.

Phase 1 manifest and every payload file hash/mode were checked unchanged. No SG, prior verdict, frontier, README, role inventory, source-status record, root proof plan, target implementation, generic target API, theorem proof body, ledger, Goal, STAB or publication operation occurred. No subagent or detached work occurred. Selective exact source and canonical literal validation used Python stdlib only. Ordinary pretrained mathematical knowledge remains available; runtime exposure isolation is not a pretraining-isolation claim. After freezing this judgment, pause before receiving any proposed source graph or process/control packet.
