"""Bounded final capsule; never mutate shared source or integration metadata."""
import json,sys
from run import ROOT,REPO,run,sha
I=ROOT/'inputs';m=json.loads((ROOT/'input-manifest.json').read_text());n=json.loads((ROOT/'native-summary.json').read_text());r=json.loads((ROOT/'reader-static.json').read_text());loc=json.loads((ROOT/'locator-checks.json').read_text())
allrows=json.loads((ROOT/'native-all-bodies-v2.json').read_text())
assert len(allrows)==18 and len(n['new_owned_names'])==4
for d in allrows:
    assert d['type_closed'] and d['body_closed']
    assert set(d['axioms'])<=set(['propext','Classical.choice','Quot.sound'])
    for p in ['⋯','sorryAx','Lean.trustCompiler','Lean.ofReduceBool']:
        assert p not in d['body'] and p not in d['type'],(d['name'],p)
sys.path[:0]=[str(REPO/'tools'),str(REPO/'website/scripts')];import astis_site as base
base.ROOT=I;base.project_lean_paths=lambda:[I/p for p in m['modules']]
mods,decls=base.scan_project_sources();authored=[];generated=[]
for row in allrows:
    matches=[d for d in decls if d.module==row['module'] and (row['name']==d.full_name or row['name'].endswith('.'+d.full_name))]
    if matches:assert len(matches)==1;authored.append(row['name'])
    else:generated.append(row)
assert len(decls)==len(authored)==16 and len(generated)==2
assert all(x['name'] in n['new_owned_names'] for x in generated)
(ROOT/'native-generated-inspection.json').write_text(json.dumps({'handwritten_names':authored,'generated':generated,'older_generated_unreachable':[],'historical_unreachable_authored':n['older_unreachable_preserved']},indent=2)+'\n')
seal=json.loads((I/'research-wiki/paper-contributions/GaussianComplexity/source-row-law-statement-seal.json').read_text())
for key in ['producer','actual_private_consumer']:
    assert sha(seal[key]['signature'].encode())==seal[key]['signature_sha256']
bind=json.loads((ROOT/'relevant-input-binding.json').read_text())
current=[]
for x in bind['tracked_relevant_input_hashes']:
    b=(REPO/x['path']).read_bytes();assert sha(b)==x['sha256'],x['path']
    current.append({'path':x['path'],'sha256':sha(b),'equal_to_candidate':True})
h=run('head-final',['git','rev-parse','HEAD']);assert h.returncode==0
run('diff-names-final',['git','diff','--name-only',m['candidate_commit']])
checks=[]
for p in sorted((ROOT/'receipts').glob('*.json')):
    v=json.loads(p.read_text());checks.append({'receipt':str(p.relative_to(ROOT)),'exit_code':v['exit_code'],'seconds':v['duration_seconds']})
fail=json.loads((ROOT/'verifier-failures.json').read_text())
report={'reviewer':'independent-native-static-rl_native_52e9','checked_commit':m['candidate_commit'],'observed_final_HEAD':h.stdout.decode().strip(),'compile_credit_only_for_checked_commit':True,'verdict':'ACCEPT bounded native/whole-module/static-reader scope; all integration/source-fidelity/publication/purification gates remain HOLD','independence':'No proof authorship or candidate mathematical edits; no prior verdict used as native evidence. Existing earlier scripts used only as scaffolding.','environment':{'Lean':m['lean_version'],'binary':m['lean_binary'],'manifest_sha256':m['files']['lake-manifest.json']['sha256'],'packages':m['dependencies']},'source_hashes':{p:v for p,v in m['files'].items() if p in m['modules']},'statement_seal':{'file_sha256':m['files']['research-wiki/paper-contributions/GaussianComplexity/source-row-law-statement-seal.json']['sha256'],'producer_literal_sha256':seal['producer']['signature_sha256'],'consumer_literal_sha256':seal['actual_private_consumer']['signature_sha256'],'both_author_exact_and_independent_literal_kernel_applications_passed':True,'raw_Expr_structural_equality':False,'meaning':'Kernel-accepted definitional equality; no raw structural-expression equality claimed.'},'native':{'fresh_modules':m['modules'],'module_owned_total':18,'handwritten_total':16,'new_owned_total':4,'new_handwritten':2,'new_generated':2,'generated_names':[x['name'] for x in generated],'all_new_owned_reachable':True,'older_generated_unreachable':[],'older_unreachable_authored_retained':n['older_unreachable_preserved'],'producer_ASTIS_parents':n['producer_ASTIS_parents'],'consumer_ASTIS_parents':n['consumer_ASTIS_parents'],'all_module_owned_types_bodies_closed_and_axioms_checked':True,'allowed_axioms':['propext','Classical.choice','Quot.sound'],'no_pretty_print_elision_markers_or_fake_closure_in_dump':True,'full_dump':n['large_full_dump'],'general_noninjective_integral_map':'Native exact MeasureTheory.integral_map type and actual body reference checked. Its premises are AEMeasurable row and AEStronglyMeasurable integrand under map; no injectivity/embedding premise.','root_extra_hypotheses_or_wrapper_certificate_inputs':'None: both exact preproof signatures kernel-applied to actual roots. Candidate constructs law and probability proof internally.'},'static_reader':{'renderer':'production render_unit + export_sources + render_source_module','all_renderer_inputs_equal_to_candidate':True,'publication_binding_sha256':r['binding_sha256'],'main_and_six_step_formulas_present':True,'six_steps':r['six_steps'],'all_details_initially_closed':True,'consumer_exact_full_module_lines':145,'consumer_source_link_line':14,'three_blank_separator_lines_between_exact_consumer_spans':[66,86,110],'local_sources_downloads_and_module_anchors':'All relevant emitted local href destinations exist and all fragments resolve; exports/downloading file bytes checked statically, no interactive-runtime credit.','dependency_distinction':'Producer has no ASTIS parent; private consumer exact two ASTIS parents stated separately from Mathlib API.','source_map_coordinate_checks':len(loc['checks']),'source_map_sha256':loc['source_map_sha256'],'raw_source_sha256':loc['source_full_sha256'],'page':r['page'],'page_sha256':r['page_sha256'],'scope_limit':'Standalone bounded production lesson/module/source output; source_card/fullsite/globalgraph/browser runtime was not inspected.'},'focused_fake_closure':'Production comment/string stripping + FORBIDDEN_REGEX; zero hits across exact5 modules, alongside native axiom checks. No fullrepo gate.','failures_preserved':fail,'actual_receipts':checks,'relevant_current_input_check':current,'HOLD':['independent source-fidelity/code review outside this native role','canonical semantic/source VERIFIED transition','publication/ledger acceptance','root Tests and fullrepo ASTIS gates','serialized imports/Registry/global graph/metadata/site integration','browser desktop/mobile and MathJax layout','clipboard and interactive download runtime','fullsite/globalgraph/public delivery','joint-row independence and arbitrary ambient-law transport','original matrix expectation adapters, centered variance/concentration/main bounds and oracle/TV/precision/cap/cost adapters','purification'],'mutations':'Only private .astis/semantic-neutral-20261112/rl_native_52e9; no ledger transitions, git commits/push, shared imports, root Tests, Registry, production UI, or global metadata changes. No permission granted.'}
(ROOT/'report.json').write_text(json.dumps(report,indent=2)+'\n')
text=f'''# Independent native and bounded static-reader report

ACCEPT the bounded native/whole-module/static scope at `{m['candidate_commit']}` only. This is no source-fidelity verdict, source VERIFIED transition, publication permission, root Tests/fullrepo gate, public delivery, or purification claim.

The actual arm64 Lean4.33.0 binary SHA256 is `{m['lean_binary']['sha256']}`. The manifest is `{m['files']['lake-manifest.json']['sha256']}`. All nine actual package HEADs matched the pinned revisions and were clean including untracked files; original commands/streams are in `receipts/`.

Five complete transitive local source modules were independently derived from immutable commit imports and freshly compiled into an initially empty private olean tree. No ASTIS cached oleans were copied or reachable through LEAN_PATH. Mathlib/dependency caches were allowed.

All18 module-owned declarations (16 authored+2 generated) had native elaborated closed types, closed bodies and standard-only axiom closures inspected. The new P/T closure is exactly4 (2 authored+2 generated); all4 are reachable. The producer has no ASTIS theorem parent. The private consumer has exactly the row-law producer and the canonical radial exponential-moment parent. Eight older authored RadonNikodym declarations are not reached by these new roots and were retained; no older generated unreachable declaration was found. Historical declaration compilation confers no new historical source-fidelity/publication credit.

Both the exact supplied kernel probe and an independently generated application of each frozen literal signature passed. Raw Expr equality is false; the kernel accepts definitional equality. The actual general MeasureTheory.integral_map call was resolved and its native type has no injectivity requirement. There are no new wrapper/certificate assumptions on either exact root interface.

The production lesson/source/module renderers were run on frozen bounded inputs, with renderer bytes checked equal to the candidate. All six adjacent formula/Lean step folds are exact source spans and initially closed. Private T is exported in full,145lines including imports/header/body, with its line14 source link resolving. The four consumer steps reconstruct the full module with exactly the three blank source separators at66,86,110. Relevant module anchors and local download/source files resolve and have exact source bytes. All34 source-map byte/character/LF-line span checks passed. Mathlib APIs and ASTIS parents remain distinguished. Only static output and anchors were checked.

Four verifier-only failure causes are preserved with original scripts and streams: obsolete pp.maxDepth, prose relation normalization, omitted blank separators in a concatenation assertion, and malformed forall separator in the first independently generated literal. The malformed literal run had parser recovery/sorry and kernel mismatches and is rejected in full; later valid literal applications exited0. No mathematical source/renderer changes were made to fix them. Parent driver exit1 receipts are retained as well.

Full native body dump stays local at `native-all-bodies-v2.json` ({n['large_full_dump']['bytes']}bytes), SHA256 `{n['large_full_dump']['sha256']}`. Portable files include every bounded original stream/receipt, scripts, exact inputs, all declaration hashes, full native types, generated providers, static output, and this original report. See `report.json`, `native-summary.json`, `relevant-input-binding.json`, and `portable-manifest.json` for all hashes.

HOLD: separate independent source/code/semantic acceptance; publication and ledger transitions; root Tests/fullrepo; serialized shared integration; fullsite/globalgraph and public delivery; browser/mobile/MathJax/clipboard/interactive download checks; all stated remaining mathematics and purification. No permission is granted.
'''
(ROOT/'report.md').write_text(text)
(ROOT/'REPRODUCE.md').write_text('''# Reproduce in a fresh private output directory

Use exactly the pinned candidate and dependency package HEADs in input-manifest.json; require the native Lean binary hash. The run.py receipts name actual argv/cwd/LEAN_PATH and original streams for every check. These are read-only source checks plus private artifacts.

prepare.py derives the5-module local import closure and freezes candidate bytes; build.py compiles all5 into an empty private output and runs the exact supplied probe. make_inspector.py / prepare_v2.py / prepare_native_v3.py retain the original verifier failures and produce the accepted InspectAllV2.lean / IndependentLiteralCheckV3.lean. Use the actual successful receipt commands, not the rejected V1/V2 literal invocation. check_native_v3.py summarizes the successful native dump. locators.py and reader_static_v3.py check the bounded static source map and production renderer output. supplement.py binds runtime to candidate; finalize.py seals scope. Paths are absolute in original receipts because they describe the actual run; portable hashes and source inputs permit relocating the scripts after adjusting ROOT-derived targets.

Do not reuse ASTIS cached oleans or infer source fidelity/VERIFIED/publication/integration from this capsule. The complete31MB native dump and built oleans are omitted from the portable archive, recorded by hash, and regenerate from the included Lean inspection sources and fresh compile commands. Dependency caches/binaries are not bundled.
''')
print(json.dumps({'report':'report.md','accepted_commit_only':m['candidate_commit'],'all18_native_checked':True,'new_closure4':True,'static34_spans6_folds_T145_L14':True,'HOLD':report['HOLD']},indent=2))
