import AutoSamplingTheory.ExampleCases.ProximalBPS.ActualEndpointTimeReversal

namespace PBPSFiniteStates99
open scoped Classical
set_option autoImplicit false

theorem finite_state_reversal {X : Type*} (n : ℕ)
    (Φ : ℝ → X → X) (S R : X → X)
    (hS : Function.Involutive S) (hR : Function.Involutive R)
    (hRS : ∀ x, R (S x) = S (R x))
    (hInv : ∀ u x, Φ u (Φ (-u) x) = x)
    (hRev : ∀ u x, R (Φ u (R x)) = Φ (-u) x)
    (d : Fin (n+1) → ℝ) (post barPost : Fin (n+1) → X)
    (hp : ∀ i : Fin n, post i.succ = S (Φ (d i.castSucc) (post i.castSucc)))
    (hb : ∀ i : Fin n, barPost i.succ = S (Φ (d i.castSucc.rev) (barPost i.castSucc)))
    (hz : barPost 0 = R (Φ (d (Fin.last n)) (post (Fin.last n)))) :
    ∀ j : Fin (n+1),
      barPost j = R (Φ (d j.rev) (post j.rev)) ∧
      Φ (d j.rev) (barPost j) = R (post j.rev) := by
  have hRR (x : X) : R (R x) = x := hR x
  have hSS (x : X) : S (S x) = x := hS x
  have hc (u : ℝ) (x : X) : R (Φ u x) = Φ (-u) (R x) := by
    simpa only [hRR] using hRev u (R x)
  have hcancel (u : ℝ) (x : X) : Φ u (R (Φ u x)) = R x := by
    rw [hc, hInv]
  intro j
  induction j using Fin.induction with
  | zero =>
    constructor
    · simpa only [Fin.rev_zero] using hz
    · rw [hz, Fin.rev_zero, hcancel]
  | succ i ih =>
    have hs : barPost i.succ = R (Φ (d i.succ.rev) (post i.succ.rev)) := by
      rw [hb, ih.2, Fin.rev_castSucc, hp, hRS, hSS, Fin.rev_succ]
    exact ⟨hs, by rw [hs, hcancel]⟩

theorem incoming_rate_product {X : Type*} (n : ℕ) (S R : X → X)
    (rate : X → ℝ) (hRate : ∀ x, rate (R (S x)) = rate x)
    (post arrive barArrive : Fin (n+1) → X)
    (hp : ∀ i : Fin n, post i.succ = S (arrive i.castSucc))
    (hb : ∀ j : Fin (n+1), barArrive j = R (post j.rev)) :
    (∏ i : Fin n, rate (barArrive i.castSucc)) =
      ∏ i : Fin n, rate (arrive i.castSucc) := by
  have he (i : Fin n) : rate (barArrive i.castSucc) = rate (arrive i.rev.castSucc) := by
    rw [hb, Fin.rev_castSucc, hp, hRate]
  simp_rw [he]
  exact Equiv.prod_comp Fin.revPerm (fun i : Fin n => rate (arrive i.castSucc))

#print axioms finite_state_reversal
#print axioms incoming_rate_product
end PBPSFiniteStates99
