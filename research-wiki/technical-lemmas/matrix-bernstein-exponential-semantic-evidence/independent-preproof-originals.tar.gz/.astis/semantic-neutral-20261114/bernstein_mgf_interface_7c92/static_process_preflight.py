"""Static review only. Never imports or executes the intake/advance modules."""
import ast
import hashlib
import json
import re
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
W = ROOT / ".astis/huanjian-gc-bernstein-mgf-preparation-20261114"
script = W / "start_shared_exponential_packet.py"
sha = lambda b: hashlib.sha256(b).hexdigest()
load = lambda p: json.loads(p.read_bytes())
text = script.read_text()
tree = ast.parse(text)
cell_path = W / "candidate-frontier-cell.unclaimed.v1.json"
proposal_path = W / "candidate-proposal-kwargs.unclaimed.v1.json"
cell, proposal, seal = load(cell_path), load(proposal_path), load(W / "statement-seal.unclaimed.v1.json")
decision_path = ROOT / ".astis/semantic-neutral-20261114/bernstein_mgf_tc_29d8/graph-challenge-v2-focused/decision.v2.json"
decision = load(decision_path)
findings = []
check = lambda condition, message: findings.append(message) if not condition else None
check(sha(decision_path.read_bytes()) == "b5a5e81d7f110c40a1fdb6ee0ba6c03003a9bf18d04dea907e3105fa5de6ede7", "Focused topology-decision hash mismatch.")
check(decision["verdict"] == "ACCEPTED_SCOPED_SOURCE_TOPOLOGY_AND_INTERNAL_PORT_RECORDS_FOR_EXACT_P_T" and not decision["blocking_findings"], "Source-decision status mismatch.")
check(cell["route"] == "shared" and cell["mode"] == "faithfulPaper", "Shared/source mode mismatch.")
check(cell["reuse_plan"]["planned_existing_P_parents"] == [] and cell["parents"] == [], "Generic P has a false planned Gaussian parent.")
check(cell["consumer_scope"]["compiled_consumer_credit"] is False and cell["reuse_plan"]["known_consumers"] == [], "Invented compiled consumer credit.")
check(cell["consumer_scope"]["current_exact_consumer"]["name"] == seal["actual_private_consumer"]["name"] and cell["consumer_scope"]["current_exact_consumer"]["state"].startswith("PLANNED_"), "Current private T is not honestly planned/sealed.")
check(cell["consumer_scope"]["second_source_required_route"]["state"].startswith("FUTURE_UNIMPLEMENTED_") and len(set(cell["consumers"])) == 2, "Second consumer not explicit future/unimplemented distinct source family.")
check(proposal["theorem_delta"] == seal["producer"]["signature"], "Proposal changes exact P signature.")
check(seal["producer"]["signature"] in cell["target_statement"] and seal["actual_private_consumer"]["signature"] in cell["target_statement"], "Cell does not retain exact sealed P/T strings.")
check(proposal["target_declarations"] == [seal["producer"]["name"]], "Public target set includes private/future consumer.")
check(not any("WeightedMgf" in p for p in proposal["proposed_files"] + cell["owned_files"]), "Future weighted route became a current file target.")

calls = [n for n in ast.walk(tree) if isinstance(n, ast.Call)]
api_calls = sorted([n for n in calls if isinstance(n.func, ast.Attribute) and isinstance(n.func.value, ast.Name) and n.func.value.id == "advance" and n.func.attr in {"propose_advance", "transition_advance"}], key=lambda n: n.lineno)
markers = [n for n in calls if isinstance(n.func, ast.Name) and n.func.id == "create" and n.args and "normal-intake-attempted.once.json" in ast.unparse(n.args[0])]
check(len(markers) == 1, "Once marker count differs from one.")
marker_line = markers[0].lineno if markers else -1
check(len(api_calls) == 3 and all(n.lineno > marker_line for n in api_calls), "Normal API calls not exactly three after once marker.")
check([n.func.attr for n in api_calls] == ["propose_advance", "transition_advance", "transition_advance"], "Normal API order differs.")
check([n.args[1].value for n in api_calls[1:]] == ["CLAIMED", "EXPLORING"], "Unexpected state transition target.")
check("with p.open('xb')" in text, "Create helper is not exclusive.")
check("paths=[C,SP,L," in text and "set(map(str,paths))" in text, "Git stage path allowlist/check missing.")
check("for p,fp in {**tracked,**controls}.items():" in text and "now==states" in text and "D.read_bytes()==discover" in text and "for p,h in foreign_frontiers.items():" in text and "git('ls-files','--stage','-z')==index" in text, "Existing-state/fingerprint guards missing.")
check("preproof-baseline.private.json" in text and "preproof-discoveries.private.json" in text and "normal-intake-paths.private.nul" in text, "Private guard paths missing.")
check(".private." in text and "private_guards_exported':False" in text, "Private guard export exclusion missing.")

# Only nonprivate actual archive candidates are opened. Never read a .private file.
roots = [ROOT / ".astis/semantic-neutral-20261113/bernstein_mgf_sg_c410", ROOT / ".astis/semantic-neutral-20261114/bernstein_mgf_tc_29d8", OUT]
candidates = []
for root in roots:
    for p in root.rglob("*"):
        if p.is_symlink():
            findings.append("Symlink candidate refused: " + str(p.relative_to(ROOT)))
        elif p.is_file() and "__pycache__" not in p.parts:
            if any(".private." in part for part in p.parts):
                findings.append("Private-named source archive candidate refused without opening: " + str(p.relative_to(ROOT)))
            else:
                candidates.append(p)
for p in W.iterdir():
    if p.is_file() and ".private." not in p.name and p.suffix in {".py", ".lean", ".json", ".txt", ".md", ".png"}:
        candidates.append(p)
candidates += [
    ROOT / ".astis/semantic-neutral-20261113/bernstein_raw_intake_74ab/Tro11-User-Friendly-preprint.pdf",
    ROOT / ".astis/huanjian-resume-20261103/2610.20492v1.html",
]
for p in (ROOT / ".astis/huanjian-resume-20261103").glob("*unclaimed-bernstein-*.receipt.json"):
    if p.is_symlink() or any(".private." in part for part in p.parts):
        findings.append("Private/symlink actual-run receipt refused without opening.")
        continue
    log = ROOT / load(p)["log"]
    if log.is_symlink() or any(".private." in part for part in log.parts):
        findings.append("Private/symlink actual-run log refused without opening.")
        continue
    candidates += [p, log]
index_line = re.compile(rb"(?m)^\d{6} [0-9a-f]{40,64} [0-3]\t[^\n\x00]+")
private_keys = {"all_foreign_states", "all_existing_frontier_hashes", "all_existing_tracked_fingerprints", "actual_control_fingerprints", "full_states", "tracked_git_index"}
def inspect_shape(o, path):
    if isinstance(o, dict):
        for key, value in o.items():
            if key in private_keys and not isinstance(value, (int, bool)):
                findings.append("Private-map/index payload key in public candidate: " + path + " key=" + key)
            inspect_shape(value, path)
        if sum(str(k).startswith("ASTIS-SA-") and isinstance(v, dict) and "state" in v for k, v in o.items()) >= 3:
            findings.append("Advance full-state map shape in public candidate: " + path)
        if sum(isinstance(v, dict) and {"mode", "kind"}.issubset(v) for v in o.values()) >= 3:
            findings.append("Fingerprint full-map shape in public candidate: " + path)
        if sum(str(k).startswith("research-wiki/frontier-cells/") and isinstance(v, str) and re.fullmatch(r"[0-9a-f]{64}", v) is not None for k, v in o.items()) >= 3:
            findings.append("Foreign-frontier full-map shape in public candidate: " + path)
    elif isinstance(o, list):
        for value in o:
            inspect_shape(value, path)
roster = []
for p in sorted(set(candidates)):
    b = p.read_bytes()
    name = str(p.relative_to(ROOT))
    if index_line.search(b):
        findings.append("Actual Git-index stage string in public candidate: " + name)
    if p.suffix == ".json":
        inspect_shape(json.loads(b), name)
    roster.append({"path": name, "bytes": len(b), "sha256": sha(b)})
absent_paths = [
    "research-wiki/frontier-cells/ASTIS-SHARED-MATRIX-BERNSTEIN-EXPONENTIAL-QUADRATIC.json",
    "research-wiki/technical-lemmas/matrix-bernstein-exponential-statement-seal.json",
    "research-wiki/technical-lemmas/matrix-bernstein-exponential-semantic-evidence",
    "AutoSamplingTheory/TechnicalLemmas/Probability/MatrixBernsteinExponential.lean",
    "Tests/GaussianComplexityBernsteinMgf.lean",
    str((W / "normal-intake-attempted.once.json").relative_to(ROOT)),
    str((W / "preproof-baseline.private.json").relative_to(ROOT)),
]
for p in absent_paths:
    check(not (ROOT / p).exists(), "Intake precondition path already exists (not opened): " + p)
report = {
    "verdict": "READY_STATIC_ONLY" if not findings else "BLOCKING_STATIC_FINDINGS",
    "scope": "Unexecuted script, candidate metadata, public source-evidence archive path/shape checks only. No intake, source/API/math experiment, baseline capture, old ledger/state-map read, production or shared write.",
    "script": {"path": str(script.relative_to(ROOT)), "sha256": sha(script.read_bytes()), "syntax": "AST_PARSE_PASS"},
    "candidate_hashes": {str(p.relative_to(ROOT)): sha(p.read_bytes()) for p in [cell_path, proposal_path]},
    "focused_topology_decision_sha256": sha(decision_path.read_bytes()),
    "normal_API_calls": [{"line": n.lineno, "call": ast.unparse(n)} for n in api_calls],
    "exclusive_once_marker_line": marker_line,
    "shared_consumer_honesty": "Two source-native uses are planned, not compiled: exact sealed unweighted private T is PLANNED; cosine-weighted MGF is explicitly FUTURE_UNIMPLEMENTED and excluded from current file/target set. known_consumers=[], compiled_consumer_credit=false. No mathematical completion credit.",
    "writes_review": "Script write destinations are own W private guards/once receipt, own shared C/SP/E, and normal advance ledger via three APIs. Staging is checked against C/SP/L/E files only. No foreign C, CSS, Registry, root import, source-correspondence or global graph writes are present.",
    "preservation_review": "Full advance/discovery states, all prior frontier hashes, raw Git index, tracked fingerprints and historical control fingerprints are held in .private guards; post-call checks compare foreign states, original frontier hashes, original tracked/control fingerprints, index and discovery bytes. Exported preservation summary carries counts/digests only.",
    "public_archive_scan": {"candidate_files": len(roster), "candidate_bytes": sum(x["bytes"] for x in roster), "roster_sha256": sha(json.dumps(roster, sort_keys=True).encode()), "private_fullmaps_opened": 0, "actual_index_string_hits": 0 if not any("Git-index" in x for x in findings) else None, "shape_findings": [x for x in findings if "candidate" in x]},
    "limitations": "Static readiness concerns this exact script and current public candidate snapshot. No normal APIs, intake script, Lean gate, source proof, proof closure or end-to-end preservation run was executed. Existing pure metadata-validator PASS is not recharacterized as theorem acceptance.",
    "findings": findings,
}
(OUT / "static-process-preflight.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
print(json.dumps(report, ensure_ascii=False, indent=2))
