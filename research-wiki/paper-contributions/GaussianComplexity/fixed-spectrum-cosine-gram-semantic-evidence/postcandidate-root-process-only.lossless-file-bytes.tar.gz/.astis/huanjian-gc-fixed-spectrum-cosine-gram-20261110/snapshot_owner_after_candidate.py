from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, subprocess, sys
sys.dont_write_bytecode = True
sys.path.insert(0, 'tools')
import astis_advance as adv
sha = lambda b: hashlib.sha256(b).hexdigest()
rows = []
for ref in ['origin/main', 'origin/codex/slc-lsi-weighted-radial-mgf-release']:
    commit = subprocess.check_output(['git', 'rev-parse', ref], text=True).strip()
    raw = subprocess.check_output(['git', 'show', commit+':runs/substantive_advances.jsonl'])
    states = adv._replay_advances([json.loads(z) for z in raw.splitlines()])
    rows.append({'ref': ref, 'commit': commit, 'ledger_sha256': sha(raw),
                 'stabilizing': [{'advance_id': a, 'owner_id': x.get('owner_id'), 'state': x['state']} for a, x in states.items() if x['state'] == 'STABILIZING']})
x = {'observed_utc': datetime.now(timezone.utc).isoformat(),
     'observation': 'Read after successful real git fetch origin; no owner transfer, ledger rewrite or shared integration.',
     'local_mathematical_candidate': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
     'refs': rows}
p = Path(__file__).parent/'latest-main-owner-after-cosine-gram-candidate.json'
with p.open('x') as f:
    json.dump(x, f, ensure_ascii=False, indent=2)
    f.write('\n')
print(json.dumps(x))
