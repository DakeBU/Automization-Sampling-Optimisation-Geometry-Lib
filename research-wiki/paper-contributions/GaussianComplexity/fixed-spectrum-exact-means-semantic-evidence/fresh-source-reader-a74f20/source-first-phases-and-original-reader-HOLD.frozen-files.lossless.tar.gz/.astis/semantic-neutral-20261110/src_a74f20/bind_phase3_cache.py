from pathlib import Path
import hashlib,json,re,subprocess
ROOT=Path('/Users/zhouhuanjian/ASTIS-GC')
BASE=ROOT/'.astis/semantic-neutral-20261110/src_a74f20/phase3'
def sha_file(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  while data:=f.read(1024*1024):h.update(data)
 return h.hexdigest()
env=json.loads((BASE/'environment-and-direct-cache.json').read_text())
roots=[Path(x) for x in env['LEAN_PATH'].split(':')]+[Path(env['lean']).parents[1]/'lib/lean']
modules=re.findall(r'^IMPORTED_MODULE (.+)$',(BASE/'fresh-definition-probe-attempt2.stdout').read_text(),re.M)
files=[];unresolved=[];seen=set()
for name in modules:
 rel=Path(*name.split('.'))
 p=next((p for root in roots if (p:=root/rel.with_suffix('.olean')).is_file()),None)
 if p is None:unresolved.append(name);continue
 for suffix in ['.olean','.olean.private','.olean.server','.ir']:
  q=Path(str(p)[:-len('.olean')]+suffix)
  if q.is_file() and str(q.resolve()) not in seen:
   seen.add(str(q.resolve()));files.append({'module':name,'resolved_path':str(q.resolve()),'requested_path':str(q),'bytes':q.stat().st_size,'sha256':sha_file(q)})
out={'basis':'Actual env.header.moduleNames from successful independent definition/cache probe, resolving this isolated LEAN_PATH then pinned toolchain lib. Cache sibling links are read-only; producer and Test resolve to new isolated outputs.','module_count':len(modules),'artifact_count':len(files),'total_bytes_hashed':sum(x['bytes'] for x in files),'unresolved':unresolved,'files':files}
(BASE/'actual-transitive-dependency-cache-hashes.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k!='files'},indent=2))
assert not unresolved

s=(BASE/'fresh-kernel.stdout').read_text()
records=[]
for block in re.split(r'(?m)^OWNED_DECL_TYPE ',s)[1:]:
 typ,sep,tail=block.partition('\nOWNED_DECL_USED ')
 if not sep:continue
 name,_,typ=typ.partition(': ')
 used,_,tail=tail.partition('\nOWNED_DECL_AXIOMS ')
 ax,_,tail=tail.partition('\nOWNED_DECL_REACHABLE_FROM_ACTUAL_ROOT ')
 reachable=tail.splitlines()[0].endswith(': true')
 records.append({'name':name,'type':typ,'used_constants_record':used,'axioms_record':ax,'reachable_from_actual_roots':reachable})
(BASE/'all-owned-kernel-inventory.json').write_text(json.dumps(records,indent=2,ensure_ascii=False)+'\n')
print('OWNED',len(records),'REACHABLE',sum(x['reachable_from_actual_roots'] for x in records),'UNREACHABLE_GENERATED_SIMP',sum(not x['reachable_from_actual_roots'] for x in records))
assert len(records)==37
assert all(x['reachable_from_actual_roots'] or '._simp_' in x['name'] for x in records)

pin='db584cd6d46c92f209a44c0f1c829460d327499d'
mathctx=[]
for rel in ['Mathlib/Probability/Distributions/Gaussian/Multivariate.lean','Mathlib/Analysis/Normed/Lp/WithLp.lean','Mathlib/Data/Matrix/Mul.lean']:
 package=ROOT/'.lake/packages/mathlib';p=package/rel
 r=subprocess.run(['git','show',pin+':'+rel],cwd=package,capture_output=True)
 assert r.returncode==0
 b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==hashlib.sha256(r.stdout).hexdigest()
 target=BASE/'definition-context'/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(b)
 mathctx.append({'path':str(p),'snapshot':str(target.relative_to(ROOT)),'sha256':hashlib.sha256(b).hexdigest(),'pinned_source_matches':True,'git_show_exit_code':r.returncode})
(BASE/'definition-context-source-bindings.json').write_text(json.dumps(mathctx,indent=2)+'\n')
print('PINNED_DEFINITION_CONTEXT_SOURCES_MATCH',len(mathctx))
