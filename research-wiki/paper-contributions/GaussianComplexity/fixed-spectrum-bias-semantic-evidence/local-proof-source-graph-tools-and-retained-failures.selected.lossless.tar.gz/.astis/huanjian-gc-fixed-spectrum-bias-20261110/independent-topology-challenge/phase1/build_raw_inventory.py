"""This packet's raw-only inventory. No seal, extractor or proof/API input."""
from pathlib import Path
import runpy
import json
import hashlib
import re
from collections import Counter

ROOT = Path('/Users/zhouhuanjian/ASTIS-GC')
OUT = ROOT / '.astis/huanjian-gc-fixed-spectrum-bias-20261110/independent-topology-challenge/phase1'
READER_PATH = ROOT / '.astis/huanjian-gc-fixed-spectrum-variances-20261110/independent-topology-challenge/source_only_reader.py'
assert hashlib.sha256(READER_PATH.read_bytes()).hexdigest() == '9b937b08225abd768e25328e213ad758de84fd455b8acf255353710271fd99c5'
r = runpy.run_path(str(READER_PATH))
walk, record = r['walk'], r['record']
raw_lines = r['TEXT'].splitlines(keepends=True)
SCOPES = ['S2', 'S4', 'A3.SS3', 'bib.bib3']


def norm(s):
    return re.sub(r'\s+', ' ', s).strip()


def kind(n):
    c = n.attrs.get('class', '').split()
    if n.tag == 'section':
        return 'section-container'
    if re.fullmatch('h[1-6]', n.tag):
        return 'heading'
    if n.tag == 'div':
        for token, result in [('ltx_para', 'paragraph-container'), ('ltx_theorem', 'source-statement-container'), ('ltx_proof', 'source-proof-container')]:
            if token in c:
                return result
    if n.tag == 'p' and 'ltx_p' in c:
        return 'substantive-paragraph'
    if n.tag == 'table' and ('ltx_equation' in c or 'ltx_equationgroup' in c):
        return 'display'
    if n.tag == 'tbody':
        return 'aligned-TBODY'
    if n.tag == 'cite':
        return 'citation-occurrence'
    if n.tag == 'a' and n.attrs.get('href'):
        return 'link-occurrence'
    if n.tag == 'li' and n.attrs.get('id', '').startswith('bib.'):
        return 'bibliography-entry'


def locator(n):
    if n.attrs.get('id'):
        return n.attrs['id']
    a = n.parent
    while a and not a.attrs.get('id'):
        a = a.parent
    return a.attrs['id'] + '::' + n.tag + '@' + str(record(n)['line_start'])


items, math_registry, link_registry, roots, readback = [], {}, [], [], []
for scope in SCOPES:
    nroot = r['READER'].ids[scope]
    roots.append({'scope': scope, **record(nroot)})
    readback.append('SOURCE ROOT ' + scope + '\n' + r['normalized'](nroot))
    for n in walk(nroot):
        if n.tag == 'math':
            key = n.attrs['id']
            assert key not in math_registry
            math_registry[key] = {'id': key, 'tex': n.attrs.get('alttext', ''),
                                  'display': n.attrs.get('display', ''), **record(n)}
        if n.tag == 'a' and n.attrs.get('href'):
            link_registry.append({'link_ordinal': len(link_registry), 'scope': scope,
                                  'href': n.attrs['href'], 'title': n.attrs.get('title', ''),
                                  'text': norm(r['normalized'](n)), **record(n)})
        k = kind(n)
        if not k:
            continue
        rec = record(n)
        text = norm(r['normalized'](n)) if k in ['substantive-paragraph', 'display', 'aligned-TBODY', 'citation-occurrence', 'heading', 'bibliography-entry', 'link-occurrence'] else None
        if k == 'source-statement-container':
            text = next((norm(r['normalized'](q)) for q in walk(n) if re.fullmatch('h[1-6]', q.tag)), '')
        items.append({'raw_ordinal': len(items), 'display_locator': locator(n), 'scope': scope,
                      'kind': k, **rec, 'line_slice_sha256': hashlib.sha256(''.join(raw_lines[rec['line_start'] - 1:rec['line_end']]).encode()).hexdigest(),
                      'text': text,
                      'math_ids': [q.attrs['id'] for q in walk(n) if q.tag == 'math'],
                      'link_byte_starts': [record(q)['byte_start_inclusive'] for q in walk(n) if q.tag == 'a' and q.attrs.get('href')],
                      'status': 'RAW_OBSERVATION_ONLY_NO_TARGET_DISPOSITION_OR_ADMISSION'})
assert len({x['raw_ordinal'] for x in items}) == len(items)
counts = {'raw_units': len(items), 'unit_kinds': dict(Counter(x['kind'] for x in items)),
          'scope_units': dict(Counter(x['scope'] for x in items)),
          'unique_math_elements': len(math_registry), 'link_occurrences': len(link_registry)}
collisions = {key: [x['raw_ordinal'] for x in items if x['display_locator'] == key]
              for key, count in Counter(x['display_locator'] for x in items).items() if count > 1}
inventory = {'phase': 'BIAS_INDEPENDENT_RAW_SOURCE_ONLY_PHASE1', 'source_sha256': hashlib.sha256(r['RAW']).hexdigest(),
             'unit_identity': 'raw_ordinal is unique; display_locator is provenance and may collide for same-line anonymous tags. Original HTML IDs are unchanged.',
             'unit_rule': 'All section/headings/paragraph/theorem/proof/display/TBODY/citation/link units within complete selected raw roots; math recorded once in separate exact registry. Containers do not create new mathematical claims.',
             'roots': roots, 'counts': counts, 'display_locator_collisions': collisions,
             'items': items, 'math_registry': list(math_registry.values()), 'link_registry': link_registry,
             'not_a_target_graph': True, 'no_NODE_EXCLUDED_or_statement_verdict': True}
OUT.mkdir(parents=True, exist_ok=True)
for name, value in [('raw-inventory.json', json.dumps(inventory, ensure_ascii=False, indent=2) + '\n'),
                    ('raw-readback.txt', '\n\n'.join(readback) + '\n')]:
    p = OUT / name
    assert not p.exists(), name
    p.write_text(value)
print(json.dumps({'counts': counts, 'collisions': collisions,
                  'outputs': {name: {'bytes': (OUT / name).stat().st_size,
                                     'sha256': hashlib.sha256((OUT / name).read_bytes()).hexdigest()} for name in ['raw-inventory.json', 'raw-readback.txt']}}, ensure_ascii=False, indent=2))
