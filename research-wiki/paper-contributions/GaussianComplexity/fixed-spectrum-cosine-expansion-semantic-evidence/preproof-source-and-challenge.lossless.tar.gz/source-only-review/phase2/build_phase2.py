#!/usr/bin/env python3
"""Bounded source-only phase2 projection and exact sealed-interface comparison."""
import sys
sys.dont_write_bytecode=True
import importlib.util
import hashlib
import json
from pathlib import Path

BASE=Path(__file__).resolve().parent
PHASE1=BASE.parent/'phase1'
REPO=BASE.parents[3]
RAW=REPO/'.astis/huanjian-resume-20261103/2610.20492v1.html'
SEAL=REPO/'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-cosine-expansion-statement-seal.json'
SEAL_SHA='748538057656b235eed54272a87e66f4bf87bdbeb79a9831795b53e72ae74a36'
PHASE1_SHA='215fe8eba52b906f54c08471d9d0e896b956cb6726af15a335f4815bac60c6d3'
def sha(b): return hashlib.sha256(b).hexdigest()
def dump(name,obj): (BASE/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
assert sha(SEAL.read_bytes())==SEAL_SHA
assert sha((PHASE1/'manifest.json').read_bytes())==PHASE1_SHA
manifest1=json.loads((PHASE1/'manifest.json').read_text())
for item in manifest1['files']:
    assert sha((PHASE1/item['path']).read_bytes())==item['sha256'],item['path']
sealed=json.loads(SEAL.read_text())
for key in ['producer','actual_private_consumer']:
    assert sha(sealed[key]['signature'].encode())==sealed[key]['signature_sha256']
(BASE/'seal-input.json').write_bytes(SEAL.read_bytes())
module_spec=importlib.util.spec_from_file_location('frozen_phase1_extractor',PHASE1/'extract_source.py')
x=importlib.util.module_from_spec(module_spec)
module_spec.loader.exec_module(x)
graph1=json.loads((PHASE1/'source_graph.json').read_text())

nodes=[]; edges=[]
def n(key,kind,anchors,meaning,**extra):
    nodes.append({'id':key,'kind':kind,'source_anchors':anchors.split() if anchors else [],'meaning':meaning,**extra})
def e(key,parents,consumer,sites,detail,**extra):
    edges.append({'id':key,'connective':'AND','parents':parents.split(),'consumer':consumer,'consumer_use_sites':sites.split(),'condition_and_scope':detail,**extra})
n('source.standing','STANDING','S4.SS1.p1.1','Real kappa>=2 and integer d>=2 are literal hard-family standing ranges. The dimension is irrelevant to the all-real-angle C.7 producer and remains in the finite-grid consumer.')
n('hard.grid','SOURCE_LITERAL','S4.E11 A3.SS3.p1','theta_i=(i-1/2)pi/d; lambda_i=(kappa+1)/2+(kappa-1)cos(theta_i)/2; i=1,...,d. Introductory paragraph announces expansion then finite-grid summation. Variance/bias work announced there is excluded.')
n('moment.definitions','SOURCE_LITERAL_CONTEXT','S4.Thmtheorem5.p1.1','Contains the standing kappa>=2, Gaussian U law, rho formula and later moment-frequency scope. Only rho and parameter context feed C.7. Gaussian/moment definitions and 1<=n<d are boundary context, not C.7 premises.')
n('rho.literal','SOURCE_LITERAL','S4.Thmtheorem5.p1.m3','rho=(sqrt(kappa)-1)/(sqrt(kappa)+1) with principal nonnegative real square root.')
n('rho.range','SOURCE_PRODUCED','A3.SS3.p2.m1','0<rho<1 is derived from literal rho and kappa>=2, not supplied as a theorem premise.')
n('C7.expansion','SOURCE_STATEMENT_PACKET','A3.Thmtheorem7','All-real-angle inverse-spectrum expansion plus absolute and uniform convergence. Split below into the three conclusion ports; no output is a new input premise.')
n('C7.pointwise','SOURCE_CONCLUSION','A3.Thmtheorem7.p1.1 A3.Ex133','For every real theta: 2/(kappa+1+(kappa-1)cos(theta))=kappa^(-1/2)[1+2 sum_{j>=1}(-rho)^j cos(j theta)].')
n('C7.absolute','SOURCE_CONCLUSION','A3.Thmtheorem7.p1.2','For every real theta, sum_{j>=1}|(-rho)^j cos(jtheta)| converges. This is pointwise absolute convergence, not merely convergence of the signed series.')
n('C7.uniform','SOURCE_CONCLUSION','A3.Thmtheorem7.p1.2','Positive-index signed partial sums converge uniformly on all real theta to the infinite cosine series; common N0 comes before all theta.')
n('C7.geometric','SOURCE_PROOF_REGION','A3.SS3.p2.1 A3.EGx14 A3.Ex134 A3.Ex135','Source geometric-series/Euler calculation gives 1-rho e^(i theta)/(1+rho e^(i theta))-rho e^(-i theta)/(1+rho e^(-i theta))=(1-rho^2)/(1+2rho cos(theta)+rho^2).')
n('C7.rho_algebra','SOURCE_PROOF_REGION','A3.SS3.p2.2 A3.Ex136','Two literal-rho algebraic identities convert the rational geometric expression to inverse spectrum with exact kappa^(-1/2) normalization.')
n('C7.combine','SOURCE_PROOF_REGION','A3.SS3.p2.3','Combining these identities proves the expansion; the subsequent display separately gives the geometric majorant.')
n('C7.domination','SOURCE_PROOF_REGION','A3.Ex137','sum_{j>=1}|(-rho)^j cos(jtheta)|<=sum_{j>=1}rho^j=rho/(1-rho), uniformly in theta. Source exposes a uniform summable majorant, stronger than just convergence at each fixed theta.')
n('C7.convergence_delivery','SOURCE_PROOF_REGION','A3.SS3.p2.4','The source concludes absolute and uniform convergence from that majorant. Tail/uniform-convergence reasoning is not spelled out as a separate named theorem.')
n('background.geometric_complex','SOURCE_GAP_UNNAMED_BACKGROUND',None,'Complex geometric series, Euler cosine conversion, real-part/rational algebra and nonzero denominators. No external citation; no expansion or library-availability claim here.',used_at=['A3.SS3.p2.1','A3.Ex134','A3.Ex135'])
n('background.uniform_convergence','SOURCE_GAP_UNNAMED_BACKGROUND',None,'Passage from a theta-independent summable geometric majorant to absolute convergence and uniform signed-series convergence; finite tail quantifiers/domain must be preserved.',used_at=['A3.Ex137','A3.SS3.p2.4'])
n('background.rho_geometry','SOURCE_GAP_UNNAMED_BACKGROUND',None,'Principal-square-root positivity, sqrt(kappa)>1, 0<rho<1, and positive/nonzero spectrum/rational denominators follow from the source parameter range and cosine bounds. They are produced, never added inputs.',used_at=['A3.SS3.p2.1','A3.Ex136','A3.Ex137'])
n('C8.trace_moments','BOUNDARY_SOURCE_BRIDGE','A3.SS3.p4.1 A3.Ex140','E U_i^2=1/lambda_i identifies actual Gaussian M and mu_n with finite reciprocal-spectrum sums. The pure private consumer does not prove this expectation identification.')
n('C8.interchange','SOURCE_ACTUAL_CONSUMER_SITE','A3.SS3.p4.2','Fact C.7 allows interchange of its absolutely convergent series with the finite grid sum. Author context is the unweighted M sum and the mu_n-weighted sum for source 1<=n<d. The source step is reconstructed independently of a planned implementation signature; full C.8 alias/closed-moment computation lies beyond the seal.')
n('gap.finite_weighted_sum_bridge','SOURCE_GAP_FINITE_SUM_BRIDGE',None,'The p4.2 sentence suppresses fixed finite real cosine weights, absolute summability of each weighted series and the finite sum, distributivity of finite summation, finite-sum/infinite-sum exchange and literal reciprocal-eigenvalue normalization. None is a public premise; no implementation route or API is selected.',used_at=['A3.SS3.p4.2'])
n('background.gaussian','SOURCE_GAP_GAUSSIAN_EXPECTATION_BRIDGE',None,'Under U~N(0,Lambda^-1), coordinate second moments/integrability and finite-sum expectation identify E||U||^2 and E[U^TD_nU] with Ex140 sums. Pure spectral-series identity alone supplies none of this expectation evidence.',used_at=['A3.SS3.p4.1','A3.Ex140'])
n('moment.transport','BOUNDARY_SOURCE_BRIDGE','S4.SS2.SSS0.Px3.p2','Conditional exact sample Y|O~pi_A transports by U=O^T Y to diagonal Gaussian and preserves norm/rotated quadratic form. Outside this minimal C.7/interchange packet.')
n('background.orthogonal_pushforward','BOUNDARY_SOURCE_GAP',None,'Orthogonal Gaussian covariance pushforward and quadratic/norm identities required for later Y|O transport; not supplied by C.7 or the private spectral sum.',used_at=['S4.SS2.SSS0.Px3.p2.1'])
n('citation.openai22','BOUNDARY_PROVENANCE','bib.bib3','Only the in-paper identity of the external [22] preprint and Section9.2 construction analogy are recorded; no external source was fetched or imported.')

e('C7-e1','source.standing rho.literal background.rho_geometry','rho.range','A3.SS3.p2.1','Literal kappa>=2 produces the radius condition and denominator safety.')
e('C7-e2','rho.range background.geometric_complex','C7.geometric','A3.SS3.p2.1 A3.Ex134 A3.Ex135','For every real theta; complex geometric convergence is produced by |rho|<1.')
e('C7-e3','rho.literal source.standing background.rho_geometry','C7.rho_algebra','A3.SS3.p2.2 A3.Ex136','Source literal-rho identities, no free radius parameter or assumed identity.')
e('C7-e4','C7.geometric C7.rho_algebra','C7.combine','A3.SS3.p2.3','Both identities are needed; neither is an alternative route.')
e('C7-e5','C7.combine','C7.pointwise','A3.SS3.p2.3 A3.Ex133','Source proof delivers the all-real-angle pointwise identity.')
e('C7-e6','rho.range background.rho_geometry','C7.domination','A3.Ex137','|cos|<=1 and convergent geometric majorant, uniform on R.')
e('C7-e7','C7.domination background.uniform_convergence','C7.convergence_delivery','A3.SS3.p2.4','Majorant supplies finite tails uniformly in theta, not merely a pointwise bounded partial sum.')
e('C7-e8','C7.convergence_delivery','C7.absolute','A3.SS3.p2.4 A3.Thmtheorem7.p1.2','Absolute convergence conclusion for each real theta.')
e('C7-e9','C7.convergence_delivery','C7.uniform','A3.SS3.p2.4 A3.Thmtheorem7.p1.2','Uniform signed partial-sum convergence on all real theta; no compact-angle restriction.')
e('C7-e10','C7.pointwise C7.absolute C7.uniform','C7.expansion','A3.Thmtheorem7','All three source outputs form the full producer packet. No output moved into premises.')
e('C7-e11','C7.pointwise C7.absolute hard.grid gap.finite_weighted_sum_bridge','C8.interchange','A3.SS3.p4.2','Pointwise identity specialized to literal finite grid, finite cosine-weighted absolutely convergent sums exchanged. Uniform convergence is retained producer output but not a necessary parent for this finite-grid consumer.',frequency_scope='Source author context: M unweighted and mu_n with 1<=n<d. No alias cancellation or Gaussian expectation conclusion supplied by this edge.')
e('C7-e13','moment.definitions hard.grid background.gaussian','C8.trace_moments','A3.SS3.p4.1 A3.Ex140','Boundary expectation identification has separate Gaussian law/integrability input; not discharged by producer or private spectral identity.',edge_context='OUTSIDE_SEALED_PACKET')
e('C7-e14','background.orthogonal_pushforward','moment.transport','S4.SS2.SSS0.Px3.p2.1','Boundary only; full source law/rotation context remains in phase1, not an implied theorem from C.7.',edge_context='OUTSIDE_SEALED_PACKET')

regions=[
('S4.SS1.p1.1','standing d/kappa range; construction citation provenance'),
('S4.E11','literal grid/eigenvalue normalization'),
('S4.Thmtheorem5.p1.1','literal rho and boundary Gaussian/moment/frequency context'),
('A3.SS3.p1','source plan and recalled grid'),
('A3.Thmtheorem7','entire C.7 statement'),
('A3.SS3.2','entire C.7 proof including all substantive paragraphs/displays'),
('A3.SS3.p4','actual finite-grid interchange paragraph and separate expectation-identification boundary'),
('A3.Thmtheorem8','excluded closed-moment source boundary'),
('A3.SS3.p3','excluded finite-grid alias computation boundary'),
('A3.SS3.p5','excluded closed M computation boundary'),
('A3.SS3.p6','excluded product-to-sum/alias/closed mu computation boundary'),
('S4.SS2.SSS0.Px3.p2','separate conditional Gaussian target transport boundary'),
('bib.bib3','citation identity only; external source/backlink targets excluded')]
excluded_region={
 'A3.Thmtheorem8':'C.8 exact closed moments and 1<=n<d range are downstream boundary context; neither formula is supplied by this C.7/interchange packet.',
 'A3.SS3.p3':'Finite midpoint-grid alias identities are a later mathematical ingredient, outside the sealed C.7/interchange packet.',
 'A3.SS3.p5':'Geometric alias resummation to closed M is outside this packet; n=0 private intermediate does not certify it.',
 'A3.SS3.p6':'Vanishing n-mode, product-to-sum, alias-class disjointness/signs and closed mu require later work and source 1<=n<d; outside all-natural-n interchange identity.'}

# Source-graph projection is bounded from the original 77-node raw-source graph.
retained={'hard.grid','moment.definitions','rho.range','C7.expansion','C7.geometric','C7.rho_algebra','C7.domination','C8.trace_moments','C8.interchange','background.geometric_complex','background.uniform_convergence','background.gaussian','moment.transport','background.orthogonal_pushforward','citation.openai22'}
projection=[]
for old in graph1['nodes']:
    key=old['id']
    if key in retained:
        disposition='RETAINED_OR_REFINED'
        reason='Exact bounded source/interface component, convergence/geometry gap, finite-grid consumer, or explicit Gaussian/provenance boundary.'
    else:
        disposition='EXCLUDED'
        reason='Outside minimal C.7 plus p4.2 interchange scope; no result or proof credit inherited.'
    projection.append({'phase1_node_id':key,'disposition':disposition,'reason':reason})
assert len(projection)==77
graph={'schema':'source-only-phase2-C7-v1','status':'FROZEN_SOURCE_COGNITION_WITH_EXACT_INTERFACE_COMPARISON_NO_SOURCE_V',
 'source_sha256':x.EXPECTED,'input_seal_sha256':SEAL_SHA,'phase1_manifest_sha256':PHASE1_SHA,
 'nodes':nodes,'hyperedges':edges,
 'sealed_interface_correspondence_NOT_dependency_graph':[
  {'source_nodes':['C7.pointwise','C7.absolute','C7.uniform'],'sealed_signature_sha256':sealed['producer']['signature_sha256'],'relation':'Exact three source conclusion meanings after positive-index Nat reindexing; no implementation proof or dependency inferred.'},
  {'source_nodes':['C8.interchange'],'sealed_signature_sha256':sealed['actual_private_consumer']['signature_sha256'],'relation':'Source-derived private deterministic weighted-sum intermediate generalized to every natural n. Source M case corresponds to n=0; source mu case later reinstates 1<=n<d and Gaussian expectation bridge. No compiled-use edge or literal all-natural C.8 source theorem asserted.'}],
 'citation_edges':[{'from':'citation.openai22','to':'source.standing','type':'PROVENANCE_NOT_MATHEMATICAL_IMPLICATION','consumer_use_sites':['S4.SS1.p1.1'],'locator':'[22], Section9.2; analogous original construction only'}],
 'AND_OR_audit':{'source_route':'One source C.7 route; pointwise identity and absolute/uniform convergence are conjunctive outputs. No alternative sufficient OR route found.','consumer':'Finite-grid consumer needs the pointwise expansion and absolute summability with the finite-sum bridge; no false AND dependency on uniform convergence.','case_work':'Later C.8 alias case splits are excluded, not OR routes for C.7.'},
 'phase1_projection':projection,
 'external_or_omitted_background_policy':'SOURCE_GAP nodes record source-suppressed mathematical expansions only; not a source-invalid verdict, a proof route, an API-availability guess or a new public hypothesis.'}

mapping={}
for item in nodes:
    for anchor in item['source_anchors']:
        assert anchor in x.ids,anchor
        mapping.setdefault(anchor,[]).append(item['id'])
coverage=[]; anchors=[]; maths=[]; links=[]; region_records=[]; readable=[]; seen=set(); counters={}
def disposition(node,region):
    if region in excluded_region:
        return {'disposition':'EXCLUDED','reason':excluded_region[region]}
    for ancestor in [node,*x.ancestors(node)]:
        if ancestor.attrs.get('id') in mapping:
            return {'disposition':'NODE','node_ids':mapping[ancestor.attrs['id']]}
    return {'disposition':'EXCLUDED','reason':'Structural wrapper or heading; substantive children separately inventoried.'}
for region,purpose in regions:
    root=x.ids[region]
    rec={**x.record(root),'purpose':purpose,'raw_excerpt_file':'raw-'+region+'.html'}
    region_records.append(rec)
    (BASE/rec['raw_excerpt_file']).write_bytes(x.excerpt(root).encode())
    readable.append('===== #'+region+' =====\n'+x.readable(root))
    for item in root.walk():
        assert id(item) not in seen,'Overlapping regions'
        seen.add(id(item))
        base={**x.record(item),'region':region}
        d=disposition(item,region)
        if item.attrs.get('id'): anchors.append({**base,**d})
        classes=item.attrs.get('class','').split()
        kinds=[]
        if item.tag=='p' and 'ltx_p' in classes: kinds.append('paragraph')
        if 'ltx_para' in classes: kinds.append('paragraph-block')
        if 'ltx_equation' in classes or 'ltx_equationgroup' in classes: kinds.append('display-container-or-row')
        if 'ltx_theorem' in classes: kinds.append('theorem-or-fact')
        if item.tag in {'h3','h5','h6'}: kinds.append('heading')
        if item.tag=='cite': kinds.append('citation')
        for kind in kinds:
            counters[(region,kind)]=counters.get((region,kind),0)+1
            disp=d
            if kind=='heading': disp={'disposition':'EXCLUDED','reason':'Heading/label only; mathematical statement/proof content separately inventoried.'}
            if kind=='citation': disp={'disposition':'EXCLUDED','reason':'Construction provenance [22] Section9.2 only; not an external C.7 proof dependency. Reference edge and bibliography identity retained.'}
            if kind=='paragraph-block' and region not in excluded_region:
                children=sorted({a for child in item.walk() for a in disposition(child,region).get('node_ids',[])})
                if children: disp={'disposition':'NODE','node_ids':children,'note':'Container only; all substantive child paragraphs/displays separately covered.'}
            coverage.append({**base,'kind':kind,'locator':item.attrs.get('id') or f'{region}::{kind}[{counters[(region,kind)]}]','readable':x.clean(x.rendered(item)),**disp})
        if item.tag=='math':
            tex=item.attrs.get('alttext','')
            anns=[a for a in item.walk() if a.tag=='annotation' and a.attrs.get('encoding')=='application/x-tex']
            ann=''.join(c for a in anns for c in a.children if isinstance(c,str))
            maths.append({**base,'tex':tex,'tex_sha256':sha(tex.encode()),'annotation_tex':ann,'alttext_equals_annotation':tex==ann,**d})
        if item.tag=='a' and item.attrs.get('href'):
            href=item.attrs['href']
            target=href[1:] if href.startswith('#') else None
            disp=d
            if region=='bib.bib3': disp={'disposition':'EXCLUDED','reason':'Bibliography backlink/catalog locator; target was not fetched or read in phase2.'}
            links.append({**base,'href':href,'text':x.clean(x.rendered(item)),'target_exists_in_pinned_snapshot':target in x.ids if target else None,**disp})

dump('source_graph.json',graph)
dump('phase1_projection.json',projection)
dump('declared_regions.json',region_records)
dump('paragraph_display_citation_coverage.json',coverage)
dump('all_source_anchors.json',anchors)
dump('all_math_anchors.json',maths)
dump('all_source_links.json',links)
(BASE/'readable-excerpts.txt').write_text('\n\n'.join(readable)+'\n')

assessment={
 'scope':'Source-only cognition of exact seal; not source V, theorem admission, implementation verification, proof construction, or API search.',
 'seal_sha256':SEAL_SHA,'producer_signature_sha256':sealed['producer']['signature_sha256'],'private_consumer_signature_sha256':sealed['actual_private_consumer']['signature_sha256'],
 'source_interface_findings':[
 {'item':'Producer pointwise component','finding':'Compatible with full C.7 pointwise claim on every real theta. Nat j+1 indexing and first N terms preserve positive source indices.'},
 {'item':'Producer absolute component','finding':'Summability of real term norms is exactly pointwise absolute convergence. No summability/majorant/radius estimate has become an input premise.'},
 {'item':'Producer uniform component','finding':'Uniform convergence on all real theta of first-N positive-index partial sums to the signed infinite series has the source quantifier order: for every epsilon>0, one eventual N0 works for every theta. Standard reading of source absolutely and uniformly is captured.'},
 {'item':'Uniform-majorant strength','finding':'Source proof supplies a stronger common summable geometric majorant, hence also uniform absolute-tail control. The seal does not expose uniform convergence of absolute-value partial sums or a numerical tail estimate, but neither is a separately asserted C.7 conclusion or needed for this finite-grid interchange. If later consumers require that stronger output, this seal must not be treated as explicitly providing it.'},
 {'item':'Standing/rho/grid definitions','finding':'kappa>=2 is inherited from literal hard-family/C.3 context; producer needs no d. Consumer Fin d index i corresponds to source i+1, so (i.val+1/2)pi/d and eigenvalue normalization agree exactly. hd>=2 remains standing family range.'},
 {'item':'Private consumer mathematical substance','finding':'The planned target is a genuine weighted finite-grid/infinite-series interchange consequence at C.8 p4.2, not a pointwise restatement or a wrapper around an assumed grid identity. It introduces an actual finite spectral sum and exchanged infinite series. Signature alone does not establish that a future proof materially applies the producer or convergence output.'},
 {'item':'All-natural n scope','finding':'All n:Nat is a private generalized intermediate, not the literal C.8 statement. Fixed real cosine weights and finite grid exchange do not invoke the 1<=n<d alias restrictions. n=0 specializes to unweighted reciprocal trace sum but proves no closed moment formula.'},
 {'item':'Future source restrictions','finding':'The source 1<=n<d must return for constant-mode cancellation, support/disjointness of alias classes and exact mu formula. The natural-n interchange cannot discharge those conditions or extend the closed C.8 formula to arbitrary n.'},
 {'item':'Gaussian boundary','finding':'The private sum is deterministic. Identifying it with mu_n (or n=0 with M) still requires U~N(0,Lambda^-1), coordinate second moments/integrability and finite expectation linearity at Ex140; Y|O transport is separate again.'}
 ],
 'binder_assessment':{
  'producer':'Real kappa typing plus source-standing 2<=kappa only. Theta occurs under conclusion forall. Literal rho, radius/denominator safety, absolute summability, uniform convergence and series identity are outputs or internal ingredients, not extra binders.',
  'consumer':'d:Nat and kappa:Real typing, standing d>=2/kappa>=2; n:Nat indexes a deliberately private generalized frequency. Calling n merely TYPING is appropriate only under that private-intermediate interpretation; it cannot erase the source theorem frequency restrictions.',
  'EXCESS_found_in_supplied_signatures':[],
  'definition_scope':'Literal on the admitted source parameter range. Totalized real division/tsum does not justify equations off-range; source-domain denominator and summability facts remain to be produced.'},
 'HOLD_and_open_boundaries':[
  {'class':'NO_SOURCE_INTERFACE_HOLD_IDENTIFIED','scope':'Exact supplied producer and explicitly private generalized finite-grid target, under the meanings above. This is a phase2 assessment, not an approval/status transition.'},
  {'class':'HOLD_ACTUAL_USE_CERTIFICATION','scope':'No implementation/proof was provided or read; actual producer invocation, material summability use and genuine interchange cannot yet be certified.'},
  {'class':'HOLD_IF_PROMOTED_TO_FULL_C8_OR_GAUSSIAN_MOMENTS','scope':'Source 1<=n<d, Gaussian expectation bridge, alias resummation, closed formulas, variance/bias estimates and later testing remain outside this seal.'},
  {'class':'SOURCE_GAP_UNEXPANDED_BACKGROUND','scope':'Geometric/Euler algebra, radius/denominator geometry, convergence from domination and finite weighted sum/interchange are visible graph nodes. No mathematical proof or API availability has been supplied in phase2.'}
 ],
 'independent_next_challenge':'Distinct role should re-read raw bounded regions and exact signatures, independently challenge binders/topology/consumer scope. This author does not certify its own graph.'}
dump('seal_source_comparison.json',assessment)

# Structural QA only; does not review or prove mathematics.
node_ids={item['id'] for item in nodes}
assert len(node_ids)==len(nodes)
for item in nodes:
    for anchor in item['source_anchors']+item.get('used_at',[]): assert anchor in x.ids
for item in edges:
    assert item['consumer'] in node_ids and set(item['parents'])<=node_ids
    assert item['condition_and_scope']
    for site in item['consumer_use_sites']: assert site in x.ids
adj={key:[] for key in node_ids}
for edge in edges:
    for p in edge['parents']: adj[p].append(edge['consumer'])
state={}
def visit(key):
    assert state.get(key)!=1,'Graph cycle: '+key
    if state.get(key)==2:return
    state[key]=1
    for child in adj[key]:visit(child)
    state[key]=2
for key in node_ids:visit(key)
for item in anchors+maths+links+coverage+region_records:
    assert sha(x.blob[item['start_byte']:item['end_byte_exclusive']])==item['raw_sha256']
for item in region_records:
    assert (BASE/item['raw_excerpt_file']).read_bytes()==x.blob[item['start_byte']:item['end_byte_exclusive']]
assert all(item['tex'] and item['alttext_equals_annotation'] for item in maths)
assert all(item['target_exists_in_pinned_snapshot'] for item in links if item['href'].startswith('#'))
assert all(item['disposition'] in {'NODE','EXCLUDED'} for item in coverage)
assert len({item['id'] for item in anchors})==len(anchors)
dump('structural_validation.json',{
 'result':'PASS: pin/projection/artifact structure only; no mathematical verification or source V',
 'phase1_unchanged':{'manifest_sha256':PHASE1_SHA,'all_34_manifested_files_match':True},
 'seal_pin':SEAL_SHA,'producer_signature_sha256':sealed['producer']['signature_sha256'],'consumer_signature_sha256':sealed['actual_private_consumer']['signature_sha256'],
 'counts':{'raw_regions':len(regions),'source_ids':len(anchors),'math':len(maths),'links':len(links),'coverage_records':len(coverage),'graph_nodes':len(nodes),'AND_hyperedges':len(edges),'original_phase1_nodes_dispositioned':len(projection)},
 'checks':['All raw spans/excerpts/hash offsets match pinned source.','Every paragraph/display/citation record has NODE/EXCLUDED.','All math alttext matches annotation.','Every local link resolves.','Node and source-anchor references valid.','Graph acyclic.','Exact supplied signature hashes match.','All original 77 source nodes are retained/refined or explicitly excluded.','Frozen phase1 manifest and all listed artifacts unchanged.'],
 'limits':['No implementation proof or API inspected.','Actual-use certification remains pending.','Distinct topology/binder challenge remains pending.']})
dump('input_exposure_log.json',{
 'phase':'phase2 source-only continuation; phase1 unchanged',
 'new_authorized_input':{'path':str(SEAL.relative_to(REPO)),'sha256':SEAL_SHA,'bytes':SEAL.stat().st_size,'role':'exact sealed signatures and root annotations; annotations independently checked against source, not accepted as verdict'},
 'mathematical_source':{'path':str(RAW.relative_to(REPO)),'sha256':x.EXPECTED,'bytes':len(x.blob),'role':'same sole pinned raw source as phase1; all declared regions read directly'},
 'prior_source_only_artifacts_read':['phase1 manifest and its 34 listed files for unchanged-hash validation only','phase1 extract_source.py as a read-only raw parser with bytecode writes disabled','phase1 source_graph.json for explicit 77-node projection'],
 'inherited_exposure':'Phase1 input/exposure log remains authoritative for ambient labels, process-only AGENTS/protocol reading, broad initial raw searches and incidental Section4.4 snippets. No new non-source implementation exposure added here.',
 'seal_annotation_exposure':['Planned declaration/file names and exact statement signatures read as specifically authorized interface input, not implementation Lean.',
                             'Seal text mentions a prior type-formation parser failure, successful type formation, local spherical Poisson name inventory and planned API retrieval. Their underlying files, receipts, libraries, proofs and logs were not opened, verified or used as mathematical evidence.',
                             'Seal binder/definition labels and actual-use requirement were read, then assessed independently against raw C.7/p4.2; no obligation to agree was assumed.'],
 'new_raw_reads':['Entire C.7 statement and proof; recalled grid; literal source rho/Gaussian/frequency context; entire C.8 p4 and actual p4.2 interchange sentence.','C.8 statement and p3/p5/p6 re-read only to locate the exact future alias/closed-moment boundary.','Post-Lemma4.5 Y|O transport re-read only as separate Gaussian boundary.','Short raw lines identify complete C.7 proof container #A3.SS3.2 and literal standing d/kappa range.'],
 'not_read_or_run':['Implementation Lean files or proofs, Mathlib/ASTIS proof API retrieval, package theorem search','Old Geometry reviews, handoffs, frontier/control-plane ledgers, SAU claim/state tools','Compiler/type-formation receipt or prior failure logs','External preprint [22] or other external source, browser/network, OS UI','Any new mathematical proof, source V, canonical/shared write, commit, subagent or provider/model call'],
 'writes':'Only new phase2 files; frozen phase1 and canonical state untouched.'})
print(json.dumps({'regions':len(regions),'nodes':len(nodes),'edges':len(edges),'coverage_records':len(coverage),'math':len(maths),'phase1_unchanged':True}))
