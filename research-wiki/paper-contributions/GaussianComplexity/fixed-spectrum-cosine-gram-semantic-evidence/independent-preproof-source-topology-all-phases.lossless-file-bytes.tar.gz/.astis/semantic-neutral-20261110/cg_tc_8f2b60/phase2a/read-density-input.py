from pathlib import Path
import hashlib
import json

base = Path(__file__).resolve().parent
source = Path('/Users/zhouhuanjian/ASTIS-GC/.astis/huanjian-gc-fixed-spectrum-cosine-gram-20261110/additional-canonical-Gaussian-density-definitions.json')
b=source.read_bytes()
assert len(b)==1233
assert hashlib.sha256(b).hexdigest()=='1a9fc0110902d684b95e7ceeb50136058a89912aead7eabd46d387a36373599d'
(base/source.name).write_bytes(b)
records=[]
for name in ['additional-canonical-Gaussian-definitions.json',source.name]:
    obj=json.loads((base/name).read_bytes())
    for definition in obj['definitions']:
        literal=definition['literal_definition'].encode()
        actual=hashlib.sha256(literal).hexdigest()
        assert actual==definition['literal_sha256'],definition['name']
        records.append({'package':name,'name':definition['name'],'literal_bytes':len(literal),'literal_sha256':actual,'declared_literal_hash_matches':True})
out='INPUT '+json.dumps({'path':str(source),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})+'\n\n'+b.decode()+'\nLITERAL STRING HASH CHECKS\n'+json.dumps(records,indent=2)+'\n'
(base/'read-density-input.stdout.txt').write_text(out)
(base/'literal-string-hash-checks.json').write_text(json.dumps(records,indent=2)+'\n')
print(out,end='')
