from hashlib import sha256
import json
from pathlib import Path

out = Path(__file__).resolve().parent
manifest = {
    'commit': '1baba1dd32bb79b66a541251f5a16ae6fdc54076',
    'base': '.astis/semantic-neutral-20261110/rm_native_941b_browser_addendum',
    'files': [],
    'privacy': 'Copied receipt and runtime log have unredacted host paths. All original copies retain their byte digests.',
    'reviewer_launched_browser': False,
}
for path in sorted(out.rglob('*')):
    if not path.is_file() or path.name == 'original-files.json':
        continue
    data = path.read_bytes()
    group = 'private_host_specific_original' if path.name.endswith(('.receipt.json', '.log')) and path.parent.name == 'originals' else 'portable_bounded_review_original'
    manifest['files'].append({'path': str(path.relative_to(out)), 'sha256': sha256(data).hexdigest(), 'bytes': len(data), 'custody': group})
target = out / 'original-files.json'
target.write_text(json.dumps(manifest, indent=2) + '\n')
print(len(manifest['files']), sha256(target.read_bytes()).hexdigest())
