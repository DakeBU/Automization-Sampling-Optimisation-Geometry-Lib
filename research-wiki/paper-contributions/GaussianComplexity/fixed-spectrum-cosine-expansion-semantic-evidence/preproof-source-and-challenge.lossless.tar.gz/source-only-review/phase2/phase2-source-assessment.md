# Phase 2: C.7 source projection and exact seal comparison

This capsule compares the exact newly supplied signatures with raw-source cognition. It does not construct a mathematical proof, inspect implementation Lean or proof APIs, issue source V, or certify actual implementation use. The frozen phase1 capsule is unchanged. A different role must still challenge this projection and binder assessment.

The input seal is `GC-FIXED-SPECTRUM-COSINE-EXPANSION-20261109-v1`, SHA-256 `748538057656b235eed54272a87e66f4bf87bdbeb79a9831795b53e72ae74a36`. Its exact producer signature digest is `1e479671bea1fd5c7b287308988d6555b9b729e2f357e30f41ff0d16ff83fc02`; the private-consumer signature digest is `435dade3ec1a9d3a4446827584c927a77ccb1ac0c6e409eaf6850946ca878117`. `seal-input.json` preserves the input bytes. Root-authored binder/meaning annotations were assessed against the source rather than treated as a verdict. The compiler receipt, proof files, failure logs and local-library inventory mentioned by the seal were not opened.

## Source-only assessment

The producer's three conclusion meanings agree with C.7 under the source's ordinary reading of “absolutely and uniformly”: the inverse-spectrum identity for every real angle, absolute convergence at each real angle, and signed-series convergence uniformly over all real angles. No source-interface HOLD was identified for those supplied meanings. This statement is an assessment at the phase2 boundary, not an approval or status transition.

The private finite-grid equation is a substantive mathematical consumer target for the actual sentence `#A3.SS3.p4.2`. It does more than restate the pointwise formula: it identifies an actual finite weighted reciprocal-spectrum sum with an expression in which the infinite series has crossed that finite sum. Its all-natural-frequency scope must remain explicitly a private generalized intermediate. It is not the literal statement of Fact C.8, and it supplies neither Gaussian expectation identification nor C.8's closed moment formulas.

Actual implementation use remains unreviewable here. No proof was supplied or read. A future proof would have to establish its own summability/normalization/interchange ingredients and materially consume the producer; a name, signature, test placement or root annotation cannot certify that event. This is `HOLD_ACTUAL_USE_CERTIFICATION`, not a mismatch in the planned mathematical target.

## Exact producer meaning and binders

Let `kappa>=2` be the hard-family standing range and

\[
r=\frac{\sqrt\kappa-1}{\sqrt\kappa+1},\qquad
a_j(\theta)=(-r)^{j+1}\cos((j+1)\theta),\qquad j\in\mathbb N.
\]

The source Fact C.7 at `#A3.Thmtheorem7` asserts

\[
\forall\theta\in\mathbb R,\quad
\frac2{\kappa+1+(\kappa-1)\cos\theta}
=\frac1{\sqrt\kappa}\left(1+2\sum_{j\ge1}(-r)^j\cos(j\theta)\right),
\]

and absolute and uniform convergence in `theta`. The seal's `j:Nat` mapped to `j+1` enumerates exactly the positive source frequencies. Its first `N` terms are `j=0,...,N-1`, so the uniform output means

\[
\forall\epsilon>0\ \exists N_0\ \forall N\ge N_0\ \forall\theta\in\mathbb R,
\quad\left|\sum_{j=0}^{N-1}a_j(\theta)-\sum_{j=0}^{\infty}a_j(\theta)\right|<\epsilon.
\]

The common threshold precedes all real angles; the seal does not restrict the angle to a compact interval or allow the threshold to depend on it. Summability of real term norms means the source absolute convergence, rather than only convergence of the signed series. The real infinite sum's off-summability default cannot justify the identity; source-domain absolute summability is a produced output.

The full source proof container is `#A3.SS3.2`. Paragraph `p2.1` invokes the geometric-series identity with produced `0<r<1`, displays `#A3.Ex134`–`#A3.Ex135`, and obtains the rational cosine-series expression. Paragraph `p2.2` and `#A3.Ex136` give the two literal-rho normalization identities. Paragraph `p2.3` combines them for the pointwise expansion and introduces the majorant display `#A3.Ex137`. Paragraph `p2.4` concludes absolute and uniform convergence. Every paragraph and display has a NODE disposition in this capsule; the proof heading is explicitly excluded as typography. There is no external citation inside this C.7 proof.

The source majorant is stronger information than just bounded partial sums:

\[
\sum_{j\ge1}|(-r)^j\cos(j\theta)|\le\sum_{j\ge1}r^j=\frac r{1-r},
\]

with a common summable geometric majorant. The unnamed passage to uniform tail control is retained as a convergence-gap node. It also supports uniform absolute-tail control. The supplied signature does not separately expose a numerical tail bound or uniform convergence of absolute-value partial sums; those stronger outputs must not silently be credited to its interface. They are not separately asserted C.7 conclusions or needed by the present finite-grid use, so this distinction is not a source-interface HOLD for the exact packet.

The producer has only real-parameter typing and the standing `2<=kappa` premise. `theta` is quantified in the conclusion. Dimension is irrelevant to this all-real-angle formula, so its omission does not change C.7's meaning. Principal-square-root/radius/denominator facts, geometric algebra, absolute summability and uniform convergence are produced ingredients. No such conclusion has become a premise.

## Actual finite-grid consumer and its scope

With source index `i=1,...,d`, the grid is `theta_i=(i-1/2)pi/d` and `lambda_i=(kappa+1)/2+(kappa-1)cos(theta_i)/2`. In the private signature `Fin d` starts at zero; mapping its `i` to source `i+1` gives exactly `(i.val+1/2)pi/d`. The eigenvalue expression and reciprocal-spectrum normalization agree with the source. `d>=2` and `kappa>=2` remain literal standing ranges. No assumed reciprocal identity, summability condition or eigenvalue bound appears in the private target's premises.

The planned equation has the deterministic form

\[
\sum_i\frac{\cos(n\theta_i)}{\lambda_i}
=\frac1{\sqrt\kappa}\left[
\sum_i\cos(n\theta_i)
+2\sum_{j\ge1}(-r)^j\sum_i\cos(n\theta_i)\cos(j\theta_i)\right].
\]

This is the source-suppressed weighted finite-grid exchange at `p4.2`. It is a genuine mathematical consumer target because the finite weighted sum and reordered infinite sum introduce a nontrivial operation absent from the pointwise producer conclusion. Calling the target private or placing it in a test file does not itself establish that a future implementation makes this use.

The finite grid needs the pointwise expansion and absolute summability. C.7's uniform convergence remains a required producer output, but it is not a necessary extra dependency for exchanging this particular finite grid. The source graph therefore does not draw a false AND edge from uniform convergence into that exchange. The geometric/radius gap, convergence gap and weighted finite-sum/interchange gap remain visible, with their actual raw use sites.

For each natural `n`, the weights are fixed finite real cosines; the exchange itself does not invoke frequency cancellation or alias-class disjointness. Thus all-natural `n` is compatible with an explicitly private generalization of this intermediate. `n=0` gives the unweighted reciprocal-spectrum sum used for the trace. It does not yield the closed `M` formula. The seal's `n:Nat` binder can be called typing only in this private-intermediate sense; it cannot remove the source C.8 restriction from a source-facing closed-moment claim.

Fact C.8 explicitly states `1<=n<d`. Its later paragraph `p6.1` uses the vanishing n-mode, and `p6.2` uses that range for the three alias classes and their disjointness/sign bookkeeping. Those steps and the resummations at `p5` and `p6` are outside this minimal packet. The all-natural interchange cannot discharge the later source range or certify its closed formulas.

Paragraph `#A3.SS3.p4.1` separately identifies `E U_i^2=1/lambda_i` and `#A3.Ex140` identifies `M` and `mu_n` with finite spectral sums. That bridge requires the actual law `U~N(0,Lambda^{-1})`, Gaussian second moments/integrability and finite-sum expectation linearity. None is established by the private deterministic equation. The conditional target-sample transport `Y|O` to `U=O^T Y` at `#S4.SS2.SSS0.Px3.p2.1` is a further separate boundary. Promoting this packet to actual Gaussian moments or full C.8 would therefore trigger a HOLD.

## Bounded graph and coverage

`source_graph.json` contains a C.7/p4.2 source subgraph: 24 nodes, 13 AND hyperedges, one separately typed construction-provenance edge, and an explicit disposition of each original phase1 node. All 77 original nodes are retained/refined or excluded; their full graph is not rebuilt. Sealed-interface correspondences are a separate record, not source proof implication or compiled-use edges. No alternative sufficient OR route appears in this source slice.

Thirteen nonoverlapping raw regions preserve the full C.7 statement/proof, literal parameter/grid/rho context, actual p4.2 consumer, and the exact future alias/Gaussian boundaries. The later C.8 theorem, `p3`, `p5` and `p6` are preserved but explicitly EXCLUDED from this packet's mathematical work. Their paragraphs/displays do not disappear. The only external citation encountered is the Section4.1 construction analogy to [22]; its bibliography identity is preserved, but the external work and backlink targets were not opened.

Every paragraph, display, citation and theorem/fact in these regions has NODE or EXCLUDED disposition. Exact source ids, math/link anchors, source byte spans and hashes are retained. Structural checks confirm pins and artifact correspondence only. The source-only graph still needs the distinct topology/binder challenge; this capsule does not approve itself.
