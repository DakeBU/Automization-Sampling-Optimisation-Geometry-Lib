# Bounded independent source topology verdict

I accept the corrected topology for the exact bounded pair. The original graph requires the attached deltas. The exact signatures need no repair, and the reviewed binders contain no EXCESS proof ingredient. This approval concerns source correspondence and mathematical dependency structure. Formal proof status is outside this review.

This review continues the interrupted challenge under recovery identity `re_tc_recovery_1d3c`. The original challenger froze the raw reconstruction (`50208c71a2b13245e70ea68b5fdb2a65a73b039eef4b034caa14438460a48d83`) and independent literal-type judgment (`cbd6252a196d9c716cf5285561d611e314bd9c79fcc0534e4a3e82676df5a0a3`) before graph exposure. Their manifests carry that exposure record. This recovery compared those frozen results against the already exposed SG graph, overlay and coverage and checked the relevant raw anchors. I relied on the original raw inventory for scope and on the supplied literals for library definitions.

## Exact interfaces

- **P** `7b27efe79e0ebbc31760b1e4bb17e8591bbca4335e35fd3fdbe4c642ee50c6b3` returns both integrability of $z\mapsto\exp(\lVert z\rVert^2/3)$ under `stdGaussian E` and its real integral $3^{(\operatorname{finrank}_{\mathbb R}E:\mathbb R)/2}$. The universe, finite-dimensional real inner-product space, and compatible Borel measurable structure are TYPING. The law is the fixed pushforward of the normalized variance-one coordinate Gaussian product through orthonormal synthesis. The result supplies integrability itself, so the Bochner integral is evaluated on its integrable branch.
- **T** `3dc0457798c1b594a16ad8f7ab8e863d8cd469c9fe0b940550e05a23cdd2d94a` has TYPING $d,q\in\mathbb N$ and STANDING $2q+1<d$. It uses `stdGaussian` on `EuclideanSpace ℝ (Fin (q + 1))` with its `PiLp` Euclidean norm and $L=2(q+1)+3\log(1000d)$. The conclusion is the strict one-row measure bound for $L<\lVert z\rVert^2$, with the positive finite reciprocal $1/(1000d)$ embedded into ENNReal. Here $r=q+1\ge1$, $d\ge2$, $2r\le d$, and $x_0=\log(1000d)\ge0$. The case $q=0$ has $r=1$, $L=2+3\log(1000d)$, and P's value is $\sqrt3$. Equality at $L$ belongs to the good event.

## Immediate repairs

1. `e-a` takes `L-definition` and `row-definition-law` directly. The measurable scalar $R_i\mathbf1_{R_i\le L}$ lies in $[0,L]$ on the Gaussian probability space, so it is integrable. Equality of the marginal laws gives the common value of $a=r^{-1}\mathbb E[R_i\mathbf1_{R_i\le L}]$.
2. `e-symmetry` uses the same $R_i,L$ and radial law for truncated covariance. Its entries are integrable since $|\gamma_{ij}\gamma_{ik}|\le R_i$ on the good event and their truncated values vanish off that event. Orthogonal invariance makes the matrix a scalar multiple of the identity, and the trace identifies $a$. Both truncated-expectation edges drop the untruncated `second-moment` premise. `e-scalar-bias` retains it because $\mathbb E R_i=r$ gives $a\le1$ by domination and gives $1-a$ by splitting the two indicators. The paper uses $a\le1$ again at p13 to obtain $\|\mathbb E Y_i\|_{\mathrm{op}}=a\|t_i\|^2/d\le2r/d$. The new context edge records that single downstream use in the excluded matrix branch.
3. `bridge-canonical-law` now describes generic normalized Gaussian orthonormal transport. `bridge-source-row-law` records the identification of a paper marginal with the canonical Euclidean measure. This identification supports downstream transfer of T to each paper row. P and the canonical proof of T use their fixed measures directly. The descriptive source/type correspondences retain their source anchors.
4. `T-use-P` now explicitly requires the positive-real-base rpow rewrite. In this route `finrank ℝ (EuclideanSpace ℝ (Fin (q+1))) = q+1` specializes the exponent. The coordinate norm formula identifies the paper observable when transferring the canonical result.

## Routes and proof ingredients

The positive-dimensional P calculation needs measurable squared norm and exponential and the normalized standard Gaussian under orthonormal coordinates. The density route multiplies the standard density by the exponential, leaving quadratic exponent $-\|z\|^2/6$, and rescales by $z=\sqrt3\,y$. Its Jacobian gives $3^{m/2}$, where $m=\operatorname{finrank}_{\mathbb R}E$. The product route integrates nonnegative coordinate factors using the product law and the finite one-dimensional integral $\mathbb E e^{Z^2/3}=\sqrt3$ for $Z\sim N(0,1)$. Both routes establish finiteness and the real integral. The branches are OR alternatives within positive dimension. The paper asserts the moment and leaves those derivations implicit.

For P at finrank zero, `Fin 0` has an empty coordinate tuple with mass one under the empty product. Orthonormal synthesis is the empty sum, so the pushforward is Dirac at zero. The exponential is $1$ there, its integral is $1$, and the positive-real power is $3^0=1$. This additional case covers the generalized producer. The paper row and T always have $r\ge1$.

In the planned P-to-T route, specialize P to T's carrier and apply exponential Markov with threshold $\exp(L/3)>0$. Strict monotonicity identifies the strict event. The integrable nonnegative exponential and the appropriate real-to-ENNReal measure inequality are proof ingredients. The positive-base real power rewrites via $3^{r/2}=\exp((r/2)\log 3)$. Combining with the threshold exponential gives

$$
3^{r/2}\exp(-L/3)
=\frac{\exp(r((\log 3)/2-2/3))}{1000d}
\le \frac{1}{1000d}.
$$

The comparison uses $r\ge0$ and $(\log3)/2<2/3$. The latter follows, for example, from $e^{4/3}>1+4/3+(4/3)^2/2=29/9>3$. The half-dimension is divided in $\mathbb R$. Denominator positivity justifies the reciprocal and ENNReal conversion. The source graph retains the more general Markov argument at each real $x\ge0$. The exact T uses only $x=x_0$.

## Residual obligations and scope

- T supplies the canonical marginal at literal $L$. Apply the separate law bridge for each paper row, then use the finite union bound over $d$ rows to obtain the paper good event with probability at least $0.999$. This uses matching marginals and needs no across-row independence.
- The full $x\ge0$ tail, the shifted tail for real $s\ge0$, the nonnegative tail integral, and the bias remain additional obligations. The shifted tail uses $x=x_0+s/3$ and yields $e^{-s/3}/(1000d)$. Layer cake gives $\mathbb E[R_i\mathbf1_{R_i>L}]=L\Pr(R_i>L)+\int_0^\infty\Pr(R_i>L+s)\,ds$. Integrating the exponential bound gives the factor $3$ and hence $(L+3)/(1000d)$. The separate second moment gives $1-a\le(L+3)/(1000rd)$.
- At p17 the good event equates original and truncated sums, and intersects with two matrix estimates to give $1-0.001-0.004=0.995$. The scalar bias contributes to the unweighted norm bound. The graph leaves the excluded matrix branch, Fact C.5, full Fact C.6, full Lemma 4.4 and the separating-test conclusion outside this pair. Row independence, fourth moments, matrix Bernstein, cosine structure, and the target sampling law have no incoming role in P or T.

This is a digest-bound topology correction and review of the frozen source and literal evidence. The recovery supplies no new source-blind phase, retrospective whole-run cleanliness claim, Lean proof inspection, elaboration, compiler dependency evidence, VERIFIED result, or SAU transition.
