# Phase 3 actual inputs, execution, exposure and freeze limits

This role first froze its own raw cognition, then its selective type/definition/
decoder comparison, before root authorized full implementation exposure.
Phase1/phase2 payloads were not modified. All 108 and 25 respective payloads,
manifest hashes, file modes0444 and directory modes0555 were rechecked.
The role is now code-exposed, not source-blind/pristine. General pretrained
knowledge is not excluded. Independence here means separate from the formalizer
and decoder, with the original cognition retained before exposure.

Authorized mathematical inputs are the exact full reviewer packet; six known
candidate Git paths P/T/lesson/publication/source-to-lean-map/G; the earlier
pinned raw source and phase1/2; and necessary actual Mathlib definitions/proofs.
No repository-wide search, agent/role inventory, other workspace, retired
reviewer, existing SourceV/ledger record, SG/TC verdict, root process result,
native output or other E artifact was opened. Mathlib symbol searches were
bounded to the relevant Gaussian/Moments/Function folders and explicit named
files. No internet lookup or Lean/build/test process was run by this role.
No canonical content was changed. Every write is under cg_src_7e41d9.

The authorized source-to-lean proposal itself contains raw-graph/typed-overlay
lineage hashes, native-log filename/hash, a proposed private kernel name and
compiler/provider counts. Those supplied metadata were exposed because the
authorized map includes them. Their underlying files/results were not read;
they were not used as independent compiler, kernel-dependency or whole-graph
evidence. The map's mathematical correspondences and literal locators were
checked against actual code/raw source. Its lineage and generated counts were
not independently certified. The packet likewise includes supplied compiled,
decoder-blindness, toolchain/dependency and binding metadata; these were not
converted into this role's execution claims.

The initial authorized-candidate read preserved all exact raw inputs and printed
255351 bytes. The native exec response reported a 63978-token original output
and truncation; the outer tool also displayed a further truncation warning.
The complete real subprocess stdout is authorized-candidate.stdout, SHA256
e3d9b35da2fd01da8f0d90e0f3a910adf31ae54353606329f2b8c9dd5f52044d.
Full P/T, lesson, publication, relevant packet fields and compact complete
proposal correspondences were then read separately. The full-packet-context
display reported truncation (7219 original tokens); its long repeated lesson
was independently read in full and checked equal. The map-nodes-proposal
display reported truncation (10747 original tokens, with an outer truncation
warning); all 24 canonical rows and all 29 correspondences were subsequently
read in the untruncated compact verification output. Original streams retain
the complete earlier content; no complete-reading claim is based on a
truncated preview alone.

The first auxiliary symbol-search launch attempted /usr/bin/rg, which does not
exist in this environment. Popen raised FileNotFoundError before the capture
wrapper could create a child-process receipt; no child command ran. The native
tool's observed combined traceback and exact argv are copied in
launch_failure_observed.txt. Separate stdout/stderr were not observable for
that wrapper failure, and no fake return code or empty-stderr receipt was
invented for a nonexistent subprocess. Retrying the same bounded search with
`rg` resolved it and exited0; its actual raw streams are captured separately.
All actual *captured child subprocesses* in actual_commands.jsonl exited0.
The failure is environmental/executable-path only, not negative mathematics.

The initial packet digest experiment hashed the entire parsed JSON including
its packet_sha256 field, so it did not equal that field. The later correct
canonical calculation excludes that self-field, yielding the supplied68eb...
digest exactly. This is not a packet mutation or semantic mismatch. The
publication binding is still supplied metadata: exact module/lesson/publication
content projections were independently matched, but the full publication tool
hash material was not reconstructed. The empty earlier hash-scheme result is
retained, as is the subsequent successful computation.

Actual subprocess argv/cwd/returncode/separate raw stdout and stderr, byte
lengths and SHA256 are retained by capture_phase3.py. Nested git-show inputs
record exact argv, original blobs and real stderr streams in input_inventory.
Nested git-rev-parse records exact raw stdout/stderr in candidate-parent files
and final_structural_verification.json. Mathlib raw file snapshots and hashes
are retained independently, with exact displayed read ranges where applicable.
The complete Gaussian.Multivariate module was displayed; it includes some
adjacent standard-library results beyond the used mean/covariance path. This
was source context, not another task's evidence or implementation.

The six folded step code strings were byte-matched directly against the
immutable P/T blobs, not trusted from the map. All57 map byte/character/line
slice locators and26 original-source anchor hashes/IDs were checked; mathematical
correspondence was then separately assessed by this reviewer. Hash agreement
alone was never treated as mathematical equivalence or proof acceptance.

The freeze manifest will hash phase3 payloads, excluding itself and its receipt.
The receipt hashes manifest plus both own mathematical judgments. Actual final
freeze stdout/stderr/exit is captured outside phase3 at the role root and binds
the receipt. Thus there is no self-hash or mutual manifest/receipt cycle.
All phase3 files become0444 and its directories0555. No later SourceV/ledger
action or canonical-content repair is authorized by this artifact itself.
