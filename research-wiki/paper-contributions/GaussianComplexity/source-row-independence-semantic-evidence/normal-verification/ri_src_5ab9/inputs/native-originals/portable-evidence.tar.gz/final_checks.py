import json,pathlib
from run import ROOT,REPO,run,sha
m=json.loads((ROOT/'input-manifest.json').read_text());tracked=[]
for p,v in m['files'].items():
    if p.startswith('private:'):continue
    b=(REPO/p).read_bytes();assert sha(b)==v['sha256'] and len(b)==v['bytes'],p
    tracked.append({'path':p,'sha256':v['sha256'],'bytes':v['bytes']})
for d in m['dependencies']:
    path=REPO/'.lake/packages'/d['name']
    h=run('package-final-'+d['name']+'-head',['git','rev-parse','HEAD'],cwd=path)
    s=run('package-final-'+d['name']+'-clean',['git','status','--porcelain=v1','--untracked-files=all'],cwd=path)
    assert h.returncode==s.returncode==0 and h.stdout.decode().strip()==d['head'] and not s.stdout
assert sha(pathlib.Path(m['lean_binary']['path']).read_bytes())==m['lean_binary']['sha256']
probe=m['files']['private:SourceRowIndependenceKernelProbe.lean'];assert sha((REPO/probe['origin']).read_bytes())==probe['sha256']
head=run('head-final',['git','rev-parse','HEAD']);assert head.returncode==0
loc=json.loads((ROOT/'locator-checks.json').read_text())
result={'compile_candidate_only':m['candidate_commit'],'HEAD_at_comparison':head.stdout.decode().strip(),'later_carrier_compilation_claimed':False,'all_tracked_relevant_inputs_equal_to_candidate_at_final':True,'tracked_relevant_input_hashes':tracked,'private_author_probe':probe,'source_raw':{'path':'.astis/huanjian-resume-20261103/2610.20492v1.html','sha256':loc['source_raw_sha256']},'native_binary':m['lean_binary'],'manifest_sha256':m['files']['lake-manifest.json']['sha256'],'all_9_packages_pinned_and_clean_including_untracked_at_final':True,'held_carrier_rule':'Compare every listed byte hash, package pin/clean state, author probe and binary before reusing bounded evidence on any later metadata carrier. Native compilation credit remains 66e0 only.','mutations':'Only assigned audit directory; no Git, shared source, ledger, Registry, import, root Tests, metadata, UI or push changes.'}
(ROOT/'relevant-input-binding.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'tracked_relevant_inputs':len(tracked),'HEAD':result['HEAD_at_comparison'],'all_equal':True}))
