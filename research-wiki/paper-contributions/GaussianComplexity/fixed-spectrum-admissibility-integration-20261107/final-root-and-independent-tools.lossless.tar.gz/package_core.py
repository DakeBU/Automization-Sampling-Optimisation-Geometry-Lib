from pathlib import Path
import json,hashlib,gzip,tarfile,subprocess,shutil
sha=lambda b:hashlib.sha256(b).hexdigest()
b=Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-admissibility-integration-20261107')
checks=b/'actual-checks';checks.mkdir(exist_ok=True)
for label in ['fixed-spectrum-admissibility-package-independent-source-V','fixed-spectrum-admissibility-claim-sole-STAB','fixed-spectrum-admissibility-apply-reviewed-shared']:
 p=sorted(Path('.astis/huanjian-resume-20261103').glob('*-'+label+'.receipt.json'))[-1];r=json.loads(p.read_bytes());raw=Path(r['log']).read_bytes();assert r['exit_code']==0 and sha(raw)==r['log_sha256'];shutil.copy2(p,checks/p.name);z=checks/(Path(r['log']).name+'.gz');z.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(z.read_bytes())==raw
private=Path('.astis/huanjian-gc-fixed-spectrum-admissibility-integration-20261107');files=sorted(p for p in private.iterdir() if p.is_file());archive=b/'core-root-tools.lossless.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz') as t:
 for p in files:t.add(p,arcname=p.name,recursive=False)
with tarfile.open(archive,'r:gz') as t:
 for p in files:assert t.extractfile(p.name).read()==p.read_bytes()
manifest=b/'core-root-tools.manifest.json';manifest.write_text(json.dumps({'archive':str(archive),'sha256':sha(archive.read_bytes()),'files':[{'path':str(p),'member':p.name,'sha256':sha(p.read_bytes())} for p in files]},indent=2)+'\n')
lineage=b/'immutable-source-phase-lineage.json';lineage.write_text(json.dumps({'mathematical_candidate':'2df0cd116cd21a71113ae67997b7482878633460','independently_checked_commit_with_blind_audit':'83fec39dfa6202cdf9bc687affb10aafbc216ab8','accepted_audit_first_carrying_commit':'96a6da3fe9d7fbe17af5624552a1152743587150','first_commit_with_both_accepted_audit_and_independent_normal_V_append':'4c1c45f7cecb6ac2351d328899848766c1683eb8','same_production_Test_lesson_publication_binding':True,'source_V_append_sha256':'beff8c6b9922a11027d25118f6f771bad79a1d3e966126c4cf79eecce498d032','truth_boundary':'No checked-tree audit-byte equality or new build at metadata successors is claimed. Canonical core real gates and final reader acceptance are next.'},indent=2)+'\n')
plan=json.loads((b/'independent-integration-reader-review/proposal/proposal-report.json').read_bytes())
paths=[Path(row['path']) for row in plan['shared_paths']]+[Path('runs/substantive_advances.jsonl'),b/'normal-stab-claim.json',b/'normal-stab-claim-ledger-prefix.jsonl.gz',b/'shared-integration-manifest.json',archive,manifest,lineage,*[p for p in checks.iterdir() if p.is_file()]]
subprocess.run(['git','add','--',*[str(p) for p in paths]],check=True)
r=subprocess.run(['git','diff','--cached','--check'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT);print(r.stdout.decode());assert r.returncode==0
assert subprocess.check_output(['git','show',':runs/substantive_advances.jsonl'])==Path('runs/substantive_advances.jsonl').read_bytes()
print(json.dumps({'shared_paths':6,'exact_current_ledger_staged':True,'sourceV_existing_only':True,'canonical_gates_pending':True}))
