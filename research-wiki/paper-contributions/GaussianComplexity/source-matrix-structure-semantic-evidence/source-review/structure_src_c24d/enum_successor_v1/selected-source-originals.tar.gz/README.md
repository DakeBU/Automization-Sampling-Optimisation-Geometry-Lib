# Enum-only source-review successor

Current immutable reader: `7c364dbeaf44c1f23defe10534e6cd3dffdac172`. Current P/T canonical reviewer packets are v4.

The exact delta changes only the source wording-status metadata from the invalid longer label to the permitted `faithful paraphrase`, plus the resulting context/packet hashes. Substantive source, Lean, assumption, formula, proof, source-map and anonymous decoder contents are unchanged. The current accepted canonical P/T overlays explicitly reuse the unaltered seven-slot v3 source judgment, with original and current review-run hashes.

`originals/` contains selected exact original raw-source/reviewer/decoder artifacts. The original phase1/2/3 closed archives remain at their prior locations and all 34/63/102 listed files were checked unchanged. Their copied manifests are provenance originals; this selected portable successor does not pretend to recursively include every old archive file. `portable-selected-closed-manifest.json` closes every file actually included in this successor, using relative paths.

The initial enum locator command also named a missing unrelated helper path and returned exit 2; its unfiltered failure is retained. The exact validation enum was then read from `tools/astis_publication.py`.

This review neither retroactively asserts that the earlier invalid-enum admission passed nor certifies current gate/build/native/layout/graph/normal-verification success. Private T receives no public API credit. No canonical files or old reviewer archives were edited.
