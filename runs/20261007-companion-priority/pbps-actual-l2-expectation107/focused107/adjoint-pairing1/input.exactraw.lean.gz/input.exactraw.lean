import Mathlib.MeasureTheory.Function.L2Space
import Mathlib.MeasureTheory.Integral.Prod
import Mathlib.Analysis.InnerProductSpace.Adjoint

open MeasureTheory
open scoped ENNReal InnerProductSpace
noncomputable section
set_option autoImplicit false
set_option maxHeartbeats 1200000

namespace PBPSActualL2Average107

theorem adjoint_contraction_pairing
    {α β : Type*} [MeasurableSpace α] [MeasurableSpace β]
    (μ : Measure α) (ν : Measure β) [IsProbabilityMeasure μ] [IsProbabilityMeasure ν]
    (Z : α × β → α) (hZ : MeasurePreserving Z (μ.prod ν) μ) :
    ∃ A : Lp ℝ 2 μ →L[ℝ] Lp ℝ 2 μ, ‖A‖ ≤ 1 ∧
      ∀ f g : Lp ℝ 2 μ,
        ⟪f, A g⟫_ℝ = ∫ p : α × β, f p.1 * g (Z p) ∂μ.prod ν := by
  have hfst : MeasurePreserving Prod.fst (μ.prod ν) μ := by
    refine ⟨measurable_fst, ?_⟩
    simp only [Measure.map_fst_prod, measure_univ, one_smul]
  let B : Lp ℝ 2 μ →L[ℝ] Lp ℝ 2 (μ.prod ν) :=
    (Lp.compMeasurePreservingₗᵢ ℝ Prod.fst hfst).toContinuousLinearMap
  let C : Lp ℝ 2 μ →L[ℝ] Lp ℝ 2 (μ.prod ν) :=
    (Lp.compMeasurePreservingₗᵢ ℝ Z hZ).toContinuousLinearMap
  let A : Lp ℝ 2 μ →L[ℝ] Lp ℝ 2 μ := B.adjoint.comp C
  have hB : ‖B‖ ≤ 1 := LinearIsometry.norm_toContinuousLinearMap_le _
  have hC : ‖C‖ ≤ 1 := LinearIsometry.norm_toContinuousLinearMap_le _
  refine ⟨A, ?_, ?_⟩
  · calc
      ‖A‖ ≤ ‖B.adjoint‖ * ‖C‖ := ContinuousLinearMap.opNorm_comp_le _ _
      _ = ‖B‖ * ‖C‖ := by rw [ContinuousLinearMap.adjoint.norm_map]
      _ ≤ 1 * 1 := mul_le_mul hB hC (norm_nonneg _) zero_le_one
      _ = 1 := one_mul 1
  · intro f g
    change ⟪f, B.adjoint (C g)⟫_ℝ = _
    rw [ContinuousLinearMap.adjoint_inner_right, L2.inner_def]
    have hb : (B f : α × β → ℝ) =ᵐ[μ.prod ν] (fun p => f p.1) :=
      Lp.coeFn_compMeasurePreserving f hfst
    have hc : (C g : α × β → ℝ) =ᵐ[μ.prod ν] (fun p => g (Z p)) :=
      Lp.coeFn_compMeasurePreserving g hZ
    apply integral_congr_ae
    filter_upwards [hb, hc] with p hp hq
    rw [hp, hq]
    simp [RCLike.inner_apply, mul_comm]

#print axioms adjoint_contraction_pairing
end PBPSActualL2Average107
