"""Run unchanged candidate render_unit/inline disclosure against only candidate P/T/G."""
import dataclasses, html, json, re, sys, types
from html.parser import HTMLParser
from verify import *

for rel in ['tools/astis_site.py','tools/astis_source.py','website/scripts/declaration_lessons.py','website/scripts/inline_lean.py']:
    b=blob(rel); assert (D/'inputs'/rel).read_bytes()==b
sys.path[:0]=[str(D/'inputs/tools'),str(D/'inputs/website/scripts')]
# render_unit never calls source_lineage. Do not import its unrelated global generators.
sys.modules['source_lineage']=types.ModuleType('source_lineage')
import astis_site as base, declaration_lessons as lessons, inline_lean
base._ACTIVE_GIT=base.GitContext(commit=C,ref='isolated-candidate',remote_url='',web_root='',
    commit_published=False,public_source_links=False,dirty_files=set())
modules,declarations=base.scan_project_sources()
assert {m.source_file for m in modules}=={P,T,G}
base._SOURCE_BY_NAME={d.full_name:d for d in declarations}
unit=json.loads((D/'inputs'/L).read_text())['units'][0]
page=lessons.lesson_path(unit['declaration'])
rendered=lessons.render_unit(unit,page)
put('static/'+page,rendered)
js('static-render-inputs.json',{'candidate':C,'page':page,
    'unchanged_production_functions':['declaration_lessons.render_unit','inline_lean.disclosure',
      'inline_lean.split_statement','astis_site.code_html','astis_site.lean_source_actions','astis_site.source_href'],
    'bounded_scanned_sources':[m.source_file for m in modules],
    'unused_import_stub':'source_lineage (unused by render_unit); no global renderer or shell invoked',
    'global_owner_released':False,'output':'HTML fragment only; no browser or MathJax acceptance'})

class Node:
    def __init__(self,tag,attrs=None,parent=None): self.tag,self.attrs,self.parent,self.children=tag,dict(attrs or []),parent,[]
    def text(self): return ''.join(c if isinstance(c,str) else c.text() for c in self.children)
    def descendants(self,tag=None):
        found=[]
        for c in self.children:
            if isinstance(c,Node):
                if tag is None or c.tag==tag: found.append(c)
                found+=c.descendants(tag)
        return found
    def cls(self,c): return c in self.attrs.get('class','').split()
class DOM(HTMLParser):
    def __init__(self): super().__init__(convert_charrefs=True); self.root=Node('root'); self.stack=[self.root]
    def handle_starttag(self,tag,attrs):
        n=Node(tag,attrs,self.stack[-1]); self.stack[-1].children.append(n)
        if tag not in ['meta','img','input','br','hr','link']: self.stack.append(n)
    def handle_endtag(self,tag):
        assert self.stack[-1].tag==tag,(self.stack[-1].tag,tag)
        self.stack.pop()
    def handle_data(self,data): self.stack[-1].children.append(data)
dom=DOM(); dom.feed(rendered); assert len(dom.stack)==1
steps=[n for n in dom.root.descendants('details') if n.cls('proof-reader-step')]
assert len(steps)==6
checks=[]
for ix,(node,step) in enumerate(zip(steps,unit['steps']),1):
    folds=[n for n in node.descendants('details') if n.children[0].tag=='summary' and n.children[0].text()=='Corresponding Lean step']
    assert len(folds)==1
    fold=folds[0]; code=fold.descendants('code'); assert len(code)==1
    formula=[n for n in node.descendants('div') if n.cls('proof-reader-equation')]
    assert len(formula)==1
    c={'step':ix,'title':step['title'],'outer_initially_closed':'open' not in node.attrs,
        'code_initially_closed':'open' not in fold.attrs,'exact_code':code[0].text()==step['lean'],
        'exact_formula':formula[0].text()=='\\['+step['formula']+'\\]',
        'copy_neighbor':any('data-lean-copy' in n.attrs for n in fold.descendants('button')),
        'download_neighbor':any('download' in n.attrs for n in fold.descendants('a')),
        'exact_module_source_neighbor':any('Exact module and namespace context'==n.text() for n in fold.descendants('a')),
        'code_bytes':len(code[0].text().encode()),'code_sha256':sha(code[0].text().encode()),
        'direct_inner_tags':[n.tag for n in fold.children if isinstance(n,Node)]}
    assert all(c[k] for k in ['outer_initially_closed','code_initially_closed','exact_code','exact_formula'])
    checks.append(c)
tbytes=(D/'inputs'/T).read_bytes()
assert checks[5]['code_sha256']==sha(tbytes) and checks[5]['code_bytes']==7494
assert tbytes.decode().splitlines()[12].startswith('private theorem actual_gaussian_gram_means')
standalone=[]
for fold in [n for n in dom.root.descendants('details') if n.cls('inline-lean')]:
    standalone.append({'role':fold.attrs['class'],'initially_closed':'open' not in fold.attrs,
       'copy_neighbor':any('data-lean-copy' in n.attrs for n in fold.descendants('button')),
       'download_neighbor':[n.attrs['href'] for n in fold.descendants('a') if 'download' in n.attrs],
       'source_neighbor':[n.attrs['href'] for n in fold.descendants('a') if n.text()=='Exact module and namespace context']})
assert len(standalone)==2
source_citations=[n.attrs['href'] for n in dom.root.descendants('a') if n.text()=='Complete actual Gaussian Gram application']
assert source_citations==['../data/lesson-sources/'+T+'.html#L13']
result={'candidate':C,'authored_claim_exact':unit['statement'] in html.unescape(rendered),
    'all_assumptions_present':all(a in html.unescape(rendered) for a in unit['assumptions']),
    'six_code_and_formula_folds':checks,'standalone_statement_proof':standalone,
    'step6_entire_actual_T_bytes':7494,'private_theorem_actual_start_line':13,
    'consumer_source_citation':source_citations,
    'reader_delivery':'HOLD','hold_reason':'All six production-rendered Corresponding Lean step disclosures lack adjacent copy/download/module-source controls. Step6 has the exact whole Tests file but no such neighbors. Only the standalone public statement/proof folds have those controls. No renderer changes are authorized while global ownership is unreleased.',
    'browser_MathJax_desktop_mobile':'NOT_TESTED; no static inference of acceptance',
    'source_fidelity_verdict':'not issued by this verifier'}
js('static-reader-findings.json',result)
scan=[]
for rel in [P,T]:
    text=(D/'inputs'/rel).read_text(); clean=base.sanitize_lean(text)
    fake=re.findall(r'\b(?:axiom|sorry|admit|unsafe|opaque)\b|Prop\s*:=\s*True|:=\s*trivial\b',clean)
    commands=[{'line':i,'text':line} for i,line in enumerate(clean.splitlines(),1)
        if re.match(r'^(?:\s*)(?:private\s+)?(?:theorem|lemma|def|abbrev|instance|axiom|opaque|structure|class|variable|section|namespace|import|set_option|run_cmd|elab|macro|syntax)\b',line)]
    scan.append({'file':rel,'bytes':len(text.encode()),'sha256':sha(text.encode()),'fake_tokens':fake,'top_commands':commands})
    assert not fake
js('whole-module-scan.json',{'candidate':C,'files':scan,'manual_judgment':{
   'P':'One public theorem, literal theta/t/D and only natural d/q plus strict range hq. Alias-derived hmode, product/triple-product sums, Gram and weighted assembly, row bound are substantive proofs; no imported conclusion or hidden source-facing premise. No wrapper closure.',
   'T':'One private theorem. Actual multivariateGaussian 0 I and actual B are let-defined. Invokes P at hframe (L45-L46), consumes hframe.1 and hframe.2.1 through hgram/hweighted and both mean calculations. Coordinate L2/products/zero mean/covariance, sqrt-d normalization and finite integral interchanges are proved internally. No caller moment, integrability, independence or Gram certificates. Row bound is available in hframe but is not needed for this mean consumer.',
   'scope':'Root type equality and all-owned kernel probes provide semantic closure beyond token scan. Rebuilt GridAlias is an existing parent and receives no new mathematical credit.'}})
print(json.dumps({'static_exact_six_folds':True,'full_T_step6_bytes':7494,'T_private_start_line':13,
  'step_fold_neighbor_controls':[{'step':c['step'],'copy':c['copy_neighbor'],'download':c['download_neighbor'],'source':c['exact_module_source_neighbor']} for c in checks],
  'reader_delivery':result['reader_delivery'],'whole_module_fake_tokens':sum(len(x['fake_tokens']) for x in scan)},indent=2))
