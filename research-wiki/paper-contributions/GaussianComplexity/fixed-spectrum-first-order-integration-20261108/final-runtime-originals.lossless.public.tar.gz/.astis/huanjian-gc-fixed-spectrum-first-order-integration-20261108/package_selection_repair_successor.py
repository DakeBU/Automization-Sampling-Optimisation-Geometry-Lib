from pathlib import Path
import gzip, hashlib, json, shutil, subprocess, tarfile
R = Path('.astis/huanjian-gc-fixed-spectrum-first-order-integration-20261108')
B = Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-first-order-integration-20261108/native-selection-repair-v3')
sha = lambda b: hashlib.sha256(b).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip() == '87ecd4d421de0146a062435f63e9dcb1f815c807'
target = Path('website/static/underlying-lean-graph.js')
assert sha(target.read_bytes()) == '016c11a60392c449ebb28e8bedc7d3ab69134fff8dde4b438fd06c9f6c951a3a'
assert subprocess.check_output(['git','diff','HEAD','--name-only'],text=True).splitlines() == [str(target)]
roots = [R/'independent-reader/browser/live-20261108T151138243939Z',
         R/'independent-reader/original38-independent-review-v3',
         R/'independent-reader/late-context-independent-review-v3',
         R/'graph-selection-repair-v1',R/'graph-selection-repair-v2',R/'graph-selection-repair-v3',
         R/'independent-reader/UI-camera-repair-independent-review-v1',
         R/'independent-reader/UI-camera-repair-independent-review-v2',
         Path('.astis/semantic-neutral-20261108/src_4e8f6a/normalpark-preparation')]
files=[]
for i,root in enumerate(roots):
    files += [(p,str(Path(str(i))/p.relative_to(root))) for p in sorted(root.rglob('*')) if p.is_file()]
files += [(R/'root-original13-review-v3.json','root-original13-review-v3.json')]
arc = B/'held-core87-runtime-and-original-evidence.lossless.tar.gz'; assert not arc.exists()
with tarfile.open(arc,'w:gz') as t:
    for p,member in files: t.add(p,arcname=member,recursive=False)
with tarfile.open(arc,'r:gz') as t:
    for p,member in files: assert t.extractfile(member).read() == p.read_bytes()
(B/'held-core87-runtime-and-original-evidence.manifest.json').write_text(json.dumps({
    'archive':str(arc),'archive_sha256':sha(arc.read_bytes()),'all_originals_retained_unchanged':True,
    'meaning':'Actual browser-v3 script PASS at heldCore87, with38 originals and independent37accepted/1HOLD pixels. JS proposals1/2 were never applied; only source repair proposal3 was applied. Old core87 park template remains unexecuted. No successor runtime is claimed.',
    'files':[{'original_path':str(p),'member':m,'raw_sha256':sha(p.read_bytes()),'bytes':p.stat().st_size} for p,m in files]},indent=2)+'\n')
for source,name in [
 (R/'independent-reader/browser/live-20261108T151138243939Z/report.json','held-browser-v3-actual-report.json'),
 (R/'independent-reader/original38-independent-review-v3/pixel-review-HOLD.json','held-independent-original38-pixel-review.json'),
 (R/'root-original13-review-v3.json','root-original13-review-v3.json')]: shutil.copy2(source,B/name)
logs = B/'actual-execution-records'; logs.mkdir()
for name in ['20261108T151123254109Z-fixed-spectrum-first-order-final-browser-v3',
             '20261108T152901409757Z-fixed-spectrum-first-order-propose-native-selection-repair',
             '20261108T154429405609Z-fixed-spectrum-first-order-propose-native-selection-repair-v3',
             '20261108T154830562720Z-fixed-spectrum-first-order-apply-reviewed-selection-repair-v3']:
    p=Path('.astis/huanjian-resume-20261103')/(name+'.receipt.json')
    r=json.loads(p.read_bytes()); raw=Path(r['log']).read_bytes(); assert sha(raw) == r['log_sha256']
    (logs/p.name).write_bytes(p.read_bytes()); (logs/(Path(r['log']).name+'.gz')).write_bytes(gzip.compress(raw,mtime=0))
pack=B/'frozen-raw-packaging';pack.mkdir();safe=[];rows=[]
for p in sorted(q for q in B.rglob('*') if q.is_file()):
    raw=p.read_bytes();binary=p.suffix in ['.gz','.zip','.png'] or b'\0' in raw
    bad=not binary and (b'\r\n' in raw or raw.endswith(b'\n\n') or any(x.endswith((b' ',b'\t')) for x in raw.splitlines()))
    ignored=subprocess.run(['git','check-ignore','-q','--',str(p)]).returncode==0
    if bad or ignored:
        z=pack/(str(len(rows)).zfill(3)+'-'+p.name+'.gz');z.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(z.read_bytes())==raw
        rows.append({'original':str(p),'raw_sha256':sha(raw),'gzip':str(z),'gzip_sha256':sha(z.read_bytes()),'original_retained_unchanged':True});safe.append(z)
    else:safe.append(p)
mp=pack/'manifest.json';mp.write_text(json.dumps({'rule':'Only frozen raw evidence is losslessly wrapped. Actual sharedJS staged directly byte-exact.','files':rows},indent=2)+'\n');safe.append(mp)
safe.append(target)
subprocess.run(['git','add','--',*map(str,safe)],check=True)
assert subprocess.check_output(['git','show',':'+str(target)]) == target.read_bytes()
subprocess.run(['git','diff','--cached','--check'],check=True)
print(json.dumps({'paths_staged':len(safe),'only_existing_tracked_source_change':str(target),
                  'raw_originals_replay_archive_verified':len(files),'new_core_runtime_or_acceptance':False}))
