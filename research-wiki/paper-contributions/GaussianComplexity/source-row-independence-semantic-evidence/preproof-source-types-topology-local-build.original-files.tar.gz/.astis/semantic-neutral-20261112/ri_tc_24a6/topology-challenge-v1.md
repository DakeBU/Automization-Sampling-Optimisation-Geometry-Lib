# Independent source coverage and topology challenge, version 1

**Accept the bounded source coverage and unproved source topology. No genuine
statement/source-coverage blocker was found. All ten internal mathematical and
Mathlib-applicability ports remain open.** This acceptance is limited to source
coverage/topology for the exact fixed sealed types. It is not a theorem proof,
implementation/call-edge check, proof permission, VERIFIED transition, or
publication grant.

## Independence and chronology

This actor froze its own independent raw-source reading before seeing the new
types, then froze its independent type-only audit before seeing these graph
records. The original raw freeze remains
`dc5f3b9278a7fe8d3eac246c794f0832ca157f4d9cf3b9c52443c28444e70ee9`;
the type freeze remains
`8d363393f9486f01bb526747d6142c8843823917f74b70a664a537988f69147a`.
Only the five specifically authorized public source-derived SG records, their
exact raw-source regions and the already reviewed sealed packet were used.
No SG type-audit, meaning-comparison, private builder/rationale, implementation,
previous judgment or ledger was opened. The extractor has not approved its own
coverage through this review.

## Exact binding and coverage

The reviewed graph is bound to Statement Seal
`88a55849ce9e13a9a04edff6aac13ce32d4370712b1b7a422fba0d570ff0b25e`,
packet `c9f8312610515f2ebc067612c981889103e7d8a93a00aa5f75ec8c74feb1ab68`,
producer signature `2898f07e581afb8c38fa6dda16193a411dee6b9729a198b0a1437a98c726405a`,
and consumer signature `026e3d3282b502cb069c022ac844e86ed4613cf62a8be2a9948edf3f25f02cf8`.
The graph, coverage and ports records have identical bindings. All five SG
input file hashes match the root's exact handoff.

I inspected every one of the 83 atomic dispositions against an independent
projection of the pinned raw HTML: 17 NODE records and 66 reasoned EXCLUDED
records. The 65 distinct atom-source elements match their raw content. The
continuous Appendix C.2 window, from its first paragraph through p12's end,
contains exactly the 47 independently identified paragraph/display units named
in coverage. No unit is missing or added. This is not whole-source coverage:
the S4 material is explicitly discontiguous and p13 onward is outside the
reviewed window.

All 472 locator occurrences across the five public records were checked:
raw-fragment SHA-256, UTF-8 span, Unicode-codepoint span and inclusive LF line
range. They cover 75 unique raw spans and all match. The SG text projection
adds spaces around some inline math, while this actor's parser preserves its
adjacency to punctuation; all 65 projections agree after whitespace removal.
This formatting difference is not a source mismatch. Source byte hashes, not
the projection's formatting, anchor the review.

The exclusions consistently leave out spectral/Haar/algorithm transfer,
Krylov/range results, cosine identities and deterministic norm/Gram estimates,
moments, tail and common-truncation-event probabilities, radial/bias/mean
calculations and the uniform/concentration conclusions. They retain the exact
grid, coordinate conventions, actual Gaussian rows, explicit row-independence
assertion, local R/L cutoff definitions, literal Y formula, and explicit
matrix-independence wording. The source's marginal N(0,I_r) assertion and B
definition remain visible context, without source-coverage credit for proving
them in this independence packet.

## Directed topology and consumer-use checks

All 30 nodes, 33 directed edges and two route hyperedges were inspected. Each
direct consumer-use site exists at the stated raw locator. No dangling node,
changed raw disposition, unexplained mathematical proof region, reversed
prerequisite edge or false conjunction of alternative proofs was found.

The producer route preserves the distinction between within-column full
coordinate product law and across-column product law. Both feed regrouping of
the actual scalar array into the actual physical rows, followed by full
row-sigma-field independence. The source p1 marginal-law context has no edge
purporting to establish joint independence. No second sample with matching
marginals, pairwise-only argument or covariance calculation replaces the full
finite family. The edge from the source independence assertion to the sealed
producer is expressly source correspondence, not a checked proof edge.

The standard-Gaussian definition in the packet uses coefficients in
stdOrthonormalBasis. A product law for those coefficients is not, merely by its
name, the required physical-evaluation-coordinate product law. The explicit
`PORT.stdGaussian-coordinate-factorization` correctly keeps that exact
basis/evaluation and unit-covariance normalization applicability open. The
column-product and regrouping ports also require their actual measure,
measurability and finite-product hypotheses internally. None is represented as
a proved parent or caller-supplied certificate.

For the consumer, gamma_i, t_i, R_i and L feed the literal Ex107 object at its
actual use site. The intended separate row map F_i uses only row i and fixed
deterministic t_i. Its cutoff is closed, its scale is exactly inverse d, its
paired indices put the Gaussian coordinate first, and its value outside the
event is the zero matrix. No common-event conditioning, extra random threshold
or abstract surrogate appears in the accepted route.

The measurability chain accounts separately for row measurability, the local
closed norm event, finite matrix-entry map measurability, literal Y=F_i(row_i),
and composition. The independence chain uses the new full row-independence
producer and the differing measurable F_i, then transfers along that same
literal identity. This gives source-independent matrices, without an iid
matrix claim. It requires no injectivity: the nonlinear truncation map need
not preserve or recover the row's sigma-field. The explicit consumer
measurability output is not silently inferred from iIndepFun.

The two AND route records describe a chosen pipeline of mutually required
internal obligations, with downstream ports depending on upstream ones. They
do not flatten unrelated sufficient alternatives into a stronger source
premise. A future library result may discharge several ports together; the
record does not demand ten new declarations. The standing natural range and
literal carrier/feature-index context remain source/type context, including
q=0. No tau or kappa condition has entered either independence route.

## Open ports and remaining truth boundary

The ten open ports are the physical-coordinate standard-Gaussian law,
canonical column-product applicability, finite coordinate regrouping, full
row iIndepFun interpretation, actual row measurability, closed-cutoff
measurability, finite matrix-row-map measurability, literal actual-Y image
identity, Y measurability by composition, and full independence of the separate
measurable images. These are expected internal mathematical obligations. Their
open status is not a missing source-statement/coverage blocker and supplies no
new hypothesis on the sealed statements.

The graph's intended producer-to-consumer edge remains unproved. This review
does not establish which Mathlib rule applies, prove the basis bridge, compile
the targets, inspect any proof body, or verify a material producer call. No
compiled parent is accepted. The original ambient transfer, marginal-law
coverage beyond the narrow split, means, centered variance, concentration and
main theorem remain outside this acceptance.

Machine-readable per-atom, per-edge and per-locator review records accompany
this versioned finding. Raw/type freezes are preserved unchanged.
