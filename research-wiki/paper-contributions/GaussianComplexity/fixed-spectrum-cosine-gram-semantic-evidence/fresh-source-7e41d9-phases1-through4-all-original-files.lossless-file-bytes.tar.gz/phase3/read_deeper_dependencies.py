#!/opt/anaconda3/bin/python
import hashlib,json,pathlib
BASE=pathlib.Path(__file__).resolve().parent
ROOT=pathlib.Path('/Users/zhouhuanjian/ASTIS-GC')
spec=[('Mathlib/Probability/Distributions/Gaussian/Basic.lean',[(40,65),(99,140)]),
      ('Mathlib/Probability/Distributions/Gaussian/Fernique.lean',[(175,214)]),
      ('Mathlib/Probability/Distributions/Gaussian/Real.lean',[(520,590)]),
      ('Mathlib/Analysis/SpecialFunctions/Trigonometric/Complex.lean',[(270,294),(382,395)]),
      ('Mathlib/Analysis/SpecialFunctions/ContinuousFunctionalCalculus/Rpow/Basic.lean',[(79,91),(236,269),(655,666)]),
      ('Mathlib/Analysis/InnerProductSpace/PiL2.lean',[(108,118),(210,222),(1070,1084)]),
      ('Mathlib/Analysis/CStarAlgebra/Matrix.lean',[(95,124)])]
records=[]
for rel,ranges in spec:
    name='.lake/packages/mathlib/'+rel;path=ROOT/name;data=path.read_bytes()
    snapshot='dependencies/'+name.replace('/','__')
    existing=BASE/snapshot
    if existing.exists():assert existing.read_bytes()==data
    else:existing.write_bytes(data)
    records.append({'source':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),
                    'snapshot':snapshot,'read_line_ranges_1based_inclusive':ranges})
    lines=data.decode().splitlines()
    print('ACTUAL_DEPENDENCY',json.dumps(records[-1]))
    for lo,hi in ranges:
        print('RANGE',lo,hi)
        for n in range(lo,hi+1):print(str(n)+'\t'+lines[n-1])
(BASE/'deeper_dependency_inventory.json').write_text(json.dumps(records,indent=2)+'\n')
