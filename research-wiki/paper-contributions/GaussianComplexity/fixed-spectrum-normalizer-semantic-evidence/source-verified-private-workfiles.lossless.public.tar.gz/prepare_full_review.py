from pathlib import Path
import json,hashlib,subprocess,sys
sys.path.insert(0,'tools')
import astis_semantic_roundtrip as rt
import astis_publication as pub
import astis_advance as adv
sha=lambda raw:hashlib.sha256(raw).hexdigest()
b=Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-normalizer-semantic-evidence')
ap=Path('research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-normalizer.json')
a=json.loads(ap.read_bytes())
assert a['state']=='blind-reconstructed' and a['publication_binding_sha256']=='b2f41e36a9d705ff68da71f72f0ec14f1cd2ff105bcf0ae5000ef1406a5d1f41'
pub.check_advance([a['lean']['declaration']],reviewed=False)
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert head=='813268bc2683a82269364caffbc0c7490a884204'
assert adv.current_advances()['ASTIS-SA-20261108-GaussianComplexityFixedSpectrumNormalizer']['state']=='PROVED_LOCAL'
packet=rt.semantic_reviewer_packet(a)
p=b/'full-anti-anchored-reviewer-packet.json';assert not p.exists();p.write_text(json.dumps(packet,ensure_ascii=False,indent=2)+'\n')
paths=[ap,Path(a['lean']['file']),Path('Tests/GaussianComplexityFixedSpectrumNormalizer.lean')]
paths += [Path('AutoSamplingTheory/ExampleCases/GaussianComplexity')/x for x in ['FixedSpectrumAdmissibility.lean','FixedSpectrumDeterminant.lean']]
paths += [Path('AutoSamplingTheory/TechnicalLemmas/Measure')/x for x in ['GaussianPrecisionDensity.lean','IsotropicGaussianDensity.lean','RadonNikodym.lean','DisplacementJacobianEntropy.lean']]
paths += [Path(x) for x in ['website/content/declaration_lessons/huanjian-fixed-spectrum-normalizer.json',
 'website/content/publications/huanjian-fixed-spectrum-normalizer.json','runs/substantive_advances.jsonl','runs/substantive_discoveries.jsonl']]
record={'checked_candidate_commit':head,'mathematical_candidate':'8d33e06485edc17320cc01308af40da44945659d',
 'full_packet_path':str(p),'full_packet_raw_sha256':sha(p.read_bytes()),'full_packet_canonical_sha256':packet['packet_sha256'],
 'publication_binding_sha256':a['publication_binding_sha256'],
 'exact_inputs':{str(q):sha(q.read_bytes()) for q in paths},
 'instruction':'Deliver only after independent phase2 selective comparison freeze. HEAD/audit/ledgers fixed during full review. Actual producer has THREE existing canonical ASTIS parents; actual private Test has FOUR including the new producer. All original source/ambient exposure records remain. Root creates no source verdict or VERIFIED.'}
(b/'full-review-input-pins.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record))
