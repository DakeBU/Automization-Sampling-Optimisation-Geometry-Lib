#!/opt/anaconda3/bin/python
import json,pathlib,sys
BASE=pathlib.Path(__file__).resolve().parent
mapping=json.loads((BASE/'inputs/research-wiki__paper-contributions__GaussianComplexity__fixed-spectrum-cosine-gram-semantic-evidence__source-to-lean-map-v1.json').read_text())
inventories=json.loads((BASE/'input_inventory.json').read_text())+json.loads((BASE/'dependency_inventory.json').read_text())
paths={r['source']:BASE/r['snapshot'] for r in inventories}
lo,hi=map(int,sys.argv[1:])
for row in mapping['locator_slices']:
    if not row['slice_id'].startswith('C') or not row['slice_id'][1:].isdigit():continue
    index=int(row['slice_id'][1:])
    if not lo<=index<=hi:continue
    data=paths[row['file']].read_bytes()
    print(row['slice_id'],row['file'],row['start_line_1based_inclusive'],row['end_line_1based_inclusive'])
    print(data[row['byte_start_inclusive']:row['byte_end_exclusive']].decode())
