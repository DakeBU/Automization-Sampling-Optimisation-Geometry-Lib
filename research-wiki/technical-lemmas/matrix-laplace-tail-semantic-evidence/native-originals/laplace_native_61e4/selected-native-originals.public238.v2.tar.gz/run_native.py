"""Run frozen native commands using only fresh owned ASTIS output and pinned upstreams."""
import json
from native_common import *

def main():
    assignment = json.loads((OWN/'native-command-assignment.json').read_text())
    assert assignment['candidate_commit'] == COMMIT
    assert not (OWN/'native-output-initialized.json').exists()
    assert not any(OUT.iterdir())
    write_json(OWN/'native-output-initialized.json',{'candidate_commit':COMMIT,'output_initially_empty':True,'assignment_sha256':file_sha(OWN/'native-command-assignment.json')})
    for command in json.loads((OWN/'native-commands.json').read_text()):
        for row in assignment['inputs']:
            path = (OWN/row['path']).resolve()
            assert path.is_relative_to(OWN) and file_sha(path) == row['sha256'], row
        assert command['env']['LEAN_PATH'].split(':')[0] == str(OUT)
        argv = command['argv']
        if '-o' in argv:
            output = Path(argv[argv.index('-o')+1])
            assert output.is_relative_to(OUT) and not output.exists()
            output.parent.mkdir(parents=True,exist_ok=True)
        print(json.dumps({'started_native_command':command['id']}),flush=True)
        run(command['id'],argv,cwd=command['cwd'],env=command['env'])
    write_json(OWN/'native-sequence-completed.json',{'candidate_commit':COMMIT,'commands':assignment['native_command_count'],'all_exit_zero':True})

if __name__ == '__main__': main()
