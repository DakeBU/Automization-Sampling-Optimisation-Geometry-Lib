# C8 exact actual Gaussian means — initial seal ACCEPT

**ACCEPT for exact statement mathematics, binders, literal definitions and source meaning.** No seal HOLD remains. Final source-topology/root-closure admission awaits the NEW extractor's exact frozen projection. No new target proof, API availability, compilation, actual consumer use, source V or Goal status is certified.

The independent full-C3 raw cognition was frozen first under `SHA256SUMS.raw` SHA-256 `a6d5e30e7bcd9dea15750bbfd80335e7c990a96e3c66c93d5ffed9581e12ff07`. Only afterward were the exact `statement-seal-v1.json` (SHA-256 `81900673dcb74d8e5a321be926904feadd368478f651c619cb3675ee0cc92e3e`) and its 223-byte `multivariateGaussian-standard-definition.txt` (SHA-256 `512ddbd6cb835fbf4bd28967f04a22cb0c0afe42e57036932fbbe27f3a2cf2cd`) opened. No new/old graph, implementation, type-formation code/log or private rationale was opened.

## All seven binders, independently classified

Both signatures have exactly the same seven declared parameters:

| Binder | Classification | Source reason |
|---|---|---|
| d:Nat | TYPING | Finite real Euclidean dimension carrier. |
| hd:2≤d | STANDING | Literal hard-family domain. |
| κ:Real | TYPING | Real condition parameter. |
| hκ:2≤κ | STANDING | Literal hard-family/Lemma 4.5 domain. |
| n:Nat | TYPING | Positive source integer represented together with its bounds. |
| hn:1≤n | SOURCE | Fact C8/Lemma 4.5 lower frequency bound. |
| hnd:n<d | SOURCE | Their strict upper frequency bound. |

No project-owned bundled Prop, witness structure or arbitrary-law/typeclass premise occurs. No EXCESS was found independently. In particular radius bounds, spectrum positivity, invertibility, summability, residue-class coverage, geometric values, moment positivity, sign and denominator facts are absent from the inputs. The creator's EXCESS list is not relied on.

## Actual measure and integrands

The grid is exactly `(i.val+1/2)π/d`, matching source one-based indices. Eigenvalues retain both halves and Λ is their diagonal precision. `multivariateGaussian 0 Λ⁻¹` uses covariance equal to the inverse precision; the standard snippet maps stdGaussian by the covariance square root. It does not multiply a standard Gaussian directly by Λ⁻¹ or pass Λ as covariance.

The local definitions contain no new fallback constructor or characterized-object choice. Standard inverse/CFC defaults outside the source positive-definite domain may not establish the target; source-domain positivity and actual-law interpretation remain internal dependencies. This review has not re-proved them.

The norm is the actual Euclidean norm, and Q is the actual cosine-weighted sum of coordinate squares, representing UᵀDₙU. Both producer Integrable outputs are explicit. Actual Gaussian integrals cannot be replaced by Bochner default-zero values or by definitions of deterministic spectral sums. The upstream GaussianMoments/C7/GridAlias names in metadata are candidate dependencies, not assumed certificates or verified compiled edges here.

## Both closed formulas

The producer's actual norm integral equals

\[
\frac d{\sqrt\kappa}\frac{1-r^{2d}}{1+r^{2d}},
\]

and its signed actual Q integral equals

\[
(-1)^n\int Q\,d\mu
=\frac d{\sqrt\kappa}\frac{r^n-r^{2d-n}}{1+r^{2d}}.
\]

These match Ex138 and the final Ex143/Ex147 rows. The d/√κ normalization, the denominator sign `+`, the r^(2d) finite-grid correction and the external (−1)^n factor are all retained. They are not continuous-average formulas. The target includes both means jointly; the unweighted and weighted source computations are different required subroutes, not alternative proofs of the whole result.

All displayed powers are natural powers. Given 1≤n<d, the Nat expression 2*d−n equals the intended positive integer difference; d−n is also positive. Required exponent addition/subtraction equalities must still be proved internally. The signature does not license truncation of intermediate signed alias frequencies, which remain all-integer obligations in the future source route. No odd-n, query relation, asymptotic κ bound or d−n≥√κ assumption was added.

## Genuine private actual-integral consumer

The private m and b are literally the two actual Gaussian integrals. They are not free scalar inputs, nor defined to be desired closed values. Its four outputs are 0<m, m≤d/√κ, 0<(−1)^n b and the exact |b|/m expression in Ex150. They match p8.2 and p9.1.

The strict sign is correctly applied to (−1)^n b, not b for every n. The absolute ratio has r^n, denominator 1−r^(2d), and numerator correction 1−r^(2*(d−n)). Positivity/nonzero m and all real denominators remain conclusions or internal facts. This consumer has substantive content requiring both actual mean values; its actual material use of the producer remains a postproof check, since no body is available or reviewed.

M upper at p8.2 follows from the exact M formula and the radius interval; Ex148–149 are not its dependencies. Exact ratio/sign need neither Ex151 nor the logarithmic/exponential estimates. The proposed statement correctly stops before those later results.

## Pending topology review and open boundary

Both exact signature strings were independently rehashed. The producer digest is `0fed0efb7d7e4170caca9a7006abae3f285561984424146ca2fed40359b9ad8e`; private consumer digest is `769a50ba478485a62579b0d565e3118d41e4a165dfa43d519b3ae0f22a71b7ba`. Prop-only formation metadata is exposure, not proof credit; its code/receipt was not opened and no Lean check was run.

The forthcoming fresh graph must expose the complete positive-index unweighted tail and three weighted classes, disjointness/completeness, negative/zero integer aliases, parity and convergent geometric normalization. It must keep actual Gaussian expectation identification distinct from scalar regrouping, treat every bridge as an internally discharged obligation, and avoid importing the closed C8 target as a premise.

The private root must use the closed means plus radius/sign/denominator arithmetic, with no false AND dependency on variance/fourth moments, Ex151 or p10–p11. Fourth moments, independence/variances, exponential bias bounds, rotated/adaptive laws, TV/oracle/precision/cost/main bounds and integration/whole-Goal status remain open.

Existing role and root preseal background exposure are disclosed. This independent review has not searched a new tail/residue/geometric proof/API, read candidate Lean or an old graph, or mutated ledgers/production/shared models. The exact seal ACCEPT will remain frozen when the new graph is reviewed separately.
