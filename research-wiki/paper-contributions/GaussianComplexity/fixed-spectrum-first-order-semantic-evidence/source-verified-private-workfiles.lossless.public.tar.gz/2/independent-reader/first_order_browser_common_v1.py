"""CONDITIONAL browser guards. No execution, source verdict or lifecycle API here."""
import argparse,gzip,hashlib,json,os,re,subprocess,sys
from pathlib import Path
sys.dont_write_bytecode=True
R=Path('/Users/zhouhuanjian/ASTIS-GC')
S=R/'.astis/huanjian-gc-fixed-spectrum-first-order-integration-20261108/independent-reader'
PROPOSAL_REPORT_SHA='43bff1329cd5b697a845184e1ff9d27004c93d46edb2251f855c4a90d92e5604'
CANDIDATE='9d306d837fbddf1518b0035494baaf5c21c24488'
ADV='ASTIS-SA-20261108-GaussianComplexityFixedSpectrumFirstOrder'
OWNER='huanjian_gc_20261108_fixed_spectrum_first_order'
ACTOR='/root/norm_integration_reader'
BINDING='51d5a5e9390a0d66c2d5b72d042a042eec8d3d60433043ea3909bf9320ccb31e'
sha=lambda b:hashlib.sha256(b).hexdigest()
def parse_args(doc):
 p=argparse.ArgumentParser(description=doc);p.add_argument('--authorization-json',required=True);p.add_argument('--authorization-sha256',required=True);return p.parse_args()
def readref(ref):
 p=(R/ref['path']).resolve();assert p.is_relative_to(R);raw=p.read_bytes();assert sha(raw)==ref['sha256'];return raw
def load_authorization(args):
 ref={'path':args.authorization_json,'sha256':args.authorization_sha256};a=json.loads(readref(ref))
 assert a['authorized_by']=='/root' and a['authorization_kind']=='fixed-spectrum-first-order-final-browser'
 assert a['execute_browser_authorized'] is True and a['new_source_verdict'] is False and a['parking_authorized'] is False
 assert a['candidate_commit']==CANDIDATE and a['publication_binding_sha256']==BINDING
 assert a['browser_checker_sha256']==sha((S/'check_final_reader_v1.py').read_bytes()) and a['browser_common_sha256']==sha(Path(__file__).read_bytes())
 assert re.fullmatch('[0-9a-f]{40}',a['accepted_immutable_core']) and a['accepted_immutable_core']!=CANDIDATE
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip()==a['accepted_immutable_core']
 subprocess.check_call(['git','merge-base','--is-ancestor',CANDIDATE,a['accepted_immutable_core']],cwd=R)
 return a,ref
def authorized_context(a):
 p=S/'conditional-proposal-v1/proposal-report.json';raw=p.read_bytes();assert sha(raw)==PROPOSAL_REPORT_SHA==a['proposal_report_sha256'];p=json.loads(raw)
 assert a['candidate_source_digest']==p['candidate_source_digest']
 assert a['source_digest']==p['predicted_source_digest_after_exact_proposed_Lean_payloads']
 for row in p['shared_paths']:
  raw=(R/row['path']).read_bytes();assert sha(raw)==row['planned_after_sha256'];assert subprocess.check_output(['git','show',a['accepted_immutable_core']+':'+row['path']],cwd=R)==raw
 b=p['protected_baseline'];br=(R/b['path']).read_bytes();assert sha(br)==b['gzip_sha256'];raw=gzip.decompress(br);assert sha(raw)==b['raw_sha256'];baseline=json.loads(raw)
 ledger='runs/substantive_advances.jsonl'
 for name,row in baseline['protected_tracked'].items():
  if name==ledger:continue
  q=R/name;raw=os.fsencode(os.readlink(q)) if q.is_symlink() else q.read_bytes();assert sha(raw)==row['sha256'],name
 before=gzip.decompress((S/'conditional-proposal-v1/before-SAU-ledger.raw.gz').read_bytes());now=(R/ledger).read_bytes();assert now.startswith(before)
 tail=now[len(before):].splitlines();assert len(tail)==2
 V,stab=map(json.loads,tail);verifier=a['source_verifier_to_preserve'];assert verifier not in [OWNER,ACTOR,'/root']
 assert V['advance_id']==stab['advance_id']==ADV and V['worker_id']==V['evidence']['verifier_id']==verifier
 assert (V['from_state'],V['to_state'])==('PROVED_LOCAL','VERIFIED') and (stab['from_state'],stab['to_state'])==('VERIFIED','STABILIZING')
 assert stab['worker_id']==a['integration_owner'] and a['integration_owner'] not in [OWNER,ACTOR,verifier]
 assert V['evidence']['verified_commit']==CANDIDATE and all(V['evidence'][k] for k in ['gate','source_audit','fake_closure_scan'])
 append=readref(a['source_V_append']);assert append==tail[0]+b'\n' and now.count(append)==1
 audit=json.loads(readref(a['accepted_source_audit']));assert a['accepted_source_audit']['path']=='research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-first-order.json'
 assert audit['state']=='accepted' and audit['publication_binding_sha256']==BINDING and audit['lean']['formalizer']==OWNER and audit['source_review']['reviewer']==verifier
 assert sha(readref(a['source_review_run']))==audit['source_review']['review_run_sha256']
 assert subprocess.check_output(['git','show',a['accepted_immutable_core']+':'+a['accepted_source_audit']['path']],cwd=R)==readref(a['accepted_source_audit'])
 sys.path[:0]=[str(R/'tools')];import astis_advance as advance
 states=advance.current_advances();assert states[ADV]['state']=='STABILIZING' and [k for k,v in states.items() if v['state']=='STABILIZING']==[ADV]
 assert {k:v for k,v in states.items() if k!=ADV}==baseline['foreign_SAU_states']
 assert advance.current_discoveries()==baseline['all_discovery_states']
 gate=json.loads(readref(a['actual_gate']));meta=json.loads(readref(a['site_metadata']))
 assert gate['passed'] and meta['gate']['passed'] and meta['gate']['current'] and gate['commit']==meta['git']['commit']==a['accepted_immutable_core']
 assert gate['source_digest']==meta['source_digest']==a['source_digest']
 required={'canonical_lean','publication','contributor','semantic','frontier','site_build','site_check','graph_check'};assert set(a['actual_checks_before_browser'])==required
 needles={'publication':'astis_publication.py','contributor':'astis_contributor_contract.py','semantic':'astis_semantic_roundtrip.py','frontier':'astis_frontier_cells.py','site_build':'build_site.py','site_check':'check_site.py','graph_check':'graph-check'}
 for role,ref in a['actual_checks_before_browser'].items():
  receipt=json.loads(readref(ref));assert receipt['exit_code']==0 and receipt['head_before']==receipt['head_after']==a['accepted_immutable_core'];log=Path(receipt['log']).read_bytes();assert sha(log)==receipt['log_sha256']
  if role=='canonical_lean':assert log.decode().splitlines().count('ASTIS check passed')==1 and receipt['command'][1:] in [['tools/astis.py','check'],['website/scripts/lean_gate.py']]
  else:assert needles[role] in str(receipt['command'])
 return {'conditional_proposal_exact_applied':True,'original_source_verifier':verifier,'unique_original_V_append_sha256':sha(append),'sole_STAB':ADV,'foreign_tracked_raw_bytes_preserved':True,'unchanged_foreign_states':len(baseline['foreign_SAU_states']),'all_discoveries_and_frontier_bytes_preserved':True,'lifecycle_API_called':False,'new_source_verdict':False,'all8_actual_receipts_exact_core_read':True}
