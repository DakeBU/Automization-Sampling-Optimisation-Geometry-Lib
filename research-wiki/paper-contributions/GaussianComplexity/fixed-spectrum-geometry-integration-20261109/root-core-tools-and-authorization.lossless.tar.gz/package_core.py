from pathlib import Path
import gzip,hashlib,json,shutil,subprocess,tarfile
P=Path('.astis/huanjian-gc-fixed-spectrum-geometry-integration-20261109')
B=Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-geometry-integration-20261109')
sha=lambda b:hashlib.sha256(b).hexdigest()
dump=lambda x:(json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode()
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()=='62813df927fd3c156dd57099cc11613074d91bc0'
assert not subprocess.check_output(['git','diff','--cached','--name-only']).strip()
proposal=json.loads((P/'independent-reader/conditional-proposal-v1/proposal-report.json').read_bytes())
receipt=json.loads((B/'exact-shared-application-receipt.json').read_bytes())
assert receipt['normal_state']=='STABILIZING' and receipt['normal_API_calls']==1
assert receipt['append_sha256']=='271a16a8c9b44294515b4cfe790b5560bbc544d415846db76adce9330420ab88'
assert receipt['source_digest']=='6905b946089555464e4eedadfad3644fb4df3ee5d49ffc8445c16bb7fd997108'
for row in proposal['shared_paths']:assert sha(Path(row['path']).read_bytes())==row['planned_after_sha256']
assert sha(Path('runs/substantive_advances.jsonl').read_bytes())=='5b58146368803e26104d11892b5d29cd6862bda63bb41268bdbc07be2b94190b'
assert sha(Path('research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-geometry.json').read_bytes())=='a101634a005e20e54c8791cf340b871a3adf79807b75b607f422957392b0bc6c'
src=P/'independent-reader';dest=B/'independent-reader';assert not dest.exists();shutil.copytree(src,dest)
for q in src.rglob('*'):
    if q.is_file():assert (dest/q.relative_to(src)).read_bytes()==q.read_bytes()
(B/'root-conditional-six-path-review.json').write_bytes((P/'root-conditional-six-path-review.json').read_bytes())
checks=B/'precore-actual-checks';checks.mkdir()
for name in ['20261109T020233123092Z-geometry-preintegration-origin-main-network-escalated',
             '20261109T020352371490Z-geometry-actual-evidence-STAB-preflight-v3',
             '20261109T020413438561Z-geometry-sole-STAB-exact-six-payload-application-v3']:
    q=Path('.astis/huanjian-resume-20261103')/(name+'.receipt.json');r=json.loads(q.read_bytes());raw=Path(r['log']).read_bytes()
    assert r['exit_code']==0 and sha(raw)==r['log_sha256']
    (checks/q.name).write_bytes(q.read_bytes());(checks/(Path(r['log']).name+'.gz')).write_bytes(gzip.compress(raw,mtime=0))
tools=sorted(q for q in P.iterdir() if q.is_file());archive=B/'root-core-tools-and-authorization.lossless.tar.gz'
assert not archive.exists()
with tarfile.open(archive,'w:gz') as t:
    for q in tools:t.add(q,arcname=q.name,recursive=False)
with tarfile.open(archive,'r:gz') as t:
    for q in tools:assert t.extractfile(q.name).read()==q.read_bytes()
(B/'root-core-tools-and-authorization.manifest.json').write_bytes(dump({
    'archive':str(archive),'sha256':sha(archive.read_bytes()),'all_originals_retained':True,
    'scope':'Actual V3 application and unexecuted prior V1/V2 HOLDs; frozen exact sourceV/oneSTAB and future-disabled browser preparation. No actual root/site/browser acceptance yet.',
    'files':[{'original':str(q),'member':q.name,'sha256':sha(q.read_bytes())} for q in tools]}))
pack=B/'frozen-raw-packaging';pack.mkdir();safe=[];wrapped=[]
for q in sorted(q for q in B.rglob('*') if q.is_file()):
    raw=q.read_bytes();binary=q.suffix in ['.gz','.zip','.png'] or b'\0' in raw
    ignored=subprocess.run(['git','check-ignore','-q','--',str(q)]).returncode==0
    bad=not binary and (b'\r\n' in raw or raw.endswith(b'\n\n') or any(line.endswith((b' ',b'\t')) for line in raw.splitlines()))
    if ignored or bad:
        z=pack/(str(len(wrapped)).zfill(3)+'-'+q.name+'.gz');z.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(z.read_bytes())==raw
        wrapped.append({'original_path':str(q),'raw_sha256':sha(raw),'raw_bytes':len(raw),'gzip_path':str(z),'gzip_sha256':sha(z.read_bytes()),'original_retained_unchanged':True});safe.append(z)
    else:safe.append(q)
mp=pack/'manifest.json';mp.write_bytes(dump({'scope':'Frozen raw evidence wrapped losslessly only; original bytes retained. Shared/mutable paths staged directly.','files':wrapped}));safe.append(mp)
mutable=[Path(row['path']) for row in proposal['shared_paths']]+[Path('runs/substantive_advances.jsonl'),Path('research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-geometry.json')]
safe=sorted(set(safe+mutable));subprocess.run(['git','add','--',*map(str,safe)],check=True)
staged=subprocess.check_output(['git','diff','--cached','--name-only','-z']).decode().strip('\0').split('\0')
assert set(staged)==set(map(str,safe))
for name in staged:assert subprocess.check_output(['git','show',':'+name])==Path(name).read_bytes(),name
subprocess.run(['git','diff','--cached','--check'],check=True)
assert Path('research-wiki/paper-contributions/GaussianComplexity/README.md').read_bytes()==subprocess.check_output(['git','show','HEAD:research-wiki/paper-contributions/GaussianComplexity/README.md'])
print(json.dumps({'staged_paths':len(staged),'exact_shared_payloads':6,'additional_own_metadata_and_ledger_paths':2,
    'all_staged_index_bytes_equal_live':True,'new_raw_wrappers':len(wrapped),'actual_root_site_browser_remote_purification_Goal_complete':False}))
