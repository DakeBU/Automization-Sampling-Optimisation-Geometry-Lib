#!/usr/bin/env python3
"""Bounded independent verifier runner; never invokes a shell."""
import datetime, hashlib, json, os, pathlib, subprocess, sys, time
ROOT = pathlib.Path(__file__).resolve().parent
REPO = ROOT.parents[2]
def run(label, argv, *, cwd=None, env=None):
    out = ROOT / 'receipts'; out.mkdir(exist_ok=True)
    assert not (out / (label + '.json')).exists(), label
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    t = time.monotonic()
    p = subprocess.run(argv, cwd=str(cwd or REPO), env=env, capture_output=True)
    paths = {}
    for stream, data in [('stdout',p.stdout), ('stderr',p.stderr)]:
        f = out / (label + '.' + stream); f.write_bytes(data)
        paths[stream] = {'path':str(f.relative_to(ROOT)), 'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
    receipt = {'label':label,'argv':argv,'cwd':str(cwd or REPO),'started_utc':started,'duration_seconds':time.monotonic()-t,'exit_code':p.returncode,**paths}
    (out/(label+'.json')).write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps({'label':label,'exit_code':p.returncode,'stdout_bytes':len(p.stdout),'stderr_bytes':len(p.stderr)}),flush=True)
    return p
if __name__ == '__main__':
    sys.exit(run(sys.argv[1],sys.argv[2:]).returncode)
