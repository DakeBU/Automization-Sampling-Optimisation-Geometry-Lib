# Phase2b independent topology challenge — frozen mathematical verdict

**HOLD the base author graph's full selected-root closure.** One actual dependency is missing at the target mean/variance step. The exact private auxiliary overlay is acceptable as a bounded mathematical specification, with all standard bridges still unproved and all implementation/probability/full-result statuses held.

This review follows the independently frozen raw-source phase1 and bounded exact-statement phase2a. Neither is edited. The source graph was produced by a different actor; I did not read that actor's private cognition, private process/exposure notes, other reviews, root history/plans/exposure, or target implementation. All whitelisted inputs and local evidence are pinned in the phase2b manifest. No Lean/API experiment was run.

## Exact challenged versions and scope

* Original HTML SHA256 `6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915`.
* Base `source_graph.json` SHA256 `2d47aa63ead6a81895dd7f81e0a3f854ec9c5041a42dc4d48faa66687ccfe2c1`.
* Coverage SHA256 `63f9a219a6b0d20cbe40acfcdae91f4049c4666363fbfddc48e0f0f4285e377a`.
* Standard bridges SHA256 `f61b903f2aaa76ec0b23f059683528c0513b1ab3695ebf68cb0a431f8119b4c2`.
* Overlay v1 SHA256 `a71c6d355c792971abca484dbf784be6cbdf897a1a199e802d26c8b7ecca170d`.
* Exact producer/consumer signature hashes remain the phase2a-approved `c1abe1c57e12337dc3592297e624edd757deb18f9eae17ecdc9faca40e2609f4` and `364843a1d3e581a3b9498eed483b0dff44faad722a67d90c46566da038fc4d2e`.

Source scopes reread in full are `S4.p1`, `S4.Thmtheorem1`, `S4.p2`, `S4.SS1`, `S4.SS2`, `S4.SS3`, and `A3.SS1` through `A3.SS4`. This is the full selected source slice, not the whole theorem's upstream-definition closure. The source's §2 conventions were independently read in phase1, but I do not silently promote the extractor's explicit `scope:QG-definition` marker to a completed node.

## Blocking finding TC-B1: missing polynomial-to-cosine dependency at Ex25

Affected edge: **`e:target-L2`**, consumer **`sg:target-L2`**, use site **`S4.SS3.SSS0.Px2.p3.1` / `S4.Ex25`**.

The source defines, at `S4.EGx2`,

`S_A(x)=(-1)^n x^T T_n((2A-(κ+1)I)/(κ−1)) x − 2τ‖x‖²`.

At the affected paragraph it sets `Z=S_A(Y)` and applies the means/variances for the **cosine quadratic** `Y^T O D_n O^T Y`, obtaining `E Z=(β−2τ)M` and the centered-L² variance bound. The mathematical link required at this consumer is

`T_n((2A-(κ+1)I)/(κ−1)) = O D_n O^T`,

already represented by **`br:polynomial-conjugation`**.

The current `e:target-L2` premises are `sg:test`, `sg:target-statistics`, `sg:target-moments`, `sg:target-coordinate-transfer`, `bg:C3-bias-ratio`, `sg:choose-d0`, and `br:centered-L2`. None supplies that link:

* `sg:test` is the literal **matrix-polynomial** definition of S.
* `sg:target-coordinate-transfer` supplies the Gaussian law, norm transport, and `Y^T O D_n O^T Y=U^T D_n U`; it does not identify the matrix polynomial with `O D_n O^T`.
* The moment, bias and L² nodes then control the cosine form and its norm term, not an unconnected matrix polynomial.

This is not repaired by the existence of `e:geometry` or `e:alg-prob`: those edges consume `br:polynomial-conjugation` in their own branches. `sg:energy-geometry` is explicitly a contextual explanation and is not an ancestor of `sg:target-L2`. The independently recomputed ancestor set confirms that **neither** `br:polynomial-conjugation` nor `sg:energy-geometry` reaches the affected target node. `edge-closure-evidence.json` pins that trace and the exact affected edge.

**Minimal requested revision:** add `br:polynomial-conjugation` to the premises of `e:target-L2`, with explicit consumed output “replace the matrix polynomial in Z=S_A(Y) by O D_n O^T before using the target cosine mean/variance,” and add the matching producer `consumer_uses` backlink. An equally explicit all-carrier coordinate-statistic adapter on that ancestor path would also resolve it, but would be a larger change. Do not force the normalized geometric-weights explanation to be a necessary premise, and do not add a MAIN/public theorem binder.

This finding is a graph omission, not a counterexample to the paper or exact signatures. The paper's algebraic identity is valid and already recorded; its consumer dependency is missing. The graph must be repaired by its original source extractor as a preserved successor, followed by independent rereview. I have not edited the challenged graph or supplied a replacement graph.

## Coverage result, independently derived from the raw HTML

The 10 indexed complete snippets were checked byte-for-byte against their original HTML intervals and their hashes. A separate HTMLParser enumeration of all selected `p`, `table`, and heading DOM elements then matched the coverage inventory by exact byte spans and raw hashes, not by trusting supplied counts. All paragraph/display dispositions were read and compared with their full source content and destination node.

The resulting inventory is 285 raw elements: 159 paragraphs, 85 displays/tables and 41 headings. Every element has exactly one disposition: 237 NODE and 48 EXCLUDED with reasons. There are no missing, extra or raw-hash-mismatched elements. All NODE destinations exist. These are audit consequences, not proof or formalization counts. `independent-coverage-check.json` preserves the per-element result.

The initial `S4.SS3.p3.1`, entire `S4.EGx2`, and `S4.SS3.p3.2` are covered by `sg:test`. The complete `S4.SS3.p4.1` is covered by `sg:energy-geometry`: nonnegative squared-coordinate weights normalized only for x≠0, the signed cosine threshold, magnitude plus target sign, and the strict-zero boundary are all retained. The graph does not replace the initial intrinsic polynomial event by normalized weights as its definition.

The exclusions are reasonable at this scope: navigation headings, roadmap paragraphs, prior-result/scope comparisons, and the recalled-grid roadmap in C.3. The four [22] citation occurrences are retained with explicit provenance exclusions. The selected paper supplies its own construction/statements and C.1 proof; [22] is not a hidden additional AND premise of the selected author route. No external [22] body was accessed or credited.

All 91 node records and 56 hyperedge records were inspected at their mathematical input/output and consumer-use fields. The independently checked endpoint/backlink database is consistent and acyclic. Those structural checks do not cure TC-B1. No additional mathematical defect was found in the remaining read edges at their explicitly unexpanded standard-input boundary; this does not turn unproved standard bridges into proved leaves.

## Bounded exact overlay: acceptable topology specification

The overlay faithfully connects the source bridge to the two exact types without claiming implementation use:

* `ov:e-coordinate` consumes the exact producer, the literal S and orthogonal coordinate/norm transport for `S(Rz)` feeding the **right** measure-equality conjunct. It is valid on all vectors, including zero.
* `ov:e-borel` uses fixed-matrix quadratic/norm continuity for the **left** measurability conjunct. It does not depend on the producer. The producer reaches the root through the equality branch, not through a fabricated measurability necessity.
* `ov:e-map` requires the literal measure, measurability of R and the strict event, then `ov:e-equality` combines preimage evaluation with pointwise statistic transport. `ov:e-root` is an AND because the exact statement asks for both outputs. These are not alternative complete proofs.
* The actual μ is the literal `multivariateGaussian 0 Λ⁻¹`; its actual map under the literal forward rotation R is evaluated on the literal event. The overlay correctly separates constructor semantics, latent-Gaussian recognition and rotated-target law recognition. The latter two are outside the local equality root.
* All natural n and real τ are explicit auxiliary generalizations. The source substitution n=2q+1 and τ=τ_{d,q} is recorded; neither q's budget nor τ's absolute-C/concentration/smallness conditions is silently discharged or deleted. Full O(d), including determinant −1, is retained. The source Haar/seed-independence experiment is outside this fixed-O helper.
* Real scalar `(κ−1)⁻¹` in B, matrix Λ⁻¹ in μ, algebraic matrix `aeval`, Nat-to-Int T_n, Euclidean WithLp coordinates, and the strict event at zero remain distinct. No off-source fallback weight definition is introduced. No MAIN theorem acquires an extra hypothesis.

The overlay's standard obligations remain obligations: finite-dimensional coordinate/isometry transport, R measurability, and ordinary map evaluation under the map constructor's measurability condition. Its explicit `proof_status=UNOBSERVED` is essential. Signature-level substantive use does not certify a Lean proof call or actual test reachability. The phase2a bounded statement/definition verdict is unchanged.

## Standard inputs, gaps and route logic

The source author route is algorithm rejection AND target acceptance AND per-input TV comparison, with a single eventual dimension threshold. The C.1 zero/nonzero residual cases are exhaustive cases of one argument, not OR routes; no alternative full source proof is invented. The two Gram events in C.2 are simultaneous requirements, with union bounds rather than an independence assumption. Gaussian starts are mutually independent but are not falsely asserted independent of O/X. Centered-L² does not assume independence of the two target quadratic forms. The normalized target bias remains a ratio of means, with exact finite-grid terms retained.

The 12 standard/scope records mark polynomial conjugation, orthogonal energy/zero semantics, fixed/joint event measurability, uniform asymptotics, law-preserving extension, Gaussian law/moments, centered L², Chebyshev, TV/averaging, matrix Bernstein, conditional Haar machinery, and the upstream Q_G definition. Named standard inputs remain distinct from omitted implicit bridges and the uninspected upstream-definition scope marker. Matrix Bernstein is correctly marked as a general theorem used without a precise numbered external citation at that source site. None is implementation Lean evidence. TC-B1 is specifically an omitted use of an already-present standard bridge, rather than a need to invent a new theorem premise.

## Unfinished boundaries and next action

Base selected-root topology remains **HOLD(TC-B1)**. Local auxiliary overlay is **ACCEPT_LOCAL_TOPOLOGY_SPECIFICATION_ONLY**. The source/library identification of μ.map R with π_A=N(0,A⁻¹), latent-law recognition sufficient for moments, concentration C, Haar/adaptive/Krylov experiment, algorithm rejection probability, target pass probability, uniform d0, per-input TV averaging, minimax/query/cost conclusion and upstream source-definition closure are not completed by these types/overlay. No Lean, native, sourceV, STAB, publication, global or wholeGoal credit is given.

Freeze this report and evidence now. Return TC-B1 to the original extractor for a transparent small successor graph; rereview that successor independently. Root process history/baseline/preparation scripts may be read only in a later separately authorized phase3, without changing this already-frozen mathematical verdict or prior source cognition.
