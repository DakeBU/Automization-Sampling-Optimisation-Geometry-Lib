from runner import *
import shutil
Q=OUT/'reader-conditional';Q.mkdir(exist_ok=False)
original=OUT/'reader-site-c4d031f';site=Q/'site';shutil.copytree(original,site)
patch=ROOT/'.astis/semantic-neutral-20261113/variance_native_61d0/production-proposal/table-scroll.patch'
assert sha(patch)=='2442d520f5888f665b8bd76777334d36a3e3346888c4c9cb309ae891280a2bff'
(Q/'table-scroll.patch').write_bytes(patch.read_bytes())
prod=Q/'production';css=prod/'website/static/proof-readers.css';css.parent.mkdir(parents=True)
before=(original/'assets/proof-readers.css').read_bytes();assert hashlib.sha256(before).hexdigest()=='4509e56205aa4bb94c3fa32c7b2b0bd98a9b44a71c23e09f18d5affe038512ad'
(Q/'proof-readers.original.css').write_bytes(before);css.write_bytes(before)
run('conditional-exact-patch',['/usr/bin/patch','--batch','--forward','-p1','-i',Q/'table-scroll.patch'],cwd=prod)
after=css.read_bytes()
assert after==before.replace(b'.proof-reader-equation mjx-container[display="true"]',b'.proof-reader .table-scroll { max-width: 100%; overflow-x: auto; }\n.proof-reader-equation mjx-container[display="true"]',1)
(site/'assets/proof-readers.css').write_bytes(after)
p,code=run('conditional-exact-cssdiff',['git','diff','--no-index','--',Q/'proof-readers.original.css',css],check=False);assert code==1
(Q/'actual-css.diff').write_bytes(p.with_suffix('.stdout').read_bytes())
before_hashes={str(p.relative_to(original)):sha(p) for p in original.rglob('*') if p.is_file()}
after_hashes={str(p.relative_to(site)):sha(p) for p in site.rglob('*') if p.is_file()}
assert before_hashes.keys()==after_hashes.keys()
changed=[p for p in before_hashes if before_hashes[p]!=after_hashes[p]];assert changed==['assets/proof-readers.css']
candidate={'kind':'CONDITIONAL UNAPPLIED shared production CSS patch; original browser FAIL retained',
 'reader_candidate':'c4d031f237fa0e16fbba16987ca6b34c7f3dfd98','original_css_sha256':hashlib.sha256(before).hexdigest(),'conditional_css_sha256':hashlib.sha256(after).hexdigest(),
 'patch_sha256':sha(Q/'table-scroll.patch'),'changed_site_files':changed,'site_file_count':len(after_hashes),
 'before_site_hashes':before_hashes,'after_site_hashes':after_hashes,
 'original_browser_freeze_sha256':sha(OUT/'reader/original-browser-freeze.json'),
 'native_math_freeze_sha256':sha(OUT/'math-freeze-manifest.json'),
 'checker':'check_conditional.py delegates the exact approved original checker after full immutable input hash guards',
 'global_css_changed':False,'browser_execution':'not yet attempted'}
files={str(p.relative_to(OUT)):sha(p) for root in [site,Q/'production'] for p in sorted(root.rglob('*')) if p.is_file()}
for p in [Q/'table-scroll.patch',Q/'proof-readers.original.css',Q/'actual-css.diff',OUT/'check_browser.py',OUT/'check_conditional.py',OUT/'runner.py']:
    files[str(p.relative_to(OUT))]=sha(p)
candidate['frozen_input_files']=files
(Q/'candidate.json').write_text(json.dumps(candidate,indent=2)+'\n')
print(json.dumps({'candidate_sha256':sha(Q/'candidate.json'),'patch_sha256':candidate['patch_sha256'],'css_sha256':candidate['conditional_css_sha256'],'site_files':len(after_hashes),'only_changed_file':changed[0],'checker_sha256':sha(OUT/'check_conditional.py')}))
