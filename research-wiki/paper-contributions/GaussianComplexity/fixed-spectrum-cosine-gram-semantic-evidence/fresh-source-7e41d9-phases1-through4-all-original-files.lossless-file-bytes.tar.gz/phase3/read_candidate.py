#!/opt/anaconda3/bin/python
import hashlib,json,pathlib,subprocess
BASE=pathlib.Path(__file__).resolve().parent
ROOT=pathlib.Path('/Users/zhouhuanjian/ASTIS-GC')
COMMIT='72e5d1405284f729f4eb600c5ae5dd556365b7e2'
E='research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-cosine-gram-semantic-evidence/'
paths=['AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumCosineGram.lean',
       'Tests/GaussianComplexityFixedSpectrumCosineGram.lean',
       'website/content/declaration_lessons/huanjian-fixed-spectrum-cosine-gram.json',
       'website/content/publications/huanjian-fixed-spectrum-cosine-gram.json',
       E+'source-to-lean-map-v1.json',
       'AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumGridAlias.lean']
(BASE/'inputs').mkdir(exist_ok=True)
records=[]
packet_path=E+'fresh-source-reviewer-packet.json'
data=(ROOT/packet_path).read_bytes()
assert hashlib.sha256(data).hexdigest()=='71a83188c154ecddba94fc180bfe6a35dae4678c644fea1390c311b3946cea09'
parsed=json.loads(data)
canonical=json.dumps(parsed,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()
records.append({'source':packet_path,'method':'working-tree authorized raw packet','bytes':len(data),
                'sha256':hashlib.sha256(data).hexdigest(),'canonical_sha256_computed':hashlib.sha256(canonical).hexdigest(),
                'snapshot':'inputs/fresh-source-reviewer-packet.json'})
(BASE/'inputs/fresh-source-reviewer-packet.json').write_bytes(data)
print('INPUT',json.dumps(records[-1]));print(data.decode())
for relative in paths:
    proc=subprocess.run(['git','show',COMMIT+':'+relative],cwd=ROOT,capture_output=True)
    name=relative.replace('/','__')
    (BASE/'inputs'/(name+'.stderr')).write_bytes(proc.stderr)
    assert proc.returncode==0,(relative,proc.returncode,proc.stderr.decode())
    (BASE/'inputs'/name).write_bytes(proc.stdout)
    records.append({'source':relative,'method':'git show','argv':['git','show',COMMIT+':'+relative],
                    'commit':COMMIT,'returncode':proc.returncode,'bytes':len(proc.stdout),
                    'sha256':hashlib.sha256(proc.stdout).hexdigest(),'snapshot':'inputs/'+name,
                    'stderr_snapshot':'inputs/'+name+'.stderr','stderr_bytes':len(proc.stderr)})
    print('INPUT',json.dumps(records[-1]));print(proc.stdout.decode())
(BASE/'input_inventory.json').write_text(json.dumps(records,indent=2)+'\n')
