# Mode-gap exact v2 projection: independent statement judgment

**ACCEPT_STATEMENT_BINDER_DEFINITION_SCOPE_ONLY. No statement-level HOLD was found.** This does not admit an extractor graph or authorize proof/API work, normal intake, source V or Goal credit. The new process chronology remains unread. Stop before those inputs.

Exact new input is the 4332-byte strict v2 projection SHA-256 `54b23ce1ccd86b780b8c2b38bb18ac3cf91b5102afefe15444b2231e1b65c0f9`. Parent authority binds it to full statement-seal-v1 SHA-256 `1f9228d5caa180bc26ae9e47dc86b2d4be074c499b670a9a9a639da67457fb0c`; neither the full seal nor the unissued v1 projection was opened. That parent-supplied full-seal binding is not misrepresented as an independent full-file inspection. The source pin and own phase1 freeze `e82bcd88ca0b31661e035c25164e51b356a48b87e6771ed77dcce458aa7015b2` were rechecked unchanged, including all eight phase1 checksum members.

## Quantifiers and the public prerequisite

The public statement faithfully isolates the unnamed numerical applicability component of S4.3. It fixes real δ with 0<δ<1, **outputs** an existential natural threshold, then quantifies all larger natural dimensions, every real κ in the exact original range 2≤κ≤d^(1−δ), and every natural q satisfying the exact budget inequality q≤(δ/256)√κ log d. Its local mode is literally n=2q+1.

There is one d0 for the fixed δ, uniformly before κ and q are chosen. The statement does not weaken this to a threshold depending on κ/q, or assume a fixed parameter sequence when claiming uniformity. A natural dimension threshold is faithful to the paper's sufficiently-large-d convention; it is not a separately chosen characterized object or an assumed successful gate.

All four conclusions are outputs: 2≤d, 1≤n, n<d and √κ≤(d:Real)−(n:Real). In particular the needed mode and gap facts have not been moved into the public hypotheses. The positive source query mode includes q=0. No q≥1 or arbitrary rounding convention has been introduced. The real gap subtraction is subtraction of casts, with no natural truncation.

The threshold need not itself be asserted ≥2: the output requires the actual active dimensions to meet that source range. The witness and any enlargement needed to guarantee it are internal obligations. No dimension-dependent regularity, Gaussian moment, τ, β, query algorithm, probability or TV certificate is supplied as an input. The public component is a scalar prerequisite, not Theorem4.1's oracle/query-complexity conclusion.

## Recursive binder audit

The signature contains only standard carriers and ordinary logical guards, with no project-owned Prop alias, structure or typeclass hiding further assumptions. After expanding the nested universal/implication scope, there are ten universally supplied carrier/guard items per statement; the existential witness is not an input:

| Item | Classification or logical role |
| --- | --- |
| δ:Real | TYPING |
| 0<δ | SOURCE |
| δ<1 | SOURCE |
| d0:Nat | Existential **output**, not a Source-Anchor hypothesis or a sixth bin |
| d:Nat | TYPING |
| d0≤d | SOURCE sufficiently-large-d clause relative to the output witness |
| κ:Real | TYPING |
| 2≤κ | SOURCE original scalar regime |
| κ≤d^(1−δ) | SOURCE original growth regime |
| q:Nat | TYPING representation of the nonnegative integer query count |
| q≤(δ/256)√κ log d | SOURCE original scalar budget condition |
| n:=2q+1 | Literal local definition, not a new binder |

There is no EXCESS public input. The d0 guard belongs to the source's existential eventual quantification; it is not a proof-result gate added to an otherwise unconditional main theorem. Conversely, those source-regime conditions cannot later be dropped when claiming this prerequisite as an input to a full paper result.

The source's separate statement of d−n≥√κ as a premise of Lemma4.5 and its derivation as an output in S4.3 have been kept distinct. No variance, log-bound, mean or source-Gaussian input is needed by this numerical producer just because another lemma consumes the resulting range facts.

## Private actual Gaussian component

The private theorem has the same nested scalar regime and no new assumed numerical premise. Its threshold is again output before all κ/q choices. Separate existential thresholds do not require a new input asserting witness equality; any common sufficient threshold must be supplied internally when composing results.

The actual normalized-bias conclusion agrees with the Ex23 numerical component: exact constant `(1−exp(−4))*exp(−3)` and dimension exponent `−δ/4`, plus positivity of actual M and signed actual mean. Its local variable b is the actual Q mean; it is distinct from the source's fixed scalar constant also denoted b in Ex23. The signature spells the fixed scalar constant out, so there is no name-driven semantic substitution.

The result is a ratio of actual Gaussian expectations. It is not a samplewise normalized statistic, expected ratio, shifted event or probability. Keeping (−1)^n*b correctly represents the source sign, including the odd query mode. The private conclusion is mathematically substantive: a new actual-law polynomial bias estimate in the query regime, not the producer's range statement copied into a wrapper. A real consumer must use the applicability bridge internally rather than take its outputs as extra hypotheses. Actual implementation use remains a later proof review and is not certified here.

`is_source_anchor:false` and the explicit private scope identify a non-Anchor application, not an additional public source Anchor. Its domain entries have exact source-regime correspondence; no invented private setting is promoted source-wide. The numerical component does not assert the original τ/β branch of Ex24, nonzero-threshold contrast or Ex26, orthogonal Y-to-U transport, algorithmic event, oracle, TV or cost theorem. Accuracy ε has no role in this isolated scalar/moment component; its absence does not purport to remove ε from the main theorem.

## Literal definitions and standard totalizations

The public mode definition is literal natural arithmetic. Real powers in the regime and private conclusion are standard real powers, not natural exponents disguised by notation. Source-domain care is required for the real log/powers at dimension zero, sqrt and division; eventual 2≤d and κ≥2 must be established internally, not inferred from a favorable off-domain totalization. There is no custom `if`, fallback or choice-based definition.

The private Fin d grid `(i.val+1/2)*π/d` is the original one-based midpoint after i_source=i.val+1. The eigenvalue coefficients and diagonal precision Λ are exact. The Gaussian's matrix argument is covariance **Λ⁻¹**, while Λ is precision. Q is the literal coordinate-square cosine quadratic. M and b are actual real Bochner integrals under that same centered law, with no closed formula or desired bound defined into them.

Actual positive precision/inverse covariance, intended Gaussian semantics and integrability must be established internally by corresponding actual-law facts. Standard square-root/inverse/log/rpow/division and integral totalizations do not authorize default-zero closure. The positive M and signed-b outputs preclude merely satisfying the claimed bias by treating nonintegrable means or a zero denominator as its intended source value. No such positivity/integrability estimate is an extra input. The projection's `approved_definition_context` was assessed as explanatory text, not adopted as a proof certificate.

No fresh Mathlib body or API was inspected. Standard Gaussian/Euclidean/integral semantics were encountered in earlier authorized roles and are disclosed prior knowledge, not a new byte audit. The complete new meaning-carrying local bodies are visible literal lets; no unseen new project-owned definition is used by the projected signatures.

## Hashes, exposure and next boundary

The exact signature strings were independently rehashed:

- Producer: 387 bytes, `cdc9becb20a9cbf4f0845d530985aca5135385f85fffd24f5579a9de28d305fa`.
- Private consumer: 1093 bytes, `936256d033cbb37521807785cafe36f0897de549d7ac187123ec9e57bd98573b`.

The new raw-first cognition preceded this projection. Earlier C7/Bias/other source-challenge and process roles remain disclosed; no pristine unfamiliarity is claimed. Parent reported an unissued projection containing removed metadata; it was not opened, so no comparison to its hidden content or route advice is inferred. No new process-chronology note or current root planning record has been read, and no assertion of root's pristine planning history is made.

Extractor coverage, all node/edge semantics, conditional selectors, source/prior-prerequisite boundaries and complete producer/private root closures remain a separate pending challenge. This statement-only ACCEPT neither substitutes for that challenge nor grants prospective proof/API permission. No implementation, old verdict artifact, API/Mathlib body, lesson/audit, full seal, frontier/ledger, build, normal transition, source V or Goal completion was accessed or executed. Only the new private phase2a directory was written. Stop here.
