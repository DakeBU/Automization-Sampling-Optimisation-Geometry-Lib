# Raw-source extracts

Pinned source: .astis/huanjian-resume-20261103/2610.20492v1.html

Bytes: 951991

SHA256: 6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915

## S4.SS1.p1

We use a construction similar to that in [22, Section 9.2],
with a cosine eigenvalue grid (Chebyshev nodes) and a random orthogonal rotation, while extending the spectral
interval from $[1,2]$ to $[1,\kappa]$.
For $d\geq 2$ and $\kappa\geq 2$, define





$\theta_{i}=\frac{(i-\tfrac{1}{2})\pi}{d},\qquad\lambda_{i}=\frac{\kappa+1}{2}+\frac{\kappa-1}{2}\cos\theta_{i},\qquad\Lambda=\operatorname{diag}(\lambda_{1},\ldots,\lambda_{d}).$

(11)


Draw $O\sim\operatorname{Haar}(\mathrm{O}(d))$, independently
of the algorithm’s private randomness, and set $A=O\Lambda O^{\top}$.
The associated potential and target are
$f_{A}(x)=x^{\top}Ax/2$ and $\pi_{A}=N(0,A^{-1})$.

## S4.Thmtheorem3

Lemma 4.3 (Krylov representation).



Fix an integer $q\geq 0$ with $2q+1<d$ and let $X$ be the output. There exist independent vectors
$g_{1},\ldots,g_{q+1}\sim N(0,I_{d})$ such that





$O^{\top}X\in\mathcal{K}_{q}(g_{1},\ldots,g_{q+1})\qquad\text{almost surely}.$

## S4.Thmtheorem4

Lemma 4.4 (Uniform bound on the Krylov space).



There is an absolute constant $C>0$ such that the following holds.
Let $q\geq 0$ satisfy $2q+1<d$, let
$g_{1},\ldots,g_{q+1}$ be independent $N(0,I_{d})$ vectors, and let
$\mathcal{K}_{q}=\mathcal{K}_{q}(g_{1},\ldots,g_{q+1})$.
Define





$\tau_{d,q}=C\left[(q+1)\sqrt{\frac{\log d}{d}}+\frac{(q+1)(q+1+\log d)\log d}{d}\right].$



If $\tau_{d,q}\leq 1/2$, then, with probability at least $0.99$,





$|u^{\top}D_{n}u|\leq 2\tau_{d,q}\|u\|^{2}\qquad\text{for every }u\in\mathcal{K}_{q}.$

## A3.SS2.p1

Set $r=q+1$ and $n=2q+1$. For $1\leq i\leq d$, define





$t_{i}=(1,\sqrt{2}\cos\theta_{i},\ldots,\sqrt{2}\cos(q\theta_{i}))^{\top},\qquad\gamma_{i}=((g_{1})_{i},\ldots,(g_{r})_{i})^{\top}.$



The vectors $\gamma_{1},\ldots,\gamma_{d}$ are independent
$N(0,I_{r})$. Let $B\in\mathbb{R}^{d\times r^{2}}$ have
$i$th row $d^{-1/2}(\gamma_{i}\otimes t_{i})^{\top}$.

## A3.SS2.p4

$\boxed{\mathbb{E}[B^{\top}B]=I_{r^{2}}}$.
Recall that $\theta_{i}=(i-\tfrac{1}{2})\pi/d$.
For every integer $k$ with $0<|k|<2d$,





$\displaystyle 2\sin\!\left(\frac{k\pi}{2d}\right)\sum_{i=1}^{d}\cos(k\theta_{i})$
$\displaystyle=\sum_{i=1}^{d}\left[\sin\!\left(\frac{ki\pi}{d}\right)-\sin\!\left(\frac{k(i-1)\pi}{d}\right)\right]$




$\displaystyle=\sin(k\pi)-\sin(0)=0.$



Since $\sin(k\pi/(2d))\neq 0$, this gives
$\sum_{i}\cos(k\theta_{i})=0$.

## A3.SS2.p5

Index the coordinates of $t_{i}$ by $0,\ldots,q$.
The entries involving the constant coordinate satisfy





$\sum_{i}(t_{i})_{0}^{2}=d,\qquad\sum_{i}(t_{i})_{0}(t_{i})_{j}=\sqrt{2}\sum_{i}\cos(j\theta_{i})=0\quad(1\leq j\leq q).$



For $1\leq j,k\leq q$, the product-to-sum identity gives





$\displaystyle\sum_{i}(t_{i})_{j}(t_{i})_{k}$
$\displaystyle=2\sum_{i}\cos(j\theta_{i})\cos(k\theta_{i})$




$\displaystyle=\sum_{i}\cos((j-k)\theta_{i})+\sum_{i}\cos((j+k)\theta_{i})$




$\displaystyle=\begin{cases}d,&j=k,\\
0,&j\neq k.\end{cases}$



Indeed, $0<j+k\leq 2q<2d$, while $j-k=0$ exactly
when $j=k$; otherwise $0<|j-k|<2d$.
By symmetry, these calculations cover all matrix entries,
and hence $\sum_{i}t_{i}t_{i}^{\top}=dI_{r}$.

## A3.SS2.p8

Finally,





$\|t_{i}\|^{2}=1+2\sum_{j=1}^{q}\cos^{2}(j\theta_{i})\leq 1+2q\leq 2r.$



∎

## A3.SS2.p10

Truncation and its bias.
Set
$L=2r+3\log(1000d)$ and $R_{i}=\|\gamma_{i}\|^{2}$.
Since $\mathbb{E}e^{R_{i}/3}=3^{r/2}$,
Markov’s inequality gives, for $x\geq 0$,





$\mathbb{P}(R_{i}>2r+3x)\leq\exp\!\left(\frac{r}{2}\log 3-\frac{2r}{3}-x\right)\leq e^{-x},$



where the last inequality uses $(\log 3)/2<2/3$.
Consequently, the event





$\mathcal{T}=\{R_{i}\leq L\text{ for every }i\}$



has probability at least
$1-d/(1000d)=0.999$.

## A3.SS2.p11

For $s\geq 0$, the same tail bound gives
$\mathbb{P}(R_{i}>L+s)\leq e^{-s/3}/(1000d)$.
Hence





$\displaystyle\mathbb{E}[R_{i}\mathbf{1}_{\{R_{i}>L\}}]$
$\displaystyle=L\mathbb{P}(R_{i}>L)+\int_{0}^{\infty}\mathbb{P}(R_{i}>L+s)\,ds\leq\frac{L+3}{1000d}.$

## A3.SS2.p12

Define the independent truncated matrices





$Y_{i}=\frac{1}{d}(\gamma_{i}\gamma_{i}^{\top}\otimes t_{i}t_{i}^{\top})\mathbf{1}_{\{R_{i}\leq L\}}.$



By radial symmetry,





$\mathbb{E}[\gamma_{i}\gamma_{i}^{\top}\mathbf{1}_{\{R_{i}\leq L\}}]=aI_{r},\qquad a=\frac{1}{r}\mathbb{E}[R_{i}\mathbf{1}_{\{R_{i}\leq L\}}].$



The scalar $a$ is the same for every $i$.
Since $\mathbb{E}R_{i}=r$, we have $0\leq a\leq 1$ and





$1-a=\frac{1}{r}\mathbb{E}[R_{i}\mathbf{1}_{\{R_{i}>L\}}]\leq\frac{L+3}{1000rd}.$



Moreover,
$\mathbb{E}Y_{i}=(a/d)(I_{r}\otimes t_{i}t_{i}^{\top})$.
Fact C.5 therefore gives





$\sum_{i}\mathbb{E}Y_{i}=aI_{r^{2}},\qquad\sum_{i}\cos(n\theta_{i})\mathbb{E}Y_{i}=0.$



Thus, the truncated weighted sum has zero expectation.

## A3.SS2.p13

Bounds for the centered summands.
Put $Z_{i}=Y_{i}-\mathbb{E}Y_{i}$.
Using $\|t_{i}\|^{2}\leq 2r$, we obtain





$\|Y_{i}\|_{\rm op}=\frac{R_{i}\|t_{i}\|^{2}}{d}\mathbf{1}_{\{R_{i}\leq L\}}\leq\frac{2rL}{d},\qquad\|\mathbb{E}Y_{i}\|_{\rm op}=\frac{a\|t_{i}\|^{2}}{d}\leq\frac{2r}{d}.$



Hence





$\|Z_{i}\|_{\rm op}\leq\frac{2r(L+1)}{d}=:R_{*}.$



The same bound holds for
$\cos(n\theta_{i})Z_{i}$, since $|\cos(n\theta_{i})|\leq 1$.

## A3.SS2.p14

The Gaussian fourth moments give





$\mathbb{E}[R_{i}\gamma_{i}\gamma_{i}^{\top}]=(r+2)I_{r}.$



Indeed, the off-diagonal entries vanish by sign symmetry,
while each diagonal entry equals $3+(r-1)=r+2$.
Since
$(\gamma_{i}\gamma_{i}^{\top})^{2}=R_{i}\gamma_{i}\gamma_{i}^{\top}$
and
$(t_{i}t_{i}^{\top})^{2}=\|t_{i}\|^{2}t_{i}t_{i}^{\top}$,
we have





$Y_{i}^{2}=\frac{R_{i}\|t_{i}\|^{2}}{d^{2}}(\gamma_{i}\gamma_{i}^{\top}\otimes t_{i}t_{i}^{\top})\mathbf{1}_{\{R_{i}\leq L\}}.$



Dropping the truncation indicator in this positive
semidefinite expression yields





$\displaystyle\sum_{i}\mathbb{E}Y_{i}^{2}$
$\displaystyle\preceq\frac{r+2}{d^{2}}\sum_{i}\|t_{i}\|^{2}(I_{r}\otimes t_{i}t_{i}^{\top})$




$\displaystyle\preceq\frac{2r(r+2)}{d^{2}}\left(I_{r}\otimes\sum_{i}t_{i}t_{i}^{\top}\right)$




$\displaystyle=\frac{2r(r+2)}{d}I_{r^{2}}.$



Here we used $\|t_{i}\|^{2}\leq 2r$ and
$\sum_{i}t_{i}t_{i}^{\top}=dI_{r}$.
Since





$\mathbb{E}Z_{i}^{2}=\mathbb{E}Y_{i}^{2}-(\mathbb{E}Y_{i})^{2}\preceq\mathbb{E}Y_{i}^{2},$



the sequence $(Z_{i})_{i}$ has variance parameter at most





$v_{*}:=\frac{2r(r+2)}{d}.$



The same is true for $(\cos(n\theta_{i})Z_{i})_{i}$, because





$\mathbb{E}[(\cos(n\theta_{i})Z_{i})^{2}]=\cos^{2}(n\theta_{i})\mathbb{E}Z_{i}^{2}\preceq\mathbb{E}Z_{i}^{2}.$
