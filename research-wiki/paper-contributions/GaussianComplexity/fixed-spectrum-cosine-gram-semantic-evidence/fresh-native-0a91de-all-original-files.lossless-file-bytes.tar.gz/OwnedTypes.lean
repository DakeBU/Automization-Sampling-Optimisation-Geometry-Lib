import Tests.GaussianComplexityFixedSpectrumCosineGram
open Lean
set_option autoImplicit false

run_cmd do
  setEnv ((← getEnv).setExporting false)
  let env ← getEnv
  let some pi := env.getModuleIdx? `AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumCosineGram
    | throwError "Missing producer module"
  let some ti := env.getModuleIdx? `Tests.GaussianComplexityFixedSpectrumCosineGram
    | throwError "Missing consumer module"
  let owned := env.constants.toList.filter (fun (n, _) =>
    env.getModuleIdxFor? n == some pi || env.getModuleIdxFor? n == some ti)
  for (n, ci) in owned do
    match ci with
    | .thmInfo _ => pure ()
    | _ => throwError "Owned constant is not a kernel-checked theorem of a Prop: {n}"
    unless !ci.type.hasFVar && !ci.type.hasMVar && !ci.type.hasLooseBVars do
      throwError "Owned type is not closed: {n}"
    logInfo m!"OWNED_EXACT_CLOSED_PROP_TYPE {n}: {ci.type}"
  logInfo m!"ALL_OWNED_EXACT_CLOSED_PROP_TYPES {owned.length}"
