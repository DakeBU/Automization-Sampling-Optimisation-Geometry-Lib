"""Run only after exact-HEAD canonical gates; real Chrome determinant reader checks. PREPARATION ONLY until separately authorized after final gates."""
import datetime
import functools
import hashlib
import http.server
import json
from pathlib import Path
import re
import subprocess
import sys
import threading
from urllib.parse import quote, urljoin, urlsplit

from playwright.sync_api import sync_playwright

ROOT = Path.cwd()
SITE = ROOT / '_site'
sys.path.insert(0, str(ROOT / 'website/scripts'))
sys.path.insert(0, str(ROOT / 'tools'))
import inline_lean
import astis_site
import astis_publication

sha = lambda raw: hashlib.sha256(raw).hexdigest()
HEAD = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
PREFIX = 'AutoSamplingTheory.ExampleCases.GaussianComplexity.'
NAME = PREFIX + 'FixedSpectrumDeterminant.actual_precision_det'
MODULE = PREFIX + 'FixedSpectrumDeterminant'
ITEM = 'huanjian-fixed-spectrum-determinant'
CANONICAL_GAUSSIAN = 'AutoSamplingTheory.TechnicalLemmas.Measure.GaussianPrecisionDensity.multivariateGaussian_eq_withDensity_of_posDef'
BINDING = 'c70bb9b23e335acf768bb889f8229fcdf2a7af160e10fa89779d00dcba58374b'
CANONICAL_PARENT = 'AutoSamplingTheory.TechnicalLemmas.Measure.DisplacementJacobianEntropy.det_conjStarAlgAut_eq'
ADMISSIBILITY = PREFIX + 'FixedSpectrumAdmissibility.actual_precision_admissible'
CONSUMER_ASTIS_PARENTS = [ADMISSIBILITY, NAME, CANONICAL_GAUSSIAN]
PINS = {
    'AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumDeterminant.lean': 'adcf336b0774dbbd5f8976b25e50c8723d14a6dab2582faee6db4d365afac9dc',
    'Tests/GaussianComplexityFixedSpectrumDeterminant.lean': '2be2c84620313264b486e20ba84904403e2ee54706bcfa2b36f929d896d9e1ec',
    'website/content/declaration_lessons/huanjian-fixed-spectrum-determinant.json': '4a3a9a3de61c2a4ffe4a8be518dcfb206273df337d7eedbd30c931c832131b95',
    'website/content/publications/huanjian-fixed-spectrum-determinant.json': 'b0ac72466ffe28e2b890400514b67236e02389e6a25e9f3d58e14f1cf5910ece',
    'AutoSamplingTheory/TechnicalLemmas/Measure/DisplacementJacobianEntropy.lean': 'a1bf2e9e21e00f1ad7dd01acadc47ea914c2a03b45c82db2aeb927336612fd85',
    'website/content/graph_memory_index.json': '019497faee75c5844ff3d3a08b0ce61c25256918cc29c45b2de5bbaca490b607',
    'website/content/functor_hypergraph.json': '94b56f87136ca97820893e5531d16d36334d44bc6b9e41981d39aa700f8fe782',
}
for path, digest in PINS.items():
    raw = (ROOT / path).read_bytes()
    assert sha(raw) == digest, path
    assert subprocess.check_output(['git', 'show', HEAD + ':' + path]) == raw, path
metadata_path = SITE / 'data/build-metadata.json'
metadata = json.loads(metadata_path.read_bytes())
gate_path = ROOT / '.astis/site-lean-gate.json'
gate = json.loads(gate_path.read_bytes())
assert gate['passed'] and gate['commit'] == metadata['git']['commit'] == HEAD
assert metadata['gate']['passed'] and metadata['gate']['current']
assert gate['source_digest'] == metadata['source_digest'] == astis_site.source_digest()
unit = json.loads((ROOT / 'website/content/declaration_lessons/huanjian-fixed-spectrum-determinant.json').read_bytes())['units'][0]
assert unit['declaration'] == NAME and unit['reading_layout'] == 'progressive'
assert unit['astis_dependencies'] == [CANONICAL_PARENT] and len(unit['steps']) == 5 and unit['mathlib_dependencies']
capsule_path = ROOT / 'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-determinant-semantic-evidence/local-proof-capsule.json'
capsule = json.loads(capsule_path.read_bytes())
assert capsule['actual_ASTIS_producer_parents'] == [CANONICAL_PARENT]
assert capsule['actual_ASTIS_consumer_parents'] == CONSUMER_ASTIS_PARENTS
assert capsule['production_and_Test_sha256'] == {k:v for k,v in PINS.items() if k.endswith('.lean') and 'FixedSpectrumDeterminant' in k}
pub = next(x for x in astis_publication.load() if x['id'] == ITEM)
assert astis_publication.binding_digest(pub, pub['bindings'][0]) == BINDING
astis_publication.check_advance([NAME], reviewed=True)
rows = {x['declaration']: x for x in json.loads((SITE / 'data/declaration-exposition.json').read_bytes())}
declarations = inline_lean.declarations()
graph = json.loads((SITE / 'data/underlying-lean-graph.json').read_bytes())
nodes = {x['id']: x for x in graph['nodes']}
own_id = 'decl:' + NAME
module_id = 'module:' + MODULE
canonical_id = 'decl:' + CANONICAL_GAUSSIAN
parent_id = 'decl:' + CANONICAL_PARENT
parent_module_id = 'module:AutoSamplingTheory.TechnicalLemmas.Measure.DisplacementJacobianEntropy'
assert sum(x['id'] == own_id for x in graph['nodes']) == 1
assert sum(x['id'] == canonical_id for x in graph['nodes']) == 1
assert sum(x['id'] == parent_id for x in graph['nodes']) == 1
assert nodes[parent_id]['kind'] == 'declaration'
assert sum(e['source'] == parent_module_id and e['target'] == parent_id and e['relation'] == 'declares' for e in graph['edges']) == 1
parent_reference_edges = [e for e in graph['edges'] if e['source'] == parent_id and e['target'] == own_id]
assert len(parent_reference_edges) == 1 and parent_reference_edges[0]['relation'] == 'source reference (scanner)'
# The actual kernel-parent evidence is the separate pinned producer/Test record.
# The displayed edge remains only a source-name scan; never relabel it formal.
assert nodes[module_id]['kind'] == 'module' and nodes[own_id]['kind'] == 'declaration'
assert sum(e['source'] == module_id and e['target'] == own_id and e['relation'] == 'declares' for e in graph['edges']) == 1
assert not [e for e in graph['edges'] if e['target'] == own_id and e['source'].startswith('decl:AutoSamplingTheory.') and e['relation'] in ('imports', 'declares')]
model = json.loads((ROOT / 'website/content/functor_hypergraph.json').read_bytes())
memory = json.loads((ROOT / 'website/content/graph_memory_index.json').read_bytes())
bridge = 'transport:gaussian-quadratic-oracle-factorization'
edge = next(e for e in model['hyperedges'] if e['id'] == bridge)
family = next(f for f in memory['families'] if f['id'] == 'family:gaussian-oracle-hardness')
assert edge['formal_refs'] == [] and edge['status'] == 'not-Lean-certified'
assert not [b for b in family['compiled_substrate_bindings'] if b['node'] == MODULE]
assert module_id not in nodes[bridge].get('candidate_substrates', [])
assert nodes[bridge]['hyperedge'] == edge
assert not [e for e in graph['edges'] if e['source'] == module_id and e['target'] == bridge]

OUT = ROOT / '.astis/huanjian-gc-fixed-spectrum-determinant-integration-20261108/browser' / ('live-' + datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ'))
OUT.mkdir(parents=True, exist_ok=False)
report = {
    'head': HEAD, 'mode': 'Actual current local site over HTTP, installed headless Chrome with isolated profile; external hosts blocked',
    'site_metadata_sha256': sha(metadata_path.read_bytes()), 'actual_gate_sha256': sha(gate_path.read_bytes()),
    'compilation_boundary': 'The genuine canonical gate commit, generated site commit and current immutable HEAD are identical; current Lean source digest is also identical. This is actual exact-HEAD gate evidence.',
    'actual_gate_commit': gate['commit'], 'site_commit': metadata['git']['commit'], 'source_digest': gate['source_digest'],
    'publication_binding_sha256': BINDING, 'input_pins': PINS,
    'pages': [], 'graphs': [], 'visible_source_index_clicks': [], 'errors': [], 'screenshots': [],
    'external_GitHub_HTML_checked': False,
    'external_source_boundary': 'Own-site source/module/downloads are checked against immutable local Git objects. Each page row records whether its GitHub commit/path syntax branch actually executed; null means no such syntax claim. External GitHub HTML and public HTTP publication are not checked.',
    'producer_ASTIS_parents': [CANONICAL_PARENT],
    'producer_parent_evidence': {'capsule': str(capsule_path.relative_to(ROOT)), 'sha256': sha(capsule_path.read_bytes()), 'scope': 'Existing actual kernel inventory, not source scanner or fresh compilation by this browser script.'},
    'consumer_ASTIS_parents': CONSUMER_ASTIS_PARENTS,
    'consumer_visibility': 'Private Test name used only for proof reflection; no public or Registry consumer node.',
    'canonical_Gaussian_dependency_role': 'Identical existing declaration reused with actual admissibility and new determinant in the same-A focused Test; GPD is not the determinant producer parent.',
}


class Quiet(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *_):
        pass


server = http.server.ThreadingHTTPServer(('127.0.0.1', 0), functools.partial(Quiet, directory=str(SITE)))
threading.Thread(target=server.serve_forever, daemon=True).start()
base = f'http://127.0.0.1:{server.server_port}/'


def screenshot(page, name):
    p = OUT / (name + '.png')
    page.screenshot(path=str(p))
    report['screenshots'].append({'file': p.name, 'sha256': sha(p.read_bytes())})


def math_ready(page):
    page.wait_for_function('Boolean(window.MathJax?.startup?.promise)', timeout=30000)
    page.evaluate('() => MathJax.startup.promise')
    assert page.locator('mjx-container').count() > 0
    assert page.locator('mjx-merror, [data-mjx-error]').count() == 0


def no_page_overflow(page):
    assert not page.evaluate('document.documentElement.scrollWidth > innerWidth + 1'), page.url


def focused_entry(page, ident, query, view='lean'):
    route = 'lean-foundations.html?view=' + view + '&focus=' + quote(ident, safe='') + '&q=' + quote(query, safe='')
    assert page.goto(base + route, wait_until='domcontentloaded').status == 200
    page.wait_for_selector('.ulg-canvas[data-view="' + view + '"][data-local="true"]')
    selected = page.locator('.ulg-node.selected[data-id="' + ident + '"]')
    selected.wait_for()
    page.wait_for_function("document.querySelector('.ulg-canvas>small').textContent.includes('Focused result at readable scale')")
    math_ready(page)
    page.locator('[data-graph-canvas]').scroll_into_view_if_needed()
    box = selected.locator('rect').bounding_box()
    canvas = page.locator('[data-graph-canvas]').bounding_box()
    assert box['width'] >= 160 and box['x'] >= canvas['x'] - 1 and box['x'] + box['width'] <= canvas['x'] + canvas['width'] + 1
    selected.click()
    no_page_overflow(page)
    return {'route': route, 'selected_native_click': True, 'node_box': box, 'canvas_box': canvas, 'scope': 'Readable focused entry plus native click; no all-label Fit readability or manual touch gesture claim.'}


try:
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True, executable_path='/Applications/Google Chrome.app/Contents/MacOS/Google Chrome')
        report['browser_version'] = browser.version
        context = browser.new_context(viewport={'width': 1440, 'height': 1000})
        context.route(re.compile(r'https?://(?!127\.0\.0\.1:)'), lambda route: route.abort())
        page = context.new_page()
        page.on('pageerror', lambda error: report['errors'].append(str(error)))
        for width in (1440, 390):
            page.set_viewport_size({'width': width, 'height': 1000 if width > 400 else 844})
            route = rows[NAME]['page']
            assert page.goto(base + route, wait_until='domcontentloaded').status == 200
            math_ready(page)
            assert HEAD[:12] in page.locator('.verification-strip').text_content()
            article = page.locator(f'article[data-authored-declaration="{NAME}"]')
            assert article.count() == 1 and article.locator('details[open]').count() == 0
            assert article.locator('.reader-main-equation mjx-container').count() == 1
            statement = article.locator(f'details.inline-lean-statement[data-inline-lean="{NAME}"]')
            proof = article.locator(f'details.inline-lean-proof[data-inline-lean="{NAME}"]')
            exact = inline_lean.display_source(declarations[NAME].source_text)
            signature, _ = inline_lean.split_statement(exact)
            assert statement.locator('code.language-lean').first.text_content() == signature
            assert proof.locator('code.language-lean').first.text_content() == exact
            assert article.locator('.reader-first-pass details.inline-lean-statement').count() == 1
            assert article.locator('.lean-verification details.inline-lean-proof').count() >= 1
            no_page_overflow(page)
            article.locator('.reader-first-pass').scroll_into_view_if_needed()
            screenshot(page, f'actual-{width}-first')
            assumptions = article.locator('.assumption-ledger')
            assumptions.locator(':scope > summary').click()
            txt = assumptions.text_content()
            for phrase in ('either determinant sign', 'zero-based', 'no Haar-law', 'prefactor', 'quadratic exponent', 'odd dimensions', 'known-normalizer'):
                assert phrase.lower() in txt.lower(), phrase
            assert assumptions.get_attribute('open') is not None
            no_page_overflow(page)
            assumptions.scroll_into_view_if_needed()
            screenshot(page, f'actual-{width}-assumptions')
            assumptions.locator(':scope > summary').click()
            steps = article.locator('details.reader-proof-disclosure')
            assert steps.count() == 5
            for i in range(5):
                step = steps.nth(i)
                step.locator('summary').first.click()
                assert step.locator('mjx-container').count() > 0
                assert unit['steps'][i]['title'] in step.text_content()
                nested = step.locator('.reader-step-body > details')
                assert nested.count() == 1 and nested.get_attribute('open') is None
                nested.locator(':scope > summary').click()
                assert unit['steps'][i]['lean'] in nested.text_content()
                if i == 1:
                    assert CANONICAL_PARENT in nested.text_content()
                if i == 4:
                    for parent in ('FixedSpectrumDeterminant.actual_precision_det', 'FixedSpectrumAdmissibility.actual_precision_admissible', 'GaussianPrecisionDensity.multivariateGaussian_eq_withDensity_of_posDef'):
                        assert parent in nested.text_content()
                no_page_overflow(page)
                step.scroll_into_view_if_needed()
                screenshot(page, f'actual-{width}-proof-step{i+1}')
                nested.locator(':scope > summary').click()
                step.locator('summary').first.click()
            provenance = article.locator('details.proof-reader-provenance')
            assert provenance.count() == 1
            provenance.locator(':scope > summary').click()
            parent_list = provenance.locator('ul').first.locator('li')
            assert parent_list.count() == 1
            assert parent_list.first.locator('code').text_content() == CANONICAL_PARENT
            parent_source_href = parent_list.first.locator('a').get_attribute('href')
            assert context.request.get(urljoin(page.url, parent_source_href)).status == 200
            for dep in unit['mathlib_dependencies']:
                assert dep in provenance.text_content(), dep
            assert 'Samplinglib parents called' in provenance.text_content() and 'Mathlib API called' in provenance.text_content()
            provenance.scroll_into_view_if_needed()
            no_page_overflow(page)
            screenshot(page, f'actual-{width}-standard-reuse')
            provenance.locator(':scope > summary').click()
            statement.locator('summary').first.click()
            assert statement.locator('code.language-lean').first.is_visible()
            statement.locator('summary').first.scroll_into_view_if_needed()
            no_page_overflow(page)
            screenshot(page, f'actual-{width}-exact-statement')
            statement.locator('summary').first.click()
            proof.locator('summary').first.click()
            proof.locator('summary').first.scroll_into_view_if_needed()
            assert proof.locator('code.language-lean').first.is_visible()
            local_scroll = proof.locator('pre').first.evaluate('node => { const max=node.scrollWidth-node.clientWidth; node.scrollLeft=max; const actual=node.scrollLeft; node.scrollLeft=0; return {clientWidth:node.clientWidth,scrollWidth:node.scrollWidth,max,actual}; }')
            if local_scroll['max'] > 1:
                assert local_scroll['actual'] > 0
            no_page_overflow(page)
            screenshot(page, f'actual-{width}-exact-proof')
            module_href = proof.locator('a').filter(has_text='Exact module and namespace context').get_attribute('href')
            module_url = urljoin(page.url, module_href)
            download = proof.locator('a[download]').first.get_attribute('href')
            actual_source = (ROOT / declarations[NAME].source_file).read_bytes()
            response = context.request.get(urljoin(page.url, download))
            assert response.status == 200 and response.body() == actual_source
            assert subprocess.check_output(['git', 'show', HEAD + ':' + str(declarations[NAME].source_file)]) == actual_source
            immutable_link = None
            if urlsplit(module_url).netloc == 'github.com':
                expected = metadata['git']['web_root'] + '/blob/' + HEAD + '/' + str(declarations[NAME].source_file)
                assert module_url.startswith(expected + '#L')
                immutable_link = module_url
                module_url = base + 'modules/' + inline_lean.base.slugify(declarations[NAME].module) + '.html#complete-module-source'
            assert page.goto(module_url, wait_until='domcontentloaded').status == 200
            page.locator('#complete-module-source > details > summary').click()
            assert page.locator('#complete-module-source pre > code').text_content().encode() == actual_source
            page.locator('#complete-module-source').scroll_into_view_if_needed()
            no_page_overflow(page)
            screenshot(page, f'actual-{width}-module')
            report['pages'].append({'target': NAME, 'route': route, 'width': width, 'closed_initially': True, 'five_formula_steps_opened': True, 'adjacent_exact_statement_and_proof': True, 'local_code_scroll': local_scroll, 'full_module_download_immutable_git_bytes_verified': True, 'immutable_link_syntax_checked': immutable_link, 'producer_ASTIS_parents': [CANONICAL_PARENT], 'consumer_ASTIS_parents': CONSUMER_ASTIS_PARENTS, 'consumer_private_name_only': True, 'consumer_canonical_Gaussian_is_separate': True, 'module_link_branch': 'GitHub commit/path syntax plus local own-site module' if immutable_link else 'own-site module only; GitHub syntax branch not executed', 'external_GitHub_HTML_checked': False, 'fullpage_overflow': False, 'screenshot_scope': 'Viewport captures only; long code/assumptions require local scrolling and are not claimed fully visible in one image.'})

            chapter = 'example-cases/samplewiki/companions/gaussian-sampling-complexity.html'
            assert page.goto(base + chapter, wait_until='domcontentloaded').status == 200
            math_ready(page)
            main = page.locator('#gaussian-complexity-eigenbasis')
            main.evaluate('(node) => { for (let p=node.parentElement;p;p=p.parentElement) if(p.matches("details"))p.open=true; }')
            boundary = main.text_content()
            for phrase in ('The full Theorem 4.1 lower bound remains open', 'Lemma4.6 precursor', 'every full real', 'Euclidean Lebesgue volume', 'real exponent', 'not another producer proof parent', 'actual source determinant product', 'canonical DisplacementJacobianEntropy', 'independent of orientation', 'retains the actual hidden', 'full unweighted Gaussian integral/known-normalizer proposition', 'C4 calculus/minimizer', 'Section 4.4 limits this uniform-Krylov/test analysis', 'not an impossibility theorem for stronger fixed-spectrum lower bounds'):
                assert phrase in boundary, phrase
            determinant_text = page.locator('#gaussian-complexity-determinant').text_content()
            for phrase in ('The full Theorem 3.1 lower bound remains open', 'worst-case deterministic query cap', 'not an expected-cost lower bound without a separate reduction', 'Actual amplified TV Ex72', 'actual pointwise first-order reconstruction'):
                assert phrase in determinant_text, phrase
            no_page_overflow(page)
            main.scroll_into_view_if_needed()
            screenshot(page, f'case-boundary-{width}')
            index = page.locator('#paper-lean-progress')
            index.scroll_into_view_if_needed()
            screenshot(page, f'source-index-{width}')
            outer = index.locator('details.paper-verified-index')
            if outer.get_attribute('open') is None:
                outer.locator(':scope > summary').click()
            sourceunit = outer.locator(f'details.paper-verified-unit[data-publication-item="{ITEM}"]')
            if sourceunit.get_attribute('open') is None:
                sourceunit.locator(':scope > summary').click()
            link = sourceunit.locator(f'a[href$="source-{ITEM}.html"]')
            assert link.count() == 1 and link.is_visible()
            sourceunit.scroll_into_view_if_needed()
            screenshot(page, f'actual-{width}-source-index-open')
            assert context.request.get(urljoin(page.url, link.get_attribute('href'))).status == 200
            link.click()
            page.wait_for_url('**/proofs/source-' + ITEM + '.html')
            math_ready(page)
            assert page.locator(f'article[data-authored-declaration="{NAME}"]').count() == 1
            report['visible_source_index_clicks'].append({'target': NAME, 'width': width, 'actual_click': True})
            no_page_overflow(page)

            focus = focused_entry(page, own_id, NAME)
            assert page.locator(f'.ulg-node[data-id="{own_id}"]').count() == 1
            assert page.locator(f'.ulg-node[data-id="{module_id}"]').count() == 1
            assert page.locator('.ulg-edge[data-relation="source reference (scanner)"][data-evidence="formal"]').count() == 0
            assert page.locator('.ulg-edge[data-relation="source correspondence; not a Lean dependency"][data-evidence="formal"]').count() == 0
            screenshot(page, f'actual-{width}-graph-focused')
            parent_neighbor = page.locator(f'[data-graph-detail] button[data-jump="{parent_id}"]')
            assert parent_neighbor.count() == 1
            parent_neighbor.click()
            page.wait_for_selector(f'.ulg-node.selected[data-id="{parent_id}"]')
            assert page.locator('[data-graph-detail]').get_attribute('data-kind') == 'declaration'
            page.locator('[data-graph-canvas]').scroll_into_view_if_needed()
            no_page_overflow(page)
            screenshot(page, f'canonical-DJE-{width}-graph-native-parent-click')
            focused_entry(page, own_id, NAME)
            neighbor = page.locator(f'[data-graph-detail] button[data-jump="{module_id}"]')
            assert neighbor.count() == 1
            neighbor.click()
            page.wait_for_selector(f'.ulg-node.selected[data-id="{module_id}"]')
            assert page.locator('[data-graph-detail]').get_attribute('data-kind') == 'module'
            page.locator('[data-graph-canvas]').scroll_into_view_if_needed()
            no_page_overflow(page)
            screenshot(page, f'actual-{width}-graph-module-native-click')
            gaussian_focus = focused_entry(page, canonical_id, CANONICAL_GAUSSIAN)
            screenshot(page, f'canonical-Gaussian-{width}-graph-focused')
            report['graphs'].append({'target': own_id, 'width': width, 'one_canonical_producer': True, 'producer_ASTIS_parents': [CANONICAL_PARENT], 'native_canonical_DJE_parent_click': True, 'source_scanner_edge_not_kernel_evidence': True, 'owner_module': module_id, 'focused_entry': focus, 'native_neighbor_module_click': True, 'canonical_Gaussian_existing_single_node': canonical_id, 'canonical_Gaussian_focus': gaussian_focus, 'semantic_boundary': 'DJE is the ONE separately kernel-confirmed canonical producer parent. Its graph source-name edge remains dashed, not formal kernel proof evidence. Actual GaussianPrecisionDensity and admissibility reuse belongs to the three-parent private Test consumer. Structural imports/declares are not theorem implication; no duplicate determinant, density or conceptual transport is created.'})

            bridge_focus = focused_entry(page, bridge, 'Quadratic observations factor', 'functor')
            assert module_id not in nodes[bridge]['candidate_substrates']
            assert page.locator(f'.ulg-node[data-id="{module_id}"]').count() == 0
            detail = page.locator('[data-graph-detail]')
            page.wait_for_function("document.querySelector('[data-graph-detail]').dataset.kind === 'concept-bridge'")
            actual_rows = detail.locator('.ulg-details > div').evaluate_all('(nodes)=>Object.fromEntries(nodes.map(n=>[n.querySelector("dt").textContent,n.querySelector("dd").textContent]))')
            for label, field in [('Mechanism','mechanism'),('Hypothesis Map','hypothesis_map'),('Conclusion Map','conclusion_map'),('Failure Boundary','failure_boundary')]:
                assert actual_rows[label] == edge[field]
            assert 'not-Lean-certified' in detail.locator('.ulg-warning').text_content()
            assert detail.locator(f'button[data-jump="{module_id}"]').count() == 0
            no_page_overflow(page)
            page.locator('[data-graph-canvas]').scroll_into_view_if_needed()
            screenshot(page, f'existing-conceptual-{width}-unchanged')
            report['graphs'].append({'target': bridge, 'width': width, 'focused_entry': bridge_focus, 'exact_model_and_memory_unchanged': True, 'no_new_determinant_candidate_or_formal_transport': True, 'formal_refs': [], 'actual_semantic_rows_equal_preserved_model': True})
        assert not report['errors'], report['errors']
        assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == HEAD
        for path, digest in PINS.items():
            assert sha((ROOT / path).read_bytes()) == digest
        browser.close()
        report['status'] = 'passed'
except Exception as error:
    report['status'] = 'failed'
    report['failure'] = repr(error)
    raise
finally:
    server.shutdown()
    server.server_close()
    (OUT / 'report.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'status': report.get('status'), 'pages': len(report['pages']), 'graphs': len(report['graphs']), 'screenshots': len(report['screenshots']), 'report': str(OUT / 'report.json')}))
