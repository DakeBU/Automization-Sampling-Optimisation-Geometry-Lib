import copy
import gzip
import hashlib
import json
import subprocess
import sys
from pathlib import Path

ROOT=Path('/Users/zhouhuanjian/ASTIS-GC')
sys.path.insert(0,str(ROOT))
from tools import astis_advance as advance
from tools import astis_publication as publication
from tools import astis_semantic_roundtrip as semantic

BASE=ROOT/'research-wiki/paper-contributions/GaussianComplexity/affinity-tensorization-semantic-evidence/fresh-source-module-review'
AUDIT=ROOT/'research-wiki/semantic-roundtrip/audits/huanjian-affinity-tensorization.json'
TARGET='ASTIS-SA-20261107-GaussianComplexityAffinityTensorization'
CANDIDATE='4014feb9c6dff0b4e0dcb9fb49ae1b961cf3cf0b'

def sha(b):return hashlib.sha256(b).hexdigest()
def canon(v):return json.dumps(v,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()
def put(name,v):(BASE/name).write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')

def main():
    paths=['AutoSamplingTheory/ExampleCases/GaussianComplexity/AffinityTensorization.lean',
           'Tests/GaussianComplexityAffinityTensorization.lean',
           'website/content/declaration_lessons/huanjian-affinity-tensorization.json',
           'website/content/publications/huanjian-affinity-tensorization.json']
    source_inputs=[]
    for s in paths:
        b=(ROOT/s).read_bytes();obj=subprocess.check_output(['git','show',CANDIDATE+':'+s],cwd=ROOT)
        assert b==obj,s
        source_inputs.append({'path':s,'sha256':sha(b),'matches_candidate_gitobject':True})
    result_path=BASE/'source-review-result-v2.json';result=json.loads(result_path.read_bytes())
    assert sha(result_path.read_bytes())=='576e909310814ead40b453340d9ea709a990bde8daf0e93097c0ff6fd024544a'
    assert sha((BASE/'review-run-v2.json').read_bytes())==result['review_run_sha256']=='0b79a4d39ab94e801c977aa8fb29fb695bd121ca9023f64724b69ca17d74b8bc'
    assert sha((BASE/'source-review-result-v1.json').read_bytes())=='471933a4406724e150e30985c61013474c73c5fa2def4c7155d812c53cd5a5be'
    assert sha((BASE/'review-run-v1.json').read_bytes())=='4321b10ee8422102f6400b946c96022e361d87b9cf094cd0974f3d6330af6cbc'
    packet_path=ROOT/'research-wiki/paper-contributions/GaussianComplexity/affinity-tensorization-semantic-evidence/fresh-reviewer-packet.json'
    packet=json.loads(packet_path.read_bytes())
    assert sha(packet_path.read_bytes())=='1667083a35060d3432439711b3c68fa6d66352b3a82504c4594fb968977e2f38'
    before=AUDIT.read_bytes();audit=json.loads(before)
    assert audit['state']=='blind-reconstructed'
    assert sha(before)=='804e776f3b48dd27bb2e6c63b35970ebdb33628f48e24fc2d12d41c7423063ca'
    assert semantic.semantic_reviewer_packet(audit)['packet_sha256']==packet['packet_sha256']==result['reviewer_packet_sha256']
    assert audit['source']['original_text']==packet['source']['original_text']
    assert audit['reconstruction']['text']==packet['blind_reconstruction']['text']
    assert audit['publication_context']==packet['candidate_publication_context']
    item=next(x for x in publication.load() if x['id']=='huanjian-affinity-tensorization')
    binding=publication.binding_digest(item,item['bindings'][0])
    assert binding==audit['publication_binding_sha256']==result['publication_binding_sha256']=='9104d934f897b788965a51b8681eb96cf568a43d3a7b7dc5ed743ffe0469533d'
    ledger_path=ROOT/'runs/substantive_advances.jsonl';ledger=ledger_path.read_bytes()
    original=gzip.decompress((BASE/'ledger-prefix-before-projection.jsonl.gz').read_bytes())
    assert ledger==original,'Ledger changed since first preservation freeze'
    state=advance._replay_advances(json.loads(x) for x in ledger.splitlines())
    foreign={k:v for k,v in state.items() if k!=TARGET}
    assert canon(foreign)==gzip.decompress((BASE/'foreign-states-before-projection.json.gz').read_bytes())
    assert len(foreign)==277 and state[TARGET]['state']=='PROVED_LOCAL'
    assert state[TARGET]['owner_id']=='huanjian_gc_20261107_ex71'
    assert not [x for x in state.values() if x['state']=='STABILIZING']
    old_pre=json.loads((BASE/'projection-preflight-v1.json').read_text())
    for s,h in old_pre['frontier_bytes'].items():assert sha((ROOT/s).read_bytes())==h,s
    put('canonical-projection-preflight-v2.json',{
        'candidate_commit':CANDIDATE,'metadata_head_at_projection':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
        'code_test_lesson_publication':source_inputs,'packet_raw_sha256':sha(packet_path.read_bytes()),
        'packet_canonical_sha256':packet['packet_sha256'],'publication_binding_sha256':binding,
        'canonical_audit_before_sha256':sha(before),'source_text_sha256':audit['source']['text_sha256'],
        'reconstruction_text_sha256':audit['reconstruction']['text_sha256'],
        'target_state_before':'PROVED_LOCAL','owner_before':state[TARGET]['owner_id'],
        'foreign_count':len(foreign),'foreign_states_sha256':sha(canon(foreign)),
        'ledger_prefix_bytes':len(ledger),'ledger_prefix_sha256':sha(ledger),
        'all_437_frontier_bytes_match_first_freeze':True,'old_frontiers_count':436,'single_stabilization_lane':[],
        'compiler_scope':'Prior real direct-source receipts have no head_before field. Their exact source hashes match candidate Gitobjects; imported oleans were reused. Metadata HEAD here is not asserted as compilation HEAD.'})
    projected=copy.deepcopy(audit);projected['state']='source-reviewed'
    for key in ['semantic_slots','deltas','verdict','repairs']:projected[key]=copy.deepcopy(result[key])
    projected['source_review']={
        'state':'accepted','reviewer':result['reviewer'],'independent_from_formalizer':True,'independent_from_decoder':True,
        'reviewer_packet_sha256':result['reviewer_packet_sha256'],'review_run_sha256':result['review_run_sha256'],
        'evidence':result['review_evidence'],'run_artifact':str(result_path.relative_to(ROOT)),
        'projection_note':'Mechanical projection of the frozen independent v2 result only, following explicit coordinator acceptance. The v1 result, real failed in-memory validation and source-based classification correction are preserved. No source/Lean/reconstruction/context/binding bytes or meaning are replaced.'}
    for key in ['source','lean','reconstruction','publication_context','publication_binding_sha256']:
        assert projected[key]==audit[key],key
    assert semantic.semantic_reviewer_packet(projected)['packet_sha256']==packet['packet_sha256']
    after=(json.dumps(projected,indent=2,ensure_ascii=False)+'\n').encode()
    (BASE/'canonical-audit-projected-v2.json.gz').write_bytes(gzip.compress(after,mtime=0))
    AUDIT.write_bytes(after)
    assert AUDIT.read_bytes()==after
    report={'artifact_kind':'canonical-audit-v2-mechanical-projection','before_state':'blind-reconstructed','after_state':'source-reviewed',
        'before_sha256':sha(before),'after_sha256':sha(after),'changed_top_level_fields':[k for k in projected if projected[k]!=audit[k]],
        'preserved_semantic_inputs':['source','lean','reconstruction','publication_context','publication_binding_sha256'],
        'result_path':str(result_path.relative_to(ROOT)),'result_sha256':sha(result_path.read_bytes()),'review_run_sha256':result['review_run_sha256'],
        'packet_sha256':packet['packet_sha256'],'publication_binding_sha256':binding,
        'v1_failure_receipt_sha256':sha((BASE/'projection-semantic-preflight-v1.receipt.json').read_bytes()),
        'classification_correction_sha256':sha((BASE/'conclusion-classification-correction-v2.md').read_bytes()),
        'ledger_unchanged':ledger_path.read_bytes()==ledger,'api_called':False,'only_already_frozen_independent_verdict_projected':True}
    put('canonical-audit-projection-v2.json',report)
    print(json.dumps(report,indent=2))

if __name__=='__main__':main()
