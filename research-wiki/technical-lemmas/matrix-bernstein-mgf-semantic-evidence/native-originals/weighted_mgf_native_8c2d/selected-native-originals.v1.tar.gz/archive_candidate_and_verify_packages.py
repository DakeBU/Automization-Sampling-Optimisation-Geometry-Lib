#!/usr/bin/env python3
"""Archive immutable Git source closure and independently hash read-only packages."""
from concurrent.futures import ThreadPoolExecutor
import datetime as dt
import hashlib
import json
import pathlib
import re
import subprocess
import time

OWN = pathlib.Path(__file__).resolve().parent
REPO = OWN.parents[2]
R13 = OWN.parent / 'bernstein_exp_native_72c4'
CANDIDATE = '4869db55d340cee39f0ba4d49fb0a7a4309ba2d6'
CAND = OWN / 'candidate-4869db55'
P = 'AutoSamplingTheory.TechnicalLemmas.Probability.MatrixBernsteinMgf'
T = 'Tests.GaussianComplexityBernsteinWeightedMgf'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def file_sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        while block := stream.read(1024 * 1024):
            h.update(block)
    return h.hexdigest()

def git(*args):
    return subprocess.check_output(['git', '--no-optional-locks', *args], cwd=REPO)

def write_json(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')

def main():
    assert not (OWN / 'native-command-assignment.json').exists()
    assert not any((OWN / 'native-output').iterdir())
    CAND.mkdir(exist_ok=True)
    tree = {}
    for raw in git('ls-tree', '-r', '-z', CANDIDATE).split(b'\0'):
        if raw:
            meta, path = raw.split(b'\t', 1)
            mode, kind, oid = meta.decode().split()
            tree[path.decode()] = (mode, kind, oid)
    project = {path[:-5].replace('/', '.'): path for path in tree if path.endswith('.lean') and path.startswith(('AutoSamplingTheory/', 'Tests/'))}
    source = {}
    imports = {}
    order = []
    visiting = set()
    def visit(module):
        if module in order:
            return
        if module in visiting:
            raise ValueError('Actual project import cycle')
        visiting.add(module)
        path = project[module]
        raw = git('cat-file', 'blob', tree[path][2])
        source[module] = raw
        declared = []
        for line in raw.decode().splitlines():
            match = re.match(r'^\s*(?:public\s+)?import\s+([^\n]+)', line)
            if match:
                declared.extend(match.group(1).split('--', 1)[0].split())
        imports[module] = declared
        for dependency in declared:
            if dependency in project:
                visit(dependency)
        visiting.remove(module)
        order.append(module)
    visit(P)
    visit(T)
    manifest = []
    for module in order:
        relative = project[module]
        dest = CAND / relative
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(source[module])
        manifest.append({'module': module, 'path': relative, 'git_oid': tree[relative][2], 'mode': tree[relative][0], 'bytes': len(source[module]), 'sha256': sha(source[module]), 'imports': imports[module], 'actual_project_imports': [x for x in imports[module] if x in project]})
    expected = {P: 'b46bb5a3eabbcadf31fee93d48c1fbabf9b5b42cf717a8a17c8c8cfdd210a3f3', T: '42f372143ffe52e4372271d09fbc6b67391739f2fe2a5fbfffe6cd9fa586936e'}
    for module, digest in expected.items():
        assert sha(source[module]) == digest
    for relative in ['lean-toolchain', 'lake-manifest.json', 'lakefile.lean', 'lakefile.toml', 'AGENTS.md', 'docs/contributor-codex-contract.md', 'docs/theorem-publication-protocol.md', 'docs/proof-digestion-protocol.md', 'docs/evidence-routed-memory-protocol.md']:
        if relative in tree:
            dest = CAND / relative
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(git('cat-file', 'blob', tree[relative][2]))
    inputs = OWN / 'immutable-inputs'
    inputs.mkdir(exist_ok=True)
    admission_source = OWN.parent / 'weighted_mgf_topology_challenge_63ad/preproof-admission.v2.json'
    admission = admission_source.read_bytes()
    assert sha(admission) == 'e85c6ef8066b693c63770cafabc42affc510c1b055f336cb168b7a488da4b55c'
    assert json.loads(admission)['decision'] == 'ADMITTED'
    (inputs / 'preproof-admission.v2.json').write_bytes(admission)
    seal = (OWN / 'preparation-originals/statement-seal.sealed.v1.json').read_bytes()
    (inputs / 'statement-seal.sealed.v1.json').write_bytes(seal)
    closure = {'schema': 'immutable-git-actual-project-import-closure-v1', 'candidate_commit': CANDIDATE, 'observed_repository_HEAD_at_archive': git('rev-parse', 'HEAD').decode().strip(), 'source_tree': git('rev-parse', CANDIDATE + '^{tree}').decode().strip(), 'P': P, 'T': T, 'module_count_derived_not_assumed': len(order), 'topological_order': order, 'modules': manifest, 'whole_P_T_and_complete_actual_ASTIS_import_source_archived': True, 'root_ASTIS_artifacts_copied': False, 'parent_edges_not_inferred_from_imports': True}
    write_json(OWN / 'actual-import-closure.json', closure)
    print(json.dumps({'immutable_closure_archived': True, 'module_count': len(order), 'P_sha256': expected[P], 'T_sha256': expected[T]}), flush=True)
    package_manifest = json.loads((CAND / 'lake-manifest.json').read_text())['packages']
    artifact_seal_path = R13 / 'package-artifact-digests.json'
    artifact_seal_bytes = artifact_seal_path.read_bytes()
    prep_report = json.loads((OWN / 'environment-preparation-report.json').read_text())
    expected_artifact_seal = next(row['sha256'] for row in prep_report['read_only_R13_infrastructure_references'] if row['path'] == str(artifact_seal_path))
    assert sha(artifact_seal_bytes) == expected_artifact_seal
    artifact_packages = {row['package']: row for row in json.loads(artifact_seal_bytes)['packages']}
    start = time.monotonic()
    results = []
    for package in package_manifest:
        name = package['name']
        source_root = REPO / '.lake/packages' / name
        actual_revision = git('-C', str(source_root), 'rev-parse', 'HEAD').decode().strip()
        status = git('-C', str(source_root), '-c', 'core.fsmonitor=false', 'status', '--porcelain', '--untracked-files=no')
        assert actual_revision == package['rev'] and not status
        artifact_root = R13 / 'clean-packages' / name / '.lake/build/lib/lean'
        frozen = artifact_packages[name]
        expected_files = {row['path'] for row in frozen['files']}
        actual_files = {str(path.relative_to(artifact_root)) for path in artifact_root.rglob('*') if path.is_file()}
        assert actual_files == expected_files, ('Package artifact membership changed', name)
        def verify(row):
            path = artifact_root / row['path']
            before = path.stat()
            actual_hash = file_sha(path)
            after = path.stat()
            assert before.st_size == after.st_size == row['bytes'] and before.st_mtime_ns == after.st_mtime_ns
            assert actual_hash == row['sha256'], ('Package artifact bytes changed', name, row['path'])
            return row['bytes']
        with ThreadPoolExecutor(max_workers=8) as pool:
            verified_bytes = sum(pool.map(verify, frozen['files']))
        result = {'name': name, 'expected_revision': package['rev'], 'actual_revision': actual_revision, 'tracked_source_clean': True, 'revision_and_source_artifact_bytes_verified': True, 'effective_lean_path': str(artifact_root), 'verified_artifact_file_count': len(expected_files), 'verified_artifact_bytes': verified_bytes, 'artifact_membership_exact': True, 'readonly_reuse_only': True, 'copied': False}
        results.append(result)
        print(json.dumps({'package_verified': name, 'files': len(expected_files), 'bytes': verified_bytes, 'elapsed_seconds': time.monotonic() - start}), flush=True)
    report = {'schema': 'independent-readonly-package-byte-verification-v1', 'status': 'READONLY_PACKAGE_BYTES_VERIFIED_FOR_THIS_ASSIGNMENT', 'candidate_commit': CANDIDATE, 'utc': dt.datetime.now(dt.timezone.utc).isoformat(), 'elapsed_seconds': time.monotonic() - start, 'packages': results, 'reference_artifact_seal_path': str(artifact_seal_path), 'reference_artifact_seal_sha256': sha(artifact_seal_bytes), 'reference_artifact_seal_copied': False, 'all_actual_artifact_bytes_independently_rehashed_now': True, 'all_source_revisions_exact_and_tracked_clean': True, 'artifact_file_count': sum(row['verified_artifact_file_count'] for row in results), 'artifact_bytes': sum(row['verified_artifact_bytes'] for row in results), 'ASTIS_root_or_old_R13_output_reused': False, 'package_bytes_copied': 0}
    write_json(OWN / 'verified-package-inputs.json', report)
    print(json.dumps({'package_verification_complete': True, 'files': report['artifact_file_count'], 'bytes': report['artifact_bytes']}), flush=True)

if __name__ == '__main__':
    main()
