from pathlib import Path
import hashlib,json,sys
sys.dont_write_bytecode=True
sys.path.insert(0,'tools');import astis_semantic_roundtrip as rt
sha=lambda b:hashlib.sha256(b).hexdigest()
dump=lambda x:(json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode()
D=Path('.astis/semantic-neutral-20261109/b4e6a1')
E=Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-cosine-expansion-semantic-evidence')
assert sha((D/'hash-manifest.json').read_bytes())=='b5f18cf1ed44b701bd92140e1890d5e0b8fb8526592d71b38b89c18a00111b20'
recon=json.loads((D/'reconstruction.json').read_bytes());run=json.loads((D/'decoder-run.json').read_bytes())
assert sha((D/'input.json').read_bytes())==run['raw_input_sha256']=='90413ac0e00642f4e2f6e4ff3e46932ecb5cd7eae8db8e51a5b4a73fc8408e30'
assert sha((D/'decoder-run.json').read_bytes())==recon['decoder_run_sha256']=='3925b7d2dcac313dbb86fa3277ffb337fa4bf95344f4eb64035fba0429d9de4c'
text=(D/'reconstructed-theorem.md').read_text()
assert text==recon['reconstructed_theorem_text'] and sha(text.encode())==recon['reconstructed_text_sha256']
assert run['source_text_visible'] is False and recon['source_text_visible'] is False
ap=Path('research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-cosine-expansion.json')
old=ap.read_bytes();a=json.loads(old);assert a['state']=='draft' and a['reconstruction']=={}
packet=rt.decoder_packet(a);assert packet['packet_sha256']==run['packet_sha256']
a['state']='blind-reconstructed'
a['reconstruction']={'text':text,'text_sha256':recon['reconstructed_text_sha256'],'decoder':'/root/decode_b4e6a1',
 'source_text_visible':False,'lean_statement_sha256':a['lean']['statement_sha256'],
 'decoder_packet_sha256':packet['packet_sha256'],'decoder_run_sha256':sha((D/'decoder-run.json').read_bytes()),
 'input_artifacts':packet['input_artifacts'],'ambient_cues_disclosed':run['ambient_topic_tool_path_cues'],
 'zero_ambient_cues_claimed':False}
assert a['semantic_slots']=={} and a['source_review']=={'state':'pending'} and a['verdict']=='pending'
dest=E/'independent-decoder-b4e6a1';assert not dest.exists();dest.mkdir()
for q in D.iterdir():
    if q.is_file():(dest/q.name).write_bytes(q.read_bytes())
(E/'audit-before-independent-reconstruction.raw.json').write_bytes(old)
ap.write_bytes(dump(a))
review=rt.semantic_reviewer_packet(a)
assert all(v is False for v in review['anti_anchoring'].values())
(E/'fresh-source-reviewer-packet.json').write_bytes(dump(review))
base=Path('.astis/semantic-neutral-20261109/src_cosine_27c4e1/phase2-inputs');assert not base.exists();base.mkdir()
(base/'reviewer-packet.json').write_bytes(dump(review))
(base/'approved-standard-context.txt').write_text('\n\n'.join(a['lean']['decoder_context'])+'\n')
s=json.loads(Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-cosine-expansion-statement-seal.json').read_bytes())
head,body=s['actual_private_consumer']['signature'].split(' :\n',1)
anonymous='∀'+head.removeprefix('private theorem actual_inverse_grid_cosine_series')+',\n'+body
(base/'private-consumer-anonymous.txt').write_text(anonymous)
(base/'decoder-run.raw.json').write_bytes((D/'decoder-run.json').read_bytes())
manifest={'scope':'Selective phase2 source/statement/reconstruction comparison only. No implementation/proof/lessons/prior source verdict/repair or proof graph included.',
 'reviewer_packet_sha256':review['packet_sha256'],'source_phase1_frozen_manifest_sha256':'14b9a615c0031e7d405328df7ac2f4a1cc918d42faad5e4186e3a51e43a1ffea',
 'files':[{'path':q.name,'sha256':sha(q.read_bytes()),'bytes':q.stat().st_size} for q in sorted(base.iterdir()) if q.is_file()]}
(base/'manifest.json').write_bytes(dump(manifest))
print(json.dumps({'state':'blind-reconstructed','reviewer_packet_canonical_sha256':review['packet_sha256'],
 'phase2_input_manifest_sha256':sha((base/'manifest.json').read_bytes()),'source_verdict_or_actual_use_credit':False}))
