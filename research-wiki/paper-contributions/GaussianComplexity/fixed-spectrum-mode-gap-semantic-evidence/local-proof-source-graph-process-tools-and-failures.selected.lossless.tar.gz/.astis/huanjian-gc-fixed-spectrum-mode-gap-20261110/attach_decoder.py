from pathlib import Path
import json,hashlib,sys
sys.dont_write_bytecode=True;sys.path.insert(0,'tools')
import astis_semantic_roundtrip as rt
W=Path('.astis/huanjian-gc-fixed-spectrum-mode-gap-20261110');E=Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-mode-gap-semantic-evidence');D=Path('.astis/semantic-neutral-20261110/d1af09')
sha=lambda b:hashlib.sha256(b).hexdigest();dump=lambda x:(json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode()
def put(p,b):
    assert not p.exists(),p;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
assert sha((D/'frozen-manifest.json').read_bytes())=='48be8b021dddce4ad3e2952f4b948b7a4ceee982c089c4c5e9b03b5f4cb1d982'
f=json.loads((D/'frozen-manifest.json').read_bytes())
for row in f['artifacts']:
    p=Path(row['path']);assert p.resolve().is_relative_to(D.resolve()) and sha(p.read_bytes())==row['sha256']
r=json.loads((D/'decoder-run.json').read_bytes());rb=r['input_bindings']
assert r['decoder']['actor_identity']=='/root/decoder_d1af09' and r['source_text_visible'] is False
assert sha((D/'decoder-run.json').read_bytes())=='f96440134c9297ed5efa5349dfc67354616c317ef4ad6da4c9c250d3f7537cc7'
rec=json.loads((D/'reconstruction.json').read_bytes());text=r['reconstructed_theorem_text']
assert sha(text.encode())==r['reconstructed_text_sha256']=='9b355aef5a10ae381f4890153e5eb4d3b5c85ad22380bd473d7b06c321dfb532'
p=Path('research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-mode-gap.json');old=p.read_bytes();a=json.loads(old)
assert a['state']=='draft' and a['reconstruction']=={}
packet=rt.decoder_packet(a)
assert packet['packet_sha256']==rb['canonical_packet_sha256'] and sha((D/'input.json').read_bytes())==rb['raw_input_sha256']
a['state']='blind-reconstructed'
a['reconstruction']={'text':text,'text_sha256':sha(text.encode()),'decoder':r['decoder']['actor_identity'],'source_text_visible':False,'lean_statement_sha256':a['lean']['statement_sha256'],'decoder_packet_sha256':packet['packet_sha256'],'decoder_run_sha256':sha((D/'decoder-run.json').read_bytes()),'input_artifacts':packet['input_artifacts'],'ambient_cues_disclosed':r['actual_ambient_exposure'],'zero_ambient_cues_claimed':False}
for x in sorted(D.iterdir()):
    if x.is_file():put(E/'independent-decoder-d1af09'/x.name,x.read_bytes())
put(E/'audit-before-independent-reconstruction.raw.json',old);p.write_bytes(dump(a))
full=rt.semantic_reviewer_packet(a);assert all(x is False for x in full['anti_anchoring'].values())
put(E/'fresh-source-reviewer-packet.json',dump(full))
s=json.loads((W/'statement-seal-v2.json').read_bytes());head,body=s['actual_private_consumer']['signature'].split(' :\n',1)
consumer='∀'+head.removeprefix('private theorem actual_gaussian_source_query_bias_power_lower')+',\n'+body
white={'schema_version':1,'task':'selective-source-statement-reconstruction-comparison','parent_canonical_packet_sha256':full['packet_sha256'],'source':{k:full['source'][k] for k in ['source_id','anchor','original_text','text_sha256']},'lean_statement':{k:full['lean'][k] for k in ['statement','statement_sha256']},'approved_definition_context':a['lean']['decoder_context'],'blind_reconstruction':{k:full['blind_reconstruction'][k] for k in ['text','text_sha256','decoder','decoder_packet_sha256','decoder_run_sha256','source_text_visible']},'private_consumer_statement':consumer,'private_standard_definition_context':['Fin d is the usual finite coordinate type; EuclideanSpace Real (Fin d) has the standard Euclidean norm, and WithLp.ofLp exposes coordinates.','ProbabilityTheory.multivariateGaussian m S is the image of standard Gaussian by x↦m+toEuclideanCLM(CFC.sqrt S)x. On the positive semidefinite domain S is covariance; outside that domain the standard totalized square root is zero. The matrix Lambda displayed in the statement is precision and its inverse is passed as covariance.','The real and matrix inverses, Bochner integral and real division have their standard totalized meanings. M and b are the displayed actual integrals against the same literal Gaussian, not free expectation parameters.']}
assert b' := by' not in dump(white)
put(W/'strict-selective-phase2-input.json',dump(white));put(E/'strict-selective-phase2-input.json',dump(white))
print(json.dumps({'state':'blind-reconstructed','full_reviewer_packet_canonical_sha256':full['packet_sha256'],'strict_whitelist_raw_sha256':sha(dump(white)),'source_review_or_sourceV':False}))
