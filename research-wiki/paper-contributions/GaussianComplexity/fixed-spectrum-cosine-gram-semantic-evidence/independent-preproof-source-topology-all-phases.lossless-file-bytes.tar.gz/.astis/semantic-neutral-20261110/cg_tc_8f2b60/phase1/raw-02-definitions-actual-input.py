from pathlib import Path
from bs4 import BeautifulSoup
import json
base=Path('.astis/semantic-neutral-20261110/cg_tc_8f2b60/phase1')
s=BeautifulSoup(Path('.astis/huanjian-resume-20261103/2610.20492v1.html').read_bytes(),'html.parser')
outs=[]
for key in ['S4','S4.SS1','S4.SS2.SSS0.Px1','S4.SS2.SSS0.Px2']:
 t=s.find(id=key)
 outs.append('ANCHOR '+key)
 if key=='S4':
  use=[c for c in t.find_all(recursive=False) if c.name!='section']
 elif key=='S4.SS2.SSS0.Px2':
  use=[c for c in t.find_all(recursive=False) if c.get('id')!='S4.Thmtheorem4']
 else:use=[t]
 for tag in use:
  c=BeautifulSoup(str(tag),'html.parser')
  for m in c.find_all('math'):m.replace_with(' $'+m.get('alttext','')+'$ ')
  outs.append(c.get_text(' ',strip=True))
outs.append('C.2 full proof structure inventory')
for c in s.find(id='A3.SS2').find_all(recursive=False):
 if c.name=='h3':continue
 outs.append(json.dumps({'id':c.get('id'),'class':c.get('class'),'children':[(a.name,a.get('id'),a.get('class')) for a in c.find_all(recursive=False)]},ensure_ascii=False))
out='\n\n'.join(outs)+'\n';(base/'raw-02-definitions-output.txt').write_text(out);print(out)
