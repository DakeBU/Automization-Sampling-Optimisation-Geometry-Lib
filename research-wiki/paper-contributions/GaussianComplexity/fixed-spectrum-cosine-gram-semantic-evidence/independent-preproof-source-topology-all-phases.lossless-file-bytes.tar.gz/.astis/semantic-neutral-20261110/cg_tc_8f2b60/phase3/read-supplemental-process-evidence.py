from pathlib import Path
import hashlib
import json
import gzip

base=Path(__file__).resolve().parent
E=Path('/Users/zhouhuanjian/ASTIS-GC/research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-cosine-gram-semantic-evidence')
specs=[
 ('20261110T143958682117Z-cosine-gram-preproof-frontier-explicit-prior-libraries.receipt.json','e65e67b2820baad2d2298b37154a4691b57fe6649798eb6c49d66e138b6c923a',None),
 ('20261110T143958682117Z-cosine-gram-preproof-frontier-explicit-prior-libraries.log.gz','9a480ab5a6a2d141177489c4b729aae2b628b3255fcef3405374e15bba87a860','8d399c9a21cb5fcb948fef41f1286aa63635a2ed87e5f3ba4d193a71b2488b42'),
 ('20261110T144250664877Z-cosine-gram-prepare-exact-control-baseline-no-API.receipt.json','88cc88cd2207c7c34394a179e8ce2457bc882b9030c83a31ca4f64312ae16364',None),
 ('20261110T144250664877Z-cosine-gram-prepare-exact-control-baseline-no-API.log.gz','8a15b0adc0d7d15456d3e18c90addb50d003685352de583b9a2363ddd6cf3fc7','7ad13ccac2c2d6e6133ddbe5bd8ca01dbbc785214649a3b262601d2f09c3de48')
]
rows=[];out=[]
for name,digest,rawdigest in specs:
    p=E/name;b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==digest,name
    (base/'E'/name).write_bytes(b)
    content=gzip.decompress(b) if rawdigest else b
    if rawdigest:
        assert hashlib.sha256(content).hexdigest()==rawdigest,name
        (base/'E'/(name+'.decoded.txt')).write_bytes(content)
    rows.append({'path':str(p),'relative_E_path':name,'bytes':len(b),'raw_sha256':digest,'decoded_sha256':rawdigest})
    out.append('SUPPLEMENT INPUT '+name+' rawSHA256 '+digest+'\n'+content.decode())
(base/'supplemental-E-inputs.json').write_text(json.dumps(rows,indent=2)+'\n')
stdout='\n\n'.join(out)+'\n';(base/'read-supplemental-process-evidence.stdout.txt').write_text(stdout);print(stdout,end='')
