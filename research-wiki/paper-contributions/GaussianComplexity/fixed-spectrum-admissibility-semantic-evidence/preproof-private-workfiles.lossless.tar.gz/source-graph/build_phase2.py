from pathlib import Path
import hashlib
import json
from datetime import datetime, timezone

ROOT=Path('/Users/zhouhuanjian/ASTIS-GC')
BASE=ROOT/'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-admissibility-semantic-evidence'
P1=BASE/'source-only-review/phase1'
P2=BASE/'source-only-review/phase2'
SEAL=ROOT/'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-admissibility-statement-seal.json'
CONTEXT=BASE/'necessary-definition-context.json'

def sha_bytes(b): return hashlib.sha256(b).hexdigest()
def sha(p): return sha_bytes(p.read_bytes())
def write(name,value):
    p=P2/name
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
def snapshot(src,name,expected=None):
    b=src.read_bytes()
    if expected: assert sha_bytes(b)==expected
    dst=P2/'inputs'/name
    dst.parent.mkdir(parents=True,exist_ok=True)
    dst.write_bytes(b)
    return {'path':str(src.relative_to(ROOT)), 'sha256':sha_bytes(b), 'snapshot':str(dst.relative_to(P2))}

assert not (P2/'freeze.json').exists(), 'Phase two is frozen; do not mutate it.'
P2.mkdir(parents=True,exist_ok=True)
pins={
 'freeze.json':'5363e9c98e484dc4439d700cdbe7ece589ec4cb5fafdcd832a0bf2a65d6e4327',
 'source-graph.json':'0159b1fdc8698702683dbe7fb872ec1e60e0be7ab0d8140f6b70b1bf85c6e0e7',
 'coverage.json':'bec73318e0437f4dc2bc70ae79286f27218ef4a884aa33523ca9fa5ecea1623b',
 'source-contract.json':'dfce7da369bcd323c679b8f21c44cfff0699903ffe064f9fca5c1ca152470319',
 'exposure-manifest.json':'d16a6167c2c92614015f5c0d7a0f4e7ccbad3d730dc8e89e4437b22e7ab05809',
 'rawhashes.json':'efde0459ec4450da27a0ac0c5d30f8bc5fb49dc1fa66a71bece596140d07fc90',
}
assert all(sha(P1/name)==expected for name,expected in pins.items())
inputs=[snapshot(SEAL,'statement-seal.json','ab68d72daa52e4607be3acf310b93cb0ad20c3638cd8062078805e3a33eccab0'),
        snapshot(CONTEXT,'necessary-definition-context.json','e41f07383b3aa3c57bbf686642e0dc14bf58555fd5451a8bf5c5f55bc325ff6a')]
seal=json.loads(SEAL.read_text())
context=json.loads(CONTEXT.read_text())
assert sha_bytes(seal['exact_signature_utf8'].encode())=='186231307d4c41acba15a1098c56518120394295cf048f504fed6f8ea50018d5'
for x in context['source_file_excerpts']:
    inputs.append(snapshot(ROOT/x['raw_excerpt'],Path(x['raw_excerpt']).name,x['raw_excerpt_sha256']))

# One necessary group-carrier expansion. Only lines 35–37 were displayed to
# the extractor; line 37 was incidental adjacent generic submonoid closure.
unitary=ROOT/'.lake/packages/mathlib/Mathlib/Algebra/Star/Unitary.lean'
assert sha(unitary)=='e7cbed9e7b9047f20ef1766c592540a2df9b3fb1c7cb578e35784aa0108d0b67'
ub=unitary.read_text().splitlines(keepends=True)
ue=''.join(ub[34:37]).encode()
(P2/'inputs/unitary-carrier-exposure.txt').write_bytes(ue)
inputs.append({'path':str(unitary.relative_to(ROOT)),'source_file_sha256':sha(unitary),'inclusive_lines':[35,37],
 'sha256':sha_bytes(ue),'snapshot':'inputs/unitary-carrier-exposure.txt',
 'semantic_lines':[35,36], 'incidental_exposure':'Line 37: one_mem\' generic structure-construction proof, not a target theorem or positivity proof.'})

g=json.loads((P1/'source-graph.json').read_text())
c=json.loads((P1/'coverage.json').read_text())
selected=['notation','orthogonal','precision-class','hard-parameters','cosine-grid','rotated-precision','lemma-4.6',
 'angles-open','cosine-open','eigenvalues-open','conjugated-bounds','gap-grid-arithmetic','gap-cosine-background',
 'gap-affine-envelope','gap-orthogonal-congruence']
selected={'sg:fs-admiss:'+x for x in selected}
pending=['target-potential','oracle-equivalence','uniform-accuracy','public-spectrum','class-membership','quadratic-calculus',
 'strong-convex-smooth','origin-minimizer','gaussian-target','normalizer-integral','determinant-invariance','known-normalizer',
 'consumer-theorem-context','consumer-admissibility-use','slc-context','gap-quadratic-calculus','gap-hessian-adapters',
 'gap-gaussian-normalization','gap-determinant']
pending={'sg:fs-admiss:'+x for x in pending}
assert selected|pending=={n['id'] for n in g['nodes']}
assert not selected&pending

write('source-graph.json',{
 'schema_version':1,'phase':'phase2-source-to-seal-matching',
 'frozen_phase1':{'path':str(P1.relative_to(ROOT)),'hashes':pins},
 'source_topology_unchanged':True,'nodes':g['nodes'],'edges':g['edges'],
 'selected_producer_source_slice':sorted(selected),
 'explicit_pending_downstream_or_context':sorted(pending),
 'route_semantics':g['route_semantics'],
 'boundary':'All source nodes and source edges are copied verbatim from frozen phase1. Selected-producer matching does not remove any appended source branch, establish any proof edge, or make an unproved bridge a theorem binder.',
 'status':'proposed-match-pending-distinct-topology-challenge'})

for u in c['units']:
    if u['disposition']=='NODE':
        ids=set(u['nodes'])
        u['phase2_binding']={
          'selected_producer_nodes':sorted(ids&selected),
          'pending_downstream_or_context_nodes':sorted(ids&pending),
          'formal_status':'not-proved; source coverage disposition retained'}
    else:
        u['phase2_binding']={'status':'source-exclusion-retained','reason':'No candidate implementation is used to expand or shrink the frozen source scope.'}
write('coverage.json',{
 'phase':'phase2','frozen_phase1_coverage_sha256':pins['coverage.json'],
 'source_sha256':c['source_sha256'],'scope':c['scope'],'coverage_counts':c['coverage_counts'],'units':c['units'],
 'dispositions_unchanged':True,
 'boundary':'NODE/EXCLUDED dispositions and all source texts/reasons are preserved. Phase2 adds only a selected producer versus explicit pending binding. Mathematical coverage approval remains for a distinct challenger.'})

adapters=[
 {'id':'meaning:index','anchor':'S4.E11','candidate_fragment':'θ i = ((i.val : ℝ) + 1/2) * Real.pi / (d : ℝ)',
  'source_meaning':'Source index i_src∈{1,…,d} corresponds to i.val+1; i_src−1/2=i.val+1/2. The finite carrier covers every source coordinate once.',
  'internal_obligation':'Discharge casts/index alignment and positive denominator from hd. Do not add index-angle or envelope hypotheses.'},
 {'id':'meaning:orthogonal','anchor':'S2.p2.1 / S4.Thmtheorem6.p1.1','candidate_fragment':'O : Matrix.orthogonalGroup (Fin d) ℝ',
  'source_meaning':'The aliases expand to unitary matrices; the carrier has star O * O = 1 and O * star O = 1. Over real matrices star is transpose. This is the full real O(d), with no determinant-sign condition.',
  'internal_obligation':'The source writes the square-matrix condition OᵀO=I. Its equivalence to the two-sided carrier uses finite square real linear algebra. That equivalence is a definition/typing adapter, not a new source premise.',
  'evidence':'Provided alias excerpts plus the narrowly expanded generic unitary carrier; real transpose sense was supplied in the authorized definition context.'},
 {'id':'meaning:literal-A','anchor':'S4.E11 / S4.SS1.p1.2','candidate_fragment':'(O : Matrix (Fin d) (Fin d) ℝ) * Matrix.diagonal (fun i => (κ+1)/2 + (κ−1)/2 * Real.cos (θ i)) * (O : Matrix (Fin d) (Fin d) ℝ).transpose',
  'source_meaning':'The actual source OΛOᵀ, with the literal cosine diagonal. diagonal has these entries on equal coordinates and zero off diagonal.',
  'internal_obligation':'No separate spectrum, matrix factorization, symmetry, or positivity premise is supplied.'},
 {'id':'meaning:finite-quadratic-form','anchor':'S2.p1.1 / S4.Thmtheorem6.p1.1','candidate_fragment':'Matrix.PosSemidef / Matrix.PosDef on Fin d',
  'source_meaning':'The excerpts quantify over finitely supported real vectors. Since Fin d is finite, these represent all ordinary real d-vectors. Hermitian means conjugate-transpose equality, hence symmetry over ℝ; the double finite sum is xᵀMx.',
  'internal_obligation':'Supply the finite-function/Finsupp and real-star meanings internally when needed. No entrywise-positivity interpretation or restriction to a subset of test vectors is permitted.'},
 {'id':'meaning:loewner','anchor':'S2.p1.1 / S4.Thmtheorem6.p1.1','candidate_fragment':'(A - 1).PosSemidef ∧ (κ • (1 : Matrix (Fin d) (Fin d) ℝ) - A).PosSemidef',
  'source_meaning':'1 is the matrix identity; κ scalar action on identity is κ I_d. Positive semidefiniteness of the two differences is exactly I_d≼A≼κ I_d in the source symmetric-matrix order.',
  'internal_obligation':'Derive all Hermitian/symmetry and finite quadratic-form requirements from literal A and orthogonality, rather than requesting them as theorem binders.'},
 {'id':'meaning:produced-PosDef','anchor':'S4.Thmtheorem6.p1.1 / A3.SS4.p1.1','candidate_fragment':'A.PosDef',
  'source_meaning':'This is not textually an extra conjunct of the numbered lemma. It is a mathematically redundant produced consequence of the lower identity bound: every nonzero vector has positive identity quadratic form. The source proof also obtains the strict scalar envelope.',
  'internal_obligation':'Prove the positive-definite consequence internally from source-backed bounds/strict envelope. Its presence in the result does not license an hPD premise or certify a Gaussian consumer.',
  'scope_classification':'source-derived explicit consequence; no new source hypothesis; not a separate source-anchor completion claim'},
]

slots=[
 {'slot':'objects','source':'Real orthogonal O, cosine θ_i/λ_i, diagonal Λ, actual precision A=OΛOᵀ.',
  'sealed':'Real Fin d orthogonal-group element; θ and A are literal let-bound formulas with no abstract spectrum provider.',
  'assessment':'Source objects preserved, subject to the definition/index adapters listed here.'},
 {'slot':'domains','source':'Integer d≥2, real κ≥2, i=1,…,d, real d×d O.',
  'sealed':'{d : ℕ} (hd : 2≤d) {κ : ℝ} (hκ : 2≤κ) and O on Fin d.',
  'assessment':'Source parameter range preserved; no off-source dimension or κ extension is claimed.'},
 {'slot':'quantifiers','source':'Define the deterministic grid for each d,κ; for every O∈O(d) define A and conclude bounds.',
  'sealed':'d,κ binders and arbitrary actual O precede let-bound θ,A and the conclusion.',
  'assessment':'Source quantifier direction/order preserved. The public result is pointwise in O.'},
 {'slot':'assumptions','source':'Standing d≥2,κ≥2; explicit O∈O(d).',
  'sealed':'Only hd, hκ and typed full actual O; no producer correctness, envelope, affine, positivity, Gaussian or algorithm hypothesis.',
  'assessment':'No excess mathematical public premise is visible in the exact signature. The two-sided group carrier is a square-real-matrix definition adapter, not a source theorem premise.'},
 {'slot':'conclusion','source':'I_d≼A≼κI_d, with symmetry internally derived from the defined A.',
  'sealed':'A.PosDef and the two PSD differences.',
  'assessment':'The two difference conclusions encode the named lemma. PosDef is a source-derived redundant result, requiring an internal proof; it is not literally another source statement. No matrix inverse, Gaussian target, density, determinant, normalizer or consumer is concluded.'},
 {'slot':'scopes_senses','source':'Finite real Euclidean matrices; actual precision, deterministic every O; source additionally discusses a randomized hard-input family.',
  'sealed':'Finite real matrix/transpose/Finsupp quadratic-form meanings, no Haar law or algorithm objects.',
  'assessment':'Pointwise deterministic admissibility scope preserved. Matrix order is quadratic-form order; precision must not later be confused with covariance.'},
 {'slot':'constant_dependencies','source':'Exact lower number 1 and upper number κ; family d≥2,κ≥2.',
  'sealed':'Exact identity and κ scalar identity, same half-offset cosine coefficients and denominator d.',
  'assessment':'No altered normalization or hidden constants. δ, q, ε, d0 and upper κ cutoff remain solely downstream consumer context.'},
]

obligations=[]
for n in g['nodes']:
    sid=n['id']
    if sid in selected:
        obligations.append({'source_node':sid,'source_anchors':n['source_anchors'],
          'match_status':'selected-producer-source-content',
          'internal_obligation': n['claim_or_meaning'] if n['kind']=='SOURCE_GAP' else 'Source meaning must be realized by the sealed literal object/conclusion or its internal proof; no compiled evidence inspected.',
          'source_gap_status':'unproved' if n['kind']=='SOURCE_GAP' else 'not-a-source-gap-node',
          'public_binder_effect':'none; only the sealed source binders remain'})
    else:
        obligations.append({'source_node':sid,'source_anchors':n['source_anchors'],
          'match_status':'explicit-pending-downstream-or-context-outside-selected-producer',
          'claim_or_meaning':n['claim_or_meaning'],
          'source_gap_status':'unproved' if n['kind']=='SOURCE_GAP' else 'not-proved-by-selected-producer',
          'boundary':'Retained in source graph/coverage. Not deleted, not certified by the selected theorem, and not promoted to a producer hypothesis.'})

write('matching.json',{
 'schema_version':1,'phase':'phase2','source_graph_pin':pins['source-graph.json'],
 'candidate_seal_sha256':sha(SEAL),'exact_signature_sha256':sha_bytes(seal['exact_signature_utf8'].encode()),
 'exact_signature_utf8':seal['exact_signature_utf8'],
 'authorized_definition_context_sha256':sha(CONTEXT),
 'assessment':'Proposed source-compatible selected producer with an explicit source-derived PosDef consequence; no excess public premise visible. This is not acceptance, proof evidence, or source verification and remains pending the distinct topology challenge.',
 'seven_slots':slots,'definition_meaning_adapters':adapters,'node_by_node_binding':obligations,
 'selected_internal_source_bridge_ids':[n['id'] for n in g['nodes'] if n['id'] in selected and n['kind']=='SOURCE_GAP'],
 'pending_appended_C4_branches':{
  'calculus':['quadratic-calculus','strong-convex-smooth','origin-minimizer','gap-quadratic-calculus','gap-hessian-adapters'],
  'gaussian_and_normalizer':['gaussian-target','normalizer-integral','determinant-invariance','known-normalizer','gap-gaussian-normalization','gap-determinant'],
  'status':'All remain outside the selected producer and explicitly unproved here. Their source existence and graph edges are preserved.'},
 'actual_consumer_boundary':{
  'planned':'Actual centered Gaussian for the inverse of this literal precision; consume produced positivity/admissibility to justify actual inverse covariance/precision or actual nondegenerate density.',
  'required_later_audit':'After full preproof admission, audit the exact existing Gaussian interface, coordinate carrier and positivity/invertibility meaning. Derive inverse relationships internally. Do not supply an abstract Gaussian correctness premise to the producer.',
  'not_yet_claimed':['an existing Gaussian API has been selected','inverse identity proved','target law constructed or identified','nondegenerate density proved','source normalizer proved','consumer compiled'],
  'source_use_site':'S4.SS1.p1.2 / A3.SS4.p3.1; lower-bound guarantee restriction uses S4.SS3.p2.1'},
 'proof_route_independence':'Only frozen source topology decides source nodes/edges. No target proof, target API, Test, root preseal audit, authored lesson or previous reviewer result was opened. Meaning adapters are not a proposed Lean implementation route.',
 'remaining_gate':'Distinct topology/coverage challenge; full preproof admission precedes target proof/API work.'})

write('exposure-manifest.json',{
 'phase':'phase2','role':'independent-source-graph matcher; not a proof worker',
 'prior_freeze':{'path':str(P1.relative_to(ROOT)),'hashes':pins},
 'new_authorized_inputs':inputs,
 'new_necessary_lookup':'The supplied orthogonalGroup aliases stopped at generic unitary. A necessary carrier-only lookup exposed Algebra/Star/Unitary.lean lines 35–37. Lines 35–36 give both multiplication/star identities; line 37 incidentally shows the generic one_mem\' structure proof. No positivity or target-specific theorem API/proof was searched.',
 'root_disclosure_boundary':'The seal states that root had incidental adjacent generic Std proof-tail exposure during preseal definition lookup. That is root-supplied disclosure only; the referenced root audit and type-check receipts were not opened by this matcher.',
 'candidate_identity_only_exposure':'The seal includes the prospective production/Test paths, receipt hashes, root audit path/hash, truth boundaries and status. Their contents were not opened, searched or independently verified.',
 'own_phase1_retrieval':'Frozen graph, coverage, source contract, exposure manifest and hashes were read/hashed for pin verification. Phase1 files were not modified.',
 'explicit_non_exposure':['Production Lean','Test proof','Target-specific API/proof search','Root preseal audit contents','Authored publication/declaration lesson','Previous reviewer result','SAU/cell/audit/ledger/discoveries/Registry state','Site/build/browser/remote','.atlas-upstream','Model trials/evaluation'],
 'own_mutations':'Only this own phase2 subtree and private helper build_phase2.py were written.',
 'truth_boundary':'Definition matching and source topology do not certify compiled mathematics or complete any pending appended source branch.',
 'stop_rule':'Freeze phase2, send exact hashes to root, then stop for a distinct topology challenge.'})

write('raw-inputs.json',{'phase':'phase2','frozen_phase1_inputs':pins,'authorized_inputs':inputs,
 'source_original_sha256':'6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915',
 'candidate_exact_signature_sha256':'186231307d4c41acba15a1098c56518120394295cf048f504fed6f8ea50018d5',
 'no_proof_input':'No target implementation/Test proof was provided or opened.'})

