from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import subprocess

ROOT = Path('/Users/zhouhuanjian/ASTIS-GC')
BASE = ROOT / 'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-admissibility-semantic-evidence'
OWN = BASE / 'fresh-source-reader-742806'
OUT = OWN / 'phase3'
HEAD = '83fec39dfa6202cdf9bc687affb10aafbc216ab8'
PACKET = '50a751a10e22704a5002fe3ae515f3874533e0e077369f9a8ca935e11fe4d2ce'
BINDING = 'e4e245c817d124b16e93b4f999df81132f1e50a9e38535903cb5c036417c0e94'

def sha(b):
    return hashlib.sha256(b).hexdigest()

def write_json(p, x):
    p.write_text(json.dumps(x, ensure_ascii=False, indent=2) + '\n')

assert not (OUT / 'manifest.json').exists()
pins = json.loads((BASE / 'full-review-input-pins.json').read_text())
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == HEAD
for path, digest in pins['exact_inputs'].items():
    assert sha((ROOT / path).read_bytes()) == digest, path
prior_hashes = {}
for phase in ['phase1', 'phase2']:
    m = json.loads((OWN / phase / 'manifest.json').read_text())
    mh = sha((OWN / phase / 'manifest.json').read_bytes())
    assert mh == (OWN / phase / 'manifest.sha256').read_text().split()[0]
    for f in m['files']:
        assert sha((OWN / phase / f['path']).read_bytes()) == f['sha256']
    prior_hashes[phase] = mh
full = json.loads((BASE / 'full-anti-anchored-reviewer-packet.json').read_text())
canon = dict(full)
assert canon.pop('packet_sha256') == PACKET
assert sha(json.dumps(canon, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()) == PACKET
assert full['publication_binding_sha256'] == BINDING
assert sha((BASE / 'full-anti-anchored-reviewer-packet.json').read_bytes()) == pins['full_packet_raw_sha256']
for p in sorted((OUT / 'receipts').glob('*.receipt.json')):
    assert json.loads(p.read_text())['returncode'] == 0, p
static = json.loads((OUT / 'static-reader-check.json').read_text())
assert static['publication_binding_sha256'] == BINDING
assert static['exact_statement_panel'] and static['exact_proof_panel']
assert static['formula_steps'] == 5 and static['source_assumption_delta_rows'] == 3
assert static['all_disclosures_initially_closed'] and static['scope_boundary_present']

paths = [
    str((BASE / 'full-review-input-pins.json').relative_to(ROOT)),
    str((BASE / 'full-anti-anchored-reviewer-packet.json').relative_to(ROOT)),
    'AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumAdmissibility.lean',
    'Tests/GaussianComplexityFixedSpectrumAdmissibility.lean',
    'website/content/declaration_lessons/huanjian-fixed-spectrum-admissibility.json',
    'website/content/publications/huanjian-fixed-spectrum-admissibility.json',
    'AutoSamplingTheory/TechnicalLemmas/Measure/GaussianPrecisionDensity.lean',
    'AutoSamplingTheory/TechnicalLemmas/Measure/IsotropicGaussianDensity.lean',
    'AutoSamplingTheory/TechnicalLemmas/Measure/RadonNikodym.lean',
    '.lake/packages/mathlib/Mathlib/Algebra/Order/Star/Real.lean',
    '.lake/packages/mathlib/Mathlib/LinearAlgebra/Matrix/PosDef.lean',
    '.lake/packages/mathlib/Mathlib/LinearAlgebra/UnitaryGroup.lean',
    '.lake/packages/mathlib/Mathlib/Probability/Distributions/Gaussian/Multivariate.lean',
    '.lake/packages/mathlib/Mathlib/MeasureTheory/Measure/Haar/InnerProductSpace.lean',
    '.lake/packages/mathlib/Mathlib/MeasureTheory/Measure/Lebesgue/EqHaar.lean',
    '.lake/packages/mathlib/Mathlib/Data/Matrix/Mul.lean',
    'website/scripts/publication_reader.py', 'website/scripts/declaration_lessons.py',
    'website/scripts/inline_lean.py', 'tools/astis_publication.py',
    str((BASE / 'source-only-review/phase1/source-graph.json').relative_to(ROOT)),
    str((BASE / 'source-only-review/phase2-repair1/source-graph.json').relative_to(ROOT)),
    '.astis/semantic-neutral-20261108/d6a1c703/input.json',
    '.astis/semantic-neutral-20261108/d6a1c703/decoded-918537/independent-run.json',
    '.astis/semantic-neutral-20261108/d6a1c703/decoded-918537/exposure-manifest.json',
    '.astis/semantic-neutral-20261108/d6a1c703/decoded-918537/reconstructed-theorem.txt',
    'lean-toolchain', 'lake-manifest.json',
    '.astis/huanjian-fixed-spectrum-admissibility-20261107/fresh-source-742806/phase3_probe.lean'
]
(OUT / 'raw-inputs').mkdir(exist_ok=False)
raw_inputs = []
for i, path in enumerate(paths):
    b = (ROOT / path).read_bytes()
    snapshot = OUT / 'raw-inputs' / f'{i:02d}-{Path(path).name}.raw'
    snapshot.write_bytes(b)
    raw_inputs.append({'original_path': path, 'snapshot': str(snapshot.relative_to(OUT)),
                       'sha256': sha(b), 'bytes': len(b)})

write_json(OUT / 'pin-and-lineage-check.json', {
    'checked_commit': HEAD,
    'all_exact_pins_still_match': pins['exact_inputs'],
    'raw_full_packet_sha256': pins['full_packet_raw_sha256'],
    'canonical_reviewer_packet_sha256': PACKET,
    'publication_binding_sha256': BINDING,
    'phase1_manifest_sha256': prior_hashes['phase1'],
    'phase2_manifest_sha256': prior_hashes['phase2'],
    'source_raw_sha256': '6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915',
    'formalizer': full['roles']['formalizer'],
    'decoder': '/root/decode_918537',
    'reviewer': '/root/reader_742806',
    'actors_distinct': True,
    'decoder_input_raw_sha256': 'a83392e166b7fc40cb0abf052f5acc8c8a93f128b714cd637156e85fe42fa933',
    'decoder_packet_canonical_sha256': '255d9aa7729ef4ab791199024074f21618ce2d1b3fa28648d8d29d2ab8729285',
    'decoder_run_raw_sha256': '3349cabb596d3544a2cc3cfcb28f5df8fae8889ad04bb3740f2ba59ae05091b3',
    'decoder_exposure_raw_sha256': 'c1dc1c691da851a1a37b1b2f6e0c4293435dc221a8b7ebd46fbdac477b071d13',
    'reconstruction_text_sha256': '205efbc539703ab9e8cf408f24e9d3b56524ff428cf24bc1dc38b147a225c731',
    'decoder_lineage_findings': 'Actual neutral input/run/exposure bytes hash-checked in phase3. Run confirms only anonymous proposition and five contexts, no source/identity/audit/repair/repository reads, no semantic equivalence judgment, and independent decoder freeze.',
    'reviewer_lineage': 'Own raw-source phase1 froze before anonymous packet/reconstruction; selective phase2 froze before full module/prose/graphs. Phase1 filename-only enumeration caveat remains preserved. Source-only and selective verdicts were not edited after fuller exposure.',
    'normal_VERIFIED_API_invoked': False
})

route_map = {
    'distinction': 'Target equivalence and implementation closure are accepted for the short source anchor. Historical source proof topology is preserved; strict source nodes are not marked proved by a different closed-envelope route.',
    'source_route': 'Exact grid -> strict interior angles -> strict cosine range -> strict affine eigenvalue interval -> orthogonal conjugation -> non-strict Loewner conclusion.',
    'actual_OR_route': 'Exact literal grid -> global -1<=cos(theta)<=1 -> nonnegative coefficient and closed affine scalar bounds -> two PSD diagonal differences -> actual orthogonal conjugation -> two PSD matrix differences -> identity plus lower difference gives PosDef.',
    'four_core_gap_mapping': [
        {'source_gap': 'sg:fs-admiss:gap-grid-arithmetic',
         'actual_evidence': 'Production uses the literal real half-grid. Focused Test first example proves source one-based j=i+1 index alignment by ring.',
         'status': 'Literal/index meaning checked; strict 0<theta_i<pi inequalities NOT proved here and are unnecessary for actual OR route.'},
        {'source_gap': 'sg:fs-admiss:gap-cosine-background',
         'actual_evidence': 'hvalue uses canonical Real.neg_one_le_cos and Real.cos_le_one for every real theta.',
         'status': 'Closed-envelope prerequisite discharged; strict source cosine-node remains unproved historical route.'},
        {'source_gap': 'sg:fs-admiss:gap-affine-envelope',
         'actual_evidence': 'hcoef derives (kappa-1)/2>=0 from kappa>=2; hvalue internally proves 1<=diagonalValue_i<=kappa by real arithmetic.',
         'status': 'Required closed scalar envelope discharged internally; strict 1<lambda_i<kappa source-node is not asserted/proved.'},
        {'source_gap': 'sg:fs-admiss:gap-orthogonal-congruence',
         'actual_evidence': 'hdiaglo/hdiaghi identify actual diagonal differences; hlow/hhigh call canonical PSD diagonal; hO comes from full orthogonal carrier; hstar reduces real conjugate transpose; hloweq/hhigheq distribute products; hAlo/hAhi use canonical PSD conjugation.',
         'status': 'Actual matrix symmetry/quadratic-form/Loewner bridge discharged. No PSD, symmetry, scalar bound or norm-preservation certificate added as premise.'}
    ],
    'topology_repair': 'Original determinant-invariance node combines det(A)=det(Lambda) with the resulting Z equality. Repaired graph adds existing normalizer-integral as a prerequisite to that full combined claim. This is warranted by the unchanged node meaning; all nodes and other edges remain unchanged. No implication from C.4 Gaussian/calculus branches into admissibility is introduced.',
    'pending': ['strict angle/cosine/eigenvalue source-route nodes', 'full C.4 calculus/Hessian/strong-convexity/smoothness/minimizer interfaces', 'determinant invariance and fixed-spectrum normalizer product independent of O', 'moments/Krylov/concentration', 'adaptive/query/TV/cost/finite-precision transports', 'both main lower bounds'],
    'actual_Gaussian_consumer': 'A separate focused Test proves same-A inverse-covariance Gaussian equals the exact Lebesgue quadratic density using the producer PosDef output and the existing canonical GaussianPrecisionDensity node. This is not a new producer proof parent and does not prove the remaining fixed-spectrum normalizer product.'
}
write_json(OUT / 'actual-proof-OR-route-and-source-gap-map.json', route_map)

write_json(OUT / 'critical-definition-and-consumer-review.json', {
    'real_order': 'Actual canonical Real.instStarOrderedRing is supplied by Mathlib.Algebra.Order.Star.Real, proved via sqrt characterization of nonnegative reals. No project replacement instance.',
    'PSD_PD': 'Actual PosSemidef/PosDef require Hermitian symmetry and quadratic-form nonnegativity/strict positivity on finitely supported vectors. Canonical posSemidef_iff_dotProduct_mulVec uses Finsupp.equivFunOnFinite, establishing all coordinate vectors in finite dimension. Diagonal, conjugation, identity and addition facts inspected in actual source.',
    'orthogonal_group': 'Actual orthogonalGroup is unitaryGroup under real trivial star; either transpose product is equivalent to membership. specialOrthogonalGroup is separate and adds determinant=1. No determinant sign premise occurs.',
    'producer_PosDef': 'hAlo supplies PSD(A-I); canonical PosDef.one and PosDef.posSemidef_add give PosDef((A-I)+I)=PosDef(A). It is output, not theorem input. hd unused is an intentional retained source binder, not missing source domain.',
    'actual_Gaussian_definition': 'multivariateGaussian mu S maps stdGaussian through mu+CFC.sqrt(S)x. Documentation and theorem show non-PSD S falls back to dirac mu through sqrt=0. This fallback is excluded on the actual Test branch: producer yields hA; canonical GPD derives hAi:A^{-1}.PosDef and uses hAi.posSemidef and CFC sqrt-square/invertibility identities.',
    'same_A': 'Test repeats the exact literal half-grid and O diagonal O.transpose construction; hA is exactly producer(...).1; the same A is passed to multivariateGaussian_eq_withDensity_of_posDef. No hPD or correct-density assumption.',
    'precision_covariance': 'Actual Gaussian covariance argument is A^{-1}; density exponent uses A. GPD inverse-square-root linear equivalence converts covariance pushforward to precision quadratic.',
    'measure': 'Reference is (volume:Measure(EuclideanSpace R (Fin d))).withDensity, not a probability base law. Haar/InnerProductSpace identifies volume with orthonormal-basis normalized Lebesgue/addHaar; coordinate toLp/ofLp equivalences preserve volume. This is separate from Haar probability on O(d).',
    'exponent': 'Test and GPD use (d:Real)/2 and Real.rpow, including odd d; no natural floor division. Density factor is sqrt(det A)/(2*pi)^(d/2), and exponent is -(x^T A x)/2.',
    'critical_GPD_ancestry': ['GPD private exists_matrix_linearEquiv with invertible covariance sqrt', 'canonical IsotropicGaussianDensity.map_sqrt_smul_stdGaussian_eq_withDensity', 'RadonNikodym.measurableEquiv_map_withDensity', 'Mathlib multivariateGaussian/CFC square root', 'Lebesgue/addHaar linear-map determinant formula'],
    'GPD_axioms': ['propext', 'Classical.choice', 'Quot.sound'],
    'producer_axioms': ['propext', 'Classical.choice', 'Quot.sound'],
    'producer_direct_ASTIS_proof_parents': [],
    'interpretation': 'GPD is existing canonical background genuinely consumed by Test, not new source/proof credit for the producer. No source target replacement or arbitrary matrix witness is used.'
})

phase2 = json.loads((OWN / 'phase2/seven-slot-comparison.json').read_text())
relations = {'objects': 'equivalent', 'domains': 'equivalent',
             'quantifiers': 'same', 'assumptions': 'same',
             'conclusion': 'explicit-elaboration', 'scopes_senses': 'equivalent',
             'constant_dependencies': 'same'}
slots = {}
for key, row in phase2['seven_semantic_slots'].items():
    canonical_key = 'scopes' if key == 'scopes_senses' else key
    slots[canonical_key] = {
        'original': row['source'],
        'reconstructed': row['anonymous_and_decoder'],
        'relation': relations[key],
        'evidence': row['comparison'] + ' Whole-module phase3 confirms the actual meaning-carrying definitions, literal constructor, source-only binders, actual proof and same-A consumer. See critical-definition-and-consumer-review.json and actual-proof-OR-route-and-source-gap-map.json. Full C.4/main bounds remain outside this short-anchor acceptance.'
    }
write_json(OUT / 'seven-semantic-slots.final.json', slots)
write_json(OUT / 'deltas.final.json', {
    'blocking_semantic_deltas': [],
    'representation_elaborations': [
        'Equivalent source j=1..d to Fin d i=0..d-1 real half-grid, proved by focused Test adapter.',
        'Explicit PosDef is a redundant produced consequence of source lower bound; no strengthened input assumption.',
        'PSD finite-support semantics covers every source vector on finite Fin d; real Hermitian is symmetry.'
    ],
    'route_delta': 'Valid alternate OR route uses closed global cosine bounds, not source strict interior-angle route; source strict nodes remain unproved.',
    'scope_delta': 'No source-statement weakening within selected Lemma 4.6. Full C.4 and both main bounds were never included in this producer acceptance; actual same-A Gaussian density consumer is separately verified.',
    'repairs': [],
    'canonical_projection_rule': 'Canonical deltas list is empty because no mathematical mismatch remains for the selected anchor. Equivalent representation/elaboration and exact residual scope are retained in slots and this evidence, not misclassified as blocking deltas.'
})

(OUT / 'review-result.md').write_text('''# Independent whole-module, source and static-reader review

Verdict: equivalent-after-elaboration for the bounded actual cosine-grid
precision admissibility source anchor, at checked commit
83fec39dfa6202cdf9bc687affb10aafbc216ab8 and publication binding
e4e245c817d124b16e93b4f999df81132f1e50a9e38535903cb5c036417c0e94.
No blocking semantic delta or source repair is required.

The exact public theorem preserves source d>=2, kappa>=2, the literal grid and
every full real orthogonal O, including either determinant sign. The actual
one-based/zero-based real half-grid meaning is proved in the focused Test.
Finite-support PSD/PD quantifiers cover every coordinate vector because Fin d
is finite. Both matrix differences are PSD in quadratic-form order; this is
not entrywise order. PosDef is produced from the lower identity bound and is
not an extra premise. There are no project-owned bundled assumptions to hide
extra inputs.

The entire production module was read. It has one public theorem, no private
helpers, no project proof parents, no scoped variable/instance surprises and
no fake closure tokens. Actual standard positivity instances and PSD/PD/group
definitions and the proof-critical standard lemmas were read. A direct Lean
probe confirms the actual signature, all proof parents and standard axiom sets.
The producer, GaussianPrecisionDensity and its critical positivity facts depend
only on propext, Classical.choice and Quot.sound.

The source route and the actual proof route are distinct sufficient OR routes.
The source uses strict interior angles, strict cosine bounds and strict scalar
eigenvalue bounds, then derives the non-strict matrix conclusion. Production
uses the globally true closed cosine envelope, derives its closed affine
interval internally, forms two actual PSD diagonal differences, conjugates
them through the actual O, and adds the positive identity for PosDef.
This is a faithful proof of the selected result. It does not prove or retire
the historical strict angle/cosine/eigenvalue source nodes. The index-meaning
adapter is not a proof of the strict grid inequalities. The four gap mappings
are explicit in actual-proof-OR-route-and-source-gap-map.json.

The original source graph retains all selected C.4 regions. Its repaired
determinant edge adds the normalizer-integral prerequisite because its unchanged
node asserts both determinant invariance and the resulting Z equality. This
repair is appropriate for that combined claim and does not add Gaussian or
calculus inputs to admissibility. Full potential calculus, Hessian,
strong-convexity/smoothness, minimizer and fixed-spectrum determinant/normalizer
product interfaces remain unproved by this contribution. Neither main lower
bound, moments/Krylov, adaptive/query/TV/cost or finite-precision transport is
claimed.

The focused Test is a genuine same-A consumer. Its only source inputs are
d>=2, kappa>=2 and full O. It obtains hA from the new producer and passes that
output to the existing canonical positive-precision Gaussian density theorem.
Actual multivariateGaussian is the covariance-square-root pushforward and has
a Dirac fallback outside PSD covariance. Here inverse precision is PosDef,
derived from producer positivity, so the fallback is excluded. The asserted
law is N(0,A^{-1}) and its density is with respect to actual Euclidean Lebesgue
volume, with sqrt(det A)/(2*pi)^((d:Real)/2) and exp(-x^T A x/2).
The real exponent preserves odd dimensions. The covariance/precision inversion,
volume convention and nonlinear coordinate equivalence were inspected in actual
canonical ancestry. This shared existing result is a Test consumer dependency,
not a producer proof parent or new theorem credit.

Independent checks passed: focused Lake target, fresh direct Lean compilations
of production, canonical GaussianPrecisionDensity and focused same-A Test,
plus a fresh signature/axiom/proof-parent probe. The only production warning
is the intentionally unused hd binder retained from the exact source domain.
No aggregate root build was run. Neither root AutoSamplingTheory.lean nor
Tests.lean currently imports the new module/Test; root integration and its
checks remain pending. All mathematical production content is nevertheless
reachable from and exercised by the focused real Test.

The actual lesson/publication were read, including all three assumption-delta
rows and the corrected narrow scope. Each of the five mathematical formula
steps agrees with the actual proof or separately verified same-A consumer.
The source statement, all conditions, exact index meanings and remaining
boundary are present. Stock publication_reader.source_card was executed
against current metadata, without a site build. Its frozen HTML has the exact
Lean statement adjacent to the mathematical claim and exact proof adjacent to
the formula steps, both initially closed; all five steps and source/assumption
comparison are in the same article. The source restatement precedes the lesson.
This is static content/DOM acceptance only, not browser/layout, website
deployment, Exposition Seal, purification or whole-Goal completion.

Raw-first independence is preserved: phase1 froze source-only before candidate
exposure; phase2 froze selective statement/decoder comparison before code,
prose or graphs. The genuine decoder was a distinct source-blind actor.
Its actual neutral input, independent-run and exposure hashes were rechecked.
The initial phase1 filename-only search caveat remains disclosed and no prior
review verdict was used to determine this result.

No canonical audit, shared cell, ledger, source graph, root import or authored
publication was changed. The audit projection and transition evidence in this
directory are proposals only. The sole independent normal VERIFIED API remains
uninvoked pending explicit root authorization.
''')

exposure = {
    'reviewer': '/root/reader_742806',
    'phase': '3-after-two-independent-freezes',
    'newly_visible': ['Pinned full anti-anchored packet', 'Current full production and focused Test', 'Actual source-critical Mathlib and existing GaussianPrecisionDensity ancestry', 'Current lesson/publication including assumption deltas/boundary', 'Original source-only graph and repaired graph', 'Actual independent decoder neutral lineage', 'Stock-rendered current target metadata'],
    'not_used_for_verdict': ['Other source reviewer verdict contents', 'Prior candidate acceptance decisions', 'Model trials/evaluation', 'ATLAS material'],
    'read_only_global_operations': ['git rev-parse HEAD', 'Hash-only audit/ledger pin checks', 'Target root-reference search', 'Pure publication binding_digest and stock source_card rendering'],
    'build_operations': 'Focused Lake build and fresh direct Lean invocations only; compiler/package caches may be used but no mathematical source edits.',
    'mutations': 'Own phase3 outputs, receipts and private phase3 probe/generator only.',
    'source_graphs_mutated': False,
    'canonical_audit_or_ledgers_mutated': False,
    'normal_VERIFIED_API_invoked': False,
    'subagents_spawned': False,
    'new_mathematical_proof_construction': False,
    'tool_note': 'A first inspection-probe add attempt failed JS parsing on Lean name backticks and made no file change; a normally quoted patch succeeded. No mathematical route retry or altered production followed.',
    'anti_anchoring': 'Source-only and selective freezes remained byte-identical throughout full review. All candidate/proof/reader decisions were made only after explicit phase3 exposure authorization.'
}
write_json(OUT / 'exposure.full-review.json', exposure)

run = {
    'schema_version': 1,
    'reviewer': '/root/reader_742806',
    'completed_at_utc': datetime.now(timezone.utc).isoformat(),
    'checked_commit': HEAD,
    'reviewer_packet_sha256': PACKET,
    'reviewer_packet_raw_sha256': pins['full_packet_raw_sha256'],
    'publication_binding_sha256': BINDING,
    'phase1_manifest_sha256': prior_hashes['phase1'],
    'phase2_manifest_sha256': prior_hashes['phase2'],
    'source_blind_decoder_distinct': True,
    'source_raw_first_review_frozen': True,
    'selective_comparison_frozen_before_full_exposure': True,
    'verdict': 'equivalent-after-elaboration',
    'blocking_deltas': [],
    'repairs': [],
    'whole_module_review': 'accepted for the selected actual admissibility anchor',
    'actual_same_A_Gaussian_consumer': 'accepted focused Test use of existing canonical leaf',
    'static_reader_content': 'accepted with explicit residual scope; no browser/site acceptance',
    'raw_inputs': raw_inputs,
    'evidence_files': [{'path': str(p.relative_to(OUT)), 'sha256': sha(p.read_bytes())}
                       for p in sorted(OUT.rglob('*')) if p.is_file()],
    'normal_VERIFIED_API_invoked': False,
    'scope': 'bounded source/module/Test/static reader review; integration, full C4 and main Goal remain open'
}
write_json(OUT / 'independent-review-run.json', run)
run_sha = sha((OUT / 'independent-review-run.json').read_bytes())

projection = {
    'semantic_slots': slots,
    'deltas': [],
    'verdict': 'equivalent-after-elaboration',
    'repairs': [],
    'reviewer': '/root/reader_742806',
    'independent_from_formalizer': True,
    'independent_from_decoder': True,
    'review_evidence': str((OUT / 'review-result.md').relative_to(ROOT)),
    'review_run_sha256': run_sha,
    'reviewer_packet_sha256': PACKET,
    'publication_binding_sha256': BINDING,
    'publication_context': full['candidate_publication_context']
}
write_json(OUT / 'proposed-canonical-audit-projection.json', projection)
write_json(OUT / 'proposed-independent-transition-evidence.json', {
    'proposed_transition': 'VERIFIED only after explicit root authorization; not executed',
    'verifier_id': '/root/reader_742806',
    'verified_commit': HEAD,
    'result_kind': 'theorem-edge',
    'declaration': full['lean']['declaration'],
    'gate': 'phase3/receipts/focused-lake-build.receipt.json plus producer-direct, canonical-density-direct, same-A-Test-direct and ancestry-probe receipts; all returncode=0',
    'source_audit': str((OUT / 'seven-semantic-slots.final.json').relative_to(ROOT)),
    'semantic_roundtrip_audit': 'ASTIS-RT-20261107-HuanjianFixedSpectrumAdmissibility; proposed-canonical-audit-projection.json remains unapplied',
    'fake_closure_scan': str((OUT / 'whole-module-and-fake-closure.json').relative_to(ROOT)),
    'review_run_sha256': run_sha,
    'reviewer_packet_sha256': PACKET,
    'publication_binding_sha256': BINDING,
    'residual_boundary': 'No root integration/build, remote/site/public delivery, full C4 normalizer product/calculus/minimizer, moments/Krylov/algorithm adapters, main lower bounds, purification/Exposition Seal or Goal completion.',
    'root_reachable_integration_status': 'Focused Test imports and exercises every new production declaration; root aggregators do not yet import it.',
    'normal_API_mutation_performed': False
})

(OUT / 'README.md').write_text('''# Fresh source reader 742806 — phase three full-review freeze

Read review-result.md for the bounded acceptance and residual source scope.
The two earlier immutable freezes are preserved. Source and implementation
OR routes are distinguished; historical strict source nodes remain unproved.
Raw inputs, compiler receipts, signature/axiom/proof-parent probe, decoder
lineage, full module scan and stock static-reader HTML are pinned here.

The canonical audit projection and independent transition evidence are
proposals only. No normal VERIFIED API or shared/canonical mutation occurred.
manifest.json binds every phase-three file except itself; manifest.sha256 seals
it. No integration, browser/site, purification or whole-Goal claim is made.
''')

# Final protection read, immediately before the content seal.
for path, digest in pins['exact_inputs'].items():
    assert sha((ROOT / path).read_bytes()) == digest, path
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == HEAD
manifest = {
    'schema': 'fresh-source-reader-phase3-full-review-freeze-v1',
    'reviewer': '/root/reader_742806',
    'frozen_at_utc': datetime.now(timezone.utc).isoformat(),
    'checked_commit': HEAD,
    'verdict': 'equivalent-after-elaboration',
    'reviewer_packet_sha256': PACKET,
    'publication_binding_sha256': BINDING,
    'review_run_sha256': run_sha,
    'earlier_freezes': prior_hashes,
    'generator': {'path': str(Path(__file__).relative_to(ROOT)), 'sha256': sha(Path(__file__).read_bytes())},
    'files': [{'path': str(p.relative_to(OUT)), 'sha256': sha(p.read_bytes()), 'bytes': p.stat().st_size}
              for p in sorted(OUT.rglob('*')) if p.is_file()],
    'all_candidate_audit_ledger_pins_unchanged': True,
    'normal_VERIFIED_API_invoked': False,
    'next_action': 'STOP; await explicit root authorization before sole independent normal VERIFIED API'
}
write_json(OUT / 'manifest.json', manifest)
mh = sha((OUT / 'manifest.json').read_bytes())
(OUT / 'manifest.sha256').write_text(mh + '  manifest.json\n')
print(json.dumps({
    'phase3_path': str(OUT), 'verdict': manifest['verdict'],
    'manifest_sha256': mh, 'review_run_sha256': run_sha,
    'review_result_sha256': sha((OUT / 'review-result.md').read_bytes()),
    'canonical_projection_sha256': sha((OUT / 'proposed-canonical-audit-projection.json').read_bytes()),
    'transition_evidence_sha256': sha((OUT / 'proposed-independent-transition-evidence.json').read_bytes()),
    'frozen_file_count': len(manifest['files']),
    'normal_VERIFIED_API_invoked': False
}, indent=2))
