# C7 browser v2 — frozen preparation, disabled

This successor changes only the guard/context binding to real records. The48-original/20-native/14-equation-layout/two-DensityAffinity view checks are unchanged from v1; checker source differs only in importing and hashing its new common helper. v1 and every earlier proposal/readback/failure record remain exact. Neither checker/common was imported or executed; only source inspection and AST syntax parsing occurred.

The guard uses the actual original V receipt fields (`normal_API_calls`, `worker_and_verifier`, `actual_append_sha256`, `checked_commit`) and actual API observation/call evidence. It checks original V event evidence, accepted audit/run/binding and raw before/after sourceV gzip ledgers. It does not request or fabricate an execution-manifest wrapper.

The actual sole-STAB receipt reports one normal call; the eight-payload receipt reports zero calls. They remain separate records, bound to exact raw pre/post STAB ledgers. Initial application receipt974d and the original independent readback retain their creation-time history.

README is compared to sourceV carrier8af and current/core bytes, with the exact candidate37645 README retained as suffix. The legitimate sourceV prepend is not rejected or relabelled as new runtime acceptance.

The actual only-field string adapter and its independent readback are separately bound. The accepted current projection has three paths: `evidence.canonical_integration`, `evidence.independent_verification`, and `graph_contribution.functor_view`. Restoring the original verification dict from8af reconstructs the exact original initial-payload974d state; removing canonical_integration and reverting functor_view then restores the exact sourceVd797 raw bytes. This is an actual metadata schema correction, not a new source/math verdict. The conditional adapter proposal remains labelled as its historical unapplied preparation, and is never used alone as actual acceptance.

The sourceV/soleSTAB/application/adapter and accepted mechanical readback refs in the disabled template point to real existing files and actual hashes. New immutable-core/all-eight-gate/source-digest/site/subject-test/core-pin/site-pin fields remain null; root must fill them from actual completed records. `authorized_by=null`, `execute_browser_authorized=false`, and `actual_facts_reviewed_by_root=false` remain explicit. The observed corrected core7ad is recorded only as an observed identity for later actual gate binding, not an all-gates PASS. e193 successes and metadata failures remain historical; neither the precommit overlay frontier PASS nor e193's Lean PASS is projected onto7ad.

There is no new review wrapper or approval stage. Root reviews the concrete actual context under the existing requested flow, enables its separate exact execution grant only after real current-core gates, and uses the already-required new scoped OS approval. All other v1 guard requirements remain: real main95322 ancestry, exact34+8 expectations, preserved original proof/verifier/decoder/owner and ledger prefix, accepted real own-frontier projections, actual same-head gates/current build metadata, exact core/site pins and no concurrent site mutation. Root-only fields and future hashes are not invented here.

The new narrow command for that later approval is:

```text
/opt/anaconda3/bin/python .astis/huanjian-resume-20261103/run_check.py cosine-expansion-final-browser-v2 .astis/huanjian-gc-integration-20261105/browser-venv/bin/python .astis/huanjian-gc-fixed-spectrum-cosine-expansion-integration-20261109/independent-reader/browser-preparation-v2/check_final_reader_v2.py --authorization-json <ACTUAL_ROOT_AUTHORIZATION_PATH> --authorization-sha256 <ACTUAL_ROOT_AUTHORIZATION_SHA256>
```

The placeholders are unfilled documentation. No command/OS approval request, server, browser, build, API, shared write, stage or commit occurs in this preparation. Actual Chrome48 originals still require independent original-image viewing; script/DOM success is not pixel acceptance. Optimisation/Discrete/SLC–LSI outline regressions remain DOM-only, and own-site evidence does not accept external GitHub HTML, remote owner release, purification, park or either full main bound.
