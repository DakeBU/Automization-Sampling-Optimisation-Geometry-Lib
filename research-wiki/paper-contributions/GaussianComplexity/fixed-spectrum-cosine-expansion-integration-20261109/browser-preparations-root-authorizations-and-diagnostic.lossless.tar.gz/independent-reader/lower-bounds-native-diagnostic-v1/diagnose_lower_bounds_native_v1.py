"""DISABLED preparation: two-width Lower Bounds native selection diagnosis only; never geometry acceptance."""
import sys
sys.dont_write_bytecode = True
import argparse, ast, datetime, functools, hashlib, http.server, importlib.util, json, re, struct, subprocess, threading, time
from pathlib import Path
from urllib.parse import quote

ROOT=Path('/Users/zhouhuanjian/ASTIS-GC')
HERE=Path(__file__).resolve().parent
CORE='7ad39273de26a0ed0315db46be231b5585e26409'
IDENT='concept:lower'
QUERY='Lower Bounds'
NATIVE_GEOMETRY_JS = "args => {\n  const rect = r => ({left:r.left,right:r.right,top:r.top,bottom:r.bottom,width:r.width,height:r.height});\n  const selected = [...document.querySelectorAll('.ulg-node.selected')];\n  const node = selected.find(n => n.dataset.id === args.id);\n  const svg = document.querySelector('[data-graph-svg]');\n  const canvas = document.querySelector('[data-graph-canvas]');\n  const detail = document.querySelector('[data-graph-detail]');\n  const box = node?.querySelector(':scope > rect');\n  const label = node?.querySelector(':scope > text.label');\n  if (!node || !svg || !canvas || !detail || !box || !label) return null;\n  const mobile = document.querySelector('.mobile-bar');\n  const top = mobile && getComputedStyle(mobile).display !== 'none' ? Math.max(0,mobile.getBoundingClientRect().bottom) : 0;\n  const labelMatrix = label.getScreenCTM();\n  if (!labelMatrix) return null;\n  const font = parseFloat(getComputedStyle(label).fontSize) * Math.hypot(labelMatrix.a,labelMatrix.b);\n  const viewport = {left:0,right:innerWidth,top,bottom:innerHeight};\n  const s = rect(svg.getBoundingClientRect()), c = rect(canvas.getBoundingClientRect());\n  const r = rect(box.getBoundingClientRect()), l = rect(label.getBoundingClientRect());\n  const inside = (a,b) => a.left >= b.left-1 && a.right <= b.right+1 && a.top >= b.top-1 && a.bottom <= b.bottom+1;\n  const actualKind = detail.dataset.kind;\n  const actualLabel = detail.querySelector(':scope > header > h2')?.textContent;\n  const query = document.querySelector('[data-graph-search]')?.value.trim();\n  const checks = {\n    unique_selected:selected.length===1,\n    source_kind:actualKind===args.kind,\n    source_full_name:actualLabel===args.label,\n    expected_view:canvas.dataset.view===args.view,\n    nonempty_query:Boolean(query),\n    readable_card:r.width>=160 && r.height>=40,\n    readable_label:font>=10 && l.width>=80 && l.height>=10 && Boolean(label.textContent.trim()),\n    full_card_inside_svg:inside(r,s),full_card_inside_canvas:inside(r,c),full_card_inside_viewport:inside(r,viewport),\n    full_label_inside_svg:inside(l,s),full_label_inside_canvas:inside(l,c),full_label_inside_viewport:inside(l,viewport),\n    full_label_inside_card:inside(l,r)\n  };\n  return {id:args.id,expected_kind:args.kind,expected_label:args.label,actual_kind:actualKind,actual_label:actualLabel,\n    actual_view:canvas.dataset.view,query,viewport,svg:s,canvas:c,selected_main_rect:r,rendered_label:l,\n    rendered_label_font_px:font,rendered_label_text:label.textContent,checks,ok:Object.values(checks).every(Boolean)};\n}"
sha=lambda raw:hashlib.sha256(raw).hexdigest()
def readref(ref):
    assert isinstance(ref,dict) and set(ref)=={'path','sha256'}
    p=(ROOT/ref['path']).resolve();assert p.is_relative_to(ROOT) and re.fullmatch('[0-9a-f]{64}',ref['sha256'])
    raw=p.read_bytes();assert sha(raw)==ref['sha256'],ref['path'];return raw
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT)
def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--authorization-json',required=True);parser.add_argument('--authorization-sha256',required=True)
    args=parser.parse_args();authref={'path':args.authorization_json,'sha256':args.authorization_sha256}
    authorization=json.loads(readref(authref))
    # This new diagnostic requires its own exact root grant. The old actual v3
    # context below supplies immutable facts only, never execution authority.
    assert authorization['authorized_by']=='/root' and authorization['execute_diagnostic_authorized'] is True
    assert authorization['authorization_kind']=='cosine-expansion-lower-bounds-native-diagnostic-v1'
    assert authorization['diagnostic_script_sha256']==sha(Path(__file__).read_bytes())
    assert authorization['new_source_verdict'] is False and authorization['parking_authorized'] is False
    assert authorization['planned_original_PNGs']==2 and authorization['planned_postclick_geometry_reads']==6
    assert authorization['geometry_acceptance_authorized'] is False
    reference_checker=readref(authorization['reference_v3_checker'])
    common_raw=readref(authorization['reference_v3_common'])
    nodes=[n for n in ast.parse(reference_checker).body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='NATIVE_GEOMETRY_JS' for t in n.targets)]
    assert len(nodes)==1 and ast.literal_eval(nodes[0].value)==NATIVE_GEOMETRY_JS
    assert sha(NATIVE_GEOMETRY_JS.encode())==authorization['native_geometry_JS_value_sha256']
    actual=json.loads(readref(authorization['actual_v3_context']))
    assert actual['accepted_immutable_core']==CORE and actual['source_digest']==authorization['expected_source_digest']
    assert actual['browser_checker_sha256']==sha(reference_checker) and actual['browser_common_sha256']==sha(common_raw)
    failed=json.loads(readref(authorization['failed_v3_report']))
    receipt=json.loads(readref(authorization['failed_v3_receipt']))
    assert failed['status']=='failed' and failed['head']==CORE and len(failed['screenshots'])==21
    assert failed['authorization']==authorization['actual_v3_context']
    assert receipt['exit_code']==1 and receipt['head_before']==receipt['head_after']==CORE
    assert sha(readref(authorization['failed_v3_log']))==receipt['log_sha256']
    assert git('rev-parse','HEAD').decode().strip()==CORE and not git('status','--porcelain=v1','--untracked-files=no')
    # Import only the already frozen read-only common. Never import the v3
    # checker, whose top-level code would execute its full browser flow.
    spec=importlib.util.spec_from_file_location('existing_v3_common_for_lower_diagnostic',(ROOT/authorization['reference_v3_common']['path']))
    common=importlib.util.module_from_spec(spec);spec.loader.exec_module(common)
    guard=common.authorized_context(actual)
    assert guard['lifecycle_API_called'] is False and guard['new_source_verdict'] is False
    graph=json.loads((ROOT/'_site/data/underlying-lean-graph.json').read_bytes())
    node=next(n for n in graph['nodes'] if n['id']==IDENT)
    assert node['label']=='Lower Bounds' and node['kind']=='concept-domain' and node['url']=='lower-bounds/index.html'
    native_args={'id':IDENT,'kind':node['kind'],'label':node['label'],'view':'functor'}
    control_names=['runs/substantive_advances.jsonl','runs/substantive_discoveries.jsonl','research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-cosine-expansion.json','research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-cosine-expansion.json']
    controls={name:sha((ROOT/name).read_bytes()) for name in control_names}
    from playwright.sync_api import sync_playwright
    out=ROOT/'.astis/huanjian-gc-fixed-spectrum-cosine-expansion-integration-20261109/independent-reader/diagnostics'/('lower-bounds-native-'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ'))
    out.mkdir(parents=True,exist_ok=False)
    report={'mode':'Actual two-width native diagnosis only; no geometry PASS, full runtime or pixel acceptance','core':CORE,'authorization':authref,'actual_v3_context':authorization['actual_v3_context'],'failed_v3_report':authorization['failed_v3_report'],'failed_v3_receipt':authorization['failed_v3_receipt'],'read_only_actual_context_guard':guard,'native_geometry_JS_value_sha256':sha(NATIVE_GEOMETRY_JS.encode()),'target':native_args,'viewports':[],'screenshots':[],'page_errors':[],'geometry_acceptance':'NOT_DECIDED','full48_checker':'NOT_RERUN','camera_actions_by_harness':[],'new_source_verdict':False,'lifecycle_API_called':False,'external_GitHub_HTML_checked':False}
    class Quiet(http.server.SimpleHTTPRequestHandler):
        def log_message(self,*_):pass
    server=http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Quiet,directory=str(ROOT/'_site')))
    worker=threading.Thread(target=server.serve_forever,daemon=True);worker.start()
    base=f'http://127.0.0.1:{server.server_port}/'
    route='lean-foundations.html?view=functor&focus='+quote(IDENT,safe='')+'&q='+quote(QUERY,safe='')
    browser=None
    def save_original(page,row,width):
        name=f'lower-bounds-native-{width}.png';p=out/name
        page.screenshot(path=str(p));raw=p.read_bytes();assert raw[:8]==b'\x89PNG\r\n\x1a\n'
        w,h=struct.unpack('>II',raw[16:24]);assert (w,h)==(page.viewport_size['width'],page.viewport_size['height'])
        saved={'file':name,'sha256':sha(raw),'width':w,'height':h,'original_viewport_capture':True,'geometry_or_pixel_acceptance':False}
        report['screenshots'].append(saved);row['original']=saved
    def capture(page,row,phase,started):
        # No ok predicate is awaited or asserted. Preserve false/null/error data.
        entry={'phase':phase,'seconds_since_native_click':time.monotonic()-started}
        try:entry['geometry']=page.evaluate(NATIVE_GEOMETRY_JS,native_args)
        except Exception as error:entry['geometry']=None;entry['read_error']=repr(error)
        entry['page_url']=page.url
        row['postclick_reads'].append(entry)
    try:
        with sync_playwright() as playwright:
            browser=playwright.chromium.launch(headless=True,executable_path='/Applications/Google Chrome.app/Contents/MacOS/Google Chrome')
            report['browser_version']=browser.version
            for width,height in [(1440,1000),(390,844)]:
                context=None;page=None;row={'width':width,'height':height,'route':route,'postclick_reads':[],'native_click_completed':False}
                report['viewports'].append(row)
                try:
                    context=browser.new_context(viewport={'width':width,'height':height})
                    context.route(re.compile(r'https?://(?!127\.0\.0\.1:)'),lambda req:req.abort())
                    page=context.new_page();page.set_default_timeout(10000)
                    page.on('pageerror',lambda error:report['page_errors'].append(str(error)))
                    response=page.goto(base+route,wait_until='domcontentloaded');row['HTTP_status']=response.status
                    assert response.status==200
                    page.wait_for_selector('.ulg-canvas[data-view="functor"][data-local="true"]')
                    selected=page.locator('.ulg-node.selected[data-id="concept:lower"]');selected.wait_for()
                    page.wait_for_function("document.querySelector('.ulg-canvas>small').textContent.includes('Focused result at readable scale')")
                    page.wait_for_function('Boolean(window.MathJax?.startup?.promise)')
                    page.evaluate('() => MathJax.startup.promise')
                    page.locator('[data-graph-canvas]').scroll_into_view_if_needed()
                    row['before_click_selected_rect']=selected.locator(':scope > rect').bounding_box()
                    selected.click();row['native_click_completed']=True;started=time.monotonic()
                    capture(page,row,'immediate-after-native-click',started)
                    page.evaluate('() => new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(() => resolve(true))))')
                    capture(page,row,'after-two-queued-animation-frames',started)
                    page.wait_for_timeout(500)
                    capture(page,row,'after-additional-500ms',started)
                    row['document_overflow']=page.evaluate('document.documentElement.scrollWidth > innerWidth + 1')
                    row['MathJax_error_count']=page.locator('mjx-merror,[data-mjx-error]').count()
                except Exception as error:
                    row['diagnostic_error']=repr(error)
                finally:
                    # Save each actual viewport even when one or every check is
                    # false. One viewport error must not skip the other width.
                    if page is not None:
                        try:save_original(page,row,width)
                        except Exception as error:row['screenshot_error']=repr(error)
                    if context is not None:
                        try:context.close()
                        except Exception as error:row['context_cleanup_error']=repr(error)
            browser.close();browser=None
        assert git('rev-parse','HEAD').decode().strip()==CORE and not git('status','--porcelain=v1','--untracked-files=no')
        for name,digest in controls.items():assert sha((ROOT/name).read_bytes())==digest,name
        for name,digest in actual['actual_immutable_input_pins'].items():assert sha((ROOT/name).read_bytes())==digest,name
        for name,digest in actual['actual_site_input_pins'].items():assert sha((ROOT/name).read_bytes())==digest,name
        assert sha(Path(__file__).read_bytes())==authorization['diagnostic_script_sha256']
        assert sha((ROOT/authref['path']).read_bytes())==authref['sha256']
        report['status']='DIAGNOSTIC_CAPTURED' if len(report['screenshots'])==2 and all(len(v['postclick_reads'])==3 for v in report['viewports']) else 'DIAGNOSTIC_INCOMPLETE'
    except Exception as error:
        report['status']='DIAGNOSTIC_ERROR';report['failure']=repr(error);raise
    finally:
        if browser is not None:
            try:browser.close()
            except Exception as error:report['browser_cleanup_error']=repr(error)
        try:server.shutdown()
        finally:server.server_close();worker.join(timeout=5)
        (out/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
        print(json.dumps({'status':report.get('status'),'originals':len(report['screenshots']),'postclick_geometry_reads':sum(len(v['postclick_reads']) for v in report['viewports']),'geometry_acceptance':'NOT_DECIDED','report':str(out/'report.json')}))
if __name__=='__main__':main()
