from pathlib import Path
import hashlib, json
P = Path('.astis/huanjian-gc-fixed-spectrum-geometry-20261109')
seal = json.loads(Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-geometry-statement-seal.json').read_bytes())
candidate = P/'GeometryProof-v3.lean'
assert hashlib.sha256(candidate.read_bytes()).hexdigest() == 'bbfedf82b0d3ef965cfe982b0af22322043a2fc7f341f07a8bdb3edb2f6fc259'
prod = Path('AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumGeometry.lean')
test = Path('Tests/GaussianComplexityFixedSpectrumGeometry.lean')
assert not prod.exists() and not test.exists()
doc = '''/-!
# Actual fixed-spectrum potential geometry

Zhou--Suzuki arXiv:2610.20492v1, Eq.(11) and Appendix C.4.
The literal potential is globally smooth, with genuine constant Euclidean
Hessian, source strong-convexity/smoothness constants and unique minimizer0.

The implementation reuses the canonical actual precision bounds and actual
first-order identity. Strong convexity uses the existing quantitative-gradient
converse; the source author's Hessian route remains separately represented in
the source proof graph. The operator-norm estimate is a Euclidean Rayleigh
quotient bound, not an entrywise matrix norm. This declaration does not prove
an adaptive algorithm, query cap, TV/precision/cost transport or main lower bound.
-/

'''
raw = candidate.read_text()
marker = 'namespace AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumGeometry'
prod.write_text(raw.replace(marker, doc+marker, 1))
test_header = '''import AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumGeometry
import Mathlib.MeasureTheory.Constructions.BorelSpace.Basic

open Matrix InnerProductSpace
set_option autoImplicit false

/- The actual same-input exact reply is Borel for each fixed source O.
The new producer supplies scalar continuity and genuine gradient continuity;
the canonical actual first-order result identifies that gradient with the
literal precision reply. This is not a whole adaptive or joint-in-O theorem. -/
'''
body = '''  classical
  dsimp only
  let θ : Fin d → ℝ := fun i => ((i.val : ℝ) + 1 / 2) * Real.pi / (d : ℝ)
  let A : Matrix (Fin d) (Fin d) ℝ :=
    (O : Matrix (Fin d) (Fin d) ℝ) *
      Matrix.diagonal (fun i => (κ + 1) / 2 + (κ - 1) / 2 * Real.cos (θ i)) *
      (O : Matrix (Fin d) (Fin d) ℝ).transpose
  let E := EuclideanSpace ℝ (Fin d)
  let f : E → ℝ := fun x => (WithLp.ofLp x) ⬝ᵥ (A *ᵥ WithLp.ofLp x) / 2
  let query : E → E := fun x => WithLp.toLp 2 (A *ᵥ WithLp.ofLp x)
  have hgeometry := AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumGeometry.actual_potential_geometry hd hκ O
  have hcinfty : ContDiff ℝ ∞ f := hgeometry.1
  have hderivative (x : E) : HasFDerivAt (gradient f)
      (Matrix.toEuclideanCLM (𝕜 := ℝ) (n := Fin d) A) x := hgeometry.2.1 x
  have hscalar : Continuous f := hcinfty.continuous
  have hgradient : Continuous (gradient f) :=
    continuous_iff_continuousAt.mpr fun x => (hderivative x).continuousAt
  have hquery : query = gradient f := by
    funext x
    exact (AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumFirstOrder.actual_first_order_query hd hκ O x).1.gradient.symm
  change @Measurable E (ℝ × E) (borel E) (borel (ℝ × E)) (fun x => (f x, query x))
  rw [hquery]
  exact (hscalar.prodMk hgradient).borel_measurable

#check AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumGeometry.actual_potential_geometry
#print axioms AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumGeometry.actual_potential_geometry
#print axioms actual_first_order_oracle_measurable
'''
test.write_text(test_header+seal['private_actual_consumer']['signature'].rstrip()+' := by\n'+body)
print(json.dumps({'production': str(prod), 'production_raw_sha256': hashlib.sha256(prod.read_bytes()).hexdigest(),
    'Test': str(test), 'Test_raw_sha256': hashlib.sha256(test.read_bytes()).hexdigest(),
    'actual_canonical_build_yet': False, 'public_binders_or_definitions_changed': False}))
