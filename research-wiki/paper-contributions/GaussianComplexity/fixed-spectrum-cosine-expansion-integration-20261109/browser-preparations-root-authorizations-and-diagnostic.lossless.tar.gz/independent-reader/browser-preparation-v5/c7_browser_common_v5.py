"""UNEXECUTED C7 read-only guards. No browser/API grant is created by this module."""
import sys
sys.dont_write_bytecode=True
import argparse, ast, gzip, hashlib, json, re, subprocess
from pathlib import Path
R=Path('/Users/zhouhuanjian/ASTIS-GC')
S=R/'.astis/huanjian-gc-fixed-spectrum-cosine-expansion-integration-20261109/independent-reader/browser-preparation-v5'
Q=S.parent/'conditional-proposal-main95322-v2'
CANDIDATE='37645c774481c4cad19fc29bcaa76799da64db7d'
MAIN='95322cd2c762e5969c560815a803c4e15a424007'
ADV='ASTIS-SA-20261109-GaussianComplexityFixedSpectrumCosineExpansion'
OWNER='huanjian_gc_20261109_fixed_spectrum_cosine_expansion'
INTEGRATOR=OWNER+'_integration'
READER='/root/geometry_integration_reader'
DECODER='/root/decode_b4e6a1'
BINDING='8ddbbdb086becb57b2b8212154d9f607b121f7955cfcce132927210eaa04b95c'
DECL='AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumCosineExpansion.actual_inverse_spectrum_cosine_expansion'
AP='research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-cosine-expansion.json'
CP='research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-cosine-expansion.json'
LP='runs/substantive_advances.jsonl'
DP='runs/substantive_discoveries.jsonl'
README='research-wiki/paper-contributions/GaussianComplexity/README.md'
PROPOSAL_SHA='6dc1f5f6ae23b60723cc4ca5f52c3152a2a7bb37f64759d29d01ad8594a8bf2d'
MAIN_PLAN_SHA='c343c294bac4f6735b625789858fd62fe1973a5453ddd2124b6692215a8cd051'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=R)
def parse_args(doc):
 p=argparse.ArgumentParser(description=doc);p.add_argument('--authorization-json',required=True);p.add_argument('--authorization-sha256',required=True);return p.parse_args()
def readref(ref):
 assert isinstance(ref,dict) and set(ref)=={'path','sha256'}
 p=(R/ref['path']).resolve();assert p.is_relative_to(R) and re.fullmatch('[0-9a-f]{64}',ref['sha256'])
 raw=p.read_bytes();assert sha(raw)==ref['sha256'],ref['path'];return raw
def load_authorization(args):
 ref={'path':args.authorization_json,'sha256':args.authorization_sha256};a=json.loads(readref(ref))
 # Fail before importing Playwright or creating any server/output directory.
 assert a['execute_browser_authorized'] is True and a['authorized_by']=='/root'
 assert a['authorization_kind']=='fixed-spectrum-cosine-expansion-final-browser-v5'
 assert a['new_source_verdict'] is False and a['parking_authorized'] is False
 assert a['candidate_commit']==CANDIDATE and a['current_main_required_ancestor']==MAIN and a['publication_binding_sha256']==BINDING
 assert a['browser_checker_sha256']==sha((S/'check_final_reader_v5.py').read_bytes())
 assert a['browser_common_sha256']==sha(Path(__file__).read_bytes())
 assert a['reviewed_UI_repair'] is None
 assert a['planned_original_PNGs']==48 and a['planned_native_geometry_rows']==20 and a['planned_old_DensityAffinity_DOM_regressions']==2
 assert a['actual_facts_reviewed_by_root'] is True
 return a,ref
def diffpaths(a,b,path=''):
 if isinstance(a,dict) and isinstance(b,dict):
  out=[]
  for k in sorted(a.keys()|b.keys()):
   p=path+'/'+k.replace('~','~0').replace('/','~1');out+=diffpaths(a[k],b[k],p) if k in a and k in b else [p]
  return out
 if isinstance(a,list) and isinstance(b,list):
  out=[]
  for k in range(max(len(a),len(b))):out+=diffpaths(a[k],b[k],path+'/'+str(k)) if k<len(a) and k<len(b) else [path+'/'+str(k)]
  return out
 return [] if a==b else [path]
def replay(raw):
 tree=ast.parse((R/'tools/astis_advance.py').read_bytes());functions=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='_replay_advances'];assert len(functions)==1
 scope={'Iterable':list,'Any':object,'NO_PROGRESS_FREEZE_AT':3};exec(compile(ast.Module(body=functions,type_ignores=[]),'<pure-replay-no-tail-repair>','exec'),scope)
 return scope['_replay_advances']([json.loads(x) for x in raw.splitlines() if x.strip()])
def one_event(raw):
 assert raw.endswith(b'\n') and len(raw.splitlines())==1;return json.loads(raw)
def receipt(ref,core):
 obj=json.loads(readref(ref));assert obj['exit_code']==0 and obj['head_before']==obj['head_after']==core
 logpath=Path(obj['log']);logpath=logpath if logpath.is_absolute() else R/logpath
 assert logpath.resolve().is_relative_to(R)
 log=logpath.read_bytes();assert sha(log)==obj['log_sha256'];return obj,log
def authorized_context(a):
 core=a['accepted_immutable_core'];assert re.fullmatch('[0-9a-f]{40}',core) and core!=CANDIDATE
 assert git('rev-parse','HEAD').decode().strip()==core and not git('status','--porcelain=v1','--untracked-files=no')
 first=a['source_V_first_carrying_commit'];assert re.fullmatch('[0-9a-f]{40}',first)
 for ancestor in [CANDIDATE,MAIN,first]:subprocess.check_call(['git','merge-base','--is-ancestor',ancestor,core],cwd=R)
 proposal_raw=(Q/'stage-B/payload-manifest.json').read_bytes();assert sha(proposal_raw)==PROPOSAL_SHA==a['conditional_payload_manifest_sha256']
 main_raw=(Q/'stage-A/reconciliation-manifest.json').read_bytes();assert sha(main_raw)==MAIN_PLAN_SHA==a['conditional_main_reconciliation_manifest_sha256']
 proposal=json.loads(proposal_raw);main=json.loads(main_raw);assert len(proposal['rows'])==8 and len(main['rows'])==34
 afters={}
 for row in proposal['rows']:
  raw=(R/row['path']).read_bytes();expected=gzip.decompress((Q/row['after']['archive']).read_bytes())
  assert raw==expected and sha(raw)==row['after']['raw_sha256'] and git('show',core+':'+row['path'])==raw,row['path']
  afters[row['path']]=sha(raw)
 for row in main['rows']:
  if row['path'] in afters:continue
  raw=(R/row['path']).read_bytes();assert sha(raw)==row['expected_merged_raw_sha256'] and git('show',core+':'+row['path'])==raw,row['path']
 readme=(R/README).read_bytes();assert readme==git('show',first+':'+README)==git('show',core+':'+README)
 assert readme.endswith(git('show',CANDIDATE+':'+README))
 vraw=readref(a['source_V_append']);sraw=readref(a['STAB_append']);V=one_event(vraw);stab=one_event(sraw)
 verifier=a['source_verifier_to_preserve'];integrator=a['integration_owner'];assert integrator==INTEGRATOR
 assert verifier=='/root/cosine_fresh_source_5d8c2a'
 assert len({OWNER,DECODER,verifier,integrator,READER,'/root'})==6
 assert V['event']==stab['event']=='transition' and V['advance_id']==stab['advance_id']==ADV
 assert (V['from_state'],V['to_state'])==('PROVED_LOCAL','VERIFIED')
 assert (stab['from_state'],stab['to_state'])==('VERIFIED','STABILIZING')
 assert V['worker_id']==V['evidence']['verifier_id']==verifier and V['evidence']['verified_commit']==CANDIDATE
 assert all(V['evidence'][k] for k in ['gate','source_audit','fake_closure_scan'])
 assert stab['worker_id']==integrator and stab['evidence']['integration_owner']==integrator
 oldledger=git('show',CANDIDATE+':'+LP);now=(R/LP).read_bytes();assert now==oldledger+vraw+sraw
 assert git('show',first+':'+LP)==oldledger+vraw
 assert git('show',core+':'+LP)==now
 state=replay(now);oldstates=replay(oldledger)
 assert state[ADV]['state']=='STABILIZING' and [k for k,v in state.items() if v['state']=='STABILIZING']==[ADV]
 assert {k:v for k,v in state.items() if k!=ADV}=={k:v for k,v in oldstates.items() if k!=ADV}
 assert (R/DP).read_bytes()==git('show',CANDIDATE+':'+DP)==git('show',core+':'+DP)
 audit_raw=readref(a['accepted_source_audit']);audit=json.loads(audit_raw);assert a['accepted_source_audit']['path']==AP
 assert audit['state'] in {'source-reviewed','accepted'} and audit['source_review']['state']=='accepted' and audit['lean']['compiled'] is True
 assert audit['publication_binding_sha256']==BINDING and audit['lean']['declaration']==DECL
 assert audit['lean']['formalizer']==OWNER and audit['reconstruction']['decoder']==DECODER and audit['source_review']['reviewer']==verifier
 run=readref(a['source_review_run']);assert sha(run)==audit['source_review']['review_run_sha256']
 assert git('show',first+':'+AP)==audit_raw==git('show',core+':'+AP)==(R/AP).read_bytes()
 vreceipt=json.loads(readref(a['source_V_actual_receipt']));observation=json.loads(readref(a['source_V_API_observation']))
 assert vreceipt['normal_API_calls']==1 and vreceipt['worker_and_verifier']==verifier and vreceipt['actual_append_sha256']==sha(vraw) and vreceipt['checked_commit']==CANDIDATE
 assert vreceipt['owner_unchanged']==OWNER and vreceipt['raw_old_prefix_preserved'] is True
 assert observation['API_call_attempts']==1 and observation['API_exception'] is None and observation['old_prefix_preserved'] is True
 assert observation['before_ledger_sha256']==sha(oldledger) and observation['after_ledger_sha256']==sha(oldledger+vraw) and observation['observed_append_sha256']==sha(vraw)
 assert json.loads(readref(a['source_V_actual_call_evidence']))==V['evidence']
 assert V['evidence']['source_audit']['observed_accepted_audit']['sha256']==sha(audit_raw)
 assert V['evidence']['source_audit']['publication_binding_sha256']==BINDING and V['evidence']['source_audit']['review_run_sha256']==sha(run)
 assert gzip.decompress(readref(a['source_V_before_ledger_gzip']))==oldledger
 assert gzip.decompress(readref(a['source_V_after_ledger_gzip']))==oldledger+vraw
 stab_receipt_raw=readref(a['sole_STAB_actual_receipt']);stab_receipt=json.loads(stab_receipt_raw)
 assert stab_receipt['state']=='OBSERVED_ONE_NORMAL_SOLE_STAB' and stab_receipt['normal_API_calls']==1
 assert stab_receipt['actor']==integrator and stab_receipt['actual_append_sha256']==sha(sraw)
 assert stab_receipt['source_V_carrier']==first and stab_receipt['source_verifier_preserved']==verifier and stab_receipt['raw_old_prefix_preserved'] is True
 assert gzip.decompress(readref(a['before_STAB_ledger_gzip']))==oldledger+vraw
 assert gzip.decompress(readref(a['after_STAB_ledger_gzip']))==now
 # Actual payload script makes zero API calls. Its receipt is separate from
 # the already completed one-call sole-STAB receipt; no combined record is invented.
 application_raw=readref(a['eight_payload_application_receipt']);application=json.loads(application_raw)
 assert application['state']=='ACTUAL_REVIEWED_EIGHT_PAYLOADS_APPLIED' and application['actual_normal_API_calls_in_this_script']==0
 assert application['real_merge_HEAD']==MAIN and application['source_V_and_STAB_prefix_unchanged'] is True
 assert application['payloads']==[{'path':r['path'],'sha256':afters[r['path']]} for r in proposal['rows']]
 readback=json.loads(readref(a['independent_actual_application_readback']))
 assert readback['reviewer']==READER and readback['verdict']=='ACCEPT_EXACT_ACTUAL_C7_APPLICATION_READBACK'
 assert readback['candidate_commit']==CANDIDATE and readback['actual_application_receipt_sha256']==sha(application_raw)
 assert readback['actual_sole_STAB_receipt_sha256']==sha(stab_receipt_raw)
 assert readback['source_V_append_sha256']==sha(vraw) and readback['STAB_append_sha256']==sha(sraw)
 assert readback['payload_manifest_sha256']==PROPOSAL_SHA and readback['shared_after_hashes']==afters
 assert readback['foreign_raw_states_frontiers_and_candidate_prefix_preserved'] is True and readback['new_mathematical_or_source_verdict'] is False
 oldcell=git('show',CANDIDATE+':'+CP);vcell=git('show',first+':'+CP);cell=readref(a['own_frontier_current']);assert a['own_frontier_current']['path']==CP
 assert (R/CP).read_bytes()==cell==git('show',core+':'+CP)
 if oldcell!=vcell:
  review=json.loads(readref(a['source_V_own_frontier_projection_review']))
  assert review['reviewer']==READER and review['verdict']=='ACCEPT_EXACT_MECHANICAL_SOURCE_V_PROJECTION'
  assert review['candidate_commit']==CANDIDATE and review['source_V_append_sha256']==sha(vraw)
  assert review['before_sha256']==sha(oldcell) and review['after_sha256']==sha(vcell)
  assert review['new_mathematical_or_source_verdict'] is False and review['changed_json_paths']==diffpaths(json.loads(oldcell),json.loads(vcell))
 else:assert a['source_V_own_frontier_projection_review'] is None
 projection=json.loads(readref(a['integration_own_frontier_projection_review']))
 assert projection['reviewer']==READER and projection['verdict']=='ACCEPT_EXACT_MECHANICAL_C7_INTEGRATION_PROJECTION'
 assert projection['candidate_commit']==CANDIDATE and projection['before_sha256']==sha(vcell) and projection['after_sha256']==sha(cell)
 assert projection['source_V_append_sha256']==sha(vraw) and projection['STAB_append_sha256']==sha(sraw)
 assert projection['new_mathematical_or_source_verdict'] is False
 assert diffpaths(json.loads(vcell),json.loads(cell))==projection['changed_json_paths']==['/evidence/canonical_integration','/evidence/independent_verification','/graph_contribution/functor_view']
 assert application['frontier_before_sha256']==sha(vcell)
 old_obj=json.loads(vcell);current_obj=json.loads(cell)
 assert old_obj['graph_contribution']['functor_view']=='candidate-published' and current_obj['graph_contribution']['functor_view']=='stabilized'
 # The real initial payload receipt is historical and retains its pre-adapter
 # own-cell hash. Reconstruct that exact state; never relabel it as the fix.
 initial_payload_obj=json.loads(cell);initial_payload_obj['evidence']['independent_verification']=old_obj['evidence']['independent_verification']
 initial_payload_raw=(json.dumps(initial_payload_obj,ensure_ascii=False,indent=2)+'\n').encode()
 assert sha(initial_payload_raw)==application['frontier_after_sha256']
 adapter_raw=readref(a['independent_verification_string_adapter_proposal']);adapter=json.loads(adapter_raw)
 assert adapter['state']=='UNAPPLIED_PROPOSAL_ONLY' and adapter['changed_json_paths']==['/evidence/independent_verification']
 assert adapter['before_sha256']==sha(initial_payload_raw) and adapter['after_sha256']==sha(cell)
 assert isinstance(current_obj['evidence']['independent_verification'],str) and current_obj['evidence']['independent_verification'].strip()
 assert current_obj['evidence']['independent_verification']==adapter['replacement_factual_string']
 assert adapter['evidence_only_schema_change_no_mathematical_or_source_verdict'] is True
 actual_adapter_raw=readref(a['string_adapter_actual_receipt']);actual_adapter=json.loads(actual_adapter_raw)
 assert actual_adapter['normal_API_calls']==0 and actual_adapter['proposal_sha256']==sha(adapter_raw)
 assert actual_adapter['before_sha256']==sha(initial_payload_raw) and actual_adapter['after_sha256']==sha(cell)
 assert actual_adapter['original_verifier_event_and_sourceV_unchanged'] is True and actual_adapter['new_mathematical_or_source_verdict'] is False
 adapter_review=json.loads(readref(a['independent_string_adapter_actual_readback']))
 assert adapter_review['reviewer']==READER and adapter_review['verdict']=='ACCEPT_EXACT_ACTUAL_C7_SCHEMA_ONLY_ADAPTER_READBACK'
 assert adapter_review['actual_application_receipt_sha256']==sha(actual_adapter_raw) and adapter_review['proposal_sha256']==sha(adapter_raw)
 assert adapter_review['before_sha256']==sha(initial_payload_raw) and adapter_review['after_sha256']==sha(cell)
 assert adapter_review['new_mathematical_or_source_verdict'] is False
 # Actual post-fix independent projection acceptance is required above. The
 # proposal itself remains an unapplied historical preparation record.
 restored=json.loads(cell);restored['evidence'].pop('canonical_integration');restored['graph_contribution']['functor_view']='candidate-published'
 restored['evidence']['independent_verification']=old_obj['evidence']['independent_verification']
 assert (json.dumps(restored,ensure_ascii=False,indent=2)+'\n').encode()==vcell
 assert projection['inverse_restores_exact_raw_bytes'] is True
 for key in ['cell_id','advance_id','owner_id','target_statement','source_anchor','parents','statement_seal','source_proof_coverage']:
  if key in json.loads(oldcell):
   # Seal/coverage source-review metadata can change only under the exact
   # separately accepted sourceV projection above; integration retains it all.
   assert json.loads(vcell)[key]==json.loads(cell)[key]
   if key not in ['statement_seal','source_proof_coverage']:assert json.loads(oldcell)[key]==json.loads(cell)[key]
 roles={'canonical_lean','publication','contributor','semantic','frontier','site_build','site_check','graph_check'};assert set(a['actual_checks_before_browser'])==roles
 needles={'publication':'astis_publication.py','contributor':'astis_contributor_contract.py','semantic':'astis_semantic_roundtrip.py','frontier':'astis_frontier_cells.py','site_build':'build_site.py','site_check':'check_site.py','graph_check':'graph-check'}
 for role,ref in a['actual_checks_before_browser'].items():
  obj,log=receipt(ref,core)
  if role=='canonical_lean':assert log.decode().splitlines().count('ASTIS check passed')==1 and obj['command'][1:] in [['tools/astis.py','check'],['website/scripts/lean_gate.py']]
  else:assert needles[role] in str(obj['command'])
 subject_tests,_=receipt(a['actual_subject_reader_focused_tests'],core)
 for name in ['test_subject_readers','test_lower_bounds','test_samplewiki_navigation','test_samplewiki_companions','test_discrete_sampling']:assert name in str(subject_tests['command'])
 gate=json.loads(readref(a['actual_gate']));meta=json.loads(readref(a['site_metadata']))
 assert a['actual_gate']['path']=='.astis/site-lean-gate.json' and a['site_metadata']['path']=='_site/data/build-metadata.json'
 assert gate['passed'] and meta['gate']['passed'] and meta['gate']['current']
 assert gate['commit']==meta['git']['commit']==core and gate['source_digest']==meta['source_digest']==a['source_digest']
 for name,expected in a['actual_immutable_input_pins'].items():
  raw=(R/name).read_bytes();assert sha(raw)==expected and git('show',core+':'+name)==raw,name
 required_site={'_site/data/build-metadata.json','_site/data/declaration-exposition.json','_site/data/site-data.json','_site/data/underlying-lean-graph.json','_site/assets/information-architecture.css','_site/assets/underlying-lean-graph.js','_site/assets/subject-readers.css'}
 assert required_site<=set(a['actual_site_input_pins'])
 for name,expected in a['actual_site_input_pins'].items():
  assert name.startswith('_site/') and re.fullmatch('[0-9a-f]{64}',expected)
  assert sha((R/name).read_bytes())==expected,name
 assert git('rev-parse','HEAD').decode().strip()==core and not git('status','--porcelain=v1','--untracked-files=no')
 return {'actual_sourceV_and_sole_STAB_checked':True,'original_source_verifier':verifier,'source_V_append_sha256':sha(vraw),'STAB_append_sha256':sha(sraw),'source_V_first_carrying_commit':first,'actual_immutable_core':core,'real_main95322_ancestor_checked':True,'exact8_payloads_and_main34_expectations_checked':True,'candidate_prefix_and_all_foreign_SAU_states_preserved':True,'discovery_ledger_candidate_bytes_preserved':True,'actual_independent_application_readback_bound':True,'accepted_source_audit_run_and_exact_own_cell_projections_bound':True,'actual8_core_gate_receipts_and_subject_tests_checked':True,'new_source_verdict':False,'lifecycle_API_called':False,'browser_pixels_accepted_by_guard':False}
