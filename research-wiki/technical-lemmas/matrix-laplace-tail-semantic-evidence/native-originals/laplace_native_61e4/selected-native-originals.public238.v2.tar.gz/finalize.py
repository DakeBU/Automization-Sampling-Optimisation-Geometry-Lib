"""Derive the audit conclusion from this role's own real evidence leaves only."""
import ast
from collections import deque
import json
import re
from native_common import *

def path_between(graph, start, end, value_only=False):
    queue = deque([(start,[])])
    seen = set()
    while queue:
        current,path = queue.popleft()
        if current == end: return path
        if current in seen: continue
        seen.add(current)
        for field in (['value_dependencies'] if value_only else ['type_dependencies','value_dependencies']):
            for dep in graph[current][field]:
                if dep not in seen:
                    queue.append((dep,path+[{'consumer':current,'ingredient':dep,'kind':field}]))
    return None

def main():
    assert json.loads((OWN/'native-sequence-completed.json').read_text())['successor_commands_all_exit_zero']
    closure = json.loads((OWN/'actual-import-closure.json').read_text())
    summary = json.loads((OWN/'native-raw-roundtrip/native-kernel-summary.json').read_text())
    recursive = json.loads((OWN/'complete-transitive-type-value-graph.json').read_text())
    assert summary['pinned_candidate'] == recursive['candidate_commit'] == COMMIT
    graph = {r['name']:r for r in recursive['declarations']}
    assert len(graph) == len(recursive['declarations'])
    for r in graph.values():
        assert all(d in graph for d in r['type_dependencies']+r['value_dependencies'])
    assert sorted(r['name'] for r in graph.values() if r['is_axiom']) == ['Classical.choice','Quot.sound','propext']
    assert not any(r['is_unsafe'] for r in graph.values())
    raw_records, raws = {}, []
    for module in closure['topological_order']+['NativeLiteralApplications']:
        data = json.loads((OWN/'native-raw-roundtrip'/(module+'.json')).read_text())
        assert data['module'] == module
        assert data['constNames'] == [r['name'] for r in data['declarations']]
        if module != 'NativeLiteralApplications':
            assert not data['extraConstNames']
            module_source = next(r for r in closure['modules'] if r['module']==module)
            assert [m for m in data['imports'] if m.startswith(('AutoSamplingTheory','Tests'))] == module_source['actual_ASTIS_imports']
        for row in data['declarations']:
            assert row['kernel_type_checked'] and row['kernel_value_checked']
            assert not row['unsafe']
            assert set(row['axioms']) <= {'propext','Classical.choice','Quot.sound'}
            raw_records[row['name']] = row
        raws.append({'module':module,'declarations':len(data['declarations']),'expression_nodes':len(data['expression_nodes']),'extra_names':data['extraConstNames']})
    project_graph = {n:r for n,r in graph.items() if (r['first_owner'] or '').startswith(('AutoSamplingTheory','Tests'))}
    assert all(n in raw_records for n in project_graph)
    assert {r['first_owner'] for r in project_graph.values()} <= set(closure['topological_order'])
    p,t = recursive['roots']
    assert t.startswith('_private.Tests.GaussianComplexityLaplaceTail.')
    expected = [
      'AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumSourceMatrixStructure.actual_source_centered_matrix_structure',
      'AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumSourceMatrixRadius.actual_source_truncated_matrix_norm_bounds',
      p]
    witnesses = []
    for parent in expected:
        witness = path_between(graph,t,parent,True)
        assert witness and len(witness)==1
        witnesses.append({'root':t,'actual_parent':parent,'value_dependency_path':witness,'import_is_not_used_as_dependency_evidence':True})
    inherited = [n for n in project_graph if n not in [p,t] and not n.startswith('_private') and not any(z in n for z in ['._proof_', '._simp_'])]
    all_project_paths = []
    for n in sorted(project_graph):
        witness = path_between(graph,t,n)
        if witness is not None:
            all_project_paths.append({'name':n,'first_owner':graph[n]['first_owner'],'path':witness})
    write_json(OWN/'actual-canonical-parent-witnesses.v1.json',{'candidate_commit':COMMIT,'roots':recursive['roots'],'direct_actual_T_parents':witnesses,'all_reachable_ASTIS_declarations':all_project_paths,'module_imports_do_not_prove_parent_edges':True})
    # Use the frozen canonical policy's exact pattern and comment/string stripper.
    policy = (CAND/'tools/astis.py').read_text()
    tree = ast.parse(policy)
    nodes = [n for n in tree.body if (isinstance(n,ast.Assign) and any(isinstance(x,ast.Name) and x.id=='FORBIDDEN_REGEX' for x in n.targets)) or (isinstance(n,ast.FunctionDef) and n.name=='strip_lean_comments_and_strings')]
    assert len(nodes)==2
    namespace = {'re':re}
    exec(compile(ast.Module(body=nodes,type_ignores=[]),'<immutable canonical fake-closure scan policy>','exec'),namespace)
    scans=[]
    for module in closure['modules']:
        path = CAND/module['path']
        assert file_sha(path)==module['sha256']
        stripped = namespace['strip_lean_comments_and_strings'](path.read_text())
        hits = [{'line':i,'text':line} for i,line in enumerate(stripped.splitlines(),1) if namespace['FORBIDDEN_REGEX'].search(line)]
        assert not hits,(module['path'],hits)
        scans.append({'module':module['module'],'source_sha256':module['sha256'],'lines':len(stripped.splitlines()),'fake_closure_hits':hits})
    write_json(OWN/'fake-closure-scan.v1.json',{'candidate_commit':COMMIT,'policy_source_sha256':file_sha(CAND/'tools/astis.py'),'canonical_pattern':namespace['FORBIDDEN_REGEX'].pattern,'scope':'all 11 actual ASTIS/Tests source import-closure modules at immutable commit; no claim of whole-repository gate','modules':scans,'passed':True})
    receipts=[]
    for path in sorted((OWN/'command-receipts').glob('*.receipt.json')):
        r=json.loads(path.read_text())
        for stream in ['stdout','stderr']:
            assert file_sha(OWN/r[stream]['path'])==r[stream]['sha256']
        receipts.append((path,r))
    success = {r['label']:r for _,r in receipts if r['exit_code']==0}
    for name in ['lean-version']+[f'build-{i:02d}' for i in range(11)]+['literal-applications-v2','raw-kernel-audit-v2','complete-transitive-type-value-graph']:
        assert name in success,name
    version=(OWN/success['lean-version']['stdout']['path']).read_text().strip()
    assert 'version 4.33.0' in version
    upstream=json.loads((OWN/'verified-package-inputs.json').read_text())
    project_raw=[r for r in raws if r['module']!='NativeLiteralApplications']
    report={
      'schema':'independent-immutable-laplace-native-mathematics-audit-v1',
      'status':'NATIVE_AUDIT_PASSED_FOR_ASSIGNED_COMMIT;NOT_A_VERIFIED_TRANSITION',
      'candidate_commit':COMMIT,'candidate_tree':closure['candidate_tree'],
      'lean_version_actual':version,'lean_toolchain_sha256':file_sha(CAND/'lean-toolchain'),'lake_manifest_sha256':file_sha(CAND/'lake-manifest.json'),
      'P':{'module':closure['P'],'source_sha256':closure['modules'][0]['sha256'],'actual_declaration':p,'full_actual_value_kernel_checked_against_sealed_literal_type':True,'nonempty_finite_real_matrix':True,'AE_Hermitian_and_AE_strong_measurability_only_analytic_binders':True,'extended_nonnegative_trace_expectation':'lintegral; infinite expectation allowed; no Bochner MGF existence claimed'},
      'T':{'module':closure['T'],'source_sha256':closure['modules'][-1]['sha256'],'actual_declaration':t,'private':True,'full_actual_value_kernel_checked_against_sealed_literal_type':True,'external_substantive_assumption':'2*q+1<d only','four_families':['ordinary positive','ordinary negative','cosine positive','cosine negative'],'genuine_model':'product of q+1 standard Gaussians in real Euclidean Fin d; original cutoff Y, actual Bochner mean, Z=Y-mean; pair-index matrix carrier','Bochner_trace_integrability':'proved inside actual T from actual radius and structure parents, not supplied as a new binder','boundary_applications':['q=0 for every d>1','q=0,d=2','all four Bool cases at q=0,d=2'],'separate_family_application_values_kernel_checked':True},
      'independent_source_rebuild':{'ASTIS_modules':len(project_raw),'all_actual_ASTIS_import_closure':True,'old_ASTIS_olean_reused':False,'all_pinned_source_compiles_exit_zero':True,'debug_skipKernelTC':False,'honest_scope':'only P/T full actual ASTIS dependency closure, not root Tests or whole-repository build'},
      'upstream_readonly_reuse':{'packages':len(upstream['packages']),'artifact_files_rehashed':sum(x['files'] for x in upstream['packages']),'artifact_bytes_rehashed':sum(x['bytes'] for x in upstream['packages']),'source_revisions_match_manifest_and_tracked_clean':True,'upstream_recompiled':False,'Cli_has_no_artifact_files_in_reused_cache':True},
      'raw_type_value_DAG':{'ASTIS_modules':len(project_raw),'ASTIS_raw_declarations':sum(x['declarations'] for x in project_raw),'ASTIS_checked_values':sum(x['declarations'] for x in project_raw),'ASTIS_expression_nodes':sum(x['expression_nodes'] for x in project_raw),'all_ASTIS_extraConstNames_empty':True,'harness_raw_declarations':raws[-1]['declarations'],'full_raw_JSON_structural_roundtrip':True,'decoded_type_and_value_kernel_rechecked':True,'ASTIS_module_import_membership_crosscheck':True},
      'complete_recursive_constant_dependency_graph':{'roots':[p,t],'declarations':len(graph),'type_edges':sum(len(x['type_dependencies']) for x in graph.values()),'value_edges':sum(len(x['value_dependencies']) for x in graph.values()),'all_references_resolved':True,'reachable_ASTIS_declarations':len(project_graph),'all_reachable_ASTIS_values_covered_by_fresh_raw_module_checks':True,'upstream_full_constant_edges_traversed_from_pinned_cached_values':True},
      'axioms':['Classical.choice','Quot.sound','propext'],'sorryAx_or_unauthorized_axiom':False,'unsafe_in_complete_target_dependency_closure':False,'canonical_fake_closure_scan':'PASS all 11 immutable source closure modules',
      'retained_failure':{'command':'literal-applications','exit_code':1,'classification':'IMPLEMENTATION_FAILED in private audit harness only','reason':'intro traversed leading let-chain and bound D:Type as scalar s in four specialization tests','repair':'successor harness zeta-reduces let-chain with dsimp only before intro; no production source changed','successful_successor':'literal-applications-v2'},
      'truth_boundary':'Native mathematical/type/value/dependency audit only. No paper-source search or independent source-fidelity verdict, normal V/API call, publication/graph/ledger update, proof repair, whole-Bernstein/Lieb/master-tail/C6/main theorem or whole-Goal completion.',
      'private_workspace_guards':'kept separate and excluded from selected-originals manifest; do not publish workspace paths or guards'
    }
    write_json(OWN/'native-mathematics-report.v1.json',report)
    notes = {
      'candidate_commit':COMMIT,
      'scope':'Independent inspection of actual native Lean statements/proof values and inherited actual-model parents; no paper-source fidelity verdict.',
      'P_mathematical_route':[
        {'step':'trace_exp_eq_sum','inspection':'Real Hermitian CFC diagonalization plus trace cyclicity gives the unnormalized sum of exp(s*eigenvalues).'},
        {'step':'exp_max_eigenvalue_le_trace_exp','inspection':'Nonempty finite index makes the real spectrum a nonempty finite eigenvalue range; its maximum is one eigenvalue. Its positive exponential is bounded by the sum of all positive terms.'},
        {'step':'measurable_Markov_function','inspection':'F=ofReal(trace(exp(sX))) is AE measurable by continuity of matrix exponential and finite-dimensional linear trace, composed with the supplied AEStronglyMeasurable X.'},
        {'step':'tail_inclusion','inspection':'For s>0, t≤lambda_max(X) implies exp(st)≤trace(exp(sX)) on the AE Hermitian set; measure_mono_ae handles the exceptional null set.'},
        {'step':'extended_Markov_and_infimum','inspection':'The threshold ofReal(exp(st)) is strictly positive and finite; ENNReal division becomes exp(-st) multiplication. No finite trace expectation or Bochner MGF is assumed. The inequality is proved for every positive s, then le_iInf gives the sealed conclusion.'}
      ],
      'T_mathematical_route':[
        {'step':'actual_model','inspection':'The literal let-chain fixes independent standard Gaussian input vectors, original cutoff rank-one Kronecker Y, its actual Bochner mean, centered Z, ordinary/cosine weights and both global signs. The kernel checks actual T against that complete chain.'},
        {'step':'structure_parent','inspection':'The exact actual_source_centered_matrix_structure theorem is applied at hq; its measurability and pointwise Hermiticity outputs are used. Independence, integrability of Z and zero mean are internally available but are not new T binders.'},
        {'step':'radius_parent','inspection':'The exact actual_source_truncated_matrix_norm_bounds theorem gives ||Y||≤2rL/d and ||mean||≤2r/d. Triangle inequality yields ||Z||≤rho=2r(L+1)/d; cosine weights have norm≤1 and signs norm=1, so ||S||≤d*rho.'},
        {'step':'matrix_exponential_integrability','inspection':'Hermitian CFC bounds ||exp(sS)|| by exp(s*d*rho). Measurability plus this finite constant on the genuine probability law gives matrix exponential Bochner integrability internally.'},
        {'step':'trace_and_conversion','inspection':'Continuous linear trace preserves integrability; CFC positivity gives nonnegative trace. The actual generic P is instantiated, iInf_le selects s, and ofReal_integral_eq_lintegral_ofReal converts extended expectation to the sealed finite scalar Bochner trace integral.'}
      ],
      'boundary_and_definition_findings':[
        'hq implies d≥2 and allows q=0; r=q+1 stays positive. Actual q=0 for every d>1 and q=0,d=2 proof applications pass the kernel.',
        'Both switches are universally quantified in actual T. Separate ordinary± and cosine± exact-let applications at q=0,d=2 pass the kernel.',
        'The matrix index is Fin(q+1)×Fin(q+1), hence matrix dimension (q+1)^2; trace is unnormalized.',
        'The tail is for the algebraic largest eigenvalue with a non-strict ≥ threshold. Negative S is a separate family; no operator-norm or union-bound conclusion is claimed.',
        'Finite trace-exponential integrability is a dependency discharged in T, rather than an added hypothesis. P retains the extended expectation domain, including infinite expectations.',
        'No Bernstein MGF, Lieb, independent-sum product estimate or final Bernstein concentration theorem appears among the new target claims.'
      ],
      'finding':'No native mathematical/type/value/dependency defect found within the assigned immutable scope.'
    }
    write_json(OWN/'native-mathematical-inspection.v1.json',notes)
    # Workspace and package locations are private operational guards, never public evidence.
    write_json(OWN/'private-workspace-guards.json',{'private_do_not_publish':True,'owned_root':str(OWN),'upstream_roots':[x['effective_lean_path'] for x in upstream['packages']],'production_or_ledger_or_git_mutation_performed':False,'normal_API_calls':0})
    selected=[OWN/n for n in ['native-mathematics-report.v1.json','native-mathematical-inspection.v1.json','actual-import-closure.json','actual-canonical-parent-witnesses.v1.json','fake-closure-scan.v1.json','literal-source-interface.json','complete-transitive-type-value-graph.json','native-sequence-completed.json','native-raw-roundtrip/native-kernel-summary.json']]
    selected += [OWN/'native-raw-roundtrip'/(m+'.json') for m in closure['topological_order']+['NativeLiteralApplications']]
    selected += [CAND/row['path'] for row in closure['modules']]
    selected += [OWN/'immutable-inputs'/n for n in ['statement-seal.sealed.v1.json','P.proposition.sealed.v1.txt','T.proposition.sealed.v1.txt','binder-definition-audit.sealed.v1.json']]
    selected += [CAND/n for n in ['lean-toolchain','lake-manifest.json','lakefile.lean']]
    selected += [OWN/n for n in ['native_common.py','prepare.py','freeze.py','run_native.py','run_successor.py','finalize.py','native-command-assignment.json','native-successor-assignment.json','native-commands.json','native-successor-commands.json','native-output-initialized.json','mechanism-provenance.json','verified-package-inputs.json']]
    selected += [OWN/sub/n for sub in ['harness','harness-v2'] for n in ['NativeLiteralApplications.lean','NativeAudit.lean']]
    selected += [OWN/'harness-v2/NativeTransitiveGraph.lean']
    for path,r in receipts:
        selected += [path,OWN/r['stdout']['path'],OWN/r['stderr']['path']]
    assert len({str(p) for p in selected})==len(selected)
    leaves=[]
    for path in selected:
        assert path.is_file() and path.resolve().is_relative_to(OWN)
        assert path.name!='private-workspace-guards.json'
        leaves.append({'path':str(path.relative_to(OWN)),'sha256':file_sha(path),'bytes':path.stat().st_size})
    write_json(OWN/'selected-originals.manifest.v1.json',{'candidate_commit':COMMIT,'schema':'explicit-own-evidence-leaves-only-v1','private_workspace_guards_excluded':True,'no_external_evidence_leaf_or_glob':True,'public_release_requires_sanitizing_private_command_environment_paths':True,'leaves':leaves})
    print(json.dumps({'native_audit_passed':True,'ASTIS_modules':len(project_raw),'ASTIS_raw_declarations':report['raw_type_value_DAG']['ASTIS_raw_declarations'],'complete_dependency_declarations':len(graph),'selected_evidence_leaves':len(leaves)}))

if __name__ == '__main__': main()
