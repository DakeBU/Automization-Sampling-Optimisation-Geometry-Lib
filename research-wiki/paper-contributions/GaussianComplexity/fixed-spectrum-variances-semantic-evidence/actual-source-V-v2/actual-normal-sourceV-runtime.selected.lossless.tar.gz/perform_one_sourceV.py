from pathlib import Path
import os,sys,json,hashlib,subprocess,datetime,traceback

os.environ['PYTHONDONTWRITEBYTECODE']='1'
sys.dont_write_bytecode=True
ROOT=Path('/Users/zhouhuanjian/ASTIS-GC')
OUT=Path(__file__).resolve().parent
BASE=OUT.parent
sys.path.insert(0,str(ROOT))
from tools import astis_advance as advance
from tools import astis_frontier_cells as frontier

ACTOR='/root/source_reader_c24a61'
SAU='ASTIS-SA-20261110-GaussianComplexityFixedSpectrumVariances'
DECL='AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumVariances.actual_diagonal_gaussian_quadratic_variances'
HEAD='93d302689aaaebe28dcbe39b155d2168f269a7c8'
CELL='research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-variances.json'
LEDGER=ROOT/'runs/substantive_advances.jsonl'
NATIVE=ROOT/'.astis/semantic-neutral-20261110/module_f35b7d'
sha=lambda b:hashlib.sha256(b).hexdigest()
canonical=lambda x:sha(json.dumps(x,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode())
def get(path):return json.loads(path.read_text())
def put(name,value):
    b=(json.dumps(value,indent=2,ensure_ascii=False)+'\n').encode()
    (OUT/name).write_bytes(b)
    return sha(b)
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()

command=[sys.executable,str(Path(__file__).relative_to(ROOT))]
result={'command':command,'cwd':str(ROOT),'start_utc':utc(),'actor':ACTOR,'advance_id':SAU,
        'normal_call_attempted':False,'normal_call_count':0,'frontier_updated':False,
        'native_rerun_by_actor':False,'fresh_native93_claimed':False}
try:
    assert not (OUT/'normal-call-attempted.json').exists(), 'Normal call already attempted; no retry permitted'
    preflight=get(OUT/'preflight-result.json')
    assert preflight['status']=='PASS' and preflight['exit_code']==0
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip()==HEAD
    before=(OUT/'ledger-before.raw.jsonl').read_bytes()
    assert LEDGER.read_bytes()==before, 'Ledger changed after preflight: do not call'
    states_before=get(OUT/'all-SAU-states-before.json')
    assert states_before[SAU]['state']=='PROVED_LOCAL'
    assert states_before[SAU]['owner_id']!=ACTOR
    frontiers_before=get(OUT/'all-frontiers-before.inventory.json')
    protected_before=get(OUT/'protected-models-Registry-imports-before.json')
    for row in frontiers_before+protected_before:
        assert sha((ROOT/row['path']).read_bytes())==row['sha256'], 'Protected bytes changed after preflight: '+row['path']
    assert (ROOT/'runs/substantive_discoveries.jsonl').read_bytes()==(OUT/'discovery-ledger-before.raw.jsonl').read_bytes()
    assert sha((BASE/'execution-binding/FREEZE.json').read_bytes())=='9a992aa7bcde868dfc1947f62991ac80bd3e029391ef3d94376b01e479b38d04'
    accepted=get(BASE/'execution-binding/canonical-audit-validation.json')
    actual_audit=(ROOT/accepted['audit_path']).read_bytes()
    assert sha(actual_audit)==accepted['current_raw_sha256']
    audit=json.loads(actual_audit)
    assert audit['source_review']['reviewer']==ACTOR
    assert audit['source_review']['state']=='accepted'
    assert audit['state']=='source-reviewed'

    native=get(BASE/'execution-binding/execution-evidence-binding.json')
    labels=get(NATIVE/'check-report.json')['checks']['final_compile_receipts']
    native_receipts=[]
    for label in labels:
        path=NATIVE/(label+'.receipt.json');rc=get(path)
        assert rc['exit_code']==0
        native_receipts.append({'path':path.relative_to(ROOT).as_posix(),
                                'receipt_sha256':sha(path.read_bytes()),
                                'stdout_sha256':rc['stdout_sha256'],
                                'stderr_sha256':rc['stderr_sha256'],
                                'start_utc':rc['start_utc'],'end_utc':rc['end_utc'],'exit_code':rc['exit_code']})
    assert len(native_receipts)==8
    lexical=(NATIVE/'lexical-inventory.json').read_bytes()
    (OUT/'completed-native-lexical-inventory.json').write_bytes(lexical)
    evidence={
      'gate':{
        'current_sourceV_preflight':'PASS: reviewed publication/semantic gate for the exact target; no native/build rerun',
        'preflight_artifact':str((OUT/'preflight-result.json').relative_to(ROOT)),
        'preflight_raw_sha256':sha((OUT/'preflight-result.json').read_bytes()),
        'current_four_metadata_gates':get(BASE/'execution-binding/validated-current-four-gates.json'),
        'scope':'Normal independent source VERIFIED for this bounded SAU only; focused exact native evidence is separately bound from f35b7d.'},
      'verifier_id':ACTOR,
      'verified_commit':HEAD,
      'source_audit':{
        'audit_id':audit['id'],'audit_path':accepted['audit_path'],
        'current_audit_raw_sha256':accepted['current_raw_sha256'],
        'current_audit_canonical_sha256':accepted['current_canonical_sha256'],
        'canonical_reviewer_packet_sha256':'0a53fd8039a1e1254bedce1508bd9fd94f378724e2c8d79cf57cab675f1701fe',
        'exact_five_field_proposal_sha256':'59afcf12a2be1b3f33c360cf014b628719d2da43f65e49c626a6f8862512cab6',
        'independent_source_run_sha256':'1079ae9eedc0c4da5f5b2109153fadc12b8b1665e3b25f3e9e85301332490048',
        'source_phase3_freeze_sha256':'ab4a3912822eee2d9c912b651644822b2e3bb15f18df8f544502bce66da270ea',
        'verdict':'equivalent-after-elaboration','repairs_preserved_unchanged':True,
        'scope':'Actual diagonal-Gaussian norm/Q L2, both exact variances, both2M bounds and2M<=2d/sqrt(kappa); separately reviewed private arbitrary-tau numerical covariance/Young route variant only.'},
      'fake_closure_scan':{
        'method':'Bound completed distinct whole-module lexical and real kernel-root inspection; source actor independently checked hashes, exact types, parent/L2 edges and axioms in final logs.',
        'native_actor':'/root/module_reader_f35b7d',
        'native_commit':'b881059811fb9bcd8d81f60e6bc7cc85498fc2d7',
        'check_report_sha256':'10da7cf43f3ce1ea17749baddcbea11435f98eaa22d1c63c106c9be278e58b54',
        'lexical_inventory_sha256':sha(lexical),
        'final_kernel_receipt_sha256':'846b7fca99d6657f6670eaf7eaa60089c73d114ec325db4ae7a3f91d7c7cc9be',
        'final_kernel_stdout_sha256':'ad6292e66da843b260cef34f5156ab6f75cef87f73e1decd9c091a7aee9a7972',
        'roots_checked':4,'axioms_each':['propext','Classical.choice','Quot.sound'],
        'fake_closure_tokens_found':[],'rerun_by_source_actor':False},
      'publication_declarations':[DECL],
      'publication_binding_sha256':'8bdbee09a451232660a793e46b50337c0e7941a8b069afe32839a23756a0a189',
      'native_binding':{
        'actor':'/root/module_reader_f35b7d','candidate_commit':'b881059811fb9bcd8d81f60e6bc7cc85498fc2d7',
        'current_metadata_carrier_commit':HEAD,
        'binding_freeze':str((BASE/'execution-binding/FREEZE.json').relative_to(ROOT)),
        'binding_freeze_sha256':'9a992aa7bcde868dfc1947f62991ac80bd3e029391ef3d94376b01e479b38d04',
        'module_freeze_sha256':'7b22114231b8d407014059b05e49fd5f13c45b0612f500f2733c0f7369bb0a91',
        'public_archive_sha256':'d9a96038bdf5915132eeebfb5c22e7e7184067268fffc557bdbaf809b02ef8c8',
        'eight_actual_final_receipts':native_receipts,
        'unchanged_current_input_hashes':native['unchanged_current_mathematical_inputs'],
        'fresh_native93_or_source_actor_rerun_claimed':False,
        'static_scope':'Completed independent isolated HTML/content/folding only; no browser/global/site/OS acceptance.'},
      'actual_compiled_parents':{
        'producer':[
          'AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumGaussianMoments.actual_diagonal_gaussian_quadratic_means',
          'AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumExactMeans.actual_diagonal_gaussian_exact_means',
          'AutoSamplingTheory.TechnicalLemmas.StochasticProcesses.GaussianFourthMoment.integral_pow_four_gaussianReal_zero'],
        'private_consumer':[DECL],
        'both_L2_and_both_2M_outputs_materially_consumed':True},
      'definition_semantics':{
        'law':'Literal multivariateGaussian with covariance Lambda inverse, Lambda precision; positive-definite inverse and actual marginals derived internally.',
        'finite_variance':'Both actual MemLp2 conclusions exclude evariance infinity/toReal-zero closure; actual covariance APIs are L2 guarded.',
        'private_tau':'Explicit private non-Anchor real0<=tau<=1/2 only; not a public/source-wide hypothesis or a proved source threshold.'},
      'truth_boundary':'Only this selected variance source SAU and separate private numeric contrast variant are independently VERIFIED. No full Lemma4.5/Ex25, exponential bias, rotated-target transport, concrete tau/query/TV/Krylov/adaptive-law result, full main lower bound, global build, integration, website/browser/remote, purification, Exposition Seal or Goal completion. No STABILIZING; foreign lanes/frontiers/models/Registry/imports remain untouched.'
    }
    advance._validate_transition_evidence('VERIFIED',evidence,schema_version=int(states_before[SAU]['schema_version']))
    assert evidence['verifier_id']==ACTOR
    raw_hash=put('actual-evidence.json',evidence)
    key_inventory=[]
    def walk(value,path=''):
        if isinstance(value,dict):
            for key in value:
                here=path+'.'+key if path else key
                key_inventory.append({'path':here,'type':type(value[key]).__name__})
                walk(value[key],here)
        elif isinstance(value,list):
            for i,value2 in enumerate(value):walk(value2,path+'['+str(i)+']')
    walk(evidence)
    put('actual-evidence-key-inventory.json',{'top_level_keys_in_actual_object':list(evidence),'sorted_top_level_keys':sorted(evidence),'top_level_key_count':len(evidence),'all_dictionary_key_paths':key_inventory,'raw_object_sha256':raw_hash,'canonical_object_sha256':canonical(evidence),'standard_keyset_claimed':False})
    kwargs={'advance_id':SAU,'to_state':'VERIFIED','worker_id':ACTOR,
            'modes':['source-review','independent-verification'],'evidence':evidence}
    put('exact-call-arguments.json',kwargs)
    attempted={'command':command,'api':'tools.astis_advance.transition_advance',
               'kwargs_artifact':'exact-call-arguments.json','evidence_raw_sha256':raw_hash,
               'evidence_canonical_sha256':canonical(evidence),'call_start_utc':utc()}
    with (OUT/'normal-call-attempted.json').open('x') as handle:
        json.dump(attempted,handle,indent=2,ensure_ascii=False);handle.write('\n')
    result['normal_call_attempted']=True
    result['normal_call_count']=1
    result['call_start_utc']=attempted['call_start_utc']
    returned=advance.transition_advance(**kwargs)
    result['call_end_utc']=utc()
    result['actual_api_return']=returned
    assert returned is None
    after=LEDGER.read_bytes()
    assert after.startswith(before),'The complete old ledger prefix was not preserved'
    appended=after[len(before):]
    appended_rows=[json.loads(line) for line in appended.splitlines() if line.strip()]
    assert len(appended_rows)==1,'Expected exactly one appended event'
    event=appended_rows[0]
    assert event['advance_id']==SAU and event['from_state']=='PROVED_LOCAL' and event['to_state']=='VERIFIED'
    assert event['worker_id']==ACTOR and event['evidence']==evidence
    after_states=advance._replay_advances([json.loads(line) for line in after.splitlines() if line.strip()])
    assert after_states[SAU]['state']=='VERIFIED' and after_states[SAU]['last_actor']==ACTOR
    assert {k:v for k,v in states_before.items() if k!=SAU}=={k:v for k,v in after_states.items() if k!=SAU}
    (OUT/'ledger-after.raw.jsonl').write_bytes(after)
    (OUT/'exact-appended-event.raw.jsonl').write_bytes(appended)
    put('exact-appended-event.json',event)
    put('all-SAU-states-after.json',after_states)
    put('own-SAU-after.json',after_states[SAU])
    assert (ROOT/CELL).read_bytes()==(OUT/'own-frontier-before.raw.json').read_bytes()
    for row in frontiers_before+protected_before:
        assert sha((ROOT/row['path']).read_bytes())==row['sha256'],'Unexpected pre-frontier mutation: '+row['path']

    # Only after the normal call has succeeded: two own-frontier field updates.
    old_cell=get(ROOT/CELL)
    new_cell=json.loads(json.dumps(old_cell))
    new_cell['status']='independently_verified'
    new_cell['evidence']['independent_verification']=(
      'Normal PROVED_LOCAL->VERIFIED published by actual independent actor /root/source_reader_c24a61 '
      'at '+event['created_at']+' on accepted-review carrier93d302689aaaebe28dcbe39b155d2168f269a7c8. '
      'Exact raw-first source review run1079ae9e and phase3freezeab4a3912; exact five-field proposal59afcf12 accepted unchanged. '
      'Separately completed /root/module_reader_f35b7d eight true isolated-final native checks on exactb881059811fb9bcd8d81f60e6bc7cc85498fc2d7 '
      'are hash-bound through execution-binding freeze9a992aa7; mathematics/Test/shared providers/lesson/publication/toolchain/manifest unchanged at93d. '
      'No native rerun by this source actor and no fresh native93 claim. Runtime and exact event: '
      '.astis/semantic-neutral-20261110/src_c24a61/normal-sourceV-runtime/. '
      'Only selected actual-Gaussian variance slice and explicitly private numerical contrast variant; '
      'no whole source theorem, STABILIZING/global build/integration/site/browser/remote/purification/Exposition Seal/Goal credit.')
    assert isinstance(new_cell['evidence']['independent_verification'],str)
    pending=OUT/'own-frontier-write.tmp'
    pending.write_text(json.dumps(new_cell,indent=2,ensure_ascii=False)+'\n')
    os.replace(pending,ROOT/CELL)
    result['frontier_updated']=True
    (OUT/'own-frontier-after.raw.json').write_bytes((ROOT/CELL).read_bytes())
    stripped=lambda c:{**c,'status':None,'evidence':{k:v for k,v in c['evidence'].items() if k!='independent_verification'}}
    assert stripped(new_cell)==stripped(old_cell)
    foreign_frontiers=[]
    for row in frontiers_before:
        actual=sha((ROOT/row['path']).read_bytes())
        if row['path']!=CELL:assert actual==row['sha256'];foreign_frontiers.append(row['path'])
    for row in protected_before:assert sha((ROOT/row['path']).read_bytes())==row['sha256']
    assert (ROOT/'runs/substantive_discoveries.jsonl').read_bytes()==(OUT/'discovery-ledger-before.raw.jsonl').read_bytes()
    frontier_errors=frontier.validate_cells(frontier.load_cells())
    assert not frontier_errors,frontier_errors
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip()==HEAD
    preservation={'full_ledger_prefix_preserved':True,'prefix_bytes':len(before),'prefix_raw_sha256':sha(before),
                  'ledger_after_raw_sha256':sha(after),'exact_append_raw_sha256':sha(appended),
                  'exact_append_canonical_sha256':canonical(event),'appended_event_count':1,
                  'event_actor':event['worker_id'],'actual_evidence_top_level_keys':list(evidence),
                  'actual_evidence_raw_sha256':raw_hash,'actual_evidence_canonical_sha256':canonical(evidence),
                  'all_other_SAU_full_states_identical':True,'other_SAU_count':len(states_before)-1,
                  'all_foreign_frontier_raw_bytes_identical':True,'foreign_frontier_count':len(foreign_frontiers),
                  'protected_models_Registry_imports_identical':True,'protected_file_count':len(protected_before),
                  'discovery_ledger_raw_bytes_identical':True,'own_frontier_only_changed_fields':['status','evidence.independent_verification'],
                  'own_frontier_before_raw_sha256':sha((OUT/'own-frontier-before.raw.json').read_bytes()),
                  'own_frontier_after_raw_sha256':sha((OUT/'own-frontier-after.raw.json').read_bytes()),
                  'own_frontier_independent_verification_type':'str','frontier_validation_errors':[],
                  'no_STABILIZING_call':True,'head_unchanged':HEAD}
    put('preservation-and-exact-append.json',preservation)
    result.update(status='PASS',exit_code=0,normal_state='VERIFIED',
                  actual_evidence_raw_sha256=raw_hash,actual_evidence_canonical_sha256=canonical(evidence),
                  exact_append_raw_sha256=sha(appended),exact_append_canonical_sha256=canonical(event),
                  actual_evidence_key_list=list(evidence),frontier_status='independently_verified')
except Exception as exc:
    result.update(status='FAIL',exit_code=1,exception_type=type(exc).__name__,exception=str(exc),traceback=traceback.format_exc())
result['end_utc']=utc()
put('actual-command-result.json',result)
print(json.dumps(result,indent=2,ensure_ascii=False))
sys.exit(result['exit_code'])
