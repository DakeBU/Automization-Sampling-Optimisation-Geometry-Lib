"""R16 normal-proof verification: read-only guards and pinned evidence. No action at import."""
import ast,copy,datetime as dt,hashlib,json,os,stat,subprocess,sys,tarfile,time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
sys.dont_write_bytecode=True
OWN=Path(__file__).resolve().parent
REPO=OWN.parents[3]
PRIVATE=OWN/'local-private-guards'
ADV='ASTIS-SA-20261115-TraceExponentialDomain'
OWNER='huanjian_20261115_trace_exponential_domain'
VERIFIER='trace_exp_native_61e4_independent_verifier'
P='AutoSamplingTheory.TechnicalLemmas.Analysis.MatrixTraceExponentialBounds.trace_exp_pos_and_le_card_mul_exp_abs_mul_norm'
MATH='30172847ec40c24426f0b39afc4887719810eca0'
BINDING='e44190bca918ce5a1e8f4ff5fc942c56ea400deb7a10af9929a698ef22a9d45c'
ADVPATH='runs/substantive_advances.jsonl';DISCPATH='runs/substantive_discoveries.jsonl'
CELL='research-wiki/frontier-cells/ASTIS-SHARED-REAL-TRACE-EXPONENTIAL-DOMAIN.json'
PLSHA='a17ff70fa56a86070673d630943b43148f32f874f6f3f1243ddf6b73c2d889bf'
PLAPPENDSHA='2b9f48ff20b6f919e1068b460a47638a0fab9b8e1616bc43c666250aa2d15947'
NATIVESHA='51481e488bee3d6de641a61a5dced0bd9bfaa6f7666e64d5c36595f3b0c5c1ca'
READERSHA='59bed62c292887d2f8bfa1c8401443033a1a4e8ea4cacb68188a4e96cd9a1071'
READERMANIFESTSHA='3704d8043fe4a57fc96cd567d98ac3ca9cb7e15a030804e37c73a7fb3265b8e3'
SOURCES={'AutoSamplingTheory/TechnicalLemmas/Analysis/MatrixTraceExponentialBounds.lean':'1ef6f49fa5f0a8b3b61ba42d31bca1bb744bebb64e433075d0ca25ab82570b76','Tests/GaussianComplexityTraceMgfDomain.lean':'72311555e65cacc8b129510f2158abc9e2e6a230882a2169f6504e80f394fedb'}
def sha(b):return hashlib.sha256(b).hexdigest()
def file_sha(p):return sha(Path(p).read_bytes())
def read(p):return json.loads(Path(p).read_text())
def private_dir(p):
    p=Path(p);assert p.resolve().is_relative_to(PRIVATE.resolve())
    p.mkdir(parents=True,exist_ok=True,mode=0o700)
    for directory in [p,*p.parents]:
        if directory.resolve().is_relative_to(PRIVATE.resolve()):os.chmod(directory,0o700)
        else:break
def output_parent(p):
    p=Path(p)
    if p.resolve().is_relative_to(PRIVATE.resolve()):private_dir(p.parent);return 0o600
    p.parent.mkdir(parents=True,exist_ok=True);return 0o644
def write(p,x):
    p=Path(p);mode=output_parent(p)
    with p.open('x') as f:os.fchmod(f.fileno(),mode);json.dump(x,f,ensure_ascii=False,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
def exact(p,b):
    p=Path(p);mode=output_parent(p)
    with p.open('xb') as f:os.fchmod(f.fileno(),mode);f.write(b);f.flush();os.fsync(f.fileno())
def ident(p):
    p=Path(p);return {'file':str(p.relative_to(REPO)),'bytes':p.stat().st_size,'sha256':file_sha(p)}
def canonical(x):return sha(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())
def pin_bytes(row):
    p=REPO/row['file'];raw=p.read_bytes();assert sha(raw)==row['sha256']
    if 'bytes' in row:assert len(raw)==row['bytes']
    if 'member' in row:
        with tarfile.open(p,'r:*') as archive:
            member=archive.getmember(row['member']);assert member.isfile();raw=archive.extractfile(member).read()
        assert sha(raw)==row['member_sha256']
        if 'member_bytes' in row:assert len(raw)==row['member_bytes']
    return raw
def git(label,*args,allow=(0,)):
    directory=PRIVATE/'read-only-git';private_dir(directory)
    out=directory/(label+'.stdout.raw');err=directory/(label+'.stderr.raw');argv=['/usr/bin/git','--no-optional-locks',*args]
    start=time.monotonic()
    with out.open('xb') as o,err.open('xb') as e:
        os.fchmod(o.fileno(),0o600);os.fchmod(e.fileno(),0o600)
        r=subprocess.run(argv,cwd=REPO,env={'PATH':'/usr/bin:/bin','LC_ALL':'C','GIT_OPTIONAL_LOCKS':'0'},stdin=subprocess.DEVNULL,stdout=o,stderr=e)
    write(directory/(label+'.receipt.json'),{'local_private_do_not_publish':True,'argv':argv,'actual_exit_code':r.returncode,'elapsed_seconds':time.monotonic()-start,'stdout_sha256':file_sha(out),'stderr_sha256':file_sha(err)})
    assert r.returncode in allow,(label,r.returncode)
    return out.read_bytes()
def replay(araw,draw):
    assert araw.endswith(b'\n') and draw.endswith(b'\n'),'Never permit API tail recovery/truncation'
    ar=[json.loads(x) for x in araw.splitlines() if x.strip()];dr=[json.loads(x) for x in draw.splitlines() if x.strip()]
    nodes=[n for n in ast.parse((REPO/'tools/astis_advance.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name in ['_replay_advances','_replay_discoveries']]
    assert len(nodes)==2
    ns={'Any':object,'Iterable':list,'NO_PROGRESS_FREEZE_AT':3};exec(compile(ast.Module(body=nodes,type_ignores=[]),'<pure-read-only-replay>','exec'),ns)
    return ar,dr,ns['_replay_advances'](copy.deepcopy(ar)),ns['_replay_discoveries'](copy.deepcopy(dr))
def filesystem_ident(p):
    p=Path(p)
    if p.is_symlink():return {'kind':'symlink','mode':stat.S_IMODE(p.lstat().st_mode),'link_sha256':sha(os.readlink(p).encode())}
    if not p.exists():return {'kind':'missing'}
    s=p.stat();h=file_sha(p);t=p.stat();assert (s.st_size,s.st_mtime_ns,s.st_mode)==(t.st_size,t.st_mtime_ns,t.st_mode)
    return {'kind':'file','mode':stat.S_IMODE(t.st_mode),'bytes':t.st_size,'sha256':h}
def snapshot(label,a):
    directory=PRIVATE/label;assert not directory.exists();private_dir(directory)
    head=git(label+'-HEAD','rev-parse','HEAD').decode().strip();branch=git(label+'-branch','symbolic-ref','HEAD').decode().strip()
    assert head==a['carrier_commit'] and branch==a['expected_branch']
    def gitpath(name):
        p=Path(git(label+'-gitpath-'+name.replace('/','_'),'rev-parse','--git-path',name).decode().strip());return p if p.is_absolute() else REPO/p
    index=gitpath('index');headpath=gitpath('HEAD');ref=gitpath(branch)
    idx=index.read_bytes();exact(directory/'index.exact',idx)
    paths=[x.decode() for x in git(label+'-tracked','ls-files','-z').split(b'\0') if x]
    assert len(paths)==len(set(paths))
    with ThreadPoolExecutor(max_workers=8) as pool:tracked=dict(zip(paths,pool.map(lambda n:filesystem_ident(REPO/n),paths)))
    araw=(REPO/ADVPATH).read_bytes();draw=(REPO/DISCPATH).read_bytes();ar,dr,adv,disc=replay(araw,draw)
    exact(directory/'advance-ledger.exact.jsonl',araw);exact(directory/'discovery-ledger.exact.jsonl',draw)
    frontiers={str(p.relative_to(REPO)):filesystem_ident(p) for p in (REPO/'research-wiki/frontier-cells').rglob('*.json')}
    state={'local_private_do_not_publish':True,'HEAD':head,'branch':branch,'HEAD_file':filesystem_ident(headpath),'branch_ref':filesystem_ident(ref),'index_mode':stat.S_IMODE(index.stat().st_mode),'index_sha256':sha(idx),'tracked':tracked,'frontiers':frontiers,'foreign_A_states':{k:canonical(v) for k,v in adv.items() if k!=ADV},'all_D_states':{k:canonical(v) for k,v in disc.items()},'A_ledger_sha256':sha(araw),'D_ledger_sha256':sha(draw),'view':'local worktree ledger replay only; no origin/main stabilizer release claim'}
    if not ref.exists():state['packed_refs']=filesystem_ident(gitpath('packed-refs'))
    write(directory/'full-guard-map.private.json',state)
    return {'state':state,'araw':araw,'draw':draw,'records':ar,'adv':adv,'disc':disc,'index':idx}
def postguards(before,after,a,allowed,cell_exception=None):
    x=before['state'];y=after['state']
    for k in ['HEAD','branch','HEAD_file','branch_ref','packed_refs','index_mode']:
        assert x.get(k)==y.get(k),k
    assert before['index']==after['index'] and set(x['tracked'])==set(y['tracked'])
    changed={k for k in x['tracked'] if x['tracked'][k]!=y['tracked'][k]};assert changed==set(allowed),changed
    # Mode bits stay exact even for the one permitted content mutation.
    assert all(x['tracked'][k].get('mode')==y['tracked'][k].get('mode') for k in x['tracked'])
    assert x['foreign_A_states']==y['foreign_A_states'] and x['all_D_states']==y['all_D_states'] and before['draw']==after['draw']
    assert {k:v for k,v in x['frontiers'].items() if k!=cell_exception}=={k:v for k,v in y['frontiers'].items() if k!=cell_exception}
    return {'HEAD_branch_index_exact':True,'all_tracked_modes_exact':True,'all_other_tracked_bytes_exact':True,'all_foreign_A_and_all_D_states_exact':True,'D_ledger_exact':True,'all_frontiers_including_target_exact':cell_exception is None,'all_other_frontiers_exact':True,'only_changed_tracked_paths':sorted(changed),'tracked_paths_checked':len(x['tracked']),'frontiers_checked':len(x['frontiers']),'full_maps_private_only':True}
def validate_authorization(path,expected_sha,window):
    assert file_sha(path)==expected_sha;a=read(path)
    assert a['authorization']=='ROOT_EXPLICIT_SINGLE_WINDOW_AUTHORIZATION' and a['authorized_action']==window
    assert a['advance_id']==ADV and a['owner_id']==OWNER and a['verifier_id']==a['worker_id']==VERIFIER and VERIFIER!=OWNER
    assert a['math_commit']==MATH and a['source_binding']==BINDING
    assert a['normal_API_calls_authorized']==(1 if window=='NORMAL_PROOF_V_ONCE' else 0)
    assert a['expected_api_sha256']==file_sha(REPO/'tools/astis_advance.py')
    for name,h in a['scripts'].items():assert Path(name).name==name and file_sha(OWN/name)==h
    assert set(a['scripts'])=={'verification_common.py','verification_driver.py'}
    assert a['separate_window2_authorization_required'] is True
    return a
def evidence_inputs(a):
    pins=a['evidence_pins'];data={k:pin_bytes(v) for k,v in pins.items()}
    assert sha(data['PL'])==PLSHA and sha(data['PL_append'])==PLAPPENDSHA
    pl=json.loads(data['PL']);assert len(pl)==24 and pl['lean_declarations']==pl['publication_declarations']==[P] and pl['actual_native_rebuilt_math_commit']==MATH
    assert data['PL_append'].endswith(b'\n') and len(data['PL_append'].splitlines())==1 and json.loads(data['PL_append'])['evidence']==pl
    native=json.loads(data['native_original']);reader=json.loads(data['reader_original'])
    assert sha(data['native_original'])==NATIVESHA and data['native_original']==data['native_carried']
    assert native['candidate_commit']==MATH and native['independent_rebuild']['ASTIS_source_modules']==11 and native['independent_rebuild']['prior_ASTIS_olean_reused'] is False and native['unsafe_in_complete_actual_target_closure']==0 and not native['unauthorized_axioms_or_sorryAx_in_final_targets']
    scan=json.loads(data['native_fake_scan']);assert scan['candidate_commit']==MATH and scan['passed'] and len(scan['modules'])==11 and all(not m['fake_closure_hits'] for m in scan['modules'])
    assert sha(data['reader_original'])==READERSHA and data['reader_original']==data['reader_carried'] and sha(data['reader_manifest_original'])==READERMANIFESTSHA
    assert reader['status']=='PASS_BOUNDED_ISOLATED_READER' and reader['reader_blocking_residual_count']==0 and reader['binding']['source_reviewed_binding']==BINDING
    assert reader['actual_browser_run']['actual_exit_code']==0 and reader['actual_browser_run']['actual_checks']==389 and reader['actual_browser_run']['actual_PNGs']==36
    for n in ['public_audit','private_audit']:
        x=json.loads(data[n]);assert x['state']=='source-reviewed' and x['publication_binding_sha256']==BINDING
    required={'objects','domains','quantifiers','assumptions','conclusion','scopes','constant_dependencies'}
    for n,h in [('P_source_review','aa3f55d76f8e5b2293f5422595096b3ce2653f7c2c41bd6bf4047e115055ef1b'),('T_source_review','e24f30c0afeefa77e24c419aa07c996fb461b38bccacd8e1e893537115359af3')]:
        x=json.loads(data[n]);assert sha(data[n])==h and x['reviewer']=='trace_exp_fresh_source_51c8' and x['independent_from_formalizer'] and x['independent_from_decoder'] and set(x['semantic_slots'])==required and not x['deltas'] and x['publication_binding_sha256']==BINDING
    assert sha(data['source_successor_run'])=='8543d7d7365431d074a20c5491750620d242a1b3125379fd8221d9e5270bf64c'
    assert sha(data['source_full_run'])=='f5cbc9dac309eda9127f3551b368c6bd2d2765e5793947f7e59d7d44a1cd212c'
    assert file_sha(REPO/'lean-toolchain')=='302cd63c54178885b89e669f33b38f12f4dd7ae7e5cac537b3203e3768d8fb2b' and file_sha(REPO/'lake-manifest.json')=='b83ca83b9cf7caa85fa8b023c2ff9a3fb7a7cce7e1c332e810c348535ec49c37'
    for raw,h in SOURCES.items():assert file_sha(REPO/raw)==h
    gates=json.loads(pin_bytes(a['gate_summary']));assert gates['carrier']==a['carrier_commit'] and gates['original_math_identity']==MATH
    assert {x['gate'] for x in gates['records']}=={'publication','contributor','semantic','private-semantic','frontier','whitespace'} and len(gates['records'])==6
    for x in gates['records']:
        assert x['checked_metadata_commit']==a['carrier_commit'] and x['actual_exit_code']==0
        rp=REPO/x['receipt'];assert file_sha(rp)==x['receipt_sha256'];receipt=read(rp)
        assert receipt['exit_code']==0 and receipt['head_before']==receipt['head_after']==a['carrier_commit']
        assert file_sha(Path(receipt['log']))==receipt['log_sha256']
    return {'pl':pl,'native':native,'reader':reader,'pins':pins,'gates':gates,'data':data}
