"""Freeze the completed independent visual observations and explicit original-artifact allowlist."""
import datetime as dt, hashlib, json
from pathlib import Path
OUT=Path(__file__).resolve().parent;OWN=OUT.parent
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,x):
    with Path(p).open('x') as f:f.write(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
data=json.loads((OUT/'readonly-data-review.json').read_text())
views=[]
for row in data['actual_original_screenshots']:
    name=Path(row['path']).name
    if 'actual-node-viewport' in name:
        observation='Selected node rectangle and readable core label are plainly inside the actual SVG viewport. Long P/PSD labels remain ellipsized; exact identity is read in separate detail. No blank-graph/crop claim.'
    elif 'full-ID-detail' in name:
        observation='Full selected identifier is readable with wrapping in the detail. Neighbor/context controls are present; complete neighbor sets/directions are additionally recorded in original DOM checks. This viewport is not a claim that every neighbor is visible at once.'
    elif 'proof-initial-folded' in name:
        observation='Actual full-page image shows initially closed source statement, assumptions, five proof steps and Lean disclosures; MathJax main formula is rendered. Mobile long formula is intentionally in a local horizontal scroll pane with a visible instruction.'
    elif 'representative-step1' in name:
        observation='Expanded first proof prose/formula is readable. Desktop adjacent Lean controls are visible; mobile formula has intentional local horizontal overflow. This representative screenshot alone does not show all five exact snippets; original DOM/action records cover them.'
    elif 'representative-step5' in name:
        observation='Expanded fifth proof text is readable and distinguishes ordinary trace/true mean/cap. Desktop formula/source actions are visible; mobile lower formula/actions continue below the viewport. No claim this image captures the failed L187 destination.'
    elif 'expanded-assumption-comparison' in name:
        observation='Expanded assumption comparison is readable. Mobile screenshot is the actual right-scrolled table region; left columns are available through the same local table scroll pane, as recorded by original scroll geometry.'
    elif 'module-full-source-context' in name:
        observation='Actual complete-source disclosure and code panel are readable. Mobile last complete-source panel fits within the viewport and scrolls code locally; this screenshot does not refute the measured offscreen/global body overflow.'
    elif 'widest-right-glyph' in name:
        observation='Actual horizontally scrolled source shows the ending code glyphs. Long left prefixes are intentionally out of the local code viewport. Recorded Range bbox uses the explicit 1 CSS px horizontal tolerance; no zero-pixel clipping claim.'
    elif 'source-T-bottom' in name:
        observation='Final source namespace line is visibly reachable near the document bottom; local horizontal position differs by viewport and the final namespace identifier remains available by local scrolling.'
    elif 'source-index' in name:
        observation='Six wrapped source labels are readable, including private application explicitly marked as having no public node. No duplicate public private-T theorem label is presented.'
    elif 'parent-context' in name:
        observation='Public P PSD parent and four associated private-application parents are readable; text explicitly says the private application has no separate public theorem node.'
    elif '-source-' in name and '-anchor' in name:
        observation='Correct selected declaration heading and source lines are readable below the actual header in this directly opened source-page screenshot. This is distinct from the failed step5 click-to-L187 instantaneous measurement.'
    else:raise AssertionError(name)
    views.append({**row,'actually_viewed_original_by_independent_reviewer':True,'method':'tools.view_image on original PNG; no generated/contact-sheet substitute','observation':observation})
assert len(views)==50
write(OUT/'visual-observations.json',{'schema':'R17-v3-independent-actual-50-PNG-observations-v1','reviewer':'matrix_domain_reader_61e4','all50_originals_actually_viewed':True,'observations':views,'aggregate_status':'FAIL_REMAINS; valid visual fragments only','not_a_new_browser_run':True})
report={
 'schema':'R17-v3-independent-reader-failure-and-valid-fragment-review-v1',
 'reviewer':'matrix_domain_reader_61e4',
 'status':'FAIL_REQUIRES_DIAGNOSIS_AND_UI_REPAIR',
 'actual_runtime':{'status':'FAIL','actual_OS_exit_code':1,'checks':501,'false_checks':3,'true_checks':498,'actual_original_PNGs':50,'Chrome':'157.0.8103.51','started_utc':'2026-11-15T14:57:51.278881+00:00','ended_utc':'2026-11-15T14:59:36.757759+00:00','elapsed_seconds':105.47830079100095,'server_and_thread_stopped':True},
 'pins':{**data['original_pins'],'preview_manifest_sha256':data['preview_manifest_sha256'],'source_reviewed_binding':data['source_reviewed_binding'],'mathematical_commit':data['mathematical_commit'],'readonly_data_review_sha256':sha(OUT/'readonly-data-review.json'),'visual_observations_sha256':sha(OUT/'visual-observations.json'),'original_OS_receipt_sha256':sha(OWN/'runtime-process/receipt.json')},
 'actual_failures':data['original_false'],
 'typed_findings':[
  {'id':'R17-v3-step5-immediate-anchor','classification':'PRESENTATION_MEASUREMENT_TIMING_UNRESOLVED','observed':'After actual step5 source.click and networkidle, L187 has zero visible vertical intersection in both viewports: desktop top1164.609375 at height1000; mobile top1230.703125 at height844. Correct target fragment and file exist, but the original compound check records no separate URL boolean for this failed row.','static_evidence':'Frozen site-base.css:83 enables html smooth scrolling, no source hash lifecycle handler found in selected root JS. Other step anchors show increasing residual offsets with depth: L138 desktop689.890625/mobile710.90625.','inference_boundary':'This is consistent with measuring before natural smooth scroll has settled. Original run has no post-networkidle trace, so it proves neither eventual correct positioning nor a final anchor UI defect. The failed instantaneous checks remain false.','next':'Separate frozen observational helper on original v3, only after fresh scoped approval: preserve immediate sample, naturally sample until stable/5s, no forced source scrolling. If supported by actual trace, successor acceptance checker may wait for natural stable visible bbox without lowering existing visibility/header thresholds.'},
  {'id':'R17-v3-mobile-module-width','classification':'PRESENTATION_LAYOUT_OVERFLOW','observed':'After opening the private-T module reading disclosures the actual mobile final measurement is viewport390/html390/body699. Original complete-source screenshot shows the final pre panel itself within18..372.','static_evidence':'The module declaration excerpt is in .declaration-list display:grid with an implicit auto column; its details/declaration-content ancestors lack explicit min-width:0. A contained pre uses width100% plus white-space:pre. This is a plausible intrinsic-size propagation path.','inference_boundary':'Original run records no offending DOM-owner/ancestor metrics. Exact owner remains inferred, and the last source-panel screenshot cannot identify an offscreen declaration/metadata owner.','next':'Observe original mobile module offscreen excerpt and ancestor computed styles before accepting an isolated generic minmax(0,1fr)/min-width:0/wrapping repair. Preserve local code scroll. Do not hide the body overflow or change the measured threshold.'}
 ],
 'independently_accepted_valid_fragments':[
  'All50 actual original PNGs viewed; no additional visual blocking finding in the recorded states. This is not aggregate reader acceptance.',
  'Five adjacent P/P/T/T/T spans cover exact P50 and T212, total262 lines. Preserved real clipboard equality checks cover all five in both viewports; clipboard payloads are not separately serialized. Independent frozen HTML/source comparison and all24 actual downloaded files match original snapshot bytes.',
  'Six full-source pages have correct selected declarations/paths and directly opened anchors, complete copy/download controls, full-source bytes and line counts. Actual T bottom and longest source lines are reachable by local scrolling.',
  'Initial folded disclosures and representative expanded proof prose render on desktop/mobile using local MathJax3.2.2 CHTML without recorded error. Mobile formulas and the assumption table use their measured local horizontal scroll panes.',
  'All six native wheel/pointer graph focuses have node/label clipped visible fractions recomputed as1 from raw rectangles. Font is approximately13 CSSpx and label visible height33.7273px. Full P/PSD identifiers remain intentionally ellipsized in SVG and are readable in actual detail. This is a bounded source-reference graph, not a type/value necessity certificate.',
  'Exact11 nodes and15 directed structure/reference edges; one private-T module, no private-T public declaration. Source-reference edges are dashed, import/declare structural edges solid; detail neighbor directions and actual context navigation match the preserved graph.',
  '1646 requests/responses, no recorded console/page/HTTP/external-request errors. Original server/thread termination and all110 fixture byte identities preserved.'
 ],
 'explicit_limits':{'not_global_PASS':True,'original_exit1_3false_never_relabelled':True,'no_new_browser_or_diagnostic_executed_by_this_review':True,'headless_CSS_viewports_not_physical_touch':True,'horizontal_Range_bbox_tolerance_css_px':1,'max_observed_horizontal_bbox_overhang_css_px':data['max_horizontal_Range_bbox_overhang_css_px'],'trimEnd_only_selects_final_nonwhitespace_codepoint_does_not_trim_any_source':True,'no_full_site_production_source_fidelity_new_math_build_normalPL_or_V_credit':True,'no_claim_metadata_carrier_rebuilt_math':True,'pending':['actual natural anchor timing trace','exact mobile overflow owner and isolated repair','successor separately authorized actual reader acceptance']},
 'preservation':{'original_runner_geometry_assignment_runtime_PNGs_downloads_unchanged':True,'preparation_implementation_exit1_and_v2_static_exit0_retained':True,'no_old_R16_verdict_transfer':True,'original_request_logs_remain_in_actual_result':True},
 'review_process':{'actual_readonly_audit_exit_code':0,'actual_readonly_checks':129,'readonly_audit_script_sha256':sha(OUT/'review_actual.py'),'readonly_audit_receipt_sha256':sha(OUT/'process/receipt.json'),'no_browser_API_Git_Lean_site_source_writes':True},
 'created_utc':dt.datetime.now(dt.timezone.utc).isoformat()
}
write(OUT/'independent-reader-failure-review.json',report)
write(OUT/'independent-review-run.json',{'schema':'R17-v3-immutable-independent-reader-review-run-v1','report_sha256':sha(OUT/'independent-reader-failure-review.json'),'readonly_data_sha256':sha(OUT/'readonly-data-review.json'),'visual_observations_sha256':sha(OUT/'visual-observations.json'),'actual_readonly_OS_receipt_sha256':sha(OUT/'process/receipt.json'),'original_runtime_receipt_sha256':sha(OWN/'runtime-process/receipt.json'),'original_runtime_result_sha256':sha(OWN/'actual-result.json'),'aggregate_reader_acceptance':'FAIL_REMAINS','actual_browser_runs_by_review':0,'actual_original_PNGs_viewed':50})
prep=json.loads((OWN/'preparation-public-selected-originals.manifest.json').read_text())
paths={x['path'] for x in prep['files']}
for x in prep['files']:assert sha(OWN/x['path'])==x['sha256']
paths.update(['preparation-public-selected-originals.manifest.json','execution-assignment.json','actual-result.json','runtime-process/receipt.json','runtime-process/stdout.raw','runtime-process/stderr.raw'])
paths.update(x['path'] for x in data['actual_original_screenshots'])
paths.update(x['path'] for x in data['actual_downloads'])
paths.update('failure-review-v1/'+p for p in ['review_actual.py','freeze_review.py','readonly-data-review.json','visual-observations.json','independent-reader-failure-review.json','independent-review-run.json','process/receipt.json','process/stdout.raw','process/stderr.raw'])
assert not any(any(x in p.split('/') for x in ['chrome-tmp','__pycache__','cache','local-private-guards']) for p in paths)
files=[{'path':p,'bytes':(OWN/p).stat().st_size,'sha256':sha(OWN/p)} for p in sorted(paths)]
write(OUT/'public-selected-originals.manifest.json',{'schema':'R17-v3-failed-actual-runtime-independent-review-explicit-own-public-leaves-v1','base':'matrix_domain_reader_61e4','status':'FAIL_WITH_VALID_FRAGMENTS_NOT_READER_ACCEPTED','files':files,'selection_is_complete_explicit_leaf_list_no_recursive_directory_copy':True,'original_files_must_be_copied_byte_exact_no_stream_trim_or_normalization':True,'selected_runtime_result_contains_only_localhost_observations_and_known_path_references':True,'no_Chrome_cache_tmp_privateguards_fullforeignmaps_global_inventory_index_ATLAS_or_credentials_selected':True,'diagnostic_preparation_is_in_distinct_directory_not_executed_or_inherited':True})
print(json.dumps({'report_sha256':sha(OUT/'independent-reader-failure-review.json'),'run_sha256':sha(OUT/'independent-review-run.json'),'manifest_sha256':sha(OUT/'public-selected-originals.manifest.json'),'selected_leaves':len(files),'selected_bytes':sum(f['bytes'] for f in files)}))
