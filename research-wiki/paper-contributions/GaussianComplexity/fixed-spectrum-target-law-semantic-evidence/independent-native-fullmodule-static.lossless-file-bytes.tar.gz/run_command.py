import subprocess,sys,json,time,datetime,os
from pathlib import Path
d=Path(__file__).resolve().parent;r=d.parents[2]
label=sys.argv[1];cmd=sys.argv[2:];e=os.environ.copy();e.update(LEAN_NUM_THREADS="2",ASTIS_ATLAS_ROOT=str(r/".atlas-upstream/v1"),PYTHONDONTWRITEBYTECODE="1")
extra=d/"lean-path.txt"
if label.startswith(("fresh-", "kernel-")):
 e["LEAN_PATH"]=str(d/"build/lib/lean")+":"+extra.read_text().strip()
start=time.monotonic();now=datetime.datetime.now(datetime.timezone.utc).isoformat()
p=subprocess.run(cmd,cwd=r,env=e,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
(d/(label+".raw.log")).write_bytes(p.stdout)
record={"label":label,"argv":cmd,"cwd":str(r),"started_at_utc":now,"elapsed_seconds":time.monotonic()-start,"exit_code":p.returncode,"HEAD":subprocess.check_output(["git","rev-parse","HEAD"],cwd=r,text=True).strip(),"environment":{"LEAN_NUM_THREADS":"2","ASTIS_ATLAS_ROOT":e["ASTIS_ATLAS_ROOT"],"PYTHONDONTWRITEBYTECODE":"1","LEAN_PATH":e.get("LEAN_PATH")}}
(d/(label+".receipt.json")).write_text(json.dumps(record,indent=2)+"\n");print(json.dumps(record));sys.stdout.buffer.write(p.stdout);sys.exit(p.returncode)
