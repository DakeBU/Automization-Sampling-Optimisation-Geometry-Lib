from html.parser import HTMLParser
from pathlib import Path
import re, json

BASE = Path(__file__).resolve().parent
SOURCE = BASE.parents[1] / 'huanjian-resume-20261103/2610.20492v1.html'
raw = SOURCE.read_text()
line_starts = [0]
for m in re.finditer('\n', raw):
    line_starts.append(m.end())

class Extractor(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.stack = []
        self.sections = []
        self.spans = {}
        self.blocks = []
        self.active = None
        self.math_depth = 0
        self.all_math = []

    def char_offset(self):
        line, col = self.getpos()
        return line_starts[line - 1] + col

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        self.stack.append((tag, a))
        if tag == 'section':
            self.sections.append((a.get('id', ''), self.char_offset()))
        if tag == 'math':
            self.math_depth += 1
            self.all_math.append(dict(id=a.get('id',''), sections=[s[0] for s in self.sections]))
            if self.math_depth == 1 and self.active is not None:
                self.active['parts'].append(' $' + a.get('alttext', '') + '$ ')
                self.active['math_ids'].append(a.get('id',''))
            return
        if self.math_depth:
            return
        if self.active is None and tag in {'h1','h2','h3','h4','h5','h6','p','table','li'}:
            self.active = dict(tag=tag, depth=len(self.stack), id=a.get('id',''),
                sections=[s[0] for s in self.sections], parts=[], math_ids=[])
        elif tag in {'br','td'} and self.active is not None:
            self.active['parts'].append(' ')

    def handle_endtag(self, tag):
        if tag == 'math':
            self.math_depth -= 1
        if self.active is not None and tag == self.active['tag'] and len(self.stack) == self.active['depth']:
            self.active['text'] = re.sub(r'\s+', ' ', ''.join(self.active.pop('parts'))).strip()
            if self.active['text']:
                self.blocks.append(self.active)
            self.active = None
        if tag == 'section' and self.sections:
            ident, start = self.sections.pop()
            self.spans[ident] = (start, self.char_offset() + len('</section>'))
        for i in range(len(self.stack)-1, -1, -1):
            if self.stack[i][0] == tag:
                self.stack = self.stack[:i]
                break

    def handle_data(self, data):
        if not self.math_depth and self.active is not None:
            self.active['parts'].append(data)

p = Extractor()
p.feed(raw)
def rendered(blocks):
    return '\n\n'.join('[' + x['id'] + '] ' + x['text'] for x in blocks) + '\n'

(BASE / 'text-full.txt').write_text(rendered(p.blocks))
(BASE / 'source-blocks.json').write_text(json.dumps(p.blocks, ensure_ascii=False, indent=2)+'\n')
for ident in ['S2', 'S4', 'A3']:
    start, end = p.spans[ident]
    (BASE / f'raw-{ident}.html').write_text(raw[start:end])
    blocks = [x for x in p.blocks if ident in x['sections']]
    (BASE / f'text-{ident}.txt').write_text(rendered(blocks))
    all_ids = [x['id'] for x in p.all_math if ident in x['sections']]
    covered = [m for x in blocks for m in x['math_ids']]
    assert all_ids == covered, (ident, set(all_ids)-set(covered))
    print(ident, len(blocks), len(rendered(blocks).encode()), 'raw-character-span',start,end, 'math-elements',len(all_ids),'all-covered')
print('FULL',len(p.blocks),len(rendered(p.blocks).encode()))
