from pathlib import Path
import gzip,hashlib,json,re,sys
sys.dont_write_bytecode=True
sys.path.insert(0,'tools');import astis_advance as adv
import astis_publication as pub
sha=lambda b:hashlib.sha256(b).hexdigest()
dump=lambda x:(json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode()
E=Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-cosine-expansion-semantic-evidence')
C=Path('research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-cosine-expansion.json')
L=Path('runs/substantive_advances.jsonl')
ADV='ASTIS-SA-20261109-GaussianComplexityFixedSpectrumCosineExpansion'
OWNER='huanjian_gc_20261109_fixed_spectrum_cosine_expansion'
name='AutoSamplingTheory.ExampleCases.GaussianComplexity.FixedSpectrumCosineExpansion.actual_inverse_spectrum_cosine_expansion'
files=[Path('AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumCosineExpansion.lean'),Path('Tests/GaussianComplexityFixedSpectrumCosineExpansion.lean')]
checks=[Path('.astis/huanjian-resume-20261103')/(n+'.receipt.json') for n in [
 '20261109T054836189144Z-cosine-expansion-actual-production-re-projection-import-v2',
 '20261109T055101900464Z-cosine-expansion-actual-private-grid-with-pi-import-v2',
 '20261109T055316561702Z-cosine-expansion-actual-kernel-and-sealed-types-v2']]
checkrows=[]
for q in checks:
    r=json.loads(q.read_bytes());raw=Path(r['log']).read_bytes()
    assert r['exit_code']==0 and sha(raw)==r['log_sha256']
    (E/q.name).write_bytes(q.read_bytes());(E/(Path(r['log']).name+'.gz')).write_bytes(gzip.compress(raw,mtime=0))
    checkrows.append({'receipt':str(q),'sha256':sha(q.read_bytes()),'raw_log_sha256':sha(raw),'exit_code':0})
klog=Path(json.loads(checks[-1].read_bytes())['log']).read_text()
assert 'ACTUAL_PRIVATE_SEALED_LITERAL_KERNEL_TYPE_APPLICATION_PASS' in klog and 'sorryAx' not in klog
pattern=re.compile(r'\b(sorry|admit|axiom)\b|Prop\s*:=\s*True|:=\s*trivial\b')
for q in files:assert not pattern.search(q.read_text()),q
pub.check_advance([name],reviewed=False)
mirror=json.loads((E/'postproof-conceptual-mirror-audit.json').read_bytes())
audit={'status':'candidates-published','discovery_ids':mirror['discovery_ids']}
before=L.read_bytes();states=adv._replay_advances([json.loads(x) for x in before.splitlines()])
assert states[ADV]['state']=='EXPLORING' and states[ADV]['owner_id']==OWNER
cellraw=C.read_bytes();cell=json.loads(cellraw)
boundary=('Compiled local full scalar FactC7 with exact original signature and real private finite-grid series-interchange consumer. '
 'Source-blind reconstruction is complete with ambient cues disclosed. Fresh source/whole-module/runtime/reader review remains pending. '
 'One attempted selective-source input exposed full proof/lesson context; its actual HOLD is retained and that actor is not the source verifier. A different fresh actor restarts raw-source cognition and receives only an explicit whitelist before phase3. '
 'The Poisson-kernel correspondence is a published raw conceptual candidate only, no Lean implication. C8 Gaussian expectation/closed moments/variance/bias, Krylov, true adaptive/oracle/precision/TV/deterministic-cap/expected-cost adapters, both main bounds, canonical integration/remote delivery and postmerge purification/Seal remain open.')
evidence={'result_kind':'theorem-edge','theorem_delta':cell['target_statement'],'lean_files':list(map(str,files)),
 'lean_declarations':[name],'publication_declarations':[name],'focused_checks':checkrows,
 'truth_boundary':boundary,'conceptual_mirror_audit':audit,
 'actual_consumer':'Compiled actual_inverse_grid_cosine_series materially uses new producer identity and absolute summability, weighted summability and Summable.tsum_finsetSum; actual direct public ASTIS parent is the new producer only.',
 'source_blind_decoder':'/root/decode_b4e6a1','source_VERIFIED_or_integration':False}
adv.transition_advance(ADV,'PROVED_LOCAL',worker_id=OWNER,evidence=evidence)
after=L.read_bytes();assert after.startswith(before);append=after[len(before):];assert len(append.splitlines())==1
new=adv._replay_advances([json.loads(x) for x in after.splitlines()])
assert new[ADV]['state']=='PROVED_LOCAL' and {k:v for k,v in new.items() if k!=ADV}=={k:v for k,v in states.items() if k!=ADV}
cell['status']='proved_locally';cell['evidence']['execution_boundary']=boundary
cell['evidence']['focused_checks']=list(map(str,checks))
cell['evidence']['local_proof_capsule']=str(E/'local-proof-capsule.json')
cell['evidence']['actual_compiled_public_ASTIS_producer_parents']=[]
cell['evidence']['actual_compiled_public_ASTIS_consumer_parents']=[name]
cell['evidence']['publication_binding_sha256']=json.loads(Path('research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-cosine-expansion.json').read_bytes())['publication_binding_sha256']
cell['statement_seal']['status']='EXACT_ORIGINAL_SIGNATURES_COMPILED_LOCAL_INDEPENDENT_SOURCE_REVIEW_PENDING'
cell['source_detail_audit']['gap']='Selected C7 scalar identity/absolute/uniform and actual finite-grid exchange locally discharged. Gaussian expectation identification, grid alias closed moments and later Lemma4.5 estimates remain separate. Independent fresh source/whole-module review is pending after an honestly retained input-exposure HOLD.'
cell['source_detail_audit']['fidelity_boundary']=boundary
cell['graph_contribution']['functor_view']='candidate-published'
cell['graph_contribution']['visual_review']='No website acceptance yet. A raw typed Poisson-boundary/cosine-spectrum candidate is published for independent review; no new formal dependency or model edit.'
cell['conceptual_mirror_audit']=audit
cell['reuse_plan']['known_consumers']=['Actual compiled private actual_inverse_grid_cosine_series: new producer identity/absolute summability, weighted series linearity, exact reciprocal normalization and finite-sum/tsum exchange.']
cell['reuse_plan']['searched_existing']+=['Post-admission exact Samplinglib GaussianComplexity radius/normalizer and TechnicalLemmas cosine-geometric searches found no existing C7 producer. Pinned Mathlib Complex.hasSum_re, hasSum_geometric_of_norm_lt_one and tendstoUniformly_tsum_nat were read and reused; no duplicate generic public theorem was introduced.']
(E/'frontier-before-PROVED_LOCAL.raw.json.gz').write_bytes(gzip.compress(cellraw,mtime=0))
C.write_bytes(dump(cell))
(E/'actual-PROVED_LOCAL-append.exact.jsonl').write_bytes(append)
capsule={'state':'PROVED_LOCAL_NOT_SOURCE_VERIFIED','advance_id':ADV,'owner':OWNER,
 'actual_normal_PROVED_LOCAL_API_calls':1,'actual_append_sha256':sha(append),'foreign_SAU_states_preserved':len(states)-1,
 'producer':{'declaration':name,'file':str(files[0]),'sha256':sha(files[0].read_bytes()),'actual_direct_public_ASTIS_parents':[]},
 'private_consumer':{'file':str(files[1]),'sha256':sha(files[1].read_bytes()),'actual_direct_public_ASTIS_parents':[name],'Registry_node':False},
 'actual_checks':checkrows,'exact_original_producer_and_consumer_signatures_kernel_applied':True,
 'actual_recursive_kernel_axioms':['propext','Classical.choice','Quot.sound'],
 'targeted_authored_fake_closure_scan':{'files':list(map(str,files)),'hits':0,'scope':'Targeted authored-text scan plus actual recursive kernel axioms; official aggregate gate remains integration work.'},
 'conceptual_mirror_audit':audit,'truth_boundary':boundary,'source_VERIFIED_or_integration_or_purification_or_Goal':False}
(E/'local-proof-capsule.json').write_bytes(dump(capsule))
print(json.dumps({'state':'PROVED_LOCAL','append_sha256':sha(append),'producer_sha256':capsule['producer']['sha256'],
 'consumer_sha256':capsule['private_consumer']['sha256'],'source_VERIFIED':False}))
