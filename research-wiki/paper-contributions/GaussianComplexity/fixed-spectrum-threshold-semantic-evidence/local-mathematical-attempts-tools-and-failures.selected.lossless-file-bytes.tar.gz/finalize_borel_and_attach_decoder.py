from pathlib import Path
import json,hashlib,sys,re
sys.dont_write_bytecode=True
sys.path.insert(0,'tools')
import astis_publication as pub
import astis_semantic_roundtrip as rt
W=Path(__file__).parent
E=Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-threshold-semantic-evidence')
D=Path('.astis/semantic-neutral-20261110/p_d327a1')
sha=lambda b:hashlib.sha256(b).hexdigest()
dump=lambda o:(json.dumps(o,ensure_ascii=False,indent=2)+'\n').encode()
def put(p,b):
 p=Path(p);assert not p.exists(),p
 p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
test=Path('Tests/GaussianComplexityFixedSpectrumThreshold.lean')
assert sha(test.read_bytes())=='a14b973691a8185b3d247b940f364b998cd22dc32e775f90fce6eaab78880ea8'
log=Path('.astis/huanjian-resume-20261103/20261110T044856585176Z-threshold-final-Borel-kernel-exact-types-owned-parents.log')
assert sha(log.read_bytes())=='39070d8e2b6c2f31d130174f63a4355ab5c47c4f8235d75eba546c79630a6e6e'
s=log.read_text();rows=[]
for m in re.finditer(r'^OWNED_DECL_TYPE (.+?): (.*?)\nOWNED_DECL_USED \1: (.*?)\nOWNED_DECL_AXIOMS \1: (.*?)\nOWNED_DECL_REACHABLE_FROM_ACTUAL_ROOT \1: (true|false)',s,re.M|re.S):
 n,t,u,a,r=m.groups();rows.append({'name':n,'type_raw':t,'direct_used_raw':u,'axioms_raw':a,'reachable_from_actual_root':r=='true','class':'generated-proof' if '._proof_' in n else 'compiler-simp' if '._simp_' in n else 'handwritten'})
assert len(rows)==6 and all(r['reachable_from_actual_root'] for r in rows)
assert sum(r['class']=='handwritten' for r in rows)==4 and sum(r['class']=='generated-proof' for r in rows)==2
parents=[{'root':m[1],'public_ASTIS_parents':[v.strip() for v in m[2].split(',')]} for m in re.finditer(r'^ACTUAL_PUBLIC_ASTIS_PARENTS (.+?): \[(.*?)\]',s,re.M|re.S)]
assert len(parents)==2
put(E/'actual-kernel-owned-inventory-v2-final-Borel.json',dump({'actual_kernel_log':str(log),'log_sha256':sha(log.read_bytes()),'final_Test_sha256':sha(test.read_bytes()),'both_exact_sealed_types_kernel_applied':True,'owned_declarations':rows,'actual_root_parents':parents,'all6_reachable':True,'handwritten4_generated_proof2_compiler_simp0':True,'Std3_only':True,'new_native_or_sourceV_claim':False}))
lp=Path('website/content/declaration_lessons/huanjian-fixed-spectrum-threshold.json')
oldlesson=lp.read_bytes();u=json.loads(oldlesson);u['units'][0]['steps'][5]['lean']=test.read_text()
u['units'][0]['steps'][5]['detail']+=' The actual polynomial statistic is explicitly Borel measurable; this proof is consumed in the MemLp input, so measurability is not supplied as an event/moment certificate.'
u['units'][0]['mathlib_dependencies']+=['EuclideanSpace.proj','Finset.measurable_sum','MeasureTheory.memLp_const']
put(E/'lesson-before-explicit-Borel.raw.json',oldlesson);lp.write_bytes(dump(u))
ap=Path('research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-threshold.json');oldaudit=ap.read_bytes();a=json.loads(oldaudit)
assert a['state']=='draft' and a['reconstruction']=={}
put(E/'audit-before-explicit-Borel-context.raw.json',oldaudit)
pub.inputs.cache_clear();pub.load.cache_clear()
item=json.loads(Path('website/content/publications/huanjian-fixed-spectrum-threshold.json').read_bytes())['items'][0];binding=item['bindings'][0]
a['publication_binding_sha256']=pub.binding_digest(item,binding);a['publication_context']=pub.review_context(item,binding)
packet=rt.decoder_packet(a);oldpacket=json.loads((D/'input.json').read_bytes())
assert packet==oldpacket and packet['packet_sha256']=='f4610d53140ca98bedb204d182dbea2e515b0d5db8422b1e099d53acbbed5036'
runfile=D/'decoder_run.1988ec7c55ab1dbb8b8fe478692b34f87f93c9c99039ab2768d1fe7ec5f72ba2.json';runsha='1988ec7c55ab1dbb8b8fe478692b34f87f93c9c99039ab2768d1fe7ec5f72ba2'
assert sha(runfile.read_bytes())==runsha;r=json.loads(runfile.read_bytes())
recraw=(D/'reconstruction.json').read_bytes();assert sha(recraw)=='20986fa8b0343aed5ba5a7ad2fa47fe739d17dc7529a2aaa643c235670a13ba5'
assert recraw==(D/'reconstruction.20986fa8b0343aed5ba5a7ad2fa47fe739d17dc7529a2aaa643c235670a13ba5.json').read_bytes()
rec=json.loads(recraw);text=rec['reconstructed_theorem_text']
assert rec['source_text_visible'] is False and rec['decoder_run_sha256']==runsha
assert sha(text.encode())==rec['reconstructed_text_sha256']==r['reconstructed_text_sha256']=='54d1bf4eae3d4f61006759ee848ad310f39e7b83bd836b4ac19b4b5bb5c7ed2a'
assert rec['actor_identity']==r['actor_identity']=='/root/neutral_decoder_07b3f1'
assert sha((D/'input.json').read_bytes())==r['input']['actual_raw_sha256']=='db97da73f0d05fda8537fb8869748746e78c181d7f759cbf5c2e36441581fef0'
assert rec['packet_sha256']==r['input']['packet_sha256']==packet['packet_sha256']
assert r['exposure']['original_source_text_visible'] is False and r['exposure']['other_data_artifact_reads']==[]
a['state']='blind-reconstructed'
a['reconstruction']={'text':text,'text_sha256':sha(text.encode()),'decoder':r['actor_identity'],'source_text_visible':False,'lean_statement_sha256':a['lean']['statement_sha256'],'decoder_packet_sha256':packet['packet_sha256'],'decoder_run_sha256':runsha,'input_artifacts':packet['input_artifacts'],'ambient_cues_disclosed':[json.dumps(r['exposure'],ensure_ascii=False)],'zero_ambient_cues_claimed':False}
for fn in ['input.json',runfile.name,'reconstruction.json','reconstruction.20986fa8b0343aed5ba5a7ad2fa47fe739d17dc7529a2aaa643c235670a13ba5.json']:
 put(E/'independent-decoder-07b3f1'/fn,(D/fn).read_bytes())
ap.write_bytes(dump(a))
pub.check_advance([a['lean']['declaration']],reviewed=False)
full=rt.semantic_reviewer_packet(a);assert all(v is False for v in full['anti_anchoring'].values())
put(E/'fresh-source-reviewer-packet.json',dump(full))
S=json.loads((W/'statement-seal-v1.json').read_bytes());head,body=S['actual_private_consumer']['signature'].split(' :\n',1)
consumer='∀ '+head.removeprefix('private theorem actual_gaussian_source_query_shifted_event_le_tenth').strip()+',\n'+body
white={'schema_version':1,'task':'selective-source-statement-reconstruction-comparison','parent_canonical_packet_sha256':full['packet_sha256'],'source':{k:full['source'][k] for k in ['source_id','anchor','original_text','text_sha256']},'lean_statement':{k:full['lean'][k] for k in ['statement','statement_sha256']},'approved_definition_context':a['lean']['decoder_context'],'blind_reconstruction':{k:full['blind_reconstruction'][k] for k in ['text','text_sha256','decoder','decoder_packet_sha256','decoder_run_sha256','source_text_visible']},'private_consumer_statement':consumer,'private_scope_note':'PRIVATE numerical-C-family actual shifted diagonal-Gaussian <=0 bad-event only; no source absolute concentration-C witness, rotated polynomial detector, algorithm/oracle/TV/cost or full Ex26/Main claim. C fixed before delta and natural cutoff; source main gains no C premise.','private_standard_definition_context':['ENNReal.toReal is the usual real conversion with zero at infinity; genuine finite-mass interpretation must be internally justified.','The private statement has the same literal inverse-precision Gaussian and coordinate cosine quadratic. Its threshold is the exact displayed two-term formula; positivity, moments, uniform signal mass and event probability are not inputs.']}
assert b' := by' not in dump(white)
put(W/'strict-selective-phase2-input.json',dump(white));put(E/'strict-selective-phase2-input.json',dump(white))
oldrec=json.loads((E/'publication-draft-record.json').read_bytes());v2={**oldrec,'Test_raw_sha256':sha(test.read_bytes()),'publication_binding_sha256':a['publication_binding_sha256'],'final_kernel_inventory':'actual-kernel-owned-inventory-v2-final-Borel.json','anonymous_packet_and_decoder_input_unchanged':True,'decoder':'completed-source-blind-no-source-verdict','full_reviewer_packet_canonical_sha256':full['packet_sha256'],'strict_whitelist_raw_sha256':sha(dump(white))}
v2['exact_step_code_records'][-1]['code_sha256']=sha(test.read_bytes())
put(E/'publication-draft-record-v2-final-Borel.json',dump(v2))
put(E/'explicit-Borel-implementation-revision.json',dump({'old_Test_sha256':'4243eb2c4e1c8bc99e6b6f0373ff90cc1e09c3fcd05bdbab8fca0d6374cfe0e4','new_Test_sha256':sha(test.read_bytes()),'exact_sealed_statements_unchanged':True,'reason':'Make actual polynomial Borel measurability explicit and consumed by MemLp, before independent proof/source/native review. The first actual producer/Test/kernel successes remain historical; final Test/native/kernel are separately bound.','source_proof_route_unchanged':'centered pointwise Young plus genuine Chebyshev','old_binding_sha256':json.loads(oldaudit)['publication_binding_sha256'],'new_binding_sha256':a['publication_binding_sha256'],'anonymous_input_and_independent_decoder_unchanged':True,'no_prior_source_verdict_existed':True,'no_new_sourceV_or_global_claim':True}))
print(json.dumps({'state':a['state'],'binding_sha256':a['publication_binding_sha256'],'full_reviewer_packet_canonical_sha256':full['packet_sha256'],'strict_whitelist_sha256':sha(dump(white)),'final_Test_sha256':sha(test.read_bytes()),'decoder_input_unchanged':True,'source_review_or_sourceV':False}))
