from pathlib import Path
import sys,subprocess,json,datetime,time,hashlib,base64,os,stat
root=Path("/Users/zhouhuanjian/ASTIS-GC/.astis/semantic-neutral-20261111/kr_src_c47e12")
p2=root/'phase2'
h=lambda b:hashlib.sha256(b).hexdigest()
child_code=r"""from pathlib import Path
import json,hashlib,stat,datetime
root=Path("/Users/zhouhuanjian/ASTIS-GC/.astis/semantic-neutral-20261111/kr_src_c47e12");p1=root/'phase1';p2=root/'phase2'
h=lambda b:hashlib.sha256(b).hexdigest()
hm=p1/'hash-manifest.json'
assert h(hm.read_bytes())=='a167e2a7d8d37008db6c3ba80e23598c86479896be084604ce46bdb9b16b3741'
m=json.loads(hm.read_text())
for r in m['files']:
 path=p1/r['path'];b=path.read_bytes()
 assert h(b)==r['sha256'] and len(b)==r['bytes'] and stat.S_IMODE(path.stat().st_mode)==0o444,r['path']
assert {str(x.relative_to(p1))for x in p1.rglob('*')if x.is_file()}=={r['path']for r in m['files']}|{'hash-manifest.json'}
assert stat.S_IMODE(hm.stat().st_mode)==0o444
assert all(stat.S_IMODE(x.stat().st_mode)==0o555 for x in [p1]+[x for x in p1.rglob('*')if x.is_dir()])
p1rec={'time_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'phase1_manifest_sha256':h(hm.read_bytes()),'total_files':84,'exact_file_set':True,'all_file_bytes_and_modes_unchanged':True,'all_directories_0555':True}
(p2/'phase1-unchanged-at-final-freeze.json').write_text(json.dumps(p1rec,indent=2)+'\n')
jf=p2/'judgment-freeze.json'
assert h(jf.read_bytes())=='cc259acc304489dc418b4f703fdfc78392a42d9f189e6fe6257fa757ad55e4d4'
j=json.loads(jf.read_text())
for r in j['core_artifacts']:
 b=(p2/r['path']).read_bytes()
 assert h(b)==r['sha256'] and len(b)==r['bytes'],r['path']
assert h((p2/'selective-types-and-definitions.json').read_bytes())=='471d8f4351d80f33d478049a0a2d8716689b2140c043aa324d8132f9b3fb79cb'
receipts=0
for rp in sorted((p2/'audit').glob('*.receipt.json')):
 r=json.loads(rp.read_text())
 for k in ['stdout','stderr']:
  b=(rp.parent/r[k]['path']).read_bytes()
  assert h(b)==r[k]['sha256'] and len(b)==r[k]['bytes']
 receipts+=1
print(json.dumps({'pre_freeze_validation':'PASS','phase1_all84_unchanged':True,'phase2_judgment_and_packet_unchanged':True,'raw_command_receipts_valid':receipts,'phase3_seen':False},indent=2))
"""
started=datetime.datetime.now(datetime.timezone.utc).isoformat();t0=time.monotonic()
argv=['/opt/anaconda3/bin/python','-c',child_code]
r=subprocess.run(argv,cwd='/Users/zhouhuanjian/ASTIS-GC',stdout=subprocess.PIPE,stderr=subprocess.PIPE)
rec={'schema':'original-phase2-final-execution-receipt-v1','wrapper_argv':sys.argv,'wrapper_file_sha256':h(Path(__file__).read_bytes()),'child_argv':argv,'cwd':'/Users/zhouhuanjian/ASTIS-GC','started_utc':started,'ended_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'elapsed_seconds':time.monotonic()-t0,'exit_code':r.returncode,'stdout_raw_base64':base64.b64encode(r.stdout).decode('ascii'),'stderr_raw_base64':base64.b64encode(r.stderr).decode('ascii'),'stdout_sha256':h(r.stdout),'stderr_sha256':h(r.stderr),'note':'Exact subprocess byte streams, no normalization. This receipt precedes the detached complete hash manifest, which includes this receipt. Final closure reporting appears in the tool transcript.','phase3_seen':False,'verifier_transition':False}
rp=p2/'original-execution-receipt.json'
rp.write_text(json.dumps(rec,indent=2)+'\n')
sys.stdout.buffer.write(r.stdout);sys.stdout.buffer.flush()
sys.stderr.buffer.write(r.stderr);sys.stderr.buffer.flush()
if r.returncode:raise SystemExit(r.returncode)
rows=[]
for path in sorted(p2.rglob('*')):
 if path.is_file() and path.name!='hash-manifest.json':
  assert not path.is_symlink(),str(path)
  os.chmod(path,0o444);b=path.read_bytes()
  rows.append({'path':str(path.relative_to(p2)),'bytes':len(b),'sha256':h(b),'mode':'0444'})
manifest={'schema':'immutable-phase2-complete-manifest-v1','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reviewer':'/root/krylov_fresh_source_c47e12','scope':'Every phase2 file except this detached manifest itself, including supplied packet, independent judgment, all raw command streams/receipts, final unchanged evidence and original final execution receipt.','packet_sha256':'471d8f4351d80f33d478049a0a2d8716689b2140c043aa324d8132f9b3fb79cb','judgment_freeze_sha256':'cc259acc304489dc418b4f703fdfc78392a42d9f189e6fe6257fa757ad55e4d4','phase1_manifest_sha256':'a167e2a7d8d37008db6c3ba80e23598c86479896be084604ce46bdb9b16b3741','phase1_all84_unchanged':True,'files':rows,'file_mode':'0444','directory_mode':'0555','before_implementation_exposure':True,'phase3_seen':False,'verifier_transition':False}
mp=p2/'hash-manifest.json';mp.write_text(json.dumps(manifest,indent=2)+'\n');os.chmod(mp,0o444)
for d in sorted([x for x in p2.rglob('*')if x.is_dir()],key=lambda x:len(x.parts),reverse=True):os.chmod(d,0o555)
os.chmod(p2,0o555)
for path in [p2]+list(p2.rglob('*')):
 expected=0o555 if path.is_dir() else 0o444
 assert stat.S_IMODE(path.stat().st_mode)==expected,str(path)
for row in rows:
 b=(p2/row['path']).read_bytes()
 assert h(b)==row['sha256'] and len(b)==row['bytes']
print(json.dumps({'phase2_manifest_sha256':h(mp.read_bytes()),'phase2_judgment_freeze_sha256':'cc259acc304489dc418b4f703fdfc78392a42d9f189e6fe6257fa757ad55e4d4','typed_judgment_sha256':h((p2/'typed-mathematical-judgment.json').read_bytes()),'original_execution_receipt_sha256':h(rp.read_bytes()),'files_in_manifest':len(rows),'total_frozen_files':len(rows)+1,'all_files_0444_and_dirs_0555':True,'phase1_all84_unchanged':True,'phase3_seen':False,'exit_code':0},indent=2))

