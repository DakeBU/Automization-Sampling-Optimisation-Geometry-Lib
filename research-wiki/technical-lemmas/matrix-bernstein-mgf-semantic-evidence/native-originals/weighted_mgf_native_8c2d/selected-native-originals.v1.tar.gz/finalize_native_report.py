#!/usr/bin/env python3
"""Seal independent native results and a bounded evidence-selection manifest."""
import datetime as dt
import hashlib
import json
import pathlib
import subprocess

OWN = pathlib.Path(__file__).resolve().parent
REPO = OWN.parents[2]
CANDIDATE = '4869db55d340cee39f0ba4d49fb0a7a4309ba2d6'

def sha(path):
    return hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()

def git(*args):
    return subprocess.check_output(['git', '--no-optional-locks', *args], cwd=REPO)

def write_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

def main():
    assignment_path = OWN / 'native-command-assignment.json'
    assignment = json.loads(assignment_path.read_text())
    commands_file = OWN / assignment['commands']['path']
    assert sha(commands_file) == assignment['commands']['sha256']
    commands = json.loads(commands_file.read_text())
    closure = json.loads((OWN / 'actual-import-closure.json').read_text())
    packages = json.loads((OWN / 'verified-package-inputs.json').read_text())
    parent_file = OWN / 'actual-canonical-parent-witnesses.v1.json'
    parent_report = json.loads(parent_file.read_text())
    kernel_file = OWN / 'native-raw-roundtrip/native-kernel-summary.json'
    kernel = json.loads(kernel_file.read_text())
    assert kernel['pinned_candidate'] == CANDIDATE and kernel['only_standard_axioms'] and kernel['JSON_DAG_full_structural_roundtrip_and_decoded_value_kernel_checks']
    assert len(kernel['literal_target_checks']) == 4
    assert all(row.get('full_actual_proof_value_kernel_checked_against_literal', row.get('full_value_kernel_checked')) for row in kernel['literal_target_checks'])
    receipts = []
    for path in sorted((OWN / 'native-command-receipts').glob('*.receipt.json')):
        receipt = json.loads(path.read_text())
        assert receipt['assignment_sha256'] == sha(assignment_path)
        assert receipt['candidate_commit_compiled'] == CANDIDATE
        assert receipt['exit_code'] == 0
        assert receipt['argv'] == commands[receipt['command_id']]['argv']
        assert receipt['environment'] == commands[receipt['command_id']]['environment']
        for field in ['stdout', 'stderr']:
            raw = OWN / receipt[field]['path']
            assert raw.stat().st_size == receipt[field]['bytes'] and sha(raw) == receipt[field]['sha256']
        receipts.append({'path': str(path.relative_to(OWN)), 'sha256': sha(path), **receipt})
    assert len(receipts) == len(commands) == 16
    assert {row['command_id'] for row in receipts} == set(commands)
    modules = []
    allowed = {'propext', 'Classical.choice', 'Quot.sound'}
    for path in sorted((OWN / 'native-raw-roundtrip').glob('*.json')):
        data = json.loads(path.read_text())
        if 'declarations' not in data:
            continue
        assert data['constNames'] == [row['name'] for row in data['declarations']]
        for row in data['declarations']:
            assert row['kernel_type_checked'] and row['kernel_value_checked']
            assert row['value_root'] is not None and not row['unsafe']
            assert set(row['axioms']) <= allowed
            assert row['emitter'] == data['module']
            assert row['first_owner'] == data['module']
        modules.append({'module': data['module'], 'raw_DAG_file': str(path.relative_to(OWN)), 'raw_DAG_sha256': sha(path), 'raw_DAG_bytes': path.stat().st_size, 'raw_declarations': len(data['declarations']), 'all_closed_types_and_values_kernel_checked': True, 'full_JSON_DAG_structural_roundtrip': True, 'first_owner_and_emitter_all_exact': True, 'raw_extraConstNames': data['extraConstNames'], 'expression_nodes': len(data['expression_nodes'])})
    production = [row for row in modules if row['module'] != 'NativeLiteralApplications']
    assert len(production) == closure['module_count_derived_not_assumed'] == 13
    assert all(not row['raw_extraConstNames'] for row in production)
    assert sum(row['raw_declarations'] for row in production) == 76
    for row in closure['modules']:
        archived = OWN / 'candidate-4869db55' / row['path']
        assert sha(archived) == row['sha256']
        assert git('rev-parse', CANDIDATE + ':' + row['path']).decode().strip() == row['git_oid']
    old_r13 = []
    for path, expected in [
        ('AutoSamplingTheory/TechnicalLemmas/Probability/MatrixBernsteinExponential.lean', '7fc1996495b439c1b0aa53a3e69b6b4547952a42ee5f721834b6a1092430f6cc'),
        ('Tests/GaussianComplexityBernsteinMgf.lean', '66bcf7750e8a70f6d69cea4bb08513f78364c3c3583862c119ffe4ff9cc9d883'),
    ]:
        assert sha(REPO / path) == expected
        old_r13.append({'path': path, 'sha256': expected, 'unchanged': True})
    new_target_current_bytes = []
    for row in closure['modules']:
        if row['module'] in [closure['P'], closure['T']]:
            current_sha = sha(REPO / row['path'])
            assert current_sha == row['sha256']
            new_target_current_bytes.append({'path': row['path'], 'immutable_candidate_sha256': row['sha256'], 'live_worktree_sha256': current_sha, 'matches_frozen_candidate': True})
    report = {
        'schema': 'independent-weighted-mgf-native-report-v1',
        'status': 'NATIVE_CODE_FIRST_ACCEPTED;READER_AND_SOURCE_VERIFICATION_SEPARATE',
        'reviewer': '/root/gaussian_push_audit_c7b1', 'assigned_native_role': 'weighted_mgf_native_8c2d',
        'sealed_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
        'immutable_candidate_compiled': CANDIDATE,
        'observed_repository_HEAD_at_archive': closure['observed_repository_HEAD_at_archive'],
        'observed_repository_HEADs_during_commands': sorted({row[key] for row in receipts for key in ['observed_repository_HEAD_before', 'observed_repository_HEAD_after']}),
        'observed_repository_HEAD_at_report': git('rev-parse', 'HEAD').decode().strip(),
        'HEAD_observation_boundary': 'All native commands compiled archived immutable4869 source bytes. Observed live repository HEAD is recorded separately and is never substituted as build identity.',
        'admission_receipt': assignment['admission_receipt'], 'admission_is_not_mathematical_acceptance': True,
        'expectation_freeze_sha256': sha(OWN / 'native-expectations.v1.md'),
        'runner_sha256': sha(OWN / 'native_runner.py'), 'assignment_sha256': sha(assignment_path), 'command_contract_sha256': sha(commands_file),
        'actual_import_closure': {'path': 'actual-import-closure.json', 'sha256': sha(OWN / 'actual-import-closure.json'), 'derived_project_module_count': 13, 'all_freshly_rebuilt': True, 'root_or_old_ASTIS_artifacts_reused': False},
        'upstream_inputs': {'path': 'verified-package-inputs.json', 'sha256': sha(OWN / 'verified-package-inputs.json'), 'manifest_pinned_packages': 9, 'independently_rehashed_artifact_files': packages['artifact_file_count'], 'independently_rehashed_artifact_bytes': packages['artifact_bytes'], 'readonly_reuse_only': True, 'package_bytes_copied': 0, 'upstream_packages_not_claimed_rebuilt': True},
        'raw_production_module_declarations_checked': 76,
        'raw_auxiliary_harness_logical_declarations_checked': sum(row['raw_declarations'] for row in modules if row['module'] == 'NativeLiteralApplications'),
        'raw_production_extraConstNames_count': 0,
        'auxiliary_extraConstNames_boundary': 'The harness extraConstNames array is retained verbatim in its raw module export; it consists of compiler implementation names separate from ModuleData.constants logical declarations. No extra names occur in any of the13 production closure modules. Complete logical ConstantInfo types/values are kernel checked.',
        'inventory_counts_are_not_additional_mathematical_results': True,
        'complete_type_value_DAGs_and_first_owner_emitter': modules,
        'kernel_summary': {'path': str(kernel_file.relative_to(OWN)), 'sha256': sha(kernel_file), 'full_structural_roundtrip_and_decoded_type_value_kernel_check': True},
        'literal_target_checks': kernel['literal_target_checks'],
        'allowed_transitive_axioms': sorted(allowed), 'nonstandard_axioms': [], 'unsafe_production_or_harness_logical_declarations': [],
        'literal_signature_source_match': {'path': 'literal-signature-source-match.json', 'sha256': sha(OWN / 'literal-signature-source-match.json')},
        'actual_parent_witnesses': {'path': str(parent_file.relative_to(OWN)), 'sha256': sha(parent_file), 'weighted_T_materially_calls_new_P': True, 'P_materially_calls_existing_canonical_deterministic_bound': True, 'imports_not_used_as_theorem_parent_evidence': True, 'generated_same_module_abel_support_not_counted_as_public_parent': True},
        'independent_code_first_findings': [
            'P retains arbitrary probability measure, finite nonempty real matrix carrier, explicit source-standing measurability/X/X-squared integrability, almost-sure Hermitian and one-sided cap, true zero mean, and every positive s. No lower eigenvalue bound or two-sided cap was introduced.',
            'P proves exp(sX) measurability and integrability via actual CFC spectral upper cap, not nonintegrable-integral default zero. It uses genuine Bochner integral algebra and the existing deterministic exponential and PSD-integral parents, then proves the actual exp(C)-(I+C) adapter internally.',
            'T retains the literal original unconditional product Gaussian law, inclusive row truncation, unconditional mean, original rho and signed cosine weight. Weighted norm control, cap, Hermitian property, rho positivity, integrability of actual X and X-squared, and actual mean zero are derived internally.',
            'The complete literal universal P and private weighted T proof values kernel check. Additional literal applications retain q=0 at every admissible dimension and the smallest d=2,q=0 case, with arbitrary positive s and actual row quantification.',
            'Actual L2 matrix norm equals the Euclidean CLM norm; actual matrix topology/uniformity, standard-Borel context, rational matrix algebra/exponential series and original Gaussian probability-instance auxiliary checks all compile and their complete values kernel check.',
            'T obtains but does not use the independence component of its structure parent. This single-summand result supplies no noncommutative sum tail, matrix Bernstein master theorem, C6 or Lemma4.4.',
        ],
        'receipts': receipts,
        'native_command_count': 16, 'all_native_command_exit_codes_zero': True,
        'raw_outputs_separate_unmodified_and_hash_checked': True,
        'native_target_compile_or_kernel_failures': [],
        'preserved_nonmathematical_observations': ['Minimal host environment makes git observed-HEAD bookkeeping emit DARWIN_USER_TEMP_DIR/confstr warnings outside the Lean subprocess streams; all16 exact Lean subprocess stdout/stderr files remain raw and all exit codes are0.', 'Preparation runner refusal(exit2) was an expected no-assignment self-check, not a mathematical/native target failure.'],
        'old_R13_P_T_unchanged': old_r13,
        'new_P_T_current_bytes_match_immutable_candidate_at_report': new_target_current_bytes,
        'source_fidelity_review_performed': False, 'source_reviewer_or_blind_decoder_role_claimed': False,
        'normal_API_or_ledger_frontier_writes': 0, 'browser_or_reader_execution_calls': 0, 'metadata_gates_run': 0,
        'production_or_shared_site_writes': 0,
        'boundary': 'Independent native code-first/compiler/kernel acceptance only. No source VERIFIED, reader/browser acceptance, canonical integration/root aggregate build, sum tail/C6/Lemma4.4/main lower bounds, purification or whole-Goal completion.',
    }
    report_path = OWN / 'native-mathematics-report.v1.json'
    write_json(report_path, report)
    public_environment = {'schema': 'bounded-native-environment-receipt-v1', 'candidate_compiled': CANDIDATE, 'lean_toolchain_sha256': sha(OWN / 'candidate-4869db55/lean-toolchain'), 'lake_manifest_sha256': sha(OWN / 'candidate-4869db55/lake-manifest.json'), 'package_count': 9, 'package_revisions_and_artifact_counts': [{k: row[k] for k in ['name', 'expected_revision', 'actual_revision', 'tracked_source_clean', 'verified_artifact_file_count', 'verified_artifact_bytes', 'artifact_membership_exact', 'readonly_reuse_only', 'copied']} for row in packages['packages']], 'artifact_seal_external_sha256': packages['reference_artifact_seal_sha256'], 'full_package_artifact_inventory_not_copied': True, 'root_ASTIS_cache_not_used': True}
    write_json(OWN / 'native-environment-bounded-receipt.v1.json', public_environment)
    selected = set()
    for path in (OWN / 'candidate-4869db55').rglob('*'):
        if path.is_file():
            selected.add(path)
    for path in (OWN / 'native-command-receipts').iterdir():
        if path.is_file():
            selected.add(path)
    for path in (OWN / 'native-raw-roundtrip').iterdir():
        if path.is_file():
            selected.add(path)
    for name in ['native_runner.py', 'native-expectations.v1.md', 'runner-contract.v1.md', 'native-command-assignment.json', 'native-commands.v1.json', 'archive_candidate_and_verify_packages.py', 'freeze_native_execution.py', 'run_native_sequence.py', 'derive_native_parent_witnesses.py', 'finalize_native_report.py', 'actual-import-closure.json', 'literal-signature-source-match.json', 'actual-canonical-parent-witnesses.v1.json', 'native-output-initialized.json', 'native-mathematics-report.v1.json', 'native-environment-bounded-receipt.v1.json', 'verified-package-inputs.json']:
        selected.add(OWN / name)
    selected.update(path for path in (OWN / 'immutable-inputs').iterdir() if path.is_file())
    selected.update(path for path in (OWN / 'harness').iterdir() if path.is_file())
    manifest = {'schema': 'bounded-native-selected-originals-v1', 'candidate_commit': CANDIDATE, 'archive_created': False, 'selection_scope': 'Exact candidate ASTIS source closure/config/protocols, native runner/harness/command/raw stdout-stderr/kernel-DAG/parent-witness/report originals only. No package cache, full artifact inventory, private index/state/whole guards, peer build outputs or duplicate old native archive.', 'files': [{'path': str(path.relative_to(OWN)), 'bytes': path.stat().st_size, 'sha256': sha(path)} for path in sorted(selected)], 'file_count': len(selected), 'total_bytes': sum(path.stat().st_size for path in selected), 'local_only_environment_preparation_and_global_fingerprint_reports_excluded': True, 'no_package_bytes_or_existing_R13_archive_copied': True}
    dest = OWN / 'native-selected-originals.manifest.v1.json'
    write_json(dest, manifest)
    print(json.dumps({'status': report['status'], 'report': str(report_path), 'report_sha256': sha(report_path), 'actual_parent_witness_sha256': sha(parent_file), 'closure_modules': 13, 'production_declarations_kernel_checked': 76, 'native_commands': 16, 'selected_manifest_sha256': sha(dest), 'selected_file_count': len(selected), 'selected_bytes': manifest['total_bytes'], 'archive_created': False}, indent=2))

if __name__ == '__main__':
    main()
