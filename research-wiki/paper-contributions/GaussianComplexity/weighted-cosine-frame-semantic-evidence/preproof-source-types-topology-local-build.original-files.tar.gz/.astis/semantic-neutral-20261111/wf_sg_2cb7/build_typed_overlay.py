from pathlib import Path
import hashlib
import json
from datetime import datetime, timezone

ROOT = Path('/Users/zhouhuanjian/ASTIS-GC')
BASE = ROOT / '.astis/semantic-neutral-20261111/wf_sg_2cb7'
OUT = BASE / 'typed_overlay'
PACKET = ROOT / '.astis/huanjian-gc-weighted-cosine-frame-20261112/selective-type-definition-packet.json'
RAW_FREEZE_SHA = 'bcc921a94fd9d552fbc9e410eb3cce1731b5234fc5a073412cb13026c8ad0d56'
PACKET_SHA = 'e1db7fbd954113035a90a60331d6430f4c116c4055e65de15899c30a2ebdb4e1'

def sha(b):
    return hashlib.sha256(b).hexdigest()

raw_freeze_bytes = (BASE / 'RAW_FREEZE.json').read_bytes()
assert sha(raw_freeze_bytes) == RAW_FREEZE_SHA
raw_freeze = json.loads(raw_freeze_bytes)
for item in raw_freeze['files']:
    b = (BASE / item['path']).read_bytes()
    assert len(b) == item['bytes'] and sha(b) == item['sha256'], item['path']
packet_bytes = PACKET.read_bytes()
assert sha(packet_bytes) == PACKET_SHA
packet = json.loads(packet_bytes)
for slot in ['producer','actual_private_consumer']:
    assert sha(packet[slot]['signature'].encode()) == packet[slot]['signature_sha256'], slot
context = packet['minimal_definition_context']
for a,b in [('literal_current_prints_and_instances','literal_current_prints_sha256'),('literal_shared_canonical_definition_prints','literal_shared_canonical_definition_prints_sha256'),('literal_shared_PSD_and_product_prints','literal_shared_PSD_and_product_prints_sha256')]:
    assert sha(context[a].encode()) == context[b], a

OUT.mkdir(exist_ok=True)
(OUT / 'selective-type-definition-packet.exact.json').write_bytes(packet_bytes)

def write(name, obj):
    (OUT / name).write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n')

raw_graph = json.loads((BASE / 'source_proof_graph.json').read_text())
raw_coverage = json.loads((BASE / 'component_coverage.json').read_text())
raw_locators = json.loads((BASE / 'source_locators.json').read_text())

manifest = {
    'phase':'SELECTIVE_TYPED_OVERLAY_AFTER_RAW_FREEZE',
    'raw_freeze_sha256':RAW_FREEZE_SHA,
    'raw_file_recheck':{'files_checked':len(raw_freeze['files']),'status':'all unchanged'},
    'exact_selective_packet':{'source_path':str(PACKET.relative_to(ROOT)),'snapshot':'typed_overlay/selective-type-definition-packet.exact.json','bytes':len(packet_bytes),'sha256':PACKET_SHA},
    'signatures':{k:{'name':packet[k]['name'],'signature_sha256':packet[k]['signature_sha256']} for k in ['producer','actual_private_consumer']},
    'raw_graph_sha256':sha((BASE / 'source_proof_graph.json').read_bytes()),
    'raw_coverage_sha256':sha((BASE / 'component_coverage.json').read_bytes()),
    'raw_locators_sha256':sha((BASE / 'source_locators.json').read_bytes()),
    'allowed_input_scope':'Only the selective packet and canonical definitions it embeds were newly read. Embedded receipt paths, provenance paths and source file references were not followed.',
    'not_read':['implementation/API candidates','root statement verdicts','topology challenger reports','old SAU proofs','new compiler output or implementation history'],
    'role':'independent source-graph/type-definition auditor; not the mathematical prover',
    'original_filename_exposure':'The raw manifest preserves the earlier filename-only discovery exposure. No additional prior-packet or implementation content was opened during this phase.',
}
write('typed_input_manifest.json',manifest)

binder_audit = {
    'status':'no EXCESS input binder found in either sealed signature',
    'scope':'Statement and definition semantics only; no target implementation exists in this packet, and no proof acceptance is issued.',
    'classification_rule':'SOURCE/STANDING are source-justified mathematical inputs; TYPING are carriers/standard structures; local let definitions define objects rather than add assumptions. Proof ingredients must remain internal dependency edges.',
    'common_binders':[
        {'binder':'{d : Nat}','class':'TYPING','meaning':'Finite physical dimension; hq internally entails d>=2 and d!=0. No positivity binder is added.','source':['S4.Thmtheorem3.p1','S4.Thmtheorem4.p1','A3.SS2.p1']},
        {'binder':'{q : Nat}','class':'TYPING + SOURCE','meaning':'Nonnegative integer query degree; q=0 is included. Natural q realizes the source integer q>=0 convention.','source':['S4.Thmtheorem3.p1','S4.Thmtheorem4.p1']},
        {'binder':'hq : 2*q+1<d','class':'STANDING','meaning':'The enclosing Lemma 4.4/source C.2 dimension restriction; it yields all needed positive denominators and frequency bounds.','source':['S4.Thmtheorem4.p1','A3.SS2.p5']},
    ],
    'producer_local_lets':[
        {'let':'r','kind':'literal','meaning':'Real cast of the natural cardinal q+1; not a free parameter or a moment hypothesis.'},
        {'let':'theta','kind':'literal','meaning':'Zero-based source reindexing: i_source=i.val+1 makes (i_source-1/2)pi/d equal (i.val+1/2)pi/d.'},
        {'let':'t','kind':'literal','meaning':'Frequency zero is 1; positive frequencies through q are sqrt(2)cos(k theta_i). The if has exactly source semantics on the entire Fin(q+1) carrier.'},
        {'let':'S','kind':'literal','meaning':'The explicit sum of coordinate squares is source Euclidean ||t_i||^2. It does not use a potentially different norm on the function type Fin(q+1)->R.'},
        {'let':'feature','kind':'literal','meaning':'vecMulVec t_i t_i has entry t_i[a]t_i[b], the source rank-one matrix.'},
        {'let':'N','kind':'typing','meaning':'Real square matrices on Fin(q+1) x Fin(q+1), matching r^2 paired coordinates.'},
        {'let':'B','kind':'literal','meaning':'The deterministic Ex115 RHS: ((r+2)/d^2) sum_i S_i (I_r tensor feature_i). This local B is not the source rectangular random B.'},
        {'let':'C','kind':'literal','meaning':'Exact scalar 2r(r+2)/d. This local C is not the source unspecified absolute constant in tau.'},
    ],
    'consumer_additional_local_lets':[
        {'let':'E','kind':'literal carrier','meaning':'EuclideanSpace R (Fin(q+1)) = PiLp 2 with Euclidean norm and Borel structure.'},
        {'let':'mu','kind':'canonical law','meaning':'stdGaussian E is the fixed standard Gaussian law constructed as the orthonormal-basis image of the product of variance-one Gaussian coordinates. No arbitrary law or Gaussian-law premise is smuggled in.'},
        {'let':'R','kind':'literal','meaning':'Euclidean norm squared of the canonical row variable.'},
        {'let':'L','kind':'literal','meaning':'2r+3 log(1000d), with the exact source constants. The cutoff positivity needed by any chosen proof route is derivable rather than an extra binder.'},
        {'let':'G','kind':'literal','meaning':'The ordinary real outer product of the canonical Euclidean coordinates WithLp.ofLp x.'},
        {'let':'Y','kind':'literal marginal counterpart','meaning':'The closed radial cutoff multiplies the source inverse-d-scaled Gaussian/feature Kronecker outer product; it is zero outside the event and has no retained-mass normalization.'},
        {'let':'secondSum','kind':'literal marginal sum','meaning':'Sum_i integral_E (Y_i(x)*Y_i(x)) dmu. This is a finite sum of individual canonical marginal second moments, not a constructed d-row random experiment.'},
    ],
    'conclusions':[
        {'signature':'producer','meaning':'PosSemidef(C I_N-B), the exact deterministic Loewner comparison from the first RHS of EGx11 to its final bound.'},
        {'signature':'consumer','meaning':'Every squared truncated row integrand is Bochner integrable, and PosSemidef(C I_N-secondSum). Integrability is an output, not a premise.'},
    ],
    'must_remain_internal_dependencies':['feature norm bound','unweighted cosine Gram identity','raw coefficient comparison','identity-tensor order/linearity port','nonnegative scaling port','paired-index identity normalization','nonzero-denominator scalar normalization','canonical radial fourth matrix moment','canonical finite fourth-moment/integrability facts','matrix-square identity','PSD indicator removal','expectation-order and finite-sum transport'],
    'not_licensed_as_added_binders':['Gaussian fourth-moment certificate','feature Gram/norm certificate','integrability certificate','PSD truncation certificate','original-family row law or joint coupling certificate','tau<=1/2','q>0','kappa parameter or bounds','Bernstein or concentration event'],
    'implicit_structure_audit':'Only canonical finite real matrix, Euclidean, measure and norm structures are present in the supplied definitions. No project-owned Prop alias or bundled assumption appears in these signatures.',
}
write('binder_definition_audit.json',binder_audit)

definition_audit = {
    'kind':'All object formulas are literal/canonical; no characterized choice or quotient representative is introduced.',
    'source_zero_based_reindexing':{'row':'i_source=i.val+1','frequency':'k_source=k.val in 0..q','dimension':'r_nat=q+1, r_real=(r_nat:R)'},
    'semantics':[
        {'definition':'Finite sum','packet_definition':'Finset.sum over Finset.univ','source_meaning':'Exactly all d rows or all r coordinates, with no omitted endpoint.'},
        {'definition':'Matrix.one','packet_definition':'diagonal with diagonal value 1','source_meaning':'Identity, not the all-ones matrix.'},
        {'definition':'Matrix.vecMulVec','packet_definition':'entry (a,b) is w[a]*v[b]','source_meaning':'Real rank-one outer product.'},
        {'definition':'Matrix.kronecker','packet_definition':'entry ((a,j),(b,k)) is A[a,b]*T[j,k]','source_meaning':'Gaussian/identity coordinate first, feature coordinate second; dimension r^2.'},
        {'definition':'Matrix scalar action','packet_definition':'entrywise scalar multiplication','source_meaning':'Source real coefficients multiply the whole matrix.'},
        {'definition':'Matrix multiplication','packet_definition':'entry (i,k) is sum_j M[i,j]*N[j,k]','source_meaning':'The consumer square Y_i*Y_i is the source matrix square, not an entrywise square.'},
        {'definition':'Matrix.PosSemidef','packet_definition':'IsHermitian plus nonnegative quadratic form on all finitely supported vectors','source_meaning':'On a finite real index set this is exactly symmetry plus every real-vector quadratic form nonnegative; PosSemidef(upper-lower) is source Loewner order.'},
        {'definition':'EuclideanSpace and WithLp.ofLp','packet_definition':'PiLp 2 carrier and coordinate projection','source_meaning':'Real Euclidean row, with its ordinary coordinates and norm; no sup-norm substitution.'},
        {'definition':'stdGaussian','packet_definition':'Measure.map of product gaussianReal 0 1 through an orthonormal-basis synthesis map','source_meaning':'Standard Gaussian on the Euclidean row space. Coordinate/moment facts for the chosen outer-product coordinates are internal canonical Gaussian dependencies, not extra law assumptions.'},
        {'definition':'Set.indicator','packet_definition':'if x belongs to R<=L then source summand else zero','source_meaning':'Closed event matches source. No default off-source semantics are invented.'},
        {'definition':'Integrable','packet_definition':'AEStronglyMeasurable and HasFiniteIntegral','source_meaning':'Actual Bochner integrability in finite-dimensional real matrix space.'},
        {'definition':'integral','packet_definition':'L1 integral when complete and integrable; zero otherwise','source_meaning':'Finite-dimensional real matrix space is complete by typing; the explicit integrability conclusion prevents acceptance based on the nonintegrable zero default.'},
        {'definition':'Matrix norm','packet_definition':'L2 operator norm induced by Euclidean continuous linear maps','source_meaning':'Relevant to Bochner integrability only here; the result itself remains PSD/Loewner rather than an asserted operator-norm bound.'},
    ],
    'no_fallback_problem':'The canonical Bochner integral has its library nonintegrable zero default, but no custom source-facing fallback is defined; the target explicitly concludes each integrability obligation. The literal t indicator branch is the exact source constant-coordinate case.',
    'notation_collision_controls':['Typed local B is the scaled deterministic coefficient matrix, not the source d-by-r^2 random design matrix B.','Typed local C is the exact bound coefficient, not the source absolute constant used to define tau.','Producer S is a coordinate-square sum, not an ambient function-type norm.','Consumer secondSum is sum of individual integrals, not E of a supplied independent d-row random family.'],
    'canonical_context_limits':'The packet gives definitions and intended dependency descriptions. No exact type/proof of an existing radial moment theorem was supplied or opened; actual reuse is not certified by this semantic audit.',
}
write('definition_semantics.json',definition_audit)

nodes=[]
def node(i,kind,statement,source,scope):
    nodes.append({'id':i,'kind':kind,'statement_or_port':statement,'source_anchors':source,'scope':scope,'proof_status':'obligation/interface only; no implementation inspected'})
node('typed-index-feature-port','definition-correspondence','Reindex source rows by i_source=i.val+1; identify Fin(q+1) feature coordinates and S_i=sum of squares with source Euclidean norm squared.',['S4.E11','A3.Ex85','A3.Ex102'],'deterministic')
node('identity-tensor-port','algebra/order port','From the raw r-by-r coefficient comparison, pass through I_r tensor (-); distribute the tensor over the finite sum and scalar weights, retaining PSD order.',['A3.Ex116'],'deterministic')
node('nonnegative-scaling-port','scalar/order port','The literal alpha=(r+2)/d^2 is nonnegative using r=q+1>=1 and hq=>d>0. Scaling the tensor comparison by alpha preserves PSD order.',['A3.Ex116','A3.Ex117'],'deterministic')
node('paired-identity-port','carrier/identity port','I_r tensor I_r is the identity matrix on Fin(q+1) x Fin(q+1), exactly the sealed N identity.',['A3.Ex117'],'deterministic')
node('coefficient-normalization-port','scalar algebra port','With d!=0, alpha*(2r*d)=2r(r+2)/d; match the sealed scalar C.',['A3.Ex117'],'deterministic')
node('typed-producer','sealed signature endpoint',packet['producer']['signature'],['A3.Ex116','A3.Ex117'],'deterministic')
node('canonical-row-law-port','canonical marginal meaning','E=EuclideanSpace R Fin(q+1), mu=stdGaussian E denotes the individual standard Gaussian row law. This does not identify a random row in the source g-family.',['A3.SS2.p1','A3.Ex113'],'canonical marginal only')
node('canonical-row-template-port','literal formula instantiation','Use the sealed E carrier and canonical coordinate variable x to instantiate R, L, G and Y as literal functions, with no assertion that x is an original source gamma_i.',['A3.Ex85','A3.SS2.p10','A3.Ex107'],'canonical row functions; no joint-law claim')
node('canonical-radial-fourth-input','intended internal dependency','Canonical E_mu[R(x) G(x)]=(r+2)I_r, together with actual integrability of its matrix entries/matrix form, is the Ex113 counterpart. Exact dependency theorem type and implementation are not inspected in this packet.',['A3.Ex113','A3.SS2.p14.2'],'canonical marginal only')
node('canonical-rank-one-square-port','algebra port','For the sealed canonical row coordinate vector and each literal feature vector, the two rank-one squares have the source R and S scalar factors. This is distribution-free finite real matrix algebra.',['A3.SS2.p14.2'],'canonical row functions; no law needed')
node('canonical-tensor-indicator-square-port','algebra port','The tensor matrix product, inverse-d scalar square, and 0/1 cutoff indicator square have the Ex114 meanings under the sealed definitions.',['A3.Ex107','A3.Ex114'],'canonical row functions; no law needed')
node('typed-square-port','algebra port','Identify Y_i*Y_i with the Ex114 formula, using inverse-d squared, the two rank-one-square identities, tensor multiplication and indicator idempotence.',['A3.Ex114','A3.SS2.p14.2'],'canonical marginal only')
node('typed-square-integrability','analytic obligation','For each i, (x |-> Y_i(x)*Y_i(x)) is Bochner integrable under mu; derive it internally using the intended canonical finite-moment/integrability input.',['A3.Ex113','A3.Ex114','A3.Ex115'],'canonical marginal only')
node('typed-PSD-indicator-removal','order port','For each i, the Ex114 pointwise PSD expression with the cutoff is at most its untruncated counterpart.',['A3.SS2.p14.3','A3.Ex115'],'canonical marginal only')
node('canonical-integration-order-port','integration/order port','For integrable finite real matrix functions under the sealed mu, Bochner integration preserves PSD differences and commutes with deterministic scalar/tensor coefficients; finite sums preserve the resulting inequalities.',['A3.Ex115'],'canonical marginal only; generic integration port')
node('typed-Ex115-integral-sum-port','integration/order port','Integrate each pointwise inequality under its canonical marginal law, apply the canonical radial fourth identity, and sum the resulting finite matrix inequalities to obtain secondSum ≼ the sealed deterministic B.',['A3.Ex115'],'canonical marginal only')
node('typed-consumer','sealed signature endpoint',packet['actual_private_consumer']['signature'],['A3.EGx11','A3.Ex117'],'canonical marginal only')

edges=[]
def edge(i,ins,out,at,condition):
    edges.append({'id':i,'kind':'AND','inputs':ins,'output':out,'consumer_use_site':at,'discharge_obligation':condition})
edge('tp01',['raw:coefficient-comparison','typed-index-feature-port'],'identity-tensor-port',['A3.Ex116'],'No Gaussian hypothesis: PSD tensor lift and linearity only.')
edge('tp02',['raw:dimensions'],'nonnegative-scaling-port',['A3.Ex116'],'r=q+1 and hq establish nonnegative alpha and positive d.')
edge('tp03',['typed-index-feature-port'],'paired-identity-port',['A3.Ex117'],'Identity entries are diagonal Kronecker deltas on the paired finite carrier.')
edge('tp04',['raw:dimensions'],'coefficient-normalization-port',['A3.Ex117'],'The real cast of d is nonzero; normalize the scalar with the source constants unchanged.')
edge('tp05',['identity-tensor-port','nonnegative-scaling-port','paired-identity-port','coefficient-normalization-port'],'typed-producer',['A3.Ex116','A3.Ex117'],'Combine deterministic ports to form exactly PosSemidef(C I_N-B).')
edge('tc01',['canonical-row-law-port','raw:dimensions'],'canonical-radial-fourth-input',['A3.Ex113'],'Canonical moment/integrability substrate must be an internal producer, not a public premise; exact reuse remains unchecked here.')
edge('tc00a',['typed-index-feature-port','raw:dimensions'],'canonical-row-template-port',['A3.Ex85','A3.Ex107'],'Literal canonical formula instantiation, without a law or original random-map transport assumption.')
edge('tc00b',['canonical-row-template-port','typed-index-feature-port'],'canonical-rank-one-square-port',['A3.SS2.p14.2'],'Generic rank-one-square identities on the actual canonical coordinate carrier.')
edge('tc00c',['canonical-row-template-port'],'canonical-tensor-indicator-square-port',['A3.Ex114'],'Generic multiplication, scaling and indicator algebra, with the closed cutoff retained.')
edge('tc02',['canonical-rank-one-square-port','canonical-tensor-indicator-square-port'],'typed-square-port',['A3.Ex114'],'Instantiate source algebra at the canonical integration variable only; no actual-family random-map identity is asserted.')
edge('tc03',['typed-square-port','canonical-radial-fourth-input'],'typed-square-integrability',['A3.Ex114','A3.Ex115'],'Supply measurable finite-dimensional matrix integrals; do not rely on the integral zero default.')
edge('tc04',['typed-square-port','raw:rank-one-and-kronecker-order'],'typed-PSD-indicator-removal',['A3.SS2.p14.3'],'Use nonnegative radial square and feature squared norm; cutoff indicator is 0 or 1.')
edge('tc04a',['typed-square-integrability','canonical-radial-fourth-input'],'canonical-integration-order-port',['A3.Ex115'],'Actual integrability for both sides enables the canonical integral order and coefficient identities; the nonintegrable zero default supplies no proof.')
edge('tc05',['typed-PSD-indicator-removal','canonical-integration-order-port','canonical-radial-fourth-input'],'typed-Ex115-integral-sum-port',['A3.Ex115'],'Each expectation is individual; no cross-row independence or common original-family law is required.')
edge('tc06',['typed-producer','typed-Ex115-integral-sum-port','typed-square-integrability'],'typed-consumer',['A3.Ex117'],'Materially consume the deterministic producer in the upper-bound composition and retain the per-i integrability output.')

raw_producer=raw_graph['root_backward_closures'][0]
producer_nodes=set(raw_producer['nodes'])
forbidden={'source-g-carriers','original-source-g-law','row-carrier','individual-row-law-from-source-family','row-marginal','gaussian-fourth-components','gaussian-polynomial-integrability','Ex113','Ex114','Y-definition','radial-and-threshold'}
assert not producer_nodes & forbidden
producer_typed=['typed-index-feature-port','identity-tensor-port','nonnegative-scaling-port','paired-identity-port','coefficient-normalization-port','typed-producer']
raw_by_output={}
typed_by_output={}
for e in raw_graph['edges']:
    raw_by_output.setdefault(e['output'],[]).append(e)
for e in edges:
    typed_by_output.setdefault(e['output'],[]).append(e)
def expanded_closure(root):
    found=set()
    used=set()
    def visit(n):
        if n in found:return
        found.add(n)
        is_raw=n.startswith('raw:')
        key=n[4:] if is_raw else n
        for e in (raw_by_output if is_raw else typed_by_output).get(key,[]):
            used.add(('raw:' if is_raw else '')+e['id'])
            for dep in e['inputs']:
                visit(('raw:'+dep) if is_raw else dep)
    visit(root)
    return {'root':root,'nodes':sorted(found),'edges':sorted(used)}
producer_expanded=expanded_closure('typed-producer')
consumer_expanded=expanded_closure('typed-consumer')
assert {n[4:] for n in producer_expanded['nodes'] if n.startswith('raw:')} == set(raw_producer['nodes'])
assert not {n[4:] for n in consumer_expanded['nodes'] if n.startswith('raw:')} & forbidden
assert {n for n in consumer_expanded['nodes'] if not n.startswith('raw:')} == {n['id'] for n in nodes}
write('typed_source_graph_overlay.json',{
    'schema':'selective-type-source-overlay-v1',
    'raw_graph_sha256':manifest['raw_graph_sha256'],
    'packet_sha256':PACKET_SHA,
    'raw_graph_unchanged':True,
    'nodes':nodes,'edges':edges,
    'producer_backward_closure':{'raw_nodes':raw_producer['nodes'],'raw_edges':raw_producer['edges'],'typed_nodes':producer_typed,'typed_edges':['tp01','tp02','tp03','tp04','tp05'],'contains_gaussian_input':False,'checked_exclusions':sorted(forbidden)},
    'computed_expanded_backward_closures':[producer_expanded,consumer_expanded],
    'consumer_backward_closure':{'producer_is_required':True,'typed_nodes':[n['id'] for n in nodes],'typed_edges':[e['id'] for e in edges],'canonical_marginal_boundary':'canonical-row-law-port','raw_reference_policy':'Only raw deterministic coefficient, dimension and PSD/tensor-order nodes enter the typed closure. Canonical row formula, square and integration ports are explicitly separate typed nodes; no raw original-g-family row-law adapter is inherited.','original_source_context_retained_at':str((BASE/'source_proof_graph.json').relative_to(ROOT))},
    'route_policy':'These are the source-faithful source/type ports, not proof code or API requirements. No alternative proof is falsely conjoined with the route.',
    'type_alignment':'The exact sealed statements align with the two bounded endpoints after explicit deterministic tensor/scaling ports and canonical-marginal scope qualification. This is statement/definition alignment, not proof/source-completion certification.',
    'review_boundary':'Extractor does not self-approve independent source topology. Separate topology challenge and later actual-proof/reuse checks remain required.'
})

typed_coverage=[]
for c in raw_coverage['inventory']:
    x=dict(c)
    if c['disposition']=='EXCLUDED':
        x['typed_disposition']='EXCLUDED_UNCLAIMED'
        x['typed_scope']='No sealed signature claims this component.'
    else:
        anchor=c['source_html_id']
        if anchor in ['A3.Ex115','A3.Ex116','A3.Ex117','A3.SS2.p14.4']:
            x['typed_disposition']='MAPPED_TO_SEALED_ENDPOINT_OR_INTERNAL_PORT'
        else:
            x['typed_disposition']='MAPPED_TO_DEFINITION_OR_INTERNAL_OBLIGATION'
        x['proof_status']='No implementation/proof acceptance in this overlay.'
    if c['source_html_id']=='A3.SS2.p1' and c['disposition']=='NODE':
        x['typed_component_split']=[
            {'part':'r and feature grid','disposition':'literal sealed definition'},
            {'part':'n','disposition':'original context; not used in these endpoints'},
            {'part':'source gamma from original g columns','disposition':'original-family row-map adapter remains open'},
            {'part':'individual N(0,I_r) law','disposition':'fixed canonical stdGaussian law realizes marginal calculation scope; original row-law equality not certified'},
        ]
    if c['source_html_id'] in ['A3.SS2.p10','A3.SS2.p12'] and c['disposition']=='NODE':
        x['original_family_qualification']='R and Y are realized as functions of the canonical row variable. Equality with original-family random rows remains an unclaimed adapter.'
    if c['source_html_id'] in ['A3.SS2.p14.1','A3.SS2.p14.2'] and c['disposition']=='NODE':
        x['canonical_input_boundary']='Intended canonical radial fourth moment and integrability are internal dependencies; their exact existing theorem type/proof is not available in this selective packet.'
    typed_coverage.append(x)
write('typed_component_coverage.json',{
    'raw_coverage_sha256':manifest['raw_coverage_sha256'],
    'inventory':typed_coverage,
    'all_raw_components_retained':len(typed_coverage)==len(raw_coverage['inventory']),
    'count':len(typed_coverage),
    'original_source_support':raw_coverage['outside_primary_support'],
    'original_source_downstream_exclusion':raw_coverage['outside_primary_downstream'],
    'new_ports_exhaustive_for_producer':['zero-based feature/norm identification','I_r tensor order and sum/scalar distribution','nonnegative alpha scaling','paired-index identity','d!=0 scalar normalization'],
    'new_ports_exhaustive_for_consumer':['canonical row-law interpretation','canonical fourth matrix moment/integrability','matrix-square identity','per-i integrability','PSD indicator removal','individual integral/finite-sum transport','producer-bound composition'],
    'coverage_status':'Every raw bounded component retained as mapped or explicitly excluded; statement-level mapping only, all proof obligations pending actual target proof.'
})

write('stopping_boundary_and_gaps.json',{
    'semantic_blockers_in_exact_signatures':[],
    'statement_scope':'Deterministic scaled coefficient producer plus finite sum of canonical individual-row second moments with per-row integrability.',
    'included_endpoints':[
        {'name':packet['producer']['name'],'source':'EGx11 deterministic Ex116/Ex117 comparison after the raw Ct bound','signature_sha256':packet['producer']['signature_sha256']},
        {'name':packet['actual_private_consumer']['name'],'source':'Canonical individual-expectation realization of EGx11 uncentered sum upper bound','signature_sha256':packet['actual_private_consumer']['signature_sha256']},
    ],
    'q_zero':'Included: r=1, t_i=(1), hq=>d>=2. No q>0 condition appears; nonconstant-coordinate cases are empty and source coefficient is 6/d.',
    'proof_obligations_not_yet_accepted':['All deterministic geometry/tensor/scalar ports in typed producer closure','Actual canonical fourth-moment/integrability dependency type and its material use','Square, PSD truncation, integrability and integral/sum ports','Actual target compilation and later independent source/proof checks'],
    'original_source_adapter_open':{'status':'open, outside sealed target','parts':['define or identify each source gamma_i as a measurable map from the original experiment','transport its individual source law to the canonical mu for relevant integrands','if later required, transport the full family joint law and independence','relate actual original-family Y_i to the canonical row template'], 'implication':'The current canonical expectation theorem alone does not establish an original-family random-matrix or concentration theorem.'},
    'downstream_unclaimed':['Centering and E[Z_i^2] comparison (Ex118)','Variance parameter or operator-norm variance bound (Ex119)','High-frequency cos(n theta_i) centered-square comparison (Ex120)','Matrix Bernstein','Simultaneous independent-row truncation/concentration events','Fact C.6','Full Lemma 4.4'],
    'definition_context_limit':'The embedded canonical definitions are read and audited. Referenced external receipt/provenance files and old proofs were not opened. The packet intended edge to an existing canonical moment theorem is not independently checked reuse evidence here.',
    'source_gap_policy':'The raw SOURCE_GAP nodes remain omitted source exposition/internal proof ports, not added assumptions and not source-invalid rulings.',
    'raw_preservation':{'raw_freeze_sha256':RAW_FREEZE_SHA,'all_raw_manifest_files_unchanged':True},
})

validation={
    'raw_freeze_exact_hash_passed':True,
    'raw_manifest_file_hashes_passed':len(raw_freeze['files']),
    'selective_packet_exact_hash_passed':True,
    'both_signature_hashes_passed':True,
    'embedded_definition_print_hashes_passed':True,
    'source_component_count_preserved':len(typed_coverage),
    'deterministic_producer_gaussian_exclusion_passed':True,
    'consumer_does_not_inherit_original_family_adapter':True,
    'typed_node_count':len(nodes),
    'typed_edge_count':len(edges),
    'producer_expanded_closure':{'nodes':len(producer_expanded['nodes']),'edges':len(producer_expanded['edges'])},
    'consumer_expanded_closure':{'nodes':len(consumer_expanded['nodes']),'edges':len(consumer_expanded['edges'])},
    'status':'structural and exact-input checks only; no proof implementation validation',
}
write('typed_validation.json',validation)
print(json.dumps(validation,indent=2))
