from pathlib import Path
from html.parser import HTMLParser
import json, hashlib, datetime
root=Path(__file__).resolve().parent
class Extract(HTMLParser):
    void={'area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr'}
    def __init__(self):
        super().__init__(convert_charrefs=True);self.depth=0;self.record=None;self.skip=0;self.items=[]
    def handle_startendtag(self,tag,attrs):
        if tag in self.void:self.handle_starttag(tag,attrs)
        else:self.handle_starttag(tag,attrs);self.handle_endtag(tag)
    def handle_starttag(self,tag,attrs):
        attrs=dict(attrs)
        if self.record is None and tag in ['p','table','h1','h2','h3','h4','h5','h6']:
            self.record={'tag':tag,'id':attrs.get('id'),'line':self.getpos()[0],'text':''};self.depth=1
        elif self.record and tag not in self.void:self.depth+=1
        if self.record:
            if tag=='math':self.record['text']+=' $'+attrs.get('alttext','[NO ALTTEXT]')+'$ ';self.skip=1
            elif self.skip and tag not in self.void:self.skip+=1
            elif tag in ['br','td','tr']:self.record['text']+=' '
    def handle_endtag(self,tag):
        if self.record and tag not in self.void:
            if self.skip:self.skip-=1
            self.depth-=1
            if self.depth==0:
                self.record['text']=' '.join(self.record['text'].split());self.items.append(self.record);self.record=None
    def handle_data(self,data):
        if self.record and not self.skip:self.record['text']+=data
source=root/'inputs/2610.20492v1.html';parser=Extract();parser.feed(source.read_text())
(root/'source-blocks.json').write_text(json.dumps(parser.items,ensure_ascii=False,indent=2)+'\n')
for name,a,b in [('C2-p1-p13',3314,3631),('C2-p14-p19',3631,3835),('S4-standing-Lemma44',1083,1241)]:
    records=[x for x in parser.items if a<=x['line']<b]
    text='\n\n'.join(f"[L{x['line']} {x['tag']} {x['id']}]\n{x['text']}" for x in records)+'\n'
    (root/'logs'/f'{name}.stdout').write_text(text)
    (root/'logs'/f'{name}.receipt.json').write_text(json.dumps({'argv':['python3',str(Path(__file__)),name],'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'html_line_range':[a,b],'blocks':len(records),'output_sha256':hashlib.sha256(text.encode()).hexdigest(),'method':'Read original HTML via stdlib HTMLParser; math alttext protected from markup stripping; original unchanged.'},indent=2)+'\n')
print('Extracted',len(parser.items),'blocks; wrote three bounded original-source reading outputs.')
