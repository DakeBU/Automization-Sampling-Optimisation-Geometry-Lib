from pathlib import Path
import json, hashlib, shutil, datetime
phase1=Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-determinant-semantic-evidence/topology-challenge/phase1')
b=phase1/'postfreeze-binder-checkpoint'
(b/'raw-inputs').mkdir(parents=True,exist_ok=True)
prefix='research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-determinant-semantic-evidence/'
paths=[
'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-determinant-statement-seal.json',
prefix+'necessary-definition-context/determinant-definition.txt',
prefix+'necessary-definition-context/orthogonal-carrier-alias.txt',
prefix+'necessary-definition-context/unitaryGroup-definition.txt',
prefix+'necessary-definition-context/unitary-carrier-definition.txt',
prefix+'preseal-binder-definition-and-exposure-audit.json',
prefix+'postseal-necessary-meaning-exposure.json',
str(phase1/'seven-semantic-slots.json'),str(phase1/'source-contract.json'),str(phase1/'freeze-manifest.json')]
manifest=[]
for i,p in enumerate(paths):
 q=b/'raw-inputs'/f'{i:02d}-{Path(p).name}.raw'
 shutil.copyfile(p,q)
 manifest.append({'path':p,'snapshot':str(q),'sha256':hashlib.sha256(q.read_bytes()).hexdigest(),'bytes':q.stat().st_size})
assert manifest[0]['sha256']=='15d7e92a84617b97ee7e9b105da967e1c6598a9ca2d6a06596c8974e25b05354'
seal=json.loads(Path(paths[0]).read_text())
sig=seal['exact_signature_utf8'].encode()
assert hashlib.sha256(sig).hexdigest()==seal['signature_sha256']=='1c55aaf1c9c11d4e1cdb1b565d3327fa8274e9a78f6440ca577b6c49b880f2dd'
assert manifest[-1]['sha256']=='0d07f9c0407e2c534563feea8c8c3458d7bc0dca75ae819eea1a3ec2f1a979b1'
def save(n,o): (b/n).write_text(json.dumps(o,ensure_ascii=False,indent=2)+'\n')
save('input-manifest.json',{'phase':'first sealed binder/meaning checkpoint','files':manifest,'raw_source_reference':{'snapshot':'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-determinant-semantic-evidence/topology-challenge/phase1/raw-inputs/10-.astis__huanjian-resume-20261103__2610.20492v1.html.raw','sha256':'6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915','read_in_frozen_raw_phase1':True}})
rows=[
{'input':'d : ℕ','expanded_meaning':'Natural finite dimension, Fin d as the index set','class':'TYPING'},
{'input':'hd : 2 ≤ d','expanded_meaning':'Exact lower dimension bound of S4.1 hard family','class':'SOURCE'},
{'input':'κ : ℝ','expanded_meaning':'Real condition parameter','class':'TYPING'},
{'input':'hκ : 2 ≤ κ','expanded_meaning':'Exact lower parameter bound of S4.1 hard family','class':'SOURCE'},
{'input':'O : Matrix.orthogonalGroup (Fin d) ℝ / underlying matrix','expanded_meaning':'Real square d-by-d matrix; Finite carrier/typeclass structures for matrix arithmetic and product','class':'TYPING'},
{'input':'O / carrier membership','expanded_meaning':'orthogonalGroup abbreviates unitaryGroup using starRingOfComm; unitaryGroup abbreviates matrix unitary submonoid; carrier requires star O * O = 1 and O * star O = 1. In this real orthogonal alias the star is transpose, hence OᵀO=I and OOᵀ=I. The second identity is equivalent to/consequence of the source finite-square orthogonality condition, not a stricter convenience assumption. No determinant-one condition exists.','class':'SOURCE'},
{'input':'let θ','expanded_meaning':'Literal ((i.val:ℝ)+1/2)*π/(d:ℝ), exactly source i=1,...,d under source i=i.val+1. All half and division arithmetic takes place in ℝ.','class':'DEFINITION_LITERAL_NOT_BINDER'},
{'input':'let diagonalValue','expanded_meaning':'Literal (κ+1)/2+((κ−1)/2)*cos θ_i for every Fin d index','class':'DEFINITION_LITERAL_NOT_BINDER'},
{'input':'let A','expanded_meaning':'Actual same-O real orthogonal conjugation of the complete displayed diagonal; no arbitrary matrix or spectrum certificate','class':'DEFINITION_LITERAL_NOT_BINDER'}]
comparisons={
'objects':{'status':'matches narrow component','comparison':'Actual real precision A is the literal orthogonal conjugate; no supplied proxy determinant or abstract spectrum witness. Potential/target are context, absent from this algebraic conclusion.'},
'domains':{'status':'matches','comparison':'d : ℕ with 2≤d, κ : ℝ with 2≤κ, O over full real orthogonalGroup (Fin d) ℝ. Carrier equations allow both orientation signs; no SO(d) subtype.'},
'quantifiers':{'status':'matches','comparison':'Universally quantified d,κ,O; no chosen orientation or probability event, no algorithm restrictions. Let definitions are local formulas, not existential witnesses.'},
'assumptions':{'status':'matches; EXCESS empty','comparison':'Only source range and orthogonality besides typing. Hidden carrier exposes two equivalent square orthogonality identities; no positivity, eigenwindow, correct-density, integrability or provider-result premise.'},
'conclusion':{'status':'equivalent determinant component only','comparison':'A.det = ∏_{i:Fin d} diagonalValue i. Matrix.det is the genuine determinant from detRowAlternating and alternatization; product traverses every diagonal coordinate once. The source intermediate det Λ is not separately printed in the signature, but the literal diagonal/product meaning is exactly its standard finite determinant expansion. No Gaussian integral, normalizer equality or target-law identification is claimed by this proposition.'},
'scopes_senses':{'status':'matches selected algebraic scope; full analytic context pending','comparison':'Real determinant rather than absolute determinant or trace. θ uses real casts before arithmetic; no odd-dimensional truncation. Fin d indices have exactly d entries. Signature has no measure or exponent expression, so it cannot resolve or certify the source Lebesgue-volume integral / real-power normalizer context.'},
'constant_dependencies':{'status':'matches','comparison':'Only d,κ,π,1/2 in explicit finite diagonal product; O removed from RHS. No q,δ,ε,d0 or asymptotic constant. No κ upper bound beyond source hard-family range.'}}
save('binder-meaning-checkpoint.json',{
'reviewer':'/root/det_topology_752618','role':'independent raw-source-first binder/definition/source-topology challenger','stage':'first sealed binder/meaning checkpoint only','raw_phase1_manifest_sha256':'0d07f9c0407e2c534563feea8c8c3458d7bc0dca75ae819eea1a3ec2f1a979b1','seal_raw_sha256':manifest[0]['sha256'],'signature_sha256':seal['signature_sha256'],
'verdict':'PASS for exact narrow determinant-component binder/meaning checkpoint; no EXCESS inputs found',
'proof_search_or_Lean_target_API_read':False,'binder_expansion':rows,'EXCESS':[],'seven_slot_comparison':comparisons,
'definition_audit':{'kind':'literal','theta':'Exact source midpoint cosine grid under source-to-Fin reindexing; d is nonzero from source d≥2. No fallback definition.','diagonalValue':'Exact source displayed scalar diagonal; no freedom to select convenient eigenvalues.','A':'Exact orthogonal diagonal conjugate.','determinant':'Direct Matrix.det definition is detRowAlternating M; row alternating map is formed by MultilinearMap.alternatization from the coordinate-product multilinear map. This is the finite commutative-ring determinant, not a supplied product value. No determinant theorem/API proof was read.','orthogonal_carrier':'Direct alias/abbreviation/carrier chain was read. It contains transpose-inverse equations and no sign restriction. Algebraic structural instances are typing, not extra mathematical assumptions.'},
'root_claim_challenges':[{'claim':'Full real orthogonal carrier, both signs','finding':'Supported by supplied exact carrier expansion; no det-one test appears. Source S2.p2 separately confirms both components.'},{'claim':'No premise smuggling via local definitions','finding':'Supported: θ,diagonalValue,A are let expressions. None takes a proposition/certificate/provider as input.'},{'claim':'Genuine determinant/product','finding':'Supported at definition/meaning level by exact definition and finite product syntax. This review does not prove the determinant identity.'},{'claim':'Actual consumer','finding':'Still a plan in seal. No exact consumer interface was delivered or inspected; no consumer acceptance/reuse credit issued.'},{'claim':'No target-specific API/proof work','finding':'This reviewer performed none. Root exposure claims are recorded as claims and cannot be independently certified from their self-report alone.'}],
'blocking_semantic_deltas':[],'nonblocking_scope_conditions':['Publication must continue labeling this as the determinant component only.','Full C.4 integral/normalizer ancestry remains pending independent topology challenge.','Exact same-A Gaussian consumer interface/carriers require later preimplementation audit; current consumer plan is not compiled use.','Source topology, Lean proof and compiler evidence are separate pending gates.'],
'approvals':{'narrow_signature_binder_meaning':True,'source_topology':False,'consumer_interface':False,'proof':False,'source_V':False,'integration':False,'full_C4_or_known_Z':False}})
save('exposure-record.json',{
'reviewer':'/root/det_topology_752618','stage':'first sealed binder/meaning checkpoint only','raw_before_candidate_order':'Original phase1 frozen and parent verified all27 payload hashes before this exposure.',
'candidate_content_now_visible':['exact statement seal including type-only receipt references, production/test path names and planned consumer prose','four minimal determinant/orthogonal alias/unitary/carrier definition snippets','root preseal and postseal audit/exposure claims'],
'implementation_or_API_content_visible':False,
'incidental_generic_proof_exposure':{'root_reported':'Root claims its carrier-lookup window34-38 incidentally exposed generic one_mem simp proof and mul_mem proof header.','reviewer_actual':'Reviewer saw only the description of that root exposure in postseal-necessary-meaning-exposure.json, not those proof lines. Minimal unitary-carrier-definition.txt ends at the carrier equation.'},
'not_read':['source extractor graph or coverage','root proof route','generic determinant lemma statement/API/proof','target production implementation','Tests content','previous reviews','prior graphs','source-V evidence','type-only receipt/log contents'],
'own_raw_phase1_filename_exposure':'Preserved unchanged in phase1/exposure-record.json; no additional filename discovery in this checkpoint.',
'stop_boundary':'STOP after binder/meaning freeze awaiting separately delivered extractor graph+coverage. No topology approval or proof permission inferred from this checkpoint.'})
(b/'checkpoint-summary.md').write_text('The exact sealed signature passes this independent first binder/meaning checkpoint for the selected algebraic determinant component. All seven semantic slots were compared with the pre-candidate raw reconstruction. Recursive full real orthogonal-carrier expansion contains no determinant-one restriction; the literal grid uses real halves and the correct zero-based index; Matrix.det is the genuine finite alternating determinant; the RHS product covers every coordinate once. EXCESS is empty.\n\nThis is no approval of source topology, target proof, source V, integration, the full C.4 Gaussian integral/known normalizer, or the still-planned same-A density consumer. The consumer interface remains unaudited. The root exposure record reports adjacent generic proofs, while this reviewer saw only that report and the minimal carrier snippets. No target API/proof was read.\n\nThe original 27-file phase1 freeze is unchanged. This postfreeze checkpoint is nested under the assigned phase1 output directory solely to preserve the original write boundary. Its own input snapshots and manifest bind the separately authorized candidate exposure. Work stops here until extractor graph and coverage are delivered.\n')
files=[p for p in b.rglob('*') if p.is_file() and p.name!='checkpoint-manifest.json']
save('checkpoint-manifest.json',{'phase':'first sealed binder/meaning checkpoint only','reviewer':'/root/det_topology_752618','frozen_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':[{'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in sorted(files)]})
for n in ['checkpoint-manifest.json','binder-meaning-checkpoint.json','input-manifest.json','exposure-record.json']:
 print(n,hashlib.sha256((b/n).read_bytes()).hexdigest())
for e in json.loads((phase1/'freeze-manifest.json').read_text())['files']:
 assert hashlib.sha256(Path(e['path']).read_bytes()).hexdigest()==e['sha256']
print('original phase1 all27 hashes unchanged')
