from pathlib import Path
import gzip, hashlib, json, subprocess, tarfile
sha = lambda raw: hashlib.sha256(raw).hexdigest()
E = Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-first-order-semantic-evidence')
P = Path('.astis/huanjian-gc-fixed-spectrum-first-order-20261108')
assert subprocess.check_output(['git', 'rev-parse', 'HEAD']).decode().strip() == 'b726e6f2490b4c644badd932931794ac6b79a021'
assert not Path('AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumFirstOrder.lean').exists()
assert not Path('Tests/GaussianComplexityFixedSpectrumFirstOrder.lean').exists()
checks = E / 'actual-checks'
checks.mkdir()
for receipt in Path('.astis/huanjian-resume-20261103').glob('*-fixed-spectrum-first-order-*.receipt.json'):
    r = json.loads(receipt.read_bytes())
    raw = Path(r['log']).read_bytes()
    assert sha(raw) == r['log_sha256']
    (checks / receipt.name).write_bytes(receipt.read_bytes())
    z = checks / (Path(r['log']).name + '.gz')
    z.write_bytes(gzip.compress(raw, mtime=0))
    assert gzip.decompress(z.read_bytes()) == raw
files = sorted(p for p in P.rglob('*') if p.is_file())
archive = E / 'preproof-private-inputs-and-tools.lossless.tar.gz'
assert not archive.exists()
with tarfile.open(archive, 'w:gz') as t:
    for p in files: t.add(p, arcname=str(p.relative_to(P)), recursive=False)
with tarfile.open(archive, 'r:gz') as t:
    assert len(t.getmembers()) == len(files)
    for p in files: assert t.extractfile(str(p.relative_to(P))).read() == p.read_bytes()
manifest = E / 'preproof-private-inputs-and-tools.manifest.json'
manifest.write_text(json.dumps({'archive': str(archive), 'archive_sha256': sha(archive.read_bytes()), 'all_originals_retained': True, 'producer_or_Test_proof_present': False, 'files': [{'original': str(p), 'member': str(p.relative_to(P)), 'raw_sha256': sha(p.read_bytes()), 'bytes': p.stat().st_size} for p in files]}, indent=2) + '\n')
safe, rows = [], []
pack = E / 'preproof-frozen-raw-packaging'
pack.mkdir()
for p in sorted(q for q in E.rglob('*') if q.is_file()):
    raw = p.read_bytes()
    ignored = subprocess.run(['git', 'check-ignore', '-q', '--', str(p)]).returncode == 0
    binary = p.suffix in ['.gz', '.png', '.zip'] or b'\0' in raw
    bad = not binary and (b'\r\n' in raw or raw.endswith(b'\n\n') or any(line.endswith((b' ', b'\t')) for line in raw.splitlines()))
    if ignored or bad:
        z = pack / (str(len(rows)).zfill(3) + '-' + p.name + '.gz')
        z.write_bytes(gzip.compress(raw, mtime=0))
        assert gzip.decompress(z.read_bytes()) == raw
        rows.append({'original_path': str(p), 'raw_sha256': sha(raw), 'raw_bytes': len(raw), 'gzip_path': str(z), 'gzip_sha256': sha(z.read_bytes()), 'ignored': ignored, 'raw_whitespace_or_blank_EOF': bad, 'original_retained_unchanged': True})
        safe.append(z)
    else: safe.append(p)
manifest = pack / 'manifest.json'
manifest.write_text(json.dumps({'scope': 'Frozen packet evidence only is wrapped losslessly. Originals are neither normalized nor deleted. Mutable ledger/frontier/README are staged directly and checked byte-exact.', 'files': rows}, indent=2) + '\n')
safe.append(manifest)
mutable = [Path('runs/substantive_advances.jsonl'), Path('research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-first-order.json'), Path('research-wiki/paper-contributions/GaussianComplexity/README.md')]
safe += mutable + [Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-first-order-statement-seal.json')]
subprocess.run(['git', 'add', '--', *map(str, safe)], check=True)
subprocess.run(['git', 'diff', '--cached', '--check'], check=True)
for p in mutable: assert subprocess.check_output(['git', 'show', ':' + str(p)]) == p.read_bytes()
assert not Path('AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumFirstOrder.lean').exists()
print(json.dumps({'preproof_admission_only': True, 'paths_staged': len(safe), 'frozen_raw_originals_losslessly_wrapped': len(rows), 'mutable_three_paths_staged_exactly': True, 'all284_old_states_443_frontiers_preserved_by_intake': True, 'target_proof_API_started': False}))
