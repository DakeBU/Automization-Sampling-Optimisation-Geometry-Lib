#!/usr/bin/env python3
"""Independent bounded native/reader verification; all writes stay beside this file."""
import datetime, hashlib, json, os, pathlib, shutil, subprocess, sys, time

R = pathlib.Path('/Users/zhouhuanjian/ASTIS-GC')
D = pathlib.Path(__file__).resolve().parent
C = '72e5d1405284f729f4eb600c5ae5dd556365b7e2'
PARENT = '75dcc0c9c7d9591384c6e0705e118b1ab440cd6c'
E = 'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-cosine-gram-semantic-evidence'
P = 'AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumCosineGram.lean'
T = 'Tests/GaussianComplexityFixedSpectrumCosineGram.lean'
G = 'AutoSamplingTheory/ExampleCases/GaussianComplexity/FixedSpectrumGridAlias.lean'
L = 'website/content/declaration_lessons/huanjian-fixed-spectrum-cosine-gram.json'
U = 'website/content/publications/huanjian-fixed-spectrum-cosine-gram.json'

def sha(b): return hashlib.sha256(b).hexdigest()
def put(rel, b):
    p = D / rel
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(b if isinstance(b, bytes) else b.encode())
    return p
def js(rel, value): return put(rel, json.dumps(value, ensure_ascii=False, indent=2) + '\n')
def run(label, argv, cwd=R, env=None, timeout=None, check=True):
    t = time.time()
    p = subprocess.run(argv, cwd=cwd, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=timeout)
    put('raw/' + label + '.stdout', p.stdout)
    put('raw/' + label + '.stderr', p.stderr)
    js('raw/' + label + '.receipt.json', {'argv': list(map(str, argv)), 'cwd': str(cwd),
       'env_overrides': None if env is None else {k: env[k] for k in ('LEAN_PATH','LEAN_SYSROOT') if k in env},
       'start_unix': t, 'elapsed_seconds': time.time()-t, 'exit_code': p.returncode,
       'stdout_sha256': sha(p.stdout), 'stderr_sha256': sha(p.stderr)})
    if check and p.returncode: raise RuntimeError(f'{label} failed: {p.returncode}: {p.stderr.decode(errors="replace")}')
    return p
def blob(path): return subprocess.check_output(['git', 'show', C + ':' + path], cwd=R)
def extract(path):
    b = blob(path)
    put('inputs/' + path, b)
    return {'path': path, 'bytes': len(b), 'sha256': sha(b), 'git_blob': subprocess.check_output(['git','rev-parse', C+':'+path],cwd=R).decode().strip()}

def bootstrap():
    paths = [P,T,G,L,U,'AGENTS.md','docs/theorem-publication-protocol.md',
       'docs/samplewiki-reader-navigation.md','lean-toolchain','lake-manifest.json',
       E+'/source-to-lean-map-v1.json', E+'/KernelExactTypesAndAllOwnedBounded.lean',
       E+'/producer-signature.txt',E+'/consumer-signature.txt']
    listing = run('candidate_matching_seal_audit_paths', ['git','ls-tree','-r','--name-only',C,'--',
       ':(glob)**/fixed-spectrum-cosine-gram-statement-seal.json',
       ':(glob)**/huanjian-fixed-spectrum-cosine-gram.json']).stdout.decode().splitlines()
    paths += [p for p in listing if p not in paths]
    js('input-hashes.json', [extract(p) for p in paths])
    parent = run('candidate_parents', ['git','show','-s','--format=%P',C]).stdout.decode().strip()
    assert parent.split()[0] == PARENT
    manifest = blob('lake-manifest.json')
    assert sha(manifest) == 'b83ca83b9cf7caa85fa8b023c2ff9a3fb7a7cce7e1c332e810c348535ec49c37'
    assert sha(blob(P)) == '88f29461fcac1825675e417a1bc3f3952404f1cd08183d6e484162aefe9f5d54'
    assert sha(blob(T)) == '90b43f488d3fe9b6c95d4c039d0f771ee5bfecdd699b72dfa52465643f0b0dee'
    lean = pathlib.Path('/Users/zhouhuanjian/.elan/toolchains/leanprover--lean4---v4.33.0/bin/lean')
    v = run('lean_version', [str(lean),'--version']).stdout.decode().strip()
    assert 'version 4.33.0,' in v
    packages = []
    for item in json.loads(manifest)['packages']:
        name = item['name']; path = R/'.lake/packages'/name
        head = run('package_'+name+'_HEAD', ['git','rev-parse','HEAD'], cwd=path).stdout.decode().strip()
        status = run('package_'+name+'_full_porcelain', ['git','status','--porcelain=v1','--untracked-files=all'],cwd=path).stdout.decode()
        packages.append({'name':name,'path':str(path),'expected_rev':item['rev'],'actual_HEAD':head,
           'exact_HEAD':head==item['rev'],'full_porcelain':status,'clean':not status,
           'library': str((path/'.lake/build/lib/lean').resolve())})
    js('native-environment.json', {'candidate':C,'parent':parent,'manifest_sha256':sha(manifest),
       'lean_binary':str(lean.resolve()),'lean_binary_sha256':sha(lean.read_bytes()),'lean_version':v,
       'packages':packages})
    assert len(packages)==9 and all(p['exact_HEAD'] and p['clean'] for p in packages)
    print(json.dumps({'input_count':len(paths),'lean':v,'lean_binary_sha256':sha(lean.read_bytes()),
       'packages':[{k:p[k] for k in ('name','actual_HEAD','exact_HEAD','clean')} for p in packages]},indent=2))

if __name__ == '__main__':
    bootstrap()
