from pathlib import Path
import copy, datetime, hashlib, json
OUT=Path(__file__).resolve().parent
g=json.loads((OUT/'source-graph.RAWFIRST.v1.json').read_text())
g['version']='source-only-v2-explicit-omitted-bridges'
g['created_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
g['before_target_signature_read']=False
g['predecessor']={'path':'source-graph.RAWFIRST.v1.json','sha256':hashlib.sha256((OUT/'source-graph.RAWFIRST.v1.json').read_bytes()).hexdigest(),
 'raw_first_unchanged':True,'refinement_reason':'Explicit source-only expansion of omitted measurability/radial-symmetry bridges, after sealed-interface and type meanings read; no target or existing parent proof body read.'}
byid={n['id']:n for n in g['nodes']}
def gap(i,statement,anchor):
    g['nodes'].append({'id':i,'kind':'SOURCE_GAP','statement':statement,'source_anchors':copy.deepcopy(byid[anchor]['source_anchors']),
                      'classification':'internal-paper-step','status':'unproved internal obligation; never a caller certificate'})
gap('gap-row-measurable','Coordinate projection of the product column experiment and WithLp.toLp 2 regrouping make each actual row_i measurable. Joint independence by itself is not used as a substitute for measurability.','rows-and-basis')
gap('gap-radial-moment-identity','Under the actual standard Gaussian row marginal, prove bounded/integrable truncated row outer products; radial cutoff is invariant under coordinate sign flips and permutations. Sign flips make off-diagonal expectations zero; permutations make diagonal expectations equal; trace and r>0 identify the common diagonal as E[R_i 1_(R_i<=L)]/r. This discharges the source radial-mean assertion internally.','radial-mean')
for e in g['edges']:
    if e['id']=='e03':
        e['prerequisites']=['gap-row-measurable','grid','dimensions','cutoff','Y']
        e['discharge']='Measurable actual rows followed by per-index polynomial/closed-indicator map; no row-law premise is needed merely for measurability.'
g['edges'] += [
 {'id':'e00a','prerequisites':['rows-and-basis','regime'],'consumer':'gap-row-measurable','logic':'AND',
  'consumer_use_site':copy.deepcopy(byid['Y']['source_anchors']),'discharge':'Coordinate projections under the canonical product measurable space and finite continuous WithLp row regrouping.'},
 {'id':'e00b','prerequisites':['row-law','cutoff','dimensions'],'consumer':'gap-radial-moment-identity','logic':'AND',
  'consumer_use_site':copy.deepcopy(byid['radial-mean']['source_anchors']),'discharge':'Derive truncated moment integrability and finite Gaussian coordinate sign/permutation invariance; do not supply them as caller premises.'},
 {'id':'e00c','prerequisites':['gap-radial-moment-identity'],'consumer':'radial-mean','logic':'AND',
  'consumer_use_site':copy.deepcopy(byid['actual-mean']['source_anchors']),'discharge':'Discharge the source radial assertion before transporting it to the actual matrix mean.'}
]
(OUT/'source-graph.source-only.v2.json').write_text(json.dumps(g,ensure_ascii=False,indent=2)+'\n')

s=(OUT/'original.2610.20492v1.html.RAW').read_text(); sb=s.encode()
cov=json.loads((OUT/'source-coverage.RAWFIRST.v1.json').read_text())
expected=sum([json.loads((OUT/f'{k}-raw-blocks.v2.json').read_text()) for k in ['s4','c2']],[])
errors=[]
assert len({x['id'] for x in cov['blocks']})==len(expected)==len(cov['blocks'])
for x in cov['blocks']:
    a,z=x['char_start'],x['char_end_exclusive']; raw=s[a:z].encode()
    if hashlib.sha256(raw).hexdigest()!=x['raw_sha256']: errors.append(f"bad raw hash {x['id']}")
    if raw!=sb[x['byte_start']:x['byte_end_exclusive']]: errors.append(f"bad byte locator {x['id']}")
    if x['disposition'] not in ['NODE','EXCLUDED'] or not x.get('reason'): errors.append(f"bad disposition {x['id']}")
for x in cov['mixed_paragraph_fragments']:
    raw=s[x['char_start']:x['char_end_exclusive']].encode()
    if hashlib.sha256(raw).hexdigest()!=x['raw_sha256']: errors.append(f"bad fragment {x['source_id']}")
    if raw!=sb[x['byte_start']:x['byte_end_exclusive']]: errors.append(f"bad fragment byte {x['source_id']}")
nodeids={x['id'] for x in g['nodes']}
assert len(nodeids)==len(g['nodes'])
for e in g['edges']:
    if not set(e['prerequisites']+[e['consumer']])<=nodeids: errors.append(f"unknown node {e['id']}")
assert not errors,errors
lint={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'errors':errors,
      'source_sha256':hashlib.sha256(sb).hexdigest(),'coverage_counts':cov['counts'],'source_nodes':len(g['nodes']),
      'source_gaps':sum(x['kind']=='SOURCE_GAP' for x in g['nodes']),'edges':len(g['edges']),
      'scope':'Structural shape/locator lint only; not independent mathematical topology approval, proof, fidelity or normalV.',
      'final_graph_sha256':hashlib.sha256((OUT/'source-graph.source-only.v2.json').read_bytes()).hexdigest(),
      'raw_first_graph_preserved_sha256':hashlib.sha256((OUT/'source-graph.RAWFIRST.v1.json').read_bytes()).hexdigest()}
(OUT/'source-coverage-lint.json').write_text(json.dumps(lint,indent=2)+'\n')
print(json.dumps(lint,indent=2))
