from pathlib import Path
import subprocess, json, hashlib, datetime, sys
out=Path(__file__).resolve().parent
raw=out/'phase2-raw'; raw.mkdir(exist_ok=True)
key=sys.argv[1]; cmd=sys.argv[2:]
p=subprocess.run(cmd,cwd='/Users/zhouhuanjian/ASTIS-GC',capture_output=True)
(raw/f'{key}.stdout').write_bytes(p.stdout); (raw/f'{key}.stderr').write_bytes(p.stderr)
(raw/f'{key}.receipt.json').write_text(json.dumps({'argv':cmd,'cwd':'/Users/zhouhuanjian/ASTIS-GC','exit_code':p.returncode,'timestamp':datetime.datetime.now(datetime.timezone.utc).isoformat(),'stdout_sha256':hashlib.sha256(p.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(p.stderr).hexdigest()},indent=2)+'\n')
print(p.stdout.decode(errors='replace'),end=''); print(p.stderr.decode(errors='replace'),end='',file=sys.stderr)
sys.exit(p.returncode)
