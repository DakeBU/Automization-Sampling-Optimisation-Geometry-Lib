from pathlib import Path
import json,hashlib,gzip,tarfile,subprocess,shutil
sha=lambda raw:hashlib.sha256(raw).hexdigest()
b=Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-normalizer-integration-20261108')
checks=b/'actual-checks';checks.mkdir(exist_ok=True)
for label in ['fixed-spectrum-normalizer-package-existing-source-V','fixed-spectrum-normalizer-apply-reviewed-shared','fixed-spectrum-normalizer-apply-reviewed-shared-corrected']:
 p=sorted(Path('.astis/huanjian-resume-20261103').glob('*-'+label+'.receipt.json'))[-1]
 r=json.loads(p.read_bytes());raw=Path(r['log']).read_bytes();assert sha(raw)==r['log_sha256']
 shutil.copy2(p,checks/p.name);z=checks/(Path(r['log']).name+'.gz');z.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(z.read_bytes())==raw
private=Path('.astis/huanjian-gc-fixed-spectrum-normalizer-integration-20261108')
files=sorted(p for p in private.rglob('*') if p.is_file())
archive=b/'core-integration-tools.lossless.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz') as bundle:
 for p in files:bundle.add(p,arcname=str(p.relative_to(private)),recursive=False)
with tarfile.open(archive,'r:gz') as bundle:
 for p in files:assert bundle.extractfile(str(p.relative_to(private))).read()==p.read_bytes()
manifest=b/'core-integration-tools.manifest.json'
manifest.write_text(json.dumps({'archive':str(archive),'sha256':sha(archive.read_bytes()),'all_members_roundtrip_verified':True,
 'files':[{'path':str(p),'member':str(p.relative_to(private)),'sha256':sha(p.read_bytes())} for p in files]},indent=2)+'\n')
ap=Path('research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-normalizer.json')
assert subprocess.check_output(['git','show','cc9e72d2a140a577258ed3a9c2c782cb561f3709:'+str(ap)])==ap.read_bytes()
lineage=b/'immutable-source-phase-lineage.json'
lineage.write_text(json.dumps({'mathematical_candidate':'8d33e06485edc17320cc01308af40da44945659d',
 'independently_checked_commit_with_blind_audit':'813268bc2683a82269364caffbc0c7490a884204',
 'first_commit_with_both_accepted_audit_and_independent_normal_V_append':'cc9e72d2a140a577258ed3a9c2c782cb561f3709',
 'same_production_Test_lesson_publication_binding':True,'accepted_audit_raw_sha256':sha(ap.read_bytes()),
 'truth_boundary':'Accepted audit/V append occur only in successor metadata; no retroactive checked-tree audit equality or new build is claimed. Exact six-path STAB candidate gates and actual browser acceptance next.'},indent=2)+'\n')
report=json.loads((b/'independent-reader/proposal-v3/proposal-report.json').read_bytes())
paths=[Path(r['path']) for r in report['shared_paths']]
paths += [p for root in [checks,b/'process-diagnostics'] for p in root.rglob('*') if p.is_file()]
paths += [b/name for name in ['root-sole-STAB-application-authorization.json','exact-shared-application-receipt.json',
 'before-STAB-ledger.lossless.jsonl.gz','after-STAB-ledger.lossless.jsonl.gz','sole-STAB-append.exact.jsonl.gz']]
paths += [archive,manifest,lineage]
mutable=[Path('runs/substantive_advances.jsonl'),Path('research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-normalizer.json')]
paths += mutable
subprocess.run(['git','add','--',*map(str,paths)],check=True)
r=subprocess.run(['git','diff','--cached','--check'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT);print(r.stdout.decode());assert r.returncode==0
for p in mutable+[Path(r['path']) for r in report['shared_paths']]:assert subprocess.check_output(['git','show',':'+str(p)])==p.read_bytes()
print(json.dumps({'shared_paths':6,'exact_current_ledger_and_cell_staged':True,'all_frozen_tools_roundtrip':True,
 'sourceV_existing_only':True,'canonical_gates_pending':True,'no_old_readme_or_otherfrontier_edit':True}))
