"""Root's final read-only concrete browser-context review; no browser grant."""
from pathlib import Path
import hashlib
import importlib.util
import json
import sys
sys.dont_write_bytecode = True
P = Path('.astis/huanjian-gc-fixed-spectrum-cosine-expansion-integration-20261109')
raw = (P / 'actual-browser-context-v2.DISABLED.json').read_bytes()
assert hashlib.sha256(raw).hexdigest() == 'f29639e79d4e8ba26c832b2845afcbaab17a1871b68ada8db06ce62585fc4c4a'
a = json.loads(raw)
assert a['authorized_by'] is None and a['execute_browser_authorized'] is False
file = P / 'independent-reader/browser-preparation-v2/c7_browser_common_v2.py'
assert hashlib.sha256(file.read_bytes()).hexdigest() == '0e99e5bb4531e84e76ee6276f19a684a9cd84b175ed199c704d1482bcfd9fc5a'
spec = importlib.util.spec_from_file_location('c7_guard_root_concrete_review', file)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
result = module.authorized_context(a)
out = {'reviewer': '/root', 'scope': 'actual evidence/control/compiled core/website context only; no browser pixel or source verdict',
       'disabled_context_sha256': hashlib.sha256(raw).hexdigest(), 'read_only_actual_guard_result': result,
       'execute_browser_authorized': False, 'OS_approval_requested_by_this_script': False}
with (P / 'root-actual-browser-context-review-v2.json').open('x') as f:
    f.write(json.dumps(out, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(out))
