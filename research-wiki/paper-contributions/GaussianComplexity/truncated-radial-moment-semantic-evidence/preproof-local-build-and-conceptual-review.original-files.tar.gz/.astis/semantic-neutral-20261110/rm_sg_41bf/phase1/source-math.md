# Appendix C.2 scalar truncation

This is a source reconstruction for *On Complexity of Gaussian Sampling*, arXiv:2610.20492v1. The exact raw HTML spans and their dispositions are in `coverage.json`. The scope is p1, p10, p11 and p12. The pinned broad source inventory supplies the surrounding scope. A distinct reviewer owns topology approval.

## Setup and the reused single-row estimate

Put $r=q+1$ and fix $1\le i\le d$. The paper’s setting has integer $q\ge 0$ and $2q+1<d$. The signs used locally are $r\ge 1$ and $d\ge 1$. The row $\gamma_i=((g_1)_i,\ldots,(g_r)_i)^\top$ has law $N(0,I_r)$. Put $R_i=\|\gamma_i\|^2$ and $L=2r+3\log(1000d)$. Thus $R_i$ is measurable and nonnegative, $1000d>0$, $\log(1000d)\ge 0$ and $L\ge 0$. These properties are implicit in the source. The scaled matrix row and cosine vector occur beside $\gamma_i$ in p1. The definition of $R_i$ uses $\gamma_i$ alone.

The reused p10 display `A3.Ex104.m1` asserts, for every real $x\ge 0$,

$$
\Pr(R_i>2r+3x)\le\exp\!\left(\tfrac r2\log 3-\tfrac{2r}3-x\right)\le e^{-x}.
$$

p10 explicitly supplies $\mathbb E e^{R_i/3}=3^{r/2}$ and invokes Markov. Its argument applies Markov to $e^{R_i/3}$ at the positive threshold $e^{(2r+3x)/3}$ and uses exponential monotonicity for the strict event. The final comparison uses $(\log 3)/2<2/3$. The Gaussian exponential-moment computation belongs to the earlier source slice. The all-rows event $\mathcal T=\{R_i\le L\text{ for every }i\}$ and the bound $\Pr(\mathcal T)\ge0.999$ are a separate p10 branch.

## p11 shifted tail and upper-tail first moment

For every real $s\ge 0$, substitute $x=\log(1000d)+s/3$ in Ex104. The weak lower endpoint implies $x\ge 0$, the threshold is $2r+3x=L+s$, and $e^{-x}=e^{-s/3}/(1000d)$. The substitution is implicit in “the same tail bound.” The conclusion is

$$
\Pr(R_i>L+s)\le\frac{e^{-s/3}}{1000d}.
$$

The two claims in Ex106 are

$$
\mathbb E[R_i\mathbf 1_{\{R_i>L\}}]
=L\Pr(R_i>L)+\int_0^\infty\Pr(R_i>L+s)\,ds
\le\frac{L+3}{1000d}.
$$

The equality uses the omitted layer-cake argument. Pointwise,

$$
R_i\mathbf 1_{\{R_i>L\}}=L\mathbf 1_{\{R_i>L\}}+(R_i-L)_+,
\qquad (R_i-L)_+=\int_0^\infty\mathbf 1_{\{R_i>L+s\}}\,ds.
$$

For a realization with $R_i>L$, the relevant $s$-section is $[0,R_i-L)$, of length $R_i-L$. At $R_i=L$ it is empty, and both sides of the pointwise decomposition vanish. The indicator is jointly measurable since $(\omega,s)\mapsto R_i(\omega)-L-s$ is measurable. Tonelli applies to nonnegative integrands and gives the expectation identity first in extended nonnegative values. The boundary term is finite, and the shifted tail at $s=0$ bounds it by $L/(1000d)$ because $L\ge0$. The tail function is Borel by monotonicity, and its Lebesgue integral is bounded by $3/(1000d)$ from $\int_0^\infty e^{-s/3}\,ds=3$. The integration endpoint $s=0$ has Lebesgue measure zero and also supplies the separate boundary estimate. These estimates show finiteness of both sides, justify the ordinary expectation and integral in the display, and give the sum $(L+3)/(1000d)$. This argument applies with atoms at $L$.

## p12 retained scalar and bias

The scalar component of Ex108 defines

$$
a=\frac1r\mathbb E[R_i\mathbf 1_{\{R_i\le L\}}].
$$

All rows have the same marginal law, hence the same scalar $a$. The p12 premise $\mathbb E R_i=r$ follows from summing the second moments of the $r$ centered variance-one coordinates. This supplies integrability of $R_i$. Both truncated variables are measurable and bounded between zero and $R_i$, so both are integrable. The retained one gives $0\le a\le1$ by monotonicity and $r>0$.

The events $\{R_i\le L\}$ and $\{R_i>L\}$ partition the sample space, with equality assigned to the retained part. Pointwise their truncated variables sum to $R_i$. Linearity of expectation and $\mathbb E R_i=r$ give the Ex109 identity. The Ex106 bound then gives the Ex109 inequality after division by $r>0$.

$$
1-a=\frac1r\mathbb E[R_i\mathbf 1_{\{R_i>L\}}]
\le\frac{L+3}{1000rd}.
$$

The matrix component of Ex108, $\mathbb E[\gamma_i\gamma_i^\top\mathbf 1_{\{R_i\le L\}}]=a I_r$, uses radial symmetry. The definitions and expectations of $Y_i$, the C.5 application to their sums, and the later concentration argument form the matrix branch. Each of these, cross-row independence, and the joint event $\mathcal T$ have explicit dispositions in the bounded inventory or its inherited outer boundary.
