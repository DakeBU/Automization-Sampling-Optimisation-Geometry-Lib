# Current binding: independent source round trip

Publication binding: `78798da7b9d1fd42fc4512bfe90663a140b438852b4996c6a5f48b7031b5c62a`.

P and T both receive `equivalent-after-elaboration`, each with seven explicit slot comparisons, zero blocking semantic deltas, and no mathematical source repair. Their current canonical reviewer packets, anonymous decoder inputs/runs/results, whole mathematical modules, current authored prose and independently reviewed citation successor are all bound by exact hashes.

P acceptance covers the disclosed finite nonempty real matrix specialization with AE regularity and nonnegative scalar extended-expectation completion. It does not identify that scope with the raw full-complex Proposition3.1 or attribute ENNReal to Tropp. T acceptance covers the authored private fixed-parameter bridge for the four literal signed Gaussian centered sums and their internally justified finite ordinary trace expectations. It is not a printed C.2 Bernstein theorem, a strict-norm union result, or a public declaration node.

The source/reconstruction payloads have not changed since old v1 exposure. The current decision was nevertheless made and bound to the new exact v3 context after the independent citation-only repair review, with old inputs/exposure preserved. No previous source/native verdict is used. Browser runtime, production admission, global graph integration, full Bernstein, purification, and whole-Goal acceptance are outside these decisions.
