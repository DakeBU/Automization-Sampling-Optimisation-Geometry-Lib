#!/usr/bin/env python3
"""Read only the pinned raw HTML; expose bounded raw-element evidence."""
from html.parser import HTMLParser
from html import unescape
from pathlib import Path
from hashlib import sha256
import sys, json, datetime

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT.parents[2] / 'huanjian-resume-20261103/2610.20492v1.html'
EXPECTED = '6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
raw = SOURCE.read_bytes()
assert len(raw) == 951991 and sha256(raw).hexdigest() == EXPECTED
src = raw.decode('utf-8')
starts = [0]
for i,c in enumerate(src):
    if c == '\n': starts.append(i+1)

class N:
    def __init__(self, tag, attrs, start):
        self.tag, self.attrs, self.start = tag, dict(attrs), start
        self.end, self.children = None, []
    def text(self):
        if self.tag == 'math': return '$'+self.attrs.get('alttext','')+'$'
        return ''.join(x if isinstance(x,str) else x.text() for x in self.children)

class P(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.stack, self.ids = [], {}
    def pos(self):
        line,col=self.getpos(); return starts[line-1]+col
    def handle_starttag(self, tag, attrs):
        n=N(tag,attrs,self.pos())
        if self.stack: self.stack[-1].children.append(n)
        if 'id' in n.attrs: self.ids[n.attrs['id']]=n
        if tag in {'meta','link','img','br','hr','input','source','wbr','area','base','col','embed','param','track'}:
            n.end=n.start+len(self.get_starttag_text())
        else: self.stack.append(n)
    def handle_endtag(self, tag):
        for i in range(len(self.stack)-1,-1,-1):
            if self.stack[i].tag == tag:
                end=src.index('>',self.pos())+1
                for n in self.stack[i:]: n.end=end
                self.stack=self.stack[:i]; return
    def handle_data(self,data):
        if self.stack: self.stack[-1].children.append(data)

p=P(); p.feed(src)
def record(key):
    n=p.ids[key]
    assert n.end is not None
    b0,b1=len(src[:n.start].encode()),len(src[:n.end].encode())
    fragment=raw[b0:b1]
    return dict(id=key, tag=n.tag, byte_start=b0, byte_end_exclusive=b1,
                raw_sha256=sha256(fragment).hexdigest(),
                text=' '.join(n.text().split()))

args=sys.argv[1:]
mode=args.pop(0) if args else 'show'
if mode == 'ids':
    keys=[key for key,n in p.ids.items() if any(key.startswith(x) for x in args)
          and n.tag in {'section','div','table','tbody','p'}]
    for key in keys: print(key,p.ids[key].tag,' '.join(p.ids[key].text().split())[:180])
    shown=keys
elif mode in {'show','save'}:
    shown=args
    records=[record(key) for key in shown]
    if mode == 'save':
        (ROOT/'raw-source-regions.json').write_text(json.dumps(dict(
            source_path=str(SOURCE),source_sha256=EXPECTED,source_bytes=len(raw),
            extraction='Exact UTF-8 source byte ranges; text uses math alttext and whitespace collapse.',
            regions=records),ensure_ascii=False,indent=2)+'\n')
    else:
        for r in records: print('\n===== '+r['id']+' =====\n'+r['text'])
else: raise ValueError(mode)
with (ROOT/'contact-reads.jsonl').open('a') as out:
    out.write(json.dumps(dict(time_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        operation=mode,source_path=str(SOURCE),source_sha256=EXPECTED,
        source_bytes=len(raw),selected_ids=shown),ensure_ascii=False)+'\n')
