"""Recompile every explicit exact570 ASTIS source in a new initially empty output tree."""
from native_common import *
def main():
    closure=json.loads((OWN/'actual-import-closure.json').read_text());packages=json.loads((OWN/'verified-package-inputs.json').read_text())
    assert closure['candidate_commit']==packages['candidate_commit']==COMMIT
    assert not OUT.exists();OUT.mkdir()
    env=lean_env(packages['packages']);flags=[str(LEAN),'-DmaxRecDepth=32768','-DmaxHeartbeats=0','-Ddebug.skipKernelTC=false']
    commands=[{'id':'lean-version','argv':[str(LEAN),'--version']}]
    for i,module in enumerate(closure['topological_order']):
        relative=module.replace('.','/');dest=OUT/(relative+'.olean');dest.parent.mkdir(parents=True,exist_ok=True)
        commands.append({'id':f'compile-{i:02d}','module':module,'argv':flags+['-o',str(dest),relative+'.lean']})
    write_json(OWN/'compile-commands.json',commands)
    files=[CAND/r['path'] for r in closure['modules']]+[CAND/n for n in ['lean-toolchain','lake-manifest.json','lakefile.lean']]+[OWN/n for n in ['native_common.py','prepare.py','prepare_v2.py','preparation-predecessor-failure.note.json','compile_closure.py','actual-import-closure.json','verified-package-inputs.json','compile-commands.json']]
    assignment={'candidate_commit':COMMIT,'fresh_ASTIS_output_initially_empty':not any(p.is_file() for p in OUT.rglob('*')),'compiler_binary_sha256_before':file_sha(LEAN),'inputs':[{'path':str(p.relative_to(OWN)),'sha256':file_sha(p)} for p in files]};assert assignment['fresh_ASTIS_output_initially_empty'];write_json(OWN/'compile-assignment.json',assignment)
    for c in commands:
        for r in assignment['inputs']:assert file_sha(OWN/r['path'])==r['sha256']
        run(c['id'],c['argv'],cwd=CAND,env=env)
    write_json(OWN/'compile-completed.json',{'candidate_commit':COMMIT,'all_actual_exit_zero':True,'ASTIS_modules_freshly_recompiled':len(closure['modules']),'no_prior_ASTIS_olean_reused':True,'compiler_binary_sha256_after':file_sha(LEAN)})
if __name__=='__main__':main()
