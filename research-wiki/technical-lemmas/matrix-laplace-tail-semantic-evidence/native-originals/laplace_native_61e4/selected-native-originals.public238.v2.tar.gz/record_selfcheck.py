"""Capture real final evidence self-check streams, then append only those own leaves."""
import json
import sys
from native_common import *

_,receipt=run('final-evidence-selfcheck',[sys.executable,str(OWN/'evidence_selfcheck.py')],cwd=OWN)
receipts=[p for p in (OWN/'command-receipts').glob('*-final-evidence-selfcheck.receipt.json') if json.loads(p.read_text())==receipt]
assert len(receipts)==1
manifest=json.loads((OWN/'selected-originals.manifest.v1.json').read_text())
additions=[OWN/'evidence_selfcheck.py',OWN/'record_selfcheck.py',receipts[0],OWN/receipt['stdout']['path'],OWN/receipt['stderr']['path']]
for path in additions:
    assert path.resolve().is_relative_to(OWN)
    manifest['leaves'].append({'path':str(path.relative_to(OWN)),'sha256':file_sha(path),'bytes':path.stat().st_size})
assert len({x['path'] for x in manifest['leaves']})==len(manifest['leaves'])
for leaf in manifest['leaves']:
    assert file_sha(OWN/leaf['path'])==leaf['sha256']
write_json(OWN/'selected-originals.manifest.v1.json',manifest)
print(json.dumps({'final_evidence_leaves':len(manifest['leaves']),'manifest_sha256':file_sha(OWN/'selected-originals.manifest.v1.json')}))
