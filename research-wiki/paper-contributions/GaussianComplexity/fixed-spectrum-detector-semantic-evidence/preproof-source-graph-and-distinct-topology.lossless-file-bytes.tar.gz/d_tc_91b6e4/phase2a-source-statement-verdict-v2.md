# Phase 2a — bounded exact statement/binder verdict (v2)

Revision note: this v2 supersedes the preserved unsealed draft `phase2a-source-statement-verdict.md` only to remove an explicitly identified digest transcription error from its interface list. The mathematical judgment is unchanged.

Status: **ACCEPT_BOUNDED_STATEMENT_AND_DEFINITIONS**. This is a review of the exact two whitelisted signatures against the independently frozen phase1 cognition and raw source. It gives no graph, process-qualification, Lean proof, sourceV, integration, probability-lower-bound, global or wholeGoal acceptance.

The phase1 freeze remains unchanged: manifest SHA256 `b9bbceed96e912930ecab3f6c82f7266750d20539f6ed81f147d9b8069a6d457`, cognition SHA256 `337d83930b28ae2f1bf1c373b73bc839926ce962f0247e96e85316d776916345`. Phase2a uses the authorized projection and exact producer/consumer text, not the full seal or implementation. The projection's proposed classifications and claimed use were reviewed as claims, not used as independent proof evidence.

## Exact reviewed interfaces

* Public `actual_chebyshev_matrix_cosine`, exact signature SHA256 `c1abe1c57e12337dc3592297e624edd757deb18f9eae17ecdc9faca40e2609f4`.
* Private `actual_rotated_gaussian_detector_event`, exact signature SHA256 `364843a1d3e581a3b9498eed483b0dff44faad722a67d90c46566da038fc4d2e`.
* Authorized projection SHA256 `f1e34ef583a965957cbde49e2005636c338f37615ad153777875438f5433fc9f`.

The first theorem is a deterministic hard-family **matrix polynomial identity**. The second is a concrete **pushforward measure event equality**, together with measurability of that event. This distinction matches the source bridge at `S4.SS3.p3`–`p4` and the target-coordinate discussion after Lemma 4.5. Neither signature is the full target pass-probability statement or Theorem 4.1.

## Binder audit, recursively at the exposed interface

There are no project-owned Prop aliases, user structures, law certificates, supplied witnesses or unexpanded project hypotheses in either text. The standard orthogonal-group carrier is expanded in the definition audit. Local `let`s bind expressions, not proof assumptions. All binders are accounted for below.

| Interface | Binder | Class | Independent reason |
|---|---|---|---|
| producer | `{d : ℕ}` | TYPING | A natural finite dimension, with `Fin d` coordinates. |
| producer | `hd : 2 ≤ d` | SOURCE | Exact §4.1 hard-family domain. No sufficiently-large-d claim is asserted here. |
| producer | `{κ : ℝ}` | TYPING | Real construction parameter. |
| producer | `hκ : 2 ≤ κ` | SOURCE | Exact §4.1 range. It entails κ−1≠0; that fact is not an extra binder. |
| producer | `O : Matrix.orthogonalGroup (Fin d) ℝ` | SOURCE | Fixed member of the full source orthogonal group, including both determinant components. Orthogonality is the source eigenbasis condition, not a supplied diagonalization/proof result. |
| producer | `n : ℕ` | TYPING | Frequency parameter for a stronger uniform auxiliary identity; the source instance is n=2q+1. The conclusion depends on n, so this is parameterization rather than an unrelated premise. |
| private consumer | `{d : ℕ}` | TYPING | Same finite dimension. |
| private consumer | `hd : 2 ≤ d` | SOURCE | Same hard-family domain. |
| private consumer | `{κ : ℝ}` | TYPING | Same real construction parameter. |
| private consumer | `hκ : 2 ≤ κ` | SOURCE | Same source family range. |
| private consumer | `O : Matrix.orthogonalGroup (Fin d) ℝ` | SOURCE | Same fixed full orthogonal eigenbasis/rotation, without a probability-law assumption. |
| private consumer | `n : ℕ` | TYPING | Same explicit generalized auxiliary frequency. |
| private consumer | `τ : ℝ` | TYPING | Explicit arbitrary threshold parameter; source specialization is τ=τ_{d,q}. The literal event transport requires neither positivity nor smallness. |

Counts: SOURCE=6, TYPING=7, STANDING=0, RULED=0, EXCESS=0. There are no existential output witnesses. This count treats the two source range inequalities and orthogonal carrier separately for each interface; it does not count local expression definitions as assumptions.

The generalizations to all n∈ℕ (including zero) and all real τ are acceptable **only at the stated auxiliary boundary**. The source theorem's odd-frequency/query-budget relation, τ's concentration constant and all eventual parameter bounds must still be supplied in a future use for the source proof. These signatures neither claim nor imply those estimates. No binder silently substitutes a proved ingredient for a source hypothesis.

## Source match and precise limitations

The zero-based formula `((i.val:ℝ)+1/2)*π/d` exactly reindexes Eq. (11)'s `(i−1/2)π/d` for i=1,…,d. The same Λ and O appear in A, B, R and the diagonal event. `B=(κ−1)⁻¹ • (2 • A−(κ+1) • I)` uses a **real scalar reciprocal**, exactly the source affine normalized matrix; it is distinct from the **matrix inverse** Λ⁻¹ used as covariance. The polynomial evaluation is in the real matrix algebra, with scalar diagonal coefficients and matrix powers, not entrywise evaluation. Nat-to-Int casting selects the nonnegative first-kind T_n; n=0 gives the valid auxiliary identity I=OIOᵀ.

The private statistic is the source homogeneous signed quadratic minus `2τ‖x‖²`. Its event is `0<S x`, exactly `S_A(x)>0`. It has no nonzero-vector binder, no denominator ‖x‖², and excludes x=0 for every n and τ. It does not define or assert the geometric weights; it formalizes the matrix/cosine bridge used to explain them. No target mean, normalized ratio, β, variance, Chebyshev probability bound or TV estimate occurs here.

The literal μ is `multivariateGaussian 0 Λ⁻¹` on the Euclidean ℓ² wrapper; R is the actual map z↦Oz. Thus the LHS is the actual measure `(μ.map R)` evaluated on the actual polynomial event, and the RHS is μ evaluated on the corresponding strict diagonal cosine event. The constructor's standard totalization and map's totalization are checked in the definition audit. The source family is positive definite, so there is no source-domain covariance fallback; the equality statement itself does not require an external Gaussian or rotation law certificate.

There is deliberately no assertion that `(μ.map R)=multivariateGaussian 0 A⁻¹`, no identification with π_A as a law, no ≥0.9 event probability and no randomized-input/algorithm experiment. This is a faithful partial transport bridge; it must not be promoted to source Lemma 4.5's full rotated-target identification or §4.3 Ex26.

## Genuine consumer assessment at statement level

The private consumer is substantive: S contains the producer's literal **left-hand matrix polynomial**, while the right-hand event contains the **cosine diagonal weights**. It transports a concrete defined measure by a concrete rotation. It does not assume the producer conclusion, an arbitrary event equality, an arbitrary compatible law, event measurability, continuity, integrability, moments or a concentration gate. As a mathematical interface it therefore provides a real use for the reviewed family identity, rather than a wrapper that merely restates a supplied hypothesis.

However, a signature alone cannot establish that a checked implementation actually invokes this producer, or that the private theorem is reachable from a source anchor/test. No implementation or Tests file was opened. Accordingly **actual compiled dependency, actual invocation/reachability and source-graph edge certification remain HOLD**. The projection's phrase “genuinely consumed” is accepted here only as an interface-level mathematical consumer claim, not as an implementation receipt.

## Retained HOLDs

Other-actor graph coverage/directions, full-root source closure, process qualification, proof validity/axioms, elaboration, compilation, actual producer invocation, test reachability, law equality with π_A, target pass probability, algorithmic probability, absolute concentration constant, query/TV lower bound, publication/integration and all broader completion statuses remain HOLD. Phase2b and phase3 must issue separate records; this mathematical verdict and phase1 cognition may not be retrospectively rewritten.
