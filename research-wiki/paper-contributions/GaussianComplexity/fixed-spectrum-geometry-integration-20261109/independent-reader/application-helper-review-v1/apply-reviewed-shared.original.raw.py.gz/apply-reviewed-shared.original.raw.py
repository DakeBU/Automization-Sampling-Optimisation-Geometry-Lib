"""Execute only with concrete actual source-V and root exact application authorization."""
from pathlib import Path
import datetime,gzip,hashlib,json,subprocess,sys
sys.path.insert(0,'tools')
import astis_advance as adv
import astis_publication as pub
P=Path('.astis/huanjian-gc-fixed-spectrum-geometry-integration-20261109')
B=Path('research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-geometry-integration-20261109')
Q=P/'independent-reader/conditional-proposal-v1'
ADV='ASTIS-SA-20261109-GaussianComplexityFixedSpectrumGeometry'
OWNER='huanjian_gc_20261109_fixed_spectrum_geometry'
INTEGRATOR='huanjian_gc_20261109_fixed_spectrum_geometry_integration'
AP=Path('research-wiki/semantic-roundtrip/audits/huanjian-fixed-spectrum-geometry.json')
CP=Path('research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-geometry.json')
sha=lambda b:hashlib.sha256(b).hexdigest()
dump=lambda x:(json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode()
authpath=P/'root-sole-STAB-application-authorization.json'
auth=json.loads(authpath.read_bytes())
assert auth['authorized_by']=='/root' and auth['exact_six_path_application_authorized'] is True
assert auth['new_source_verdict'] is False
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert head==auth['source_V_first_carrying_commit']
assert not subprocess.check_output(['git','diff','HEAD','--name-only']).strip()
main=subprocess.check_output(['git','rev-parse','origin/main'],text=True).strip()
assert main==auth['fresh_origin_main']
subprocess.run(['git','merge-base','--is-ancestor',main,head],check=True)
report=Q/'proposal-report.json'; freeze=Q/'freeze.json'
assert sha(report.read_bytes())==auth['proposal_report_sha256']=='6f9045472dc9f11da494942d065b093efab12c2cf385f6d83a379ad771a5e904'
assert sha(freeze.read_bytes())=='3bebcf376f16376e2225accf6db7fb679034923a7e7a9b8a526dccf5334e3bda'
for row in json.loads(freeze.read_bytes())['files']: assert sha(Path(row['path']).read_bytes())==row['sha256']
review=P/'root-conditional-six-path-review.json'
assert sha(review.read_bytes())==auth['root_conditional_review_sha256']=='d0976e1b5f621fc0ecd157ea466ab02e135f71ef74bd2d3f7a002c5ee409832d'
r=json.loads(report.read_bytes()); assert len(r['shared_paths'])==6
audit_raw=AP.read_bytes(); audit=json.loads(audit_raw)
assert sha(audit_raw)==auth['accepted_audit_sha256'] and audit['state']=='accepted'
assert audit['source_review']['reviewer']==auth['source_verifier']
assert audit['publication_binding_sha256']==r['publication_binding_sha256']
assert subprocess.check_output(['git','show',head+':'+str(AP)])==audit_raw
states=adv.current_advances(); assert states[ADV]['state']=='VERIFIED' and states[ADV]['owner_id']==OWNER
assert not [k for k,v in states.items() if v['state']=='STABILIZING']
lp=Path('runs/substantive_advances.jsonl'); before=lp.read_bytes()
assert sha(before)==auth['ledger_before_STAB_sha256']
vraw=Path(auth['actual_source_V_append_path']).read_bytes()
assert sha(vraw)==auth['actual_source_V_append_sha256'] and before.endswith(vraw)
v=json.loads(vraw)
assert v['advance_id']==ADV and (v['from_state'],v['to_state'])==('PROVED_LOCAL','VERIFIED')
assert v['worker_id']==v['evidence']['verifier_id']==auth['source_verifier']
assert v['evidence']['verified_commit']==r['candidate_commit']=='ab8b47caed9f781191f8408154cd355c7e7c104c'
assert all(v['evidence'][k] for k in ['gate','source_audit','fake_closure_scan'])
candidate_ledger=subprocess.check_output(['git','show',r['candidate_commit']+':'+str(lp)])
assert before==candidate_ledger+vraw
assert sha(candidate_ledger)==r['source_Test_lesson_publication_pins'][str(lp)]
assert sha(subprocess.check_output(['git','show',r['candidate_commit']+':'+str(AP)]))==r['source_Test_lesson_publication_pins'][str(AP)]
pub.check_advance([audit['lean']['declaration']],reviewed=True)
foreign={str(q):q.read_bytes() for q in CP.parent.glob('*.json') if q!=CP}
protected={str(q):q.read_bytes() for q in [Path('runs/substantive_discoveries.jsonl'),
    Path('research-wiki/paper-contributions/GaussianComplexity/README.md'),
    Path('website/content/graph_memory_index.json'),Path('website/content/functor_hypergraph.json')]}
payloads=[]
for row in r['shared_paths']:
    q=Path(row['path']); assert q.exists()==row['before_exists']
    assert not q.exists() or sha(q.read_bytes())==row['before_sha256']
    ref=row['planned_after_archive']; z=Path(ref['path']).read_bytes(); raw=gzip.decompress(z)
    assert sha(z)==ref['gzip_sha256'] and sha(raw)==row['planned_after_sha256'] and len(raw)==ref['raw_bytes']
    payloads.append((q,raw))
for path,digest in r['source_Test_lesson_publication_pins'].items():
    if path in [str(AP),str(lp)]: continue  # Actual accepted audit and sole normal V are checked above.
    assert sha(Path(path).read_bytes())==digest
assert not B.exists(); B.mkdir()
(B/authpath.name).write_bytes(authpath.read_bytes())
adv.transition_advance(ADV,'STABILIZING',worker_id=INTEGRATOR,evidence={
    'integration_owner':INTEGRATOR,'canonical_branch':subprocess.check_output(['git','branch','--show-current'],text=True).strip(),
    'verifier_id':auth['source_verifier'],'verified_commit':r['candidate_commit'],'source_V_first_carrying_commit':head,
    'publication_declarations':[audit['lean']['declaration']],'lean_declarations':[audit['lean']['declaration']],
    'independent_proposal':str(report),'proposal_sha256':sha(report.read_bytes()),'root_exact_diff_review':str(review),
    'scope':'Exactly six reviewed shared paths; one new public producer and actual private Borel Test. Models/discoveries unchanged, no parent standalone audit upgrade.',
    'truth_boundary':'Genuine independent source/whole-module/fresh-Lean/STATIC-reader V preserved. Actual immutable-core root/site/graph/desktop-mobile, remote, purification/Seal and both main bounds remain open.'})
after=lp.read_bytes(); assert after.startswith(before); append=after[len(before):]; assert len(append.splitlines())==1
for q,raw in payloads:
    q.parent.mkdir(parents=True,exist_ok=True); q.write_bytes(raw)
now=adv.current_advances()
assert [k for k,v in now.items() if v['state']=='STABILIZING']==[ADV]
assert now[ADV]['owner_id']==OWNER and all(now[k]==value for k,value in states.items() if k!=ADV)
assert all(Path(q).read_bytes()==raw for q,raw in foreign.items())
assert all(Path(q).read_bytes()==raw for q,raw in protected.items()) and AP.read_bytes()==audit_raw
for row in r['shared_paths']: assert sha(Path(row['path']).read_bytes())==row['planned_after_sha256']
cell=json.loads(CP.read_bytes())
cell['evidence']['canonical_integration']={
    'state':'SOLE_STAB_EXACT_SIX_PATHS_APPLIED_ACTUAL_CORE_GATES_PENDING','owner':INTEGRATOR,
    'source_V_first_carrying_commit':head,'source_verifier_preserved':auth['source_verifier'],
    'proposal_report_sha256':sha(report.read_bytes()),'new_public_producer':audit['lean']['declaration'],
    'private_Test_Registry_node':False,'new_conceptual_transport':False,'actual_STAB_append_sha256':sha(append)}
CP.write_bytes(dump(cell))
for name,raw in [('before-STAB-ledger.lossless.jsonl.gz',before),('after-STAB-ledger.lossless.jsonl.gz',after),('sole-STAB-append.exact.jsonl.gz',append)]:
    q=B/name; q.write_bytes(gzip.compress(raw,mtime=0)); assert gzip.decompress(q.read_bytes())==raw
(B/'sole-STAB-append.exact.jsonl').write_bytes(append)
record={'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'normal_state':now[ADV]['state'],
    'integration_owner':INTEGRATOR,'normal_STAB_append_events':1,'ledger_before_sha256':sha(before),
    'ledger_after_sha256':sha(after),'append_sha256':sha(append),'old_ledger_prefix_preserved':True,
    'foreign_states_preserved':len(states)-1,'foreign_raw_frontiers_preserved':len(foreign),
    'README_discovery_models_source_audit_unchanged':True,
    'exact_shared_paths':[{'path':row['path'],'sha256':row['planned_after_sha256']} for row in r['shared_paths']],
    'new_source_verdict':False,'actual_core_build_site_browser_acceptance':False}
(B/'exact-shared-application-receipt.json').write_bytes(dump(record))
print(json.dumps({'state':now[ADV]['state'],'exact_shared_paths_applied':6,'foreign_states_preserved':len(states)-1,
    'foreign_raw_frontiers_preserved':len(foreign),'existing_source_V_preserved':True,'next':'Freeze immutable integration core then actual8gates and separately approved browser.'}))
