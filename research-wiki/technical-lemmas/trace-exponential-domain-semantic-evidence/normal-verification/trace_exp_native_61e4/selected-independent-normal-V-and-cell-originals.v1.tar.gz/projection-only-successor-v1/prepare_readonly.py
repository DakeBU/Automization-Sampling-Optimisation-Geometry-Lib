"""Seal draft hashes and run only the explicitly read-only precheck; no authorization or cell action."""
from verification_common import *
import traceback
def main():
    path=OWN/'projection.authorization.draft.json';a=read(path);assert a['authorization']=='PREPARED_ONLY_NOT_AUTHORIZED'
    a['scripts']['projection_only.py']=file_sha(OWN/'projection_only.py')
    # This is a preparation draft, not an actual authorization or process record.
    with path.open('w') as f:json.dump(a,f,ensure_ascii=False,indent=2);f.write('\n')
    text=(OWN/'projection_only.py').read_text();ast.parse(text);assert 'transition_advance' not in text
    tree=ast.parse(text);assert not any(isinstance(n,ast.ImportFrom) and n.module and 'astis_advance' in n.module for n in ast.walk(tree))
    directory=PRIVATE/'read-only-precheck-OS';assert not directory.exists();private_dir(directory);out=directory/'stdout.raw';err=directory/'stderr.raw';argv=[sys.executable,'-B',str(OWN/'projection_only.py'),'--read-only-precheck','--authorization',str(path),'--authorization-sha256',file_sha(path)];started=dt.datetime.now(dt.timezone.utc).isoformat();start=time.monotonic()
    with out.open('xb') as o,err.open('xb') as e:
        os.fchmod(o.fileno(),0o600);os.fchmod(e.fileno(),0o600);child=subprocess.Popen(argv,cwd=REPO,stdin=subprocess.DEVNULL,stdout=o,stderr=e);code=child.wait()
    receipt={'schema':'r16-projection-successor-readonly-precheck-actual-OS-receipt-v1','argv':argv,'cwd':str(REPO),'pid':child.pid,'parent_pid':os.getpid(),'started_utc':started,'ended_utc':dt.datetime.now(dt.timezone.utc).isoformat(),'elapsed_seconds':time.monotonic()-start,'actual_exit_code':code,'stdout_sha256':file_sha(out),'stderr_sha256':file_sha(err),'raw_streams_private':True,'scripts':a['scripts'],'draft_sha256':file_sha(path),'normal_API_or_cell_actions':0}
    write(directory/'receipt.private.json',receipt);exact(OWN/'read-only-precheck-OS.public.json',(directory/'receipt.private.json').read_bytes())
    assert code==0,'Actual read-only precheck failed; preserve originals and do not launch action.'
    assert not (PRIVATE/'projection-attempted.once.json').exists() and file_sha(REPO/CELL)==a['expected_before_sha256']
    assert not (PRIVATE/'successor-before').exists() and not (PRIVATE/'successor-after').exists() and not (PRIVATE/'projection-OS-process').exists()
    write(OWN/'preparation-contract.json',{'status':'PREPARED_ONLY_NO_SUCCESSOR_ACTION_AUTHORIZED_OR_EXECUTED','advance_id':ADV,'exact_before_sha256':a['expected_before_sha256'],'exact_fixed_target_sha256':a['expected_fixed_sha256'],'original_proof_V_outcome_sha256':a['pins']['V_outcome']['sha256'],'original_proof_V_append_sha256':a['pins']['V_append']['sha256'],'original_PL24_sha256':a['pins']['PL24']['sha256'],'source_carrier':a['carrier_commit'],'scripts':a['scripts'],'approved_guard_mechanism_copy_is_exact72830':True,'actual_readonly_precheck_exit_code':code,'actual_canonical_schema_errors':read(OWN/'read-only-precheck.actual.json')['actual_validator_errors'],'old_failure_and_original_V_pins_unchanged':True,'normal_API_or_additional_V_calls':0,'cell_writes':0,'actual_action_marker_absent':True,'new_private_guard_and_output_paths':str(PRIVATE.relative_to(REPO)),'private_dirs0700_files0600_umask077':True,'action_boundary':'Only a new ROOT_EXPLICIT_PROJECTION_ONLY_SUCCESSOR_AUTHORIZATION with exact SHA may invoke projection action. New once marker and snapshots live here; no old directory/marker/process is reused.','future_exact_write':'The only candidate bytes are the hash-fixed0bec proposal; canonical validator runs before marker/write. All tracked/filesystem modes, ledgers, HEAD/branch/index, all other frontiers and foreign states receive fresh guards. No normal proof call exists in projection runner.','public_boundary':'Explicit own list only; safe actual receipt plus bounded outcome/schema/postguard booleans. Full snapshots/index/ledgers/foreign states and raw streams remain private.'})
    print(json.dumps({'status':'PREPARED_ONLY_READONLY_PRECHECK_EXIT0','runner_sha256':a['scripts']['projection_only.py'],'guard_sha256':a['scripts']['verification_common.py'],'draft_sha256':file_sha(path),'contract_sha256':file_sha(OWN/'preparation-contract.json'),'normal_API_calls':0,'cell_writes':0}))
if __name__=='__main__':
    os.umask(0o077)
    main()
