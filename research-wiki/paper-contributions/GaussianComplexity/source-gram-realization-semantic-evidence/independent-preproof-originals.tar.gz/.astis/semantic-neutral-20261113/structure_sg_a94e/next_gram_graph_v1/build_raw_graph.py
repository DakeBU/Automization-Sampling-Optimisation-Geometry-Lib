from pathlib import Path
import bisect,datetime,hashlib,json,re
OUT=Path(__file__).resolve().parent
bs=json.loads((OUT/'source-blocks.RAWFIRST.json').read_text());B={b['id']:b for b in bs};s=(OUT/'original.2610.20492v1.RAW.html').read_text();starts=[0]+[m.end() for m in re.finditer('\n',s)]
def ref(ids):return [{'source_id':i,**{k:v for k,v in B[i].items() if k not in ['id','tag','text']}} for i in ids]
ns=[];es=[]
def N(i,k,st,ids):ns.append({'id':i,'kind':k,'statement':st,'source_anchors':ref(ids)})
def E(i,ps,c,ids,dis):es.append({'id':i,'parents':ps,'consumer':c,'logic':'AND','consumer_use_sites':ref(ids),'discharge':dis})
N('regime','SOURCE','q>=0 integer,2q+1<d; original independent g_1..g_(q+1)~N(0,I_d). r=q+1,n=2q+1.',['S4.Thmtheorem4.p1.1','A3.SS2.p1.1'])
N('grid-objects','LITERAL','theta_i=(i-1/2)pi/d; t_i=(1,sqrt2 cos(theta_i),...,sqrt2 cos(q theta_i)); gamma_i=((g_1)_i,...,(g_r)_i); D_n=diag(cos(n theta_i)); B row_i=d^(-1/2)(gamma_i tensor t_i)^T.',['S4.E11','S4.Ex12','A3.Ex85','A3.SS2.p1.2'])
N('cutoff','LITERAL','L=2r+3log(1000d),R_i=||gamma_i||^2; G=T={all i:R_i<=L}, literal closed cutoff under original unconditional mu.',['A3.SS2.p10.1','A3.Ex105'])
N('Y','LITERAL','Y_i=d^(-1)(gamma_i gamma_i^T tensor t_i t_i^T)1_(R_i<=L).',['A3.Ex107'])
N('actual-mean','SOURCE','E_mu Y_i=(a/d)(I_r tensor t_i t_i^T); a=(1/r)E[R_i1_(R_i<=L)] is actual truncated Gaussian row-norm mean, common across i.',['A3.SS2.p12.2','A3.Ex108','A3.SS2.p12.3','A3.SS2.p12.4'])
N('a-bounds','SOURCE','E R_i=r and0<=a<=1. The common a is actual expectation; no positivity or bias certificate is supplied by caller.',['A3.SS2.p12.3'])
N('Z-weight','LITERAL','Z_i=Y_i-E_mu Y_i; w_i=cos(n theta_i), weighted family w_i Z_i. Same unconditional mu is used for every mean.',['A3.SS2.p13.1','A3.SS2.p13.3'])
N('cosine-sum','SOURCE','For integer0<|k|<2d, sum_i cos(k theta_i)=0 by sine telescoping and nonzero sin(k pi/(2d)).',['A3.SS2.p4.1','A3.EGx5','A3.SS2.p4.2'])
N('frame','SOURCE','The source states ||t_i||^2<=2r, sum_i t_i t_i^T=d I_r, and sum_i w_i t_i t_i^T=0. Only the two exact frame sums are consumed here; the norm estimate is contextual and no radius result is claimed.',['A3.Ex87','A3.SS2.p5.1','A3.Ex90','A3.SS2.p5.2','A3.EGx6','A3.SS2.p5.3','A3.SS2.p7.1','A3.Ex96','A3.SS2.p7.2','A3.EGx8','A3.SS2.p7.3','A3.Ex102'])
N('aggregate-means','SOURCE','sum_i E_mu Y_i=a I_(r^2), sum_i w_i E_mu Y_i=0; truncated weighted sum has zero expectation.',['A3.Ex110','A3.SS2.p12.5'])
N('gap-row-law-integrability','SOURCE_GAP','From the original Gaussian columns derive actual row marginal N(0,I_r), measurability, true integrability of row norm square and cutoff row outer products, and Bochner integrability of Y. The totalized integral must not replace true source expectation.',['A3.SS2.p1.2','A3.Ex107','A3.Ex108'])
N('gap-radial-mean','SOURCE_GAP','Radial Gaussian cutoff is sign/permutation invariant; offdiagonal truncated row moments vanish, diagonals agree, and trace/r identifies a. Transport actual row law and coordinate integrals to same-mu actual matrix mean.',['A3.SS2.p12.2','A3.Ex108','A3.SS2.p12.4'])
N('gap-a-le-one','SOURCE_GAP','Since0<=R1_(R<=L)<=R, row norm-square moment E R=r and r>0 give0<=a<=1. Integrability and probability mass are internal; no tail estimate or a<=1 public binder is needed.',['A3.SS2.p12.3'])
N('gap-d-sqrt','SOURCE_GAP','Derive r>=1,d>=2 from source regime and (d^(-1/2))^2=1/d for literal real positive d, including the exact normalization represented by sqrt(1/d) if that notation is chosen. No sqrt-normalization certificate is a public premise.',['A3.SS2.p1.2','A3.SS2.p17.1'])
N('gap-Gram-expansion','SOURCE_GAP','Entrywise expand actual B^T B=(1/d)sum_i(gamma_i gamma_i^T tensor t_i t_i^T) and B^T D_n B=(1/d)sum_i w_i(gamma_i gamma_i^T tensor t_i t_i^T), preserving pair-index ordering gamma first,t second.',['A3.SS2.p1.2','A3.SS2.p17.1'])
N('gap-cutoff-agreement','SOURCE_GAP','For every actual omega in G, all inclusive cutoff indicators equal1, hence sum_i Y_i(omega)=B(omega)^T B(omega) and sum_i w_iY_i(omega)=B(omega)^T D_nB(omega). Outside G these equalities are not asserted.',['A3.SS2.p17.1'])
N('P-Ex125','TARGET-SOURCE','For every actual omega in G: sum_i Z_i(omega)=B(omega)^T B(omega)-aI_(r^2), and sum_i w_iZ_i(omega)=B(omega)^T D_nB(omega). Equivalent printed first identity: B^TB-I=sumZ-(1-a)I.',['A3.SS2.p17.1','A3.Ex125'])
N('source-norm-event','LOCAL-CONDITION','At source threshold Delta, both actual centered-sum norms are<=Delta. For the private deterministic consumer one may universally generalize the real threshold Delta and retain these as pointwise event antecedents, without claiming their probability.',['A3.Ex124','A3.SS2.p17.2'])
N('gap-bias-norm','SOURCE_GAP','Use a<=1 and nonempty r^2-dimensional real L2 operator carrier to get ||(1-a)I||op=1-a. Triangle inequality applied to B^TB-I=sumZ-(1-a)I yields the first norm bound; second is exact weighted identity.',['A3.Ex125','A3.Ex126'])
N('T-Ex126-deterministic','TARGET-PRIVATE-GENERALIZATION','For every real Delta and actual sample omega, membership in G and both centered norm conditions<=Delta imply ||B^TB-I||op<=Delta+(1-a) and ||B^TD_nB||op<=Delta. If Delta<0 the antecedent is impossible; no Delta>=0 premise is added. No0.995 probability conclusion is included.',['A3.SS2.p17.2','A3.Ex126'])
E('e01',['regime','grid-objects','Y','cutoff'],'gap-row-law-integrability',['A3.Ex108'],'Discharge actual law/integrability under original Gaussian experiment internally.')
E('e02',['gap-row-law-integrability','Y'],'gap-radial-mean',['A3.SS2.p12.4'],'Actual radial second moment and coordinate-Bochner transport.')
E('e03',['gap-radial-mean'],'actual-mean',['A3.SS2.p12.4'],'Identify actual mean, not a proxy/caller certificate.')
E('e04',['regime','gap-row-law-integrability'],'gap-a-le-one',['A3.SS2.p12.3'],'Use actual Gaussian norm-square moment and cutoff domination.')
E('e05',['gap-a-le-one'],'a-bounds',['A3.Ex126'],'Discharge actual sign1-a>=0.')
E('e06',['regime','grid-objects','cosine-sum'],'frame',['A3.Ex110'],'Unweighted product-to-sum frequencies<=2q and weighted frequencies1..4q+1<2d; no extra q>0.')
E('e07',['actual-mean','frame'],'aggregate-means',['A3.SS2.p17.1','A3.Ex125'],'Finite sum/tensor linearity, d>0, exact deterministic frame cancellations.')
E('e08',['regime','grid-objects'],'gap-d-sqrt',['A3.SS2.p17.1'],'Positive d real sqrt inverse-scaling algebra.')
E('e09',['gap-d-sqrt','grid-objects'],'gap-Gram-expansion',['A3.SS2.p17.1'],'Literal matrix multiplication and tensor outer-product identity.')
E('e10',['gap-Gram-expansion','Y','cutoff'],'gap-cutoff-agreement',['A3.SS2.p17.1'],'Discharge G membership per row; no global untruncated=truncated assertion.')
E('e11',['gap-cutoff-agreement','aggregate-means','Z-weight'],'P-Ex125',['A3.Ex125'],'Expand finite centered sums; subtract actual mean. No new Gram/mean/frame hypothesis.')
E('e12',['P-Ex125','a-bounds'],'gap-bias-norm',['A3.Ex126'],'Rewrite Bgram-I with minus(1-a)I and use exact operator norm of scalar identity.')
E('e13',['gap-bias-norm','P-Ex125','source-norm-event'],'T-Ex126-deterministic',['A3.Ex126'],'Use pointwise event antecedents only; no Bernstein/probability premise.')

used={a['source_id'] for n in ns for a in n['source_anchors']}
cov=[]
for b in bs:
 x={k:v for k,v in b.items() if k!='text'}
 if b['id'] in used:
  x.update(disposition='NODE',node_ids=[n['id'] for n in ns if any(a['source_id']==b['id'] for a in n['source_anchors'])],reason='Represented source definition/assertion/omitted bridge or conditional use. Mixed-block fragment dispositions below take precedence where supplied.')
 else:
  sid=b['id']
  if b['tag'].startswith('h'):reason='Navigation/proof heading, no mathematical premise.'
  elif sid in ['A3.Ex109','A3.EGx10'] or sid.startswith(('A3.SS2.p11.','A3.SS2.p10.2','A3.SS2.p10.3')) or sid=='A3.Ex104':reason='Quantitative tail probability/truncation bias estimate is not needed for deterministic G-conditioned identities or threshold implication. a<=1 is derived internally by direct moment domination.'
  elif sid.startswith('A3.SS2.p14.') or sid in ['A3.Ex113','A3.Ex114','A3.EGx11','A3.Ex118','A3.Ex119','A3.Ex120','A3.Ex111','A3.Ex112'] or sid.startswith('A3.SS2.p13.2'):reason='Actual norm/radius/fourth-moment/variance estimate is outside this eventwise Gram packet; no variance inequality is silently represented by a family expression.'
  elif sid.startswith(('A3.SS2.p15.','A3.SS2.p16.')) or sid in ['A3.Ex121','A3.Ex122','A3.Ex123']:reason='Unproved matrix Bernstein/threshold inversion/probability argument is excluded background. No tail or probability certificate enters P or private T.'
  elif sid.startswith(('A3.SS2.p18.','A3.SS2.p19.')) or sid in ['A3.Ex103','A3.Thmtheorem6.p1.1','A3.EGx12','A3.Ex129','A3.EGx13','A3.Ex132']:reason='Downstream absolute-C concentration/probability or uniform Krylov theorem; current packet stops at deterministic Ex125/Ex126 implications.'
  elif sid in ['A3.Ex86','A3.EGx7','A3.EGx9'] or sid.startswith(('A3.SS2.p3.','A3.SS2.p6.')):reason='Range(B)=Kq or untruncated Gram expectation result is not required: literal row Gram algebra and actual truncated aggregate means are used instead.'
  elif sid.startswith('S4.'):reason='Contextual source result/spectrum/Krylov discussion outside the deterministic packet; exact needed regime/grid/D_n are separately represented.'
  else:reason='Connector or prior/downstream proof context not an additional premise of the bounded eventwise packet.'
  x.update(disposition='EXCLUDED',reason=reason)
 cov.append(x)
# Exact partitions prevent whole mixed paragraphs from silently claiming excluded estimates.
fr=[]
def split(sid,mark,left,right):
 b=B[sid];a,z=b['char_start'],b['char_end_exclusive'];k=s.index(mark,a,z)
 for j,(u,v),(disp,why) in zip([1,2],[(a,k),(k,z)],[left,right]):
  fr.append({'source_id':sid,'fragment':j,'char_start':u,'char_end_exclusive':v,'byte_start':len(s[:u].encode()),'byte_end_exclusive':len(s[:v].encode()),'line_start_1based':bisect.bisect_right(starts,u),'line_end_1based':bisect.bisect_right(starts,max(u,v-1)),'raw_sha256':hashlib.sha256(s[u:v].encode()).hexdigest(),'disposition':disp,'reason':why})
split('A3.SS2.p10.1','Since ',('NODE','Literal L and R definitions.'),('EXCLUDED','MGF/Markov quantitative tail preparation is not used.'))
split('A3.SS2.p13.1','Using ',('NODE','Actual Z_i=Y_i-E_muY_i definition.'),('EXCLUDED','Norm/radius-bound preparation is outside the packet.'))
split('A3.SS2.p4.1','Recall ',('EXCLUDED','Boxed untruncated Gram expectation heading is outside the packet.'),('NODE','Midpoint grid and nonzero-frequency cosine-sum domain.'))
split('A3.SS2.p7.3','Consequently,',('NODE','Exact high-frequency deterministic frame cancellation.'),('EXCLUDED','Connector to untruncated weighted Gram expectation calculation.'))
split('A3.SS2.p17.2','with probability',('NODE','Pointwise intersection of literal cutoff and norm events gives deterministic consumer.'),('EXCLUDED','0.995 probability composition is not claimed or used.'))
g={'version':'RAWFIRST-GRAM-v1','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_sha256':'6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915','before_exact_new_Gram_seal_read':True,'nodes':ns,'edges':es,
 'alternative_routes':{'status':'One chosen sufficient route is recorded for each required mathematical bridge. No alternative radial/mean/norm routes are flattened into an AND. No claim that this is the unique possible proof.','a_bound_route':'Direct truncated-norm domination plus Gaussian norm-square moment; quantitative tail-bias route is explicitly excluded.'},
 'source_hypotheses_not_certificates':['Source integer regime','Literal G membership and actual norm-event memberships as conclusion antecedents only'],
 'excluded_analytic_background':'Matrix Bernstein is an unproved separate background obligation; neither its theorem nor its conclusion is a source premise here.',
 'review_status':'Requires distinct raw-source topology challenge; no extractor self-approval, proof, source/normalV verdict or SAU admission.'}
c={'version':'RAWFIRST-GRAM-coverage-v1','blocks':cov,'mixed_fragments':fr,'counts':{'total':len(cov),'NODE':sum(x['disposition']=='NODE' for x in cov),'EXCLUDED':sum(x['disposition']=='EXCLUDED' for x in cov)}}
for name,d in [('SOURCE-GRAPH.RAWFIRST.v1.json',g),('SOURCE-COVERAGE.RAWFIRST.v1.json',c)]: (OUT/name).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
f={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'stage':'Independent original-source Gram graph frozen BEFORE reading exact new seal/signatures/formation','files':{n:hashlib.sha256((OUT/n).read_bytes()).hexdigest() for n in ['SOURCE-GRAPH.RAWFIRST.v1.json','SOURCE-COVERAGE.RAWFIRST.v1.json','SOURCE-RAWFREEZE.v1.json']}}
(OUT/'TOPOLOGY-RAWFREEZE.v1.json').write_text(json.dumps(f,indent=2)+'\n');print(json.dumps(f,indent=2))
