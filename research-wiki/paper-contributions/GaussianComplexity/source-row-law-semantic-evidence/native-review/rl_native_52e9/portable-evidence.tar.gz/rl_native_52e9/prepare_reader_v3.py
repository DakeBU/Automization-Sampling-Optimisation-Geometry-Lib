from run import ROOT
import json
s=(ROOT/'reader_static_v2.py').read_text().replace("''.join(s['lean'] for s in u['steps'][2:])", "'\\n'.join(s['lean'] for s in u['steps'][2:])")
s=s.replace("'private_consumer_full_module_exact_145_lines':True,", "'private_consumer_full_module_exact_145_lines':True,'step_separator_blank_lines':[66,86,110],")
(ROOT/'reader_static_v3.py').write_text(s)
p=ROOT/'verifier-failures.json';data=json.loads(p.read_text());data.append({'original':'receipts/reader-static-driver-v2.json','class':'IMPLEMENTATION_FAILED','scope':'Verifier exact-concatenation assertion','diagnosis':'The four consumer folds are exact source spans; the source has three blank separator lines66,86,110 between them. V3 reconstructs using exactly one newline separator. Complete source export remains all145 exact lines. No source or renderer changed.'});p.write_text(json.dumps(data,indent=2)+'\n')
print('Preserved V2. V3 checks exact fold spans plus all145-line reconstruction including three blank separators.')
