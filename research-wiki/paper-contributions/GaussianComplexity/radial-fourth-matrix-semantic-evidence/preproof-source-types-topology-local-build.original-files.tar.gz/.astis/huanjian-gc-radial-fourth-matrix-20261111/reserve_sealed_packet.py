"""Reserve one literal source packet with a private preservation baseline."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys

sys.dont_write_bytecode = True
sys.path.insert(0, 'tools')
import astis_advance as advance
import astis_frontier_cells as frontiers

workspace = Path(__file__).resolve().parent.relative_to(Path.cwd())
paper = Path('research-wiki/paper-contributions/GaussianComplexity')
evidence = paper / 'radial-fourth-matrix-semantic-evidence'
seal_path = paper / 'radial-fourth-matrix-statement-seal.json'
cell_path = Path('research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-radial-fourth-matrix.json')
ledger = Path('runs/substantive_advances.jsonl')
advance_id = 'ASTIS-SA-20261111-GaussianComplexityRadialFourthMatrix'
owner = 'huanjian_gc_20261111_radial_fourth_matrix'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
dump = lambda value: (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode()


def create(path, raw):
    with path.open('xb') as out:
        out.write(raw)


head = subprocess.check_output(['git', 'rev-parse', 'HEAD']).decode().strip()
assert head == 'a7244d6ad6043e03c126be08d9d32e2ae19a9e41'
assert not subprocess.check_output(['git', 'diff', 'HEAD', '--name-only'])
seal_raw = seal_path.read_bytes()
assert sha(seal_raw) == 'cc628d801ed367e1e57e99d69449d36a90b2803f7371986b964b4864409f6dec'
seal = json.loads(seal_raw)
producer, consumer = [seal[key]['planned_file'] for key in ('producer', 'actual_private_consumer')]
assert not Path(producer).exists() and not Path(consumer).exists() and not cell_path.exists()
ledger_raw = ledger.read_bytes()
assert sha(ledger_raw) == '96292fa7e0198b262112240d532ac50d34c2150d938564a3c46c73ddc58476f0'
states = advance._replay_advances([json.loads(line) for line in ledger_raw.splitlines()])
assert advance_id not in states
assert states['ASTIS-SA-20261111-GaussianComplexityTruncatedRowMoment']['state'] == 'VERIFIED'
frontier_hashes = {str(path): sha(path.read_bytes()) for path in cell_path.parent.rglob('*')
                   if path.is_file() and not path.is_symlink()}
assert len(states) == 303 and len(frontier_hashes) == 463
baseline = {
    'head': head, 'ledger_bytes': len(ledger_raw), 'ledger_sha256': sha(ledger_raw),
    'all_foreign_states': states, 'all_existing_frontier_hashes': frontier_hashes,
    'tracked_git_index': subprocess.check_output(['git', 'ls-files', '--stage']).decode(),
    'scope': 'Private complete preservation state. Keep local. Never export the full replay.',
}
create(workspace / 'preproof-baseline.private.json', dump(baseline))
searches = [
    'Samplinglib canonical standard-Gaussian norm and row-moment nodes from the completed preceding packets retain their exact declaration identities.',
    'Mathlib canonical standard Gaussian, Euclidean coordinates, Bochner integral, matrix product, PSD and L2 operator norm definitions were audited literally before new-target proof API retrieval.',
    'The current source target is the fourth weighted matrix moment and its individual squared-summand consumer. Prior conceptual symmetry comparison supplies no compiled fourth-moment implication.',
]
slug = 'huanjian-gaussian-radial-fourth-matrix.json'
boundary = seal['scope_boundary']
cell = {
    'schema_version': 3, 'cell_id': cell_path.stem, 'route': 'samplewiki-route', 'mode': 'faithfulPaper',
    'title': 'Gaussian radial fourth matrix moment and individual squared-summand bound',
    'source_anchor': 'arXiv2610.20492v1 C.2 Ex113, Ex114 and p14.3, with definitions in p1/p10 and the standing source range',
    'target_statement': seal['producer']['signature'] + '\nPrivate actual consumer\n' + seal['actual_private_consumer']['signature'],
    'status': 'claimed', 'owner_id': owner, 'advance_id': advance_id,
    'reservation_only': 'Exact-type reservation. Normal ledger intake has not occurred.',
    'parents': [], 'consumers': ['The actual private individual second-moment PSD upper bound preceding C.2 EGx11.'],
    'shared_floor_audit': {'searched': searches, 'classification': 'missing', 'decision': 'new_route_local',
                           'canonical_declaration': seal['producer']['name'], 'canonical_shared_cell': ''},
    'reuse_plan': {'searched_existing': searches, 'reused_declarations': [], 'new_shared_declarations': [],
                  'known_consumers': [], 'planned_consumers': [seal['actual_private_consumer']['name']],
                  'no_duplicate_wrapper': True,
                  'decision_reason': 'Derive the actual canonical fourth matrix mean and consume it in the individual squared-summand PSD bound.'},
    'reader_contract': {'reference_standard': 'textbook/chapter-01/section-1-3.html',
                        **{key: False for key in ['source_ordered', 'source_statement_adjacent', 'natural_language_formula_proof',
                                                 'hidden_assumptions_visible', 'lean_collapsed', 'external_dependencies_visible']},
                        'status': 'Prospective exact formulas, source steps and adjacent Lean after proof.'},
    'graph_contribution': {'lean_view': 'new-node', 'overview_view': 'no-change-with-reason', 'functor_view': 'pending-audit',
                          'edge_semantics': 'formal-solid; overlays-dashed', 'color_semantics': 'evidence-status; library-scope',
                          'focus_targets': [seal['producer']['name']],
                          'visual_review': 'Raw source reading and exact type review. Compiled parent edges require actual proof evidence.'},
    'learning_contract': {
        'control_plane_math_authority': False, 'process_memory_checked': True, 'process_memory_ids': [],
        'failure_class': 'NONE',
        'salvage': {'required': False, 'status': 'not-applicable', 'reason': 'No target proof attempted.',
                    'promoted_fragments': [], 'discarded_fragments': []},
        'parallelism': {'decision': 'serial', 'direction_fingerprints': [],
                        'expected_information_gain': 'One mathematical prover with independent raw-source and different-role topology reviewers.',
                        'shared_verified_context_digest': ''},
        'cross_route_blind_spot_audit': {'required': False, 'status': 'not-applicable', 'evidence': '',
                                       'canonical_route': '', 'selection_reason': 'One source-facing implementation packet.'},
        'reader_backpressure': {'purification_status': 'pending', 'exposition_seal_status': 'pending', 'exposition_evidence': '',
                               'source_expansion_nodes': [], 'lean_expansion_nodes': [],
                               'assumptions_preserved': False, 'boundary_preserved': True}},
    'source_detail_audit': {
        'primary_edition': 'arXiv2610.20492v1 raw SHA ' + seal['source']['raw_sha256'],
        'primary_anchor': 'C.2 Ex113, Ex114 and p14.3 before first EGx11 inequality',
        'detail_status': 'omitted',
        'gap': 'Fourth and mixed Gaussian moments, quartic integrability and sign cancellation, rank-one/Kronecker square algebra, PSD indicator removal and Bochner transport require internal proofs.',
        'consulted': [{'source': 'Pinned actual source and canonical Mathlib definitions',
                       'anchor': 'Exact literal Gaussian, matrix multiplication, PSD and integral definition context',
                       'hypothesis_adapter': 'Use the actual standard law. Derive all moment, integrability, square and positivity facts internally. Retain q=0.'}],
        'fidelity_boundary': boundary},
    'statement_seal': {'status': seal['state'], 'file': str(seal_path), 'sha256': sha(seal_raw),
                       'signature_sha256': seal['producer']['signature_sha256'],
                       'private_consumer_signature_sha256': seal['actual_private_consumer']['signature_sha256']},
    'evidence': {'actual_literal_formation': seal['actual_statement_formation'],
                 'actual_definition_meaning': seal['actual_definition_meaning'],
                 'new_target_proof_attempts': 0, 'formalizer_API_pristine': False},
    'blocked': {'reason': '', 'children': []},
    'owned_files': [producer, consumer, str(seal_path), str(cell_path), str(evidence) + '/',
                    'website/content/declaration_lessons/' + slug, 'website/content/publications/' + slug,
                    'research-wiki/semantic-roundtrip/audits/' + slug],
    'forbidden_shared_files': ['AutoSamplingTheory.lean', 'Tests.lean', 'AutoSamplingTheory/TechnicalLemmas/Registry.lean',
                               'website/content/source_correspondence.json', 'website/content/graph_memory_index.json',
                               'website/content/functor_hypergraph.json'],
    'truth_boundary': boundary, 'conceptual_mirror_audit': {'status': 'pending'},
}
create(cell_path, dump(cell))
errors = frontiers.validate_cells(frontiers.load_cells())
assert not errors, errors
assert ledger.read_bytes() == ledger_raw
for path, digest in frontier_hashes.items():
    assert sha(Path(path).read_bytes()) == digest, path
summary = {
    'baseline_commit': head, 'exact_seal_sha256': sha(seal_raw), 'cell': str(cell_path),
    'cell_sha256': sha(cell_path.read_bytes()), 'foreign_full_states_guarded': len(states),
    'older_frontier_files_guarded': len(frontier_hashes),
    'normal_API_and_proof_calls': 0, 'independent_topology_acceptance': 'pending',
}
create(workspace / 'actual-seal-and-reservation-summary.json', dump(summary))
print(json.dumps(summary))
