"""Private immutable-source audit utilities; each subprocess has separate raw streams."""
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

OWN = Path(__file__).resolve().parent
REPO = OWN.parents[2]
COMMIT = '1d1103af694b9663a72b0d610004ed85c7c6b527'
CAND = OWN / 'candidate-1d1103af6'
OUT = OWN / 'native-output'
LEAN = Path('/Users/zhouhuanjian/.elan/toolchains/leanprover--lean4---v4.33.0/bin/lean')

def sha(data):
    return hashlib.sha256(data).hexdigest()

def file_sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        while block := stream.read(1024 * 1024):
            h.update(block)
    return h.hexdigest()

def write_json(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

def run(label, argv, cwd=REPO, env=None, check=True):
    receipts = OWN / 'command-receipts'
    receipts.mkdir(exist_ok=True)
    stamp = dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    prefix = receipts / (stamp + '-' + label)
    out, err = prefix.with_suffix('.stdout.raw'), prefix.with_suffix('.stderr.raw')
    environment = env or {'PATH': '/usr/bin:/bin', 'LC_ALL': 'C', 'GIT_OPTIONAL_LOCKS': '0'}
    start = time.monotonic()
    started = dt.datetime.now(dt.timezone.utc).isoformat()
    with out.open('xb') as stdout, err.open('xb') as stderr:
        result = subprocess.run(list(map(str, argv)), cwd=cwd, env=environment, stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr)
    receipt = {'schema': 'laplace-native-real-command-v1', 'candidate_commit': COMMIT,
               'label': label, 'argv': list(map(str, argv)), 'cwd': str(cwd), 'environment': environment,
               'started_utc': started, 'ended_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
               'elapsed_seconds': time.monotonic() - start, 'exit_code': result.returncode,
               'stdout': {'path': str(out.relative_to(OWN)), 'bytes': out.stat().st_size, 'sha256': file_sha(out)},
               'stderr': {'path': str(err.relative_to(OWN)), 'bytes': err.stat().st_size, 'sha256': file_sha(err)}}
    write_json(prefix.with_suffix('.receipt.json'), receipt)
    print(json.dumps({'label': label, 'exit_code': result.returncode, 'elapsed_seconds': receipt['elapsed_seconds']}), flush=True)
    if check and result.returncode:
        raise RuntimeError(f'{label} failed; see {prefix}')
    return out.read_bytes(), receipt

def git(label, *args):
    return run(label, ['/usr/bin/git', '--no-optional-locks', *args])[0]

def lean_env(packages):
    return {'HOME': '/Users/zhouhuanjian', 'PATH': str(LEAN.parent) + ':/usr/bin:/bin',
            'LEAN_PATH': os.pathsep.join([str(OUT)] + [p['effective_lean_path'] for p in packages]),
            'LC_ALL': 'C', 'LEAN_ABORT_ON_PANIC': '1'}
