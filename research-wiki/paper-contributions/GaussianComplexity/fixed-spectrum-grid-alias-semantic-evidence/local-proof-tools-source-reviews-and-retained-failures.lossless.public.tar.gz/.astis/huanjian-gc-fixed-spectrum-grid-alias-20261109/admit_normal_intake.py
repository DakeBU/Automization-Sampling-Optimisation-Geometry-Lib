"""Execute only after an exact independently reviewed preproof grant exists."""
from pathlib import Path
import gzip,hashlib,json,sys
sys.dont_write_bytecode=True
W=Path('.astis/huanjian-gc-fixed-spectrum-grid-alias-20261109')
B=Path('research-wiki/paper-contributions/GaussianComplexity')
E=B/'fixed-spectrum-grid-alias-semantic-evidence'
C=Path('research-wiki/frontier-cells/ASTIS-SW-GAUSSIAN-COMPLEXITY-fixed-spectrum-grid-alias.json')
L=Path('runs/substantive_advances.jsonl')
ADV='ASTIS-SA-20261109-GaussianComplexityFixedSpectrumGridAlias'
OWNER='huanjian_gc_20261109_fixed_spectrum_grid_alias'
sha=lambda b:hashlib.sha256(b).hexdigest()
dump=lambda x:(json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode()
def ref(p):return {'path':str(p),'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size}
def put(p,b):
 assert not p.exists(),p
 p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)

grant=json.loads((W/'root-preproof-admission-grant.json').read_bytes())
assert grant['source_graph_and_distinct_topology_admitted'] is True
assert grant['target_proof_or_API_search_has_started'] is False
sealpath=W/'statement-seal-v2.json';sealraw=sealpath.read_bytes()
assert sha(sealraw)==grant['seal_sha256']=='5abb51d681187baa67985c54f942a670cdc79e65a5ef12393dcaf8c94a376285'
for r in grant['actual_frozen_review_inputs']:
 assert sha(Path(r['path']).read_bytes())==r['sha256'],r['path']
seal=json.loads(sealraw)
baseline=json.loads((W/'preproof-preservation-baseline.json').read_bytes())
before=L.read_bytes();assert sha(before)==baseline['ledger']['sha256']
for name,h in baseline['all_existing_frontier_raw_hashes'].items():assert sha(Path(name).read_bytes())==h,name
for name,h in baseline['protected_shared_raw_hashes'].items():assert sha(Path(name).read_bytes())==h,name
assert not C.exists() and not E.exists()
sys.path.insert(0,'tools');import astis_advance as advance
states=advance._replay_advances([json.loads(x) for x in before.splitlines()])
assert states==baseline['all_existing_SAU_states'] and ADV not in states
assert not [k for k,v in states.items() if v['state']=='STABILIZING']
declaration=seal['producer']['name'];prod=seal['producer']['planned_file'];test=seal['actual_private_consumer']['planned_file']
boundary=seal['truth_boundary']
publicseal=B/'fixed-spectrum-grid-alias-statement-seal.json'
put(publicseal,sealraw)
put(E/'preproof-source-admission.json',dump(grant))
put(E/'environment-and-preservation-baseline.json.gz',gzip.compress((W/'preproof-preservation-baseline.json').read_bytes(),mtime=0))
put(E/'type-formation-and-seal-confirmation-v2.json',(W/'type-formation-and-seal-confirmation-v2.json').read_bytes())
put(E/'producer.signature.lean.txt',seal['producer']['signature'].encode())
put(E/'consumer.signature.lean.txt',seal['actual_private_consumer']['signature'].encode())
searched=seal['shared_floor_audit']['searched_before_seal']
cell={
 'schema_version':3,'cell_id':C.stem,'route':'samplewiki-route','mode':'faithfulPaper',
 'title':'All-integer midpoint cosine aliases with actual weighted inverse-grid series',
 'source_anchor':'arXiv2610.20492v1 A3.SS3.p3/Ex139; deterministic weighted consumer A3.SS3.p6/Ex144',
 'target_statement':seal['producer']['signature'],'status':'claimed','owner_id':OWNER,'advance_id':ADV,'parents':[],
 'consumers':['Sealed actual private weighted inverse-grid alias-supported summable series; not compiled yet.','Planned exact finite-grid trace/weighted moments and Lemma4.5; not certified by this packet.'],
 'shared_floor_audit':{'searched':searched,'classification':'adapt','decision':'adapt_existing','canonical_declaration':declaration,'canonical_shared_cell':'','notes':'Post-admission exact Mathlib/shared canonicality search remains required. Reuse a found identical canonical theorem instead of introducing a duplicate wrapper.'},
 'reuse_plan':{'searched_existing':searched,'reused_declarations':[],'new_shared_declarations':[],'known_consumers':[],
  'planned_consumers':['actual_weighted_inverse_grid_alias_series; use new alias and canonical C7 materially.'],
  'no_duplicate_wrapper':True,'decision_reason':'Literal integer-frequency source identity with an actual finite-grid alias-supported consumer; no Gaussian expectation or closed-moment claim.'},
 'reader_contract':{'reference_standard':'textbook/chapter-01/section-1-3.html','source_ordered':True,'source_statement_adjacent':True,'natural_language_formula_proof':True,'hidden_assumptions_visible':True,'lean_collapsed':True,'external_dependencies_visible':True},
 'graph_contribution':{'lean_view':'new-node','overview_view':'no-change-with-reason','functor_view':'none-found','edge_semantics':'formal-solid; overlays-dashed','color_semantics':'evidence-status; library-scope','focus_targets':[declaration],'visual_review':'Exact preproof source topology admitted only. No compiled node, site or conceptual bridge acceptance yet.'},
 'source_detail_audit':{'primary_edition':'arXiv2610.20492v1','primary_anchor':'A3.SS3.p3;A3.Ex139;A3.SS3.p6;A3.Ex144','detail_status':'omitted',
  'gap':'Source supplies finite cosine ratio and multiple-of-2d evaluation. Nonzero-denominator/finite-trigonometric background, integer quotient/zpow, weighted convergence and finite series interchange must be produced internally. Gaussian expectation identification and closed alias-tail resummations remain outside this packet.',
  'consulted':[{'source':'Pinned raw source, independent raw-first graph and distinct exact topology/binder challenge','anchor':'A3.SS3.p3,p4,p6;S4.E11;S4.Thmtheorem5','hypothesis_adapter':'All Int k including negative/zero; source d>=2. Private deterministic consumer d>=2,kappa>=2,1<=n<d with Int subtraction and produced Summable.'}],
  'fidelity_boundary':boundary},
 'learning_contract':{'control_plane_math_authority':False,'process_memory_checked':True,'process_memory_ids':seal['process_memory']['consulted_ids'],'failure_class':'IMPLEMENTATION_FAILED',
  'salvage':{'required':True,'status':'completed','reason':'Only temporary Prop-formation reserved-token parser failures; exact v2 types compiled. No target assertion or failed target proof exists.','promoted_fragments':['Exact type-formed signatures only; no proved theorem credit.'],'discarded_fragments':[]},
  'parallelism':{'decision':'serial','direction_fingerprints':[],'expected_information_gain':'Root sole mathematical worker; separate source graph and challenge roles address source uncertainty only.','shared_verified_context_digest':seal['producer']['signature_sha256']},
  'cross_route_blind_spot_audit':{'required':False,'status':'not-applicable','evidence':'','canonical_route':'','selection_reason':'No parallel proof routes.'},
  'reader_backpressure':{'purification_status':'pending','exposition_seal_status':'pending','exposition_evidence':'','source_expansion_nodes':[],'lean_expansion_nodes':[],'assumptions_preserved':True,'boundary_preserved':True}},
 'statement_seal':{'path':str(publicseal),'sha256':sha(sealraw),'signature_sha256':seal['producer']['signature_sha256'],'status':'EXACT_TYPE_FORMED_INDEPENDENT_PREPROOF_ADMITTED_NO_PROOF'},
 'source_proof_coverage':{'preproof_admission':ref(E/'preproof-source-admission.json'),'internal_obligations_still_unproved':seal['internal_dependencies_not_premises']},
 'evidence':{'execution_boundary':boundary,'focused_checks':[],'preproof_source_admission':str(E/'preproof-source-admission.json'),'actual_consumer_seal':seal['actual_private_consumer'],'independent_verification':'','root_build':'','graph_regeneration':'','pr':''},
 'blocked':{'reason':'','children':[]}}
proposal=advance.AdvanceProposal(advance_id=ADV,task_id='ASTIS-SW-GAUSSIAN-COMPLEXITY-2026',
 goal='Prove all-integer exact midpoint-grid cosine alias sum, and consume it with canonical C7 in an actual summable weighted inverse-grid alias series.',
 source_anchor=cell['source_anchor'],theorem_delta=seal['producer']['signature'],truth_boundary=boundary,created_by=OWNER,
 dag_inputs=('source:arXiv2610.20492v1:A3.SS3.p3/Ex139','canonical:C7 actual_inverse_spectrum_cosine_expansion for private consumer'),
 proposed_files=(prod,test,str(C),'website/content/declaration_lessons/huanjian-fixed-spectrum-grid-alias.json','website/content/publications/huanjian-fixed-spectrum-grid-alias.json'),
 focused_checks=('lake env lean '+prod,'lake env lean '+test),modes=('source-reading','proof-design','compiler-diagnosis'),priority=50,frontier_cell=C.stem,target_declarations=(declaration,))
proposal.validate();advance.propose_advance(proposal)
advance.transition_advance(ADV,'CLAIMED',worker_id=OWNER,evidence={'exact_statement_seal':ref(publicseal),'preproof_admission':ref(E/'preproof-source-admission.json'),'truth_boundary':boundary})
advance.transition_advance(ADV,'EXPLORING',worker_id=OWNER,evidence={'preproof_admission':ref(E/'preproof-source-admission.json'),'source_graph_and_distinct_topology_admitted':True,'target_proof_API_work_starts_after_this_event':True,'truth_boundary':boundary})
C.write_bytes(dump(cell))
after=L.read_bytes();assert after.startswith(before);appended=after[len(before):];assert len(appended.splitlines())==3
newstates=advance._replay_advances([json.loads(x) for x in after.splitlines()])
assert newstates[ADV]['state']=='EXPLORING' and newstates[ADV]['owner_id']==OWNER
assert {k:v for k,v in newstates.items() if k!=ADV}==states
for name,h in baseline['all_existing_frontier_raw_hashes'].items():assert sha(Path(name).read_bytes())==h,name
for name,h in baseline['protected_shared_raw_hashes'].items():assert sha(Path(name).read_bytes())==h,name
put(E/'normal-EXPLORING-append.exact.jsonl',appended)
put(E/'normal-intake-preservation.json',dump({'normal_API_calls':3,'state':'EXPLORING','advance_id':ADV,'owner':OWNER,'before_ledger_sha256':sha(before),'after_ledger_sha256':sha(after),'raw_prefix_preserved':True,'foreign_SAU_states_preserved':len(states),'foreign_frontier_files_preserved':len(baseline['all_existing_frontier_raw_hashes']),'shared_models_and_discovery_unchanged':True,'STAB':[],'append':ref(E/'normal-EXPLORING-append.exact.jsonl'),'new_cell':ref(C),'proof_consumer_sourceV_or_integration_credit':False}))
print(json.dumps({'normal_state':'EXPLORING','normal_API_calls':3,'append_sha256':sha(appended),'foreign_states_preserved':len(states),'foreign_frontiers_preserved':len(baseline['all_existing_frontier_raw_hashes']),'new_source_verdict_or_mathematical_result':False}))
