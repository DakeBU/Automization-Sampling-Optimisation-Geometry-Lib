import os, sys, json, hashlib, subprocess, datetime, pathlib, shutil
R=pathlib.Path('/Users/zhouhuanjian/ASTIS-GC')
D=pathlib.Path(__file__).resolve().parent
C='eed870294de059136900110ade59b4a292a126ad'
P='AutoSamplingTheory/ExampleCases/GaussianComplexity/ZeroQuerySeparation.lean'
T='Tests/GaussianComplexityZeroQuerySeparation.lean'
E='research-wiki/paper-contributions/GaussianComplexity/zero-query-separation-semantic-evidence'
def sha(b): return hashlib.sha256(b).hexdigest()
def write(p,b):
 p=D/p; p.parent.mkdir(parents=True,exist_ok=True); p.write_bytes(b if isinstance(b,bytes) else b.encode()); return p
def js(p,v): return write(p,json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def run(label,args,cwd=R,env=None):
 start=datetime.datetime.now(datetime.timezone.utc).isoformat()
 r=subprocess.run(args,cwd=cwd,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 out=write('logs/'+label+'.log',r.stdout)
 js('logs/'+label+'.receipt.json',{'argv':args,'cwd':str(cwd),'start':start,'end':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':r.returncode,'stdout_sha256':sha(r.stdout),'stdout_bytes':len(r.stdout),'environment_overrides':{k:v for k,v in (env or {}).items() if k=='LEAN_PATH'}})
 print(label,r.returncode,len(r.stdout),flush=True)
 return r
def gitbytes(p): return subprocess.check_output(['git','show',C+':'+p],cwd=R)
def setup():
 files=[P,T,'lean-toolchain','lake-manifest.json',E+'/source-to-lean-map-v1.json','research-wiki/paper-contributions/GaussianComplexity/zero-query-separation-statement-seal.json','website/content/declaration_lessons/huanjian-zero-query-separation.json','website/content/publications/huanjian-zero-query-separation.json','research-wiki/semantic-roundtrip/audits/huanjian-zero-query-separation.json']
 files += ['AGENTS.md','docs/theorem-publication-protocol.md','docs/proof-digestion-protocol.md','docs/evidence-routed-memory-protocol.md','.agents/skills/astis-semantic-roundtrip/SKILL.md']
 for p in files: write('candidate/'+p,gitbytes(p))
 identity=run('candidate-identity',['git','show','--no-patch','--format=fuller',C]).stdout.decode()
 deps=json.loads(gitbytes('lake-manifest.json'))
 assert sha(gitbytes('lake-manifest.json'))=='b83ca83b9cf7caa85fa8b023c2ff9a3fb7a7cce7e1c332e810c348535ec49c37'
 rows=[]
 for pkg in deps['packages']:
  p=R/'.lake/packages'/pkg['name']; h=run('dependency-'+pkg['name']+'-head',['git','rev-parse','HEAD'],cwd=p).stdout.decode().strip(); s=run('dependency-'+pkg['name']+'-tracked-status',['git','status','--porcelain','--untracked-files=no'],cwd=p).stdout.decode(); rows.append({'name':pkg['name'],'actual_head':h,'manifest_rev':pkg['rev'],'tracked_clean':not s}); assert h==pkg['rev'] and not s
 leanpath=run('native-which',['lake','env','which','lean']).stdout.decode().strip(); version=run('native-version',[leanpath,'--version']).stdout.decode().strip(); assert '4.33.0' in version
 paths=run('lake-lean-path',['lake','env','printenv','LEAN_PATH']).stdout.decode().strip(); js('environment.json',{'candidate':C,'candidate_info':identity,'P_sha':sha(gitbytes(P)),'P_bytes':len(gitbytes(P)),'T_sha':sha(gitbytes(T)),'T_bytes':len(gitbytes(T)),'toolchain':gitbytes('lean-toolchain').decode(),'manifest_sha':sha(gitbytes('lake-manifest.json')),'toolchain_sha':sha(gitbytes('lean-toolchain')),'lean_binary':leanpath,'lean_binary_sha':sha(pathlib.Path(leanpath).read_bytes()),'version':version,'dependencies':rows,'lake_lean_path':paths})
 for p in [P,T,'lean-toolchain','lake-manifest.json']: assert (R/p).read_bytes()==gitbytes(p),p
 run('normal-lake-pair',['lake','build',P[:-5].replace('/','.'),T[:-5].replace('/','.')])
 # Each symlink is dependency cache only; the two owned modules have no symlink.
 src=D/'fresh/source'; out=D/'fresh/lib'; src.mkdir(parents=True,exist_ok=True); out.mkdir(parents=True,exist_ok=True)
 for p in [P,T]:
  target=src/p; target.parent.mkdir(parents=True,exist_ok=True); target.write_bytes(gitbytes(p)); (out/pathlib.Path(p).parent).mkdir(parents=True,exist_ok=True)
 env=os.environ.copy(); env['LEAN_PATH']=str(out)+':'+':'.join(str((R/p).resolve()) if not pathlib.Path(p).is_absolute() else p for p in paths.split(':'))
 js('fresh/symlink-inventory.json',[{'entry':str(p),'target':os.readlink(p)} for p in (D/'fresh').rglob('*') if p.is_symlink()])
 for name,p in [('P',P),('T',T)]:
  r=run('fresh-'+name,[leanpath,'-o',str(out/p.replace('.lean','.olean')),'-i',str(out/p.replace('.lean','.ilean')),p],cwd=src,env=env); assert r.returncode==0
 js('fresh/import-path.json',{'LEAN_PATH':env['LEAN_PATH'],'first_entry':str(out),'fresh_P_import':str(out/P.replace('.lean','.olean')),'no_P_symlink':not (out/P.replace('.lean','.olean')).is_symlink(),'note':'Owned P/T are regular files produced here. No dependency symlinks were needed: absolute dependency LEAN_PATH follows the fresh output directory. Fresh T cannot select cached P because fresh output path is first.'})
 js('fresh/artifacts.json',[{'path':str(p.relative_to(D)),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in (D/'fresh').rglob('*') if p.is_file()])
if __name__=='__main__': setup()
