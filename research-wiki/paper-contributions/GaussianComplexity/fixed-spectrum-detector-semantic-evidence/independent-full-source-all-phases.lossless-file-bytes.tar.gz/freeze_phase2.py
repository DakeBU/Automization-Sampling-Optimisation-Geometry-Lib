"""Freeze the authorized selective Phase 2 review; no proof or API execution."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import runpy
import stat

ROOT = Path('/Users/zhouhuanjian/ASTIS-GC')
OUT = ROOT / '.astis/semantic-neutral-20261110/d_fresh_a6c943'
INPUT = ROOT / 'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-detector-semantic-evidence/selective-fresh-source-phase2-input.json'
SOURCE = ROOT / '.astis/huanjian-resume-20261103/2610.20492v1.html'

def digest(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data),
            'sha256': hashlib.sha256(data).hexdigest()}

def sha_string(text):
    return hashlib.sha256(text.encode()).hexdigest()

def write_json(path, obj):
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n')

phase1_receipt = OUT / 'phase1-freeze-receipt.json'
phase1_cognition = OUT / 'phase1-source-cognition.md'
phase1_manifest = OUT / 'phase1-input-exposure-manifest.json'
assert digest(phase1_receipt)['sha256'] == 'f7a0179225df164d57079e25ec13057e31bbd3def0b22b6916ee73cc13d7abb8'
assert digest(phase1_cognition)['sha256'] == 'c5f8bca886476e04c99ff7a9bcc9423ed43e4a3575f7d5616a866ed43abff66a'
assert digest(phase1_manifest)['sha256'] == '93923c9fb53d8ce41635c51550c66b8f65a52f3de798ee925aae3684aa8a1b86'
previous = json.loads(phase1_receipt.read_text())
for entry in previous['artifacts']:
    path = Path(entry['path'])
    assert path.is_relative_to(OUT)
    assert digest(path) == entry
    assert stat.S_IMODE(path.stat().st_mode) == 0o444
assert digest(SOURCE)['sha256'] == '6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'

input_data = INPUT.read_bytes()
assert hashlib.sha256(input_data).hexdigest() == '7ea3428cd87be556bd4c4133f6eed4dc0bfabf7e2f4940e22bc3f1732b74ed54'
j = json.loads(input_data)
for block, textkey, hashkey in [
    ('source', 'original_text', 'text_sha256'),
    ('lean', 'statement', 'statement_sha256'),
    ('blind_reconstruction', 'text', 'text_sha256'),
]:
    assert sha_string(j[block][textkey]) == j[block][hashkey]
snapshot_path = OUT / 'phase2-selective-input.snapshot.json'
snapshot_path.write_bytes(input_data)

definitions = [
    {
        'path': ROOT / '.lake/packages/mathlib/Mathlib/Probability/Distributions/Gaussian/Multivariate.lean',
        'range': [168, 172],
        'sha256': '1fec35cf781da1009c37db80a96b05d70f2296ca7768e19bfc0b6314c9b43d49',
    },
    {
        'path': ROOT / '.lake/packages/mathlib/Mathlib/MeasureTheory/Measure/Map.lean',
        'range': [91, 93],
        'sha256': 'e9c245b054b5a897dba730cdefd02e89f94e9d7c54835bf149b6c952ad589a08',
    },
]
definition_records = []
definition_texts = []
for definition in definitions:
    meta = digest(definition['path'])
    assert meta['sha256'] == definition['sha256']
    lines = definition['path'].read_text().splitlines()
    first, last = definition['range']
    excerpt = '\n'.join(f'{number}: {lines[number-1]}' for number in range(first, last+1)) + '\n'
    definition_records.append({
        **meta,
        'content_read_lines_inclusive': [first, last],
        'full_file_access': 'bytes read for hash only; only authorized line range exposed as content',
        'excerpt_with_line_numbers_sha256': sha_string(excerpt),
    })
    definition_texts.append(str(definition['path']) + '\n' + excerpt)
definition_path = OUT / 'phase2-permitted-definition-excerpts.txt'
definition_path.write_text('\n'.join(definition_texts))

source_anchors = [
    'S4.E11', 'S4.EGx2', 'S4.SS3.p4.1',
    'S4.SS2.SSS0.Px3.p2.1',
    'S4.SS3.SSS0.Px2.p3.1', 'S4.SS3.SSS0.Px2.p3.2', 'A3.SS4',
]
loaded = runpy.run_path(str(OUT / 'extract_source.py'))
nodes, render = loaded['p'].nodes, loaded['render']
source_texts = []
for anchor in source_anchors:
    node = next(n for n in nodes if n.attrs.get('id') == anchor)
    content = render(node)
    content = re.sub(r'[^\S\n]+', ' ', content)
    content = re.sub(r'\n[ \t]+', '\n', content)
    content = re.sub(r'\n{3,}', '\n\n', content).strip()
    source_texts.append(content)
source_excerpt_path = OUT / 'phase2-source-anchors-reread.txt'
source_excerpt_path.write_text('\n\n'.join(source_texts) + '\n')

slots = [
    {
        'slot': 'objects',
        'public_vs_blind': 'equivalent',
        'public_vs_raw_source': 'explicit-elaboration',
        'finding': 'Same real matrix construction, midpoint grid, same-rotation conjugation, scalar reciprocal, first-kind matrix polynomial. Zero-based index shift is correct. Private R is Oz; private covariance uses matrix inverse of Lambda, not scalar inverse.',
        'source_anchors': ['S4.E11', 'S4.EGx2', 'S4.SS3.p4.1'],
    },
    {
        'slot': 'domains',
        'public_vs_blind': 'same',
        'public_vs_raw_source': 'explicit-elaboration',
        'finding': 'd>=2, kappa>=2 and full O(d) match hard family. Auxiliary includes all natural n, including zero; source proof specializes n=2q+1. No n<d is required for this algebraic identity. Private arbitrary real tau explicitly generalizes the source instance.',
        'generalization': ['all natural n', 'private all real tau'],
        'source_anchors': ['S4.SS1', 'S4.SS3.p3.1'],
    },
    {
        'slot': 'quantifiers',
        'public_vs_blind': 'same',
        'public_vs_raw_source': 'stronger-in-lean',
        'finding': 'Universally quantified fixed-input O and every natural n; no existential witnesses or random-law hypotheses. Stronger-in-lean refers only to explicit all-n extension of the source use, not a stronger Theorem 4.1. Private event equality is per fixed O/tau, not averaged.',
        'source_anchors': ['S4.SS1', 'S4.SS3', 'S4.SS2.SSS0.Px3.p2.1'],
    },
    {
        'slot': 'assumptions',
        'public_vs_blind': 'same',
        'public_vs_raw_source': 'same',
        'finding': 'For the selected deterministic hard-family identity, only source d/kappa bounds and orthogonality occur. Nonzero scalar, inverse identities, continuity and measurability must be internally derived; no moment/probability/cost certificate is an input. No project-owned Prop aliases in shown signatures.',
        'excess_public_premises_found_in_shown_type': [],
        'source_anchors': ['S4.SS1', 'S4.E11', 'A3.SS4'],
    },
    {
        'slot': 'conclusion',
        'public_vs_blind': 'equivalent',
        'public_vs_raw_source': 'explicit-elaboration',
        'finding': 'Exact matrix equality, not entrywise, approximate, trace-only or expected-value equality. Private strict event and pushforward event mass retain sign, 2*tau and x=0 exclusion; source target probability is not asserted.',
        'source_anchors': ['S4.EGx2', 'S4.SS3.p4.1', 'S4.SS2.SSS0.Px3.p2.1'],
    },
    {
        'slot': 'scopes',
        'public_vs_blind': 'same',
        'public_vs_raw_source': 'explicit-elaboration',
        'finding': 'Declared narrow source-extracted algebraic auxiliary. Private literal event transport is relevant but is not the target-law identification, target moments/probability, normalized-energy theorem, or query lower bound. Authored source.original_text is a contract paraphrase, not original quotation.',
        'full_module_and_reader': 'not-audited',
        'source_anchors': ['S4.EGx2', 'S4.SS3.p4.1', 'S4.SS2.SSS0.Px3.p2.1', 'S4.SS3'],
    },
    {
        'slot': 'constant_dependencies',
        'public_vs_blind': 'same',
        'public_vs_raw_source': 'same',
        'finding': 'Exact literal affine normalization and coefficients. No hidden epsilon/delta/q/C/d0 or probability/error constants. Private tau is explicit and correction remains 2*tau. Frequency specialization and asymptotic constants remain outside this helper.',
        'source_anchors': ['S4.E11', 'S4.EGx2'],
    },
]

comparison = {
    'schema': 'fresh-source-selective-seven-slot-comparison-v1',
    'status': 'PHASE2_FROZEN_PENDING_PHASE3',
    'authority': 'selective statement/definition/source-scope comparison only',
    'phase1_cognition': digest(phase1_cognition),
    'phase2_selective_input': digest(INPUT),
    'public_type_sha256': j['lean']['statement_sha256'],
    'blind_text_sha256': j['blind_reconstruction']['text_sha256'],
    'private_signature_sha256': sha_string(j['exact_private_consumer_statement']),
    'public_vs_blind_comparison': 'equivalent-after-elaboration',
    'source_comparison_boundary': 'compatible source-extracted algebraic auxiliary with explicit all-natural-n generalization; not a separately printed source theorem or full-source completion',
    'source_original_text_field_kind': 'authored auxiliary contract/paraphrase, not verbatim pinned source',
    'seven_slots': slots,
    'typed_scopes': [
        {'type': 'PUBLIC_AUXILIARY', 'scope': 'fixed-input matrix-polynomial/cosine equality'},
        {'type': 'PUBLIC_GENERALIZATION', 'scope': 'all natural n, including zero, beyond source frequency n=2q+1'},
        {'type': 'PRIVATE_GENERALIZATION', 'scope': 'all real tau for event transport; no negative-threshold target-sign geometry claimed'},
        {'type': 'PRIVATE_EVENT_TRANSPORT', 'scope': 'Borel strict event and literal mu.map R event mass equality'},
        {'type': 'RESIDUAL_GAUSSIAN_LAW', 'scope': 'identify mu.map R with pi_A / Gaussian covariance A inverse'},
        {'type': 'RESIDUAL_SOURCE_GEOMETRY', 'scope': 'normalized nonzero eigenvector energy fractions and sum-to-one statement'},
        {'type': 'RESIDUAL_SOURCE_ESTIMATES', 'scope': 'moments, variances, uniform asymptotic conditions, target probability, algorithm averaged probability, TV contradiction and query lower bound'},
        {'type': 'IMPLEMENTATION_NOT_AUDITED', 'scope': 'actual theorem calls, providers, proof/module/native cleanliness'},
        {'type': 'EXPOSITION_NOT_AUDITED', 'scope': 'candidate exposition, full correspondence and reader'},
    ],
    'private_consumer_relevance': {
        'signature_contains_public_lhs': True,
        'same_theta_A_B_definitions': True,
        'public_output_supplies_direct_intrinsic_to_cosine_bridge': True,
        'pointwise_specialization': 'S(Rz)=(-1)^n*sum_i cos(n*theta_i)*z_i^2-2*tau*norm(z)^2',
        'additional_obligations': ['orthogonal norm preservation', 'event Borelness', 'measurable R and pushforward event formula'],
        'actual_declaration_invocation_verified': False,
        'logical_uniqueness_or_necessity_of_this_particular_declaration_claimed': False,
        'finding': 'Concrete semantically relevant consumer signature; type alone does not establish compiler-backed call dependence.',
    },
    'definition_context_review': definition_records,
    'candidate_history_assertions_not_verified': ['compiled:true', 'decoder source-blind run provenance', 'private not Registry/source Anchor metadata'],
    'source_theorem_repair_proposed': False,
    'final_source_audit_five_field_proposal_issued': False,
    'native_or_implementation_acceptance': False,
    'full_module_or_reader_acceptance': False,
    'sourceV_or_PROVED_or_global_or_wholeGoal_acceptance': False,
}
comparison_path = OUT / 'phase2-seven-slot-comparison.json'
write_json(comparison_path, comparison)

manifest = {
    'schema': 'fresh-source-review-phase2-input-exposure-v1',
    'reviewer_task': '/root/detector_fresh_source',
    'phase1_freeze_unchanged': {
        'receipt': digest(phase1_receipt),
        'cognition': digest(phase1_cognition),
        'manifest': digest(phase1_manifest),
        'all_16_receipted_artifacts_hashes_and_readonly_modes_rechecked': True,
    },
    'new_candidate_content_input': digest(INPUT),
    'raw_source_input_reused': digest(SOURCE),
    'source_anchors_reread': source_anchors,
    'source_reading_method': 'full pinned HTML parsed by existing Phase1 own helper; only listed anchors deliberately emitted in Phase2; full Phase1 source excerpts retained',
    'permitted_partial_mathlib_content_inputs': definition_records,
    'permitted_definition_context_from_input': j['approved_definition_context'],
    'actual_events': [
        'Read only selective input JSON after verifying its full bytes and SHA256; all its fields were visible, including public type, approved context, source contract, blind reconstruction, exact private signature and history metadata.',
        'Read exactly Multivariate.lean lines168-172 and Map.lean lines91-93; full bytes used for hash only. No API search and no proof bodies. Line172 exposes only the next lemma name/header prefix because the parent whitelist includes it.',
        'Verified source contract, public statement and blind text embedded string hashes against the actual JSON strings. Computed private signature SHA256 independently.',
        'Re-read only the listed original-paper anchors, including complete A3.SS4, with full math alttext. No accidental wider content emission in Phase2.',
        'Authored the Phase2 comparison and this snapshot machinery. Rechecked the existing own Phase1 receipt/cognition/manifest and all receipted own artifacts for unchanged hashes/modes, without revising them.',
        'Copied the selective input verbatim, preserved only the whitelisted definition excerpts and scoped source re-read, and froze all new artifacts read-only.',
    ],
    'visible_but_unopened_references': {
        'full_canonical_reviewer_packet_sha256': '9525ebc96a14c49ea7694c6997103ac371ae5942b83356718ccaf05ce5aa751b',
        'decoder_packet_sha256': '351cd6156093dcec58f7e29d0a6a9288aa2d63f3fba82f6769be45b21d70a8bc',
        'decoder_run_sha256': 'aaef7a460bb871f17252a6fa5c547c3b995bca0c9c49ce5667263b8474e41b11',
        'treatment': 'reference strings visible in assignment/selective file only; none of these packets/process records opened',
    },
    'compiled_field_treatment': 'unverified historical assertion in candidate JSON; not this reviewer native/Lean evidence',
    'blind_reconstruction_treatment': 'text compared independently to exact type; claimed source-blind process itself not re-audited',
    'prior_knowledge': 'same general mathematical knowledge disclosed in Phase1; no claim of pretrained ignorance',
    'accidental_exposures_this_phase': [],
    'prohibited_content_reads_this_phase': [],
    'not_performed': [
        'no AutoSamplingTheory/Tests read', 'no Mathlib content outside the two authorized line ranges',
        'no public/private proof body or actual provider/module read',
        'no sourcegraph/topology/Root plan/lesson/old audit/delta/review/native file read',
        'no full canonical reviewer or decoder packet read',
        'no Git, Lean, native, V, STAB, API, network or browser operation',
        'no canonical/ledger/frontier mutation', 'no other-chat/PBPS/SPHMC/Bench/ATLAS access',
        'no subagent spawn',
    ],
    'output_scope': 'independent seven-slot comparison and typed source scopes; no final five-field source proposal, implementation/native/full module/reader/sourceV/global acceptance',
    'next_phase': 'PAUSE pending explicit Phase3 fullmodule/provider/private-consumer/correspondence/exposition whitelist',
}
manifest_path = OUT / 'phase2-input-exposure-manifest.json'
write_json(manifest_path, manifest)

artifacts = [
    OUT / 'freeze_phase2.py', OUT / 'phase2-selective-comparison.md',
    comparison_path, manifest_path, snapshot_path, definition_path, source_excerpt_path,
]
receipt = {
    'schema': 'fresh-source-review-phase2-freeze-v1',
    'frozen_at_utc': datetime.now(timezone.utc).isoformat(),
    'status': 'PHASE2_FROZEN_PENDING_PHASE3_WHITELIST',
    'phase1_receipt': digest(phase1_receipt),
    'selective_input': digest(INPUT),
    'artifacts': [digest(path) for path in artifacts],
    'freeze_policy': 'all listed artifacts and this receipt set to POSIX mode0444; Phase1 untouched; parent output directory remains writable for future separately named Phase3 artifacts',
    'acceptance_authority': 'selective semantic comparison only; no implementation/native/full-module/reader/sourceV/PROVED/global/wholeGoal acceptance',
}
receipt_path = OUT / 'phase2-freeze-receipt.json'
write_json(receipt_path, receipt)
for path in artifacts + [receipt_path]:
    path.chmod(0o444)
assert all(stat.S_IMODE(path.stat().st_mode) == 0o444 for path in artifacts + [receipt_path])
print(json.dumps({
    'receipt': digest(receipt_path),
    'comparison': digest(OUT / 'phase2-selective-comparison.md'),
    'seven_slots': digest(comparison_path),
    'input_exposure_manifest': digest(manifest_path),
    'readonly_new_files_checked': len(artifacts) + 1,
    'phase1_artifacts_unchanged': True,
}, ensure_ascii=False, indent=2))
