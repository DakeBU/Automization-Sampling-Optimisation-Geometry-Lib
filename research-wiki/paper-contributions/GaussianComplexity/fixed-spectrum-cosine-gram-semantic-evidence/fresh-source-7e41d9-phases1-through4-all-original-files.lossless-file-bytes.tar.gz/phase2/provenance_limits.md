# Phase 2 provenance and exposure limits

The phase-1 cognition remained frozen. The phase-2 role prompt supplied two
exact files, permitted selected public/private types, anonymous reconstruction,
minimal literal definitions and characterizations. Both raw byte counts/digests
were verified before their full contents were displayed. No output truncation
was observed. A precise request for stdOrthonormalBasis and EuclideanSpace
coordinate normalization was sent to root. Root then explicitly authorized the
third input minimal-requested-orthonormal-normalization-context.json, 3571 bytes,
SHA256 9af7f1de95198297be6a385134419d1ed00fb780809c79db5662822ea0ad2933.
Only that file was subsequently read; no linked upstream path or exporter/log
was read. Its full contents were displayed without observed truncation.

The permitted stdOrthonormalBasis literal definition contains its own `by`
definition body; that body was authorized and viewed. No standalone theorem
proof or target implementation was provided or read. Supplied characterization
statements have no proof bodies. The main input exposes decoder identification,
hashes, source_text_visible=false, compiled=true and publication/whole-file
digests. These are supplied assertions, not independently verified process,
compiler or blindness facts. I read only the permitted anonymous reconstruction
and metadata, no other role's independent verdict or workspace.

The draft judgment was written before the requested normalization packet was
authorized and records the then-open question. The final judgment retains that
draft and resolves the question explicitly from the authorized third input.
No phase-1 claim was rewritten. General pretrained mathematical knowledge
cannot be excluded, and task labels/scope plus authorized decoder/type content
are now known; no pristine or continuing source-blind claim is made.

Actual subprocess argv, cwd, return codes and separate raw stdout/stderr are
captured by capture_phase2.py and hashed in actual_commands.jsonl. All observed
subprocess exits so far were 0, with genuinely captured empty stderr. No command
failure, display truncation or other accidental exposure was observed in
phase 2. Apply-patch calls returned `{}` and created the retained scripts and
draft/provenance files. No repository-wide filename/text search, agent inventory,
source graph, lesson/source-map, Lean implementation, SourceV/ledger API,
compiler run, external web source, or other workspace was accessed.

The only rechecks outside phase2 are explicit paths enumerated by my own frozen
phase1 manifest, used to verify preservation of all 108 original payloads. The
phase1 directory, cognition, manifest, receipt and payload bytes/modes remain
unchanged; literal_and_phase1_verification.json gives actual observed hashes.

Phase 2 freezes its own payloads in place. manifest.json excludes itself and
freeze_receipt.json; the receipt binds manifest and final judgment. The actual
freeze process stdout/stderr/exit record is written afterward under the role
root, outside the frozen phase2 directory, and binds the receipt. These
directions have no hash cycle. All phase2 files become 0444 and its directories
0555. Future implementation input must be separately staged and authorized.
