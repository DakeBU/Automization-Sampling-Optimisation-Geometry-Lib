from hashlib import sha256
from html import unescape
import json
from pathlib import Path
import re

ROOT = Path('/Users/zhouhuanjian/ASTIS-GC')
BASE = ROOT / '.astis/semantic-neutral-20261114/mgf_fresh_source_5b7e'
OUT = BASE / 'phase12_final_native_visual'
NATIVE = ROOT / '.astis/semantic-neutral-20261114/weighted_mgf_native_8c2d/runtime'
sha = lambda p: sha256(p.read_bytes()).hexdigest()
actual_path = OUT / 'originals/candidate/actual-checks.json'
receipt_path = OUT / 'originals/process/process-receipt.json'
actual = json.loads(actual_path.read_text())
receipt = json.loads(receipt_path.read_text())
contract = json.loads((BASE / 'phase11_v4_measurement_preflight/attempt2/originals/independent-browser-contract.v4.json').read_text())
checks = {}
checks['actual_report_and_process_receipt_exact_announced_hashes'] = (
    sha(actual_path) == 'dd84dcee1105f455b1dd273f21187e8fe5c2539b515f8a1580b8888c614dd492' and
    sha(receipt_path) == '2cbc3228118bc7aabbd3c9e86c0ed87284171dfd490327b0b7198fed15df184b')
checks['actual343_checks_all_true_and86_PNGs_not_reconstructed'] = (
    len(actual['checks']) == 343 and all(c['pass'] for c in actual['checks']) and
    len(actual['screenshots']) == 86 and actual['status'] == 'PASS')
checks['exit0_exception_null_real67_second_process'] = (
    receipt['exit_code'] == 0 and receipt['exception'] is None and
    67 < receipt['elapsed_seconds'] < 68)
checks['receipt_report_script_contract_and_browser_identity_agree'] = (
    receipt['actual_checks']['sha256'] == sha(actual_path) and
    receipt['actual_checks']['screenshot_count'] == 86 and
    actual['wrapper_sha256'] == receipt['wrapper_sha256'] == contract['wrapper_sha256'] ==
        '89170589853cf1eed161d98e5a3438614688e68902c91ab876e68baa06af1c03' and
    actual['contract_sha256'] == receipt['contract_sha256'] ==
        '123942888e8864a4a4e2acce653fd431c8f6e007c4af89d5aa6fb7bdcb0000d4' and
    actual['reader_identity'] == contract['reader_identity'] and
    actual['mathematical_candidate'] == contract['mathematical_candidate'] and
    set(actual['actual_chrome']) == set(receipt['actual_chrome']) | {'launch'} and
    all(actual['actual_chrome'][key] == value for key,value in receipt['actual_chrome'].items()) and
    actual['actual_chrome']['launch'] == {'headless':True,'executable_path':receipt['actual_chrome']['executable_path']})
checks['all86_actual_PNG_hashes_match_original_report'] = all(
    sha(OUT / 'originals/candidate' / Path(row['path']).name) == row['sha256']
    for row in actual['screenshots'])
checks['real_stdout_stderr_hashes_bytes_match_actual_receipt'] = all(
    sha(OUT / 'originals/process' / Path(receipt[key]['path']).name) == receipt[key]['sha256'] and
    (OUT / 'originals/process' / Path(receipt[key]['path']).name).stat().st_size == receipt[key]['bytes']
    for key in ['stdout','stderr'])
checks['all373_frozen_owned_inputs_still_hash_exact_after_actual_browser'] = all(
    sha(NATIVE / row['path']) == row['sha256'] for row in contract['owned_inputs'])
checks['no_actual_JS_errors_or_external_requests'] = (
    actual['javascript_errors'] == [] and actual['blocked_external_requests'] == [])

expected_files = {
    'P': BASE / 'phase2/immutable-tree/AutoSamplingTheory/TechnicalLemmas/Probability/MatrixBernsteinMgf.lean',
    'T': BASE / 'phase2/immutable-tree/Tests/GaussianComplexityBernsteinWeightedMgf.lean',
}
downloads = list((OUT / 'originals/candidate').glob('*.lean'))
def kind(path):
    if '-step-' in path.name:
        number = int(path.name.split('-step-')[1].split('-')[0])
        return 'P' if number <= 3 else 'T'
    return path.stem[-1]
checks['all16_actual_download_files_equal_exact_frozen_P_or_T_module'] = (
    len(downloads) == 16 and all(p.read_bytes() == expected_files[kind(p)].read_bytes() for p in downloads))

glyph_rows = [row for row in actual['checks'] if 'last-source-glyph-actually-visible-below-header' in row['name']]
checks['all4_actual_selected_d_s_diagnostics_correct_and_real_width_positive'] = (
    len(glyph_rows) == 4 and all(
        row['detail']['selectedGlyph'] == ('d' if '-P-' in row['name'] else 's') and
        row['detail']['selectedGlyphCodePoints'] == ([100] if '-P-' in row['name'] else [115]) and
        (row['detail']['selectedGlyphStartUTF16'], row['detail']['selectedGlyphEndUTF16']) ==
          ((120,121) if '-P-' in row['name'] else (128,129)) and
        row['detail']['oldLastCodeUnit'] == '\n' and row['detail']['trailingWhitespaceCodeUnitsSkipped'] == 1 and
        row['detail']['lastGlyphWidth'] > 0 and row['detail']['lastGlyphHeight'] > 0 and
        row['detail']['glyphVerticallyVisible'] and row['detail']['lineVerticallyVisible'] and
        row['detail']['scroll'] >= row['detail']['max'] - 1 and
        row['detail']['lastGlyphLeft'] >= row['detail']['left'] - 1 and
        row['detail']['lastGlyphRight'] <= row['detail']['right'] + 1
        for row in glyph_rows))

preview = ROOT / '.astis/huanjian-gc-weighted-mgf-20261114/reader-preview-v2'
lesson = ROOT / 'website/content/declaration_lessons/huanjian-matrix-bernstein-mgf.json'
publication = ROOT / 'website/content/publications/huanjian-matrix-bernstein-mgf.json'
checks['current_installed_lesson_and_publication_still_accepted_v2'] = (
    sha(lesson) == 'd88b96ad5397be27a9f234a6b3ac993a236267591dd4c922c7ba7aa1915f28c0' and
    sha(publication) == '51580fc5033dcfb049ab5e1bc8754f42666f27bdedd65eda60029f40b2d96e1c')
unit = json.loads(lesson.read_text())['units'][0]
page = (preview / 'fixtures/candidate/proofs/huanjian-matrix-bernstein-mgf.html').read_text()
links = [unescape(s) for s in re.findall(r'href="([^"]+)"', page)]
web_sources = [row['url'] for row in unit['sources'] if 'url' in row]
checks['all9_authored_direct_unit_web_source_links_render_in_actual_fixture'] = (
    len(web_sources) == 9 and all(url in links for url in web_sources))

results = {
    'schema':'independent-actual-v4-material-integrity-review-v1',
    'reviewer':'mgf_fresh_source_5b7e',
    'checks':checks,'all_checks_passed':all(checks.values()),
    'actual_glyph_geometry':glyph_rows,
    'scope':'Read-only material/hash and recorded geometry verification, not new native checks and not replacement flags.',
    'actual_raw_human_visual_field_left_unmodified':actual['human_visual_review'],
    'step_own_source_metadata_runtime_claim':'source_attribution exact-span metadata remains authored evidence; current generic renderer does not consume it per-step. Direct unit source links and canonical-parent drilldown are the bounded rendered source navigation; no per-step metadata/runtime claim.',
    'normal_proof_VERIFIED_called':False,'reviewer_Chrome_or_build_calls':0,
}
(OUT / 'independent-actual-v4-material-checks.attempt2.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'all_checks_passed':results['all_checks_passed'],'check_count':len(checks),
                  'failed':[k for k,v in checks.items() if not v]},indent=2))
assert results['all_checks_passed']
