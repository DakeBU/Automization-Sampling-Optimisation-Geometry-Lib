from pathlib import Path
from html.parser import HTMLParser
from bs4 import BeautifulSoup
import hashlib
import json
import re

ROOT = Path('/Users/zhouhuanjian/ASTIS-GC')
SOURCE = ROOT / '.astis/huanjian-resume-20261103/2610.20492v1.html'
PRIVATE = ROOT / '.astis/huanjian-gc-fixed-spectrum-first-order-20261108/source-graph/phase1'
PUBLIC = ROOT / 'research-wiki/paper-contributions/GaussianComplexity/fixed-spectrum-first-order-semantic-evidence/source-only-review/phase1'
EXPECTED = '6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915'
raw = SOURCE.read_bytes()
assert len(raw) == 951991 and hashlib.sha256(raw).hexdigest() == EXPECTED
html = raw.decode('utf-8')
soup = BeautifulSoup(html, 'html.parser')

def sha(b):
    if isinstance(b, str):
        b = b.encode('utf-8')
    return hashlib.sha256(b).hexdigest()

class Spans(HTMLParser):
    def __init__(self, text):
        super().__init__(convert_charrefs=False)
        self.text, self.stack, self.spans = text, [], {}
        self.lines = [0]
        for m in re.finditer('\n', text):
            self.lines.append(m.end())
        self.feed(text)
    def pos(self):
        line, col = self.getpos()
        return self.lines[line-1] + col
    def handle_starttag(self, tag, attrs):
        start = self.pos()
        attrs = dict(attrs)
        item = (tag, attrs.get('id'), start)
        if tag in {'area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr'}:
            if item[1]:
                self.spans[item[1]] = (start, start + len(self.get_starttag_text()))
        else:
            self.stack.append(item)
    def handle_startendtag(self, tag, attrs):
        start = self.pos()
        attrs = dict(attrs)
        if attrs.get('id'):
            self.spans[attrs['id']] = (start, start + len(self.get_starttag_text()))
    def handle_endtag(self, tag):
        end = self.text.index('>', self.pos()) + 1
        for i in range(len(self.stack)-1, -1, -1):
            if self.stack[i][0] == tag:
                for _, id_, start in self.stack[i:]:
                    if id_:
                        self.spans[id_] = (start, end)
                self.stack = self.stack[:i]
                return

spans = Spans(html).spans

def raw_info(id_):
    start, end = spans[id_]
    b = html[start:end].encode('utf-8')
    return {
        'source_element_id': id_,
        'source_byte_start': len(html[:start].encode('utf-8')),
        'source_byte_end_exclusive': len(html[:end].encode('utf-8')),
        'source_line_start': html.count('\n', 0, start)+1,
        'source_line_end': html.count('\n', 0, end)+1,
        'raw_bytes': len(b), 'raw_sha256': sha(b),
    }

def rendered(el, tokens=False):
    c = BeautifulSoup(str(el), 'html.parser')
    for m in c.find_all('math'):
        m.replace_with('⟦'+m['id']+'⟧' if tokens else ' $'+m.get('alttext', m.get_text(' ', strip=True))+'$ ')
    return ' '.join(c.get_text(' ', strip=True).split())

def restore(text):
    return re.sub(r'⟦([^⟧]+)⟧', lambda m: '$'+soup.find(id=m[1]).get('alttext', '')+'$', text)

scopes = [
    ('S2', 'primary', 'Complete standing conventions, precision/FO definitions, random-algorithm model, TV and fixed-cap complexity.'),
    ('S4.p1', 'parameter-context', 'Complete Section 4 introductory paragraph; external attribution and scope.'),
    ('S4.Thmtheorem1', 'parameter-context', 'Complete Theorem 4.1 statement; proof in 4.3 is outside this phase.'),
    ('S4.p2', 'parameter-context', 'Complete comparison/known-spectrum/accuracy boundary paragraph.'),
    ('S4.SS1', 'primary', 'Complete literal hard family Eq.11, public spectrum, and Remark 4.2.'),
    ('S4.SS2', 'supporting-context', 'Complete statements and explanatory paragraphs of 4.2, necessary to disambiguate Remark 4.2 and 4.4 use sites; proofs C.1-C.3 are not read or admitted.'),
    ('A3.SS4', 'primary', 'All of C.4, including unnumbered assertions and normalizer display.'),
    ('S4.SS4', 'boundary-context', 'Complete 4.4, including both limitations, Lemma 4.7 statement and Remark 4.8.'),
]

for path in (PRIVATE, PUBLIC):
    assert not path.exists(), f'Never overwrite frozen evidence: {path}'
    (path/'raw-blocks').mkdir(parents=True)

files = {}
inputs = []
for id_, role, reason in scopes:
    start,end = spans[id_]
    content = html[start:end].encode('utf-8')
    filename = 'raw-blocks/'+id_+'.html'
    files[filename] = content
    inputs.append({**raw_info(id_), 'role':role, 'reason':reason,
                   'extracted_file':filename, 'rendered_text':rendered(soup.find(id=id_))})

# Bibliography entry is source-attribution context, never a certificate for the external result.
start,end = spans['bib.bib3']
files['raw-blocks/bib.bib3.html'] = html[start:end].encode('utf-8')
inputs.append({**raw_info('bib.bib3'),'role':'citation-context','reason':'Pinned source identity of [22] only; external preprint itself not opened.',
               'extracted_file':'raw-blocks/bib.bib3.html','rendered_text':rendered(soup.find(id='bib.bib3'))})

source_inputs = {
    'schema':'gc-source-only-phase1-inputs-v1','source_revision':'arXiv:2610.20492v1',
    'source_title':'On Complexity of Gaussian Sampling','source_path':str(SOURCE.relative_to(ROOT)),
    'source_bytes':len(raw),'source_sha256':EXPECTED,
    'whole_source_read':False,'blocks':inputs,
    'forbidden_inputs_not_read':['candidate endpoint or sealed target','implementation Lean','proof API indexes','other actors private artifacts','existing target seals','.atlas-upstream'],
    'coverage_boundary':'Exhaustive within the eight disjoint blocks above. Bibliography [22] is attribution-only. Not exhaustive for all Section 4 proofs or the paper.',
}

nodes=[]
coverage=[]
math_covered=set()
sentence_lookup={}
display_lookup={}
node_ids=set()

def add_node(id_, kind, formula, source_refs, provenance='EXACT_SOURCE', **extra):
    assert id_ not in node_ids, id_
    node_ids.add(id_)
    n={'id':id_,'kind':kind,'statement':formula,'source_refs':source_refs,
       'provenance':provenance,'review_status':'proposed-pending-independent-topology-challenge',**extra}
    nodes.append(n)
    return id_

def S(id_, n=1):
    return 'SRC:'+id_+':s'+str(n).zfill(2)
def D(id_):
    return 'SRC:'+id_+':display'

def classify(id_, text):
    if id_ in {'S2.p1.1','S2.p2.1'}:
        return 'standing-definition-or-convention'
    if id_.startswith('S2.'):
        if any(x in id_ for x in ['Px2','Px4']): return 'oracle-model-or-complexity-definition'
        return 'source-definition-or-assertion'
    if 'Thmtheorem' in id_: return 'theorem-or-remark-assertion'
    if id_.startswith('A3.SS4'): return 'substantive-proof-sentence'
    if id_.startswith('S4.SS4'): return 'proof-limitation-or-explanatory-sentence'
    if id_.startswith('S4.SS1'): return 'hard-family-definition-or-explanation'
    return 'substantive-explanatory-sentence'

for scope_id,_,_ in scopes:
    scope=soup.find(id=scope_id)
    for p in scope.find_all('p'):
        pid=p['id']
        tok=rendered(p,True)
        sentences=re.split(r'(?<=[.!?])\s+(?=[A-Z∎])',tok)
        assert ' '.join(sentences)==tok
        for i, sentence in enumerate(sentences,1):
            uid='UNIT:'+pid+':s'+str(i).zfill(2)
            mathids=re.findall(r'⟦([^⟧]+)⟧',sentence)
            if sentence=='∎':
                coverage.append({'unit_id':uid,'unit_kind':'proof-end-marker','source':raw_info(pid),
                                 'text':sentence,'disposition':'EXCLUDED','reason':'Typographic end-of-proof marker; no mathematical assertion.'})
                continue
            nid=add_node(S(pid,i),classify(pid,restore(sentence)),restore(sentence),[{'element_id':pid,'sentence':i}],
                         source_math_ids=mathids,
                         logical_role='source-statement-or-standing-model; proof-role edges below distinguish hypothesis from ingredient')
            sentence_lookup[(pid,i)]=nid
            coverage.append({'unit_id':uid,'unit_kind':'sentence-or-display-continuation','source':raw_info(pid),
                             'text_with_math_ids':sentence,'text':restore(sentence),'normalized_text_sha256':sha(restore(sentence)),
                             'disposition':'NODE','node_id':nid,'source_math_ids':mathids})
            for mid in mathids:
                assert mid not in math_covered,mid
                math_covered.add(mid)
                m=soup.find(id=mid)
                coverage.append({'unit_id':'FORMULA:'+mid,'unit_kind':'inline-formula','source':raw_info(mid),
                                 'latex':m.get('alttext'),'disposition':'NODE','node_id':nid,
                                 'formula_role':'Exact formula occurrence within this source sentence; not an independent proof premise.'})
    for table in scope.find_all('table'):
        if table.find_parent('table'): continue
        tid=table['id']
        mids=[m['id'] for m in table.find_all('math')]
        nid=add_node(D(tid),'source-display',rendered(table),[{'element_id':tid}],source_math_ids=mids)
        display_lookup[tid]=nid
        coverage.append({'unit_id':'UNIT:'+tid,'unit_kind':'display','source':raw_info(tid),'text':rendered(table),
                         'normalized_text_sha256':sha(rendered(table)),'disposition':'NODE','node_id':nid,'source_math_ids':mids})
        for mid in mids:
            assert mid not in math_covered,mid
            math_covered.add(mid)
            coverage.append({'unit_id':'FORMULA:'+mid,'unit_kind':'display-formula','source':raw_info(mid),
                             'latex':soup.find(id=mid).get('alttext'),'disposition':'NODE','node_id':nid})
    for h in scope.find_all(['h2','h3','h4','h5','h6']):
        hid=h.get('id') or h.parent.get('id')
        coverage.append({'unit_id':'HEADING:'+scope_id+':'+hid,'unit_kind':'structural-heading',
                         'source_locator':{'element_id':hid,'selector':'heading descendant'},'text':rendered(h),
                         'disposition':'EXCLUDED','reason':'Structural title/statement label only; all substantive statement bodies are separately covered.'})
        for m in h.find_all('math'):
            mid=m['id']
            assert mid not in math_covered,mid
            math_covered.add(mid)
            coverage.append({'unit_id':'FORMULA:'+mid,'unit_kind':'heading-formula','source':raw_info(mid),
                             'latex':m.get('alttext'),'disposition':'EXCLUDED',
                             'reason':'Formula in structural title only; the substantive parameter/claim occurs in separately covered body.'})
    for ci,cite in enumerate(scope.find_all('cite'),1):
        pid=cite.find_parent('p')['id']
        nid=next(x['node_id'] for x in coverage if x.get('source',{}).get('source_element_id')==pid and x.get('node_id') and rendered(cite) in x.get('text',''))
        coverage.append({'unit_id':f'CITATION:{scope_id}:{ci}','unit_kind':'external-citation-use',
                         'source_locator':{'paragraph_id':pid,'citation_ordinal_in_scope':ci},'text':rendered(cite),
                         'source_targets':[a.get('href') for a in cite.find_all('a')],
                         'disposition':'NODE','node_id':nid,'reason':'Source-attributed external use; referenced preprint not inspected or admitted.'})

add_node('EXT:openai22','external-citation-identity',rendered(soup.find(id='bib.bib3')),[{'element_id':'bib.bib3'}],
         truth_boundary='Identity and paper attribution only. No external source result or Lean proof admitted.')
coverage.append({'unit_id':'BIB:bib.bib3','unit_kind':'bibliography-entry','source':raw_info('bib.bib3'),
                 'text':rendered(soup.find(id='bib.bib3')),'disposition':'NODE','node_id':'EXT:openai22'})

inferred = [
 ('INF:index-range','typing-interpretation','In Eq.11, i ranges over {1,...,d}; matrices and vectors are real and d-dimensional.','S4.E11','TYPING_IMPLICIT','Index range is recovered from the d-entry diagonal and surrounding Euclidean conventions, not an additional analytic hypothesis.'),
 ('INF:theta-bound','omitted-bookkeeping','d >= 2 and 1 <= i <= d imply 0 < ((i-1/2) pi)/d < pi.','A3.SS4.p1.1','INFERRED_EXPANSION','C.4 states the angle bound but omits its arithmetic proof.'),
 ('INF:cos-and-eigenvalues','omitted-bookkeeping','0 < theta_i < pi implies -1 < cos(theta_i) < 1; kappa >= 2 makes (kappa-1)/2 positive, yielding 1 < lambda_i < kappa.','A3.SS4.p1.1','INFERRED_EXPANSION','Expanded proof of the exact first sentence of C.4; no strict-eigenvalue assumption is added.'),
 ('INF:symmetry','definition-meaning-obligation','Lambda is real diagonal, O^T O = I, and A=O Lambda O^T imply A=A^T.','S4.SS1.p1.2','INFERRED_EXPANSION','Required to instantiate the precision-class definition; not separately stated in C.4.'),
 ('INF:conjugation-order','omitted-bookkeeping','For all x, x^T A x = sum_i lambda_i (O^T x)_i^2 and ||O^T x||^2=||x||^2; hence I <= A <= kappa I.','A3.SS4.p1.1','INFERRED_EXPANSION','C.4 explicitly gives the order result, without this quadratic-form derivation.'),
 ('INF:gradient','definition-meaning-obligation','For the symmetric hard-family A, grad V_A(x)=A x for every x.','A3.SS4.p2.1','INFERRED_EXPANSION','This gradient formula is NOT literal wording of C.4. It is derived from the quadratic and symmetry; Eq.1 states it for precision-class inputs.'),
 ('INF:quadratic-differentiation','omitted-analytic-bridge','A real finite-dimensional quadratic with symmetric A is C-infinity, has gradient A x and Hessian A.','A3.SS4.p2.1','INFERRED_EXPANSION','C.4 explicitly asserts C-infinity and Hessian A; no differentiation proof is supplied.'),
 ('INF:sc-smooth-adapter','definition-meaning-obligation','Hessian bounds I <= Hess V_A <= kappa I imply global 1-strong convexity and kappa-Lipschitz gradient (the source smoothness convention).','A3.SS4.p2.1','INFERRED_EXPANSION','Must discharge this bridge, not bind strong convexity/smoothness as extra public hypotheses.'),
 ('INF:positive-gap','omitted-bookkeeping','V_A(0)=0; for x != 0, the lower quadratic bound gives V_A(x)>=||x||^2/2>0, so zero is the unique minimizer.','A3.SS4.p2.1','INFERRED_EXPANSION','Existence, minimality and uniqueness are conclusions, not input witnesses.'),
 ('INF:det-conjugation','omitted-bookkeeping','det(O Lambda O^T)=det Lambda=product_i lambda_i>0 for orthogonal O.','A3.Ex160','INFERRED_EXPANSION','C.4 displays equality of determinant-based normalizers; determinant algebra and positivity are omitted.'),
 ('GAP:normalizer-meaning','SOURCE_GAP','Interpret Z_A as the Lebesgue integral of exp(-V_A(x)) over R^d, with this exact real Gaussian convention.','A3.Ex160','INFERRED_CONVENTION','The scoped C.4 text names Z_A and invokes Gaussian integration; it does not literally write this integral definition. No claim about definitions outside the scoped raw blocks.'),
 ('GAP:gaussian-integration','SOURCE_GAP','For positive-definite real symmetric A, integral_{R^d} exp(-x^T A x/2) dx = (2 pi)^(d/2) (det A)^(-1/2), finite and positive.','A3.SS4.p3.1','INFERRED_EXPANSION','Gaussian integration is invoked by name without a theorem citation or proof in C.4; this is an omitted analytical bridge, not a source-invalid verdict.'),
 ('INF:normalizer-independence','omitted-bookkeeping','The determinant expression depends only on the fixed Lambda, so it has the same value for all O; public Lambda determines it.','A3.SS4.p3.2','INFERRED_EXPANSION','Computational/public-information meaning; not an algorithmic runtime or bit-complexity claim.'),
 ('INF:affine-forward-matvec','derived-reply-transport','At the same x, A_kappa x=(kappa-1) A_2 x-(kappa-2)x.','S4.Thmtheorem2.p1.1','INFERRED_EXPANSION','Exact matrix identity is source literal; expanded reply formula is inferred algebra.'),
 ('INF:affine-inverse-matvec','derived-reply-transport','At the same x, A_2 x=(A_kappa x+(kappa-2)x)/(kappa-1), using kappa>=2 so kappa-1!=0.','S4.Thmtheorem2.p1.1','INFERRED_EXPANSION','Reverse simulation requires scalar nonzero discharge; no new oracle call is hidden.'),
 ('INF:affine-forward-value','derived-reply-transport','f_{A_kappa}(x)=(kappa-1) f_{A_2}(x)-(kappa-2)||x||^2/2.','S4.Thmtheorem2.p1.1','INFERRED_EXPANSION','Not literal in Remark 4.2; follows from the quadratic definition and same-matrix affine identity.'),
 ('INF:affine-inverse-value','derived-reply-transport','f_{A_2}(x)=(f_{A_kappa}(x)+(kappa-2)||x||^2/2)/(kappa-1).','S4.Thmtheorem2.p1.1','INFERRED_EXPANSION','Not literal in Remark 4.2; exact scalar algebra, kappa-1 nonzero.'),
 ('INF:fo-hard-family','derived-semantic-integration','For every hard-family orthogonal O and every x, FO_A(x)=(x^T A x/2,A x); admissibility allows the S2 Eq.1 interface.','S2.E1','INFERRED_EXPANSION','C.4 itself does not write an FO formula. This inference combines its admissibility with the literal S2 definition.'),
 ('INF:fo-affine-transport','derived-semantic-integration','The exact value-gradient reply at x for either same-rotation A_2 or A_kappa determines the other reply at x by the component formulas, with one original reply.','S4.Thmtheorem2.p1.1','INFERRED_EXPANSION','A mathematical consequence of S2 plus Remark4.2, not a verbatim Remark or C.4 statement. No standalone claimed endpoint.'),
 ('EXT:section4.3-proof','EXTERNAL_TO_SLICE','The complete proof of Theorem4.1 in S4.SS3 is outside this phase1 read/coverage.','S4.Thmtheorem1','SOURCE_POINTER_ONLY','Theorem parameters are audited, not the global lower bound proof closure.'),
 ('EXT:C1-proof','EXTERNAL_TO_SLICE','Proof of Lemma4.3 is deferred to C.1.','S4.SS2.SSS0.Px1.p3.1','SOURCE_POINTER_ONLY','No C.1 proof admission.'),
 ('EXT:C2-proof','EXTERNAL_TO_SLICE','Proof of Lemma4.4 is deferred to C.2.','S4.SS2.SSS0.Px2.p2.1','SOURCE_POINTER_ONLY','No C.2 proof admission.'),
 ('EXT:C3-proof','EXTERNAL_TO_SLICE','Proof of Lemma4.5 is deferred to C.3.','S4.SS2.SSS0.Px3.p2.1','SOURCE_POINTER_ONLY','No C.3 proof admission.'),
 ('EXT:FactC6-calculation','EXTERNAL_TO_SLICE','Section4.4 refers to a Bernstein calculation in the proof of Fact C.6.','S4.SS4.SSS0.Px2.p1.1','SOURCE_POINTER_ONLY','This calculation was not opened. The quoted limitation is exact source; its derivation remains unreviewed here.'),
 ('EXT:Lemma4.7-proof','EXTERNAL_TO_SLICE','The dimension formula for the block Krylov space is stated in Lemma4.7; its proof is outside this slice.','S4.Ex28','SOURCE_POINTER_ONLY','Do not infer necessity or a theorem-level impossibility from the stated limitation.'),
]
for id_,kind,text,ref,prov,boundary in inferred:
    add_node(id_,kind,text,[{'element_id':ref}],prov,truth_boundary=boundary,
             logical_role='proof-ingredient-to-discharge; never an extra source-facing binder' if id_.startswith(('INF:','GAP:')) else 'unadmitted-outside-slice-input')

edges=[]
def edge(parents,child,use_site,why,provenance='EXACT_SOURCE',semantics='AND',discharge=None,**extra):
    if isinstance(parents,str): parents=[parents]
    assert child in node_ids,child
    for x in parents: assert x in node_ids,x
    edges.append({'id':f'E{len(edges)+1:03}','parents':parents,'consumer':child,'consumer_use_site':use_site,
                  'semantics':semantics,'reason':why,'provenance':provenance,
                  'conditional_premises':discharge or [],'status':'proposed-source-edge; no Lean implication asserted',**extra})

# Standing definitions and exact response equivalence.
edge(S('S2.SS0.SSS0.Px1.p1.1',3),D('S2.Ex1'),'S2.Ex1','d>=1, kappa>=1 scope the precision-class definition.',semantics='DEFINITION_CONTEXT')
edge([D('S2.Ex1'),S('S2.SS0.SSS0.Px1.p1.2',1)],D('S2.E1'),'S2.E1','Input is a precision-class symmetric matrix; literal quadratic and gradient reply formula.',semantics='DEFINITION_CONTEXT')
edge(D('S2.E1'),S('S2.SS0.SSS0.Px1.p2.1',2),'S2.SS0.SSS0.Px1.p2.1:s02','Project Ax from a first-order reply, or reconstruct value from a matrix-vector reply.')
edge(S('S2.SS0.SSS0.Px1.p2.1',2),S('S2.SS0.SSS0.Px1.p2.1',1),'S2.SS0.SSS0.Px1.p2.1:s01','Both exact simulations establish equivalence; they are jointly needed for equivalence.')
edge([S('S2.SS0.SSS0.Px1.p2.1',1),S('S2.SS0.SSS0.Px2.p1.1',1),S('S2.SS0.SSS0.Px2.p1.1',3)],S('S2.SS0.SSS0.Px1.p2.1',3),'S2.SS0.SSS0.Px1.p2.1:s03','Exact deterministic Borel postprocessing simulates one reply per query; fixed caps are preserved.','INFERRED_EXPANSION')
edge([S('S2.SS0.SSS0.Px3.p1.1'),S('S2.SS0.SSS0.Px3.p1.2')],D('S2.Ex2'),'S2.Ex2','TV definition and density convention.',semantics='DEFINITION_CONTEXT')
edge(D('S2.Ex2'),S('S2.SS0.SSS0.Px3.p1.2',2),'S2.SS0.SSS0.Px3.p1.2:s02','[0,1]-test expectation bound is a source-asserted consequence; proof omitted.',discharge=[{'premise':'h measurable and 0<=h<=1','source':'same sentence','status':'explicit source condition'}])
edge([D('S2.Ex1'),S('S2.SS0.SSS0.Px2.p1.1',1),S('S2.SS0.SSS0.Px2.p1.1',2),S('S2.SS0.SSS0.Px2.p1.1',3),D('S2.Ex2'),S('S2.SS0.SSS0.Px4.p1.1',1),S('S2.SS0.SSS0.Px4.p1.1',2)],D('S2.E2'),'S2.E2','Uniform TV accuracy and existence of a randomized algorithm with deterministic runwise cap define Q_G.',semantics='DEFINITION_CONTEXT')
edge(D('S2.E2'),S('S2.SS0.SSS0.Px4.p1.2',1),'S2.SS0.SSS0.Px4.p1.2:s01','The output law averages the seed; supremum over inputs remains outside it.',semantics='SEMANTIC_EXPLANATION')
edge(S('S2.SS0.SSS0.Px2.p1.1',3),S('S2.SS0.SSS0.Px4.p1.2',2),'S2.SS0.SSS0.Px4.p1.2:s02','Explicitly excludes replacing runwise deterministic caps by expected-query bounds.',semantics='MODEL_BOUNDARY')

# Main-theorem boundary: do not claim a full proof through context stubs.
edge([D('S2.E2'),S('S4.Thmtheorem1.p1.1')],D('S4.Ex9'),'S4.Ex9','The lower bound has the quantifier order delta -> d0(delta) -> d,kappa,epsilon.',semantics='STATEMENT_CONTEXT')
edge('EXT:section4.3-proof',D('S4.Ex9'),'S4.Thmtheorem1','Full proof lies in unread S4.SS3; this is a boundary pointer, not a discharged proof.',semantics='OUT_OF_SLICE_PROOF_POINTER')
edge('EXT:openai22',S('S4.p1.1'),'S4.p1.1:s01','Prior kappa=2 lower bound is attributed to [22].',semantics='ATTRIBUTION')
edge('EXT:openai22',S('S4.SS1.p1.1'),'S4.SS1.p1.1:s01','Construction is explicitly similar to [22,Section9.2].',semantics='ATTRIBUTION')

# Literal family, C.4 proof, and definition obligations.
edge(S('S4.SS1.p1.1',2),D('S4.E11'),'S4.E11','Hard-family range d>=2 and kappa>=2.',semantics='DEFINITION_CONTEXT')
edge(D('S4.E11'),'INF:index-range','S4.E11','Finite-coordinate interpretation of the literal diagonal formula.','TYPING_IMPLICIT',semantics='DEFINITION_CONTEXT')
edge([D('S4.E11'),S('S4.SS1.p1.2')],'INF:theta-bound','A3.SS4.p1.1:s01','Derive angle range from literal grid, not a new input assumption.','INFERRED_EXPANSION',discharge=[{'premise':'d>=2, 1<=i<=d','source':'S4.SS1.p1.1:s02; Eq11 diagonal index convention','status':'standing source range and typing'}])
edge(['INF:theta-bound',D('S4.E11')],'INF:cos-and-eigenvalues','A3.SS4.p1.1:s01','Monotone affine image of cosine bounds; kappa-1 is positive.','INFERRED_EXPANSION',discharge=[{'premise':'kappa>=2','source':'S4.SS1.p1.1:s02','status':'source standing assumption'}])
edge(['INF:theta-bound','INF:cos-and-eigenvalues'],S('A3.SS4.p1.1'),'A3.SS4.p1.1:s01','Expanded proof of the source assertion.','INFERRED_EXPANSION')
edge([D('S4.E11'),S('S4.SS1.p1.2')],'INF:symmetry','S2.Ex1 / hard-family membership','Symmetry comes from the real diagonal conjugation, not from an added binder.','INFERRED_EXPANSION')
edge([S('A3.SS4.p1.1'),S('S4.SS1.p1.2'),S('S2.p2.1')],'INF:conjugation-order','A3.SS4.p1.1:s02','Orthogonal norm preservation transfers the eigenvalue interval.','INFERRED_EXPANSION',discharge=[{'premise':'O orthogonal','source':'O in O(d), S4.SS1.p1.2; S2.p2.1 definition','status':'source pointwise condition, not Haar event'}])
edge('INF:conjugation-order',S('A3.SS4.p1.1',2),'A3.SS4.p1.1:s02','Expanded quadratic-form argument for the exact Loewner conclusion.','INFERRED_EXPANSION')
edge(S('A3.SS4.p1.1',2),S('S4.Thmtheorem6.p1.1'),'S4.Thmtheorem6.p1.1','C.4 supplies the stated admissibility inequality; source result is pointwise every O.')
edge([S('S4.Thmtheorem6.p1.1'),'INF:symmetry',D('S2.Ex1')],S('S4.SS2.SSS0.Px4.p1.1'),'S4.SS2.SSS0.Px4.p1.1:s01','Bounds plus symmetry instantiate the whole precision-class predicate.','INFERRED_EXPANSION')
edge(['INF:symmetry',S('S4.SS1.p1.2',2)],'INF:quadratic-differentiation','A3.SS4.p2.1:s01','Unpack the asserted quadratic regularity and Hessian.','INFERRED_EXPANSION')
edge('INF:quadratic-differentiation','INF:gradient','A3.SS4.p2.1:s01 / S2.E1','Differentiate the literal quadratic. This intermediate formula is inferred, not a C.4 quote.','INFERRED_EXPANSION')
edge('INF:quadratic-differentiation',S('A3.SS4.p2.1'),'A3.SS4.p2.1:s01','Source explicitly states C-infinity and Hessian A; omitted proof bridge separately recorded.','INFERRED_EXPANSION')
edge([S('A3.SS4.p2.1'),S('A3.SS4.p1.1',2)],'INF:sc-smooth-adapter','A3.SS4.p2.1:s02','Hessian spectral bounds imply the two global regularity conclusions.','INFERRED_EXPANSION')
edge('INF:sc-smooth-adapter',S('A3.SS4.p2.1',2),'A3.SS4.p2.1:s02','Discharge strong convexity/smoothness internally.','INFERRED_EXPANSION')
edge([S('S4.SS1.p1.2',2),S('A3.SS4.p1.1',2)],'INF:positive-gap','A3.SS4.p2.1:s03','Quadratic evaluation plus lower order bound establishes unique minimizer.','INFERRED_EXPANSION')
edge('INF:positive-gap',S('A3.SS4.p2.1',3),'A3.SS4.p2.1:s03','The zero-minimizer witness and uniqueness are proved conclusions.','INFERRED_EXPANSION')
edge([D('S4.E11'),S('S4.SS1.p1.2'),S('A3.SS4.p1.1')],'INF:det-conjugation','A3.Ex160','Orthogonal determinant cancellation and positive eigenvalue product.','INFERRED_EXPANSION')
edge([S('A3.SS4.p1.1',2),'INF:symmetry','GAP:normalizer-meaning'],'GAP:gaussian-integration','A3.SS4.p3.1:s02 / A3.Ex160','Positive-definite Gaussian integration is required under the intended integral meaning.','INFERRED_EXPANSION',discharge=[{'premise':'symmetric positive definite A','source':'INF:symmetry and C.4 lower bound I<=A','status':'derived proof ingredient, not extra premise'}])
edge(['GAP:gaussian-integration','INF:det-conjugation'],D('A3.Ex160'),'A3.Ex160','Integral evaluation AND determinant invariance produce the two equal expressions.','INFERRED_EXPANSION')
edge(S('S4.SS1.p1.2',2),S('A3.SS4.p3.1'),'A3.SS4.p3.1:s01','Same associated target N(0,A^{-1}) as the hard-family definition.',semantics='DEFINITION_REUSE')
edge([D('A3.Ex160'),D('S4.E11')],'INF:normalizer-independence','A3.SS4.p3.2:s01','No O occurs in the fixed Lambda expression.','INFERRED_EXPANSION')
edge('INF:normalizer-independence',S('A3.SS4.p3.2'),'A3.SS4.p3.2:s01','Pointwise rotation invariance and public-spectrum knowledge.','INFERRED_EXPANSION')
edge(S('A3.SS4.p3.2'),S('S4.SS1.p2.1',2),'S4.SS1.p2.1:s02','C.4 expands the earlier known-normalizer assertion.',semantics='SOURCE_JUSTIFICATION')

# Remark4.2 exact identity, both replies, and explicitly inferred FO expansions.
edge('EXT:openai22',S('S4.Thmtheorem2.p1.1'),'S4.Thmtheorem2.p1.1:s01','kappa=2 recovery is attributed to the earlier construction.',semantics='ATTRIBUTION')
edge([D('S4.E11'),S('S4.SS1.p1.2')],S('S4.Thmtheorem2.p1.1',2),'S4.Thmtheorem2.p1.1:s02','Same angles and same O yield the exact affine precision identity.','INFERRED_EXPANSION',discharge=[{'premise':'A2 is original kappa=2 precision with same O','source':'same source sentence','status':'explicit relational condition; independent rotations are not allowed'}])
edge(S('S4.Thmtheorem2.p1.1',2),'INF:affine-forward-matvec','S4.Thmtheorem2.p1.1:s03','Multiply the literal matrix identity by the current x.','INFERRED_EXPANSION')
edge([S('S4.Thmtheorem2.p1.1',2),S('S4.SS1.p1.1',2)],'INF:affine-inverse-matvec','S4.Thmtheorem2.p1.1:s03','Solve for the same-point A2 reply.','INFERRED_EXPANSION',discharge=[{'premise':'kappa-1 != 0','source':'kappa>=2 from hard-family scope','status':'arithmetic consequence to discharge'}])
edge(['INF:affine-forward-matvec','INF:affine-inverse-matvec'],S('S4.Thmtheorem2.p1.1',3),'S4.Thmtheorem2.p1.1:s03','Both directions are required for the source claim that either reply determines the other.','INFERRED_EXPANSION')
edge([S('S4.Thmtheorem2.p1.1',2),S('S4.SS1.p1.2',2)],'INF:affine-forward-value','S4.Thmtheorem2.p1.1:s03 / S2.E1','Evaluate the same affine identity in x^T(.)x/2.','INFERRED_EXPANSION')
edge(['INF:affine-forward-value',S('S4.SS1.p1.1',2)],'INF:affine-inverse-value','S4.Thmtheorem2.p1.1:s03 / S2.E1','Solve the scalar relation using kappa-1 nonzero.','INFERRED_EXPANSION')
edge([S('S4.SS2.SSS0.Px4.p1.1'),D('S2.E1')],'INF:fo-hard-family','S2.E1 / C.4 result','Admissibility permits the S2 source oracle interface.','INFERRED_EXPANSION')
edge(['INF:fo-hard-family','INF:affine-forward-matvec','INF:affine-inverse-matvec','INF:affine-forward-value','INF:affine-inverse-value'],'INF:fo-affine-transport','S2.E1 + Remark4.2','Assemble the componentwise same-point exact first-order transformations.','INFERRED_EXPANSION')

# Context claims feeding the statistical comparison, never a claimed full theorem proof.
edge('EXT:openai22',S('S4.SS2.SSS0.Px1.p1.1',2),'S4.SS2.SSS0.Px1.p1.1:s02','Deferred-rotation argument is attributed to [22,Lemma9.2].',semantics='ATTRIBUTION')
edge(S('S4.SS2.SSS0.Px1.p2.1'),D('S4.Ex10'),'S4.Ex10','Block Krylov definition.',semantics='DEFINITION_CONTEXT')
edge([S('S4.Thmtheorem3.p1.1'),S('S4.Thmtheorem3.p1.1',2),D('S4.Ex10')],D('S4.Ex11'),'S4.Ex11','q integer >=0 and 2q+1<d; independent standard Gaussian witness vectors.',semantics='STATEMENT_CONTEXT')
edge('EXT:C1-proof',D('S4.Ex11'),'S4.SS2.SSS0.Px1.p3.1:s05','Proof deferred outside slice.',semantics='OUT_OF_SLICE_PROOF_POINTER')
edge(D('S4.Ex11'),S('S4.SS2.SSS0.Px1.p3.1',2),'S4.SS2.SSS0.Px1.p3.1:s02','Polynomial representation is the source-equivalent restatement.')
edge([S('S4.SS2.SSS0.Px1.p3.1'),S('S4.SS2.SSS0.Px1.p3.1',3)],S('S4.SS2.SSS0.Px1.p3.1',4),'S4.SS2.SSS0.Px1.p3.1:s04','Arbitrary output and extended-experiment coefficients motivate a simultaneous bound.',semantics='PROOF_MOTIVATION')
edge(S('S4.SS2.SSS0.Px2.p1.1',2),D('S4.Ex12'),'S4.Ex12','Define n=2q+1 and D_n.',semantics='DEFINITION_CONTEXT')
edge(D('S4.Ex12'),S('S4.SS2.SSS0.Px2.p1.2'),'S4.SS2.SSS0.Px2.p1.2:s01','Source high-frequency choice explanation.')
edge([S('S4.Thmtheorem4.p1.1'),S('S4.Thmtheorem4.p1.1',2)],D('S4.Ex13'),'S4.Ex13','Absolute C and q/d range scope tau.',semantics='DEFINITION_CONTEXT')
edge([D('S4.Ex13'),S('S4.Thmtheorem4.p1.2'),D('S4.Ex12')],D('S4.Ex14'),'S4.Ex14','Uniform cosine bound with explicit tau<=1/2 and probability .99.',semantics='STATEMENT_CONTEXT')
edge('EXT:C2-proof',D('S4.Ex14'),'S4.SS2.SSS0.Px2.p2.1:s01','Proof deferred outside slice.',semantics='OUT_OF_SLICE_PROOF_POINTER')
edge([D('S4.E11'),D('S4.Ex10')],S('S4.SS2.SSS0.Px2.p2.1',2),'S4.SS2.SSS0.Px2.p2.1:s02','Nonconstant affine lambda(cos theta) gives the equivalent cosine-polynomial span.')
edge(S('S4.SS2.SSS0.Px2.p2.1',2),S('S4.SS2.SSS0.Px2.p2.1',3),'S4.SS2.SSS0.Px2.p2.1:s03','Equivalent span removes kappa from the uniform estimate.')
edge([D('S4.Ex11'),D('S4.Ex14'),S('S4.SS2.SSS0.Px2.p3.1')],D('S4.Ex15'),'S4.Ex15','Representation AND uniform event imply the algorithm-output statistic estimate.',discharge=[{'premise':'event of Lemma4.4','source':'S4.SS2.SSS0.Px2.p3.1:s01','status':'explicit event condition, retained rather than assumed unconditional'}])
edge([S('S4.Thmtheorem5.p1.1'),S('S4.Thmtheorem5.p1.1',2)],D('S4.EGx1'),'S4.EGx1','Target U law, rho_kappa, M, mu_n, and 1<=n<d scope the exact means.',semantics='STATEMENT_CONTEXT')
edge('EXT:C3-proof',D('S4.EGx1'),'S4.SS2.SSS0.Px3.p2.1:s01','Proof deferred outside slice.',semantics='OUT_OF_SLICE_PROOF_POINTER')
edge([D('S4.EGx1'),S('S4.Thmtheorem5.p2.1')],D('S4.Ex17'),'S4.Ex17','Two-sided exponential moment-ratio bound needs d-n>=sqrt(kappa).',semantics='STATEMENT_CONTEXT')
edge([S('S4.SS1.p1.2'),S('S4.SS2.SSS0.Px3.p2.1',2),D('S4.EGx1'),S('S4.Thmtheorem5.p1.2')],S('S4.SS2.SSS0.Px3.p2.1',3),'S4.SS2.SSS0.Px3.p2.1:s03','Orthogonal transport of the exact conditional target supplies the Y means/variances.')
edge([D('S4.Ex15'),D('S4.Ex17')],S('S4.Thmtheorem2.p1.1',5),'S4.Thmtheorem2.p1.1:s05','Remark compares the algorithm bound and target mean-ratio scale.',semantics='SOURCE_COMPARISON',discharge=[{'premise':'regimes required by Lemmas4.4/4.5','source':'4.2 statements','status':'not discharged by the informal Remark alone; full4.3 proof outside slice'}])
edge(S('S4.Thmtheorem2.p1.1',5),S('S4.Thmtheorem2.p1.1',6),'S4.Thmtheorem2.p1.1:s06','Informal source explanation of sqrt(kappa) scale; does not bypass theorem range.',semantics='ASYMPTOTIC_EXPLANATION')

# Complete limitation topology. These are route limitations, not lower-bound counterexamples.
edge([S('S4.Thmtheorem1.p1.1'),D('S4.Ex9')],S('S4.SS4.p1.1'),'S4.SS4.p1.1:s01','Recalls exact kappa range.',semantics='MODEL_BOUNDARY')
edge([D('S4.Ex9'),S('S4.Thmtheorem1.p1.1')],S('S4.SS4.p1.1',2),'S4.SS4.p1.1:s02','Constant-accuracy lower bound has no epsilon growth.',semantics='MODEL_BOUNDARY')
edge([D('S4.Ex11'),D('S4.Ex14')],S('S4.SS4.SSS0.Px1.p1.1',2),'S4.SS4.SSS0.Px1.p1.1:s02','States the representation-plus-uniform-control method under discussion.',semantics='ROUTE_DESCRIPTION')
edge(D('S4.Ex10'),S('S4.SS4.SSS0.Px1.p1.1',3),'S4.SS4.SSS0.Px1.p1.1:s03','The source definition has (q+1)^2 generating vectors.')
edge([S('S4.Thmtheorem7.p1.1'),S('S4.SS4.SSS0.Px1.p1.1',4)],D('S4.Ex28'),'S4.Ex28','Dimension formula is source-stated under independent Gaussian generators and distinct eigenvalues.',semantics='STATEMENT_CONTEXT')
edge('EXT:Lemma4.7-proof',D('S4.Ex28'),'S4.Ex28','No proof of dimension formula audited here.',semantics='OUT_OF_SLICE_PROOF_POINTER')
edge(D('S4.Ex28'),S('S4.SS4.SSS0.Px1.p2.1'),'S4.SS4.SSS0.Px1.p2.1:s01','At (q+1)^2>=d the random Krylov space is all R^d almost surely.',discharge=[{'premise':'(q+1)^2>=d','source':'same sentence','status':'explicit failure-regime condition'}])
edge(D('S4.E11'),S('S4.SS4.SSS0.Px1.p2.1',2),'S4.SS4.SSS0.Px1.p2.1:s02','Cosine grid gives sum cos^2=d/2 and a coordinate >=1/sqrt2.',discharge=[{'premise':'n=2q+1<d','source':'same sentence','status':'explicit; cannot be dropped'}])
edge([S('S4.SS4.SSS0.Px1.p2.1'),S('S4.SS4.SSS0.Px1.p2.1',2),S('S4.SS4.SSS0.Px1.p2.1',3)],D('S4.Ex29'),'S4.Ex29','Full space contains the extremal coordinate vector; hence a constant-size statistic.')
edge([D('S4.Ex29'),S('S4.SS4.SSS0.Px1.p2.2')],S('S4.SS4.SSS0.Px1.p2.2',2),'S4.SS4.SSS0.Px1.p2.2:s02','Required <=1/2 uniform separation conflicts with >=1/sqrt2 in the stated regime.',semantics='ROUTE_FAILURE_ONLY')
edge(S('S4.SS4.SSS0.Px1.p2.2',2),S('S4.SS4.SSS0.Px1.p1.1'),'S4.SS4.SSS0.Px1.p1.1:s01','Source asymptotic interpretation at kappa on order d/log^2 d.',semantics='ROUTE_FAILURE_ONLY')
edge(D('S4.Ex14'),S('S4.SS4.SSS0.Px2.p1.1',2),'S4.SS4.SSS0.Px2.p1.1:s02','Uniform algorithm bound requires threshold t>=a for this certification.',semantics='ROUTE_NECESSITY_AS_ASSERTED')
edge([D('S4.EGx1'),S('S4.Thmtheorem5.p1.2')],S('S4.SS4.SSS0.Px2.p1.1',3),'S4.SS4.SSS0.Px2.p1.1:s03','Chebyshev-based target-side certification requires t<|mu_n|/M.',semantics='ROUTE_NECESSITY_AS_ASSERTED')
edge([S('S4.SS4.SSS0.Px2.p1.1',2),S('S4.SS4.SSS0.Px2.p1.1',3)],S('S4.SS4.SSS0.Px2.p1.1',4),'S4.SS4.SSS0.Px2.p1.1:s04','A common threshold must satisfy a<|mu_n|/M.')
edge('EXT:FactC6-calculation',S('S4.SS4.SSS0.Px2.p1.1',5),'S4.SS4.SSS0.Px2.p1.1:s05','The source explicitly invokes the Bernstein calculation; outside-slice input retained.',semantics='OUT_OF_SLICE_PROOF_POINTER')
edge(D('S4.Ex17'),S('S4.SS4.SSS0.Px2.p1.1',6),'S4.SS4.SSS0.Px2.p1.1:s06','Upper ratio bound recalled from Lemma4.5.',semantics='SOURCE_REUSE',discharge=[{'premise':'Lemma4.5 stated regime includes d-n>=sqrt(kappa) for Ex17','source':'S4.Thmtheorem5.p2.1','status':'retained as source context; generalization beyond it is not certified here'}])
edge([S('S4.SS4.SSS0.Px2.p1.1',4),S('S4.SS4.SSS0.Px2.p1.1',5),S('S4.SS4.SSS0.Px2.p1.1',6),S('S4.SS4.SSS0.Px2.p1.1',7)],D('S4.Ex30'),'S4.Ex30','ALL lower-a, separating-gap, exponential-upper and n=2q+1 ingredients produce the displayed chain.')
edge(D('S4.Ex30'),S('S4.SS4.SSS0.Px2.p1.2'),'S4.SS4.SSS0.Px2.p1.2:s01','Taking logarithms bounds q by O(sqrt(kappa) log d), independent of epsilon.')
edge(S('S4.SS4.SSS0.Px2.p1.2'),S('S4.SS4.SSS0.Px2.p1.2',2),'S4.SS4.SSS0.Px2.p1.2:s02','Changing threshold/constants within this route cannot add epsilon dependence.',semantics='ROUTE_FAILURE_ONLY')
edge([S('S4.SS4.SSS0.Px1.p2.2',2),S('S4.SS4.SSS0.Px2.p1.2',2)],S('S4.Thmtheorem8.p1.1'),'S4.Thmtheorem8.p1.1:s01','The two route limitations concern this proof, not impossibility for the family.',semantics='SCOPE_BOUNDARY')

routes = {
 'schema':'gc-source-only-routes-v1',
 'rule':'Conjunction inside a sufficient route; disjunction only between complete independently sufficient routes for the same output. Definition-context and boundary pointers are not proof hyperedges.',
 'routes':[
  {'id':'R:C4-admissibility','mode':'source-asserted-with-inferred-expansions','target':S('S4.Thmtheorem6.p1.1'),
   'AND':['Eq11 parameter scope and finite index range','angle interval','strict cosine interval','positive kappa-1 affine scale','orthogonal conjugation order'],
   'not_required':['Haar randomness','randomness independence','algorithm output','Krylov representation','normalizer formula','Theorem4.1 delta/epsilon range'],
   'status':'proposed graph; no implementation or topology acceptance'},
  {'id':'R:C4-regularity','target':S('A3.SS4.p2.1',2),'AND':['literal quadratic','symmetry derived from diagonal conjugation','quadratic differentiation','spectral Hessian bounds'],
   'status':'omitted differentiation/convexity bridges explicit; not extra theorem assumptions'},
  {'id':'R:C4-normalizer','target':S('A3.SS4.p3.2'),'AND':['positive symmetric precision','normalizer integral convention (inferred)','Gaussian integration bridge','determinant conjugation','fixed/public Lambda'],
   'status':'source formula literal, analytical/conventional omissions separately visible'},
  {'id':'R:MV-forward','target':'INF:affine-forward-matvec','AND':['same-rotation affine precision identity','current query x'],
   'status':'inferred algebraic expansion of explicit source determination claim'},
  {'id':'R:MV-reverse','target':'INF:affine-inverse-matvec','AND':['same-rotation affine precision identity','kappa-1 nonzero from kappa>=2','current query x'],
   'status':'reverse direction is not alternative to forward for bidirectional equivalence'},
  {'id':'R:FO-via-MV','target':'INF:fo-affine-transport','AND':['literal S2 FO-to-MV projection','Remark4.2 MV affine transformation','literal S2 MV-to-FO reconstruction'],
   'provenance':'INFERRED_ALTERNATIVE_EXPANSION','status':'mathematical source-derived route, not an author-stated distinct proof'},
  {'id':'R:FO-components','target':'INF:fo-affine-transport','AND':['hard-family admissibility and S2 FO formula','affine value relations','affine gradient/matvec relations','nonzero kappa-1'],
   'provenance':'INFERRED_ALTERNATIVE_EXPANSION','status':'mathematical source-derived route, not an author-stated distinct proof'},
  {'id':'R:limit-kappa','target':S('S4.SS4.SSS0.Px1.p2.2',2),'AND':['dimension lemma statement','saturation (q+1)^2>=d','n=2q+1<d','cosine-square grid identity','test requires uniform <=1/2'],
   'status':'source proof-route obstruction only'},
  {'id':'R:limit-accuracy','target':S('S4.SS4.SSS0.Px2.p1.2',2),'AND':['algorithm-side threshold requirement','target Chebyshev requirement','FactC6 Bernstein floor','target moment upper bound','n=2q+1','logarithms'],
   'status':'source proof-route obstruction only; FactC6 proof outside slice'},
 ],
 'OR_groups':[
  {'target':'INF:fo-affine-transport','routes':['R:FO-via-MV','R:FO-components'],
   'logical_form':'(S2 projection AND Remark4.2 matvec transport AND S2 reconstruction) OR (componentwise value AND componentwise gradient formulas AND admissibility)',
   'provenance':'INFERRED_ROUTE_ALTERNATIVES','status':'not source-literal alternative proofs; no selected implementation; no cost/API comparison possible pre-proof'},
 ],
 'false_ANDs_rejected':[
  'Haar distribution and algorithm-seed independence are not needed for pointwise C.4 admissibility or affine reply algebra.',
  'Normalizer integration is not a prerequisite for the literal quadratic FO reply or affine reply transport.',
  'Both alternative FO expansions must not be flattened into one route requiring both proofs.',
  'Both MV directions are AND for bidirectional equivalence, not OR for the same directional conclusion.',
  'Krylov/statistical lemmas are not prerequisites for local deterministic family semantics.',
  'The two analysis limitations are parallel boundaries, not jointly needed premises of admissibility.',
 ],
}

definitions = [
 {'id':'DEF:precision','source':['S2.Ex1'],'kind':'literal','meaning':'Real dxd symmetric matrices with I_d <= A <= kappa I_d.',
  'domain':'d integer >=1; real kappa>=1; Euclidean/Loewner conventions in S2.',
  'obligations':['Preserve symmetry as well as both spectral inequalities.','No arbitrary-matrix fallback to zero or default positive precision.'],
  'ingredient_nodes':['INF:symmetry',S('A3.SS4.p1.1',2)]},
 {'id':'DEF:quadratic','source':['S2.SS0.SSS0.Px1.p1.2','S4.SS1.p1.2','A3.SS4.p2.1'],'kind':'literal','meaning':'f_A(x)=V_A(x)=x^T A x/2 on the whole real Euclidean carrier.',
  'obligations':['Preserve the factor 1/2, transpose/inner-product convention, and all-x domain.','C.4 changes the letter f to V; identify only the identical displayed quadratic.','Gradient formula is derivative output; do not silently define gradient to be Ax without derivative meaning.']},
 {'id':'DEF:FO','source':['S2.E1'],'kind':'literal','meaning':'Exact ordered pair (quadratic value, mathematical gradient)=(x^T A x/2,Ax).',
  'obligations':['Preserve value and vector components, common query x, input A and real exact arithmetic.','For hard-family use derive membership/symmetry; no assumption that merely restates oracle correctness.'],
  'ingredient_nodes':['INF:gradient','INF:fo-hard-family']},
 {'id':'DEF:hard-family','source':['S4.E11','S4.SS1.p1.2'],'kind':'literal','meaning':'theta_i=((i-1/2)pi)/d, lambda_i=(kappa+1)/2+((kappa-1)/2)cos(theta_i), Lambda=diag(lambda_i), A=O Lambda O^T.',
  'domain':'d>=2, kappa>=2, i=1,...,d; O real orthogonal.',
  'obligations':['Preserve the half-node cosine grid, order/indexing and same O across kappa comparisons.','Do not replace the cosine grid by an arbitrary spectrum inside [1,kappa].','Haar and seed independence govern the randomized experiment; pointwise facts quantify every orthogonal O.']},
 {'id':'DEF:target','source':['S2.SS0.SSS0.Px1.p1.2','S4.SS1.p1.2','A3.SS4.p3.1'],'kind':'literal','meaning':'Centered Gaussian N(0,A^{-1}) with A a precision, not covariance.',
  'obligations':['Derive A inverse exists from positive definiteness.','Do not swap precision/covariance, introduce a nonzero mean, or normalize with the wrong base measure.']},
 {'id':'DEF:normalizer','source':['A3.SS4.p3.1','A3.Ex160','A3.SS4.p3.2'],'kind':'literal-formula-with-inferred-integral-convention',
  'meaning':'Source formula Z_A=(2pi)^(d/2)(det A)^(-1/2)=(2pi)^(d/2)(det Lambda)^(-1/2).',
  'literal_vs_inferred':'C.4 does not literally spell out integral exp(-V_A) dx. That conventional meaning and Gaussian-integration proof must be discharged separately.',
  'obligations':['Use real Lebesgue Gaussian normalization, positive determinant and real square-root convention.','Keep finite/positive integral and determinant invariance as proof edges.','Public fixed spectrum supplies information, not an expected-cost oracle or executable bit-complexity bound.'],
  'ingredient_nodes':['GAP:normalizer-meaning','GAP:gaussian-integration','INF:det-conjugation']},
 {'id':'DEF:randomized-algorithm','source':['S2.SS0.SSS0.Px2.p1.1'],'kind':'characterized-model-predicate',
  'meaning':'Borel queries/stopping/output from independent internal randomness and past responses; arbitrary Rd-valued Borel output.',
  'obligations':['Keep independence from input and full history dependence.','Do not force output into the query/reply span.','This predicate is not a chosen unique algorithm; no artificial existence/default object.']},
 {'id':'DEF:fixed-budget','source':['S2.SS0.SSS0.Px2.p1.1','S2.SS0.SSS0.Px4.p1.2'],'kind':'literal-predicate',
  'meaning':'At most T queries for every admissible input AND every realization of the seed.',
  'obligations':['Universal runwise cap, including stopping behavior, is stronger than an expectation bound.','No expected-query complexity is defined in the scoped source; its replacement requires a distinct claim.']},
 {'id':'DEF:TV','source':['S2.Ex2','S2.SS0.SSS0.Px3.p1.2'],'kind':'literal','meaning':'sup over measurable B of |P(B)-Q(B)| = one-half L1 density difference under any common dominating measure.',
  'obligations':['Preserve the factor 1/2 and measurable-set scope.','The test bound requires measurable h in [0,1].']},
 {'id':'DEF:QG','source':['S2.E2','S2.SS0.SSS0.Px4.p1.1','S2.SS0.SSS0.Px4.p1.2'],'kind':'literal-infimum-definition',
  'meaning':'Infimum of T in nonnegative integers for which some fixed-cap algorithm has sup_A TV(output-law-with-seed-averaged,pi_A)<=epsilon.',
  'obligations':['Keep quantifier order exists Alg then uniform sup over A, and separate averaged output accuracy from pointwise cap.','Do not invent empty-feasible-set fallback zero; the scoped text does not specify a Lean codomain/default convention.','No seedwise TV guarantee is asserted.']},
 {'id':'DEF:minimizer','source':['A3.SS4.p2.1'],'kind':'characterized','meaning':'The unique global minimizer of the literal potential is zero.',
  'obligations':['Prove zero attains the minimum and no other point does, using positive gap.','No if-exists default, choice witness, minimizer uniqueness, or gap premise may be added to a source-facing theorem.'],
  'ingredient_nodes':['INF:positive-gap']},
 {'id':'DEF:SC-smooth','source':['A3.SS4.p2.1'],'kind':'characterized-property','meaning':'Global Euclidean 1-strong convexity and kappa-smoothness.',
  'literal_vs_inferred':'Words/constants are literal C.4; Bregman-inequality/Lipschitz-gradient semantic expansions are inferred conventional adapters.',
  'obligations':['Source supplies these as conclusions. Derive from Hessian bounds on all Rd.','No added higher derivative, integrability or bounded-domain premise.'],
  'ingredient_nodes':['INF:sc-smooth-adapter']},
 {'id':'DEF:Krylov','source':['S4.Ex10'],'kind':'literal','meaning':'span{Lambda^j g_a:1<=a<=q+1,0<=j<=q}.',
  'obligations':['Preserve q+1 seed vectors, degree q and coefficient dependence on full experiment.','Do not identify dimension with generator count without the separate dimension lemma.']},
]

hypotheses = {
 'schema':'gc-source-only-hypothesis-audit-v1',
 'rule':'No endpoint or Lean signature was supplied/read; this classifies raw-source inputs and proof ingredients only. It is not a Statement Seal.',
 'source_inputs':[
  {'scope':'S2 precision/complexity','class':'SOURCE','inputs':['d integer>=1','kappa>=1','A real symmetric with I<=A<=kappa I','x in Rd','0<epsilon<1 for QG']},
  {'scope':'S2 randomized experiment','class':'STANDING','inputs':['internal randomness independent of input','Borel query, stopping and output maps from seed/history','budget cap for every input and every seed realization']},
  {'scope':'Eq11 hard family and C.4','class':'SOURCE/STANDING','inputs':['d>=2','kappa>=2','O in O(d)','literal Eq11 theta/lambda/Lambda','A=O Lambda O^T']},
  {'scope':'Hard-family random experiment only','class':'SOURCE','inputs':['O Haar distributed','O independent of private seed'],
   'not_needed_for':['pointwise admissibility','quadratic derivative identities','normalizer O-invariance','same-rotation affine algebra']},
  {'scope':'Remark4.2 affine comparison','class':'SOURCE','inputs':['A2 is original kappa=2 family at same d/grid and same O','kappa>=2 inherited from4.1']},
  {'scope':'Theorem4.1 only','class':'SOURCE','inputs':['fixed delta in(0,1)','exists d0(delta)','every integer d>=d0(delta)','2<=kappa<=d^(1-delta)','0<epsilon<=1/10'],
   'not_needed_for':['local Eq11/C.4 properties','affine reply identities']},
  {'scope':'4.4 proof-route boundaries','class':'SOURCE','inputs':['q integer>=0','independent standard Gaussian Krylov seeds','n=2q+1<d for cosine-coordinate argument','saturation(q+1)^2>=d for kappa failure','test-certification threshold restrictions'],
   'caution':'Conditional limitation statements cannot become global impossibility claims.'},
  {'scope':'Euclidean conventions','class':'TYPING','inputs':['finite real matrices/vectors','coordinate i=1,...,d','ordinary transpose, Euclidean norm, real determinant']},
 ],
 'proof_ingredients_not_binders':[
  'strict angle/cosine/eigenvalue bounds','symmetry','Loewner bounds','positive definiteness and invertibility',
  'C-infinity','gradient Ax','Hessian A','strong convexity','smoothness','positive energy gap','zero unique minimizer',
  'determinant conjugation/product/positivity','normalizer integral finiteness and value','normalizer independence from O',
  'affine matrix identity and both reply formulas','kappa-1 nonzero','first-order/matrix-vector exact simulation',
 ],
 'expected_cost_boundary':{'exact_source':'Throughout the paper, query budgets are deterministic caps on the number of queries in each run, rather than bounds on the expected number of queries.',
                           'meaning':'No expected-query definition or extension is admitted; expected caps do not imply the source fixed cap.'},
 'no_proposed_public_binders':True,'no_Lean_target_inspected':True,
}

provenance = {
 'schema':'gc-source-only-provenance-v1','role':'independent PREPROOF SOURCE GRAPH extractor',
 'task':'Phase1 raw-source reconstruction, before endpoint/candidate disclosure',
 'actor':'/root/fixed_foq_source_graph','status':'EXTRACTION_FROZEN_PENDING_DISTINCT_TOPOLOGY_CHALLENGE',
 'not_statuses':['SOURCE_VERIFIED','SOURCE_ADMITTED','STATEMENT_SEALED','PROVED','VERIFIED','PURIFIED'],
 'inputs_read':[str(SOURCE.relative_to(ROOT))]+[
  'AGENTS.md','.agents/skills/astis-source-dependency-audit/SKILL.md','.agents/skills/astis-substantive-advance/SKILL.md',
  'docs/proof-digestion-protocol.md','docs/evidence-routed-memory-protocol.md','docs/theorem-publication-protocol.md','docs/contributor-codex-contract.md'],
 'raw_source_blocks': [x[0] for x in scopes]+['bib.bib3'],
 'source_raw_hash_recomputed':EXPECTED,
 'implementation_Lean_read':False,'candidate_or_sealed_endpoint_read':False,'API_search_performed':False,
 'other_actor_private_evidence_read':False,'atlas_accessed':False,
 'shared_state_or_ledger_changes':False,'mathematical_proof_or_compilation_claim':False,
 'phase1_independence':'Graph, coverage, hypotheses and definition meaning reconstructed from the pinned raw blocks. No implementation topology or candidate statement was available.',
 'inference_labels':{
  'EXACT_SOURCE':'Statement/formula/paraphrase use or edge is explicit in pinned source.',
  'INFERRED_EXPANSION':'Mathematical bookkeeping/semantic bridge reconstructed by extractor; not claimed to be literal source wording.',
  'TYPING_IMPLICIT':'Carrier/index interpretation implicit in finite Euclidean notation.',
  'INFERRED_CONVENTION':'Conventional meaning needed for a named source quantity; not literally defined in the scoped blocks.',
  'SOURCE_POINTER_ONLY':'A source citation/deferred-proof locator retained without reading/admitting that proof.'},
 'review_required':['Distinct raw-source topology challenger rereads source and proposed public records, without implementation Lean or private rationale.',
                    'Endpoint/binder/definition comparison occurs only after this phase1 manifest is frozen.',
                    'Full theorem4.1 proof/root closure is explicitly outside this bounded slice.'],
}

boundary = r'''# Phase 1 raw-source graph: frozen extraction, pending challenge

This packet was reconstructed from the pinned local HTML before any candidate endpoint, target seal, implementation Lean or proof API was disclosed. It is a proposed source graph, not source admission or a proof certificate. A distinct actor must challenge coverage and topology.

The source is arXiv:2610.20492v1, *On Complexity of Gaussian Sampling*, 951991 bytes, SHA256 `6bc5ddc1e19cea9ba1dfe862fa79bc69fe861dff045d6ad1c7baa4a113c37915`. `source-inputs.json` gives exact raw byte ranges and hashes. Its eight disjoint scopes contain all of S2, hard family/Remark4.2, all of4.2 statements, all C.4, all4.4 and the necessary main-theorem parameter context. The earlier [22] bibliography item is identity-only. No source proof outside those scopes is certified.

S2 defines the real symmetric precision class, the literal quadratic and centered Gaussian, exact value-gradient reply, Borel adaptive randomized algorithm and uniform total-variation complexity. Accuracy concerns the output law averaged over the seed. A query budget is a deterministic cap for every admissible input and every seed realization. The source explicitly distinguishes this from expected query cost and does not define an expected-query complexity in this slice.

Eq.11 fixes the half-node cosine grid and its affine eigenvalues for d>=2 and kappa>=2. The random object is the orthogonal eigenbasis. Haar randomness and seed independence are part of the lower-bound experiment; pointwise C.4 conclusions quantify every orthogonal O. The local deterministic claims do not need delta, epsilon, Krylov representation or statistical separation.

C.4 explicitly asserts strict angle/cosine/eigenvalue bounds, Loewner bounds, C-infinity regularity, Hessian A, 1-strong convexity, kappa-smoothness, the positive quadratic gap and unique minimizer zero, the associated centered Gaussian, and the determinant normalizer formula. It explicitly concludes the normalizer is independent of O and known when the fixed spectrum is public. It does not literally state a gradient formula or an integral definition for Z_A. The proposed graph labels gradient differentiation, the integral convention and Gaussian integration as inferred bridges. These cannot be imported as convenience public premises.

Remark4.2 literally states A_kappa=(kappa-1)A_2-(kappa-2)I for the same O and says either matrix-vector reply determines the other. The expanded forward/reverse reply formulas and componentwise first-order transformations in this graph are algebraic consequences, not quotations. The reverse transformation uses kappa-1 nonzero, discharged from kappa>=2. Different rotations would not satisfy the comparison condition. The normalizer is independent of these reply identities.

The admissibility route conjoins the literal grid, parameter bounds and orthogonal conjugation. The normalizer route additionally needs the Gaussian integral and determinant invariance. Two inferred sufficient expansions of first-order reply transport are explicit OR-routes: projection/transport/reconstruction, or direct value and gradient component formulas. Both directions are still jointly required for bidirectional equivalence. No implementation route has been selected.

Theorem4.1 has quantifier order fixed delta in(0,1), then d0(delta), then all sufficiently large integer d, kappa in[2,d^(1-delta)] and epsilon in(0,1/10]. It is a constant-accuracy scale and does not grow as epsilon decreases. This packet does not inspect its proof in4.3.

Section4.4 limits this analysis. For the kappa limitation, the full-space Krylov dimension argument and cosine-coordinate obstruction have their own conditions, including n=2q+1<d. For the accuracy limitation, threshold compatibility, the Bernstein floor and target exponential bound are separate conjunctive ingredients. C.1-C.3, Fact C.6 and the proof of Lemma4.7 remain explicit outside-slice pointers. Remark4.8 says stronger lower bounds for this same fixed-spectrum family are unknown. Neither limitation is a theorem that the family cannot support a stronger result.

The coverage inventory lists every sentence or display continuation, every display, every math occurrence, every citation occurrence and every structural heading in the scoped blocks. Headings and the end-of-proof marker are explicitly excluded as typography; body mathematics is represented. A shared node may cover inline formula occurrences within its one sentence; each formula still has its own exact raw span and hash. Mechanical zero-unmapped coverage does not replace independent mathematical review.
'''

# Ensure all math in scoped blocks has one and only one explicit disposition.
expected_math={m['id'] for a,_,_ in scopes for m in soup.find(id=a).find_all('math')}
assert math_covered==expected_math,(expected_math-math_covered, math_covered-expected_math)
assert len({x['unit_id'] for x in coverage})==len(coverage)
assert all(x.get('disposition') in {'NODE','EXCLUDED'} for x in coverage)
assert all(x.get('node_id') in node_ids for x in coverage if x['disposition']=='NODE')

coverage_obj={
 'schema':'gc-source-only-exhaustive-coverage-v1','status':'extractor-complete-pending-independent-review',
 'granularity':'sentence/display-continuation + separate every math occurrence + every display + citation occurrences + structural headings',
 'sentences_are_normalized_renderings':'Whitespace normalized; MathML alttext restored verbatim. Raw parent paragraphs remain in exact extracted blocks and raw byte spans.',
 'statistics':{
  'units':len(coverage),'node_dispositions':sum(x['disposition']=='NODE' for x in coverage),
  'excluded_dispositions':sum(x['disposition']=='EXCLUDED' for x in coverage),
  'source_math_occurrences':len(expected_math),'unmapped_math_occurrences':0,
  'source_sentence_or_continuation_units':sum(x['unit_kind']=='sentence-or-display-continuation' for x in coverage),
  'source_display_units':len(display_lookup),'graph_nodes':len(nodes),'edges':len(edges),
 },'units':coverage,
}

def put_json(name,data):
    files[name]=(json.dumps(data,ensure_ascii=False,indent=2)+'\n').encode('utf-8')

put_json('source-inputs.json',source_inputs)
put_json('coverage.json',coverage_obj)
put_json('nodes.json',{'schema':'gc-source-only-nodes-v1','status':'proposed','nodes':nodes})
put_json('edges.json',{'schema':'gc-source-only-edges-v1','edge_contract':'consumer_use_site required; source/context/attribution/route boundaries are not Lean dependencies','edges':edges})
put_json('routes.json',routes)
put_json('definition-audit.json',{'schema':'gc-source-only-definition-audit-v1','status':'source-meaning-obligations, no Lean candidate read','definitions':definitions})
put_json('hypothesis-audit.json',hypotheses)
put_json('provenance.json',provenance)
files['README.md']=boundary.encode('utf-8')

checks={
 'source_bytes_and_sha256':'PASS','scoped_raw_spans_hash_to_exact_source':'PASS',
 'all_in_scope_math_occurrences_disposed_once':'PASS','coverage_unit_ids_unique':'PASS',
 'all_node_dispositions_resolve':'PASS','all_edge_endpoints_resolve':'PASS',
 'source_verified_or_admitted':False,'independent_topology_review':'PENDING',
 'candidate_or_implementation_comparison':'NOT_STARTED',
 'counts':coverage_obj['statistics'],
 'meaning':'Mechanical structural checks only; does not certify mathematical coverage/topology.'}
put_json('structural-checks.json',checks)

manifest={
 'schema':'gc-source-only-phase1-manifest-v1',
 'freeze_id':'gc-fixed-spectrum-source-graph-phase1-20261108',
 'freeze_kind':'immutable-raw-source-extraction-before-endpoint-disclosure',
 'source_sha256':EXPECTED,'source_bytes':len(raw),
 'status':'FROZEN_EXTRACTION_PENDING_DISTINCT_TOPOLOGY_CHALLENGE',
 'files':[{'path':p,'bytes':len(b),'sha256':sha(b)} for p,b in sorted(files.items())],
 'manifest_self_hash':'External manifest.sha256 hashes these exact manifest.json bytes; no recursive self-hash.',
 'successor_policy':'Do not overwrite these bytes. Challenges/corrections require separately named successor evidence.'}
put_json('manifest.json',manifest)
manifest_hash=sha(files['manifest.json'])
files['manifest.sha256']=(manifest_hash+'  manifest.json\n').encode()

for out in (PRIVATE,PUBLIC):
    for filename,content in files.items():
        dest=out/filename
        assert not dest.exists()
        dest.parent.mkdir(parents=True,exist_ok=True)
        dest.write_bytes(content)
    for record in manifest['files']:
        b=(out/record['path']).read_bytes()
        assert sha(b)==record['sha256'] and len(b)==record['bytes']
    assert sha((out/'manifest.json').read_bytes())==manifest_hash

print(json.dumps({'status':manifest['status'],'manifest_sha256':manifest_hash,
                  'private_dir':str(PRIVATE.relative_to(ROOT)),'public_dir':str(PUBLIC.relative_to(ROOT)),
                  'files_per_copy':len(files),'statistics':coverage_obj['statistics']},ensure_ascii=False,indent=2))
