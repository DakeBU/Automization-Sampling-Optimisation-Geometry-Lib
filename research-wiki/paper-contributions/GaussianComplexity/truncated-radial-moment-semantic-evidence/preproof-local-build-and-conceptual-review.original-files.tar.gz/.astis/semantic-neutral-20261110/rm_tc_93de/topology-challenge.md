# Final independent topology challenge

Both sealed literal types stand. The frozen source graph has one missing definition-use edge. Its scalar estimates, constants, endpoints, and analytic dependencies agree with the source and the typed overlay.

The source reconstruction and typed judgment were separately frozen before the author’s source graph was opened. The final manifest pins both independent freezes, the three author source artifacts, and the author’s typed overlay and manifest. `topology-commands-results.md` records the reads and checks.

## Standing assumptions and normalization

The earlier typed freeze left the provenance of `hq` open within its then-authorized paragraphs. The pinned HTML now directly resolves it. Appendix C.2 identifies itself as the proof of Lemma 4.4, and line 1211 in that lemma’s statement gives `S4.Thmtheorem4.p1.m2` for \(q\ge0\) and `S4.Thmtheorem4.p1.m3` for \(2q+1<d\). Thus `hq` is a standing premise for this scalar source slice. Natural `q` implements the nonnegative count in \(r=q+1\). The local inequalities \(d\ge2\), \(r>0\), \(1000d>1\), and \(L>0\) follow. The local estimate can use the weaker \(d\ge1\). The extra strength is inherited source scope.

The types use \(E=\mathbb R^{q+1}\) with its Euclidean norm and the actual \(N(0,I_{q+1})\) law, implemented by a standard-coordinate Gaussian product pushed through an orthonormal basis. Row-law transport preserves the squared norm probabilities and integrals for each source row. The Gaussian event measure is finite, so `ENNReal.toReal` gives ordinary probability. The real level integral uses Lebesgue volume restricted to \(s>0\). Since the singleton \(\{0\}\) has zero level measure, this restriction gives the source integral from \(0\) to \(\infty\). The separate \(L\,\mathrm{tail}(0)\) term retains the strict \(R>L\) boundary contribution. The consumer’s \(R\le L\) indicator includes equality. The two threshold events are complementary even with an atom at \(L\).

## Backward scalar closure

* **p10 to p11.** The named Markov step in `A3.Ex104.m1` uses the exact stated \( \mathbb E e^{R_i/3}=3^{r/2} \), the positive exponential threshold, and the logarithm comparison. The source graph retains it as a reused display. At `A3.SS2.p11.1`, \(x=\log(1000d)+s/3\) is admissible for every real \(s\ge0\), gives the exact shifted threshold \(2r+3x=L+s\), and gives \(e^{-x}=e^{-s/3}/(1000d)\). The all-rows union bound and its \(0.999\) event form a sibling branch.
* **p11 identity and bound.** The display group `A3.EGx10` contains `A3.Ex106.m1` and `A3.Ex106.m2`. The graph exposes its omitted nonnegative positive-part layer-cake and Tonelli argument. The shifted tail is Borel by monotonicity. Finite event mass and the integrable envelope allow passage from the extended nonnegative equality to the real Gaussian moment and real level integral. The quantitative bound then uses the \(s=0\) tail bound, \(L\ge0\), and the exponential integral with value \(3\). The producer returns both integrability conclusions and the exact equality and bound \((L+3)/(1000d)\).
* **p12 scalar range, identity and bound.** The scalar formula in `A3.Ex108.m1#a` gives \(a=\mathbb E[R_i\mathbf1_{\{R_i\le L\}}]/r\). Common \(a\) follows from the common marginal. The omitted coordinate second-moment calculation yields the exact finite \(\mathbb E R_i=r\) at `A3.SS2.p12.m3`. Domination by \(R_i\) yields both truncated integrals, and the complementary split and \(r>0\) give the range and identity in `A3.SS2.p12.m4` and `A3.Ex109.m1#identity`. The upper bias bound in `A3.Ex109.m1#bound` combines this identity with the producer’s upper bound and divides by \(r\) to obtain \((L+3)/(1000rd)\).
* **Route scope.** The author’s single source route is sufficient and follows the printed use sites. The exact radius mean gives an independent way to obtain discarded integrability in the consumer. The overlay keeps that route independent of the producer. The p12 range and identity therefore have no dependency on p11, and the p12 upper inequality consumes the p11 upper bound through the scalar bias identity. No source-level alternative proof is printed for these goals. The all-rows event, cross-row independence, the matrix component of Ex108, truncated matrices, Fact C.5, and downstream concentration have explicit contextual dispositions.

## Minimal source-graph correction

The 79 local coverage spans agree with the raw HTML byte ranges, character ranges, line locations, and stored digests. Their dispositions identify 27 node-backed items and 52 exclusions. The graph’s backward closure reaches all nodes except `row-definition`, although the covered row formula in `A3.Ex85.m1#row` supplies \(\gamma_i\) for the radius definition at `A3.SS2.p10.m2`. The graph’s prose already describes this use. Append the following edge object to `edges` in `source-graph.json` to record it.

```json
{
  "from_all": ["row-definition"],
  "to": "radial-variable",
  "use_site": "A3.SS2.p10.m2",
  "discharge_or_use": "Apply the squared Euclidean norm to the row defined in A3.Ex85.m1#row."
}
```

The in-memory replay gives full backward closure and preserves acyclicity. This is a source definition-use correction. The statements, binders, analytic proof obligations, and coverage dispositions are unaffected. No other defect was identified in the bounded topology and typed correspondence.
